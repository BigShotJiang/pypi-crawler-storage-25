# Plutus CLI

**Your AI assistant in the terminal.** A full-featured command-line client for [Plutus Cloud](https://useplutus.ai) — chat with Plutus, manage email, connectors, memory, skills, workers, and more, all from your terminal.

## Installation

```bash
pip install plutus-cli
```

Or install from source:

```bash
git clone https://github.com/Crypt0nly/plutus-cli.git
cd plutus-cli
pip install -e .
```

## Quick Start

### 1. Authenticate

```bash
plutus login
```

You'll be prompted for your API key. Get it from [app.useplutus.ai/settings/api-keys](https://app.useplutus.ai/settings/api-keys).

Alternatively, set the environment variable:

```bash
export PLUTUS_API_KEY="your-api-key"
```

### 2. Chat

**Interactive mode** — a full REPL with history, streaming, and tool call visibility:

```bash
plutus chat
```

**One-shot mode** — send a single message and get a response:

```bash
plutus ask "What emails did I get today?"
plutus ask "Deploy my app to Vercel"
plutus ask "Summarize the latest news about AI"
```

### 3. Manage Everything

```bash
plutus email inbox          # Check your email
plutus email drafts         # View drafts
plutus connectors list      # See all connectors
plutus memory facts         # View stored facts
plutus workers list         # Check running workers
plutus schedule list        # View scheduled jobs
```

## Commands

### Chat

| Command | Description |
|---------|-------------|
| `plutus chat` | Interactive chat REPL |
| `plutus ask "message"` | One-shot message |

**REPL commands:** `/help`, `/new` (new conversation), `/verbose` (toggle tool output), `/history`, `/exit`

### Email

| Command | Description |
|---------|-------------|
| `plutus email inbox` | List inbox messages |
| `plutus email read <id>` | Read a specific email |
| `plutus email drafts` | List drafts |
| `plutus email send-draft <id>` | Send a draft |
| `plutus email delete-draft <id>` | Delete a draft |
| `plutus email threads` | List email threads |
| `plutus email reply <id> "text"` | Reply to an email |
| `plutus email inboxes` | List configured inboxes |
| `plutus email domains` | List email domains |

### Connectors

| Command | Description |
|---------|-------------|
| `plutus connectors list` | List all connectors |
| `plutus connectors info <name>` | Show connector details |
| `plutus connectors setup <name>` | Configure a connector (interactive) |
| `plutus connectors test <name>` | Test a connector |
| `plutus connectors disconnect <name>` | Disconnect a connector |

### Memory

| Command | Description |
|---------|-------------|
| `plutus memory stats` | Memory statistics |
| `plutus memory facts` | List stored facts |
| `plutus memory facts -c "category"` | Filter facts by category |
| `plutus memory delete-fact <id>` | Delete a fact |
| `plutus memory goals` | List active goals |
| `plutus memory improvements` | View self-improvement log |

### Skills

| Command | Description |
|---------|-------------|
| `plutus skills list` | List all skills |
| `plutus skills info <name>` | Show skill details |
| `plutus skills export <name>` | Export skill to JSON |
| `plutus skills import <file>` | Import skill from JSON |
| `plutus skills delete <name>` | Delete a skill |

### Custom Tools

| Command | Description |
|---------|-------------|
| `plutus tools list` | List custom tools |
| `plutus tools create <name> <file>` | Create tool from Python file |
| `plutus tools delete <name>` | Delete a custom tool |

### Workers

| Command | Description |
|---------|-------------|
| `plutus workers list` | List active workers |
| `plutus workers cancel <id>` | Cancel a worker |

### Scheduler

| Command | Description |
|---------|-------------|
| `plutus schedule list` | List scheduled jobs |
| `plutus schedule create -n "name" -s "0 9 * * *" -p "prompt"` | Create a job |
| `plutus schedule delete <id>` | Delete a job |
| `plutus schedule pause <id>` | Pause a job |
| `plutus schedule resume <id>` | Resume a job |
| `plutus schedule history` | View execution history |

### Contacts

| Command | Description |
|---------|-------------|
| `plutus contacts list` | List contacts |
| `plutus contacts list -q "search"` | Search contacts |
| `plutus contacts info <id>` | Show contact details |
| `plutus contacts delete <id>` | Delete a contact |

### Conversation History

| Command | Description |
|---------|-------------|
| `plutus history list` | List recent conversations |
| `plutus history show <id>` | Show conversation messages |
| `plutus history delete <id>` | Delete a conversation |
| `plutus history clear` | Delete all conversations |

### Workspace

| Command | Description |
|---------|-------------|
| `plutus workspace ls` | List workspace files |
| `plutus workspace download <path>` | Download a file |
| `plutus workspace delete <path>` | Delete a file |

### Configuration

| Command | Description |
|---------|-------------|
| `plutus config model` | View model routing |
| `plutus config model -p anthropic -m sonnet` | Set model |
| `plutus config keys` | View API key status |
| `plutus config set-key <provider> <key>` | Set an API key |
| `plutus config delete-key <provider>` | Delete an API key |
| `plutus config usage` | View token usage |
| `plutus config heartbeat` | View heartbeat status |

### Guardrails

| Command | Description |
|---------|-------------|
| `plutus guardrails show` | View guardrail config |
| `plutus guardrails set-tier <tier>` | Set tier (minimal/standard/strict) |
| `plutus guardrails approvals` | List pending approvals |
| `plutus guardrails approve <id>` | Approve a tool call |
| `plutus guardrails deny <id>` | Deny a tool call |

### Auth & Status

| Command | Description |
|---------|-------------|
| `plutus login` | Authenticate with API key |
| `plutus logout` | Remove stored credentials |
| `plutus status` | Check connection status |

## Configuration

Config is stored at `~/.plutus/config.toml`:

```toml
api_key = "your-api-key"
api_url = "https://api.useplutus.ai"   # optional, for custom deployments
```

You can also use environment variables:

```bash
export PLUTUS_API_KEY="your-api-key"
export PLUTUS_API_URL="https://api.useplutus.ai"
```

## Requirements

- Python 3.10+
- A Plutus Cloud account with an API key

## License

MIT
