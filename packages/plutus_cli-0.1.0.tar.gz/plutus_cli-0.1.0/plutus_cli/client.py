"""HTTP + WebSocket client for the Plutus Cloud API."""

from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator

import httpx
import websockets

from plutus_cli.config import get_api_base, get_api_key, get_ws_base

# ---------------------------------------------------------------------------
# REST client
# ---------------------------------------------------------------------------


class PlutusClient:
    """Thin wrapper around httpx for authenticated Plutus API calls."""

    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        self.api_key = api_key or get_api_key()
        self.base_url = (base_url or get_api_base()).rstrip("/")
        if not self.api_key:
            raise RuntimeError(
                "No API key configured. Run `plutus login` first or set PLUTUS_API_KEY."
            )
        self._client: httpx.AsyncClient | None = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                timeout=60.0,
            )
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    # -- Generic helpers -----------------------------------------------------

    async def get(self, path: str, params: dict | None = None) -> Any:
        resp = await self.client.get(path, params=params)
        resp.raise_for_status()
        return resp.json()

    async def post(self, path: str, body: dict | None = None) -> Any:
        resp = await self.client.post(path, json=body or {})
        resp.raise_for_status()
        return resp.json()

    async def put(self, path: str, body: dict | None = None) -> Any:
        resp = await self.client.put(path, json=body or {})
        resp.raise_for_status()
        return resp.json()

    async def patch(self, path: str, body: dict | None = None) -> Any:
        resp = await self.client.patch(path, json=body or {})
        resp.raise_for_status()
        return resp.json()

    async def delete(self, path: str) -> Any:
        resp = await self.client.delete(path)
        resp.raise_for_status()
        if resp.headers.get("content-type", "").startswith("application/json"):
            return resp.json()
        return {"ok": True}

    async def download(self, path: str, dest: str) -> str:
        """Download a file to a local path."""
        async with self.client.stream("GET", path) as resp:
            resp.raise_for_status()
            with open(dest, "wb") as f:
                async for chunk in resp.aiter_bytes(8192):
                    f.write(chunk)
        return dest

    # -- Chat (REST) ---------------------------------------------------------

    async def chat(self, message: str, conversation_id: str | None = None) -> dict:
        """Send a message via the REST chat endpoint (non-streaming)."""
        body: dict[str, Any] = {"message": message}
        if conversation_id:
            body["conversation_id"] = conversation_id
        return await self.post("/chat", body)

    # -- Conversations -------------------------------------------------------

    async def get_conversations(self, limit: int = 50) -> list[dict]:
        return await self.get("/chat/history", params={"limit": limit})

    async def get_messages(self, conv_id: str) -> list[dict]:
        return await self.get(f"/chat/messages/{conv_id}")

    async def delete_conversation(self, conv_id: str) -> dict:
        return await self.delete(f"/chat/conversations/{conv_id}")

    async def rename_conversation(self, conv_id: str, title: str) -> dict:
        return await self.patch(f"/chat/conversations/{conv_id}", {"title": title})

    # -- Connectors ----------------------------------------------------------

    async def get_connectors(self) -> list[dict]:
        return await self.get("/connectors")

    async def get_connector(self, name: str) -> dict:
        return await self.get(f"/connectors/{name}")

    async def update_connector_config(self, name: str, config: dict) -> dict:
        return await self.put(f"/connectors/{name}/config", config)

    async def test_connector(self, name: str) -> dict:
        return await self.post(f"/connectors/{name}/test")

    async def disconnect_connector(self, name: str) -> dict:
        return await self.post(f"/connectors/{name}/disconnect")

    # -- Email (AgentMail) ---------------------------------------------------

    async def email_inbox_info(self) -> dict:
        return await self.get("/connectors/agentmail/inbox")

    async def email_list_messages(self, limit: int = 20) -> dict:
        return await self.get("/connectors/agentmail/messages", params={"limit": limit})

    async def email_get_message(self, msg_id: str) -> dict:
        return await self.get(f"/connectors/agentmail/message/{msg_id}")

    async def email_list_drafts(self, limit: int = 20) -> dict:
        return await self.get("/connectors/agentmail/drafts", params={"limit": limit})

    async def email_get_draft(self, draft_id: str) -> dict:
        return await self.get(f"/connectors/agentmail/draft/{draft_id}")

    async def email_send_draft(self, draft_id: str) -> dict:
        return await self.post(f"/connectors/agentmail/drafts/send/{draft_id}")

    async def email_delete_draft(self, draft_id: str) -> dict:
        return await self.delete(f"/connectors/agentmail/draft/{draft_id}")

    async def email_reply(self, msg_id: str, text: str) -> dict:
        return await self.post(f"/connectors/agentmail/reply/{msg_id}", {"text": text})

    async def email_list_threads(self, limit: int = 20) -> dict:
        return await self.get("/connectors/agentmail/threads", params={"limit": limit})

    async def email_get_thread(self, thread_id: str) -> dict:
        return await self.get(f"/connectors/agentmail/thread/{thread_id}")

    async def email_list_inboxes(self) -> dict:
        return await self.get("/connectors/agentmail/inboxes")

    async def email_list_domains(self) -> dict:
        return await self.get("/connectors/agentmail/domains")

    # -- Guardrails ----------------------------------------------------------

    async def get_guardrails(self) -> dict:
        return await self.get("/guardrails")

    async def set_guardrail_tier(self, tier: str) -> dict:
        return await self.put("/guardrails/tier", {"tier": tier})

    async def get_approvals(self) -> list[dict]:
        return await self.get("/approvals")

    async def resolve_approval(self, approval_id: str, approved: bool) -> dict:
        return await self.post(
            "/approvals/resolve",
            {"approval_id": approval_id, "approved": approved},
        )

    # -- Memory --------------------------------------------------------------

    async def get_memory_stats(self) -> dict:
        return await self.get("/agents/memory")

    async def get_facts(self, category: str | None = None, limit: int = 50) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if category:
            params["category"] = category
        return await self.get("/agents/memory/facts", params=params)

    async def delete_fact(self, fact_id: int) -> dict:
        return await self.delete(f"/agents/memory/facts/{fact_id}")

    async def get_goals(self, limit: int = 50) -> list[dict]:
        return await self.get("/agents/goals", params={"limit": limit})

    async def get_improvement_log(self, limit: int = 50) -> list[dict]:
        return await self.get("/agents/memory/improvement", params={"limit": limit})

    # -- Skills --------------------------------------------------------------

    async def get_skills(self, category: str | None = None) -> dict:
        params = {"category": category} if category else None
        return await self.get("/agents/skills", params=params)

    async def get_skill_detail(self, name: str) -> dict:
        return await self.get(f"/agents/skills/{name}")

    async def export_skill(self, name: str) -> dict:
        return await self.get(f"/agents/skills/{name}/export")

    async def import_skill(self, data: dict) -> dict:
        return await self.post("/agents/skills/import", data)

    async def delete_skill(self, name: str) -> dict:
        return await self.delete(f"/agents/skills/{name}")

    # -- Custom Tools --------------------------------------------------------

    async def get_custom_tools(self) -> dict:
        return await self.get("/custom-tools")

    async def create_custom_tool(self, name: str, description: str, code: str) -> dict:
        return await self.post(
            "/custom-tools",
            {"tool_name": name, "description": description, "code": code, "register": True},
        )

    async def delete_custom_tool(self, name: str) -> dict:
        return await self.delete(f"/custom-tools/{name}")

    # -- Workers -------------------------------------------------------------

    async def get_workers(self) -> dict:
        return await self.get("/workers")

    async def cancel_worker(self, task_id: str) -> dict:
        return await self.post(f"/workers/{task_id}/cancel")

    async def update_worker_config(self, patch: dict) -> dict:
        return await self.patch("/workers/config", patch)

    # -- Scheduler -----------------------------------------------------------

    async def get_scheduled_jobs(self) -> dict:
        return await self.get("/scheduler/jobs")

    async def create_job(self, name: str, schedule: str, prompt: str) -> dict:
        return await self.post(
            "/scheduler/jobs",
            {"name": name, "schedule": schedule, "prompt": prompt},
        )

    async def delete_job(self, job_id: str) -> dict:
        return await self.delete(f"/scheduler/jobs/{job_id}")

    async def pause_job(self, job_id: str) -> dict:
        return await self.post(f"/scheduler/jobs/{job_id}/pause")

    async def resume_job(self, job_id: str) -> dict:
        return await self.post(f"/scheduler/jobs/{job_id}/resume")

    async def get_scheduler_history(self, limit: int = 50) -> dict:
        return await self.get("/scheduler/history", params={"limit": limit})

    # -- Settings / Models ---------------------------------------------------

    async def get_model_routing(self) -> dict:
        return await self.get("/models")

    async def update_model_routing(self, patch: dict) -> dict:
        return await self.patch("/models", patch)

    async def get_key_status(self) -> dict:
        return await self.get("/keys/status")

    async def set_key(self, provider: str, key: str) -> dict:
        return await self.post("/keys", {"provider": provider, "key": key})

    async def delete_key(self, provider: str) -> dict:
        return await self.delete(f"/keys/{provider}")

    # -- Contacts ------------------------------------------------------------

    async def list_contacts(self, q: str | None = None, limit: int = 50) -> dict:
        params: dict[str, Any] = {"limit": limit}
        if q:
            params["q"] = q
        return await self.get("/contacts", params=params)

    async def get_contact(self, contact_id: int) -> dict:
        return await self.get(f"/contacts/{contact_id}")

    async def create_contact(self, data: dict) -> dict:
        return await self.post("/contacts", data)

    async def delete_contact(self, contact_id: int) -> dict:
        return await self.delete(f"/contacts/{contact_id}")

    # -- Billing / Usage -----------------------------------------------------

    async def get_usage(self, month: str | None = None) -> dict:
        params = {"month": month} if month else None
        return await self.get("/billing/usage", params=params)

    # -- Heartbeat -----------------------------------------------------------

    async def get_heartbeat(self) -> dict:
        return await self.get("/heartbeat")

    async def start_heartbeat(self) -> dict:
        return await self.post("/heartbeat/start")

    async def stop_heartbeat(self) -> dict:
        return await self.post("/heartbeat/stop")

    # -- Plans ---------------------------------------------------------------

    async def get_plans(self, limit: int = 20) -> dict:
        return await self.get("/agents/plans", params={"limit": limit})

    async def get_active_plan(self) -> dict:
        return await self.get("/agents/plans/active")

    # -- Workspace -----------------------------------------------------------

    async def get_workspace_files(self) -> dict:
        return await self.get("/workspace/files")

    async def delete_workspace_file(self, path: str) -> dict:
        encoded = "/".join(part for part in path.split("/") if part)
        return await self.delete(f"/workspace/files/{encoded}")

    # -- Status --------------------------------------------------------------

    async def get_status(self) -> dict:
        return await self.get("/health/status")


# ---------------------------------------------------------------------------
# WebSocket streaming client
# ---------------------------------------------------------------------------


async def stream_chat(
    message: str,
    session_id: str | None = None,
    api_key: str | None = None,
) -> AsyncIterator[dict]:
    """Connect to the Plutus WebSocket and stream a chat response.

    Yields dicts with keys like:
      {"type": "text", "content": "...", "role": "assistant"}
      {"type": "thinking", ...}
      {"type": "tool_call", "name": "...", "result": "..."}
      {"type": "done"}
    """
    key = api_key or get_api_key()
    if not key:
        raise RuntimeError("No API key configured. Run `plutus login` first.")

    ws_base = get_ws_base()
    uri = f"{ws_base}?token={key}"

    async with websockets.connect(uri, max_size=10 * 1024 * 1024) as ws:
        # Wait for the 'connected' message
        raw = await asyncio.wait_for(ws.recv(), timeout=15)
        msg = json.loads(raw)
        if msg.get("type") != "connected":
            raise RuntimeError(f"Unexpected initial message: {msg}")

        # If no session_id, create a new session
        if not session_id:
            await ws.send(json.dumps({"type": "new_session"}))
            raw = await asyncio.wait_for(ws.recv(), timeout=15)
            msg = json.loads(raw)
            if msg.get("type") == "session_created":
                session_id = msg["session"]["id"]
            else:
                raise RuntimeError(f"Failed to create session: {msg}")

        # Send the chat message
        await ws.send(json.dumps({"type": "chat", "session_id": session_id, "content": message}))

        # Stream responses until 'done'
        while True:
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=300)
            except asyncio.TimeoutError:
                yield {"type": "error", "message": "Response timed out (5 min)"}
                break

            msg = json.loads(raw)
            msg_type = msg.get("type", "")

            if msg_type == "pong":
                continue

            yield msg

            if msg_type in ("done", "error"):
                break
