"""Rich-based display helpers for terminal output."""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.theme import Theme

theme = Theme(
    {
        "info": "cyan",
        "success": "green",
        "warning": "yellow",
        "error": "red bold",
        "muted": "dim",
        "accent": "magenta",
        "tool": "blue",
    }
)

console = Console(theme=theme)


def success(msg: str) -> None:
    console.print(f"[success]✓[/success] {msg}")


def error(msg: str) -> None:
    console.print(f"[error]✗[/error] {msg}")


def warning(msg: str) -> None:
    console.print(f"[warning]![/warning] {msg}")


def info(msg: str) -> None:
    console.print(f"[info]ℹ[/info] {msg}")


def muted(msg: str) -> None:
    console.print(f"[muted]{msg}[/muted]")


def print_markdown(text: str) -> None:
    """Render Markdown in the terminal."""
    console.print(Markdown(text))


def print_panel(content: str, title: str = "", border_style: str = "cyan") -> None:
    console.print(Panel(content, title=title, border_style=border_style))


def print_json_compact(data: Any) -> None:
    """Print JSON data in a compact, readable way."""
    console.print_json(data=data)


def print_table(
    rows: list[dict],
    columns: list[tuple[str, str]],
    title: str = "",
) -> None:
    """Print a list of dicts as a Rich table.

    columns: list of (key, header_label) tuples.
    """
    table = Table(title=title, show_lines=False, pad_edge=False)
    for _, header in columns:
        table.add_column(header, overflow="fold")
    for row in rows:
        table.add_row(*[str(row.get(k, "")) for k, _ in columns])
    console.print(table)


def print_kv(pairs: list[tuple[str, str]], title: str = "") -> None:
    """Print key-value pairs in a clean format."""
    if title:
        console.print(f"\n[bold]{title}[/bold]")
    max_key = max((len(k) for k, _ in pairs), default=0)
    for key, val in pairs:
        console.print(f"  [accent]{key:<{max_key}}[/accent]  {val}")
    console.print()


def stream_token(text: str) -> None:
    """Print a streaming token without a newline."""
    console.print(text, end="", highlight=False)


def stream_newline() -> None:
    console.print()


def tool_call_start(name: str) -> None:
    console.print(f"  [tool]⚙ Using tool:[/tool] [bold]{name}[/bold]")


def tool_call_result(result: str, verbose: bool = False) -> None:
    if verbose:
        console.print(f"    [muted]{result[:500]}[/muted]")
    else:
        preview = result[:80].replace("\n", " ")
        if len(result) > 80:
            preview += "…"
        console.print(f"    [muted]→ {preview}[/muted]")


def thinking_indicator() -> None:
    console.print("  [muted]💭 Thinking…[/muted]")


def approval_prompt(tool_name: str, details: str = "") -> bool:
    """Show an interactive approval prompt. Returns True if approved."""
    console.print(f"\n[warning]⚠ Plutus wants to use:[/warning] [bold]{tool_name}[/bold]")
    if details:
        console.print(f"  [muted]{details}[/muted]")
    try:
        response = console.input("[warning]Allow? (y/n): [/warning]").strip().lower()
        return response in ("y", "yes")
    except (EOFError, KeyboardInterrupt):
        return False
