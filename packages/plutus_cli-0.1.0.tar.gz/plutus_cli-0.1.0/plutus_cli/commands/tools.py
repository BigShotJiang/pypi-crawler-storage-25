"""Custom tools management commands."""

from __future__ import annotations

import asyncio
from pathlib import Path

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("tools")
def tools_cmd() -> None:
    """Manage custom tools."""


@tools_cmd.command("list")
def list_tools() -> None:
    """List all custom tools."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_custom_tools()
            tools = data if isinstance(data, list) else data.get("tools", [])
            if not tools:
                display.muted("No custom tools.")
                return
            rows = []
            for t in tools:
                rows.append(
                    {
                        "name": t.get("name", t.get("tool_name", "")),
                        "description": (t.get("description", "") or "")[:50],
                    }
                )
            display.print_table(
                rows,
                [("name", "Name"), ("description", "Description")],
                title="Custom Tools",
            )
        finally:
            await client.close()

    _run(_run_it())


@tools_cmd.command("create")
@click.argument("name")
@click.argument("code_file", type=click.Path(exists=True))
@click.option("--description", "-d", default="", help="Tool description")
def create_tool(name: str, code_file: str, description: str) -> None:
    """Create a custom tool from a Python file."""

    async def _run_it():
        client = PlutusClient()
        try:
            code = Path(code_file).read_text(encoding="utf-8")
            await client.create_custom_tool(name, description, code)
            display.success(f"Tool '{name}' created and registered.")
        finally:
            await client.close()

    _run(_run_it())


@tools_cmd.command("delete")
@click.argument("name")
@click.confirmation_option(prompt="Delete this tool?")
def delete_tool(name: str) -> None:
    """Delete a custom tool."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.delete_custom_tool(name)
            display.success(f"Tool '{name}' deleted.")
        finally:
            await client.close()

    _run(_run_it())
