"""Conversation history commands."""

from __future__ import annotations

import asyncio

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("history")
def history_cmd() -> None:
    """View and manage conversation history."""


@history_cmd.command("list")
@click.option("--limit", "-n", default=20, help="Number of conversations to show")
def list_conversations(limit: int) -> None:
    """List recent conversations."""

    async def _run_it():
        client = PlutusClient()
        try:
            convs = await client.get_conversations(limit=limit)
            items = convs if isinstance(convs, list) else convs.get("conversations", [])
            if not items:
                display.muted("No conversations yet.")
                return
            rows = []
            for c in items:
                rows.append(
                    {
                        "id": str(c.get("id", ""))[:16],
                        "title": (c.get("title") or "Untitled")[:50],
                        "updated": str(c.get("updated_at", ""))[:16],
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("title", "Title"), ("updated", "Updated")],
                title="Conversations",
            )
        finally:
            await client.close()

    _run(_run_it())


@history_cmd.command("show")
@click.argument("conversation_id")
def show_conversation(conversation_id: str) -> None:
    """Show messages in a conversation."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_conversation(conversation_id)
            messages = data.get("messages", [])
            if not messages:
                display.muted("Empty conversation.")
                return
            for m in messages:
                role = m.get("role", "unknown")
                content = m.get("content", "")
                if role == "user":
                    display.console.print(f"\n[bold cyan]You:[/bold cyan] {content}")
                elif role == "assistant":
                    display.console.print("\n[bold magenta]Plutus:[/bold magenta]")
                    display.print_markdown(content)
                elif role == "tool":
                    name = m.get("name", "tool")
                    display.tool_call_start(name)
        finally:
            await client.close()

    _run(_run_it())


@history_cmd.command("delete")
@click.argument("conversation_id")
@click.confirmation_option(prompt="Delete this conversation?")
def delete_conversation(conversation_id: str) -> None:
    """Delete a conversation."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.delete_conversation(conversation_id)
            display.success("Conversation deleted.")
        finally:
            await client.close()

    _run(_run_it())


@history_cmd.command("clear")
@click.confirmation_option(prompt="Delete ALL conversations?")
def clear_all() -> None:
    """Delete all conversations."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.clear_conversations()
            display.success("All conversations cleared.")
        finally:
            await client.close()

    _run(_run_it())
