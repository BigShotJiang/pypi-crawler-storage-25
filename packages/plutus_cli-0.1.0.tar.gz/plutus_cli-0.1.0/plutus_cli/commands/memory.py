"""Memory management commands — facts, goals, improvement log."""

from __future__ import annotations

import asyncio

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("memory")
def memory_cmd() -> None:
    """View and manage Plutus memory (facts, goals, improvements)."""


@memory_cmd.command("stats")
def stats() -> None:
    """Show memory statistics."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_memory_stats()
            display.print_kv(
                [
                    ("Total facts", str(data.get("total_facts", 0))),
                ],
                title="Memory Stats",
            )
        finally:
            await client.close()

    _run(_run_it())


@memory_cmd.command("facts")
@click.option("--category", "-c", default=None, help="Filter by category")
@click.option("--limit", "-n", default=50, help="Number of facts to show")
def facts(category: str | None, limit: int) -> None:
    """List stored facts."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_facts(category=category, limit=limit)
            facts_list = data if isinstance(data, list) else data.get("facts", [])
            if not facts_list:
                display.muted("No facts stored.")
                return
            rows = []
            for f in facts_list:
                rows.append(
                    {
                        "id": str(f.get("id", "")),
                        "category": f.get("category", ""),
                        "content": (f.get("content", "") or "")[:60],
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("category", "Category"), ("content", "Content")],
                title="Facts",
            )
        finally:
            await client.close()

    _run(_run_it())


@memory_cmd.command("delete-fact")
@click.argument("fact_id", type=int)
@click.confirmation_option(prompt="Delete this fact?")
def delete_fact(fact_id: int) -> None:
    """Delete a stored fact."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.delete_fact(fact_id)
            display.success(f"Fact {fact_id} deleted.")
        finally:
            await client.close()

    _run(_run_it())


@memory_cmd.command("goals")
@click.option("--limit", "-n", default=50, help="Number of goals to show")
def goals(limit: int) -> None:
    """List active goals."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_goals(limit=limit)
            goals_list = data if isinstance(data, list) else data.get("goals", [])
            if not goals_list:
                display.muted("No goals set.")
                return
            rows = []
            for g in goals_list:
                rows.append(
                    {
                        "id": str(g.get("id", "")),
                        "description": (g.get("description", "") or "")[:60],
                        "status": g.get("status", ""),
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("description", "Description"), ("status", "Status")],
                title="Goals",
            )
        finally:
            await client.close()

    _run(_run_it())


@memory_cmd.command("improvements")
@click.option("--limit", "-n", default=50, help="Number of entries to show")
def improvements(limit: int) -> None:
    """Show the self-improvement log."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.get_improvement_log(limit=limit)
            entries = data if isinstance(data, list) else data.get("entries", [])
            if not entries:
                display.muted("No improvement entries.")
                return
            rows = []
            for e in entries:
                rows.append(
                    {
                        "date": str(e.get("created_at", ""))[:16],
                        "type": e.get("type", ""),
                        "description": (e.get("description", "") or "")[:60],
                    }
                )
            display.print_table(
                rows,
                [("date", "Date"), ("type", "Type"), ("description", "Description")],
                title="Improvement Log",
            )
        finally:
            await client.close()

    _run(_run_it())
