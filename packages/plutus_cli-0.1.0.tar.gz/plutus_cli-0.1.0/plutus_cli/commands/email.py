"""Email (AgentMail) management commands."""

from __future__ import annotations

import asyncio

import click

from plutus_cli import display
from plutus_cli.client import PlutusClient


def _run(coro):
    try:
        return asyncio.get_event_loop().run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


@click.group("email")
def email_cmd() -> None:
    """Manage your Plutus email inbox, drafts, and threads."""


@email_cmd.command("inbox")
@click.option("--limit", "-n", default=20, help="Number of messages to show")
def inbox(limit: int) -> None:
    """Show recent inbox messages."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.email_list_messages(limit=limit)
            messages = data if isinstance(data, list) else data.get("messages", [])
            if not messages:
                display.muted("Inbox is empty.")
                return
            rows = []
            for m in messages:
                sender = ""
                from_list = m.get("from_", m.get("from", []))
                if isinstance(from_list, list) and from_list:
                    sender = from_list[0].get("email", str(from_list[0]))
                elif isinstance(from_list, str):
                    sender = from_list
                rows.append(
                    {
                        "id": m.get("id", "")[:12],
                        "from": sender[:30],
                        "subject": (m.get("subject") or "(no subject)")[:50],
                        "date": str(m.get("created_at", ""))[:16],
                        "read": "Yes" if m.get("is_read") else "",
                    }
                )
            display.print_table(
                rows,
                [
                    ("id", "ID"),
                    ("from", "From"),
                    ("subject", "Subject"),
                    ("date", "Date"),
                    ("read", "Read"),
                ],
                title="Inbox",
            )
        finally:
            await client.close()

    _run(_run_it())


@email_cmd.command("read")
@click.argument("message_id")
def read_message(message_id: str) -> None:
    """Read a specific email message."""

    async def _run_it():
        client = PlutusClient()
        try:
            m = await client.email_get_message(message_id)
            sender = ""
            from_list = m.get("from_", m.get("from", []))
            if isinstance(from_list, list) and from_list:
                sender = from_list[0].get("email", str(from_list[0]))
            elif isinstance(from_list, str):
                sender = from_list

            to_list = m.get("to", [])
            to_str = ""
            if isinstance(to_list, list):
                to_str = ", ".join(
                    t.get("email", str(t)) if isinstance(t, dict) else str(t) for t in to_list
                )

            display.print_kv(
                [
                    ("From", sender),
                    ("To", to_str),
                    ("Subject", m.get("subject", "(no subject)")),
                    ("Date", str(m.get("created_at", ""))),
                    ("ID", m.get("id", "")),
                ],
                title="Email",
            )

            body = m.get("text") or m.get("body") or m.get("html") or "(empty body)"
            display.console.print()
            display.print_markdown(body)
        finally:
            await client.close()

    _run(_run_it())


@email_cmd.command("drafts")
@click.option("--limit", "-n", default=20, help="Number of drafts to show")
def list_drafts(limit: int) -> None:
    """List email drafts."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.email_list_drafts(limit=limit)
            drafts = data if isinstance(data, list) else data.get("drafts", [])
            if not drafts:
                display.muted("No drafts.")
                return
            rows = []
            for d in drafts:
                to_list = d.get("to", [])
                to_str = ""
                if isinstance(to_list, list) and to_list:
                    first = to_list[0]
                    to_str = (
                        first.get("email", str(first)) if isinstance(first, dict) else str(first)
                    )
                rows.append(
                    {
                        "id": d.get("id", "")[:12],
                        "to": to_str[:30],
                        "subject": (d.get("subject") or "(no subject)")[:50],
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("to", "To"), ("subject", "Subject")],
                title="Drafts",
            )
        finally:
            await client.close()

    _run(_run_it())


@email_cmd.command("send-draft")
@click.argument("draft_id")
@click.confirmation_option(prompt="Send this draft?")
def send_draft(draft_id: str) -> None:
    """Send an email draft."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.email_send_draft(draft_id)
            display.success(f"Draft {draft_id[:12]} sent.")
        finally:
            await client.close()

    _run(_run_it())


@email_cmd.command("delete-draft")
@click.argument("draft_id")
@click.confirmation_option(prompt="Delete this draft?")
def delete_draft(draft_id: str) -> None:
    """Delete an email draft."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.email_delete_draft(draft_id)
            display.success(f"Draft {draft_id[:12]} deleted.")
        finally:
            await client.close()

    _run(_run_it())


@email_cmd.command("threads")
@click.option("--limit", "-n", default=20, help="Number of threads to show")
def list_threads(limit: int) -> None:
    """List email threads."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.email_list_threads(limit=limit)
            threads = data if isinstance(data, list) else data.get("threads", [])
            if not threads:
                display.muted("No threads.")
                return
            rows = []
            for t in threads:
                rows.append(
                    {
                        "id": t.get("id", "")[:12],
                        "subject": (t.get("subject") or "(no subject)")[:50],
                        "count": str(t.get("message_count", t.get("messages", 0))),
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("subject", "Subject"), ("count", "Messages")],
                title="Threads",
            )
        finally:
            await client.close()

    _run(_run_it())


@email_cmd.command("reply")
@click.argument("message_id")
@click.argument("text")
def reply(message_id: str, text: str) -> None:
    """Reply to an email message."""

    async def _run_it():
        client = PlutusClient()
        try:
            await client.email_reply(message_id, text)
            display.success("Reply sent.")
        finally:
            await client.close()

    _run(_run_it())


@email_cmd.command("inboxes")
def list_inboxes() -> None:
    """List configured email inboxes."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.email_list_inboxes()
            inboxes = data if isinstance(data, list) else data.get("inboxes", [])
            if not inboxes:
                display.muted("No inboxes configured.")
                return
            rows = []
            for i in inboxes:
                rows.append(
                    {
                        "id": i.get("inbox_id", i.get("id", ""))[:16],
                        "email": i.get("email", ""),
                        "name": i.get("display_name", ""),
                        "draft": "Yes" if i.get("draft_only") else "No",
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("email", "Email"), ("name", "Name"), ("draft", "Draft Only")],
                title="Inboxes",
            )
        finally:
            await client.close()

    _run(_run_it())


@email_cmd.command("domains")
def list_domains() -> None:
    """List email domains."""

    async def _run_it():
        client = PlutusClient()
        try:
            data = await client.email_list_domains()
            domains = data if isinstance(data, list) else data.get("domains", [])
            if not domains:
                display.muted("No domains configured.")
                return
            rows = []
            for d in domains:
                rows.append(
                    {
                        "id": d.get("id", "")[:12],
                        "domain": d.get("domain", ""),
                        "verified": "Yes" if d.get("verified") else "No",
                    }
                )
            display.print_table(
                rows,
                [("id", "ID"), ("domain", "Domain"), ("verified", "Verified")],
                title="Domains",
            )
        finally:
            await client.close()

    _run(_run_it())
