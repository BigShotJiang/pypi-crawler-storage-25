"""Production test app for switchly.

Boots with Redis backend when REDIS_URL is set, otherwise falls back to
MemoryBackend so the app still starts without Redis during local dev.

Run locally (no Redis):
    cd production_test && uvicorn main:app --reload --port 8000

Run locally with Redis (via docker-compose):
    cd production_test && docker compose up --build

Admin dashboard:  http://localhost:8000/switchly  (admin / changeme)
API docs:         http://localhost:8000/docs
"""

import logging

from config import ADMIN_PASS, ADMIN_USER, REDIS_URL, SECRET_KEY, SWITCHLY_ENV
from fastapi import FastAPI
from fastapi.responses import JSONResponse

from switchly import MemoryBackend, SwitchlyEngine
from switchly.fastapi import (
    SwitchlyAdmin,
    SwitchlyMiddleware,
    SwitchlyRouter,
    apply_switchly_to_openapi,
    deprecated,
    disabled,
    env_only,
    force_active,
    maintenance,
    rate_limit,
    setup_switchly_docs,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Backend — Redis in production, Memory for local dev without Redis
# ---------------------------------------------------------------------------


def _build_backend():
    if REDIS_URL:
        try:
            from switchly.core.backends.redis import RedisBackend

            logger.info("Using RedisBackend: %s", REDIS_URL.split("@")[-1])
            return RedisBackend(url=REDIS_URL)
        except Exception as exc:
            logger.warning("RedisBackend init failed (%s) — falling back to MemoryBackend", exc)
    else:
        logger.warning(
            "REDIS_URL not set — using MemoryBackend. Route state will be lost on restart."
        )
    return MemoryBackend()


backend = _build_backend()

# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

engine = SwitchlyEngine(backend=backend, current_env=SWITCHLY_ENV)

# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = SwitchlyRouter(engine=engine, prefix="/api")

# ---------------------------------------------------------------------------
# Routes with various switchly states
# ---------------------------------------------------------------------------


@router.get("/payments", tags=["billing"])
@maintenance(reason="Scheduled database migration — back in 30 minutes")
async def get_payments():
    """Fetch pending payments. Currently in maintenance."""
    return {"payments": []}


@router.get("/payments/history", tags=["billing"])
async def get_payment_history():
    """Payment history — always live."""
    return {"history": [{"id": "pay_001", "amount": 99.00, "status": "settled"}]}


@router.get("/orders", tags=["orders"])
@rate_limit("10/minute")
async def get_orders():
    """Fetch orders — rate limited to 10 req/min per IP."""
    return {"orders": [{"id": "ord_001", "status": "shipped"}]}


@router.post("/orders", tags=["orders"])
@rate_limit("5/minute")
async def create_order():
    """Create an order — stricter rate limit."""
    return {"id": "ord_new", "status": "pending"}


@router.get("/debug", tags=["internal"])
@env_only("dev", "staging")
async def debug_info():
    """Internal debug endpoint — only accessible in dev / staging."""
    return {"env": SWITCHLY_ENV, "debug": True}


@router.get("/legacy/export", tags=["legacy"])
@disabled(reason="Use /api/v2/export instead. This endpoint will be removed.")
async def legacy_export():
    """Old export endpoint — permanently disabled."""
    return {"data": []}


@router.get("/v1/users", tags=["users"])
@deprecated(
    sunset="Sat, 01 Jan 2027 00:00:00 GMT",
    use_instead="/api/v2/users",
)
async def v1_users():
    """List users — deprecated, use /api/v2/users."""
    return {"users": [{"id": 1, "name": "Alice"}]}


@router.get("/v2/users", tags=["users"])
async def v2_users():
    """List users — current version."""
    return {"users": [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]}


@router.get("/analytics", tags=["analytics"])
@rate_limit("60/minute")
async def analytics():
    """Analytics — rate limited to 60 req/min per IP."""
    return {"page_views": 12_340, "unique_users": 3_210}


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------


def create_app() -> FastAPI:
    _app = FastAPI(
        title="APISwitchly Production Test",
        description=(
            "Demonstrates switchly route lifecycle management.\n\n"
            "**Admin dashboard**: [/switchly](/switchly)\n\n"
            f"**Current environment**: `{SWITCHLY_ENV}`  |  "
            f"**Backend**: `{'Redis' if REDIS_URL else 'Memory'}`"
        ),
        version="1.0.0",
    )

    _app.add_middleware(SwitchlyMiddleware, engine=engine)
    _app.include_router(router)

    admin = SwitchlyAdmin(engine=engine, auth=(ADMIN_USER, ADMIN_PASS), secret_key=SECRET_KEY)
    _app.mount("/switchly", admin)

    apply_switchly_to_openapi(_app, engine)
    setup_switchly_docs(_app, engine)

    @_app.get("/", include_in_schema=False)
    async def root():
        return {
            "app": "APISwitchly Production Test",
            "env": SWITCHLY_ENV,
            "backend": "redis" if REDIS_URL else "memory",
            "docs": "/docs",
            "admin": "/switchly",
            "routes": {
                "GET /api/payments": "maintenance",
                "GET /api/payments/history": "active",
                "GET /api/orders": "active + rate_limit(10/min)",
                "POST /api/orders": "active + rate_limit(5/min)",
                "GET /api/debug": "env_gated (dev/staging only)",
                "GET /api/legacy/export": "disabled",
                "GET /api/v1/users": "deprecated → /api/v2/users",
                "GET /api/v2/users": "active",
                "GET /api/analytics": "active + rate_limit(60/min)",
                "GET /health": "force_active (always 200)",
            },
        }

    @_app.get("/health", tags=["ops"])
    @force_active
    async def health():
        """Health check — bypasses all switchly checks, always 200."""
        return {
            "status": "ok",
            "env": SWITCHLY_ENV,
            "backend": "redis" if REDIS_URL else "memory",
        }

    @_app.exception_handler(404)
    async def not_found(request, exc):
        return JSONResponse(
            status_code=404,
            content={"error": {"code": "NOT_FOUND", "path": str(request.url.path)}},
        )

    return _app


app = create_app()
