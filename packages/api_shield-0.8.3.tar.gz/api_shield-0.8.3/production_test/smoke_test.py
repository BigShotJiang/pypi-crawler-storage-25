"""Smoke test — runs against the live server on localhost:8000.

Usage:
    # Start the server first:
    uvicorn production_test.main:app --port 8000

    # Then in another terminal:
    python production_test/smoke_test.py
"""

import httpx

BASE = "http://localhost:8000"
SEP = "-" * 60


def check(label: str, method: str, path: str, **kwargs) -> None:
    url = f"{BASE}{path}"
    r = getattr(httpx, method.lower())(url, **kwargs)
    status_icon = "✓" if r.status_code < 400 else ("!" if r.status_code == 404 else "✗")
    print(f"\n{status_icon} [{r.status_code}]  {method.upper()} {path}")
    # Show notable headers
    for h in ("Retry-After", "Deprecation", "Sunset", "Link", "X-RateLimit-Limit"):
        if h.lower() in {k.lower() for k in r.headers}:
            val = r.headers.get(h) or r.headers.get(h.lower())
            print(f"     {h}: {val}")
    if r.status_code != 200 or len(r.content) < 300:
        try:
            print(f"     body: {r.json()}")
        except Exception:
            pass


print(SEP)
print("switchly production smoke test")
print(SEP)

# Always-on
check("Health check (force_active)", "GET", "/health")
check("Root index", "GET", "/")

# Maintenance
print(f"\n{SEP}")
print("Lifecycle states")
print(SEP)
check("Payments (maintenance)", "GET", "/api/payments")
check("Payment history (active)", "GET", "/api/payments/history")
check("Legacy export (disabled)", "GET", "/api/legacy/export")
check("v1 users (deprecated)", "GET", "/api/v1/users")
check("v2 users (active)", "GET", "/api/v2/users")

# Env-gated (should 404 in production)
print(f"\n{SEP}")
print("Environment gating  (running in production → /api/debug should 404)")
print(SEP)
check("Debug endpoint (env_gated)", "GET", "/api/debug")

# Rate limiting — burst 12 requests, 10/min limit
print(f"\n{SEP}")
print("Rate limiting  (GET /api/orders — limit 10/min, sending 12 requests)")
print(SEP)
for i in range(12):
    r = httpx.get(f"{BASE}/api/orders")
    icon = "✓" if r.status_code == 200 else "✗"
    remaining = r.headers.get("x-ratelimit-remaining", "?")
    print(f"  req {i + 1:02d}  {icon} [{r.status_code}]  remaining={remaining}")

# OpenAPI schema filtering
print(f"\n{SEP}")
print("OpenAPI schema — disabled + env-gated routes should be hidden")
print(SEP)
schema = httpx.get(f"{BASE}/openapi.json").json()
paths = list(schema.get("paths", {}).keys())
print("  Paths in schema:", paths)
hidden = ["/api/legacy/export", "/api/debug"]
for p in hidden:
    present = p in paths
    print(f"  {p}  → {'VISIBLE (unexpected)' if present else 'hidden ✓'}")

print(f"\n{SEP}")
print("Done. Visit http://localhost:8000/switchly (admin / secret) to toggle routes live.")
print(SEP)
