# switchly — Production Test App

A production-grade FastAPI application that exercises every switchly feature:
`@maintenance`, `@disabled`, `@deprecated`, `@env_only`, `@force_active`, and `@rate_limit`.

Runs on Railway with a Redis backend, Gunicorn + UvicornWorker, and the full admin dashboard + CLI.

---

## Routes

| Method | Path | Switchly state |
|--------|------|-------------|
| GET | `/health` | `@force_active` — always 200, bypasses all checks |
| GET | `/api/payments` | `@maintenance` — 503 with reason |
| GET | `/api/payments/history` | Active |
| GET | `/api/orders` | `@rate_limit("10/minute")` |
| POST | `/api/orders` | `@rate_limit("5/minute")` |
| GET | `/api/debug` | `@env_only("dev","staging")` — 404 in production |
| GET | `/api/legacy/export` | `@disabled` — 503 |
| GET | `/api/v1/users` | `@deprecated` — 200 + deprecation headers |
| GET | `/api/v2/users` | Active |
| GET | `/api/analytics` | `@rate_limit("60/minute")` |

---

## Local development

### Without Redis (Memory backend)

```bash
cd production_test
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### With Redis (Docker Compose)

```bash
cd production_test
docker compose up --build
```

Both options expose:
- App: http://localhost:8000
- Admin dashboard: http://localhost:8000/switchly — `admin / changeme`
- API docs: http://localhost:8000/docs

---

## Deploy to Railway

### Prerequisites

- [Railway CLI](https://docs.railway.app/develop/cli): `brew install railway`
- A Railway account: https://railway.com

### Step 1 — Login and initialise

```bash
railway login
cd production_test
railway init        # create a new Railway project, name it e.g. "switchly-prod"
```

### Step 2 — Provision Redis

```bash
railway add --database redis
```

Railway creates a Redis service and injects `REDIS_URL` (private internal URL) into
the project. Do **not** set `REDIS_URL` manually — Railway handles it.

> **Important**: Redis injects its own `PORT=6379` into the shared project environment.
> Always set `PORT=8000` explicitly on the **web service** so Gunicorn binds to the
> correct port and Railway's healthcheck can reach it.

### Step 3 — Generate a secret key

All Gunicorn workers must share the same HMAC signing key so that a token issued by
worker A is accepted by worker B. Without this, every request after login redirects
back to the login page.

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

Copy the output — you will set it as `SWITCHLY_SECRET_KEY` in the next step.

### Step 4 — Set environment variables

Run these against your **web service** (not the Redis service):

```bash
railway variables set PORT=8000
railway variables set SWITCHLY_SECRET_KEY=<output-from-step-3>
railway variables set SWITCHLY_ADMIN_USER=admin
railway variables set SWITCHLY_ADMIN_PASS=<strong-password>
railway variables set SWITCHLY_ENV=production
railway variables set WEB_CONCURRENCY=2
railway variables set LOG_LEVEL=info
```

| Variable | Required | Description |
|----------|----------|-------------|
| `REDIS_URL` | Auto-injected | Set by Railway when Redis plugin is attached |
| `PORT` | Yes | Must be `8000` — overrides Redis's injected `PORT=6379` |
| `SWITCHLY_SECRET_KEY` | Yes | Stable HMAC key shared across all workers |
| `SWITCHLY_ADMIN_USER` | Yes | Admin dashboard username |
| `SWITCHLY_ADMIN_PASS` | Yes | Admin dashboard password |
| `SWITCHLY_ENV` | No | Environment name, default `production` |
| `WEB_CONCURRENCY` | No | Gunicorn worker count, default `2` |
| `LOG_LEVEL` | No | Log verbosity, default `info` |

### Step 5 — Deploy

```bash
railway up
```

Railway reads `railway.toml`, builds the Dockerfile, and starts the container.
The healthcheck hits `GET /health` (decorated with `@force_active`) to confirm the
app is up before routing traffic.

### Step 6 — Get your public URL

```bash
railway domain
```

---

## CLI usage

The `switchly` CLI talks to the admin REST API at `<your-url>/switchly`.

### Setup

```bash
# Point the CLI at your deployed instance
export SWITCHLY_SERVER_URL=https://<your-app>.up.railway.app/switchly

# Or save it persistently (only works when SWITCHLY_SERVER_URL env var is not set)
switchly config set-url https://<your-app>.up.railway.app/switchly
```

> If `SWITCHLY_SERVER_URL` is set as an environment variable it always takes priority
> over the saved config. Unset it if you want `switchly config set-url` to take effect:
> `unset SWITCHLY_SERVER_URL`

### Login

```bash
switchly login admin      # prompts for password
```

### Common commands

```bash
switchly status                                   # list all routes and their states
switchly status /api/payments                     # inspect one route

switchly enable /api/payments                     # lift maintenance
switchly maintenance /api/payments --reason "migration" --start "2026-04-01T02:00Z" --end "2026-04-01T04:00Z"
switchly disable /api/legacy/export --reason "retired"

switchly log                                      # audit log
switchly log --route /api/payments --limit 20
```

---

## Architecture

```
production_test/
├── main.py            # FastAPI app — routes, middleware, admin mount
├── config.py          # All config from environment variables
├── gunicorn.conf.py   # Gunicorn + UvicornWorker settings
├── requirements.txt   # switchly[all]==0.3.0 + gunicorn + uvicorn
├── Dockerfile         # Multi-stage build, non-root user, healthcheck
├── docker-compose.yml # Local: app + Redis
├── railway.toml       # Railway deploy config
└── .env.example       # Template — copy to .env for local overrides
```

### How switchly is installed

The Dockerfile installs `switchly[all]==0.3.0` directly from PyPI — no local source
is copied into the image. The `switchly/` library is accessed purely from site-packages,
identical to how any end-user would install it.

### Backend selection

`config.py` reads `REDIS_URL` at startup:

- **Set** → `RedisBackend` — route state persists across restarts, shared across all workers and instances.
- **Not set** → `MemoryBackend` — state resets on every restart. Fine for local dev, not for production.


### Token signing

`SwitchlyAdmin` is initialised with `secret_key=SECRET_KEY` (from `SWITCHLY_SECRET_KEY` env var).
All Gunicorn workers share the same key, so tokens are valid across workers and survive
process restarts. Without a stable key, every worker restart or load-balanced request
to a different worker invalidates the session.
