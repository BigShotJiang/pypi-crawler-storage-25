"""Production configuration loaded from environment variables.

Set these in your Railway dashboard or .env file.

Required in production
----------------------
REDIS_URL          Redis connection string injected automatically by Railway.
                   e.g. redis://default:password@host:6379

Optional
--------
SWITCHLY_ENV         Current environment name.       Default: production
SWITCHLY_ADMIN_USER  Admin dashboard username.        Default: admin
SWITCHLY_ADMIN_PASS  Admin dashboard password.        Default: changeme  ← change this
PORT               HTTP port uvicorn listens on.    Default: 8000
LOG_LEVEL          uvicorn / gunicorn log level.    Default: info
WEB_CONCURRENCY    Number of gunicorn worker procs. Default: 2
"""

import os

# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------

SWITCHLY_ENV: str = os.getenv("SWITCHLY_ENV", "production")

# Redis URL is provided automatically by Railway when you
# attach a Redis add-on.  Falls back to None → MemoryBackend (single-instance).
REDIS_URL: str | None = os.getenv("REDIS_URL")

# ---------------------------------------------------------------------------
# Admin dashboard
# ---------------------------------------------------------------------------

ADMIN_USER: str = os.getenv("SWITCHLY_ADMIN_USER", "admin")
ADMIN_PASS: str = os.getenv("SWITCHLY_ADMIN_PASS", "changeme")
# Required in production with multiple workers — all workers must share the
# same key so tokens signed by one worker are accepted by another.
# Generate with: python -c "import secrets; print(secrets.token_hex(32))"
SECRET_KEY: str | None = os.getenv("SWITCHLY_SECRET_KEY")

# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------

PORT: int = int(os.getenv("PORT", "8000"))
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "info")
WEB_CONCURRENCY: int = int(os.getenv("WEB_CONCURRENCY", "2"))
