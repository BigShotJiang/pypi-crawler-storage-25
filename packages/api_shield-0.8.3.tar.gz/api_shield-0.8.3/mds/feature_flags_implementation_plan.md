# Feature Flags — Implementation Plan

## Overview

Full-featured, OpenFeature-compliant feature flag system built into switchly.
Ships as an optional extra: `pip install switchly[flags]`.
Zero impact on applications that do not install or use it.
Works in both the **embedded design** (SwitchlyAdmin inside the app) and the
**Switchly Server design** (central SwitchlyServer + SwitchlySDK clients).
Flags are service-independent — multiple services evaluate the same flag
against their own evaluation context.

---

## Table of Contents

1. [Optional Dependency](#1-optional-dependency)
2. [Architecture Overview](#2-architecture-overview)
3. [Module Structure](#3-module-structure)
4. [Data Models](#4-data-models)
5. [Evaluation Engine](#5-evaluation-engine)
6. [Provider System](#6-provider-system)
7. [SwitchlyFeatureClient](#7-switchlyfeatureclient)
8. [Hooks](#8-hooks)
9. [Import Facade](#9-import-facade)
10. [Integration Patterns](#10-integration-patterns)
11. [Embedded Design Integration](#11-embedded-design-integration)
12. [Switchly Server Design Integration](#12-switchly-server-design-integration)
13. [REST API Endpoints](#13-rest-api-endpoints)
14. [CLI Commands](#14-cli-commands)
15. [Dashboard Design](#15-dashboard-design)
16. [Metrics and Observability](#16-metrics-and-observability)
17. [Segments](#17-segments)
18. [Scheduled Flag Changes](#18-scheduled-flag-changes)
19. [Flag Health and Stale Detection](#19-flag-health-and-stale-detection)
20. [Live Events Stream](#20-live-events-stream)
21. [Eval Debugger](#21-eval-debugger)
22. [pyproject.toml Changes](#22-pyprojecttoml-changes)
23. [Test Conventions](#23-test-conventions)
24. [Implementation Order](#24-implementation-order)

---

## 1. Optional Dependency

### Installation

```bash
# Flags only
pip install switchly[flags]

# Flags + redis (recommended for multi-service)
pip install switchly[flags,redis]

# Everything
pip install switchly[all]
```

### What gets installed

| Package | Purpose |
|---|---|
| `openfeature-sdk>=0.8` | Evaluation API, provider ABC, hook lifecycle |
| `packaging>=23.0` | Semantic version comparisons in targeting rules |

### Guard pattern — zero import cost when not installed

Every module inside `switchly/core/feature_flags/` and `switchly/fastapi/`
that touches the flags system wraps its imports in a lazy guard:

```python
# switchly/core/feature_flags/__init__.py

def _require_flags() -> None:
    try:
        import openfeature  # noqa: F401
    except ImportError:
        raise ImportError(
            "Feature flags require the [flags] extra.\n"
            "Install with: pip install switchly[flags]"
        ) from None
```

All public symbols re-exported from `switchly/core/feature_flags/__init__.py`
call `_require_flags()` at import time — never at module load time —
so apps that never import from this module pay zero cost.

`SwitchlyEngine`, `SwitchlyAdmin`, `SwitchlySDK`, and middleware are **never**
modified to unconditionally import flag code. Flag wiring is always
initiated by the application via `engine.use_openfeature()`.

---

## 2. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│  Application code                                                   │
│                                                                     │
│  from switchly.core.feature_flags import EvaluationContext            │
│  await flags.get_boolean_value("new_checkout", False, ctx)          │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│  SwitchlyFeatureClient   (switchly/core/feature_flags/client.py)        │
│  • Wraps OpenFeature client                                         │
│  • Runs hooks before/after every evaluation                         │
│  • Returns typed values or ResolutionDetails                        │
└────────────────────────────┬────────────────────────────────────────┘
                             │
           ┌─────────────────┴──────────────────┐
           │  OpenFeature SDK internals          │
           │  • Hook chain execution             │
           │  • Provider dispatch                │
           └─────────────────┬──────────────────┘
                             │
         ┌───────────────────┼────────────────────────┐
         │                   │                        │
         ▼                   ▼                        ▼
┌─────────────────┐ ┌─────────────────┐  ┌──────────────────────┐
│ SwitchlyOpenFeat  │ │ LaunchDarkly    │  │ Flagsmith / ConfigCat │
│ ureProvider     │ │ Provider        │  │ / any OpenFeature     │
│ (native, built  │ │ (third-party,   │  │   provider            │
│  into library)  │ │  user-supplied) │  │                       │
└────────┬────────┘ └─────────────────┘  └──────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────────┐
│  SwitchlyBackend  (MemoryBackend | FileBackend | RedisBackend |       │
│                  SwitchlyServerBackend)                               │
│  • Stores FeatureFlag objects alongside RouteState                  │
│  • Pub/sub notifies all connected services on flag change           │
└─────────────────────────────────────────────────────────────────────┘
```

### Evaluation flow (per request)

```
1. Flag OFF globally?              → return off_variation
2. Prerequisites met?              → if any fail, return off_variation
3. Individual targeting?           → if context.key in target list → return variation
4. Segment targeting rules?        → first rule match → return variation
5. Targeting rules (top→bottom)?   → first rule match → return variation
6. Fallthrough (default rule)?     → fixed variation OR percentage rollout bucket
7. Attach EvaluationReason + return ResolutionDetails
```

---

## 3. Module Structure

```
switchly/
└── core/
    └── feature_flags/
        ├── __init__.py          ← public re-export facade (switchly.* namespace)
        ├── _guard.py            ← _require_flags() helper
        ├── models.py            ← all data models
        ├── evaluator.py         ← pure evaluation logic (FlagEvaluator)
        ├── provider.py          ← SwitchlyOpenFeatureProvider
        ├── client.py            ← SwitchlyFeatureClient
        ├── hooks.py             ← SwitchlyHook ABC + built-in hooks
        ├── metrics.py           ← FlagMetricsCollector (eval stats)
        ├── health.py            ← FlagHealthChecker (stale detection)
        ├── scheduler.py         ← FlagScheduler (scheduled changes)
        └── segments.py          ← Segment evaluation helpers

switchly/
└── fastapi/
    └── decorators.py            ← @feature_flag added to existing file

switchly/
└── admin/
    ├── api.py                   ← /api/flags/* and /api/segments/* routes added
    └── app.py                   ← flag_client wired into SwitchlyAdmin if present

switchly/
└── sdk/
    └── __init__.py              ← SwitchlySDK.use_openfeature() method added

switchly/
└── dashboard/
    └── templates/
        ├── flags.html
        ├── flag_detail.html
        ├── segments.html
        └── partials/
            ├── flag_row.html
            ├── flag_event_row.html
            ├── flag_stat_bars.html
            ├── flag_rules_panel.html
            ├── flag_schedule_panel.html
            ├── flag_history_panel.html
            ├── segment_row.html
            ├── modal_flag_create.html
            ├── modal_flag_eval.html
            ├── modal_flag_prereq.html
            └── modal_segment_detail.html
```

---

## 4. Data Models

File: `switchly/core/feature_flags/models.py`

### Flag type and variations

```python
class FlagType(StrEnum):
    BOOLEAN = "boolean"
    STRING  = "string"
    INTEGER = "integer"
    FLOAT   = "float"
    JSON    = "json"

class FlagVariation(BaseModel):
    name: str           # "on", "off", "blue", "v2", "control"
    value: bool | str | int | float | dict | list
    description: str = ""
```

### Targeting operators (all 20)

```python
class Operator(StrEnum):
    # Equality
    IS              = "is"
    IS_NOT          = "is_not"
    # String
    CONTAINS        = "contains"
    NOT_CONTAINS    = "not_contains"
    STARTS_WITH     = "starts_with"
    ENDS_WITH       = "ends_with"
    MATCHES         = "matches"       # regex
    NOT_MATCHES     = "not_matches"
    # Numeric
    GT              = "gt"
    GTE             = "gte"
    LT              = "lt"
    LTE             = "lte"
    # Date
    BEFORE          = "before"
    AFTER           = "after"
    # Collection
    IN              = "in"
    NOT_IN          = "not_in"
    # Segment
    IN_SEGMENT      = "in_segment"
    NOT_IN_SEGMENT  = "not_in_segment"
    # Semver
    SEMVER_EQ       = "semver_eq"
    SEMVER_LT       = "semver_lt"
    SEMVER_GT       = "semver_gt"
```

### Rule and targeting models

```python
class RuleClause(BaseModel):
    attribute: str          # "role", "plan", "email", "country", "app_version"
    operator: Operator
    values: list[Any]       # multiple values are OR'd within the clause
    negate: bool = False    # invert the result

class RolloutVariation(BaseModel):
    variation: str          # references FlagVariation.name
    weight: int             # out of 100_000 (fine-grained, like LaunchDarkly)

class TargetingRule(BaseModel):
    id: str                 # uuid4
    description: str = ""
    clauses: list[RuleClause]        # ALL clauses must match (AND logic)
    variation: str | None = None     # fixed variation OR rollout, not both
    rollout: list[RolloutVariation] | None = None
    track_events: bool = False

class Prerequisite(BaseModel):
    flag_key: str
    variation: str          # required variation name from the prerequisite flag
```

### Segment models

```python
class SegmentRule(BaseModel):
    id: str
    clauses: list[RuleClause]

class Segment(BaseModel):
    key: str
    name: str
    description: str = ""
    included: list[str] = Field(default_factory=list)  # explicit context keys
    excluded: list[str] = Field(default_factory=list)  # explicit exclusions
    rules: list[SegmentRule] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime
```

### Scheduled change

```python
class ScheduledChangeAction(StrEnum):
    ENABLE          = "enable"
    DISABLE         = "disable"
    UPDATE_ROLLOUT  = "update_rollout"
    DELETE_RULE     = "delete_rule"
    ADD_RULE        = "add_rule"

class ScheduledChange(BaseModel):
    id: str
    execute_at: datetime
    action: ScheduledChangeAction
    payload: dict[str, Any] = Field(default_factory=dict)
    created_by: str = "system"
    created_at: datetime
```

### Full flag definition

```python
class FlagStatus(StrEnum):
    ACTIVE      = "active"
    INACTIVE    = "inactive"
    LAUNCHED    = "launched"
    DEPRECATED  = "deprecated"
    ARCHIVED    = "archived"

class FeatureFlag(BaseModel):
    key: str
    name: str
    description: str = ""
    type: FlagType
    tags: list[str] = Field(default_factory=list)

    variations: list[FlagVariation]
    off_variation: str               # served when flag is globally disabled
    fallthrough: str | list[RolloutVariation]  # default when no rule matches

    enabled: bool = True
    prerequisites: list[Prerequisite] = Field(default_factory=list)

    # Individual targeting: variation_name → list of context keys
    targets: dict[str, list[str]] = Field(default_factory=dict)

    # Rules evaluated top-to-bottom, first match wins
    rules: list[TargetingRule] = Field(default_factory=list)

    # Scheduling
    scheduled_changes: list[ScheduledChange] = Field(default_factory=list)

    # Metadata
    status: FlagStatus = FlagStatus.ACTIVE
    temporary: bool = True          # hint for flag hygiene tooling
    maintainer: str | None = None
    created_at: datetime
    updated_at: datetime
    created_by: str = "system"
```

### Evaluation context and result

```python
class EvaluationContext(BaseModel):
    """Per-request targeting context. Imported from switchly.* namespace."""
    key: str                # required — unique identifier (user_id, session, org_id)
    kind: str = "user"      # "user" | "organization" | "device" | custom
    # named convenience fields
    email: str | None = None
    ip: str | None = None
    country: str | None = None
    app_version: str | None = None
    # arbitrary additional attributes
    attributes: dict[str, Any] = Field(default_factory=dict)

    def all_attributes(self) -> dict[str, Any]:
        """Merge named fields and attributes dict for rule evaluation."""
        base = {k: v for k, v in {
            "email": self.email, "ip": self.ip,
            "country": self.country, "app_version": self.app_version,
            "kind": self.kind,
        }.items() if v is not None}
        return {**base, **self.attributes}

class EvaluationReason(StrEnum):
    OFF               = "OFF"
    FALLTHROUGH       = "FALLTHROUGH"
    TARGET_MATCH      = "TARGET_MATCH"
    RULE_MATCH        = "RULE_MATCH"
    PREREQUISITE_FAIL = "PREREQUISITE_FAIL"
    ERROR             = "ERROR"
    DEFAULT           = "DEFAULT"

class ResolutionDetails(BaseModel):
    """Full result of a flag evaluation."""
    value: Any
    variation: str | None = None
    reason: EvaluationReason
    rule_id: str | None = None
    prerequisite_key: str | None = None
    error_message: str | None = None
```

---

## 5. Evaluation Engine

File: `switchly/core/feature_flags/evaluator.py`

Pure evaluation logic — no I/O, no async, fully testable in isolation.
Takes preloaded `FeatureFlag`, `Segment` maps and an `EvaluationContext`.

### Evaluation steps

```python
class FlagEvaluator:
    def __init__(self, segments: dict[str, Segment]) -> None: ...

    def evaluate(
        self,
        flag: FeatureFlag,
        ctx: EvaluationContext,
        all_flags: dict[str, FeatureFlag],  # for prerequisite recursion
    ) -> ResolutionDetails:
        # Step 1: Flag disabled → off_variation
        # Step 2: Prerequisites (recursive, short-circuits on first failure)
        # Step 3: Individual targets (highest priority after prerequisites)
        # Step 4: Rules top-to-bottom (first match wins)
        # Step 5: Fallthrough (fixed variation or percentage bucket)
        ...
```

### Clause evaluation

- All clauses within a rule use AND logic (all must match)
- Multiple values within a single clause use OR logic (any must match)
- `negate=True` inverts the final result of the clause
- Regex via Python `re` module (standard library, no extra deps)
- Semver via `packaging.version.Version` (only imported when semver operator used)

### Percentage rollout bucketing

Deterministic, stable across evaluations:

```python
@staticmethod
def _bucket(flag_key: str, ctx: EvaluationContext) -> int:
    """Returns 0–99999. Same context always gets the same bucket."""
    import hashlib
    seed = f"{flag_key}:{ctx.kind}:{ctx.key}"
    return int(hashlib.sha1(seed.encode()).hexdigest(), 16) % 100_000
```

Weights are out of 100,000 (same granularity as LaunchDarkly) allowing
precise rollouts like 0.1%, 33.33%, etc.

---

## 6. Provider System

### SwitchlyOpenFeatureProvider (native)

File: `switchly/core/feature_flags/provider.py`

Implements OpenFeature's `AbstractProvider`.
Backed by `SwitchlyBackend` — flags stored alongside `RouteState`.
Subscribes to backend pub/sub for instant hot-reload on flag change.

```python
from openfeature.provider.abstract_provider import AbstractProvider

class SwitchlyOpenFeatureProvider(AbstractProvider):
    name = "switchly"

    def __init__(self, backend: SwitchlyBackend) -> None:
        self._backend = backend
        self._flags: dict[str, FeatureFlag] = {}
        self._segments: dict[str, Segment] = {}
        self._evaluator: FlagEvaluator | None = None

    async def initialize(self, evaluation_context=None) -> None:
        # Load flags and segments from backend
        # Subscribe to backend pub/sub for hot-reload
        # Build FlagEvaluator with loaded segments
        ...

    async def shutdown(self) -> None:
        # Unsubscribe from pub/sub
        ...

    def resolve_boolean_details(self, flag_key, default, ctx): ...
    def resolve_string_details(self, flag_key, default, ctx): ...
    def resolve_integer_details(self, flag_key, default, ctx): ...
    def resolve_float_details(self, flag_key, default, ctx): ...
    def resolve_object_details(self, flag_key, default, ctx): ...
```

All `resolve_*` methods delegate to `FlagEvaluator.evaluate()` and
map the result to OpenFeature's `FlagResolutionDetails`.

### External provider (user-supplied)

Any OpenFeature-compatible provider (LaunchDarkly, Flagsmith, ConfigCat, etc.)
can be passed to `engine.use_openfeature(provider=...)`.
The user implements nothing Switchly-specific — they only implement
OpenFeature's `AbstractProvider` (or use a pre-built third-party provider).

```python
from launchdarkly_openfeature_server import LaunchDarklyProvider
# No switchly imports needed for the provider itself

engine.use_openfeature(provider=LaunchDarklyProvider("sdk-key"))
```

When an external provider is used:
- Flag CRUD via Switchly admin UI and CLI is unavailable (flags live in the external system)
- Hooks, audit logging, live eval stream, and all evaluation patterns work unchanged
- `SwitchlyFeatureClient` API is identical regardless of provider

---

## 7. SwitchlyFeatureClient

File: `switchly/core/feature_flags/client.py`

Thin wrapper around OpenFeature's client.
This is the object application code interacts with.

```python
class SwitchlyFeatureClient:
    def __init__(self, domain: str = "switchly") -> None:
        from openfeature import api
        self._client = api.get_client(domain)
        self._metrics: FlagMetricsCollector | None = None

    # Simple value methods — most common usage
    async def get_boolean_value(self, flag_key: str, default: bool,
                                ctx: EvaluationContext | None = None) -> bool: ...
    async def get_string_value(self, flag_key: str, default: str,
                               ctx: EvaluationContext | None = None) -> str: ...
    async def get_integer_value(self, flag_key: str, default: int,
                                ctx: EvaluationContext | None = None) -> int: ...
    async def get_float_value(self, flag_key: str, default: float,
                              ctx: EvaluationContext | None = None) -> float: ...
    async def get_object_value(self, flag_key: str, default: dict,
                               ctx: EvaluationContext | None = None) -> dict: ...

    # Full details methods — for debugging, audit, metrics
    async def resolve_boolean_details(self, ...) -> ResolutionDetails[bool]: ...
    async def resolve_string_details(self, ...) -> ResolutionDetails[str]: ...
    async def resolve_integer_details(self, ...) -> ResolutionDetails[int]: ...
    async def resolve_object_details(self, ...) -> ResolutionDetails[dict]: ...
```

### Engine integration

```python
# switchly/core/engine.py — new method on SwitchlyEngine

def use_openfeature(
    self,
    provider=None,          # any OpenFeature AbstractProvider, or None → SwitchlyProvider
    hooks: list | None = None,
    domain: str = "switchly",
) -> SwitchlyFeatureClient:
    from openfeature import api
    from openfeature.provider.no_op_provider import NoOpProvider
    from switchly.core.feature_flags.provider import SwitchlyOpenFeatureProvider
    from switchly.core.feature_flags.client import SwitchlyFeatureClient
    from switchly.core.feature_flags.hooks import LoggingHook, AuditHook

    if provider is not None:
        api.set_provider(provider, domain)
    elif isinstance(api.get_provider(domain), NoOpProvider):
        api.set_provider(SwitchlyOpenFeatureProvider(backend=self.backend), domain)

    # Default hooks: logging + audit (audit writes to existing AuditEntry system)
    default_hooks = [LoggingHook(), AuditHook(self)]
    for hook in (hooks or []):
        default_hooks.append(hook)
    api.add_hooks(default_hooks)

    client = SwitchlyFeatureClient(domain=domain)
    self._flag_client = client
    return client

@property
def flag_client(self) -> SwitchlyFeatureClient | None:
    return self._flag_client
```

`SwitchlyRouter` startup hook calls `provider.initialize()` automatically
if a flag client is registered. Shutdown calls `provider.shutdown()`.

---

## 8. Hooks

File: `switchly/core/feature_flags/hooks.py`

Uses OpenFeature's native hook interface — no Switchly-specific base class needed.

### Built-in hooks shipped with the library

```python
# Logging hook — always registered by default
class LoggingHook(Hook):
    """Logs every flag evaluation at DEBUG level."""
    def after(self, hook_context, details, hints): ...
    def error(self, hook_context, exception, hints): ...

# Audit hook — always registered by default
class AuditHook(Hook):
    """Records flag evaluations into SwitchlyEngine's audit log.
    Only records non-FALLTHROUGH, non-DEFAULT reasons to avoid noise."""
    def __init__(self, engine: SwitchlyEngine): ...
    async def after(self, hook_context, details, hints): ...

# Metrics hook — registered automatically when flag_client has a collector
class MetricsHook(Hook):
    """Increments per-variation counters for dashboard stats."""
    def __init__(self, collector: FlagMetricsCollector): ...
    def after(self, hook_context, details, hints): ...

# OpenTelemetry hook — optional, registered by user
class OpenTelemetryHook(Hook):
    """Sets feature_flag.{key} span attributes on the current OTel span."""
    def after(self, hook_context, details, hints): ...
```

### Hook execution order (OpenFeature spec)

```
Before:  API hooks → Client hooks → Invocation hooks → Provider hooks
After:   Provider hooks → Invocation hooks → Client hooks → API hooks
Error:   same as After
Finally: same as After (always runs)
```

---

## 9. Import Facade

File: `switchly/core/feature_flags/__init__.py`

Users import from `switchly.*` exclusively. `openfeature` is never visible.

```python
# All exports use Switchly-namespaced names
from openfeature.evaluation_context import EvaluationContext as EvaluationContext
from openfeature.hook import Hook as SwitchlyHook
from openfeature.flag_evaluation import FlagResolutionDetails as ResolutionDetails
from openfeature.provider.abstract_provider import AbstractProvider as SwitchlyFlagProvider
from openfeature.flag_evaluation import Reason as ResolutionReason

from switchly.core.feature_flags.models import (
    FeatureFlag as FeatureFlag,
    FlagType as FlagType,
    FlagVariation as FlagVariation,
    FlagStatus as FlagStatus,
    FlagVariation as FlagVariation,
    TargetingRule as TargetingRule,
    RuleClause as RuleClause,
    Operator as Operator,
    Prerequisite as Prerequisite,
    Segment as Segment,
    SegmentRule as SegmentRule,
    ScheduledChange as ScheduledChange,
    EvaluationContext as EvaluationContext,
    EvaluationReason as EvaluationReason,
    ResolutionDetails as ResolutionDetails,
    RolloutVariation as RolloutVariation,
)

from switchly.core.feature_flags.client import SwitchlyFeatureClient as SwitchlyFeatureClient
from switchly.core.feature_flags.provider import SwitchlyOpenFeatureProvider as SwitchlyOpenFeatureProvider
from switchly.core.feature_flags.hooks import (
    LoggingHook as LoggingHook,
    AuditHook as AuditHook,
    OpenTelemetryHook as OpenTelemetryHook,
)

__all__ = [
    "EvaluationContext", "EvaluationReason", "ResolutionDetails",
    "ResolutionReason", "SwitchlyHook", "SwitchlyFlagProvider",
    "SwitchlyFeatureClient", "SwitchlyOpenFeatureProvider",
    "FeatureFlag", "FlagType", "FlagVariation", "FlagStatus",
    "TargetingRule", "RuleClause", "Operator", "Prerequisite",
    "RolloutVariation", "Segment", "SegmentRule", "ScheduledChange",
    "LoggingHook", "AuditHook", "OpenTelemetryHook",
]
```

### What users write

```python
# All switchly-namespaced — openfeature never appears in user code
from switchly.core.feature_flags import EvaluationContext, SwitchlyFeatureClient

# If building a custom provider (rare):
from switchly.core.feature_flags import SwitchlyFlagProvider

class MyProvider(SwitchlyFlagProvider):   # actually AbstractProvider under the hood
    ...
```

---

## 10. Integration Patterns

### Pattern 1 — Inline in route handler (most common)

```python
async def checkout(request: Request):
    ctx = EvaluationContext(
        key=request.headers.get("x-user-id", "anonymous"),
        attributes={"role": request.headers.get("x-role"), "plan": "pro"},
    )
    if await flag_client.get_boolean_value("new_checkout", False, ctx):
        return await new_checkout_flow(request)
    return await legacy_checkout_flow(request)
```

### Pattern 2 — FastAPI Dependency (shared across routes)

```python
async def flags(
    request: Request,
    client: SwitchlyFeatureClient = Depends(get_flag_client),
) -> dict[str, Any]:
    ctx = build_ctx(request)
    return {
        "new_ui":    await client.get_boolean_value("new_ui", False, ctx),
        "dark_mode": await client.get_boolean_value("dark_mode", False, ctx),
    }

@router.get("/dashboard")
async def dashboard(resolved_flags: dict = Depends(flags)):
    template = "v2.html" if resolved_flags["new_ui"] else "v1.html"
    ...
```

`get_flag_client` FastAPI dependency reads from `request.app.state.switchly_engine.flag_client`.

### Pattern 3 — Decorator (full endpoint gate)

```python
# switchly/fastapi/decorators.py — new decorator alongside @maintenance, @env_only

def feature_flag(
    flag_key: str,
    *,
    default: bool = False,
    fallback_response: Any = None,   # custom response when flag is off
    client: SwitchlyFeatureClient | None = None,
):
    def decorator(func):
        @wraps(func)
        async def wrapper(request: Request, *args, **kwargs):
            _client = client or _get_engine_flag_client(request)
            ctx = _build_ctx_from_request(request)
            enabled = await _client.get_boolean_value(flag_key, default, ctx)
            if not enabled:
                if fallback_response is not None:
                    return fallback_response
                raise HTTPException(404, detail=f"Feature '{flag_key}' not available")
            return await func(request, *args, **kwargs)
        return wrapper
    return decorator
```

### Pattern 4 — Middleware (request-wide resolution)

```python
class FeatureFlagMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, client: SwitchlyFeatureClient, flags: list[str]):
        super().__init__(app)
        self._client = client
        self._flags = flags

    async def dispatch(self, request: Request, call_next):
        ctx = _build_ctx_from_request(request)
        request.state.flags = {
            key: await self._client.get_boolean_value(key, False, ctx)
            for key in self._flags
        }
        return await call_next(request)
```

### Pattern 5 — Service / domain layer (no HTTP dependency)

```python
class BillingService:
    def __init__(self, flags: SwitchlyFeatureClient): ...

    async def charge(self, user: User, amount: Decimal):
        ctx = EvaluationContext(
            key=user.id,
            attributes={"plan": user.plan, "country": user.country},
        )
        if await self._flags.get_boolean_value("stripe_v2", False, ctx):
            return await stripe_v2.charge(user, amount)
        return await stripe_v1.charge(user, amount)
```

### Pattern 6 — String / object / numeric variants

```python
# String flag: which algorithm to use
algorithm = await flags.get_string_value("search_algorithm", "bm25", ctx)
# Returns: "bm25" | "semantic" | "hybrid" depending on targeting

# Object flag: entire config blob as a variation
limits = await flags.get_object_value("rate_limit_config", default_limits, ctx)
# Returns: {"requests_per_minute": 100, "burst": 20}

# Integer flag: page size variant
page_size = await flags.get_integer_value("results_page_size", 20, ctx)
```

### Pattern 7 — Background tasks / Celery workers

```python
@celery.task
def generate_report(user_id: str):
    ctx = EvaluationContext(key=user_id)
    # anyio.run bridges sync context into async evaluation
    use_new = anyio.from_thread.run_sync(
        lambda: asyncio.run(flag_client.get_boolean_value("new_reports", False, ctx))
    )
    engine = new_engine if use_new else legacy_engine
    engine.generate(user_id)
```

---

## 11. Embedded Design Integration

The embedded design has `SwitchlyAdmin` mounted inside the application.
Flags are stored in the same backend as route state.

### Setup

```python
from switchly.core.engine import SwitchlyEngine
from switchly.core.backends.redis import RedisBackend
from switchly.fastapi import SwitchlyAdmin, SwitchlyRouter
from switchly.core.feature_flags import EvaluationContext

engine = SwitchlyEngine(backend=RedisBackend("redis://localhost:6379"))
router = SwitchlyRouter(engine=engine)

# One line to activate feature flags
flag_client = engine.use_openfeature()

# OR with a third-party provider:
# from launchdarkly_openfeature_server import LaunchDarklyProvider
# flag_client = engine.use_openfeature(provider=LaunchDarklyProvider("sdk-key"))

# OR with extra hooks:
# from switchly.core.feature_flags import OpenTelemetryHook
# flag_client = engine.use_openfeature(hooks=[OpenTelemetryHook()])

@router.get("/checkout")
async def checkout(request: Request):
    ctx = EvaluationContext(key=request.headers.get("x-user-id", "anon"))
    if await flag_client.get_boolean_value("new_checkout", False, ctx):
        ...

admin = SwitchlyAdmin(engine=engine, auth=("admin", "pass"))
app.include_router(router)
app.mount("/switchly", admin)
```

### What SwitchlyAdmin does when flags are active

- Adds `Flags` and `Segments` tabs to the dashboard navigation
- Mounts `/api/flags/*` and `/api/segments/*` REST endpoints
- Registers `FlagScheduler` as a background task on startup
- Wires `FlagMetricsCollector` into `SwitchlyFeatureClient` via `MetricsHook`
- Exposes `/api/flags/{key}/stream` SSE endpoint for live events

### Multi-service with embedded design

Multiple services all connect to the same `RedisBackend`.
A flag change on Service A's admin dashboard propagates via Redis pub/sub
to Services B and C immediately.
Each service evaluates flags locally against its own request context.

---

## 12. Switchly Server Design Integration

The Switchly Server design has a central `SwitchlyServer` process.
`SwitchlySDK` clients connect to it via SSE for live state updates.

### Server setup

```python
# switchly_server.py
from switchly.server import SwitchlyServer
from switchly.core.backends.redis import RedisBackend

app = SwitchlyServer(
    backend=RedisBackend("redis://redis:6379"),
    auth=("admin", "secret"),
    enable_flags=True,    # NEW: activates flag endpoints + dashboard tabs
)
# Flags are managed centrally from this server's admin UI and CLI.
# uvicorn switchly_server:app --host 0.0.0.0 --port 9000
```

`enable_flags=True` is a new parameter on `SwitchlyServer` (and `SwitchlyAdmin`).
When `True`, calls `engine.use_openfeature()` internally and mounts
all flag API routes and dashboard templates.
Defaults to `False` so existing deployments are unaffected.

### Client service setup

```python
# payments_service.py
from switchly.sdk import SwitchlySDK
from switchly.core.feature_flags import EvaluationContext

sdk = SwitchlySDK(
    server_url="http://switchly-server:9000",
    app_id="payments-service",
    token="...",
)
sdk.attach(app)

# Activate flags — syncs flag state from Switchly Server via SSE
flag_client = sdk.use_openfeature()

@app.get("/checkout")
async def checkout(request: Request):
    ctx = EvaluationContext(key=request.headers.get("x-user-id", "anon"))
    if await flag_client.get_boolean_value("new_checkout", False, ctx):
        ...
```

### How flag sync works in Switchly Server design

1. On `sdk.use_openfeature()`, `SwitchlySDK` creates a `SwitchlySDKFlagProvider`
   which extends `SwitchlyOpenFeatureProvider` but backed by `SwitchlyServerBackend`.
2. On startup, `SwitchlySDKFlagProvider.initialize()` calls
   `GET /api/flags` on the Switchly Server to load all flags and segments.
3. The existing SSE channel (used for route state) is extended to also
   carry flag change events (`{"type": "flag_updated", "flag": {...}}`).
4. On flag change event, the local flag cache is updated instantly.
5. All evaluations run **locally** — no network call per evaluation.
6. Evaluation metrics are collected locally and pushed to the Switchly Server
   periodically via `POST /api/flags/{key}/metrics`.

### SSE event types extended for flags

```json
// Existing route state event (unchanged)
{"type": "route_updated", "route": {...}}

// New flag events
{"type": "flag_updated",  "flag": {...}}
{"type": "flag_deleted",  "key": "..."}
{"type": "segment_updated", "segment": {...}}
{"type": "segment_deleted", "key": "..."}
```

---

## 13. REST API Endpoints

All endpoints mounted under the SwitchlyAdmin/SwitchlyServer prefix (e.g. `/switchly`).
Authentication follows existing Bearer token / session cookie pattern.

### Flag CRUD

```
GET    /api/flags                              List all flags
                                               ?tag=beta&status=active&type=boolean
POST   /api/flags                              Create flag
GET    /api/flags/{key}                        Get flag + current eval stats
PATCH  /api/flags/{key}                        Update flag (partial)
DELETE /api/flags/{key}                        Delete flag (must be archived first)
```

### Flag lifecycle

```
POST   /api/flags/{key}/enable                 Enable flag
POST   /api/flags/{key}/disable                Disable flag
POST   /api/flags/{key}/archive                Archive flag
POST   /api/flags/{key}/deprecate              Deprecate flag
```

### Targeting

```
PUT    /api/flags/{key}/targets                Replace individual target lists
PUT    /api/flags/{key}/rules                  Replace full rule list (ordered)
PUT    /api/flags/{key}/fallthrough            Update default rule
PUT    /api/flags/{key}/prerequisites          Update prerequisite list
```

### Rollout

```
PATCH  /api/flags/{key}/rollout                Set fallthrough percentage weights
POST   /api/flags/{key}/rollout/complete       Jump fallthrough to 100% on-variation
```

### Scheduling

```
GET    /api/flags/{key}/scheduled              List scheduled changes
POST   /api/flags/{key}/scheduled              Create scheduled change
DELETE /api/flags/{key}/scheduled/{id}         Cancel scheduled change
```

### Metrics and observability

```
GET    /api/flags/{key}/stats                  Eval counts per variation
                                               ?window=1h|24h|7d|30d
GET    /api/flags/{key}/health                 Health report (stale detection)
GET    /api/flags/health                       Health report for all flags
GET    /api/flags/{key}/stream                 SSE live evaluation stream
```

### Eval debugger

```
POST   /api/flags/{key}/evaluate               Dry-run evaluation
                                               Body: EvaluationContext
                                               Returns: ResolutionDetails
```

### Segments

```
GET    /api/segments                           List all segments
POST   /api/segments                           Create segment
GET    /api/segments/{key}                     Get segment
PATCH  /api/segments/{key}                     Update segment
DELETE /api/segments/{key}                     Delete segment
POST   /api/segments/{key}/include             Add context keys to included list
POST   /api/segments/{key}/exclude             Add context keys to excluded list
DELETE /api/segments/{key}/include/{ctx_key}   Remove from included list
DELETE /api/segments/{key}/exclude/{ctx_key}   Remove from excluded list
```

### Metrics push (Switchly Server design only)

```
POST   /api/flags/{key}/metrics                SDK clients push local eval counts
```

---

## 14. CLI Commands

All commands follow the existing pattern: thin HTTP client via `SwitchlyClient`.
Requires `switchly[cli]` in addition to `switchly[flags]`.

### Flag commands

```bash
switchly flags list
switchly flags list --tag beta --status active --type boolean

switchly flags get <key>
switchly flags create <key> --name "New Checkout" --type boolean
switchly flags enable  <key>
switchly flags disable <key>
switchly flags archive <key>
switchly flags delete  <key>
```

### Targeting

```bash
# Individual targets
switchly flags target <key> --variation on  --add-key user_123,user_456
switchly flags target <key> --variation off --remove-key user_123

# Rules
switchly flags rules list <key>
switchly flags rules add  <key> --clause "role in [admin,beta]" --variation on
switchly flags rules add  <key> --clause "plan is pro" --rollout "on:75,off:25"
switchly flags rules move <key> <rule_id> --position 0
switchly flags rules delete <key> <rule_id>

# Fallthrough
switchly flags fallthrough <key> --variation off
switchly flags fallthrough <key> --rollout "on:25,off:75"

# Prerequisites
switchly flags prereqs add    <key> --flag auth_v2 --variation on
switchly flags prereqs remove <key> --flag auth_v2
```

### Rollout

```bash
switchly flags rollout <key> --variation on --percentage 25
switchly flags rollout <key> --complete       # → 100%
```

### Scheduling

```bash
switchly flags schedule <key> --action enable  --at "2026-04-01T09:00:00Z"
switchly flags schedule <key> --action disable --at "2026-04-30T00:00:00Z"
switchly flags schedule list   <key>
switchly flags schedule cancel <key> <schedule_id>
```

### Metrics and health

```bash
switchly flags stats  <key>                   # eval counts last 24h
switchly flags stats  <key> --window 7d
switchly flags health                         # all flags health report
switchly flags health --filter safe_to_remove
switchly flags health --filter monitor
```

### Live stream (like `tail -f`)

```bash
switchly flags stream             # live evaluation feed, all flags
switchly flags stream <key>       # live feed for one flag
switchly flags stream <key> --reason RULE_MATCH  # filter by reason
```

### Eval debugger

```bash
switchly flags eval <key> \
  --key user_123 \
  --kind user \
  --attr role=admin \
  --attr plan=pro \
  --attr country=US

# Output:
# value:     true
# variation: on
# reason:    RULE_MATCH
# rule_id:   rule_abc123
# rule desc: "Pro and admin users"
```

### Segments

```bash
switchly segments list
switchly segments create <key> --name "Beta Users"
switchly segments get    <key>
switchly segments delete <key>

switchly segments include <key> --context-key user_123,user_456
switchly segments exclude <key> --context-key user_789

switchly segments rules add    <key> --clause "plan in [pro,enterprise]"
switchly segments rules delete <key> <rule_id>
```

---

## 15. Dashboard Design

Built on the existing HTMX + Tailwind stack. No new JS libraries.

### Nav changes in `base.html`

Add two tabs to the existing pill nav:

```
Routes | Audit | Rate Limits | Blocked | Flags | Segments
```

### Page: Flag List (`flags.html`)

Columns: Key (font-mono, clickable) | Type badge | Status badge | Health badge |
         Evals today | On/Off toggle | Actions menu

- Search bar: `hx-get` on input → swaps `#flags-table-body` (same pattern as routes)
- Filter dropdowns: Type, Status, Tag (query params)
- Create Flag button → opens `<dialog>` modal (`modal_flag_create.html`)
- On/Off toggle: `hx-post` to `/flags/{key}/enable` or `/disable`
- Actions: View (link to detail page) | Archive | Delete

### Page: Flag Detail (`flag_detail.html`)

URL: `/flags/{key}`

Header: breadcrumb `← Flags` | flag key + type badge + status | Enable/Disable/Archive buttons

In-page sub-tabs (HTMX, not page navigation):

```
[Overview] [Targeting] [Variations] [Schedule] [Live] [History]
```

Each tab click: `hx-get="/flags/{key}/tab/{tab_name}"` → swaps `#flag-tab-content`

#### Overview tab

- 4 stat cards: Total evals (24h) | Unique contexts | Top variant | Health verdict
- Variation bar chart: pure CSS width-based bars, HTMX polls `/api/flags/{key}/stats`
  every 30s
- Reasons breakdown: same bar pattern for RULE_MATCH / FALLTHROUGH / TARGET_MATCH / OFF
- Time range selector: 1h | 24h | 7d | 30d (updates both sections)
- Flag metadata section: key, type, created, maintainer, tags, temporary flag, prerequisites

#### Targeting tab

Three sections:

**Prerequisites section**
- List of prerequisite flags with required variation
- `[+ Add prerequisite]` → modal with flag key input + variation select
- `[✕ remove]` per prerequisite

**Individual Targets section**
- Per variation: tag-style input list of context keys
- `[+ add key]` inline — appends a new chip
- `[✕]` on each chip to remove

**Rules section (core of targeting tab)**
- Drag-to-reorder via HTML5 drag events + `hx-post` on drop
- Each rule card: description | clause builder | serve variation | `[▾]` | `[✕]`
- Clause builder per rule:
  - `[attribute input]` `[operator select]` `[values input]`
  - `negate` checkbox
  - `[+ AND clause]` to add another clause
- Serve: `[variation select]` OR `[rollout sliders]` (toggle between modes)
- Rollout sliders: `<input type="range">` per variation, weights auto-normalize to 100%
- `[+ Add Rule]` appends new empty rule card

**Default Rule section**
- Radio: Fixed variation | Percentage rollout
- Fixed: variation select
- Rollout: sliders per variation
- Off variation select (separate — served when flag is globally disabled)
- `[Save Targeting]` button: `hx-put` to `/api/flags/{key}/rules` + `/api/flags/{key}/fallthrough`

#### Variations tab

Table: Name | Value | Description | `[✕ remove]`
- Inline edit for name, value, description
- `[+ Add variation]` appends row
- `[Save]`: `hx-put` to `/api/flags/{key}/variations`
- JSON type: value column uses `<textarea>` with monospace font

#### Schedule tab

Timeline list of pending scheduled changes (sorted by `execute_at`):
- Each entry: datetime | action description | created by | `[Cancel]` button
- `[+ Schedule Change]` → modal with: Action select | Date | Time | Timezone
- Cancel: `hx-delete` to `/api/flags/{key}/scheduled/{id}`

#### Live Events tab

SSE stream using existing `htmx-ext-sse`:

```html
<div hx-ext="sse"
     sse-connect="/api/flags/{key}/stream"
     sse-swap="message"
     hx-swap="afterbegin"
     id="live-events-feed">
</div>
```

- Scrolling table, newest on top, max 200 rows (JS trims oldest)
- Columns: Time | Context key | Variation | Reason | Rule (if RULE_MATCH)
- Click row → expand drawer showing full evaluation context attributes
- `[Pause]` button: toggles SSE connection disconnect/reconnect
- `[Clear]` button: empties the feed
- Connection status indicator: `● Connected` (green) / `○ Reconnecting...` (amber)

#### History tab

Same `audit_rows.html` partial, filtered to `resource_type=flag AND resource_key={key}`.
Extended with diff rendering: show `previous_value → new_value` inline below each entry.

### Page: Segments (`segments.html`)

Columns: Key | Name | Rules count | Members count | Used by (flag count)

- Create Segment button → modal
- Click row → segment detail modal (or sub-page for complex segments)

Segment detail:
- Included keys: chip list + `[+ add]` input
- Excluded keys: chip list + `[+ add]` input
- Rules: same clause builder as flag targeting, simplified (no variation — just inclusion)
- `[Save]` → `hx-patch` to `/api/segments/{key}`

### Eval Debugger Modal (`modal_flag_eval.html`)

Triggered by `[Eval]` button on each row in the flags list.

Form:
- Context key input (required)
- Kind select (`user`, `organization`, `device`, custom)
- Named attributes: email, ip, country, app_version (optional)
- `[+ attribute]` to add arbitrary key/value pairs

`[Evaluate]` button: `hx-post` to `/api/flags/{key}/evaluate` → swaps result section:

```
Result:     true
Variation:  on
Reason:     RULE_MATCH
Rule:       "Pro and admin users" (rule_abc123)
```

Error case (flag not found, provider error) shows red alert with `error_message`.

---

## 16. Metrics and Observability

File: `switchly/core/feature_flags/metrics.py`

### FlagMetricsCollector

Stores rolling time-series bucketed by flag key, variation, and reason.
Buckets: 1-minute slots, retained for 30 days in Redis, 24h in Memory/File.

```python
class FlagEvalRecord(TypedDict):
    variation: str
    reason: str
    context_key: str
    timestamp: datetime

class FlagMetricsCollector:
    async def record(self, flag_key: str, record: FlagEvalRecord) -> None: ...
    async def get_stats(
        self, flag_key: str, window: timedelta
    ) -> dict[str, int]: ...  # variation → count
    async def get_reason_stats(
        self, flag_key: str, window: timedelta
    ) -> dict[str, int]: ...  # reason → count
    async def get_unique_contexts(
        self, flag_key: str, window: timedelta
    ) -> int: ...
    async def get_last_evaluated(self, flag_key: str) -> datetime | None: ...
```

`MetricsHook` calls `collector.record()` after every evaluation.
The dashboard polls `/api/flags/{key}/stats` every 30s via HTMX.

### Flag status auto-derivation

Status is computed from metrics + configuration, not stored:

```python
def compute_flag_status(flag: FeatureFlag, collector: FlagMetricsCollector) -> FlagStatus:
    age = (now - flag.created_at).days
    days_since_eval = (now - last_eval).days if last_eval else None
    days_since_config_change = (now - flag.updated_at).days

    if not flag.enabled and days_since_eval and days_since_eval > 7:
        return FlagStatus.INACTIVE
    if age < 7 and not last_eval:
        return FlagStatus.NEW
    if last_eval and days_since_eval <= 7 and serving_single_variation:
        return FlagStatus.LAUNCHED
    return FlagStatus.ACTIVE
```

---

## 17. Segments

File: `switchly/core/feature_flags/segments.py`

Segments are stored in `SwitchlyBackend` alongside flags.
`FlagEvaluator` receives a preloaded `dict[str, Segment]` on init.

Evaluation order within a segment:
1. If `context.key` in `excluded` → not in segment
2. If `context.key` in `included` → in segment
3. Evaluate `rules` top-to-bottom — if any rule matches → in segment

Segments are referenced in flag rules via `Operator.IN_SEGMENT` /
`Operator.NOT_IN_SEGMENT` clauses with the segment key as value.

Backend storage key convention:
- Flags: `switchly:flag:{key}`
- Segments: `switchly:segment:{key}`

Pub/sub channel for segment changes:
- Same channel as flag changes: `switchly:flags:events`
- Event type: `segment_updated`

---

## 18. Scheduled Flag Changes

File: `switchly/core/feature_flags/scheduler.py`

Modeled after the existing `switchly/core/scheduler.py` (MaintenanceScheduler).

```python
class FlagScheduler:
    """Background task that fires scheduled flag changes at their execute_at time.
    Survives restarts by restoring pending changes from backend on startup."""

    async def start(self) -> None: ...    # called by SwitchlyRouter/SwitchlyAdmin startup
    async def stop(self) -> None: ...     # called on shutdown
    async def _loop(self) -> None:
        # Polls every 30 seconds
        # For each flag with pending scheduled changes:
        #   If change.execute_at <= now: apply change + remove from flag
        #   Write updated flag to backend
        #   Fire webhook for the change
        ...
```

Supported actions:
- `enable` — set `flag.enabled = True`
- `disable` — set `flag.enabled = False`
- `update_rollout` — update fallthrough weights
- `add_rule` — append a rule to `flag.rules`
- `delete_rule` — remove rule by `rule_id`

---

## 19. Flag Health and Stale Detection

File: `switchly/core/feature_flags/health.py`

```python
class FlagHealthVerdict(StrEnum):
    HEALTHY         = "healthy"
    MONITOR         = "monitor"        # watch — may be stale soon
    SAFE_TO_ARCHIVE = "safe_to_archive"
    SAFE_TO_REMOVE  = "safe_to_remove"

class FlagHealthReport(BaseModel):
    flag_key: str
    status: FlagStatus
    verdict: FlagHealthVerdict
    reason: str                        # human explanation
    days_since_created: int
    days_since_last_eval: int | None
    days_since_last_config_change: int
    serving_single_variation: bool
    is_prerequisite: bool              # true if another flag depends on this one
    total_evals_last_7d: int
```

### Verdict logic

```
SAFE_TO_REMOVE  when ALL:
  - temporary=True
  - created >30 days ago
  - status is LAUNCHED or INACTIVE for >7 days
  - not a prerequisite for any other flag
  - serving only one variation

SAFE_TO_ARCHIVE when ALL:
  - temporary=True
  - created >30 days ago
  - status is INACTIVE for >7 days
  - is a prerequisite for another flag (can't remove yet)

MONITOR when ANY:
  - temporary=True AND created >60 days ago AND status=ACTIVE
  - last evaluated >3 days ago but <7 days ago

HEALTHY otherwise
```

---

## 20. Live Events Stream

SSE endpoint: `GET /api/flags/{key}/stream` (or `/api/flags/stream` for all)

Each evaluation emits an SSE event via an in-memory asyncio queue.
`MetricsHook.after()` pushes to the queue.
The SSE endpoint reads from the queue and streams to connected clients.

```python
# Event payload per evaluation
{
    "flag_key":      "new_checkout",
    "value":         true,
    "variation":     "on",
    "reason":        "RULE_MATCH",
    "rule_id":       "rule_abc123",
    "context_key":   "user_99",
    "context_kind":  "user",
    "context_attrs": {"role": "admin", "plan": "pro"},
    "timestamp":     "2026-03-21T14:32:01Z"
}
```

Per-flag streams filter to only that flag's events.
Max 10 concurrent SSE connections per flag (configurable).
Events not buffered for disconnected clients — purely live.

Dashboard uses `htmx-ext-sse` (already loaded in `base.html`):

```html
<div hx-ext="sse"
     sse-connect="{{ prefix }}/api/flags/{{ flag_key }}/stream"
     sse-swap="message"
     hx-swap="afterbegin"
     id="live-events-feed">
</div>
```

---

## 21. Eval Debugger

`POST /api/flags/{key}/evaluate` accepts an `EvaluationContext` body.
Runs the full `FlagEvaluator.evaluate()` call with no side effects
(does not increment metrics counters — dry-run only).
Returns `ResolutionDetails` including `rule_id` and `prerequisite_key`.

Both the dashboard modal and the CLI `switchly flags eval` command use this endpoint.

---

## 22. pyproject.toml Changes

```toml
[project.optional-dependencies]
# existing extras unchanged...
flags = [
    "openfeature-sdk>=0.8",
    "packaging>=23.0",
]
all = [
    # existing...
    "openfeature-sdk>=0.8",
    "packaging>=23.0",
]
dev = [
    # existing...
    "openfeature-sdk>=0.8",
    "packaging>=23.0",
]
```

`packaging` is already a transitive dependency of many packages.
If already present, pip uses the existing installation — no extra overhead.

---

## 23. Test Conventions

Follow all existing test conventions plus the following:

### Test location

```
tests/
└── core/
    └── feature_flags/
        ├── test_models.py          # model validation
        ├── test_evaluator.py       # FlagEvaluator (no I/O, no async — pure unit tests)
        ├── test_provider.py        # SwitchlyOpenFeatureProvider (parametrized over backends)
        ├── test_client.py          # SwitchlyFeatureClient + hook ordering
        ├── test_metrics.py         # FlagMetricsCollector
        ├── test_health.py          # FlagHealthChecker verdicts
        ├── test_scheduler.py       # FlagScheduler (anyio clock mock)
        └── test_segments.py        # segment evaluation logic

tests/
└── fastapi/
    └── test_feature_flags.py       # @feature_flag decorator + Depends integration

tests/
└── admin/
    └── test_flag_api.py            # REST API endpoints (httpx AsyncClient + ASGITransport)

tests/
└── cli/
    └── test_flags_cli.py           # CLI commands (sync def, CliRunner + patch make_client)
```

### Key gotchas

- `test_evaluator.py` tests are **sync**, **pure** — `FlagEvaluator` has no async methods
- Provider tests are **async**, parametrized over `["memory", "file", "redis"]`,
  same pattern as existing backend tests
- CLI tests must be `def` (not `async def`) — same reason as existing CLI tests
- Eval debugger tests mock `MetricsHook` to confirm dry-run does not record metrics
- When `openfeature-sdk` is not installed, import of `switchly.core.feature_flags`
  must raise `ImportError` with a clear message — test this explicitly

### Skip guard for missing dependency

```python
# conftest.py or per test module
pytest.importorskip("openfeature", reason="switchly[flags] not installed")
```

---

## 24. Implementation Order

Build in this order — each phase is independently shippable and tested.

### Phase 1 — Core evaluation (no UI, no API)

1. `switchly/core/feature_flags/models.py` — all data models
2. `switchly/core/feature_flags/evaluator.py` — `FlagEvaluator` (pure)
3. `switchly/core/feature_flags/segments.py` — segment eval helpers
4. `switchly/core/feature_flags/__init__.py` — import facade + `_require_flags()`
5. `switchly/core/feature_flags/_guard.py` — guard helper
6. `pyproject.toml` — add `flags` extra
7. **Tests:** `test_evaluator.py`, `test_segments.py`, `test_models.py`

### Phase 2 — Provider and client

8. `switchly/core/feature_flags/provider.py` — `SwitchlyOpenFeatureProvider`
9. `switchly/core/feature_flags/client.py` — `SwitchlyFeatureClient`
10. `switchly/core/feature_flags/hooks.py` — `LoggingHook`, `AuditHook`
11. `switchly/core/engine.py` — `engine.use_openfeature()` method
12. `switchly/fastapi/router.py` — auto-initialize/shutdown provider on startup/shutdown
13. **Tests:** `test_provider.py`, `test_client.py`

### Phase 3 — REST API

14. `switchly/core/feature_flags/metrics.py` — `FlagMetricsCollector`
15. `switchly/core/feature_flags/hooks.py` — `MetricsHook`
16. `switchly/admin/api.py` — flag + segment REST endpoints
17. `switchly/admin/app.py` — mount flag routes when `enable_flags=True`
18. `switchly/server/__init__.py` — `enable_flags` param on `SwitchlyServer`
19. **Tests:** `test_flag_api.py`

### Phase 4 — CLI

20. `switchly/cli/main.py` — `switchly flags` + `switchly segments` subcommand groups
21. **Tests:** `test_flags_cli.py`

### Phase 5 — Dashboard

22. `switchly/dashboard/templates/flags.html` — flag list page
23. `switchly/dashboard/templates/partials/flag_row.html`
24. `switchly/dashboard/templates/partials/modal_flag_create.html`
25. `switchly/dashboard/templates/partials/modal_flag_eval.html`
26. `switchly/dashboard/templates/flag_detail.html` — with sub-tab routing
27. `switchly/dashboard/templates/partials/flag_rules_panel.html`
28. `switchly/dashboard/templates/partials/flag_stat_bars.html`
29. `switchly/dashboard/templates/partials/flag_event_row.html` — SSE row
30. `switchly/dashboard/templates/partials/flag_schedule_panel.html`
31. `switchly/dashboard/templates/partials/flag_history_panel.html`
32. `switchly/dashboard/templates/segments.html`
33. `switchly/dashboard/templates/partials/segment_row.html`
34. `switchly/dashboard/templates/partials/modal_segment_detail.html`
35. `switchly/dashboard/routes.py` — flag + segment dashboard routes
36. `base.html` — Flags + Segments nav tabs

### Phase 6 — Scheduling and health

37. `switchly/core/feature_flags/scheduler.py` — `FlagScheduler`
38. `switchly/core/feature_flags/health.py` — `FlagHealthChecker`
39. Wire scheduler into `SwitchlyAdmin`/`SwitchlyServer` startup
40. Add `/api/flags/health` and `/api/flags/{key}/health` endpoints
41. Dashboard health tab + flags list health badge
42. CLI `switchly flags health` command
43. **Tests:** `test_scheduler.py`, `test_health.py`

### Phase 7 — Switchly Server design

44. `switchly/sdk/__init__.py` — `SwitchlySDK.use_openfeature()` method
45. `SwitchlyServerBackend` SSE — extend to carry flag change events
46. `SwitchlySDKFlagProvider` — syncs flags from Switchly Server on startup,
    hot-reloads via SSE, pushes metrics periodically
47. `switchly/server/__init__.py` — flag metrics push endpoint
48. **Tests:** integration tests for SDK + Server flag sync

### Phase 8 — Live events stream

49. In-memory asyncio queue per flag + global queue
50. `MetricsHook` pushes to queue
51. `GET /api/flags/{key}/stream` SSE endpoint
52. Dashboard Live Events tab wiring
53. CLI `switchly flags stream` command

---

## Summary

| Component | New files | Modified files |
|---|---|---|
| Core models | `feature_flags/models.py` | — |
| Evaluation engine | `feature_flags/evaluator.py`, `segments.py` | — |
| Provider | `feature_flags/provider.py` | — |
| Client | `feature_flags/client.py` | `core/engine.py` |
| Hooks | `feature_flags/hooks.py` | `fastapi/router.py` |
| Metrics | `feature_flags/metrics.py` | — |
| Health | `feature_flags/health.py` | — |
| Scheduler | `feature_flags/scheduler.py` | `admin/app.py` |
| Facade | `feature_flags/__init__.py` | — |
| Decorator | — | `fastapi/decorators.py` |
| REST API | — | `admin/api.py`, `admin/app.py` |
| CLI | — | `cli/main.py` |
| Dashboard | 14 new templates | `base.html`, `dashboard/routes.py` |
| Switchly Server | — | `server/__init__.py`, `sdk/__init__.py` |
| Dependency | — | `pyproject.toml` |
| Tests | ~12 new test files | `conftest.py` |

Estimated new code: ~2,500–3,000 lines across all phases.
All phases are independently releasable and testable.
Zero impact on applications that do not install `switchly[flags]`.
