## Dashboard Responsiveness & Tailwind v4 Migration

### Summary

- All four dashboard tables (Routes, Audit, Rate Limits, Blocked) are now fully responsive — they transform into stacked cards on mobile/tablet screens using a CSS-only approach with `data-label` attributes. No JS, no layout shifts.
- Action buttons collapse to icon-only on small screens; labels reappear at `sm:` and above.
- Two-row header on mobile: brand/auth row on top, nav tabs row below with full-width tap targets.
- Added a back-to-top button (bottom-right, appears after 200 px scroll) and success toast notifications after any mutating action (enable, disable, maintenance, rate limit edits).
- Migrated from Tailwind CDN to a pre-built local stylesheet (`switchly.min.css`) eliminating the production warning and the runtime CDN dependency.
- Upgraded Tailwind CSS v3 → v4. Config moved from `tailwind.config.js` into `input.css` (`@import "tailwindcss"`, `@source`, `@theme`). `tailwind.config.js` removed.
- CI gains a `css` job that rebuilds `switchly.min.css` and fails the PR if the committed file is stale.
- `CONTRIBUTING.md` and `docs/contributing.md` updated with the developer CSS workflow.
- Changelog `[Unreleased]` section updated.

### Files changed

| Area | Change |
|---|---|
| `switchly/dashboard/templates/base.html` | Responsive header, mobile card CSS, toast + back-to-top HTML/CSS/JS, local CSS `<link>` |
| `switchly/dashboard/templates/partials/route_row.html` | `data-label` attributes, icon-only button wrappers |
| `switchly/dashboard/templates/partials/audit_row.html` | `data-label` attributes |
| `switchly/dashboard/templates/partials/rate_limit_rows.html` | `data-label` attributes |
| `switchly/dashboard/templates/partials/rate_limit_hits.html` | `data-label` attributes |
| `switchly/dashboard/templates/login.html` | Switched from CDN script to local CSS link |
| `switchly/dashboard/static/switchly.min.css` | Rebuilt with Tailwind v4 |
| `input.css` | New — v4 CSS config (`@import`, `@source`, `@theme`) |
| `package.json` | `@tailwindcss/cli@^4`, updated build scripts |
| `tailwind.config.js` | Deleted (v4 uses CSS config) |
| `.github/workflows/ci.yml` | Added `css` job |
| `CONTRIBUTING.md` | CSS workflow section |
| `docs/contributing.md` | CSS workflow section |
| `docs/changelog.md` | `[Unreleased]` entries |
