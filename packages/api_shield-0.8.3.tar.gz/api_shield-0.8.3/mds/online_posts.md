# Online Posts

---

## Reddit — r/Python

**Title:** switchly — application-level API control for ASGI frameworks, no redeployment needed

---

There is no complete library for managing API lifecycle at the application level in ASGI frameworks, so I built one.

**switchly** gives you per-route control over maintenance windows, environment gating, deprecation, rate limiting, canary rollouts, and feature flags — all at runtime, without redeploying. FastAPI is fully supported today, more adapters are on the roadmap.

The core engine has zero framework dependencies. The FastAPI adapter is a thin layer on top of it.

---

### What it covers

**Per-route maintenance windows** — put one endpoint in maintenance while every other route keeps serving. Schedule windows in advance and they activate/deactivate automatically.

**Environment gating** — routes decorated with `@env_only("dev")` return 404 in production (not 403 — you probably don't want to advertise the route exists). Hidden from OpenAPI docs in the wrong environment too.

**Deprecation headers** — `@deprecated` injects `Deprecation`, `Sunset`, and `Link` RFC headers automatically. Route keeps working, clients get the signal to migrate.

**Rate limiting** — per-IP, per-user, per-API-key, or global shared counters. Fixed window, sliding window, moving window. Tiered limits by subscription plan. Exempt specific IPs or roles. One decorator.

**Canary rollouts** — `@rollout(percentage=10)` sends 10% of traffic to the route. Adjust the percentage at runtime without touching code.

**Feature flags** — built-in flag engine with an OpenFeature-compatible client. Boolean, string, integer, float, and JSON flag types. Individual targeting, attribute-based rules, percentage rollout, and kill-switch. Flags share the same dashboard and CLI as everything else.

**Multiple services, one control plane** — run a standalone Switchly Server and connect multiple services to it via the SDK. Each service registers under its own namespace. Manage them independently or all at once from one dashboard and one CLI.

> Full examples: [github.com/Attakay78/switchly/tree/main/examples](https://github.com/Attakay78/switchly/tree/main/examples)

---

### Runtime control

Everything is controllable at runtime through three surfaces with no redeploy and no restart:

- **Dashboard** — mountable HTMX UI with live SSE updates. Route state, maintenance scheduling, audit log, flag management.
- **CLI** — `switchly status`, `switchly maintenance /api/payments --reason "DB migration"`, `switchly flags disable new-checkout`, `switchly services` and more.
- **REST API** — the same admin is also a REST API for integration with deployment pipelines and runbooks.

---


### Links

- GitHub: [github.com/Attakay78/switchly](https://github.com/Attakay78/switchly)
- Install: `pip install switchly`

Happy to answer questions about any of the supported features.
