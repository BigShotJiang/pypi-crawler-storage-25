# switchly Roadmap

> Route lifecycle management for FastAPI — maintenance mode, env gating, deprecation, and more.
>
> This roadmap reflects the current state of the project and the planned build stages.
> Each version is built and fully tested before the next begins.

---

## Project Summary

`switchly` is a **route lifecycle management library for FastAPI** that gives developers fine-grained, declarative control over individual API endpoints at runtime — no redeployment required.

Each route is a first-class entity with its own lifecycle: active, maintenance, disabled, env-gated, deprecated, or in a canary rollout — expressed through clean Python decorators that live next to the route definition.

The core engine is pure Python with zero framework dependencies. Framework-specific behaviour (FastAPI, future adapters) is handled by thin adapter layers.

---

## Architecture at a Glance

```
switchly/
├── core/           # Framework-agnostic engine, models, backends, scheduler
│   └── backends/   # Memory, File, Redis — all implement SwitchlyBackend ABC
├── fastapi/        # Adapter: middleware, decorators, router, OpenAPI filter
├── dashboard/      # HTMX admin UI (v0.3)
├── cli/            # Typer CLI (v0.2, complete)
└── adapters/       # Future framework adapters (Litestar, Flask — v0.4+)
```

**Invariants that never change:**
- `switchly.core` has zero FastAPI/Starlette imports
- All business logic lives in `SwitchlyEngine`
- `engine.check()` is the single chokepoint for every request
- Fail-open: backend errors are logged, requests always pass through

---

## Version History and Status

| Version | Theme              | Status        | Tests       |
|---------|--------------------|---------------|-------------|
| v0.1    | Core Foundation    | **Complete**  | Passing     |
| v0.2    | Operations Layer   | **Complete**  | 173 passing |
| v0.3    | Dashboard          | Planned       | —           |
| v0.4    | Advanced Features  | Planned       | —           |
| v0.5    | Polish & Release   | Planned       | —           |

---

## v0.1 — Core Foundation ✅

**Theme:** A working, installable library with the minimum useful feature set.

### Delivered

#### Core Models (`switchly/core/models.py`)
- `RouteStatus` — `StrEnum`: `active`, `maintenance`, `disabled`, `env_gated`, `deprecated`
- `MaintenanceWindow` — Pydantic v2 model with `start`, `end`, `reason`
- `RouteState` — full route configuration: status, reason, allowed_envs, allowed_ips, allowed_roles, rollout_percentage, sunset_date, successor_path, force_active
- `GlobalMaintenanceConfig` — global kill-switch configuration with exempt paths
- `AuditEntry` — immutable audit record: id, timestamp, path, action, actor, reason, old/new status

#### Exceptions (`switchly/core/exceptions.py`)
- `SwitchlyException` base
- `MaintenanceException` — carries reason and optional retry_after datetime
- `EnvGatedException` — carries path, current_env, allowed_envs
- `RouteDisabledException` — carries reason
- `RouteProtectedException` — raised when mutating a `force_active` route

#### Backends
- `SwitchlyBackend` ABC — full contract: `get_state`, `set_state`, `delete_state`, `list_states`, `write_audit`, `get_audit_log`, `subscribe`, `startup`, `shutdown`, `get_global_config`, `set_global_config`
- `MemoryBackend` — in-process dict, audit list capped at 1000, `subscribe()` via asyncio.Queue
- `FileBackend` — JSON/YAML/TOML on disk via aiofiles, asyncio.Lock for write safety, `subscribe()` raises NotImplementedError

#### Engine (`switchly/core/engine.py`)
- `SwitchlyEngine` — central orchestrator
- `check(path, method, context)` — single chokepoint, fail-open on backend errors
- `register(path, meta)` — called by SwitchlyRouter at startup; persistence-first (runtime state wins over decorator)
- `enable`, `disable`, `set_maintenance`, `set_env_only` — state mutations with full audit
- `get_state`, `list_states`, `get_audit_log` — read operations
- Global maintenance: `enable_global_maintenance`, `disable_global_maintenance`, `set_global_exempt_paths`
- `_audit()` — internal; writes `AuditEntry` after every state change
- `_fire_webhooks()` — fire-and-forget via `asyncio.create_task()`
- `add_webhook(url, formatter)` — register webhook handler
- Async context manager (`__aenter__`/`__aexit__`) for backend lifecycle

#### FastAPI Adapter
- `@maintenance(reason, start, end)` — stamps `__switchly_meta__`
- `@env_only(*envs)` — stamps `__switchly_meta__`
- `@disabled(reason)` — stamps `__switchly_meta__`
- `@force_active` — stamps `__switchly_meta__`; route becomes immutable
- `@deprecated(sunset, use_instead)` — stamps `__switchly_meta__`
- `SwitchlyRouter(APIRouter)` — drop-in replacement; scans `__switchly_meta__` at startup; registers all routes with engine
- `SwitchlyMiddleware(BaseHTTPMiddleware)` — ASGI middleware; intercepts every request; enforces route state; injects RFC headers on deprecated routes; sets `Retry-After` on maintenance responses; returns structured JSON errors
- `apply_switchly_to_openapi(app, engine)` — filters `/docs`, `/redoc`, OpenAPI schema at runtime: hides disabled/env-gated routes, marks deprecated routes

#### Error Response Format
```json
{
  "error": {
    "code": "MAINTENANCE_MODE",
    "message": "This endpoint is temporarily unavailable",
    "reason": "Database migration in progress",
    "path": "/api/payments",
    "retry_after": "2025-03-10T04:00:00Z"
  }
}
```

---

## v0.2 — Operations Layer ✅

**Theme:** Production-ready tooling for teams managing running systems.

### Delivered

#### Scheduler (`switchly/core/scheduler.py`)
- `MaintenanceScheduler` — asyncio.Task-based, no Celery or APScheduler
- `schedule(path, window)` — sleeps until `window.start`, activates maintenance, sleeps until `window.end`, re-enables
- `cancel(path)` — cancels the pending task
- `list_scheduled()` — returns all pending windows
- `restore_from_backend()` — on startup, reloads any scheduled windows that survived a restart
- Engine exposes `schedule_maintenance(path, window)` which delegates here

#### Redis Backend (`switchly/core/backends/redis.py`)
- `RedisBackend(url)` — production-ready, multi-instance-safe
- Key schema: `switchly:state:{path}` for route state, `switchly:audit` list capped at 1000 entries
- `subscribe()` via Redis pub/sub on `switchly:changes` channel
- `set_state()` publishes to `switchly:changes` after each write
- Connection pooling via `redis.asyncio.ConnectionPool`
- Graceful handling of connection errors (fail-open)

#### Webhooks (`switchly/core/webhooks.py`)
- `default_formatter(event, path, state)` — generic JSON payload
- `SlackWebhookFormatter` — Slack Block Kit message formatter
- `_fire_webhooks()` in engine: fires all registered URLs via `asyncio.create_task()`, never blocks the hot path, errors logged only

#### CLI (`switchly/cli/main.py`)
- `switchly status [route]` — rich table of all routes or detail for one
- `switchly enable <route>` — enable a route
- `switchly disable <route> [--reason TEXT] [--until DURATION]` — disable with optional expiry
- `switchly maintenance <route> [--reason TEXT] [--start DATETIME] [--end DATETIME]`
- `switchly schedule <route> --start DATETIME --end DATETIME [--reason TEXT]`
- `switchly global status / enable / disable / exempt-add / exempt-remove`
- `switchly log [--route ROUTE] [--limit INT]` — audit log table
- Config discovery: env vars → `--config` flag → `.switchly` file auto-discovery → defaults
- Custom backend support: `SWITCHLY_BACKEND=custom` + `SWITCHLY_CUSTOM_PATH=module:factory`

#### `@deprecated` Decorator
- Stamps `__switchly_meta__` with `status=DEPRECATED`, `sunset_date`, `successor_path`
- Middleware injects response headers without blocking the request:
  - `Deprecation: true`
  - `Sunset: <RFC 7231 date>`
  - `Link: </v2/endpoint>; rel="successor-version"` (when `use_instead` provided)
- OpenAPI filter marks route with `deprecated: true`

#### Additional Engine Capabilities
- Method-aware routing: `GET:/payments` and `POST:/payments` are independent
- `scan_routes(app, engine)` — standalone helper to register routes from a plain `APIRouter`
- Parameterized route support: `/items/{item_id}` matched via path template resolution
- Global maintenance with `include_force_active` override
- Custom OpenAPI docs UI: banner messages, status chips, maintenance overlays

---

## v0.3 — Dashboard (Next)

**Theme:** Visual admin UI for non-CLI users. Live state updates without polling.

### What to Build

#### `switchly/dashboard/app.py`
- `SwitchlyDashboard(engine, prefix="/switchly", auth=None)` — factory returning a Starlette app
- Drop-in mount: `app.mount("/switchly", SwitchlyDashboard(engine=engine))`
- Initializes Jinja2 templates and static files
- Passes engine via Starlette `state`
- No side effects on the parent FastAPI app beyond its mount prefix

#### `switchly/dashboard/auth.py`
- `BasicAuthMiddleware` — wraps dashboard when `auth=(username, password)` provided
- Returns `WWW-Authenticate` challenge on missing or wrong credentials

#### `switchly/dashboard/routes.py`

| Route | Method | Description |
|---|---|---|
| `/` | GET | Full route list page |
| `/routes` | GET | HTMX partial: routes table body only |
| `/toggle/{path:path}` | POST | Toggle active/maintenance; returns `route_row.html` partial |
| `/disable/{path:path}` | POST | Disable route; returns `route_row.html` partial |
| `/schedule` | POST | Set maintenance window from form; returns updated partial |
| `/schedule/{path:path}` | DELETE | Cancel scheduled window |
| `/audit` | GET | Full audit log page |
| `/audit/rows` | GET | HTMX partial: audit log rows only |
| `/events` | GET | SSE endpoint: streams `RouteState` changes as `text/event-stream` |

The SSE endpoint falls back to keepalive pings if the backend doesn't support `subscribe()`.

#### Templates (HTMX + Jinja2 + Tailwind CDN)

`base.html`:
- Loads Tailwind CSS from CDN
- Loads HTMX v2 from CDN
- Loads HTMX SSE extension
- Navigation: "Routes" | "Audit Log"
- Switchly header with version

`index.html`:
- Route table: Method, Path, Status badge, Reason, Environment, Actions
- Status badges — colour-coded: `ACTIVE`=green, `MAINTENANCE`=yellow, `DISABLED`=red, `ENV_GATED`=blue, `DEPRECATED`=grey
- Action buttons per row: Enable / Maintenance / Disable
- "Schedule Maintenance" modal (HTMX-powered, no page reload)
- SSE listener on the table: `hx-ext="sse" sse-connect="/switchly/events"`

`partials/route_row.html`:
- Single `<tr>` for one route
- `id="row-{path_slug}"` for HTMX `hx-swap="outerHTML"` targeting

`partials/audit_row.html`:
- Single `<tr>` for one audit entry
- Timestamp, Route, Action, Actor, Reason, Old → New status

Audit page:
- Auto-refreshes every 10 seconds via `hx-trigger="every 10s"`

### Acceptance Criteria
- [ ] `app.mount("/switchly", SwitchlyDashboard(engine=engine))` works
- [ ] Dashboard renders all routes with correct status badges
- [ ] Toggling a route in the UI updates that row without a page reload
- [ ] Scheduling a maintenance window via UI form works end-to-end
- [ ] Audit log shows last 50 entries, auto-refreshes every 10s
- [ ] SSE: state change in one browser tab reflects in another within 1 second
- [ ] Basic auth blocks the dashboard when credentials are configured
- [ ] Dashboard routes do not appear in the parent app's OpenAPI schema
- [ ] All dashboard tests pass

---

## v0.4 — Advanced Features

**Theme:** Power features that differentiate switchly from everything else.

### What to Build

#### `@rollout(percentage, env)` Decorator
- `@rollout(percentage=10, env="production")`
- On each request: draw a random float 0–100; if value > percentage → 503
- Rollout only active in the target env; other envs pass through normally
- `rollout_percentage` stored in `RouteState`, changeable at runtime via engine/CLI/dashboard

#### IP and Role Allowlisting
- `RouteState.allowed_ips` — CIDR notation supported (`"10.0.0.0/24"`)
- `RouteState.allowed_roles` — checked against `request.state.user_roles` if set
- In `engine.check()`: if route is `MAINTENANCE` but request IP is in `allowed_ips` → allow through
- In `engine.check()`: if route is `MAINTENANCE` but request has an allowed role → allow through
- Use `ipaddress` stdlib for CIDR matching
- Update `@maintenance()` to accept `allow_ips` and `allow_roles`

#### Dependency-Aware Warnings
- At startup, `SwitchlyRouter` builds a dependency graph from FastAPI `Depends()` declarations
- Disabling a route that other routes depend on emits a warning:
  `WARNING: Disabling /api/auth will affect 3 dependent routes: /api/payments, /api/orders, /api/users`
- Warning only — does not block the disable operation
- `engine.get_dependents(path) -> list[str]`

#### Multi-Instance State Sync (Non-Redis)
- `FileBackend`: optional file watcher via `asyncio` + `os.stat` polling in executor
- External writes (another process, CLI) trigger state reload + SSE notification
- Allows CLI-dashboard roundtrip on file-backed deployments without Redis

#### Litestar Adapter (`switchly/adapters/litestar/`)
- `SwitchlyGuard` — implements Litestar's `Guard` interface, calls `engine.check()`
- `SwitchlyController` — equivalent of `SwitchlyRouter` for Litestar
- Reuses existing decorators unchanged (they are framework-agnostic metadata stamps)
- Adapter passes the same integration test suite as the FastAPI adapter

#### Enhanced CLI
- `switchly watch` — live-updating route table, refreshes every 2 seconds
- `switchly webhooks add/list/remove` — manage registered webhooks
- `switchly export` — dump all current state to JSON
- `switchly import <file>` — restore state from JSON export

### Acceptance Criteria
- [ ] `@rollout(percentage=10)` passes ~10% of requests (validated over 1000 requests, 8–12% pass)
- [ ] IP allowlisting: request from allowed IP bypasses maintenance mode
- [ ] Role allowlisting: request with allowed role bypasses maintenance mode
- [ ] Dependency warning fires when a depended-upon route is disabled
- [ ] Litestar adapter passes full integration test suite
- [ ] `switchly watch` refreshes terminal table every 2 seconds

---

## v0.5 — Polish and Release

**Theme:** Make this something developers are proud to depend on.
The docs theme colour should be #F59E0B
Consider light and dark mode themes

### What to Build

#### Documentation Site (MkDocs Material)
- `docs/index.md` — overview and 30-second quickstart
- `docs/features.md` - all the powerful features this package provides
- `docs/tutorial/` — installation → first decorator → middleware → backends → dashboard and any other features in the application
- `docs/reference/` — full API reference auto-generated from docstrings via `mkdocstrings`
- `docs/adapters/` — FastAPI guide, "Building Your Own Adapter"
- `docs/changelog.md`

#### README Overhaul
<!-- - Animated GIF of the dashboard UI -->
- Badges: PyPI version, Python versions, test coverage, license
- 10-line quickstart that runs without modification
- Comparison table vs existing tools
- Link to full docs site

#### Type Completeness
- 100% of public API typed
- `mypy --strict` passes with zero errors
- `py.typed` marker present for PEP 561

<!-- #### Performance Benchmarks
- `engine.check()` with MemoryBackend: < 0.1ms overhead per request
- `engine.check()` with RedisBackend: < 2ms overhead per request (local Redis)
- Benchmarks run in CI, results stored in `benchmarks/results.json` -->

<!-- #### Security Hardening
- Dashboard: CSRF token on all POST/DELETE forms
- Dashboard: `Content-Security-Policy` header
- Dashboard: no sensitive data (Redis passwords, internal paths) in HTML source
- CLI: no secrets written to shell history or logs -->

#### PyPI Release
- `pyproject.toml` fully filled: classifiers, keywords, project URLs
- GitHub Actions CI: Python 3.10 / Python 3.11 / 3.12 / 3.13 × Linux / macOS / Windows
- GitHub Actions release workflow: git tag → build → publish to PyPI
- `CHANGELOG.md` in Keep a Changelog format

### Acceptance Criteria
<!-- - [ ] `pip install switchly` installs cleanly on Python 3.10 3.11, 3.12, 3.13 -->
- [ ] `mypy --strict switchly/` exits 0
<!-- - [ ] MemoryBackend benchmark: < 0.1ms per `check()` call
- [ ] RedisBackend benchmark: < 2ms per `check()` call -->
- [ ] Documentation site deployed and publicly accessible
<!-- - [ ] Package published to PyPI -->

---

<!-- ## Feature Matrix

| Feature | v0.1 | v0.2 | v0.3 | v0.4 | v0.5 |
|---|:---:|:---:|:---:|:---:|:---:|
| `@maintenance` decorator | ✅ | | | | |
| `@env_only` decorator | ✅ | | | | |
| `@disabled` decorator | ✅ | | | | |
| `@force_active` decorator | ✅ | | | | |
| `@deprecated` decorator | | ✅ | | | |
| `@rollout` decorator | | | | ✅ | |
| MemoryBackend | ✅ | | | | |
| FileBackend (JSON/YAML/TOML) | ✅ | | | | |
| RedisBackend | | ✅ | | | |
| SwitchlyMiddleware (ASGI) | ✅ | | | | |
| SwitchlyRouter | ✅ | | | | |
| OpenAPI / Docs filtering | ✅ | | | | |
| Global maintenance mode | ✅ | | | | |
| Maintenance scheduler | | ✅ | | | |
| Webhooks (generic + Slack) | | ✅ | | | |
| CLI (`switchly` command) | | ✅ | | | |
| HTMX Dashboard | | | ✅ | | |
| SSE live updates | | | ✅ | | |
| Dashboard basic auth | | | ✅ | | |
| IP/role allowlisting | | | | ✅ | |
| Dependency-aware warnings | | | | ✅ | |
| `@rollout` canary | | | | ✅ | |
| Litestar adapter | | | | ✅ | |
| Docs site | | | | | ✅ |
| PyPI release | | | | | ✅ |
| Type completeness (mypy strict) | | | | | ✅ |
| Performance benchmarks | | | | | ✅ |

--- -->
<!-- 
## Request Lifecycle (for reference)

```
Incoming HTTP request
        │
        ▼
SwitchlyMiddleware.dispatch(request)
        │
        ├── path is /switchly/, /docs, /redoc, /openapi.json? → skip → call_next ✅
        │
        ├── route has force_active? AND global maintenance not overriding? → skip → call_next ✅
        │
        ▼
engine.check(path, method, context)
        │
        ├── global maintenance enabled?
        │       └── path exempt or force_active (without override)? → call_next ✅
        │       └── otherwise → 503 MAINTENANCE_MODE 🔴
        │
        ▼
backend.get_state(path)   ← single async read
        │
        ├── ACTIVE          → call_next(request)                              ✅
        ├── MAINTENANCE     → JSONResponse 503 + Retry-After header           🔴
        ├── DISABLED        → JSONResponse 503                                🔴
        ├── ENV_GATED       → JSONResponse 404 (silent, path not revealed)    🔴
        ├── DEPRECATED      → call_next + inject Deprecation/Sunset headers   ⚠️
        └── backend error   → log + call_next (fail-open)                     ✅
``` -->

---

<!-- ## Backend Contract (for custom implementations)

```python
class SwitchlyBackend(ABC):
    async def get_state(self, path: str) -> RouteState: ...
    async def set_state(self, path: str, state: RouteState) -> None: ...
    async def delete_state(self, path: str) -> None: ...
    async def list_states(self) -> list[RouteState]: ...
    async def write_audit(self, entry: AuditEntry) -> None: ...
    async def get_audit_log(self, path: str | None, limit: int) -> list[AuditEntry]: ...
    async def subscribe(self) -> AsyncIterator[RouteState]: ...  # raise NotImplementedError if unsupported
    async def startup(self) -> None: ...   # optional lifecycle hook
    async def shutdown(self) -> None: ...  # optional lifecycle hook
    async def get_global_config(self) -> GlobalMaintenanceConfig: ...
    async def set_global_config(self, config: GlobalMaintenanceConfig) -> None: ...
```

A custom backend example (SQLite) lives in `examples/fastapi/custom_backend/sqlite_backend.py`. -->
