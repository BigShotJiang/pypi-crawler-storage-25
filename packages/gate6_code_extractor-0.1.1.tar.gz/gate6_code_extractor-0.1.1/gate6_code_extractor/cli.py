#!/usr/bin/env python3
"""
gate6-code-extractor

Monolith module extraction for Flask-RESTful / Python projects.

Removes all .py files under --src-root that are NOT directly or transitively
reachable from the target module set, while preserving startup chain safety.

The ONLY permitted changes are:
  1. Deleting unreachable .py files entirely.
  2. When --prune-routes is set: removing non-target api.add_resource() lines
     and their now-unused import lines from the route file.

No content inside a kept file is ever modified, rewritten, or optimised.
Every kept file is byte-for-byte identical to the original.

---------------------------------------------------------------------------
TWO WAYS TO SPECIFY WHAT TO KEEP
---------------------------------------------------------------------------

Option A — by API endpoint URLs (recommended: you know your endpoints):

  gate6-code-extractor \\
      --endpoints /customer_payment_list_app /customer_invoice_list_app \\
      --prune-routes --remove-unused-imports --dry-run --no-entry-prompt

  gate6-code-extractor \\
      --endpoint-pattern ".*_app$" \\
      --prune-routes --remove-unused-imports --dry-run --no-entry-prompt

Option B — by source folder paths (if you know the code structure):

  gate6-code-extractor \\
      --targets src/controllers/appCustomers \\
      --prune-routes --remove-unused-imports --dry-run --no-entry-prompt

Tip: run --list-endpoints first to discover all available endpoint URLs.

  gate6-code-extractor --list-endpoints --src-root src

---------------------------------------------------------------------------
"""

import ast
import re
import sys
import argparse
import subprocess
import datetime
from pathlib import Path
from collections import deque
from typing import Dict, Set, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

_log_lines: List[str] = []


def log(tag: str, message: str) -> None:
    line = f"[{tag}] {message}"
    print(line)
    _log_lines.append(line)


def flush_log(log_dir: Path, run_number: int) -> Path:
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"cleanup_run_{run_number:03d}.log"
    log_path.write_text("\n".join(_log_lines) + "\n", encoding="utf-8")
    return log_path


def next_run_number(log_dir: Path) -> int:
    if not log_dir.exists():
        return 1
    existing = sorted(log_dir.glob("cleanup_run_*.log"))
    if not existing:
        return 1
    try:
        return int(existing[-1].stem.split("_")[-1]) + 1
    except ValueError:
        return len(existing) + 1


# ---------------------------------------------------------------------------
# Module <-> file resolution
# ---------------------------------------------------------------------------

def file_to_module(file_path: Path, src_root: Path) -> Optional[str]:
    try:
        rel = file_path.relative_to(src_root)
    except ValueError:
        return None
    parts = list(rel.parts)
    if not parts:
        return None
    if parts[-1] == "__init__.py":
        parts = parts[:-1]
    elif parts[-1].endswith(".py"):
        parts[-1] = parts[-1][:-3]
    else:
        return None
    return ".".join(parts) if parts else None


def module_to_file(module_name: str, src_root: Path) -> Optional[Path]:
    parts = module_name.split(".")
    as_file = src_root.joinpath(*parts).with_suffix(".py")
    if as_file.exists():
        return as_file
    as_pkg = src_root.joinpath(*parts, "__init__.py")
    if as_pkg.exists():
        return as_pkg
    return None


# ---------------------------------------------------------------------------
# Import graph (AST-based)
# ---------------------------------------------------------------------------

# Names/attributes that indicate runtime file/module loading which AST cannot
# trace statically. When detected we conservatively keep all sibling .py files
# in the same directory so runtime-loaded files are never deleted.
_DYNAMIC_IMPORT_NAMES = frozenset({
    "__import__",
    "SourceFileLoader",
    "import_module",
    "spec_from_file_location",
    "load_source",           # imp.load_source (legacy)
    "load_module",
    "exec_module",
})


def _uses_dynamic_imports(tree: ast.AST) -> bool:
    """Return True if the file uses runtime import patterns AST cannot trace."""
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and node.id in _DYNAMIC_IMPORT_NAMES:
            return True
        if isinstance(node, ast.Attribute) and node.attr in _DYNAMIC_IMPORT_NAMES:
            return True
    return False


def parse_imports(file_path: Path, src_root: Path) -> Set[Path]:
    try:
        source = file_path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(file_path))
    except SyntaxError:
        return set()

    current_module = file_to_module(file_path, src_root) or ""
    # For __init__.py files the file IS the package, so relative imports like
    # `from .auth import X` must resolve against the package itself, not its parent.
    # e.g. quickbooksold/__init__.py  →  current_pkg = "quickbooksold"
    # For regular module files the current package is the parent.
    # e.g. quickbooksold/client.py   →  current_pkg = "quickbooksold"
    if file_path.name == "__init__.py":
        current_pkg = current_module
    else:
        pkg_parts = current_module.rsplit(".", 1)
        current_pkg = pkg_parts[0] if len(pkg_parts) > 1 else ""

    imported: Set[Path] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                resolved = module_to_file(alias.name, src_root)
                if resolved:
                    imported.add(resolved)

        elif isinstance(node, ast.ImportFrom):
            if node.module is None:
                continue
            if node.level == 0:
                module_name = node.module
            elif node.level == 1:
                module_name = f"{current_pkg}.{node.module}" if current_pkg else node.module
            elif node.level == 2:
                grandparent = ".".join(current_pkg.split(".")[:-1])
                module_name = f"{grandparent}.{node.module}" if grandparent else node.module
            else:
                continue

            resolved = module_to_file(module_name, src_root)
            if resolved:
                imported.add(resolved)

    # Dynamic import guard: if this file loads modules at runtime via
    # SourceFileLoader / importlib / __import__, static analysis cannot see
    # those dependencies.
    if _uses_dynamic_imports(tree):
        rel = file_path.relative_to(src_root) if file_path.is_relative_to(src_root) else file_path.name

        # 1. Keep all siblings in the same directory (covers file-path based
        #    loaders like SourceFileLoader("...", "Configuration.py")).
        for sibling in file_path.parent.glob("*.py"):
            if sibling != file_path and "__pycache__" not in sibling.parts:
                imported.add(sibling)

        # 2. Try to extract explicit module paths from the call arguments so we
        #    also protect packages loaded by name (e.g. importlib.import_module).
        #    Handles:
        #      - string literal:  import_module("models.Member")
        #      - f-string prefix: import_module(f"models.{var}")  → keep "models"
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            is_dyn = (
                (isinstance(func, ast.Name) and func.id in _DYNAMIC_IMPORT_NAMES) or
                (isinstance(func, ast.Attribute) and func.attr in _DYNAMIC_IMPORT_NAMES)
            )
            if not is_dyn or not node.args:
                continue

            arg = node.args[0]
            module_str: Optional[str] = None
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                module_str = arg.value
            elif isinstance(arg, ast.JoinedStr) and arg.values:
                first = arg.values[0]
                if isinstance(first, ast.Constant) and isinstance(first.value, str):
                    module_str = first.value.rstrip(".")  # e.g. "models" from f"models.{x}"

            if not module_str:
                continue

            resolved = module_to_file(module_str, src_root)
            if resolved:
                imported.add(resolved)
                # If it resolves to a package __init__.py, keep the whole package
                # because we only know the top-level name, not which submodule
                # will be requested at runtime.
                if resolved.name == "__init__.py":
                    for pkg_file in resolved.parent.rglob("*.py"):
                        if "__pycache__" not in pkg_file.parts:
                            imported.add(pkg_file)
                    log("TRACE", f"Dynamic import in {rel} loads from package '{module_str}' — keeping entire package directory")
                else:
                    log("TRACE", f"Dynamic import in {rel} loads '{module_str}' — keeping {resolved.name}")

        log("TRACE", f"Dynamic import guard applied to {rel} — siblings + resolved targets added")

    return imported


def build_import_graph(src_root: Path) -> Dict[Path, Set[Path]]:
    graph: Dict[Path, Set[Path]] = {}
    for py_file in src_root.rglob("*.py"):
        if "__pycache__" in py_file.parts:
            continue
        graph[py_file] = parse_imports(py_file, src_root)
    return graph


# ---------------------------------------------------------------------------
# Reachability
# ---------------------------------------------------------------------------

def compute_reachable(seeds: Set[Path], graph: Dict[Path, Set[Path]]) -> Set[Path]:
    visited: Set[Path] = set()
    queue: deque = deque(seeds)
    while queue:
        current = queue.popleft()
        if current in visited:
            continue
        visited.add(current)
        for dep in graph.get(current, set()):
            if dep not in visited:
                queue.append(dep)
    return visited


# ---------------------------------------------------------------------------
# Route file parsing
# ---------------------------------------------------------------------------

def parse_route_symbol_map(route_file: Path) -> Dict[str, str]:
    """
    Returns {symbol_name: dotted_module_path} for every name imported in route_file.
    E.g. {'AppCustomerJobList': 'controllers.appCustomers.jobs', ...}
    """
    symbol_to_module: Dict[str, str] = {}
    try:
        source = route_file.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source)
    except SyntaxError:
        return symbol_to_module

    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            for alias in node.names:
                used_name = alias.asname if alias.asname else alias.name
                symbol_to_module[used_name] = node.module

    return symbol_to_module


def parse_all_routes(route_file: Path) -> List[Tuple[int, str, str]]:
    """
    Find every api.add_resource(ClassName, '/url') call.
    Returns list of (1-based line number, class_name, url).
    """
    results: List[Tuple[int, str, str]] = []
    try:
        source = route_file.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source)
    except SyntaxError:
        return results

    for node in ast.walk(tree):
        if not isinstance(node, ast.Expr):
            continue
        call = node.value
        if not isinstance(call, ast.Call):
            continue
        func = call.func
        if not (isinstance(func, ast.Attribute) and func.attr == "add_resource"):
            continue
        if not call.args:
            continue
        first = call.args[0]
        if not isinstance(first, ast.Name):
            continue
        class_name = first.id
        url = ""
        if len(call.args) >= 2 and isinstance(call.args[1], ast.Constant):
            url = str(call.args[1].value)
        results.append((node.lineno, class_name, url))

    return results


# ---------------------------------------------------------------------------
# Endpoint-to-file resolution  (the core of "I know endpoints, not files")
# ---------------------------------------------------------------------------

def resolve_endpoints_to_files(
    endpoints: List[str],
    endpoint_pattern: Optional[str],
    route_file: Path,
    src_root: Path,
) -> Tuple[Set[Path], Set[str]]:
    """
    Given a list of endpoint URLs and/or a regex pattern, find which source
    files contain the Resource classes that handle those endpoints.

    Returns:
        (target_files, matched_class_names)
    """
    all_routes = parse_all_routes(route_file)       # [(lineno, class, url), ...]
    symbol_map = parse_route_symbol_map(route_file)  # {class: module}

    # Build a set of URLs to match (normalise: strip trailing slash, lowercase)
    exact_urls: Set[str] = {u.rstrip("/").lower() for u in (endpoints or [])}
    compiled_pattern: Optional[re.Pattern] = None
    if endpoint_pattern:
        compiled_pattern = re.compile(endpoint_pattern)

    target_files: Set[Path] = set()
    matched_classes: Set[str] = set()

    for lineno, class_name, url in all_routes:
        url_normalised = url.rstrip("/").lower()
        hit = (url_normalised in exact_urls) or (
            compiled_pattern is not None and compiled_pattern.search(url)
        )
        if not hit:
            continue

        module = symbol_map.get(class_name, "")
        if not module:
            log("WARN", f"  {url} → {class_name} — cannot find source module (not in imports?)")
            continue

        source_file = module_to_file(module, src_root)
        if not source_file:
            log("WARN", f"  {url} → {class_name} → {module} — file not found on disk")
            continue

        matched_classes.add(class_name)
        target_files.add(source_file)
        log("TRACE", f"  endpoint {url!r:40s} → {class_name} → {source_file.relative_to(src_root)}")

    return target_files, matched_classes


def list_all_endpoints(route_file: Path) -> None:
    """Print all registered endpoints grouped by source module — useful for discovery."""
    all_routes = parse_all_routes(route_file)
    symbol_map = parse_route_symbol_map(route_file)

    by_module: Dict[str, List[Tuple[str, str]]] = {}
    for _, class_name, url in all_routes:
        module = symbol_map.get(class_name, "<unknown>")
        by_module.setdefault(module, []).append((url, class_name))

    print("\n" + "=" * 70)
    print("ALL REGISTERED ENDPOINTS (grouped by source module)")
    print("=" * 70)
    for module in sorted(by_module):
        print(f"\n  [{module}]")
        for url, cls in sorted(by_module[module]):
            print(f"    {url:<50s}  ({cls})")
    print("=" * 70 + "\n")


# ---------------------------------------------------------------------------
# Route file pruning
# ---------------------------------------------------------------------------

def _multiline_import_end(lines: List[str], start_idx: int) -> int:
    line = lines[start_idx]
    stripped = line.split("#")[0]
    if "(" in stripped and ")" not in stripped:
        for i in range(start_idx + 1, len(lines)):
            if ")" in lines[i]:
                return i
        return start_idx
    if stripped.rstrip().endswith("\\"):
        for i in range(start_idx + 1, len(lines)):
            if not lines[i].rstrip().endswith("\\"):
                return i
    return start_idx


def prune_route_file(
    route_file: Path,
    kept_classes: Set[str],
    all_route_classes: Set[str],
    dry_run: bool,
) -> None:
    """
    Remove from route.py:
      - api.add_resource() lines for classes NOT in kept_classes
      - import lines where ALL names are non-kept route classes

    Import lines that contain at least one kept class (or a non-route symbol)
    are left completely untouched.
    """
    removed_classes = all_route_classes - kept_classes

    if not removed_classes:
        log("INFO", "Route pruning: nothing to remove")
        return

    if dry_run:
        log("DRY-RUN", f"Would remove {len(removed_classes)} add_resource calls from route.py")
        return

    source = route_file.read_text(encoding="utf-8", errors="replace")
    lines = source.splitlines(keepends=True)
    remove_indices: Set[int] = set()

    add_res_re = re.compile(r"^\s*api\.add_resource\s*\(\s*(\w+)\s*[,)]")
    for i, line in enumerate(lines):
        m = add_res_re.match(line)
        if m and m.group(1) in removed_classes:
            remove_indices.add(i)

    try:
        tree = ast.parse(source)
    except SyntaxError:
        log("REVERT", "route.py has a syntax error — cannot safely prune imports")
        return

    for node in ast.walk(tree):
        if not isinstance(node, ast.ImportFrom):
            continue
        if not node.module or node.level != 0:
            continue
        all_names = [alias.asname if alias.asname else alias.name for alias in node.names]
        if all_names and all(n in removed_classes for n in all_names):
            start = node.lineno - 1
            end = (node.end_lineno - 1) if hasattr(node, "end_lineno") else _multiline_import_end(lines, start)
            for i in range(start, end + 1):
                remove_indices.add(i)
            log("UNUSED", f"route.py import removed: {lines[start].strip()[:80]}")

    new_lines = [line for i, line in enumerate(lines) if i not in remove_indices]
    route_file.write_text("".join(new_lines), encoding="utf-8")
    log("INFO", f"route.py pruned: {len(remove_indices)} lines removed")


# ---------------------------------------------------------------------------
# Unused import removal (post-cleanup pass)
# ---------------------------------------------------------------------------

def _collect_name_usages(tree: ast.AST, skip_nodes: Set[ast.AST]) -> Set[str]:
    used: Set[str] = set()
    for node in ast.walk(tree):
        if node in skip_nodes:
            continue
        if isinstance(node, ast.Name):
            used.add(node.id)
        elif isinstance(node, ast.Attribute):
            root = node
            while isinstance(root, ast.Attribute):
                root = root.value
            if isinstance(root, ast.Name):
                used.add(root.id)
    return used


def _is_safe_to_analyse(tree: ast.AST) -> bool:
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == "*":
                    return False
        if isinstance(node, ast.Name) and node.id in ("eval", "exec", "globals", "locals", "vars"):
            return False
        if isinstance(node, ast.Name) and node.id == "__all__":
            return False
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "__all__":
                    return False
    return True


def find_unused_imports(file_path: Path) -> List[Tuple[int, int, str, List[str]]]:
    try:
        source = file_path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(file_path))
    except SyntaxError:
        return []

    if not _is_safe_to_analyse(tree):
        return []

    import_nodes: Set[ast.AST] = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            import_nodes.add(node)

    used_names = _collect_name_usages(tree, skip_nodes=import_nodes)
    results = []

    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            unused_names: List[str] = []
            for alias in node.names:
                code_name = alias.asname if alias.asname else alias.name.split(".")[0]
                if code_name not in used_names:
                    unused_names.append(code_name)

            if unused_names:
                module = node.module if isinstance(node, ast.ImportFrom) and node.module else ""
                start = node.lineno
                end   = node.end_lineno if hasattr(node, "end_lineno") else node.lineno
                results.append((start, end, module, unused_names))

    return results


def remove_unused_imports_from_file(file_path: Path, src_root: Path, dry_run: bool) -> int:
    try:
        source = file_path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(file_path))
    except SyntaxError:
        log("WARN", f"Skipping (syntax error): {file_path.relative_to(src_root)}")
        return 0

    if not _is_safe_to_analyse(tree):
        log("INFO", f"Skipping (star import / dynamic): {file_path.relative_to(src_root)}")
        return 0

    unused_entries = find_unused_imports(file_path)
    if not unused_entries:
        return 0

    rel = file_path.relative_to(src_root) if file_path.is_relative_to(src_root) else file_path
    total_removed = 0

    for start, end, module, unused_names in unused_entries:
        log("UNUSED-IMPORT", f"{rel}:{start}  unused names: {unused_names}")
        total_removed += len(unused_names)

    if dry_run:
        return total_removed

    lines = source.splitlines(keepends=True)
    remove_line_ranges: List[Tuple[int, int]] = []
    partial_edits: List[Tuple[int, str]] = []

    import_nodes: Set[ast.AST] = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            import_nodes.add(node)

    used_names = _collect_name_usages(tree, skip_nodes=import_nodes)

    for node in ast.walk(tree):
        if not isinstance(node, (ast.Import, ast.ImportFrom)):
            continue

        all_aliases  = node.names
        kept_aliases = [a for a in all_aliases
                        if (a.asname if a.asname else a.name.split(".")[0]) in used_names]

        start_0 = node.lineno - 1
        end_0   = (node.end_lineno - 1) if hasattr(node, "end_lineno") else start_0

        if not kept_aliases:
            remove_line_ranges.append((start_0, end_0))
        elif len(kept_aliases) < len(all_aliases):
            names_str = ", ".join(
                (f"{a.name} as {a.asname}" if a.asname else a.name)
                for a in kept_aliases
            )
            if isinstance(node, ast.ImportFrom):
                level_dots = "." * node.level
                mod_part   = node.module or ""
                new_line   = f"from {level_dots}{mod_part} import {names_str}\n"
            else:
                new_line = f"import {names_str}\n"
            partial_edits.append((start_0, new_line))
            if end_0 > start_0:
                remove_line_ranges.append((start_0 + 1, end_0))

    drop: Set[int] = set()
    for s, e in remove_line_ranges:
        for i in range(s, e + 1):
            drop.add(i)

    partial_map = {idx: text for idx, text in partial_edits}
    new_lines: List[str] = []

    for i, line in enumerate(lines):
        if i in drop:
            continue
        if i in partial_map:
            new_lines.append(partial_map[i])
        else:
            new_lines.append(line)

    file_path.write_text("".join(new_lines), encoding="utf-8")

    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(file_path)],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        log("REVERT", f"{rel}: syntax error after import cleanup — restoring original")
        log("REVERT", result.stderr.strip())
        file_path.write_text(source, encoding="utf-8")
        return 0

    log("INFO", f"Cleaned unused imports in {rel} ({total_removed} names removed)")
    return total_removed


def remove_unused_imports_pass(kept_files: Set[Path], src_root: Path, dry_run: bool) -> int:
    log("INFO", f"Scanning {len(kept_files)} kept files for unused imports...")
    total = 0
    modified: List[Path] = []

    for f in sorted(kept_files):
        if f.name == "__init__.py":
            continue
        removed = remove_unused_imports_from_file(f, src_root, dry_run)
        if removed > 0:
            total += removed
            if not dry_run:
                modified.append(f)

    log("INFO", f"Unused import cleanup: {total} import names removed across {len(modified)} files")
    return total


# ---------------------------------------------------------------------------
# Deletion
# ---------------------------------------------------------------------------

def apply_deletions(unused_files: Set[Path], src_root: Path, dry_run: bool) -> int:
    count = 0
    for f in sorted(unused_files):
        rel = f.relative_to(src_root) if f.is_relative_to(src_root) else f
        if dry_run:
            log("UNUSED", str(rel))
            count += 1
        else:
            log("DELETE", str(rel))
            try:
                f.unlink()
                count += 1
            except OSError as e:
                log("ERROR", f"Could not delete {f}: {e}")
    return count


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------

def verify_syntax(files: List[Path], python_bin: str) -> List[Path]:
    failed: List[Path] = []
    for f in files:
        result = subprocess.run(
            [python_bin, "-m", "py_compile", str(f)],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            failed.append(f)
            log("REVERT", f"Syntax error in {f}: {result.stderr.strip()}")
    return failed


def run_startup_check(python_bin: str, src_root: Path, entry_module: str) -> bool:
    try:
        result = subprocess.run(
            [python_bin, "-u", "-c", f"import {entry_module}; print('IMPORT_OK')"],
            cwd=str(src_root),
            capture_output=True, text=True,
            timeout=60,
        )
    except subprocess.TimeoutExpired:
        log("FAIL", "Startup check timed out after 60s")
        return False

    if result.returncode == 0 and "IMPORT_OK" in result.stdout:
        log("OK", "Startup check passed")
        return True

    log("FAIL", f"Startup check failed\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}")
    return False


# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------

def _version() -> str:
    try:
        from importlib.metadata import version
        return version("gate6-code-extractor")
    except Exception:
        return "dev"


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--version", action="version", version=f"gate6-code-extractor {_version()}")

    keep_group = p.add_argument_group("What to keep (choose one or both)")
    keep_group.add_argument(
        "--endpoints", nargs="+", metavar="URL",
        help="Exact endpoint URLs to keep, e.g. /customer_job_list_app /invoice_list_app",
    )
    keep_group.add_argument(
        "--endpoint-pattern", metavar="REGEX",
        help="Regex pattern matched against endpoint URLs, e.g. '.*_app$'",
    )
    keep_group.add_argument(
        "--targets", nargs="+", metavar="DIR",
        help="Source folder paths to keep, e.g. src/controllers/appCustomers",
    )

    p.add_argument(
        "--list-endpoints", action="store_true",
        help="Print all registered endpoints grouped by module, then exit.",
    )

    p.add_argument("--src-root",      default="src",  metavar="PATH",
                   help="Root of the Python source tree (default: src)")
    p.add_argument("--entry-module",  default="api",  metavar="MODULE",
                   help="Module name for startup import check (default: api)")
    p.add_argument("--route-file",    default=None,   metavar="PATH",
                   help="Route registration file (default: <src-root>/route.py)")
    p.add_argument("--venv",          default=None,   metavar="PATH",
                   help="Virtual env path (default: <src-root>/.venv)")
    p.add_argument("--prune-routes",  action="store_true",
                   help="Remove non-target routes from route.py before computing reachability")
    p.add_argument("--remove-unused-imports", action="store_true",
                   help="After deletions, remove unused imports from kept files")
    p.add_argument("--dry-run",       action="store_true",
                   help="Log what would change — make no changes")
    p.add_argument("--skip-parity",   action="store_true",
                   help="Skip parity test")
    p.add_argument("--no-entry-prompt", action="store_true",
                   help="Do not prompt before applying changes")
    p.add_argument("--parity-cmd",    default=None, metavar="CMD",
                   help="Shell command for parity test after cleanup")
    p.add_argument("--log-dir",       default="cleanup_logs", metavar="DIR",
                   help="Directory for per-run logs (default: cleanup_logs)")
    p.add_argument("--always-keep",   nargs="*", default=[], metavar="PATH",
                   help="Extra paths (relative to src-root) to always keep")

    return p.parse_args()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    args = parse_args()

    src_root   = Path(args.src_root).resolve()
    log_dir    = Path(args.log_dir)
    run_number = next_run_number(log_dir)

    venv_python = Path(args.venv).resolve() / "bin" / "python" if args.venv \
                  else src_root / ".venv" / "bin" / "python"
    python_bin = str(venv_python) if venv_python.exists() else sys.executable
    if not venv_python.exists():
        log("WARN", f"venv not found — using system Python: {python_bin}")

    route_file = (Path(args.route_file).resolve() if args.route_file
                  else src_root / "route.py")
    entry_file = src_root / f"{args.entry_module}.py"

    if args.list_endpoints:
        list_all_endpoints(route_file)
        return

    if not args.endpoints and not args.endpoint_pattern and not args.targets:
        print(
            "ERROR: specify what to keep.\n"
            "  --endpoints URL [URL ...]   exact endpoint URLs\n"
            "  --endpoint-pattern REGEX    regex on endpoint URLs\n"
            "  --targets DIR [DIR ...]     source folder paths\n"
            "\nTip: run with --list-endpoints to see all available endpoints."
        )
        sys.exit(1)

    # Always-keep: entry point, route file, this installed script (site-packages path)
    always_keep: Set[Path] = {entry_file, route_file, Path(__file__).resolve()}
    for rel in (args.always_keep or []):
        p = (src_root / rel).resolve()
        if p.exists():
            always_keep.add(p)
        else:
            log("WARN", f"--always-keep path not found: {p}")

    log("INFO", "=" * 65)
    log("INFO", f"gate6-code-extractor  v{_version()}")
    log("INFO", f"Run #{run_number:03d}  {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log("INFO", f"dry_run          : {args.dry_run}")
    log("INFO", f"prune_routes     : {args.prune_routes}")
    log("INFO", f"src_root         : {src_root}")
    log("INFO", f"route_file       : {route_file}")
    log("INFO", f"endpoints        : {args.endpoints}")
    log("INFO", f"endpoint_pattern : {args.endpoint_pattern}")
    log("INFO", f"target_dirs      : {args.targets}")
    log("INFO", "=" * 65)

    log("STEP", "1/6  Baseline startup check")
    if not run_startup_check(python_bin, src_root, args.entry_module):
        log("ABORT", "Baseline check failed. Fix the project first.")
        flush_log(log_dir, run_number)
        sys.exit(1)

    log("STEP", "2/6  Resolving selections to source files")

    target_files: Set[Path] = set()
    kept_route_classes: Set[str] = set()
    all_route_classes:  Set[str] = set()

    all_routes = parse_all_routes(route_file)
    for _, cls, _ in all_routes:
        all_route_classes.add(cls)

    if args.endpoints or args.endpoint_pattern:
        ep_files, ep_classes = resolve_endpoints_to_files(
            args.endpoints or [], args.endpoint_pattern, route_file, src_root,
        )
        target_files       |= ep_files
        kept_route_classes |= ep_classes

        if not ep_files:
            log("WARN", "No endpoints matched — check your --endpoints / --endpoint-pattern values")
            log("WARN", "Run with --list-endpoints to see all available endpoints")

    if args.targets:
        for t in args.targets:
            target_dir = Path(t).resolve()
            if not target_dir.exists():
                log("ERROR", f"Target folder does not exist: {target_dir}")
                sys.exit(1)
            for py_file in target_dir.rglob("*.py"):
                if "__pycache__" not in py_file.parts:
                    target_files.add(py_file)
            sym_map = parse_route_symbol_map(route_file)
            try:
                rel_prefix = ".".join(target_dir.relative_to(src_root).parts)
            except ValueError:
                rel_prefix = ""
            for cls, mod in sym_map.items():
                if rel_prefix and mod.startswith(rel_prefix):
                    kept_route_classes.add(cls)

    log("INFO", f"Target source files  : {len(target_files)}")
    log("INFO", f"Kept route classes   : {len(kept_route_classes)}")
    for f in sorted(target_files):
        log("TRACE", f"  target file: {f.relative_to(src_root)}")

    log("STEP", "3/6  Route pruning")
    if args.prune_routes:
        if not route_file.exists():
            log("WARN", f"Route file not found: {route_file} — skipping")
        else:
            for lineno, cls, url in sorted(all_routes, key=lambda x: x[0]):
                if cls in kept_route_classes:
                    log("KEEP",   f"route:{lineno:4d}  {url:<45s}  ({cls})")
                else:
                    log("UNUSED", f"route:{lineno:4d}  {url:<45s}  ({cls})")

            prune_route_file(route_file, kept_route_classes, all_route_classes, args.dry_run)
            if not args.dry_run:
                verify_syntax([route_file], python_bin)
    else:
        log("INFO", "Route pruning skipped (pass --prune-routes to enable)")
        log("WARN",
            "Without --prune-routes, route.py imports every controller, so "
            "most files stay reachable and very little gets deleted.")

    log("STEP", "4/6  Building import graph")
    graph = build_import_graph(src_root)
    log("INFO", f"Import graph: {len(graph)} files indexed")

    log("STEP", "5/6  Computing reachability")
    seeds     = target_files | always_keep
    reachable = compute_reachable(seeds, graph)
    all_py    = {f for f in src_root.rglob("*.py") if "__pycache__" not in f.parts}
    unused    = all_py - reachable

    log("INFO", f"Reachable: {len(reachable)} files")
    log("INFO", f"Unused   : {len(unused)} files")
    for f in sorted(unused):
        log("UNUSED", str(f.relative_to(src_root)))
    for f in sorted(reachable & all_py):
        log("KEEP", str(f.relative_to(src_root)))

    log("STEP", "6/6  Applying changes")

    if args.dry_run:
        log("DRY-RUN", f"Would delete {len(unused)} files — no changes made")
        if args.remove_unused_imports:
            log("STEP", "7/7  Dry-run: scanning for unused imports in kept files")
            kept_files = {f for f in src_root.rglob("*.py")
                          if "__pycache__" not in f.parts and f not in unused}
            remove_unused_imports_pass(kept_files, src_root, dry_run=True)
        log_path = flush_log(log_dir, run_number)
        print(f"\nLog written to: {log_path}")
        return

    if not args.no_entry_prompt:
        print(f"\nAbout to delete {len(unused)} unused files from {src_root}")
        answer = input("Proceed? [y/N] ").strip().lower()
        if answer != "y":
            log("ABORT", "Cancelled by user.")
            flush_log(log_dir, run_number)
            return

    deleted = apply_deletions(unused, src_root, dry_run=False)
    log("INFO", f"Deleted {deleted} files")

    log("INFO", "Post-deletion startup check...")
    post_ok = run_startup_check(python_bin, src_root, args.entry_module)
    if not post_ok:
        log("FAIL", "Post-deletion startup check FAILED — review [DELETE] lines above")

    if args.parity_cmd and not args.skip_parity:
        log("INFO", f"Running parity test: {args.parity_cmd}")
        result = subprocess.run(args.parity_cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            log("OK", "Parity test passed")
        else:
            log("FAIL", f"Parity test FAILED\n{result.stdout}\n{result.stderr}")

    imports_removed = 0
    if args.remove_unused_imports:
        log("STEP", "7/7  Removing unused imports from kept files")
        live_files = {f for f in src_root.rglob("*.py") if "__pycache__" not in f.parts}
        imports_removed = remove_unused_imports_pass(live_files, src_root, dry_run=False)
        if imports_removed > 0:
            log("INFO", "Startup check after import cleanup...")
            run_startup_check(python_bin, src_root, args.entry_module)

    log("INFO", "=" * 65)
    log("INFO", f"DONE  deleted={deleted}  imports_cleaned={imports_removed}  startup={'PASS' if post_ok else 'FAIL'}")
    log("INFO", "=" * 65)

    log_path = flush_log(log_dir, run_number)
    print(f"\nLog written to: {log_path}")


if __name__ == "__main__":
    main()
