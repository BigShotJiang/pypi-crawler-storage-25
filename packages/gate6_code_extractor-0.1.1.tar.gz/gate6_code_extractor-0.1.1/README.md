# gate6-code-extractor

Extract a Flask-RESTful module from a Python monolith by removing all unreachable code.

## Install

```bash
pip install gate6-code-extractor
```

## Usage

```bash
# Discover all endpoints
g6-extract --list-endpoints --src-root src

# Dry run — see what would be deleted
g6-extract --endpoints /customer_list /invoice_list \
    --src-root src --prune-routes --remove-unused-imports --dry-run

# Real run
g6-extract --endpoints /customer_list /invoice_list \
    --src-root src --prune-routes --remove-unused-imports --no-entry-prompt

# Keep all endpoints matching a pattern
g6-extract --endpoint-pattern ".*_app$" \
    --src-root src --prune-routes --remove-unused-imports --dry-run
```

## How it works

1. You specify which API endpoints to keep
2. Script traces every import chain from those endpoints (AST-based, no regex)
3. Deletes all unreachable `.py` files
4. Optionally removes unused imports from kept files
5. Runs a startup check after every change to confirm nothing broke

Requires Python 3.9+. Zero dependencies — stdlib only.
