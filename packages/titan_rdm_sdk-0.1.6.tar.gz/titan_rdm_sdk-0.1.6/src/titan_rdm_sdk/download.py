"""Download class for TitanRDM export operations."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

import pandas as pd
import requests

from titan_rdm_sdk.exceptions import (
    APIError,
    ExportFailedError,
    ExportNotReadyError,
    ValidationError,
)
from titan_rdm_sdk.utils import parse_csv_response, validate_iso8601

if TYPE_CHECKING:
    from titan_rdm_sdk.client import TitanRDMClient


class Download:
    """
    Represents an export operation from TitanRDM.

    Downloads table data as CSV and returns as pandas DataFrame.
    """

    def __init__(
        self,
        client: TitanRDMClient,
        branch_id: int,
        table_definition_key: int,
        pattern: str = "full",
        correlation_code: str | None = None,
        high_water_mark: str | None = None,
    ) -> None:
        """
        Create a new export operation.

        Args:
            client: TitanRDMClient instance for API calls.
            branch_id: Target branch ID.
            table_definition_key: Table definition key.
            pattern: Export pattern ('full' or 'incremental').
            correlation_code: User-defined tracking identifier.
            high_water_mark: ISO 8601 timestamp (required for incremental).

        Raises:
            ValidationError: If pattern is 'incremental' but high_water_mark
                is not provided, or if pattern is invalid.
            APIError: If the export creation fails.
        """
        # Validate pattern
        if pattern not in ("full", "incremental"):
            raise ValidationError("pattern must be 'full' or 'incremental'")

        # Validate high_water_mark for incremental exports
        if pattern == "incremental":
            if not high_water_mark:
                raise ValidationError(
                    "high_water_mark is required for incremental exports"
                )
            if not validate_iso8601(high_water_mark):
                raise ValidationError("high_water_mark must be in ISO 8601 format")

        self._client = client
        self.branch_id = branch_id
        self.table_definition_key = table_definition_key
        self.pattern = pattern
        self.correlation_code = correlation_code
        self.high_water_mark = high_water_mark

        # Attributes populated from API response
        self.id: int | None = None
        self.status: str | None = None
        self.started_datetime: str | None = None
        self.completed_datetime: str | None = None
        self.rows_exported: int | None = None
        self.files_exported: int | None = None
        self.bytes_exported: int | None = None
        self.download_url: str | None = None
        self.message: str | None = None
        self.compressed: bool = False
        self.duration_secs: int | None = None

        # Create the export
        self._create_export()

    def _create_export(self) -> None:
        """Create the export via the API."""
        payload: dict[str, Any] = {
            "branch_id": self.branch_id,
            "table_definition_key": self.table_definition_key,
            "pattern": self.pattern,
        }

        if self.correlation_code:
            payload["correlation_code"] = self.correlation_code

        if self.high_water_mark:
            payload["high_water_mark"] = self.high_water_mark

        response = self._client._make_request(
            method="POST",
            endpoint="/api/exports/new",
            json=payload,
        )

        self._update_from_response(response)

    def _update_from_response(self, data: dict[str, Any]) -> None:
        """Update attributes from API response."""
        self.id = data.get("id")
        self.status = data.get("status")
        self.started_datetime = data.get("started_datetime")
        self.completed_datetime = data.get("complete_datetime")
        self.rows_exported = data.get("rows_exported")
        self.files_exported = data.get("files_exported")
        self.bytes_exported = data.get("bytes_exported")
        self.download_url = data.get("download_url")
        self.message = data.get("message")
        self.compressed = data.get("compressed", False)
        self.duration_secs = data.get("duration_secs")

        # Also update from response if available
        if data.get("branch_id"):
            self.branch_id = data["branch_id"]
        if data.get("table_definition_key"):
            self.table_definition_key = data["table_definition_key"]
        if data.get("pattern"):
            self.pattern = data["pattern"]
        if data.get("correlation_code"):
            self.correlation_code = data["correlation_code"]
        if data.get("high_water_mark"):
            self.high_water_mark = data["high_water_mark"]

    def check_status(self) -> str:
        """
        Poll the export status from the server and update local attributes.

        Returns:
            Current status ('started', 'ready', or 'failed').

        Raises:
            APIError: If the status check fails.
        """
        if self.id is None:
            raise APIError("Export ID is not set. Export may not have been created.")

        response = self._client._make_request(
            method="GET",
            endpoint=f"/api/exports/{self.id}",
        )

        self._update_from_response(response)
        return self.status

    def receive(self) -> pd.DataFrame:
        """
        Download the exported data and return as a pandas DataFrame.

        If the export is not ready, calls check_status() first.

        Returns:
            The exported data as a pandas DataFrame.

        Raises:
            ExportNotReadyError: If export status is 'started' after status check.
            ExportFailedError: If export status is 'failed'.
            APIError: If the download fails.
        """
        # Check status if not ready
        if self.status != "ready":
            self.check_status()

        # Handle status
        if self.status == "started":
            raise ExportNotReadyError(
                "Export is still in progress. "
                "Use wait_until_ready() to wait for completion."
            )

        if self.status == "failed":
            raise ExportFailedError(
                f"Export failed: {self.message or 'Unknown error'}"
            )

        if not self.download_url:
            raise APIError("Download URL is not available")

        # Download the file
        try:
            response = requests.get(self.download_url, stream=True, timeout=300)
            response.raise_for_status()
        except requests.RequestException as e:
            raise APIError(f"Failed to download export file: {e}") from e

        # Parse CSV into DataFrame
        return parse_csv_response(response.content)

    def wait_until_ready(
        self,
        poll_interval: float = 2.0,
        max_wait: float = 300.0,
    ) -> str:
        """
        Poll status until export is ready or failed.

        Args:
            poll_interval: Seconds between status checks (default: 2.0).
            max_wait: Maximum seconds to wait (default: 300.0).

        Returns:
            Final status ('ready' or 'failed').

        Raises:
            TimeoutError: If max_wait exceeded while status is 'started'.
            ExportFailedError: If export fails.
        """
        start_time = time.time()

        while True:
            status = self.check_status()

            if status == "ready":
                return status

            if status == "failed":
                raise ExportFailedError(
                    f"Export failed: {self.message or 'Unknown error'}"
                )

            # Check timeout
            elapsed = time.time() - start_time
            if elapsed >= max_wait:
                raise TimeoutError(
                    f"Export did not complete within {max_wait} seconds. "
                    f"Current status: {status}"
                )

            # Wait before next poll
            time.sleep(poll_interval)
