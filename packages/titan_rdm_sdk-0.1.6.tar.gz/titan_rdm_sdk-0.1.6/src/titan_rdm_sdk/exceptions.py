"""Custom exceptions for TitanRDM SDK."""

from typing import Any


class TitanRDMError(Exception):
    """Base exception for TitanRDM SDK errors."""

    pass


class AuthenticationError(TitanRDMError):
    """Raised when authentication fails."""

    pass


class APIError(TitanRDMError):
    """Raised when an API request fails."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class ExportNotReadyError(TitanRDMError):
    """Raised when attempting to download an export that is not ready."""

    pass


class ExportFailedError(TitanRDMError):
    """Raised when an export operation fails."""

    pass


class UploadError(TitanRDMError):
    """Raised when a file upload to S3 fails."""

    pass


class ValidationError(TitanRDMError):
    """Raised when input validation fails."""

    pass
