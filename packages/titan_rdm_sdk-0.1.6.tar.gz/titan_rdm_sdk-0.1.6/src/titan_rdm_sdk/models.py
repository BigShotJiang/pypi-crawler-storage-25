"""Data model classes for TitanRDM API entities."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Branch:
    """Represents a TitanRDM branch.

    Attributes:
        id: Branch ID.
        name: Branch name.
        description: Branch description.
        branch_type: Type of branch ('shared' or 'private').
        status: Branch status ('open' or 'closed').
        database_suffix: Database suffix for this branch.
        is_default_dev_branch: Whether this is the default development branch.
        is_integration_branch: Whether this is an integration branch.
        parent_branch_id: ID of the parent branch (if any).
        parent_branch_name: Name of the parent branch (if any).
        owner_id: ID of the branch owner (if private).
        owner_email: Email of the branch owner (if private).
        created_at: ISO 8601 creation timestamp.
        updated_at: ISO 8601 last-updated timestamp.
    """

    id: int | None = None
    name: str | None = None
    description: str | None = None
    branch_type: str | None = None
    status: str | None = None
    database_suffix: str | None = None
    is_default_dev_branch: bool = False
    is_integration_branch: bool = False
    parent_branch_id: int | None = None
    parent_branch_name: str | None = None
    owner_id: int | None = None
    owner_email: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_api_response(cls, data: dict[str, Any]) -> Branch:
        """Create a Branch from an API response dictionary.

        Args:
            data: Dictionary from the API JSON response.

        Returns:
            A new Branch instance.
        """
        parent = data.get("parent_branch") or {}
        owner = data.get("owner") or {}

        return cls(
            id=data.get("id"),
            name=data.get("name"),
            description=data.get("description"),
            branch_type=data.get("branch_type"),
            status=data.get("status"),
            database_suffix=data.get("database_suffix"),
            is_default_dev_branch=data.get("is_default_dev_branch", False),
            is_integration_branch=data.get("is_integration_branch", False),
            parent_branch_id=data.get("parent_branch_id"),
            owner_id=data.get("owner_id"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )


@dataclass
class Domain:
    """Represents a TitanRDM domain.

    Attributes:
        id: Domain ID.
        name: Domain name.
        abbreviation: Short abbreviation for the domain.
        description: Domain description.
        created_at: ISO 8601 creation timestamp.
        updated_at: ISO 8601 last-updated timestamp.
    """

    id: int | None = None
    name: str | None = None
    abbreviation: str | None = None
    description: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_api_response(cls, data: dict[str, Any]) -> Domain:
        """Create a Domain from an API response dictionary.

        Args:
            data: Dictionary from the API JSON response.

        Returns:
            A new Domain instance.
        """
        return cls(
            id=data.get("id"),
            name=data.get("name"),
            abbreviation=data.get("abbreviation"),
            description=data.get("description"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )


@dataclass
class DeployedColumnDefinition:
    """Represents a column definition within a deployed table.

    Attributes:
        id: Column definition ID.
        key: Column definition UUID key.
        name: Column name.
        data_type: Data type (e.g. 'integer', 'varchar').
        length: Length constraint (for varchar types).
        is_primary_key: Whether this column is part of the primary key.
        is_required: Whether this column is required (NOT NULL).
        display_order: Display ordering position.
        is_deleted: Whether this column has been soft-deleted.
        description: Column description.
    """

    id: int | None = None
    key: str | None = None
    name: str | None = None
    data_type: str | None = None
    length: int | None = None
    is_primary_key: bool = False
    is_required: bool = False
    display_order: int | None = None
    is_deleted: bool = False
    description: str | None = None

    @classmethod
    def from_api_response(cls, data: dict[str, Any]) -> DeployedColumnDefinition:
        """Create a DeployedColumnDefinition from an API response dictionary.

        Args:
            data: Dictionary from the API JSON response.

        Returns:
            A new DeployedColumnDefinition instance.
        """
        return cls(
            id=data.get("id"),
            key=data.get("key"),
            name=data.get("name"),
            data_type=data.get("data_type"),
            length=data.get("length"),
            is_primary_key=data.get("is_primary_key", False),
            is_required=data.get("is_required", False),
            display_order=data.get("display_order"),
            is_deleted=data.get("is_deleted", False),
            description=data.get("description"),
        )


@dataclass
class DeployedTableDefinition:
    """Represents a deployed table definition in TitanRDM.

    A deployed table definition is a table that has been deployed to a branch
    and is available for data operations (imports/exports).

    Attributes:
        id: Deployed table definition ID.
        key: Table definition UUID key.
        name: Table name.
        database_table_name: Physical database table name (e.g. 't_cust_customers').
        domain_id: ID of the domain this table belongs to.
        domain_name: Name of the domain.
        domain_abbreviation: Abbreviation of the domain.
        branch_id: ID of the branch this table is deployed to.
        branch_name: Name of the branch.
        column_definitions: List of deployed column definitions.
        created_at: ISO 8601 creation timestamp.
        updated_at: ISO 8601 last-updated timestamp.
    """

    id: int | None = None
    key: str | None = None
    name: str | None = None
    database_table_name: str | None = None
    domain_id: int | None = None
    domain_name: str | None = None
    domain_abbreviation: str | None = None
    branch_id: int | None = None
    branch_name: str | None = None
    column_definitions: list[DeployedColumnDefinition] = field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_api_response(cls, data: dict[str, Any]) -> DeployedTableDefinition:
        """Create a DeployedTableDefinition from an API response dictionary.

        Args:
            data: Dictionary from the API JSON response.

        Returns:
            A new DeployedTableDefinition instance.
        """
        domain = data.get("domain") or {}
        branch = data.get("branch") or {}

        # Handle both 'column_definitions' and 'deployed_column_definitions'
        raw_columns = (
            data.get("deployed_column_definitions")
            or data.get("column_definitions")
            or []
        )
        columns = [DeployedColumnDefinition.from_api_response(c) for c in raw_columns]

        return cls(
            id=data.get("id"),
            key=data.get("key"),
            name=data.get("name"),
            database_table_name=data.get("database_table_name"),
            domain_id=domain.get("id"),
            domain_name=domain.get("name"),
            domain_abbreviation=domain.get("abbreviation"),
            branch_id=branch.get("id"),
            branch_name=branch.get("name"),
            column_definitions=columns,
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )


@dataclass
class ImportMapping:
    """Represents an import mapping for a table definition in TitanRDM.

    An import mapping defines how source data columns are mapped to the
    target table columns for data import operations.

    Attributes:
        id: Import mapping ID.
        key: Import mapping UUID key.
        table_definition_id: ID of the table definition this mapping belongs to.
        table_definition_name: Name of the table definition.
        name: Human-readable name for this import mapping.
        is_default: Whether this is the default import mapping for the table.
        branch_id: ID of the branch this mapping is associated with.
        branch_name: Name of the branch.
        mapping_config: Dictionary containing column mapping configuration.
        created_at: ISO 8601 creation timestamp.
        updated_at: ISO 8601 last-updated timestamp.
    """

    id: int | None = None
    key: str | None = None
    table_definition_id: int | None = None
    table_definition_name: str | None = None
    name: str | None = None
    is_default: bool = False
    branch_id: int | None = None
    branch_name: str | None = None
    mapping_config: dict[str, Any] = field(default_factory=dict)
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_api_response(cls, data: dict[str, Any]) -> ImportMapping:
        """Create an ImportMapping from an API response dictionary.

        Args:
            data: Dictionary from the API JSON response.

        Returns:
            A new ImportMapping instance.
        """
        table_definition = data.get("table_definition") or {}
        branch = data.get("branch") or {}

        return cls(
            id=data.get("id"),
            key=data.get("key"),
            table_definition_id=table_definition.get("id"),
            table_definition_name=table_definition.get("name"),
            name=data.get("name"),
            is_default=data.get("is_default", False),
            branch_id=branch.get("id"),
            branch_name=branch.get("name"),
            mapping_config=data.get("mapping_config") or {},
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )

