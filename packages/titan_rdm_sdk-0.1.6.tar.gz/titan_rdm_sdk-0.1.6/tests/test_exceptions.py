"""Tests for custom exceptions."""

import pytest

from titan_rdm_sdk.exceptions import (
    APIError,
    AuthenticationError,
    ExportFailedError,
    ExportNotReadyError,
    TitanRDMError,
    UploadError,
    ValidationError,
)


class TestTitanRDMError:
    """Tests for base TitanRDMError."""

    def test_is_exception(self):
        """Test that TitanRDMError is an Exception."""
        assert issubclass(TitanRDMError, Exception)

    def test_can_be_raised_with_message(self):
        """Test that TitanRDMError can be raised with a message."""
        with pytest.raises(TitanRDMError, match="Test error"):
            raise TitanRDMError("Test error")


class TestAuthenticationError:
    """Tests for AuthenticationError."""

    def test_inherits_from_titan_rdm_error(self):
        """Test that AuthenticationError inherits from TitanRDMError."""
        assert issubclass(AuthenticationError, TitanRDMError)

    def test_can_be_caught_as_titan_rdm_error(self):
        """Test that AuthenticationError can be caught as TitanRDMError."""
        with pytest.raises(TitanRDMError):
            raise AuthenticationError("Auth failed")


class TestAPIError:
    """Tests for APIError."""

    def test_inherits_from_titan_rdm_error(self):
        """Test that APIError inherits from TitanRDMError."""
        assert issubclass(APIError, TitanRDMError)

    def test_stores_status_code(self):
        """Test that APIError stores status code."""
        error = APIError("Not found", status_code=404)
        assert error.status_code == 404

    def test_stores_response(self):
        """Test that APIError stores response."""
        response_data = {"error": "Not found", "details": "Resource missing"}
        error = APIError("Not found", status_code=404, response=response_data)
        assert error.response == response_data

    def test_message_is_accessible(self):
        """Test that error message is accessible."""
        error = APIError("Something went wrong", status_code=500)
        assert str(error) == "Something went wrong"

    def test_default_values(self):
        """Test default values for optional parameters."""
        error = APIError("Error")
        assert error.status_code is None
        assert error.response is None


class TestExportNotReadyError:
    """Tests for ExportNotReadyError."""

    def test_inherits_from_titan_rdm_error(self):
        """Test that ExportNotReadyError inherits from TitanRDMError."""
        assert issubclass(ExportNotReadyError, TitanRDMError)


class TestExportFailedError:
    """Tests for ExportFailedError."""

    def test_inherits_from_titan_rdm_error(self):
        """Test that ExportFailedError inherits from TitanRDMError."""
        assert issubclass(ExportFailedError, TitanRDMError)


class TestUploadError:
    """Tests for UploadError."""

    def test_inherits_from_titan_rdm_error(self):
        """Test that UploadError inherits from TitanRDMError."""
        assert issubclass(UploadError, TitanRDMError)


class TestValidationError:
    """Tests for ValidationError."""

    def test_inherits_from_titan_rdm_error(self):
        """Test that ValidationError inherits from TitanRDMError."""
        assert issubclass(ValidationError, TitanRDMError)


class TestExceptionHierarchy:
    """Tests for exception hierarchy."""

    def test_all_exceptions_caught_by_base(self):
        """Test that all custom exceptions can be caught by TitanRDMError."""
        exceptions = [
            AuthenticationError("auth"),
            APIError("api"),
            ExportNotReadyError("not ready"),
            ExportFailedError("failed"),
            UploadError("upload"),
            ValidationError("validation"),
        ]

        for exc in exceptions:
            try:
                raise exc
            except TitanRDMError:
                pass  # Should be caught
            except Exception:
                pytest.fail(f"{type(exc).__name__} not caught by TitanRDMError")
