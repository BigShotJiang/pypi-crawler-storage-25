"""Tests for utility functions."""

import pandas as pd
import pytest

from titan_rdm_sdk.utils import (
    dataframe_to_csv,
    extract_error_message,
    parse_csv_response,
    validate_iso8601,
)


class TestValidateISO8601:
    """Tests for validate_iso8601 function."""

    def test_valid_iso8601_with_z(self):
        """Test valid ISO 8601 timestamp with Z suffix."""
        assert validate_iso8601("2025-01-22T10:30:00Z") is True

    def test_valid_iso8601_with_offset(self):
        """Test valid ISO 8601 timestamp with timezone offset."""
        assert validate_iso8601("2025-01-22T10:30:00+00:00") is True

    def test_valid_iso8601_date_only(self):
        """Test valid ISO 8601 date only."""
        assert validate_iso8601("2025-01-22") is True

    def test_valid_iso8601_with_microseconds(self):
        """Test valid ISO 8601 with microseconds."""
        assert validate_iso8601("2025-01-22T10:30:00.123456Z") is True

    def test_invalid_format(self):
        """Test invalid format returns False."""
        assert validate_iso8601("not-a-date") is False

    def test_invalid_date_values(self):
        """Test invalid date values return False."""
        assert validate_iso8601("2025-13-45T10:30:00Z") is False

    def test_empty_string(self):
        """Test empty string returns False."""
        assert validate_iso8601("") is False

    def test_none_returns_false(self):
        """Test None returns False."""
        assert validate_iso8601(None) is False


class TestParseCSVResponse:
    """Tests for parse_csv_response function."""

    def test_parse_bytes(self):
        """Test parsing CSV from bytes."""
        csv_bytes = b"id,name,value\n1,Alice,100\n2,Bob,200\n"
        df = parse_csv_response(csv_bytes)

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert list(df.columns) == ["id", "name", "value"]

    def test_parse_string(self):
        """Test parsing CSV from string."""
        csv_string = "id,name,value\n1,Alice,100\n2,Bob,200\n"
        df = parse_csv_response(csv_string)

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2

    def test_parse_with_special_characters(self):
        """Test parsing CSV with special characters."""
        csv_bytes = 'id,name,description\n1,Test,"Value with, comma"\n'.encode("utf-8")
        df = parse_csv_response(csv_bytes)

        assert df.iloc[0]["description"] == "Value with, comma"

    def test_parse_empty_csv(self):
        """Test parsing empty CSV (headers only)."""
        csv_bytes = b"id,name,value\n"
        df = parse_csv_response(csv_bytes)

        assert len(df) == 0
        assert list(df.columns) == ["id", "name", "value"]


class TestDataFrameToCSV:
    """Tests for dataframe_to_csv function."""

    def test_basic_conversion(self):
        """Test basic DataFrame to CSV conversion."""
        df = pd.DataFrame({"id": [1, 2], "name": ["Alice", "Bob"]})
        csv_bytes = dataframe_to_csv(df)

        assert isinstance(csv_bytes, bytes)
        assert b"id,name" in csv_bytes
        assert b"1,Alice" in csv_bytes

    def test_no_index(self):
        """Test that index is not included."""
        df = pd.DataFrame({"id": [1, 2]})
        csv_bytes = dataframe_to_csv(df)
        csv_string = csv_bytes.decode("utf-8")

        # Should not have numeric index column
        lines = csv_string.strip().split("\n")
        assert lines[0] == "id"

    def test_utf8_encoding(self):
        """Test UTF-8 encoding with special characters."""
        df = pd.DataFrame({"name": ["Müller", "Café", "日本語"]})
        csv_bytes = dataframe_to_csv(df)

        # Should decode without error
        csv_string = csv_bytes.decode("utf-8")
        assert "Müller" in csv_string
        assert "Café" in csv_string
        assert "日本語" in csv_string

    def test_empty_dataframe(self):
        """Test conversion of empty DataFrame."""
        df = pd.DataFrame(columns=["id", "name"])
        csv_bytes = dataframe_to_csv(df)

        assert b"id,name" in csv_bytes


class TestExtractErrorMessage:
    """Tests for extract_error_message function."""

    def test_message_field(self):
        """Test extraction from message field."""
        response = {"message": "Resource not found"}
        assert extract_error_message(response) == "Resource not found"

    def test_error_field(self):
        """Test extraction from error field."""
        response = {"error": "invalid_request"}
        assert extract_error_message(response) == "invalid_request"

    def test_error_with_description(self):
        """Test extraction from error with error_description."""
        response = {
            "error": "invalid_client",
            "error_description": "Client authentication failed",
        }
        assert (
            extract_error_message(response)
            == "invalid_client: Client authentication failed"
        )

    def test_errors_list(self):
        """Test extraction from errors list."""
        response = {"errors": ["Field is required", "Invalid format"]}
        assert extract_error_message(response) == "Field is required; Invalid format"

    def test_fallback_to_string(self):
        """Test fallback to string representation."""
        response = {"unknown_field": "some value"}
        result = extract_error_message(response)
        assert "unknown_field" in result

    def test_message_takes_precedence(self):
        """Test that message field takes precedence."""
        response = {
            "message": "Primary message",
            "error": "Secondary error",
            "errors": ["Third option"],
        }
        assert extract_error_message(response) == "Primary message"
