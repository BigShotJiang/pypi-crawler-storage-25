"""Tests for TitanRDMClient."""

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

from titan_rdm_sdk import TitanRDMClient
from titan_rdm_sdk.exceptions import AuthenticationError, ValidationError


class TestClientInitialization:
    """Tests for client initialization."""

    def test_missing_url_raises_validation_error(self):
        """Test that missing URL raises ValidationError."""
        with pytest.raises(ValidationError, match="url is required"):
            TitanRDMClient(url="", client_id="id", client_secret="secret")

    def test_missing_client_id_raises_validation_error(self):
        """Test that missing client_id raises ValidationError."""
        with pytest.raises(ValidationError, match="client_id is required"):
            TitanRDMClient(url="https://example.com", client_id="", client_secret="secret")

    def test_missing_client_secret_raises_validation_error(self):
        """Test that missing client_secret raises ValidationError."""
        with pytest.raises(ValidationError, match="client_secret is required"):
            TitanRDMClient(url="https://example.com", client_id="id", client_secret="")

    def test_none_url_raises_validation_error(self):
        """Test that None URL raises ValidationError."""
        with pytest.raises(ValidationError, match="url is required"):
            TitanRDMClient(url=None, client_id="id", client_secret="secret")

    @patch("titan_rdm_sdk.client.requests.post")
    def test_successful_initialization(self, mock_post):
        """Test successful client initialization."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "token_type": "Bearer",
            "expires_in": 7200,
            "created_at": 1700000000,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        assert client.url == "https://example.com"
        assert client.access_token == "test_token"
        assert client.token_expires_at is not None

    @patch("titan_rdm_sdk.client.requests.post")
    def test_trailing_slash_removed_from_url(self, mock_post):
        """Test that trailing slash is removed from URL."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com/",
            client_id="test_id",
            client_secret="test_secret",
        )

        assert client.url == "https://example.com"


class TestAuthentication:
    """Tests for authentication flow."""

    @patch("titan_rdm_sdk.client.requests.post")
    def test_authentication_failure_raises_error(self, mock_post):
        """Test that authentication failure raises AuthenticationError."""
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.json.return_value = {
            "error": "invalid_client",
            "error_description": "Client authentication failed",
        }
        mock_post.return_value = mock_response

        with pytest.raises(AuthenticationError, match="Authentication failed"):
            TitanRDMClient(
                url="https://example.com",
                client_id="bad_id",
                client_secret="bad_secret",
            )

    @patch("titan_rdm_sdk.client.requests.post")
    def test_authentication_request_format(self, mock_post):
        """Test that authentication request is properly formatted."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        mock_post.assert_called_once()
        call_args = mock_post.call_args
        assert call_args[0][0] == "https://example.com/oauth/token"
        assert call_args[1]["data"]["grant_type"] == "client_credentials"
        assert call_args[1]["data"]["client_id"] == "test_id"
        assert call_args[1]["data"]["client_secret"] == "test_secret"

    @patch("titan_rdm_sdk.client.requests.post")
    def test_connection_error_raises_authentication_error(self, mock_post):
        """Test that connection errors raise AuthenticationError."""
        import requests

        mock_post.side_effect = requests.RequestException("Connection failed")

        with pytest.raises(AuthenticationError, match="Failed to connect"):
            TitanRDMClient(
                url="https://example.com",
                client_id="test_id",
                client_secret="test_secret",
            )


class TestTokenRefresh:
    """Tests for token refresh functionality."""

    @patch("titan_rdm_sdk.client.requests.post")
    def test_token_is_valid_when_not_expired(self, mock_post):
        """Test that token is considered valid when not expired."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        assert client._token_is_valid() is True

    @patch("titan_rdm_sdk.client.requests.post")
    def test_token_is_invalid_when_expired(self, mock_post):
        """Test that token is considered invalid when expired."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        # Set token to expire in the past
        client.token_expires_at = datetime.now(timezone.utc) - timedelta(hours=1)

        assert client._token_is_valid() is False

    @patch("titan_rdm_sdk.client.requests.post")
    def test_token_is_invalid_when_expiring_soon(self, mock_post):
        """Test that token is considered invalid when expiring within 5 minutes."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        # Set token to expire in 3 minutes (less than 5 minute buffer)
        client.token_expires_at = datetime.now(timezone.utc) + timedelta(minutes=3)

        assert client._token_is_valid() is False


class TestGetHeaders:
    """Tests for header generation."""

    @patch("titan_rdm_sdk.client.requests.post")
    def test_get_headers_returns_correct_headers(self, mock_post):
        """Test that headers include authorization and content type."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "test_token_123",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        headers = client._get_headers()

        assert headers["Authorization"] == "Bearer test_token_123"
        assert headers["Content-Type"] == "application/json"
        assert headers["Accept"] == "application/json"


class TestGetDownload:
    """Tests for get_download method."""

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_download_creates_download_instance(self, mock_request, mock_post):
        """Test that get_download returns a Download instance."""
        # Auth response
        mock_auth_response = MagicMock()
        mock_auth_response.status_code = 200
        mock_auth_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_auth_response

        # Export creation response
        mock_export_response = MagicMock()
        mock_export_response.status_code = 201
        mock_export_response.json.return_value = {
            "id": 123,
            "status": "started",
            "branch_id": 174,
            "table_definition_key": 50,
        }
        mock_request.return_value = mock_export_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        download = client.get_download(
            branch_id=174,
            table_definition_key=50,
            pattern="full",
        )

        from titan_rdm_sdk import Download

        assert isinstance(download, Download)
        assert download.id == 123
        assert download.status == "started"


class TestGetUpload:
    """Tests for get_upload method."""

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_upload_creates_upload_instance(self, mock_request, mock_post):
        """Test that get_upload returns an Upload instance."""
        # Auth response
        mock_auth_response = MagicMock()
        mock_auth_response.status_code = 200
        mock_auth_response.json.return_value = {
            "access_token": "test_token",
            "expires_in": 7200,
        }
        mock_post.return_value = mock_auth_response

        # Import creation response
        mock_import_response = MagicMock()
        mock_import_response.status_code = 201
        mock_import_response.json.return_value = {
            "id": 456,
            "status": "created",
            "message": "New Import Created via API",
        }
        mock_request.return_value = mock_import_response

        client = TitanRDMClient(
            url="https://example.com",
            client_id="test_id",
            client_secret="test_secret",
        )

        upload = client.get_upload(
            branch_id=174,
            description="Test upload",
        )

        from titan_rdm_sdk import Upload

        assert isinstance(upload, Upload)
        assert upload.id == 456
        assert upload.status == "created"


class TestGetPaginated:
    """Tests for _get_paginated helper."""

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_single_page(self, mock_request, mock_post):
        """Test pagination with a single page."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [{"id": 1}, {"id": 2}],
            "meta": {"page": 1, "per_page": 100, "total_count": 2, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        result = client._get_paginated("/api/v1/test")

        assert len(result) == 2
        assert result[0]["id"] == 1

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_multiple_pages(self, mock_request, mock_post):
        """Test pagination across multiple pages."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        page1 = MagicMock()
        page1.status_code = 200
        page1.json.return_value = {
            "data": [{"id": 1}, {"id": 2}],
            "meta": {"page": 1, "per_page": 2, "total_count": 3, "total_pages": 2},
        }
        page2 = MagicMock()
        page2.status_code = 200
        page2.json.return_value = {
            "data": [{"id": 3}],
            "meta": {"page": 2, "per_page": 2, "total_count": 3, "total_pages": 2},
        }
        mock_request.side_effect = [page1, page2]

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        result = client._get_paginated("/api/v1/test", per_page=2)

        assert len(result) == 3
        assert [r["id"] for r in result] == [1, 2, 3]


class TestGetBranches:
    """Tests for branch metadata methods."""

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_branches(self, mock_request, mock_post):
        """Test get_branches returns list of Branch objects."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [
                {"id": 1, "name": "prod", "branch_type": "shared", "status": "open"},
                {"id": 5, "name": "dev", "branch_type": "shared", "status": "open"},
            ],
            "meta": {"page": 1, "per_page": 100, "total_count": 2, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        branches = client.get_branches()

        from titan_rdm_sdk import Branch

        assert len(branches) == 2
        assert all(isinstance(b, Branch) for b in branches)
        assert branches[0].name == "prod"
        assert branches[1].name == "dev"

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_branch_by_id(self, mock_request, mock_post):
        """Test get_branch returns a single Branch."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "id": 5,
            "name": "dev",
            "branch_type": "shared",
            "status": "open",
            "parent_branch": {"id": 2, "name": "test"},
            "owner": None,
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        branch = client.get_branch(5)

        from titan_rdm_sdk import Branch

        assert isinstance(branch, Branch)
        assert branch.id == 5
        assert branch.name == "dev"
        assert branch.parent_branch_id == 2

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_branch_by_name(self, mock_request, mock_post):
        """Test get_branch_by_name returns matching Branch."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [{"id": 5, "name": "dev", "branch_type": "shared", "status": "open"}],
            "meta": {"page": 1, "per_page": 100, "total_count": 1, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        branch = client.get_branch_by_name("dev")

        assert branch.name == "dev"

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_branch_by_name_not_found(self, mock_request, mock_post):
        """Test get_branch_by_name raises ValidationError when not found."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [],
            "meta": {"page": 1, "per_page": 100, "total_count": 0, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")

        with pytest.raises(ValidationError, match="No branch found"):
            client.get_branch_by_name("nonexistent")

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_branch_by_name_with_owner_id(self, mock_request, mock_post):
        """Test get_branch_by_name with owner_id filter."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [
                {"id": 10, "name": "feature", "owner": {"id": 1, "email": "a@b.com"}},
                {"id": 11, "name": "feature", "owner": {"id": 2, "email": "c@d.com"}},
            ],
            "meta": {"page": 1, "per_page": 100, "total_count": 2, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        branch = client.get_branch_by_name("feature", owner_id=2)

        assert branch.id == 11
        assert branch.owner_id == 2


class TestGetDomains:
    """Tests for domain metadata methods."""

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_domains(self, mock_request, mock_post):
        """Test get_domains returns list of Domain objects."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [
                {"id": 1, "name": "Customer Data", "abbreviation": "cust"},
                {"id": 2, "name": "Product Data", "abbreviation": "prod"},
            ],
            "meta": {"page": 1, "per_page": 100, "total_count": 2, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        domains = client.get_domains()

        from titan_rdm_sdk import Domain

        assert len(domains) == 2
        assert all(isinstance(d, Domain) for d in domains)
        assert domains[0].name == "Customer Data"

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_domain_by_id(self, mock_request, mock_post):
        """Test get_domain returns a single Domain."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "id": 1,
            "name": "Customer Data",
            "abbreviation": "cust",
            "description": "Customer reference data",
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        domain = client.get_domain(1)

        assert domain.id == 1
        assert domain.name == "Customer Data"

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_domain_by_name(self, mock_request, mock_post):
        """Test get_domain_by_name returns matching Domain."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [{"id": 1, "name": "Customer Data", "abbreviation": "cust"}],
            "meta": {"page": 1, "per_page": 100, "total_count": 1, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        domain = client.get_domain_by_name("Customer Data")

        assert domain.name == "Customer Data"

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_domain_by_name_not_found(self, mock_request, mock_post):
        """Test get_domain_by_name raises ValidationError when not found."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [],
            "meta": {"page": 1, "per_page": 100, "total_count": 0, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")

        with pytest.raises(ValidationError, match="No domain found"):
            client.get_domain_by_name("Nonexistent")


class TestGetDeployedTableDefinitions:
    """Tests for deployed table definition methods."""

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_deployed_table_definitions(self, mock_request, mock_post):
        """Test get_deployed_table_definitions returns list."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [
                {
                    "id": 10,
                    "key": "uuid-1",
                    "name": "customers",
                    "database_table_name": "t_cust_customers",
                    "domain": {"id": 1, "name": "Customer Data", "abbreviation": "cust"},
                    "branch": {"id": 5, "name": "dev"},
                    "column_definitions": [
                        {"id": 100, "name": "customer_id", "data_type": "integer"},
                    ],
                },
            ],
            "meta": {"page": 1, "per_page": 100, "total_count": 1, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        tables = client.get_deployed_table_definitions(branch_id=5, domain_id=1)

        from titan_rdm_sdk import DeployedTableDefinition

        assert len(tables) == 1
        assert isinstance(tables[0], DeployedTableDefinition)
        assert tables[0].name == "customers"
        assert tables[0].database_table_name == "t_cust_customers"
        assert len(tables[0].column_definitions) == 1

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_deployed_table_definitions_passes_params(self, mock_request, mock_post):
        """Test that branch_id and domain_id are passed as query params."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "data": [],
            "meta": {"page": 1, "per_page": 100, "total_count": 0, "total_pages": 1},
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        client.get_deployed_table_definitions(branch_id=5, domain_id=3)

        call_args = mock_request.call_args
        params = call_args[1]["params"]
        assert params["branch_id"] == 5
        assert params["domain_id"] == 3

    @patch("titan_rdm_sdk.client.requests.post")
    @patch("titan_rdm_sdk.client.requests.request")
    def test_get_deployed_table_definition_by_key(self, mock_request, mock_post):
        """Test get_deployed_table_definition lookup by key + branch."""
        mock_auth = MagicMock()
        mock_auth.status_code = 200
        mock_auth.json.return_value = {"access_token": "t", "expires_in": 7200}
        mock_post.return_value = mock_auth

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "id": 10,
            "key": "uuid-1",
            "name": "customers",
            "database_table_name": "t_cust_customers",
            "domain": {"id": 1, "name": "Customer Data"},
            "branch": {"id": 5, "name": "dev"},
            "column_definitions": [
                {"id": 100, "name": "customer_id", "data_type": "integer", "is_primary_key": True},
            ],
        }
        mock_request.return_value = mock_resp

        client = TitanRDMClient(url="https://example.com", client_id="id", client_secret="secret")
        table = client.get_deployed_table_definition(key="uuid-1", branch_id=5)

        from titan_rdm_sdk import DeployedTableDefinition

        assert isinstance(table, DeployedTableDefinition)
        assert table.key == "uuid-1"
        assert table.database_table_name == "t_cust_customers"
