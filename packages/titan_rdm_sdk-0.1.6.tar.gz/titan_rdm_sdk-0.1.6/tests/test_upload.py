"""Tests for Upload class."""

from unittest.mock import MagicMock

import pytest

from titan_rdm_sdk import TitanRDMClient, Upload
from titan_rdm_sdk.exceptions import ValidationError


@pytest.fixture
def mock_client():
    """Create a mock TitanRDMClient."""
    client = MagicMock(spec=TitanRDMClient)
    client.url = "https://example.com"
    client.access_token = "test_token"
    return client


class TestUploadInitialization:
    """Tests for Upload initialization."""

    def test_missing_branch_id_raises_validation_error(self, mock_client):
        """Test that missing branch_id raises ValidationError."""
        with pytest.raises(ValidationError, match="branch_id is required"):
            Upload(
                client=mock_client,
                branch_id=None,
            )

    def test_successful_upload_creation(self, mock_client):
        """Test successful upload creation."""
        mock_client._make_request.return_value = {
            "id": 456,
            "status": "created",
            "message": "New Import Created via API",
            "created_date": "2025-01-22T10:30:00Z",
        }

        upload = Upload(
            client=mock_client,
            branch_id=174,
            description="Test upload",
            correlation_code="batch-001",
        )

        assert upload.id == 456
        assert upload.status == "created"
        assert upload.branch_id == 174

    def test_api_request_payload(self, mock_client):
        """Test that API request is made with correct payload."""
        mock_client._make_request.return_value = {"id": 1, "status": "created"}

        Upload(
            client=mock_client,
            branch_id=174,
            description="Test description",
            correlation_code="test-code",
        )

        mock_client._make_request.assert_called_once_with(
            method="POST",
            endpoint="/api/imports/new",
            json={
                "branch_id": 174,
                "description": "Test description",
                "correlation_code": "test-code",
            },
        )

    def test_optional_parameters_not_included_when_none(self, mock_client):
        """Test that optional parameters are not included when None."""
        mock_client._make_request.return_value = {"id": 1, "status": "created"}

        Upload(
            client=mock_client,
            branch_id=174,
        )

        mock_client._make_request.assert_called_once_with(
            method="POST",
            endpoint="/api/imports/new",
            json={"branch_id": 174},
        )


class TestGetTableUpload:
    """Tests for get_table_upload method."""

    def test_get_table_upload_creates_instance(self, mock_client):
        """Test that get_table_upload returns a TableUpload instance."""
        mock_client._make_request.side_effect = [
            {"id": 456, "status": "created"},  # Upload creation
            {"id": 108},  # Lookup deployed table definition
            {  # Table upload creation
                "id": 789,
                "status": "created",
                "signed_s3_url": "https://s3.example.com/upload",
            },
        ]

        upload = Upload(
            client=mock_client,
            branch_id=174,
        )

        from titan_rdm_sdk import TableUpload

        table_upload = upload.get_table_upload(
            table_definition_key=100,
            import_mapping_key=10,
            pattern="full",
        )

        assert isinstance(table_upload, TableUpload)
        assert table_upload.id == 789
        assert table_upload.signed_s3_url == "https://s3.example.com/upload"


class TestComplete:
    """Tests for complete method."""

    def test_complete_updates_status(self, mock_client):
        """Test that complete updates the upload status."""
        mock_client._make_request.side_effect = [
            {"id": 456, "status": "created"},  # Creation
            {  # Completion
                "id": 456,
                "status": "completed",
                "message": "Import completed successfully",
            },
        ]

        upload = Upload(
            client=mock_client,
            branch_id=174,
        )

        result = upload.complete(message="All done")

        assert result is upload  # Returns self for chaining
        assert upload.status == "completed"

    def test_complete_api_request(self, mock_client):
        """Test that complete makes correct API request."""
        mock_client._make_request.side_effect = [
            {"id": 456, "status": "created"},
            {"id": 456, "status": "completed"},
        ]

        upload = Upload(
            client=mock_client,
            branch_id=174,
        )

        upload.complete(message="Test message")

        # Check the second call (complete)
        calls = mock_client._make_request.call_args_list
        assert calls[1] == (
            (),
            {
                "method": "POST",
                "endpoint": "/api/imports/456/complete",
                "json": {"message": "Test message"},
            },
        )

    def test_complete_without_message(self, mock_client):
        """Test that complete works without a message."""
        mock_client._make_request.side_effect = [
            {"id": 456, "status": "created"},
            {"id": 456, "status": "completed"},
        ]

        upload = Upload(
            client=mock_client,
            branch_id=174,
        )

        upload.complete()

        calls = mock_client._make_request.call_args_list
        assert calls[1] == (
            (),
            {
                "method": "POST",
                "endpoint": "/api/imports/456/complete",
                "json": None,
            },
        )
