import json
import threading
from datetime import datetime
from typing import Any
from kafka import KafkaProducer
from pydantic import BaseModel


class KafkaLoggerSettings(BaseModel):
    app_name: str = "unknown_app"
    bootstrap_servers: list[str] = ["localhost:9092"]
    topic: str = "topic"

class KafkaLogger:
    _producer = None
    _topic = None
    _app_name = None
    _lock = threading.RLock()

    def __init__(self, service: str) -> None:
        self.service = service

    def info(self, msg: str, context: dict[str, Any] = None) -> None:
        self.__log("info", msg, context)

    def warn(self, msg: str, context: dict[str, Any] = None) -> None:
        self.__log("warn", msg, context)

    def error(self, msg: str, context: dict[str, Any] = None) -> None:
        self.__log("error", msg, context)

    def debug(self, msg: str, context: dict[str, Any] = None) -> None:
        self.__log("debug", msg, context)

    def trace(self, msg: str, context: dict[str, Any] = None) -> None:
        self.__log("trace", msg, context)

    def __log(self, level: str, message: str, context: dict[str, Any] = None) -> None:
        if context and (context.get("message") or context.get("source") or context.get("host")):
            raise ValueError("Invalid context")
        try:
            context.update({
                "message": message,
                "level": level,
                "source": KafkaLogger._app_name,
                "service": self.service,
                "ts": datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:23]
            })

            KafkaLogger._producer.send(KafkaLogger._topic, context).get(
                timeout=10
            )
            KafkaLogger._producer.flush(timeout=10)
        except Exception as exc:
            raise Exception("can't log message [" + str(exc) + "]: " + message + "; context:\n" + json.dumps(context))

    @staticmethod
    def close() -> None:
        with KafkaLogger._lock:
            if KafkaLogger._producer is not None:
                KafkaLogger._producer.close()

    @staticmethod
    def init_producer(settings: KafkaLoggerSettings) -> None:
        if KafkaLogger._producer is None:
            with KafkaLogger._lock:
                if KafkaLogger._producer is None:
                    KafkaLogger._topic = settings.topic
                    KafkaLogger._app_name = settings.app_name
                    KafkaLogger._producer = KafkaProducer(
                        bootstrap_servers=settings.bootstrap_servers,
                        client_id=KafkaLogger._app_name + "_client_id",
                        value_serializer=lambda value: json.dumps(value).encode("utf-8"),
                    )
        else:
            raise Exception("Kafka logger already initialized")
