# py_kafka_logger
Gelf logger

config example:
```yaml
kafka_logger:
  app_name: "app_name"
  bootstrap_servers:
    - "serv1:9092"
  topic: "log_topic"
```

usage:
```python
from pathlib import Path

import yaml
import kafka_logger.kafka_logger

path = Path(__file__).resolve().parent / "config.yaml"
with path.open("r", encoding="utf-8") as handle:
    raw_config = (yaml.safe_load(handle) or {"kafka_logger": {}}).get("kafka_logger")
    settings = kafka_logger.kafka_logger.KafkaLoggerSettings(**raw_config)

kafka_logger.kafka_logger.KafkaLogger.init_producer(settings)

kl = kafka_logger.kafka_logger.KafkaLogger("test_service")

kl.info( "test_message", {"test_context": "text_value"})
```
