"""
API Service functionality for Autotrainer.
"""

from typing import Optional

from .api_options import ApiOptions, create_default_api_options
from .api_event_kind import ApiEventKind
from .api_application_mode import ApiApplicationMode
from .api_training_mode import ApiTrainingMode
from .api_status import ApiSystemStatus, ApiPelletStatus, ApiHeadFixStatus, ApiDetectorStatus, ApiAlarmStatus
from .api_alarm_kind import ApiAlarmKind
from .api_detector_kind import ApiDetectorKind
from .api_system_configuration import ApiSystemConfiguration
from .command import ApiCommand
from .rpc_service import ApiTopic, ApiCommandRequest, ApiCommandRequestResponse, ApiCommandRequestResult, \
    ApiCommandRequestErrorKind, RpcService


def create_api_service(options: ApiOptions) -> Optional[RpcService]:
    from .zeromq import ZeroMQApiService

    # TODO Enable when ready
    # configure_telemetry(options.telemetry)

    if options.rpc.enable:
        return ZeroMQApiService(options.rpc)
    else:
        return None
