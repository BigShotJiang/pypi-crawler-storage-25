import math
import socket
from dataclasses import asdict, is_dataclass
from datetime import date, datetime
from enum import Enum
from uuid import UUID


def get_ip4_addr_str() -> str:
    # gethostname() and gethostbyname() and associated IP lookup have proven unreliable on deployed devices where the
    # configuration is not perfect.  This method assumes access to the internet (Google DNS) which has its own
    # limitations.  A more complex implementation to manage all conditions but avoid ending up with 12.0.0.1 when an
    # actual address is available is needed.
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()

    return ip


def prepare_for_serialization(obj):
    """
    Recursively convert non-JSON-native types to JSON-serializable equivalents.

    Unknown types are left as-is so that json.dumps will raise TypeError, preserving the hard-error behavior for
    unhandled types.
    """
    if isinstance(obj, dict):
        return {k: prepare_for_serialization(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [prepare_for_serialization(elem) for elem in obj]
    elif is_dataclass(obj) and not isinstance(obj, type):
        return prepare_for_serialization(asdict(obj))
    elif isinstance(obj, UUID):
        return str(obj)
    elif isinstance(obj, datetime):
        return obj.timestamp()
    elif isinstance(obj, date):
        return obj.isoformat()
    elif isinstance(obj, Enum):
        return obj.value
    elif isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    else:
        return obj
