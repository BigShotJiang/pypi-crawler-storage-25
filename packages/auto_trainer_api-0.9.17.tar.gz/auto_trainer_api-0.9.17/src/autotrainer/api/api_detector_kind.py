from enum import IntEnum


class ApiDetectorKind(IntEnum):
    frontDoor = 101
    slidingDoor = 102

    loadCellThrash = 201
    audioThrash = 202

    pelletMisplaced = 301

    deviceAckTimeOut = 401

    pelletStatusMessageInterruption = 411
    tunnelStatusMessageInterruption = 412

    lowFreeDiskSpace = 501

    pelletRefillCountExceeded = 601
    consectivePelletLoadFailureExceeded = 610
