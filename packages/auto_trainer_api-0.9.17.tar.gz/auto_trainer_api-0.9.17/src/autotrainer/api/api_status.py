from dataclasses import dataclass
from typing import List

from .api_application_mode import ApiApplicationMode
from .api_alarm_kind import ApiAlarmKind
from .api_detector_kind import ApiDetectorKind
from .api_training_mode import ApiTrainingMode

@dataclass(frozen=True)
class ProjectStatus:
    day_path: str           # Absolute path to the current day's directory (currently `location` out of get_day_path())
    session_index: int      # Current session index

@dataclass(frozen=True)
class ApiDetectorStatus:
    detector_id: ApiDetectorKind
    is_active: bool
    is_enabled: bool


@dataclass(frozen=True)
class ApiAlarmStatus:
    alarm_id: ApiAlarmKind
    is_active: bool
    is_enabled: bool


@dataclass(frozen=True)
class ApiHeadFixStatus:
    currentMagnetIntensity: float
    baselineMagnetIntensity: float


@dataclass(frozen=True)
class ApiPelletStatus:
    send_x: float
    send_y: float
    send_z: float


@dataclass(frozen=True)
class ApiSystemStatus:
    application_mode: ApiApplicationMode
    training_mode: ApiTrainingMode

    animal_id: str

    project: ProjectStatus

    alarms: List[ApiAlarmStatus]
    detectors: List[ApiDetectorStatus]

    pellet: ApiPelletStatus
    headfix: ApiHeadFixStatus
