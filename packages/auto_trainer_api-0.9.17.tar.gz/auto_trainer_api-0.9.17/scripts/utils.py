from enum import IntEnum
from typing import Type, TypeVar

T = TypeVar("T", bound=IntEnum)


def resolve_enum(enum_type: Type[T], value: str) -> T:
    """
    Resolve a string to an IntEnum member by numeric value, exact name, or unique prefix.
    """
    # Try numeric value first
    try:
        return enum_type(int(value))
    except (ValueError, KeyError):
        pass

    try:
        return enum_type[value]
    except KeyError:
        pass

    lower = value.lower()
    matches = [m for m in enum_type if m.name.lower().startswith(lower)]

    if len(matches) == 1:
        return matches[0]
    elif len(matches) == 0:
        names = ", ".join(m.name for m in enum_type)
        raise ValueError(f"'{value}' does not match any {enum_type.__name__} member. Valid: {names}")
    else:
        names = ", ".join(m.name for m in matches)
        raise ValueError(f"'{value}' is ambiguous, matches: {names}")
