# Encoder Refactoring Plan

## Problem

The current JSON serialization in `src/autotrainer/api/util.py` has two concerns:

1. **Additive and fragile** — every time a new non-serializable type appears in a message dict, you get a fatal crash in the RPC thread until someone adds another `isinstance` branch to `UUIDEncoder`. The error path in `_send_dict` is an unhandled exception that kills message delivery.

2. **The `patch_uuid_encoder` monkey-patch** (util.py lines 27-32) globally replaces `JSONEncoder.default`, which affects all JSON serialization in the process — not just the API. This is a hidden side-effect that could mask serialization bugs elsewhere.

## Proposed Solution

Replace the `isinstance` chain in `UUIDEncoder` with a **recursive pre-processing step** that normalizes non-JSON-native types into JSON-native types before calling `json.dumps`.

### Details

- Create a single recursive dict-walker (similar to the existing `replace_nan_with_null` in `util.py`) that handles all type conversions: `UUID` → `str`, `datetime` → `float` (timestamp), `date` → `str` (isoformat), `Enum` → value, dataclasses → dict, NaN/Inf → None.
- This would **replace both** `replace_nan_with_null` and `UUIDEncoder` with one unified pre-processing function.
- After pre-processing, `json.dumps` can be called with the default encoder (no `cls=` argument).
- Remove the `patch_uuid_encoder` monkey-patch entirely. Audit callers to ensure they go through `_dictionary_to_json_bytes` or the new preprocessing function instead of relying on the global patch.

### Key files

- `src/autotrainer/api/util.py` — `UUIDEncoder`, `replace_nan_with_null`, `patch_uuid_encoder`
- `src/autotrainer/api/rpc_service.py` — `_dictionary_to_json_bytes` (line 25-28), `_ApiCommandRequestServiceResponse.as_bytes` (line 163-194)
- `src/autotrainer/api/zeromq/zeromq_api_service.py` — calls `_send_dict` → `dictionary_to_json_bytes`

### Error handling consideration

The hard-error behavior for unknown types is the **right default** — silently dropping or skipping unserializable properties would be worse since there is no way to signal to the caller that a property was omitted.

The `_ApiCommandRequestServiceResponse.as_bytes` method already demonstrates the correct pattern for graceful degradation: try to serialize, and on failure, return a degraded response with an error indicator. That same pattern could be extended to `send_dict` publishing if needed, rather than letting the exception propagate uncaught into the RPC thread.

### Callers of `patch_uuid_encoder` to audit

Search for usages of `patch_uuid_encoder()` in the consuming codebase to ensure they are migrated to use `_dictionary_to_json_bytes` or the new preprocessing function directly.
