# ZMQ Assertion Failure Review

`Assertion failed: check () (src/msg.cpp:387)` — root cause analysis and recommendations.

---

## 1. CRITICAL — Heartbeat Timer Sends on ZMQ Socket from Wrong Thread

**File:** `rpc_service.py:440-445`

`threading.Timer` fires its callback on a **new thread** each time. `_heartbeat_timer_callback` directly calls `self._send_dict()`, which resolves to `ZeroMQApiService._send_dict` → `_send()` → `self._pub_socket.send()`. This means the ZMQ PUB socket is used from the Timer's thread, while it was created on and is primarily used by the RpcServiceThread.

```python
def _heartbeat_timer_callback(self):
    # Must happen on the queue processing thread.   <-- Comment acknowledges the requirement!
    if not self._termination_requested:
        self._heartbeat.timestamp = time.time()
        self._send_dict(ApiTopic.HEARTBEAT, asdict(self._heartbeat))  # WRONG THREAD
        self._queue_heartbeat()
```

The comment says "Must happen on the queue processing thread" but the implementation does not honor that — `Timer` fires on its own thread. This is **the most likely cause** of the intermittent ZMQ assertion failure.

**Fix:** Queue the heartbeat onto the RPC thread instead of sending directly:

```python
def _heartbeat_timer_callback(self):
    if not self._termination_requested:
        self._heartbeat.timestamp = time.time()
        self._queue.put(lambda: self._send_dict(ApiTopic.HEARTBEAT, asdict(self._heartbeat)))
        self._queue_heartbeat()
```

---

## 2. Socket Cleanup Uses `disconnect()` Instead of `unbind()` + `close()`

**File:** `zeromq_api_service.py:58-66`

The sockets are opened with `bind()` but torn down with `disconnect()`. For bound sockets, the correct teardown is `unbind()` then `close()`. `disconnect()` is the counterpart to `connect()`, not `bind()`. Using the wrong call can leave the socket in an inconsistent internal state, which could contribute to assertion failures during shutdown or rapid restart cycles.

```python
def _stop(self):
    if self._pub_socket is not None:
        for address in self._pub_addresses:
            self._pub_socket.disconnect(address)   # Should be unbind()
        self._pub_socket = None                     # Never close()-d
```

**Fix:** Use `unbind()` then `close()`:

```python
def _stop(self):
    if self._pub_socket is not None:
        for address in self._pub_addresses:
            self._pub_socket.unbind(address)
        self._pub_socket.close()
        self._pub_socket = None
    if self._cmd_socket is not None:
        for address in self._cmd_addresses:
            self._cmd_socket.unbind(address)
        self._cmd_socket.close()
        self._cmd_socket = None
```

---

## 3. Two Separate ZMQ Contexts / Contexts Not Stored or Terminated

**File:** `zeromq_api_service.py:36-49`

Two separate `zmq.Context()` instances are created (one per socket), assigned to a local variable, and never stored. The contexts are never `term()`-ed on shutdown. While the sockets keep internal references preventing premature GC, the contexts cannot be cleanly shut down without a reference.

Using a single shared context is the standard ZMQ pattern and avoids unnecessary overhead.

```python
context = zmq.Context()
self._pub_socket = context.socket(zmq.PUB)
...
context = zmq.Context()       # second context, local var shadows first
self._cmd_socket = context.socket(zmq.REP)
```

**Fix:** Create one context in `_start()`, store it as `self._context`, and call `self._context.term()` in `_stop()` after closing sockets.

---

## 4. Socket Leak on Partial `_start()` Failure

**File:** `zeromq_api_service.py:36-56`

If the PUB socket binds successfully but the REP socket fails, the except block sets both to `None` without closing the already-bound PUB socket. The socket (and its context) leak.

**Fix:** Close any successfully created sockets in the except handler before setting to None.

---

## 5. `_send_string` Passes Bytes to `dictionary_to_json_bytes`

**File:** `zeromq_api_service.py:76-77`

```python
def _send_string(self, topic: ApiTopic, message: str):
    self._send(topic, RpcService.dictionary_to_json_bytes(message.encode("utf8")))
```

`message.encode("utf8")` produces `bytes`, but `dictionary_to_json_bytes()` expects a `Dict[str, Any]`. This will pass `bytes` through `replace_nan_with_null` (returns it unchanged), then into `humps.camelize(bytes_obj)` which will produce incorrect output or raise an exception. The result could be malformed data sent to ZMQ.

**Fix:** Should be `self._send(topic, message.encode("utf8"))` — the string is already the message content, no dict serialization needed.

---

## 6. `as_bytes()` Fallback Mutates Frozen Dataclass

**File:** `rpc_service.py:163-194`

`_ApiCommandRequestServiceResponse` is `@dataclass(frozen=True)`, but the fallback path in `as_bytes()` mutates `self.__dict__` directly, bypassing frozen protection:

```python
contents = self.__dict__        # reference, not copy
contents["data"] = None         # mutates the frozen instance
contents["error_kind"] = ...
```

This silently corrupts the frozen dataclass's internal state. While unlikely to cause the ZMQ assertion directly (it's an error path), the corrupted object could produce unexpected serialization output if referenced again.

**Fix:** Use `contents = dict(self.__dict__)` to operate on a copy.

---

## Priority

| # | Issue | Severity | Likely Cause of Assert |
|---|-------|----------|----------------------|
| 1 | Heartbeat timer thread safety | Critical | **Yes — most likely** |
| 2 | disconnect() vs unbind()/close() | High | Possible on shutdown/restart |
| 3 | Contexts not stored/terminated | Medium | Unlikely but poor practice |
| 4 | Socket leak on partial start | Medium | Unlikely |
| 5 | _send_string type mismatch | Medium | Possible if method is used |
| 6 | Frozen dataclass mutation | Low | Unlikely |
