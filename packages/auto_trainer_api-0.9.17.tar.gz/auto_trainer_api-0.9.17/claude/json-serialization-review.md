There is a bit of extra handling in the JSON serialization such as the UUIDEncoder that handles UUIDs and
datetime objects (not well named).

We are now getting exceptions for `date` objects (see exception below).

Confirm that this is infact because of `date` type vs `datetime`.  Add support in the `UUIDEncoder` for `date` objects
if that is in fact the case.

Also, recommend but do not implement, a better solution to this problem if there is one.  I want to be
careful about silently ignoring exceptions in the JSON serialization and skipping over those properties.

There is usually no way to tell the caller that the property was not serialized so if we don't hard-error
I think we will silently ignore properties that are not serializable.


The exception:
10:48:08.098560 ERROR autotrainer.core.logging[MainProcess.12917-RpcServiceThread.13036] Fatal unhandled thread exception: Object of type date is not JSON serializable
Traceback (most recent call last):
  File "/usr/lib/python3.8/threading.py", line 932, in _bootstrap_inner
    self.run()
  File "/usr/lib/python3.8/threading.py", line 870, in run
    self._target(*self._args, **self._kwargs)
  File "/home/greg/Projects/toptal/Anschutz/auto-trainer-api/src/autotrainer/api/rpc_service.py", line 418, in _run
    action()
  File "/home/greg/Projects/toptal/Anschutz/auto-trainer-api/src/autotrainer/api/rpc_service.py", line 345, in <lambda>
    self._queue.put(lambda: self._send_dict(topic, message))
  File "/home/greg/Projects/toptal/Anschutz/auto-trainer-api/src/autotrainer/api/zeromq/zeromq_api_service.py", line 92, in _send_dict
    self._send(topic, RpcService.dictionary_to_json_bytes(message))
  File "/home/greg/Projects/toptal/Anschutz/auto-trainer-api/src/autotrainer/api/rpc_service.py", line 354, in dictionary_to_json_bytes
    return _dictionary_to_json_bytes(obj)
  File "/home/greg/Projects/toptal/Anschutz/auto-trainer-api/src/autotrainer/api/rpc_service.py", line 28, in _dictionary_to_json_bytes
    return json.dumps(humps.camelize(safe_dict), cls=UUIDEncoder).encode("utf8")
  File "/usr/lib/python3.8/json/__init__.py", line 234, in dumps
    return cls(
  File "/usr/lib/python3.8/json/encoder.py", line 199, in encode
    chunks = self.iterencode(o, _one_shot=True)
  File "/usr/lib/python3.8/json/encoder.py", line 257, in iterencode
    return _iterencode(o, 0)
  File "/home/greg/Projects/toptal/Anschutz/auto-trainer-api/src/autotrainer/api/util.py", line 41, in default
    return super().default(obj)
  File "/usr/lib/python3.8/json/encoder.py", line 179, in default
    raise TypeError(f'Object of type {o.__class__.__name__} '