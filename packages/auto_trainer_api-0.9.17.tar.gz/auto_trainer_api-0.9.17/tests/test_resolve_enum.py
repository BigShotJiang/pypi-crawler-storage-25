import pytest

from autotrainer.api import ApiDetectorKind, ApiAlarmKind
from scripts.utils import resolve_enum


class TestResolveEnum:
    """Verify resolve_enum handles numeric, exact, prefix, and error cases."""

    def test_numeric_value(self):
        assert resolve_enum(ApiDetectorKind, "101") == ApiDetectorKind.frontDoor

    def test_exact_name(self):
        assert resolve_enum(ApiDetectorKind, "frontDoor") == ApiDetectorKind.frontDoor

    def test_unique_prefix(self):
        assert resolve_enum(ApiDetectorKind, "fr") == ApiDetectorKind.frontDoor

    def test_unique_prefix_case_insensitive(self):
        assert resolve_enum(ApiDetectorKind, "FR") == ApiDetectorKind.frontDoor

    def test_ambiguous_prefix_raises(self):
        # "l" matches loadCellThrash and lowFreeDiskSpace
        with pytest.raises(ValueError, match="ambiguous"):
            resolve_enum(ApiDetectorKind, "l")
        with pytest.raises(ValueError, match="ambiguous"):
            resolve_enum(ApiDetectorKind, "lo")

    def test_longer_prefix_resolves_ambiguity(self):
        assert resolve_enum(ApiDetectorKind, "loa") == ApiDetectorKind.loadCellThrash
        assert resolve_enum(ApiDetectorKind, "low") == ApiDetectorKind.lowFreeDiskSpace

    def test_no_match_raises(self):
        with pytest.raises(ValueError, match="does not match"):
            resolve_enum(ApiDetectorKind, "nonexistent")

    def test_invalid_numeric_raises(self):
        with pytest.raises(ValueError):
            resolve_enum(ApiDetectorKind, "99")

    def test_works_with_alarm_kind(self):
        assert resolve_enum(ApiAlarmKind, "thr") == ApiAlarmKind.thrashing
        assert resolve_enum(ApiAlarmKind, "301") == ApiAlarmKind.thrashing
