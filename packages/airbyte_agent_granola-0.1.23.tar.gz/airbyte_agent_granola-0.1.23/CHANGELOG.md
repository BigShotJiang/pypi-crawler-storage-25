# Granola changelog

## [0.1.23] - 2026-04-03
- Updated connector definition (YAML version 1.0.4)
- Source commit: 525a1c0f
- SDK version: 0.1.0

## [0.1.22] - 2026-04-01
- Updated connector definition (YAML version 1.0.3)
- Source commit: e4c74933
- SDK version: 0.1.0

## [0.1.21] - 2026-04-01
- Updated connector definition (YAML version 1.0.3)
- Source commit: 513344c6
- SDK version: 0.1.0

## [0.1.20] - 2026-03-26
- Updated connector definition (YAML version 1.0.3)
- Source commit: 75f38884
- SDK version: 0.1.0

## [0.1.19] - 2026-03-26
- Updated connector definition (YAML version 1.0.3)
- Source commit: 20f00dda
- SDK version: 0.1.0

## [0.1.18] - 2026-03-25
- Updated connector definition (YAML version 1.0.3)
- Source commit: bbb46256
- SDK version: 0.1.0

## [0.1.17] - 2026-03-23
- Updated connector definition (YAML version 1.0.3)
- Source commit: 6ad04bc3
- SDK version: 0.1.0

## [0.1.16] - 2026-03-23
- Updated connector definition (YAML version 1.0.3)
- Source commit: 5718dee3
- SDK version: 0.1.0

## [0.1.15] - 2026-03-12
- Updated connector definition (YAML version 1.0.3)
- Source commit: b541ca65
- SDK version: 0.1.0

## [0.1.14] - 2026-03-11
- Updated connector definition (YAML version 1.0.3)
- Source commit: 44677ecb
- SDK version: 0.1.0

## [0.1.13] - 2026-03-09
- Updated connector definition (YAML version 1.0.3)
- Source commit: d395373b
- SDK version: 0.1.0

## [0.1.12] - 2026-03-05
- Updated connector definition (YAML version 1.0.2)
- Source commit: e50d6dd2
- SDK version: 0.1.0

## [0.1.11] - 2026-03-03
- Updated connector definition (YAML version 1.0.2)
- Source commit: 9808f8a1
- SDK version: 0.1.0

## [0.1.10] - 2026-03-03
- Updated connector definition (YAML version 1.0.2)
- Source commit: 258f32e0
- SDK version: 0.1.0

## [0.1.9] - 2026-02-27
- Updated connector definition (YAML version 1.0.2)
- Source commit: a735c402
- SDK version: 0.1.0

## [0.1.8] - 2026-02-27
- Updated connector definition (YAML version 1.0.2)
- Source commit: 7bd29cad
- SDK version: 0.1.0

## [0.1.7] - 2026-02-27
- Updated connector definition (YAML version 1.0.2)
- Source commit: 39690c8e
- SDK version: 0.1.0

## [0.1.6] - 2026-02-26
- Updated connector definition (YAML version 1.0.2)
- Source commit: 9072a725
- SDK version: 0.1.0

## [0.1.5] - 2026-02-23
- Updated connector definition (YAML version 1.0.2)
- Source commit: 62fbfc1f
- SDK version: 0.1.0

## [0.1.4] - 2026-02-20
- Updated connector definition (YAML version 1.0.2)
- Source commit: fc238ee4
- SDK version: 0.1.0

## [0.1.3] - 2026-02-20
- Updated connector definition (YAML version 1.0.1)
- Source commit: cb4380e7
- SDK version: 0.1.0

## [0.1.2] - 2026-02-19
- Updated connector definition (YAML version 1.0.1)
- Source commit: 7cda3ed1
- SDK version: 0.1.0

## [0.1.1] - 2026-02-19
- Updated connector definition (YAML version 1.0.1)
- Source commit: 3f4da97b
- SDK version: 0.1.0

## [0.1.0] - 2026-02-12
- Updated connector definition (YAML version 1.0.1)
- Source commit: 7afbc8f0
- SDK version: 0.1.0
