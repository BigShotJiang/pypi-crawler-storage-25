"""Vendored connector-sdk runtime."""
