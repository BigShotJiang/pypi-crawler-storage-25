# easylabs

Python SDK for the [Easy Labs](https://itseasy.co) API.

> Status: `0.1.0` — feature parity with `@easylabs/node@0.1.0`. Sync-only
> in this release; async (`easylabs.aio.Client`) is planned for `0.2`.

## Install

```bash
pip install easylabs
# or
uv add easylabs
```

Requires Python `>= 3.10`.

## Quickstart

```python
import os
from easylabs import Client

client = Client(api_key=os.environ["EASY_API_KEY"])

customer = client.customers.create(
    first_name="Ada",
    last_name="Lovelace",
    email="ada@example.com",
)

subscription = client.subscriptions.create(
    identity_id=customer["id"],
    items=[{"price_id": "price_…"}],
)
```

## Authentication

Pass your secret API key as `api_key=`. Keys prefixed `sk_test_` are
automatically routed to the sandbox environment; production keys go to
production. Override the URL with `internal_api_url=` for self-hosted /
testing setups.

```python
client = Client(api_key="sk_test_…")            # sandbox
client = Client(api_key="sk_live_…")            # production
client = Client(api_key="sk_test_…",
                internal_api_url="http://localhost:4000/v1/api")  # tests / self-hosted
```

## Resources

Resources are namespaced on the client:

| Namespace | Highlights |
|---|---|
| `client.customers` | `create`, `update`, `retrieve`, `list`, `payment_instruments`, `orders`, `subscriptions`, `wallets` |
| `client.payment_instruments` | `create`, `update` |
| `client.transfers` | `create`, `update`, `retrieve`, `list`, `create_refund` |
| `client.disputes` | `retrieve`, `list`, `update` |
| `client.settlements` | `retrieve`, `list`, `close` |
| `client.products` | `create`, `update`, `retrieve`, `list`, `archive`, `with_price`, `with_prices` |
| `client.product_prices` | `create`, `update`, `retrieve`, `list`, `archive` |
| `client.orders` | `retrieve`, `list`, `update_tags` |
| `client.subscriptions` | `create`, `update`, `retrieve`, `list`, `cancel`, `pause`, `resume`, `proration_preview`, `add_item`, `update_item`, `remove_item`, `apply_discount`, `list_discounts`, `remove_discount`, `create_one_time_charge`, `report_usage`, `usage_summary`, `usage_reconciliation` |
| `client.checkout` | `create` |
| `client.payment_links` | `create` |
| `client.embedded_checkout` | `create_session`, `retrieve_session`, `crypto_status`, `validate`, `confirm`, `get_config`, `update_config` |
| `client.webhooks_management` | `register`, `list`, `update`, `delete`, `list_deliveries`, `list_endpoint_deliveries` |
| `client.invoices` | `create`, `list`, `retrieve`, `update`, `send_invoice`, `pay`, `remind`, `void`, `pdf_data` |
| `client.coupons` | `create`, `list`, `retrieve`, `update`, `delete` |
| `client.promotion_codes` | `create`, `list`, `retrieve`, `update`, `delete`, `validate` |
| `client.authorizations` | `list`, `retrieve`, `capture`, `void` |
| `client.analytics` | `transactions`, `disputes`, `settlements`, `revenue`, `revenue_recovery` |
| `client.compliance_forms` | `list`, `retrieve`, `sign` |
| `client.dunning_config` | `create_or_replace`, `retrieve`, `update` |
| `client.revenue_recovery_automations` | `list`, `create`, `update`, `delete`, `list_runs` |

## Webhooks

```python
from easylabs import Webhooks

@app.post("/webhooks/easy")
def receive(request):
    event = Webhooks.construct_event(
        payload=request.body,
        signature=request.headers.get("x-easy-webhook-signature", ""),
        secret=os.environ["EASY_WEBHOOK_SECRET"],
    )
    # event.type, event.data, event.id ...
    return ("", 204)
```

## Errors

```python
from easylabs import Client, RateLimitError, EasyError

try:
    client.subscriptions.cancel("sub_123")
except RateLimitError as e:
    time.sleep(e.retry_after_seconds or 1)
except EasyError as e:
    print(e.status, e.code, e.details)
    raise
```

## License

MIT
