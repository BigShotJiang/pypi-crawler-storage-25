# easylabs (Python)

## 0.1.1

### Removed

- The `dev=True` keyword argument on `Client(...)` and the matching
  `EASY_API_URL_DEV` constant in `easylabs._api_url`. The internal Easy
  Labs dev environment URL is no longer baked into the public package.
  Internal callers who genuinely need to point at a non-public host
  should pass `internal_api_url="https://..."` to `Client(...)`.

  Migration: replace `Client(api_key=..., dev=True)` with
  `Client(api_key=..., internal_api_url="https://...")` if you were
  using it. The standard `sk_test_` → sandbox / `sk_live_` → production
  routing is unchanged.

## 0.1.0

First published release of the Python SDK, mirroring `@easylabs/node@0.1.0`.

### Added

- `easylabs.Client` — instance-style API client (mirrors `createClient` in the
  Node SDK) with namespaced resources (`client.customers.create(...)`).
- HTTP transport built on `httpx`, supporting query encoding, JSON bodies,
  optional `Idempotency-Key` header, and `skipAuth` for embedded-checkout
  public endpoints (`validate` / `confirm`).
- Sandbox / production URL routing — keys prefixed `sk_test_` route to
  `https://sandbox-api.itseasy.co/v1/api`; everything else routes to
  `https://api.itseasy.co/v1/api`. An `internal_api_url=` override is
  available for tests and self-hosted setups.
- Full resource surface (~80 methods across 21 namespaces): customers,
  payment instruments, transfers (incl. refunds), disputes, settlements,
  products, product prices, orders, subscriptions (incl. items, discounts,
  usage, one-time charges, proration preview, pause/resume), checkout,
  payment links, embedded checkout (incl. config + crypto status), webhook
  endpoints (incl. delivery listings), invoices, coupons, promotion codes,
  authorizations, analytics, compliance forms, dunning config, and revenue
  recovery automations.
- `easylabs.Webhooks.construct_event(...)` — verifies HMAC-SHA256 webhook
  signatures with `hmac.compare_digest` and parses the payload into a typed
  `WebhookEvent` Pydantic model.
- `EASY_EVENT_TYPES` constant — full catalog of webhook event types.
- Error class hierarchy under `easylabs.error.EasyError` with HTTP-status
  subclasses (`AuthenticationError`, `PermissionError`, `NotFoundError`,
  `ConflictError`, `RateLimitError`, `InvalidRequestError`, `ServerError`)
  plus `status`, `code`, `details`, `retry_after_seconds`, and `raw` fields.
- Pydantic v2 response models with `extra="allow"` for forward compatibility.
