"""Webhook signature verifier — port of `packages/easy-node/src/webhooks.ts`.

`Webhooks.construct_event` verifies the `x-easy-webhook-signature` header
against the raw request body using HMAC-SHA256 with `hmac.compare_digest`,
then parses the body into a typed `WebhookEvent`.

The error codes match the Node SDK: `WEBHOOK_SIGNATURE_MISSING`,
`WEBHOOK_SIGNATURE_FORMAT_INVALID`, `WEBHOOK_SIGNATURE_MISMATCH`,
`WEBHOOK_BODY_INVALID_JSON`. All raise `InvalidRequestError` (HTTP 400).
"""

from __future__ import annotations

import hashlib
import hmac
import json

from .error import InvalidRequestError
from .models import WebhookEvent

_SIGNATURE_PREFIX = "sha256="

EVENT_TYPES: tuple[str, ...] = (
    "payment.created",
    "payment.updated",
    "refund.created",
    "refund.updated",
    "authorization.created",
    "authorization.updated",
    "authorization.voided",
    "subscription.created",
    "subscription.updated",
    "subscription.deleted",
    "subscription.paused",
    "subscription.resumed",
    "subscription.trial_will_end",
    "subscription.pending_update_applied",
    "subscription.pending_update_expired",
    "invoice.created",
    "invoice.finalized",
    "invoice.paid",
    "invoice.payment_failed",
    "invoice.upcoming",
    "invoice.voided",
    "invoice.marked_uncollectible",
    "revenue_recovery.action_completed",
    "coupon.created",
    "coupon.updated",
    "coupon.deleted",
    "promotion_code.created",
    "promotion_code.updated",
    "promotion_code.deleted",
    "identity.created",
    "identity.updated",
    "settlement.created",
    "dispute.created",
    "dispute.updated",
    "checkout.session.completed",
    "checkout.session.crypto_confirmed",
    "test.webhook",
)


class Webhooks:
    """Static utility namespace mirroring `EasyWebhooks` in the Node SDK."""

    EVENT_TYPES: tuple[str, ...] = EVENT_TYPES

    @staticmethod
    def construct_event(
        *,
        payload: bytes | str,
        signature: str,
        secret: str,
    ) -> WebhookEvent:
        """Verify the signature on a webhook delivery and parse the body.

        Args:
            payload:    The exact request body — bytes preferred. JSON
                        re-stringifying changes whitespace and breaks the
                        signature comparison.
            signature:  The value of the `x-easy-webhook-signature` header
                        on the inbound request, e.g. `sha256=<hex>`.
            secret:     The endpoint signing secret returned (once) by
                        `register`.

        Raises:
            InvalidRequestError (status=400) on missing / malformed /
            mismatched signatures and non-JSON bodies. Inspect `.code`
            for the specific failure reason.
        """
        if not signature:
            raise InvalidRequestError(
                "Missing webhook signature header",
                status=400,
                code="WEBHOOK_SIGNATURE_MISSING",
            )

        if not signature.startswith(_SIGNATURE_PREFIX):
            raise InvalidRequestError(
                f'Webhook signature must be prefixed with "{_SIGNATURE_PREFIX}"',
                status=400,
                code="WEBHOOK_SIGNATURE_FORMAT_INVALID",
            )

        provided_hex = signature[len(_SIGNATURE_PREFIX) :]
        body_bytes: bytes = payload if isinstance(payload, bytes) else payload.encode("utf-8")
        expected_hex = hmac.new(secret.encode("utf-8"), body_bytes, hashlib.sha256).hexdigest()

        try:
            provided_bytes = bytes.fromhex(provided_hex)
            expected_bytes = bytes.fromhex(expected_hex)
        except ValueError as exc:
            raise InvalidRequestError(
                "Webhook signature is not valid hex",
                status=400,
                code="WEBHOOK_SIGNATURE_FORMAT_INVALID",
            ) from exc

        if len(provided_bytes) != len(expected_bytes) or not hmac.compare_digest(
            provided_bytes, expected_bytes
        ):
            raise InvalidRequestError(
                "Webhook signature does not match expected value",
                status=400,
                code="WEBHOOK_SIGNATURE_MISMATCH",
            )

        try:
            parsed = json.loads(body_bytes)
        except (ValueError, json.JSONDecodeError) as exc:
            raise InvalidRequestError(
                "Webhook body is not valid JSON",
                status=400,
                code="WEBHOOK_BODY_INVALID_JSON",
            ) from exc

        return WebhookEvent.model_validate(parsed)
