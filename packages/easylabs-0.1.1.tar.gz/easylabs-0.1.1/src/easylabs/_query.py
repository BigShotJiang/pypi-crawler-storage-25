"""URL query encoding helpers.

Mirrors the JS SDK's `URLSearchParams` usage in `EasyApiClient`:

  - drop `None` values
  - lists join on `,`
  - booleans render as the lowercase strings `"true"` / `"false"`
  - numbers render via `str(...)`
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any
from urllib.parse import urlencode


def encode(params: Mapping[str, Any] | None) -> str:
    """Encode a query mapping. Returns `""` if no usable params remain."""
    if not params:
        return ""
    pairs: list[tuple[str, str]] = []
    for key, value in params.items():
        if value is None:
            continue
        pairs.append((key, _stringify(value)))
    if not pairs:
        return ""
    return urlencode(pairs)


def _stringify(value: Any) -> str:
    if isinstance(value, bool):
        # Must come before `int` because bool is a subclass of int.
        return "true" if value else "false"
    if isinstance(value, (str, int, float)):
        return str(value)
    if isinstance(value, Iterable):
        return ",".join(_stringify(item) for item in value)
    return str(value)
