"""Subscription response models.

See TS `SubscriptionData`, `SubscriptionItem`, and `SubscriptionDiscount`
in `packages/common/src/types.ts` for the canonical wire shapes.
"""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class SubscriptionItem(EasyModel):
    id: str
    subscription_id: str | None = None
    price_id: str | None = None
    quantity: int | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None


class SubscriptionDiscount(EasyModel):
    id: str
    subscription_id: str | None = None
    subscription_item_id: str | None = None
    coupon_id: str | None = None
    promotion_code_id: str | None = None
    start: str | None = None
    end: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class Subscription(EasyModel):
    id: str
    identity_id: str | None = None
    status: str | None = None
    items: list[SubscriptionItem] | None = None
    current_period_start: str | None = None
    current_period_end: str | None = None
    billing_cycle_anchor: str | None = None
    cancel_at_period_end: bool | None = None
    pause_collection: dict[str, Any] | None = None
    latest_invoice_id: str | None = None
    proration_behavior: str | None = None
    credit_balance: int | None = None
    pending_update: dict[str, Any] | None = None
    trial_end: str | None = None
    description: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None


class SubscriptionPlan(EasyModel):
    """Deprecated read-back type kept for the legacy Finix engine."""

    id: str
    name: str | None = None
    state: str | None = None
    amount: int | None = None
    currency: str | None = None
    interval_type: str | None = None
    interval_count: int | None = None
