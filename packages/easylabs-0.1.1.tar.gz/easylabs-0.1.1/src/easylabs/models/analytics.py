"""Analytics response model — generic envelope; shape varies per endpoint."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class AnalyticsResult(EasyModel):
    """Aggregator response. Concrete shape depends on the endpoint —
    use `model_dump()` to get the full payload."""

    period: str | None = None
    start_date: str | None = None
    end_date: str | None = None
    totals: dict[str, Any] | None = None
    series: list[dict[str, Any]] | None = None
