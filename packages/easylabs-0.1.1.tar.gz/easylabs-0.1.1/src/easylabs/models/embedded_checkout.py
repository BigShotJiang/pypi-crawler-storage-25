"""Embedded checkout models — see TS `EmbeddedCheckoutSessionData` and friends."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class EmbeddedCheckoutSession(EasyModel):
    id: str
    client_secret: str | None = None
    status: str | None = None
    expires_at: str | None = None
    return_url: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class EmbeddedCheckoutSessionStatus(EasyModel):
    id: str
    status: str | None = None
    payment_status: str | None = None


class CryptoPaymentStatus(EasyModel):
    status: str | None = None
    tx_signature: str | None = None
    payment_address: str | None = None
    chain: str | None = None
    asset: str | None = None
    amount: str | None = None


class ValidateEmbeddedCheckoutSessionResponse(EasyModel):
    valid: bool | None = None
    session: dict[str, Any] | None = None


class EmbeddedCheckoutConfig(EasyModel):
    allowed_origins: list[str] | None = None
    updated_at: str | None = None
