"""Base model for every Easy Labs response model."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class EasyModel(BaseModel):
    """Base for SDK response models.

    `extra="allow"` is critical for forward compatibility: when the API
    adds fields, old SDK versions still receive and surface them. Callers
    can always reach the raw shape via `model.model_dump()`.
    """

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
        protected_namespaces=(),
    )
