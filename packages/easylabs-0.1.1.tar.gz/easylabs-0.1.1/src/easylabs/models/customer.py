"""Customer response model — see TS `CustomerData` in packages/common/src/types.ts."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Customer(EasyModel):
    id: str
    created_at: str | None = None
    updated_at: str | None = None
    type: str | None = None
    application: str | None = None
    identity_roles: list[str] | None = None
    entity: dict[str, Any] | None = None
    tags: dict[str, Any] | None = None
