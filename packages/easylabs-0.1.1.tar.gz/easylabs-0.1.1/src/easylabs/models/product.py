"""Product response model — see TS `ProductData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Product(EasyModel):
    id: str
    name: str | None = None
    description: str | None = None
    active: bool | None = None
    default_price_id: str | None = None
    price_ids: list[str] | None = None
    metadata: dict[str, Any] | None = None
    images: list[str] | None = None
    company_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
