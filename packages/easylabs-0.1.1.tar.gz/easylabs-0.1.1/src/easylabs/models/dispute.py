"""Dispute response model — see TS `DisputeData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Dispute(EasyModel):
    id: str
    state: str | None = None
    reason: str | None = None
    amount: int | None = None
    currency: str | None = None
    transfer: str | None = None
    tags: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
