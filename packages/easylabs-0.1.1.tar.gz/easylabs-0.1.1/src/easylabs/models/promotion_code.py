"""Promotion code response model — see TS `PromotionCodeData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class PromotionCode(EasyModel):
    id: str
    code: str | None = None
    coupon_id: str | None = None
    active: bool | None = None
    max_redemptions: int | None = None
    times_redeemed: int | None = None
    expires_at: str | None = None
    customer_id: str | None = None
    minimum_amount: int | None = None
    minimum_amount_currency: str | None = None
    first_time_transaction: bool | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None


class ValidatePromotionCodeResponse(EasyModel):
    valid: bool
    promotion_code: PromotionCode | None = None
    coupon: dict[str, Any] | None = None
    discount_preview: dict[str, Any] | None = None
    reason: str | None = None
