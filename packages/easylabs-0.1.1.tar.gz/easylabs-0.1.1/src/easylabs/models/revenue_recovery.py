"""Revenue recovery automation model — see TS `CreateRevenueRecoveryAutomation`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class RevenueRecoveryAutomation(EasyModel):
    id: str
    name: str | None = None
    enabled: bool | None = None
    trigger: str | None = None
    conditions: list[dict[str, Any]] | None = None
    actions: list[dict[str, Any]] | None = None
    created_at: str | None = None
    updated_at: str | None = None


class RevenueRecoveryAutomationRun(EasyModel):
    id: str
    automation_id: str | None = None
    status: str | None = None
    triggered_at: str | None = None
    completed_at: str | None = None
    metadata: dict[str, Any] | None = None
