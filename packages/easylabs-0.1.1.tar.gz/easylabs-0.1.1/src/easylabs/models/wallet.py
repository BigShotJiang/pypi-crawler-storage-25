"""Wallet response model — see TS `WalletData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Wallet(EasyModel):
    id: str
    identity_id: str | None = None
    currency: str | None = None
    balance: int | None = None
    state: str | None = None
    tags: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
