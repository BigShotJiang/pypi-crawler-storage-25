"""Payment instrument models — see TS `PaymentInstrumentData` and `FinixPaymentInstrumentData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class PaymentInstrument(EasyModel):
    id: str
    identity_id: str | None = None
    type: str | None = None
    enabled: bool | None = None
    currency: str | None = None
    last_four: str | None = None
    brand: str | None = None
    card_type: str | None = None
    expiration_month: int | None = None
    expiration_year: int | None = None
    bank_code: str | None = None
    masked_account_number: str | None = None
    account_type: str | None = None
    name: str | None = None
    fingerprint: str | None = None
    address: dict[str, Any] | None = None
    tags: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None


class FinixPaymentInstrument(EasyModel):
    """Wire shape returned by `POST /payment` (creates pass through Finix)."""

    id: str
    type: str | None = None
    instrument_type: str | None = None
    enabled: bool | None = None
    currency: str | None = None
    fingerprint: str | None = None
    name: str | None = None
    last_four: str | None = None
    brand: str | None = None
    card_type: str | None = None
    bin: str | None = None
    expiration_month: int | None = None
    expiration_year: int | None = None
    issuer_country: str | None = None
    address: dict[str, Any] | None = None
    address_verification: str | None = None
    tags: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
