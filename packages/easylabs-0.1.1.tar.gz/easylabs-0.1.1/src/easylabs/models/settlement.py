"""Settlement response model — see TS `SettlementData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Settlement(EasyModel):
    id: str
    status: str | None = None
    state: str | None = None
    currency: str | None = None
    total_amount: int | None = None
    net_amount: int | None = None
    total_fees: int | None = None
    transfer_count: int | None = None
    tags: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
