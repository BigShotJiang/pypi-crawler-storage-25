"""Invoice response model — see TS `InvoiceData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Invoice(EasyModel):
    id: str
    status: str | None = None
    customer_id: str | None = None
    subscription_id: str | None = None
    collection_method: str | None = None
    currency: str | None = None
    amount_due: int | None = None
    amount_paid: int | None = None
    amount_remaining: int | None = None
    subtotal: int | None = None
    total: int | None = None
    items: list[dict[str, Any]] | None = None
    custom_fields: list[dict[str, Any]] | None = None
    tax_ids: list[dict[str, Any]] | None = None
    due_date: str | None = None
    period_start: str | None = None
    period_end: str | None = None
    description: str | None = None
    metadata: dict[str, Any] | None = None
    hosted_invoice_url: str | None = None
    invoice_pdf_url: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
