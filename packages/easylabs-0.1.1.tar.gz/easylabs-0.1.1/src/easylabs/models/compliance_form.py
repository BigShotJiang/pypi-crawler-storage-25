"""Compliance form response model — see TS `ComplianceFormData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class ComplianceForm(EasyModel):
    id: str
    state: str | None = None
    type: str | None = None
    valid_from: str | None = None
    valid_to: str | None = None
    signed_at: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
