"""Product price response model — see TS `PriceData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class ProductPrice(EasyModel):
    id: str
    product_id: str | None = None
    active: bool | None = None
    type: str | None = None
    currency: str | None = None
    unit_amount: int | None = None
    description: str | None = None
    interval: str | None = None
    interval_count: int | None = None
    pricing_model: str | None = None
    trial_period_days: int | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
