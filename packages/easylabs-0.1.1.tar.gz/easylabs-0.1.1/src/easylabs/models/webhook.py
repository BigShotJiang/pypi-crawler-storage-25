"""Webhook management + event models — see TS `WebhookEndpoint`, `WebhookEvent`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class WebhookEndpoint(EasyModel):
    id: str
    url: str | None = None
    status: str | None = None
    events: list[str] | None = None
    created_at: str | None = None
    updated_at: str | None = None


class RegisteredWebhookEndpoint(WebhookEndpoint):
    """Returned (once) on creation — includes the signing secret."""

    secret: str | None = None


class WebhookDelivery(EasyModel):
    id: str
    endpoint_id: str | None = None
    event_type: str | None = None
    success: bool | None = None
    attempt: int | None = None
    attempt_number: int | None = None
    status_code: int | None = None
    response_body: str | None = None
    created_at: str | None = None
    delivered_at: str | None = None


class WebhookEvent(EasyModel):
    """Verified webhook event payload — produced by `Webhooks.construct_event`."""

    id: str
    type: str
    data: Any = None
    created_at: str | None = None
