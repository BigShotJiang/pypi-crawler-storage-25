"""Transfer response model — see TS `TransferData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Transfer(EasyModel):
    id: str
    type: str | None = None
    state: str | None = None
    amount: int | None = None
    amount_requested: int | None = None
    currency: str | None = None
    source: str | None = None
    destination: str | None = None
    fee: int | None = None
    failure_code: str | None = None
    failure_message: str | None = None
    tags: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
