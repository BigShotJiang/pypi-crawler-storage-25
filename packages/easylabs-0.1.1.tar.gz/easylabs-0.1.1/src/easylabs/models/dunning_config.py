"""Dunning / revenue-recovery config model — see TS `DunningConfig`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class DunningConfig(EasyModel):
    retry_mode: str | None = None
    smart_retry_window: str | None = None
    custom_retry_schedule: list[dict[str, Any]] | None = None
    subscription_terminal_action: str | None = None
    invoice_terminal_action: str | None = None
    recovery_page_mode: str | None = None
    custom_recovery_link: str | None = None
    notifications: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
