"""Authorization response model — see TS `AuthorizationData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Authorization(EasyModel):
    id: str
    state: str | None = None
    amount: int | None = None
    currency: str | None = None
    captured_amount: int | None = None
    voided: bool | None = None
    transfer_id: str | None = None
    payment_instrument_id: str | None = None
    expires_at: str | None = None
    tags: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
