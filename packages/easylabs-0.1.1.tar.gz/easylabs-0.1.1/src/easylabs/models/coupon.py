"""Coupon response model — see TS `CouponData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Coupon(EasyModel):
    id: str
    name: str | None = None
    code: str | None = None
    duration: str | None = None
    duration_in_months: int | None = None
    amount_off: int | None = None
    percent_off: float | None = None
    currency: str | None = None
    max_redemptions: int | None = None
    times_redeemed: int | None = None
    redeem_by: str | None = None
    valid: bool | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
