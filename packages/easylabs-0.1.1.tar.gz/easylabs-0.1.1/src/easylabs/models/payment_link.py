"""Payment link models — see TS `PaymentLinkData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class PaymentLink(EasyModel):
    id: str
    state: str | None = None
    payment_count: int | None = None
    payment_limit: int | None = None
    branding_overrides: dict[str, Any] | None = None
    tags: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None


class CreatePaymentLinkResponse(EasyModel):
    """`POST /payment-link` returns just `{ id }` per the JS SDK signature."""

    id: str
