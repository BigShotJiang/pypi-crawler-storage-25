"""Checkout session response — see TS `EasyApiClient.createCheckout` return shape."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from ._base import EasyModel
from .transfer import Transfer


class CheckoutResponse(EasyModel):
    """Returned by `POST /checkout`. Combines transfer + order + subscriptions."""

    transfer: Transfer | None = None
    order_id: str | None = Field(default=None, alias="orderId")
    subscriptions: list[dict[str, Any]] | None = None
    order: dict[str, Any] | None = None
    customer: dict[str, Any] | None = None
