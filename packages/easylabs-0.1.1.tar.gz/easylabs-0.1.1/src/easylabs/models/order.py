"""Order response model — see TS `OrderData`."""

from __future__ import annotations

from typing import Any

from ._base import EasyModel


class Order(EasyModel):
    id: str
    order_number: str | None = None
    status: str | None = None
    customer_id: str | None = None
    transfer_id: str | None = None
    currency: str | None = None
    total_amount: int | None = None
    items: list[dict[str, Any]] | None = None
    tags: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
