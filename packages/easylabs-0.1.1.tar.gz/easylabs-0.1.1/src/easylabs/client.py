"""`easylabs.Client` — top-level instance that owns HTTP transport and resources."""

from __future__ import annotations

from . import _api_url
from ._http import _HTTP
from ._validate import validate_api_key
from .resources import (
    Analytics,
    Authorizations,
    Checkout,
    ComplianceForms,
    Coupons,
    Customers,
    Disputes,
    DunningConfig,
    EmbeddedCheckout,
    Invoices,
    Orders,
    PaymentInstruments,
    PaymentLinks,
    ProductPrices,
    Products,
    PromotionCodes,
    RevenueRecoveryAutomations,
    Settlements,
    Subscriptions,
    Transfers,
    WebhooksManagement,
)


class Client:
    """Easy Labs API client.

    Args:
        api_key:           Your secret API key (`sk_live_...` or `sk_test_...`).
        internal_api_url:  Override the base URL entirely. Intended for
                           tests, self-hosted setups, and pinned-CI
                           environments. The default routing (sandbox vs.
                           production based on key prefix) covers normal
                           use; this escape hatch covers everything else.

    On construction, the client calls `GET /validate-key` to confirm the key
    is live. This populates `basis_theory_public_api_key` for downstream use.
    """

    def __init__(
        self,
        *,
        api_key: str,
        internal_api_url: str | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")

        self.api_url: str = internal_api_url or _api_url.resolve(api_key=api_key)
        self._http = _HTTP(api_url=self.api_url, api_key=api_key)
        self.basis_theory_public_api_key: str = validate_api_key(
            api_key=api_key, api_url=self.api_url
        )

        self.customers = Customers(self._http)
        self.payment_instruments = PaymentInstruments(self._http)
        self.transfers = Transfers(self._http)
        self.disputes = Disputes(self._http)
        self.settlements = Settlements(self._http)
        self.products = Products(self._http)
        self.product_prices = ProductPrices(self._http)
        self.orders = Orders(self._http)
        self.subscriptions = Subscriptions(self._http)
        self.checkout = Checkout(self._http)
        self.payment_links = PaymentLinks(self._http)
        self.embedded_checkout = EmbeddedCheckout(self._http)
        self.webhooks_management = WebhooksManagement(self._http)
        self.invoices = Invoices(self._http)
        self.coupons = Coupons(self._http)
        self.promotion_codes = PromotionCodes(self._http)
        self.authorizations = Authorizations(self._http)
        self.analytics = Analytics(self._http)
        self.compliance_forms = ComplianceForms(self._http)
        self.dunning_config = DunningConfig(self._http)
        self.revenue_recovery_automations = RevenueRecoveryAutomations(self._http)
