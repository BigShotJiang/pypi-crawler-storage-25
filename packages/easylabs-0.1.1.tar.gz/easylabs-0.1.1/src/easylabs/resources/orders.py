"""Orders resource — `client.orders.*`."""

from __future__ import annotations

from typing import Any

from ..models import Order
from ._base import _model, _model_list, _Resource


class Orders(_Resource):
    def retrieve(self, order_id: str) -> Order:
        return _model(Order, self._http.request("GET", f"/orders/{order_id}"))

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Order]:
        return _model_list(
            Order,
            self._http.request(
                "GET",
                "/orders",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def update_tags(
        self,
        order_id: str,
        *,
        tags: dict[str, Any],
        idempotency_key: str | None = None,
    ) -> Order:
        return _model(
            Order,
            self._http.request(
                "PATCH",
                f"/orders/{order_id}",
                body={"tags": tags},
                idempotency_key=idempotency_key,
            ),
        )
