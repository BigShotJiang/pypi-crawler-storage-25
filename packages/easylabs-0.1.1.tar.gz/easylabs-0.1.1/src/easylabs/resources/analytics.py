"""Analytics resource — `client.analytics.*`."""

from __future__ import annotations

from typing import Any

from ._base import _data, _Resource


class Analytics(_Resource):
    def _get(
        self,
        endpoint: str,
        *,
        period: str | None,
        start_date: str | None,
        end_date: str | None,
    ) -> dict[str, Any]:
        return _data(
            self._http.request(
                "GET",
                f"/analytics/{endpoint}",
                query={"period": period, "start_date": start_date, "end_date": end_date},
            )
        )

    def transactions(
        self,
        *,
        period: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, Any]:
        return self._get("transactions", period=period, start_date=start_date, end_date=end_date)

    def disputes(
        self,
        *,
        period: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, Any]:
        return self._get("disputes", period=period, start_date=start_date, end_date=end_date)

    def settlements(
        self,
        *,
        period: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, Any]:
        return self._get("settlements", period=period, start_date=start_date, end_date=end_date)

    def revenue(
        self,
        *,
        period: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, Any]:
        return self._get("revenue", period=period, start_date=start_date, end_date=end_date)

    def revenue_recovery(
        self,
        *,
        period: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, Any]:
        return self._get(
            "revenue-recovery",
            period=period,
            start_date=start_date,
            end_date=end_date,
        )
