"""Customers resource — `client.customers.*`."""

from __future__ import annotations

from typing import Any

from ..models import Customer, Order, PaymentInstrument, Subscription, Wallet
from ._base import _data, _model, _model_list, _Resource


class Customers(_Resource):
    def create(
        self,
        *,
        first_name: str,
        last_name: str,
        email: str | None = None,
        phone: str | None = None,
        personal_address: dict[str, Any] | None = None,
        tags: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> Customer:
        body: dict[str, Any] = {"first_name": first_name, "last_name": last_name}
        if email is not None:
            body["email"] = email
        if phone is not None:
            body["phone"] = phone
        if personal_address is not None:
            body["personal_address"] = personal_address
        if tags is not None:
            body["tags"] = tags
        return _model(
            Customer,
            self._http.request("POST", "/customer", body=body, idempotency_key=idempotency_key),
        )

    def update(
        self,
        customer_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Customer:
        return _model(
            Customer,
            self._http.request(
                "PATCH",
                f"/customer/{customer_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def retrieve(self, customer_id: str) -> Customer:
        return _model(Customer, self._http.request("GET", f"/customer/{customer_id}"))

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Customer]:
        return _model_list(
            Customer,
            self._http.request(
                "GET",
                "/customer",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def payment_instruments(self, customer_id: str) -> list[PaymentInstrument]:
        return _model_list(
            PaymentInstrument,
            self._http.request("GET", f"/customer/{customer_id}/instruments"),
        )

    def orders(
        self,
        customer_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Order]:
        return _model_list(
            Order,
            self._http.request(
                "GET",
                f"/customer/{customer_id}/orders",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def subscriptions(
        self,
        customer_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        """Returns the paginated wrapper `{ data, total, limit, offset }`.

        The `data` list contains `Subscription` instances; the wrapper
        itself is returned as a plain dict because the wire envelope is
        already paginated.
        """
        raw = _data(
            self._http.request(
                "GET",
                f"/customer/{customer_id}/subscriptions",
                query={
                    "limit": limit,
                    "offset": offset,
                    "ids": ids,
                    "status": status,
                },
            )
        )
        if not isinstance(raw, dict):
            return {"data": [], "total": 0, "limit": limit or 0, "offset": offset or 0}
        return {
            **raw,
            "data": [Subscription.model_validate(item) for item in raw.get("data", [])],
        }

    def wallets(
        self,
        customer_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Wallet]:
        return _model_list(
            Wallet,
            self._http.request(
                "GET",
                f"/customer/{customer_id}/wallets",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )
