"""Webhook endpoint management — `client.webhooks_management.*`.

This is the management surface (register/list/update/delete endpoints,
list deliveries). The webhook *signature verifier* lives at
`easylabs.Webhooks.construct_event` — they are intentionally separate.
"""

from __future__ import annotations

from typing import Any

from ..models import RegisteredWebhookEndpoint, WebhookEndpoint
from ._base import _data, _model, _model_list, _Resource


class WebhooksManagement(_Resource):
    def register(
        self,
        *,
        url: str,
        events: list[str] | None = None,
        idempotency_key: str | None = None,
    ) -> RegisteredWebhookEndpoint:
        body: dict[str, Any] = {"url": url}
        if events is not None:
            body["events"] = events
        return _model(
            RegisteredWebhookEndpoint,
            self._http.request("POST", "/webhooks", body=body, idempotency_key=idempotency_key),
        )

    def list(self) -> list[WebhookEndpoint]:
        return _model_list(WebhookEndpoint, self._http.request("GET", "/webhooks"))

    def update(
        self,
        endpoint_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> WebhookEndpoint:
        return _model(
            WebhookEndpoint,
            self._http.request(
                "PATCH",
                f"/webhooks/{endpoint_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def delete(
        self,
        endpoint_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> None:
        self._http.request(
            "DELETE",
            f"/webhooks/{endpoint_id}",
            idempotency_key=idempotency_key,
        )

    def list_deliveries(
        self,
        *,
        event_type: str | None = None,
        success: bool | None = None,
        attempt: int | None = None,
        attempt_number: int | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        endpoint_id: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
        include_counts: bool | None = None,
    ) -> dict[str, Any]:
        return _data(
            self._http.request(
                "GET",
                "/webhooks/deliveries",
                query={
                    "event_type": event_type,
                    "success": success,
                    "attempt": attempt,
                    "attempt_number": attempt_number,
                    "created_after": created_after,
                    "created_before": created_before,
                    "endpoint_id": endpoint_id,
                    "limit": limit,
                    "offset": offset,
                    "include_counts": include_counts,
                },
            )
        )

    def list_endpoint_deliveries(
        self,
        endpoint_id: str,
        *,
        event_type: str | None = None,
        success: bool | None = None,
        attempt: int | None = None,
        attempt_number: int | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> dict[str, Any]:
        return _data(
            self._http.request(
                "GET",
                f"/webhooks/{endpoint_id}/deliveries",
                query={
                    "event_type": event_type,
                    "success": success,
                    "attempt": attempt,
                    "attempt_number": attempt_number,
                    "created_after": created_after,
                    "created_before": created_before,
                    "limit": limit,
                    "offset": offset,
                },
            )
        )
