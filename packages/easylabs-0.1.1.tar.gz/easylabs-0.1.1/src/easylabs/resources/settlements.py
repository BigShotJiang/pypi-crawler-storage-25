"""Settlements resource — `client.settlements.*`."""

from __future__ import annotations

from ..models import Settlement
from ._base import _model, _model_list, _Resource


class Settlements(_Resource):
    def retrieve(self, settlement_id: str) -> Settlement:
        return _model(
            Settlement,
            self._http.request("GET", f"/settlements/{settlement_id}"),
        )

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Settlement]:
        return _model_list(
            Settlement,
            self._http.request(
                "GET",
                "/settlements",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def close(
        self,
        settlement_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> Settlement:
        return _model(
            Settlement,
            self._http.request(
                "PATCH",
                f"/settlements/{settlement_id}",
                idempotency_key=idempotency_key,
            ),
        )
