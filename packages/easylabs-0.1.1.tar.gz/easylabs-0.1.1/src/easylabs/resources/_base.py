"""Shared resource base + envelope helpers."""

from __future__ import annotations

from typing import Any, TypeVar

from .._http import _HTTP
from ..models._base import EasyModel

T = TypeVar("T", bound=EasyModel)


class _Resource:
    """Mixin-style base. Resources own a reference to the HTTP transport."""

    def __init__(self, http: _HTTP) -> None:
        self._http = http


def _data(payload: Any) -> Any:
    """Unwrap the standard `{ "data": ... }` envelope used by the API."""
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


def _model(cls: type[T], payload: Any) -> T:
    """Validate `payload["data"]` (or payload itself) into `cls`."""
    return cls.model_validate(_data(payload))


def _model_list(cls: type[T], payload: Any) -> list[T]:
    """Validate a list payload into `list[cls]`."""
    raw = _data(payload)
    if raw is None:
        return []
    return [cls.model_validate(item) for item in raw]


def _drop_none(d: dict[str, Any]) -> dict[str, Any]:
    """Remove keys whose values are None — used when building request bodies."""
    return {k: v for k, v in d.items() if v is not None}
