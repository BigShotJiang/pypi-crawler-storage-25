"""Products resource — `client.products.*`."""

from __future__ import annotations

from typing import Any

from ..models import Product
from ._base import _data, _model, _model_list, _Resource


class Products(_Resource):
    def create(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Product:
        return _model(
            Product,
            self._http.request("POST", "/products", body=fields, idempotency_key=idempotency_key),
        )

    def update(
        self,
        product_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Product:
        return _model(
            Product,
            self._http.request(
                "PATCH",
                f"/products/{product_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def retrieve(self, product_id: str) -> Product:
        return _model(Product, self._http.request("GET", f"/products/{product_id}"))

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Product]:
        return _model_list(
            Product,
            self._http.request(
                "GET",
                "/products",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def archive(
        self,
        product_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> Product:
        return _model(
            Product,
            self._http.request(
                "PATCH",
                f"/products/{product_id}/archive",
                idempotency_key=idempotency_key,
            ),
        )

    def with_prices(self, product_id: str) -> dict[str, Any]:
        """Return the product augmented with all of its prices."""
        return _data(self._http.request("GET", f"/products/{product_id}/prices"))

    def with_price(self, product_id: str, price_id: str) -> dict[str, Any]:
        """Return the product augmented with a single price."""
        return _data(self._http.request("GET", f"/products/{product_id}/prices/{price_id}"))
