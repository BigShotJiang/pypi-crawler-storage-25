"""Checkout resource — `client.checkout.*`."""

from __future__ import annotations

from typing import Any

from ..models import CheckoutResponse
from ._base import _model, _Resource


class Checkout(_Resource):
    def create(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> CheckoutResponse:
        return _model(
            CheckoutResponse,
            self._http.request("POST", "/checkout", body=fields, idempotency_key=idempotency_key),
        )
