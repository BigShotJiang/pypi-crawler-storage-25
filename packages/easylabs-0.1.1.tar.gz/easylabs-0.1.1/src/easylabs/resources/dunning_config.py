"""Dunning config resource — `client.dunning_config.*`."""

from __future__ import annotations

from typing import Any

from ..models import DunningConfig as DunningConfigModel
from ._base import _model, _Resource


class DunningConfig(_Resource):
    def create_or_replace(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> DunningConfigModel:
        return _model(
            DunningConfigModel,
            self._http.request(
                "POST",
                "/dunning-config",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def retrieve(self) -> DunningConfigModel:
        return _model(DunningConfigModel, self._http.request("GET", "/dunning-config"))

    def update(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> DunningConfigModel:
        return _model(
            DunningConfigModel,
            self._http.request(
                "PATCH",
                "/dunning-config",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )
