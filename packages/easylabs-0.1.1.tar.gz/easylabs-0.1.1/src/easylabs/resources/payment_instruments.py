"""Payment instruments resource — `client.payment_instruments.*`."""

from __future__ import annotations

from typing import Any

from ..models import FinixPaymentInstrument, PaymentInstrument
from ._base import _model, _Resource


class PaymentInstruments(_Resource):
    def create(
        self,
        *,
        type: str,
        name: str,
        identity_id: str,
        token_id: str,
        idempotency_key: str | None = None,
        **extras: Any,
    ) -> FinixPaymentInstrument:
        """Create a payment instrument.

        Pass `type="PAYMENT_CARD"` (with optional `address`) or
        `type="BANK_ACCOUNT"` (with `account_type`,
        `attempt_bank_account_validation_check`). The Node SDK's
        `createClient` enforces a `tokenId` is supplied — this method
        does the same via the `token_id` parameter.
        """
        if not token_id:
            raise ValueError("token_id is required to create a payment instrument.")

        body: dict[str, Any] = {
            "type": type,
            "name": name,
            "identityId": identity_id,
            "tokenId": token_id,
            **extras,
        }
        return _model(
            FinixPaymentInstrument,
            self._http.request("POST", "/payment", body=body, idempotency_key=idempotency_key),
        )

    def update(
        self,
        payment_instrument_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> PaymentInstrument:
        return _model(
            PaymentInstrument,
            self._http.request(
                "PATCH",
                f"/payment/{payment_instrument_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )
