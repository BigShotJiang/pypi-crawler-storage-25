"""Compliance forms resource — `client.compliance_forms.*`."""

from __future__ import annotations

from typing import Any

from ..models import ComplianceForm
from ._base import _model, _model_list, _Resource


class ComplianceForms(_Resource):
    def list(self) -> list[ComplianceForm]:
        return _model_list(ComplianceForm, self._http.request("GET", "/compliance-forms"))

    def retrieve(self, form_id: str) -> ComplianceForm:
        return _model(
            ComplianceForm,
            self._http.request("GET", f"/compliance-forms/{form_id}"),
        )

    def sign(
        self,
        form_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> ComplianceForm:
        return _model(
            ComplianceForm,
            self._http.request(
                "PUT",
                f"/compliance-forms/{form_id}/sign",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )
