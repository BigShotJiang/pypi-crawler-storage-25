"""Subscriptions resource — `client.subscriptions.*` (largest surface)."""

from __future__ import annotations

from typing import Any

from ..models import Subscription, SubscriptionDiscount, SubscriptionItem
from ._base import _data, _model, _model_list, _Resource


class Subscriptions(_Resource):
    # ── Core CRUD ──────────────────────────────────────────────────────

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Subscription]:
        return _model_list(
            Subscription,
            self._http.request(
                "GET",
                "/subscriptions",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def retrieve(self, subscription_id: str) -> Subscription:
        return _model(Subscription, self._http.request("GET", f"/subscriptions/{subscription_id}"))

    def create(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Subscription:
        return _model(
            Subscription,
            self._http.request(
                "POST",
                "/subscriptions",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def update(
        self,
        subscription_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Subscription:
        return _model(
            Subscription,
            self._http.request(
                "PATCH",
                f"/subscriptions/{subscription_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def cancel(
        self,
        subscription_id: str,
        *,
        at_period_end: bool = False,
        idempotency_key: str | None = None,
    ) -> Subscription:
        return _model(
            Subscription,
            self._http.request(
                "DELETE",
                f"/subscriptions/{subscription_id}",
                query={"at_period_end": at_period_end},
                idempotency_key=idempotency_key,
            ),
        )

    # ── Pause / resume / proration preview ─────────────────────────────

    def pause(
        self,
        subscription_id: str,
        *,
        behavior: str,
        resumes_at: str | None = None,
        idempotency_key: str | None = None,
    ) -> Subscription:
        body: dict[str, Any] = {"behavior": behavior}
        if resumes_at is not None:
            body["resumes_at"] = resumes_at
        return _model(
            Subscription,
            self._http.request(
                "POST",
                f"/subscriptions/{subscription_id}/pause",
                body=body,
                idempotency_key=idempotency_key,
            ),
        )

    def resume(
        self,
        subscription_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> Subscription:
        return _model(
            Subscription,
            self._http.request(
                "POST",
                f"/subscriptions/{subscription_id}/resume",
                idempotency_key=idempotency_key,
            ),
        )

    def proration_preview(
        self,
        subscription_id: str,
        *,
        items: list[dict[str, Any]] | None = None,
        remove_items: list[str] | None = None,
        proration_date: str | None = None,
    ) -> dict[str, Any]:
        query: dict[str, Any] = {}
        if items:
            query["items"] = ",".join(
                f"{i['price_id']}:{i['quantity']}"
                if i.get("quantity") is not None
                else i["price_id"]
                for i in items
            )
        if remove_items:
            query["remove_items"] = ",".join(remove_items)
        if proration_date:
            query["proration_date"] = proration_date
        return _data(
            self._http.request(
                "GET",
                f"/subscriptions/{subscription_id}/proration-preview",
                query=query,
            )
        )

    # ── Items ──────────────────────────────────────────────────────────

    def add_item(
        self,
        subscription_id: str,
        *,
        price_id: str,
        quantity: int | None = None,
        idempotency_key: str | None = None,
    ) -> SubscriptionItem:
        body: dict[str, Any] = {"price_id": price_id}
        if quantity is not None:
            body["quantity"] = quantity
        return _model(
            SubscriptionItem,
            self._http.request(
                "POST",
                f"/subscriptions/{subscription_id}/items",
                body=body,
                idempotency_key=idempotency_key,
            ),
        )

    def update_item(
        self,
        subscription_id: str,
        item_id: str,
        *,
        quantity: int,
        idempotency_key: str | None = None,
    ) -> SubscriptionItem:
        return _model(
            SubscriptionItem,
            self._http.request(
                "PATCH",
                f"/subscriptions/{subscription_id}/items/{item_id}",
                body={"quantity": quantity},
                idempotency_key=idempotency_key,
            ),
        )

    def remove_item(
        self,
        subscription_id: str,
        item_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> SubscriptionItem:
        return _model(
            SubscriptionItem,
            self._http.request(
                "DELETE",
                f"/subscriptions/{subscription_id}/items/{item_id}",
                idempotency_key=idempotency_key,
            ),
        )

    # ── Discounts ──────────────────────────────────────────────────────

    def apply_discount(
        self,
        subscription_id: str,
        *,
        idempotency_key: str | None = None,
        **body: Any,
    ) -> SubscriptionDiscount:
        """Apply a coupon or promotion code.

        Pass exactly one of `coupon_id` or `promotion_code`, optionally
        scoped to a `subscription_item_id`. Server enforces the XOR.
        """
        return _model(
            SubscriptionDiscount,
            self._http.request(
                "POST",
                f"/subscriptions/{subscription_id}/discounts",
                body=body,
                idempotency_key=idempotency_key,
            ),
        )

    def list_discounts(self, subscription_id: str) -> list[SubscriptionDiscount]:
        return _model_list(
            SubscriptionDiscount,
            self._http.request("GET", f"/subscriptions/{subscription_id}/discounts"),
        )

    def remove_discount(
        self,
        subscription_id: str,
        discount_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> SubscriptionDiscount:
        return _model(
            SubscriptionDiscount,
            self._http.request(
                "DELETE",
                f"/subscriptions/{subscription_id}/discounts/{discount_id}",
                idempotency_key=idempotency_key,
            ),
        )

    # ── One-time charges + usage ───────────────────────────────────────

    def create_one_time_charge(
        self,
        subscription_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> dict[str, Any]:
        return _data(
            self._http.request(
                "POST",
                f"/subscriptions/{subscription_id}/one-time-charges",
                body=fields,
                idempotency_key=idempotency_key,
            )
        )

    def report_usage(
        self,
        subscription_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> dict[str, Any]:
        return _data(
            self._http.request(
                "POST",
                f"/subscriptions/{subscription_id}/usage",
                body=fields,
                idempotency_key=idempotency_key,
            )
        )

    def usage_summary(
        self,
        subscription_id: str,
        *,
        subscription_item_id: str | None = None,
        from_: str | None = None,
        to: str | None = None,
        as_of: str | None = None,
    ) -> dict[str, Any]:
        return _data(
            self._http.request(
                "GET",
                f"/subscriptions/{subscription_id}/usage/summary",
                query={
                    "subscription_item_id": subscription_item_id,
                    "from": from_,
                    "to": to,
                    "as_of": as_of,
                },
            )
        )

    def usage_reconciliation(
        self,
        subscription_id: str,
        *,
        subscription_item_id: str | None = None,
        period_start: str | None = None,
        period_end: str | None = None,
    ) -> dict[str, Any]:
        return _data(
            self._http.request(
                "GET",
                f"/subscriptions/{subscription_id}/usage/reconciliation",
                query={
                    "subscription_item_id": subscription_item_id,
                    "period_start": period_start,
                    "period_end": period_end,
                },
            )
        )
