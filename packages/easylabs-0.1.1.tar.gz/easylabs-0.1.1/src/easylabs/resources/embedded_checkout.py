"""Embedded checkout resource — `client.embedded_checkout.*`."""

from __future__ import annotations

from typing import Any

from ..models import (
    CryptoPaymentStatus,
    EmbeddedCheckoutConfig,
    EmbeddedCheckoutSession,
    EmbeddedCheckoutSessionStatus,
    ValidateEmbeddedCheckoutSessionResponse,
)
from ._base import _data, _model, _Resource


class EmbeddedCheckout(_Resource):
    def create_session(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> EmbeddedCheckoutSession:
        return _model(
            EmbeddedCheckoutSession,
            self._http.request(
                "POST",
                "/embedded-checkout",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def retrieve_session(self, session_id: str) -> EmbeddedCheckoutSessionStatus:
        return _model(
            EmbeddedCheckoutSessionStatus,
            self._http.request("GET", f"/embedded-checkout/{session_id}"),
        )

    def crypto_status(self, session_id: str) -> CryptoPaymentStatus:
        return _model(
            CryptoPaymentStatus,
            self._http.request("GET", f"/embedded-checkout/{session_id}/crypto-status"),
        )

    def validate(
        self,
        *,
        client_secret: str,
        parent_origin: str | None = None,
    ) -> ValidateEmbeddedCheckoutSessionResponse:
        """Browser-side validation. Authenticates via `client_secret`,
        not the SDK's API key."""
        body: dict[str, Any] = {"client_secret": client_secret}
        if parent_origin is not None:
            body["parent_origin"] = parent_origin
        return _model(
            ValidateEmbeddedCheckoutSessionResponse,
            self._http.request("POST", "/embedded-checkout/validate", body=body, skip_auth=True),
        )

    def confirm(
        self,
        *,
        client_secret: str,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> dict[str, Any]:
        """Browser-side confirmation. Authenticates via `client_secret`,
        not the SDK's API key."""
        body: dict[str, Any] = {"client_secret": client_secret, **fields}
        return _data(
            self._http.request(
                "POST",
                "/embedded-checkout/confirm",
                body=body,
                skip_auth=True,
                idempotency_key=idempotency_key,
            )
        )

    def get_config(self) -> EmbeddedCheckoutConfig:
        return _model(
            EmbeddedCheckoutConfig,
            self._http.request("GET", "/embedded-checkout/config"),
        )

    def update_config(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> EmbeddedCheckoutConfig:
        return _model(
            EmbeddedCheckoutConfig,
            self._http.request(
                "PATCH",
                "/embedded-checkout/config",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )
