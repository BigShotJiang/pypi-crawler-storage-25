"""Transfers resource — `client.transfers.*` (incl. refunds)."""

from __future__ import annotations

from typing import Any

from ..models import Transfer
from ._base import _model, _model_list, _Resource


class Transfers(_Resource):
    def create(
        self,
        *,
        amount: int,
        currency: str,
        source: str,
        tags: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> Transfer:
        body: dict[str, Any] = {"amount": amount, "currency": currency, "source": source}
        if tags is not None:
            body["tags"] = tags
        return _model(
            Transfer,
            self._http.request("POST", "/transfer", body=body, idempotency_key=idempotency_key),
        )

    def update(
        self,
        transfer_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Transfer:
        return _model(
            Transfer,
            self._http.request(
                "PATCH",
                f"/transfer/{transfer_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def retrieve(self, transfer_id: str) -> Transfer:
        return _model(Transfer, self._http.request("GET", f"/transfer/{transfer_id}"))

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Transfer]:
        return _model_list(
            Transfer,
            self._http.request(
                "GET",
                "/transfer",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def create_refund(
        self,
        transfer_id: str,
        *,
        refund_amount: int,
        tags: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> Transfer:
        body: dict[str, Any] = {"refund_amount": refund_amount}
        if tags is not None:
            body["tags"] = tags
        return _model(
            Transfer,
            self._http.request(
                "POST",
                f"/transfer/{transfer_id}/reversals",
                body=body,
                idempotency_key=idempotency_key,
            ),
        )
