"""Authorizations resource — `client.authorizations.*`."""

from __future__ import annotations

from ..models import Authorization
from ._base import _model, _model_list, _Resource


class Authorizations(_Resource):
    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Authorization]:
        return _model_list(
            Authorization,
            self._http.request(
                "GET",
                "/authorizations",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def retrieve(self, authorization_id: str) -> Authorization:
        return _model(
            Authorization,
            self._http.request("GET", f"/authorizations/{authorization_id}"),
        )

    def capture(
        self,
        authorization_id: str,
        *,
        amount: int,
        idempotency_key: str | None = None,
    ) -> Authorization:
        return _model(
            Authorization,
            self._http.request(
                "POST",
                f"/authorizations/{authorization_id}/capture",
                body={"amount": amount},
                idempotency_key=idempotency_key,
            ),
        )

    def void(
        self,
        authorization_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> Authorization:
        return _model(
            Authorization,
            self._http.request(
                "POST",
                f"/authorizations/{authorization_id}/void",
                idempotency_key=idempotency_key,
            ),
        )
