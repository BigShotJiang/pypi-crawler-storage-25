"""Coupons resource — `client.coupons.*`."""

from __future__ import annotations

from typing import Any

from ..models import Coupon
from ._base import _model, _model_list, _Resource


class Coupons(_Resource):
    def create(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Coupon:
        return _model(
            Coupon,
            self._http.request("POST", "/coupons", body=fields, idempotency_key=idempotency_key),
        )

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Coupon]:
        return _model_list(
            Coupon,
            self._http.request(
                "GET",
                "/coupons",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def retrieve(self, coupon_id: str) -> Coupon:
        return _model(Coupon, self._http.request("GET", f"/coupons/{coupon_id}"))

    def update(
        self,
        coupon_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Coupon:
        return _model(
            Coupon,
            self._http.request(
                "PATCH",
                f"/coupons/{coupon_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def delete(
        self,
        coupon_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> None:
        self._http.request(
            "DELETE",
            f"/coupons/{coupon_id}",
            idempotency_key=idempotency_key,
        )
