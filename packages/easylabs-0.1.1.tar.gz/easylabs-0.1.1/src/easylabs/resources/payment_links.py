"""Payment links resource — `client.payment_links.*`."""

from __future__ import annotations

from typing import Any

from ..models import CreatePaymentLinkResponse
from ._base import _model, _Resource


class PaymentLinks(_Resource):
    def create(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> CreatePaymentLinkResponse:
        return _model(
            CreatePaymentLinkResponse,
            self._http.request(
                "POST", "/payment-link", body=fields, idempotency_key=idempotency_key
            ),
        )
