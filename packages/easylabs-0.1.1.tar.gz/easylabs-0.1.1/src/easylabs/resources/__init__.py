"""Resource namespaces wired onto `easylabs.Client`."""

from .analytics import Analytics
from .authorizations import Authorizations
from .checkout import Checkout
from .compliance_forms import ComplianceForms
from .coupons import Coupons
from .customers import Customers
from .disputes import Disputes
from .dunning_config import DunningConfig
from .embedded_checkout import EmbeddedCheckout
from .invoices import Invoices
from .orders import Orders
from .payment_instruments import PaymentInstruments
from .payment_links import PaymentLinks
from .product_prices import ProductPrices
from .products import Products
from .promotion_codes import PromotionCodes
from .revenue_recovery_automations import RevenueRecoveryAutomations
from .settlements import Settlements
from .subscriptions import Subscriptions
from .transfers import Transfers
from .webhooks_management import WebhooksManagement

__all__ = [
    "Analytics",
    "Authorizations",
    "Checkout",
    "ComplianceForms",
    "Coupons",
    "Customers",
    "Disputes",
    "DunningConfig",
    "EmbeddedCheckout",
    "Invoices",
    "Orders",
    "PaymentInstruments",
    "PaymentLinks",
    "ProductPrices",
    "Products",
    "PromotionCodes",
    "RevenueRecoveryAutomations",
    "Settlements",
    "Subscriptions",
    "Transfers",
    "WebhooksManagement",
]
