"""Promotion codes resource — `client.promotion_codes.*`."""

from __future__ import annotations

from typing import Any

from ..models import PromotionCode, ValidatePromotionCodeResponse
from ._base import _model, _model_list, _Resource


class PromotionCodes(_Resource):
    def create(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> PromotionCode:
        return _model(
            PromotionCode,
            self._http.request(
                "POST",
                "/promotion-codes",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[PromotionCode]:
        return _model_list(
            PromotionCode,
            self._http.request(
                "GET",
                "/promotion-codes",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def retrieve(self, promotion_code_id: str) -> PromotionCode:
        return _model(
            PromotionCode,
            self._http.request("GET", f"/promotion-codes/{promotion_code_id}"),
        )

    def update(
        self,
        promotion_code_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> PromotionCode:
        return _model(
            PromotionCode,
            self._http.request(
                "PATCH",
                f"/promotion-codes/{promotion_code_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def delete(
        self,
        promotion_code_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> None:
        self._http.request(
            "DELETE",
            f"/promotion-codes/{promotion_code_id}",
            idempotency_key=idempotency_key,
        )

    def validate(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> ValidatePromotionCodeResponse:
        return _model(
            ValidatePromotionCodeResponse,
            self._http.request(
                "POST",
                "/promotion-codes/validate",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )
