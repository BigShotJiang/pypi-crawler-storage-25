"""Invoices resource — `client.invoices.*`."""

from __future__ import annotations

from typing import Any

from ..models import Invoice
from ._base import _data, _model, _model_list, _Resource


class Invoices(_Resource):
    def create(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Invoice:
        return _model(
            Invoice,
            self._http.request("POST", "/invoices", body=fields, idempotency_key=idempotency_key),
        )

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
        status: str | None = None,
        collection_method: str | None = None,
        due_date_from: str | None = None,
        due_date_to: str | None = None,
    ) -> list[Invoice]:
        return _model_list(
            Invoice,
            self._http.request(
                "GET",
                "/invoices",
                query={
                    "limit": limit,
                    "offset": offset,
                    "ids": ids,
                    "status": status,
                    "collection_method": collection_method,
                    "due_date_from": due_date_from,
                    "due_date_to": due_date_to,
                },
            ),
        )

    def retrieve(self, invoice_id: str) -> Invoice:
        return _model(Invoice, self._http.request("GET", f"/invoices/{invoice_id}"))

    def update(
        self,
        invoice_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Invoice:
        return _model(
            Invoice,
            self._http.request(
                "PATCH",
                f"/invoices/{invoice_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def send_invoice(
        self,
        invoice_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Invoice:
        """Send the invoice email. Named `send_invoice` to avoid the
        `send`/coroutine semantics association in Python and to match
        the Ruby SDK."""
        return _model(
            Invoice,
            self._http.request(
                "POST",
                f"/invoices/{invoice_id}/send",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def pay(
        self,
        invoice_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> Invoice:
        return _model(
            Invoice,
            self._http.request(
                "POST",
                f"/invoices/{invoice_id}/pay",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def remind(
        self,
        invoice_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> Invoice:
        return _model(
            Invoice,
            self._http.request(
                "POST",
                f"/invoices/{invoice_id}/remind",
                idempotency_key=idempotency_key,
            ),
        )

    def void(
        self,
        invoice_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> Invoice:
        return _model(
            Invoice,
            self._http.request(
                "POST",
                f"/invoices/{invoice_id}/void",
                idempotency_key=idempotency_key,
            ),
        )

    def pdf_data(self, invoice_id: str) -> dict[str, Any]:
        return _data(self._http.request("GET", f"/invoices/{invoice_id}/pdf"))
