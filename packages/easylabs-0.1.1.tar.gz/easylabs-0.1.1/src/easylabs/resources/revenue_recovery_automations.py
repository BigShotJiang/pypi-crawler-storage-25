"""Revenue-recovery automations resource — `client.revenue_recovery_automations.*`."""

from __future__ import annotations

from typing import Any

from ..models import RevenueRecoveryAutomation, RevenueRecoveryAutomationRun
from ._base import _model, _model_list, _Resource


class RevenueRecoveryAutomations(_Resource):
    def list(self) -> list[RevenueRecoveryAutomation]:
        return _model_list(
            RevenueRecoveryAutomation,
            self._http.request("GET", "/revenue-recovery-automations"),
        )

    def create(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> RevenueRecoveryAutomation:
        return _model(
            RevenueRecoveryAutomation,
            self._http.request(
                "POST",
                "/revenue-recovery-automations",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def update(
        self,
        automation_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> RevenueRecoveryAutomation:
        return _model(
            RevenueRecoveryAutomation,
            self._http.request(
                "PATCH",
                f"/revenue-recovery-automations/{automation_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def delete(
        self,
        automation_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> None:
        self._http.request(
            "DELETE",
            f"/revenue-recovery-automations/{automation_id}",
            idempotency_key=idempotency_key,
        )

    def list_runs(self, automation_id: str) -> list[RevenueRecoveryAutomationRun]:
        return _model_list(
            RevenueRecoveryAutomationRun,
            self._http.request(
                "GET",
                f"/revenue-recovery-automations/{automation_id}/runs",
            ),
        )
