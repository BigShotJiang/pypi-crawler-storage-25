"""Product prices resource — `client.product_prices.*`."""

from __future__ import annotations

from typing import Any

from ..models import ProductPrice
from ._base import _model, _model_list, _Resource


class ProductPrices(_Resource):
    def create(
        self,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> ProductPrice:
        """Create a price.

        For one-time prices pass `recurring=False` and the standard
        `{ currency, unit_amount }`. For recurring prices pass
        `recurring=True` and `{ currency, unit_amount, interval,
        interval_count }`. The discriminated union is enforced by the
        server — see TS `CreatePrice` in packages/common/src/types.ts.
        """
        return _model(
            ProductPrice,
            self._http.request(
                "POST",
                "/product-prices",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def update(
        self,
        price_id: str,
        *,
        idempotency_key: str | None = None,
        **fields: Any,
    ) -> ProductPrice:
        return _model(
            ProductPrice,
            self._http.request(
                "PATCH",
                f"/product-prices/{price_id}",
                body=fields,
                idempotency_key=idempotency_key,
            ),
        )

    def retrieve(self, price_id: str) -> ProductPrice:
        return _model(
            ProductPrice,
            self._http.request("GET", f"/product-prices/{price_id}"),
        )

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[ProductPrice]:
        return _model_list(
            ProductPrice,
            self._http.request(
                "GET",
                "/product-prices",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def archive(
        self,
        price_id: str,
        *,
        idempotency_key: str | None = None,
    ) -> ProductPrice:
        return _model(
            ProductPrice,
            self._http.request(
                "PATCH",
                f"/product-prices/{price_id}/archive",
                idempotency_key=idempotency_key,
            ),
        )
