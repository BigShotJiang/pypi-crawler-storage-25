"""Disputes resource — `client.disputes.*`."""

from __future__ import annotations

from typing import Any

from ..models import Dispute
from ._base import _model, _model_list, _Resource


class Disputes(_Resource):
    def retrieve(self, dispute_id: str) -> Dispute:
        return _model(Dispute, self._http.request("GET", f"/disputes/{dispute_id}"))

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        ids: list[str] | None = None,
    ) -> list[Dispute]:
        return _model_list(
            Dispute,
            self._http.request(
                "GET",
                "/disputes",
                query={"limit": limit, "offset": offset, "ids": ids},
            ),
        )

    def update(
        self,
        dispute_id: str,
        *,
        tags: dict[str, Any],
        idempotency_key: str | None = None,
    ) -> Dispute:
        return _model(
            Dispute,
            self._http.request(
                "PATCH",
                f"/disputes/{dispute_id}",
                body={"tags": tags},
                idempotency_key=idempotency_key,
            ),
        )
