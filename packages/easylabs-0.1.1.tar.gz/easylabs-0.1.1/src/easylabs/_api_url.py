"""API URL resolver — port of `getAPIUrl` from `@easylabs/common`."""

from __future__ import annotations

EASY_API_URL_PROD = "https://api.itseasy.co/v1/api"
EASY_API_URL_SANDBOX = "https://sandbox-api.itseasy.co/v1/api"
BASIS_THEORY_API_URL = "https://api.basistheory.com"
SANDBOX_KEY_PREFIX = "sk_test_"


def resolve(*, api_key: str) -> str:
    """Return the API URL for a given key.

    Keys prefixed `sk_test_` route to sandbox; everything else routes to
    production. For local / non-public environments, callers can bypass
    this helper entirely by passing `internal_api_url=` to `Client`.
    """
    if api_key.startswith(SANDBOX_KEY_PREFIX):
        return EASY_API_URL_SANDBOX
    return EASY_API_URL_PROD
