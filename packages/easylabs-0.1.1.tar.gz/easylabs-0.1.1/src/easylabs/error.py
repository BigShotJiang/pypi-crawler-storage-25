"""Exception hierarchy for the Easy Labs SDK.

`EasyError` is the parent for every SDK-originated error. Subclasses are
selected by HTTP status — callers can `except RateLimitError` for
targeted handling, or `except EasyError` to catch everything.

Note: `PermissionError` here shadows the Python built-in. Always import
explicitly (`from easylabs.error import PermissionError`) or reference
through the package (`easylabs.PermissionError`) to avoid ambiguity.
"""

from __future__ import annotations

from typing import Any


class EasyError(Exception):
    """Base class for SDK errors raised on non-2xx API responses."""

    def __init__(
        self,
        message: str,
        *,
        status: int,
        code: str | None = None,
        details: Any = None,
        retry_after_seconds: int | None = None,
        raw: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code
        self.details = details
        self.retry_after_seconds = retry_after_seconds
        self.raw = raw


class AuthenticationError(EasyError):
    """401 — authentication failed (bad / missing API key)."""


class PermissionError(EasyError):
    """403 — caller is authenticated but not authorized for the action."""


class NotFoundError(EasyError):
    """404 — resource does not exist."""


class ConflictError(EasyError):
    """409 — request conflicts with current resource state."""


class RateLimitError(EasyError):
    """429 — rate limit hit. See `retry_after_seconds`."""


class InvalidRequestError(EasyError):
    """400 / 422 — request was malformed or failed validation."""


class ServerError(EasyError):
    """5xx — Easy Labs server-side error."""


_STATUS_CLASSES: dict[int, type[EasyError]] = {
    400: InvalidRequestError,
    401: AuthenticationError,
    403: PermissionError,
    404: NotFoundError,
    409: ConflictError,
    422: InvalidRequestError,
    429: RateLimitError,
}


def class_for_status(status: int) -> type[EasyError]:
    """Pick the right `EasyError` subclass for a given HTTP status."""
    if status in _STATUS_CLASSES:
        return _STATUS_CLASSES[status]
    if 500 <= status < 600:
        return ServerError
    return EasyError
