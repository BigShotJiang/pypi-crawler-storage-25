"""API key validation — port of `validateApiKey` from `@easylabs/common`."""

from __future__ import annotations

import contextlib

import httpx

from .error import AuthenticationError, EasyError, class_for_status


def validate_api_key(*, api_key: str, api_url: str) -> str:
    """GET `/validate-key` to confirm the key is live; return the BT public key.

    Raises `AuthenticationError` (or another `EasyError` subclass) on a
    non-2xx response. Mirrors the JS SDK behavior.
    """
    url = f"{api_url.rstrip('/')}/validate-key"
    response = httpx.get(
        url,
        headers={
            "Content-Type": "application/json",
            "x-easy-api-key": api_key,
        },
        timeout=30.0,
    )

    if not response.is_success:
        body = None
        with contextlib.suppress(ValueError):
            body = response.json()
        cls = class_for_status(response.status_code)
        # Default to AuthenticationError when the status doesn't map to a
        # specific subclass, since /validate-key only fails for auth reasons.
        if cls is EasyError:
            cls = AuthenticationError
        raise cls(
            f"API key validation failed: {response.status_code} {response.reason_phrase}".rstrip(),
            status=response.status_code,
            raw=body,
        )

    payload = response.json()
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict) or "basisTheoryPublicApiKey" not in data:
        raise AuthenticationError(
            "API key validation succeeded but response was missing basisTheoryPublicApiKey.",
            status=response.status_code,
            raw=payload,
        )
    return str(data["basisTheoryPublicApiKey"])
