"""Internal HTTP wrapper around `httpx.Client`.

Behavior mirrors `EasyApiClient.makeRequest` in `@easylabs/common`:

  - JSON content type, `x-easy-api-key` auth header (skippable for
    embedded-checkout `validate` / `confirm` endpoints).
  - Optional `Idempotency-Key` header passed through from callers.
  - Non-2xx responses are mapped to the appropriate `EasyError` subclass
    with `status`, `code`, `details`, `retry_after_seconds`, and `raw`.
  - 204 responses return `None`. Other 2xx return parsed JSON.
"""

from __future__ import annotations

from typing import Any

import httpx

from . import _query
from .error import EasyError, class_for_status


class _HTTP:
    def __init__(
        self,
        *,
        api_url: str,
        api_key: str,
        timeout: float = 30.0,
        client: httpx.Client | None = None,
    ) -> None:
        self.api_url = api_url.rstrip("/")
        self._api_key = api_key
        self._client = client or httpx.Client(timeout=timeout)

    def request(
        self,
        method: str,
        path: str,
        *,
        query: dict[str, Any] | None = None,
        body: Any = None,
        skip_auth: bool = False,
        idempotency_key: str | None = None,
    ) -> Any:
        url = f"{self.api_url}{path}"
        encoded = _query.encode(query)
        if encoded:
            url = f"{url}?{encoded}"

        headers: dict[str, str] = {"Content-Type": "application/json"}
        if not skip_auth:
            headers["x-easy-api-key"] = self._api_key
        if idempotency_key is not None:
            headers["Idempotency-Key"] = idempotency_key

        response = self._client.request(
            method=method.upper(),
            url=url,
            headers=headers,
            json=body if body is not None else None,
        )

        if response.status_code == 204:
            return None

        if not response.is_success:
            raise self._build_error(response)

        if not response.content:
            return None
        return response.json()

    @staticmethod
    def _build_error(response: httpx.Response) -> EasyError:
        retry_after_seconds: int | None = None
        retry_after = response.headers.get("retry-after")
        if retry_after is not None:
            try:
                retry_after_seconds = int(retry_after)
            except (TypeError, ValueError):
                retry_after_seconds = None

        body: Any = None
        try:
            body = response.json()
        except ValueError:
            body = None

        code: str | None = None
        details: Any = None
        message: str
        if (
            isinstance(body, dict)
            and body.get("success") is False
            and isinstance(body.get("error"), dict)
        ):
            err = body["error"]
            code = err.get("code") or None
            details = err.get("details")
            message = f"API request failed: {err}"
        else:
            message = (
                f"API request failed: {response.status_code} {response.reason_phrase}".rstrip()
            )

        cls = class_for_status(response.status_code)
        return cls(
            message,
            status=response.status_code,
            code=code,
            details=details,
            retry_after_seconds=retry_after_seconds,
            raw=body,
        )
