"""Client-side session discovery and parsing for ``nmem t save --from ...``.

This module intentionally duplicates some host transcript logic that also exists
on the server side. That duplication is deliberate because ``nmem-cli`` is
published separately on PyPI and must remain able to perform remote-safe capture
without importing server internals.

Maintenance rule:
- if Claude Code, Codex, or Gemini CLI change their transcript formats or
  storage layout, update this client module and the corresponding server-local
  parser/import path in the same change
- keep the normalized thread output aligned across both sides
"""

import hashlib
import json
import logging
import os
import re
import sqlite3
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Optional


logger = logging.getLogger(__name__)


def _env_path(env_var: str, default: Path) -> Path:
    raw = os.environ.get(env_var, "").strip()
    if not raw:
        return default
    return Path(raw).expanduser()


def _get_claude_projects_dir() -> Path:
    return _env_path("CLAUDE_CONFIG_DIR", Path.home() / ".claude") / "projects"


def _get_codex_sessions_dir() -> Path:
    return _env_path("CODEX_HOME", Path.home() / ".codex") / "sessions"


def _encode_claude_project_path(project_path: str) -> str:
    return _encode_claude_project_path_variant(
        project_path,
        preserve_hidden_dot=False,
    )


def _encode_claude_project_path_legacy(project_path: str) -> str:
    return _encode_claude_project_path_variant(
        project_path,
        preserve_hidden_dot=True,
    )


def _resolve_claude_project_dir(project_path: str) -> tuple[Optional[Path], Path]:
    claude_projects_dir = _get_claude_projects_dir()
    candidate_dirs: list[Path] = []
    for encoded in (
        _encode_claude_project_path(project_path),
        _encode_claude_project_path_legacy(project_path),
    ):
        candidate = claude_projects_dir / encoded
        if candidate not in candidate_dirs:
            candidate_dirs.append(candidate)

    for candidate in candidate_dirs:
        if candidate.exists() and candidate.is_dir():
            return candidate, candidate_dirs[0]

    normalized_project_path = _normalize_project_path(project_path)
    if claude_projects_dir.exists() and claude_projects_dir.is_dir():
        for project_dir in claude_projects_dir.iterdir():
            if not project_dir.is_dir():
                continue

            decoded_path = _decode_claude_project_dir_name(project_dir.name)
            if (
                decoded_path is not None
                and _normalize_project_path(decoded_path) == normalized_project_path
            ):
                return project_dir, candidate_dirs[0]

    return None, candidate_dirs[0]


class SessionImportError(Exception):
    def __init__(self, error: str, hint: Optional[str] = None) -> None:
        super().__init__(error)
        self.error = error
        self.hint = hint


@dataclass
class SessionCandidate:
    file: Path
    session_id: str
    sort_key: float
    user_messages: int = 0
    assistant_messages: int = 0


def discover_sessions(
    client: str,
    project_path: str,
    persist_mode: str,
    session_id: Optional[str],
) -> list[SessionCandidate]:
    if client == "claude-code":
        candidates = _discover_claude_sessions(project_path)
    elif client == "codex":
        candidates = _discover_codex_sessions(project_path, session_id)
    elif client == "gemini-cli":
        candidates = _discover_gemini_sessions(project_path, session_id)
    elif client == "opencode":
        candidates = _discover_opencode_sessions(project_path, session_id)
    else:
        raise SessionImportError(
            f"Unsupported client: {client}. Supported: claude-code, codex, gemini-cli, opencode"
        )

    if not candidates:
        raise SessionImportError(f"No {client} sessions found for project: {project_path}")

    return candidates if persist_mode == "all" else [candidates[0]]


def parse_session(
    client: str,
    file_path: Path,
    truncate_large_content: bool = False,
    session_id: Optional[str] = None,
) -> dict[str, Any]:
    if client == "claude-code":
        return parse_claude_code_session_streaming(file_path, truncate_large_content)
    if client == "codex":
        return parse_codex_session_streaming(file_path, truncate_large_content)
    if client == "gemini-cli":
        return parse_gemini_session(file_path)
    if client == "opencode":
        return parse_opencode_session(file_path, session_id=session_id)
    raise SessionImportError(
        f"Unsupported client: {client}. Supported: claude-code, codex, gemini-cli, opencode"
    )


def _discover_claude_sessions(project_path: str) -> list[SessionCandidate]:
    claude_base, expected_claude_base = _resolve_claude_project_dir(project_path)
    if claude_base is None:
        raise SessionImportError(
            f"Claude Code session directory not found for project: {project_path}",
            (
                "Make sure Claude Code has created sessions for this project "
                f"(expected under {expected_claude_base})"
            ),
        )

    candidates: list[SessionCandidate] = []

    for session_file in claude_base.glob("*.jsonl"):
        try:
            with open(session_file, "r", encoding="utf-8") as handle:
                lines = handle.readlines()

            user_messages = 0
            assistant_messages = 0
            last_message_time: Optional[float] = None

            for line in lines:
                try:
                    event = json.loads(line.strip())
                except json.JSONDecodeError:
                    continue

                if not isinstance(event, dict):
                    continue

                event_type = event.get("type")
                if event_type in ["file-history-snapshot", "summary"]:
                    continue

                if event_type in ["user", "assistant"]:
                    timestamp_str = event.get("timestamp")
                    if isinstance(timestamp_str, str):
                        try:
                            dt = datetime.fromisoformat(
                                timestamp_str.replace("Z", "+00:00")
                            )
                            timestamp_unix = dt.timestamp()
                            if (
                                last_message_time is None
                                or timestamp_unix > last_message_time
                            ):
                                last_message_time = timestamp_unix
                        except (ValueError, AttributeError):
                            pass

                if event_type == "user":
                    msg_content = event.get("message", {}).get("content", "")
                    if msg_content not in ["Warmup", "warmup"] and not event.get(
                        "isMeta"
                    ):
                        user_messages += 1
                elif event_type == "assistant":
                    assistant_messages += 1

            if user_messages > 0 or assistant_messages > 1:
                sort_key = last_message_time or session_file.stat().st_mtime
                candidates.append(
                    SessionCandidate(
                        file=session_file,
                        session_id=session_file.stem,
                        sort_key=sort_key,
                        user_messages=user_messages,
                        assistant_messages=assistant_messages,
                    )
                )
        except Exception as exc:
            logger.warning(
                "Failed to analyze Claude session file %s: %s",
                session_file,
                exc,
            )
            continue

    if not candidates:
        raise SessionImportError(
            f"No valid conversation sessions found in: {claude_base}",
            "Found session files, but they only contain snapshots or warmup messages",
        )

    candidates.sort(key=lambda s: (s.sort_key, s.file.stat().st_mtime), reverse=True)
    return candidates


def _discover_codex_sessions(
    project_path: str, target_session_id: Optional[str]
) -> list[SessionCandidate]:
    codex_base = _get_codex_sessions_dir()
    if not codex_base.exists() or not codex_base.is_dir():
        raise SessionImportError(
            f"Codex sessions directory not found: {codex_base}",
            "Make sure Codex has created sessions",
        )

    candidates: list[SessionCandidate] = []
    for session_file in codex_base.glob("**/rollout-*.jsonl"):
        try:
            with open(session_file, "r", encoding="utf-8") as handle:
                first_line = handle.readline().strip()
            if not first_line:
                continue

            session_meta = json.loads(first_line)
            if session_meta.get("type") != "session_meta":
                continue

            payload = session_meta.get("payload", {})
            session_cwd = payload.get("cwd", "")
            if session_cwd != project_path:
                continue

            filename = session_file.stem
            parts = filename.rsplit("-", 1)
            file_session_id = parts[1] if len(parts) > 1 else filename
            if target_session_id and file_session_id != target_session_id:
                continue

            candidates.append(
                SessionCandidate(
                    file=session_file,
                    session_id=file_session_id,
                    sort_key=session_file.stat().st_mtime,
                )
            )
        except Exception as exc:
            logger.warning(
                "Failed to analyze Codex session file %s: %s",
                session_file,
                exc,
            )
            continue

    candidates.sort(key=lambda s: s.sort_key, reverse=True)
    return candidates


def _discover_gemini_sessions(
    project_path: str, target_session_id: Optional[str]
) -> list[SessionCandidate]:
    gemini_chats_dir = _resolve_gemini_chats_dir(project_path)
    if gemini_chats_dir is None:
        expected_hash_dir = (
            Path.home()
            / ".gemini"
            / "tmp"
            / hashlib.sha256(project_path.encode("utf-8")).hexdigest()
            / "chats"
        )
        raise SessionImportError(
            f"Gemini CLI session directory not found for project: {project_path}",
            (
                "Make sure Gemini CLI has created sessions for this project. "
                f"Checked hashed path {expected_hash_dir} and Gemini registry/markers."
            ),
        )

    candidates: list[SessionCandidate] = []
    for session_file in gemini_chats_dir.glob("session-*.json"):
        try:
            with open(session_file, "r", encoding="utf-8") as handle:
                conversation = json.load(handle)

            if not isinstance(conversation, dict):
                continue

            file_session_id = conversation.get("sessionId") or session_file.stem
            if target_session_id and file_session_id != target_session_id:
                continue

            messages = conversation.get("messages", [])
            if not isinstance(messages, list):
                continue

            user_messages = sum(
                1
                for msg in messages
                if isinstance(msg, dict) and msg.get("type") == "user"
            )
            assistant_messages = sum(
                1
                for msg in messages
                if isinstance(msg, dict) and msg.get("type") == "gemini"
            )
            if user_messages == 0 and assistant_messages == 0:
                continue

            last_updated = conversation.get("lastUpdated")
            sort_key = session_file.stat().st_mtime
            if isinstance(last_updated, str):
                try:
                    sort_key = datetime.fromisoformat(
                        last_updated.replace("Z", "+00:00")
                    ).timestamp()
                except (ValueError, AttributeError):
                    pass

            candidates.append(
                SessionCandidate(
                    file=session_file,
                    session_id=str(file_session_id),
                    sort_key=sort_key,
                    user_messages=user_messages,
                    assistant_messages=assistant_messages,
                )
            )
        except Exception as exc:
            logger.warning(
                "Failed to analyze Gemini session file %s: %s",
                session_file,
                exc,
            )
            continue

    candidates.sort(key=lambda s: (s.sort_key, s.file.stat().st_mtime), reverse=True)
    return candidates


def _get_opencode_base_path() -> Path:
    home = Path.home()
    if sys.platform == "darwin" or sys.platform == "win32":
        return home / ".local" / "share" / "opencode"

    xdg_data = os.environ.get("XDG_DATA_HOME", "").strip()
    if xdg_data:
        return Path(xdg_data).expanduser() / "opencode"
    return home / ".local" / "share" / "opencode"


def _get_opencode_db_path(base_path: Path) -> Optional[Path]:
    db_path = base_path / "opencode.db"
    if db_path.exists():
        return db_path

    if base_path.name == "storage":
        parent_db = base_path.parent / "opencode.db"
        if parent_db.exists():
            return parent_db
    return None


def _safe_opencode_sqlite_connect(db_path: Path) -> Optional[sqlite3.Connection]:
    max_retries = 3
    delays = [0.1, 0.2, 0.4]

    for attempt in range(max_retries):
        try:
            conn = sqlite3.connect(
                f"file:{db_path}?mode=ro",
                timeout=5,
                uri=True,
            )
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.OperationalError as exc:
            if "database is locked" in str(exc) and attempt < max_retries - 1:
                time.sleep(delays[attempt])
                continue
            logger.warning(
                "Failed to connect to OpenCode database %s: %s",
                db_path,
                exc,
            )
            return None
        except Exception as exc:
            logger.warning(
                "Unexpected error connecting to OpenCode database %s: %s",
                db_path,
                exc,
            )
            return None

    return None


def _discover_opencode_sessions(
    project_path: str, target_session_id: Optional[str]
) -> list[SessionCandidate]:
    base_path = _get_opencode_base_path()
    normalized_project_path = _normalize_project_path(project_path)
    candidates: list[SessionCandidate] = []
    seen_session_ids: set[str] = set()

    db_path = _get_opencode_db_path(base_path)
    if db_path and db_path.exists():
        conn = _safe_opencode_sqlite_connect(db_path)
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute(
                    """
                    SELECT
                        s.id,
                        s.directory,
                        s.time_created,
                        s.time_updated,
                        (
                            SELECT COUNT(*)
                            FROM message m
                            WHERE m.session_id = s.id
                        ) AS message_count
                    FROM session s
                    WHERE s.time_archived IS NULL
                    ORDER BY s.time_updated DESC
                    """
                )
                for row in cursor.fetchall():
                    session_project = str(row["directory"] or "")
                    if _normalize_project_path(session_project) != normalized_project_path:
                        continue

                    file_session_id = str(row["id"])
                    if target_session_id and file_session_id != target_session_id:
                        continue

                    message_count = int(row["message_count"] or 0)
                    if message_count <= 0:
                        continue

                    sort_key = float(
                        row["time_updated"] or row["time_created"] or 0.0
                    )
                    candidates.append(
                        SessionCandidate(
                            file=db_path,
                            session_id=file_session_id,
                            sort_key=sort_key,
                            user_messages=message_count,
                        )
                    )
                    seen_session_ids.add(file_session_id)
            finally:
                conn.close()

    storage_root = base_path / "storage"
    session_root = storage_root / "session"
    if session_root.exists() and session_root.is_dir():
        for session_file in session_root.glob("*/*.json"):
            try:
                with open(session_file, "r", encoding="utf-8") as handle:
                    session_data = json.load(handle)
            except Exception as exc:
                logger.warning(
                    "Failed to analyze OpenCode session file %s: %s",
                    session_file,
                    exc,
                )
                continue

            if not isinstance(session_data, dict):
                continue

            session_project = str(session_data.get("directory") or "")
            if _normalize_project_path(session_project) != normalized_project_path:
                continue

            file_session_id = str(session_data.get("id") or session_file.stem)
            if target_session_id and file_session_id != target_session_id:
                continue
            if file_session_id in seen_session_ids:
                continue

            message_dir = storage_root / "message" / file_session_id
            message_count = len(list(message_dir.glob("*.json"))) if message_dir.exists() else 0
            if message_count <= 0:
                continue

            sort_key = session_file.stat().st_mtime
            updated = session_data.get("time", {}).get("updated")
            created = session_data.get("time", {}).get("created")
            if isinstance(updated, (int, float)):
                sort_key = float(updated)
            elif isinstance(created, (int, float)):
                sort_key = float(created)

            candidates.append(
                SessionCandidate(
                    file=session_file,
                    session_id=file_session_id,
                    sort_key=sort_key,
                    user_messages=message_count,
                )
            )

    candidates.sort(key=lambda s: (s.sort_key, s.file.stat().st_mtime), reverse=True)
    return candidates


def _resolve_gemini_chats_dir(project_path: str) -> Optional[Path]:
    gemini_root = Path.home() / ".gemini"
    tmp_root = gemini_root / "tmp"
    hashed_dir = tmp_root / hashlib.sha256(project_path.encode("utf-8")).hexdigest() / "chats"
    if hashed_dir.exists() and hashed_dir.is_dir():
        return hashed_dir

    registry_path = gemini_root / "projects.json"
    try:
        if registry_path.exists():
            registry = json.loads(registry_path.read_text(encoding="utf-8"))
            projects = registry.get("projects", {}) if isinstance(registry, dict) else {}
            short_id = projects.get(project_path)
            if isinstance(short_id, str) and short_id.strip():
                short_dir = tmp_root / short_id / "chats"
                if short_dir.exists() and short_dir.is_dir():
                    return short_dir
    except Exception as exc:
        logger.warning("Failed to read Gemini project registry: %s", exc)

    try:
        if tmp_root.exists():
            for candidate in tmp_root.iterdir():
                if not candidate.is_dir():
                    continue
                marker = candidate / ".project_root"
                chats_dir = candidate / "chats"
                if not marker.exists() or not chats_dir.exists() or not chats_dir.is_dir():
                    continue
                try:
                    owner = marker.read_text(encoding="utf-8").strip()
                except Exception:
                    continue
                if owner == project_path:
                    return chats_dir
    except Exception as exc:
        logger.warning("Failed to scan Gemini temp directories: %s", exc)

    return None


def parse_codex_session_streaming(
    file_path: Path, truncate_large_content: bool = False
) -> dict[str, Any]:
    del truncate_large_content
    session_meta: Optional[dict[str, Any]] = None
    messages: list[dict[str, Any]] = []
    first_user_content: Optional[str] = None
    seen_message_hashes: set[str] = set()

    with open(file_path, "r", encoding="utf-8") as handle:
        for line_num, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue

            try:
                record: dict[str, Any] = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipping invalid Codex JSON on line %s", line_num)
                continue

            if not isinstance(record, dict):
                continue

            record_type = record.get("type")
            timestamp = record.get("timestamp")

            if record_type == "session_meta" and not session_meta:
                payload = record.get("payload", {})
                session_meta = {
                    "id": payload.get("id"),
                    "timestamp": payload.get("timestamp"),
                    "cwd": payload.get("cwd"),
                    "originator": payload.get("originator"),
                    "cli_version": payload.get("cli_version"),
                    "source": payload.get("source"),
                    "git": payload.get("git"),
                }
                continue

            role: Optional[str] = None
            content_text: Optional[str] = None
            content_extracted = False

            if record_type == "event_msg":
                payload = record.get("payload", {})
                msg_type = payload.get("type")
                if msg_type == "user_message" and payload.get("kind") == "plain":
                    role = "user"
                    content_text = payload.get("message", "")
                    content_extracted = True
                elif msg_type == "agent_message":
                    role = "assistant"
                    content_text = payload.get("message", "")
                    content_extracted = True
            elif record_type == "response_item" and not content_extracted:
                payload = record.get("payload", {})
                if payload.get("type") == "message":
                    role = payload.get("role")
                    content_items = payload.get("content", [])
                    text_parts: list[str] = []
                    for item in content_items:
                        if isinstance(item, dict) and item.get("type") in [
                            "input_text",
                            "output_text",
                        ]:
                            text = item.get("text", "")
                            if isinstance(text, str) and text.strip():
                                text_parts.append(text)
                    content_text = "\n".join(text_parts) if text_parts else None

            if role and content_text and content_text.strip():
                message_hash = hashlib.md5(f"{role}:{content_text}".encode()).hexdigest()
                if message_hash in seen_message_hashes:
                    continue
                seen_message_hashes.add(message_hash)

                if role == "user" and not first_user_content:
                    first_user_content = content_text

                messages.append(
                    {
                        "role": role,
                        "content": content_text,
                        "timestamp": timestamp,
                    }
                )

    if not session_meta:
        raise SessionImportError("No session_meta found in Codex rollout file")
    if not messages:
        raise SessionImportError(
            "No valid user/assistant messages found in Codex rollout file"
        )

    title = "Codex Session"
    if first_user_content:
        title = first_user_content[:60].replace("\n", " ").strip()
        if len(first_user_content) > 60:
            title += "..."
    elif session_meta.get("cwd"):
        project_name = os.path.basename(str(session_meta["cwd"]).rstrip("/\\"))
        title = f"Codex: {project_name}"

    session_id = session_meta.get("id") or file_path.stem
    return {
        "thread_id": f"codex-{session_id}",
        "title": title,
        "messages": messages,
        "source": "codex",
        "workspace": session_meta.get("cwd"),
        "metadata": {
            "session_id": session_id,
            "timestamp": session_meta.get("timestamp"),
            "cwd": session_meta.get("cwd"),
            "git": session_meta.get("git"),
            "cli_version": session_meta.get("cli_version"),
            "originator": session_meta.get("originator"),
            "original_file_path": str(file_path),
        },
    }


def parse_gemini_session(file_path: Path) -> dict[str, Any]:
    with open(file_path, "r", encoding="utf-8") as handle:
        conversation = json.load(handle)

    if not isinstance(conversation, dict):
        raise SessionImportError("Gemini session file must contain a JSON object")

    messages_raw = conversation.get("messages")
    if not isinstance(messages_raw, list):
        raise SessionImportError("Gemini session file missing messages array")

    session_id = conversation.get("sessionId") or file_path.stem
    project_hash = conversation.get("projectHash")
    start_time = conversation.get("startTime")
    last_updated = conversation.get("lastUpdated")
    kind = conversation.get("kind")
    directories = conversation.get("directories")

    messages: list[dict[str, Any]] = []
    first_user_content: Optional[str] = None

    for msg in messages_raw:
        if not isinstance(msg, dict):
            continue

        msg_type = msg.get("type")
        if msg_type not in ("user", "gemini"):
            continue

        role = "user" if msg_type == "user" else "assistant"
        content_text = _extract_gemini_text_parts(msg.get("content"))
        if not content_text.strip():
            content_text = _extract_gemini_text_parts(msg.get("displayContent"))
        if not content_text.strip():
            continue

        if role == "user" and not first_user_content:
            first_user_content = content_text

        messages.append(
            {
                "role": role,
                "content": content_text,
                "timestamp": msg.get("timestamp"),
            }
        )

    if not messages:
        raise SessionImportError(
            "No valid user/assistant messages found in Gemini session file"
        )

    title = "Gemini CLI Session"
    if first_user_content:
        title = first_user_content[:60].replace("\n", " ").strip()
        if len(first_user_content) > 60:
            title += "..."
    elif isinstance(directories, list) and directories:
        first_dir = directories[0]
        if isinstance(first_dir, str) and first_dir.strip():
            project_name = os.path.basename(first_dir.rstrip("/\\"))
            if project_name:
                title = f"Gemini CLI: {project_name}"

    return {
        "thread_id": f"gemini-cli-{session_id}",
        "title": title,
        "messages": messages,
        "source": "gemini-cli",
        "workspace": directories[0] if isinstance(directories, list) and directories else None,
        "metadata": {
            "session_id": session_id,
            "project_hash": project_hash,
            "start_time": start_time,
            "last_updated": last_updated,
            "kind": kind,
            "directories": directories,
            "original_file_path": str(file_path),
        },
    }


def parse_opencode_session(
    file_path: Path,
    *,
    session_id: Optional[str],
) -> dict[str, Any]:
    if file_path.suffix.lower() == ".db":
        if not session_id:
            raise SessionImportError("OpenCode SQLite import requires a session_id")
        return _parse_opencode_sqlite_session(file_path, session_id)
    return _parse_opencode_json_session(file_path)


def _parse_opencode_sqlite_session(db_path: Path, session_id: str) -> dict[str, Any]:
    conn = _safe_opencode_sqlite_connect(db_path)
    if conn is None:
        raise SessionImportError(f"Failed to connect to OpenCode database: {db_path}")

    try:
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT id, project_id, directory, title, version, time_created
            FROM session
            WHERE id = ?
            """,
            (session_id,),
        )
        session_row = cursor.fetchone()
        if session_row is None:
            raise SessionImportError(f"Session not found in OpenCode database: {session_id}")

        parts_by_message: dict[str, list[dict[str, Any]]] = {}
        cursor.execute(
            """
            SELECT message_id, data
            FROM part
            WHERE session_id = ?
            ORDER BY message_id, id ASC
            """,
            (session_id,),
        )
        for row in cursor.fetchall():
            message_id = str(row["message_id"])
            try:
                part_data = (
                    json.loads(row["data"])
                    if isinstance(row["data"], str)
                    else row["data"]
                )
            except Exception:
                continue
            if not isinstance(part_data, dict):
                continue
            parts_by_message.setdefault(message_id, []).append(part_data)

        cursor.execute(
            """
            SELECT id, data, time_created
            FROM message
            WHERE session_id = ?
            ORDER BY time_created ASC
            """,
            (session_id,),
        )

        messages: list[dict[str, Any]] = []
        first_user_content: Optional[str] = None
        for row in cursor.fetchall():
            try:
                message_data = (
                    json.loads(row["data"])
                    if isinstance(row["data"], str)
                    else row["data"]
                )
            except Exception:
                continue
            if not isinstance(message_data, dict):
                continue

            role = str(message_data.get("role") or "user")
            content_parts: list[str] = []
            for part in parts_by_message.get(str(row["id"]), []):
                formatted = _format_opencode_part(part)
                if formatted:
                    content_parts.append(formatted)
            content = "\n".join(content_parts).strip()
            if not content:
                continue

            if role == "user" and not first_user_content:
                first_user_content = content

            messages.append(
                {
                    "role": role,
                    "content": content,
                    "timestamp": row["time_created"],
                }
            )

        if not messages:
            raise SessionImportError(
                "No valid user/assistant messages found in OpenCode session"
            )

        session_title = str(session_row["title"] or "")
        if (
            not session_title
            or session_title.startswith("New session - ")
            or session_title.startswith("Child session - ")
        ):
            session_title = _build_opencode_title(first_user_content)

        return {
            "thread_id": f"opencode-{session_id}",
            "title": session_title,
            "messages": messages,
            "source": "opencode",
            "workspace": session_row["directory"],
            "metadata": {
                "session_id": session_id,
                "project_id": session_row["project_id"],
                "directory": session_row["directory"],
                "version": session_row["version"],
                "storage": "sqlite",
                "original_file_path": str(db_path),
            },
        }
    finally:
        conn.close()


def _parse_opencode_json_session(session_path: Path) -> dict[str, Any]:
    with open(session_path, "r", encoding="utf-8") as handle:
        session_data = json.load(handle)

    if not isinstance(session_data, dict):
        raise SessionImportError("OpenCode session file must contain a JSON object")

    session_id = str(session_data.get("id") or session_path.stem)
    storage_base = session_path.parent.parent.parent
    message_path = storage_base / "message" / session_id

    messages: list[dict[str, Any]] = []
    first_user_content: Optional[str] = None
    if message_path.exists():
        for msg_file in sorted(message_path.glob("*.json"), key=lambda p: (len(p.stem), p.stem)):
            try:
                with open(msg_file, "r", encoding="utf-8") as handle:
                    message_data = json.load(handle)
            except Exception:
                continue
            if not isinstance(message_data, dict):
                continue

            role = str(message_data.get("role") or "user")
            msg_id = str(message_data.get("id") or msg_file.stem)
            timestamp = message_data.get("time", {}).get("created")

            content_parts: list[str] = []
            part_path = storage_base / "part" / msg_id
            if part_path.exists():
                for part_file in sorted(part_path.glob("*.json"), key=lambda p: (len(p.stem), p.stem)):
                    try:
                        with open(part_file, "r", encoding="utf-8") as handle:
                            part_data = json.load(handle)
                    except Exception:
                        continue
                    if not isinstance(part_data, dict):
                        continue
                    formatted = _format_opencode_part(part_data)
                    if formatted:
                        content_parts.append(formatted)
            content = "\n".join(content_parts).strip()
            if not content:
                continue

            if role == "user" and not first_user_content:
                first_user_content = content

            messages.append(
                {
                    "role": role,
                    "content": content,
                    "timestamp": timestamp,
                }
            )

    if not messages:
        raise SessionImportError(
            "No valid user/assistant messages found in OpenCode session"
        )

    title = str(session_data.get("title") or "")
    if (
        not title
        or title.startswith("New session - ")
        or title.startswith("Child session - ")
    ):
        title = _build_opencode_title(first_user_content)

    return {
        "thread_id": f"opencode-{session_id}",
        "title": title,
        "messages": messages,
        "source": "opencode",
        "workspace": session_data.get("directory"),
        "metadata": {
            "session_id": session_id,
            "project_id": session_data.get("projectID"),
            "directory": session_data.get("directory"),
            "version": session_data.get("version"),
            "storage": "json",
            "original_file_path": str(session_path),
        },
    }


def _build_opencode_title(first_user_content: Optional[str]) -> str:
    if first_user_content:
        title = first_user_content[:60].replace("\n", " ").strip()
        if len(first_user_content) > 60:
            title += "..."
        if title:
            return title
    return "OpenCode Session"


def _format_opencode_part(part_data: dict[str, Any]) -> str:
    part_type = part_data.get("type")

    if part_type == "text":
        text = part_data.get("text", "")
        if isinstance(text, str) and text and not part_data.get("ignored"):
            return text

    if part_type == "tool":
        return _format_opencode_tool_part(part_data)

    if part_type == "reasoning":
        text = part_data.get("text", "")
        if isinstance(text, str) and text:
            return f"<thinking>{text}</thinking>"

    if part_type == "file":
        file_path = part_data.get("path", part_data.get("file", ""))
        if isinstance(file_path, str) and file_path:
            return f"[File: {file_path}]"

    if part_type == "patch":
        patch_text = part_data.get("content", part_data.get("text", ""))
        if isinstance(patch_text, str) and patch_text:
            truncated = patch_text[:500]
            if len(patch_text) > 500:
                truncated += "..."
            return f"[Patch]\n{truncated}"

    if part_type in ("agent", "subtask"):
        description = part_data.get("description", part_data.get("text", ""))
        if isinstance(description, str) and description:
            return f"[{part_type.title()}: {description}]"

    return ""


def _format_opencode_tool_part(part_data: dict[str, Any]) -> str:
    tool_name = str(part_data.get("tool") or "unknown")
    state = part_data.get("state", {})
    if not isinstance(state, dict):
        return f"[Tool: {tool_name}]"

    status = str(state.get("status") or "")
    title = str(state.get("title") or "")
    tool_input = state.get("input", {})
    metadata = state.get("metadata", {})
    line = f"[Tool: {tool_name}]"

    if title:
        line += f" {title}"
    else:
        input_summary = _summarize_opencode_tool_input(tool_name, tool_input)
        if input_summary:
            line += f" {input_summary}"

    annotations = _format_opencode_tool_metadata(tool_name, metadata)
    if annotations:
        line += f" {annotations}"

    if status == "error":
        error_text = str(state.get("error") or "")
        if error_text:
            line += f" — Error: {error_text[:200]}"
        return line

    if tool_name == "bash" and status == "completed":
        output = state.get("output")
        if output is not None:
            output_text = str(output).strip()
            if output_text:
                truncated = output_text[:500]
                if len(output_text) > 500:
                    truncated += "..."
                return f"{line}\n{truncated}"

    return line


def _summarize_opencode_tool_input(tool_name: str, tool_input: Any) -> str:
    if not isinstance(tool_input, dict):
        return ""

    if tool_name == "bash":
        command = tool_input.get("command", "")
        description = tool_input.get("description", "")
        if isinstance(command, str) and command:
            display = command[:200]
            if len(command) > 200:
                display += "..."
            return f"$ {display}"
        if isinstance(description, str):
            return description

    if tool_name == "read":
        file_path = tool_input.get("filePath", "")
        if isinstance(file_path, str) and file_path:
            return f"File: {file_path}"

    if tool_name == "glob":
        pattern = tool_input.get("pattern", "")
        if isinstance(pattern, str) and pattern:
            return f"Pattern: {pattern}"

    if tool_name == "grep":
        pattern = tool_input.get("pattern", "")
        path = tool_input.get("path", "")
        if isinstance(pattern, str) and pattern:
            if isinstance(path, str) and path:
                return f"Pattern: {pattern} in {path}"
            return f"Pattern: {pattern}"

    if tool_name == "webfetch":
        url = tool_input.get("url", "")
        if isinstance(url, str) and url:
            return f"URL: {url}"

    if tool_name == "task":
        description = tool_input.get("description", "")
        if isinstance(description, str) and description:
            return f"Task: {description}"

    return ""


def _format_opencode_tool_metadata(tool_name: str, metadata: Any) -> str:
    if not isinstance(metadata, dict):
        return ""

    annotations: list[str] = []
    if tool_name == "bash":
        exit_code = metadata.get("exit")
        if exit_code is not None and exit_code != 0:
            annotations.append(f"exit={exit_code}")
    elif tool_name == "grep":
        matches = metadata.get("matches")
        if matches is not None:
            annotations.append(f"{matches} matches")
        if metadata.get("truncated"):
            annotations.append("truncated")
    elif tool_name == "glob":
        count = metadata.get("count")
        if count is not None:
            annotations.append(f"{count} files")

    return f"({', '.join(annotations)})" if annotations else ""


def _extract_gemini_text_parts(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, dict):
        text = content.get("text")
        return text if isinstance(text, str) else ""
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            text = _extract_gemini_text_parts(item)
            if text.strip():
                parts.append(text)
        return "\n".join(parts)
    return ""


def parse_claude_code_session_streaming(
    file_path: Path, truncate_large_content: bool = False
) -> dict[str, Any]:
    events: list[dict[str, Any]] = []
    session_id = None
    cwd = None
    decoded_path = _decode_claude_project_path(file_path)

    with open(file_path, "r", encoding="utf-8") as handle:
        for line_num, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipping invalid Claude JSON on line %s", line_num)
                continue
            if not isinstance(event, dict):
                continue
            event_type = event.get("type")
            if "sessionId" in event and not session_id:
                session_id = event["sessionId"]
            if "cwd" in event and not cwd:
                cwd = event["cwd"]
            if event_type in ["user", "assistant"]:
                events.append(event)

    if not events:
        raise SessionImportError("No valid user/assistant messages found in JSONL file")

    messages: list[dict[str, Any]] = []
    first_user_content = None

    i = 0
    while i < len(events):
        event = events[i]
        role = event.get("message", {}).get("role", event.get("type"))

        turn_events = [event]
        current_uuid = event.get("uuid")
        timestamp = event.get("timestamp")

        j = i + 1
        while j < len(events):
            next_event = events[j]
            next_role = next_event.get("message", {}).get("role", next_event.get("type"))
            if next_role != role:
                break
            if next_event.get("parentUuid") == current_uuid:
                turn_events.append(next_event)
                current_uuid = next_event.get("uuid")
                j += 1
            else:
                break

        content_parts: list[str] = []
        for evt in turn_events:
            msg_data = evt.get("message", {})
            if not isinstance(msg_data, dict):
                continue
            content_raw = msg_data.get("content", "")
            if isinstance(content_raw, str):
                if content_raw.strip():
                    content_parts.append(content_raw)
            elif isinstance(content_raw, list):
                for block in content_raw:
                    if isinstance(block, dict):
                        if block.get("type") == "text":
                            text = block.get("text", "")
                            if isinstance(text, str) and text.strip():
                                content_parts.append(text)
                        elif block.get("type") == "tool_use":
                            tool_name = block.get("name", "unknown_tool")
                            tool_input = block.get("input", {})
                            tool_summary = _summarize_claude_tool_input(tool_name, tool_input)
                            if tool_summary:
                                content_parts.append(
                                    f"[Used tool: {tool_name}] {tool_summary}"
                                )
                            else:
                                content_parts.append(f"[Used tool: {tool_name}]")
                    elif isinstance(block, str) and block.strip():
                        content_parts.append(block)

        content = "\n\n".join(content_parts) if content_parts else ""
        if not content.strip():
            i = max(i + 1, j)
            continue

        if role == "user" and not first_user_content:
            first_user_content = content

        messages.append(
            {
                "role": role,
                "content": content,
                "timestamp": timestamp,
                "metadata": {
                    "uuid": event.get("uuid"),
                    "parentUuid": event.get("parentUuid"),
                    "turn_event_count": len(turn_events),
                },
            }
        )
        i = max(i + 1, j)

    if not messages:
        raise SessionImportError("No valid user/assistant messages found in JSONL file")

    title = "Claude Code Session"
    if first_user_content:
        title = first_user_content[:60].replace("\n", " ").strip()
        if len(first_user_content) > 60:
            title += "..."
    elif decoded_path:
        project_name = os.path.basename(decoded_path.rstrip("/\\"))
        title = f"Claude Code: {project_name}"

    thread_id = session_id or file_path.stem
    thread_data: dict[str, Any] = {
        "thread_id": f"claude-code-{thread_id}",
        "title": title,
        "messages": messages,
        "source": "claude-code",
        "workspace": cwd or decoded_path,
        "metadata": {
            "sessionId": session_id,
            "cwd": cwd,
            "original_file_path": str(file_path),
        },
    }
    if decoded_path:
        thread_data["metadata"]["decoded_project_path"] = decoded_path

    subagent_files = _discover_claude_subagent_files(file_path)
    if subagent_files:
        subagents = []
        total_subagent_messages = 0
        for agent_file in subagent_files:
            subagent_data = _parse_claude_subagent_file(
                agent_file, truncate_large_content
            )
            if subagent_data:
                subagents.append(subagent_data)
                total_subagent_messages += subagent_data["message_count"]
        if subagents:
            thread_data["metadata"]["subagents"] = subagents
            thread_data["metadata"]["subagent_count"] = len(subagents)
            thread_data["metadata"]["total_subagent_messages"] = total_subagent_messages

    return thread_data


def _decode_claude_project_path(file_path: Path) -> Optional[str]:
    project_indices = [
        idx for idx, part in enumerate(file_path.parts) if part == "projects"
    ]
    if not project_indices:
        return None

    projects_idx = project_indices[-1]
    if projects_idx + 1 >= len(file_path.parts):
        return None

    encoded_dir = file_path.parts[projects_idx + 1]
    return _decode_claude_project_dir_name(encoded_dir)


def _decode_claude_project_dir_name(encoded: str) -> Optional[str]:
    decoded = _decode_project_path_enhanced(encoded)
    if decoded is not None:
        return decoded
    return _decode_project_path_windows(encoded)


def _decode_project_path_enhanced(encoded: str) -> Optional[str]:
    if not encoded or not encoded.startswith("-"):
        return None

    simple = "/" + encoded[1:].replace("-", "/")
    if os.path.exists(simple):
        return simple

    segments = encoded[1:].split("-")
    result = _find_valid_path("/", segments)
    if result:
        return result

    return simple


def _find_valid_path(base: str, remaining: list[str]) -> Optional[str]:
    if not remaining:
        return base if os.path.exists(base) else None

    if remaining[0] == "" and len(remaining) >= 2 and remaining[1]:
        for prefix in (".", "-"):
            result = _find_valid_path(base, [prefix + remaining[1], *remaining[2:]])
            if result:
                return result

    next_segment = remaining[0]
    with_slash = os.path.join(base, next_segment)
    if os.path.exists(with_slash):
        result = _find_valid_path(with_slash, remaining[1:])
        if result:
            return result

    if len(remaining) >= 2:
        combined = remaining[0] + "-" + remaining[1]
        result = _find_valid_path(base, [combined] + remaining[2:])
        if result:
            return result

    return None


def _decode_project_path_windows(encoded: str) -> Optional[str]:
    drive_match = re.match(r"^([A-Za-z])-(.*)$", encoded)
    if not drive_match:
        return None

    drive_letter = drive_match.group(1)
    rest = drive_match.group(2)

    simple = f"{drive_letter}:\\" + rest.replace("-", "\\")
    if os.path.exists(simple):
        return simple

    segments = rest.split("-")
    base = f"{drive_letter}:\\"
    result = _find_valid_path_windows(base, segments)
    if result:
        return result

    return simple


def _find_valid_path_windows(base: str, remaining: list[str]) -> Optional[str]:
    if not remaining:
        return base if os.path.exists(base) else None

    if remaining[0] == "" and len(remaining) >= 2 and remaining[1]:
        for prefix in (".", "-"):
            result = _find_valid_path_windows(
                base,
                [prefix + remaining[1], *remaining[2:]],
            )
            if result:
                return result

    next_segment = remaining[0]
    with_slash = os.path.join(base, next_segment)
    if os.path.exists(with_slash):
        result = _find_valid_path_windows(with_slash, remaining[1:])
        if result:
            return result

    if len(remaining) >= 2:
        combined = remaining[0] + "-" + remaining[1]
        result = _find_valid_path_windows(base, [combined] + remaining[2:])
        if result:
            return result

    return None


def _encode_claude_project_path_variant(
    project_path: str, *, preserve_hidden_dot: bool
) -> str:
    windows_match = re.match(r"^([A-Za-z]):[\\/](.*)$", project_path)
    if windows_match:
        drive_letter = windows_match.group(1)
        rest = windows_match.group(2)
        segments = [
            _encode_claude_path_segment(
                segment,
                preserve_hidden_dot=preserve_hidden_dot,
            )
            for segment in re.split(r"[\\/]+", rest)
            if segment
        ]
        return "-".join([drive_letter, *segments]) if segments else drive_letter

    segments = [
        _encode_claude_path_segment(segment, preserve_hidden_dot=preserve_hidden_dot)
        for segment in project_path.replace("\\", "/").split("/")
        if segment
    ]
    return "-" + "-".join(segments)


def _encode_claude_path_segment(
    segment: str, *, preserve_hidden_dot: bool
) -> str:
    if not preserve_hidden_dot and segment.startswith(".") and len(segment) > 1:
        return "-" + segment[1:]
    return segment


def _normalize_project_path(path: str) -> str:
    return os.path.normcase(os.path.normpath(path))


def _discover_claude_subagent_files(main_session_path: Path) -> list[Path]:
    session_dir = main_session_path.parent
    session_stem = main_session_path.stem
    subagents_dir = session_dir / session_stem / "subagents"
    if not subagents_dir.exists() or not subagents_dir.is_dir():
        return []
    return sorted(subagents_dir.glob("agent-*.jsonl"), key=lambda p: p.stat().st_mtime)


def _parse_claude_subagent_file(
    agent_file: Path, truncate_large_content: bool = False
) -> Optional[dict[str, Any]]:
    del truncate_large_content
    try:
        agent_id = agent_file.stem[6:] if agent_file.stem.startswith("agent-") else agent_file.stem
        messages: list[dict[str, Any]] = []
        task_description = None
        session_id = None

        with open(agent_file, "r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(event, dict):
                    continue
                if "sessionId" in event and not session_id:
                    session_id = event["sessionId"]
                event_type = event.get("type")
                if event_type == "user" and not task_description:
                    content = event.get("message", {}).get("content", "")
                    if isinstance(content, str):
                        task_description = content[:200] + ("..." if len(content) > 200 else "")
                if event_type in ["user", "assistant"]:
                    content = event.get("message", {}).get("content", "")
                    if isinstance(content, list):
                        text_parts = []
                        for block in content:
                            if isinstance(block, dict):
                                if block.get("type") == "text":
                                    text_parts.append(block.get("text", ""))
                                elif block.get("type") == "tool_use":
                                    tool_name = block.get("name", "unknown_tool")
                                    tool_input = block.get("input", {})
                                    summary = _summarize_claude_tool_input(tool_name, tool_input)
                                    if summary:
                                        text_parts.append(f"[Used tool: {tool_name}] {summary}")
                                    else:
                                        text_parts.append(f"[Used tool: {tool_name}]")
                        content = "\n\n".join(p for p in text_parts if p)
                    if isinstance(content, str) and content.strip():
                        messages.append(
                            {
                                "role": event_type,
                                "content": content,
                                "timestamp": event.get("timestamp"),
                            }
                        )

        if not messages:
            return None

        return {
            "agent_id": agent_id,
            "session_id": session_id,
            "task_description": task_description,
            "message_count": len(messages),
            "file_path": str(agent_file),
            "messages": messages,
        }
    except Exception as exc:
        logger.warning("Failed to parse Claude subagent file %s: %s", agent_file, exc)
        return None


def _summarize_claude_tool_input(tool_name: str, tool_input: dict[str, Any]) -> str:
    if not tool_input:
        return ""

    name_lower = tool_name.lower()
    if name_lower in ("read", "write", "edit"):
        path = tool_input.get("file_path", "")
        return path if isinstance(path, str) else ""
    if name_lower == "bash":
        desc = tool_input.get("description", "")
        cmd = tool_input.get("command", "")
        if isinstance(desc, str) and desc:
            return desc
        if isinstance(cmd, str):
            return cmd[:120]
    if name_lower in ("grep", "glob"):
        pattern = tool_input.get("pattern", "")
        return pattern if isinstance(pattern, str) else ""
    return ""
