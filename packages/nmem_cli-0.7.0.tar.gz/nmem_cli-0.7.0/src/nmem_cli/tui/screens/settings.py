"""
Settings Screen - Configuration and preferences for server/headless deployments.

Provides license activation, LLM provider configuration, embedding model
management, knowledge processing settings, and keyboard shortcuts reference.
"""

import ipaddress
import socket
import re
import webbrowser
from typing import Any, Literal
from urllib.parse import urlparse

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.timer import Timer
from textual.widgets import Button, Input, Rule, Select, Static

from ...license_payload import decode_license_email
from ..api_client import ApiClient

try:
    import pyperclip

    HAS_CLIPBOARD = True
except ImportError:
    HAS_CLIPBOARD = False

PROVIDER_OPTIONS = [
    ("OpenAI (`openai`)", "openai"),
    ("Anthropic (`anthropic`)", "anthropic"),
    ("Gemini (`gemini`)", "gemini"),
    ("xAI (`xai`)", "xai"),
    ("DeepSeek (`deepseek`)", "deepseek"),
    ("OpenRouter (`openrouter`)", "openrouter"),
    ("Ollama (`ollama`)", "ollama"),
    ("GitHub Copilot (`github_copilot`)", "github_copilot"),
    ("ChatGPT Subscription (`openai_codex`)", "openai_codex"),
    ("MiniMax (`minimax`)", "minimax"),
    ("Z.AI (`zai`)", "zai"),
    ("Moonshot (`moonshot`)", "moonshot"),
    ("Groq (`groq`)", "groq"),
    ("Together (`together`)", "together"),
    ("Fireworks (`fireworks`)", "fireworks"),
    ("Kimi OpenAI-compatible (`kimi`)", "kimi"),
    ("Custom OpenAI-compatible (`openai_compatible`)", "openai_compatible"),
]

PROVIDER_DEFAULTS: dict[str, dict[str, str]] = {
    "openai": {"model": "gpt-4o", "api_base": "https://api.openai.com/v1"},
    "anthropic": {"model": "claude-sonnet-4-20250514", "api_base": "https://api.anthropic.com"},
    "gemini": {"model": "gemini-flash-latest", "api_base": "https://generativelanguage.googleapis.com"},
    "xai": {"model": "grok-3", "api_base": "https://api.x.ai/v1"},
    "deepseek": {"model": "deepseek-chat", "api_base": "https://api.deepseek.com/v1"},
    "openrouter": {"model": "anthropic/claude-sonnet-4", "api_base": "https://openrouter.ai/api/v1"},
    "github_copilot": {"model": "gpt-5-mini"},
    "openai_codex": {"model": "gpt-5.2-codex"},
    "minimax": {"model": "MiniMax-M2.1", "api_base": "https://api.minimax.io/anthropic"},
    "zai": {"model": "glm-4.7", "api_base": "https://api.z.ai/api/paas/v4"},
    "moonshot": {"model": "kimi-k2-thinking", "api_base": "https://api.moonshot.ai/v1"},
    "ollama": {"model": "llama3.2", "api_base": "http://127.0.0.1:11434"},
    "kimi": {"model": "kimi-k2-thinking", "api_base": "https://api.moonshot.cn/v1"},
}

ACCESS_ANYWHERE_DOCS_URL = "https://mem.nowledge.co/docs/remote-access"


def _normalize_account_tunnel_url_input(value: str) -> str:
    trimmed = value.strip().rstrip("/")
    if not trimmed:
        return ""
    if re.match(r"^https?://", trimmed, re.IGNORECASE):
        return trimmed
    if re.match(r"^[^\s]+$", trimmed):
        return f"https://{trimmed}"
    return trimmed


def _validate_account_tunnel_url(url_value: str) -> str | None:
    """Validate account tunnel URL as HTTPS domain root only."""
    parsed = urlparse(url_value)
    if parsed.scheme.lower() != "https" or not parsed.netloc:
        return "Public URL must be HTTPS (for example https://mem.example.com)."
    if parsed.path not in {"", "/"}:
        return (
            "Public URL must be domain root only "
            "(for example https://mem.example.com). Do not add /remote-api."
        )
    if parsed.query or parsed.fragment:
        return "Public URL cannot include query strings or fragments."
    return None


def _extract_cloudflare_tunnel_token(raw_input: str) -> str:
    trimmed = raw_input.strip()
    if not trimmed:
        return ""

    def _clean(candidate: str) -> str:
        return (
            candidate.strip()
            .strip("\"'")
            .rstrip(";,")
            .strip()
        )

    command_patterns = [
        re.compile(r"--\s*token\s*(?:=|\s)\s*['\"]?([A-Za-z0-9._-]+)['\"]?", re.IGNORECASE),
        re.compile(r"\bservice\s+install\s+['\"]?([A-Za-z0-9._-]+)['\"]?", re.IGNORECASE),
    ]

    for pattern in command_patterns:
        match = pattern.search(trimmed)
        if match and match.group(1):
            return _clean(match.group(1))

    jwt_like = re.search(r"\beyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b", trimmed)
    if jwt_like and jwt_like.group(0):
        return _clean(jwt_like.group(0))

    return _clean(trimmed)


# =============================================================================
# Modal: License Activation
# =============================================================================


class LicenseActivateModal(ModalScreen):
    """Modal for entering license key and email."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    LicenseActivateModal { align: center middle; }
    LicenseActivateModal > Vertical {
        width: 70%;
        max-width: 80;
        height: auto;
        max-height: 20;
        background: $surface;
        border: round $primary;
        padding: 1 2;
    }
    LicenseActivateModal .modal-title {
        text-style: bold;
        color: $primary;
        text-align: center;
        margin-bottom: 1;
    }
    LicenseActivateModal .field-label {
        color: $secondary;
        margin-top: 1;
    }
    LicenseActivateModal Input {
        margin-bottom: 1;
        border: round $boost;
    }
    LicenseActivateModal Input:focus { border: round $primary; }
    LicenseActivateModal .hint { color: $text-muted; text-align: center; }
    LicenseActivateModal .error-text { color: $error; text-align: center; }
    """

    def __init__(self, api_client: ApiClient) -> None:
        super().__init__()
        self.api_client = api_client

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("ACTIVATE LICENSE", classes="modal-title")
            yield Static("License Key (base64):", classes="field-label")
            yield Input(placeholder="Paste your license key...", id="lic-key-input")
            yield Static("Email (optional):", classes="field-label")
            yield Input(
                placeholder="Inferred from the license key when left blank",
                id="lic-email-input",
            )
            yield Static("", id="lic-error", classes="error-text")
            yield Static(
                "Press Enter on email field to activate  |  Esc to cancel",
                classes="hint",
            )

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "lic-email-input":
            key_input = self.query_one("#lic-key-input", Input)
            email_input = self.query_one("#lic-email-input", Input)
            key = key_input.value.strip()
            email = email_input.value.strip()
            if not key:
                self.query_one("#lic-error", Static).update(
                    "Paste the license key first."
                )
                return
            if not email:
                try:
                    email = decode_license_email(key)
                    email_input.value = email
                except ValueError as exc:
                    self.query_one("#lic-error", Static).update(str(exc))
                    return
            self.query_one("#lic-error", Static).update("")
            result = await self.api_client.activate_license(key, email)
            self.dismiss(result)

    def action_cancel(self) -> None:
        self.dismiss(None)


# =============================================================================
# Modal: Provider Configuration
# =============================================================================


class ProviderConfigModal(ModalScreen):
    """Modal for configuring an LLM provider."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    ProviderConfigModal { align: center middle; }
    ProviderConfigModal > Vertical {
        width: 70%;
        max-width: 80;
        height: auto;
        max-height: 26;
        background: $surface;
        border: round $primary;
        padding: 1 2;
    }
    ProviderConfigModal .modal-title {
        text-style: bold;
        color: $primary;
        text-align: center;
        margin-bottom: 1;
    }
    ProviderConfigModal .field-label {
        color: $secondary;
        margin-top: 1;
    }
    ProviderConfigModal Input {
        margin-bottom: 1;
        border: round $boost;
    }
    ProviderConfigModal Select {
        margin-bottom: 1;
    }
    ProviderConfigModal Input:focus { border: round $primary; }
    ProviderConfigModal .hint { color: $text-muted; text-align: center; }
    """

    def __init__(self, api_client: ApiClient, config_data: dict[str, Any] | None = None) -> None:
        super().__init__()
        self.api_client = api_client
        data = config_data or {}
        providers = data.get("providers", {}) if isinstance(data, dict) else {}
        active_provider = (
            str(data.get("active_provider", "")).strip()
            if isinstance(data, dict)
            else ""
        )

        configured_options: list[tuple[str, str]] = []
        self._provider_configs: dict[str, dict[str, Any]] = {}
        if isinstance(providers, dict):
            for pid, p in providers.items():
                if not isinstance(pid, str):
                    continue
                if not isinstance(p, dict):
                    p = {}
                self._provider_configs[pid] = p
                display_name = str(p.get("display_name") or pid)
                provider_type = str(p.get("provider_type") or pid)
                model_name = str(p.get("model") or "").strip()
                # Keep labels markup-safe for Textual Select overlay rendering.
                label = f"{display_name} (configured, type={provider_type})"
                if model_name:
                    label += f" ({model_name})"
                configured_options.append((label, pid))

        configured_ids = {value for _, value in configured_options}
        self._provider_options = list(configured_options)
        for label, value in PROVIDER_OPTIONS:
            if value not in configured_ids:
                self._provider_options.append((label, value))

        self._initial_provider = (
            active_provider if active_provider in self._provider_configs else "openai"
        )

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("CONFIGURE LLM PROVIDER", classes="modal-title")
            yield Static("Provider:", classes="field-label")
            yield Select(self._provider_options, value=self._initial_provider, id="prov-name-select")
            yield Static("API Key:", classes="field-label")
            yield Input(placeholder="sk-...", password=True, id="prov-key-input")
            yield Static("Model:", classes="field-label")
            yield Input(placeholder="e.g. claude-sonnet-4-20250514", id="prov-model-input")
            yield Static("Base URL (optional):", classes="field-label")
            yield Input(placeholder="Leave empty for default", id="prov-base-input")
            yield Static("API Format (optional):", classes="field-label", id="prov-format-label")
            yield Select(
                [("Chat Completions (default)", "chat_completions"), ("Responses API", "responses")],
                value="chat_completions",
                id="prov-format-select",
            )
            yield Static("Context Window (optional):", classes="field-label")
            yield Input(placeholder="e.g., 128000 (auto-detected if empty)", id="prov-context-input")
            yield Button("Save Provider Config", id="btn-save-provider-config", variant="primary")
            yield Static("Press Enter on Base URL or click Save  |  Esc to cancel", classes="hint")

    def on_mount(self) -> None:
        self._apply_provider_defaults(self._initial_provider)
        self._toggle_format_visibility(self._initial_provider)

    def on_select_changed(self, event: Select.Changed) -> None:
        if event.select.id == "prov-name-select" and isinstance(event.value, str):
            self._apply_provider_defaults(event.value)
            self._toggle_format_visibility(event.value)

    def _is_openai_compatible(self, provider: str) -> bool:
        """Check if provider is openai_compatible (exact or instance like openai_compatible:foo)."""
        return provider == "openai_compatible" or provider.startswith("openai_compatible:")

    def _toggle_format_visibility(self, provider: str) -> None:
        """Show API Format selector only for openai_compatible providers."""
        is_compat = self._is_openai_compatible(provider)
        format_label = self.query_one("#prov-format-label", Static)
        format_select = self.query_one("#prov-format-select", Select)
        format_label.display = is_compat
        format_select.display = is_compat

    def _apply_provider_defaults(self, provider: str) -> None:
        model_input = self.query_one("#prov-model-input", Input)
        base_input = self.query_one("#prov-base-input", Input)
        format_select = self.query_one("#prov-format-select", Select)
        context_input = self.query_one("#prov-context-input", Input)
        if provider not in self._provider_configs:
            defaults = PROVIDER_DEFAULTS.get(provider, {})
            model_input.value = defaults.get("model", "")
            base_input.value = defaults.get("api_base", "")
            format_select.value = "chat_completions"
            context_input.value = ""
            return
        existing = self._provider_configs.get(provider, {})
        model_input.value = str(existing.get("model") or "")
        base_input.value = str(existing.get("api_base") or "")
        format_select.value = str(existing.get("api_format") or "chat_completions")
        context_input.value = str(existing.get("context_window") or "")

    async def _save_config(self) -> None:
        provider_value = self.query_one("#prov-name-select", Select).value
        provider = provider_value.strip() if isinstance(provider_value, str) else ""
        api_key = self.query_one("#prov-key-input", Input).value.strip()
        model = self.query_one("#prov-model-input", Input).value.strip()
        api_base = self.query_one("#prov-base-input", Input).value.strip()
        format_value = self.query_one("#prov-format-select", Select).value
        api_format = format_value.strip() if isinstance(format_value, str) else ""
        if not provider:
            return
        # For already-configured providers, preserve the existing provider_type
        # (important for custom instances where id ≠ type, e.g. "my-gpt" with
        # type "openai_compatible"). For new built-in providers, id == type.
        existing_type = (
            self._provider_configs.get(provider, {}).get("provider_type", "")
            if provider in self._provider_configs
            else ""
        )
        config: dict[str, Any] = {
            "enabled": True,
            "provider": provider,
            "provider_type": existing_type or provider,
            "model": model or "",
            "temperature": 0.7,
            "max_tokens": 8192,
            "timeout": 60.0,
        }
        if api_key:
            config["api_key"] = api_key
        if api_base:
            config["api_base"] = api_base
        if api_format and self._is_openai_compatible(provider):
            config["api_format"] = api_format
        context_window_str = self.query_one("#prov-context-input", Input).value.strip()
        if context_window_str:
            try:
                config["context_window"] = int(context_window_str)
            except ValueError:
                pass
        result = await self.api_client.update_remote_llm_config(config)
        self.dismiss(result)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "prov-base-input":
            await self._save_config()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-save-provider-config":
            await self._save_config()

    def action_cancel(self) -> None:
        self.dismiss(None)


class CloneProviderModal(ModalScreen):
    """Modal for cloning an existing provider to a new custom id."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = ProviderConfigModal.DEFAULT_CSS

    def __init__(self, api_client: ApiClient, config_data: dict[str, Any]) -> None:
        super().__init__()
        self.api_client = api_client
        providers = config_data.get("providers", {}) if isinstance(config_data, dict) else {}

        self._provider_configs: dict[str, dict[str, Any]] = {}
        options: list[tuple[str, str]] = []
        if isinstance(providers, dict):
            for pid, provider in providers.items():
                if not isinstance(pid, str):
                    continue
                if not isinstance(provider, dict):
                    provider = {}
                self._provider_configs[pid] = provider
                display_name = str(provider.get("display_name") or pid)
                provider_type = str(provider.get("provider_type") or pid)
                model_name = str(provider.get("model") or "").strip()
                label = f"{display_name} (type={provider_type})"
                if model_name:
                    label += f" ({model_name})"
                options.append((label, pid))

        self._provider_options = options
        self._initial_source_provider = options[0][1] if options else ""

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("CLONE PROVIDER", classes="modal-title")
            yield Static("Source Provider:", classes="field-label")
            yield Select(
                self._provider_options,
                value=self._initial_source_provider,
                id="clone-source-provider",
            )
            yield Static("New Provider ID:", classes="field-label")
            yield Input(
                placeholder="e.g. openai:reasoning",
                id="clone-provider-id",
            )
            yield Static("Display Name (optional):", classes="field-label")
            yield Input(
                placeholder="Shown in configured provider lists",
                id="clone-display-name",
            )
            yield Static("Model Override (optional):", classes="field-label")
            yield Input(
                placeholder="Leave empty to keep the source model",
                id="clone-model-input",
            )
            yield Button(
                "Clone Provider",
                id="btn-clone-provider-save",
                variant="primary",
            )
            yield Static(
                "Press Enter on model field or click Clone  |  Esc to cancel",
                classes="hint",
            )

    async def _save_clone(self) -> None:
        source_value = self.query_one("#clone-source-provider", Select).value
        source_provider = source_value.strip() if isinstance(source_value, str) else ""
        new_provider = self.query_one("#clone-provider-id", Input).value.strip()
        display_name = self.query_one("#clone-display-name", Input).value.strip()
        model = self.query_one("#clone-model-input", Input).value.strip()

        if not source_provider or not new_provider:
            self.dismiss({"error": "Source provider and new provider id are required."})
            return

        result = await self.api_client.clone_remote_llm_provider(
            source_provider,
            new_provider,
            model=model or None,
            display_name=display_name or None,
        )
        self.dismiss(result)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "clone-model-input":
            await self._save_clone()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-clone-provider-save":
            await self._save_clone()

    def action_cancel(self) -> None:
        self.dismiss(None)


class PurposeConfigModal(ModalScreen):
    """Modal for selecting purpose-specific provider/model."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = ProviderConfigModal.DEFAULT_CSS

    def __init__(
        self,
        api_client: ApiClient,
        config_data: dict[str, Any],
        purpose: Literal["default", "ai_now", "embedding"],
    ) -> None:
        super().__init__()
        self.api_client = api_client
        self.purpose = purpose
        self._provider_configs: dict[str, dict[str, Any]] = {}
        providers = (
            config_data.get("providers", {}) if isinstance(config_data, dict) else {}
        )
        purposes = (
            config_data.get("purposes", {}) if isinstance(config_data, dict) else {}
        )

        options: list[tuple[str, str]] = []
        if purpose == "ai_now":
            options.append(("Inherit default provider/model", "__inherit__"))
        elif purpose == "embedding":
            options.append(("Use local embedding model", "__local__"))

        if isinstance(providers, dict):
            for pid, p in providers.items():
                if not isinstance(pid, str):
                    continue
                if not isinstance(p, dict):
                    p = {}
                self._provider_configs[pid] = p
                display_name = str(p.get("display_name") or pid)
                provider_type = str(p.get("provider_type") or pid)
                model_name = str(p.get("model") or "").strip()
                label = f"{display_name} (type={provider_type})"
                if model_name:
                    label += f" ({model_name})"
                options.append((label, pid))
        self._provider_options = options

        selected_provider: str = (
            str(config_data.get("active_provider") or "").strip()
            if isinstance(config_data, dict)
            else ""
        )
        selected_model = ""
        if isinstance(purposes, dict):
            this_purpose = purposes.get(purpose, {})
            if isinstance(this_purpose, dict):
                selected_provider = (
                    str(this_purpose.get("provider") or "").strip() or selected_provider
                )
                selected_model = str(this_purpose.get("model") or "").strip()

        if purpose == "ai_now" and not selected_provider:
            selected_provider = "__inherit__"
        elif purpose == "embedding" and not selected_provider:
            selected_provider = "__local__"

        # Check if embedding purpose uses local (no provider set)
        if purpose == "embedding" and isinstance(purposes, dict):
            emb_purpose = purposes.get("embedding", {})
            if isinstance(emb_purpose, dict) and emb_purpose.get("uses_local", True):
                selected_provider = "__local__"

        valid_values = {v for _, v in self._provider_options}
        self._initial_provider = (
            selected_provider
            if selected_provider in valid_values
            else (
                "__inherit__" if purpose == "ai_now"
                else "__local__" if purpose == "embedding"
                else (next(iter(valid_values)) if valid_values else "openai")
            )
        )
        self._initial_model = selected_model

    def compose(self) -> ComposeResult:
        with Vertical():
            if self.purpose == "embedding":
                title = "SET EMBEDDING PURPOSE"
            elif self.purpose == "ai_now":
                title = "SET AGENTS PURPOSE"
            else:
                title = "SET DEFAULT PURPOSE"
            yield Static(title, classes="modal-title")
            yield Static("Provider:", classes="field-label")
            yield Select(self._provider_options, value=self._initial_provider, id="purpose-provider-select")
            model_label = "Embedding model:" if self.purpose == "embedding" else "Model override (optional):"
            model_placeholder = (
                "e.g. text-embedding-3-small"
                if self.purpose == "embedding"
                else "Leave empty to use selected provider default model"
            )
            yield Static(model_label, classes="field-label")
            yield Input(
                placeholder=model_placeholder,
                id="purpose-model-input",
            )
            if self.purpose == "embedding":
                yield Static("", id="embedding-test-status", classes="setting-muted")
            yield Button("Save Purpose Selection", id="btn-save-purpose-selection", variant="primary")
            yield Static("Press Enter on model field or click Save  |  Esc to cancel", classes="hint")

    def on_mount(self) -> None:
        model_input = self.query_one("#purpose-model-input", Input)
        model_input.value = self._initial_model

    async def _save_purpose(self) -> None:
        provider_value = self.query_one("#purpose-provider-select", Select).value
        provider = provider_value.strip() if isinstance(provider_value, str) else ""
        model = self.query_one("#purpose-model-input", Input).value.strip()

        if self.purpose == "ai_now" and provider == "__inherit__":
            result = await self.api_client.set_remote_llm_purpose("ai_now")
            self.dismiss(result)
            return

        if self.purpose == "embedding" and provider == "__local__":
            # Revert to local embedding
            result = await self.api_client.set_remote_llm_purpose("embedding")
            self.dismiss(result)
            return

        if self.purpose == "embedding":
            # Test embedding model to detect dimension
            if not model:
                try:
                    status = self.query_one("#embedding-test-status", Static)
                    status.update("[red]Model name is required for remote embedding[/red]")
                except Exception:
                    pass
                return
            try:
                status = self.query_one("#embedding-test-status", Static)
                status.update("Testing embedding model...")
            except Exception:
                pass
            test_result = await self.api_client.test_remote_embedding(provider, model)
            if test_result.get("success"):
                dimension = test_result.get("dimension")
                try:
                    status = self.query_one("#embedding-test-status", Static)
                    status.update(f"[green]✓ OK — dimension: {dimension}[/green]")
                except Exception:
                    pass
                result = await self.api_client.set_remote_llm_purpose(
                    "embedding", provider, model, dimension=dimension
                )
                self.dismiss(result)
            else:
                err = test_result.get("error") or test_result.get("message", "Test failed")
                try:
                    status = self.query_one("#embedding-test-status", Static)
                    status.update(f"[red]✗ {err}[/red]")
                except Exception:
                    pass
            return

        payload_provider = provider or None
        payload_model = model if model else None

        # Default purpose requires a provider
        if self.purpose == "default" and not payload_provider:
            self.dismiss({"error": "Default purpose requires a provider."})
            return

        result = await self.api_client.set_remote_llm_purpose(
            self.purpose, payload_provider, payload_model
        )
        self.dismiss(result)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "purpose-model-input":
            await self._save_purpose()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-save-purpose-selection":
            await self._save_purpose()

    def action_cancel(self) -> None:
        self.dismiss(None)


class DeleteProviderModal(ModalScreen):
    """Modal for deleting a configured provider."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = ProviderConfigModal.DEFAULT_CSS

    def __init__(self, api_client: ApiClient, config_data: dict[str, Any]) -> None:
        super().__init__()
        self.api_client = api_client
        providers = (
            config_data.get("providers", {}) if isinstance(config_data, dict) else {}
        )

        options: list[tuple[str, str]] = []
        if isinstance(providers, dict):
            for pid, p in providers.items():
                if not isinstance(pid, str):
                    continue
                if not isinstance(p, dict):
                    p = {}
                display_name = str(p.get("display_name") or pid)
                provider_type = str(p.get("provider_type") or pid)
                model_name = str(p.get("model") or "").strip()
                label = f"{display_name} (type={provider_type})"
                if model_name:
                    label += f" ({model_name})"
                options.append((label, pid))
        self._provider_options = options
        self._initial_provider = options[0][1] if options else ""

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("DELETE PROVIDER", classes="modal-title")
            yield Static("Provider:", classes="field-label")
            yield Select(
                self._provider_options,
                value=self._initial_provider,
                id="delete-provider-select",
            )
            yield Static(
                "This removes saved config and API key for this provider.",
                classes="hint",
            )
            yield Button(
                "Delete Provider",
                id="btn-confirm-delete-provider",
                variant="error",
            )
            yield Static("Esc to cancel", classes="hint")

    async def _remove_provider(self) -> None:
        provider_value = self.query_one("#delete-provider-select", Select).value
        provider = provider_value.strip() if isinstance(provider_value, str) else ""
        if not provider:
            self.dismiss({"error": "Provider selection is required."})
            return
        result = await self.api_client.remove_remote_llm_provider(provider)
        self.dismiss(result)

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-confirm-delete-provider":
            await self._remove_provider()

    def action_cancel(self) -> None:
        self.dismiss(None)


class AccessAnywhereAccountModal(ModalScreen):
    """Modal for configuring Access Anywhere stable-link settings."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = ProviderConfigModal.DEFAULT_CSS

    def __init__(
        self,
        api_client: ApiClient,
        *,
        current_url: str = "",
        token_already_configured: bool = False,
    ) -> None:
        super().__init__()
        self.api_client = api_client
        self.current_url = current_url
        self.token_already_configured = token_already_configured

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("CONFIGURE STABLE LINK", classes="modal-title")
            yield Static("Public URL (domain root):", classes="field-label")
            yield Input(
                placeholder="https://mem.example.com",
                id="aa-account-url-input",
                value=self.current_url,
            )
            yield Static("Tunnel Token (or Cloudflare command):", classes="field-label")
            token_placeholder = (
                "Paste token or full command (cloudflared ...). Leave empty to keep saved token."
                if self.token_already_configured
                else "Paste token or full command (cloudflared ...)."
            )
            yield Input(
                placeholder=token_placeholder,
                password=True,
                id="aa-account-token-input",
            )
            yield Button(
                "Save Stable Link Setup",
                id="btn-save-aa-account",
                variant="primary",
            )
            yield Static("Press Enter on token field or click Save  |  Esc to cancel", classes="hint")

    async def _save(self) -> None:
        raw_url = self.query_one("#aa-account-url-input", Input).value
        raw_token = self.query_one("#aa-account-token-input", Input).value

        normalized_url = _normalize_account_tunnel_url_input(raw_url)
        if not normalized_url:
            self.dismiss({"error": "Public URL is required."})
            return
        url_error = _validate_account_tunnel_url(normalized_url)
        if url_error:
            self.dismiss({"error": url_error})
            return

        token_value = _extract_cloudflare_tunnel_token(raw_token)
        payload: dict[str, Any] = {
            "mode": "account",
            "account_tunnel_url": normalized_url,
        }
        if token_value:
            payload["account_tunnel_token"] = token_value
        elif not self.token_already_configured:
            self.dismiss({"error": "Tunnel token is required."})
            return

        result = await self.api_client.configure_remote_access(**payload)
        if "error" not in result and token_value and token_value != raw_token.strip():
            result["token_extracted"] = True
        self.dismiss(result)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "aa-account-token-input":
            await self._save()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-save-aa-account":
            await self._save()

    def action_cancel(self) -> None:
        self.dismiss(None)


class AccessAnywhereAllowlistModal(ModalScreen):
    """Modal for editing LAN IP allowlist entries."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = ProviderConfigModal.DEFAULT_CSS

    def __init__(self, *, current_allowlist: str = "") -> None:
        super().__init__()
        self.current_allowlist = current_allowlist

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("SET IP ALLOWLIST", classes="modal-title")
            yield Static("Allowed IPs / CIDR ranges:", classes="field-label")
            yield Input(
                placeholder="192.168.1.100, 10.0.0.0/24",
                id="aa-allowlist-input",
                value=self.current_allowlist,
            )
            yield Button(
                "Save IP Allowlist",
                id="btn-save-aa-allowlist",
                variant="primary",
            )
            yield Static(
                "Comma-separated IPs or CIDR ranges. Leave empty to allow all devices.",
                classes="hint",
            )

    async def _save(self) -> None:
        raw_value = self.query_one("#aa-allowlist-input", Input).value
        entries = [
            part.strip()
            for part in re.split(r"[,\n]", raw_value)
            if part.strip()
        ]
        self.dismiss({"ipAllowlist": entries})

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "aa-allowlist-input":
            await self._save()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-save-aa-allowlist":
            await self._save()

    def action_cancel(self) -> None:
        self.dismiss(None)


# =============================================================================
# Main Settings Screen
# =============================================================================


class SettingsScreen(VerticalScroll):
    """Screen for managing settings and configuration."""

    DEFAULT_CSS = """
    SettingsScreen {
        padding: 1 2;
    }

    SettingsScreen > .section-title {
        text-style: bold;
        color: $primary;
        margin-top: 1;
        padding: 0 1;
    }

    SettingsScreen > .setting {
        padding: 0 2;
        color: $text;
    }

    SettingsScreen > .setting-muted {
        padding: 0 2;
        color: $text-muted;
    }

    SettingsScreen > .key-group {
        margin-top: 1;
        padding: 0 2;
        color: $secondary;
    }

    SettingsScreen > .about-text {
        padding: 0 2;
        color: $primary;
    }

    SettingsScreen Rule {
        margin: 1 0;
        color: $boost;
    }

    SettingsScreen > .status-row {
        padding: 0 2;
        height: auto;
    }

    SettingsScreen > .status-row > Static {
        width: auto;
    }

    SettingsScreen > .status-row > Button {
        min-width: 12;
        margin-left: 2;
    }

    SettingsScreen > .action-button {
        margin: 0 2;
        min-width: 16;
    }

    SettingsScreen > .success-text {
        padding: 0 2;
        color: $success;
    }

    SettingsScreen > .warning-text {
        padding: 0 2;
        color: $warning;
    }

    SettingsScreen > .error-text {
        padding: 0 2;
        color: $error;
    }
    """

    def __init__(self, api_client: ApiClient, **kwargs) -> None:
        super().__init__(**kwargs)
        self.api_client = api_client
        self._remote_access_status: dict[str, Any] = {}
        self._remote_access_key_cache: str | None = None
        self._cli_access_settings: dict[str, Any] = {}
        self._remote_status_poll_timer: Timer | None = None
        self._remote_status_poll_inflight = False

    def compose(self) -> ComposeResult:
        yield Static("◈ SETTINGS", classes="section-title")
        yield Rule()

        # --- Connection ---
        yield Static("◇ CONNECTION", classes="section-title")
        mode = "Remote" if self.api_client.is_remote else "Local"
        yield Static(f"Mode: {mode}", classes="setting")
        yield Static(f"API URL: {self.api_client.base_url}", classes="setting")
        yield Static("Status: ◌ checking...", id="server-status", classes="setting")

        yield Rule()

        # --- Access Anywhere ---
        yield Static("◇ ACCESS ANYWHERE", classes="section-title")
        yield Static(
            "Securely connect your Mem API from other devices.",
            classes="setting-muted",
        )
        yield Static("Status: ◌ checking...", id="remote-access-status", classes="setting")
        yield Static("Mode: ◌ checking...", id="remote-access-mode", classes="setting")
        yield Static("Public URL: —", id="remote-access-url", classes="setting")
        yield Static("API Key: hidden", id="remote-access-key", classes="setting")
        yield Static("LAN access: ◌ checking...", id="remote-access-lan", classes="setting")
        yield Static("IP allowlist: ◌ checking...", id="remote-access-allowlist", classes="setting-muted")
        yield Static("Localhost auth: off", id="remote-access-loopback-auth", classes="setting-muted")
        yield Static("Cloudflare: ◌ checking...", id="remote-access-cloudflared", classes="setting-muted")
        yield Static("", id="remote-access-limitations", classes="setting-muted")
        yield Button("Enable LAN Access", id="btn-remote-lan-toggle", variant="default", classes="action-button")
        yield Button("Set IP Allowlist", id="btn-remote-allowlist", variant="default", classes="action-button")
        yield Button("Start Quick Link", id="btn-remote-start-quick", variant="primary", classes="action-button")
        yield Button("Configure Stable Link", id="btn-remote-config-account", variant="default", classes="action-button")
        yield Button("Start Stable Link", id="btn-remote-start-account", variant="default", classes="action-button")
        yield Button("Stop Access Anywhere", id="btn-remote-stop", variant="error", classes="action-button", disabled=True)
        yield Button("Rotate API Key", id="btn-remote-rotate", variant="default", classes="action-button")
        yield Button("Reveal API Key", id="btn-remote-reveal", variant="default", classes="action-button")
        yield Button("Copy API Key", id="btn-remote-copy-key", variant="default", classes="action-button")
        yield Button("Show Terminal Setup", id="btn-remote-terminal", variant="default", classes="action-button")
        yield Button("Copy Terminal Setup", id="btn-remote-copy-terminal", variant="default", classes="action-button")
        yield Button("Copy LAN Setup", id="btn-remote-copy-lan", variant="default", classes="action-button")
        yield Button("Show QR Code", id="btn-remote-qr", variant="default", classes="action-button")
        yield Button("Toggle Localhost Auth", id="btn-remote-loopback-auth", variant="default", classes="action-button")
        yield Button("Guide", id="btn-remote-guide", variant="default", classes="action-button")
        yield Static("", id="remote-access-terminal", classes="setting-muted")
        yield Static("", id="remote-access-action-status", classes="setting-muted")

        yield Rule()

        # --- License ---
        yield Static("◇ LICENSE", classes="section-title")
        yield Static("Tier: ◌ checking...", id="license-tier", classes="setting")
        yield Static("", id="license-email", classes="setting")
        yield Static("", id="license-access", classes="setting")
        yield Static("", id="license-activation", classes="setting")
        yield Static("", id="license-device-id", classes="setting-muted")
        yield Button("Activate License", id="btn-activate-license", variant="primary", classes="action-button")
        yield Button("Refresh License", id="btn-renew-license", variant="default", classes="action-button", disabled=True)
        yield Button("Deactivate", id="btn-deactivate-license", variant="error", classes="action-button", disabled=True)
        yield Static("", id="license-action-status", classes="setting-muted")

        yield Rule()

        # --- LLM Providers ---
        yield Static("◇ LLM PROVIDERS", classes="section-title")
        yield Static(
            "Configure remote LLM providers for AI features (Knowledge Agent, insights, etc.).",
            classes="setting-muted",
        )
        yield Static("Provider: ◌ checking...", id="llm-provider-status", classes="setting")
        yield Static("", id="llm-model-status", classes="setting")
        yield Static("", id="llm-purpose-status", classes="setting-muted")
        yield Static("", id="llm-providers-list", classes="setting-muted")
        yield Button("Configure Provider", id="btn-config-provider", variant="primary", classes="action-button")
        yield Button("Clone Provider", id="btn-clone-provider", variant="default", classes="action-button", disabled=True)
        yield Button("Delete Provider", id="btn-delete-provider", variant="error", classes="action-button", disabled=True)
        yield Button("Set Default Provider", id="btn-set-default-provider", variant="default", classes="action-button", disabled=True)
        yield Button("Set Agents Purpose", id="btn-set-agents-purpose", variant="default", classes="action-button", disabled=True)
        yield Button("Set Embedding Purpose", id="btn-set-embedding-purpose", variant="default", classes="action-button", disabled=True)
        yield Button("Test Connection", id="btn-test-llm", variant="default", classes="action-button", disabled=True)
        yield Static("", id="llm-action-status", classes="setting-muted")

        yield Rule()

        # --- Search Index ---
        yield Static("◇ SEARCH INDEX", classes="section-title")
        yield Static(
            "Hybrid search uses semantic embeddings for better results.",
            classes="setting-muted",
        )
        yield Static("Embedding Model: ◌ checking...", id="bge-m3-status", classes="setting")
        yield Static("Local LLM: ◌ checking...", id="local-llm-status", classes="setting")
        yield Static("Search Index: ◌ checking...", id="search-index-status", classes="setting")
        yield Button("Verify Models", id="btn-verify-models", variant="default", classes="action-button")
        yield Button("Download Model", id="btn-install-bge-m3", variant="primary", classes="action-button", disabled=True)
        yield Button("Rebuild Index", id="btn-reindex", variant="default", classes="action-button", disabled=True)
        yield Static("", id="search-action-status", classes="setting-muted")

        yield Rule()

        # --- Knowledge Processing ---
        yield Static("◇ KNOWLEDGE PROCESSING", classes="section-title")
        yield Static(
            "Background intelligence features (require LLM provider).",
            classes="setting-muted",
        )
        yield Static("◌ loading...", id="kp-settings-display", classes="setting")
        yield Button("Toggle Background Intelligence", id="btn-toggle-bg-intel", variant="default", classes="action-button")
        yield Button("Toggle Daily Briefing", id="btn-toggle-briefing", variant="default", classes="action-button")
        yield Button("Toggle KG Extraction", id="btn-toggle-kg-extract", variant="default", classes="action-button")
        yield Button("Toggle Community Detection", id="btn-toggle-community", variant="default", classes="action-button")
        yield Button("Toggle Crystallization", id="btn-toggle-crystal", variant="default", classes="action-button")
        yield Button("Toggle Insight Detection", id="btn-toggle-insight", variant="default", classes="action-button")
        yield Button("Toggle Decay Refresh", id="btn-toggle-decay-refresh", variant="default", classes="action-button")
        yield Button("Toggle Memory Compaction", id="btn-toggle-compaction", variant="default", classes="action-button")
        yield Button("Toggle Auto-Archive", id="btn-toggle-auto-archive", variant="default", classes="action-button")
        yield Static("", id="kp-action-status", classes="setting-muted")

        yield Rule()

        # --- Token Budget ---
        yield Static("◇ TOKEN BUDGET", classes="section-title")
        yield Static(
            "Limit token usage for background intelligence tasks.",
            classes="setting-muted",
        )
        yield Static("◌ loading...", id="budget-display", classes="setting")
        yield Static("", id="budget-action-status", classes="setting-muted")

        yield Rule()

        # --- Keyboard Shortcuts ---
        yield Static("◇ KEYBOARD SHORTCUTS", classes="section-title")

        yield Static("◇ Navigation", classes="key-group")
        yield Static("  1-5       Switch between tabs", classes="setting-muted")
        yield Static("  /         Focus search input", classes="setting-muted")
        yield Static("  ?         Show help overlay", classes="setting-muted")
        yield Static("  q         Quit application", classes="setting-muted")

        yield Static("◇ Lists", classes="key-group")
        yield Static("  j / Down  Move down in list", classes="setting-muted")
        yield Static("  k / Up    Move up in list", classes="setting-muted")
        yield Static("  Enter     Select / Open item", classes="setting-muted")
        yield Static("  Esc       Go back / Close", classes="setting-muted")

        yield Static("◇ Memories", classes="key-group")
        yield Static("  a         Add new memory", classes="setting-muted")
        yield Static("  e         Edit selected memory", classes="setting-muted")
        yield Static("  c         Copy memory content", classes="setting-muted")
        yield Static("  d         Delete selected memory", classes="setting-muted")
        yield Static("  r         Refresh list", classes="setting-muted")

        yield Static("◇ Detail Views", classes="key-group")
        yield Static("  c         Copy content to clipboard", classes="setting-muted")
        yield Static("  y         Copy ID to clipboard", classes="setting-muted")

        yield Static("◇ Threads", classes="key-group")
        yield Static("  d         Distill to memories", classes="setting-muted")
        yield Static("  x         Delete thread", classes="setting-muted")
        yield Static("  r         Refresh list", classes="setting-muted")

        yield Static("◇ Graph", classes="key-group")
        yield Static("  e         Expand all nodes", classes="setting-muted")
        yield Static("  c         Collapse all nodes", classes="setting-muted")
        yield Static("  r         Refresh graph", classes="setting-muted")

        yield Rule()
        yield Static("◇ ABOUT", classes="section-title")
        yield Static("◈ Nowledge Mem", classes="about-text")
        yield Static("  AI that remembers your world", classes="setting-muted")
        yield Static(
            "  TUI built with Textual (textual.textualize.io)", classes="setting-muted"
        )
        yield Static("  Your data stays only on your device.", classes="setting-muted")

    def on_mount(self) -> None:
        self.run_worker(self._check_status(), exclusive=True, thread=False)
        self.run_worker(self._check_remote_access_status(), exclusive=False, thread=False)
        self.run_worker(self._load_cli_access_settings(), exclusive=False, thread=False)
        self.run_worker(self._check_search_index_status(), exclusive=False, thread=False)
        self.run_worker(self._check_license_status(), exclusive=False, thread=False)
        self.run_worker(self._check_llm_status(), exclusive=False, thread=False)
        self.run_worker(self._check_kp_settings(), exclusive=False, thread=False)
        self.run_worker(self._check_budget_status(), exclusive=False, thread=False)
        # Keep Access Anywhere status fresh so auto-restored tunnels surface URL changes
        # without requiring a manual action after app restart.
        self._remote_status_poll_timer = self.set_interval(
            5.0,
            self._queue_remote_access_status_refresh,
        )

    def on_unmount(self) -> None:
        if self._remote_status_poll_timer is not None:
            self._remote_status_poll_timer.stop()
            self._remote_status_poll_timer = None

    # =========================================================================
    # Status checks
    # =========================================================================

    async def _check_status(self) -> None:
        try:
            health = await self.api_client.get_health()
            status = health.get("status", "unknown")
            version = health.get("version", "unknown")

            status_widget = self.query_one("#server-status", Static)
            if status == "ok":
                status_widget.update(f"Status: ● Online (v{version})")
            else:
                status_widget.update(f"Status: ○ {status}")
        except Exception as e:
            self.query_one("#server-status", Static).update(f"Status: ✗ Error - {e}")

    def _is_local_management_url(self) -> bool:
        """Whether the current API URL can call local-only management endpoints."""
        try:
            parsed = urlparse(self.api_client.base_url)
            host = (parsed.hostname or "").strip()
            if not host:
                return False
            if host in {"localhost", "127.0.0.1", "::1"}:
                return True
            try:
                return ipaddress.ip_address(host).is_loopback
            except ValueError:
                resolved = {
                    info[4][0]
                    for info in socket.getaddrinfo(host, parsed.port or 14242, proto=socket.IPPROTO_TCP)
                }
                return bool(
                    resolved
                    and all(ipaddress.ip_address(addr).is_loopback for addr in resolved)
                )
        except Exception:
            return False

    @staticmethod
    def _mask_api_key(value: str, keep_start: int = 10, keep_end: int = 6) -> str:
        if len(value) <= keep_start + keep_end + 3:
            return "•" * max(len(value), 8)
        return f"{value[:keep_start]}...{value[-keep_end:]}"

    def _local_loopback_port(self) -> int:
        """Port the local operator should use for browser/CLI login on this machine."""
        parsed = urlparse(self.api_client.base_url)
        if self._is_local_management_url():
            return parsed.port or 14242
        return 14242

    def _local_web_app_url(self) -> str:
        return f"http://127.0.0.1:{self._local_loopback_port()}/app"

    def _render_remote_terminal_setup(self) -> None:
        terminal_widget = self.query_one("#remote-access-terminal", Static)
        sections: list[str] = []

        local_lines = [
            "Local web app:",
            f"  open {self._local_web_app_url()}",
        ]
        if self._remote_access_key_cache:
            local_lines.append(f"  API key: {self._remote_access_key_cache}")
        else:
            local_lines.append("  Reveal or Rotate key first to show the API key.")
        sections.append("\n".join(local_lines))

        url = (self._remote_access_status.get("tunnel_url") or "").strip()
        if url:
            if not self._remote_access_key_cache:
                sections.append(
                    "Terminal setup:\n"
                    "  rotate or reveal key first, then use:\n"
                    f"  export NMEM_API_URL=\"{url}\""
                )
            else:
                sections.append(
                    "Terminal setup:\n"
                    f"  export NMEM_API_URL=\"{url}\"\n"
                    f"  export NMEM_API_KEY=\"{self._remote_access_key_cache}\""
                )

        terminal_widget.update("\n\n".join(section for section in sections if section))

    def _build_lan_setup_text(self) -> str | None:
        if not self._remote_access_key_cache:
            return None
        port = self._local_loopback_port()
        return (
            "LAN setup:\n"
            f"  export NMEM_API_URL=\"http://<your-lan-ip>:{port}\"\n"
            f"  export NMEM_API_KEY=\"{self._remote_access_key_cache}\""
        )

    def _copy_to_clipboard(self, text: str, *, success_message: str) -> bool:
        if not HAS_CLIPBOARD or pyperclip is None:
            self.query_one("#remote-access-action-status", Static).update(
                "Clipboard support unavailable. Install 'pyperclip' to copy from TUI."
            )
            return False
        try:
            pyperclip.copy(text)
        except Exception as exc:
            self.query_one("#remote-access-action-status", Static).update(
                f"Clipboard copy failed: {exc}"
            )
            return False
        self.query_one("#remote-access-action-status", Static).update(success_message)
        return True

    async def _load_cli_access_settings(self) -> None:
        data = await self.api_client.get_cli_access_settings()
        if "error" in data:
            self._cli_access_settings = {}
            self.query_one("#remote-access-lan", Static).update(
                f"LAN access: ✗ {data['error']}"
            )
            self.query_one("#remote-access-allowlist", Static).update(
                "IP allowlist: unavailable"
            )
            return
        self._render_cli_access_settings(data.get("settings", {}))

    def _render_cli_access_settings(self, data: dict[str, Any]) -> None:
        self._cli_access_settings = data
        bind_all = bool(data.get("bindBackendAllInterfaces"))
        allowlist = data.get("ipAllowlist") or []
        if not isinstance(allowlist, list):
            allowlist = []
        bind_widget = self.query_one("#remote-access-lan", Static)
        allowlist_widget = self.query_one("#remote-access-allowlist", Static)
        bind_button = self.query_one("#btn-remote-lan-toggle", Button)
        apply_button = self.query_one("#btn-remote-allowlist", Button)

        bind_label = "● on (0.0.0.0)" if bind_all else "○ off (127.0.0.1)"
        bind_widget.update(f"LAN access: {bind_label}")

        if allowlist:
            allowlist_text = ", ".join(str(item) for item in allowlist)
            allowlist_widget.update(f"IP allowlist: {allowlist_text}")
        else:
            allowlist_widget.update("IP allowlist: all devices allowed")

        bind_button.label = (
            "Disable Same-Wi-Fi Access" if bind_all else "Enable Same-Wi-Fi Access"
        )
        if self._is_local_management_url():
            apply_button.disabled = False

    async def _update_cli_access_settings(
        self,
        updates: dict[str, Any],
        *,
        success_message: str,
        follow_up_message: str | None = None,
    ) -> bool:
        status_widget = self.query_one("#remote-access-action-status", Static)
        result = await self.api_client.update_cli_access_settings(updates)
        if "error" in result:
            status_widget.update(f"✗ {result['error']}")
            return False
        settings = result.get("settings", {})
        if isinstance(settings, dict):
            self._render_cli_access_settings(settings)
        status_widget.update(success_message)
        if follow_up_message:
            self.query_one("#remote-access-terminal", Static).update(follow_up_message)
        return True

    def _set_remote_management_controls_disabled(self, disabled: bool) -> None:
        """Enable/disable all local management controls for Access Anywhere."""
        for control_id in (
            "#btn-remote-lan-toggle",
            "#btn-remote-allowlist",
            "#btn-remote-start-quick",
            "#btn-remote-config-account",
            "#btn-remote-start-account",
            "#btn-remote-stop",
            "#btn-remote-rotate",
            "#btn-remote-reveal",
            "#btn-remote-copy-key",
            "#btn-remote-terminal",
            "#btn-remote-copy-terminal",
            "#btn-remote-copy-lan",
            "#btn-remote-qr",
            "#btn-remote-loopback-auth",
        ):
            self.query_one(control_id, Button).disabled = disabled

    def _ensure_local_remote_management(self) -> bool:
        """Require local-loopback API URL for local-only management endpoints."""
        if self._is_local_management_url():
            return True
        self._set_remote_management_controls_disabled(True)
        self.query_one("#remote-access-action-status", Static).update(
            "Access Anywhere management is local-only. "
            "Set NMEM_API_URL to this machine (for example http://127.0.0.1:14242)."
        )
        return False

    def _render_remote_access_status(self, data: dict[str, Any]) -> None:
        self._remote_access_status = data
        status_widget = self.query_one("#remote-access-status", Static)
        mode_widget = self.query_one("#remote-access-mode", Static)
        url_widget = self.query_one("#remote-access-url", Static)
        key_widget = self.query_one("#remote-access-key", Static)
        cloudflared_widget = self.query_one("#remote-access-cloudflared", Static)
        limits_widget = self.query_one("#remote-access-limitations", Static)
        action_widget = self.query_one("#remote-access-action-status", Static)

        start_quick_btn = self.query_one("#btn-remote-start-quick", Button)
        config_account_btn = self.query_one("#btn-remote-config-account", Button)
        start_account_btn = self.query_one("#btn-remote-start-account", Button)
        stop_btn = self.query_one("#btn-remote-stop", Button)
        rotate_btn = self.query_one("#btn-remote-rotate", Button)
        reveal_btn = self.query_one("#btn-remote-reveal", Button)
        terminal_btn = self.query_one("#btn-remote-terminal", Button)

        if "error" in data:
            error_msg = str(data.get("error"))
            status_widget.update(f"Status: ✗ {error_msg}")
            mode_widget.update("Mode: —")
            url_widget.update("Public URL: —")
            key_widget.update("API Key: —")
            cloudflared_widget.update("Cloudflare: —")
            limits_widget.update("")
            stop_btn.disabled = True
            start_quick_btn.disabled = True
            config_account_btn.disabled = True
            start_account_btn.disabled = True
            rotate_btn.disabled = True
            reveal_btn.disabled = True
            terminal_btn.disabled = True
            self._set_remote_management_controls_disabled(True)
            if "local-only" in error_msg.lower() and not self._is_local_management_url():
                action_widget.update(
                    "Access Anywhere settings are local-only. "
                    "Set NMEM_API_URL to this machine (for example http://127.0.0.1:14242)."
                )
            return

        running = bool(data.get("running"))
        active_mode = str(data.get("active_mode") or data.get("mode") or "quick")
        mode_label = "Quick link" if active_mode == "quick" else "Stable link"
        status_widget.update(f"Status: {'● Live' if running else '○ Off'}")
        mode_widget.update(f"Mode: {mode_label}")

        tunnel_url = (data.get("tunnel_url") or "").strip()
        url_widget.update(f"Public URL: {tunnel_url if tunnel_url else '—'}")

        api_key_payload = data.get("api_key")
        if isinstance(api_key_payload, str) and api_key_payload.strip():
            self._remote_access_key_cache = api_key_payload.strip()
        if self._remote_access_key_cache:
            key_widget.update(
                "API Key: "
                f"{self._mask_api_key(self._remote_access_key_cache)} "
                "(loaded)"
            )
        elif data.get("api_key_configured"):
            key_widget.update("API Key: hidden (use Reveal or Rotate)")
        else:
            key_widget.update("API Key: not configured")

        # Loopback auth status
        loopback_widget = self.query_one("#remote-access-loopback-auth", Static)
        require_loopback = bool(data.get("require_auth_loopback"))
        loopback_widget.update(
            f"Localhost auth: {'● on' if require_loopback else '○ off'}"
        )

        cloudflared_installed = bool(data.get("cloudflared_installed"))
        cloudflared_source = str(data.get("cloudflared_source") or "none")
        cloudflared_path = str(data.get("cloudflared_path") or "").strip()
        transport_protocol = str(data.get("transport_protocol") or "auto").strip()
        transport_protocol_source = str(
            data.get("transport_protocol_source") or "default"
        ).strip()
        active_transport_protocol = str(
            data.get("active_transport_protocol") or transport_protocol or "auto"
        ).strip()
        cloudflare_state = "● ready" if cloudflared_installed else "○ missing"
        path_text = f" @ {cloudflared_path}" if cloudflared_path else ""
        protocol_text = (
            f" transport={active_transport_protocol}"
            if running
            else (
                f" transport={transport_protocol} ({transport_protocol_source})"
                if cloudflared_installed
                else ""
            )
        )
        cloudflared_widget.update(
            f"Cloudflare: {cloudflare_state} ({cloudflared_source}){path_text}{protocol_text}"
        )

        limitations = data.get("limitations") or []
        if isinstance(limitations, list) and limitations:
            limits_widget.update("Notes: " + " | ".join(str(item) for item in limitations))
        else:
            limits_widget.update("")

        account_ready = bool(data.get("account_tunnel_configured"))
        if not self._is_local_management_url():
            self._set_remote_management_controls_disabled(True)
            action_widget.update(
                "Access Anywhere management is local-only. "
                "Set NMEM_API_URL to this machine (for example http://127.0.0.1:14242)."
            )
            return

        start_quick_btn.disabled = not cloudflared_installed
        config_account_btn.disabled = False
        start_account_btn.disabled = (not cloudflared_installed) or (not account_ready)
        stop_btn.disabled = not running
        rotate_btn.disabled = False
        reveal_btn.disabled = not bool(data.get("api_key_recoverable"))
        terminal_btn.disabled = not bool(tunnel_url)

        self._render_remote_terminal_setup()

    async def _check_remote_access_status(self) -> None:
        """Load Access Anywhere tunnel/auth status."""
        data = await self.api_client.get_remote_access_status()
        self._render_remote_access_status(data)

    def _queue_remote_access_status_refresh(self) -> None:
        """Schedule a background refresh while avoiding overlapping polls."""
        if self._remote_status_poll_inflight:
            return
        self._remote_status_poll_inflight = True
        self.run_worker(
            self._poll_remote_access_status_once(),
            exclusive=False,
            thread=False,
        )

    async def _poll_remote_access_status_once(self) -> None:
        try:
            await self._check_remote_access_status()
        finally:
            self._remote_status_poll_inflight = False

    async def _check_license_status(self) -> None:
        try:
            data = await self.api_client.get_license_status()
            if "error" in data:
                self.query_one("#license-tier", Static).update(f"Tier: ✗ {data['error']}")
                self.query_one("#btn-activate-license", Button).disabled = True
                self.query_one("#btn-renew-license", Button).disabled = True
                self.query_one("#btn-deactivate-license", Button).disabled = True
                return

            tier = data.get("tier", "free")
            email = data.get("email", "")
            activated = data.get("is_device_activated", False)
            activation_status = data.get("activation_status", "not_activated")
            access_state = data.get("pro_access_state", "free")
            has_full_pro_access = bool(data.get("has_full_pro_access"))
            device_id = data.get("device_id", "")

            tier_display = "● Pro" if tier == "pro" else "○ Free"
            self.query_one("#license-tier", Static).update(f"Tier: {tier_display}")

            if email:
                self.query_one("#license-email", Static).update(f"Email: {email}")
            else:
                self.query_one("#license-email", Static).update("")

            access_icon = "●" if has_full_pro_access else "○"
            self.query_one("#license-access", Static).update(
                f"Access: {access_icon} {access_state}"
            )

            act_icon = "●" if activated else "○"
            self.query_one("#license-activation", Static).update(
                f"Activation: {act_icon} {activation_status}"
            )

            if device_id:
                self.query_one("#license-device-id", Static).update(
                    f"Device: {device_id[:16]}..."
                )
            else:
                self.query_one("#license-device-id", Static).update("")

            # Enable/disable buttons based on state
            activate_btn = self.query_one("#btn-activate-license", Button)
            renew_btn = self.query_one("#btn-renew-license", Button)
            deactivate_btn = self.query_one("#btn-deactivate-license", Button)

            if access_state in {"active", "renewal_pending"}:
                activate_btn.disabled = True
                activate_btn.label = "Licensed"
                activate_btn.variant = "success"
            elif access_state == "pending_verification":
                activate_btn.disabled = True
                activate_btn.label = "Pending Verification"
                activate_btn.variant = "warning"
            else:
                activate_btn.disabled = False
                activate_btn.label = "Activate License"
                activate_btn.variant = "primary"

            renew_btn.disabled = access_state not in {
                "active",
                "renewal_pending",
                "pending_verification",
            }
            renew_btn.label = (
                "Renew Authorization"
                if access_state in {"renewal_pending", "pending_verification"}
                else "Refresh License"
            )

            if tier == "pro" or email or device_id:
                deactivate_btn.disabled = False
            else:
                deactivate_btn.disabled = True

        except Exception as e:
            try:
                self.query_one("#license-tier", Static).update(f"Tier: ✗ Error - {e}")
            except Exception:
                pass

    async def _check_llm_status(self) -> None:
        try:
            data = await self.api_client.get_remote_llm_config()
            if "error" in data:
                self.query_one("#llm-provider-status", Static).update(
                    f"Provider: ✗ {data['error']}"
                )
                self.query_one("#btn-test-llm", Button).disabled = True
                self.query_one("#btn-clone-provider", Button).disabled = True
                self.query_one("#btn-set-default-provider", Button).disabled = True
                self.query_one("#btn-set-agents-purpose", Button).disabled = True
                self.query_one("#btn-set-embedding-purpose", Button).disabled = True
                self.query_one("#btn-delete-provider", Button).disabled = True
                return

            enabled = data.get("enabled", False)
            active = data.get("active_provider", "")
            model = data.get("model", "")
            has_key = data.get("has_api_key", False)
            purposes = data.get("purposes", {})

            # OAuth providers (github_copilot, openai_codex) use the Test button
            # to trigger their device-code flow, so keep it enabled even without a key.
            _OAUTH_PROVIDERS = {"github_copilot", "openai_codex"}
            is_oauth = active in _OAUTH_PROVIDERS

            if enabled and active:
                if is_oauth:
                    key_str = "● authenticated" if has_key else "○ not authenticated"
                else:
                    key_str = "● key set" if has_key else "○ no key"
                self.query_one("#llm-provider-status", Static).update(
                    f"Provider: ● {active} ({key_str})"
                )
                self.query_one("#llm-model-status", Static).update(
                    f"Model: {model}" if model else ""
                )
                self.query_one("#btn-test-llm", Button).disabled = (
                    not has_key and not is_oauth
                )
            else:
                self.query_one("#llm-provider-status", Static).update(
                    "Provider: ○ Not configured"
                )
                self.query_one("#btn-test-llm", Button).disabled = True

            # Show provider list summary
            providers = data.get("providers", {})
            if providers:
                names = [
                    f"{p.get('display_name') or pid}"
                    + (" [key]" if p.get("has_api_key") else "")
                    for pid, p in providers.items()
                ]
                self.query_one("#llm-providers-list", Static).update(
                    f"Configured: {', '.join(names)}"
                )
                self.query_one("#btn-clone-provider", Button).disabled = False
                self.query_one("#btn-delete-provider", Button).disabled = False
                self.query_one("#btn-set-default-provider", Button).disabled = False
                self.query_one("#btn-set-agents-purpose", Button).disabled = False
                self.query_one("#btn-set-embedding-purpose", Button).disabled = False
            else:
                self.query_one("#llm-providers-list", Static).update(
                    "Configured: none"
                )
                self.query_one("#btn-clone-provider", Button).disabled = True
                self.query_one("#btn-delete-provider", Button).disabled = True
                self.query_one("#btn-set-default-provider", Button).disabled = True
                self.query_one("#btn-set-agents-purpose", Button).disabled = True
                self.query_one("#btn-set-embedding-purpose", Button).disabled = True

            if isinstance(purposes, dict):
                default_info = purposes.get("default", {})
                agents_info = purposes.get("ai_now", {})
                embedding_info = purposes.get("embedding", {})
                d_provider = (
                    default_info.get("effective_provider", "")
                    if isinstance(default_info, dict)
                    else ""
                )
                d_model = (
                    default_info.get("effective_model", "")
                    if isinstance(default_info, dict)
                    else ""
                )
                a_provider = (
                    agents_info.get("effective_provider", "")
                    if isinstance(agents_info, dict)
                    else ""
                )
                a_model = (
                    agents_info.get("effective_model", "")
                    if isinstance(agents_info, dict)
                    else ""
                )
                # Embedding purpose
                e_uses_local = (
                    embedding_info.get("uses_local", True)
                    if isinstance(embedding_info, dict)
                    else True
                )
                e_provider = (
                    embedding_info.get("effective_provider", "")
                    if isinstance(embedding_info, dict)
                    else ""
                )
                e_model = (
                    embedding_info.get("effective_model", "")
                    if isinstance(embedding_info, dict)
                    else ""
                )
                e_dim = (
                    embedding_info.get("dimension")
                    if isinstance(embedding_info, dict)
                    else None
                )
                embedding_str = "local"
                if not e_uses_local and e_provider:
                    embedding_str = f"{e_provider}/{e_model or '-'}"
                    if e_dim:
                        embedding_str += f" ({e_dim}d)"
                self.query_one("#llm-purpose-status", Static).update(
                    "Purposes: "
                    + f"default={d_provider}/{d_model or '-'}; "
                    + f"agents={a_provider}/{a_model or '-'}; "
                    + f"embedding={embedding_str}"
                )
            else:
                self.query_one("#llm-purpose-status", Static).update("")

        except Exception as e:
            try:
                self.query_one("#llm-provider-status", Static).update(
                    f"Provider: ✗ Error - {e}"
                )
            except Exception:
                pass

    @staticmethod
    def _render_state_text(state: str | None, exists_fallback: bool) -> str:
        normalized = state or ("ready" if exists_fallback else "not_installed")
        if normalized == "ready":
            return "● ready"
        if normalized == "installed_unverified":
            return "◐ installed (unverified)"
        if normalized == "corrupted":
            return "✗ corrupted"
        if normalized == "unsupported":
            return "○ unsupported"
        return "○ not installed"

    async def _check_search_index_status(
        self,
        *,
        full_verify: bool = False,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        """Check embedding model and search index status."""
        try:
            models_status = await self.api_client.get_models_status(
                full_verify=full_verify,
                force_refresh=force_refresh,
            )
            model_status = await self.api_client.get_bge_m3_status(
                full_verify=full_verify,
                force_refresh=force_refresh,
            )
            model_widget = self.query_one("#bge-m3-status", Static)
            llm_widget = self.query_one("#local-llm-status", Static)
            install_btn = self.query_one("#btn-install-bge-m3", Button)
            reindex_btn = self.query_one("#btn-reindex", Button)
            verify_btn = self.query_one("#btn-verify-models", Button)

            model_name = model_status.get("model_name", "Embedding Model")
            size_mb = model_status.get("size_mb", 500)
            search_state = model_status.get("state")

            if model_status.get("error"):
                model_widget.update(f"Embedding Model: ✗ Error - {model_status['error']}")
                install_btn.disabled = True
                verify_btn.disabled = False
            elif search_state == "corrupted":
                model_widget.update(f"Embedding Model: ✗ {model_name} (corrupted)")
                install_btn.disabled = False
                install_btn.label = "Reinstall"
                install_btn.variant = "error"
            elif model_status.get("exists"):
                state_text = self._render_state_text(search_state, True)
                model_widget.update(f"Embedding Model: {state_text} {model_name} (~{size_mb}MB)")
                install_btn.disabled = True
                install_btn.label = "Installed"
                install_btn.variant = "success"
            else:
                state_text = self._render_state_text(search_state, False)
                model_widget.update(f"Embedding Model: {state_text} {model_name} (~{size_mb}MB)")
                install_btn.disabled = False
                install_btn.label = "Download Model"
                install_btn.variant = "primary"

            local_state = models_status.get("model_states", {}).get("local_llm", {})
            local_state_name = local_state.get("model_name", "Local LLM")
            local_state_text = self._render_state_text(
                local_state.get("state"),
                bool(models_status.get("local_llm", False)),
            )
            if models_status.get("error"):
                llm_widget.update(f"Local LLM: ✗ Error - {models_status['error']}")
            else:
                llm_widget.update(f"Local LLM: {local_state_text} {local_state_name}")
            verify_btn.disabled = False

            index_status = await self.api_client.get_search_index_status()
            index_widget = self.query_one("#search-index-status", Static)

            if index_status.get("error"):
                index_widget.update(f"Search Index: ✗ Error - {index_status['error']}")
                reindex_btn.disabled = True
            elif index_status.get("available"):
                index_widget.update("Search Index: ● Ready for hybrid search")
                reindex_btn.disabled = False
            elif index_status.get("model_cached"):
                index_widget.update("Search Index: ○ Model cached, index not initialized")
                reindex_btn.disabled = False
            else:
                index_widget.update(f"Search Index: ○ {model_name} required")
                reindex_btn.disabled = True

            return {
                "models_status": models_status,
                "search_model_status": model_status,
                "index_status": index_status,
            }
        except Exception as e:
            try:
                self.query_one("#bge-m3-status", Static).update(f"Embedding Model: ✗ Error - {e}")
                self.query_one("#local-llm-status", Static).update(f"Local LLM: ✗ Error - {e}")
                self.query_one("#search-index-status", Static).update(f"Search Index: ✗ Error - {e}")
            except Exception:
                pass
            return {"error": str(e)}

    async def _check_kp_settings(self) -> None:
        """Load knowledge processing settings."""
        try:
            data = await self.api_client.get_knowledge_processing_settings()
            if "error" in data:
                self.query_one("#kp-settings-display", Static).update(
                    f"✗ {data['error']}"
                )
                return

            settings = data.get("settings", {})
            self._render_kp_settings(settings)
        except Exception as e:
            try:
                self.query_one("#kp-settings-display", Static).update(f"✗ Error - {e}")
            except Exception:
                pass

    def _render_kp_settings(self, settings: dict[str, Any]) -> None:
        """Render knowledge processing settings display."""
        toggles = [
            ("backgroundIntelligence", "Background Intelligence"),
            ("autoDailyBriefing", "Daily Briefing"),
            ("autoKGExtraction", "KG Extraction"),
            ("autoCommunityDetection", "Community Detection"),
            ("autoCrystallization", "Crystallization"),
            ("autoInsightDetection", "Insight Detection"),
            ("autoDecayRefresh", "Decay Score Refresh"),
            ("autoMemoryCompaction", "Memory Compaction"),
            ("autoArchiveStaleMemories", "Auto-Archive Stale"),
        ]
        lines = []
        for key, label in toggles:
            val = settings.get(key, False)
            icon = "●" if val else "○"
            lines.append(f"  {icon} {label}")

        hour = settings.get("briefingHour", 5)
        lines.append(f"  Briefing Hour: {hour}:00")

        self.query_one("#kp-settings-display", Static).update("\n".join(lines))

    async def _check_budget_status(self) -> None:
        """Load token budget status from agent."""
        try:
            # Get current limits from settings
            kp_data = await self.api_client.get_knowledge_processing_settings()
            settings = kp_data.get("settings", {})
            max_hour = settings.get("maxTokensPerHour", 500_000)
            max_day = settings.get("maxTokensPerDay", 2_000_000)
            max_task = settings.get("maxTokensPerTask", 500_000)

            # Get current usage from agent status
            agent_data = await self.api_client.get_agent_status()
            tokens_hour = agent_data.get("tokens_this_hour", 0)
            tokens_day = agent_data.get("tokens_today", 0)
            paused = agent_data.get("budget_paused", False)
            usage_incomplete = agent_data.get("usage_reporting_incomplete", False)
            missing_hour = agent_data.get("usage_unreported_this_hour", 0)
            missing_day = agent_data.get("usage_unreported_today", 0)

            self._render_budget(
                tokens_hour,
                tokens_day,
                max_hour,
                max_day,
                max_task,
                paused,
                usage_incomplete,
                missing_hour,
                missing_day,
            )
        except Exception as e:
            try:
                self.query_one("#budget-display", Static).update(f"✗ Error - {e}")
            except Exception:
                pass

    @staticmethod
    def _format_tokens(n: int) -> str:
        if n >= 1_000_000:
            return f"{n / 1_000_000:.1f}M"
        if n >= 1_000:
            return f"{n / 1_000:.0f}K"
        return str(n)

    def _render_budget(
        self,
        tokens_hour: int,
        tokens_day: int,
        max_hour: int,
        max_day: int,
        max_task: int,
        paused: bool,
        usage_incomplete: bool = False,
        missing_hour: int = 0,
        missing_day: int = 0,
    ) -> None:
        fmt = self._format_tokens
        lines = [
            f"  Hourly:   {fmt(tokens_hour)} / {fmt(max_hour)}",
            f"  Daily:    {fmt(tokens_day)} / {fmt(max_day)}",
            f"  Per Task: {fmt(max_task) if max_task > 0 else '∞'}",
        ]
        if paused:
            lines.append("  ✗ Budget exceeded — background tasks paused")
        if usage_incomplete:
            lines.append(
                f"  ! Totals are partial — {missing_hour} unreported step(s) this hour, {missing_day} today"
            )

        # Show editable hint
        lines.append("")
        lines.append("  Set via: nmem config settings set maxTokensPerHour <value>")
        lines.append("           nmem config settings set maxTokensPerDay <value>")
        lines.append("           nmem config settings set maxTokensPerTask <value>")

        self.query_one("#budget-display", Static).update("\n".join(lines))

    # =========================================================================
    # Button handlers
    # =========================================================================

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id

        # Access Anywhere buttons
        if button_id == "btn-remote-lan-toggle":
            if not self._ensure_local_remote_management():
                return
            bind_all = bool(self._cli_access_settings.get("bindBackendAllInterfaces"))
            new_value = not bind_all
            message = (
                "LAN access enabled. Restart the server or reinstall/restart the service to apply."
                if new_value
                else "LAN access disabled. Restart the server or reinstall/restart the service to apply."
            )
            await self._update_cli_access_settings(
                {"bindBackendAllInterfaces": new_value},
                success_message=message,
            )
        elif button_id == "btn-remote-allowlist":
            if not self._ensure_local_remote_management():
                return
            current = self._cli_access_settings.get("ipAllowlist") or []
            current_text = ", ".join(str(item) for item in current)
            self.app.push_screen(
                AccessAnywhereAllowlistModal(current_allowlist=current_text),
                callback=self._on_remote_allowlist_result,
            )
        elif button_id == "btn-remote-start-quick":
            if not self._ensure_local_remote_management():
                return
            await self._start_remote_access("quick")
        elif button_id == "btn-remote-config-account":
            if not self._ensure_local_remote_management():
                return
            current_url = str(self._remote_access_status.get("account_tunnel_url") or "")
            token_configured = bool(
                self._remote_access_status.get("account_tunnel_token_configured")
            )
            self.app.push_screen(
                AccessAnywhereAccountModal(
                    self.api_client,
                    current_url=current_url,
                    token_already_configured=token_configured,
                ),
                callback=self._on_remote_account_config_result,
            )
        elif button_id == "btn-remote-start-account":
            if not self._ensure_local_remote_management():
                return
            await self._start_remote_access("account")
        elif button_id == "btn-remote-stop":
            if not self._ensure_local_remote_management():
                return
            status_widget = self.query_one("#remote-access-action-status", Static)
            status_widget.update("Stopping Access Anywhere...")
            result = await self.api_client.stop_remote_access()
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                status_widget.update("Access Anywhere stopped.")
            await self._check_remote_access_status()
        elif button_id == "btn-remote-rotate":
            if not self._ensure_local_remote_management():
                return
            status_widget = self.query_one("#remote-access-action-status", Static)
            status_widget.update("Rotating remote API key...")
            result = await self.api_client.rotate_remote_access_key()
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                if isinstance(result.get("api_key"), str) and result["api_key"].strip():
                    self._remote_access_key_cache = result["api_key"].strip()
                status_widget.update("Remote API key rotated and loaded.")
                self._render_remote_access_status(result)
            await self._check_remote_access_status()
        elif button_id == "btn-remote-reveal":
            if not self._ensure_local_remote_management():
                return
            status_widget = self.query_one("#remote-access-action-status", Static)
            status_widget.update("Revealing remote API key...")
            result = await self.api_client.reveal_remote_access_key()
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                if isinstance(result.get("api_key"), str) and result["api_key"].strip():
                    self._remote_access_key_cache = result["api_key"].strip()
                    status_widget.update("Remote API key loaded for terminal setup.")
                else:
                    status_widget.update("Remote API key unavailable.")
                self._render_remote_access_status(result)
            await self._check_remote_access_status()
        elif button_id == "btn-remote-copy-key":
            if not self._ensure_local_remote_management():
                return
            if not self._remote_access_key_cache:
                result = await self.api_client.reveal_remote_access_key()
                if isinstance(result.get("api_key"), str) and result["api_key"].strip():
                    self._remote_access_key_cache = result["api_key"].strip()
                    self._render_remote_access_status(result)
                else:
                    self.query_one("#remote-access-action-status", Static).update(
                        "Reveal or Rotate key first."
                    )
                    return
            self._copy_to_clipboard(
                self._remote_access_key_cache,
                success_message="API key copied to clipboard.",
            )
        elif button_id == "btn-remote-terminal":
            if not self._ensure_local_remote_management():
                return
            status_widget = self.query_one("#remote-access-action-status", Static)
            self._render_remote_terminal_setup()
            if self._remote_access_key_cache:
                status_widget.update("Terminal setup shown below.")
            else:
                status_widget.update("Rotate or Reveal key to complete terminal setup.")
        elif button_id == "btn-remote-copy-terminal":
            if not self._ensure_local_remote_management():
                return
            tunnel_url = (self._remote_access_status.get("tunnel_url") or "").strip()
            if not tunnel_url:
                self.query_one("#remote-access-action-status", Static).update(
                    "Start a tunnel first."
                )
                return
            if not self._remote_access_key_cache:
                result = await self.api_client.reveal_remote_access_key()
                if isinstance(result.get("api_key"), str) and result["api_key"].strip():
                    self._remote_access_key_cache = result["api_key"].strip()
                    self._render_remote_access_status(result)
                else:
                    self.query_one("#remote-access-action-status", Static).update(
                        "Reveal or Rotate key first."
                    )
                    return
            self._copy_to_clipboard(
                (
                    f'export NMEM_API_URL="{tunnel_url}"\n'
                    f'export NMEM_API_KEY="{self._remote_access_key_cache}"'
                ),
                success_message="Terminal setup copied to clipboard.",
            )
        elif button_id == "btn-remote-copy-lan":
            if not self._ensure_local_remote_management():
                return
            if not self._remote_access_key_cache:
                result = await self.api_client.reveal_remote_access_key()
                if isinstance(result.get("api_key"), str) and result["api_key"].strip():
                    self._remote_access_key_cache = result["api_key"].strip()
                    self._render_remote_access_status(result)
                else:
                    self.query_one("#remote-access-action-status", Static).update(
                        "Reveal or Rotate key first."
                    )
                    return
            lan_setup = self._build_lan_setup_text()
            if not lan_setup:
                self.query_one("#remote-access-action-status", Static).update(
                    "No LAN setup available yet."
                )
                return
            self._copy_to_clipboard(
                lan_setup.replace("LAN setup:\n", "", 1),
                success_message="LAN setup copied to clipboard.",
            )
        elif button_id == "btn-remote-qr":
            if not self._ensure_local_remote_management():
                return
            status_widget = self.query_one("#remote-access-action-status", Static)
            terminal_widget = self.query_one("#remote-access-terminal", Static)
            if not self._remote_access_key_cache:
                # Try to reveal key first
                result = await self.api_client.reveal_remote_access_key()
                if isinstance(result.get("api_key"), str) and result["api_key"].strip():
                    self._remote_access_key_cache = result["api_key"].strip()
                else:
                    status_widget.update("Rotate or Reveal key first to generate a QR code.")
                    return
            tunnel_url = (self._remote_access_status.get("tunnel_url") or "").strip()
            if not tunnel_url:
                status_widget.update("No tunnel URL — start a tunnel first. QR needs a URL reachable from your phone.")
                return
            try:
                import json as _json
                import qrcode  # type: ignore[import-untyped]
                payload = _json.dumps({"url": tunnel_url, "key": self._remote_access_key_cache, "v": 1})
                qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M)
                qr.add_data(payload)
                qr.make(fit=True)
                import io
                buf = io.StringIO()
                qr.print_ascii(out=buf, invert=True)
                qr_text = buf.getvalue()
                terminal_widget.update(
                    f"{qr_text}\n"
                    f"  Server: {tunnel_url}\n"
                    f"  Scan from the Nowledge Mem mobile/web login screen."
                )
                status_widget.update("QR code shown below.")
            except ImportError:
                status_widget.update("QR output requires the 'qrcode' package.")
        elif button_id == "btn-remote-loopback-auth":
            if not self._ensure_local_remote_management():
                return
            status_widget = self.query_one("#remote-access-action-status", Static)
            current = bool(self._remote_access_status.get("require_auth_loopback"))
            new_state = not current
            status_widget.update(
                f"{'Enabling' if new_state else 'Disabling'} localhost auth..."
            )
            result = await self.api_client.set_loopback_auth(new_state)
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                label = "on" if new_state else "off"
                status_widget.update(f"Localhost auth: {label}")
                self._render_remote_access_status(result)
            await self._check_remote_access_status()
        elif button_id == "btn-remote-guide":
            status_widget = self.query_one("#remote-access-action-status", Static)
            try:
                opened = webbrowser.open(ACCESS_ANYWHERE_DOCS_URL)
                if opened:
                    status_widget.update(f"Opened guide: {ACCESS_ANYWHERE_DOCS_URL}")
                else:
                    status_widget.update(
                        f"Guide URL: {ACCESS_ANYWHERE_DOCS_URL}"
                    )
            except Exception:
                status_widget.update(f"Guide URL: {ACCESS_ANYWHERE_DOCS_URL}")

        # Search index buttons
        elif button_id == "btn-verify-models":
            status_widget = self.query_one("#search-action-status", Static)
            await self._verify_models(status_widget)
        elif button_id == "btn-install-bge-m3":
            status_widget = self.query_one("#search-action-status", Static)
            await self._install_bge_m3(status_widget)
        elif button_id == "btn-reindex":
            status_widget = self.query_one("#search-action-status", Static)
            await self._reindex_search_index(status_widget)

        # License buttons
        elif button_id == "btn-activate-license":
            self.app.push_screen(
                LicenseActivateModal(self.api_client),
                callback=self._on_license_activate_result,
            )
        elif button_id == "btn-renew-license":
            status_widget = self.query_one("#license-action-status", Static)
            status_widget.update("Refreshing license status...")
            result = await self.api_client.renew_license()
            if result.get("success"):
                status_widget.update(result.get("message") or "License refreshed.")
            else:
                status_widget.update(
                    f"✗ {result.get('message') or result.get('error') or result}"
                )
            await self._check_license_status()
        elif button_id == "btn-deactivate-license":
            result = await self.api_client.deactivate_license()
            status_widget = self.query_one("#license-action-status", Static)
            if result.get("success"):
                status_widget.update("License deactivated.")
            else:
                status_widget.update(f"✗ {result}")
            await self._check_license_status()

        # LLM provider buttons
        elif button_id == "btn-config-provider":
            config_data = await self.api_client.get_remote_llm_config()
            self.app.push_screen(
                ProviderConfigModal(self.api_client, config_data=config_data),
                callback=self._on_provider_config_result,
            )
        elif button_id == "btn-clone-provider":
            config_data = await self.api_client.get_remote_llm_config()
            providers = config_data.get("providers", {}) if isinstance(config_data, dict) else {}
            if not isinstance(providers, dict) or not providers:
                status_widget = self.query_one("#llm-action-status", Static)
                status_widget.update("✗ No configured providers to clone.")
                return
            self.app.push_screen(
                CloneProviderModal(self.api_client, config_data),
                callback=self._on_provider_clone_result,
            )
        elif button_id == "btn-delete-provider":
            config_data = await self.api_client.get_remote_llm_config()
            providers = config_data.get("providers", {}) if isinstance(config_data, dict) else {}
            if not isinstance(providers, dict) or not providers:
                status_widget = self.query_one("#llm-action-status", Static)
                status_widget.update("✗ No configured providers to delete.")
                return
            self.app.push_screen(
                DeleteProviderModal(self.api_client, config_data),
                callback=self._on_provider_remove_result,
            )
        elif button_id == "btn-set-default-provider":
            config_data = await self.api_client.get_remote_llm_config()
            self.app.push_screen(
                PurposeConfigModal(self.api_client, config_data, purpose="default"),
                callback=self._on_purpose_config_result,
            )
        elif button_id == "btn-set-agents-purpose":
            config_data = await self.api_client.get_remote_llm_config()
            self.app.push_screen(
                PurposeConfigModal(self.api_client, config_data, purpose="ai_now"),
                callback=self._on_purpose_config_result,
            )
        elif button_id == "btn-set-embedding-purpose":
            config_data = await self.api_client.get_remote_llm_config()
            self.app.push_screen(
                PurposeConfigModal(self.api_client, config_data, purpose="embedding"),
                callback=self._on_purpose_config_result,
            )
        elif button_id == "btn-test-llm":
            status_widget = self.query_one("#llm-action-status", Static)
            status_widget.update("Testing connection...")
            test_btn = self.query_one("#btn-test-llm", Button)
            test_btn.disabled = True
            try:
                result = await self.api_client.test_remote_llm_connection()
                if result.get("success"):
                    provider = result.get("provider", "")
                    model = result.get("model", "")
                    status_widget.update(f"● Connection OK — {provider}/{model}")
                else:
                    status_widget.update(f"✗ {result.get('message', 'Test failed')}")
            except Exception as e:
                status_widget.update(f"✗ Error: {e}")
            finally:
                test_btn.disabled = False

        # Knowledge processing toggles
        elif button_id and button_id.startswith("btn-toggle-"):
            await self._handle_kp_toggle(button_id)

    async def _on_license_activate_result(self, result: dict | None) -> None:
        """Callback for license activation modal."""
        if result:
            status = result.get("status", "error")
            msg = result.get("message", "")
            status_widget = self.query_one("#license-action-status", Static)
            if status in (
                "activated",
                "verified_offline",
                "verified_offline_pending_activation",
            ):
                status_widget.update(f"● {msg}")
            else:
                status_widget.update(f"✗ {msg}")
            await self._check_license_status()

    async def _on_provider_config_result(self, result: dict | None) -> None:
        """Callback for provider configuration modal."""
        if result:
            status_widget = self.query_one("#llm-action-status", Static)
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                status_widget.update("Provider configured.")
            await self._check_llm_status()

    async def _on_purpose_config_result(self, result: dict | None) -> None:
        """Callback for purpose configuration modal."""
        if result:
            status_widget = self.query_one("#llm-action-status", Static)
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                status_widget.update("Purpose selection updated.")
            await self._check_llm_status()

    async def _on_provider_remove_result(self, result: dict | None) -> None:
        """Callback for provider removal modal."""
        if result:
            status_widget = self.query_one("#llm-action-status", Static)
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                status_widget.update("Provider removed.")
            await self._check_llm_status()

    async def _on_provider_clone_result(self, result: dict | None) -> None:
        """Callback for provider clone modal."""
        if result:
            status_widget = self.query_one("#llm-action-status", Static)
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                status_widget.update("Provider cloned.")
            await self._check_llm_status()

    async def _start_remote_access(self, mode: str) -> None:
        status_widget = self.query_one("#remote-access-action-status", Static)
        if mode == "quick":
            status_widget.update("Starting quick link...")
        else:
            status_widget.update("Starting stable link...")
        result = await self.api_client.start_remote_access(mode=mode)
        if "error" in result:
            status_widget.update(f"✗ {result['error']}")
        else:
            if isinstance(result.get("api_key"), str) and result["api_key"].strip():
                self._remote_access_key_cache = result["api_key"].strip()
            tunnel_url = str(result.get("tunnel_url") or "").strip()
            if tunnel_url:
                status_widget.update(
                    "Access Anywhere is live. "
                    "Use Show Terminal Setup for env exports."
                )
            else:
                status_widget.update("Access Anywhere started.")
            self._render_remote_access_status(result)
        await self._check_remote_access_status()

    async def _on_remote_account_config_result(self, result: dict | None) -> None:
        """Callback for stable-link account configuration modal."""
        if result is None:
            return
        status_widget = self.query_one("#remote-access-action-status", Static)
        if "error" in result:
            status_widget.update(f"✗ {result['error']}")
        else:
            if result.get("token_extracted"):
                status_widget.update(
                    "Stable link saved. Tunnel token extracted from pasted command."
                )
            else:
                status_widget.update("Stable link saved.")
            self._render_remote_access_status(result)
        await self._check_remote_access_status()

    async def _on_remote_allowlist_result(self, result: dict | None) -> None:
        """Callback for LAN IP allowlist modal."""
        if result is None:
            return
        allowlist = result.get("ipAllowlist")
        if not isinstance(allowlist, list):
            self.query_one("#remote-access-action-status", Static).update(
                "✗ Invalid allowlist input."
            )
            return
        await self._update_cli_access_settings(
            {"ipAllowlist": allowlist},
            success_message=(
                "IP allowlist saved. Restart the server or reinstall/restart the service to apply."
            ),
        )

    async def _handle_kp_toggle(self, button_id: str) -> None:
        """Toggle a knowledge processing setting."""
        toggle_map = {
            "btn-toggle-bg-intel": "backgroundIntelligence",
            "btn-toggle-briefing": "autoDailyBriefing",
            "btn-toggle-kg-extract": "autoKGExtraction",
            "btn-toggle-community": "autoCommunityDetection",
            "btn-toggle-crystal": "autoCrystallization",
            "btn-toggle-insight": "autoInsightDetection",
            "btn-toggle-decay-refresh": "autoDecayRefresh",
            "btn-toggle-compaction": "autoMemoryCompaction",
            "btn-toggle-auto-archive": "autoArchiveStaleMemories",
        }
        key = toggle_map.get(button_id)
        if not key:
            return

        status_widget = self.query_one("#kp-action-status", Static)

        # Get current value and flip it
        current = await self.api_client.get_knowledge_processing_settings()
        settings = current.get("settings", {})
        new_val = not settings.get(key, False)

        result = await self.api_client.update_knowledge_processing_settings({key: new_val})
        if "error" in result:
            status_widget.update(f"✗ {result['error']}")
        else:
            state = "on" if new_val else "off"
            status_widget.update(f"Set {key} = {state}")
            self._render_kp_settings(result.get("settings", {}))

    # =========================================================================
    # Existing action handlers
    # =========================================================================

    async def _verify_models(self, status_widget: Static) -> None:
        """Run full verification for built-in local models."""
        verify_btn = self.query_one("#btn-verify-models", Button)
        verify_btn.disabled = True
        verify_btn.label = "Verifying..."
        status_widget.update("Running full model verification...")
        try:
            status = await self._check_search_index_status(
                full_verify=True,
                force_refresh=True,
            )
            if "error" in status:
                status_widget.update(f"Verification failed: {status['error']}")
                return

            states = status.get("models_status", {}).get("model_states", {})
            corrupted = [
                model_id
                for model_id, state in states.items()
                if isinstance(state, dict) and state.get("state") == "corrupted"
            ]
            if corrupted:
                status_widget.update(
                    "Verification failed. Corrupted model(s): "
                    + ", ".join(corrupted)
                    + ". Reinstall required."
                )
            else:
                status_widget.update("Verification complete. Installed models look healthy.")
        except Exception as e:
            status_widget.update(f"Verification error: {e}")
        finally:
            verify_btn.label = "Verify Models"
            verify_btn.disabled = False

    async def _install_bge_m3(self, status_widget: Static) -> None:
        """Download and install embedding model."""
        try:
            install_btn = self.query_one("#btn-install-bge-m3", Button)
            install_btn.disabled = True
            install_btn.label = "Downloading..."
            status_widget.update("Downloading embedding model... This may take a few minutes.")

            result = await self.api_client.install_bge_m3()

            if result.get("success"):
                status_widget.update("Model installed successfully! Click 'Rebuild Index' to enable hybrid search.")
                install_btn.label = "Installed"
                install_btn.variant = "success"
                await self._check_search_index_status(full_verify=True, force_refresh=True)
            else:
                error_msg = result.get("error") or result.get("message", "Unknown error")
                status_widget.update(f"Installation failed: {error_msg}")
                install_btn.label = "Download Model"
                install_btn.disabled = False

        except Exception as e:
            status_widget.update(f"Installation error: {e}")
            try:
                install_btn = self.query_one("#btn-install-bge-m3", Button)
                install_btn.label = "Download Model"
                install_btn.disabled = False
            except Exception:
                pass

    async def _reindex_search_index(self, status_widget: Static) -> None:
        """Rebuild the search index."""
        try:
            reindex_btn = self.query_one("#btn-reindex", Button)
            reindex_btn.disabled = True
            reindex_btn.label = "Reindexing..."
            status_widget.update("Rebuilding search index... This may take a while for large databases.")

            result = await self.api_client.reindex_search_index()

            if result.get("success"):
                memories = result.get("memories", 0)
                messages = result.get("messages", 0)
                communities = result.get("communities", 0)
                entities = result.get("entities", 0)
                status_widget.update(
                    f"Reindex complete! Indexed {memories} memories, {messages} messages, "
                    f"{communities} communities, {entities} entities."
                )
                await self._check_search_index_status()
            else:
                error_msg = result.get("error") or result.get("message", "Unknown error")
                status_widget.update(f"Reindex failed: {error_msg}")

            reindex_btn.label = "Rebuild Index"
            reindex_btn.disabled = False

        except Exception as e:
            status_widget.update(f"Reindex error: {e}")
            try:
                reindex_btn = self.query_one("#btn-reindex", Button)
                reindex_btn.label = "Rebuild Index"
                reindex_btn.disabled = False
            except Exception:
                pass
