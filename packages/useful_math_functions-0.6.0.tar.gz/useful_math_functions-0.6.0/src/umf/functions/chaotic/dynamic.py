"""Model for dynamic functions."""
