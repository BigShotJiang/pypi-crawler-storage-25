//! Python bindings for `TardigradeDB` via `PyO3`.
//!
//! Exposes the `Engine` as a Python class with `mem_write` / `mem_read` methods.
//! Key/value vectors are exchanged as numpy arrays for zero-copy where possible.
//!
//! Thread safety: Engine is wrapped in `Arc<Mutex<>>` (Monitor Object pattern).
//! Hot-path methods release the GIL via `py.detach()` so other Python threads
//! can run while Rust computes.

use std::sync::{Arc, Mutex};

use numpy::{PyReadonlyArray1, PyReadonlyArray2};
use pyo3::exceptions::PyRuntimeError;
use pyo3::prelude::*;

use tdb_engine::engine::Engine as RustEngine;

/// One element of a `mem_write_batch_packs` input list: a tuple of
/// `(owner, retrieval_key, layer_payloads, salience, text)`.
type BatchPackInput<'py> =
    (u64, PyReadonlyArray1<'py, f32>, Vec<(u16, PyReadonlyArray1<'py, f32>)>, f32, Option<String>);

/// A single retrieval result returned from `mem_read`.
#[pyclass]
#[derive(Debug)]
struct ReadResult {
    #[pyo3(get)]
    cell_id: u64,
    #[pyo3(get)]
    owner: u64,
    #[pyo3(get)]
    layer: u16,
    #[pyo3(get)]
    score: f32,
    #[pyo3(get)]
    tier: u8,
    #[pyo3(get)]
    importance: f32,
    key_data: Vec<f32>,
    value_data: Vec<f32>,
}

#[pymethods]
impl ReadResult {
    /// Get the key vector as a list of floats.
    fn key(&self) -> Vec<f32> {
        self.key_data.clone()
    }

    /// Get the value vector as a list of floats.
    fn value(&self) -> Vec<f32> {
        self.value_data.clone()
    }

    fn __repr__(&self) -> String {
        format!(
            "ReadResult(cell_id={}, owner={}, score={:.4}, tier={})",
            self.cell_id, self.owner, self.score, self.tier
        )
    }
}

/// `TardigradeDB` engine — persistent KV cache memory for LLM agents.
///
/// Thread-safe: wrapped in `Arc<Mutex<>>` so the GIL can be released
/// during engine operations and multiple Python threads can share one
/// instance.
#[pyclass]
struct Engine {
    inner: Arc<Mutex<RustEngine>>,
    maintenance_worker: Option<tdb_engine::maintenance::MaintenanceWorker>,
}

/// Resolve the effective salience for a write given the caller's explicit
/// value and an optional [`SalienceMode`] name. Returns the salience to
/// store or a `ValueError`-shaped error on an unknown mode.
///
/// The derivation lives in [`tdb_core::salience::SalienceMode::resolve`];
/// this function just adapts string→enum and re-shapes the error for
/// Python consumers.
fn resolve_salience(explicit: f32, mode: Option<&str>, encoded_key: &[f32]) -> PyResult<f32> {
    use tdb_core::salience::SalienceMode;
    use tdb_retrieval::per_token::HEADER_SIZE;
    let mode = match mode {
        None => return Ok(explicit),
        Some(s) => s,
    };
    let parsed = SalienceMode::parse(mode)
        .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
    Ok(parsed.resolve(explicit, encoded_key, HEADER_SIZE))
}

fn lock_engine(inner: &Mutex<RustEngine>) -> PyResult<std::sync::MutexGuard<'_, RustEngine>> {
    inner.lock().map_err(|_| PyRuntimeError::new_err("engine lock poisoned"))
}

#[pymethods]
impl Engine {
    /// Open or create a `TardigradeDB` engine at the given directory path.
    ///
    /// Optional configuration:
    ///   - `segment_size`: Segment file size threshold in bytes (default: 256MB).
    ///   - `vamana_threshold`: Cell count before activating Vamana ANN index (default: 10000).
    #[new]
    #[pyo3(signature = (path, segment_size=None, vamana_threshold=None))]
    fn new(
        path: &str,
        segment_size: Option<u64>,
        vamana_threshold: Option<usize>,
    ) -> PyResult<Self> {
        let dir = std::path::Path::new(path);
        let inner = match (segment_size, vamana_threshold) {
            (Some(seg), _) => RustEngine::open_with_segment_size(dir, seg),
            (None, Some(vt)) => RustEngine::open_with_vamana_threshold(dir, vt),
            (None, None) => RustEngine::open(dir),
        }
        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(Self { inner: Arc::new(Mutex::new(inner)), maintenance_worker: None })
    }

    /// Write key/value vectors to the engine (cell-level API).
    ///
    /// Prefer [`Engine::mem_write_pack`] for new code — the Pack API is
    /// the canonical interface for storing multi-layer KV caches.
    fn mem_write(
        &self,
        py: Python<'_>,
        owner: u64,
        layer: u16,
        key: PyReadonlyArray1<'_, f32>,
        value: PyReadonlyArray1<'_, f32>,
        salience: f32,
        parent_cell_id: Option<u64>,
    ) -> PyResult<u64> {
        let key_vec = key.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?.to_vec();
        let value_vec =
            value.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?.to_vec();

        let engine = Arc::clone(&self.inner);
        py.detach(move || {
            lock_engine(&engine)?
                .mem_write(owner, layer, &key_vec, value_vec, salience, parent_cell_id)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    /// Write multiple cells in a single batch with one fsync (Batch Command).
    ///
    /// Each item is a tuple of (owner, layer, key, value, salience, parent).
    /// Returns a list of assigned cell IDs.
    fn mem_write_batch(
        &self,
        requests: Vec<pyo3::Py<pyo3::PyAny>>,
        py: Python<'_>,
    ) -> PyResult<Vec<u64>> {
        use tdb_engine::engine::WriteRequest;

        let reqs: Vec<WriteRequest> = requests
            .iter()
            .map(|item| {
                let tuple = item.bind(py).cast::<pyo3::types::PyTuple>()?;
                let owner: u64 = tuple.get_item(0)?.extract()?;
                let layer: u16 = tuple.get_item(1)?.extract()?;
                let key: PyReadonlyArray1<'_, f32> = tuple.get_item(2)?.extract()?;
                let value: PyReadonlyArray1<'_, f32> = tuple.get_item(3)?.extract()?;
                let salience: f32 = tuple.get_item(4)?.extract()?;
                let parent: Option<u64> = tuple.get_item(5)?.extract()?;
                Ok(WriteRequest {
                    owner,
                    layer,
                    key: key
                        .as_slice()
                        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
                        .to_vec(),
                    value: value
                        .as_slice()
                        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
                        .to_vec(),
                    salience,
                    parent_cell_id: parent,
                })
            })
            .collect::<PyResult<Vec<_>>>()?;

        let engine = Arc::clone(&self.inner);
        py.detach(move || {
            lock_engine(&engine)?
                .mem_write_batch(&reqs)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    /// Read the top-k most relevant cells for a query key (cell-level API).
    ///
    /// Prefer [`Engine::mem_read_pack`] for new code — the Pack API returns
    /// complete multi-layer KV caches ready for injection.
    fn mem_read(
        &self,
        py: Python<'_>,
        query_key: PyReadonlyArray1<'_, f32>,
        k: usize,
        owner: Option<u64>,
    ) -> PyResult<Vec<ReadResult>> {
        let query_vec =
            query_key.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?.to_vec();

        let engine = Arc::clone(&self.inner);
        let raw_results = py.detach(move || -> PyResult<Vec<_>> {
            let mut eng = lock_engine(&engine)?;
            let results = eng
                .mem_read(&query_vec, k, owner)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
            Ok(results
                .into_iter()
                .map(|r| {
                    let importance = eng.cell_importance(r.cell.id).unwrap_or(0.0);
                    (r, importance)
                })
                .collect())
        })?;

        Ok(raw_results
            .into_iter()
            .map(|(r, importance)| ReadResult {
                cell_id: r.cell.id,
                owner: r.cell.owner,
                layer: r.cell.layer,
                score: r.score,
                tier: r.tier as u8,
                importance,
                key_data: r.cell.key,
                value_data: r.cell.value,
            })
            .collect())
    }

    /// Read top-k cells using a raw per-token query matrix (Direct Token Query API).
    ///
    /// Accepts a 2D `NumPy` array of shape `(n_tokens, dim)` directly, avoiding
    /// the Python-side `encode_per_token` round-trip (header build + flatten +
    /// `PyO3` copy + Rust header parse). The Rust engine builds the encoded key
    /// in one allocation and delegates to `mem_read`.
    fn mem_read_tokens(
        &self,
        py: Python<'_>,
        query_tokens: PyReadonlyArray2<'_, f32>,
        k: usize,
        owner: Option<u64>,
    ) -> PyResult<Vec<ReadResult>> {
        let query_arr = query_tokens.as_array();
        let shape = query_arr.shape();
        let n_tokens = shape[0];
        let dim = shape[1];

        // numpy may give a non-contiguous view; ensure C-order before passing on.
        let flat: Vec<f32> = if let Some(slice) = query_arr.as_slice() {
            slice.to_vec()
        } else {
            query_arr.iter().copied().collect()
        };

        let engine = Arc::clone(&self.inner);
        let raw_results = py.detach(move || -> PyResult<Vec<_>> {
            let mut eng = lock_engine(&engine)?;
            let results = eng
                .mem_read_tokens(&flat, n_tokens, dim, k, owner)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
            Ok(results
                .into_iter()
                .map(|r| {
                    let importance = eng.cell_importance(r.cell.id).unwrap_or(0.0);
                    (r, importance)
                })
                .collect())
        })?;

        Ok(raw_results
            .into_iter()
            .map(|(r, importance)| ReadResult {
                cell_id: r.cell.id,
                owner: r.cell.owner,
                layer: r.cell.layer,
                score: r.score,
                tier: r.tier as u8,
                importance,
                key_data: r.cell.key,
                value_data: r.cell.value,
            })
            .collect())
    }

    /// Configure post-retrieval refinement (vague-query rescue).
    ///
    /// `mode` selects the strategy: `"none"`, `"centered"`, `"whitened"`, `"prf"`.
    /// With `"prf"`, optional `alpha` (default 0.7), `beta` (default 0.3), and
    /// `k_prime` (default 3) tune the Rocchio expansion.
    #[pyo3(signature = (mode, alpha=None, beta=None, k_prime=None))]
    fn set_refinement_mode(
        &self,
        mode: &str,
        alpha: Option<f32>,
        beta: Option<f32>,
        k_prime: Option<usize>,
    ) -> PyResult<()> {
        let strategy = tdb_retrieval::refinement::strategy_from_name(mode, alpha, beta, k_prime)
            .ok_or_else(|| {
                PyRuntimeError::new_err(format!(
                    "unknown refinement mode '{mode}' (expected 'none', 'centered', 'prf', or 'whitened')"
                ))
            })?;
        lock_engine(&self.inner)?.set_refinement_strategy(strategy);
        Ok(())
    }

    /// Currently configured refinement mode as `"none" | "centered" | "whitened" | "prf"`.
    fn refinement_mode(&self) -> PyResult<String> {
        Ok(lock_engine(&self.inner)?.refinement_mode_name().to_string())
    }

    /// Enable or disable corpus-mean distance token importance reweighting.
    ///
    /// When enabled, each per-token score is scaled by
    /// `1 - cosine(token, corpus_mean)` before aggregation — distinctive tokens
    /// carry more retrieval signal than tokens aligned with the mean activation.
    fn set_token_reweighting(&self, enabled: bool) -> PyResult<()> {
        lock_engine(&self.inner)?.set_token_reweighting(enabled);
        Ok(())
    }

    /// Whether corpus-mean distance token importance reweighting is enabled.
    fn token_reweighting(&self) -> PyResult<bool> {
        Ok(lock_engine(&self.inner)?.token_reweighting())
    }

    /// Get the current importance score of a cell.
    fn cell_importance(&self, cell_id: u64) -> PyResult<Option<f32>> {
        Ok(lock_engine(&self.inner)?.cell_importance(cell_id))
    }

    /// Get the current tier of a cell (0=Draft, 1=Validated, 2=Core).
    fn cell_tier(&self, cell_id: u64) -> PyResult<Option<u8>> {
        Ok(lock_engine(&self.inner)?.cell_tier(cell_id).map(|t| t as u8))
    }

    /// Total number of cells in the engine.
    fn cell_count(&self) -> PyResult<usize> {
        Ok(lock_engine(&self.inner)?.cell_count())
    }

    /// Get transitive ancestors of a cell following causal edges.
    fn trace_ancestors(&self, cell_id: u64) -> PyResult<Vec<u64>> {
        Ok(lock_engine(&self.inner)?.trace_ancestors(cell_id))
    }

    /// Whether the Vamana ANN index is active.
    fn has_vamana(&self) -> PyResult<bool> {
        Ok(lock_engine(&self.inner)?.has_vamana())
    }

    /// Simulate passage of time for governance decay (testing utility).
    fn advance_days(&self, days: f32) -> PyResult<()> {
        lock_engine(&self.inner)?.advance_days(days);
        Ok(())
    }

    /// Evict Draft-tier packs below the importance threshold.
    #[pyo3(signature = (importance_threshold, owner=None))]
    fn evict_draft_packs(&self, importance_threshold: f32, owner: Option<u64>) -> PyResult<usize> {
        lock_engine(&self.inner)?
            .evict_draft_packs(importance_threshold, owner)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Run a governance sweep synchronously.
    ///
    /// Advances importance decay by ``hours`` and evicts Draft-tier
    /// packs that fall below ``eviction_threshold``. Returns the
    /// number of packs evicted. Use after a known event when you
    /// want tier transitions visible before the next read.
    #[pyo3(signature = (hours=0.0, eviction_threshold=15.0))]
    fn sweep_now(&self, hours: f32, eviction_threshold: f32) -> PyResult<usize> {
        lock_engine(&self.inner)?
            .sweep_now(hours, eviction_threshold)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Enumerate every owner with at least one pack stored.
    ///
    /// Returns owners in ascending order.
    fn list_owners(&self) -> PyResult<Vec<u64>> {
        Ok(lock_engine(&self.inner)?.list_owners())
    }

    /// Schedule an ``evict_draft`` action to fire at
    /// ``fires_at_unix_secs`` (seconds since the Unix epoch).
    /// Returns the assigned schedule id.
    ///
    /// The schedule is persisted to a JSON sidecar before this
    /// returns and survives engine restart. Built-in actions
    /// are idempotent; the at-least-once delivery model gives
    /// fire-once-in-effect across crashes.
    fn schedule_evict_draft(
        &self,
        fires_at_unix_secs: f64,
        owner: u64,
        threshold: f32,
    ) -> PyResult<u64> {
        let fires_at =
            std::time::UNIX_EPOCH + std::time::Duration::from_secs_f64(fires_at_unix_secs);
        lock_engine(&self.inner)?
            .schedule(
                fires_at,
                tdb_engine::scheduler::ScheduledAction::EvictDraft { owner, threshold },
            )
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Cancel a previously-scheduled action. Returns ``True`` if
    /// the entry was found and removed.
    fn cancel_scheduled(&self, id: u64) -> PyResult<bool> {
        lock_engine(&self.inner)?
            .cancel_scheduled(id)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// List pending scheduled entries as dicts:
    /// ``{"id": int, "fires_at_unix_secs": float, "action": dict}``.
    /// Entries are sorted by fire time ascending.
    fn list_scheduled(&self, py: Python<'_>) -> PyResult<Vec<pyo3::Py<pyo3::PyAny>>> {
        use std::time::UNIX_EPOCH;
        let entries = lock_engine(&self.inner)?.list_scheduled();
        entries
            .iter()
            .map(|e| {
                let dict = pyo3::types::PyDict::new(py);
                dict.set_item("id", e.id)?;
                let secs =
                    e.fires_at.duration_since(UNIX_EPOCH).map(|d| d.as_secs_f64()).unwrap_or(0.0);
                dict.set_item("fires_at_unix_secs", secs)?;
                let action = pyo3::types::PyDict::new(py);
                match &e.action {
                    tdb_engine::scheduler::ScheduledAction::EvictDraft { owner, threshold } => {
                        action.set_item("type", "evict_draft")?;
                        action.set_item("owner", *owner)?;
                        action.set_item("threshold", *threshold)?;
                    }
                }
                dict.set_item("action", action)?;
                Ok(dict.into())
            })
            .collect()
    }

    /// Fire any actions whose `fires_at <= now`. Returns the
    /// number of actions that fired successfully. Use after a
    /// known event when you want scheduled work committed
    /// before the next tick of the background maintenance
    /// worker.
    fn fire_due_scheduled(&self) -> PyResult<usize> {
        lock_engine(&self.inner)?
            .fire_due_scheduled(std::time::SystemTime::now())
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Return ``True`` iff the engine has at least one pack for ``owner``.
    fn owner_exists(&self, owner: u64) -> PyResult<bool> {
        Ok(lock_engine(&self.inner)?.owner_exists(owner))
    }

    /// Delete every pack belonging to ``owner``; return the count
    /// deleted. Unlike :py:meth:`evict_draft_packs`, this is
    /// unconditional — validated and core-tier packs are removed
    /// too. Returns ``0`` when the owner has no packs.
    fn delete_owner(&self, owner: u64) -> PyResult<usize> {
        lock_engine(&self.inner)?
            .delete_owner(owner)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Snapshot the engine state to a portable tar archive at
    /// ``out_path``. Returns the manifest as a dict with keys
    /// ``magic``, ``format_version``, ``created_at``, ``pack_count``,
    /// ``owner_count``, ``sha256``.
    ///
    /// ``out_path`` must be outside the engine's working directory —
    /// otherwise the tar walker would read its own output.
    fn snapshot(&self, py: Python<'_>, out_path: &str) -> PyResult<pyo3::Py<pyo3::PyAny>> {
        let manifest = lock_engine(&self.inner)?
            .snapshot(std::path::Path::new(out_path))
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        let dict = pyo3::types::PyDict::new(py);
        dict.set_item("magic", &manifest.magic)?;
        dict.set_item("format_version", manifest.format_version)?;
        dict.set_item("created_at", &manifest.created_at)?;
        dict.set_item("pack_count", manifest.stats.pack_count)?;
        dict.set_item("owner_count", manifest.stats.owner_count)?;
        dict.set_item("sha256", &manifest.sha256)?;
        dict.set_item("quantization_codec", &manifest.codecs.quantization)?;
        dict.set_item("key_codec", &manifest.codecs.key)?;
        Ok(dict.into())
    }

    /// Restore a snapshot archive at ``in_path`` into ``target_dir``
    /// and return a freshly opened :class:`Engine`.
    ///
    /// ``target_dir`` must be empty or non-existent. Raises
    /// :py:exc:`RuntimeError` with a typed message on integrity,
    /// magic, version, or codec mismatch.
    #[staticmethod]
    fn restore_from(in_path: &str, target_dir: &str) -> PyResult<Self> {
        let engine = tdb_engine::engine::Engine::restore_from(
            std::path::Path::new(in_path),
            std::path::Path::new(target_dir),
        )
        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(Self {
            inner: std::sync::Arc::new(std::sync::Mutex::new(engine)),
            maintenance_worker: None,
        })
    }

    /// Open an engine at ``path`` with a streaming-ingest write
    /// buffer enabled. Buffered writes return their pack id
    /// synchronously and defer the fsync until the buffer reaches
    /// ``max_batch_size`` or :py:meth:`flush_buffer` is called.
    ///
    /// ``max_idle_ms`` is reserved for a future idle-timer flush
    /// (currently has no effect); pass ``0``.
    #[staticmethod]
    #[pyo3(signature = (path, max_batch_size, max_idle_ms=0))]
    fn open_with_write_buffer(
        path: &str,
        max_batch_size: usize,
        max_idle_ms: u64,
    ) -> PyResult<Self> {
        let engine = tdb_engine::engine::Engine::open_with_write_buffer(
            std::path::Path::new(path),
            tdb_engine::engine::BufferConfig { max_batch_size, max_idle_ms },
        )
        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(Self {
            inner: std::sync::Arc::new(std::sync::Mutex::new(engine)),
            maintenance_worker: None,
        })
    }

    /// Drain the streaming write buffer. No-op when the
    /// engine was opened without a buffer or when the buffer is
    /// already empty.
    fn flush_buffer(&self) -> PyResult<()> {
        lock_engine(&self.inner)?.flush_buffer().map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Number of stages in the retrieval pipeline.
    fn pipeline_stage_count(&self) -> PyResult<usize> {
        Ok(lock_engine(&self.inner)?.pipeline_stage_count())
    }

    // ── SynapticBank (`LoRA` adapter persistence) ─────────────────────────

    /// Store a `LoRA` adapter entry. Arrays are f32 in Python, converted to f16 internally.
    #[pyo3(signature = (id, owner, lora_a, lora_b, scale, rank, d_model, last_used=None, quality=None))]
    #[expect(clippy::too_many_arguments)]
    fn store_synapsis(
        &self,
        id: u64,
        owner: u64,
        lora_a: PyReadonlyArray1<'_, f32>,
        lora_b: PyReadonlyArray1<'_, f32>,
        scale: f32,
        rank: u32,
        d_model: u32,
        last_used: Option<u64>,
        quality: Option<f32>,
    ) -> PyResult<()> {
        use half::f16;
        use pyo3::exceptions::PyValueError;
        use tdb_core::synaptic_bank::SynapticBankEntry;

        let expected_len = (rank * d_model) as usize;
        let a_slice = lora_a.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        let b_slice = lora_b.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?;

        if a_slice.len() != expected_len {
            return Err(PyValueError::new_err(format!(
                "lora_a length {} != rank({}) * d_model({}) = {}",
                a_slice.len(),
                rank,
                d_model,
                expected_len
            )));
        }
        if b_slice.len() != expected_len {
            return Err(PyValueError::new_err(format!(
                "lora_b length {} != rank({}) * d_model({}) = {}",
                b_slice.len(),
                rank,
                d_model,
                expected_len
            )));
        }

        let mut entry = SynapticBankEntry::new(
            id,
            owner,
            a_slice.iter().map(|v| f16::from_f32(*v)).collect(),
            b_slice.iter().map(|v| f16::from_f32(*v)).collect(),
            f16::from_f32(scale),
            rank,
            d_model,
        );
        entry.last_used = last_used.unwrap_or(0);
        entry.quality = quality.unwrap_or(0.0);
        lock_engine(&self.inner)?
            .store_synapsis(&entry)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Load all `LoRA` adapter entries for an owner.
    ///
    /// Returns list of dicts with f32 numpy arrays (f16 converted to f32 on return).
    fn load_synapsis(&self, py: Python<'_>, owner: u64) -> PyResult<Vec<pyo3::Py<pyo3::PyAny>>> {
        let entries = lock_engine(&self.inner)?
            .load_synapsis(owner)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;

        let mut results = Vec::with_capacity(entries.len());
        for entry in entries {
            let dict = pyo3::types::PyDict::new(py);
            dict.set_item("id", entry.id)?;
            dict.set_item("owner", entry.owner)?;
            dict.set_item("rank", entry.rank)?;
            dict.set_item("d_model", entry.d_model)?;
            dict.set_item("scale", entry.scale.to_f32())?;
            dict.set_item("last_used", entry.last_used)?;
            dict.set_item("quality", entry.quality)?;

            let a_f32: Vec<f32> = entry.lora_a.iter().map(|v| v.to_f32()).collect();
            let b_f32: Vec<f32> = entry.lora_b.iter().map(|v| v.to_f32()).collect();
            dict.set_item("lora_a", numpy::PyArray1::from_vec(py, a_f32))?;
            dict.set_item("lora_b", numpy::PyArray1::from_vec(py, b_f32))?;

            results.push(dict.into_any().unbind());
        }
        Ok(results)
    }

    /// Snapshot of engine state for monitoring and diagnostics.
    ///
    /// Returns a dict with keys: `cell_count`, `pack_count`, `segment_count`,
    /// `slb_occupancy`, `slb_capacity`, `vamana_active`, `pipeline_stages`,
    /// `governance_entries`, `trace_edges`, `arena_bytes`, `arena_bytes_per_cell`.
    fn status(&self, py: Python<'_>) -> PyResult<pyo3::Py<pyo3::PyAny>> {
        let s = lock_engine(&self.inner)?.status();
        let dict = pyo3::types::PyDict::new(py);
        dict.set_item("cell_count", s.cell_count)?;
        dict.set_item("pack_count", s.pack_count)?;
        dict.set_item("segment_count", s.segment_count)?;
        dict.set_item("slb_occupancy", s.slb_occupancy)?;
        dict.set_item("slb_capacity", s.slb_capacity)?;
        dict.set_item("vamana_active", s.vamana_active)?;
        dict.set_item("pipeline_stages", s.pipeline_stages)?;
        dict.set_item("governance_entries", s.governance_entries)?;
        dict.set_item("trace_edges", s.trace_edges)?;
        dict.set_item("arena_bytes", s.arena_bytes)?;
        dict.set_item("arena_bytes_per_cell", s.arena_bytes_per_cell)?;
        Ok(dict.into_any().unbind())
    }

    /// Compact storage by rewriting segments with dead cells.
    ///
    /// Returns a dict with `segments_compacted`, `cells_moved`, `bytes_reclaimed`.
    fn compact(&self, py: Python<'_>) -> PyResult<pyo3::Py<pyo3::PyAny>> {
        let engine = Arc::clone(&self.inner);
        let result = py.detach(move || {
            lock_engine(&engine)?.compact().map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })?;
        let dict = pyo3::types::PyDict::new(py);
        dict.set_item("segments_compacted", result.segments_compacted)?;
        dict.set_item("cells_moved", result.cells_moved)?;
        dict.set_item("bytes_reclaimed", result.bytes_reclaimed)?;
        Ok(dict.into_any().unbind())
    }

    // ── Maintenance (background governance + compaction) ────────────────

    /// Start background maintenance (governance sweep + auto-compaction).
    #[pyo3(signature = (sweep_interval_secs=3600.0, compaction_interval_secs=21600.0, eviction_threshold=15.0, hours_per_tick=1.0))]
    fn start_maintenance(
        &mut self,
        sweep_interval_secs: f64,
        compaction_interval_secs: f64,
        eviction_threshold: f32,
        hours_per_tick: f32,
    ) -> PyResult<()> {
        use tdb_engine::maintenance::{MaintenanceConfig, MaintenanceWorker};

        if self.maintenance_worker.as_ref().is_some_and(|w| w.is_running()) {
            return Err(PyRuntimeError::new_err("maintenance already running"));
        }

        let config = MaintenanceConfig {
            sweep_interval: std::time::Duration::from_secs_f64(sweep_interval_secs),
            compaction_interval: std::time::Duration::from_secs_f64(compaction_interval_secs),
            eviction_threshold,
            hours_per_tick,
            enabled: true,
        };

        let mut worker = MaintenanceWorker::new(config);
        worker.start(Arc::clone(&self.inner));
        self.maintenance_worker = Some(worker);
        Ok(())
    }

    /// Stop background maintenance.
    fn stop_maintenance(&mut self) {
        if let Some(ref mut worker) = self.maintenance_worker {
            worker.stop();
        }
    }

    /// Whether background maintenance is currently running.
    fn is_maintenance_running(&self) -> bool {
        self.maintenance_worker.as_ref().is_some_and(|w| w.is_running())
    }

    /// Get maintenance statistics.
    fn maintenance_status(&self, py: Python<'_>) -> PyResult<pyo3::Py<pyo3::PyAny>> {
        let status = self
            .maintenance_worker
            .as_ref()
            .map_or_else(tdb_engine::maintenance::MaintenanceStatus::default, |w| w.status());

        let dict = pyo3::types::PyDict::new(py);
        dict.set_item("sweep_count", status.sweep_count)?;
        dict.set_item("compaction_count", status.compaction_count)?;
        dict.set_item("total_packs_evicted", status.total_packs_evicted)?;
        dict.set_item("total_bytes_reclaimed", status.total_bytes_reclaimed)?;
        dict.set_item("last_sweep_epoch_secs", status.last_sweep_epoch_secs)?;
        dict.set_item("last_compaction_epoch_secs", status.last_compaction_epoch_secs)?;
        Ok(dict.into_any().unbind())
    }

    /// Persist a known-size batch of packs with one coalesced fsync.
    ///
    /// Each pack is a tuple `(owner, retrieval_key, layer_payloads, salience, text)`
    /// where `layer_payloads` is a list of `(layer_idx, data)` tuples and `text`
    /// is optional. Returns a list of assigned pack ids, strictly increasing
    /// and aligned to the input order.
    ///
    /// Distinct from [`Engine::open_with_write_buffer`]: this is the eager
    /// "I have N packs in hand, persist them all now" path. If a streaming
    /// write buffer is configured, its pending entries are flushed first so
    /// the batch lands after them.
    ///
    /// An empty input returns an empty list and does not touch storage.
    fn mem_write_batch_packs(
        &self,
        py: Python<'_>,
        packs: Vec<BatchPackInput<'_>>,
    ) -> PyResult<Vec<u64>> {
        use tdb_core::kv_pack::{KVLayerPayload, KVPack};

        if packs.is_empty() {
            return Ok(Vec::new());
        }

        let kv_packs: Vec<KVPack> = packs
            .into_iter()
            .map(|(owner, retrieval_key, layer_payloads, salience, text)| {
                let key = retrieval_key
                    .as_slice()
                    .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
                    .to_vec();
                let layers: Vec<KVLayerPayload> = layer_payloads
                    .iter()
                    .map(|(idx, data)| {
                        Ok(KVLayerPayload {
                            layer_idx: *idx,
                            data: data
                                .as_slice()
                                .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
                                .to_vec(),
                        })
                    })
                    .collect::<PyResult<Vec<_>>>()?;
                Ok::<_, PyErr>(KVPack { id: 0, owner, retrieval_key: key, layers, salience, text })
            })
            .collect::<PyResult<Vec<_>>>()?;

        let engine = Arc::clone(&self.inner);
        py.detach(move || {
            lock_engine(&engine)?
                .mem_write_batch_packs(&kv_packs)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    /// Store a complete multi-layer KV pack from a raw per-token retrieval matrix.
    ///
    /// Accepts a 2D `NumPy` array of shape `(n_tokens, dim)` directly. The
    /// engine builds the encoded retrieval key in one allocation in Rust,
    /// avoiding the Python-side `encode_per_token` round-trip (header build +
    /// flatten + `PyO3` copy + Rust re-parse).
    ///
    /// Symmetric write-side counterpart to [`Engine::mem_read_tokens`]. Prefer
    /// this over [`Engine::mem_write_pack`] when the caller already has the
    /// retrieval tokens as a 2D matrix; use [`Engine::mem_write_pack`] when
    /// the key is already encoded.
    ///
    /// Returns the assigned pack ID. Raises `RuntimeError` (stable code
    /// `tdb::write::empty_token_matrix`) on an empty / malformed matrix —
    /// silently writing such a pack would create an unqueryable cell.
    #[pyo3(signature = (owner, token_matrix, layer_payloads, salience, text=None, salience_mode=None))]
    fn mem_write_pack_tokens(
        &self,
        py: Python<'_>,
        owner: u64,
        token_matrix: PyReadonlyArray2<'_, f32>,
        layer_payloads: Vec<(u16, PyReadonlyArray1<'_, f32>)>,
        salience: f32,
        text: Option<String>,
        salience_mode: Option<&str>,
    ) -> PyResult<u64> {
        use tdb_core::kv_pack::KVLayerPayload;
        use tdb_retrieval::per_token::encode_per_token_keys;

        let tokens_arr = token_matrix.as_array();
        let shape = tokens_arr.shape();
        let n_tokens = shape[0];
        let dim = shape[1];

        // Non-contiguous views (e.g. `tokens[::2]`) must work; fall back to a
        // copy when the strided layout disagrees with C-order.
        let flat: Vec<f32> = if let Some(slice) = tokens_arr.as_slice() {
            slice.to_vec()
        } else {
            tokens_arr.iter().copied().collect()
        };

        // For salience_mode resolution we need the encoded key the engine
        // will see. When the caller passes a derivation mode (not `None`
        // and not `"none"`) we build the encoded key view in Python-land
        // too; otherwise we skip the cost.
        let mode_needs_key = matches!(salience_mode, Some(m) if m != "none");
        let effective_salience = if mode_needs_key && n_tokens > 0 && dim > 0 {
            let row_refs: Vec<&[f32]> =
                (0..n_tokens).map(|t| &flat[t * dim..(t + 1) * dim]).collect();
            let encoded = encode_per_token_keys(&row_refs);
            resolve_salience(salience, salience_mode, &encoded)?
        } else {
            salience
        };

        let layers: Vec<KVLayerPayload> = layer_payloads
            .iter()
            .map(|(idx, data)| {
                Ok(KVLayerPayload {
                    layer_idx: *idx,
                    data: data
                        .as_slice()
                        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
                        .to_vec(),
                })
            })
            .collect::<PyResult<Vec<_>>>()?;

        let engine = Arc::clone(&self.inner);
        py.detach(move || {
            lock_engine(&engine)?
                .mem_write_pack_tokens(
                    owner,
                    &flat,
                    n_tokens,
                    dim,
                    layers,
                    effective_salience,
                    text,
                )
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    /// Store a complete multi-layer KV cache as a single atomic pack.
    ///
    /// Returns the assigned pack ID.
    #[pyo3(signature = (owner, retrieval_key, layer_payloads, salience, text=None, salience_mode=None))]
    fn mem_write_pack(
        &self,
        py: Python<'_>,
        owner: u64,
        retrieval_key: PyReadonlyArray1<'_, f32>,
        layer_payloads: Vec<(u16, PyReadonlyArray1<'_, f32>)>,
        salience: f32,
        text: Option<String>,
        salience_mode: Option<&str>,
    ) -> PyResult<u64> {
        use tdb_core::kv_pack::{KVLayerPayload, KVPack};

        let key =
            retrieval_key.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?.to_vec();

        let effective_salience = resolve_salience(salience, salience_mode, &key)?;

        let layers: Vec<KVLayerPayload> = layer_payloads
            .iter()
            .map(|(idx, data)| {
                Ok(KVLayerPayload {
                    layer_idx: *idx,
                    data: data
                        .as_slice()
                        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
                        .to_vec(),
                })
            })
            .collect::<PyResult<Vec<_>>>()?;

        let pack =
            KVPack { id: 0, owner, retrieval_key: key, layers, salience: effective_salience, text };

        let engine = Arc::clone(&self.inner);
        py.detach(move || {
            lock_engine(&engine)?
                .mem_write_pack(&pack)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    /// Register one or more view keys for an existing pack.
    ///
    /// View keys are additional retrieval keys — queries matching any view key
    /// will surface this pack during `mem_read_pack`. Returns the total number
    /// of view keys registered for this pack after the call.
    #[pyo3(signature = (pack_id, view_keys))]
    fn add_view_keys(
        &self,
        py: Python<'_>,
        pack_id: u64,
        view_keys: Vec<PyReadonlyArray1<'_, f32>>,
    ) -> PyResult<usize> {
        let keys: Vec<Vec<f32>> =
            view_keys.iter().map(|k| k.as_slice().map(|s| s.to_vec())).collect::<Result<_, _>>()?;
        let engine = Arc::clone(&self.inner);
        py.detach(move || {
            lock_engine(&engine)?
                .add_view_keys(pack_id, &keys)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })
    }

    /// Return the number of view keys registered for a pack.
    ///
    /// Raises `RuntimeError` if the pack does not exist.
    fn view_count(&self, pack_id: u64) -> PyResult<usize> {
        lock_engine(&self.inner)?
            .view_count(pack_id)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Store a pack with automatic discovery and linking of similar existing packs.
    ///
    /// Returns a dict with `pack_id` and `linked_pack_ids`.
    /// Threshold defaults to [`DEFAULT_AUTO_LINK_THRESHOLD`] (250.0) when omitted.
    #[pyo3(signature = (owner, retrieval_key, layer_payloads, salience, auto_link_threshold=None, text=None))]
    fn mem_write_pack_with_auto_link(
        &self,
        py: Python<'_>,
        owner: u64,
        retrieval_key: PyReadonlyArray1<'_, f32>,
        layer_payloads: Vec<(u16, PyReadonlyArray1<'_, f32>)>,
        salience: f32,
        auto_link_threshold: Option<f32>,
        text: Option<String>,
    ) -> PyResult<pyo3::Py<pyo3::PyAny>> {
        use tdb_core::kv_pack::{KVLayerPayload, KVPack};
        use tdb_engine::engine::DEFAULT_AUTO_LINK_THRESHOLD;

        let threshold = auto_link_threshold.unwrap_or(DEFAULT_AUTO_LINK_THRESHOLD);

        let key =
            retrieval_key.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?.to_vec();

        let layers: Vec<KVLayerPayload> = layer_payloads
            .iter()
            .map(|(idx, data)| {
                Ok(KVLayerPayload {
                    layer_idx: *idx,
                    data: data
                        .as_slice()
                        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
                        .to_vec(),
                })
            })
            .collect::<PyResult<Vec<_>>>()?;

        let pack = KVPack { id: 0, owner, retrieval_key: key, layers, salience, text };

        let engine = Arc::clone(&self.inner);
        let result = py.detach(move || {
            lock_engine(&engine)?
                .mem_write_pack_with_auto_link(&pack, threshold)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })?;

        let dict = pyo3::types::PyDict::new(py);
        dict.set_item("pack_id", result.pack_id)?;
        dict.set_item("linked_pack_ids", &result.linked_pack_ids)?;
        Ok(dict.into())
    }

    /// Retrieve the top-k KV Packs matching a query key.
    ///
    /// Returns list of dicts with pack ID, owner, score, tier, and layers.
    fn mem_read_pack(
        &self,
        py: Python<'_>,
        query_key: PyReadonlyArray1<'_, f32>,
        k: usize,
        owner: Option<u64>,
    ) -> PyResult<Vec<pyo3::Py<pyo3::PyAny>>> {
        let query_vec =
            query_key.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?.to_vec();

        let engine = Arc::clone(&self.inner);
        let results = py.detach(move || {
            lock_engine(&engine)?
                .mem_read_pack(&query_vec, k, owner)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })?;

        let mut py_results = Vec::with_capacity(results.len());
        for r in results {
            let dict = pyo3::types::PyDict::new(py);
            dict.set_item("pack_id", r.pack.id)?;
            dict.set_item("owner", r.pack.owner)?;
            dict.set_item("score", r.score)?;
            dict.set_item("tier", r.tier as u8)?;

            let layers_list = pyo3::types::PyList::empty(py);
            for layer in &r.pack.layers {
                let layer_dict = pyo3::types::PyDict::new(py);
                layer_dict.set_item("layer_idx", layer.layer_idx)?;
                let data_arr = numpy::PyArray1::from_slice(py, &layer.data);
                layer_dict.set_item("data", data_arr)?;
                layers_list.append(layer_dict)?;
            }
            dict.set_item("layers", layers_list)?;
            dict.set_item("text", r.pack.text.as_deref())?;

            py_results.push(dict.into_any().unbind());
        }

        Ok(py_results)
    }

    /// Batch read: run N retrievals in one `PyO3` crossing.
    ///
    /// `queries` is a list of 1-D float32 ndarrays; the call returns a
    /// `list[list[dict]]` aligned by input position. `k` and `owner`
    /// each accept a scalar (broadcast across all queries) or a list of
    /// length `len(queries)` for per-query specialisation. `owner` list
    /// entries may be `None` to skip the filter for that one query.
    ///
    /// Behaviour is identical to calling [`Engine::mem_read_pack`] N
    /// times — this method exists to amortise `PyO3` crossing cost and
    /// to give consumers a single point of entry for multi-agent /
    /// multi-NPC fanout queries.
    fn mem_read_pack_batch(
        &self,
        py: Python<'_>,
        queries: Vec<PyReadonlyArray1<'_, f32>>,
        k: Bound<'_, pyo3::PyAny>,
        owner: Bound<'_, pyo3::PyAny>,
    ) -> PyResult<Vec<Vec<pyo3::Py<pyo3::PyAny>>>> {
        use pyo3::exceptions::PyValueError;
        let n = queries.len();
        if n == 0 {
            return Ok(Vec::new());
        }

        // Resolve k: scalar broadcast or per-query list.
        let ks: Vec<usize> = if let Ok(scalar) = k.extract::<usize>() {
            vec![scalar; n]
        } else {
            let list = k
                .extract::<Vec<usize>>()
                .map_err(|_| PyValueError::new_err("k must be an int or a list[int]"))?;
            if list.len() != n {
                return Err(PyValueError::new_err(format!(
                    "k list length {} does not match queries length {n}",
                    list.len()
                )));
            }
            list
        };

        // Resolve owner: scalar (int or None) broadcast or per-query list.
        let owners: Vec<Option<u64>> = if owner.is_none() {
            vec![None; n]
        } else if let Ok(scalar) = owner.extract::<u64>() {
            vec![Some(scalar); n]
        } else {
            let list = owner.extract::<Vec<Option<u64>>>().map_err(|_| {
                PyValueError::new_err("owner must be int | None | list[int | None]")
            })?;
            if list.len() != n {
                return Err(PyValueError::new_err(format!(
                    "owner list length {} does not match queries length {n}",
                    list.len()
                )));
            }
            list
        };

        // Materialise each query as an owned Vec<f32> for the GIL-released loop.
        let owned_queries: Vec<Vec<f32>> = queries
            .iter()
            .map(|q| {
                q.as_slice()
                    .map(<[f32]>::to_vec)
                    .unwrap_or_else(|_| q.as_array().iter().copied().collect())
            })
            .collect();

        let engine = Arc::clone(&self.inner);
        let raw_results =
            py.detach(move || -> PyResult<Vec<Vec<tdb_core::kv_pack::PackReadResult>>> {
                let mut eng = lock_engine(&engine)?;
                let mut out = Vec::with_capacity(n);
                for ((q, k), owner) in owned_queries.iter().zip(ks.iter()).zip(owners.iter()) {
                    let rows = eng
                        .mem_read_pack(q, *k, *owner)
                        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
                    out.push(rows);
                }
                Ok(out)
            })?;

        let mut py_results = Vec::with_capacity(n);
        for rows in raw_results {
            let mut py_rows = Vec::with_capacity(rows.len());
            for r in rows {
                let dict = pyo3::types::PyDict::new(py);
                dict.set_item("pack_id", r.pack.id)?;
                dict.set_item("owner", r.pack.owner)?;
                dict.set_item("score", r.score)?;
                dict.set_item("tier", r.tier as u8)?;

                let layers_list = pyo3::types::PyList::empty(py);
                for layer in &r.pack.layers {
                    let layer_dict = pyo3::types::PyDict::new(py);
                    layer_dict.set_item("layer_idx", layer.layer_idx)?;
                    let data_arr = numpy::PyArray1::from_slice(py, &layer.data);
                    layer_dict.set_item("data", data_arr)?;
                    layers_list.append(layer_dict)?;
                }
                dict.set_item("layers", layers_list)?;
                dict.set_item("text", r.pack.text.as_deref())?;
                py_rows.push(dict.into_any().unbind());
            }
            py_results.push(py_rows);
        }

        Ok(py_results)
    }

    /// Multi-layer query fusion via Reciprocal Rank Fusion.
    ///
    /// One engine call hides the N-query fanout + RRF merge that the
    /// Python `multi_layer_query` helper previously implemented in
    /// `tardigrade_hooks`. Each query key typically comes from a
    /// different transformer layer's hidden state; the engine fetches
    /// `k * 2` candidates per layer and fuses them.
    #[pyo3(signature = (query_keys, k, owner=None, rrf_k=60))]
    fn mem_read_multi_layer(
        &self,
        py: Python<'_>,
        query_keys: Vec<PyReadonlyArray1<'_, f32>>,
        k: usize,
        owner: Option<u64>,
        rrf_k: u32,
    ) -> PyResult<Vec<pyo3::Py<pyo3::PyAny>>> {
        if query_keys.is_empty() {
            return Ok(Vec::new());
        }

        let owned_queries: Vec<Vec<f32>> = query_keys
            .iter()
            .map(|q| {
                q.as_slice()
                    .map(<[f32]>::to_vec)
                    .unwrap_or_else(|_| q.as_array().iter().copied().collect())
            })
            .collect();

        let engine = Arc::clone(&self.inner);
        let raw = py.detach(move || -> PyResult<Vec<tdb_engine::engine::MultiLayerRow>> {
            let mut eng = lock_engine(&engine)?;
            eng.mem_read_multi_layer(&owned_queries, k, rrf_k, owner)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })?;

        let mut py_rows = Vec::with_capacity(raw.len());
        for row in raw {
            let r = &row.pack_read;
            let dict = pyo3::types::PyDict::new(py);
            dict.set_item("pack_id", r.pack.id)?;
            dict.set_item("owner", r.pack.owner)?;
            dict.set_item("score", r.score)?;
            dict.set_item("rrf_score", row.rrf_score)?;
            dict.set_item("tier", r.tier as u8)?;

            let layers_list = pyo3::types::PyList::empty(py);
            for layer in &r.pack.layers {
                let layer_dict = pyo3::types::PyDict::new(py);
                layer_dict.set_item("layer_idx", layer.layer_idx)?;
                let data_arr = numpy::PyArray1::from_slice(py, &layer.data);
                layer_dict.set_item("data", data_arr)?;
                layers_list.append(layer_dict)?;
            }
            dict.set_item("layers", layers_list)?;
            dict.set_item("text", r.pack.text.as_deref())?;
            py_rows.push(dict.into_any().unbind());
        }
        Ok(py_rows)
    }

    /// Number of KV Packs stored.
    fn pack_count(&self) -> PyResult<usize> {
        Ok(lock_engine(&self.inner)?.pack_count())
    }

    /// Re-sync in-memory state from disk.
    ///
    /// Use when another process or `Engine` handle has written to the same
    /// directory and this handle needs to see those writes. Re-applies the
    /// Memento pattern from `open()`: rescans segments, replays the WAL,
    /// refreshes governance / `pack_directory` / `text_store` / `deletion_log`.
    /// Idempotent and cheap when nothing changed on disk.
    fn refresh(&self) -> PyResult<()> {
        lock_engine(&self.inner)?.refresh().map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Get the importance score of a pack.
    fn pack_importance(&self, pack_id: u64) -> PyResult<Option<f32>> {
        Ok(lock_engine(&self.inner)?.pack_importance(pack_id))
    }

    /// Enumerate pack metadata (no text) as a struct-of-arrays.
    ///
    /// Returns a dict of four parallel numpy arrays, all of length N:
    /// * `pack_ids`   — `np.uint64[N]`
    /// * `owners`     — `np.uint64[N]`
    /// * `tiers`      — `np.uint8[N]`  (0=Draft, 1=Validated, 2=Core)
    /// * `importances`— `np.float32[N]`
    ///
    /// Rows are aligned by index and sorted by importance descending.
    ///
    /// The columnar shape lets the call answer from `PackDirectory`'s
    /// in-memory indices via a single Rust→Python crossing, with no per-row
    /// Python dict allocation. Use [`Engine::list_packs`] with
    /// `fetch_text=True` when you need text alongside the metadata.
    #[pyo3(signature = (owner=None))]
    fn list_packs_metadata(
        &self,
        py: Python<'_>,
        owner: Option<u64>,
    ) -> PyResult<pyo3::Py<pyo3::PyAny>> {
        let eng = lock_engine(&self.inner)?;
        let packs = eng.list_packs(owner);

        let n = packs.len();
        let mut pack_ids = Vec::<u64>::with_capacity(n);
        let mut owners = Vec::<u64>::with_capacity(n);
        let mut tiers = Vec::<u8>::with_capacity(n);
        let mut importances = Vec::<f32>::with_capacity(n);
        for (pack_id, pack_owner, tier, importance) in packs {
            pack_ids.push(pack_id);
            owners.push(pack_owner);
            tiers.push(tier as u8);
            importances.push(importance);
        }

        let dict = pyo3::types::PyDict::new(py);
        dict.set_item("pack_ids", numpy::PyArray1::from_slice(py, &pack_ids))?;
        dict.set_item("owners", numpy::PyArray1::from_slice(py, &owners))?;
        dict.set_item("tiers", numpy::PyArray1::from_slice(py, &tiers))?;
        dict.set_item("importances", numpy::PyArray1::from_slice(py, &importances))?;
        Ok(dict.into_any().unbind())
    }

    /// Load the model's token-embedding table into the engine.
    ///
    /// `weights` is a `(vocab_size, hidden_size)` float32 ndarray. The
    /// engine takes a flat owned copy so the call is safe even if the
    /// caller drops or mutates `weights` afterwards. Repeated calls
    /// replace the previous table; the load counter is incremented.
    fn load_embedding_table(&self, weights: PyReadonlyArray2<'_, f32>) -> PyResult<()> {
        let arr = weights.as_array();
        let shape = arr.shape();
        let vocab_size = shape[0];
        let hidden_size = shape[1];
        let flat: Vec<f32> = if let Some(slice) = arr.as_slice() {
            slice.to_vec()
        } else {
            arr.iter().copied().collect()
        };
        let mut eng = lock_engine(&self.inner)?;
        eng.load_embedding_table(flat, vocab_size, hidden_size);
        Ok(())
    }

    /// Number of `load_embedding_table` calls (observability counter).
    fn embedding_table_load_count(&self) -> PyResult<u64> {
        Ok(lock_engine(&self.inner)?.embedding_table_load_count())
    }

    /// Install a projection matrix for the `"projected"` strategy.
    ///
    /// `matrix` is a `(kv_dim, hidden_size)` float32 ndarray.
    fn set_projection_matrix(&self, matrix: PyReadonlyArray2<'_, f32>) -> PyResult<()> {
        let arr = matrix.as_array();
        let shape = arr.shape();
        let kv_dim = shape[0];
        let hidden_size = shape[1];
        let flat: Vec<f32> = if let Some(slice) = arr.as_slice() {
            slice.to_vec()
        } else {
            arr.iter().copied().collect()
        };
        let mut eng = lock_engine(&self.inner)?;
        eng.set_projection_matrix(flat, kv_dim, hidden_size);
        Ok(())
    }

    /// Compute a retrieval key from `token_ids` via the named strategy.
    ///
    /// Returns the key as a 1-D float32 ndarray, or `None` when the
    /// embedding table has not been loaded, when `token_ids` is empty,
    /// or when every id is out of vocabulary range. Raises
    /// `ValueError` when `strategy` is not one of `"last_token"`,
    /// `"mean_pool"`, `"projected"`.
    #[pyo3(signature = (token_ids, strategy="last_token"))]
    fn compute_retrieval_key(
        &self,
        py: Python<'_>,
        token_ids: Vec<i64>,
        strategy: &str,
    ) -> PyResult<Option<pyo3::Py<pyo3::PyAny>>> {
        use pyo3::exceptions::PyValueError;
        let eng = lock_engine(&self.inner)?;
        let key = eng
            .compute_retrieval_key(&token_ids, strategy)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(key.map(|v| numpy::PyArray1::from_vec(py, v).into_any().unbind()))
    }

    /// Configure (or resize) the engine-side fingerprint LRU cache.
    ///
    /// `capacity` matches the vLLM scheduler's `max_num_seqs` in
    /// practice — keeps the cache exactly large enough to hold every
    /// concurrently in-flight request and no larger, so a finished
    /// request's fingerprint cannot survive into a new request that
    /// reuses the same block id.
    fn set_fingerprint_capacity(&self, capacity: usize) -> PyResult<()> {
        lock_engine(&self.inner)?.set_fingerprint_capacity(capacity);
        Ok(())
    }

    /// Lookup the pack id last written for this fingerprint.
    /// Returns `None` when absent or when the cache has not been
    /// sized yet via [`Engine::set_fingerprint_capacity`].
    fn fingerprint_get(&self, fingerprint: u64) -> PyResult<Option<u64>> {
        Ok(lock_engine(&self.inner)?.fingerprint_get(fingerprint))
    }

    /// Store `pack_id` for this fingerprint, evicting the LRU entry
    /// when the cache is full.
    fn fingerprint_put(&self, fingerprint: u64, pack_id: u64) -> PyResult<()> {
        lock_engine(&self.inner)?.fingerprint_put(fingerprint, pack_id);
        Ok(())
    }

    /// Drop the entry for this fingerprint (no-op when absent).
    /// Call from the connector's `request_finished` lifecycle hook.
    fn fingerprint_release(&self, fingerprint: u64) -> PyResult<()> {
        lock_engine(&self.inner)?.fingerprint_release(fingerprint);
        Ok(())
    }

    /// Current number of fingerprint entries (observability hook).
    fn fingerprint_len(&self) -> PyResult<usize> {
        Ok(lock_engine(&self.inner)?.fingerprint_len())
    }

    /// Enumerate all packs as a list of dicts, with text included.
    ///
    /// Returns a list of dicts with keys: `pack_id`, `owner`, `tier`, `importance`, `text`.
    /// Sorted by importance descending.
    ///
    /// **Performance note:** this shape allocates one Python dict per pack, which
    /// dominates wall time at scale. When you don't need text, prefer
    /// [`Engine::list_packs_metadata`] — it returns parallel numpy arrays from a
    /// single Rust→Python crossing.
    ///
    /// `fetch_text` is a required keyword argument. Pass `True` to populate
    /// the `text` field via a per-pack lookup. Pass `False` to skip the
    /// lookup and emit `None` for every `text` entry — useful when only
    /// metadata is needed but the list-of-dicts shape is still convenient.
    /// For pure metadata enumeration prefer [`Engine::list_packs_metadata`].
    #[pyo3(signature = (owner=None, *, fetch_text))]
    fn list_packs(
        &self,
        py: Python<'_>,
        owner: Option<u64>,
        fetch_text: bool,
    ) -> PyResult<pyo3::Py<pyo3::PyAny>> {
        let eng = lock_engine(&self.inner)?;
        let packs = eng.list_packs(owner);
        let py_list = pyo3::types::PyList::empty(py);
        for (pack_id, pack_owner, tier, importance) in packs {
            let dict = pyo3::types::PyDict::new(py);
            dict.set_item("pack_id", pack_id)?;
            dict.set_item("owner", pack_owner)?;
            dict.set_item("tier", tier as u8)?;
            dict.set_item("importance", importance)?;
            let text = if fetch_text { eng.pack_text(pack_id) } else { None };
            dict.set_item("text", text)?;
            py_list.append(dict)?;
        }
        Ok(py_list.into_any().unbind())
    }

    /// Load a pack by ID without retrieval scoring.
    fn load_pack_by_id(&self, py: Python<'_>, pack_id: u64) -> PyResult<pyo3::Py<pyo3::PyAny>> {
        let engine = Arc::clone(&self.inner);
        let result = py.detach(move || {
            lock_engine(&engine)?
                .load_pack_by_id(pack_id)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })?;

        let layers_list = pyo3::types::PyList::empty(py);
        for layer in &result.pack.layers {
            let layer_dict = pyo3::types::PyDict::new(py);
            layer_dict.set_item("layer_idx", layer.layer_idx)?;
            let data_array = numpy::PyArray1::from_slice(py, &layer.data).into_any().unbind();
            layer_dict.set_item("data", data_array)?;
            layers_list.append(layer_dict)?;
        }

        let dict = pyo3::types::PyDict::new(py);
        dict.set_item("pack_id", result.pack.id)?;
        dict.set_item("owner", result.pack.owner)?;
        dict.set_item("score", result.score)?;
        dict.set_item("tier", result.tier as u8)?;
        dict.set_item("layers", layers_list)?;
        dict.set_item("text", result.pack.text.as_deref())?;
        Ok(dict.into_any().unbind())
    }

    /// Create a durable typed trace edge between two packs.
    ///
    /// `edge_type`: 0=CausedBy, 1=Follows, 2=Contradicts, 3=Supports.
    fn add_pack_edge(&self, pack_id_1: u64, pack_id_2: u64, edge_type: u8) -> PyResult<()> {
        use tdb_engine::EdgeType;
        let et = EdgeType::from_u8(edge_type).ok_or_else(|| {
            PyRuntimeError::new_err(format!(
                "Invalid edge_type {edge_type}. Valid: 0=CausedBy, 1=Follows, 2=Contradicts, 3=Supports"
            ))
        })?;
        lock_engine(&self.inner)?
            .add_pack_edge(pack_id_1, pack_id_2, et)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Create a durable Follows link between two packs.
    fn add_pack_link(&self, pack_id_1: u64, pack_id_2: u64) -> PyResult<()> {
        lock_engine(&self.inner)?
            .add_pack_link(pack_id_1, pack_id_2)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Get all packs linked to a given pack via trace edges (any type).
    fn pack_links(&self, pack_id: u64) -> PyResult<Vec<u64>> {
        Ok(lock_engine(&self.inner)?.pack_links(pack_id))
    }

    /// Get packs linked via a specific edge type.
    fn pack_links_by_type(&self, pack_id: u64, edge_type: u8) -> PyResult<Vec<u64>> {
        use tdb_engine::EdgeType;
        let et = EdgeType::from_u8(edge_type)
            .ok_or_else(|| PyRuntimeError::new_err(format!("Invalid edge_type {edge_type}")))?;
        Ok(lock_engine(&self.inner)?.pack_links_by_type(pack_id, et))
    }

    /// Get packs that support a given pack.
    fn pack_supports(&self, pack_id: u64) -> PyResult<Vec<u64>> {
        Ok(lock_engine(&self.inner)?.pack_supports(pack_id))
    }

    /// Get packs that contradict a given pack.
    fn pack_contradicts(&self, pack_id: u64) -> PyResult<Vec<u64>> {
        Ok(lock_engine(&self.inner)?.pack_contradicts(pack_id))
    }

    /// Retrieve packs with trace-boosted scoring.
    fn mem_read_pack_with_trace_boost(
        &self,
        py: Python<'_>,
        query_key: PyReadonlyArray1<'_, f32>,
        k: usize,
        owner: Option<u64>,
        boost_factor: f32,
    ) -> PyResult<Vec<pyo3::Py<pyo3::PyAny>>> {
        let query_vec =
            query_key.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?.to_vec();

        let engine = Arc::clone(&self.inner);
        let results = py.detach(move || {
            lock_engine(&engine)?
                .mem_read_pack_with_trace_boost(&query_vec, k, owner, boost_factor)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })?;

        let mut py_results = Vec::with_capacity(results.len());
        for r in results {
            let layers_list = pyo3::types::PyList::empty(py);
            for layer in &r.pack.layers {
                let layer_dict = pyo3::types::PyDict::new(py);
                layer_dict.set_item("layer_idx", layer.layer_idx)?;
                let data_array = numpy::PyArray1::from_slice(py, &layer.data).into_any().unbind();
                layer_dict.set_item("data", data_array)?;
                layers_list.append(layer_dict)?;
            }

            let dict = pyo3::types::PyDict::new(py);
            dict.set_item("pack_id", r.pack.id)?;
            dict.set_item("owner", r.pack.owner)?;
            dict.set_item("score", r.score)?;
            dict.set_item("tier", r.tier as u8)?;
            dict.set_item("layers", layers_list)?;
            dict.set_item("text", r.pack.text.as_deref())?;
            py_results.push(dict.into_any().unbind());
        }
        Ok(py_results)
    }

    /// Retrieve packs with trace-boosted scoring and automatic link traversal.
    fn mem_read_pack_with_trace_boost_and_follow(
        &self,
        py: Python<'_>,
        query_key: PyReadonlyArray1<'_, f32>,
        k: usize,
        owner: Option<u64>,
        boost_factor: f32,
    ) -> PyResult<Vec<pyo3::Py<pyo3::PyAny>>> {
        let query_vec =
            query_key.as_slice().map_err(|e| PyRuntimeError::new_err(e.to_string()))?.to_vec();

        let engine = Arc::clone(&self.inner);
        let results = py.detach(move || {
            lock_engine(&engine)?
                .mem_read_pack_with_trace_boost_and_follow(&query_vec, k, owner, boost_factor)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))
        })?;

        let mut py_results = Vec::with_capacity(results.len());
        for r in results {
            let layers_list = pyo3::types::PyList::empty(py);
            for layer in &r.pack.layers {
                let layer_dict = pyo3::types::PyDict::new(py);
                layer_dict.set_item("layer_idx", layer.layer_idx)?;
                let data_array = numpy::PyArray1::from_slice(py, &layer.data).into_any().unbind();
                layer_dict.set_item("data", data_array)?;
                layers_list.append(layer_dict)?;
            }

            let dict = pyo3::types::PyDict::new(py);
            dict.set_item("pack_id", r.pack.id)?;
            dict.set_item("owner", r.pack.owner)?;
            dict.set_item("score", r.score)?;
            dict.set_item("tier", r.tier as u8)?;
            dict.set_item("layers", layers_list)?;
            dict.set_item("text", r.pack.text.as_deref())?;
            py_results.push(dict.into_any().unbind());
        }
        Ok(py_results)
    }

    /// Get the stored text for a pack, if any.
    fn pack_text(&self, pack_id: u64) -> PyResult<Option<String>> {
        Ok(lock_engine(&self.inner)?.pack_text(pack_id).map(str::to_owned))
    }

    /// Set or update the stored text for an existing pack.
    fn set_pack_text(&self, pack_id: u64, text: &str) -> PyResult<()> {
        lock_engine(&self.inner)?
            .set_pack_text(pack_id, text)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Set or update text for many packs in a single batched fsync.
    fn set_pack_texts(&self, entries: Vec<(u64, String)>) -> PyResult<()> {
        let borrowed: Vec<(u64, &str)> = entries.iter().map(|(id, t)| (*id, t.as_str())).collect();
        lock_engine(&self.inner)?
            .set_pack_texts(&borrowed)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Whether a pack with the given ID exists (and has not been deleted).
    fn pack_exists(&self, pack_id: u64) -> PyResult<bool> {
        Ok(lock_engine(&self.inner)?.pack_exists(pack_id))
    }

    /// Delete a pack permanently. Irreversible.
    fn delete_pack(&self, pack_id: u64) -> PyResult<()> {
        lock_engine(&self.inner)?
            .delete_pack(pack_id)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    /// Explicit durability checkpoint — ensures all components have fsynced.
    fn flush(&self) -> PyResult<()> {
        lock_engine(&self.inner)?.flush().map_err(|e| PyRuntimeError::new_err(e.to_string()))
    }

    fn __repr__(&self) -> PyResult<String> {
        let eng = lock_engine(&self.inner)?;
        Ok(format!("Engine(path='{}', cells={})", eng.dir().display(), eng.cell_count()))
    }
}

/// Labeled checkpoint repository.
///
/// Wraps `tdb_engine::checkpoint::CheckpointRepository` so consumers
/// can save engine snapshots under string labels with a
/// monotonically increasing sequence per label, list / find latest,
/// and restore the latest into a fresh directory.
#[pyclass]
struct CheckpointRepository {
    inner: tdb_engine::checkpoint::CheckpointRepository,
}

fn entry_to_dict(
    py: Python<'_>,
    entry: &tdb_engine::checkpoint::CheckpointEntry,
) -> PyResult<pyo3::Py<pyo3::PyAny>> {
    let dict = pyo3::types::PyDict::new(py);
    dict.set_item("label", &entry.label)?;
    dict.set_item("seq", entry.seq)?;
    dict.set_item("path", entry.path.display().to_string())?;
    let manifest_dict = pyo3::types::PyDict::new(py);
    manifest_dict.set_item("magic", &entry.manifest.magic)?;
    manifest_dict.set_item("format_version", entry.manifest.format_version)?;
    manifest_dict.set_item("created_at", &entry.manifest.created_at)?;
    manifest_dict.set_item("pack_count", entry.manifest.stats.pack_count)?;
    manifest_dict.set_item("owner_count", entry.manifest.stats.owner_count)?;
    manifest_dict.set_item("sha256", &entry.manifest.sha256)?;
    manifest_dict.set_item("quantization_codec", &entry.manifest.codecs.quantization)?;
    manifest_dict.set_item("key_codec", &entry.manifest.codecs.key)?;
    dict.set_item("manifest", manifest_dict)?;
    Ok(dict.into())
}

#[pymethods]
impl CheckpointRepository {
    /// Open a repository rooted at ``root`` (created lazily).
    #[new]
    fn new(root: &str) -> Self {
        Self {
            inner: tdb_engine::checkpoint::CheckpointRepository::new(std::path::PathBuf::from(
                root,
            )),
        }
    }

    /// Save ``engine``'s current state under ``label``. Returns a
    /// dict with ``label``, ``seq``, ``path``, and ``manifest``.
    fn save(
        &self,
        py: Python<'_>,
        engine: &Engine,
        label: &str,
    ) -> PyResult<pyo3::Py<pyo3::PyAny>> {
        let entry = {
            let mut eng = lock_engine(&engine.inner)?;
            self.inner
                .save_from(&mut eng, label)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
        };
        entry_to_dict(py, &entry)
    }

    /// Return all checkpoints, optionally filtered by ``label``.
    #[pyo3(signature = (label=None))]
    fn list(&self, py: Python<'_>, label: Option<&str>) -> PyResult<Vec<pyo3::Py<pyo3::PyAny>>> {
        let entries = self.inner.list(label).map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        entries.iter().map(|e| entry_to_dict(py, e)).collect()
    }

    /// Latest checkpoint for ``label`` or ``None`` if none exist.
    fn latest(&self, py: Python<'_>, label: &str) -> PyResult<Option<pyo3::Py<pyo3::PyAny>>> {
        match self.inner.latest(label).map_err(|e| PyRuntimeError::new_err(e.to_string()))? {
            Some(entry) => Ok(Some(entry_to_dict(py, &entry)?)),
            None => Ok(None),
        }
    }

    /// Restore the latest checkpoint for ``label`` into ``target_dir``.
    fn restore_latest(&self, label: &str, target_dir: &str) -> PyResult<Engine> {
        let engine = self
            .inner
            .restore_latest(label, std::path::Path::new(target_dir))
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(Engine {
            inner: std::sync::Arc::new(std::sync::Mutex::new(engine)),
            maintenance_worker: None,
        })
    }
}

/// `TardigradeDB` — LLM-native database kernel for persistent KV cache memory.
#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;
    m.add_class::<Engine>()?;
    m.add_class::<ReadResult>()?;
    m.add_class::<CheckpointRepository>()?;

    m.add("ENCODING_HEADER_SIZE", tdb_engine::encoding::HEADER_SIZE)?;
    m.add("ENCODING_SENTINEL", tdb_engine::encoding::HEADER_SENTINEL)?;
    m.add("ENCODING_N_TOKENS_IDX", tdb_engine::encoding::N_TOKENS_IDX)?;
    m.add("ENCODING_DIM_IDX", tdb_engine::encoding::DIM_IDX)?;

    m.add("SALIENCE_SCALE", tdb_core::salience::SALIENCE_SCALE)?;
    m.add("SALIENCE_CAP", tdb_core::salience::SALIENCE_CAP)?;

    m.add_function(wrap_pyfunction!(find_chunk_boundary, m)?)?;
    m.add_function(wrap_pyfunction!(flat_to_paged, m)?)?;
    m.add_function(wrap_pyfunction!(paged_to_flat, m)?)?;
    m.add_function(wrap_pyfunction!(flat_to_paged_torch, m)?)?;

    Ok(())
}

/// Torch-tensor variant of [`flat_to_paged`]. Reads the tensor's raw
/// buffer via `data_ptr()` directly — no numpy intermediary, no
/// libtorch link, no `tch-rs` dependency. The consumer's installed
/// torch handles all the C++ side; Rust just reads the memory.
///
/// Requires the tensor to be a contiguous CPU float32 buffer. CUDA
/// tensors, non-contiguous views, and non-f32 dtypes get rejected
/// with a clear error — converting them is a Python-side responsibility
/// (`tensor.cpu().contiguous().to(torch.float32)`).
#[pyfunction]
fn flat_to_paged_torch(
    py: Python<'_>,
    flat_kv: Bound<'_, pyo3::PyAny>,
    num_kv_heads: usize,
    head_dim: usize,
    block_size: usize,
) -> PyResult<(pyo3::Py<pyo3::PyAny>, pyo3::Py<pyo3::PyAny>)> {
    use pyo3::exceptions::PyValueError;

    // Detach from autograd graph before any data access — a grad-tracking
    // tensor's data_ptr() still works but we don't want a stray view
    // into the engine's write path keeping the autograd graph alive.
    let tensor = flat_kv.call_method0("detach")?;

    // Device check: must be on cpu. torch tensors expose `device.type`
    // ("cpu", "cuda", "mps", ...). Anything other than "cpu" needs to
    // round-trip through .cpu() on the Python side.
    let device_type: String = tensor.getattr("device")?.getattr("type")?.extract()?;
    if device_type != "cpu" {
        return Err(PyValueError::new_err(format!(
            "flat_to_paged_torch requires a cpu tensor; got device='{device_type}'. \
             Call tensor.cpu() before passing it in."
        )));
    }

    // Dtype check: must be float32. We compare against the torch.float32
    // singleton via repr() to avoid pulling in tch-rs just to inspect dtype.
    let dtype_repr: String = tensor.getattr("dtype")?.str()?.extract()?;
    if dtype_repr != "torch.float32" {
        return Err(PyValueError::new_err(format!(
            "flat_to_paged_torch requires float32; got dtype={dtype_repr}. \
             Call tensor.to(torch.float32) before passing it in."
        )));
    }

    // Contiguity check: non-contiguous views (transpose, stride != 1
    // slicing, etc.) have data_ptr pointing at a buffer that isn't the
    // flat row-major layout we'd read. Reject — don't silently corrupt.
    let is_contig: bool = tensor.call_method0("is_contiguous")?.extract()?;
    if !is_contig {
        return Err(PyValueError::new_err(
            "flat_to_paged_torch requires a contiguous tensor; \
             call tensor.contiguous() before passing it in.",
        ));
    }

    let numel: usize = tensor.call_method0("numel")?.extract()?;
    let data_ptr: usize = tensor.call_method0("data_ptr")?.extract()?;

    // SAFETY:
    // - `data_ptr` is the address of the tensor's contiguous f32
    //   storage. The dtype check above guarantees f32; the contiguity
    //   check guarantees the buffer is flat row-major; `numel` is the
    //   element count.
    // - The GIL is held for the entire scope of this function, so the
    //   torch tensor cannot be garbage-collected nor have its storage
    //   reallocated by another Python thread while we read.
    // - We only read; never write.
    let slice: &[f32] = unsafe { std::slice::from_raw_parts(data_ptr as *const f32, numel) };

    let (k, v) =
        tdb_engine::engine::Engine::flat_to_paged(slice, num_kv_heads, head_dim, block_size)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
    Ok((
        numpy::PyArray1::from_vec(py, k).into_any().unbind(),
        numpy::PyArray1::from_vec(py, v).into_any().unbind(),
    ))
}

/// Convert a flat `[K_flat | V_flat]` ndarray into vLLM paged blocks.
///
/// Returns `(k_blocks, v_blocks)` as 1-D float32 ndarrays of length
/// `num_blocks * block_size * num_kv_heads * head_dim`. Reshape in
/// Python with `.reshape(num_blocks, block_size, num_kv_heads, head_dim)`
/// to recover the four-axis layout. Stateless — does not touch the engine.
#[pyfunction]
fn flat_to_paged(
    py: Python<'_>,
    flat_kv: PyReadonlyArray1<'_, f32>,
    num_kv_heads: usize,
    head_dim: usize,
    block_size: usize,
) -> PyResult<(pyo3::Py<pyo3::PyAny>, pyo3::Py<pyo3::PyAny>)> {
    use pyo3::exceptions::PyValueError;
    let arr = flat_kv.as_array();
    let owned;
    let slice: &[f32] = if let Some(s) = arr.as_slice() {
        s
    } else {
        owned = arr.iter().copied().collect::<Vec<f32>>();
        &owned
    };
    let (k, v) =
        tdb_engine::engine::Engine::flat_to_paged(slice, num_kv_heads, head_dim, block_size)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
    Ok((
        numpy::PyArray1::from_vec(py, k).into_any().unbind(),
        numpy::PyArray1::from_vec(py, v).into_any().unbind(),
    ))
}

/// Convert vLLM paged K/V blocks back into a flat `[K_flat | V_flat]`
/// float32 ndarray. Stateless — does not touch the engine.
#[pyfunction]
fn paged_to_flat(
    py: Python<'_>,
    k_blocks: PyReadonlyArray1<'_, f32>,
    v_blocks: PyReadonlyArray1<'_, f32>,
    seq_len: usize,
    num_kv_heads: usize,
    head_dim: usize,
) -> PyResult<pyo3::Py<pyo3::PyAny>> {
    use pyo3::exceptions::PyValueError;
    let k = k_blocks.as_array();
    let v = v_blocks.as_array();
    let k_owned;
    let v_owned;
    let k_slice: &[f32] = if let Some(s) = k.as_slice() {
        s
    } else {
        k_owned = k.iter().copied().collect::<Vec<f32>>();
        &k_owned
    };
    let v_slice: &[f32] = if let Some(s) = v.as_slice() {
        s
    } else {
        v_owned = v.iter().copied().collect::<Vec<f32>>();
        &v_owned
    };
    let out = tdb_engine::engine::Engine::paged_to_flat(
        k_slice,
        v_slice,
        seq_len,
        num_kv_heads,
        head_dim,
    )
    .map_err(|e| PyValueError::new_err(e.to_string()))?;
    Ok(numpy::PyArray1::from_vec(py, out).into_any().unbind())
}

/// Find a byte position `<= max_pos` to split `text` at, preferring the
/// natural boundary indicated by `strategy`.
///
/// `strategy` is one of `"whitespace"`, `"sentence"`, or `"paragraph"`.
/// See `tdb_engine::chunk_boundary` for the precise semantics — this is
/// a direct `PyO3` surface over the Rust function.
#[pyfunction]
fn find_chunk_boundary(text: &str, max_pos: usize, strategy: &str) -> PyResult<usize> {
    use tdb_engine::chunk_boundary::{BoundaryStrategy, find_chunk_boundary as inner};
    let parsed = BoundaryStrategy::parse(strategy)
        .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
    Ok(inner(text, max_pos, parsed))
}
