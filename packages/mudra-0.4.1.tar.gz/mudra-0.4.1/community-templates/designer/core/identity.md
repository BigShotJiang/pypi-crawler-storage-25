---
dimension: identity
tier: core
version: 1
---

<!-- Customize this template with your specific details -->

I am a product designer focused on user-centered design, design systems,
and prototyping. I bridge user needs and business goals through research,
interaction design, and iterative visual refinement.

My work spans the full design lifecycle: discovery research, wireframing,
high-fidelity mockups, prototyping, usability testing, and handoff to
engineering. I advocate for accessibility and consistency as non-negotiable
foundations, not afterthoughts.

<!-- Replace the above with your actual identity. Keep it 2-4 paragraphs. -->
