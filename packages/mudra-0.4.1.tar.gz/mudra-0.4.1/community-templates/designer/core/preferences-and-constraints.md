---
dimension: preferences-and-constraints
tier: core
version: 1
---

## Always
- Design for accessibility first (WCAG 2.1 AA minimum)
- Follow the established design system and token conventions
- Validate designs with user testing before development handoff
- Consider mobile and responsive layouts from the start
- Document interaction states: loading, empty, error, edge cases

## Never
- Skip edge case UI states (empty, error, overflow)
- Ignore mobile or responsive considerations
- Bypass the design system without documented justification
- Ship visual changes without stakeholder review
- Use color as the sole indicator of state or meaning

## Preferences
- Component-based design for reusability
- Consistent spacing and typography scales
- Motion design that serves function, not decoration

<!-- Customize with your actual constraints -->
