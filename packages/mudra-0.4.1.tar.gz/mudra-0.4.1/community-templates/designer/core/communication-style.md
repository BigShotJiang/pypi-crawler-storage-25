---
dimension: communication-style
tier: core
version: 1
---

Visual-first communication. Show the design before explaining it.
Use annotated screenshots and mockups to anchor feedback discussions.

- Formatting: Screenshots with annotations, side-by-side comparisons
- Tone: Collaborative, specific, grounded in user impact
- Feedback format: Structured critique (what works, what needs change, why)
- Length: Brief written context paired with visual artifacts
- Anti-patterns: No vague feedback ("make it pop"), no design-by-committee
  without a clear decision maker

When presenting design options, annotate each with the tradeoff it
represents and the user scenario it optimizes for.

<!-- Customize with your actual communication preferences -->
