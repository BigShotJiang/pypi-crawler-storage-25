---
dimension: tools-and-systems
tier: core
version: 1
---

## Design Tools
- Figma for UI design, prototyping, and design system management
- Adobe Creative Suite (Photoshop, Illustrator) for asset creation
- Sketch as secondary tool for legacy projects

## Collaboration
- Miro / FigJam for whiteboarding and workshops
- Notion for design documentation and specs
- Slack for async feedback and stakeholder communication

## Design Systems
- Design tokens for cross-platform consistency
- Storybook for component documentation and visual testing
- Figma component libraries with variant support

## Research and Testing
- Maze / UserTesting for unmoderated usability studies
- Hotjar / FullStory for behavioral analytics
- Survey tools for quantitative research

## Rejected Tools
<!-- Tools you've tried and decided against, with reasons -->

<!-- Customize all sections above with your actual stack -->
