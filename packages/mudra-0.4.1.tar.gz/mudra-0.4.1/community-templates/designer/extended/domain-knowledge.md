---
dimension: domain-knowledge
tier: extended
version: 1
---

## Expert Areas
- UI/UX patterns and interaction design
- Design systems architecture and governance
- Accessibility standards (WCAG 2.1, ARIA patterns)
- Responsive and adaptive layout strategies

## Working Knowledge
- User research methods (interviews, surveys, usability testing)
- Information architecture and navigation design
- Motion design and micro-interactions
- Design-to-development handoff workflows

## Learning Areas
- Design engineering (CSS, HTML prototyping)
- Data visualization and dashboard design
- Voice and conversational UI patterns

<!-- Customize with your actual expertise and growth areas -->
