---
dimension: domain-knowledge
tier: extended
version: 1
---

## Expert Areas
- Backend development, API design, system architecture
- Database design and query optimization
- CI/CD pipelines and deployment automation

## Working Knowledge
- Frontend frameworks (React, Vue)
- Container orchestration and infrastructure as code
- Observability: logging, metrics, tracing

## Learning Areas
- Machine learning fundamentals
- Distributed systems consensus protocols
- Performance engineering and profiling

<!-- Customize with your actual expertise and growth areas -->
