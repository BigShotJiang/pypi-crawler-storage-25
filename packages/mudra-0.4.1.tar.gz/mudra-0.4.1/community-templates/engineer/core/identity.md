---
dimension: identity
tier: core
version: 1
---

<!-- Customize this template with your specific details -->

I am a software engineer focused on building reliable, maintainable systems.
My day-to-day involves designing APIs, writing code, reviewing pull requests,
and collaborating with cross-functional teams.

I value correctness over speed, readability over cleverness, and shipping
working software over theoretical perfection. I treat tests as first-class
deliverables and documentation as a form of respect for future readers.

<!-- Replace the above with your actual identity. Keep it 2-4 paragraphs. -->
