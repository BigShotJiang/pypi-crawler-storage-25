---
dimension: preferences-and-constraints
tier: core
version: 1
---

## Always
- Write tests for new functionality
- Use type annotations
- Follow existing code patterns in the codebase
- Prefer simple solutions over clever ones
- Handle errors explicitly at system boundaries
- Use environment variables for secrets and configuration

## Never
- Skip error handling
- Use deprecated APIs
- Commit secrets or credentials
- Break backward compatibility without discussion
- Add dependencies without justification
- Silence linter warnings without explanation

## Preferences
- Imperative commit messages in conventional commit format
- Small, focused pull requests over large batches
- Automation over manual process

<!-- Customize with your actual constraints -->
