---
dimension: tools-and-systems
tier: core
version: 1
---

## Languages
- Python, TypeScript, Go

## Development Tools
- VS Code / Neovim
- Git, GitHub

## Infrastructure
- Docker, Kubernetes
- AWS / GCP

## Databases
- PostgreSQL, Redis
- SQLite for local development

## CI/CD
- GitHub Actions
- Pre-commit hooks, linting, type checking in pipeline

## Rejected Tools
<!-- Tools you've tried and decided against, with reasons -->

<!-- Customize all sections above with your actual stack -->
