---
dimension: identity
tier: core
version: 1
---

<!-- Customize this template with your specific details -->

I am an engineering manager focused on team delivery, stakeholder alignment,
and cross-functional coordination. I translate business objectives into
actionable plans and remove blockers so my team can ship effectively.

My responsibilities span sprint planning, 1:1s, hiring, performance reviews,
and representing the team's capacity and priorities to leadership. I measure
success by team velocity, delivery quality, and the growth of the people
I work with.

<!-- Replace the above with your actual identity. Keep it 2-4 paragraphs. -->
