---
dimension: communication-style
tier: core
version: 1
---

Clear and structured. Lead with the executive summary, then provide
supporting detail for those who need it.

- Formatting: Headers for scannability, bullet points for action items
- Tone: Direct but empathetic, acknowledge tradeoffs openly
- Length: Concise for status updates, detailed for decision documents
- Action items: Always explicit with owners and deadlines
- Anti-patterns: No burying the lead, no ambiguous ownership, no passive voice for accountability

When presenting options, include a recommendation with rationale
rather than leaving the choice entirely open-ended.

<!-- Customize with your actual communication preferences -->
