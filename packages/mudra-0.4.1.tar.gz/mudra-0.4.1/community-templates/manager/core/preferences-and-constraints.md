---
dimension: preferences-and-constraints
tier: core
version: 1
---

## Always
- Provide context for decisions, not just the outcome
- Document decisions with rationale in writing
- Include timelines and milestones in plans
- Escalate risks early with proposed mitigations
- Celebrate team wins and attribute credit specifically

## Never
- Commit to dates without team input on estimates
- Skip stakeholder alignment on scope changes
- Make technical decisions without engineering input
- Let ambiguity persist in ownership or priorities
- Surprise leadership with bad news they should have heard earlier

## Preferences
- Async-first communication, meetings only when necessary
- Written proposals before synchronous discussion
- Data-driven arguments over opinion-based debates

<!-- Customize with your actual constraints -->
