---
dimension: tools-and-systems
tier: core
version: 1
---

## Project Management
- Jira / Linear for issue tracking and sprint boards
- Confluence / Notion for documentation and specs

## Communication
- Slack for async communication
- Zoom / Google Meet for synchronous meetings
- Google Workspace for documents and presentations

## Data and Reporting
- Looker / Amplitude for product analytics
- Google Sheets for capacity planning and roadmaps
- OKR tracking tools

## Engineering Visibility
- GitHub for pull request reviews and repository health
- CI/CD dashboards for deployment status

## Rejected Tools
<!-- Tools you've tried and decided against, with reasons -->

<!-- Customize all sections above with your actual stack -->
