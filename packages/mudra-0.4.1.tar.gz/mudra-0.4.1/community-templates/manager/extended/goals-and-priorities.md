---
dimension: goals-and-priorities
tier: extended
version: 1
---

## Current Quarter Goals
- Improve team delivery velocity by reducing cycle time
- Ship the next major milestone on schedule
- Hire and onboard one senior engineer

## Standing Priorities
- Team health and retention
- Delivery predictability and quality
- Stakeholder satisfaction and trust
- Technical debt paydown (allocated percentage per sprint)

## Success Metrics
- Sprint completion rate above 85%
- P0/P1 bug escape rate below target
- Team satisfaction scores trending positive
- On-time delivery against committed roadmap

<!-- Customize with your actual goals and priorities -->
