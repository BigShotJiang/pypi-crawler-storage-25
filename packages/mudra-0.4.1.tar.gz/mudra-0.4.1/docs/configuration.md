# Configuration

Mudra stores configuration in `.mudra/config.toml` within the portfolio directory. This file is created on `mudra init` with sensible defaults.

## Full Configuration Schema

```toml
[portfolio]
path = "~/.mudra"                    # Portfolio directory location
version = "1"                        # Schema version

[freshness]
check_on_serve = true                # Warn about stale files in MCP responses
default_staleness_days = 30          # Default threshold for unlisted files

[freshness.thresholds]
identity = 90
tools-and-systems = 60
communication-style = 90
preferences-and-constraints = 60
role-and-responsibilities = 60
current-projects = 21
team-and-relationships = 30
goals-and-priorities = 30
domain-knowledge = 90
decision-log = 30

[mcp]
transport = "stdio"                  # stdio | streamable-http
port = 3100                          # Port for streamable-http transport

[interview]
provider = "anthropic"               # LLM provider: anthropic | openai | ollama
model = "claude-sonnet-4-20250514"   # Model identifier
temperature = 0.3                    # Low temperature for deterministic synthesis
max_questions_per_file = 8           # Cap on interview question count
```

## Reading and Writing Config

```bash
mudra config get freshness.default_staleness_days    # → 30
mudra config get mcp.transport                       # → stdio
mudra config set mcp.port 8080
mudra config set interview.provider openai
mudra config set freshness.check_on_serve false
```

Keys use dot notation matching the TOML structure. Boolean values accept `true`/`false`, `1`/`0`, `yes`/`no`.

## Freshness Thresholds

Each portfolio file has a staleness threshold — the number of days after which `mudra status` and MCP responses flag it as stale.

Files that change frequently (like `current-projects`) have shorter thresholds. Stable files (like `identity`) have longer ones.

To customize:

```bash
mudra config set freshness.thresholds.current-projects 14    # Check every 2 weeks
mudra config set freshness.thresholds.identity 180           # 6 months for identity
```

## MCP Server Configuration

The MCP server supports two transport modes:

**stdio** (default) — Communicates via stdin/stdout. Used by Claude Code, Cursor, Windsurf, and most local MCP clients.

**streamable-http** — HTTP-based transport for remote access. Runs on the configured port.

```bash
mudra config set mcp.transport streamable-http
mudra config set mcp.port 8080
```

No authentication is built-in for HTTP transport. For remote deployments, use a reverse proxy or SSH tunnel.

## Interview Engine Configuration

The interview engine requires an LLM API key in the environment:

| Provider  | Environment Variable                      |
| --------- | ----------------------------------------- |
| anthropic | `ANTHROPIC_API_KEY`                       |
| openai    | `OPENAI_API_KEY`                          |
| ollama    | None (local, uses `base_url` from config) |

The `--provider` CLI flag overrides the config file setting for a single invocation:

```bash
mudra interview --file identity --provider openai
```

## Config File Location

- Default portfolio: `~/.mudra/.mudra/config.toml`
- Named profile: `~/.mudra/profiles/<name>/.mudra/config.toml`
- Custom path: `<path>/.mudra/config.toml`

The config file is listed in `.gitignore` by default (it may contain provider preferences). The portfolio's markdown files and routing config are tracked by git.

## Routing Configuration

Role-to-file mappings live in `.mudra/routing.toml`, not in `config.toml`. See [Routing and Roles](routing.md) for details.
