# Interview Engine

The interview engine is an alternative to manual editing. It conducts structured Q&A sessions, checks for specificity, and synthesizes your answers into polished portfolio files using an LLM.

## Prerequisites

Install with the interview extra:

```bash
uv tool install "mudra[interview]"
```

Set an API key for your LLM provider:

```bash
export ANTHROPIC_API_KEY=your-key     # Anthropic (default)
export OPENAI_API_KEY=your-key        # OpenAI
# Ollama requires no key (local)
```

## Running an Interview

```bash
mudra interview --file identity
```

The engine walks through a structured set of questions tailored to the file type, then synthesizes your answers into markdown.

### Flow

1. **Intro** — Brief explanation of what the file captures
2. **Questions** — 3-5 questions specific to the file dimension
3. **Specificity check** — If your answer is too vague, the engine asks for concrete examples
4. **Synthesis** — Your answers are sent to the LLM, which produces a polished draft
5. **Review** — You see the draft and can accept, reject, or provide revision feedback
6. **Save** — Accepted drafts are written to the portfolio, committed to git, and freshness is updated

### During the Interview

- Type your answer at the `>` prompt
- Type `skip` or `s` to skip any question
- Press `Ctrl+C` to pause — the session is saved for later `--resume`
- During review, type `yes` to accept, `no` to reject, or type feedback for revision

## Provider Selection

Default provider is configured in `.mudra/config.toml`:

```toml
[interview]
provider = "anthropic"
model = "claude-sonnet-4-20250514"
temperature = 0.3
```

Override for a single session:

```bash
mudra interview --file identity --provider openai
mudra interview --file identity --provider ollama
```

### Supported Providers

| Provider    | Model Format                         | API Key             |
| ----------- | ------------------------------------ | ------------------- |
| `anthropic` | `anthropic/claude-sonnet-4-20250514` | `ANTHROPIC_API_KEY` |
| `openai`    | `openai/gpt-4.1`                     | `OPENAI_API_KEY`    |
| `ollama`    | `ollama/llama3.1:8b`                 | None (local)        |

Model routing is handled by [litellm](https://github.com/BerriAI/litellm).

## Resuming Interrupted Sessions

If you press `Ctrl+C` during an interview, the session state is saved:

```bash
mudra interview --file identity --resume
```

Resume picks up from where you left off — answered questions are preserved, and the interview continues from the next unanswered question.

Session files are stored in `.mudra/interview_session_<file>.json` and cleaned up after successful completion.

## File-Specific Protocols

Each portfolio file has a tailored interview protocol with questions designed to extract the right kind of information:

| File                        | Questions | Focus                                                             |
| --------------------------- | --------- | ----------------------------------------------------------------- |
| identity                    | 5         | Name, role, org, day-to-day, key context                          |
| tools-and-systems           | 5         | Languages, tools, infrastructure, rejected tools, preferred stack |
| communication-style         | 4         | Writing style, formatting, anti-patterns, formality               |
| preferences-and-constraints | 4         | Always/never rules, required practices, mandates                  |
| role-and-responsibilities   | 3         | Official role, deliverables, weekly rhythm                        |
| current-projects            | 3         | Active work, status/priority, collaborators                       |
| team-and-relationships      | 3         | Key people, relationships, dependencies                           |
| goals-and-priorities        | 3         | Quarterly, medium-term, long-term goals                           |
| domain-knowledge            | 3         | Expert areas, skip-basics topics, learning areas                  |
| decision-log                | 3         | Decision, context, tags (produces JSONL)                          |

## Specificity Checking

The engine uses heuristics to detect vague answers:

- Answers shorter than 5 words are flagged
- Answers with too many vague words ("stuff", "things", "basically", "various") are flagged
- Up to 2 follow-up prompts push for concrete examples

This is intentionally lightweight — no LLM calls for specificity checking, keeping costs predictable.

## Updating Existing Files

Running an interview on a file that already has content loads the existing content as context for the LLM synthesis. The synthesizer merges your new answers with the existing content rather than replacing it entirely.

```bash
mudra interview --file identity    # Updates existing identity.md
```

## Manual Editing as Fallback

The interview engine is a convenience layer. You can always create and maintain portfolio files manually:

```bash
mudra edit identity                # Direct editor access
```

If the LLM provider is unavailable, unreachable, or produces unsatisfactory results, manual editing works the same as it always has.
