# CLI Reference

All commands support `--profile <name>` and `--path <dir>` global options for targeting a specific portfolio.

## mudra init

Initialize a new portfolio directory.

```
mudra init [--template NAME]
```

| Flag         | Description                                                 |
| ------------ | ----------------------------------------------------------- |
| `--template` | Community template name (`engineer`, `manager`, `designer`) |

Creates `~/.mudra/` (or profile directory) with:

- 4 core file templates (or pre-filled content from community template)
- Extended files from template (if applicable)
- `.mudra/config.toml` — default configuration
- `.mudra/routing.toml` — role-to-file mappings with 7 default roles
- `.mudra/freshness.json` — per-file update timestamps
- Git repository with initial commit

Errors if the portfolio already exists.

## mudra edit

Open a portfolio file in your default editor.

```
mudra edit <file>
```

`<file>` is a portfolio file name without extension (e.g., `identity`, `tools-and-systems`).

Opens the file in `$EDITOR`. After the editor closes:

- If content changed: writes file, commits to git (`mudra: update <file>`), updates freshness
- If unchanged: no-op

Errors if the file does not exist. For extended files not yet added, suggests `mudra add`.

## mudra add

Add an extended portfolio file from the template.

```
mudra add <file>
```

`<file>` must be one of the 6 extended file names. Core files already exist after `mudra init`.

Copies the template, commits to git (`mudra: add extended file <file>`), updates freshness.

Errors if the file already exists or the name is unrecognized.

## mudra status

Show portfolio freshness and completeness.

```
mudra status [--json]
```

| Flag     | Description                  |
| -------- | ---------------------------- |
| `--json` | Machine-readable JSON output |

Displays:

- Core file count (N/4) with missing files highlighted
- Extended file count
- Per-file freshness: fresh (green), stale (yellow), unknown (white)
- Uncommitted git changes warning

JSON output structure:

```json
{
  "core_files": { "present": 4, "total": 4, "files": [...] },
  "extended_files": { "count": 2, "files": [...] },
  "freshness": { "identity": { "status": "fresh", "days_since_update": 5, ... } },
  "uncommitted_changes": false
}
```

## mudra validate

Run health checks on the portfolio.

```
mudra validate [--strict] [--file NAME]
```

| Flag       | Description                            |
| ---------- | -------------------------------------- |
| `--strict` | Treat warnings as errors (exit code 1) |
| `--file`   | Validate a single file                 |

Checks performed:

| Check                 | Severity | What It Catches                   |
| --------------------- | -------- | --------------------------------- |
| Core file existence   | Error    | Missing required core files       |
| Non-empty content     | Warning  | Files with only template comments |
| Freshness             | Warning  | Files past staleness threshold    |
| Decision log validity | Warning  | Malformed JSONL entries           |

Exit codes: `0` = pass, `1` = errors (or warnings in strict mode).

## mudra history

Show git commit history for the portfolio.

```
mudra history [--file NAME] [--diff]
```

| Flag     | Description                     |
| -------- | ------------------------------- |
| `--file` | Filter history to a single file |
| `--diff` | Show uncommitted diffs          |

Displays a table with commit hash, date, and message.

## mudra roles

List available routing roles.

```
mudra roles [--verbose]
```

| Flag        | Description                      |
| ----------- | -------------------------------- |
| `--verbose` | Show file mappings for each role |

Reads role definitions from `.mudra/routing.toml`.

## mudra config

Read or write configuration values.

```
mudra config get <key>
mudra config set <key> <value>
```

Keys use dot notation: `freshness.default_staleness_days`, `mcp.port`, `interview.provider`.

Boolean values accept: `true`, `false`, `1`, `0`, `yes`, `no`.

## mudra log

Append to the decision log or view entries.

```
mudra log <decision> [--context TEXT] [--tags CSV]
mudra log --list [--tag TAG]
```

| Flag        | Description                                     |
| ----------- | ----------------------------------------------- |
| `--context` | Why this decision was made                      |
| `--tags`    | Comma-separated tags                            |
| `--list`    | List recent decisions (no decision text needed) |
| `--tag`     | Filter listed decisions by tag                  |

Each entry is stored as a JSONL line in `decision-log.jsonl` with auto-generated date. Commits to git after append.

## mudra export

Export portfolio content in various formats.

```
mudra export --format FORMAT [--role NAME] [--output PATH]
```

| Flag       | Description                                                                    |
| ---------- | ------------------------------------------------------------------------------ |
| `--format` | Required. One of: `system-prompt`, `claude-project`, `api-payload`, `markdown` |
| `--role`   | Filter files by routing role (e.g., `code-review`)                             |
| `--output` | Write to file instead of stdout. Required for `claude-project` format.         |

### Formats

**system-prompt** — Wraps content in `<user_context>` XML tags with `##` section headers. Suitable for pasting into system prompts or Claude Projects instructions.

**markdown** — Single concatenated document with `# Mudra Portfolio` heading, `##` sections, and `---` separators.

**api-payload** — JSON with `mudra_version`, `exported_at` timestamp, and file contents keyed by name with tier classification (`core`/`extended`).

**claude-project** — Copies individual `.md` files (frontmatter stripped) into the output directory.

## mudra serve

Start the MCP resource server.

```
mudra serve [--transport MODE] [--port N]
```

| Flag          | Description                              |
| ------------- | ---------------------------------------- |
| `--transport` | `stdio` (default) or `streamable-http`   |
| `--port`      | Port for streamable-http (default: 3100) |

Registers four MCP resources:

| URI                                  | Description        |
| ------------------------------------ | ------------------ |
| `mudra://portfolio/{file_name}`      | Single file        |
| `mudra://portfolio/role/{role_name}` | Role-based context |
| `mudra://portfolio/all`              | All files          |
| `mudra://portfolio/status`           | Freshness report   |

Stale files include an HTML comment freshness warning in the response.

## mudra interview

Create or update a portfolio file through LLM-driven Q&A.

```
mudra interview --file NAME [--provider NAME] [--resume]
```

| Flag         | Description                                             |
| ------------ | ------------------------------------------------------- |
| `--file`     | Required. Portfolio file to interview                   |
| `--provider` | Override LLM provider (`anthropic`, `openai`, `ollama`) |
| `--resume`   | Resume an interrupted interview from saved session      |

Flow: intro → structured questions → specificity checks → LLM synthesis → review/revise → save.

Type `skip` during any question to skip it. On `Ctrl+C`, the session is saved for later `--resume`.

Requires `mudra[interview]` extra and an API key in the environment (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`).

## mudra templates

List available community templates.

```
mudra templates
```

Shows template names and descriptions from `template.toml` metadata files.
