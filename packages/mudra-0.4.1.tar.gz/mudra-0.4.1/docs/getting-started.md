# Getting Started

This guide walks you through installing Mudra, creating your first portfolio, and connecting it to an AI agent.

## Prerequisites

- Python 3.12 or later
- git (for version tracking)
- A text editor (Mudra uses `$EDITOR`)

## Install

```bash
uv tool install mudra
```

Or with pip:

```bash
pip install mudra
```

For MCP server support:

```bash
uv tool install "mudra[mcp]"
```

For the interview engine (LLM-driven portfolio creation):

```bash
uv tool install "mudra[interview]"
```

## Create Your Portfolio

### Option A: Start from scratch

```bash
mudra init
```

This creates `~/.mudra/` with 4 core file templates, a git repository, and default configuration. Each file contains commented guidance explaining what to write.

### Option B: Start from a template

```bash
mudra templates                    # See available templates
mudra init --template engineer     # Pre-filled for software engineers
```

Available templates: `engineer`, `manager`, `designer`.

### Option C: Use a named profile

```bash
mudra init --profile work          # Creates ~/.mudra/profiles/work/
mudra init --profile personal      # Creates ~/.mudra/profiles/personal/
```

## Fill In Your Core Files

Open each core file in your editor:

```bash
mudra edit identity
mudra edit tools-and-systems
mudra edit communication-style
mudra edit preferences-and-constraints
```

Each file opens in `$EDITOR` with a commented template. Delete the comments and write your actual content. When you save and close, Mudra auto-commits the change and updates the freshness timestamp.

### What to write in each file

**identity.md** — Write 2-4 paragraphs in first person. Include your name, role, organization, what you do day-to-day, what you're known for, and the one thing any AI agent must know about you.

**tools-and-systems.md** — List your tech stack organized by category: languages, development tools, cloud/infrastructure, databases. Include tools you've explicitly rejected and why.

**communication-style.md** — Describe your preferred tone, formatting, and anti-patterns. Be specific: "No filler phrases" is more useful than "Be concise."

**preferences-and-constraints.md** — Document your hard rules as "Always" and "Never" lists. Include the reasoning behind each constraint when possible.

## Check Your Progress

```bash
mudra status                       # Freshness report
mudra validate                     # Health checks
```

A complete core portfolio has all 4 files with substantial content (>100 words each, excluding template comments).

## Add Extended Files

When you need more context for specific agent scenarios:

```bash
mudra add current-projects         # For context-switching between projects
mudra add domain-knowledge         # So agents calibrate explanation depth
mudra add goals-and-priorities     # For strategic and planning work
```

Edit after adding:

```bash
mudra edit current-projects
```

## Connect to an AI Agent

### Via MCP (recommended)

Start the MCP server:

```bash
mudra serve
```

Add to your AI tool's MCP configuration:

**Claude Code** — Add to `~/.claude.json`:
```json
{
  "mcpServers": {
    "mudra": {
      "command": "mudra",
      "args": ["serve"]
    }
  }
}
```

**Cursor** — Add to `.cursor/mcp.json`:
```json
{
  "mcpServers": {
    "mudra": {
      "command": "mudra",
      "args": ["serve"]
    }
  }
}
```

The agent will now pull your context automatically via MCP resources.

### Via Export (no MCP needed)

```bash
mudra export --format system-prompt    # Copy output into system prompt
mudra export --format markdown > context.md
```

### Via Copy-Paste

The files are plain markdown. You can always copy content directly from `~/.mudra/`.

## Use the Interview Engine

If you prefer guided creation over manual writing:

```bash
mudra interview --file identity
```

The engine asks structured questions, checks for specificity, and synthesizes your answers into polished content. Requires an LLM API key:

```bash
export ANTHROPIC_API_KEY=your-key     # For Anthropic (default)
export OPENAI_API_KEY=your-key        # For OpenAI
```

Configure the provider in `.mudra/config.toml`:

```toml
[interview]
provider = "anthropic"
model = "claude-sonnet-4-20250514"
temperature = 0.3
```

## Maintain Your Portfolio

### Freshness tracking

Mudra tracks when each file was last updated. Files go stale after their threshold (e.g., `current-projects` after 21 days).

```bash
mudra status                       # See what's fresh and what's stale
```

### Decision logging

Record decisions for future reference:

```bash
mudra log "Chose FastAPI over Flask" --context "Need async support and auto-docs" --tags api,framework
mudra log --list
```

### Version history

Every change is git-committed:

```bash
mudra history                      # View all changes
mudra history --file identity      # Changes to one file
```

## Next Steps

- Read the [CLI Reference](cli-reference.md) for all commands and flags
- Read [Routing and Roles](routing.md) to understand selective context serving
- Read [Configuration](configuration.md) for all config options
