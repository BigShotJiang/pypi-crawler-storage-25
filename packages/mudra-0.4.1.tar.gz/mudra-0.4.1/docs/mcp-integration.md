# MCP Integration Guide

Mudra serves your personal context portfolio via the [Model Context Protocol](https://modelcontextprotocol.io/), allowing any MCP-compatible AI agent to pull your context automatically.

## Starting the Server

```bash
mudra serve                                          # stdio (default)
mudra serve --transport streamable-http --port 3100  # HTTP transport
```

The server runs until terminated (`Ctrl+C`). For stdio transport, the MCP client manages the server lifecycle.

## Client Setup

### Claude Code

Add to your user-level MCP config (`~/.claude.json`) or project-level (`.mcp.json`):

```json
{
  "mcpServers": {
    "mudra": {
      "command": "mudra",
      "args": ["serve"]
    }
  }
}
```

Or use the CLI:

```bash
claude mcp add mudra -- mudra serve
```

### Cursor

Create or edit `.cursor/mcp.json` in your project root:

```json
{
  "mcpServers": {
    "mudra": {
      "command": "mudra",
      "args": ["serve"]
    }
  }
}
```

### Windsurf

Edit `~/.codeium/windsurf/mcp_config.json`:

```json
{
  "mcpServers": {
    "mudra": {
      "command": "mudra",
      "args": ["serve"]
    }
  }
}
```

### Other MCP Clients

Any client that supports stdio transport can connect by running `mudra serve` as a subprocess. The server follows the MCP specification and exposes resources (not tools or prompts).

## Available Resources

The server registers four resource URI patterns:

### Single File

```
mudra://portfolio/{file_name}
```

Reads one portfolio file by name (e.g., `mudra://portfolio/identity`). Returns the file content with frontmatter stripped and a section header. Appends a freshness warning if the file is stale.

### Role-Based Context

```
mudra://portfolio/role/{role_name}
```

Resolves a role to its configured file set (see [Routing and Roles](routing.md)), reads each file, and returns combined content with section headers. Missing extended files are silently excluded.

Examples:

- `mudra://portfolio/role/code-review` — identity + communication-style + tools + preferences
- `mudra://portfolio/role/meeting-prep` — identity + team + projects + goals
- `mudra://portfolio/role/full` — all existing files

Unknown roles fall back to `general-assistant`.

### All Files

```
mudra://portfolio/all
```

Returns all existing portfolio files combined with section headers. Equivalent to the `full` role.

### Status Report

```
mudra://portfolio/status
```

Returns a markdown table showing each file's freshness status, last update date, and days since update.

## Freshness Warnings

When a file is past its staleness threshold, the server appends an HTML comment to the response:

```html
<!-- mudra:freshness-warning
stale_files:
  - file: current-projects
    last_updated: 2026-03-01
    staleness_days: 21
    days_overdue: 14
-->
```

Agents can parse this to suggest that the user update stale files.

## Transport Modes

### stdio (default)

The MCP client starts `mudra serve` as a subprocess and communicates via stdin/stdout using JSON-RPC. This is the standard for local MCP clients (Claude Code, Cursor, Windsurf).

### streamable-http

HTTP-based transport for remote or browser-based clients:

```bash
mudra serve --transport streamable-http --port 3100
```

No authentication is built-in. For remote deployments:

- Use an SSH tunnel: `ssh -L 3100:localhost:3100 user@server`
- Or place behind a reverse proxy with auth (nginx, Caddy)

## Using with Profiles

To serve a specific profile:

```bash
mudra serve --profile work
```

Each profile is an independent portfolio — the MCP server serves files from that profile's directory.

## Troubleshooting

**Server won't start:** Run `mudra status` to verify the portfolio exists. The server requires `mudra init` to have been run.

**Client can't connect:** Verify the `command` path resolves correctly. Try running `mudra serve` manually to check for errors.

**Files not showing up:** The server only serves files that exist on disk. Run `mudra status` to see which files are present. Extended files need `mudra add <file>` before they appear.

**Stale warnings everywhere:** Update the files (`mudra edit <file>`) or adjust thresholds (`mudra config set freshness.thresholds.<file> <days>`).
