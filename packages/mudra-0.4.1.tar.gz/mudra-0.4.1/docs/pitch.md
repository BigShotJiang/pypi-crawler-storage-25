# Mudra

**Your identity, sealed and portable across every AI agent.**

_mudra (मुद्रा) (/ˈmuːdrə/): a seal, stamp, or mark of identity._

---

## The Problem

You use Claude Code for development, ChatGPT for brainstorming, Cursor for code review, and Gemini for research. Every single session starts the same way:

> "I'm a senior engineer at a fintech startup. I prefer Go over Python. I write terse, direct prose. My current sprint is focused on the payments API rewrite. I have a hard constraint against ORMs. My team includes..."

You're paying the **context repetition tax** — re-explaining yourself to every agent, every session, every tool. And you're not even doing it well: under time pressure, you skip details, and the agent fills gaps with generic assumptions.

This tax compounds. With one agent, it's a minor annoyance. With three, it's friction. With ten — the direction we're all headed — it's untenable.

**The numbers back this up:**

- 57% of organizations already have AI agents in production (LangChain, 2025)
- 32% cite quality as their top AI barrier — most failures trace to poor context, not model capability
- The AI agent market is projected to hit $50B by 2030 (MarketsAndMarkets, CAGR 46.3%)
- Gartner has formally defined "context engineering" as the successor discipline to prompt engineering

---

## The Existing Solutions Fall Short

| Solution               | What It Does                                 | Why It's Not Enough                                            |
| ---------------------- | -------------------------------------------- | -------------------------------------------------------------- |
| **ChatGPT Memory**     | Auto-extracts facts from conversations       | Opaque (can't inspect/version), non-portable, privacy concerns |
| **Claude Projects**    | Upload files to a knowledge base             | Claude-only, static uploads, manual refresh                    |
| **Copy-paste prompts** | Paste instructions at session start          | Doesn't scale, versions drift, incomplete                      |
| **Mem0 / Zep / Letta** | Memory infrastructure for developers         | SDKs for building apps, not end-user tools                     |
| **nlwhittemore**       | 10-file markdown portfolio + interview guide | Templates only — no CLI, no MCP, no routing, no freshness      |
| **Plurality Network**  | Decentralized context layer                  | Early stage, crypto-adjacent, complex onboarding               |

The gap: **no tool lets you build structured personal context once and serve it to any AI agent, on any platform, with selective routing and version history.**

---

## What We're Building

**Mudra** — a CLI tool and MCP server that packages your professional identity into modular markdown files and serves them to any AI agent on demand.

### Start With 4 Files, Extend When You Need To

Most tools force you to fill 10 fields before you get value. Mudra starts with 4 core files — the minimum any agent needs — and lets you add more as you feel the gaps.

#### Core Files (Created on Init)

| File                          | What It Captures                    | Why It Matters                               |
| ----------------------------- | ----------------------------------- | -------------------------------------------- |
| **Identity**                  | Name, role, org, what you do        | The one file every agent needs               |
| **Tools & Systems**           | Stack, integrations, rejected tools | Agents stop suggesting tools you don't use   |
| **Communication Style**       | Tone, formatting, voice             | Agent outputs sound like you, not like an AI |
| **Preferences & Constraints** | Hard rules (always/never)           | No more fighting agent defaults              |

#### Extended Files (Added On Demand)

| File                        | What It Captures                              | Add When...                                 |
| --------------------------- | --------------------------------------------- | ------------------------------------------- |
| **Role & Responsibilities** | Work rhythms, deliverables, reporting         | Agents need to understand your actual job   |
| **Current Projects**        | Active workstreams + status                   | You context-switch across multiple projects |
| **Team & Relationships**    | Collaborators, dependencies                   | You use AI for meeting prep and 1:1s        |
| **Goals & Priorities**      | What you're optimizing for                    | You use AI for strategic or planning work   |
| **Domain Knowledge**        | Expertise, terminology                        | Agents over-explain things you already know |
| **Decision Log**            | Past decisions + reasoning (structured JSONL) | You want agents to predict your preferences |

### How It Works

```
$ uv tool install mudra

$ mudra init
# Creates ~/.mudra/ with 4 core file templates + git init

$ mudra edit identity
# Opens in your $EDITOR with a commented template to guide you

$ mudra serve
# MCP server starts — any compatible agent can now pull your context

$ mudra status
# See which files are fresh and which need a quick update

$ mudra add current-projects
# When you're ready, add an extended file
```

### Three Serving Modes

1. **MCP Server** (primary) — agents pull exactly the files they need. Claude Code, Cursor, Windsurf, and any MCP client connect directly.
2. **Export** — generate a system prompt block, Claude Projects bundle, or JSON payload for platforms without MCP support.
3. **Manual** — the files are just markdown. Copy-paste still works.

### Selective Context Routing

Not every agent needs all your files. The router maps agent roles to file subsets:

| Agent Role        | Files Served                                             |
| ----------------- | -------------------------------------------------------- |
| Code review       | identity + communication-style + tools + preferences     |
| Meeting prep      | identity + team + current-projects + goals               |
| Writing assistant | identity + communication-style + domain-knowledge        |
| Strategic advisor | identity + goals + projects + decision-log + preferences |

Extended files that haven't been added yet are silently skipped — no errors, no empty placeholders.

### Git-Backed Version History

Every edit is a git commit. You get full diff history, painless reverts, and a clear audit trail of how your context has evolved — without thinking about version control.

---

## Prior Art and Honest Positioning

The concept of a structured personal context portfolio in markdown files was published by [nlwhittemore/personal-context-portfolio](https://github.com/nlwhittemore/personal-context-portfolio). That project provides templates and an interview guide for 10 context files.

Mudra builds tooling on top of this idea. The core concept — "put who you are in markdown files and share them with AI agents" — is not novel to this project.

**What Mudra adds:**

- CLI with `$EDITOR` integration (not blank templates)
- MCP server with selective routing (not copy-paste)
- Core/extended tier system (not 10 files upfront)
- Git-backed versioning (not overwrite-in-place)
- Freshness tracking and validation
- Structured decision log (JSONL, not freeform markdown)
- Multiple profiles (work/personal/client)
- Interview engine for guided creation (v1.2+)

If all you need is templates, nlwhittemore's repo works. Mudra is for when you want the serving infrastructure, progressive onboarding, and maintenance tooling.

---

## Why This, Why Now

### The Timing Is Right

- **MCP is the standard.** 20,871 servers on Glama.ai, 97M+ SDK downloads/month. The protocol layer is mature enough to build on.
- **Multi-agent is the norm.** Developers routinely use 3–5+ AI tools daily. The tax is real and growing.
- **Portability is the moat platforms can't build.** ChatGPT Memory will keep improving — but it will never work in Claude. Claude Projects will keep improving — but it will never work in Cursor. Portability is structurally impossible for platform vendors to offer.

### Competitive Position

```
                    User-Facing ←────────────────→ Developer Infrastructure
                         │                                    │
           ┌─────────────┼────────────────┐     ┌────────────┼──────────┐
Platform   │ ChatGPT Memory               │     │                       │
Locked     │ Claude Projects               │     │                       │
           │ Notion AI                     │     │                       │
           └─────────────┬────────────────┘     └────────────┬──────────┘
                         │                                    │
           ┌─────────────┼────────────────┐     ┌────────────┼──────────┐
Portable   │ Contextify (web, basic)      │     │ Mem0 ($24.5M funded)  │
           │ AI Context Kit (templates)    │     │ Letta ($10M funded)   │
           │ nlwhittemore (templates)      │     │ Zep ($2.3M funded)    │
           │                               │     │                       │
           │  ┌──────────────────────┐     │     │                       │
           │  │  MUDRA               │     │     │                       │
           │  │  (CLI + MCP + Router)│     │     │                       │
           │  └──────────────────────┘     │     │                       │
           └──────────────────────────────┘     └───────────────────────┘
```

Mudra occupies the **portable, user-facing** quadrant — the one with no dominant player.

### Honest Assessment of Defensibility

This is a **low-moat, high-utility** tool. The format is open markdown. The moat comes from:

1. **First-mover in a specific gap** — portable + user-facing + installable + MCP-native
2. **Routing intelligence** — knowing which files serve which agent role improves with usage data (V1 ships with metadata tracking to feed this)
3. **Progressive onboarding** — 4-file core reduces the blank-page problem that kills adoption of 10-file systems
4. **Community templates** — contributed role templates reduce onboarding friction for new users

**The risk:** if Anthropic or OpenAI ships a portable context standard, standalone tools lose most value. The bet is that portability requires vendor-neutrality — and vendors have no incentive to build it.

---

## Target Users

### Primary: AI Power Users

- Use 3+ AI tools daily (Claude Code, ChatGPT, Cursor, Gemini)
- Already maintain system prompts or CLAUDE.md files manually
- Frustrated by re-explaining themselves across tools
- Technically comfortable with CLI tools and MCP

**Estimated addressable:** Developers and knowledge workers using multiple AI agents daily. Conservative estimate: 500K–2M users globally in 2026, growing with agent adoption.

### Secondary: Engineering Teams

- Standardizing AI agent usage across a team
- Want consistent agent behavior for team members
- Need a lightweight "team context" layer without enterprise infrastructure

### Tertiary: Consultants and Multi-Context Workers

- Switch between client contexts regularly
- Need a stable personal identity layer separate from project-specific context
- Multiple profiles (`--profile client-a`, `--profile client-b`) solve this directly

---

## What We're NOT Building

- **A SaaS platform.** No accounts, no cloud, no subscription.
- **A memory system.** Mem0/Letta/Zep handle conversation memory. This is persistent identity, not session history.
- **A data pipeline.** The user maintains their own context. The tool makes it easier, not automatic.
- **A platform feature.** This is vendor-neutral by design. If it only works with Claude, it failed.
- **A template repo.** nlwhittemore already did that. This is tooling with serving infrastructure.

---

## Development Plan

### Phase 1: Foundation (Weeks 1–3)

- Portfolio store (file management, core/extended tiers, git init)
- CLI commands: `init`, `edit`, `add`, `status`, `validate`, `log`, `history`
- Commented templates for all 4 core files + 6 extended files
- Export module (system-prompt, markdown, claude-project, api-payload formats)
- Multiple profile support (`--profile`)
- PyPI distribution via `uv tool install mudra`

**Milestone:** Users can create, manage, version, and export portfolios using `$EDITOR`.

### Phase 2: Serving (Weeks 4–6)

- MCP resource server (stdio + SSE)
- Selective context routing (role → file mapping)
- Graceful handling of missing extended files in role resolution
- Freshness warnings in MCP responses
- Routing metadata tracking (local-only usage logging)
- Integration docs for Claude Code, Cursor, Windsurf

**Milestone:** Agents can pull context automatically via MCP with selective routing.

### Phase 3: Intelligence (Weeks 7–9)

- Interview engine with LLM-driven Q&A
- Push-for-specificity logic
- Synthesis (answers → markdown)
- Multi-provider support (Anthropic, OpenAI, Ollama)
- Temperature 0.3 for deterministic output

**Milestone:** Users who prefer guided creation can build portfolios through interviews.

### Phase 4: Ecosystem (Weeks 10–12)

- Armory bridge skill (optional integration)
- Community template framework
- 3+ community role templates (engineer, manager, designer)
- Documentation for custom routing roles
- Routing metadata analysis tooling (which mappings are most used, which files are most requested)

**Milestone:** Community contributions flowing, routing intelligence data accumulating.

---

## Open Questions

These are decisions we haven't locked yet — input welcome:

1. **CLI name collision:** `mudra` needs verification against PyPI, Homebrew, and common shell aliases before committing.
2. **Interview UX:** Pure CLI (terminal Q&A) vs. TUI (rich terminal interface with panels) vs. hybrid (CLI triggers browser-based interview)?
3. **Team portfolios:** Should V1 support shared team context (team.md, org-context.md), or is that V2 scope?
4. **Pricing model (if any):** Open source core + paid templates? Fully open? Open source with hosted interview service?
5. **Decision log ergonomics:** Is JSONL the right format, or would a structured markdown table be more accessible for non-technical users?
6. **Routing adaptation:** When should the routing metadata start informing default mappings — after 100 sessions? 1000? User-triggered recalibration?

---

## Call to Action

If this resonates, I'd value your input on:

- **Would you use this?** Be honest. "I'd just keep copy-pasting" is valid feedback.
- **Which of the 4 core files matters most?** If you could only have 1, which?
- **What's the 5th file?** Which extended file would you add first?
- **MCP or export?** Would you set up an MCP server, or would you just export to system prompts?
- **What would stop you?** Privacy concerns? Setup friction? "I only use one AI tool"?

The pitch is simple: **build your context once, use it everywhere, keep it fresh.**

The question is whether "everywhere" matters enough today — or whether this is a tool for 2027 being built in 2026.

---

_Repository: [github.com/Mathews-Tom/mudra](https://github.com/Mathews-Tom/mudra) (coming soon)_
