# Community Templates

Community templates provide pre-filled portfolio content for specific roles, reducing the blank-page problem when getting started.

## Using a Template

```bash
mudra templates                    # List available templates
mudra init --template engineer     # Initialize with engineer template
```

Templates include all 4 core files with role-specific content, plus relevant extended files. After init, customize the content to match your actual details.

## Available Templates

### engineer

For software engineers and developers. Includes:

- **identity.md** — Software engineering focus, system design, code review
- **tools-and-systems.md** — Python, TypeScript, Go, Docker, k8s, cloud platforms
- **communication-style.md** — Direct, code-first, technical terminology
- **preferences-and-constraints.md** — Testing, type safety, simple solutions, no deprecated APIs
- **domain-knowledge.md** (extended) — Backend development, API design, database optimization

### manager

For engineering and product managers. Includes:

- **identity.md** — Team leadership, delivery coordination, stakeholder alignment
- **tools-and-systems.md** — Jira/Linear, Confluence/Notion, Slack, Google Workspace, analytics
- **communication-style.md** — Structured, executive summary first, action items explicit
- **preferences-and-constraints.md** — Document decisions, include timelines, team input on dates
- **goals-and-priorities.md** (extended) — Team velocity, delivery quality, stakeholder satisfaction

### designer

For product and UX designers. Includes:

- **identity.md** — User-centered design, design systems, prototyping
- **tools-and-systems.md** — Figma, Adobe Creative Suite, Miro, Storybook, design tokens
- **communication-style.md** — Visual-first, annotations, structured feedback format
- **preferences-and-constraints.md** — Accessibility-first, design system compliance, mobile considerations
- **domain-knowledge.md** (extended) — UI/UX patterns, WCAG standards, user research methods

## Creating a Template

Community templates live under `community-templates/<name>/` with this structure:

```
community-templates/
└── your-template/
    ├── template.toml              # Required metadata
    ├── core/                      # Required: all 4 core files
    │   ├── identity.md
    │   ├── tools-and-systems.md
    │   ├── communication-style.md
    │   └── preferences-and-constraints.md
    └── extended/                  # Optional: any extended files
        └── domain-knowledge.md
```

### template.toml

```toml
[template]
name = "your-template"
description = "Template for [role description]"
author = "your-name"
tags = ["relevant", "tags"]
```

### File format

Each file must have YAML frontmatter:

```markdown
---
dimension: identity
tier: core
version: 1
---

Your pre-filled content here. Write real, useful content that
someone in this role would customize — not empty placeholders.
```

### Submission

Submit templates via [GitHub issue](https://github.com/Mathews-Tom/mudra/issues/new?template=template_submission.yml) using the template submission form. Requirements:

- All 4 core files included
- Each file has YAML frontmatter
- Content is original
- template.toml metadata present
