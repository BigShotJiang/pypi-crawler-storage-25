# Routing and Roles

Mudra's selective context routing determines which portfolio files are served to an agent based on its role. This reduces token usage and ensures agents receive only relevant context.

## How Routing Works

1. An MCP client requests context for a role (e.g., `mudra://portfolio/role/code-review`)
2. The router looks up the role in `.mudra/routing.toml`
3. The role maps to a list of portfolio file names
4. Files that exist in the portfolio are served; missing files are silently skipped
5. If the role is unknown, the router falls back to `general-assistant`

## Default Roles

Mudra ships with 7 predefined roles:

| Role                | Files                                                                                       | Use Case                                 |
| ------------------- | ------------------------------------------------------------------------------------------- | ---------------------------------------- |
| `general-assistant` | identity, communication-style, preferences-and-constraints                                  | General-purpose AI assistants            |
| `code-review`       | identity, communication-style, tools-and-systems, preferences-and-constraints               | Code review and technical feedback       |
| `meeting-prep`      | identity, team-and-relationships, current-projects, goals-and-priorities                    | Meeting agendas and 1:1 notes            |
| `writing-assistant` | identity, communication-style, domain-knowledge                                             | Drafting posts, docs, and communications |
| `strategic-advisor` | identity, goals-and-priorities, current-projects, decision-log, preferences-and-constraints | Strategic planning and decision-making   |
| `career-coach`      | identity, role-and-responsibilities, goals-and-priorities, domain-knowledge, decision-log   | Career development and growth            |
| `full`              | all files (wildcard)                                                                        | When the agent needs everything          |

## Missing File Handling

Extended files referenced in a role definition but not yet added to the portfolio are silently excluded. The router serves what exists, not what's configured.

Example: The `meeting-prep` role references `team-and-relationships`, `current-projects`, and `goals-and-priorities`. If you've only added `current-projects`, the router serves `identity` + `current-projects` and skips the other two without error.

This design means you can start with just the 4 core files and roles still work — they serve the subset of files that exist.

## Custom Roles

Add custom roles by editing `.mudra/routing.toml`:

```toml
[roles.onboarding-buddy]
description = "Context for helping new team members"
files = ["identity", "team-and-relationships", "tools-and-systems", "current-projects"]

[roles.incident-response]
description = "Context for on-call and incident handling"
files = ["identity", "tools-and-systems", "role-and-responsibilities", "preferences-and-constraints"]
```

List all roles:

```bash
mudra roles              # Names and descriptions
mudra roles --verbose    # With file mappings
```

## Using Roles

### Via MCP

Agents request role-based context through the MCP resource URI:

```
mudra://portfolio/role/code-review
mudra://portfolio/role/meeting-prep
mudra://portfolio/role/onboarding-buddy
```

### Via Export

```bash
mudra export --format system-prompt --role code-review
mudra export --format markdown --role meeting-prep
```

### Fallback Behavior

Unknown role names fall back to `general-assistant`. The router never raises an error for an unrecognized role — it always serves some context.

## Routing Metadata

Mudra tracks which roles are requested in `.mudra/routing_usage.jsonl` (local-only, opt-in via config). This data helps identify:

- Which roles are most used
- Which files are most frequently missing from role requests
- Opportunities to suggest `mudra add <file>` for commonly-needed extended files

The routing metadata is never transmitted — it stays in your local portfolio directory.

## Configuration

Routing configuration lives in `.mudra/routing.toml`. The file is generated on `mudra init` with all 7 default roles. You can modify it freely — add roles, remove roles, or change file mappings.

The `files` array for each role can contain:

- Specific file names: `["identity", "tools-and-systems"]`
- Wildcard: `["*"]` (serves all existing files)
