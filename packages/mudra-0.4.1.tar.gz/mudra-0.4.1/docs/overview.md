# Mudra — System Overview

**Your identity, sealed and portable across every AI agent.**

_mudra (मुद्रा) (/ˈmuːdrə/): a seal, stamp, or mark of identity — a personal imprint that authenticates who you are._

---

## What

Mudra is a CLI tool and MCP server that lets users build, manage, and serve a structured personal context package to any AI agent. It replaces the repetitive, lossy process of re-explaining yourself to every new AI session with a single, portable, machine-readable identity layer.

A portfolio consists of **4 core files** — the minimum context any AI agent needs to be useful — and **6 extended files** that users add as their needs grow.

### Core Files (Required)

| File                             | What It Captures                                       |
| -------------------------------- | ------------------------------------------------------ |
| `identity.md`                    | Name, role, org, what you do — the single-file summary |
| `tools-and-systems.md`           | Tech stack, integrations, rejected tools               |
| `communication-style.md`         | Tone, formatting, dislikes, voice                      |
| `preferences-and-constraints.md` | Hard rules — always/never constraints                  |

### Extended Files (Added On Demand)

| File                           | What It Captures                                             | When to Add                                      |
| ------------------------------ | ------------------------------------------------------------ | ------------------------------------------------ |
| `role-and-responsibilities.md` | Work rhythms, deliverables, reporting structure              | When agents need to understand your actual job   |
| `current-projects.md`          | Active workstreams, status, collaborators                    | When context-switching between projects          |
| `team-and-relationships.md`    | Key people, interaction patterns, dependencies               | When using AI for meeting prep or 1:1s           |
| `goals-and-priorities.md`      | What you're optimizing for at every time horizon             | When using AI for strategic or planning work     |
| `domain-knowledge.md`          | Areas of expertise, terminology, knowledge gaps              | When agents over-explain things you already know |
| `decision-log.jsonl`           | Past decisions and their reasoning (structured, append-only) | When you want agents to predict your preferences |

The 4-core / 6-extended split exists for a reason: onboarding with 10 empty files triggers blank-page paralysis. Four files is 15–20 minutes of focused writing. The extended files earn their place when users feel the absence — not before.

### Capabilities

The tool provides:

- **CLI with `$EDITOR` integration** — create and maintain portfolio files using your own editor, with commented templates that guide content
- **MCP resource server** — serves portfolio files to any MCP-compatible agent on demand
- **Selective context routing** — agents request context by role (meeting-prep, code-review, writing-assistant) and receive only relevant files
- **Freshness tracking** — flags stale files, prompts targeted updates
- **Multi-format export** — system prompts, Claude Projects bundles, API payloads, raw markdown
- **Git-backed versioning** — portfolio directory is a git repo; every update is a commit with a meaningful message
- **Interview engine** (Phase 3) — AI-driven Q&A that extracts specifics when users prefer guided creation over manual writing

---

## Why

### The Context Repetition Tax

Every AI interaction starts at zero. Users re-explain their role, preferences, constraints, communication style, and project context to each new agent, each new session, each new tool. This is the **context repetition tax** — and it compounds:

- **1 agent**: tolerable. Copy-paste some instructions.
- **3 agents**: annoying. Different versions of "who I am" drift across tools.
- **10+ agents**: untenable. Context is incomplete, inconsistent, and stale everywhere.

The tax isn't just time. It degrades quality. Under time pressure, users omit critical context — and the agent fills gaps with assumptions.

### The Portability Problem

Platform-native solutions (ChatGPT Memory, Claude Projects) lock context inside one vendor:

- ChatGPT Memory is opaque — users can't inspect, version, or export the full profile it builds
- Claude Projects requires manual re-upload when context changes
- Neither works across competing platforms

When users switch tools — or use multiple tools simultaneously — they start from scratch.

### The Paradigm Shift

Gartner now formally defines **context engineering** as a discipline: "designing and structuring the relevant data, workflows and environment so AI systems can understand intent, make better decisions and deliver contextual, enterprise-aligned outcomes."

Context engineering has displaced prompt engineering as the bottleneck. The model is capable; the context is what's missing.

### Why Now

1. **MCP adoption is exploding** — 20,871 servers on Glama.ai, 88K+ repos on GitHub, 97M+ monthly SDK downloads. The protocol layer is ready.
2. **Multi-agent workflows are mainstream** — 57% of organizations have AI agents in production (LangChain, 2025). Users interact with 3–10+ agents daily.
3. **Platform switching is real** — geopolitical events, pricing changes, and capability leapfrogs trigger mass migrations. Portable context is insurance.
4. **Enterprise AI failures trace to context, not capability** — 32% of organizations cite quality as their top AI barrier, with most failures attributed to poor context management.

---

## How

### User Journey

```
1. Install         →  uv tool install mudra
2. Initialize      →  mudra init
                      (creates ~/.mudra/ with 4 core templates + git init)
3. Edit            →  mudra edit identity
                      (opens in $EDITOR with commented template)
4. Serve           →  mudra serve
                      (local MCP resource server — agents pull context on demand)
5. Connect agents  →  Add MCP endpoint to Claude Code, Cursor, etc.
6. Extend          →  mudra add current-projects
                      (adds an extended file when you need it)
7. Maintain        →  mudra status
                      (freshness report + git log of changes)
```

### Architecture Summary

```
┌─────────────────────────────────────────────────────┐
│                   User's Machine                     │
│                                                      │
│  ~/.mudra/            (git-initialized)              │
│  ├── identity.md               ← core               │
│  ├── tools-and-systems.md      ← core               │
│  ├── communication-style.md    ← core               │
│  ├── preferences-and-constraints.md  ← core         │
│  ├── current-projects.md       ← extended (opt-in)  │
│  ├── ...                       ← extended (opt-in)  │
│  └── .mudra/                                         │
│      ├── config.toml      (preferences, defaults)    │
│      ├── freshness.json   (last-updated timestamps)  │
│      └── routing.toml     (role → file mappings)     │
│                                                      │
│  mudra CLI ───────────────────┐                      │
│  ├── init / edit / add        │                      │
│  ├── freshness tracker        │                      │
│  ├── export module            ├── MCP Server         │
│  ├── validator                │   (stdio / SSE)      │
│  └── interview engine (v1.2+) │                      │
└───────────────────────────────┘──────────────────────┘
         │                              │
         │ export                       │ MCP protocol
         ▼                              ▼
  Claude Projects              Claude Code, Cursor,
  System Prompts               Windsurf, any MCP client
  API payloads
```

### Prior Art

The concept of a portable personal context portfolio in 10 markdown files was published by [nlwhittemore/personal-context-portfolio](https://github.com/nlwhittemore/personal-context-portfolio), which includes templates and an interview guide. Mudra builds on this idea with significant tooling additions — but the foundational concept of "structured markdown files for personal AI context" is not novel to this project. The delta is in the serving infrastructure, selective routing, freshness management, and the core/extended tier system.

| Feature           | nlwhittemore               | Mudra                                                        |
| ----------------- | -------------------------- | ------------------------------------------------------------ |
| Creation          | Manual fill-in with guides | `$EDITOR` with commented templates; interview engine (v1.2+) |
| Serving           | Copy-paste                 | MCP server with selective routing                            |
| Maintenance       | Manual                     | Freshness tracking + targeted refresh                        |
| Context selection | All-or-nothing             | Role-based file subsets per agent                            |
| Onboarding        | 10 files upfront           | 4 core files; extend when needed                             |
| Versioning        | None                       | Git-backed history                                           |
| Validation        | None                       | Schema + completeness checks                                 |
| Distribution      | Git clone                  | `uv tool install` / PyPI                                     |

---

## Market Research

### Market Size

| Metric                            | Value     | Source                                       |
| --------------------------------- | --------- | -------------------------------------------- |
| AI Agent market (2025)            | $7.6–8.3B | Grand View Research, MarketsAndMarkets       |
| AI Agent market (2030)            | $50–53B   | MarketsAndMarkets (CAGR 46.3%)               |
| AI Agent market (2033)            | $183B     | Grand View Research (CAGR 49.6%)             |
| Orgs with AI agents in production | 57%       | LangChain State of Agent Engineering 2025    |
| Orgs using AI in ≥1 function      | 88%       | 2025 enterprise survey (up from 55% in 2023) |
| Quality cited as top AI barrier   | 32%       | Enterprise adoption survey 2025              |

### Competitive Landscape

The market segments into three tiers. Mudra targets the gap between them.

#### Tier 1: Memory Infrastructure (Funded, API-First)

| Player    | Approach                 | Funding       | Scale             |
| --------- | ------------------------ | ------------- | ----------------- |
| **Mem0**  | Memory layer for AI apps | $24.5M (a16z) | 20K+ GitHub stars |
| **Letta** | Long-term memory agents  | $10M (a16z)   | Formerly MemGPT   |
| **Zep**   | Memory for AI assistants | $2.3M seed    | Cloud-first       |

These are **developer infrastructure** — SDKs for building memory into applications. Not end-user tools.

#### Tier 2: Platform-Native Memory (Vendor-Locked)

| Player              | Approach                               | Limitation                                  |
| ------------------- | -------------------------------------- | ------------------------------------------- |
| **ChatGPT Memory**  | Auto-extracts facts from conversations | Opaque, non-portable, can't inspect/version |
| **Claude Projects** | Upload files to a knowledge base       | Claude-only, static uploads, manual refresh |
| **Notion AI**       | Document-backed AI assistant           | Notion-only                                 |

Vendor lock-in. Context dies when you switch platforms.

#### Tier 3: Portability Attempts (Early)

| Player                                      | Approach                                            | Status                                      |
| ------------------------------------------- | --------------------------------------------------- | ------------------------------------------- |
| **Plurality Network / AI Context Flow**     | Decentralized Open Context Layer, browser extension | Early stage, crypto-adjacent, complex setup |
| **Contextify**                              | Save persona + constraints, use across LLMs         | Lightweight, web-only, no MCP               |
| **AI Context Kit**                          | Template repo for portable AI collaboration         | Templates only, no tooling                  |
| **nlwhittemore/personal-context-portfolio** | 10-file markdown portfolio + interview protocol     | Templates + guides, no CLI/MCP/automation   |

**The gap Mudra fills:** No tool combines structured creation, selective serving (MCP with role-based routing), versioned maintenance, and a progressive onboarding path (start with 4 files, not 10) in a single installable package.

### MCP Ecosystem Context

| Signal                    | Number  |
| ------------------------- | ------- |
| MCP servers on Glama.ai   | ~20,871 |
| MCP repos on GitHub       | 88,153  |
| awesome-mcp-servers stars | 84,205  |
| MCP SDK monthly downloads | 97M+    |

Notable MCP memory servers exist (context-portal, mcp-memory-service, MemoryMesh) but all focus on **session/project memory** — what happened in this conversation. None serve **persistent personal identity** — who you are across all conversations.

---

## Risks

### Technical Risks

| Risk                           | Severity | Mitigation                                                                                                                                                                                       |
| ------------------------------ | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **MCP spec instability**       | Medium   | Abstract transport layer; support stdio + SSE. MCP is backed by Anthropic with massive adoption — unlikely to be abandoned, but spec may evolve.                                                 |
| **LLM context window limits**  | Low      | Selective routing already solves this — serve 2–4 files, not 10. Context windows are growing, not shrinking.                                                                                     |
| **Interview quality variance** | Medium   | Interview engine is Phase 3, not launch-critical. Users can always fall back to manual editing. Structured prompts with push-for-specificity logic. Temperature 0.3 for deterministic synthesis. |
| **File format evolution**      | Low      | Markdown is universal and stable. Schema is additive — new optional fields don't break existing portfolios.                                                                                      |

### Market Risks

| Risk                                | Severity | Mitigation                                                                                                                                                              |
| ----------------------------------- | -------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Platform-native memory improves** | High     | ChatGPT Memory and Claude Projects will get better. Moat is portability — platform features can't be portable by definition.                                            |
| **Mem0 / Letta move downstream**    | Medium   | They're building infrastructure for developers, not end-user tools. Different audience, different distribution. But they could add a "personal profile" feature.        |
| **Users don't maintain portfolios** | High     | Freshness tracking + nudges. Git history makes reverting painless. Core-4 reduces maintenance surface by 60%. Low-friction partial updates (refresh one file, not all). |
| **"Good enough" with copy-paste**   | Medium   | Works for 1 agent. Breaks at 3+. Target power users already using multiple agents.                                                                                      |
| **Privacy concerns**                | Medium   | All data local by default. No cloud, no telemetry, no account. Git repo is local-only unless user explicitly pushes.                                                    |

### Execution Risks

| Risk                               | Severity | Mitigation                                                                                                                         |
| ---------------------------------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| **Solo maintainer burnout**        | High     | Scope to CLI + MCP server. No web app, no SaaS, no accounts. Keep it a tool, not a platform.                                       |
| **Adoption chicken-and-egg**       | Medium   | Works immediately with `$EDITOR` + export (no MCP needed). MCP is the upgrade path, not the prerequisite.                          |
| **Multiple profiles needed early** | Medium   | V1 supports `--profile` flag for switching between work/personal/client contexts. Each profile is a separate git-backed directory. |

---

## Possible Moat

### Defensibility Analysis

Mudra is a **thin tool over a simple format**. Markdown files are trivially copyable. The moat is not in the format — it's in the accumulated layers:

#### 1. First-Mover in the Portable + User-Facing Quadrant

No installable tool currently combines structured creation, MCP serving, and selective routing. Being first with a complete, usable solution creates early adoption and community gravity.

#### 2. Schema Moat (Selective Routing Mappings)

The mapping of agent roles → file subsets is the non-obvious value. Knowing that `meeting-prep` needs `team-and-relationships.md` + `current-projects.md` while `code-review` needs `communication-style.md` + `tools-and-systems.md` requires real-world usage data. V1 ships with a `routing_metadata` schema to capture which mappings are used and overridden — this telemetry (opt-in, local-only) feeds routing improvements in future versions.

#### 3. Maintenance Moat (Freshness + Git History)

Users who've built portfolios face switching costs — not because the data is locked in, but because the maintenance workflow (targeted refresh, freshness nudges, version history) is integrated into their routine. Git-backed history means users can diff changes, revert mistakes, and see how their context has evolved.

#### 4. Community Moat (Templates + Roles Library)

A growing library of community-contributed role templates (data-scientist, engineering-manager, founder, designer) and routing mappings creates value that scales with contributors.

#### 5. Armory Integration (Optional Multiplier)

For users of [Armory](https://github.com/Mathews-Tom/armory) (92 production-grade packages for AI coding agents), a thin bridge skill connects Mudra context to every installed package. This is an integration, not a dependency — Mudra works without Armory, and Armory works without Mudra. But together, every armory skill inherits the user's communication style, tool preferences, and constraints without per-skill configuration.

### Realistic Assessment

This is a **low-moat, high-utility** tool. The format is open (intentionally). The honest answer: if Anthropic or OpenAI builds a portable context standard, standalone tools lose most of their value. The bet is that **portability is the feature they can't build** — and portability is the whole point.

---

## Success Metrics

### Adoption (First 6 Months)

| Metric                                      | Target |
| ------------------------------------------- | ------ |
| PyPI installs                               | 1,000  |
| GitHub stars                                | 500    |
| Complete portfolios created (self-reported) | 200    |
| Users with MCP server active                | 100    |

### Quality

| Metric                                      | Target               |
| ------------------------------------------- | -------------------- |
| Average core file completeness (4/4 filled) | ≥90%                 |
| Extended files adopted per user (avg)       | ≥2                   |
| Files updated within staleness threshold    | ≥60%                 |
| User-reported "context quality improvement" | Qualitative feedback |

### Ecosystem

| Metric                               | Target                                               |
| ------------------------------------ | ---------------------------------------------------- |
| Community role templates contributed | 10                                                   |
| MCP client integrations documented   | 5 (Claude Code, Cursor, Windsurf, Codex, Gemini CLI) |
| Community routing role definitions   | 15                                                   |
