# Mudra — System Design

## Architecture Overview

Mudra is a Python CLI tool and MCP server. It follows a layered architecture with clear separation between data (portfolio files), logic (routing, validation, interview), and transport (MCP server, export formats).

The portfolio uses a **core/extended tier** model: 4 core files ship with `mudra init`, and 6 extended files are added explicitly via `mudra add`. The entire portfolio directory is git-initialized for version history.

```text
┌───────────────────────────────────────────────────────────────────┐
│                        MCP Clients                                │
│  Claude Code  │  Cursor  │  Windsurf  │  Codex  │  Gemini CLI     │
└──────┬────────┴─────┬────┴──────┬─────┴────┬────┴───────┬─────────┘
       │              │           │          │            │
       └──────────────┴─────┬─────┴──────────┴────────────┘
                            │ MCP Protocol (stdio / SSE)
                            ▼
┌───────────────────────────────────────────────────────────────────┐
│                          Mudra                                    │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐ │
│  │  MCP Server  │  │  CLI (mudra) │  │     Export Module        │ │
│  │  - resources │  │  - init      │  │  - system-prompt         │ │
│  │  - selective │  │  - edit      │  │  - claude-projects       │ │
│  │    routing   │  │  - add       │  │  - api-payload           │ │
│  │  - freshness │  │  - status    │  │  - raw markdown          │ │
│  │              │  │  - validate  │  │                          │ │
│  │              │  │  - interview │  │                          │ │
│  └──────┬───────┘  └──────┬───────┘  └────────────┬─────────────┘ │
│         │                 │                       │               │
│  ┌──────┴─────────────────┴───────────────────────┴─────────────┐ │
│  │                        Core Engine                           │ │
│  │                                                              │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌─────────────────────┐ │ │
│  │  │   Router     │  │  Validator   │  │  Interviewer (v1.2) │ │ │
│  │  │  - role maps │  │  - schema    │  │  - protocols        │ │ │
│  │  │  - file sets │  │  - complete  │  │  - synthesis        │ │ │
│  │  │  - metadata  │  │  - freshness │  │  - follow-ups       │ │ │
│  │  │  - fallback  │  │  - git status│  │                     │ │ │
│  │  └──────────────┘  └──────────────┘  └─────────────────────┘ │ │
│  └───────────────────────────┬──────────────────────────────────┘ │
│                              │                                    │
│  ┌───────────────────────────┴──────────────────────────────────┐ │
│  │                     Portfolio Store                          │ │
│  │                                                              │ │
│  │  ~/.mudra/                            (git-initialized)      │ │
│  │  ├── identity.md                      ← core                 │ │
│  │  ├── tools-and-systems.md             ← core                 │ │
│  │  ├── communication-style.md           ← core                 │ │
│  │  ├── preferences-and-constraints.md   ← core                 │ │
│  │  ├── current-projects.md              ← extended (opt-in)    │ │
│  │  ├── role-and-responsibilities.md     ← extended (opt-in)    │ │
│  │  ├── team-and-relationships.md        ← extended (opt-in)    │ │
│  │  ├── goals-and-priorities.md          ← extended (opt-in)    │ │
│  │  ├── domain-knowledge.md              ← extended (opt-in)    │ │
│  │  ├── decision-log.jsonl               ← extended (opt-in)    │ │
│  │  └── .mudra/                                                 │ │
│  │      ├── config.toml                                         │ │
│  │      ├── freshness.json                                      │ │
│  │      └── routing.toml                                        │ │
│  └──────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────┘
```

---

## Component Design

### 1. Portfolio Store

The portfolio is a git-initialized directory of markdown files (plus one JSONL file) with a metadata sidecar.

#### Directory Layout

```text
~/.mudra/                                # default profile
├── identity.md                          # core
├── tools-and-systems.md                 # core
├── communication-style.md               # core
├── preferences-and-constraints.md       # core
├── current-projects.md                  # extended (added via `mudra add`)
├── role-and-responsibilities.md         # extended
├── team-and-relationships.md            # extended
├── goals-and-priorities.md              # extended
├── domain-knowledge.md                  # extended
├── decision-log.jsonl                   # extended (structured, append-only)
├── .mudra/
│   ├── config.toml          # User preferences, LLM provider config
│   ├── freshness.json       # Per-file last-updated timestamps + staleness thresholds
│   └── routing.toml         # Role → file subset mappings (user-customizable)
├── .gitignore               # Ignores .mudra/config.toml (may contain provider prefs)
└── .git/                    # Auto-initialized; every save = commit
```

#### Multiple Profiles

Users who need separate contexts (work vs. personal, or per-client for consultants) use profiles:

```bash
mudra init --profile work          # creates ~/.mudra/profiles/work/
mudra init --profile personal      # creates ~/.mudra/profiles/personal/
mudra edit identity --profile work
mudra serve --profile work
```

Each profile is an independent git-backed directory with its own config, routing, and files. The default profile (no flag) uses `~/.mudra/`.

#### File Tiers

```python
CORE_FILES: list[str] = [
    "identity",
    "tools-and-systems",
    "communication-style",
    "preferences-and-constraints",
]

EXTENDED_FILES: list[str] = [
    "role-and-responsibilities",
    "current-projects",
    "team-and-relationships",
    "goals-and-priorities",
    "domain-knowledge",
    "decision-log",
]
```

`mudra init` creates the 4 core files with commented templates. Extended files are added individually via `mudra add <file>` when the user needs them. The CLI never pressures users to fill files they haven't opted into.

#### File Schema

Each portfolio file is freeform markdown with optional YAML frontmatter for machine-readable metadata:

```markdown
---
dimension: identity
tier: core
version: 1
last_updated: 2026-04-05
---

# Identity

Tom Mathews. AI tooling engineer building developer infrastructure...
```

The frontmatter is optional for user-created files — the CLI writes it automatically during edits and interviews.

#### Decision Log Format

The decision log uses JSONL (one JSON object per line) rather than markdown, because it has fundamentally different access patterns: append-only, grows unboundedly, and needs structured entries with timestamps.

```jsonl
{"date": "2026-04-05", "decision": "Chose Click over Typer for CLI framework", "context": "Typer's magic type inference conflicts with explicit style preferences", "tags": ["tooling", "architecture"], "outcome": null}
{"date": "2026-04-03", "decision": "Rejected ORM for database layer", "context": "Query patterns are simple enough for raw SQL; ORM adds abstraction without value", "tags": ["architecture", "database"], "outcome": "Confirmed — 3 months in, no regrets"}
```

The CLI provides helpers:

```bash
mudra log "Chose Click over Typer" --context "Typer's magic inference conflicts with explicit style" --tags tooling,architecture
mudra log --list                    # pretty-print recent decisions
mudra log --list --tag architecture # filter by tag
```

When served via MCP, the decision log is rendered as a readable markdown section for the agent's context window.

#### Freshness Tracking (`freshness.json`)

```json
{
  "identity": {
    "last_updated": "2026-04-05T10:30:00Z",
    "staleness_days": 90,
    "status": "fresh"
  },
  "current-projects": {
    "last_updated": "2026-03-20T14:00:00Z",
    "staleness_days": 21,
    "status": "stale"
  }
}
```

Default staleness thresholds (configurable):

| File                          | Default Staleness | Tier     |
| ----------------------------- | ----------------- | -------- |
| `identity`                    | 90 days           | core     |
| `tools-and-systems`           | 60 days           | core     |
| `communication-style`         | 90 days           | core     |
| `preferences-and-constraints` | 60 days           | core     |
| `role-and-responsibilities`   | 60 days           | extended |
| `current-projects`            | 21 days           | extended |
| `team-and-relationships`      | 30 days           | extended |
| `goals-and-priorities`        | 30 days           | extended |
| `domain-knowledge`            | 90 days           | extended |
| `decision-log`                | 30 days           | extended |

#### Git-Backed Versioning

`mudra init` runs `git init` in the portfolio directory. Every file write — whether from `mudra edit`, `mudra add`, `mudra interview`, or `mudra log` — commits with a meaningful message:

```
mudra: update identity.md via editor
mudra: add extended file current-projects.md
mudra: refresh current-projects.md via interview
mudra: log decision "Chose Click over Typer"
```

This gives users:

- Full version history: `git log --oneline` in the portfolio directory
- Diff between versions: `git diff HEAD~1 identity.md`
- Revert mistakes: `git checkout HEAD~1 -- identity.md`
- Branching for experimental changes (advanced users)

The portfolio is a local git repo by default. Users who want remote backup can add a remote — but Mudra never pushes automatically.

#### Routing Configuration (`routing.toml`)

Maps agent roles to file subsets. Only references files that exist in the portfolio — extended files that haven't been added are silently excluded from role resolution.

```toml
[roles]

[roles.general-assistant]
files = ["identity", "communication-style", "preferences-and-constraints"]
description = "Default context for general-purpose AI assistants"

[roles.meeting-prep]
files = ["identity", "team-and-relationships", "current-projects", "goals-and-priorities"]
description = "Context for preparing meeting agendas and 1:1 notes"

[roles.code-review]
files = ["identity", "communication-style", "tools-and-systems", "preferences-and-constraints"]
description = "Context for code review and technical feedback"

[roles.writing-assistant]
files = ["identity", "communication-style", "domain-knowledge"]
description = "Context for drafting posts, docs, and communications"

[roles.strategic-advisor]
files = ["identity", "goals-and-priorities", "current-projects", "decision-log", "preferences-and-constraints"]
description = "Context for strategic planning and decision-making"

[roles.career-coach]
files = ["identity", "role-and-responsibilities", "goals-and-priorities", "domain-knowledge", "decision-log"]
description = "Context for career development and growth planning"

[roles.full]
files = ["*"]
description = "All portfolio files — use sparingly"

# Routing metadata — captures usage patterns for future optimization
[routing_metadata]
track_usage = true          # log which roles are requested (local-only)
log_overrides = true        # log when users override role → file mappings
log_path = ".mudra/routing_usage.jsonl"
```

Users can add custom roles and override defaults. The `routing_metadata` section enables future instrumentation — V1 captures the data, future versions use it to improve default mappings.

---

### 2. CLI (`mudra`)

The CLI is the primary user interface. Built with `click` for argument parsing.

#### Command Tree

```text
mudra
├── init              # Initialize a new portfolio directory
│   ├── --template <name>     # Start from a community template
│   ├── --profile <name>      # Create a named profile (default: ~/.mudra/)
│   └── --path <dir>          # Custom portfolio location
│
├── edit <file>       # Open a portfolio file in $EDITOR
│   └── --profile <name>      # Edit in a specific profile
│
├── add <file>        # Add an extended file to the portfolio
│   └── --profile <name>
│
├── status            # Freshness report + portfolio health
│   ├── --json                # Machine-readable output
│   └── --profile <name>
│
├── validate          # Schema + completeness checks
│   ├── --strict              # Fail on warnings
│   └── --file <name>         # Validate a specific file
│
├── serve             # Start the MCP server
│   ├── --transport <stdio|sse>  # Transport mode (default: stdio)
│   ├── --port <n>               # Port for SSE mode (default: 3100)
│   ├── --role <name>            # Serve only files for a specific role
│   └── --profile <name>
│
├── export            # Export portfolio in various formats
│   ├── --format <system-prompt|claude-project|api-payload|markdown>
│   ├── --role <name>         # Export only files for a specific role
│   ├── --output <path>       # Output file (default: stdout)
│   └── --profile <name>
│
├── roles             # List available routing roles
│   └── --verbose             # Show file mappings per role
│
├── log               # Append to decision log
│   ├── <decision>            # Decision text (positional)
│   ├── --context <text>      # Why this decision was made
│   ├── --tags <csv>          # Comma-separated tags
│   ├── --list                # Pretty-print recent decisions
│   └── --tag <tag>           # Filter list by tag
│
├── interview         # AI-driven interview to create/update files (v1.2+)
│   ├── --file <name>         # Interview a specific file
│   ├── --all                 # Interview all existing files
│   ├── --resume              # Resume an interrupted interview
│   └── --provider <name>     # LLM provider (anthropic, openai, ollama)
│
├── history           # Show git log for portfolio changes
│   ├── --file <name>         # History for a specific file
│   └── --diff                # Show diffs
│
└── config            # View/edit configuration
    ├── get <key>
    └── set <key> <value>
```

---

### 3. MCP Server

The MCP server exposes portfolio files as resources that any MCP-compatible client can request. **V1 is read-only.** Write tools (agent-initiated updates) are deferred until real usage patterns emerge to inform conflict resolution and append semantics.

#### MCP Resource Architecture

```mermaid
sequenceDiagram
    participant Client as MCP Client (Claude Code, Cursor)
    participant Server as mudra MCP Server
    participant Store as Portfolio Store

    Client->>Server: resources/list
    Server->>Store: Read routing.toml + freshness.json
    Store-->>Server: Available files + roles + staleness
    Server-->>Client: Resource list with metadata

    Client->>Server: resources/read (uri: mudra://portfolio/identity)
    Server->>Store: Read identity.md
    Store-->>Server: File content
    Server-->>Client: Resource content

    Client->>Server: resources/read (uri: mudra://portfolio/role/meeting-prep)
    Server->>Store: Read routing.toml → resolve files
    Note over Server: Skip files not yet added to portfolio
    Server->>Store: Read available files for role
    Store-->>Server: File contents
    Server-->>Client: Combined context for role
```

#### Resource URI Scheme

```text
mudra://portfolio/{file-name}           # Single file
mudra://portfolio/role/{role-name}      # All files for a role (skips missing extended files)
mudra://portfolio/all                   # All files (use sparingly)
mudra://portfolio/status                # Freshness report
```

#### Transport Modes

| Mode      | Command                                   | Use Case                             |
| --------- | ----------------------------------------- | ------------------------------------ |
| **stdio** | `mudra serve`                             | Claude Code, local MCP clients       |
| **SSE**   | `mudra serve --transport sse --port 3100` | Remote access, browser-based clients |

#### Freshness Warnings

When serving stale files, the server appends a machine-readable warning:

```markdown
<!-- mudra:freshness-warning
stale_files:
  - file: current-projects
    last_updated: 2026-03-01
    staleness_days: 21
    days_overdue: 14
-->
```

Agents can interpret this and suggest the user run `mudra edit current-projects` or `mudra interview --file current-projects`.

#### Why No Write Tools in V1

MCP write tools (e.g., `mudra_update_project`, `mudra_log_decision`) sound useful but introduce hard problems:

- **Conflict resolution**: two agents writing to the same file in different sessions
- **Append semantics**: how does an agent "update" a markdown file without clobbering context it doesn't understand?
- **Trust boundary**: should an agent modify your identity without explicit approval?

These are solvable, but solving them well requires real usage data. V1 ships read-only. If users request write access, V2 will implement it with append-only semantics, per-file allowlists, and mandatory confirmation — informed by observed patterns from the routing metadata.

---

### 4. Selective Context Router

The router determines which files to serve based on the requesting agent's role or the user's explicit selection.

#### Routing Logic

```mermaid
flowchart TD
    A[MCP Request] --> B{URI type?}

    B -->|mudra://portfolio/file-name| C[Serve single file]

    B -->|mudra://portfolio/role/name| D[Lookup role in routing.toml]
    D --> E{Role exists?}
    E -->|Yes| F[Resolve file list]
    E -->|No| G[Fall back to general-assistant role]
    G --> F
    F --> H[Filter to files present in portfolio]
    H --> I[Read files from store]
    I --> J[Check freshness per file]
    J --> K{Any stale files?}
    K -->|Yes| L[Append staleness warning to response]
    K -->|No| M[Return combined context]
    L --> M

    B -->|mudra://portfolio/all| N[Read all existing files]
    N --> J

    B -->|mudra://portfolio/status| O[Return freshness report]
```

The key addition at step H: extended files that appear in `routing.toml` but haven't been added via `mudra add` are silently excluded. The router serves what exists, not what's configured. This prevents errors when a role references `team-and-relationships.md` but the user hasn't created it yet.

#### Routing Metadata

When `routing_metadata.track_usage` is enabled (default: true), the router logs:

```jsonl
{"timestamp": "2026-04-05T10:30:00Z", "role": "code-review", "files_requested": ["identity", "communication-style", "tools-and-systems", "preferences-and-constraints"], "files_served": ["identity", "communication-style", "tools-and-systems", "preferences-and-constraints"], "files_missing": []}
{"timestamp": "2026-04-05T11:00:00Z", "role": "meeting-prep", "files_requested": ["identity", "team-and-relationships", "current-projects", "goals-and-priorities"], "files_served": ["identity", "current-projects"], "files_missing": ["team-and-relationships", "goals-and-priorities"]}
```

This data feeds future improvements: if 80% of `meeting-prep` requests result in `goals-and-priorities` being missing, the CLI can suggest adding that file.

---

### 5. Export Module

Exports portfolio content for platforms that don't support MCP.

#### Export Formats

**System Prompt Block:**

```markdown
<user_context>

## Identity

Tom Mathews. AI tooling engineer...

## Communication Style

Terse, direct, no filler...
</user_context>
```

**Claude Projects Bundle:**

```
export/claude-project/
├── identity.md
├── communication-style.md
└── tools-and-systems.md
```

**API Payload (JSON):**

```json
{
  "mudra_version": "1.0.0",
  "exported_at": "2026-04-05T10:30:00Z",
  "role": "general-assistant",
  "files": {
    "identity": { "content": "...", "last_updated": "2026-04-05" },
    "communication-style": { "content": "...", "last_updated": "2026-04-01" }
  }
}
```

**Raw Markdown (concatenated):**
Single file with all selected portfolio content, separated by headers.

---

### 6. Validator

Checks portfolio health without requiring the user to read every file.

#### Validation Checks

| Check                     | Level   | What It Catches                                                |
| ------------------------- | ------- | -------------------------------------------------------------- |
| **Core file existence**   | Error   | Missing required core files                                    |
| **Non-empty content**     | Error   | Template files never filled in                                 |
| **Frontmatter schema**    | Warning | Malformed or missing metadata                                  |
| **Freshness**             | Warning | Files past staleness threshold                                 |
| **Completeness score**    | Info    | Percentage of core files with substantial content (>100 words) |
| **Consistency**           | Warning | Name in identity.md doesn't match other files                  |
| **Git status**            | Info    | Uncommitted changes in portfolio                               |
| **Decision log validity** | Warning | Malformed JSONL entries in decision-log                        |

#### Validation Output

```
$ mudra validate

Portfolio Health Report
═══════════════════════
Core Files (required):
  ✓ identity.md                fresh (updated 2 days ago)
  ✓ tools-and-systems.md       fresh (updated 45 days ago)
  ✓ communication-style.md     fresh (updated 60 days ago)
  ✓ preferences-and-constraints fresh (updated 30 days ago)

Extended Files (opt-in):
  ✗ current-projects.md        STALE (updated 35 days ago, threshold: 21)
  ✓ team-and-relationships.md  fresh (updated 10 days ago)
  ○ role-and-responsibilities  NOT ADDED (run `mudra add role-and-responsibilities`)
  ○ goals-and-priorities       NOT ADDED
  ○ domain-knowledge           NOT ADDED
  ○ decision-log               NOT ADDED

Core completeness: 4/4 filled (100%)
Freshness: 4/5 active files current (80%)
Git: 2 uncommitted changes
Overall: Good — run `mudra edit current-projects` to fix staleness
```

---

### 7. Interview Engine (Phase 3 — v1.2+)

The interview engine drives structured Q&A to produce high-quality portfolio files. It is a convenience layer — not required for portfolio creation. Users can always create and maintain files manually via `mudra edit`.

#### Interview Flow

```mermaid
flowchart TD
    A[mudra interview --file identity] --> B{Portfolio file exists?}
    B -->|No| C[Load interview protocol for file]
    B -->|Yes| D[Load existing content + protocol]

    C --> E[Initialize LLM conversation]
    D --> E

    E --> F[Ask question 1 of N]
    F --> G[User responds]
    G --> H{Response specific enough?}

    H -->|No| I[Push for specificity]
    I --> G

    H -->|Yes| J{More questions?}
    J -->|Yes| K[Ask next question]
    K --> G

    J -->|No| L[Synthesize answers into markdown]
    L --> M[Present draft to user]
    M --> N{User satisfied?}

    N -->|No| O[Collect feedback]
    O --> P[Revise draft]
    P --> M

    N -->|Yes| Q[Write file to portfolio store]
    Q --> R[Git commit: "mudra: refresh {file} via interview"]
    R --> S[Update freshness.json]
    S --> T[Done]
```

#### Interview Protocol Structure

Each file has a dedicated interview protocol:

```python
PROTOCOLS: dict[str, InterviewProtocol] = {
    "identity": InterviewProtocol(
        intro="Let's capture who you are in a way that gives any AI agent immediate context.",
        questions=[
            "What's your name and current role/title?",
            "What organization do you work for, and what does it do?",
            "In one paragraph, how would you describe what you actually do day-to-day?",
            "What are you known for professionally? What do people come to you for?",
            "What's the one thing an AI agent must know about you to be useful?",
        ],
        push_for_specificity=[
            "Can you give a concrete example?",
            "What does that look like in practice?",
            "Who specifically? What specifically?",
        ],
        synthesis_instruction=(
            "Write a concise identity summary in first person. "
            "No bullet lists — flowing prose. "
            "Should sound like the user, not like an AI profile."
        ),
    ),
}
```

#### LLM Provider Abstraction

```toml
# config.toml
[interview]
provider = "anthropic"            # anthropic | openai | ollama
model = "claude-sonnet-4-20250514"
temperature = 0.3                 # low temperature for deterministic synthesis
max_questions_per_file = 8        # cap on interview length

[interview.providers.anthropic]
# Uses ANTHROPIC_API_KEY env var

[interview.providers.openai]
# Uses OPENAI_API_KEY env var

[interview.providers.ollama]
base_url = "http://localhost:11434"
model = "llama3.1:8b"
```

---

## System Workflow

### Full User Workflow (End-to-End)

```mermaid
flowchart TD
    subgraph Setup ["Phase 1: Setup"]
        A["Install: uv tool install mudra"] --> B["mudra init"]
        B --> C{Start from template?}
        C -->|Yes| D["mudra init --template engineer"]
        C -->|No| E["mudra init — empty portfolio"]
        D --> F["4 core template files + git init"]
        E --> F
    end

    subgraph Create ["Phase 2: Create Core Portfolio"]
        F --> G["mudra edit identity"]
        G --> H["User fills core files in $EDITOR"]
        H --> I["mudra edit tools-and-systems"]
        I --> J["mudra edit communication-style"]
        J --> K["mudra edit preferences-and-constraints"]
        K --> L["Core portfolio complete — 4 files"]
    end

    subgraph Serve ["Phase 3: Serve Context"]
        L --> M{How to serve?}
        M -->|MCP| N["mudra serve — starts MCP server"]
        M -->|Export| O["mudra export --format system-prompt"]
        M -->|Manual| P["Copy files into Claude Project / system prompt"]
        N --> Q["Add to Claude Code / Cursor MCP config"]
        Q --> R["Agents pull context on demand"]
        O --> S["Paste into target platform"]
        P --> S
    end

    subgraph Extend ["Phase 4: Extend When Needed"]
        R --> T{"Need more context?"}
        T -->|Yes| U["mudra add current-projects"]
        U --> V["mudra edit current-projects"]
        V --> R
        T -->|No| W["mudra status — periodic freshness check"]
        W --> X{Stale files?}
        X -->|Yes| Y["mudra edit current-projects"]
        X -->|No| Z["No action needed"]
        Y --> R
    end
```

### MCP Client Configuration Workflow

```mermaid
sequenceDiagram
    participant User
    participant CLI as mudra CLI
    participant Config as MCP Client Config
    participant Server as mudra MCP Server
    participant Agent as AI Agent

    User->>CLI: mudra serve
    CLI->>Server: Start MCP server (stdio)

    User->>Config: Add to settings.json / .cursor/mcp.json
    Note over Config: { "mcpServers": { "mudra": { "command": "mudra", "args": ["serve"] } } }

    Agent->>Server: resources/list
    Server-->>Agent: Available files + roles (core + active extended)

    Agent->>Server: resources/read (mudra://portfolio/role/code-review)
    Server-->>Agent: identity + communication-style + tools-and-systems + preferences

    Agent->>User: Response informed by personal context
```

### Decision Log Workflow

```mermaid
flowchart LR
    A["mudra log 'Chose Click over Typer'"] --> B["Parse args"]
    B --> C["Create JSONL entry"]
    C --> D["Append to decision-log.jsonl"]
    D --> E["Git commit: 'mudra: log decision'"]
    E --> F["Update freshness.json"]
```

---

## Data Flow

### Read Path (MCP Resource Request)

```mermaid
flowchart LR
    A[MCP Client] -->|resources/read| B[MCP Server]
    B --> C{URI type}
    C -->|Single file| D[Read file from store]
    C -->|Role-based| E[Resolve role → files]
    E --> F[Filter to existing files]
    F --> D
    D --> G[Check freshness]
    G --> H{Stale?}
    H -->|Yes| I[Append warning]
    H -->|No| J[Return content]
    I --> J
```

### Write Path (Editor)

```mermaid
flowchart LR
    A[User] -->|mudra edit| B["Open in $EDITOR"]
    B -->|Save + close| C[Detect changes]
    C --> D{Changed?}
    D -->|Yes| E[Write file]
    E --> F["Git commit"]
    F --> G[Update freshness.json]
    D -->|No| H[No-op]
```

### Export Path

```mermaid
flowchart LR
    A["mudra export --role code-review --format system-prompt"] --> B[Router]
    B --> C[Resolve role → file list]
    C --> D[Filter to existing files]
    D --> E[Read files]
    E --> F[Format for target]
    F --> G{Output}
    G -->|stdout| H[Terminal]
    G -->|--output file| I[File on disk]
```

---

## Technology Stack

| Component           | Technology                | Rationale                                       |
| ------------------- | ------------------------- | ----------------------------------------------- |
| **Language**        | Python 3.12+              | Largest AI tooling community, matches ecosystem |
| **Package manager** | uv                        | Project standard, fast, reliable                |
| **CLI framework**   | click                     | Lightweight, composable, well-documented        |
| **MCP SDK**         | mcp (Python)              | Official Anthropic MCP SDK                      |
| **LLM calls**       | litellm or direct SDKs    | Provider abstraction for interview engine       |
| **Config**          | tomli / tomli-w           | TOML parsing (stdlib in 3.11+)                  |
| **Validation**      | pydantic                  | Schema validation for frontmatter and config    |
| **Versioning**      | gitpython (or subprocess) | Git operations for portfolio history            |
| **Distribution**    | PyPI via uv               | `uv tool install mudra`                         |
| **Testing**         | pytest                    | Project standard                                |
| **Linting**         | ruff                      | Project standard                                |
| **Type checking**   | mypy --strict             | Project standard                                |

---

## Project Structure

```text
mudra/
├── pyproject.toml
├── LICENSE                          # MIT
├── README.md
├── justfile                         # Task automation
├── src/
│   └── mudra/
│       ├── __init__.py
│       ├── cli.py                   # Click CLI entry point
│       ├── config.py                # Config loading (config.toml)
│       ├── store.py                 # Portfolio store (read/write files, freshness, git)
│       ├── tiers.py                 # Core/extended file definitions
│       ├── git.py                   # Git operations (init, commit, log, diff)
│       ├── decision_log.py          # JSONL append, read, filter for decision-log
│       ├── interview/
│       │   ├── __init__.py
│       │   ├── engine.py            # Interview state machine
│       │   ├── protocols.py         # Per-file question sets
│       │   ├── specificity.py       # Push-for-specificity logic
│       │   └── synthesizer.py       # Answer → markdown synthesis
│       ├── mcp/
│       │   ├── __init__.py
│       │   ├── server.py            # MCP server (stdio + SSE)
│       │   └── resources.py         # Resource handlers
│       ├── router/
│       │   ├── __init__.py
│       │   ├── selector.py          # Role → file mapping resolution
│       │   └── metadata.py          # Routing usage tracking
│       ├── export/
│       │   ├── __init__.py
│       │   ├── system_prompt.py
│       │   ├── claude_project.py
│       │   ├── api_payload.py
│       │   └── markdown.py
│       └── validate/
│           ├── __init__.py
│           └── checks.py            # All validation logic
├── templates/                       # Built-in file templates
│   ├── core/
│   │   ├── identity.md
│   │   ├── tools-and-systems.md
│   │   ├── communication-style.md
│   │   └── preferences-and-constraints.md
│   └── extended/
│       ├── role-and-responsibilities.md
│       ├── current-projects.md
│       ├── team-and-relationships.md
│       ├── goals-and-priorities.md
│       ├── domain-knowledge.md
│       └── decision-log.md          # Template with JSONL format example
├── community-templates/             # Role-based starter templates
│   ├── engineer/
│   ├── manager/
│   ├── designer/
│   ├── founder/
│   └── consultant/
├── tests/
│   ├── test_cli.py
│   ├── test_store.py
│   ├── test_git.py
│   ├── test_decision_log.py
│   ├── test_interview.py
│   ├── test_mcp_server.py
│   ├── test_router.py
│   ├── test_export.py
│   └── test_validate.py
└── .github/
    └── workflows/
        ├── ci.yml                   # Lint + type check + test
        └── release.yml              # PyPI publish on tag
```

---

## Configuration

### `config.toml` (Full Schema)

```toml
[portfolio]
path = "~/.mudra"                    # Portfolio directory location
version = "1.0.0"                    # Schema version

[interview]
provider = "anthropic"               # LLM provider for interviews
model = "claude-sonnet-4-20250514"   # Model for synthesis
temperature = 0.3                    # Low temp for deterministic output
max_questions_per_file = 8           # Cap on interview length

[interview.providers.anthropic]
# Uses ANTHROPIC_API_KEY env var

[interview.providers.openai]
# Uses OPENAI_API_KEY env var

[interview.providers.ollama]
base_url = "http://localhost:11434"
model = "llama3.1:8b"

[mcp]
transport = "stdio"                  # stdio | sse
port = 3100                          # For SSE mode

[freshness]
check_on_serve = true                # Warn about stale files in MCP responses
default_staleness_days = 30          # Default if not specified per-file

[freshness.thresholds]
identity = 90
tools-and-systems = 60
communication-style = 90
preferences-and-constraints = 60
role-and-responsibilities = 60
current-projects = 21
team-and-relationships = 30
goals-and-priorities = 30
domain-knowledge = 90
decision-log = 30

[routing_metadata]
track_usage = true                   # Log role requests locally
log_overrides = true                 # Log user overrides of role mappings
log_path = ".mudra/routing_usage.jsonl"

[export]
default_format = "system-prompt"
default_role = "general-assistant"
```

---

## Security Considerations

| Concern                   | Design Decision                                                                                                                                                                                             |
| ------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Data locality**         | All files stored locally. No cloud sync, no telemetry, no account required.                                                                                                                                 |
| **API keys**              | Stored in environment variables, never in config files. Config references providers, not credentials.                                                                                                       |
| **MCP access**            | Read-only in V1. No write tools until conflict resolution and trust boundaries are properly specified.                                                                                                      |
| **Remote serving (SSE)**  | No authentication built-in. Users deploying remotely must add their own auth layer (reverse proxy, SSH tunnel). Documentation warns explicitly.                                                             |
| **Portfolio content**     | May contain sensitive information (team names, project details). `~/.mudra/` is gitignored globally by `mudra init`. The portfolio's own `.gitignore` excludes `.mudra/config.toml` (provider preferences). |
| **Interview transcripts** | Not stored. Only the final synthesized markdown is persisted. Raw Q&A is ephemeral.                                                                                                                         |
| **Git history**           | Local-only by default. No automatic push to remote. Users opt-in to remote backup explicitly.                                                                                                               |
| **Routing metadata**      | Local-only JSONL. Never transmitted. Opt-out via `track_usage = false`.                                                                                                                                     |

---

## Extension Points

### Community Templates

Users can contribute role-based starter templates:

```text
community-templates/
├── data-scientist/
│   ├── core/
│   │   ├── identity.md          # Pre-filled with data science framing
│   │   └── tools-and-systems.md # Common DS stack (pandas, jupyter, etc.)
│   └── extended/
│       └── domain-knowledge.md  # ML/stats terminology
├── product-manager/
├── devops-engineer/
└── ...
```

Install: `mudra init --template data-scientist`

### Custom Routing Roles

Users add roles in `routing.toml`:

```toml
[roles.my-custom-role]
files = ["identity", "domain-knowledge", "decision-log"]
description = "Context for domain-specific decision-making"
```

### Armory Bridge (Optional)

For users of [Armory](https://github.com/Mathews-Tom/armory), a thin bridge skill detects `mudra` and connects context to armory packages:

```yaml
# armory/skills/mudra-bridge/SKILL.md
---
name: mudra-bridge
description: Detects and integrates personal context from mudra CLI
metadata:
  version: 1.0.0
  category: context
  tags: [personal-context, portfolio, identity, mcp]
---
```

This is an optional integration — neither project depends on the other.

### Plugin Architecture (Future)

The engine is designed for extensibility without requiring it at launch:

- **Custom dimensions** — users can add files beyond the core 4 + extended 6
- **Custom interview protocols** — override question sets per file
- **Custom export formats** — register new formatters
- **Custom validators** — add domain-specific checks
- **MCP write tools** — append-only updates with per-file allowlists (V2, informed by routing metadata)
