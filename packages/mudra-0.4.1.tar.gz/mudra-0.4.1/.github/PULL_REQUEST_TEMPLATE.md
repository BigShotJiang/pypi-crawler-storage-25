## Summary
<!-- 1-3 bullet points describing what this PR does -->

## Changes
<!-- List the key changes -->

## Test Plan
<!-- How was this tested? -->
- [ ] All existing tests pass (`uv run pytest`)
- [ ] New tests added for new functionality
- [ ] `uv run ruff check src/ tests/` passes
- [ ] `uv run mypy --strict src/mudra/` passes
