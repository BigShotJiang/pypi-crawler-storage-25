from __future__ import annotations

from pathlib import Path

import pytest

from mudra.git import (
    create_gitignore,
    git_add,
    git_commit,
    git_diff,
    git_has_changes,
    git_init,
    git_log,
)


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    """Initialize a git repo in a temp dir with initial commit."""
    git_init(tmp_path)
    # Configure git user for commits in test env
    import subprocess

    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.name", "Test User"], cwd=tmp_path, check=True)
    return tmp_path


def test_git_init_creates_repo(tmp_path: Path) -> None:
    git_init(tmp_path)
    assert (tmp_path / ".git").is_dir()


def test_git_init_idempotent(tmp_path: Path) -> None:
    git_init(tmp_path)
    git_init(tmp_path)
    assert (tmp_path / ".git").is_dir()


def test_git_add_and_commit(git_repo: Path) -> None:
    (git_repo / "test.txt").write_text("hello")
    git_add(git_repo, "test.txt")
    result = git_commit(git_repo, "add test file")
    assert result is True


def test_git_commit_nothing_to_commit(git_repo: Path) -> None:
    # Need at least one commit first
    (git_repo / "initial.txt").write_text("init")
    git_add(git_repo, "initial.txt")
    git_commit(git_repo, "initial")

    result = git_commit(git_repo, "empty commit")
    assert result is False


def test_git_add_no_files(git_repo: Path) -> None:
    # Should not raise
    git_add(git_repo)


def test_git_log_empty_repo(git_repo: Path) -> None:
    logs = git_log(git_repo)
    assert logs == []


def test_git_log_returns_entries(git_repo: Path) -> None:
    (git_repo / "a.txt").write_text("a")
    git_add(git_repo, "a.txt")
    git_commit(git_repo, "first commit")

    (git_repo / "b.txt").write_text("b")
    git_add(git_repo, "b.txt")
    git_commit(git_repo, "second commit")

    logs = git_log(git_repo)
    assert len(logs) == 2
    assert logs[0]["message"] == "second commit"
    assert logs[1]["message"] == "first commit"
    assert "hash" in logs[0]
    assert "date" in logs[0]


def test_git_log_for_specific_file(git_repo: Path) -> None:
    (git_repo / "a.txt").write_text("a")
    git_add(git_repo, "a.txt")
    git_commit(git_repo, "add a")

    (git_repo / "b.txt").write_text("b")
    git_add(git_repo, "b.txt")
    git_commit(git_repo, "add b")

    logs = git_log(git_repo, file="a.txt")
    assert len(logs) == 1
    assert logs[0]["message"] == "add a"


def test_git_diff_empty(git_repo: Path) -> None:
    diff = git_diff(git_repo)
    assert diff == ""


def test_git_diff_shows_changes(git_repo: Path) -> None:
    (git_repo / "file.txt").write_text("original")
    git_add(git_repo, "file.txt")
    git_commit(git_repo, "add file")

    (git_repo / "file.txt").write_text("modified")
    diff = git_diff(git_repo)
    assert "modified" in diff


def test_git_has_changes_false_in_clean_repo(git_repo: Path) -> None:
    (git_repo / "file.txt").write_text("content")
    git_add(git_repo, "file.txt")
    git_commit(git_repo, "initial")
    assert git_has_changes(git_repo) is False


def test_git_has_changes_true_with_modifications(git_repo: Path) -> None:
    (git_repo / "file.txt").write_text("content")
    assert git_has_changes(git_repo) is True


def test_create_gitignore(tmp_path: Path) -> None:
    create_gitignore(tmp_path)
    gitignore = tmp_path / ".gitignore"
    assert gitignore.exists()
    content = gitignore.read_text()
    assert ".mudra/config.toml" in content
