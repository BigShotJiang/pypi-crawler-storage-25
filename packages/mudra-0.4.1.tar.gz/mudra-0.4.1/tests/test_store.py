from __future__ import annotations

from pathlib import Path

import pytest

from mudra.store import PortfolioStore


def test_default_path_is_home_mudra() -> None:
    store = PortfolioStore()
    assert store.path == Path.home() / ".mudra"


def test_explicit_path_overrides_default(tmp_path: Path) -> None:
    store = PortfolioStore(path=tmp_path / "custom")
    assert store.path == tmp_path / "custom"


def test_profile_path_resolves_correctly() -> None:
    store = PortfolioStore(profile="work")
    assert store.path == Path.home() / ".mudra" / "profiles" / "work"


def test_explicit_path_overrides_profile(tmp_path: Path) -> None:
    store = PortfolioStore(path=tmp_path / "explicit", profile="work")
    assert store.path == tmp_path / "explicit"


def test_metadata_dir(tmp_portfolio: PortfolioStore) -> None:
    assert tmp_portfolio.metadata_dir == tmp_portfolio.path / ".mudra"


def test_ensure_dirs_creates_directories(tmp_path: Path) -> None:
    store = PortfolioStore(path=tmp_path / "new" / "portfolio")
    store.ensure_dirs()
    assert store.path.is_dir()
    assert store.metadata_dir.is_dir()


def test_file_path_markdown(tmp_portfolio: PortfolioStore) -> None:
    fp = tmp_portfolio.file_path("identity")
    assert fp == tmp_portfolio.path / "identity.md"


def test_file_path_jsonl(tmp_portfolio: PortfolioStore) -> None:
    fp = tmp_portfolio.file_path("decision-log")
    assert fp == tmp_portfolio.path / "decision-log.jsonl"


def test_file_path_raises_for_invalid(tmp_portfolio: PortfolioStore) -> None:
    with pytest.raises(ValueError, match="Unknown portfolio file"):
        tmp_portfolio.file_path("bogus")


def test_file_exists_false_when_missing(tmp_portfolio: PortfolioStore) -> None:
    assert not tmp_portfolio.file_exists("identity")


def test_file_exists_true_after_write(tmp_portfolio: PortfolioStore) -> None:
    tmp_portfolio.write_file("identity", "test content")
    assert tmp_portfolio.file_exists("identity")


def test_file_exists_false_for_invalid_name(tmp_portfolio: PortfolioStore) -> None:
    assert not tmp_portfolio.file_exists("bogus")


def test_list_files_empty(tmp_portfolio: PortfolioStore) -> None:
    assert tmp_portfolio.list_files() == []


def test_list_files_after_write(tmp_portfolio: PortfolioStore) -> None:
    tmp_portfolio.write_file("identity", "content")
    tmp_portfolio.write_file("decision-log", "content")
    files = tmp_portfolio.list_files()
    assert "identity" in files
    assert "decision-log" in files


def test_list_core_files(tmp_portfolio: PortfolioStore) -> None:
    tmp_portfolio.write_file("identity", "content")
    tmp_portfolio.write_file("current-projects", "content")
    core = tmp_portfolio.list_core_files()
    assert core == ["identity"]


def test_list_extended_files(tmp_portfolio: PortfolioStore) -> None:
    tmp_portfolio.write_file("identity", "content")
    tmp_portfolio.write_file("current-projects", "content")
    extended = tmp_portfolio.list_extended_files()
    assert extended == ["current-projects"]


def test_read_file_returns_content(tmp_portfolio: PortfolioStore) -> None:
    tmp_portfolio.write_file("identity", "hello world")
    assert tmp_portfolio.read_file("identity") == "hello world"


def test_read_file_raises_when_missing(tmp_portfolio: PortfolioStore) -> None:
    with pytest.raises(FileNotFoundError, match="Portfolio file not found"):
        tmp_portfolio.read_file("identity")


def test_write_file_creates_file(tmp_portfolio: PortfolioStore) -> None:
    tmp_portfolio.write_file("identity", "content here")
    assert tmp_portfolio.file_path("identity").read_text() == "content here"


def test_write_file_overwrites(tmp_portfolio: PortfolioStore) -> None:
    tmp_portfolio.write_file("identity", "first")
    tmp_portfolio.write_file("identity", "second")
    assert tmp_portfolio.read_file("identity") == "second"


def test_create_from_template(tmp_portfolio: PortfolioStore) -> None:
    templates_dir = PortfolioStore.resolve_templates_dir() / "core"
    tmp_portfolio.create_from_template("identity", templates_dir)
    content = tmp_portfolio.read_file("identity")
    assert "dimension: identity" in content


def test_create_from_template_raises_for_missing_template(
    tmp_portfolio: PortfolioStore, tmp_path: Path
) -> None:
    with pytest.raises(FileNotFoundError, match="Template not found"):
        tmp_portfolio.create_from_template("identity", tmp_path / "nonexistent")


def test_resolve_templates_dir() -> None:
    templates_dir = PortfolioStore.resolve_templates_dir()
    assert templates_dir.name == "templates"
    assert (templates_dir / "core" / "identity.md").exists()


def test_list_community_templates() -> None:
    templates = PortfolioStore.list_community_templates()
    assert "engineer" in templates
    assert "manager" in templates
    assert "designer" in templates


def test_load_template_metadata() -> None:
    meta = PortfolioStore.load_template_metadata("engineer")
    assert meta["name"] == "engineer"
    assert "description" in meta
    assert "author" in meta


def test_load_template_metadata_missing() -> None:
    with pytest.raises(FileNotFoundError, match="Template not found"):
        PortfolioStore.load_template_metadata("nonexistent-template")
