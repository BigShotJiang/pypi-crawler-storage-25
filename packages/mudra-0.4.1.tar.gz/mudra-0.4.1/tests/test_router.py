from __future__ import annotations

from pathlib import Path

from mudra.router.metadata import RoutingMetadata
from mudra.router.selector import (
    DEFAULT_ROLES,
    RoleConfig,
    RoutingConfig,
    generate_routing_toml,
    list_roles,
    load_routing_config,
    resolve_role,
)
from mudra.store import PortfolioStore

# -- Role resolution --


class TestResolveRole:
    def test_resolve_known_role(self, initialized_portfolio: PortfolioStore) -> None:
        config = RoutingConfig()
        result = resolve_role("code-review", config, initialized_portfolio)
        # code-review requires: identity, communication-style, tools-and-systems,
        # preferences-and-constraints -- all core files present in initialized_portfolio
        expected = [
            "identity",
            "communication-style",
            "tools-and-systems",
            "preferences-and-constraints",
        ]
        assert result == expected

    def test_resolve_unknown_role_falls_back_to_general_assistant(
        self, initialized_portfolio: PortfolioStore
    ) -> None:
        config = RoutingConfig()
        result = resolve_role("nonexistent-role", config, initialized_portfolio)
        ga_files = DEFAULT_ROLES["general-assistant"].files
        expected = [f for f in ga_files if initialized_portfolio.file_exists(f)]
        assert result == expected

    def test_resolve_full_role_returns_all_existing_files(
        self, initialized_portfolio: PortfolioStore
    ) -> None:
        config = RoutingConfig()
        result = resolve_role("full", config, initialized_portfolio)
        assert result == initialized_portfolio.list_files()

    def test_resolve_skips_missing_extended_files(
        self, initialized_portfolio: PortfolioStore
    ) -> None:
        config = RoutingConfig()
        result = resolve_role("meeting-prep", config, initialized_portfolio)
        # meeting-prep wants: identity, team-and-relationships, current-projects,
        # goals-and-priorities. Only identity exists in initialized_portfolio.
        assert result == ["identity"]

    def test_resolve_empty_portfolio_returns_nothing(self, tmp_portfolio: PortfolioStore) -> None:
        config = RoutingConfig()
        result = resolve_role("code-review", config, tmp_portfolio)
        assert result == []

    def test_resolve_deduplicates_files(self, initialized_portfolio: PortfolioStore) -> None:
        role = RoleConfig(
            description="test",
            files=["identity", "identity", "communication-style"],
        )
        config = RoutingConfig(roles={"duped": role})
        result = resolve_role("duped", config, initialized_portfolio)
        assert result == ["identity", "communication-style"]

    def test_resolve_preserves_order(self, initialized_portfolio: PortfolioStore) -> None:
        role = RoleConfig(
            description="test",
            files=[
                "preferences-and-constraints",
                "identity",
                "tools-and-systems",
            ],
        )
        config = RoutingConfig(roles={"ordered": role})
        result = resolve_role("ordered", config, initialized_portfolio)
        assert result == [
            "preferences-and-constraints",
            "identity",
            "tools-and-systems",
        ]

    def test_resolve_with_extended_files_present(
        self, initialized_portfolio: PortfolioStore
    ) -> None:
        initialized_portfolio.write_file("team-and-relationships", "# Team")
        initialized_portfolio.write_file("current-projects", "# Projects")
        initialized_portfolio.write_file("goals-and-priorities", "# Goals")
        config = RoutingConfig()
        result = resolve_role("meeting-prep", config, initialized_portfolio)
        assert result == [
            "identity",
            "team-and-relationships",
            "current-projects",
            "goals-and-priorities",
        ]


# -- Config loading --


class TestConfigLoading:
    def test_load_default_config(self, tmp_path: Path) -> None:
        config = load_routing_config(tmp_path / "nonexistent.toml")
        assert "general-assistant" in config.roles
        assert "full" in config.roles
        assert config.roles == DEFAULT_ROLES

    def test_load_custom_config_from_toml(self, tmp_path: Path) -> None:
        toml_path = tmp_path / "routing.toml"
        custom = RoutingConfig(
            roles={
                "custom-role": RoleConfig(
                    description="A custom role",
                    files=["identity", "domain-knowledge"],
                ),
            }
        )
        toml_path.write_text(generate_routing_toml(custom), encoding="utf-8")
        loaded = load_routing_config(toml_path)
        assert "custom-role" in loaded.roles
        assert loaded.roles["custom-role"].files == ["identity", "domain-knowledge"]

    def test_load_missing_file_returns_default(self, tmp_path: Path) -> None:
        config = load_routing_config(tmp_path / "does-not-exist.toml")
        assert config == RoutingConfig()

    def test_generate_routing_toml_roundtrip(self, tmp_path: Path) -> None:
        original = RoutingConfig()
        toml_str = generate_routing_toml(original)
        toml_path = tmp_path / "routing.toml"
        toml_path.write_text(toml_str, encoding="utf-8")
        loaded = load_routing_config(toml_path)
        assert loaded.roles.keys() == original.roles.keys()
        for name in original.roles:
            assert loaded.roles[name].files == original.roles[name].files
            assert loaded.roles[name].description == original.roles[name].description


# -- Metadata --


class TestRoutingMetadata:
    def test_log_routing_event(self, tmp_path: Path) -> None:
        metadata = RoutingMetadata(tmp_path)
        metadata.log_request(
            role="code-review",
            files_requested=["identity", "tools-and-systems"],
            files_served=["identity"],
        )
        events = metadata.read_events()
        assert len(events) == 1
        assert events[0].role == "code-review"
        assert events[0].files_missing == ["tools-and-systems"]

    def test_read_events(self, tmp_path: Path) -> None:
        metadata = RoutingMetadata(tmp_path)
        metadata.log_request("role-a", ["identity"], ["identity"])
        metadata.log_request("role-b", ["identity"], [])
        events = metadata.read_events()
        assert len(events) == 2
        assert events[0].role == "role-a"
        assert events[1].role == "role-b"

    def test_read_events_with_limit(self, tmp_path: Path) -> None:
        metadata = RoutingMetadata(tmp_path)
        for i in range(5):
            metadata.log_request(f"role-{i}", [], [])
        events = metadata.read_events(max_entries=2)
        assert len(events) == 2
        assert events[0].role == "role-3"
        assert events[1].role == "role-4"

    def test_summary_counts(self, tmp_path: Path) -> None:
        metadata = RoutingMetadata(tmp_path)
        metadata.log_request("code-review", [], [])
        metadata.log_request("code-review", [], [])
        metadata.log_request("full", [], [])
        summary = metadata.summary()
        assert summary == {"code-review": 2, "full": 1}

    def test_metadata_empty_log(self, tmp_path: Path) -> None:
        metadata = RoutingMetadata(tmp_path)
        assert metadata.read_events() == []
        assert metadata.summary() == {}


# -- Role listing --


class TestListRoles:
    def test_list_roles_returns_all_defaults(self) -> None:
        config = RoutingConfig()
        roles = list_roles(config)
        assert set(roles.keys()) == set(DEFAULT_ROLES.keys())

    def test_list_roles_includes_custom(self) -> None:
        custom = RoleConfig(description="Custom", files=["identity"])
        config = RoutingConfig(
            roles={
                **DEFAULT_ROLES,
                "my-custom": custom,
            }
        )
        roles = list_roles(config)
        assert "my-custom" in roles
        assert roles["my-custom"].files == ["identity"]


# -- Routing Analytics --


class TestRoutingAnalytics:
    def test_most_requested_roles_empty(self, tmp_path: Path) -> None:
        meta = RoutingMetadata(tmp_path)
        assert meta.most_requested_roles() == []

    def test_most_requested_roles_sorted(self, tmp_path: Path) -> None:
        meta = RoutingMetadata(tmp_path)
        meta.log_request("code-review", ["identity", "tools"], ["identity", "tools"])
        meta.log_request("code-review", ["identity", "tools"], ["identity", "tools"])
        meta.log_request("meeting-prep", ["identity"], ["identity"])
        top = meta.most_requested_roles()
        assert top[0] == ("code-review", 2)
        assert top[1] == ("meeting-prep", 1)

    def test_most_requested_roles_limit(self, tmp_path: Path) -> None:
        meta = RoutingMetadata(tmp_path)
        for i in range(10):
            meta.log_request(f"role-{i}", [], [])
        assert len(meta.most_requested_roles(limit=3)) == 3

    def test_most_missing_files_empty(self, tmp_path: Path) -> None:
        meta = RoutingMetadata(tmp_path)
        assert meta.most_missing_files() == []

    def test_most_missing_files_counts(self, tmp_path: Path) -> None:
        meta = RoutingMetadata(tmp_path)
        meta.log_request("meeting-prep", ["identity", "team", "goals"], ["identity"])
        meta.log_request("meeting-prep", ["identity", "team", "goals"], ["identity"])
        missing = meta.most_missing_files()
        assert ("team", 2) in missing
        assert ("goals", 2) in missing

    def test_format_report_empty(self, tmp_path: Path) -> None:
        meta = RoutingMetadata(tmp_path)
        assert "No routing data" in meta.format_report()

    def test_format_report_with_data(self, tmp_path: Path) -> None:
        meta = RoutingMetadata(tmp_path)
        meta.log_request("code-review", ["identity", "tools"], ["identity", "tools"])
        report = meta.format_report()
        assert "code-review" in report
        assert "Routing Analytics" in report
