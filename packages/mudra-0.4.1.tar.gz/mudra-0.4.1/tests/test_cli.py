from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from mudra.cli import main
from mudra.config import InterviewConfig
from mudra.router.selector import DEFAULT_ROLES
from mudra.store import PortfolioStore
from mudra.tiers import CORE_FILES


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def portfolio_path(tmp_path: Path) -> str:
    return str(tmp_path / "portfolio")


def invoke_init(runner: CliRunner, path: str) -> None:
    """Run mudra init and assert success."""
    result = runner.invoke(main, ["--path", path, "init"])
    assert result.exit_code == 0, result.output + result.stderr


def test_version_flag(runner: CliRunner) -> None:
    from mudra import __version__

    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.output


def test_init_creates_portfolio(runner: CliRunner, portfolio_path: str) -> None:
    result = runner.invoke(main, ["--path", portfolio_path, "init"])
    assert result.exit_code == 0
    assert Path(portfolio_path).is_dir()


def test_init_creates_core_files(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    store = PortfolioStore(path=Path(portfolio_path))
    for name in CORE_FILES:
        assert store.file_exists(name), f"Core file missing: {name}"


def test_init_creates_git_repo(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    assert (Path(portfolio_path) / ".git").is_dir()


def test_init_creates_config(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    assert (Path(portfolio_path) / ".mudra" / "config.toml").exists()


def test_init_creates_routing(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    assert (Path(portfolio_path) / ".mudra" / "routing.toml").exists()


def test_init_creates_freshness(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    assert (Path(portfolio_path) / ".mudra" / "freshness.json").exists()


def test_init_already_exists(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "init"])
    assert result.exit_code != 0
    combined = result.output.lower() + result.stderr.lower()
    assert "already initialized" in combined


def test_init_with_template_engineer(runner: CliRunner, portfolio_path: str) -> None:
    result = runner.invoke(main, ["--path", portfolio_path, "init", "--template", "engineer"])
    assert result.exit_code == 0, result.output + (result.stderr or "")
    store = PortfolioStore(path=Path(portfolio_path))
    for name in CORE_FILES:
        assert store.file_exists(name), f"Core file missing: {name}"
    content = store.read_file("identity")
    assert "software engineer" in content


def test_init_with_template_creates_extended_files(runner: CliRunner, portfolio_path: str) -> None:
    result = runner.invoke(main, ["--path", portfolio_path, "init", "--template", "engineer"])
    assert result.exit_code == 0, result.output + (result.stderr or "")
    store = PortfolioStore(path=Path(portfolio_path))
    assert store.file_exists("domain-knowledge")


def test_init_with_invalid_template(runner: CliRunner, portfolio_path: str) -> None:
    result = runner.invoke(main, ["--path", portfolio_path, "init", "--template", "nonexistent"])
    assert result.exit_code != 0
    combined = result.output + (result.stderr or "")
    assert "Unknown template" in combined


def test_templates_command_lists_available(runner: CliRunner) -> None:
    result = runner.invoke(main, ["templates"])
    assert result.exit_code == 0
    assert "engineer" in result.output
    assert "manager" in result.output
    assert "designer" in result.output


def test_add_extended_file(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "add", "current-projects"])
    assert result.exit_code == 0, result.output + result.stderr
    store = PortfolioStore(path=Path(portfolio_path))
    assert store.file_exists("current-projects")


def test_add_invalid_file(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "add", "nonexistent-file"])
    assert result.exit_code != 0


def test_add_duplicate_file(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    runner.invoke(main, ["--path", portfolio_path, "add", "current-projects"])
    result = runner.invoke(main, ["--path", portfolio_path, "add", "current-projects"])
    assert result.exit_code != 0
    assert "already exists" in result.output.lower() or "already exists" in result.stderr.lower()


def test_add_core_file(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "add", "identity"])
    assert result.exit_code != 0
    assert "core file" in result.output.lower() or "core file" in result.stderr.lower()


def test_status_fresh_portfolio(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "status"])
    assert result.exit_code == 0
    assert "Core files: 4/4" in result.output


def test_status_json_output(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "status", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["core_files"]["present"] == 4
    assert data["core_files"]["total"] == 4


def test_validate_complete_portfolio(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    # Write meaningful content to each core file
    store = PortfolioStore(path=Path(portfolio_path))
    for name in CORE_FILES:
        store.write_file(name, "This is substantial content for validation testing purposes.")
    result = runner.invoke(main, ["--path", portfolio_path, "validate"])
    assert result.exit_code == 0


def test_validate_missing_core_file(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    # Delete a core file
    store = PortfolioStore(path=Path(portfolio_path))
    store.file_path("identity").unlink()
    result = runner.invoke(main, ["--path", portfolio_path, "validate"])
    assert result.exit_code != 0
    assert "missing core file" in result.output.lower()


def test_validate_strict_mode(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    # Core files with template content trigger "empty/template-only" warnings
    # In strict mode these become errors
    result = runner.invoke(main, ["--path", portfolio_path, "validate", "--strict"])
    # May pass or fail depending on template content length, just ensure it runs
    assert result.exit_code in (0, 1)


def test_history_shows_commits(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "history"])
    assert result.exit_code == 0
    assert "initialize portfolio" in result.output


def test_history_no_git(runner: CliRunner, tmp_path: Path) -> None:
    path = str(tmp_path / "bare")
    Path(path).mkdir()
    (Path(path) / ".mudra").mkdir()
    result = runner.invoke(main, ["--path", path, "history"])
    assert result.exit_code != 0


def test_roles_lists_roles(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "roles"])
    assert result.exit_code == 0
    assert "general-assistant" in result.output


def test_roles_verbose(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "roles", "--verbose"])
    assert result.exit_code == 0
    # "full" role has files=["*"] which renders as "(all files)"
    assert "(all files)" in result.output


def test_config_get(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(
        main, ["--path", portfolio_path, "config", "get", "freshness.default_staleness_days"]
    )
    assert result.exit_code == 0
    assert "30" in result.output


def test_config_set(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(
        main,
        ["--path", portfolio_path, "config", "set", "freshness.default_staleness_days", "45"],
    )
    assert result.exit_code == 0
    result = runner.invoke(
        main, ["--path", portfolio_path, "config", "get", "freshness.default_staleness_days"]
    )
    assert "45" in result.output


def test_log_append_decision(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "log", "Use FastAPI"])
    assert result.exit_code == 0, result.output + result.stderr
    assert "logged" in result.output.lower()


def test_log_list_decisions(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    runner.invoke(main, ["--path", portfolio_path, "log", "Decision Alpha"])
    result = runner.invoke(main, ["--path", portfolio_path, "log", "--list"])
    assert result.exit_code == 0
    assert "Decision Alpha" in result.output


def test_log_filter_by_tag(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    runner.invoke(main, ["--path", portfolio_path, "log", "Use Docker", "--tags", "infra,deploy"])
    runner.invoke(main, ["--path", portfolio_path, "log", "Use React", "--tags", "frontend"])
    result = runner.invoke(main, ["--path", portfolio_path, "log", "--tag", "infra"])
    assert result.exit_code == 0
    assert "Use Docker" in result.output
    assert "Use React" not in result.output


def test_log_with_context(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(
        main,
        ["--path", portfolio_path, "log", "Migrate to Postgres", "--context", "Need JSONB"],
    )
    assert result.exit_code == 0


def test_export_system_prompt(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "export", "--format", "system-prompt"])
    assert result.exit_code == 0
    assert "<user_context>" in result.output
    assert "</user_context>" in result.output


def test_export_markdown(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "export", "--format", "markdown"])
    assert result.exit_code == 0
    assert "## Identity" in result.output


def test_export_api_payload(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "export", "--format", "api-payload"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "mudra_version" in data
    assert "exported_at" in data
    assert "files" in data


def test_export_to_file(runner: CliRunner, portfolio_path: str, tmp_path: Path) -> None:
    invoke_init(runner, portfolio_path)
    output_file = str(tmp_path / "export.md")
    result = runner.invoke(
        main,
        ["--path", portfolio_path, "export", "--format", "markdown", "--output", output_file],
    )
    assert result.exit_code == 0
    assert Path(output_file).exists()
    content = Path(output_file).read_text(encoding="utf-8")
    assert "## Identity" in content


def test_export_claude_project(runner: CliRunner, portfolio_path: str, tmp_path: Path) -> None:
    invoke_init(runner, portfolio_path)
    output_dir = str(tmp_path / "claude-project")
    result = runner.invoke(
        main,
        [
            "--path",
            portfolio_path,
            "export",
            "--format",
            "claude-project",
            "--output",
            output_dir,
        ],
    )
    assert result.exit_code == 0
    assert Path(output_dir).is_dir()
    exported_files = list(Path(output_dir).iterdir())
    assert len(exported_files) == len(CORE_FILES)


def test_serve_requires_init(runner: CliRunner, tmp_path: Path) -> None:
    path = str(tmp_path / "empty-portfolio")
    result = runner.invoke(main, ["--path", path, "serve"])
    assert result.exit_code != 0
    combined = result.output + (result.stderr or "")
    assert "mudra init" in combined.lower() or "no portfolio" in combined.lower()


def test_serve_starts_server(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    mock_run = MagicMock()
    with patch("mudra.mcp.run_server", mock_run):
        result = runner.invoke(main, ["--path", portfolio_path, "serve"])
    assert result.exit_code == 0, result.output + (result.stderr or "")
    mock_run.assert_called_once()


def test_interview_config_defaults() -> None:
    iv = InterviewConfig()
    assert iv.provider == "anthropic"
    assert iv.model == "claude-sonnet-4-20250514"
    assert iv.temperature == 0.3
    assert iv.max_questions_per_file == 8


def test_interview_requires_file_flag(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "interview"])
    assert result.exit_code != 0
    assert "Missing option" in result.output or "missing" in result.output.lower()


def test_interview_requires_init(runner: CliRunner, portfolio_path: str) -> None:
    result = runner.invoke(main, ["--path", portfolio_path, "interview", "--file", "identity"])
    assert result.exit_code != 0
    assert "no portfolio found" in result.output.lower() or "mudra init" in result.output.lower()


def test_interview_invalid_file(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "interview", "--file", "nonexistent"])
    assert result.exit_code != 0
    assert "Unknown file" in result.output


def test_interview_runs_engine(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)

    mock_result = MagicMock()
    mock_result.draft = "# Identity\nTest content"

    mock_engine = MagicMock()
    mock_engine.run.return_value = mock_result
    mock_engine.session_path.return_value = (
        Path(portfolio_path) / ".mudra" / "interview_session_identity.json"
    )

    mock_synthesizer_class = MagicMock(return_value=MagicMock())
    mock_engine_class = MagicMock(return_value=mock_engine)
    mock_session_class = MagicMock()

    mock_interview_module = MagicMock()
    mock_interview_module.Synthesizer = mock_synthesizer_class
    mock_interview_module.InterviewEngine = mock_engine_class
    mock_interview_module.InterviewSession = mock_session_class

    with patch.dict("sys.modules", {"mudra.interview": mock_interview_module}):
        result = runner.invoke(main, ["--path", portfolio_path, "interview", "--file", "identity"])

    assert result.exit_code == 0, result.output
    assert "Saved" in result.output or "identity" in result.output
    mock_engine.run.assert_called_once()


def test_edit_opens_editor(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    with patch("click.edit", return_value="Updated identity content here."):
        result = runner.invoke(main, ["--path", portfolio_path, "edit", "identity"])
    assert result.exit_code == 0, result.output + result.stderr
    assert "updated" in result.output.lower()


def test_edit_no_changes(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    with patch("click.edit", return_value=None):
        result = runner.invoke(main, ["--path", portfolio_path, "edit", "identity"])
    assert result.exit_code == 0
    assert "no changes" in result.output.lower()


def test_edit_invalid_file(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "edit", "nonexistent"])
    assert result.exit_code != 0


def test_edit_missing_extended_file(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "edit", "current-projects"])
    assert result.exit_code != 0
    assert "mudra add" in result.output.lower() or "mudra add" in result.stderr.lower()


def test_roles_lists_default_roles(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "roles"])
    assert result.exit_code == 0
    for role_name in DEFAULT_ROLES:
        assert role_name in result.output


def test_roles_verbose_shows_files(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(main, ["--path", portfolio_path, "roles", "--verbose"])
    assert result.exit_code == 0
    # code-review role lists specific files
    assert "tools-and-systems" in result.output
    assert "identity" in result.output


def test_export_with_role_filter(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(
        main, ["--path", portfolio_path, "export", "--format", "markdown", "--role", "code-review"]
    )
    assert result.exit_code == 0
    # code-review role includes identity and communication-style
    assert "Identity" in result.output
    assert "Communication Style" in result.output


def test_export_with_unknown_role_falls_back(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    result = runner.invoke(
        main,
        ["--path", portfolio_path, "export", "--format", "markdown", "--role", "nonexistent-role"],
    )
    assert result.exit_code == 0
    # Unknown role falls back to general-assistant which includes identity
    assert "Identity" in result.output


def test_init_creates_routing_with_default_roles(runner: CliRunner, portfolio_path: str) -> None:
    invoke_init(runner, portfolio_path)
    import tomllib

    routing_path = Path(portfolio_path) / ".mudra" / "routing.toml"
    with routing_path.open("rb") as f:
        data = tomllib.load(f)
    roles_data = data.get("roles", {})
    assert len(roles_data) == len(DEFAULT_ROLES)
    for role_name in DEFAULT_ROLES:
        assert role_name in roles_data
