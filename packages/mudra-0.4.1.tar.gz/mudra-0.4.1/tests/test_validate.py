from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta

from mudra.freshness import FileStatus, FreshnessTracker
from mudra.store import PortfolioStore
from mudra.tiers import CORE_FILES
from mudra.validate.checks import (
    CheckResult,
    Severity,
    ValidationReport,
    check_completeness_score,
    check_core_files_exist,
    check_decision_log_valid,
    check_files_not_empty,
    check_freshness,
    check_frontmatter_valid,
    check_git_status,
    run_all_checks,
)

REAL_CONTENT = (
    "---\n"
    "dimension: identity\n"
    "tier: core\n"
    "version: 1\n"
    "---\n\n"
    "I am a software engineer with over ten years of experience building "
    "distributed systems and backend services. My primary focus is on Python "
    "and Go, and I work extensively with cloud-native architectures on AWS. "
    "I lead a platform team of six engineers at a fintech startup where we "
    "handle payment processing and fraud detection. I am known for writing "
    "clean, well-tested code and for being a strong advocate of automated "
    "testing and continuous delivery. My day-to-day involves architecture "
    "reviews, mentoring junior engineers, and writing critical-path code. "
    "The one thing every AI agent must know about me is that I value "
    "precision and directness above all else. I do not tolerate vague "
    "answers or hand-wavy explanations. Give me the exact command, the "
    "exact path, the exact line number.\n"
)


def _write_real_content(store: PortfolioStore, name: str, content: str = REAL_CONTENT) -> None:
    store.write_file(name, content)


def _make_tracker(store: PortfolioStore) -> FreshnessTracker:
    tracker = FreshnessTracker(store.metadata_dir)
    tracker.load()
    return tracker


# --- check_core_files_exist ---


def test_check_core_files_all_present(initialized_portfolio: PortfolioStore) -> None:
    results = check_core_files_exist(initialized_portfolio)
    assert len(results) == 0


def test_check_core_files_missing(tmp_portfolio: PortfolioStore) -> None:
    results = check_core_files_exist(tmp_portfolio)
    assert len(results) == len(CORE_FILES)
    for r in results:
        assert r.severity is Severity.ERROR
        assert r.file in CORE_FILES


# --- check_files_not_empty ---


def test_check_files_not_empty_with_content(initialized_portfolio: PortfolioStore) -> None:
    for name in CORE_FILES:
        _write_real_content(initialized_portfolio, name)
    results = check_files_not_empty(initialized_portfolio)
    assert len(results) == 0


def test_check_files_not_empty_template_only(initialized_portfolio: PortfolioStore) -> None:
    # Templates have only frontmatter + HTML comments, no real content
    results = check_files_not_empty(initialized_portfolio)
    assert len(results) == len(CORE_FILES)
    for r in results:
        assert r.severity is Severity.ERROR


# --- check_frontmatter_valid ---


def test_check_frontmatter_valid(initialized_portfolio: PortfolioStore) -> None:
    for name in CORE_FILES:
        _write_real_content(initialized_portfolio, name)
    results = check_frontmatter_valid(initialized_portfolio)
    assert len(results) == 0


def test_check_frontmatter_malformed(initialized_portfolio: PortfolioStore) -> None:
    initialized_portfolio.write_file(
        "identity",
        "---\ndimension: identity\ntier: [invalid yaml\n---\nSome content here.\n",
    )
    results = check_frontmatter_valid(initialized_portfolio)
    malformed = [r for r in results if r.file == "identity"]
    assert len(malformed) == 1
    assert malformed[0].severity is Severity.WARNING


# --- check_freshness ---


def test_check_freshness_all_fresh(initialized_portfolio: PortfolioStore) -> None:
    tracker = _make_tracker(initialized_portfolio)
    for name in CORE_FILES:
        tracker.update(name)
    tracker.save()
    results = check_freshness(initialized_portfolio, tracker)
    assert len(results) == 0


def test_check_freshness_stale_files(initialized_portfolio: PortfolioStore) -> None:
    tracker = _make_tracker(initialized_portfolio)
    stale_date = datetime.now(tz=UTC) - timedelta(days=365)
    tracker._data["identity"] = FileStatus(
        last_updated=stale_date,
        staleness_days=90,
    )
    tracker.save()
    results = check_freshness(initialized_portfolio, tracker)
    stale_results = [r for r in results if r.file == "identity"]
    assert len(stale_results) == 1
    assert stale_results[0].severity is Severity.WARNING


# --- check_completeness_score ---


def test_check_completeness_full(initialized_portfolio: PortfolioStore) -> None:
    for name in CORE_FILES:
        _write_real_content(initialized_portfolio, name)
    results = check_completeness_score(initialized_portfolio)
    assert len(results) == 1
    assert "100%" in results[0].message


def test_check_completeness_partial(initialized_portfolio: PortfolioStore) -> None:
    # Templates have very few words -- all below 100
    results = check_completeness_score(initialized_portfolio)
    assert len(results) == 1
    assert "0%" in results[0].message


# --- check_git_status ---


def test_check_git_status_clean(initialized_portfolio: PortfolioStore) -> None:
    results = check_git_status(initialized_portfolio)
    assert len(results) == 1
    assert results[0].severity is Severity.INFO
    assert "clean" in results[0].message


def test_check_git_status_dirty(initialized_portfolio: PortfolioStore) -> None:
    # Write a new file to make git dirty
    initialized_portfolio.write_file("identity", "dirty content\n")
    results = check_git_status(initialized_portfolio)
    assert len(results) == 1
    assert results[0].severity is Severity.INFO
    assert "uncommitted" in results[0].message.lower()


# --- check_decision_log_valid ---


def test_check_decision_log_valid_entries(initialized_portfolio: PortfolioStore) -> None:
    log_content = (
        json.dumps({"date": "2024-01-01", "decision": "Use PostgreSQL", "context": "Need ACID"})
        + "\n"
        + json.dumps({"date": "2024-02-01", "decision": "Use Redis", "context": "Caching"})
        + "\n"
    )
    initialized_portfolio.write_file("decision-log", log_content)
    results = check_decision_log_valid(initialized_portfolio)
    assert len(results) == 0


def test_check_decision_log_malformed_entries(initialized_portfolio: PortfolioStore) -> None:
    log_content = (
        json.dumps({"date": "2024-01-01", "decision": "Use PostgreSQL"})
        + "\n"
        + "this is not valid json\n"
        + json.dumps({"date": "2024-03-01", "decision": "Use S3"})
        + "\n"
    )
    initialized_portfolio.write_file("decision-log", log_content)
    results = check_decision_log_valid(initialized_portfolio)
    assert len(results) == 1
    assert results[0].severity is Severity.WARNING
    assert "Line 2" in results[0].message


# --- run_all_checks ---


def test_run_all_checks_clean_portfolio(initialized_portfolio: PortfolioStore) -> None:
    for name in CORE_FILES:
        _write_real_content(initialized_portfolio, name)
    tracker = _make_tracker(initialized_portfolio)
    for name in CORE_FILES:
        tracker.update(name)
    tracker.save()
    # Commit the content so git is clean
    from mudra.git import git_add, git_commit

    git_add(initialized_portfolio.path, ".")
    git_commit(initialized_portfolio.path, "add content")

    report = run_all_checks(initialized_portfolio, tracker)
    assert not report.has_errors
    assert not report.has_warnings


def test_run_all_checks_with_issues(tmp_portfolio: PortfolioStore) -> None:
    tracker = _make_tracker(tmp_portfolio)
    report = run_all_checks(tmp_portfolio, tracker)
    assert report.has_errors
    assert len(report.errors) == len(CORE_FILES)


# --- exit_code ---


def test_exit_code_no_errors() -> None:
    report = ValidationReport(
        results=[
            CheckResult(severity=Severity.INFO, file=None, message="All good"),
        ]
    )
    assert report.exit_code() == 0


def test_exit_code_with_errors() -> None:
    report = ValidationReport(
        results=[
            CheckResult(severity=Severity.ERROR, file="identity", message="Missing"),
        ]
    )
    assert report.exit_code() == 1


def test_exit_code_strict_with_warnings() -> None:
    report = ValidationReport(
        results=[
            CheckResult(severity=Severity.WARNING, file="identity", message="Stale"),
        ]
    )
    assert report.exit_code(strict=False) == 0
    assert report.exit_code(strict=True) == 1


# --- format_text / format_json ---


def test_format_text_output() -> None:
    report = ValidationReport(
        results=[
            CheckResult(severity=Severity.ERROR, file="identity", message="Missing file"),
            CheckResult(
                severity=Severity.WARNING,
                file=None,
                message="Something",
                suggestion="Fix it",
            ),
            CheckResult(severity=Severity.INFO, file=None, message="All fine"),
        ]
    )
    text = report.format_text()
    assert "[ERROR] identity:" in text
    assert "[WARN]" in text
    assert "[INFO]" in text
    assert "-> Fix it" in text


def test_format_json_output() -> None:
    report = ValidationReport(
        results=[
            CheckResult(severity=Severity.ERROR, file="identity", message="Missing file"),
        ]
    )
    data = json.loads(report.format_json())
    assert len(data) == 1
    assert data[0]["severity"] == "error"
    assert data[0]["file"] == "identity"


# --- file_filter ---


def test_file_filter(initialized_portfolio: PortfolioStore) -> None:
    _write_real_content(initialized_portfolio, "identity")
    tracker = _make_tracker(initialized_portfolio)
    tracker.update("identity")
    tracker.save()

    report = run_all_checks(initialized_portfolio, tracker, file_filter="identity")
    # Should only contain results about identity (or portfolio-level)
    for r in report.results:
        if r.file is not None:
            assert r.file == "identity"
