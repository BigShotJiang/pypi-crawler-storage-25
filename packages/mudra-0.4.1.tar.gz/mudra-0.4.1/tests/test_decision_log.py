from __future__ import annotations

from pathlib import Path

import pytest

from mudra.decision_log import DecisionLog
from mudra.store import PortfolioStore


@pytest.fixture
def log_store(tmp_path: Path) -> PortfolioStore:
    store = PortfolioStore(path=tmp_path / "portfolio")
    store.ensure_dirs()
    return store


def test_append_entry(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    entry = log.append("Use PostgreSQL for persistence")
    assert entry.decision == "Use PostgreSQL for persistence"
    assert entry.context is None
    assert entry.tags == []
    assert entry.date  # non-empty


def test_append_with_tags(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    entry = log.append("Switch to uv", tags=["tooling", "python"])
    assert entry.tags == ["tooling", "python"]


def test_append_with_context(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    entry = log.append("Adopt FastAPI", context="Need async support")
    assert entry.context == "Need async support"


def test_read_entries(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    log.append("Decision A")
    log.append("Decision B")
    entries = log.read()
    assert len(entries) == 2
    assert entries[0].decision == "Decision A"
    assert entries[1].decision == "Decision B"


def test_read_empty_log(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    entries = log.read()
    assert entries == []


def test_read_max_entries(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    log.append("A")
    log.append("B")
    log.append("C")
    entries = log.read(max_entries=2)
    assert len(entries) == 2
    assert entries[0].decision == "B"
    assert entries[1].decision == "C"


def test_filter_by_tag(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    log.append("Use Docker", tags=["infra"])
    log.append("Use k8s", tags=["infra", "orchestration"])
    log.append("Use React", tags=["frontend"])
    results = log.filter_by_tag("infra")
    assert len(results) == 2
    assert results[0].decision == "Use Docker"
    assert results[1].decision == "Use k8s"


def test_filter_no_matches(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    log.append("Use Python", tags=["language"])
    results = log.filter_by_tag("nonexistent")
    assert results == []


def test_render_markdown(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    log.append("Use Postgres", context="Relational data", tags=["db"])
    md = log.render_markdown()
    assert "| Date |" in md
    assert "Use Postgres" in md
    assert "Relational data" in md
    assert "db" in md


def test_render_markdown_empty(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    md = log.render_markdown()
    assert md == "No decisions logged."


def test_skip_malformed_jsonl(
    log_store: PortfolioStore,
    capsys: pytest.CaptureFixture[str],
) -> None:
    log = DecisionLog(log_store)
    log.append("Valid entry")
    log_path = log_store.file_path("decision-log")
    with log_path.open("a", encoding="utf-8") as f:
        f.write("this is not json\n")
    log.append("Another valid")

    entries = log.read()
    assert len(entries) == 2
    assert entries[0].decision == "Valid entry"
    assert entries[1].decision == "Another valid"

    captured = capsys.readouterr()
    assert "malformed" in captured.err.lower()


def test_date_auto_generated(log_store: PortfolioStore) -> None:
    log = DecisionLog(log_store)
    entry = log.append("Test date generation")
    # Date must be YYYY-MM-DD format
    parts = entry.date.split("-")
    assert len(parts) == 3
    assert len(parts[0]) == 4
    assert len(parts[1]) == 2
    assert len(parts[2]) == 2
