from __future__ import annotations

import pytest

from mudra.tiers import (
    ALL_FILES,
    CORE_FILES,
    DEFAULT_STALENESS_DAYS,
    EXTENDED_FILES,
    get_file_extension,
    is_core,
    is_extended,
    is_valid_file,
)


def test_core_files_count() -> None:
    assert len(CORE_FILES) == 4


def test_extended_files_count() -> None:
    assert len(EXTENDED_FILES) == 6


def test_all_files_is_union_of_core_and_extended() -> None:
    assert ALL_FILES == CORE_FILES + EXTENDED_FILES


def test_no_duplicates_in_all_files() -> None:
    assert len(ALL_FILES) == len(set(ALL_FILES))


def test_is_core_returns_true_for_core_files() -> None:
    for name in CORE_FILES:
        assert is_core(name), f"{name} should be core"


def test_is_core_returns_false_for_extended_files() -> None:
    for name in EXTENDED_FILES:
        assert not is_core(name), f"{name} should not be core"


def test_is_core_returns_false_for_unknown() -> None:
    assert not is_core("nonexistent")


def test_is_extended_returns_true_for_extended_files() -> None:
    for name in EXTENDED_FILES:
        assert is_extended(name), f"{name} should be extended"


def test_is_extended_returns_false_for_core_files() -> None:
    for name in CORE_FILES:
        assert not is_extended(name), f"{name} should not be extended"


def test_is_valid_file_returns_true_for_all_files() -> None:
    for name in ALL_FILES:
        assert is_valid_file(name), f"{name} should be valid"


def test_is_valid_file_returns_false_for_unknown() -> None:
    assert not is_valid_file("nonexistent")


def test_get_file_extension_markdown() -> None:
    assert get_file_extension("identity") == ".md"
    assert get_file_extension("tools-and-systems") == ".md"


def test_get_file_extension_jsonl_for_decision_log() -> None:
    assert get_file_extension("decision-log") == ".jsonl"


def test_get_file_extension_raises_for_unknown() -> None:
    with pytest.raises(ValueError, match="Unknown portfolio file"):
        get_file_extension("nonexistent")


def test_staleness_days_covers_all_files() -> None:
    for name in ALL_FILES:
        assert name in DEFAULT_STALENESS_DAYS, f"Missing staleness config for {name}"


def test_staleness_days_are_positive() -> None:
    for name, days in DEFAULT_STALENESS_DAYS.items():
        assert days > 0, f"Staleness days for {name} must be positive"
