from __future__ import annotations

from pathlib import Path

import pytest

from mudra.config import default_config, save_config
from mudra.git import create_gitignore, git_add, git_commit, git_init
from mudra.store import PortfolioStore
from mudra.tiers import CORE_FILES


@pytest.fixture
def tmp_portfolio(tmp_path: Path) -> PortfolioStore:
    """Empty portfolio store in temp dir."""
    store = PortfolioStore(path=tmp_path / "portfolio")
    store.ensure_dirs()
    return store


@pytest.fixture
def initialized_portfolio(tmp_portfolio: PortfolioStore) -> PortfolioStore:
    """Portfolio with init completed (4 core templates, git, config)."""
    templates_dir = PortfolioStore.resolve_templates_dir()
    core_template_dir = templates_dir / "core"

    for name in CORE_FILES:
        tmp_portfolio.create_from_template(name, core_template_dir)

    config = default_config()
    config_path = tmp_portfolio.metadata_dir / "config.toml"
    save_config(config, config_path)

    git_init(tmp_portfolio.path)
    create_gitignore(tmp_portfolio.path)
    git_add(tmp_portfolio.path, ".")
    git_commit(tmp_portfolio.path, "mudra init")

    return tmp_portfolio
