from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from mudra.interview.engine import InterviewEngine, InterviewSession, InterviewState
from mudra.interview.protocols import PROTOCOLS, InterviewProtocol, get_protocol
from mudra.interview.specificity import is_specific_enough
from mudra.interview.synthesizer import Synthesizer
from mudra.store import PortfolioStore
from mudra.tiers import ALL_FILES

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_litellm() -> MagicMock:  # type: ignore[type-arg]
    with patch("mudra.interview.synthesizer.litellm") as mock:
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Synthesized content here."
        mock.completion.return_value = mock_response
        yield mock


@pytest.fixture
def synthesizer() -> Synthesizer:
    return Synthesizer()


# ---------------------------------------------------------------------------
# Protocol tests
# ---------------------------------------------------------------------------


class TestProtocols:
    def test_all_files_have_protocols(self) -> None:
        for file_name in ALL_FILES:
            assert file_name in PROTOCOLS, f"Missing protocol for {file_name}"

    def test_get_protocol_known_file(self) -> None:
        protocol = get_protocol("identity")
        assert isinstance(protocol, InterviewProtocol)
        assert len(protocol.questions) > 0

    def test_get_protocol_unknown_file_raises(self) -> None:
        with pytest.raises(KeyError, match="No interview protocol for file"):
            get_protocol("nonexistent-file")

    def test_protocol_has_required_fields(self) -> None:
        for name, protocol in PROTOCOLS.items():
            assert protocol.intro, f"{name}: empty intro"
            assert protocol.questions, f"{name}: empty questions"
            assert protocol.synthesis_instruction, f"{name}: empty synthesis_instruction"

    def test_protocol_push_for_specificity_defaults(self) -> None:
        protocol = get_protocol("identity")
        assert len(protocol.push_for_specificity) == 3


# ---------------------------------------------------------------------------
# Specificity tests
# ---------------------------------------------------------------------------


class TestSpecificity:
    def test_specific_enough_with_detailed_response(self) -> None:
        response = (
            "I use Python 3.12 with FastAPI for backend services, "
            "PostgreSQL for persistence, and deploy on AWS ECS."
        )
        assert is_specific_enough(response) is True

    def test_not_specific_enough_too_short(self) -> None:
        assert is_specific_enough("yes") is False
        assert is_specific_enough("I code") is False

    def test_not_specific_enough_too_vague(self) -> None:
        response = "I usually do various stuff with things and basically etc"
        assert is_specific_enough(response) is False

    def test_specific_enough_at_boundary(self) -> None:
        # Exactly MIN_WORD_COUNT words, none vague
        response = "Python FastAPI PostgreSQL AWS Docker"
        assert is_specific_enough(response) is True

    def test_not_specific_boundary_word_count(self) -> None:
        # 4 words (below MIN_WORD_COUNT=5)
        response = "Python and some tools"
        assert is_specific_enough(response) is False


# ---------------------------------------------------------------------------
# Synthesizer tests
# ---------------------------------------------------------------------------


class TestSynthesizer:
    def test_synthesize_calls_litellm(
        self,
        synthesizer: Synthesizer,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        protocol = get_protocol("identity")
        answers = {"What's your name?": "Alice"}
        synthesizer.synthesize(file_name="identity", protocol=protocol, answers=answers)
        mock_litellm.completion.assert_called_once()

    def test_synthesize_returns_content(
        self,
        synthesizer: Synthesizer,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        protocol = get_protocol("identity")
        answers = {"What's your name?": "Alice"}
        result = synthesizer.synthesize(file_name="identity", protocol=protocol, answers=answers)
        assert result == "Synthesized content here."

    def test_synthesize_with_existing_content(
        self,
        synthesizer: Synthesizer,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        protocol = get_protocol("identity")
        answers = {"What's your name?": "Alice"}
        result = synthesizer.synthesize(
            file_name="identity",
            protocol=protocol,
            answers=answers,
            existing_content="Old content to merge.",
        )
        assert result == "Synthesized content here."
        call_args = mock_litellm.completion.call_args
        system_msg = call_args.kwargs["messages"][0]["content"]
        assert "Old content to merge." in system_msg

    def test_synthesize_empty_response_raises(
        self,
        synthesizer: Synthesizer,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        mock_litellm.completion.return_value.choices[0].message.content = None
        protocol = get_protocol("identity")
        with pytest.raises(RuntimeError, match="LLM returned empty response"):
            synthesizer.synthesize(
                file_name="identity",
                protocol=protocol,
                answers={"Q": "A"},
            )

    def test_revise_calls_litellm(
        self,
        synthesizer: Synthesizer,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        protocol = get_protocol("identity")
        synthesizer.revise(content="Draft text.", feedback="Make it shorter.", protocol=protocol)
        mock_litellm.completion.assert_called_once()

    def test_revise_returns_revised_content(
        self,
        synthesizer: Synthesizer,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        mock_litellm.completion.return_value.choices[0].message.content = "Revised text."
        protocol = get_protocol("identity")
        result = synthesizer.revise(
            content="Draft text.", feedback="Make it shorter.", protocol=protocol
        )
        assert result == "Revised text."

    def test_revise_empty_response_raises(
        self,
        synthesizer: Synthesizer,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        mock_litellm.completion.return_value.choices[0].message.content = None
        protocol = get_protocol("identity")
        with pytest.raises(RuntimeError, match="LLM returned empty response"):
            synthesizer.revise(content="Draft text.", feedback="Fix it.", protocol=protocol)

    def test_synthesize_ollama_model_prefix(
        self,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        synth = Synthesizer(provider="ollama", model="llama3")
        protocol = get_protocol("identity")
        synth.synthesize(file_name="identity", protocol=protocol, answers={"Q": "A"})
        call_args = mock_litellm.completion.call_args
        assert call_args.kwargs["model"] == "ollama/llama3"


# ---------------------------------------------------------------------------
# Engine tests
# ---------------------------------------------------------------------------


class TestEngine:
    def _make_engine(
        self,
        store: PortfolioStore,
        answers: list[str],
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> tuple[InterviewEngine, list[str]]:
        answer_iter = iter(answers)
        output: list[str] = []
        engine = InterviewEngine(
            store=store,
            synthesizer=Synthesizer(),
            input_fn=lambda _: next(answer_iter),
            output_fn=lambda msg: output.append(msg),
        )
        return engine, output

    def test_engine_intro_state(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        # Run with a session already past INTRO
        session = InterviewSession(
            file_name="identity",
            state=InterviewState.COMPLETE,
        )
        engine, output = self._make_engine(tmp_portfolio, [], mock_litellm)
        result = engine.run("identity", session=session)
        assert result.state == InterviewState.COMPLETE
        # No intro message should appear for COMPLETE state
        assert not any("Let's capture who you are" in o for o in output)

    def test_engine_asking_collects_answers(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        protocol = get_protocol("identity")
        # Provide enough answers for all questions + "yes" for review
        answers = [
            "Alice Smith, Senior Engineer at TechCorp building infrastructure",
            "TechCorp, builds developer tools for enterprise teams",
            "I design and build distributed systems for internal platform tooling",
            "Architecture and system design for complex distributed systems",
            "I need precise, technical responses without hand-holding",
            "yes",
        ]
        engine, _ = self._make_engine(tmp_portfolio, answers, mock_litellm)
        session = engine.run("identity")
        assert len(session.answers) == len(protocol.questions)

    def test_engine_skip_question(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        protocol = get_protocol("identity")
        num_q = len(protocol.questions)
        # Skip first question, answer the rest
        answers = (
            ["skip"]
            + [
                f"Detailed answer number {i} with enough words to pass specificity"
                for i in range(1, num_q)
            ]
            + ["yes"]
        )
        engine, _ = self._make_engine(tmp_portfolio, answers, mock_litellm)
        session = engine.run("identity")
        assert len(session.answers) == num_q - 1

    def test_engine_specificity_retry(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        # Use a protocol with fewer questions for simplicity
        protocol = get_protocol("goals-and-priorities")
        num_q = len(protocol.questions)
        # First question: vague answer, then detailed. Rest: detailed. Then accept.
        answers = (
            [
                "stuff",  # vague, triggers retry
                "Increase deployment frequency by 50% this quarter using automated pipelines",
            ]
            + [
                f"Detailed goal answer number {i} providing enough specifics to pass"
                for i in range(1, num_q)
            ]
            + ["yes"]
        )
        engine, output = self._make_engine(tmp_portfolio, answers, mock_litellm)
        session = engine.run("goals-and-priorities")
        assert session.state == InterviewState.COMPLETE
        # Check that a specificity prompt was shown
        assert any("specific" in o.lower() or "example" in o.lower() for o in output)

    def test_engine_synthesize_state(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        session = InterviewSession(
            file_name="identity",
            state=InterviewState.SYNTHESIZING,
            answers={"Q1": "A1"},
        )
        engine, output = self._make_engine(tmp_portfolio, ["yes"], mock_litellm)
        result = engine.run("identity", session=session)
        assert result.draft == "Synthesized content here."
        assert any("Synthesizing" in o for o in output)

    def test_engine_review_accept(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        session = InterviewSession(
            file_name="identity",
            state=InterviewState.REVIEWING,
            answers={"Q1": "A1"},
            draft="Draft content.",
        )
        engine, _ = self._make_engine(tmp_portfolio, ["yes"], mock_litellm)
        result = engine.run("identity", session=session)
        assert result.state == InterviewState.COMPLETE
        assert result.draft == "Draft content."

    def test_engine_review_reject(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        session = InterviewSession(
            file_name="identity",
            state=InterviewState.REVIEWING,
            answers={"Q1": "A1"},
            draft="Draft content.",
        )
        engine, output = self._make_engine(tmp_portfolio, ["no"], mock_litellm)
        result = engine.run("identity", session=session)
        assert result.state == InterviewState.COMPLETE
        assert result.draft is None
        assert any("rejected" in o.lower() for o in output)

    def test_engine_review_with_feedback(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        mock_litellm.completion.return_value.choices[0].message.content = "Revised draft."
        session = InterviewSession(
            file_name="identity",
            state=InterviewState.REVIEWING,
            answers={"Q1": "A1"},
            draft="Draft content.",
        )
        engine, output = self._make_engine(tmp_portfolio, ["Make it shorter", "yes"], mock_litellm)
        result = engine.run("identity", session=session)
        assert result.state == InterviewState.COMPLETE
        assert result.draft == "Revised draft."
        assert any("Revising" in o for o in output)

    def test_engine_full_flow(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        answers = [
            "John Doe, Principal Engineer at TechCorp building developer tools",
            "TechCorp builds enterprise developer productivity tools for large teams",
            "I design distributed systems and lead architecture reviews every day",
            "Architecture and system design expertise in distributed computing",
            "Context about my technical preferences matters most for usefulness",
            "yes",
        ]
        engine, _ = self._make_engine(tmp_portfolio, answers, mock_litellm)
        session = engine.run("identity")
        assert session.state == InterviewState.COMPLETE
        assert session.draft is not None

    def test_engine_max_revisions_reached(
        self,
        tmp_portfolio: PortfolioStore,
        mock_litellm: MagicMock,  # type: ignore[type-arg]
    ) -> None:
        mock_litellm.completion.return_value.choices[0].message.content = "Revised again."
        session = InterviewSession(
            file_name="identity",
            state=InterviewState.REVIEWING,
            answers={"Q1": "A1"},
            draft="Draft.",
        )
        # 3 rounds of feedback, none accepted -> hits max revisions
        engine, output = self._make_engine(
            tmp_portfolio,
            ["feedback1", "feedback2", "feedback3"],
            mock_litellm,
        )
        result = engine.run("identity", session=session)
        assert result.state == InterviewState.COMPLETE
        assert any("Maximum revisions" in o for o in output)


# ---------------------------------------------------------------------------
# Session persistence tests
# ---------------------------------------------------------------------------


class TestSessionPersistence:
    def test_session_save_and_load(self, tmp_path: Path) -> None:
        session = InterviewSession(
            file_name="identity",
            state=InterviewState.ASKING,
            current_question_index=2,
            answers={"Q1": "A1", "Q2": "A2"},
        )
        save_path = tmp_path / "session.json"
        session.save(save_path)

        loaded = InterviewSession.load(save_path)
        assert loaded.file_name == "identity"
        assert loaded.state == InterviewState.ASKING
        assert loaded.current_question_index == 2
        assert loaded.answers == {"Q1": "A1", "Q2": "A2"}

    def test_session_save_creates_dirs(self, tmp_path: Path) -> None:
        session = InterviewSession(file_name="identity")
        save_path = tmp_path / "nested" / "deep" / "session.json"
        session.save(save_path)
        assert save_path.exists()
        data = json.loads(save_path.read_text(encoding="utf-8"))
        assert data["file_name"] == "identity"

    def test_session_roundtrip_with_draft(self, tmp_path: Path) -> None:
        session = InterviewSession(
            file_name="tools-and-systems",
            state=InterviewState.REVIEWING,
            draft="Some draft content.",
            answers={"Q": "A"},
        )
        save_path = tmp_path / "session.json"
        session.save(save_path)
        loaded = InterviewSession.load(save_path)
        assert loaded.draft == "Some draft content."
        assert loaded.state == InterviewState.REVIEWING

    def test_session_path_method(self, tmp_portfolio: PortfolioStore) -> None:
        engine = InterviewEngine(
            store=tmp_portfolio,
            synthesizer=Synthesizer(),
            input_fn=lambda _: "",
            output_fn=lambda _: None,
        )
        path = engine.session_path("identity")
        assert path.name == "interview_session_identity.json"
        assert path.parent == tmp_portfolio.metadata_dir
