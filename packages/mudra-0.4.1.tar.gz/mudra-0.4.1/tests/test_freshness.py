from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

from mudra.freshness import FileStatus, FreshnessTracker


def test_file_status_unknown_when_no_update() -> None:
    status = FileStatus()
    assert status.status == "unknown"
    assert status.days_since_update is None


def test_file_status_fresh_when_recently_updated() -> None:
    status = FileStatus(
        last_updated=datetime.now(tz=UTC),
        staleness_days=30,
    )
    assert status.status == "fresh"
    assert status.days_since_update == 0


def test_file_status_stale_when_old() -> None:
    old_date = datetime.now(tz=UTC) - timedelta(days=60)
    status = FileStatus(
        last_updated=old_date,
        staleness_days=30,
    )
    assert status.status == "stale"
    assert status.days_since_update is not None
    assert status.days_since_update >= 60


def test_file_status_fresh_at_boundary() -> None:
    boundary_date = datetime.now(tz=UTC) - timedelta(days=29)
    status = FileStatus(
        last_updated=boundary_date,
        staleness_days=30,
    )
    assert status.status == "fresh"


def test_tracker_load_empty(tmp_path: Path) -> None:
    tracker = FreshnessTracker(tmp_path)
    data = tracker.load()
    assert data == {}


def test_tracker_update_and_save(tmp_path: Path) -> None:
    tracker = FreshnessTracker(tmp_path)
    tracker.load()
    tracker.update("identity")
    tracker.save()

    tracker2 = FreshnessTracker(tmp_path)
    data = tracker2.load()
    assert "identity" in data
    assert data["identity"].status == "fresh"


def test_tracker_get_status_untracked(tmp_path: Path) -> None:
    tracker = FreshnessTracker(tmp_path)
    tracker.load()
    status = tracker.get_status("identity")
    assert status.status == "unknown"
    assert status.staleness_days == 90  # from DEFAULT_STALENESS_DAYS


def test_tracker_get_status_tracked(tmp_path: Path) -> None:
    tracker = FreshnessTracker(tmp_path)
    tracker.load()
    tracker.update("identity")
    status = tracker.get_status("identity")
    assert status.status == "fresh"


def test_tracker_get_stale_files(tmp_path: Path) -> None:
    tracker = FreshnessTracker(tmp_path)
    tracker.load()
    tracker.update("identity")

    # Manually set a file as stale
    old_date = datetime.now(tz=UTC) - timedelta(days=100)
    tracker._data["tools-and-systems"] = FileStatus(
        last_updated=old_date,
        staleness_days=60,
    )

    stale = tracker.get_stale_files()
    assert "tools-and-systems" in stale
    assert "identity" not in stale


def test_tracker_save_creates_directory(tmp_path: Path) -> None:
    metadata_dir = tmp_path / "nested" / "metadata"
    tracker = FreshnessTracker(metadata_dir)
    tracker.load()
    tracker.update("identity")
    tracker.save()
    assert (metadata_dir / "freshness.json").exists()


def test_tracker_roundtrip_preserves_data(tmp_path: Path) -> None:
    tracker = FreshnessTracker(tmp_path)
    tracker.load()
    tracker.update("identity")
    tracker.update("tools-and-systems")
    tracker.save()

    tracker2 = FreshnessTracker(tmp_path)
    data = tracker2.load()
    assert len(data) == 2
    assert data["identity"].status == "fresh"
    assert data["tools-and-systems"].status == "fresh"
