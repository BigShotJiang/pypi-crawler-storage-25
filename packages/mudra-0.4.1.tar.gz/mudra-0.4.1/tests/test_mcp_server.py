from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from mudra.freshness import FileStatus, FreshnessTracker
from mudra.mcp.resources import (
    format_freshness_warning,
    get_all_files,
    get_role_context,
    get_single_file,
    get_status_report,
)
from mudra.mcp.server import create_mcp_server
from mudra.store import PortfolioStore


@pytest.fixture
def store(initialized_portfolio: PortfolioStore) -> PortfolioStore:
    """Alias for initialized_portfolio with known content."""
    return initialized_portfolio


@pytest.fixture
def tracker(store: PortfolioStore) -> FreshnessTracker:
    """FreshnessTracker backed by the test portfolio metadata dir."""
    t = FreshnessTracker(store.metadata_dir)
    t.load()
    return t


# --- Single file ---


class TestGetSingleFile:
    def test_returns_content(self, store: PortfolioStore, tracker: FreshnessTracker) -> None:
        store.write_file("identity", "---\ndimension: identity\n---\nI am a test user.")
        result = get_single_file(store, tracker, "identity")
        assert "I am a test user." in result

    def test_strips_frontmatter(self, store: PortfolioStore, tracker: FreshnessTracker) -> None:
        store.write_file("identity", "---\ndimension: identity\n---\nI am a test user.")
        result = get_single_file(store, tracker, "identity")
        assert "---" not in result
        assert "dimension: identity" not in result

    def test_missing_raises_error(self, store: PortfolioStore, tracker: FreshnessTracker) -> None:
        # Remove the file if it exists from template init
        fp = store.file_path("current-projects")
        if fp.exists():
            fp.unlink()
        with pytest.raises(FileNotFoundError):
            get_single_file(store, tracker, "current-projects")

    def test_with_freshness_warning(
        self,
        store: PortfolioStore,
        tracker: FreshnessTracker,
    ) -> None:
        store.write_file("identity", "---\ndimension: identity\n---\nContent here.")
        # Mark identity as updated 100 days ago (staleness threshold is 90)
        tracker._data["identity"] = FileStatus(
            last_updated=datetime.now(tz=UTC) - timedelta(days=100),
            staleness_days=90,
        )
        result = get_single_file(store, tracker, "identity")
        assert "mudra:freshness-warning" in result
        assert "identity" in result


# --- Role context ---


class TestGetRoleContext:
    def test_returns_combined_content(
        self,
        store: PortfolioStore,
        tracker: FreshnessTracker,
    ) -> None:
        store.write_file("identity", "---\ndimension: identity\n---\nUser identity.")
        store.write_file("communication-style", "---\ndimension: comms\n---\nDirect and concise.")
        result = get_role_context(store, tracker, "developer")
        assert "User identity." in result
        assert "Direct and concise." in result

    def test_has_section_headers(self, store: PortfolioStore, tracker: FreshnessTracker) -> None:
        store.write_file("identity", "---\ndimension: identity\n---\nContent.")
        result = get_role_context(store, tracker, "developer")
        assert "## Identity" in result


# --- All files ---


class TestGetAllFiles:
    def test_includes_core(self, store: PortfolioStore, tracker: FreshnessTracker) -> None:
        store.write_file("identity", "---\ndimension: identity\n---\nCore content.")
        result = get_all_files(store, tracker)
        assert "Core content." in result

    def test_includes_extended_if_present(
        self,
        store: PortfolioStore,
        tracker: FreshnessTracker,
    ) -> None:
        store.write_file("current-projects", "---\ndimension: projects\n---\nProject X.")
        result = get_all_files(store, tracker)
        assert "Project X." in result

    def test_empty_portfolio(self, tmp_path: PortfolioStore) -> None:
        empty_store = PortfolioStore(path=tmp_path / "empty")
        empty_store.ensure_dirs()
        empty_tracker = FreshnessTracker(empty_store.metadata_dir)
        empty_tracker.load()
        result = get_all_files(empty_store, empty_tracker)
        assert result == "No portfolio files found."


# --- Status report ---


class TestGetStatusReport:
    def test_format(self, store: PortfolioStore, tracker: FreshnessTracker) -> None:
        result = get_status_report(store, tracker)
        assert "# Portfolio Status" in result
        assert "| File |" in result
        assert "Identity" in result

    def test_shows_stale_files(self, store: PortfolioStore, tracker: FreshnessTracker) -> None:
        tracker._data["identity"] = FileStatus(
            last_updated=datetime.now(tz=UTC) - timedelta(days=100),
            staleness_days=90,
        )
        result = get_status_report(store, tracker)
        assert "mudra:freshness-warning" in result


# --- Freshness warning formatting ---


class TestFormatFreshnessWarning:
    def test_empty(self) -> None:
        result = format_freshness_warning([])
        assert result == ""

    def test_with_stale_files(self) -> None:
        status = FileStatus(
            last_updated=datetime.now(tz=UTC) - timedelta(days=35),
            staleness_days=21,
        )
        result = format_freshness_warning([("current-projects", status)])
        assert "current-projects" in result
        assert "days_overdue: 14" in result

    def test_html_comment_format(self) -> None:
        status = FileStatus(
            last_updated=datetime.now(tz=UTC) - timedelta(days=35),
            staleness_days=21,
        )
        result = format_freshness_warning([("current-projects", status)])
        assert result.startswith("<!-- mudra:freshness-warning")
        assert result.endswith("-->")


# --- Server creation ---


class TestCreateMcpServer:
    def test_returns_fastmcp_instance(
        self,
        store: PortfolioStore,
        tracker: FreshnessTracker,
    ) -> None:
        from mcp.server.fastmcp import FastMCP  # type: ignore[import-untyped]

        server = create_mcp_server(store, tracker)
        assert isinstance(server, FastMCP)

    def test_server_has_resources_registered(
        self,
        store: PortfolioStore,
        tracker: FreshnessTracker,
    ) -> None:
        server = create_mcp_server(store, tracker)
        # FastMCP stores static resources and URI templates separately
        rm = server._resource_manager
        static_count = len(rm._resources)
        template_count = len(rm._templates)
        assert static_count + template_count >= 4
