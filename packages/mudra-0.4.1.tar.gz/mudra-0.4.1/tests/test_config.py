from __future__ import annotations

from pathlib import Path

import pytest

from mudra.config import (
    FreshnessConfig,
    McpConfig,
    MudraConfig,
    PortfolioConfig,
    default_config,
    load_config,
    save_config,
)
from mudra.tiers import DEFAULT_STALENESS_DAYS


def test_default_config_returns_valid_config() -> None:
    config = default_config()
    assert isinstance(config, MudraConfig)
    assert config.portfolio.path == "~/.mudra"


def test_default_config_freshness_thresholds() -> None:
    config = default_config()
    assert config.freshness.thresholds == DEFAULT_STALENESS_DAYS


def test_default_config_mcp_defaults() -> None:
    config = default_config()
    assert config.mcp.transport == "stdio"
    assert config.mcp.port == 3100


def test_save_and_load_roundtrip(tmp_path: Path) -> None:
    config = default_config()
    config_path = tmp_path / "config.toml"
    save_config(config, config_path)
    loaded = load_config(config_path)
    assert loaded == config


def test_save_creates_parent_dirs(tmp_path: Path) -> None:
    config = default_config()
    config_path = tmp_path / "nested" / "dir" / "config.toml"
    save_config(config, config_path)
    assert config_path.exists()


def test_load_raises_for_missing_file(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="Config file not found"):
        load_config(tmp_path / "nonexistent.toml")


def test_load_with_custom_values(tmp_path: Path) -> None:
    config = MudraConfig(
        portfolio=PortfolioConfig(path="/custom/path", version="2"),
        freshness=FreshnessConfig(check_on_serve=False, default_staleness_days=14),
        mcp=McpConfig(transport="sse", port=8080),
    )
    config_path = tmp_path / "config.toml"
    save_config(config, config_path)
    loaded = load_config(config_path)
    assert loaded.portfolio.path == "/custom/path"
    assert loaded.portfolio.version == "2"
    assert loaded.freshness.check_on_serve is False
    assert loaded.freshness.default_staleness_days == 14
    assert loaded.mcp.transport == "sse"
    assert loaded.mcp.port == 8080


def test_portfolio_config_defaults() -> None:
    pc = PortfolioConfig()
    assert pc.path == "~/.mudra"
    assert pc.version == "1"


def test_freshness_config_defaults() -> None:
    fc = FreshnessConfig()
    assert fc.check_on_serve is True
    assert fc.default_staleness_days == 30
