from __future__ import annotations

import json
from pathlib import Path

from mudra import __version__
from mudra.export import (
    EXPORT_FORMATS,
    export_api_payload,
    export_claude_project,
    export_markdown,
    export_system_prompt,
)
from mudra.export._helpers import file_name_to_title, resolve_files, strip_frontmatter
from mudra.store import PortfolioStore

SAMPLE_CONTENT_WITH_FM = """\
---
dimension: identity
tier: core
version: 1
---

I am a software engineer focused on backend systems.
"""

SAMPLE_CONTENT_NO_FM = "I am a software engineer focused on backend systems."


def _populate_portfolio(store: PortfolioStore) -> None:
    """Write known content to identity and tools-and-systems files."""
    store.write_file(
        "identity",
        "---\ndimension: identity\ntier: core\nversion: 1\n---\n\nI build backend systems.",
    )
    store.write_file(
        "tools-and-systems",
        "---\ndimension: tools\ntier: core\nversion: 1\n---\n\nI use Python and Rust.",
    )


# -- Helper tests --


class TestStripFrontmatter:
    def test_strip_frontmatter_removes_yaml(self) -> None:
        result = strip_frontmatter(SAMPLE_CONTENT_WITH_FM)
        assert "---" not in result
        assert "dimension:" not in result
        assert "software engineer" in result

    def test_strip_frontmatter_no_frontmatter(self) -> None:
        result = strip_frontmatter(SAMPLE_CONTENT_NO_FM)
        assert result == SAMPLE_CONTENT_NO_FM


class TestFileNameToTitle:
    def test_file_name_to_title(self) -> None:
        assert file_name_to_title("tools-and-systems") == "Tools And Systems"
        assert file_name_to_title("identity") == "Identity"
        assert file_name_to_title("current-projects") == "Current Projects"


class TestResolveFiles:
    def test_resolve_files_all(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = resolve_files(initialized_portfolio, None)
        assert "identity" in result
        assert "tools-and-systems" in result

    def test_resolve_files_subset(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = resolve_files(initialized_portfolio, ["identity"])
        assert result == ["identity"]

    def test_resolve_files_nonexistent_filtered(
        self, initialized_portfolio: PortfolioStore
    ) -> None:
        _populate_portfolio(initialized_portfolio)
        result = resolve_files(initialized_portfolio, ["identity", "domain-knowledge"])
        assert result == ["identity"]


# -- System prompt tests --


class TestExportSystemPrompt:
    def test_system_prompt_format(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = export_system_prompt(initialized_portfolio)
        assert result.startswith("<user_context>")
        assert result.endswith("</user_context>")
        assert "## Identity" in result
        assert "## Tools And Systems" in result

    def test_system_prompt_strips_frontmatter(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = export_system_prompt(initialized_portfolio)
        assert "dimension:" not in result
        assert "tier:" not in result
        assert "I build backend systems." in result

    def test_system_prompt_to_file(
        self, initialized_portfolio: PortfolioStore, tmp_path: Path
    ) -> None:
        _populate_portfolio(initialized_portfolio)
        out = tmp_path / "prompt.txt"
        result = export_system_prompt(initialized_portfolio, output=out)
        assert out.exists()
        assert out.read_text(encoding="utf-8") == result

    def test_system_prompt_selected_files(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = export_system_prompt(initialized_portfolio, files=["identity"])
        assert "## Identity" in result
        assert "Tools And Systems" not in result


# -- Claude project tests --


class TestExportClaudeProject:
    def test_claude_project_creates_directory(
        self, initialized_portfolio: PortfolioStore, tmp_path: Path
    ) -> None:
        _populate_portfolio(initialized_portfolio)
        out_dir = tmp_path / "claude-export"
        export_claude_project(initialized_portfolio, output=out_dir)
        assert out_dir.is_dir()

    def test_claude_project_individual_files(
        self, initialized_portfolio: PortfolioStore, tmp_path: Path
    ) -> None:
        _populate_portfolio(initialized_portfolio)
        out_dir = tmp_path / "claude-export"
        result = export_claude_project(initialized_portfolio, output=out_dir)
        identity_file = out_dir / "identity.md"
        assert identity_file.exists()
        content = identity_file.read_text(encoding="utf-8")
        assert "dimension:" not in content
        assert "I build backend systems." in content
        assert "identity.md" in result


# -- API payload tests --


class TestExportApiPayload:
    def test_api_payload_valid_json(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = export_api_payload(initialized_portfolio)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)

    def test_api_payload_has_version(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = export_api_payload(initialized_portfolio)
        parsed = json.loads(result)
        assert parsed["mudra_version"] == __version__
        assert "exported_at" in parsed

    def test_api_payload_has_tier(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = export_api_payload(initialized_portfolio)
        parsed = json.loads(result)
        assert parsed["files"]["identity"]["tier"] == "core"
        assert "content" in parsed["files"]["identity"]


# -- Markdown tests --


class TestExportMarkdown:
    def test_markdown_format(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = export_markdown(initialized_portfolio)
        assert result.startswith("# Mudra Portfolio")
        assert "## Identity" in result

    def test_markdown_separators(self, initialized_portfolio: PortfolioStore) -> None:
        _populate_portfolio(initialized_portfolio)
        result = export_markdown(initialized_portfolio)
        assert "\n\n---\n\n" in result


# -- Edge case tests --


class TestExportEdgeCases:
    def test_export_empty_portfolio(self, tmp_portfolio: PortfolioStore) -> None:
        result = export_system_prompt(tmp_portfolio)
        assert result == "<user_context>\n</user_context>"

    def test_export_formats_registry(self) -> None:
        assert "system-prompt" in EXPORT_FORMATS
        assert "claude-project" in EXPORT_FORMATS
        assert "api-payload" in EXPORT_FORMATS
        assert "markdown" in EXPORT_FORMATS
