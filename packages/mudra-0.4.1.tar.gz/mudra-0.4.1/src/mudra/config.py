from __future__ import annotations

import tomllib
from pathlib import Path

import tomli_w
from pydantic import BaseModel, Field

from mudra.tiers import DEFAULT_STALENESS_DAYS


class PortfolioConfig(BaseModel):
    """Configuration for the portfolio location and version."""

    path: str = "~/.mudra"
    version: str = "1"


class FreshnessConfig(BaseModel):
    """Configuration for staleness checking."""

    check_on_serve: bool = True
    default_staleness_days: int = 30
    thresholds: dict[str, int] = Field(default_factory=lambda: dict(DEFAULT_STALENESS_DAYS))


class McpConfig(BaseModel):
    """Configuration for the MCP server."""

    transport: str = "stdio"
    port: int = 3100


class InterviewConfig(BaseModel):
    """Configuration for the interview engine."""

    provider: str = "anthropic"
    model: str = "claude-sonnet-4-20250514"
    temperature: float = 0.3
    max_questions_per_file: int = 8


class MudraConfig(BaseModel):
    """Top-level Mudra configuration."""

    portfolio: PortfolioConfig = Field(default_factory=PortfolioConfig)
    freshness: FreshnessConfig = Field(default_factory=FreshnessConfig)
    mcp: McpConfig = Field(default_factory=McpConfig)
    interview: InterviewConfig = Field(default_factory=InterviewConfig)


def load_config(config_path: Path) -> MudraConfig:
    """Load configuration from a TOML file.

    Raises FileNotFoundError if the config file does not exist.
    """
    if not config_path.exists():
        msg = f"Config file not found: {config_path}"
        raise FileNotFoundError(msg)
    with config_path.open("rb") as f:
        data = tomllib.load(f)
    return MudraConfig.model_validate(data)


def save_config(config: MudraConfig, config_path: Path) -> None:
    """Save configuration to a TOML file."""
    config_path.parent.mkdir(parents=True, exist_ok=True)
    data = config.model_dump()
    with config_path.open("wb") as f:
        tomli_w.dump(data, f)


def default_config() -> MudraConfig:
    """Return a MudraConfig with all defaults."""
    return MudraConfig()
