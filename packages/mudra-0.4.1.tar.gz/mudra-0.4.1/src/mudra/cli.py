from __future__ import annotations

import json
from pathlib import Path

import click

from mudra import __version__
from mudra.config import MudraConfig, default_config, load_config, save_config
from mudra.decision_log import DecisionLog
from mudra.freshness import FreshnessTracker
from mudra.git import (
    create_gitignore,
    git_add,
    git_commit,
    git_diff,
    git_has_changes,
    git_log,
)
from mudra.git import (
    git_init as _git_init,
)
from mudra.store import PortfolioStore
from mudra.tiers import ALL_FILES, CORE_FILES, is_core, is_extended, is_valid_file


def get_store(ctx: click.Context) -> PortfolioStore:
    """Extract PortfolioStore from click context."""
    return ctx.obj["store"]  # type: ignore[no-any-return]


def get_tracker(store: PortfolioStore) -> FreshnessTracker:
    """Create and load a FreshnessTracker for the given store."""
    tracker = FreshnessTracker(store.metadata_dir)
    tracker.load()
    return tracker


@click.group()
@click.version_option(version=__version__)
@click.option("--profile", default=None, help="Portfolio profile name")
@click.option(
    "--path",
    "portfolio_path",
    default=None,
    type=click.Path(),
    help="Portfolio directory path",
)
@click.pass_context
def main(ctx: click.Context, profile: str | None, portfolio_path: str | None) -> None:
    """Mudra: Your identity, sealed and portable across every AI agent."""
    ctx.ensure_object(dict)
    path = Path(portfolio_path) if portfolio_path else None
    ctx.obj["store"] = PortfolioStore(path=path, profile=profile)


@main.command()
@click.option(
    "--template", default=None, help="Community template name (engineer, manager, designer)"
)
@click.pass_context
def init(ctx: click.Context, template: str | None) -> None:
    """Initialize a new Mudra portfolio."""
    store = get_store(ctx)

    if store.metadata_dir.exists():
        raise click.UsageError(f"Portfolio already initialized at {store.path}")

    store.ensure_dirs()

    if template is not None:
        available = PortfolioStore.list_community_templates()
        if template not in available:
            raise click.UsageError(
                f"Unknown template: {template}. Available: {', '.join(available)}"
            )
        community_dir = PortfolioStore.resolve_community_templates_dir() / template
        core_dir = community_dir / "core"
        for name in CORE_FILES:
            store.create_from_template(name, core_dir)

        extended_dir = community_dir / "extended"
        if extended_dir.is_dir():
            for ext_file in sorted(extended_dir.iterdir()):
                if ext_file.is_file():
                    ext_name = ext_file.stem
                    if is_valid_file(ext_name):
                        store.create_from_template(ext_name, extended_dir)
    else:
        templates_dir = PortfolioStore.resolve_templates_dir()
        core_template_dir = templates_dir / "core"
        for name in CORE_FILES:
            store.create_from_template(name, core_template_dir)

    config = default_config()
    save_config(config, store.metadata_dir / "config.toml")

    from mudra.router import RoutingConfig, generate_routing_toml

    routing_path = store.metadata_dir / "routing.toml"
    routing_config = RoutingConfig()
    routing_path.write_text(generate_routing_toml(routing_config), encoding="utf-8")

    _git_init(store.path)
    create_gitignore(store.path)

    tracker = FreshnessTracker(store.metadata_dir)
    for name in CORE_FILES:
        tracker.update(name)
    for name in store.list_extended_files():
        tracker.update(name)
    tracker.save()

    git_add(store.path, ".")
    git_commit(store.path, "mudra: initialize portfolio")

    click.echo(f"Portfolio initialized at {store.path}")


@main.command(name="templates")
def list_templates() -> None:
    """List available community templates."""
    available = PortfolioStore.list_community_templates()
    if not available:
        click.echo("No community templates available.")
        return

    click.echo("Available templates:")
    for name in available:
        try:
            meta = PortfolioStore.load_template_metadata(name)
            desc = meta.get("description", "No description")
            click.echo(f"  {name}: {desc}")
        except FileNotFoundError:
            click.echo(f"  {name}: (metadata unavailable)")


@main.command()
@click.argument("file")
@click.pass_context
def edit(ctx: click.Context, file: str) -> None:
    """Edit a portfolio file in your default editor."""
    if not is_valid_file(file):
        raise click.UsageError(f"Unknown file: {file}. Valid files: {', '.join(ALL_FILES)}")

    store = get_store(ctx)

    if not store.file_exists(file):
        if is_extended(file):
            raise click.UsageError(
                f"File '{file}' does not exist. Use 'mudra add {file}' to create it."
            )
        raise click.UsageError(f"File '{file}' does not exist. Run 'mudra init' first.")

    current_content = store.read_file(file)
    new_content = click.edit(current_content)

    if new_content is None or new_content == current_content:
        click.echo("No changes made.")
        return

    store.write_file(file, new_content)
    file_path = store.file_path(file)
    git_add(store.path, str(file_path.relative_to(store.path)))
    git_commit(store.path, f"mudra: update {file}")

    tracker = get_tracker(store)
    tracker.update(file)
    tracker.save()

    click.echo(f"Updated {file}.")


@main.command()
@click.argument("file")
@click.pass_context
def add(ctx: click.Context, file: str) -> None:
    """Add an extended portfolio file."""
    if not is_valid_file(file):
        raise click.UsageError(f"Unknown file: {file}. Valid files: {', '.join(ALL_FILES)}")

    if is_core(file):
        raise click.UsageError(f"'{file}' is a core file and already exists after 'mudra init'.")

    if not is_extended(file):
        raise click.UsageError(f"'{file}' is not a recognized extended file.")

    store = get_store(ctx)

    if store.file_exists(file):
        raise click.UsageError(f"File '{file}' already exists.")

    templates_dir = PortfolioStore.resolve_templates_dir()
    extended_template_dir = templates_dir / "extended"
    store.create_from_template(file, extended_template_dir)

    file_path = store.file_path(file)
    git_add(store.path, str(file_path.relative_to(store.path)))
    git_commit(store.path, f"mudra: add extended file {file}")

    tracker = get_tracker(store)
    tracker.update(file)
    tracker.save()

    click.echo(f"Added {file}.")


@main.command()
@click.option("--json", "as_json", is_flag=True, help="Output machine-readable JSON")
@click.pass_context
def status(ctx: click.Context, as_json: bool) -> None:
    """Show portfolio freshness and completeness status."""
    store = get_store(ctx)
    tracker = get_tracker(store)

    existing_core = store.list_core_files()
    existing_extended = store.list_extended_files()
    existing_all = store.list_files()

    has_changes = False
    if (store.path / ".git").is_dir():
        has_changes = git_has_changes(store.path)

    file_statuses: dict[str, dict[str, str | int | None]] = {}
    for name in existing_all:
        fs = tracker.get_status(name)
        file_statuses[name] = {
            "status": fs.status,
            "days_since_update": fs.days_since_update,
            "staleness_days": fs.staleness_days,
        }

    if as_json:
        output = {
            "core_files": {
                "present": len(existing_core),
                "total": len(CORE_FILES),
                "files": existing_core,
            },
            "extended_files": {
                "count": len(existing_extended),
                "files": existing_extended,
            },
            "freshness": file_statuses,
            "uncommitted_changes": has_changes,
        }
        click.echo(json.dumps(output, indent=2))
        return

    click.echo(f"Core files: {len(existing_core)}/{len(CORE_FILES)}")
    missing_core = [f for f in CORE_FILES if f not in existing_core]
    for name in missing_core:
        click.echo(click.style(f"  MISSING: {name}", fg="red"))

    click.echo(f"Extended files: {len(existing_extended)}")

    click.echo("\nFreshness:")
    for name in existing_all:
        fs = tracker.get_status(name)
        if fs.status == "fresh":
            color = "green"
        elif fs.status == "stale":
            color = "yellow"
        else:
            color = "white"
        days = fs.days_since_update
        days_str = f"{days}d ago" if days is not None else "unknown"
        click.echo(click.style(f"  {name}: {fs.status} ({days_str})", fg=color))

    if has_changes:
        click.echo(click.style("\nUncommitted changes detected.", fg="yellow"))


@main.command()
@click.option("--strict", is_flag=True, help="Treat warnings as errors")
@click.option("--file", "single_file", default=None, help="Validate a single file")
@click.pass_context
def validate(ctx: click.Context, strict: bool, single_file: str | None) -> None:
    """Validate portfolio completeness and quality."""
    store = get_store(ctx)
    tracker = get_tracker(store)

    errors: list[str] = []
    warnings: list[str] = []

    files_to_check = [single_file] if single_file else list(ALL_FILES)

    for name in files_to_check:
        if not is_valid_file(name):
            errors.append(f"Unknown file: {name}")
            continue

        if not store.file_exists(name):
            if is_core(name):
                errors.append(f"Missing core file: {name}")
            continue

        if name == "decision-log":
            log = DecisionLog(store)
            log.read()  # triggers warnings on malformed lines
            continue

        content = store.read_file(name)
        non_comment_content = "\n".join(
            line for line in content.splitlines() if not line.strip().startswith("<!--")
        ).strip()

        if len(non_comment_content) <= 10:
            warnings.append(f"File '{name}' appears to be empty or template-only")

        fs = tracker.get_status(name)
        if fs.status == "stale":
            warnings.append(f"File '{name}' is stale ({fs.days_since_update}d since update)")

    if strict:
        errors.extend(warnings)
        warnings = []

    if errors:
        click.echo("Errors:")
        for e in errors:
            click.echo(click.style(f"  - {e}", fg="red"))

    if warnings:
        click.echo("Warnings:")
        for w in warnings:
            click.echo(click.style(f"  - {w}", fg="yellow"))

    if not errors and not warnings:
        click.echo(click.style("Validation passed.", fg="green"))

    if errors:
        ctx.exit(1)


@main.command()
@click.option("--file", "single_file", default=None, help="Filter to a single file")
@click.option("--diff", "show_diff", is_flag=True, help="Show diffs")
@click.pass_context
def history(ctx: click.Context, single_file: str | None, show_diff: bool) -> None:
    """Show portfolio git history."""
    store = get_store(ctx)

    if not (store.path / ".git").is_dir():
        raise click.UsageError("No git repository found. Run 'mudra init' first.")

    file_arg: str | None = None
    if single_file is not None:
        if not is_valid_file(single_file):
            raise click.UsageError(f"Unknown file: {single_file}")
        file_arg = str(store.file_path(single_file).relative_to(store.path))

    entries = git_log(store.path, file=file_arg)

    if not entries:
        click.echo("No history found.")
        return

    click.echo(f"{'Hash':<10} {'Date':<26} {'Message'}")
    click.echo("-" * 70)
    for entry in entries:
        short_hash = entry["hash"][:8]
        click.echo(f"{short_hash:<10} {entry['date']:<26} {entry['message']}")

    if show_diff:
        click.echo("\n--- Diff ---")
        diff_output = git_diff(store.path, file=file_arg)
        if diff_output:
            click.echo(diff_output)
        else:
            click.echo("No uncommitted changes.")


@main.command()
@click.option("--verbose", is_flag=True, help="Show file mappings per role")
@click.pass_context
def roles(ctx: click.Context, verbose: bool) -> None:
    """List available roles from routing configuration."""
    store = get_store(ctx)
    routing_path = store.metadata_dir / "routing.toml"

    if not routing_path.exists():
        raise click.UsageError("No routing.toml found. Run 'mudra init' first.")

    from mudra.router import list_roles, load_routing_config

    config = load_routing_config(routing_path)
    all_roles = list_roles(config)

    if not all_roles:
        click.echo("No roles defined.")
        return

    for role_name, role_config in all_roles.items():
        click.echo(f"  {role_name}: {role_config.description}")
        if verbose:
            if role_config.files == ["*"]:
                click.echo("    (all files)")
            elif role_config.files:
                for fname in role_config.files:
                    click.echo(f"    - {fname}")
            else:
                click.echo("    (no files)")


@main.group(name="config")
def config_group() -> None:
    """Get or set Mudra configuration values."""


@config_group.command(name="get")
@click.argument("key")
@click.pass_context
def config_get(ctx: click.Context, key: str) -> None:
    """Get a configuration value by dot-notation key."""
    store = get_store(ctx)
    config_path = store.metadata_dir / "config.toml"

    if not config_path.exists():
        raise click.UsageError("No config.toml found. Run 'mudra init' first.")

    config = load_config(config_path)
    data = config.model_dump()

    parts = key.split(".")
    current: object = data
    for part in parts:
        if not isinstance(current, dict) or part not in current:
            raise click.UsageError(f"Unknown config key: {key}")
        current = current[part]

    click.echo(current)


@config_group.command(name="set")
@click.argument("key")
@click.argument("value")
@click.pass_context
def config_set(ctx: click.Context, key: str, value: str) -> None:
    """Set a configuration value by dot-notation key."""
    store = get_store(ctx)
    config_path = store.metadata_dir / "config.toml"

    if not config_path.exists():
        raise click.UsageError("No config.toml found. Run 'mudra init' first.")

    config = load_config(config_path)
    data = config.model_dump()

    parts = key.split(".")
    current: dict[str, object] = data
    for part in parts[:-1]:
        if part not in current or not isinstance(current[part], dict):
            raise click.UsageError(f"Unknown config key: {key}")
        current = current[part]  # type: ignore[assignment]

    final_key = parts[-1]
    if final_key not in current:
        raise click.UsageError(f"Unknown config key: {key}")

    existing = current[final_key]
    if isinstance(existing, bool):
        parsed: object = value.lower() in ("true", "1", "yes")
    elif isinstance(existing, int):
        parsed = int(value)
    else:
        parsed = value

    current[final_key] = parsed

    new_config = MudraConfig.model_validate(data)
    save_config(new_config, config_path)
    click.echo(f"Set {key} = {parsed}")


@main.command(name="log")
@click.argument("decision", required=False)
@click.option("--context", "log_context", default=None, help="Why this decision was made")
@click.option("--tags", default=None, help="Comma-separated tags")
@click.option("--list", "list_entries", is_flag=True, help="List recent decisions")
@click.option("--tag", "filter_tag", default=None, help="Filter list by tag")
@click.pass_context
def log_cmd(
    ctx: click.Context,
    decision: str | None,
    log_context: str | None,
    tags: str | None,
    list_entries: bool,
    filter_tag: str | None,
) -> None:
    """Log a decision or view decision history."""
    store = get_store(ctx)
    log = DecisionLog(store)

    if list_entries or filter_tag is not None:
        entries = log.filter_by_tag(filter_tag) if filter_tag is not None else log.read()

        if not entries:
            click.echo("No decisions found.")
            return

        for entry in entries:
            tags_str = f" [{', '.join(entry.tags)}]" if entry.tags else ""
            ctx_str = f" -- {entry.context}" if entry.context else ""
            click.echo(f"  {entry.date}: {entry.decision}{tags_str}{ctx_str}")
        return

    if decision is None:
        raise click.UsageError("Provide a decision text or use --list to view decisions.")

    tag_list = [t.strip() for t in tags.split(",")] if tags else None
    entry = log.append(decision, context=log_context, tags=tag_list)

    file_path = store.file_path("decision-log")
    git_add(store.path, str(file_path.relative_to(store.path)))
    git_commit(store.path, "mudra: log decision")

    click.echo(f"Logged: {entry.decision}")


@main.command()
@click.option(
    "--format",
    "fmt",
    required=True,
    type=click.Choice(["system-prompt", "claude-project", "api-payload", "markdown"]),
    help="Export format",
)
@click.option("--role", default=None, help="Role name for filtering")
@click.option("--output", "output_path", default=None, type=click.Path(), help="Output file")
@click.pass_context
def export(
    ctx: click.Context,
    fmt: str,
    role: str | None,
    output_path: str | None,
) -> None:
    """Export portfolio in various formats."""
    store = get_store(ctx)
    existing_files = store.list_files()

    if not existing_files:
        raise click.UsageError("No portfolio files found. Run 'mudra init' first.")

    file_list: list[str] | None = None
    if role is not None:
        from mudra.router import load_routing_config, resolve_role

        routing_config = load_routing_config(store.metadata_dir / "routing.toml")
        file_list = resolve_role(role, routing_config, store)

    from mudra.export import EXPORT_FORMATS

    exporter = EXPORT_FORMATS.get(fmt)
    if exporter is None:
        raise click.UsageError(f"Unknown format: {fmt}")

    out = Path(output_path) if output_path else None
    output_text = exporter(store, files=file_list, output=out)

    if out is not None:
        click.echo(f"Exported to {out}")
    else:
        click.echo(output_text)


@main.command()
@click.option(
    "--transport",
    type=click.Choice(["stdio", "streamable-http"]),
    default="stdio",
    help="Transport mode",
)
@click.option("--port", default=3100, type=int, help="Port for streamable-http transport")
@click.pass_context
def serve(ctx: click.Context, transport: str, port: int) -> None:
    """Start the MCP resource server."""
    store = get_store(ctx)

    if not store.metadata_dir.exists():
        raise click.UsageError("No portfolio found. Run 'mudra init' first.")

    tracker = get_tracker(store)

    from mudra.mcp import run_server

    run_server(store, tracker, transport=transport, port=port)


@main.command()
@click.option("--file", "file_name", required=True, help="Portfolio file to interview")
@click.option("--provider", default=None, help="LLM provider (anthropic, openai, ollama)")
@click.option("--resume", is_flag=True, help="Resume an interrupted interview")
@click.pass_context
def interview(ctx: click.Context, file_name: str, provider: str | None, resume: bool) -> None:
    """Create or update a portfolio file through guided Q&A."""
    store = get_store(ctx)

    if not store.metadata_dir.exists():
        raise click.UsageError("No portfolio found. Run 'mudra init' first.")

    if not is_valid_file(file_name):
        raise click.UsageError(f"Unknown file: {file_name}. Valid files: {', '.join(ALL_FILES)}")

    config_path = store.metadata_dir / "config.toml"
    if config_path.exists():
        config = load_config(config_path)
        iv_config = config.interview
    else:
        from mudra.config import InterviewConfig

        iv_config = InterviewConfig()

    llm_provider = provider or iv_config.provider
    llm_model = iv_config.model
    temperature = iv_config.temperature

    from mudra.interview import InterviewEngine, InterviewSession, Synthesizer

    synthesizer = Synthesizer(
        provider=llm_provider,
        model=llm_model,
        temperature=temperature,
    )

    engine = InterviewEngine(store=store, synthesizer=synthesizer)

    session: InterviewSession | None = None
    session_path = engine.session_path(file_name)
    if resume and session_path.exists():
        session = InterviewSession.load(session_path)
        click.echo(f"Resuming interview for {file_name}...")

    try:
        result = engine.run(file_name, session=session)
    except KeyboardInterrupt:
        if session is not None:
            session.save(session_path)
            click.echo(
                f"\nInterview paused. Resume with: mudra interview --file {file_name} --resume"
            )
        else:
            click.echo("\nInterview cancelled.")
        return

    if result.draft is not None:
        store.write_file(file_name, result.draft)

        file_path = store.file_path(file_name)
        git_add(store.path, str(file_path.relative_to(store.path)))
        git_commit(store.path, f"mudra: refresh {file_name} via interview")

        tracker = get_tracker(store)
        tracker.update(file_name)
        tracker.save()

        click.echo(f"\nSaved {file_name} via interview.")

    if session_path.exists():
        session_path.unlink()
