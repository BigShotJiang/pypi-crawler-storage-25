from __future__ import annotations

from pydantic import BaseModel, Field


class InterviewProtocol(BaseModel):
    """Defines the structure and behavior of an interview for a portfolio file."""

    intro: str
    questions: list[str]
    push_for_specificity: list[str] = Field(
        default_factory=lambda: [
            "Can you give a concrete example?",
            "What does that look like in practice?",
            "Who specifically? What specifically?",
        ]
    )
    synthesis_instruction: str


PROTOCOLS: dict[str, InterviewProtocol] = {
    "identity": InterviewProtocol(
        intro="Let's capture who you are in a way that gives any AI agent immediate context.",
        questions=[
            "What's your name and current role/title?",
            "What organization do you work for, and what does it do?",
            "In one paragraph, how would you describe what you actually do day-to-day?",
            "What are you known for professionally? What do people come to you for?",
            "What's the one thing an AI agent must know about you to be useful?",
        ],
        synthesis_instruction=(
            "Write a concise identity summary in first person. "
            "No bullet lists — flowing prose. "
            "Should sound like the user, not like an AI profile."
        ),
    ),
    "tools-and-systems": InterviewProtocol(
        intro="Let's document your technical environment so agents know what tools you work with.",
        questions=[
            "What programming languages do you use most?",
            "What are your primary development tools and IDEs?",
            "What cloud platforms, databases, or infrastructure do you work with?",
            "Are there any tools or frameworks you've explicitly rejected? Why?",
            "What's your preferred tech stack for new projects?",
        ],
        synthesis_instruction=(
            "Write a structured summary of the user's technical environment. "
            "Group by category: languages, tools, infrastructure, rejected tools. "
            "Use concise bullet lists under clear headings."
        ),
    ),
    "communication-style": InterviewProtocol(
        intro="Let's capture how you communicate so agents match your voice.",
        questions=[
            "How would you describe your writing style in 2-3 words?",
            "What formatting do you prefer? (bullet points, prose, headers, etc.)",
            "What communication patterns do you dislike in AI responses?",
            "How formal or casual should AI responses be?",
        ],
        synthesis_instruction=(
            "Write a communication style guide in second person ('you'). "
            "Include preferences and anti-patterns. "
            "Be specific about tone, structure, and what to avoid."
        ),
    ),
    "preferences-and-constraints": InterviewProtocol(
        intro=(
            "Let's document your hard rules — the things that are always true or never acceptable."
        ),
        questions=[
            "What are your absolute 'always do' rules when working with AI?",
            "What are your 'never do' constraints?",
            "Are there specific patterns, practices, or approaches you insist on?",
            "Any organizational mandates or compliance requirements that apply?",
        ],
        synthesis_instruction=(
            "Write a clear list of constraints organized as 'Always' and 'Never' sections. "
            "Each item should be a specific, actionable rule. "
            "Include the reason behind each constraint where the user provided one."
        ),
    ),
    "role-and-responsibilities": InterviewProtocol(
        intro="Let's capture what your actual job looks like day-to-day.",
        questions=[
            "What's your official role and who do you report to?",
            "What are your key deliverables and responsibilities?",
            "What does a typical week look like for you?",
        ],
        synthesis_instruction=(
            "Write a concise role description in first person. "
            "Cover responsibilities, deliverables, and work rhythms."
        ),
    ),
    "current-projects": InterviewProtocol(
        intro="Let's document your active workstreams.",
        questions=[
            "What are you actively working on right now?",
            "What's the status and priority of each project?",
            "Who are you collaborating with on each?",
        ],
        synthesis_instruction=(
            "Create a structured list of current projects. "
            "For each: name, status, priority, collaborators. "
            "Use a consistent format for easy scanning."
        ),
    ),
    "team-and-relationships": InterviewProtocol(
        intro="Let's document the key people you work with.",
        questions=[
            "Who are the key people you interact with regularly?",
            "What's your relationship with each (manager, peer, report, stakeholder)?",
            "Are there any important interaction patterns or dependencies?",
        ],
        synthesis_instruction=(
            "Write a structured overview of key relationships. "
            "Group by relationship type. "
            "Include interaction patterns and dependencies."
        ),
    ),
    "goals-and-priorities": InterviewProtocol(
        intro="Let's capture what you're optimizing for.",
        questions=[
            "What are your top priorities this quarter?",
            "What are your medium-term goals (6-12 months)?",
            "What are you optimizing for in the long term?",
        ],
        synthesis_instruction=(
            "Organize goals by time horizon: immediate, medium-term, long-term. "
            "Be specific about what success looks like for each."
        ),
    ),
    "domain-knowledge": InterviewProtocol(
        intro="Let's document your expertise so agents calibrate their explanations.",
        questions=[
            "What are your primary areas of expertise?",
            "What topics do you know deeply enough that agents should skip basics?",
            "Where are your knowledge gaps that you'd want agents to explain more?",
        ],
        synthesis_instruction=(
            "Create two sections: 'Expert Areas' (skip the basics) and "
            "'Learning Areas' (explain more). Be specific about depth levels."
        ),
    ),
    "decision-log": InterviewProtocol(
        intro="Let's document a recent decision for your decision log.",
        questions=[
            "What decision did you make?",
            "What was the context — why did this decision come up?",
            "What tags or categories apply? (comma-separated)",
        ],
        synthesis_instruction=(
            "This is a special file — produce a single JSON line (JSONL format) with keys: "
            "date (today YYYY-MM-DD), decision, context, tags (array), outcome (null). "
            "Do NOT produce markdown for this file."
        ),
    ),
}


def get_protocol(file_name: str) -> InterviewProtocol:
    """Get the interview protocol for a file. Raises KeyError if not found."""
    if file_name not in PROTOCOLS:
        msg = f"No interview protocol for file: {file_name}"
        raise KeyError(msg)
    return PROTOCOLS[file_name]
