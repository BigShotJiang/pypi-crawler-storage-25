from __future__ import annotations

import litellm

from mudra.interview.protocols import InterviewProtocol


class Synthesizer:
    """Converts interview Q&A pairs into polished markdown via LLM."""

    def __init__(
        self,
        provider: str = "anthropic",
        model: str = "claude-sonnet-4-20250514",
        temperature: float = 0.3,
    ) -> None:
        self._provider = provider
        self._model = model
        self._temperature = temperature

    def _resolve_model(self) -> str:
        if self._provider == "ollama":
            return f"ollama/{self._model}"
        return f"{self._provider}/{self._model}"

    def _complete(self, system: str, user: str) -> str:
        """Call litellm and extract the text response. Raises on empty."""
        response = litellm.completion(
            model=self._resolve_model(),
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=self._temperature,
        )
        result: str | None = response.choices[0].message.content
        if result is None:
            msg = "LLM returned empty response"
            raise RuntimeError(msg)
        return result

    def synthesize(
        self,
        file_name: str,
        protocol: InterviewProtocol,
        answers: dict[str, str],
        existing_content: str | None = None,
    ) -> str:
        """Synthesize interview answers into markdown content."""
        qa_text = "\n\n".join(f"Q: {q}\nA: {a}" for q, a in answers.items())

        system_prompt = (
            "You are helping a user create a personal context file for AI agents. "
            "Synthesize the following Q&A into a polished document.\n\n"
            f"File: {file_name}\n"
            f"Synthesis instructions: {protocol.synthesis_instruction}"
        )

        if existing_content:
            system_prompt += f"\n\nExisting content to update/merge:\n{existing_content}"

        return self._complete(
            system_prompt,
            f"Here are the interview answers:\n\n{qa_text}\n\nProduce the final document.",
        )

    def revise(
        self,
        content: str,
        feedback: str,
        protocol: InterviewProtocol,
    ) -> str:
        """Revise synthesized content based on user feedback."""
        return self._complete(
            (
                "You are revising a personal context document based on user feedback.\n"
                f"Synthesis instructions: {protocol.synthesis_instruction}"
            ),
            (
                f"Current document:\n{content}\n\n"
                f"User feedback:\n{feedback}\n\n"
                "Produce the revised document."
            ),
        )
