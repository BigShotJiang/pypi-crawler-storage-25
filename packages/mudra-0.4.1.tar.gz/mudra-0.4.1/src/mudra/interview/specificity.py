from __future__ import annotations

import random

VAGUE_WORDS: set[str] = {
    "stuff",
    "things",
    "various",
    "general",
    "usually",
    "sometimes",
    "etc",
    "basically",
    "maybe",
    "probably",
}

VAGUE_PHRASES: list[str] = [
    "kind of",
    "sort of",
]

MIN_WORD_COUNT = 5


def is_specific_enough(response: str) -> bool:
    """Check if a response is specific enough to be useful.

    Returns False if:
    - Response has fewer than MIN_WORD_COUNT words
    - Response contains too many vague words (>30% of total)
    """
    words = response.lower().split()
    if len(words) < MIN_WORD_COUNT:
        return False

    vague_count = sum(1 for w in words if w.strip(".,!?;:") in VAGUE_WORDS)
    lower_response = response.lower()
    for phrase in VAGUE_PHRASES:
        if phrase in lower_response:
            vague_count += 1

    vague_ratio = vague_count / len(words)
    return vague_ratio <= 0.3


def get_specificity_prompt(original_question: str) -> str:
    """Generate a follow-up prompt pushing for more specificity."""
    prompts = [
        f"That's a good start, but can you be more specific? {original_question}",
        "Can you give a concrete example of what you mean?",
        "What does that look like in practice — with names, tools, or specifics?",
    ]
    return random.choice(prompts)  # noqa: S311
