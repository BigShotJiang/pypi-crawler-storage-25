from __future__ import annotations

import json
from collections.abc import Callable
from enum import Enum
from pathlib import Path

from pydantic import BaseModel, Field

from mudra.interview.protocols import get_protocol
from mudra.interview.specificity import get_specificity_prompt, is_specific_enough
from mudra.interview.synthesizer import Synthesizer
from mudra.store import PortfolioStore


class InterviewState(Enum):
    """States of an interview session."""

    INTRO = "intro"
    ASKING = "asking"
    SYNTHESIZING = "synthesizing"
    REVIEWING = "reviewing"
    COMPLETE = "complete"


class InterviewSession(BaseModel):
    """Serializable interview session state for resume support."""

    file_name: str
    state: InterviewState = InterviewState.INTRO
    current_question_index: int = 0
    answers: dict[str, str] = Field(default_factory=dict)
    draft: str | None = None

    def save(self, path: Path) -> None:
        """Save session to disk for resume."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.model_dump_json(indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> InterviewSession:
        """Load session from disk."""
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls.model_validate(data)


class InterviewEngine:
    """Drives a structured interview to produce a portfolio file.

    Takes callbacks for user I/O so it can be tested without actual stdin/stdout.
    """

    def __init__(
        self,
        store: PortfolioStore,
        synthesizer: Synthesizer,
        input_fn: Callable[[str], str] | None = None,
        output_fn: Callable[[str], None] | None = None,
    ) -> None:
        self._store = store
        self._synthesizer = synthesizer
        self._input_fn: Callable[[str], str] = input_fn or (lambda prompt: input(prompt))
        self._output_fn: Callable[[str], None] = output_fn or (lambda msg: print(msg))  # noqa: T201

    def _ask(self, prompt: str) -> str:
        """Get input from user."""
        return self._input_fn(prompt)

    def _say(self, message: str) -> None:
        """Display message to user."""
        self._output_fn(message)

    def run(
        self,
        file_name: str,
        session: InterviewSession | None = None,
        max_specificity_retries: int = 2,
    ) -> InterviewSession:
        """Run an interview for the given file.

        If session is provided, resume from that state.
        Returns the final session (state=COMPLETE if finished).
        """
        protocol = get_protocol(file_name)

        if session is None:
            session = InterviewSession(file_name=file_name)

        existing_content: str | None = None
        if self._store.file_exists(file_name):
            existing_content = self._store.read_file(file_name)

        if session.state == InterviewState.INTRO:
            self._say(f"\n{protocol.intro}\n")
            session.state = InterviewState.ASKING

        if session.state == InterviewState.ASKING:
            questions = protocol.questions
            while session.current_question_index < len(questions):
                q = questions[session.current_question_index]
                self._say(f"\n[{session.current_question_index + 1}/{len(questions)}] {q}")

                answer = self._ask("> ")

                if answer.strip().lower() in ("skip", "s"):
                    session.current_question_index += 1
                    continue

                retries = 0
                while not is_specific_enough(answer) and retries < max_specificity_retries:
                    follow_up = get_specificity_prompt(q)
                    self._say(f"\n{follow_up}")
                    answer = self._ask("> ")
                    retries += 1

                session.answers[q] = answer
                session.current_question_index += 1

            session.state = InterviewState.SYNTHESIZING

        if session.state == InterviewState.SYNTHESIZING:
            self._say("\nSynthesizing your answers...")
            draft = self._synthesizer.synthesize(
                file_name=file_name,
                protocol=protocol,
                answers=session.answers,
                existing_content=existing_content,
            )
            session.draft = draft
            session.state = InterviewState.REVIEWING

        if session.state == InterviewState.REVIEWING:
            max_revisions = 3
            revision_count = 0

            while revision_count < max_revisions:
                self._say(f"\n--- Draft ---\n{session.draft}\n--- End Draft ---\n")
                response = self._ask("Accept this draft? (yes/no/feedback): ")

                if response.strip().lower() in ("yes", "y"):
                    session.state = InterviewState.COMPLETE
                    break
                elif response.strip().lower() in ("no", "n"):
                    self._say("Draft rejected. You can edit the file manually with 'mudra edit'.")
                    session.state = InterviewState.COMPLETE
                    session.draft = None
                    break
                else:
                    self._say("\nRevising based on your feedback...")
                    session.draft = self._synthesizer.revise(
                        content=session.draft or "",
                        feedback=response,
                        protocol=protocol,
                    )
                    revision_count += 1

            if revision_count >= max_revisions:
                self._say("Maximum revisions reached. Accepting current draft.")
                session.state = InterviewState.COMPLETE

        return session

    def session_path(self, file_name: str) -> Path:
        """Return the path for saving/loading a session."""
        return self._store.metadata_dir / f"interview_session_{file_name}.json"
