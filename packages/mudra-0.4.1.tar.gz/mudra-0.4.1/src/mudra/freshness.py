from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from pydantic import BaseModel

from mudra.tiers import ALL_FILES, DEFAULT_STALENESS_DAYS


class FileStatus(BaseModel):
    """Tracks the freshness status of a single portfolio file."""

    last_updated: datetime | None = None
    staleness_days: int = 30

    @property
    def status(self) -> str:
        """Return 'fresh', 'stale', or 'unknown'."""
        if self.last_updated is None:
            return "unknown"
        if self.days_since_update is None:
            return "unknown"
        if self.days_since_update > self.staleness_days:
            return "stale"
        return "fresh"

    @property
    def days_since_update(self) -> int | None:
        """Return number of days since the file was last updated, or None if never updated."""
        if self.last_updated is None:
            return None
        now = datetime.now(tz=UTC)
        last = (
            self.last_updated
            if self.last_updated.tzinfo
            else self.last_updated.replace(tzinfo=UTC)
        )
        delta = now - last
        return delta.days


class FreshnessTracker:
    """Manages freshness metadata for all portfolio files."""

    def __init__(self, metadata_dir: Path) -> None:
        self._metadata_dir = metadata_dir
        self._data: dict[str, FileStatus] = {}
        self._file = metadata_dir / "freshness.json"

    def load(self) -> dict[str, FileStatus]:
        """Load freshness data from disk. Returns the loaded data."""
        if not self._file.exists():
            self._data = {}
            return self._data
        raw = self._file.read_text(encoding="utf-8")
        parsed = json.loads(raw)
        self._data = {}
        for name, entry in parsed.items():
            self._data[name] = FileStatus.model_validate(entry)
        return self._data

    def save(self) -> None:
        """Persist freshness data to disk."""
        self._metadata_dir.mkdir(parents=True, exist_ok=True)
        serialized: dict[str, object] = {
            name: status.model_dump(mode="json") for name, status in self._data.items()
        }
        self._file.write_text(json.dumps(serialized, indent=2), encoding="utf-8")

    def update(self, name: str) -> None:
        """Mark a file as just updated (set last_updated to now)."""
        staleness = DEFAULT_STALENESS_DAYS.get(name, 30)
        self._data[name] = FileStatus(
            last_updated=datetime.now(tz=UTC),
            staleness_days=staleness,
        )

    def get_status(self, name: str) -> FileStatus:
        """Get the status for a file. Returns a default FileStatus if not tracked."""
        if name in self._data:
            return self._data[name]
        staleness = DEFAULT_STALENESS_DAYS.get(name, 30)
        return FileStatus(staleness_days=staleness)

    def get_stale_files(self) -> list[str]:
        """Return names of all tracked files that are stale."""
        stale: list[str] = []
        for name in ALL_FILES:
            if name in self._data and self._data[name].status == "stale":
                stale.append(name)
        return stale
