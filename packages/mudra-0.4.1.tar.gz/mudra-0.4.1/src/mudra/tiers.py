from __future__ import annotations

CORE_FILES: list[str] = [
    "identity",
    "tools-and-systems",
    "communication-style",
    "preferences-and-constraints",
]

EXTENDED_FILES: list[str] = [
    "role-and-responsibilities",
    "current-projects",
    "team-and-relationships",
    "goals-and-priorities",
    "domain-knowledge",
    "decision-log",
]

ALL_FILES: list[str] = CORE_FILES + EXTENDED_FILES

DEFAULT_STALENESS_DAYS: dict[str, int] = {
    "identity": 90,
    "tools-and-systems": 60,
    "communication-style": 90,
    "preferences-and-constraints": 60,
    "role-and-responsibilities": 60,
    "current-projects": 21,
    "team-and-relationships": 30,
    "goals-and-priorities": 30,
    "domain-knowledge": 90,
    "decision-log": 30,
}


def is_core(name: str) -> bool:
    """Return True if the given name is a core portfolio file."""
    return name in CORE_FILES


def is_extended(name: str) -> bool:
    """Return True if the given name is an extended portfolio file."""
    return name in EXTENDED_FILES


def is_valid_file(name: str) -> bool:
    """Return True if the given name is a recognized portfolio file."""
    return name in ALL_FILES


def get_file_extension(name: str) -> str:
    """Return the file extension for a portfolio file name.

    All files use .md except decision-log which uses .jsonl.
    Raises ValueError for unrecognized file names.
    """
    if not is_valid_file(name):
        msg = f"Unknown portfolio file: {name}"
        raise ValueError(msg)
    if name == "decision-log":
        return ".jsonl"
    return ".md"
