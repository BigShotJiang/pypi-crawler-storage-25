from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from enum import Enum

import yaml

from mudra.freshness import FreshnessTracker
from mudra.git import git_has_changes
from mudra.store import PortfolioStore
from mudra.tiers import CORE_FILES


class Severity(Enum):
    """Severity level for a validation finding."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class CheckResult:
    """Single validation finding."""

    severity: Severity
    file: str | None
    message: str
    suggestion: str | None = None


@dataclass
class ValidationReport:
    """Complete validation report."""

    results: list[CheckResult] = field(default_factory=list)

    @property
    def errors(self) -> list[CheckResult]:
        return [r for r in self.results if r.severity is Severity.ERROR]

    @property
    def warnings(self) -> list[CheckResult]:
        return [r for r in self.results if r.severity is Severity.WARNING]

    @property
    def infos(self) -> list[CheckResult]:
        return [r for r in self.results if r.severity is Severity.INFO]

    @property
    def has_errors(self) -> bool:
        return any(r.severity is Severity.ERROR for r in self.results)

    @property
    def has_warnings(self) -> bool:
        return any(r.severity is Severity.WARNING for r in self.results)

    def exit_code(self, strict: bool = False) -> int:
        """0 if clean, 1 if errors (or warnings in strict mode)."""
        if self.has_errors:
            return 1
        if strict and self.has_warnings:
            return 1
        return 0

    def format_text(self) -> str:
        """Human-readable report with symbols: [ERROR], [WARN], [INFO]."""
        if not self.results:
            return "No issues found."
        labels = {
            Severity.ERROR: "[ERROR]",
            Severity.WARNING: "[WARN]",
            Severity.INFO: "[INFO]",
        }
        lines: list[str] = []
        for r in self.results:
            label = labels[r.severity]
            file_part = f" {r.file}:" if r.file else ""
            lines.append(f"{label}{file_part} {r.message}")
            if r.suggestion:
                lines.append(f"  -> {r.suggestion}")
        return "\n".join(lines)

    def format_json(self) -> str:
        """Machine-readable JSON report."""
        entries: list[dict[str, str | None]] = []
        for r in self.results:
            entries.append(
                {
                    "severity": r.severity.value,
                    "file": r.file,
                    "message": r.message,
                    "suggestion": r.suggestion,
                }
            )
        return json.dumps(entries, indent=2)


_FRONTMATTER_RE = re.compile(r"\A---\n(.*?\n)---\n?", re.DOTALL)
_HTML_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)


def strip_comments_and_frontmatter(content: str) -> str:
    """Remove YAML frontmatter and HTML comments, return meaningful content."""
    text = _FRONTMATTER_RE.sub("", content)
    text = _HTML_COMMENT_RE.sub("", text)
    return text.strip()


def word_count(text: str) -> int:
    """Count words in text after stripping frontmatter and comments."""
    cleaned = strip_comments_and_frontmatter(text)
    if not cleaned:
        return 0
    return len(cleaned.split())


def parse_frontmatter(content: str) -> dict[str, object] | None:
    """Parse YAML frontmatter. Return None if no frontmatter. Raise ValueError if malformed."""
    match = _FRONTMATTER_RE.match(content)
    if match is None:
        return None
    raw = match.group(1)
    try:
        parsed = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        msg = f"Malformed YAML frontmatter: {exc}"
        raise ValueError(msg) from exc
    if not isinstance(parsed, dict):
        msg = f"Frontmatter must be a YAML mapping, got {type(parsed).__name__}"
        raise ValueError(msg)
    result: dict[str, object] = parsed
    return result


def check_core_files_exist(store: PortfolioStore) -> list[CheckResult]:
    """ERROR if any of the 4 core files are missing."""
    results: list[CheckResult] = []
    for name in CORE_FILES:
        if not store.file_exists(name):
            results.append(
                CheckResult(
                    severity=Severity.ERROR,
                    file=name,
                    message=f"Core file '{name}' is missing",
                    suggestion=f"Run 'mudra init' to create {name}",
                )
            )
    return results


def check_files_not_empty(store: PortfolioStore) -> list[CheckResult]:
    """ERROR if any existing file has <10 chars of real content."""
    results: list[CheckResult] = []
    for name in store.list_files():
        # Skip decision-log -- it's JSONL, not markdown
        if name == "decision-log":
            continue
        content = store.read_file(name)
        cleaned = strip_comments_and_frontmatter(content)
        if len(cleaned) < 10:
            results.append(
                CheckResult(
                    severity=Severity.ERROR,
                    file=name,
                    message=f"File '{name}' has no meaningful content (only template/comments)",
                    suggestion=f"Edit {name} and add real content",
                )
            )
    return results


def check_frontmatter_valid(store: PortfolioStore) -> list[CheckResult]:
    """WARNING if any file has malformed YAML frontmatter."""
    results: list[CheckResult] = []
    for name in store.list_files():
        if name == "decision-log":
            continue
        content = store.read_file(name)
        try:
            parse_frontmatter(content)
        except ValueError as exc:
            results.append(
                CheckResult(
                    severity=Severity.WARNING,
                    file=name,
                    message=str(exc),
                    suggestion="Fix the YAML frontmatter at the top of the file",
                )
            )
    return results


def check_freshness(
    store: PortfolioStore,
    tracker: FreshnessTracker,
) -> list[CheckResult]:
    """WARNING for stale files (past their staleness threshold)."""
    results: list[CheckResult] = []
    for name in store.list_files():
        status = tracker.get_status(name)
        if status.status == "stale":
            days = status.days_since_update
            days_str = f" ({days} days ago)" if days is not None else ""
            results.append(
                CheckResult(
                    severity=Severity.WARNING,
                    file=name,
                    message=f"File '{name}' is stale{days_str}",
                    suggestion=f"Review and update {name}",
                )
            )
    return results


def check_completeness_score(store: PortfolioStore) -> list[CheckResult]:
    """INFO with completeness percentage -- core files with >100 words of real content."""
    complete_count = 0
    for name in CORE_FILES:
        if store.file_exists(name):
            content = store.read_file(name)
            if word_count(content) > 100:
                complete_count += 1
    total = len(CORE_FILES)
    pct = int((complete_count / total) * 100)
    return [
        CheckResult(
            severity=Severity.INFO,
            file=None,
            message=(
                f"Portfolio completeness: {pct}%"
                f" ({complete_count}/{total} core files with >100 words)"
            ),
        )
    ]


def check_git_status(store: PortfolioStore) -> list[CheckResult]:
    """INFO if there are uncommitted changes in the portfolio git repo."""
    repo_path = store.path
    if not (repo_path / ".git").is_dir():
        return [
            CheckResult(
                severity=Severity.INFO,
                file=None,
                message="Portfolio is not a git repository",
                suggestion="Run 'mudra init' to initialize git tracking",
            )
        ]
    try:
        has_changes = git_has_changes(repo_path)
    except (RuntimeError, OSError):
        return [
            CheckResult(
                severity=Severity.INFO,
                file=None,
                message="Could not determine git status",
            )
        ]
    if has_changes:
        return [
            CheckResult(
                severity=Severity.INFO,
                file=None,
                message="Uncommitted changes in portfolio",
                suggestion="Run 'mudra snapshot' to commit changes",
            )
        ]
    return [
        CheckResult(
            severity=Severity.INFO,
            file=None,
            message="Portfolio git status is clean",
        )
    ]


def check_decision_log_valid(store: PortfolioStore) -> list[CheckResult]:
    """WARNING for malformed JSONL entries in decision-log.jsonl (if it exists)."""
    if not store.file_exists("decision-log"):
        return []
    content = store.read_file("decision-log")
    results: list[CheckResult] = []
    for i, line in enumerate(content.splitlines(), start=1):
        stripped = line.strip()
        if not stripped:
            continue
        try:
            entry = json.loads(stripped)
        except json.JSONDecodeError as exc:
            results.append(
                CheckResult(
                    severity=Severity.WARNING,
                    file="decision-log",
                    message=f"Line {i}: invalid JSON -- {exc}",
                    suggestion="Fix or remove the malformed line",
                )
            )
            continue
        if not isinstance(entry, dict):
            results.append(
                CheckResult(
                    severity=Severity.WARNING,
                    file="decision-log",
                    message=f"Line {i}: entry is not a JSON object",
                    suggestion="Each line must be a JSON object",
                )
            )
    return results


def run_all_checks(
    store: PortfolioStore,
    tracker: FreshnessTracker,
    file_filter: str | None = None,
) -> ValidationReport:
    """Run all checks. If file_filter provided, only run checks relevant to that file."""
    all_results: list[CheckResult] = []

    if file_filter is None:
        all_results.extend(check_core_files_exist(store))
        all_results.extend(check_files_not_empty(store))
        all_results.extend(check_frontmatter_valid(store))
        all_results.extend(check_freshness(store, tracker))
        all_results.extend(check_completeness_score(store))
        all_results.extend(check_git_status(store))
        all_results.extend(check_decision_log_valid(store))
    else:
        # File-specific checks
        if file_filter in CORE_FILES and not store.file_exists(file_filter):
            all_results.append(
                CheckResult(
                    severity=Severity.ERROR,
                    file=file_filter,
                    message=f"Core file '{file_filter}' is missing",
                    suggestion=f"Run 'mudra init' to create {file_filter}",
                )
            )

        if store.file_exists(file_filter):
            if file_filter != "decision-log":
                # Not-empty check
                content = store.read_file(file_filter)
                cleaned = strip_comments_and_frontmatter(content)
                if len(cleaned) < 10:
                    all_results.append(
                        CheckResult(
                            severity=Severity.ERROR,
                            file=file_filter,
                            message=(
                                f"File '{file_filter}' has no meaningful content"
                                " (only template/comments)"
                            ),
                            suggestion=f"Edit {file_filter} and add real content",
                        )
                    )

                # Frontmatter check
                try:
                    parse_frontmatter(content)
                except ValueError as exc:
                    all_results.append(
                        CheckResult(
                            severity=Severity.WARNING,
                            file=file_filter,
                            message=str(exc),
                            suggestion="Fix the YAML frontmatter at the top of the file",
                        )
                    )

            # Freshness check
            status = tracker.get_status(file_filter)
            if status.status == "stale":
                days = status.days_since_update
                days_str = f" ({days} days ago)" if days is not None else ""
                all_results.append(
                    CheckResult(
                        severity=Severity.WARNING,
                        file=file_filter,
                        message=f"File '{file_filter}' is stale{days_str}",
                        suggestion=f"Review and update {file_filter}",
                    )
                )

            # Decision log check
            if file_filter == "decision-log":
                all_results.extend(check_decision_log_valid(store))

    # Filter results to only include those relevant to the file
    if file_filter is not None:
        all_results = [r for r in all_results if r.file is None or r.file == file_filter]

    return ValidationReport(results=all_results)
