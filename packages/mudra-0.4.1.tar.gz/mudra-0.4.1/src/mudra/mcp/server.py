from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from mudra.freshness import FreshnessTracker
from mudra.mcp.resources import (
    get_all_files,
    get_role_context,
    get_single_file,
    get_status_report,
)
from mudra.store import PortfolioStore


def _register_resources(
    mcp: FastMCP[None],
    store: PortfolioStore,
    tracker: FreshnessTracker,
) -> None:
    """Register all portfolio resources on the given FastMCP instance.

    Static routes are registered before the catch-all {file_name} pattern
    so that 'all', 'status', and 'role/' are not captured by it.
    """

    @mcp.resource("mudra://portfolio/all")
    def portfolio_all() -> str:
        return get_all_files(store, tracker)

    @mcp.resource("mudra://portfolio/status")
    def portfolio_status() -> str:
        return get_status_report(store, tracker)

    @mcp.resource("mudra://portfolio/role/{role_name}")
    def portfolio_role(role_name: str) -> str:
        return get_role_context(store, tracker, role_name)

    @mcp.resource("mudra://portfolio/{file_name}")
    def portfolio_file(file_name: str) -> str:
        return get_single_file(store, tracker, file_name)


def create_mcp_server(
    store: PortfolioStore,
    tracker: FreshnessTracker,
    port: int = 3100,
) -> FastMCP[None]:
    """Create and configure the MCP server with resource handlers.

    Registers these resources:
    - mudra://portfolio/{file_name} -- single file
    - mudra://portfolio/role/{role_name} -- role-based context
    - mudra://portfolio/all -- all files
    - mudra://portfolio/status -- freshness report
    """
    mcp: FastMCP[None] = FastMCP("mudra", port=port)
    _register_resources(mcp, store, tracker)
    return mcp


def run_server(
    store: PortfolioStore,
    tracker: FreshnessTracker,
    transport: str = "stdio",
    port: int = 3100,
) -> None:
    """Create and run the MCP server."""
    server = create_mcp_server(store, tracker, port=port)
    if transport == "streamable-http":
        server.run(transport="streamable-http")
    else:
        server.run(transport="stdio")
