from __future__ import annotations

from mudra.export._helpers import file_name_to_title, strip_frontmatter
from mudra.freshness import FileStatus, FreshnessTracker
from mudra.router.selector import RoutingConfig, load_routing_config, resolve_role
from mudra.store import PortfolioStore


def _format_file_section(file_name: str, content: str) -> str:
    """Format a single file as a titled markdown section with frontmatter stripped."""
    title = file_name_to_title(file_name)
    body = strip_frontmatter(content)
    return f"## {title}\n\n{body}"


def format_freshness_warning(stale_files: list[tuple[str, FileStatus]]) -> str:
    """Format freshness warning as an HTML comment block.

    Returns an empty string when no files are stale.
    """
    if not stale_files:
        return ""

    lines = [
        "<!-- mudra:freshness-warning",
        "stale_files:",
    ]
    for file_name, status in stale_files:
        days_since = status.days_since_update
        last_updated_str = (
            status.last_updated.strftime("%Y-%m-%d")
            if status.last_updated is not None
            else "never"
        )
        staleness_days = days_since if days_since is not None else 0
        days_overdue = max(0, staleness_days - status.staleness_days)
        lines.append(f"  - file: {file_name}")
        lines.append(f"    last_updated: {last_updated_str}")
        lines.append(f"    staleness_days: {staleness_days}")
        lines.append(f"    days_overdue: {days_overdue}")
    lines.append("-->")
    return "\n".join(lines)


def _collect_stale_files(
    store: PortfolioStore,
    tracker: FreshnessTracker,
) -> list[tuple[str, FileStatus]]:
    """Collect stale file statuses for all files in the portfolio."""
    stale: list[tuple[str, FileStatus]] = []
    for file_name in store.list_files():
        status = tracker.get_status(file_name)
        if status.status == "stale":
            stale.append((file_name, status))
    return stale


def get_single_file(
    store: PortfolioStore,
    tracker: FreshnessTracker,
    file_name: str,
) -> str:
    """Read a single portfolio file by name.

    Returns file content with freshness warning appended if stale.
    Raises FileNotFoundError if the file does not exist.
    """
    content = store.read_file(file_name)
    result = _format_file_section(file_name, content)

    status = tracker.get_status(file_name)
    if status.status == "stale":
        warning = format_freshness_warning([(file_name, status)])
        result = f"{result}\n\n{warning}"

    return result


def _combine_files(
    store: PortfolioStore,
    tracker: FreshnessTracker,
    file_names: list[str],
) -> str:
    """Read, format, and combine portfolio files with freshness warnings."""
    sections: list[str] = []
    stale_files: list[tuple[str, FileStatus]] = []

    for file_name in file_names:
        content = store.read_file(file_name)
        sections.append(_format_file_section(file_name, content))

        status = tracker.get_status(file_name)
        if status.status == "stale":
            stale_files.append((file_name, status))

    result = "\n\n".join(sections)
    warning = format_freshness_warning(stale_files)
    if warning:
        result = f"{result}\n\n{warning}"

    return result


def get_role_context(
    store: PortfolioStore,
    tracker: FreshnessTracker,
    role: str,
    routing_config: RoutingConfig | None = None,
) -> str:
    """Resolve a role to files using the router and return combined content.

    If routing_config is not provided, loads from the store's metadata dir.
    """
    if routing_config is None:
        routing_config = load_routing_config(store.metadata_dir / "routing.toml")
    file_names = resolve_role(role, routing_config, store)
    return _combine_files(store, tracker, file_names)


def get_all_files(
    store: PortfolioStore,
    tracker: FreshnessTracker,
) -> str:
    """Read all existing portfolio files and combine them."""
    file_names = store.list_files()
    if not file_names:
        return "No portfolio files found."
    return _combine_files(store, tracker, file_names)


def get_status_report(
    store: PortfolioStore,
    tracker: FreshnessTracker,
) -> str:
    """Generate a freshness status report as markdown."""
    file_names = store.list_files()
    if not file_names:
        return "# Portfolio Status\n\nNo portfolio files found."

    lines = [
        "# Portfolio Status",
        "",
        "| File | Status | Last Updated | Days Since Update |",
        "|------|--------|--------------|-------------------|",
    ]

    for file_name in file_names:
        status = tracker.get_status(file_name)
        last_updated_str = (
            status.last_updated.strftime("%Y-%m-%d")
            if status.last_updated is not None
            else "never"
        )
        days_since = status.days_since_update
        days_str = str(days_since) if days_since is not None else "n/a"
        title = file_name_to_title(file_name)
        lines.append(f"| {title} | {status.status} | {last_updated_str} | {days_str} |")

    stale = _collect_stale_files(store, tracker)
    if stale:
        lines.append("")
        lines.append(format_freshness_warning(stale))

    return "\n".join(lines)
