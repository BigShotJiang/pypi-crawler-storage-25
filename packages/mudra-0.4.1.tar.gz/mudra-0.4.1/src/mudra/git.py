from __future__ import annotations

import subprocess
from pathlib import Path

GITIGNORE_CONTENT = """\
# Mudra metadata
.mudra/config.toml

# Python
__pycache__/
*.py[cod]
*.egg-info/
dist/
build/
.venv/
"""


def _run_git(repo_path: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    """Run a git command in the given repo directory.

    Raises RuntimeError if git is not installed.
    Raises subprocess.CalledProcessError on non-zero exit (when check=True).
    """
    try:
        return subprocess.run(
            ["git", *args],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=check,
        )
    except FileNotFoundError:
        msg = "git is not installed or not found in PATH"
        raise RuntimeError(msg) from None


def _ensure_git_identity(repo_path: Path) -> None:
    """Set local git identity if not configured globally or locally."""
    result = _run_git(repo_path, "config", "user.name", check=False)
    if result.returncode != 0 or not result.stdout.strip():
        _run_git(repo_path, "config", "user.name", "mudra")
    result = _run_git(repo_path, "config", "user.email", check=False)
    if result.returncode != 0 or not result.stdout.strip():
        _run_git(repo_path, "config", "user.email", "mudra@localhost")


def git_init(repo_path: Path) -> None:
    """Initialize a git repo. Idempotent -- no-op if .git/ exists."""
    if (repo_path / ".git").is_dir():
        return
    _run_git(repo_path, "init")
    _ensure_git_identity(repo_path)


def git_add(repo_path: Path, *files: str) -> None:
    """Stage files for commit."""
    if not files:
        return
    _run_git(repo_path, "add", *files)


def git_commit(repo_path: Path, message: str) -> bool:
    """Commit staged changes.

    Returns True if a commit was created, False if nothing to commit.
    """
    result = _run_git(repo_path, "commit", "-m", message, check=False)
    if result.returncode == 0:
        return True
    if "nothing to commit" in result.stdout or "nothing to commit" in result.stderr:
        return False
    msg = f"git commit failed: {result.stderr.strip()}"
    raise RuntimeError(msg)


def git_log(repo_path: Path, file: str | None = None, max_count: int = 20) -> list[dict[str, str]]:
    """Return list of commit dicts with keys: hash, message, date."""
    args = ["log", f"--max-count={max_count}", "--format=%H%n%s%n%aI%n---"]
    if file is not None:
        args.append("--")
        args.append(file)
    result = _run_git(repo_path, *args, check=False)
    if result.returncode != 0:
        return []
    entries: list[dict[str, str]] = []
    raw = result.stdout.strip()
    if not raw:
        return entries
    blocks = raw.split("---\n")
    for block in blocks:
        block = block.strip()
        if not block:
            continue
        lines = block.split("\n", 2)
        if len(lines) >= 3:
            entries.append(
                {
                    "hash": lines[0],
                    "message": lines[1],
                    "date": lines[2],
                }
            )
    return entries


def git_diff(repo_path: Path, file: str | None = None) -> str:
    """Return diff output for the repo or a specific file."""
    args = ["diff"]
    if file is not None:
        args.append("--")
        args.append(file)
    result = _run_git(repo_path, *args)
    return result.stdout


def git_has_changes(repo_path: Path) -> bool:
    """Check if there are uncommitted changes (staged or unstaged)."""
    result = _run_git(repo_path, "status", "--porcelain")
    return bool(result.stdout.strip())


def create_gitignore(repo_path: Path) -> None:
    """Create .gitignore that excludes .mudra/config.toml and common artifacts."""
    gitignore_path = repo_path / ".gitignore"
    gitignore_path.write_text(GITIGNORE_CONTENT, encoding="utf-8")
