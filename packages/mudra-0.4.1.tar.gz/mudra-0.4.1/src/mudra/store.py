from __future__ import annotations

import shutil
import tomllib
from pathlib import Path

from mudra.tiers import ALL_FILES, CORE_FILES, EXTENDED_FILES, get_file_extension, is_valid_file


class PortfolioStore:
    """Manages file I/O for a Mudra portfolio directory."""

    def __init__(self, path: Path | None = None, profile: str | None = None) -> None:
        """Resolve portfolio path.

        Default: ~/.mudra/
        Profile: ~/.mudra/profiles/{name}/
        Explicit path overrides both.
        """
        if path is not None:
            self._path = path
        elif profile is not None:
            self._path = Path.home() / ".mudra" / "profiles" / profile
        else:
            self._path = Path.home() / ".mudra"

    @property
    def path(self) -> Path:
        """Return the root path of the portfolio."""
        return self._path

    @property
    def metadata_dir(self) -> Path:
        """Return the .mudra/ metadata subdirectory within the portfolio."""
        return self._path / ".mudra"

    def ensure_dirs(self) -> None:
        """Create portfolio dir and .mudra/ metadata dir if missing."""
        self._path.mkdir(parents=True, exist_ok=True)
        self.metadata_dir.mkdir(parents=True, exist_ok=True)

    def file_path(self, name: str) -> Path:
        """Return full path for a portfolio file.

        Raises ValueError for unrecognized file names.
        """
        ext = get_file_extension(name)
        return self._path / f"{name}{ext}"

    def file_exists(self, name: str) -> bool:
        """Return True if the portfolio file exists on disk."""
        if not is_valid_file(name):
            return False
        return self.file_path(name).exists()

    def list_files(self) -> list[str]:
        """Return names of all portfolio files that exist on disk."""
        return [name for name in ALL_FILES if self.file_exists(name)]

    def list_core_files(self) -> list[str]:
        """Return names of core portfolio files that exist on disk."""
        return [name for name in CORE_FILES if self.file_exists(name)]

    def list_extended_files(self) -> list[str]:
        """Return names of extended portfolio files that exist on disk."""
        return [name for name in EXTENDED_FILES if self.file_exists(name)]

    def read_file(self, name: str) -> str:
        """Read file content.

        Raises FileNotFoundError if the file does not exist.
        Raises ValueError for unrecognized file names.
        """
        fp = self.file_path(name)
        if not fp.exists():
            msg = f"Portfolio file not found: {fp}"
            raise FileNotFoundError(msg)
        return fp.read_text(encoding="utf-8")

    def write_file(self, name: str, content: str) -> None:
        """Write content to a portfolio file. Create parent dirs if needed."""
        fp = self.file_path(name)
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content, encoding="utf-8")

    def create_from_template(self, name: str, templates_dir: Path) -> None:
        """Copy a template file into the portfolio.

        Raises FileNotFoundError if the template does not exist.
        Raises ValueError for unrecognized file names.
        """
        ext = get_file_extension(name)
        template_file = templates_dir / f"{name}{ext}"
        if not template_file.exists():
            msg = f"Template not found: {template_file}"
            raise FileNotFoundError(msg)
        dest = self.file_path(name)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(template_file, dest)

    @staticmethod
    def resolve_templates_dir() -> Path:
        """Find the templates/ directory relative to this package."""
        return Path(__file__).parent.parent.parent / "templates"

    @staticmethod
    def resolve_community_templates_dir() -> Path:
        """Find the community-templates/ directory relative to this package."""
        return Path(__file__).parent.parent.parent / "community-templates"

    @staticmethod
    def list_community_templates() -> list[str]:
        """Return names of available community templates."""
        templates_dir = PortfolioStore.resolve_community_templates_dir()
        if not templates_dir.is_dir():
            return []
        return sorted(
            d.name
            for d in templates_dir.iterdir()
            if d.is_dir() and (d / "template.toml").exists()
        )

    @staticmethod
    def load_template_metadata(template_name: str) -> dict[str, object]:
        """Load template.toml metadata for a community template."""
        template_dir = PortfolioStore.resolve_community_templates_dir() / template_name
        meta_path = template_dir / "template.toml"
        if not meta_path.exists():
            msg = f"Template not found: {template_name}"
            raise FileNotFoundError(msg)
        with meta_path.open("rb") as f:
            data = tomllib.load(f)
        result: dict[str, object] = data.get("template", {})
        return result
