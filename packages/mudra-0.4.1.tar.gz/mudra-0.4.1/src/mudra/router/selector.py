from __future__ import annotations

import tomllib
from pathlib import Path

import tomli_w
from pydantic import BaseModel, Field

from mudra.store import PortfolioStore


class RoleConfig(BaseModel):
    """Configuration for a single routing role."""

    description: str = ""
    files: list[str] = Field(default_factory=list)


DEFAULT_ROLES: dict[str, RoleConfig] = {
    "general-assistant": RoleConfig(
        description="Default context for general-purpose AI assistants",
        files=["identity", "communication-style", "preferences-and-constraints"],
    ),
    "code-review": RoleConfig(
        description="Context for code review and technical feedback",
        files=[
            "identity",
            "communication-style",
            "tools-and-systems",
            "preferences-and-constraints",
        ],
    ),
    "meeting-prep": RoleConfig(
        description="Context for preparing meeting agendas and 1:1 notes",
        files=["identity", "team-and-relationships", "current-projects", "goals-and-priorities"],
    ),
    "writing-assistant": RoleConfig(
        description="Context for drafting posts, docs, and communications",
        files=["identity", "communication-style", "domain-knowledge"],
    ),
    "strategic-advisor": RoleConfig(
        description="Context for strategic planning and decision-making",
        files=[
            "identity",
            "goals-and-priorities",
            "current-projects",
            "decision-log",
            "preferences-and-constraints",
        ],
    ),
    "career-coach": RoleConfig(
        description="Context for career development and growth planning",
        files=[
            "identity",
            "role-and-responsibilities",
            "goals-and-priorities",
            "domain-knowledge",
            "decision-log",
        ],
    ),
    "full": RoleConfig(
        description="All portfolio files",
        files=["*"],
    ),
}


class RoutingConfig(BaseModel):
    """Top-level routing configuration with role definitions."""

    roles: dict[str, RoleConfig] = Field(default_factory=lambda: dict(DEFAULT_ROLES))


def load_routing_config(routing_path: Path) -> RoutingConfig:
    """Load routing.toml. If missing, return default config."""
    if not routing_path.exists():
        return RoutingConfig()
    with routing_path.open("rb") as f:
        data = tomllib.load(f)
    roles_raw = data.get("roles", {})
    roles: dict[str, RoleConfig] = {}
    for name, role_data in roles_raw.items():
        if isinstance(role_data, dict):
            roles[name] = RoleConfig.model_validate(role_data)
    return RoutingConfig(roles=roles)


def resolve_role(
    role: str,
    config: RoutingConfig,
    store: PortfolioStore,
) -> list[str]:
    """Resolve a role name to a list of existing portfolio file names.

    1. Look up role in config.roles
    2. If role not found, fall back to 'general-assistant'
    3. If files contains '*', return all existing files
    4. Filter file list to only files that exist in the portfolio
    5. Return deduplicated list preserving order
    """
    role_config = config.roles.get(role)
    if role_config is None:
        role_config = config.roles.get("general-assistant", DEFAULT_ROLES["general-assistant"])

    if "*" in role_config.files:
        return store.list_files()

    seen: set[str] = set()
    result: list[str] = []
    for file_name in role_config.files:
        if file_name in seen:
            continue
        seen.add(file_name)
        if store.file_exists(file_name):
            result.append(file_name)
    return result


def list_roles(config: RoutingConfig) -> dict[str, RoleConfig]:
    """Return all defined roles."""
    return dict(config.roles)


def generate_routing_toml(config: RoutingConfig) -> str:
    """Serialize a RoutingConfig to TOML string for writing to routing.toml."""
    data: dict[str, object] = {
        "roles": {name: role.model_dump() for name, role in config.roles.items()},
    }
    return tomli_w.dumps(data)
