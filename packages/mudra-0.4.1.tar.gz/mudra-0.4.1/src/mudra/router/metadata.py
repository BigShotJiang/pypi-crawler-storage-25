from __future__ import annotations

import json
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

from pydantic import BaseModel


class RoutingEvent(BaseModel):
    """A single routing request event."""

    timestamp: str
    role: str
    files_requested: list[str]
    files_served: list[str]
    files_missing: list[str]


class RoutingMetadata:
    """Append-only JSONL log of routing requests."""

    def __init__(self, metadata_dir: Path) -> None:
        self._log_path = metadata_dir / "routing_usage.jsonl"

    def log_request(
        self,
        role: str,
        files_requested: list[str],
        files_served: list[str],
    ) -> None:
        """Append a routing event to the log."""
        missing = [f for f in files_requested if f not in files_served]
        event = RoutingEvent(
            timestamp=datetime.now(tz=UTC).isoformat(),
            role=role,
            files_requested=files_requested,
            files_served=files_served,
            files_missing=missing,
        )
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(event.model_dump_json() + "\n")

    def read_events(self, max_entries: int | None = None) -> list[RoutingEvent]:
        """Read routing events from the log.

        Returns up to max_entries most recent events, or all if max_entries is None.
        """
        if not self._log_path.exists():
            return []
        lines = self._log_path.read_text(encoding="utf-8").strip().splitlines()
        events = [RoutingEvent.model_validate(json.loads(line)) for line in lines]
        if max_entries is not None:
            return events[-max_entries:]
        return events

    def summary(self) -> dict[str, int]:
        """Return {role: request_count} for all logged roles."""
        events = self.read_events()
        return dict(Counter(event.role for event in events))

    def most_requested_roles(self, limit: int = 5) -> list[tuple[str, int]]:
        """Return top N most-requested roles as (role, count) tuples, sorted descending."""
        counts = self.summary()
        sorted_roles = sorted(counts.items(), key=lambda x: x[1], reverse=True)
        return sorted_roles[:limit]

    def most_missing_files(self, limit: int = 5) -> list[tuple[str, int]]:
        """Return top N most-frequently-missing files as (file, count) tuples.

        A file is "missing" when it appears in files_requested but not in files_served.
        """
        events = self.read_events()
        missing_counts = Counter(f for event in events for f in event.files_missing)
        return missing_counts.most_common(limit)

    def format_report(self) -> str:
        """Generate a human-readable analytics report as formatted text."""
        events = self.read_events()
        if not events:
            return "No routing data collected yet."

        lines = [
            f"Routing Analytics ({len(events)} total requests)",
            "=" * 45,
            "",
            "Most Requested Roles:",
        ]

        for role, count in self.most_requested_roles():
            lines.append(f"  {role}: {count} requests")

        missing = self.most_missing_files()
        if missing:
            lines.append("")
            lines.append("Most Frequently Missing Files:")
            for file_name, count in missing:
                lines.append(f"  {file_name}: missing in {count} requests")
            lines.append("")
            lines.append("Suggestion: Consider adding these files with 'mudra add <file>'")

        return "\n".join(lines)
