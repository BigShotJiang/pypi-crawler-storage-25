from __future__ import annotations

import json
import sys
from datetime import UTC, datetime

from pydantic import BaseModel, Field

from mudra.store import PortfolioStore


class DecisionEntry(BaseModel):
    """A single decision log entry."""

    date: str
    decision: str
    context: str | None = None
    tags: list[str] = Field(default_factory=list)
    outcome: str | None = None


class DecisionLog:
    """JSONL-based append-only decision log stored in a portfolio."""

    FILENAME = "decision-log"

    def __init__(self, store: PortfolioStore) -> None:
        self._store = store
        self._path = store.file_path(self.FILENAME)

    def append(
        self,
        decision: str,
        context: str | None = None,
        tags: list[str] | None = None,
    ) -> DecisionEntry:
        """Append a new decision entry. Auto-generates today's date."""
        entry = DecisionEntry(
            date=datetime.now(tz=UTC).strftime("%Y-%m-%d"),
            decision=decision,
            context=context,
            tags=tags or [],
        )
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with self._path.open("a", encoding="utf-8") as f:
            f.write(entry.model_dump_json() + "\n")
        return entry

    def read(self, max_entries: int | None = None) -> list[DecisionEntry]:
        """Read entries from the log. Skips malformed lines with a warning to stderr."""
        if not self._path.exists():
            return []
        entries: list[DecisionEntry] = []
        with self._path.open("r", encoding="utf-8") as f:
            for line_num, line in enumerate(f, start=1):
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    data = json.loads(stripped)
                    entries.append(DecisionEntry.model_validate(data))
                except (json.JSONDecodeError, ValueError) as exc:
                    print(
                        f"WARNING: skipping malformed line {line_num} in decision log: {exc}",
                        file=sys.stderr,
                    )
        if max_entries is not None:
            return entries[-max_entries:]
        return entries

    def filter_by_tag(self, tag: str) -> list[DecisionEntry]:
        """Return entries that contain the given tag."""
        return [e for e in self.read() if tag in e.tags]

    def render_markdown(self) -> str:
        """Render all entries as a markdown table."""
        entries = self.read()
        if not entries:
            return "No decisions logged."
        lines = [
            "| Date | Decision | Context | Tags |",
            "|------|----------|---------|------|",
        ]
        for e in entries:
            ctx = e.context or ""
            tags = ", ".join(e.tags) if e.tags else ""
            lines.append(f"| {e.date} | {e.decision} | {ctx} | {tags} |")
        return "\n".join(lines)
