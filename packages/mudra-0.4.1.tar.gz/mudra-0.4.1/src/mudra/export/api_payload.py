from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from mudra import __version__
from mudra.export._helpers import resolve_files, strip_frontmatter
from mudra.store import PortfolioStore
from mudra.tiers import is_core


def export_api_payload(
    store: PortfolioStore,
    files: list[str] | None = None,
    output: Path | None = None,
) -> str:
    """Export portfolio as a JSON API payload.

    Produces a JSON object containing mudra version, export timestamp,
    and file contents keyed by name with their tier classification.

    Returns the JSON string. If output path is provided, also writes to file.
    """
    resolved = resolve_files(store, files)
    file_entries: dict[str, dict[str, str]] = {}

    for name in resolved:
        content = store.read_file(name)
        stripped = strip_frontmatter(content)
        tier = "core" if is_core(name) else "extended"
        file_entries[name] = {
            "content": stripped,
            "tier": tier,
        }

    payload: dict[str, object] = {
        "mudra_version": __version__,
        "exported_at": datetime.now(tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "files": file_entries,
    }

    result = json.dumps(payload, indent=2)

    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(result, encoding="utf-8")

    return result
