from __future__ import annotations

from pathlib import Path

from mudra.export._helpers import file_name_to_title, resolve_files, strip_frontmatter
from mudra.store import PortfolioStore


def export_system_prompt(
    store: PortfolioStore,
    files: list[str] | None = None,
    output: Path | None = None,
) -> str:
    """Export portfolio as a system prompt block wrapped in <user_context> tags.

    Each portfolio file becomes a section with a ## header derived from the file name.
    YAML frontmatter is stripped from each file's content.

    If output path is provided, the content is written to that file.
    Returns the formatted content string.
    """
    resolved = resolve_files(store, files)
    sections: list[str] = []

    for name in resolved:
        content = store.read_file(name)
        stripped = strip_frontmatter(content)
        title = file_name_to_title(name)
        sections.append(f"## {title}\n{stripped}")

    inner = "\n\n".join(sections)
    if sections:
        result = f"<user_context>\n{inner}\n</user_context>"
    else:
        result = "<user_context>\n</user_context>"

    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(result, encoding="utf-8")

    return result
