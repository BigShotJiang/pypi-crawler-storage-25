from __future__ import annotations

import re

from mudra.store import PortfolioStore


def strip_frontmatter(content: str) -> str:
    """Remove YAML frontmatter (between --- markers) from markdown content."""
    pattern = r"\A---\s*\n.*?\n---\s*\n?"
    result = re.sub(pattern, "", content, count=1, flags=re.DOTALL)
    return result.strip()


def file_name_to_title(name: str) -> str:
    """Convert kebab-case file name to title case.

    Example: 'tools-and-systems' -> 'Tools and Systems'
    """
    return " ".join(word.capitalize() for word in name.split("-"))


def resolve_files(store: PortfolioStore, files: list[str] | None) -> list[str]:
    """Resolve file list: if None, return all existing files. Otherwise filter to existing."""
    if files is None:
        return store.list_files()
    return [f for f in files if store.file_exists(f)]
