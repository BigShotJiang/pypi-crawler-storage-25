from __future__ import annotations

from pathlib import Path

from mudra.export._helpers import file_name_to_title, resolve_files, strip_frontmatter
from mudra.store import PortfolioStore


def export_markdown(
    store: PortfolioStore,
    files: list[str] | None = None,
    output: Path | None = None,
) -> str:
    """Export portfolio as a single concatenated markdown document.

    Each portfolio file becomes a ## section under a top-level # Mudra Portfolio
    heading. Sections are separated by horizontal rules. YAML frontmatter is stripped.

    Returns the markdown string. If output path is provided, also writes to file.
    """
    resolved = resolve_files(store, files)
    sections: list[str] = []

    for name in resolved:
        content = store.read_file(name)
        stripped = strip_frontmatter(content)
        title = file_name_to_title(name)
        sections.append(f"## {title}\n{stripped}")

    body = "\n\n---\n\n".join(sections)
    result = f"# Mudra Portfolio\n\n{body}" if sections else "# Mudra Portfolio"

    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(result, encoding="utf-8")

    return result
