from __future__ import annotations

from pathlib import Path

from mudra.export._helpers import resolve_files, strip_frontmatter
from mudra.store import PortfolioStore
from mudra.tiers import get_file_extension


def export_claude_project(
    store: PortfolioStore,
    files: list[str] | None = None,
    output: Path | None = None,
) -> str:
    """Export portfolio as a Claude Projects bundle -- one file per portfolio file.

    Creates a directory at the output path with individual .md files,
    each containing the portfolio file content with frontmatter stripped.

    Output must be a directory path. If None, defaults to ./mudra-export.
    Returns a summary string listing exported files.
    """
    resolved = resolve_files(store, files)
    target_dir = output if output is not None else Path.cwd() / "mudra-export"
    target_dir.mkdir(parents=True, exist_ok=True)

    exported: list[str] = []
    for name in resolved:
        content = store.read_file(name)
        stripped = strip_frontmatter(content)
        ext = get_file_extension(name)
        dest = target_dir / f"{name}{ext}"
        dest.write_text(stripped, encoding="utf-8")
        exported.append(f"{name}{ext}")

    if not exported:
        return f"No files exported to {target_dir}"

    file_list = "\n".join(f"  - {f}" for f in exported)
    return f"Exported {len(exported)} files to {target_dir}:\n{file_list}"
