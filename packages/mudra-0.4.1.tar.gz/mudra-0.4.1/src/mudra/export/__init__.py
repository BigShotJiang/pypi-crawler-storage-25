from __future__ import annotations

from collections.abc import Callable

from mudra.export.api_payload import export_api_payload
from mudra.export.claude_project import export_claude_project
from mudra.export.markdown import export_markdown
from mudra.export.system_prompt import export_system_prompt

EXPORT_FORMATS: dict[str, Callable[..., str]] = {
    "system-prompt": export_system_prompt,
    "claude-project": export_claude_project,
    "api-payload": export_api_payload,
    "markdown": export_markdown,
}

__all__ = [
    "EXPORT_FORMATS",
    "export_api_payload",
    "export_claude_project",
    "export_markdown",
    "export_system_prompt",
]
