---
dimension: role-and-responsibilities
tier: extended
version: 1
---

<!-- Mudra: Role and Responsibilities
Describe your current role in detail. What are you accountable for?
What decisions do you own? What is your scope of authority?
Include reporting structure and key stakeholders if relevant.
Delete these comments when done. -->
