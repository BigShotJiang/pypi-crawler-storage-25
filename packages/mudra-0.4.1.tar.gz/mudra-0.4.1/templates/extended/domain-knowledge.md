---
dimension: domain-knowledge
tier: extended
version: 1
---

<!-- Mudra: Domain Knowledge
Capture the specialized knowledge you bring to your work.
Include: technical domains you're expert in, industry-specific
knowledge, institutional knowledge, architectural patterns you
understand deeply, and areas where you're actively learning.
Delete these comments when done. -->
