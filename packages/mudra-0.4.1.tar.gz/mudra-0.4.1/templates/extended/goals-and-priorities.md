---
dimension: goals-and-priorities
tier: extended
version: 1
---

<!-- Mudra: Goals and Priorities
Document your current professional goals and priorities.
Include: short-term goals (this sprint/month), medium-term goals
(this quarter), and long-term goals (this year and beyond).
Rank by priority. Note any deadlines or milestones.
Delete these comments when done. -->
