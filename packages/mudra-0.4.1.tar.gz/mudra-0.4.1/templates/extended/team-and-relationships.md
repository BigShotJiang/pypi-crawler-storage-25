---
dimension: team-and-relationships
tier: extended
version: 1
---

<!-- Mudra: Team and Relationships
Describe the people you work with regularly.
Include: team members and their roles, collaborators across teams,
key stakeholders, and the nature of each working relationship.
Note communication preferences for key people if relevant.
Delete these comments when done. -->
