---
dimension: tools-and-systems
tier: core
version: 1
---

<!-- Mudra: Tools and Systems
List the tools, languages, frameworks, platforms, and services you use regularly.
Group by category (e.g., Languages, Editors, Cloud, CI/CD, Databases).
Include version preferences or constraints where relevant.
Mention tools you explicitly avoid and why.
Delete these comments when done. -->
