---
dimension: communication-style
tier: core
version: 1
---

<!-- Mudra: Communication Style
Describe how you prefer AI agents to communicate with you.
Cover: tone (formal/casual/terse), verbosity (concise/detailed),
formatting preferences (bullets/prose/code-first), what to avoid
(hedging, praise, filler), and how you want errors or bad news delivered.
Delete these comments when done. -->
