---
dimension: identity
tier: core
version: 1
---

<!-- Mudra: Identity
Write a concise summary of who you are professionally.
Include: name, role/title, organization, what you do day-to-day,
what you're known for, and the one thing any AI agent must know about you.
Write in first person. Aim for 2-4 paragraphs of flowing prose.
Delete these comments when done. -->
