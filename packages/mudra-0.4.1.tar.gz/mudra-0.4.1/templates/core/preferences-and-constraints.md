---
dimension: preferences-and-constraints
tier: core
version: 1
---

<!-- Mudra: Preferences and Constraints
Document your non-negotiable technical preferences and constraints.
Cover: coding conventions, architecture patterns you favor or reject,
testing requirements, documentation standards, security practices,
performance expectations, and any organizational mandates.
Delete these comments when done. -->
