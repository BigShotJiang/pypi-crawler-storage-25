# Changelog

All notable changes to Mudra are documented in this file.

## [0.4.1] - 2026-04-05

### Fixes

- Add PyPI metadata: readme, authors, classifiers, and project URLs

## [0.4.0] - 2026-04-05

First public release.

### Features

- **CLI**: Complete command suite — `init`, `edit`, `status`, `export`, `validate`, `interview`, `serve`, `route`
- **Portfolio Store**: Markdown-based portfolio in `~/.mudra/` with automatic git versioning
- **Freshness Tracking**: Staleness detection with configurable thresholds per file
- **Validation**: Portfolio health checks with severity levels (error, warning, info)
- **Multi-format Export**: Export portfolio to JSON, YAML, TOML, and Markdown
- **Context Router**: Role-based selective context routing — agents receive only relevant files
- **Routing Analytics**: Usage tracking and reporting for route patterns
- **MCP Server**: FastMCP resource server for agent integration via Model Context Protocol
- **Interview Engine**: LLM-driven guided interview with protocol-based synthesis
- **Community Templates**: Template framework with 3 built-in role templates
- **Decision Log**: Structured decision tracking within the portfolio

### Infrastructure

- CI pipeline with ruff, mypy strict, and pytest coverage
- GitHub issue and PR templates
- Project documentation with usage guides

[0.4.1]: https://github.com/Mathews-Tom/mudra/releases/tag/v0.4.1
[0.4.0]: https://github.com/Mathews-Tom/mudra/releases/tag/v0.4.0
