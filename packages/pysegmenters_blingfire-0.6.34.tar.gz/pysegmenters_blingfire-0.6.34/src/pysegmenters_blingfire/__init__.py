"""Segmenter based on Spacy"""

__version__ = "0.6.34"
