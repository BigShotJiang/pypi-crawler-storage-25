from __future__ import annotations

from functools import cached_property


RUNCACHE_ORG_SCOPE_PREFIX = "runcache:scope:org"
LEGACY_ORG_SCOPE_PREFIX = "conway:scope:org"
ORG_SCOPE_PREFIXES = (RUNCACHE_ORG_SCOPE_PREFIX, LEGACY_ORG_SCOPE_PREFIX)


class Scope:
    def __init__(self, org_id_to_level: dict[str, str]) -> None:
        self._org_id_to_level: dict[str, str] = org_id_to_level

    @classmethod
    def from_string(cls, scope: str) -> Scope:
        """Create a Scope instance from a scope string.

        Supports both the current ``runcache:`` prefix and the legacy ``conway:`` prefix.

        Args:
            scope: The scope string to parse.

        Returns:
            A Scope instance.
        """
        scopes = scope.split(" ")
        org_scopes = [s for s in scopes if any(s.strip().startswith(p) for p in ORG_SCOPE_PREFIXES)]

        org_id_to_level = {}
        for org_scope in org_scopes:
            scope_parts = org_scope.split(":")
            if len(scope_parts) < 5:
                raise ValueError(f"Invalid scope format: '{scope}'.")
            org_id = scope_parts[3]
            if org_id:
                org_id_to_level[org_id] = scope_parts[4]
        return cls(org_id_to_level=org_id_to_level)

    @property
    def org_id(self) -> str:
        """Extract the organization ID from a given scope string.

        This method raises ValueError if the scope is not associated with exactly one organization ID.

        Returns:
            The extracted organization ID.
        """
        org_ids = self.org_ids
        if not org_ids:
            raise ValueError("No organization scope found.")
        if len(org_ids) > 1:
            raise ValueError(f"Only one organization scope is supported, got multiple: {org_ids}.")
        org_id = org_ids[0]
        if org_id == "*":
            raise ValueError(f"Wildcard organization ID is not allowed.")
        return org_id

    @cached_property
    def org_ids(self) -> list[str]:
        """Returns all organization IDs from the scope, including wildcards."""
        return list(self._org_id_to_level)

    def is_org_id_in_scope(self, org_id: str) -> bool:
        """Check if the given organization ID is included in the scope.

        Args:
            org_id: The organization ID to check.

        Returns:
            True if the org_id is in the scope or if a wildcard "*" is present; False otherwise.
        """
        return org_id in self._org_id_to_level or "*" in self._org_id_to_level
