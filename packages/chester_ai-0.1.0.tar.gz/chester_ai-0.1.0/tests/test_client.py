import pytest
from chester_ai import ChesterClient


def test_create_client():
    client = ChesterClient(url="localhost:8990", api_key="cht_test123")
    assert client is not None
    assert client.agents is not None
    assert client.queue is not None
    assert client.events is not None


def test_all_27_services():
    client = ChesterClient(url="localhost:8990", api_key="cht_test123")
    services = [
        "agents", "queue", "decisions", "cron", "plans", "teams",
        "skills", "mcp", "daemon", "events", "context", "tools",
        "db", "temporal", "auth", "users", "goals", "capabilities",
        "templates", "organizations", "workflow_templates", "guardrails",
        "kanban", "observe", "datasets", "twins", "integrations",
    ]
    for svc in services:
        assert getattr(client, svc) is not None, f"Missing service: {svc}"
    assert len(services) == 27


def test_missing_url():
    with pytest.raises(ValueError, match="url"):
        ChesterClient(url="", api_key="cht_test")


def test_missing_api_key():
    with pytest.raises(ValueError, match="api_key"):
        ChesterClient(url="localhost:8990", api_key="")


def test_context_manager():
    with ChesterClient(url="localhost:8990", api_key="cht_test") as client:
        assert client.agents is not None
