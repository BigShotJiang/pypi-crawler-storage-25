"""Service wrapper that injects auth metadata on every call."""
from __future__ import annotations
from typing import Any


class ServiceWrapper:
    """Wraps a gRPC stub to automatically inject metadata on every call."""

    def __init__(self, stub: Any, metadata: list[tuple[str, str]]) -> None:
        self._stub = stub
        self._metadata = metadata

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._stub, name)
        if not callable(attr):
            return attr

        def wrapper(*args: Any, **kwargs: Any) -> Any:
            existing = list(kwargs.get("metadata", []))
            kwargs["metadata"] = existing + self._metadata
            return attr(*args, **kwargs)

        return wrapper
