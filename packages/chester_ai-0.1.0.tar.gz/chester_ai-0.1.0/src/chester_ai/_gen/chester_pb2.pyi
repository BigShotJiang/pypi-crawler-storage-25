from google.api import annotations_pb2 as _annotations_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ListAgentsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListAgentsResponse(_message.Message):
    __slots__ = ("agents",)
    AGENTS_FIELD_NUMBER: _ClassVar[int]
    agents: _containers.RepeatedCompositeFieldContainer[AgentSummary]
    def __init__(self, agents: _Optional[_Iterable[_Union[AgentSummary, _Mapping]]] = ...) -> None: ...

class AgentSummary(_message.Message):
    __slots__ = ("name", "emoji", "identity", "default_model", "has_telegram", "has_webhook", "has_email", "queue_size", "category", "has_slack", "temporal_orchestrator", "uuid")
    NAME_FIELD_NUMBER: _ClassVar[int]
    EMOJI_FIELD_NUMBER: _ClassVar[int]
    IDENTITY_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_MODEL_FIELD_NUMBER: _ClassVar[int]
    HAS_TELEGRAM_FIELD_NUMBER: _ClassVar[int]
    HAS_WEBHOOK_FIELD_NUMBER: _ClassVar[int]
    HAS_EMAIL_FIELD_NUMBER: _ClassVar[int]
    QUEUE_SIZE_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    HAS_SLACK_FIELD_NUMBER: _ClassVar[int]
    TEMPORAL_ORCHESTRATOR_FIELD_NUMBER: _ClassVar[int]
    UUID_FIELD_NUMBER: _ClassVar[int]
    name: str
    emoji: str
    identity: str
    default_model: str
    has_telegram: bool
    has_webhook: bool
    has_email: bool
    queue_size: int
    category: str
    has_slack: bool
    temporal_orchestrator: bool
    uuid: str
    def __init__(self, name: _Optional[str] = ..., emoji: _Optional[str] = ..., identity: _Optional[str] = ..., default_model: _Optional[str] = ..., has_telegram: bool = ..., has_webhook: bool = ..., has_email: bool = ..., queue_size: _Optional[int] = ..., category: _Optional[str] = ..., has_slack: bool = ..., temporal_orchestrator: bool = ..., uuid: _Optional[str] = ...) -> None: ...

class CreateAgentRequest(_message.Message):
    __slots__ = ("name", "identity", "model", "emoji")
    NAME_FIELD_NUMBER: _ClassVar[int]
    IDENTITY_FIELD_NUMBER: _ClassVar[int]
    MODEL_FIELD_NUMBER: _ClassVar[int]
    EMOJI_FIELD_NUMBER: _ClassVar[int]
    name: str
    identity: str
    model: str
    emoji: str
    def __init__(self, name: _Optional[str] = ..., identity: _Optional[str] = ..., model: _Optional[str] = ..., emoji: _Optional[str] = ...) -> None: ...

class CreateAgentResponse(_message.Message):
    __slots__ = ("success", "message", "agent_id")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    agent_id: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class RemoveAgentRequest(_message.Message):
    __slots__ = ("name", "agent_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    agent_id: str
    def __init__(self, name: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class RemoveAgentResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GetConfigRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class AgentConfigResponse(_message.Message):
    __slots__ = ("name", "emoji", "identity", "system_text", "default_model", "default_provider", "allowed_models", "max_iterations", "context_window", "task_timeout", "timezone", "runtime_discovery", "shell_denylist", "telegram_enabled", "telegram_user_id", "telegram_allowed_user_ids", "webhook_enabled", "webhook_port", "webhook_secret", "email_enabled", "email_address", "email_imap_host", "email_imap_port", "email_allowed_senders", "email_poll_interval_secs", "email_mark_as_read", "skills", "allowed_tools", "category", "fallback_chain", "slack_enabled", "slack_bot_token_masked", "slack_app_token_masked", "slack_allowed_user_ids", "slack_allowed_channel_ids", "temporal_orchestrator", "agent_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    EMOJI_FIELD_NUMBER: _ClassVar[int]
    IDENTITY_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_TEXT_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_MODEL_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_PROVIDER_FIELD_NUMBER: _ClassVar[int]
    ALLOWED_MODELS_FIELD_NUMBER: _ClassVar[int]
    MAX_ITERATIONS_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_WINDOW_FIELD_NUMBER: _ClassVar[int]
    TASK_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_DISCOVERY_FIELD_NUMBER: _ClassVar[int]
    SHELL_DENYLIST_FIELD_NUMBER: _ClassVar[int]
    TELEGRAM_ENABLED_FIELD_NUMBER: _ClassVar[int]
    TELEGRAM_USER_ID_FIELD_NUMBER: _ClassVar[int]
    TELEGRAM_ALLOWED_USER_IDS_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_ENABLED_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_PORT_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_SECRET_FIELD_NUMBER: _ClassVar[int]
    EMAIL_ENABLED_FIELD_NUMBER: _ClassVar[int]
    EMAIL_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    EMAIL_IMAP_HOST_FIELD_NUMBER: _ClassVar[int]
    EMAIL_IMAP_PORT_FIELD_NUMBER: _ClassVar[int]
    EMAIL_ALLOWED_SENDERS_FIELD_NUMBER: _ClassVar[int]
    EMAIL_POLL_INTERVAL_SECS_FIELD_NUMBER: _ClassVar[int]
    EMAIL_MARK_AS_READ_FIELD_NUMBER: _ClassVar[int]
    SKILLS_FIELD_NUMBER: _ClassVar[int]
    ALLOWED_TOOLS_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    FALLBACK_CHAIN_FIELD_NUMBER: _ClassVar[int]
    SLACK_ENABLED_FIELD_NUMBER: _ClassVar[int]
    SLACK_BOT_TOKEN_MASKED_FIELD_NUMBER: _ClassVar[int]
    SLACK_APP_TOKEN_MASKED_FIELD_NUMBER: _ClassVar[int]
    SLACK_ALLOWED_USER_IDS_FIELD_NUMBER: _ClassVar[int]
    SLACK_ALLOWED_CHANNEL_IDS_FIELD_NUMBER: _ClassVar[int]
    TEMPORAL_ORCHESTRATOR_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    emoji: str
    identity: str
    system_text: str
    default_model: str
    default_provider: str
    allowed_models: _containers.RepeatedScalarFieldContainer[str]
    max_iterations: int
    context_window: int
    task_timeout: int
    timezone: str
    runtime_discovery: bool
    shell_denylist: _containers.RepeatedScalarFieldContainer[str]
    telegram_enabled: bool
    telegram_user_id: int
    telegram_allowed_user_ids: _containers.RepeatedScalarFieldContainer[int]
    webhook_enabled: bool
    webhook_port: int
    webhook_secret: str
    email_enabled: bool
    email_address: str
    email_imap_host: str
    email_imap_port: int
    email_allowed_senders: _containers.RepeatedScalarFieldContainer[str]
    email_poll_interval_secs: int
    email_mark_as_read: bool
    skills: _containers.RepeatedScalarFieldContainer[str]
    allowed_tools: _containers.RepeatedScalarFieldContainer[str]
    category: str
    fallback_chain: _containers.RepeatedScalarFieldContainer[str]
    slack_enabled: bool
    slack_bot_token_masked: str
    slack_app_token_masked: str
    slack_allowed_user_ids: _containers.RepeatedScalarFieldContainer[str]
    slack_allowed_channel_ids: _containers.RepeatedScalarFieldContainer[str]
    temporal_orchestrator: bool
    agent_id: str
    def __init__(self, name: _Optional[str] = ..., emoji: _Optional[str] = ..., identity: _Optional[str] = ..., system_text: _Optional[str] = ..., default_model: _Optional[str] = ..., default_provider: _Optional[str] = ..., allowed_models: _Optional[_Iterable[str]] = ..., max_iterations: _Optional[int] = ..., context_window: _Optional[int] = ..., task_timeout: _Optional[int] = ..., timezone: _Optional[str] = ..., runtime_discovery: bool = ..., shell_denylist: _Optional[_Iterable[str]] = ..., telegram_enabled: bool = ..., telegram_user_id: _Optional[int] = ..., telegram_allowed_user_ids: _Optional[_Iterable[int]] = ..., webhook_enabled: bool = ..., webhook_port: _Optional[int] = ..., webhook_secret: _Optional[str] = ..., email_enabled: bool = ..., email_address: _Optional[str] = ..., email_imap_host: _Optional[str] = ..., email_imap_port: _Optional[int] = ..., email_allowed_senders: _Optional[_Iterable[str]] = ..., email_poll_interval_secs: _Optional[int] = ..., email_mark_as_read: bool = ..., skills: _Optional[_Iterable[str]] = ..., allowed_tools: _Optional[_Iterable[str]] = ..., category: _Optional[str] = ..., fallback_chain: _Optional[_Iterable[str]] = ..., slack_enabled: bool = ..., slack_bot_token_masked: _Optional[str] = ..., slack_app_token_masked: _Optional[str] = ..., slack_allowed_user_ids: _Optional[_Iterable[str]] = ..., slack_allowed_channel_ids: _Optional[_Iterable[str]] = ..., temporal_orchestrator: bool = ..., agent_id: _Optional[str] = ...) -> None: ...

class SetConfigRequest(_message.Message):
    __slots__ = ("agent", "emoji", "identity", "system_text", "default_model", "default_provider", "add_model", "remove_model", "telegram_bot_token", "telegram_user_id", "remove_telegram", "timezone", "task_timeout", "max_iterations", "context_window", "runtime_discovery", "add_denylist", "remove_denylist", "webhook_port", "webhook_secret", "remove_webhook", "add_skill", "remove_skill", "set_allowed_tools", "add_allowed_tool", "remove_allowed_tool", "clear_allowed_tools", "category", "set_fallback_chain", "add_fallback_model", "remove_fallback_model", "clear_fallback_chain", "add_telegram_user_id", "remove_telegram_user_id", "slack_bot_token", "slack_app_token", "remove_slack", "add_slack_allowed_user_id", "remove_slack_allowed_user_id", "add_slack_allowed_channel_id", "remove_slack_allowed_channel_id", "temporal_orchestrator", "agent_id", "rename", "email_enabled", "email_imap_host", "email_imap_port", "email_address", "email_oauth_client_id", "email_oauth_client_secret", "email_oauth_refresh_token", "email_add_allowed_sender", "email_remove_allowed_sender", "email_poll_interval_secs", "email_mark_as_read", "remove_email")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    EMOJI_FIELD_NUMBER: _ClassVar[int]
    IDENTITY_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_TEXT_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_MODEL_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_PROVIDER_FIELD_NUMBER: _ClassVar[int]
    ADD_MODEL_FIELD_NUMBER: _ClassVar[int]
    REMOVE_MODEL_FIELD_NUMBER: _ClassVar[int]
    TELEGRAM_BOT_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TELEGRAM_USER_ID_FIELD_NUMBER: _ClassVar[int]
    REMOVE_TELEGRAM_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    TASK_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    MAX_ITERATIONS_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_WINDOW_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_DISCOVERY_FIELD_NUMBER: _ClassVar[int]
    ADD_DENYLIST_FIELD_NUMBER: _ClassVar[int]
    REMOVE_DENYLIST_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_PORT_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_SECRET_FIELD_NUMBER: _ClassVar[int]
    REMOVE_WEBHOOK_FIELD_NUMBER: _ClassVar[int]
    ADD_SKILL_FIELD_NUMBER: _ClassVar[int]
    REMOVE_SKILL_FIELD_NUMBER: _ClassVar[int]
    SET_ALLOWED_TOOLS_FIELD_NUMBER: _ClassVar[int]
    ADD_ALLOWED_TOOL_FIELD_NUMBER: _ClassVar[int]
    REMOVE_ALLOWED_TOOL_FIELD_NUMBER: _ClassVar[int]
    CLEAR_ALLOWED_TOOLS_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    SET_FALLBACK_CHAIN_FIELD_NUMBER: _ClassVar[int]
    ADD_FALLBACK_MODEL_FIELD_NUMBER: _ClassVar[int]
    REMOVE_FALLBACK_MODEL_FIELD_NUMBER: _ClassVar[int]
    CLEAR_FALLBACK_CHAIN_FIELD_NUMBER: _ClassVar[int]
    ADD_TELEGRAM_USER_ID_FIELD_NUMBER: _ClassVar[int]
    REMOVE_TELEGRAM_USER_ID_FIELD_NUMBER: _ClassVar[int]
    SLACK_BOT_TOKEN_FIELD_NUMBER: _ClassVar[int]
    SLACK_APP_TOKEN_FIELD_NUMBER: _ClassVar[int]
    REMOVE_SLACK_FIELD_NUMBER: _ClassVar[int]
    ADD_SLACK_ALLOWED_USER_ID_FIELD_NUMBER: _ClassVar[int]
    REMOVE_SLACK_ALLOWED_USER_ID_FIELD_NUMBER: _ClassVar[int]
    ADD_SLACK_ALLOWED_CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    REMOVE_SLACK_ALLOWED_CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPORAL_ORCHESTRATOR_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    RENAME_FIELD_NUMBER: _ClassVar[int]
    EMAIL_ENABLED_FIELD_NUMBER: _ClassVar[int]
    EMAIL_IMAP_HOST_FIELD_NUMBER: _ClassVar[int]
    EMAIL_IMAP_PORT_FIELD_NUMBER: _ClassVar[int]
    EMAIL_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    EMAIL_OAUTH_CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    EMAIL_OAUTH_CLIENT_SECRET_FIELD_NUMBER: _ClassVar[int]
    EMAIL_OAUTH_REFRESH_TOKEN_FIELD_NUMBER: _ClassVar[int]
    EMAIL_ADD_ALLOWED_SENDER_FIELD_NUMBER: _ClassVar[int]
    EMAIL_REMOVE_ALLOWED_SENDER_FIELD_NUMBER: _ClassVar[int]
    EMAIL_POLL_INTERVAL_SECS_FIELD_NUMBER: _ClassVar[int]
    EMAIL_MARK_AS_READ_FIELD_NUMBER: _ClassVar[int]
    REMOVE_EMAIL_FIELD_NUMBER: _ClassVar[int]
    agent: str
    emoji: str
    identity: str
    system_text: str
    default_model: str
    default_provider: str
    add_model: str
    remove_model: str
    telegram_bot_token: str
    telegram_user_id: int
    remove_telegram: bool
    timezone: str
    task_timeout: int
    max_iterations: int
    context_window: int
    runtime_discovery: bool
    add_denylist: str
    remove_denylist: str
    webhook_port: int
    webhook_secret: str
    remove_webhook: bool
    add_skill: str
    remove_skill: str
    set_allowed_tools: _containers.RepeatedScalarFieldContainer[str]
    add_allowed_tool: str
    remove_allowed_tool: str
    clear_allowed_tools: bool
    category: str
    set_fallback_chain: _containers.RepeatedScalarFieldContainer[str]
    add_fallback_model: str
    remove_fallback_model: str
    clear_fallback_chain: bool
    add_telegram_user_id: int
    remove_telegram_user_id: int
    slack_bot_token: str
    slack_app_token: str
    remove_slack: bool
    add_slack_allowed_user_id: str
    remove_slack_allowed_user_id: str
    add_slack_allowed_channel_id: str
    remove_slack_allowed_channel_id: str
    temporal_orchestrator: bool
    agent_id: str
    rename: str
    email_enabled: bool
    email_imap_host: str
    email_imap_port: int
    email_address: str
    email_oauth_client_id: str
    email_oauth_client_secret: str
    email_oauth_refresh_token: str
    email_add_allowed_sender: str
    email_remove_allowed_sender: str
    email_poll_interval_secs: int
    email_mark_as_read: bool
    remove_email: bool
    def __init__(self, agent: _Optional[str] = ..., emoji: _Optional[str] = ..., identity: _Optional[str] = ..., system_text: _Optional[str] = ..., default_model: _Optional[str] = ..., default_provider: _Optional[str] = ..., add_model: _Optional[str] = ..., remove_model: _Optional[str] = ..., telegram_bot_token: _Optional[str] = ..., telegram_user_id: _Optional[int] = ..., remove_telegram: bool = ..., timezone: _Optional[str] = ..., task_timeout: _Optional[int] = ..., max_iterations: _Optional[int] = ..., context_window: _Optional[int] = ..., runtime_discovery: bool = ..., add_denylist: _Optional[str] = ..., remove_denylist: _Optional[str] = ..., webhook_port: _Optional[int] = ..., webhook_secret: _Optional[str] = ..., remove_webhook: bool = ..., add_skill: _Optional[str] = ..., remove_skill: _Optional[str] = ..., set_allowed_tools: _Optional[_Iterable[str]] = ..., add_allowed_tool: _Optional[str] = ..., remove_allowed_tool: _Optional[str] = ..., clear_allowed_tools: bool = ..., category: _Optional[str] = ..., set_fallback_chain: _Optional[_Iterable[str]] = ..., add_fallback_model: _Optional[str] = ..., remove_fallback_model: _Optional[str] = ..., clear_fallback_chain: bool = ..., add_telegram_user_id: _Optional[int] = ..., remove_telegram_user_id: _Optional[int] = ..., slack_bot_token: _Optional[str] = ..., slack_app_token: _Optional[str] = ..., remove_slack: bool = ..., add_slack_allowed_user_id: _Optional[str] = ..., remove_slack_allowed_user_id: _Optional[str] = ..., add_slack_allowed_channel_id: _Optional[str] = ..., remove_slack_allowed_channel_id: _Optional[str] = ..., temporal_orchestrator: bool = ..., agent_id: _Optional[str] = ..., rename: _Optional[str] = ..., email_enabled: bool = ..., email_imap_host: _Optional[str] = ..., email_imap_port: _Optional[int] = ..., email_address: _Optional[str] = ..., email_oauth_client_id: _Optional[str] = ..., email_oauth_client_secret: _Optional[str] = ..., email_oauth_refresh_token: _Optional[str] = ..., email_add_allowed_sender: _Optional[str] = ..., email_remove_allowed_sender: _Optional[str] = ..., email_poll_interval_secs: _Optional[int] = ..., email_mark_as_read: bool = ..., remove_email: bool = ...) -> None: ...

class SetConfigResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class TestTelegramRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class TestTelegramResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class TestWebhookRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class TestWebhookResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class TestSlackRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class TestSlackResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class TestEmailRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class TestEmailResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class ListToolsRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ListToolsResponse(_message.Message):
    __slots__ = ("tools",)
    TOOLS_FIELD_NUMBER: _ClassVar[int]
    tools: _containers.RepeatedCompositeFieldContainer[ToolInfo]
    def __init__(self, tools: _Optional[_Iterable[_Union[ToolInfo, _Mapping]]] = ...) -> None: ...

class ToolInfo(_message.Message):
    __slots__ = ("name", "description", "source")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    name: str
    description: str
    source: str
    def __init__(self, name: _Optional[str] = ..., description: _Optional[str] = ..., source: _Optional[str] = ...) -> None: ...

class ListAvailableModelsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListAvailableModelsResponse(_message.Message):
    __slots__ = ("models",)
    MODELS_FIELD_NUMBER: _ClassVar[int]
    models: _containers.RepeatedCompositeFieldContainer[AvailableModel]
    def __init__(self, models: _Optional[_Iterable[_Union[AvailableModel, _Mapping]]] = ...) -> None: ...

class AvailableModel(_message.Message):
    __slots__ = ("id", "display_name", "provider", "description")
    ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    id: str
    display_name: str
    provider: str
    description: str
    def __init__(self, id: _Optional[str] = ..., display_name: _Optional[str] = ..., provider: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class SendTaskRequest(_message.Message):
    __slots__ = ("agent", "message", "priority", "session_id", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    message: str
    priority: int
    session_id: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., message: _Optional[str] = ..., priority: _Optional[int] = ..., session_id: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class SendTaskResponse(_message.Message):
    __slots__ = ("task_id",)
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    def __init__(self, task_id: _Optional[str] = ...) -> None: ...

class ListQueueRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ListQueueResponse(_message.Message):
    __slots__ = ("entries",)
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedCompositeFieldContainer[QueueEntry]
    def __init__(self, entries: _Optional[_Iterable[_Union[QueueEntry, _Mapping]]] = ...) -> None: ...

class QueueEntry(_message.Message):
    __slots__ = ("id", "status", "message_preview", "priority", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    status: str
    message_preview: str
    priority: int
    created_at: str
    def __init__(self, id: _Optional[str] = ..., status: _Optional[str] = ..., message_preview: _Optional[str] = ..., priority: _Optional[int] = ..., created_at: _Optional[str] = ...) -> None: ...

class DrainQueueRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class DrainQueueResponse(_message.Message):
    __slots__ = ("drained_count",)
    DRAINED_COUNT_FIELD_NUMBER: _ClassVar[int]
    drained_count: int
    def __init__(self, drained_count: _Optional[int] = ...) -> None: ...

class GetResultRequest(_message.Message):
    __slots__ = ("agent", "agent_id", "task_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    task_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., task_id: _Optional[str] = ...) -> None: ...

class GetResultResponse(_message.Message):
    __slots__ = ("task_id", "status", "result", "completed_at", "tool_calls", "delegations", "retryable", "error_code")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    TOOL_CALLS_FIELD_NUMBER: _ClassVar[int]
    DELEGATIONS_FIELD_NUMBER: _ClassVar[int]
    RETRYABLE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    status: str
    result: str
    completed_at: str
    tool_calls: _containers.RepeatedCompositeFieldContainer[ToolCallSummary]
    delegations: _containers.RepeatedCompositeFieldContainer[DelegationResult]
    retryable: bool
    error_code: str
    def __init__(self, task_id: _Optional[str] = ..., status: _Optional[str] = ..., result: _Optional[str] = ..., completed_at: _Optional[str] = ..., tool_calls: _Optional[_Iterable[_Union[ToolCallSummary, _Mapping]]] = ..., delegations: _Optional[_Iterable[_Union[DelegationResult, _Mapping]]] = ..., retryable: bool = ..., error_code: _Optional[str] = ...) -> None: ...

class ToolCallSummary(_message.Message):
    __slots__ = ("tool_name", "input_preview", "output_preview", "is_error", "tool_id", "duration_ms", "error_code")
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    INPUT_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    IS_ERROR_FIELD_NUMBER: _ClassVar[int]
    TOOL_ID_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    tool_name: str
    input_preview: str
    output_preview: str
    is_error: bool
    tool_id: str
    duration_ms: int
    error_code: str
    def __init__(self, tool_name: _Optional[str] = ..., input_preview: _Optional[str] = ..., output_preview: _Optional[str] = ..., is_error: bool = ..., tool_id: _Optional[str] = ..., duration_ms: _Optional[int] = ..., error_code: _Optional[str] = ...) -> None: ...

class DelegationResult(_message.Message):
    __slots__ = ("agent", "emoji", "role", "request", "output", "is_error", "duration_secs")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    EMOJI_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    IS_ERROR_FIELD_NUMBER: _ClassVar[int]
    DURATION_SECS_FIELD_NUMBER: _ClassVar[int]
    agent: str
    emoji: str
    role: str
    request: str
    output: str
    is_error: bool
    duration_secs: float
    def __init__(self, agent: _Optional[str] = ..., emoji: _Optional[str] = ..., role: _Optional[str] = ..., request: _Optional[str] = ..., output: _Optional[str] = ..., is_error: bool = ..., duration_secs: _Optional[float] = ...) -> None: ...

class ListHistoryRequest(_message.Message):
    __slots__ = ("agent", "agent_id", "limit", "offset")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    limit: int
    offset: int
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class ListHistoryResponse(_message.Message):
    __slots__ = ("entries", "total_count", "has_more")
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedCompositeFieldContainer[HistoryEntry]
    total_count: int
    has_more: bool
    def __init__(self, entries: _Optional[_Iterable[_Union[HistoryEntry, _Mapping]]] = ..., total_count: _Optional[int] = ..., has_more: bool = ...) -> None: ...

class HistoryEntry(_message.Message):
    __slots__ = ("id", "message_preview", "result_preview", "completed_at", "source", "status", "model_used", "input_tokens", "output_tokens", "error", "priority", "created_at", "direction")
    ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    RESULT_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MODEL_USED_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    DIRECTION_FIELD_NUMBER: _ClassVar[int]
    id: str
    message_preview: str
    result_preview: str
    completed_at: str
    source: str
    status: str
    model_used: str
    input_tokens: int
    output_tokens: int
    error: str
    priority: int
    created_at: str
    direction: str
    def __init__(self, id: _Optional[str] = ..., message_preview: _Optional[str] = ..., result_preview: _Optional[str] = ..., completed_at: _Optional[str] = ..., source: _Optional[str] = ..., status: _Optional[str] = ..., model_used: _Optional[str] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., error: _Optional[str] = ..., priority: _Optional[int] = ..., created_at: _Optional[str] = ..., direction: _Optional[str] = ...) -> None: ...

class DeleteHistoryEntryRequest(_message.Message):
    __slots__ = ("agent", "agent_id", "task_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    task_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., task_id: _Optional[str] = ...) -> None: ...

class DeleteHistoryEntryResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class RetryTaskRequest(_message.Message):
    __slots__ = ("agent", "agent_id", "task_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    task_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., task_id: _Optional[str] = ...) -> None: ...

class RetryTaskResponse(_message.Message):
    __slots__ = ("success", "new_task_id", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    NEW_TASK_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    new_task_id: str
    message: str
    def __init__(self, success: bool = ..., new_task_id: _Optional[str] = ..., message: _Optional[str] = ...) -> None: ...

class CancelTaskRequest(_message.Message):
    __slots__ = ("agent", "agent_id", "task_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    task_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., task_id: _Optional[str] = ...) -> None: ...

class CancelTaskResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class ListUniqueSessionsRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ListUniqueSessionsResponse(_message.Message):
    __slots__ = ("sessions",)
    SESSIONS_FIELD_NUMBER: _ClassVar[int]
    sessions: _containers.RepeatedCompositeFieldContainer[ChatSessionSummary]
    def __init__(self, sessions: _Optional[_Iterable[_Union[ChatSessionSummary, _Mapping]]] = ...) -> None: ...

class ChatSessionSummary(_message.Message):
    __slots__ = ("session_key", "latest_message", "latest_response", "latest_time", "message_count", "last_compaction_tier", "approx_tokens_in_context", "latest_context_summary", "agent_id")
    SESSION_KEY_FIELD_NUMBER: _ClassVar[int]
    LATEST_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    LATEST_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    LATEST_TIME_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    LAST_COMPACTION_TIER_FIELD_NUMBER: _ClassVar[int]
    APPROX_TOKENS_IN_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    LATEST_CONTEXT_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    session_key: str
    latest_message: str
    latest_response: str
    latest_time: str
    message_count: int
    last_compaction_tier: int
    approx_tokens_in_context: int
    latest_context_summary: str
    agent_id: str
    def __init__(self, session_key: _Optional[str] = ..., latest_message: _Optional[str] = ..., latest_response: _Optional[str] = ..., latest_time: _Optional[str] = ..., message_count: _Optional[int] = ..., last_compaction_tier: _Optional[int] = ..., approx_tokens_in_context: _Optional[int] = ..., latest_context_summary: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class DeleteSessionByKeyRequest(_message.Message):
    __slots__ = ("agent", "agent_id", "session_key")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_KEY_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    session_key: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., session_key: _Optional[str] = ...) -> None: ...

class DeleteSessionByKeyResponse(_message.Message):
    __slots__ = ("success", "deleted_count")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    DELETED_COUNT_FIELD_NUMBER: _ClassVar[int]
    success: bool
    deleted_count: int
    def __init__(self, success: bool = ..., deleted_count: _Optional[int] = ...) -> None: ...

class PurgeAllHistoryRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class PurgeAllHistoryResponse(_message.Message):
    __slots__ = ("success", "deleted_count")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    DELETED_COUNT_FIELD_NUMBER: _ClassVar[int]
    success: bool
    deleted_count: int
    def __init__(self, success: bool = ..., deleted_count: _Optional[int] = ...) -> None: ...

class PendingDecision(_message.Message):
    __slots__ = ("id", "session_id", "agent", "agent_id", "question", "question_type", "options", "context", "tags", "session", "asked_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    QUESTION_FIELD_NUMBER: _ClassVar[int]
    QUESTION_TYPE_FIELD_NUMBER: _ClassVar[int]
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    SESSION_FIELD_NUMBER: _ClassVar[int]
    ASKED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    session_id: str
    agent: str
    agent_id: str
    question: str
    question_type: str
    options: _containers.RepeatedScalarFieldContainer[str]
    context: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    session: str
    asked_at: str
    def __init__(self, id: _Optional[str] = ..., session_id: _Optional[str] = ..., agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., question: _Optional[str] = ..., question_type: _Optional[str] = ..., options: _Optional[_Iterable[str]] = ..., context: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., session: _Optional[str] = ..., asked_at: _Optional[str] = ...) -> None: ...

class ListPendingRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListPendingResponse(_message.Message):
    __slots__ = ("pending",)
    PENDING_FIELD_NUMBER: _ClassVar[int]
    pending: _containers.RepeatedCompositeFieldContainer[PendingDecision]
    def __init__(self, pending: _Optional[_Iterable[_Union[PendingDecision, _Mapping]]] = ...) -> None: ...

class GetPendingRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class PendingDecisionResponse(_message.Message):
    __slots__ = ("has_pending", "pending")
    HAS_PENDING_FIELD_NUMBER: _ClassVar[int]
    PENDING_FIELD_NUMBER: _ClassVar[int]
    has_pending: bool
    pending: PendingDecision
    def __init__(self, has_pending: bool = ..., pending: _Optional[_Union[PendingDecision, _Mapping]] = ...) -> None: ...

class AnswerDecisionRequest(_message.Message):
    __slots__ = ("agent", "answer", "decision_id", "session", "session_id", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    ANSWER_FIELD_NUMBER: _ClassVar[int]
    DECISION_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    answer: str
    decision_id: str
    session: str
    session_id: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., answer: _Optional[str] = ..., decision_id: _Optional[str] = ..., session: _Optional[str] = ..., session_id: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class AnswerDecisionResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class ListSessionsRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ListSessionsResponse(_message.Message):
    __slots__ = ("sessions",)
    SESSIONS_FIELD_NUMBER: _ClassVar[int]
    sessions: _containers.RepeatedCompositeFieldContainer[SessionSummary]
    def __init__(self, sessions: _Optional[_Iterable[_Union[SessionSummary, _Mapping]]] = ...) -> None: ...

class SessionSummary(_message.Message):
    __slots__ = ("session", "agent", "question", "answer", "answered_at")
    SESSION_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    QUESTION_FIELD_NUMBER: _ClassVar[int]
    ANSWER_FIELD_NUMBER: _ClassVar[int]
    ANSWERED_AT_FIELD_NUMBER: _ClassVar[int]
    session: str
    agent: str
    question: str
    answer: str
    answered_at: str
    def __init__(self, session: _Optional[str] = ..., agent: _Optional[str] = ..., question: _Optional[str] = ..., answer: _Optional[str] = ..., answered_at: _Optional[str] = ...) -> None: ...

class GetSessionRequest(_message.Message):
    __slots__ = ("agent", "session", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    SESSION_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    session: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., session: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class GetSessionResponse(_message.Message):
    __slots__ = ("session", "agent", "question", "question_type", "options", "answer", "answered_at", "tags")
    SESSION_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    QUESTION_FIELD_NUMBER: _ClassVar[int]
    QUESTION_TYPE_FIELD_NUMBER: _ClassVar[int]
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    ANSWER_FIELD_NUMBER: _ClassVar[int]
    ANSWERED_AT_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    session: str
    agent: str
    question: str
    question_type: str
    options: _containers.RepeatedScalarFieldContainer[str]
    answer: str
    answered_at: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, session: _Optional[str] = ..., agent: _Optional[str] = ..., question: _Optional[str] = ..., question_type: _Optional[str] = ..., options: _Optional[_Iterable[str]] = ..., answer: _Optional[str] = ..., answered_at: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class DeleteSessionRequest(_message.Message):
    __slots__ = ("agent", "session", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    SESSION_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    session: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., session: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class DeleteSessionResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class CronJob(_message.Message):
    __slots__ = ("name", "agent", "schedule", "message", "enabled", "priority", "team", "agent_id", "team_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    agent: str
    schedule: str
    message: str
    enabled: bool
    priority: int
    team: str
    agent_id: str
    team_id: str
    def __init__(self, name: _Optional[str] = ..., agent: _Optional[str] = ..., schedule: _Optional[str] = ..., message: _Optional[str] = ..., enabled: bool = ..., priority: _Optional[int] = ..., team: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class ListCronJobsRequest(_message.Message):
    __slots__ = ("agent", "team", "agent_id", "team_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    team: str
    agent_id: str
    team_id: str
    def __init__(self, agent: _Optional[str] = ..., team: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class ListCronJobsResponse(_message.Message):
    __slots__ = ("jobs",)
    JOBS_FIELD_NUMBER: _ClassVar[int]
    jobs: _containers.RepeatedCompositeFieldContainer[CronJob]
    def __init__(self, jobs: _Optional[_Iterable[_Union[CronJob, _Mapping]]] = ...) -> None: ...

class AddCronJobRequest(_message.Message):
    __slots__ = ("agent", "name", "schedule", "message", "priority", "plan_title", "plan_goal", "plan_steps", "team", "agent_id", "team_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    PLAN_TITLE_FIELD_NUMBER: _ClassVar[int]
    PLAN_GOAL_FIELD_NUMBER: _ClassVar[int]
    PLAN_STEPS_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    name: str
    schedule: str
    message: str
    priority: int
    plan_title: str
    plan_goal: str
    plan_steps: _containers.RepeatedScalarFieldContainer[str]
    team: str
    agent_id: str
    team_id: str
    def __init__(self, agent: _Optional[str] = ..., name: _Optional[str] = ..., schedule: _Optional[str] = ..., message: _Optional[str] = ..., priority: _Optional[int] = ..., plan_title: _Optional[str] = ..., plan_goal: _Optional[str] = ..., plan_steps: _Optional[_Iterable[str]] = ..., team: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class AddCronJobResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class RemoveCronJobRequest(_message.Message):
    __slots__ = ("agent", "name", "team", "agent_id", "team_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    name: str
    team: str
    agent_id: str
    team_id: str
    def __init__(self, agent: _Optional[str] = ..., name: _Optional[str] = ..., team: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class RemoveCronJobResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class EnableCronJobRequest(_message.Message):
    __slots__ = ("agent", "name", "team", "agent_id", "team_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    name: str
    team: str
    agent_id: str
    team_id: str
    def __init__(self, agent: _Optional[str] = ..., name: _Optional[str] = ..., team: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class EnableCronJobResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class DisableCronJobRequest(_message.Message):
    __slots__ = ("agent", "name", "team", "agent_id", "team_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    name: str
    team: str
    agent_id: str
    team_id: str
    def __init__(self, agent: _Optional[str] = ..., name: _Optional[str] = ..., team: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class DisableCronJobResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class RunCronJobRequest(_message.Message):
    __slots__ = ("agent", "job_name", "team", "agent_id", "team_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    JOB_NAME_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    job_name: str
    team: str
    agent_id: str
    team_id: str
    def __init__(self, agent: _Optional[str] = ..., job_name: _Optional[str] = ..., team: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class RunCronJobResponse(_message.Message):
    __slots__ = ("task_id", "message")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    message: str
    def __init__(self, task_id: _Optional[str] = ..., message: _Optional[str] = ...) -> None: ...

class GetCronLogsRequest(_message.Message):
    __slots__ = ("agent", "name", "limit", "team", "agent_id", "team_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    name: str
    limit: int
    team: str
    agent_id: str
    team_id: str
    def __init__(self, agent: _Optional[str] = ..., name: _Optional[str] = ..., limit: _Optional[int] = ..., team: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class GetCronLogsResponse(_message.Message):
    __slots__ = ("entries",)
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedCompositeFieldContainer[CronLogEntry]
    def __init__(self, entries: _Optional[_Iterable[_Union[CronLogEntry, _Mapping]]] = ...) -> None: ...

class CronLogEntry(_message.Message):
    __slots__ = ("job_name", "started_at", "completed_at", "status", "result_preview")
    JOB_NAME_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    RESULT_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    job_name: str
    started_at: str
    completed_at: str
    status: str
    result_preview: str
    def __init__(self, job_name: _Optional[str] = ..., started_at: _Optional[str] = ..., completed_at: _Optional[str] = ..., status: _Optional[str] = ..., result_preview: _Optional[str] = ...) -> None: ...

class ListPlansRequest(_message.Message):
    __slots__ = ("agent", "status", "team_name", "limit", "offset", "agent_id", "team_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    status: str
    team_name: str
    limit: int
    offset: int
    agent_id: str
    team_id: str
    def __init__(self, agent: _Optional[str] = ..., status: _Optional[str] = ..., team_name: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class ListPlansForSessionRequest(_message.Message):
    __slots__ = ("session_id", "status", "limit", "offset")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    status: str
    limit: int
    offset: int
    def __init__(self, session_id: _Optional[str] = ..., status: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class ListPlansResponse(_message.Message):
    __slots__ = ("plans", "total_count", "has_more")
    PLANS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    plans: _containers.RepeatedCompositeFieldContainer[PlanSummary]
    total_count: int
    has_more: bool
    def __init__(self, plans: _Optional[_Iterable[_Union[PlanSummary, _Mapping]]] = ..., total_count: _Optional[int] = ..., has_more: bool = ...) -> None: ...

class PlanSummary(_message.Message):
    __slots__ = ("id", "agent", "title", "status", "total_steps", "completed_steps", "created_at", "team_name", "goal", "agent_id", "team_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_STEPS_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_STEPS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    GOAL_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    agent: str
    title: str
    status: str
    total_steps: int
    completed_steps: int
    created_at: str
    team_name: str
    goal: str
    agent_id: str
    team_id: str
    def __init__(self, id: _Optional[str] = ..., agent: _Optional[str] = ..., title: _Optional[str] = ..., status: _Optional[str] = ..., total_steps: _Optional[int] = ..., completed_steps: _Optional[int] = ..., created_at: _Optional[str] = ..., team_name: _Optional[str] = ..., goal: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class GetPlanRequest(_message.Message):
    __slots__ = ("plan_id", "agent", "agent_id", "team_id")
    PLAN_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    plan_id: str
    agent: str
    agent_id: str
    team_id: str
    def __init__(self, plan_id: _Optional[str] = ..., agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class GetPlanResponse(_message.Message):
    __slots__ = ("id", "agent", "title", "goal", "status", "steps", "created_at", "updated_at", "team_name", "agent_id", "team_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    GOAL_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    agent: str
    title: str
    goal: str
    status: str
    steps: _containers.RepeatedCompositeFieldContainer[PlanStep]
    created_at: str
    updated_at: str
    team_name: str
    agent_id: str
    team_id: str
    def __init__(self, id: _Optional[str] = ..., agent: _Optional[str] = ..., title: _Optional[str] = ..., goal: _Optional[str] = ..., status: _Optional[str] = ..., steps: _Optional[_Iterable[_Union[PlanStep, _Mapping]]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., team_name: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class PlanStep(_message.Message):
    __slots__ = ("title", "status", "result", "retries", "assigned_agent", "started_at", "completed_at")
    TITLE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    RETRIES_FIELD_NUMBER: _ClassVar[int]
    ASSIGNED_AGENT_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    title: str
    status: str
    result: str
    retries: int
    assigned_agent: str
    started_at: str
    completed_at: str
    def __init__(self, title: _Optional[str] = ..., status: _Optional[str] = ..., result: _Optional[str] = ..., retries: _Optional[int] = ..., assigned_agent: _Optional[str] = ..., started_at: _Optional[str] = ..., completed_at: _Optional[str] = ...) -> None: ...

class CancelPlanRequest(_message.Message):
    __slots__ = ("plan_id", "agent", "agent_id", "team_id")
    PLAN_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    plan_id: str
    agent: str
    agent_id: str
    team_id: str
    def __init__(self, plan_id: _Optional[str] = ..., agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class CancelPlanResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class UpdatePlanStepRequest(_message.Message):
    __slots__ = ("agent", "plan_id", "step_index", "status", "agent_id", "team_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    PLAN_ID_FIELD_NUMBER: _ClassVar[int]
    STEP_INDEX_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    plan_id: str
    step_index: int
    status: str
    agent_id: str
    team_id: str
    def __init__(self, agent: _Optional[str] = ..., plan_id: _Optional[str] = ..., step_index: _Optional[int] = ..., status: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class UpdatePlanStepResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class DeletePlanRequest(_message.Message):
    __slots__ = ("plan_id", "agent", "agent_id", "team_id")
    PLAN_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    plan_id: str
    agent: str
    agent_id: str
    team_id: str
    def __init__(self, plan_id: _Optional[str] = ..., agent: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class DeletePlanResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class PurgePlansRequest(_message.Message):
    __slots__ = ("team_name", "status", "team_id")
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team_name: str
    status: str
    team_id: str
    def __init__(self, team_name: _Optional[str] = ..., status: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class PurgePlansResponse(_message.Message):
    __slots__ = ("purged_count",)
    PURGED_COUNT_FIELD_NUMBER: _ClassVar[int]
    purged_count: int
    def __init__(self, purged_count: _Optional[int] = ...) -> None: ...

class ListTeamsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListTeamsResponse(_message.Message):
    __slots__ = ("teams",)
    TEAMS_FIELD_NUMBER: _ClassVar[int]
    teams: _containers.RepeatedCompositeFieldContainer[TeamSummary]
    def __init__(self, teams: _Optional[_Iterable[_Union[TeamSummary, _Mapping]]] = ...) -> None: ...

class TeamSummary(_message.Message):
    __slots__ = ("name", "description", "member_count", "team_id", "mode")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    MEMBER_COUNT_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    name: str
    description: str
    member_count: int
    team_id: str
    mode: str
    def __init__(self, name: _Optional[str] = ..., description: _Optional[str] = ..., member_count: _Optional[int] = ..., team_id: _Optional[str] = ..., mode: _Optional[str] = ...) -> None: ...

class GetTeamRequest(_message.Message):
    __slots__ = ("team", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    team_id: str
    def __init__(self, team: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class GetTeamResponse(_message.Message):
    __slots__ = ("name", "description", "members", "coordinator_agent", "agent_order", "mode", "telegram_bot_token", "telegram_allowed_user_ids", "slack_bot_token", "slack_app_token", "slack_allowed_user_ids", "webhook_port", "webhook_secret", "team_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    COORDINATOR_AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ORDER_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    TELEGRAM_BOT_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TELEGRAM_ALLOWED_USER_IDS_FIELD_NUMBER: _ClassVar[int]
    SLACK_BOT_TOKEN_FIELD_NUMBER: _ClassVar[int]
    SLACK_APP_TOKEN_FIELD_NUMBER: _ClassVar[int]
    SLACK_ALLOWED_USER_IDS_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_PORT_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_SECRET_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    description: str
    members: _containers.RepeatedCompositeFieldContainer[TeamMember]
    coordinator_agent: str
    agent_order: _containers.RepeatedScalarFieldContainer[str]
    mode: str
    telegram_bot_token: str
    telegram_allowed_user_ids: _containers.RepeatedScalarFieldContainer[int]
    slack_bot_token: str
    slack_app_token: str
    slack_allowed_user_ids: _containers.RepeatedScalarFieldContainer[str]
    webhook_port: int
    webhook_secret: str
    team_id: str
    def __init__(self, name: _Optional[str] = ..., description: _Optional[str] = ..., members: _Optional[_Iterable[_Union[TeamMember, _Mapping]]] = ..., coordinator_agent: _Optional[str] = ..., agent_order: _Optional[_Iterable[str]] = ..., mode: _Optional[str] = ..., telegram_bot_token: _Optional[str] = ..., telegram_allowed_user_ids: _Optional[_Iterable[int]] = ..., slack_bot_token: _Optional[str] = ..., slack_app_token: _Optional[str] = ..., slack_allowed_user_ids: _Optional[_Iterable[str]] = ..., webhook_port: _Optional[int] = ..., webhook_secret: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class TeamMember(_message.Message):
    __slots__ = ("agent", "role", "description", "emoji")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    EMOJI_FIELD_NUMBER: _ClassVar[int]
    agent: str
    role: str
    description: str
    emoji: str
    def __init__(self, agent: _Optional[str] = ..., role: _Optional[str] = ..., description: _Optional[str] = ..., emoji: _Optional[str] = ...) -> None: ...

class CreateTeamRequest(_message.Message):
    __slots__ = ("name", "description")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    name: str
    description: str
    def __init__(self, name: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class CreateTeamResponse(_message.Message):
    __slots__ = ("success", "team_id")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    success: bool
    team_id: str
    def __init__(self, success: bool = ..., team_id: _Optional[str] = ...) -> None: ...

class RemoveTeamRequest(_message.Message):
    __slots__ = ("team", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    team_id: str
    def __init__(self, team: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class RemoveTeamResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class AddTeamMemberRequest(_message.Message):
    __slots__ = ("team", "agent", "role", "description", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    agent: str
    role: str
    description: str
    team_id: str
    def __init__(self, team: _Optional[str] = ..., agent: _Optional[str] = ..., role: _Optional[str] = ..., description: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class AddTeamMemberResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class RemoveTeamMemberRequest(_message.Message):
    __slots__ = ("team", "agent", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    agent: str
    team_id: str
    def __init__(self, team: _Optional[str] = ..., agent: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class RemoveTeamMemberResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class SetTeamRequest(_message.Message):
    __slots__ = ("team", "description", "coordinator", "agent_order", "clear_agent_order", "telegram_bot_token", "telegram_allowed_user_ids", "slack_bot_token", "slack_app_token", "slack_allowed_user_ids", "webhook_port", "webhook_secret", "clear_integrations", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COORDINATOR_FIELD_NUMBER: _ClassVar[int]
    AGENT_ORDER_FIELD_NUMBER: _ClassVar[int]
    CLEAR_AGENT_ORDER_FIELD_NUMBER: _ClassVar[int]
    TELEGRAM_BOT_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TELEGRAM_ALLOWED_USER_IDS_FIELD_NUMBER: _ClassVar[int]
    SLACK_BOT_TOKEN_FIELD_NUMBER: _ClassVar[int]
    SLACK_APP_TOKEN_FIELD_NUMBER: _ClassVar[int]
    SLACK_ALLOWED_USER_IDS_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_PORT_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_SECRET_FIELD_NUMBER: _ClassVar[int]
    CLEAR_INTEGRATIONS_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    description: str
    coordinator: str
    agent_order: _containers.RepeatedScalarFieldContainer[str]
    clear_agent_order: bool
    telegram_bot_token: str
    telegram_allowed_user_ids: _containers.RepeatedScalarFieldContainer[int]
    slack_bot_token: str
    slack_app_token: str
    slack_allowed_user_ids: _containers.RepeatedScalarFieldContainer[str]
    webhook_port: int
    webhook_secret: str
    clear_integrations: bool
    team_id: str
    def __init__(self, team: _Optional[str] = ..., description: _Optional[str] = ..., coordinator: _Optional[str] = ..., agent_order: _Optional[_Iterable[str]] = ..., clear_agent_order: bool = ..., telegram_bot_token: _Optional[str] = ..., telegram_allowed_user_ids: _Optional[_Iterable[int]] = ..., slack_bot_token: _Optional[str] = ..., slack_app_token: _Optional[str] = ..., slack_allowed_user_ids: _Optional[_Iterable[str]] = ..., webhook_port: _Optional[int] = ..., webhook_secret: _Optional[str] = ..., clear_integrations: bool = ..., team_id: _Optional[str] = ...) -> None: ...

class SetTeamResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GetTeamMemoryRequest(_message.Message):
    __slots__ = ("team", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    team_id: str
    def __init__(self, team: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class GetTeamMemoryResponse(_message.Message):
    __slots__ = ("content",)
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    content: str
    def __init__(self, content: _Optional[str] = ...) -> None: ...

class SetTeamMemoryRequest(_message.Message):
    __slots__ = ("team", "content", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    content: str
    team_id: str
    def __init__(self, team: _Optional[str] = ..., content: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class SetTeamMemoryResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class RunTeamRequest(_message.Message):
    __slots__ = ("team", "message", "priority", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    message: str
    priority: int
    team_id: str
    def __init__(self, team: _Optional[str] = ..., message: _Optional[str] = ..., priority: _Optional[int] = ..., team_id: _Optional[str] = ...) -> None: ...

class RunTeamResponse(_message.Message):
    __slots__ = ("success", "message", "task_ids", "run_id")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    TASK_IDS_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    task_ids: _containers.RepeatedScalarFieldContainer[str]
    run_id: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ..., task_ids: _Optional[_Iterable[str]] = ..., run_id: _Optional[str] = ...) -> None: ...

class TeamRunEntry(_message.Message):
    __slots__ = ("run_id", "team", "mode", "task_message", "status", "started_at", "completed_at", "agent_results", "delegations", "coordinator_output", "team_id")
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    TASK_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    AGENT_RESULTS_FIELD_NUMBER: _ClassVar[int]
    DELEGATIONS_FIELD_NUMBER: _ClassVar[int]
    COORDINATOR_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    team: str
    mode: str
    task_message: str
    status: str
    started_at: str
    completed_at: str
    agent_results: _containers.RepeatedCompositeFieldContainer[TeamRunAgentResult]
    delegations: _containers.RepeatedCompositeFieldContainer[DelegationResult]
    coordinator_output: str
    team_id: str
    def __init__(self, run_id: _Optional[str] = ..., team: _Optional[str] = ..., mode: _Optional[str] = ..., task_message: _Optional[str] = ..., status: _Optional[str] = ..., started_at: _Optional[str] = ..., completed_at: _Optional[str] = ..., agent_results: _Optional[_Iterable[_Union[TeamRunAgentResult, _Mapping]]] = ..., delegations: _Optional[_Iterable[_Union[DelegationResult, _Mapping]]] = ..., coordinator_output: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class TeamRunAgentResult(_message.Message):
    __slots__ = ("agent", "emoji", "role", "task_id", "status", "output", "error", "duration_secs")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    EMOJI_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    DURATION_SECS_FIELD_NUMBER: _ClassVar[int]
    agent: str
    emoji: str
    role: str
    task_id: str
    status: str
    output: str
    error: str
    duration_secs: float
    def __init__(self, agent: _Optional[str] = ..., emoji: _Optional[str] = ..., role: _Optional[str] = ..., task_id: _Optional[str] = ..., status: _Optional[str] = ..., output: _Optional[str] = ..., error: _Optional[str] = ..., duration_secs: _Optional[float] = ...) -> None: ...

class ListTeamRunsRequest(_message.Message):
    __slots__ = ("team", "limit", "offset", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    limit: int
    offset: int
    team_id: str
    def __init__(self, team: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., team_id: _Optional[str] = ...) -> None: ...

class ListTeamRunsResponse(_message.Message):
    __slots__ = ("runs", "total_count", "has_more")
    RUNS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    runs: _containers.RepeatedCompositeFieldContainer[TeamRunEntry]
    total_count: int
    has_more: bool
    def __init__(self, runs: _Optional[_Iterable[_Union[TeamRunEntry, _Mapping]]] = ..., total_count: _Optional[int] = ..., has_more: bool = ...) -> None: ...

class GetTeamRunRequest(_message.Message):
    __slots__ = ("team", "run_id", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    run_id: str
    team_id: str
    def __init__(self, team: _Optional[str] = ..., run_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class GetTeamRunResponse(_message.Message):
    __slots__ = ("run",)
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: TeamRunEntry
    def __init__(self, run: _Optional[_Union[TeamRunEntry, _Mapping]] = ...) -> None: ...

class DeleteTeamRunRequest(_message.Message):
    __slots__ = ("team", "run_id", "team_id")
    TEAM_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    team: str
    run_id: str
    team_id: str
    def __init__(self, team: _Optional[str] = ..., run_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class DeleteTeamRunResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ListSkillsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListSkillsResponse(_message.Message):
    __slots__ = ("skills",)
    SKILLS_FIELD_NUMBER: _ClassVar[int]
    skills: _containers.RepeatedCompositeFieldContainer[SkillSummary]
    def __init__(self, skills: _Optional[_Iterable[_Union[SkillSummary, _Mapping]]] = ...) -> None: ...

class SkillSummary(_message.Message):
    __slots__ = ("name", "skill_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SKILL_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    skill_id: str
    def __init__(self, name: _Optional[str] = ..., skill_id: _Optional[str] = ...) -> None: ...

class GetSkillRequest(_message.Message):
    __slots__ = ("name", "skill_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SKILL_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    skill_id: str
    def __init__(self, name: _Optional[str] = ..., skill_id: _Optional[str] = ...) -> None: ...

class GetSkillResponse(_message.Message):
    __slots__ = ("name", "content", "skill_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    SKILL_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    content: str
    skill_id: str
    def __init__(self, name: _Optional[str] = ..., content: _Optional[str] = ..., skill_id: _Optional[str] = ...) -> None: ...

class CreateSkillRequest(_message.Message):
    __slots__ = ("name", "content")
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    name: str
    content: str
    def __init__(self, name: _Optional[str] = ..., content: _Optional[str] = ...) -> None: ...

class CreateSkillResponse(_message.Message):
    __slots__ = ("success", "skill_id")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    SKILL_ID_FIELD_NUMBER: _ClassVar[int]
    success: bool
    skill_id: str
    def __init__(self, success: bool = ..., skill_id: _Optional[str] = ...) -> None: ...

class UpdateSkillRequest(_message.Message):
    __slots__ = ("name", "content", "skill_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    SKILL_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    content: str
    skill_id: str
    def __init__(self, name: _Optional[str] = ..., content: _Optional[str] = ..., skill_id: _Optional[str] = ...) -> None: ...

class UpdateSkillResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class RemoveSkillRequest(_message.Message):
    __slots__ = ("name", "skill_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SKILL_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    skill_id: str
    def __init__(self, name: _Optional[str] = ..., skill_id: _Optional[str] = ...) -> None: ...

class RemoveSkillResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class McpAuthConfig(_message.Message):
    __slots__ = ("auth_type", "secret_ref", "value", "header_name")
    AUTH_TYPE_FIELD_NUMBER: _ClassVar[int]
    SECRET_REF_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    HEADER_NAME_FIELD_NUMBER: _ClassVar[int]
    auth_type: str
    secret_ref: str
    value: str
    header_name: str
    def __init__(self, auth_type: _Optional[str] = ..., secret_ref: _Optional[str] = ..., value: _Optional[str] = ..., header_name: _Optional[str] = ...) -> None: ...

class McpServer(_message.Message):
    __slots__ = ("mcp_server_id", "display_name", "server_type", "status", "error_detail", "tool_count", "created_at", "binding_count")
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    SERVER_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ERROR_DETAIL_FIELD_NUMBER: _ClassVar[int]
    TOOL_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    BINDING_COUNT_FIELD_NUMBER: _ClassVar[int]
    mcp_server_id: str
    display_name: str
    server_type: str
    status: str
    error_detail: str
    tool_count: int
    created_at: str
    binding_count: int
    def __init__(self, mcp_server_id: _Optional[str] = ..., display_name: _Optional[str] = ..., server_type: _Optional[str] = ..., status: _Optional[str] = ..., error_detail: _Optional[str] = ..., tool_count: _Optional[int] = ..., created_at: _Optional[str] = ..., binding_count: _Optional[int] = ...) -> None: ...

class McpEntityBinding(_message.Message):
    __slots__ = ("mcp_server_id", "entity_type", "entity_id", "entity_name")
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_NAME_FIELD_NUMBER: _ClassVar[int]
    mcp_server_id: str
    entity_type: str
    entity_id: str
    entity_name: str
    def __init__(self, mcp_server_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., entity_name: _Optional[str] = ...) -> None: ...

class CreateMcpServerRequest(_message.Message):
    __slots__ = ("display_name", "server_type", "config_json", "auth_type", "bearer_token", "api_key", "api_key_header", "basic_username", "basic_password", "extra_headers_json")
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    SERVER_TYPE_FIELD_NUMBER: _ClassVar[int]
    CONFIG_JSON_FIELD_NUMBER: _ClassVar[int]
    AUTH_TYPE_FIELD_NUMBER: _ClassVar[int]
    BEARER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    API_KEY_FIELD_NUMBER: _ClassVar[int]
    API_KEY_HEADER_FIELD_NUMBER: _ClassVar[int]
    BASIC_USERNAME_FIELD_NUMBER: _ClassVar[int]
    BASIC_PASSWORD_FIELD_NUMBER: _ClassVar[int]
    EXTRA_HEADERS_JSON_FIELD_NUMBER: _ClassVar[int]
    display_name: str
    server_type: str
    config_json: str
    auth_type: str
    bearer_token: str
    api_key: str
    api_key_header: str
    basic_username: str
    basic_password: str
    extra_headers_json: str
    def __init__(self, display_name: _Optional[str] = ..., server_type: _Optional[str] = ..., config_json: _Optional[str] = ..., auth_type: _Optional[str] = ..., bearer_token: _Optional[str] = ..., api_key: _Optional[str] = ..., api_key_header: _Optional[str] = ..., basic_username: _Optional[str] = ..., basic_password: _Optional[str] = ..., extra_headers_json: _Optional[str] = ...) -> None: ...

class UpdateMcpServerRequest(_message.Message):
    __slots__ = ("mcp_server_id", "display_name", "server_type", "config_json", "auth_type", "bearer_token", "api_key", "api_key_header", "basic_username", "basic_password", "extra_headers_json")
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    SERVER_TYPE_FIELD_NUMBER: _ClassVar[int]
    CONFIG_JSON_FIELD_NUMBER: _ClassVar[int]
    AUTH_TYPE_FIELD_NUMBER: _ClassVar[int]
    BEARER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    API_KEY_FIELD_NUMBER: _ClassVar[int]
    API_KEY_HEADER_FIELD_NUMBER: _ClassVar[int]
    BASIC_USERNAME_FIELD_NUMBER: _ClassVar[int]
    BASIC_PASSWORD_FIELD_NUMBER: _ClassVar[int]
    EXTRA_HEADERS_JSON_FIELD_NUMBER: _ClassVar[int]
    mcp_server_id: str
    display_name: str
    server_type: str
    config_json: str
    auth_type: str
    bearer_token: str
    api_key: str
    api_key_header: str
    basic_username: str
    basic_password: str
    extra_headers_json: str
    def __init__(self, mcp_server_id: _Optional[str] = ..., display_name: _Optional[str] = ..., server_type: _Optional[str] = ..., config_json: _Optional[str] = ..., auth_type: _Optional[str] = ..., bearer_token: _Optional[str] = ..., api_key: _Optional[str] = ..., api_key_header: _Optional[str] = ..., basic_username: _Optional[str] = ..., basic_password: _Optional[str] = ..., extra_headers_json: _Optional[str] = ...) -> None: ...

class DeleteMcpServerRequest(_message.Message):
    __slots__ = ("mcp_server_id",)
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    mcp_server_id: str
    def __init__(self, mcp_server_id: _Optional[str] = ...) -> None: ...

class DeleteMcpServerResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GetMcpServerRequest(_message.Message):
    __slots__ = ("mcp_server_id",)
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    mcp_server_id: str
    def __init__(self, mcp_server_id: _Optional[str] = ...) -> None: ...

class ListMcpServersRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListMcpServersResponse(_message.Message):
    __slots__ = ("servers",)
    SERVERS_FIELD_NUMBER: _ClassVar[int]
    servers: _containers.RepeatedCompositeFieldContainer[McpServer]
    def __init__(self, servers: _Optional[_Iterable[_Union[McpServer, _Mapping]]] = ...) -> None: ...

class TestMcpServerRequest(_message.Message):
    __slots__ = ("mcp_server_id",)
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    mcp_server_id: str
    def __init__(self, mcp_server_id: _Optional[str] = ...) -> None: ...

class TestMcpServerResponse(_message.Message):
    __slots__ = ("success", "error", "tool_names", "tool_count")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    TOOL_NAMES_FIELD_NUMBER: _ClassVar[int]
    TOOL_COUNT_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    tool_names: _containers.RepeatedScalarFieldContainer[str]
    tool_count: int
    def __init__(self, success: bool = ..., error: _Optional[str] = ..., tool_names: _Optional[_Iterable[str]] = ..., tool_count: _Optional[int] = ...) -> None: ...

class SetMcpEntityBindingRequest(_message.Message):
    __slots__ = ("mcp_server_id", "entity_type", "entity_id")
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    mcp_server_id: str
    entity_type: str
    entity_id: str
    def __init__(self, mcp_server_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ...) -> None: ...

class RemoveMcpEntityBindingRequest(_message.Message):
    __slots__ = ("mcp_server_id", "entity_type", "entity_id")
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    mcp_server_id: str
    entity_type: str
    entity_id: str
    def __init__(self, mcp_server_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ...) -> None: ...

class RemoveMcpEntityBindingResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ListMcpEntityBindingsRequest(_message.Message):
    __slots__ = ("mcp_server_id",)
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    mcp_server_id: str
    def __init__(self, mcp_server_id: _Optional[str] = ...) -> None: ...

class ListMcpEntityBindingsResponse(_message.Message):
    __slots__ = ("bindings",)
    BINDINGS_FIELD_NUMBER: _ClassVar[int]
    bindings: _containers.RepeatedCompositeFieldContainer[McpEntityBinding]
    def __init__(self, bindings: _Optional[_Iterable[_Union[McpEntityBinding, _Mapping]]] = ...) -> None: ...

class ListMcpServerBindingsRequest(_message.Message):
    __slots__ = ("entity_type", "entity_id")
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    entity_type: str
    entity_id: str
    def __init__(self, entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ...) -> None: ...

class ListMcpServerBindingsResponse(_message.Message):
    __slots__ = ("servers",)
    SERVERS_FIELD_NUMBER: _ClassVar[int]
    servers: _containers.RepeatedCompositeFieldContainer[McpServer]
    def __init__(self, servers: _Optional[_Iterable[_Union[McpServer, _Mapping]]] = ...) -> None: ...

class McpServerChangedEvent(_message.Message):
    __slots__ = ("org_id", "mcp_server_id")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    MCP_SERVER_ID_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    mcp_server_id: str
    def __init__(self, org_id: _Optional[str] = ..., mcp_server_id: _Optional[str] = ...) -> None: ...

class ListKnownMcpServersRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListKnownMcpServersResponse(_message.Message):
    __slots__ = ("servers",)
    SERVERS_FIELD_NUMBER: _ClassVar[int]
    servers: _containers.RepeatedCompositeFieldContainer[KnownMcpServerInfo]
    def __init__(self, servers: _Optional[_Iterable[_Union[KnownMcpServerInfo, _Mapping]]] = ...) -> None: ...

class KnownMcpServerInfo(_message.Message):
    __slots__ = ("name", "description", "command", "args", "required_env", "setup_notes")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    ARGS_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_ENV_FIELD_NUMBER: _ClassVar[int]
    SETUP_NOTES_FIELD_NUMBER: _ClassVar[int]
    name: str
    description: str
    command: str
    args: _containers.RepeatedScalarFieldContainer[str]
    required_env: _containers.RepeatedScalarFieldContainer[str]
    setup_notes: str
    def __init__(self, name: _Optional[str] = ..., description: _Optional[str] = ..., command: _Optional[str] = ..., args: _Optional[_Iterable[str]] = ..., required_env: _Optional[_Iterable[str]] = ..., setup_notes: _Optional[str] = ...) -> None: ...

class GetMemoryRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class GetMemoryResponse(_message.Message):
    __slots__ = ("content",)
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    content: str
    def __init__(self, content: _Optional[str] = ...) -> None: ...

class SetMemoryRequest(_message.Message):
    __slots__ = ("agent", "content", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    content: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., content: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class SetMemoryResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ClearMemoryRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ClearMemoryResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GetLogsRequest(_message.Message):
    __slots__ = ("agent", "tail", "follow", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    TAIL_FIELD_NUMBER: _ClassVar[int]
    FOLLOW_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    tail: int
    follow: bool
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., tail: _Optional[int] = ..., follow: bool = ..., agent_id: _Optional[str] = ...) -> None: ...

class LogLine(_message.Message):
    __slots__ = ("timestamp", "level", "message")
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    timestamp: str
    level: str
    message: str
    def __init__(self, timestamp: _Optional[str] = ..., level: _Optional[str] = ..., message: _Optional[str] = ...) -> None: ...

class GetStatusRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetStatusResponse(_message.Message):
    __slots__ = ("running", "pid", "uptime", "agent_count", "activities")
    RUNNING_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    UPTIME_FIELD_NUMBER: _ClassVar[int]
    AGENT_COUNT_FIELD_NUMBER: _ClassVar[int]
    ACTIVITIES_FIELD_NUMBER: _ClassVar[int]
    running: bool
    pid: int
    uptime: str
    agent_count: int
    activities: _containers.RepeatedCompositeFieldContainer[AgentActivity]
    def __init__(self, running: bool = ..., pid: _Optional[int] = ..., uptime: _Optional[str] = ..., agent_count: _Optional[int] = ..., activities: _Optional[_Iterable[_Union[AgentActivity, _Mapping]]] = ...) -> None: ...

class AgentActivity(_message.Message):
    __slots__ = ("agent", "last_task_at", "status")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    LAST_TASK_AT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    agent: str
    last_task_at: str
    status: str
    def __init__(self, agent: _Optional[str] = ..., last_task_at: _Optional[str] = ..., status: _Optional[str] = ...) -> None: ...

class StreamLogsRequest(_message.Message):
    __slots__ = ("tail", "level_filter")
    TAIL_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FILTER_FIELD_NUMBER: _ClassVar[int]
    tail: int
    level_filter: str
    def __init__(self, tail: _Optional[int] = ..., level_filter: _Optional[str] = ...) -> None: ...

class StreamDashboardRequest(_message.Message):
    __slots__ = ("refresh_ms",)
    REFRESH_MS_FIELD_NUMBER: _ClassVar[int]
    refresh_ms: int
    def __init__(self, refresh_ms: _Optional[int] = ...) -> None: ...

class DashboardSnapshot(_message.Message):
    __slots__ = ("agents", "timestamp")
    AGENTS_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    agents: _containers.RepeatedCompositeFieldContainer[AgentSnapshot]
    timestamp: str
    def __init__(self, agents: _Optional[_Iterable[_Union[AgentSnapshot, _Mapping]]] = ..., timestamp: _Optional[str] = ...) -> None: ...

class AgentSnapshot(_message.Message):
    __slots__ = ("name", "emoji", "status", "queue_depth", "last_activity", "agent_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    EMOJI_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    QUEUE_DEPTH_FIELD_NUMBER: _ClassVar[int]
    LAST_ACTIVITY_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    emoji: str
    status: str
    queue_depth: int
    last_activity: str
    agent_id: str
    def __init__(self, name: _Optional[str] = ..., emoji: _Optional[str] = ..., status: _Optional[str] = ..., queue_depth: _Optional[int] = ..., last_activity: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class GetFrameworkRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetFrameworkResponse(_message.Message):
    __slots__ = ("content",)
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    content: str
    def __init__(self, content: _Optional[str] = ...) -> None: ...

class SetFrameworkRequest(_message.Message):
    __slots__ = ("content",)
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    content: str
    def __init__(self, content: _Optional[str] = ...) -> None: ...

class SetFrameworkResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GetWorkingMemoryRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetWorkingMemoryResponse(_message.Message):
    __slots__ = ("content",)
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    content: str
    def __init__(self, content: _Optional[str] = ...) -> None: ...

class SetWorkingMemoryRequest(_message.Message):
    __slots__ = ("content",)
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    content: str
    def __init__(self, content: _Optional[str] = ...) -> None: ...

class SetWorkingMemoryResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class PreviewSystemPromptRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class PreviewSystemPromptResponse(_message.Message):
    __slots__ = ("prompt", "estimated_tokens")
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    ESTIMATED_TOKENS_FIELD_NUMBER: _ClassVar[int]
    prompt: str
    estimated_tokens: int
    def __init__(self, prompt: _Optional[str] = ..., estimated_tokens: _Optional[int] = ...) -> None: ...

class ListSessionContextEventsRequest(_message.Message):
    __slots__ = ("agent", "session_key", "limit", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    SESSION_KEY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    session_key: str
    limit: int
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., session_key: _Optional[str] = ..., limit: _Optional[int] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ContextEventItem(_message.Message):
    __slots__ = ("event_id", "domain", "event_type", "timestamp", "detail")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    DOMAIN_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    event_id: str
    domain: str
    event_type: str
    timestamp: str
    detail: str
    def __init__(self, event_id: _Optional[str] = ..., domain: _Optional[str] = ..., event_type: _Optional[str] = ..., timestamp: _Optional[str] = ..., detail: _Optional[str] = ...) -> None: ...

class ListSessionContextEventsResponse(_message.Message):
    __slots__ = ("events",)
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[ContextEventItem]
    def __init__(self, events: _Optional[_Iterable[_Union[ContextEventItem, _Mapping]]] = ...) -> None: ...

class ContextSnapshot(_message.Message):
    __slots__ = ("snapshot_id", "agent", "session_key", "session_id", "task_id", "timestamp", "trigger", "total_tokens", "context_window", "system_prompt_tokens", "conversation_tokens", "tool_definitions_tokens", "sections", "compaction_tier", "messages_before", "messages_after", "compaction_summary", "compaction_reason", "system_prompt", "agent_id")
    SNAPSHOT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    SESSION_KEY_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TOKENS_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_WINDOW_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PROMPT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    CONVERSATION_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOOL_DEFINITIONS_TOKENS_FIELD_NUMBER: _ClassVar[int]
    SECTIONS_FIELD_NUMBER: _ClassVar[int]
    COMPACTION_TIER_FIELD_NUMBER: _ClassVar[int]
    MESSAGES_BEFORE_FIELD_NUMBER: _ClassVar[int]
    MESSAGES_AFTER_FIELD_NUMBER: _ClassVar[int]
    COMPACTION_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    COMPACTION_REASON_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PROMPT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    snapshot_id: str
    agent: str
    session_key: str
    session_id: str
    task_id: str
    timestamp: str
    trigger: str
    total_tokens: int
    context_window: int
    system_prompt_tokens: int
    conversation_tokens: int
    tool_definitions_tokens: int
    sections: _containers.RepeatedCompositeFieldContainer[ContextSection]
    compaction_tier: int
    messages_before: int
    messages_after: int
    compaction_summary: str
    compaction_reason: str
    system_prompt: str
    agent_id: str
    def __init__(self, snapshot_id: _Optional[str] = ..., agent: _Optional[str] = ..., session_key: _Optional[str] = ..., session_id: _Optional[str] = ..., task_id: _Optional[str] = ..., timestamp: _Optional[str] = ..., trigger: _Optional[str] = ..., total_tokens: _Optional[int] = ..., context_window: _Optional[int] = ..., system_prompt_tokens: _Optional[int] = ..., conversation_tokens: _Optional[int] = ..., tool_definitions_tokens: _Optional[int] = ..., sections: _Optional[_Iterable[_Union[ContextSection, _Mapping]]] = ..., compaction_tier: _Optional[int] = ..., messages_before: _Optional[int] = ..., messages_after: _Optional[int] = ..., compaction_summary: _Optional[str] = ..., compaction_reason: _Optional[str] = ..., system_prompt: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ContextSection(_message.Message):
    __slots__ = ("name", "tokens", "active")
    NAME_FIELD_NUMBER: _ClassVar[int]
    TOKENS_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    name: str
    tokens: int
    active: bool
    def __init__(self, name: _Optional[str] = ..., tokens: _Optional[int] = ..., active: bool = ...) -> None: ...

class GetContextSnapshotRequest(_message.Message):
    __slots__ = ("snapshot_id",)
    SNAPSHOT_ID_FIELD_NUMBER: _ClassVar[int]
    snapshot_id: str
    def __init__(self, snapshot_id: _Optional[str] = ...) -> None: ...

class GetContextSnapshotResponse(_message.Message):
    __slots__ = ("snapshot",)
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    snapshot: ContextSnapshot
    def __init__(self, snapshot: _Optional[_Union[ContextSnapshot, _Mapping]] = ...) -> None: ...

class ListContextSnapshotsRequest(_message.Message):
    __slots__ = ("agent", "session_key", "limit", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    SESSION_KEY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    session_key: str
    limit: int
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., session_key: _Optional[str] = ..., limit: _Optional[int] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ListContextSnapshotsResponse(_message.Message):
    __slots__ = ("snapshots",)
    SNAPSHOTS_FIELD_NUMBER: _ClassVar[int]
    snapshots: _containers.RepeatedCompositeFieldContainer[ContextSnapshotSummary]
    def __init__(self, snapshots: _Optional[_Iterable[_Union[ContextSnapshotSummary, _Mapping]]] = ...) -> None: ...

class ContextSnapshotSummary(_message.Message):
    __slots__ = ("snapshot_id", "timestamp", "trigger", "total_tokens", "context_window", "compaction_tier", "message_count", "compaction_reason")
    SNAPSHOT_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TOKENS_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_WINDOW_FIELD_NUMBER: _ClassVar[int]
    COMPACTION_TIER_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    COMPACTION_REASON_FIELD_NUMBER: _ClassVar[int]
    snapshot_id: str
    timestamp: str
    trigger: str
    total_tokens: int
    context_window: int
    compaction_tier: int
    message_count: int
    compaction_reason: str
    def __init__(self, snapshot_id: _Optional[str] = ..., timestamp: _Optional[str] = ..., trigger: _Optional[str] = ..., total_tokens: _Optional[int] = ..., context_window: _Optional[int] = ..., compaction_tier: _Optional[int] = ..., message_count: _Optional[int] = ..., compaction_reason: _Optional[str] = ...) -> None: ...

class GetStatsRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class GetStatsResponse(_message.Message):
    __slots__ = ("total_tasks", "pending_tasks", "completed_tasks", "failed_tasks", "db_size_bytes", "backend_type")
    TOTAL_TASKS_FIELD_NUMBER: _ClassVar[int]
    PENDING_TASKS_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_TASKS_FIELD_NUMBER: _ClassVar[int]
    FAILED_TASKS_FIELD_NUMBER: _ClassVar[int]
    DB_SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    BACKEND_TYPE_FIELD_NUMBER: _ClassVar[int]
    total_tasks: int
    pending_tasks: int
    completed_tasks: int
    failed_tasks: int
    db_size_bytes: int
    backend_type: str
    def __init__(self, total_tasks: _Optional[int] = ..., pending_tasks: _Optional[int] = ..., completed_tasks: _Optional[int] = ..., failed_tasks: _Optional[int] = ..., db_size_bytes: _Optional[int] = ..., backend_type: _Optional[str] = ...) -> None: ...

class ListRedisKeysRequest(_message.Message):
    __slots__ = ("agent", "pattern", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    PATTERN_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    pattern: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., pattern: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class RedisKeyInfo(_message.Message):
    __slots__ = ("key", "type")
    KEY_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    key: str
    type: str
    def __init__(self, key: _Optional[str] = ..., type: _Optional[str] = ...) -> None: ...

class ListRedisKeysResponse(_message.Message):
    __slots__ = ("keys",)
    KEYS_FIELD_NUMBER: _ClassVar[int]
    keys: _containers.RepeatedCompositeFieldContainer[RedisKeyInfo]
    def __init__(self, keys: _Optional[_Iterable[_Union[RedisKeyInfo, _Mapping]]] = ...) -> None: ...

class GetRedisValueRequest(_message.Message):
    __slots__ = ("agent", "key", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    key: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., key: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class GetRedisValueResponse(_message.Message):
    __slots__ = ("type", "value")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    type: str
    value: str
    def __init__(self, type: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class ListWorkstreamsRequest(_message.Message):
    __slots__ = ("limit", "query", "offset", "status_filter")
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    limit: int
    query: str
    offset: int
    status_filter: str
    def __init__(self, limit: _Optional[int] = ..., query: _Optional[str] = ..., offset: _Optional[int] = ..., status_filter: _Optional[str] = ...) -> None: ...

class WorkstreamSummary(_message.Message):
    __slots__ = ("workstream_id", "workflow_type", "entity_id", "status", "created_at_ms", "updated_at_ms", "upcoming_count", "past_count", "next_event_at_ms", "total_events", "team_name", "display_name")
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_MS_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_MS_FIELD_NUMBER: _ClassVar[int]
    UPCOMING_COUNT_FIELD_NUMBER: _ClassVar[int]
    PAST_COUNT_FIELD_NUMBER: _ClassVar[int]
    NEXT_EVENT_AT_MS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_EVENTS_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    workflow_type: str
    entity_id: str
    status: str
    created_at_ms: int
    updated_at_ms: int
    upcoming_count: int
    past_count: int
    next_event_at_ms: int
    total_events: int
    team_name: str
    display_name: str
    def __init__(self, workstream_id: _Optional[str] = ..., workflow_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., status: _Optional[str] = ..., created_at_ms: _Optional[int] = ..., updated_at_ms: _Optional[int] = ..., upcoming_count: _Optional[int] = ..., past_count: _Optional[int] = ..., next_event_at_ms: _Optional[int] = ..., total_events: _Optional[int] = ..., team_name: _Optional[str] = ..., display_name: _Optional[str] = ...) -> None: ...

class ListWorkstreamsResponse(_message.Message):
    __slots__ = ("workstreams", "total_count")
    WORKSTREAMS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    workstreams: _containers.RepeatedCompositeFieldContainer[WorkstreamSummary]
    total_count: int
    def __init__(self, workstreams: _Optional[_Iterable[_Union[WorkstreamSummary, _Mapping]]] = ..., total_count: _Optional[int] = ...) -> None: ...

class GetWorkstreamTimelineRequest(_message.Message):
    __slots__ = ("workstream_id", "limit", "offset")
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    limit: int
    offset: int
    def __init__(self, workstream_id: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class WorkstreamEvent(_message.Message):
    __slots__ = ("event_id", "event_type", "timestamp_ms", "task_id", "target_agent_role", "instruction", "status", "is_past", "detail", "reasoning")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_MS_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_AGENT_ROLE_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    IS_PAST_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    REASONING_FIELD_NUMBER: _ClassVar[int]
    event_id: str
    event_type: str
    timestamp_ms: int
    task_id: str
    target_agent_role: str
    instruction: str
    status: str
    is_past: bool
    detail: str
    reasoning: str
    def __init__(self, event_id: _Optional[str] = ..., event_type: _Optional[str] = ..., timestamp_ms: _Optional[int] = ..., task_id: _Optional[str] = ..., target_agent_role: _Optional[str] = ..., instruction: _Optional[str] = ..., status: _Optional[str] = ..., is_past: bool = ..., detail: _Optional[str] = ..., reasoning: _Optional[str] = ...) -> None: ...

class GetWorkstreamTimelineResponse(_message.Message):
    __slots__ = ("summary", "events", "total_events", "has_more")
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_EVENTS_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    summary: WorkstreamSummary
    events: _containers.RepeatedCompositeFieldContainer[WorkstreamEvent]
    total_events: int
    has_more: bool
    def __init__(self, summary: _Optional[_Union[WorkstreamSummary, _Mapping]] = ..., events: _Optional[_Iterable[_Union[WorkstreamEvent, _Mapping]]] = ..., total_events: _Optional[int] = ..., has_more: bool = ...) -> None: ...

class DeleteWorkstreamRequest(_message.Message):
    __slots__ = ("workstream_id",)
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    def __init__(self, workstream_id: _Optional[str] = ...) -> None: ...

class DeleteWorkstreamResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class TemporalStepCondition(_message.Message):
    __slots__ = ("require_state", "require_step_completed", "await_signal", "not_before_ms", "not_after_ms")
    class RequireStateEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    REQUIRE_STATE_FIELD_NUMBER: _ClassVar[int]
    REQUIRE_STEP_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    AWAIT_SIGNAL_FIELD_NUMBER: _ClassVar[int]
    NOT_BEFORE_MS_FIELD_NUMBER: _ClassVar[int]
    NOT_AFTER_MS_FIELD_NUMBER: _ClassVar[int]
    require_state: _containers.ScalarMap[str, str]
    require_step_completed: str
    await_signal: str
    not_before_ms: int
    not_after_ms: int
    def __init__(self, require_state: _Optional[_Mapping[str, str]] = ..., require_step_completed: _Optional[str] = ..., await_signal: _Optional[str] = ..., not_before_ms: _Optional[int] = ..., not_after_ms: _Optional[int] = ...) -> None: ...

class TemporalStepDef(_message.Message):
    __slots__ = ("step_id", "agent", "instruction", "execute_at_ms", "delay_after_previous", "require_step_completed", "conditions", "team", "branch_on", "if_false_step", "has_sub_workflow", "sub_workflow_type", "max_retries", "failure_action", "step_type", "notify_config", "wait_config", "decision_config", "loop_config", "condition_config")
    STEP_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    EXECUTE_AT_MS_FIELD_NUMBER: _ClassVar[int]
    DELAY_AFTER_PREVIOUS_FIELD_NUMBER: _ClassVar[int]
    REQUIRE_STEP_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    CONDITIONS_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    BRANCH_ON_FIELD_NUMBER: _ClassVar[int]
    IF_FALSE_STEP_FIELD_NUMBER: _ClassVar[int]
    HAS_SUB_WORKFLOW_FIELD_NUMBER: _ClassVar[int]
    SUB_WORKFLOW_TYPE_FIELD_NUMBER: _ClassVar[int]
    MAX_RETRIES_FIELD_NUMBER: _ClassVar[int]
    FAILURE_ACTION_FIELD_NUMBER: _ClassVar[int]
    STEP_TYPE_FIELD_NUMBER: _ClassVar[int]
    NOTIFY_CONFIG_FIELD_NUMBER: _ClassVar[int]
    WAIT_CONFIG_FIELD_NUMBER: _ClassVar[int]
    DECISION_CONFIG_FIELD_NUMBER: _ClassVar[int]
    LOOP_CONFIG_FIELD_NUMBER: _ClassVar[int]
    CONDITION_CONFIG_FIELD_NUMBER: _ClassVar[int]
    step_id: str
    agent: str
    instruction: str
    execute_at_ms: int
    delay_after_previous: str
    require_step_completed: str
    conditions: TemporalStepCondition
    team: str
    branch_on: BranchCondition
    if_false_step: str
    has_sub_workflow: bool
    sub_workflow_type: str
    max_retries: int
    failure_action: str
    step_type: str
    notify_config: TemporalNotifyConfig
    wait_config: TemporalWaitConfig
    decision_config: TemporalDecisionConfig
    loop_config: TemporalLoopConfig
    condition_config: TemporalConditionConfig
    def __init__(self, step_id: _Optional[str] = ..., agent: _Optional[str] = ..., instruction: _Optional[str] = ..., execute_at_ms: _Optional[int] = ..., delay_after_previous: _Optional[str] = ..., require_step_completed: _Optional[str] = ..., conditions: _Optional[_Union[TemporalStepCondition, _Mapping]] = ..., team: _Optional[str] = ..., branch_on: _Optional[_Union[BranchCondition, _Mapping]] = ..., if_false_step: _Optional[str] = ..., has_sub_workflow: bool = ..., sub_workflow_type: _Optional[str] = ..., max_retries: _Optional[int] = ..., failure_action: _Optional[str] = ..., step_type: _Optional[str] = ..., notify_config: _Optional[_Union[TemporalNotifyConfig, _Mapping]] = ..., wait_config: _Optional[_Union[TemporalWaitConfig, _Mapping]] = ..., decision_config: _Optional[_Union[TemporalDecisionConfig, _Mapping]] = ..., loop_config: _Optional[_Union[TemporalLoopConfig, _Mapping]] = ..., condition_config: _Optional[_Union[TemporalConditionConfig, _Mapping]] = ...) -> None: ...

class TemporalLoopConfig(_message.Message):
    __slots__ = ("mode", "max_iterations", "until_condition", "body_steps")
    MODE_FIELD_NUMBER: _ClassVar[int]
    MAX_ITERATIONS_FIELD_NUMBER: _ClassVar[int]
    UNTIL_CONDITION_FIELD_NUMBER: _ClassVar[int]
    BODY_STEPS_FIELD_NUMBER: _ClassVar[int]
    mode: str
    max_iterations: int
    until_condition: TemporalConditionConfig
    body_steps: _containers.RepeatedCompositeFieldContainer[TemporalStepDef]
    def __init__(self, mode: _Optional[str] = ..., max_iterations: _Optional[int] = ..., until_condition: _Optional[_Union[TemporalConditionConfig, _Mapping]] = ..., body_steps: _Optional[_Iterable[_Union[TemporalStepDef, _Mapping]]] = ...) -> None: ...

class TemporalConditionConfig(_message.Message):
    __slots__ = ("evaluate_step_output", "question", "model", "if_true", "if_false")
    EVALUATE_STEP_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    QUESTION_FIELD_NUMBER: _ClassVar[int]
    MODEL_FIELD_NUMBER: _ClassVar[int]
    IF_TRUE_FIELD_NUMBER: _ClassVar[int]
    IF_FALSE_FIELD_NUMBER: _ClassVar[int]
    evaluate_step_output: str
    question: str
    model: str
    if_true: _containers.RepeatedScalarFieldContainer[str]
    if_false: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, evaluate_step_output: _Optional[str] = ..., question: _Optional[str] = ..., model: _Optional[str] = ..., if_true: _Optional[_Iterable[str]] = ..., if_false: _Optional[_Iterable[str]] = ...) -> None: ...

class TemporalNotifyConfig(_message.Message):
    __slots__ = ("channel", "recipient", "message", "subject", "agent")
    CHANNEL_FIELD_NUMBER: _ClassVar[int]
    RECIPIENT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    channel: str
    recipient: str
    message: str
    subject: str
    agent: str
    def __init__(self, channel: _Optional[str] = ..., recipient: _Optional[str] = ..., message: _Optional[str] = ..., subject: _Optional[str] = ..., agent: _Optional[str] = ...) -> None: ...

class TemporalWaitConfig(_message.Message):
    __slots__ = ("mode", "duration_ms", "until_ms")
    MODE_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    UNTIL_MS_FIELD_NUMBER: _ClassVar[int]
    mode: str
    duration_ms: int
    until_ms: int
    def __init__(self, mode: _Optional[str] = ..., duration_ms: _Optional[int] = ..., until_ms: _Optional[int] = ...) -> None: ...

class TemporalDecisionConfig(_message.Message):
    __slots__ = ("question", "options", "tags", "timeout_ms")
    QUESTION_FIELD_NUMBER: _ClassVar[int]
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    question: str
    options: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    timeout_ms: int
    def __init__(self, question: _Optional[str] = ..., options: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., timeout_ms: _Optional[int] = ...) -> None: ...

class BranchCondition(_message.Message):
    __slots__ = ("state_key", "operator", "value", "if_false_step")
    STATE_KEY_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    IF_FALSE_STEP_FIELD_NUMBER: _ClassVar[int]
    state_key: str
    operator: str
    value: str
    if_false_step: str
    def __init__(self, state_key: _Optional[str] = ..., operator: _Optional[str] = ..., value: _Optional[str] = ..., if_false_step: _Optional[str] = ...) -> None: ...

class DefineWorkflowRequest(_message.Message):
    __slots__ = ("workflow_type", "entity_id", "steps", "initial_context_json", "team_name")
    WORKFLOW_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    INITIAL_CONTEXT_JSON_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    workflow_type: str
    entity_id: str
    steps: _containers.RepeatedCompositeFieldContainer[TemporalStepDef]
    initial_context_json: str
    team_name: str
    def __init__(self, workflow_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., steps: _Optional[_Iterable[_Union[TemporalStepDef, _Mapping]]] = ..., initial_context_json: _Optional[str] = ..., team_name: _Optional[str] = ...) -> None: ...

class DefineWorkflowResponse(_message.Message):
    __slots__ = ("workstream_id", "success", "error")
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    success: bool
    error: str
    def __init__(self, workstream_id: _Optional[str] = ..., success: bool = ..., error: _Optional[str] = ...) -> None: ...

class GetWorkflowPlanRequest(_message.Message):
    __slots__ = ("workstream_id",)
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    def __init__(self, workstream_id: _Optional[str] = ...) -> None: ...

class GetWorkflowPlanResponse(_message.Message):
    __slots__ = ("workstream_id", "workflow_type", "entity_id", "steps", "success", "team_name", "completion_criteria", "max_concurrent")
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    COMPLETION_CRITERIA_FIELD_NUMBER: _ClassVar[int]
    MAX_CONCURRENT_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    workflow_type: str
    entity_id: str
    steps: _containers.RepeatedCompositeFieldContainer[TemporalStepDef]
    success: bool
    team_name: str
    completion_criteria: str
    max_concurrent: int
    def __init__(self, workstream_id: _Optional[str] = ..., workflow_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., steps: _Optional[_Iterable[_Union[TemporalStepDef, _Mapping]]] = ..., success: bool = ..., team_name: _Optional[str] = ..., completion_criteria: _Optional[str] = ..., max_concurrent: _Optional[int] = ...) -> None: ...

class GetWorkstreamStateRequest(_message.Message):
    __slots__ = ("workstream_id",)
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    def __init__(self, workstream_id: _Optional[str] = ...) -> None: ...

class StepResultSummary(_message.Message):
    __slots__ = ("status", "summary", "skipped_reason")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    SKIPPED_REASON_FIELD_NUMBER: _ClassVar[int]
    status: str
    summary: str
    skipped_reason: str
    def __init__(self, status: _Optional[str] = ..., summary: _Optional[str] = ..., skipped_reason: _Optional[str] = ...) -> None: ...

class GetWorkstreamStateResponse(_message.Message):
    __slots__ = ("step_results", "signals", "success", "error", "data")
    class StepResultsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: StepResultSummary
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[StepResultSummary, _Mapping]] = ...) -> None: ...
    class SignalsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    class DataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    STEP_RESULTS_FIELD_NUMBER: _ClassVar[int]
    SIGNALS_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    step_results: _containers.MessageMap[str, StepResultSummary]
    signals: _containers.ScalarMap[str, str]
    success: bool
    error: str
    data: _containers.ScalarMap[str, str]
    def __init__(self, step_results: _Optional[_Mapping[str, StepResultSummary]] = ..., signals: _Optional[_Mapping[str, str]] = ..., success: bool = ..., error: _Optional[str] = ..., data: _Optional[_Mapping[str, str]] = ...) -> None: ...

class SignalWorkflowRequest(_message.Message):
    __slots__ = ("workstream_id", "signal_name", "value")
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    signal_name: str
    value: str
    def __init__(self, workstream_id: _Optional[str] = ..., signal_name: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class SignalWorkflowResponse(_message.Message):
    __slots__ = ("success", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ...) -> None: ...

class AddStepToWorkflowRequest(_message.Message):
    __slots__ = ("workstream_id", "step")
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    step: TemporalStepDef
    def __init__(self, workstream_id: _Optional[str] = ..., step: _Optional[_Union[TemporalStepDef, _Mapping]] = ...) -> None: ...

class AddStepToWorkflowResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class WorkflowDraft(_message.Message):
    __slots__ = ("draft_id", "agent_name", "original_request", "workflow_type", "entity_id", "plan_json", "validation_json", "intent_coverage_json", "critique_notes", "status", "revision", "summary", "completion_criteria", "steps", "created_at_ms", "updated_at_ms")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_REQUEST_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    PLAN_JSON_FIELD_NUMBER: _ClassVar[int]
    VALIDATION_JSON_FIELD_NUMBER: _ClassVar[int]
    INTENT_COVERAGE_JSON_FIELD_NUMBER: _ClassVar[int]
    CRITIQUE_NOTES_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    COMPLETION_CRITERIA_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_MS_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_MS_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    agent_name: str
    original_request: str
    workflow_type: str
    entity_id: str
    plan_json: str
    validation_json: str
    intent_coverage_json: str
    critique_notes: str
    status: str
    revision: int
    summary: str
    completion_criteria: str
    steps: _containers.RepeatedCompositeFieldContainer[TemporalStepDef]
    created_at_ms: int
    updated_at_ms: int
    def __init__(self, draft_id: _Optional[str] = ..., agent_name: _Optional[str] = ..., original_request: _Optional[str] = ..., workflow_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., plan_json: _Optional[str] = ..., validation_json: _Optional[str] = ..., intent_coverage_json: _Optional[str] = ..., critique_notes: _Optional[str] = ..., status: _Optional[str] = ..., revision: _Optional[int] = ..., summary: _Optional[str] = ..., completion_criteria: _Optional[str] = ..., steps: _Optional[_Iterable[_Union[TemporalStepDef, _Mapping]]] = ..., created_at_ms: _Optional[int] = ..., updated_at_ms: _Optional[int] = ...) -> None: ...

class ListDraftsRequest(_message.Message):
    __slots__ = ("status_filter",)
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    status_filter: str
    def __init__(self, status_filter: _Optional[str] = ...) -> None: ...

class ListDraftsResponse(_message.Message):
    __slots__ = ("drafts",)
    DRAFTS_FIELD_NUMBER: _ClassVar[int]
    drafts: _containers.RepeatedCompositeFieldContainer[WorkflowDraft]
    def __init__(self, drafts: _Optional[_Iterable[_Union[WorkflowDraft, _Mapping]]] = ...) -> None: ...

class GetDraftRequest(_message.Message):
    __slots__ = ("draft_id",)
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    def __init__(self, draft_id: _Optional[str] = ...) -> None: ...

class GetDraftResponse(_message.Message):
    __slots__ = ("draft", "success", "error")
    DRAFT_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    draft: WorkflowDraft
    success: bool
    error: str
    def __init__(self, draft: _Optional[_Union[WorkflowDraft, _Mapping]] = ..., success: bool = ..., error: _Optional[str] = ...) -> None: ...

class UpdateDraftStepRequest(_message.Message):
    __slots__ = ("draft_id", "step_index", "agent", "instruction", "delay", "depends_on", "expected_revision")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    STEP_INDEX_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    DELAY_FIELD_NUMBER: _ClassVar[int]
    DEPENDS_ON_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_REVISION_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    step_index: int
    agent: str
    instruction: str
    delay: str
    depends_on: str
    expected_revision: int
    def __init__(self, draft_id: _Optional[str] = ..., step_index: _Optional[int] = ..., agent: _Optional[str] = ..., instruction: _Optional[str] = ..., delay: _Optional[str] = ..., depends_on: _Optional[str] = ..., expected_revision: _Optional[int] = ...) -> None: ...

class UpdateDraftStepResponse(_message.Message):
    __slots__ = ("success", "error", "new_revision")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    NEW_REVISION_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    new_revision: int
    def __init__(self, success: bool = ..., error: _Optional[str] = ..., new_revision: _Optional[int] = ...) -> None: ...

class AddDraftStepRequest(_message.Message):
    __slots__ = ("draft_id", "agent", "instruction", "delay", "depends_on")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    DELAY_FIELD_NUMBER: _ClassVar[int]
    DEPENDS_ON_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    agent: str
    instruction: str
    delay: str
    depends_on: str
    def __init__(self, draft_id: _Optional[str] = ..., agent: _Optional[str] = ..., instruction: _Optional[str] = ..., delay: _Optional[str] = ..., depends_on: _Optional[str] = ...) -> None: ...

class AddDraftStepResponse(_message.Message):
    __slots__ = ("success", "error", "step_id")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    STEP_ID_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    step_id: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ..., step_id: _Optional[str] = ...) -> None: ...

class RemoveDraftStepRequest(_message.Message):
    __slots__ = ("draft_id", "step_index")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    STEP_INDEX_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    step_index: str
    def __init__(self, draft_id: _Optional[str] = ..., step_index: _Optional[str] = ...) -> None: ...

class RemoveDraftStepResponse(_message.Message):
    __slots__ = ("success", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ...) -> None: ...

class RequestDraftRevisionRequest(_message.Message):
    __slots__ = ("draft_id", "feedback")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    FEEDBACK_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    feedback: str
    def __init__(self, draft_id: _Optional[str] = ..., feedback: _Optional[str] = ...) -> None: ...

class RequestDraftRevisionResponse(_message.Message):
    __slots__ = ("success", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ...) -> None: ...

class ApproveDraftRequest(_message.Message):
    __slots__ = ("draft_id",)
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    def __init__(self, draft_id: _Optional[str] = ...) -> None: ...

class ApproveDraftResponse(_message.Message):
    __slots__ = ("success", "error", "workstream_id")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    workstream_id: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ..., workstream_id: _Optional[str] = ...) -> None: ...

class RejectDraftRequest(_message.Message):
    __slots__ = ("draft_id", "reason")
    DRAFT_ID_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    draft_id: str
    reason: str
    def __init__(self, draft_id: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class RejectDraftResponse(_message.Message):
    __slots__ = ("success", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ...) -> None: ...

class ListDlqRequest(_message.Message):
    __slots__ = ("offset", "limit")
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    offset: int
    limit: int
    def __init__(self, offset: _Optional[int] = ..., limit: _Optional[int] = ...) -> None: ...

class DlqEntry(_message.Message):
    __slots__ = ("index", "task_id", "workstream_id", "agent", "instruction", "retries", "moved_to_dlq_at_ms", "reason", "raw_json")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    RETRIES_FIELD_NUMBER: _ClassVar[int]
    MOVED_TO_DLQ_AT_MS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    RAW_JSON_FIELD_NUMBER: _ClassVar[int]
    index: int
    task_id: str
    workstream_id: str
    agent: str
    instruction: str
    retries: int
    moved_to_dlq_at_ms: int
    reason: str
    raw_json: str
    def __init__(self, index: _Optional[int] = ..., task_id: _Optional[str] = ..., workstream_id: _Optional[str] = ..., agent: _Optional[str] = ..., instruction: _Optional[str] = ..., retries: _Optional[int] = ..., moved_to_dlq_at_ms: _Optional[int] = ..., reason: _Optional[str] = ..., raw_json: _Optional[str] = ...) -> None: ...

class ListDlqResponse(_message.Message):
    __slots__ = ("entries", "total")
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedCompositeFieldContainer[DlqEntry]
    total: int
    def __init__(self, entries: _Optional[_Iterable[_Union[DlqEntry, _Mapping]]] = ..., total: _Optional[int] = ...) -> None: ...

class ReplayDlqRequest(_message.Message):
    __slots__ = ("index",)
    INDEX_FIELD_NUMBER: _ClassVar[int]
    index: int
    def __init__(self, index: _Optional[int] = ...) -> None: ...

class ReplayDlqResponse(_message.Message):
    __slots__ = ("success", "task_id", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    task_id: str
    error: str
    def __init__(self, success: bool = ..., task_id: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...

class PurgeDlqRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PurgeDlqResponse(_message.Message):
    __slots__ = ("purged_count",)
    PURGED_COUNT_FIELD_NUMBER: _ClassVar[int]
    purged_count: int
    def __init__(self, purged_count: _Optional[int] = ...) -> None: ...

class PurgeRequest(_message.Message):
    __slots__ = ("agent", "keep_count", "keep_days", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    KEEP_COUNT_FIELD_NUMBER: _ClassVar[int]
    KEEP_DAYS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    keep_count: int
    keep_days: int
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., keep_count: _Optional[int] = ..., keep_days: _Optional[int] = ..., agent_id: _Optional[str] = ...) -> None: ...

class PurgeResponse(_message.Message):
    __slots__ = ("purged_count",)
    PURGED_COUNT_FIELD_NUMBER: _ClassVar[int]
    purged_count: int
    def __init__(self, purged_count: _Optional[int] = ...) -> None: ...

class PurgeCronLogsRequest(_message.Message):
    __slots__ = ("agent", "keep_count", "keep_days", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    KEEP_COUNT_FIELD_NUMBER: _ClassVar[int]
    KEEP_DAYS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    keep_count: int
    keep_days: int
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., keep_count: _Optional[int] = ..., keep_days: _Optional[int] = ..., agent_id: _Optional[str] = ...) -> None: ...

class PurgeCronLogsResponse(_message.Message):
    __slots__ = ("purged_count",)
    PURGED_COUNT_FIELD_NUMBER: _ClassVar[int]
    purged_count: int
    def __init__(self, purged_count: _Optional[int] = ...) -> None: ...

class ResetStuckRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ResetStuckResponse(_message.Message):
    __slots__ = ("reset_count",)
    RESET_COUNT_FIELD_NUMBER: _ClassVar[int]
    reset_count: int
    def __init__(self, reset_count: _Optional[int] = ...) -> None: ...

class ExportRequest(_message.Message):
    __slots__ = ("agent", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., agent_id: _Optional[str] = ...) -> None: ...

class ExportChunk(_message.Message):
    __slots__ = ("data",)
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: bytes
    def __init__(self, data: _Optional[bytes] = ...) -> None: ...

class ListTokensRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListTokensResponse(_message.Message):
    __slots__ = ("tokens",)
    TOKENS_FIELD_NUMBER: _ClassVar[int]
    tokens: _containers.RepeatedCompositeFieldContainer[TokenInfo]
    def __init__(self, tokens: _Optional[_Iterable[_Union[TokenInfo, _Mapping]]] = ...) -> None: ...

class TokenInfo(_message.Message):
    __slots__ = ("id", "name", "role", "created_at", "last_used_at", "expires_at", "agent_scope", "created_by_user_id", "created_by_username")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_USED_AT_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    AGENT_SCOPE_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_USER_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_USERNAME_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    role: str
    created_at: str
    last_used_at: str
    expires_at: str
    agent_scope: _containers.RepeatedScalarFieldContainer[str]
    created_by_user_id: str
    created_by_username: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., created_at: _Optional[str] = ..., last_used_at: _Optional[str] = ..., expires_at: _Optional[str] = ..., agent_scope: _Optional[_Iterable[str]] = ..., created_by_user_id: _Optional[str] = ..., created_by_username: _Optional[str] = ...) -> None: ...

class CreateTokenRequest(_message.Message):
    __slots__ = ("name", "role", "expires_at", "agent_scope")
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    AGENT_SCOPE_FIELD_NUMBER: _ClassVar[int]
    name: str
    role: str
    expires_at: str
    agent_scope: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, name: _Optional[str] = ..., role: _Optional[str] = ..., expires_at: _Optional[str] = ..., agent_scope: _Optional[_Iterable[str]] = ...) -> None: ...

class CreateTokenResponse(_message.Message):
    __slots__ = ("success", "token", "id", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    token: str
    id: str
    message: str
    def __init__(self, success: bool = ..., token: _Optional[str] = ..., id: _Optional[str] = ..., message: _Optional[str] = ...) -> None: ...

class RevokeTokenRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class RevokeTokenResponse(_message.Message):
    __slots__ = ("success", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ...) -> None: ...

class RegenerateBootstrapRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RegenerateBootstrapResponse(_message.Message):
    __slots__ = ("success", "token", "message")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    success: bool
    token: str
    message: str
    def __init__(self, success: bool = ..., token: _Optional[str] = ..., message: _Optional[str] = ...) -> None: ...

class GetCurrentUserRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetCurrentUserResponse(_message.Message):
    __slots__ = ("token_id", "name", "role", "agent_scope", "user_id", "username", "display_name", "email", "user_role")
    TOKEN_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    AGENT_SCOPE_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    USER_ROLE_FIELD_NUMBER: _ClassVar[int]
    token_id: str
    name: str
    role: str
    agent_scope: _containers.RepeatedScalarFieldContainer[str]
    user_id: str
    username: str
    display_name: str
    email: str
    user_role: str
    def __init__(self, token_id: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., agent_scope: _Optional[_Iterable[str]] = ..., user_id: _Optional[str] = ..., username: _Optional[str] = ..., display_name: _Optional[str] = ..., email: _Optional[str] = ..., user_role: _Optional[str] = ...) -> None: ...

class User(_message.Message):
    __slots__ = ("user_id", "username", "email", "display_name", "role", "is_active", "created_at", "last_login_at")
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_LOGIN_AT_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    username: str
    email: str
    display_name: str
    role: str
    is_active: bool
    created_at: str
    last_login_at: str
    def __init__(self, user_id: _Optional[str] = ..., username: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., role: _Optional[str] = ..., is_active: bool = ..., created_at: _Optional[str] = ..., last_login_at: _Optional[str] = ...) -> None: ...

class ListUsersRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListUsersResponse(_message.Message):
    __slots__ = ("users",)
    USERS_FIELD_NUMBER: _ClassVar[int]
    users: _containers.RepeatedCompositeFieldContainer[User]
    def __init__(self, users: _Optional[_Iterable[_Union[User, _Mapping]]] = ...) -> None: ...

class GetUserRequest(_message.Message):
    __slots__ = ("user_id",)
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    def __init__(self, user_id: _Optional[str] = ...) -> None: ...

class GetUserResponse(_message.Message):
    __slots__ = ("user",)
    USER_FIELD_NUMBER: _ClassVar[int]
    user: User
    def __init__(self, user: _Optional[_Union[User, _Mapping]] = ...) -> None: ...

class CreateUserRequest(_message.Message):
    __slots__ = ("username", "email", "display_name", "role")
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    username: str
    email: str
    display_name: str
    role: str
    def __init__(self, username: _Optional[str] = ..., email: _Optional[str] = ..., display_name: _Optional[str] = ..., role: _Optional[str] = ...) -> None: ...

class CreateUserResponse(_message.Message):
    __slots__ = ("user", "invite_token")
    USER_FIELD_NUMBER: _ClassVar[int]
    INVITE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    user: User
    invite_token: str
    def __init__(self, user: _Optional[_Union[User, _Mapping]] = ..., invite_token: _Optional[str] = ...) -> None: ...

class UpdateUserRequest(_message.Message):
    __slots__ = ("user_id", "display_name", "email", "role")
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    display_name: str
    email: str
    role: str
    def __init__(self, user_id: _Optional[str] = ..., display_name: _Optional[str] = ..., email: _Optional[str] = ..., role: _Optional[str] = ...) -> None: ...

class UpdateUserResponse(_message.Message):
    __slots__ = ("user",)
    USER_FIELD_NUMBER: _ClassVar[int]
    user: User
    def __init__(self, user: _Optional[_Union[User, _Mapping]] = ...) -> None: ...

class DeactivateUserRequest(_message.Message):
    __slots__ = ("user_id",)
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    def __init__(self, user_id: _Optional[str] = ...) -> None: ...

class DeactivateUserResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class DeleteUserRequest(_message.Message):
    __slots__ = ("user_id",)
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    def __init__(self, user_id: _Optional[str] = ...) -> None: ...

class DeleteUserResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class LoginRequest(_message.Message):
    __slots__ = ("username", "password")
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    username: str
    password: str
    def __init__(self, username: _Optional[str] = ..., password: _Optional[str] = ...) -> None: ...

class LoginResponse(_message.Message):
    __slots__ = ("token", "expires_at", "user")
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    token: str
    expires_at: str
    user: User
    def __init__(self, token: _Optional[str] = ..., expires_at: _Optional[str] = ..., user: _Optional[_Union[User, _Mapping]] = ...) -> None: ...

class AcceptInviteRequest(_message.Message):
    __slots__ = ("invite_token", "password")
    INVITE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    invite_token: str
    password: str
    def __init__(self, invite_token: _Optional[str] = ..., password: _Optional[str] = ...) -> None: ...

class AcceptInviteResponse(_message.Message):
    __slots__ = ("token", "user")
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    token: str
    user: User
    def __init__(self, token: _Optional[str] = ..., user: _Optional[_Union[User, _Mapping]] = ...) -> None: ...

class ChangePasswordRequest(_message.Message):
    __slots__ = ("current_password", "new_password")
    CURRENT_PASSWORD_FIELD_NUMBER: _ClassVar[int]
    NEW_PASSWORD_FIELD_NUMBER: _ClassVar[int]
    current_password: str
    new_password: str
    def __init__(self, current_password: _Optional[str] = ..., new_password: _Optional[str] = ...) -> None: ...

class ChangePasswordResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ListCustomToolsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListCustomToolsResponse(_message.Message):
    __slots__ = ("tools",)
    TOOLS_FIELD_NUMBER: _ClassVar[int]
    tools: _containers.RepeatedCompositeFieldContainer[CustomToolInfo]
    def __init__(self, tools: _Optional[_Iterable[_Union[CustomToolInfo, _Mapping]]] = ...) -> None: ...

class CustomToolInfo(_message.Message):
    __slots__ = ("name", "qualified_name", "description", "command", "args", "timeout_secs", "dir")
    NAME_FIELD_NUMBER: _ClassVar[int]
    QUALIFIED_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    ARGS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_SECS_FIELD_NUMBER: _ClassVar[int]
    DIR_FIELD_NUMBER: _ClassVar[int]
    name: str
    qualified_name: str
    description: str
    command: str
    args: _containers.RepeatedScalarFieldContainer[str]
    timeout_secs: int
    dir: str
    def __init__(self, name: _Optional[str] = ..., qualified_name: _Optional[str] = ..., description: _Optional[str] = ..., command: _Optional[str] = ..., args: _Optional[_Iterable[str]] = ..., timeout_secs: _Optional[int] = ..., dir: _Optional[str] = ...) -> None: ...

class DeleteCustomToolRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class DeleteCustomToolResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReadToolFileRequest(_message.Message):
    __slots__ = ("tool_name", "file_name")
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    FILE_NAME_FIELD_NUMBER: _ClassVar[int]
    tool_name: str
    file_name: str
    def __init__(self, tool_name: _Optional[str] = ..., file_name: _Optional[str] = ...) -> None: ...

class ReadToolFileResponse(_message.Message):
    __slots__ = ("content",)
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    content: str
    def __init__(self, content: _Optional[str] = ...) -> None: ...

class WriteToolFileRequest(_message.Message):
    __slots__ = ("tool_name", "file_name", "content")
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    FILE_NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    tool_name: str
    file_name: str
    content: str
    def __init__(self, tool_name: _Optional[str] = ..., file_name: _Optional[str] = ..., content: _Optional[str] = ...) -> None: ...

class WriteToolFileResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListToolFilesRequest(_message.Message):
    __slots__ = ("tool_name",)
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    tool_name: str
    def __init__(self, tool_name: _Optional[str] = ...) -> None: ...

class ListToolFilesResponse(_message.Message):
    __slots__ = ("files",)
    FILES_FIELD_NUMBER: _ClassVar[int]
    files: _containers.RepeatedCompositeFieldContainer[ToolFileInfo]
    def __init__(self, files: _Optional[_Iterable[_Union[ToolFileInfo, _Mapping]]] = ...) -> None: ...

class ToolFileInfo(_message.Message):
    __slots__ = ("name", "size_bytes", "is_executable")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    IS_EXECUTABLE_FIELD_NUMBER: _ClassVar[int]
    name: str
    size_bytes: int
    is_executable: bool
    def __init__(self, name: _Optional[str] = ..., size_bytes: _Optional[int] = ..., is_executable: bool = ...) -> None: ...

class ChatStreamRequest(_message.Message):
    __slots__ = ("agent", "user_message", "control")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    USER_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    CONTROL_FIELD_NUMBER: _ClassVar[int]
    agent: str
    user_message: ChatUserMessage
    control: ChatControl
    def __init__(self, agent: _Optional[str] = ..., user_message: _Optional[_Union[ChatUserMessage, _Mapping]] = ..., control: _Optional[_Union[ChatControl, _Mapping]] = ...) -> None: ...

class ChatUserMessage(_message.Message):
    __slots__ = ("content", "session_id", "project_root", "cwd")
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ROOT_FIELD_NUMBER: _ClassVar[int]
    CWD_FIELD_NUMBER: _ClassVar[int]
    content: str
    session_id: str
    project_root: str
    cwd: str
    def __init__(self, content: _Optional[str] = ..., session_id: _Optional[str] = ..., project_root: _Optional[str] = ..., cwd: _Optional[str] = ...) -> None: ...

class ChatControl(_message.Message):
    __slots__ = ("action",)
    ACTION_FIELD_NUMBER: _ClassVar[int]
    action: str
    def __init__(self, action: _Optional[str] = ...) -> None: ...

class ChatStreamResponse(_message.Message):
    __slots__ = ("agent", "text_delta", "tool_use", "tool_result", "turn_complete", "error", "session_info")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    TEXT_DELTA_FIELD_NUMBER: _ClassVar[int]
    TOOL_USE_FIELD_NUMBER: _ClassVar[int]
    TOOL_RESULT_FIELD_NUMBER: _ClassVar[int]
    TURN_COMPLETE_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    SESSION_INFO_FIELD_NUMBER: _ClassVar[int]
    agent: str
    text_delta: ChatTextDelta
    tool_use: ChatToolUse
    tool_result: ChatToolResult
    turn_complete: ChatTurnComplete
    error: ChatError
    session_info: ChatSessionInfo
    def __init__(self, agent: _Optional[str] = ..., text_delta: _Optional[_Union[ChatTextDelta, _Mapping]] = ..., tool_use: _Optional[_Union[ChatToolUse, _Mapping]] = ..., tool_result: _Optional[_Union[ChatToolResult, _Mapping]] = ..., turn_complete: _Optional[_Union[ChatTurnComplete, _Mapping]] = ..., error: _Optional[_Union[ChatError, _Mapping]] = ..., session_info: _Optional[_Union[ChatSessionInfo, _Mapping]] = ...) -> None: ...

class ChatTextDelta(_message.Message):
    __slots__ = ("text", "index")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    INDEX_FIELD_NUMBER: _ClassVar[int]
    text: str
    index: int
    def __init__(self, text: _Optional[str] = ..., index: _Optional[int] = ...) -> None: ...

class ChatToolUse(_message.Message):
    __slots__ = ("tool_name", "tool_id", "input_json")
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    TOOL_ID_FIELD_NUMBER: _ClassVar[int]
    INPUT_JSON_FIELD_NUMBER: _ClassVar[int]
    tool_name: str
    tool_id: str
    input_json: str
    def __init__(self, tool_name: _Optional[str] = ..., tool_id: _Optional[str] = ..., input_json: _Optional[str] = ...) -> None: ...

class ChatToolResult(_message.Message):
    __slots__ = ("tool_id", "result", "is_error")
    TOOL_ID_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    IS_ERROR_FIELD_NUMBER: _ClassVar[int]
    tool_id: str
    result: str
    is_error: bool
    def __init__(self, tool_id: _Optional[str] = ..., result: _Optional[str] = ..., is_error: bool = ...) -> None: ...

class ChatTurnComplete(_message.Message):
    __slots__ = ("full_response", "input_tokens", "output_tokens", "model_used", "has_more")
    FULL_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    MODEL_USED_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    full_response: str
    input_tokens: int
    output_tokens: int
    model_used: str
    has_more: bool
    def __init__(self, full_response: _Optional[str] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., model_used: _Optional[str] = ..., has_more: bool = ...) -> None: ...

class ChatError(_message.Message):
    __slots__ = ("message", "is_fatal")
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    IS_FATAL_FIELD_NUMBER: _ClassVar[int]
    message: str
    is_fatal: bool
    def __init__(self, message: _Optional[str] = ..., is_fatal: bool = ...) -> None: ...

class ChatSessionInfo(_message.Message):
    __slots__ = ("session_id",)
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    def __init__(self, session_id: _Optional[str] = ...) -> None: ...

class SubscribeAllRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ChesterEvent(_message.Message):
    __slots__ = ("domain", "event_type", "agent", "entity_id", "detail", "timestamp", "error_details", "event_id", "parent_id", "session_key", "session_id", "agent_id", "team_id")
    DOMAIN_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ERROR_DETAILS_FIELD_NUMBER: _ClassVar[int]
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    PARENT_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_KEY_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TEAM_ID_FIELD_NUMBER: _ClassVar[int]
    domain: str
    event_type: str
    agent: str
    entity_id: str
    detail: str
    timestamp: str
    error_details: str
    event_id: str
    parent_id: str
    session_key: str
    session_id: str
    agent_id: str
    team_id: str
    def __init__(self, domain: _Optional[str] = ..., event_type: _Optional[str] = ..., agent: _Optional[str] = ..., entity_id: _Optional[str] = ..., detail: _Optional[str] = ..., timestamp: _Optional[str] = ..., error_details: _Optional[str] = ..., event_id: _Optional[str] = ..., parent_id: _Optional[str] = ..., session_key: _Optional[str] = ..., session_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., team_id: _Optional[str] = ...) -> None: ...

class GetTokenAnalyticsRequest(_message.Message):
    __slots__ = ("agent", "days", "agent_id")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    DAYS_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent: str
    days: int
    agent_id: str
    def __init__(self, agent: _Optional[str] = ..., days: _Optional[int] = ..., agent_id: _Optional[str] = ...) -> None: ...

class GetTokenAnalyticsResponse(_message.Message):
    __slots__ = ("agents", "total_cost_usd", "total_input_tokens", "total_output_tokens")
    AGENTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    TOTAL_INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    agents: _containers.RepeatedCompositeFieldContainer[AgentTokenSummary]
    total_cost_usd: float
    total_input_tokens: int
    total_output_tokens: int
    def __init__(self, agents: _Optional[_Iterable[_Union[AgentTokenSummary, _Mapping]]] = ..., total_cost_usd: _Optional[float] = ..., total_input_tokens: _Optional[int] = ..., total_output_tokens: _Optional[int] = ...) -> None: ...

class AgentTokenSummary(_message.Message):
    __slots__ = ("agent_name", "agent_id", "daily_usage", "total_cost_usd", "total_input_tokens", "total_output_tokens", "total_tasks", "model_breakdown", "daily_budget_usd", "monthly_budget_usd", "current_month_cost_usd")
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    DAILY_USAGE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    TOTAL_INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TASKS_FIELD_NUMBER: _ClassVar[int]
    MODEL_BREAKDOWN_FIELD_NUMBER: _ClassVar[int]
    DAILY_BUDGET_USD_FIELD_NUMBER: _ClassVar[int]
    MONTHLY_BUDGET_USD_FIELD_NUMBER: _ClassVar[int]
    CURRENT_MONTH_COST_USD_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    agent_id: str
    daily_usage: _containers.RepeatedCompositeFieldContainer[DailyUsage]
    total_cost_usd: float
    total_input_tokens: int
    total_output_tokens: int
    total_tasks: int
    model_breakdown: _containers.RepeatedCompositeFieldContainer[ModelBreakdown]
    daily_budget_usd: float
    monthly_budget_usd: float
    current_month_cost_usd: float
    def __init__(self, agent_name: _Optional[str] = ..., agent_id: _Optional[str] = ..., daily_usage: _Optional[_Iterable[_Union[DailyUsage, _Mapping]]] = ..., total_cost_usd: _Optional[float] = ..., total_input_tokens: _Optional[int] = ..., total_output_tokens: _Optional[int] = ..., total_tasks: _Optional[int] = ..., model_breakdown: _Optional[_Iterable[_Union[ModelBreakdown, _Mapping]]] = ..., daily_budget_usd: _Optional[float] = ..., monthly_budget_usd: _Optional[float] = ..., current_month_cost_usd: _Optional[float] = ...) -> None: ...

class DailyUsage(_message.Message):
    __slots__ = ("date", "input_tokens", "output_tokens", "cost_usd", "task_count")
    DATE_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    TASK_COUNT_FIELD_NUMBER: _ClassVar[int]
    date: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    task_count: int
    def __init__(self, date: _Optional[str] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., cost_usd: _Optional[float] = ..., task_count: _Optional[int] = ...) -> None: ...

class ModelBreakdown(_message.Message):
    __slots__ = ("model", "input_tokens", "output_tokens", "cost_usd", "task_count")
    MODEL_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    TASK_COUNT_FIELD_NUMBER: _ClassVar[int]
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    task_count: int
    def __init__(self, model: _Optional[str] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., cost_usd: _Optional[float] = ..., task_count: _Optional[int] = ...) -> None: ...

class GetModelPricingRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetModelPricingResponse(_message.Message):
    __slots__ = ("entries", "default_input_per_million", "default_output_per_million")
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_INPUT_PER_MILLION_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_OUTPUT_PER_MILLION_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedCompositeFieldContainer[ModelPricingEntry]
    default_input_per_million: float
    default_output_per_million: float
    def __init__(self, entries: _Optional[_Iterable[_Union[ModelPricingEntry, _Mapping]]] = ..., default_input_per_million: _Optional[float] = ..., default_output_per_million: _Optional[float] = ...) -> None: ...

class ModelPricingEntry(_message.Message):
    __slots__ = ("model", "input_per_million", "output_per_million", "is_user_override")
    MODEL_FIELD_NUMBER: _ClassVar[int]
    INPUT_PER_MILLION_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_PER_MILLION_FIELD_NUMBER: _ClassVar[int]
    IS_USER_OVERRIDE_FIELD_NUMBER: _ClassVar[int]
    model: str
    input_per_million: float
    output_per_million: float
    is_user_override: bool
    def __init__(self, model: _Optional[str] = ..., input_per_million: _Optional[float] = ..., output_per_million: _Optional[float] = ..., is_user_override: bool = ...) -> None: ...

class SetModelPricingRequest(_message.Message):
    __slots__ = ("entries", "default_input_per_million", "default_output_per_million")
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_INPUT_PER_MILLION_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_OUTPUT_PER_MILLION_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedCompositeFieldContainer[ModelPricingEntry]
    default_input_per_million: float
    default_output_per_million: float
    def __init__(self, entries: _Optional[_Iterable[_Union[ModelPricingEntry, _Mapping]]] = ..., default_input_per_million: _Optional[float] = ..., default_output_per_million: _Optional[float] = ...) -> None: ...

class SetModelPricingResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GoalProto(_message.Message):
    __slots__ = ("goal_id", "agent_name", "title", "description", "acceptance_criteria", "status", "budget_usd", "budget_spent_usd", "workflow_run_id", "cycle_count", "parent_goal_id", "created_by", "created_at", "updated_at", "cognitive_model")
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ACCEPTANCE_CRITERIA_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BUDGET_USD_FIELD_NUMBER: _ClassVar[int]
    BUDGET_SPENT_USD_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    CYCLE_COUNT_FIELD_NUMBER: _ClassVar[int]
    PARENT_GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    COGNITIVE_MODEL_FIELD_NUMBER: _ClassVar[int]
    goal_id: str
    agent_name: str
    title: str
    description: str
    acceptance_criteria: str
    status: str
    budget_usd: float
    budget_spent_usd: float
    workflow_run_id: str
    cycle_count: int
    parent_goal_id: str
    created_by: str
    created_at: str
    updated_at: str
    cognitive_model: str
    def __init__(self, goal_id: _Optional[str] = ..., agent_name: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., acceptance_criteria: _Optional[str] = ..., status: _Optional[str] = ..., budget_usd: _Optional[float] = ..., budget_spent_usd: _Optional[float] = ..., workflow_run_id: _Optional[str] = ..., cycle_count: _Optional[int] = ..., parent_goal_id: _Optional[str] = ..., created_by: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., cognitive_model: _Optional[str] = ...) -> None: ...

class CognitiveIterationProto(_message.Message):
    __slots__ = ("iteration_id", "goal_id", "cycle_number", "stage", "reasoning", "sub_tasks_json", "critique_result", "gap_detected", "gap_description", "human_escalation_id", "human_response", "learnings_extracted", "created_at")
    ITERATION_ID_FIELD_NUMBER: _ClassVar[int]
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    CYCLE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    STAGE_FIELD_NUMBER: _ClassVar[int]
    REASONING_FIELD_NUMBER: _ClassVar[int]
    SUB_TASKS_JSON_FIELD_NUMBER: _ClassVar[int]
    CRITIQUE_RESULT_FIELD_NUMBER: _ClassVar[int]
    GAP_DETECTED_FIELD_NUMBER: _ClassVar[int]
    GAP_DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HUMAN_ESCALATION_ID_FIELD_NUMBER: _ClassVar[int]
    HUMAN_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    LEARNINGS_EXTRACTED_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    iteration_id: str
    goal_id: str
    cycle_number: int
    stage: str
    reasoning: str
    sub_tasks_json: str
    critique_result: str
    gap_detected: bool
    gap_description: str
    human_escalation_id: str
    human_response: str
    learnings_extracted: str
    created_at: str
    def __init__(self, iteration_id: _Optional[str] = ..., goal_id: _Optional[str] = ..., cycle_number: _Optional[int] = ..., stage: _Optional[str] = ..., reasoning: _Optional[str] = ..., sub_tasks_json: _Optional[str] = ..., critique_result: _Optional[str] = ..., gap_detected: bool = ..., gap_description: _Optional[str] = ..., human_escalation_id: _Optional[str] = ..., human_response: _Optional[str] = ..., learnings_extracted: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class AgentCapabilityProto(_message.Message):
    __slots__ = ("agent_name", "capability_tags", "quality_score", "avg_cost_usd", "avg_latency_ms", "task_count", "specialization_depth", "updated_at")
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    CAPABILITY_TAGS_FIELD_NUMBER: _ClassVar[int]
    QUALITY_SCORE_FIELD_NUMBER: _ClassVar[int]
    AVG_COST_USD_FIELD_NUMBER: _ClassVar[int]
    AVG_LATENCY_MS_FIELD_NUMBER: _ClassVar[int]
    TASK_COUNT_FIELD_NUMBER: _ClassVar[int]
    SPECIALIZATION_DEPTH_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    capability_tags: _containers.RepeatedScalarFieldContainer[str]
    quality_score: float
    avg_cost_usd: float
    avg_latency_ms: int
    task_count: int
    specialization_depth: int
    updated_at: str
    def __init__(self, agent_name: _Optional[str] = ..., capability_tags: _Optional[_Iterable[str]] = ..., quality_score: _Optional[float] = ..., avg_cost_usd: _Optional[float] = ..., avg_latency_ms: _Optional[int] = ..., task_count: _Optional[int] = ..., specialization_depth: _Optional[int] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateGoalRequest(_message.Message):
    __slots__ = ("agent_name", "title", "description", "acceptance_criteria", "budget_usd", "parent_goal_id", "cognitive_model")
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ACCEPTANCE_CRITERIA_FIELD_NUMBER: _ClassVar[int]
    BUDGET_USD_FIELD_NUMBER: _ClassVar[int]
    PARENT_GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    COGNITIVE_MODEL_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    title: str
    description: str
    acceptance_criteria: str
    budget_usd: float
    parent_goal_id: str
    cognitive_model: str
    def __init__(self, agent_name: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., acceptance_criteria: _Optional[str] = ..., budget_usd: _Optional[float] = ..., parent_goal_id: _Optional[str] = ..., cognitive_model: _Optional[str] = ...) -> None: ...

class ListGoalsRequest(_message.Message):
    __slots__ = ("agent_name", "status_filter")
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    status_filter: str
    def __init__(self, agent_name: _Optional[str] = ..., status_filter: _Optional[str] = ...) -> None: ...

class ListGoalsResponse(_message.Message):
    __slots__ = ("goals",)
    GOALS_FIELD_NUMBER: _ClassVar[int]
    goals: _containers.RepeatedCompositeFieldContainer[GoalProto]
    def __init__(self, goals: _Optional[_Iterable[_Union[GoalProto, _Mapping]]] = ...) -> None: ...

class GetGoalRequest(_message.Message):
    __slots__ = ("goal_id",)
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    goal_id: str
    def __init__(self, goal_id: _Optional[str] = ...) -> None: ...

class UpdateGoalRequest(_message.Message):
    __slots__ = ("goal_id", "status", "budget_usd")
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BUDGET_USD_FIELD_NUMBER: _ClassVar[int]
    goal_id: str
    status: str
    budget_usd: float
    def __init__(self, goal_id: _Optional[str] = ..., status: _Optional[str] = ..., budget_usd: _Optional[float] = ...) -> None: ...

class AbandonGoalRequest(_message.Message):
    __slots__ = ("goal_id",)
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    goal_id: str
    def __init__(self, goal_id: _Optional[str] = ...) -> None: ...

class ListIterationsRequest(_message.Message):
    __slots__ = ("goal_id", "cycle_number")
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    CYCLE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    goal_id: str
    cycle_number: int
    def __init__(self, goal_id: _Optional[str] = ..., cycle_number: _Optional[int] = ...) -> None: ...

class ListIterationsResponse(_message.Message):
    __slots__ = ("iterations",)
    ITERATIONS_FIELD_NUMBER: _ClassVar[int]
    iterations: _containers.RepeatedCompositeFieldContainer[CognitiveIterationProto]
    def __init__(self, iterations: _Optional[_Iterable[_Union[CognitiveIterationProto, _Mapping]]] = ...) -> None: ...

class EscalationStepProto(_message.Message):
    __slots__ = ("description", "outcome")
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    description: str
    outcome: str
    def __init__(self, description: _Optional[str] = ..., outcome: _Optional[str] = ...) -> None: ...

class EscalationCardProto(_message.Message):
    __slots__ = ("escalation_id", "goal_id", "goal_title", "agent_name", "cycle_number", "stage", "what_was_tried", "gap_description", "formatted_text", "status", "human_response", "created_at", "resolved_at")
    ESCALATION_ID_FIELD_NUMBER: _ClassVar[int]
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    GOAL_TITLE_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    CYCLE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    STAGE_FIELD_NUMBER: _ClassVar[int]
    WHAT_WAS_TRIED_FIELD_NUMBER: _ClassVar[int]
    GAP_DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FORMATTED_TEXT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    HUMAN_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_AT_FIELD_NUMBER: _ClassVar[int]
    escalation_id: str
    goal_id: str
    goal_title: str
    agent_name: str
    cycle_number: int
    stage: str
    what_was_tried: _containers.RepeatedCompositeFieldContainer[EscalationStepProto]
    gap_description: str
    formatted_text: str
    status: str
    human_response: str
    created_at: str
    resolved_at: str
    def __init__(self, escalation_id: _Optional[str] = ..., goal_id: _Optional[str] = ..., goal_title: _Optional[str] = ..., agent_name: _Optional[str] = ..., cycle_number: _Optional[int] = ..., stage: _Optional[str] = ..., what_was_tried: _Optional[_Iterable[_Union[EscalationStepProto, _Mapping]]] = ..., gap_description: _Optional[str] = ..., formatted_text: _Optional[str] = ..., status: _Optional[str] = ..., human_response: _Optional[str] = ..., created_at: _Optional[str] = ..., resolved_at: _Optional[str] = ...) -> None: ...

class ReflectionProto(_message.Message):
    __slots__ = ("reflection_id", "agent_name", "goals_reviewed", "learnings_count", "memory_updated", "learnings_text", "created_at")
    REFLECTION_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    GOALS_REVIEWED_FIELD_NUMBER: _ClassVar[int]
    LEARNINGS_COUNT_FIELD_NUMBER: _ClassVar[int]
    MEMORY_UPDATED_FIELD_NUMBER: _ClassVar[int]
    LEARNINGS_TEXT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    reflection_id: str
    agent_name: str
    goals_reviewed: int
    learnings_count: int
    memory_updated: bool
    learnings_text: str
    created_at: str
    def __init__(self, reflection_id: _Optional[str] = ..., agent_name: _Optional[str] = ..., goals_reviewed: _Optional[int] = ..., learnings_count: _Optional[int] = ..., memory_updated: bool = ..., learnings_text: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class GetEscalationRequest(_message.Message):
    __slots__ = ("escalation_id",)
    ESCALATION_ID_FIELD_NUMBER: _ClassVar[int]
    escalation_id: str
    def __init__(self, escalation_id: _Optional[str] = ...) -> None: ...

class ListEscalationsRequest(_message.Message):
    __slots__ = ("goal_id", "status", "limit")
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    goal_id: str
    status: str
    limit: int
    def __init__(self, goal_id: _Optional[str] = ..., status: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListEscalationsResponse(_message.Message):
    __slots__ = ("escalations",)
    ESCALATIONS_FIELD_NUMBER: _ClassVar[int]
    escalations: _containers.RepeatedCompositeFieldContainer[EscalationCardProto]
    def __init__(self, escalations: _Optional[_Iterable[_Union[EscalationCardProto, _Mapping]]] = ...) -> None: ...

class ResolveEscalationRequest(_message.Message):
    __slots__ = ("escalation_id", "response")
    ESCALATION_ID_FIELD_NUMBER: _ClassVar[int]
    RESPONSE_FIELD_NUMBER: _ClassVar[int]
    escalation_id: str
    response: str
    def __init__(self, escalation_id: _Optional[str] = ..., response: _Optional[str] = ...) -> None: ...

class ListReflectionsRequest(_message.Message):
    __slots__ = ("agent_name", "limit")
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    limit: int
    def __init__(self, agent_name: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListReflectionsResponse(_message.Message):
    __slots__ = ("reflections",)
    REFLECTIONS_FIELD_NUMBER: _ClassVar[int]
    reflections: _containers.RepeatedCompositeFieldContainer[ReflectionProto]
    def __init__(self, reflections: _Optional[_Iterable[_Union[ReflectionProto, _Mapping]]] = ...) -> None: ...

class RunGoalCycleRequest(_message.Message):
    __slots__ = ("goal_id",)
    GOAL_ID_FIELD_NUMBER: _ClassVar[int]
    goal_id: str
    def __init__(self, goal_id: _Optional[str] = ...) -> None: ...

class ListCapabilitiesRequest(_message.Message):
    __slots__ = ("tag_filter",)
    TAG_FILTER_FIELD_NUMBER: _ClassVar[int]
    tag_filter: str
    def __init__(self, tag_filter: _Optional[str] = ...) -> None: ...

class ListCapabilitiesResponse(_message.Message):
    __slots__ = ("capabilities",)
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    capabilities: _containers.RepeatedCompositeFieldContainer[AgentCapabilityProto]
    def __init__(self, capabilities: _Optional[_Iterable[_Union[AgentCapabilityProto, _Mapping]]] = ...) -> None: ...

class GetCapabilityRequest(_message.Message):
    __slots__ = ("agent_name",)
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    def __init__(self, agent_name: _Optional[str] = ...) -> None: ...

class UpdateCapabilityRequest(_message.Message):
    __slots__ = ("capability",)
    CAPABILITY_FIELD_NUMBER: _ClassVar[int]
    capability: AgentCapabilityProto
    def __init__(self, capability: _Optional[_Union[AgentCapabilityProto, _Mapping]] = ...) -> None: ...

class SectorProto(_message.Message):
    __slots__ = ("sector_id", "name", "display_name", "description", "compliance_tags", "system_preamble", "default_skills", "default_mcp_servers", "icon", "sort_order")
    SECTOR_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COMPLIANCE_TAGS_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PREAMBLE_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_SKILLS_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_MCP_SERVERS_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    SORT_ORDER_FIELD_NUMBER: _ClassVar[int]
    sector_id: str
    name: str
    display_name: str
    description: str
    compliance_tags: _containers.RepeatedScalarFieldContainer[str]
    system_preamble: str
    default_skills: _containers.RepeatedScalarFieldContainer[str]
    default_mcp_servers: _containers.RepeatedScalarFieldContainer[str]
    icon: str
    sort_order: int
    def __init__(self, sector_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., compliance_tags: _Optional[_Iterable[str]] = ..., system_preamble: _Optional[str] = ..., default_skills: _Optional[_Iterable[str]] = ..., default_mcp_servers: _Optional[_Iterable[str]] = ..., icon: _Optional[str] = ..., sort_order: _Optional[int] = ...) -> None: ...

class ListSectorsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListSectorsResponse(_message.Message):
    __slots__ = ("sectors",)
    SECTORS_FIELD_NUMBER: _ClassVar[int]
    sectors: _containers.RepeatedCompositeFieldContainer[SectorProto]
    def __init__(self, sectors: _Optional[_Iterable[_Union[SectorProto, _Mapping]]] = ...) -> None: ...

class GetSectorRequest(_message.Message):
    __slots__ = ("name", "sector_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SECTOR_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    sector_id: str
    def __init__(self, name: _Optional[str] = ..., sector_id: _Optional[str] = ...) -> None: ...

class CreateSectorRequest(_message.Message):
    __slots__ = ("name", "display_name", "description", "compliance_tags", "system_preamble", "default_skills", "default_mcp_servers", "icon", "sort_order")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COMPLIANCE_TAGS_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PREAMBLE_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_SKILLS_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_MCP_SERVERS_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    SORT_ORDER_FIELD_NUMBER: _ClassVar[int]
    name: str
    display_name: str
    description: str
    compliance_tags: _containers.RepeatedScalarFieldContainer[str]
    system_preamble: str
    default_skills: _containers.RepeatedScalarFieldContainer[str]
    default_mcp_servers: _containers.RepeatedScalarFieldContainer[str]
    icon: str
    sort_order: int
    def __init__(self, name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., compliance_tags: _Optional[_Iterable[str]] = ..., system_preamble: _Optional[str] = ..., default_skills: _Optional[_Iterable[str]] = ..., default_mcp_servers: _Optional[_Iterable[str]] = ..., icon: _Optional[str] = ..., sort_order: _Optional[int] = ...) -> None: ...

class UpdateSectorRequest(_message.Message):
    __slots__ = ("name", "display_name", "description", "compliance_tags", "system_preamble", "default_skills", "default_mcp_servers", "icon", "sort_order")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COMPLIANCE_TAGS_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_PREAMBLE_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_SKILLS_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_MCP_SERVERS_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    SORT_ORDER_FIELD_NUMBER: _ClassVar[int]
    name: str
    display_name: str
    description: str
    compliance_tags: _containers.RepeatedScalarFieldContainer[str]
    system_preamble: str
    default_skills: _containers.RepeatedScalarFieldContainer[str]
    default_mcp_servers: _containers.RepeatedScalarFieldContainer[str]
    icon: str
    sort_order: int
    def __init__(self, name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., compliance_tags: _Optional[_Iterable[str]] = ..., system_preamble: _Optional[str] = ..., default_skills: _Optional[_Iterable[str]] = ..., default_mcp_servers: _Optional[_Iterable[str]] = ..., icon: _Optional[str] = ..., sort_order: _Optional[int] = ...) -> None: ...

class DeleteSectorRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class DeleteSectorResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class TemplateProto(_message.Message):
    __slots__ = ("template_id", "name", "display_name", "description", "sector_id", "sector_name", "tags", "config_toml", "version", "published", "parent_id", "parameter_schema", "author")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SECTOR_ID_FIELD_NUMBER: _ClassVar[int]
    SECTOR_NAME_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    CONFIG_TOML_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_FIELD_NUMBER: _ClassVar[int]
    PARENT_ID_FIELD_NUMBER: _ClassVar[int]
    PARAMETER_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    AUTHOR_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    name: str
    display_name: str
    description: str
    sector_id: str
    sector_name: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    config_toml: str
    version: int
    published: bool
    parent_id: str
    parameter_schema: str
    author: str
    def __init__(self, template_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., sector_id: _Optional[str] = ..., sector_name: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., config_toml: _Optional[str] = ..., version: _Optional[int] = ..., published: bool = ..., parent_id: _Optional[str] = ..., parameter_schema: _Optional[str] = ..., author: _Optional[str] = ...) -> None: ...

class TemplateSummaryProto(_message.Message):
    __slots__ = ("template_id", "name", "display_name", "description", "sector_name", "tags", "version", "published", "author")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SECTOR_NAME_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_FIELD_NUMBER: _ClassVar[int]
    AUTHOR_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    name: str
    display_name: str
    description: str
    sector_name: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    version: int
    published: bool
    author: str
    def __init__(self, template_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., sector_name: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., version: _Optional[int] = ..., published: bool = ..., author: _Optional[str] = ...) -> None: ...

class ListTemplatesRequest(_message.Message):
    __slots__ = ("sector", "published_only")
    SECTOR_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_ONLY_FIELD_NUMBER: _ClassVar[int]
    sector: str
    published_only: bool
    def __init__(self, sector: _Optional[str] = ..., published_only: bool = ...) -> None: ...

class ListTemplatesResponse(_message.Message):
    __slots__ = ("templates",)
    TEMPLATES_FIELD_NUMBER: _ClassVar[int]
    templates: _containers.RepeatedCompositeFieldContainer[TemplateSummaryProto]
    def __init__(self, templates: _Optional[_Iterable[_Union[TemplateSummaryProto, _Mapping]]] = ...) -> None: ...

class GetTemplateRequest(_message.Message):
    __slots__ = ("name", "template_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    template_id: str
    def __init__(self, name: _Optional[str] = ..., template_id: _Optional[str] = ...) -> None: ...

class CreateTemplateRequest(_message.Message):
    __slots__ = ("name", "display_name", "description", "sector", "tags", "config_toml", "parameter_schema", "author")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SECTOR_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    CONFIG_TOML_FIELD_NUMBER: _ClassVar[int]
    PARAMETER_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    AUTHOR_FIELD_NUMBER: _ClassVar[int]
    name: str
    display_name: str
    description: str
    sector: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    config_toml: str
    parameter_schema: str
    author: str
    def __init__(self, name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., sector: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., config_toml: _Optional[str] = ..., parameter_schema: _Optional[str] = ..., author: _Optional[str] = ...) -> None: ...

class UpdateTemplateRequest(_message.Message):
    __slots__ = ("name", "display_name", "description", "sector", "tags", "config_toml", "parameter_schema", "published", "author")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SECTOR_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    CONFIG_TOML_FIELD_NUMBER: _ClassVar[int]
    PARAMETER_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_FIELD_NUMBER: _ClassVar[int]
    AUTHOR_FIELD_NUMBER: _ClassVar[int]
    name: str
    display_name: str
    description: str
    sector: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    config_toml: str
    parameter_schema: str
    published: bool
    author: str
    def __init__(self, name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., sector: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., config_toml: _Optional[str] = ..., parameter_schema: _Optional[str] = ..., published: bool = ..., author: _Optional[str] = ...) -> None: ...

class DeleteTemplateRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class DeleteTemplateResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class PublishTemplateRequest(_message.Message):
    __slots__ = ("name", "published")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_FIELD_NUMBER: _ClassVar[int]
    name: str
    published: bool
    def __init__(self, name: _Optional[str] = ..., published: bool = ...) -> None: ...

class InstantiateTemplateRequest(_message.Message):
    __slots__ = ("template_name", "agent_name", "parameters")
    TEMPLATE_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    template_name: str
    agent_name: str
    parameters: str
    def __init__(self, template_name: _Optional[str] = ..., agent_name: _Optional[str] = ..., parameters: _Optional[str] = ...) -> None: ...

class InstantiateTemplateResponse(_message.Message):
    __slots__ = ("success", "agent_name", "template_id", "template_version")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_VERSION_FIELD_NUMBER: _ClassVar[int]
    success: bool
    agent_name: str
    template_id: str
    template_version: int
    def __init__(self, success: bool = ..., agent_name: _Optional[str] = ..., template_id: _Optional[str] = ..., template_version: _Optional[int] = ...) -> None: ...

class ListInstantiationsRequest(_message.Message):
    __slots__ = ("template_name",)
    TEMPLATE_NAME_FIELD_NUMBER: _ClassVar[int]
    template_name: str
    def __init__(self, template_name: _Optional[str] = ...) -> None: ...

class InstantiationProto(_message.Message):
    __slots__ = ("agent_name", "template_version", "parameters")
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_VERSION_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    template_version: int
    parameters: str
    def __init__(self, agent_name: _Optional[str] = ..., template_version: _Optional[int] = ..., parameters: _Optional[str] = ...) -> None: ...

class ListInstantiationsResponse(_message.Message):
    __slots__ = ("instantiations",)
    INSTANTIATIONS_FIELD_NUMBER: _ClassVar[int]
    instantiations: _containers.RepeatedCompositeFieldContainer[InstantiationProto]
    def __init__(self, instantiations: _Optional[_Iterable[_Union[InstantiationProto, _Mapping]]] = ...) -> None: ...

class OrganizationProto(_message.Message):
    __slots__ = ("org_id", "name", "display_name", "slug", "description", "plan", "is_active", "settings", "icon")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    PLAN_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    name: str
    display_name: str
    slug: str
    description: str
    plan: str
    is_active: bool
    settings: str
    icon: str
    def __init__(self, org_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., slug: _Optional[str] = ..., description: _Optional[str] = ..., plan: _Optional[str] = ..., is_active: bool = ..., settings: _Optional[str] = ..., icon: _Optional[str] = ...) -> None: ...

class OrgMemberProto(_message.Message):
    __slots__ = ("org_id", "user_id", "role", "username", "display_name")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    user_id: str
    role: str
    username: str
    display_name: str
    def __init__(self, org_id: _Optional[str] = ..., user_id: _Optional[str] = ..., role: _Optional[str] = ..., username: _Optional[str] = ..., display_name: _Optional[str] = ...) -> None: ...

class ListOrganizationsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListOrganizationsResponse(_message.Message):
    __slots__ = ("organizations",)
    ORGANIZATIONS_FIELD_NUMBER: _ClassVar[int]
    organizations: _containers.RepeatedCompositeFieldContainer[OrganizationProto]
    def __init__(self, organizations: _Optional[_Iterable[_Union[OrganizationProto, _Mapping]]] = ...) -> None: ...

class GetOrganizationRequest(_message.Message):
    __slots__ = ("identifier",)
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    identifier: str
    def __init__(self, identifier: _Optional[str] = ...) -> None: ...

class CreateOrganizationRequest(_message.Message):
    __slots__ = ("name", "display_name", "slug", "description", "plan", "icon")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    PLAN_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    name: str
    display_name: str
    slug: str
    description: str
    plan: str
    icon: str
    def __init__(self, name: _Optional[str] = ..., display_name: _Optional[str] = ..., slug: _Optional[str] = ..., description: _Optional[str] = ..., plan: _Optional[str] = ..., icon: _Optional[str] = ...) -> None: ...

class UpdateOrganizationRequest(_message.Message):
    __slots__ = ("org_id", "display_name", "description", "plan", "is_active", "settings", "icon")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    PLAN_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    display_name: str
    description: str
    plan: str
    is_active: bool
    settings: str
    icon: str
    def __init__(self, org_id: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., plan: _Optional[str] = ..., is_active: bool = ..., settings: _Optional[str] = ..., icon: _Optional[str] = ...) -> None: ...

class DeleteOrganizationRequest(_message.Message):
    __slots__ = ("org_id",)
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    def __init__(self, org_id: _Optional[str] = ...) -> None: ...

class DeleteOrganizationResponse(_message.Message):
    __slots__ = ("deleted",)
    DELETED_FIELD_NUMBER: _ClassVar[int]
    deleted: bool
    def __init__(self, deleted: bool = ...) -> None: ...

class ListOrgMembersRequest(_message.Message):
    __slots__ = ("org_id",)
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    def __init__(self, org_id: _Optional[str] = ...) -> None: ...

class ListOrgMembersResponse(_message.Message):
    __slots__ = ("members",)
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    members: _containers.RepeatedCompositeFieldContainer[OrgMemberProto]
    def __init__(self, members: _Optional[_Iterable[_Union[OrgMemberProto, _Mapping]]] = ...) -> None: ...

class AddOrgMemberRequest(_message.Message):
    __slots__ = ("org_id", "user_id", "role")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    user_id: str
    role: str
    def __init__(self, org_id: _Optional[str] = ..., user_id: _Optional[str] = ..., role: _Optional[str] = ...) -> None: ...

class AddOrgMemberResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class RemoveOrgMemberRequest(_message.Message):
    __slots__ = ("org_id", "user_id")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    user_id: str
    def __init__(self, org_id: _Optional[str] = ..., user_id: _Optional[str] = ...) -> None: ...

class RemoveOrgMemberResponse(_message.Message):
    __slots__ = ("removed",)
    REMOVED_FIELD_NUMBER: _ClassVar[int]
    removed: bool
    def __init__(self, removed: bool = ...) -> None: ...

class GetCurrentOrganizationRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetCostAnalyticsRequest(_message.Message):
    __slots__ = ("days", "group_by")
    DAYS_FIELD_NUMBER: _ClassVar[int]
    GROUP_BY_FIELD_NUMBER: _ClassVar[int]
    days: int
    group_by: str
    def __init__(self, days: _Optional[int] = ..., group_by: _Optional[str] = ...) -> None: ...

class GetCostAnalyticsResponse(_message.Message):
    __slots__ = ("totals", "breakdown", "daily_trend")
    TOTALS_FIELD_NUMBER: _ClassVar[int]
    BREAKDOWN_FIELD_NUMBER: _ClassVar[int]
    DAILY_TREND_FIELD_NUMBER: _ClassVar[int]
    totals: OrgCostTotals
    breakdown: _containers.RepeatedCompositeFieldContainer[CostBreakdownEntry]
    daily_trend: _containers.RepeatedCompositeFieldContainer[DailyCostEntry]
    def __init__(self, totals: _Optional[_Union[OrgCostTotals, _Mapping]] = ..., breakdown: _Optional[_Iterable[_Union[CostBreakdownEntry, _Mapping]]] = ..., daily_trend: _Optional[_Iterable[_Union[DailyCostEntry, _Mapping]]] = ...) -> None: ...

class OrgCostTotals(_message.Message):
    __slots__ = ("total_cost_usd", "llm_cost_usd", "tool_cost_usd", "input_tokens", "output_tokens", "task_count")
    TOTAL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    LLM_COST_USD_FIELD_NUMBER: _ClassVar[int]
    TOOL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TASK_COUNT_FIELD_NUMBER: _ClassVar[int]
    total_cost_usd: float
    llm_cost_usd: float
    tool_cost_usd: float
    input_tokens: int
    output_tokens: int
    task_count: int
    def __init__(self, total_cost_usd: _Optional[float] = ..., llm_cost_usd: _Optional[float] = ..., tool_cost_usd: _Optional[float] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., task_count: _Optional[int] = ...) -> None: ...

class CostBreakdownEntry(_message.Message):
    __slots__ = ("dimension", "total_cost_usd", "llm_cost_usd", "tool_cost_usd", "input_tokens", "output_tokens", "task_count")
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    LLM_COST_USD_FIELD_NUMBER: _ClassVar[int]
    TOOL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TASK_COUNT_FIELD_NUMBER: _ClassVar[int]
    dimension: str
    total_cost_usd: float
    llm_cost_usd: float
    tool_cost_usd: float
    input_tokens: int
    output_tokens: int
    task_count: int
    def __init__(self, dimension: _Optional[str] = ..., total_cost_usd: _Optional[float] = ..., llm_cost_usd: _Optional[float] = ..., tool_cost_usd: _Optional[float] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., task_count: _Optional[int] = ...) -> None: ...

class DailyCostEntry(_message.Message):
    __slots__ = ("date", "total_cost_usd", "llm_cost_usd", "tool_cost_usd", "input_tokens", "output_tokens", "task_count")
    DATE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    LLM_COST_USD_FIELD_NUMBER: _ClassVar[int]
    TOOL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TASK_COUNT_FIELD_NUMBER: _ClassVar[int]
    date: str
    total_cost_usd: float
    llm_cost_usd: float
    tool_cost_usd: float
    input_tokens: int
    output_tokens: int
    task_count: int
    def __init__(self, date: _Optional[str] = ..., total_cost_usd: _Optional[float] = ..., llm_cost_usd: _Optional[float] = ..., tool_cost_usd: _Optional[float] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., task_count: _Optional[int] = ...) -> None: ...

class GetUsageLogsRequest(_message.Message):
    __slots__ = ("agent", "event_type", "limit", "offset")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    agent: str
    event_type: str
    limit: int
    offset: int
    def __init__(self, agent: _Optional[str] = ..., event_type: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class GetUsageLogsResponse(_message.Message):
    __slots__ = ("logs",)
    LOGS_FIELD_NUMBER: _ClassVar[int]
    logs: _containers.RepeatedCompositeFieldContainer[UsageLogEntry]
    def __init__(self, logs: _Optional[_Iterable[_Union[UsageLogEntry, _Mapping]]] = ...) -> None: ...

class UsageLogEntry(_message.Message):
    __slots__ = ("log_id", "agent_name", "team_name", "event_type", "task_id", "source", "model", "input_tokens", "output_tokens", "cost_usd", "latency_ms", "tool_name", "success", "error_message", "created_at")
    LOG_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    MODEL_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    LATENCY_MS_FIELD_NUMBER: _ClassVar[int]
    TOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    log_id: str
    agent_name: str
    team_name: str
    event_type: str
    task_id: str
    source: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    latency_ms: int
    tool_name: str
    success: bool
    error_message: str
    created_at: str
    def __init__(self, log_id: _Optional[str] = ..., agent_name: _Optional[str] = ..., team_name: _Optional[str] = ..., event_type: _Optional[str] = ..., task_id: _Optional[str] = ..., source: _Optional[str] = ..., model: _Optional[str] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., cost_usd: _Optional[float] = ..., latency_ms: _Optional[int] = ..., tool_name: _Optional[str] = ..., success: bool = ..., error_message: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class GetPnlAnalyticsRequest(_message.Message):
    __slots__ = ("days", "group_by")
    DAYS_FIELD_NUMBER: _ClassVar[int]
    GROUP_BY_FIELD_NUMBER: _ClassVar[int]
    days: int
    group_by: str
    def __init__(self, days: _Optional[int] = ..., group_by: _Optional[str] = ...) -> None: ...

class GetPnlAnalyticsResponse(_message.Message):
    __slots__ = ("totals", "breakdown", "daily_trend")
    TOTALS_FIELD_NUMBER: _ClassVar[int]
    BREAKDOWN_FIELD_NUMBER: _ClassVar[int]
    DAILY_TREND_FIELD_NUMBER: _ClassVar[int]
    totals: PnlTotals
    breakdown: _containers.RepeatedCompositeFieldContainer[PnlBreakdownEntry]
    daily_trend: _containers.RepeatedCompositeFieldContainer[DailyPnlEntry]
    def __init__(self, totals: _Optional[_Union[PnlTotals, _Mapping]] = ..., breakdown: _Optional[_Iterable[_Union[PnlBreakdownEntry, _Mapping]]] = ..., daily_trend: _Optional[_Iterable[_Union[DailyPnlEntry, _Mapping]]] = ...) -> None: ...

class PnlTotals(_message.Message):
    __slots__ = ("total_revenue_usd", "total_cost_usd", "total_margin_usd", "margin_pct", "input_tokens", "output_tokens", "task_count")
    TOTAL_REVENUE_USD_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    TOTAL_MARGIN_USD_FIELD_NUMBER: _ClassVar[int]
    MARGIN_PCT_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TASK_COUNT_FIELD_NUMBER: _ClassVar[int]
    total_revenue_usd: float
    total_cost_usd: float
    total_margin_usd: float
    margin_pct: float
    input_tokens: int
    output_tokens: int
    task_count: int
    def __init__(self, total_revenue_usd: _Optional[float] = ..., total_cost_usd: _Optional[float] = ..., total_margin_usd: _Optional[float] = ..., margin_pct: _Optional[float] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., task_count: _Optional[int] = ...) -> None: ...

class PnlBreakdownEntry(_message.Message):
    __slots__ = ("dimension", "revenue_usd", "cost_usd", "margin_usd", "margin_pct", "input_tokens", "output_tokens", "task_count")
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    REVENUE_USD_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    MARGIN_USD_FIELD_NUMBER: _ClassVar[int]
    MARGIN_PCT_FIELD_NUMBER: _ClassVar[int]
    INPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TASK_COUNT_FIELD_NUMBER: _ClassVar[int]
    dimension: str
    revenue_usd: float
    cost_usd: float
    margin_usd: float
    margin_pct: float
    input_tokens: int
    output_tokens: int
    task_count: int
    def __init__(self, dimension: _Optional[str] = ..., revenue_usd: _Optional[float] = ..., cost_usd: _Optional[float] = ..., margin_usd: _Optional[float] = ..., margin_pct: _Optional[float] = ..., input_tokens: _Optional[int] = ..., output_tokens: _Optional[int] = ..., task_count: _Optional[int] = ...) -> None: ...

class DailyPnlEntry(_message.Message):
    __slots__ = ("date", "revenue_usd", "cost_usd", "margin_usd", "task_count")
    DATE_FIELD_NUMBER: _ClassVar[int]
    REVENUE_USD_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    MARGIN_USD_FIELD_NUMBER: _ClassVar[int]
    TASK_COUNT_FIELD_NUMBER: _ClassVar[int]
    date: str
    revenue_usd: float
    cost_usd: float
    margin_usd: float
    task_count: int
    def __init__(self, date: _Optional[str] = ..., revenue_usd: _Optional[float] = ..., cost_usd: _Optional[float] = ..., margin_usd: _Optional[float] = ..., task_count: _Optional[int] = ...) -> None: ...

class BillingRuleProto(_message.Message):
    __slots__ = ("rule_id", "org_id", "entity_type", "entity_name", "dimension", "rate", "rate_unit", "is_active", "notes")
    RULE_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_NAME_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    RATE_FIELD_NUMBER: _ClassVar[int]
    RATE_UNIT_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    rule_id: str
    org_id: str
    entity_type: str
    entity_name: str
    dimension: str
    rate: float
    rate_unit: str
    is_active: bool
    notes: str
    def __init__(self, rule_id: _Optional[str] = ..., org_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_name: _Optional[str] = ..., dimension: _Optional[str] = ..., rate: _Optional[float] = ..., rate_unit: _Optional[str] = ..., is_active: bool = ..., notes: _Optional[str] = ...) -> None: ...

class OrgBillingConfigProto(_message.Message):
    __slots__ = ("org_id", "is_free", "billing_notes", "monthly_budget_usd")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    IS_FREE_FIELD_NUMBER: _ClassVar[int]
    BILLING_NOTES_FIELD_NUMBER: _ClassVar[int]
    MONTHLY_BUDGET_USD_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    is_free: bool
    billing_notes: str
    monthly_budget_usd: float
    def __init__(self, org_id: _Optional[str] = ..., is_free: bool = ..., billing_notes: _Optional[str] = ..., monthly_budget_usd: _Optional[float] = ...) -> None: ...

class BillingEventProto(_message.Message):
    __slots__ = ("event_id", "org_id", "rule_id", "dimension", "entity_type", "entity_name", "quantity", "rate", "cost_usd", "revenue_usd", "margin_usd", "task_id", "created_at")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    RULE_ID_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_NAME_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    RATE_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    REVENUE_USD_FIELD_NUMBER: _ClassVar[int]
    MARGIN_USD_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    event_id: str
    org_id: str
    rule_id: str
    dimension: str
    entity_type: str
    entity_name: str
    quantity: float
    rate: float
    cost_usd: float
    revenue_usd: float
    margin_usd: float
    task_id: str
    created_at: str
    def __init__(self, event_id: _Optional[str] = ..., org_id: _Optional[str] = ..., rule_id: _Optional[str] = ..., dimension: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_name: _Optional[str] = ..., quantity: _Optional[float] = ..., rate: _Optional[float] = ..., cost_usd: _Optional[float] = ..., revenue_usd: _Optional[float] = ..., margin_usd: _Optional[float] = ..., task_id: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class ListBillingRulesRequest(_message.Message):
    __slots__ = ("org_id",)
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    def __init__(self, org_id: _Optional[str] = ...) -> None: ...

class ListBillingRulesResponse(_message.Message):
    __slots__ = ("rules",)
    RULES_FIELD_NUMBER: _ClassVar[int]
    rules: _containers.RepeatedCompositeFieldContainer[BillingRuleProto]
    def __init__(self, rules: _Optional[_Iterable[_Union[BillingRuleProto, _Mapping]]] = ...) -> None: ...

class UpsertBillingRuleRequest(_message.Message):
    __slots__ = ("rule",)
    RULE_FIELD_NUMBER: _ClassVar[int]
    rule: BillingRuleProto
    def __init__(self, rule: _Optional[_Union[BillingRuleProto, _Mapping]] = ...) -> None: ...

class UpsertBillingRuleResponse(_message.Message):
    __slots__ = ("rule_id", "success")
    RULE_ID_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    rule_id: str
    success: bool
    def __init__(self, rule_id: _Optional[str] = ..., success: bool = ...) -> None: ...

class DeleteBillingRuleRequest(_message.Message):
    __slots__ = ("rule_id",)
    RULE_ID_FIELD_NUMBER: _ClassVar[int]
    rule_id: str
    def __init__(self, rule_id: _Optional[str] = ...) -> None: ...

class DeleteBillingRuleResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GetOrgBillingConfigRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetOrgBillingConfigResponse(_message.Message):
    __slots__ = ("config",)
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    config: OrgBillingConfigProto
    def __init__(self, config: _Optional[_Union[OrgBillingConfigProto, _Mapping]] = ...) -> None: ...

class SetOrgBillingConfigRequest(_message.Message):
    __slots__ = ("is_free", "billing_notes", "monthly_budget_usd")
    IS_FREE_FIELD_NUMBER: _ClassVar[int]
    BILLING_NOTES_FIELD_NUMBER: _ClassVar[int]
    MONTHLY_BUDGET_USD_FIELD_NUMBER: _ClassVar[int]
    is_free: bool
    billing_notes: str
    monthly_budget_usd: float
    def __init__(self, is_free: bool = ..., billing_notes: _Optional[str] = ..., monthly_budget_usd: _Optional[float] = ...) -> None: ...

class SetOrgBillingConfigResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GetBillingMarginCalcRequest(_message.Message):
    __slots__ = ("days",)
    DAYS_FIELD_NUMBER: _ClassVar[int]
    days: int
    def __init__(self, days: _Optional[int] = ...) -> None: ...

class GetBillingMarginCalcResponse(_message.Message):
    __slots__ = ("total_cost_usd", "total_revenue_usd", "total_margin_usd", "margin_pct", "per_rule")
    TOTAL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    TOTAL_REVENUE_USD_FIELD_NUMBER: _ClassVar[int]
    TOTAL_MARGIN_USD_FIELD_NUMBER: _ClassVar[int]
    MARGIN_PCT_FIELD_NUMBER: _ClassVar[int]
    PER_RULE_FIELD_NUMBER: _ClassVar[int]
    total_cost_usd: float
    total_revenue_usd: float
    total_margin_usd: float
    margin_pct: float
    per_rule: _containers.RepeatedCompositeFieldContainer[RuleMarginEntryProto]
    def __init__(self, total_cost_usd: _Optional[float] = ..., total_revenue_usd: _Optional[float] = ..., total_margin_usd: _Optional[float] = ..., margin_pct: _Optional[float] = ..., per_rule: _Optional[_Iterable[_Union[RuleMarginEntryProto, _Mapping]]] = ...) -> None: ...

class RuleMarginEntryProto(_message.Message):
    __slots__ = ("rule_id", "entity_type", "entity_name", "dimension", "rate", "usage_quantity", "cost_usd", "revenue_usd", "margin_usd")
    RULE_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_NAME_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    RATE_FIELD_NUMBER: _ClassVar[int]
    USAGE_QUANTITY_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    REVENUE_USD_FIELD_NUMBER: _ClassVar[int]
    MARGIN_USD_FIELD_NUMBER: _ClassVar[int]
    rule_id: str
    entity_type: str
    entity_name: str
    dimension: str
    rate: float
    usage_quantity: float
    cost_usd: float
    revenue_usd: float
    margin_usd: float
    def __init__(self, rule_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_name: _Optional[str] = ..., dimension: _Optional[str] = ..., rate: _Optional[float] = ..., usage_quantity: _Optional[float] = ..., cost_usd: _Optional[float] = ..., revenue_usd: _Optional[float] = ..., margin_usd: _Optional[float] = ...) -> None: ...

class ListBillingEventsRequest(_message.Message):
    __slots__ = ("days", "dimension", "entity_type")
    DAYS_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    days: int
    dimension: str
    entity_type: str
    def __init__(self, days: _Optional[int] = ..., dimension: _Optional[str] = ..., entity_type: _Optional[str] = ...) -> None: ...

class ListBillingEventsResponse(_message.Message):
    __slots__ = ("events",)
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[BillingEventProto]
    def __init__(self, events: _Optional[_Iterable[_Union[BillingEventProto, _Mapping]]] = ...) -> None: ...

class InvoiceProto(_message.Message):
    __slots__ = ("invoice_id", "org_id", "period", "status", "base_fee_usd", "agent_seats_usd", "token_revenue_usd", "task_fees_usd", "orchestration_usd", "subtotal_usd", "discount_usd", "total_usd", "total_cost_usd", "margin_usd", "margin_pct", "total_tokens", "total_tasks", "active_agents", "plan_name", "notes", "finalized_at", "created_at", "updated_at")
    INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    PERIOD_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BASE_FEE_USD_FIELD_NUMBER: _ClassVar[int]
    AGENT_SEATS_USD_FIELD_NUMBER: _ClassVar[int]
    TOKEN_REVENUE_USD_FIELD_NUMBER: _ClassVar[int]
    TASK_FEES_USD_FIELD_NUMBER: _ClassVar[int]
    ORCHESTRATION_USD_FIELD_NUMBER: _ClassVar[int]
    SUBTOTAL_USD_FIELD_NUMBER: _ClassVar[int]
    DISCOUNT_USD_FIELD_NUMBER: _ClassVar[int]
    TOTAL_USD_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COST_USD_FIELD_NUMBER: _ClassVar[int]
    MARGIN_USD_FIELD_NUMBER: _ClassVar[int]
    MARGIN_PCT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TOKENS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TASKS_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_AGENTS_FIELD_NUMBER: _ClassVar[int]
    PLAN_NAME_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    FINALIZED_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    invoice_id: str
    org_id: str
    period: str
    status: str
    base_fee_usd: float
    agent_seats_usd: float
    token_revenue_usd: float
    task_fees_usd: float
    orchestration_usd: float
    subtotal_usd: float
    discount_usd: float
    total_usd: float
    total_cost_usd: float
    margin_usd: float
    margin_pct: float
    total_tokens: int
    total_tasks: int
    active_agents: int
    plan_name: str
    notes: str
    finalized_at: str
    created_at: str
    updated_at: str
    def __init__(self, invoice_id: _Optional[str] = ..., org_id: _Optional[str] = ..., period: _Optional[str] = ..., status: _Optional[str] = ..., base_fee_usd: _Optional[float] = ..., agent_seats_usd: _Optional[float] = ..., token_revenue_usd: _Optional[float] = ..., task_fees_usd: _Optional[float] = ..., orchestration_usd: _Optional[float] = ..., subtotal_usd: _Optional[float] = ..., discount_usd: _Optional[float] = ..., total_usd: _Optional[float] = ..., total_cost_usd: _Optional[float] = ..., margin_usd: _Optional[float] = ..., margin_pct: _Optional[float] = ..., total_tokens: _Optional[int] = ..., total_tasks: _Optional[int] = ..., active_agents: _Optional[int] = ..., plan_name: _Optional[str] = ..., notes: _Optional[str] = ..., finalized_at: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class GenerateInvoiceRequest(_message.Message):
    __slots__ = ("period",)
    PERIOD_FIELD_NUMBER: _ClassVar[int]
    period: str
    def __init__(self, period: _Optional[str] = ...) -> None: ...

class GenerateInvoiceResponse(_message.Message):
    __slots__ = ("invoice_id", "invoice")
    INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    INVOICE_FIELD_NUMBER: _ClassVar[int]
    invoice_id: str
    invoice: InvoiceProto
    def __init__(self, invoice_id: _Optional[str] = ..., invoice: _Optional[_Union[InvoiceProto, _Mapping]] = ...) -> None: ...

class GetInvoiceRequest(_message.Message):
    __slots__ = ("invoice_id",)
    INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    invoice_id: str
    def __init__(self, invoice_id: _Optional[str] = ...) -> None: ...

class GetInvoiceResponse(_message.Message):
    __slots__ = ("invoice",)
    INVOICE_FIELD_NUMBER: _ClassVar[int]
    invoice: InvoiceProto
    def __init__(self, invoice: _Optional[_Union[InvoiceProto, _Mapping]] = ...) -> None: ...

class ListInvoicesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListInvoicesResponse(_message.Message):
    __slots__ = ("invoices",)
    INVOICES_FIELD_NUMBER: _ClassVar[int]
    invoices: _containers.RepeatedCompositeFieldContainer[InvoiceProto]
    def __init__(self, invoices: _Optional[_Iterable[_Union[InvoiceProto, _Mapping]]] = ...) -> None: ...

class FinalizeInvoiceRequest(_message.Message):
    __slots__ = ("invoice_id",)
    INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    invoice_id: str
    def __init__(self, invoice_id: _Optional[str] = ...) -> None: ...

class FinalizeInvoiceResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class WorkflowTemplateProto(_message.Message):
    __slots__ = ("template_id", "name", "display_name", "description", "tags", "plan_json", "parameter_schema", "metadata_example", "default_cron", "version", "published_version", "status", "author", "created_at", "updated_at")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PLAN_JSON_FIELD_NUMBER: _ClassVar[int]
    PARAMETER_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    METADATA_EXAMPLE_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_CRON_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PUBLISHED_VERSION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AUTHOR_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    name: str
    display_name: str
    description: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    plan_json: str
    parameter_schema: str
    metadata_example: str
    default_cron: str
    version: int
    published_version: int
    status: str
    author: str
    created_at: str
    updated_at: str
    def __init__(self, template_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., plan_json: _Optional[str] = ..., parameter_schema: _Optional[str] = ..., metadata_example: _Optional[str] = ..., default_cron: _Optional[str] = ..., version: _Optional[int] = ..., published_version: _Optional[int] = ..., status: _Optional[str] = ..., author: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class WorkflowTemplateRunProto(_message.Message):
    __slots__ = ("run_id", "template_id", "template_version", "workstream_id", "parameters", "metadata", "entity_id", "status", "triggered_by", "cron_config_id", "created_at", "completed_at", "template_name")
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_VERSION_FIELD_NUMBER: _ClassVar[int]
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TRIGGERED_BY_FIELD_NUMBER: _ClassVar[int]
    CRON_CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_NAME_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    template_id: str
    template_version: int
    workstream_id: str
    parameters: str
    metadata: str
    entity_id: str
    status: str
    triggered_by: str
    cron_config_id: str
    created_at: str
    completed_at: str
    template_name: str
    def __init__(self, run_id: _Optional[str] = ..., template_id: _Optional[str] = ..., template_version: _Optional[int] = ..., workstream_id: _Optional[str] = ..., parameters: _Optional[str] = ..., metadata: _Optional[str] = ..., entity_id: _Optional[str] = ..., status: _Optional[str] = ..., triggered_by: _Optional[str] = ..., cron_config_id: _Optional[str] = ..., created_at: _Optional[str] = ..., completed_at: _Optional[str] = ..., template_name: _Optional[str] = ...) -> None: ...

class WorkflowTemplateCronProto(_message.Message):
    __slots__ = ("cron_config_id", "template_id", "template_version", "name", "cron_expression", "parameters", "metadata", "entity_id", "enabled", "last_run_at", "next_run_at", "created_at", "template_name", "latest_version")
    CRON_CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_VERSION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CRON_EXPRESSION_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    LAST_RUN_AT_FIELD_NUMBER: _ClassVar[int]
    NEXT_RUN_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_NAME_FIELD_NUMBER: _ClassVar[int]
    LATEST_VERSION_FIELD_NUMBER: _ClassVar[int]
    cron_config_id: str
    template_id: str
    template_version: int
    name: str
    cron_expression: str
    parameters: str
    metadata: str
    entity_id: str
    enabled: bool
    last_run_at: str
    next_run_at: str
    created_at: str
    template_name: str
    latest_version: int
    def __init__(self, cron_config_id: _Optional[str] = ..., template_id: _Optional[str] = ..., template_version: _Optional[int] = ..., name: _Optional[str] = ..., cron_expression: _Optional[str] = ..., parameters: _Optional[str] = ..., metadata: _Optional[str] = ..., entity_id: _Optional[str] = ..., enabled: bool = ..., last_run_at: _Optional[str] = ..., next_run_at: _Optional[str] = ..., created_at: _Optional[str] = ..., template_name: _Optional[str] = ..., latest_version: _Optional[int] = ...) -> None: ...

class WorkflowTemplateStepProto(_message.Message):
    __slots__ = ("step_id", "agent", "team", "instruction", "require_step_completed", "await_signal", "timeout_ms", "max_retries", "delay_after_previous_ms")
    STEP_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    TEAM_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    REQUIRE_STEP_COMPLETED_FIELD_NUMBER: _ClassVar[int]
    AWAIT_SIGNAL_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    MAX_RETRIES_FIELD_NUMBER: _ClassVar[int]
    DELAY_AFTER_PREVIOUS_MS_FIELD_NUMBER: _ClassVar[int]
    step_id: str
    agent: str
    team: str
    instruction: str
    require_step_completed: _containers.RepeatedScalarFieldContainer[str]
    await_signal: str
    timeout_ms: int
    max_retries: int
    delay_after_previous_ms: int
    def __init__(self, step_id: _Optional[str] = ..., agent: _Optional[str] = ..., team: _Optional[str] = ..., instruction: _Optional[str] = ..., require_step_completed: _Optional[_Iterable[str]] = ..., await_signal: _Optional[str] = ..., timeout_ms: _Optional[int] = ..., max_retries: _Optional[int] = ..., delay_after_previous_ms: _Optional[int] = ...) -> None: ...

class CreateWorkflowTemplateRequest(_message.Message):
    __slots__ = ("name", "display_name", "description", "tags", "parameter_schema", "metadata_example", "default_cron", "author", "steps")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PARAMETER_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    METADATA_EXAMPLE_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_CRON_FIELD_NUMBER: _ClassVar[int]
    AUTHOR_FIELD_NUMBER: _ClassVar[int]
    STEPS_FIELD_NUMBER: _ClassVar[int]
    name: str
    display_name: str
    description: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    parameter_schema: str
    metadata_example: str
    default_cron: str
    author: str
    steps: _containers.RepeatedCompositeFieldContainer[WorkflowTemplateStepProto]
    def __init__(self, name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., parameter_schema: _Optional[str] = ..., metadata_example: _Optional[str] = ..., default_cron: _Optional[str] = ..., author: _Optional[str] = ..., steps: _Optional[_Iterable[_Union[WorkflowTemplateStepProto, _Mapping]]] = ...) -> None: ...

class CreateWorkflowTemplateResponse(_message.Message):
    __slots__ = ("template",)
    TEMPLATE_FIELD_NUMBER: _ClassVar[int]
    template: WorkflowTemplateProto
    def __init__(self, template: _Optional[_Union[WorkflowTemplateProto, _Mapping]] = ...) -> None: ...

class GetWorkflowTemplateRequest(_message.Message):
    __slots__ = ("template_id",)
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    def __init__(self, template_id: _Optional[str] = ...) -> None: ...

class GetWorkflowTemplateResponse(_message.Message):
    __slots__ = ("template",)
    TEMPLATE_FIELD_NUMBER: _ClassVar[int]
    template: WorkflowTemplateProto
    def __init__(self, template: _Optional[_Union[WorkflowTemplateProto, _Mapping]] = ...) -> None: ...

class ListWorkflowTemplatesRequest(_message.Message):
    __slots__ = ("status_filter",)
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    status_filter: str
    def __init__(self, status_filter: _Optional[str] = ...) -> None: ...

class ListWorkflowTemplatesResponse(_message.Message):
    __slots__ = ("templates",)
    TEMPLATES_FIELD_NUMBER: _ClassVar[int]
    templates: _containers.RepeatedCompositeFieldContainer[WorkflowTemplateProto]
    def __init__(self, templates: _Optional[_Iterable[_Union[WorkflowTemplateProto, _Mapping]]] = ...) -> None: ...

class UpdateWorkflowTemplateRequest(_message.Message):
    __slots__ = ("template_id", "display_name", "description", "tags", "parameter_schema", "metadata_example", "default_cron", "plan_json")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PARAMETER_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    METADATA_EXAMPLE_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_CRON_FIELD_NUMBER: _ClassVar[int]
    PLAN_JSON_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    display_name: str
    description: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    parameter_schema: str
    metadata_example: str
    default_cron: str
    plan_json: str
    def __init__(self, template_id: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., parameter_schema: _Optional[str] = ..., metadata_example: _Optional[str] = ..., default_cron: _Optional[str] = ..., plan_json: _Optional[str] = ...) -> None: ...

class UpdateWorkflowTemplateResponse(_message.Message):
    __slots__ = ("template",)
    TEMPLATE_FIELD_NUMBER: _ClassVar[int]
    template: WorkflowTemplateProto
    def __init__(self, template: _Optional[_Union[WorkflowTemplateProto, _Mapping]] = ...) -> None: ...

class DeleteWorkflowTemplateRequest(_message.Message):
    __slots__ = ("template_id",)
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    def __init__(self, template_id: _Optional[str] = ...) -> None: ...

class DeleteWorkflowTemplateResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class PublishWorkflowTemplateRequest(_message.Message):
    __slots__ = ("template_id",)
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    def __init__(self, template_id: _Optional[str] = ...) -> None: ...

class PublishWorkflowTemplateResponse(_message.Message):
    __slots__ = ("template",)
    TEMPLATE_FIELD_NUMBER: _ClassVar[int]
    template: WorkflowTemplateProto
    def __init__(self, template: _Optional[_Union[WorkflowTemplateProto, _Mapping]] = ...) -> None: ...

class AddTemplateStepRequest(_message.Message):
    __slots__ = ("template_id", "step")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    step: WorkflowTemplateStepProto
    def __init__(self, template_id: _Optional[str] = ..., step: _Optional[_Union[WorkflowTemplateStepProto, _Mapping]] = ...) -> None: ...

class AddTemplateStepResponse(_message.Message):
    __slots__ = ("template",)
    TEMPLATE_FIELD_NUMBER: _ClassVar[int]
    template: WorkflowTemplateProto
    def __init__(self, template: _Optional[_Union[WorkflowTemplateProto, _Mapping]] = ...) -> None: ...

class UpdateTemplateStepRequest(_message.Message):
    __slots__ = ("template_id", "step_index", "step")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STEP_INDEX_FIELD_NUMBER: _ClassVar[int]
    STEP_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    step_index: int
    step: WorkflowTemplateStepProto
    def __init__(self, template_id: _Optional[str] = ..., step_index: _Optional[int] = ..., step: _Optional[_Union[WorkflowTemplateStepProto, _Mapping]] = ...) -> None: ...

class UpdateTemplateStepResponse(_message.Message):
    __slots__ = ("template",)
    TEMPLATE_FIELD_NUMBER: _ClassVar[int]
    template: WorkflowTemplateProto
    def __init__(self, template: _Optional[_Union[WorkflowTemplateProto, _Mapping]] = ...) -> None: ...

class RemoveTemplateStepRequest(_message.Message):
    __slots__ = ("template_id", "step_index")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STEP_INDEX_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    step_index: int
    def __init__(self, template_id: _Optional[str] = ..., step_index: _Optional[int] = ...) -> None: ...

class RemoveTemplateStepResponse(_message.Message):
    __slots__ = ("template",)
    TEMPLATE_FIELD_NUMBER: _ClassVar[int]
    template: WorkflowTemplateProto
    def __init__(self, template: _Optional[_Union[WorkflowTemplateProto, _Mapping]] = ...) -> None: ...

class RunWorkflowTemplateRequest(_message.Message):
    __slots__ = ("template_id", "parameters", "metadata", "entity_id", "triggered_by")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    TRIGGERED_BY_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    parameters: str
    metadata: str
    entity_id: str
    triggered_by: str
    def __init__(self, template_id: _Optional[str] = ..., parameters: _Optional[str] = ..., metadata: _Optional[str] = ..., entity_id: _Optional[str] = ..., triggered_by: _Optional[str] = ...) -> None: ...

class RunWorkflowTemplateResponse(_message.Message):
    __slots__ = ("run",)
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: WorkflowTemplateRunProto
    def __init__(self, run: _Optional[_Union[WorkflowTemplateRunProto, _Mapping]] = ...) -> None: ...

class ListWorkflowTemplateRunsRequest(_message.Message):
    __slots__ = ("template_id", "status_filter", "triggered_by_filter", "metadata_filter", "limit")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    TRIGGERED_BY_FILTER_FIELD_NUMBER: _ClassVar[int]
    METADATA_FILTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    status_filter: str
    triggered_by_filter: str
    metadata_filter: str
    limit: int
    def __init__(self, template_id: _Optional[str] = ..., status_filter: _Optional[str] = ..., triggered_by_filter: _Optional[str] = ..., metadata_filter: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListWorkflowTemplateRunsResponse(_message.Message):
    __slots__ = ("runs",)
    RUNS_FIELD_NUMBER: _ClassVar[int]
    runs: _containers.RepeatedCompositeFieldContainer[WorkflowTemplateRunProto]
    def __init__(self, runs: _Optional[_Iterable[_Union[WorkflowTemplateRunProto, _Mapping]]] = ...) -> None: ...

class GetWorkflowTemplateRunRequest(_message.Message):
    __slots__ = ("run_id",)
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    def __init__(self, run_id: _Optional[str] = ...) -> None: ...

class GetWorkflowTemplateRunResponse(_message.Message):
    __slots__ = ("run",)
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: WorkflowTemplateRunProto
    def __init__(self, run: _Optional[_Union[WorkflowTemplateRunProto, _Mapping]] = ...) -> None: ...

class CancelWorkflowTemplateRunRequest(_message.Message):
    __slots__ = ("run_id",)
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    def __init__(self, run_id: _Optional[str] = ...) -> None: ...

class CancelWorkflowTemplateRunResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class DeleteWorkflowTemplateRunRequest(_message.Message):
    __slots__ = ("run_id",)
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    run_id: str
    def __init__(self, run_id: _Optional[str] = ...) -> None: ...

class DeleteWorkflowTemplateRunResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class CreateTemplateCronRequest(_message.Message):
    __slots__ = ("template_id", "name", "cron_expression", "parameters", "metadata", "entity_id")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CRON_EXPRESSION_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    name: str
    cron_expression: str
    parameters: str
    metadata: str
    entity_id: str
    def __init__(self, template_id: _Optional[str] = ..., name: _Optional[str] = ..., cron_expression: _Optional[str] = ..., parameters: _Optional[str] = ..., metadata: _Optional[str] = ..., entity_id: _Optional[str] = ...) -> None: ...

class CreateTemplateCronResponse(_message.Message):
    __slots__ = ("cron",)
    CRON_FIELD_NUMBER: _ClassVar[int]
    cron: WorkflowTemplateCronProto
    def __init__(self, cron: _Optional[_Union[WorkflowTemplateCronProto, _Mapping]] = ...) -> None: ...

class ListTemplateCronsRequest(_message.Message):
    __slots__ = ("template_id",)
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    def __init__(self, template_id: _Optional[str] = ...) -> None: ...

class ListTemplateCronsResponse(_message.Message):
    __slots__ = ("crons",)
    CRONS_FIELD_NUMBER: _ClassVar[int]
    crons: _containers.RepeatedCompositeFieldContainer[WorkflowTemplateCronProto]
    def __init__(self, crons: _Optional[_Iterable[_Union[WorkflowTemplateCronProto, _Mapping]]] = ...) -> None: ...

class UpdateTemplateCronRequest(_message.Message):
    __slots__ = ("cron_config_id", "name", "cron_expression", "parameters", "metadata", "entity_id", "enabled")
    CRON_CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CRON_EXPRESSION_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    cron_config_id: str
    name: str
    cron_expression: str
    parameters: str
    metadata: str
    entity_id: str
    enabled: bool
    def __init__(self, cron_config_id: _Optional[str] = ..., name: _Optional[str] = ..., cron_expression: _Optional[str] = ..., parameters: _Optional[str] = ..., metadata: _Optional[str] = ..., entity_id: _Optional[str] = ..., enabled: bool = ...) -> None: ...

class UpdateTemplateCronResponse(_message.Message):
    __slots__ = ("cron",)
    CRON_FIELD_NUMBER: _ClassVar[int]
    cron: WorkflowTemplateCronProto
    def __init__(self, cron: _Optional[_Union[WorkflowTemplateCronProto, _Mapping]] = ...) -> None: ...

class DeleteTemplateCronRequest(_message.Message):
    __slots__ = ("cron_config_id",)
    CRON_CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
    cron_config_id: str
    def __init__(self, cron_config_id: _Optional[str] = ...) -> None: ...

class DeleteTemplateCronResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class UpgradeTemplateCronVersionRequest(_message.Message):
    __slots__ = ("cron_config_id", "target_version")
    CRON_CONFIG_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_VERSION_FIELD_NUMBER: _ClassVar[int]
    cron_config_id: str
    target_version: int
    def __init__(self, cron_config_id: _Optional[str] = ..., target_version: _Optional[int] = ...) -> None: ...

class UpgradeTemplateCronVersionResponse(_message.Message):
    __slots__ = ("cron",)
    CRON_FIELD_NUMBER: _ClassVar[int]
    cron: WorkflowTemplateCronProto
    def __init__(self, cron: _Optional[_Union[WorkflowTemplateCronProto, _Mapping]] = ...) -> None: ...

class TopicRuleProto(_message.Message):
    __slots__ = ("action", "topic")
    ACTION_FIELD_NUMBER: _ClassVar[int]
    TOPIC_FIELD_NUMBER: _ClassVar[int]
    action: str
    topic: str
    def __init__(self, action: _Optional[str] = ..., topic: _Optional[str] = ...) -> None: ...

class GuardrailProto(_message.Message):
    __slots__ = ("entity_type", "entity_id", "topic_rules", "prompt_injection", "updated_at")
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    TOPIC_RULES_FIELD_NUMBER: _ClassVar[int]
    PROMPT_INJECTION_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    entity_type: str
    entity_id: str
    topic_rules: _containers.RepeatedCompositeFieldContainer[TopicRuleProto]
    prompt_injection: str
    updated_at: str
    def __init__(self, entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., topic_rules: _Optional[_Iterable[_Union[TopicRuleProto, _Mapping]]] = ..., prompt_injection: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class GetGuardrailRequest(_message.Message):
    __slots__ = ("entity_type", "entity_id")
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    entity_type: str
    entity_id: str
    def __init__(self, entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ...) -> None: ...

class GetGuardrailResponse(_message.Message):
    __slots__ = ("guardrail", "found")
    GUARDRAIL_FIELD_NUMBER: _ClassVar[int]
    FOUND_FIELD_NUMBER: _ClassVar[int]
    guardrail: GuardrailProto
    found: bool
    def __init__(self, guardrail: _Optional[_Union[GuardrailProto, _Mapping]] = ..., found: bool = ...) -> None: ...

class UpsertGuardrailRequest(_message.Message):
    __slots__ = ("guardrail",)
    GUARDRAIL_FIELD_NUMBER: _ClassVar[int]
    guardrail: GuardrailProto
    def __init__(self, guardrail: _Optional[_Union[GuardrailProto, _Mapping]] = ...) -> None: ...

class UpsertGuardrailResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class DeleteGuardrailRequest(_message.Message):
    __slots__ = ("entity_type", "entity_id")
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    entity_type: str
    entity_id: str
    def __init__(self, entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ...) -> None: ...

class DeleteGuardrailResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class KanbanColumn(_message.Message):
    __slots__ = ("id", "name", "column_type", "wip_limit", "system")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    COLUMN_TYPE_FIELD_NUMBER: _ClassVar[int]
    WIP_LIMIT_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    column_type: str
    wip_limit: int
    system: bool
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., column_type: _Optional[str] = ..., wip_limit: _Optional[int] = ..., system: bool = ...) -> None: ...

class KanbanBoard(_message.Message):
    __slots__ = ("board_id", "workstream_id", "name", "description", "columns", "team_name", "template_id", "status", "created_by", "created_at", "updated_at", "cards")
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    CARDS_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    workstream_id: str
    name: str
    description: str
    columns: _containers.RepeatedCompositeFieldContainer[KanbanColumn]
    team_name: str
    template_id: str
    status: str
    created_by: str
    created_at: str
    updated_at: str
    cards: _containers.RepeatedCompositeFieldContainer[KanbanCard]
    def __init__(self, board_id: _Optional[str] = ..., workstream_id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., columns: _Optional[_Iterable[_Union[KanbanColumn, _Mapping]]] = ..., team_name: _Optional[str] = ..., template_id: _Optional[str] = ..., status: _Optional[str] = ..., created_by: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., cards: _Optional[_Iterable[_Union[KanbanCard, _Mapping]]] = ...) -> None: ...

class KanbanCard(_message.Message):
    __slots__ = ("card_id", "board_id", "task_id", "column_id", "position", "title", "description", "instruction", "agent_name", "team_name", "labels", "color", "priority", "step_type", "step_config", "depends_on", "cost_usd", "started_at", "completed_at", "duration_ms", "output_summary", "error_message", "created_at_ts", "output_full", "status")
    CARD_ID_FIELD_NUMBER: _ClassVar[int]
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    COLUMN_ID_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    STEP_TYPE_FIELD_NUMBER: _ClassVar[int]
    STEP_CONFIG_FIELD_NUMBER: _ClassVar[int]
    DEPENDS_ON_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_TS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FULL_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    card_id: str
    board_id: str
    task_id: str
    column_id: str
    position: int
    title: str
    description: str
    instruction: str
    agent_name: str
    team_name: str
    labels: _containers.RepeatedScalarFieldContainer[str]
    color: str
    priority: int
    step_type: str
    step_config: str
    depends_on: _containers.RepeatedScalarFieldContainer[str]
    cost_usd: float
    started_at: str
    completed_at: str
    duration_ms: int
    output_summary: str
    error_message: str
    created_at_ts: str
    output_full: str
    status: str
    def __init__(self, card_id: _Optional[str] = ..., board_id: _Optional[str] = ..., task_id: _Optional[str] = ..., column_id: _Optional[str] = ..., position: _Optional[int] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., instruction: _Optional[str] = ..., agent_name: _Optional[str] = ..., team_name: _Optional[str] = ..., labels: _Optional[_Iterable[str]] = ..., color: _Optional[str] = ..., priority: _Optional[int] = ..., step_type: _Optional[str] = ..., step_config: _Optional[str] = ..., depends_on: _Optional[_Iterable[str]] = ..., cost_usd: _Optional[float] = ..., started_at: _Optional[str] = ..., completed_at: _Optional[str] = ..., duration_ms: _Optional[int] = ..., output_summary: _Optional[str] = ..., error_message: _Optional[str] = ..., created_at_ts: _Optional[str] = ..., output_full: _Optional[str] = ..., status: _Optional[str] = ...) -> None: ...

class CreateBoardRequest(_message.Message):
    __slots__ = ("name", "description", "columns", "team_name")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    description: str
    columns: _containers.RepeatedCompositeFieldContainer[KanbanColumn]
    team_name: str
    def __init__(self, name: _Optional[str] = ..., description: _Optional[str] = ..., columns: _Optional[_Iterable[_Union[KanbanColumn, _Mapping]]] = ..., team_name: _Optional[str] = ...) -> None: ...

class CreateBoardResponse(_message.Message):
    __slots__ = ("board",)
    BOARD_FIELD_NUMBER: _ClassVar[int]
    board: KanbanBoard
    def __init__(self, board: _Optional[_Union[KanbanBoard, _Mapping]] = ...) -> None: ...

class ListBoardsRequest(_message.Message):
    __slots__ = ("status_filter", "limit")
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    status_filter: str
    limit: int
    def __init__(self, status_filter: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListBoardsResponse(_message.Message):
    __slots__ = ("boards",)
    BOARDS_FIELD_NUMBER: _ClassVar[int]
    boards: _containers.RepeatedCompositeFieldContainer[KanbanBoard]
    def __init__(self, boards: _Optional[_Iterable[_Union[KanbanBoard, _Mapping]]] = ...) -> None: ...

class GetBoardRequest(_message.Message):
    __slots__ = ("board_id",)
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    def __init__(self, board_id: _Optional[str] = ...) -> None: ...

class GetBoardResponse(_message.Message):
    __slots__ = ("board",)
    BOARD_FIELD_NUMBER: _ClassVar[int]
    board: KanbanBoard
    def __init__(self, board: _Optional[_Union[KanbanBoard, _Mapping]] = ...) -> None: ...

class UpdateBoardRequest(_message.Message):
    __slots__ = ("board_id", "name", "description", "columns", "status")
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    name: str
    description: str
    columns: _containers.RepeatedCompositeFieldContainer[KanbanColumn]
    status: str
    def __init__(self, board_id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., columns: _Optional[_Iterable[_Union[KanbanColumn, _Mapping]]] = ..., status: _Optional[str] = ...) -> None: ...

class UpdateBoardResponse(_message.Message):
    __slots__ = ("board",)
    BOARD_FIELD_NUMBER: _ClassVar[int]
    board: KanbanBoard
    def __init__(self, board: _Optional[_Union[KanbanBoard, _Mapping]] = ...) -> None: ...

class DeleteBoardRequest(_message.Message):
    __slots__ = ("board_id",)
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    def __init__(self, board_id: _Optional[str] = ...) -> None: ...

class DeleteBoardResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class CreateCardRequest(_message.Message):
    __slots__ = ("board_id", "title", "description", "instruction", "column_id", "agent_name", "step_type", "step_config", "labels", "priority", "depends_on", "team_name")
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    COLUMN_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    STEP_TYPE_FIELD_NUMBER: _ClassVar[int]
    STEP_CONFIG_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    DEPENDS_ON_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    title: str
    description: str
    instruction: str
    column_id: str
    agent_name: str
    step_type: str
    step_config: str
    labels: _containers.RepeatedScalarFieldContainer[str]
    priority: int
    depends_on: _containers.RepeatedScalarFieldContainer[str]
    team_name: str
    def __init__(self, board_id: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., instruction: _Optional[str] = ..., column_id: _Optional[str] = ..., agent_name: _Optional[str] = ..., step_type: _Optional[str] = ..., step_config: _Optional[str] = ..., labels: _Optional[_Iterable[str]] = ..., priority: _Optional[int] = ..., depends_on: _Optional[_Iterable[str]] = ..., team_name: _Optional[str] = ...) -> None: ...

class CreateCardResponse(_message.Message):
    __slots__ = ("card",)
    CARD_FIELD_NUMBER: _ClassVar[int]
    card: KanbanCard
    def __init__(self, card: _Optional[_Union[KanbanCard, _Mapping]] = ...) -> None: ...

class UpdateCardRequest(_message.Message):
    __slots__ = ("card_id", "title", "description", "instruction", "agent_name", "priority", "labels", "output_summary", "error_message", "team_name", "depends_on")
    CARD_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    INSTRUCTION_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    TEAM_NAME_FIELD_NUMBER: _ClassVar[int]
    DEPENDS_ON_FIELD_NUMBER: _ClassVar[int]
    card_id: str
    title: str
    description: str
    instruction: str
    agent_name: str
    priority: int
    labels: _containers.RepeatedScalarFieldContainer[str]
    output_summary: str
    error_message: str
    team_name: str
    depends_on: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, card_id: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., instruction: _Optional[str] = ..., agent_name: _Optional[str] = ..., priority: _Optional[int] = ..., labels: _Optional[_Iterable[str]] = ..., output_summary: _Optional[str] = ..., error_message: _Optional[str] = ..., team_name: _Optional[str] = ..., depends_on: _Optional[_Iterable[str]] = ...) -> None: ...

class UpdateCardResponse(_message.Message):
    __slots__ = ("card",)
    CARD_FIELD_NUMBER: _ClassVar[int]
    card: KanbanCard
    def __init__(self, card: _Optional[_Union[KanbanCard, _Mapping]] = ...) -> None: ...

class MoveCardRequest(_message.Message):
    __slots__ = ("card_id", "target_column_id", "target_position")
    CARD_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_COLUMN_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_POSITION_FIELD_NUMBER: _ClassVar[int]
    card_id: str
    target_column_id: str
    target_position: int
    def __init__(self, card_id: _Optional[str] = ..., target_column_id: _Optional[str] = ..., target_position: _Optional[int] = ...) -> None: ...

class MoveCardResponse(_message.Message):
    __slots__ = ("card",)
    CARD_FIELD_NUMBER: _ClassVar[int]
    card: KanbanCard
    def __init__(self, card: _Optional[_Union[KanbanCard, _Mapping]] = ...) -> None: ...

class DeleteCardRequest(_message.Message):
    __slots__ = ("card_id",)
    CARD_ID_FIELD_NUMBER: _ClassVar[int]
    card_id: str
    def __init__(self, card_id: _Optional[str] = ...) -> None: ...

class DeleteCardResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class CreateBoardFromTemplateRequest(_message.Message):
    __slots__ = ("template_id", "name", "parameters_json")
    TEMPLATE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_JSON_FIELD_NUMBER: _ClassVar[int]
    template_id: str
    name: str
    parameters_json: str
    def __init__(self, template_id: _Optional[str] = ..., name: _Optional[str] = ..., parameters_json: _Optional[str] = ...) -> None: ...

class ExecuteBoardRequest(_message.Message):
    __slots__ = ("board_id",)
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    def __init__(self, board_id: _Optional[str] = ...) -> None: ...

class ExecuteBoardResponse(_message.Message):
    __slots__ = ("workstream_id", "board")
    WORKSTREAM_ID_FIELD_NUMBER: _ClassVar[int]
    BOARD_FIELD_NUMBER: _ClassVar[int]
    workstream_id: str
    board: KanbanBoard
    def __init__(self, workstream_id: _Optional[str] = ..., board: _Optional[_Union[KanbanBoard, _Mapping]] = ...) -> None: ...

class PauseBoardRequest(_message.Message):
    __slots__ = ("board_id",)
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    def __init__(self, board_id: _Optional[str] = ...) -> None: ...

class PauseBoardResponse(_message.Message):
    __slots__ = ("board",)
    BOARD_FIELD_NUMBER: _ClassVar[int]
    board: KanbanBoard
    def __init__(self, board: _Optional[_Union[KanbanBoard, _Mapping]] = ...) -> None: ...

class ResumeBoardRequest(_message.Message):
    __slots__ = ("board_id",)
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    def __init__(self, board_id: _Optional[str] = ...) -> None: ...

class ResumeBoardResponse(_message.Message):
    __slots__ = ("board",)
    BOARD_FIELD_NUMBER: _ClassVar[int]
    board: KanbanBoard
    def __init__(self, board: _Optional[_Union[KanbanBoard, _Mapping]] = ...) -> None: ...

class StopBoardRequest(_message.Message):
    __slots__ = ("board_id",)
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    def __init__(self, board_id: _Optional[str] = ...) -> None: ...

class StopBoardResponse(_message.Message):
    __slots__ = ("board",)
    BOARD_FIELD_NUMBER: _ClassVar[int]
    board: KanbanBoard
    def __init__(self, board: _Optional[_Union[KanbanBoard, _Mapping]] = ...) -> None: ...

class ResetBoardRequest(_message.Message):
    __slots__ = ("board_id",)
    BOARD_ID_FIELD_NUMBER: _ClassVar[int]
    board_id: str
    def __init__(self, board_id: _Optional[str] = ...) -> None: ...

class ResetBoardResponse(_message.Message):
    __slots__ = ("board",)
    BOARD_FIELD_NUMBER: _ClassVar[int]
    board: KanbanBoard
    def __init__(self, board: _Optional[_Union[KanbanBoard, _Mapping]] = ...) -> None: ...

class ListTracesRequest(_message.Message):
    __slots__ = ("type_filter", "status_filter", "limit", "cursor")
    TYPE_FILTER_FIELD_NUMBER: _ClassVar[int]
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    CURSOR_FIELD_NUMBER: _ClassVar[int]
    type_filter: str
    status_filter: str
    limit: int
    cursor: str
    def __init__(self, type_filter: _Optional[str] = ..., status_filter: _Optional[str] = ..., limit: _Optional[int] = ..., cursor: _Optional[str] = ...) -> None: ...

class ListTracesResponse(_message.Message):
    __slots__ = ("traces", "next_cursor")
    TRACES_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    traces: _containers.RepeatedCompositeFieldContainer[TraceProto]
    next_cursor: str
    def __init__(self, traces: _Optional[_Iterable[_Union[TraceProto, _Mapping]]] = ..., next_cursor: _Optional[str] = ...) -> None: ...

class GetTraceRequest(_message.Message):
    __slots__ = ("trace_id",)
    TRACE_ID_FIELD_NUMBER: _ClassVar[int]
    trace_id: str
    def __init__(self, trace_id: _Optional[str] = ...) -> None: ...

class GetTraceResponse(_message.Message):
    __slots__ = ("trace",)
    TRACE_FIELD_NUMBER: _ClassVar[int]
    trace: TraceProto
    def __init__(self, trace: _Optional[_Union[TraceProto, _Mapping]] = ...) -> None: ...

class TraceEvent(_message.Message):
    __slots__ = ("trace_id", "span")
    TRACE_ID_FIELD_NUMBER: _ClassVar[int]
    SPAN_FIELD_NUMBER: _ClassVar[int]
    trace_id: str
    span: SpanProto
    def __init__(self, trace_id: _Optional[str] = ..., span: _Optional[_Union[SpanProto, _Mapping]] = ...) -> None: ...

class TraceProto(_message.Message):
    __slots__ = ("id", "type", "title", "status", "started_at", "duration_ms", "total_cost", "total_tokens", "spans")
    ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COST_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TOKENS_FIELD_NUMBER: _ClassVar[int]
    SPANS_FIELD_NUMBER: _ClassVar[int]
    id: str
    type: str
    title: str
    status: str
    started_at: int
    duration_ms: int
    total_cost: float
    total_tokens: int
    spans: _containers.RepeatedCompositeFieldContainer[SpanProto]
    def __init__(self, id: _Optional[str] = ..., type: _Optional[str] = ..., title: _Optional[str] = ..., status: _Optional[str] = ..., started_at: _Optional[int] = ..., duration_ms: _Optional[int] = ..., total_cost: _Optional[float] = ..., total_tokens: _Optional[int] = ..., spans: _Optional[_Iterable[_Union[SpanProto, _Mapping]]] = ...) -> None: ...

class SpanProto(_message.Message):
    __slots__ = ("id", "parent_id", "kind", "label", "status", "started_at", "duration_ms", "cost_usd", "tokens_in", "tokens_out", "input", "output", "metadata", "children")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    PARENT_ID_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    TOKENS_IN_FIELD_NUMBER: _ClassVar[int]
    TOKENS_OUT_FIELD_NUMBER: _ClassVar[int]
    INPUT_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    CHILDREN_FIELD_NUMBER: _ClassVar[int]
    id: str
    parent_id: str
    kind: str
    label: str
    status: str
    started_at: int
    duration_ms: int
    cost_usd: float
    tokens_in: int
    tokens_out: int
    input: str
    output: str
    metadata: _containers.ScalarMap[str, str]
    children: _containers.RepeatedCompositeFieldContainer[SpanProto]
    def __init__(self, id: _Optional[str] = ..., parent_id: _Optional[str] = ..., kind: _Optional[str] = ..., label: _Optional[str] = ..., status: _Optional[str] = ..., started_at: _Optional[int] = ..., duration_ms: _Optional[int] = ..., cost_usd: _Optional[float] = ..., tokens_in: _Optional[int] = ..., tokens_out: _Optional[int] = ..., input: _Optional[str] = ..., output: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., children: _Optional[_Iterable[_Union[SpanProto, _Mapping]]] = ...) -> None: ...

class DatasetProto(_message.Message):
    __slots__ = ("dataset_id", "org_id", "name", "display_name", "description", "access_level", "created_by", "created_at", "updated_at", "columns")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ACCESS_LEVEL_FIELD_NUMBER: _ClassVar[int]
    CREATED_BY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    org_id: str
    name: str
    display_name: str
    description: str
    access_level: str
    created_by: str
    created_at: str
    updated_at: str
    columns: _containers.RepeatedCompositeFieldContainer[DatasetColumnProto]
    def __init__(self, dataset_id: _Optional[str] = ..., org_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., access_level: _Optional[str] = ..., created_by: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., columns: _Optional[_Iterable[_Union[DatasetColumnProto, _Mapping]]] = ...) -> None: ...

class DatasetColumnProto(_message.Message):
    __slots__ = ("column_id", "name", "data_type", "nullable", "description", "ordinal")
    COLUMN_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NULLABLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ORDINAL_FIELD_NUMBER: _ClassVar[int]
    column_id: str
    name: str
    data_type: str
    nullable: bool
    description: str
    ordinal: int
    def __init__(self, column_id: _Optional[str] = ..., name: _Optional[str] = ..., data_type: _Optional[str] = ..., nullable: bool = ..., description: _Optional[str] = ..., ordinal: _Optional[int] = ...) -> None: ...

class DatasetRowProto(_message.Message):
    __slots__ = ("row_id", "dataset_id", "data_json", "created_at", "updated_at")
    ROW_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    row_id: str
    dataset_id: str
    data_json: str
    created_at: str
    updated_at: str
    def __init__(self, row_id: _Optional[str] = ..., dataset_id: _Optional[str] = ..., data_json: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class DatasetPermissionProto(_message.Message):
    __slots__ = ("permission_id", "dataset_id", "entity_type", "entity_id", "permission")
    PERMISSION_ID_FIELD_NUMBER: _ClassVar[int]
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    PERMISSION_FIELD_NUMBER: _ClassVar[int]
    permission_id: str
    dataset_id: str
    entity_type: str
    entity_id: str
    permission: str
    def __init__(self, permission_id: _Optional[str] = ..., dataset_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., permission: _Optional[str] = ...) -> None: ...

class QueryFilter(_message.Message):
    __slots__ = ("field", "op", "value")
    FIELD_FIELD_NUMBER: _ClassVar[int]
    OP_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    field: str
    op: str
    value: str
    def __init__(self, field: _Optional[str] = ..., op: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class SortSpec(_message.Message):
    __slots__ = ("field", "ascending")
    FIELD_FIELD_NUMBER: _ClassVar[int]
    ASCENDING_FIELD_NUMBER: _ClassVar[int]
    field: str
    ascending: bool
    def __init__(self, field: _Optional[str] = ..., ascending: bool = ...) -> None: ...

class AggregationSpec(_message.Message):
    __slots__ = ("function", "field", "alias", "group_by")
    FUNCTION_FIELD_NUMBER: _ClassVar[int]
    FIELD_FIELD_NUMBER: _ClassVar[int]
    ALIAS_FIELD_NUMBER: _ClassVar[int]
    GROUP_BY_FIELD_NUMBER: _ClassVar[int]
    function: str
    field: str
    alias: str
    group_by: str
    def __init__(self, function: _Optional[str] = ..., field: _Optional[str] = ..., alias: _Optional[str] = ..., group_by: _Optional[str] = ...) -> None: ...

class CreateDatasetRequest(_message.Message):
    __slots__ = ("name", "display_name", "description", "access_level", "columns")
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ACCESS_LEVEL_FIELD_NUMBER: _ClassVar[int]
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    name: str
    display_name: str
    description: str
    access_level: str
    columns: _containers.RepeatedCompositeFieldContainer[DatasetColumnProto]
    def __init__(self, name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., access_level: _Optional[str] = ..., columns: _Optional[_Iterable[_Union[DatasetColumnProto, _Mapping]]] = ...) -> None: ...

class CreateDatasetResponse(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: DatasetProto
    def __init__(self, dataset: _Optional[_Union[DatasetProto, _Mapping]] = ...) -> None: ...

class ListDatasetsRequest(_message.Message):
    __slots__ = ("search", "access_level", "limit", "offset")
    SEARCH_FIELD_NUMBER: _ClassVar[int]
    ACCESS_LEVEL_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    search: str
    access_level: str
    limit: int
    offset: int
    def __init__(self, search: _Optional[str] = ..., access_level: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class ListDatasetsResponse(_message.Message):
    __slots__ = ("datasets", "total")
    DATASETS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    datasets: _containers.RepeatedCompositeFieldContainer[DatasetProto]
    total: int
    def __init__(self, datasets: _Optional[_Iterable[_Union[DatasetProto, _Mapping]]] = ..., total: _Optional[int] = ...) -> None: ...

class GetDatasetRequest(_message.Message):
    __slots__ = ("dataset_id",)
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    def __init__(self, dataset_id: _Optional[str] = ...) -> None: ...

class GetDatasetResponse(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: DatasetProto
    def __init__(self, dataset: _Optional[_Union[DatasetProto, _Mapping]] = ...) -> None: ...

class UpdateDatasetRequest(_message.Message):
    __slots__ = ("dataset_id", "name", "display_name", "description", "access_level")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ACCESS_LEVEL_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    name: str
    display_name: str
    description: str
    access_level: str
    def __init__(self, dataset_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., access_level: _Optional[str] = ...) -> None: ...

class UpdateDatasetResponse(_message.Message):
    __slots__ = ("dataset",)
    DATASET_FIELD_NUMBER: _ClassVar[int]
    dataset: DatasetProto
    def __init__(self, dataset: _Optional[_Union[DatasetProto, _Mapping]] = ...) -> None: ...

class DeleteDatasetRequest(_message.Message):
    __slots__ = ("dataset_id",)
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    def __init__(self, dataset_id: _Optional[str] = ...) -> None: ...

class DeleteDatasetResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class AddColumnRequest(_message.Message):
    __slots__ = ("dataset_id", "name", "data_type", "nullable", "description")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NULLABLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    name: str
    data_type: str
    nullable: bool
    description: str
    def __init__(self, dataset_id: _Optional[str] = ..., name: _Optional[str] = ..., data_type: _Optional[str] = ..., nullable: bool = ..., description: _Optional[str] = ...) -> None: ...

class AddColumnResponse(_message.Message):
    __slots__ = ("column",)
    COLUMN_FIELD_NUMBER: _ClassVar[int]
    column: DatasetColumnProto
    def __init__(self, column: _Optional[_Union[DatasetColumnProto, _Mapping]] = ...) -> None: ...

class RemoveColumnRequest(_message.Message):
    __slots__ = ("dataset_id", "column_name")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    COLUMN_NAME_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    column_name: str
    def __init__(self, dataset_id: _Optional[str] = ..., column_name: _Optional[str] = ...) -> None: ...

class RemoveColumnResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class InsertRowsRequest(_message.Message):
    __slots__ = ("dataset_id", "rows_json")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    ROWS_JSON_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    rows_json: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, dataset_id: _Optional[str] = ..., rows_json: _Optional[_Iterable[str]] = ...) -> None: ...

class InsertRowsResponse(_message.Message):
    __slots__ = ("rows", "inserted_count")
    ROWS_FIELD_NUMBER: _ClassVar[int]
    INSERTED_COUNT_FIELD_NUMBER: _ClassVar[int]
    rows: _containers.RepeatedCompositeFieldContainer[DatasetRowProto]
    inserted_count: int
    def __init__(self, rows: _Optional[_Iterable[_Union[DatasetRowProto, _Mapping]]] = ..., inserted_count: _Optional[int] = ...) -> None: ...

class UpdateRowRequest(_message.Message):
    __slots__ = ("dataset_id", "row_id", "data_json")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    ROW_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    row_id: str
    data_json: str
    def __init__(self, dataset_id: _Optional[str] = ..., row_id: _Optional[str] = ..., data_json: _Optional[str] = ...) -> None: ...

class UpdateRowResponse(_message.Message):
    __slots__ = ("row",)
    ROW_FIELD_NUMBER: _ClassVar[int]
    row: DatasetRowProto
    def __init__(self, row: _Optional[_Union[DatasetRowProto, _Mapping]] = ...) -> None: ...

class DeleteRowRequest(_message.Message):
    __slots__ = ("dataset_id", "row_id")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    ROW_ID_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    row_id: str
    def __init__(self, dataset_id: _Optional[str] = ..., row_id: _Optional[str] = ...) -> None: ...

class DeleteRowResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class QueryDatasetRequest(_message.Message):
    __slots__ = ("dataset_id", "filters", "sorts", "limit", "offset", "aggregations", "select_fields")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    SORTS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    AGGREGATIONS_FIELD_NUMBER: _ClassVar[int]
    SELECT_FIELDS_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    filters: _containers.RepeatedCompositeFieldContainer[QueryFilter]
    sorts: _containers.RepeatedCompositeFieldContainer[SortSpec]
    limit: int
    offset: int
    aggregations: _containers.RepeatedCompositeFieldContainer[AggregationSpec]
    select_fields: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, dataset_id: _Optional[str] = ..., filters: _Optional[_Iterable[_Union[QueryFilter, _Mapping]]] = ..., sorts: _Optional[_Iterable[_Union[SortSpec, _Mapping]]] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., aggregations: _Optional[_Iterable[_Union[AggregationSpec, _Mapping]]] = ..., select_fields: _Optional[_Iterable[str]] = ...) -> None: ...

class QueryDatasetResponse(_message.Message):
    __slots__ = ("rows", "total", "aggregation_results")
    ROWS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    AGGREGATION_RESULTS_FIELD_NUMBER: _ClassVar[int]
    rows: _containers.RepeatedCompositeFieldContainer[DatasetRowProto]
    total: int
    aggregation_results: _containers.RepeatedCompositeFieldContainer[AggregationResult]
    def __init__(self, rows: _Optional[_Iterable[_Union[DatasetRowProto, _Mapping]]] = ..., total: _Optional[int] = ..., aggregation_results: _Optional[_Iterable[_Union[AggregationResult, _Mapping]]] = ...) -> None: ...

class AggregationResult(_message.Message):
    __slots__ = ("alias", "group_value", "value")
    ALIAS_FIELD_NUMBER: _ClassVar[int]
    GROUP_VALUE_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    alias: str
    group_value: str
    value: float
    def __init__(self, alias: _Optional[str] = ..., group_value: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...

class GetDatasetStatsRequest(_message.Message):
    __slots__ = ("dataset_id",)
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    def __init__(self, dataset_id: _Optional[str] = ...) -> None: ...

class GetDatasetStatsResponse(_message.Message):
    __slots__ = ("row_count", "column_count", "last_updated", "storage_bytes")
    ROW_COUNT_FIELD_NUMBER: _ClassVar[int]
    COLUMN_COUNT_FIELD_NUMBER: _ClassVar[int]
    LAST_UPDATED_FIELD_NUMBER: _ClassVar[int]
    STORAGE_BYTES_FIELD_NUMBER: _ClassVar[int]
    row_count: int
    column_count: int
    last_updated: str
    storage_bytes: int
    def __init__(self, row_count: _Optional[int] = ..., column_count: _Optional[int] = ..., last_updated: _Optional[str] = ..., storage_bytes: _Optional[int] = ...) -> None: ...

class SetPermissionRequest(_message.Message):
    __slots__ = ("dataset_id", "entity_type", "entity_id", "permission")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    PERMISSION_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    entity_type: str
    entity_id: str
    permission: str
    def __init__(self, dataset_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., permission: _Optional[str] = ...) -> None: ...

class SetPermissionResponse(_message.Message):
    __slots__ = ("permission",)
    PERMISSION_FIELD_NUMBER: _ClassVar[int]
    permission: DatasetPermissionProto
    def __init__(self, permission: _Optional[_Union[DatasetPermissionProto, _Mapping]] = ...) -> None: ...

class RemovePermissionRequest(_message.Message):
    __slots__ = ("dataset_id", "entity_type", "entity_id")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    entity_type: str
    entity_id: str
    def __init__(self, dataset_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ...) -> None: ...

class RemovePermissionResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ListPermissionsRequest(_message.Message):
    __slots__ = ("dataset_id",)
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    def __init__(self, dataset_id: _Optional[str] = ...) -> None: ...

class ListPermissionsResponse(_message.Message):
    __slots__ = ("permissions",)
    PERMISSIONS_FIELD_NUMBER: _ClassVar[int]
    permissions: _containers.RepeatedCompositeFieldContainer[DatasetPermissionProto]
    def __init__(self, permissions: _Optional[_Iterable[_Union[DatasetPermissionProto, _Mapping]]] = ...) -> None: ...

class ImportCsvRequest(_message.Message):
    __slots__ = ("dataset_id", "csv_data", "has_headers")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    CSV_DATA_FIELD_NUMBER: _ClassVar[int]
    HAS_HEADERS_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    csv_data: str
    has_headers: bool
    def __init__(self, dataset_id: _Optional[str] = ..., csv_data: _Optional[str] = ..., has_headers: bool = ...) -> None: ...

class ImportCsvResponse(_message.Message):
    __slots__ = ("imported_count", "error_count", "errors")
    IMPORTED_COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_COUNT_FIELD_NUMBER: _ClassVar[int]
    ERRORS_FIELD_NUMBER: _ClassVar[int]
    imported_count: int
    error_count: int
    errors: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, imported_count: _Optional[int] = ..., error_count: _Optional[int] = ..., errors: _Optional[_Iterable[str]] = ...) -> None: ...

class CheckAgentAccessRequest(_message.Message):
    __slots__ = ("dataset_id", "agent_name", "permission")
    DATASET_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    PERMISSION_FIELD_NUMBER: _ClassVar[int]
    dataset_id: str
    agent_name: str
    permission: str
    def __init__(self, dataset_id: _Optional[str] = ..., agent_name: _Optional[str] = ..., permission: _Optional[str] = ...) -> None: ...

class CheckAgentAccessResponse(_message.Message):
    __slots__ = ("has_access", "permission")
    HAS_ACCESS_FIELD_NUMBER: _ClassVar[int]
    PERMISSION_FIELD_NUMBER: _ClassVar[int]
    has_access: bool
    permission: str
    def __init__(self, has_access: bool = ..., permission: _Optional[str] = ...) -> None: ...

class ListAgentDatasetsRequest(_message.Message):
    __slots__ = ("agent_name", "permission")
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    PERMISSION_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    permission: str
    def __init__(self, agent_name: _Optional[str] = ..., permission: _Optional[str] = ...) -> None: ...

class ListAgentDatasetsResponse(_message.Message):
    __slots__ = ("permissions",)
    PERMISSIONS_FIELD_NUMBER: _ClassVar[int]
    permissions: _containers.RepeatedCompositeFieldContainer[DatasetPermissionProto]
    def __init__(self, permissions: _Optional[_Iterable[_Union[DatasetPermissionProto, _Mapping]]] = ...) -> None: ...

class TwinTypeProto(_message.Message):
    __slots__ = ("twin_type_id", "org_id", "name", "display_name", "description", "base_agent_name", "coordinator_cfg_json", "workflow_template_ids", "allowed_board_ids", "tools_allowlist", "skill_names", "mcp_server_configs_json", "dataset_ids", "created_at", "updated_at")
    TWIN_TYPE_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    BASE_AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    COORDINATOR_CFG_JSON_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_TEMPLATE_IDS_FIELD_NUMBER: _ClassVar[int]
    ALLOWED_BOARD_IDS_FIELD_NUMBER: _ClassVar[int]
    TOOLS_ALLOWLIST_FIELD_NUMBER: _ClassVar[int]
    SKILL_NAMES_FIELD_NUMBER: _ClassVar[int]
    MCP_SERVER_CONFIGS_JSON_FIELD_NUMBER: _ClassVar[int]
    DATASET_IDS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    twin_type_id: str
    org_id: str
    name: str
    display_name: str
    description: str
    base_agent_name: str
    coordinator_cfg_json: str
    workflow_template_ids: _containers.RepeatedScalarFieldContainer[str]
    allowed_board_ids: _containers.RepeatedScalarFieldContainer[str]
    tools_allowlist: _containers.RepeatedScalarFieldContainer[str]
    skill_names: _containers.RepeatedScalarFieldContainer[str]
    mcp_server_configs_json: str
    dataset_ids: _containers.RepeatedScalarFieldContainer[str]
    created_at: str
    updated_at: str
    def __init__(self, twin_type_id: _Optional[str] = ..., org_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., base_agent_name: _Optional[str] = ..., coordinator_cfg_json: _Optional[str] = ..., workflow_template_ids: _Optional[_Iterable[str]] = ..., allowed_board_ids: _Optional[_Iterable[str]] = ..., tools_allowlist: _Optional[_Iterable[str]] = ..., skill_names: _Optional[_Iterable[str]] = ..., mcp_server_configs_json: _Optional[str] = ..., dataset_ids: _Optional[_Iterable[str]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class TwinProto(_message.Message):
    __slots__ = ("twin_id", "org_id", "twin_type_id", "external_id", "display_name", "metadata_json", "status", "last_event_at", "created_at", "updated_at")
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    TWIN_TYPE_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    METADATA_JSON_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LAST_EVENT_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    org_id: str
    twin_type_id: str
    external_id: str
    display_name: str
    metadata_json: str
    status: str
    last_event_at: str
    created_at: str
    updated_at: str
    def __init__(self, twin_id: _Optional[str] = ..., org_id: _Optional[str] = ..., twin_type_id: _Optional[str] = ..., external_id: _Optional[str] = ..., display_name: _Optional[str] = ..., metadata_json: _Optional[str] = ..., status: _Optional[str] = ..., last_event_at: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class TwinEventProto(_message.Message):
    __slots__ = ("event_id", "twin_id", "source", "event_type", "payload_json", "status", "routing_decision_json", "created_at")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_JSON_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ROUTING_DECISION_JSON_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    event_id: str
    twin_id: str
    source: str
    event_type: str
    payload_json: str
    status: str
    routing_decision_json: str
    created_at: str
    def __init__(self, event_id: _Optional[str] = ..., twin_id: _Optional[str] = ..., source: _Optional[str] = ..., event_type: _Optional[str] = ..., payload_json: _Optional[str] = ..., status: _Optional[str] = ..., routing_decision_json: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class CreateTwinTypeRequest(_message.Message):
    __slots__ = ("org_id", "name", "display_name", "description", "base_agent_name", "coordinator_cfg_json", "mcp_server_configs_json")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    BASE_AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    COORDINATOR_CFG_JSON_FIELD_NUMBER: _ClassVar[int]
    MCP_SERVER_CONFIGS_JSON_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    name: str
    display_name: str
    description: str
    base_agent_name: str
    coordinator_cfg_json: str
    mcp_server_configs_json: str
    def __init__(self, org_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., base_agent_name: _Optional[str] = ..., coordinator_cfg_json: _Optional[str] = ..., mcp_server_configs_json: _Optional[str] = ...) -> None: ...

class GetTwinTypeRequest(_message.Message):
    __slots__ = ("twin_type_id",)
    TWIN_TYPE_ID_FIELD_NUMBER: _ClassVar[int]
    twin_type_id: str
    def __init__(self, twin_type_id: _Optional[str] = ...) -> None: ...

class ListTwinTypesRequest(_message.Message):
    __slots__ = ("org_id",)
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    def __init__(self, org_id: _Optional[str] = ...) -> None: ...

class ListTwinTypesResponse(_message.Message):
    __slots__ = ("twin_types",)
    TWIN_TYPES_FIELD_NUMBER: _ClassVar[int]
    twin_types: _containers.RepeatedCompositeFieldContainer[TwinTypeProto]
    def __init__(self, twin_types: _Optional[_Iterable[_Union[TwinTypeProto, _Mapping]]] = ...) -> None: ...

class UpdateTwinTypeRequest(_message.Message):
    __slots__ = ("twin_type_id", "workflow_template_ids", "allowed_board_ids", "tools_allowlist", "skill_names", "dataset_ids", "mcp_server_configs_json")
    TWIN_TYPE_ID_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_TEMPLATE_IDS_FIELD_NUMBER: _ClassVar[int]
    ALLOWED_BOARD_IDS_FIELD_NUMBER: _ClassVar[int]
    TOOLS_ALLOWLIST_FIELD_NUMBER: _ClassVar[int]
    SKILL_NAMES_FIELD_NUMBER: _ClassVar[int]
    DATASET_IDS_FIELD_NUMBER: _ClassVar[int]
    MCP_SERVER_CONFIGS_JSON_FIELD_NUMBER: _ClassVar[int]
    twin_type_id: str
    workflow_template_ids: _containers.RepeatedScalarFieldContainer[str]
    allowed_board_ids: _containers.RepeatedScalarFieldContainer[str]
    tools_allowlist: _containers.RepeatedScalarFieldContainer[str]
    skill_names: _containers.RepeatedScalarFieldContainer[str]
    dataset_ids: _containers.RepeatedScalarFieldContainer[str]
    mcp_server_configs_json: str
    def __init__(self, twin_type_id: _Optional[str] = ..., workflow_template_ids: _Optional[_Iterable[str]] = ..., allowed_board_ids: _Optional[_Iterable[str]] = ..., tools_allowlist: _Optional[_Iterable[str]] = ..., skill_names: _Optional[_Iterable[str]] = ..., dataset_ids: _Optional[_Iterable[str]] = ..., mcp_server_configs_json: _Optional[str] = ...) -> None: ...

class DeleteTwinTypeRequest(_message.Message):
    __slots__ = ("twin_type_id",)
    TWIN_TYPE_ID_FIELD_NUMBER: _ClassVar[int]
    twin_type_id: str
    def __init__(self, twin_type_id: _Optional[str] = ...) -> None: ...

class DeleteTwinTypeResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class CreateTwinRequest(_message.Message):
    __slots__ = ("org_id", "twin_type_id", "external_id", "display_name", "metadata_json")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    TWIN_TYPE_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    METADATA_JSON_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    twin_type_id: str
    external_id: str
    display_name: str
    metadata_json: str
    def __init__(self, org_id: _Optional[str] = ..., twin_type_id: _Optional[str] = ..., external_id: _Optional[str] = ..., display_name: _Optional[str] = ..., metadata_json: _Optional[str] = ...) -> None: ...

class GetTwinRequest(_message.Message):
    __slots__ = ("twin_id",)
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    def __init__(self, twin_id: _Optional[str] = ...) -> None: ...

class ListTwinsRequest(_message.Message):
    __slots__ = ("org_id", "twin_type_id")
    ORG_ID_FIELD_NUMBER: _ClassVar[int]
    TWIN_TYPE_ID_FIELD_NUMBER: _ClassVar[int]
    org_id: str
    twin_type_id: str
    def __init__(self, org_id: _Optional[str] = ..., twin_type_id: _Optional[str] = ...) -> None: ...

class ListTwinsResponse(_message.Message):
    __slots__ = ("twins",)
    TWINS_FIELD_NUMBER: _ClassVar[int]
    twins: _containers.RepeatedCompositeFieldContainer[TwinProto]
    def __init__(self, twins: _Optional[_Iterable[_Union[TwinProto, _Mapping]]] = ...) -> None: ...

class UpdateTwinRequest(_message.Message):
    __slots__ = ("twin_id", "display_name", "metadata_json")
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    METADATA_JSON_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    display_name: str
    metadata_json: str
    def __init__(self, twin_id: _Optional[str] = ..., display_name: _Optional[str] = ..., metadata_json: _Optional[str] = ...) -> None: ...

class DeleteTwinRequest(_message.Message):
    __slots__ = ("twin_id",)
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    def __init__(self, twin_id: _Optional[str] = ...) -> None: ...

class DeleteTwinResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class SendEventRequest(_message.Message):
    __slots__ = ("twin_id", "event_type", "payload_json", "workflow_template_id_override")
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_JSON_FIELD_NUMBER: _ClassVar[int]
    WORKFLOW_TEMPLATE_ID_OVERRIDE_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    event_type: str
    payload_json: str
    workflow_template_id_override: str
    def __init__(self, twin_id: _Optional[str] = ..., event_type: _Optional[str] = ..., payload_json: _Optional[str] = ..., workflow_template_id_override: _Optional[str] = ...) -> None: ...

class SendEventResponse(_message.Message):
    __slots__ = ("event_id", "routing_decision_json", "response")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    ROUTING_DECISION_JSON_FIELD_NUMBER: _ClassVar[int]
    RESPONSE_FIELD_NUMBER: _ClassVar[int]
    event_id: str
    routing_decision_json: str
    response: str
    def __init__(self, event_id: _Optional[str] = ..., routing_decision_json: _Optional[str] = ..., response: _Optional[str] = ...) -> None: ...

class QueryTwinRequest(_message.Message):
    __slots__ = ("twin_id", "question")
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    QUESTION_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    question: str
    def __init__(self, twin_id: _Optional[str] = ..., question: _Optional[str] = ...) -> None: ...

class QueryTwinResponse(_message.Message):
    __slots__ = ("answer",)
    ANSWER_FIELD_NUMBER: _ClassVar[int]
    answer: str
    def __init__(self, answer: _Optional[str] = ...) -> None: ...

class GetTwinMemoryRequest(_message.Message):
    __slots__ = ("twin_id",)
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    def __init__(self, twin_id: _Optional[str] = ...) -> None: ...

class TwinMemoryProto(_message.Message):
    __slots__ = ("twin_id", "content", "updated_at")
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    content: str
    updated_at: str
    def __init__(self, twin_id: _Optional[str] = ..., content: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class GetTwinHistoryRequest(_message.Message):
    __slots__ = ("twin_id", "session_name")
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_NAME_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    session_name: str
    def __init__(self, twin_id: _Optional[str] = ..., session_name: _Optional[str] = ...) -> None: ...

class TwinHistoryProto(_message.Message):
    __slots__ = ("twin_id", "session_name", "content_json")
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_NAME_FIELD_NUMBER: _ClassVar[int]
    CONTENT_JSON_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    session_name: str
    content_json: str
    def __init__(self, twin_id: _Optional[str] = ..., session_name: _Optional[str] = ..., content_json: _Optional[str] = ...) -> None: ...

class ListTwinEventsRequest(_message.Message):
    __slots__ = ("twin_id", "limit")
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    limit: int
    def __init__(self, twin_id: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListTwinEventsResponse(_message.Message):
    __slots__ = ("events",)
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[TwinEventProto]
    def __init__(self, events: _Optional[_Iterable[_Union[TwinEventProto, _Mapping]]] = ...) -> None: ...

class WatchTwinRequest(_message.Message):
    __slots__ = ("twin_id",)
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    def __init__(self, twin_id: _Optional[str] = ...) -> None: ...

class TwinWatchEvent(_message.Message):
    __slots__ = ("twin_id", "event_type", "payload_json", "timestamp")
    TWIN_ID_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_JSON_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    twin_id: str
    event_type: str
    payload_json: str
    timestamp: str
    def __init__(self, twin_id: _Optional[str] = ..., event_type: _Optional[str] = ..., payload_json: _Optional[str] = ..., timestamp: _Optional[str] = ...) -> None: ...

class Channel(_message.Message):
    __slots__ = ("channel_id", "channel_type", "display_name", "status", "error_detail", "connection_count", "created_at")
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    CHANNEL_TYPE_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ERROR_DETAIL_FIELD_NUMBER: _ClassVar[int]
    CONNECTION_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    channel_type: str
    display_name: str
    status: str
    error_detail: str
    connection_count: int
    created_at: str
    def __init__(self, channel_id: _Optional[str] = ..., channel_type: _Optional[str] = ..., display_name: _Optional[str] = ..., status: _Optional[str] = ..., error_detail: _Optional[str] = ..., connection_count: _Optional[int] = ..., created_at: _Optional[str] = ...) -> None: ...

class CreateChannelRequest(_message.Message):
    __slots__ = ("channel_type", "display_name", "credentials_json")
    CHANNEL_TYPE_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    CREDENTIALS_JSON_FIELD_NUMBER: _ClassVar[int]
    channel_type: str
    display_name: str
    credentials_json: str
    def __init__(self, channel_type: _Optional[str] = ..., display_name: _Optional[str] = ..., credentials_json: _Optional[str] = ...) -> None: ...

class UpdateChannelRequest(_message.Message):
    __slots__ = ("channel_id", "display_name", "credentials_json", "status")
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    CREDENTIALS_JSON_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    display_name: str
    credentials_json: str
    status: str
    def __init__(self, channel_id: _Optional[str] = ..., display_name: _Optional[str] = ..., credentials_json: _Optional[str] = ..., status: _Optional[str] = ...) -> None: ...

class DeleteChannelRequest(_message.Message):
    __slots__ = ("channel_id",)
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    def __init__(self, channel_id: _Optional[str] = ...) -> None: ...

class DeleteChannelResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetChannelRequest(_message.Message):
    __slots__ = ("channel_id",)
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    def __init__(self, channel_id: _Optional[str] = ...) -> None: ...

class ListChannelsRequest(_message.Message):
    __slots__ = ("channel_type",)
    CHANNEL_TYPE_FIELD_NUMBER: _ClassVar[int]
    channel_type: str
    def __init__(self, channel_type: _Optional[str] = ...) -> None: ...

class ListChannelsResponse(_message.Message):
    __slots__ = ("channels",)
    CHANNELS_FIELD_NUMBER: _ClassVar[int]
    channels: _containers.RepeatedCompositeFieldContainer[Channel]
    def __init__(self, channels: _Optional[_Iterable[_Union[Channel, _Mapping]]] = ...) -> None: ...

class TestChannelRequest(_message.Message):
    __slots__ = ("channel_id", "recipient")
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    RECIPIENT_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    recipient: str
    def __init__(self, channel_id: _Optional[str] = ..., recipient: _Optional[str] = ...) -> None: ...

class TestChannelResponse(_message.Message):
    __slots__ = ("ok", "detail")
    OK_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    ok: bool
    detail: str
    def __init__(self, ok: bool = ..., detail: _Optional[str] = ...) -> None: ...

class EntityConnection(_message.Message):
    __slots__ = ("channel_id", "entity_type", "entity_id", "role", "channel_display_name", "entity_display_name")
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    CHANNEL_DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    ENTITY_DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    entity_type: str
    entity_id: str
    role: str
    channel_display_name: str
    entity_display_name: str
    def __init__(self, channel_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., role: _Optional[str] = ..., channel_display_name: _Optional[str] = ..., entity_display_name: _Optional[str] = ...) -> None: ...

class SetEntityConnectionRequest(_message.Message):
    __slots__ = ("channel_id", "entity_type", "entity_id", "role")
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    entity_type: str
    entity_id: str
    role: str
    def __init__(self, channel_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., role: _Optional[str] = ...) -> None: ...

class RemoveEntityConnectionRequest(_message.Message):
    __slots__ = ("channel_id", "entity_type", "entity_id")
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    entity_type: str
    entity_id: str
    def __init__(self, channel_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ...) -> None: ...

class RemoveEntityConnectionResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListEntityConnectionsRequest(_message.Message):
    __slots__ = ("channel_id",)
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    def __init__(self, channel_id: _Optional[str] = ...) -> None: ...

class ListEntityConnectionsResponse(_message.Message):
    __slots__ = ("connections",)
    CONNECTIONS_FIELD_NUMBER: _ClassVar[int]
    connections: _containers.RepeatedCompositeFieldContainer[EntityConnection]
    def __init__(self, connections: _Optional[_Iterable[_Union[EntityConnection, _Mapping]]] = ...) -> None: ...

class ChannelEvent(_message.Message):
    __slots__ = ("event_id", "channel_id", "direction", "entity_type", "entity_id", "status", "summary", "created_at")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    DIRECTION_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    event_id: str
    channel_id: str
    direction: str
    entity_type: str
    entity_id: str
    status: str
    summary: str
    created_at: str
    def __init__(self, event_id: _Optional[str] = ..., channel_id: _Optional[str] = ..., direction: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., status: _Optional[str] = ..., summary: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class ListChannelEventsRequest(_message.Message):
    __slots__ = ("channel_id", "entity_type", "entity_id", "direction", "limit")
    CHANNEL_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    DIRECTION_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    channel_id: str
    entity_type: str
    entity_id: str
    direction: str
    limit: int
    def __init__(self, channel_id: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., direction: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class ListChannelEventsResponse(_message.Message):
    __slots__ = ("events",)
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[ChannelEvent]
    def __init__(self, events: _Optional[_Iterable[_Union[ChannelEvent, _Mapping]]] = ...) -> None: ...
