"""Generated protobuf and gRPC stubs. Do not edit manually."""
