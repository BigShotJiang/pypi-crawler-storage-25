"""gRPC channel creation with auth metadata."""
from __future__ import annotations
import grpc


def create_channel(url: str, api_key: str) -> tuple[grpc.Channel, list[tuple[str, str]]]:
    """Create an insecure gRPC channel and auth metadata tuple."""
    channel = grpc.insecure_channel(url)
    metadata = [("authorization", f"Bearer {api_key}")]
    return channel, metadata


def create_async_channel(url: str, api_key: str) -> tuple[grpc.aio.Channel, list[tuple[str, str]]]:
    """Create an async insecure gRPC channel and auth metadata tuple."""
    channel = grpc.aio.insecure_channel(url)
    metadata = [("authorization", f"Bearer {api_key}")]
    return channel, metadata
