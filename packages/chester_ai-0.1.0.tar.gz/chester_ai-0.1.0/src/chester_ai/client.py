"""Chester AI Python SDK client."""
from __future__ import annotations
import grpc

from chester_ai._gen import chester_pb2_grpc
from chester_ai._interceptors import create_channel, create_async_channel
from chester_ai._services import ServiceWrapper


class ChesterClient:
    """Synchronous client for Chester's gRPC API.

    Args:
        url: Chester daemon host:port (e.g. "localhost:8990")
        api_key: API token (e.g. "cht_abc123...")
    """

    def __init__(self, url: str, api_key: str) -> None:
        if not url:
            raise ValueError("ChesterClient requires a url")
        if not api_key:
            raise ValueError("ChesterClient requires an api_key")

        self._channel, self._metadata = create_channel(url, api_key)
        self._init_services()

    def _init_services(self) -> None:
        m = self._metadata
        ch = self._channel
        self.agents = ServiceWrapper(chester_pb2_grpc.AgentServiceStub(ch), m)
        self.queue = ServiceWrapper(chester_pb2_grpc.QueueServiceStub(ch), m)
        self.decisions = ServiceWrapper(chester_pb2_grpc.DecisionServiceStub(ch), m)
        self.cron = ServiceWrapper(chester_pb2_grpc.CronServiceStub(ch), m)
        self.plans = ServiceWrapper(chester_pb2_grpc.PlanServiceStub(ch), m)
        self.teams = ServiceWrapper(chester_pb2_grpc.TeamServiceStub(ch), m)
        self.skills = ServiceWrapper(chester_pb2_grpc.SkillServiceStub(ch), m)
        self.mcp = ServiceWrapper(chester_pb2_grpc.McpServiceStub(ch), m)
        self.daemon = ServiceWrapper(chester_pb2_grpc.DaemonServiceStub(ch), m)
        self.events = ServiceWrapper(chester_pb2_grpc.EventServiceStub(ch), m)
        self.context = ServiceWrapper(chester_pb2_grpc.ContextServiceStub(ch), m)
        self.tools = ServiceWrapper(chester_pb2_grpc.ToolServiceStub(ch), m)
        self.db = ServiceWrapper(chester_pb2_grpc.DbServiceStub(ch), m)
        self.temporal = ServiceWrapper(chester_pb2_grpc.TemporalServiceStub(ch), m)
        self.auth = ServiceWrapper(chester_pb2_grpc.AuthServiceStub(ch), m)
        self.users = ServiceWrapper(chester_pb2_grpc.UserServiceStub(ch), m)
        self.goals = ServiceWrapper(chester_pb2_grpc.GoalServiceStub(ch), m)
        self.capabilities = ServiceWrapper(chester_pb2_grpc.AgentCapabilityServiceStub(ch), m)
        self.templates = ServiceWrapper(chester_pb2_grpc.TemplateServiceStub(ch), m)
        self.organizations = ServiceWrapper(chester_pb2_grpc.OrganizationServiceStub(ch), m)
        self.workflow_templates = ServiceWrapper(chester_pb2_grpc.WorkflowTemplateServiceStub(ch), m)
        self.guardrails = ServiceWrapper(chester_pb2_grpc.GuardrailServiceStub(ch), m)
        self.kanban = ServiceWrapper(chester_pb2_grpc.KanbanServiceStub(ch), m)
        self.observe = ServiceWrapper(chester_pb2_grpc.ObserveServiceStub(ch), m)
        self.datasets = ServiceWrapper(chester_pb2_grpc.DatasetServiceStub(ch), m)
        self.twins = ServiceWrapper(chester_pb2_grpc.TwinServiceStub(ch), m)
        self.integrations = ServiceWrapper(chester_pb2_grpc.IntegrationServiceStub(ch), m)

    def close(self) -> None:
        self._channel.close()

    def __enter__(self) -> ChesterClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncChesterClient:
    """Async client for Chester's gRPC API."""

    def __init__(self, url: str, api_key: str) -> None:
        if not url:
            raise ValueError("AsyncChesterClient requires a url")
        if not api_key:
            raise ValueError("AsyncChesterClient requires an api_key")

        self._channel, self._metadata = create_async_channel(url, api_key)
        m = self._metadata
        ch = self._channel
        self.agents = ServiceWrapper(chester_pb2_grpc.AgentServiceStub(ch), m)
        self.queue = ServiceWrapper(chester_pb2_grpc.QueueServiceStub(ch), m)
        self.decisions = ServiceWrapper(chester_pb2_grpc.DecisionServiceStub(ch), m)
        self.cron = ServiceWrapper(chester_pb2_grpc.CronServiceStub(ch), m)
        self.plans = ServiceWrapper(chester_pb2_grpc.PlanServiceStub(ch), m)
        self.teams = ServiceWrapper(chester_pb2_grpc.TeamServiceStub(ch), m)
        self.skills = ServiceWrapper(chester_pb2_grpc.SkillServiceStub(ch), m)
        self.mcp = ServiceWrapper(chester_pb2_grpc.McpServiceStub(ch), m)
        self.daemon = ServiceWrapper(chester_pb2_grpc.DaemonServiceStub(ch), m)
        self.events = ServiceWrapper(chester_pb2_grpc.EventServiceStub(ch), m)
        self.context = ServiceWrapper(chester_pb2_grpc.ContextServiceStub(ch), m)
        self.tools = ServiceWrapper(chester_pb2_grpc.ToolServiceStub(ch), m)
        self.db = ServiceWrapper(chester_pb2_grpc.DbServiceStub(ch), m)
        self.temporal = ServiceWrapper(chester_pb2_grpc.TemporalServiceStub(ch), m)
        self.auth = ServiceWrapper(chester_pb2_grpc.AuthServiceStub(ch), m)
        self.users = ServiceWrapper(chester_pb2_grpc.UserServiceStub(ch), m)
        self.goals = ServiceWrapper(chester_pb2_grpc.GoalServiceStub(ch), m)
        self.capabilities = ServiceWrapper(chester_pb2_grpc.AgentCapabilityServiceStub(ch), m)
        self.templates = ServiceWrapper(chester_pb2_grpc.TemplateServiceStub(ch), m)
        self.organizations = ServiceWrapper(chester_pb2_grpc.OrganizationServiceStub(ch), m)
        self.workflow_templates = ServiceWrapper(chester_pb2_grpc.WorkflowTemplateServiceStub(ch), m)
        self.guardrails = ServiceWrapper(chester_pb2_grpc.GuardrailServiceStub(ch), m)
        self.kanban = ServiceWrapper(chester_pb2_grpc.KanbanServiceStub(ch), m)
        self.observe = ServiceWrapper(chester_pb2_grpc.ObserveServiceStub(ch), m)
        self.datasets = ServiceWrapper(chester_pb2_grpc.DatasetServiceStub(ch), m)
        self.twins = ServiceWrapper(chester_pb2_grpc.TwinServiceStub(ch), m)
        self.integrations = ServiceWrapper(chester_pb2_grpc.IntegrationServiceStub(ch), m)

    async def close(self) -> None:
        await self._channel.close()

    async def __aenter__(self) -> AsyncChesterClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
