# chester-ai

Python SDK for the Chester AI agent platform. Full typed access to all 27 gRPC services.

## Install

```bash
pip install chester-ai
# or
uv add chester-ai
```

## Quick Start

```python
from chester_ai import ChesterClient, proto

chester = ChesterClient(url="localhost:8990", api_key="cht_your_api_key_here")

# List all agents
response = chester.agents.ListAgents(proto.ListAgentsRequest())
for agent in response.agents:
    print(agent.name)

# Send a task to an agent
response = chester.queue.SendTask(proto.SendTaskRequest(
    agent="mybot",
    prompt="Summarize today's news",
))
print("Task queued:", response.task_id)

# Stream chat responses
for chunk in chester.agents.ChatWeb(proto.ChatStreamRequest(
    agent="mybot",
    user_message="Hello!",
)):
    print(chunk.content, end="")

# Subscribe to real-time events
for event in chester.events.SubscribeAll(proto.SubscribeAllRequest()):
    print(event.domain, event.event_type)
```

## Async Usage

```python
import asyncio
from chester_ai import AsyncChesterClient, proto

async def main():
    async with AsyncChesterClient(url="localhost:8990", api_key="cht_abc123") as chester:
        response = await chester.agents.ListAgents(proto.ListAgentsRequest())
        for agent in response.agents:
            print(agent.name)

asyncio.run(main())
```

## Authentication

Chester uses Bearer tokens. Create one via the CLI:

```bash
chester auth create-token --name "my-app" --role operator
```

## Services

All 27 Chester services are available as typed properties:

`chester.agents`, `chester.queue`, `chester.decisions`, `chester.cron`,
`chester.plans`, `chester.teams`, `chester.skills`, `chester.mcp`,
`chester.daemon`, `chester.events`, `chester.context`, `chester.tools`,
`chester.db`, `chester.temporal`, `chester.auth`, `chester.users`,
`chester.goals`, `chester.capabilities`, `chester.templates`,
`chester.organizations`, `chester.workflow_templates`, `chester.guardrails`,
`chester.kanban`, `chester.observe`, `chester.datasets`, `chester.twins`,
`chester.integrations`

## Requirements

- Python 3.10+
- Chester daemon running (default port 8990)
