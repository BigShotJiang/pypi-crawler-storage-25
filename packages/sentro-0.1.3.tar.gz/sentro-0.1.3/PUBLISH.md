# PyPI Publishing Checklist

## Status: Ready to publish

Name confirmed available on PyPI: **`sentro`**

---

## What is already done

- [x] Package name `sentro` available on PyPI
- [x] `README.md` written
- [x] `pyproject.toml` complete — author: Solvyx, dev@solvyx.dev
- [x] 91 unit tests passing
- [x] `build` and `twine` installed
- [x] All references updated to `sentro`

---

## Publishing steps

### 1. Create a PyPI account
https://pypi.org/account/register

### 2. Create an API token
https://pypi.org/manage/account/token/

Set scope to "Entire account" for the first upload, then restrict it to the `sentro` project.

### 3. Configure credentials

```bash
# Option A — ~/.pypirc file
[pypi]
  username = __token__
  password = pypi-xxxxxxxxxxxxxxxx

# Option B — env vars (better for CI)
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-xxxxxxxxxxxxxxxx
```

### 4. Build

```bash
cd /home/ckdev/development/sentro
python -m build
# produces:
#   dist/sentro-0.1.0-py3-none-any.whl
#   dist/sentro-0.1.0.tar.gz
```

### 5. Test on TestPyPI first

```bash
twine upload --repository testpypi dist/*
# verify at: https://test.pypi.org/project/sentro/

pip install --index-url https://test.pypi.org/simple/ sentro
sentro --version
sentro install requests --no-install
```

### 6. Upload to PyPI

```bash
twine upload dist/*
```

### 7. Verify live

```bash
pip install sentro
sentro --version
sentro install requests --no-install
```

---

## Bumping the version

When ready to release a new version:

1. Update `pyproject.toml` → `version = "x.x.x"`
2. Update `src/sentro/_version.py` → `__version__ = "x.x.x"`
3. Build and upload again

Current version: `0.1.0`

Before bumping to `1.0.0` consider:
- `requirements.txt` file scanning (`sentro install -r requirements.txt`)
- Broader real-world package testing
- Stable config format

---

## Notes

- `PUBLISH.md` is dev-only — it won't be included in the PyPI distribution
- The GitHub repo should be at `https://github.com/solvyx-dev/sentro` before publishing
