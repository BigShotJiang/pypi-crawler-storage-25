# MACE MCP Server

## Project Overview
A standalone, pip-installable MCP (Model Context Protocol) server that exposes MACE machine learning interatomic potentials to any AI assistant. Researchers use natural language to run atomistic simulations -- energy calculations, geometry optimizations, molecular dynamics, vibrational analysis, and more.

**Author:** Zicheng Zhao, Northeastern University
**Status:** Ready for Implementation (Design v2 complete)
**License:** MIT

## Tech Stack
- **Language:** Python 3.10+
- **MCP SDK:** `mcp[cli]` >= 1.26 (FastMCP high-level API)
- **MCP Protocol:** 2025-06-18 spec (tool annotations, outputSchema, tasks)
- **Transport:** stdio (primary), Streamable HTTP (optional)
- **Schema:** Pydantic v2 (auto JSON Schema for inputSchema + outputSchema)
- **Calculator:** mace-torch >= 0.3.10
- **Atomistic:** ASE >= 3.22
- **Compute:** PyTorch >= 2.0
- **Build:** Hatchling
- **Distribution:** PyPI (`pip install mace-mcp-server`) / `uvx`

## Package Structure
```
mace-mcp-server/
  pyproject.toml
  src/
    mace_mcp_server/
      __init__.py              # Version, package metadata
      server.py                # FastMCP instance, lifespan, entry point
      tools/
        __init__.py
        calculation.py         # single_point, optimize, molecular_dynamics, vibrational_freq
        structure.py           # parse_structure, build_structure, convert_structure
        analysis.py            # equation_of_state, extract_descriptors
        intelligence.py        # suggest_parameters
      resources/
        __init__.py
        models.py              # mace://models, mace://models/{model_id}
        catalog.py             # mace://catalog, mace://catalog/{structure_id}
        reference.py           # mace://units, mace://examples/{type}
      prompts/
        __init__.py
        workflows.py           # analyze_structure, optimize_molecule, md_simulation
      engine/
        __init__.py
        calculator.py          # MACE calculator loading + caching
        runner.py              # Calculation execution (single-point, opt, MD, freq)
        builders.py            # ASE structure builders (molecule, bulk, surface)
        validators.py          # Scientific validation checks
      schemas/
        __init__.py
        inputs.py              # Pydantic input models
        outputs.py             # Pydantic output models (structured results)
  tests/
    test_tools.py
    test_engine.py
    test_resources.py
    conftest.py
```

## Architecture Principles
- **`engine/`** = all scientific logic, testable WITHOUT MCP
- **`tools/`** = thin MCP wrappers over engine functions (validate input, call engine, format output)
- **`schemas/`** = Pydantic models that auto-generate `inputSchema` and `outputSchema`
- **`resources/`** + **`prompts/`** = separate MCP primitives (all 3 primitives used)
- Lifespan-managed model cache (models loaded lazily, cached for reuse)
- Never use global mutable state -- use lifespan context

## MCP Server Patterns

### FastMCP Conventions
- Import from `mcp.server.fastmcp import FastMCP`
- Use `@mcp.tool()` with `ToolAnnotations` (readOnlyHint, destructiveHint, idempotentHint, openWorldHint)
- Use `@mcp.resource("mace://...")` for URI-addressable data
- Use `@mcp.prompt()` for workflow templates returning `list[Message]`
- Use `ctx: Context` for progress reporting: `await ctx.report_progress(current, total, message)`
- Use `await ctx.info(...)` for status messages
- Logging to stderr only (stdout corrupts JSON-RPC in stdio mode)
- Entry point: `mcp.run(transport="stdio")`

### Error Handling
- Every error includes `hint` and `next_action` fields for LLM self-correction
- Use custom `MACEToolError(ToolError)` with structured error messages
- Raise `ToolError` (from `mcp.server.fastmcp.exceptions`) -- NOT raw exceptions
- Categories: model mismatch, D3 double-counting, bad structure, convergence failure, missing periodicity, precision warning, device fallback

### Tool Design
- 10 tools total: 4 calculation, 3 structure, 2 analysis, 1 intelligence
- Keep tool count low (10-12 max) to avoid LLM cognitive overload
- All tools use Pydantic dataclasses for structured output
- Tool annotations mark read-only tools, flag long-running computations

## Scientific Rules (MUST enforce)
- D3 dispersion is NEVER used with MACE-OFF (double-counting wB97M-D3BJ)
- MACE-OFF elements: only H, C, N, O, F, P, S, Cl, Br, I
- MACE-ANI-CC elements: only H, C, N, O
- Vibrational analysis always uses float64 (auto-upgrade if float32)
- NPT only on periodic systems with valid cell
- Default model is MACE-MPA-0 (not MACE-MP-0)
- MACE-OFF defaults to float64 (not float32)
- MD timestep: use `ase.units.fs` for conversion
- MaxwellBoltzmannDistribution must initialize velocities before MD
- PyTorch 2.6+ requires `weights_only=False` for MACE model loading

## Foundation Models (11)
| Model | Loader | Elements | Domain |
|-------|--------|----------|--------|
| MACE-MPA-0 (default) | `mace_mp()` | 89 | Materials |
| MACE-MP-0 | `mace_mp(model="small")` | 89 | Materials (original) |
| MACE-OMAT-0 | `mace_mp(model="small-omat-0")` | 89 | Materials (phonons) |
| MACE-MATPES-PBE-0 | `mace_mp(model="mace-matpes-pbe-0")` | 89 | Materials (PBE) |
| MACE-MATPES-r2SCAN-0 | `mace_mp(model="mace-matpes-r2scan-0")` | 89 | Materials (r2SCAN) |
| MACE-MH-1 | `mace_mp(model="mh-1")` | 89 | Cross-domain (7 heads) |
| MACE-OFF23 | `mace_off()` | 10 | Organic molecules |
| MACE-OMOL-0 | `mace_omol()` | 83 | Molecules + metals |
| MACE-Polar-1 | `mace_polar()` | 83 | Polarizability |
| MACE-ANI-CC | `mace_anicc()` | 4 | CCSD(T) accuracy |
| Custom | `MACECalculator(model_paths=...)` | varies | User-trained |

## Implementation Phases
1. **Phase 1 (Foundation):** server.py + engine/calculator.py + engine/runner.py (single_point) + engine/builders.py + tools/calculation.py (single_point) + tools/structure.py (parse_structure) + tools/intelligence.py (suggest_parameters) + resources + schemas + pyproject.toml
2. **Phase 2 (Full Suite):** optimize, molecular_dynamics, vibrational_freq, build_structure, convert_structure + progress reporting
3. **Phase 3 (Analysis & Polish):** equation_of_state, extract_descriptors, prompts, .mcp.json, README, PyPI release

## Commands
```bash
# Install (dev)
pip install -e ".[dev]"

# Run server
mace-mcp-server                    # stdio transport
python -m mace_mcp_server.server   # alternative

# Test
pytest tests/

# MCP Inspector
npx -y @modelcontextprotocol/inspector mace-mcp-server

# Register with Claude Code
claude mcp add mace -- mace-mcp-server
```

## Key Dependencies
```
mcp[cli]>=1.26.0    # FastMCP SDK
mace-torch>=0.3.10  # MACE models
ase>=3.22.0         # Atomistic simulation
torch>=2.0.0        # PyTorch backend
numpy>=1.24.0       # Numerics
pydantic>=2.0.0     # Schema validation
```

## Anti-patterns to Avoid
- Global mutable state (use lifespan context)
- SSH-only execution (support local first)
- 50+ tools (keep to 10-12 focused tools)
- No error context (always include hints)
- `run_shell_command` (security vulnerability)
- Writing to stdout in stdio mode (corrupts JSON-RPC)
- Mocking the database in tests when engine tests can run directly
