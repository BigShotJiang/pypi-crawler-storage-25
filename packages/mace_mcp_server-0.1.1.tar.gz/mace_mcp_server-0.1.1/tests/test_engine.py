"""Tests for the MACE engine layer -- scientific logic without MCP transport.

These tests validate calculator loading, structure building, validation,
and calculation runners independently of the MCP server.
"""

from __future__ import annotations

import numpy as np
import pytest

from mace_mcp_server.engine.builders import (
    atoms_to_xyz_string,
    build_bulk,
    build_molecule,
    build_surface,
    get_min_distance,
    parse_structure_input,
)
from mace_mcp_server.engine.calculator import (
    MACEToolError,
    _resolve_device,
    _resolve_mp_model_key,
    validate_elements,
)
from mace_mcp_server.engine.validators import (
    validate_periodicity_for_cell_opt,
    validate_periodicity_for_eos,
    validate_periodicity_for_npt,
    validate_precision_for_hessian,
    validate_structure_for_frequencies,
    validate_structure_sanity,
)


# ============================================================
# Builder tests
# ============================================================

class TestBuilders:
    """Test structure builders."""

    def test_build_molecule_water(self):
        atoms = build_molecule("H2O")
        assert len(atoms) == 3
        assert sorted(atoms.get_chemical_symbols()) == ["H", "H", "O"]
        assert not any(atoms.get_pbc())

    def test_build_molecule_methane(self):
        atoms = build_molecule("CH4")
        assert len(atoms) == 5
        assert atoms.get_chemical_formula() == "CH4"

    def test_build_molecule_benzene(self):
        atoms = build_molecule("C6H6")
        assert len(atoms) == 12

    def test_build_bulk_copper(self):
        atoms = build_bulk("Cu", "fcc")
        assert len(atoms) >= 1
        assert all(atoms.get_pbc())
        assert atoms.get_volume() > 0

    def test_build_bulk_silicon(self):
        atoms = build_bulk("Si", "diamond")
        assert all(atoms.get_pbc())
        symbols = atoms.get_chemical_symbols()
        assert all(s == "Si" for s in symbols)

    def test_build_bulk_supercell(self):
        atoms = build_bulk("Cu", "fcc", supercell=[2, 2, 2])
        single = build_bulk("Cu", "fcc")
        assert len(atoms) == len(single) * 8

    def test_build_surface_cu111(self):
        atoms = build_surface("Cu", "fcc", [1, 1, 1], num_layers=3, vacuum=10.0)
        assert len(atoms) >= 3
        # Surfaces have pbc in x,y but vacuum (non-periodic) in z
        assert any(atoms.get_pbc())

    def test_parse_inline_xyz(self, water_xyz):
        atoms = parse_structure_input(water_xyz)
        assert len(atoms) == 3
        assert "O" in atoms.get_chemical_symbols()

    def test_parse_file(self, water_xyz_file):
        atoms = parse_structure_input(water_xyz_file)
        assert len(atoms) == 3

    def test_parse_periodic(self, silicon_xyz):
        atoms = parse_structure_input(silicon_xyz)
        assert len(atoms) == 2
        assert all(atoms.get_pbc())

    def test_parse_invalid_raises(self):
        with pytest.raises(ValueError, match="Cannot parse"):
            parse_structure_input("not_a_file_or_xyz")

    def test_atoms_to_xyz_string(self):
        atoms = build_molecule("H2O")
        xyz = atoms_to_xyz_string(atoms)
        assert "3" in xyz.split("\n")[0]
        assert "O" in xyz
        assert "H" in xyz

    def test_min_distance_normal(self):
        atoms = build_molecule("H2O")
        min_d, overlaps = get_min_distance(atoms)
        assert min_d > 0.5
        assert overlaps == []

    def test_min_distance_single_atom(self):
        from ase import Atoms

        atoms = Atoms("H", positions=[[0, 0, 0]])
        min_d, overlaps = get_min_distance(atoms)
        assert min_d == float("inf")
        assert overlaps == []


# ============================================================
# Calculator tests (no actual MACE loading -- tests mapping logic)
# ============================================================

class TestCalculatorMapping:
    """Test calculator model name resolution."""

    def test_resolve_mp_model_key_mpa(self):
        assert _resolve_mp_model_key("MACE-MPA-0", "medium") == "medium-mpa-0"
        assert _resolve_mp_model_key("MACE-MPA-0", "small") == "small-mpa-0"

    def test_resolve_mp_model_key_mp0(self):
        assert _resolve_mp_model_key("MACE-MP-0", "small") == "small"
        assert _resolve_mp_model_key("MACE-MP-0", "large") == "large"

    def test_resolve_mp_model_key_omat(self):
        assert _resolve_mp_model_key("MACE-OMAT-0", "small") == "small-omat-0"

    def test_resolve_mp_model_key_matpes(self):
        assert _resolve_mp_model_key("MACE-MATPES-PBE-0", "medium") == "mace-matpes-pbe-0"
        assert _resolve_mp_model_key("MACE-MATPES-r2SCAN-0", "medium") == "mace-matpes-r2scan-0"

    def test_resolve_mp_model_key_mh(self):
        assert _resolve_mp_model_key("MACE-MH-1", "large") == "mh-1"

    def test_resolve_mp_model_key_unknown_defaults(self):
        result = _resolve_mp_model_key("UNKNOWN-MODEL", "medium")
        assert result == "medium-mpa-0"

    def test_resolve_device_cpu(self):
        assert _resolve_device("cpu") == "cpu"

    def test_resolve_device_cuda_fallback(self):
        # On machines without CUDA, should fall back to cpu
        result = _resolve_device("cuda")
        assert result in ("cpu", "cuda")


class TestElementValidation:
    """Test element validation for model families."""

    def test_mace_off_valid(self):
        # Should not raise
        validate_elements(["H", "C", "O"], "MACE-OFF")

    def test_mace_off_invalid(self):
        with pytest.raises(MACEToolError, match="does not support"):
            validate_elements(["H", "C", "Fe"], "MACE-OFF")

    def test_mace_off_all_elements(self):
        all_off = ["H", "C", "N", "O", "F", "P", "S", "Cl", "Br", "I"]
        validate_elements(all_off, "MACE-OFF")

    def test_mace_anicc_valid(self):
        validate_elements(["H", "C", "N", "O"], "MACE-ANI-CC")

    def test_mace_anicc_invalid(self):
        with pytest.raises(MACEToolError, match="does not support"):
            validate_elements(["H", "C", "S"], "MACE-ANI-CC")

    def test_mace_mp_no_restriction(self):
        # MP models support 89 elements -- no restriction in our validator
        validate_elements(["Fe", "O", "Si", "H"], "MACE-MPA-0")
        validate_elements(["U", "Pu"], "MACE-MP-0")


# ============================================================
# Validator tests
# ============================================================

class TestValidators:
    """Test scientific validation checks."""

    def test_npt_periodic_ok(self):
        atoms = build_bulk("Cu", "fcc")
        validate_periodicity_for_npt(atoms, "NPT")  # Should not raise

    def test_npt_nonperiodic_raises(self):
        atoms = build_molecule("H2O")
        with pytest.raises(MACEToolError, match="NPT"):
            validate_periodicity_for_npt(atoms, "NPT")

    def test_nvt_nonperiodic_ok(self):
        atoms = build_molecule("H2O")
        validate_periodicity_for_npt(atoms, "NVT")  # Should not raise

    def test_cell_opt_periodic_ok(self):
        atoms = build_bulk("Cu", "fcc")
        validate_periodicity_for_cell_opt(atoms, True)

    def test_cell_opt_nonperiodic_raises(self):
        atoms = build_molecule("H2O")
        with pytest.raises(MACEToolError, match="Cell optimization"):
            validate_periodicity_for_cell_opt(atoms, True)

    def test_cell_opt_false_ok(self):
        atoms = build_molecule("H2O")
        validate_periodicity_for_cell_opt(atoms, False)  # Should not raise

    def test_eos_periodic_ok(self):
        atoms = build_bulk("Cu", "fcc")
        validate_periodicity_for_eos(atoms)

    def test_eos_nonperiodic_raises(self):
        atoms = build_molecule("H2O")
        with pytest.raises(MACEToolError, match="periodic crystal"):
            validate_periodicity_for_eos(atoms)

    def test_empty_structure_raises(self):
        from ase import Atoms

        atoms = Atoms()
        with pytest.raises(MACEToolError, match="no atoms"):
            validate_structure_sanity(atoms)

    def test_normal_structure_ok(self):
        atoms = build_molecule("H2O")
        validate_structure_sanity(atoms)  # Should not raise

    def test_precision_for_hessian_upgrade(self):
        assert validate_precision_for_hessian("float32") == "float64"
        assert validate_precision_for_hessian("float64") == "float64"

    def test_structure_for_frequencies_warning(self):
        warning = validate_structure_for_frequencies(0.5)
        assert warning is not None
        assert "0.005" in warning

    def test_structure_for_frequencies_ok(self):
        warning = validate_structure_for_frequencies(0.001)
        assert warning is None


# ============================================================
# MACEToolError tests
# ============================================================

class TestMACEToolError:
    """Test the custom error class."""

    def test_error_message_format(self):
        err = MACEToolError("test error", hint="try this", next_action="do that")
        assert "test error" in str(err)
        assert "Hint: try this" in str(err)
        assert "Next action: do that" in str(err)
        assert err.hint == "try this"
        assert err.next_action == "do that"
