"""Shared test fixtures for MACE MCP Server tests."""

from __future__ import annotations

import os
import tempfile

import pytest


@pytest.fixture
def water_xyz() -> str:
    """Inline XYZ string for a water molecule."""
    return """3
Properties=species:S:1:pos:R:3 pbc="F F F"
O       0.00000000       0.00000000       0.11926200
H       0.00000000       0.76323900      -0.47704700
H       0.00000000      -0.76323900      -0.47704700
"""


@pytest.fixture
def ethanol_xyz() -> str:
    """Inline XYZ string for ethanol."""
    return """9
Properties=species:S:1:pos:R:3 pbc="F F F"
C      -0.04789000      -0.56805000       0.00000000
C       1.41819000      -0.01743000       0.00000000
O       1.41819000       1.40894000       0.00000000
H      -0.60703000      -0.18695000       0.87069000
H      -0.60703000      -0.18695000      -0.87069000
H      -0.04789000      -1.66405000       0.00000000
H       1.97733000      -0.39854000       0.87069000
H       1.97733000      -0.39854000      -0.87069000
H       2.32397000       1.75244000       0.00000000
"""


@pytest.fixture
def silicon_xyz() -> str:
    """Inline XYZ string for silicon crystal."""
    return """2
Lattice="5.43 0.0 0.0 0.0 5.43 0.0 0.0 0.0 5.43" Properties=species:S:1:pos:R:3 pbc="T T T"
Si      0.00000000       0.00000000       0.00000000
Si      1.35750000       1.35750000       1.35750000
"""


@pytest.fixture
def copper_xyz() -> str:
    """Inline XYZ string for copper FCC primitive cell."""
    return """1
Lattice="0.0 1.805 1.805 1.805 0.0 1.805 1.805 1.805 0.0" Properties=species:S:1:pos:R:3 pbc="T T T"
Cu      0.00000000       0.00000000       0.00000000
"""


@pytest.fixture
def water_xyz_file(water_xyz: str) -> str:
    """Write water XYZ to a temp file and return path."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".xyz", delete=False, prefix="test_water_"
    ) as f:
        f.write(water_xyz)
        path = f.name
    yield path
    os.unlink(path)


@pytest.fixture
def silicon_xyz_file(silicon_xyz: str) -> str:
    """Write silicon XYZ to a temp file and return path."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".xyz", delete=False, prefix="test_si_"
    ) as f:
        f.write(silicon_xyz)
        path = f.name
    yield path
    os.unlink(path)


@pytest.fixture
def model_cache() -> dict:
    """Shared model cache for tests."""
    return {}
