"""Tests for MCP resources -- model catalog, units, examples."""

from __future__ import annotations

import pytest

from mace_mcp_server.resources.models import MODEL_CATALOG
from mace_mcp_server.resources.reference import EXAMPLE_STRUCTURES, UNIT_CONVENTIONS


class TestModelCatalog:
    """Test model catalog data integrity."""

    def test_catalog_has_10_models(self):
        assert len(MODEL_CATALOG) == 10

    def test_all_models_have_required_fields(self):
        required = {"name", "loader", "elements", "domain", "default_dtype", "sizes", "license", "description", "when_to_use", "when_not_to_use"}
        for model_id, info in MODEL_CATALOG.items():
            missing = required - set(info.keys())
            assert not missing, f"Model {model_id} missing fields: {missing}"

    def test_default_model_is_mpa(self):
        """MACE-MPA-0 should be the default, not MACE-MP-0."""
        assert "mace-mpa-0" in MODEL_CATALOG
        mpa = MODEL_CATALOG["mace-mpa-0"]
        assert "default" in mpa["loader"].lower() or "default" in mpa["when_to_use"].lower()

    def test_mace_off_warns_about_dispersion(self):
        off = MODEL_CATALOG["mace-off"]
        assert "D3BJ" in off["description"] or "dispersion" in off["description"].lower()

    def test_mace_off_default_dtype(self):
        """MACE-OFF defaults to float64."""
        assert MODEL_CATALOG["mace-off"]["default_dtype"] == "float64"

    def test_all_model_ids_lowercase(self):
        for model_id in MODEL_CATALOG:
            assert model_id == model_id.lower()


class TestExampleStructures:
    """Test example structure data."""

    def test_has_6_examples(self):
        assert len(EXAMPLE_STRUCTURES) == 6

    def test_all_examples_have_xyz(self):
        for key, info in EXAMPLE_STRUCTURES.items():
            assert "xyz" in info, f"Example {key} missing xyz"
            assert "description" in info, f"Example {key} missing description"

    def test_xyz_valid_format(self):
        for key, info in EXAMPLE_STRUCTURES.items():
            xyz = info["xyz"].strip()
            lines = xyz.split("\n")
            n_atoms = int(lines[0].strip())
            # Should have n_atoms + 2 lines (count, comment, atoms)
            assert len(lines) >= n_atoms + 2, f"Example {key}: expected {n_atoms + 2} lines, got {len(lines)}"

    def test_water_example(self):
        water = EXAMPLE_STRUCTURES["water"]
        assert "H2O" in water["description"] or "Water" in water["description"]
        xyz = water["xyz"].strip()
        assert int(xyz.split("\n")[0]) == 3

    def test_periodic_examples_have_lattice(self):
        periodic = ["silicon", "copper_fcc", "nacl", "cu111_surface"]
        for key in periodic:
            xyz = EXAMPLE_STRUCTURES[key]["xyz"]
            assert "Lattice=" in xyz, f"Periodic example {key} missing Lattice"
            assert 'pbc="T T T"' in xyz, f"Periodic example {key} missing pbc"


class TestUnitConventions:
    """Test unit conventions resource."""

    def test_has_content(self):
        assert len(UNIT_CONVENTIONS) > 100

    def test_mentions_key_units(self):
        assert "eV" in UNIT_CONVENTIONS
        assert "Angstrom" in UNIT_CONVENTIONS
        assert "GPa" in UNIT_CONVENTIONS
        assert "Voigt" in UNIT_CONVENTIONS

    def test_mentions_ase_units(self):
        assert "ase.units" in UNIT_CONVENTIONS or "units.fs" in UNIT_CONVENTIONS
