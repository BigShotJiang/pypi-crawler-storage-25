"""Tests for MCP tool registration and intelligence logic.

These tests validate the tool registration functions and the
suggest_parameters intelligence logic without requiring MACE models.
"""

from __future__ import annotations

import pytest

from mace_mcp_server.tools.intelligence import _suggest_model, _get_task_parameters


class TestSuggestModel:
    """Test model suggestion logic."""

    def test_organic_molecule(self):
        model, reasoning, warnings, alts = _suggest_model(
            {"H", "C", "O"}, is_periodic=False, n_atoms=9
        )
        assert model == "MACE-OFF"
        assert "organic" in reasoning.lower() or "MACE-OFF" in reasoning

    def test_organic_periodic(self):
        model, reasoning, warnings, alts = _suggest_model(
            {"H", "C", "N", "O"}, is_periodic=True, n_atoms=20
        )
        assert model == "MACE-OFF"

    def test_inorganic_periodic(self):
        model, reasoning, warnings, alts = _suggest_model(
            {"Si"}, is_periodic=True, n_atoms=2
        )
        assert model == "MACE-MPA-0"

    def test_metal_elements_periodic(self):
        model, reasoning, warnings, alts = _suggest_model(
            {"Fe", "O"}, is_periodic=True, n_atoms=4
        )
        assert model == "MACE-MPA-0"
        # Should warn about MACE-OFF not supporting Fe
        fe_warnings = [w for w in warnings if "Fe" in w]
        assert len(fe_warnings) > 0

    def test_organometallic(self):
        model, reasoning, warnings, alts = _suggest_model(
            {"Fe", "C", "H", "N"}, is_periodic=False, n_atoms=15
        )
        assert model == "MACE-OMOL-0"

    def test_anicc_suggestion(self):
        model, reasoning, warnings, alts = _suggest_model(
            {"H", "C", "N", "O"}, is_periodic=False, n_atoms=10
        )
        assert model == "MACE-OFF"
        # Should mention ANI-CC as alternative
        anicc_mentioned = any("ANI-CC" in w for w in warnings) or "MACE-ANI-CC" in alts
        assert anicc_mentioned


class TestTaskParameters:
    """Test task-specific parameter recommendations."""

    def test_single_point_params(self):
        params = _get_task_parameters("single_point", 10, False, {"H", "C"})
        assert "precision" in params

    def test_optimize_params(self):
        params = _get_task_parameters("optimize", 10, True, {"Si"})
        assert params["fmax"] == 0.01
        assert params["optimizer"] == "BFGS"
        assert params["optimize_cell"] is True
        assert params["precision"] == "float64"

    def test_md_params_with_hydrogen(self):
        params = _get_task_parameters("md", 20, False, {"H", "C", "O"})
        assert params["timestep_fs"] == 0.5  # H-containing
        assert params["ensemble"] == "NVT"

    def test_md_params_heavy_atoms(self):
        params = _get_task_parameters("md", 20, True, {"Si", "O"})
        assert params["timestep_fs"] == 1.0  # No H

    def test_frequencies_params(self):
        params = _get_task_parameters("frequencies", 5, False, {"H", "O"})
        assert params["precision"] == "float64"

    def test_eos_params(self):
        params = _get_task_parameters("eos", 2, True, {"Cu"})
        assert params["num_points"] == 7
        assert params["eos_type"] == "birchmurnaghan"


class TestToolRegistration:
    """Test that tools register without errors."""

    def test_calculation_tools_register(self):
        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("test")
        from mace_mcp_server.tools.calculation import register_calculation_tools

        register_calculation_tools(mcp)
        # Verify tools are registered
        assert mcp._tool_manager is not None

    def test_structure_tools_register(self):
        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("test")
        from mace_mcp_server.tools.structure import register_structure_tools

        register_structure_tools(mcp)

    def test_analysis_tools_register(self):
        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("test")
        from mace_mcp_server.tools.analysis import register_analysis_tools

        register_analysis_tools(mcp)

    def test_intelligence_tools_register(self):
        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("test")
        from mace_mcp_server.tools.intelligence import register_intelligence_tools

        register_intelligence_tools(mcp)

    def test_all_tools_register_together(self):
        """Test that all tools can be registered on the same server."""
        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("test")
        from mace_mcp_server.tools.analysis import register_analysis_tools
        from mace_mcp_server.tools.calculation import register_calculation_tools
        from mace_mcp_server.tools.intelligence import register_intelligence_tools
        from mace_mcp_server.tools.structure import register_structure_tools

        register_calculation_tools(mcp)
        register_structure_tools(mcp)
        register_analysis_tools(mcp)
        register_intelligence_tools(mcp)


class TestResourceRegistration:
    """Test that resources register without errors."""

    def test_model_resources_register(self):
        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("test")
        from mace_mcp_server.resources.models import register_model_resources

        register_model_resources(mcp)

    def test_reference_resources_register(self):
        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("test")
        from mace_mcp_server.resources.reference import register_reference_resources

        register_reference_resources(mcp)

    def test_catalog_resources_register(self):
        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("test")
        from mace_mcp_server.resources.catalog import register_catalog_resources

        register_catalog_resources(mcp)


class TestPromptRegistration:
    """Test that prompts register without errors."""

    def test_prompts_register(self):
        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("test")
        from mace_mcp_server.prompts.workflows import register_prompts

        register_prompts(mcp)
