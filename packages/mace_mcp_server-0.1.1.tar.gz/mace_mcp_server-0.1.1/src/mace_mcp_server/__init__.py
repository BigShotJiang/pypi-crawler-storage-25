"""MACE MCP Server -- AI-callable atomistic simulation tools."""

__version__ = "0.1.1"
