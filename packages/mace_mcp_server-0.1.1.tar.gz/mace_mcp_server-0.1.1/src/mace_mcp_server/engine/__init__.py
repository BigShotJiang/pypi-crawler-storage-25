"""MACE calculation engine -- scientific logic independent of MCP."""
