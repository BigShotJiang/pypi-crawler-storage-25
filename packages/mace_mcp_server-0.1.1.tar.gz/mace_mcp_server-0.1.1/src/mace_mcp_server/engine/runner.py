"""Calculation execution engine -- single-point, optimization, MD, frequencies, EOS, descriptors.

All functions take ASE Atoms + calculator and return plain dicts.
They are MCP-agnostic and can be tested independently.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable

import numpy as np
from ase import Atoms
from ase.io import write

from mace_mcp_server.engine.builders import atoms_to_xyz_string
from mace_mcp_server.engine.calculator import MACEToolError

logger = logging.getLogger(__name__)


def run_single_point(atoms: Atoms, calc: Any, model_name: str = "") -> dict:
    """Run a single-point energy and force calculation.

    Args:
        atoms: ASE Atoms with positions (and cell if periodic).
        calc: MACE calculator instance.
        model_name: For labeling in results.

    Returns:
        Dict matching SinglePointResult fields.
    """
    t0 = time.time()
    atoms = atoms.copy()
    atoms.calc = calc

    energy = float(atoms.get_potential_energy())
    forces = atoms.get_forces()
    n = len(atoms)

    force_magnitudes = np.linalg.norm(forces, axis=1)
    max_force = float(np.max(force_magnitudes))
    rms_force = float(np.sqrt(np.sum(force_magnitudes**2) / n))

    is_periodic = any(atoms.get_pbc())
    stress = None
    if is_periodic:
        try:
            raw_stress = atoms.get_stress(voigt=True)
            stress = [float(s) for s in raw_stress]
        except Exception:
            pass

    # Per-atom energies (MACE provides these via node energy decomposition)
    per_atom_energies = []
    try:
        per_atom_energies = [float(e) for e in atoms.get_potential_energies()]
    except Exception:
        per_atom_energies = [energy / n] * n

    return {
        "status": "success",
        "energy_eV": energy,
        "energy_per_atom_eV": energy / n,
        "forces_eV_per_A": forces.tolist(),
        "max_force_eV_per_A": max_force,
        "rms_force_eV_per_A": rms_force,
        "stress_voigt_eV_per_A3": stress,
        "per_atom_energies_eV": per_atom_energies,
        "atom_count": n,
        "symbols": list(atoms.get_chemical_symbols()),
        "is_periodic": is_periodic,
        "model_used": model_name,
        "time_seconds": round(time.time() - t0, 3),
    }


def run_optimization(
    atoms: Atoms,
    calc: Any,
    fmax: float = 0.05,
    max_steps: int = 500,
    optimizer_name: str = "BFGS",
    optimize_cell: bool = False,
    output_file: str = "",
    model_name: str = "",
    progress_callback: Callable[[int, int, str], Any] | None = None,
) -> dict:
    """Run geometry optimization.

    Args:
        atoms: ASE Atoms (modified in place).
        calc: MACE calculator.
        fmax: Force convergence criterion (eV/A).
        max_steps: Maximum number of optimization steps.
        optimizer_name: 'BFGS' or 'FIRE'.
        optimize_cell: Whether to optimize the unit cell (periodic only).
        output_file: Path to save optimized structure.
        model_name: For labeling.
        progress_callback: Called with (step, max_steps, message).

    Returns:
        Dict matching OptimizationResult fields.
    """
    from ase.optimize import BFGS, FIRE

    t0 = time.time()
    atoms = atoms.copy()
    atoms.calc = calc

    # Initial state
    initial_energy = float(atoms.get_potential_energy())
    initial_forces = atoms.get_forces()
    initial_max_force = float(np.max(np.linalg.norm(initial_forces, axis=1)))

    # Set up optimizer
    opt_class = FIRE if optimizer_name.upper() == "FIRE" else BFGS
    opt_target = atoms

    if optimize_cell and any(atoms.get_pbc()):
        from ase.constraints import ExpCellFilter

        opt_target = ExpCellFilter(atoms)

    optimizer = opt_class(opt_target, logfile=None)

    # Track trajectory
    traj_energies = [initial_energy]
    traj_forces = [initial_max_force]
    step_count = [0]

    def _on_step():
        e = float(atoms.get_potential_energy())
        f = float(np.max(np.linalg.norm(atoms.get_forces(), axis=1)))
        traj_energies.append(e)
        traj_forces.append(f)
        step_count[0] += 1
        if progress_callback:
            progress_callback(
                step_count[0], max_steps, f"Step {step_count[0]}: max_force={f:.4f} eV/A"
            )

    optimizer.attach(_on_step)

    try:
        optimizer.run(fmax=fmax, steps=max_steps)
    except Exception as e:
        raise MACEToolError(
            f"Optimization failed: {e}",
            hint="The optimizer encountered an error. The structure may be problematic.",
            next_action="Check the structure for issues, try FIRE optimizer, or relax fmax.",
        ) from e

    # Final state
    final_energy = float(atoms.get_potential_energy())
    final_forces = atoms.get_forces()
    force_mags = np.linalg.norm(final_forces, axis=1)
    final_max_force = float(np.max(force_mags))
    final_rms_force = float(np.sqrt(np.sum(force_mags**2) / len(atoms)))

    converged = final_max_force <= fmax

    if not converged:
        logger.warning(
            "Optimization did not converge: max_force=%.4f > fmax=%.4f after %d steps",
            final_max_force,
            fmax,
            step_count[0],
        )

    # Save if requested
    saved_path = None
    if output_file:
        write(output_file, atoms, format="extxyz")
        saved_path = output_file

    cell = atoms.get_cell().tolist() if any(atoms.get_pbc()) else None

    return {
        "status": "success",
        "converged": converged,
        "initial_energy_eV": initial_energy,
        "final_energy_eV": final_energy,
        "energy_change_eV": final_energy - initial_energy,
        "initial_max_force": initial_max_force,
        "final_max_force": final_max_force,
        "final_rms_force": final_rms_force,
        "optimization_steps": step_count[0],
        "trajectory_energies_eV": traj_energies,
        "trajectory_max_forces": traj_forces,
        "optimized_positions": atoms.get_positions().tolist(),
        "optimized_cell": cell,
        "optimized_xyz": atoms_to_xyz_string(atoms),
        "symbols": list(atoms.get_chemical_symbols()),
        "atom_count": len(atoms),
        "model_used": model_name,
        "time_seconds": round(time.time() - t0, 3),
        "output_file": saved_path,
    }


def run_molecular_dynamics(
    atoms: Atoms,
    calc: Any,
    ensemble: str = "NVT",
    temperature_K: float = 300.0,
    timestep_fs: float = 1.0,
    num_steps: int = 100,
    pressure_GPa: float = 0.0,
    friction: float = 0.005,
    output_file: str = "",
    model_name: str = "",
    progress_callback: Callable[[int, int, str], Any] | None = None,
) -> dict:
    """Run molecular dynamics simulation.

    Args:
        atoms: ASE Atoms (starting structure).
        calc: MACE calculator.
        ensemble: 'NVT', 'NPT', or 'NVE'.
        temperature_K: Target temperature in Kelvin.
        timestep_fs: Timestep in femtoseconds.
        num_steps: Number of MD steps.
        pressure_GPa: External pressure for NPT.
        friction: Langevin friction for NVT.
        output_file: Path to save final structure.
        model_name: For labeling.
        progress_callback: Called with (step, num_steps, message).

    Returns:
        Dict matching MDResult fields.
    """
    from ase import units
    from ase.md.langevin import Langevin
    from ase.md.velocitydistribution import MaxwellBoltzmannDistribution
    from ase.md.verlet import VelocityVerlet

    t0 = time.time()
    atoms = atoms.copy()
    atoms.calc = calc

    # Initialize velocities
    MaxwellBoltzmannDistribution(atoms, temperature_K=temperature_K)

    # Set up integrator
    dt = timestep_fs * units.fs
    ensemble_upper = ensemble.upper()

    if ensemble_upper == "NVT":
        dyn = Langevin(atoms, dt, temperature_K=temperature_K, friction=friction / units.fs)
    elif ensemble_upper == "NPT":
        try:
            from ase.md.npt import NPT as NPTIntegrator

            pressure_au = pressure_GPa * units.GPa
            dyn = NPTIntegrator(
                atoms,
                dt,
                temperature_K=temperature_K,
                externalstress=pressure_au,
                ttime=25 * units.fs,
                pfactor=None,
            )
        except Exception:
            # Fallback: use Langevin + Berendsen-like approach
            from ase.md.nptberendsen import NPTBerendsen

            dyn = NPTBerendsen(
                atoms,
                dt,
                temperature_K=temperature_K,
                pressure_au=pressure_GPa * units.GPa,
                taut=100 * units.fs,
                taup=1000 * units.fs,
            )
    elif ensemble_upper == "NVE":
        dyn = VelocityVerlet(atoms, dt)
    else:
        raise MACEToolError(
            f"Unknown ensemble: {ensemble}",
            hint="Supported ensembles: NVT, NPT, NVE.",
            next_action="Set ensemble to 'NVT', 'NPT', or 'NVE'.",
        )

    # Run MD and collect trajectory
    traj_energies = []
    traj_temperatures = []
    report_interval = max(1, num_steps // 50)  # ~50 data points

    def _collect():
        e = float(atoms.get_potential_energy())
        T = float(atoms.get_temperature())
        traj_energies.append(e)
        traj_temperatures.append(T)

    # Collect initial state
    _collect()

    for step in range(1, num_steps + 1):
        dyn.run(1)
        if step % report_interval == 0 or step == num_steps:
            _collect()
            if progress_callback:
                progress_callback(
                    step,
                    num_steps,
                    f"Step {step}/{num_steps}, T={traj_temperatures[-1]:.1f}K",
                )

    # Statistics
    temps = np.array(traj_temperatures)
    energies = np.array(traj_energies)
    n_atoms = len(atoms)

    # Energy drift for NVE
    if len(traj_energies) > 1:
        total_time_ps = num_steps * timestep_fs / 1000.0
        drift = (traj_energies[-1] - traj_energies[0]) / n_atoms / max(total_time_ps, 1e-10)
    else:
        drift = 0.0

    # Save if requested
    saved_path = None
    if output_file:
        write(output_file, atoms, format="extxyz")
        saved_path = output_file

    return {
        "status": "success",
        "ensemble": ensemble_upper,
        "num_steps_completed": num_steps,
        "temperature_target_K": temperature_K,
        "temperature_mean_K": float(np.mean(temps)),
        "temperature_std_K": float(np.std(temps)),
        "energy_initial_eV": traj_energies[0],
        "energy_final_eV": traj_energies[-1],
        "energy_mean_eV": float(np.mean(energies)),
        "energy_drift_eV_per_atom_per_ps": drift,
        "trajectory_energies_eV": traj_energies,
        "trajectory_temperatures_K": traj_temperatures,
        "final_positions": atoms.get_positions().tolist(),
        "final_xyz": atoms_to_xyz_string(atoms),
        "symbols": list(atoms.get_chemical_symbols()),
        "atom_count": n_atoms,
        "model_used": model_name,
        "time_seconds": round(time.time() - t0, 3),
        "output_file": saved_path,
    }


def run_vibrational_analysis(
    atoms: Atoms,
    calc: Any,
    model_name: str = "",
) -> dict:
    """Calculate vibrational frequencies and thermodynamic properties.

    Requires float64 precision (caller should ensure this).
    Structure should be at a local minimum (max_force < 0.005 eV/A).

    Returns:
        Dict matching VibrationalResult fields.
    """
    from ase.vibrations import Vibrations

    t0 = time.time()
    atoms = atoms.copy()
    atoms.calc = calc

    n = len(atoms)

    # Run vibrational analysis
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp(prefix="mace_vib_")
    try:
        vib = Vibrations(atoms, name=f"{tmpdir}/vib")
        vib.run()

        # Get frequencies in cm^-1
        freqs_raw = vib.get_frequencies()
        # ASE returns complex numbers: real part is frequency, imaginary means negative
        frequencies = []
        for f in freqs_raw:
            if np.iscomplex(f):
                real_part = float(np.real(f))
                imag_part = float(np.imag(f))
                if abs(imag_part) > abs(real_part) and imag_part < 0:
                    frequencies.append(-abs(imag_part))
                else:
                    frequencies.append(real_part)
            else:
                frequencies.append(float(np.real(f)))

        frequencies.sort(reverse=True)

        real_freqs = [f for f in frequencies if f > 0]
        imag_freqs = [f for f in frequencies if f < 0]

        # Zero-point energy
        zpe = 0.0
        try:
            zpe = float(vib.get_zero_point_energy())
        except Exception:
            if real_freqs:
                from ase import units

                zpe = 0.5 * sum(
                    f * units.invcm for f in real_freqs
                )

        # Determine if linear (3N-5 vs 3N-6)
        is_linear = _is_linear(atoms)
        expected_modes = 3 * n - 5 if is_linear else 3 * n - 6

        has_imaginary = len(imag_freqs) > 0
        warning = None
        if has_imaginary:
            warning = (
                f"Found {len(imag_freqs)} imaginary frequencies: {imag_freqs}. "
                "This indicates the structure is not at a local minimum. "
                "Run optimize with fmax=0.005 first."
            )

        vib.clean()
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    return {
        "status": "success",
        "frequencies_cm_inv": frequencies,
        "real_frequencies_cm_inv": real_freqs,
        "imaginary_frequencies_cm_inv": imag_freqs,
        "zero_point_energy_eV": zpe,
        "num_atoms": n,
        "num_modes": len(frequencies),
        "expected_real_modes": expected_modes,
        "is_linear": is_linear,
        "has_imaginary": has_imaginary,
        "model_used": model_name,
        "time_seconds": round(time.time() - t0, 3),
        "warning": warning,
    }


def _is_linear(atoms: Atoms) -> bool:
    """Check if a molecule is linear (all atoms on a line)."""
    if len(atoms) <= 2:
        return True
    positions = atoms.get_positions()
    # Use SVD to check dimensionality
    centered = positions - positions.mean(axis=0)
    _, s, _ = np.linalg.svd(centered)
    # If second singular value is very small relative to first, it's linear
    if s[0] > 1e-10:
        return s[1] / s[0] < 0.01
    return True


def run_equation_of_state(
    atoms: Atoms,
    calc: Any,
    num_points: int = 7,
    strain_range: float = 0.05,
    eos_type: str = "birchmurnaghan",
    model_name: str = "",
    progress_callback: Callable[[int, int, str], Any] | None = None,
) -> dict:
    """Compute equation of state by uniform volume scaling.

    Args:
        atoms: Periodic ASE Atoms.
        calc: MACE calculator.
        num_points: Number of volume points.
        strain_range: Fractional volume strain (+/-).
        eos_type: EOS type for fitting.
        model_name: For labeling.
        progress_callback: Progress reporting.

    Returns:
        Dict matching EOSResult fields.
    """
    from ase.eos import EquationOfState

    t0 = time.time()
    atoms = atoms.copy()
    atoms.calc = calc

    cell = atoms.get_cell()
    original_volume = float(atoms.get_volume())

    # Generate volume points
    strains = np.linspace(1 - strain_range, 1 + strain_range, num_points)
    volumes = []
    energies = []

    for i, strain in enumerate(strains):
        strained = atoms.copy()
        strained.calc = calc
        # Scale cell uniformly
        scale = strain ** (1.0 / 3.0)
        strained.set_cell(cell * scale, scale_atoms=True)

        e = float(strained.get_potential_energy())
        v = float(strained.get_volume())
        volumes.append(v)
        energies.append(e)

        if progress_callback:
            progress_callback(i + 1, num_points, f"EOS point {i + 1}/{num_points}")

    # Fit EOS
    eos = EquationOfState(volumes, energies, eos=eos_type)
    v0, e0, B = eos.fit()

    # Convert bulk modulus from eV/A^3 to GPa
    from ase import units

    B_GPa = float(B / units.GPa)

    return {
        "status": "success",
        "equilibrium_volume_A3": float(v0),
        "equilibrium_energy_eV": float(e0),
        "bulk_modulus_GPa": B_GPa,
        "bulk_modulus_derivative": 0.0,  # Not directly from ASE fit
        "eos_type": eos_type,
        "volumes_A3": volumes,
        "energies_eV": energies,
        "num_points": num_points,
        "model_used": model_name,
        "time_seconds": round(time.time() - t0, 3),
    }


def run_extract_descriptors(
    atoms: Atoms,
    calc: Any,
    invariants_only: bool = True,
    model_name: str = "",
) -> dict:
    """Extract MACE learned atomic descriptors.

    Args:
        atoms: ASE Atoms.
        calc: MACE calculator (must support get_descriptors).
        invariants_only: Whether to return only invariant features.
        model_name: For labeling.

    Returns:
        Dict matching DescriptorResult fields.
    """
    t0 = time.time()
    atoms = atoms.copy()
    atoms.calc = calc

    try:
        descriptors = calc.get_descriptors(atoms, invariants_only=invariants_only)
        desc_array = np.array(descriptors)
    except AttributeError:
        raise MACEToolError(
            "This calculator does not support descriptor extraction",
            hint="Descriptor extraction requires a MACE calculator with get_descriptors() method.",
            next_action="Use a MACE foundation model (e.g. MACE-MPA-0).",
        )
    except Exception as e:
        raise MACEToolError(
            f"Descriptor extraction failed: {e}",
            hint="An error occurred during descriptor computation.",
            next_action="Check the structure and model compatibility.",
        ) from e

    return {
        "status": "success",
        "descriptors": desc_array.tolist(),
        "num_atoms": len(atoms),
        "num_features": desc_array.shape[1] if desc_array.ndim > 1 else desc_array.shape[0],
        "invariants_only": invariants_only,
        "symbols": list(atoms.get_chemical_symbols()),
        "model_used": model_name,
        "time_seconds": round(time.time() - t0, 3),
    }
