"""ASE structure builders for molecules, bulk crystals, and surfaces.

These functions are independent of MCP -- pure atomistic construction using ASE.
"""

from __future__ import annotations

import io
import os
import tempfile
from typing import Any

import numpy as np
from ase import Atoms
from ase.io import read, write


def build_molecule(name: str) -> Atoms:
    """Build a molecule from ASE's G2 database.

    Args:
        name: Molecule name or formula (e.g. 'H2O', 'CH4', 'C6H6', 'ethanol').

    Returns:
        ASE Atoms object (non-periodic).
    """
    from ase.build import molecule

    return molecule(name)


def build_bulk(
    symbol: str,
    crystal_structure: str,
    lattice_constant: float = 0,
    supercell: list[int] | None = None,
) -> Atoms:
    """Build a periodic bulk crystal.

    Args:
        symbol: Element or compound (e.g. 'Cu', 'Si', 'NaCl').
        crystal_structure: Crystal type ('fcc', 'bcc', 'hcp', 'diamond', 'rocksalt', 'zincblende').
        lattice_constant: Lattice constant in Angstroms (0 = use ASE default).
        supercell: Repetitions [nx, ny, nz].

    Returns:
        ASE Atoms object (periodic).
    """
    from ase.build import bulk

    kwargs: dict[str, Any] = {"crystalstructure": crystal_structure}
    if lattice_constant > 0:
        kwargs["a"] = lattice_constant

    atoms = bulk(symbol, **kwargs)

    if supercell and supercell != [1, 1, 1]:
        atoms = atoms.repeat(supercell)

    return atoms


def build_surface(
    symbol: str,
    crystal_structure: str,
    miller_indices: list[int],
    num_layers: int = 4,
    vacuum: float = 10.0,
    lattice_constant: float = 0,
    supercell: list[int] | None = None,
) -> Atoms:
    """Build a surface slab with vacuum.

    Args:
        symbol: Element (e.g. 'Cu', 'Si').
        crystal_structure: Crystal type for the parent bulk.
        miller_indices: Miller indices [h, k, l].
        num_layers: Number of atomic layers.
        vacuum: Vacuum thickness in Angstroms.
        lattice_constant: Lattice constant (0 = ASE default).
        supercell: In-plane repetitions [nx, ny, nz].

    Returns:
        ASE Atoms object (periodic with vacuum).
    """
    from ase.build import fcc111, fcc100, fcc110, bcc111, bcc100, bcc110

    h, k, l = miller_indices
    a = lattice_constant if lattice_constant > 0 else None

    # Map to ASE slab builders for common cases
    surface_builders = {
        ("fcc", (1, 1, 1)): fcc111,
        ("fcc", (1, 0, 0)): fcc100,
        ("fcc", (1, 1, 0)): fcc110,
        ("bcc", (1, 1, 1)): bcc111,
        ("bcc", (1, 0, 0)): bcc100,
        ("bcc", (1, 1, 0)): bcc110,
    }

    key = (crystal_structure.lower(), (h, k, l))
    if key in surface_builders:
        builder = surface_builders[key]
        kwargs: dict[str, Any] = {"size": (1, 1, num_layers), "vacuum": vacuum}
        if a is not None:
            kwargs["a"] = a
        atoms = builder(symbol, **kwargs)
    else:
        # Generic surface via ase.build.surface
        from ase.build import surface

        bulk_atoms = build_bulk(symbol, crystal_structure, lattice_constant or 0)
        atoms = surface(bulk_atoms, (h, k, l), num_layers, vacuum=vacuum)

    if supercell and supercell != [1, 1, 1]:
        atoms = atoms.repeat(supercell)

    return atoms


def parse_structure_input(structure: str) -> Atoms:
    """Parse a structure from file path or inline XYZ string.

    Args:
        structure: Either a file path (XYZ, CIF, POSCAR, PDB) or inline XYZ content.

    Returns:
        ASE Atoms object.

    Raises:
        ValueError: If the structure cannot be parsed.
    """
    # Check if it's a file path
    if os.path.isfile(structure):
        return _read_structure_file(structure)

    # Try to parse as inline XYZ
    if "\n" in structure and structure.strip()[0].isdigit():
        return _parse_inline_xyz(structure)

    raise ValueError(
        f"Cannot parse structure: '{structure[:80]}...'. "
        "Provide a valid file path (XYZ, CIF, POSCAR, PDB) or inline XYZ string."
    )


def _read_structure_file(filepath: str) -> Atoms:
    """Read a structure file using ASE's format detection."""
    ext = os.path.splitext(filepath)[1].lower()

    format_map = {
        ".xyz": "extxyz",
        ".cif": "cif",
        ".pdb": "pdb",
        ".poscar": "vasp",
        ".contcar": "vasp",
        ".vasp": "vasp",
    }

    # Files named POSCAR or CONTCAR without extension
    basename = os.path.basename(filepath).upper()
    if basename in ("POSCAR", "CONTCAR"):
        fmt = "vasp"
    else:
        fmt = format_map.get(ext)

    if fmt:
        return read(filepath, format=fmt)
    # Let ASE guess
    return read(filepath)


def _parse_inline_xyz(xyz_string: str) -> Atoms:
    """Parse inline XYZ content."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".xyz", delete=False) as f:
        f.write(xyz_string)
        f.flush()
        tmppath = f.name

    try:
        return read(tmppath, format="extxyz")
    finally:
        os.unlink(tmppath)


def atoms_to_xyz_string(atoms: Atoms) -> str:
    """Convert ASE Atoms to extended XYZ string."""
    buf = io.StringIO()
    write(buf, atoms, format="extxyz")
    return buf.getvalue()


def get_min_distance(atoms: Atoms) -> tuple[float, list[list[int]]]:
    """Compute minimum interatomic distance and find overlapping pairs.

    Returns:
        (min_distance, overlap_pairs) where overlap_pairs are atom index pairs
        with distance < 0.5 Angstroms.
    """
    positions = atoms.get_positions()
    n = len(atoms)
    if n < 2:
        return float("inf"), []

    min_dist = float("inf")
    overlaps = []

    for i in range(n):
        for j in range(i + 1, n):
            d = float(np.linalg.norm(positions[i] - positions[j]))
            if d < min_dist:
                min_dist = d
            if d < 0.5:
                overlaps.append([i, j])

    return min_dist, overlaps
