"""Scientific validation checks for MACE calculations.

Enforces the rules from the DESIGN.md scientific accuracy checklist.
"""

from __future__ import annotations

from ase import Atoms

from mace_mcp_server.engine.calculator import MACEToolError


def validate_periodicity_for_npt(atoms: Atoms, ensemble: str) -> None:
    """NPT requires a periodic system with valid cell."""
    if ensemble.upper() == "NPT":
        if not any(atoms.get_pbc()):
            raise MACEToolError(
                "NPT ensemble requires a periodic system",
                hint="NPT simulates constant pressure, which requires periodic boundary conditions.",
                next_action="Use NVT for molecules, or provide a periodic structure with a unit cell.",
            )


def validate_periodicity_for_cell_opt(atoms: Atoms, optimize_cell: bool) -> None:
    """Cell optimization requires a periodic system."""
    if optimize_cell:
        if not any(atoms.get_pbc()):
            raise MACEToolError(
                "Cell optimization requires a periodic system",
                hint="Cannot optimize cell dimensions without periodic boundary conditions.",
                next_action="Set optimize_cell=False for molecules, or provide a periodic structure.",
            )


def validate_periodicity_for_eos(atoms: Atoms) -> None:
    """EOS requires a periodic crystal."""
    if not any(atoms.get_pbc()):
        raise MACEToolError(
            "Equation of state requires a periodic crystal",
            hint="EOS works by scaling the unit cell volume, which requires periodicity.",
            next_action="Provide a periodic crystal structure (CIF, POSCAR, or bulk-built structure).",
        )


def validate_structure_sanity(atoms: Atoms) -> None:
    """Check for obvious structural problems."""
    if len(atoms) == 0:
        raise MACEToolError(
            "Structure has no atoms",
            hint="The provided structure is empty.",
            next_action="Provide a valid structure file or inline XYZ string.",
        )

    # Check for overlapping atoms
    positions = atoms.get_positions()
    n = len(atoms)
    for i in range(n):
        for j in range(i + 1, n):
            import numpy as np

            d = float(np.linalg.norm(positions[i] - positions[j]))
            if d < 0.3:
                raise MACEToolError(
                    f"Atoms at indices [{i},{j}] are only {d:.2f} A apart",
                    hint="Atoms closer than 0.3 A likely indicate a structural error.",
                    next_action="Check your structure for duplicate or misplaced atoms.",
                )


def validate_precision_for_hessian(precision: str) -> str:
    """Vibrational analysis requires float64. Auto-upgrade if needed."""
    if precision == "float32":
        return "float64"
    return precision


def validate_structure_for_frequencies(max_force: float) -> str | None:
    """Warn if structure isn't well-optimized before frequency calculation."""
    if max_force > 0.01:
        return (
            f"Structure has max force {max_force:.4f} eV/A (should be < 0.005 for accurate "
            "frequencies). Consider running optimize with fmax=0.005 first."
        )
    return None


def warn_dispersion_model(model: str, dispersion: bool) -> str | None:
    """Return warning string if dispersion is misused."""
    if dispersion and model in ("MACE-OFF", "MACE-OFF23"):
        return (
            "MACE-OFF already includes D3BJ dispersion. "
            "Enabling dispersion=True will double-count. Setting dispersion=False."
        )
    return None
