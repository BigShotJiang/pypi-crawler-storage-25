"""MACE calculator loading, caching, and device resolution.

All model loading goes through get_calculator(), which handles:
- Model name -> loader mapping for all 11 foundation models + custom
- Lazy loading with caching by (model, size, precision, device, dispersion) key
- CUDA fallback to CPU
- Scientific validation (D3 + MACE-OFF rejection)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from mcp.server.fastmcp.exceptions import ToolError

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# Elements supported by each model family
MACE_OFF_ELEMENTS = frozenset({"H", "C", "N", "O", "F", "P", "S", "Cl", "Br", "I"})
MACE_ANICC_ELEMENTS = frozenset({"H", "C", "N", "O"})


class MACEToolError(ToolError):
    """Error with LLM-friendly hint and next action.

    Inherits from ToolError so FastMCP returns the structured message
    (with hint + next_action) to the client instead of a generic
    'Internal Server Error'.
    """

    def __init__(self, message: str, hint: str = "", next_action: str = ""):
        self.hint = hint
        self.next_action = next_action
        parts = [message]
        if hint:
            parts.append(f"\n\nHint: {hint}")
        if next_action:
            parts.append(f"\nNext action: {next_action}")
        super().__init__("".join(parts))


def get_calculator(
    model: str,
    model_size: str,
    precision: str,
    device: str,
    dispersion: bool,
    cache: dict[tuple, Any],
) -> Any:
    """Load or retrieve a cached MACE calculator.

    Args:
        model: Model name (e.g. 'MACE-MPA-0', 'MACE-OFF') or path to .model file.
        model_size: One of 'small', 'medium', 'large', 'extra_large'.
        precision: 'float32' or 'float64'.
        device: 'cpu' or 'cuda'.
        dispersion: Whether to enable D3(BJ) dispersion correction.
        cache: Shared model cache dict from lifespan context.

    Returns:
        An ASE-compatible MACE calculator.

    Raises:
        MACEToolError: On invalid model/dispersion combinations.
    """
    cache_key = (model, model_size, precision, device, dispersion)

    if cache_key in cache:
        logger.info("Using cached calculator: %s", cache_key)
        return cache[cache_key]

    actual_device = _resolve_device(device)
    if actual_device != device:
        logger.warning("Requested device '%s' not available, using '%s'", device, actual_device)

    calc = _load_calculator(model, model_size, precision, actual_device, dispersion)

    cache[cache_key] = calc
    logger.info("Loaded and cached calculator: %s", cache_key)
    return calc


def _load_calculator(
    model: str,
    model_size: str,
    precision: str,
    device: str,
    dispersion: bool,
) -> Any:
    """Internal: instantiate a MACE calculator by model name."""
    if model in ("MACE-OFF", "MACE-OFF23"):
        if dispersion:
            raise MACEToolError(
                "D3 dispersion cannot be used with MACE-OFF",
                hint="MACE-OFF is trained on wB97M-D3BJ which already includes dispersion.",
                next_action="Set dispersion=False and retry.",
            )
        from mace.calculators import mace_off

        return mace_off(model=model_size, device=device, default_dtype=precision)

    if model in ("MACE-OMOL", "MACE-OMOL-0"):
        from mace.calculators import mace_omol

        return mace_omol(model=model_size, device=device, default_dtype=precision)

    if model in ("MACE-Polar", "MACE-Polar-1") or model.startswith("polar"):
        from mace.calculators import mace_polar

        size_char = model_size[0]  # s/m/l -> first character
        return mace_polar(model=f"polar-1-{size_char}", device=device, default_dtype=precision)

    if model == "MACE-ANI-CC":
        from mace.calculators import mace_anicc

        return mace_anicc(device=device)

    if model.endswith(".model") or "/" in model:
        # Custom model path
        from mace.calculators import MACECalculator

        return MACECalculator(model_paths=model, device=device, default_dtype=precision)

    # All MACE-MP variants
    from mace.calculators import mace_mp

    model_key = _resolve_mp_model_key(model, model_size)
    return mace_mp(model=model_key, device=device, dispersion=dispersion, default_dtype=precision)


def _resolve_mp_model_key(model: str, size: str) -> str:
    """Map user-friendly model names to mace_mp() model keys."""
    mapping = {
        "MACE-MPA-0": f"{size}-mpa-0",
        "MACE-MP-0": size,
        "MACE-OMAT-0": f"{size}-omat-0",
        "MACE-MATPES-PBE-0": "mace-matpes-pbe-0",
        "MACE-MATPES-r2SCAN-0": "mace-matpes-r2scan-0",
        "MACE-MH-0": "mh-0",
        "MACE-MH-1": "mh-1",
    }
    return mapping.get(model, f"{size}-mpa-0")


def _resolve_device(requested: str) -> str:
    """Resolve compute device with CUDA fallback."""
    if requested in ("cuda", "gpu"):
        try:
            import torch

            return "cuda" if torch.cuda.is_available() else "cpu"
        except ImportError:
            return "cpu"
    return requested


def validate_elements(symbols: list[str], model: str) -> None:
    """Check that all elements are supported by the chosen model.

    Raises:
        MACEToolError: If unsupported elements are found.
    """
    unique = set(symbols)

    if model in ("MACE-OFF", "MACE-OFF23"):
        unsupported = unique - MACE_OFF_ELEMENTS
        if unsupported:
            raise MACEToolError(
                f"MACE-OFF does not support elements: {sorted(unsupported)}",
                hint=f"MACE-OFF only supports {sorted(MACE_OFF_ELEMENTS)}. "
                "Use MACE-MPA-0 for materials or MACE-OMOL for organometallics.",
                next_action="Change model to 'MACE-MPA-0' or 'MACE-OMOL' and retry.",
            )

    if model == "MACE-ANI-CC":
        unsupported = unique - MACE_ANICC_ELEMENTS
        if unsupported:
            raise MACEToolError(
                f"MACE-ANI-CC does not support elements: {sorted(unsupported)}",
                hint=f"MACE-ANI-CC only supports {sorted(MACE_ANICC_ELEMENTS)}.",
                next_action="Change model to 'MACE-MPA-0' or 'MACE-OFF' and retry.",
            )
