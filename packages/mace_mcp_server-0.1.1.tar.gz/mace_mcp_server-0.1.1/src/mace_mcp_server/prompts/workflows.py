"""MCP prompt templates for guided MACE workflows."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.prompts import base


def register_prompts(mcp: FastMCP) -> None:
    """Register workflow prompt templates."""

    @mcp.prompt()
    def analyze_structure(
        filepath: str, model: str = "MACE-MPA-0"
    ) -> list[base.Message]:
        """Guided workflow for comprehensive structure analysis.

        Walks through parsing, parameter suggestion, single-point calculation,
        and assessment of results with recommendations for next steps.
        """
        return [
            base.Message(
                role="user",
                content=(
                    f"Please analyze the atomic structure at {filepath}:\n\n"
                    "1. Parse the structure to understand composition and geometry\n"
                    "2. Use suggest_parameters to determine the best model and settings\n"
                    "3. Run a single-point calculation\n"
                    "4. Assess the results:\n"
                    "   - Is the energy in a reasonable range for the model?\n"
                    "   - Are forces reasonable (< 10 eV/A)?\n"
                    "   - For periodic systems, check the stress tensor\n"
                    "5. If max force > 1 eV/A, recommend geometry optimization\n"
                    "6. Summarize findings and suggest next steps"
                ),
            )
        ]

    @mcp.prompt()
    def optimize_molecule(molecule_name: str) -> list[base.Message]:
        """Guided workflow: build, optimize, and analyze a molecule.

        Complete pipeline from molecule construction through optimization
        and optional vibrational analysis.
        """
        return [
            base.Message(
                role="user",
                content=(
                    f"Please build and optimize {molecule_name}:\n\n"
                    "1. Build the molecule using build_structure\n"
                    "2. Run a single-point to get the initial energy/forces\n"
                    "3. Optimize with fmax=0.01 using MACE-OFF (organic) or MACE-MPA-0 (inorganic)\n"
                    "4. If the molecule is small (< 20 atoms), run vibrational_frequencies "
                    "(with fmax=0.005 first)\n"
                    "5. Report: optimized energy, bond lengths, frequencies, zero-point energy"
                ),
            )
        ]

    @mcp.prompt()
    def md_simulation(
        filepath: str, temperature_K: float = 300
    ) -> list[base.Message]:
        """Guided workflow for setting up and running molecular dynamics.

        Includes structure preparation, parameter optimization, MD execution,
        and trajectory analysis.
        """
        return [
            base.Message(
                role="user",
                content=(
                    f"Please run a molecular dynamics simulation on {filepath} at {temperature_K}K:\n\n"
                    "1. Parse the structure and suggest optimal parameters\n"
                    "2. First optimize the structure (fmax=0.05)\n"
                    "3. Run NVT MD with appropriate timestep and friction\n"
                    "4. Analyze the trajectory: temperature stability, energy conservation, "
                    "structural changes\n"
                    "5. Report key findings and whether the simulation appears stable"
                ),
            )
        ]
