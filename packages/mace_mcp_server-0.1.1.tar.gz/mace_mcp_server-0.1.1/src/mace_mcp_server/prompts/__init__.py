"""MCP prompt templates for MACE workflows."""
