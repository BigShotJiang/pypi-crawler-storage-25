"""MCP tools for advanced analysis: equation_of_state, extract_descriptors."""

from __future__ import annotations

from typing import Annotated

from mcp.server.fastmcp import Context, FastMCP
from mcp.types import ToolAnnotations
from pydantic import Field

from mace_mcp_server.engine.builders import parse_structure_input
from mace_mcp_server.engine.calculator import MACEToolError, get_calculator, validate_elements
from mace_mcp_server.engine.runner import run_equation_of_state, run_extract_descriptors
from mace_mcp_server.engine.validators import validate_periodicity_for_eos, validate_structure_sanity


def register_analysis_tools(mcp: FastMCP) -> None:
    """Register analysis tools on the FastMCP instance."""

    @mcp.tool(
        annotations=ToolAnnotations(readOnlyHint=True, idempotentHint=True),
    )
    async def equation_of_state(
        ctx: Context,
        structure: Annotated[
            str, Field(description="Path to periodic crystal structure file")
        ],
        model: str = "MACE-MPA-0",
        model_size: str = "medium",
        num_points: Annotated[
            int,
            Field(description="Number of volume points to sample", ge=5, le=21),
        ] = 7,
        strain_range: Annotated[
            float,
            Field(description="Fractional volume strain range (+/-)", ge=0.01, le=0.15),
        ] = 0.05,
        eos_type: Annotated[
            str,
            Field(description="EOS type: 'birchmurnaghan', 'murnaghan', 'vinet'"),
        ] = "birchmurnaghan",
        dispersion: bool = False,
        device: str = "cpu",
    ) -> str:
        """Compute equation of state for a periodic crystal.

        Fits E(V) curve by uniformly scaling the unit cell volume.
        Returns equilibrium volume, energy, and bulk modulus (GPa).
        Structure must be periodic with a valid unit cell.
        """
        try:
            atoms = parse_structure_input(structure)
            validate_structure_sanity(atoms)
            validate_periodicity_for_eos(atoms)
            validate_elements(list(atoms.get_chemical_symbols()), model)

            cache = ctx.request_context.lifespan_context.get("model_cache", {})
            calc = get_calculator(model, model_size, "float64", device, dispersion, cache)

            await ctx.info(f"Computing EOS with {num_points} points, strain={strain_range}...")

            result = run_equation_of_state(
                atoms,
                calc,
                num_points=num_points,
                strain_range=strain_range,
                eos_type=eos_type,
                model_name=f"{model}/{model_size}",
            )

            await ctx.info(
                f"EOS complete: V0={result['equilibrium_volume_A3']:.2f} A^3, "
                f"B={result['bulk_modulus_GPa']:.1f} GPa"
            )

            from mace_mcp_server.schemas.outputs import EOSResult

            return EOSResult(**result).model_dump_json(indent=2)
        except MACEToolError:
            raise
        except Exception as e:
            raise MACEToolError(
                f"EOS calculation failed: {e}",
                hint="Ensure the structure is periodic with a valid unit cell.",
                next_action="Check that the structure is a crystal (CIF, POSCAR, or built with build_structure bulk).",
            ) from e

    @mcp.tool(
        annotations=ToolAnnotations(readOnlyHint=True, idempotentHint=True),
    )
    async def extract_descriptors(
        structure: Annotated[
            str, Field(description="Path to structure file or inline XYZ")
        ],
        model: str = "MACE-MPA-0",
        model_size: str = "medium",
        invariants_only: Annotated[
            bool,
            Field(description="True = rotation-invariant features; False = full equivariant"),
        ] = True,
        device: str = "cpu",
    ) -> str:
        """Extract MACE learned atomic descriptors for ML featurization.

        Returns per-atom feature vectors from the model's internal representations.
        Useful for: clustering structures, similarity analysis, active learning,
        and downstream ML models. Shape: (num_atoms, num_features).
        """
        try:
            atoms = parse_structure_input(structure)
            validate_structure_sanity(atoms)
            validate_elements(list(atoms.get_chemical_symbols()), model)

            cache = {}  # Descriptors don't need long-lived cache
            calc = get_calculator(model, model_size, "float32", device, False, cache)

            result = run_extract_descriptors(
                atoms,
                calc,
                invariants_only=invariants_only,
                model_name=f"{model}/{model_size}",
            )

            from mace_mcp_server.schemas.outputs import DescriptorResult

            return DescriptorResult(**result).model_dump_json(indent=2)
        except MACEToolError:
            raise
        except Exception as e:
            raise MACEToolError(
                f"Descriptor extraction failed: {e}",
                hint="Check model and structure compatibility.",
                next_action="Try using a MACE foundation model (e.g. MACE-MPA-0).",
            ) from e
