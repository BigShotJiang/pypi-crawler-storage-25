"""MCP tools for structure manipulation: parse_structure, build_structure, convert_structure."""

from __future__ import annotations

from typing import Annotated

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from pydantic import Field

from mace_mcp_server.engine.builders import (
    atoms_to_xyz_string,
    build_bulk,
    build_molecule,
    build_surface,
    get_min_distance,
    parse_structure_input,
)
from mace_mcp_server.engine.calculator import MACEToolError


def register_structure_tools(mcp: FastMCP) -> None:
    """Register all structure tools on the FastMCP instance."""

    @mcp.tool(
        annotations=ToolAnnotations(
            readOnlyHint=True, idempotentHint=True, openWorldHint=False
        ),
    )
    async def parse_structure(
        structure: Annotated[
            str, Field(description="Path to structure file (XYZ, CIF, POSCAR, PDB)")
        ],
    ) -> str:
        """Parse an atomic structure file and return detailed analysis.

        Reports composition, formula, periodicity, cell parameters, bounding box,
        minimum interatomic distances (overlap detection), and reference data.
        Supports: XYZ, extended XYZ, CIF, POSCAR/CONTCAR, PDB.
        """
        try:
            atoms = parse_structure_input(structure)
        except Exception as e:
            raise MACEToolError(
                f"Cannot parse structure: {e}",
                hint="Check the file path or XYZ format.",
                next_action="Provide a valid structure file (XYZ, CIF, POSCAR, PDB) or inline XYZ.",
            ) from e

        import os

        import numpy as np

        symbols = list(atoms.get_chemical_symbols())
        unique_elements = sorted(set(symbols))
        is_periodic = any(atoms.get_pbc())

        cell = None
        cell_lengths = None
        cell_angles = None
        volume = None
        if is_periodic:
            cell_obj = atoms.get_cell()
            cell = cell_obj.tolist()
            cell_lengths = [float(x) for x in cell_obj.lengths()]
            cell_angles = [float(x) for x in cell_obj.angles()]
            volume = float(atoms.get_volume())

        min_dist, overlaps = get_min_distance(atoms)

        # Detect source format from file extension
        source_format = "inline_xyz"
        if os.path.isfile(structure):
            ext = os.path.splitext(structure)[1].lower()
            fmt_map = {
                ".xyz": "xyz",
                ".cif": "cif",
                ".pdb": "pdb",
                ".poscar": "vasp",
                ".contcar": "vasp",
                ".vasp": "vasp",
            }
            source_format = fmt_map.get(ext, "unknown")
            basename = os.path.basename(structure).upper()
            if basename in ("POSCAR", "CONTCAR"):
                source_format = "vasp"

        from mace_mcp_server.schemas.outputs import StructureInfo

        result = StructureInfo(
            status="success",
            formula=atoms.get_chemical_formula(),
            num_atoms=len(atoms),
            symbols=symbols,
            unique_elements=unique_elements,
            positions=atoms.get_positions().tolist(),
            is_periodic=is_periodic,
            cell=cell,
            cell_lengths_A=cell_lengths,
            cell_angles_deg=cell_angles,
            volume_A3=volume,
            min_distance_A=float(min_dist) if np.isfinite(min_dist) else 0.0,
            has_overlap=len(overlaps) > 0,
            overlap_pairs=overlaps,
            source_format=source_format,
        )
        return result.model_dump_json(indent=2)

    @mcp.tool(
        annotations=ToolAnnotations(
            readOnlyHint=False, destructiveHint=False, idempotentHint=True
        ),
    )
    async def build_structure(
        build_type: Annotated[
            str,
            Field(
                description="'molecule' (named, e.g. H2O), 'bulk' (crystal), 'surface' (slab)"
            ),
        ],
        molecule_name: Annotated[
            str,
            Field(
                description="Molecule name/formula for build_type='molecule'. "
                "Examples: H2O, CH4, C2H5OH, C6H6, NH3, CO2"
            ),
        ] = "",
        symbol: Annotated[
            str,
            Field(description="Element for bulk/surface: 'Si', 'Cu', 'NaCl', 'GaAs'"),
        ] = "",
        crystal_structure: Annotated[
            str,
            Field(
                description="Crystal type: 'fcc', 'bcc', 'hcp', 'diamond', 'rocksalt', 'zincblende'"
            ),
        ] = "",
        lattice_constant_A: Annotated[
            float, Field(description="Lattice constant in Angstroms (0 = ASE default)")
        ] = 0,
        supercell: Annotated[
            list[int], Field(description="Supercell repetitions [nx, ny, nz]")
        ] = [1, 1, 1],
        miller_indices: Annotated[
            list[int], Field(description="Miller indices for surface: [1,1,1], [1,0,0], etc.")
        ] = [1, 1, 1],
        num_layers: Annotated[
            int, Field(description="Number of atomic layers in surface slab")
        ] = 4,
        vacuum_A: Annotated[
            float, Field(description="Vacuum thickness in Angstroms for surface slab")
        ] = 10.0,
        output_file: str = "",
    ) -> str:
        """Build atomic structures: molecules by name, bulk crystals, or surface slabs.

        Molecule: Builds from ASE's G2 database (100+ molecules).
        Bulk: Creates periodic crystal with specified lattice type.
        Surface: Creates slab with Miller indices, layers, and vacuum.
        """
        try:
            bt = build_type.lower()

            if bt == "molecule":
                if not molecule_name:
                    raise MACEToolError(
                        "molecule_name required for build_type='molecule'",
                        hint="Provide a molecule name like 'H2O', 'CH4', 'C6H6'.",
                        next_action="Set molecule_name and retry.",
                    )
                atoms = build_molecule(molecule_name)

            elif bt == "bulk":
                if not symbol or not crystal_structure:
                    raise MACEToolError(
                        "symbol and crystal_structure required for build_type='bulk'",
                        hint="Example: symbol='Cu', crystal_structure='fcc'.",
                        next_action="Set symbol and crystal_structure and retry.",
                    )
                atoms = build_bulk(symbol, crystal_structure, lattice_constant_A, supercell)

            elif bt == "surface":
                if not symbol or not crystal_structure:
                    raise MACEToolError(
                        "symbol and crystal_structure required for build_type='surface'",
                        hint="Example: symbol='Cu', crystal_structure='fcc', miller_indices=[1,1,1].",
                        next_action="Set symbol, crystal_structure, and miller_indices.",
                    )
                atoms = build_surface(
                    symbol,
                    crystal_structure,
                    miller_indices,
                    num_layers,
                    vacuum_A,
                    lattice_constant_A,
                    supercell,
                )
            else:
                raise MACEToolError(
                    f"Unknown build_type: '{build_type}'",
                    hint="Supported: 'molecule', 'bulk', 'surface'.",
                    next_action="Set build_type to 'molecule', 'bulk', or 'surface'.",
                )

            # Save if requested
            saved_path = None
            if output_file:
                from ase.io import write

                write(output_file, atoms, format="extxyz")
                saved_path = output_file

            from mace_mcp_server.schemas.outputs import BuildResult

            result = BuildResult(
                status="success",
                build_type=bt,
                formula=atoms.get_chemical_formula(),
                num_atoms=len(atoms),
                symbols=list(atoms.get_chemical_symbols()),
                positions=atoms.get_positions().tolist(),
                cell=atoms.get_cell().tolist() if any(atoms.get_pbc()) else None,
                is_periodic=any(atoms.get_pbc()),
                xyz_string=atoms_to_xyz_string(atoms),
                output_file=saved_path,
            )
            return result.model_dump_json(indent=2)

        except MACEToolError:
            raise
        except Exception as e:
            raise MACEToolError(
                f"Structure build failed: {e}",
                hint="Check the parameters for the selected build_type.",
                next_action="Verify molecule_name, symbol, or crystal_structure is correct.",
            ) from e

    @mcp.tool(
        annotations=ToolAnnotations(
            readOnlyHint=False, destructiveHint=False, idempotentHint=True
        ),
    )
    async def convert_structure(
        input_file: Annotated[str, Field(description="Path to input structure file")],
        output_file: Annotated[str, Field(description="Path for output file")],
        output_format: Annotated[
            str, Field(description="'xyz', 'extxyz', 'cif', 'vasp', 'pdb'")
        ] = "extxyz",
    ) -> str:
        """Convert structure between file formats using ASE.

        Supported: XYZ, extended XYZ, CIF, POSCAR/VASP, PDB.
        Extended XYZ preserves all metadata (energy, forces, stress).
        """
        try:
            from ase.io import write

            atoms = parse_structure_input(input_file)
            write(output_file, atoms, format=output_format)

            from mace_mcp_server.schemas.outputs import ConvertResult

            result = ConvertResult(
                status="success",
                input_file=input_file,
                output_file=output_file,
                output_format=output_format,
                num_atoms=len(atoms),
                formula=atoms.get_chemical_formula(),
            )
            return result.model_dump_json(indent=2)

        except Exception as e:
            raise MACEToolError(
                f"Structure conversion failed: {e}",
                hint="Check that the input file exists and output format is supported.",
                next_action="Supported formats: 'xyz', 'extxyz', 'cif', 'vasp', 'pdb'.",
            ) from e
