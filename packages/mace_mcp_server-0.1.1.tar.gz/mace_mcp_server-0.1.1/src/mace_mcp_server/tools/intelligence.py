"""MCP tool for intelligent parameter suggestion."""

from __future__ import annotations

from typing import Annotated

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from pydantic import Field

from mace_mcp_server.engine.builders import parse_structure_input
from mace_mcp_server.engine.calculator import (
    MACE_ANICC_ELEMENTS,
    MACE_OFF_ELEMENTS,
    MACEToolError,
)


def register_intelligence_tools(mcp: FastMCP) -> None:
    """Register intelligence tools on the FastMCP instance."""

    @mcp.tool(
        annotations=ToolAnnotations(
            readOnlyHint=True, idempotentHint=True, openWorldHint=False
        ),
    )
    async def suggest_parameters(
        structure: Annotated[
            str, Field(description="Path to structure file or inline XYZ string")
        ],
        task: Annotated[
            str,
            Field(
                description="'single_point', 'optimize', 'md', 'frequencies', 'eos'"
            ),
        ],
    ) -> str:
        """Suggest optimal MACE model and calculation parameters for a structure.

        Analyzes the structure's composition, periodicity, and size to recommend:
        - Best model (MACE-MP vs MACE-OFF vs MACE-OMOL)
        - Model size (speed vs accuracy trade-off)
        - Precision (float32 vs float64)
        - Task-specific parameters (fmax, timestep, ensemble, etc.)
        - Warnings (D3 dispersion rules, element support, etc.)
        """
        try:
            atoms = parse_structure_input(structure)
        except Exception as e:
            raise MACEToolError(
                f"Cannot parse structure for analysis: {e}",
                hint="Provide a valid structure file or inline XYZ.",
                next_action="Check the file path or format.",
            ) from e

        symbols = list(atoms.get_chemical_symbols())
        unique_elements = set(symbols)
        n_atoms = len(atoms)
        is_periodic = any(atoms.get_pbc())

        # Determine best model
        model, reasoning, warnings, alternatives = _suggest_model(
            unique_elements, is_periodic, n_atoms
        )

        # Determine model size
        if n_atoms > 200:
            model_size = "small"
            reasoning += " Using small model for speed with large system."
        elif n_atoms > 50:
            model_size = "medium"
            reasoning += " Medium model balances speed and accuracy."
        else:
            model_size = "medium"
            reasoning += " Medium model recommended for accuracy."

        # Determine precision
        if task in ("frequencies",):
            precision = "float64"
            reasoning += " float64 mandatory for Hessian accuracy."
        elif task in ("optimize",):
            precision = "float64"
            reasoning += " float64 recommended for optimization convergence."
        else:
            precision = "float32"
            reasoning += " float32 sufficient for this task."

        # Determine device
        device = "cpu"
        try:
            import torch

            if torch.cuda.is_available():
                device = "cuda"
                reasoning += " CUDA GPU detected."
        except ImportError:
            pass

        # Task-specific parameters
        task_params = _get_task_parameters(task, n_atoms, is_periodic, unique_elements)

        # Add dispersion warning
        if model in ("MACE-OFF",):
            warnings.append(
                "MACE-OFF includes D3BJ dispersion -- do NOT set dispersion=True (double-counting)."
            )

        from mace_mcp_server.schemas.outputs import ParameterSuggestion

        result = ParameterSuggestion(
            recommended_model=model,
            recommended_model_size=model_size,
            recommended_precision=precision,
            recommended_device=device,
            task_parameters=task_params,
            warnings=warnings,
            reasoning=reasoning.strip(),
            alternative_models=alternatives,
        )
        return result.model_dump_json(indent=2)


def _suggest_model(
    elements: set[str], is_periodic: bool, n_atoms: int
) -> tuple[str, str, list[str], list[str]]:
    """Suggest the best MACE model based on structure analysis.

    Returns (model, reasoning, warnings, alternatives).
    """
    warnings: list[str] = []
    alternatives: list[str] = []

    # Check if pure organic
    is_organic = elements.issubset(MACE_OFF_ELEMENTS)
    is_anicc_compatible = elements.issubset(MACE_ANICC_ELEMENTS)

    if is_organic and not is_periodic:
        # Organic molecule
        model = "MACE-OFF"
        reasoning = (
            f"Structure contains only organic elements ({sorted(elements)}), non-periodic. "
            "MACE-OFF is trained on wB97M-D3BJ for organic molecules."
        )
        alternatives = ["MACE-OMOL-0", "MACE-MPA-0"]
        if is_anicc_compatible and n_atoms < 30:
            alternatives.insert(0, "MACE-ANI-CC")
            warnings.append(
                "MACE-ANI-CC offers CCSD(T) accuracy for small H/C/N/O molecules."
            )
    elif is_organic and is_periodic:
        # Organic crystal
        model = "MACE-OFF"
        reasoning = (
            f"Periodic organic structure ({sorted(elements)}). "
            "MACE-OFF supports organic crystals and liquids."
        )
        alternatives = ["MACE-MPA-0", "MACE-OMOL-0"]
    elif is_periodic:
        # Inorganic/mixed periodic
        model = "MACE-MPA-0"
        reasoning = (
            f"Periodic structure with elements {sorted(elements)}. "
            "MACE-MPA-0 is the state-of-the-art materials foundation model."
        )
        alternatives = ["MACE-OMAT-0", "MACE-MP-0", "MACE-MATPES-PBE-0"]
        if not elements.issubset(MACE_OFF_ELEMENTS):
            warnings.append(
                f"Elements {sorted(elements - MACE_OFF_ELEMENTS)} not supported by MACE-OFF."
            )
    else:
        # Non-periodic, non-organic (organometallic, charged, etc.)
        has_metals = bool(
            elements
            - {"H", "C", "N", "O", "F", "P", "S", "Cl", "Br", "I", "B", "Si", "Se"}
        )
        if has_metals:
            model = "MACE-OMOL-0"
            reasoning = (
                f"Non-periodic structure with metal elements ({sorted(elements)}). "
                "MACE-OMOL supports organometallics and charged species."
            )
            alternatives = ["MACE-MPA-0", "MACE-MH-1"]
        else:
            model = "MACE-MPA-0"
            reasoning = (
                f"Non-periodic structure with elements {sorted(elements)}. "
                "MACE-MPA-0 as general-purpose default."
            )
            alternatives = ["MACE-OFF", "MACE-OMOL-0"]

    return model, reasoning, warnings, alternatives


def _get_task_parameters(
    task: str, n_atoms: int, is_periodic: bool, elements: set[str]
) -> dict:
    """Get task-specific parameter recommendations."""
    has_hydrogen = "H" in elements

    if task == "single_point":
        return {"precision": "float32"}

    if task == "optimize":
        return {
            "fmax": 0.01,
            "max_steps": min(500, n_atoms * 10),
            "optimizer": "BFGS",
            "optimize_cell": is_periodic,
            "precision": "float64",
        }

    if task == "md":
        timestep = 0.5 if has_hydrogen else 1.0
        return {
            "ensemble": "NVT",
            "temperature_K": 300.0,
            "timestep_fs": timestep,
            "num_steps": 1000,
            "friction": 0.005,
            "precision": "float32",
        }

    if task == "frequencies":
        return {
            "precision": "float64",
            "note": "Optimize with fmax=0.005 first!",
        }

    if task == "eos":
        return {
            "num_points": 7,
            "strain_range": 0.05,
            "eos_type": "birchmurnaghan",
            "precision": "float64",
        }

    return {}
