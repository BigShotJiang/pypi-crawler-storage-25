"""MCP tool definitions for MACE calculations."""
