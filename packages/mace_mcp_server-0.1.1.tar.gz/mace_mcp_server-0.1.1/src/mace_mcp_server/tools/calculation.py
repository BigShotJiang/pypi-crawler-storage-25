"""MCP tools for MACE calculations: single_point, optimize, molecular_dynamics, vibrational_frequencies.

Each tool is a thin wrapper that:
1. Validates input (element support, periodicity, dispersion rules)
2. Loads/caches the MACE calculator
3. Calls the engine runner
4. Returns structured Pydantic output
"""

from __future__ import annotations

import asyncio
from typing import Annotated

from mcp.server.fastmcp import Context, FastMCP
from mcp.types import ToolAnnotations
from pydantic import Field

from mace_mcp_server.engine.builders import parse_structure_input
from mace_mcp_server.engine.calculator import MACEToolError, get_calculator, validate_elements
from mace_mcp_server.engine.runner import (
    run_molecular_dynamics,
    run_optimization,
    run_single_point,
    run_vibrational_analysis,
)
from mace_mcp_server.engine.validators import (
    validate_periodicity_for_cell_opt,
    validate_periodicity_for_npt,
    validate_precision_for_hessian,
    validate_structure_for_frequencies,
    validate_structure_sanity,
)


def register_calculation_tools(mcp: FastMCP) -> None:
    """Register all calculation tools on the FastMCP instance."""

    @mcp.tool(
        annotations=ToolAnnotations(
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=False,
        ),
    )
    async def single_point(
        ctx: Context,
        structure: Annotated[
            str,
            Field(
                description="Path to structure file (XYZ, CIF, POSCAR, PDB) or inline XYZ string"
            ),
        ],
        model: Annotated[
            str,
            Field(
                description="MACE model: 'MACE-MPA-0', 'MACE-MP-0', 'MACE-OFF', 'MACE-OMAT-0', "
                "'MACE-OMOL', 'MACE-ANI-CC', or path to .model file"
            ),
        ] = "MACE-MPA-0",
        model_size: Annotated[
            str, Field(description="Model size: 'small', 'medium', 'large', 'extra_large'")
        ] = "medium",
        dispersion: Annotated[
            bool,
            Field(
                description="D3(BJ) dispersion correction. ONLY for MACE-MP models. "
                "NEVER use with MACE-OFF (double-counting)."
            ),
        ] = False,
        precision: Annotated[
            str, Field(description="'float32' (fast, MD) or 'float64' (accurate, optimization)")
        ] = "float32",
        device: Annotated[str, Field(description="'cpu' or 'cuda'")] = "cpu",
    ) -> str:
        """Run a single-point energy and force calculation on an atomic structure.

        Returns total energy (eV), per-atom forces (eV/A), stress tensor (periodic systems),
        per-atom energies, and force statistics.

        Use MACE-MPA-0 (default) for materials/crystals/surfaces.
        Use MACE-OFF for organic molecules (H,C,N,O,F,P,S,Cl,Br,I only).
        Use MACE-OMOL for organometallics or charged species.
        """
        try:
            atoms = parse_structure_input(structure)
            validate_structure_sanity(atoms)
            validate_elements(list(atoms.get_chemical_symbols()), model)

            cache = ctx.request_context.lifespan_context.get("model_cache", {})
            calc = get_calculator(model, model_size, precision, device, dispersion, cache)

            await ctx.info(f"Running single-point with {model}/{model_size}...")
            result = run_single_point(atoms, calc, model_name=f"{model}/{model_size}")

            from mace_mcp_server.schemas.outputs import SinglePointResult

            return SinglePointResult(**result).model_dump_json(indent=2)
        except MACEToolError:
            raise
        except Exception as e:
            raise MACEToolError(
                f"Single-point calculation failed: {e}",
                hint="Check that the structure is valid and the model supports all elements.",
                next_action="Use parse_structure to inspect the structure, or try suggest_parameters.",
            ) from e

    @mcp.tool(
        annotations=ToolAnnotations(
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=True,
        ),
    )
    async def optimize(
        ctx: Context,
        structure: Annotated[
            str, Field(description="Path to structure file or inline XYZ string")
        ],
        model: str = "MACE-MPA-0",
        model_size: str = "medium",
        fmax: Annotated[
            float,
            Field(
                description="Force convergence (eV/A). 0.05=general, 0.01=production, "
                "0.005=before frequencies",
                ge=0.0001,
                le=1.0,
            ),
        ] = 0.05,
        max_steps: Annotated[
            int, Field(description="Maximum optimization steps", ge=1, le=5000)
        ] = 500,
        optimizer: Annotated[
            str, Field(description="'BFGS' (default) or 'FIRE' (difficult convergence)")
        ] = "BFGS",
        optimize_cell: Annotated[
            bool,
            Field(description="Also optimize unit cell (periodic systems only, uses ExpCellFilter)"),
        ] = False,
        dispersion: bool = False,
        precision: str = "float64",
        device: str = "cpu",
        output_file: Annotated[
            str, Field(description="Path to save optimized structure as XYZ. Empty = no file output.")
        ] = "",
    ) -> str:
        """Optimize atomic positions (and optionally cell) to minimize energy.

        Uses BFGS or FIRE optimizer from ASE. Returns optimized structure with full
        energy/force trajectory for convergence analysis.

        Recommended fmax values:
        - 0.05 eV/A: Quick screening
        - 0.01 eV/A: Production calculations
        - 0.005 eV/A: Required before vibrational frequency calculations
        """
        try:
            atoms = parse_structure_input(structure)
            validate_structure_sanity(atoms)
            validate_elements(list(atoms.get_chemical_symbols()), model)
            validate_periodicity_for_cell_opt(atoms, optimize_cell)

            cache = ctx.request_context.lifespan_context.get("model_cache", {})
            calc = get_calculator(model, model_size, precision, device, dispersion, cache)

            await ctx.info(f"Optimizing with {model}/{model_size}, fmax={fmax}...")

            loop = asyncio.get_running_loop()

            def _opt_progress(step: int, total: int, msg: str):
                """Sync callback that schedules async progress reports."""
                asyncio.run_coroutine_threadsafe(
                    ctx.report_progress(step, total), loop
                )
                asyncio.run_coroutine_threadsafe(ctx.info(msg), loop)

            result = await loop.run_in_executor(
                None,
                lambda: run_optimization(
                    atoms,
                    calc,
                    fmax=fmax,
                    max_steps=max_steps,
                    optimizer_name=optimizer,
                    optimize_cell=optimize_cell,
                    output_file=output_file,
                    model_name=f"{model}/{model_size}",
                    progress_callback=_opt_progress,
                ),
            )

            status = "converged" if result["converged"] else "reached max steps"
            await ctx.info(
                f"Optimization {status} in {result['optimization_steps']} steps "
                f"(max_force={result['final_max_force']:.4f} eV/A)"
            )

            from mace_mcp_server.schemas.outputs import OptimizationResult

            return OptimizationResult(**result).model_dump_json(indent=2)
        except MACEToolError:
            raise
        except Exception as e:
            raise MACEToolError(
                f"Optimization failed: {e}",
                hint="Check structure validity and model compatibility.",
                next_action="Try FIRE optimizer, increase max_steps, or relax fmax.",
            ) from e

    @mcp.tool(
        annotations=ToolAnnotations(
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=False,
        ),
    )
    async def molecular_dynamics(
        ctx: Context,
        structure: Annotated[
            str, Field(description="Path to structure file or inline XYZ string")
        ],
        model: str = "MACE-MPA-0",
        model_size: str = "medium",
        ensemble: Annotated[
            str,
            Field(
                description="'NVT' (Langevin thermostat), 'NPT' (constant P, periodic only), "
                "'NVE' (energy conservation)"
            ),
        ] = "NVT",
        temperature_K: Annotated[
            float, Field(description="Temperature in Kelvin", ge=0.1, le=10000)
        ] = 300.0,
        timestep_fs: Annotated[
            float,
            Field(
                description="Integration timestep in fs. 0.5-1.0 for H-containing, "
                "1.0-2.0 for heavy atoms",
                ge=0.1,
                le=5.0,
            ),
        ] = 1.0,
        num_steps: Annotated[
            int, Field(description="Number of MD steps", ge=1, le=100000)
        ] = 100,
        pressure_GPa: Annotated[
            float, Field(description="External pressure for NPT (GPa)")
        ] = 0.0,
        friction: Annotated[
            float, Field(description="Langevin friction parameter for NVT (1/fs)")
        ] = 0.005,
        dispersion: bool = False,
        precision: str = "float32",
        device: str = "cpu",
        output_file: str = "",
    ) -> str:
        """Run molecular dynamics simulation.

        NVT: Langevin thermostat -- constant temperature, stochastic dynamics.
        NPT: Constant temperature + pressure -- requires periodic system with cell.
        NVE: Microcanonical -- tests energy conservation (no thermostat).

        Velocities initialized via Maxwell-Boltzmann distribution at target temperature.
        Use timestep 0.5-1.0 fs for systems with hydrogen, 1.0-2.0 fs for heavier atoms.
        """
        try:
            atoms = parse_structure_input(structure)
            validate_structure_sanity(atoms)
            validate_elements(list(atoms.get_chemical_symbols()), model)
            validate_periodicity_for_npt(atoms, ensemble)

            cache = ctx.request_context.lifespan_context.get("model_cache", {})
            calc = get_calculator(model, model_size, precision, device, dispersion, cache)

            await ctx.info(
                f"Running {ensemble} MD at {temperature_K}K, {num_steps} steps with {model}..."
            )

            loop = asyncio.get_running_loop()

            def _progress(step: int, total: int, msg: str):
                """Sync callback that schedules async progress reports."""
                asyncio.run_coroutine_threadsafe(
                    ctx.report_progress(step, total), loop
                )
                asyncio.run_coroutine_threadsafe(ctx.info(msg), loop)

            result = await loop.run_in_executor(
                None,
                lambda: run_molecular_dynamics(
                    atoms,
                    calc,
                    ensemble=ensemble,
                    temperature_K=temperature_K,
                    timestep_fs=timestep_fs,
                    num_steps=num_steps,
                    pressure_GPa=pressure_GPa,
                    friction=friction,
                    output_file=output_file,
                    model_name=f"{model}/{model_size}",
                    progress_callback=_progress,
                ),
            )

            await ctx.info(
                f"MD completed: {result['num_steps_completed']} steps, "
                f"T_mean={result['temperature_mean_K']:.1f}K in {result['time_seconds']:.1f}s"
            )

            from mace_mcp_server.schemas.outputs import MDResult

            return MDResult(**result).model_dump_json(indent=2)
        except MACEToolError:
            raise
        except Exception as e:
            raise MACEToolError(
                f"MD simulation failed: {e}",
                hint="Check structure, ensemble, and model compatibility.",
                next_action="Try reducing timestep, optimizing structure first, or using NVT.",
            ) from e

    @mcp.tool(
        annotations=ToolAnnotations(
            readOnlyHint=True,
            idempotentHint=True,
        ),
    )
    async def vibrational_frequencies(
        ctx: Context,
        structure: Annotated[
            str, Field(description="Path to structure file or inline XYZ string")
        ],
        model: str = "MACE-MPA-0",
        model_size: str = "medium",
        dispersion: bool = False,
        device: str = "cpu",
    ) -> str:
        """Calculate vibrational frequencies, normal modes, and thermodynamic properties.

        IMPORTANT PREREQUISITES:
        1. Structure MUST be at a local minimum (run optimize with fmax < 0.005 first)
        2. Uses float64 precision automatically (mandatory for accurate Hessians)

        For molecules: expect 3N-6 real frequencies (3N-5 for linear molecules).
        Imaginary frequencies at a non-transition-state indicate incomplete optimization.

        Returns frequencies (cm^-1), zero-point energy, and thermodynamic functions.
        """
        try:
            atoms = parse_structure_input(structure)
            validate_structure_sanity(atoms)
            validate_elements(list(atoms.get_chemical_symbols()), model)

            # Always use float64 for Hessians
            precision = validate_precision_for_hessian("float32")

            cache = ctx.request_context.lifespan_context.get("model_cache", {})
            calc = get_calculator(model, model_size, precision, device, dispersion, cache)

            # Check if structure is well-optimized
            atoms_check = atoms.copy()
            atoms_check.calc = calc
            forces = atoms_check.get_forces()
            import numpy as np

            max_force = float(np.max(np.linalg.norm(forces, axis=1)))
            warning = validate_structure_for_frequencies(max_force)
            if warning:
                await ctx.info(f"WARNING: {warning}")

            await ctx.info(f"Computing vibrational frequencies with {model}/{model_size} (float64)...")
            result = run_vibrational_analysis(atoms, calc, model_name=f"{model}/{model_size}")

            await ctx.info(
                f"Found {len(result['real_frequencies_cm_inv'])} real modes, "
                f"{len(result['imaginary_frequencies_cm_inv'])} imaginary"
            )

            from mace_mcp_server.schemas.outputs import VibrationalResult

            return VibrationalResult(**result).model_dump_json(indent=2)
        except MACEToolError:
            raise
        except Exception as e:
            raise MACEToolError(
                f"Vibrational analysis failed: {e}",
                hint="Ensure the structure is well-optimized (fmax < 0.005) and model supports all elements.",
                next_action="Run optimize with fmax=0.005 first, then retry vibrational_frequencies.",
            ) from e
