"""Pydantic schemas for MCP input/output validation."""
