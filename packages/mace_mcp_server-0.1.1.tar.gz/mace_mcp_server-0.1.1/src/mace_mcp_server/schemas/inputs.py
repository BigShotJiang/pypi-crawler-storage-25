"""Pydantic input models for typed tool parameters."""

from __future__ import annotations

from pydantic import BaseModel, Field


class CalculationParams(BaseModel):
    """Common parameters for MACE calculations."""

    structure: str = Field(description="Path to structure file (XYZ, CIF, POSCAR, PDB) or inline XYZ string")
    model: str = Field(default="MACE-MPA-0", description="MACE model name or path to .model file")
    model_size: str = Field(default="medium", description="Model size: 'small', 'medium', 'large', 'extra_large'")
    dispersion: bool = Field(default=False, description="D3(BJ) dispersion correction. ONLY for MACE-MP models.")
    precision: str = Field(default="float32", description="'float32' (fast) or 'float64' (accurate)")
    device: str = Field(default="cpu", description="'cpu' or 'cuda'")


class OptimizationParams(CalculationParams):
    """Parameters for geometry optimization."""

    fmax: float = Field(default=0.05, ge=0.0001, le=1.0, description="Force convergence (eV/A)")
    max_steps: int = Field(default=500, ge=1, le=5000, description="Maximum optimization steps")
    optimizer: str = Field(default="BFGS", description="'BFGS' or 'FIRE'")
    optimize_cell: bool = Field(default=False, description="Also optimize unit cell (periodic only)")
    precision: str = Field(default="float64", description="Default float64 for optimization accuracy")
    output_file: str = Field(default="", description="Path to save optimized structure")


class MDParams(CalculationParams):
    """Parameters for molecular dynamics."""

    ensemble: str = Field(default="NVT", description="'NVT', 'NPT', or 'NVE'")
    temperature_K: float = Field(default=300.0, ge=0.1, le=10000, description="Temperature in K")
    timestep_fs: float = Field(default=1.0, ge=0.1, le=5.0, description="Timestep in fs")
    num_steps: int = Field(default=100, ge=1, le=100000, description="Number of MD steps")
    pressure_GPa: float = Field(default=0.0, description="External pressure for NPT (GPa)")
    friction: float = Field(default=0.005, description="Langevin friction (1/fs) for NVT")
    output_file: str = Field(default="", description="Path to save trajectory")
