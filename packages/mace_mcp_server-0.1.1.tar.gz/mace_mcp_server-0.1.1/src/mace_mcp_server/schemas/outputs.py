"""Pydantic output models for structured MCP tool results.

These auto-generate outputSchema for the MCP protocol via JSON Schema.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class SinglePointResult(BaseModel):
    """Result from a single-point energy/force calculation."""

    status: Literal["success", "error"]
    energy_eV: float = Field(description="Total potential energy in eV")
    energy_per_atom_eV: float = Field(description="Energy per atom in eV")
    forces_eV_per_A: list[list[float]] = Field(description="Per-atom forces [N][3] in eV/A")
    max_force_eV_per_A: float = Field(description="Maximum force magnitude in eV/A")
    rms_force_eV_per_A: float = Field(description="RMS force in eV/A")
    stress_voigt_eV_per_A3: list[float] | None = Field(
        default=None, description="Stress tensor [xx,yy,zz,yz,xz,xy] in eV/A^3 (periodic only)"
    )
    per_atom_energies_eV: list[float] = Field(description="Per-atom energy decomposition in eV")
    atom_count: int
    symbols: list[str]
    is_periodic: bool
    model_used: str
    time_seconds: float


class OptimizationResult(BaseModel):
    """Result from geometry optimization."""

    status: Literal["success", "error"]
    converged: bool
    initial_energy_eV: float
    final_energy_eV: float
    energy_change_eV: float
    initial_max_force: float
    final_max_force: float
    final_rms_force: float
    optimization_steps: int
    trajectory_energies_eV: list[float] = Field(description="Energy at each step")
    trajectory_max_forces: list[float] = Field(description="Max force at each step")
    optimized_positions: list[list[float]]
    optimized_cell: list[list[float]] | None = Field(default=None, description="If periodic")
    optimized_xyz: str = Field(description="Full XYZ string of optimized structure")
    symbols: list[str]
    atom_count: int
    model_used: str
    time_seconds: float
    output_file: str | None = None


class MDResult(BaseModel):
    """Result from molecular dynamics simulation."""

    status: Literal["success", "error"]
    ensemble: str
    num_steps_completed: int
    temperature_target_K: float
    temperature_mean_K: float
    temperature_std_K: float
    energy_initial_eV: float
    energy_final_eV: float
    energy_mean_eV: float
    energy_drift_eV_per_atom_per_ps: float = Field(
        description="Energy drift for NVE conservation check"
    )
    trajectory_energies_eV: list[float]
    trajectory_temperatures_K: list[float]
    final_positions: list[list[float]]
    final_xyz: str
    symbols: list[str]
    atom_count: int
    model_used: str
    time_seconds: float
    output_file: str | None = None


class VibrationalResult(BaseModel):
    """Result from vibrational frequency analysis."""

    status: Literal["success", "error"]
    frequencies_cm_inv: list[float] = Field(description="All frequencies sorted descending")
    real_frequencies_cm_inv: list[float] = Field(description="Positive frequencies only")
    imaginary_frequencies_cm_inv: list[float] = Field(description="Imaginary (negative) frequencies")
    zero_point_energy_eV: float
    num_atoms: int
    num_modes: int
    expected_real_modes: int = Field(description="3N-6 (or 3N-5 for linear)")
    is_linear: bool
    has_imaginary: bool
    model_used: str
    time_seconds: float
    warning: str | None = None


class StructureInfo(BaseModel):
    """Result from parsing a structure file."""

    status: Literal["success", "error"]
    formula: str
    num_atoms: int
    symbols: list[str]
    unique_elements: list[str]
    positions: list[list[float]]
    is_periodic: bool
    cell: list[list[float]] | None = None
    cell_lengths_A: list[float] | None = None
    cell_angles_deg: list[float] | None = None
    volume_A3: float | None = None
    min_distance_A: float = Field(description="Minimum interatomic distance")
    has_overlap: bool = Field(description="True if any atoms < 0.5 A apart")
    overlap_pairs: list[list[int]] = Field(default_factory=list)
    source_format: str


class BuildResult(BaseModel):
    """Result from building a structure."""

    status: Literal["success", "error"]
    build_type: str
    formula: str
    num_atoms: int
    symbols: list[str]
    positions: list[list[float]]
    cell: list[list[float]] | None = None
    is_periodic: bool
    xyz_string: str = Field(description="Extended XYZ representation")
    output_file: str | None = None


class ConvertResult(BaseModel):
    """Result from structure format conversion."""

    status: Literal["success", "error"]
    input_file: str
    output_file: str
    output_format: str
    num_atoms: int
    formula: str


class EOSResult(BaseModel):
    """Result from equation of state calculation."""

    status: Literal["success", "error"]
    equilibrium_volume_A3: float
    equilibrium_energy_eV: float
    bulk_modulus_GPa: float
    bulk_modulus_derivative: float
    eos_type: str
    volumes_A3: list[float]
    energies_eV: list[float]
    num_points: int
    model_used: str
    time_seconds: float


class DescriptorResult(BaseModel):
    """Result from extracting MACE descriptors."""

    status: Literal["success", "error"]
    descriptors: list[list[float]] = Field(
        description="Per-atom feature vectors [num_atoms, num_features]"
    )
    num_atoms: int
    num_features: int
    invariants_only: bool
    symbols: list[str]
    model_used: str
    time_seconds: float


class ParameterSuggestion(BaseModel):
    """Result from parameter suggestion."""

    recommended_model: str
    recommended_model_size: str
    recommended_precision: str
    recommended_device: str
    task_parameters: dict = Field(description="Task-specific recommended parameters")
    warnings: list[str] = Field(default_factory=list)
    reasoning: str = Field(description="Human-readable explanation")
    alternative_models: list[str] = Field(default_factory=list)
