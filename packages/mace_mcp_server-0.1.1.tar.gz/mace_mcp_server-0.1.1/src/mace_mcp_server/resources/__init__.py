"""MCP resource definitions for MACE model catalog and references."""
