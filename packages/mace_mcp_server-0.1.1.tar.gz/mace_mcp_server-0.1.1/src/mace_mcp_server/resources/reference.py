"""MCP resources for unit conventions and example structures."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP


UNIT_CONVENTIONS = """# MACE + ASE Unit Conventions

All MACE calculations use ASE's internal unit system (based on eV, Angstrom, amu):

## Core Units
| Quantity | Unit | Notes |
|----------|------|-------|
| Energy | eV | 1 eV = 96.485 kJ/mol = 23.060 kcal/mol |
| Force | eV/A | Per-atom force vector components |
| Distance | Angstrom (A) | 1 A = 1e-10 m |
| Stress | eV/A^3 | Voigt notation: [xx, yy, zz, yz, xz, xy] |
| Pressure | eV/A^3 | 1 GPa = 1/160.21766 eV/A^3 |
| Temperature | Kelvin (K) | |
| Time | ASE time unit | 1 ASE time unit = 1.018e-14 s; use ase.units.fs |
| Mass | amu | Atomic mass units |
| Frequency | cm^-1 | Wavenumber (vibrational analysis) |

## Conversion Factors (via ase.units)
```python
from ase import units
units.eV        # 1.0 (base unit)
units.Angstrom  # 1.0 (base unit)
units.fs        # femtoseconds -> ASE time
units.GPa       # GPa -> eV/A^3
units.kB        # Boltzmann constant in eV/K
units.invcm     # cm^-1 -> eV (for frequencies)
```

## Important Notes
- MACE-OFF outputs are in eV but the model was trained at float64 precision
- Stress tensor uses Voigt notation: [xx, yy, zz, yz, xz, xy]
- For MD timesteps: always multiply by units.fs (e.g., 1.0 * units.fs)
- RMS force = sqrt(sum(|F_i|^2) / N_atoms), NOT sqrt(sum(f^2) / 3N)
- Per-atom energies from MACE are node energy decompositions (not total/N)
"""

EXAMPLE_STRUCTURES = {
    "water": {
        "description": "Water molecule (H2O) -- 3 atoms, non-periodic",
        "xyz": """3
Properties=species:S:1:pos:R:3 pbc="F F F"
O       0.00000000       0.00000000       0.11926200
H       0.00000000       0.76323900      -0.47704700
H       0.00000000      -0.76323900      -0.47704700
""",
    },
    "ethanol": {
        "description": "Ethanol molecule (C2H5OH) -- 9 atoms, non-periodic",
        "xyz": """9
Properties=species:S:1:pos:R:3 pbc="F F F"
C      -0.04789000      -0.56805000       0.00000000
C       1.41819000      -0.01743000       0.00000000
O       1.41819000       1.40894000       0.00000000
H      -0.60703000      -0.18695000       0.87069000
H      -0.60703000      -0.18695000      -0.87069000
H      -0.04789000      -1.66405000       0.00000000
H       1.97733000      -0.39854000       0.87069000
H       1.97733000      -0.39854000      -0.87069000
H       2.32397000       1.75244000       0.00000000
""",
    },
    "silicon": {
        "description": "Silicon diamond crystal -- 2 atoms, periodic (conventional cell)",
        "xyz": """2
Lattice="5.43 0.0 0.0 0.0 5.43 0.0 0.0 0.0 5.43" Properties=species:S:1:pos:R:3 pbc="T T T"
Si      0.00000000       0.00000000       0.00000000
Si      1.35750000       1.35750000       1.35750000
""",
    },
    "copper_fcc": {
        "description": "Copper FCC crystal -- 1 atom, periodic (primitive cell)",
        "xyz": """1
Lattice="0.0 1.805 1.805 1.805 0.0 1.805 1.805 1.805 0.0" Properties=species:S:1:pos:R:3 pbc="T T T"
Cu      0.00000000       0.00000000       0.00000000
""",
    },
    "nacl": {
        "description": "NaCl rocksalt crystal -- 2 atoms, periodic",
        "xyz": """2
Lattice="5.64 0.0 0.0 0.0 5.64 0.0 0.0 0.0 5.64" Properties=species:S:1:pos:R:3 pbc="T T T"
Na      0.00000000       0.00000000       0.00000000
Cl      2.82000000       2.82000000       2.82000000
""",
    },
    "cu111_surface": {
        "description": "Cu(111) surface slab -- 4 layers with 10A vacuum",
        "xyz": """4
Lattice="2.55 0.0 0.0 1.275 2.209 0.0 0.0 0.0 28.35" Properties=species:S:1:pos:R:3 pbc="T T T"
Cu      0.00000000       0.00000000      10.00000000
Cu      1.27500000       0.73631000      12.08141000
Cu      0.00000000       1.47262000      14.16282000
Cu      1.27500000       0.00000000      16.24423000
""",
    },
}


def register_reference_resources(mcp: FastMCP) -> None:
    """Register reference resources (units, examples)."""

    @mcp.resource("mace://units")
    def unit_conventions() -> str:
        """MACE + ASE unit conventions for all physical quantities.

        Reference for energy (eV), force (eV/A), distance (A), stress (eV/A^3),
        and conversion factors.
        """
        return UNIT_CONVENTIONS

    @mcp.resource("mace://examples/{example_type}")
    def example_structure(example_type: str) -> str:
        """Example XYZ structures for common use cases.

        Available types: water, ethanol, silicon, copper_fcc, nacl, cu111_surface.
        Returns extended XYZ format that can be used directly with MACE tools.
        """
        example = EXAMPLE_STRUCTURES.get(example_type.lower())
        if not example:
            available = ", ".join(sorted(EXAMPLE_STRUCTURES.keys()))
            return f"Unknown example type: '{example_type}'. Available: {available}"

        return f"# {example['description']}\n\n{example['xyz']}"
