"""MCP resources for MACE model catalog."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP


# Complete model catalog data
MODEL_CATALOG = {
    "mace-mpa-0": {
        "name": "MACE-MPA-0",
        "loader": "mace_mp() (default)",
        "model_key": "medium-mpa-0",
        "elements": 89,
        "domain": "Materials (state-of-the-art)",
        "default_dtype": "float32",
        "sizes": ["small", "medium", "large"],
        "license": "MIT",
        "description": (
            "The default and recommended model for materials science. Trained on Materials Project "
            "data with improved accuracy over the original MACE-MP-0. Covers 89 elements. "
            "Use for crystals, surfaces, interfaces, and bulk materials."
        ),
        "when_to_use": "Default choice for any periodic/materials system.",
        "when_not_to_use": "For organic molecules (use MACE-OFF) or organometallics (use MACE-OMOL).",
    },
    "mace-mp-0": {
        "name": "MACE-MP-0",
        "loader": "mace_mp(model='small')",
        "model_key": "small/medium/large",
        "elements": 89,
        "domain": "Materials (original)",
        "default_dtype": "float32",
        "sizes": ["small", "medium", "large"],
        "license": "MIT",
        "description": (
            "The original MACE foundation model for materials. Superseded by MACE-MPA-0 "
            "for most use cases but still valid for benchmarking."
        ),
        "when_to_use": "Benchmarking or reproducing published MACE-MP-0 results.",
        "when_not_to_use": "General use (prefer MACE-MPA-0).",
    },
    "mace-omat-0": {
        "name": "MACE-OMAT-0",
        "loader": "mace_mp(model='small-omat-0')",
        "model_key": "small-omat-0 / medium-omat-0",
        "elements": 89,
        "domain": "Materials (excellent phonons)",
        "default_dtype": "float32",
        "sizes": ["small", "medium"],
        "license": "ASL",
        "description": (
            "Trained on OMAT dataset from Meta. Excellent for phonon calculations and "
            "mechanical properties. Particularly good for oxide materials."
        ),
        "when_to_use": "Phonon calculations, elastic constants, oxide materials.",
        "when_not_to_use": "General materials (MACE-MPA-0 is more broadly validated).",
    },
    "mace-matpes-pbe": {
        "name": "MACE-MATPES-PBE-0",
        "loader": "mace_mp(model='mace-matpes-pbe-0')",
        "model_key": "mace-matpes-pbe-0",
        "elements": 89,
        "domain": "Materials (pure PBE, no +U)",
        "default_dtype": "float32",
        "sizes": ["medium"],
        "license": "ASL",
        "description": (
            "Trained on pure PBE DFT data without +U corrections. Use when you need "
            "consistency with PBE calculations (e.g., band structure comparisons)."
        ),
        "when_to_use": "When PBE-level consistency is needed without +U corrections.",
        "when_not_to_use": "Strongly correlated materials (use MACE-MPA-0 with +U corrections).",
    },
    "mace-matpes-r2scan": {
        "name": "MACE-MATPES-r2SCAN-0",
        "loader": "mace_mp(model='mace-matpes-r2scan-0')",
        "model_key": "mace-matpes-r2scan-0",
        "elements": 89,
        "domain": "Materials (r2SCAN meta-GGA)",
        "default_dtype": "float32",
        "sizes": ["medium"],
        "license": "ASL",
        "description": (
            "Trained on r2SCAN meta-GGA DFT data. r2SCAN provides better accuracy than PBE "
            "for many properties, especially energetics and geometries."
        ),
        "when_to_use": "When higher-accuracy DFT reference (r2SCAN) is preferred over PBE.",
        "when_not_to_use": "When PBE compatibility is needed.",
    },
    "mace-mh-1": {
        "name": "MACE-MH-1",
        "loader": "mace_mp(model='mh-1')",
        "model_key": "mh-1",
        "elements": 89,
        "domain": "Cross-domain (7 heads)",
        "default_dtype": "float32",
        "sizes": ["large"],
        "license": "ASL",
        "description": (
            "Multi-head model with 7 output heads trained on different datasets: "
            "omat_pbe, matpes_r2scan, omol, rgd1_b3lyp, mp_pbe_refit_add, spice_wB97M, oc20_usemppbe. "
            "Can predict properties at multiple DFT levels simultaneously."
        ),
        "when_to_use": "Cross-domain studies, comparing DFT functional predictions, catalysis.",
        "when_not_to_use": "Single-domain studies (simpler single-head models are faster).",
    },
    "mace-off": {
        "name": "MACE-OFF23",
        "loader": "mace_off()",
        "model_key": "small/medium/large",
        "elements": 10,
        "element_list": "H, C, N, O, F, P, S, Cl, Br, I",
        "domain": "Organic molecules",
        "default_dtype": "float64",
        "sizes": ["small", "medium", "large"],
        "license": "ASL",
        "description": (
            "Organic Force Field trained on SPICE dataset at wB97M-D3BJ level. "
            "Covers organic molecules, crystals, and liquids. "
            "IMPORTANT: Already includes D3BJ dispersion -- NEVER set dispersion=True."
        ),
        "when_to_use": "Organic molecules, drug-like molecules, polymers, organic crystals.",
        "when_not_to_use": "Any system with metals or elements not in H,C,N,O,F,P,S,Cl,Br,I.",
    },
    "mace-omol": {
        "name": "MACE-OMOL-0",
        "loader": "mace_omol()",
        "model_key": "extra_large",
        "elements": 83,
        "domain": "Molecules + metals",
        "default_dtype": "float64",
        "sizes": ["extra_large"],
        "license": "ASL",
        "description": (
            "Trained on OMol25 dataset at wB97M-VV10 level. Supports organometallics, "
            "charged species, and transition metal complexes. Includes charge and spin embedding."
        ),
        "when_to_use": "Organometallics, charged molecules, transition metal complexes.",
        "when_not_to_use": "Pure organic molecules (MACE-OFF is more accurate).",
    },
    "mace-polar": {
        "name": "MACE-Polar-1",
        "loader": "mace_polar()",
        "model_key": "polar-1-s/m/l",
        "elements": 83,
        "domain": "Polarizability/dielectrics",
        "default_dtype": "float32",
        "sizes": ["small", "medium", "large"],
        "license": "TBD",
        "description": (
            "Electrostatics foundation model for molecular chemistry. "
            "Predicts polarizability tensors and dielectric properties."
        ),
        "when_to_use": "Polarizability, dielectric constants, optical properties.",
        "when_not_to_use": "Standard energy/force calculations (use other models).",
    },
    "mace-anicc": {
        "name": "MACE-ANI-CC",
        "loader": "mace_anicc()",
        "model_key": "bundled",
        "elements": 4,
        "element_list": "H, C, N, O",
        "domain": "CCSD(T) accuracy",
        "default_dtype": "float64",
        "sizes": ["bundled"],
        "license": "MIT",
        "description": (
            "Trained on ANI-1ccx CCSD(T) data. Provides near coupled-cluster accuracy "
            "for small organic molecules with only H, C, N, O atoms."
        ),
        "when_to_use": "Small organic molecules when highest accuracy is needed.",
        "when_not_to_use": "Molecules with elements beyond H,C,N,O or large systems.",
    },
}


def register_model_resources(mcp: FastMCP) -> None:
    """Register model catalog resources."""

    @mcp.resource("mace://models")
    def list_models() -> str:
        """Complete catalog of MACE foundation models.

        Lists all 11 available models with their capabilities, supported elements,
        recommended use cases, and loading instructions.
        """
        lines = ["# MACE Foundation Models Catalog\n"]
        lines.append(f"Total models: {len(MODEL_CATALOG)}\n")

        for model_id, info in MODEL_CATALOG.items():
            lines.append(f"## {info['name']}")
            lines.append(f"- **ID:** {model_id}")
            lines.append(f"- **Loader:** `{info['loader']}`")
            lines.append(f"- **Elements:** {info['elements']}")
            if "element_list" in info:
                lines.append(f"- **Element list:** {info['element_list']}")
            lines.append(f"- **Domain:** {info['domain']}")
            lines.append(f"- **Default dtype:** {info['default_dtype']}")
            lines.append(f"- **Sizes:** {', '.join(info['sizes'])}")
            lines.append(f"- **License:** {info['license']}")
            lines.append(f"- **Description:** {info['description']}")
            lines.append(f"- **When to use:** {info['when_to_use']}")
            lines.append(f"- **When NOT to use:** {info['when_not_to_use']}")
            lines.append("")

        return "\n".join(lines)

    @mcp.resource("mace://models/{model_id}")
    def model_details(model_id: str) -> str:
        """Detailed information about a specific MACE model.

        Supported model IDs: mace-mpa-0, mace-mp-0, mace-off, mace-omat-0,
        mace-matpes-pbe, mace-matpes-r2scan, mace-mh-1, mace-omol, mace-polar, mace-anicc.
        """
        info = MODEL_CATALOG.get(model_id.lower())
        if not info:
            available = ", ".join(sorted(MODEL_CATALOG.keys()))
            return f"Unknown model ID: '{model_id}'. Available models: {available}"

        lines = [f"# {info['name']}\n"]
        for key, value in info.items():
            if key == "name":
                continue
            label = key.replace("_", " ").title()
            lines.append(f"**{label}:** {value}")

        return "\n".join(lines)
