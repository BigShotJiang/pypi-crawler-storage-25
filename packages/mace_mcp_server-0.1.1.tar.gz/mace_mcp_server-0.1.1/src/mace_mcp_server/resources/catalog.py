"""MCP resources for structure catalog (example structures by category)."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from mace_mcp_server.resources.reference import EXAMPLE_STRUCTURES


def register_catalog_resources(mcp: FastMCP) -> None:
    """Register catalog resources."""

    @mcp.resource("mace://catalog")
    def list_catalog() -> str:
        """List all available example structures in the catalog.

        Returns a summary of each example with description and atom count.
        """
        lines = ["# MACE Structure Catalog\n"]
        lines.append("Available example structures for testing and demonstration:\n")

        for key, info in EXAMPLE_STRUCTURES.items():
            # Count atoms from first line of XYZ
            xyz = info["xyz"].strip()
            n_atoms = int(xyz.split("\n")[0].strip())
            lines.append(f"- **{key}**: {info['description']} ({n_atoms} atoms)")

        lines.append("")
        lines.append("Use `mace://examples/{type}` to get the full XYZ structure.")
        return "\n".join(lines)
