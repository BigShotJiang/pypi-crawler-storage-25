"""MACE MCP Server -- AI-callable atomistic simulation tools.

Entry point for the mace-mcp-server command. Sets up FastMCP with lifespan
model caching, registers all tools/resources/prompts, and runs stdio transport.
"""

from __future__ import annotations

import logging
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP

logger = logging.getLogger(__name__)


@asynccontextmanager
async def server_lifespan(server: FastMCP) -> AsyncIterator[dict]:
    """Manage MACE model lifecycle.

    Models are loaded lazily on first use but cached for subsequent calls.
    A typical MACE model load takes 5-30 seconds; caching avoids this
    penalty on every tool invocation.
    """
    model_cache: dict = {}
    logger.info("MACE MCP Server starting up...")

    try:
        yield {"model_cache": model_cache}
    finally:
        # Cleanup: free GPU memory
        logger.info("MACE MCP Server shutting down, clearing %d cached models...", len(model_cache))
        model_cache.clear()
        try:
            import torch

            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except ImportError:
            pass


mcp = FastMCP(
    "mace-server",
    instructions=(
        "MACE machine learning interatomic potential server for atomistic simulations. "
        "Provides tools for energy/force calculations, geometry optimization, molecular dynamics, "
        "vibrational analysis, structure building, and more. "
        "Supports 11 foundation models covering 89 elements. "
        "All energies in eV, forces in eV/A, distances in Angstroms. "
        "Use the suggest_parameters tool if unsure which model or settings to use."
    ),
    lifespan=server_lifespan,
)

# Register all components
from mace_mcp_server.prompts.workflows import register_prompts
from mace_mcp_server.resources.catalog import register_catalog_resources
from mace_mcp_server.resources.models import register_model_resources
from mace_mcp_server.resources.reference import register_reference_resources
from mace_mcp_server.tools.analysis import register_analysis_tools
from mace_mcp_server.tools.calculation import register_calculation_tools
from mace_mcp_server.tools.intelligence import register_intelligence_tools
from mace_mcp_server.tools.structure import register_structure_tools

register_calculation_tools(mcp)
register_structure_tools(mcp)
register_analysis_tools(mcp)
register_intelligence_tools(mcp)
register_model_resources(mcp)
register_reference_resources(mcp)
register_catalog_resources(mcp)
register_prompts(mcp)


def main():
    """Entry point for the mace-mcp-server command."""
    # CRITICAL: Never write to stdout in stdio mode (corrupts JSON-RPC)
    # All logging goes to stderr
    logging.basicConfig(
        stream=sys.stderr,
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
