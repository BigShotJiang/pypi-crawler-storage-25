# MACE MCP Server -- Design Document v2

**Author:** Zicheng Zhao, Northeastern University
**Date:** 2026-04-11
**Status:** Research Complete / Ready for Implementation
**Version:** 2.0 (Standalone project, informed by official MCP spec + competitive analysis)

---

## 1. Executive Summary

**mace-mcp-server** is a standalone, pip-installable MCP (Model Context Protocol) server that gives any AI assistant direct access to MACE machine learning interatomic potentials. Researchers can ask an AI to run atomistic simulations -- energy calculations, geometry optimizations, molecular dynamics, vibrational analysis, and more -- through natural language.

This is a **new open-source project for the research community**, not tied to any specific web interface.

### Why Build This?

**The gap:** 8 scientific MCP servers exist (mcp.science/GPAW, MCP_LAMMPS, mcp-atomictoolkit, VASPilot, ABACUS, OpenMM, molecule-mcp, ChEMBL) -- **none support MACE**. The closest competitor, `mcp-atomictoolkit`, wraps KIM/NequIP/Orb but not MACE. MACE is the most widely-used ML force field with 11 foundation models covering 89 elements, yet has zero MCP integration.

**The opportunity:** MACE-MP-0 and MACE-OFF are the de facto standard ML potentials for materials and organic chemistry respectively. A MACE MCP server would be the first to offer sub-second atomistic simulations through conversational AI.

---

## 2. Competitive Landscape

| Server | Domain | Calculator | Tools | Resources | Prompts | Distribution | Key Pattern |
|--------|--------|-----------|-------|-----------|---------|-------------|-------------|
| **mcp-atomictoolkit** | General atomistic | KIM, NequIP, Orb | 8 workflow tools | No | No | Clone + pip | Artifact store, TaskConfig, structured errors with hints |
| **mcp.science/GPAW** | DFT | GPAW | 3 tools | URI-based | No | `uvx mcp-science` | SSH-to-HPC, cross-server URI interop |
| **MCP_LAMMPS** | Classical MD | LAMMPS | 20+ tools | No | No | Clone + pip | SMILES pipeline, SLURM, simulation lifecycle |
| **VASPilot** | DFT | VASP | 15+ tools | No | No | Clone | CrewAI multi-agent, SQLite persistence, calc chaining |
| **ABACUS MCP** | DFT | ABACUS | 20+ tools | 5 URI resources | 7 prompts | Clone | **Only server using all 3 MCP primitives**, intelligent param suggestion |
| **OpenMM MCP** | Classical MD | OpenMM | Many | No | No | Clone | Async task management, template configs |
| **molecule-mcp** | Visualization | PyMOL/GROMACS | 25+ tools | 1 | No | pip (chatmol) | Thin wrapper over existing libraries |
| **mace-mcp-server (ours)** | **ML force fields** | **MACE (11 models)** | **10 tools** | **4 resources** | **3 prompts** | **`pip install` / `uvx`** | **All 3 primitives, structured output, tool annotations, progress reporting** |

### What We Adopt from Each

| Pattern | Source | How We Use It |
|---------|--------|---------------|
| All 3 MCP primitives (Tools + Resources + Prompts) | ABACUS MCP | Full implementation with model catalog resources, workflow prompts |
| Structured errors with LLM-friendly hints | mcp-atomictoolkit | Every error includes `hint` and `next_action` fields |
| Tool annotations (`readOnlyHint`, `destructiveHint`) | MCP spec + ABACUS | Mark read-only tools, flag long-running computations |
| Progress reporting for long calculations | MCP spec | `ctx.report_progress()` for optimization and MD |
| `outputSchema` for structured results | MCP spec (2025-06-18) | Pydantic dataclasses auto-generate JSON Schema |
| PyPI distribution via `uvx` | mcp.science | `uvx mace-mcp-server` or `pip install mace-mcp-server` |
| Lifespan model caching | FastMCP best practice | Load MACE models once at startup |
| Intelligent parameter suggestion | ABACUS MCP | `suggest_parameters` tool recommends model + settings |

### What We Avoid

| Anti-pattern | Source | Why |
|-------------|--------|-----|
| Global mutable state | molecule-mcp | Fragile; use lifespan context instead |
| SSH-only execution | mcp.science/GPAW | Too narrow; support local execution first |
| 50+ tools | MCP_LAMMPS, ABACUS | Cognitive overload for LLMs; keep to 10-12 focused tools |
| No error context | molecule-mcp | LLMs need actionable hints to self-correct |
| `run_shell_command` | molecule-mcp/GROMACS | Security vulnerability |

---

## 3. Architecture

```
                    Claude Code / Claude Desktop / VS Code / Any MCP Host
                                        |
                                        | stdio or Streamable HTTP (JSON-RPC 2.0)
                                        |
                              +---------------------+
                              |  mace-mcp-server    |
                              |  (Python / FastMCP) |
                              +---------------------+
                                        |
                  +---------------------+---------------------+
                  |                     |                     |
            10 Tools              4 Resources           3 Prompts
                  |                     |                     |
    +-------------+--------+     +-----+-----+        +------+------+
    | Calculation (4)      |     | models    |        | analyze     |
    |  single_point        |     | catalog   |        | optimize    |
    |  optimize            |     | units     |        | md_simulate |
    |  molecular_dynamics  |     | examples  |        +-------------+
    |  vibrational_freq    |     +-----------+
    +----------------------+
    | Structure (3)        |
    |  parse_structure     |
    |  build_structure     |
    |  convert_structure   |
    +----------------------+
    | Analysis (2)         |
    |  equation_of_state   |
    |  extract_descriptors |
    +----------------------+
    | Intelligence (1)     |
    |  suggest_parameters  |
    +----------------------+
                  |
        +---------+---------+
        |  MACE Engine      |
        |  (mace-torch +    |
        |   ASE + PyTorch)  |
        +-------------------+
```

### Package Structure (Standalone)

```
mace-mcp-server/
  pyproject.toml               # Package metadata, dependencies, entry points
  LICENSE                      # MIT
  README.md                    # Installation, usage, examples
  src/
    mace_mcp_server/
      __init__.py              # Version, package metadata
      server.py                # FastMCP instance, lifespan, entry point
      tools/
        __init__.py
        calculation.py         # single_point, optimize, molecular_dynamics, vibrational_freq
        structure.py           # parse_structure, build_structure, convert_structure
        analysis.py            # equation_of_state, extract_descriptors
        intelligence.py        # suggest_parameters
      resources/
        __init__.py
        models.py              # mace://models, mace://models/{model_id}
        catalog.py             # mace://catalog, mace://catalog/{structure_id}
        reference.py           # mace://units, mace://examples/{type}
      prompts/
        __init__.py
        workflows.py           # analyze_structure, optimize_molecule, md_simulation
      engine/
        __init__.py
        calculator.py          # MACE calculator loading + caching
        runner.py              # Calculation execution (single-point, opt, MD, freq)
        builders.py            # ASE structure builders (molecule, bulk, surface)
        validators.py          # Scientific validation checks
      schemas/
        __init__.py
        inputs.py              # Pydantic input models (typed parameters)
        outputs.py             # Pydantic output models (structured results with outputSchema)
  tests/
    test_tools.py
    test_engine.py
    test_resources.py
    conftest.py                # Fixtures: sample structures, mock calculators
```

### Why This Structure?

- **`engine/`** contains all scientific logic, independent of MCP. This is testable without running the server.
- **`tools/`** are thin MCP wrappers over engine functions. Each tool validates input, calls the engine, formats output.
- **`schemas/`** defines Pydantic models that auto-generate `inputSchema` and `outputSchema` for the MCP protocol.
- **`resources/`** and **`prompts/`** are separate from tools (different MCP primitives, different control model).
- Tests can run against `engine/` directly without MCP transport overhead.

---

## 4. Technology Stack

| Component | Choice | Rationale |
|-----------|--------|-----------|
| **Language** | Python 3.10+ | MACE is Python; direct import, no subprocess overhead |
| **MCP SDK** | `mcp[cli]` >= 1.26 (FastMCP) | High-level decorators, auto-schema from type hints, lifespan |
| **MCP Protocol** | 2025-06-18 | Latest spec with tool annotations, outputSchema, tasks |
| **Transport** | stdio (primary), Streamable HTTP (optional) | stdio for Claude Code/Desktop; HTTP for remote/multi-user |
| **Schema** | Pydantic v2 | Auto JSON Schema generation for inputSchema + outputSchema |
| **Calculator** | mace-torch >= 0.3.10 | Foundation models, custom models, descriptors, Hessians |
| **Atomistic** | ASE >= 3.22 | Structure I/O, optimization, MD, phonons, EOS |
| **Compute** | PyTorch >= 2.0 | GPU support, model loading |
| **Distribution** | PyPI (`pip install mace-mcp-server`) | Standard Python packaging; also works with `uvx` |

### Dependencies

```toml
[project]
dependencies = [
    "mcp[cli]>=1.26.0",
    "mace-torch>=0.3.10",
    "ase>=3.22.0",
    "torch>=2.0.0",
    "numpy>=1.24.0",
    "pydantic>=2.0.0",
]

[project.optional-dependencies]
dispersion = ["torch-dftd>=0.4.0"]   # D3 corrections
gpu = ["torch>=2.0.0+cu118"]         # CUDA support
dev = ["pytest", "pytest-asyncio"]

[project.scripts]
mace-mcp-server = "mace_mcp_server.server:main"
```

---

## 5. Foundation Models Supported (11 Models, Verified Against Docs)

| Model | Loader | Elements | Domain | Default dtype | Sizes | License |
|-------|--------|----------|--------|---------------|-------|---------|
| **MACE-MPA-0** | `mace_mp()` (default) | 89 | Materials (state-of-art) | float32 | medium | MIT |
| **MACE-MP-0** | `mace_mp(model="small")` | 89 | Materials (original) | float32 | small/medium/large | MIT |
| **MACE-OMAT-0** | `mace_mp(model="small-omat-0")` | 89 | Materials (excellent phonons) | float32 | small/medium | ASL |
| **MACE-MATPES-PBE-0** | `mace_mp(model="mace-matpes-pbe-0")` | 89 | Materials (pure PBE, no +U) | float32 | medium | ASL |
| **MACE-MATPES-r2SCAN-0** | `mace_mp(model="mace-matpes-r2scan-0")` | 89 | Materials (r2SCAN meta-GGA) | float32 | medium | ASL |
| **MACE-MH-1** | `mace_mp(model="mh-1")` | 89 | Cross-domain (7 heads) | float32 | large | ASL |
| **MACE-OFF23** | `mace_off()` | 10 (organic) | Organic molecules | **float64** | small/medium/large | ASL |
| **MACE-OMOL-0** | `mace_omol()` | 83 | Molecules + metals | float64 | extra_large | ASL |
| **MACE-Polar-1** | `mace_polar()` | 83 | Polarizability/dielectrics | float32 | s/m/l | TBD |
| **MACE-ANI-CC** | `mace_anicc()` | 4 (H,C,N,O) | CCSD(T) accuracy | float64 | bundled | MIT |
| **Custom** | `MACECalculator(model_paths=...)` | varies | User-trained | varies | varies | varies |

### Key Corrections from v1 Design
1. **Default model is now MACE-MPA-0** (not MACE-MP-0) -- `mace_mp()` with no args loads `medium-mpa-0`
2. **MACE-OFF defaults to float64**, not float32
3. **5 additional models** not in v1: MACE-OMAT-0, MACE-MATPES-PBE-0, MACE-MATPES-r2SCAN-0, MACE-MH-1, MACE-OMOL-0, MACE-Polar-1, MACE-ANI-CC
4. **Multi-head models** (MH-1) have 7 heads: omat_pbe, matpes_r2scan, omol, rgd1_b3lyp, mp_pbe_refit_add, spice_wB97M, oc20_usemppbe

---

## 6. Tool Design (10 Tools)

All tools use proper MCP tool annotations, Pydantic input/output schemas, and structured error handling.

### 6.1 Calculation Tools (4)

#### `single_point` -- Energy, forces, stress evaluation

```python
@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,        # Does not modify files
        destructiveHint=False,
        idempotentHint=True,      # Same input = same output
        openWorldHint=False,      # No external network calls (models cached)
    ),
)
async def single_point(
    ctx: Context,
    structure: Annotated[str, Field(description="Path to structure file (XYZ, CIF, POSCAR, PDB) or inline XYZ string")],
    model: Annotated[str, Field(description="MACE model: 'MACE-MP-0', 'MACE-MPA-0', 'MACE-OFF', 'MACE-OMAT-0', 'MACE-OMOL', 'MACE-ANI-CC', or path to .model file")] = "MACE-MPA-0",
    model_size: Annotated[str, Field(description="Model size: 'small', 'medium', 'large', 'extra_large'")] = "medium",
    dispersion: Annotated[bool, Field(description="D3(BJ) dispersion correction. ONLY for MACE-MP models. NEVER use with MACE-OFF (double-counting).")] = False,
    precision: Annotated[str, Field(description="'float32' (fast, MD) or 'float64' (accurate, optimization)")] = "float32",
    device: Annotated[str, Field(description="'cpu' or 'cuda'")] = "cpu",
) -> SinglePointResult:
    """Run a single-point energy and force calculation on an atomic structure.

    Returns total energy (eV), per-atom forces (eV/A), stress tensor (periodic systems),
    per-atom energies, and force statistics.

    Use MACE-MPA-0 (default) for materials/crystals/surfaces.
    Use MACE-OFF for organic molecules (H,C,N,O,F,P,S,Cl,Br,I only).
    Use MACE-OMOL for organometallics or charged species.
    """
```

**Output (auto-generates outputSchema via Pydantic):**
```python
@dataclass
class SinglePointResult:
    status: Literal["success", "error"]
    energy_eV: float                        # Total potential energy
    energy_per_atom_eV: float               # Energy / N_atoms
    forces_eV_per_A: list[list[float]]      # Per-atom forces [N][3]
    max_force_eV_per_A: float               # max(|F_i|)
    rms_force_eV_per_A: float               # sqrt(sum(|F_i|^2) / N_atoms)
    stress_voigt_eV_per_A3: list[float] | None  # [xx,yy,zz,yz,xz,xy] if periodic
    per_atom_energies_eV: list[float]       # Node energy decomposition
    atom_count: int
    symbols: list[str]
    is_periodic: bool
    model_used: str
    time_seconds: float
```

#### `optimize` -- Geometry optimization

```python
@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=False,       # Creates optimized structure file
        destructiveHint=False,
        idempotentHint=True,
    ),
)
async def optimize(
    ctx: Context,
    structure: Annotated[str, Field(description="Path to structure file or inline XYZ string")],
    model: str = "MACE-MPA-0",
    model_size: str = "medium",
    fmax: Annotated[float, Field(description="Force convergence (eV/A). 0.05=general, 0.01=production, 0.005=before frequencies", ge=0.0001, le=1.0)] = 0.05,
    max_steps: Annotated[int, Field(description="Maximum optimization steps", ge=1, le=5000)] = 500,
    optimizer: Annotated[str, Field(description="'BFGS' (default) or 'FIRE' (difficult convergence)")] = "BFGS",
    optimize_cell: Annotated[bool, Field(description="Also optimize unit cell (periodic systems only, uses ExpCellFilter)")] = False,
    dispersion: bool = False,
    precision: str = "float64",   # Default to float64 for optimization
    device: str = "cpu",
    output_file: Annotated[str, Field(description="Path to save optimized structure as XYZ. Empty = no file output.")] = "",
) -> OptimizationResult:
    """Optimize atomic positions (and optionally cell) to minimize energy.

    Uses BFGS or FIRE optimizer from ASE. Returns optimized structure with full
    energy/force trajectory for convergence analysis.

    Recommended fmax values:
    - 0.05 eV/A: Quick screening
    - 0.01 eV/A: Production calculations
    - 0.005 eV/A: Required before vibrational frequency calculations
    """
```

**Output:**
```python
@dataclass
class OptimizationResult:
    status: Literal["success", "error"]
    converged: bool
    initial_energy_eV: float
    final_energy_eV: float
    energy_change_eV: float
    initial_max_force: float
    final_max_force: float
    final_rms_force: float
    optimization_steps: int
    trajectory_energies_eV: list[float]      # Energy at each step
    trajectory_max_forces: list[float]        # Max force at each step
    optimized_positions: list[list[float]]
    optimized_cell: list[list[float]] | None  # If periodic
    optimized_xyz: str                        # Full XYZ string of optimized structure
    symbols: list[str]
    atom_count: int
    model_used: str
    time_seconds: float
    output_file: str | None                   # Path if saved
```

#### `molecular_dynamics` -- NVT/NPT/NVE simulations

```python
@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=False,       # Produces trajectory output
        destructiveHint=False,
        idempotentHint=False,     # Stochastic (velocity initialization)
    ),
)
async def molecular_dynamics(
    ctx: Context,
    structure: str,
    model: str = "MACE-MPA-0",
    model_size: str = "medium",
    ensemble: Annotated[str, Field(description="'NVT' (Langevin thermostat), 'NPT' (constant P, periodic only), 'NVE' (energy conservation)")] = "NVT",
    temperature_K: Annotated[float, Field(description="Temperature in Kelvin", ge=0.1, le=10000)] = 300.0,
    timestep_fs: Annotated[float, Field(description="Integration timestep in fs. 0.5-1.0 for H-containing, 1.0-2.0 for heavy atoms", ge=0.1, le=5.0)] = 1.0,
    num_steps: Annotated[int, Field(description="Number of MD steps", ge=1, le=100000)] = 100,
    pressure_GPa: Annotated[float, Field(description="External pressure for NPT (GPa)")] = 0.0,
    friction: Annotated[float, Field(description="Langevin friction parameter for NVT (1/fs)")] = 0.005,
    dispersion: bool = False,
    precision: str = "float32",    # float32 is fine for MD
    device: str = "cpu",
    output_file: str = "",
) -> MDResult:
    """Run molecular dynamics simulation.

    NVT: Langevin thermostat -- constant temperature, stochastic dynamics.
    NPT: Constant temperature + pressure -- requires periodic system with cell.
    NVE: Microcanonical -- tests energy conservation (no thermostat).

    Velocities initialized via Maxwell-Boltzmann distribution at target temperature.
    Use timestep 0.5-1.0 fs for systems with hydrogen, 1.0-2.0 fs for heavier atoms.
    """
```

**Output:**
```python
@dataclass
class MDResult:
    status: Literal["success", "error"]
    ensemble: str
    num_steps_completed: int
    temperature_target_K: float
    temperature_mean_K: float
    temperature_std_K: float
    energy_initial_eV: float
    energy_final_eV: float
    energy_mean_eV: float
    energy_drift_eV_per_atom_per_ps: float   # For NVE conservation check
    trajectory_energies_eV: list[float]
    trajectory_temperatures_K: list[float]
    final_positions: list[list[float]]
    final_xyz: str
    symbols: list[str]
    atom_count: int
    model_used: str
    time_seconds: float
    output_file: str | None
```

#### `vibrational_frequencies` -- Normal modes and thermodynamics (NEW)

```python
@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,
        idempotentHint=True,
    ),
)
async def vibrational_frequencies(
    ctx: Context,
    structure: str,
    model: str = "MACE-MPA-0",
    model_size: str = "medium",
    dispersion: bool = False,
    device: str = "cpu",
) -> VibrationalResult:
    """Calculate vibrational frequencies, normal modes, and thermodynamic properties.

    IMPORTANT PREREQUISITES:
    1. Structure MUST be at a local minimum (run optimize with fmax < 0.005 first)
    2. Uses float64 precision automatically (mandatory for accurate Hessians)

    For molecules: expect 3N-6 real frequencies (3N-5 for linear molecules).
    Imaginary frequencies at a non-transition-state indicate incomplete optimization.

    Returns frequencies (cm^-1), zero-point energy, and thermodynamic functions.
    """
```

**Output:**
```python
@dataclass
class VibrationalResult:
    status: Literal["success", "error"]
    frequencies_cm_inv: list[float]       # All frequencies, sorted descending
    real_frequencies_cm_inv: list[float]   # Positive frequencies only
    imaginary_frequencies_cm_inv: list[float]  # Negative = imaginary
    zero_point_energy_eV: float
    num_atoms: int
    num_modes: int
    expected_real_modes: int              # 3N-6 (or 3N-5 for linear)
    is_linear: bool
    has_imaginary: bool
    model_used: str
    time_seconds: float
    warning: str | None                   # Set if imaginary frequencies detected
```

### 6.2 Structure Tools (3)

#### `parse_structure` -- Read and analyze any structure file

```python
@mcp.tool(
    annotations=ToolAnnotations(readOnlyHint=True, idempotentHint=True, openWorldHint=False),
)
async def parse_structure(
    structure: Annotated[str, Field(description="Path to structure file (XYZ, CIF, POSCAR, PDB)")],
) -> StructureInfo:
    """Parse an atomic structure file and return detailed analysis.

    Reports composition, formula, periodicity, cell parameters, bounding box,
    minimum interatomic distances (overlap detection), and reference data.
    Supports: XYZ, extended XYZ, CIF, POSCAR/CONTCAR, PDB.
    """
```

#### `build_structure` -- Generate structures programmatically

```python
@mcp.tool(
    annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=True),
)
async def build_structure(
    build_type: Annotated[str, Field(description="'molecule' (named, e.g. H2O), 'bulk' (crystal), 'surface' (slab)")],
    # Molecule parameters
    molecule_name: Annotated[str, Field(description="Molecule name/formula for build_type='molecule'. Examples: H2O, CH4, C2H5OH, C6H6, NH3, CO2")] = "",
    # Bulk parameters
    symbol: Annotated[str, Field(description="Element for bulk/surface: 'Si', 'Cu', 'NaCl', 'GaAs'")] = "",
    crystal_structure: Annotated[str, Field(description="Crystal type: 'fcc', 'bcc', 'hcp', 'diamond', 'rocksalt', 'zincblende'")] = "",
    lattice_constant_A: Annotated[float, Field(description="Lattice constant in Angstroms (0 = ASE default)")] = 0,
    supercell: Annotated[list[int], Field(description="Supercell repetitions [nx, ny, nz]")] = [1, 1, 1],
    # Surface parameters
    miller_indices: Annotated[list[int], Field(description="Miller indices for surface: [1,1,1], [1,0,0], etc.")] = [1, 1, 1],
    num_layers: Annotated[int, Field(description="Number of atomic layers in surface slab")] = 4,
    vacuum_A: Annotated[float, Field(description="Vacuum thickness in Angstroms for surface slab")] = 10.0,
    # Output
    output_file: str = "",
) -> BuildResult:
    """Build atomic structures: molecules by name, bulk crystals, or surface slabs.

    Molecule: Builds from ASE's G2 database (100+ molecules).
    Bulk: Creates periodic crystal with specified lattice type.
    Surface: Creates slab with Miller indices, layers, and vacuum.
    """
```

#### `convert_structure` -- Format conversion

```python
@mcp.tool(
    annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=True),
)
async def convert_structure(
    input_file: str,
    output_file: str,
    output_format: Annotated[str, Field(description="'xyz', 'extxyz', 'cif', 'vasp', 'pdb'")] = "extxyz",
) -> ConvertResult:
    """Convert structure between file formats using ASE.

    Supported: XYZ, extended XYZ, CIF, POSCAR/VASP, PDB.
    Extended XYZ preserves all metadata (energy, forces, stress).
    """
```

### 6.3 Analysis Tools (2)

#### `equation_of_state` -- Bulk modulus and equilibrium volume (NEW)

```python
@mcp.tool(
    annotations=ToolAnnotations(readOnlyHint=True, idempotentHint=True),
)
async def equation_of_state(
    ctx: Context,
    structure: str,
    model: str = "MACE-MPA-0",
    model_size: str = "medium",
    num_points: Annotated[int, Field(description="Number of volume points to sample", ge=5, le=21)] = 7,
    strain_range: Annotated[float, Field(description="Fractional volume strain range (+/-)", ge=0.01, le=0.15)] = 0.05,
    eos_type: Annotated[str, Field(description="EOS type: 'birchmurnaghan', 'murnaghan', 'vinet'")] = "birchmurnaghan",
    dispersion: bool = False,
    device: str = "cpu",
) -> EOSResult:
    """Compute equation of state for a periodic crystal.

    Fits E(V) curve by uniformly scaling the unit cell volume.
    Returns equilibrium volume, energy, and bulk modulus (GPa).
    Structure must be periodic with a valid unit cell.
    """
```

#### `extract_descriptors` -- MACE learned atomic representations (NEW)

```python
@mcp.tool(
    annotations=ToolAnnotations(readOnlyHint=True, idempotentHint=True),
)
async def extract_descriptors(
    structure: str,
    model: str = "MACE-MPA-0",
    model_size: str = "medium",
    invariants_only: Annotated[bool, Field(description="True = rotation-invariant features; False = full equivariant")] = True,
    device: str = "cpu",
) -> DescriptorResult:
    """Extract MACE learned atomic descriptors for ML featurization.

    Returns per-atom feature vectors from the model's internal representations.
    Useful for: clustering structures, similarity analysis, active learning,
    and downstream ML models. Shape: (num_atoms, num_features).
    """
```

### 6.4 Intelligence Tool (1)

#### `suggest_parameters` -- AI-powered parameter recommendation

```python
@mcp.tool(
    annotations=ToolAnnotations(readOnlyHint=True, idempotentHint=True, openWorldHint=False),
)
async def suggest_parameters(
    structure: str,
    task: Annotated[str, Field(description="'single_point', 'optimize', 'md', 'frequencies', 'eos'")],
) -> ParameterSuggestion:
    """Suggest optimal MACE model and calculation parameters for a structure.

    Analyzes the structure's composition, periodicity, and size to recommend:
    - Best model (MACE-MP vs MACE-OFF vs MACE-OMOL)
    - Model size (speed vs accuracy trade-off)
    - Precision (float32 vs float64)
    - Task-specific parameters (fmax, timestep, ensemble, etc.)
    - Warnings (D3 dispersion rules, element support, etc.)
    """
```

**Output:**
```python
@dataclass
class ParameterSuggestion:
    recommended_model: str
    recommended_model_size: str
    recommended_precision: str
    recommended_device: str
    task_parameters: dict          # Task-specific recommended params
    warnings: list[str]            # e.g., "MACE-OFF does not support Fe"
    reasoning: str                 # Human-readable explanation
    alternative_models: list[str]  # Other options with trade-offs
```

---

## 7. Resources (4 URI-Addressable Data Sources)

### `mace://models` -- Foundation model catalog

```python
@mcp.resource("mace://models")
def list_models() -> str:
    """Complete catalog of MACE foundation models."""
```

Returns structured text listing all 11 models with: name, loader function, elements, domain, sizes, default dtype, license, and when to use each.

### `mace://models/{model_id}` -- Individual model details

```python
@mcp.resource("mace://models/{model_id}")
def model_details(model_id: str) -> str:
    """Detailed information about a specific MACE model."""
```

Supported model_ids: `mace-mpa-0`, `mace-mp-0`, `mace-off`, `mace-omat-0`, `mace-matpes-pbe`, `mace-matpes-r2scan`, `mace-mh-1`, `mace-omol`, `mace-polar`, `mace-anicc`.

### `mace://units` -- Unit conventions reference

```python
@mcp.resource("mace://units")
def unit_conventions() -> str:
    """MACE + ASE unit conventions for all physical quantities."""
```

### `mace://examples/{example_type}` -- Example structures

```python
@mcp.resource("mace://examples/{example_type}")
def example_structure(example_type: str) -> str:
    """Example XYZ structures for common use cases."""
```

Example types: `water`, `ethanol`, `silicon`, `copper_fcc`, `nacl`, `cu111_surface`.

---

## 8. Prompts (3 Workflow Templates)

### `analyze_structure` -- Comprehensive analysis

```python
@mcp.prompt()
def analyze_structure(filepath: str, model: str = "MACE-MPA-0") -> list[Message]:
    """Guided workflow for comprehensive structure analysis."""
    return [Message(role="user", content=f"""Please analyze the atomic structure at {filepath}:

1. Parse the structure to understand composition and geometry
2. Use suggest_parameters to determine the best model and settings
3. Run a single-point calculation
4. Assess the results:
   - Is the energy in a reasonable range for the model?
   - Are forces reasonable (< 10 eV/A)?
   - For periodic systems, check the stress tensor
5. If max force > 1 eV/A, recommend geometry optimization
6. Summarize findings and suggest next steps
""")]
```

### `optimize_molecule` -- Molecular optimization pipeline

```python
@mcp.prompt()
def optimize_molecule(molecule_name: str) -> list[Message]:
    """Guided workflow: build, optimize, and analyze a molecule."""
    return [Message(role="user", content=f"""Please build and optimize {molecule_name}:

1. Build the molecule using build_structure
2. Run a single-point to get the initial energy/forces
3. Optimize with fmax=0.01 using MACE-OFF (organic) or MACE-MPA-0 (inorganic)
4. If the molecule is small (< 20 atoms), run vibrational_frequencies (with fmax=0.005 first)
5. Report: optimized energy, bond lengths, frequencies, zero-point energy
""")]
```

### `md_simulation` -- Molecular dynamics workflow

```python
@mcp.prompt()
def md_simulation(filepath: str, temperature_K: float = 300) -> list[Message]:
    """Guided workflow for setting up and running MD."""
    return [Message(role="user", content=f"""Please run a molecular dynamics simulation on {filepath} at {temperature_K}K:

1. Parse the structure and suggest optimal parameters
2. First optimize the structure (fmax=0.05)
3. Run NVT MD with appropriate timestep and friction
4. Analyze the trajectory: temperature stability, energy conservation, structural changes
5. Report key findings and whether the simulation appears stable
""")]
```

---

## 9. Error Handling Strategy

Following the MCP spec and mcp-atomictoolkit's pattern, every error response includes LLM-actionable context:

```python
from mcp.server.fastmcp.exceptions import ToolError

# Scientific validation errors (always reach the LLM for self-correction)
class MACEToolError(ToolError):
    """Error with LLM-friendly hint and next action."""
    def __init__(self, message: str, hint: str, next_action: str):
        super().__init__(
            f"{message}\n\n"
            f"Hint: {hint}\n"
            f"Next action: {next_action}"
        )
```

### Error Categories

| Category | Example | Hint Pattern |
|----------|---------|-------------|
| **Model mismatch** | MACE-OFF with Fe atoms | "MACE-OFF only supports H,C,N,O,F,P,S,Cl,Br,I. Use MACE-MPA-0 for materials." |
| **D3 double-counting** | dispersion=True with MACE-OFF | "MACE-OFF already includes D3BJ dispersion. Set dispersion=False." |
| **Bad structure** | Overlapping atoms (dist < 0.5 A) | "Atoms at indices [3,7] are only 0.2 A apart. Check your structure for errors." |
| **Convergence failure** | Optimization hit max_steps | "Optimization did not converge in {max_steps} steps. Try: increase max_steps, use FIRE optimizer, or relax fmax." |
| **Missing periodicity** | NPT on non-periodic system | "NPT requires a periodic system with a defined unit cell. Use NVT for molecules." |
| **Precision warning** | float32 for Hessian | "Vibrational analysis requires float64 for accurate Hessians. Precision was automatically upgraded." |
| **Device fallback** | CUDA not available | "CUDA not available, falling back to CPU. Install PyTorch with CUDA for GPU acceleration." |

---

## 10. Lifespan & Model Caching

```python
from contextlib import asynccontextmanager
from collections.abc import AsyncIterator
from mcp.server.fastmcp import FastMCP

@asynccontextmanager
async def server_lifespan(server: FastMCP) -> AsyncIterator[dict]:
    """
    Manage MACE model lifecycle.

    Models are loaded lazily on first use but cached for subsequent calls.
    A typical MACE model load takes 5-30 seconds; caching avoids this
    penalty on every tool invocation.
    """
    model_cache = {}   # key: (model_name, model_size, precision) -> MACECalculator

    try:
        yield {"model_cache": model_cache}
    finally:
        # Cleanup: free GPU memory
        model_cache.clear()
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except ImportError:
            pass

mcp = FastMCP(
    "mace-server",
    instructions=(
        "MACE machine learning interatomic potential server. "
        "Provides atomistic simulation tools: energy calculations, geometry optimization, "
        "molecular dynamics, vibrational analysis, and structure building. "
        "All energies in eV, forces in eV/A, distances in Angstroms. "
        "Use suggest_parameters tool first if unsure which model or settings to use."
    ),
    lifespan=server_lifespan,
)
```

### Calculator Loading with Cache

```python
# engine/calculator.py

def get_calculator(
    model: str,
    model_size: str,
    precision: str,
    device: str,
    dispersion: bool,
    cache: dict,
) -> "MACECalculator":
    """Load or retrieve a cached MACE calculator."""
    cache_key = (model, model_size, precision, device, dispersion)

    if cache_key in cache:
        return cache[cache_key]

    # Resolve device (CUDA fallback)
    actual_device = _resolve_device(device)

    if model == "MACE-OFF" or model == "MACE-OFF23":
        from mace.calculators import mace_off
        if dispersion:
            raise MACEToolError(
                "D3 dispersion cannot be used with MACE-OFF",
                hint="MACE-OFF is trained on wB97M-D3BJ which already includes dispersion",
                next_action="Set dispersion=False and retry",
            )
        calc = mace_off(model=model_size, device=actual_device, default_dtype=precision)

    elif model == "MACE-OMOL" or model == "MACE-OMOL-0":
        from mace.calculators import mace_omol
        calc = mace_omol(model=model_size, device=actual_device, default_dtype=precision)

    elif model == "MACE-Polar" or model.startswith("polar"):
        from mace.calculators import mace_polar
        calc = mace_polar(model=f"polar-1-{model_size[0]}", device=actual_device, default_dtype=precision)

    elif model == "MACE-ANI-CC":
        from mace.calculators import mace_anicc
        calc = mace_anicc(device=actual_device)

    elif model.endswith(".model") or "/" in model:
        # Custom model path
        from mace.calculators import MACECalculator
        calc = MACECalculator(model_paths=model, device=actual_device, default_dtype=precision)

    else:
        # All MACE-MP variants: MACE-MP-0, MACE-MPA-0, MACE-OMAT-0, MACE-MATPES-*, MACE-MH-*
        from mace.calculators import mace_mp
        model_key = _resolve_mp_model_key(model, model_size)
        calc = mace_mp(model=model_key, device=actual_device, dispersion=dispersion, default_dtype=precision)

    cache[cache_key] = calc
    return calc


def _resolve_mp_model_key(model: str, size: str) -> str:
    """Map user-friendly model names to mace_mp() model keys."""
    mapping = {
        "MACE-MPA-0":          f"{size}-mpa-0" if size == "medium" else f"{size}-mpa-0",
        "MACE-MP-0":           size,                 # "small", "medium", "large"
        "MACE-OMAT-0":         f"{size}-omat-0",
        "MACE-MATPES-PBE-0":   "mace-matpes-pbe-0",
        "MACE-MATPES-r2SCAN-0": "mace-matpes-r2scan-0",
        "MACE-MH-0":           "mh-0",
        "MACE-MH-1":           "mh-1",
    }
    return mapping.get(model, f"{size}-mpa-0")  # Default to MPA-0


def _resolve_device(requested: str) -> str:
    """Resolve compute device with CUDA fallback."""
    if requested in ("cuda", "gpu"):
        try:
            import torch
            return "cuda" if torch.cuda.is_available() else "cpu"
        except ImportError:
            return "cpu"
    return requested
```

---

## 11. Progress Reporting

Long-running tools report progress via MCP's built-in progress protocol:

```python
# In optimize tool
async def optimize(ctx: Context, ...):
    await ctx.info(f"Loading {model}/{model_size}...")

    # During optimization, report progress
    for step in range(max_steps):
        if converged:
            break
        await ctx.report_progress(step, max_steps, f"Step {step}: max_force={current_fmax:.4f} eV/A")

    await ctx.info(f"Optimization {'converged' if converged else 'reached max steps'} in {step} steps")

# In MD tool
async def molecular_dynamics(ctx: Context, ...):
    await ctx.info(f"Initializing {ensemble} MD at {temperature_K}K...")

    for step in range(num_steps):
        if step % report_interval == 0:
            await ctx.report_progress(step, num_steps, f"Step {step}/{num_steps}, T={current_T:.1f}K")

    await ctx.info(f"MD completed: {num_steps} steps in {time:.1f}s")
```

---

## 12. Configuration & Distribution

### PyPI Package (`pyproject.toml`)

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "mace-mcp-server"
version = "0.1.0"
description = "MCP server for MACE machine learning interatomic potentials"
readme = "README.md"
license = "MIT"
requires-python = ">=3.10"
authors = [{ name = "Zicheng Zhao", email = "zhao.ziche@northeastern.edu" }]
keywords = ["mace", "mcp", "atomistic", "simulation", "force-field", "materials-science"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Science/Research",
    "Topic :: Scientific/Engineering :: Chemistry",
    "Topic :: Scientific/Engineering :: Physics",
]
dependencies = [
    "mcp[cli]>=1.26.0",
    "mace-torch>=0.3.10",
    "ase>=3.22.0",
    "torch>=2.0.0",
    "numpy>=1.24.0",
    "pydantic>=2.0.0",
]

[project.optional-dependencies]
dispersion = ["torch-dftd>=0.4.0"]
dev = ["pytest", "pytest-asyncio", "ruff"]

[project.scripts]
mace-mcp-server = "mace_mcp_server.server:main"
```

### Installation

```bash
# Standard pip install
pip install mace-mcp-server

# With D3 dispersion support
pip install mace-mcp-server[dispersion]

# From source (development)
git clone https://github.com/zichengzhao/mace-mcp-server
cd mace-mcp-server
pip install -e ".[dev]"

# Run directly with uvx (no install needed)
uvx mace-mcp-server
```

### Claude Code Configuration

```bash
# Register the server (after pip install)
claude mcp add mace -- mace-mcp-server

# Or with explicit Python path
claude mcp add mace -- python3 -m mace_mcp_server.server
```

### `.mcp.json` (project-scoped, committed to git)

```json
{
  "mcpServers": {
    "mace": {
      "command": "mace-mcp-server",
      "env": {}
    }
  }
}
```

### Claude Desktop Configuration

```json
{
  "mcpServers": {
    "mace": {
      "command": "uvx",
      "args": ["mace-mcp-server"]
    }
  }
}
```

---

## 13. Server Entry Point

```python
# src/mace_mcp_server/server.py

#!/usr/bin/env python3
"""MACE MCP Server -- AI-callable atomistic simulation tools."""

import sys
from mcp.server.fastmcp import FastMCP
from mace_mcp_server.tools.calculation import register_calculation_tools
from mace_mcp_server.tools.structure import register_structure_tools
from mace_mcp_server.tools.analysis import register_analysis_tools
from mace_mcp_server.tools.intelligence import register_intelligence_tools
from mace_mcp_server.resources.models import register_model_resources
from mace_mcp_server.resources.reference import register_reference_resources
from mace_mcp_server.prompts.workflows import register_prompts
from mace_mcp_server.lifespan import server_lifespan

mcp = FastMCP(
    "mace-server",
    version="0.1.0",
    instructions=(
        "MACE machine learning interatomic potential server for atomistic simulations. "
        "Provides tools for energy/force calculations, geometry optimization, molecular dynamics, "
        "vibrational analysis, structure building, and more. "
        "Supports 11 foundation models covering 89 elements. "
        "All energies in eV, forces in eV/A, distances in Angstroms. "
        "Use the suggest_parameters tool if unsure which model or settings to use."
    ),
    lifespan=server_lifespan,
)

# Register all components
register_calculation_tools(mcp)
register_structure_tools(mcp)
register_analysis_tools(mcp)
register_intelligence_tools(mcp)
register_model_resources(mcp)
register_reference_resources(mcp)
register_prompts(mcp)


def main():
    """Entry point for the mace-mcp-server command."""
    # CRITICAL: Never write to stdout in stdio mode (corrupts JSON-RPC)
    # All logging goes to stderr
    import logging
    logging.basicConfig(stream=sys.stderr, level=logging.INFO)

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
```

---

## 14. Testing Strategy

### Unit Tests (no MCP transport)

```python
# tests/test_engine.py
import pytest
from mace_mcp_server.engine.calculator import get_calculator
from mace_mcp_server.engine.runner import run_single_point, run_optimization
from mace_mcp_server.engine.builders import build_molecule, build_bulk

def test_single_point_water():
    atoms = build_molecule("H2O")
    calc = get_calculator("MACE-OFF", "small", "float64", "cpu", False, {})
    result = run_single_point(atoms, calc)
    assert result["status"] == "success"
    assert -200 < result["energy_eV"] < 0  # MACE-OFF range for water
    assert len(result["forces_eV_per_A"]) == 3

def test_optimization_convergence():
    atoms = build_molecule("CH4")
    calc = get_calculator("MACE-OFF", "small", "float64", "cpu", False, {})
    result = run_optimization(atoms, calc, fmax=0.05, max_steps=100)
    assert result["converged"] is True
    assert result["final_max_force"] < 0.05

def test_d3_mace_off_rejected():
    with pytest.raises(MACEToolError, match="double-counting"):
        get_calculator("MACE-OFF", "small", "float64", "cpu", dispersion=True, cache={})
```

### MCP Inspector (Interactive)

```bash
# Launch visual inspector in browser
npx -y @modelcontextprotocol/inspector mace-mcp-server

# Or with explicit command
npx -y @modelcontextprotocol/inspector -- python3 -m mace_mcp_server.server
```

### Integration with Claude Code

```bash
claude mcp add mace -- mace-mcp-server
claude
# "Parse the structure at examples/water.xyz"
# "What model should I use for silicon?"
# "Calculate the energy of ethanol with MACE-OFF"
# "Optimize this crystal structure"
# "Run NVT MD at 500K for 200 steps"
```

---

## 15. Implementation Plan

### Phase 1: Foundation (Days 1-2)
**Goal:** Working server with `single_point` + `parse_structure` + `suggest_parameters`

| Task | Files | Details |
|------|-------|---------|
| Project scaffold | `pyproject.toml`, `src/mace_mcp_server/__init__.py` | Package metadata, entry points, dependencies |
| Engine: calculator loading | `engine/calculator.py` | `get_calculator()` with model mapping, cache, device fallback |
| Engine: single-point runner | `engine/runner.py` | `run_single_point()` -- energy, forces, stress, per-atom energies |
| Engine: structure builders | `engine/builders.py` | `build_molecule()`, ASE I/O wrappers |
| Schemas: output models | `schemas/outputs.py` | Pydantic dataclasses for all result types |
| Tool: `single_point` | `tools/calculation.py` | With annotations, structured output, error handling |
| Tool: `parse_structure` | `tools/structure.py` | Format detection, composition analysis, overlap check |
| Tool: `suggest_parameters` | `tools/intelligence.py` | Element analysis -> model recommendation |
| Resource: `mace://models` | `resources/models.py` | Full model catalog |
| Resource: `mace://units` | `resources/reference.py` | Unit conventions |
| Server entry point | `server.py` | FastMCP with lifespan, registration |
| Test: MCP Inspector | manual | Verify all 3 tools + 2 resources work |
| Test: Claude Code | manual | Register and run end-to-end |

### Phase 2: Full Calculation Suite (Days 3-4)
**Goal:** All 4 calculation types + all 3 structure tools + progress reporting

| Task | Files | Details |
|------|-------|---------|
| Engine: optimization runner | `engine/runner.py` | BFGS/FIRE, cell optimization via ExpCellFilter |
| Engine: MD runner | `engine/runner.py` | NVT/NPT/NVE, Maxwell-Boltzmann init, trajectory recording |
| Engine: vibrational analysis | `engine/runner.py` | Hessian via `calc.get_hessian()`, eigenvalue decomposition |
| Tool: `optimize` | `tools/calculation.py` | With progress reporting, convergence tracking |
| Tool: `molecular_dynamics` | `tools/calculation.py` | With progress reporting, trajectory output |
| Tool: `vibrational_frequencies` | `tools/calculation.py` | Auto-upgrade to float64, imaginary freq warnings |
| Tool: `build_structure` | `tools/structure.py` | molecule/bulk/surface dispatching |
| Tool: `convert_structure` | `tools/structure.py` | ASE format conversion |
| Resource: `mace://examples/{type}` | `resources/reference.py` | Embedded example XYZ structures |
| Tests | `tests/test_engine.py` | Unit tests for all engine functions |

### Phase 3: Analysis & Polish (Days 5-6)
**Goal:** Advanced analysis tools, all prompts, documentation, PyPI release

| Task | Files | Details |
|------|-------|---------|
| Engine: EOS | `engine/runner.py` | Volume scaling, Birch-Murnaghan fit |
| Engine: descriptors | `engine/runner.py` | `calc.get_descriptors()` wrapper |
| Tool: `equation_of_state` | `tools/analysis.py` | With progress reporting |
| Tool: `extract_descriptors` | `tools/analysis.py` | Invariant/equivariant options |
| Resource: `mace://models/{model_id}` | `resources/models.py` | Parameterized URI template |
| Prompts: all 3 | `prompts/workflows.py` | analyze, optimize, md workflows |
| `.mcp.json` | root | Project-scoped config for team sharing |
| README.md | root | Installation, usage examples, model guide |
| PyPI release | CI/CD | `hatch build && hatch publish` |

---

## 16. Scientific Accuracy Checklist

**Every tool MUST enforce these rules (verified from MACE docs):**

- [ ] D3 dispersion is NEVER used with MACE-OFF (double-counting wB97M-D3BJ)
- [ ] MACE-OFF element check: only H, C, N, O, F, P, S, Cl, Br, I
- [ ] MACE-ANI-CC element check: only H, C, N, O
- [ ] Vibrational analysis always uses float64 (auto-upgrade if float32 requested)
- [ ] Hessian computation only on optimized structures (warn if max_force > 0.01)
- [ ] NPT only on periodic systems with valid cell
- [ ] Default model is MACE-MPA-0 (not MACE-MP-0) -- `mace_mp()` returns MPA-0
- [ ] MACE-OFF defaults to float64 (not float32)
- [ ] RMS force = sqrt(sum(|F_i|^2) / N_atoms), NOT sqrt(sum(f^2) / 3N)
- [ ] Energy ranges: MACE-MP: -1 to -15 eV/atom; MACE-OFF: -100 to -600 eV/atom
- [ ] Stress tensor in Voigt notation: [xx, yy, zz, yz, xz, xy] in eV/A^3
- [ ] MD timestep: use `ase.units.fs` for conversion, not raw floats
- [ ] MaxwellBoltzmannDistribution must initialize velocities before MD
- [ ] Models cached to `~/.cache/mace/` (configurable via XDG_CACHE_HOME)
- [ ] PyTorch 2.6+ requires `weights_only=False` for MACE model loading

---

## 17. References

### MCP Protocol & SDK
- [MCP Specification (2025-06-18)](https://modelcontextprotocol.io/specification/2025-06-18)
- [MCP Architecture](https://modelcontextprotocol.io/docs/concepts/architecture)
- [MCP Tools Spec](https://modelcontextprotocol.io/specification/draft/server/tools)
- [MCP Python SDK (FastMCP)](https://github.com/modelcontextprotocol/python-sdk)
- [FastMCP Server Reference](https://gofastmcp.com/servers/server)
- [FastMCP Tools Reference](https://gofastmcp.com/servers/tools)
- [FastMCP Context Reference](https://gofastmcp.com/python-sdk/fastmcp-server-context)
- [Build a Server Tutorial](https://modelcontextprotocol.io/docs/develop/build-server)

### MACE
- [MACE Documentation](https://mace-docs.readthedocs.io/en/latest/)
- [MACE GitHub](https://github.com/ACEsuit/mace)
- [MACE Foundation Models](https://mace-docs.readthedocs.io/en/latest/guide/foundation_models.html)
- [MACE Fine-tuning Guide](https://mace-docs.readthedocs.io/en/latest/guide/finetuning.html)

### Scientific MCP Servers (Competitive)
- [mcp-atomictoolkit](https://github.com/XirtamEsrevni/mcp-atomictoolkit) -- Closest competitor (KIM/NequIP/Orb)
- [mcp.science](https://github.com/pathintegral-institute/mcp.science) -- Multi-science MCP (GPAW, Materials Project)
- [MCP_LAMMPS](https://github.com/Chenghao-Wu/MCP_LAMMPS) -- LAMMPS molecular dynamics
- [VASPilot](https://github.com/JiaxuanLiu-Arsko/VASPilot) -- VASP DFT automation (Chinese Physics B paper)
- [ABACUS MCP](https://github.com/PhelanShao/abacus-mcp-server) -- All 3 MCP primitives example
- [OpenMM MCP](https://github.com/PhelanShao/openmm-mcp-server) -- Classical MD
- [molecule-mcp](https://github.com/ChatMol/molecule-mcp) -- PyMOL + GROMACS

### ASE
- [ASE Documentation](https://wiki.fysik.dtu.dk/ase/)
- [ASE Optimizers](https://wiki.fysik.dtu.dk/ase/ase/optimize.html)
- [ASE MD](https://wiki.fysik.dtu.dk/ase/ase/md.html)
- [ASE EOS](https://wiki.fysik.dtu.dk/ase/ase/eos.html)
