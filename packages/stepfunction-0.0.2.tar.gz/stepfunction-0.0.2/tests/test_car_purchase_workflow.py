from pathlib import Path
import sys
import types
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))


class _FakeSubgraph:
    def __init__(self):
        self.attrs = {}

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def attr(self, **kwargs):
        self.attrs.update(kwargs)


class _FakeDigraph:
    def __init__(self, comment=None):
        self.comment = comment
        self.nodes = []
        self.edges = []
        self.render_calls = []

    def node(self, *args, **kwargs):
        self.nodes.append((args, kwargs))

    def edge(self, *args, **kwargs):
        self.edges.append((args, kwargs))

    def subgraph(self):
        return _FakeSubgraph()

    def render(self, *args, **kwargs):
        self.render_calls.append((args, kwargs))

    def pipe(self, format=None, renderer=None):
        return f"digraph {self.comment} ({format}, {renderer})".encode("utf-8")


fake_graphviz = types.ModuleType("graphviz")
fake_graphviz.Digraph = _FakeDigraph
sys.modules.setdefault("graphviz", fake_graphviz)


from examples.car_purchase_workflow import validate_car_purchase_transaction_workflow
from stepfunction.constants.enums import StepFunctionStatus


class CarPurchaseWorkflowTests(unittest.IsolatedAsyncioTestCase):
    async def test_valid_car_purchase_workflow_runs_to_completion(self):
        workflow = await validate_car_purchase_transaction_workflow(
            transaction={
                "transaction_id": "CAR-1001",
                "customer_email": "buyer@example.com",
                "is_valid": True,
            },
            visualize=True,
        )

        self.assertEqual(workflow.status, StepFunctionStatus.COMPLETED)
        self.assertEqual(workflow.last_result["workflow"], "done")
        self.assertEqual(
            workflow.context["Update_Company_DB_Records"]["update_shipping_db_record"],
            "shipping_updated",
        )
        self.assertEqual(
            workflow.context["Update_Car_Purchase_Transaction_Status"]["status"],
            "completed",
        )
        self.assertTrue(
            workflow.context["Send_Notification_To_User_Email"]["notification_sent"])

    async def test_invalid_car_purchase_skips_parallel_update_steps(self):
        workflow = await validate_car_purchase_transaction_workflow(
            transaction={
                "transaction_id": "CAR-1002",
                "customer_email": "buyer@example.com",
                "is_valid": False,
            },
            visualize=False,
        )

        self.assertEqual(workflow.status, StepFunctionStatus.COMPLETED)
        self.assertEqual(
            workflow.context["Check_If_Car_Purchase_Transaction_Is_Valid"], "invalid")
        self.assertNotIn("Update_Company_DB_Records", workflow.context)
        self.assertEqual(
            workflow.context["Send_Notification_To_User_Email"]["status"],
            "validation_failed",
        )


if __name__ == "__main__":
    unittest.main()
