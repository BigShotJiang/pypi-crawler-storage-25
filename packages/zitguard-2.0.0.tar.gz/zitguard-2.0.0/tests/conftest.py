"""
Shared fixtures for the ZITGUARD Python SDK test suite.
"""
import pytest
from unittest.mock import MagicMock

from zitguard import GuardrailsClient


# ------------------------------------------------------------------ #
# Stock Runtime responses
# ------------------------------------------------------------------ #

ALLOW_RESPONSE = {
    "decision": "ALLOW",
    "risk_score": 0.05,
    "rule_hits": [],
    "detectors": {
        "jailbreak": {"decision": "ALLOW", "score": 0.02, "triggered": False},
        "toxicity":  {"decision": "ALLOW", "score": 0.01, "triggered": False},
    },
    "sanitized_text": None,
}

BLOCK_RESPONSE = {
    "decision": "BLOCK",
    "risk_score": 0.97,
    "reason": "jailbreak_detected",
    "rule_hits": ["rule_jailbreak_001"],
    "detectors": {
        "jailbreak": {"decision": "BLOCK", "score": 0.97, "triggered": True},
    },
    "sanitized_text": None,
}

REDACT_RESPONSE = {
    "decision": "REDACT",
    "risk_score": 0.65,
    "rule_hits": ["rule_pii_credit_card"],
    "detectors": {
        "pii": {"decision": "REDACT", "score": 0.99, "triggered": True},
    },
    "sanitized_text": "My card number is [REDACTED], please update billing.",
}

WARN_RESPONSE = {
    "decision": "WARN",
    "risk_score": 0.30,
    "rule_hits": ["rule_topic_offtopic"],
    "detectors": {
        "topic": {"decision": "WARN", "score": 0.30, "triggered": True},
    },
    "sanitized_text": None,
}

OUTPUT_WITH_QUALITY = {
    "decision": "ALLOW",
    "risk_score": 0.03,
    "rule_hits": [],
    "detectors": {},
    "sanitized_text": None,
    "quality": {
        "groundedness": 0.92,
        "relevance": 0.88,
        "coherence": 0.95,
        "fluency": 0.97,
        "intent_resolution": 0.85,
        "task_adherence": 0.90,
        "tool_call_accuracy": 0.93,
    },
}

HEALTH_RESPONSE = {
    "status": "ok",
    "version": "1.2.0",
    "uptime_seconds": 3600,
}


# ------------------------------------------------------------------ #
# Client fixture (no network — tests mock _http)
# ------------------------------------------------------------------ #

@pytest.fixture
def client():
    """Return a GuardrailsClient wired to localhost:8080."""
    return GuardrailsClient(base_url="http://localhost:8080")


@pytest.fixture
def enterprise_client():
    """Return a GuardrailsClient pre-configured with tenant/app defaults."""
    return GuardrailsClient(
        base_url="https://api.zitguard.zitrino.com",
        api_key="zgk_test_secret",
        tenant_id="acme",
        app_id="support-bot",
    )
