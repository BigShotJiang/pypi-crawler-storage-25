# zitguard — Python SDK

> Lightweight Python client for [ZITGUARD AI](https://zitguard.zitrino.com) — LLM guardrails made simple.

## Installation

```bash
pip install zitguard
```

Requires Python ≥ 3.9.

## Quick Start

```python
from zitguard import GuardrailsClient

client = GuardrailsClient()   # connects to ZITGUARD Runtime at localhost:8080

# --- Evaluate user input before sending to the LLM ---
result = client.evaluate_input("Where is my order #12345?")

if result.is_blocked:
    print("Blocked:", result.raw.get("reason"))
elif result.is_redacted:
    safe_text = result.safe_text          # use the cleaned version
    print("Redacted input:", safe_text)
else:
    # Pass result.text (or safe_text) to your LLM
    llm_response = call_your_llm(result.safe_text or "Where is my order #12345?")

    # --- Evaluate LLM output before returning to the user ---
    out = client.evaluate_output(llm_response, context="Where is my order #12345?")
    if not out.is_blocked:
        print(out.safe_text or llm_response)
```

## Using with a Remote Control Plane

```python
client = GuardrailsClient(
    base_url="https://api.zitguard.zitrino.com",
    api_key="zgk_xxxxxx",
    tenant_id="acme",
    app_id="support-bot",
)
```

## Raise on Block

```python
from zitguard import ZitguardBlockedError

try:
    result = client.evaluate_input(user_text, raise_on_block=True)
except ZitguardBlockedError as e:
    return {"error": str(e)}
```

## Agentic Pipelines — Tool Result Evaluation

```python
tool_output = run_tool("search_database", query="customer data")
check = client.evaluate_tool(str(tool_output), raise_on_block=True)
# Blocks exfiltration and secrets automatically
```

## API Reference

### `GuardrailsClient(base_url, api_key, tenant_id, app_id, timeout, retries)`

| Parameter     | Default                     | Description                                  |
|---------------|-----------------------------|----------------------------------------------|
| `base_url`    | `http://localhost:8080`     | ZITGUARD Runtime or Control Plane URL        |
| `api_key`     | `None`                      | Bearer token (required for Control Plane)    |
| `tenant_id`   | `None`                      | Default tenant scope                         |
| `app_id`      | `None`                      | Default application scope                   |
| `timeout`     | `5.0`                       | Per-request timeout in seconds               |
| `retries`     | `2`                         | Auto-retry on transient errors               |

### `EvaluationResult`

| Property          | Type             | Description                              |
|-------------------|------------------|------------------------------------------|
| `decision`        | `str`            | `ALLOW / BLOCK / REDACT / WARN / TRANSFORM` |
| `risk_score`      | `float`          | 0–1 risk score                           |
| `latency_ms`      | `int`            | Round-trip time in milliseconds          |
| `is_blocked`      | `bool`           | True if decision == BLOCK                |
| `is_redacted`     | `bool`           | True if decision == REDACT               |
| `safe_text`       | `str \| None`   | Sanitized text (REDACT/TRANSFORM only)   |
| `quality`         | `QualityScores`  | Output quality metrics (evaluate_output) |
| `detector_results`| `dict`           | Per-detector breakdown                   |

## Running Tests

```bash
pip install -e ".[dev]"
pytest                          # unit tests (no Runtime needed)
ZITGUARD_INTEGRATION=1 pytest tests/test_integration.py   # integration
```

## License

Apache 2.0 — see [LICENSE](LICENSE)
