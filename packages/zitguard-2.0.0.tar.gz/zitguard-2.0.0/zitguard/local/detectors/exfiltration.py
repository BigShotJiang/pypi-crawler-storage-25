"""
ZITGUARD AI — Python SDK
ExfiltrationDetector: detects data exfiltration patterns in tool-call results.

Intended for the tool evaluation path where agentic systems may attempt
to leak internal data via:
  - URLs with embedded sensitive query params
  - Large base-64 blobs being transmitted out-of-band
  - SQL / NoSQL dump statements
  - Redirect to external webhooks / callbacks
  - Indirect prompt injection hidden in tool output
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

from .base import BaseDetector

# ---------------------------------------------------------------------------
# (label, raw_pattern, flags)
# ---------------------------------------------------------------------------
_RAW_PATTERNS: List[Tuple[str, str, int]] = [
    # URLs carrying suspicious query parameters (token, secret, api_key, pass, data)
    (
        "url_sensitive_params",
        r"https?://[^\s\"'<>]+[?&]"
        r"(?:token|key|secret|auth|pass(?:word)?|api_key|access_token|credential)"
        r"=[^\s&\"'<>]+",
        re.IGNORECASE,
    ),
    # Large base-64 blobs (≥80 chars) — potential covert channel
    (
        "large_base64_blob",
        r"(?:[A-Za-z0-9+/]{20,}={0,2})(?:\s*[A-Za-z0-9+/]{20,}={0,2}){3,}",
        0,
    ),
    # SQL statements typical of a DB dump or exfil attempt
    (
        "sql_exfil",
        r"\b(?:SELECT\s+\*\s+FROM|INSERT\s+INTO\s+\w+\s+VALUES|"
        r"DROP\s+(?:TABLE|DATABASE)|DUMP\s+DATABASE|mysqldump)\b",
        re.IGNORECASE,
    ),
    # Explicit data dump / exfil language
    (
        "data_dump_language",
        r"(?i)(?:database\s+dump|data\s+exfil(?:tration)?|"
        r"send\s+(?:all\s+)?(?:data|records|users?|credentials?)\s+to\s+https?://|"
        r"upload\s+(?:all\s+)?(?:files?|data)\s+to\s+https?://)",
        re.IGNORECASE,
    ),
    # Webhook / callback URLs pointing to external hosts
    (
        "external_webhook",
        r"(?i)(?:webhook|callback|exfil(?:trate)?)\s*(?:url|endpoint|address)?\s*"
        r"[=:]\s*https?://(?!(?:localhost|127\.|10\.|192\.168\.|172\.(?:1[6-9]|2\d|3[01]))\b)"
        r"\S+",
        re.IGNORECASE,
    ),
    # Indirect prompt injection: hidden instructions embedded in tool output
    (
        "embedded_instruction",
        r"(?i)(?:<!-- .*(?:ignore|override|execute|run).*-->|"
        r"\[\s*(?:system|ignore\s+above|new\s+instructions?)\s*\])",
        re.IGNORECASE,
    ),
    # Suspicious curl / wget commands in tool results
    (
        "shell_exfil_command",
        r"\b(?:curl|wget)\s+(?:-[a-zA-Z\s]+\s+)?https?://[^\s]+\s*"
        r"(?:\|\s*(?:bash|sh|python|exec))?",
        re.IGNORECASE,
    ),
]

# Score per hit — multiple indicators raise the overall score
_HIT_WEIGHT = 0.35
_BLOCK_THRESHOLD = 0.70


class ExfiltrationDetector(BaseDetector):
    """
    Detects data-exfiltration patterns in tool / function call output.

    score = min(0.35 × number_of_hits, 1.0)
    - score > 0.70 → BLOCK
    - score > 0.00 → WARN
    """

    name = "exfiltration"

    def __init__(self) -> None:
        self._patterns: List[Tuple[str, re.Pattern[str]]] = [
            (label, re.compile(pat, flags))
            for label, pat, flags in _RAW_PATTERNS
        ]

    def detect(self, text: str, **kwargs: Any) -> Dict[str, Any]:
        hits: List[str] = []

        for label, pattern in self._patterns:
            if pattern.search(text):
                hits.append(label)

        if not hits:
            return self._allow()

        score = min(_HIT_WEIGHT * len(hits), 1.0)
        details: Dict[str, Any] = {"indicators": hits, "count": len(hits)}

        if score >= _BLOCK_THRESHOLD:
            return self._block(score=score, details=details)

        return self._warn(score=score, details=details)
