"""
ZITGUARD AI — Python SDK
ToxicityDetector: tiered keyword / pattern-based toxicity detector.

Tier 1 (BLOCK)  — clear-and-present harmful content requests.
Tier 2 (WARN)   — sensitive topics that warrant caution.

Deliberately conservative to minimise false positives.  For production
use cases requiring high recall, integrate an ML-based classifier.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

from .base import BaseDetector

# ---------------------------------------------------------------------------
# BLOCK patterns — match content that is harmful in virtually all contexts
# ---------------------------------------------------------------------------
_BLOCK_PATTERNS: List[Tuple[str, str]] = [
    # Weapons / mass harm instructions
    (
        r"\b(how\s+to\s+|instructions?\s+(?:for\s+|to\s+)?)"
        r"(make|build|create|synthesize|produce)\s+"
        r"(a\s+)?(bomb|explosive|bioweapon|chemical\s+weapon|nerve\s+agent|ricin|sarin|anthrax|fentanyl)",
        "weapon_synthesis",
    ),
    (
        r"\b(detonate|blow\s+up|trigger\s+an?\s+explosion|ignite)\s+"
        r"(a\s+)?(device|bomb|explosive|charge)\b",
        "detonation",
    ),
    # Child sexual abuse material
    (
        r"\b(child|minor|underage|teen)\s+(sexual|nude|naked|porn|pornography|exploitation)\b",
        "csam",
    ),
    (
        r"\b(cp|childporn|child_porn)\b",
        "csam_slang",
    ),
    # Direct calls for violence against named individuals/groups
    (
        r"\b(kill|murder|assassinate|execute)\s+(all\s+)?"
        r"(the\s+)?(jews?|muslims?|christians?|blacks?|whites?|asians?|immigrants?|homeless)\b",
        "hate_violence",
    ),
    # Suicide/self-harm detailed instructions
    (
        r"\b(step[\-\s]by[\-\s]step|detailed|exact)\s+"
        r"(instructions?|guide|method|way)\s+(to\s+|for\s+)?"
        r"(commit\s+suicide|kill\s+(?:my|your)self|self[\-\s]harm)\b",
        "self_harm_instructions",
    ),
    # Ransomware / malware creation
    (
        r"\b(write|create|build|code)\s+(me\s+)?(a\s+)?"
        r"(ransomware|malware|keylogger|rootkit|trojan|spyware|cryptovirus)\b",
        "malware_creation",
    ),
]

# ---------------------------------------------------------------------------
# WARN patterns — sensitive but not inherently harmful
# ---------------------------------------------------------------------------
_WARN_PATTERNS: List[Tuple[str, str]] = [
    (r"\b(racist|sexist|bigot(ed)?|homophob(ic|e)|transphob(ic|e))\b", "hate_language"),
    (r"\b(suicide|self[\-\s]harm|cut\s+(?:my|your)self)\b", "self_harm_mention"),
    (
        r"\b(how\s+to\s+(?:buy|get|obtain|use))\s+"
        r"(cocaine|heroin|methamphetamine|meth|fentanyl|opioid)\b",
        "drug_acquisition",
    ),
    (r"\b(dark\s+web|darkweb|tor\s+browser)\s+(?:drugs?|weapons?|guns?|hitman)\b", "darkweb"),
    (
        r"\b(?:threats?\s+to\s+(?:kill|harm|hurt|attack)|i\s+will\s+(?:kill|hurt|attack))\s+"
        r"(?:you|them|everyone|anyone)\b",
        "direct_threat",
    ),
    (r"\b(harassment|doxxing|dox)\s+(campaign|someone|them|you)\b", "harassment"),
]


class ToxicityDetector(BaseDetector):
    """
    Two-tier toxicity detector.

    - BLOCK (score 0.95) on Tier-1 matches.
    - WARN  (score 0.60 + 0.05 per extra hit, max 0.85) on Tier-2 matches.
    """

    name = "toxicity"

    def __init__(self) -> None:
        self._block: List[Tuple[re.Pattern[str], str]] = [
            (re.compile(pat, re.IGNORECASE | re.UNICODE), label)
            for pat, label in _BLOCK_PATTERNS
        ]
        self._warn: List[Tuple[re.Pattern[str], str]] = [
            (re.compile(pat, re.IGNORECASE | re.UNICODE), label)
            for pat, label in _WARN_PATTERNS
        ]

    def detect(self, text: str, **kwargs: Any) -> Dict[str, Any]:
        # Check BLOCK tier first
        block_hits = [
            label for pattern, label in self._block if pattern.search(text)
        ]
        if block_hits:
            return self._block_result(categories=block_hits)

        # Check WARN tier
        warn_hits = [
            label for pattern, label in self._warn if pattern.search(text)
        ]
        if warn_hits:
            score = min(0.60 + 0.05 * (len(warn_hits) - 1), 0.85)
            return self._warn(score=score, details={"categories": warn_hits})

        return self._allow()

    # rename to avoid name collision with BaseDetector._block()
    def _block_result(self, categories: List[str]) -> Dict[str, Any]:
        return self._block(
            score=0.95,
            details={"categories": categories},
        )
