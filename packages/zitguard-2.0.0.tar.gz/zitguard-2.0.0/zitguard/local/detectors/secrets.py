"""
ZITGUARD AI — Python SDK
SecretsDetector: regex-based credentials / secret key detector.

Catches common secrets patterns:
  AWS access/secret keys, GitHub tokens, Stripe keys, JWT tokens,
  OpenAI keys, Slack tokens, Google API keys, private key PEM blocks,
  generic API key / password assignments, and long hex secrets.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

from .base import BaseDetector

# ---------------------------------------------------------------------------
# (label, raw_pattern) – case SENSITIVE unless noted.
# ---------------------------------------------------------------------------
_RAW_PATTERNS: List[Tuple[str, str, int]] = [
    # AWS access key ID
    (
        "aws_access_key",
        r"\bAKIA[0-9A-Z]{16}\b",
        0,
    ),
    # AWS secret access key (usually follows AKIA key assignment)
    (
        "aws_secret_key",
        r"(?i)aws.{0,30}secret.{0,10}['\"\s:=]+([A-Za-z0-9/+]{40})",
        re.IGNORECASE,
    ),
    # GitHub personal / oauth / app tokens (ghp_, gho_, ghu_, ghs_, ghr_)
    (
        "github_token",
        r"\b(ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36,}\b",
        0,
    ),
    # Stripe publishable / secret keys
    (
        "stripe_key",
        r"\b(sk|pk)_(test|live)_[0-9A-Za-z]{24,}\b",
        0,
    ),
    # OpenAI / Anthropic-style keys  sk-...
    (
        "openai_api_key",
        r"\bsk-[A-Za-z0-9]{20,}\b",
        0,
    ),
    # Slack tokens
    (
        "slack_token",
        r"\bxox[baprs]-[0-9A-Za-z\-]{10,}\b",
        0,
    ),
    # Google API key
    (
        "google_api_key",
        r"\bAIza[0-9A-Za-z\-_]{35}\b",
        0,
    ),
    # JSON Web Token
    (
        "jwt",
        r"\beyJ[A-Za-z0-9\-_]{10,}\.[A-Za-z0-9\-_]{10,}\.[A-Za-z0-9\-_]{10,}\b",
        0,
    ),
    # PEM private key block
    (
        "private_key_pem",
        r"-----BEGIN\s+(RSA|EC|OPENSSH|DSA|PGP|PRIVATE)\s+PRIVATE\s+KEY",
        re.IGNORECASE,
    ),
    # Generic API key / token / secret assignment in code or config
    (
        "generic_api_key",
        r"(?i)(?:api[_\-]?key|api[_\-]?secret|auth[_\-]?token|access[_\-]?token)"
        r"[\s]*[=:\"']+[\s]*['\"]?([A-Za-z0-9\-_\.]{20,})['\"]?",
        re.IGNORECASE,
    ),
    # Password literal in code / config  password = "s3cr3t!"
    (
        "password_literal",
        r"(?i)\b(?:password|passwd|pwd)\s*[=:]\s*['\"]([^'\"]{8,})['\"]",
        re.IGNORECASE,
    ),
    # Hex-encoded secret (32-64 hex chars after a keyword)
    (
        "hex_secret",
        r"(?i)(?:secret|token|key)\s*[=:\"'\s]+([0-9a-f]{32,64})\b",
        re.IGNORECASE,
    ),
    # Bearer tokens in HTTP headers
    (
        "bearer_token",
        r"(?i)\bAuthorization\s*:\s*Bearer\s+([A-Za-z0-9\-_\.~+/]{20,}={0,3})\b",
        re.IGNORECASE,
    ),
]


class SecretsDetector(BaseDetector):
    """
    Detects hard-coded credentials and API secrets in text.

    Decision: BLOCK (score 0.95) — secrets should never pass through.
    Multiple hits raise the score up to 0.99.
    """

    name = "secrets"

    def __init__(self) -> None:
        self._patterns: List[Tuple[str, re.Pattern[str]]] = [
            (label, re.compile(pat, flags))
            for label, pat, flags in _RAW_PATTERNS
        ]

    def detect(self, text: str, **kwargs: Any) -> Dict[str, Any]:
        found: List[str] = []

        for label, pattern in self._patterns:
            if pattern.search(text):
                found.append(label)

        if not found:
            return self._allow()

        score = min(0.95 + 0.01 * (len(found) - 1), 0.99)
        return self._block(
            score=score,
            details={
                "secret_types": found,
                "count": len(found),
            },
        )
