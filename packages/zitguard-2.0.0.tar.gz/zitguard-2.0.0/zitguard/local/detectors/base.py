"""
ZITGUARD AI — Python SDK
BaseDetector: abstract base class for all local (serverless) detectors.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict


class BaseDetector(ABC):
    """
    Every local detector must subclass this and implement ``detect()``.

    The returned dict matches the per-detector slice of the server's response:
        {
            "decision":  "ALLOW" | "BLOCK" | "REDACT" | "WARN" | "TRANSFORM",
            "score":     float,      # 0.0 – 1.0
            "triggered": bool,
            "details":   dict,       # detector-specific metadata
        }
    """

    #: Detector name used in EvaluationResult.detector_results keys.
    name: str = "base"

    @abstractmethod
    def detect(self, text: str, **kwargs: Any) -> Dict[str, Any]:
        """Run the detector on *text* and return a result dict."""
        ...

    # ------------------------------------------------------------------ #
    # Convenience factories
    # ------------------------------------------------------------------ #

    def _allow(self, score: float = 0.0, details: Dict | None = None) -> Dict[str, Any]:
        return {
            "decision": "ALLOW",
            "score": round(score, 4),
            "triggered": False,
            "details": details or {},
        }

    def _block(self, score: float = 1.0, details: Dict | None = None) -> Dict[str, Any]:
        return {
            "decision": "BLOCK",
            "score": round(score, 4),
            "triggered": True,
            "details": details or {},
        }

    def _warn(self, score: float = 0.5, details: Dict | None = None) -> Dict[str, Any]:
        return {
            "decision": "WARN",
            "score": round(score, 4),
            "triggered": True,
            "details": details or {},
        }

    def _redact(self, score: float = 0.8, details: Dict | None = None) -> Dict[str, Any]:
        return {
            "decision": "REDACT",
            "score": round(score, 4),
            "triggered": True,
            "details": details or {},
        }
