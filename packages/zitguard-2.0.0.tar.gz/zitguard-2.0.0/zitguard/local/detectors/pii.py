"""
ZITGUARD AI — Python SDK
PIIDetector: regex-based personally-identifiable information detector.

Detects and (optionally) redacts:
  email, SSN, US phone, credit card numbers, IP addresses,
  passport-style IDs, date-of-birth literals, generic bank account numbers.

Decision: REDACT (the LocalEngine will call pii.redact() to produce sanitized text).
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

from .base import BaseDetector

# ---------------------------------------------------------------------------
# (label, regex_string) pairs — compiled once at import time.
# ---------------------------------------------------------------------------
_RAW_PATTERNS: List[Tuple[str, str]] = [
    # E-mail
    (
        "email",
        r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b",
    ),
    # US Social Security Number  XXX-XX-XXXX
    (
        "ssn",
        r"\b(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b",
    ),
    # US phone  (xxx) xxx-xxxx / xxx.xxx.xxxx / +1-xxx-xxx-xxxx
    (
        "phone_us",
        r"\b(?:\+1[\s.\-]?)?\(?\d{3}\)?[\s.\-]?\d{3}[\s.\-]\d{4}\b",
    ),
    # Major credit card numbers (Visa, MC, Amex, Discover)
    (
        "credit_card",
        r"\b(?:"
        r"4[0-9]{12}(?:[0-9]{3})?"           # Visa
        r"|5[1-5][0-9]{14}"                   # Mastercard
        r"|3[47][0-9]{13}"                    # Amex
        r"|6(?:011|5[0-9]{2})[0-9]{12}"      # Discover
        r"|3(?:0[0-5]|[68][0-9])[0-9]{11}"   # Diners
        r")\b",
    ),
    # IPv4 address
    (
        "ip_address",
        r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}"
        r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b",
    ),
    # Passport-style (1-2 letters + 6-9 digits, standalone)
    (
        "passport",
        r"\b[A-Z]{1,2}\d{6,9}\b",
    ),
    # Date of birth expressed inline
    (
        "date_of_birth",
        r"(?i)\b(?:born|dob|date\s+of\s+birth)\s*[:\-]?\s*"
        r"\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}\b",
    ),
    # Generic bank account numbers (8-17 consecutive digits, conservative)
    (
        "bank_account",
        r"(?i)(?:account|acct|iban|routing)\s*(?:number|no\.?|#)?\s*[:\-]?\s*\d{8,17}\b",
    ),
    # UK National Insurance Number
    (
        "national_insurance",
        r"\b[A-Z]{2}\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b",
    ),
]


class PIIDetector(BaseDetector):
    """
    Detects PII in text and signals REDACT so the engine can strip it.

    score  = min(0.3 × number_of_pii_types_found, 1.0)
    """

    name = "pii"

    def __init__(self) -> None:
        self._patterns: List[Tuple[str, re.Pattern[str]]] = [
            (label, re.compile(pat, re.UNICODE))
            for label, pat in _RAW_PATTERNS
        ]

    # ------------------------------------------------------------------
    # BaseDetector interface
    # ------------------------------------------------------------------

    def detect(self, text: str, **kwargs: Any) -> Dict[str, Any]:
        found: Dict[str, int] = {}

        for label, pattern in self._patterns:
            matches = pattern.findall(text)
            if matches:
                found[label] = len(matches)

        if not found:
            return self._allow()

        score = min(0.3 * len(found), 1.0)
        return self._redact(
            score=score,
            details={"pii_types": found, "type_count": len(found)},
        )

    # ------------------------------------------------------------------
    # Redaction helper — called by LocalEngine when decision == REDACT
    # ------------------------------------------------------------------

    def redact(self, text: str) -> str:
        """Return *text* with all detected PII replaced by placeholders."""
        result = text
        for label, pattern in self._patterns:
            result = pattern.sub(f"[{label.upper()}_REDACTED]", result)
        return result
