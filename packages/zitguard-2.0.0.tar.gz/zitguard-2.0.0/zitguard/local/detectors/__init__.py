"""
ZITGUARD AI — Python SDK
Local detector registry.
"""
from .base import BaseDetector
from .exfiltration import ExfiltrationDetector
from .pii import PIIDetector
from .prompt_injection import PromptInjectionDetector
from .secrets import SecretsDetector
from .toxicity import ToxicityDetector

__all__ = [
    "BaseDetector",
    "PromptInjectionDetector",
    "PIIDetector",
    "ToxicityDetector",
    "SecretsDetector",
    "ExfiltrationDetector",
]
