"""
ZITGUARD AI — Python SDK
PromptInjectionDetector: regex-based, zero-dependency detector.

Catches:
  - Classic "ignore / forget / override instructions" patterns
  - Role / identity manipulation (DAN, jailbreaks, persona swaps)
  - System-prompt leaking attempts
  - Delimiter / token smuggling
  - Encoding tricks (base64 decode commands)
"""
from __future__ import annotations

import re
from typing import Any, Dict, List

from .base import BaseDetector

# ---------------------------------------------------------------------------
# Pattern library
# Each tuple is (regex_string, human_readable_label).
# Patterns are matched case-insensitively against the full text.
# ---------------------------------------------------------------------------
_RAW_PATTERNS: List[tuple[str, str]] = [
    # Ignore / override instructions
    (
        r"ignore\s+(all\s+)?(previous|prior|above|earlier|your)\s+"
        r"(instructions?|prompts?|rules?|system\s+prompts?|context)",
        "ignore_instructions",
    ),
    (
        r"disregard\s+(all\s+)?(previous|prior|above|earlier|your)\s+"
        r"(instructions?|prompts?|rules?|directives?)",
        "disregard_instructions",
    ),
    (
        r"forget\s+(everything|all|your\s+previous|prior\s+instructions?|the\s+above)",
        "forget_instructions",
    ),
    (
        r"override\s+(your\s+)?(instructions?|system|rules?|prompts?|policies?)",
        "override_instructions",
    ),
    (
        r"(stop|cease)\s+(following|obeying)\s+(your\s+)?"
        r"(instructions?|rules?|guidelines?|policies?)",
        "stop_following",
    ),
    # Role / identity manipulation
    (r"you\s+are\s+now\s+(a|an|the)\s+\w+", "you_are_now"),
    (r"pretend\s+(you\s+are|to\s+be)\s+", "pretend_roleplay"),
    (r"act\s+as\s+(if\s+you\s+are\s+)?(a|an|the)?\s*\w+", "act_as"),
    (r"roleplay\s+as\b", "roleplay_as"),
    (r"simulate\s+(being\s+)?(a|an)?\s*\w+", "simulate"),
    (r"(switch|change)\s+(to|your)\s+(personality|mode|persona)\b", "persona_switch"),
    # Jailbreaks
    (r"\bDAN\b", "dan_jailbreak"),
    (r"jailbreak", "jailbreak_keyword"),
    (r"developer\s+mode", "developer_mode"),
    (r"do\s+anything\s+now", "do_anything_now"),
    (
        r"without\s+(any\s+)?(restrictions?|limits?|limitations?|filters?|"
        r"safety\s+guidelines?|guardrails?)",
        "bypass_restrictions",
    ),
    (
        r"bypass\s+(safety|filter|restriction|guardrail|content\s+policy|moderation)",
        "bypass_safety",
    ),
    (r"(remove|disable|turn\s+off)\s+(your\s+)?(safety|filter|restriction)", "disable_safety"),
    # System-prompt leaking
    (
        r"(reveal|show|print|output|tell\s+me|display|repeat)\s+"
        r"(your\s+)?(system\s+prompt|initial\s+prompt|instructions?|rules?)",
        "leak_system_prompt",
    ),
    (
        r"what\s+(are|were|is)\s+(your\s+)?(instructions?|system\s+prompt|rules?|directives?)",
        "query_system_prompt",
    ),
    # Encoding / obfuscation tricks
    (r"base64\s*(decode|encode|encoded|decoded)", "base64_trick"),
    (r"rot\s*13", "rot13_trick"),
    # Delimiter / token smuggling
    (r"(\[INST\]|\[\/INST\]|<\|im_start\|>|<\|im_end\|>|<\|system\|>)", "token_delimiter"),
    (r"(###\s*Human:|###\s*Assistant:|###\s*System:)", "chat_delimiter"),
    (r"(\[SYSTEM\]|\[USER\]|\[ASSISTANT\]|\[\/SYSTEM\])", "role_delimiter"),
    # SSRF / indirect injection via URLs
    (r"fetch\s+https?://\S+\s+(and\s+)?(execute|run|eval)", "ssrf_injection"),
]


class PromptInjectionDetector(BaseDetector):
    """
    Detects prompt injection and jailbreak attempts using regex pattern matching.

    Decision logic:
      - 1 pattern hit  → BLOCK (score 0.75)
      - 2+ pattern hits → BLOCK (score min(0.75 + 0.05 * extra, 0.99))
    """

    name = "prompt_injection"

    def __init__(self) -> None:
        self._patterns: List[tuple[re.Pattern[str], str]] = [
            (re.compile(pat, re.IGNORECASE | re.UNICODE), label)
            for pat, label in _RAW_PATTERNS
        ]

    def detect(self, text: str, **kwargs: Any) -> Dict[str, Any]:
        hits: List[str] = []
        matched_text: List[str] = []

        for pattern, label in self._patterns:
            m = pattern.search(text)
            if m:
                hits.append(label)
                matched_text.append(m.group(0)[:80])  # cap snippet length

        if not hits:
            return self._allow()

        score = min(0.75 + 0.04 * (len(hits) - 1), 0.99)
        return self._block(
            score=score,
            details={
                "match_count": len(hits),
                "categories": hits[:10],
                "snippets": matched_text[:5],
            },
        )
