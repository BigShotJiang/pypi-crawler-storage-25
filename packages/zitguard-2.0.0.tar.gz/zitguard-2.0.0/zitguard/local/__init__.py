"""
ZITGUARD AI — Python SDK
Local (serverless) evaluation sub-package.
"""
from .engine import LocalEngine

__all__ = ["LocalEngine"]
