"""
ZITGUARD AI — Python SDK
LocalEngine: orchestrates local (serverless) evaluation.

Returns dicts in exactly the same shape as the ZITGUARD Runtime HTTP API so
that EvaluationResult.from_dict() works without modification.

Response schema
---------------
{
    "decision":       "ALLOW" | "BLOCK" | "REDACT" | "WARN" | "TRANSFORM",
    "risk_score":     float,          # 0.0 – 1.0
    "rule_hits":      List[str],      # detector names that fired
    "detectors":      {               # per-detector breakdown
        "<name>": {
            "decision":  str,
            "score":     float,
            "triggered": bool,
            "details":   dict,
        },
        ...
    },
    "sanitized_text": str | None,     # populated on REDACT
    "quality":        dict | None,    # populated by evaluate_output when context provided
    "_latency_ms":    int,            # injected by this engine
}
"""
from __future__ import annotations

import re
import time
from typing import Any, Dict, List, Optional

from .detectors.exfiltration import ExfiltrationDetector
from .detectors.pii import PIIDetector
from .detectors.prompt_injection import PromptInjectionDetector
from .detectors.secrets import SecretsDetector
from .detectors.toxicity import ToxicityDetector
from .detectors.base import BaseDetector

# ---------------------------------------------------------------------------
# Decision priority  (higher = wins when merging multi-detector results)
# ---------------------------------------------------------------------------
_PRIORITY: Dict[str, int] = {
    "BLOCK":     5,
    "REDACT":    4,
    "WARN":      3,
    "TRANSFORM": 2,
    "ALLOW":     1,
}

# ---------------------------------------------------------------------------
# Per-path detector suites  (instantiated once — detectors are stateless)
# ---------------------------------------------------------------------------
_INPUT_DETECTORS: List[BaseDetector] = [
    PromptInjectionDetector(),
    PIIDetector(),
    ToxicityDetector(),
    SecretsDetector(),
]

_OUTPUT_DETECTORS: List[BaseDetector] = [
    PIIDetector(),
    ToxicityDetector(),
    SecretsDetector(),
]

_TOOL_DETECTORS: List[BaseDetector] = [
    ExfiltrationDetector(),
    SecretsDetector(),
    PIIDetector(),
]


def _merge_decision(results: Dict[str, Dict[str, Any]]) -> tuple[str, float, List[str]]:
    """
    Fold per-detector results into a single final decision, risk_score,
    and list of triggered detector names (rule_hits).
    """
    final_decision = "ALLOW"
    max_score = 0.0
    rule_hits: List[str] = []

    for name, det in results.items():
        decision = det.get("decision", "ALLOW")
        score = float(det.get("score", 0.0))
        triggered = det.get("triggered", False)

        if _PRIORITY.get(decision, 0) > _PRIORITY.get(final_decision, 0):
            final_decision = decision

        if score > max_score:
            max_score = score

        if triggered:
            rule_hits.append(name)

    return final_decision, round(max_score, 4), rule_hits


def _apply_redaction(
    text: str,
    detectors: List[BaseDetector],
    results: Dict[str, Dict[str, Any]],
) -> Optional[str]:
    """
    If the final decision includes REDACT, find the PII detector and use its
    ``redact()`` method to produce sanitized text.
    """
    for det in detectors:
        if det.name == "pii" and hasattr(det, "redact"):
            if results.get("pii", {}).get("triggered"):
                return det.redact(text)  # type: ignore[attr-defined]
    return None


def _quality_scores(text: str, context: str) -> Dict[str, float]:
    """
    Heuristic quality scoring when context is provided.

    These scores are best-effort approximations using only statistical
    features; they are NOT equivalent to LLM-based quality evaluation.

    groundedness  — keyword overlap (response uses words from context)
    relevance     — proportion of context keywords echoed in response
    coherence     — fraction of well-formed sentences (≥ 3 words)
    fluency       — average words-per-sentence closeness to 15 (optimal)
    intent_resolution / task_adherence / tool_call_accuracy
                  — always 0.0 (cannot be determined without an LLM)
    """
    word_re = re.compile(r"\b\w{4,}\b")
    sentence_re = re.compile(r"[^.!?]+[.!?]?")

    context_words = set(word_re.findall(context.lower()))
    response_words = set(word_re.findall(text.lower()))

    # Relevance: response word overlap with context vocabulary
    if context_words:
        relevance = len(context_words & response_words) / len(context_words)
        relevance = min(relevance, 1.0)
    else:
        relevance = 0.5

    # Groundedness: conservative (assume 80 % of overlapping words are grounded)
    groundedness = round(relevance * 0.80, 4)

    # Coherence: proportion of sentences that have ≥ 3 words
    sentences = [s.strip() for s in sentence_re.findall(text) if s.strip()]
    valid = [s for s in sentences if len(s.split()) >= 3]
    coherence = (len(valid) / len(sentences)) if sentences else 0.5
    coherence = round(min(coherence, 1.0), 4)

    # Fluency: penalise deviation from the ~15-word sweet spot
    word_counts = [len(s.split()) for s in valid]
    if word_counts:
        avg_words = sum(word_counts) / len(word_counts)
        fluency = round(max(1.0 - abs(avg_words - 15) / 20, 0.0), 4)
    else:
        fluency = 0.5

    return {
        "groundedness": groundedness,
        "relevance": round(relevance, 4),
        "coherence": coherence,
        "fluency": fluency,
        "intent_resolution": 0.0,
        "task_adherence": 0.0,
        "tool_call_accuracy": 0.0,
    }


class LocalEngine:
    """
    Zero-dependency, serverless evaluation engine.

    This engine replicates the ZITGUARD Runtime evaluation contract locally
    so that users can run guardrails without deploying any server.
    """

    def __init__(
        self,
        input_detectors: Optional[List[BaseDetector]] = None,
        output_detectors: Optional[List[BaseDetector]] = None,
        tool_detectors: Optional[List[BaseDetector]] = None,
    ) -> None:
        """
        Parameters
        ----------
        input_detectors  : Override the default set used by evaluate_input().
        output_detectors : Override the default set used by evaluate_output().
        tool_detectors   : Override the default set used by evaluate_tool().

        Pass custom detector instances to extend or replace the built-in suite.
        """
        self._input_detectors = input_detectors or _INPUT_DETECTORS
        self._output_detectors = output_detectors or _OUTPUT_DETECTORS
        self._tool_detectors = tool_detectors or _TOOL_DETECTORS

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate_input(
        self,
        text: str,
        detectors: Optional[List[str]] = None,
        **_kwargs: Any,
    ) -> Dict[str, Any]:
        """Evaluate user-supplied prompt text. Returns a runtime-compatible dict."""
        return self._run(text, self._input_detectors, allowed=detectors)

    def evaluate_output(
        self,
        text: str,
        context: Optional[str] = None,
        detectors: Optional[List[str]] = None,
        **_kwargs: Any,
    ) -> Dict[str, Any]:
        """Evaluate LLM response text. Adds quality scores when *context* is given."""
        result = self._run(text, self._output_detectors, allowed=detectors)
        if context:
            result["quality"] = _quality_scores(text, context)
        return result

    def evaluate_tool(
        self,
        text: str,
        detectors: Optional[List[str]] = None,
        **_kwargs: Any,
    ) -> Dict[str, Any]:
        """Evaluate tool / function-call result text."""
        return self._run(text, self._tool_detectors, allowed=detectors)

    def health(self) -> Dict[str, Any]:
        """Local health response — mirrors the runtime /health contract."""
        return {
            "status": "ok",
            "mode": "local",
            "version": "2.0.0",
            "uptime_seconds": 0,
        }

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run(
        self,
        text: str,
        suite: List[BaseDetector],
        allowed: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        t0 = time.monotonic()

        detector_results: Dict[str, Dict[str, Any]] = {}
        for det in suite:
            if allowed is not None and det.name not in allowed:
                continue
            detector_results[det.name] = det.detect(text)

        decision, risk_score, rule_hits = _merge_decision(detector_results)

        sanitized_text: Optional[str] = None
        if decision == "REDACT":
            sanitized_text = _apply_redaction(text, suite, detector_results)

        latency_ms = int((time.monotonic() - t0) * 1000)

        return {
            "decision": decision,
            "risk_score": risk_score,
            "rule_hits": rule_hits,
            "detectors": detector_results,
            "sanitized_text": sanitized_text,
            "_latency_ms": latency_ms,
        }
