"""
ZITGUARD AI — Python SDK
Data models (pure dataclasses, no external dependencies)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class DetectorResult:
    """Per-detector breakdown returned by the Runtime."""
    name: str
    decision: str                   # ALLOW | BLOCK | REDACT | WARN | TRANSFORM
    score: float = 0.0
    triggered: bool = False
    details: Dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, name: str, data: dict) -> "DetectorResult":
        return cls(
            name=name,
            decision=data.get("decision", "ALLOW"),
            score=float(data.get("score", 0.0)),
            triggered=data.get("triggered", False),
            details=data.get("details", {}),
        )


@dataclass
class QualityScores:
    """Output-quality metrics (evaluate_output only)."""
    groundedness: float = 0.0
    relevance: float = 0.0
    coherence: float = 0.0
    fluency: float = 0.0
    intent_resolution: float = 0.0
    task_adherence: float = 0.0
    tool_call_accuracy: float = 0.0

    @property
    def overall(self) -> float:
        scores = [
            self.groundedness, self.relevance, self.coherence,
            self.fluency, self.intent_resolution, self.task_adherence,
            self.tool_call_accuracy,
        ]
        valid = [s for s in scores if s > 0]
        return round(sum(valid) / len(valid), 4) if valid else 0.0

    @classmethod
    def from_dict(cls, data: dict) -> "QualityScores":
        return cls(
            groundedness=float(data.get("groundedness", 0.0)),
            relevance=float(data.get("relevance", 0.0)),
            coherence=float(data.get("coherence", 0.0)),
            fluency=float(data.get("fluency", 0.0)),
            intent_resolution=float(data.get("intent_resolution", 0.0)),
            task_adherence=float(data.get("task_adherence", 0.0)),
            tool_call_accuracy=float(data.get("tool_call_accuracy", 0.0)),
        )


@dataclass
class EvaluationResult:
    """
    Returned by evaluate_input(), evaluate_output(), and evaluate_tool().

    decision        — final policy decision (ALLOW / BLOCK / REDACT / WARN / TRANSFORM)
    risk_score      — float 0–1 (higher = riskier)
    latency_ms      — round-trip time in milliseconds
    rule_hits       — list of rule IDs that fired
    detector_results— per-detector breakdown keyed by detector name
    sanitized_text  — redacted/transformed version of the text (if REDACT/TRANSFORM)
    quality         — quality scores (output evaluation only)
    raw             — full raw response dict from the Runtime
    """
    decision: str
    risk_score: float
    latency_ms: int
    rule_hits: List[str] = field(default_factory=list)
    detector_results: Dict[str, DetectorResult] = field(default_factory=dict)
    sanitized_text: Optional[str] = None
    quality: Optional[QualityScores] = None
    raw: Dict = field(default_factory=dict)

    # ------------------------------------------------------------------ #
    # Convenience properties
    # ------------------------------------------------------------------ #
    @property
    def is_blocked(self) -> bool:
        return self.decision == "BLOCK"

    @property
    def is_allowed(self) -> bool:
        return self.decision == "ALLOW"

    @property
    def is_redacted(self) -> bool:
        return self.decision == "REDACT"

    @property
    def is_warned(self) -> bool:
        return self.decision == "WARN"

    @property
    def safe_text(self) -> Optional[str]:
        """
        Returns sanitized_text if the content was redacted/transformed,
        or None otherwise.  Useful for passing the cleaned text to the LLM.
        """
        return self.sanitized_text

    # ------------------------------------------------------------------ #
    # Factory
    # ------------------------------------------------------------------ #
    @classmethod
    def from_dict(cls, data: dict, latency_ms: int = 0) -> "EvaluationResult":
        detectors: Dict[str, DetectorResult] = {
            name: DetectorResult.from_dict(name, det)
            for name, det in data.get("detectors", {}).items()
        }

        quality: Optional[QualityScores] = None
        if "quality" in data and data["quality"]:
            quality = QualityScores.from_dict(data["quality"])

        return cls(
            decision=data.get("decision", "ALLOW"),
            risk_score=float(data.get("risk_score", 0.0)),
            latency_ms=latency_ms,
            rule_hits=data.get("rule_hits", []),
            detector_results=detectors,
            sanitized_text=data.get("sanitized_text"),
            quality=quality,
            raw=data,
        )

    def __repr__(self) -> str:
        return (
            f"EvaluationResult(decision={self.decision!r}, "
            f"risk_score={self.risk_score:.2f}, latency_ms={self.latency_ms})"
        )
