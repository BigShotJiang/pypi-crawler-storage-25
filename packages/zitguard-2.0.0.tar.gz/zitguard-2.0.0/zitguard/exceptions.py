"""
ZITGUARD AI — Python SDK
Exceptions module
"""


class ZitguardError(Exception):
    """Base exception for all ZITGUARD SDK errors."""
    pass


class ZitguardConnectionError(ZitguardError):
    """Raised when the SDK cannot reach the ZITGUARD Runtime."""

    def __init__(self, url: str, cause: Exception | None = None):
        self.url = url
        self.cause = cause
        msg = f"Cannot connect to ZITGUARD Runtime at {url}"
        if cause:
            msg += f": {cause}"
        super().__init__(msg)


class ZitguardAPIError(ZitguardError):
    """Raised when the Runtime returns a non-2xx HTTP status."""

    def __init__(self, status_code: int, body: str = ""):
        self.status_code = status_code
        self.body = body
        super().__init__(
            f"ZITGUARD Runtime returned HTTP {status_code}: {body[:200]}"
        )


class ZitguardTimeoutError(ZitguardError):
    """Raised when a request to the Runtime exceeds the configured timeout."""

    def __init__(self, timeout: float):
        self.timeout = timeout
        super().__init__(
            f"ZITGUARD Runtime did not respond within {timeout}s"
        )


class ZitguardBlockedError(ZitguardError):
    """
    Optional: raise this instead of returning a result when decision == BLOCK.
    Useful for middleware-style usage where you want to abort the pipeline
    immediately on a block decision.
    """

    def __init__(self, reason: str, risk_score: float = 1.0):
        self.reason = reason
        self.risk_score = risk_score
        super().__init__(f"Content blocked by ZITGUARD: {reason}")
