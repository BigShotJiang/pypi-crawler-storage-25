"""
ZITGUARD AI — Python SDK
Internal HTTP helper — wraps requests.Session with retry logic.
Not part of the public API.
"""
from __future__ import annotations

import time
from typing import Any, Dict, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .exceptions import (
    ZitguardAPIError,
    ZitguardConnectionError,
    ZitguardTimeoutError,
)


def _build_session(retries: int, backoff: float = 0.3) -> requests.Session:
    """Create a requests.Session with automatic retry on connection errors."""
    session = requests.Session()
    retry = Retry(
        total=retries,
        backoff_factor=backoff,
        status_forcelist=[502, 503, 504],
        allowed_methods=["POST", "GET"],
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


class HttpClient:
    """Low-level HTTP client used by GuardrailsClient."""

    def __init__(
        self,
        base_url: str,
        timeout: float,
        retries: int,
        api_key: Optional[str] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = _build_session(retries)

        # Build base headers
        self._headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "zitguard-python/1.0.0",
        }
        if api_key:
            self._headers["Authorization"] = f"Bearer {api_key}"
        if extra_headers:
            self._headers.update(extra_headers)

    def post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """POST JSON to the Runtime; return parsed response dict."""
        url = f"{self.base_url}{path}"
        t0 = time.monotonic()

        try:
            resp = self._session.post(
                url,
                json=payload,
                headers=self._headers,
                timeout=self.timeout,
            )
        except requests.exceptions.Timeout as exc:
            raise ZitguardTimeoutError(self.timeout) from exc
        except requests.exceptions.ConnectionError as exc:
            raise ZitguardConnectionError(self.base_url, exc) from exc

        latency_ms = int((time.monotonic() - t0) * 1000)

        if not resp.ok:
            raise ZitguardAPIError(resp.status_code, resp.text)

        data = resp.json()
        data["_latency_ms"] = latency_ms
        return data

    def get(self, path: str) -> Dict[str, Any]:
        """GET from the Runtime; return parsed response dict."""
        url = f"{self.base_url}{path}"
        try:
            resp = self._session.get(
                url,
                headers=self._headers,
                timeout=self.timeout,
            )
        except requests.exceptions.Timeout as exc:
            raise ZitguardTimeoutError(self.timeout) from exc
        except requests.exceptions.ConnectionError as exc:
            raise ZitguardConnectionError(self.base_url, exc) from exc

        if not resp.ok:
            raise ZitguardAPIError(resp.status_code, resp.text)

        return resp.json()
