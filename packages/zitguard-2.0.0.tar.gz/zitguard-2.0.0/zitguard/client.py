"""
ZITGUARD AI — Python SDK
Main client: GuardrailsClient  +  LocalGuardrailsClient convenience alias.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .exceptions import ZitguardBlockedError
from .models import EvaluationResult


class GuardrailsClient:
    """
    Primary entry-point for the ZITGUARD Python SDK.

    Two operation modes
    -------------------

    **Server mode** (default) — calls a live ZITGUARD Runtime:

    >>> from zitguard import GuardrailsClient
    >>> client = GuardrailsClient()                        # localhost:8080
    >>> result = client.evaluate_input("Hello, world!")

    **Serverless / local mode** — all evaluation runs in-process, no network:

    >>> client = GuardrailsClient(serverless=True)
    >>> result = client.evaluate_input("Ignore previous instructions.")
    >>> print(result.decision)   # BLOCK

    Remote Control Plane (server mode)
    ------------------------------------
    >>> client = GuardrailsClient(
    ...     base_url="https://api.zitguard.zitrino.com",
    ...     api_key="zgk_xxxxxx",
    ...     tenant_id="acme",
    ... )

    Raise on block
    --------------
    >>> result = client.evaluate_input(text, raise_on_block=True)
    # Raises ZitguardBlockedError if decision == BLOCK
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8080",
        api_key: Optional[str] = None,
        tenant_id: Optional[str] = None,
        app_id: Optional[str] = None,
        timeout: float = 5.0,
        retries: int = 2,
        extra_headers: Optional[Dict[str, str]] = None,
        serverless: bool = False,
    ):
        """
        Parameters
        ----------
        base_url     : ZITGUARD Runtime or Control Plane base URL.
                       Ignored when *serverless=True*.
        api_key      : Bearer token for Control Plane auth (Growth/Enterprise).
        tenant_id    : Default tenant scope applied to every request.
        app_id       : Default application scope applied to every request.
        timeout      : Per-request timeout in seconds (server mode only).
        retries      : Automatic retries on transient errors (server mode only).
        extra_headers: Additional HTTP headers (server mode only).
        serverless   : When True, all evaluation runs locally — no server,
                       no network, no dependencies beyond the stdlib.
        """
        self._serverless = serverless
        self._defaults: Dict[str, Any] = {}

        if tenant_id:
            self._defaults["tenant_id"] = tenant_id
        if app_id:
            self._defaults["app_id"] = app_id

        if serverless:
            # ── Local (serverless) mode ───────────────────────────────────
            from .local.engine import LocalEngine  # lazy import

            self._http = None               # type: ignore[assignment]
            self._local = LocalEngine()
        else:
            # ── Server mode (original behaviour) ─────────────────────────
            from ._http import HttpClient

            self._http = HttpClient(
                base_url=base_url,
                timeout=timeout,
                retries=retries,
                api_key=api_key,
                extra_headers=extra_headers,
            )
            self._local = None              # type: ignore[assignment]

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def evaluate_input(
        self,
        text: str,
        *,
        tenant_id: Optional[str] = None,
        app_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        detectors: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        raise_on_block: bool = False,
    ) -> EvaluationResult:
        """
        Evaluate user input (prompt) before sending it to an LLM.

        Parameters
        ----------
        text          : The raw user input text.
        tenant_id     : Override default tenant scope.
        app_id        : Override default application scope.
        agent_id      : Agent identifier for granular policy targeting.
        session_id    : Conversation session identifier.
        user_id       : End-user identifier for audit logs.
        detectors     : Allowlist of detectors to run (None = all enabled).
        metadata      : Arbitrary key-value metadata (server mode only).
        raise_on_block: Raise ZitguardBlockedError instead of returning result.

        Returns
        -------
        EvaluationResult
        """
        if self._serverless:
            raw = self._local.evaluate_input(text, detectors=detectors)
        else:
            payload = self._build_payload(
                text, tenant_id, app_id, agent_id,
                session_id, user_id, detectors, metadata,
            )
            raw = self._http.post("/v1/evaluate/input", payload)

        result = EvaluationResult.from_dict(raw, latency_ms=raw.pop("_latency_ms", 0))

        if raise_on_block and result.is_blocked:
            reason = raw.get("reason") or "content blocked"
            raise ZitguardBlockedError(reason, result.risk_score)

        return result

    def evaluate_output(
        self,
        text: str,
        *,
        context: Optional[str] = None,
        tenant_id: Optional[str] = None,
        app_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        detectors: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        raise_on_block: bool = False,
    ) -> EvaluationResult:
        """
        Evaluate LLM output before returning it to the user.

        Parameters
        ----------
        text    : The LLM-generated response text.
        context : Optional original prompt for groundedness / relevance scoring.
        (remaining params same as evaluate_input)

        Returns
        -------
        EvaluationResult — includes quality scores when context is provided.
        """
        if self._serverless:
            raw = self._local.evaluate_output(
                text, context=context, detectors=detectors,
            )
        else:
            payload = self._build_payload(
                text, tenant_id, app_id, agent_id,
                session_id, user_id, detectors, metadata,
            )
            if context:
                payload["context"] = context
            raw = self._http.post("/v1/evaluate/output", payload)

        result = EvaluationResult.from_dict(raw, latency_ms=raw.pop("_latency_ms", 0))

        if raise_on_block and result.is_blocked:
            reason = raw.get("reason") or "output blocked"
            raise ZitguardBlockedError(reason, result.risk_score)

        return result

    def evaluate_tool(
        self,
        text: str,
        *,
        tenant_id: Optional[str] = None,
        app_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        detectors: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        raise_on_block: bool = False,
    ) -> EvaluationResult:
        """
        Evaluate tool / function-call results in an agentic pipeline.

        Runs the Exfiltration and Secrets detectors at higher priority,
        in addition to the standard output detector suite.

        Returns
        -------
        EvaluationResult
        """
        if self._serverless:
            raw = self._local.evaluate_tool(text, detectors=detectors)
        else:
            payload = self._build_payload(
                text, tenant_id, app_id, agent_id,
                session_id, user_id, detectors, metadata,
            )
            raw = self._http.post("/v1/evaluate/tool", payload)

        result = EvaluationResult.from_dict(raw, latency_ms=raw.pop("_latency_ms", 0))

        if raise_on_block and result.is_blocked:
            reason = raw.get("reason") or "tool result blocked"
            raise ZitguardBlockedError(reason, result.risk_score)

        return result

    def health(self) -> Dict[str, Any]:
        """
        Check ZITGUARD Runtime health.

        In serverless mode returns a local status dict:
            { "status": "ok", "mode": "local", "version": "2.0.0" }

        In server mode returns the Runtime's health response.
        """
        if self._serverless:
            return self._local.health()
        return self._http.get("/health")

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    def _build_payload(
        self,
        text: str,
        tenant_id: Optional[str],
        app_id: Optional[str],
        agent_id: Optional[str],
        session_id: Optional[str],
        user_id: Optional[str],
        detectors: Optional[List[str]],
        metadata: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {**self._defaults, "text": text}

        if tenant_id:
            payload["tenant_id"] = tenant_id
        if app_id:
            payload["app_id"] = app_id
        if agent_id:
            payload["agent_id"] = agent_id
        if session_id:
            payload["session_id"] = session_id
        if user_id:
            payload["user_id"] = user_id
        if detectors:
            payload["detectors"] = detectors
        if metadata:
            payload["metadata"] = metadata

        return payload


# ---------------------------------------------------------------------------
# Convenience alias — idiomatic for fully local / offline usage
# ---------------------------------------------------------------------------

class LocalGuardrailsClient(GuardrailsClient):
    """
    A ``GuardrailsClient`` pre-configured for **serverless / local** operation.

    No server, no network, no configuration required.

    >>> from zitguard import LocalGuardrailsClient
    >>> client = LocalGuardrailsClient()
    >>> result = client.evaluate_input("Ignore all previous instructions.")
    >>> print(result.decision)   # BLOCK
    """

    def __init__(
        self,
        tenant_id: Optional[str] = None,
        app_id: Optional[str] = None,
    ) -> None:
        super().__init__(
            serverless=True,
            tenant_id=tenant_id,
            app_id=app_id,
        )
