#compdef crypt4gh-keygen

# Zsh completion for crypt4gh-keygen
# Install: place this file in a directory on your $fpath, e.g.:
#   cp _crypt4gh-keygen ~/.zsh/completions/
#   fpath=(~/.zsh/completions $fpath)
#   autoload -Uz compinit && compinit

_crypt4gh_keygen() {
  _arguments \
    '(- :)'{-h,--help}'[Show help and exit]' \
    '(- :)'{-v,--version}'[Show version and exit]' \
    '--log[Path to log file]:log file:_files' \
    '-f[Overwrite existing key files]' \
    '--pk[Public key output file]:public key file:_files' \
    '--sk[Secret key output file]:secret key file:_files' \
    '--nocrypt[Do not encrypt the private key with a passphrase]' \
    '-C[Comment to embed in the key]:comment' \
    '--relock[Re-encrypt an existing private key with a new passphrase]:existing secret key file:_files'
}

_crypt4gh_keygen "$@"
