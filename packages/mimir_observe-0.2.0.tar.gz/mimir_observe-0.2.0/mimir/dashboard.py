"""
Mimir local dashboard — HTTP server + trajectory storage.

Receives telemetry from the SDK, persists runs grouped by fingerprint,
and serves a single-page dashboard for viewing and diffing agent runs.
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
from datetime import datetime, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import urlparse, parse_qs

# ---------------------------------------------------------------------------
# Storage paths — all under ~/.mimir/
# ---------------------------------------------------------------------------

MIMIR_DIR = Path.home() / ".mimir"
TASK_GROUPS_FILE = MIMIR_DIR / "task_groups.json"
TRAJECTORIES_DIR = MIMIR_DIR / "trajectories"
TELEMETRY_DIR = MIMIR_DIR / "telemetry"


def _ensure_dirs():
    MIMIR_DIR.mkdir(exist_ok=True)
    TRAJECTORIES_DIR.mkdir(exist_ok=True)
    TELEMETRY_DIR.mkdir(exist_ok=True)


# ---------------------------------------------------------------------------
# FrameworkRecorder — persistence layer
# ---------------------------------------------------------------------------


class FrameworkRecorder:
    """Thread-safe persistence for task groups, trajectories, and telemetry."""

    def __init__(self):
        _ensure_dirs()
        self._lock = threading.Lock()
        self._active_runs: dict[str, dict] = {}  # run_id -> run data

    # --- task groups ---

    def _load_task_groups(self) -> dict:
        if TASK_GROUPS_FILE.exists():
            try:
                return json.loads(TASK_GROUPS_FILE.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def _save_task_groups(self, groups: dict) -> None:
        TASK_GROUPS_FILE.write_text(json.dumps(groups, indent=2))

    def register_task(self, data: dict) -> None:
        with self._lock:
            groups = self._load_task_groups()
            tid = data["task_type_id"]
            if tid not in groups:
                groups[tid] = {
                    "task_type_id": tid,
                    "name": data.get("name", ""),
                    "config": data.get("config", ""),
                    "config_hash": data.get("config_hash", ""),
                    "tools": data.get("tools", []),
                    "model": data.get("model", ""),
                    "run_count": 0,
                    "created_at": time.time(),
                }
            self._save_task_groups(groups)

    # --- runs ---

    def start_run(self, data: dict) -> None:
        run_id = data["run_id"]
        with self._lock:
            self._active_runs[run_id] = {
                "run_id": run_id,
                "task_type_id": data.get("task_type_id", ""),
                "task_name": data.get("task_name", ""),
                "input": data.get("input", {}),
                "started_at": data.get("started_at", time.time()),
                "steps": [],
            }

    def add_step(self, data: dict) -> None:
        run_id = data.get("run_id", "")
        with self._lock:
            run = self._active_runs.get(run_id)
            if run:
                step = {k: v for k, v in data.items() if k != "run_id"}
                run["steps"].append(step)

    def end_run(self, data: dict) -> None:
        run_id = data["run_id"]
        with self._lock:
            run = self._active_runs.pop(run_id, None)
            if run is None:
                # Reconstruct from end payload if we missed the start
                run = {
                    "run_id": run_id,
                    "task_type_id": data.get("task_type_id", ""),
                    "task_name": data.get("task_name", ""),
                    "input": {},
                    "started_at": data.get("ended_at", time.time()),
                    "steps": data.get("steps", []),
                }

            run.update({
                "status": data.get("status", "unknown"),
                "duration_s": data.get("duration_s", 0),
                "usage": data.get("usage", {}),
                "cost_usd": data.get("cost_usd"),
                "output": data.get("output"),
                "ended_at": data.get("ended_at", time.time()),
            })

            # If end payload has steps and run had none, use those
            if not run.get("steps") and data.get("steps"):
                run["steps"] = data["steps"]

            self._persist_run(run)

    def _persist_run(self, run: dict) -> None:
        """Save run to trajectory file (grouped by tool-call fingerprint) and telemetry."""
        # Compute fingerprint from tool step shapes
        fp = self._fingerprint(run.get("steps", []))
        traj_file = TRAJECTORIES_DIR / f"{fp}.json"

        # Load or create trajectory
        if traj_file.exists():
            try:
                traj = json.loads(traj_file.read_text())
            except (json.JSONDecodeError, OSError):
                traj = {"fingerprint": fp, "runs": []}
        else:
            traj = {"fingerprint": fp, "runs": []}

        traj["runs"].append(run)
        traj_file.write_text(json.dumps(traj, indent=2))

        # Update task group run count
        groups = self._load_task_groups()
        tid = run.get("task_type_id", "")
        if tid in groups:
            groups[tid]["run_count"] = groups[tid].get("run_count", 0) + 1
            groups[tid]["last_run_at"] = run.get("ended_at", time.time())
            self._save_task_groups(groups)

        # Write telemetry
        self._write_telemetry(run)

    def _fingerprint(self, steps: list[dict]) -> str:
        """SHA-256 of tool step shapes (type + tool name sequence)."""
        shapes = []
        for s in steps:
            if s.get("type") in ("tool", "tool_error"):
                shapes.append(f"{s.get('type')}:{s.get('tool', '')}")
        raw = "|".join(shapes) if shapes else "empty"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    def _write_telemetry(self, run: dict) -> None:
        """Append tool call records to daily JSONL telemetry file."""
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        path = TELEMETRY_DIR / f"{today}.jsonl"
        lines = []
        for step in run.get("steps", []):
            if step.get("type") in ("tool", "tool_error"):
                record = {
                    "run_id": run["run_id"],
                    "task_type_id": run.get("task_type_id", ""),
                    "task_name": run.get("task_name", ""),
                    "tool": step.get("tool", ""),
                    "type": step.get("type", ""),
                    "duration_ms": step.get("duration_ms", 0),
                    "ts": step.get("ts", time.time()),
                }
                lines.append(json.dumps(record))
        if lines:
            with open(path, "a") as f:
                f.write("\n".join(lines) + "\n")

    # --- query methods ---

    def get_overview(self) -> dict:
        groups = self._load_task_groups()
        total_runs = sum(g.get("run_count", 0) for g in groups.values())
        traj_count = len(list(TRAJECTORIES_DIR.glob("*.json")))
        return {
            "task_groups": len(groups),
            "total_runs": total_runs,
            "trajectories": traj_count,
            "active_runs": len(self._active_runs),
        }

    def get_task_groups(self) -> list[dict]:
        groups = self._load_task_groups()
        return sorted(groups.values(), key=lambda g: g.get("last_run_at", 0), reverse=True)

    def get_task_group(self, task_type_id: str) -> dict | None:
        groups = self._load_task_groups()
        group = groups.get(task_type_id)
        if not group:
            return None
        # Attach runs from all trajectory files that match this task
        runs = []
        for traj_file in TRAJECTORIES_DIR.glob("*.json"):
            try:
                traj = json.loads(traj_file.read_text())
                for r in traj.get("runs", []):
                    if r.get("task_type_id") == task_type_id:
                        runs.append(r)
            except (json.JSONDecodeError, OSError):
                continue
        group["runs"] = sorted(runs, key=lambda r: r.get("ended_at", 0), reverse=True)
        return group

    def get_divergence(self) -> list[dict]:
        """Cross-run divergence map — find fingerprint groups with multiple patterns."""
        divergences = []
        groups = self._load_task_groups()

        for tid, group in groups.items():
            fingerprints: dict[str, list] = {}
            for traj_file in TRAJECTORIES_DIR.glob("*.json"):
                try:
                    traj = json.loads(traj_file.read_text())
                    for r in traj.get("runs", []):
                        if r.get("task_type_id") == tid:
                            fp = traj["fingerprint"]
                            fingerprints.setdefault(fp, []).append(r["run_id"])
                except (json.JSONDecodeError, OSError):
                    continue

            if len(fingerprints) > 1:
                divergences.append({
                    "task_type_id": tid,
                    "task_name": group.get("name", ""),
                    "fingerprints": {fp: {"run_count": len(ids), "run_ids": ids} for fp, ids in fingerprints.items()},
                })

        return divergences

    def get_all_data(self) -> dict:
        """Full data export."""
        groups = self._load_task_groups()
        trajectories = {}
        for traj_file in TRAJECTORIES_DIR.glob("*.json"):
            try:
                traj = json.loads(traj_file.read_text())
                trajectories[traj_file.stem] = traj
            except (json.JSONDecodeError, OSError):
                continue
        return {"task_groups": groups, "trajectories": trajectories}


# ---------------------------------------------------------------------------
# HTTP handler
# ---------------------------------------------------------------------------

_recorder = FrameworkRecorder()


class DashboardHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        # Suppress default logging
        pass

    def _send_json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(data, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html: str, status: int = 200) -> None:
        body = html.encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {}

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        params = parse_qs(parsed.query)

        if path == "" or path == "/":
            self._send_html(_dashboard_html())
        elif path == "/api/overview":
            self._send_json(_recorder.get_overview())
        elif path == "/api/task-groups":
            self._send_json(_recorder.get_task_groups())
        elif path.startswith("/api/task-group/"):
            tid = path.split("/api/task-group/")[1].split("/")[0]
            result = _recorder.get_task_group(tid)
            if result:
                self._send_json(result)
            else:
                self._send_json({"error": "not found"}, 404)
        elif path == "/api/divergence":
            self._send_json(_recorder.get_divergence())
        elif path == "/api/data":
            self._send_json(_recorder.get_all_data())
        else:
            self._send_json({"error": "not found"}, 404)

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/")
        data = self._read_body()

        if path == "/api/task/register":
            _recorder.register_task(data)
            self._send_json({"ok": True})
        elif path == "/api/run/start":
            _recorder.start_run(data)
            self._send_json({"ok": True})
        elif path == "/api/run/step":
            _recorder.add_step(data)
            self._send_json({"ok": True})
        elif path == "/api/run/end":
            _recorder.end_run(data)
            self._send_json({"ok": True})
        else:
            self._send_json({"error": "not found"}, 404)


# ---------------------------------------------------------------------------
# Dashboard HTML (single-page app)
# ---------------------------------------------------------------------------


def _dashboard_html() -> str:
    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mimir</title>
<style>
  :root {
    --bg: #09090b; --surface: #18181b; --surface2: #1e1e22; --border: #27272a;
    --text: #fafafa; --text2: #d4d4d8; --muted: #71717a; --dim: #52525b;
    --accent: #6366f1; --accent2: #818cf8; --accent-bg: rgba(99,102,241,0.08);
    --green: #22c55e; --green-bg: rgba(34,197,94,0.08);
    --red: #ef4444; --red-bg: rgba(239,68,68,0.08);
    --amber: #f59e0b; --amber-bg: rgba(245,158,11,0.08);
    --cyan: #06b6d4; --cyan-bg: rgba(6,182,212,0.06);
    --radius: 8px;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', sans-serif; background: var(--bg); color: var(--text); font-size: 13px; line-height: 1.6; }
  code, .mono { font-family: 'SF Mono', 'Cascadia Code', 'Fira Code', 'JetBrains Mono', monospace; font-size: 12px; }

  /* Layout */
  .shell { display: flex; height: 100vh; overflow: hidden; }
  .sidebar { width: 280px; min-width: 280px; border-right: 1px solid var(--border); display: flex; flex-direction: column; background: var(--surface); }
  .main { flex: 1; overflow-y: auto; }

  /* Sidebar */
  .sidebar-header { padding: 20px 16px 12px; border-bottom: 1px solid var(--border); }
  .sidebar-header h1 { font-size: 15px; font-weight: 700; letter-spacing: -0.02em; }
  .sidebar-header h1 span { color: var(--accent2); }
  .sidebar-header p { color: var(--muted); font-size: 11px; margin-top: 2px; }
  .sidebar-nav { padding: 8px; flex: 1; overflow-y: auto; }
  .nav-section { padding: 8px 8px 4px; font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.06em; color: var(--dim); }
  .nav-item { display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-radius: 6px; cursor: pointer; color: var(--text2); transition: all 0.1s; }
  .nav-item:hover { background: var(--accent-bg); color: var(--text); }
  .nav-item.active { background: var(--accent-bg); color: var(--accent2); font-weight: 500; }
  .nav-item .count { margin-left: auto; font-size: 11px; color: var(--muted); background: var(--bg); padding: 0 6px; border-radius: 10px; }
  .nav-item .dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }
  .sidebar-stats { padding: 12px 16px; border-top: 1px solid var(--border); display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .sidebar-stat { text-align: center; }
  .sidebar-stat .val { font-size: 18px; font-weight: 700; }
  .sidebar-stat .lbl { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.04em; }

  /* Main content */
  .main-header { padding: 20px 32px 16px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; background: var(--bg); z-index: 10; }
  .main-header h2 { font-size: 16px; font-weight: 600; }
  .main-header .subtitle { color: var(--muted); font-size: 12px; margin-top: 2px; }
  .main-body { padding: 24px 32px; }

  /* Empty state */
  .empty { color: var(--muted); text-align: center; padding: 80px 40px; }
  .empty h3 { font-size: 15px; color: var(--text2); margin-bottom: 8px; }

  /* Badges */
  .badge { display: inline-flex; align-items: center; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 500; }
  .badge-tool { background: var(--accent-bg); color: var(--accent2); }
  .badge-success { background: var(--green-bg); color: var(--green); }
  .badge-error { background: var(--red-bg); color: var(--red); }
  .badge-amber { background: var(--amber-bg); color: var(--amber); }
  .badge-outline { background: none; border: 1px solid var(--border); color: var(--muted); }

  /* Run cards */
  .run-list { display: flex; flex-direction: column; gap: 8px; }
  .run-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; transition: border-color 0.15s; }
  .run-card:hover { border-color: var(--dim); }
  .run-card-header { display: flex; align-items: center; gap: 12px; padding: 14px 16px; cursor: pointer; user-select: none; }
  .run-label { font-weight: 600; font-size: 14px; color: var(--accent2); min-width: 70px; }
  .run-prompt { flex: 1; color: var(--text2); font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .run-meta { display: flex; gap: 12px; align-items: center; font-size: 11px; color: var(--muted); flex-shrink: 0; }
  .run-meta .sep { color: var(--border); }
  .run-chevron { color: var(--dim); transition: transform 0.2s; font-size: 12px; }
  .run-card.open .run-chevron { transform: rotate(90deg); }
  .run-body { display: none; border-top: 1px solid var(--border); }
  .run-card.open .run-body { display: block; }

  /* Run body sections */
  .run-section { padding: 16px; border-bottom: 1px solid var(--border); }
  .run-section:last-child { border-bottom: none; }
  .run-section-title { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; color: var(--dim); margin-bottom: 10px; }
  .run-io { font-size: 12px; color: var(--text2); line-height: 1.7; }
  .run-io .label { color: var(--muted); font-size: 11px; font-weight: 500; }
  .run-output { margin-top: 10px; padding: 12px; background: var(--bg); border-radius: 6px; white-space: pre-wrap; word-break: break-word; max-height: 300px; overflow-y: auto; font-size: 12px; }

  /* Timeline steps */
  .timeline { position: relative; padding-left: 20px; }
  .timeline::before { content: ''; position: absolute; left: 5px; top: 8px; bottom: 8px; width: 1px; background: var(--border); }
  .tl-step { position: relative; padding: 6px 0 6px 16px; }
  .tl-step::before { content: ''; position: absolute; left: -1px; top: 14px; width: 9px; height: 9px; border-radius: 50%; border: 2px solid var(--border); background: var(--bg); z-index: 1; }
  .tl-step.tl-tool::before { border-color: var(--accent); background: var(--accent-bg); }
  .tl-step.tl-tool-error::before { border-color: var(--red); background: var(--red-bg); }
  .tl-step.tl-reasoning::before { border-color: var(--green); background: var(--green-bg); }

  .tl-head { display: flex; align-items: center; gap: 8px; }
  .tl-name { font-weight: 600; font-size: 12px; }
  .tl-tool .tl-name { color: var(--accent2); }
  .tl-tool-error .tl-name { color: var(--red); }
  .tl-reasoning .tl-name { color: var(--green); }
  .tl-dur { font-size: 10px; color: var(--muted); font-family: 'SF Mono', monospace; }
  .tl-detail { margin-top: 4px; font-size: 12px; color: var(--muted); }
  .tl-args { padding: 6px 10px; margin-top: 4px; background: var(--bg); border-radius: 4px; font-size: 11px; white-space: pre-wrap; word-break: break-word; max-height: 120px; overflow-y: auto; }
  .tl-args.mono { font-family: 'SF Mono', 'Cascadia Code', monospace; }
  .tl-result { padding: 6px 10px; margin-top: 4px; background: var(--cyan-bg); border-radius: 4px; border-left: 2px solid var(--cyan); font-size: 11px; white-space: pre-wrap; word-break: break-word; max-height: 150px; overflow-y: auto; }
  .tl-reasoning-text { padding: 8px 12px; margin-top: 4px; background: var(--green-bg); border-radius: 4px; border-left: 2px solid var(--green); font-size: 12px; line-height: 1.6; white-space: pre-wrap; word-break: break-word; max-height: 200px; overflow-y: auto; color: var(--text2); }
  .tl-toggle { font-size: 11px; color: var(--accent2); cursor: pointer; margin-left: 8px; }
  .tl-toggle:hover { text-decoration: underline; }

  /* Diff */
  .diff-bar { display: flex; gap: 8px; align-items: center; margin-bottom: 16px; flex-wrap: wrap; }
  .diff-bar select { background: var(--surface); color: var(--text); border: 1px solid var(--border); padding: 6px 10px; border-radius: 6px; font-family: inherit; font-size: 12px; }
  .diff-bar select:focus { border-color: var(--accent); outline: none; }
  .diff-btn { background: var(--accent); color: #fff; border: none; padding: 6px 14px; border-radius: 6px; cursor: pointer; font-family: inherit; font-size: 12px; font-weight: 500; }
  .diff-btn:hover { opacity: 0.9; }
  .diff-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .diff-col { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px; overflow-x: auto; }
  .diff-col-title { font-size: 12px; font-weight: 600; margin-bottom: 12px; display: flex; justify-content: space-between; }
  .diff-col-title .diff-stats { font-weight: 400; color: var(--muted); }
  .diff-row { padding: 6px 10px; margin: 3px 0; border-radius: 4px; font-size: 12px; display: flex; justify-content: space-between; }
  .diff-row-tool { background: var(--accent-bg); }
  .diff-match { background: var(--surface2); }
  .diff-add { background: var(--green-bg); }
  .diff-rm { background: var(--red-bg); }
  .diff-summary { margin-top: 16px; padding: 14px 16px; background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); display: grid; grid-template-columns: repeat(auto-fit, minmax(140px,1fr)); gap: 12px; font-size: 12px; }
  .diff-summary .ds-label { color: var(--muted); font-size: 10px; text-transform: uppercase; }
  .diff-summary .ds-val { font-weight: 600; margin-top: 2px; }
  .diff-delta-pos { color: var(--red); }
  .diff-delta-neg { color: var(--green); }

  /* Divergence */
  .div-card { background: var(--surface); border: 1px solid var(--amber); border-radius: var(--radius); padding: 16px; margin-bottom: 8px; }
  .div-card .name { font-weight: 600; font-size: 14px; }
  .div-card .patterns { margin-top: 8px; display: flex; gap: 6px; flex-wrap: wrap; }

  /* Buttons */
  .btn-ghost { background: none; border: 1px solid var(--border); color: var(--text2); padding: 5px 12px; border-radius: 6px; cursor: pointer; font-family: inherit; font-size: 12px; }
  .btn-ghost:hover { border-color: var(--accent); color: var(--text); }
</style>
</head>
<body>
<div class="shell">
  <aside class="sidebar">
    <div class="sidebar-header">
      <h1><span>mimir</span></h1>
      <p>agent observability</p>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section">Views</div>
      <div class="nav-item active" data-view="agents" onclick="switchView('agents')">Agents</div>
      <div class="nav-item" data-view="divergence" onclick="switchView('divergence')">Divergence</div>
      <div class="nav-section" id="agents-nav-label" style="margin-top:12px">Agents</div>
      <div id="agents-nav"></div>
    </nav>
    <div class="sidebar-stats" id="sidebar-stats"></div>
  </aside>
  <div class="main">
    <div class="main-header">
      <div>
        <h2 id="main-title">Agents</h2>
        <div class="subtitle" id="main-subtitle">Select an agent to view runs</div>
      </div>
      <button class="btn-ghost" onclick="loadAll()">Refresh</button>
    </div>
    <div class="main-body" id="main-body">
      <div class="empty"><h3>No agents tracked yet</h3>Instrument your agent with Mimir and run it.</div>
    </div>
  </div>
</div>

<script>
const API = '';
let _groups = [];
let _currentGroup = null;
let _currentRuns = [];
let _openRuns = new Set();       // indices of expanded run cards
let _openDetails = new Set();    // "runIdx-stepIdx" keys for expanded tool details
let _lastRunCount = 0;           // detect new runs arriving

function switchView(name) {
  document.querySelectorAll('.nav-item[data-view]').forEach(n => n.classList.toggle('active', n.dataset.view === name));
  if (name === 'divergence') {
    document.getElementById('main-title').textContent = 'Divergence';
    document.getElementById('main-subtitle').textContent = 'Agents with inconsistent tool patterns across runs';
    loadDivergence();
  } else {
    _currentGroup = null;
    document.getElementById('main-title').textContent = 'Agents';
    document.getElementById('main-subtitle').textContent = _groups.length + ' tracked agents';
    renderAgentsNav();
    renderAgentsHome();
  }
}

async function loadAll() {
  try {
    const [overview, groups] = await Promise.all([
      fetch(API + '/api/overview').then(r => r.json()),
      fetch(API + '/api/task-groups').then(r => r.json()),
    ]);
    _groups = groups;
    renderSidebarStats(overview);
    renderAgentsNav();
    // Only render the agents home if no agent is selected yet
    if (!_currentGroup) renderAgentsHome();
  } catch(e) { console.error(e); }
}

function renderSidebarStats(o) {
  document.getElementById('sidebar-stats').innerHTML = `
    <div class="sidebar-stat"><div class="val">${o.total_runs}</div><div class="lbl">Runs</div></div>
    <div class="sidebar-stat"><div class="val">${o.task_groups}</div><div class="lbl">Agents</div></div>
    <div class="sidebar-stat"><div class="val">${o.trajectories}</div><div class="lbl">Traces</div></div>
    <div class="sidebar-stat"><div class="val">${o.active_runs}</div><div class="lbl">Active</div></div>`;
}

function renderAgentsHome() {
  const body = document.getElementById('main-body');
  if (!_groups.length) {
    body.innerHTML = '<div class="empty"><h3>No agents tracked yet</h3>Instrument your agent with Mimir and run it.</div>';
    return;
  }
  body.innerHTML = _groups.map(g => `
    <div class="run-card" style="cursor:pointer;margin-bottom:8px" onclick="loadTaskGroup('${g.task_type_id}')">
      <div class="run-card-header">
        <span class="run-label" style="min-width:auto">${esc(g.name)}</span>
        <div class="run-meta">
          <span>${g.run_count} run${g.run_count!==1?'s':''}</span>
          <span class="sep">|</span>
          <span>${esc(g.model||'unknown')}</span>
          <span class="sep">|</span>
          ${(g.tools||[]).map(t => `<span class="badge badge-tool">${esc(t)}</span>`).join(' ')}
        </div>
        <span class="run-chevron">&#9654;</span>
      </div>
    </div>
  `).join('');
}

function renderAgentsNav() {
  const el = document.getElementById('agents-nav');
  if (!_groups.length) { el.innerHTML = ''; return; }
  el.innerHTML = _groups.map(g => `
    <div class="nav-item ${_currentGroup && _currentGroup.task_type_id === g.task_type_id ? 'active' : ''}" onclick="loadTaskGroup('${g.task_type_id}')">
      <div class="dot" style="background:${g.run_count ? 'var(--accent)' : 'var(--dim)'}"></div>
      ${esc(g.name)}
      <span class="count">${g.run_count}</span>
    </div>
  `).join('');
}

async function loadTaskGroup(tid) {
  const data = await fetch(API + '/api/task-group/' + tid).then(r => r.json());
  _currentGroup = data;
  _currentRuns = (data.runs || []);
  _currentRuns.sort((a, b) => (a.started_at || 0) - (b.started_at || 0));
  // Reset UI state when switching agents
  _openRuns.clear();
  _openDetails.clear();
  _lastRunCount = _currentRuns.length;
  renderAgentsNav();
  renderRunPanel();
}

function renderRunPanel() {
  const g = _currentGroup;
  const runs = _currentRuns;
  document.getElementById('main-title').textContent = g.name;
  const toolsHtml = (g.tools||[]).map(t => `<span class="badge badge-tool">${esc(t)}</span>`).join(' ');
  document.getElementById('main-subtitle').innerHTML = `${runs.length} runs &middot; ${esc(g.model||'unknown')} &middot; ${toolsHtml}`;

  let html = '';

  // Diff bar
  if (runs.length >= 2) {
    html += `<div class="diff-bar">
      <span style="color:var(--muted);font-size:12px">Compare</span>
      <select id="diff-a">${runs.map((r,i) => `<option value="${i}">Run #${i+1}</option>`).join('')}</select>
      <span style="color:var(--dim)">vs</span>
      <select id="diff-b">${runs.map((r,i) => `<option value="${i}" ${i===Math.min(1,runs.length-1)?'selected':''}>Run #${i+1}</option>`).join('')}</select>
      <button class="diff-btn" onclick="diffRuns()">Compare runs</button>
    </div>
    <div id="diff-result"></div>`;
  }

  // Run list
  html += '<div class="run-list">';
  runs.forEach((r, idx) => {
    const num = idx + 1;
    const prompt = (r.input && r.input.prompt) ? r.input.prompt : '';
    const toolSteps = (r.steps||[]).filter(s => s.type === 'tool' || s.type === 'tool_error');
    const reasonSteps = (r.steps||[]).filter(s => s.type === 'reasoning');
    const inTok = (r.usage||{}).input_tokens || 0;
    const outTok = (r.usage||{}).output_tokens || 0;

    html += `<div class="run-card ${_openRuns.has(idx)?'open':''}" id="run-card-${idx}">
      <div class="run-card-header" onclick="toggleRun(${idx})">
        <span class="run-label">Run #${num}</span>
        <span class="run-prompt">${esc(prompt)}</span>
        <div class="run-meta">
          <span class="badge badge-${r.status === 'success' ? 'success' : 'error'}">${r.status}</span>
          <span class="sep">|</span>
          <span>${toolSteps.length} tools</span>
          <span class="sep">|</span>
          <span>${reasonSteps.length} reasoning</span>
          <span class="sep">|</span>
          <span class="mono">${fmtTokens(inTok)} in / ${fmtTokens(outTok)} out</span>
          <span class="sep">|</span>
          <span>${r.duration_s ? r.duration_s.toFixed(1) + 's' : '?'}${r.cost_usd ? ' / $' + r.cost_usd.toFixed(4) : ''}</span>
        </div>
        <span class="run-chevron">&#9654;</span>
      </div>
      <div class="run-body">
        <div class="run-section">
          <div class="run-section-title">Input</div>
          <div class="run-io">${esc(prompt) || '<span style="color:var(--dim)">No input recorded</span>'}</div>
        </div>
        <div class="run-section">
          <div class="run-section-title">Timeline &mdash; ${(r.steps||[]).length} steps</div>
          <div class="timeline">${renderTimeline(idx, r.steps || [])}</div>
        </div>
        ${r.output ? `<div class="run-section">
          <div class="run-section-title">Output</div>
          <div class="run-output">${esc(typeof r.output === 'string' ? r.output : JSON.stringify(r.output, null, 2))}</div>
        </div>` : ''}
      </div>
    </div>`;
  });
  html += '</div>';

  document.getElementById('main-body').innerHTML = html;
}

function renderTimeline(runIdx, steps) {
  return steps.map((s, i) => {
    const key = runIdx + '-' + i;
    const isOpen = _openDetails.has(key);
    if (s.type === 'tool') {
      const argsStr = typeof s.args === 'string' ? s.args : JSON.stringify(s.args || '', null, 2);
      const resultStr = typeof s.result === 'string' ? s.result : JSON.stringify(s.result || '', null, 2);
      return `<div class="tl-step tl-tool">
        <div class="tl-head">
          <span class="tl-name">${esc(s.tool)}</span>
          <span class="tl-dur">${s.duration_ms ? s.duration_ms.toFixed(0) + 'ms' : ''}</span>
          <span class="tl-toggle" onclick="toggleDetail(${runIdx},${i})">${isOpen?'hide':'details'}</span>
        </div>
        <div class="tl-detail" id="tl-detail-${key}" style="display:${isOpen?'block':'none'}">
          <div style="color:var(--dim);font-size:10px;margin-bottom:2px">ARGS</div>
          <div class="tl-args mono">${esc(argsStr)}</div>
          <div style="color:var(--dim);font-size:10px;margin-top:6px;margin-bottom:2px">RESULT</div>
          <div class="tl-result">${esc(resultStr)}</div>
        </div>
      </div>`;
    }
    if (s.type === 'tool_error') {
      return `<div class="tl-step tl-tool-error">
        <div class="tl-head">
          <span class="tl-name">${esc(s.tool)} &mdash; ERROR</span>
          <span class="tl-dur">${s.duration_ms ? s.duration_ms.toFixed(0) + 'ms' : ''}</span>
        </div>
        <div class="tl-detail"><div class="tl-args" style="border-left:2px solid var(--red)">${esc(s.error || '')}</div></div>
      </div>`;
    }
    if (s.type === 'reasoning') {
      const text = s.text || '';
      const isShort = text.length < 80;
      const isAgentEvent = text.startsWith('[agent ') || text.startsWith('[handoff') || text.startsWith('[subagent');
      if (isAgentEvent) {
        return `<div class="tl-step tl-reasoning">
          <div class="tl-head"><span class="tl-name">${esc(text)}</span></div>
        </div>`;
      }
      return `<div class="tl-step tl-reasoning">
        <div class="tl-head">
          <span class="tl-name">reasoning${s.tokens ? ' (' + s.tokens + ' tokens)' : ''}</span>
          ${!isShort ? `<span class="tl-toggle" onclick="toggleDetail(${runIdx},${i})">${isOpen?'collapse':'expand'}</span>` : ''}
        </div>
        ${isShort
          ? `<div class="tl-reasoning-text">${esc(text)}</div>`
          : `<div class="tl-reasoning-text" id="tl-detail-${key}" style="max-height:${isOpen?'2000px':'60px'};overflow:hidden;cursor:pointer" onclick="toggleDetail(${runIdx},${i})">${esc(text)}</div>`
        }
      </div>`;
    }
    return '';
  }).join('');
}

function toggleDetail(runIdx, stepIdx) {
  const key = runIdx + '-' + stepIdx;
  const el = document.getElementById('tl-detail-' + key);
  if (!el) return;
  if (_openDetails.has(key)) { _openDetails.delete(key); el.style.display = 'none'; }
  else { _openDetails.add(key); el.style.display = 'block'; }
}

function toggleRun(idx) {
  const card = document.getElementById('run-card-' + idx);
  if (!card) return;
  if (_openRuns.has(idx)) { _openRuns.delete(idx); card.classList.remove('open'); }
  else { _openRuns.add(idx); card.classList.add('open'); }
}

function diffRuns() {
  const aIdx = parseInt(document.getElementById('diff-a').value);
  const bIdx = parseInt(document.getElementById('diff-b').value);
  const a = _currentRuns[aIdx], b = _currentRuns[bIdx];
  if (!a || !b) return;

  const stepsA = (a.steps||[]).filter(s => s.type==='tool'||s.type==='tool_error');
  const stepsB = (b.steps||[]).filter(s => s.type==='tool'||s.type==='tool_error');

  // LCS-based diff for better alignment
  const lcs = lcsTools(stepsA, stepsB);
  const {rowsA, rowsB} = buildDiffRows(stepsA, stepsB, lcs);

  const aIn = (a.usage||{}).input_tokens||0, aOut = (a.usage||{}).output_tokens||0;
  const bIn = (b.usage||{}).input_tokens||0, bOut = (b.usage||{}).output_tokens||0;
  const dDur = (b.duration_s||0) - (a.duration_s||0);
  const dTok = (bIn + bOut) - (aIn + aOut);

  document.getElementById('diff-result').innerHTML = `
    <div class="diff-grid">
      <div class="diff-col">
        <div class="diff-col-title">Run #${aIdx+1} <span class="diff-stats">${stepsA.length} tool calls &middot; ${(a.duration_s||0).toFixed(1)}s</span></div>
        ${rowsA}
      </div>
      <div class="diff-col">
        <div class="diff-col-title">Run #${bIdx+1} <span class="diff-stats">${stepsB.length} tool calls &middot; ${(b.duration_s||0).toFixed(1)}s</span></div>
        ${rowsB}
      </div>
    </div>
    <div class="diff-summary">
      <div><div class="ds-label">Duration delta</div><div class="ds-val ${dDur>0?'diff-delta-pos':'diff-delta-neg'}">${dDur>0?'+':''}${dDur.toFixed(1)}s</div></div>
      <div><div class="ds-label">Token delta</div><div class="ds-val ${dTok>0?'diff-delta-pos':'diff-delta-neg'}">${dTok>0?'+':''}${fmtTokens(dTok)}</div></div>
      <div><div class="ds-label">Run #${aIdx+1} tokens</div><div class="ds-val">${fmtTokens(aIn)} in / ${fmtTokens(aOut)} out</div></div>
      <div><div class="ds-label">Run #${bIdx+1} tokens</div><div class="ds-val">${fmtTokens(bIn)} in / ${fmtTokens(bOut)} out</div></div>
    </div>`;
}

function lcsTools(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({length: m+1}, () => Array(n+1).fill(0));
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = a[i-1].tool === b[j-1].tool ? dp[i-1][j-1]+1 : Math.max(dp[i-1][j], dp[i][j-1]);
  const result = [];
  let i = m, j = n;
  while (i > 0 && j > 0) {
    if (a[i-1].tool === b[j-1].tool) { result.unshift([i-1, j-1]); i--; j--; }
    else if (dp[i-1][j] > dp[i][j-1]) i--;
    else j--;
  }
  return result;
}

function buildDiffRows(stepsA, stepsB, lcs) {
  let rowsA = '', rowsB = '';
  let ai = 0, bi = 0;
  for (const [la, lb] of lcs) {
    while (ai < la) { rowsA += diffRow(stepsA[ai], 'diff-rm'); rowsB += diffRow(null, 'diff-rm'); ai++; }
    while (bi < lb) { rowsA += diffRow(null, 'diff-add'); rowsB += diffRow(stepsB[bi], 'diff-add'); bi++; }
    rowsA += diffRow(stepsA[ai], 'diff-match');
    rowsB += diffRow(stepsB[bi], 'diff-match');
    ai++; bi++;
  }
  while (ai < stepsA.length) { rowsA += diffRow(stepsA[ai], 'diff-rm'); rowsB += diffRow(null, 'diff-rm'); ai++; }
  while (bi < stepsB.length) { rowsA += diffRow(null, 'diff-add'); rowsB += diffRow(stepsB[bi], 'diff-add'); bi++; }
  return {rowsA, rowsB};
}

function diffRow(step, cls) {
  if (!step) return `<div class="diff-row ${cls}" style="opacity:0.3">&mdash;</div>`;
  return `<div class="diff-row ${cls}"><span>${esc(step.tool)}</span><span class="mono" style="color:var(--muted)">${(step.duration_ms||0).toFixed(0)}ms</span></div>`;
}

async function loadDivergence() {
  const data = await fetch(API + '/api/divergence').then(r => r.json());
  const body = document.getElementById('main-body');
  if (!data.length) { body.innerHTML = '<div class="empty"><h3>No divergence detected</h3>All agents follow consistent tool patterns across runs.</div>'; return; }
  body.innerHTML = data.map(d => {
    const fps = Object.entries(d.fingerprints);
    return `<div class="div-card">
      <div class="name">${esc(d.task_name)}</div>
      <div style="color:var(--muted);font-size:12px;margin-top:4px">${fps.length} distinct tool patterns detected</div>
      <div class="patterns">${fps.map(([fp, info]) =>
        `<span class="badge badge-amber">${fp.substring(0,8)} &middot; ${info.run_count} run${info.run_count>1?'s':''}</span>`
      ).join('')}</div>
    </div>`;
  }).join('');
}

function fmtTokens(n) {
  if (Math.abs(n) >= 1000) return (n/1000).toFixed(1) + 'k';
  return String(n);
}

function esc(s) { const d = document.createElement('div'); d.textContent = String(s||''); return d.innerHTML; }

loadAll();
</script>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------


def run_dashboard(host: str = "0.0.0.0", port: int = 9847) -> None:
    """Start the Mimir dashboard HTTP server (blocking)."""
    _ensure_dirs()
    server = HTTPServer((host, port), DashboardHandler)
    print(f"  mimir dashboard running at http://localhost:{port}")
    print(f"  data stored in {MIMIR_DIR}")
    print(f"  press ctrl+c to stop")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  mimir dashboard stopped.")
        server.server_close()
