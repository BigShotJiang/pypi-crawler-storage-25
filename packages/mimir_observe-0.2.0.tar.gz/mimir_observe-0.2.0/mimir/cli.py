"""
Mimir CLI — entry point for `mimir dashboard`.
"""

from __future__ import annotations

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="mimir",
        description="Mimir — auto-instrumentation and visibility for AI agents",
    )
    sub = parser.add_subparsers(dest="command")

    dash = sub.add_parser("dashboard", help="Start the local Mimir dashboard")
    dash.add_argument("--host", default="0.0.0.0", help="Bind address (default: 0.0.0.0)")
    dash.add_argument("--port", type=int, default=9847, help="Port (default: 9847)")

    version = sub.add_parser("version", help="Print version")

    args = parser.parse_args()

    if args.command == "dashboard":
        from .dashboard import run_dashboard
        run_dashboard(host=args.host, port=args.port)
    elif args.command == "version":
        from . import __version__
        print(f"mimir {__version__}")
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
