"""
Mimir auto-instrumentation for the raw OpenAI Python client.

Patches chat.completions.create (sync and async) on the class level
so every OpenAI client instance is automatically instrumented.

    import mimir
    mimir.instrument_openai()
"""

from __future__ import annotations

import time
from typing import Any

from .sdk import Task, Run, _safe_serialize

# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

_instrumented = False
_original_create = None
_original_async_create = None
_task_cache: dict[str, Task] = {}  # model -> Task


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_task(model: str, tools: list[str] | None = None) -> Task:
    if model not in _task_cache:
        _task_cache[model] = Task(
            name=model,
            config=model,
            tools=tools or [],
            model=model,
        )
    return _task_cache[model]


def _extract_prompt(messages) -> str:
    """Walk backward through messages to find the last user message."""
    if not messages:
        return ""
    for msg in reversed(messages):
        if isinstance(msg, dict):
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role == "user" and isinstance(content, str) and content:
                return content[:500]
    return ""


def _extract_tool_names(tools) -> list[str]:
    """Extract tool/function names from the tools parameter."""
    if not tools:
        return []
    names = []
    for t in tools:
        if isinstance(t, dict):
            fn = t.get("function", {})
            name = fn.get("name", "") if isinstance(fn, dict) else ""
            if name:
                names.append(name)
    return names


def _process_response(run: Run, response, duration_ms: float) -> None:
    """Extract tool calls, usage, and content from an OpenAI response."""
    # Usage
    usage = getattr(response, "usage", None)
    if usage:
        inp = getattr(usage, "prompt_tokens", 0) or 0
        out = getattr(usage, "completion_tokens", 0) or 0
        run.set_usage(inp, out)

    # Process choices
    choices = getattr(response, "choices", []) or []
    for choice in choices:
        msg = getattr(choice, "message", None)
        if not msg:
            continue

        # Tool calls
        tool_calls = getattr(msg, "tool_calls", None) or []
        for tc in tool_calls:
            fn = getattr(tc, "function", None)
            if fn:
                name = getattr(fn, "name", "unknown")
                args = getattr(fn, "arguments", "")
                run.tool(name, args, None, 0)

        # Content (assistant reasoning / response)
        content = getattr(msg, "content", None)
        if content and isinstance(content, str) and content.strip():
            run.reasoning(content[:2000])

        # Refusal
        refusal = getattr(msg, "refusal", None)
        if refusal:
            run.reasoning(f"[refusal] {refusal[:500]}")


# ---------------------------------------------------------------------------
# Patching
# ---------------------------------------------------------------------------


def instrument_openai() -> None:
    """Patch OpenAI chat.completions.create to auto-capture every call."""
    global _instrumented, _original_create, _original_async_create

    if _instrumented:
        return

    try:
        from openai.resources.chat.completions.completions import Completions, AsyncCompletions
    except ImportError:
        raise ImportError(
            "Could not import 'openai'. Install it: pip install openai"
        )

    _original_create = Completions.create
    _original_async_create = AsyncCompletions.create

    def _patched_create(self, *, messages, model, **kwargs):
        tools = kwargs.get("tools")
        tool_names = _extract_tool_names(tools)
        task = _get_task(model, tool_names)
        prompt = _extract_prompt(messages)

        start = time.time()
        with task.run(input={"prompt": prompt}) as run:
            try:
                result = _original_create(self, messages=messages, model=model, **kwargs)
            except Exception as e:
                run.tool_error("chat.completions.create", {"model": model}, str(e), (time.time() - start) * 1000)
                raise
            duration_ms = (time.time() - start) * 1000
            _process_response(run, result, duration_ms)
            run.set_output(_safe_serialize(getattr(result, "choices", [])))
            return result

    async def _patched_async_create(self, *, messages, model, **kwargs):
        tools = kwargs.get("tools")
        tool_names = _extract_tool_names(tools)
        task = _get_task(model, tool_names)
        prompt = _extract_prompt(messages)

        start = time.time()
        with task.run(input={"prompt": prompt}) as run:
            try:
                result = await _original_async_create(self, messages=messages, model=model, **kwargs)
            except Exception as e:
                run.tool_error("chat.completions.create", {"model": model}, str(e), (time.time() - start) * 1000)
                raise
            duration_ms = (time.time() - start) * 1000
            _process_response(run, result, duration_ms)
            run.set_output(_safe_serialize(getattr(result, "choices", [])))
            return result

    Completions.create = _patched_create
    AsyncCompletions.create = _patched_async_create
    _instrumented = True


def uninstrument_openai() -> None:
    """Restore original OpenAI client methods."""
    global _instrumented, _original_create, _original_async_create

    if not _instrumented:
        return

    try:
        from openai.resources.chat.completions.completions import Completions, AsyncCompletions
    except ImportError:
        return

    if _original_create is not None:
        Completions.create = _original_create
    if _original_async_create is not None:
        AsyncCompletions.create = _original_async_create

    _instrumented = False
    _original_create = None
    _original_async_create = None
    _task_cache.clear()
