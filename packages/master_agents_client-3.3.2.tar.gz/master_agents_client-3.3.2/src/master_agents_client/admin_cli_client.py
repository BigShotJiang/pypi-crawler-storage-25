"""``mao-client admin <…>`` subcommand handlers.

Thin HTTP wrapper around the server's ``/admin/clients/*``,
``/admin/roles``, and ``/admin/audit`` endpoints (added in
master-agents v1.6.0). Lets operators run RBAC + tier-key
management remotely from a workstation without ``docker exec`` or
ad-hoc SQL.

All commands require an admin-role tier-key in
``~/.master_agents/remote.yaml`` (configured via ``mao-client
remote login --token <admin-token>``). Non-admin tokens get HTTP
403 from every command here.

Subcommand tree::

    mao-client admin clients list
    mao-client admin clients show <client_id>
    mao-client admin clients create --email <e> --plan <p> --role <r>
    mao-client admin clients role <client_id> <new_role>
    mao-client admin clients suspend <client_id>
    mao-client admin clients reactivate <client_id>
    mao-client admin keys list <client_id>
    mao-client admin keys issue --client <client_id> [--name <name>]
    mao-client admin keys revoke <client_id> <key_id>
    mao-client admin roles list
    mao-client admin audit recent [--client <id>] [--limit N]
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Any

import httpx

from .remote_cli import _config_path, load_remote_config


def _http(cfg) -> httpx.Client:
    """Build a synchronous httpx client with the saved bearer."""
    return httpx.Client(
        base_url=cfg.server.rstrip("/"),
        headers={"Authorization": f"Bearer {cfg.token}"},
        timeout=30.0,
    )


def _format_error(resp: httpx.Response) -> str:
    try:
        detail = resp.json().get("detail", "")
    except Exception:  # noqa: BLE001 — minimal CLI; surface raw on parse fail
        detail = resp.text
    return f"HTTP {resp.status_code}: {detail}"


def _print_json(obj: Any) -> None:
    print(json.dumps(obj, indent=2, sort_keys=True))


def _print_clients_table(clients: list[dict]) -> None:
    if not clients:
        print("(no clients)")
        return
    cols = ("email", "plan", "role", "status", "is_admin", "id")
    widths = {c: max(len(c), max(len(str(r.get(c, ""))) for r in clients))
              for c in cols}
    header = "  ".join(c.ljust(widths[c]) for c in cols)
    print(header)
    print("  ".join("-" * widths[c] for c in cols))
    for r in clients:
        print("  ".join(str(r.get(c, "")).ljust(widths[c]) for c in cols))


def _print_keys_table(keys: list[dict]) -> None:
    if not keys:
        print("(no keys)")
        return
    cols = ("prefix", "name", "active", "last_used_at", "id")
    widths = {c: max(len(c), max(len(str(r.get(c) or "")) for r in keys))
              for c in cols}
    header = "  ".join(c.ljust(widths[c]) for c in cols)
    print(header)
    print("  ".join("-" * widths[c] for c in cols))
    for r in keys:
        print("  ".join(str(r.get(c) or "").ljust(widths[c]) for c in cols))


# ── clients ──────────────────────────────────────────────────────────


def _cmd_clients_list(args: argparse.Namespace, cfg) -> int:
    with _http(cfg) as c:
        resp = c.get("/admin/clients")
    if resp.status_code != 200:
        print(_format_error(resp), file=sys.stderr)
        return 1
    data = resp.json()
    if args.json:
        _print_json(data)
    else:
        print(f"Total clients: {data['count']}")
        _print_clients_table(data["clients"])
    return 0


def _cmd_clients_show(args: argparse.Namespace, cfg) -> int:
    with _http(cfg) as c:
        resp = c.get(f"/admin/clients/{args.client_id}")
    if resp.status_code != 200:
        print(_format_error(resp), file=sys.stderr)
        return 1
    _print_json(resp.json())
    return 0


def _cmd_clients_create(args: argparse.Namespace, cfg) -> int:
    body = {
        "email": args.email,
        "plan": args.plan,
        "role": args.role,
        "is_admin": args.admin,
    }
    if args.display_name:
        body["display_name"] = args.display_name
    with _http(cfg) as c:
        resp = c.post("/admin/clients", json=body)
    if resp.status_code not in (200, 201):
        print(_format_error(resp), file=sys.stderr)
        return 1
    print(f"Created client {resp.json()['email']} (id={resp.json()['id']}).")
    print("Next: mint a key with:")
    print(f"  mao-client admin keys issue --client {resp.json()['id']}")
    return 0


def _cmd_clients_role(args: argparse.Namespace, cfg) -> int:
    with _http(cfg) as c:
        resp = c.patch(
            f"/admin/clients/{args.client_id}",
            json={"role": args.role},
        )
    if resp.status_code != 200:
        print(_format_error(resp), file=sys.stderr)
        return 1
    print(f"Role updated: {resp.json()['email']} → {resp.json()['role']}")
    return 0


def _cmd_clients_suspend(args: argparse.Namespace, cfg) -> int:
    return _patch_status(args.client_id, "suspended", cfg)


def _cmd_clients_reactivate(args: argparse.Namespace, cfg) -> int:
    return _patch_status(args.client_id, "active", cfg)


def _patch_status(client_id: str, status: str, cfg) -> int:
    with _http(cfg) as c:
        resp = c.patch(
            f"/admin/clients/{client_id}",
            json={"status": status},
        )
    if resp.status_code != 200:
        print(_format_error(resp), file=sys.stderr)
        return 1
    print(f"Status updated: {resp.json()['email']} → {resp.json()['status']}")
    return 0


# ── keys ─────────────────────────────────────────────────────────────


def _cmd_keys_list(args: argparse.Namespace, cfg) -> int:
    with _http(cfg) as c:
        resp = c.get(f"/admin/clients/{args.client_id}/keys")
    if resp.status_code != 200:
        print(_format_error(resp), file=sys.stderr)
        return 1
    data = resp.json()
    if args.json:
        _print_json(data)
    else:
        print(f"Keys for client {data['client_id']}: {data['count']}")
        _print_keys_table(data["keys"])
    return 0


def _cmd_keys_issue(args: argparse.Namespace, cfg) -> int:
    body: dict = {}
    if args.name:
        body["name"] = args.name
    with _http(cfg) as c:
        resp = c.post(
            f"/admin/clients/{args.client}/keys",
            json=body,
        )
    if resp.status_code not in (200, 201):
        print(_format_error(resp), file=sys.stderr)
        return 1
    data = resp.json()
    print("=" * 60)
    print(f"  client_id: {data['client_id']}")
    print(f"  key_id:    {data['key_id']}")
    print(f"  prefix:    {data['prefix']}")
    print(f"  name:      {data['name']}")
    print()
    print("  TOKEN (shown once — copy now):")
    print(f"  {data['token']}")
    print("=" * 60)
    return 0


def _cmd_keys_revoke(args: argparse.Namespace, cfg) -> int:
    with _http(cfg) as c:
        resp = c.delete(
            f"/admin/clients/{args.client_id}/keys/{args.key_id}",
        )
    if resp.status_code != 200:
        print(_format_error(resp), file=sys.stderr)
        return 1
    data = resp.json()
    if data.get("already_revoked"):
        print(f"Key {data['key_id']} already revoked.")
    else:
        print(f"Key {data['key_id']} revoked.")
    return 0


# ── roles ────────────────────────────────────────────────────────────


def _cmd_roles_list(args: argparse.Namespace, cfg) -> int:
    with _http(cfg) as c:
        resp = c.get("/admin/roles")
    if resp.status_code != 200:
        print(_format_error(resp), file=sys.stderr)
        return 1
    data = resp.json()
    if args.json:
        _print_json(data)
        return 0
    print(f"Roles ({data['count']}):")
    print()
    for r in data["roles"]:
        print(f"  {r['name']}")
        print(f"    description: {r['description']}")
        if r["agent_allowlist"] is not None:
            print(f"    agents:      {', '.join(r['agent_allowlist'])}")
        else:
            print(f"    agents:      (full registry — subject to "
                  f"tier:internal filtering)")
        print()
    return 0


# ── audit ────────────────────────────────────────────────────────────


def _cmd_audit_recent(args: argparse.Namespace, cfg) -> int:
    params: dict = {"limit": args.limit}
    if args.client:
        params["client_id"] = args.client
    with _http(cfg) as c:
        resp = c.get("/admin/audit", params=params)
    if resp.status_code != 200:
        print(_format_error(resp), file=sys.stderr)
        return 1
    data = resp.json()
    if args.json:
        _print_json(data)
        return 0
    print(f"Recent audit events: {data['count']}")
    print()
    for e in data["events"]:
        print(
            f"  [{e['ts']}] {e['method']} {e['endpoint']} "
            f"→ {e['status']} ({e['duration_ms']}ms) "
            f"client={e['client_id'] or '-'} ip={e['ip'] or '-'}"
        )
    return 0


# ── parser + dispatch ────────────────────────────────────────────────


def add_admin_subparser(sub) -> None:
    """Register the ``admin`` subcommand tree on the top-level parser.

    Called from ``cli.build_parser()``."""
    p_admin = sub.add_parser(
        "admin",
        help="Server-side RBAC + tier-key management (admin role only).",
        description=(
            "Manage clients, RBAC roles, and tier-keys remotely. All "
            "commands require an admin-role tier-key configured via "
            "`mao-client remote login`. See `mao-client admin -h` for "
            "subcommands."
        ),
    )
    admin_sub = p_admin.add_subparsers(dest="admin_command", required=True)

    # clients ------------------------------------------------------
    p_c = admin_sub.add_parser("clients", help="Manage client accounts.")
    csub = p_c.add_subparsers(dest="clients_command", required=True)

    pl = csub.add_parser("list", help="List all clients.")
    pl.add_argument("--json", action="store_true", help="Raw JSON output.")

    ps = csub.add_parser("show", help="Show one client's full record.")
    ps.add_argument("client_id")

    pn = csub.add_parser("create", help="Create a new client.")
    pn.add_argument("--email", required=True)
    pn.add_argument("--plan", default="free", choices=["free", "pro", "premium"])
    pn.add_argument("--role", default="platform-engineer")
    pn.add_argument("--display-name", default=None)
    pn.add_argument("--admin", action="store_true",
                    help="Mark this client as admin (full access).")

    pr = csub.add_parser("role", help="Change a client's RBAC role.")
    pr.add_argument("client_id")
    pr.add_argument("role")

    psp = csub.add_parser("suspend", help="Suspend a client (status=suspended).")
    psp.add_argument("client_id")

    pra = csub.add_parser("reactivate", help="Reactivate a suspended client.")
    pra.add_argument("client_id")

    # keys ---------------------------------------------------------
    p_k = admin_sub.add_parser("keys", help="Manage API keys.")
    ksub = p_k.add_subparsers(dest="keys_command", required=True)

    pkl = ksub.add_parser("list", help="List keys for a client.")
    pkl.add_argument("client_id")
    pkl.add_argument("--json", action="store_true")

    pki = ksub.add_parser("issue", help="Mint a fresh tier-key for a client.")
    pki.add_argument("--client", required=True, help="Client UUID.")
    pki.add_argument("--name", default=None,
                     help="Optional friendly name (e.g. 'alice-laptop').")

    pkr = ksub.add_parser("revoke", help="Revoke a specific key.")
    pkr.add_argument("client_id")
    pkr.add_argument("key_id")

    # roles --------------------------------------------------------
    p_r = admin_sub.add_parser("roles", help="Inspect the role catalog.")
    rsub = p_r.add_subparsers(dest="roles_command", required=True)
    prl = rsub.add_parser("list", help="List all roles + their allowlists.")
    prl.add_argument("--json", action="store_true")

    # audit --------------------------------------------------------
    p_a = admin_sub.add_parser("audit", help="Query the auth audit log.")
    asub = p_a.add_subparsers(dest="audit_command", required=True)
    par = asub.add_parser("recent", help="List most-recent audit events.")
    par.add_argument("--client", default=None, help="Filter by client UUID.")
    par.add_argument("--limit", type=int, default=100,
                     help="Max events (default 100, max 1000).")
    par.add_argument("--json", action="store_true")


_DISPATCH = {
    ("clients", "list"): _cmd_clients_list,
    ("clients", "show"): _cmd_clients_show,
    ("clients", "create"): _cmd_clients_create,
    ("clients", "role"): _cmd_clients_role,
    ("clients", "suspend"): _cmd_clients_suspend,
    ("clients", "reactivate"): _cmd_clients_reactivate,
    ("keys", "list"): _cmd_keys_list,
    ("keys", "issue"): _cmd_keys_issue,
    ("keys", "revoke"): _cmd_keys_revoke,
    ("roles", "list"): _cmd_roles_list,
    ("audit", "recent"): _cmd_audit_recent,
}


def cmd_admin(args: argparse.Namespace) -> int:
    """Top-level handler for ``mao-client admin <…>`` invocations."""
    # Admin subparsers don't redeclare ``--config`` (it's a remote-
    # only concept on the public CLI); fall back to default path.
    from pathlib import Path
    from .remote_cli import DEFAULT_REMOTE_CONFIG_PATH
    config_arg = getattr(args, "config", None)
    config_path = Path(config_arg) if config_arg else DEFAULT_REMOTE_CONFIG_PATH
    cfg = load_remote_config(config_path)
    sub_cmd = args.admin_command
    leaf_cmd = (
        getattr(args, "clients_command", None)
        or getattr(args, "keys_command", None)
        or getattr(args, "roles_command", None)
        or getattr(args, "audit_command", None)
    )
    handler = _DISPATCH.get((sub_cmd, leaf_cmd))
    if handler is None:
        print(
            f"Unknown admin command: {sub_cmd} {leaf_cmd}",
            file=sys.stderr,
        )
        return 2
    return handler(args, cfg)
