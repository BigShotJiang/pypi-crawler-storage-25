"""Built-in `file_grep` tool — recursive substring search in a text corpus.

Intended for local document-search use cases where an agent is pointed at
a directory of text/markdown files and needs to find matches for a query.

Performance path: when `ripgrep` (`rg`) is on PATH, the tool shells out
to it (~50–100x faster on large corpora than the pure-Python fallback).
On a 3000-file knowledge base this is the difference between ~100 ms
and ~100 seconds. The pure-Python implementation remains as a fallback
for hosts without ripgrep installed.
"""

import asyncio
import os
import re
import shutil
import time
from pathlib import Path
from typing import Iterator

from .base import Tool

MAX_FILE_SIZE_BYTES = 5_000_000  # skip files larger than this
MAX_TOTAL_OUTPUT_CHARS = 50_000

# F2 (2026-05-07) — guardrails. Real incident: a brainstormer issued
# `file_grep(path='/', query='master_agents_os', max_matches=10)` which
# scanned the WSL filesystem root for ~90 minutes (trace
# 30f2c613a29746bcbd9f78b5c4228ea4). F1's server-side timeout caught
# the symptom; these caps prevent the broken input from running in the
# first place. Same defensive pattern `read_file` already uses for
# oversized files — fail fast with a clear message.
#
# MAX_WALK_FILES bounds the pure-Python fallback walker only. The
# ripgrep fast path has its own 30s subprocess timeout (in
# `_try_ripgrep`'s `asyncio.wait_for(proc.communicate(), timeout=30.0)`),
# which already caps total work, so it doesn't need this counter.
MAX_WALK_FILES = 5000
MAX_WALK_SECONDS = 20.0
_SKIP_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "dist",
    "build",
}


def _is_pathological_scan_root(resolved: Path) -> tuple[bool, str]:
    """F2: classify a resolved scan root as pathological (too broad to
    grep usefully). Returns (flagged, reason). Currently flags
    filesystem root only — `Path('/').resolve()` yields `/` on Unix and
    the current drive root (e.g. `C:\\`) on Windows; in both cases
    `resolved == resolved.parent` (root has no parent). Top-level system
    dirs like `/etc`, `/home`, `C:\\Users` are NOT flagged here because
    we can't know without context whether they're legitimate; the
    walk-count cap (`MAX_WALK_FILES`) bounds the damage either way."""
    if resolved == resolved.parent:
        # Filesystem root — every walk from here is too broad.
        return True, (
            f"the filesystem root ({resolved}) — narrow the path to a "
            "specific project directory"
        )
    return False, ""


def _iter_candidate_files(base: Path) -> Iterator[Path]:
    """Walk `base` yielding candidate files, skipping junk dirs.
    Caller is responsible for enforcing `MAX_WALK_FILES` /
    `MAX_WALK_SECONDS` caps — keeping them out of this iterator
    preserves the simple `for fp in _iter_candidate_files(...)`
    contract for callers that don't need the cap (single-file mode)."""
    if base.is_file():
        yield base
        return
    for root, dirs, files in os.walk(base, followlinks=False):
        # Prune junk directories (in-place mutation affects os.walk)
        dirs[:] = [
            d for d in dirs if d not in _SKIP_DIRS and not d.startswith(".")
        ]
        for f in files:
            yield Path(root) / f


def _line_matches(
    line: str,
    raw_query: str,
    q_case_folded: str,
    pattern: "re.Pattern | None",
    case_sensitive: bool,
) -> bool:
    if pattern is not None:
        return pattern.search(line) is not None
    if case_sensitive:
        return raw_query in line
    return q_case_folded in line.lower()


def _looks_binary(path: Path) -> bool:
    try:
        with path.open("rb") as fh:
            head = fh.read(1024)
        return b"\x00" in head
    except OSError:
        return True


async def _try_ripgrep(
    query: str,
    base: Path,
    max_matches: int,
    regex: bool,
    case_sensitive: bool,
) -> str | None:
    """Fast path via ripgrep when on PATH. Returns formatted output, or
    None if rg is unavailable / failed (caller falls back to pure-Python).
    """
    rg = shutil.which("rg")
    if rg is None:
        return None

    argv = [
        rg,
        "--no-heading",
        "--line-number",
        "--no-messages",            # suppress "binary file matches" etc.
        "--max-count", str(max_matches),
        "--max-filesize", str(MAX_FILE_SIZE_BYTES),
        # Skip the same junk dirs the pure-Python walker prunes.
        "--glob", "!.git",
        "--glob", "!node_modules",
        "--glob", "!__pycache__",
        "--glob", "!.venv",
        "--glob", "!venv",
        "--glob", "!.mypy_cache",
        "--glob", "!.pytest_cache",
        "--glob", "!.ruff_cache",
        "--glob", "!dist",
        "--glob", "!build",
    ]
    if not case_sensitive:
        argv.append("--ignore-case")
    if not regex:
        argv.append("--fixed-strings")
    argv.extend(["--", query, str(base)])

    try:
        proc = await asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        # 30s ceiling — should never approach this with ripgrep.
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30.0)
    except (FileNotFoundError, asyncio.TimeoutError):
        return None
    except Exception:
        return None

    rc = proc.returncode if proc.returncode is not None else 1
    # rg exits 0 on matches, 1 on no-match, 2 on error.
    if rc not in (0, 1):
        return None
    text = stdout.decode("utf-8", errors="replace")
    if not text.strip():
        return f"No matches for {query!r} in {base}"

    # Rewrite absolute paths in rg output to be relative to `base` for
    # consistency with the pure-Python output format.
    lines: list[str] = []
    base_str = str(base)
    for raw_line in text.splitlines():
        if len(lines) >= max_matches:
            break
        if raw_line.startswith(base_str):
            tail = raw_line[len(base_str):].lstrip(os.sep).lstrip("/")
            lines.append(tail)
        else:
            lines.append(raw_line)

    header = f"Found {len(lines)} match(es) for {query!r} in {base} (via ripgrep):"
    out = header + "\n" + "\n".join(lines)
    if len(out) > MAX_TOTAL_OUTPUT_CHARS:
        out = out[:MAX_TOTAL_OUTPUT_CHARS] + "\n...[truncated]"
    return out


async def _file_grep_handler(
    query: str,
    path: str,
    max_matches: int = 30,
    regex: bool = False,
    pattern: bool | None = None,
    case_sensitive: bool = False,
) -> str:
    """: accept `pattern` as an alias for `regex`. LLM training
    priors universally call this kwarg `pattern` (every grep CLI,
    Python's `re.compile`, every code editor's "use regex" toggle
    is colloquially "pattern matching"). The original schema picked
    `regex` for explicitness, which made every LLM's first call
    fail with TypeError. Accept both, prefer `pattern` when both
    are supplied (matches LLM intent), document `regex` as
    deprecated."""
    if pattern is not None:
        regex = bool(pattern)
    from ._session_cwd import resolve_under_session_cwd
    base = resolve_under_session_cwd(path)
    if not base.exists():
        return f"Path does not exist: {path}"

    # F2: refuse pathological scan roots upfront. file_grep on the
    # filesystem root is never useful and historically caused 90-min
    # hangs. Fail fast with an actionable message instead of letting
    # the walk run.
    flagged, reason = _is_pathological_scan_root(base)
    if flagged:
        return (
            f"file_grep: refusing to scan {reason}. "
            f"Pass a more specific path (e.g. a project directory)."
        )

    # Fast path — ripgrep, when available.
    rg_result = await _try_ripgrep(query, base, max_matches, regex, case_sensitive)
    if rg_result is not None:
        return rg_result

    # Fallback — pure-Python walker.
    pattern: re.Pattern | None = None
    if regex:
        flags = 0 if case_sensitive else re.IGNORECASE
        try:
            pattern = re.compile(query, flags)
        except re.error as exc:
            return f"file_grep: invalid regex {query!r}: {exc}"
    q_lower = query.lower() if not case_sensitive else query
    matches: list[str] = []

    # F2: walk-count + wall-clock caps. Bounded so a non-matching query
    # against a large tree doesn't run forever. When the cap fires, we
    # return whatever we have plus a [scan truncated] marker so the
    # agent knows it should narrow the path.
    walked = 0
    walk_started = time.monotonic()
    walk_truncated = False
    truncate_reason = ""

    for fp in _iter_candidate_files(base):
        if len(matches) >= max_matches:
            break
        if walked >= MAX_WALK_FILES:
            walk_truncated = True
            truncate_reason = f"scan limit ({MAX_WALK_FILES} files walked)"
            break
        if (time.monotonic() - walk_started) >= MAX_WALK_SECONDS:
            walk_truncated = True
            truncate_reason = f"scan limit ({MAX_WALK_SECONDS:.0f}s wall-clock)"
            break
        walked += 1
        try:
            if fp.is_symlink():
                continue
            if fp.stat().st_size > MAX_FILE_SIZE_BYTES:
                continue
            if _looks_binary(fp):
                continue
            with fp.open("r", encoding="utf-8", errors="ignore") as fh:
                for lineno, line in enumerate(fh, start=1):
                    if len(matches) >= max_matches:
                        break
                    if _line_matches(line, query, q_lower, pattern, case_sensitive):
                        rel: Path
                        if base.is_dir():
                            rel = fp.relative_to(base)
                        else:
                            rel = fp.name  # single-file case
                        matches.append(
                            f"{rel}:{lineno}: {line.rstrip()}"
                        )
        except (OSError, UnicodeDecodeError):
            continue

    if not matches:
        if walk_truncated:
            return (
                f"No matches for {query!r} in {path} "
                f"[scan truncated: {truncate_reason}; narrow the path "
                "or use a more specific query]"
            )
        return f"No matches for {query!r} in {path}"

    header = f"Found {len(matches)} match(es) for {query!r} in {path}:"
    out = header + "\n" + "\n".join(matches)
    if walk_truncated:
        out += f"\n...[scan truncated: {truncate_reason}]"
    if len(out) > MAX_TOTAL_OUTPUT_CHARS:
        out = out[:MAX_TOTAL_OUTPUT_CHARS] + "\n...[truncated]"
    return out


file_grep = Tool(
    name="file_grep",
    description=(
        "Search a local text corpus for a case-insensitive substring. "
        "Recursively walks the given directory (or searches a single file) "
        "and returns matching lines as `<relpath>:<lineno>: <line>`, capped "
        "at max_matches. Use for finding where a specific term, name, or "
        "phrase appears in a document collection. "
        "Pass regex=true to interpret the query as a Python regex (applied "
        "per line); pass case_sensitive=true for exact-case matching. "
        "WARNING: regex=true compiles user-supplied patterns without a "
        "timeout — pathological patterns like `(a+)+$` can hang on long "
        "lines. Do not pass attacker-controlled queries to regex mode."
    ),
    input_schema={
        "type": "object",
        "required": ["query", "path"],
        "properties": {
            "query": {
                "type": "string",
                "description": "Substring to search for (case-insensitive).",
            },
            "path": {
                "type": "string",
                "description": (
                    "Path to a directory (searched recursively, "
                    "skipping .git / node_modules / build dirs) or a single file."
                ),
            },
            "max_matches": {
                "type": "integer",
                "description": "Cap on returned matches.",
                "default": 30,
            },
            "pattern": {
                "type": "boolean",
                "description": (
                    "If true, interpret query as a Python regex (re.MULTILINE "
                    "implicitly per-line). If false (default), substring match. "
                    "Aliases: `regex` (back-compat); both names accepted."
                ),
                "default": False,
            },
            "regex": {
                "type": "boolean",
                "description": (
                    "Deprecated alias for `pattern`. Prefer `pattern` in new "
                    "calls. Both kwargs are accepted; if both supplied, "
                    "`pattern` wins (matches LLM-prior intent)."
                ),
                "default": False,
            },
            "case_sensitive": {
                "type": "boolean",
                "description": (
                    "If true, match case-sensitively. Default false."
                ),
                "default": False,
            },
        },
    },
    handler=_file_grep_handler,
    untrusted_output=True,
    channels=["cli", "web"],
)
