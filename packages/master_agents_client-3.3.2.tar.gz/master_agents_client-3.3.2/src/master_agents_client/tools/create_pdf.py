"""Built-in `create_pdf` tool — HTML → PDF via xhtml2pdf (default).

Engine choice:
- xhtml2pdf (default): pure Python, Windows-friendly, basic CSS. Installs
  via pip alone.
- weasyprint (opt-in): requires GTK on Windows; richer CSS including flex
  and grid. Install with `pip install master-agents[pdf-weasyprint]`.
- reportlab (opt-in): programmatic only (not HTML); for forms / exact
  positioning. Install with `pip install master-agents[pdf-reportlab]`.

LLM usage notes — xhtml2pdf limitations agents should know about:
- No CSS flexbox / grid (silently drops; content may position off-page)
- No `@font-face` with remote URLs
- Non-Latin glyphs (Chinese, Arabic, emoji) render as boxes unless a font
  is explicitly embedded
- Use `page-break-before` / `page-break-after` (not `break-before`)
- Prefer table-based layouts with inline styles
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from .base import Tool

SUPPORTED_ENGINES = ("xhtml2pdf", "weasyprint", "reportlab")


async def _create_pdf_handler(
    path: str,
    html: str,
    css: str | None = None,
    engine: Literal["xhtml2pdf", "weasyprint", "reportlab"] = "xhtml2pdf",
    max_html_chars: int = 500_000,
    max_css_chars: int = 100_000,
) -> str:
    if engine not in SUPPORTED_ENGINES:
        return (
            f"create_pdf: unknown engine {engine!r}. "
            f"Supported: {', '.join(SUPPORTED_ENGINES)}"
        )
    if not isinstance(html, str) or not html:
        return "create_pdf: html must be a non-empty string"
    if len(html) > max_html_chars:
        return (
            f"create_pdf: html too large ({len(html)} chars, max {max_html_chars}). "
            "Reduce the content or split into multiple PDFs."
        )
    if css is not None:
        if not isinstance(css, str):
            return "create_pdf: css must be a string if provided"
        if len(css) > max_css_chars:
            return (
                f"create_pdf: css too large ({len(css)} chars, max {max_css_chars})."
            )

    from ._session_outputs import (
        download_url_for,
        resolve_create_target,
        session_id_var,
    )
    try:
        p, is_sandboxed = resolve_create_target(path)
    except ValueError as exc:
        return f"create_pdf: {exc}"
    if p.suffix.lower() != ".pdf":
        return f"create_pdf: path must end in .pdf (got {path})"

    try:
        p.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return f"create_pdf: {type(exc).__name__}: {exc}"

    # Compose final HTML with inline CSS if provided
    final_html = html
    if css:
        if "<style>" not in html and "<head>" in html:
            final_html = html.replace(
                "<head>", f"<head><style>{css}</style>", 1
            )
        else:
            # Wrap with a minimal document envelope
            final_html = (
                f"<html><head><style>{css}</style></head>"
                f"<body>{html}</body></html>"
            )

    if engine == "xhtml2pdf":
        result = _render_xhtml2pdf(p, final_html)
    elif engine == "weasyprint":
        result = _render_weasyprint(p, final_html)
    elif engine == "reportlab":
        result = _render_reportlab(p, final_html)
    else:
        return f"create_pdf: engine {engine!r} not implemented"
    # On web channel, tell the agent where the user can fetch the file.
    if is_sandboxed and not result.startswith("create_pdf:"):
        sid = session_id_var.get()
        if sid is not None:
            result += f"\n\nDownload URL: {download_url_for(sid, p.name)}"
    return result


def _render_xhtml2pdf(path: Path, html: str) -> str:
    try:
        from xhtml2pdf import pisa  # type: ignore
    except ImportError:
        return (
            "create_pdf: xhtml2pdf not installed. "
            "Install with: pip install xhtml2pdf"
        )
    try:
        with path.open("wb") as fh:
            status = pisa.CreatePDF(html, dest=fh)
        if getattr(status, "err", 0):
            return f"create_pdf: xhtml2pdf render failed ({status.err} error(s))"
    except Exception as exc:
        return f"create_pdf: xhtml2pdf error: {type(exc).__name__}: {exc}"
    return f"Wrote pdf: {path} ({path.stat().st_size} bytes, engine=xhtml2pdf)"


def _render_weasyprint(path: Path, html: str) -> str:
    try:
        from weasyprint import HTML  # type: ignore
    except ImportError:
        return (
            "create_pdf: weasyprint engine not installed. "
            "Install with: pip install master-agents[pdf-weasyprint]"
        )
    except OSError as exc:
        # weasyprint import itself tries to load GTK / libgobject on import.
        # On Windows without GTK, that raises OSError: "cannot load library ...".
        return (
            f"create_pdf: weasyprint native libraries missing ({exc}). "
            "Windows users need GTK runtime libraries — see "
            "https://doc.courtbouillon.org/weasyprint/stable/first_steps.html. "
            "Fall back to engine='xhtml2pdf' for pure-Python rendering."
        )
    try:
        HTML(string=html).write_pdf(str(path))
    except OSError as exc:
        return (
            f"create_pdf: weasyprint render failed ({exc}). "
            "Windows users may need GTK runtime libraries; see "
            "https://doc.courtbouillon.org/weasyprint/stable/first_steps.html"
        )
    except Exception as exc:
        return f"create_pdf: weasyprint error: {type(exc).__name__}: {exc}"
    return f"Wrote pdf: {path} ({path.stat().st_size} bytes, engine=weasyprint)"


def _render_reportlab(path: Path, html: str) -> str:
    try:
        from reportlab.lib.pagesizes import letter  # type: ignore
        from reportlab.pdfgen import canvas  # type: ignore
    except ImportError:
        return (
            "create_pdf: reportlab engine not installed. "
            "Install with: pip install master-agents[pdf-reportlab]"
        )
    # reportlab is programmatic, not HTML. For the opt-in path we provide a
    # minimal text-dump fallback — users who want layout control should call
    # reportlab directly via python_eval. The framework's reportlab path is
    # intentionally limited in v1.
    try:
        import re as _re

        text = _re.sub(r"<[^>]+>", " ", html)
        text = _re.sub(r"\s+", " ", text).strip()
        c = canvas.Canvas(str(path), pagesize=letter)
        c.setFont("Helvetica", 11)
        y = 750
        for line in _wrap_lines(text, width=90):
            if y < 50:
                c.showPage()
                c.setFont("Helvetica", 11)
                y = 750
            c.drawString(50, y, line)
            y -= 14
        c.save()
    except Exception as exc:
        return f"create_pdf: reportlab error: {type(exc).__name__}: {exc}"
    return f"Wrote pdf: {path} ({path.stat().st_size} bytes, engine=reportlab)"


def _wrap_lines(text: str, *, width: int) -> list[str]:
    words = text.split(" ")
    lines: list[str] = []
    current = ""
    for word in words:
        if len(current) + len(word) + 1 > width:
            if current:
                lines.append(current)
            current = word
        else:
            current = f"{current} {word}" if current else word
    if current:
        lines.append(current)
    return lines


create_pdf = Tool(
    name="create_pdf",
    description=(
        "Render HTML (with optional CSS) to a PDF file. Default engine is "
        "xhtml2pdf (pure Python, basic CSS, Windows-friendly). Opt-in engines: "
        "'weasyprint' (requires GTK on Windows; richer CSS with flex/grid), "
        "'reportlab' (programmatic; for precision forms). "
        "Limitations of default xhtml2pdf: no flex/grid, no remote webfonts, "
        "non-Latin glyphs render as boxes without embedded fonts. "
        "Prefer table-based layouts + inline styles."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "html"],
        "properties": {
            "path": {"type": "string", "description": "Destination .pdf path."},
            "html": {
                "type": "string",
                "description": "HTML document to render. A minimal html/body envelope is added if missing.",
            },
            "css": {
                "type": "string",
                "description": "Optional CSS to inject into <head><style>...</style></head>.",
            },
            "engine": {
                "type": "string",
                "enum": list(SUPPORTED_ENGINES),
                "description": "Render engine. Default 'xhtml2pdf'.",
                "default": "xhtml2pdf",
            },
            "max_html_chars": {
                "type": "integer",
                "description": "Hard cap on html input length (default 500000).",
                "default": 500_000,
            },
            "max_css_chars": {
                "type": "integer",
                "description": "Hard cap on css input length (default 100000).",
                "default": 100_000,
            },
        },
    },
    handler=_create_pdf_handler,
    requires_approval=True,
    channels=["cli", "web"],
    tier="premium",
)
