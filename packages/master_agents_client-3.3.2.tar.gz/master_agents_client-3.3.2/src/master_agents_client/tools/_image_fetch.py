"""Shared image-fetching helper for create_docx / create_pptx.

Both tools accept an `image: { url | path | base64 }` field and need
to materialise the bytes the same way: download via httpx for URLs,
read for local paths, -decode for inline. Same 5MB cap, same 15s
timeout — the spec was duplicated in create_docx; lifted here so
create_pptx (and any future creator) can reuse it.
"""

from __future__ import annotations

import base64 as _b64
from pathlib import Path

from ._session_cwd import resolve_under_session_cwd


# Same 5MB cap the service uses; large images bloat the output and slow
# downloads. Override per-call by passing your own cap if a use case
# really needs it.
DEFAULT_MAX_IMAGE_BYTES = 5 * 1024 * 1024
DEFAULT_FETCH_TIMEOUT_S = 15.0


_EXT_BY_CTYPE = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/webp": ".webp",
    "image/gif": ".gif",
}


def fetch_image_bytes(
    *,
    url: str | None = None,
    path: str | None = None,
    base64: str | None = None,
    max_bytes: int = DEFAULT_MAX_IMAGE_BYTES,
    timeout_seconds: float = DEFAULT_FETCH_TIMEOUT_S,
) -> tuple[bytes, str]:
    """Materialise image bytes from one of url / path / base64.

    Returns (bytes, suggested_extension). Raises ValueError on:
      - missing source / multiple sources
      - non-http(s) url
      - non-200 response
      - missing local path
      - invalid base64
      - oversize content (> max_bytes)

    Callers wrap the bytes in `io.BytesIO(...)` for python-docx /
    python-pptx `add_picture()`.
    """
    sources = sum(1 for v in (url, path, base64) if v)
    if sources == 0:
        raise ValueError("image requires one of: url, path, base64")
    if sources > 1:
        raise ValueError("image: provide only one of url/path/base64")

    if url:
        if not url.startswith(("http://", "https://")):
            raise ValueError(f"image url must be http(s): {url!r}")
        # Lazy import — httpx is an optional runtime dep for this path.
        import httpx
        with httpx.Client(
            timeout=timeout_seconds, follow_redirects=True,
        ) as cli:
            resp = cli.get(
                url, headers={"User-Agent": "master-agents-client/0.1"},
            )
        if resp.status_code != 200:
            raise ValueError(f"image fetch failed: HTTP {resp.status_code}")
        raw = resp.content
        ctype = (
            resp.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        )
        ext = (
            _EXT_BY_CTYPE.get(ctype)
            or Path(url.split("?", 1)[0]).suffix.lower()
            or ".png"
        )
    elif path:
        target = resolve_under_session_cwd(path)
        if not target.exists() or not target.is_file():
            raise ValueError(f"image path not found: {path}")
        raw = target.read_bytes()
        ext = target.suffix.lower() or ".png"
    else:
        try:
            raw = _b64.b64decode(base64, validate=True)
        except Exception as exc:
            raise ValueError(f"image base64 invalid: {exc}")
        ext = ".png"  # caller must know; default

    if len(raw) > max_bytes:
        raise ValueError(
            f"image too large ({len(raw)} bytes; max {max_bytes})"
        )
    return raw, ext
