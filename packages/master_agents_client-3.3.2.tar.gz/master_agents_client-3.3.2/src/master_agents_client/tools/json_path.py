"""Built-in `json_path` tool — JSONPath extraction from JSON files."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

from .base import Tool


async def _json_path_handler(
    path: str,
    expression: str,
    max_results: int = 100,
    max_file_bytes: int = 50_000_000,
    timeout_seconds: int = 10,
    max_chars: int = 50_000,
) -> str:
    p = Path(path)
    if not p.exists():
        return f"Path does not exist: {path}"
    if not p.is_file():
        return f"Not a file: {path}"

    size = p.stat().st_size
    if size > max_file_bytes:
        return (
            f"json_path: file too large ({size} bytes, max {max_file_bytes}). "
            "Reduce the file or increase max_file_bytes."
        )

    try:
        with p.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
    except json.JSONDecodeError as exc:
        return f"json_path: invalid JSON — decode error: {exc}"
    except (OSError, UnicodeDecodeError) as exc:
        return f"json_path: {type(exc).__name__}: {exc}"

    try:
        from jsonpath_ng.ext import parse  # type: ignore
    except ImportError:  # pragma: no cover
        return "json_path: jsonpath-ng not installed."

    try:
        jsonpath_expr = parse(expression)
    except Exception as exc:
        return f"json_path: JSONPath error ({type(exc).__name__}): {exc}"

    def _do_match() -> list:
        return [match.value for match in jsonpath_expr.find(data)]

    try:
        matches = await asyncio.wait_for(
            asyncio.to_thread(_do_match),
            timeout=timeout_seconds,
        )
    except asyncio.TimeoutError:
        return (
            f"json_path: evaluation timed out after {timeout_seconds}s. "
            "Simplify the expression or increase timeout_seconds."
        )

    if not matches:
        return f"json_path: 0 results for {expression!r}"

    total = len(matches)
    truncated = total > max_results
    matches = matches[:max_results]

    header = f"expression={expression} | {len(matches)} result(s)"
    if truncated:
        header += f" [truncated at max_results={max_results}]"
    lines = [header]
    for value in matches:
        lines.append(json.dumps(value, ensure_ascii=False))
    out = "\n".join(lines)
    if len(out) > max_chars:
        out = out[:max_chars] + "\n[truncated]"
    return out


json_path = Tool(
    name="json_path",
    description=(
        "Extract values from a JSON file via a JSONPath expression "
        "(e.g. '$.store.book[*].title', '$[1]', '$..price'). Returns "
        "one JSON value per line. Use for structured lookup in configs, "
        "API dumps, and data files. "
        "NOTE on timeout: timeout_seconds unblocks the caller on expiry, "
        "but jsonpath-ng evaluation runs on a worker thread that cannot "
        "be force-cancelled — an adversarial expression on deep data may "
        "continue consuming CPU until it finishes naturally. Keep "
        "max_file_bytes and expression complexity in check."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "expression"],
        "properties": {
            "path": {"type": "string", "description": "Path to a JSON file."},
            "expression": {
                "type": "string",
                "description": "JSONPath expression.",
            },
            "max_results": {
                "type": "integer",
                "description": "Cap on returned matches (default 100).",
                "default": 100,
            },
            "max_file_bytes": {
                "type": "integer",
                "description": "Reject files larger than this (default 50MB).",
                "default": 50_000_000,
            },
            "timeout_seconds": {
                "type": "integer",
                "description": "Wall-clock cap on JSONPath evaluation (default 10s).",
                "default": 10,
            },
        },
    },
    handler=_json_path_handler,
    untrusted_output=True,
    channels=["cli"],
)
