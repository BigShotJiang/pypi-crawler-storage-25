"""Built-in `create_pptx` tool.

Renders a structured spec into a `.pptx` deck. Supports a compact set of slide
layouts that are straightforward for LLMs to emit consistently: title,
content, two-column, and table.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import Tool


def _require_pptx():
    try:
        from pptx import Presentation
        from pptx.dml.color import RGBColor
        from pptx.enum.shapes import MSO_SHAPE
        from pptx.enum.text import MSO_AUTO_SIZE
        from pptx.util import Emu, Inches, Pt
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "create_pptx requires the 'python-pptx' package. "
            "Install it before using this tool."
        ) from exc
    return Presentation, RGBColor, MSO_SHAPE, MSO_AUTO_SIZE, Emu, Inches, Pt


def _enable_auto_fit(text_frame: Any) -> None:
    """Make a textbox auto-shrink its text to stay within its shape.

    Set TEXT_TO_FIT_SHAPE so when bullets / paragraphs run long, the
    font shrinks rather than overflowing the slide. The shape's
    geometry stays fixed (caller's layout intent preserved).
    Best-effort: catches python-pptx version differences on older
    deployments where the property may not exist.
    """
    try:
        from pptx.enum.text import MSO_AUTO_SIZE
        text_frame.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
        text_frame.word_wrap = True
    except Exception:  # pragma: no cover - defensive
        pass


# Default font sizes — tuned for slide projection at ~10ft.
_TITLE_SLIDE_TITLE_PT = 40    # opening slide, bold + dramatic
_TITLE_SLIDE_SUB_PT = 22
_SECTION_TITLE_PT = 48        # divider — biggest
_SECTION_SUB_PT = 22
_CONTENT_TITLE_PT = 30        # in placeholder default; we set explicitly
_CONTENT_BODY_PT = 22         # bullets default
_IMAGE_TITLE_PT = 32          # full-bleed image layout
_IMAGE_CAPTION_PT = 16
_TWO_COL_TITLE_PT = 28
_TWO_COL_BODY_PT = 20
_TABLE_TITLE_PT = 28
_TABLE_HEADER_PT = 18
_TABLE_BODY_PT = 16


# Default 16:9 widescreen content area dimensions used when computing
# image fits / hero layouts (python-pptx default deck is 13.33 x 7.5").
_SLIDE_WIDTH_IN = 13.33
_SLIDE_HEIGHT_IN = 7.5


def _set_slide_background(slide: Any, hex_color: str | None, RGBColor: Any) -> None:
    """Fill the slide background with a solid color (hex like '#0F1117')."""
    rgb = _rgb_from_hex(hex_color, RGBColor)
    if rgb is None:
        return
    try:
        bg = slide.background
        fill = bg.fill
        fill.solid()
        fill.fore_color.rgb = rgb
    except Exception:  # pragma: no cover - defensive
        pass


def _is_dark_hex(hex_color: str | None) -> bool:
    """Return True if the hex color is dark enough to need light text.

    Uses the standard luma formula (0.299 R + 0.587 G + 0.114 B); a
    luma value below ~0.55 reads as dark for readability purposes.
    Anything that isn't a valid 6-char hex is treated as not-dark
    (fall back to default theme behavior).
    """
    if not hex_color:
        return False
    text = hex_color.strip().lstrip("#")
    if len(text) != 6:
        return False
    try:
        r = int(text[0:2], 16) / 255
        g = int(text[2:4], 16) / 255
        b = int(text[4:6], 16) / 255
    except ValueError:
        return False
    luma = 0.299 * r + 0.587 * g + 0.114 * b
    return luma < 0.55


def _contrast_text_color(bg_hex: str | None, RGBColor: Any) -> Any | None:
    """Return a text-color RGB that reads cleanly on the given bg.

    Dark bg → near-white (#F8FAFC). Light bg → near-black (#0F172A).
    Returns None if bg_hex isn't parseable (caller falls back to its
    own default).
    """
    if not bg_hex or not isinstance(bg_hex, str):
        return None
    if _is_dark_hex(bg_hex):
        return _rgb_from_hex("#F8FAFC", RGBColor)
    return _rgb_from_hex("#0F172A", RGBColor)


def _add_speaker_notes(slide: Any, notes: str | None) -> None:
    """Attach speaker notes to the slide if provided."""
    if not isinstance(notes, str) or not notes.strip():
        return
    notes_slide = slide.notes_slide
    notes_slide.notes_text_frame.text = notes.strip()


def _add_picture_from_spec(
    slide: Any,
    image_spec: dict[str, Any],
    *,
    Inches: Any,
    default_width_in: float = 8.0,
    default_top_in: float = 1.5,
    default_left_in: float | None = None,
    max_height_in: float | None = None,
) -> Any:
    """Embed an image on a slide. Returns the picture shape.

    Aspect-aware fit: setting `width` alone makes python-pptx scale
    height proportionally — but a 4:3 image at 10" width becomes 7.5"
    tall and overflows the slide bottom (slide is 7.5" tall and we
    typically reserve ~1.3" for the title). We therefore inspect the
    source image's actual dimensions and clamp width down so the
    resulting height fits `max_height_in` (default = remaining space
    on a 16:9 slide after the title).

    Spec fields:
      url | path | base64   one source (required)
      width_in              optional float, defaults to default_width_in
      left_in / top_in      optional explicit positioning (inches)
      align                 'left' | 'center' | 'right' if no left_in
                            given (default 'center')
    """
    import io
    from ._image_fetch import fetch_image_bytes
    raw, _ext = fetch_image_bytes(
        url=image_spec.get("url"),
        path=image_spec.get("path"),
        base64=image_spec.get("base64"),
    )

    requested_width_in = float(image_spec.get("width_in", default_width_in))
    requested_width_in = max(0.5, min(requested_width_in, _SLIDE_WIDTH_IN - 0.5))

    top_in = float(image_spec.get("top_in", default_top_in))
    # Default max height = whatever's left below the top + a small
    # bottom margin. Caller can pass an explicit cap (e.g. for
    # full-bleed image layouts that reserve space for a caption).
    if max_height_in is None:
        max_height_in = max(1.0, _SLIDE_HEIGHT_IN - top_in - 0.4)

    # Get actual image aspect ratio. Pillow ships as a transitive
    # dep of python-pptx; if unavailable, fall back to assuming the
    # caller's width is correct (preserves old behavior).
    aspect = None
    try:
        from PIL import Image as _Image
        with _Image.open(io.BytesIO(raw)) as img:
            w, h = img.size
            if w > 0 and h > 0:
                aspect = w / h  # >1 = landscape, <1 = portrait
    except Exception:  # pragma: no cover - defensive
        pass

    width_in = requested_width_in
    if aspect is not None:
        height_at_requested = requested_width_in / aspect
        if height_at_requested > max_height_in:
            # Scale down so height fits.
            width_in = max_height_in * aspect
            width_in = max(0.5, min(width_in, _SLIDE_WIDTH_IN - 0.5))

    if image_spec.get("left_in") is not None:
        left_in = float(image_spec["left_in"])
    elif default_left_in is not None:
        left_in = default_left_in
    else:
        align = (image_spec.get("align") or "center").lower()
        if align == "left":
            left_in = 0.5
        elif align == "right":
            left_in = _SLIDE_WIDTH_IN - width_in - 0.5
        else:
            left_in = (_SLIDE_WIDTH_IN - width_in) / 2

    return slide.shapes.add_picture(
        io.BytesIO(raw),
        Inches(left_in),
        Inches(top_in),
        width=Inches(width_in),
    )


def _normalise_bullets(bullets: list[Any]) -> list[tuple[str, int]]:
    """Accept bullets as either str or `{text, level}` dicts. Returns
    a flat list of (text, level) tuples with level clamped to 0-3."""
    out: list[tuple[str, int]] = []
    for item in bullets or []:
        if isinstance(item, dict):
            text = str(item.get("text", "")).strip()
            level = max(0, min(int(item.get("level", 0) or 0), 3))
        else:
            text = str(item).strip()
            level = 0
        if text:
            out.append((text, level))
    return out


def _rgb_from_hex(value: str | None, RGBColor: Any) -> Any | None:
    if not value:
        return None
    text = value.strip().lstrip("#")
    if len(text) != 6:
        return None
    try:
        return RGBColor.from_string(text.upper())
    except Exception:
        return None


def _apply_run_theme(run: Any, *, font_name: str | None, size_pt: int | None, color: Any | None, Pt: Any) -> None:
    if font_name:
        run.font.name = font_name
    if size_pt:
        run.font.size = Pt(size_pt)
    if color is not None:
        run.font.color.rgb = color


def _set_text_frame(
    text_frame: Any,
    paragraphs: list[str],
    *,
    font_name: str | None,
    size_pt: int,
    color: Any | None,
    Pt: Any,
) -> None:
    text_frame.clear()
    _enable_auto_fit(text_frame)
    for idx, line in enumerate(paragraphs):
        para = text_frame.paragraphs[0] if idx == 0 else text_frame.add_paragraph()
        para.text = str(line)
        para.level = 0
        for run in para.runs:
            _apply_run_theme(
                run,
                font_name=font_name,
                size_pt=size_pt,
                color=color,
                Pt=Pt,
            )


def _set_bullets(
    text_frame: Any,
    bullets: list[Any],
    *,
    font_name: str | None,
    size_pt: int,
    color: Any | None,
    Pt: Any,
    add_markers: bool = True,
) -> None:
    """Render bullets into a text frame.

    `add_markers=True` prepends a Unicode bullet glyph to each line —
    needed when the parent textbox is custom (not a placeholder), since
    only placeholders inherit "List Bullet" styling from the slide
    master. Set False if you've placed the bullets in a content
    placeholder that already renders markers.
    """
    text_frame.clear()
    _enable_auto_fit(text_frame)
    levelled = _normalise_bullets(bullets)
    # Glyph per level: top-level filled disc, level 1 en-dash,
    # level 2 hollow disc, level 3 small square. Indented via
    # leading spaces (custom textboxes ignore para.level for indent).
    glyphs = ["• ", "  – ", "    ◦ ", "      ▪ "]
    for idx, (text, level) in enumerate(levelled):
        para = text_frame.paragraphs[0] if idx == 0 else text_frame.add_paragraph()
        if add_markers:
            para.text = glyphs[min(level, len(glyphs) - 1)] + text
        else:
            para.text = text
        para.level = level
        # Slightly smaller font for nested levels — visual hierarchy.
        effective_size = max(14, size_pt - level * 2)
        for run in para.runs:
            _apply_run_theme(
                run,
                font_name=font_name,
                size_pt=effective_size,
                color=color,
                Pt=Pt,
            )


def _set_title(
    shape: Any,
    title: str,
    *,
    font_name: str | None,
    color: Any | None,
    Pt: Any,
    size_pt: int = _CONTENT_TITLE_PT,
    bold: bool = True,
) -> None:
    if not getattr(shape, "text_frame", None):
        return
    shape.text = str(title)
    _enable_auto_fit(shape.text_frame)
    for paragraph in shape.text_frame.paragraphs:
        for run in paragraph.runs:
            run.font.bold = bold
            _apply_run_theme(
                run,
                font_name=font_name,
                size_pt=size_pt,
                color=color,
                Pt=Pt,
            )


def _render_content_slide(
    presentation: Any,
    slide_spec: dict[str, Any],
    *,
    font_name: str | None,
    primary_color: Any | None,
    body_color: Any | None,
    RGBColor: Any,
    Inches: Any,
    Pt: Any,
) -> None:
    slide = presentation.slides.add_slide(presentation.slide_layouts[1])
    _set_title(
        slide.shapes.title, str(slide_spec.get("title", "")),
        font_name=font_name, color=primary_color, Pt=Pt,
        size_pt=_CONTENT_TITLE_PT,
    )
    bullets = slide_spec.get("bullets", []) or []
    image_spec = slide_spec.get("image") or slide_spec.get("hero_image")
    has_hero = isinstance(slide_spec.get("hero_image"), dict)

    if has_hero and bullets:
        # Split: bullets on the left half, image on the right.
        # Replace the default content placeholder with a custom textbox.
        try:
            slide.placeholders[1]._element.getparent().remove(
                slide.placeholders[1]._element
            )
        except Exception:  # pragma: no cover - defensive
            pass
        bullet_box = slide.shapes.add_textbox(
            Inches(0.6), Inches(1.4), Inches(6.0), Inches(5.5),
        )
        _set_bullets(
            bullet_box.text_frame, bullets,
            font_name=font_name, size_pt=_CONTENT_BODY_PT, color=body_color, Pt=Pt,
        )
        _add_picture_from_spec(
            slide, slide_spec["hero_image"],
            Inches=Inches,
            default_width_in=6.0,
            default_top_in=1.4,
            default_left_in=7.0,
        )
    elif bullets and len(slide.placeholders) > 1:
        _set_bullets(
            slide.placeholders[1].text_frame, bullets,
            font_name=font_name, size_pt=_CONTENT_BODY_PT, color=body_color, Pt=Pt,
            add_markers=False,  # placeholder inherits master's bullet style
        )
        if isinstance(image_spec, dict) and not has_hero:
            # `image` field on a content slide: place below the bullets,
            # centered, half-width.
            _add_picture_from_spec(
                slide, image_spec, Inches=Inches,
                default_width_in=6.0, default_top_in=4.5,
            )

    _set_slide_background(slide, slide_spec.get("background"), RGBColor)
    _add_speaker_notes(slide, slide_spec.get("notes"))


def _render_title_slide(
    presentation: Any,
    slide_spec: dict[str, Any],
    *,
    font_name: str | None,
    primary_color: Any | None,
    body_color: Any | None,
    RGBColor: Any,
    Pt: Any,
) -> None:
    slide = presentation.slides.add_slide(presentation.slide_layouts[0])
    # Pick text colors that contrast with whatever background we'll
    # paint (default white if no override). Title slides commonly use
    # dark backgrounds — text MUST flip to light for readability.
    bg_hex = slide_spec.get("background")
    contrast_text = _contrast_text_color(bg_hex, RGBColor)
    title_color = contrast_text or primary_color
    sub_color = contrast_text or body_color
    _set_title(
        slide.shapes.title, str(slide_spec.get("title", "")),
        font_name=font_name, color=title_color, Pt=Pt,
        size_pt=_TITLE_SLIDE_TITLE_PT,
    )
    subtitle = str(slide_spec.get("subtitle", ""))
    if subtitle and len(slide.placeholders) > 1:
        slide.placeholders[1].text = subtitle
        for paragraph in slide.placeholders[1].text_frame.paragraphs:
            for run in paragraph.runs:
                _apply_run_theme(
                    run,
                    font_name=font_name,
                    size_pt=_TITLE_SLIDE_SUB_PT,
                    color=sub_color,
                    Pt=Pt,
                )
    _set_slide_background(slide, bg_hex, RGBColor)
    _add_speaker_notes(slide, slide_spec.get("notes"))


def _render_section_slide(
    presentation: Any,
    slide_spec: dict[str, Any],
    *,
    font_name: str | None,
    primary_color: Any | None,
    body_color: Any | None,
    RGBColor: Any,
    Inches: Any,
    Pt: Any,
) -> None:
    """Big centered divider slide: 'Part 2 — Implementation' style.

    Default background = primary_color so it visually breaks from the
    surrounding content slides; override with slide.background.
    Section slides default to a colored background; text auto-flips
    to a contrasting light color so the title is always readable.
    """
    slide = presentation.slides.add_slide(presentation.slide_layouts[6])  # blank
    title = str(slide_spec.get("title", ""))
    subtitle = str(slide_spec.get("subtitle", ""))

    # Section slides usually have a dark/colored background. Pick
    # contrast colors so title and subtitle stay legible regardless
    # of the bg the designer chose. Falls back to primary_color /
    # body_color when no bg is specified.
    bg_hex = slide_spec.get("background")
    contrast_text = _contrast_text_color(bg_hex, RGBColor)
    title_color = contrast_text or primary_color
    sub_color = contrast_text or body_color

    title_box = slide.shapes.add_textbox(
        Inches(1.0), Inches(2.8), Inches(_SLIDE_WIDTH_IN - 2.0), Inches(1.5),
    )
    tf = title_box.text_frame
    tf.word_wrap = True
    tf.text = title
    para = tf.paragraphs[0]
    para.alignment = 2  # center
    for run in para.runs:
        run.font.bold = True
        _apply_run_theme(
            run, font_name=font_name, size_pt=_SECTION_TITLE_PT,
            color=title_color, Pt=Pt,
        )

    if subtitle:
        sub_box = slide.shapes.add_textbox(
            Inches(1.0), Inches(4.4),
            Inches(_SLIDE_WIDTH_IN - 2.0), Inches(0.8),
        )
        sf = sub_box.text_frame
        sf.text = subtitle
        sub_para = sf.paragraphs[0]
        sub_para.alignment = 2
        for run in sub_para.runs:
            _apply_run_theme(
                run, font_name=font_name, size_pt=_SECTION_SUB_PT,
                color=sub_color, Pt=Pt,
            )

    _set_slide_background(slide, bg_hex, RGBColor)
    _add_speaker_notes(slide, slide_spec.get("notes"))


def _render_image_slide(
    presentation: Any,
    slide_spec: dict[str, Any],
    *,
    font_name: str | None,
    primary_color: Any | None,
    body_color: Any | None,
    RGBColor: Any,
    Inches: Any,
    Pt: Any,
) -> None:
    """Full-bleed visual: title (top), big image (center), optional caption.

    Image required; defaults to fitting most of the content area.
    """
    slide = presentation.slides.add_slide(presentation.slide_layouts[6])  # blank

    title = str(slide_spec.get("title", ""))
    if title:
        title_box = slide.shapes.add_textbox(
            Inches(0.5), Inches(0.3), Inches(_SLIDE_WIDTH_IN - 1.0), Inches(0.8),
        )
        tf = title_box.text_frame
        tf.text = title
        para = tf.paragraphs[0]
        para.alignment = 2  # center
        for run in para.runs:
            run.font.bold = True
            _apply_run_theme(
                run, font_name=font_name, size_pt=_IMAGE_TITLE_PT,
                color=primary_color, Pt=Pt,
            )

    image_spec = slide_spec.get("image")
    if isinstance(image_spec, dict):
        try:
            top = 1.3 if title else 0.6
            caption_reserve = 0.9 if slide_spec.get("caption") else 0.4
            _add_picture_from_spec(
                slide, image_spec, Inches=Inches,
                default_width_in=10.0,
                default_top_in=top,
                max_height_in=_SLIDE_HEIGHT_IN - top - caption_reserve,
            )
        except ValueError as exc:
            # Surface the error inline so the user can see what went wrong.
            err_box = slide.shapes.add_textbox(
                Inches(1.0), Inches(3.0),
                Inches(_SLIDE_WIDTH_IN - 2.0), Inches(1.0),
            )
            err_box.text_frame.text = f"image error: {exc}"

    caption = str(slide_spec.get("caption", "")).strip()
    if caption:
        cap_box = slide.shapes.add_textbox(
            Inches(0.5), Inches(_SLIDE_HEIGHT_IN - 0.7),
            Inches(_SLIDE_WIDTH_IN - 1.0), Inches(0.5),
        )
        cf = cap_box.text_frame
        cf.text = caption
        cap_para = cf.paragraphs[0]
        cap_para.alignment = 2
        for run in cap_para.runs:
            run.italic = True
            _apply_run_theme(
                run, font_name=font_name, size_pt=_IMAGE_CAPTION_PT,
                color=body_color, Pt=Pt,
            )

    _set_slide_background(slide, slide_spec.get("background"), RGBColor)
    _add_speaker_notes(slide, slide_spec.get("notes"))


def _render_two_column_slide(
    presentation: Any,
    slide_spec: dict[str, Any],
    *,
    font_name: str | None,
    primary_color: Any | None,
    body_color: Any | None,
    RGBColor: Any,
    Inches: Any,
    Pt: Any,
) -> None:
    slide = presentation.slides.add_slide(presentation.slide_layouts[6])
    # Centered title across the full content width.
    title_box = slide.shapes.add_textbox(
        Inches(0.5), Inches(0.3),
        Inches(_SLIDE_WIDTH_IN - 1.0), Inches(0.8),
    )
    tf = title_box.text_frame
    tf.text = str(slide_spec.get("title", ""))
    _enable_auto_fit(tf)
    title_para = tf.paragraphs[0]
    title_para.alignment = 2  # center
    for run in title_para.runs:
        run.font.bold = True
        _apply_run_theme(
            run, font_name=font_name, size_pt=_TWO_COL_TITLE_PT,
            color=primary_color, Pt=Pt,
        )
    left = slide_spec.get("left", {}) if isinstance(slide_spec.get("left"), dict) else {}
    right = slide_spec.get("right", {}) if isinstance(slide_spec.get("right"), dict) else {}
    # Column geometry: 0.5" margin, 12.33" usable, ~0.4" gutter.
    col_w = (_SLIDE_WIDTH_IN - 0.5 * 2 - 0.4) / 2
    left_x = 0.5
    right_x = 0.5 + col_w + 0.4
    col_top = 1.4
    col_h = _SLIDE_HEIGHT_IN - col_top - 0.4
    # Heading box on top of each column (smaller height), bullets below.
    left_head = slide.shapes.add_textbox(
        Inches(left_x), Inches(col_top),
        Inches(col_w), Inches(0.6),
    )
    right_head = slide.shapes.add_textbox(
        Inches(right_x), Inches(col_top),
        Inches(col_w), Inches(0.6),
    )
    for box, side in ((left_head, left), (right_head, right)):
        head_tf = box.text_frame
        head_tf.text = str(side.get("heading", ""))
        _enable_auto_fit(head_tf)
        for run in head_tf.paragraphs[0].runs:
            run.font.bold = True
            _apply_run_theme(
                run, font_name=font_name, size_pt=_TWO_COL_BODY_PT + 4,
                color=primary_color, Pt=Pt,
            )
    # Bullet boxes below headings — use the real `_set_bullets` so we
    # get proper bullet markers + auto-fit + leveled indent.
    left_box = slide.shapes.add_textbox(
        Inches(left_x), Inches(col_top + 0.7),
        Inches(col_w), Inches(col_h - 0.7),
    )
    right_box = slide.shapes.add_textbox(
        Inches(right_x), Inches(col_top + 0.7),
        Inches(col_w), Inches(col_h - 0.7),
    )
    _set_bullets(
        left_box.text_frame, left.get("bullets", []) or [],
        font_name=font_name, size_pt=_TWO_COL_BODY_PT,
        color=body_color, Pt=Pt,
    )
    _set_bullets(
        right_box.text_frame, right.get("bullets", []) or [],
        font_name=font_name, size_pt=_TWO_COL_BODY_PT,
        color=body_color, Pt=Pt,
    )
    # Optional image on either column.
    if isinstance(left.get("image"), dict):
        _add_picture_from_spec(
            slide, left["image"], Inches=Inches,
            default_width_in=5.0, default_top_in=4.0,
            default_left_in=0.8,
        )
    if isinstance(right.get("image"), dict):
        _add_picture_from_spec(
            slide, right["image"], Inches=Inches,
            default_width_in=5.0, default_top_in=4.0,
            default_left_in=7.0,
        )
    _set_slide_background(slide, slide_spec.get("background"), RGBColor)
    _add_speaker_notes(slide, slide_spec.get("notes"))


def _render_table_slide(
    presentation: Any,
    slide_spec: dict[str, Any],
    *,
    font_name: str | None,
    primary_color: Any | None,
    body_color: Any | None,
    RGBColor: Any,
    Inches: Any,
    Pt: Any,
) -> None:
    slide = presentation.slides.add_slide(presentation.slide_layouts[6])
    title_box = slide.shapes.add_textbox(
        Inches(0.5), Inches(0.3),
        Inches(_SLIDE_WIDTH_IN - 1.0), Inches(0.8),
    )
    tf = title_box.text_frame
    tf.text = str(slide_spec.get("title", ""))
    _enable_auto_fit(tf)
    for run in tf.paragraphs[0].runs:
        run.font.bold = True
        _apply_run_theme(
            run, font_name=font_name, size_pt=_TABLE_TITLE_PT,
            color=primary_color, Pt=Pt,
        )
    columns = [str(c) for c in slide_spec.get("columns", []) or []]
    rows = slide_spec.get("rows", []) or []
    if not columns:
        return
    # Compact rows: header 0.6", body 0.55" each. Table top-aligned at
    # 1.4" so it sits just below the title; total height = sum of rows
    # rather than filling the slide (avoids massive padding when only
    # a few rows are present).
    n_rows = len(rows) + 1
    header_h = 0.6
    body_h = 0.55
    table_h = header_h + body_h * len(rows)
    table_shape = slide.shapes.add_table(
        n_rows,
        len(columns),
        Inches(0.5),
        Inches(1.4),
        Inches(_SLIDE_WIDTH_IN - 1.0),
        Inches(table_h),
    )
    table = table_shape.table
    # Lock per-row heights — python-pptx defaults to evenly-distributing
    # the total table height across rows, which gives huge cells for
    # short tables. Set explicitly.
    table.rows[0].height = Inches(header_h)
    for r in range(1, n_rows):
        table.rows[r].height = Inches(body_h)

    for idx, value in enumerate(columns):
        cell = table.cell(0, idx)
        cell.text = value
        for paragraph in cell.text_frame.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
                _apply_run_theme(run, font_name=font_name, size_pt=_TABLE_HEADER_PT, color=primary_color, Pt=Pt)
    for row_idx, row_values in enumerate(rows, start=1):
        for col_idx, value in enumerate(row_values):
            if col_idx >= len(columns):
                break
            cell = table.cell(row_idx, col_idx)
            cell.text = str(value)
            for paragraph in cell.text_frame.paragraphs:
                for run in paragraph.runs:
                    _apply_run_theme(run, font_name=font_name, size_pt=_TABLE_BODY_PT, color=body_color, Pt=Pt)
    _set_slide_background(slide, slide_spec.get("background"), RGBColor)
    _add_speaker_notes(slide, slide_spec.get("notes"))


def _render_pptx(path: Path, spec: dict[str, Any]) -> str:
    Presentation, RGBColor, MSO_SHAPE, MSO_AUTO_SIZE, Emu, Inches, Pt = _require_pptx()
    template_path = spec.get("template_path")
    if template_path:
        presentation = Presentation(str(Path(template_path).resolve()))
    else:
        presentation = Presentation()
        # Force 16:9 widescreen — python-pptx's default master is 4:3
        # (10×7.5"), but every layout/textbox/image position in this
        # module is computed against 13.33×7.5 (`_SLIDE_WIDTH_IN`).
        # Without this, custom textboxes overflow the right edge:
        # tables clip, two-column right column hangs off, full-bleed
        # images end up squashed in the corner.
        presentation.slide_width = Inches(_SLIDE_WIDTH_IN)
        presentation.slide_height = Inches(_SLIDE_HEIGHT_IN)

    props = presentation.core_properties
    if spec.get("title"):
        props.title = str(spec["title"])
    if spec.get("author"):
        props.author = str(spec["author"])

    theme = spec.get("theme", {}) if isinstance(spec.get("theme"), dict) else {}
    font_name = theme.get("font")
    primary_color = _rgb_from_hex(theme.get("primary_color"), RGBColor)
    body_color = _rgb_from_hex(theme.get("accent_color"), RGBColor)

    if not template_path:
        kwargs = dict(
            font_name=font_name,
            primary_color=primary_color,
            body_color=body_color,
            RGBColor=RGBColor,
            Inches=Inches,
            Pt=Pt,
        )
        for slide_spec in spec.get("slides", []) or []:
            if not isinstance(slide_spec, dict):
                continue
            layout = str(slide_spec.get("layout", "content"))
            if layout == "title":
                _render_title_slide(
                    presentation, slide_spec,
                    font_name=font_name,
                    primary_color=primary_color,
                    body_color=body_color,
                    RGBColor=RGBColor, Pt=Pt,
                )
            elif layout == "section":
                _render_section_slide(presentation, slide_spec, **kwargs)
            elif layout == "image":
                _render_image_slide(presentation, slide_spec, **kwargs)
            elif layout == "two_column":
                _render_two_column_slide(presentation, slide_spec, **kwargs)
            elif layout == "table":
                _render_table_slide(presentation, slide_spec, **kwargs)
            else:
                _render_content_slide(presentation, slide_spec, **kwargs)

    path.parent.mkdir(parents=True, exist_ok=True)
    presentation.save(path)
    return f"PPTX created at {path}"


async def _create_pptx_handler(path: str, spec: dict[str, Any]) -> str:
    from ._session_outputs import (
        download_url_for,
        resolve_create_target,
        session_id_var,
    )
    try:
        target, is_sandboxed = resolve_create_target(path)
    except ValueError as exc:
        return f"create_pptx: {exc}"
    if target.suffix.lower() != ".pptx":
        return f"create_pptx requires a .pptx path: {path}"
    if not isinstance(spec, dict):
        return "create_pptx requires spec to be an object."
    try:
        result = _render_pptx(target, spec)
    except Exception as exc:
        return f"create_pptx failed for {path}: {type(exc).__name__}: {exc}"
    if is_sandboxed:
        sid = session_id_var.get()
        if sid is not None:
            result += f"\n\nDownload URL: {download_url_for(sid, target.name)}"
    return result


create_pptx = Tool(
    name="create_pptx",
    description=(
        "Create a formatted .pptx deck (16:9, 13.33×7.5 in).\n"
        "\n"
        "Spec shape:\n"
        "  {\n"
        "    title?: str, author?: str,\n"
        "    template_path?: str,    # use a corporate .pptx as base\n"
        "    theme?: { font?, primary_color?, accent_color? },\n"
        "    slides: [\n"
        "      # Six layouts. Every slide accepts optional\n"
        "      # `background: '#hex'` and `notes: 'speaker notes'`.\n"
        "\n"
        "      # 1) title — opening slide\n"
        "      { layout: 'title', title, subtitle?, background?, notes? }\n"
        "\n"
        "      # 2) section — divider with big centered title\n"
        "      { layout: 'section', title, subtitle?, background?, notes? }\n"
        "\n"
        "      # 3) content — title + bullets, optional image\n"
        "      {\n"
        "        layout: 'content', title,\n"
        "        bullets: [ str | {text, level: 0-3} ],\n"
        "        image?: <image-spec>,         # placed below bullets\n"
        "        hero_image?: <image-spec>,    # placed RIGHT of bullets\n"
        "                                       # (mutually-exclusive w/ image)\n"
        "        background?, notes?\n"
        "      }\n"
        "\n"
        "      # 4) image — full-bleed visual + title + caption\n"
        "      {\n"
        "        layout: 'image', title?, caption?,\n"
        "        image: <image-spec>,\n"
        "        background?, notes?\n"
        "      }\n"
        "\n"
        "      # 5) two_column — heading + bullets in each column\n"
        "      {\n"
        "        layout: 'two_column', title,\n"
        "        left:  { heading, bullets, image? },\n"
        "        right: { heading, bullets, image? },\n"
        "        background?, notes?\n"
        "      }\n"
        "\n"
        "      # 6) table — title + columns + rows\n"
        "      {\n"
        "        layout: 'table', title,\n"
        "        columns: [str], rows: [[str, ...]],\n"
        "        background?, notes?\n"
        "      }\n"
        "    ]\n"
        "  }\n"
        "\n"
        "Image spec (used wherever `image` / `hero_image` appears):\n"
        "  {\n"
        "    # exactly one source:\n"
        "    url?: 'http(s)://...',  # tool fetches (5MB cap)\n"
        "    path?: '/local/path',\n"
        "    base64?: '...',\n"
        "    width_in?: 8.0,         # default 8\" (clamps to 0.5-12.8)\n"
        "    align?: 'center'|'left'|'right',  # ignored if left_in given\n"
        "    left_in?: 1.0, top_in?: 1.5       # explicit positioning\n"
        "  }\n"
        "\n"
        "For professional decks: lean on `section` slides between groups, "
        "use `image` layout for screenshots/diagrams, mix `hero_image` "
        "into content slides for explain-and-show. Bullet `level` "
        "indents for hierarchy (top-level = 0)."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "spec"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Destination .pptx path to write.",
            },
            "spec": {
                "type": "object",
                "description": (
                    "Deck spec — see tool description for the full shape "
                    "including image embedding, leveled bullets, "
                    "speaker notes, and background colors."
                ),
            },
        },
    },
    handler=_create_pptx_handler,
    requires_approval=True,
    channels=["cli", "web"],
    tier="premium",
)
