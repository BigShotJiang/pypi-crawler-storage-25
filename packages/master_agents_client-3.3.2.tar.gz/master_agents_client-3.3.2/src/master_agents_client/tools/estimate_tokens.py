"""Built-in `estimate_tokens` tool — pre-flight cost estimator.

Lets an agent ask "how big is this file?" or "how big would this slice
be?" BEFORE issuing `read_file`. The estimate runs server-side
(client-side under tool inversion); only the small summary string is
shipped back to the agent — the file's actual content never enters
the agent's context window.

Why this matters
----------------

Reading is expensive. A 340 KB index file is ~85k tokens. A 2.3 MB
JSON map is ~575k tokens. An agent that issues `read_file` blindly
on these files burns its entire budget on one tool call. With this
tool, the agent calls `estimate_tokens(path)` first, sees "85000
tokens", and switches to `file_grep` + narrow-window reads instead.

Token approximation
-------------------

Uses chars/4 — the standard heuristic for English / code. It's
approximate (real BPE tokens vary 3.5–4.5 chars depending on
language and code density) but accurate enough for budget decisions.
The tool reports the heuristic explicitly so the agent doesn't treat
it as exact.
"""

from __future__ import annotations

from pathlib import Path

from .base import Tool


# Heuristic: 1 token ≈ 4 chars for English / code. Documented so
# callers don't mistake the result for a tiktoken-precise count.
CHARS_PER_TOKEN = 4

# Hard cap on bytes we'll read just to count. Tool is metadata-only;
# don't burn server I/O scanning multi-GB files.
MAX_SCAN_BYTES = 50 * 1024 * 1024  # 50 MB


def _format_bytes(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n / (1024 * 1024):.2f} MB"


def _format_tokens(n: int) -> str:
    if n < 1000:
        return str(n)
    if n < 1_000_000:
        return f"{n / 1000:.1f}k".rstrip("0").rstrip(".") + "k" if False else f"{n / 1000:.1f}k"
    return f"{n / 1_000_000:.2f}M"


async def _estimate_tokens_handler(
    path: str | None = None,
    text: str | None = None,
    offset: int = 0,
    limit: int | None = None,
) -> str:
    """Return a one-line size summary for a file slice or a literal string.

    Exactly one of `path` or `text` must be provided. For `path`,
    `offset` (0-indexed lines) and `limit` (max lines) optionally
    narrow the measurement to a specific slice — match the same
    semantics the agent would use with `read_file`.
    """
    if (path is None) == (text is None):
        return "estimate_tokens: provide exactly one of `path` or `text`"

    if text is not None:
        chars = len(text)
        lines = text.count("\n") + (1 if text and not text.endswith("\n") else 0)
        tokens = chars // CHARS_PER_TOKEN
        return (
            f"~{_format_tokens(tokens)} tokens "
            f"({chars} chars, {lines} lines, heuristic chars/4)"
        )

    # path mode
    from ._session_cwd import resolve_under_session_cwd
    p = resolve_under_session_cwd(path)
    if not p.exists():
        return f"estimate_tokens: path does not exist: {path}"
    if not p.is_file():
        return f"estimate_tokens: not a file: {path}"

    size = p.stat().st_size
    if size > MAX_SCAN_BYTES and offset == 0 and limit is None:
        # Whole-file estimate on a huge file: skip the read, derive
        # from byte count + average line length is overkill — chars
        # ≈ bytes for ASCII-heavy corpora.
        tokens = size // CHARS_PER_TOKEN
        return (
            f"~{_format_tokens(tokens)} tokens "
            f"({_format_bytes(size)}, full file, heuristic chars/4 ≈ bytes/4)"
        )

    try:
        raw = p.read_bytes()
    except OSError as exc:
        return f"estimate_tokens: read failed: {exc}"

    text_content = raw.decode("utf-8", errors="replace")
    all_lines = text_content.splitlines(keepends=True)
    total_lines = len(all_lines)

    if offset < 0:
        offset = 0
    if offset >= total_lines:
        return (
            f"~0 tokens (0 chars, 0 lines: offset={offset} >= total {total_lines})"
        )
    end = total_lines if limit is None else min(offset + limit, total_lines)
    slice_text = "".join(all_lines[offset:end])
    chars = len(slice_text)
    lines = end - offset
    tokens = chars // CHARS_PER_TOKEN

    if offset == 0 and end == total_lines:
        scope = "full file"
    else:
        scope = f"lines {offset}–{end - 1} of {total_lines}"

    return (
        f"~{_format_tokens(tokens)} tokens "
        f"({chars} chars, {lines} lines, {scope}, "
        f"file size {_format_bytes(size)}, heuristic chars/4)"
    )


estimate_tokens = Tool(
    name="estimate_tokens",
    description=(
        "Pre-flight cost estimator. Returns approximate token count for "
        "a file (or a slice via offset/limit) WITHOUT loading the content "
        "into your context. Use this BEFORE read_file on any file you're "
        "not sure about — the result is a one-line summary, costs ~10 "
        "tokens, and tells you whether the read fits your budget. "
        "Heuristic: 1 token ≈ 4 chars (English / code). "
        "Alternatively pass `text` to count tokens in a string you "
        "already have. Use `path` mode for the cost-saving case."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": (
                    "File path to estimate. Provide either this OR `text`, "
                    "not both."
                ),
            },
            "text": {
                "type": "string",
                "description": (
                    "Literal string to measure. Provide either this OR "
                    "`path`, not both."
                ),
            },
            "offset": {
                "type": "integer",
                "default": 0,
                "minimum": 0,
                "description": (
                    "0-indexed start line for `path` mode. Same semantics "
                    "as read_file's offset."
                ),
            },
            "limit": {
                "type": "integer",
                "minimum": 1,
                "description": (
                    "Maximum lines to measure for `path` mode. Omit for "
                    "the whole file."
                ),
            },
        },
    },
    handler=_estimate_tokens_handler,
    requires_approval=False,
    abortable=False,
    channels=["cli", "web"],
)
