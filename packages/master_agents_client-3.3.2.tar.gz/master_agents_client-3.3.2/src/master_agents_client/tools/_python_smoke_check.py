""" — post-edit smoke-import check.

Used by `edit_file` and `write_file` to catch broken Python source
BEFORE the modification is left on disk. Closes A25, the live-test
finding where mao's A7 commit shipped a `NameError` because the
agent had no post-edit verification path.

Two-phase check:

1. **Syntax**: `py_compile.compile(path, doraise=True)`. ~1ms.
   Catches `SyntaxError` / `IndentationError`.
2. **Import**: subprocess `python -c "import <pkg>.<mod>"`. ~200-
   500ms on Windows, but catches `NameError`, `ImportError`,
   top-level execution errors, dataclass-field-default-factory
   bugs (the exact A7 case).

The subprocess uses the same Python interpreter (`sys.executable`).
PYTHONPATH is augmented with the package-root parent so the dotted
import resolves correctly. A 5-second timeout prevents hangs from
modules with heavy import-time side effects.

The check is opt-out, not opt-in: by default every Python edit
runs it. Set `MASTER_AGENTS_DISABLE_SMOKE_CHECK=1` to skip — used
by users editing snippets, fragments, or files that aren't
importable as modules.

The check returns `None` on pass and a short diagnostic string
on fail. Callers (edit_file / write_file) revert the on-disk
file and surface the diagnostic to the agent verbatim.
"""

from __future__ import annotations

import os
import py_compile
import subprocess
import sys
from pathlib import Path

_SUBPROCESS_TIMEOUT_S = 5.0
_DIAGNOSTIC_MAX_CHARS = 1500


def python_smoke_check(path: Path) -> str | None:
    """Return a diagnostic string if `path` doesn't import cleanly.

    Returns `None` when:
      - The file isn't a `.py` file.
      - The check is disabled via env var.
      - py_compile passes AND (subprocess import passes OR the
        module path can't be determined OR the subprocess timed
        out).

    Returns a diagnostic on:
      - py_compile failure (SyntaxError, IndentationError).
      - subprocess import returning non-zero exit (the stderr is
        included up to ~1500 chars).
    """
    if path.suffix != ".py":
        return None
    if os.environ.get("MASTER_AGENTS_DISABLE_SMOKE_CHECK") == "1":
        return None
    if not path.exists():
        return None

    # Phase 1 — syntax check via py_compile (cheap, ~1ms).
    try:
        py_compile.compile(str(path), doraise=True)
    except py_compile.PyCompileError as e:
        msg = str(e)[:_DIAGNOSTIC_MAX_CHARS]
        return f"SyntaxError in {path.name}: {msg}"

    # Phase 2 — import check via subprocess (catches runtime
    # import errors: NameError, ImportError, top-level execution
    # bugs). Two paths depending on whether the file is part of
    # a package:
    #   - In-package: `import <pkg>.<mod>` with PYTHONPATH set so
    #     the dotted import resolves. This supports relative
    #     imports inside the module.
    #   - Standalone: load via `importlib.util.spec_from_file_
    #     location` + `exec_module`. Doesn't support relative
    #     imports (file isn't a package member), but works for
    #     scripts and ad-hoc files.
    module_dotted, sys_path_entry = _compute_module_import_target(path)
    env = os.environ.copy()
    if module_dotted is not None and sys_path_entry is not None:
        cmd = [sys.executable, "-c", f"import {module_dotted}"]
        existing_pp = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = (
            f"{sys_path_entry}{os.pathsep}{existing_pp}"
            if existing_pp
            else str(sys_path_entry)
        )
        target_label = module_dotted
    else:
        # Standalone file — load directly via importlib.util.
        # Using a literal path string in the subprocess code
        # avoids escaping issues across platforms.
        cmd = [
            sys.executable,
            "-c",
            (
                "import importlib.util, sys\n"
                "spec = importlib.util.spec_from_file_location("
                "'_smoke', sys.argv[1])\n"
                "if spec is None or spec.loader is None:\n"
                "    sys.exit('cannot create spec')\n"
                "m = importlib.util.module_from_spec(spec)\n"
                "spec.loader.exec_module(m)\n"
            ),
            str(path),
        ]
        target_label = path.name
    # Suppress user-site so the subprocess sees only the
    # canonical interpreter + PYTHONPATH we set.
    env.setdefault("PYTHONNOUSERSITE", "1")

    try:
        proc = subprocess.run(  # noqa: S603 — sys.executable is trusted
            cmd,
            env=env,
            capture_output=True,
            text=True,
            timeout=_SUBPROCESS_TIMEOUT_S,
        )
    except subprocess.TimeoutExpired:
        # Module has a heavy import-time side effect or hangs.
        # Don't fail the edit on that — it's a different bug class.
        return None
    except OSError:
        # Couldn't spawn subprocess (e.g. no python in PATH).
        # Treat as "skip" rather than "fail".
        return None

    if proc.returncode == 0:
        return None

    stderr = (proc.stderr or "").strip()
    if not stderr:
        # Some uncommon failure modes return non-zero with no
        # stderr (e.g. SystemExit). Surface a minimal diag.
        return (
            f"Import of {target_label} failed (rc={proc.returncode}) "
            f"after writing {path.name}."
        )

    # Truncate the diagnostic so a multi-MB traceback doesn't
    # dominate the agent's tool result.
    if len(stderr) > _DIAGNOSTIC_MAX_CHARS:
        stderr = stderr[:_DIAGNOSTIC_MAX_CHARS] + "\n...[truncated]"

    return f"Import of {target_label} failed:\n{stderr}"


def _compute_module_import_target(
    path: Path,
) -> tuple[str | None, Path | None]:
    """Compute `(dotted_module, sys_path_entry)` for a `.py` file.

    Walks up while each parent has `__init__.py`. The last directory
    that has one IS the package root. Its parent is the entry that
    must be on `sys.path` for `import pkg.sub.mod` to resolve.

    Returns `(None, None)` if the file isn't part of a package
    (no sibling `__init__.py`) — caller should skip phase 2 in
    that case.
    """
    try:
        path = path.resolve()
    except OSError:
        return None, None

    parents = []  # accumulator: package directories above `path`
    current = path.parent
    while (current / "__init__.py").exists():
        parents.append(current.name)
        nxt = current.parent
        if nxt == current:
            break  # reached filesystem root
        current = nxt

    if not parents:
        # File isn't inside a package — `import` won't work
        # without specifying a path. Skip phase 2.
        return None, None

    parents.reverse()
    stem = path.stem
    if stem == "__init__":
        dotted = ".".join(parents)
    else:
        dotted = ".".join([*parents, stem])

    # `current` is now the parent of the topmost package dir.
    return dotted, current
