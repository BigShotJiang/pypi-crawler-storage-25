"""Built-in `browser_fetch` tool.

Playwright-backed headless browser fetch for JS-rendered pages where
`http_get` sees only script stubs.

Optional dependency — `playwright` is NOT in base `pyproject.toml`. Users
install via `pip install 'master-agents[browser]'` then run
`playwright install chromium` once to download the browser binary.

If either step is missing, the tool returns a clear error message rather
than crashing. Hard 30s ceiling regardless of input timeout.
"""

from __future__ import annotations

import asyncio

from .base import Tool

HARD_CEILING_MS = 30_000
DEFAULT_TIMEOUT_MS = 15_000
MAX_OUTPUT_CHARS = 100_000


def _playwright_status() -> tuple[bool, str]:
    """Return (available, message). `message` is the install hint on failure."""
    try:
        import playwright  # noqa: F401
    except ImportError:
        return False, (
            "browser_fetch: playwright not installed. "
            "Run `pip install 'master-agents[browser]'` to install."
        )
    try:
        from playwright.async_api import async_playwright  # noqa: F401
    except ImportError:
        return False, (
            "browser_fetch: playwright.async_api unavailable; "
            "reinstall playwright?"
        )
    return True, "ok"


async def _fetch_with_playwright(
    url: str,
    wait_for_selector: str | None,
    timeout_ms: int,
    return_text_only: bool,
) -> str:
    from playwright.async_api import (
        Error as PlaywrightError,
        TimeoutError as PlaywrightTimeoutError,
        async_playwright,
    )

    async with async_playwright() as p:
        try:
            browser = await p.chromium.launch(headless=True)
        except PlaywrightError as exc:
            msg = str(exc)
            if "Executable doesn't exist" in msg or "browser binary" in msg.lower():
                return (
                    "browser_fetch: chromium binary not installed. "
                    "Run `playwright install chromium` once to download it."
                )
            return f"browser_fetch: launch failed: {msg}"

        try:
            context = await browser.new_context()
            page = await context.new_page()
            try:
                await page.goto(url, timeout=timeout_ms, wait_until="networkidle")
            except PlaywrightTimeoutError:
                # Continue with partial load if networkidle takes too long;
                # better to return partial content than fail.
                pass
            except PlaywrightError as exc:
                return f"browser_fetch: navigation error: {exc}"

            if wait_for_selector:
                try:
                    await page.wait_for_selector(
                        wait_for_selector, timeout=timeout_ms,
                    )
                except PlaywrightTimeoutError:
                    return (
                        f"browser_fetch: selector {wait_for_selector!r} did "
                        f"not appear within {timeout_ms}ms"
                    )

            if return_text_only:
                content = await page.inner_text("body")
            else:
                content = await page.content()
        finally:
            await browser.close()

    if len(content) > MAX_OUTPUT_CHARS:
        content = content[:MAX_OUTPUT_CHARS] + "\n...[truncated]"
    return f"<untrusted_content>\n{content}\n</untrusted_content>"


async def _browser_fetch_handler(
    url: str,
    wait_for_selector: str | None = None,
    timeout_ms: int = DEFAULT_TIMEOUT_MS,
    return_text_only: bool = True,
) -> str:
    ok, msg = _playwright_status()
    if not ok:
        return msg

    effective_timeout = min(int(timeout_ms), HARD_CEILING_MS)
    try:
        return await asyncio.wait_for(
            _fetch_with_playwright(
                url=url,
                wait_for_selector=wait_for_selector,
                timeout_ms=effective_timeout,
                return_text_only=return_text_only,
            ),
            timeout=(HARD_CEILING_MS / 1000) + 5.0,  # outer belt-and-suspenders
        )
    except asyncio.TimeoutError:
        return f"browser_fetch: hard timeout ({HARD_CEILING_MS}ms) exceeded"
    except Exception as exc:
        return f"browser_fetch: {type(exc).__name__}: {exc}"


browser_fetch = Tool(
    name="browser_fetch",
    description=(
        "Fetch a URL using a headless Chromium browser (Playwright). Use when "
        "http_get returns a page that's mostly <script> tags (JS-rendered "
        "SPA). Returns inner text of <body> by default, or raw HTML if "
        "return_text_only=false. Requires `pip install 'master-agents[browser]'`"
        " and `playwright install chromium` one-time setup."
    ),
    input_schema={
        "type": "object",
        "required": ["url"],
        "properties": {
            "url": {
                "type": "string",
                "description": "Absolute URL to fetch.",
            },
            "wait_for_selector": {
                "type": "string",
                "description": (
                    "Optional CSS selector to wait for before extracting "
                    "content. Useful for SPAs where content loads after "
                    "initial page load."
                ),
            },
            "timeout_ms": {
                "type": "integer",
                "default": DEFAULT_TIMEOUT_MS,
                "description": "Per-step timeout. Capped at 30000ms.",
            },
            "return_text_only": {
                "type": "boolean",
                "default": True,
            },
        },
    },
    handler=_browser_fetch_handler,
    untrusted_output=True,
    channels=["cli"],
)
