"""Built-in `create_pptx_from_md` tool — Markdown → PPTX via Marp CLI.

Where this fits in the create-* family:
  - `create_pptx`          structured-spec, native python-pptx; pixel
                           control but limited visual polish
  - `create_pptx_from_md`  Markdown input → Marp CLI subprocess →
                           themed PPTX/PDF; gives "real designer
                           deck" output without us hand-designing
                           templates

Theme is one of Marp's built-ins (default, gaia, uncover) or a custom
CSS string the caller passes via `theme_css`. The tool defaults to
`gaia` because it produces the most "boardroom-friendly" output of the
shipped themes.

Marp dialect basics the agent should produce:
  ---
  marp: true
  theme: gaia
  size: 16:9
  ---
  # Title slide

  ---

  ## Section heading
  - bullet 1
  - bullet 2

  ---

  ![bg right](https://example.com/chart.png)
  # Slide with right-side image
  - Bullet content next to the image

The tool runs a single subprocess to `marp` (Node, ~3-10s per deck)
which spins up headless Chromium for layout. The container ships
Chromium + Marp CLI; PUPPETEER_EXECUTABLE_PATH is set in the
Dockerfile so Marp uses the system Chromium rather than re-downloading.
"""

from __future__ import annotations

import asyncio
import os
import shutil
import tempfile
from pathlib import Path

from .base import Tool
from ..themes import BUNDLED_THEMES, load_theme_css


# Marp's built-in themes (resolved by the CLI via `--theme`) plus our
# bundled custom CSS themes (loaded from disk and passed via `--theme-set`).
_BUILTIN_MARP_THEMES = ("default", "gaia", "uncover")
_BUNDLED_THEME_NAMES = tuple(BUNDLED_THEMES.keys())
_MARP_THEMES = _BUILTIN_MARP_THEMES + _BUNDLED_THEME_NAMES
_DEFAULT_THEME = "breakthrough"
_DEFAULT_TIMEOUT_S = 90.0  # Marp + Chromium cold-start can take 5-15s
_MAX_MARKDOWN_CHARS = 200_000


def _marp_executable() -> str | None:
    """Locate the Marp CLI binary — `marp` on PATH after `npm i -g`."""
    return shutil.which("marp")


async def _create_pptx_from_md_handler(
    content: str,
    theme: str = _DEFAULT_THEME,
    theme_css: str | None = None,
    path: str = "deck.pptx",
    paginate: bool = True,
    timeout_seconds: float = _DEFAULT_TIMEOUT_S,
) -> str:
    if not isinstance(content, str) or not content.strip():
        return "create_pptx_from_md: content must be non-empty markdown"
    if len(content) > _MAX_MARKDOWN_CHARS:
        return (
            f"create_pptx_from_md: content too large ({len(content)} chars; "
            f"max {_MAX_MARKDOWN_CHARS}). Split across multiple decks."
        )
    if theme not in _MARP_THEMES and not theme_css:
        return (
            f"create_pptx_from_md: theme {theme!r} unknown. "
            f"Use one of {_MARP_THEMES} or supply `theme_css`."
        )

    # If the caller named a bundled theme (e.g. 'breakthrough'), load
    # its CSS from disk and route through the `--theme-set` path so
    # Marp picks it up. The bundled CSS itself sets `@theme` so Marp
    # registers it; the caller didn't need to know the @theme name.
    if not theme_css and theme in _BUNDLED_THEME_NAMES:
        theme_css = load_theme_css(theme)

    # Resolve target via the per-session sandbox (web channel) or
    # working_dir (CLI). Same routing as the other create-* tools.
    from ._session_outputs import (
        download_url_for,
        resolve_create_target,
        session_id_var,
    )
    try:
        target, is_sandboxed = resolve_create_target(path)
    except ValueError as exc:
        return f"create_pptx_from_md: {exc}"
    if target.suffix.lower() != ".pptx":
        return f"create_pptx_from_md requires a .pptx path (got {path})"

    # ── Sidecar delegation (preferred path) ─────────────────────────
    # When `the designer service URL` is set on the API container,
    # delegate to the designer sidecar over HTTP and stop. The lite
    # API never needs Marp/Chromium locally — they live in the
    # sidecar image. The sidecar process itself MUST NOT have this
    # env set, or it would loop on itself; compose enforces that
    # asymmetry by exporting the var only on the api service.
    sidecar_url = os.environ.get("the designer service URL")
    if sidecar_url:
        err = await _delegate_pptx_to_sidecar(
            sidecar_url, content, theme, theme_css, paginate, target,
        )
        return _format_pptx_result(
            err, target, theme, is_sandboxed, session_id_var,
            download_url_for,
        )

    # ── Local Marp path ─────────────────────────────────────────────
    # Used by the designer sidecar service itself (no DESIGNER_URL on
    # its own container) and by direct CLI use on full-flavor images.
    # On lite-only images the marp binary is absent and we surface a
    # clean error pointing the user to start a sidecar.
    marp = _marp_executable()
    if marp is None:
        return (
            "create_pptx_from_md: `marp` binary not found, and no "
            "`the designer service URL` is configured. Either set "
            "the URL to a running designer sidecar, or run this on "
            "a full-flavor image with Marp installed."
        )

    # Write the markdown + optional theme CSS into a tempdir, then
    # invoke marp. We add the marp front-matter ONLY if the user
    # didn't include one — lets advanced callers control everything.
    md_body = content.lstrip()
    has_front_matter = md_body.startswith("---\n") or md_body.startswith("---\r\n")
    if not has_front_matter:
        # Always set `theme:` even when we're passing `--theme-set
        # custom.css` — Marp needs the theme name to *select* the
        # registered theme; without it, the CLI falls back to 'default'.
        front = [
            "---",
            "marp: true",
            f"theme: {theme}",
            "paginate: true" if paginate else "paginate: false",
            "size: 16:9",
            "---",
        ]
        md_body = "\n".join(front) + "\n\n" + md_body

    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        md_file = td_path / "deck.md"
        md_file.write_text(md_body, encoding="utf-8")

        argv = [
            marp,
            str(md_file),
            "--pptx",
            "--allow-local-files",
            "--output", str(target),
        ]
        if theme_css:
            css_file = td_path / "theme.css"
            css_file.write_text(theme_css, encoding="utf-8")
            argv.extend(["--theme-set", str(css_file)])

        env = dict(os.environ)
        # Chrome flags Marp passes to puppeteer — `--no-sandbox` is
        # required when running as non-root in a slim container.
        env.setdefault(
            "PUPPETEER_ARGS",
            "--no-sandbox --disable-setuid-sandbox --disable-dev-shm-usage",
        )

        try:
            proc = await asyncio.create_subprocess_exec(
                *argv,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
            stdout_b, stderr_b = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_seconds,
            )
        except asyncio.TimeoutError:
            return (
                f"create_pptx_from_md: marp timed out after "
                f"{timeout_seconds}s (Chromium cold-start is slow on "
                "first invocation; retry)"
            )
        except FileNotFoundError as exc:
            return f"create_pptx_from_md: failed to launch marp: {exc}"

        if proc.returncode != 0:
            err = stderr_b.decode("utf-8", errors="replace")[:600]
            return f"create_pptx_from_md: marp exit {proc.returncode}: {err}"
        if not target.exists() or target.stat().st_size == 0:
            return "create_pptx_from_md: marp completed but no output file"

    return _format_pptx_result(
        None, target, theme, is_sandboxed, session_id_var, download_url_for,
    )


def _format_pptx_result(
    error_msg: str | None,
    target: Path,
    theme: str,
    is_sandboxed: bool,
    session_id_var,
    download_url_for,
) -> str:
    """Shared success/error formatting for both local-Marp and sidecar
    paths. `error_msg` is None on success (target file exists)."""
    if error_msg is not None:
        return error_msg
    if not target.exists() or target.stat().st_size == 0:
        return "create_pptx_from_md: render completed but no output file"
    size = target.stat().st_size
    result = f"Wrote pptx (via Marp / theme={theme}): {target} ({size} bytes)"
    if is_sandboxed:
        sid = session_id_var.get()
        if sid is not None:
            result += f"\n\nDownload URL: {download_url_for(sid, target.name)}"
    return result


async def _delegate_pptx_to_sidecar(
    sidecar_url: str,
    content: str,
    theme: str,
    theme_css: str | None,
    paginate: bool,
    target: Path,
) -> str | None:
    """POST the markdown to the designer sidecar's /render-pptx-from-md
    endpoint, write the returned PPTX bytes to `target`. Returns:
      - None on success (caller formats success message)
      - error string if the sidecar is unreachable / returned non-200

    Returns None ALSO on success so the caller knows to format result.
    Errors short-circuit the local-Marp fallback (we don't want to
    silently produce dirty local output when the sidecar is the
    intended path but failed transiently).
    """
    import httpx
    headers: dict[str, str] = {}
    token = os.environ.get("the designer service token")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    body = {
        "content": content,
        "theme": theme,
        "paginate": paginate,
    }
    if theme_css is not None:
        body["theme_css"] = theme_css

    try:
        async with httpx.AsyncClient(timeout=120.0) as cli:
            resp = await cli.post(
                f"{sidecar_url.rstrip('/')}/render-pptx-from-md",
                json=body, headers=headers,
            )
    except httpx.ConnectError as exc:
        return (
            "create_pptx_from_md: designer sidecar unreachable at "
            f"{sidecar_url} ({exc}). Is the master-agents-designer "
            "container running? `docker compose -f docker-compose.yml "
            "-f docker-compose.local.yml -f docker-compose.designer.yml "
            "--profile designer up -d`."
        )
    except httpx.RequestError as exc:
        return f"create_pptx_from_md: designer sidecar transport error: {exc}"

    if resp.status_code != 200:
        snippet = resp.text[:500] if resp.text else f"status {resp.status_code}"
        return f"create_pptx_from_md: designer sidecar error: {snippet}"

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(resp.content)
    return None  # success — caller formats the success message


create_pptx_from_md = Tool(
    name="create_pptx_from_md",
    description=(
        "Render a Markdown source to a .pptx deck via Marp CLI. Marp\n"
        "produces visually-polished decks with built-in themes — best\n"
        "for presentation-quality output where pixel-precise layout\n"
        "isn't required. For exact spec-driven layout, use `create_pptx`\n"
        "instead.\n"
        "\n"
        "Marp markdown dialect (the agent should emit this directly):\n"
        "  ---\n"
        "  marp: true\n"
        "  theme: gaia        # or 'default' or 'uncover'\n"
        "  size: 16:9\n"
        "  paginate: true\n"
        "  ---\n"
        "  # Slide 1 title\n"
        "  Slide body content (markdown).\n"
        "  ---\n"
        "  ## Slide 2 heading\n"
        "  - bullet 1\n"
        "  - bullet 2\n"
        "  ---\n"
        "  ![bg right](https://example.com/img.png)\n"
        "  # Slide with image on the right side\n"
        "  Body text — Marp auto-positions the image.\n"
        "\n"
        "Image directives (Marp-specific):\n"
        "  ![bg](url)              full-bleed background\n"
        "  ![bg right](url)        right-half background\n"
        "  ![bg left:33%](url)     left third background\n"
        "  ![w:600px](url)         inline at fixed width\n"
        "\n"
        "Themes:\n"
        "  breakthrough  boardroom-grade — Newsreader serif headlines,\n"
        "                Inter body, accent stripes, .lead/.big/.quote/\n"
        "                .divider variants. Default.\n"
        "  gaia          modern, accent color highlights\n"
        "  default       neutral, white background\n"
        "  uncover       minimalist, large typography\n"
        "\n"
        "Custom CSS via `theme_css` overrides the built-in theme."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "content"],
        "properties": {
            "path": {
                "type": "string",
                "description": (
                    "Destination filename ending in .pptx. On web "
                    "channel must be a bare filename (no directories)."
                ),
            },
            "content": {
                "type": "string",
                "description": (
                    "Marp markdown source. If you don't include a "
                    "`---\\nmarp: true\\n...---` front-matter block, "
                    "the tool prepends a default one with `theme` + "
                    "`paginate: true` + `size: 16:9`."
                ),
            },
            "theme": {
                "type": "string",
                "enum": list(_MARP_THEMES),
                "description": (
                    "Marp theme: 'breakthrough' (default — boardroom-"
                    "grade), 'gaia', 'default', 'uncover'."
                ),
                "default": _DEFAULT_THEME,
            },
            "theme_css": {
                "type": "string",
                "description": (
                    "Optional custom CSS — overrides the built-in "
                    "theme. Useful for brand colors / fonts."
                ),
            },
            "paginate": {
                "type": "boolean",
                "description": "Show slide numbers in footer. Default true.",
                "default": True,
            },
        },
    },
    handler=_create_pptx_from_md_handler,
    requires_approval=True,
    channels=["cli", "web"],
    tier="premium",
)
