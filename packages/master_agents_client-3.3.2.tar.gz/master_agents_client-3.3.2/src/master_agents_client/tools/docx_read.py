"""Built-in `docx_read` tool — extract structured text from a .docx file.

Preserves heading levels (as markdown `#` / `##` / ...), renders tables as
pipe-delimited rows with a separator, renders bulleted and numbered list
items with a leading `-`, and marks inline images with `[image]`. Best-effort
list detection — files from non-Word sources may sometimes render as plain
paragraphs; see the design doc for details.
"""

from __future__ import annotations

from pathlib import Path

from .base import Tool

MAX_CHARS = 50_000


def _paragraph_style_name(paragraph) -> str:
    try:
        style = paragraph.style
        if style is None:
            return ""
        return (style.name or "").lower()
    except Exception:
        return ""


def _is_list_paragraph(paragraph) -> bool:
    style_name = _paragraph_style_name(paragraph)
    if "list" in style_name and (
        "bullet" in style_name or "number" in style_name
    ):
        return True
    # Fallback: inspect numbering-properties element directly. Docs authored
    # in LibreOffice or Google Docs often don't use the named list styles.
    try:
        pPr = paragraph._p.pPr
        if pPr is not None and pPr.numPr is not None:
            return True
    except AttributeError:
        pass
    return False


def _heading_level(paragraph) -> int | None:
    """Return N for a `Heading N` style, else None."""
    style_name = _paragraph_style_name(paragraph)
    if not style_name.startswith("heading "):
        return None
    try:
        level = int(style_name.split(" ", 1)[1])
    except (IndexError, ValueError):
        return None
    return max(1, min(6, level))


def _paragraph_has_image(paragraph) -> bool:
    """Detect inline images by looking for drawing/pict descendants."""
    try:
        element = paragraph._p
        # Use xpath-ish lookup through the underlying lxml element
        for child in element.iter():
            tag = child.tag
            if isinstance(tag, str) and (tag.endswith("}drawing") or tag.endswith("}pict")):
                return True
    except Exception:
        pass
    return False


def _render_table(table) -> list[str]:
    """Render a docx table as markdown-style pipe rows."""
    rows: list[list[str]] = []
    for row in table.rows:
        cells = [cell.text.replace("\n", " ").strip() for cell in row.cells]
        rows.append(cells)
    if not rows:
        return []
    width = max(len(r) for r in rows)
    # Pad short rows
    rows = [r + [""] * (width - len(r)) for r in rows]
    lines = [f"| {' | '.join(rows[0])} |"]
    lines.append("| " + " | ".join(["---"] * width) + " |")
    for row in rows[1:]:
        lines.append(f"| {' | '.join(row)} |")
    return lines


def _iter_body_blocks(doc):
    """Walk paragraphs AND tables in document order.

    python-docx exposes `doc.paragraphs` and `doc.tables` as flat lists and
    loses their interleaved order. Walk the underlying XML body to get the
    real order.
    """
    from docx.oxml.ns import qn
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    body = doc.element.body
    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, doc)
        elif child.tag == qn("w:tbl"):
            yield Table(child, doc)


async def _docx_read_handler(path: str, max_chars: int = MAX_CHARS) -> str:
    p = Path(path)
    if not p.exists():
        return f"Path does not exist: {path}"
    if not p.is_file():
        return f"Not a file: {path}"
    if p.suffix.lower() != ".docx":
        return f"Not a DOCX file: {path}"

    try:
        from docx import Document
        from docx.table import Table
        from docx.text.paragraph import Paragraph
    except ImportError:  # pragma: no cover
        return "python-docx is not installed."

    try:
        doc = Document(str(p))
    except Exception as e:
        return f"Failed to read DOCX: {type(e).__name__}: {e}"

    lines: list[str] = []
    for block in _iter_body_blocks(doc):
        if isinstance(block, Paragraph):
            if _paragraph_has_image(block):
                lines.append("[image]")
                # Some image paragraphs also have text — render that below.
                if block.text.strip():
                    lines.append(block.text)
                continue
            text = block.text
            heading_level = _heading_level(block)
            if heading_level is not None and text.strip():
                lines.append(f"{'#' * heading_level} {text}")
            elif _is_list_paragraph(block) and text.strip():
                lines.append(f"- {text}")
            else:
                lines.append(text)
        elif isinstance(block, Table):
            lines.extend(_render_table(block))

    # Collapse consecutive blank lines but keep intentional paragraph spacing
    cleaned: list[str] = []
    prev_blank = False
    for line in lines:
        is_blank = not line.strip()
        if is_blank and prev_blank:
            continue
        cleaned.append(line)
        prev_blank = is_blank

    output = "\n".join(cleaned).strip()
    if len(output) > max_chars:
        output = output[:max_chars] + "\n...[truncated]"
    return output


docx_read = Tool(
    name="docx_read",
    description=(
        "Read a .docx (Microsoft Word) file and return its text with "
        "structure preserved: headings as markdown `#`/`##`, tables as "
        "pipe-delimited rows, bulleted and numbered list items with `-`, "
        "inline images marked `[image]`. Use for corporate reports, "
        "contracts, structured documents."
    ),
    input_schema={
        "type": "object",
        "required": ["path"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to a .docx file.",
            },
            "max_chars": {
                "type": "integer",
                "description": (
                    f"Hard cap on returned length (default {MAX_CHARS}). "
                    "Content is truncated with a [truncated] marker."
                ),
                "default": MAX_CHARS,
            },
        },
    },
    handler=_docx_read_handler,
    untrusted_output=True,
    channels=["cli"],
)
