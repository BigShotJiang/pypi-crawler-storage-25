"""Built-in `git` tool —   expansion +  branch guard.

Restricted git command execution. ONE tool with allowlisted subcommands:
- Read: status, log, diff, show, blame
- Write (approval required): add, commit, restore,
  branch, checkout, merge, push, pull, fetch, stash, tag  branch guard:
  Direct commits to `main` / `master` are refused. Agents must
  `git_write checkout -b feat/<scope>` first. Per-session override
  available via `allow_main_commits_var` (slash command:
  /allow-main-commits on/off). The guard fires inside run_git just
  before subprocess.exec so it catches every code path.

Safety:
- Per-subcommand flag reject-lists :
    commit -a/-A/--amend
    add -A/--all/-i
    restore without --staged
    branch -D / -M / --force / --delete --force
    checkout --force / -B / --orphan
    merge --abort / -X
    push --force / -f / --force-with-lease / --delete / --mirror
    pull --force / -f
    fetch --force / -f
    stash clear / drop --all
    tag -d / -f / --delete / --force
- Sanitized subprocess env : no GIT_* env vars passthrough.
- Global flag rejection: `-c`, `-C`, `--exec-path`, `--git-dir`,
  `--work-tree`, `--namespace`, `--super-prefix`, `--literal-pathspecs`.
- Session-bound cwd; 30s timeout; output truncated at 10_000 chars.
- : push/pull/fetch ALLOWED in safe form (no --force, no --delete);
  GIT_TERMINAL_PROMPT=0 still set so a credentials prompt can't hang.

Instances of this tool are built via Session._make_git_tool(spec); the bare
`git` Tool in BUILTINS is a template for MCP schema generation and is NOT
directly callable against a repo.
"""

from __future__ import annotations

import asyncio
import os
import shutil
from pathlib import Path


from .base import Tool


def _resolve_cwd() -> Path:
    """Plain-handler git fallback for cwd. Bound from session.working_dir
    when available, else process cwd."""
    from ._session_cwd import session_cwd_var
    return session_cwd_var.get() or Path.cwd()

READ_SUBCOMMANDS = frozenset({"status", "log", "diff", "show", "blame"})
WRITE_SUBCOMMANDS = frozenset({
    "add", "commit", "restore",
    # daily co-coding ops (replace per-call bash fallbacks).
    "branch", "checkout", "merge", "push", "pull", "fetch", "stash", "tag",
})
ALLOWED_SUBCOMMANDS = READ_SUBCOMMANDS | WRITE_SUBCOMMANDS

# Global flags that can change git's invocation target; always rejected.
_GLOBAL_REJECT_FLAGS = frozenset({
    "-c", "-C",
    "--exec-path", "--git-dir", "--work-tree", "--namespace",
    "--super-prefix", "--literal-pathspecs",
})

# Per-subcommand reject-lists for write ops .
# Conventions:
#   - For each subcommand we list flags that are destructive, force a
#     bypass of safety, or rewrite history. The agent can ALWAYS do
#     these via the bash fallback — but with explicit user approval.
#   - We list the long form AND the common short form. We do NOT try
#     to canonicalize (e.g. -fX → -f); that would be a parser. Each
#     individual token is checked.
_PER_SUBCOMMAND_REJECTS: dict[str, frozenset[str]] = {
    "commit": frozenset({"-a", "--all", "--amend", "--allow-empty", "--no-verify"}),
    "add": frozenset({"-A", "--all", "-i", "--interactive", "-p", "--patch"}),
    # restore handled specially — requires `--staged`
    #  expansion below.
    "branch": frozenset({
        "-D",                     # force-delete (loses unmerged commits)
        "-M",                     # force-rename (overrides existing branch)
        "-f", "--force",          # general force flag (--copy/--move accept it)
    }),
    "checkout": frozenset({
        "-f", "--force",          # discards uncommitted working-tree edits
        "-B",                     # force-create-or-reset branch
        "--orphan",               # creates parent-less branch (niche, easy to misuse)
    }),
    "merge": frozenset({
        "--abort",                # discards in-progress merge state
        "-X",                     # silently picks a side ("theirs"/"ours")
        "-f", "--force",
    }),
    "push": frozenset({
        "-f", "--force",          # rewrites remote history
        "--force-with-lease",     # safer but still a force-push
        "-d", "--delete",         # removes remote branches
        "--mirror",               # full-replace: refuses no force-pushes
        "--prune",                # removes refs not in source
    }),
    "pull": frozenset({
        "-f", "--force",
    }),
    "fetch": frozenset({
        "-f", "--force",
    }),
    "stash": frozenset({
        "clear",                  # discards ALL stashes
    }),
    "tag": frozenset({
        "-d", "--delete",         # removes a tag (worse on published tags)
        "-f", "--force",          # overwrites an existing tag
    }),
}

MAX_OUTPUT_CHARS = 10_000
DEFAULT_TIMEOUT_SECONDS = 30.0

# branches the commit guard refuses. Re-exported from
# branch_guard for convenience and so tests can pin against it.
from .branch_guard import (
    _BRANCH_GUARD_BRANCHES,
    allow_main_commits_var,
    block_commit_message,
    is_main_branch,
)


def _check_branch_for_commit(
    branch: str | None, *, allow_override: bool,
) -> str | None:
    """ pure-string check: given a (possibly-detected) branch name
    and the override flag, return a block-reason message or None.

    None = proceed. Non-None = block; the message is what gets
    returned to the agent in lieu of running git commit.

    Empty / None branch → None (don't refuse on detection failure;
    only refuse when we KNOW we're on main).
    """
    if not branch:
        return None
    if not is_main_branch(branch):
        return None
    if allow_override:
        return None
    return block_commit_message(branch.lower())


async def _detect_current_branch(cwd: Path) -> str | None:
    """Run `git rev-parse --abbrev-ref HEAD` and return the branch
    name as a string (e.g. "main", "feat/auth"), or None if detection
    fails (no git, not a repo, detached HEAD, etc.)."""
    git_exe = shutil.which("git")
    if git_exe is None:
        return None
    try:
        proc = await asyncio.create_subprocess_exec(
            git_exe, "rev-parse", "--abbrev-ref", "HEAD",
            cwd=str(cwd),
            env=_sanitized_env(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5.0)
    except (asyncio.TimeoutError, OSError):
        return None
    if proc.returncode != 0:
        return None
    branch = stdout.decode("utf-8", errors="replace").strip()
    # `HEAD` (literal) means detached HEAD → not a branch we can name.
    if branch == "HEAD" or not branch:
        return None
    return branch


def _check_args(subcommand: str, args: list[str]) -> str | None:
    """Return an error string if args are rejected; None if clean."""
    if subcommand not in ALLOWED_SUBCOMMANDS:
        return (
            f"git: subcommand {subcommand!r} not allowed. "
            f"Allowed: {sorted(ALLOWED_SUBCOMMANDS)}"
        )
    for arg in args:
        if not isinstance(arg, str):
            return f"git: non-string arg {arg!r}"
        # Reject global flags anywhere in the args — including the
        # `--flag=value` form (exact-string match would miss these).
        if arg in _GLOBAL_REJECT_FLAGS:
            return f"git: flag {arg!r} is rejected for safety"
        if any(arg.startswith(f + "=") for f in _GLOBAL_REJECT_FLAGS):
            return f"git: flag {arg!r} is rejected for safety"
        # Reject shell metachars (extra defense; we don't shell-invoke anyway).
        if any(ch in arg for ch in ";&|`$\n\r"):
            return f"git: shell metachar in arg {arg!r}"
    per_subcommand = _PER_SUBCOMMAND_REJECTS.get(subcommand, frozenset())
    for arg in args:
        if arg in per_subcommand:
            return (
                f"git {subcommand}: flag {arg!r} is rejected (bypasses the "
                "intended approval boundary)"
            )
    # `restore` requires `--staged` in v1.
    if subcommand == "restore":
        if "--staged" not in args:
            return (
                "git restore: only --staged form is allowed in v1 (bare "
                "restore destroys uncommitted working-tree edits)"
            )
    #  special case: `git stash drop --all` blows away every stash. The
    # `--all` token alone is harmless (it's only meaningful here), so we
    # don't put it in the per-subcommand reject-list — we catch the combo.
    if subcommand == "stash" and len(args) >= 2:
        if args[0] == "drop" and "--all" in args[1:]:
            return (
                "git stash: 'drop --all' is rejected (discards every "
                "stash; route through bash if truly intended)"
            )
    return None


def _sanitized_env() -> dict[str, str]:
    """Allow-listed environment for the git subprocess."""
    env: dict[str, str] = {
        "LANG": "C",
        "LC_ALL": "C",
        # Defense-in-depth: GIT_TERMINAL_PROMPT=0 prevents the subprocess
        # from hanging on a credential prompt.  enables push/pull/fetch,
        # which CAN need credentials — when they do, the subprocess errors
        # out cleanly instead of blocking. Users authenticate once via
        # `git config credential.helper`, ssh keys, or `gh auth login`
        # outside the framework; we don't act as a credential broker.
        "GIT_TERMINAL_PROMPT": "0",
    }
    for key in ("PATH", "HOME", "USERPROFILE", "SystemRoot", "Windir"):
        if key in os.environ:
            env[key] = os.environ[key]
    return env


def _truncate(text: str) -> str:
    if len(text) <= MAX_OUTPUT_CHARS:
        return text
    return text[:MAX_OUTPUT_CHARS] + "\n...[truncated]"


async def run_git(
    *,
    subcommand: str,
    args: list[str],
    cwd: Path,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
) -> str:
    """Execute a restricted git subcommand. Returns output text or error string."""
    check = _check_args(subcommand, args)
    if check is not None:
        return check

    git_exe = shutil.which("git")
    if git_exe is None:
        return "git: 'git' executable not found on PATH"

    cwd_path = Path(cwd).resolve()
    if not (cwd_path / ".git").exists() and not _has_parent_git(cwd_path):
        return f"git: {cwd_path} is not inside a git repository"

    # feat-branch-only commit guard. Detect current branch BEFORE
    # commit subprocess fires; refuse if on main/master without override.
    if subcommand == "commit":
        current_branch = await _detect_current_branch(cwd_path)
        block = _check_branch_for_commit(
            current_branch,
            allow_override=allow_main_commits_var.get(),
        )
        if block is not None:
            return block

    cmd = [git_exe, subcommand, *args]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=str(cwd_path),
            env=_sanitized_env(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except Exception as exc:
        return f"git: failed to launch: {type(exc).__name__}: {exc}"

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=timeout_seconds,
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        return f"git: {subcommand} timed out after {timeout_seconds} seconds"

    out = stdout.decode("utf-8", errors="replace")
    err = stderr.decode("utf-8", errors="replace")
    if proc.returncode != 0:
        msg = err.strip() or out.strip() or f"exit code {proc.returncode}"
        return f"git {subcommand} failed: {_truncate(msg)}"
    return _truncate(out.strip() or err.strip() or "(no output)")


def _has_parent_git(path: Path) -> bool:
    for parent in path.parents:
        if (parent / ".git").exists():
            return True
    return False


async def _plain_git_read_handler(
    subcommand: str,
    args: list[str] | None = None,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
) -> str:
    if subcommand not in READ_SUBCOMMANDS:
        return (
            f"git_read: subcommand {subcommand!r} not a read op. "
            f"Use git_write for {sorted(WRITE_SUBCOMMANDS)}."
        )
    return await run_git(
        subcommand=subcommand,
        args=list(args or []),
        cwd=_resolve_cwd(),
        timeout_seconds=timeout_seconds,
    )


async def _plain_git_write_handler(
    subcommand: str,
    args: list[str] | None = None,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
) -> str:
    if subcommand not in WRITE_SUBCOMMANDS:
        return (
            f"git_write: subcommand {subcommand!r} not a write op. "
            f"Use git_read for {sorted(READ_SUBCOMMANDS)}."
        )
    return await run_git(
        subcommand=subcommand,
        args=list(args or []),
        cwd=_resolve_cwd(),
        timeout_seconds=timeout_seconds,
    )


git_read = Tool(
    name="git_read",
    description=(
        "Run a read-only git subcommand (status, log, diff, show, blame) in "
        "the session's working directory. No approval required. Global flags "
        "-c/-C/--git-dir/--work-tree/--exec-path are rejected."
    ),
    input_schema={
        "type": "object",
        "required": ["subcommand"],
        "properties": {
            "subcommand": {
                "type": "string",
                "enum": sorted(READ_SUBCOMMANDS),
            },
            "args": {
                "type": "array",
                "items": {"type": "string"},
                "default": [],
            },
            "timeout_seconds": {
                "type": "number",
                "default": DEFAULT_TIMEOUT_SECONDS,
            },
        },
    },
    handler=_plain_git_read_handler,
    requires_approval=False,
    untrusted_output=True,
    channels=["cli"],
)


git_write = Tool(
    name="git_write",
    description=(
        "Run a write git subcommand in the session's working directory. "
        "APPROVAL REQUIRED. Subcommands: add, commit, restore --staged "
        "(local), branch, checkout, merge, stash, tag (local), "
        "push, pull, fetch (remote). Force flags rejected: "
        "commit -a/--amend, add -A/-i, branch -D/-M/--force, "
        "checkout --force/-B/--orphan, merge --abort/-X, push --force/"
        "--force-with-lease/--delete/--mirror/--prune, pull/fetch --force, "
        "tag -d/-f, stash clear / drop --all. Credential prompts are "
        "disabled — authenticate via git's credential helper, SSH keys, "
        "or `gh auth login` outside the framework."
    ),
    input_schema={
        "type": "object",
        "required": ["subcommand"],
        "properties": {
            "subcommand": {
                "type": "string",
                "enum": sorted(WRITE_SUBCOMMANDS),
            },
            "args": {
                "type": "array",
                "items": {"type": "string"},
                "default": [],
            },
            "timeout_seconds": {
                "type": "number",
                "default": DEFAULT_TIMEOUT_SECONDS,
            },
        },
    },
    handler=_plain_git_write_handler,
    requires_approval=True,
    untrusted_output=True,
    channels=["cli"],
)
