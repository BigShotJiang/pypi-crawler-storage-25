"""Session-aware cwd context for path-resolving tools.

Tools like `read_file`, `file_grep`, `estimate_tokens`, `bash`,
`apply_patch` accept relative paths from the agent. Without context,
those paths resolve against the *process* cwd — which is whatever
directory the agents server happened to be started from. Users running
the framework on their own machines hit broken reads when their cwd
doesn't match the project root.

This module exposes an asyncio-safe context variable that `Session`
binds to its `working_dir` on entry to a turn. Path-resolving tools
use `resolve_under_session_cwd(path)` instead of `Path(path).resolve()`.

Behaviour:
  - Absolute paths on CLI channel: returned as-is (resolved).
  - Absolute paths on web/office channel: rejected (PermissionError)
    UNLESS the resolved path falls inside the session cwd. This is
    the Security F1 (audit 2026-05-12) hardening: web-channel agents
    previously could `read_file("/etc/passwd")` because absolute
    paths passed through unchecked.
  - Relative paths with a session cwd bound: resolved against it.
  - Relative paths with no session cwd (legacy / standalone use):
    fall back to process cwd, matching the pre-fix behavior so
    existing scripts don't break.

`asyncio.Task` copies contextvars on spawn, so the binding propagates
through the entire tool-call chain of one turn without manual
threading.
"""

from __future__ import annotations

import contextvars
from pathlib import Path

session_cwd_var: contextvars.ContextVar[Path | None] = contextvars.ContextVar(
    "session_cwd", default=None,
)


# Channels where absolute paths outside the session cwd are denied.
# CLI is the user's own machine — they can already cat /etc/passwd
# themselves, the bridge ships path-touching tools to their machine
# anyway, so no incremental security gain from confinement.
_CONFINED_CHANNELS = frozenset({"web", "office"})


def resolve_under_session_cwd(
    path: str | Path,
    *,
    allow_outside_cwd: bool = False,
) -> Path:
    """Resolve `path` to an absolute Path. Relative inputs use the
    active session's working_dir when set; otherwise fall back to the
    process cwd (legacy behavior).

    Args:
        path: Path string or Path object.
        allow_outside_cwd: When True, web/office sessions may pass
            absolute paths outside the session cwd. Reserved for
            tools that legitimately need to reach mounted corpora
            outside the cwd (none today). Callers should document
            the rationale at the call site.

    Raises:
        PermissionError: web/office session passed an absolute path
            resolving outside the session cwd, and `allow_outside_cwd`
            is False. PermissionError extends OSError so existing
            handlers that catch OSError pick it up and surface it
            as a normal "error" string to the agent (no exception
            propagation up the tool loop).
    """
    p = Path(path)
    if p.is_absolute():
        resolved = p.resolve()
        if allow_outside_cwd:
            return resolved
        # Channel-aware confinement: web/office must stay inside the
        # session cwd. The contextvar is set by the session lifecycle
        # via `client_channel_var` in `_session_outputs.py`.
        try:
            from ._session_outputs import client_channel_var
            channel = client_channel_var.get()
        except ImportError:  # pragma: no cover - circular-import defense
            channel = None
        if channel in _CONFINED_CHANNELS:
            cwd = session_cwd_var.get()
            if cwd is None:
                raise PermissionError(
                    f"absolute path {resolved} not permitted on "
                    f"{channel!r} sessions without a session cwd"
                )
            try:
                resolved.relative_to(cwd.resolve())
            except ValueError:
                raise PermissionError(
                    f"absolute path {resolved} is outside the session "
                    f"cwd {cwd}; {channel!r} sessions are confined to "
                    f"their cwd / notebook mount (Security F1)"
                )
        return resolved
    cwd = session_cwd_var.get()
    if cwd is not None:
        return (cwd / p).resolve()
    return p.resolve()
