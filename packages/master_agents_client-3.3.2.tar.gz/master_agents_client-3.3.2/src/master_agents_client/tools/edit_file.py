"""Built-in `edit_file` tool — anchor-based unique-match replacement.

Matches Claude Code's Edit tool semantics intentionally: given `old_string`
+ `new_string`, find a unique match and replace it. If ambiguous (>=2
matches), return a structured error asking for a longer anchor. Callers
use this for precise code-modification workflows; agents pair it with
`read_file` / `file_grep` to locate the right anchor before editing.
"""

from __future__ import annotations

from pathlib import Path

from .base import Tool


def _looks_binary(path: Path) -> bool:
    try:
        with path.open("rb") as fh:
            head = fh.read(1024)
        return b"\x00" in head
    except OSError:
        return True


def _detect_newline_bytes(raw: bytes) -> str:
    """Detect the file's dominant line-ending from raw bytes.

    Must work on the on-disk bytes, not decoded text — Python's text-mode
    read normalizes CRLF → LF silently, hiding the original.
    """
    if b"\r\n" in raw:
        return "\r\n"
    if b"\r" in raw:
        return "\r"
    return "\n"


async def _edit_file_handler(
    path: str,
    old_string: str,
    new_string: str,
    replace_all: bool = False,
) -> str:
    import sys
    from .._self_host import is_self_hosted_repo, self_hosted_warning_for
    from ._session_cwd import resolve_under_session_cwd
    from ._session_file_state import check_can_edit, record_read
    p = resolve_under_session_cwd(path)
    # self-hosted load-bearing warning. Compute relative path
    # to the repo root so `is_load_bearing` matches the canonical
    # form. Only fire when we're inside a master_agents_os checkout.
    cwd = resolve_under_session_cwd(".")
    if is_self_hosted_repo(cwd):
        try:
            rel = p.resolve().relative_to(cwd.resolve())
            warning = self_hosted_warning_for(rel.as_posix())
        except ValueError:
            warning = None
        if warning:
            sys.stderr.write(warning + "\n")
            sys.stderr.flush()
    if not p.exists():
        return f"Path does not exist: {path}"
    if not p.is_file():
        return f"Not a file: {path}"
    if _looks_binary(p):
        return f"Refusing to edit binary file: {path}"
    rejection = check_can_edit(p)
    if rejection is not None:
        return rejection
    if not old_string:
        # Guard: `"abc".replace("", "X") == "XaXbXcX"` — an empty anchor with
        # replace_all=True would interleave new_string between every character
        # and destroy the file.
        return "edit_file: old_string must not be empty"
    if old_string == new_string:
        return "edit_file: old_string equals new_string — no change requested"

    try:
        raw_bytes = p.read_bytes()
    except OSError as e:
        return f"Failed to read {path}: {type(e).__name__}: {e}"

    original_newline = _detect_newline_bytes(raw_bytes)
    try:
        raw = raw_bytes.decode("utf-8")
    except UnicodeDecodeError as e:
        return f"Failed to decode {path} as UTF-8: {e}"

    # Normalize both sides to LF for matching — handles the common case of a
    # CRLF file + LF-emitted anchor from the LLM.
    normalized = raw.replace("\r\n", "\n").replace("\r", "\n")
    normalized_old = old_string.replace("\r\n", "\n").replace("\r", "\n")
    normalized_new = new_string.replace("\r\n", "\n").replace("\r", "\n")

    count = normalized.count(normalized_old)
    if count == 0:
        return (
            f"edit_file: old_string not found in {path}. "
            "If the file uses non-LF line endings, ensure old_string "
            "matches exactly (the tool already normalizes CRLF/CR → LF)."
        )
    if count >= 2 and not replace_all:
        return (
            f"edit_file: old_string matched {count} times in {path}. "
            "Provide a longer anchor that uniquely identifies the location, "
            "or set replace_all=true to replace every occurrence."
        )

    if replace_all:
        updated = normalized.replace(normalized_old, normalized_new)
    else:
        updated = normalized.replace(normalized_old, normalized_new, 1)

    # Restore the file's original line-ending convention on write
    if original_newline != "\n":
        updated = updated.replace("\n", original_newline)

    # Atomic write — see _session_file_state.atomic_write_bytes for
    # rationale. Direct `write_bytes` would truncate-then-write, and a
    # kill mid-write would corrupt the file (D2 resume hash mismatch).
    from ._session_file_state import atomic_write_bytes
    try:
        atomic_write_bytes(p, updated.encode("utf-8"))
    except OSError as e:
        return f"Failed to write {path}: {type(e).__name__}: {e}"

    # post-edit smoke-import check. For Python source we run
    # `py_compile` + a subprocess `import <module>` so NameError /
    # SyntaxError / ImportError caught at write time, not at first
    # use. On failure the file is reverted to `raw_bytes`.
    from ._python_smoke_check import python_smoke_check
    smoke_diag = python_smoke_check(p)
    if smoke_diag is not None:
        try:
            atomic_write_bytes(p, raw_bytes)
        except OSError as e:
            return (
                f"edit_file: smoke check FAILED for {path} and revert "
                f"ALSO failed ({type(e).__name__}: {e}). File is in an "
                f"inconsistent state on disk. Smoke check said:\n{smoke_diag}"
            )
        return (
            f"edit_file: smoke check failed; reverted {path} to pre-edit "
            f"contents. Fix the issue and retry. Diagnostic:\n{smoke_diag}"
        )

    # Refresh the recorded mtime so consecutive edits in this task
    # don't trip the externally-modified gate on our own write.
    record_read(p)

    return (
        f"Edited {path}: {count} replacement(s) "
        f"({len(old_string)} → {len(new_string)} chars each)"
    )


edit_file = Tool(
    name="edit_file",
    description=(
        "Replace an exact substring (old_string) with new text (new_string) "
        "in a single text file. The anchor must be unique unless replace_all=true. "
        "If old_string matches zero or multiple times, the tool returns a clear "
        "error so you can widen the anchor. Use for targeted code edits; pair "
        "with read_file or file_grep to locate the right anchor first. "
        "CRLF line endings on disk are handled transparently."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "old_string", "new_string"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to the text file to edit.",
            },
            "old_string": {
                "type": "string",
                "description": (
                    "Exact substring to find and replace. Must match uniquely "
                    "unless replace_all=true."
                ),
            },
            "new_string": {
                "type": "string",
                "description": "Replacement text.",
            },
            "replace_all": {
                "type": "boolean",
                "description": (
                    "If true, replace every occurrence of old_string. "
                    "If false (default), requires exactly one match."
                ),
                "default": False,
            },
        },
    },
    handler=_edit_file_handler,
    requires_approval=True,
    channels=["cli"],
)
