"""Client-side stub of _session_outputs.

The full canonical module on the server runs the per-session sandbox
for web-channel uploads (signing, quotas, sweep). On the client none
of that is reachable: tools always write under the user's
session_cwd. This file exposes only the public symbols other client
modules import — `validate_filename`, the context-var declarations,
and the CLI fallback in `resolve_create_target`.
"""

from __future__ import annotations

import contextvars
import re
from pathlib import Path

from ._session_cwd import session_cwd_var


# ── Context variables ────────────────────────────────────────────────

outputs_dir_var: contextvars.ContextVar[Path | None] = contextvars.ContextVar(
    "outputs_dir", default=None,
)
client_channel_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "client_channel", default=None,
)
session_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "session_id", default=None,
)


# ── Filename validation ──────────────────────────────────────────────

_VALID_FILENAME_RE = re.compile(r"^[A-Za-z0-9_\- ]+(?:\.[A-Za-z0-9_\-]{1,16})?$")


def validate_filename(name: str) -> str:
    """Return a cleaned filename or raise ValueError on unsafe input."""
    if not isinstance(name, str) or not name.strip():
        raise ValueError("filename must be a non-empty string")
    cleaned = name.strip()
    if "/" in cleaned or "\\" in cleaned:
        raise ValueError(f"filename must not contain path separators: {name!r}")
    if cleaned.startswith(".") or cleaned == "..":
        raise ValueError(f"filename must not start with '.': {name!r}")
    if ".." in cleaned:
        raise ValueError(f"filename must not contain '..': {name!r}")
    if not _VALID_FILENAME_RE.match(cleaned):
        raise ValueError(
            f"filename must be alphanumeric / dot / underscore / dash / "
            f"space, with at most one extension: {name!r}"
        )
    if len(cleaned) > 120:
        raise ValueError(f"filename too long (max 120 chars): {name!r}")
    return cleaned


# ── Resolution (CLI only) ────────────────────────────────────────────

def is_web_channel() -> bool:
    """Always False on the client wheel — clients have no sandbox."""
    return False


def session_outputs_dir() -> Path | None:
    return None


def resolve_create_target(filename_or_path: str) -> tuple[Path, bool]:
    """Resolve where a `create_*` tool should write its output.

    Always returns ``(absolute_path, False)`` — the client wheel has no
    sandbox. The path is resolved against the bound session_cwd if
    relative; otherwise used as-is.
    """
    p = Path(filename_or_path)
    if p.is_absolute():
        return (p.resolve(), False)
    cwd = session_cwd_var.get()
    if cwd is not None:
        return ((cwd / p).resolve(), False)
    return (p.resolve(), False)
