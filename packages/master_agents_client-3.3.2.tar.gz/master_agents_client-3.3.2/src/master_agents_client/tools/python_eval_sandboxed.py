"""Built-in `python_eval_sandboxed` tool.

Docker-based isolation for LLM-emitted code. Real process/network/filesystem/
memory isolation via `docker run --network=none --read-only --user nobody
--cap-drop=ALL ...`.

Env var `MASTER_AGENTS_DOCKER_CMD` (default "docker") controls the docker
invocation. Windows dev workstations where Docker runs inside WSL set it to
"wsl -- docker". Validated against an allow-list at handler entry.

Amendments from  spec review:
- A1: `docker run -i` is required to pipe stdin into the container.
- A2: Each container gets a unique `--name`; on host timeout, issue
  `docker kill <name>` before returning.
- A3: `MASTER_AGENTS_DOCKER_CMD` first token restricted to {docker, wsl,
  podman}; reject `-H` / `--host` / `DOCKER_HOST` to prevent remote-daemon
  redirection.
- A11: `requires_approval=False` — the sandbox IS the approval.
"""

from __future__ import annotations

import asyncio
import json
import os
import shlex
import uuid
from textwrap import dedent

from .base import Tool

MAX_OUTPUT_CHARS = 50_000
DEFAULT_TIMEOUT_SECONDS = 30.0
DEFAULT_MEMORY_MB = 512
DEFAULT_CPUS = 1.0
_SANDBOX_IMAGE = "python:3.13-slim"
_DOCKER_CMD_ALLOWLIST = frozenset({"docker", "wsl", "podman"})
_DOCKER_CMD_REJECT_TOKENS = frozenset({"-H", "--host", "DOCKER_HOST"})

_WRAPPER = dedent("""
    import json
    import sys

    inputs = json.load(sys.stdin)
    namespace = {"inputs": inputs, "__name__": "__main__"}
    code = sys.argv[1]
    exec(compile(code, "<python_eval_sandboxed>", "exec"), namespace, namespace)

    if namespace.get("result") is not None:
        value = namespace["result"]
        try:
            print(json.dumps(value, ensure_ascii=False))
        except TypeError:
            # Non-JSON-serializable result — emit a structured envelope so the
            # caller can tell what happened instead of silently getting repr().
            print(json.dumps({
                "_repr": str(value),
                "_type": type(value).__name__,
                "_note": "non-JSON-serializable result; envelope contains str() only.",
            }, ensure_ascii=False))
""").strip()


def _resolve_docker_cmd() -> tuple[list[str] | None, str | None]:
    """Parse MASTER_AGENTS_DOCKER_CMD. Returns (argv_prefix, error).

    Uses shlex.split so quoted arguments with embedded whitespace survive
    (e.g. `wsl -d "Ubuntu 22.04" -- docker`). Allowlist/rejects run after.
    """
    raw = os.environ.get("MASTER_AGENTS_DOCKER_CMD", "docker").strip()
    try:
        tokens = shlex.split(raw, posix=True)
    except ValueError as exc:
        return None, f"MASTER_AGENTS_DOCKER_CMD parse error: {exc}"
    if not tokens:
        return None, "MASTER_AGENTS_DOCKER_CMD is empty"
    first = tokens[0]
    if first not in _DOCKER_CMD_ALLOWLIST:
        return None, (
            f"Refusing to use non-allowlisted docker command: {first!r}. "
            f"Allowed: {sorted(_DOCKER_CMD_ALLOWLIST)}"
        )
    for t in tokens:
        if t in _DOCKER_CMD_REJECT_TOKENS:
            return None, (
                f"Refusing to use MASTER_AGENTS_DOCKER_CMD containing {t!r}: "
                "remote-daemon redirection is not allowed in sandboxed mode."
            )
        if t.startswith("-H=") or t.startswith("--host="):
            return None, (
                f"Refusing to use MASTER_AGENTS_DOCKER_CMD containing {t!r}."
            )
        # Short-option form without space or equals: `-Htcp://remote:2375`.
        if t.startswith("-H") and t != "-H" and len(t) > 2:
            return None, (
                f"Refusing to use MASTER_AGENTS_DOCKER_CMD containing {t!r}."
            )
    return tokens, None


_DEFAULT_PROBE_TIMEOUT = 5.0


def _probe_timeout() -> float:
    """Probe timeout in seconds. Overridable via MASTER_AGENTS_DOCKER_PROBE_TIMEOUT
    for cold-start-prone environments (e.g. WSL, where the first `wsl -- docker
    --version` after idle can take 10-15s)."""
    raw = os.environ.get("MASTER_AGENTS_DOCKER_PROBE_TIMEOUT")
    if not raw:
        return _DEFAULT_PROBE_TIMEOUT
    try:
        v = float(raw)
    except ValueError:
        return _DEFAULT_PROBE_TIMEOUT
    return v if v > 0 else _DEFAULT_PROBE_TIMEOUT


async def _probe_docker_available(docker_argv: list[str]) -> tuple[bool, str]:
    """Run `{docker_cmd} --version` and return (available, error_msg)."""
    try:
        proc = await asyncio.create_subprocess_exec(
            *docker_argv, "--version",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError:
        return False, (
            "python_eval_sandboxed requires Docker. Install Docker Desktop "
            "(Windows/macOS) or docker-ce (Linux). If Docker is only "
            "available via WSL, set `MASTER_AGENTS_DOCKER_CMD=\"wsl -- docker\"`."
        )
    except Exception as exc:
        return False, f"docker probe launch failed: {type(exc).__name__}: {exc}"
    timeout = _probe_timeout()
    try:
        _stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        return False, (
            f"docker probe timed out after {timeout}s — is the daemon running? "
            f"Override via MASTER_AGENTS_DOCKER_PROBE_TIMEOUT=<seconds>."
        )
    if proc.returncode != 0:
        err = stderr.decode("utf-8", errors="replace").strip()
        return False, f"docker probe failed: {err or 'non-zero exit'}"
    return True, ""


def _build_run_argv(
    *,
    docker_argv: list[str],
    container_name: str,
    image: str,
    memory_mb: int,
    cpus: float,
    allow_network: bool,
    code: str,
) -> list[str]:
    argv = [*docker_argv, "run", "--rm", "-i"]
    argv += ["--name", container_name]
    if not allow_network:
        argv += ["--network=none"]
    argv += [
        f"--memory={memory_mb}m",
        f"--cpus={cpus}",
        "--read-only",
        "--tmpfs", "/tmp:size=64m",
        "--tmpfs", "/work:size=64m",
        "--workdir", "/work",
        "--user", "65534:65534",
        "--cap-drop=ALL",
        "--security-opt=no-new-privileges",
        image,
        "python", "-c", _WRAPPER, code,
    ]
    return argv


async def _kill_container(docker_argv: list[str], name: str) -> None:
    try:
        proc = await asyncio.create_subprocess_exec(
            *docker_argv, "kill", name,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        try:
            await asyncio.wait_for(proc.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
    except Exception:  # pragma: no cover - best effort
        pass


async def _python_eval_sandboxed_handler(
    code: str,
    inputs: dict | None = None,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    memory_mb: int = DEFAULT_MEMORY_MB,
    cpus: float = DEFAULT_CPUS,
    allow_network: bool = False,
) -> str:
    docker_argv, err = _resolve_docker_cmd()
    if err:
        return f"python_eval_sandboxed error: {err}"

    ok, probe_err = await _probe_docker_available(docker_argv)
    if not ok:
        return f"python_eval_sandboxed error: {probe_err}"

    container_name = f"master-agents-sbx-{uuid.uuid4().hex[:8]}"
    run_argv = _build_run_argv(
        docker_argv=docker_argv,
        container_name=container_name,
        image=_SANDBOX_IMAGE,
        memory_mb=memory_mb,
        cpus=cpus,
        allow_network=allow_network,
        code=code,
    )

    try:
        proc = await asyncio.create_subprocess_exec(
            *run_argv,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except Exception as exc:
        return f"python_eval_sandboxed: launch failed: {type(exc).__name__}: {exc}"

    payload = json.dumps(inputs or {}).encode("utf-8")
    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(payload), timeout=timeout_seconds,
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        # Killing the docker client does NOT stop the container; issue
        # docker kill <name> to enforce the wall-clock ceiling.
        await _kill_container(docker_argv, container_name)
        return (
            f"python_eval_sandboxed timed out after {timeout_seconds} "
            f"seconds; container {container_name} killed."
        )

    out = stdout.decode("utf-8", errors="replace").strip()
    err_text = stderr.decode("utf-8", errors="replace").strip()
    if proc.returncode != 0:
        msg = err_text or out or f"exit {proc.returncode}"
        if len(msg) > MAX_OUTPUT_CHARS:
            msg = msg[:MAX_OUTPUT_CHARS] + "\n...[truncated]"
        return f"python_eval_sandboxed error: {msg}"
    text = out or err_text or "(no output)"
    if len(text) > MAX_OUTPUT_CHARS:
        text = text[:MAX_OUTPUT_CHARS] + "\n...[truncated]"
    return text


python_eval_sandboxed = Tool(
    name="python_eval_sandboxed",
    description=(
        "Run a short Python program in an isolated Docker container. "
        "No network, read-only filesystem (with tmpfs /tmp and /work), "
        "nobody:nogroup user, all capabilities dropped. This tool runs "
        "in a network-isolated, read-only container — it CANNOT access "
        "files on the host. Pass data inline via the `inputs` JSON object "
        "on stdin; write results to stdout. Set `allow_network=True` to "
        "drop --network=none (defeats a major part of the sandbox). "
        "Requires Docker: set MASTER_AGENTS_DOCKER_CMD=\"wsl -- docker\" "
        "on Windows hosts where Docker is in WSL."
    ),
    input_schema={
        "type": "object",
        "required": ["code"],
        "properties": {
            "code": {
                "type": "string",
                "description": "Python source code to execute.",
            },
            "inputs": {
                "type": "object",
                "description": "Optional JSON object exposed as `inputs`.",
                "default": {},
            },
            "timeout_seconds": {
                "type": "number",
                "default": DEFAULT_TIMEOUT_SECONDS,
            },
            "memory_mb": {
                "type": "integer",
                "default": DEFAULT_MEMORY_MB,
            },
            "cpus": {
                "type": "number",
                "default": DEFAULT_CPUS,
            },
            "allow_network": {
                "type": "boolean",
                "default": False,
                "description": (
                    "If true, drop --network=none. WARNING: defeats a core "
                    "part of the sandbox against exfiltration."
                ),
            },
        },
    },
    handler=_python_eval_sandboxed_handler,
    requires_approval=False,  # the sandbox IS the approval channels=["cli"],
)
