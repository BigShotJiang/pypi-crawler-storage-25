"""Built-in `calc` tool — symbolic math via sympy in a fresh subprocess.

 . The subprocess pattern is the abort mechanism — sympy is not
cancellable in-process, so we isolate evaluation in a subprocess and use
asyncio.wait_for + proc.kill to enforce timeouts.

Modes:
- evaluate: numeric value (preserves symbolic constants like pi/e)
- simplify: simplified symbolic form
- solve: solve "{equation}:{variable}" for the variable; returns the solution set
"""

from __future__ import annotations

import asyncio
import sys
from textwrap import dedent

from .base import Tool

MAX_EXPRESSION_CHARS = 2000
DEFAULT_TIMEOUT_SECONDS = 5.0


_SUBPROCESS_RUNNER = dedent("""
    import json
    import sys

    expression = sys.argv[1]
    mode = sys.argv[2]

    try:
        from sympy import sympify, simplify, solve, Eq, symbols, sin, cos, tan, exp, log, sqrt, pi, E, I  # noqa: F401
        from sympy.parsing.sympy_parser import parse_expr
    except ImportError as exc:
        print(json.dumps({"error": f"sympy not installed: {exc}"}))
        sys.exit(1)

    try:
        if mode == "evaluate":
            expr = parse_expr(expression)
            try:
                evaluated = expr.evalf()
                # Prefer simple numeric output when no free symbols remain.
                if not expr.free_symbols:
                    print(json.dumps({"result": str(evaluated)}))
                else:
                    print(json.dumps({"result": str(expr)}))
            except Exception:
                print(json.dumps({"result": str(expr)}))
        elif mode == "simplify":
            expr = parse_expr(expression)
            print(json.dumps({"result": str(simplify(expr))}))
        elif mode == "solve":
            if ":" not in expression:
                print(json.dumps({
                    "error": "solve mode requires 'equation:variable' format "
                             "(e.g. 'x**2 - 4 = 0:x')"
                }))
                sys.exit(2)
            eq_text, var_text = expression.rsplit(":", 1)
            var = symbols(var_text.strip())
            if "=" in eq_text:
                lhs_text, rhs_text = eq_text.split("=", 1)
                eq = Eq(parse_expr(lhs_text), parse_expr(rhs_text))
            else:
                eq = parse_expr(eq_text)
            solutions = solve(eq, var)
            print(json.dumps({"result": str(solutions)}))
        else:
            print(json.dumps({"error": f"unknown mode {mode!r}"}))
            sys.exit(2)
    except Exception as exc:
        print(json.dumps({"error": f"{type(exc).__name__}: {exc}"}))
        sys.exit(3)
""").strip()


async def _calc_handler(
    expression: str,
    mode: str = "evaluate",
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
) -> str:
    if not isinstance(expression, str) or not expression.strip():
        return "error: expression must be a non-empty string"
    if len(expression) > MAX_EXPRESSION_CHARS:
        return (
            f"error: expression length {len(expression)} exceeds cap "
            f"{MAX_EXPRESSION_CHARS}"
        )
    if mode not in ("evaluate", "simplify", "solve"):
        return f"error: unknown mode {mode!r}; use evaluate | simplify | solve"

    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable,
            "-I",
            "-c",
            _SUBPROCESS_RUNNER,
            expression,
            mode,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except Exception as exc:
        return f"error: failed to launch subprocess: {type(exc).__name__}: {exc}"

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=timeout_seconds,
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        return f"error: calc timed out after {timeout_seconds} seconds"

    out = stdout.decode("utf-8", errors="replace").strip()
    err = stderr.decode("utf-8", errors="replace").strip()

    import json
    if out:
        try:
            payload = json.loads(out)
            if "error" in payload:
                return f"error: {payload['error']}"
            return str(payload.get("result", ""))
        except json.JSONDecodeError:
            return f"error: malformed subprocess output: {out!r}"
    if err:
        return f"error: {err}"
    return "error: no output"


calc = Tool(
    name="calc",
    description=(
        "Symbolic math via sympy. Modes: 'evaluate' (numeric value, preserves "
        "pi/e/etc.), 'simplify' (simplified symbolic form), 'solve' (solve "
        "'equation:variable' e.g. 'x**2 - 4 = 0:x' for the variable). "
        "Cheaper and more deterministic than python_eval for pure math."
    ),
    input_schema={
        "type": "object",
        "required": ["expression"],
        "properties": {
            "expression": {
                "type": "string",
                "description": (
                    "Math expression. For 'solve' mode use 'equation:variable' "
                    "e.g. 'x**2 - 4 = 0:x'. The LAST ':' in the string is the "
                    "separator (rsplit). Equations that legitimately contain "
                    "a colon should place the variable after the final one — "
                    "e.g. 'Piecewise((0, x<0:x), (1, True)):x'. Max 2000 chars."
                ),
            },
            "mode": {
                "type": "string",
                "enum": ["evaluate", "simplify", "solve"],
                "default": "evaluate",
            },
            "timeout_seconds": {
                "type": "number",
                "default": DEFAULT_TIMEOUT_SECONDS,
            },
        },
    },
    handler=_calc_handler,
    requires_approval=False,
    channels=["cli", "web"],
)
