"""Built-in `csv_read` tool — structured extraction from CSV files."""

from __future__ import annotations

import csv
from pathlib import Path

from .base import Tool


async def _csv_read_handler(
    path: str,
    max_rows: int = 100,
    columns: list[str] | None = None,
    delimiter: str = ",",
    has_header: bool = True,
    encoding: str = "utf-8-sig",
    max_chars: int = 50_000,
) -> str:
    p = Path(path)
    if not p.exists():
        return f"Path does not exist: {path}"
    if not p.is_file():
        return f"Not a file: {path}"

    try:
        with p.open("r", encoding=encoding, newline="") as fh:
            if has_header:
                reader = csv.DictReader(fh, delimiter=delimiter)
                header = list(reader.fieldnames or [])
                if columns is not None:
                    missing = [c for c in columns if c not in header]
                    if missing:
                        return (
                            f"csv_read: requested column(s) not in header: {missing}. "
                            f"Available: {header}"
                        )
                    output_columns = columns
                else:
                    output_columns = header
                rows: list[list[str]] = []
                truncated = False
                for i, row in enumerate(reader):
                    if i >= max_rows:
                        truncated = True
                        break
                    rows.append([_render(row.get(c, "")) for c in output_columns])
            else:
                reader_iter = csv.reader(fh, delimiter=delimiter)
                all_rows = list(reader_iter)
                if columns:
                    return (
                        "csv_read: `columns` requires has_header=True — "
                        "column selection needs a named header row."
                    )
                output_columns = [f"col{i}" for i in range(len(all_rows[0]) if all_rows else 0)]
                truncated = len(all_rows) > max_rows
                rows = [[_render(c) for c in r] for r in all_rows[:max_rows]]
    except UnicodeDecodeError as exc:
        return (
            f"csv_read: decode error ({exc}). "
            f"Try passing encoding='latin-1' or encoding='cp1252' / 'gbk' for non-UTF-8 files."
        )
    except OSError as exc:
        return f"csv_read: {type(exc).__name__}: {exc}"

    metadata = f"path={p.name} | {len(rows)} row(s)"
    if truncated:
        metadata += f" [truncated at max_rows={max_rows}]"
    lines = [metadata, " | ".join(output_columns)]
    for row in rows:
        lines.append(" | ".join(row))
    out = "\n".join(lines)
    if len(out) > max_chars:
        out = out[:max_chars] + "\n[truncated]"
    return out


def _render(value) -> str:
    if value is None:
        return ""
    return str(value)


csv_read = Tool(
    name="csv_read",
    description=(
        "Read rows from a CSV file and return a pipe-delimited extract. "
        "Default encoding is utf-8-sig (handles BOM-prefixed Excel exports). "
        "For non-UTF-8 files pass encoding='latin-1' / 'cp1252' / 'gbk' etc. "
        "Optional `columns` restricts output to named columns. Use for "
        "structured-data lookup; pair with read_file for small free-form files."
    ),
    input_schema={
        "type": "object",
        "required": ["path"],
        "properties": {
            "path": {"type": "string", "description": "Path to a CSV file."},
            "max_rows": {
                "type": "integer",
                "description": "Cap on returned rows (default 100).",
                "default": 100,
            },
            "columns": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional list of column names to return (requires has_header=true).",
            },
            "delimiter": {
                "type": "string",
                "description": "Field delimiter (default ','). Use '\\t' for TSV.",
                "default": ",",
            },
            "has_header": {
                "type": "boolean",
                "description": "Whether the first row is column headers (default true).",
                "default": True,
            },
            "encoding": {
                "type": "string",
                "description": "File encoding (default 'utf-8-sig'). Use 'latin-1' / 'cp1252' / 'gbk' for non-UTF-8.",
                "default": "utf-8-sig",
            },
        },
    },
    handler=_csv_read_handler,
    untrusted_output=True,
    channels=["cli"],
)
