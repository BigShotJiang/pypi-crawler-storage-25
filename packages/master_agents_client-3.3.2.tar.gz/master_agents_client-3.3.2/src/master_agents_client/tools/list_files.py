"""Built-in `list_files` tool — list filenames in a directory.

Cross-platform replacement for the `bash dir /b` and `bash ls`
incantations agents have been failing on. Uses Python's pathlib
directly, so:
  - Windows paths like `C:\\Users\\X` work natively (no WSL
    path-translation, no cmd.exe escaping).
  - POSIX paths work the same as native ls.
  - When routed client-side via tool inversion, the listing happens
    on the CLIENT'S filesystem, not the server's.

This tool does the listing job that bash was being misused for. Most
agents reading a directory + summarising should use list_files +
read_file in parallel — no shell needed.
"""

from fnmatch import fnmatch
from pathlib import Path

from ._session_cwd import resolve_under_session_cwd
from .base import Tool

# Cap so an accidental list of /usr or C:\ doesn't return a 50k-line
# blob. Truncation marker is appended when this fires.
MAX_FILES = 500


async def _list_files_handler(
    path: str,
    pattern: str | None = None,
    recursive: bool = False,
    include_dirs: bool = False,
) -> str:
    p = resolve_under_session_cwd(path)
    if not p.exists():
        return f"Path does not exist: {path}"
    if not p.is_dir():
        return (
            f"Not a directory: {path} "
            "(use read_file for files, file_grep for content search)"
        )

    try:
        if recursive:
            iter_ = p.rglob(pattern or "*") if pattern else p.rglob("*")
        else:
            iter_ = p.iterdir()
    except OSError as e:
        return f"List error on {path}: {e}"

    entries: list[str] = []
    for child in iter_:
        try:
            is_file = child.is_file()
            is_dir = child.is_dir()
        except OSError:
            continue
        if not include_dirs and is_dir:
            continue
        if pattern and not recursive:
            if not fnmatch(child.name, pattern):
                continue
        # Render relative to the requested path so the agent gets short
        # readable names regardless of how deep it asked.
        try:
            rel = child.relative_to(p)
            display = str(rel) if str(rel) else child.name
        except ValueError:
            display = child.name
        # Suffix dirs with "/" so the agent can tell at a glance.
        if is_dir:
            display = display + "/"
        entries.append(display)

    if not entries:
        if pattern:
            return f"(no entries matching {pattern!r} under {path})"
        return f"(empty directory: {path})"

    entries.sort()
    truncated = ""
    if len(entries) > MAX_FILES:
        truncated = (
            f"\n...[truncated — {len(entries) - MAX_FILES} more entries; "
            f"narrow with `pattern` or `recursive=false`]"
        )
        entries = entries[:MAX_FILES]
    return "\n".join(entries) + truncated


list_files = Tool(
    name="list_files",
    description=(
        "List filenames in a directory. Cross-platform — works with "
        "Windows paths (C:\\X\\Y), POSIX paths (/x/y), or relative "
        "paths. Prefer this over `bash dir /b` or `bash ls` for "
        "directory listing; no shell, no path translation, no quoting "
        "issues. By default returns files only (not subdirectories) — "
        "set include_dirs=true to include them. Cap "
        f"{MAX_FILES} entries; narrow with pattern (e.g. '*.md') or "
        "recursive=false."
    ),
    input_schema={
        "type": "object",
        "required": ["path"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Directory path. Absolute or relative to session cwd.",
            },
            "pattern": {
                "type": "string",
                "description": (
                    "Optional glob pattern (e.g. '*.md', 'test_*.py'). "
                    "Filters by filename, not path. Omit to list all."
                ),
            },
            "recursive": {
                "type": "boolean",
                "description": (
                    "Recurse into subdirectories. Default false."
                ),
                "default": False,
            },
            "include_dirs": {
                "type": "boolean",
                "description": (
                    "Include subdirectory names (suffixed '/') in the "
                    "output. Default false (files only)."
                ),
                "default": False,
            },
        },
    },
    handler=_list_files_handler,
    channels=["cli", "web"],
)
