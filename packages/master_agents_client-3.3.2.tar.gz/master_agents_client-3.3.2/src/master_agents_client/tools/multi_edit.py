"""Built-in `multi_edit` tool — atomic batched single-file replacements .

Why a separate tool from `edit_file`:
- `edit_file` is one anchor-replace per call. Three edits in one file = three
  reads, three writes, three round-trips.
- `multi_edit` accepts a list of (old, new) pairs against a single file and
  applies them ATOMICALLY: validate every anchor first, then apply all in
  one write. If any anchor is ambiguous or missing, ZERO writes happen.

Atomicity guarantees (in order of check):
1. Each `old` string appears at least once in the original file content.
2. Each `old` string appears EXACTLY once (no ambiguity — caller must provide
   a longer anchor if a substring matches multiple times). Override with
   `replace_all=True` per edit.
3. Mutual non-interference: applying edits sequentially against the running
   buffer must not lose any anchor. If edit N's `old` no longer appears in
   the running buffer (because edit M earlier removed or rewrote it), that's
   an interference error.

If any check fails: NOTHING is written; the tool returns a structured error
naming which edit failed and why. The caller (planner / agent) then
reorders or refines the edits and tries again.
"""

from __future__ import annotations

import difflib
from pathlib import Path
from typing import Any

from .base import Tool


def _closest_substring_hint(content: str, target: str, max_lines: int = 8) -> str:
    """Return a short hint showing the closest contiguous substring in
    `content` to `target`, formatted as a unified diff.

    Used to enrich "old not found" errors so the calling LLM can see
    what's actually in the file vs what it proposed. Targets multi-line
    anchors (typical `old` values are 3–10 lines).

    Returns "" when `content` or `target` is too small to compare or
    when no plausible match is found (similarity below cutoff).
    """
    if not content.strip() or not target.strip():
        return ""
    target_lines = target.splitlines()
    if not target_lines:
        return ""
    content_lines = content.splitlines()
    n_target = len(target_lines)
    if n_target == 0 or n_target > len(content_lines):
        return ""

    # Slide a window of len(target_lines) across content; pick the
    # window with highest SequenceMatcher ratio against target.
    sm = difflib.SequenceMatcher(autojunk=False)
    sm.set_seq1(target_lines)
    best_ratio = 0.0
    best_start = -1
    for start in range(len(content_lines) - n_target + 1):
        sm.set_seq2(content_lines[start : start + n_target])
        r = sm.ratio()
        if r > best_ratio:
            best_ratio = r
            best_start = start
    if best_start < 0 or best_ratio < 0.4:
        return ""  # no plausible match — better to say nothing than mislead

    closest = content_lines[best_start : best_start + n_target]
    diff_lines = list(
        difflib.unified_diff(
            target_lines,
            closest,
            fromfile="your `old`",
            tofile=f"actual file (lines {best_start + 1}–{best_start + n_target})",
            n=0,
            lineterm="",
        )
    )
    if not diff_lines:
        return ""
    # Cap diff length to avoid blowing up the prompt
    diff_lines = diff_lines[: max_lines + 4]  # +4 for diff headers
    return "\n".join(diff_lines)


def _looks_binary(path: Path) -> bool:
    try:
        with path.open("rb") as fh:
            head = fh.read(1024)
        return b"\x00" in head
    except OSError:
        return True


def _detect_newline_bytes(raw: bytes) -> str:
    if b"\r\n" in raw:
        return "\r\n"
    if b"\r" in raw:
        return "\r"
    return "\n"


def _validate_edits(content: str, edits: list[dict[str, Any]]) -> str | None:
    """Return None if all edits validate; else an error string.

    Validation walks the edits in order against a running buffer so we
    catch mutual interference (edit M rewrites what edit N anchored to).
    """
    buffer = content
    for i, e in enumerate(edits, start=1):
        old = e.get("old", "")
        new = e.get("new", "")
        replace_all = bool(e.get("replace_all", False))
        if not isinstance(old, str) or not isinstance(new, str):
            return f"edit #{i}: old/new must be strings"
        if not old:
            # Same trap as edit_file's guard.
            return f"edit #{i}: old must not be empty"
        if old == new:
            return f"edit #{i}: old equals new — no change"

        count = buffer.count(old)
        if count == 0:
            base_msg = (
                f"edit #{i}: old not found in file (after {i - 1} prior edits "
                "applied to the running buffer — interference?)"
            )
            # G-FB enrichment: surface the closest matching substring in
            # the running buffer as a unified diff. Tells the calling
            # LLM exactly what's in the file vs what it proposed,
            # without requiring it to re-read the whole file. Empty
            # string when no plausible match — diff would mislead more
            # than help.
            hint = _closest_substring_hint(buffer, old)
            if hint:
                return base_msg + "\n\nClosest match in the file:\n" + hint
            return base_msg
        if count > 1 and not replace_all:
            return (
                f"edit #{i}: old matches {count} times — provide a longer "
                "anchor or set replace_all: true on this edit"
            )
        if replace_all:
            buffer = buffer.replace(old, new)
        else:
            buffer = buffer.replace(old, new, 1)
    return None


def _apply_edits(content: str, edits: list[dict[str, Any]]) -> str:
    """Apply edits sequentially. Caller must have validated first."""
    buffer = content
    for e in edits:
        if e.get("replace_all"):
            buffer = buffer.replace(e["old"], e["new"])
        else:
            buffer = buffer.replace(e["old"], e["new"], 1)
    return buffer


async def _multi_edit_handler(path: str, edits: list[dict[str, Any]]) -> str:
    if not isinstance(edits, list) or not edits:
        return "multi_edit: edits must be a non-empty list"

    from ._session_cwd import resolve_under_session_cwd
    from ._session_file_state import check_can_edit, record_read
    p = resolve_under_session_cwd(path)
    if not p.exists():
        return f"multi_edit: path does not exist: {path}"
    if not p.is_file():
        return f"multi_edit: not a file: {path}"
    if _looks_binary(p):
        return f"multi_edit: refusing to edit binary file: {path}"

    # A4-new: stale-content gate. Mirrors edit_file.py — file-state
    # tracking (Phase 1.1) was wired into edit_file but NOT multi_edit,
    # leaving the coder pipeline's primary edit tool with no protection
    # against editing a file that was modified externally between the
    # last read and this edit. With this gate, re-running coder_cli on
    # the same plan no longer risks applying anchors against a
    # half-modified buffer; the gate fails loudly instead of producing
    # silent corruption.
    rejection = check_can_edit(p)
    if rejection is not None:
        return f"multi_edit: {rejection}"

    try:
        raw = p.read_bytes()
    except OSError as exc:
        return f"multi_edit: read failed: {exc}"

    newline = _detect_newline_bytes(raw)
    # Normalise all line endings to \n internally so anchor matching is
    # consistent regardless of the file's on-disk convention. We restore
    # the original convention before writing.
    text = raw.decode("utf-8", errors="replace")
    content = text.replace("\r\n", "\n").replace("\r", "\n")

    err = _validate_edits(content, edits)
    if err is not None:
        return f"multi_edit: validation failed — no changes written. {err}"

    new_content = _apply_edits(content, edits)
    if new_content == content:
        return "multi_edit: no changes (all edits were no-ops?)"

    # Restore the original line-ending convention on the way out.
    if newline == "\n":
        out_bytes = new_content.encode("utf-8")
    else:
        out_bytes = new_content.replace("\n", newline).encode("utf-8")

    try:
        p.write_bytes(out_bytes)
    except OSError as exc:
        return f"multi_edit: write failed: {exc}"

    # Refresh the recorded mtime so consecutive multi_edits in this
    # session don't trip the gate on our own write.
    record_read(p)

    return f"multi_edit: applied {len(edits)} edit(s) to {path} ({len(out_bytes)} bytes)"


multi_edit = Tool(
    name="multi_edit",
    description=(
        "Apply multiple anchor-based replacements to a single file ATOMICALLY. "
        "Validates every anchor first; if any is missing, ambiguous, or would "
        "be invalidated by a prior edit in this batch, NO writes happen and a "
        "structured error is returned. Use this instead of multiple edit_file "
        "calls when you have several edits in one file — it's one round-trip "
        "and guarantees no half-applied state. For multi-file changes, use "
        "apply_patch."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "edits"],
        "properties": {
            "path": {
                "type": "string",
                "description": "File to edit.",
            },
            "edits": {
                "type": "array",
                "minItems": 1,
                "description": "Ordered list of replacements to apply.",
                "items": {
                    "type": "object",
                    "required": ["old", "new"],
                    "properties": {
                        "old": {
                            "type": "string",
                            "description": (
                                "Exact substring to find. Must match exactly "
                                "once unless replace_all is true."
                            ),
                        },
                        "new": {
                            "type": "string",
                            "description": "Replacement text.",
                        },
                        "replace_all": {
                            "type": "boolean",
                            "default": False,
                            "description": (
                                "If true, replace every occurrence of old. "
                                "Otherwise old must match exactly once."
                            ),
                        },
                    },
                },
            },
        },
    },
    handler=_multi_edit_handler,
    requires_approval=True,
    channels=["cli"],
)
