"""Built-in `create_md` tool — write a Markdown file.

Mirrors the `create_pdf/docx/xlsx/pptx` family: dual-channel (CLI +
web), sandbox-resolved when on web, returns a download URL when the
file lands in the per-session sandbox.

Markdown is the simplest of the create-* family — input is just text,
no rendering pipeline. Useful for: meeting notes, reports the user
wants to keep editable, exported chat summaries, generated docs that
will be rendered by another tool downstream.
"""

from __future__ import annotations

from .base import Tool


_DEFAULT_MAX_CHARS = 500_000


async def _create_md_handler(
    path: str,
    content: str,
    max_chars: int = _DEFAULT_MAX_CHARS,
) -> str:
    if not isinstance(content, str):
        return "create_md: content must be a string"
    if len(content) > max_chars:
        return (
            f"create_md: content too large ({len(content)} chars, "
            f"max {max_chars}). Split into multiple files."
        )

    from ._session_outputs import (
        download_url_for,
        resolve_create_target,
        session_id_var,
    )
    try:
        target, is_sandboxed = resolve_create_target(path)
    except ValueError as exc:
        return f"create_md: {exc}"
    if target.suffix.lower() not in (".md", ".markdown"):
        return f"create_md requires a .md or .markdown path (got {path})"

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    except OSError as exc:
        return f"create_md: {type(exc).__name__}: {exc}"

    size = target.stat().st_size
    result = f"Wrote markdown: {target} ({size} bytes, {len(content)} chars)"
    if is_sandboxed:
        sid = session_id_var.get()
        if sid is not None:
            result += f"\n\nDownload URL: {download_url_for(sid, target.name)}"
    return result


create_md = Tool(
    name="create_md",
    description=(
        "Write a Markdown (.md) file. Pass `content` as the full file "
        "body — headings, lists, code fences, tables all valid. "
        "On the web channel the file lands in a per-session sandbox "
        "and a download URL is returned in the result. On CLI the file "
        "writes to the user's working directory at the given path."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "content"],
        "properties": {
            "path": {
                "type": "string",
                "description": (
                    "Destination filename ending in .md or .markdown. "
                    "On web, must be a bare filename (no directories)."
                ),
            },
            "content": {
                "type": "string",
                "description": "The full Markdown body to write.",
            },
            "max_chars": {
                "type": "integer",
                "description": (
                    f"Hard cap on content length. Default {_DEFAULT_MAX_CHARS}."
                ),
                "default": _DEFAULT_MAX_CHARS,
            },
        },
    },
    handler=_create_md_handler,
    requires_approval=True,
    channels=["cli", "web"],
)
