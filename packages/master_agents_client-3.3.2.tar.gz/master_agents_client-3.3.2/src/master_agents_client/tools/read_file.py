"""Built-in `read_file` tool — read a single text file's contents.

Complement to `file_grep`: where `file_grep` tells you WHERE in a corpus
a term appears, `read_file` returns the full content of a specific file
so an agent can answer based on the whole thing.
"""

from pathlib import Path

from ._session_cwd import resolve_under_session_cwd
from ._session_file_state import record_read
from .base import Tool

MAX_CHARS = 50_000


def _looks_binary(path: Path) -> bool:
    try:
        with path.open("rb") as fh:
            head = fh.read(1024)
        return b"\x00" in head
    except OSError:
        return True


async def _read_file_handler(
    path: str,
    max_chars: int = MAX_CHARS,
    offset: int = 0,
) -> str:
    """Read a text file, optionally skipping the first `offset` LINES.

     added the `offset` kwarg. LLM training prior universally
    uses paginated-read semantics — `tail -n +N`, Python slicing
    on file lines, every IDE's "go to line" — but the original
    schema had no such kwarg. Run 2 of the live mao refactor test
    (2026-05-03) hit `TypeError: _read_file_handler got an
    unexpected keyword argument 'offset'` on the first attempt to
    page through the service beyond the first 50K chars. Same
    schema-drift class as A2 (file_grep `pattern` vs `regex`).

    Semantics:
      - `offset=0` (default): unchanged behaviour, read from start.
      - `offset>0`: skip the first N LINES, then return up to
        `max_chars` of what remains. Line-based (not byte-based)
        because LLM citations are line-oriented and matching
        `file_grep`'s line:N output style.

    The trailing `[truncated]` marker fires when content past the
    offset still exceeds `max_chars`."""
    p = resolve_under_session_cwd(path)
    if not p.exists():
        return f"Path does not exist: {path}"
    if not p.is_file():
        return f"Not a file: {path}"
    if _looks_binary(p):
        return f"Refusing to read (looks binary): {path}"
    try:
        text = p.read_text(encoding="utf-8", errors="ignore")
    except OSError as e:
        return f"Read error on {path}: {e}"
    record_read(p)
    if offset > 0:
        # Line-based skip — find the start of line `offset+1`.
        lines = text.split("\n")
        if offset >= len(lines):
            return (
                f"Offset {offset} is past end of file "
                f"({len(lines)} lines)."
            )
        text = "\n".join(lines[offset:])
    if len(text) > max_chars:
        return text[:max_chars] + "\n...[truncated]"
    return text


read_file = Tool(
    name="read_file",
    description=(
        "Read the full contents of a single text file and return them "
        "as a string. Use when you need the whole file's content, not "
        "just matching lines (for that, use file_grep). Binary files "
        "and very large files are refused."
    ),
    input_schema={
        "type": "object",
        "required": ["path"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to a text file.",
            },
            "max_chars": {
                "type": "integer",
                "description": (
                    f"Hard cap on returned length (default {MAX_CHARS}). "
                    "Content is truncated with a [truncated] marker."
                ),
                "default": MAX_CHARS,
            },
            "offset": {
                "type": "integer",
                "description": (
                    "Skip this many leading LINES before returning "
                    "content. Default 0 (read from start). Use to page "
                    "through large files: e.g. `offset=1100` reads "
                    "from line 1101 onward. Combine with `max_chars` "
                    "to get a windowed view. Off-by-end returns a "
                    "diagnostic, not an empty string."
                ),
                "default": 0,
            },
        },
    },
    handler=_read_file_handler,
    untrusted_output=True,
    channels=["cli", "web"],
)
