"""Built-in `score_output` tool — grader agents emit a structured verdict.

Used by LLM-as-judge grading agents . The grader's system prompt
instructs it to call score_output(...) exactly once per grading run;
the returned JSON is parsed by the golden-tests runner in rubric mode
to determine pass/fail.
"""

from __future__ import annotations

import json

from .base import Tool


async def _score_output_handler(
    score: int,
    passing: bool,
    reasoning: str,
    flags: list[str] | None = None,
) -> str:
    # Validate score range at tool-handler time so the LLM self-corrects
    # on the next turn rather than producing an invalid verdict.
    try:
        score_int = int(score)
    except (TypeError, ValueError):
        return f"score_output: score must be an integer (got {score!r})"
    if score_int < 0 or score_int > 10:
        return (
            f"score_output: score out of range (got {score_int}; must be 0-10). "
            "Re-emit score_output with a corrected score."
        )
    verdict = {
        "score": score_int,
        "passing": bool(passing),
        "reasoning": str(reasoning),
        "flags": list(flags) if flags else [],
    }
    return json.dumps(verdict)


score_output = Tool(
    name="score_output",
    description=(
        "Emit a structured grading verdict. Used by LLM-as-judge grading "
        "agents. Must be called exactly once per grading run. Score is "
        "0-10 (integer). Passing is a boolean (true if the candidate "
        "output meets the rubric). Reasoning is a one-paragraph "
        "justification. Flags are optional tags like 'hallucination', "
        "'off-topic', 'partial'."
    ),
    input_schema={
        "type": "object",
        "required": ["score", "passing", "reasoning"],
        "properties": {
            "score": {
                "type": "integer",
                "description": "0-10 integer score.",
                "minimum": 0,
                "maximum": 10,
            },
            "passing": {
                "type": "boolean",
                "description": "True if the candidate output meets the rubric.",
            },
            "reasoning": {
                "type": "string",
                "description": "One-paragraph justification for the score.",
            },
            "flags": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional quality tags.",
            },
        },
    },
    handler=_score_output_handler,
    channels=["cli", "web"],
)
