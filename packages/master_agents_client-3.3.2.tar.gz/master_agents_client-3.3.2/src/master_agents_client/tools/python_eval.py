"""Built-in `python_eval` tool."""

from __future__ import annotations

import asyncio
import json
import sys
from textwrap import dedent
from typing import Any

from .base import Tool

MAX_OUTPUT_CHARS = 50_000

_WRAPPER = dedent(
    """
    import json
    import sys

    inputs = json.load(sys.stdin)
    result = None
    namespace = {"inputs": inputs, "__name__": "__main__"}
    code = sys.argv[1]
    exec(compile(code, "<python_eval>", "exec"), namespace, namespace)

    if namespace.get("result") is not None:
        value = namespace["result"]
        if isinstance(value, (dict, list, int, float, bool)) or value is None:
            print(json.dumps(value, ensure_ascii=False))
        else:
            print(str(value))
    """
).strip()


async def _python_eval_handler(
    code: str,
    inputs: dict[str, Any] | None = None,
    timeout_seconds: float = 30.0,
) -> str:
    payload = inputs or {}
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable,
            "-I",
            "-c",
            _WRAPPER,
            code,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(json.dumps(payload).encode("utf-8")),
                timeout=timeout_seconds,
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            return f"python_eval timed out after {timeout_seconds} seconds."

        out = stdout.decode("utf-8", errors="replace").strip()
        err = stderr.decode("utf-8", errors="replace").strip()
        if proc.returncode != 0:
            message = err or out or f"Process exited with code {proc.returncode}"
            if len(message) > MAX_OUTPUT_CHARS:
                message = message[:MAX_OUTPUT_CHARS] + "\n...[truncated]"
            return f"python_eval error: {message}"
        text = out or err or "(no output)"
        if len(text) > MAX_OUTPUT_CHARS:
            text = text[:MAX_OUTPUT_CHARS] + "\n...[truncated]"
        return text
    except Exception as exc:
        return f"python_eval error: {type(exc).__name__}: {exc}"


python_eval = Tool(
    name="python_eval",
    description=(
        "Run a short Python program in a fresh subprocess. The program receives "
        "a JSON object named `inputs` on stdin and may either print to stdout "
        "or assign a final value to `result`."
    ),
    input_schema={
        "type": "object",
        "required": ["code"],
        "properties": {
            "code": {
                "type": "string",
                "description": "Python source code to execute.",
            },
            "inputs": {
                "type": "object",
                "description": "Optional JSON object exposed to the program as `inputs`.",
                "default": {},
            },
            "timeout_seconds": {
                "type": "number",
                "description": "Wall-clock timeout for the subprocess.",
                "default": 30.0,
            },
        },
    },
    handler=_python_eval_handler,
    requires_approval=True,
    channels=["cli"],
)
