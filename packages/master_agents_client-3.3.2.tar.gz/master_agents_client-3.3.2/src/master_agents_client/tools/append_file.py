"""Built-in `append_file` tool.

Append text to a file (creating it + parent dirs if absent). Mirrors
write_file's path-scoping pattern; the session-bound variant is built in
the service via _make_append_file_tool, enforcing writable_paths.
"""

from __future__ import annotations

from pathlib import Path

from .base import Tool


def append_text_file(
    path: Path, content: str, newline_separator: bool = True
) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = content
    if newline_separator and content and not content.endswith("\n"):
        payload = content + "\n"
    with path.open("a", encoding="utf-8") as fh:
        fh.write(payload)
    return f"Appended {len(payload)} chars to {path}"


async def _append_file_handler(
    path: str,
    content: str,
    newline_separator: bool = True,
) -> str:
    from ._session_cwd import resolve_under_session_cwd
    target = resolve_under_session_cwd(path)
    return append_text_file(target, content, newline_separator=newline_separator)


append_file = Tool(
    name="append_file",
    description=(
        "Append text to a file (created if absent). Use for journaling, "
        "logging, or running-notes workflows where you want to preserve "
        "prior content. Adds a trailing newline by default if missing."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "content"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Target file path (created if absent).",
            },
            "content": {
                "type": "string",
                "description": "Text to append.",
            },
            "newline_separator": {
                "type": "boolean",
                "default": True,
                "description": (
                    "If true (default), append a newline after content if it "
                    "doesn't already end in one."
                ),
            },
        },
    },
    handler=_append_file_handler,
    requires_approval=True,
    channels=["cli"],
)
