"""Built-in `python_run` tool — OS-agnostic Python invocation .

Runs Python directly via subprocess on the *client's* machine, with
NO shell involved. Works identically on Windows native (no WSL),
Linux, and macOS — Python itself is the only dependency.

Why this exists
---------------

`bash` was over-coupling. Most agent shell needs are "run a Python
script" or "run pytest" — invocations that don't require bash semantics
at all. Forcing those through `wsl -e bash -c "python -m pytest ..."`
on Windows blocked anyone without WSL2 from using test-running agents
(`backend_tester`, `triage_ci_failure`, `coder_cli` verify steps).

`python_run` skips the shell entirely:

    python_run(args=["-m", "pytest", "tests/"])
    → subprocess.run([sys.executable, "-m", "pytest", "tests/"])

Same call works on every OS. No bash, no cmd, no WSL, no quoting bugs.

CLI-channel only
----------------

This is `channels: ["cli"]`. Web sessions cannot reach it (the deny
set in `the service` is derived from this field at import time). It
runs on the user's machine via tool inversion so file paths and the
working directory match what the user sees.

Output
------

stdout + stderr captured separately, surfaced together in the result
with a clear header. Cap of 100 KB combined; over-cap output is
truncated with a `[...truncated N bytes]` marker.
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

from .base import Tool


MAX_OUTPUT_BYTES = 100 * 1024
MAX_TIMEOUT = 600
DEFAULT_TIMEOUT = 60


def _build_argv(args: list[str]) -> list[str]:
    """Return [python_executable, *args] for direct subprocess invocation.

    Uses `sys.executable` so the agent runs against the same Python
    the framework itself uses — no PATH ambiguity.
    """
    if not isinstance(args, list):
        raise ValueError("args must be a list of strings")
    if not args:
        raise ValueError("args must not be empty")
    return [sys.executable, *(str(a) for a in args)]


def _truncate(blob: bytes, *, cap: int = MAX_OUTPUT_BYTES) -> str:
    if len(blob) <= cap:
        return blob.decode("utf-8", errors="replace")
    head = blob[:cap].decode("utf-8", errors="replace")
    return f"{head}\n[...truncated {len(blob) - cap} bytes]"


async def _python_run_handler(
    args: list[str],
    *,
    cwd: str | None = None,
    timeout: float | int | None = None,
) -> str:
    if not args:
        return "error: args must be a non-empty list"

    secs = float(timeout if timeout is not None else DEFAULT_TIMEOUT)
    if secs <= 0 or secs > MAX_TIMEOUT:
        secs = min(max(secs, 1.0), float(MAX_TIMEOUT))

    try:
        argv = _build_argv(args)
    except ValueError as exc:
        return f"error: {exc}"

    from ._session_cwd import resolve_under_session_cwd, session_cwd_var
    if cwd:
        work_dir = resolve_under_session_cwd(cwd)
    else:
        work_dir = session_cwd_var.get() or Path.cwd()
    if not work_dir.is_dir():
        return f"error: cwd does not exist: {work_dir}"

    try:
        proc = await asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(work_dir),
            env=os.environ.copy(),
        )
    except FileNotFoundError as exc:
        return f"error: python executable not found ({exc})"
    except Exception as exc:
        return f"error: failed to spawn python: {type(exc).__name__}: {exc}"

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=secs,
        )
        rc = proc.returncode if proc.returncode is not None else -1
        out_body = _truncate(stdout or b"")
        err_body = _truncate(stderr or b"")
        sections = [f"[exit {rc}] cwd={work_dir}"]
        if out_body:
            sections.append(f"stdout:\n{out_body}")
        if err_body:
            sections.append(f"stderr:\n{err_body}")
        return "\n".join(sections)
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=2.0,
            )
        except asyncio.TimeoutError:
            stdout, stderr = b"", b""
        out_body = _truncate(stdout or b"")
        err_body = _truncate(stderr or b"")
        sections = [
            f"[exit -1; timed out after {secs:.0f}s] cwd={work_dir}",
        ]
        if out_body:
            sections.append(f"stdout:\n{out_body}")
        if err_body:
            sections.append(f"stderr:\n{err_body}")
        sections.append(
            "[note: kill the long-running command or set a higher 'timeout']"
        )
        return "\n".join(sections)


python_run = Tool(
    name="python_run",
    description=(
        "Run Python on the local machine with the given argv. "
        "OS-agnostic — works on Windows (no WSL needed), Linux, and "
        "macOS uniformly. CLI channel only.\n\n"
        "Use for: running tests (`-m pytest`), running scripts "
        "(`path/to/script.py arg1`), one-off Python expressions "
        "(`-c \"print(1+1)\"`), package management (`-m pip install ...`). "
        "Prefer this over `bash` whenever the command starts with "
        "`python` or `python3` — same semantics, no shell-syntax pitfalls "
        "across platforms.\n\n"
        "Default timeout 60s, max 600s. Output capped at 100 KB."
    ),
    input_schema={
        "type": "object",
        "required": ["args"],
        "properties": {
            "args": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Argv list passed to Python (after the interpreter). "
                    "Examples: [\"-m\", \"pytest\", \"tests/\"], "
                    "[\"-c\", \"import sys; print(sys.version)\"], "
                    "[\"script.py\", \"--flag\"]."
                ),
                "minItems": 1,
            },
            "cwd": {
                "type": "string",
                "description": (
                    "Working directory. Defaults to the client's session cwd."
                ),
            },
            "timeout": {
                "type": "number",
                "description": (
                    "Timeout in seconds (default 60, max 600). On timeout "
                    "the process is killed and partial output returned."
                ),
                "minimum": 1,
                "maximum": MAX_TIMEOUT,
            },
        },
    },
    handler=_python_run_handler,
    requires_approval=True,
    abortable=False,
    channels=["cli"],
)
