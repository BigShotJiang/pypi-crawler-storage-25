"""Client-side no-op branch guard.

The canonical server-side guard refuses commits to the master_agents
project's own main branch as part of internal release discipline.
Customer repos have their own branching policy; this stub leaves
git_write commits unrestricted on the client.

Public surface kept compatible with git.py's import so behaviour
collapses to "always allowed" without changing the call site.
"""

from __future__ import annotations

import contextvars


_BRANCH_GUARD_BRANCHES: frozenset[str] = frozenset()

allow_main_commits_var: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "allow_main_commits", default=True,
)


def is_main_branch(branch: str | None) -> bool:
    """Always False on the client wheel — no branch is guarded."""
    return False


def block_commit_message(branch: str) -> str:
    """Unreachable on the client (is_main_branch always returns False),
    but kept for import compatibility."""
    return f"commit to {branch!r} refused"
