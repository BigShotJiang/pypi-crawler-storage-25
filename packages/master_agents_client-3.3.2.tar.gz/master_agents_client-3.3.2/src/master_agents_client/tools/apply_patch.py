"""Built-in `apply_patch` tool — atomic unified-diff application .

Wraps `git apply` for industrial-grade unified-diff handling:
- Cross-file changes in one atomic operation.
- Honours diff context lines (refuses on context mismatch).
- New-file / delete-file / rename / mode-change all supported by `git apply`.
- `--check` first → if validation passes, apply; if not, return the
  exact failure reason without touching any file.

Why `git apply` and not a pure-Python parser:
- `git apply` is 20+ years of edge-case hardening (CRLF, binary diffs,
  whitespace tolerance, fuzz factor disabled).
- Pure-Python diff appliers are notoriously fragile on real-world output
  (especially when the LLM emits slightly off context lines).
- Coder_cli is CLI-channel only and already requires bash/git — git is
  always available.

The tool runs `git apply` in the working directory's git root. If the cwd
isn't inside a git repo, the tool refuses with a clear message rather than
falling back to a pure-Python applier (failure should be loud, not silent).
"""

from __future__ import annotations

import asyncio
import os
import tempfile
from pathlib import Path

from .base import Tool


# Hard caps. A unified diff over a small refactor is typically <50 KB; the
# 1 MB cap catches accidental-firehose patches without rejecting real work.
MAX_PATCH_BYTES = 1 * 1024 * 1024


async def _run(
    argv: list[str], *, cwd: Path, stdin_bytes: bytes | None = None
) -> tuple[int, str, str]:
    """Run a subprocess; return (rc, stdout, stderr) as decoded text."""
    proc = await asyncio.create_subprocess_exec(
        *argv,
        cwd=str(cwd),
        stdin=asyncio.subprocess.PIPE if stdin_bytes is not None else None,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=os.environ.copy(),
    )
    out, err = await proc.communicate(input=stdin_bytes)
    rc = proc.returncode if proc.returncode is not None else -1
    return rc, out.decode("utf-8", errors="replace"), err.decode("utf-8", errors="replace")


async def _git_root(cwd: Path) -> Path | None:
    """Find the git toplevel for `cwd`, or None if not in a repo."""
    rc, out, _ = await _run(["git", "rev-parse", "--show-toplevel"], cwd=cwd)
    if rc != 0:
        return None
    line = out.strip().splitlines()[0] if out.strip() else ""
    return Path(line) if line else None


async def _apply_patch_handler(
    patch: str,
    *,
    cwd: str | None = None,
    check_only: bool = False,
) -> str:
    if not patch or not patch.strip():
        return "apply_patch: empty patch"
    if len(patch.encode("utf-8")) > MAX_PATCH_BYTES:
        return (
            f"apply_patch: patch is {len(patch)} chars; max is "
            f"{MAX_PATCH_BYTES} bytes — split into smaller patches"
        )

    from ._session_cwd import resolve_under_session_cwd, session_cwd_var
    if cwd:
        work_dir = resolve_under_session_cwd(cwd)
    else:
        work_dir = session_cwd_var.get() or Path.cwd()
    if not work_dir.is_dir():
        return f"apply_patch: cwd does not exist: {work_dir}"

    root = await _git_root(work_dir)
    if root is None:
        return (
            "apply_patch: not inside a git repository. apply_patch uses "
            "`git apply` for atomic application; initialise a repo with "
            "`git init` or work inside an existing one."
        )

    # Always operate at the git root so paths in the diff resolve correctly.
    patch_bytes = patch.encode("utf-8")
    if not patch_bytes.endswith(b"\n"):
        # `git apply` is strict about trailing newline on the last hunk.
        patch_bytes += b"\n"

    # Stage 1 — `git apply --check` validates without touching the tree.
    rc, _, err = await _run(
        ["git", "apply", "--check", "--whitespace=nowarn"],
        cwd=root,
        stdin_bytes=patch_bytes,
    )
    if rc != 0:
        return f"apply_patch: --check failed (no files modified)\n{err.strip()}"

    if check_only:
        return f"apply_patch: --check OK at {root} (no files modified; check_only=true)"

    # Stage 2 — apply for real. We already passed --check so this should
    # succeed unless the tree changed between the two calls.
    rc, _, err = await _run(
        ["git", "apply", "--whitespace=nowarn"],
        cwd=root,
        stdin_bytes=patch_bytes,
    )
    if rc != 0:
        return f"apply_patch: applied --check but apply failed\n{err.strip()}"

    return f"apply_patch: applied at {root}"


apply_patch = Tool(
    name="apply_patch",
    description=(
        "Apply a unified diff atomically across one or more files. Wraps "
        "`git apply --check` (validate) → `git apply` (apply). If the "
        "validation fails, NO files are modified and the exact reason is "
        "returned. Required to run inside a git repository.\n"
        "Use this for multi-file edits or when you have a precise diff in "
        "hand. For single-file batched edits, multi_edit is a simpler "
        "primitive. For one-off single-anchor edits, edit_file is enough."
    ),
    input_schema={
        "type": "object",
        "required": ["patch"],
        "properties": {
            "patch": {
                "type": "string",
                "description": (
                    "Unified diff text (the `diff --git ...` / `--- a/file` / "
                    "`+++ b/file` / `@@ ... @@` format). Must end with a "
                    "newline; tool adds one if missing."
                ),
            },
            "cwd": {
                "type": "string",
                "description": (
                    "Working directory. The tool finds the git root above "
                    "this directory and applies the patch from there. "
                    "Defaults to the client's current directory."
                ),
            },
            "check_only": {
                "type": "boolean",
                "default": False,
                "description": (
                    "If true, validate the patch via `git apply --check` "
                    "and report whether it would apply cleanly, without "
                    "modifying any file."
                ),
            },
        },
    },
    handler=_apply_patch_handler,
    requires_approval=True,
    channels=["cli"],
)
