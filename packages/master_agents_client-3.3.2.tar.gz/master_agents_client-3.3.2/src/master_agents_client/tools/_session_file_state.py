import os
from contextvars import ContextVar
from pathlib import Path

file_state_var: ContextVar[dict[str, float] | None] = ContextVar('file_state_var', default=None)

_MTIME_EPSILON = 0.001


def atomic_write_bytes(path: Path, data: bytes) -> None:
    """Atomic write: temp file in same directory, fsync, replace.

    Guarantees: either ``path`` contains the full ``data`` after this
    returns, or it contains exactly what it contained before — never a
    partial write. Survives Ctrl+C, OOM, and power loss between the
    truncate-and-write window that ``Path.write_bytes`` exposes
    directly.

    Mirrors the load-bearing pattern at ``checkpoint.py:230-242``.
    Both ``write_file`` and ``edit_file`` tools route through this so
    coder pipelines cannot corrupt source files mid-edit. The D2
    checkpoint-and-resume primitive depends on file hashes being
    consistent — a partial write would produce a hash the resume
    layer cannot reconcile.

    The temp path is ``<path>.__mao_tmp__`` in the same directory as
    ``path``; same-filesystem placement guarantees ``replace()`` is a
    single atomic rename rather than a copy-and-delete fallback. The
    ``.__mao_tmp__`` suffix is chosen to be distinctive enough that
    a stray temp left behind by a crash is identifiable as MAO's.

    Args:
        path: Destination path. Parent directory is created if it
            does not exist.
        data: Bytes to write. Caller encodes text upstream
            (typically ``content.encode("utf-8")``).

    Raises:
        OSError: Disk I/O failure (out of space, permission denied,
            etc.). The original file at ``path`` (if it existed) is
            untouched. Best-effort cleanup attempts to remove the
            temp file before re-raising; orphaned temp files are
            possible if cleanup itself fails.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".__mao_tmp__")
    try:
        with tmp.open("wb") as fh:
            fh.write(data)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                # fsync is unsupported on some filesystems (procfs,
                # certain network mounts). replace() is still atomic
                # for in-kernel renames; only crash-safety across
                # power loss degrades on those backends.
                pass
        tmp.replace(path)
    except OSError:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise

def record_read(path: str) -> None:
    state = file_state_var.get(None)
    if state is None:
        return
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return
    state[path] = mtime

def check_can_edit(path: str) -> str | None:
    state = file_state_var.get(None)
    if state is None:
        return None
    if path not in state:
        return f"Path '{path}' was never read in this session"
    try:
        current_mtime = os.path.getmtime(path)
    except OSError:
        return f"Cannot stat path '{path}'"
    recorded_mtime = state[path]
    if current_mtime > recorded_mtime + _MTIME_EPSILON:
        return f"Path '{path}' has been modified since last read"
    return None
