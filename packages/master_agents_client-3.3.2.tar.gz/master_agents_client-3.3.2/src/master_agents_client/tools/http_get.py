"""Built-in `http_get` tool.

By default returns **readable text** extracted from the fetched page
(scripts, styles, SVG, and noscript are stripped, then visible text is
collected). This keeps tool output information-dense for LLMs — a typical
news homepage drops from ~250k chars of raw HTML with JS bundles down
to ~5-15k chars of actual visible content.

Pass `readable=false` to get raw HTML when you need to parse specific
tags or work with structured data.

Includes transient-failure retry with exponential backoff :
- Retries on 408/429/500/502/503/504 status codes + ReadTimeout
  + RemoteProtocolError (truly transient failures).
- Does NOT retry on ConnectError (DNS/refused — rarely transient).
- Honors server Retry-After header up to an absolute ceiling.
"""

from __future__ import annotations

import asyncio

import httpx
from bs4 import BeautifulSoup

from .base import Tool

MAX_CONTENT_CHARS = 50000
_STRIP_TAGS = ("script", "style", "noscript", "svg", "template", "iframe")

DEFAULT_RETRY_STATUS = (408, 429, 500, 502, 503, 504)
RETRY_AFTER_MAX_SECONDS = 60  # absolute ceiling on honored Retry-After


async def _fetch(url: str, timeout_seconds: float) -> str:
    # Security F1 (audit 2026-05-12): SSRF guard. The guard fires
    # only when the active session channel is web/office — CLI
    # sessions route http_get through the tool-inversion bridge to
    # the user's machine, where their network is the trust boundary.
    from ._url_guard import (
        UrlBlocked, make_redirect_event_hook, validate_outbound_url,
    )
    from ._session_outputs import client_channel_var
    channel = client_channel_var.get()
    try:
        validate_outbound_url(url, channel=channel)
    except UrlBlocked as exc:
        raise httpx.HTTPError(f"blocked by SSRF guard: {exc}") from exc
    async with httpx.AsyncClient(
        timeout=timeout_seconds,
        follow_redirects=True,
        event_hooks={"response": [make_redirect_event_hook(channel)]},
    ) as client:
        response = await client.get(url)
        response.raise_for_status()
        return response.text


def extract_readable_text(html: str) -> str:
    """Strip noise tags and return visible text. Robust on non-HTML input
    (plain text, JSON, etc. pass through unchanged)."""
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(_STRIP_TAGS):
        tag.decompose()
    # Prefer body if present; else root
    root = soup.body or soup
    text = root.get_text(separator="\n", strip=True)
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    return "\n".join(lines)


async def _http_get_handler(
    url: str,
    timeout_seconds: float = 10.0,
    readable: bool = True,
    max_retries: int = 3,
    retry_on: list[int] | None = None,
) -> str:
    retry_statuses = tuple(retry_on) if retry_on else DEFAULT_RETRY_STATUS
    attempts = 0

    while True:
        attempts += 1
        try:
            raw = await _fetch(url, timeout_seconds)
            text = extract_readable_text(raw) if readable else raw
            if len(text) > MAX_CONTENT_CHARS:
                text = text[:MAX_CONTENT_CHARS] + "\n...[truncated]"
            if attempts > 1:
                return f"[retried {attempts - 1} time(s); succeeded]\n{text}"
            return text
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            retry_after = _parse_retry_after(exc.response.headers.get("Retry-After"))
            if status not in retry_statuses or attempts > max_retries:
                preamble = (
                    f"[retried {attempts - 1} time(s); final status={status}]\n"
                    if attempts > 1 else ""
                )
                return f"{preamble}http_get: HTTP {status} for {url}"
            if retry_after is not None and retry_after > RETRY_AFTER_MAX_SECONDS:
                return (
                    f"http_get: HTTP {status} for {url}. Server requested "
                    f"Retry-After={retry_after}s which exceeds {RETRY_AFTER_MAX_SECONDS}s cap. "
                    "Retry manually later or raise the ceiling."
                )
            wait = retry_after if retry_after is not None else _backoff_delay(attempts)
            await asyncio.sleep(wait)
        except (httpx.ReadTimeout, httpx.RemoteProtocolError) as exc:
            if attempts > max_retries:
                return (
                    f"[retried {attempts - 1} time(s); final error]\n"
                    f"http_get: {type(exc).__name__}: {exc}"
                )
            await asyncio.sleep(_backoff_delay(attempts))
        except httpx.ConnectError as exc:
            # DNS / connection-refused — do not retry
            return f"http_get: ConnectError: {exc}"
        except httpx.HTTPError as exc:
            # Other httpx errors — don't retry, surface to agent
            return f"http_get: {type(exc).__name__}: {exc}"


def _parse_retry_after(value: str | None) -> float | None:
    """Parse Retry-After header — accepts seconds or HTTP-date (seconds only for v1)."""
    if value is None:
        return None
    try:
        seconds = float(value)
        if seconds < 0:
            return None
        return seconds
    except (TypeError, ValueError):
        # HTTP-date format not supported in v1; treat as absent
        return None


def _backoff_delay(attempt: int) -> float:
    """Exponential backoff: 1s, 2s, 4s, ... capped at 30s."""
    return min(2 ** (attempt - 1), 30.0)


http_get = Tool(
    name="http_get",
    description=(
        "Fetch the body of a URL via HTTP GET. By default returns the "
        "readable text content only (scripts, styles, SVG, and other "
        "noise are stripped) — preferred for reading web pages. Pass "
        "readable=false to get raw HTML when you need to parse specific "
        f"tags. Content is truncated at {MAX_CONTENT_CHARS} characters "
        "if longer. "
        "Transient failures (408/429/500/502/503/504, ReadTimeout, "
        "RemoteProtocolError) are retried up to max_retries=3 times with "
        "exponential backoff (1s→2s→4s). Server Retry-After header is "
        "honored up to a 60-second ceiling — larger values return "
        "immediately without retrying. ConnectError / DNS failures are "
        "NEVER retried. HTTP-date format Retry-After is not parsed in v1."
    ),
    input_schema={
        "type": "object",
        "required": ["url"],
        "properties": {
            "url": {"type": "string", "description": "The URL to fetch."},
            "timeout_seconds": {
                "type": "number",
                "description": "Request timeout in seconds.",
                "default": 10.0,
            },
            "readable": {
                "type": "boolean",
                "description": (
                    "If true (default), strip scripts/styles and return "
                    "clean readable text. If false, return raw HTML."
                ),
                "default": True,
            },
            "max_retries": {
                "type": "integer",
                "description": (
                    "Max retry attempts for transient failures "
                    "(408/429/500/502/503/504 + ReadTimeout/RemoteProtocolError). "
                    "Default 3. Set 0 to disable retry."
                ),
                "default": 3,
            },
            "retry_on": {
                "type": "array",
                "items": {"type": "integer"},
                "description": (
                    "Status codes to retry on (default 408/429/500/502/503/504). "
                    "ConnectError / DNS failures are NEVER retried."
                ),
            },
        },
    },
    handler=_http_get_handler,
    untrusted_output=True,
    # Deliberately multi-channel: load-bearing for assistant_web and
    # assistant_office. SSRF guard inside _fetch() makes the web
    # surface safe (validates URL + denies private IPs + redirect
    # re-validation). CLI sessions route via DEFAULT_CLIENT_SIDE_TOOLS
    # bridge to user's machine — user's network is their trust
    # boundary, guard intentionally exempts CLI.
    channels=["cli", "web", "office"],
)
