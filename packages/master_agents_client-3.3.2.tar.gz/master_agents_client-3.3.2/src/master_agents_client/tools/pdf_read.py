"""Built-in `pdf_read` tool — extract text from a PDF with page markers.

  adds optional OCR for scanned/image-only PDFs via Tesseract
(pytesseract) + Poppler (pdf2image). OCR mode is controlled by the `ocr`
kwarg: "off" (default, no OCR), "auto" (OCR only pages where pypdf
returned empty/whitespace text), "force" (OCR every page).
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Literal

from .base import Tool

MAX_CHARS = 50_000
OCR_PER_PAGE_TIMEOUT = 15.0
OCR_WHOLE_DOC_TIMEOUT = 120.0
OCR_DPI = 200


def _ocr_dependencies_available() -> tuple[bool, str]:
    """Return (ok, error_msg). Distinguishes pytesseract vs pdf2image vs Tesseract binary vs Poppler."""
    try:
        import pytesseract  # noqa: F401
    except ImportError:
        return False, (
            "OCR requested but pytesseract not installed. "
            "Run: `pip install 'master-agents[ocr]'`"
        )
    try:
        import pdf2image  # noqa: F401
    except ImportError:
        return False, (
            "OCR requested but pdf2image not installed. "
            "Run: `pip install 'master-agents[ocr]'`"
        )
    return True, ""


def _ocr_page(path: Path, page_num: int, deadline: float) -> tuple[str, str | None]:
    """Render page_num (1-indexed) as image and OCR it. Returns (text, error)."""
    import pdf2image
    import pytesseract
    from pdf2image.exceptions import PDFInfoNotInstalledError, PDFPageCountError
    from pytesseract.pytesseract import TesseractError, TesseractNotFoundError

    remaining = deadline - time.time()
    if remaining <= 0:
        return "", "whole-document ceiling reached"
    try:
        images = pdf2image.convert_from_path(
            str(path), dpi=OCR_DPI,
            first_page=page_num, last_page=page_num,
        )
    except PDFInfoNotInstalledError:
        return "", (
            "Poppler binary not found. "
            "(Debian) `apt-get install poppler-utils`; "
            "(macOS) `brew install poppler`; "
            "(Windows) `choco install poppler` or "
            "`conda install -c conda-forge poppler`."
        )
    except PDFPageCountError as exc:
        return "", f"pdf2image page-count error: {exc}"
    except Exception as exc:
        return "", f"pdf2image error: {type(exc).__name__}: {exc}"

    if not images:
        return "", "no image rendered"

    try:
        text = pytesseract.image_to_string(images[0], timeout=OCR_PER_PAGE_TIMEOUT)
    except TesseractNotFoundError:
        return "", (
            "Tesseract binary not found. "
            "(Debian) `apt-get install tesseract-ocr`; "
            "(macOS) `brew install tesseract`; "
            "(Windows) `winget install UB-Mannheim.TesseractOCR`."
        )
    except RuntimeError as exc:
        # pytesseract raises RuntimeError on its per-call timeout.
        if "timeout" in str(exc).lower():
            return "", f"OCR timed out after {OCR_PER_PAGE_TIMEOUT}s"
        return "", f"tesseract error: {exc}"
    except TesseractError as exc:
        return "", f"tesseract error: {exc}"
    return text, None


async def _pdf_read_handler(
    path: str,
    max_chars: int = MAX_CHARS,
    start_page: int | None = None,
    end_page: int | None = None,
    ocr: Literal["off", "auto", "force"] = "off",
) -> str:
    p = Path(path)
    if not p.exists():
        return f"Path does not exist: {path}"
    if not p.is_file():
        return f"Not a file: {path}"
    if p.suffix.lower() != ".pdf":
        return f"Not a PDF file: {path}"

    try:
        from pypdf import PdfReader
        from pypdf.errors import PdfReadError
    except ImportError:  # pragma: no cover
        return "pypdf is not installed. Install the master-agents package with pdf extras."

    try:
        reader = PdfReader(str(p))
    except (PdfReadError, OSError, ValueError) as e:
        # pypdf raises PdfReadError for malformed PDFs, OSError for disk
        # issues, and ValueError for some structural corruption. Anything
        # else is a genuine bug and should propagate.
        return f"Failed to read PDF: {type(e).__name__}: {e}"

    if reader.is_encrypted:
        try:
            ok = reader.decrypt("")
        except Exception as e:
            return f"Failed to read PDF (encrypted): {type(e).__name__}: {e}"
        if not ok:
            return f"Refusing to read encrypted PDF (password required): {path}"

    total_pages = len(reader.pages)
    if total_pages == 0:
        return f"PDF has no pages: {path}"

    # Page range: 1-indexed, inclusive. Validate before extracting.
    first = 1 if start_page is None else start_page
    last = total_pages if end_page is None else end_page
    if first < 1 or last < 1:
        return (
            f"Invalid page range: start_page and end_page must be 1-indexed positive integers "
            f"(got start_page={start_page}, end_page={end_page})"
        )
    if first > last:
        return (
            f"Invalid page range: start_page ({first}) must be <= end_page ({last})"
        )
    if first > total_pages:
        return (
            f"Invalid page range: start_page ({first}) exceeds PDF page count ({total_pages})"
        )
    last = min(last, total_pages)

    if ocr not in ("off", "auto", "force"):
        return f"Invalid ocr mode {ocr!r}: expected 'off' | 'auto' | 'force'"

    ocr_available = False
    ocr_error: str | None = None
    if ocr != "off":
        ocr_available, ocr_error = _ocr_dependencies_available()
        if not ocr_available:
            return ocr_error

    parts: list[str] = []
    extracted_any = False
    deadline = time.time() + OCR_WHOLE_DOC_TIMEOUT
    ocr_cutoff_page: int | None = None

    for page_num in range(first, last + 1):
        extraction_failed = False
        try:
            text = reader.pages[page_num - 1].extract_text() or ""
        except Exception as e:
            text = f"[extraction error: {type(e).__name__}: {e}]"
            extraction_failed = True

        needs_ocr = (
            (ocr == "force")
            # auto mode fires on empty/whitespace OR on extraction failure —
            # the exact case OCR was added for.
            or (ocr == "auto" and (extraction_failed or not text.strip()))
        )
        if needs_ocr and ocr_available:
            if time.time() >= deadline:
                ocr_cutoff_page = page_num
                break
            ocr_text, ocr_err = _ocr_page(p, page_num, deadline)
            if ocr_err and "ceiling" in ocr_err:
                ocr_cutoff_page = page_num
                break
            if ocr_err:
                text = f"{text}\n[OCR error on page {page_num}: {ocr_err}]"
            else:
                if ocr == "force":
                    text = f"[page {page_num}: OCR] {ocr_text}"
                else:
                    text = ocr_text

        if text.strip():
            extracted_any = True
        parts.append(f"---page {page_num}---\n{text}")

    if ocr_cutoff_page is not None:
        parts.append(
            f"[OCR stopped before page {ocr_cutoff_page} of {last}: "
            f"whole-document ceiling ({OCR_WHOLE_DOC_TIMEOUT}s) reached]"
        )

    if not extracted_any:
        return (
            f"PDF has no extractable text (may be scanned): {path}"
        )

    output = "\n".join(parts)
    if len(output) > max_chars:
        output = output[:max_chars] + "\n...[truncated]"
    return output


pdf_read = Tool(
    name="pdf_read",
    description=(
        "Read a PDF file and return its extracted text with page markers "
        "in the form `---page N---`. Use for research papers, contracts, "
        "manuals, or any PDF where you need the content as text. Set "
        "`ocr='auto'` to OCR empty pages via Tesseract (requires "
        "`pip install 'master-agents[ocr]'` + Tesseract/Poppler system "
        "binaries). `ocr='force'` OCRs every page — use for PDFs where "
        "the existing text layer is garbled. Optional start_page / "
        "end_page (1-indexed, inclusive) slice a subset."
    ),
    input_schema={
        "type": "object",
        "required": ["path"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to a .pdf file.",
            },
            "max_chars": {
                "type": "integer",
                "description": (
                    f"Hard cap on returned length (default {MAX_CHARS}). "
                    "Content is truncated with a [truncated] marker."
                ),
                "default": MAX_CHARS,
            },
            "start_page": {
                "type": "integer",
                "description": "First page to read, 1-indexed inclusive. Defaults to first page.",
            },
            "end_page": {
                "type": "integer",
                "description": "Last page to read, 1-indexed inclusive. Defaults to last page.",
            },
            "ocr": {
                "type": "string",
                "enum": ["off", "auto", "force"],
                "default": "off",
                "description": (
                    "OCR mode. 'off': no OCR (default); 'auto': OCR only "
                    "pages where pypdf returned empty text; 'force': OCR "
                    "every page (for garbled text-layer PDFs)."
                ),
            },
        },
    },
    handler=_pdf_read_handler,
    untrusted_output=True,
    channels=["cli"],
)
