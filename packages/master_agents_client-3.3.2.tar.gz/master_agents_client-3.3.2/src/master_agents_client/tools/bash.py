"""Built-in `bash` tool — cross-platform shell exec on the CLI channel .

Runs a shell command on the *client's* machine (via tool inversion), with:

- bash semantics on Unix (`bash -c "..."`)
- transparent WSL2 bridge on Windows-with-WSL (`wsl -e bash -c "..."`)
- cmd.exe fallback on Windows-without-WSL . Bash-only syntax
  (heredocs, `$VAR`, POSIX utilities like `ls`/`grep`/`cat`) will
  fail under cmd.exe — but portable invocations (`git status`,
  `npm test`, `python -m pytest`) work identically. The agent's
  `<client_platform>` system-prompt block tells it which shell it
  has so it can pick syntax accordingly. For Python specifically,
  prefer the dedicated `python_run` tool — it skips the shell.

This tool is **CLI-channel only**. Web sessions cannot reach it: it's
on `_TOOLS_DENIED_ON_WEB` in `the service` AND any agent that lists it
should be marked `channels: ["cli"]`. The CLI client's
`--writable-paths` does NOT constrain bash (commands can read anywhere),
which is why this tool is gated to the trusted CLI channel.

Output handling
---------------

Both stdout and stderr are captured + interleaved into one block (so
the agent sees compiler errors next to the command that emitted them).
A small header surfaces the exit code. Output over `MAX_OUTPUT_BYTES`
is truncated with a clear `[...truncated N bytes]` marker — agents
should narrow their command (e.g. `head`, `grep -c`) rather than rely
on full streams.

Timeouts
--------

`timeout` arg is in seconds, capped at `MAX_TIMEOUT`. On timeout the
process group is killed; the tool returns a non-zero exit and the
partial captured output. No hung-forever case.
"""

from __future__ import annotations

import asyncio
import os
import shutil
import sys
from pathlib import Path

from .base import Tool


# Hard caps. The agent should never need more output than this from a
# single command — narrow with grep / head / tail.
MAX_OUTPUT_BYTES = 100 * 1024     # 100 KB combined stdout+stderr
MAX_TIMEOUT = 600                  # 10 min absolute ceiling
DEFAULT_TIMEOUT = 60               # 60s default — most commands return fast


def _is_windows() -> bool:
    return sys.platform == "win32"


def _git_bash_path() -> str | None:
    """Locate Git Bash on Windows.

    Git Bash inherits the user's Windows PATH (so it sees Windows-side
    Python installs and any project that's `pip install -e`'d in that
    interpreter), which WSL does NOT — WSL has its own Python env on
    its own filesystem. For most user dev setups (Git for Windows +
    Python installed via the python.org installer or Microsoft Store),
    Git Bash is the right shell choice for cross-env tool inversion.

    Returns the absolute path to bash.exe, or None if not found.
    """
    if not _is_windows():
        return None
    found = shutil.which("bash")
    if found:
        return found
    standard_paths = [
        r"C:\Program Files\Git\bin\bash.exe",
        r"C:\Program Files (x86)\Git\bin\bash.exe",
    ]
    for candidate in standard_paths:
        if Path(candidate).is_file():
            return candidate
    return None


def _wsl_available() -> bool:
    """Return True if we can run `wsl -e bash` on this host.

    We don't probe at import time — `shutil.which("wsl")` is cheap.
    """
    return _is_windows() and shutil.which("wsl") is not None


# Operator override: force a specific shell choice via env var. Useful
# when auto-detection picks the wrong shell. Values: "git-bash", "wsl",
# "cmd", "auto" (default — preference order: git-bash, wsl, cmd).
_SHELL_OVERRIDE_ENV = "MAO_BASH_SHELL"


_VALID_SHELL_OVERRIDES = frozenset(
    {"auto", "", "git-bash", "git_bash", "gitbash", "wsl", "cmd"}
)


def _resolve_shell_choice() -> str:
    """Pick the Windows shell using the auto-detect / override logic.

    Loud-fail on unknown ``MAO_BASH_SHELL`` values: silently falling
    back to auto-detect when the operator set a typo'd override
    (e.g. ``gitbash2``, ``powershell``) gives the operator the
    opposite of what they asked for with no signal. The
    ``_bash_handler`` wraps the raised ``RuntimeError`` into a
    surface ``error: ...`` so the agent sees the misconfiguration.
    """
    override = os.environ.get(_SHELL_OVERRIDE_ENV, "auto").strip().lower()
    if override and override not in _VALID_SHELL_OVERRIDES:
        raise RuntimeError(
            f"unknown {_SHELL_OVERRIDE_ENV}={override!r} — "
            f"valid values: git-bash, wsl, cmd, auto (default)"
        )
    if override in ("git-bash", "git_bash", "gitbash"):
        return "git-bash"
    if override == "wsl":
        return "wsl"
    if override == "cmd":
        return "cmd"
    if _git_bash_path():
        return "git-bash"
    if _wsl_available():
        return "wsl"
    return "cmd"


def _build_argv(command: str) -> list[str]:
    """Pick the right shell invocation for the current host.

    On Unix → `bash -lc <command>`.

    On Windows, prefer in order (override via `MAO_BASH_SHELL`):
      1. Git Bash (`bash.exe -lc <command>`) — shares Windows Python
         env with the host, so a verify_command like
         `python -c "import <user_project>"` works against the user's
         `pip install -e` package.
      2. WSL (`wsl -e bash -lc <command>`) — Linux env, isolated
         Python, only works if the project is also installed in WSL.
      3. cmd.exe (`/c <command>`) — bash-only syntax fails but
         portable invocations work.

    The auto-detect order changed 2026-05-10: previously WSL was
    preferred over Git Bash, which broke verify_commands using the
    user's editable Python install (the Phase 1 SimOS strict-validator
    dispatch surfaced this — coder_cli's `python -c "from
    simulation_os.config..."` failed with exit 127 because WSL had
    neither `python` nor the simulation_os package on PATH).
    """
    if _is_windows():
        choice = _resolve_shell_choice()
        if choice == "git-bash":
            git_bash = _git_bash_path()
            if git_bash:
                return [git_bash, "-lc", command]
        if choice == "wsl" and _wsl_available():
            return ["wsl", "-e", "bash", "-lc", command]
        return ["cmd.exe", "/c", command]
    return ["bash", "-lc", command]


def _truncate(blob: bytes, *, cap: int = MAX_OUTPUT_BYTES) -> str:
    """Decode + truncate combined output."""
    if len(blob) <= cap:
        return blob.decode("utf-8", errors="replace")
    head = blob[:cap].decode("utf-8", errors="replace")
    return f"{head}\n[...truncated {len(blob) - cap} bytes]"


async def _bash_handler(
    command: str,
    *,
    cwd: str | None = None,
    timeout: float | int | None = None,
) -> str:
    """Run `command` via bash on the host; return formatted result."""
    if not command or not command.strip():
        return "error: empty command"

    secs = float(timeout if timeout is not None else DEFAULT_TIMEOUT)
    if secs <= 0 or secs > MAX_TIMEOUT:
        secs = min(max(secs, 1.0), float(MAX_TIMEOUT))

    try:
        argv = _build_argv(command)
    except RuntimeError as exc:
        return f"error: {exc}"

    from ._session_cwd import resolve_under_session_cwd, session_cwd_var
    if cwd:
        work_dir = resolve_under_session_cwd(cwd)
    else:
        work_dir = session_cwd_var.get() or Path.cwd()
    if not work_dir.is_dir():
        return f"error: cwd does not exist: {work_dir}"

    # Merge stderr into stdout for combined ordering — agents read this
    # as one stream, which matches how a developer reads a terminal.
    try:
        proc = await asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=str(work_dir),
            env=os.environ.copy(),
        )
    except FileNotFoundError as exc:
        return f"error: shell not found ({exc})"
    except Exception as exc:
        return f"error: failed to spawn shell: {type(exc).__name__}: {exc}"

    try:
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=secs)
        rc = proc.returncode if proc.returncode is not None else -1
        body = _truncate(stdout or b"")
        return f"[exit {rc}] cwd={work_dir}\n{body}"
    except asyncio.TimeoutError:
        # Best-effort kill of the whole process group; on Windows we
        # only have terminate(), no setpgid trick available.
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=2.0)
        except asyncio.TimeoutError:
            stdout = b""
        body = _truncate(stdout or b"")
        return (
            f"[exit -1; timed out after {secs:.0f}s] cwd={work_dir}\n"
            f"{body}\n[note: kill the long-running command or set a higher 'timeout']"
        )


bash = Tool(
    name="bash",
    description=(
        "Run a shell command on the local machine and return combined "
        "stdout+stderr with the exit code. CLI channel only — the web "
        "channel cannot reach this tool. Use for: running tests, linters, "
        "builds, git, package managers; one-shot file inspection (head, "
        "wc, file). Prefer the dedicated tools (read_file, file_grep, "
        "edit_file) for read/edit when possible; use bash for things "
        "those tools can't do.\n"
        "Shell selection: `bash -lc` on Unix; `wsl -e bash -lc` on "
        "Windows-with-WSL; `cmd.exe /c` on Windows-without-WSL. The "
        "<client_platform> block in the system prompt tells you which. "
        "For Python invocations (pytest, scripts, pip) prefer the "
        "`python_run` tool — it bypasses the shell entirely and is "
        "OS-agnostic. Output is capped at 100 KB; default timeout 60s, "
        "max 600s."
    ),
    input_schema={
        "type": "object",
        "required": ["command"],
        "properties": {
            "command": {
                "type": "string",
                "description": (
                    "Shell command to execute. Bash semantics. Use `&&` "
                    "for sequencing and quote arguments containing spaces."
                ),
            },
            "cwd": {
                "type": "string",
                "description": (
                    "Working directory for the command. Defaults to the "
                    "client's current directory."
                ),
            },
            "timeout": {
                "type": "number",
                "description": (
                    "Timeout in seconds (default 60, max 600). On timeout "
                    "the command is killed and partial output returned."
                ),
                "minimum": 1,
                "maximum": MAX_TIMEOUT,
            },
        },
    },
    handler=_bash_handler,
    requires_approval=True,   # Destructive by default; planner gates explicitly.
    abortable=False,           # In-flight kill handled by timeout, not asyncio cancel.
    channels=["cli"],
)
