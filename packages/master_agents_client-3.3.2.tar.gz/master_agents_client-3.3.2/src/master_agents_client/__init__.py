"""Master Agents — thin client.

Public surface is the ``agents`` CLI (see ``master_agents_client.cli``).
Programmatic users may import:

    from master_agents_client.remote_client import RemoteToolExecutor
    from master_agents_client.tracer import ConsoleTracer

This package ships no orchestration logic, prompts, or agent specs."""

# Read version from installed package metadata so pyproject.toml is
# the single source of truth. Hardcoded literal here drifted before
# (was "0.1.0" while wheel was on "1.0.1"; mao-client --version lied).
from importlib.metadata import version as _pkg_version, PackageNotFoundError as _PackageNotFoundError

try:
    __version__ = _pkg_version("master-agents-client")
except _PackageNotFoundError:
    __version__ = "0.0.0+unknown"
del _pkg_version, _PackageNotFoundError
