"""No-op self-host detector for the client wheel.

The canonical server-side module enumerates the master_agents
project's own load-bearing source files for use during self-hosted
refactor sessions. End users are not editing the service's source,
so the gate is permanently inactive on the client.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional


def is_load_bearing(path: str | Path) -> bool:
    return False


def is_self_hosted_repo(cwd: str | Path) -> bool:
    """Always False on the client wheel."""
    return False


def self_hosted_warning_for(path: str | Path) -> Optional[str]:
    return None
