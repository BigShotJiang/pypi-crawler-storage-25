""" — streaming markdown buffer (closes A26).

Buffers streaming text-delta chunks during a turn and flushes at
SAFE boundaries — points where the rendered output won't shift if
a partial inline-markdown token is still incoming. Rendered chunks
go through `rich.markdown.Markdown` so bold / lists / headings /
code blocks render properly, matching the post-turn final-answer
rendering that  added.

Boundary rules:

  - Paragraph break (`\\n\\n`)        — always safe.
  - Single newline (`\\n`)            — safe unless inside an open
                                        inline `**` or `` ` ``
                                        token, or inside an open
                                        code fence (```` ``` ````).
  - Code-fence closure                — flushes when the closing
                                        ```` ``` ```` arrives, so the
                                        whole block renders at once.

The buffer is otherwise stream-friendly: `feed(text)` is non-
blocking and order-preserving; `flush` emits remaining buffer
regardless of state. `flush_fn` is injectable for testability;
without it, `rich.markdown.Markdown` writes to the configured
stream.
"""

from __future__ import annotations

import re
import sys
from typing import IO, Callable, Optional


_PARAGRAPH_BREAK = "\n\n"
_CODE_FENCE_RE = re.compile(r"```")


def _has_open_inline_token(text: str) -> bool:
    """Return True if `text` ends with an open `**` bold span or
    `` ` `` code span. We count occurrences naively (good enough
    for boundary detection — false negatives are rare and the
    flush would just include slightly more text)."""
    # Strip code fences first so triple-backticks don't confuse
    # the inline-backtick count.
    fences_stripped = _CODE_FENCE_RE.sub("", text)
    bold_count = fences_stripped.count("**")
    # Odd count = unmatched open `**`.
    if bold_count % 2 == 1:
        return True
    # Inline backticks, after stripping fences. Odd count = open.
    backtick_count = fences_stripped.count("`")
    if backtick_count % 2 == 1:
        return True
    return False


def _has_open_code_fence(text: str) -> bool:
    """True if there's an unclosed ```` ``` ```` fence in the text.
    Open at odd count of fences."""
    return len(_CODE_FENCE_RE.findall(text)) % 2 == 1


class StreamingMarkdownBuffer:
    """Buffer-and-flush wrapper for streaming markdown rendering.

    Production usage:
      buf = StreamingMarkdownBuffer(stream=sys.stdout, color=True)
      async for chunk in stream:
          buf.feed(chunk.text)
      buf.flush()

    Test usage:
      flushed = []
      buf = StreamingMarkdownBuffer(flush_fn=flushed.append)
      buf.feed(...)
      assert flushed == [...]
    """

    def __init__(
        self,
        *,
        stream: Optional[IO[str]] = None,
        color: bool = True,
        flush_fn: Optional[Callable[[str], None]] = None,
    ) -> None:
        self._buf = ""
        self._color = color
        # Default sink: stderr (matches ConsoleTracer's default;
        # streaming text is "live progress" not "final result").
        self._stream = stream if stream is not None else sys.stderr
        if flush_fn is not None:
            self._flush_fn: Callable[[str], None] = flush_fn
        else:
            self._flush_fn = self._render_via_rich

    # ── Public API ────────────────────────────────────────────────

    def feed(self, text: str) -> None:
        """Add text to the buffer; flush at any safe boundary
        crossed by the addition."""
        if not text:
            return
        self._buf += text
        self._try_flush_at_boundaries()

    def flush(self) -> None:
        """Emit anything remaining in the buffer, regardless of
        state. Call at end of stream."""
        if self._buf:
            self._flush_fn(self._buf)
            self._buf = ""

    # ── Boundary detection ────────────────────────────────────────

    def _try_flush_at_boundaries(self) -> None:
        """Walk the buffer left to right; flush each completed
        chunk as we cross a safe boundary."""
        while True:
            # Code-fence handling — fences are sticky. If the buffer
            # contains a fenced region (opening ``` somewhere), we
            # must NEVER cut between opening and closing fence.
            fence_starts = [
                m.start() for m in _CODE_FENCE_RE.finditer(self._buf)
            ]
            if fence_starts:
                # First fence is the opening one.
                opening = fence_starts[0]
                # If there's no closing fence yet, hold everything
                # from `opening` onward; flush only what's strictly
                # before it (using the inline-only boundary logic).
                if len(fence_starts) < 2:
                    pre = self._buf[:opening]
                    pre_boundary = self._find_safe_inline_boundary(pre)
                    if pre_boundary is None:
                        return
                    self._flush_fn(self._buf[:pre_boundary])
                    self._buf = self._buf[pre_boundary:]
                    continue
                # Fully-bracketed fence: flush everything up to AND
                # INCLUDING the closing fence + its trailing newline
                # as one atomic chunk so the block renders together.
                close_pos = fence_starts[1]
                end = close_pos + 3
                if end < len(self._buf) and self._buf[end] == "\n":
                    end += 1
                elif end > len(self._buf):
                    # closing ``` not fully present yet
                    return
                self._flush_fn(self._buf[:end])
                self._buf = self._buf[end:]
                continue

            # No code fence anywhere in the buffer: fall through to
            # the normal inline-only boundary detection.
            boundary = self._find_safe_inline_boundary(self._buf)
            if boundary is None:
                return
            chunk = self._buf[:boundary]
            self._flush_fn(chunk)
            self._buf = self._buf[boundary:]

    @staticmethod
    def _find_safe_inline_boundary(text: str) -> Optional[int]:
        """Return the index AFTER the next safe boundary in `text`,
        or None if none is present.

        Safe boundaries:
          - `\\n\\n` (paragraph break)  — always safe (even when
            the preceding prefix contains an unmatched inline token,
            because a paragraph break ends the inline context).
          - `\\n` (single newline)     — safe iff the prefix up to
            and including the newline contains no unmatched inline
            `**` or `` ` `` token.

        Scans every newline left to right — returns the FIRST safe
        boundary, not just the first newline. Earlier versions
        bailed at the first newline if it was unsafe and missed
        later safe newlines in the same buffer."""
        # Paragraph break wins — always safe.
        idx = text.find(_PARAGRAPH_BREAK)
        if idx != -1:
            return idx + len(_PARAGRAPH_BREAK)

        # Single newline — scan ALL newlines, return the first one
        # whose prefix has balanced inline tokens.
        pos = 0
        while True:
            i = text.find("\n", pos)
            if i == -1:
                return None
            prefix = text[: i + 1]
            if not _has_open_inline_token(prefix):
                return i + 1
            pos = i + 1

    # ── Default flush sink: rich.markdown.Markdown ────────────────

    def _render_via_rich(self, chunk: str) -> None:
        """Production sink — render through `rich.markdown.Markdown`
        and write to the configured stream. Silently falls back to
        plain write if rich isn't installed."""
        try:
            from rich.console import Console
            from rich.markdown import Markdown

            console = Console(file=self._stream, force_terminal=self._color)
            console.print(Markdown(chunk), end="")
        except ImportError:
            try:
                self._stream.write(chunk)
                self._stream.flush()
            except Exception:
                pass
