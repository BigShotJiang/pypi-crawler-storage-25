"""Detect the client's platform (OS + shell) for  platform-aware
tool routing.

The CLIENT calls `detect_client_platform` on session open and POSTs
the result in the /sessions creation body. The SERVER stores it on
ManagedSession; the runner injects it as a `<client_platform>` block
into the agent's system prompt context so specialists can pick the
right command syntax (cmd.exe vs WSL bash vs POSIX bash) without
guessing.

Why this exists: agents have been writing `bash dir /b "C:\\..."`
under WSL bash, where `dir` is GNU coreutils' dir (not cmd.exe's),
`/b` is parsed as a path argument, and Windows paths don't exist in
the WSL namespace. Same agent on macOS would silently work because
`ls "/Users/..."` is valid bash. The fix isn't smarter prompts; it's
giving the agent factual context about its execution environment.

E38 (2026-05-13) extension — capability detection: shell type alone
is insufficient. Real session 2026-05-13 traced `litreview_simos_cli`
running `python3 scripts/pool_fetch_batch.py`, failing on a missing
`httpx` dependency, then `pip install httpx`, then retry. The trial-
and-error loop happens because the agent has no upfront signal that
httpx wasn't installed. E38 extends the probe to surface Python
interpreter inventory + key packages + CLI binaries on PATH, so the
agent's `<client_platform>` block answers "is httpx here?" before
turn 1 instead of after the first failed run.
"""

from __future__ import annotations

import json
import platform
import shutil
import subprocess
from typing import Any


# E38: package allowlist. Kept small + standard so the rendered
# block doesn't bloat the prompt (each package adds ~1 line to the
# rendered output). Twelve covers the dependencies that actually
# matter for our agents' typical workflows. Order is fixed so the
# rendered output is byte-stable (cache-friendly).
KEY_PYTHON_PACKAGES: tuple[str, ...] = (
    "httpx",
    "requests",
    "httpcore",
    "aiohttp",
    "pydantic",
    "pyyaml",
    "pandas",
    "numpy",
    "scipy",
    "matplotlib",
    "anthropic",
    "openai",
)

# E38: CLI binary allowlist. Same byte-stability + small-rendered-
# output reasoning as KEY_PYTHON_PACKAGES.
KEY_CLI_BINARIES: tuple[str, ...] = (
    "git",
    "node",
    "npm",
    "python",
    "python3",
    "pip",
    "docker",
    "wsl",
    "cloudflared",
    "gh",
)


def detect_client_platform() -> dict[str, Any]:
    """Return a dict describing the current machine's OS + preferred
    shell + (E38) capability inventory. Schema:

      {
        "os": "windows" | "linux" | "darwin" | "unknown",
        "shell": "wsl-bash" | "cmd" | "powershell" | "bash" | "zsh" | "unknown",
        "wsl_available": bool,        # only relevant on Windows
        "wsl_distro": str | None,     # first available distro name, if any
        # E38 (2026-05-13) — capability inventory:
        "python_envs": [               # list, order-stable
          {
            "name": "windows-python" | "wsl-python3" | "system-python3" | ...,
            "path": "C:\\Users\\...\\python.exe" | "/usr/bin/python3" | ...,
            "version": "3.13.12" | None,
            "packages": {              # dict, KEY_PYTHON_PACKAGES keys only
              "httpx": True | False, "requests": True | False, ...,
            },
          },
          ...
        ],
        "cli_binaries": {              # dict, KEY_CLI_BINARIES keys only
          "git": "/usr/bin/git" | None, "docker": "..." | None, ...,
        },
      }

    Detection logic:
    - Windows + WSL with installed distro → shell="wsl-bash" (`bash`
      tool will route through `wsl -e bash -lc ...`).
    - Windows without working WSL → shell="cmd" (degraded mode; agents
      that need a shell are limited to cmd.exe semantics).
    - Linux → shell="bash".
    - macOS → shell="zsh" (default modern; bash also works).
    - Anything else → shell="unknown" (agents fall through to a
      best-effort prompt).

    E38 capability probes:
    - Each detected Python interpreter is invoked ONCE with a JSON-
      emitting probe that checks all `KEY_PYTHON_PACKAGES` in a
      single subprocess call (≤2s typical). Failures (timeout,
      interpreter crash, malformed JSON) downgrade to
      `version=None, packages={}` — never raises out.
    - CLI binaries use `shutil.which()` only (no subprocess
      execution) — pure path lookup, microseconds.

    All probes are cheap (≤5s timeout on the WSL distro check,
    ≤2s per Python probe) and cached at module level so re-calling
    is free within a session. Network and filesystem-write are NOT
    probed.

    Backward compat: older servers reading `client_platform` ignore
    the new `python_envs` / `cli_binaries` keys (dict.get pattern in
    runner._format_platform_block). Older clients (pre-E38 wheels)
    omit them entirely; the renderer handles missing keys gracefully.
    """
    if _CACHE is not None:
        return _CACHE
    info = _detect()
    globals()["_CACHE"] = info
    return info


_CACHE: dict[str, Any] | None = None


def _detect() -> dict[str, Any]:
    system = platform.system()
    if system == "Windows":
        info = _detect_windows()
    elif system == "Linux":
        info = {
            "os": "linux",
            "shell": "bash",
            "wsl_available": False,
            "wsl_distro": None,
        }
    elif system == "Darwin":
        info = {
            "os": "darwin",
            "shell": "zsh",
            "wsl_available": False,
            "wsl_distro": None,
        }
    else:
        info = {
            "os": "unknown",
            "shell": "unknown",
            "wsl_available": False,
            "wsl_distro": None,
        }
    # E38: layer capability detection on top of the OS/shell base.
    # Always runs (every OS path); failures degrade gracefully to
    # empty lists/dicts so the schema is always well-formed.
    info["python_envs"] = _detect_python_envs(info)
    info["cli_binaries"] = _detect_cli_binaries()
    return info


def _detect_python_envs(base_info: dict[str, Any]) -> list[dict[str, Any]]:
    """Inventory Python interpreters available to the agent + probe
    each for KEY_PYTHON_PACKAGES presence. Returns a list of env
    dicts in stable order (cache-friendly).

    On Windows-with-WSL, probes BOTH the Windows-native interpreter
    AND the WSL distro's `python3` because they have separate
    package universes — the 2026-05-13 incident traced exactly this
    asymmetry (WSL bash ran `python3` against the WSL env where
    httpx wasn't installed; then python_run ran the Windows env
    where it WAS, after a pip install).
    """
    envs: list[dict[str, Any]] = []
    seen_paths: set[str] = set()

    # 1) Native interpreters by name in PATH order.
    for name in ("python", "python3"):
        exe = shutil.which(name)
        if exe is None or exe in seen_paths:
            continue
        seen_paths.add(exe)
        envs.append(_probe_python_env(
            label=("windows-" if base_info.get("os") == "windows" else "system-") + name,
            executable=[exe],
        ))

    # 2) On Windows-with-WSL, also probe the WSL distro's python3
    # — different filesystem, different package universe. This is
    # the env `bash python3 ...` calls hit, which is DIFFERENT from
    # what `python_run` hits (latter uses Windows native python).
    #
    # NOTE: use `wsl --exec` (long form), NOT `wsl -e`. Empirically,
    # `wsl -e python3 -c "..."` from a non-TTY subprocess.run on
    # Windows hangs indefinitely waiting for stdin even with
    # stdin=DEVNULL (verified 2026-05-13). `wsl --exec` is documented
    # as equivalent but behaves correctly here. If the runtime ever
    # switches to a Linux wsl-compat layer (e.g. wslg, ssh-WSL), test
    # both forms before changing.
    if (
        base_info.get("os") == "windows"
        and base_info.get("wsl_available")
        and base_info.get("wsl_distro")
    ):
        envs.append(_probe_python_env(
            label="wsl-python3",
            executable=["wsl", "--exec", "python3"],
        ))

    return envs


def _probe_python_env(
    *, label: str, executable: list[str],
) -> dict[str, Any]:
    """Run ONE subprocess call against `executable` that emits a JSON
    line with version + per-package presence. Single call batches all
    KEY_PYTHON_PACKAGES checks; failure downgrades to empty/None.

    The probe uses `importlib.util.find_spec` rather than `import`
    because find_spec doesn't execute module init code — safer
    against side-effect-heavy packages."""
    # Build a one-line Python program that emits JSON. List of
    # packages is baked into the source so the subprocess gets it
    # inline (no env var, no temp file).
    #
    # CRITICAL: use SINGLE quotes around package names. `json.dumps`
    # would emit double quotes which get mangled when the arg passes
    # through wsl.exe's command-line parser on Windows (CreateProcess
    # → wsl.exe → WSL argv), causing the WSL probe to silently time
    # out. Verified 2026-05-13: same probe with double-quoted pkg
    # list times out via `wsl --exec python3 -c`; single-quoted form
    # works in <1s. Backslash + quote interpretation differs across
    # the two layers; sticking to single quotes inside the Python
    # source eliminates the ambiguity entirely.
    packages_repr = (
        "[" + ",".join(f"'{p}'" for p in KEY_PYTHON_PACKAGES) + "]"
    )
    probe = (
        "import importlib.util,sys,json;"
        f"pkgs={packages_repr};"
        "print(json.dumps({"
        "'version':'.'.join(map(str,sys.version_info[:3])),"
        "'packages':{p:importlib.util.find_spec(p) is not None for p in pkgs}"
        "}))"
    )
    cmd = list(executable) + ["-c", probe]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10,  # WSL bridge adds ~3-5s overhead on cold cache
            check=False,
            # stdin=DEVNULL prevents wsl.exe / native interpreters
            # from hanging on TTY-input waits in non-interactive
            # contexts (Claude Code's subprocess pipes are not TTYs).
            stdin=subprocess.DEVNULL,
        )
    except (subprocess.TimeoutExpired, OSError):
        return {
            "name": label,
            "path": " ".join(executable),
            "version": None,
            "packages": {},
        }

    if result.returncode != 0:
        return {
            "name": label,
            "path": " ".join(executable),
            "version": None,
            "packages": {},
        }

    # WSL outputs UTF-16-with-nulls on some Windows builds (same
    # quirk as `wsl --list` above). Strip nulls before parsing JSON.
    cleaned = result.stdout.replace("\x00", "").strip()
    try:
        payload = json.loads(cleaned)
    except json.JSONDecodeError:
        return {
            "name": label,
            "path": " ".join(executable),
            "version": None,
            "packages": {},
        }

    # Resolve the actual interpreter path — for WSL the `executable`
    # is `wsl -e python3` (not a real path); ask the interpreter
    # itself where it lives. Cheap because we already have the
    # subprocess available... actually for simplicity, leave path as
    # the command string. The agent can read it as such.
    return {
        "name": label,
        "path": " ".join(executable),
        "version": payload.get("version"),
        "packages": {
            p: bool(payload.get("packages", {}).get(p, False))
            for p in KEY_PYTHON_PACKAGES
        },
    }


def _detect_cli_binaries() -> dict[str, str | None]:
    """Locate each KEY_CLI_BINARIES entry on PATH. Pure shutil.which —
    no subprocess. Returns name → absolute path (or None if missing).

    Order in the returned dict matches KEY_CLI_BINARIES — Python
    dict insertion order is preserved since 3.7, so this is byte-
    stable when rendered.
    """
    return {name: shutil.which(name) for name in KEY_CLI_BINARIES}


def _detect_windows() -> dict[str, Any]:
    """Windows-specific probe. WSL availability + first installed distro
    decide whether `bash` will work."""
    has_wsl_exe = shutil.which("wsl") is not None
    if not has_wsl_exe:
        return {
            "os": "windows",
            "shell": "cmd",
            "wsl_available": False,
            "wsl_distro": None,
        }
    # WSL is on PATH. Verify a distro is actually installed — `wsl
    # --list --quiet` returns the names one per line. Empty stdout =
    # no distro = bash will fail.
    try:
        result = subprocess.run(
            ["wsl", "--list", "--quiet"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return {
            "os": "windows",
            "shell": "cmd",
            "wsl_available": False,
            "wsl_distro": None,
        }
    if result.returncode != 0:
        return {
            "os": "windows",
            "shell": "cmd",
            "wsl_available": False,
            "wsl_distro": None,
        }
    # Decode UTF-16 if needed — `wsl --list` on some Windows builds
    # outputs UTF-16. shutil.which gave us the same wsl.exe; mismatched
    # encoding shows as null bytes in stdout. Strip nulls + whitespace.
    cleaned = result.stdout.replace("\x00", "").strip()
    distros = [
        line.strip() for line in cleaned.splitlines()
        if line.strip()
    ]
    if not distros:
        return {
            "os": "windows",
            "shell": "cmd",
            "wsl_available": False,
            "wsl_distro": None,
        }
    return {
        "os": "windows",
        "shell": "wsl-bash",
        "wsl_available": True,
        "wsl_distro": distros[0],
    }
