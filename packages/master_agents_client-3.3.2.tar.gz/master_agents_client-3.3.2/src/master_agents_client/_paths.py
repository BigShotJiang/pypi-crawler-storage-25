"""Resolve the master_agents config + state directory.

Holds remote.yaml (login config), server.toml (bearer tokens),
memory.db (sqlite agent memory), and checkpoints/ (coder pipeline
state).

Resolution order (first match wins):
  1. ``MASTER_AGENTS_HOME`` env var — explicit override.
  2. Walk up from cwd; first ancestor with a ``.master_agents/``
     dir wins. This makes the config travel with the repo (e.g.,
     OneDrive- or Google-Drive-synced ``platforms_os/.master_agents/``)
     so multiple machines share the same login + memory by default.
  3. Fallback: ``~/.master_agents/`` — legacy / out-of-repo invocations.
"""

from __future__ import annotations

import os
from pathlib import Path


def master_agents_home() -> Path:
    """Return the master_agents config + state directory."""
    override = os.environ.get("MASTER_AGENTS_HOME")
    if override:
        return Path(override).expanduser()
    cwd = Path.cwd()
    for base in (cwd, *cwd.parents):
        candidate = base / ".master_agents"
        if candidate.is_dir():
            return candidate
    return Path.home() / ".master_agents"


def load_platforms_env_files() -> None:
    """Auto-load .env files walking the FULL chain from cwd to root.
    At each ancestor dir, loads (if present): ``.env.development``,
    ``.env``, ``vps/.env.production``. Innermost values win
    (``override=False`` so earlier loads aren't clobbered).

    Why walk the full chain instead of stopping at the first hit:
    secrets like ``MASTER_AGENTS_API_TOKEN`` live in
    ``platforms_os/vps/.env.production``, but inner platforms (e.g.,
    ``master_agents_os/.env.development``) hold model API keys. Both
    are needed; stopping at the first hit would skip whichever lives
    higher up.
    """
    try:
        from dotenv import load_dotenv
    except ImportError:  # dotenv is a runtime dep, but be defensive
        return
    cwd = Path.cwd()
    for base in (cwd, *cwd.parents):
        for candidate in (
            base / ".env.development",
            base / ".env",
            base / "vps" / ".env.production",
        ):
            if candidate.exists():
                load_dotenv(candidate, override=False)
