"""Bundled Marp themes for the formatting_designer pipeline.

CSS files in this directory are loaded at runtime by
`tools.create_pptx_from_md` and `graph_steps.render_deck_plan` and
passed to the Marp CLI via `--theme-set`.
"""

from __future__ import annotations

from pathlib import Path

_THEMES_DIR = Path(__file__).resolve().parent

# Map of theme name -> CSS file path. Adding a theme = drop a .css file
# in this directory and add the entry here.
BUNDLED_THEMES: dict[str, Path] = {
    "breakthrough": _THEMES_DIR / "breakthrough.css",
}


def load_theme_css(name: str) -> str | None:
    """Return the CSS source for a bundled theme name, or None if the
    theme isn't bundled (Marp built-ins like 'gaia' return None — the
    CLI handles them via `--theme` instead).
    """
    path = BUNDLED_THEMES.get(name)
    if path is None or not path.exists():
        return None
    return path.read_text(encoding="utf-8")
