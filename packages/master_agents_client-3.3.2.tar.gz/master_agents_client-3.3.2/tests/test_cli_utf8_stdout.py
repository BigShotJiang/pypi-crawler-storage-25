"""Wheel-side smoke test: the carved CLI ships the UTF-8 stdout
reconfigure helper.

Customer-facing failure mode: on Windows, default cp1252 stdout
crashes when an agent answer contains arrows / em-dashes / box-
drawing chars. The wheel's `agents` entry point must reconfigure
to UTF-8 before any print fires.
"""
from __future__ import annotations

import io
import sys


def test_carved_cli_exposes_ensure_utf8_helper():
    """The wheel's cli.py must define _ensure_utf8_stdout — proves
    sync_client.py's CLI_ENTRY shipped the helper to customers."""
    from master_agents_client import cli

    assert hasattr(cli, "_ensure_utf8_stdout"), (
        "wheel's cli.py is missing _ensure_utf8_stdout — the customer-"
        "facing CLI will crash on cp1252 Windows when agents emit "
        "arrows / em-dashes. Update CLI_ENTRY in scripts/sync_client.py."
    )


def test_carved_helper_actually_reconfigures(monkeypatch):
    """Behavioral check: the wheel's helper does the same thing as
    canonical — flips a cp1252 TextIOWrapper to utf-8."""
    from master_agents_client.cli import _ensure_utf8_stdout

    fake_buf = io.BytesIO()
    fake_stdout = io.TextIOWrapper(fake_buf, encoding="cp1252", errors="strict")
    monkeypatch.setattr(sys, "stdout", fake_stdout)
    monkeypatch.setattr(sys, "stderr", fake_stdout)

    _ensure_utf8_stdout()
    assert sys.stdout.encoding.lower() == "utf-8"
    sys.stdout.write("→ arrow\n")
    sys.stdout.flush()
    assert "→".encode("utf-8") in fake_buf.getvalue()
