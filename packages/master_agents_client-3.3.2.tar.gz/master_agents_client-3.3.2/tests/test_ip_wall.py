"""IP-wall enforcement.

The whole point of master_agents_client is to ship to remote users
without exposing the server-side IP (graph runners, RAG retrievers,
agent specs, prompts). The wheel must therefore contain ZERO references
to the internal master_agents package.

These tests parse every .py file shipped in the client wheel and assert:
  1. No `import master_agents` / `from master_agents` (server import).
  2. No relative `..` imports that would walk above the package root.
  3. tools/ exposes exactly the agreed client-side tool set.
  4. The DEFAULT_CLIENT_SIDE_TOOLS constant matches the README claims.

If any of these fail, the carve-out has regressed and the wheel
cannot be shipped.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest


PKG_ROOT = (
    Path(__file__).resolve().parents[1]
    / "src" / "master_agents_client"
)


def _all_py_files() -> list[Path]:
    return sorted(p for p in PKG_ROOT.rglob("*.py")
                  if "__pycache__" not in p.parts)


@pytest.mark.parametrize("py_file", _all_py_files(), ids=lambda p: p.name)
def test_no_master_agents_imports(py_file: Path) -> None:
    """No file may import the server-side master_agents package."""
    src = py_file.read_text(encoding="utf-8")
    tree = ast.parse(src, filename=str(py_file))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                assert not alias.name.startswith("master_agents") or alias.name.startswith("master_agents_client"), (
                    f"{py_file.name}: forbidden import "
                    f"`import {alias.name}` — server IP must not leak "
                    f"into the client wheel"
                )
        elif isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            # node.level=0 means absolute. >0 means relative (`.foo`,
            # `..bar`). Both are checked.
            if node.level == 0 and mod.startswith("master_agents") and not mod.startswith("master_agents_client"):
                raise AssertionError(
                    f"{py_file.name}: forbidden import "
                    f"`from {mod} import ...` — server IP must not "
                    f"leak into the client wheel"
                )


@pytest.mark.parametrize("py_file", _all_py_files(), ids=lambda p: p.name)
def test_relative_imports_stay_in_package(py_file: Path) -> None:
    """No `from ...x import ...` that would escape the package root.

    `from ..themes import ...` is allowed (themes/ is inside the
    package). Anything climbing higher (`...` or beyond) would only
    work in a multi-package layout — which we explicitly don't have.
    """
    src = py_file.read_text(encoding="utf-8")
    tree = ast.parse(src, filename=str(py_file))
    rel_to_pkg = py_file.relative_to(PKG_ROOT)
    depth = len(rel_to_pkg.parts) - 1  # 0 for top-level, 1 for tools/, etc.
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.level > 0:
            assert node.level <= depth + 1, (
                f"{py_file}: relative import level={node.level} "
                f"escapes package root (file depth={depth})"
            )


@pytest.mark.parametrize("py_file", _all_py_files(), ids=lambda p: p.name)
def test_relative_imports_resolve_to_shipped_files(py_file: Path) -> None:
    """Every `from .X import Y` and `from ..X import Y` in the client
    tree must resolve to a module that's actually present in the
    client tree. Catches the case where a canonical-source edit
    introduces a lazy import (e.g. inside a function body) and the
    sync-script file lists weren't updated to ship the dependency.

    The smoke tests don't catch this because they only exercise top-
    level imports, not handler bodies. The IP-wall AST scan doesn't
    catch it either — it only checks that absolute imports don't name
    `master_agents.*`. A `from ._missing import foo` looks fine to
    both.
    """
    src = py_file.read_text(encoding="utf-8")
    tree = ast.parse(src, filename=str(py_file))
    file_dir = py_file.parent
    for node in ast.walk(tree):
        if not isinstance(node, ast.ImportFrom):
            continue
        if node.level == 0:
            continue  # absolute — covered by other tests
        # Walk up `level` directories from file_dir to compute the
        # base for resolving the dotted module.
        base = file_dir
        for _ in range(node.level - 1):
            base = base.parent
        target_mod = node.module or ""
        if not target_mod:
            # `from . import X` — X is either a submodule (file/pkg)
            # or an attribute exported by base's __init__.py
            # (e.g. `__version__`). Only flag missing submodules.
            init_path = base / "__init__.py"
            init_text = (
                init_path.read_text(encoding="utf-8")
                if init_path.exists() else ""
            )
            for alias in node.names:
                child = base / alias.name
                as_module = (
                    (child.with_suffix(".py")).exists()
                    or (child / "__init__.py").exists()
                )
                # Attribute defined in __init__.py — pattern-match the
                # common forms (assignment, def, class, import as X).
                as_attr = bool(re.search(
                    rf"^\s*(?:{re.escape(alias.name)}\s*[:=]"
                    rf"|def\s+{re.escape(alias.name)}\b"
                    rf"|class\s+{re.escape(alias.name)}\b"
                    rf"|import\s+\S+\s+as\s+{re.escape(alias.name)}\b)",
                    init_text,
                    re.MULTILINE,
                ))
                assert as_module or as_attr, (
                    f"{py_file.name}: `from . import {alias.name}` "
                    f"resolves to neither a submodule at {child} "
                    f"nor an attribute of {init_path} — "
                    f"sync_client.py file lists may be missing this"
                )
            continue
        # `from .a.b import X` — target is base/a/b
        parts = target_mod.split(".")
        target = base
        for p in parts:
            target = target / p
        # Either it's a module file or a package directory.
        as_file = target.with_suffix(".py")
        as_pkg = target / "__init__.py"
        assert as_file.exists() or as_pkg.exists(), (
            f"{py_file.name}: `from {'.' * node.level}{target_mod} "
            f"import ...` resolves to {target} which doesn't exist "
            f"in the shipped tree — sync_client.py file lists are "
            f"missing this module (or a transitive dep of it)"
        )


@pytest.mark.parametrize("py_file", _all_py_files(), ids=lambda p: p.name)
def test_no_internal_module_strings(py_file: Path) -> None:
    """Even string content (docstrings, comments, error messages)
    must not name internal master_agents.* modules. Such leaks
    don't break runtime but reveal server-package layout to
    end users."""
    src = py_file.read_text(encoding="utf-8")
    # Catch ``master_agents.<x>`` where <x> is NOT ``client``.
    matches = re.findall(r"\bmaster_agents\.(?!client\b)\w+", src)
    assert not matches, (
        f"{py_file.name}: leaks internal module names {matches!r} — "
        f"sync_client.py's scrubber should have caught this"
    )
    # Slash form: ``master_agents/X`` in URL paths, repo paths,
    # UA strings, etc. Allow:
    #   - ``master_agents_os`` and ``master_agents_client`` (legit names)
    #   - ``.master_agents/*`` user-config dotfile dir (legit public
    #     surface — that's where remote.yaml + active_session.json
    #     are stored on the customer's box)
    # The leading negative lookbehind ``(?<![.\w])`` excludes both
    # word continuations (``master_agents_os``) and the dotted user-
    # config form (``.master_agents/``).
    slash = re.findall(
        r"(?<![.\w])master_agents/(?!os\b|client\b)[\w/.-]+",
        src,
    )
    assert not slash, (
        f"{py_file.name}: leaks internal slash paths {slash!r}"
    )


# Server-only env vars that should never appear in client source.
# NOTE: MASTER_AGENTS_API_TOKEN and MASTER_AGENTS_HOME are
# customer-facing knobs — the wheel reads them via os.environ.get
# and the customer needs to set them. They are deliberately NOT in
# this list.
SERVER_ONLY_ENV_VARS = frozenset({
    "MASTER_AGENTS_DOWNLOAD_SECRET",
    "MASTER_AGENTS_DOWNLOAD_TTL_SECONDS",
    "MASTER_AGENTS_OUTPUTS_DIR",
    "MASTER_AGENTS_OUTPUTS_MAX_FILES",
    "MASTER_AGENTS_OUTPUTS_MAX_BYTES",
    "MASTER_AGENTS_PREMIUM",
    "MASTER_AGENTS_DESIGNER_URL",
    "MASTER_AGENTS_DB_URL",
})


@pytest.mark.parametrize("py_file", _all_py_files(), ids=lambda p: p.name)
def test_no_server_only_env_vars(py_file: Path) -> None:
    """Server-side env-var names reveal server architecture
    (HMAC signing, sandbox quotas, premium gates, designer sidecar).
    None should appear in shipped client files."""
    src = py_file.read_text(encoding="utf-8")
    leaks = [v for v in SERVER_ONLY_ENV_VARS if v in src]
    assert not leaks, (
        f"{py_file.name}: leaks server env-var names {leaks!r} — "
        f"these reveal server-side architecture"
    )


# Internal milestone codenames. None should remain in shipped source
# after _scrub runs.
@pytest.mark.parametrize("py_file", _all_py_files(), ids=lambda p: p.name)
def test_no_internal_codenames(py_file: Path) -> None:
    """`B22.3`, `C18.1`, `wave 8`, `amendment A26` style internal
    milestone names are project-development cadence markers and have
    no public meaning. They should be stripped during sync."""
    src = py_file.read_text(encoding="utf-8")
    # Be specific: only the parenthetical / inline-comment forms,
    # not legitimate identifiers like `B40` in numeric strings.
    patterns = [
        r"\(B\d+(?:\.\d+)?\b",        # (B22.3)
        r"\(C\d+(?:\.\d+)?\b",        # (C18.1)
        r"\bwave\s+\d+\b",             # wave 8
        r"\bamendment\s+A\d+\b",       # amendment A26
        r"\bdesign\s+amendment\s+A\d+\b",
    ]
    leaks: list[str] = []
    for pat in patterns:
        leaks.extend(re.findall(pat, src, flags=re.IGNORECASE))
    assert not leaks, (
        f"{py_file.name}: contains internal codenames {leaks!r} — "
        f"_scrub() should be stripping these"
    )


def test_no_internal_doc_references() -> None:
    """Internal docs (HARNESS_ROADMAP, COST_DISCIPLINE, RAG_TUNING,
    HANDOFF, CHANGELOG, CAPABILITIES, MASTER_ARCHITECTURE,
    CONSTITUTION) must not be referenced in shipped client code.

    A reference here would either ship the doc itself (leak) or 404
    at runtime (broken)."""
    forbidden = [
        "HARNESS_ROADMAP",
        "RELIABILITY_ROADMAP",
        "COST_DISCIPLINE",
        "CACHE_FRIENDLY_DESIGN",
        "RAG_TUNING",
        "HANDOFF.md",
        "CAPABILITIES.md",
        "MASTER_ARCHITECTURE",
        "CONSTITUTION.md",
    ]
    for py_file in _all_py_files():
        src = py_file.read_text(encoding="utf-8")
        for token in forbidden:
            assert token not in src, (
                f"{py_file.name}: references internal doc {token!r} — "
                f"strip the reference before shipping"
            )


def test_builtins_subset_of_default_client_side_tools() -> None:
    """The client BUILTINS must be a subset of DEFAULT_CLIENT_SIDE_TOOLS.

    Anything in BUILTINS but not in DEFAULT_CLIENT_SIDE_TOOLS would be
    advertised by the client as available without server agreement —
    routing would silently break."""
    from master_agents_client.tools import BUILTINS
    from master_agents_client.remote_client import DEFAULT_CLIENT_SIDE_TOOLS

    builtin_names = set(BUILTINS.keys())
    extras = builtin_names - DEFAULT_CLIENT_SIDE_TOOLS
    assert not extras, (
        f"BUILTINS contains tools not in DEFAULT_CLIENT_SIDE_TOOLS: "
        f"{sorted(extras)}"
    )


# Tools that the server-side DEFAULT_CLIENT_SIDE_TOOLS list advertises
# but the client deliberately omits because they need a server-only
# resource. Keep this list MINIMAL — every entry is a route the
# server may try to delegate that will fail with "tool not available".
KNOWN_CLIENT_OMISSIONS = frozenset({
    # vision_describe needs the server's vision provider client.
    "vision_describe",
})


def test_builtins_covers_advertised_set() -> None:
    """The flip side of the subset test: everything the client
    side advertises must have a handler. Otherwise the server will
    route a tool to us and we'll return ``tool not available`` —
    presented to the user as an agent crash."""
    from master_agents_client.tools import BUILTINS
    from master_agents_client.remote_client import DEFAULT_CLIENT_SIDE_TOOLS

    expected = DEFAULT_CLIENT_SIDE_TOOLS - KNOWN_CLIENT_OMISSIONS
    missing = expected - set(BUILTINS.keys())
    assert not missing, (
        f"client missing handlers for advertised tools: "
        f"{sorted(missing)}"
    )


def test_no_server_only_tools_in_client_builtins() -> None:
    """ask_user, web_search, sql_query, corpus_search, memory_*,
    scratchpad_*, notebook_*, excel_propose_ops, pptx_propose_ops
    must NEVER appear in the client BUILTINS — they require server
    resources (DB, provider keys, session-scope stores)."""
    from master_agents_client.tools import BUILTINS

    forbidden = {
        "ask_user", "web_search", "sql_query", "corpus_search",
        "memory_get", "memory_set", "memory_list", "memory_delete",
        "scratchpad_append", "scratchpad_read",
        "notebook_list", "notebook_read", "notebook_search",
        "excel_propose_ops", "pptx_propose_ops",
    }
    leaks = forbidden & set(BUILTINS.keys())
    assert not leaks, (
        f"Server-only tools must not be in client BUILTINS: "
        f"{sorted(leaks)}"
    )
