"""Smoke imports — every public surface module must import clean.

A passing run here proves the wheel won't ImportError on first use."""

from __future__ import annotations


def test_top_level_package_imports() -> None:
    import master_agents_client
    assert master_agents_client.__version__


def test_cli_parser_builds() -> None:
    from master_agents_client.cli import build_parser
    parser = build_parser()
    args = parser.parse_args(["remote", "logout"])
    assert args.command == "remote"
    assert args.remote_command == "logout"


def test_remote_cli_module_loads() -> None:
    from master_agents_client.remote_cli import _cmd_remote
    assert callable(_cmd_remote)


def test_remote_client_constants() -> None:
    from master_agents_client.remote_client import (
        DEFAULT_CLIENT_SIDE_TOOLS,
        SERVER_ONLY_TOOLS,
        RemoteToolExecutor,
    )
    # Sanity: the known split.
    assert "read_file" in DEFAULT_CLIENT_SIDE_TOOLS
    assert "sql_query" in SERVER_ONLY_TOOLS
    assert DEFAULT_CLIENT_SIDE_TOOLS.isdisjoint(SERVER_ONLY_TOOLS)
    assert RemoteToolExecutor


def test_tracer_module_loads() -> None:
    from master_agents_client.tracer import ConsoleTracer, Tracer
    assert ConsoleTracer
    assert Tracer


def test_tools_registry_populated() -> None:
    from master_agents_client.tools import BUILTINS, Tool
    assert len(BUILTINS) >= 25
    # Every entry is a Tool instance.
    assert all(isinstance(t, Tool) for t in BUILTINS.values())
