"""Wheel-side test for the `interactive` field on POST /sessions.

`RemoteSessionClient.run()` is the one-shot path used by
`agents remote run`; it cannot answer ask_user, so it must send
interactive=False to the server. `RemoteSessionClient.open()`
(used by `agents remote chat`) is interactive by default.

Captured POST body via httpx.MockTransport — no live server needed.
"""
from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from master_agents_client.remote_cli import RemoteSessionClient


def _capture_transport(captured: list[dict]) -> httpx.MockTransport:
    """MockTransport that records every POST body and returns a
    canned /sessions response so the client's open() path completes
    without erroring on the response shape."""

    def _handler(request: httpx.Request) -> httpx.Response:
        body: dict = {}
        if request.content:
            try:
                body = json.loads(request.content.decode())
            except (json.JSONDecodeError, UnicodeDecodeError):
                body = {"_raw": request.content.decode(errors="replace")}
        captured.append({
            "method": request.method,
            "url": str(request.url),
            "body": body,
        })
        # Canned response covering the open()/run() call paths:
        if request.url.path == "/sessions" and request.method == "POST":
            return httpx.Response(
                200,
                json={
                    "session_id": "sess_test_id",
                    "session_nonce": "nonce_test",
                    "agent_name": body.get("agent_name", ""),
                    "limits": {
                        "max_concurrent_agents": 1,
                        "max_spawn_depth": 1,
                        "max_total_steps": 1,
                    },
                },
            )
        if request.url.path.endswith("/turn") and request.method == "POST":
            return httpx.Response(200, json={
                "final": {"text": "done", "tokens": {}},
                "events": [],
            })
        if request.method == "DELETE":
            return httpx.Response(200, json={"status": "deleted"})
        return httpx.Response(404, json={"detail": "unmocked"})

    return httpx.MockTransport(_handler)


async def test_run_sends_interactive_false(tmp_path: Path) -> None:
    """One-shot client.run() must declare interactive=False so the
    server gates ask_user pre-dispatch. Without this, the agent would
    block forever on a question no one is listening for."""
    captured: list[dict] = []
    client = RemoteSessionClient(
        base_url="http://t",
        token=None,
        cwd=tmp_path,
        writable_paths=[str(tmp_path)],
        transport=_capture_transport(captured),
    )
    # The /turn streaming response shape isn't perfectly mocked here
    # (we only care about the /sessions POST body). Swallow any
    # downstream error — the assertion is on the already-captured
    # POST /sessions body, which fires BEFORE turn() runs.
    try:
        await client.run("any_agent", "hi")
    except Exception:
        pass

    sessions_posts = [
        c for c in captured
        if c["method"] == "POST" and c["url"].endswith("/sessions")
    ]
    assert len(sessions_posts) == 1, (
        f"expected exactly one POST /sessions; got {len(sessions_posts)}"
    )
    body = sessions_posts[0]["body"]
    assert "interactive" in body, (
        f"POST /sessions body must include the `interactive` field; "
        f"got keys: {sorted(body.keys())}"
    )
    assert body["interactive"] is False, (
        f"client.run() one-shot path must send interactive=False; "
        f"got body['interactive']={body['interactive']!r}"
    )


async def test_open_default_interactive_true(tmp_path: Path) -> None:
    """client.open() (used by chat REPL) defaults interactive=True so
    the agent can ask clarifying questions and the REPL can answer."""
    captured: list[dict] = []
    client = RemoteSessionClient(
        base_url="http://t",
        token=None,
        cwd=tmp_path,
        writable_paths=[str(tmp_path)],
        transport=_capture_transport(captured),
    )
    try:
        await client.open("any_agent")
        sessions_posts = [
            c for c in captured
            if c["method"] == "POST" and c["url"].endswith("/sessions")
        ]
        assert len(sessions_posts) == 1
        body = sessions_posts[0]["body"]
        assert body.get("interactive") is True, (
            f"client.open() must default interactive=True; got "
            f"body['interactive']={body.get('interactive')!r}"
        )
    finally:
        await client.close()


async def test_open_explicit_interactive_false(tmp_path: Path) -> None:
    """Programmatic callers can pass interactive=False explicitly to
    open() — same effect as run() but with control over the turn loop.
    Verifies the kwarg propagates."""
    captured: list[dict] = []
    client = RemoteSessionClient(
        base_url="http://t",
        token=None,
        cwd=tmp_path,
        writable_paths=[str(tmp_path)],
        transport=_capture_transport(captured),
    )
    try:
        await client.open("any_agent", interactive=False)
        body = next(
            c["body"] for c in captured
            if c["method"] == "POST" and c["url"].endswith("/sessions")
        )
        assert body["interactive"] is False
    finally:
        await client.close()
