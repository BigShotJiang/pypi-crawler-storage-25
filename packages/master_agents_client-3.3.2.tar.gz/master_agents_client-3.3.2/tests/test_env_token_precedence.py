"""Regression test for the second pre-merge review's C1 finding.

The wheel's load_remote_config must read MASTER_AGENTS_API_TOKEN
from the env (canonical c819d82 contract). Earlier sync_client.py
included this name in its env-var redaction list, so after scrub
the carved code read os.environ.get("an environment flag") and
silently broke the env-wins-over-yaml precedence.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from unittest.mock import patch


def test_env_token_wins_over_yaml() -> None:
    from master_agents_client.remote_cli import (
        RemoteConfig,
        load_remote_config,
        save_remote_config,
    )
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "remote.yaml"
        save_remote_config(
            path,
            RemoteConfig(
                server="https://example.com",
                token="tok_in_yaml",
                default_master=None,
                cwd_mode="auto",
                writable_paths=["."],
            ),
        )
        with patch.dict(
            os.environ, {"MASTER_AGENTS_API_TOKEN": "tok_from_env"},
            clear=False,
        ):
            cfg = load_remote_config(path)
        assert cfg.token == "tok_from_env", (
            f"env token must win — got {cfg.token!r}. If carved code "
            f"reads os.environ.get('an environment flag'), the env-var "
            f"scrub list in scripts/sync_client.py over-redacted."
        )


# Note: a "yaml fallback when env unset" test is intentionally NOT
# included here. The wheel's load_remote_config calls
# load_platforms_env_files() which walks ancestor dirs auto-loading
# .env files; running tests from inside the repo always surfaces
# vps/.env.production's MASTER_AGENTS_API_TOKEN regardless of
# monkeypatch.delenv. The fallback-precedence test lives in the
# server-side test suite (test_remote_cli_client.py) where it can
# control the env-load path.
