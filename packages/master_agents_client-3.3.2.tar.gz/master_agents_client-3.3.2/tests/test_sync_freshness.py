"""CI-side check that scripts/sync_client.py output is up to date.

Run the sync script in a temp dir and compare to the checked-in
client tree. If they differ, the dev forgot to re-run the script
after editing canonical master_agents source. Fail loudly in CI
so we never ship a stale wheel.
"""

from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[3]
CHECKED_IN = REPO_ROOT / "packages" / "py-client" / "src" / "master_agents_client"
SYNC_SCRIPT = REPO_ROOT / "scripts" / "sync_client.py"


def _files_in(root: Path) -> dict[Path, bytes]:
    out: dict[Path, bytes] = {}
    for p in root.rglob("*"):
        if "__pycache__" in p.parts:
            continue
        if p.is_file():
            out[p.relative_to(root)] = p.read_bytes()
    return out


@pytest.mark.skipif(
    not SYNC_SCRIPT.exists() or not (REPO_ROOT / "packages" / "py" / "src" / "master_agents").exists(),
    reason="canonical source tree not present",
)
def test_sync_client_output_matches_checked_in() -> None:
    """Running scripts/sync_client.py must produce a byte-identical
    tree to what's currently checked in. If this fails, run:

        python scripts/sync_client.py

    and commit the result."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        regen_dir = tmp_path / "regen"

        # Run sync into a tmp dir — never touch the working tree.
        result = subprocess.run(
            [sys.executable, str(SYNC_SCRIPT), "--out", str(regen_dir)],
            cwd=str(REPO_ROOT),
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, (
            f"sync_client.py failed:\nstdout: {result.stdout}"
            f"\nstderr: {result.stderr}"
        )

        regenerated = _files_in(regen_dir)
        original = _files_in(CHECKED_IN)

        # Compare keys.
        only_in_orig = sorted(set(original) - set(regenerated))
        only_in_new = sorted(set(regenerated) - set(original))
        assert not only_in_orig, (
            f"files removed by sync (canonical source likely deleted): "
            f"{only_in_orig}"
        )
        assert not only_in_new, (
            f"files added by sync (canonical source has new files): "
            f"{only_in_new}"
        )

        # Compare bytes for shared files.
        diffs = [str(rel) for rel in regenerated
                 if regenerated[rel] != original[rel]]
        assert not diffs, (
            f"sync_client output differs from checked-in: {diffs}\n"
            f"Run `python scripts/sync_client.py` and commit."
        )
