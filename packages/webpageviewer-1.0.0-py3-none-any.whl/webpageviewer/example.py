import streamlit as st
from streamlit_web_page_viewer import web_page_viewer

st.set_page_config(page_title="Web Page Viewer", layout="wide")
st.title("Web Page Viewer Demo")

result = web_page_viewer(
    url="https://example.com",
    title="Demo",
    key="web_page_viewer_demo",
    height=700,
)

st.write(result)
