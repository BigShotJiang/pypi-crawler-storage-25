"""Evaluation: metrics and plotting."""

from .metrics import compute_all_metrics
from .plotting import generate_all_figures
