"""Publication-quality figure generation for PRISM.

Figures follow NeurIPS style: matplotlib, fontsize=8, colorblind palette,
no titles, (a)/(b)/(c)/(d) labels, vector PDF, textwidth=5.5in.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

# Colorblind-friendly palette (Okabe-Ito)
PALETTE = {
    "prism": "#0072B2",
    "a1_nebula": "#E69F00",
    "a2_context": "#009E73",
    "a3_latent": "#CC79A7",
    "a5_pseudobulk": "#D55E00",
    "a6_nbglm": "#56B4E9",
    "null": "#999999",
    "fixed_de": "#F0E442",
    "context_de": "#0072B2",
}

FIGSIZE_FULL = (5.5, 4.5)  # Full width
FIGSIZE_HALF = (2.75, 2.5)  # Half width
DPI = 300
FONTSIZE = 8


def set_style():
    """Set publication figure style."""
    plt.rcParams.update({
        "font.size": FONTSIZE,
        "axes.labelsize": FONTSIZE,
        "axes.titlesize": FONTSIZE,
        "xtick.labelsize": FONTSIZE - 1,
        "ytick.labelsize": FONTSIZE - 1,
        "legend.fontsize": FONTSIZE - 1,
        "figure.dpi": DPI,
        "savefig.dpi": DPI,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.05,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })
    sns.set_palette(list(PALETTE.values()))


def generate_all_figures(
    results_dir: str | Path,
    output_dir: str | Path,
    simulation_results: Optional[dict] = None,
    rosmap_results: Optional[dict] = None,
):
    """Generate all paper figures.

    Parameters
    ----------
    results_dir : directory containing result files.
    output_dir : directory for output figures.
    simulation_results : pre-loaded simulation results dict.
    rosmap_results : pre-loaded ROSMAP results dict.
    """
    set_style()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if simulation_results is not None:
        fig1_simulation(simulation_results, output_dir / "figure1.pdf")

    if rosmap_results is not None:
        fig2_rosmap(rosmap_results, output_dir / "figure2.pdf")


def fig1_simulation(results: dict, output_path: Path):
    """Generate Figure 1: simulation results.

    (a) AUC of q_ij vs rho
    (b) Effect sharpening boxplot
    (c) Power curves vs theta_strength
    (d) Histogram of q_ij colored by true d_ij
    """
    fig = plt.figure(figsize=FIGSIZE_FULL)
    gs = gridspec.GridSpec(2, 2, hspace=0.35, wspace=0.35)

    # (a) AUC vs rho
    ax_a = fig.add_subplot(gs[0, 0])
    if "auc_vs_rho" in results:
        _plot_auc_vs_rho(ax_a, results["auc_vs_rho"])
    ax_a.text(-0.15, 1.05, "(a)", transform=ax_a.transAxes, fontweight="bold", fontsize=FONTSIZE)

    # (b) Sharpening boxplot
    ax_b = fig.add_subplot(gs[0, 1])
    if "sharpening" in results:
        _plot_sharpening(ax_b, results["sharpening"])
    ax_b.text(-0.15, 1.05, "(b)", transform=ax_b.transAxes, fontweight="bold", fontsize=FONTSIZE)

    # (c) Power curves
    ax_c = fig.add_subplot(gs[1, 0])
    if "power_curves" in results:
        _plot_power_curves(ax_c, results["power_curves"])
    ax_c.text(-0.15, 1.05, "(c)", transform=ax_c.transAxes, fontweight="bold", fontsize=FONTSIZE)

    # (d) q histogram
    ax_d = fig.add_subplot(gs[1, 1])
    if "q_histogram" in results:
        _plot_q_histogram(ax_d, results["q_histogram"])
    ax_d.text(-0.15, 1.05, "(d)", transform=ax_d.transAxes, fontweight="bold", fontsize=FONTSIZE)

    fig.savefig(output_path, format="pdf")
    plt.close(fig)


def _plot_auc_vs_rho(ax, data: dict):
    """Panel (a): AUC of q_ij vs rho, one line per (m, n) setting."""
    for label, vals in data.items():
        ax.plot(vals["rho"], vals["auc"], marker="o", markersize=3, label=label)
    ax.set_xlabel(r"$\rho$ (disease prevalence)")
    ax.set_ylabel("AUC (q vs d)")
    ax.set_ylim(0.4, 1.05)
    ax.legend(frameon=False, fontsize=FONTSIZE - 2)


def _plot_sharpening(ax, data: dict):
    """Panel (b): Effect sharpening boxplot."""
    labels = list(data.keys())
    values = [data[k] for k in labels]
    bp = ax.boxplot(values, labels=labels, patch_artist=True, widths=0.5)
    colors = [PALETTE.get("prism", "#0072B2"), PALETTE.get("a1_nebula", "#E69F00")]
    for patch, color in zip(bp["boxes"], colors * 10):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    ax.set_ylabel(r"$|\hat{\Delta} / \Delta^*|$")
    ax.axhline(1.0, color="gray", linestyle="--", linewidth=0.5)


def _plot_power_curves(ax, data: dict):
    """Panel (c): Power curves, x=theta_strength, y=sensitivity."""
    for method, vals in data.items():
        color = PALETTE.get(method, "#333333")
        ax.plot(vals["theta"], vals["power"], marker="o", markersize=3,
                label=method, color=color)
    ax.set_xlabel(r"$\|\theta\|$ (context effect strength)")
    ax.set_ylabel("Power (FDR 0.05)")
    ax.set_ylim(-0.05, 1.05)
    ax.legend(frameon=False, fontsize=FONTSIZE - 2)


def _plot_q_histogram(ax, data: dict):
    """Panel (d): Histogram of q_ij colored by true d_ij."""
    q_d0 = data.get("q_d0", [])
    q_d1 = data.get("q_d1", [])
    bins = np.linspace(0, 1, 40)
    ax.hist(q_d0, bins=bins, alpha=0.6, color=PALETTE["null"], label="d=0", density=True)
    ax.hist(q_d1, bins=bins, alpha=0.6, color=PALETTE["context_de"], label="d=1", density=True)
    ax.set_xlabel(r"$q_{ij}$")
    ax.set_ylabel("Density")
    ax.legend(frameon=False)


def fig2_rosmap(results: dict, output_path: Path):
    """Generate Figure 2: ROSMAP analysis.

    (a) UMAP colored by q_ij
    (b) q_bar_i vs Braak stage
    (c) Context-effect curves for top gene
    (d) Top 20 genes by LLR contribution
    """
    fig = plt.figure(figsize=FIGSIZE_FULL)
    gs = gridspec.GridSpec(2, 2, hspace=0.35, wspace=0.35)

    ax_a = fig.add_subplot(gs[0, 0])
    if "umap" in results:
        _plot_umap_q(ax_a, results["umap"])
    ax_a.text(-0.15, 1.05, "(a)", transform=ax_a.transAxes, fontweight="bold")

    ax_b = fig.add_subplot(gs[0, 1])
    if "q_vs_braak" in results:
        _plot_q_vs_braak(ax_b, results["q_vs_braak"])
    ax_b.text(-0.15, 1.05, "(b)", transform=ax_b.transAxes, fontweight="bold")

    ax_c = fig.add_subplot(gs[1, 0])
    if "context_curves" in results:
        _plot_context_curves(ax_c, results["context_curves"])
    ax_c.text(-0.15, 1.05, "(c)", transform=ax_c.transAxes, fontweight="bold")

    ax_d = fig.add_subplot(gs[1, 1])
    if "top_genes" in results:
        _plot_top_genes(ax_d, results["top_genes"])
    ax_d.text(-0.15, 1.05, "(d)", transform=ax_d.transAxes, fontweight="bold")

    fig.savefig(output_path, format="pdf")
    plt.close(fig)


def _plot_umap_q(ax, data: dict):
    """UMAP colored by q_ij."""
    sc = ax.scatter(data["umap1"], data["umap2"], c=data["q"], s=0.5,
                    cmap="RdBu_r", vmin=0, vmax=1, rasterized=True)
    plt.colorbar(sc, ax=ax, label=r"$q_{ij}$", shrink=0.8)
    ax.set_xlabel("UMAP1")
    ax.set_ylabel("UMAP2")


def _plot_q_vs_braak(ax, data: dict):
    """q_bar_i vs Braak stage with regression line."""
    ax.scatter(data["braak"], data["q_bar"], s=20, alpha=0.7, color=PALETTE["prism"])
    # Linear regression line
    z = np.polyfit(data["braak"], data["q_bar"], 1)
    x_line = np.linspace(min(data["braak"]), max(data["braak"]), 100)
    ax.plot(x_line, np.polyval(z, x_line), "--", color="gray", linewidth=1)
    ax.set_xlabel("Braak stage")
    ax.set_ylabel(r"$\bar{q}_i$")


def _plot_context_curves(ax, data: dict):
    """Context-effect curves: Delta_hat(z) vs Braak for a gene."""
    z_vals = data["z"]
    delta_mean = data["delta_mean"]
    delta_lo = data.get("delta_lo")
    delta_hi = data.get("delta_hi")
    ax.plot(z_vals, delta_mean, color=PALETTE["prism"], linewidth=1.5)
    if delta_lo is not None and delta_hi is not None:
        ax.fill_between(z_vals, delta_lo, delta_hi, alpha=0.2, color=PALETTE["prism"])
    ax.axhline(0, color="gray", linestyle="--", linewidth=0.5)
    ax.set_xlabel("Braak stage (standardized)")
    ax.set_ylabel(r"$\hat{\Delta}(z)$")
    if "gene_name" in data:
        ax.set_title(data["gene_name"], fontsize=FONTSIZE)


def _plot_top_genes(ax, data: dict):
    """Horizontal bar chart: top 20 genes by LLR contribution."""
    names = data["gene_names"][:20]
    llr = data["llr"][:20]
    y_pos = np.arange(len(names))
    ax.barh(y_pos, llr, color=PALETTE["prism"], height=0.6)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(names, fontsize=FONTSIZE - 2)
    ax.invert_yaxis()
    ax.set_xlabel("LLR contribution")
