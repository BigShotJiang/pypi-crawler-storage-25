"""Evaluation metrics for PRISM: power, FPR, AUC, recovery, sharpening."""

from __future__ import annotations

from typing import Optional

import torch
import numpy as np
from torch import Tensor


def compute_all_metrics(
    results,  # PRISMResults or dict
    ground_truth: dict,
    fdr_threshold: float = 0.05,
) -> dict[str, float]:
    """Compute all evaluation metrics.

    Three distinct tests are reported for PRISM family methods:

    power_ctx   \u2014 context-specific DE: fraction of context_de genes detected by
                  the theta (context-modulation) Wald test.  Uses q_values_context
                  when available, falling back to the raw q_values.

    power_fixed \u2014 general / constant DE: fraction of fixed_de genes detected by
                  the "general DE" test.  Uses q_values_general (which equals the
                  theta test for ConstantEncoder, the alpha_de test for NoneEncoder
                  and LinearEncoder).

    power_all   \u2014 all DE: fraction of all non-null genes detected by q_values_general.

    power_any   \u2014 omnibus: fraction of all non-null genes detected by q_values_any
                  (combines context-specific and general tests).

    Parameters
    ----------
    results : PRISMResults or dict with keys: q_hat, q_values, theta_hat, beta0_hat.
    ground_truth : dict with keys: d_true, gene_category, theta_true, beta0_true, rho_true.
    fdr_threshold : FDR level for significance.

    Returns
    -------
    dict of metric_name -> value.
    """
    metrics = {}

    # Extract results
    if hasattr(results, "q_hat"):
        q_hat = results.q_hat
        q_values = results.q_values
        theta_hat = results.theta_hat
        beta0_hat = results.beta0_hat
    else:
        q_hat = results.get("q_hat")
        q_values = results.get("q_values")
        theta_hat = results.get("theta_hat")
        beta0_hat = results.get("beta0_hat")

    # 1. AUC of q_ij for recovering true d_ij (over disease-arm cells only)
    if q_hat is not None and "d_true" in ground_truth:
        d_true = ground_truth["d_true"]
        # Evaluate over disease-arm cells (I=True) to avoid trivial control-cell signal
        if "I" in ground_truth:
            I_mask = ground_truth["I"]
            if hasattr(I_mask, "cpu"):
                I_mask = I_mask.cpu()
            I_np = I_mask.numpy().astype(bool)
            q_dis = q_hat[torch.from_numpy(I_np)]
            d_dis = d_true[torch.from_numpy(I_np)]
        else:
            q_dis = q_hat
            d_dis = d_true
        metrics["auc_q_d"] = auc_binary(q_dis, d_dis)
        # Brier score over disease-arm cells
        q_dis_np = q_dis.detach().cpu().numpy()
        d_dis_np = d_dis.detach().cpu().numpy()
        metrics["brier"] = float(((q_dis_np - d_dis_np) ** 2).mean())

    # 2. Gene-level power and FPR
    if q_values is not None and "gene_category" in ground_truth:
        cats = ground_truth["gene_category"]

        # q_values may be (P, K2); collapse to (P,) via min across extra dims
        qv = q_values.detach()
        if qv.dim() > 1:
            qv = qv.min(dim=-1).values  # (P,)

        is_null    = torch.tensor([c == "null"       for c in cats], device=qv.device)
        is_ctx     = torch.tensor([c == "context_de" for c in cats], device=qv.device)
        is_fixed   = torch.tensor([c == "fixed_de"   for c in cats], device=qv.device)
        is_de      = ~is_null

        # --- Context-specific DE test (theta Wald test, or q_values_context) ---
        # Uses q_values_context if available (LinearEncoder), otherwise falls back
        # to q_values (which equals the theta test for all encoder types).
        q_values_context = (
            getattr(results, "q_values_context", None)
            if hasattr(results, "q_values_context")
            else results.get("q_values_context", None) if isinstance(results, dict) else None
        )
        if q_values_context is not None:
            qv_ctx = q_values_context.detach()
            if qv_ctx.dim() > 1:
                qv_ctx = qv_ctx.min(dim=-1).values
        else:
            qv_ctx = qv  # fallback to raw theta test
        sig_ctx = qv_ctx < fdr_threshold

        # power_ctx: sensitivity for context-DE genes via context-specific test
        if is_ctx.sum() > 0:
            metrics["power_ctx"] = (sig_ctx & is_ctx).float().sum().item() / is_ctx.float().sum().item()
        else:
            metrics["power_ctx"] = 0.0

        # --- General DE test (alpha_de or theta, depending on encoder) ---
        # q_values_general is the correct "general DE" test for every encoder type:
        #   ConstantEncoder -> theta test (theta IS the disease effect)
        #   NoneEncoder     -> alpha_de test (alpha_de IS the disease effect)
        #   LinearEncoder   -> alpha_de test (constant component)
        q_values_general = (
            getattr(results, "q_values_general", None)
            if hasattr(results, "q_values_general")
            else results.get("q_values_general", None) if isinstance(results, dict) else None
        )
        if q_values_general is not None:
            qv_gen = q_values_general.detach()
            if qv_gen.dim() > 1:
                qv_gen = qv_gen.min(dim=-1).values
            sig_gen = qv_gen < fdr_threshold
        else:
            # Legacy fallback: try q_values_de, then q_values
            q_values_de = (
                getattr(results, "q_values_de", None)
                if hasattr(results, "q_values_de")
                else results.get("q_values_de", None) if isinstance(results, dict) else None
            )
            if q_values_de is not None:
                qv_de = q_values_de.detach()
                if qv_de.dim() > 1:
                    qv_de = qv_de.min(dim=-1).values
                sig_gen = qv_de < fdr_threshold
            else:
                sig_gen = sig_ctx  # last resort: use context-specific test

        # power_all: sensitivity for ALL DE genes via general DE test
        if is_de.sum() > 0:
            metrics["power_all"]   = (sig_gen & is_de   ).float().sum().item() / is_de.float().sum().item()
            metrics["power_fixed"] = (sig_gen & is_fixed).float().sum().item() / is_fixed.float().sum().item() if is_fixed.sum() > 0 else 0.0
        else:
            metrics["power_all"]   = 0.0
            metrics["power_fixed"] = 0.0

        # Overall power alias (backward-compat)
        metrics["power"] = metrics["power_all"]

        # FPR: false positive rate using general DE test (comparable across all methods)
        if is_null.sum() > 0:
            metrics["fpr"] = (sig_gen & is_null).float().sum().item() / is_null.float().sum().item()
        else:
            metrics["fpr"] = 0.0

        # FPR_context: false positive rate of the theta (context) test on null genes.
        # A null gene has both α=0 and θ=0, so any significant theta result is a FP.
        if is_null.sum() > 0:
            metrics["fpr_context"] = (sig_ctx & is_null).float().sum().item() / is_null.float().sum().item()
        else:
            metrics["fpr_context"] = 0.0

        # Precision: fraction of general-test positives that are true DE genes
        if sig_gen.sum() > 0:
            metrics["precision"] = (sig_gen & is_de).float().sum().item() / sig_gen.float().sum().item()
        else:
            metrics["precision"] = 0.0

        # --- Omnibus test (any DE signal) ---
        q_values_any = (
            getattr(results, "q_values_any", None)
            if hasattr(results, "q_values_any")
            else results.get("q_values_any", None) if isinstance(results, dict) else None
        )
        if q_values_any is not None:
            qv_any = q_values_any.detach()
            if qv_any.dim() > 1:
                qv_any = qv_any.min(dim=-1).values
            sig_any = qv_any < fdr_threshold
            if is_de.sum() > 0:
                metrics["power_any"] = (sig_any & is_de).float().sum().item() / is_de.float().sum().item()
        else:
            metrics["power_any"] = metrics["power_all"]  # same as general when no omnibus

    # 2b. alpha_de recovery (fixed-effect disease coefficient)
    alpha_de_hat = getattr(results, "alpha_de_hat", None) if hasattr(results, "alpha_de_hat") else (results.get("alpha_de_hat") if isinstance(results, dict) else None)
    if alpha_de_hat is not None and "alpha_de_true" in ground_truth:
        alpha_de_true = ground_truth["alpha_de_true"].to(alpha_de_hat.device)
        if alpha_de_hat.shape == alpha_de_true.shape and alpha_de_hat.std() > 1e-10 and alpha_de_true.std() > 1e-10:
            metrics["alpha_de_corr"] = _correlation(alpha_de_hat.flatten(), alpha_de_true.flatten())
            metrics["alpha_de_mse"] = ((alpha_de_hat - alpha_de_true) ** 2).mean().item()

    # 3. Effect recovery (theta)
    if theta_hat is not None and "theta_true" in ground_truth:
        theta_true = ground_truth["theta_true"]
        if theta_hat.shape == theta_true.shape:
            metrics["theta_mse"] = ((theta_hat - theta_true) ** 2).mean().item()
            metrics["theta_corr"] = _correlation(theta_hat.flatten(), theta_true.flatten())

    # 4. Beta0 recovery
    if beta0_hat is not None and "beta0_true" in ground_truth:
        beta0_true = ground_truth["beta0_true"]
        if beta0_hat.shape == beta0_true.shape:
            metrics["beta0_mse"] = ((beta0_hat - beta0_true) ** 2).mean().item()
            metrics["beta0_corr"] = _correlation(beta0_hat.flatten(), beta0_true.flatten())

    # 5. Effect sharpening: |theta_hat / theta_true| for DE genes
    if theta_hat is not None and "gene_category" in ground_truth and "theta_true" in ground_truth:
        cats = ground_truth["gene_category"]
        theta_true = ground_truth["theta_true"]
        is_context_de = torch.tensor([c == "context_de" for c in cats])

        if is_context_de.sum() > 0 and theta_hat.shape == theta_true.shape:
            theta_hat_de = theta_hat[is_context_de].flatten()
            theta_true_de = theta_true[is_context_de].flatten()
            mask_nonzero = theta_true_de.abs() > 0.01
            if mask_nonzero.sum() > 0:
                ratio = (theta_hat_de[mask_nonzero] / theta_true_de[mask_nonzero]).abs()
                metrics["sharpening_mean"] = ratio.mean().item()
                metrics["sharpening_median"] = ratio.median().item()

    # 6. Rho recovery
    if "rho_true" in ground_truth and hasattr(results, "rho_hat"):
        rho_hat = results.rho_hat if hasattr(results, "rho_hat") else results.get("rho_hat")
        if rho_hat is not None:
            rho_true = ground_truth["rho_true"]
            metrics["rho_mse"] = ((rho_hat - rho_true) ** 2).mean().item()
            metrics["rho_mean_hat"] = rho_hat.mean().item()

    return metrics


def auc_binary(scores: Tensor, labels: Tensor) -> float:
    """Compute AUC for binary classification.

    Parameters
    ----------
    scores : (N,) predicted probabilities.
    labels : (N,) true binary labels.

    Returns
    -------
    float — AUC.
    """
    from sklearn.metrics import roc_auc_score

    s = scores.detach().cpu().numpy().astype(np.float64)
    l = labels.detach().cpu().numpy().astype(np.float64)

    # Filter out constant labels
    if l.std() == 0:
        return 0.5

    return float(roc_auc_score(l, s))


def _correlation(a: Tensor, b: Tensor) -> float:
    """Pearson correlation between two flat tensors."""
    a_np = a.detach().cpu().numpy().astype(np.float64)
    b_np = b.detach().cpu().numpy().astype(np.float64)
    if a_np.std() == 0 or b_np.std() == 0:
        return 0.0
    return float(np.corrcoef(a_np, b_np)[0, 1])
