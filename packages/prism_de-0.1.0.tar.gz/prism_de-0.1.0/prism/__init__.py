"""PRISM: Probabilistic Inference of Subject-level Mixture for Contextualized DE."""

__version__ = "0.1.0"

from .inference.em_loop import PRISMConfig, PRISMResults, PRISMTrainer
from .data.dataset import PrismData
from .data.simulation import generate_prism_data

__all__ = [
    "PRISMConfig",
    "PRISMResults",
    "PRISMTrainer",
    "PrismData",
    "generate_prism_data",
]
