"""Baseline methods A1–A6 + external R baselines for ablation comparisons."""
