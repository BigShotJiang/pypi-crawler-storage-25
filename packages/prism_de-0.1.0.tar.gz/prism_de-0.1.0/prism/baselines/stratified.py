"""A3b: Stratified baseline — binned context + Cochran's Q test.

Bin the context variable into discrete strata, run NEBULA within each
stratum, and combine using Cochran's Q heterogeneity test.
"""

from __future__ import annotations

from typing import Optional

import torch
import numpy as np
from torch import Tensor

from ..data.dataset import PrismData
from ..inference.em_loop import PRISMConfig, PRISMTrainer


def run_stratified(
    data: PrismData,
    n_bins: int = 4,
    context_dim: int = 0,
    max_iter: int = 200,
    device: str = "cuda",
) -> dict:
    """Run stratified baseline (A3b).

    1. Bin cells into n_bins strata based on context_dim-th context variable.
    2. Run NEBULA (A1) within each stratum.
    3. Combine via Cochran's Q test for heterogeneity.

    Returns
    -------
    dict with keys:
        beta_per_stratum : list of (P, K) tensors
        se_per_stratum : list of (P,) tensors
        cochran_q : (P,) Cochran Q statistics
        p_values : (P,) p-values for heterogeneity
    """
    z_col = data.Z[:, context_dim].cpu().numpy()

    # Bin into quantiles
    bin_edges = np.quantile(z_col, np.linspace(0, 1, n_bins + 1))
    bin_edges[-1] += 1e-6  # include max
    bin_labels = np.digitize(z_col, bin_edges) - 1
    bin_labels = np.clip(bin_labels, 0, n_bins - 1)

    beta_per_stratum = []
    se_per_stratum = []

    for b in range(n_bins):
        mask_np = bin_labels == b
        if mask_np.sum() < 10:
            continue

        mask = torch.tensor(mask_np, dtype=torch.bool, device=data.device)

        # Create stratum-level PrismData
        Y_b = data.Y[mask]
        X_b = data.X[mask]
        Z_b = data.Z[mask]
        I_b = data.I[mask]
        log_pi_b = data.log_pi[mask]
        subj_b = data.subject_idx[mask]
        dis_subj_b = data.disease_subject_idx[mask]

        # Remap subjects
        unique_subj = subj_b.unique()
        subj_map = {s.item(): i for i, s in enumerate(unique_subj)}
        subj_b_remapped = torch.tensor([subj_map[s.item()] for s in subj_b],
                                        dtype=torch.long, device=data.device)

        unique_dis = dis_subj_b[I_b].unique() if I_b.any() else torch.tensor([], dtype=torch.long)
        n_dis = len(unique_dis)
        if n_dis == 0:
            continue

        dis_map = {s.item(): i for i, s in enumerate(unique_dis)}
        dis_b_remapped = torch.tensor(
            [dis_map.get(s.item(), 0) for s in dis_subj_b],
            dtype=torch.long, device=data.device,
        )

        data_b = PrismData.from_tensors(
            Y=Y_b, X=X_b, Z=Z_b, I=I_b,
            log_pi=log_pi_b,
            subject_idx=subj_b_remapped,
            n_subjects=len(unique_subj),
            disease_subject_idx=dis_b_remapped,
            n_disease_subjects=n_dis,
        )

        # Run NEBULA (A1)
        config = PRISMConfig(
            n_genes=data.n_genes,
            n_covars=data.n_covars,
            n_context=data.n_context,
            encoder_type="none",
            max_em_iter=1,
            m_step_max_iter=max_iter,
            m_step_optimizer="adam",
            wandb_enabled=False,
            run_wald=True,
            device=device,
        )
        trainer = PRISMTrainer(config)
        res = trainer.fit(data_b)
        beta_per_stratum.append(res.beta_hat)
        if res.se is not None:
            se_per_stratum.append(res.se)

    # Cochran's Q test for heterogeneity
    P = data.n_genes
    cochran_q = torch.zeros(P, device=data.device)
    p_values = torch.ones(P, device=data.device)

    if len(beta_per_stratum) >= 2 and len(se_per_stratum) >= 2:
        # Use the condition-effect column (column 2 if K >= 3, else column 0)
        col = 2 if data.n_covars >= 3 else 0
        betas = torch.stack([b[:, col] for b in beta_per_stratum])  # (n_strata, P)
        ses = torch.stack(se_per_stratum)  # (n_strata, P) or (n_strata, P, K2)
        if ses.dim() == 3:
            ses = ses[:, :, 0]

        # Weights = 1 / se^2
        w = 1.0 / (ses ** 2).clamp(min=1e-12)  # (n_strata, P)
        beta_bar = (w * betas).sum(dim=0) / w.sum(dim=0).clamp(min=1e-12)  # (P,)
        cochran_q = (w * (betas - beta_bar.unsqueeze(0)) ** 2).sum(dim=0)  # (P,)

        # p-values from chi2(n_strata - 1)
        df = len(beta_per_stratum) - 1
        from scipy.stats import chi2
        q_np = cochran_q.cpu().numpy()
        p_values = torch.tensor(chi2.sf(q_np, df), device=data.device, dtype=torch.float32)

    return {
        "beta_per_stratum": beta_per_stratum,
        "se_per_stratum": se_per_stratum,
        "cochran_q": cochran_q,
        "p_values": p_values,
    }
