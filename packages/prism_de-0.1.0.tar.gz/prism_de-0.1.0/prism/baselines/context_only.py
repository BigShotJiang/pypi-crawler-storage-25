"""A2: PRISM-C baseline — encoder=linear, rho=1.

PRISM with context encoder but without latent disease states.
All disease cells are treated as affected.
"""

from __future__ import annotations

from ..data.dataset import PrismData
from ..inference.em_loop import PRISMTrainer, PRISMConfig, PRISMResults


def run_context_only(
    data: PrismData,
    max_iter: int = 200,
    device: str = "cuda",
    **kwargs,
) -> PRISMResults:
    """Run context-only baseline (A2): linear encoder, rho=1.

    Equivalent to PRISM with:
        - encoder_type = "linear"
        - q = I fixed (no E-step / EM)
    """
    config = PRISMConfig(
        n_genes=data.n_genes,
        n_covars=data.n_covars,
        n_context=data.n_context,
        encoder_type="linear",
        max_em_iter=1,
        m_step_max_iter=max_iter,
        m_step_optimizer="adam",
        m_step_lr=0.01,
        wandb_enabled=False,
        run_wald=True,
        device=device,
        **kwargs,
    )
    trainer = PRISMTrainer(config)
    return trainer.fit(data)
