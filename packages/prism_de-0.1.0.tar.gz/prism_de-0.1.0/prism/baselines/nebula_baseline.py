"""A1: NEBULA baseline — encoder=none, rho=1 (all disease cells affected).

This is standard NEBULA without latent states or context effects.
Equivalent to PRISM with NoneEncoder and q=I.
"""

from __future__ import annotations

import torch

from ..data.dataset import PrismData
from ..inference.em_loop import PRISMTrainer, PRISMConfig, PRISMResults


def run_nebula_baseline(
    data: PrismData,
    max_iter: int = 200,
    device: str = "cuda",
    **kwargs,
) -> PRISMResults:
    """Run NEBULA baseline (A1): no encoder, rho=1.

    This is equivalent to:
        - Setting encoder_type = "none"
        - Fixing q = I (all disease cells are "affected")
        - Running only the M-step (no EM loop needed)
    """
    config = PRISMConfig(
        n_genes=data.n_genes,
        n_covars=data.n_covars,
        n_context=data.n_context,
        encoder_type="none",
        max_em_iter=1,  # Single M-step
        m_step_max_iter=max_iter,
        m_step_optimizer="adam",
        m_step_lr=0.01,
        wandb_enabled=False,
        run_wald=True,
        device=device,
        **kwargs,
    )
    trainer = PRISMTrainer(config)

    # Override: fix q = I
    results = trainer.fit(data)
    return results
