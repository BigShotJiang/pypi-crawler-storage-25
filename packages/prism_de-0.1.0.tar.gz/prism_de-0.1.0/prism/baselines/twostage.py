"""Two-stage combo baseline: cluster cells first, then run DE.

Pipeline:
    1. Fit a GMM (2 components) on context/PC space within disease cells.
    2. Assign each disease cell to the larger cluster.
    3. Run pseudobulk DE (subject-level aggregation + per-gene NB GLM)
       using only cells from the majority cluster.

This tests whether a simple "classify then test" strategy can
approximate PRISM's latent-state-aware inference.
"""

from __future__ import annotations

import numpy as np
import torch
from sklearn.mixture import GaussianMixture

from ..data.dataset import PrismData
from .pseudobulk import run_pseudobulk


def run_twostage(
    data: PrismData,
    n_components: int = 2,
    use_context: bool = True,
    random_state: int = 42,
) -> dict:
    """Run two-stage GMM→pseudobulk baseline.

    Parameters
    ----------
    data : PrismData
    n_components : Number of GMM components (default 2 for disease/responder split).
    use_context : If True, cluster on context Z; if False, cluster on covariates X.
    random_state : Seed for GMM.

    Returns
    -------
    dict with keys: p_values, q_values, beta_hat, se
    """
    I = data.I.cpu().numpy().astype(bool)
    disease_mask = I  # cells from disease subjects

    # Features for clustering: context covariates of disease cells
    if use_context:
        features = data.Z[disease_mask].cpu().numpy()
    else:
        features = data.X[disease_mask].cpu().numpy()

    # Fit GMM on disease cells
    gmm = GaussianMixture(
        n_components=n_components,
        random_state=random_state,
        max_iter=200,
    )
    labels = gmm.fit_predict(features)

    # Pick the largest cluster as the "affected" subpopulation
    cluster_sizes = np.bincount(labels, minlength=n_components)
    major_cluster = int(np.argmax(cluster_sizes))

    # Build mask: keep all control cells + disease cells from major cluster
    keep = np.ones(data.n_cells, dtype=bool)
    disease_indices = np.where(disease_mask)[0]
    for i, idx in enumerate(disease_indices):
        if labels[i] != major_cluster:
            keep[idx] = False

    keep_t = torch.tensor(keep, dtype=torch.bool, device=data.Y.device)

    # Subset data
    Y_sub = data.Y[keep_t]
    X_sub = data.X[keep_t]
    Z_sub = data.Z[keep_t]
    I_sub = data.I[keep_t]
    log_pi_sub = data.log_pi[keep_t]
    subj_sub = data.subject_idx[keep_t]
    dis_subj_sub = data.disease_subject_idx[keep_t]

    # Remap subjects
    unique_subj = subj_sub.unique()
    subj_map = {s.item(): i for i, s in enumerate(unique_subj)}
    subj_remapped = torch.tensor(
        [subj_map[s.item()] for s in subj_sub],
        dtype=torch.long, device=data.Y.device,
    )

    unique_dis = dis_subj_sub[I_sub.bool()].unique() if I_sub.any() else torch.tensor([])
    n_dis = len(unique_dis)
    dis_map = {s.item(): i for i, s in enumerate(unique_dis)}
    dis_remapped = torch.tensor(
        [dis_map.get(s.item(), 0) for s in dis_subj_sub],
        dtype=torch.long, device=data.Y.device,
    )

    data_sub = PrismData.from_tensors(
        Y=Y_sub, X=X_sub, Z=Z_sub, I=I_sub,
        log_pi=log_pi_sub,
        subject_idx=subj_remapped,
        n_subjects=len(unique_subj),
        disease_subject_idx=dis_remapped,
        n_disease_subjects=n_dis,
    )

    # Run pseudobulk DE on the filtered subset
    return run_pseudobulk(data_sub)
