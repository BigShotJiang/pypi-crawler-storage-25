"""Python wrappers for R-based DE baselines (MAST, NEBULA, DESeq2, edgeR).

These wrappers:
    1. Export PRISM simulation data to temporary CSV files.
    2. Call R scripts via subprocess.
    3. Read back results into the same dict format as other baselines.

Requires R with {MAST, nebula, DESeq2, edgeR, data.table, argparse} installed.
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import torch

from ..data.dataset import PrismData

_R_SCRIPT_DIR = Path(__file__).parent


def _check_r_available() -> bool:
    """Check if R is available on the system."""
    try:
        subprocess.run(
            ["Rscript", "--version"],
            capture_output=True, timeout=10,
        )
        return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _export_data_to_csv(
    data: PrismData,
    tmpdir: str,
) -> tuple[str, str]:
    """Export PrismData to CSV files for R consumption.

    Returns
    -------
    counts_path : path to cells × genes count matrix CSV.
    meta_path : path to cell metadata CSV.
    """
    Y = data.Y.cpu().numpy()
    X = data.X.cpu().numpy()
    I = data.I.cpu().numpy().astype(int)
    subject_idx = data.subject_idx.cpu().numpy()
    log_pi = data.log_pi.cpu().numpy()

    # Counts (cells × genes)
    counts_path = os.path.join(tmpdir, "counts.csv")
    gene_names = [f"gene_{g}" for g in range(data.n_genes)]
    pd.DataFrame(Y, columns=gene_names).to_csv(
        counts_path, index=False
    )

    # Metadata
    meta_path = os.path.join(tmpdir, "meta.csv")
    pd.DataFrame({
        "condition": I,
        "subject_id": subject_idx,
        "log_pi": log_pi,
    }).to_csv(meta_path, index=False)

    return counts_path, meta_path


def _parse_r_results(
    csv_path: str,
    n_genes: int,
) -> dict:
    """Parse R output CSV into standard baseline result dict."""
    df = pd.read_csv(csv_path)

    p_values = np.ones(n_genes)
    q_values = np.ones(n_genes)
    coefs = np.zeros(n_genes)
    se_vals = np.ones(n_genes) * float("inf")

    n_found = min(len(df), n_genes)
    p_values[:n_found] = df["p_value"].values[:n_found]
    q_values[:n_found] = df["q_value"].values[:n_found]

    if "coef" in df.columns:
        coef_arr = df["coef"].values[:n_found]
        coefs[:n_found] = np.nan_to_num(coef_arr, nan=0.0)

    if "se" in df.columns:
        se_arr = df["se"].values[:n_found]
        se_vals[:n_found] = np.nan_to_num(se_arr, nan=float("inf"))

    return {
        "p_values": torch.tensor(p_values, dtype=torch.float32),
        "q_values": torch.tensor(q_values, dtype=torch.float32),
        "beta_hat": torch.tensor(
            np.column_stack([np.zeros(n_genes), coefs]),
            dtype=torch.float32,
        ),
        "se": torch.tensor(se_vals, dtype=torch.float32),
    }


def run_mast(
    data: PrismData,
    fdr_threshold: float = 0.05,
    timeout: int = 7200,
) -> dict:
    """Run MAST hurdle model on PrismData.

    Parameters
    ----------
    data : PrismData
    fdr_threshold : FDR threshold (applied inside R).
    timeout : max seconds for R process.

    Returns
    -------
    dict with keys: beta_hat, p_values, q_values, se.
    """
    if not _check_r_available():
        raise RuntimeError(
            "R is not available. Install R and the MAST package to use this baseline."
        )

    r_script = _R_SCRIPT_DIR / "run_mast.R"
    if not r_script.exists():
        raise FileNotFoundError(f"MAST R script not found: {r_script}")

    with tempfile.TemporaryDirectory(prefix="prism_mast_") as tmpdir:
        counts_path, meta_path = _export_data_to_csv(data, tmpdir)
        out_path = os.path.join(tmpdir, "mast_results.csv")

        cmd = [
            "Rscript", str(r_script),
            "--counts", counts_path,
            "--meta", meta_path,
            "--out", out_path,
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

        if result.returncode != 0:
            raise RuntimeError(
                f"MAST R script failed:\nSTDOUT: {result.stdout}\n"
                f"STDERR: {result.stderr}"
            )

        return _parse_r_results(out_path, data.n_genes)


def run_nebula_r(
    data: PrismData,
    method: str = "LN",
    fdr_threshold: float = 0.05,
    timeout: int = 1800,
) -> dict:
    """Run NEBULA (R package) on PrismData.

    Parameters
    ----------
    data : PrismData
    method : "LN" (fast approximate) or "HL" (exact hierarchical).
    fdr_threshold : FDR threshold.
    timeout : max seconds for R process.

    Returns
    -------
    dict with keys: beta_hat, p_values, q_values, se.
    """
    if not _check_r_available():
        raise RuntimeError(
            "R is not available. Install R and the nebula package to use this baseline."
        )

    r_script = _R_SCRIPT_DIR / "run_nebula.R"
    if not r_script.exists():
        raise FileNotFoundError(f"NEBULA R script not found: {r_script}")

    with tempfile.TemporaryDirectory(prefix="prism_nebula_") as tmpdir:
        counts_path, meta_path = _export_data_to_csv(data, tmpdir)
        out_path = os.path.join(tmpdir, "nebula_results.csv")

        cmd = [
            "Rscript", str(r_script),
            "--counts", counts_path,
            "--meta", meta_path,
            "--out", out_path,
            "--method", method,
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

        if result.returncode != 0:
            raise RuntimeError(
                f"NEBULA R script failed:\nSTDOUT: {result.stdout}\n"
                f"STDERR: {result.stderr}"
            )

        return _parse_r_results(out_path, data.n_genes)


def _export_context_to_csv(data: PrismData, tmpdir: str) -> str:
    """Export context matrix Z to CSV for R scripts that need it."""
    Z = data.Z.cpu().numpy()
    ctx_path = os.path.join(tmpdir, "context.csv")
    col_names = [f"ctx{k+1}" for k in range(Z.shape[1])]
    pd.DataFrame(Z, columns=col_names).to_csv(ctx_path, index=False)
    return ctx_path


def run_deseq2(
    data: PrismData,
    timeout: int = 3600,
) -> dict:
    """Run pseudobulk DESeq2 on PrismData.

    Aggregates single-cell counts to subject-level pseudobulk,
    then fits DESeq2 NB model with Wald test.
    """
    if not _check_r_available():
        raise RuntimeError("R is not available. Install R and DESeq2.")

    r_script = _R_SCRIPT_DIR / "run_deseq2.R"
    if not r_script.exists():
        raise FileNotFoundError(f"DESeq2 R script not found: {r_script}")

    with tempfile.TemporaryDirectory(prefix="prism_deseq2_") as tmpdir:
        counts_path, meta_path = _export_data_to_csv(data, tmpdir)
        out_path = os.path.join(tmpdir, "deseq2_results.csv")

        cmd = [
            "Rscript", str(r_script),
            "--counts", counts_path,
            "--meta", meta_path,
            "--out", out_path,
        ]

        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"DESeq2 R script failed:\nSTDOUT: {result.stdout}\n"
                f"STDERR: {result.stderr}"
            )
        return _parse_r_results(out_path, data.n_genes)


def run_edger(
    data: PrismData,
    timeout: int = 3600,
) -> dict:
    """Run pseudobulk edgeR on PrismData.

    Aggregates single-cell counts to subject-level pseudobulk,
    then fits edgeR QL F-test with TMM normalization.
    """
    if not _check_r_available():
        raise RuntimeError("R is not available. Install R and edgeR.")

    r_script = _R_SCRIPT_DIR / "run_edger.R"
    if not r_script.exists():
        raise FileNotFoundError(f"edgeR R script not found: {r_script}")

    with tempfile.TemporaryDirectory(prefix="prism_edger_") as tmpdir:
        counts_path, meta_path = _export_data_to_csv(data, tmpdir)
        out_path = os.path.join(tmpdir, "edger_results.csv")

        cmd = [
            "Rscript", str(r_script),
            "--counts", counts_path,
            "--meta", meta_path,
            "--out", out_path,
        ]

        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"edgeR R script failed:\nSTDOUT: {result.stdout}\n"
                f"STDERR: {result.stderr}"
            )
        return _parse_r_results(out_path, data.n_genes)


def run_nebula_interaction(
    data: PrismData,
    method: str = "LN",
    timeout: int = 3600,
) -> dict:
    """Run NEBULA with condition×context interaction terms.

    Tests whether adding explicit interaction terms to the NBMM
    design matrix can capture context-dependent effects, without
    latent-state machinery.
    """
    if not _check_r_available():
        raise RuntimeError("R is not available. Install R and nebula.")

    r_script = _R_SCRIPT_DIR / "run_nebula_interaction.R"
    if not r_script.exists():
        raise FileNotFoundError(f"NEBULA-interaction R script not found: {r_script}")

    with tempfile.TemporaryDirectory(prefix="prism_interaction_") as tmpdir:
        counts_path, meta_path = _export_data_to_csv(data, tmpdir)
        ctx_path = _export_context_to_csv(data, tmpdir)
        out_path = os.path.join(tmpdir, "interaction_results.csv")

        cmd = [
            "Rscript", str(r_script),
            "--counts", counts_path,
            "--meta", meta_path,
            "--context", ctx_path,
            "--out", out_path,
            "--method", method,
        ]

        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"NEBULA-interaction R script failed:\nSTDOUT: {result.stdout}\n"
                f"STDERR: {result.stderr}"
            )
        return _parse_r_results(out_path, data.n_genes)
