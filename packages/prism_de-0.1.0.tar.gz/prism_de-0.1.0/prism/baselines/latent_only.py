"""A3: Latent-only baseline — encoder=constant, rho=learned.

PRISM with latent disease states but no context dependence.
The effect size is a scalar per gene (no z dependence).
"""

from __future__ import annotations

from ..data.dataset import PrismData
from ..inference.em_loop import PRISMTrainer, PRISMConfig, PRISMResults


def run_latent_only(
    data: PrismData,
    max_em_iter: int = 50,
    device: str = "cuda",
    **kwargs,
) -> PRISMResults:
    """Run latent-only baseline (A3): constant encoder, rho learned via EM.

    Equivalent to PRISM with:
        - encoder_type = "constant" (Delta_g = scalar per gene)
        - Full EM loop to learn rho and q
    """
    config = PRISMConfig(
        n_genes=data.n_genes,
        n_covars=data.n_covars,
        n_context=data.n_context,
        encoder_type="constant",
        max_em_iter=max_em_iter,
        m_step_optimizer="adam",
        m_step_lr=0.01,
        wandb_enabled=False,
        run_wald=True,
        device=device,
        **kwargs,
    )
    trainer = PRISMTrainer(config)
    return trainer.fit(data)
