"""A6: Per-gene NB GLM baseline — no random effects.

Run a standard negative-binomial GLM per gene without subject-level
random effects.  This is the "fixed effects only" approach.
"""

from __future__ import annotations

import numpy as np
import torch
from torch import Tensor

from ..data.dataset import PrismData


def run_nb_glm(
    data: PrismData,
    fdr_threshold: float = 0.05,
) -> dict:
    """Run per-gene NB GLM without random effects (A6).

    For each gene g:
        Y_g ~ NB(mu_g, phi_g)  where log(mu) = X beta + log(pi)

    Uses statsmodels for estimation.

    Returns
    -------
    dict with keys: beta_hat, p_values, q_values, se.
    """
    import statsmodels.api as sm
    from statsmodels.stats.multitest import multipletests

    N = data.n_cells
    P = data.n_genes
    K = data.n_covars

    Y_np = data.Y.cpu().numpy().astype(int)
    X_np = data.X.cpu().numpy()
    exposure_np = data.log_pi.cpu().exp().numpy()

    beta_hat = np.zeros((P, K))
    p_values = np.ones(P)
    se_hat = np.ones(P) * float("inf")

    test_col = 2 if K >= 3 else K - 1

    for g in range(P):
        y_g = Y_np[:, g]
        if y_g.sum() < 5:
            continue
        try:
            model = sm.GLM(
                y_g,
                X_np,
                family=sm.families.NegativeBinomial(),
                exposure=exposure_np,
            )
            result = model.fit(disp=False, maxiter=100)
            beta_hat[g] = result.params
            if test_col < len(result.pvalues):
                p_values[g] = result.pvalues[test_col]
                se_hat[g] = result.bse[test_col]
        except Exception:
            pass

    _, q_values_np, _, _ = multipletests(p_values, method="fdr_bh")

    return {
        "beta_hat": torch.tensor(beta_hat, dtype=torch.float32),
        "p_values": torch.tensor(p_values, dtype=torch.float32),
        "q_values": torch.tensor(q_values_np, dtype=torch.float32),
        "se": torch.tensor(se_hat, dtype=torch.float32),
    }
