"""A5: Pseudobulk baseline — subject-level aggregation.

Aggregate cell-level counts to subject-level pseudobulk, then run
a standard NB GLM (via statsmodels) for differential expression.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import torch
from torch import Tensor

from ..data.dataset import PrismData


def run_pseudobulk(
    data: PrismData,
    fdr_threshold: float = 0.05,
) -> dict:
    """Run pseudobulk DE analysis (A5).

    Steps:
        1. Sum counts per subject: Y_pb (m, P).
        2. Average covariates per subject: X_pb (m, K).
        3. Run per-gene NB GLM via statsmodels.
        4. Extract p-values, q-values.

    Returns
    -------
    dict with keys: beta_hat, p_values, q_values, se.
    """
    import statsmodels.api as sm
    from statsmodels.stats.multitest import multipletests

    m = data.n_subjects
    P = data.n_genes
    K = data.n_covars

    # Aggregate to pseudobulk
    Y_pb = torch.zeros(m, P, device="cpu")
    X_pb = torch.zeros(m, K, device="cpu")
    lib_size = torch.zeros(m, device="cpu")

    # Condition indicator per subject (1 = disease, 0 = control)
    I_subject = torch.zeros(m, dtype=torch.float32)
    for s in range(m):
        mask_s = (data.subject_idx == s).cpu()
        if mask_s.any():
            I_subject[s] = float(data.I[mask_s][0].item())

    Y_cpu = data.Y.cpu().float()
    X_cpu = data.X.cpu().float()
    log_pi_cpu = data.log_pi.cpu()

    for s in range(m):
        mask = (data.subject_idx == s).cpu()
        n_s = mask.sum()
        if n_s == 0:
            continue
        Y_pb[s] = Y_cpu[mask].sum(dim=0)
        X_pb[s] = X_cpu[mask].mean(dim=0)
        lib_size[s] = log_pi_cpu[mask].exp().sum()

    # Build design matrix: [X_covars, condition_indicator]
    # condition is appended as the last column so test_col = K
    cond_col = I_subject.numpy().reshape(-1, 1)
    X_np = np.hstack([X_pb.numpy(), cond_col])  # (m, K+1)
    Y_np = Y_pb.numpy().astype(int)
    lib_np = lib_size.numpy()

    n_params = K + 1
    beta_hat = np.zeros((P, n_params))
    p_values = np.ones(P)
    se_hat = np.ones(P) * float("inf")

    # Test the condition coefficient (last column)
    test_col = K

    for g in range(P):
        y_g = Y_np[:, g]
        if y_g.sum() < 5:
            continue
        try:
            model = sm.GLM(
                y_g,
                X_np,
                family=sm.families.NegativeBinomial(alpha=1.0),
                exposure=lib_np,
            )
            result = model.fit(disp=False, maxiter=100)
            beta_hat[g] = result.params[:n_params]
            if test_col < len(result.pvalues):
                p_values[g] = result.pvalues[test_col]
                se_hat[g] = result.bse[test_col]
        except Exception:
            pass  # Keep defaults (p=1, se=inf)

    # BH correction
    _, q_values_np, _, _ = multipletests(p_values, method="fdr_bh")

    return {
        "beta_hat": torch.tensor(beta_hat, dtype=torch.float32),
        "p_values": torch.tensor(p_values, dtype=torch.float32),
        "q_values": torch.tensor(q_values_np, dtype=torch.float32),
        "se": torch.tensor(se_hat, dtype=torch.float32),
        "theta_hat": None,
    }
