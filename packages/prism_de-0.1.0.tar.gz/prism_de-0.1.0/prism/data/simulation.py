"""Synthetic data generation from the full PRISM generative model.

Contextualized model:
    log mu = log pi + x' beta0_g + x' Gamma_g z + d * (alpha_g + theta_g' z) + log omega + log nu

Generation process:
    1. Assign m/2 subjects to control, m/2 to disease.
    2. Generate X (covariates) and Z (context) per cell.
    3. For disease subjects: d_ij ~ Bernoulli(rho); controls: d_ij = 0.
    4. Generate beta0_g (baseline), Gamma_g (contextualized covariates),
       alpha_g (constant DE), theta_g (context-dependent DE).
    5. Generate omega_ig ~ Gamma(alpha, lambda) from sigma2.
    6. Generate nu_ijg ~ Gamma(phi, phi).
    7. Generate Y_ijg ~ Poisson(mu).
"""

from __future__ import annotations

from typing import Optional

import torch
from torch import Tensor

from .dataset import PrismData


def generate_ground_truth(
    n_subjects: int = 50,
    n_cells_per_subject: int = 200,
    n_genes: int = 60,
    n_covars: int = 3,
    n_context: int = 1,
    frac_null: float = 0.4,
    frac_fixed_de: float = 0.25,
    frac_context_de: float = 0.35,
    rho: float = 0.5,
    effect_range: tuple = (0.3, 1.0),
    context_effect_range: tuple = (0.3, 1.0),
    beta0_range: tuple = (-2.0, 2.0),
    Gamma_scale: float = 0.3,
    seed: int = 42,
    **_kwargs,  # absorb unused params (sigma2, phi, pi_mode, device, ...)
) -> dict:
    """Return only ground-truth labels and true parameters without generating cell data.

    Reproduces the same RNG sequence as generate_prism_data (steps 1–4 + X/Z)
    so gene_category and true parameters are identical to the full simulation.

    Skips the expensive omega/nu/Y sampling (~40M Gamma+Poisson draws on CPU).
    Also returns X, Z, subject_idx so callers can compute analytical SEs from
    saved model parameters without regenerating counts.

    Returns
    -------
    dict with keys: gene_category, alpha_de_true, theta_true, beta0_true,
                    Gamma_true, rho_true, n_null, n_fixed_de, n_context_de,
                    X, Z, log_pi (zeros), subject_idx, I, n_subjects,
                    n_disease_subjects, n_cells.
    """
    gen = torch.Generator(device="cpu").manual_seed(seed)

    m = n_subjects
    m_ctrl = m // 2
    m_disease = m - m_ctrl
    n = n_cells_per_subject
    N = m * n
    P = n_genes
    K = n_covars
    K2 = n_context

    # Step 1: subject assignment (no RNG)
    I_subject = torch.zeros(m, dtype=torch.bool)
    I_subject[m_ctrl:] = True
    subject_idx = torch.arange(m).repeat_interleave(n)
    I = I_subject[subject_idx]

    # Step 2: covariates — must match generate_prism_data RNG order exactly
    X = torch.zeros(N, K)
    X[:, 0] = 1.0
    for k in range(1, K):
        X[:, k] = torch.randn(N, generator=gen)
    Z = torch.randn(N, K2, generator=gen)

    # Step 3: draw disease state indicators (same RNG as generate_prism_data)
    d_true = torch.zeros(N, dtype=torch.float32)
    for s in range(m_ctrl, m):
        n_s = n  # constant cells per subject
        cell_mask = subject_idx == s
        d_true[cell_mask] = torch.bernoulli(torch.full((n_s,), rho), generator=gen)

    # Step 4: gene categories and true parameters
    n_null = int(P * frac_null)
    n_fixed = int(P * frac_fixed_de)
    n_context_de = P - n_null - n_fixed
    gene_category = ["null"] * n_null + ["fixed_de"] * n_fixed + ["context_de"] * n_context_de

    beta0_true = torch.zeros(P, K)
    beta0_true[:, 0] = torch.empty(P).uniform_(beta0_range[0], beta0_range[1], generator=gen)
    for k in range(1, K):
        beta0_true[:, k] = torch.empty(P).uniform_(-0.5, 0.5, generator=gen)
    Gamma_true = torch.randn(P, K * K2, generator=gen) * Gamma_scale

    alpha_de_true = torch.zeros(P)
    theta_true = torch.zeros(P, K2)

    for g in range(n_null, n_null + n_fixed):
        sign = 2.0 * torch.bernoulli(torch.tensor(0.5), generator=gen) - 1.0
        mag = torch.empty(1).uniform_(effect_range[0], effect_range[1], generator=gen).item()
        alpha_de_true[g] = sign * mag

    for g in range(n_null + n_fixed, P):
        sign = 2.0 * torch.bernoulli(torch.tensor(0.5), generator=gen) - 1.0
        mag = torch.empty(1).uniform_(effect_range[0], effect_range[1], generator=gen).item()
        alpha_de_true[g] = sign * mag
        for k2 in range(K2):
            sign = 2.0 * torch.bernoulli(torch.tensor(0.5), generator=gen) - 1.0
            mag = torch.empty(1).uniform_(
                context_effect_range[0], context_effect_range[1], generator=gen
            ).item()
            theta_true[g, k2] = sign * mag

    return {
        "gene_category": gene_category,
        "alpha_de_true": alpha_de_true,
        "theta_true": theta_true,
        "beta0_true": beta0_true,
        "Gamma_true": Gamma_true,
        "rho_true": torch.full((m_disease,), rho),
        "d_true": d_true,
        "n_null": n_null,
        "n_fixed_de": n_fixed,
        "n_context_de": n_context_de,
        "X": X,
        "Z": Z,
        "log_pi": torch.zeros(N),  # unit library size (minor approximation for SE only)
        "subject_idx": subject_idx,
        "I": I,
        "n_subjects": m,
        "n_disease_subjects": m_disease,
        "n_cells": N,
    }


def generate_prism_data(
    n_subjects: int = 50,
    n_cells_per_subject: int = 200,
    n_genes: int = 60,
    n_covars: int = 3,
    n_context: int = 1,
    frac_null: float = 0.4,
    frac_fixed_de: float = 0.25,
    frac_context_de: float = 0.35,
    rho: float = 0.5,
    sigma2: float = 0.1,
    phi: float = 10.0,
    effect_range: tuple[float, float] = (0.3, 1.0),
    context_effect_range: tuple[float, float] = (0.3, 1.0),
    beta0_range: tuple[float, float] = (-2.0, 2.0),
    Gamma_scale: float = 0.3,
    pi_mode: str = "gamma",
    seed: int = 42,
    device: str = "cuda",
) -> tuple[PrismData, dict]:
    """Generate synthetic data from the contextualized PRISM model.

    Parameters
    ----------
    n_subjects : m — total subjects (half control, half disease).
    n_cells_per_subject : n_i — cells per subject (constant).
    n_genes : P
    n_covars : K — number of fixed-effect covariates (incl. intercept).
    n_context : K2 — number of context covariates.
    frac_null : fraction of genes with no DE (alpha=0, theta=0).
    frac_fixed_de : fraction of genes with constant DE only (alpha!=0, theta=0).
    frac_context_de : fraction with context-dependent DE (alpha!=0, theta!=0).
    rho : true disease prevalence per disease subject.
    sigma2 : subject-level variance.
    phi : cell-level dispersion (higher = less overdispersion).
    effect_range : (lo, hi) for alpha_de magnitude.
    context_effect_range : (lo, hi) for theta magnitude.
    beta0_range : (lo, hi) for intercept beta_0.
    Gamma_scale : scale of Gamma_g entries ~ N(0, Gamma_scale).
    pi_mode : "gamma" (random library size) or "constant" (pi=1).
    seed : random seed.
    device : target device.

    Returns
    -------
    data : PrismData on the specified device.
    ground_truth : dict with true parameters and labels.
    """
    if not torch.cuda.is_available() and device == "cuda":
        device = "cpu"

    gen = torch.Generator(device="cpu").manual_seed(seed)

    m = n_subjects
    m_ctrl = m // 2
    m_disease = m - m_ctrl
    n = n_cells_per_subject
    N = m * n
    P = n_genes
    K = n_covars
    K2 = n_context

    # ------------------------------------------------------------------
    # 1. Assign subjects
    # ------------------------------------------------------------------
    I_subject = torch.zeros(m, dtype=torch.bool)
    I_subject[m_ctrl:] = True  # second half = disease

    # Per-cell subject index and condition
    subject_idx = torch.arange(m).repeat_interleave(n)  # (N,)
    I = I_subject[subject_idx]  # (N,)

    # Disease subject local index
    disease_global_ids = torch.where(I_subject)[0]
    subject_to_disease = torch.zeros(m, dtype=torch.long)
    for local, glob in enumerate(disease_global_ids):
        subject_to_disease[glob] = local
    disease_subject_idx = subject_to_disease[subject_idx]

    # ------------------------------------------------------------------
    # 2. Covariates X (N, K) and context Z (N, K2)
    # ------------------------------------------------------------------
    X = torch.zeros(N, K)
    X[:, 0] = 1.0  # intercept
    for k in range(1, K):
        X[:, k] = torch.randn(N, generator=gen)

    Z = torch.randn(N, K2, generator=gen)

    # ------------------------------------------------------------------
    # 3. Latent disease states d (N,)
    # ------------------------------------------------------------------
    d_true = torch.zeros(N, dtype=torch.float32)
    for s in range(m_ctrl, m):
        cell_mask = subject_idx == s
        n_s = cell_mask.sum()
        d_true[cell_mask] = torch.bernoulli(
            torch.full((n_s,), rho), generator=gen
        )

    # ------------------------------------------------------------------
    # 4. Gene categories and true parameters
    # ------------------------------------------------------------------
    n_null = int(P * frac_null)
    n_fixed = int(P * frac_fixed_de)
    n_context_de = P - n_null - n_fixed

    gene_category = (
        ["null"] * n_null
        + ["fixed_de"] * n_fixed
        + ["context_de"] * n_context_de
    )

    # beta0_true: (P, K) — baseline fixed effects
    beta0_true = torch.zeros(P, K)
    beta0_true[:, 0] = torch.empty(P).uniform_(beta0_range[0], beta0_range[1], generator=gen)
    for k in range(1, K):
        beta0_true[:, k] = torch.empty(P).uniform_(-0.5, 0.5, generator=gen)

    # Gamma_true: (P, K*K2) — contextualized covariate modulation (ALL cells)
    Gamma_true = torch.randn(P, K * K2, generator=gen) * Gamma_scale

    # alpha_de_true: (P,) — constant disease effect
    alpha_de_true = torch.zeros(P)

    # theta_true: (P, K2) — context-dependent disease effect
    theta_true = torch.zeros(P, K2)

    # Fixed-DE genes: alpha != 0, theta = 0
    for g in range(n_null, n_null + n_fixed):
        sign = 2.0 * torch.bernoulli(torch.tensor(0.5), generator=gen) - 1.0
        mag = torch.empty(1).uniform_(effect_range[0], effect_range[1], generator=gen).item()
        alpha_de_true[g] = sign * mag

    # Context-DE genes: alpha != 0, theta != 0
    for g in range(n_null + n_fixed, P):
        # Constant DE component
        sign = 2.0 * torch.bernoulli(torch.tensor(0.5), generator=gen) - 1.0
        mag = torch.empty(1).uniform_(effect_range[0], effect_range[1], generator=gen).item()
        alpha_de_true[g] = sign * mag
        # Context-varying component
        for k2 in range(K2):
            sign = 2.0 * torch.bernoulli(torch.tensor(0.5), generator=gen) - 1.0
            mag = torch.empty(1).uniform_(
                context_effect_range[0], context_effect_range[1], generator=gen
            ).item()
            theta_true[g, k2] = sign * mag

    # rho_true: (m_disease,)
    rho_true = torch.full((m_disease,), rho)

    # ------------------------------------------------------------------
    # 5. Random effects
    # ------------------------------------------------------------------
    exp_s2 = torch.exp(torch.tensor(float(sigma2)).clamp(max=20.0))
    denom_re = (exp_s2 - 1.0).clamp(min=1e-8)
    alpha_true = 1.0 / denom_re
    lam_true = 1.0 / (torch.exp(torch.tensor(float(sigma2) / 2.0)) * denom_re)

    omega = torch.zeros(m, P)
    for s in range(m):
        omega[s] = torch.distributions.Gamma(alpha_true.expand(P), lam_true.expand(P)).sample()
    omega = omega.clamp(min=1e-6)

    # nu_ijg ~ Gamma(phi, phi)
    phi_t = torch.tensor(float(phi)).expand(N, P)
    nu = torch.distributions.Gamma(phi_t, phi_t).sample()
    nu = nu.clamp(min=1e-6)

    # ------------------------------------------------------------------
    # 6. Library size
    # ------------------------------------------------------------------
    if pi_mode == "gamma":
        pi = torch.distributions.Gamma(torch.ones(N), torch.ones(N)).sample()
        pi = pi.clamp(min=0.1)
    else:
        pi = torch.ones(N)
    log_pi = pi.log()

    # ------------------------------------------------------------------
    # 7. Generate counts
    # ------------------------------------------------------------------
    # Khatri-Rao interaction: XZ = X[:,:,None] * Z[:,None,:] -> (N, K, K2) -> (N, K*K2)
    XZ = (X.unsqueeze(2) * Z.unsqueeze(1)).reshape(N, K * K2)

    # eta = x' beta0 + x' Gamma z + d * (alpha + theta' z)
    eta = X @ beta0_true.T + XZ @ Gamma_true.T  # (N, P)
    delta = alpha_de_true.unsqueeze(0) + Z @ theta_true.T  # (N, P)
    eta = eta + d_true.unsqueeze(1) * delta

    eta = eta.clamp(-20, 20)

    # mu = pi * exp(eta) * nu * omega
    omega_cell = omega[subject_idx]
    mu = pi.unsqueeze(1) * torch.exp(eta) * nu * omega_cell
    mu = mu.clamp(min=1e-6, max=1e8)

    Y = torch.poisson(mu).int()

    # ------------------------------------------------------------------
    # Move to device
    # ------------------------------------------------------------------
    data = PrismData.from_tensors(
        Y=Y.to(device),
        X=X.to(device),
        Z=Z.to(device),
        I=I.to(device),
        log_pi=log_pi.to(device),
        subject_idx=subject_idx.to(device),
        n_subjects=m,
        disease_subject_idx=disease_subject_idx.to(device),
        n_disease_subjects=m_disease,
    )

    ground_truth = {
        "d_true": d_true.to(device),
        "beta0_true": beta0_true.to(device),
        "Gamma_true": Gamma_true.to(device),
        "alpha_de_true": alpha_de_true.to(device),
        "theta_true": theta_true.to(device),
        "rho_true": rho_true.to(device),
        "sigma2_true": torch.tensor(sigma2, device=device),
        "phi_true": torch.tensor(float(phi), device=device),
        "gene_category": gene_category,
        "omega_true": omega.to(device),
        "n_null": n_null,
        "n_fixed_de": n_fixed,
        "n_context_de": n_context_de,
    }

    return data, ground_truth
