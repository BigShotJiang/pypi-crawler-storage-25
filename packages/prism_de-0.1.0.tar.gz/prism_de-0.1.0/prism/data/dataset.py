"""PrismData: core data container for PRISM.

All data is packed into a single dataclass that lives on GPU.
NO repeated CPU-GPU transfers during training.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch
from torch import Tensor


@dataclass
class PrismData:
    """Immutable container for all data needed by the PRISM model.

    All tensors live on the same device (ideally GPU).

    Attributes
    ----------
    Y : (N, P) int32 — UMI count matrix.
    X : (N, K) float32 — fixed-effect covariates (includes intercept).
    Z : (N, K2) float32 — context variables.
    I : (N,) bool — subject-level condition label (True = disease).
    log_pi : (N,) float32 — log library-size offset per cell.
    subject_idx : (N,) int64 — maps each cell to subject 0..m-1.
    n_subjects : int — total number of subjects.
    n_genes : int — P.
    n_cells : int — N.
    n_covars : int — K (number of fixed-effect covariates).
    n_context : int — K2 (number of context covariates).
    disease_subject_idx : (N,) int64 — maps disease cells to 0..m_disease-1
        (undefined for control cells, but still has a value).
    n_disease_subjects : int — number of disease-arm subjects.
    """

    Y: Tensor
    X: Tensor
    Z: Tensor
    I: Tensor
    log_pi: Tensor
    subject_idx: Tensor
    n_subjects: int
    n_genes: int
    n_cells: int
    n_covars: int
    n_context: int
    disease_subject_idx: Tensor
    n_disease_subjects: int

    # ------------------------------------------------------------------
    # Construction helpers
    # ------------------------------------------------------------------

    @classmethod
    def from_anndata(
        cls,
        adata,
        covar_cols: list[str],
        context_cols: list[str],
        condition_col: str,
        subject_col: str,
        library_size_col: Optional[str] = None,
        device: str = "cuda",
        dtype: torch.dtype = torch.float32,
    ) -> "PrismData":
        """Build PrismData from an AnnData object.

        Parameters
        ----------
        adata : anndata.AnnData
            Annotated data matrix (cells × genes).
        covar_cols : list[str]
            Column names in adata.obs for fixed-effect covariates.
        context_cols : list[str]
            Column names in adata.obs for context variables.
        condition_col : str
            Column name for binary condition (0/1 or False/True).
        subject_col : str
            Column name for subject identifier.
        library_size_col : str, optional
            Column name for library size. If None, computed as row sums of Y.
        device : str
            Target device ("cuda" or "cpu").
        dtype : torch.dtype
            Float dtype for X, Z, log_pi.
        """
        import numpy as np

        # Count matrix
        Y_np = adata.X
        if hasattr(Y_np, "toarray"):
            Y_np = Y_np.toarray()
        Y_np = np.asarray(Y_np, dtype=np.int32)
        Y = torch.tensor(Y_np, dtype=torch.int32, device=device)

        N, P = Y.shape

        # Covariates
        X_np = adata.obs[covar_cols].values.astype(np.float32)
        X = torch.tensor(X_np, dtype=dtype, device=device)

        # Context
        Z_np = adata.obs[context_cols].values.astype(np.float32)
        Z = torch.tensor(Z_np, dtype=dtype, device=device)

        # Condition
        I_np = adata.obs[condition_col].values.astype(bool)
        I = torch.tensor(I_np, dtype=torch.bool, device=device)

        # Subject index
        subjects = adata.obs[subject_col].values
        unique_subjects, subject_codes = np.unique(subjects, return_inverse=True)
        subject_idx = torch.tensor(subject_codes, dtype=torch.int64, device=device)
        n_subjects = len(unique_subjects)

        # Disease subject mapping
        disease_subject_flags = np.array(
            [I_np[subject_codes == s].any() for s in range(n_subjects)]
        )
        disease_subject_ids = np.where(disease_subject_flags)[0]
        n_disease = len(disease_subject_ids)
        # Build per-subject mapping: subject_global -> disease_local
        subject_to_disease = np.full(n_subjects, 0, dtype=np.int64)
        for local, global_id in enumerate(disease_subject_ids):
            subject_to_disease[global_id] = local
        disease_subject_idx = torch.tensor(
            subject_to_disease[subject_codes], dtype=torch.int64, device=device
        )

        # Library size
        if library_size_col is not None:
            log_pi_np = np.log(adata.obs[library_size_col].values.astype(np.float32) + 1e-8)
        else:
            log_pi_np = np.log(Y_np.sum(axis=1).astype(np.float32) + 1e-8)
        log_pi = torch.tensor(log_pi_np, dtype=dtype, device=device)

        return cls(
            Y=Y,
            X=X,
            Z=Z,
            I=I,
            log_pi=log_pi,
            subject_idx=subject_idx,
            n_subjects=n_subjects,
            n_genes=P,
            n_cells=N,
            n_covars=X.shape[1],
            n_context=Z.shape[1],
            disease_subject_idx=disease_subject_idx,
            n_disease_subjects=n_disease,
        )

    @classmethod
    def from_tensors(
        cls,
        Y: Tensor,
        X: Tensor,
        Z: Tensor,
        I: Tensor,
        log_pi: Tensor,
        subject_idx: Tensor,
        n_subjects: int,
        disease_subject_idx: Tensor,
        n_disease_subjects: int,
    ) -> "PrismData":
        """Build PrismData directly from tensors (all on the same device)."""
        N, P = Y.shape
        return cls(
            Y=Y,
            X=X,
            Z=Z,
            I=I,
            log_pi=log_pi,
            subject_idx=subject_idx,
            n_subjects=n_subjects,
            n_genes=P,
            n_cells=N,
            n_covars=X.shape[1],
            n_context=Z.shape[1],
            disease_subject_idx=disease_subject_idx,
            n_disease_subjects=n_disease_subjects,
        )

    # ------------------------------------------------------------------
    def to(self, device: str | torch.device) -> "PrismData":
        """Move all tensors to *device* and return a new PrismData."""
        return PrismData(
            Y=self.Y.to(device),
            X=self.X.to(device),
            Z=self.Z.to(device),
            I=self.I.to(device),
            log_pi=self.log_pi.to(device),
            subject_idx=self.subject_idx.to(device),
            n_subjects=self.n_subjects,
            n_genes=self.n_genes,
            n_cells=self.n_cells,
            n_covars=self.n_covars,
            n_context=self.n_context,
            disease_subject_idx=self.disease_subject_idx.to(device),
            n_disease_subjects=self.n_disease_subjects,
        )

    def cells_for_subject(self, i: int) -> Tensor:
        """Boolean mask for cells belonging to subject *i*."""
        return self.subject_idx == i

    @property
    def device(self) -> torch.device:
        return self.Y.device
