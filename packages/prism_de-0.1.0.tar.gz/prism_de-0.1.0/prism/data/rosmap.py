"""ROSMAP dataset preprocessing for PRISM.

Steps:
    1. Load pre-processed h5ad (from Mathys et al. 2023 companion data).
    2. Optional: merge with individual-level metadata TSV.
    3. Filter cell type (supports exact match or prefix, e.g. "Mic").
    4. QC: 3 MADs on total counts + detected genes.
    5. Filter genes: CPC > threshold per cell type.
    6. Select highly variable genes (top *n_hvgs*, default 5 000).
    7. Compute cell-level QC covariates (nFeature_RNA, percent_ribo).
    8. Compute PCs on normalised expression → context variables.
    9. Build PrismData:
       - X: [intercept, age_death, msex, pmi, nFeature_RNA, percent_ribo]
       - I: AD diagnosis (Pathologic_diagnosis_of_AD)
       - Z: [PC_1, PC_2]  (expandable with braak/apoe if available)
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import torch

from .dataset import PrismData


# ── Default column mappings ──────────────────────────────────────────
DEFAULT_COVAR_COLS = [
    "intercept",
    "age_death",
    "msex",
    "pmi",
    "nFeature_RNA",
    "percent_ribo",
]

DEFAULT_CONTEXT_COLS = [
    "PC_1",
    "PC_2",
]

# Extended context when Synapse full metadata is available
EXTENDED_CONTEXT_COLS = [
    "braak",
    "apoe_e4",
    "PC_1",
    "PC_2",
]

DEFAULT_CONDITION_COL = "Pathologic_diagnosis_of_AD"
DEFAULT_SUBJECT_COL = "subject"

# Cell-type prefixes for the Mathys 2023 high-resolution types
CELL_TYPE_PREFIXES = {
    "microglia": "Mic",
    "astrocytes": "Ast",
    "oligodendrocytes": "Oli",
    "opc": "OPC",
    "excitatory_neurons": "Exc",
    "inhibitory_neurons": "Inh",
    "immune": "Mic",  # alias
}


def preprocess_rosmap(
    adata_path: str | Path,
    metadata_path: Optional[str | Path] = None,
    cell_type: str = "microglia",
    covar_cols: Optional[list[str]] = None,
    context_cols: Optional[list[str]] = None,
    condition_col: str = DEFAULT_CONDITION_COL,
    subject_col: str = DEFAULT_SUBJECT_COL,
    cell_type_col: str = "cell_type_high_resolution",
    min_cells_per_gene_pct: float = 0.1,
    n_hvgs: Optional[int] = 5000,
    qc_mad_threshold: float = 3.0,
    n_pcs: int = 2,
    min_cells_per_subject: int = 5,
    ribo_prefix: str = "RPL|RPS",
    device: str = "cuda",
    verbose: bool = True,
    return_anndata: bool = False,
) -> "PrismData | tuple[PrismData, Any]":
    """Load and preprocess ROSMAP data into PrismData.

    Parameters
    ----------
    adata_path : path to the h5ad file.
    metadata_path : optional path to individual-level metadata TSV/CSV.
    return_anndata : if True, return (PrismData, filtered_adata) tuple.
    cell_type : cell type to filter on.  Accepts a key from
        ``CELL_TYPE_PREFIXES`` (e.g. "microglia") or a raw prefix/exact
        value to match against ``cell_type_col``.
    covar_cols : fixed-effect covariate columns in obs.
    context_cols : context covariate columns in obs.
    condition_col : binary condition column in obs.
    subject_col : subject identifier column in obs.
    cell_type_col : column with cell-type annotations.
    min_cells_per_gene_pct : min % of cells expressing a gene to keep it.
    n_hvgs : number of highly variable genes to select (None to skip).
    qc_mad_threshold : number of MADs for QC filtering.
    n_pcs : number of PCs to add to context if PC columns not present.
    min_cells_per_subject : drop subjects with fewer cells.
    ribo_prefix : regex for ribosomal gene names.
    device : target device.
    verbose : print progress.

    Returns
    -------
    PrismData
    """
    import scanpy as sc
    import pandas as pd

    def _log(msg: str) -> None:
        if verbose:
            print(f"[ROSMAP] {msg}")

    covar_cols = list(covar_cols or DEFAULT_COVAR_COLS)
    context_cols = list(context_cols or DEFAULT_CONTEXT_COLS)

    # ── 1. Load ──────────────────────────────────────────────────────
    _log(f"Loading {adata_path}")
    adata = sc.read_h5ad(adata_path)
    _log(f"  Loaded: {adata.shape[0]:,} cells × {adata.shape[1]:,} genes")

    # ── 2. Merge metadata if provided ────────────────────────────────
    if metadata_path is not None:
        _log(f"Merging metadata from {metadata_path}")
        sep = "\t" if str(metadata_path).endswith(".tsv") else ","
        meta = pd.read_csv(metadata_path, sep=sep)
        # Only merge columns not already present (avoid _x/_y suffixes)
        existing_cols = set(adata.obs.columns) - {subject_col}
        new_cols = [c for c in meta.columns if c not in existing_cols]
        if new_cols:
            meta_subset = meta[[subject_col] + [c for c in new_cols if c != subject_col]]
            adata.obs = adata.obs.merge(
                meta_subset, left_on=subject_col, right_on=subject_col, how="left"
            )
            adata.obs.index = adata.obs.index.astype(str)
        else:
            _log("  All metadata columns already present; skipping merge")

    # ── 3. Filter cell type ──────────────────────────────────────────
    prefix = CELL_TYPE_PREFIXES.get(cell_type, cell_type)
    if cell_type_col in adata.obs.columns:
        mask = adata.obs[cell_type_col].str.startswith(prefix)
        adata = adata[mask].copy()
        _log(f"  After cell-type filter ({prefix}*): {adata.shape[0]:,} cells")
    elif "cell_type" in adata.obs.columns:
        adata = adata[adata.obs["cell_type"] == cell_type].copy()
    elif "broad_cell_type" in adata.obs.columns:
        adata = adata[adata.obs["broad_cell_type"] == cell_type].copy()

    # ── 4. Drop subjects with too few cells ──────────────────────────
    if subject_col in adata.obs.columns:
        counts_per_subj = adata.obs[subject_col].value_counts()
        keep_subj = counts_per_subj[counts_per_subj >= min_cells_per_subject].index
        pre = adata.shape[0]
        adata = adata[adata.obs[subject_col].isin(keep_subj)].copy()
        _log(
            f"  Dropped subjects with <{min_cells_per_subject} cells: "
            f"{pre:,} → {adata.shape[0]:,} cells "
            f"({adata.obs[subject_col].nunique()} subjects)"
        )

    # ── 5. QC: 3 MADs on total counts and n_genes ────────────────────
    sc.pp.calculate_qc_metrics(adata, inplace=True)
    pre = adata.shape[0]
    for col in ["total_counts", "n_genes_by_counts"]:
        if col not in adata.obs.columns:
            continue
        med = adata.obs[col].median()
        mad = np.median(np.abs(adata.obs[col] - med))
        if mad == 0:
            continue
        lo = med - qc_mad_threshold * mad
        hi = med + qc_mad_threshold * mad
        mask = (adata.obs[col] >= lo) & (adata.obs[col] <= hi)
        adata = adata[mask].copy()
    _log(f"  QC (3-MAD): {pre:,} → {adata.shape[0]:,} cells")

    # ── 6. Gene filtering: CPC > threshold ──────────────────────────
    n_cells = adata.shape[0]
    gene_counts = np.asarray((adata.X > 0).sum(axis=0)).flatten()
    gene_mask = gene_counts / n_cells > (min_cells_per_gene_pct / 100.0)
    adata = adata[:, gene_mask].copy()
    _log(f"  Gene filter (CPC>{min_cells_per_gene_pct}%): {gene_mask.sum():,} genes kept")

    # ── 6b. Select highly variable genes ─────────────────────────────
    if n_hvgs is not None and adata.shape[1] > n_hvgs:
        _log(f"  Selecting top {n_hvgs:,} highly variable genes")
        # Use seurat_v3 flavor on raw counts (works directly on .X)
        sc.pp.highly_variable_genes(
            adata, n_top_genes=n_hvgs, flavor="seurat_v3", subset=False,
        )
        adata = adata[:, adata.var["highly_variable"]].copy()
        _log(f"  After HVG selection: {adata.shape[1]:,} genes")

    # ── 7. Compute cell-level QC covariates ──────────────────────────
    # nFeature_RNA
    if "nFeature_RNA" not in adata.obs.columns:
        adata.obs["nFeature_RNA"] = np.asarray((adata.X > 0).sum(axis=1)).flatten().astype(float)

    # percent_ribo
    if "percent_ribo" not in adata.obs.columns:
        ribo_genes = adata.var_names.str.match(ribo_prefix)
        if ribo_genes.sum() > 0:
            ribo_counts = np.asarray(adata[:, ribo_genes].X.sum(axis=1)).flatten()
            total_counts = np.asarray(adata.X.sum(axis=1)).flatten()
            adata.obs["percent_ribo"] = ribo_counts / np.clip(total_counts, 1, None) * 100
        else:
            _log("  WARNING: no ribosomal genes found; dropping percent_ribo")
            if "percent_ribo" in covar_cols:
                covar_cols.remove("percent_ribo")

    # ── 8. Add intercept ─────────────────────────────────────────────
    if "intercept" not in adata.obs.columns:
        adata.obs["intercept"] = 1.0

    # ── 9. Compute PCs if not present ────────────────────────────────
    pc_cols = [f"PC_{i}" for i in range(1, n_pcs + 1)]
    if not all(pc in adata.obs.columns for pc in pc_cols):
        _log(f"  Computing {n_pcs} PCs on log-normalised expression")
        adata_pp = adata.copy()
        sc.pp.normalize_total(adata_pp, target_sum=1e4)
        sc.pp.log1p(adata_pp)
        sc.pp.pca(adata_pp, n_comps=max(n_pcs, 10))
        for i in range(n_pcs):
            adata.obs[f"PC_{i+1}"] = adata_pp.obsm["X_pca"][:, i]
        del adata_pp

    # ── 10. Encode condition as binary int ───────────────────────────
    if condition_col in adata.obs.columns:
        cond = adata.obs[condition_col]
        if cond.dtype == object or cond.dtype.name == "category":
            # Handle "yes"/"no" or "AD"/"control"
            adata.obs[condition_col] = cond.map(
                lambda x: 1 if str(x).lower() in ("yes", "ad", "1", "true") else 0
            ).astype(int)
        _log(
            f"  Condition ({condition_col}): "
            f"{(adata.obs[condition_col] == 1).sum()} disease / "
            f"{(adata.obs[condition_col] == 0).sum()} control cells"
        )

    # ── 11. Drop missing ─────────────────────────────────────────────
    all_needed = [c for c in covar_cols + context_cols + [condition_col, subject_col]
                  if c in adata.obs.columns]
    pre = adata.shape[0]
    adata = adata[adata.obs[all_needed].notna().all(axis=1)].copy()
    if adata.shape[0] < pre:
        _log(f"  Dropped {pre - adata.shape[0]} cells with missing covariates")

    # ── 12. Filter to available columns ──────────────────────────────
    covar_cols = [c for c in covar_cols if c in adata.obs.columns]
    context_cols = [c for c in context_cols if c in adata.obs.columns]
    _log(f"  Covariates: {covar_cols}")
    _log(f"  Context:    {context_cols}")

    # ── 13. Standardize continuous covariates ────────────────────────
    for col in covar_cols + context_cols:
        if col == "intercept" or adata.obs[col].nunique() <= 2:
            continue
        # Ensure column is plain (not categorical)
        raw = adata.obs[col]
        if hasattr(raw, "cat"):
            raw = raw.astype(str)
        # Handle non-numeric entries (e.g. "90+" for age_death)
        vals = pd.to_numeric(raw.astype(str).str.replace(r"[^0-9.\-]", "", regex=True),
                             errors="coerce")
        n_bad = vals.isna().sum() - adata.obs[col].isna().sum()
        if n_bad > 0:
            _log(f"  {col}: coerced {n_bad} non-numeric values → median")
        vals = vals.fillna(vals.median())
        std = max(vals.std(), 1e-8)
        adata.obs[col] = ((vals - vals.mean()) / std).astype(float)

    _log(
        f"  Final: {adata.shape[0]:,} cells × {adata.shape[1]:,} genes, "
        f"{adata.obs[subject_col].nunique()} subjects"
    )

    # ── 14. Build PrismData ──────────────────────────────────────────
    prism_data = PrismData.from_anndata(
        adata,
        covar_cols=covar_cols,
        context_cols=context_cols,
        condition_col=condition_col,
        subject_col=subject_col,
        device=device,
    )
    if return_anndata:
        return prism_data, adata
    return prism_data
