"""Misspecified simulation scenarios for robustness experiments.

These generators produce data from DGPs that VIOLATE one or more PRISM
assumptions, testing robustness of the method under model misspecification.

Scenarios
---------
1. contaminated_controls : Some control cells harbour latent disease signal.
2. nonlinear_context     : True Δ_g(z) is nonlinear; PRISM fits linear.
3. continuous_latent     : d_ij ∈ [0,1] (Beta) rather than binary {0,1}.
4. batch_confounding     : Unseen batch effect correlated with condition.
5. variable_cells        : n_i varies across subjects (unbalanced design).
6. zero_inflated         : Excess zeros beyond NB model (ZINB DGP).
"""

from __future__ import annotations

from typing import Optional

import torch
from torch import Tensor

from .dataset import PrismData
from .simulation import generate_prism_data


def generate_misspecified_data(
    scenario: str,
    severity: float = 0.5,
    *,
    # All standard PRISM params forwarded:
    n_subjects: int = 100,
    n_cells_per_subject: int = 800,
    n_genes: int = 500,
    n_covars: int = 3,
    n_context: int = 1,
    frac_null: float = 0.4,
    frac_fixed_de: float = 0.25,
    frac_context_de: float = 0.35,
    rho: float = 0.6,
    sigma2: float = 0.15,
    phi: float = 10.0,
    effect_range: tuple[float, float] = (0.3, 1.0),
    context_effect_range: tuple[float, float] = (0.3, 1.0),
    beta0_range: tuple[float, float] = (-2.0, 2.0),
    pi_mode: str = "gamma",
    seed: int = 42,
    device: str = "cuda",
) -> tuple[PrismData, dict]:
    """Generate data under a specified misspecification scenario.

    Parameters
    ----------
    scenario : one of {"contaminated_controls", "nonlinear_context",
               "continuous_latent", "batch_confounding", "variable_cells",
               "zero_inflated"}.
    severity : float in [0, 1] controlling how far from the PRISM DGP
               the data are.  0 = no misspecification, 1 = maximum.
    **kwargs  : forwarded to the base generator.

    Returns
    -------
    data : PrismData (may be modified from the base generator).
    ground_truth : dict — includes original ground truth plus
                   ``misspec_info`` sub-dict with scenario details.
    """
    base_kw = dict(
        n_subjects=n_subjects,
        n_cells_per_subject=n_cells_per_subject,
        n_genes=n_genes,
        n_covars=n_covars,
        n_context=n_context,
        frac_null=frac_null,
        frac_fixed_de=frac_fixed_de,
        frac_context_de=frac_context_de,
        rho=rho,
        sigma2=sigma2,
        phi=phi,
        effect_range=effect_range,
        context_effect_range=context_effect_range,
        beta0_range=beta0_range,
        pi_mode=pi_mode,
        seed=seed,
        device=device,
    )

    _SCENARIOS = {
        "contaminated_controls": _contaminated_controls,
        "nonlinear_context": _nonlinear_context,
        "continuous_latent": _continuous_latent,
        "batch_confounding": _batch_confounding,
        "variable_cells": _variable_cells,
        "zero_inflated": _zero_inflated,
    }

    if scenario not in _SCENARIOS:
        raise ValueError(
            f"Unknown scenario '{scenario}'. "
            f"Choose from {list(_SCENARIOS.keys())}"
        )

    return _SCENARIOS[scenario](severity=severity, **base_kw)


def _contaminated_controls(
    severity: float,
    **kw,
) -> tuple[PrismData, dict]:
    """Some fraction (= severity) of control cells harbour disease signal.

    This violates Assumption 1 (the asymmetric anchor: all control cells
    are truly healthy).  Specifically, we draw d_ij ~ Bernoulli(severity)
    for control cells, then regenerate counts Y with those latent states.

    severity = 0 → standard PRISM; severity = 0.3 → 30% control cells
    are actually diseased (label noise in the control arm).
    """
    data, gt = generate_prism_data(**kw)

    if severity <= 0:
        gt["misspec_info"] = {"scenario": "contaminated_controls",
                              "severity": 0.0, "n_contaminated": 0}
        return data, gt

    gen = torch.Generator(device="cpu").manual_seed(kw["seed"] + 999)

    d_true = gt["d_true"].cpu().clone()
    I = data.I.cpu()
    ctrl_mask = ~I  # control cells

    # Flip a fraction of control cells to d=1
    ctrl_indices = torch.where(ctrl_mask)[0]
    n_flip = int(severity * len(ctrl_indices))
    flip_perm = torch.randperm(len(ctrl_indices), generator=gen)[:n_flip]
    flip_idx = ctrl_indices[flip_perm]
    d_true[flip_idx] = 1.0

    # Regenerate Y using contaminated d
    data, gt = _regenerate_counts_with_d(data, gt, d_true, kw)
    gt["misspec_info"] = {
        "scenario": "contaminated_controls",
        "severity": float(severity),
        "n_contaminated": int(n_flip),
    }
    return data, gt


def _nonlinear_context(
    severity: float,
    **kw,
) -> tuple[PrismData, dict]:
    """True Δ_g(z) is nonlinear; PRISM fits linear.

    We replace the linear context effect with:
        Δ_g(z) = θ_g z + severity * θ_g * sin(2πz)
    so severity=0 recovers linear, severity=1 adds a strong sinusoidal
    component that a linear encoder cannot capture.

    Ground-truth labels (which genes are context-DE) are unchanged.
    """
    data, gt = generate_prism_data(**kw)

    if severity <= 0:
        gt["misspec_info"] = {"scenario": "nonlinear_context", "severity": 0.0}
        return data, gt

    # Retrieve tensors on CPU for manipulation
    dev = data.device
    Y_cpu = data.Y.cpu().float()
    X_cpu = data.X.cpu()
    Z_cpu = data.Z.cpu()
    d_true = gt["d_true"].cpu()
    theta_true = gt["theta_true"].cpu()
    beta_true = gt["beta_true"].cpu()
    omega_true = gt["omega_true"].cpu()
    log_pi = data.log_pi.cpu()
    subject_idx = data.subject_idx.cpu()

    gen = torch.Generator(device="cpu").manual_seed(kw["seed"] + 777)

    N = data.n_cells
    P = data.n_genes

    # Compute nonlinear delta: theta_g * z + severity * theta_g * sin(2*pi*z)
    linear_delta = Z_cpu @ theta_true.T  # (N, P)
    # For K2-dim: Δ_g(z) = Σ_k [θ_{gk} * z_k + sev * θ_{gk} * sin(2π z_k)]
    nonlinear_delta = torch.zeros(N, P)
    for k2 in range(data.n_context):
        z_k = Z_cpu[:, k2]  # (N,)
        th_k = theta_true[:, k2]  # (P,)
        linear_part = z_k.unsqueeze(1) * th_k.unsqueeze(0)  # (N, P)
        sin_part = severity * th_k.unsqueeze(0) * torch.sin(
            2 * torch.pi * z_k
        ).unsqueeze(1)
        nonlinear_delta += linear_part + sin_part

    # Recompute eta with nonlinear delta
    eta = X_cpu @ beta_true.T  # (N, P)
    eta = eta + d_true.unsqueeze(1) * nonlinear_delta
    eta = eta.clamp(-20, 20)

    # Reuse random effects from original generation
    phi_val = kw.get("phi", 10.0)
    phi_t = torch.tensor(phi_val).expand(N, P)
    nu = torch.distributions.Gamma(phi_t, phi_t).sample()
    nu = nu.clamp(min=1e-6)

    pi = log_pi.exp()
    omega_cell = omega_true[subject_idx]

    mu = pi.unsqueeze(1) * torch.exp(eta) * nu * omega_cell
    mu = mu.clamp(min=1e-6, max=1e8)
    Y_new = torch.poisson(mu).int()

    # Replace Y in data
    data = PrismData.from_tensors(
        Y=Y_new.to(dev), X=data.X, Z=data.Z, I=data.I,
        log_pi=data.log_pi, subject_idx=data.subject_idx,
        n_subjects=data.n_subjects,
        disease_subject_idx=data.disease_subject_idx,
        n_disease_subjects=data.n_disease_subjects,
    )

    gt["misspec_info"] = {
        "scenario": "nonlinear_context",
        "severity": float(severity),
    }
    return data, gt


def _continuous_latent(
    severity: float,
    **kw,
) -> tuple[PrismData, dict]:
    """d_ij ∈ [0,1] from a Beta distribution rather than binary.

    For disease subjects:
        d_ij ~ Beta(a, b)  with  mean = ρ,  concentration = 1/severity
    As severity → 0, concentration → ∞ and Beta → point mass at ρ ≈ binary.
    As severity → 1, Beta(ρ/1, (1-ρ)/1) spreads across [0,1].

    The model assumes binary d_ij; continuous d tests whether EM can
    handle graded disease states.
    """
    data, gt = generate_prism_data(**kw)

    if severity <= 0:
        gt["misspec_info"] = {"scenario": "continuous_latent", "severity": 0.0}
        return data, gt

    dev = data.device
    rho_val = kw.get("rho", 0.6)
    gen = torch.Generator(device="cpu").manual_seed(kw["seed"] + 555)

    # Beta parameters: mean=rho, concentration kappa = 1/severity
    # a = rho * kappa, b = (1-rho) * kappa
    kappa = 1.0 / max(severity, 0.01)
    a = rho_val * kappa
    b = (1.0 - rho_val) * kappa

    d_true = gt["d_true"].cpu().clone()
    I = data.I.cpu()

    # For disease cells, replace binary d with continuous Beta draws
    disease_mask = I
    n_disease = disease_mask.sum().item()
    d_continuous = torch.distributions.Beta(
        torch.tensor(a), torch.tensor(b)
    ).sample((n_disease,))
    d_true[disease_mask] = d_continuous
    # Control cells remain d=0

    # Store the original binary for evaluation
    gt["d_true_binary"] = gt["d_true"].clone()

    # Regenerate counts with continuous d
    data, gt = _regenerate_counts_with_d(data, gt, d_true, kw)
    gt["misspec_info"] = {
        "scenario": "continuous_latent",
        "severity": float(severity),
        "beta_a": float(a),
        "beta_b": float(b),
    }
    return data, gt


def _batch_confounding(
    severity: float,
    **kw,
) -> tuple[PrismData, dict]:
    """Add batch effects that correlate with condition but are NOT in the model.

    We simulate 2 batches such that batch is partially confounded with
    condition (fraction = 0.5 + 0.5*severity overlap).  Batch shifts
    baseline expression by a gene-specific offset:
        log μ → log μ + batch_effect_g * I(batch=1)
    where batch_effect_g ~ N(0, severity * 0.5).

    The batch covariate is NOT included in X, so the model cannot
    adjust for it.  This creates a nuisance variable that inflates FPR.
    """
    data, gt = generate_prism_data(**kw)

    if severity <= 0:
        gt["misspec_info"] = {"scenario": "batch_confounding", "severity": 0.0}
        return data, gt

    dev = data.device
    gen = torch.Generator(device="cpu").manual_seed(kw["seed"] + 333)

    m = data.n_subjects
    N = data.n_cells
    P = data.n_genes
    subject_idx = data.subject_idx.cpu()
    I_subject = torch.zeros(m, dtype=torch.bool)
    m_ctrl = m // 2
    I_subject[m_ctrl:] = True

    # Assign batches: partially confounded with condition
    # confound_prob: probability that a disease subject is in batch 1
    confound_prob = 0.5 + 0.5 * severity  # severity=0 → random; =1 → perfect
    batch_subject = torch.zeros(m, dtype=torch.long)
    for s in range(m):
        if I_subject[s]:
            batch_subject[s] = int(
                torch.bernoulli(torch.tensor(confound_prob), generator=gen)
            )
        else:
            batch_subject[s] = int(
                torch.bernoulli(torch.tensor(1.0 - confound_prob), generator=gen)
            )

    batch_cell = batch_subject[subject_idx]  # (N,)

    # Gene-specific batch effects
    batch_effect = torch.randn(P, generator=gen) * severity * 0.5  # (P,)

    # Add batch shift to Y (regenerate counts)
    X_cpu = data.X.cpu()
    Z_cpu = data.Z.cpu()
    d_true = gt["d_true"].cpu()
    beta_true = gt["beta_true"].cpu()
    theta_true = gt["theta_true"].cpu()
    omega_true = gt["omega_true"].cpu()
    log_pi = data.log_pi.cpu()

    eta = X_cpu @ beta_true.T  # (N, P)
    delta = Z_cpu @ theta_true.T
    eta = eta + d_true.unsqueeze(1) * delta
    # Add batch effect (not modelled!)
    eta = eta + batch_cell.float().unsqueeze(1) * batch_effect.unsqueeze(0)
    eta = eta.clamp(-20, 20)

    phi_val = kw.get("phi", 10.0)
    phi_t = torch.tensor(phi_val).expand(N, P)
    nu = torch.distributions.Gamma(phi_t, phi_t).sample()
    nu = nu.clamp(min=1e-6)

    pi = log_pi.exp()
    omega_cell = omega_true[subject_idx]

    mu = pi.unsqueeze(1) * torch.exp(eta) * nu * omega_cell
    mu = mu.clamp(min=1e-6, max=1e8)
    Y_new = torch.poisson(mu).int()

    data = PrismData.from_tensors(
        Y=Y_new.to(dev), X=data.X, Z=data.Z, I=data.I,
        log_pi=data.log_pi, subject_idx=data.subject_idx,
        n_subjects=data.n_subjects,
        disease_subject_idx=data.disease_subject_idx,
        n_disease_subjects=data.n_disease_subjects,
    )

    gt["misspec_info"] = {
        "scenario": "batch_confounding",
        "severity": float(severity),
        "batch_subject": batch_subject.numpy().tolist(),
        "batch_effect": batch_effect.numpy().tolist(),
    }
    return data, gt


def _variable_cells(
    severity: float,
    **kw,
) -> tuple[PrismData, dict]:
    """Subjects have variable numbers of cells (unbalanced design).

    n_i ~ max(10, Poisson(n_cells_per_subject * scale_i))
    where scale_i ~ LogNormal(0, severity).

    severity=0 → constant n_i; severity=1 → some subjects have 10×
    more cells than others.
    """
    if severity <= 0:
        data, gt = generate_prism_data(**kw)
        gt["misspec_info"] = {"scenario": "variable_cells", "severity": 0.0}
        return data, gt

    if not torch.cuda.is_available() and kw.get("device", "cuda") == "cuda":
        kw["device"] = "cpu"

    gen = torch.Generator(device="cpu").manual_seed(kw["seed"])
    dev = kw.get("device", "cpu")

    m = kw["n_subjects"]
    n_base = kw["n_cells_per_subject"]
    P = kw["n_genes"]
    K = kw["n_covars"]
    K2 = kw["n_context"]
    rho_val = kw.get("rho", 0.6)
    sigma2_val = kw.get("sigma2", 0.15)
    phi_val = kw.get("phi", 10.0)

    m_ctrl = m // 2
    m_disease = m - m_ctrl

    # Draw variable cell counts
    scales = torch.empty(m).log_normal_(mean=0, std=severity, generator=gen)
    n_cells = (n_base * scales).int().clamp(min=10)
    n_cells_list = n_cells.tolist()
    N = sum(n_cells_list)

    # Build subject_idx
    subject_idx = torch.cat([
        torch.full((nc,), s, dtype=torch.long) for s, nc in enumerate(n_cells_list)
    ])

    I_subject = torch.zeros(m, dtype=torch.bool)
    I_subject[m_ctrl:] = True
    I = I_subject[subject_idx]

    disease_global_ids = torch.where(I_subject)[0]
    subject_to_disease = torch.zeros(m, dtype=torch.long)
    for local, glob in enumerate(disease_global_ids):
        subject_to_disease[glob] = local
    disease_subject_idx = subject_to_disease[subject_idx]

    # Covariates
    X = torch.zeros(N, K)
    X[:, 0] = 1.0
    if K >= 2:
        X[:, 1] = torch.randn(N, generator=gen)
    if K >= 3:
        X[:, 2] = I.float()
    Z = torch.randn(N, K2, generator=gen)

    # Latent states
    d_true = torch.zeros(N, dtype=torch.float32)
    for s in range(m_ctrl, m):
        mask = subject_idx == s
        n_s = mask.sum()
        d_true[mask] = torch.bernoulli(
            torch.full((n_s,), rho_val), generator=gen
        )

    # Gene categories
    frac_null = kw.get("frac_null", 0.4)
    frac_fixed_de = kw.get("frac_fixed_de", 0.25)
    n_null = int(P * frac_null)
    n_fixed = int(P * frac_fixed_de)
    n_context_de = P - n_null - n_fixed
    gene_category = ["null"] * n_null + ["fixed_de"] * n_fixed + ["context_de"] * n_context_de

    # Parameters
    eff_lo, eff_hi = kw.get("effect_range", (0.3, 1.0))
    ctx_lo, ctx_hi = kw.get("context_effect_range", (0.3, 1.0))
    b0_lo, b0_hi = kw.get("beta0_range", (-2.0, 2.0))

    beta_true = torch.zeros(P, K)
    beta_true[:, 0] = torch.empty(P).uniform_(b0_lo, b0_hi, generator=gen)
    for k in range(1, K):
        beta_true[:, k] = torch.empty(P).uniform_(-0.5, 0.5, generator=gen)

    theta_true = torch.zeros(P, K2)
    for g in range(n_null, n_null + n_fixed):
        sign = 2.0 * torch.bernoulli(torch.tensor(0.5), generator=gen) - 1.0
        mag = torch.empty(1).uniform_(eff_lo, eff_hi, generator=gen).item()
        if K >= 3:
            beta_true[g, 2] += sign * mag
        else:
            beta_true[g, 0] += sign * mag
    for g in range(n_null + n_fixed, P):
        for k2 in range(K2):
            sign = 2.0 * torch.bernoulli(torch.tensor(0.5), generator=gen) - 1.0
            mag = torch.empty(1).uniform_(ctx_lo, ctx_hi, generator=gen).item()
            theta_true[g, k2] = sign * mag

    rho_true = torch.full((m_disease,), rho_val)

    # Random effects
    exp_s2 = torch.exp(torch.tensor(sigma2_val).clamp(max=20.0))
    denom = (exp_s2 - 1.0).clamp(min=1e-8)
    alpha_true = 1.0 / denom
    lam_true = 1.0 / (torch.exp(torch.tensor(sigma2_val / 2.0)) * denom)

    omega = torch.zeros(m, P)
    for s in range(m):
        omega[s] = torch.distributions.Gamma(
            alpha_true.expand(P), lam_true.expand(P)
        ).sample()
    omega = omega.clamp(min=1e-6)

    phi_t = torch.tensor(phi_val).expand(N, P)
    nu = torch.distributions.Gamma(phi_t, phi_t).sample()
    nu = nu.clamp(min=1e-6)

    if kw.get("pi_mode", "gamma") == "gamma":
        pi = torch.distributions.Gamma(torch.ones(N), torch.ones(N)).sample().clamp(min=0.1)
    else:
        pi = torch.ones(N)
    log_pi = pi.log()

    # Counts
    eta = X @ beta_true.T + d_true.unsqueeze(1) * (Z @ theta_true.T)
    eta = eta.clamp(-20, 20)
    omega_cell = omega[subject_idx]
    mu = pi.unsqueeze(1) * torch.exp(eta) * nu * omega_cell
    mu = mu.clamp(min=1e-6, max=1e8)
    Y = torch.poisson(mu).int()

    data = PrismData.from_tensors(
        Y=Y.to(dev), X=X.to(dev), Z=Z.to(dev), I=I.to(dev),
        log_pi=log_pi.to(dev), subject_idx=subject_idx.to(dev),
        n_subjects=m,
        disease_subject_idx=disease_subject_idx.to(dev),
        n_disease_subjects=m_disease,
    )
    ground_truth = {
        "d_true": d_true.to(dev),
        "beta_true": beta_true.to(dev),
        "theta_true": theta_true.to(dev),
        "rho_true": rho_true.to(dev),
        "sigma2_true": torch.tensor(sigma2_val, device=dev),
        "phi_true": torch.tensor(phi_val, device=dev),
        "gene_category": gene_category,
        "omega_true": omega.to(dev),
        "n_null": n_null,
        "n_fixed_de": n_fixed,
        "n_context_de": n_context_de,
        "misspec_info": {
            "scenario": "variable_cells",
            "severity": float(severity),
            "n_cells_per_subject": n_cells_list,
        },
    }
    return data, ground_truth


def _zero_inflated(
    severity: float,
    **kw,
) -> tuple[PrismData, dict]:
    """Excess zeros beyond the NB model (ZINB DGP).

    Each count is set to zero with probability p_zero = severity * 0.3,
    independently of the NB draw.  This mimics dropout / technical zeros
    that are not captured by the NB.
    """
    data, gt = generate_prism_data(**kw)

    if severity <= 0:
        gt["misspec_info"] = {"scenario": "zero_inflated", "severity": 0.0}
        return data, gt

    gen = torch.Generator(device="cpu").manual_seed(kw["seed"] + 111)

    p_zero = severity * 0.3  # max 30% dropout at severity=1
    Y_cpu = data.Y.cpu().float()
    dropout_mask = torch.bernoulli(
        torch.full(Y_cpu.shape, p_zero), generator=gen
    ).bool()
    Y_cpu[dropout_mask] = 0
    Y_new = Y_cpu.int()

    dev = data.device
    data = PrismData.from_tensors(
        Y=Y_new.to(dev), X=data.X, Z=data.Z, I=data.I,
        log_pi=data.log_pi, subject_idx=data.subject_idx,
        n_subjects=data.n_subjects,
        disease_subject_idx=data.disease_subject_idx,
        n_disease_subjects=data.n_disease_subjects,
    )

    gt["misspec_info"] = {
        "scenario": "zero_inflated",
        "severity": float(severity),
        "p_zero": float(p_zero),
    }
    return data, gt


def _regenerate_counts_with_d(
    data: PrismData,
    gt: dict,
    d_new: Tensor,
    kw: dict,
) -> tuple[PrismData, dict]:
    """Re-draw counts Y from the PRISM generative model with modified d.

    Used by contaminated_controls and continuous_latent scenarios.
    """
    dev = data.device
    X_cpu = data.X.cpu()
    Z_cpu = data.Z.cpu()
    beta_true = gt["beta_true"].cpu()
    theta_true = gt["theta_true"].cpu()
    omega_true = gt["omega_true"].cpu()
    log_pi = data.log_pi.cpu()
    subject_idx = data.subject_idx.cpu()

    N = data.n_cells
    P = data.n_genes
    phi_val = kw.get("phi", 10.0)

    # Recompute eta with new d
    eta = X_cpu @ beta_true.T
    delta = Z_cpu @ theta_true.T
    eta = eta + d_new.unsqueeze(1) * delta
    eta = eta.clamp(-20, 20)

    # Fresh cell-level overdispersion
    phi_t = torch.tensor(phi_val).expand(N, P)
    nu = torch.distributions.Gamma(phi_t, phi_t).sample()
    nu = nu.clamp(min=1e-6)

    pi = log_pi.exp()
    omega_cell = omega_true[subject_idx]

    mu = pi.unsqueeze(1) * torch.exp(eta) * nu * omega_cell
    mu = mu.clamp(min=1e-6, max=1e8)
    Y_new = torch.poisson(mu).int()

    data_new = PrismData.from_tensors(
        Y=Y_new.to(dev), X=data.X, Z=data.Z, I=data.I,
        log_pi=data.log_pi, subject_idx=data.subject_idx,
        n_subjects=data.n_subjects,
        disease_subject_idx=data.disease_subject_idx,
        n_disease_subjects=data.n_disease_subjects,
    )

    gt["d_true"] = d_new.to(dev)
    return data_new, gt
