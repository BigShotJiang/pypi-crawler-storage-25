"""E-step: compute cell-level disease posteriors q_ij.

q_ij = P(d_ij = 1 | Y_ij, Theta) = sigmoid(log_prior_odds + multi-gene LLR)

Steps:
    1. Compute mu_d0, mu_d1 for all cells (vectorized over genes).
    2. Compute per-cell, per-gene NB log-pmf under both models.
    3. Sum log-likelihood ratio over genes -> per-cell logit.
    4. Add prior log-odds log(rho / (1 - rho)).
    5. Clamp logit to [-50, 50], apply sigmoid.
    6. Set q = 0 for control cells.
"""

from __future__ import annotations

import torch
from torch import Tensor

from ..data.dataset import PrismData
from ..model.nb_likelihood import nb_log_pmf, compute_omega_bar
from ..model.random_effects import gamma_params_from_sigma2
from ..utils.numerical import EPS, LOGIT_CLAMP, safe_log, safe_sigmoid


@torch.no_grad()
def e_step(
    data: PrismData,
    model,  # PrismModel
    gene_chunk_size: int | None = None,
    effective_mode: str | None = None,
) -> Tensor:
    """Compute q_ij = P(d_ij = 1 | Y_ij, params) for all cells.

    Parameters
    ----------
    data : PrismData
    model : PrismModel — holds beta, encoder, sigma2, phi, logit_rho, q.
    gene_chunk_size : optional int — if set, process genes in chunks to save
        memory.  For N=70K, P=15K, a chunk_size of 1000 is recommended.

    Returns
    -------
    q : (N,) — disease posteriors for every cell.
    """
    N, P = data.Y.shape
    device = data.device

    # Gamma RE params
    alpha, lam = model.alpha_lambda  # (P,), (P,)

    # Compute per-cell omega values:
    # HL mode → use exp(eta[s,g]) directly
    # LN mode → use posterior mean omega_bar
    mode = effective_mode or getattr(model, '_likelihood_mode', 'ln')
    use_hl = mode == 'hl'
    if use_hl:
        omega_bar = _compute_omega_from_eta(data, model)  # (N, P)
    else:
        omega_bar = _compute_omega_bar_all(data, model, alpha, lam)  # (N, P)

    phi = model.phi  # (P,)

    if gene_chunk_size is None or gene_chunk_size >= P:
        cell_llr = _compute_cell_llr(data, model, omega_bar, phi)
    else:
        # Chunked over genes to save memory
        cell_llr = torch.zeros(N, device=device)
        for g_start in range(0, P, gene_chunk_size):
            g_end = min(g_start + gene_chunk_size, P)
            cell_llr += _compute_cell_llr_chunk(
                data, model, omega_bar, phi, g_start, g_end
            )

    # Prior log-odds from rho
    rho = model.rho  # (m_disease,)
    rho_cell = rho[data.disease_subject_idx]  # (N,)
    log_prior_odds = safe_log(rho_cell) - safe_log(1.0 - rho_cell)

    # Combine and sigmoid
    logit_q = torch.clamp(log_prior_odds + cell_llr, -LOGIT_CLAMP, LOGIT_CLAMP)
    q = torch.sigmoid(logit_q)

    # Zero out control cells
    q = q * data.I.float()
    return q


def _compute_omega_bar_all(
    data: PrismData,
    model,
    alpha: Tensor,
    lam: Tensor,
) -> Tensor:
    """Compute omega_bar for every cell by broadcasting from per-subject values.

    Returns (N, P).
    """
    N, P = data.Y.shape
    omega_bar_per_subject = torch.ones(data.n_subjects, P, device=data.device)

    mu_star = model.compute_mu_star(data.X, data.log_pi, data.Z)  # (N, P)

    for s in range(data.n_subjects):
        mask = data.cells_for_subject(s)
        Y_s = data.Y[mask]          # (n_s, P)
        mu_s = mu_star[mask]        # (n_s, P)
        omega_bar_per_subject[s] = compute_omega_bar(Y_s, mu_s, alpha, lam)

    # Broadcast to cells
    return omega_bar_per_subject[data.subject_idx]  # (N, P)


def _compute_omega_from_eta(
    data: PrismData,
    model,
) -> Tensor:
    """Compute omega for every cell from explicit eta parameters (HL mode).

    omega_{ig} = exp(eta_{ig}), broadcast to cells.

    Returns (N, P).
    """
    import torch
    omega_per_subject = torch.exp(
        torch.clamp(model.eta.detach(), min=-20.0, max=20.0)
    )  # (S, P)
    return omega_per_subject[data.subject_idx]  # (N, P)


def _compute_cell_llr(
    data: PrismData,
    model,
    omega_bar: Tensor,
    phi: Tensor,
) -> Tensor:
    """Compute the multi-gene log-likelihood ratio for all cells, all genes at once.

    Returns (N,).
    """
    mu_d0, mu_d1 = model.compute_mu_d0_d1(
        data.X, data.Z, data.log_pi, omega_bar
    )
    Y_f = data.Y.float()
    llr = nb_log_pmf(Y_f, mu_d1, phi) - nb_log_pmf(Y_f, mu_d0, phi)
    return llr.sum(dim=1)  # (N,)


def _compute_cell_llr_chunk(
    data: PrismData,
    model,
    omega_bar: Tensor,
    phi: Tensor,
    g_start: int,
    g_end: int,
) -> Tensor:
    """Chunked version — process genes [g_start, g_end) only.

    Returns (N,) partial LLR.
    """
    Y_chunk = data.Y[:, g_start:g_end].float()
    phi_chunk = phi[g_start:g_end]
    beta0_chunk = model.beta0[g_start:g_end]   # (P_c, K)
    Gamma_chunk = model.Gamma[g_start:g_end]    # (P_c, K*K2)
    alpha_de_chunk = model.alpha_de[g_start:g_end]  # (P_c,)
    omega_chunk = omega_bar[:, g_start:g_end]

    X = data.X.to(beta0_chunk.dtype)
    Z = data.Z.to(beta0_chunk.dtype)

    # Contextualized baseline
    XZ = model._context_interaction(X, Z)  # (N, K*K2)
    eta_base = X @ beta0_chunk.T + XZ @ Gamma_chunk.T + data.log_pi.unsqueeze(1).to(beta0_chunk.dtype)
    log_omega = torch.log(omega_chunk.clamp(min=EPS))
    log_mu_d0 = eta_base + log_omega

    # Disease effect: alpha_de + theta^T z
    delta_chunk = alpha_de_chunk.unsqueeze(0)  # (1, P_c)
    if hasattr(model.encoder, 'theta'):
        theta_chunk = model.encoder.theta[g_start:g_end]
        if theta_chunk.ndim == 2:
            delta_chunk = delta_chunk + Z @ theta_chunk.T  # (N, P_c)
        else:
            delta_chunk = delta_chunk + theta_chunk.unsqueeze(0)  # (1, P_c)
    else:
        delta_full = model.compute_delta(Z)
        delta_chunk = delta_full[:, g_start:g_end]

    log_mu_d1 = log_mu_d0 + delta_chunk

    from ..utils.numerical import clamp_exp
    mu_d0 = clamp_exp(log_mu_d0)
    mu_d1 = clamp_exp(log_mu_d1)

    llr = nb_log_pmf(Y_chunk, mu_d1, phi_chunk) - nb_log_pmf(Y_chunk, mu_d0, phi_chunk)
    return llr.sum(dim=1)
