"""Score test for the neural/nonlinear encoder.

The score test evaluates H0: theta = 0 (linear encoder has no effect)
without fitting the alternative model.  This is useful for:
  - Quickly screening which genes benefit from context-dependent DE.
  - Comparing linear vs. nonlinear encoders.

Score statistic:
    S_g = U_g^T * I_g^{-1} * U_g
where
    U_g = d ell / d theta_g | theta=0  (score at the null)
    I_g = -E[d^2 ell / d theta_g^2 | theta=0]  (expected information at null)

Under H0, S_g ~ chi^2(K2).
"""

from __future__ import annotations

import torch
from torch import Tensor

from ..data.dataset import PrismData
from ..model.nb_likelihood import nb_log_pmf, compute_omega_bar
from ..model.random_effects import gamma_params_from_sigma2
from ..utils.numerical import EPS, clamp_exp, safe_log


def score_test(
    data: PrismData,
    model,  # PrismModel — fitted under H0 (encoder=none or theta=0)
) -> tuple[Tensor, Tensor]:
    """Compute score test statistics for each gene.

    The model should have been fitted under H0 (theta = 0, or encoder = "none").

    Parameters
    ----------
    data : PrismData
    model : PrismModel with converged null parameters.

    Returns
    -------
    score_stat : (P,) — score test statistics.
    p_values : (P,) — p-values from chi2(K2).
    """
    P = data.n_genes
    K2 = data.n_context
    device = data.device

    alpha, lam = model.alpha_lambda
    phi = model.phi

    # Score: d ell / d theta_g | theta=0
    # Under theta=0, mu_d1 = mu_d0, so the score is:
    #   U_g = sum_i sum_j q_ij * Z_j * (Y_ij - mu_d0_ij) / (1 + mu_d0_ij / phi_g)
    # This is the "working residual" weighted by q and Z.

    mu_star = model.compute_mu_star(data.X, data.log_pi, data.Z)  # (N, P)

    # Working residuals: (Y - mu) / (1 + mu/phi)
    Y_f = data.Y.float()
    var_factor = 1.0 + mu_star / phi.unsqueeze(0)  # (N, P)
    residuals = (Y_f - mu_star) / var_factor.clamp(min=EPS)  # (N, P)

    # Weighted by q
    q = model.q  # (N,)
    weighted_resid = q.unsqueeze(1) * residuals  # (N, P)

    # Score: sum_j q_ij * Z_j * resid_ij
    # U_g has shape (K2,) for each gene g
    # U = Z^T @ weighted_resid -> (K2, P)
    U = data.Z.T @ weighted_resid  # (K2, P)

    # Information matrix (diagonal approx):
    # I_g = sum_j q_ij * (Z_j^T Z_j) * mu_ij / var_factor
    # For diagonal: I_g ≈ diag(Z^T diag(w) Z) where w_j = q_j * mu_j / var_j
    weights = q.unsqueeze(1) * mu_star / var_factor.clamp(min=EPS)  # (N, P)

    # For each gene, I_g = Z^T diag(w_g) Z -> (K2, K2)
    # Score stat = U_g^T I_g^{-1} U_g
    # For efficiency, compute gene-by-gene only if K2 is small
    score_stats = torch.zeros(P, device=device)

    if K2 <= 10:
        for g in range(P):
            w_g = weights[:, g]  # (N,)
            # I_g = Z^T diag(w_g) Z
            Zw = data.Z * w_g.unsqueeze(1).sqrt()  # (N, K2)
            I_g = Zw.T @ Zw  # (K2, K2)
            I_g = I_g + torch.eye(K2, device=device) * EPS  # regularize

            U_g = U[:, g]  # (K2,)
            # S_g = U^T I^{-1} U
            try:
                I_inv_U = torch.linalg.solve(I_g, U_g)
                score_stats[g] = U_g @ I_inv_U
            except torch.linalg.LinAlgError:
                score_stats[g] = 0.0
    else:
        # Diagonal approximation for large K2
        I_diag = (data.Z ** 2).T @ weights  # (K2, P)
        I_diag = I_diag.clamp(min=EPS)
        score_stats = (U ** 2 / I_diag).sum(dim=0)  # (P,)

    score_stats = score_stats.clamp(min=0.0)

    # p-values from chi2(K2)
    p_values = _chi2_sf(score_stats, df=K2)

    return score_stats, p_values


def _chi2_sf(x: Tensor, df: int) -> Tensor:
    """Survival function (1 - CDF) of chi-squared distribution."""
    import scipy.stats as st
    import numpy as np
    x_np = x.detach().cpu().numpy()
    sf_np = st.chi2.sf(x_np, df)
    return torch.tensor(sf_np, device=x.device, dtype=x.dtype)
