"""EM outer loop with convergence monitoring and W&B logging.

The PRISM EM algorithm alternates:
    E-step: compute q_ij = P(d_ij=1 | Y, Theta)
    M-step: optimize (beta, theta, sigma2, phi) given q
    rho update: rho_i = mean(q_ij) over cells of disease subject i

Convergence: relative change in observed log-likelihood < tol.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import torch
from torch import Tensor

import yaml

from ..data.dataset import PrismData
from ..model.prism_model import PrismModel, PrismParams
from ..model.nb_likelihood import nb_log_pmf
from ..model.random_effects import gamma_params_from_sigma2
from ..inference.e_step import e_step
from ..inference.m_step import run_m_step, m_step_objective, m_step_objective_hl
from ..utils.numerical import EPS, safe_log, safe_sigmoid
from ..utils.logging import WandbLogger


@dataclass
class PRISMConfig:
    """Configuration for the PRISM EM trainer."""

    # Model
    n_genes: int = 60
    n_covars: int = 3
    n_context: int = 1
    encoder_type: str = "linear"
    d_hidden: int = 64
    n_layers: int = 1

    # EM loop
    max_em_iter: int = 50
    em_tol: float = 1e-6
    min_em_iter: int = 3
    fix_q: bool = False  # If True, fix q = I (disease arm) and skip E-step entirely
    fix_q_warmup: int = 0  # If > 0, fix q = I for the first N EM iterations (warmup)

    # M-step
    m_step_optimizer: str = "adam"
    m_step_max_iter: int = 80
    m_step_grad_tol: float = 1e-6
    m_step_trust_radius: float = 1.0
    m_step_lr: float = 0.01

    # Likelihood mode
    likelihood_mode: str = "hl"           # "ln" | "hl" | "auto"
    sigma2_hl_threshold: float = 0.5     # threshold for auto mode (He et al. 2021)

    # E-step
    gene_chunk_size: Optional[int] = None

    # ── E-step damping ─────────────────────────────────────────────────
    # Blend each E-step update toward the previous q:
    #   q_new = (1 - e_step_damping) * q_exact + e_step_damping * q_old
    # Prevents the catastrophic LL drops caused by aggressive q jumps
    # (observed in ROSMAP microglia iter 3: LL drops 6 M nats, never
    # recovers).  0.0 = no damping (legacy); 0.3–0.5 recommended.
    e_step_damping: float = 0.0

    # Wald test
    run_wald: bool = True
    use_louis_correction: bool = False
    hessian_se_alpha_de: bool = True    # closed-form Hessian SE (default; OPG is overly conservative)
    hessian_se_theta: bool = True       # closed-form Hessian SE for theta (context params)
    fdr_threshold: float = 0.05

    # Post-EM theta sparsification (spike-and-slab two-stage estimator)
    # After EM convergence, genes with non-significant theta (p_theta > threshold)
    # are zeroed and alpha_de is refined to absorb the signal back.
    sparsify_theta: bool = False
    sparsify_threshold: float = 0.10   # p-value threshold; genes above → zeroed
    sparsify_refine_iters: int = 5     # M-step iterations for alpha_de recovery

    # Rho (phenotype prevalence) prior — Beta(rho_prior_a, rho_prior_b) MAP.
    # Default a=b=1 → uniform → MLE mean(q_ij), identical to previous behaviour.
    # Setting a > b biases rho toward 1, counteracting the self-reinforcing
    # shrinkage loop where low rho → low q → lower rho across EM iterations.
    # Recommended: rho_prior_a=9.0, rho_prior_b=1.0  (Beta(9,1), E[rho]=0.9).
    rho_prior_a: float = 1.0
    rho_prior_b: float = 1.0

    # ── Fix 1: Pseudobulk warm-start for alpha_de ──────────────────────────
    # Before EM, initialise alpha_de_g from the subject-level log-fold-change
    # (disease pseudobulk vs control pseudobulk).  Breaks the (rho, alpha_de)
    # cold-start deadlock at low n.  Default False for backward compatibility.
    alpha_de_warmstart: bool = False

    # ── Fix 2: L2 (Gaussian) prior on alpha_de ─────────────────────────────
    # Adds −(alpha_de_l2 / 2) * ||alpha_de||^2 to the M-step objective,
    # preventing alpha_de from collapsing to zero when q is uncertain early in
    # EM.  Equivalent to a N(0, 1/alpha_de_l2) MAP prior.  0 = off (MLE).
    alpha_de_l2: float = 0.0

    # ── Fix 3: Subject-level pseudobulk test for alpha_de ──────────────────
    # After EM, run a Welch t-test on library-size-normalised pseudobulk means
    # (disease subjects vs control subjects), then combine with the cell-level
    # alpha_de Wald p-value via Bonferroni min-p.  Gains subject-level power
    # for constant-effect genes without requiring accurate q convergence.
    # Default False for backward compatibility.
    pseudobulk_alpha_de_test: bool = True

    # ── Fix 5: Clustered score test for alpha_de ───────────────────────────
    # After EM, compute per-subject q-weighted gradient contributions to
    # alpha_de (the "score" for alpha_de at the MLE), then run a two-sample
    # Welch t-test (disease subjects vs control subjects) on these scores.
    # Uses q from EM (unlike the raw pseudobulk test) while properly
    # accounting for subject-level clustering (unlike the cell-level Wald).
    # Effectively a subject-level test with n_disease-1 d.f., but informed
    # by q.  Combined with cell-level Wald p-value via Fisher's method (or
    # Bonferroni if fisher_combine = False).
    # Default: False. The pseudobulk Welch test alone with Fisher
    # combination (PRISM-PB-FISHER) is the default configuration.
    clustered_score_test: bool = False

    # When True AND clustered_score_test is enabled, the clustered score-test
    # p-value REPLACES the cell-level Wald p-value as the "cell" input to
    # Fisher/Brown combination. Required for PRISM (soft EM q) because the
    # cell-level Wald on alpha_de is unreliable under q shrinkage: α̂ is pulled
    # toward 0 on null genes faster than SE shrinks, so the test is severely
    # under-powered while still over-rejecting when q is miscalibrated. The
    # score test at H0: α=0 uses residuals against μ_d0, immune to shrinkage.
    # Leave False for PRISM-C (fixed q=I) where Wald is well-behaved.
    score_test_replaces_wald: bool = False

    # ── Fisher combination flag ────────────────────────────────────────────
    # When True, combine the cell-level Wald p-value with the subject-level
    # test p-value via Fisher's statistic F = -2(log p1 + log p2); else use
    # Bonferroni min-p. Default reference distribution is Brown-corrected
    # χ²_{fisher_brown_df} (see `fisher_brown_df` below), which calibrates F
    # for data-sharing component tests.
    fisher_combine: bool = True

    # Brown correction for Fisher combination.  Three modes:
    #   - float (e.g. 8.37): fixed Brown df from a pooled null simulation.
    #     Conservative when the actual test-statistic correlation is below
    #     the pooled value (esp. at small m).
    #   - "adaptive": per-run k̂ estimated from the empirical -2 log p
    #     correlation among null-like genes (Kost-McDermott style moment
    #     match).  Recommended default: recovers power without loss of
    #     calibration.
    #   - None: uncorrected χ²_{2K} reference (mis-calibrated when component
    #     tests share data).
    fisher_brown_df: Optional[float | str] = "adaptive"

    # ── Fix 4: Label-anchored E-step ───────────────────────────────────────
    # After each E-step, blend q_ij with the hard disease label d_i:
    #   q_ij = (1 - w) * q_ij_EM  +  w * anchor_target
    #   w = exp(-n_disease / label_anchor_tau)
    # label_anchor_tau = 0.0  → disabled (default).
    # label_anchor_iters = 0  → apply every iter (default when tau > 0);
    #                  N > 0  → apply only for em_iter < N (warm-start mode).
    # label_anchor_to_rho     → anchor toward rho_i (prior mean) instead of 1.0;
    #                           more conservative, anchors null genes to ~rho not ~1.
    label_anchor_tau: float = 0.0
    label_anchor_iters: int = 0     # 0 = unlimited; N = first N iters only
    label_anchor_to_rho: bool = False

    # ── Rho lower bound ─────────────────────────────────────────────────
    # Clamp the MAP rho estimate from below during _update_rho.
    # rho_min_clamp = 0.01 (default) = current behavior (no real lower bound).
    # Setting to e.g. 0.3 prevents self-reinforcing rho-collapse at low n without
    # the ongoing E-step bias that label_anchor introduces.  Biologically motivated:
    # a known diseased subject should have at least ~rho_min of cells showing the
    # disease phenotype.
    rho_min_clamp: float = 0.01

    # Logging
    wandb_enabled: bool = True
    wandb_project: str = "prism"
    run_name: Optional[str] = None
    verbose: bool = True

    # Device
    device: str = "cuda"
    dtype: str = "float32"

    @classmethod
    def from_yaml(cls, path: str | Path) -> "PRISMConfig":
        with open(path) as f:
            d = yaml.safe_load(f)
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    @property
    def torch_dtype(self) -> torch.dtype:
        return getattr(torch, self.dtype)


@dataclass
class PRISMResults:
    """Results from a PRISM run."""

    # Per-gene statistics
    beta0_hat: Tensor         # (P, K) — fixed baseline covariate effects
    Gamma_hat: Tensor         # (P, K*K2) — contextualized covariate modulation
    alpha_de_hat: Tensor      # (P,) — constant disease effect
    theta_hat: Tensor         # (P, K2) or (P,) for constant encoder
    sigma2_hat: Tensor        # (P,)
    phi_hat: Tensor           # (P,)
    rho_hat: Tensor           # (m_disease,)
    q_hat: Tensor             # (N,)

    # Wald test results — theta (context-specific DE modulation)
    wald_stat: Optional[Tensor] = None      # (P,) or (P, K2)
    p_values: Optional[Tensor] = None       # (P,) or (P, K2)
    se: Optional[Tensor] = None             # (P,) or (P, K2) standard errors
    q_values: Optional[Tensor] = None       # (P,) BH-adjusted, H0: theta=0

    # Wald test results — alpha_de (constant disease effect, H0: alpha_de=0)
    # `p_values_de` is the *combined* p (Fisher-Brown or Bonferroni) when a
    # subject-level test is also run; the raw components are retained below
    # so users can recompute under a different combination rule post-hoc.
    p_values_de: Optional[Tensor] = None            # (P,) combined p
    q_values_de: Optional[Tensor] = None            # (P,) BH-adjusted
    p_values_de_cell: Optional[Tensor] = None       # (P,) cell-level Wald only
    p_values_de_subject: Optional[Tensor] = None    # (P,) pseudobulk / clustered score

    # Diagnostic: subject-level pseudobulk log-fold-change estimate.
    # Same natural-log units as `alpha_de_hat`, but *not* calibrated: conflates
    # within-subject pseudoreplication with between-subject variance.  Useful
    # as an interpretability / identifiability diagnostic — compare to
    # `alpha_de_hat` to see how much the subject random effect has absorbed.
    # NaN when <2 disease or <2 control subjects.
    alpha_de_pseudobulk: Optional[Tensor] = None         # (P,) pseudobulk log-FC
    alpha_de_pseudobulk_se: Optional[Tensor] = None      # (P,) Welch SE
    pvalue_alpha_de_pseudobulk: Optional[Tensor] = None  # (P,) two-sided Welch p

    # ----------------------------------------------------------------
    # Semantic test interface — three distinct scientific questions
    # ----------------------------------------------------------------
    # q_values_general : "Is gene g differentially expressed in general
    #                     (averaged over contexts)?"
    #   - ConstantEncoder / NoneEncoder: primary disease test (theta or alpha_de)
    #   - LinearEncoder / MLP: Wald test on alpha_de (constant component)
    #
    # q_values_context : "Does the DE effect of gene g vary significantly
    #                     by context?"  (None when no context encoder is used)
    #   - ConstantEncoder / NoneEncoder: None
    #   - LinearEncoder / MLP: Wald test on theta (context-specific modulation)
    #
    # q_values_any     : "Is there any disease signal for gene g at all?"
    #                    (omnibus / combined test)
    #   - ConstantEncoder / NoneEncoder: same as q_values_general
    #   - LinearEncoder / MLP: Bonferroni-corrected minimum of p_general and
    #     p_context, then BH correction across genes
    q_values_general: Optional[Tensor] = None   # (P,)
    q_values_context: Optional[Tensor] = None   # (P,) or None
    q_values_any:     Optional[Tensor] = None   # (P,)

    # Convergence diagnostics
    obs_loglik_trace: list[float] = field(default_factory=list)
    em_iterations: int = 0
    converged: bool = False

    def significant_genes(self, fdr: float = 0.05, test: str = "any") -> Tensor:
        """Return boolean mask of genes significant at given FDR.

        Parameters
        ----------
        fdr : FDR threshold (default 0.05).
        test : which test to use.  One of:

            ``"any"`` *(default)*
                Omnibus — a gene is called DE if **either** the constant
                disease-effect test *or* the context-modulation test is
                significant.  For ConstantEncoder / baseline methods this
                is identical to ``"general"``.  This is the recommended
                metric for overall DE gene recovery ($P_{\\mathrm{DE}}$).

            ``"general"``
                Constant (context-averaged) disease effect
                (``q_values_general``).  Tests $H_0: \\alpha_{\\mathrm{de},g}=0$
                for LinearEncoder; tests $H_0: \\theta_g=0$ for
                ConstantEncoder.

            ``"context"``
                Context-specific DE modulation
                (``q_values_context``).  Tests $H_0: \\theta_g=0$ for
                LinearEncoder.  **Not available for ConstantEncoder** — raises
                ``ValueError``.

            ``"theta"``
                Legacy alias for ``"context"``.
        """
        if test in ("theta", "context"):
            qv = self.q_values_context   # None for ConstantEncoder → caught below
        elif test == "any":
            qv = self.q_values_any
        else:  # "general"
            qv = self.q_values_general
        if qv is None:
            raise ValueError(
                f"Test '{test}' is not available for this model configuration "
                f"(q_values_context is None — method uses a ConstantEncoder)."
            )
        return qv < fdr

    def de_summary(self, fdr: float = 0.05, gene_names=None) -> "pd.DataFrame":
        """Return a tidy per-gene DataFrame with all test results and estimates.

        Columns
        -------
        gene :
            Gene index (0-based) or gene name if *gene_names* provided.
        alpha_de_hat :
            Estimated constant (context-averaged) log fold change.
        theta_hat :
            Context-modulation coefficient(s); one column per context
            dimension (``theta_0``, ``theta_1``, …).  ``None`` / NaN for
            ConstantEncoder models.
        q_general :
            BH-adjusted p-value for the constant disease-effect test
            ($P_{\\mathrm{gen}}$).
        q_context :
            BH-adjusted p-value for the context-specific modulation test
            ($P_{\\mathrm{ctx}}$).  ``NaN`` if not available.
        q_any :
            BH-adjusted p-value for the omnibus test ($P_{\\mathrm{DE}}$).
        sig_general, sig_context, sig_any :
            Boolean significance flags at *fdr*.

        Parameters
        ----------
        fdr :
            FDR threshold for the ``sig_*`` columns (default 0.05).
        gene_names :
            Optional list/array of gene names; length must match P.
        """
        import pandas as pd
        import numpy as np

        P = self.alpha_de_hat.shape[0]
        d: dict = {}

        d["gene"] = list(gene_names) if gene_names is not None else list(range(P))

        # Parameter estimates
        d["alpha_de_hat"] = self.alpha_de_hat.detach().cpu().numpy()

        if self.theta_hat is not None:
            theta_np = self.theta_hat.detach().cpu().numpy()
            if theta_np.ndim == 1:
                d["theta_0"] = theta_np
            else:
                for k in range(theta_np.shape[1]):
                    d[f"theta_{k}"] = theta_np[:, k]

        # q-values
        def _to_np(t):
            if t is None:
                return np.full(P, float("nan"))
            v = t.detach().cpu().numpy()
            return v.min(axis=-1) if v.ndim > 1 else v

        d["q_general"] = _to_np(self.q_values_general)
        d["q_context"] = _to_np(self.q_values_context)
        d["q_any"]     = _to_np(self.q_values_any)

        # Significance flags
        d["sig_general"] = d["q_general"] < fdr
        d["sig_context"] = d["q_context"] < fdr
        d["sig_any"]     = d["q_any"]     < fdr

        return pd.DataFrame(d)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to CPU numpy dict for saving."""
        d = {}
        for k in ["beta0_hat", "Gamma_hat", "alpha_de_hat", "theta_hat",
                   "sigma2_hat", "phi_hat", "rho_hat", "q_hat",
                   "wald_stat", "p_values", "se", "q_values",
                   "p_values_de", "q_values_de",
                   "q_values_general", "q_values_context", "q_values_any"]:
            v = getattr(self, k)
            if v is not None:
                d[k] = v.detach().cpu().numpy()
        d["obs_loglik_trace"] = self.obs_loglik_trace
        d["em_iterations"] = self.em_iterations
        d["converged"] = self.converged
        return d


class PRISMTrainer:
    """Full PRISM EM loop trainer."""

    def __init__(self, config: PRISMConfig):
        self.config = config
        self.model: Optional[PrismModel] = None
        self.logger: Optional[WandbLogger] = None

    @classmethod
    def from_config(cls, path: str | Path) -> "PRISMTrainer":
        return cls(PRISMConfig.from_yaml(path))

    # ------------------------------------------------------------------
    # Main fit
    # ------------------------------------------------------------------

    def fit(self, data: PrismData, init_callback=None) -> PRISMResults:
        """Run the full PRISM EM algorithm on *data*.

        Parameters
        ----------
        data : PrismData — all data on the target device.
        init_callback : optional callable(model) — called after model init,
            before EM iterations.  Useful for freezing parameters.

        Returns
        -------
        PRISMResults
        """
        cfg = self.config
        device = data.device

        # Build model
        self.model = PrismModel(
            n_genes=data.n_genes,
            n_covars=data.n_covars,
            n_context=data.n_context,
            n_disease_subjects=data.n_disease_subjects,
            n_cells=data.n_cells,
            n_subjects=data.n_subjects,
            encoder_type=cfg.encoder_type,
            d_hidden=cfg.d_hidden,
            n_layers=cfg.n_layers,
            likelihood_mode=cfg.likelihood_mode,
            device=str(device),
            dtype=cfg.torch_dtype,
        ).to(device)

        self.model.initialize_from_data(data, warmstart_alpha_de=cfg.alpha_de_warmstart)

        # Attach L2 penalty weight so m_step_objective can read it
        self.model.alpha_de_l2 = cfg.alpha_de_l2

        if cfg.fix_q:
            # Fixed-label mode: q is fixed to the disease arm indicator I throughout.
            # No E-step or rho update will be run.  q = I was already set by
            # initialize_from_data, but we re-copy to be explicit.
            self.model.q.copy_(data.I.float())

        if init_callback is not None:
            init_callback(self.model)

        # Logger
        self.logger = WandbLogger(
            project=cfg.wandb_project,
            config=vars(cfg),
            enabled=cfg.wandb_enabled,
            run_name=cfg.run_name,
            max_iter=cfg.max_em_iter,
            verbose=cfg.verbose,
        )

        # EM loop
        prev_ll = -float("inf")
        obs_loglik_trace: list[float] = []
        converged = False

        # Resolve likelihood mode
        lik_mode = cfg.likelihood_mode  # "ln", "hl", or "auto"

        # HL mode uses a two-phase approach (following He et al. 2021):
        #   Phase 1: LN warm-up to estimate sigma2/phi (these are frozen in HL)
        #   Phase 2: HL with fixed sigma2/phi, optimising beta/theta/eta
        hl_warmup_iters = cfg.min_em_iter if lik_mode in ("hl", "auto") else 0

        for em_iter in range(cfg.max_em_iter):
            t0 = time.time()

            # Determine effective mode for this iteration
            effective_mode = lik_mode
            if lik_mode == "hl":
                # Phase 1: LN warm-up for sigma2/phi estimation
                effective_mode = "ln" if em_iter < hl_warmup_iters else "hl"
            elif lik_mode == "auto":
                if em_iter < hl_warmup_iters:
                    effective_mode = "ln"
                else:
                    from ..model.hl_likelihood import sigma2_needs_hl
                    frac_hl = sigma2_needs_hl(
                        self.model.sigma2.detach(), cfg.sigma2_hl_threshold
                    ).float().mean().item()
                    # If >10% of genes need HL, use HL for all
                    effective_mode = "hl" if frac_hl > 0.10 else "ln"
                    if em_iter == hl_warmup_iters and cfg.verbose:
                        print(f"  [auto] {frac_hl*100:.1f}% genes σ²>{cfg.sigma2_hl_threshold} → mode={effective_mode}")

            if em_iter == hl_warmup_iters and lik_mode in ("hl", "auto") and cfg.verbose:
                if effective_mode == "hl":
                    s2_mean = self.model.sigma2.detach().mean().item()
                    print(f"  Switching to HL (σ² mean={s2_mean:.4f} from LN warm-up)")

            # --- M-step ---
            t_m = time.time()
            m_info = run_m_step(
                data, self.model,
                max_iter=cfg.m_step_max_iter,
                grad_tol=cfg.m_step_grad_tol,
                trust_radius=cfg.m_step_trust_radius,
                lr=cfg.m_step_lr,
                optimizer_type=cfg.m_step_optimizer,
                likelihood_mode=effective_mode,
            )
            m_step_time = time.time() - t_m

            # --- E-step (skipped in fixed-label mode or during warmup) ---
            _skip_estep = cfg.fix_q or (cfg.fix_q_warmup > 0 and em_iter < cfg.fix_q_warmup)
            if not _skip_estep:
                t_e = time.time()
                q_em = e_step(data, self.model, cfg.gene_chunk_size,
                              effective_mode=effective_mode)

                # ── E-step damping: blend toward previous q ────────────
                if cfg.e_step_damping > 0.0:
                    lam = cfg.e_step_damping
                    q_em = (1.0 - lam) * q_em + lam * self.model.q.detach()

                # Fix 4: blend q toward anchor target at low n
                _apply_anchor = (
                    cfg.label_anchor_tau > 0.0
                    and (
                        cfg.label_anchor_iters == 0
                        or em_iter < cfg.label_anchor_iters
                    )
                )
                if _apply_anchor:
                    import math as _math
                    n_disease = float(data.n_disease_subjects)
                    w = _math.exp(-n_disease / cfg.label_anchor_tau)
                    if cfg.label_anchor_to_rho:
                        # Anchor toward prior mean  rho_i * I  (not hard 1.0)
                        # .detach() is essential: rho is sigmoid(logit_rho) which
                        # is part of the M-step graph; leaving it attached would
                        # cause "backward through graph twice" errors.
                        rho_cell = self.model.rho[data.disease_subject_idx].detach()
                        anchor_target = rho_cell * data.I.float()
                    else:
                        anchor_target = data.I.float()
                    q_em = (1.0 - w) * q_em + w * anchor_target
                # Always detach before copying: q is a buffer used in the M-step
                # objective; any grad_fn attached here would corrupt autograd.
                self.model.q.copy_(q_em.detach())
                e_step_time = time.time() - t_e
                # --- Update rho ---
                self._update_rho(data, cfg)
            else:
                e_step_time = 0.0

            # --- Observed log-likelihood ---
            obs_ll = self._observed_loglik(data, effective_mode).item()
            obs_loglik_trace.append(obs_ll)

            # --- Logging ---
            metrics = {
                "em_iter": em_iter,
                "obs_loglik": obs_ll,
                "delta_ll": obs_ll - prev_ll if prev_ll > -float("inf") else 0.0,
                "m_step_loss": m_info["loss"],
                "m_step_grad_norm": m_info["grad_norm"],
                "m_step_n_iter": m_info["n_iter"],
                "m_step_time": m_step_time,
                "e_step_time": e_step_time,
                "mean_q_disease": self.model.q[data.I].mean().item() if data.I.any() else 0.0,
                "mean_rho": self.model.rho.mean().item(),
                "iter_time": time.time() - t0,
                "likelihood_mode": effective_mode,
            }
            self.logger.log(metrics, step=em_iter)

            # --- Convergence ---
            # Normalize by number of observations (N*P) so the criterion
            # is independent of dataset size.  Without this, the relative
            # change |Δll|/|ll| ~ O(1/√(NP)) shrinks with N and P,
            # causing premature convergence on large datasets.
            n_obs = data.n_cells * data.n_genes
            delta_per_obs = abs(obs_ll - prev_ll) / max(n_obs, 1)
            # In fixed-label mode there is no E-step oscillation, so we can
            # check convergence from the first iteration onward.
            min_iter_gate = 1 if cfg.fix_q else cfg.min_em_iter
            if em_iter >= min_iter_gate and delta_per_obs < cfg.em_tol:
                converged = True
                break
            prev_ll = obs_ll

        # --- Post-EM: theta sparsification (two-stage debiased estimator) ---
        if cfg.sparsify_theta and hasattr(self.model.encoder, "theta"):
            from .wald_test import wald_test as _wt
            _, _p_theta_pre, _ = _wt(
                data, self.model,
                use_louis_correction=False,
                likelihood_mode=effective_mode,
            )
            _p_1d = (
                _p_theta_pre.min(dim=-1).values
                if _p_theta_pre.dim() > 1
                else _p_theta_pre
            ).cpu()
            _freeze = _p_1d > cfg.sparsify_threshold
            if _freeze.any():
                self.model.encoder.theta.data[_freeze] = 0.0
                # Gradient hook: keep frozen genes at zero during refinement
                def _make_hook(mask):
                    def _h(g):
                        c = g.clone(); c[mask] = 0.0; return c
                    return _h
                _hh = self.model.encoder.theta.register_hook(_make_hook(_freeze))
                for _ in range(cfg.sparsify_refine_iters):
                    run_m_step(
                        data, self.model,
                        max_iter=cfg.m_step_max_iter,
                        grad_tol=cfg.m_step_grad_tol,
                        trust_radius=cfg.m_step_trust_radius,
                        lr=cfg.m_step_lr,
                        optimizer_type=cfg.m_step_optimizer,
                        likelihood_mode=effective_mode,
                    )
                _hh.remove()
                self.model.encoder.theta.data[_freeze] = 0.0

        # --- Post-EM: Wald test ---
        wald_stat, p_values, se, q_values = None, None, None, None
        p_values_de, q_values_de = None, None
        p_values_de_cell, p_values_de_subject = None, None
        q_values_general = q_values_context = q_values_any = None
        alpha_de_pseudobulk = None
        alpha_de_pseudobulk_se = None
        pvalue_alpha_de_pseudobulk = None

        if cfg.run_wald:
            import sys as _sys
            _se_method = "Hessian" if cfg.hessian_se_alpha_de else "OPG"
            _se_method_theta = "Hessian" if cfg.hessian_se_theta else "OPG"
            print(f"\n[PRISM] EM converged ({em_iter} iters). Running Wald test "
                  f"(alpha_de: {_se_method}, theta: {_se_method_theta}, n_subjects={data.n_subjects})...",
                  flush=True)
            _sys.stderr.flush()
            from .wald_test import wald_test
            from ..model.encoders import ConstantEncoder, NoneEncoder

            # theta test: H0: theta_g = 0 (context-specific DE modulation)
            wald_stat, p_values, se = wald_test(
                data, self.model,
                use_louis_correction=cfg.use_louis_correction,
                likelihood_mode=effective_mode,
                hessian_se=cfg.hessian_se_theta,
            )
            q_values = _bh_correction(p_values)

            # alpha_de test: H0: alpha_de_g = 0 (constant disease effect)
            _, p_values_de, _ = wald_test(
                data, self.model,
                param_name="alpha_de",
                use_louis_correction=cfg.use_louis_correction,
                likelihood_mode=effective_mode,
                hessian_se=cfg.hessian_se_alpha_de,
            )

            # Combine cell-level alpha_de p-value with subject-level tests
            # (pseudobulk Welch; optionally clustered score). Default uses
            # Fisher's F = -2 Σ log p_k referenced to Brown-corrected
            # χ²_{fisher_brown_df}; Bonferroni min-p is the fallback.
            subject_p = None
            alpha_de_pseudobulk = None
            alpha_de_pseudobulk_se = None
            pvalue_alpha_de_pseudobulk = None
            if cfg.pseudobulk_alpha_de_test:
                from .wald_test import pseudobulk_alpha_de_test
                _, p_pb, log_fc_pb, se_pb = pseudobulk_alpha_de_test(data, self.model)
                subject_p = p_pb
                alpha_de_pseudobulk = log_fc_pb
                alpha_de_pseudobulk_se = se_pb
                pvalue_alpha_de_pseudobulk = p_pb
            if cfg.clustered_score_test:
                from .wald_test import clustered_score_test_alpha_de
                _, p_cs = clustered_score_test_alpha_de(data, self.model)
                if cfg.score_test_replaces_wald:
                    # Score test supersedes the shrinkage-biased Wald on α_de.
                    # Use p_cs as the cell-level component and keep pseudobulk
                    # as the subject-level component for Brown combination.
                    p_values_de = p_cs
                else:
                    # Take the more powerful of the two subject-level p-values
                    subject_p = p_cs if subject_p is None else torch.minimum(subject_p, p_cs) * 2

            p_values_de_cell = p_values_de.clone()
            p_values_de_subject = subject_p.clone() if subject_p is not None else None

            if subject_p is not None:
                if cfg.fisher_combine:
                    from .wald_test import fisher_combine_pvalues
                    p_values_de = fisher_combine_pvalues(
                        p_values_de, subject_p, df=cfg.fisher_brown_df,
                    )
                else:
                    p_values_de = (torch.minimum(p_values_de, subject_p) * 2).clamp(max=1.0)

            q_values_de = _bh_correction(p_values_de)

            # --------------------------------------------------------
            # Populate semantic test fields based on encoder type
            # --------------------------------------------------------
            if isinstance(self.model.encoder, ConstantEncoder):
                # theta_g IS the (constant) disease effect; alpha_de frozen at 0.
                # The theta Wald test is the only meaningful test.
                # Fix: mirror q_values -> q_values_de so downstream code that
                # reads q_values_de for "general DE" gets the correct answer.
                p_values_de = p_values.clone()
                q_values_de = q_values.clone()
                q_values_general = q_values          # theta test = general DE
                q_values_context = None              # no context modulation
                q_values_any     = q_values          # only one test

            elif isinstance(self.model.encoder, NoneEncoder):
                # alpha_de IS the (constant) disease effect; theta always zero.
                # The alpha_de Wald test is the only meaningful test.
                # Fix: mirror q_values_de -> q_values for backward compat.
                p_values = p_values_de.clone()
                q_values = q_values_de.clone()
                q_values_general = q_values_de       # alpha_de test = general DE
                q_values_context = None              # no context modulation
                q_values_any     = q_values_de       # only one test

            else:
                # LinearEncoder / MLP: both alpha_de and theta are meaningful.
                q_values_general = q_values_de       # constant component
                q_values_context = q_values          # context-specific modulation
                # Omnibus: gene is DE if EITHER the constant OR the context-
                # specific component is nonzero.
                # Bonferroni min-p: conservative but valid under arbitrary dependence.
                p_theta_1d = (
                    p_values.min(dim=-1).values
                    if p_values.dim() > 1
                    else p_values
                )
                p_any = (torch.minimum(p_theta_1d, p_values_de) * 2).clamp(max=1.0)
                q_values_any = _bh_correction(p_any)

        # Collect theta
        if hasattr(self.model.encoder, "theta"):
            theta_hat = self.model.encoder.theta.detach()
        else:
            theta_hat = torch.zeros(data.n_genes, data.n_context, device=device)

        results = PRISMResults(
            beta0_hat=self.model.beta0.detach(),
            Gamma_hat=self.model.Gamma.detach(),
            alpha_de_hat=self.model.alpha_de.detach(),
            theta_hat=theta_hat,
            sigma2_hat=self.model.sigma2.detach(),
            phi_hat=self.model.phi.detach(),
            rho_hat=self.model.rho.detach(),
            q_hat=self.model.q.detach(),
            wald_stat=wald_stat,
            p_values=p_values,
            se=se,
            q_values=q_values,
            p_values_de=p_values_de,
            q_values_de=q_values_de,
            p_values_de_cell=p_values_de_cell if cfg.run_wald else None,
            p_values_de_subject=p_values_de_subject if cfg.run_wald else None,
            alpha_de_pseudobulk=alpha_de_pseudobulk,
            alpha_de_pseudobulk_se=alpha_de_pseudobulk_se,
            pvalue_alpha_de_pseudobulk=pvalue_alpha_de_pseudobulk,
            q_values_general=q_values_general,
            q_values_context=q_values_context,
            q_values_any=q_values_any,
            obs_loglik_trace=obs_loglik_trace,
            em_iterations=em_iter + 1,
            converged=converged,
        )

        n_sig = (
            int(results.significant_genes(0.05, test="general").sum())
            if q_values_general is not None
            else -1
        )
        self.logger.log_summary({
            "final_obs_loglik": obs_loglik_trace[-1],
            "em_iterations": results.em_iterations,
            "converged": converged,
            "n_significant_fdr05": n_sig,
        })
        self.logger.finish()

        return results

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _update_rho(self, data: PrismData, cfg: "PRISMConfig") -> None:
        """MAP update for rho_i using a Beta(rho_prior_a, rho_prior_b) prior.

        With a=b=1 (default), reduces to the MLE: rho_i = mean(q_ij).
        With a > b (e.g. a=9, b=1), biases rho toward 1, counteracting the
        self-reinforcing shrinkage loop in low-prevalence settings.

        MAP formula:  rho_map = (sum_q + a - 1) / (n + a + b - 2)
        """
        a = cfg.rho_prior_a
        b = cfg.rho_prior_b
        use_map = not (a == 1.0 and b == 1.0)
        with torch.no_grad():
            for s_local in range(data.n_disease_subjects):
                mask = data.disease_subject_idx == s_local
                mask = mask & data.I  # only disease cells
                if mask.sum() > 0:
                    q_sub = self.model.q[mask]
                    if use_map:
                        sum_q = q_sub.sum()
                        n = float(mask.sum())
                        rho_val = (sum_q + a - 1.0) / (n + a + b - 2.0)
                    else:
                        rho_val = q_sub.mean()
                    rho_clamped = rho_val.clamp(cfg.rho_min_clamp, 0.99)
                    self.model.logit_rho.data[s_local] = torch.log(
                        rho_clamped / (1.0 - rho_clamped)
                    )

    def _observed_loglik(self, data: PrismData, effective_mode: str = "ln") -> Tensor:
        """Compute observed-data log-likelihood (approximate via LN or HL).

        For each cell:
            p(Y_ij | Theta) = q_ij * NB(Y; mu_d1, phi) + (1-q_ij) * NB(Y; mu_d0, phi)

        We approximate this using the current q and the selected likelihood.
        """
        if effective_mode == "hl":
            return -m_step_objective_hl(data, self.model)
        return -m_step_objective(data, self.model)


def _bh_correction(p_values: Tensor) -> Tensor:
    """Benjamini-Hochberg FDR correction.

    Works on tensors of any shape by flattening, applying BH, then
    reshaping back.

    Parameters
    ----------
    p_values : (...,) raw p-values (any shape).

    Returns
    -------
    q_values : same shape as p_values — BH-adjusted p-values.
    """
    original_shape = p_values.shape
    flat = p_values.reshape(-1)
    P = flat.numel()

    sorted_idx = torch.argsort(flat)
    sorted_p = flat[sorted_idx]
    ranks = torch.arange(1, P + 1, device=flat.device, dtype=flat.dtype)

    q_sorted = sorted_p * P / ranks
    # Enforce monotonicity (backward cumulative min)
    q_sorted = torch.flip(torch.cummin(torch.flip(q_sorted, [0]), dim=0).values, [0])
    q_sorted = q_sorted.clamp(max=1.0)

    # Un-sort and restore original shape
    q_flat = torch.empty_like(flat)
    q_flat[sorted_idx] = q_sorted
    return q_flat.reshape(original_shape)
