"""Wald test and Louis-formula standard errors for PRISM.

After EM convergence, we test H0: theta_g = 0 (no context-dependent DE)
using a Wald statistic:
    W_g = theta_hat_g^T * [Var(theta_hat_g)]^{-1} * theta_hat_g

The variance is computed via the Louis formula:
    I_obs = I_comp - I_miss
where:
    I_comp = -E[d^2 ell / d theta^2 | Y, q]   (complete-data information)
    I_miss = Var[d ell / d theta | Y, q]        (missing-data information)

Supported param_name values:
    "theta"    — context-dependent disease effect θ_g  (P, K2)
    "alpha_de" — constant disease effect α_g            (P,)
    "beta0"    — fixed baseline covariate effect β_g^0  (P, K)
    "Gamma"    — contextualized covariate modulation Γ_g (P, K*K2)
"""

from __future__ import annotations

from typing import Optional

import torch
from torch import Tensor

from ..data.dataset import PrismData
from ..utils.numerical import EPS, clamp_exp, safe_log


def wald_test(
    data: PrismData,
    model,  # PrismModel
    param_name: str = "theta",
    use_louis_correction: bool = False,
    likelihood_mode: str = "ln",
    hessian_se: bool = False,
) -> tuple[Tensor, Tensor, Tensor]:
    """Compute Wald statistics for testing a parameter = 0.

    Parameters
    ----------
    data : PrismData
    model : PrismModel (with converged parameters)
    param_name : "theta" | "alpha_de" | "beta0" | "Gamma"
    likelihood_mode : "ln" or "hl" — which objective to use for I_comp.
    hessian_se : bool — if True and param_name in {"alpha_de", "theta"}, use
        closed-form diagonal Hessian instead of OPG for I_comp.

    Returns
    -------
    wald_stat, p_values, se — all same shape as the target parameter.
    """
    if param_name == "theta" and hasattr(model.encoder, "theta"):
        theta = model.encoder.theta.detach()
    elif param_name == "alpha_de":
        theta = model.alpha_de.detach()
    elif param_name == "beta0":
        theta = model.beta0.detach()
    elif param_name == "Gamma":
        theta = model.Gamma.detach()
    else:
        P = model.n_genes
        K2 = data.n_context
        return (
            torch.zeros(P, K2, device=data.device),
            torch.ones(P, K2, device=data.device),
            torch.ones(P, K2, device=data.device) * float("inf"),
        )

    # Compute observed information matrix (diagonal approx)
    se = louis_formula_se(data, model, param_name,
                          use_louis_correction=use_louis_correction,
                          likelihood_mode=likelihood_mode,
                          hessian_se=hessian_se)

    # Wald statistic
    wald_stat = (theta / se.clamp(min=EPS)) ** 2

    # p-values from chi2(1)
    p_values = 1.0 - _chi2_cdf(wald_stat, df=1)

    return wald_stat, p_values, se


def louis_formula_se(
    data: PrismData,
    model,
    param_name: str = "theta",
    use_louis_correction: bool = False,
    likelihood_mode: str = "ln",
    hessian_se: bool = False,
) -> Tensor:
    """Compute standard errors via the Louis formula.

    The observed information under EM is:
        I_obs = I_comp − I_miss

    where I_comp = −∂²Q/∂θ² is the complete-data information evaluated at
    the converged Q-function, and I_miss captures the information lost due
    to the missing data (latent d_ij).

    When ``use_louis_correction=False`` (default, backward-compatible):
        SE = 1 / √(diag(I_comp))

    When ``use_louis_correction=True``:
        SE = 1 / √(diag(I_comp − I_miss))

    I_comp is computed via the diagonal Hessian of −Q using the same
    objective that was used for optimization (LN or HL).
    I_miss is computed analytically from the same Q-function scores.

    When ``hessian_se=True`` and ``param_name='alpha_de'``, the complete-data
    information is computed via the **exact diagonal Hessian** rather than the
    OPG estimator.  For alpha_de (one scalar per gene) the NB second
    derivative is available in closed form:

        I_comp[g] = Σ_j q_j · (y_{jg} + φ_g) · μ_{jg} · φ_g / (μ_{jg} + φ_g)²

    This avoids the OPG bias in clustered data where subjects have wildly
    different cell counts (the OPG squares per-subject sums, giving
    disproportionate weight to subjects with many cells).

    Parameters
    ----------
    use_louis_correction : bool
        If True, subtract I_miss to get the corrected observed information.
    likelihood_mode : str
        "ln" or "hl" — which M-step objective to use for I_comp.
    hessian_se : bool
        If True and param_name in {"alpha_de", "theta"}, use exact diagonal
        Hessian instead of the OPG for I_comp.

    Returns
    -------
    se : same shape as the target parameter — estimated standard errors.
    """
    if param_name == "theta" and hasattr(model.encoder, "theta"):
        target = model.encoder.theta  # nn.Parameter (P, K2)
    elif param_name == "alpha_de":
        target = model.alpha_de  # nn.Parameter (P,)
    elif param_name == "beta0":
        target = model.beta0  # nn.Parameter (P, K)
    elif param_name == "Gamma":
        target = model.Gamma  # nn.Parameter (P, K*K2)
    else:
        return torch.ones(model.n_genes, data.n_context, device=data.device) * 1e6

    # Make sure gradients are tracked
    target.requires_grad_(True)

    # Diagonal of I_comp: exact Hessian for alpha_de/theta if requested, else OPG.
    if hessian_se and param_name == "alpha_de":
        I_comp = _compute_I_comp_hessian_alpha_de(data, model, likelihood_mode)
    elif hessian_se and param_name == "theta":
        I_comp = _compute_I_comp_hessian_theta(data, model, likelihood_mode)
        I_comp = I_comp.reshape(-1)  # flatten (P, K2) -> (P*K2,)
    else:
        # OPG: I_comp[k] = Σ_s (∂Q_s/∂θ_k)²
        # O(n_subjects) passes instead of O(n_params) — ~35× faster for ROSMAP.
        I_comp = _compute_I_comp_opg(data, model, target, likelihood_mode)

    if use_louis_correction:
        I_miss = _compute_I_miss(data, model, target, param_name,
                                 likelihood_mode=likelihood_mode)
        I_obs = (I_comp - I_miss).clamp(min=EPS)
    else:
        I_obs = I_comp

    se = (1.0 / I_obs.sqrt()).reshape(target.shape)
    return se.detach()


def louis_formula_se_both(
    data: PrismData,
    model,
    param_name: str = "theta",
    likelihood_mode: str = "ln",
) -> tuple[Tensor, Tensor]:
    """Return BOTH naive and Louis-corrected SEs for comparison.

    Returns
    -------
    se_naive : SE from I_comp only (current default).
    se_louis : SE from I_comp − I_miss (Louis-corrected).
    """
    if param_name == "theta" and hasattr(model.encoder, "theta"):
        target = model.encoder.theta
    elif param_name == "alpha_de":
        target = model.alpha_de
    elif param_name == "beta0":
        target = model.beta0
    elif param_name == "Gamma":
        target = model.Gamma
    else:
        big = torch.ones(model.n_genes, data.n_context, device=data.device) * 1e6
        return big, big

    target.requires_grad_(True)
    I_comp = _compute_I_comp_opg(data, model, target, likelihood_mode)
    I_miss = _compute_I_miss(data, model, target, param_name,
                             likelihood_mode=likelihood_mode)

    se_naive = (1.0 / I_comp.sqrt()).reshape(target.shape).detach()
    I_obs = (I_comp - I_miss).clamp(min=EPS)
    se_louis = (1.0 / I_obs.sqrt()).reshape(target.shape).detach()

    return se_naive, se_louis


def _compute_I_comp_opg(
    data: PrismData,
    model,
    target: Tensor,
    likelihood_mode: str = "ln",
) -> Tensor:
    """Compute diagonal of I_comp via per-subject OPG (outer-product-of-gradients).

    Uses the complete-data Fisher identity evaluated at the EM fixed point:
        I_comp[k] = Σ_s (∂Q_s/∂θ_k)²

    This is exact at the EM optimum (where ∂Q/∂θ = 0) and O(n_subjects)
    passes instead of O(n_params) — ~35× faster for ROSMAP-scale data.

    Parameters
    ----------
    data : PrismData
    model : PrismModel with converged parameters
    target : nn.Parameter (theta, alpha_de, beta0, or Gamma)
    likelihood_mode : "ln" or "hl"

    Returns
    -------
    I_comp_diag : (n,) — flattened positive diagonal of I_comp.
    """
    from ..model.nb_likelihood import ln_approx_loglik_weighted
    from ..model.hl_likelihood import hl_loglik_weighted

    n = target.numel()
    I_comp = torch.zeros(n, device=data.device, dtype=torch.float32)

    alpha, lam = model.alpha_lambda
    phi = model.phi
    if likelihood_mode == "hl":
        alpha = alpha.detach()
        lam = lam.detach()
        phi = phi.detach()

    for s in range(data.n_subjects):
        mask = data.cells_for_subject(s)
        if mask.sum() == 0:
            continue

        Y_s = data.Y[mask]
        X_s = data.X[mask]
        Z_s = data.Z[mask]
        log_pi_s = data.log_pi[mask]
        q_s = model.q[mask].detach()

        # Fresh computation graph for this subject only
        target.requires_grad_(True)
        mu_star_d0 = model.compute_mu_star(X_s, log_pi_s, Z_s)
        delta_s = model.compute_delta(Z_s)
        mu_star_d1 = mu_star_d0 * clamp_exp(delta_s)

        if likelihood_mode == "hl":
            ll_s = hl_loglik_weighted(
                Y_s, mu_star_d0, mu_star_d1,
                model.eta[s], phi, alpha, lam, q_s,
            )
        else:
            ll_s = ln_approx_loglik_weighted(
                Y_s, mu_star_d0, mu_star_d1, alpha, lam, phi, q_s,
            )

        loss_s = -ll_s.sum()  # scalar (neg Q contribution for subject s)
        (g_s,) = torch.autograd.grad(loss_s, target, retain_graph=False)
        I_comp += g_s.detach().float().reshape(-1) ** 2

    return I_comp.clamp(min=EPS)


@torch.no_grad()
def _compute_I_comp_hessian_alpha_de(
    data: PrismData,
    model,
    likelihood_mode: str = "ln",
) -> Tensor:
    """Profile-Fisher diagonal Hessian of -Q w.r.t. alpha_de.

    The per-cell NB info weight is w_j = (y_j + φ)·μ_j·φ / (μ_j + φ)².  For
    the Q-function with cell-level latent d_j ∈ {0, 1}

        ∂Q/∂α   = Σ_j q_j · (y_j − μ_j(d=1))
        ∂Q/∂b_i = Σ_{j∈i} [q_j(y_j − μ_j(d=1)) + (1−q_j)(y_j − μ_j(d=0))]

    the per-subject Q-Hessian blocks are

        I_αα^i = I_αb^i = Σ_{j∈i} q_j w_j
        I_bb^i = Σ_{j∈i} w_j  +  1/σ²_g                 (h-likelihood prior)

    After integrating out (profiling) b_i ~ N(0, σ²_g) the subject-profile
    Fisher is

        I_α^i = I_αα^i − (I_αb^i)² / I_bb^i
              = Σ q_j w_j  −  (Σ q_j w_j)² / (Σ w_j + 1/σ²_g)

    Summed across subjects this is the marginal Fisher for α_de.

    The older "conditional" form Σ_j q_j w_j — which was used previously —
    ignored the random-effect profile and underestimated SE by a factor of
    up to √(1 + n_cells·σ²_g) per subject.  Under PRISM-direct (q ≡ I_i)
    this inflated FPR catastrophically (>80 %); under PRISM-EM the soft q
    weighting damped the effect (Σ q w ≪ Σ w + 1/σ²), so the bug was
    masked as spurious conservatism.

    Returns
    -------
    I_comp_diag : (P,) — diagonal of profile Fisher for alpha_de.
    """
    device = data.device
    P = data.n_genes
    q = model.q.detach()          # (N,)
    Y = data.Y.float()             # (N, P)
    phi = model.phi.detach()       # (P,)
    sigma2 = model.sigma2.detach().clamp(min=1e-4)  # (P,) or scalar

    # Compute full disease-model means for d=1 (α-cell) and d=0 (non-α) cells
    mu_star = model.compute_mu_star(data.X, data.log_pi, data.Z)  # (N, P) = mu_d0_star
    delta = model.compute_delta(data.Z)                             # (N, P)
    mu_d1_star = mu_star * clamp_exp(delta)                         # (N, P)

    if likelihood_mode == "hl":
        # omega = exp(eta[subject, gene])
        omega = torch.exp(
            model.eta[data.subject_idx].detach().clamp(-20, 20)
        )
    else:
        # LN: use omega_bar posterior mean
        from ..model.nb_likelihood import compute_omega_bar
        alpha_re, lam_re = model.alpha_lambda
        omega_ss = torch.ones(data.n_subjects, P, device=device)
        for s in range(data.n_subjects):
            mask = data.cells_for_subject(s)
            if mask.sum() == 0:
                continue
            omega_ss[s] = compute_omega_bar(
                Y[mask], mu_d1_star[mask], alpha_re, lam_re,
            )
        omega = omega_ss[data.subject_idx]  # (N, P)

    mu_d1 = mu_d1_star * omega  # (N, P)  -- α-cell mean
    mu_d0 = mu_star * omega      # (N, P)  -- non-α-cell mean

    # Per-cell NB info weight for each component
    phi_exp = phi.unsqueeze(0)
    w_a = (Y + phi_exp) * mu_d1 * phi_exp / (mu_d1 + phi_exp).square()
    w_0 = (Y + phi_exp) * mu_d0 * phi_exp / (mu_d0 + phi_exp).square()
    q2 = q.unsqueeze(1)
    qw_a = q2 * w_a                            # contributes to Iaa, Iab
    w_mix = q2 * w_a + (1.0 - q2) * w_0        # contributes to Ibb

    # Subject-wise accumulators via scatter_add
    subj = data.subject_idx
    Iaa_s = torch.zeros(data.n_subjects, P, device=device)
    Ibb_s = torch.zeros(data.n_subjects, P, device=device)
    Iaa_s.index_add_(0, subj, qw_a)
    Ibb_s.index_add_(0, subj, w_mix)

    # Prior contribution 1/σ²_g added to I_bb
    if sigma2.dim() == 0:
        inv_s2 = (1.0 / sigma2).expand(P).unsqueeze(0)
    else:
        inv_s2 = (1.0 / sigma2).unsqueeze(0)
    Ibb_s = Ibb_s + inv_s2

    # Profile Fisher: I_α^i = I_αα − I_αb² / I_bb   (I_αα = I_αb here)
    I_profile = (Iaa_s - Iaa_s.square() / Ibb_s.clamp(min=EPS)).sum(dim=0)

    return I_profile.clamp(min=EPS)


@torch.no_grad()
def _compute_I_comp_hessian_theta(
    data: PrismData,
    model,
    likelihood_mode: str = "ln",
) -> Tensor:
    """Profile-Fisher diagonal Hessian of -Q w.r.t. each theta_k.

    Let δ_g(z) = α_g + θ_g^T z and w_j = (y + φ)·μ·φ / (μ + φ)².  The
    per-subject Q-Hessian blocks for θ_{g,k} are

        I_{θθ}^i = Σ_{j∈i} q_j w_j z_{j,k}²
        I_{θb}^i = Σ_{j∈i} q_j w_j z_{j,k}
        I_{bb}^i = Σ_{j∈i} w_j  +  1/σ²_g

    Profile Fisher after integrating out the subject random effect b_i:

        I_θ_{g,k}^i = I_{θθ}^i − (I_{θb}^i)² / I_{bb}^i

    For contexts that vary within subject (z_{j,k} − z̄_k^i ≠ 0 on average)
    the subtractive term is small, because b_i cannot absorb within-subject
    signal.  For subject-constant contexts (genotype, sex, stage) the
    correction is equivalent to the α profile correction.

    Returns
    -------
    I_comp_diag : (P, K2) — diagonal of profile Fisher for each θ_{g,k}.
    """
    device = data.device
    P = data.n_genes
    K2 = data.n_context
    q = model.q.detach()          # (N,)
    Y = data.Y.float()             # (N, P)
    phi = model.phi.detach()       # (P,)
    Z = data.Z                      # (N, K2)
    sigma2 = model.sigma2.detach().clamp(min=1e-4)

    # Compute full disease-model mean for each cell
    mu_star = model.compute_mu_star(data.X, data.log_pi, data.Z)
    delta = model.compute_delta(data.Z)
    mu_d1_star = mu_star * clamp_exp(delta)

    if likelihood_mode == "hl":
        omega = torch.exp(
            model.eta[data.subject_idx].detach().clamp(-20, 20)
        )
    else:
        from ..model.nb_likelihood import compute_omega_bar
        alpha_re, lam_re = model.alpha_lambda
        omega_ss = torch.ones(data.n_subjects, P, device=device)
        for s in range(data.n_subjects):
            mask = data.cells_for_subject(s)
            if mask.sum() == 0:
                continue
            omega_ss[s] = compute_omega_bar(
                Y[mask], mu_d1_star[mask], alpha_re, lam_re,
            )
        omega = omega_ss[data.subject_idx]

    mu_d1 = mu_d1_star * omega
    mu_d0 = mu_star * omega

    phi_exp = phi.unsqueeze(0)
    w_a = (Y + phi_exp) * mu_d1 * phi_exp / (mu_d1 + phi_exp).square()
    w_0 = (Y + phi_exp) * mu_d0 * phi_exp / (mu_d0 + phi_exp).square()
    q2 = q.unsqueeze(1)
    qw_a = q2 * w_a  # (N, P)
    w_mix = q2 * w_a + (1.0 - q2) * w_0

    # Subject-wise I_bb accumulator
    subj = data.subject_idx
    Ibb_s = torch.zeros(data.n_subjects, P, device=device)
    Ibb_s.index_add_(0, subj, w_mix)
    if sigma2.dim() == 0:
        inv_s2 = (1.0 / sigma2).expand(P).unsqueeze(0)
    else:
        inv_s2 = (1.0 / sigma2).unsqueeze(0)
    Ibb_s = Ibb_s + inv_s2

    I_comp = torch.zeros(P, K2, device=device)
    for k in range(K2):
        z_k = Z[:, k].unsqueeze(1)              # (N, 1)
        z_k_sq = z_k.square()
        qw_zk = qw_a * z_k                       # (N, P)
        qw_zk2 = qw_a * z_k_sq                   # (N, P)

        Itt_s = torch.zeros(data.n_subjects, P, device=device)
        Itb_s = torch.zeros(data.n_subjects, P, device=device)
        Itt_s.index_add_(0, subj, qw_zk2)
        Itb_s.index_add_(0, subj, qw_zk)

        I_profile = (Itt_s - Itb_s.square() / Ibb_s.clamp(min=EPS)).sum(dim=0)
        I_comp[:, k] = I_profile

    return I_comp.clamp(min=EPS)


def _compute_I_miss(
    data: PrismData,
    model,
    target: Tensor,
    param_name: str,
    likelihood_mode: str = "ln",
) -> Tensor:
    """Compute the diagonal of I_miss (missing-information matrix).

    For cell-level binary latent d_{ij} the Louis identity gives:
        I_miss[k] = Σ_i Σ_{j∈i} q_{ij}(1−q_{ij}) * (s_{ij,1,k} − s_{ij,0,k})²

    where s_{ij,d,k} = ∂/∂θ_k ℓ(y_{ij} | d_{ij}=d, θ) is the cell-level
    score.  Computing individual per-cell backward passes is O(n_cells) which
    is expensive, so we use a per-subject approximation:

        I_miss_s[k] ≈ q̄_s(1−q̄_s) · (1/n_s) · (Σ_{j∈s} score_diff_j)²
                     = q̄_s(1−q̄_s) · score_diff_s² / n_s

    where score_diff_s = ∂/∂θ_k Σ_{j∈s} (ℓ_j(d=1) − ℓ_j(d=0)) is the
    summed subject score and n_s is the number of cells in subject s.

    Dividing by n_s corrects for the (Σ s_j)² vs Σ s_j² overestimation that
    arises from within-subject cells sharing the same context covariate z_s:
    without the 1/n_s factor I_miss is overestimated by ~n_s, inflating
    SE_Louis/SE_naive from the true ≈1.0 to ≈√n_s.

    Returns
    -------
    I_miss_diag : (n,) — flattened diagonal of I_miss, shape matches target.
    """
    from ..model.nb_likelihood import ln_approx_loglik, compute_omega_bar
    from ..model.hl_likelihood import hl_loglik_subject
    from ..model.random_effects import gamma_params_from_sigma2

    n_params = target.numel()
    I_miss_diag = torch.zeros(n_params, device=data.device)

    alpha, lam = model.alpha_lambda
    phi = model.phi.detach()

    for s in range(data.n_subjects):
        mask = data.cells_for_subject(s)
        n_s = mask.sum()
        if n_s == 0:
            continue

        q_s = model.q[mask].detach()
        q_bar = q_s.mean()
        var_q = q_bar * (1.0 - q_bar)  # subject-level

        if var_q < 1e-10:
            continue

        Y_s = data.Y[mask].float()
        X_s = data.X[mask]
        Z_s = data.Z[mask]
        log_pi_s = data.log_pi[mask]

        # Need gradients w.r.t. target for score computation
        target.requires_grad_(True)

        # Compute mu* under d=0 and d=1 WITH gradient tracking through target
        mu_star_d0 = model.compute_mu_star(X_s, log_pi_s, Z_s)
        delta_s = model.compute_delta(Z_s)
        mu_star_d1 = mu_star_d0 * clamp_exp(delta_s)

        if likelihood_mode == "hl":
            # HL: use exact NB likelihood with eta
            eta_s = model.eta[s].detach()
            ll_d1 = hl_loglik_subject(Y_s, mu_star_d1, eta_s, phi,
                                      alpha.detach(), lam.detach()).sum()
            ll_d0 = hl_loglik_subject(Y_s, mu_star_d0, eta_s, phi,
                                      alpha.detach(), lam.detach()).sum()
        else:
            # LN: use LN approximate likelihood
            # omega_bar using q-weighted mu for consistency
            mu_star_eff = q_bar * mu_star_d1 + (1.0 - q_bar) * mu_star_d0
            omega_bar = compute_omega_bar(Y_s, mu_star_eff.detach(),
                                          alpha.detach(), lam.detach())
            # Score under d=1 and d=0 via the LN approximate likelihood
            ll_d1 = ln_approx_loglik(Y_s, mu_star_d1, alpha.detach(),
                                     lam.detach(), phi).sum()
            ll_d0 = ln_approx_loglik(Y_s, mu_star_d0, alpha.detach(),
                                     lam.detach(), phi).sum()

        # Score difference: ∂ℓ(d=1)/∂θ - ∂ℓ(d=0)/∂θ via autograd (summed over cells)
        ll_diff = ll_d1 - ll_d0
        (score_diff,) = torch.autograd.grad(
            ll_diff, target, create_graph=False, retain_graph=False,
        )
        score_diff_flat = score_diff.detach().reshape(-1)

        # I_miss contribution: q_bar(1-q_bar) * (S1-S0)^2 / n_s
        # The 1/n_s factor corrects for using the squared summed score instead of
        # the sum of squared per-cell scores (see docstring).
        I_miss_diag += var_q * score_diff_flat ** 2 / float(n_s)

    return I_miss_diag


def _chi2_cdf(x: Tensor, df: int = 1) -> Tensor:
    """Chi-squared CDF using the regularized incomplete gamma function.

    For df=1: chi2_cdf(x) = 2 * Phi(sqrt(x)) - 1 = erf(sqrt(x/2))
    """
    if df == 1:
        return torch.erf(torch.sqrt(x.clamp(min=0) / 2.0))
    else:
        # General case: use scipy as fallback (should not happen in hot path)
        import scipy.stats as st
        import numpy as np
        x_np = x.detach().cpu().numpy()
        cdf_np = st.chi2.cdf(x_np, df)
        return torch.tensor(cdf_np, device=x.device, dtype=x.dtype)


def pseudobulk_alpha_de_test(data: "PrismData", model) -> tuple[Tensor, Tensor, Tensor, Tensor]:
    """Subject-level pseudobulk Wald test for the constant disease effect α_de.

    Computes library-size-normalised pseudobulk means per subject, then runs a
    Welch t-test (disease subjects vs control subjects) per gene.  The result
    has n_subjects degrees of freedom for α_de — independent of the EM's q
    uncertainty — giving substantially higher power at low n.

    Intended for use AFTER EM convergence.  The returned p-values are combined
    with the cell-level α_de Wald p-values via Bonferroni min-p in the caller.

    Parameters
    ----------
    data  : PrismData
    model : PrismModel (parameters not used, only data.I / subject_idx / Y / log_pi)

    Returns
    -------
    wald_stat : (P,) — squared Welch t-statistics (chi2(1) approx)
    p_values  : (P,) — two-sided p-values
    log_fc    : (P,) — pseudobulk natural-log fold-change (disease − control
                 mean of log library-normalised subject means); same units as
                 α̂_de_hat, intended as an interpretable magnitude diagnostic.
                 NaN when either group has <2 valid subjects.
    se        : (P,) — Welch standard error of *log_fc* (same scale).
                 NaN when the test is undefined.
    """
    device = data.device
    P = data.n_genes
    S = data.n_subjects

    # Pseudobulk: library-size-normalised mean expression per subject
    pb = torch.zeros(S, P, device=device)  # (S, P)
    valid = torch.zeros(S, dtype=torch.bool, device=device)

    for s in range(S):
        mask = data.cells_for_subject(s)
        if mask.sum() == 0:
            continue
        lib_s = data.log_pi[mask].exp().mean().clamp(min=EPS)
        pb[s] = data.Y[mask].float().mean(dim=0) / lib_s
        valid[s] = True

    log_pb = torch.log(pb.clamp(min=EPS))  # (S, P)

    # Disease / control masks at subject level
    # A subject is "disease" if any of its cells has data.I == True
    is_disease_subj = torch.zeros(S, dtype=torch.bool, device=device)
    for s in range(S):
        mask = data.cells_for_subject(s)
        if mask.sum() > 0 and data.I[mask].any():
            is_disease_subj[s] = True

    disease_idx = (is_disease_subj & valid).nonzero(as_tuple=True)[0]
    control_idx = (~is_disease_subj & valid).nonzero(as_tuple=True)[0]

    n_d = len(disease_idx)
    n_c = len(control_idx)

    if n_d < 2 or n_c < 2:
        # Not enough subjects for a two-sample test
        nan_vec = torch.full((P,), float("nan"), device=device)
        return (
            torch.zeros(P, device=device),
            torch.ones(P, device=device),
            nan_vec,
            nan_vec,
        )

    pb_d = log_pb[disease_idx]   # (n_d, P)
    pb_c = log_pb[control_idx]   # (n_c, P)

    mean_d = pb_d.mean(dim=0)    # (P,)
    mean_c = pb_c.mean(dim=0)    # (P,)

    # Unbiased per-group variances
    var_d = pb_d.var(dim=0, unbiased=True).clamp(min=EPS)   # (P,)
    var_c = pb_c.var(dim=0, unbiased=True).clamp(min=EPS)   # (P,)

    # Welch t-statistic
    se_welch = (var_d / n_d + var_c / n_c).clamp(min=EPS).sqrt()  # (P,)
    t_stat = (mean_d - mean_c) / se_welch  # (P,)
    wald_stat = t_stat ** 2  # chi2(1) approx (valid for large df)

    # Welch-Satterthwaite degrees of freedom (per gene, for accurate p-values)
    num = (var_d / n_d + var_c / n_c) ** 2
    denom = (var_d / n_d) ** 2 / (n_d - 1) + (var_c / n_c) ** 2 / (n_c - 1)
    df_welch = (num / denom.clamp(min=EPS)).clamp(min=1.0)  # (P,)

    # p-values: two-sided from t distribution → use scipy vectorised
    import scipy.stats as st
    import numpy as np
    t_np = t_stat.detach().cpu().numpy()
    df_np = df_welch.detach().cpu().numpy()
    p_np = 2.0 * st.t.sf(np.abs(t_np), df=df_np)
    p_values = torch.tensor(p_np, device=device, dtype=torch.float32)

    log_fc = (mean_d - mean_c).to(torch.float32)  # (P,) natural-log fold-change
    return wald_stat, p_values, log_fc, se_welch.to(torch.float32)


def clustered_score_test_alpha_de(
    data: "PrismData",
    model,
) -> tuple[Tensor, Tensor]:
    """Subject-level clustered score test for the constant disease effect α_de.

    Score test at H0: α_de_g = 0.  Residuals are evaluated against the *null*
    baseline μ_d0 = μ_star (not μ_d1), so that under H0 the q-weighted
    residual has zero expectation regardless of the α̂ estimate.  This makes
    the test immune to α̂ shrinkage that breaks the cell-level Wald when q is
    EM-inferred (soft).  For each disease subject i:

        s_{ig} = Σ_{j ∈ i, disease} q_{ij} · (y_{ijg} − μ̂_{d0,ijg}) / n_cells_i

    Under H0, E[s_{ig}] = 0 up to random-intercept noise shared across cells
    in subject i — exactly what a cluster-robust score test requires.  Under
    H1 the q-weighted residual picks up q·μ_d0·(e^α − 1), preserving power
    even when α̂ itself is pulled toward zero by soft q. A two-sample Welch
    t-test against control-subject residuals gives n_disease−1 effective df.

    Returns
    -------
    wald_stat : (P,)  squared t-statistics
    p_values  : (P,)  two-sided p-values
    """
    import scipy.stats as st
    import numpy as np

    device = data.device
    P = data.n_genes

    q = model.q.detach()          # (N,)
    Y = data.Y.float()             # (N, P)

    with torch.no_grad():
        mu_star = model.compute_mu_star(data.X, data.log_pi, data.Z)  # (N, P)
        alpha_d1 = model.alpha_de.detach()                             # (P,)
        mu_d1 = mu_star * alpha_d1.exp().unsqueeze(0)                  # (N, P)
        mu_d0 = mu_star                                                 # (N, P)

    n_subjects = data.n_subjects

    is_disease_subj = torch.zeros(n_subjects, dtype=torch.bool, device=device)
    for s in range(n_subjects):
        mask = data.cells_for_subject(s)
        if mask.sum() > 0 and data.I[mask].any():
            is_disease_subj[s] = True

    disease_subjects = is_disease_subj.nonzero(as_tuple=True)[0]
    control_subjects = (~is_disease_subj).nonzero(as_tuple=True)[0]

    n_d = len(disease_subjects)
    n_c = len(control_subjects)

    if n_d < 2:
        return torch.zeros(P, device=device), torch.ones(P, device=device)

    # Disease subjects: q-weighted residual score, normalised by n_cells
    scores_d = torch.zeros(n_d, P, device=device)
    for i, s in enumerate(disease_subjects):
        mask = data.cells_for_subject(s)
        n_s = float(mask.sum())
        if n_s == 0:
            continue
        q_s  = q[mask].unsqueeze(1)          # (n_s, 1)
        y_s  = Y[mask]                        # (n_s, P)
        mu_s = mu_d0[mask]                    # null baseline; α=0
        scores_d[i] = (q_s * (y_s - mu_s)).sum(dim=0) / n_s

    # Control subjects: baseline residual score (q=0 always)
    scores_c = torch.zeros(max(n_c, 1), P, device=device)
    for i, s in enumerate(control_subjects):
        mask = data.cells_for_subject(s)
        n_s = float(mask.sum())
        if n_s == 0:
            continue
        scores_c[i] = (Y[mask] - mu_d0[mask]).mean(dim=0)

    mean_d = scores_d.mean(dim=0)
    var_d  = scores_d.var(dim=0, unbiased=True).clamp(min=EPS)

    if n_c >= 2:
        mean_c = scores_c.mean(dim=0)
        var_c  = scores_c.var(dim=0, unbiased=True).clamp(min=EPS)
        se     = (var_d / n_d + var_c / n_c).clamp(min=EPS).sqrt()
        t_stat = (mean_d - mean_c) / se
        num    = (var_d / n_d + var_c / n_c) ** 2
        denom  = (var_d / n_d) ** 2 / (n_d - 1) + (var_c / n_c) ** 2 / (n_c - 1)
        df     = (num / denom.clamp(min=EPS)).clamp(min=1.0)
    else:
        se     = (var_d / n_d).clamp(min=EPS).sqrt()
        t_stat = mean_d / se
        df     = torch.full((P,), float(n_d - 1), device=device)

    t_np  = t_stat.detach().cpu().numpy()
    df_np = (df.detach().cpu().numpy() if isinstance(df, Tensor)
             else np.full(P, float(df)))
    p_np  = 2.0 * st.t.sf(np.abs(t_np), df=df_np)

    return t_stat ** 2, torch.tensor(p_np, device=device, dtype=torch.float32)


def brown_df_adaptive(*p_tensors: Tensor, null_threshold: float = 0.2) -> float:
    """Estimate Brown-corrected df from the observed -2 log p correlation.

    Under H0, each -2 log p_i has mean 2 and variance 4 (χ²_2).  The variance
    of F = Σ -2 log p_i is

        Var(F) = Σ Var(-2 log p_i) + 2 Σ_{i<j} Cov(-2 log p_i, -2 log p_j)
               = 4K + 2 Σ_{i<j} 4·r_{ij}
               = 4K + 8 Σ_{i<j} r_{ij}

    with r_{ij} the Pearson correlation of -2 log p under H0.  Moment matching
    F to a χ²_{k̂} reference with variance 2k̂ gives

        k̂ = Var(F)/2 = 2K + 4 Σ_{i<j} r_{ij}.

    We estimate r_{ij} from null-like genes (both p_i, p_j > `null_threshold`)
    to avoid inflation from H1 genes where -log p is jointly large.
    """
    import numpy as np

    K = len(p_tensors)
    if K < 2:
        return float(2 * K)

    arrays = [p.detach().cpu().numpy().clip(1e-300, 1.0 - 1e-7) for p in p_tensors]
    null_mask = np.ones_like(arrays[0], dtype=bool)
    for a in arrays:
        null_mask &= (a > null_threshold)

    if null_mask.sum() < 30:
        null_mask = np.ones_like(null_mask, dtype=bool)

    neglogs = [-2.0 * np.log(a[null_mask]) for a in arrays]

    pair_cov_sum = 0.0
    for i in range(K):
        for j in range(i + 1, K):
            xi, xj = neglogs[i], neglogs[j]
            if xi.std() < 1e-8 or xj.std() < 1e-8:
                r = 0.0
            else:
                r = float(np.corrcoef(xi, xj)[0, 1])
            r = max(0.0, min(0.999, r))
            pair_cov_sum += r

    return float(2 * K + 4.0 * pair_cov_sum)


def fisher_combine_pvalues(
    *p_tensors: Tensor,
    df: Optional[float | str] = None,
) -> Tensor:
    """Combine k p-value vectors via Fisher's statistic F = -2 Σ log(p_k).

    Parameters
    ----------
    p_tensors : each (P,).
    df : reference degrees of freedom for F.

        - ``None`` → use 2K (classical Fisher; exact under independence).
        - ``float`` → fixed Brown-corrected reference χ²_{df}, e.g. 8.37
          from a pooled null simulation.
        - ``"adaptive"`` → estimate k̂ per run from the observed -2 log p
          correlation among null-like genes (see `brown_df_adaptive`).
          Lifts power when the actual correlation is below the pooled null,
          while preserving calibration when it matches.

    Returns
    -------
    p_combined : (P,).
    """
    import scipy.stats as st

    device = p_tensors[0].device
    k = len(p_tensors)
    log_sum = sum(torch.log(p.clamp(min=1e-300, max=1.0 - 1e-7)) for p in p_tensors)
    F = -2.0 * log_sum
    if isinstance(df, str):
        if df != "adaptive":
            raise ValueError(f"Unknown df mode: {df!r}")
        ref_df = brown_df_adaptive(*p_tensors)
    else:
        ref_df = float(df) if df is not None else 2 * k
    p_np = st.chi2.sf(F.detach().cpu().numpy(), df=ref_df)
    return torch.tensor(p_np, device=device, dtype=torch.float32)

