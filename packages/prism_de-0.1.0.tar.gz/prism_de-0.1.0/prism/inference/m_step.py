"""M-step: optimize model parameters given fixed q (E-step output).

The M-step objective Q is the expected complete-data log-likelihood:
    Q(Theta | Theta_old) = sum_i sum_g Q_ig
where
    Q_ig = sum_j [ q*_ij * ell(Y_ij; mu_d1) + (1 - q*_ij) * ell(Y_ij; mu_d0) ]

We support two likelihood approximations:
  - LN (default): NEBULA-LN approximate likelihood (fast, subject-level reduction).
  - HL: NEBULA-HL hierarchical likelihood with explicit eta (more accurate for
    large sigma^2 but includes S*P extra parameters).

Both support trust-region Newton-CG and Adam; Adam is the default and runs fully on GPU. Trust-region Newton-CG uses a serial Python CG inner loop and is significantly slower.
"""

from __future__ import annotations

from typing import Callable, Optional

import torch
from torch import Tensor

from ..data.dataset import PrismData
from ..model.nb_likelihood import (
    ln_approx_loglik_weighted,
    compute_omega_bar,
)
from ..model.hl_likelihood import hl_loglik_weighted
from ..model.random_effects import gamma_params_from_sigma2
from ..utils.numerical import EPS, clamp_exp, safe_log


def _copy_to_param(param: torch.nn.Parameter, src: Tensor) -> None:
    """Copy src into param.data (detached, for model state sync)."""
    param.data.copy_(src.detach())


def _functional_m_step_objective(
    data: PrismData,
    model,
    beta0: Tensor,
    Gamma: Tensor,
    alpha_de: Tensor,
    log_sigma2: Tensor,
    log_phi: Tensor,
    theta: Optional[Tensor] = None,
) -> Tensor:
    """Functional M-step objective (LN mode) with explicit parameter tensors.

    New model:
        log mu_d0 = x' beta0 + x' Gamma z + log_pi   (contextualized baseline)
        log mu_d1 = log mu_d0 + alpha_de + theta' z   (+ disease effect)
    """
    alpha, lam = gamma_params_from_sigma2(log_sigma2)
    phi = torch.nn.functional.softplus(log_phi).clamp(min=EPS)

    total_ll = torch.zeros(data.n_genes, device=data.device)

    for s in range(data.n_subjects):
        mask = data.cells_for_subject(s)
        if mask.sum() == 0:
            continue

        Y_s = data.Y[mask]
        X_s = data.X[mask].to(beta0.dtype)
        Z_s = data.Z[mask].to(beta0.dtype)
        log_pi_s = data.log_pi[mask].to(beta0.dtype)
        q_s = model.q[mask]

        # Contextualized baseline: x' beta0 + x' Gamma z + log_pi
        XZ_s = model._context_interaction(X_s, Z_s)  # (n_s, K*K2)
        eta = X_s @ beta0.T + XZ_s @ Gamma.T + log_pi_s.unsqueeze(1)
        mu_star_d0 = clamp_exp(eta)

        # Disease effect: alpha_de + theta' z
        delta_s = alpha_de.unsqueeze(0)  # (1, P) broadcast
        if theta is not None:
            if theta.ndim == 2:
                delta_s = delta_s + Z_s @ theta.T  # (n_s, P)
            else:
                delta_s = delta_s + theta.unsqueeze(0)  # (1, P)

        mu_star_d1 = mu_star_d0 * clamp_exp(delta_s)

        ll_s = ln_approx_loglik_weighted(
            Y_s, mu_star_d0, mu_star_d1, alpha, lam, phi, q_s
        )
        total_ll = total_ll + ll_s

    return -total_ll.sum()


def _functional_m_step_objective_hl(
    data: PrismData,
    model,
    beta0: Tensor,
    Gamma: Tensor,
    alpha_de: Tensor,
    eta: Tensor,
    theta: Optional[Tensor] = None,
) -> Tensor:
    """Functional HL M-step objective with explicit parameters.

    Like the LN version but evaluates the exact NB likelihood per cell
    with omega_i = exp(eta_ig). sigma2/phi are FROZEN.

    Parameters
    ----------
    beta0 : (P, K)
    Gamma : (P, K*K2)
    alpha_de : (P,)
    eta : (S, P)
    theta : (P, K2), optional
    """
    alpha, lam = model.alpha_lambda
    phi = model.phi

    total_ll = torch.zeros(data.n_genes, device=data.device)

    for s in range(data.n_subjects):
        mask = data.cells_for_subject(s)
        if mask.sum() == 0:
            continue

        Y_s = data.Y[mask]
        X_s = data.X[mask].to(beta0.dtype)
        Z_s = data.Z[mask].to(beta0.dtype)
        log_pi_s = data.log_pi[mask].to(beta0.dtype)
        q_s = model.q[mask]

        # Contextualized baseline (WITHOUT random effect — HL adds it inside)
        XZ_s = model._context_interaction(X_s, Z_s)
        eta_base = X_s @ beta0.T + XZ_s @ Gamma.T + log_pi_s.unsqueeze(1)
        mu_star_d0 = clamp_exp(eta_base)

        # Disease effect
        delta_s = alpha_de.unsqueeze(0)
        if theta is not None:
            if theta.ndim == 2:
                delta_s = delta_s + Z_s @ theta.T
            else:
                delta_s = delta_s + theta.unsqueeze(0)

        mu_star_d1 = mu_star_d0 * clamp_exp(delta_s)

        ll_s = hl_loglik_weighted(
            Y_s, mu_star_d0, mu_star_d1, eta[s], phi, alpha, lam, q_s
        )
        total_ll = total_ll + ll_s

    return -total_ll.sum()


def m_step_objective(
    data: PrismData,
    model,  # PrismModel
) -> Tensor:
    """Compute the M-step objective Q = sum_g Q_g (negative, for minimization).

    For each subject i:
        1. Get cells for subject i: Y_i (n_i, P), X_i, Z_i, q_i
        2. Compute mu_star under d=0 and d=1
        3. Compute the weighted NEBULA-LN approximate log-likelihood
        4. Sum over subjects and genes

    Returns
    -------
    loss : scalar — negative Q (to minimize).
    """
    alpha, lam = model.alpha_lambda
    phi = model.phi

    total_ll = torch.zeros(data.n_genes, device=data.device)

    for s in range(data.n_subjects):
        mask = data.cells_for_subject(s)
        if mask.sum() == 0:
            continue

        Y_s = data.Y[mask]              # (n_s, P)
        X_s = data.X[mask]              # (n_s, K)
        Z_s = data.Z[mask]              # (n_s, K2)
        log_pi_s = data.log_pi[mask]    # (n_s,)
        q_s = model.q[mask]             # (n_s,)

        # mu* under d=0: exp(X' beta + log pi)
        mu_star_d0 = model.compute_mu_star(X_s, log_pi_s, Z_s)  # (n_s, P)

        # delta
        delta_s = model.compute_delta(Z_s)  # (n_s, P)
        mu_star_d1 = mu_star_d0 * clamp_exp(delta_s)  # (n_s, P)

        # Weighted LN log-likelihood
        ll_s = ln_approx_loglik_weighted(
            Y_s, mu_star_d0, mu_star_d1, alpha, lam, phi, q_s
        )  # (P,)

        total_ll = total_ll + ll_s

    loss = -total_ll.sum()  # scalar, negative for minimization
    # L2 (Gaussian MAP) prior on alpha_de: −(l2/2)||alpha_de||²
    alpha_de_l2 = getattr(model, 'alpha_de_l2', 0.0)
    if alpha_de_l2 > 0.0 and model.alpha_de.requires_grad:
        loss = loss + alpha_de_l2 * model.alpha_de.pow(2).sum()
    return loss


def m_step_objective_hl(
    data: PrismData,
    model,  # PrismModel
) -> Tensor:
    """HL M-step objective: sum over subjects of h-likelihood.

    Like m_step_objective but uses the exact NB likelihood with eta parameters.
    sigma2 and phi are treated as FROZEN (no gradients).
    """
    alpha, lam = model.alpha_lambda
    phi = model.phi
    # Detach so no gradient flows to sigma2/phi
    alpha = alpha.detach()
    lam = lam.detach()
    phi = phi.detach()

    total_ll = torch.zeros(data.n_genes, device=data.device)

    for s in range(data.n_subjects):
        mask = data.cells_for_subject(s)
        if mask.sum() == 0:
            continue

        Y_s = data.Y[mask]
        X_s = data.X[mask]
        Z_s = data.Z[mask]
        log_pi_s = data.log_pi[mask]
        q_s = model.q[mask]

        mu_star_d0 = model.compute_mu_star(X_s, log_pi_s, Z_s)
        delta_s = model.compute_delta(Z_s)
        mu_star_d1 = mu_star_d0 * clamp_exp(delta_s)

        ll_s = hl_loglik_weighted(
            Y_s, mu_star_d0, mu_star_d1, model.eta[s],
            phi, alpha, lam, q_s,
        )
        total_ll = total_ll + ll_s

    loss = -total_ll.sum()
    # L2 (Gaussian MAP) prior on alpha_de: −(l2/2)||alpha_de||²
    alpha_de_l2 = getattr(model, 'alpha_de_l2', 0.0)
    if alpha_de_l2 > 0.0 and model.alpha_de.requires_grad:
        loss = loss + alpha_de_l2 * model.alpha_de.pow(2).sum()
    return loss


class TrustRegionNewtonCG:
    """Trust-region Newton-CG optimizer using HVPs via torch.func.

    This optimizer is designed for the smooth, concave NEBULA-LN objective
    where second-order methods converge in ~10 iterations.

    Parameters
    ----------
    max_iter : int — maximum trust-region steps.
    max_cg_iter : int — maximum CG iterations per step.
    trust_radius : float — initial trust radius.
    grad_tol : float — convergence threshold on gradient norm.
    max_grad_norm : float — gradient clipping value.
    eta : float — trust-region acceptance threshold.
    """

    def __init__(
        self,
        max_iter: int = 50,
        max_cg_iter: int = 20,
        trust_radius: float = 1.0,
        grad_tol: float = 1e-6,
        max_grad_norm: float = 5.0,
        eta: float = 0.15,
    ):
        self.max_iter = max_iter
        self.max_cg_iter = max_cg_iter
        self.trust_radius = trust_radius
        self.grad_tol = grad_tol
        self.max_grad_norm = max_grad_norm
        self.eta = eta

        # Diagnostics
        self.n_iter = 0
        self.grad_norms: list[float] = []
        self.losses: list[float] = []

    def minimize(
        self,
        loss_fn: Callable[[Tensor], Tensor],
        x0: Tensor,
    ) -> Tensor:
        """Minimize loss_fn starting from x0.

        Parameters
        ----------
        loss_fn : callable — pure function x -> scalar loss.
        x0 : flat parameter tensor.

        Returns
        -------
        x_opt : optimized parameters (same shape as x0).
        """
        x = x0.clone().detach().requires_grad_(True)
        trust_r = self.trust_radius

        for it in range(self.max_iter):
            # Forward + backward once, retaining graph for cheap HVPs in CG.
            loss = loss_fn(x)
            g = torch.autograd.grad(loss, x, create_graph=True)[0]
            loss_val = loss.item()

            g_norm = g.norm().item()
            self.grad_norms.append(g_norm)
            self.losses.append(loss_val)

            if g_norm < self.grad_tol:
                break

            g_clamped = torch.clamp(g.detach(), -self.max_grad_norm, self.max_grad_norm)

            # CG solve — HVPs computed from retained gradient graph (no forward
            # recomputation).  This matches the old TrustRegion optimizer that
            # called ``loss.backward(retain_graph=True, create_graph=True)``
            # once and then used ``autograd.grad(g·p, x, retain_graph=True)``
            # for every CG direction.
            d = self._cg_solve(g, x, g_clamped, trust_r)

            # Predicted reduction (last HVP from retained graph, then free it)
            Hd = torch.autograd.grad(
                (g * d.detach()).sum(), x, retain_graph=False
            )[0].detach()
            pred_reduction = -(g_clamped @ d + 0.5 * d @ Hd).item()

            # Free computation graph before new forward pass
            del g, loss

            # Actual reduction (no graph needed)
            x_new = (x + d).detach().requires_grad_(True)
            with torch.no_grad():
                loss_new = loss_fn(x_new).item()
            actual_reduction = loss_val - loss_new

            # Trust-region ratio
            if pred_reduction > 0:
                ratio = actual_reduction / pred_reduction
            else:
                ratio = 0.0

            # Accept or reject step
            if ratio > self.eta:
                x = x_new
                # Expand trust region
                if ratio > 0.75:
                    trust_r = min(trust_r * 2.0, 10.0)
            else:
                # Shrink trust region
                trust_r = max(trust_r * 0.25, 1e-6)

            self.n_iter = it + 1

        return x.detach()

    def _cg_solve(
        self,
        g_graph: Tensor,
        x: Tensor,
        g: Tensor,
        trust_r: float,
    ) -> Tensor:
        """Truncated CG solve for H*d = -g within trust radius.

        HVPs are computed from the retained gradient graph: differentiating
        ``(g_graph · p).sum()`` w.r.t. ``x`` gives ``H @ p`` without
        re-running the (expensive) forward pass.
        """
        d = torch.zeros_like(g)
        r = -g.clone()
        p = r.clone()
        r_dot = r @ r

        for _ in range(self.max_cg_iter):
            # HVP via retained graph — no forward recomputation
            Hp = torch.autograd.grad(
                (g_graph * p.detach()).sum(), x, retain_graph=True
            )[0].detach()
            pHp = (p @ Hp).item()

            # Negative curvature: go to trust boundary
            if pHp <= 0:
                tau = self._boundary_step(d, p, trust_r)
                return d + tau * p

            alpha_cg = r_dot.item() / max(pHp, 1e-12)
            d_new = d + alpha_cg * p

            # Trust-region constraint
            if d_new.norm().item() > trust_r:
                tau = self._boundary_step(d, p, trust_r)
                return d + tau * p

            d = d_new
            r = r - alpha_cg * Hp
            r_dot_new = r @ r

            if r_dot_new.sqrt().item() < self.grad_tol:
                break

            p = r + (r_dot_new / r_dot.clamp(min=1e-12)) * p
            r_dot = r_dot_new

        return d

    @staticmethod
    def _boundary_step(d: Tensor, p: Tensor, trust_r: float) -> float:
        """Compute tau so that ||d + tau * p|| = trust_r."""
        dd = (d @ d).item()
        dp = (d @ p).item()
        pp = (p @ p).item()
        # Solve ||d + tau*p||^2 = trust_r^2
        a = pp
        b = 2 * dp
        c = dd - trust_r ** 2
        disc = max(b * b - 4 * a * c, 0.0)
        tau = (-b + disc ** 0.5) / (2 * a + 1e-12)
        return max(tau, 0.0)


def run_m_step(
    data: PrismData,
    model,  # PrismModel
    max_iter: int = 80,
    grad_tol: float = 1e-6,
    trust_radius: float = 1.0,
    lr: float = 0.01,
    optimizer_type: str = "adam",
    likelihood_mode: str = "ln",
) -> dict:
    """Run the M-step: optimize beta0, Gamma, alpha_de, theta, log_sigma2, log_phi given q.

    Parameters
    ----------
    data : PrismData
    model : PrismModel
    max_iter : maximum iterations.
    grad_tol : convergence tolerance.
    trust_radius : initial trust radius (for TR-NCG).
    lr : learning rate (for Adam).
    optimizer_type : "adam" (default) or "trust_region".
    likelihood_mode : "ln" (NEBULA-LN) or "hl" (NEBULA-HL).

    Returns
    -------
    dict with keys: "loss", "grad_norm", "n_iter".
    """
    # Accept both "trust_region" and "trust-region"
    if optimizer_type.replace("-", "_") == "trust_region":
        return _m_step_trust_region(data, model, max_iter, grad_tol, trust_radius, likelihood_mode)
    else:
        return _m_step_adam(data, model, max_iter, lr, grad_tol, likelihood_mode)


def _m_step_trust_region(
    data: PrismData,
    model,
    max_iter: int,
    grad_tol: float,
    trust_radius: float,
    likelihood_mode: str = "ln",
) -> dict:
    """M-step using trust-region Newton-CG."""
    use_hl = likelihood_mode == "hl"

    if use_hl:
        # HL mode: optimise beta0, Gamma, alpha_de, theta, eta.
        # sigma2 and phi are FROZEN.
        param_list = [model.beta0]
        if model.Gamma.requires_grad:
            param_list.append(model.Gamma)
        if model.alpha_de.requires_grad:
            param_list.append(model.alpha_de)
        if hasattr(model.encoder, 'theta'):
            param_list.append(model.encoder.theta)
        param_list.append(model.eta)
    else:
        # LN mode: optimise beta0, Gamma, alpha_de, log_sigma2, log_phi, theta.
        param_list = [model.beta0]
        if model.Gamma.requires_grad:
            param_list.append(model.Gamma)
        if model.alpha_de.requires_grad:
            param_list.append(model.alpha_de)
        param_list.extend([model.log_sigma2, model.log_phi])
        if hasattr(model.encoder, 'theta'):
            param_list.append(model.encoder.theta)

    shapes = [p.shape for p in param_list]
    sizes = [p.numel() for p in param_list]

    def pack(params):
        return torch.cat([p.reshape(-1) for p in params])

    def unpack(flat):
        out = []
        offset = 0
        for shape, size in zip(shapes, sizes):
            out.append(flat[offset:offset + size].reshape(shape))
            offset += size
        return out

    x0 = pack([p.data for p in param_list])

    # Build flags for dynamic unpacking
    gamma_in_list = model.Gamma.requires_grad
    alpha_de_in_list = model.alpha_de.requires_grad
    has_theta = hasattr(model.encoder, 'theta')

    def loss_fn(x_flat):
        parts = unpack(x_flat)
        idx = 0
        beta0_val = parts[idx]; idx += 1
        Gamma_val = parts[idx] if gamma_in_list else model.Gamma.detach()
        if gamma_in_list:
            idx += 1
        alpha_de_val = parts[idx] if alpha_de_in_list else model.alpha_de.detach()
        if alpha_de_in_list:
            idx += 1
        if use_hl:
            theta_val = None
            if has_theta:
                theta_val = parts[idx]; idx += 1
            eta_val = parts[idx]
            return _functional_m_step_objective_hl(
                data, model,
                beta0=beta0_val,
                Gamma=Gamma_val,
                alpha_de=alpha_de_val,
                eta=eta_val,
                theta=theta_val,
            )
        else:
            log_sigma2_val = parts[idx]; idx += 1
            log_phi_val = parts[idx]; idx += 1
            theta_val = None
            if has_theta:
                theta_val = parts[idx]; idx += 1
            return _functional_m_step_objective(
                data, model,
                beta0=beta0_val,
                Gamma=Gamma_val,
                alpha_de=alpha_de_val,
                log_sigma2=log_sigma2_val,
                log_phi=log_phi_val,
                theta=theta_val,
            )

    solver = TrustRegionNewtonCG(
        max_iter=max_iter,
        grad_tol=grad_tol,
        trust_radius=trust_radius,
    )
    x_opt = solver.minimize(loss_fn, x0)

    # Write optimised values back to model
    parts = unpack(x_opt)
    idx = 0
    model.beta0.data = parts[idx]; idx += 1
    if gamma_in_list:
        model.Gamma.data = parts[idx]; idx += 1
    if alpha_de_in_list:
        model.alpha_de.data = parts[idx]; idx += 1
    if use_hl:
        if has_theta:
            model.encoder.theta.data = parts[idx]; idx += 1
        model.eta.data = parts[idx]
    else:
        model.log_sigma2.data = parts[idx]; idx += 1
        model.log_phi.data = parts[idx]; idx += 1
        if has_theta:
            model.encoder.theta.data = parts[idx]; idx += 1

    return {
        "loss": solver.losses[-1] if solver.losses else float("nan"),
        "grad_norm": solver.grad_norms[-1] if solver.grad_norms else float("nan"),
        "n_iter": solver.n_iter,
    }


def _m_step_adam(
    data: PrismData,
    model,
    max_iter: int,
    lr: float,
    grad_tol: float,
    likelihood_mode: str = "ln",
) -> dict:
    """M-step using Adam optimizer (standard)."""
    use_hl = likelihood_mode == "hl"

    if use_hl:
        # HL mode: optimise beta0, Gamma, alpha_de, theta/encoder, eta.
        # sigma2 and phi are frozen.
        params = [model.beta0]
        if model.Gamma.requires_grad:
            params.append(model.Gamma)
        if model.alpha_de.requires_grad:
            params.append(model.alpha_de)
        params.append(model.eta)
        if hasattr(model.encoder, 'parameters'):
            params.extend(list(model.encoder.parameters()))
        # Explicitly zero gradients on sigma2/phi so Adam never touches them
        model.log_sigma2.requires_grad_(False)
        model.log_phi.requires_grad_(False)
    else:
        params = [p for p in model.parameters() if p.requires_grad]

    obj_fn = m_step_objective_hl if use_hl else m_step_objective
    optimizer = torch.optim.Adam(params, lr=lr, weight_decay=1e-6)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=10, min_lr=1e-5
    )

    best_loss = float("inf")
    patience_counter = 0
    last_grad_norm = float("nan")

    for it in range(max_iter):
        optimizer.zero_grad()
        loss = obj_fn(data, model)
        loss.backward()

        # Gradient clipping
        grad_norm = torch.nn.utils.clip_grad_norm_(params, max_norm=5.0).item()
        last_grad_norm = grad_norm

        optimizer.step()
        scheduler.step(loss.item())

        if grad_norm < grad_tol:
            break

        # Early stopping
        if loss.item() < best_loss - 1e-6:
            best_loss = loss.item()
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= 50:
                break

    # Restore gradient tracking for sigma2/phi
    if use_hl:
        model.log_sigma2.requires_grad_(True)
        model.log_phi.requires_grad_(True)

    return {
        "loss": loss.item(),
        "grad_norm": last_grad_norm,
        "n_iter": it + 1,
    }
