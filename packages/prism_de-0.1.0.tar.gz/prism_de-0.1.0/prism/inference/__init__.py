"""Inference modules: E-step, M-step, EM loop, Wald test, Score test.

The Wald test function lives at ``prism.inference.wald_test.wald_test``;
the function is not re-exported here to keep the submodule accessible as
``prism.inference.wald_test``.
"""

from .e_step import e_step
from .m_step import m_step_objective, TrustRegionNewtonCG
from .em_loop import PRISMTrainer
from .wald_test import louis_formula_se, fisher_combine_pvalues
from .score_test import score_test

__all__ = [
    "e_step",
    "m_step_objective",
    "TrustRegionNewtonCG",
    "PRISMTrainer",
    "louis_formula_se",
    "fisher_combine_pvalues",
    "score_test",
]
