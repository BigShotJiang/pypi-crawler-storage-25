"""Logging helpers for PRISM — tqdm progress bar + optional W&B.

The EM loop uses a single tqdm bar that updates in-place, showing the
current iteration metrics without cluttering the console.  W&B logging
is also supported when available and enabled.
"""

from __future__ import annotations

import sys
import time
from typing import Any

try:
    import wandb

    _WANDB_AVAILABLE = True
except ImportError:
    _WANDB_AVAILABLE = False

try:
    from tqdm.auto import tqdm
except ImportError:
    from tqdm import tqdm  # type: ignore[assignment]


class WandbLogger:
    """Thin wrapper: tqdm progress bar locally, optional W&B sync."""

    def __init__(
        self,
        project: str = "prism",
        config: dict[str, Any] | None = None,
        enabled: bool = True,
        run_name: str | None = None,
        max_iter: int | None = None,
        verbose: bool = True,
    ):
        self.enabled = enabled and _WANDB_AVAILABLE
        self._step = 0
        self._start_time = time.time()
        self._max_iter = max_iter

        # ── W&B ───────────────────────────────────────────────
        if self.enabled:
            try:
                wandb.init(
                    project=project,
                    config=config,
                    name=run_name,
                    reinit=True,
                    settings=wandb.Settings(silent=True),
                )
            except Exception:
                self.enabled = False

        # ── tqdm bar (controlled by verbose) ───────────────
        self._bar: tqdm | None = None
        if max_iter is not None:
            self._bar = tqdm(
                total=max_iter,
                desc="EM",
                unit="iter",
                dynamic_ncols=True,
                file=sys.stderr,
                disable=not verbose,
                bar_format=(
                    "{l_bar}{bar}| {n_fmt}/{total_fmt} "
                    "[{elapsed}<{remaining}, {postfix}]"
                ),
            )

    # ------------------------------------------------------------------
    def log(self, metrics: dict[str, Any], step: int | None = None) -> None:
        if step is not None:
            self._step = step

        # W&B
        if self.enabled:
            try:
                wandb.log(metrics, step=self._step)
            except Exception:
                pass

        # tqdm: update postfix with key metrics
        if self._bar is not None:
            pf: dict[str, str] = {}
            if "obs_loglik" in metrics:
                pf["LL"] = f"{metrics['obs_loglik']:.0f}"
            if "delta_ll" in metrics:
                pf["ΔLL"] = f"{metrics['delta_ll']:+.1f}"
            if "mean_q_disease" in metrics:
                pf["q̄"] = f"{metrics['mean_q_disease']:.3f}"
            if "mean_rho" in metrics:
                pf["ρ̄"] = f"{metrics['mean_rho']:.3f}"
            if "m_step_time" in metrics:
                pf["Mstep"] = f"{metrics['m_step_time']:.1f}s"
            if "iter_time" in metrics:
                pf["t"] = f"{metrics['iter_time']:.1f}s"
            self._bar.set_postfix(pf, refresh=True)
            self._bar.update(1)
        self._step += 1

    def log_summary(self, metrics: dict[str, Any]) -> None:
        if self.enabled:
            try:
                for k, v in metrics.items():
                    wandb.run.summary[k] = v  # type: ignore[union-attr]
            except Exception:
                pass

    def finish(self) -> None:
        elapsed = time.time() - self._start_time
        self.log_summary({"total_time_s": elapsed})
        if self._bar is not None:
            self._bar.close()
            self._bar = None
        if self.enabled:
            try:
                wandb.finish(quiet=True)
            except Exception:
                pass

    def __del__(self) -> None:
        if self._bar is not None:
            self._bar.close()
