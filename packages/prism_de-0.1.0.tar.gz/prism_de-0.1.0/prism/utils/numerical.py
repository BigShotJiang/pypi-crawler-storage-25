"""Numerical utility functions for log-space arithmetic, clamping, and softplus."""

from __future__ import annotations

import torch
from torch import Tensor

EPS = 1e-8
LOG_EPS = -60.0
LOG_MAX = 60.0
LOGIT_CLAMP = 50.0


def softplus(x: Tensor, beta: float = 1.0, threshold: float = 20.0) -> Tensor:
    """Numerically stable softplus: log(1 + exp(beta * x)) / beta."""
    return torch.nn.functional.softplus(x, beta=beta, threshold=threshold)


def inv_softplus(x: Tensor, beta: float = 1.0, threshold: float = 20.0) -> Tensor:
    """Inverse softplus: log(exp(beta * x) - 1) / beta.

    For large x (> threshold / beta), returns x directly.
    """
    cond = x * beta > threshold
    safe_x = torch.where(cond, torch.ones_like(x), x)
    result = torch.log(torch.expm1(safe_x * beta)) / beta
    return torch.where(cond, x, result)


def clamp_exp(x: Tensor, lo: float = LOG_EPS, hi: float = LOG_MAX) -> Tensor:
    """Clamped exponential: exp(clamp(x, lo, hi))."""
    return torch.exp(torch.clamp(x, lo, hi))


def log_sum_exp(a: Tensor, b: Tensor) -> Tensor:
    """Numerically stable log(exp(a) + exp(b))."""
    return torch.logaddexp(a, b)


def safe_log(x: Tensor, eps: float = EPS) -> Tensor:
    """Safe logarithm: log(max(x, eps))."""
    return torch.log(torch.clamp(x, min=eps))


def safe_sigmoid(x: Tensor, lo: float = -LOGIT_CLAMP, hi: float = LOGIT_CLAMP) -> Tensor:
    """Sigmoid with clamped input to prevent saturation."""
    return torch.sigmoid(torch.clamp(x, lo, hi))


def batch_lgamma(x: Tensor) -> Tensor:
    """Vectorized lgamma, handling x <= 0 gracefully."""
    return torch.lgamma(torch.clamp(x, min=EPS))
