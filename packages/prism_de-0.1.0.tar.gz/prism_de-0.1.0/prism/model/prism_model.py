"""PrismModel: full PRISM generative model as a PyTorch Module.

Fully-contextualized generative process (per gene g, per cell j in subject i):
    (1)  omega_ig  ~ Gamma(alpha_g, lambda_g)          [subject RE]
    (2)  d_ij      ~ Bernoulli(rho_i)   if I_i=1       [latent disease state]
         d_ij      = 0                   if I_i=0
    (3)  log mu    = log pi + x' beta^0_g + x' Gamma_g z    [contextualized baseline]
                     + d * (alpha_g + theta_g' z)            [disease effect]
                     + eta_ig                                [subject RE]

    All covariate effects are modulated by context z via Gamma_g (K x K2).
    Disease effect is split into constant (alpha_g) and context-dependent
    (theta_g' z) components.

Model variants and their tests:
    n_context=0 (no context provided):
        Gamma vanishes; encoder output is zero; alpha_de captures the full disease
        effect.  This is exactly the NEBULA-LN/HL model (He et al. 2021).
        Test: Wald test on alpha_de — "is gene g differentially expressed?"

    encoder_type="none" (NoneEncoder, context ignored):
        Equivalent to n_context=0.  Useful for ablation when context covariates
        exist but should not modulate the disease effect.
        Test: Wald test on alpha_de — "is gene g DE in general?"

    encoder_type="constant" (ConstantEncoder, no context modulation):
        alpha_de is frozen to 0 (collinear with ConstantEncoder.theta).
        theta_g (scalar) captures the full disease effect.
        Test: Wald test on theta — "is gene g DE in general?"

    encoder_type="linear" / "mlp" (full PRISM):
        Three scientifically distinct tests are available:
          (A) alpha_de test — "is there a general (context-averaged) DE effect?"
          (B) theta test    — "does the DE effect vary significantly by context?"
          (C) omnibus test  — "is there any DE signal at all?" (combines A and B)
        Effect at context z: alpha_de_g + theta_g' z  (reported as de_effects_hat)

Parameters stored:
    beta0     : (P, K)     fixed baseline effects
    Gamma     : (P, K*K2)  contextualized covariate coefficients (flattened; zero
                            when include_context_baseline=False or n_context=0)
    alpha_de  : (P,)       constant disease effect (frozen for ConstantEncoder)
    theta     : (P, K2)    context-dependent disease effect (in encoder)
    log_sigma2: (P,)       log subject-level variance
    log_phi   : (P,)       log cell-level dispersion
    logit_rho : (m_d,)     logit disease prevalence per disease subject
    eta       : (S, P)     log random-effect values [HL mode only]

Likelihood modes:
    "ln"   — NEBULA-LN: marginalise omega analytically (fast, accurate for small sigma^2)
    "hl"   — NEBULA-HL: keep eta = log(omega) as explicit parameters (more accurate
             for large sigma^2, GPU-friendly gradient-based optimisation)
    "auto" — Use LN by default, switch to HL for genes with sigma^2 > threshold
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch
from torch import Tensor, nn

from .encoders import build_encoder, LinearEncoder, ConstantEncoder
from .random_effects import gamma_params_from_sigma2, gamma_posterior_mean
from ..utils.numerical import softplus, clamp_exp, safe_sigmoid, EPS


@dataclass
class PrismParams:
    """Container for all PRISM model parameters.

    These are the *optimizable* quantities.  ``q`` is the E-step output,
    not a model parameter per se, but stored here for convenience.
    """

    beta0: Tensor         # (P, K) — fixed baseline effects
    log_sigma2: Tensor    # (P,)
    log_phi: Tensor       # (P,)
    logit_rho: Tensor     # (m_disease,)
    q: Tensor             # (N,) cell-level posteriors

    # Derived ---------------------------------------------------------------
    @property
    def sigma2(self) -> Tensor:
        return softplus(self.log_sigma2)

    @property
    def phi(self) -> Tensor:
        return softplus(self.log_phi)

    @property
    def rho(self) -> Tensor:
        return safe_sigmoid(self.logit_rho)

    @property
    def alpha_lambda(self) -> tuple[Tensor, Tensor]:
        return gamma_params_from_sigma2(self.log_sigma2)


class PrismModel(nn.Module):
    """Full PRISM model with contextualized covariate effects.

    New model:
        log mu = log pi + x' beta0_g + x' Gamma_g z + d * (alpha_g + theta_g' z) + eta_ig

    Gamma_g in R^{K x K2} contextualizes ALL covariate effects.
    alpha_g is a constant (average) disease effect.
    theta_g in R^{K2} is the context-dependent disease effect.
    """

    def __init__(
        self,
        n_genes: int,
        n_covars: int,
        n_context: int,
        n_disease_subjects: int,
        n_cells: int,
        n_subjects: int = 0,
        encoder_type: str = "linear",
        d_hidden: int = 64,
        n_layers: int = 1,
        likelihood_mode: str = "ln",
        device: str = "cuda",
        dtype: torch.dtype = torch.float32,
        include_context_baseline: bool = True,
    ):
        """
        Parameters
        ----------
        include_context_baseline : bool
            If True (default), include the Gamma term `x' Gamma_g z` in the
            baseline mean (contextualized covariate modulation).  Set to False
            to freeze Gamma=0, reducing the baseline to standard NEBULA
            `log mu* = log pi + x' beta0`.  Has no effect when n_context=0
            (Gamma is empty regardless).
        """
        super().__init__()
        self.n_genes = n_genes
        self.n_covars = n_covars
        self.n_context = n_context
        self._likelihood_mode = likelihood_mode
        self.include_context_baseline = include_context_baseline

        self.encoder = build_encoder(
            encoder_type, n_genes, n_context, d_hidden, n_layers
        ).to(dtype=dtype, device=device)

        # ---- Parameters ----
        # beta0: (P, K) — fixed baseline effects (non-contextualized)
        self.beta0 = nn.Parameter(torch.zeros(n_genes, n_covars, dtype=dtype, device=device))

        # Gamma: (P, K*K2) — contextualized covariate modulation (stored flat)
        # x' Gamma_g z = (x kron z)' vec(Gamma_g).
        # Frozen at zero when include_context_baseline=False or n_context=0.
        self.Gamma = nn.Parameter(torch.zeros(n_genes, n_covars * n_context, dtype=dtype, device=device))
        if not include_context_baseline or n_context == 0:
            self.Gamma.requires_grad_(False)

        # alpha_de: (P,) — constant (average) disease effect
        # With ConstantEncoder, alpha_de is collinear with theta (both are
        # additive per-gene scalars).  We freeze alpha_de=0 so that the
        # encoder's theta captures the full constant disease effect.
        self.alpha_de = nn.Parameter(torch.zeros(n_genes, dtype=dtype, device=device))
        if isinstance(self.encoder, ConstantEncoder):
            self.alpha_de.requires_grad_(False)

        # Dispersion / RE
        self.log_sigma2 = nn.Parameter(torch.zeros(n_genes, dtype=dtype, device=device))
        self.log_phi = nn.Parameter(torch.full((n_genes,), 2.0, dtype=dtype, device=device))  # softplus(2.0) ≈ 2.1
        self.logit_rho = nn.Parameter(torch.zeros(n_disease_subjects, dtype=dtype, device=device))

        # q is not an nn.Parameter — it is updated in the E-step
        self.register_buffer("q", torch.zeros(n_cells, dtype=dtype, device=device))

        # HL mode: eta_{ig} = log(omega_{ig}) — per-subject, per-gene
        if likelihood_mode in ("hl", "auto") and n_subjects > 0:
            self.eta = nn.Parameter(torch.zeros(n_subjects, n_genes, dtype=dtype, device=device))
        else:
            self.register_buffer(
                "eta", torch.zeros(max(n_subjects, 1), n_genes, dtype=dtype, device=device)
            )

    # ------------------------------------------------------------------
    # Convenience accessors
    # ------------------------------------------------------------------

    @property
    def likelihood_mode(self) -> str:
        return self._likelihood_mode

    @likelihood_mode.setter
    def likelihood_mode(self, value: str) -> None:
        assert value in ("ln", "hl", "auto"), f"Unknown mode: {value}"
        self._likelihood_mode = value

    @property
    def params(self) -> PrismParams:
        return PrismParams(
            beta0=self.beta0,
            log_sigma2=self.log_sigma2,
            log_phi=self.log_phi,
            logit_rho=self.logit_rho,
            q=self.q,
        )

    @property
    def sigma2(self) -> Tensor:
        return softplus(self.log_sigma2)

    @property
    def phi(self) -> Tensor:
        return softplus(self.log_phi)

    @property
    def rho(self) -> Tensor:
        return safe_sigmoid(self.logit_rho)

    @property
    def alpha_lambda(self) -> tuple[Tensor, Tensor]:
        return gamma_params_from_sigma2(self.log_sigma2)

    # ------------------------------------------------------------------
    # Mean computation
    # ------------------------------------------------------------------

    @staticmethod
    def _context_interaction(X: Tensor, Z: Tensor) -> Tensor:
        """Compute Khatri-Rao (row-wise Kronecker) product of X and Z.

        Parameters
        ----------
        X : (N, K)
        Z : (N, K2)

        Returns
        -------
        (N, K*K2) — each row is vec(x_j z_j^T), i.e. x_j ⊗ z_j.
        """
        # X[:, :, None] * Z[:, None, :] -> (N, K, K2) then flatten
        return (X.unsqueeze(2) * Z.unsqueeze(1)).reshape(X.shape[0], -1)

    def compute_mu_star(self, X: Tensor, log_pi: Tensor, Z: Tensor) -> Tensor:
        """Compute mu* = exp(x' beta0 + x' Gamma z + log pi) for all cells.

        This is the baseline mean (without disease or RE terms).

        Parameters
        ----------
        X : (N, K)
        log_pi : (N,)
        Z : (N, K2)

        Returns
        -------
        (N, P)
        """
        X = X.to(self.beta0.dtype)
        Z = Z.to(self.beta0.dtype)
        log_pi = log_pi.to(self.beta0.dtype)

        # Fixed baseline: x' beta0_g
        eta = X @ self.beta0.T + log_pi.unsqueeze(1)  # (N, P)

        # Contextualized covariate term: x' Gamma_g z = XZ @ Gamma^T
        XZ = self._context_interaction(X, Z)  # (N, K*K2)
        eta = eta + XZ @ self.Gamma.T  # (N, P)

        return clamp_exp(eta)

    def compute_delta(self, Z: Tensor) -> Tensor:
        """Compute disease effect Delta(z) = alpha_g + theta_g' z for all cells.

        Parameters
        ----------
        Z : (N, K2)

        Returns
        -------
        (N, P) — per-cell, per-gene total disease log-fold-change.
        """
        Z = Z.to(self.beta0.dtype)
        # Constant disease effect
        delta = self.alpha_de.unsqueeze(0).expand(Z.shape[0], -1)  # (N, P)
        # Context-dependent disease effect from encoder
        if isinstance(self.encoder, (LinearEncoder, ConstantEncoder)):
            delta = delta + self.encoder(Z, self.encoder.theta)
        else:
            delta = delta + self.encoder(Z)
        return delta

    def de_effect(self, Z: Tensor) -> Tensor:
        """Predicted disease log-fold-change for each cell at context Z.

        Returns alpha_de_g + encoder(Z)_g for all cells and genes.  For
        ConstantEncoder this equals theta_g (constant); for NoneEncoder it
        equals alpha_de_g; for LinearEncoder it equals alpha_de_g + theta_g' z.

        Parameters
        ----------
        Z : (N, K2) context covariates for the cells of interest.

        Returns
        -------
        (N, P) — log-fold-change at each context z.
        """
        return self.compute_delta(Z)

    def compute_mu_d0_d1(
        self,
        X: Tensor,
        Z: Tensor,
        log_pi: Tensor,
        omega_bar: Tensor,
    ) -> tuple[Tensor, Tensor]:
        """Compute mean under d=0 and d=1 for all cells.

        Parameters
        ----------
        X : (N, K)
        Z : (N, K2)
        log_pi : (N,)
        omega_bar : (N, P) — per-cell posterior mean of subject RE.

        Returns
        -------
        mu_d0, mu_d1 : (N, P)
        """
        X = X.to(self.beta0.dtype)
        Z = Z.to(self.beta0.dtype)
        log_pi = log_pi.to(self.beta0.dtype)

        # Baseline: x' beta0 + x' Gamma z + log_pi
        eta_base = X @ self.beta0.T + log_pi.unsqueeze(1)
        XZ = self._context_interaction(X, Z)
        eta_base = eta_base + XZ @ self.Gamma.T

        log_omega = torch.log(omega_bar.clamp(min=EPS))

        log_mu_d0 = eta_base + log_omega
        delta = self.compute_delta(Z)  # (N, P) = alpha + theta' z
        log_mu_d1 = log_mu_d0 + delta

        mu_d0 = clamp_exp(log_mu_d0)
        mu_d1 = clamp_exp(log_mu_d1)
        return mu_d0, mu_d1

    # ------------------------------------------------------------------
    # Initialization helpers
    # ------------------------------------------------------------------

    def initialize_from_data(self, data, warmstart_alpha_de: bool = False) -> None:
        """Heuristic initialization from PrismData.

        - beta0[:,0] (intercept) ≈ log(mean(Y) / mean(pi))
        - Gamma = 0 (no context modulation initially)
        - alpha_de: 0 by default, or pseudobulk LFC if warmstart_alpha_de=True
        - q = I (all disease cells start as diseased)
        - logit_rho = 0 (rho = 0.5)
        - eta = 0 (omega = 1)

        Parameters
        ----------
        warmstart_alpha_de : bool
            If True, initialise alpha_de from the library-size-normalised
            log-fold-change between disease and control pseudobulk means.
            This breaks the (rho, alpha_de) cold-start deadlock at low n.
        """
        from ..data.dataset import PrismData
        assert isinstance(data, PrismData)

        with torch.no_grad():
            mean_y = data.Y.float().mean(dim=0)  # (P,)
            mean_pi = data.log_pi.exp().mean()
            self.beta0[:, 0] = torch.log(mean_y.clamp(min=EPS) / mean_pi.clamp(min=EPS))

            self.q.copy_(data.I.float())
            self.logit_rho.zero_()  # rho = 0.5
            self.eta.zero_()        # omega = 1

            # Pseudobulk warm-start for alpha_de
            if warmstart_alpha_de and self.alpha_de.requires_grad:
                disease_mask = data.I
                control_mask = ~data.I
                if disease_mask.any() and control_mask.any():
                    lib_d = data.log_pi[disease_mask].exp().mean().clamp(min=EPS)
                    lib_c = data.log_pi[control_mask].exp().mean().clamp(min=EPS)
                    mean_d = data.Y[disease_mask].float().mean(dim=0) / lib_d
                    mean_c = data.Y[control_mask].float().mean(dim=0) / lib_c
                    lfc = torch.log(mean_d.clamp(min=EPS)) - torch.log(mean_c.clamp(min=EPS))
                    # Scale by 1/rho_init (0.5) to recover per-cell effect from
                    # the marginal LFC; clamp to ±3 to avoid extreme init values.
                    self.alpha_de.data.copy_(lfc.clamp(-3.0, 3.0) * 2.0)
