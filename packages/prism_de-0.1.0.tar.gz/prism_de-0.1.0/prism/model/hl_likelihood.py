"""NEBULA-HL (hierarchical likelihood) for the NB mixed model.

Unlike the LN approximation (which analytically marginalises the Gamma
random effect using moment-matched log-normal moments), the HL approach
retains an *explicit* per-subject, per-gene random-effect parameter

    eta_{ig} = log(omega_{ig})

and optimises it alongside the fixed effects.  The per-cell negative-binomial
likelihood is evaluated with the exact omega rather than its posterior mean,
and a Gamma prior on omega = exp(eta) regularises the estimate.

When to prefer HL over LN (He et al., Nature Communications 2021):
  - sigma^2 > ~0.5 : the LN moment-matching becomes inaccurate
  - The NEBULA R package defaults to HL for genes with sigma^2 >= 1

Implementation
--------------
* All operations are pure PyTorch, fully GPU-compatible (no BOBYQA / scipy).
* The h-likelihood for subject *i*, gene *g* is:

    h_{ig} = sum_j [Y_{ijg} * pred_{ijg}
                    - (Y_{ijg} + phi_g) * log(exp(pred_{ijg}) + phi_g)]
             + alpha_g * eta_{ig}
             - lambda_g * exp(eta_{ig})

  where pred_{ijg} = X_ij^T beta_g + log(pi_{ij}) + d_ij * Delta_g(z_ij) + eta_ig

* An optional Laplace correction (for profiling sigma^2, phi) is also
  provided:  -0.5 * log|det(-d^2h / deta^2)|

Reference
---------
He et al. (2021) "NEBULA is a fast negative binomial mixed model for
differential or co-expression analysis of large-scale multi-subject
single-cell data."  Nature Communications 12, 262.
Lee & Nelder (1996) "Hierarchical generalized linear models."
JRSS-B 58, 619–678.
"""

from __future__ import annotations

import torch
from torch import Tensor

from ..utils.numerical import EPS, LOG_EPS, LOG_MAX, safe_log, clamp_exp


def hl_loglik_subject(
    Y_i: Tensor,
    mu_star_i: Tensor,
    eta_i: Tensor,
    phi: Tensor,
    alpha: Tensor,
    lam: Tensor,
) -> Tensor:
    """H-likelihood contribution of subject *i* (all genes).

    Parameters
    ----------
    Y_i : (n_i, P) int/float — counts for cells of subject i.
    mu_star_i : (n_i, P) — mu* = exp(X' beta + log pi + d * Delta).
        This does NOT include the random effect; we add eta_i here.
    eta_i : (P,) — log-random-effect for subject i, each gene.
    phi : (P,) — NB dispersion (larger = less variance).
    alpha, lam : (P,) — Gamma prior parameters for omega = exp(eta).

    Returns
    -------
    (P,) — per-gene h-likelihood contribution.
    """
    Y_f = Y_i.float()

    # Fold random effect into the mean: mu_ij = mu*_ij * exp(eta_i)
    # => log(mu_ij) = log(mu*_ij) + eta_i
    # We work in log-space for stability, then compute the NB terms.
    omega_i = torch.exp(torch.clamp(eta_i, min=-20.0, max=20.0))  # (P,)
    mu_ij = mu_star_i * omega_i.unsqueeze(0)  # (n_i, P)
    mu_ij = mu_ij.clamp(min=EPS)

    # NB log-likelihood per cell (without the lgamma(Y+1) constant):
    #   Y * log(mu) - (Y + phi) * log(mu + phi) + phi*log(phi) + lgamma(Y+phi) - lgamma(phi)
    log_mu = safe_log(mu_ij)
    log_mu_phi = safe_log(mu_ij + phi.unsqueeze(0))

    cell_ll = (
        Y_f * log_mu
        - (Y_f + phi.unsqueeze(0)) * log_mu_phi
        + phi.unsqueeze(0) * safe_log(phi).unsqueeze(0)
        + torch.lgamma(Y_f + phi.unsqueeze(0))
        - torch.lgamma(phi).unsqueeze(0)
    )
    nb_sum = cell_ll.sum(dim=0)  # (P,) — sum over cells

    # Gamma prior on omega = exp(eta):
    #   log p(omega; alpha, lam) = alpha * log(lam) - lgamma(alpha)
    #                             + (alpha - 1) * log(omega) - lam * omega
    #   In terms of eta = log(omega):
    #     alpha * eta - lam * exp(eta) + const(alpha, lam)
    #   (the +const doesn't affect gradients but we include for completeness)
    prior = alpha * eta_i - lam * omega_i

    return nb_sum + prior  # (P,)


def hl_loglik_weighted(
    Y_i: Tensor,
    mu_star_d0_i: Tensor,
    mu_star_d1_i: Tensor,
    eta_i: Tensor,
    phi: Tensor,
    alpha: Tensor,
    lam: Tensor,
    q_i: Tensor,
) -> Tensor:
    """Weighted h-likelihood for one subject in the EM M-step.

    Computes the proper Q-function:
        Q_i = q_bar * h(Y; mu_d1, eta) + (1 - q_bar) * h(Y; mu_d0, eta)

    by evaluating the HL separately under d=0 and d=1 and mixing with
    subject-level q-weight.  This avoids Jensen's approximation.

    Parameters
    ----------
    Y_i : (n_i, P)
    mu_star_d0_i, mu_star_d1_i : (n_i, P) — mu* under d=0 and d=1
        (without random effect).
    eta_i : (P,) — log-random-effect for subject i.
    phi, alpha, lam : (P,)
    q_i : (n_i,) — cell-level disease posteriors.

    Returns
    -------
    (P,) — per-gene weighted h-likelihood.
    """
    ll_d0 = hl_loglik_subject(Y_i, mu_star_d0_i, eta_i, phi, alpha, lam)  # (P,)
    ll_d1 = hl_loglik_subject(Y_i, mu_star_d1_i, eta_i, phi, alpha, lam)  # (P,)
    q_bar = q_i.mean()  # subject-level q
    return q_bar * ll_d1 + (1.0 - q_bar) * ll_d0


def _hl_eta_hessian_diag(
    Y_i: Tensor,
    mu_star_i: Tensor,
    eta_i: Tensor,
    phi: Tensor,
    alpha: Tensor,
    lam: Tensor,
) -> Tensor:
    """Diagonal of d^2 h / d eta_i^2 for one subject (per gene).

    For the NB model with omega = exp(eta), the second derivative of the
    h-likelihood w.r.t. eta_i is:

        d^2h/deta^2 = sum_j [
            Y_ij * omega * mu*_ij / (omega*mu*_ij + phi)
            - (Y_ij + phi) * omega * mu*_ij * phi / (omega*mu*_ij + phi)^2
        ]  (from the NB part — actually we compute it via autograd)
        - lam * exp(eta_i)   (from the prior)

    For efficiency we use the analytical form. The NB part is:
      d^2/deta^2 [ sum_j Y*log(mu) - (Y+phi)*log(mu+phi) ]
    where mu = mu* * exp(eta).

    Let w = mu*_ij * omega = mu_ij.  Then:
      d/deta   = sum_j [ Y_ij - (Y_ij + phi) * w/(w+phi) ]
      d^2/deta^2 = sum_j [ -(Y_ij + phi) * w * phi / (w+phi)^2 ]
    Prior part: d^2/deta^2 [ alpha*eta - lam*exp(eta) ] = -lam * exp(eta)

    Returns
    -------
    (P,) — the diagonal Hessian d^2h/d(eta_ig)^2  (should be negative).
    """
    omega_i = torch.exp(torch.clamp(eta_i, min=-20.0, max=20.0))
    mu_ij = mu_star_i * omega_i.unsqueeze(0)  # (n_i, P)
    mu_ij = mu_ij.clamp(min=EPS)

    Y_f = Y_i.float()
    phi_u = phi.unsqueeze(0)  # (1, P)

    # Per-cell second derivative of NB part w.r.t. eta
    denom = (mu_ij + phi_u).clamp(min=EPS)
    d2_nb_per_cell = -(Y_f + phi_u) * mu_ij * phi_u / (denom * denom)
    d2_nb = d2_nb_per_cell.sum(dim=0)  # (P,)

    # Prior second derivative
    d2_prior = -lam * omega_i  # (P,)

    return d2_nb + d2_prior  # (P,), should be < 0


def laplace_correction(
    data,  # PrismData
    model,  # PrismModel
    eta: Tensor,
    phi: Tensor,
    alpha: Tensor,
    lam: Tensor,
) -> Tensor:
    """Laplace correction = -0.5 * sum_{i,g} log|-d^2h/d(eta_{ig})^2|.

    This is the *profile* h-likelihood adjustment for (sigma^2, phi).
    The sum is over subjects and genes.

    Parameters
    ----------
    data : PrismData
    model : PrismModel
    eta : (S, P) — eta[s, g] = log omega for subject s, gene g.
    phi, alpha, lam : (P,)

    Returns
    -------
    scalar — the Laplace correction term.
    """
    correction = torch.zeros(model.n_genes, device=data.device)

    for s in range(data.n_subjects):
        mask = data.cells_for_subject(s)
        if mask.sum() == 0:
            continue

        Y_s = data.Y[mask]
        X_s = data.X[mask].to(model.beta.dtype)
        log_pi_s = data.log_pi[mask].to(model.beta.dtype)

        # mu* without random effect
        eta_base = X_s @ model.beta.T + log_pi_s.unsqueeze(1)
        mu_star_s = clamp_exp(eta_base)

        h_diag = _hl_eta_hessian_diag(Y_s, mu_star_s, eta[s], phi, alpha, lam)

        # -0.5 * log(|h_diag|)  (h_diag should be negative → abs)
        correction = correction + (-0.5) * safe_log((-h_diag).clamp(min=EPS))

    return correction.sum()


def sigma2_needs_hl(sigma2: Tensor, threshold: float = 0.5) -> Tensor:
    """Boolean mask: True for genes where sigma^2 exceeds the HL threshold.

    The NEBULA paper (He et al. 2021) recommends using HL when sigma^2 >= 1.0.
    In practice, the LN approximation degrades gradually starting around
    sigma^2 ~ 0.5.  We default to 0.5 for a conservative switch.

    Parameters
    ----------
    sigma2 : (P,) — estimated per-gene subject variance.
    threshold : float — switch point (default 0.5).

    Returns
    -------
    (P,) bool tensor.
    """
    return sigma2 > threshold
