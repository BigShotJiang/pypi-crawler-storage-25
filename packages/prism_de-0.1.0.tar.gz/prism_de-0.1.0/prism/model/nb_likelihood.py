"""Negative-binomial log-likelihood and NEBULA-LN approximate likelihood.

All functions are pure PyTorch, operate on GPU, and are vectorized over
genes (dim P) and cells (dim N).

Key equations from the paper:
    NB log-pmf:  log p(y; mu, phi)
        = lgamma(y+phi) - lgamma(phi) - lgamma(y+1)
          + phi*log(phi/(mu+phi)) + y*log(mu/(mu+phi))

    NEBULA-LN approximate log-likelihood for subject i:
        tilde{l}_i(beta, sigma2, phi) =
            alpha*log(lambda)
            + lgamma(T_i + alpha) - lgamma(alpha)
            + sum_j x_{ij}*log(mu*_{ij})
            - (T_i + alpha)*log(lambda + sum_j mu*_{ij})
            + sum_j [ phi*log(phi)
                     + lgamma(x_{ij} + phi) - lgamma(phi)
                     - (x_{ij} + phi)*log(phi + w_i*mu*_{ij})
                     + w_i*mu*_{ij} ]

    where:
        T_i = sum_j x_{ij}
        mu*_{ij} = exp(X_{ij}^T beta + log(pi_{ij}))
        alpha = 1 / (exp(sigma2) - 1)
        lambda = 1 / (exp(sigma2/2) * (exp(sigma2) - 1))
        w_i = (T_i + alpha) / (lambda + sum_j mu*_{ij})
"""

from __future__ import annotations

import torch
from torch import Tensor

from ..utils.numerical import EPS, LOG_EPS, LOG_MAX, safe_log, batch_lgamma


def nb_log_pmf(y: Tensor, mu: Tensor, phi: Tensor) -> Tensor:
    """Vectorized negative-binomial log-probability mass function.

    Parameters
    ----------
    y : (...) int or float tensor — observed counts.
    mu : (...) float tensor — mean parameter (broadcastable with y).
    phi : (...) float tensor — dispersion/shape parameter
        (higher phi = less overdispersion). Broadcastable with y.

    Returns
    -------
    (...) float tensor — log p(y; mu, phi).

    Notes
    -----
    For y = 0 (common in scRNA-seq), the formula simplifies to
        phi * log(phi / (mu + phi))
    which avoids lgamma calls.  We use a branch-free implementation that
    handles the general case correctly even for y = 0.
    """
    dtype = mu.dtype if mu.is_floating_point() else torch.float32
    y_f = y.to(dtype)
    phi = phi.to(dtype)
    mu = torch.clamp(mu.to(dtype), min=EPS)

    # Log-gamma terms
    ll = (
        torch.lgamma(y_f + phi)
        - torch.lgamma(phi)
        - torch.lgamma(y_f + 1.0)
    )
    # Log-ratio terms (numerically stable)
    log_denom = safe_log(mu + phi)
    ll = ll + phi * (safe_log(phi) - log_denom)
    ll = ll + y_f * (safe_log(mu) - log_denom)

    return ll


def gamma_params_from_sigma2(log_sigma2: Tensor) -> tuple[Tensor, Tensor]:
    """Convert log(sigma^2) to the Gamma(alpha, lambda) parameterization.

    alpha = 1 / (exp(sigma2) - 1)
    lambda = 1 / (exp(sigma2/2) * (exp(sigma2) - 1))

    Parameters
    ----------
    log_sigma2 : (P,) — log subject-level variance in *unconstrained* space.
        We apply softplus to get sigma2 > 0.

    Returns
    -------
    alpha : (P,) — shape of the Gamma RE prior.
    lam : (P,) — rate of the Gamma RE prior.
    """
    sigma2 = torch.nn.functional.softplus(log_sigma2).clamp(min=EPS)
    exp_s2 = torch.exp(torch.clamp(sigma2, max=20.0))
    denom = (exp_s2 - 1.0).clamp(min=EPS)
    alpha = 1.0 / denom
    exp_s2_half = torch.exp(torch.clamp(sigma2 / 2.0, max=20.0))
    lam = 1.0 / (exp_s2_half * denom).clamp(min=EPS)
    return alpha, lam


def compute_omega_bar(
    Y_i: Tensor, mu_star_i: Tensor, alpha: Tensor, lam: Tensor
) -> Tensor:
    """Posterior mean of subject random effect for subject *i*.

    omega_bar_i = (sum_j Y_{ij} + alpha) / (lambda + sum_j mu*_{ij})

    Parameters
    ----------
    Y_i : (n_i, P) int/float — counts for subject i.
    mu_star_i : (n_i, P) float — mu* for subject i.
    alpha, lam : (P,) — Gamma prior parameters.

    Returns
    -------
    (P,) — posterior mean omega_bar for each gene.
    """
    sum_y = Y_i.float().sum(dim=0)        # (P,)
    sum_mu = mu_star_i.sum(dim=0)          # (P,)
    omega = (sum_y + alpha) / (lam + sum_mu).clamp(min=EPS)
    return omega


def ln_approx_loglik(
    Y_i: Tensor,
    mu_star_i: Tensor,
    alpha: Tensor,
    lam: Tensor,
    phi: Tensor,
) -> Tensor:
    """NEBULA-LN approximate log-likelihood for one subject.

    Parameters
    ----------
    Y_i : (n_i, P) counts for subject i.
    mu_star_i : (n_i, P) mu* = exp(X' beta + log pi).
    alpha, lam, phi : (P,) per-gene parameters.

    Returns
    -------
    (P,) — per-gene approximate log-likelihood contribution of subject i.
    """
    Y_f = Y_i.float()
    n_i = Y_i.shape[0]

    T_i = Y_f.sum(dim=0)                         # (P,)
    sum_mu = mu_star_i.sum(dim=0).clamp(min=EPS)  # (P,)
    w_i = (T_i + alpha) / (lam + sum_mu).clamp(min=EPS)  # (P,)

    # Term 1: alpha * log(lambda) + lgamma(T_i + alpha) - lgamma(alpha)
    term1 = (
        alpha * safe_log(lam)
        + torch.lgamma(T_i + alpha)
        - torch.lgamma(alpha)
    )

    # Term 2: sum_j x_{ij} * log(mu*_{ij})
    term2 = (Y_f * safe_log(mu_star_i)).sum(dim=0)  # (P,)

    # Term 3: -(T_i + alpha) * log(lambda + sum_j mu*_{ij})
    term3 = -(T_i + alpha) * safe_log(lam + sum_mu)

    # Term 4: per-cell NB dispersion correction (sum over j)
    #   phi*log(phi) + lgamma(x+phi) - lgamma(phi) - (x+phi)*log(phi+w*mu*) + w*mu*
    log_phi = safe_log(phi)
    phi_logphi = phi * log_phi  # (P,), broadcast over j
    cell_terms = (
        phi_logphi.unsqueeze(0)                                              # (1, P)
        + torch.lgamma(Y_f + phi.unsqueeze(0))                              # (n_i, P)
        - torch.lgamma(phi).unsqueeze(0)                                     # (1, P)
        - (Y_f + phi.unsqueeze(0)) * safe_log(phi.unsqueeze(0) + w_i.unsqueeze(0) * mu_star_i)
        + w_i.unsqueeze(0) * mu_star_i
    )
    term4 = cell_terms.sum(dim=0)  # (P,)

    return term1 + term2 + term3 + term4


def ln_approx_loglik_weighted(
    Y_i: Tensor,
    mu_star_d0_i: Tensor,
    mu_star_d1_i: Tensor,
    alpha: Tensor,
    lam: Tensor,
    phi: Tensor,
    q_i: Tensor,
) -> Tensor:
    """Weighted NEBULA-LN log-likelihood for one subject in the EM M-step.

    Computes the proper Q-function:
        Q_i = sum_j [ q_ij * ell_LN(Y; mu_d1) + (1 - q_ij) * ell_LN(Y; mu_d0) ]

    by evaluating the LN likelihood separately under d=0 and d=1 and
    mixing with q-weights.  This avoids Jensen's approximation.

    Parameters
    ----------
    Y_i : (n_i, P) counts.
    mu_star_d0_i, mu_star_d1_i : (n_i, P) mu* under d=0 and d=1.
    alpha, lam, phi : (P,) per-gene params.
    q_i : (n_i,) cell-level disease posteriors.

    Returns
    -------
    (P,) — per-gene weighted LL contribution of subject i.
    """
    # Evaluate LN log-likelihood under each disease state separately,
    # then weight by cell-level posteriors q_ij.
    # The LN likelihood is subject-level but depends on per-cell mu*,
    # so we compute separate "virtual subjects" under d=0 and d=1.
    ll_d0 = ln_approx_loglik(Y_i, mu_star_d0_i, alpha, lam, phi)  # (P,)
    ll_d1 = ln_approx_loglik(Y_i, mu_star_d1_i, alpha, lam, phi)  # (P,)

    # Weight: average q across cells for this subject gives the
    # subject-level mixture weight.
    q_bar = q_i.mean()  # scalar — subject-level q
    return q_bar * ll_d1 + (1.0 - q_bar) * ll_d0
