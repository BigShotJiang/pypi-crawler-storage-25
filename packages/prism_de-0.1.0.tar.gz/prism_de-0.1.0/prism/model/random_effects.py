"""Random-effect utilities: Gamma parameterization and posterior moments.

The NEBULA model places a Gamma prior on subject-level random effects:
    omega_i ~ Gamma(alpha, lambda)
where
    alpha = 1 / (exp(sigma^2) - 1)
    lambda = 1 / (exp(sigma^2/2) * (exp(sigma^2) - 1))

The posterior mean (conditional on data) is:
    omega_bar_i = (sum_j Y_{ij} + alpha) / (lambda + sum_j mu*_{ij})
"""

from __future__ import annotations

import torch
from torch import Tensor

from ..utils.numerical import EPS, softplus


def gamma_params_from_sigma2(log_sigma2: Tensor) -> tuple[Tensor, Tensor]:
    """Convert unconstrained log_sigma2 -> (alpha, lambda) for the Gamma RE.

    Parameters
    ----------
    log_sigma2 : (P,) — unconstrained parameter.  softplus is applied internally.

    Returns
    -------
    alpha : (P,) Gamma shape.
    lam   : (P,) Gamma rate.
    """
    sigma2 = softplus(log_sigma2).clamp(min=EPS)
    exp_s2 = torch.exp(torch.clamp(sigma2, max=20.0))
    denom = (exp_s2 - 1.0).clamp(min=EPS)
    alpha = 1.0 / denom
    exp_s2_half = torch.exp(torch.clamp(sigma2 / 2.0, max=20.0))
    lam = 1.0 / (exp_s2_half * denom).clamp(min=EPS)
    return alpha, lam


def gamma_posterior_mean(
    Y_i: Tensor,
    mu_star_i: Tensor,
    alpha: Tensor,
    lam: Tensor,
) -> Tensor:
    """Posterior mean of the subject random effect omega_bar.

    omega_bar_i = (sum_j Y_{ij} + alpha) / (lambda + sum_j mu*_{ij})

    Parameters
    ----------
    Y_i : (n_i, P) — counts for subject i.
    mu_star_i : (n_i, P) — mu* for subject i.
    alpha : (P,) — Gamma shape.
    lam : (P,) — Gamma rate.

    Returns
    -------
    (P,) — posterior mean for each gene.
    """
    sum_y = Y_i.float().sum(dim=0)
    sum_mu = mu_star_i.sum(dim=0)
    return (sum_y + alpha) / (lam + sum_mu).clamp(min=EPS)


def gamma_posterior_variance(
    Y_i: Tensor,
    mu_star_i: Tensor,
    alpha: Tensor,
    lam: Tensor,
) -> Tensor:
    """Posterior variance of subject RE under the Gamma conjugate model.

    Var[omega_i | Y] = (sum_j Y_{ij} + alpha) / (lambda + sum_j mu*_{ij})^2

    Returns
    -------
    (P,)
    """
    sum_y = Y_i.float().sum(dim=0)
    sum_mu = mu_star_i.sum(dim=0)
    denom = (lam + sum_mu).clamp(min=EPS)
    return (sum_y + alpha) / (denom * denom)
