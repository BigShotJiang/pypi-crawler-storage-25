"""Context encoders: map context covariates Z to per-cell, per-gene effects Delta.

Three variants:
    LinearEncoder   — Delta_g(z) = theta_g^T z       (P × K2 params)
    ConstantEncoder — Delta_g    = theta_g             (P params)
    MLPEncoder      — shared backbone, gene-specific heads
"""

from __future__ import annotations

from typing import Optional

import torch
from torch import Tensor, nn


class LinearEncoder(nn.Module):
    """Linear encoder: Delta_g(z) = theta_g^T z.

    Parameters
    ----------
    n_genes : int (P)
    n_context : int (K2)
    """

    def __init__(self, n_genes: int, n_context: int):
        super().__init__()
        self.n_genes = n_genes
        self.n_context = n_context
        # theta: (P, K2) — each gene has its own K2-dim weight vector
        self.theta = nn.Parameter(torch.zeros(n_genes, n_context))

    def forward(self, z: Tensor, theta: Optional[Tensor] = None) -> Tensor:
        """Compute Delta for all cells.

        Parameters
        ----------
        z : (N, K2) context covariates.
        theta : optional override for self.theta (used when optimizing externally).

        Returns
        -------
        (N, P) — per-cell, per-gene effect sizes.
        """
        t = theta if theta is not None else self.theta
        return z @ t.T  # (N, K2) @ (K2, P) = (N, P)


class ConstantEncoder(nn.Module):
    """Constant encoder: Delta_g = theta_g (scalar per gene).

    Parameters
    ----------
    n_genes : int (P)
    """

    def __init__(self, n_genes: int):
        super().__init__()
        self.theta = nn.Parameter(torch.zeros(n_genes))

    def forward(self, z: Tensor, theta: Optional[Tensor] = None) -> Tensor:
        """Return constant Delta for each gene, broadcast to all cells.

        Parameters
        ----------
        z : (N, K2) — context (unused, but kept for API consistency).

        Returns
        -------
        (N, P)
        """
        t = theta if theta is not None else self.theta
        return t.unsqueeze(0).expand(z.shape[0], -1)  # (N, P)


class MLPEncoder(nn.Module):
    """MLP encoder: shared backbone, gene-specific linear heads.

    Delta_g(z) = w2_g^T sigma(W1 z + b1)

    Parameters
    ----------
    n_context : int (K2)
    d_hidden : int — hidden dimension.
    n_genes : int (P)
    n_layers : int — number of hidden layers in backbone.
    """

    def __init__(
        self,
        n_context: int,
        d_hidden: int,
        n_genes: int,
        n_layers: int = 1,
    ):
        super().__init__()
        layers: list[nn.Module] = []
        in_dim = n_context
        for _ in range(n_layers):
            layers.append(nn.Linear(in_dim, d_hidden))
            layers.append(nn.ReLU())
            in_dim = d_hidden
        self.backbone = nn.Sequential(*layers)
        self.heads = nn.Linear(d_hidden, n_genes)

    def forward(self, z: Tensor, theta: Optional[Tensor] = None) -> Tensor:
        """Compute Delta for all cells via MLP.

        Parameters
        ----------
        z : (N, K2)
        theta : unused (MLP params live inside the module).

        Returns
        -------
        (N, P)
        """
        h = self.backbone(z)    # (N, d_h)
        return self.heads(h)    # (N, P)


class NoneEncoder(nn.Module):
    """No encoder: Delta = 0.  Equivalent to standard NEBULA."""

    def forward(self, z: Tensor, theta: Optional[Tensor] = None) -> Tensor:
        return torch.zeros(z.shape[0], 1, device=z.device, dtype=z.dtype)


def build_encoder(
    encoder_type: str,
    n_genes: int,
    n_context: int,
    d_hidden: int = 64,
    n_layers: int = 1,
) -> nn.Module:
    """Build an encoder from a string specification.

    Parameters
    ----------
    encoder_type : one of {"linear", "reg", "constant", "const", "mlp", "nnet", "none"}.
    n_genes : P
    n_context : K2
    d_hidden : MLP hidden dimension (only used for "mlp"/"nnet").
    n_layers : number of hidden layers for MLP.
    """
    enc = encoder_type.lower().strip()
    if enc in ("linear", "reg"):
        return LinearEncoder(n_genes, n_context)
    elif enc in ("constant", "const"):
        return ConstantEncoder(n_genes)
    elif enc in ("mlp", "nnet"):
        return MLPEncoder(n_context, d_hidden, n_genes, n_layers)
    elif enc in ("none", "no"):
        return NoneEncoder()
    else:
        raise ValueError(f"Unknown encoder type: {encoder_type!r}")
