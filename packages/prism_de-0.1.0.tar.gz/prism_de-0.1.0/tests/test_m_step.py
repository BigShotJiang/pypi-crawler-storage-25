"""Unit tests for the M-step: parameter optimization given q."""

import pytest
import torch

from prism.data.simulation import generate_prism_data
from prism.model.prism_model import PrismModel
from prism.inference.m_step import m_step_objective, run_m_step


@pytest.fixture
def simple_data():
    """Generate simple data with rho=1 (no latent states)."""
    data, gt = generate_prism_data(
        n_subjects=20,
        n_cells_per_subject=50,
        n_genes=5,
        rho=1.0,  # No latent states -> all disease cells affected
        sigma2=0.1,
        phi=10.0,
        seed=42,
        device="cpu",
    )
    return data, gt


class TestMStepObjective:
    """Tests for the M-step objective function."""

    def test_returns_scalar(self, simple_data):
        data, gt = simple_data
        model = PrismModel(
            n_genes=data.n_genes,
            n_covars=data.n_covars,
            n_context=data.n_context,
            n_disease_subjects=data.n_disease_subjects,
            n_cells=data.n_cells,
            encoder_type="linear",
            device="cpu",
        )
        model.initialize_from_data(data)

        loss = m_step_objective(data, model)
        assert loss.dim() == 0, "M-step objective should be a scalar"
        assert not torch.isnan(loss), "M-step objective is NaN"

    def test_not_inf(self, simple_data):
        data, gt = simple_data
        model = PrismModel(
            n_genes=data.n_genes,
            n_covars=data.n_covars,
            n_context=data.n_context,
            n_disease_subjects=data.n_disease_subjects,
            n_cells=data.n_cells,
            encoder_type="linear",
            device="cpu",
        )
        model.initialize_from_data(data)

        loss = m_step_objective(data, model)
        assert not torch.isinf(loss), "M-step objective is Inf"


class TestMStepOptimization:
    """Tests for M-step optimization (Adam fallback for speed in tests)."""

    def test_loss_decreases(self, simple_data):
        """M-step optimization should decrease the loss."""
        data, gt = simple_data
        model = PrismModel(
            n_genes=data.n_genes,
            n_covars=data.n_covars,
            n_context=data.n_context,
            n_disease_subjects=data.n_disease_subjects,
            n_cells=data.n_cells,
            encoder_type="linear",
            device="cpu",
        )
        model.initialize_from_data(data)

        loss_before = m_step_objective(data, model).item()

        info = run_m_step(
            data, model,
            max_iter=50,
            optimizer_type="adam",
            lr=0.01,
        )

        loss_after = m_step_objective(data, model).item()
        assert loss_after <= loss_before + 1e-3, \
            f"Loss did not decrease: {loss_before:.4f} -> {loss_after:.4f}"

    def test_recovers_beta_with_rho1(self, simple_data):
        """With rho=1, the M-step should recover beta approximately."""
        data, gt = simple_data
        model = PrismModel(
            n_genes=data.n_genes,
            n_covars=data.n_covars,
            n_context=data.n_context,
            n_disease_subjects=data.n_disease_subjects,
            n_cells=data.n_cells,
            encoder_type="linear",
            device="cpu",
        )
        model.initialize_from_data(data)

        run_m_step(
            data, model,
            max_iter=200,
            optimizer_type="adam",
            lr=0.01,
        )

        # Check intercept recovery (column 0)
        beta0_hat = model.beta0.detach()
        beta0_true = gt["beta0_true"]

        # At least the sign should be correct for most genes
        intercept_corr = torch.corrcoef(
            torch.stack([beta0_hat[:, 0], beta0_true[:, 0]])
        )[0, 1]
        assert intercept_corr > 0.5, f"Intercept correlation = {intercept_corr:.3f}"

    def test_gradient_finite_difference(self, simple_data):
        """Compare M-step gradient to finite-difference approximation."""
        data, gt = simple_data
        model = PrismModel(
            n_genes=data.n_genes,
            n_covars=data.n_covars,
            n_context=data.n_context,
            n_disease_subjects=data.n_disease_subjects,
            n_cells=data.n_cells,
            encoder_type="linear",
            device="cpu",
            dtype=torch.float64,
        )
        model.initialize_from_data(data)

        # Compute analytic gradient
        loss = m_step_objective(data, model)
        loss.backward()
        grad_beta = model.beta0.grad.clone()

        # Finite-difference gradient for a few elements
        eps = 1e-5
        for i in range(min(3, data.n_genes)):
            for j in range(min(2, data.n_covars)):
                model.zero_grad()
                old_val = model.beta0.data[i, j].item()

                model.beta0.data[i, j] = old_val + eps
                loss_plus = m_step_objective(data, model).item()

                model.beta0.data[i, j] = old_val - eps
                loss_minus = m_step_objective(data, model).item()

                model.beta0.data[i, j] = old_val

                fd_grad = (loss_plus - loss_minus) / (2 * eps)
                analytic_grad = grad_beta[i, j].item()

                # Allow 10% relative error
                if abs(fd_grad) > 1e-6:
                    rel_err = abs(fd_grad - analytic_grad) / abs(fd_grad)
                    assert rel_err < 0.2, \
                        f"Gradient mismatch at [{i},{j}]: FD={fd_grad:.6f}, " \
                        f"analytic={analytic_grad:.6f}, rel_err={rel_err:.3f}"
