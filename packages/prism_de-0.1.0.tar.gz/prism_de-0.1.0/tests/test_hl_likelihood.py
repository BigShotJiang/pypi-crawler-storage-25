"""Tests for the NEBULA-HL likelihood implementation.

Tests:
  1. Gradient check: autograd vs finite differences for hl_loglik_subject.
  2. HL ≈ LN for small sigma^2: when sigma^2 is tiny, both likelihoods
     should give similar parameter estimates.
  3. HL handles large sigma^2 without NaN/Inf.
  4. Full EM convergence with HL mode on a tiny simulation.
  5. sigma2_needs_hl threshold logic.
"""

from __future__ import annotations

import torch
import numpy as np
import pytest

# Make sure the package is importable
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from prism.model.hl_likelihood import (
    hl_loglik_subject,
    hl_loglik_weighted,
    _hl_eta_hessian_diag,
    sigma2_needs_hl,
)
from prism.model.nb_likelihood import ln_approx_loglik, nb_log_pmf
from prism.model.random_effects import gamma_params_from_sigma2
from prism.utils.numerical import EPS, softplus


DEVICE = "cpu"
DTYPE = torch.float64  # use float64 for gradient checks


# ======================================================================
# Fixtures
# ======================================================================


def _make_simple_data(n_cells: int = 20, n_genes: int = 5, seed: int = 42):
    """Create simple synthetic data for HL likelihood tests."""
    rng = np.random.RandomState(seed)
    Y = torch.tensor(rng.poisson(5, (n_cells, n_genes)), dtype=DTYPE, device=DEVICE)
    mu_star = torch.tensor(
        rng.exponential(5, (n_cells, n_genes)), dtype=DTYPE, device=DEVICE
    ).clamp(min=EPS)
    eta = torch.tensor(rng.randn(n_genes) * 0.3, dtype=DTYPE, device=DEVICE)
    log_sigma2 = torch.tensor(rng.randn(n_genes) * 0.5, dtype=DTYPE, device=DEVICE)
    alpha, lam = gamma_params_from_sigma2(log_sigma2)
    phi = softplus(torch.tensor(rng.randn(n_genes) + 2.0, dtype=DTYPE, device=DEVICE))
    return Y, mu_star, eta, phi, alpha, lam, log_sigma2


# ======================================================================
# Test 1: Gradient check
# ======================================================================


def test_hl_gradient_wrt_eta():
    """Check that autograd gradients match finite differences for eta."""
    Y, mu_star, eta, phi, alpha, lam, _ = _make_simple_data()
    eta = eta.clone().requires_grad_(True)

    ll = hl_loglik_subject(Y, mu_star, eta, phi, alpha, lam).sum()
    (grad_auto,) = torch.autograd.grad(ll, eta)

    # Finite differences
    eps = 1e-5
    grad_fd = torch.zeros_like(eta)
    for g in range(eta.shape[0]):
        eta_p = eta.detach().clone()
        eta_p[g] += eps
        ll_p = hl_loglik_subject(Y, mu_star, eta_p, phi, alpha, lam).sum()
        eta_m = eta.detach().clone()
        eta_m[g] -= eps
        ll_m = hl_loglik_subject(Y, mu_star, eta_m, phi, alpha, lam).sum()
        grad_fd[g] = (ll_p - ll_m) / (2 * eps)

    assert torch.allclose(grad_auto, grad_fd, atol=1e-4, rtol=1e-3), (
        f"max diff = {(grad_auto - grad_fd).abs().max():.2e}"
    )


def test_hl_gradient_wrt_mu_star():
    """Check gradients w.r.t. mu_star pass through correctly."""
    Y, mu_star, eta, phi, alpha, lam, _ = _make_simple_data()
    mu_star = mu_star.clone().requires_grad_(True)

    ll = hl_loglik_subject(Y, mu_star, eta, phi, alpha, lam).sum()
    (grad,) = torch.autograd.grad(ll, mu_star)
    assert torch.isfinite(grad).all(), "Non-finite gradients w.r.t. mu_star"
    assert grad.shape == mu_star.shape


# ======================================================================
# Test 2: HL ≈ LN for small sigma^2
# ======================================================================


def test_hl_agrees_with_ln_small_sigma2():
    """For very small sigma^2, HL with optimal eta ≈ LN likelihood.

    When sigma^2 → 0, the random effect is concentrated at 1 (eta ≈ 0),
    and both formulations should give similar log-likelihoods.
    """
    n_cells, n_genes = 30, 3
    rng = np.random.RandomState(123)
    Y = torch.tensor(rng.poisson(10, (n_cells, n_genes)), dtype=DTYPE, device=DEVICE)

    # Very small sigma^2 → alpha very large, omega ≈ 1
    log_sigma2 = torch.full((n_genes,), -3.0, dtype=DTYPE, device=DEVICE)
    alpha, lam = gamma_params_from_sigma2(log_sigma2)
    phi = torch.full((n_genes,), 10.0, dtype=DTYPE, device=DEVICE)
    mu_star = torch.ones(n_cells, n_genes, dtype=DTYPE, device=DEVICE) * 8.0

    # LN likelihood
    ll_ln = ln_approx_loglik(Y, mu_star, alpha, lam, phi)  # (P,)

    # HL likelihood with eta=0 (omega=1)
    eta = torch.zeros(n_genes, dtype=DTYPE, device=DEVICE)
    ll_hl = hl_loglik_subject(Y, mu_star, eta, phi, alpha, lam)  # (P,)

    # They won't be exactly equal (different formulations), but should be
    # in the same ballpark for small sigma^2
    ratio = ll_hl / ll_ln.clamp(min=-1e10)
    assert (ratio - 1.0).abs().max() < 0.3, (
        f"HL and LN likelihoods differ too much for small sigma^2: "
        f"ratio range [{ratio.min():.3f}, {ratio.max():.3f}]"
    )


# ======================================================================
# Test 3: HL handles large sigma^2
# ======================================================================


def test_hl_large_sigma2_no_nan():
    """HL should be numerically stable even for large sigma^2."""
    Y, mu_star, _, phi, _, _, _ = _make_simple_data()

    # Large sigma^2 — this is where LN approximation breaks
    log_sigma2 = torch.full((5,), 2.0, dtype=DTYPE, device=DEVICE)  # sigma^2 ≈ 7.4
    alpha, lam = gamma_params_from_sigma2(log_sigma2)
    eta = torch.randn(5, dtype=DTYPE, device=DEVICE) * 1.5  # larger random effects

    ll = hl_loglik_subject(Y, mu_star, eta, phi, alpha, lam)
    assert torch.isfinite(ll).all(), f"Non-finite HL likelihood for large sigma^2: {ll}"


def test_hl_large_sigma2_gradient_finite():
    """Gradients should be finite even for large sigma^2."""
    Y, mu_star, _, phi, _, _, _ = _make_simple_data()
    log_sigma2 = torch.full((5,), 2.0, dtype=DTYPE, device=DEVICE)
    alpha, lam = gamma_params_from_sigma2(log_sigma2)
    eta = torch.randn(5, dtype=DTYPE, device=DEVICE, requires_grad=True) * 1.5

    ll = hl_loglik_subject(Y, mu_star, eta, phi, alpha, lam).sum()
    (grad,) = torch.autograd.grad(ll, eta)
    assert torch.isfinite(grad).all(), f"Non-finite gradient for large sigma^2: {grad}"


# ======================================================================
# Test 4: Hessian diagonal check
# ======================================================================


def test_hessian_diagonal_negative():
    """The Hessian d^2h/deta^2 should be negative (concave in eta)."""
    Y, mu_star, eta, phi, alpha, lam, _ = _make_simple_data()
    h_diag = _hl_eta_hessian_diag(Y, mu_star, eta, phi, alpha, lam)
    assert (h_diag < 0).all(), f"Hessian diagonal should be negative: {h_diag}"


def test_hessian_diagonal_matches_autograd():
    """Analytical Hessian diagonal should match autograd."""
    Y, mu_star, eta, phi, alpha, lam, _ = _make_simple_data()

    # Analytical
    h_diag_ana = _hl_eta_hessian_diag(Y, mu_star, eta, phi, alpha, lam)

    # Autograd
    eta_req = eta.clone().requires_grad_(True)
    ll = hl_loglik_subject(Y, mu_star, eta_req, phi, alpha, lam)
    # Get per-gene second derivative
    h_diag_auto = torch.zeros_like(eta)
    for g in range(eta.shape[0]):
        (g1,) = torch.autograd.grad(ll[g], eta_req, create_graph=True)
        (g2,) = torch.autograd.grad(g1[g], eta_req, retain_graph=(g < eta.shape[0] - 1))
        h_diag_auto[g] = g2[g]

    assert torch.allclose(h_diag_ana, h_diag_auto, atol=1e-4, rtol=1e-3), (
        f"max diff = {(h_diag_ana - h_diag_auto).abs().max():.2e}\n"
        f"analytical: {h_diag_ana}\nautograd:   {h_diag_auto}"
    )


# ======================================================================
# Test 5: sigma2_needs_hl threshold
# ======================================================================


def test_sigma2_needs_hl_threshold():
    """Test that the threshold function works correctly."""
    sigma2 = torch.tensor([0.1, 0.3, 0.5, 0.8, 1.2, 2.0])

    mask_05 = sigma2_needs_hl(sigma2, threshold=0.5)
    assert mask_05.tolist() == [False, False, False, True, True, True]

    mask_10 = sigma2_needs_hl(sigma2, threshold=1.0)
    assert mask_10.tolist() == [False, False, False, False, True, True]


# ======================================================================
# Test 6: Weighted HL (EM M-step version)
# ======================================================================


def test_weighted_hl_reduces_to_unweighted():
    """When q=1, weighted HL with d1=d0 should equal unweighted HL."""
    Y, mu_star, eta, phi, alpha, lam, _ = _make_simple_data()
    q = torch.ones(Y.shape[0], dtype=DTYPE, device=DEVICE)

    ll_unweighted = hl_loglik_subject(Y, mu_star, eta, phi, alpha, lam)
    ll_weighted = hl_loglik_weighted(
        Y, mu_star, mu_star, eta, phi, alpha, lam, q
    )

    assert torch.allclose(ll_unweighted, ll_weighted, atol=1e-6), (
        f"Weighted with q=1 should equal unweighted: "
        f"max diff = {(ll_unweighted - ll_weighted).abs().max():.2e}"
    )


# ======================================================================
# Test 7: Full mini EM with HL mode
# ======================================================================


def test_hl_em_convergence_mini():
    """Run a tiny PRISM EM with HL mode and check it converges."""
    from prism.data.simulation import generate_prism_data
    from prism.inference.em_loop import PRISMTrainer, PRISMConfig

    # Tiny simulation
    data, _gt = generate_prism_data(
        n_subjects=6, n_cells_per_subject=15, n_genes=10,
        n_covars=2, n_context=1,
        sigma2=0.8,  # moderately high — HL should help
        seed=42, device=DEVICE,
    )

    config = PRISMConfig(
        n_genes=data.n_genes,
        n_covars=data.n_covars,
        n_context=data.n_context,
        encoder_type="linear",
        max_em_iter=8,
        min_em_iter=2,
        m_step_optimizer="adam",
        m_step_max_iter=100,
        m_step_lr=0.01,
        likelihood_mode="hl",
        wandb_enabled=False,
        verbose=False,
        device=str(DEVICE),
        dtype="float32",
    )

    trainer = PRISMTrainer(config)
    results = trainer.fit(data)

    # Check basic sanity
    assert results.em_iterations >= 2, "Should run at least 2 EM iterations"
    assert len(results.obs_loglik_trace) >= 2
    # Log-likelihood should generally increase (allow small decreases)
    diffs = np.diff(results.obs_loglik_trace)
    assert (diffs > -1e3).all(), (
        f"Log-likelihood decreased significantly: {diffs}"
    )
    # Parameters should be finite
    assert torch.isfinite(results.beta0_hat).all()
    assert torch.isfinite(results.sigma2_hat).all()
    assert torch.isfinite(results.phi_hat).all()


# ======================================================================
# Test 8: LN vs HL comparison on same data
# ======================================================================


def test_ln_vs_hl_similar_estimates_small_sigma():
    """For small sigma^2, LN and HL should give similar beta estimates."""
    from prism.data.simulation import generate_prism_data
    from prism.inference.em_loop import PRISMTrainer, PRISMConfig

    data, _gt = generate_prism_data(
        n_subjects=8, n_cells_per_subject=20, n_genes=8,
        n_covars=2, n_context=1,
        sigma2=0.1,  # small → LN should be fine
        seed=99, device=DEVICE,
    )

    common = dict(
        n_genes=data.n_genes, n_covars=data.n_covars, n_context=data.n_context,
        encoder_type="linear", max_em_iter=6, min_em_iter=2,
        m_step_optimizer="adam", m_step_max_iter=80, m_step_lr=0.01,
        wandb_enabled=False, verbose=False,
        device=str(DEVICE),
        dtype="float32",
    )

    results_ln = PRISMTrainer(PRISMConfig(likelihood_mode="ln", **common)).fit(data)
    results_hl = PRISMTrainer(PRISMConfig(likelihood_mode="hl", **common)).fit(data)

    # Beta estimates should be correlated
    corr = np.corrcoef(
        results_ln.beta0_hat[:, 0].cpu().numpy(),
        results_hl.beta0_hat[:, 0].cpu().numpy()
    )[0, 1]
    assert corr > 0.7, (
        f"LN and HL beta estimates should be correlated for small sigma^2, "
        f"got corr = {corr:.3f}"
    )


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
