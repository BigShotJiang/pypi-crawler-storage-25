"""Unit tests for NB log-likelihood and NEBULA-LN approximate likelihood."""

import pytest
import torch
import numpy as np
from scipy.stats import nbinom

from prism.model.nb_likelihood import (
    nb_log_pmf,
    ln_approx_loglik,
    compute_omega_bar,
    gamma_params_from_sigma2,
)


class TestNBLogPMF:
    """Tests for the negative-binomial log-PMF."""

    @pytest.fixture
    def random_inputs(self):
        torch.manual_seed(42)
        N, P = 100, 10
        y = torch.randint(0, 50, (N, P))
        mu = torch.rand(N, P) * 10.0 + 0.1
        phi = torch.rand(P) * 10.0 + 0.1
        return y, mu, phi

    def test_matches_scipy(self, random_inputs):
        """Compare nb_log_pmf to scipy.stats.nbinom.logpmf."""
        y, mu, phi = random_inputs

        # Our implementation
        log_p_ours = nb_log_pmf(y, mu, phi)

        # Scipy: NB parameterized as (n=phi, p=phi/(mu+phi))
        y_np = y.numpy()
        mu_np = mu.numpy()
        phi_np = phi.numpy()

        # Broadcast phi to (N, P)
        phi_broad = np.broadcast_to(phi_np, (y_np.shape[0], y_np.shape[1]))
        p_scipy = phi_broad / (mu_np + phi_broad)
        log_p_scipy = nbinom.logpmf(y_np, n=phi_broad, p=p_scipy)

        np.testing.assert_allclose(
            log_p_ours.numpy(), log_p_scipy, rtol=1e-4, atol=1e-6,
            err_msg="nb_log_pmf does not match scipy"
        )

    def test_zero_counts(self, random_inputs):
        """Verify correct handling of y=0 (common in scRNA-seq)."""
        _, mu, phi = random_inputs
        y_zero = torch.zeros_like(mu, dtype=torch.int32)

        log_p = nb_log_pmf(y_zero, mu, phi)

        # For y=0: log p = phi * log(phi / (mu + phi))
        expected = phi * torch.log(phi / (mu + phi))
        torch.testing.assert_close(log_p, expected, rtol=1e-4, atol=1e-6)

    def test_gradient_exists(self, random_inputs):
        """Check that gradients flow through nb_log_pmf."""
        y, mu, phi = random_inputs
        mu.requires_grad_(True)
        phi_param = phi.clone().requires_grad_(True)

        log_p = nb_log_pmf(y.float(), mu, phi_param)
        loss = log_p.sum()
        loss.backward()

        assert mu.grad is not None, "No gradient for mu"
        assert phi_param.grad is not None, "No gradient for phi"
        assert not torch.isnan(mu.grad).any(), "NaN in mu gradient"
        assert not torch.isnan(phi_param.grad).any(), "NaN in phi gradient"

    def test_gradcheck(self):
        """torch.autograd.gradcheck on nb_log_pmf."""
        y = torch.tensor([[5.0, 0.0, 10.0]], dtype=torch.float64)
        mu = torch.tensor([[2.0, 5.0, 3.0]], dtype=torch.float64, requires_grad=True)
        phi = torch.tensor([5.0, 10.0, 1.0], dtype=torch.float64, requires_grad=True)

        def fn(mu_, phi_):
            return nb_log_pmf(y, mu_, phi_).sum()

        assert torch.autograd.gradcheck(fn, (mu, phi), eps=1e-5, atol=1e-3)

    def test_output_shape(self, random_inputs):
        """Verify output shape matches input shape."""
        y, mu, phi = random_inputs
        log_p = nb_log_pmf(y, mu, phi)
        assert log_p.shape == y.shape

    def test_negative_log_prob(self, random_inputs):
        """All log probabilities should be <= 0."""
        y, mu, phi = random_inputs
        log_p = nb_log_pmf(y, mu, phi)
        assert (log_p <= 1e-6).all(), "Found positive log-probabilities"


class TestComputeOmegaBar:
    """Tests for posterior mean of subject random effects."""

    def test_basic(self):
        torch.manual_seed(42)
        n_i, P = 20, 5
        Y_i = torch.randint(0, 30, (n_i, P)).float()
        mu_star_i = torch.rand(n_i, P) * 5.0 + 0.1
        alpha = torch.ones(P) * 2.0
        lam = torch.ones(P) * 3.0

        omega = compute_omega_bar(Y_i, mu_star_i, alpha, lam)

        assert omega.shape == (P,)
        assert (omega > 0).all(), "omega_bar should be positive"

        # Manual computation
        sum_y = Y_i.sum(dim=0)
        sum_mu = mu_star_i.sum(dim=0)
        expected = (sum_y + alpha) / (lam + sum_mu)
        torch.testing.assert_close(omega, expected, rtol=1e-5, atol=1e-7)


class TestGammaParams:
    """Tests for sigma2 -> (alpha, lambda) conversion."""

    def test_positive(self):
        log_sigma2 = torch.tensor([0.0, -2.0, 1.0, 3.0])
        alpha, lam = gamma_params_from_sigma2(log_sigma2)
        assert (alpha > 0).all(), "alpha must be positive"
        assert (lam > 0).all(), "lambda must be positive"

    def test_mean_one(self):
        """For small sigma2, E[omega] = alpha/lambda ≈ 1."""
        log_sigma2 = torch.tensor([-5.0])  # sigma2 ≈ 0.007, very small
        alpha, lam = gamma_params_from_sigma2(log_sigma2)
        mean = alpha / lam
        assert abs(mean.item() - 1.0) < 0.05, f"E[omega] = {mean.item()}, expected ~1.0"


class TestLNApproxLoglik:
    """Tests for the NEBULA-LN approximate log-likelihood."""

    def test_runs_without_nan(self):
        torch.manual_seed(42)
        n_i, P = 30, 8
        Y_i = torch.randint(0, 20, (n_i, P))
        mu_star_i = torch.rand(n_i, P) * 5.0 + 0.1
        log_sigma2 = torch.zeros(P)
        alpha, lam = gamma_params_from_sigma2(log_sigma2)
        phi = torch.ones(P) * 5.0

        ll = ln_approx_loglik(Y_i, mu_star_i, alpha, lam, phi)

        assert ll.shape == (P,)
        assert not torch.isnan(ll).any(), "NaN in LN log-likelihood"
        assert not torch.isinf(ll).any(), "Inf in LN log-likelihood"
