"""Tests for evaluation metrics."""

import pytest
import torch

from prism.evaluation.metrics import compute_all_metrics, auc_binary


class TestAucBinary:
    def test_perfect_separation(self):
        scores = torch.tensor([0.1, 0.2, 0.8, 0.9])
        labels = torch.tensor([0, 0, 1, 1])
        assert auc_binary(scores, labels) == 1.0

    def test_random_auc_near_half(self):
        torch.manual_seed(42)
        scores = torch.rand(200)
        labels = (torch.rand(200) > 0.5).long()
        auc = auc_binary(scores, labels)
        assert 0.3 < auc < 0.7

    def test_single_class_returns_nan(self):
        """AUC is undefined when only one class is present."""
        import math
        scores = torch.tensor([0.1, 0.5, 0.9])
        labels = torch.tensor([0, 0, 0])
        auc = auc_binary(scores, labels)
        # sklearn returns nan or raises; our wrapper may return nan
        assert math.isnan(auc) or isinstance(auc, float)


class TestComputeAllMetrics:
    @pytest.fixture
    def mock_results_and_gt(self):
        n_cells, n_genes = 60, 8
        n_subjects = 6
        # Build a mock "results" dict
        results = {
            "q_hat": torch.rand(n_cells),
            "q_values": torch.rand(n_genes),
            "theta_hat": torch.randn(n_genes, 1),
            "beta0_hat": torch.randn(n_genes, 3),
            "rho_hat": torch.full((n_subjects // 2,), 0.5),
        }
        # Build a matching ground truth
        gt = {
            "d_true": (torch.rand(n_cells) > 0.5).float(),
            "gene_category": (["null"] * 3 + ["fixed_de"] * 3 + ["context_de"] * 2),
            "theta_true": torch.randn(n_genes, 1),
            "beta0_true": torch.randn(n_genes, 3),
            "rho_true": torch.full((n_subjects // 2,), 0.5),
        }
        return results, gt

    def test_returns_dict(self, mock_results_and_gt):
        results, gt = mock_results_and_gt
        metrics = compute_all_metrics(results, gt)
        assert isinstance(metrics, dict)

    def test_expected_keys(self, mock_results_and_gt):
        results, gt = mock_results_and_gt
        metrics = compute_all_metrics(results, gt)
        for key in ["power", "fpr", "theta_mse", "beta0_mse"]:
            assert key in metrics
