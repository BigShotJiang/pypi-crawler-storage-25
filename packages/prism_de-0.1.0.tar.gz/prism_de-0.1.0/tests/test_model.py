"""Tests for encoders and PrismModel."""

import pytest
import torch

from prism.model.encoders import (
    LinearEncoder,
    ConstantEncoder,
    MLPEncoder,
    NoneEncoder,
    build_encoder,
)
from prism.model.prism_model import PrismModel, PrismParams
from prism.data.simulation import generate_prism_data


# ── Encoder tests ──────────────────────────────────────────────────────


class TestLinearEncoder:
    def test_output_shape(self):
        enc = LinearEncoder(n_genes=10, n_context=3)
        z = torch.randn(20, 3)
        out = enc(z)
        assert out.shape == (20, 10)

    def test_parameter_count(self):
        enc = LinearEncoder(n_genes=10, n_context=3)
        assert enc.theta.shape == (10, 3)


class TestConstantEncoder:
    def test_output_shape(self):
        enc = ConstantEncoder(n_genes=5)
        z = torch.randn(12, 2)
        out = enc(z)
        assert out.shape == (12, 5)

    def test_constant_across_cells(self):
        enc = ConstantEncoder(n_genes=5)
        z = torch.randn(12, 2)
        out = enc(z)
        # All rows should be identical (context-independent)
        assert torch.allclose(out[0], out[1])


class TestMLPEncoder:
    def test_output_shape(self):
        enc = MLPEncoder(n_context=3, d_hidden=16, n_genes=10, n_layers=1)
        z = torch.randn(20, 3)
        out = enc(z)
        assert out.shape == (20, 10)


class TestNoneEncoder:
    def test_output_zero(self):
        enc = NoneEncoder()
        z = torch.randn(5, 2)
        out = enc(z)
        assert (out == 0).all()


class TestBuildEncoder:
    @pytest.mark.parametrize("enc_type,cls", [
        ("linear", LinearEncoder),
        ("reg", LinearEncoder),
        ("constant", ConstantEncoder),
        ("const", ConstantEncoder),
        ("mlp", MLPEncoder),
        ("nnet", MLPEncoder),
        ("none", NoneEncoder),
        ("no", NoneEncoder),
    ])
    def test_build_returns_correct_type(self, enc_type, cls):
        enc = build_encoder(enc_type, n_genes=4, n_context=2)
        assert isinstance(enc, cls)


# ── PrismModel tests ──────────────────────────────────────────────────


@pytest.fixture
def model_and_data():
    data, gt = generate_prism_data(
        n_subjects=8, n_cells_per_subject=20, n_genes=6,
        seed=42, device="cpu",
    )
    model = PrismModel(
        n_genes=data.n_genes,
        n_covars=data.n_covars,
        n_context=data.n_context,
        n_disease_subjects=data.n_disease_subjects,
        n_cells=data.n_cells,
        n_subjects=data.n_subjects,
        encoder_type="linear",
        device="cpu",
    )
    return model, data, gt


class TestPrismModel:
    def test_params_property(self, model_and_data):
        model, data, _ = model_and_data
        p = model.params
        assert isinstance(p, PrismParams)
        assert p.beta0.shape == (data.n_genes, data.n_covars)
        assert p.log_sigma2.shape == (data.n_genes,)
        assert p.log_phi.shape == (data.n_genes,)
        assert p.logit_rho.shape == (data.n_disease_subjects,)

    def test_sigma2_positive(self, model_and_data):
        model, _, _ = model_and_data
        assert (model.sigma2 > 0).all()

    def test_phi_positive(self, model_and_data):
        model, _, _ = model_and_data
        assert (model.phi > 0).all()

    def test_rho_in_01(self, model_and_data):
        model, _, _ = model_and_data
        assert (model.rho > 0).all()
        assert (model.rho < 1).all()

    def test_compute_delta_shape(self, model_and_data):
        model, data, _ = model_and_data
        delta = model.compute_delta(data.Z)
        assert delta.shape == (data.n_cells, data.n_genes)

    def test_compute_mu_star_shape(self, model_and_data):
        model, data, _ = model_and_data
        mu_star = model.compute_mu_star(data.X, data.log_pi, data.Z)
        assert mu_star.shape == (data.n_cells, data.n_genes)
        assert (mu_star > 0).all()

    def test_initialize_from_data(self, model_and_data):
        model, data, _ = model_and_data
        model.initialize_from_data(data)
        # After initialization, parameters should still be valid
        assert (model.sigma2 > 0).all()
        assert (model.phi > 0).all()
