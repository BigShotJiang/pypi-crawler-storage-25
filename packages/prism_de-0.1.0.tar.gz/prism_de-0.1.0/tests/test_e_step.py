"""Unit tests for the E-step: cell-level disease posterior computation."""

import pytest
import torch

from prism.data.simulation import generate_prism_data
from prism.model.prism_model import PrismModel
from prism.inference.e_step import e_step


@pytest.fixture
def perfect_setup():
    """Generate data and set model params to ground truth."""
    data, gt = generate_prism_data(
        n_subjects=20,
        n_cells_per_subject=50,
        n_genes=10,
        rho=0.6,
        sigma2=0.1,
        phi=10.0,
        seed=42,
        device="cpu",
    )

    model = PrismModel(
        n_genes=data.n_genes,
        n_covars=data.n_covars,
        n_context=data.n_context,
        n_disease_subjects=data.n_disease_subjects,
        n_cells=data.n_cells,
        encoder_type="linear",
        device="cpu",
    )

    # Set model params to ground truth
    with torch.no_grad():
        model.beta0.copy_(gt["beta0_true"])
        if "Gamma_true" in gt:
            model.Gamma.copy_(gt["Gamma_true"].reshape(model.Gamma.shape))
        model.alpha_de.copy_(gt["alpha_de_true"])
        model.encoder.theta.copy_(gt["theta_true"])
        # Set sigma2 and phi via inverse softplus (approx)
        model.log_sigma2.fill_(torch.log(torch.expm1(gt["sigma2_true"])).item())
        model.log_phi.fill_(torch.log(torch.expm1(gt["phi_true"])).item())
        for s in range(data.n_disease_subjects):
            rho_s = gt["rho_true"][s]
            model.logit_rho.data[s] = torch.log(rho_s / (1 - rho_s))

    return data, model, gt


class TestEStep:
    """Tests for the E-step."""

    def test_q_close_to_d_with_perfect_params(self, perfect_setup):
        """With ground-truth params, q should approximate d well."""
        data, model, gt = perfect_setup
        q = e_step(data, model)

        # Compute AUC
        from sklearn.metrics import roc_auc_score
        d_true = gt["d_true"].cpu().numpy()
        q_np = q.cpu().numpy()

        # Only evaluate on disease subjects
        disease_mask = data.I.cpu().numpy().astype(bool)
        if disease_mask.sum() > 0 and d_true[disease_mask].std() > 0:
            auc = roc_auc_score(d_true[disease_mask], q_np[disease_mask])
            assert auc > 0.7, f"AUC = {auc:.3f}, expected > 0.7 with perfect params"

    def test_q_zero_for_controls(self, perfect_setup):
        """q should be 0 for all control cells."""
        data, model, _ = perfect_setup
        q = e_step(data, model)

        control_mask = ~data.I
        assert (q[control_mask] == 0).all(), "q should be 0 for control cells"

    def test_q_in_01(self, perfect_setup):
        """q values should be in [0, 1]."""
        data, model, _ = perfect_setup
        q = e_step(data, model)

        assert (q >= 0).all(), "q has negative values"
        assert (q <= 1).all(), "q has values > 1"

    def test_no_nan(self, perfect_setup):
        """q should not contain NaN."""
        data, model, _ = perfect_setup
        q = e_step(data, model)
        assert not torch.isnan(q).any(), "NaN in q"

    def test_chunked_matches_full(self, perfect_setup):
        """Chunked E-step should produce same result as full."""
        data, model, _ = perfect_setup

        q_full = e_step(data, model, gene_chunk_size=None)
        q_chunked = e_step(data, model, gene_chunk_size=3)

        torch.testing.assert_close(q_full, q_chunked, rtol=1e-4, atol=1e-6)

    def test_rho_one_gives_high_q(self):
        """With rho=1, all disease cells should have high q."""
        data, gt = generate_prism_data(
            n_subjects=20,
            n_cells_per_subject=50,
            n_genes=10,
            rho=1.0,
            seed=123,
            device="cpu",
        )

        model = PrismModel(
            n_genes=data.n_genes,
            n_covars=data.n_covars,
            n_context=data.n_context,
            n_disease_subjects=data.n_disease_subjects,
            n_cells=data.n_cells,
            encoder_type="linear",
            device="cpu",
        )

        with torch.no_grad():
            model.beta0.copy_(gt["beta0_true"])
            if "Gamma_true" in gt:
                model.Gamma.copy_(gt["Gamma_true"].reshape(model.Gamma.shape))
            model.alpha_de.copy_(gt["alpha_de_true"])
            model.encoder.theta.copy_(gt["theta_true"])
            # logit_rho = large positive -> rho ≈ 1
            model.logit_rho.fill_(5.0)

        q = e_step(data, model)
        disease_q = q[data.I]
        assert disease_q.mean() > 0.5, f"Mean q for rho=1 is {disease_q.mean():.3f}"
