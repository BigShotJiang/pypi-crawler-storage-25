"""Integration tests for EM convergence behaviour."""

import pytest
import torch

from prism.data.simulation import generate_prism_data
from prism.inference.em_loop import PRISMConfig, PRISMTrainer


@pytest.fixture(scope="module")
def em_data():
    """Generate data for EM convergence tests."""
    data, gt = generate_prism_data(
        n_subjects=30,
        n_cells_per_subject=40,
        n_genes=5,
        rho=0.6,
        sigma2=0.2,
        phi=8.0,
        seed=123,
        device="cpu",
    )
    return data, gt


@pytest.fixture(scope="module")
def em_data_rho1():
    """Generate data with rho=1 (all disease subjects affected)."""
    data, gt = generate_prism_data(
        n_subjects=30,
        n_cells_per_subject=40,
        n_genes=5,
        rho=1.0,
        sigma2=0.2,
        phi=8.0,
        seed=456,
        device="cpu",
    )
    return data, gt


def _make_config(**overrides) -> PRISMConfig:
    """Create a PRISMConfig with test defaults."""
    defaults = dict(
        max_em_iter=10,
        min_em_iter=1,
        m_step_max_iter=30,
        m_step_optimizer="adam",
        m_step_lr=0.01,
        encoder_type="linear",
        wandb_enabled=False,
        run_wald=False,
        device="cpu",
    )
    defaults.update(overrides)
    return PRISMConfig(**defaults)


class TestEMConvergence:
    """Test that the EM algorithm converges properly."""

    def test_ll_increases_monotonically(self, em_data):
        """Observed log-likelihood should increase (or stay flat) at each EM step."""
        data, gt = em_data
        config = _make_config(max_em_iter=10, m_step_max_iter=30)
        trainer = PRISMTrainer(config)
        results = trainer.fit(data)

        lls = results.obs_loglik_trace
        if len(lls) >= 2:
            # Allow small numerical tolerance for LL decrease
            for t in range(1, len(lls)):
                assert lls[t] >= lls[t - 1] - 1e-2, \
                    f"LL decreased at step {t}: {lls[t - 1]:.4f} -> {lls[t]:.4f}"

    def test_q_converges(self, em_data):
        """q_ij posteriors should stabilise (LL trace should flatten)."""
        data, gt = em_data
        config = _make_config(max_em_iter=15, m_step_max_iter=30)
        trainer = PRISMTrainer(config)
        results = trainer.fit(data)

        # If LL trace exists with at least 3 points, the last increment should
        # be smaller than the first (convergence behaviour).
        lls = results.obs_loglik_trace
        if len(lls) >= 3:
            first_delta = abs(lls[1] - lls[0])
            last_delta = abs(lls[-1] - lls[-2])
            assert last_delta <= first_delta + 1.0, \
                f"LL not converging: first delta={first_delta:.4f}, last={last_delta:.4f}"

    def test_params_converge(self, em_data):
        """Parameters should converge (LL trace should flatten)."""
        data, gt = em_data
        config = _make_config(max_em_iter=15, m_step_max_iter=30)
        trainer = PRISMTrainer(config)
        results = trainer.fit(data)

        # LL should improve from first to last
        lls = results.obs_loglik_trace
        if len(lls) >= 2:
            assert lls[-1] >= lls[0] - 1e-2, \
                f"LL did not improve: first={lls[0]:.4f}, last={lls[-1]:.4f}"

    def test_rho1_converges_in_one_iteration(self, em_data_rho1):
        """With rho=1.0, EM should essentially converge quickly
        (equivalent to A2 solution without latent states)."""
        data, gt = em_data_rho1
        config = _make_config(max_em_iter=5, m_step_max_iter=50)
        trainer = PRISMTrainer(config)
        results = trainer.fit(data)

        # With rho=1, q should be ~1 for all disease cells, so EM converges fast.
        # Check that the LL doesn't change much after the first iteration.
        lls = results.obs_loglik_trace
        if len(lls) >= 3:
            later_delta = abs(lls[-1] - lls[1])
            first_step = abs(lls[1] - lls[0]) + 1e-6
            # The change after step 1 should be small relative to the first step
            assert later_delta < first_step * 5.0, \
                f"With rho=1, EM should converge fast; " \
                f"first_step={first_step:.4f}, later_delta={later_delta:.4f}"


class TestEMOutputs:
    """Test that EM outputs are well-formed."""

    def test_results_contain_required_fields(self, em_data):
        """PRISMResults should have all required fields."""
        data, gt = em_data
        config = _make_config(max_em_iter=3, m_step_max_iter=20)
        trainer = PRISMTrainer(config)
        results = trainer.fit(data)

        assert results.beta0_hat is not None
        assert results.sigma2_hat is not None
        assert results.phi_hat is not None
        assert results.rho_hat is not None
        assert results.q_hat is not None
        assert results.beta0_hat.shape[0] == data.n_genes

    def test_results_no_nan(self, em_data):
        """No NaN values in EM outputs."""
        data, gt = em_data
        config = _make_config(max_em_iter=3, m_step_max_iter=20)
        trainer = PRISMTrainer(config)
        results = trainer.fit(data)

        assert not torch.isnan(results.beta0_hat).any(), "NaN in beta0_hat"
        assert not torch.isnan(results.sigma2_hat).any(), "NaN in sigma2_hat"
        assert not torch.isnan(results.phi_hat).any(), "NaN in phi_hat"
        assert not torch.isnan(results.q_hat).any(), "NaN in q_hat"

    def test_rho_in_range(self, em_data):
        """Estimated rho should be in [0, 1]."""
        data, gt = em_data
        config = _make_config(max_em_iter=3, m_step_max_iter=20)
        trainer = PRISMTrainer(config)
        results = trainer.fit(data)

        rho = results.rho_hat
        assert (rho >= 0.0).all() and (rho <= 1.0).all(), \
            f"rho out of range: min={rho.min()}, max={rho.max()}"
