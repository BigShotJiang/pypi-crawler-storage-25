"""Tests for numerical utilities and random effects helpers."""

import pytest
import torch
import math

from prism.utils.numerical import (
    softplus, inv_softplus, clamp_exp, log_sum_exp,
    safe_log, safe_sigmoid, batch_lgamma,
)
from prism.model.random_effects import (
    gamma_params_from_sigma2,
    gamma_posterior_mean,
    gamma_posterior_variance,
)


# ── Numerical utilities ───────────────────────────────────────────────


class TestSoftplus:
    def test_positive_output(self):
        x = torch.randn(100)
        assert (softplus(x) > 0).all()

    def test_roundtrip(self):
        x = torch.tensor([0.5, 1.0, 5.0, 20.0])
        y = softplus(x)
        x_back = inv_softplus(y)
        assert torch.allclose(x, x_back, atol=1e-5)


class TestClampExp:
    def test_extreme_values_no_inf(self):
        x = torch.tensor([-200.0, 0.0, 200.0])
        out = clamp_exp(x)
        assert torch.isfinite(out).all()
        assert (out > 0).all()


class TestLogSumExp:
    def test_known_value(self):
        a = torch.tensor(0.0)
        b = torch.tensor(0.0)
        result = log_sum_exp(a, b)
        assert torch.isclose(result, torch.tensor(math.log(2.0)))


class TestSafeLog:
    def test_zero_input(self):
        x = torch.tensor(0.0)
        out = safe_log(x)
        assert torch.isfinite(out)

    def test_negative_input(self):
        x = torch.tensor(-1.0)
        out = safe_log(x)
        assert torch.isfinite(out)


class TestSafeSigmoid:
    def test_extreme_inputs(self):
        x = torch.tensor([-1000.0, 0.0, 1000.0])
        out = safe_sigmoid(x)
        assert torch.isfinite(out).all()
        assert (out >= 0).all() and (out <= 1).all()


class TestBatchLgamma:
    def test_matches_torch(self):
        x = torch.tensor([1.0, 2.0, 5.0, 10.0])
        out = batch_lgamma(x)
        expected = torch.lgamma(x)
        assert torch.allclose(out, expected, atol=1e-6)


# ── Random effects ────────────────────────────────────────────────────


class TestGammaParams:
    def test_positive_outputs(self):
        log_sigma2 = torch.tensor([0.0, -1.0, 1.0])
        alpha, lam = gamma_params_from_sigma2(log_sigma2)
        assert (alpha > 0).all()
        assert (lam > 0).all()

    def test_small_sigma2_large_alpha(self):
        """Small variance → large shape (concentrated around 1)."""
        log_sigma2 = inv_softplus(torch.tensor([0.01]))
        alpha, _ = gamma_params_from_sigma2(log_sigma2)
        assert alpha.item() > 10


class TestGammaPosterior:
    def test_posterior_mean_positive(self):
        Y_i = torch.randint(0, 10, (5, 3)).float()
        mu_star_i = torch.rand(5, 3) + 0.1
        alpha = torch.tensor([2.0, 2.0, 2.0])
        lam = torch.tensor([1.0, 1.0, 1.0])
        mean = gamma_posterior_mean(Y_i, mu_star_i, alpha, lam)
        assert mean.shape == (3,)
        assert (mean > 0).all()

    def test_posterior_variance_positive(self):
        Y_i = torch.randint(0, 10, (5, 3)).float()
        mu_star_i = torch.rand(5, 3) + 0.1
        alpha = torch.tensor([2.0, 2.0, 2.0])
        lam = torch.tensor([1.0, 1.0, 1.0])
        var = gamma_posterior_variance(Y_i, mu_star_i, alpha, lam)
        assert var.shape == (3,)
        assert (var > 0).all()
