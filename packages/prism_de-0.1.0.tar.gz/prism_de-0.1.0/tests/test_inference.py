"""Tests for Wald test and score test."""

import pytest
import torch

from prism.data.simulation import generate_prism_data
from prism.inference.em_loop import PRISMConfig, PRISMTrainer


@pytest.fixture(scope="module")
def fitted():
    """Fit a small model once for the test module."""
    data, gt = generate_prism_data(
        n_subjects=10, n_cells_per_subject=40, n_genes=6,
        rho=0.5, sigma2=0.1, phi=10.0, seed=0, device="cpu",
    )
    config = PRISMConfig(
        max_em_iter=5, em_tol=1e-2, min_em_iter=2,
        encoder_type="linear", run_wald=True,
        fdr_threshold=0.05, device="cpu",
    )
    results = PRISMTrainer(config).fit(data)
    return data, gt, results


class TestWaldTest:
    """Tests for the Wald test output."""

    def test_wald_stat_shape(self, fitted):
        _, _, results = fitted
        assert results.wald_stat is not None
        assert results.wald_stat.shape[0] == 6  # n_genes

    def test_p_values_range(self, fitted):
        _, _, results = fitted
        assert results.p_values is not None
        assert (results.p_values >= 0).all()
        assert (results.p_values <= 1).all()

    def test_q_values_range(self, fitted):
        _, _, results = fitted
        assert results.q_values is not None
        assert (results.q_values >= 0).all()
        assert (results.q_values <= 1).all()

    def test_se_positive(self, fitted):
        _, _, results = fitted
        assert results.se is not None
        assert (results.se >= 0).all()


class TestScoreTest:
    """Test the score test by running it directly."""

    def test_score_test_runs(self):
        from prism.inference.score_test import score_test
        from prism.model.prism_model import PrismModel

        data, gt = generate_prism_data(
            n_subjects=8, n_cells_per_subject=30, n_genes=4,
            seed=1, device="cpu",
        )
        model = PrismModel(
            n_genes=data.n_genes, n_covars=data.n_covars,
            n_context=data.n_context,
            n_disease_subjects=data.n_disease_subjects,
            n_cells=data.n_cells, n_subjects=data.n_subjects,
            encoder_type="linear", device="cpu",
        )
        model.initialize_from_data(data)
        stat, pvals = score_test(data, model)
        assert stat.shape == (4,)
        assert pvals.shape == (4,)
        assert (pvals >= 0).all() and (pvals <= 1).all()
