"""Tests for data generation and PrismData dataclass."""

import pytest
import torch

from prism.data.simulation import generate_prism_data
from prism.data.dataset import PrismData


@pytest.fixture
def sim_data():
    """Small simulated dataset for fast tests."""
    data, gt = generate_prism_data(
        n_subjects=10,
        n_cells_per_subject=30,
        n_genes=8,
        rho=0.5,
        sigma2=0.1,
        phi=10.0,
        seed=0,
        device="cpu",
    )
    return data, gt


class TestGeneratePrismData:
    """Tests for the simulation data generator."""

    def test_returns_tuple(self, sim_data):
        data, gt = sim_data
        assert isinstance(data, PrismData)
        assert isinstance(gt, dict)

    def test_shapes(self, sim_data):
        data, gt = sim_data
        n, p = 10 * 30, 8
        assert data.Y.shape == (n, p)
        assert data.X.shape[0] == n
        assert data.Z.shape[0] == n
        assert data.I.shape == (n,)
        assert data.log_pi.shape == (n,)
        assert data.subject_idx.shape == (n,)

    def test_properties(self, sim_data):
        data, _ = sim_data
        assert data.n_subjects == 10
        assert data.n_genes == 8
        assert data.n_cells == 10 * 30

    def test_ground_truth_keys(self, sim_data):
        _, gt = sim_data
        expected = {
            "d_true", "beta0_true", "theta_true", "rho_true",
            "sigma2_true", "phi_true", "gene_category", "omega_true",
            "n_null", "n_fixed_de", "n_context_de",
        }
        assert expected.issubset(gt.keys())

    def test_gene_categories_sum(self, sim_data):
        _, gt = sim_data
        total = gt["n_null"] + gt["n_fixed_de"] + gt["n_context_de"]
        assert total == 8  # n_genes

    def test_controls_have_d_zero(self, sim_data):
        data, gt = sim_data
        control_mask = ~data.I
        assert (gt["d_true"][control_mask] == 0).all()

    def test_deterministic_seed_structure(self):
        """Same seed produces identical non-stochastic outputs (X, Z, I)."""
        kwargs = dict(n_subjects=6, n_cells_per_subject=10,
                      n_genes=4, seed=77, device="cpu")
        d1, g1 = generate_prism_data(**kwargs)
        d2, g2 = generate_prism_data(**kwargs)
        assert torch.equal(d1.X, d2.X)
        assert torch.equal(d1.Z, d2.Z)
        assert torch.equal(d1.I, d2.I)
        assert torch.equal(g1["beta0_true"], g2["beta0_true"])

    def test_counts_nonnegative(self, sim_data):
        data, _ = sim_data
        assert (data.Y >= 0).all()


class TestPrismData:
    """Tests for the PrismData dataclass."""

    def test_from_tensors(self, sim_data):
        data, _ = sim_data
        data2 = PrismData.from_tensors(
            Y=data.Y, X=data.X, Z=data.Z, I=data.I,
            log_pi=data.log_pi, subject_idx=data.subject_idx,
            n_subjects=data.n_subjects,
            disease_subject_idx=data.disease_subject_idx,
            n_disease_subjects=data.n_disease_subjects,
        )
        assert torch.equal(data2.Y, data.Y)
        assert data2.n_genes == data.n_genes

    def test_cells_for_subject(self, sim_data):
        data, _ = sim_data
        mask = data.cells_for_subject(0)
        assert mask.dtype == torch.bool
        assert mask.shape == (data.n_cells,)
        assert mask.sum() > 0

    def test_to_device(self, sim_data):
        data, _ = sim_data
        data_cpu = data.to("cpu")
        assert data_cpu.Y.device.type == "cpu"
        assert data_cpu.device.type == "cpu"
