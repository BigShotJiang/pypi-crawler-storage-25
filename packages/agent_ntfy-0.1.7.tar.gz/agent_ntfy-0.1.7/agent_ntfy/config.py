"""Configuration management for agent-notifier."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field


class NotifierConfig(BaseModel):
    """Configuration for agent-notifier."""

    ntfy_topic: str = Field(
        default="CHANGE_ME",
        description="ntfy.sh topic ID for push notifications",
    )
    ntfy_server: str = Field(
        default="https://ntfy.sh",
        description="ntfy.sh server URL",
    )
    ntfy_token: Optional[str] = Field(
        default=None,
        description="ntfy.sh access token for private topics",
    )
    ntfy_priority: str = Field(
        default="default",
        description="Notification priority: low, default, high, urgent",
    )
    ntfy_tags: list[str] = Field(
        default=["robot"],
        description="Tags for ntfy notifications",
    )
    ntfy_enabled: bool = Field(
        default=True,
        description="Enable ntfy.sh notifications",
    )
    terminal_enabled: bool = Field(
        default=True,
        description="Enable terminal OSC 9 notifications",
    )
    os_native_enabled: bool = Field(
        default=True,
        description="Enable OS-native notifications (BurntToast, osascript, notify-send)",
    )
    log_file: Optional[str] = Field(
        default=None,
        description="Path to log file (default: ~/.agent-notifier/notifier.log)",
    )
    log_level: str = Field(
        default="INFO",
        description="Logging level (DEBUG, INFO, WARNING, ERROR)",
    )


def get_config_dir() -> Path:
    """Get the configuration directory."""
    if sys.platform == "win32":
        return Path.home() / ".agent-notifier"
    elif sys.platform == "darwin":
        return Path.home() / ".config" / "agent-notifier"
    return Path.home() / ".config" / "agent-notifier"


def get_default_config_path() -> Path:
    """Get the default config file path."""
    return get_config_dir() / "config.json"


def load_config(config_path: Optional[str] = None) -> NotifierConfig:
    """
    Load configuration from file and environment variables.

    Priority: environment variables > config file > defaults
    """
    if config_path:
        config_file = Path(config_path)
    else:
        config_file = get_default_config_path()

    config_data = {}

    if config_file.exists():
        try:
            config_data = json.loads(config_file.read_text())
        except (json.JSONDecodeError, IOError):
            pass

    env_overrides = {
        "ntfy_topic": os.environ.get("AGENT_NOTIFY_NTFY_TOPIC"),
        "ntfy_server": os.environ.get("AGENT_NOTIFY_NTFY_SERVER"),
        "ntfy_token": os.environ.get("AGENT_NOTIFY_NTFY_TOKEN"),
        "ntfy_priority": os.environ.get("AGENT_NOTIFY_NTFY_PRIORITY"),
        "ntfy_enabled": os.environ.get("AGENT_NOTIFY_NTFY_ENABLED"),
        "terminal_enabled": os.environ.get("AGENT_NOTIFY_TERMINAL_ENABLED"),
        "os_native_enabled": os.environ.get("AGENT_NOTIFY_OS_NATIVE_ENABLED"),
    }

    for key, value in env_overrides.items():
        if value is not None:
            if key.endswith("_enabled"):
                config_data[key] = value.lower() in ("true", "1", "yes")
            else:
                config_data[key] = value

    return NotifierConfig(**config_data)


def ensure_config_dir() -> Path:
    """Ensure the configuration directory exists."""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def write_default_config() -> Path:
    """Write a default configuration file."""
    config_dir = ensure_config_dir()
    config_file = config_dir / "config.json"

    default_config = {
        "ntfy_topic": "CHANGE_ME",
        "ntfy_server": "https://ntfy.sh",
        "ntfy_token": None,
        "ntfy_priority": "default",
        "ntfy_tags": ["robot"],
        "ntfy_enabled": True,
        "terminal_enabled": True,
        "os_native_enabled": True,
        "log_level": "INFO",
    }
    config_file.write_text(json.dumps(default_config, indent=2))

    return config_file
