"""OS-native notification support for Windows, macOS, and Linux."""
from __future__ import annotations

import logging
import shutil
import subprocess
import sys

logger = logging.getLogger(__name__)


def _get_shell() -> str:
    """Get the appropriate shell command (prefer pwsh on Windows)."""
    if sys.platform == "win32":
        if shutil.which("pwsh"):
            return "pwsh"
        return "powershell"
    return "sh"


def _escape_single_quotes(s: str) -> str:
    """Escape single quotes for PowerShell strings."""
    return s.replace("'", "''")


def _escape_shell_arg(s: str) -> str:
    """Escape a string for shell execution."""
    return s.replace('"', '\\"')


def notify_windows(title: str, message: str) -> bool:
    """Send Windows notification via BurntToast PowerShell module."""
    try:
        shell = _get_shell()
        safe_title = _escape_single_quotes(title)
        safe_message = _escape_single_quotes(message)

        script = f"Import-Module BurntToast; New-BurntToastNotification -Sound IM -Text '{safe_title}', '{safe_message}'"

        result = subprocess.run(
            [shell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True,
            timeout=10,
        )

        if result.returncode == 0:
            logger.info(f"Windows BurntToast notification sent: {title}")
            return True
        else:
            stderr = result.stderr.decode() if result.stderr else ""
            logger.error(f"BurntToast failed: {stderr}")
            return False

    except subprocess.TimeoutExpired:
        logger.error("Windows notification timed out")
        return False
    except Exception as e:
        logger.error(f"Windows notification failed: {e}")
        return False


def notify_macos(title: str, message: str) -> bool:
    """Send macOS notification via osascript."""
    try:
        if not shutil.which("osascript"):
            logger.debug("osascript not found, skipping macOS notification")
            return False

        safe_title = _escape_shell_arg(title)
        safe_message = _escape_shell_arg(message)
        script = f'display notification "{safe_message}" with title "{safe_title}"'

        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            timeout=10,
        )

        if result.returncode == 0:
            logger.info(f"macOS notification sent: {title}")
            return True
        else:
            stderr = result.stderr.decode() if result.stderr else ""
            logger.error(f"osascript failed: {stderr}")
            return False

    except subprocess.TimeoutExpired:
        logger.error("macOS notification timed out")
        return False
    except Exception as e:
        logger.error(f"macOS notification failed: {e}")
        return False


def notify_linux(title: str, message: str) -> bool:
    """Send Linux notification via notify-send."""
    try:
        if not shutil.which("notify-send"):
            logger.debug("notify-send not found, skipping Linux notification")
            return False

        result = subprocess.run(
            ["notify-send", title, message],
            capture_output=True,
            timeout=10,
        )

        if result.returncode == 0:
            logger.info(f"Linux notification sent: {title}")
            return True
        else:
            stderr = result.stderr.decode() if result.stderr else ""
            logger.error(f"notify-send failed: {stderr}")
            return False

    except subprocess.TimeoutExpired:
        logger.error("Linux notification timed out")
        return False
    except Exception as e:
        logger.error(f"Linux notification failed: {e}")
        return False


def notify_os(title: str, message: str) -> bool:
    """Send OS-native notification based on current platform."""
    platform = sys.platform

    if platform == "win32":
        return notify_windows(title, message)
    elif platform == "darwin":
        return notify_macos(title, message)
    elif platform.startswith("linux"):
        return notify_linux(title, message)
    else:
        logger.warning(f"Unsupported platform for OS notification: {platform}")
        return False
