"""Unified notification system - sends via all available channels."""
from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from agent_notifier import config, ntfy_notify, os_notify, terminal


def setup_logging(level: str = "INFO", log_file: Optional[str] = None) -> None:
    """Configure logging for the notifier."""
    log_format = "%(asctime)s - %(levelname)s - %(message)s"
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stderr)]

    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(log_path))

    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format=log_format,
        handlers=handlers,
    )


def send_all_notifications(
    title: str,
    message: str,
    ntfy_topic: str,
    enable_ntfy: bool = True,
    enable_terminal: bool = True,
    enable_os: bool = True,
    ntfy_server: str = "https://ntfy.sh",
    ntfy_token: Optional[str] = None,
    ntfy_priority: str = "default",
    ntfy_tags: Optional[list[str]] = None,
) -> Dict[str, bool]:
    """
    Send notifications via all available channels.

    Returns:
        Dict mapping channel name to success status.
    """
    results: Dict[str, bool] = {}

    if enable_terminal:
        results["terminal"] = terminal.send_terminal_notification(message)
    else:
        results["terminal"] = False

    if enable_os:
        results["os_native"] = os_notify.notify_os(title, message)
    else:
        results["os_native"] = False

    if enable_ntfy and ntfy_topic and ntfy_topic != "CHANGE_ME":
        results["ntfy"] = ntfy_notify.notify_ntfy(
            title=title,
            message=message,
            topic=ntfy_topic,
            server=ntfy_server,
            token=ntfy_token,
            priority=ntfy_priority,
            tags=ntfy_tags,
        )
    else:
        results["ntfy"] = False
        if enable_ntfy and (not ntfy_topic or ntfy_topic == "CHANGE_ME"):
            logging.warning("ntfy topic not configured. Set ntfy_topic in config or AGENT_NOTIFY_NTFY_TOPIC env var.")

    return results


def parse_payload(payload_text: str) -> Dict[str, Any]:
    """
    Parse notification payload from JSON.

    Supports multiple input formats:
    - Claude Code: {"title": "...", "message": "...", "notification_type": "..."}
    - Gemini CLI: {"notification_type": "...", "message": "...", "session_id": "..."}
    - Simple: {"message": "..."}
    """
    try:
        payload = json.loads(payload_text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON payload: {e}")

    notification_type = payload.get("notification_type", "Notification")
    message = payload.get("message", "Agent requires attention")

    if "title" in payload and payload["title"]:
        title = payload["title"]
    else:
        source = payload.get("source", "Agent")
        title = f"{source} - {notification_type}"

    return {
        "title": title,
        "message": message,
        "notification_type": notification_type,
    }


def notify_from_stdin(config_path: Optional[str] = None) -> int:
    """
    Main entry point for stdin-based notification.

    Reads JSON payload from stdin and sends via all channels.
    """
    try:
        payload_text = sys.stdin.read()

        if not payload_text.strip():
            logging.warning("Empty payload received")
            return 0

        cfg = config.load_config(config_path)

        setup_logging(level=cfg.log_level, log_file=cfg.log_file)

        payload = parse_payload(payload_text)
        logging.debug(f"Parsed payload: {payload}")

        results = send_all_notifications(
            title=payload["title"],
            message=payload["message"],
            ntfy_topic=cfg.ntfy_topic,
            enable_ntfy=cfg.ntfy_enabled,
            enable_terminal=cfg.terminal_enabled,
            enable_os=cfg.os_native_enabled,
            ntfy_server=cfg.ntfy_server,
            ntfy_token=cfg.ntfy_token,
            ntfy_priority=cfg.ntfy_priority,
            ntfy_tags=cfg.ntfy_tags,
        )

        success_count = sum(results.values())
        logging.info(
            f"Notification results: {success_count}/{len(results)} channels - "
            f"Terminal: {results['terminal']}, OS: {results['os_native']}, ntfy: {results['ntfy']}"
        )

        return 0 if success_count > 0 else 1

    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        return 1


def notify(
    title: str,
    message: str,
    ntfy_topic: Optional[str] = None,
    config_path: Optional[str] = None,
    ntfy_server: Optional[str] = None,
    ntfy_token: Optional[str] = None,
    ntfy_priority: Optional[str] = None,
) -> Dict[str, bool]:
    """
    Programmatic notification API.

    Args:
        title: Notification title
        message: Notification message
        ntfy_topic: Override ntfy topic (uses config if not provided)
        config_path: Path to config file
        ntfy_server: Override ntfy server URL
        ntfy_token: Override ntfy access token
        ntfy_priority: Override ntfy priority

    Returns:
        Dict mapping channel name to success status.
    """
    cfg = config.load_config(config_path)

    setup_logging(level=cfg.log_level, log_file=cfg.log_file)

    return send_all_notifications(
        title=title,
        message=message,
        ntfy_topic=ntfy_topic if ntfy_topic else cfg.ntfy_topic,
        enable_ntfy=cfg.ntfy_enabled,
        enable_terminal=cfg.terminal_enabled,
        enable_os=cfg.os_native_enabled,
        ntfy_server=ntfy_server if ntfy_server else cfg.ntfy_server,
        ntfy_token=ntfy_token if ntfy_token else cfg.ntfy_token,
        ntfy_priority=ntfy_priority if ntfy_priority else cfg.ntfy_priority,
        ntfy_tags=cfg.ntfy_tags,
    )
