"""CLI for agent-notifier."""
from __future__ import annotations

import argparse
import json
import sys

from agent_notifier import unified
from agent_notifier.config import ensure_config_dir, get_default_config_path, write_default_config


def main() -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Agent Notifier - Cross-platform notifications for AI agents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Send a test notification
  agent-notify --title "Test" --message "Hello from agent-notifier!"

  # Send notification via stdin (JSON)
  echo '{"title":"Claude","message":"Task complete","notification_type":"Completion"}' | agent-notify

  # Send via specific channels only
  agent-notify --title "Alert" --message "Error occurred" --no-terminal --no-os

  # Use custom ntfy topic
  agent-notify --title "Alert" --message "Urgent!" --ntfy-topic my-custom-topic

  # Initialize configuration
  agent-notifier-setup --init

  # Install all hooks
  agent-notifier-setup --all

  # Install hooks for specific agents:
  agent-notifier-setup --install-claude   # Claude Code
  agent-notifier-setup --install-gemini    # Gemini CLI
  agent-notifier-setup --install-opencode  # OpenCode
  agent-notifier-setup --install-cursor    # Cursor CLI
  agent-notifier-setup --install-codex     # Codex CLI

  # Check prerequisites
  agent-notifier-setup --check

  # Uninstall all hooks
  agent-notifier-setup --uninstall
        """,
    )

    parser.add_argument(
        "--title",
        "-t",
        help="Notification title",
    )
    parser.add_argument(
        "--message",
        "-m",
        help="Notification message",
    )
    parser.add_argument(
        "--ntfy-topic",
        help="ntfy.sh topic ID (overrides config)",
    )
    parser.add_argument(
        "--no-terminal",
        action="store_true",
        help="Disable terminal notifications",
    )
    parser.add_argument(
        "--no-os",
        action="store_true",
        help="Disable OS-native notifications",
    )
    parser.add_argument(
        "--no-ntfy",
        action="store_true",
        help="Disable ntfy.sh notifications",
    )
    parser.add_argument(
        "--config",
        help="Path to config file",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args()

    if args.verbose:
        import logging
        logging.basicConfig(level=logging.DEBUG)

    if args.title and args.message:
        results = unified.notify(
            title=args.title,
            message=args.message,
            ntfy_topic=args.ntfy_topic,
            config_path=args.config,
        )
        success = sum(results.values()) > 0
        print(json.dumps(results, indent=2))
        return 0 if success else 1

    elif not sys.stdin.isatty():
        return unified.notify_from_stdin(config_path=args.config)

    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
