"""Terminal notification support using OSC 9 protocol."""
from __future__ import annotations

import logging
import os
import sys

logger = logging.getLogger(__name__)

ALLOWLISTED_TERMINALS = [
    "ghostty",
    "iterm.app",
    "iterm2",
    "kitty",
    "vscode",
    "apple_terminal",
    "windows-terminal",
]


def is_supported_terminal() -> bool:
    """Check if running in a terminal that supports OSC 9 notifications."""
    term_program = os.environ.get("TERM_PROGRAM", "").lower()
    return any(term in term_program for term in ALLOWLISTED_TERMINALS)


def send_terminal_notification(message: str) -> bool:
    """
    Send a terminal notification using OSC 9 protocol.

    OSC 9 format: \\x1b]9;{message}\\x07
    Supported terminals: Ghostty, iTerm2, Kitty, VSCode, Apple Terminal, Windows Terminal

    Returns:
        True if notification was sent, False otherwise.
    """
    try:
        if is_supported_terminal():
            sys.stdout.write(f"\x1b]9;{message}\x07")
            sys.stdout.flush()
            logger.debug(f"Terminal notification sent: {message}")
            return True
        else:
            term = os.environ.get("TERM_PROGRAM", "unknown")
            logger.debug(f"Terminal {term} not in allowlist, skipping OSC 9")
            return False
    except Exception as e:
        logger.error(f"Terminal notification failed: {e}")
        return False
