"""Setup and installation utilities for agent-notifier."""
from __future__ import annotations

import json
import os
import platform
import shutil
import sys
from pathlib import Path

HOME = Path.home()


def get_claude_settings_path() -> Path:
    """Get Claude Code settings.json path."""
    return HOME / ".claude" / "settings.json"


def get_gemini_settings_path() -> Path:
    """Get Gemini CLI settings.json path."""
    return HOME / ".gemini" / "settings.json"


def get_opencode_config_path() -> Path:
    """Get OpenCode config.json path."""
    if platform.system() == "Windows":
        return HOME / "AppData" / "Roaming" / "opencode" / "opencode.json"
    elif platform.system() == "darwin":
        return HOME / "Library" / "Application Support" / "opencode" / "opencode.json"
    return HOME / ".config" / "opencode" / "opencode.json"


def get_cursor_hooks_path() -> Path:
    """Get Cursor CLI hooks.json path."""
    return HOME / ".cursor" / "hooks.json"


def get_codex_config_path() -> Path:
    """Get Codex CLI config.toml path."""
    codex_home = os.environ.get("CODEX_HOME", str(HOME / ".codex"))
    return Path(codex_home) / "config.toml"


def ensure_dir(path: Path) -> None:
    """Ensure directory exists."""
    path.parent.mkdir(parents=True, exist_ok=True)


def load_json(path: Path) -> dict:
    """Load JSON file, return empty dict if not exists."""
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def save_json(path: Path, data: dict) -> None:
    """Save JSON file with proper encoding."""
    ensure_dir(path)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def install_claude_hook(script_path: str) -> bool:
    """Install notification hook for Claude Code."""
    settings_path = get_claude_settings_path()
    settings = load_json(settings_path)

    if "hooks" not in settings:
        settings["hooks"] = {}

    if "Notification" not in settings["hooks"]:
        settings["hooks"]["Notification"] = []

    hook_entry = {
        "matcher": "",
        "hooks": [
            {
                "type": "command",
                "command": f'pwsh -NoLogo -NoProfile -File "{script_path}"',
            }
        ],
    }

    exists = any(
        h.get("hooks", [{}])[0].get("command", "").endswith(script_path.replace("/", "\\"))
        for h in settings["hooks"].get("Notification", [])
        if h.get("hooks")
    )

    if not exists:
        settings["hooks"]["Notification"].append(hook_entry)

    save_json(settings_path, settings)
    print(f"Installed Claude Code hook: {settings_path}")
    return True


def install_gemini_hook(script_path: str) -> bool:
    """Install notification hook for Gemini CLI."""
    settings_path = get_gemini_settings_path()
    settings = load_json(settings_path)

    if "hooks" not in settings:
        settings["hooks"] = {}

    if "Notification" not in settings["hooks"]:
        settings["hooks"]["Notification"] = []

    hook_entry = {
        "matcher": ".*",
        "hooks": [
            {
                "name": "agent-notifier",
                "type": "command",
                "command": f'agent-notify --config "$HOME/.agent-notifier/config.json"',
                "timeout": 30000,
            }
        ],
    }

    exists = any(
        h.get("hooks", [{}])[0].get("name") == "agent-notifier"
        for h in settings["hooks"].get("Notification", [])
        if h.get("hooks")
    )

    if not exists:
        settings["hooks"]["Notification"].append(hook_entry)

    save_json(settings_path, settings)
    print(f"Installed Gemini CLI hook: {settings_path}")
    return True


def get_opencode_plugins_dir() -> Path:
    """Get OpenCode plugins directory."""
    if platform.system() == "Windows":
        return HOME / "AppData" / "Roaming" / "opencode" / "plugins"
    elif platform.system() == "darwin":
        return HOME / "Library" / "Application Support" / "opencode" / "plugins"
    return HOME / ".config" / "opencode" / "plugins"


def create_opencode_plugin(install_dir: Path) -> Path:
    """Create OpenCode notification plugin (self-contained)."""
    plugins_dir = get_opencode_plugins_dir()
    ensure_dir(plugins_dir)
    plugin_path = plugins_dir / "agent-notifier.mjs"

    plugin_content = '''/**
 * Agent Notifier - OpenCode Plugin
 * Sends notifications via terminal, OS native, and ntfy.sh
 * 
 * Events handled:
 * - session.idle: Agent completed a turn
 * - session.error: Error occurred
 * - permission.asked: Permission requested
 */

const AgentNotifierPlugin = async ({ $, config }) => {
    // Get config from agent-notifier config file
    const configPath = process.platform === "win32" 
        ? `${process.env.USERPROFILE}\\\\.agent-notifier\\\\config.json`
        : `${process.env.HOME}/.agent-notifier/config.json`;

    // Event handler
    const handleEvent = async (event) => {
        const eventType = event.type || "unknown";
        
        // Map OpenCode event types to notification types
        const eventTitles = {
            "session.idle": "OpenCode - Session Idle",
            "session.error": "OpenCode - Error",
            "permission.asked": "OpenCode - Permission Needed",
            "session.started": "OpenCode - Session Started",
            "subagent.complete": "OpenCode - Subagent Complete",
        };

        const title = eventTitles[eventType] || "OpenCode";
        const message = event.message || event.description || getDefaultMessage(eventType);

        // Build notification payload
        const payload = JSON.stringify({
            title,
            message,
            notification_type: eventType,
            source: "OpenCode"
        });

        // Call agent-notify CLI via shell
        try {
            // Try pwsh first (PowerShell 7+), fall back to powershell
            const shell = process.platform === "win32" ? "pwsh" : "sh";
            const shellArgs = process.platform === "win32" 
                ? ["-NoProfile", "-Command", `echo '${payload}' | agent-notify --config "${configPath.replace(/\\\\/g, "\\\\\\\\")}"`]
                : ["-c", `echo '${payload}' | agent-notify --config "${configPath}"`];
            
            await $([shell, ...shellArgs]);
        } catch (err) {
            // Silent failure - notifications are best-effort
        }
    };

    const getDefaultMessage = (eventType) => {
        const messages = {
            "session.idle": "Agent session completed",
            "session.error": "Agent encountered an error",
            "permission.asked": "Waiting for permission",
            "session.started": "Session started",
            "subagent.complete": "Subagent task completed",
        };
        return messages[eventType] || "Event occurred";
    };

    return {
        event: async ({ event }) => {
            // Only notify on specific events to avoid noise
            const notifyEvents = [
                "session.idle",
                "session.error",
                "permission.asked",
                "subagent.complete"
            ];
            
            if (notifyEvents.includes(event.type)) {
                await handleEvent(event);
            }
        }
    };
};

export default AgentNotifierPlugin;
'''

    plugin_path.write_text(plugin_content, encoding="utf-8")
    return plugin_path


def install_opencode_plugin() -> bool:
    """Install OpenCode plugin for notifications (self-contained)."""
    install_dir = HOME / ".agent-notifier"
    plugin_path = create_opencode_plugin(install_dir)
    
    config_path = get_opencode_config_path()
    config = load_json(config_path)

    if "plugin" not in config:
        config["plugin"] = []

    # Use local plugin path
    plugins_dir = get_opencode_plugins_dir()
    local_plugin_ref = str(plugin_path)
    
    if local_plugin_ref not in config["plugin"]:
        config["plugin"].append(local_plugin_ref)

    save_json(config_path, config)
    print(f"Installed OpenCode plugin: {config_path}")
    print(f"  Plugin: {plugin_path}")
    return True


def install_cursor_hook(script_path: str) -> bool:
    """Install notification hook for Cursor CLI."""
    hooks_path = get_cursor_hooks_path()
    hooks = load_json(hooks_path)

    if "stop" not in hooks:
        hooks["stop"] = []

    hook_entry = {
        "command": f'pwsh -NoLogo -NoProfile -File "{script_path}"',
    }

    exists = any(
        h.get("command", "").endswith(script_path.replace("/", "\\"))
        for h in hooks.get("stop", [])
    )

    if not exists:
        hooks["stop"].append(hook_entry)

    save_json(hooks_path, hooks)
    print(f"Installed Cursor CLI hook: {hooks_path}")
    return True


def install_codex_hook(script_path: str) -> bool:
    """Install notification hook for Codex CLI via config.toml."""
    config_path = get_codex_config_path()
    ensure_dir(config_path)

    script_content = ""
    if config_path.exists():
        script_content = config_path.read_text(encoding="utf-8")

    notify_line = f'notify = ["pwsh", "-NoLogo", "-NoProfile", "-File", "{script_path}"]'

    if "notify" not in script_content:
        if script_content.strip():
            script_content += "\n"
        script_content += f"\n{notify_line}\n"
    else:
        import re
        pattern = r'notify\s*=\s*\[[^\]]*\]'
        if re.search(pattern, script_content):
            script_content = re.sub(pattern, notify_line, script_content)
        else:
            script_content += f"\n{notify_line}\n"

    config_path.write_text(script_content, encoding="utf-8")
    print(f"Installed Codex CLI hook: {config_path}")
    return True


def create_claude_notify_script(install_dir: Path) -> Path:
    """Create Claude Code PowerShell notification script."""
    ensure_dir(install_dir)
    script_path = install_dir / "notify.ps1"

    script_content = '''$inputText = $input | Out-String
if ($inputText.Trim()) {
    $j = $inputText | ConvertFrom-Json

    $title = if ($j.title) { $j.title } else { "Claude Code" }
    $notificationType = if ($j.notification_type) { $j.notification_type } else { "Notification" }

    $payload = @{
        title = $title
        message = $j.message
        notification_type = $notificationType
        source = "Claude Code"
    } | ConvertTo-Json -Compress

    try {
        $payload | agent-notify 2>$null
    }
    catch {
        Write-Error "Failed to send notification: $_"
    }
}
'''
    script_path.write_text(script_content, encoding="utf-8")
    return script_path


def create_gemini_notify_script(install_dir: Path) -> Path:
    """Create Gemini CLI notification script."""
    ensure_dir(install_dir)
    script_path = install_dir / "notify.py"

    script_content = '''#!/usr/bin/env python3
"""Gemini CLI notification hook - reads from stdin and sends notifications."""
import sys
import json

from agent_notifier import unified

if __name__ == "__main__":
    payload_text = sys.stdin.read()
    if payload_text.strip():
        try:
            unified.notify_from_stdin()
        except Exception as e:
            print(f"Notification failed: {e}", file=sys.stderr)
            sys.exit(1)
'''
    script_path.write_text(script_content, encoding="utf-8")
    return script_path


def create_cursor_notify_script(install_dir: Path) -> Path:
    """Create Cursor CLI PowerShell notification script."""
    ensure_dir(install_dir)
    script_path = install_dir / "cursor_notify.ps1"

    script_content = '''$inputText = $input | Out-String
if ($inputText.Trim()) {
    try {
        $j = $inputText | ConvertFrom-Json
        $title = "Cursor CLI"
        $message = if ($j.message) { $j.message } else { "Task completed" }

        $payload = @{
            title = $title
            message = $message
            notification_type = "TaskComplete"
            source = "Cursor"
        } | ConvertTo-Json -Compress

        $payload | agent-notify 2>$null
    }
    catch {
        Write-Error "Failed to send notification: $_"
    }
}
'''
    script_path.write_text(script_content, encoding="utf-8")
    return script_path


def create_codex_notify_script(install_dir: Path) -> Path:
    """Create Codex CLI PowerShell notification script."""
    ensure_dir(install_dir)
    script_path = install_dir / "codex_notify.ps1"

    script_content = '''$inputText = $input | Out-String
if ($inputText.Trim()) {
    try {
        $j = $inputText | ConvertFrom-Json
        $title = "Codex CLI"
        $message = if ($j.message) { $j.message } else { "Task completed" }

        if ($j.type -eq "agent-turn-complete") {
            $message = "Agent turn complete"
        } elseif ($j.type -eq "approval-requested") {
            $message = "Approval requested - " + $message
        }

        $payload = @{
            title = $title
            message = $message
            notification_type = $j.type
            source = "Codex"
        } | ConvertTo-Json -Compress

        $payload | agent-notify 2>$null
    }
    catch {
        Write-Error "Failed to send notification: $_"
    }
}
'''
    script_path.write_text(script_content, encoding="utf-8")
    return script_path


def init_config(config_path: Path) -> None:
    """Initialize default configuration."""
    config_path.parent.mkdir(parents=True, exist_ok=True)
    if not config_path.exists():
        default_config = {
            "ntfy_topic": "CHANGE_ME",
            "ntfy_server": "https://ntfy.sh",
            "ntfy_token": None,
            "ntfy_priority": "default",
            "ntfy_tags": ["robot"],
            "ntfy_enabled": True,
            "terminal_enabled": True,
            "os_native_enabled": True,
            "log_level": "INFO",
        }
        config_path.write_text(json.dumps(default_config, indent=2), encoding="utf-8")
        print(f"Created config: {config_path}")
        print("Edit the config and set your ntfy.sh topic ID")
    else:
        print(f"Config already exists: {config_path}")


def check_prerequisites() -> dict:
    """Check if required tools are installed."""
    results = {
        "pwsh": shutil.which("pwsh") or shutil.which("powershell"),
        "python": shutil.which("python") or shutil.which("python3"),
        "pip": shutil.which("pip"),
    }
    return results


def main() -> int:
    """Main setup entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="Agent Notifier Setup")
    parser.add_argument("--init", action="store_true", help="Initialize default configuration")
    parser.add_argument("--install-claude", action="store_true", help="Install Claude Code hook")
    parser.add_argument("--install-gemini", action="store_true", help="Install Gemini CLI hook")
    parser.add_argument("--install-opencode", action="store_true", help="Install OpenCode plugin")
    parser.add_argument("--install-cursor", action="store_true", help="Install Cursor CLI hook")
    parser.add_argument("--install-codex", action="store_true", help="Install Codex CLI hook")
    parser.add_argument("--all", action="store_true", help="Install all hooks and init config")
    parser.add_argument("--check", action="store_true", help="Check prerequisites")
    parser.add_argument("--uninstall", action="store_true", help="Uninstall all hooks")

    args = parser.parse_args()

    install_dir = HOME / ".agent-notifier"
    config_path = install_dir / "config.json"
    claude_script = install_dir / "notify.ps1"
    gemini_script = install_dir / "notify.py"
    cursor_script = install_dir / "cursor_notify.ps1"
    codex_script = install_dir / "codex_notify.ps1"

    if args.check:
        print("Checking prerequisites...")
        results = check_prerequisites()
        for tool, path in results.items():
            if path:
                print(f"  {tool}: {path}")
            else:
                print(f"  {tool}: NOT FOUND")
        return 0

    if args.all or args.init:
        init_config(config_path)

    if args.all or args.install_claude:
        create_claude_notify_script(install_dir)
        install_claude_hook(str(claude_script))

    if args.all or args.install_gemini:
        create_gemini_notify_script(install_dir)
        install_gemini_hook(str(gemini_script))

    if args.all or args.install_opencode:
        install_opencode_plugin()

    if args.all or args.install_cursor:
        create_cursor_notify_script(install_dir)
        install_cursor_hook(str(cursor_script))

    if args.all or args.install_codex:
        create_codex_notify_script(install_dir)
        install_codex_hook(str(codex_script))

    if args.uninstall:
        uninstall_all()

    if not any([
        args.init, args.install_claude, args.install_gemini,
        args.install_opencode, args.install_cursor, args.install_codex,
        args.all, args.check, args.uninstall
    ]):
        parser.print_help()

    return 0


def uninstall_all() -> None:
    """Uninstall hooks from all agents."""
    claude_settings = get_claude_settings_path()
    gemini_settings = get_gemini_settings_path()
    opencode_config = get_opencode_config_path()
    cursor_hooks = get_cursor_hooks_path()
    codex_config = get_codex_config_path()

    if claude_settings.exists():
        settings = json.loads(claude_settings.read_text(encoding="utf-8"))
        if "hooks" in settings and "Notification" in settings["hooks"]:
            settings["hooks"]["Notification"] = [
                h for h in settings["hooks"]["Notification"]
                if not any("agent-notifier" in str(hook) for hook in h.get("hooks", []))
            ]
            claude_settings.write_text(json.dumps(settings, indent=2), encoding="utf-8")
            print(f"Removed Claude Code hook: {claude_settings}")

    if gemini_settings.exists():
        settings = json.loads(gemini_settings.read_text(encoding="utf-8"))
        if "hooks" in settings and "Notification" in settings["hooks"]:
            settings["hooks"]["Notification"] = [
                h for h in settings["hooks"]["Notification"]
                if h.get("hooks", [{}])[0].get("name") != "agent-notifier"
            ]
            gemini_settings.write_text(json.dumps(settings, indent=2), encoding="utf-8")
            print(f"Removed Gemini CLI hook: {gemini_settings}")

    if opencode_config.exists():
        settings = json.loads(opencode_config.read_text(encoding="utf-8"))
        if "plugin" in settings:
            # Remove local plugin and npm plugins
            settings["plugin"] = [
                p for p in settings["plugin"]
                if "agent-notifier" not in p.lower() and "opencode-notifier" not in p.lower()
            ]
            opencode_config.write_text(json.dumps(settings, indent=2), encoding="utf-8")
            print(f"Removed OpenCode plugin: {opencode_config}")
    
    # Remove local plugin file
    plugin_path = get_opencode_plugins_dir() / "agent-notifier.mjs"
    if plugin_path.exists():
        plugin_path.unlink()
        print(f"Removed plugin file: {plugin_path}")

    if cursor_hooks.exists():
        hooks = json.loads(cursor_hooks.read_text(encoding="utf-8"))
        if "stop" in hooks:
            hooks["stop"] = [
                h for h in hooks["stop"]
                if "agent-notifier" not in h.get("command", "") and "cursor_notify" not in h.get("command", "")
            ]
            cursor_hooks.write_text(json.dumps(hooks, indent=2), encoding="utf-8")
            print(f"Removed Cursor CLI hook: {cursor_hooks}")

    if codex_config.exists():
        import re
        content = codex_config.read_text(encoding="utf-8")
        content = re.sub(r'\n?notify\s*=\s*\[[^\]]*agent-notifier[^\]]*\]\n?', '\n', content)
        codex_config.write_text(content, encoding="utf-8")
        print(f"Removed Codex CLI hook: {codex_config}")


if __name__ == "__main__":
    sys.exit(main())
