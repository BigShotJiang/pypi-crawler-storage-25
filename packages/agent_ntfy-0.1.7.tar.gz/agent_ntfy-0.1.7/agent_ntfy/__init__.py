"""Agent Notifier - Cross-platform notification system for AI agents."""
__version__ = "0.1.0"
