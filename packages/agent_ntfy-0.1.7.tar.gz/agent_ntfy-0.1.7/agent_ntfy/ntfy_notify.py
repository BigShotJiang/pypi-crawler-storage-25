"""ntfy.sh notification support."""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


def notify_ntfy(
    title: str,
    message: str,
    topic: str,
    server: str = "https://ntfy.sh",
    token: Optional[str] = None,
    priority: str = "default",
    tags: Optional[list[str]] = None,
) -> bool:
    """
    Send notification via ntfy.sh using python-ntfy library.

    Args:
        title: Notification title
        message: Notification message body
        topic: ntfy.sh topic ID
        server: ntfy.sh server URL (default: https://ntfy.sh)
        token: Optional access token for private topics
        priority: Message priority (low, default, high, urgent)
        tags: List of tags for the notification

    Returns:
        True if notification was sent successfully, False otherwise.
    """
    try:
        from python_ntfy import NtfyClient

        priority_map = {
            "low": 1,
            "default": 3,
            "high": 4,
            "urgent": 5,
        }
        priority_value = priority_map.get(priority.lower(), 3)

        if tags is None:
            tags = ["robot"]

        client = NtfyClient(topic=topic, base_url=server, token=token)
        client.send(
            message=message,
            title=title,
            priority=priority_value,
            tags=tags,
        )
        logger.info(f"ntfy notification sent - Title: {title}, Topic: {topic}, Server: {server}")
        return True

    except ImportError:
        logger.error("python-ntfy not installed. Run: pip install python-ntfy")
        return False
    except Exception as e:
        logger.error(f"ntfy notification failed: {e}")
        return False
