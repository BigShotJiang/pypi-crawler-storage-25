"""RuntimeToolCallSmoke workflow package."""
