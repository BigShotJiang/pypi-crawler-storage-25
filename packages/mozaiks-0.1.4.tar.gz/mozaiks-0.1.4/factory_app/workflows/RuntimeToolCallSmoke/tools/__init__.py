"""Tools for RuntimeToolCallSmoke."""
