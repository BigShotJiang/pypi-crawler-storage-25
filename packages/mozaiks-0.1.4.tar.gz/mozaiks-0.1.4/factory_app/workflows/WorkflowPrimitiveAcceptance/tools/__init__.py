"""Tools for WorkflowPrimitiveAcceptance."""
