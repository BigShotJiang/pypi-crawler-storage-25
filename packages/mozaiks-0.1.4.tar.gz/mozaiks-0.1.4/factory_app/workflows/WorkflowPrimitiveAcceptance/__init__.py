"""WorkflowPrimitiveAcceptance workflow package."""
