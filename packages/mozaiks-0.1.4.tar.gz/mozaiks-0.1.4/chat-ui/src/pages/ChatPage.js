import { useEffect, useState, useRef, useCallback } from "react";
import Header from "../components/layout/Header";
import Footer from "../components/layout/Footer";
import ChatInterface from '../components/chat/ChatInterface';
import ArtifactPanel from '../components/chat/ArtifactPanel';
import WorkflowCompletion from '../components/chat/WorkflowCompletion';
import FluidChatLayout from '../components/chat/FluidChatLayout';
import MobileArtifactDrawer from '../components/chat/MobileArtifactDrawer';
import { TransitionScreen } from '../ui/screens/TransitionScreen';
import { applyArtifactUpdate, applyOptimisticUpdate, deriveArtifactId, interpolateParams } from '../core/actions/actionUtils';
import { useNavigate, useLocation } from "react-router-dom";
import { useContext } from "react";
import { useChatUI } from "../context/ChatUIContext";
import { NavigationContext } from "../providers/NavigationProvider";
import workflowConfig from '../config/workflowConfig';
import { getWorkflow } from '../@chat-workflows/index.js';
import resolveWorkflow from '../utils/resolveWorkflow';
import { dynamicUIHandler } from '../core/dynamicUIHandler';
import platform from '../platform/index.js';
import LoadingSpinner from '../utils/AgentChatLoadingSpinner';
import useTheme from "../styles/useTheme";
import {
  applyBrandImageFallback,
  getBrandLogoSrc,
  getChatBackgroundSrc,
} from "../styles/brandAssets";
import { readNavigationCache, writeNavigationCache } from '../navigation/navigationCache';
import ErrorBoundary, { ArtifactErrorFallback, ChatInterfaceErrorFallback } from '../components/ErrorBoundary';
import { useWorkflowStart } from '../hooks/useWorkflowStart';
import {
  clearStoredArtifactState,
  clearStoredChatCacheSeed,
  getStoredActiveChatId,
  getStoredActiveGeneralChatId,
  getStoredActiveWorkflowName,
  getStoredArtifactPanelOpen,
  getStoredChatCacheSeed,
  readStoredCurrentArtifact,
  readStoredLastArtifact,
  setStoredActiveChatId,
  setStoredArtifactPanelOpen,
  setStoredChatCacheSeed,
  writeStoredLastArtifact,
  writeStoredCurrentArtifact,
} from '../session/chatSessionStorage';

// Extracted hooks for gradual migration
// Usage: const { messages, addMessage, ... } = useConversation({ chatId, conversationMode, ... });
// import { useConversation, useArtifacts, useChatWebSocket } from './hooks';

// Debug utilities
const DEBUG_LOG_ALL_AGENT_OUTPUT = true;
const shouldDebugAllAgents = () => { try { const v = localStorage.getItem('mozaiks.debug_all_agents'); if (v!=null) return v==='1'||v==='true'; } catch{} return DEBUG_LOG_ALL_AGENT_OUTPUT; };
const logAgentOutput = (phase, agentName, content, meta={}) => { if(!shouldDebugAllAgents()) return; try { const prev = typeof content==='string'?content.slice(0,400):JSON.stringify(content); console.log(`🛰️ [${phase}]`, {agent:agentName||'Unknown', content:prev, ...meta}); } catch { console.log(`🛰️ [${phase}]`, {agent:agentName||'Unknown', content}); } };
// Generic localStorage gated debug flag helper (used for pipeline + render tracing)
const debugFlag = (k) => {
  try { return ['1','true','on','yes'].includes((localStorage.getItem(k)||'').toLowerCase()); } catch { return false; }
};

const getAccessToken = () => {
  if (typeof window !== 'undefined' && window.mozaiksAuth?.getAccessToken) {
    return window.mozaiksAuth.getAccessToken();
  }
  if (typeof localStorage !== 'undefined') {
    return localStorage.getItem('chatui_token') || localStorage.getItem('access_token');
  }
  return null;
};

const getUserIdFromToken = () => {
  const token = getAccessToken();
  if (!token || typeof token !== 'string') {
    return null;
  }
  const parts = token.split('.');
  if (parts.length < 2) {
    return null;
  }
  try {
    const normalized = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
    if (typeof window === 'undefined' || typeof window.atob !== 'function') {
      return null;
    }
    const json = window.atob(padded);
    const payload = JSON.parse(json);
    return payload?.sub || payload?.user_id || payload?.preferred_username || null;
  } catch (_err) {
    return null;
  }
};

const formatHistoryTimestamp = (timestamp) => {
  if (!timestamp) return 'Just now';
  try {
    const parsed = new Date(timestamp);
    if (Number.isNaN(parsed.getTime())) return 'Just now';
    return parsed.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  } catch {
    return 'Just now';
  }
};

const AskHistorySidebar = ({
  sessions = [],
  activeChatId,
  loading,
  onSelectChat,
  onStartNewChat,
  onRefresh,
  onClear,
}) => {
  const hasSessions = Array.isArray(sessions) && sessions.length > 0;
  return (
    <aside className="hidden lg:flex flex-col w-64 xl:w-72 2xl:w-80 shrink-0 self-stretch min-h-0 h-full rounded-2xl border border-[rgba(var(--color-primary-light-rgb),0.25)] bg-[rgba(2,6,23,0.72)] backdrop-blur-xl shadow-[0_20px_60px_rgba(2,6,23,0.6)] px-4 py-4 text-sm text-slate-100">
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="text-[11px] tracking-[0.2em] uppercase text-[rgba(148,163,184,0.9)]">Ask</p>
          <h2 className="text-lg font-semibold">Recent Conversations</h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="px-2 py-1 rounded-lg border border-[rgba(248,113,113,0.45)] text-[11px] tracking-wide text-[rgba(254,202,202,0.92)] hover:text-white hover:border-[rgba(248,113,113,0.8)] transition disabled:opacity-60"
            onClick={onClear}
            disabled={loading}
          >
            Clear
          </button>
          <button
            type="button"
            className="px-2 py-1 rounded-lg border border-[rgba(var(--color-primary-light-rgb),0.4)] text-[11px] tracking-wide text-[rgba(148,163,184,0.9)] hover:text-white hover:border-[rgba(var(--color-primary-light-rgb),0.8)] transition"
            onClick={onRefresh}
            disabled={loading}
          >
            {loading ? '…' : 'Refresh'}
          </button>
        </div>
      </div>
      <div className="mt-3 flex flex-col gap-2">
        <button
          type="button"
          onClick={onStartNewChat}
          className="w-full inline-flex items-center justify-center gap-2 rounded-xl border border-[rgba(var(--color-secondary-rgb),0.35)] bg-[rgba(var(--color-secondary-rgb),0.12)] py-2 text-sm font-semibold text-white hover:border-[rgba(var(--color-secondary-rgb),0.55)] hover:bg-[rgba(var(--color-secondary-rgb),0.18)] transition"
        >
          <span className="text-base" aria-hidden="true">＋</span>
          New Chat
        </button>
        <p className="text-[12px] text-[rgba(148,163,184,0.9)]">{hasSessions ? `${sessions.length} saved session${sessions.length === 1 ? '' : 's'}` : 'No saved conversations yet.'}</p>
      </div>
      <div className="mt-3 flex-1 overflow-y-auto my-scroll1 pr-1 space-y-2">
        {hasSessions ? (
          sessions.map((session) => {
            const chatId = session?.chat_id;
            if (!chatId) return null;
            const isActive = chatId === activeChatId;
            const label = session?.label || `Chat ${chatId.slice(-4)}`;
            const summary = session?.summary || session?.last_message_preview || 'Tap to resume conversation.';
            const timestamp = formatHistoryTimestamp(session?.last_updated_at || session?.updated_at);
            return (
              <button
                key={chatId}
                type="button"
                onClick={() => onSelectChat(chatId)}
                className={`w-full text-left rounded-2xl border px-3 py-2 transition focus:outline-none focus:ring-2 focus:ring-[rgba(var(--color-primary-light-rgb),0.6)] ${isActive
                  ? 'border-[rgba(var(--color-primary-light-rgb),0.7)] bg-[rgba(var(--color-primary-rgb),0.15)] shadow-[0_10px_35px_rgba(6,182,212,0.15)]'
                  : 'border-[rgba(148,163,184,0.2)] bg-[rgba(15,23,42,0.65)] hover:border-[rgba(148,163,184,0.4)] hover:bg-[rgba(15,23,42,0.8)]'}`}
              >
                <div className="flex items-center justify-between text-[11px] text-[rgba(148,163,184,0.95)]">
                  <span className="font-semibold text-[rgba(226,232,240,0.9)] text-sm">{label}</span>
                  <span>{timestamp}</span>
                </div>
                <p className="mt-1 text-[13px] leading-relaxed text-[rgba(226,232,240,0.8)] max-h-[3.6rem] overflow-hidden">{summary}</p>
              </button>
            );
          })
        ) : (
          <div className="rounded-2xl border border-dashed border-[rgba(148,163,184,0.4)] px-3 py-6 text-center text-[13px] text-[rgba(148,163,184,0.9)]">
            Start a conversation to see it appear here.
          </div>
        )}
      </div>
    </aside>
  );
};

const MobileAskHistoryDrawer = ({
  mode = 'ask',
  open,
  sessions = [],
  activeChatId,
  loading,
  onSelectChat,
  onSelectWorkflow,
  onStartNewChat,
  onStartEntryWorkflow,
  onRefresh,
  onClear,
  onClose,
}) => {
  if (!open) {
    return null;
  }

  const isWorkflowMode = mode === 'workflow';
  const hasSessions = Array.isArray(sessions) && sessions.length > 0;
  const title = isWorkflowMode ? 'Recent Workflows' : 'Recent Chats';
  const modeLabel = isWorkflowMode ? 'Workflow' : 'Ask';
  const emptyText = isWorkflowMode
    ? 'Start a workflow run to see it appear here.'
    : 'Start a conversation to see it appear here.';
  const countText = hasSessions
    ? `${sessions.length} saved ${isWorkflowMode ? `workflow run${sessions.length === 1 ? '' : 's'}` : `conversation${sessions.length === 1 ? '' : 's'}`}`
    : (isWorkflowMode ? 'No saved workflow runs yet.' : 'No saved conversations yet.');
  const launchButtonLabel = isWorkflowMode ? 'Open Workflow' : 'New Chat';

  return (
    <div className="fixed inset-0 z-[70] lg:hidden pointer-events-none">
      <button
        type="button"
        aria-label={`Close ${modeLabel} history`}
        className="absolute inset-0 bg-black/55 backdrop-blur-sm pointer-events-auto"
        onClick={onClose}
      ></button>
      <div className="absolute inset-x-0 bottom-0 pointer-events-auto px-2 sm:px-3 pb-[calc(env(safe-area-inset-bottom,0px)+0.35rem)]">
        <div className="mx-auto w-full max-w-3xl rounded-t-3xl border border-[rgba(var(--color-primary-light-rgb),0.35)] bg-[rgba(5,10,24,0.96)] backdrop-blur-2xl shadow-[0_20px_60px_rgba(2,6,23,0.85)] flex flex-col overflow-hidden max-h-[min(78dvh,720px)]">
          <div className="flex justify-center pt-2 pb-1">
            <div className="h-1 w-10 rounded-full bg-[rgba(148,163,184,0.45)]" />
          </div>

          <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-[rgba(var(--color-primary-light-rgb),0.25)]">
            <div>
              <p className="text-[10px] tracking-[0.3em] uppercase text-[rgba(148,163,184,0.8)]">{modeLabel}</p>
              <h2 className="text-base font-semibold text-white">{title}</h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[rgba(var(--color-primary-light-rgb),0.35)] text-[11px] tracking-[0.15em] uppercase text-[rgba(226,232,240,0.95)] hover:border-[rgba(var(--color-primary-light-rgb),0.75)] hover:text-white transition"
            >
              <span aria-hidden="true">←</span>
              Back To Chat
            </button>
          </div>

          <div className="px-4 py-3 border-b border-[rgba(148,163,184,0.35)]">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  if (isWorkflowMode) {
                    onStartEntryWorkflow?.();
                  } else {
                    onStartNewChat?.();
                  }
                  onClose?.();
                }}
                className="flex-1 inline-flex items-center justify-center gap-2 rounded-xl border border-[rgba(var(--color-secondary-rgb),0.35)] bg-[rgba(var(--color-secondary-rgb),0.15)] py-2 text-sm font-semibold text-white"
              >
                <span className="text-lg" aria-hidden="true">＋</span>
                {launchButtonLabel}
              </button>
              <button
                type="button"
                onClick={onRefresh}
                disabled={loading}
                className="px-3 py-2 rounded-xl border border-[rgba(var(--color-primary-light-rgb),0.35)] text-xs text-[rgba(148,163,184,0.95)] hover:border-[rgba(var(--color-primary-light-rgb),0.7)] hover:text-white transition disabled:opacity-60"
              >
                {loading ? '…' : 'Refresh'}
              </button>
              <button
                type="button"
                onClick={onClear}
                disabled={loading}
                className="px-3 py-2 rounded-xl border border-[rgba(248,113,113,0.45)] text-xs text-[rgba(254,202,202,0.95)] hover:border-[rgba(248,113,113,0.8)] hover:text-white transition disabled:opacity-60"
              >
                Clear
              </button>
            </div>
            <p className="mt-2 text-[12px] text-[rgba(148,163,184,0.9)]">
              {countText}
            </p>
          </div>

          <div className="flex-1 overflow-y-auto my-scroll1 px-3 py-3 space-y-2">
            {hasSessions ? (
              sessions.map((session) => {
                const chatId = session?.chat_id;
                if (!chatId) return null;
                const isActive = chatId === activeChatId;
                const label = isWorkflowMode
                  ? (session?.workflow_name || `Workflow ${chatId.slice(-4)}`)
                  : (session?.label || `Chat ${chatId.slice(-4)}`);
                const summary = isWorkflowMode
                  ? (session?.last_artifact?.component_name
                      ? `Last artifact: ${session.last_artifact.component_name}`
                      : 'Tap to resume workflow run.')
                  : (session?.summary || session?.last_message_preview || 'Tap to resume conversation.');
                const timestamp = formatHistoryTimestamp(session?.last_updated_at || session?.updated_at);
                return (
                  <button
                    key={chatId}
                    type="button"
                    onClick={() => {
                      if (isWorkflowMode) {
                        onSelectWorkflow?.(chatId, session?.workflow_name || null);
                      } else {
                        onSelectChat?.(chatId);
                      }
                      onClose?.();
                    }}
                    className={`w-full text-left rounded-2xl border px-3 py-2 transition focus:outline-none focus:ring-2 focus:ring-[rgba(var(--color-primary-light-rgb),0.6)] ${isActive
                      ? 'border-[rgba(var(--color-primary-light-rgb),0.7)] bg-[rgba(var(--color-primary-rgb),0.15)] shadow-[0_10px_35px_rgba(6,182,212,0.15)]'
                      : 'border-[rgba(148,163,184,0.2)] bg-[rgba(15,23,42,0.65)] hover:border-[rgba(148,163,184,0.4)] hover:bg-[rgba(15,23,42,0.8)]'}`}
                  >
                    <div className="flex items-center justify-between text-[11px] text-[rgba(148,163,184,0.95)]">
                      <span className="font-semibold text-[rgba(226,232,240,0.95)] text-sm">{label}</span>
                      <span>{timestamp}</span>
                    </div>
                    <p className="mt-1 text-[13px] leading-relaxed text-[rgba(226,232,240,0.85)] max-h-[3.6rem] overflow-hidden">{summary}</p>
                  </button>
                );
              })
            ) : (
              <div className="rounded-2xl border border-dashed border-[rgba(148,163,184,0.4)] px-3 py-6 text-center text-[13px] text-[rgba(148,163,184,0.9)]">
                {emptyText}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const WorkflowHistorySidebar = ({
  sessions = [],
  activeChatId,
  loading,
  onSelectSession,
  onRefresh,
  onClear,
  onStartEntryWorkflow,
}) => {
  const hasSessions = Array.isArray(sessions) && sessions.length > 0;
  return (
    <aside className="hidden lg:flex flex-col w-64 xl:w-72 2xl:w-80 shrink-0 self-stretch min-h-0 h-full rounded-2xl border border-[rgba(var(--color-primary-light-rgb),0.25)] bg-[rgba(2,6,23,0.72)] backdrop-blur-xl shadow-[0_20px_60px_rgba(2,6,23,0.6)] px-4 py-4 text-sm text-slate-100">
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="text-[11px] tracking-[0.2em] uppercase text-[rgba(148,163,184,0.9)]">Workflow</p>
          <h2 className="text-lg font-semibold">Recent Workflows</h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="px-2 py-1 rounded-lg border border-[rgba(248,113,113,0.45)] text-[11px] tracking-wide text-[rgba(254,202,202,0.92)] hover:text-white hover:border-[rgba(248,113,113,0.8)] transition disabled:opacity-60"
            onClick={onClear}
            disabled={loading}
          >
            Clear
          </button>
          <button
            type="button"
            className="px-2 py-1 rounded-lg border border-[rgba(var(--color-primary-light-rgb),0.4)] text-[11px] tracking-wide text-[rgba(148,163,184,0.9)] hover:text-white hover:border-[rgba(var(--color-primary-light-rgb),0.8)] transition"
            onClick={onRefresh}
            disabled={loading}
          >
            {loading ? '…' : 'Refresh'}
          </button>
        </div>
      </div>
      <div className="mt-3 flex flex-col gap-2">
        <button
          type="button"
          onClick={onStartEntryWorkflow}
          className="w-full inline-flex items-center justify-center gap-2 rounded-xl border border-[rgba(var(--color-secondary-rgb),0.35)] bg-[rgba(var(--color-secondary-rgb),0.12)] py-2 text-sm font-semibold text-white hover:border-[rgba(var(--color-secondary-rgb),0.55)] hover:bg-[rgba(var(--color-secondary-rgb),0.18)] transition"
        >
          <span className="text-base" aria-hidden="true">▶</span>
          Open Workflow
        </button>
        <p className="text-[12px] text-[rgba(148,163,184,0.9)]">{hasSessions ? `${sessions.length} active run${sessions.length === 1 ? '' : 's'}` : 'No active workflows yet.'}</p>
      </div>
      <div className="mt-3 flex-1 overflow-y-auto my-scroll1 pr-1 space-y-2">
        {hasSessions ? (
          sessions.map((session) => {
            const chatId = session?.chat_id;
            if (!chatId) return null;
            const workflowName = session?.workflow_name || 'Workflow';
            const isActive = chatId === activeChatId;
            const summary = session?.last_artifact?.component_name
              ? `Last artifact: ${session.last_artifact.component_name}`
              : 'Tap to resume workflow run.';
            const timestamp = formatHistoryTimestamp(session?.last_updated_at || session?.updated_at || session?.created_at);
            return (
              <button
                key={chatId}
                type="button"
                onClick={() => onSelectSession(chatId, workflowName)}
                className={`w-full text-left rounded-2xl border px-3 py-2 transition focus:outline-none focus:ring-2 focus:ring-[rgba(var(--color-primary-light-rgb),0.6)] ${isActive
                  ? 'border-[rgba(var(--color-primary-light-rgb),0.7)] bg-[rgba(var(--color-primary-rgb),0.15)] shadow-[0_10px_35px_rgba(6,182,212,0.15)]'
                  : 'border-[rgba(148,163,184,0.2)] bg-[rgba(15,23,42,0.65)] hover:border-[rgba(148,163,184,0.4)] hover:bg-[rgba(15,23,42,0.8)]'}`}
              >
                <div className="flex items-center justify-between text-[11px] text-[rgba(148,163,184,0.95)]">
                  <span className="font-semibold text-[rgba(226,232,240,0.9)] text-sm">{workflowName}</span>
                  <span>{timestamp}</span>
                </div>
                <p className="mt-1 text-[13px] leading-relaxed text-[rgba(226,232,240,0.8)] max-h-[3.6rem] overflow-hidden">{summary}</p>
              </button>
            );
          })
        ) : (
          <div className="rounded-2xl border border-dashed border-[rgba(148,163,184,0.4)] px-3 py-6 text-center text-[13px] text-[rgba(148,163,184,0.9)]">
            Start a workflow run to see it appear here.
          </div>
        )}
      </div>
    </aside>
  );
};

const ChatPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  // Navigation config (null-safe — dev shell may omit NavigationProvider)
  const navContext = useContext(NavigationContext);
  const configuredStartupMode = navContext?.chat_startup_mode || 'ask';  // "ask" or "workflow"
  const configuredEntryWorkflow = navContext?.entry_point || null;
  const configuredResumePolicy = 'last_active_then_oldest_then_entry_point';
  const navigationLoading = navContext?.loading ?? false;
  // Core state
  const [messages, setMessages] = useState([]);
  // Ref mirror to access latest messages inside callbacks without stale closure
  const messagesRef = useRef([]);
  useEffect(() => { messagesRef.current = messages; }, [messages]);
  const [ws, setWs] = useState(null);
  const wsRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const setMessagesWithLogging = useCallback(updater => setMessages(prev => typeof updater==='function'?updater(prev):updater), []);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [transportType, setTransportType] = useState(null);
  const [modeChangePending, setModeChangePending] = useState(false);
  const [currentChatId, setCurrentChatId] = useState(null); // set via start/resume flow below
  const LOCAL_STORAGE_KEY = 'mozaiks.current_chat_id';
  const [, setConnectionInitialized] = useState(false);
  const [workflowConfigLoaded, setWorkflowConfigLoaded] = useState(false); // becomes true once workflow config resolved
  const [cacheSeed, setCacheSeed] = useState(null); // per-chat cache seed for unified backend/frontend caching
  const [chatExists, setChatExists] = useState(null); // tri-state: null=unknown, true=exists, false=new
  const connectionInProgressRef = useRef(false);
  // Guard to prevent overlapping start logic (used by preflight existence effect)
  const pendingStartRef = useRef(false);
  const conversationBootstrapRef = useRef(false);
  const modeChangeInProgressRef = useRef(false);
  const pathSegments = location.pathname.split('/').filter(Boolean);
  let pathAppId = null;
  let pathWorkflowName = null;
  const isPrimaryChatRoute = pathSegments.length === 0 || pathSegments[0] === 'chat' || pathSegments[0] === 'app';
  const lastPrimaryRouteRef = useRef(isPrimaryChatRoute);

  if (pathSegments[0] === 'chat') {
    pathAppId = pathSegments[1] || null;
    pathWorkflowName = pathSegments[2] || null;
  } else if (pathSegments[0] === 'app') {
    pathAppId = pathSegments[1] || null;
    pathWorkflowName = pathSegments[2] || null;
  }

  const searchParams = new URLSearchParams(location.search || '');
  const queryAppId = searchParams.get('appId') || searchParams.get('app_id');
  const queryWorkflowName = searchParams.get('workflow');
  const queryChatId = searchParams.get('chat_id');
  const queryMode = searchParams.get('mode'); // 'ask' or 'workflow'
  const queryEmbeddedView = searchParams.get('view');
  const queryResume = searchParams.get('resume');
  // Gate / action / refinement context — set by useWorkflowStart
  // e.g. /chat?workflow=AppGenerator&context={"app_type":"new"}&trigger_source=gate
  const queryContextRaw = searchParams.get('context');
  const queryContext = (() => {
    if (!queryContextRaw) return null;
    try { return JSON.parse(queryContextRaw); } catch { return null; }
  })();
  const queryTriggerSource = searchParams.get('trigger_source') || 'chat';
  const queryActionId = searchParams.get('action_id') || null;
  const queryChangeClass = searchParams.get('change_class') || null;
  const queryArtifactVersionId = searchParams.get('artifact_version_id') || null;

  const appId = pathAppId || queryAppId;
  const urlWorkflowName = pathWorkflowName || queryWorkflowName;
  const {
    user,
    api,
    config,
    logout,
    activeChatId,
    setActiveChatId,
    activeWorkflowName,
    setActiveWorkflowName,
    setChatMinimized,
    layoutMode,
    setLayoutMode,
    isArtifactOpen,
    setIsArtifactOpen,
    widgetOverlayOpen,
    setWidgetOverlayOpen,
    dispatchSurfaceEvent,
    dispatchSurfaceAction,
    currentArtifactContext,
    setCurrentArtifactContext,
    isInWidgetMode,
    setIsInWidgetMode,
    conversationMode,
    setConversationMode,
    activeGeneralChatId,
    setActiveGeneralChatId,
    generalChatSummary,
    setGeneralChatSummary,
    generalChatSessions,
    setGeneralChatSessions,
    workflowSessions,
    setWorkflowSessions,
    askMessages,
    setAskMessages,
    workflowMessages,
    setWorkflowMessages,
    pendingNavigationTrigger,
    setPendingNavigationTrigger,
    surfaceState,
  } = useChatUI();
  const surfaceStateRef = useRef(surfaceState);
  useEffect(() => {
    surfaceStateRef.current = surfaceState;
  }, [surfaceState]);
  const isSidePanelOpen = isArtifactOpen;
  const setIsSidePanelOpen = setIsArtifactOpen;
  const [forceOverlay, setForceOverlay] = useState(false);
  const [widgetChatMinimized, setWidgetChatMinimized] = useState(false);
  const [isAskHistoryDrawerOpen, setIsAskHistoryDrawerOpen] = useState(false);
  const [pendingTransitionId, setPendingTransitionId] = useState(null);
  const [pendingTransitionContext, setPendingTransitionContext] = useState({});
  
  // Mobile-specific state
  const [isMobileView, setIsMobileView] = useState(false);
  const [mobileDrawerState, setMobileDrawerState] = useState('peek'); // 'hidden' | 'peek' | 'expanded'
  const [hasUnseenChat, setHasUnseenChat] = useState(false);
  const [hasUnseenArtifact, setHasUnseenArtifact] = useState(false);
  const [actionStatusMap, setActionStatusMap] = useState({});
  const [pendingWorkflowReply, setPendingWorkflowReply] = useState(null);
  const [pendingHarnessDecision, setPendingHarnessDecision] = useState(null);
  const [pendingHarnessDecisionError, setPendingHarnessDecisionError] = useState(null);
  const optimisticSnapshotsRef = useRef(new Map());
  
  // Current artifact messages rendered inside ArtifactPanel (not in chat messages)
  const [currentArtifactMessages, setCurrentArtifactMessages] = useState([]);
  const currentArtifactMessagesRef = useRef([]);
  useEffect(() => {
    currentArtifactMessagesRef.current = currentArtifactMessages;
  }, [currentArtifactMessages]);
  const navTriggerRef = useRef(null);
  const navCacheContextRef = useRef(null);
  const embeddedViewHandledRef = useRef(false);
  const viewArtifactSnapshotRef = useRef(null);
  // Track the most recent artifact-mode UI event id to manage auto-collapse
  const lastArtifactEventRef = useRef(null);
  // Prevent duplicate restores per connection
  const artifactRestoredOnceRef = useRef(false);
  const artifactCacheValidRef = useRef(false);
  const lastErrorIdRef = useRef(null); // Track last error to prevent duplicates
  const workflowMessagesCacheRef = useRef([]);
  const workflowReplayPendingRef = useRef(false);
  const workflowMessagesSharedRef = useRef([]);
  const generalMessagesCacheRef = useRef([]);
  const resumeOldestFromWidgetRef = useRef(false);
  const layoutModeForConversation = conversationMode === 'ask' ? 'full' : layoutMode;
  // Respect explicit layout state in workflow mode; force full in ask mode.
  const effectiveLayoutMode = conversationMode === 'ask' ? 'full' : layoutMode;
  const isViewMode = effectiveLayoutMode === 'view';
  const mainPaddingClass = 'pt-14 md:pt-16';
  const mainContentStyle = isMobileView
    ? { paddingTop: 'calc(env(safe-area-inset-top, 0px) + 3.5rem)' }
    : undefined;
  const chatPageShellStyle = isMobileView
    ? { height: '100vh', minHeight: '100dvh' }
    : undefined;

  const defaultWorkflow = resolveWorkflow(urlWorkflowName) || '';
  const [currentWorkflowName, setCurrentWorkflowName] = useState(defaultWorkflow);
  const currentWorkflowNameRef = useRef(defaultWorkflow);

  useEffect(() => {
    currentWorkflowNameRef.current = currentWorkflowName || activeWorkflowName || urlWorkflowName || '';
  }, [activeWorkflowName, currentWorkflowName, urlWorkflowName]);

  const normalizeComparableText = (value) => String(value || '').replace(/\s+/g, ' ').trim();

  const shouldSuppressHiddenWorkflowMessage = useCallback((message) => {
    if (!message || typeof message !== 'object') {
      return false;
    }

    const directSeedKind = message._mozaiks_seed_kind || message.metadata?._mozaiks_seed_kind;
    if (directSeedKind === 'initial_message' || directSeedKind === 'userdriven_trigger') {
      return true;
    }

    const workflowName = String(
      currentWorkflowNameRef.current || currentWorkflowName || activeWorkflowName || urlWorkflowName || ''
    ).trim();
    if (!workflowName || !workflowConfig?.getWorkflowConfig) {
      return false;
    }

    const wfCfg = workflowConfig.getWorkflowConfig(workflowName);
    const startupMode = String(wfCfg?.startup_mode || '').trim().toLowerCase();
    if (startupMode === 'userdriven') {
      return false;
    }

    const hiddenInitialMessage = normalizeComparableText(wfCfg?.initial_message);
    const content = normalizeComparableText(message.content);
    if (!hiddenInitialMessage || !content || content !== hiddenInitialMessage) {
      return false;
    }

    const metadata = message.metadata && typeof message.metadata === 'object'
      ? message.metadata
      : null;
    const normalizedSender = String(
      message.sender
      || message.agent
      || message.agentName
      || message.agent_name
      || ''
    ).trim().toLowerCase();
    const normalizedRole = String(message.role || '').trim().toLowerCase();
    const source = String(metadata?.source || '').trim().toLowerCase();

    return normalizedSender === 'user'
      || normalizedRole === 'user'
      || source === 'workflow_user'
      || Boolean(metadata?.input_request_id);
  }, [activeWorkflowName, currentWorkflowName, urlWorkflowName, workflowConfig]);

  const sanitizeVisibleWorkflowMessages = useCallback((messageList) => {
    if (!Array.isArray(messageList) || messageList.length === 0) {
      return [];
    }
    return messageList.filter((message) => !shouldSuppressHiddenWorkflowMessage(message));
  }, [shouldSuppressHiddenWorkflowMessage]);

  const isAskModeWorkflowLeak = useCallback((event) => {
    if (conversationMode !== 'ask' || !event || typeof event !== 'object') {
      return false;
    }

    const metadata = event.metadata && typeof event.metadata === 'object'
      ? event.metadata
      : event.data?.metadata && typeof event.data?.metadata === 'object'
        ? event.data.metadata
        : {};
    const source = String(metadata?.source || '').trim().toLowerCase();

    if (source === 'general_agent') {
      return false;
    }

    const normalizedAgentName = String(
      event.agentName
      || event.agent
      || event.agent_name
      || ''
    ).trim().toLowerCase();

    const sender = String(
      event.sender
      || event.agent
      || event.agent_name
      || event.agentName
      || ''
    ).trim().toLowerCase();
    const role = String(event.role || '').trim().toLowerCase();
    const seedKind = String(
      event._mozaiks_seed_kind
      || metadata?._mozaiks_seed_kind
      || ''
    ).trim().toLowerCase();

    if (seedKind === 'initial_message' || seedKind === 'userdriven_trigger') {
      return true;
    }

    if (source === 'workflow_user') {
      return true;
    }

    if (Boolean(metadata?.input_request_id)) {
      return true;
    }

    if (source && source !== 'general_agent' && sender !== 'system' && role !== 'system') {
      return true;
    }

    if (!source && normalizedAgentName.endsWith('agent') && normalizedAgentName !== 'assistant') {
      return true;
    }

    return sender === 'user' || role === 'user';
  }, [conversationMode]);

  const sanitizeVisibleAskMessages = useCallback((messageList) => {
    if (!Array.isArray(messageList) || messageList.length === 0) {
      return [];
    }
    return messageList.filter((message) => !isAskModeWorkflowLeak(message));
  }, [isAskModeWorkflowLeak]);

  const resolveKnownWorkflowName = useCallback((preferredWorkflow = null) => {
    const explicitKnownWorkflow = workflowConfig.resolveKnownWorkflowName(preferredWorkflow);
    if (explicitKnownWorkflow) {
      return explicitKnownWorkflow;
    }
    return resolveWorkflow() || workflowConfig.getDefaultWorkflow() || null;
  }, []);

  const restoreStoredArtifactForChat = useCallback((chatId, fallbackWorkflowName = null) => {
    if (!chatId) {
      return false;
    }

    try {
      const cachedCurrent = readStoredCurrentArtifact(chatId);
      const cachedLast = readStoredLastArtifact(chatId);
      const cached = cachedCurrent || cachedLast;
      if (!cached?.tool_name) {
        return false;
      }

      const shouldOpen = getStoredArtifactPanelOpen(chatId);
        const restoredMsg = {
          id: `ui-restored-${Date.now()}`,
          sender: 'agent',
          agentName: cached.payload?.agentName || cached.payload?.agent_name || cached.agentName || cached.agent_name || 'Agent',
          content: cached.payload?.structured_output || cached.payload || {},
          isStreaming: false,
          toolCall: {
            tool_name: cached.tool_name,
            payload: cached.payload || {},
            tool_call_id: cached.tool_call_id || null,
            workflow_name: cached.workflow_name || fallbackWorkflowName || currentWorkflowName,
            onResponse: undefined,
            display: cached.display || 'artifact',
            restored: true,
          },
        };

      setCurrentArtifactMessages([restoredMsg]);
      lastArtifactEventRef.current = cached.tool_call_id || restoredMsg.id;
      artifactCacheValidRef.current = true;
      artifactRestoredOnceRef.current = true;

      if (shouldOpen !== false) {
        setIsSidePanelOpen(true);
        if (setLayoutMode) {
          setLayoutMode('split');
        }
      }

      return true;
    } catch (e) {
      console.warn('[RESTORE] Failed to restore artifact from stored session:', e);
      return false;
    }
  }, [currentWorkflowName, setIsSidePanelOpen, setLayoutMode]);

  useEffect(() => {
    if (typeof setCurrentArtifactContext !== 'function') {
      return;
    }
    if (!currentArtifactMessages || currentArtifactMessages.length === 0) {
      setCurrentArtifactContext(null);
      return;
    }
    const artifactMsg = currentArtifactMessages.find(m => m?.toolCall?.tool_name) || currentArtifactMessages[0];
    const toolCall = artifactMsg?.toolCall;
    if (!toolCall) {
      setCurrentArtifactContext(null);
      return;
    }
    setCurrentArtifactContext({
      id: toolCall.tool_call_id || artifactMsg.id || null,
      type: toolCall.tool_name,
      payload: toolCall.payload || null,
      artifact_id: deriveArtifactId(toolCall.payload, toolCall.tool_call_id || artifactMsg.id || null),
      chat_id: currentChatId,
      workflow_name: currentWorkflowName,
    });
  }, [currentArtifactMessages, currentChatId, currentWorkflowName, setCurrentArtifactContext]);

  useEffect(() => {
    if (!currentChatId || conversationMode !== 'workflow') {
      return;
    }
    setStoredArtifactPanelOpen(currentChatId, isSidePanelOpen);
  }, [currentChatId, conversationMode, isSidePanelOpen]);

  useEffect(() => {
    if (!currentChatId) return;
    if (!Array.isArray(currentArtifactMessages) || currentArtifactMessages.length === 0) return;
    const artifactMsg = currentArtifactMessages.find(m => m?.toolCall?.payload) || currentArtifactMessages[0];
    const toolCall = artifactMsg?.toolCall;
    if (!toolCall) return;

    const payload = toolCall.payload || {};
    const displayMode = toolCall.display || payload.display || payload.mode || 'artifact';
    if (displayMode !== 'artifact') return;

    const artifactPayload = {
      ...payload,
      artifact_id: deriveArtifactId(payload, toolCall.tool_call_id || artifactMsg?.id || null),
    };

    try {
      const serializableArtifact = {
        ...artifactMsg,
        toolCall: {
          ...toolCall,
          payload: artifactPayload,
          onResponse: null,
        },
      };
      writeStoredCurrentArtifact(currentChatId, serializableArtifact);

      writeStoredLastArtifact(currentChatId, {
        tool_name: toolCall.tool_name || 'core.state',
        tool_call_id: toolCall.tool_call_id || null,
        workflow_name: toolCall.workflow_name || currentWorkflowName,
        payload: artifactPayload,
        display: displayMode || 'artifact',
        ts: Date.now(),
      });
      artifactCacheValidRef.current = true;
    } catch (e) {
      console.warn('Failed to persist artifact cache', e);
    }

    try {
      const navCache = navCacheContextRef.current;
      if (navCache?.cache_ttl && artifactPayload) {
        const artifactWorkflow = toolCall.workflow_name || currentWorkflowName;
        if (!navCache.workflow || navCache.workflow === artifactWorkflow) {
          const cacheWorkflow = navCache.workflow || artifactWorkflow;
          if (cacheWorkflow) {
            writeNavigationCache(
              cacheWorkflow,
              navCache?.input ?? null,
              {
                tool_name: toolCall.tool_name || 'core.state',
                tool_call_id: toolCall.tool_call_id || null,
                workflow_name: cacheWorkflow,
                payload: artifactPayload,
                display: displayMode || 'artifact',
              },
              navCache.cache_ttl,
            );
          }
        }
      }
    } catch (e) {
      console.warn('Failed to update nav-trigger cache', e);
    }
  }, [currentArtifactMessages, currentChatId, currentWorkflowName]);
  const generalHydrationPendingRef = useRef(false);
  const askModeSyncedChatRef = useRef(null);
  const workflowArtifactSnapshotRef = useRef({ isOpen: false, messages: [], layoutMode: 'split' });
  const queryResumeHandledRef = useRef(null);
  const validatedChatIdRef = useRef(null);
  const validatingChatIdRef = useRef(false);

  useEffect(() => {
    const sanitizedWorkflowMessages = sanitizeVisibleWorkflowMessages(workflowMessages);
    workflowMessagesSharedRef.current = sanitizedWorkflowMessages;
    if (Array.isArray(workflowMessages) && sanitizedWorkflowMessages.length !== workflowMessages.length) {
      setWorkflowMessages(sanitizedWorkflowMessages);
    }
  }, [sanitizeVisibleWorkflowMessages, setWorkflowMessages, workflowMessages]);
  
  useEffect(() => {
    if (conversationMode === 'workflow') {
      // Resume clears the visible transcript briefly while the backend replays.
      // Keep the last shared workflow snapshot intact during that window.
      if (!(workflowReplayPendingRef.current && messages.length === 0)) {
        const sanitizedMessages = sanitizeVisibleWorkflowMessages(messages);
        workflowMessagesCacheRef.current = sanitizedMessages;
        workflowMessagesSharedRef.current = sanitizedMessages;
        setWorkflowMessages(sanitizedMessages);
      }
    } else {
      generalMessagesCacheRef.current = sanitizeVisibleAskMessages(messages);
    }
    if (conversationMode === 'ask') {
      setAskMessages(sanitizeVisibleAskMessages(messages));
    }
  }, [messages, conversationMode, sanitizeVisibleAskMessages, sanitizeVisibleWorkflowMessages, setAskMessages, setWorkflowMessages]);

  useEffect(() => {
    if (conversationMode !== 'ask') {
      return;
    }
    if (!Array.isArray(messages) || messages.length === 0) {
      return;
    }

    const sanitizedMessages = sanitizeVisibleAskMessages(messages);
    if (sanitizedMessages.length === messages.length) {
      return;
    }

    console.log(`🧹 [ASK_SANITIZE] Removing ${messages.length - sanitizedMessages.length} workflow message(s) from ask transcript`);
    generalMessagesCacheRef.current = sanitizedMessages;
    setAskMessages(sanitizedMessages);
    setMessagesWithLogging(sanitizedMessages);
  }, [conversationMode, messages, sanitizeVisibleAskMessages, setAskMessages, setMessagesWithLogging]);

  useEffect(() => {
    if (conversationMode !== 'workflow') {
      return;
    }
    if (!Array.isArray(messages) || messages.length === 0) {
      return;
    }

    const sanitizedMessages = sanitizeVisibleWorkflowMessages(messages);
    if (sanitizedMessages.length === messages.length) {
      return;
    }

    console.log(`🧹 [WORKFLOW_SANITIZE] Removing ${messages.length - sanitizedMessages.length} hidden seed message(s) from workflow transcript`);
    workflowMessagesCacheRef.current = sanitizedMessages;
    workflowMessagesSharedRef.current = sanitizedMessages;
    setWorkflowMessages(sanitizedMessages);
    setMessagesWithLogging(sanitizedMessages);
  }, [conversationMode, messages, sanitizeVisibleWorkflowMessages, setMessagesWithLogging, setWorkflowMessages]);
  
  // Note: Artifact panel restoration is handled directly in ensureWorkflowMode with setTimeout
  const implicitDevAppId =
    process.env.NODE_ENV !== 'production' &&
    process.env.REACT_APP_ALLOW_IMPLICIT_APP_ID === 'true'
      ? 'local-dev'
      : null;

  const currentAppId =
    appId ||
    config?.chat?.defaultAppId ||
    navContext?.appId ||
    config?.appId ||
    config?.app_id ||
    process.env.REACT_APP_DEFAULT_APP_ID ||
    process.env.REACT_APP_DEFAULT_app_id ||
    implicitDevAppId ||
    null;
  const { theme: chatTheme, loading: themeLoading } = useTheme(currentAppId);
  const brandLogoSrc = getBrandLogoSrc(chatTheme);
  const chatBackgroundSrc = getChatBackgroundSrc(chatTheme);
  const resolvedAppDisplayName = String(
    navContext?.appName ||
    config?.appName ||
    config?.app_name ||
    chatTheme?.branding?.name ||
    'MozaiksAI'
  ).trim() || 'MozaiksAI';
  const currentUserId = user?.id || user?.user_id || user?.sub || getUserIdFromToken() || 'anonymous';
  const {
    startWorkflow: startPendingHarnessWorkflow,
    starting: pendingHarnessDecisionBusy,
    error: pendingHarnessWorkflowStartError,
  } = useWorkflowStart();
  const buildPendingHarnessDecision = useCallback((decision, fallback = null) => {
    const source = decision && typeof decision === 'object' ? decision : null;
    const base = fallback && typeof fallback === 'object' ? fallback : {};
    const decisionId = String(
      source?.decision_id
      || base.decision_id
      || base.change_request_id
      || base.revision_id
      || ''
    ).trim();
    const decisionType = String(source?.decision_type || base.decision_type || '').trim();
    const message = String(source?.message || base.message || '').trim();
    const rationale = String(source?.rationale || base.rationale || '').trim();
    if (!decisionId || !decisionType || !message || !rationale) {
      return null;
    }

    const normalizeAction = (action) => {
      if (!action || typeof action !== 'object') {
        return null;
      }
      const actionId = String(action.action_id || '').trim();
      const label = String(action.label || '').trim();
      if (!actionId || !label) {
        return null;
      }
      return {
        action_id: actionId,
        label,
        action_type: String(action.action_type || 'run_workflow').trim() || 'run_workflow',
        workflow_id: String(action.workflow_id || '').trim() || null,
        metadata: action.metadata && typeof action.metadata === 'object' ? { ...action.metadata } : {},
      };
    };

    const actions = (
      Array.isArray(source?.actions)
        ? source.actions
        : Array.isArray(base.actions)
          ? base.actions
          : []
    )
      .map(normalizeAction)
      .filter(Boolean);

    const selectedPaths = (
      Array.isArray(source?.selected_paths)
        ? source.selected_paths
        : Array.isArray(base.selected_paths)
          ? base.selected_paths
          : []
    )
      .map((path) => String(path || '').trim())
      .filter(Boolean);

    return {
      decision_id: decisionId,
      decision_type: decisionType,
      message,
      rationale,
      confidence: Number(source?.confidence ?? base.confidence ?? 0) || 0,
      recommended_workflow_id: String(
        source?.recommended_workflow_id
        || base.recommended_workflow_id
        || ''
      ).trim() || null,
      selected_paths: selectedPaths,
      clarification_question: String(
        source?.clarification_question
        || base.clarification_question
        || ''
      ).trim() || null,
      change_request_id: String(
        source?.change_request_id
        || base.change_request_id
        || ''
      ).trim() || null,
      revision_id: String(source?.revision_id || base.revision_id || '').trim() || null,
      requires_confirmation: Boolean(
        source?.requires_confirmation ?? base.requires_confirmation ?? false
      ),
      trigger_source: String(source?.trigger_source || base.trigger_source || 'refinement').trim() || 'refinement',
      requested_workflow_id: String(
        source?.requested_workflow_id
        || base.requested_workflow_id
        || ''
      ).trim() || null,
      journey_id: String(source?.journey_id || base.journey_id || '').trim() || null,
      context_variables: source?.context_variables && typeof source.context_variables === 'object'
        ? { ...source.context_variables }
        : base.context_variables && typeof base.context_variables === 'object'
          ? { ...base.context_variables }
          : {},
      trigger_payload: source?.trigger_payload && typeof source.trigger_payload === 'object'
        ? { ...source.trigger_payload }
        : base.trigger_payload && typeof base.trigger_payload === 'object'
          ? { ...base.trigger_payload }
          : {},
      actions,
      metadata: source?.metadata && typeof source.metadata === 'object'
        ? { ...source.metadata }
        : base.metadata && typeof base.metadata === 'object'
          ? { ...base.metadata }
          : {},
    };
  }, []);
  const applySessionStatePendingHarnessDecision = useCallback((sessionState) => {
    const nextDecision = buildPendingHarnessDecision(sessionState?.pending_harness_decision);
    setPendingHarnessDecision(nextDecision);
    if (!nextDecision) {
      setPendingHarnessDecisionError(null);
    }
  }, [buildPendingHarnessDecision]);
  const handlePendingHarnessDecisionAction = useCallback(async (action) => {
    if (!pendingHarnessDecision || !action) {
      return;
    }

    setPendingHarnessDecisionError(null);
    const workflowId = action.workflow_id
      || pendingHarnessDecision.recommended_workflow_id
      || pendingHarnessDecision.requested_workflow_id
      || currentWorkflowName
      || null;
    const contextVariables = {
      ...(pendingHarnessDecision.context_variables || {}),
    };
    const triggerPayload = {
      ...(pendingHarnessDecision.trigger_payload || {}),
      harness_action: {
        action_id: action.action_id,
      },
    };
    if (pendingHarnessDecision.change_request_id && !triggerPayload.change_request_id) {
      triggerPayload.change_request_id = pendingHarnessDecision.change_request_id;
    }
    if (pendingHarnessDecision.revision_id && !triggerPayload.revision_id) {
      triggerPayload.revision_id = pendingHarnessDecision.revision_id;
    }

    const result = await startPendingHarnessWorkflow(workflowId, contextVariables, {
      trigger_source: pendingHarnessDecision.trigger_source || 'refinement',
      journey_id: pendingHarnessDecision.journey_id || null,
      app_id: currentAppId || null,
      user_id: currentUserId || null,
      trigger_payload: triggerPayload,
    });

    if (!result) {
      setPendingHarnessDecisionError(
        pendingHarnessWorkflowStartError || 'Failed to continue this harness decision.'
      );
      return;
    }

    if (result.execution_mode === 'harness_decision') {
      const nextDecision = buildPendingHarnessDecision(
        result.harness_decision,
        {
          ...pendingHarnessDecision,
          trigger_source: pendingHarnessDecision.trigger_source || 'refinement',
          requested_workflow_id: workflowId,
          recommended_workflow_id: result.workflow_id || workflowId || pendingHarnessDecision.recommended_workflow_id,
          journey_id: pendingHarnessDecision.journey_id || null,
          context_variables: contextVariables,
          trigger_payload: triggerPayload,
          change_request_id: triggerPayload.change_request_id || pendingHarnessDecision.change_request_id,
          revision_id: triggerPayload.revision_id || pendingHarnessDecision.revision_id,
        },
      );
      setPendingHarnessDecision(nextDecision);
      setPendingHarnessDecisionError(null);
      return;
    }

    setPendingHarnessDecision(null);
    setPendingHarnessDecisionError(null);
  }, [
    buildPendingHarnessDecision,
    currentAppId,
    currentUserId,
    currentWorkflowName,
    pendingHarnessDecision,
    pendingHarnessWorkflowStartError,
    startPendingHarnessWorkflow,
  ]);
  useEffect(() => {
    if (pendingHarnessWorkflowStartError) {
      setPendingHarnessDecisionError(pendingHarnessWorkflowStartError);
    }
  }, [pendingHarnessWorkflowStartError]);
  const consumeNavigationQueryParams = useCallback((keys = []) => {
    if (!Array.isArray(keys) || keys.length === 0) {
      return;
    }

    const params = new URLSearchParams(location.search || '');
    let changed = false;
    for (const key of keys) {
      if (params.has(key)) {
        params.delete(key);
        changed = true;
      }
    }

    if (!changed) {
      return;
    }

    const nextSearch = params.toString();
    navigate(`${location.pathname}${nextSearch ? `?${nextSearch}` : ''}`, { replace: true });
  }, [location.pathname, location.search, navigate]);
  const [generalSessionsLoading, setGeneralSessionsLoading] = useState(false);
  const [workflowSessionsLoading, setWorkflowSessionsLoading] = useState(false);
  // Workflow completion state
  const [workflowCompleted, setWorkflowCompleted] = useState(false);
  const [completionData, setCompletionData] = useState(null);
  const resolveNavMode = (mode) => {
    const normalized = typeof mode === 'string' ? mode.toLowerCase() : 'workflow';
    if (normalized === 'view' || normalized === 'ask' || normalized === 'workflow') {
      return normalized;
    }
    return 'workflow';
  };
  const resolveNavLayoutMode = (mode) => {
    if (mode === 'view') return 'view';
    if (mode === 'ask') return 'full';
    return 'split';
  };
  // CRITICAL: Clear widget mode immediately when ChatPage mounts on a primary chat route.
  // This must happen regardless of connection status so the UI doesn't show stale widget state.
  useEffect(() => {
    if (isPrimaryChatRoute && isInWidgetMode) {
      console.log('🧭 [WIDGET_MODE] ChatPage mounted on primary route - clearing widget mode immediately');
      setIsInWidgetMode(false);
    }
  }, [isPrimaryChatRoute, isInWidgetMode, setIsInWidgetMode]);

  useEffect(() => {
    if (urlWorkflowName && urlWorkflowName !== currentWorkflowName) {
      console.log('🧭 [WORKFLOW_ROUTE] Updating workflow from URL param:', urlWorkflowName);
      setCurrentWorkflowName(urlWorkflowName);
    }
  }, [urlWorkflowName, currentWorkflowName]);

  useEffect(() => {
    if (!workflowConfigLoaded) {
      return;
    }

    const nextWorkflowName =
      workflowConfig.resolveKnownWorkflowName(urlWorkflowName)
      || workflowConfig.resolveKnownWorkflowName(currentWorkflowName)
      || workflowConfig.resolveKnownWorkflowName(activeWorkflowName)
      || workflowConfig.resolveKnownWorkflowName(getStoredActiveWorkflowName())
      || resolveWorkflow()
      || workflowConfig.getDefaultWorkflow()
      || null;

    if (!nextWorkflowName) {
      return;
    }

    if (nextWorkflowName !== currentWorkflowName) {
      console.log('🧭 [WORKFLOW_SYNC] Normalizing current workflow to loaded config:', nextWorkflowName);
      setCurrentWorkflowName(nextWorkflowName);
    }
    if (nextWorkflowName !== activeWorkflowName) {
      console.log('🧭 [WORKFLOW_SYNC] Normalizing active workflow to loaded config:', nextWorkflowName);
      setActiveWorkflowName(nextWorkflowName);
    }
  }, [workflowConfigLoaded, urlWorkflowName, currentWorkflowName, activeWorkflowName, setActiveWorkflowName]);

  useEffect(() => {
    if (!pendingNavigationTrigger) return;
    const trigger = pendingNavigationTrigger;
    const triggerId = trigger?.id || `${trigger?.workflow || 'nav'}-${trigger?.requested_at || Date.now()}`;
    if (navTriggerRef.current === triggerId) return;
    navTriggerRef.current = triggerId;

    const resolvedMode = resolveNavMode(trigger?.mode);
    const nextLayoutMode = resolveNavLayoutMode(resolvedMode);
    if (layoutMode !== nextLayoutMode) {
      setLayoutMode(nextLayoutMode);
    }
    if (resolvedMode === 'ask' && conversationMode !== 'ask') {
      setConversationMode('ask');
    }
    if (resolvedMode !== 'ask' && conversationMode !== 'workflow') {
      setConversationMode('workflow');
    }

    const nextWorkflow = trigger?.workflow || resolveWorkflow() || currentWorkflowName;
    if (nextWorkflow && nextWorkflow !== currentWorkflowName) {
      setCurrentWorkflowName(nextWorkflow);
    }
    if (nextWorkflow) {
      setActiveWorkflowName(nextWorkflow);
    }

    try {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    } catch {}
    pendingStartRef.current = false;
    connectionInProgressRef.current = false;
    setConnectionInitialized(false);
    setConnectionStatus('disconnected');
    setLoading(true);
    if (wsRef.current && typeof wsRef.current.close === 'function') {
      wsRef.current.close();
    }
    wsRef.current = null;
    setWs(null);
    setCurrentChatId(null);
    setActiveChatId(null);

    setMessagesWithLogging([]);
    setCurrentArtifactMessages([]);
    setWorkflowCompleted(false);
    setCompletionData(null);
    lastArtifactEventRef.current = null;
    artifactRestoredOnceRef.current = false;
    artifactCacheValidRef.current = false;

    navCacheContextRef.current = null;
    if (trigger?.cache_ttl && nextWorkflow) {
      navCacheContextRef.current = {
        workflow: nextWorkflow,
        input: trigger?.input ?? null,
        cache_ttl: trigger.cache_ttl,
      };
      const cached = readNavigationCache(nextWorkflow, trigger?.input ?? null);
      if (cached?.artifact) {
        const cachedEvent = cached.artifact;
        const cachedPayload = {
          ...(cachedEvent?.payload || {}),
          artifact_id: deriveArtifactId(cachedEvent?.payload || {}, cachedEvent?.tool_call_id || null),
        };
        const artifactMsg = {
          id: `nav-cache-${Date.now()}`,
          sender: 'agent',
          agentName: cachedEvent?.agentName || cachedEvent?.agent_name || 'Agent',
          content: cachedPayload.structured_output || cachedPayload.content || cachedPayload || {},
          isStreaming: false,
          toolCall: {
            tool_name: cachedEvent?.tool_name || cachedEvent?.tool || 'core.cached',
            payload: cachedPayload,
            tool_call_id: cachedEvent?.tool_call_id || null,
            workflow_name: cachedEvent?.workflow_name || nextWorkflow,
            onResponse: null,
            display: cachedEvent?.display || 'artifact',
          }
        };
        setCurrentArtifactMessages([artifactMsg]);
        setIsSidePanelOpen(true);
        artifactCacheValidRef.current = true;
      }
    }

    if (typeof setPendingNavigationTrigger === 'function') {
      setPendingNavigationTrigger(null);
    }
  }, [
    pendingNavigationTrigger,
    currentWorkflowName,
    layoutMode,
    conversationMode,
    setLayoutMode,
    setConversationMode,
    setCurrentWorkflowName,
    setActiveWorkflowName,
    setConnectionInitialized,
    setConnectionStatus,
    setLoading,
    setWs,
    setCurrentChatId,
    setActiveChatId,
    setMessagesWithLogging,
    setCurrentArtifactMessages,
    setWorkflowCompleted,
    setCompletionData,
    setIsSidePanelOpen,
    setPendingNavigationTrigger,
  ]);

  // One-time initial spinner: show after websocket connects, hide after first agent chat.text message
  const [showInitSpinner, setShowInitSpinner] = useState(false);
  // Refs for race-free spinner control
  const initSpinnerShownRef = useRef(false);
  const initSpinnerHiddenOnceRef = useRef(false);
  // Removed dynamic UI accumulation & dedupe refs (no longer needed with chat.* events)


  // Helper function to extract agent name from nested message structure
  const extractAgentName = useCallback((data) => {
    try {
      // First try direct agent field
      if (data.agent && data.agent !== 'Unknown') {
        return data.agent;
      }
      if (data.agentName && data.agentName !== 'Unknown') {
        return data.agentName;
      }
      if (data.agent_name && data.agent_name !== 'Unknown') {
        return data.agent_name;
      }
      
      // Parse content if it's a JSON string containing nested agent info
      if (data.content && typeof data.content === 'string') {
        const parsed = JSON.parse(data.content);
        if (parsed?.data?.content?.sender) {
          return parsed.data.content.sender;
        }
        if (parsed?.data?.agent) {
          return parsed.data.agent;
        }
      }
      
      return 'Agent'; // fallback
    } catch {
      return data.agent || data.agent_name || 'Agent';
    }
  }, []);

  const shouldSuppressConsecutiveAssistantDuplicate = useCallback((messageList, { agentName, content, source } = {}) => {
    if (source !== 'general_agent') {
      return false;
    }

    const normalizedContent = String(content || '').trim();
    if (!normalizedContent || !Array.isArray(messageList) || messageList.length === 0) {
      return false;
    }

    for (let i = messageList.length - 1; i >= 0; i -= 1) {
      const candidate = messageList[i];
      if (!candidate || candidate.isThinking) {
        continue;
      }
      if (candidate.sender === 'system') {
        continue;
      }
      if (candidate.sender === 'user') {
        return false;
      }
      if (candidate.__streaming) {
        return false;
      }

      const candidateContent = String(candidate.content || '').trim();
      const candidateSource = candidate.metadata?.source || null;
      return candidate.sender === 'agent'
        && candidate.agentName === agentName
        && candidateContent === normalizedContent
        && candidateSource === source;
    }

    return false;
  }, []);

  const getSeedKindFromEvent = useCallback((eventData) => {
    if (!eventData || typeof eventData !== 'object') {
      return null;
    }
    const directSeedKind = eventData._mozaiks_seed_kind || eventData.data?._mozaiks_seed_kind;
    if (typeof directSeedKind === 'string' && directSeedKind.trim()) {
      return directSeedKind.trim();
    }
    const metadata = eventData.metadata && typeof eventData.metadata === 'object'
      ? eventData.metadata
      : eventData.data?.metadata && typeof eventData.data.metadata === 'object'
        ? eventData.data.metadata
        : null;
    const metadataSeedKind = metadata?._mozaiks_seed_kind;
    return typeof metadataSeedKind === 'string' && metadataSeedKind.trim()
      ? metadataSeedKind.trim()
      : null;
  }, []);

  const normalizeSeedComparableText = useCallback((value) => {
    return normalizeComparableText(value);
  }, []);

  const shouldSuppressLegacyHiddenInitialReplay = useCallback((eventData) => {
    if (!eventData || typeof eventData !== 'object') {
      return false;
    }

    if (!(eventData.replay || eventData.data?.replay)) {
      return false;
    }

    const workflowName = String(
      currentWorkflowNameRef.current || currentWorkflowName || activeWorkflowName || urlWorkflowName || ''
    ).trim();
    if (!workflowName || !workflowConfig?.getWorkflowConfig) {
      return false;
    }

    const wfCfg = workflowConfig.getWorkflowConfig(workflowName);
    const startupMode = String(wfCfg?.startup_mode || '').trim().toLowerCase();
    if (startupMode === 'userdriven') {
      return false;
    }

    const hiddenInitialMessage = normalizeSeedComparableText(wfCfg?.initial_message);
    if (!hiddenInitialMessage) {
      return false;
    }

    const content = normalizeSeedComparableText(eventData.content || eventData.data?.content);
    if (!content || content !== hiddenInitialMessage) {
      return false;
    }

    const metadata = eventData.metadata && typeof eventData.metadata === 'object'
      ? eventData.metadata
      : eventData.data?.metadata && typeof eventData.data.metadata === 'object'
        ? eventData.data.metadata
        : null;
    const normalizedAgent = String(
      eventData.agent
      || eventData.agent_name
      || eventData.sender
      || eventData.data?.agent
      || eventData.data?.agent_name
      || eventData.data?.sender
      || ''
    ).trim().toLowerCase();
    const normalizedRole = String(eventData.role || eventData.data?.role || '').trim().toLowerCase();
    const source = String(metadata?.source || '').trim().toLowerCase();

    return normalizedAgent === 'user'
      || normalizedRole === 'user'
      || source === 'workflow_user'
      || Boolean(metadata?.input_request_id);
  }, [activeWorkflowName, currentWorkflowName, normalizeSeedComparableText, urlWorkflowName, workflowConfig]);

  const shouldSuppressHiddenSeedEvent = useCallback((eventData) => {
    const seedKind = getSeedKindFromEvent(eventData);
    return seedKind === 'initial_message'
      || seedKind === 'userdriven_trigger'
      || shouldSuppressLegacyHiddenInitialReplay(eventData);
  }, [getSeedKindFromEvent, shouldSuppressLegacyHiddenInitialReplay]);

  const refreshGeneralSessions = useCallback(async () => {
    if (!api || !currentAppId || !currentUserId) {
      return [];
    }
    setGeneralSessionsLoading(true);
    try {
      const result = await api.listGeneralChats(currentAppId, currentUserId, 50);
      const sessions = Array.isArray(result?.sessions) ? result.sessions : [];
      setGeneralChatSessions(sessions);
      return sessions;
    } catch (err) {
      console.error('Failed to list general chats:', err);
      return [];
    } finally {
      setGeneralSessionsLoading(false);
    }
  }, [api, currentAppId, currentUserId, setGeneralChatSessions]);

  const refreshWorkflowSessions = useCallback(async () => {
    if (!api || typeof api.get !== 'function' || !currentAppId || !currentUserId) {
      return [];
    }
    setWorkflowSessionsLoading(true);
    try {
      const result = await api.get(`/api/sessions/list/${currentAppId}/${currentUserId}`);
      const sessions = Array.isArray(result?.sessions) ? result.sessions : [];
      setWorkflowSessions(sessions);
      return sessions;
    } catch (err) {
      console.error('Failed to list workflow sessions:', err);
      setWorkflowSessions([]);
      return [];
    } finally {
      setWorkflowSessionsLoading(false);
    }
  }, [api, currentAppId, currentUserId, setWorkflowSessions]);

  const mapGeneralMessage = useCallback((message) => {
    if (!message) {
      return null;
    }
    const timestamp = (() => {
      if (!message.timestamp) return Date.now();
      try {
        return new Date(message.timestamp).getTime();
      } catch (_) {
        return Date.now();
      }
    })();
    return {
      id: message.event_id || `general-${message.sequence || Date.now()}`,
      sender: message.role === 'assistant' ? 'agent' : 'user',
      agentName: message.role === 'assistant' ? 'Assistant' : 'You',
      content: message.content,
      isStreaming: false,
      timestamp,
      metadata: message.metadata || {},
    };
  }, []);

  const hydrateGeneralTranscript = useCallback(async (chatId, options = {}) => {
    if (!api || !chatId) {
      return;
    }
    try {
      const transcript = await api.fetchGeneralChatTranscript(currentAppId, chatId, options);
      if (!transcript) {
        return;
      }
      const normalized = (transcript.messages || [])
        .map(mapGeneralMessage)
        .filter(Boolean);
      generalMessagesCacheRef.current = normalized;
      if (conversationMode === 'ask') {
        setMessagesWithLogging(normalized);
      }
      setActiveGeneralChatId(transcript.chat_id);
      setGeneralChatSummary({
        chatId: transcript.chat_id,
        label: transcript.label || transcript.chat_id,
        lastUpdatedAt: transcript.last_updated_at,
        lastSequence: transcript.last_sequence,
      });
      setGeneralChatSessions((prev) => {
        if (!Array.isArray(prev) || !transcript.chat_id) {
          return prev;
        }
        const next = [...prev];
        const idx = next.findIndex((session) => session?.chat_id === transcript.chat_id);
        if (idx === -1) {
          return prev;
        }
        next[idx] = {
          ...next[idx],
          label: transcript.label || next[idx]?.label,
          last_updated_at: transcript.last_updated_at,
          lastSequence: transcript.last_sequence,
          sequence: transcript.sequence ?? next[idx]?.sequence,
        };
        return next;
      });
    } catch (err) {
      console.error('Failed to hydrate general chat transcript:', err);
    }
  }, [api, conversationMode, currentAppId, mapGeneralMessage, setActiveGeneralChatId, setGeneralChatSummary, setGeneralChatSessions, setMessagesWithLogging]);

  useEffect(() => {
    if (!api || !currentAppId || !currentUserId) {
      return;
    }
    refreshGeneralSessions();
  }, [api, currentAppId, currentUserId, refreshGeneralSessions]);

  useEffect(() => {
    if (!api || !currentAppId || !currentUserId) {
      return;
    }
    if (conversationMode !== 'workflow') {
      return;
    }
    refreshWorkflowSessions();
  }, [api, currentAppId, currentUserId, conversationMode, refreshWorkflowSessions]);

  useEffect(() => {
    if (conversationBootstrapRef.current) {
      return;
    }
    // Wait for navigation config so ai.chat.chat_startup_mode can be honored.
    // Explicit URL mode (?mode=ask|workflow) still takes precedence immediately.
    if (!queryMode && navigationLoading) {
      return;
    }
    conversationBootstrapRef.current = true;
    console.log('🧭 [BOOTSTRAP] chat_startup_mode resolved to:', configuredStartupMode);
    
    // Respect explicit mode from URL query param (e.g., ?mode=ask from widget navigation)
    if (queryMode === 'ask') {
      console.log('🧭 [BOOTSTRAP] Explicit ask mode requested via URL param');
      setConversationMode('ask');
      consumeNavigationQueryParams(['mode', 'resume', 'chat_id']);
      // Restore shared ask-mode messages if available (widget uses askMessages)
      if (askMessages && askMessages.length > 0) {
        setMessagesWithLogging(askMessages);
      } else if (generalMessagesCacheRef.current && generalMessagesCacheRef.current.length > 0) {
        setMessagesWithLogging(generalMessagesCacheRef.current);
      }
      // Close artifact panel in a setTimeout to ensure it happens AFTER all other effects
      // This is necessary because other effects may try to restore/open the panel
      setTimeout(() => {
        console.log('🧹 [BOOTSTRAP] Closing artifact panel for Ask mode');
        setIsSidePanelOpen(false);
        setCurrentArtifactMessages([]);
        // IMPORTANT: Also set layoutMode to 'full' - this controls desktop artifact visibility
        if (setLayoutMode) setLayoutMode('full');
      }, 50);
      return;
    }
    
    // Handle explicit workflow mode request (e.g., from widget Mozaiks logo button)
    if (queryMode === 'workflow') {
      console.log('🧭 [BOOTSTRAP] Explicit workflow mode requested via URL param');
      setConversationMode('workflow');
      consumeNavigationQueryParams(['mode', 'resume']);
      if (!queryChatId && queryResume === 'oldest') {
        resumeOldestFromWidgetRef.current = true;
      }
      
      // Try to restore artifact state from snapshot or platform storage (works offline)
      const snapshot = workflowArtifactSnapshotRef.current;
      if (snapshot?.isOpen && snapshot?.messages?.length > 0) {
        console.log('🎨 [BOOTSTRAP] Restoring artifact panel from in-memory snapshot');
        setTimeout(() => {
          setIsSidePanelOpen(true);
          setCurrentArtifactMessages(snapshot.messages);
          if (snapshot.layoutMode && setLayoutMode) {
            setLayoutMode(snapshot.layoutMode);
          }
        }, 100);
      } else {
        const restoreChatId = queryChatId || currentChatId || activeChatId || getStoredActiveChatId();
        if (restoreChatId) {
          const restored = restoreStoredArtifactForChat(restoreChatId, urlWorkflowName);
          if (restored) {
            console.log('🎨 [BOOTSTRAP] Restored artifact from stored session', restoreChatId);
          }
        }
      }
      return;
    }
    
    // Default to configured chat_startup_mode (from app/config/ai.json)
    // "ask" = start in Ask mode, "workflow" = go directly to entry_point workflow
    const startupDefault = configuredStartupMode;
    if (startupDefault === 'ask') {
      console.log('🧭 [BOOTSTRAP] chat_startup_mode is "ask" — entering Ask mode');
      setConversationMode('ask');
      setTimeout(() => {
        setIsSidePanelOpen(false);
        setCurrentArtifactMessages([]);
        if (setLayoutMode) setLayoutMode('full');
      }, 50);
    } else if (conversationMode !== 'workflow') {
      setConversationMode('workflow');
    }
  }, [conversationMode, setConversationMode, queryMode, queryChatId, queryResume, urlWorkflowName, setLayoutMode, askMessages, setMessagesWithLogging, configuredStartupMode, navigationLoading, consumeNavigationQueryParams]);

  // Keep backend/session mode aligned when startup lands directly in Ask mode.
  // Without this, the UI can show Ask while backend remains in workflow context.
  useEffect(() => {
    if (conversationMode !== 'ask') return;
    if (connectionStatus !== 'connected') return;
    if (!currentChatId) return;
    if (askModeSyncedChatRef.current === currentChatId) return;

    const activeWs = wsRef.current;
    if (!activeWs || typeof activeWs.send !== 'function') return;

    const sent = activeWs.send({ type: 'chat.enter_general_mode', chat_id: currentChatId });
    if (sent) {
      askModeSyncedChatRef.current = currentChatId;
      console.log('🧭 [ASK_SYNC] chat.enter_general_mode sent for chat:', currentChatId);
    }
  }, [conversationMode, connectionStatus, currentChatId]);

  // Separate effect to enforce Ask mode artifact panel state
  // This ensures the panel stays closed even if other effects try to open it
  // IMPORTANT: Check conversationMode (actual mode) not queryMode (URL param)
  // because user can toggle mode via UI without changing the URL
  useEffect(() => {
    if (conversationMode === 'ask' && (isSidePanelOpen || layoutMode !== 'full')) {
      console.log('🧹 [ASK_MODE_ENFORCER] Closing artifact panel (Ask mode should not have artifacts)');
      setIsSidePanelOpen(false);
      setCurrentArtifactMessages([]);
      // IMPORTANT: Also set layoutMode to 'full' - this controls desktop artifact visibility
      if (setLayoutMode) setLayoutMode('full');
    }
  }, [conversationMode, isSidePanelOpen, layoutMode, setLayoutMode]);

  useEffect(() => {
    if (conversationMode === 'workflow') {
      const cached = sanitizeVisibleWorkflowMessages(workflowMessagesCacheRef.current);
      if (cached) {
        setMessagesWithLogging(cached);
      }
      return;
    }
    if (conversationMode !== 'ask') {
      return;
    }
    if (generalMessagesCacheRef.current && generalMessagesCacheRef.current.length > 0) {
      setMessagesWithLogging(generalMessagesCacheRef.current);
      return;
    }
    if ((!generalMessagesCacheRef.current || generalMessagesCacheRef.current.length === 0) && messagesRef.current.length > 0) {
      setMessagesWithLogging([]);
    }
    if (!activeGeneralChatId || generalHydrationPendingRef.current) {
      return;
    }
    generalHydrationPendingRef.current = true;
    Promise.resolve(hydrateGeneralTranscript(activeGeneralChatId)).finally(() => {
      generalHydrationPendingRef.current = false;
    });
  }, [activeGeneralChatId, conversationMode, hydrateGeneralTranscript, setMessagesWithLogging]);

  useEffect(() => {
    if (conversationMode !== 'workflow') return;
    if (workflowReplayPendingRef.current) return;
    if (messagesRef.current && messagesRef.current.length > 0) return;
    const restoredWorkflowMessages = sanitizeVisibleWorkflowMessages(workflowMessages);
    if (restoredWorkflowMessages.length > 0) {
      console.log(`📦 [WORKFLOW_RESTORE] Restoring ${restoredWorkflowMessages.length} shared workflow messages`);
      setMessagesWithLogging(restoredWorkflowMessages);
    }
  }, [conversationMode, sanitizeVisibleWorkflowMessages, workflowMessages, setMessagesWithLogging]);

  const updateArtifactPayload = useCallback((artifactId, updateFn) => {
    if (!updateFn) return;
    setCurrentArtifactMessages((prev) => {
      if (!Array.isArray(prev) || prev.length === 0) return prev;
      let updated = false;
      const next = prev.map((msg) => {
        const payload = msg?.toolCall?.payload;
        if (!msg?.toolCall) return msg;
        const resolvedId = deriveArtifactId(payload, msg?.toolCall?.tool_call_id || msg?.id);
        if (artifactId && resolvedId !== artifactId) return msg;
        updated = true;
        const nextPayload = updateFn(payload || {});
        return {
          ...msg,
          toolCall: {
            ...msg.toolCall,
            payload: nextPayload,
          },
        };
      });
      if (updated) return next;
      // Fallback: apply to most recent artifact if id mismatch
      const lastIdx = prev.length - 1;
      const last = prev[lastIdx];
      if (last?.toolCall) {
        const nextPayload = updateFn(last.toolCall.payload || {});
        const fallback = [...prev];
        fallback[lastIdx] = {
          ...last,
          toolCall: {
            ...last.toolCall,
            payload: nextPayload,
          },
        };
        return fallback;
      }
      return prev;
    });
  }, [setCurrentArtifactMessages]);

  const applyOptimisticForAction = useCallback((actionId, artifactId, optimistic) => {
    if (!optimistic) return;
    updateArtifactPayload(artifactId, (payload) => {
      if (!optimisticSnapshotsRef.current.has(actionId)) {
        let snapshotPayload = payload;
        try {
          if (payload && typeof payload === 'object') {
            snapshotPayload = JSON.parse(JSON.stringify(payload));
          }
        } catch {}
        optimisticSnapshotsRef.current.set(actionId, { artifactId, payload: snapshotPayload });
      }
      return applyOptimisticUpdate(payload, optimistic);
    });
  }, [updateArtifactPayload]);

  const applyArtifactUpdateForAction = useCallback((artifactId, update) => {
    if (!update) return;
    updateArtifactPayload(artifactId, (payload) => applyArtifactUpdate(payload, update));
  }, [updateArtifactPayload]);
  const handleIncomingRef = useRef(null);

  // Simplified incoming handler (namespaced chat.* only)
  const handleIncoming = useCallback((data) => {
    // Log all incoming events for debugging - you can filter this later if needed
    if (data?.type) {
      try { logAgentOutput('INCOMING', extractAgentName(data), data, { type: data?.type }); } catch {}
    }
    if (!data?.type) return;
    if (dispatchSurfaceEvent) {
      dispatchSurfaceEvent(data);
    }
    const showSystemMessages = debugFlag('mozaiks.show_system_messages') || debugFlag('mozaiks.debug_pipeline');
    // Robust spinner hide: only once
    try {
      if (initSpinnerShownRef.current && !initSpinnerHiddenOnceRef.current) {
        const outerType = data.type || '';
        const isText = outerType === 'chat.text';
        const isMeta = outerType === 'chat_meta' || outerType === 'chat.chat_meta';
        const isStreamChunk = outerType === 'chat.stream_chunk';
        const serializedText = !isText && typeof data.content === 'string' && data.content.includes('"type":"chat.text"');
        if (isText || isMeta || isStreamChunk || serializedText) {
          initSpinnerHiddenOnceRef.current = true;
          if (showInitSpinner) console.log('🧹 [SPINNER] Hiding spinner (ready event). text?', isText, 'meta?', isMeta, 'serialized?', serializedText);
          setShowInitSpinner(false);
        }
      }
    } catch {}
    if (debugFlag('mozaiks.debug_pipeline')) {
      const agentDbg = data.agent || data.agent_name;
      console.log('[PIPELINE] raw event', {
        type: data.type,
        agent: agentDbg,
        visual: data.is_visual,
        structuredCapable: data.is_structured_capable,
        hasStructuredOutput: !!data.structured_output,
        contentPreview: (data.content||'').slice(0,120)
      });
      if ((data.type === 'chat.print' || data.type === 'chat.text') && data.is_visual === false) {
        console.warn('[PIPELINE] Non-visual agent message received (unexpected?)', agentDbg);
      }
    }

    // Handle chat_meta events (which may not have chat. prefix)
    if (data.type === 'chat_meta' || data.type === 'chat.chat_meta') {
      // Initial metadata handshake from backend
      console.log('🧬 [META] Received chat_meta event:', data);
      applySessionStatePendingHarnessDecision(data.session_state);
      if (data.cache_seed !== undefined && data.cache_seed !== null) {
        setCacheSeed(data.cache_seed);
        if (currentChatId) {
          setStoredChatCacheSeed(currentChatId, data.cache_seed);
        }
        console.log('🧬 [META] Received cache_seed', data.cache_seed, 'for chat', currentChatId);
      }
      if (data.chat_exists === false) {
        // Backend indicates this chat_id had no persisted session (fresh after client-side reuse)
        setChatExists(false);
        console.log('🧬 [META] Backend reports chat did NOT previously exist. Suppressing artifact restore. chat_id=', currentChatId);
        clearStoredArtifactState(currentChatId);
        console.log('🧼 [META] Purged stale artifacts for non-existent chat');
        // Reset any prior artifact state
        setCurrentArtifactMessages([]);
        lastArtifactEventRef.current = null;
        artifactCacheValidRef.current = false;
        artifactRestoredOnceRef.current = true; // prevent later restore effect
      } else if (data.chat_exists === true) {
        setChatExists(true);
        console.log('🧬 [META] Backend confirms chat exists. Artifact restore allowed.');
        if (!data.last_artifact || !data.last_artifact.tool_name) {
          clearStoredArtifactState(currentChatId);
          setCurrentArtifactMessages([]);
          lastArtifactEventRef.current = null;
          artifactRestoredOnceRef.current = false;
          artifactCacheValidRef.current = false;
        }

        // If backend already sent last_artifact and we have not restored yet, cache it for restore effect
        if (!artifactRestoredOnceRef.current && data.last_artifact && data.last_artifact.tool_name) {
          try {
            writeStoredLastArtifact(currentChatId, {
              tool_name: data.last_artifact.tool_name,
              tool_call_id: data.last_artifact.tool_call_id || null,
              workflow_name: data.last_artifact.workflow_name || currentWorkflowName,
              payload: data.last_artifact.payload || {},
              display: data.last_artifact.display || 'artifact',
              ts: Date.now(),
            });
            console.log('🧬 [META] Cached last_artifact from server meta event');
            artifactCacheValidRef.current = true;
          } catch (e) { console.warn('Failed to cache server last_artifact', e); }
        }
      }
      return;
    }
    
    // Some backends double-serialize the envelope: outer {type, content: JSON-stringified {type:"chat.text", data:{...}}}
    // Detect and unwrap once so downstream logic always works with a flat object.
    // Do this BEFORE checking for chat. prefix so we can unwrap "unknown" events that contain chat events.
    try {
      if (typeof data.content === 'string' && data.content.startsWith('{') && data.content.includes('"type":"')) {
        const inner = JSON.parse(data.content);
        if (inner && inner.type) {
          if (debugFlag('mozaiks.debug_pipeline')) {
            console.log('[PIPELINE] unwrapped nested envelope', { originalType: data.type, innerType: inner.type });
          }
          // If this is chat_meta, handle it directly
          if (inner.type === 'chat_meta') {
            console.log('🧬 [META] Received chat_meta event (unwrapped):', inner);
            const metaData = inner.data || {};
            applySessionStatePendingHarnessDecision(metaData.session_state);
            if (metaData.cache_seed !== undefined && metaData.cache_seed !== null) {
              setCacheSeed(metaData.cache_seed);
              if (currentChatId) {
                setStoredChatCacheSeed(currentChatId, metaData.cache_seed);
              }
              console.log('🧬 [META] Received cache_seed', metaData.cache_seed, 'for chat', currentChatId);
            }
            if (metaData.chat_exists === false) {
              setChatExists(false);
              console.log('🧬 [META] Backend reports chat did NOT previously exist. Suppressing artifact restore. chat_id=', currentChatId);
              clearStoredArtifactState(currentChatId);
              console.log('🧼 [META] Purged stale artifacts for non-existent chat');
              setCurrentArtifactMessages([]);
              lastArtifactEventRef.current = null;
              artifactRestoredOnceRef.current = true;
              artifactCacheValidRef.current = false;
            } else if (metaData.chat_exists === true) {
              setChatExists(true);
              console.log('🧬 [META] Backend confirms chat exists. Artifact restore allowed.');
              if (!metaData.last_artifact || !metaData.last_artifact.tool_name) {
                clearStoredArtifactState(currentChatId);
                setCurrentArtifactMessages([]);
                lastArtifactEventRef.current = null;
                artifactRestoredOnceRef.current = false;
                artifactCacheValidRef.current = false;
              }
              if (!artifactRestoredOnceRef.current && metaData.last_artifact && metaData.last_artifact.tool_name) {
                try {
                  writeStoredLastArtifact(currentChatId, {
                    tool_name: metaData.last_artifact.tool_name,
                    tool_call_id: metaData.last_artifact.tool_call_id || null,
                    workflow_name: metaData.last_artifact.workflow_name || currentWorkflowName,
                    payload: metaData.last_artifact.payload || {},
                    display: metaData.last_artifact.display || 'artifact',
                    ts: Date.now(),
                  });
                  console.log('🧬 [META] Cached last_artifact from server meta event');
                  artifactCacheValidRef.current = true;
                } catch (e) { console.warn('Failed to cache server last_artifact', e); }
              }
            }
            return;
          }
          // For other events, unwrap and continue processing
          const innerData = inner.data || {};
          data.type = inner.type; // Use the inner type (could be chat.*, unknown, etc.)
          if (typeof innerData.content === 'string') data.content = innerData.content;
          if (innerData.agent) data.agent = innerData.agent;
          if (innerData.agent_name) data.agent_name = innerData.agent_name;
          if (innerData.sender && !innerData.agent && !innerData.agent_name) data.agent = innerData.sender;
          // Capability flags
          data.is_structured_capable = !!innerData.is_structured_capable;
          if (innerData.is_visual !== undefined) data.is_visual = innerData.is_visual;
          if (innerData.is_tool_agent !== undefined) data.is_tool_agent = innerData.is_tool_agent;
          if (innerData.ui_visibility !== undefined) data.ui_visibility = innerData.ui_visibility;
          if (innerData.trace_reason !== undefined) data.trace_reason = innerData.trace_reason;
          if (innerData.trace_agent !== undefined) data.trace_agent = innerData.trace_agent;
          if (innerData.sequence !== undefined) data.sequence = innerData.sequence;
          if (innerData.stream_id !== undefined) data.stream_id = innerData.stream_id;
          if (innerData.full_content !== undefined) data.full_content = innerData.full_content;
          if (innerData.metadata !== undefined) data.metadata = innerData.metadata;
          // Preserve structured output payloads if present
          if (innerData.structured_output !== undefined) data.structured_output = innerData.structured_output;
          if (innerData.structured_schema !== undefined) data.structured_schema = innerData.structured_schema;
          if (debugFlag('mozaiks.debug_pipeline')) {
            console.log('[PIPELINE] unwrap summary', {
              finalType: data.type,
              agent: data.agent || data.agent_name,
              visual: data.is_visual,
              structuredCapable: data.is_structured_capable,
              contentPreview: (data.content||'').slice(0,120)
            });
          }
        }
      }
    } catch (e) {
      if (debugFlag('mozaiks.debug_pipeline')) console.warn('[PIPELINE] failed to unwrap nested envelope', e);
    }
    
    if (!data.type.startsWith('chat.') && data.type !== 'unknown') return;

    // Some events may arrive already as { type:'chat.text', data:{ ...actualFields... } } (no double-serialization)
    // or after the above unwrap we can still retain an inner data object we need to promote.
    try {
      if (data.data && typeof data.data === 'object') {
        const inner = data.data;
        // Promote only if target field missing or clearly placeholder
        const promote = (k, aliasArr=[]) => {
          if (inner[k] === undefined) return;
          if (data[k] === undefined || data[k] === 'Unknown' || data[k] === null) data[k] = inner[k];
          // Apply aliases (e.g. sender -> agent) if primary absent
          aliasArr.forEach(alias => {
            if (data[alias] === undefined && inner[k] !== undefined) data[alias] = inner[k];
          });
        };
        promote('agent');
        promote('agent_name');
        // sender can act as agent fallback
        if (!data.agent && !data.agent_name && inner.sender) data.agent = inner.sender;
        // Core textual content (avoid overwriting if we already have a non-empty string)
        if (inner.content && (!data.content || !String(data.content).trim())) data.content = inner.content;
        // Capability / classification flags
        ['is_visual','is_structured_capable','is_tool_agent'].forEach(f => { if (inner[f] !== undefined && data[f] === undefined) data[f] = inner[f]; });
        // Structured output payload + schema
        if (inner.structured_output !== undefined && data.structured_output === undefined) data.structured_output = inner.structured_output;
        if (inner.structured_schema !== undefined && data.structured_schema === undefined) data.structured_schema = inner.structured_schema;
        // UI tool / component hints (input_request etc.) + error messages
        ['component_type','tool_name','tool_call_id','request_id','progress_percent','prompt','success','interaction_type','status','corr','call_id','payload','message','error_code','ui_visibility','trace_reason','trace_agent','sequence','stream_id','full_content','metadata'].forEach(f => {
          if (inner[f] !== undefined && data[f] === undefined) data[f] = inner[f];
        });
      }
    } catch (e) {
      if (debugFlag('mozaiks.debug_pipeline')) console.warn('[PIPELINE] failed to promote data.data fields', e);
    }

    // Final resolution / fallback normalization before dispatch
    try {
      if (typeof data.content === 'object' && data.content !== null) {
        // Some backends might leave content object like { content: 'text' }
        if (data.content.content && typeof data.content.content === 'string') {
          data.content = data.content.content;
        } else if (data.content.text && typeof data.content.text === 'string') {
          data.content = data.content.text;
        } else if (data.content.message && typeof data.content.message === 'string') {
          data.content = data.content.message;
        }
      }
      if (!data.agent && !data.agent_name && data.sender) data.agent = data.sender;
      if (debugFlag('mozaiks.debug_pipeline')) {
        console.log('[PIPELINE] resolved event pre-dispatch', {
          type: data.type,
          agent: data.agent || data.agent_name,
          visual: data.is_visual,
          structuredCapable: data.is_structured_capable,
          hasStructuredOutput: !!data.structured_output,
          contentPreview: (typeof data.content === 'string' ? data.content : JSON.stringify(data.content || '')).slice(0,120)
        });
      }
    } catch {}

    const evt = data.type.startsWith('chat.') ? data.type.slice(5) : data.type;
    switch (evt) {
      case 'mode_changed': {
        const payload = data.data || {};
        const nextMode = payload.mode || payload.status;
        if (nextMode === 'general') {
          setConversationMode('ask');
          const generalId = payload.general_chat_id || payload.chat_id;
          if (generalId) {
            setActiveGeneralChatId(generalId);
            setGeneralChatSummary({
              chatId: generalId,
              label: payload.general_chat_label || payload.label || 'Ask',
              lastUpdatedAt: payload.last_updated_at || payload.timestamp || null,
              lastSequence: payload.general_chat_sequence,
            });
            if (!generalHydrationPendingRef.current) {
              generalHydrationPendingRef.current = true;
              Promise.resolve(hydrateGeneralTranscript(generalId)).finally(() => {
                generalHydrationPendingRef.current = false;
              });
            }
          }
          refreshGeneralSessions();
        } else if (nextMode === 'workflow') {
          setConversationMode('workflow');
        }
        if (payload.message && showSystemMessages) {
          setMessagesWithLogging((prev) => ([
            ...prev,
            {
              id: `mode-msg-${Date.now()}`,
              sender: 'system',
              agentName: 'System',
              content: payload.message,
              isStreaming: false,
            }
          ]));
        }
        return;
      }
      case 'general_session_created': {
        const payload = data.data || {};
        const generalId = payload.general_chat_id || payload.chat_id;
        if (generalId) {
          generalMessagesCacheRef.current = [];
          setActiveGeneralChatId(generalId);
          setGeneralChatSummary({
            chatId: generalId,
            label: payload.general_chat_label || payload.label || 'Ask',
            lastUpdatedAt: payload.last_updated_at || payload.timestamp || null,
            lastSequence: payload.general_chat_sequence,
          });
          setConversationMode('ask');
          generalHydrationPendingRef.current = true;
          Promise.resolve(hydrateGeneralTranscript(generalId)).finally(() => {
            generalHydrationPendingRef.current = false;
          });
        }
        refreshGeneralSessions();
        return;
      }
      case 'transition_requested': {
        const payload = data.data || {};
        if (payload.transition_id) {
          setPendingTransitionId(payload.transition_id);
          setPendingTransitionContext(payload.context_variables || {});
        }
        return;
      }
      case 'context_switched': {
        const payload = data.data || {};
        const targetChatId = payload.to_chat_id || payload.chat_id;
        if (targetChatId) {
          setCurrentChatId(targetChatId);
          setActiveChatId(targetChatId);
          try { localStorage.setItem(LOCAL_STORAGE_KEY, targetChatId); } catch {}
        }
        if (payload.workflow_name) {
          currentWorkflowNameRef.current = payload.workflow_name;
          setCurrentWorkflowName(payload.workflow_name);
          setActiveWorkflowName(payload.workflow_name);
        }
        setConversationMode('workflow');
        setWorkflowCompleted(false);
        setCompletionData(null);
        if (String(payload.workflow_name || '').toLowerCase() === 'designdocs') {
          setMessagesWithLogging((prev) => {
            const statusKey = 'designdocs-generating';
            const last = prev.length ? prev[prev.length - 1] : null;
            if (last?.metadata?.status_key === statusKey) return prev;
            return [
              ...prev,
              {
                id: `designdocs-status-${Date.now()}`,
                sender: 'system',
                agentName: 'System',
                content: 'Generating design...',
                isStreaming: false,
                metadata: {
                  event_type: 'workflow_status',
                  status_key: statusKey,
                },
              },
            ];
          });
        }
        if (payload.message && showSystemMessages) {
          setMessagesWithLogging((prev) => ([
            ...prev,
            {
              id: `ctx-msg-${Date.now()}`,
              sender: 'system',
              agentName: 'System',
              content: payload.message,
              isStreaming: false,
            }
          ]));
        }
        return;
      }
      case 'stream_chunk': {
        // Real-time token streaming from AG2/transport chunk pipeline.
        // Each chunk is one word (or small slice) of the agent response.
        const agentNameChunk = extractAgentName(data);
        const chunkContent = data.content || '';
        const streamId = data.stream_id || null;
        if (!chunkContent) return;
        // Hide init spinner on first streaming token
        if (showInitSpinner) setShowInitSpinner(false);
        initSpinnerHiddenOnceRef.current = true;
        setMessagesWithLogging(prev => {
          // Clear thinking bubbles when the first chunk of a new message arrives
          const withoutThinking = prev.filter(m => !m.isThinking);
          const updated = [...withoutThinking];
          // Append to an existing in-progress streaming message for this agent
          for (let i = updated.length - 1; i >= 0; i--) {
            const m = updated[i];
            const sameStream = streamId && m.__streamId && m.__streamId === streamId;
            const sameAgentFallback = !streamId && !m.__streamId && m.agentName === agentNameChunk;
            if (m.__streaming && (sameStream || sameAgentFallback)) {
              updated[i] = {
                ...m,
                content: `${m.content || ''}${chunkContent}`,
              };
              return updated;
            }
          }
          // No existing streaming message — create one using event metadata
          updated.push({
            id: `stream-chunk-${Date.now()}`,
            sender: 'agent',
            agentName: agentNameChunk,
            content: chunkContent,
            isStreaming: true,
            __streaming: true,
            __streamId: streamId,
            isStructuredCapable: !!(data.is_structured_capable),
            isVisual: data.is_visual !== undefined ? !!data.is_visual : true,
            isToolAgent: !!(data.is_tool_agent),
          });
          return updated;
        });
        return;
      }
      case 'stream_end': {
        // End of a streaming turn — finalize the streamed message.
        // stream_end carries the authoritative full_content plus any capability
        // metadata (is_visual, structured_output, etc.) that were on chat.text.
        const agentNameEnd = extractAgentName(data);
        const finalContent = data.full_content || data.content || '';
        const streamEndMetadata = data.metadata || data.data?.metadata || {};
        const streamId = data.stream_id || data.data?.stream_id || null;
        setMessagesWithLogging(prev => {
          const updated = [...prev];
          for (let i = updated.length - 1; i >= 0; i--) {
            const m = updated[i];
            const sameStream = streamId && m.__streamId && m.__streamId === streamId;
            const sameAgentFallback = !streamId && !m.__streamId && m.agentName === agentNameEnd;
            if (m.__streaming && (sameStream || sameAgentFallback)) {
              const finalized = {
                ...m,
                content: finalContent || m.content,
                isStreaming: false,
                metadata: streamEndMetadata || m.metadata || null,
              };
              delete finalized.__streaming;
              delete finalized.__streamId;
              // Apply capability flags forwarded from the original chat.text data
              if (data.is_structured_capable !== undefined) finalized.isStructuredCapable = !!data.is_structured_capable;
              if (data.is_visual !== undefined) finalized.isVisual = !!data.is_visual;
              if (data.is_tool_agent !== undefined) finalized.isToolAgent = !!data.is_tool_agent;
              if (data.structured_output) finalized.structuredOutput = data.structured_output;
              if (data.structured_schema) finalized.structuredSchema = data.structured_schema;
              updated[i] = finalized;
              return updated;
            }
          }
          // No in-progress streaming message found — add a finished message directly
          if (finalContent) {
            if (shouldSuppressConsecutiveAssistantDuplicate(updated, {
              agentName: agentNameEnd,
              content: finalContent,
              source: streamEndMetadata?.source || null,
            })) {
              return updated;
            }
            updated.push({
              id: `stream-end-${Date.now()}`,
              sender: 'agent',
              agentName: agentNameEnd,
              content: finalContent,
              isStreaming: false,
              isStructuredCapable: !!(data.is_structured_capable),
              isVisual: data.is_visual !== undefined ? !!data.is_visual : true,
              isToolAgent: !!(data.is_tool_agent),
              structuredOutput: data.structured_output || null,
              structuredSchema: data.structured_schema || null,
              metadata: streamEndMetadata || null,
            });
          }
          return updated;
        });
        // Mobile badge: notify if the artifact drawer is covering the chat feed
        if (isMobileView && mobileDrawerState === 'expanded') {
          setHasUnseenChat(true);
        }
        return;
      }
      case 'print': {
        const printVisibility = data.ui_visibility || data.data?.ui_visibility || null;
        const showTraceMessages = debugFlag('mozaiks.show_trace_messages') || debugFlag('mozaiks.debug_pipeline');
        if (printVisibility === 'trace' && !showTraceMessages) {
          return;
        }
        if (shouldSuppressHiddenSeedEvent(data)) {
          if (debugFlag('mozaiks.debug_pipeline')) {
            console.log('[PIPELINE] suppressing hidden seed print event', {
              seedKind: getSeedKindFromEvent(data),
            });
          }
          if (showInitSpinner) setShowInitSpinner(false);
          return;
        }
        const printMetadata = data.metadata || data.data?.metadata || {};
        if (conversationMode === 'ask' && printMetadata?.source !== 'general_agent') {
          if (debugFlag('mozaiks.debug_pipeline')) {
            console.log('[PIPELINE] suppressing workflow print while in ask mode', {
              source: printMetadata?.source || null,
              agent: data.agent || data.agent_name || data.sender || null,
            });
          }
          return;
        }
        const agentName = extractAgentName(data);
        const chunk = data.content || '';
        if (!chunk) return;
        setMessagesWithLogging(prev => {
          const updated = [...prev];
            for (let i = updated.length -1; i>=0; i--) {
              const m = updated[i];
              if (m.__streaming && m.agentName === agentName) {
                m.content += chunk;
                if (debugFlag('mozaiks.debug_pipeline')) {
                  console.log('[PIPELINE] appended chunk to existing stream', { agent: agentName, newLength: m.content.length });
                }
                return updated;
              }
            }
          // Capability flags (new schema) from backend event data
          const isStructuredCapable = !!data.is_structured_capable;
          const isVisual = !!data.is_visual;
          const isToolAgent = !!data.is_tool_agent;
          updated.push({
            id:`stream-${Date.now()}`,
            sender:'agent',
            agentName,
            content:chunk,
            isStreaming:true,
            __streaming:true,
            isStructuredCapable,
            isVisual,
            isToolAgent
          });
          if (debugFlag('mozaiks.debug_pipeline')) {
            console.log('[PIPELINE] created new streaming message', { agent: agentName, chunkLen: chunk.length, isStructuredCapable, isVisual });
          }
          return updated;
        });
        return;
      }
      case 'text': {
        const textVisibility = data.ui_visibility || data.data?.ui_visibility || data.metadata?.ui_visibility || null;
        const showTraceMessages = debugFlag('mozaiks.show_trace_messages') || debugFlag('mozaiks.debug_pipeline');
        if (textVisibility === 'trace' && !showTraceMessages) {
          return;
        }
        if (shouldSuppressHiddenSeedEvent(data)) {
          if (debugFlag('mozaiks.debug_pipeline')) {
            console.log('[PIPELINE] suppressing hidden seed text event', {
              seedKind: getSeedKindFromEvent(data),
            });
          }
          if (showInitSpinner) {
            console.log('🧹 [SPINNER] Hiding spinner due to suppressed hidden seed message');
            setShowInitSpinner(false);
          }
          return;
        }
        const content = data.content || '';
        const metadataSource = data.metadata || data.data?.metadata || {};
        const isReplayEvent = Boolean(data.replay);
        const replayIndexRaw = data.index;
        const replayIndex = Number.isFinite(replayIndexRaw)
          ? Number(replayIndexRaw)
          : Number.isFinite(Number(replayIndexRaw))
            ? Number(replayIndexRaw)
            : null;
        const serverSequenceRaw = data.sequence;
        const serverSequence = Number.isFinite(serverSequenceRaw)
          ? Number(serverSequenceRaw)
          : Number.isFinite(Number(serverSequenceRaw))
            ? Number(serverSequenceRaw)
            : null;
        const normalizedAgent = (data.agent || data.agent_name || data.sender || '').toLowerCase();
        const isGeneralUserEcho = metadataSource?.source === 'general_agent' && normalizedAgent === 'user';
        const isWorkflowUserMessage = !isGeneralUserEcho && (
          normalizedAgent === 'user' ||
          (data.role && String(data.role).toLowerCase() === 'user') ||
          metadataSource?.source === 'workflow_user' ||
          Boolean(metadataSource?.input_request_id)
        );
        if (conversationMode === 'ask' && metadataSource?.source !== 'general_agent') {
          if (debugFlag('mozaiks.debug_pipeline')) {
            console.log('[PIPELINE] suppressing workflow text while in ask mode', {
              source: metadataSource?.source || null,
              agent: data.agent || data.agent_name || data.sender || null,
              replay: isReplayEvent,
            });
          }
          return;
        }
        try {
          const wfCfg = workflowConfig?.getWorkflowConfig(currentWorkflowName);
          const startupMode = String(wfCfg?.startup_mode || '').trim().toLowerCase();
          const hasInitialGreeting = Boolean(String(wfCfg?.initial_message_to_user || '').trim());
          const isSyntheticUserDrivenReplay = (
            isReplayEvent &&
            isWorkflowUserMessage &&
            startupMode === 'userdriven' &&
            hasInitialGreeting &&
            String(content).trim() === '.' &&
            replayIndex === 0
          );
          if (isSyntheticUserDrivenReplay) {
            if (debugFlag('mozaiks.debug_pipeline')) {
              console.log('[PIPELINE] suppressing replayed synthetic UserDriven trigger', {
                workflow: currentWorkflowName,
                replayIndex,
              });
            }
            return;
          }
        } catch {}
        if (isReplayEvent && conversationMode !== 'workflow' && metadataSource?.source !== 'general_agent') {
          if (debugFlag('mozaiks.debug_pipeline')) {
            console.log('[PIPELINE] skipping workflow replay while not in workflow mode', {
              conversationMode,
              agent: data.agent || data.agent_name || data.sender || null,
              index: replayIndex,
            });
          }
          return;
        }
        if (isGeneralUserEcho) {
          const recent = messagesRef.current[messagesRef.current.length - 1];
          if (recent && recent.sender === 'user') {
            const recentText = String(recent.content || '').trim();
            if (recentText && recentText === String(content).trim()) {
              return;
            }
          }
        }
        // Enhanced suppression for assistant parroting user input (including minor variation)
        try {
          if (content) {
            const msgs = messagesRef.current;
            if (msgs.length) {
              const lastUserIdx = [...msgs].reverse().findIndex(m => m && m.sender === 'user');
              if (lastUserIdx !== -1) {
                const actualIndex = msgs.length - 1 - lastUserIdx;
                const lastUser = msgs[actualIndex];
                if (lastUser) {
                  const normUser = String(lastUser.content||'').trim();
                  const normContent = String(content).trim();
                  // Simple fuzzy: treat as echo if one contains the other and length difference small
                  const shorter = normUser.length <= normContent.length ? normUser : normContent;
                  const longer = normUser.length > normContent.length ? normUser : normContent;
                  const lengthDiff = Math.abs(normUser.length - normContent.length);
                  const containsRel = longer.includes(shorter);
                  const smallDiff = lengthDiff <= 3; // allow small typos / spacing differences
                  const identical = normUser === normContent;
                  if (normUser && (identical || (containsRel && smallDiff))) {
                    if (debugFlag('mozaiks.debug_pipeline')) console.log('[PIPELINE] suppressing assistant echo/fuzzy repeat of user content');
                    return; // skip echo-like repetition
                  }
                }
              }
            }
          }
        } catch {}
        if (!content.trim()) return;
        if (workflowReplayPendingRef.current && conversationMode === 'workflow' && metadataSource?.source !== 'general_agent') {
          workflowReplayPendingRef.current = false;
        }
        const displayAsUser = isGeneralUserEcho || isWorkflowUserMessage;
        const agentName = displayAsUser ? 'You' : extractAgentName(data);
        const computedSender = displayAsUser ? 'user' : 'agent';
        setMessagesWithLogging(prev => {
          // Remove any thinking messages when agent actually speaks
          const thinkingMessages = prev.filter(m => m.isThinking);
          if (thinkingMessages.length > 0) {
            console.log('💭 [THINKING] Text event received - removing', thinkingMessages.length, 'thinking bubble(s)');
          }
          const filtered = prev.filter(m => !m.isThinking);
          const updated = [...filtered];
          
          if (updated.length) {
            const last = updated[updated.length-1];
            if (last.__streaming && last.agentName === agentName) {
              last.isStreaming = false; delete last.__streaming; if(!last.content.endsWith(content)) last.content+=content; return updated;
            }
          }

          if (isReplayEvent) {
            const normalizedContent = String(content).trim();
            for (let i = updated.length - 1; i >= 0; i -= 1) {
              const candidate = updated[i];
              if (!candidate || candidate.sender !== computedSender || candidate.agentName !== agentName) {
                continue;
              }
              const candidateContent = String(candidate.content || '').trim();
              if (!candidateContent || candidateContent !== normalizedContent) {
                continue;
              }
              const candidateReplayIndex = Number.isFinite(candidate.replayIndex)
                ? Number(candidate.replayIndex)
                : null;
              if (replayIndex !== null && candidateReplayIndex !== null && candidateReplayIndex !== replayIndex) {
                continue;
              }
              updated[i] = {
                ...candidate,
                metadata: metadataSource,
                replayIndex: replayIndex ?? candidateReplayIndex,
                serverSequence: serverSequence ?? candidate.serverSequence ?? null,
              };
              return updated;
            }
          }
          
          // Capability + structured output payload (if any) from new unified dispatcher
          const isStructuredCapable = !!data.is_structured_capable;
          const structuredOutput = data.structured_output || null; // actual structured content (if produced)
          const structuredSchema = data.structured_schema || null; // schema describing structuredOutput
          const isVisual = !!data.is_visual;
          const isToolAgent = !!data.is_tool_agent;
          if (computedSender === 'agent' && shouldSuppressConsecutiveAssistantDuplicate(updated, {
            agentName,
            content,
            source: metadataSource?.source || null,
          })) {
            return updated;
          }
          updated.push({
            id:`text-${Date.now()}`,
            sender: computedSender,
            agentName,
            content,
            isStreaming:false,
            isStructuredCapable,
            structuredOutput,
            structuredSchema,
            isVisual,
            isToolAgent,
            metadata: metadataSource,
            replayIndex,
            serverSequence,
          });
          if (debugFlag('mozaiks.debug_pipeline')) {
            console.log('[PIPELINE] appended final text message', { agent: agentName, len: content.length, isStructuredCapable, hasStructuredOutput: !!structuredOutput });
          }
          return updated;
        });
        if (metadataSource?.general_chat_id) {
          setGeneralChatSummary((prev) => ({
            chatId: metadataSource.general_chat_id,
            label: metadataSource.general_chat_label || prev?.label || 'Ask',
            lastUpdatedAt: Date.now(),
            lastSequence: metadataSource.general_chat_sequence || metadataSource.sequence || prev?.lastSequence,
          }));
        }
        
        // Badge notification: Set unseen chat badge if artifact drawer is covering chat
        if (isMobileView && mobileDrawerState === 'expanded') {
          setHasUnseenChat(true);
        }
        
        // Hide the one-time initialization spinner after the first successfully rendered chat.text
        if (showInitSpinner) {
          setShowInitSpinner(false);
        }
        // Auto-open artifact panel for visual outputs with display === 'artifact'
        try {
          const hasStructuredOutput = data.structured_output && Object.keys(data.structured_output).length > 0;
          const displayMode = data.display || data.display_type || data.mode || 
                              (data.structured_output && data.structured_output.display);
          
          // Only auto-open if explicitly marked as artifact display (not inline)
          if ((hasStructuredOutput || data.is_visual) && displayMode === 'artifact') {
            console.log('📊 [TELEMETRY] Auto-opening artifact panel for text event:', {
              agent: agentName,
              is_visual: data.is_visual,
              has_structured_output: hasStructuredOutput,
              display: displayMode,
              workflow: currentWorkflowName,
              chat_id: currentChatId
            });
            setLayoutMode && setLayoutMode('split');
            setIsSidePanelOpen && setIsSidePanelOpen(true);
          }
        } catch (e) {}
        return;
      }
      case 'tool_call': {
        if (data.component_type || (data.data && data.data.component_type)) {
          const envelope = data || {};
          const detail = envelope.data || {};
          const toolName = envelope.tool_name || detail.tool_name || detail.tool || 'UnknownTool';
          const componentType = envelope.component_type || detail.component_type || detail.component || toolName;
          const basePayload = detail.payload || envelope.payload || {};
          const payloadKeys = Object.keys(basePayload);
          console.log('🛠️ [TOOL_CALL] Processing UI tool event:', toolName, 'component:', componentType);
          console.log('🛠️ [TOOL_CALL] Raw tool_call data:', envelope);
          console.log('🛠️ [TOOL_CALL] Payload keys received:', payloadKeys);
          const derivedDisplay = envelope.display || envelope.display_type || envelope.mode || detail.display || detail.display_type || detail.mode || basePayload.display || basePayload.mode || null;
          const toolCallId = envelope.tool_call_id || envelope.corr || detail.tool_call_id || detail.corr || null;
          const awaiting = envelope.awaiting_response !== undefined ? envelope.awaiting_response : detail.awaiting_response;
          const resolvedWorkflowName = envelope.workflow_name || detail.workflow_name || basePayload.workflow_name || currentWorkflowName;
          const interactionType = envelope.interaction_type || detail.interaction_type || basePayload.interaction_type || (awaiting ? 'ui_tool' : 'ui_surface');
          const sendResponse = (responseData) => {
            console.log('dY"O ChatPage: Sending WebSocket response for tool_call:', responseData);
            const activeWs = wsRef.current;
            if (activeWs && activeWs.send) {
              return activeWs.send(responseData);
            }
            console.warn('���s������,? No WebSocket connection available for UI tool response (tool_call)');
            return false;
          };
          dynamicUIHandler.processUIEvent({
            type: 'tool_call',
            tool_name: toolName,
            tool_call_id: toolCallId || undefined,
            component_type: componentType,
            workflow_name: resolvedWorkflowName,
            display: derivedDisplay,
            agent: envelope.agent || detail.agent || envelope.agent_name || detail.agent_name,
            agentName: envelope.agent || detail.agent || envelope.agent_name || detail.agent_name,
            payload: {
              ...basePayload,
              tool_name: toolName,
              component_type: componentType,
              workflow_name: resolvedWorkflowName,
              awaiting_response: awaiting,
              interaction_type: interactionType,
              ...(derivedDisplay ? { display: derivedDisplay } : {})
            }
          }, sendResponse);
          // Auto-open artifact panel ONLY for display === 'artifact'
          try {
            if (derivedDisplay === 'artifact') {
              console.log('📊 [TELEMETRY] Auto-opening artifact panel for tool_call:', {
                tool_name: toolName,
                component_type: componentType,
                display: derivedDisplay,
                workflow: currentWorkflowName,
                chat_id: currentChatId
              });
              setLayoutMode && setLayoutMode('split');
              setIsSidePanelOpen && setIsSidePanelOpen(true);
            }
          } catch (e) {}
        } else {
          if (showSystemMessages) {
            setMessagesWithLogging(prev => [...prev, { id: data.tool_call_id || `tool-call-${Date.now()}`, sender:'system', agentName:'System', content:`🔧 Tool Call: ${data.tool_name}`, isStreaming:false }]);
          }
        }
        return;
      }
      // ── ui.* typed event contract (L2) ──────────────────────────────────
      case 'ui.render': {
        // Typed contract fields mirror UIRenderData from ui_events.py.
        const inner = data.data || {};
        const component  = inner.component || inner.component_type || '';
        const displayMode = inner.display_mode || inner.display || 'inline';
        const toolCallId  = inner.tool_call_id || null;
        const workflow    = inner.workflow || inner.workflow_name || currentWorkflowName;
        const agent       = inner.agent || inner.agent_name || null;
        const awaiting    = inner.awaiting_response !== false;
        const basePayload = inner.payload || {};
        const toolName    = inner.tool_name || component;
        const interactionType = inner.interaction_type || (awaiting ? 'ui_tool' : 'ui_surface');

        console.log('🛠️ [UI_RENDER] Received ui.render:', { toolName, component, displayMode, toolCallId });

        const sendResponse = (responseData) => {
          const activeWs = wsRef.current;
          if (activeWs && activeWs.send) return activeWs.send(responseData);
          console.warn('⚠️ No WebSocket available for ui.render response');
          return false;
        };

        dynamicUIHandler.processUIEvent({
          type: 'ui.render',
          tool_name: toolName,
          component: component,
          component_type: component,
          tool_call_id: toolCallId || undefined,
          workflow: workflow,
          workflow_name: workflow,
          display: displayMode,
          display_mode: displayMode,
          awaiting_response: awaiting,
          agent,
          agentName: agent,
          interaction_type: interactionType,
          payload: {
            ...basePayload,
            component_type: component,
            workflow_name: workflow,
            awaiting_response: awaiting,
            interaction_type: interactionType,
            display: displayMode,
          },
        }, sendResponse);

        try {
          if (displayMode === 'artifact') {
            setLayoutMode && setLayoutMode('split');
            setIsSidePanelOpen && setIsSidePanelOpen(true);
          }
        } catch (e) {}
        return;
      }

      case 'ui.update': {
        // Patch a live component's payload without re-mounting.
        const inner = data.data || {};
        const patchId = inner.tool_call_id || null;
        const patch   = inner.patch || {};
        if (patchId) {
          const applyPatch = (msg) => {
            if (msg?.toolCall?.tool_call_id === patchId || msg?.metadata?.toolCallId === patchId) {
              return {
                ...msg,
                toolCall: msg.toolCall
                  ? { ...msg.toolCall, payload: { ...(msg.toolCall.payload || {}), ...patch } }
                  : msg.toolCall,
              };
            }
            return msg;
          };
          setMessagesWithLogging(prev => prev.map(applyPatch));
          setCurrentArtifactMessages(prev => prev.map(applyPatch));
        }
        return;
      }

      case 'ui.dismiss': {
        // Tear down a rendered component — same logic as tool_call_dismiss.
        const inner = data.data || {};
        const dismissedId = inner.tool_call_id || null;
        if (dismissedId) {
          setMessagesWithLogging((prev) =>
            prev.filter(
              (msg) => !(
                msg?.metadata?.toolCallId === dismissedId
                && (
                  msg?.metadata?.type === 'tool_call_agent_message'
                  || msg?.metadata?.type === 'composer_tool_call'
                  || msg?.metadata?.hideInTranscript
                )
              )
            )
          );
        }
        if (lastArtifactEventRef.current && (!dismissedId || dismissedId === lastArtifactEventRef.current)) {
          setIsSidePanelOpen(false);
          lastArtifactEventRef.current = null;
          artifactCacheValidRef.current = false;
          setCurrentArtifactMessages([]);
          if (currentChatId) clearStoredArtifactState(currentChatId);
        }
        return;
      }
      // ── end ui.* ────────────────────────────────────────────────────────

      case 'tool_call_complete':
      case 'chat.tool_call_complete': {
        const envelope = data || {};
        const detail = envelope.data || {};
        const completedId = detail.tool_call_id || envelope.tool_call_id || null;
        const completedTool = detail.tool_name || envelope.tool_name || null;
        const status = detail.status || envelope.status || 'completed';
        
        console.log('✓ [UI_COMPLETE] Inline tool completed:', { completedId, completedTool, status });

        if (completedId) {
          // Mark matching tool-call messages complete so composer requests do not
          // remain pending after the user has already answered them.
          setMessagesWithLogging((prev) =>
            prev.map((msg) => {
              if (msg?.metadata?.toolCallId !== completedId) {
                return msg;
              }
              const displayMode =
                msg?.metadata?.display
                || msg?.toolCall?.display
                || msg?.toolCall?.payload?.display
                || msg?.toolCall?.payload?.mode
                || null;
              if (displayMode === 'inline') {
                return {
                  ...msg,
                  tool_call_completed: true,
                  tool_call_status: status,
                  tool_call_summary: `${completedTool || 'Tool'} completed`
                };
              }
              if (displayMode === 'composer' || msg?.metadata?.hideInTranscript) {
                return {
                  ...msg,
                  tool_call_completed: true,
                  tool_call_status: status,
                };
              }
              return msg;
            })
          );
        }
        return;
      }
      case 'tool_call_dismiss':
      case 'chat.tool_call_dismiss': {
        const envelope = data || {};
        const detail = envelope.data || {};
        const dismissedId = detail.tool_call_id || envelope.tool_call_id || null;
        const dismissedTool = detail.tool_name || envelope.tool_name || null;
        console.log('🧩 [UI] Received tool_call_dismiss event:', { dismissedId, dismissedTool });

        if (dismissedId) {
          setMessagesWithLogging((prev) =>
            prev.filter(
              (msg) => !(
                msg?.metadata?.toolCallId === dismissedId
                && (
                  msg?.metadata?.type === 'tool_call_agent_message'
                  || msg?.metadata?.type === 'composer_tool_call'
                  || msg?.metadata?.hideInTranscript
                )
              )
            )
          );
        }

        if (lastArtifactEventRef.current && (!dismissedId || dismissedId === lastArtifactEventRef.current)) {
          try { console.log('🧹 [UI] Backend-dismissed artifact event -> collapsing panel'); } catch {}
          setIsSidePanelOpen(false);
          lastArtifactEventRef.current = null;
          artifactCacheValidRef.current = false;
          setCurrentArtifactMessages([]);
          if (currentChatId) {
            clearStoredArtifactState(currentChatId);
          }
        }
        return;
      }
      case 'artifact.action.started': {
        const detail = data.data || {};
        const actionId = detail.action_id || data.action_id;
        const artifactId = detail.artifact_id || data.artifact_id;
        if (actionId) {
          setActionStatusMap((prev) => ({
            ...prev,
            [actionId]: {
              ...(prev[actionId] || {}),
              status: 'started',
              artifact_id: artifactId,
              tool: detail.tool || data.tool,
            }
          }));
        }
        return;
      }
      case 'artifact.action.completed': {
        const detail = data.data || {};
        const actionId = detail.action_id || data.action_id;
        const artifactId = detail.artifact_id || data.artifact_id;
        const result = detail.result || data.result || {};
        const artifactUpdate = detail.artifact_update || data.artifact_update || result?.artifact_update;
        if (actionId) {
          setActionStatusMap((prev) => ({
            ...prev,
            [actionId]: {
              ...(prev[actionId] || {}),
              status: 'completed',
              result,
            }
          }));
          optimisticSnapshotsRef.current.delete(actionId);
        }
        if (artifactUpdate) {
          applyArtifactUpdateForAction(artifactId, artifactUpdate);
        }
        return;
      }
      case 'artifact.action.failed': {
        const detail = data.data || {};
        const actionId = detail.action_id || data.action_id;
        const artifactId = detail.artifact_id || data.artifact_id;
        const error = detail.error || data.error || 'Action failed';
        const rollback = detail.rollback || data.rollback;
        if (actionId) {
          setActionStatusMap((prev) => ({
            ...prev,
            [actionId]: {
              ...(prev[actionId] || {}),
              status: 'failed',
              error,
            }
          }));
        }
        if (rollback && actionId) {
          const snapshot = optimisticSnapshotsRef.current.get(actionId);
          if (snapshot?.payload) {
            updateArtifactPayload(snapshot.artifactId || artifactId, () => snapshot.payload);
          }
          optimisticSnapshotsRef.current.delete(actionId);
        }
        return;
      }
      case 'tool_response': {
        // Suppress intermediate auto-tool responses (already handled by dynamicUIHandler)
        // Only show failures or non-auto-tool responses
        if (data.interaction_type === 'auto_tool' && data.success) {
          console.log(`⏭️ Skipping auto-tool success response (${data.tool_name}) - handled by UI renderer`);
          return;
        }
        if (showSystemMessages) {
          const responseContent = data.success ? `✅ Tool Response: ${data.content || 'Success'}` : `❌ Tool Failed: ${data.content || 'Error'}`;
          setMessagesWithLogging(prev => [...prev, { id: data.tool_call_id || `tool-response-${Date.now()}`, sender:'system', agentName:'System', content: responseContent, isStreaming:false }]);
        }
        return;
      }
      case 'usage_summary': {
        if (showSystemMessages) {
          setMessagesWithLogging(prev => [...prev, { id:`usage-${Date.now()}`, sender:'system', agentName:'System', content:`📊 Usage: tokens=${data.total_tokens} prompt=${data.prompt_tokens} completion=${data.completion_tokens}${data.cost?` cost=$${data.cost}`:''}`, isStreaming:false }]);
        }
        return;
      }
      case 'workflow_batch_started': {
        const payload = data.data || {};
        const count = Number(data.count ?? payload.count ?? 0);
        const label = count > 0 ? `Running ${count} parallel workflow task${count === 1 ? '' : 's'}...` : 'Running parallel workflow tasks...';
        setMessagesWithLogging(prev => [...prev, {
          id: `mfj-batch-${Date.now()}`,
          sender: 'system',
          agentName: 'System',
          content: `⚙️ ${label}`,
          isStreaming: false,
          metadata: {
            event_type: 'workflow_batch_started',
            trigger_id: data.trigger_id || payload.trigger_id || null,
            mfj_cycle: data.mfj_cycle || payload.mfj_cycle || null,
            count: count || null,
          },
        }]);
        return;
      }
      case 'workflow_child_completed': {
        if (!showSystemMessages) {
          return;
        }
        const payload = data.data || {};
        const idx = Number(data.child_index ?? payload.child_index ?? 0);
        const total = Number(data.child_total ?? payload.child_total ?? 0);
        const ok = data.success ?? payload.success;
        const status = String(data.status || payload.status || (ok ? 'completed' : 'failed'));
        const progressText = idx > 0 && total > 0 ? ` (${idx}/${total})` : '';
        const icon = ok ? '✅' : '⚠️';
        setMessagesWithLogging(prev => [...prev, {
          id: `mfj-child-${Date.now()}`,
          sender: 'system',
          agentName: 'System',
          content: `${icon} Parallel child${progressText}: ${status}`,
          isStreaming: false,
          metadata: {
            event_type: 'workflow_child_completed',
            child_chat_id: data.child_chat_id || payload.child_chat_id || null,
            trigger_id: data.trigger_id || payload.trigger_id || null,
            mfj_cycle: data.mfj_cycle || payload.mfj_cycle || null,
          },
        }]);
        return;
      }
      case 'mfj_fan_in_started': {
        const payload = data.data || {};
        setMessagesWithLogging(prev => [...prev, {
          id: `mfj-fanin-${Date.now()}`,
          sender: 'system',
          agentName: 'System',
          content: `🧩 Merging parallel results...`,
          isStreaming: false,
          metadata: {
            event_type: 'mfj_fan_in_started',
            trigger_id: data.trigger_id || payload.trigger_id || null,
            mfj_cycle: data.mfj_cycle || payload.mfj_cycle || null,
          },
        }]);
        return;
      }
      case 'mfj_timeout_prompt': {
        const payload = data.data || {};
        const failed = Number(data.failed_count ?? payload.failed_count ?? 0);
        const total = Number(data.total_count ?? payload.total_count ?? 0);
        const detail = failed > 0 && total > 0 ? ` (${failed}/${total} failed)` : '';
        setMessagesWithLogging(prev => [...prev, {
          id: `mfj-timeout-${Date.now()}`,
          sender: 'system',
          agentName: 'System',
          content: `⏱️ Parallel tasks timed out${detail}. Continuing with available results.`,
          isStreaming: false,
          metadata: {
            event_type: 'mfj_timeout_prompt',
            trigger_id: data.trigger_id || payload.trigger_id || null,
            mfj_cycle: data.mfj_cycle || payload.mfj_cycle || null,
          },
        }]);
        return;
      }
      case 'workflow_resumed': {
        const payload = data.data || {};
        const resumeAgent = data.resume_agent || payload.resume_agent || 'resume agent';
        setMessagesWithLogging(prev => [...prev, {
          id: `mfj-resume-${Date.now()}`,
          sender: 'system',
          agentName: 'System',
          content: `↩️ Parallel phase complete. Resuming at ${resumeAgent}.`,
          isStreaming: false,
          metadata: {
            event_type: 'workflow_resumed',
            trigger_id: data.trigger_id || payload.trigger_id || null,
            mfj_cycle: data.mfj_cycle || payload.mfj_cycle || null,
            inject_as: data.inject_as || payload.inject_as || null,
            succeeded_count: data.succeeded_count ?? payload.succeeded_count ?? null,
            failed_count: data.failed_count ?? payload.failed_count ?? null,
          },
        }]);
        return;
      }
      case 'select_speaker': {
        // Speaker selection marks a new agent taking over - inject thinking state
        const nextAgentName = data.agent || data.agent_name || data.selected_speaker || 'Agent';
        
        console.log('💭 [THINKING] Speaker selected:', nextAgentName, '- adding thinking bubble');
        
        // Add a temporary "thinking" message that will be removed when next agent speaks
        setMessagesWithLogging(prev => {
          // Remove any existing thinking messages first
          const existingThinking = prev.filter(m => m.isThinking);
          if (existingThinking.length > 0) {
            console.log('💭 [THINKING] Removing', existingThinking.length, 'existing thinking bubble(s) before adding new one');
          }
          
          const filtered = prev.filter(m => !m.isThinking);
          return [
            ...filtered,
            {
              id: `thinking-${Date.now()}`,
              sender: 'agent',
              agentName: nextAgentName,
              content: '', // Empty content - will show thinking indicator
              isThinking: true,
              timestamp: Date.now()
            }
          ];
        });
        
        // Speaker selection often marks a new turn/run start. If we have an open artifact
        // from a prior sequence, collapse it now and clear the cache.
        if (lastArtifactEventRef.current && isSidePanelOpen) {
          try {
            console.log('🧹 [UI] New sequence detected; collapsing ArtifactPanel (event:', lastArtifactEventRef.current, ')');
          } catch {}
          setIsSidePanelOpen(false);
          lastArtifactEventRef.current = null;
          setCurrentArtifactMessages([]);
          // Clear artifact cache on new conversation turn
          if (currentChatId) {
            clearStoredArtifactState(currentChatId);
          }
        }
        return;
      }
      case 'activity': {
        const activityType = data.activity_type || data.status || 'background';
        const activityAgent = data.agent || data.agent_name || 'System';
        const activityStatus = data.status || 'working';
        const activityMessage = data.message
          || `${activityAgent} is working in the background.`;
        const activityKey = `${activityType}:${activityAgent}`;
        if (showInitSpinner) {
          setShowInitSpinner(false);
          initSpinnerHiddenOnceRef.current = true;
        }
        setMessagesWithLogging(prev => {
          const updated = [...prev];
          const last = updated.length ? updated[updated.length - 1] : null;
          const nextEntry = {
            id: last?.metadata?.event_type === 'activity' && last?.metadata?.activity_key === activityKey
              ? last.id
              : `activity-${Date.now()}`,
            sender: 'system',
            agentName: 'System',
            content: `⏳ ${activityMessage}`,
            isStreaming: false,
            metadata: {
              event_type: 'activity',
              activity_type: activityType,
              activity_status: activityStatus,
              activity_agent: activityAgent,
              activity_key: activityKey,
              workflow_name: data.workflow_name || currentWorkflowName || null,
            },
          };
          if (last?.metadata?.event_type === 'activity' && last?.metadata?.activity_key === activityKey) {
            updated[updated.length - 1] = nextEntry;
            return updated;
          }
          if (last?.metadata?.event_type === 'activity' && last?.content === nextEntry.content) {
            return updated;
          }
          updated.push(nextEntry);
          return updated;
        });
        return;
      }
      case 'tool_progress': {
        // Update or append progress for a long-running tool
        const progress = data.progress_percent;
        const tool = data.tool_name || 'tool';
        if (!showSystemMessages) {
          return;
        }
        setMessagesWithLogging(prev => {
          const updated = [...prev];
          for (let i = updated.length - 1; i >=0; i--) {
            const m = updated[i];
            if (m.metadata && m.metadata.event_type === 'tool_call' && m.metadata.tool_name === tool) {
              m.content = `🔧 ${tool} progress: ${progress}%`;
              m.metadata.progress_percent = progress;
              return updated;
            }
          }
          updated.push({ id:`tool-progress-${Date.now()}`, sender:'system', agentName:'System', content:`🔧 ${tool} progress: ${progress}%`, isStreaming:false, metadata:{ event_type:'tool_progress', tool_name: tool, progress_percent: progress }});
          return updated;
        });
        return;
      }
      case 'deployment_started': {
        const payload = data.data || {};
        const message = payload.message || 'Starting deployment to GitHub...';
        if (showSystemMessages) {
          setMessagesWithLogging(prev => [...prev, {
            id: `deploy-start-${Date.now()}`,
            sender: 'system',
            agentName: 'System',
            content: `🚀 ${message}`,
            isStreaming: false,
            metadata: { event_type: 'deployment', status: 'started', job_id: payload.job_id || payload.jobId || null }
          }]);
        }
        return;
      }
      case 'deployment_progress': {
        const payload = data.data || {};
        const jobId = payload.job_id || payload.jobId || null;
        const statusText = payload.status || payload.message || 'Deployment in progress...';
        if (!showSystemMessages) {
          return;
        }
        setMessagesWithLogging(prev => {
          const updated = [...prev];
          if (jobId) {
            for (let i = updated.length - 1; i >= 0; i--) {
              const m = updated[i];
              if (m.metadata && m.metadata.event_type === 'deployment' && m.metadata.job_id === jobId) {
                m.content = `⏳ ${statusText}`;
                m.metadata.status = 'progress';
                return updated;
              }
            }
          }
          updated.push({
            id: `deploy-progress-${Date.now()}`,
            sender: 'system',
            agentName: 'System',
            content: `⏳ ${statusText}`,
            isStreaming: false,
            metadata: { event_type: 'deployment', status: 'progress', job_id: jobId }
          });
          return updated;
        });
        return;
      }
      case 'deployment_completed': {
        const payload = data.data || {};
        const repoUrl = payload.repo_url || payload.repoUrl;
        const message = payload.message || 'Deployment completed.';
        if (showSystemMessages) {
          setMessagesWithLogging(prev => [...prev, {
            id: `deploy-done-${Date.now()}`,
            sender: 'system',
            agentName: 'System',
            content: repoUrl ? `✅ ${message} Repo: ${repoUrl}` : `✅ ${message}`,
            isStreaming: false,
            metadata: { event_type: 'deployment', status: 'completed', job_id: payload.job_id || payload.jobId || null, repo_url: repoUrl || null }
          }]);
        }
        return;
      }
      case 'deployment_failed': {
        const payload = data.data || {};
        const message = payload.message || payload.error || 'Deployment failed.';
        if (showSystemMessages) {
          setMessagesWithLogging(prev => [...prev, {
            id: `deploy-fail-${Date.now()}`,
            sender: 'system',
            agentName: 'System',
            content: `❌ ${message}`,
            isStreaming: false,
            metadata: { event_type: 'deployment', status: 'failed', job_id: payload.job_id || payload.jobId || null }
          }]);
        }
        return;
      }
      case 'input_timeout': {
        setMessagesWithLogging(prev => [...prev, { id:`timeout-${Date.now()}`, sender:'system', agentName:'System', content:`⏱️ Input request timed out.`, isStreaming:false }]);
        return;
      }
      case 'awaiting_reply': {
        const payload = data.data || {};
        setLoading(false);
        setPendingWorkflowReply({
          agent: payload.source_agent || payload.agent || 'Agent',
          prompt: payload.prompt || '',
          reason: payload.reason || 'awaiting_user_reply',
        });
        return;
      }
      case 'run_complete': {
        console.log('🎉 [COMPLETION] Workflow completed:', data);
        
        // Extract completion metadata
        const reason = data.reason || data.data?.reason || 'finished';
        const status = data.status ?? data.data?.status ?? 1;
        const normalizedStatus = String(status).trim().toLowerCase();
        const isTerminalCompletion = (
          status === 1 ||
          normalizedStatus === '1' ||
          ['completed', 'complete', 'success', 'succeeded', 'done', 'ok'].includes(normalizedStatus)
        );
        if (!isTerminalCompletion) {
          setLoading(false);
          setPendingWorkflowReply(prev => prev || {
            agent: data.agent || data.data?.agent || 'Agent',
            prompt: data.prompt || data.data?.prompt || '',
            reason,
          });
          return;
        }
        setPendingWorkflowReply(null);
        const duration = data.duration_sec || data.data?.duration_sec;
        const tokensUsed = data.total_tokens || data.data?.total_tokens;
        
        // Set completion state to show WorkflowCompletion component
        setWorkflowCompleted(true);
        setCompletionData({
          reason,
          status,
          duration: duration ? `${Math.round(duration)}s` : null,
          tokensUsed: tokensUsed ? tokensUsed.toLocaleString() : null,
        });
        
        // Also add a system message to chat history
        setMessagesWithLogging(prev => [...prev, { 
          id:`run-complete-${Date.now()}`, 
          sender:'system', 
          agentName:'System', 
          content:`✅ Workflow complete (${reason})`, 
          isStreaming:false 
        }]);
        return;
      }
      case 'error': {
        setPendingWorkflowReply(null);
        const errorMsg = data.message || data.data?.message || 'Unknown error';
        const errorCode = data.error_code || data.data?.error_code;
        // Create a stable ID based on error content to prevent duplicates
        const errorId = `${errorCode || 'error'}-${errorMsg.slice(0, 50)}`;
        
        // Prevent duplicate errors (React StrictMode or event replay)
        if (lastErrorIdRef.current === errorId) {
          console.log('🔴 [ERROR_EVENT] Duplicate error detected, skipping:', errorId);
          return;
        }
        lastErrorIdRef.current = errorId;
        
        console.log('🔴 [ERROR_EVENT] Received error event:', { message: errorMsg, error_code: errorCode, raw_data: data });
        setMessagesWithLogging(prev => [...prev, { id:`err-${Date.now()}`, sender:'system', agentName:'System', content:`❌ Error: ${errorMsg}`, isStreaming:false }]);
        return;
      }
      case 'input_ack':
        setPendingWorkflowReply(null);
        return;
      case 'resume_boundary':
        if (workflowReplayPendingRef.current) {
          workflowReplayPendingRef.current = false;
          const payload = data.data || {};
          const replayedCount = Number(payload.replayed_messages ?? payload.replayed_events ?? 0);
          if (replayedCount <= 0 && messagesRef.current.length === 0) {
            const cachedWorkflow = sanitizeVisibleWorkflowMessages(workflowMessagesSharedRef.current || []);
            if (cachedWorkflow.length > 0) {
              console.log(`📦 [WORKFLOW_RESTORE] Replay empty; restoring ${cachedWorkflow.length} cached workflow messages`);
              setMessagesWithLogging(cachedWorkflow);
            }
          }
        }
        if (showSystemMessages) {
          // Replay boundary marker for debug visibility
          setMessagesWithLogging(prev => [...prev, { id:`resume-${Date.now()}`, sender:'system', agentName:'System', content:`🔄 Session replay complete. Live events resumed.`, isStreaming:false }]);
        }
        return;
      default:
        return;
    }
  }, [currentChatId, currentWorkflowName, sanitizeVisibleWorkflowMessages, setMessagesWithLogging, extractAgentName, isSidePanelOpen, showInitSpinner, setLayoutMode, isMobileView, mobileDrawerState, setConversationMode, setActiveGeneralChatId, setGeneralChatSummary, hydrateGeneralTranscript, refreshGeneralSessions, setActiveChatId, setActiveWorkflowName, setCurrentChatId, applyArtifactUpdateForAction, updateArtifactPayload, applySessionStatePendingHarnessDecision]);
  useEffect(() => {
    handleIncomingRef.current = handleIncoming;
  }, [handleIncoming]);

  // Debug: Log spinner state changes
  useEffect(() => {
    console.log('🧹 [SPINNER] State changed to:', showInitSpinner);
  }, [showInitSpinner]);

  // Failsafe: never leave the one-time init spinner on indefinitely.
  useEffect(() => {
    if (!showInitSpinner || initSpinnerHiddenOnceRef.current) return undefined;

    const timer = setTimeout(() => {
      if (!initSpinnerHiddenOnceRef.current) {
        console.log('🧹 [SPINNER] Auto-hiding spinner (failsafe timeout)');
        initSpinnerHiddenOnceRef.current = true;
        setShowInitSpinner(false);
      }
    }, 4000);

    return () => clearTimeout(timer);
  }, [showInitSpinner]);

  // Workflow configuration & resume bootstrap (no direct startChat here; handled by preflight existence effect)
  useEffect(() => {
    if (!api) return;

    // Hard requirement: app_id must be set via route/query/env (no implicit fallback)
    if (!currentAppId) {
      console.error(
        "Missing app_id. Provide it via URL (/chat/<app_id>), query (?appId=...), or REACT_APP_DEFAULT_APP_ID."
      );
      setConnectionStatus('error');
      setLoading(false);
      // Allow retry once the user fixes config (don’t lock the flags)
      setConnectionInitialized(false);
      connectionInProgressRef.current = false;
      return;
    }
    // Fetch workflow configs first; only signal ready once the registry is populated.
    // This prevents connectWithCorrectTransport from firing against an empty registry.
    workflowConfig.fetchWorkflowConfigs().finally(() => {
      setWorkflowConfigLoaded(true);
    });
    if (!currentChatId) {
      const stored = getStoredActiveChatId();
      if (stored) {
        setCurrentChatId(stored);
        const seedStored = getStoredChatCacheSeed(stored);
        if (seedStored !== null) {
          setCacheSeed(seedStored);
          console.log('🧬 [RESUME] Loaded cached cache_seed for resumed chat', stored, seedStored);
        }
      }
    }
  }, [api, currentChatId, currentAppId]);

  // NEW: Preflight chat existence + cache clearing logic
useEffect(() => {
  if (!api) return;
  if (!workflowConfigLoaded) return; // wait until registry is ready
  if (currentChatId) return; // existing logic handles resume or already started
  if (pendingStartRef.current) return;

  pendingStartRef.current = true;
  (async () => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const chatIdParam = urlParams.get('chat_id');
      let reuseChatId = chatIdParam;

      if (reuseChatId) {
        console.log('[EXISTS] Checking existence of chat', reuseChatId);
        const wfName = resolveKnownWorkflowName(currentWorkflowName);
        if (!wfName) {
          console.warn('[EXISTS] No runnable workflow resolved; skipping chat reuse check');
          pendingStartRef.current = false;
          return;
        }
        try {
          const resp = await fetch(`${api.getHttpBaseUrl()}/api/chats/exists/${currentAppId}/${wfName}/${reuseChatId}`);
          if (resp.ok) {
            const data = await resp.json();
            if (data.exists) {
              console.log('[EXISTS] Chat exists; adopting chat_id and skipping startChat');
              setCurrentChatId(reuseChatId);
              setChatExists(true);
              
              // Update global chat context for persistent bubble
              setActiveChatId(reuseChatId);
              setActiveWorkflowName(wfName);
              setChatMinimized(false);
              
              pendingStartRef.current = false;
              return;
            }
            console.log('[EXISTS] Chat does NOT exist; clearing any cached artifacts for that id');
            clearStoredArtifactState(reuseChatId);
            clearStoredChatCacheSeed(reuseChatId);
            if (getStoredActiveChatId() === reuseChatId) {
              setStoredActiveChatId(null);
            }
            consumeNavigationQueryParams(['chat_id']);
          } else {
            console.warn('[EXISTS] Backend returned non-OK; falling back to reuse chat_id');
            setCurrentChatId(reuseChatId);
            setChatExists(null);
            setActiveChatId(reuseChatId);
            setActiveWorkflowName(wfName);
            setChatMinimized(false);
            pendingStartRef.current = false;
            return;
          }
        } catch (e) {
          console.warn('[EXISTS] Existence check failed; reusing chat_id without backend', e);
          setCurrentChatId(reuseChatId);
          setChatExists(null);
          setActiveChatId(reuseChatId);
          setActiveWorkflowName(wfName || null);
          setChatMinimized(false);
          pendingStartRef.current = false;
          return;
        }
      }

      console.log('[INIT] Creating new chat via startChat');
      const startWorkflowName = resolveKnownWorkflowName(currentWorkflowName);
      if (!startWorkflowName) {
        console.warn('[INIT] No runnable workflow resolved; skipping startChat');
        return;
      }
      const triggerMeta = {
        trigger_source: queryTriggerSource,
        ...(queryActionId ? { action_id: queryActionId } : {}),
        ...(queryChangeClass ? { change_class: queryChangeClass } : {}),
        ...(queryArtifactVersionId ? { artifact_version_id: queryArtifactVersionId } : {}),
      };
      const askCarrierMode = queryMode === 'ask' || conversationMode === 'ask';
      const result = await api.startChat(
        currentAppId,
        startWorkflowName,
        currentUserId,
        {},
        queryContext,
        triggerMeta,
        askCarrierMode ? { transportPurpose: 'ask_carrier' } : null,
      );
      if (result && (result.chat_id || result.id)) {
        const newId = result.chat_id || result.id;
        const reused = !!result.reused;
        const resolvedWorkflowName = result.workflow_name || startWorkflowName;
        setCurrentChatId(newId);
        setChatExists(reused);

        // Remove ?context= param after seeding — prevent re-injection on refresh
        if (queryContextRaw) {
          const cleanParams = new URLSearchParams(location.search || '');
          cleanParams.delete('context');
          const nextSearch = cleanParams.toString();
          navigate(location.pathname + (nextSearch ? `?${nextSearch}` : ''), { replace: true });
        }

        // Update global chat context for persistent bubble
        setActiveChatId(newId);
        setActiveWorkflowName(resolvedWorkflowName);
        setCurrentWorkflowName(resolvedWorkflowName);
        setChatMinimized(false);
        setStoredActiveChatId(newId);
        if (!reused) {
          clearStoredArtifactState(newId);
        }
        console.log('[INIT] startChat complete', { newId, reused, contextSeeded: !!queryContext });
      }
    } catch (e) {
      console.error('[INIT] Failed to initialize chat:', e);
    } finally {
      pendingStartRef.current = false;
    }
  })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, [api, workflowConfigLoaded, currentChatId, currentWorkflowName, currentAppId, currentUserId, resolveKnownWorkflowName, consumeNavigationQueryParams]);

  // Guard against stale chat IDs restored from local storage (e.g. after cleanse).
  // If the chat does not exist anymore, clear it so preflight can create a new one.
  useEffect(() => {
    if (!api) return;
    if (!workflowConfigLoaded) return;
    if (!currentAppId) return;
    if (!currentChatId) return;
    if (validatingChatIdRef.current) return;
    if (validatedChatIdRef.current === currentChatId) return;

    validatingChatIdRef.current = true;
    (async () => {
      try {
        const workflowForCheck =
          resolveKnownWorkflowName(currentWorkflowName)
          || resolveKnownWorkflowName(urlWorkflowName)
          || workflowConfig.getDefaultWorkflow()
          || 'GreenRoom';

        const resp = await fetch(
          `${api.getHttpBaseUrl()}/api/chats/exists/${currentAppId}/${workflowForCheck}/${currentChatId}`
        );
        if (!resp.ok) {
          validatedChatIdRef.current = currentChatId;
          return;
        }

        const result = await resp.json();
        if (result?.exists === false) {
          console.warn('🧹 [CHAT_GUARD] Stale chat id detected; resetting:', currentChatId);
          try {
            const activeWs = wsRef.current;
            if (activeWs && typeof activeWs.close === 'function') {
              activeWs.close();
            }
          } catch {}

          clearStoredArtifactState(currentChatId);
          clearStoredChatCacheSeed(currentChatId);
          setStoredActiveChatId(null);
          validatedChatIdRef.current = null;
          setActiveChatId(null);
          setMessagesWithLogging([]);
          setCurrentChatId(null);
          return;
        }

        validatedChatIdRef.current = currentChatId;
      } catch (err) {
        console.warn('⚠️ [CHAT_GUARD] Chat existence validation failed, keeping current chat id:', err);
        validatedChatIdRef.current = currentChatId;
      } finally {
        validatingChatIdRef.current = false;
      }
    })();
  }, [
    api,
    workflowConfigLoaded,
    currentAppId,
    currentChatId,
    currentWorkflowName,
    urlWorkflowName,
    resolveKnownWorkflowName,
    setActiveChatId,
    setMessagesWithLogging,
  ]);

  // Expose a helper to force-reset the current chat client-side (can be wired to a debug button later)
  const forceResetChat = useCallback(() => {
    const current = getStoredActiveChatId();
    if (current) {
      clearStoredArtifactState(current);
      clearStoredChatCacheSeed(current);
    }
    console.log('🧼 [CACHE] Manual force reset invoked; clearing in-memory state');
    setCurrentArtifactMessages([]);
    lastArtifactEventRef.current = null;
    artifactRestoredOnceRef.current = false;
    artifactCacheValidRef.current = false;
    setCurrentChatId(null);
  }, []);

  // Dev: expose reset helper & read cacheSeed to avoid unused warnings
  useEffect(() => {
    // Use cacheSeed in a benign way (log only when it changes)
    if (cacheSeed !== null) {
      // Minimal, low-noise log – toggle off by removing line if undesired
      console.debug('🧬 Active cacheSeed now', cacheSeed);
    }
    // Expose forceResetChat for manual debugging in console
    try { window.__mozaiksForceResetChat = forceResetChat; } catch {}
    
    // Expose artifact inspection helper
    try {
      window.__mozaiksInspectArtifacts = () => {
        const keys = [];
        const chatId = currentChatId || getStoredActiveChatId();
        console.log('🔍 [DEBUG] Inspecting artifact session cache for chat:', chatId);
        if (chatId) {
          const currentArtifact = readStoredCurrentArtifact(chatId);
          const lastArtifact = readStoredLastArtifact(chatId);
          const cacheSeedValue = getStoredChatCacheSeed(chatId);
          keys.push({ key: `mozaiks.current_artifact.${chatId}`, value: currentArtifact ? JSON.stringify(currentArtifact).slice(0, 200) : null });
          keys.push({ key: `mozaiks.last_artifact.${chatId}`, value: lastArtifact ? JSON.stringify(lastArtifact).slice(0, 200) : null });
          keys.push({ key: `${LOCAL_STORAGE_KEY}.cache_seed.${chatId}`, value: cacheSeedValue });
        }
        
        console.table(keys);
        return keys;
      };
    } catch {}
  }, [cacheSeed, forceResetChat, currentChatId]);

  // Connect to streaming when API becomes available and chat ID exists
  useEffect(() => {
    if (!api) return;
    
    // Wait for workflow configuration to be loaded before connecting
    if (!workflowConfigLoaded) {
  // console.debug('Waiting for workflow configuration to load...');
      return;
    }
    
    // Require chat ID to connect
    if (!currentChatId) {
  // console.debug('Waiting for chat ID to be available...');
      return;
    }
    
    // Prevent duplicate connections
    if (connectionInProgressRef.current) {
      // console.debug('Connection already initialized or in progress, skipping...');
      return;
    }
    if (wsRef.current && wsRef.current.chatId === currentChatId) {
      return;
    }
    
  // console.debug('Establishing WebSocket connection');
    
    // Mark connection as in progress immediately to prevent duplicates
    connectionInProgressRef.current = true;
    setConnectionInitialized(true);
    
    // Define connection functions inside useEffect to avoid dependency issues
    const connectWebSocket = (resolvedWorkflowName = null) => {
      // WebSocket connection for chat communication
      if (!currentChatId) {
        console.error('WebSocket requires existing chat ID');
        return () => {};
      }
      
      setConnectionStatus('connecting');
      setTransportType('websocket');

      const workflowName = resolveKnownWorkflowName(resolvedWorkflowName)
        || resolveKnownWorkflowName(urlWorkflowName)
        || resolveKnownWorkflowName(currentWorkflowName)
        || resolveWorkflow(resolvedWorkflowName || urlWorkflowName || currentWorkflowName);
      if (!workflowName) {
        console.warn('⚠️ No workflow available to connect');
        setConnectionInitialized(false);
        connectionInProgressRef.current = false;
        return () => {};
      }

      // If a stale connection is still around from a prior chat/session, close it first.
      if (wsRef.current && wsRef.current.chatId && wsRef.current.chatId !== currentChatId) {
        try {
          wsRef.current.close();
        } catch {}
        wsRef.current = null;
        setWs(null);
      }

      let connection = null;
      connection = api.createWebSocketConnection(
        currentAppId,
        currentUserId,
        {
          onOpen: () => {
            if (!connection || wsRef.current !== connection) {
              return;
            }
            // console.debug('WebSocket connection established');
            setConnectionStatus('connected');
            setLoading(false);
            // Show one-time spinner ONLY if it has never been shown and never been hidden
            if (!initSpinnerHiddenOnceRef.current && !initSpinnerShownRef.current) {
              console.log('🧹 [SPINNER] Showing initial spinner on WebSocket connect');
              setShowInitSpinner(true);
              initSpinnerShownRef.current = true;
            } else {
              console.log('🧹 [SPINNER] Skipping show on reconnect (hiddenOnce=', initSpinnerHiddenOnceRef.current, 'shownRef=', initSpinnerShownRef.current, ')');
              // Ensure we never regress into showing again this session
              if (initSpinnerHiddenOnceRef.current) {
                initSpinnerShownRef.current = true; // lock state
              }
            }
            setStoredActiveChatId(currentChatId);
          },
          onMessage: (data) => {
            // Ignore callbacks from stale sockets that are no longer active.
            if (!connection || wsRef.current !== connection) {
              return;
            }
            if (handleIncomingRef.current) {
              handleIncomingRef.current(data);
            }
          },
          onError: (error) => {
            if (!connection || wsRef.current !== connection) {
              return;
            }
            console.error("WebSocket error:", error);
            setConnectionStatus('error');
            setLoading(false);
          },
          onClose: () => {
            if (!connection || wsRef.current !== connection) {
              return;
            }
            // console.debug('WebSocket connection closed');
            setConnectionStatus('disconnected');
            wsRef.current = null;
            setWs(null);
          }
        },
        workflowName,
        currentChatId // Pass the existing chat ID
      );

      if (!connection) {
        setConnectionStatus('error');
        setLoading(false);
        setConnectionInitialized(false);
        connectionInProgressRef.current = false;
        return () => {};
      }
      connection.chatId = currentChatId;
      setWs(connection);
      wsRef.current = connection;
  // console.debug('WebSocket connection established:', !!ws);
      return () => {
        if (connection) {
          connection.close();
          // console.debug('WebSocket connection closed');
        }
        if (wsRef.current === connection) {
          wsRef.current = null;
          setWs(null);
        }
      };
    };

    // Query the workflow transport type and use WebSocket connection
    const connectWithCorrectTransport = async () => {
      try {
        // Unified workflow resolution: URL explicit → backend entry_point → singleton → null
        const workflowName = resolveKnownWorkflowName(urlWorkflowName)
          || resolveKnownWorkflowName(currentWorkflowName)
          || resolveWorkflow(urlWorkflowName)
          || resolveWorkflow(currentWorkflowName);
        if (!workflowName) {
          throw new Error('No workflow available');
        }
  // console.debug('Using workflow name:', workflowName);
        
        // Query transport info from backend and use it (was previously unused)
        const transportInfo = await api.getWorkflowTransport(workflowName);
        // transportInfo example: { transport: 'websocket' | 'sse' | 'poll', allow_resume: true }
        if (transportInfo && transportInfo.transport) {
          setTransportType(transportInfo.transport);
        } else {
          setTransportType('websocket');
        }
        // Expose transport flags or capabilities if provided
        if (transportInfo && transportInfo.allow_resume === false) {
          console.debug('Transport indicates resume is disabled for', workflowName);
        }
        setCurrentWorkflowName(workflowName);
        return connectWebSocket(workflowName);
      } catch (error) {
        console.error('Error querying workflow transport:', error);
        // Fallback to WebSocket
        const fallbackWf = resolveKnownWorkflowName(currentWorkflowName)
          || resolveKnownWorkflowName(urlWorkflowName)
          || resolveWorkflow(currentWorkflowName)
          || resolveWorkflow(urlWorkflowName);
        if (!fallbackWf) {
          console.warn('⚠️ No workflow available for fallback');
          setConnectionInitialized(false);
          connectionInProgressRef.current = false;
          return () => {};
        }
        setTransportType('websocket');
        setCurrentWorkflowName(fallbackWf);
        return connectWebSocket(fallbackWf);
      }
    };
    
    // Execute the async function and handle cleanup
    let effectDisposed = false;
    let cleanup = () => {};
    connectWithCorrectTransport().then(cleanupFn => {
      const normalizedCleanup = typeof cleanupFn === 'function' ? cleanupFn : () => {};
      if (effectDisposed) {
        try { normalizedCleanup(); } catch {}
        return;
      }
      cleanup = normalizedCleanup;
    }).catch(error => {
      console.error('Failed to connect with transport:', error);
      // Reset connection flags on error so user can retry
      setConnectionInitialized(false);
      connectionInProgressRef.current = false;
    });
    
    return () => {
      effectDisposed = true;
      if (cleanup) cleanup();
      // Reset the in-progress flag when component unmounts
      connectionInProgressRef.current = false;
    };
  }, [api, currentAppId, currentUserId, workflowConfigLoaded, currentChatId, urlWorkflowName, currentWorkflowName, resolveKnownWorkflowName]);

  // Retry connection function
  const retryConnection = useCallback(() => {
  // console.debug('Retrying connection...');
    setConnectionInitialized(false);
    connectionInProgressRef.current = false;
    setConnectionStatus('disconnected');
    
    // Trigger reconnection by setting up the connection again
    setTimeout(() => {
      if (currentChatId && workflowConfigLoaded) {
        setConnectionStatus('connecting');
      }
    }, 1000);
  }, [currentChatId, workflowConfigLoaded]);

  // Subscribe to DynamicUIHandler updates and insert tool_call render events into chat messages
  useEffect(() => {
    // Bridge workflow UI tool calls into the chat message stream
    const unsubscribe = dynamicUIHandler.onUIUpdate((update) => {
      try {
        if (!update || !update.type) return;

        // ui.update — patch live component payload without re-mounting
        if (update.type === 'ui.update') {
          const { tool_call_id: patchId, patch = {} } = update;
          if (patchId) {
            const applyPatch = (msg) => {
              if (msg?.toolCall?.tool_call_id === patchId || msg?.metadata?.toolCallId === patchId) {
                return { ...msg, toolCall: msg.toolCall ? { ...msg.toolCall, payload: { ...(msg.toolCall.payload || {}), ...patch } } : msg.toolCall };
              }
              return msg;
            };
            setMessagesWithLogging(prev => prev.map(applyPatch));
            setCurrentArtifactMessages(prev => prev.map(applyPatch));
          }
          return;
        }

        // ui.dismiss — remove rendered component
        if (update.type === 'ui.dismiss') {
          const { tool_call_id: dismissId } = update;
          if (dismissId) {
            setMessagesWithLogging(prev => prev.filter(
              msg => !(
                msg?.metadata?.toolCallId === dismissId
                && (
                  msg?.metadata?.type === 'tool_call_agent_message'
                  || msg?.metadata?.type === 'composer_tool_call'
                  || msg?.metadata?.hideInTranscript
                )
              )
            ));
            if (lastArtifactEventRef.current === dismissId) {
              setIsSidePanelOpen(false);
              lastArtifactEventRef.current = null;
              artifactCacheValidRef.current = false;
              setCurrentArtifactMessages([]);
              if (currentChatId) clearStoredArtifactState(currentChatId);
            }
          }
          return;
        }

        // tool_call (legacy InputRequestEvent path) and ui.render (L2 typed path)
        if (update.type === 'tool_call' || update.type === 'ui.render') {
          setPendingWorkflowReply(null);
          if (dispatchSurfaceEvent) {
            dispatchSurfaceEvent(update);
          }
          const { tool_name, payload = {}, tool_call_id, workflow_name, onResponse, display } = update;
          console.log('🧩 [UI] ChatPage received tool_call -> inserting into messages', { tool_name, tool_call_id, workflow_name });
          // If this UI tool requests artifact display, auto-open the ArtifactPanel like OpenAI/Claude canvases
          const displayMode = (display || payload.display || payload.mode);
          const resolvedAgentName =
            payload.agentName
            || payload.agent_name
            || update.agent_name
            || update.agent
            || 'Agent';
          const composerPrompt = String(
            payload.prompt
              || payload.agent_message
              || payload.description
              || ''
          ).trim();
          if (displayMode === 'composer') {
            setMessagesWithLogging((prev) => {
              const withoutThinking = prev.filter((msg) => !msg.isThinking);
              const messageKey = tool_call_id || tool_name;
              const composerMessage = {
                id: `tool-call-${messageKey || Date.now()}`,
                sender: 'agent',
                agentName: resolvedAgentName,
                content: '',
                isStreaming: false,
                toolCall: {
                  tool_name,
                  payload: {
                    ...payload,
                    ...(composerPrompt ? { prompt: composerPrompt } : {}),
                  },
                  tool_call_id,
                  workflow_name,
                  onResponse,
                  display: 'composer',
                  component_type: update.component_type || payload.component_type || tool_name,
                },
                metadata: {
                  type: 'composer_tool_call',
                  toolCallId: messageKey,
                  tool_name,
                  display: 'composer',
                  hideInTranscript: true,
                },
              };

              const existingIndex = withoutThinking.findIndex(
                (msg) => msg?.metadata?.toolCallId === messageKey && msg?.metadata?.hideInTranscript
              );
              if (existingIndex === -1) {
                return [...withoutThinking, composerMessage];
              }

              const updated = [...withoutThinking];
              updated[existingIndex] = {
                ...updated[existingIndex],
                ...composerMessage,
                id: updated[existingIndex]?.id || composerMessage.id,
              };
              return updated;
            });
            return;
          }
          const isViewDisplay = displayMode === 'view' || displayMode === 'fullscreen';
          if (isViewDisplay) {
            const snapshotState = surfaceStateRef.current;
            if (snapshotState?.layoutMode !== 'view') {
              const snapshotLayout = snapshotState?.layoutMode || 'split';
              viewArtifactSnapshotRef.current = {
                isOpen: Boolean(snapshotState?.artifact?.panelOpen),
                layoutMode: snapshotLayout,
                messages: Array.isArray(currentArtifactMessagesRef.current) ? [...currentArtifactMessagesRef.current] : [],
              };
            }
          }
          const shouldRenderArtifact = displayMode === 'artifact' || isViewDisplay;
          if (shouldRenderArtifact) {
            console.log('🖼️ [UI] Auto-opening ArtifactPanel for artifact-mode event');
            if (isMobileView) {
              setMobileDrawerState('expanded');
              setHasUnseenArtifact(false);
            }
            if (!dispatchSurfaceEvent) {
              setIsSidePanelOpen(true);
            }
            const agentText = payload.agent_message || payload.description || null;
            if (agentText) {
              setMessagesWithLogging((prev) => {
                const withoutThinking = prev.filter(msg => !msg.isThinking);
                const hasExisting = withoutThinking.some(msg => msg?.metadata?.toolCallId === (tool_call_id || tool_name) && msg?.metadata?.type === 'tool_call_agent_message');
                if (hasExisting) return withoutThinking;
                return [
                  ...withoutThinking,
                  {
                    id: `tool-call-msg-${tool_call_id || Date.now()}`,
                    sender: 'agent',
                    agentName: resolvedAgentName,
                    content: agentText,
                    isStreaming: false,
                    metadata: { type: 'tool_call_agent_message', toolCallId: tool_call_id || tool_name, tool_name }
                  }
                ];
              });
            }
            // Create artifact payload for ArtifactPanel to render
            let artifactPayload = null;
            try {
              artifactPayload = {
                ...payload,
                artifact_id: deriveArtifactId(payload, tool_call_id || tool_name || null),
              };
              const artifactMsg = {
                id: `tool-call-artifact-${tool_call_id || Date.now()}`,
                sender: 'agent',
                agentName: resolvedAgentName,
                content: artifactPayload.structured_output || artifactPayload.content || artifactPayload || {},
                isStreaming: false,
                toolCall: { tool_name, payload: artifactPayload, tool_call_id, workflow_name, onResponse, display: displayMode, component_type: update.component_type || payload.component_type || tool_name }
              };
              console.log('🖼️ [UI] Setting currentArtifactMessages', artifactMsg.id);
              setCurrentArtifactMessages([artifactMsg]);
              artifactCacheValidRef.current = true;
              
              // Also cache to platform storage for persistence across panel open/close
              try {
                if (currentChatId) {
                  // Create a serializable version without the function
                  const serializableArtifact = {
                    ...artifactMsg,
                    toolCall: {
                      ...artifactMsg.toolCall,
                      onResponse: null // Functions can't be serialized, will be reconstructed on restore
                    }
                  };
                  writeStoredCurrentArtifact(currentChatId, serializableArtifact);
                  console.log('🖼️ [UI] Cached artifact to platform storage');
                }
              } catch (e) { console.warn('Failed to cache artifact', e); }
            } catch (e) { console.warn('Failed to set artifact message', e); }
            // Remember this artifact to collapse on next sequence
            lastArtifactEventRef.current = tool_call_id || tool_name || 'artifact';
            // Persist minimal artifact session state for graceful refresh restore
            try {
              if (currentChatId) {
                const cache = {
                  tool_name,
                  tool_call_id: tool_call_id || null,
                  workflow_name,
                  payload: artifactPayload || payload,
                  display: displayMode || 'artifact',
                  ts: Date.now(),
                };
                writeStoredLastArtifact(currentChatId, cache);
              }
            } catch {}
            // Persist nav trigger cache if configured
            try {
              const navCache = navCacheContextRef.current;
              if (navCache?.cache_ttl && artifactPayload) {
                const artifactWorkflow = workflow_name || currentWorkflowName;
                if (navCache.workflow && artifactWorkflow && navCache.workflow !== artifactWorkflow) {
                  return;
                }
                const cacheWorkflow = navCache.workflow || artifactWorkflow;
                if (cacheWorkflow) {
                  writeNavigationCache(
                    cacheWorkflow,
                    navCache?.input ?? null,
                    {
                      tool_name,
                      tool_call_id: tool_call_id || null,
                      workflow_name: cacheWorkflow,
                      payload: artifactPayload,
                      display: displayMode || 'artifact',
                    },
                    navCache.cache_ttl,
                  );
                }
              }
            } catch (e) {
              console.warn('Failed to cache nav-trigger artifact', e);
            }
            // Don't inject artifact UIs into the chat feed; they'll render in ArtifactPanel only
            return;
          }
          setMessagesWithLogging((prev) => {
            const thinkingMessages = prev.filter(m => m.isThinking);
            if (thinkingMessages.length > 0) {
              console.log('💭 [THINKING] UI tool event (inline) received - removing', thinkingMessages.length, 'thinking bubble(s)');
            }
            
            const withoutThinking = prev.filter(m => !m.isThinking); // Remove thinking bubbles when UI tool event arrives
            return [
              ...withoutThinking,
              {
                id: `tool-call-${tool_call_id || Date.now()}`,
                sender: 'agent',
                agentName: resolvedAgentName,
                content: (payload.agent_message || payload.description || ''), // Surface agent context alongside inline UI
                isStreaming: false,
                toolCall: {
                  tool_name,
                  payload,
                  tool_call_id,
                  workflow_name,
                  onResponse,
                  // Surface display mode for inline Completed chip logic
                  display: displayMode || 'inline',
                  component_type: update.component_type || payload.component_type || tool_name,
                },
              },
            ];
          });
        }
      } catch (err) {
        console.error('❌ Failed to handle DynamicUIHandler update in ChatPage:', err);
      }
    });
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
    }, [setMessagesWithLogging, currentChatId]);

  const isComposerInputRequestToolCall = (toolCall, message = null) => {
    if (!toolCall?.tool_call_id || message?.tool_call_completed) {
      return false;
    }
    const payload = toolCall.payload || {};
    const interactionType = String(
      toolCall.interaction_type || payload.interaction_type || ''
    ).trim().toLowerCase();
    if (interactionType !== 'input_request') {
      return false;
    }
    if (Boolean(payload.password)) {
      return false;
    }
    const displayMode = String(
      toolCall.display || payload.display || payload.mode || ''
    ).trim().toLowerCase();
    return displayMode === 'composer';
  };

  const findPendingComposerInputRequestToolCall = (messageList) => {
    if (!Array.isArray(messageList) || messageList.length === 0) {
      return null;
    }
    for (let index = messageList.length - 1; index >= 0; index -= 1) {
      const message = messageList[index];
      const toolCall = message?.toolCall;
      if (isComposerInputRequestToolCall(toolCall, message)) {
        return toolCall;
      }
    }
    return null;
  };

  const clearPendingComposerInputRequestToolCall = useCallback((toolCallId) => {
    if (!toolCallId) {
      return;
    }
    setMessagesWithLogging((prev) =>
      prev.filter(
        (msg) => !(
          msg?.metadata?.toolCallId === toolCallId
          && msg?.metadata?.hideInTranscript
        )
      )
    );
  }, [setMessagesWithLogging]);

  const buildToolCallTextResponseAction = (toolCall, text = '') => ({
    type: 'tool_call_response',
    tool_name: toolCall.tool_name,
    tool_call_id: toolCall.tool_call_id,
    response: {
      status: 'submitted',
      text,
      user_input: text,
      user_response: text,
    },
  });

  const handlePendingComposerInputSkip = async (toolCall) => {
    if (!toolCall?.tool_call_id) {
      return;
    }
    await handleAgentAction(buildToolCallTextResponseAction(toolCall, ''));
    clearPendingComposerInputRequestToolCall(toolCall.tool_call_id);
    setLoading(true);
  };

  const sendMessage = async (messageContent) => {
    console.log('🚀 [SEND] Sending message:', messageContent);
    console.log('🚀 [SEND] Current chat ID:', currentChatId);
    console.log('🚀 [SEND] Transport type:', transportType);
    console.log('🚀 [SEND] App ID:', currentAppId);
    console.log('🚀 [SEND] User ID:', currentUserId);
    console.log('🚀 [SEND] Workflow name:', currentWorkflowName);

    const artifactContextPayload = messageContent?.artifactContext || currentArtifactContext || null;
    
    // Create a properly structured user message
    const userMessage = {
      id: Date.now().toString(),
      sender: 'user',  // Use 'user' to align message to the right
      agentName: 'You',
      content: messageContent.content,
      timestamp: Date.now(),
      isStreaming: false
    };
    
    console.log('💭 [THINKING] User message sent, adding thinking bubble');
    
    // Optimistic add: add user message to chat immediately, then add thinking indicator
    setMessagesWithLogging(prevMessages => {
      const existingThinking = prevMessages.filter(m => m.isThinking);
      if (existingThinking.length > 0) {
        console.log('💭 [THINKING] Removing', existingThinking.length, 'existing thinking bubble(s)');
      }
      
      const thinkingBubble = {
        id: `thinking-${Date.now()}`,
        sender: 'agent',
        agentName: 'Agent',
        content: '',
        isThinking: true,
        timestamp: Date.now()
      };
      
      console.log('💭 [THINKING] Adding thinking bubble:', thinkingBubble.id);
      
      return [
        ...prevMessages.filter(m => !m.isThinking), // Remove any existing thinking bubbles
        userMessage,
        thinkingBubble
      ];
    });
    
    if (conversationMode === 'ask') {
      const targetChatId = activeGeneralChatId || currentChatId;
      if (!targetChatId) {
        console.error('❌ [SEND] No chat available for ask-mode message');
        return;
      }

      const didSend = sendWsMessage({
        type: 'user.input.submit',
        chat_id: targetChatId,
        text: messageContent.content,
        context: {
          source: 'chat_interface',
          conversation_mode: 'ask',
          general_chat_id: activeGeneralChatId || undefined,
          ...(artifactContextPayload ? { artifact_context: artifactContextPayload } : {}),
        },
      });
      if (!didSend) {
        console.error('❌ [SEND] Failed to send ask-mode message (socket unavailable)');
      } else {
        setLoading(true);
        }
        return;
      }

      const pendingComposerInputRequestToolCall = findPendingComposerInputRequestToolCall(messagesRef.current);
      if (pendingComposerInputRequestToolCall?.tool_call_id) {
        console.log(
          '📤 [SEND] Routing workflow reply through tool_call_response:',
          pendingComposerInputRequestToolCall.tool_call_id
        );
        await handleAgentAction(
          buildToolCallTextResponseAction(
            pendingComposerInputRequestToolCall,
            messageContent.content,
          ),
        );
        clearPendingComposerInputRequestToolCall(pendingComposerInputRequestToolCall.tool_call_id);
        setLoading(true);
        return;
      }

      // Send directly to backend workflow via WebSocket
      try {
      if (!currentChatId) {
        console.error('❌ [SEND] No chat ID available for sending message');
        return;
      }
      
      console.log('📤 [SEND] Sending via WebSocket to workflow...');
      const success = await api.sendMessageToWorkflow(
        messageContent.content, 
        currentAppId, 
        currentUserId, 
        currentWorkflowName,
        currentChatId, // Pass the chat ID
        artifactContextPayload ? { artifact_context: artifactContextPayload } : null
      );
      console.log('📤 [SEND] WebSocket send result:', success);
      if (success) {
        if (pendingWorkflowReply) {
          setPendingWorkflowReply(null);
        }
        setLoading(true);
      }
    } catch (error) {
      console.error('❌ [SEND] Failed to send message via WebSocket:', error);
    }
  };

  const sendWsMessage = useCallback((payload) => {
    const activeWs = wsRef.current;
    if (!activeWs || typeof activeWs.send !== 'function') {
      console.warn('⚠️ No websocket connection available for payload', payload?.type || payload);
      return false;
    }
    try {
      activeWs.send(payload);
      return true;
    } catch (err) {
      console.error('Failed to send websocket payload', payload, err);
      return false;
    }
  }, []);

  const isViewArtifactMessage = useCallback((msg) => {
    const toolCall = msg?.toolCall;
    if (!toolCall) return false;
    const display = toolCall.display || toolCall?.payload?.display || toolCall?.payload?.mode;
    if (display === 'view' || display === 'fullscreen') return true;
    if (toolCall?.payload?.page && toolCall?.payload?.presentation === 'artifact') return true;
    return false;
  }, []);

  const restoreViewSnapshot = useCallback(() => {
    const snapshot = viewArtifactSnapshotRef.current;
    if (!snapshot) return false;
    const nextLayout = snapshot.layoutMode || (snapshot.isOpen ? 'split' : 'full');
    if (setLayoutMode) setLayoutMode(nextLayout);
    setIsSidePanelOpen(Boolean(snapshot.isOpen));
    if (Array.isArray(snapshot.messages)) {
      setCurrentArtifactMessages(snapshot.messages);
    }
    viewArtifactSnapshotRef.current = null;
    return true;
  }, [setLayoutMode, setIsSidePanelOpen, setCurrentArtifactMessages]);

  const clearViewArtifacts = useCallback(() => {
    if (!Array.isArray(currentArtifactMessages) || currentArtifactMessages.length === 0) return false;
    const hasView = currentArtifactMessages.some(isViewArtifactMessage);
    if (hasView) {
      setCurrentArtifactMessages([]);
      return true;
    }
    return false;
  }, [currentArtifactMessages, isViewArtifactMessage, setCurrentArtifactMessages]);

  const exitViewMode = () => {
    const restored = restoreViewSnapshot();
    if (!restored) {
      const cleared = clearViewArtifacts();
      if (setLayoutMode) setLayoutMode('split');
      setIsSidePanelOpen(!cleared);
    }
    if (isMobileView) {
      setMobileDrawerState('expanded');
    }
    if (widgetOverlayOpen) {
      setWidgetOverlayOpen(false);
    }
  };

  const ensureGeneralMode = useCallback((requestedGeneralChatId = null) => {
    const preferredGeneralChatId = requestedGeneralChatId || activeGeneralChatId || getStoredActiveGeneralChatId();
    if (conversationMode === 'ask') {
      if (requestedGeneralChatId) {
        sendWsMessage({
          type: 'chat.enter_general_mode',
          general_chat_id: preferredGeneralChatId || undefined,
        });
      }
      return true;
    }
    workflowReplayPendingRef.current = false;
    console.log('🧠 [MODE_TOGGLE] Switching to ask mode (sending chat.enter_general_mode)');
    const sent = sendWsMessage({
      type: 'chat.enter_general_mode',
      general_chat_id: preferredGeneralChatId || undefined,
    });
    
    // ALWAYS switch to ask mode locally, even if backend is unavailable
    // This ensures the UI updates correctly for offline operation
    setConversationMode('ask');
    // Cache workflow messages and snapshot artifact panel state
    console.log('🧹 [MODE_TOGGLE] Caching workflow messages + artifact state, closing artifact panel, restoring ask-mode messages');
    workflowMessagesCacheRef.current = messagesRef.current;
    workflowArtifactSnapshotRef.current = {
      isOpen: isSidePanelOpen,
      layoutMode: layoutMode || 'split',
      messages: isSidePanelOpen ? [...currentArtifactMessages] : []
    };
    console.log('📸 [ARTIFACT_SNAPSHOT] Saved artifact state before switching to Ask:', workflowArtifactSnapshotRef.current);
    // Close artifact panel when entering Ask mode
    setIsSidePanelOpen(false);
    setCurrentArtifactMessages([]);
    // Restore cached general messages if available (prefer shared askMessages)
    if (askMessages && askMessages.length > 0) {
      console.log(`📦 [MODE_TOGGLE] Restoring ${askMessages.length} cached ask-mode messages (shared)`);
      setMessagesWithLogging(askMessages);
    } else if (generalMessagesCacheRef.current && generalMessagesCacheRef.current.length > 0) {
      console.log(`📦 [MODE_TOGGLE] Restoring ${generalMessagesCacheRef.current.length} cached ask-mode messages`);
      setMessagesWithLogging(generalMessagesCacheRef.current);
    } else {
      console.log('📭 [MODE_TOGGLE] No cached ask-mode messages, starting fresh');
      setMessagesWithLogging([]);
    }
    
    refreshGeneralSessions();
    return sent;
  }, [activeGeneralChatId, conversationMode, refreshGeneralSessions, sendWsMessage, setConversationMode, setMessagesWithLogging, currentArtifactMessages, isSidePanelOpen, layoutMode, askMessages]);

  const startNewGeneralSession = useCallback(() => {
    const sent = sendWsMessage({ type: 'chat.start_general_chat' });
    // Always update local state, even if backend is unavailable
    setConversationMode('ask');
    refreshGeneralSessions();
    generalMessagesCacheRef.current = [];
    setMessagesWithLogging([]);
    return sent;
  }, [refreshGeneralSessions, sendWsMessage, setConversationMode, setMessagesWithLogging]);

  const handleSelectGeneralChat = useCallback((chatId) => {
    if (!chatId || generalHydrationPendingRef.current) {
      return;
    }
    ensureGeneralMode(chatId);
    generalHydrationPendingRef.current = true;
    setActiveGeneralChatId(chatId);
    const session = (generalChatSessions || []).find((item) => item?.chat_id === chatId);
    if (session) {
      setGeneralChatSummary({
        chatId,
        label: session.label || session.chat_id,
        lastUpdatedAt: session.last_updated_at || session.updated_at,
        lastSequence: session.last_sequence ?? session.sequence,
      });
    }
    setMessagesWithLogging([]);
    Promise.resolve(hydrateGeneralTranscript(chatId)).finally(() => {
      generalHydrationPendingRef.current = false;
    });
  }, [ensureGeneralMode, generalChatSessions, hydrateGeneralTranscript, setActiveGeneralChatId, setGeneralChatSummary, setMessagesWithLogging]);

  const handleRefreshGeneralSessions = useCallback(() => {
    refreshGeneralSessions();
  }, [refreshGeneralSessions]);

  const handleClearGeneralSessions = useCallback(async () => {
    if (!api || typeof api.clearGeneralChats !== 'function' || !currentAppId || !currentUserId) {
      return;
    }

    const confirmed = typeof window === 'undefined'
      ? true
      : window.confirm('Clear all Ask conversations for this app and user?');
    if (!confirmed) {
      return;
    }

    setGeneralSessionsLoading(true);
    try {
      await api.clearGeneralChats(currentAppId, currentUserId, { status: 'all' });
      setGeneralChatSessions([]);
      setActiveGeneralChatId(null);
      setGeneralChatSummary(null);
      generalMessagesCacheRef.current = [];
      if (conversationMode === 'ask') {
        setMessagesWithLogging([]);
      }
      console.log('🧹 [ASK] Cleared general chat sessions');
    } catch (err) {
      console.error('Failed to clear general chat sessions:', err);
    } finally {
      setGeneralSessionsLoading(false);
    }
  }, [
    api,
    currentAppId,
    currentUserId,
    conversationMode,
    setActiveGeneralChatId,
    setGeneralChatSummary,
    setGeneralChatSessions,
    setMessagesWithLogging,
  ]);

  const ensureWorkflowMode = useCallback((options = {}) => {
    const { sendSwitch = true, forceRestore = false } = options;
    if (conversationMode === 'workflow' && !forceRestore) {
      return true;
    }
    if (!currentChatId) {
      console.warn('⚠️ Cannot resume workflow mode without chat id, switching mode anyway');
    }
    console.log(`🤖 [MODE_TOGGLE] Switching to workflow mode (${sendSwitch ? 'sending chat.switch_workflow' : 'local shell only'})`);
    const sent = sendSwitch && currentChatId
      ? sendWsMessage({ type: 'chat.switch_workflow', chat_id: currentChatId })
      : false;
    
    // ALWAYS switch to workflow mode locally, even if backend is unavailable
    setConversationMode('workflow');
    // Cache general messages and restore workflow messages + artifact panel state
    console.log('🧹 [MODE_TOGGLE] Caching ask-mode messages, restoring workflow messages + artifact panel state');
    generalMessagesCacheRef.current = messagesRef.current;
    
    // Restore cached workflow messages (prefer shared workflowMessages)
    const sharedWorkflowMessages = sanitizeVisibleWorkflowMessages(workflowMessages);
    const cachedWorkflowMessages = sanitizeVisibleWorkflowMessages(workflowMessagesCacheRef.current);
    if (sharedWorkflowMessages.length > 0) {
      console.log(`📦 [MODE_TOGGLE] Restoring ${sharedWorkflowMessages.length} cached workflow messages (shared)`);
      setMessagesWithLogging(sharedWorkflowMessages);
    } else if (cachedWorkflowMessages.length > 0) {
      console.log(`📦 [MODE_TOGGLE] Restoring ${cachedWorkflowMessages.length} cached workflow messages`);
      setMessagesWithLogging(cachedWorkflowMessages);
    } else {
      console.log('📭 [MODE_TOGGLE] No cached workflow messages, starting fresh');
      setMessagesWithLogging([]);
    }
    
    // Restore artifact panel state from snapshot (respecting user's previous state)
    // Use setTimeout to ensure this runs after React state updates settle
    setTimeout(() => {
      const surfaceSnapshot = surfaceStateRef.current;
      if (surfaceSnapshot?.layoutMode === 'view'
        || surfaceSnapshot?.artifact?.display === 'view'
        || surfaceSnapshot?.artifact?.display === 'fullscreen') {
        console.log('🎨 [ARTIFACT_RESTORE] Skipping snapshot restore; view mode active');
        return;
      }
      const snapshot = workflowArtifactSnapshotRef.current;
      console.log('🎨 [ARTIFACT_RESTORE] Checking snapshot:', snapshot);
      
      // If we have a snapshot, always respect it (whether open or closed)
      if (snapshot && typeof snapshot.isOpen === 'boolean') {
        if (snapshot.isOpen) {
          console.log('🎨 [ARTIFACT_SNAPSHOT_RESTORE] Restoring artifact panel OPEN from snapshot');
          setIsSidePanelOpen(true);
          if (snapshot.layoutMode && setLayoutMode) {
            setLayoutMode(snapshot.layoutMode);
          }
          if (snapshot.messages?.length) {
            setCurrentArtifactMessages(snapshot.messages);
            console.log(`📦 [ARTIFACT_SNAPSHOT_RESTORE] Restored ${snapshot.messages.length} artifact messages`);
          }
        } else {
          // User had artifact closed - respect that choice
          console.log('🎨 [ARTIFACT_SNAPSHOT_RESTORE] Restoring artifact panel CLOSED from snapshot');
          setIsSidePanelOpen(false);
          if (setLayoutMode) setLayoutMode('full');
          // Keep any artifact messages cached but panel closed
        }
        // Clear snapshot after restore to allow fresh state capture next time
        workflowArtifactSnapshotRef.current = { isOpen: false, messages: [], layoutMode: 'split' };
        return;
      }
      
      // No valid snapshot - fall back to auto-detect based on message content
      // This only happens on first workflow entry, not when toggling back
      const cachedMessages = workflowMessagesCacheRef.current || [];
      const hasArtifacts = cachedMessages.some(msg => {
        if (msg.ui_mode) return true;
        if (msg.tool_calls && Array.isArray(msg.tool_calls)) {
          return msg.tool_calls.some(tc => tc.function?.name === 'render_ui_component');
        }
        return false;
      });
      
      if (hasArtifacts) {
        console.log('🎨 [ARTIFACT_AUTO_OPEN] Detected UI artifacts in workflow messages, opening artifact panel');
        setIsSidePanelOpen(true);
        if (setLayoutMode) setLayoutMode('split');
        const artifactMsgs = cachedMessages.filter(msg => 
          msg.ui_mode || (msg.tool_calls && msg.tool_calls.some(tc => tc.function?.name === 'render_ui_component'))
        );
        if (artifactMsgs.length > 0) {
          setCurrentArtifactMessages(artifactMsgs);
          console.log(`📦 [ARTIFACT_AUTO_OPEN] Restored ${artifactMsgs.length} artifact messages`);
        }
      } else {
        console.log('📭 [ARTIFACT_AUTO_OPEN] No UI artifacts detected, keeping panel closed');
        setIsSidePanelOpen(false);
        if (setLayoutMode) setLayoutMode('full');
      }
    }, 100);
    
    return sendSwitch ? sent : true;
  }, [conversationMode, currentChatId, sanitizeVisibleWorkflowMessages, sendWsMessage, setConversationMode, setMessagesWithLogging, setLayoutMode, workflowMessages]);

  const resumeWorkflowSession = useCallback((targetChatId, targetWorkflow = null) => {
    if (!targetChatId) {
      console.warn('🔁 [WORKFLOW_RESUME] Missing chat_id, cannot resume');
      return false;
    }

    const resolvedWorkflow = targetWorkflow || currentWorkflowName || resolveWorkflow();
    console.log('🔁 [WORKFLOW_RESUME] Attempting resume for chat:', targetChatId, 'workflow:', resolvedWorkflow);

    setCurrentChatId(targetChatId);
    setActiveChatId(targetChatId);
    setActiveWorkflowName(resolvedWorkflow);
    currentWorkflowNameRef.current = resolvedWorkflow;
    setCurrentWorkflowName(resolvedWorkflow);

    // Reset visible transcript before workflow replay arrives to avoid
    // mixing Ask-mode messages with workflow history.
    workflowReplayPendingRef.current = true;
    setMessagesWithLogging([]);

    // Clear cached workflow messages to prevent stale restore on resume_boundary.
    // This ensures that if the backend has no persisted messages (fresh start),
    // we don't accidentally restore old cached messages from a previous session.
    workflowMessagesSharedRef.current = [];
    workflowMessagesCacheRef.current = [];

    const sent = sendWsMessage({
      type: 'chat.switch_workflow',
      chat_id: targetChatId,
      replay_on_switch: true,
    });
    console.log('🔁 [WORKFLOW_RESUME] chat.switch_workflow sent:', sent);

    if (sent) {
      setConversationMode('workflow');
      generalMessagesCacheRef.current = messagesRef.current;
      console.log('🔁 [WORKFLOW_RESUME] Workflow mode restored, cached general messages count:', messagesRef.current.length);
      return true;
    }

    workflowReplayPendingRef.current = false;

    return false;
  }, [currentWorkflowName, sendWsMessage, setActiveChatId, setActiveWorkflowName, setConversationMode, setCurrentWorkflowName, setCurrentChatId, setMessagesWithLogging]);

  const handleSelectWorkflowSession = useCallback((chatId, workflowName = null) => {
    if (!chatId) {
      return;
    }
    const targetWorkflow =
      resolveKnownWorkflowName(workflowName)
      || resolveKnownWorkflowName(activeWorkflowName)
      || resolveKnownWorkflowName(currentWorkflowName)
      || resolveKnownWorkflowName(configuredEntryWorkflow)
      || resolveWorkflow();

    const resumed = resumeWorkflowSession(chatId, targetWorkflow);
    if (resumed) {
      refreshWorkflowSessions();
    }
  }, [
    activeWorkflowName,
    currentWorkflowName,
    configuredEntryWorkflow,
    resolveKnownWorkflowName,
    resumeWorkflowSession,
    setLayoutMode,
    refreshWorkflowSessions,
  ]);

  const handleRefreshWorkflowSessions = useCallback(() => {
    refreshWorkflowSessions();
  }, [refreshWorkflowSessions]);

  const handleClearWorkflowSessions = useCallback(async () => {
    if (!api || typeof api.clearWorkflowSessions !== 'function' || !currentAppId || !currentUserId) {
      return;
    }

    const confirmed = typeof window === 'undefined'
      ? true
      : window.confirm('Clear all workflow runs for this app and user?');
    if (!confirmed) {
      return;
    }

    setWorkflowSessionsLoading(true);
    try {
      const existing = Array.isArray(workflowSessions) ? workflowSessions : [];
      await api.clearWorkflowSessions(currentAppId, currentUserId, { status: 'all' });
      for (const session of existing) {
        const chatId = session?.chat_id;
        if (!chatId) continue;
        clearStoredArtifactState(chatId);
        clearStoredChatCacheSeed(chatId);
      }
      setWorkflowSessions([]);
      setStoredActiveChatId(null);
      if (conversationMode === 'workflow') {
        setMessagesWithLogging([]);
        setCurrentArtifactMessages([]);
      }
      console.log('🧹 [WORKFLOW] Cleared workflow sessions');
    } catch (err) {
      console.error('Failed to clear workflow sessions:', err);
    } finally {
      setWorkflowSessionsLoading(false);
    }
  }, [
    api,
    currentAppId,
    currentUserId,
    workflowSessions,
    conversationMode,
    setMessagesWithLogging,
    setWorkflowSessions,
  ]);

  const resolveResumePolicyOrder = useCallback(() => {
    const policy = String(configuredResumePolicy || 'last_active_then_oldest_then_entry_point').toLowerCase().trim();
    const policyMap = {
      last_active_then_oldest_then_entry_point: ['last_active', 'oldest', 'entry_point'],
      last_active_then_recent_then_entry_point: ['last_active', 'recent', 'entry_point'],
      recent_then_entry_point: ['recent', 'entry_point'],
      oldest_then_entry_point: ['oldest', 'entry_point'],
      entry_point_only: ['entry_point'],
    };
    return policyMap[policy] || ['last_active', 'oldest', 'entry_point'];
  }, [configuredResumePolicy]);

  const describeApiError = useCallback((error) => ({
    status: error?.status || null,
    message: error?.message || String(error),
    body: error?.body || null,
  }), []);

  const resolveWorkflowSessionByStrategy = useCallback(async (strategy) => {
    const normalized = String(strategy || '').toLowerCase();
    const fallbackWorkflowName =
      resolveKnownWorkflowName(activeWorkflowName)
      || resolveKnownWorkflowName(currentWorkflowName)
      || resolveKnownWorkflowName(getStoredActiveWorkflowName())
      || resolveKnownWorkflowName(configuredEntryWorkflow);

    if (normalized === 'last_active') {
      const shouldRestoreStoredWorkflowChat = !(
        conversationMode === 'ask'
      );
      if (!shouldRestoreStoredWorkflowChat) {
        return null;
      }
      const lastActiveChatId = activeChatId || currentChatId || getStoredActiveChatId();
      if (!lastActiveChatId) {
        return null;
      }
      // last_active should only resume chats that are still IN_PROGRESS.
      // If the chat is completed, fall through to next resume strategy.
      if (Array.isArray(workflowSessions) && workflowSessions.length > 0) {
        const isActiveSession = workflowSessions.some((s) => s?.chat_id === lastActiveChatId);
        if (!isActiveSession) {
          return null;
        }
      } else if (api && typeof api.get === 'function' && currentAppId && currentUserId) {
        try {
          const listed = await api.get(`/api/sessions/list/${currentAppId}/${currentUserId}`);
          const sessions = Array.isArray(listed?.sessions) ? listed.sessions : [];
          const isActiveSession = sessions.some((s) => s?.chat_id === lastActiveChatId);
          if (!isActiveSession) {
            return null;
          }
        } catch (err) {
          console.warn('Failed to validate last_active workflow session:', describeApiError(err));
          return null;
        }
      }
      return {
        strategy: 'last_active',
        chat_id: lastActiveChatId,
        workflow_name: fallbackWorkflowName || resolveWorkflow() || null,
      };
    }

    if (!api || typeof api.get !== 'function' || !currentAppId || !currentUserId) {
      return null;
    }

    if (normalized === 'recent') {
      try {
        const recent = await api.get(`/api/sessions/recent/${currentAppId}/${currentUserId}`);
        if (recent?.found && recent?.chat_id) {
          return {
            strategy: 'recent',
            chat_id: recent.chat_id,
            workflow_name: recent.workflow_name || fallbackWorkflowName || null,
          };
        }
      } catch (err) {
        console.warn('Failed to resolve recent workflow session:', describeApiError(err));
      }
      return null;
    }

    if (normalized === 'oldest') {
      try {
        const oldest = await api.get(`/api/sessions/oldest/${currentAppId}/${currentUserId}`);
        if (oldest?.found && oldest?.chat_id) {
          return {
            strategy: 'oldest',
            chat_id: oldest.chat_id,
            workflow_name: oldest.workflow_name || fallbackWorkflowName || null,
          };
        }
      } catch (err) {
        if (err?.status !== 404) {
          console.warn('Failed to resolve oldest workflow session:', describeApiError(err));
          return null;
        }
        // Backward fallback for runtimes without /sessions/oldest.
        try {
          const listed = await api.get(`/api/sessions/list/${currentAppId}/${currentUserId}`);
          const sessions = Array.isArray(listed?.sessions) ? [...listed.sessions] : [];
          if (sessions.length === 0) {
            return null;
          }
          sessions.sort((a, b) => {
            const aTs = Date.parse(a?.created_at || '') || Number.MAX_SAFE_INTEGER;
            const bTs = Date.parse(b?.created_at || '') || Number.MAX_SAFE_INTEGER;
            return aTs - bTs;
          });
          const first = sessions[0];
          if (first?.chat_id) {
            return {
              strategy: 'oldest',
              chat_id: first.chat_id,
              workflow_name: first.workflow_name || fallbackWorkflowName || null,
            };
          }
        } catch (fallbackErr) {
          console.warn('Failed to resolve oldest session from list fallback:', describeApiError(fallbackErr));
        }
      }
      return null;
    }

    return null;
  }, [
    activeChatId,
    currentChatId,
    activeWorkflowName,
    currentWorkflowName,
    describeApiError,
    resolveKnownWorkflowName,
    configuredEntryWorkflow,
    api,
    currentAppId,
    currentUserId,
    workflowSessions,
    conversationMode,
  ]);

  const handleConversationModeChange = useCallback(async (mode) => {
    if (modeChangeInProgressRef.current) {
      console.log('⏳ [MODE_CHANGE] Ignoring duplicate mode toggle while a transition is already in progress');
      return;
    }

    modeChangeInProgressRef.current = true;
    setModeChangePending(true);

    console.log('🔄 [MODE_CHANGE] handleConversationModeChange called with mode:', mode);
    console.log('🔄 [MODE_CHANGE] Current conversationMode:', conversationMode);
    console.log('🔄 [MODE_CHANGE] Current activeChatId (from context):', activeChatId);
    console.log('🔄 [MODE_CHANGE] Current activeWorkflowName (from context):', activeWorkflowName);
    console.log('🔄 [MODE_CHANGE] Current currentChatId (local state):', currentChatId);

    try {
      if (mode === 'ask') {
        console.log('🧠 [MODE_CHANGE] Switching to Ask mode');
        resumeOldestFromWidgetRef.current = false;
        queryResumeHandledRef.current = null;
        consumeNavigationQueryParams(['mode', 'resume', 'chat_id']);
        ensureGeneralMode();
        if (setLayoutMode) setLayoutMode('full');
        if (isMobileView) setMobileDrawerState('peek');
      } else {
        console.log('🤖 [MODE_CHANGE] Switching to workflow mode, resolving session with resume policy');
        console.log('🤖 [MODE_CHANGE] isInWidgetMode:', isInWidgetMode);
        console.log('🤖 [MODE_CHANGE] API available?', !!api);
        console.log('🤖 [MODE_CHANGE] App ID:', currentAppId);
        console.log('🤖 [MODE_CHANGE] User ID:', currentUserId);

        // Flip the shell immediately so the UI responds on click even if backend session APIs are slow.
        ensureWorkflowMode({ sendSwitch: false, forceRestore: true });

        if (!workflowConfigLoaded) {
          console.log('🤖 [MODE_CHANGE] Workflow registry not ready yet, waiting for fetch');
          await workflowConfig.fetchWorkflowConfigs();
          setWorkflowConfigLoaded(true);
        }

        const canonicalWorkflowName =
          resolveKnownWorkflowName(urlWorkflowName)
          || resolveKnownWorkflowName(configuredEntryWorkflow)
          || resolveKnownWorkflowName(currentWorkflowName)
          || resolveKnownWorkflowName(activeWorkflowName)
          || resolveKnownWorkflowName(getStoredActiveWorkflowName())
          || resolveWorkflow(currentWorkflowName)
          || resolveWorkflow(urlWorkflowName)
          || workflowConfig.getDefaultWorkflow();

        if (canonicalWorkflowName && canonicalWorkflowName !== currentWorkflowName) {
          setCurrentWorkflowName(canonicalWorkflowName);
        }
        if (canonicalWorkflowName && canonicalWorkflowName !== activeWorkflowName) {
          setActiveWorkflowName(canonicalWorkflowName);
        }

        if (layoutMode === 'view') {
          console.log('🧭 [MODE_CHANGE] Leaving view mode -> restoring workflow surface');
          const restored = restoreViewSnapshot();
          if (!restored) {
            clearViewArtifacts();
          }
        }

        if (!api || typeof api.get !== 'function' || !currentAppId || !currentUserId) {
          const storedChatId = activeChatId || currentChatId || getStoredActiveChatId();
          const storedWorkflowName = canonicalWorkflowName || resolveKnownWorkflowName(getStoredActiveWorkflowName());

          if (storedChatId) {
            setCurrentChatId(storedChatId);
            setActiveChatId(storedChatId);
          }
          if (storedWorkflowName) {
            setActiveWorkflowName(storedWorkflowName);
            setCurrentWorkflowName(storedWorkflowName);
          }

          return;
        }

        if (isInWidgetMode) {
          console.log('🚀 [MODE_CHANGE] In widget mode - navigating to /chat');
          navigate('/chat');
          setIsInWidgetMode(false);
        }

        const startEntryWorkflowSession = async () => {
          console.log('📭 [MODE_CHANGE] No resumable workflow session — starting entry_point workflow');
          const entryWorkflow =
            canonicalWorkflowName
            || resolveKnownWorkflowName(configuredEntryWorkflow)
            || resolveWorkflow(currentWorkflowName)
            || resolveWorkflow(urlWorkflowName)
            || workflowConfig.getDefaultWorkflow();
          if (!entryWorkflow) {
            console.warn('⚠️ [MODE_CHANGE] No entry_point workflow available to start');
            return false;
          }

          try {
            const askCarrierMode = queryMode === 'ask' || conversationMode === 'ask';
            const result = await api.startChat(
              currentAppId,
              entryWorkflow,
              currentUserId,
              {},
              null,
              null,
              askCarrierMode ? { transportPurpose: 'ask_carrier' } : null,
            );
            if (result && (result.chat_id || result.id)) {
              const newChatId = result.chat_id || result.id;
              console.log(`🚀 [MODE_CHANGE] Created new session for ${entryWorkflow}: ${newChatId}`);
              setCurrentChatId(newChatId);
              setActiveChatId(newChatId);
              setActiveWorkflowName(entryWorkflow);
              setCurrentWorkflowName(entryWorkflow);
              setStoredActiveChatId(newChatId);

              setConnectionInitialized(false);
              connectionInProgressRef.current = false;

              setConversationMode('workflow');
              generalMessagesCacheRef.current = messagesRef.current;
              refreshWorkflowSessions();
              console.log('✅ [MODE_CHANGE] Entry_point workflow session started, WS will connect on re-render');
              return true;
            }

            console.error('❌ [MODE_CHANGE] startChat returned no chat_id:', result);
            return false;
          } catch (startErr) {
            console.error('❌ [MODE_CHANGE] Failed to start entry_point workflow session:', describeApiError(startErr));
            return false;
          }
        };

        try {
          const policyOrder = resolveResumePolicyOrder();
          console.log('🧭 [MODE_CHANGE] Resume policy order:', policyOrder.join(' -> '));

          let resumed = false;
          for (const strategy of policyOrder) {
            if (strategy === 'entry_point') {
              continue;
            }
            const target = await resolveWorkflowSessionByStrategy(strategy);
            if (!target?.chat_id) {
              continue;
            }
            const targetWorkflowName = resolveKnownWorkflowName(target.workflow_name)
              || canonicalWorkflowName
              || resolveWorkflow(currentWorkflowName)
              || resolveWorkflow(urlWorkflowName);
            console.log(`🎯 [MODE_CHANGE] Resuming workflow via ${strategy}: ${targetWorkflowName} (${target.chat_id})`);
            resumed = resumeWorkflowSession(target.chat_id, targetWorkflowName);
            if (resumed) {
              generalMessagesCacheRef.current = messagesRef.current;
              refreshWorkflowSessions();
              break;
            }
            console.warn(`⚠️ [MODE_CHANGE] Resume send failed for strategy ${strategy}; trying next option`);
          }

          if (!resumed) {
            await startEntryWorkflowSession();
          }
        } catch (err) {
          console.error('❌ [MODE_CHANGE] Error resolving workflow session:', describeApiError(err));
          console.log('🔄 [MODE_CHANGE] Staying in local workflow shell while backend is unavailable');
        }
      }

      console.log('✅ [MODE_CHANGE] handleConversationModeChange completed');
    } finally {
      modeChangeInProgressRef.current = false;
      setModeChangePending(false);
    }
  }, [
    ensureGeneralMode,
    ensureWorkflowMode,
    restoreViewSnapshot,
    clearViewArtifacts,
    setLayoutMode,
    api,
    currentAppId,
    currentUserId,
    sendWsMessage,
    setConversationMode,
    setCurrentChatId,
    setActiveChatId,
    setActiveWorkflowName,
    conversationMode,
    activeChatId,
    activeWorkflowName,
    isInWidgetMode,
    navigate,
    setIsInWidgetMode,
    currentChatId,
    isMobileView,
    setMobileDrawerState,
    layoutMode,
    workflowConfigLoaded,
    resolveKnownWorkflowName,
    configuredEntryWorkflow,
    configuredResumePolicy,
    refreshWorkflowSessions,
    resolveResumePolicyOrder,
    resolveWorkflowSessionByStrategy,
    resumeWorkflowSession,
    describeApiError,
    modeChangePending,
    consumeNavigationQueryParams,
  ]);

  useEffect(() => {
    if (!resumeOldestFromWidgetRef.current) {
      return;
    }
    if (conversationMode !== 'workflow') {
      return;
    }
    resumeOldestFromWidgetRef.current = false;
    handleConversationModeChange('workflow');
  }, [conversationMode, handleConversationModeChange]);

  useEffect(() => {
    if (layoutMode !== 'view') {
      return;
    }
    if (!isPrimaryChatRoute || isInWidgetMode) {
      return;
    }
    const hasArtifact = Array.isArray(currentArtifactMessages) && currentArtifactMessages.length > 0;
    const artifactActive = surfaceState?.artifact?.status === 'active';
    if (hasArtifact || artifactActive) {
      return;
    }
    setLayoutMode(layoutModeForConversation);
    if (widgetOverlayOpen) {
      setWidgetOverlayOpen(false);
    }
  }, [
    layoutMode,
    layoutModeForConversation,
    isPrimaryChatRoute,
    isInWidgetMode,
    currentArtifactMessages,
    surfaceState,
    setLayoutMode,
    widgetOverlayOpen,
    setWidgetOverlayOpen,
  ]);

  useEffect(() => {
    if (!queryChatId) {
      return;
    }
    if (queryMode === 'ask') {
      return;
    }
    if (!isPrimaryChatRoute) {
      return;
    }
    if (connectionStatus !== 'connected') {
      return;
    }

    const workflowFromQuery = urlWorkflowName || currentWorkflowName;
    const cacheKey = `${queryChatId}:${workflowFromQuery || ''}`;
    if (queryResumeHandledRef.current === cacheKey) {
      return;
    }

    let cancelled = false;

    const attemptRouteResume = async () => {
      const workflowForCheck =
        resolveKnownWorkflowName(workflowFromQuery)
        || resolveKnownWorkflowName(currentWorkflowName)
        || workflowConfig.getDefaultWorkflow()
        || workflowFromQuery;

      if (api && typeof api.getHttpBaseUrl === 'function' && currentAppId && workflowForCheck) {
        try {
          const response = await fetch(
            `${api.getHttpBaseUrl()}/api/chats/exists/${currentAppId}/${workflowForCheck}/${queryChatId}`
          );
          if (cancelled) {
            return;
          }

          if (response.ok) {
            const result = await response.json();
            if (cancelled) {
              return;
            }
            if (result?.exists === false) {
              console.warn('🧹 [ROUTE_RESUME] Ignoring stale query chat_id after backend reset:', queryChatId);
              clearStoredArtifactState(queryChatId);
              clearStoredChatCacheSeed(queryChatId);
              if (getStoredActiveChatId() === queryChatId) {
                setStoredActiveChatId(null);
              }
              if (activeChatId === queryChatId) {
                setActiveChatId(null);
              }
              queryResumeHandledRef.current = cacheKey;
              consumeNavigationQueryParams(['chat_id']);
              return;
            }
          }
        } catch (err) {
          console.warn('⚠️ [ROUTE_RESUME] Could not validate query chat_id, attempting resume anyway:', err);
        }
      }

      console.log('🧭 [ROUTE_RESUME] Detected chat_id in URL, attempting resume:', { queryChatId, workflowFromQuery });
      if (isInWidgetMode) {
        console.log('🧭 [ROUTE_RESUME] Exiting widget mode for direct resume');
        setIsInWidgetMode(false);
      }

      const success = resumeWorkflowSession(queryChatId, workflowFromQuery);
      if (success) {
        queryResumeHandledRef.current = cacheKey;
        consumeNavigationQueryParams(['chat_id']);
      }
    };

    attemptRouteResume();

    return () => {
      cancelled = true;
    };
  }, [queryChatId, queryMode, urlWorkflowName, currentWorkflowName, resumeWorkflowSession, conversationMode, connectionStatus, isInWidgetMode, setIsInWidgetMode, isPrimaryChatRoute, resolveKnownWorkflowName, api, currentAppId, activeChatId, setActiveChatId, consumeNavigationQueryParams]);

  const handleStartGeneralChat = useCallback(() => {
    startNewGeneralSession();
  }, [startNewGeneralSession]);

  // Force Ask mode once when transitioning away from the primary chat routes
  useEffect(() => {
    const wasPrimary = lastPrimaryRouteRef.current;
    if (!isPrimaryChatRoute && wasPrimary) {
      ensureGeneralMode();
    }
    lastPrimaryRouteRef.current = isPrimaryChatRoute;
  }, [ensureGeneralMode, isPrimaryChatRoute]);

  const sendArtifactAction = useCallback((action, contextData = {}) => {
    if (!action || !action.tool) {
      return null;
    }

    const artifactPayload = contextData?.artifactPayload || contextData?.payload || contextData || {};
    const fallbackId = currentArtifactContext?.id || (lastArtifactEventRef.current ? String(lastArtifactEventRef.current) : null);
    const artifactId = deriveArtifactId(artifactPayload, fallbackId);
    const actionId = (crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`);

    const paramsContext = {
      artifact: artifactPayload,
      ...artifactPayload,
      ...contextData,
      artifact_id: artifactId,
      app_id: currentAppId,
      chat_id: currentChatId,
      user_id: currentUserId,
      workflow_name: currentWorkflowName,
    };
    const params = interpolateParams(action.params || {}, paramsContext);

    const payload = {
      type: 'artifact.action',
      action_id: actionId,
      artifact_id: artifactId,
      tool: action.tool,
      params,
      context: {
        chat_id: currentChatId,
        app_id: currentAppId,
        user_id: currentUserId,
        workflow_name: currentWorkflowName,
      }
    };

    const connection = wsRef.current;
    if (connection && typeof connection.send === 'function') {
      connection.send(payload);
      setActionStatusMap((prev) => ({
        ...prev,
        [actionId]: { status: 'pending', tool: action.tool, artifact_id: artifactId, started_at: Date.now() }
      }));
      if (action.optimistic) {
        applyOptimisticForAction(actionId, artifactId, action.optimistic);
      }
    } else {
      console.warn('No WebSocket connection available for artifact.action');
      return null;
    }

    return actionId;
  }, [
    currentArtifactContext,
    currentChatId,
    currentUserId,
    currentAppId,
    currentWorkflowName,
    applyOptimisticForAction,
  ]);

  // Handle agent UI actions
  const handleAgentAction = async (action) => {
    console.log('Agent action received in chat page:', action);
    
    try {
      // Handle UI tool responses for the dynamic UI system
      if (action.type === 'tool_call_response') {
        console.log('🎯 Processing UI tool response:', action);

        // If this response corresponds to the most recent artifact event, close the panel immediately
        if (lastArtifactEventRef.current && (!action.tool_call_id || action.tool_call_id === lastArtifactEventRef.current)) {
          try { console.log('🧹 [UI] Artifact response received; collapsing ArtifactPanel now'); } catch {}
          setIsSidePanelOpen(false);
          if (dispatchSurfaceAction) {
            dispatchSurfaceAction({ type: 'ARTIFACT_CLEARED' });
          }
            lastArtifactEventRef.current = null;
          console.log('🖼️ [UI] Clearing currentArtifactMessages due to response');
          setCurrentArtifactMessages([]);
          // Clear persisted artifact cache for this chat
          if (currentChatId) {
            clearStoredArtifactState(currentChatId);
          }
        }
        // If we lack a real tool_call_id (e.g., restored artifact), don't submit to backend; just close locally
        if (!action.tool_call_id) {
          console.log('ℹ️ Skipping backend submission for restored UI tool response (no tool_call_id)');
          return;
        }

        const payload = {
          event_id: action.tool_call_id,
          response_data: action.response
        };

        // Send the UI tool response to the backend
        try {
          const submitPath = '/api/tool-call/respond';
          const baseUrl = api && typeof api.getHttpBaseUrl === 'function'
            ? api.getHttpBaseUrl()
            : null;
          const submitUrl = baseUrl ? `${baseUrl}${submitPath}` : submitPath;
          const headers = {
            'Content-Type': 'application/json',
          };
          const token = getAccessToken();
          if (token) {
            headers.Authorization = `Bearer ${token}`;
          }

          const response = await fetch(submitUrl, {
            method: 'POST',
            headers,
            body: JSON.stringify(payload)
          });
          if (response.ok) {
            const result = await response.json();
            console.log('✅ UI tool response submitted successfully:', result);
          } else {
            console.error('❌ Failed to submit UI tool response:', response.statusText);
          }
        } catch (e) {
          console.error('❌ Network error submitting UI tool response:', e);
        }
        
        return;
      }
      
      // Handle other agent action types
    // console.debug('Agent action handled through workflow system');
      // Other response types will come through WebSocket from backend
    } catch (error) {
      console.error('❌ Error handling agent action:', error);
    }
  };

  const handleAppClick = () => {
  // console.debug('Navigate to App');
  };

  const handleNotificationClick = () => {
  // console.debug('Show notifications');
  };

  const emitLocalArtifactEvent = useCallback((event) => {
    try {
      if (!event || !event.tool_name) {
        return;
      }
      dynamicUIHandler.notifyUIUpdate(event);
    } catch (err) {
      console.warn('Failed to emit local artifact event', err);
    }
  }, []);

  const resolveEmbeddedViewId = (value) => {
    if (!value) return null;
    if (value === '1' || value === 'true') return null;
    return String(value).trim() || null;
  };

  const openEmbeddedView = useCallback(async (source = 'header_action', viewId = null) => {
    try {
      const resolvedViewId = resolveEmbeddedViewId(viewId);
      if (!resolvedViewId) return;
      if (conversationMode === 'workflow') {
        viewArtifactSnapshotRef.current = {
          isOpen: isSidePanelOpen,
          layoutMode: layoutMode || 'split',
          messages: Array.isArray(currentArtifactMessages) ? [...currentArtifactMessages] : [],
        };
      } else {
        viewArtifactSnapshotRef.current = null;
      }
      if (conversationMode !== 'workflow') {
        await handleConversationModeChange('workflow');
      }

      const toolCallId = `embedded-view-${Date.now()}`;
      const payload = {
        embedded: true,
        presentation: 'artifact',
        page: resolvedViewId,
        source,
        workflow_name: 'core',
        component_type: resolvedViewId,
      };

      emitLocalArtifactEvent({
        type: 'tool_call',
        tool_name: resolvedViewId,
        tool_call_id: toolCallId,
        component_type: resolvedViewId,
        workflow_name: 'core',
        display: 'view',
        payload,
        agentName: 'System',
        agent_name: 'System',
      });
    } catch (err) {
      console.warn('Failed to open embedded view', err);
    }
  }, [conversationMode, emitLocalArtifactEvent, handleConversationModeChange, isSidePanelOpen, layoutMode, currentArtifactMessages]);

  const handleEmbeddedViewClick = async (viewOverride = null) => {
    try {
      if (isInWidgetMode) {
        setIsInWidgetMode(false);
      }
      const viewId = resolveEmbeddedViewId(viewOverride);
      await openEmbeddedView('header_action', viewId);
    } catch (err) {
      console.warn('Failed to open embedded view', err);
    }
  };

  useEffect(() => {
    if (!queryEmbeddedView) {
      embeddedViewHandledRef.current = false;
      return;
    }
    if (embeddedViewHandledRef.current) {
      return;
    }
    embeddedViewHandledRef.current = true;
    if (isInWidgetMode) {
      setIsInWidgetMode(false);
    }
    openEmbeddedView('query_param', resolveEmbeddedViewId(queryEmbeddedView));
    try {
      const params = new URLSearchParams(location.search || '');
      params.delete('view');
      const nextSearch = params.toString();
      navigate(
        { pathname: location.pathname, search: nextSearch ? `?${nextSearch}` : '' },
        { replace: true }
      );
    } catch (_) {
      /* ignore navigation cleanup errors */
    }
  }, [queryEmbeddedView, isInWidgetMode, location.pathname, location.search, navigate, openEmbeddedView, setIsInWidgetMode]);

  const resolveHeaderActionViewId = (action = null) => {
    if (!action || typeof action !== 'object') return null;
    return (
      action.view ||
      action.surface ||
      action.target ||
      action.component ||
      action.component_type ||
      action?.payload?.view ||
      action?.payload?.surface ||
      action?.payload?.component ||
      action?.payload?.component_type ||
      action?.payload?.page ||
      null
    );
  };

  const handleHeaderAction = (actionId, action = null) => {
    const explicitActionType = String(action?.action || action?.action_type || '').trim().toLowerCase();
    const viewId = resolveHeaderActionViewId(action);
    if (explicitActionType === 'open_view' || explicitActionType === 'open_surface' || viewId) {
      handleEmbeddedViewClick(viewId);
      return;
    }

    // Handle profile menu navigation
    if (actionId === 'navigate' || action?.action === 'navigate') {
      const href = action?.href || action?.path;
      if (href) {
        if (href.startsWith('/')) {
          navigate(href);
        } else {
          window.location.href = href;
        }
      }
      return;
    }

    // Handle signout
    if (actionId === 'signout' || action?.action === 'signout') {
      logout();
      return;
    }

    // Handle other navigation by id (profile-settings, preferences, etc.)
    if (action?.href) {
      if (action.href.startsWith('/')) {
        navigate(action.href);
      } else {
        window.location.href = action.href;
      }
    }
  };

  const handleReturnToChat = useCallback(() => {
    navigate('/chat');
  }, [navigate]);

  const toggleWidgetChatMinimized = useCallback(() => {
    setWidgetChatMinimized(prev => !prev);
  }, []);

  useEffect(() => {
    if (!isInWidgetMode && widgetChatMinimized) {
      setWidgetChatMinimized(false);
    }
  }, [isInWidgetMode, widgetChatMinimized]);

  const toggleSidePanel = () => {
    if (layoutMode === 'view') {
      exitViewMode();
      return;
    }
    setIsSidePanelOpen((open) => {
      const next = !open;
      
      // Update fluid layout state
      if (next) {
        // Opening artifact - switch to split view
        setLayoutMode('split');
      } else {
        // Closing artifact - back to full chat
        setLayoutMode('full');
      }

      if (isMobileView) {
        setMobileDrawerState(next ? 'expanded' : 'peek');
      }
      
      if (next && currentArtifactMessages.length === 0 && artifactCacheValidRef.current) {
        // Panel opening and no current artifact - try to restore from cache
        try {
          const artifactMsg = readStoredCurrentArtifact(currentChatId);
          if (artifactMsg) {
            if (artifactMsg.toolCall && !artifactMsg.toolCall.onResponse) {
              artifactMsg.toolCall.onResponse = (response) => {
                console.log('🔌 [UI] Cached artifact response (no longer functional):', response);
                console.warn('⚠️ This is a restored artifact - responses may not work until next interaction');
              };
            }

            console.log('🖼️ [UI] Restored artifact from cache on panel open');
            setCurrentArtifactMessages([artifactMsg]);
            lastArtifactEventRef.current = artifactMsg.toolCall?.tool_call_id || 'cached';
          } else {
            artifactCacheValidRef.current = false;
          }
        } catch (e) {
          artifactCacheValidRef.current = false;
          console.warn('Failed to restore artifact from cache', e);
        }
      } else if (next && currentArtifactMessages.length === 0) {
        artifactCacheValidRef.current = false;
      }
      
      console.log(`🖼️ [UI] Panel ${next ? 'opening' : 'closing'} - keeping artifact cached`);
      return next;
    });
  };

  // Simplified artifact restore effect: only restore when chatExists === true and connection is open
  // last_artifact semantics:
  //   - Cached locally on each artifact-mode tool_call
  //   - Server persists ONLY the most recent artifact (overwrite strategy)
  //   - On refresh / second user: websocket chat_meta may include last_artifact; if not, we fetch /api/chats/meta
  //   - We avoid speculative restores for brand new chats (chat_exists === false)
  //   - We skip restore entirely when in Ask mode (artifacts are workflow-only)
  useEffect(() => {
    if (connectionStatus !== 'connected') return;
    if (!currentChatId) return;
    if (!chatExists) return; // only restore for persisted chats
    if (artifactRestoredOnceRef.current) return;
    if (conversationMode === 'ask') return; // Don't restore artifacts in Ask mode

    try {
      const cached = readStoredLastArtifact(currentChatId);
      if (!cached || !cached.tool_name) return;

      console.log('[RESTORE] Restoring cached artifact for chat', currentChatId, cached.tool_name);
      restoreStoredArtifactForChat(currentChatId, currentWorkflowName);
    } catch (e) {
      console.warn('[RESTORE] Failed to restore artifact:', e);
    }
  }, [connectionStatus, currentChatId, chatExists, currentWorkflowName, conversationMode, restoreStoredArtifactForChat]);

  // Mobile detection and layout adaptation
  useEffect(() => {
    const compute = () => {
      try {
        const w = window.innerWidth;
        const h = window.innerHeight;
        const isMobile = w < 768; // md breakpoint
        const isShort = h < 500; // landscape phones/tablets
        
        console.log('📱 [MOBILE] Detection:', { width: w, height: h, isMobile, isShort });
        setIsMobileView(isMobile);
        setForceOverlay(isMobile || isShort);
        
        // On mobile, avoid split mode - use tabs instead
        if (isMobile && layoutMode === 'split') {
          setLayoutMode('full');
        }
      } catch {}
    };
    compute();
    window.addEventListener('resize', compute);
    window.addEventListener('orientationchange', compute);
    return () => {
      window.removeEventListener('resize', compute);
      window.removeEventListener('orientationchange', compute);
    };
  }, [layoutMode, setLayoutMode]);

  useEffect(() => {
    if (layoutMode !== 'view' && widgetOverlayOpen) {
      setWidgetOverlayOpen(false);
    }
  }, [layoutMode, widgetOverlayOpen, setWidgetOverlayOpen]);

  useEffect(() => {
    if (layoutMode !== 'view') {
      return;
    }
    if (!isSidePanelOpen) {
      setIsSidePanelOpen(true);
    }
    if (isMobileView) {
      setMobileDrawerState('expanded');
    }
  }, [layoutMode, isMobileView, isSidePanelOpen]);

  // Keep drawer state in sync as viewport or artifact availability changes
  useEffect(() => {
    if (!isMobileView) {
      if (mobileDrawerState !== 'peek') {
        setMobileDrawerState('peek');
      }
      return;
    }
  }, [isMobileView, mobileDrawerState]);

  useEffect(() => {
    if (!isSidePanelOpen) {
      setHasUnseenArtifact(false);
      return;
    }
    setHasUnseenArtifact(mobileDrawerState !== 'expanded');
  }, [mobileDrawerState, isSidePanelOpen]);

  useEffect(() => {
    if (mobileDrawerState !== 'expanded' && hasUnseenChat) {
      setHasUnseenChat(false);
    }
  }, [mobileDrawerState, hasUnseenChat]);

  // Lock body scroll when overlay is open
  useEffect(() => {
    if (isSidePanelOpen && forceOverlay) {
      const { overflow } = document.body.style;
      document.body.style.overflow = 'hidden';
      return () => { document.body.style.overflow = overflow; };
    }
  }, [isSidePanelOpen, forceOverlay]);

  // Only show artifact toggle in workflow mode (Ask mode has no artifacts)
  const artifactToggleHandler = conversationMode === 'ask'
    ? null
    : isInWidgetMode
      ? handleReturnToChat
      : (isMobileView
          ? () => {
              if (layoutMode === 'view') {
                exitViewMode();
                return;
              }
              setIsSidePanelOpen(true);
              setMobileDrawerState((prev) => (prev === 'expanded' ? 'peek' : 'expanded'));
            }
          : toggleSidePanel);

  const artifactToggleLabel = conversationMode === 'ask'
    ? undefined
    : isInWidgetMode
      ? 'Return to chat'
      : (isMobileView ? 'Artifact drawer' : undefined);

  const handleViewWidgetAsk = useCallback(() => {
    setWidgetOverlayOpen(false);
    handleConversationModeChange('ask');
  }, [handleConversationModeChange, setWidgetOverlayOpen]);

  const handleViewWidgetWorkflow = useCallback(() => {
    setWidgetOverlayOpen(false);
    handleConversationModeChange('workflow');
  }, [handleConversationModeChange, setWidgetOverlayOpen]);

  const viewWidget = isViewMode ? (
    <div className={`flex flex-col-reverse items-end gap-2 ${widgetOverlayOpen ? 'mr-[20px] mb-[40px]' : 'mr-3 mb-3'}`}>
      {!widgetOverlayOpen && (
        <button
          type="button"
          onClick={() => setWidgetOverlayOpen(true)}
          className="pointer-events-auto group relative w-20 h-20 rounded-2xl bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-secondary)] shadow-[0_8px_32px_rgba(15,23,42,0.6)] border-2 border-[rgba(var(--color-primary-light-rgb),0.5)] hover:shadow-[0_16px_48px_rgba(51,240,250,0.4)] hover:scale-105 transition-all duration-300 flex items-center justify-center"
          title="Open chat"
          aria-label="Open chat"
        >
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[rgba(var(--color-primary-light-rgb),0.2)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <img
            src={brandLogoSrc}
            alt="Mozaiks"
            className="w-11 h-11 relative z-10 group-hover:scale-110 transition-transform"
            onError={applyBrandImageFallback}
          />
        </button>
      )}

      <div
        className="w-[26rem] max-w-[calc(100vw-2.5rem)] h-[50vh] md:h-[70vh] min-h-[360px] transition-all duration-300"
        style={{
          opacity: widgetOverlayOpen ? 1 : 0,
          transform: widgetOverlayOpen ? 'translateY(0)' : 'translateY(1.5rem)',
          pointerEvents: widgetOverlayOpen ? 'auto' : 'none',
        }}
      >
        <button
          type="button"
          onClick={() => setWidgetOverlayOpen(false)}
          className="pointer-events-auto relative group mt-[-1px] z-20"
          title="Minimize chat"
        >
          <div className="w-32 h-8 rounded-t-2xl bg-gradient-to-r from-[rgba(var(--color-primary-rgb),0.4)] to-[rgba(var(--color-secondary-rgb),0.4)] border-t border-l border-r border-[rgba(var(--color-primary-light-rgb),0.4)] backdrop-blur-sm flex items-center justify-center group-hover:bg-gradient-to-r group-hover:from-[rgba(var(--color-primary-rgb),0.6)] group-hover:to-[rgba(var(--color-secondary-rgb),0.6)] transition-all">
            <svg className="w-5 h-5 text-[var(--color-primary-light)] group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </button>

        <div className="h-full bg-gradient-to-br from-gray-900/95 via-slate-900/95 to-black/95 backdrop-blur-xl border border-[rgba(var(--color-primary-light-rgb),0.3)] rounded-2xl rounded-tr-none shadow-2xl overflow-hidden flex flex-col">
          <div className="flex-shrink-0 bg-[rgba(0,0,0,0.6)] border-b border-[rgba(var(--color-primary-light-rgb),0.2)] backdrop-blur-xl">
            <div className="flex flex-row items-center justify-between px-3 py-2.5 sm:px-4 sm:py-3">
              <button
                type="button"
                onClick={handleViewWidgetAsk}
                className="flex items-center gap-2 sm:gap-3 focus:outline-none focus:ring-2 focus:ring-[var(--color-primary-light)]/60 rounded-xl min-w-0 flex-1"
                title="Open Chat Station"
              >
                <span className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl flex items-center justify-center shadow-lg flex-shrink-0 bg-gradient-to-br from-[var(--color-secondary)] to-[var(--color-primary)]">
                  <span className="text-xl sm:text-2xl" role="img" aria-hidden="true">🧠</span>
                </span>
                <span className="text-left min-w-0 flex-1">
                  <span className="block text-sm sm:text-lg font-bold text-white tracking-tight truncate">{`Ask ${resolvedAppDisplayName}`}</span>
                  <span className="block text-[10px] sm:text-xs text-gray-400 truncate">Chat Station</span>
                </span>
              </button>

              <button
                onClick={handleViewWidgetWorkflow}
                className="group relative p-2 rounded-lg bg-gradient-to-r from-[rgba(var(--color-primary-rgb),0.1)] to-[rgba(var(--color-secondary-rgb),0.1)] border border-[rgba(var(--color-primary-light-rgb),0.3)] hover:border-[rgba(var(--color-primary-light-rgb),0.6)] transition-all duration-300 backdrop-blur-sm flex-shrink-0"
                title="Resume Workflow"
              >
                <img
                  src={brandLogoSrc}
                  className="w-8 h-8 opacity-70 group-hover:opacity-100 transition-all duration-300 group-hover:scale-105"
                  alt="Workflow"
                  onError={applyBrandImageFallback}
                />
                <div className="absolute inset-0 bg-[rgba(var(--color-primary-light-rgb),0.1)] rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10"></div>
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-hidden">
            <ChatInterface
              messages={messages}
              onSendMessage={sendMessage}
              loading={loading}
              onAgentAction={handleAgentAction}
              connectionStatus={connectionStatus}
              transportType={transportType}
              workflowName={currentWorkflowName}
              structuredOutputs={getWorkflow(currentWorkflowName)?.structuredOutputs || {}}
              startupMode={workflowConfig?.getWorkflowConfig(currentWorkflowName)?.startup_mode}
              initialMessageToUser={
                workflowConfig?.getWorkflowConfig(currentWorkflowName)?.startup_mode === 'UserDriven'
                  ? null
                  : workflowConfig?.getWorkflowConfig(currentWorkflowName)?.initial_message_to_user
              }
              onRetry={retryConnection}
              conversationMode={conversationMode}
              onConversationModeChange={handleConversationModeChange}
              onStartGeneralChat={handleStartGeneralChat}
              generalChatSummary={generalChatSummary}
              isOnChatPage={false}
              generalSessionsLoading={generalSessionsLoading}
              showAskHistoryMenu={false}
              showHistoryMenu={false}
              hideHeader={true}
              disableMobileShellChrome={true}
              plainContainer={true}
              chatTheme={chatTheme}
              appDisplayName={resolvedAppDisplayName}
              artifactContext={currentArtifactContext}
              onArtifactAction={sendArtifactAction}
              actionStatusMap={actionStatusMap}
              pendingComposerInputToolCall={pendingComposerInputToolCall}
              pendingComposerReply={pendingWorkflowReply}
              onPendingComposerInputSkip={handlePendingComposerInputSkip}
              pendingHarnessDecision={pendingHarnessDecision}
              pendingHarnessDecisionBusy={pendingHarnessDecisionBusy}
              pendingHarnessDecisionError={pendingHarnessDecisionError}
              onPendingHarnessDecisionAction={handlePendingHarnessDecisionAction}
            />
          </div>
        </div>
      </div>
    </div>
  ) : null;

  const mobileChatPaddingBottomClass = 'pb-[calc(env(safe-area-inset-bottom,0px)+0.5rem)]';
  const mobileChatTopMarginClass = 'mt-0';

  const isChatPageSurface = isPrimaryChatRoute && !isInWidgetMode && !isViewMode;
  const showAskHistorySidebar = isChatPageSurface && !isMobileView && conversationMode === 'ask';
  const showWorkflowHistorySidebar = false;
  const showMobileAskHistoryMenu = isChatPageSurface && isMobileView && conversationMode === 'ask';
  const showMobileWorkflowHistoryMenu = false;
  const showMobileHistoryMenu = showMobileAskHistoryMenu || showMobileWorkflowHistoryMenu;
  const mobileHistoryLabel = conversationMode === 'workflow' ? 'Workflows' : 'Chats';

  useEffect(() => {
    if (!showMobileHistoryMenu && isAskHistoryDrawerOpen) {
      setIsAskHistoryDrawerOpen(false);
    }
  }, [showMobileHistoryMenu, isAskHistoryDrawerOpen]);

  useEffect(() => {
    if (!isAskHistoryDrawerOpen) {
      return undefined;
    }
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previous;
    };
  }, [isAskHistoryDrawerOpen]);

  const currentWorkflowConfig = workflowConfig?.getWorkflowConfig(currentWorkflowName) || {};
  const uiStartupMode = currentWorkflowConfig?.startup_mode;
  const headerInitialMessageToUser =
    uiStartupMode === 'UserDriven'
      ? null
      : currentWorkflowConfig?.initial_message_to_user;
  const pendingComposerInputToolCall = findPendingComposerInputRequestToolCall(messages);

  const handlePendingTransitionNavigate = useCallback(
    async (option_id = null, contextVariables = {}) => {
      if (!pendingTransitionId) return;
      const mergedContext = {
        ...(pendingTransitionContext || {}),
        ...(contextVariables || {}),
      };
      const resolvedAppId = (
        appId ||
        user?.app_id ||
        config?.chat?.defaultAppId ||
        config?.appId ||
        config?.app_id ||
        'default'
      );
      const resolvedUserId = user?.id || user?.user_id || user?.email || null;

      try {
        const res = await fetch('/api/transitions/resolve', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            transition_id: pendingTransitionId,
            option_id,
            context_variables: mergedContext,
            app_id: resolvedAppId,
            user_id: resolvedUserId,
          }),
        });

        if (!res.ok) {
          const err = await res.json().catch(() => ({ detail: res.statusText }));
          throw new Error(err.detail || 'Failed to resolve transition');
        }

        const data = await res.json();
        if (data.resolution_type === 'transition' && data.transition?.id) {
          setPendingTransitionContext(data.context_variables ?? mergedContext);
          setPendingTransitionId(data.transition.id);
          return;
        }

        if (data.resolution_type === 'workflow' && data.chat_id && data.workflow_id) {
          setPendingTransitionId(null);
          setPendingTransitionContext({});
          setCurrentChatId(data.chat_id);
          setActiveChatId(data.chat_id);
          setCurrentWorkflowName(data.workflow_id);
          setActiveWorkflowName(data.workflow_id);
          setConversationMode('workflow');
          navigate(
            `/chat?workflow=${encodeURIComponent(data.workflow_id)}&chat_id=${encodeURIComponent(data.chat_id)}`
          );
          return;
        }

        throw new Error('Transition resolution returned an unsupported response');
      } catch (err) {
        console.error('[ChatPage] transition resolution failed:', err);
      }
    },
    [
      appId,
      config,
      navigate,
      pendingTransitionContext,
      pendingTransitionId,
      setActiveChatId,
      setActiveWorkflowName,
      setConversationMode,
      user,
    ]
  );

  const chatInterface = (
    <ErrorBoundary fallback={<ChatInterfaceErrorFallback onRetry={() => window.location.reload()} />}>
      <ChatInterface
        messages={messages}
        onSendMessage={sendMessage}
        loading={loading}
        onAgentAction={handleAgentAction}
        onArtifactToggle={artifactToggleHandler}
        artifactToggleLabel={artifactToggleLabel}
        connectionStatus={connectionStatus}
        transportType={transportType}
        workflowName={currentWorkflowName}
        structuredOutputs={getWorkflow(currentWorkflowName)?.structuredOutputs || {}}
        startupMode={uiStartupMode}
        initialMessageToUser={headerInitialMessageToUser}
        onRetry={retryConnection}
        onBrandClick={undefined}
        conversationMode={conversationMode}
        onConversationModeChange={handleConversationModeChange}
        modeTogglePending={modeChangePending}
        onStartGeneralChat={handleStartGeneralChat}
        generalChatSummary={generalChatSummary}
        isOnChatPage={isChatPageSurface}
        generalSessionsLoading={generalSessionsLoading}
        showAskHistoryMenu={showMobileAskHistoryMenu}
        onAskHistoryToggle={() => setIsAskHistoryDrawerOpen((prev) => !prev)}
        showHistoryMenu={showMobileHistoryMenu}
        onHistoryToggle={() => setIsAskHistoryDrawerOpen((prev) => !prev)}
        historyMenuLabel={mobileHistoryLabel}
              chatTheme={chatTheme}
              appDisplayName={resolvedAppDisplayName}
              artifactContext={currentArtifactContext}
              onArtifactAction={sendArtifactAction}
        actionStatusMap={actionStatusMap}
        pendingComposerInputToolCall={pendingComposerInputToolCall}
        pendingComposerReply={pendingWorkflowReply}
        onPendingComposerInputSkip={handlePendingComposerInputSkip}
        pendingHarnessDecision={pendingHarnessDecision}
        pendingHarnessDecisionBusy={pendingHarnessDecisionBusy}
        pendingHarnessDecisionError={pendingHarnessDecisionError}
        onPendingHarnessDecisionAction={handlePendingHarnessDecisionAction}
        hasUnseenArtifact={hasUnseenArtifact}
      />
    </ErrorBoundary>
  );

  console.log('📱 [RENDER] ChatPage render:', { isInWidgetMode, isMobileView, workflowCompleted, mobileDrawerState });

  // Widget mode has its own UI (persistent widget on non-ChatPage routes), so render that
  if (isInWidgetMode) {
    if (widgetChatMinimized) {
      return (
        <div className="fixed right-4 bottom-4 z-50 widget-safe-bottom">
          <button
            type="button"
            onClick={toggleWidgetChatMinimized}
            className="group relative w-20 h-20 rounded-2xl bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-secondary)] shadow-[0_8px_32px_rgba(15,23,42,0.6)] border-2 border-[rgba(var(--color-primary-light-rgb),0.5)] hover:shadow-[0_16px_48px_rgba(51,240,250,0.4)] hover:scale-105 transition-all duration-300 flex items-center justify-center"
            title="Expand chat"
          >
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[rgba(var(--color-primary-light-rgb),0.2)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <img 
              src={brandLogoSrc} 
              alt="mozaiksai" 
              className="w-11 h-11 relative z-10 group-hover:scale-110 transition-transform"
              onError={applyBrandImageFallback}
            />
          </button>
        </div>
      );
    }

    return (
      <div className="fixed right-4 bottom-4 z-50 flex flex-col items-end gap-0 pointer-events-none widget-safe-bottom">
        <button
          type="button"
          onClick={toggleWidgetChatMinimized}
          className="pointer-events-auto relative group mb-[-1px] z-20"
          title="Minimize chat"
        >
          <div className="w-32 h-8 rounded-t-2xl bg-gradient-to-r from-[rgba(var(--color-primary-rgb),0.4)] to-[rgba(var(--color-secondary-rgb),0.4)] border-t border-l border-r border-[rgba(var(--color-primary-light-rgb),0.4)] backdrop-blur-sm flex items-center justify-center group-hover:bg-gradient-to-r group-hover:from-[rgba(var(--color-primary-rgb),0.6)] group-hover:to-[rgba(var(--color-secondary-rgb),0.6)] transition-all">
            <svg className="w-5 h-5 text-[var(--color-primary-light)] group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </button>
        <div className="pointer-events-auto w-[26rem] max-w-[calc(100vw-2.5rem)] h-[50vh] md:h-[70vh] min-h-[360px]">
          <div className="h-full">
            {chatInterface}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="relative flex flex-col h-screen min-h-screen overflow-hidden"
      style={chatPageShellStyle}
    >
      {showInitSpinner && (
        // Make the overlay visually blocking but non-interactive so background UI can still receive events
        <div className="fixed inset-0 flex items-center justify-center bg-black/20 backdrop-blur-sm z-50 pointer-events-none">
          <div className="pointer-events-auto">
            <LoadingSpinner />
          </div>
        </div>
      )}
      {pendingTransitionId && (
        <TransitionScreen
          transitionId={pendingTransitionId}
          onNavigate={handlePendingTransitionNavigate}
        />
      )}
      <img
        src={chatBackgroundSrc}
        alt=""
        className="z-[-10] fixed sm:-w-auto w-full h-full top-0 object-cover"
      />
      <Header 
        user={user}
        chatTheme={chatTheme}
        themeLoading={themeLoading}
        onNotificationClick={handleNotificationClick}
        onAction={handleHeaderAction}
      />
      
      {/* Main content area that fills remaining screen height - no scrolling */}
      <div
        className={`flex-1 flex flex-col min-h-0 overflow-hidden ${mainPaddingClass}`}
        style={mainContentStyle}
      >{/* Padding for header */}
        {workflowCompleted ? (
          /* Workflow Completion Screen */
          <div className="flex-1 flex items-center justify-center px-4">
            <WorkflowCompletion
              workflowName={currentWorkflowName}
              completionMessage={`Your ${currentWorkflowName} workflow has completed successfully!`}
              summary={{
                duration: completionData?.duration,
                tokensUsed: completionData?.tokensUsed,
              }}
              onContinue={() => {
                console.log('🎉 [COMPLETION] User continuing to Mozaiks');
                // Optional: Send analytics event here
              }}
            />
          </div>
        ) : isMobileView ? (
          <div className="relative flex-1 flex flex-col">
            <div className={`flex-1 flex flex-col transition-[padding-bottom] duration-300 ${mobileChatTopMarginClass} ${mobileChatPaddingBottomClass}`}>
              {chatInterface}
            </div>

            {isSidePanelOpen && mobileDrawerState === 'expanded' && conversationMode === 'workflow' && (
              <button
                type="button"
                aria-label="Collapse artifact workspace"
                className="absolute inset-x-0 top-0 z-30 h-16 bg-gradient-to-b from-black/40 to-transparent"
                onClick={() => setMobileDrawerState('peek')}
              ></button>
            )}

            {/* Only show mobile artifact drawer in workflow mode (Ask mode has no artifacts) */}
            {conversationMode === 'workflow' && (
              <MobileArtifactDrawer
                state={mobileDrawerState}
                onStateChange={setMobileDrawerState}
                onClose={() => {
                  setMobileDrawerState('peek');
                  setIsSidePanelOpen(false);
                }}
                viewMode={isViewMode}
                chatTheme={chatTheme}
                onExitView={exitViewMode}
                artifactContent={
                  <ErrorBoundary fallback={<ArtifactErrorFallback onRetry={() => setMobileDrawerState('peek')} />}>
                    <ArtifactPanel
                      onClose={() => {
                        setMobileDrawerState('peek');
                        setIsSidePanelOpen(false);
                      }}
                      isMobile
                      isEmbedded
                      viewMode={isViewMode}
                      onExitView={exitViewMode}
                      messages={currentArtifactMessages}
                      chatId={currentChatId}
                      workflowName={currentWorkflowName}
                      chatTheme={chatTheme}
                      onArtifactAction={sendArtifactAction}
                      actionStatusMap={actionStatusMap}
                      floatingWidget={viewWidget}
                    />
                  </ErrorBoundary>
                }
                hasUnseenChat={hasUnseenChat}
                hasUnseenArtifact={hasUnseenArtifact}
              />
            )}

            {showMobileHistoryMenu && (
              <MobileAskHistoryDrawer
                mode={conversationMode}
                open={isAskHistoryDrawerOpen}
                sessions={conversationMode === 'workflow' ? workflowSessions : generalChatSessions}
                activeChatId={conversationMode === 'workflow' ? (activeChatId || currentChatId) : activeGeneralChatId}
                loading={conversationMode === 'workflow' ? workflowSessionsLoading : generalSessionsLoading}
                onSelectChat={handleSelectGeneralChat}
                onSelectWorkflow={handleSelectWorkflowSession}
                onStartNewChat={handleStartGeneralChat}
                onStartEntryWorkflow={() => handleConversationModeChange('workflow')}
                onRefresh={conversationMode === 'workflow' ? handleRefreshWorkflowSessions : handleRefreshGeneralSessions}
                onClear={conversationMode === 'workflow' ? handleClearWorkflowSessions : handleClearGeneralSessions}
                onClose={() => setIsAskHistoryDrawerOpen(false)}
              />
            )}
          </div>
        ) : (
          <div className="flex flex-1 min-h-0 gap-4 px-3 md:px-6 pt-5 pb-4 items-stretch">
            {showAskHistorySidebar && (
              <AskHistorySidebar
                sessions={generalChatSessions}
                activeChatId={activeGeneralChatId}
                loading={generalSessionsLoading}
                onSelectChat={handleSelectGeneralChat}
                onStartNewChat={handleStartGeneralChat}
                onRefresh={handleRefreshGeneralSessions}
                onClear={handleClearGeneralSessions}
              />
            )}
            <div className="flex-1 min-h-0 -my-2 h-[calc(100%+1rem)]">
              <FluidChatLayout
                layoutMode={effectiveLayoutMode}
                onLayoutChange={setLayoutMode}
                isArtifactAvailable={true}
                hasActiveChat={!!currentChatId}
                onToggleArtifact={() => {
                  if (layoutMode === 'full') {
                    setLayoutMode('split');
                    setIsSidePanelOpen(true);
                  } else {
                    setLayoutMode('full');
                    setIsSidePanelOpen(false);
                  }
                }}
                onToggleChat={() => {
                  if (layoutMode === 'minimized') {
                    setLayoutMode('split');
                  }
                }}
                chatContent={chatInterface}
                artifactContent={
                  <ErrorBoundary fallback={<ArtifactErrorFallback onRetry={() => setLayoutMode('full')} />}>
                    <ArtifactPanel
                      onClose={toggleSidePanel}
                      viewMode={isViewMode}
                      onExitView={exitViewMode}
                      messages={currentArtifactMessages}
                      chatId={currentChatId}
                      workflowName={currentWorkflowName}
                      chatTheme={chatTheme}
                      onArtifactAction={sendArtifactAction}
                      actionStatusMap={actionStatusMap}
                      floatingWidget={viewWidget}
                    />
                  </ErrorBoundary>
                }
              />
            </div>
          </div>
        )}
      </div>
      {!isMobileView && <Footer />}

    </div>
  );
};

export default ChatPage;
