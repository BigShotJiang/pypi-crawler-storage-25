#!/usr/bin/env python3
"""
Build experiment tables from prediction_scores: Accuracy, Macro F1, EER, EER CI
per (training_data, frontend, backend, seed, eval_set). Saves one CSV/TSV per
(training_data, frontend) for Excel.

Path structure:
  prediction_scores/<training_data>/<model_run>/<model_run>_<eval_suffix>/results/predictions/*.txt
  e.g. ASV19/DeepFense_ASV19_EAT_AASIST_NoAug_Seed2/DeepFense_ASV19_EAT_AASIST_NoAug_Seed2_itw_eval/...
"""
from __future__ import annotations

import csv
import re
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

# Self-contained EER and EER CI (only numpy) to avoid deepfense env
def _compute_det_curve(labels, scores, bonafide_label=1):
    """DET curve: (frr, far, thresholds). scores: higher = more bonafide."""
    labels = np.asarray(labels).astype(int)
    scores = np.asarray(scores).astype(float)
    spoof_label = 1 - bonafide_label
    target_scores = scores[labels == bonafide_label]
    nontarget_scores = scores[labels == spoof_label]
    if target_scores.size == 0 or nontarget_scores.size == 0:
        return np.array([0.0]), np.array([1.0]), np.array([0.0])
    n_scores = target_scores.size + nontarget_scores.size
    all_scores = np.concatenate((target_scores, nontarget_scores))
    all_labels = np.concatenate((np.ones(target_scores.size), np.zeros(nontarget_scores.size)))
    indices = np.argsort(all_scores, kind="mergesort")
    sorted_labels = all_labels[indices]
    tar_trial_sums = np.cumsum(sorted_labels)
    nontarget_trial_sums = nontarget_scores.size - (np.arange(1, n_scores + 1) - tar_trial_sums)
    frr = np.concatenate(([0.0], tar_trial_sums / target_scores.size))
    far = np.concatenate(([1.0], nontarget_trial_sums / nontarget_scores.size))
    thresholds = np.concatenate(([all_scores[indices[0]] - 1e-6], all_scores[indices]))
    return frr, far, thresholds


def _evaluate_with_conf_int(scores_1d, metric, labels, num_bootstraps=1000, alpha=5):
    """Bootstrap CI for a metric(labels, scores). Returns (center, (ci_low, ci_high))."""
    rng = np.random.default_rng(42)
    n = len(scores_1d)
    center = metric(labels, scores_1d)
    vals = np.zeros(num_bootstraps)
    for i in range(num_bootstraps):
        idx = rng.choice(n, size=n, replace=True)
        vals[i] = metric(labels[idx], scores_1d[idx])
    ci_low = np.percentile(vals, alpha / 2)
    ci_high = np.percentile(vals, 100 - alpha / 2)
    return center, (ci_low, ci_high)

PREDICTION_SCORES_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = PREDICTION_SCORES_DIR / "experiment_tables"
BONAFIDE_LABEL = 1
EER_CI_BOOTSTRAPS = 200  # increase to 1000 for final tables
EER_CI_ALPHA = 5
COMPUTE_EER_CI = True  # set False for fast run (Acc, F1, EER only)

# Eval suffix (folder name part after model_run) -> short name for table
EVAL_DISPLAY = {
    "asvspoof2019_la_eval": "ASV19",
    "asvspoof21_la_eval": "LA21",
    "asvspoof21_df_eval": "DF21",
    "itw_eval": "ITW",
    "add22_test_track1": "add22_track1",
    "add22_test_track3": "add22_track3",
    "add23_test_R1": "add23_R1",
    "add23_test_R2": "add23_R2",
    "asvspoof5_test": "ASV5",
    "codecfake_eval": "CodecFake",
    "habla_test": "HABLA",
    "odss_test": "ODSS",
    "replaydf_all_eval": "ReplayDF",
    "spoofceleb_eval": "SpoofCeleb",
    "MLAAD_final": "MLAAD_final",
}

# Order of eval sets for columns
EVAL_ORDER = [
    "ASV19", "LA21", "DF21", "ITW",
    "add22_track1", "add22_track3", "add23_R1", "add23_R2",
    "ASV5", "CodecFake", "HABLA", "ODSS", "ReplayDF", "SpoofCeleb", "MLAAD_final",
]

# Model run pattern: DeepFense_<DATA>_<Frontend>_<Backend>_NoAug_Seed<N>
MODEL_RUN_RE = re.compile(r"^DeepFense_[A-Za-z0-9]+_([A-Za-z0-9]+)_([A-Za-z0-9]+)_NoAug_Seed(\d+)$")


def parse_model_run(model_run_name: str) -> tuple[str | None, str | None, int | None]:
    """Return (frontend, backend, seed) or (None, None, None)."""
    m = MODEL_RUN_RE.match(model_run_name)
    if not m:
        return None, None, None
    return m.group(1), m.group(2), int(m.group(3))


def get_eval_suffix(inner_dir_name: str, model_run_name: str) -> str | None:
    """e.g. DeepFense_ASV19_EAT_AASIST_NoAug_Seed2_itw_eval -> itw_eval."""
    if not inner_dir_name.startswith(model_run_name + "_"):
        return None
    return inner_dir_name[len(model_run_name) + 1:]


def load_predictions(txt_path: Path) -> tuple[np.ndarray, np.ndarray]:
    """Load CSV with ID_audio,label,score_class0,score_class1. Return (labels, scores_2d)."""
    labels_list = []
    scores_list = []
    with open(txt_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, skipinitialspace=True)
        for row in reader:
            # Normalize keys (strip BOM/spaces) for lookup
            row_norm = {k.strip().lstrip("\ufeff"): v for k, v in row.items()}
            lab_val = row_norm.get("label")
            s0_val = row_norm.get("score_class0")
            s1_val = row_norm.get("score_class1")
            if lab_val in (None, "") or s0_val in (None, "") or s1_val in (None, ""):
                continue
            try:
                lab = int(float(lab_val))
                s0 = float(s0_val)
                s1 = float(s1_val)
            except (ValueError, TypeError):
                continue
            labels_list.append(lab)
            scores_list.append([s0, s1])
    labels = np.array(labels_list, dtype=np.int64)
    scores = np.array(scores_list, dtype=np.float64)
    return labels, scores


def scores_to_1d(scores_2d: np.ndarray, bonafide_label: int = 1) -> np.ndarray:
    """Convert [N,2] to 1D: higher = more bonafide. Uses bonafide - spoof."""
    spoof_label = 1 - bonafide_label
    return scores_2d[:, bonafide_label] - scores_2d[:, spoof_label]


def compute_eer_from_curve(labels: np.ndarray, scores_1d: np.ndarray, bonafide_label: int = 1) -> float:
    frr, far, _ = _compute_det_curve(labels, scores_1d, bonafide_label)
    abs_diffs = np.abs(frr - far)
    min_index = np.argmin(abs_diffs)
    return float(np.mean((frr[min_index], far[min_index])))


def compute_eer_ci(labels: np.ndarray, scores_1d: np.ndarray, bonafide_label: int = 1):
    def _metric(lbl, sc):
        return compute_eer_from_curve(lbl, sc, bonafide_label)
    center, (ci_low, ci_high) = _evaluate_with_conf_int(
        scores_1d, _metric, labels,
        num_bootstraps=EER_CI_BOOTSTRAPS, alpha=EER_CI_ALPHA,
    )
    return center, ci_low, ci_high


def _accuracy(labels: np.ndarray, preds: np.ndarray) -> float:
    return float(np.mean(labels == preds))


def _macro_f1(labels: np.ndarray, preds: np.ndarray) -> float:
    """Macro F1: average of F1 for class 0 and class 1."""
    out = 0.0
    for c in (0, 1):
        tp = np.sum((labels == c) & (preds == c))
        fp = np.sum((labels != c) & (preds == c))
        fn = np.sum((labels == c) & (preds != c))
        if 2 * tp + fp + fn == 0:
            out += 1.0
        else:
            out += (2.0 * tp) / (2 * tp + fp + fn)
    return out / 2.0


def compute_metrics(labels: np.ndarray, scores_2d: np.ndarray) -> dict:
    """Return dict with Accuracy, MacroF1, EER, EER_CI_low, EER_CI_high."""
    if len(labels) == 0:
        return {"Accuracy": np.nan, "MacroF1": np.nan, "EER": np.nan, "EER_CI_low": np.nan, "EER_CI_high": np.nan}
    scores_1d = scores_to_1d(scores_2d, BONAFIDE_LABEL)
    preds = (scores_1d >= 0).astype(np.int64)  # bonafide if score >= 0
    if BONAFIDE_LABEL == 0:
        preds = 1 - preds
    acc = _accuracy(labels, preds)
    f1 = _macro_f1(labels, preds)
    eer = compute_eer_from_curve(labels, scores_1d, BONAFIDE_LABEL)
    if COMPUTE_EER_CI:
        try:
            _, ci_low, ci_high = compute_eer_ci(labels, scores_1d, BONAFIDE_LABEL)
        except Exception:
            ci_low, ci_high = np.nan, np.nan
    else:
        ci_low, ci_high = np.nan, np.nan
    return {
        "Accuracy": round(acc, 4),
        "MacroF1": round(f1, 4),
        "EER": round(eer, 4),
        "EER_CI_low": round(ci_low, 4) if not np.isnan(ci_low) else "",
        "EER_CI_high": round(ci_high, 4) if not np.isnan(ci_high) else "",
    }


def discover_predictions(datasets: list[str] | None = None) -> list[tuple[str, str, str, int, str, Path]]:
    """Yield (training_data, frontend, backend, seed, eval_display, txt_path)."""
    results = []
    for root in PREDICTION_SCORES_DIR.iterdir():
        if not root.is_dir() or root.name.startswith("."):
            continue
        training_data = root.name
        if datasets is not None and training_data not in datasets:
            continue
        for model_run_dir in root.iterdir():
            if not model_run_dir.is_dir() or not model_run_dir.name.startswith("DeepFense_"):
                continue
            model_run_name = model_run_dir.name
            frontend, backend, seed = parse_model_run(model_run_name)
            if frontend is None:
                continue
            for inner in model_run_dir.iterdir():
                if not inner.is_dir():
                    continue
                suffix = get_eval_suffix(inner.name, model_run_name)
                if suffix is None:
                    continue
                eval_display = EVAL_DISPLAY.get(suffix, suffix)
                pred_dir = inner / "results" / "predictions"
                if not pred_dir.is_dir():
                    continue
                for txt in pred_dir.glob("*.txt"):
                    results.append((training_data, frontend, backend, seed, eval_display, txt))
    return results


def main():
    global COMPUTE_EER_CI, EER_CI_BOOTSTRAPS
    import argparse
    p = argparse.ArgumentParser(description="Build experiment tables (Acc, F1, EER, EER CI)")
    p.add_argument("--no-ci", action="store_true", help="Skip EER confidence interval (faster)")
    p.add_argument("--bootstraps", type=int, default=200, help="Bootstrap count for EER CI")
    p.add_argument("--datasets", nargs="+", default=None, help="Only these training datasets (e.g. ASV19 HABLA)")
    args = p.parse_args()
    if args.no_ci:
        COMPUTE_EER_CI = False
        print("EER CI disabled (--no-ci)")
    else:
        EER_CI_BOOTSTRAPS = args.bootstraps
        print(f"EER CI: {EER_CI_BOOTSTRAPS} bootstraps")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    all_rows = discover_predictions(datasets=args.datasets)
    print(f"Found {len(all_rows)} prediction files")

    # Group by (training_data, frontend) so we can write each CSV as we finish that group
    by_tf = defaultdict(list)
    for t in all_rows:
        by_tf[(t[0], t[1])].append(t)

    key_cols = ["Backend", "Seed", "EvalSet", "Accuracy", "MacroF1", "EER", "EER_CI_low", "EER_CI_high"]
    all_cols = ["TrainingData", "Frontend"] + key_cols
    rows_for_tsv = []

    for (training_data, frontend), file_list in sorted(by_tf.items()):
        group = []
        for (_, _, backend, seed, eval_display, txt_path) in file_list:
            try:
                labels, scores_2d = load_predictions(txt_path)
            except Exception as e:
                print(f"  Skip {txt_path}: {e}")
                continue
            metrics = compute_metrics(labels, scores_2d)
            r = {
                "TrainingData": training_data,
                "Frontend": frontend,
                "Backend": backend,
                "Seed": seed,
                "EvalSet": eval_display,
                **metrics,
            }
            group.append(r)
            rows_for_tsv.append(r)
        if not group:
            continue
        out_name = f"{training_data}_{frontend}.csv"
        out_path = OUTPUT_DIR / out_name
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=key_cols, extrasaction="ignore")
            writer.writeheader()

            def _sort_key(x):
                ei = EVAL_ORDER.index(x["EvalSet"]) if x["EvalSet"] in EVAL_ORDER else 999
                return (x["Backend"], x["Seed"], ei, x["EvalSet"])

            for r in sorted(group, key=_sort_key):
                writer.writerow(r)
        print(f"Wrote {out_path} ({len(group)} rows)")

    # Combined TSV for all experiments
    combined_path = OUTPUT_DIR / "all_experiments.tsv"
    with open(combined_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=all_cols, extrasaction="ignore", delimiter="\t")
        writer.writeheader()
        for r in rows_for_tsv:
            writer.writerow(r)
    print(f"Wrote {combined_path} ({len(rows_for_tsv)} rows)")
    print("Done.")


if __name__ == "__main__":
    main()
