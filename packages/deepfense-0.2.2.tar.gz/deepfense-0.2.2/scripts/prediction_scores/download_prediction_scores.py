#!/usr/bin/env python3
"""
Download DeepFense/prediction_scores (Hugging Face dataset) into this directory.
Uses HF_TOKEN or HUGGING_FACE_HUB_TOKEN from the environment.
"""
import os
from pathlib import Path
from huggingface_hub import snapshot_download

REPO_ID = "DeepFense/prediction_scores"
REPO_TYPE = "dataset"
LOCAL_DIR = Path(__file__).resolve().parent


def main():
    token = "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"
    if not token:
        print("Set HF_TOKEN or HUGGING_FACE_HUB_TOKEN to download (private dataset).")
        return
    path = snapshot_download(
        repo_id=REPO_ID,
        repo_type=REPO_TYPE,
        local_dir=str(LOCAL_DIR),
        token=token,
    )
    print(f"Downloaded to: {path}")


if __name__ == "__main__":
    main()
