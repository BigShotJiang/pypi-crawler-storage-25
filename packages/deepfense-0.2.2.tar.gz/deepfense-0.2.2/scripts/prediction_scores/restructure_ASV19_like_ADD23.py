#!/usr/bin/env python3
"""
Restructure ASV19 to match ADD23 folder structure.

ADD23 structure:
  ADD23/<model_run>/<model_run>_<eval_split>/
    results.json
    results/predictions/...

ASV19 currently (flat):
  ASV19/DeepFense_ASV19_<...>_Seed<N>_<eval_split>/   (all at top level)
  ASV19/*.csv   (leave at top level)

Target ASV19 structure (same as ADD23):
  ASV19/<model_run>/<model_run>_<eval_split>/
    results.json
    results/predictions/...

where model_run = prefix up to and including _Seed<N>, e.g. DeepFense_ASV19_EAT_AASIST_NoAug_Seed2
"""
import re
import os
from pathlib import Path

ASV19_ROOT = Path(__file__).resolve().parent / "ASV19"
# Match dir name: DeepFense_ASV19_..._Seed<N>_<rest>
MODEL_RUN_PATTERN = re.compile(r"^(.+_Seed\d+)_(.+)$")


def main():
    if not ASV19_ROOT.is_dir():
        print(f"Not a directory: {ASV19_ROOT}")
        return
    moved = 0
    skipped = 0
    errors = []
    for item in sorted(ASV19_ROOT.iterdir()):
        if not item.is_dir():
            # Keep .csv and other files at top level
            continue
        name = item.name
        if not name.startswith("DeepFense_ASV19_"):
            continue
        m = MODEL_RUN_PATTERN.match(name)
        if not m:
            skipped += 1
            continue
        model_run, eval_suffix = m.group(1), m.group(2)
        # Target: ASV19/<model_run>/<name>/
        parent = ASV19_ROOT / model_run
        target = parent / name
        if target.resolve() == item.resolve():
            skipped += 1
            continue
        if target.exists():
            errors.append(f"Target exists: {target}")
            continue
        try:
            parent.mkdir(parents=True, exist_ok=True)
            item.rename(target)
            moved += 1
        except Exception as e:
            errors.append(f"{item.name}: {e}")
    print(f"Moved {moved} run dirs into model-run subfolders.")
    if skipped:
        print(f"Skipped {skipped} dirs (no match or already in place).")
    for e in errors[:20]:
        print(f"  Error: {e}")
    if len(errors) > 20:
        print(f"  ... and {len(errors) - 20} more errors.")


if __name__ == "__main__":
    main()
