#!/usr/bin/env python3
"""
Restructure prediction_scores subfolders to match ADD23 layout.

ADD23 structure:
  <ROOT>/<model_run>/<model_run>_<eval_split>/
    results.json
    results/predictions/...

Flat structure (current):
  <ROOT>/DeepFense_<ROOT>_<...>_Seed<N>_<eval_split>/   (all at top level)

Target: same as ADD23, with model_run = prefix up to and including _Seed<N>.

Run dirs must start with DeepFense_<ROOT>_ (e.g. DeepFense_CompSpoof_).
"""
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOTS = ["CompSpoof", "CtrSVDD", "FakeMusicCaps", "HABLA", "PartialSpoof"]
MODEL_RUN_PATTERN = re.compile(r"^(.+_Seed\d+)_(.+)$")


def restructure_one(root_path: Path, prefix: str) -> tuple[int, int, list]:
    """Process one folder (e.g. CompSpoof). Return (moved, skipped, errors)."""
    moved, skipped, errors = 0, 0, []
    if not root_path.is_dir():
        return 0, 0, [f"Not a directory: {root_path}"]
    for item in sorted(root_path.iterdir()):
        if not item.is_dir():
            continue
        name = item.name
        if not name.startswith(prefix):
            continue
        m = MODEL_RUN_PATTERN.match(name)
        if not m:
            skipped += 1
            continue
        model_run, _ = m.group(1), m.group(2)
        parent = root_path / model_run
        target = parent / name
        if target.resolve() == item.resolve():
            skipped += 1
            continue
        if target.exists():
            errors.append(f"Target exists: {target}")
            continue
        try:
            parent.mkdir(parents=True, exist_ok=True)
            item.rename(target)
            moved += 1
        except Exception as e:
            errors.append(f"{item.name}: {e}")
    return moved, skipped, errors


def main():
    for root_name in ROOTS:
        root_path = BASE / root_name
        prefix = f"DeepFense_{root_name}_"
        moved, skipped, errors = restructure_one(root_path, prefix)
        print(f"{root_name}: moved {moved}, skipped {skipped}")
        for e in errors[:10]:
            print(f"  Error: {e}")
        if len(errors) > 10:
            print(f"  ... and {len(errors) - 10} more errors.")


if __name__ == "__main__":
    main()
