#!/usr/bin/env python3
"""
Build a wide-format TSV from all_experiments.tsv:
- Rows: Frontend, Backend, Training Data, Seed
- Column groups: one per eval set (ASV19, LA21, DF21, ITW, ODSS, HABLA, ADD22 1, ADD22 2, ADD23 1, ADD23 2, CodecFake, MLAAD, ReplayDF)
- Each eval set has 3 columns: EER, ACC, F1

Output: experiment_tables/wide_experiments.tsv
"""
from __future__ import annotations

import csv
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ALL_TSV = SCRIPT_DIR / "all_experiments.tsv"
OUT_TSV = SCRIPT_DIR / "wide_experiments.tsv"

# Eval set (as in all_experiments.tsv) -> display name for column group
EVAL_TO_HEADER = {
    "ASV19": "ASV19",
    "LA21": "LA21",
    "ASVSpoofLA21": "LA21",
    "DF21": "DF21",
    "ITW": "ITW",
    "ODSS": "ODSS",
    "HABLA": "HABLA",
    "add22_track1": "ADD22 1",
    "add22_track3": "ADD22 2",
    "add23_R1": "ADD23 1",
    "add23_R2": "ADD23 2",
    "CodecFake": "CodecFake",
    "MLAAD_final": "MLAAD",
    "ReplayDF": "ReplayDF",
}

# Column groups in desired order (only these appear in the wide table)
EVAL_ORDER = [
    "ASV19", "LA21", "DF21", "ITW", "ODSS", "HABLA",
    "ADD22 1", "ADD22 2", "ADD23 1", "ADD23 2",
    "CodecFake", "MLAAD", "ReplayDF",
]

# Reverse: header -> possible internal names
HEADER_TO_EVAL = {}
for k, v in EVAL_TO_HEADER.items():
    HEADER_TO_EVAL.setdefault(v, []).append(k)

# Row ordering
FRONTEND_ORDER = ["Wav2Vec2", "WavLM", "Hubert", "EAT", "mert"]
BACKEND_ORDER = ["MLP", "AASIST", "Nes2Net", "Res2Net", "NLP", "TCM"]
SEED_ORDER = [2, 42, 240]


def main():
    # Load long-format data
    rows = []
    with open(ALL_TSV, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f, delimiter="\t")
        for row in r:
            rows.append(row)

    # Key: (Frontend, Backend, TrainingData, Seed) -> { header -> (EER, ACC, F1) }
    data = {}
    for r in rows:
        frontend = r["Frontend"]
        backend = r["Backend"]
        training_data = r["TrainingData"]
        try:
            seed = int(r["Seed"])
        except (ValueError, KeyError):
            continue
        eval_set = r["EvalSet"]
        header = EVAL_TO_HEADER.get(eval_set)
        if header not in EVAL_ORDER:
            continue
        try:
            acc = float(r["Accuracy"]) if r.get("Accuracy") else ""
            f1 = float(r["MacroF1"]) if r.get("MacroF1") else ""
            eer = float(r["EER"]) if r.get("EER") else ""
        except (ValueError, TypeError):
            acc = f1 = eer = ""
        key = (frontend, backend, training_data, seed)
        data.setdefault(key, {})[header] = (eer, acc, f1)

    # Sort row keys: TrainingData, Frontend, Backend, Seed
    def frontend_idx(x):
        try:
            return FRONTEND_ORDER.index(x)
        except ValueError:
            return len(FRONTEND_ORDER)

    def backend_idx(x):
        try:
            return BACKEND_ORDER.index(x)
        except ValueError:
            return len(BACKEND_ORDER)

    def seed_idx(x):
        try:
            return SEED_ORDER.index(x)
        except ValueError:
            return 999

    sorted_keys = sorted(
        data.keys(),
        key=lambda k: (k[2], frontend_idx(k[0]), backend_idx(k[1]), seed_idx(k[3]), k[3])
    )

    # Build header rows (row1: eval group names spanning 3 cols each; row2: EER, ACC, F1)
    line1 = ["FrontEnd", "BackEnd", "Training Data", "Seed"]
    line2 = ["", "", "", ""]
    for h in EVAL_ORDER:
        line1.extend([h, "", ""])  # one label + 2 empty for sub-cols
        line2.extend(["EER", "ACC", "F1"])

    # Write TSV
    with open(OUT_TSV, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(line1)
        w.writerow(line2)
        for key in sorted_keys:
            frontend, backend, training_data, seed = key
            row = [frontend, backend, training_data, seed]
            for h in EVAL_ORDER:
                triple = data[key].get(h, ("", "", ""))
                if isinstance(triple[0], float):
                    row.append(round(triple[0], 4))
                else:
                    row.append(triple[0])
                if isinstance(triple[1], float):
                    row.append(round(triple[1], 4))
                else:
                    row.append(triple[1])
                if isinstance(triple[2], float):
                    row.append(round(triple[2], 4))
                else:
                    row.append(triple[2])
            w.writerow(row)

    print(f"Wrote {OUT_TSV} ({len(sorted_keys)} rows)")


if __name__ == "__main__":
    main()
