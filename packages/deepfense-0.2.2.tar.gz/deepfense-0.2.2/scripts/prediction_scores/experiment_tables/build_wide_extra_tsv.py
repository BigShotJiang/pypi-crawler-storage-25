#!/usr/bin/env python3
"""
Build wide-format TSVs (same style as wide_experiments.tsv) for:
1. EnvSSD + CombSpoof: from prediction_scores/EnvSSD and prediction_scores/CompSpoof
   (models trained on EnvSSD or CompSpoof, evaluated on EnvSDD and CompSpoof)
2. CtrSVDD (from CtrSVDD_*.csv in experiment_tables)
3. FakeMusicCaps (from FakeMusicCaps_*.csv in experiment_tables)
"""
from __future__ import annotations

import csv
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PREDICTION_SCORES_DIR = SCRIPT_DIR.parent  # prediction_scores/

FRONTEND_ORDER = ["Wav2Vec2", "WavLM", "Hubert", "EAT", "mert"]
BACKEND_ORDER = ["MLP", "AASIST", "Nes2Net", "Res2Net", "NLP", "TCM"]
SEED_ORDER = [2, 42, 240]
TRAINING_DATA_ORDER = ["EnvSSD", "CompSpoof"]
EVAL_SETS_ENV_COMP = ["EnvSDD", "CompSpoof"]


def build_wide_envssd_compspoof() -> None:
    """
    Build wide_EnvSSD_CombSpoof.tsv from prediction_scores/EnvSSD and prediction_scores/CompSpoof.
    Each folder has EnvSDD.csv and CompSpoof.csv (eval results). CSV columns: FrontEnd, BackEnd, Loss, Seed, EER, EER_CI, F1, Accuracy.
    """
    # Key: (Frontend, Backend, Training Data, Seed) -> { EvalSet -> (EER, ACC, F1) }
    data = {}
    for training_data in ["EnvSSD", "CompSpoof"]:
        folder = PREDICTION_SCORES_DIR / training_data
        if not folder.is_dir():
            continue
        for eval_name, eval_set in [("EnvSDD", "EnvSDD"), ("CompSpoof", "CompSpoof")]:
            csv_path = folder / f"{eval_name}.csv"
            if not csv_path.exists():
                continue
            with open(csv_path, newline="", encoding="utf-8") as f:
                r = csv.DictReader(f)
                for row in r:
                    frontend = (row.get("FrontEnd") or row.get("Frontend") or "").strip()
                    backend = (row.get("BackEnd") or row.get("Backend") or "").strip()
                    try:
                        seed = int(row.get("Seed", 0))
                    except (ValueError, TypeError):
                        continue
                    try:
                        eer = float(row["EER"]) if row.get("EER") else ""
                        acc = float(row["Accuracy"]) if row.get("Accuracy") else ""
                        f1 = float(row["F1"]) if row.get("F1") else ""
                    except (ValueError, TypeError):
                        eer = acc = f1 = ""
                    key = (frontend, backend, training_data, seed)
                    data.setdefault(key, {})[eval_set] = (eer, acc, f1)

    def frontend_idx(x):
        try:
            return FRONTEND_ORDER.index(x)
        except ValueError:
            return len(FRONTEND_ORDER)

    def backend_idx(x):
        try:
            return BACKEND_ORDER.index(x)
        except ValueError:
            return len(BACKEND_ORDER)

    def training_data_idx(x):
        try:
            return TRAINING_DATA_ORDER.index(x)
        except ValueError:
            return len(TRAINING_DATA_ORDER)

    def seed_idx(x):
        try:
            return SEED_ORDER.index(x)
        except ValueError:
            return 999

    sorted_keys = sorted(
        data.keys(),
        key=lambda k: (
            training_data_idx(k[2]),
            frontend_idx(k[0]),
            backend_idx(k[1]),
            seed_idx(k[3]),
            k[3],
        ),
    )

    line1 = ["FrontEnd", "BackEnd", "Training Data", "Seed"]
    line2 = ["", "", "", ""]
    for h in EVAL_SETS_ENV_COMP:
        line1.extend([h, "", ""])
        line2.extend(["EER", "ACC", "F1"])

    out_path = SCRIPT_DIR / "wide_EnvSSD_CombSpoof.tsv"
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(line1)
        w.writerow(line2)
        for key in sorted_keys:
            frontend, backend, training_data, seed = key
            row = [frontend, backend, training_data, seed]
            for h in EVAL_SETS_ENV_COMP:
                triple = data[key].get(h, ("", "", ""))
                for v in triple:
                    if isinstance(v, float):
                        row.append(round(v, 4))
                    else:
                        row.append(v)
            w.writerow(row)

    print(f"Wrote {out_path} ({len(sorted_keys)} rows)")


def load_csv_for_frontend(prefix: str, frontend: str) -> list[dict]:
    """Load a single {prefix}_{frontend}.csv; return list of row dicts."""
    path = SCRIPT_DIR / f"{prefix}_{frontend}.csv"
    if not path.exists():
        return []
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            row["_Frontend"] = frontend
            rows.append(row)
    return rows


def build_wide_tsv(
    out_name: str,
    csv_prefix: str,
    eval_sets: list[str],
    frontends: list[str] | None = None,
    training_data: str = "",
) -> None:
    """
    csv_prefix: e.g. "CompSpoof", "CtrSVDD", "FakeMusicCaps"
    eval_sets: e.g. ["EnvSDD", "CompSpoof"] or ["CtrSVDD"] or ["FakeMusicCaps"]
    frontends: which frontends to look for (default: Wav2Vec2, WavLM, Hubert, EAT, mert)
    training_data: value for Training Data column (e.g. "CompSpoof" for models trained on CompSpoof)
    """
    if frontends is None:
        frontends = ["Wav2Vec2", "WavLM", "Hubert", "EAT", "mert"]

    # Gather all rows
    all_rows = []
    for fe in frontends:
        all_rows.extend(load_csv_for_frontend(csv_prefix, fe))

    # Key: (Frontend, Backend, Seed) -> { EvalSet -> (EER, ACC, F1) }
    data = {}
    for r in all_rows:
        frontend = r["_Frontend"]
        backend = r["Backend"]
        try:
            seed = int(r["Seed"])
        except (ValueError, KeyError):
            continue
        eval_set = r["EvalSet"]
        if eval_set not in eval_sets:
            continue
        try:
            acc = float(r["Accuracy"]) if r.get("Accuracy") else ""
            f1 = float(r["MacroF1"]) if r.get("MacroF1") else ""
            eer = float(r["EER"]) if r.get("EER") else ""
        except (ValueError, TypeError):
            acc = f1 = eer = ""
        key = (frontend, backend, seed)
        data.setdefault(key, {})[eval_set] = (eer, acc, f1)

    def frontend_idx(x):
        try:
            return FRONTEND_ORDER.index(x)
        except ValueError:
            return len(FRONTEND_ORDER)

    def backend_idx(x):
        try:
            return BACKEND_ORDER.index(x)
        except ValueError:
            return len(BACKEND_ORDER)

    def seed_idx(x):
        try:
            return SEED_ORDER.index(x)
        except ValueError:
            return 999

    sorted_keys = sorted(
        data.keys(),
        key=lambda k: (frontend_idx(k[0]), backend_idx(k[1]), seed_idx(k[2]), k[2]),
    )

    # Header rows (same as wide_experiments: Training Data column present but empty)
    line1 = ["FrontEnd", "BackEnd", "Training Data", "Seed"]
    line2 = ["", "", "", ""]
    for h in eval_sets:
        line1.extend([h, "", ""])
        line2.extend(["EER", "ACC", "F1"])

    out_path = SCRIPT_DIR / out_name
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(line1)
        w.writerow(line2)
        for key in sorted_keys:
            frontend, backend, seed = key
            row = [frontend, backend, training_data, seed]
            for h in eval_sets:
                triple = data[key].get(h, ("", "", ""))
                for v in triple:
                    if isinstance(v, float):
                        row.append(round(v, 4))
                    else:
                        row.append(v)
            w.writerow(row)

    print(f"Wrote {out_path} ({len(sorted_keys)} rows)")


def main():
    # 1) EnvSSD + CombSpoof: from prediction_scores/EnvSSD and prediction_scores/CompSpoof (both training conditions)
    build_wide_envssd_compspoof()

    # 2) CtrSVDD
    build_wide_tsv(
        "wide_CtrSVDD.tsv",
        "CtrSVDD",
        ["CtrSVDD"],
        frontends=["Wav2Vec2", "WavLM", "Hubert", "EAT"],
    )

    # 3) FakeMusicCaps (only EAT and mert have CSVs)
    build_wide_tsv(
        "wide_FakeMusicCaps.tsv",
        "FakeMusicCaps",
        ["FakeMusicCaps"],
        frontends=["EAT", "mert"],
    )


if __name__ == "__main__":
    main()
