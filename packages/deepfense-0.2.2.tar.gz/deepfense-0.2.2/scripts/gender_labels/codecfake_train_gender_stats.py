#!/usr/bin/env python3
"""Gender (from aishell.txt) × bonafide/spoof stats for CodecFake train parquet."""
import pandas as pd
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
GENDER_PATH = SCRIPT_DIR / "aishell.txt"
PARQUET_PATH = Path("/netscratch/yelkheir/DeepFense/DeepFense/scripts/data_preparation/CodecFake/codecfake_train.parquet")

# Load gender: SSB1837\tB\tfemale\tnorth
gender = {}
with open(GENDER_PATH) as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        parts = line.split("\t")
        if len(parts) >= 3:
            gender[parts[0].strip()] = parts[2].strip().lower()

print(f"Loaded {len(gender)} gender labels from aishell.txt")

df = pd.read_parquet(PARQUET_PATH)

def base_id(row_id):
    s = str(row_id).strip()
    if "_" in s:
        s = s.split("_", 1)[1]
    if s.startswith("SSB") and len(s) >= 7:
        return s[:7]
    return s[:7] if len(s) >= 7 else s

df["base_id"] = df["ID"].map(base_id)
df["gender"] = df["base_id"].map(gender)
df_with_g = df.dropna(subset=["gender"])
unknown = len(df) - len(df_with_g)
if unknown:
    print(f"Samples with no gender in aishell.txt: {unknown} (excluded)\n")

print("=" * 60)
print("Gender x Label (bonafide / spoof) — CodecFake train")
print("=" * 60)

for label in ["bonafide", "spoof"]:
    sub = df_with_g[df_with_g["label"] == label]
    f = (sub["gender"] == "female").sum()
    m = (sub["gender"] == "male").sum()
    t = len(sub)
    print(f"\n{label.upper()}")
    print(f"  female: {f:>8}  ({100*f/t:.2f}%)")
    print(f"  male:   {m:>8}  ({100*m/t:.2f}%)")
    print(f"  total:  {t:>8}")

print("\n" + "-" * 60)
ct = pd.crosstab(df_with_g["label"], df_with_g["gender"])
print("Crosstab (counts):")
print(ct)
print("\nRow %:")
print(pd.crosstab(df_with_g["label"], df_with_g["gender"], normalize="index").apply(lambda x: (100*x).round(2).astype(str) + "%"))
print("\nOverall total with gender:", len(df_with_g))
