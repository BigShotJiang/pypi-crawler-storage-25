#!/usr/bin/env python3
"""Gender (from ASV19.txt) x bonafide/spoof stats for asvspoof19_train.parquet.

Uses protocol to map utterance ID (LA_T_xxx) -> speaker ID (LA_xxxx), then ASV19.txt for gender.
"""
import pandas as pd
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ASV19_TXT = SCRIPT_DIR / "ASV19.txt"
PARQUET_PATH = Path("/netscratch/yelkheir/DeepFense/DeepFense/scripts/data_preparation/ASV19/asvspoof19_train.parquet")
PROTOCOL_PATH = Path("/netscratch/yelkheir/DeepFense/Distillation/protocols/asv19/asvspoof19.txt")

# Load ASV19.txt: ID,-,ASVspoofID,AGE,GENDER,...
# We need ASVspoofID (col 2) -> GENDER (col 4); normalize to female/male
gender_by_speaker = {}
with open(ASV19_TXT) as f:
    lines = f.readlines()
header = lines[0].strip().split(",")
for line in lines[1:]:
    parts = [p.strip() for p in line.split(",")]
    if len(parts) >= 5:
        asv_id = parts[2]   # ASVspoofID e.g. LA_0001
        g = parts[4].upper()  # M or F
        gender_by_speaker[asv_id] = "female" if g == "F" else "male"

print(f"Loaded {len(gender_by_speaker)} speaker genders from ASV19.txt")

# Protocol: speaker_id utterance_id - - label
utt_to_speaker = {}
if PROTOCOL_PATH.exists():
    with open(PROTOCOL_PATH) as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 2:
                utt_to_speaker[parts[1]] = parts[0]
    print(f"Loaded {len(utt_to_speaker)} utterance->speaker mappings from protocol")
else:
    print(f"Protocol not found: {PROTOCOL_PATH}")
    print("Cannot map utterance ID to speaker; exiting.")
    exit(1)

# Parquet: ID = utterance_id, label = bonafide/spoof
df = pd.read_parquet(PARQUET_PATH)
df["speaker_id"] = df["ID"].map(utt_to_speaker)
df["gender"] = df["speaker_id"].map(gender_by_speaker)
df_with_g = df.dropna(subset=["gender"])
unknown = len(df) - len(df_with_g)
if unknown:
    print(f"Samples with no gender in ASV19.txt: {unknown} (excluded)\n")

print("=" * 60)
print("Gender x Label (bonafide / spoof) — ASV19 train")
print("=" * 60)

for label in ["bonafide", "spoof"]:
    sub = df_with_g[df_with_g["label"] == label]
    f = (sub["gender"] == "female").sum()
    m = (sub["gender"] == "male").sum()
    t = len(sub)
    print(f"\n{label.upper()}")
    print(f"  female: {f:>8}  ({100*f/t:.2f}%)")
    print(f"  male:   {m:>8}  ({100*m/t:.2f}%)")
    print(f"  total:  {t:>8}")

print("\n" + "-" * 60)
ct = pd.crosstab(df_with_g["label"], df_with_g["gender"])
print("Crosstab (counts):")
print(ct)
print("\nRow %:")
print(pd.crosstab(df_with_g["label"], df_with_g["gender"], normalize="index").apply(lambda x: (100*x).round(2).astype(str) + "%"))
print("\nOverall total with gender:", len(df_with_g))
