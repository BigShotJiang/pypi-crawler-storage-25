#!/usr/bin/env python3
"""
Normalize result CSVs: rename *_class0 -> class0, *_class1 -> class1; drop *_pred_label.
Keep all other columns (file_id, label, quality metadata, gender, language, etc.).
Push the directories to Hugging Face DeepFense/Labeling dataset.

Usage:
  export HF_TOKEN=your_token
  python3 normalize_and_push_labeling.py [--push]
  Without --push: only writes normalized CSVs to labeling_upload/
  With --push: uploads labeling_upload/ to DeepFense/Labeling (dataset).
"""

import argparse
import os
import sys
from pathlib import Path

import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
SOURCES = [
    ("quality_results", "quality"),
    ("gender_results", "gender"),
    ("language_results", "language"),
]
UPLOAD_DIR = SCRIPT_DIR / "labeling_upload"
REPO_ID = "DeepFense/Labeling"
HF_TOKEN = "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"  # Hugging Face token for push


def find_score_columns(df):
    """Return (class0_col, class1_col) for columns ending with _class0 and _class1."""
    cols = list(df.columns)
    c0 = [c for c in cols if c.endswith("_class0")]
    c1 = [c for c in cols if c.endswith("_class1")]
    if len(c0) != 1 or len(c1) != 1:
        return None, None
    return c0[0], c1[0]


def normalize_csv(src_path: Path, out_path: Path) -> bool:
    """
    Read CSV, rename *_class0 -> class0, *_class1 -> class1; drop *_pred_label.
    Keep all other columns (file_id, label, quality, gender, language, etc.).
    """
    df = pd.read_csv(src_path, low_memory=False)
    c0_col, c1_col = find_score_columns(df)
    if c0_col is None or c1_col is None:
        print(f"  Skip (no *_class0/*_class1): {src_path}")
        return False

    # Start with a copy; we'll rename/drop and keep everything else
    out_df = df.copy()

    # Rename score columns to class0, class1
    out_df = out_df.rename(columns={c0_col: "class0", c1_col: "class1"})

    # Drop pred_label column(s); keep ground truth 'label'. If no 'label', use first _pred_label as 'label'
    pred_cols = [c for c in out_df.columns if c.endswith("_pred_label")]
    if pred_cols:
        if "label" not in out_df.columns:
            first_pred = pred_cols[0]
            out_df = out_df.rename(columns={first_pred: "label"})
            out_df = out_df.drop(columns=[c for c in pred_cols if c != first_pred])
        else:
            out_df = out_df.drop(columns=pred_cols)

    # Explicit column order: file_id first, then all metadata, then label, class0, class1 last
    meta = [c for c in out_df.columns if c not in ("file_id", "label", "class0", "class1")]
    final_cols = ["file_id"] + meta + [c for c in ("label", "class0", "class1") if c in out_df.columns]
    out_df = out_df[[c for c in final_cols if c in out_df.columns]]

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False)
    return True


def main():
    parser = argparse.ArgumentParser(description="Normalize CSVs and optionally push to HF")
    parser.add_argument("--push", action="store_true", help="Push labeling_upload/ to DeepFense/Labeling")
    parser.add_argument("--push-subdir", type=str, default=None, help="Push only this subdir (e.g. quality, gender, language) to avoid timeout")
    args = parser.parse_args()

    # # 1) Normalize all CSVs into labeling_upload/
    # for src_name, dest_name in SOURCES:
    #     src_root = SCRIPT_DIR / src_name
    #     dest_root = UPLOAD_DIR / dest_name
    #     if not src_root.exists():
    #         print(f"Skipping {src_name} (not found)")
    #         continue
    #     for src_path in src_root.rglob("*.csv"):
    #         rel = src_path.relative_to(src_root)
    #         out_path = dest_root / rel
    #         if normalize_csv(src_path, out_path):
    #             print(f"Normalized -> {out_path.relative_to(UPLOAD_DIR)}")

    # print(f"\nNormalized CSVs written under {UPLOAD_DIR}")

    # if not args.push:
    #     return

    # # 2) Push to Hugging Face
    token = os.environ.get("HF_TOKEN") or HF_TOKEN
    # if not token:
    #     print("Set HF_TOKEN to push to Hugging Face.", file=sys.stderr)
    #     sys.exit(1)

    try:
        from huggingface_hub import HfApi
        api = HfApi(token=token)
        if args.push_subdir:
            folder = UPLOAD_DIR / args.push_subdir
            path_in_repo = f"scores/{args.push_subdir}"
            if not folder.is_dir():
                print(f"Folder not found: {folder}", file=sys.stderr)
                sys.exit(1)
            print(f"Uploading {folder} to {REPO_ID} (path_in_repo: {path_in_repo}) ...")
            api.upload_folder(
                folder_path=str(folder),
                repo_id=REPO_ID,
                repo_type="dataset",
                path_in_repo=path_in_repo,
            )
        else:
            print(f"Uploading {UPLOAD_DIR} to {REPO_ID} (path_in_repo: scores/) ...")
            api.upload_folder(
                folder_path=str(UPLOAD_DIR),
                repo_id=REPO_ID,
                repo_type="dataset",
                path_in_repo="scores",
            )
        view_url = f"https://huggingface.co/datasets/{REPO_ID}/tree/main/scores"
        print(f"Upload done. View your score CSVs here: {view_url}")
    except Exception as e:
        print(f"Upload failed: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
