#!/usr/bin/env python3
"""
Build gender CSV results for selected DeepFense models.

Same 10 models as quality script. For each model × test set we merge
predictions with Labeling/gender parquet (MLAAD_Final, codecfake_eval,
asvspoof5_test, asvspoof19_test, asvspoof21_la_eval) and write CSVs
under gender_results/.
"""

import pandas as pd
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PREDICTION_SCORES = SCRIPT_DIR / "prediction_scores"
LABELING_GENDER = SCRIPT_DIR / "Labeling" / "gender"
OUT_DIR = SCRIPT_DIR / "gender_results"

# Same 10 models as build_quality_scores.py
MODELS = [
    ("ASV19", "DeepFense_ASV19_EAT_AASIST_NoAug_Seed2"),
    ("ASV19", "DeepFense_ASV19_Hubert_AASIST_NoAug_Seed2"),
    ("ASV19", "DeepFense_ASV19_Wav2Vec2_AASIST_NoAug_Seed2"),
    ("ASV19", "DeepFense_ASV19_WavLM_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_EAT_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_Hubert_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_Wav2Vec2_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_WavLM_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_Wav2Vec2_MLP_NoAug_Seed2"),
    ("ASV19", "DeepFense_ASV19_Wav2Vec2_TCM_NoAug_Seed2"),
]

# test_set (prediction folder name) -> (parquet filename, prediction filename)
# asvspoof2019_la_eval uses asvspoof19_test.parquet for gender (same LA_E_* IDs)
GENDER_TEST_SETS = [
    ("MLAAD_final", "MLAAD_Final.parquet", "MLAAD_final_predictions.txt"),
    ("codecfake_eval", "codecfake_eval.parquet", "codecfake_eval_predictions.txt"),
    ("asvspoof5_test", "asvspoof5_test.parquet", "asvspoof5_test_predictions.txt"),
    ("asvspoof2019_la_eval", "asvspoof19_test.parquet", "asvspoof2019_la_eval_predictions.txt"),
    ("asvspoof21_la_eval", "asvspoof21_la_eval.parquet", "asvspoof21_la_eval_predictions.txt"),
]


def load_gender(parquet_path: Path, use_basename_id: bool = False) -> pd.DataFrame:
    """Load gender parquet. If use_basename_id (MLAAD), set file_id = stem of ID."""
    df = pd.read_parquet(parquet_path)
    df = df.rename(columns={"ID": "file_id"})
    if use_basename_id:
        df["file_id"] = df["file_id"].astype(str).map(lambda x: Path(x).stem)
    return df


def load_predictions(pred_path: Path, score_prefix: str) -> pd.DataFrame:
    """Load predictions (ID_audio, label, score_class0, score_class1)."""
    df = pd.read_csv(pred_path)
    df = df.rename(columns={
        "ID_audio": "file_id",
        "label": f"{score_prefix}_pred_label",
        "score_class0": f"{score_prefix}_class0",
        "score_class1": f"{score_prefix}_class1",
    })
    return df


def main():
    for test_set, parquet_name, pred_filename in GENDER_TEST_SETS:
        parquet_path = LABELING_GENDER / parquet_name
        if not parquet_path.exists():
            print(f"Skip {test_set}: missing {parquet_path}")
            continue
        use_basename = test_set == "MLAAD_final"
        gender_df = load_gender(parquet_path, use_basename_id=use_basename)

        for train_set, model_folder in MODELS:
            base = PREDICTION_SCORES / train_set / model_folder
            pred_path = base / f"{model_folder}_{test_set}" / "results" / "predictions" / pred_filename
            if not pred_path.exists():
                continue
            df_pred = load_predictions(pred_path, score_prefix=test_set)
            merged = gender_df.merge(df_pred, on="file_id", how="inner")
            out_path = OUT_DIR / test_set / f"{model_folder}.csv"
            out_path.parent.mkdir(parents=True, exist_ok=True)
            merged.to_csv(out_path, index=False)
            print(f"Wrote {out_path} ({len(merged)} rows)")

    print(f"\nDone. Results under {OUT_DIR}")


if __name__ == "__main__":
    main()
