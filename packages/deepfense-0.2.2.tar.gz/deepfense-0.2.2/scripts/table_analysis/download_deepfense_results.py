#!/usr/bin/env python3
"""
Download DeepFense/deepfense-results (Hugging Face Space) into this directory.
Uses HF_TOKEN or HUGGING_FACE_HUB_TOKEN from the environment.
"""
import os
from pathlib import Path
from huggingface_hub import snapshot_download

REPO_ID = "DeepFense/deepfense-results"
REPO_TYPE = "space"
LOCAL_DIR = Path(__file__).resolve().parent


def main():
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if not token:
        print("Set HF_TOKEN or HUGGING_FACE_HUB_TOKEN to download (private Space).")
        return
    path = snapshot_download(
        repo_id=REPO_ID,
        repo_type=REPO_TYPE,
        local_dir=str(LOCAL_DIR),
        token=token,
    )
    print(f"Downloaded to: {path}")


if __name__ == "__main__":
    main()
