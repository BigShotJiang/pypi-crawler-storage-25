#!/usr/bin/env python3
"""
Combine per-model CSV files across all dataset folders under language/.
Creates language/all/<model_name>/<model_name>.csv with one combined CSV per model.
Adds a column 'eval_set' with the source folder name (e.g. MLAAD_final).
Streams row-by-row to avoid loading all data into memory.
"""
import csv
from pathlib import Path

LANGUAGE_DIR = Path(__file__).resolve().parent
ALL_DIR = LANGUAGE_DIR / "all"

# Dataset subdirs to include (subdirs containing per-model CSVs)
DATASET_DIRS = [
    "MLAAD_final",
]


def main():
    # Collect (model_name -> list of (csv_path, eval_set))
    model_files = {}
    for eval_set in DATASET_DIRS:
        d = LANGUAGE_DIR / eval_set
        if not d.is_dir():
            continue
        for csv_path in d.glob("*.csv"):
            model_name = csv_path.stem
            model_files.setdefault(model_name, []).append((str(csv_path), eval_set))

    ALL_DIR.mkdir(parents=True, exist_ok=True)

    for model_name, pairs in sorted(model_files.items()):
        subdir = ALL_DIR / model_name
        subdir.mkdir(parents=True, exist_ok=True)
        out_path = subdir / f"{model_name}.csv"

        total_rows = 0
        header_written = False
        header_with_eval = None

        with open(out_path, "w", newline="", encoding="utf-8") as out_f:
            writer = None
            for csv_path, eval_set in pairs:
                with open(csv_path, "r", encoding="utf-8", newline="") as f:
                    reader = csv.reader(f)
                    header = next(reader)
                    if not header_written:
                        header_with_eval = header + ["eval_set"]
                        writer = csv.writer(out_f)
                        writer.writerow(header_with_eval)
                        header_written = True
                    for row in reader:
                        if len(row) == len(header):
                            writer.writerow(row + [eval_set])
                            total_rows += 1

        print(f"{model_name}: {total_rows} rows -> {out_path}")

    print(f"\nDone. Output under {ALL_DIR}")


if __name__ == "__main__":
    main()
