#!/usr/bin/env python3
"""
Export all combined CSVs under quality/all/ into one Excel workbook.
Each model -> one or more sheets (Excel limit 1,048,576 rows per sheet).
Requires: pip install openpyxl
Run from this directory: python3 csvs_to_one_excel.py
"""
import csv
import sys
from pathlib import Path

QUALITY_DIR = Path(__file__).resolve().parent
ALL_DIR = QUALITY_DIR / "all"
EXCEL_PATH = QUALITY_DIR / "quality_all_models.xlsx"
MAX_ROWS_PER_SHEET = 3_048_576  # Excel limit
SHEET_NAME_MAX_LEN = 31  # Excel sheet name limit

try:
    import openpyxl
    from openpyxl.utils.exceptions import IllegalCharacterError
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False


def sanitize_sheet_name(name: str) -> str:
    """Excel sheet names: max 31 chars, no []:*?/\\"""
    for c in "[]:*?/\\":
        name = name.replace(c, "_")
    return name[:SHEET_NAME_MAX_LEN].strip() or "Sheet"


def export_to_excel():
    model_csvs = []
    for subdir in sorted(ALL_DIR.iterdir()):
        if not subdir.is_dir():
            continue
        csv_path = subdir / f"{subdir.name}.csv"
        if csv_path.is_file():
            model_csvs.append((subdir.name, csv_path))

    if not model_csvs:
        print("No model CSVs found under all/")
        return

    wb = openpyxl.Workbook(write_only=True)
    sheet_names_used = set()

    for model_name, csv_path in model_csvs:
        base_sheet = sanitize_sheet_name(model_name)
        part = 0
        rows_in_sheet = 0
        ws = None
        header = None

        with open(csv_path, "r", encoding="utf-8", newline="") as f:
            reader = csv.reader(f)
            header = next(reader)
            for row in reader:
                if ws is None or rows_in_sheet >= MAX_ROWS_PER_SHEET - 1:
                    part += 1
                    rows_in_sheet = 0
                    sheet_name = base_sheet if part == 1 else f"{base_sheet[:28]}_{part}"
                    while sheet_name in sheet_names_used:
                        part += 1
                        sheet_name = f"{base_sheet[:26]}_{part}"
                    sheet_names_used.add(sheet_name)
                    ws = wb.create_sheet(title=sheet_name)
                    ws.append(header)
                try:
                    ws.append(row)
                except IllegalCharacterError:
                    row_clean = [str(c).replace("\x00", "") for c in row]
                    ws.append(row_clean)
                rows_in_sheet += 1

        print(f"{model_name} -> {part} sheet(s)")

    wb.save(EXCEL_PATH)
    print(f"\nSaved: {EXCEL_PATH}")


def fallback_one_csv():
    """Fallback: one combined CSV with 'model' column (open in Excel, then Save As .xlsx)."""
    out_path = QUALITY_DIR / "quality_all_models_combined.csv"
    model_csvs = []
    for subdir in sorted(ALL_DIR.iterdir()):
        if not subdir.is_dir():
            continue
        csv_path = subdir / f"{subdir.name}.csv"
        if csv_path.is_file():
            model_csvs.append((subdir.name, csv_path))
    if not model_csvs:
        print("No model CSVs found under all/")
        return
    total = 0
    with open(out_path, "w", newline="", encoding="utf-8") as out_f:
        writer = None
        for model_name, csv_path in model_csvs:
            with open(csv_path, "r", encoding="utf-8", newline="") as f:
                reader = csv.reader(f)
                header = next(reader)
                if writer is None:
                    writer = csv.writer(out_f)
                    writer.writerow(header + ["model"])
                for row in reader:
                    if len(row) == len(header):
                        writer.writerow(row + [model_name])
                        total += 1
            print(f"  {model_name}")
    print(f"\nSaved: {out_path} ({total} rows). Open in Excel and use Save As .xlsx if needed.")


def main():
    if not ALL_DIR.is_dir():
        print(f"Missing {ALL_DIR}. Run combine_per_model.py first.")
        sys.exit(1)
    if HAS_OPENPYXL:
        export_to_excel()
    else:
        print("openpyxl not found. Install with: pip install openpyxl")
        print("Writing one combined CSV instead (open in Excel, then Save As .xlsx):\n")
        fallback_one_csv()


if __name__ == "__main__":
    main()
