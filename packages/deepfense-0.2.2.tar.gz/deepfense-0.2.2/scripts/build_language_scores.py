#!/usr/bin/env python3
"""
Build per-language score CSVs for MLAAD_Final, fake classes only.

Uses same 10 models as quality/gender scripts. Loads MLAAD_Final.parquet,
filters to label=='fake', extracts language from path (e.g. .../fake/zh-cn/...),
merges with each model's MLAAD_final predictions, and writes one CSV per model
under language_results/MLAAD_final/ with columns: file_id, language, gender, label,
score_class0, score_class1 (and pred_label).
"""

import pandas as pd
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PREDICTION_SCORES = SCRIPT_DIR / "prediction_scores"
LABELING_GENDER = SCRIPT_DIR / "Labeling" / "gender"
OUT_DIR = SCRIPT_DIR / "language_results"

MODELS = [
    ("ASV19", "DeepFense_ASV19_EAT_AASIST_NoAug_Seed2"),
    ("ASV19", "DeepFense_ASV19_Hubert_AASIST_NoAug_Seed2"),
    ("ASV19", "DeepFense_ASV19_Wav2Vec2_AASIST_NoAug_Seed2"),
    ("ASV19", "DeepFense_ASV19_WavLM_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_EAT_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_Hubert_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_Wav2Vec2_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_WavLM_AASIST_NoAug_Seed2"),
    ("CodecFake", "DeepFense_CodecFake_Wav2Vec2_MLP_NoAug_Seed2"),
    ("ASV19", "DeepFense_ASV19_Wav2Vec2_TCM_NoAug_Seed2"),
]

MLAAD_PARQUET = LABELING_GENDER / "MLAAD_Final.parquet"
PRED_FILENAME = "MLAAD_final_predictions.txt"


def extract_language(path: str):
    """Extract language from MLAAD path: .../fake/LANG/..."""
    parts = str(path).split("/")
    if "fake" in parts:
        i = parts.index("fake")
        if i + 1 < len(parts):
            return parts[i + 1]
    return None


def load_mlaad_fake_with_language() -> pd.DataFrame:
    """Load MLAAD_Final.parquet, keep only fake, add language and file_id."""
    df = pd.read_parquet(MLAAD_PARQUET)
    df = df[df["label"] == "fake"].copy()
    df["language"] = df["ID"].astype(str).map(extract_language)
    df["file_id"] = df["ID"].astype(str).map(lambda x: Path(x).stem)
    return df[["file_id", "language", "gender", "label"]]


def load_predictions(pred_path: Path, score_prefix: str = "MLAAD_final") -> pd.DataFrame:
    """Load predictions (ID_audio, label, score_class0, score_class1), one row per file_id."""
    df = pd.read_csv(pred_path)
    df = df.rename(columns={
        "ID_audio": "file_id",
        "label": f"{score_prefix}_pred_label",
        "score_class0": f"{score_prefix}_class0",
        "score_class1": f"{score_prefix}_class1",
    })
    # Keep one row per file_id (predictions may contain duplicates)
    df = df.drop_duplicates(subset=["file_id"], keep="first")
    return df


def main():
    if not MLAAD_PARQUET.exists():
        print(f"Missing {MLAAD_PARQUET}")
        return
    mlaad_df = load_mlaad_fake_with_language()
    print(f"MLAAD fake samples with language: {len(mlaad_df)}")

    out_subdir = OUT_DIR / "MLAAD_final"
    out_subdir.mkdir(parents=True, exist_ok=True)

    for train_set, model_folder in MODELS:
        base = PREDICTION_SCORES / train_set / model_folder
        pred_path = base / f"{model_folder}_MLAAD_final" / "results" / "predictions" / PRED_FILENAME
        if not pred_path.exists():
            print(f"Skip {model_folder}: no predictions")
            continue
        pred_df = load_predictions(pred_path)
        merged = mlaad_df.merge(pred_df, on="file_id", how="inner")
        out_path = out_subdir / f"{model_folder}.csv"
        merged.to_csv(out_path, index=False)
        print(f"Wrote {out_path} ({len(merged)} rows, {merged['language'].nunique()} languages)")

    print(f"\nDone. Results under {OUT_DIR}")


if __name__ == "__main__":
    main()
