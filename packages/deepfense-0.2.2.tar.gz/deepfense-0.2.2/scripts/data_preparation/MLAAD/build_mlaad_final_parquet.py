"""
Build MLAAD_Final.parquet with columns: ID, gender, label (fake/real).

- ID: absolute path to the wav file under Processed_sr_16000_PCM16.
- gender: F (female), M (male), or U (unknown e.g. mix).
- label: "fake" or "real".

Gender is inferred from the real sample path in meta.csv (original_file contains
/female/ or /male/). Reals are deduplicated by ID (one row per unique real file).
"""
from pathlib import Path
import pandas as pd

PROCESSED_ROOT = Path("/ds-slt/audio/MLAAD/v5/Processed_sr_16000_PCM16")
FAKE_META_ROOT = Path("/ds-slt/audio/MLAAD/fake")
OUTPUT_DIR = Path(__file__).resolve().parent
OUTPUT_FILE = OUTPUT_DIR / "MLAAD_Final.parquet"


def gender_from_original_file(original_file: str) -> str:
    """Infer F/M/U from original_file path (e.g. de_DE/by_book/female/...)."""
    if not isinstance(original_file, str):
        return "U"
    p = original_file.lower()
    if "female" in p:
        return "F"
    if "male" in p:
        return "M"
    return "U"


def main():
    rows_fake = []
    real_by_id = {}  # id -> {id, gender, label} to deduplicate reals

    meta_files = sorted(FAKE_META_ROOT.rglob("meta.csv"))
    print(f"Found {len(meta_files)} meta.csv files")

    for meta_path in meta_files:
        try:
            df = pd.read_csv(meta_path, sep="|", dtype=str, on_bad_lines="skip")
        except Exception as e:
            print(f"Skip {meta_path}: {e}")
            continue
        if df.empty:
            continue
        # Expect columns: path, original_file, ...
        if "path" not in df.columns or "original_file" not in df.columns:
            print(f"Skip {meta_path}: missing path or original_file")
            continue

        for _, row in df.iterrows():
            path_val = row.get("path", "")
            orig_val = row.get("original_file", "")
            if pd.isna(path_val) or pd.isna(orig_val) or not str(path_val).strip():
                continue
            path_val = str(path_val).strip()
            orig_val = str(orig_val).strip()
            # meta path: ./fake/lang/tech/file.wav -> fake/lang/tech/file.wav
            rel_fake = path_val.removeprefix("./").lstrip("/")
            if not rel_fake.startswith("fake/"):
                continue
            # Processed paths
            fake_abs = PROCESSED_ROOT / rel_fake
            real_abs = PROCESSED_ROOT / "real" / orig_val
            gender = gender_from_original_file(orig_val)

            # Fake row (one per meta row)
            rows_fake.append({"ID": str(fake_abs), "gender": gender, "label": "fake"})

            # Real row (deduplicate by ID)
            real_id = str(real_abs)
            if real_id not in real_by_id:
                real_by_id[real_id] = {"ID": real_id, "gender": gender, "label": "real"}

    fake_df = pd.DataFrame(rows_fake)
    real_df = pd.DataFrame(list(real_by_id.values()))
    combined = pd.concat([fake_df, real_df], ignore_index=True)

    # MLAAD_Final must have the same row order as MLAAD_final: row i has ID = MLAAD_final.path[i]
    # Left join: for each row in MLAAD_final, output ID=path, gender/label from our data when matched
    reference_path = OUTPUT_DIR / "MLAAD_final.parquet"
    if reference_path.exists():
        ref_df = pd.read_parquet(reference_path)
        if "path" in ref_df.columns:
            # Left join: ref keeps order; for each ref.path we attach gender/label from combined
            combined = (
                ref_df[["path"]]
                .merge(combined, left_on="path", right_on="ID", how="left")
                .drop(columns=["ID"])
                .rename(columns={"path": "ID"})
            )
            combined = combined[["ID", "gender", "label"]]
            print(f"Ordered like {reference_path.name}: row i has ID = MLAAD_final.path[i]")
        else:
            print("Reference has no 'path' column, skipping reorder")
    else:
        print(f"No reference {reference_path.name}, skipping reorder")

    combined.to_parquet(OUTPUT_FILE, index=False)
    print(f"Written {OUTPUT_FILE}")
    print(f"  Fake: {len(fake_df)}")
    print(f"  Real (after dedup): {len(real_df)}")
    print(f"  Total: {len(combined)}")
    print("  Label counts:", combined["label"].value_counts().to_dict())
    print("  Gender counts:", combined["gender"].value_counts().to_dict())


if __name__ == "__main__":
    main()
