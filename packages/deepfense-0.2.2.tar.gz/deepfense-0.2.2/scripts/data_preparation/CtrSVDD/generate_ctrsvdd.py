"""
Generate CtrSVDD parquet files (train, dev, test) from protocol .txt files.

Inspired by:
  - /netscratch/yelkheir/DeepFense/Distillation/protocols/ctrsvdd (train.txt, dev.txt, test.txt)
  - /netscratch/yelkheir/DeepFense/Distillation/config.py (CtrSVDD paths)

Protocol format: 5 columns per line
  source  filename  placeholder  placeholder_or_attack  label
  e.g. CtrSVDD_0000 CtrSVDD_0000_T_0000000 - - bonafide
  e.g. CtrSVDD_0125_E_0000001 CtrSVDD_0125_E_0000001 _ _ spoof

Labels: bonafide | spoof
Audio: {filename}.flac under the corresponding set directory (train_set, dev_set, test_set).
"""
import argparse
import os
from pathlib import Path

import pandas as pd

# Default paths aligned with Distillation config.py CtrSVDD
DEFAULT_TRAIN_FLAC = "/ds/audio/CtrSVDD/train_set"
DEFAULT_DEV_FLAC = "/ds/audio/CtrSVDD/dev_set"
DEFAULT_EVAL_FLAC = "/ds-slt/audio/yelkheir/ctrSVDD/test_set"
DEFAULT_PROTOCOL_DIR = "/netscratch/yelkheir/DeepFense/Distillation/protocols/ctrsvdd"
SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT_DIR = str(SCRIPT_DIR)
DATASET_NAME = "CtrSVDD"


def process_protocol(txt_path: Path, flac_root: str, split_name: str) -> pd.DataFrame:
    """
    Read a CtrSVDD protocol file and build a dataframe with ID, path, label, dataset_name.

    Protocol: 5 columns — source, filename, col2, col3, label.
    """
    data = []
    with open(txt_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 5:
                continue
            audio_id = parts[1]
            label = parts[-1]
            if label not in ("bonafide", "spoof"):
                continue
            file_path = os.path.join(flac_root, f"{audio_id}.flac")
            data.append({
                "ID": audio_id,
                "path": file_path,
                "label": label,
                "dataset_name": DATASET_NAME,
            })
    return pd.DataFrame(data)


def main():
    parser = argparse.ArgumentParser(
        description="Generate CtrSVDD train/dev/test parquet files from protocol txt."
    )
    parser.add_argument(
        "--protocol_dir",
        type=str,
        default=DEFAULT_PROTOCOL_DIR,
        help="Directory containing train.txt, dev.txt, test.txt",
    )
    parser.add_argument(
        "--train_flac",
        type=str,
        default=DEFAULT_TRAIN_FLAC,
        help="Root directory for train_set (audio files)",
    )
    parser.add_argument(
        "--dev_flac",
        type=str,
        default=DEFAULT_DEV_FLAC,
        help="Root directory for dev_set (audio files)",
    )
    parser.add_argument(
        "--eval_flac",
        type=str,
        default=DEFAULT_EVAL_FLAC,
        help="Root directory for test_set (audio files)",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=DEFAULT_OUTPUT_DIR,
        help="Directory to write train.parquet, dev.parquet, test.parquet",
    )
    parser.add_argument(
        "--train_name",
        type=str,
        default=None,
        help="Output filename for train split (e.g. ctrsvdd_train.parquet)",
    )
    parser.add_argument(
        "--val_name",
        type=str,
        default=None,
        help="Output filename for dev split (e.g. ctrsvdd_val.parquet)",
    )
    parser.add_argument(
        "--test_name",
        type=str,
        default=None,
        help="Output filename for test split (e.g. ctrsvdd_test.parquet)",
    )
    args = parser.parse_args()

    protocol_dir = Path(args.protocol_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Optional naming for config compatibility: e.g. ctrsvdd_train.parquet, ctrsvdd_val.parquet
    split_output_names = {
        "train": getattr(args, "train_name", None) or "train.parquet",
        "dev": getattr(args, "val_name", None) or "dev.parquet",
        "test": getattr(args, "test_name", None) or "test.parquet",
    }
    splits = [
        ("train.txt", args.train_flac, "train"),
        ("dev.txt", args.dev_flac, "dev"),
        ("test.txt", args.eval_flac, "test"),
    ]

    for proto_name, flac_root, split_name in splits:
        txt_path = protocol_dir / proto_name
        if not txt_path.exists():
            print(f"Skip {split_name}: protocol not found {txt_path}")
            continue
        print(f"Processing {txt_path} with flac root {flac_root}...")
        df = process_protocol(txt_path, flac_root, split_name)
        out_name = split_output_names[split_name]
        out_path = output_dir / out_name
        df.to_parquet(out_path, index=False)
        print(f"  Saved {len(df)} rows to {out_path}")
        print(f"  Label distribution:\n{df['label'].value_counts()}\n")


if __name__ == "__main__":
    main()
