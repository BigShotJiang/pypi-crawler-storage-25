import pandas as pd
import os

parquet_path = '/netscratch/yelkheir/DeepFense/DeepFense/deepfense/config/parquets/asvspoof19_train.parquet'
try:
    df = pd.read_parquet(parquet_path)
    print(f"Columns in {os.path.basename(parquet_path)}:")
    print(df.columns.tolist())
    print("\nFirst 5 rows:")
    print(df.head())
except Exception as e:
    print(f"Error reading parquet: {e}")
