"""
Create all parquet files expected by batch_ALL config under deepfense/config/parquets/.

Expected paths (from config.yaml):
  train: ASV5/asvspoof5_train.parquet, asvspoof19_train.parquet, CtrSVDD/ctrsvdd_train.parquet,
         HABLA/habla_train.parquet, CodecFake/codecfake_train.parquet
  val:   asvspoof19_val.parquet, CtrSVDD/ctrsvdd_val.parquet

ADD23 and LibriSeVoc in config point to external /ds-slt/.../parquets/; we also run ADD23
so parquets/ADD23/add23_train.parquet exists if you switch config to local paths.
CodecFake generator only produces eval (no train); codecfake_train.parquet will be missing
unless you add train data.
"""
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
PARQUETS_ROOT = REPO_ROOT / "deepfense" / "config" / "parquets"
PREP = REPO_ROOT / "scripts" / "data_preparation"


def run(cmd, cwd=None):
    cwd = cwd or str(REPO_ROOT)
    print(f"\n>>> {' '.join(cmd)}\n")
    r = subprocess.run(cmd, cwd=cwd)
    if r.returncode != 0:
        print(f"Exit code {r.returncode}", file=sys.stderr)
        sys.exit(r.returncode)


def main():
    PARQUETS_ROOT.mkdir(parents=True, exist_ok=True)
    (PARQUETS_ROOT / "ASV5").mkdir(exist_ok=True)
    (PARQUETS_ROOT / "CtrSVDD").mkdir(exist_ok=True)
    (PARQUETS_ROOT / "HABLA").mkdir(exist_ok=True)
    (PARQUETS_ROOT / "CodecFake").mkdir(exist_ok=True)
    (PARQUETS_ROOT / "ADD23").mkdir(exist_ok=True)

    # ASV19 -> asvspoof19_train.parquet, asvspoof19_val.parquet (and test) in parquets root
    run([
        sys.executable,
        str(PREP / "generate_asv19.py"),
        "--output_dir", str(PARQUETS_ROOT),
    ])

    # CtrSVDD -> CtrSVDD/ctrsvdd_train.parquet, CtrSVDD/ctrsvdd_val.parquet, CtrSVDD/test.parquet
    run([
        sys.executable,
        str(PREP / "CtrSVDD" / "generate_ctrsvdd.py"),
        "--output_dir", str(PARQUETS_ROOT / "CtrSVDD"),
        "--train_name", "ctrsvdd_train.parquet",
        "--val_name", "ctrsvdd_val.parquet",
    ])

    # ASV5 -> ASV5/asvspoof5_train.parquet (script already writes to parquets/ASV5)
    run([sys.executable, str(PREP / "ASV5" / "generate_asv5.py")])

    # HABLA -> HABLA/habla_train.parquet
    run([
        sys.executable,
        str(PREP / "HABLA" / "generate_habla.py"),
        "--output_dir", str(PARQUETS_ROOT / "HABLA"),
    ])

    # ADD23 -> ADD23/add23_train.parquet (for local config; config may use external path)
    run([sys.executable, str(PREP / "ADD23" / "generate_add23.py")])

    # CodecFake -> CodecFake/codecfake_eval.parquet only (no train in dataset)
    run([sys.executable, str(PREP / "CodecFake" / "generate_codecfake.py")])

    print("\nDone. Created parquets under", PARQUETS_ROOT)
    print("Note: CodecFake has no separate train protocol; codecfake_train.parquet is written from eval data.")
    print("ADD23/LibriSeVoc in config use external paths; ADD23 was also written here.")


if __name__ == "__main__":
    main()
