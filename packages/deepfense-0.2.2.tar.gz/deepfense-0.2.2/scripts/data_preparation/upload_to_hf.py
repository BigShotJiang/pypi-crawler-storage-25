#!/usr/bin/env python3
"""
Script to upload gender-labeled parquet files to HuggingFace
Repository: DeepFense/Labeling (private)
Folder: gender
"""

import os
from huggingface_hub import HfApi, login

# Define the parquet files to upload (test/eval only)
PARQUET_FILES = [
    # ASVSpoof19 test
    "/netscratch/yelkheir/DeepFense/DeepFense/deepfense/config/parquets_gender/asvspoof19_test.parquet",
    
    # ASVSpoof21 eval
    "/netscratch/yelkheir/DeepFense/DeepFense/deepfense/config/parquets_gender/ASV21/asvspoof21_la_eval.parquet",
    
    # ASVSpoof5 test
    "/netscratch/yelkheir/DeepFense/DeepFense/deepfense/config/parquets_gender/ASV5/asvspoof5_test.parquet",
    
    # CodecFake eval
    "/netscratch/yelkheir/DeepFense/DeepFense/deepfense/config/parquets_gender/CodecFake/codecfake_eval.parquet",
    
    # L2Arctic (all bonafide)
    "/netscratch/yelkheir/DeepFense/DeepFense/deepfense/config/parquets_gender/L2Arctic/l2arctic.parquet",
    
    # Artie Bias Corpus
    "/netscratch/yelkheir/DeepFense/DeepFense/deepfense/config/parquets_gender/artie-bias-corpus/artie_bias.parquet",
    
    # MLAAD all eval only
    "/netscratch/yelkheir/DeepFense/DeepFense/deepfense/config/parquets_gender/MLAAD/mlaad_all_eval.parquet",
    # MLAAD_Final (ID, gender, label) – same order as MLAAD_final
    "/netscratch/yelkheir/DeepFense/DeepFense/scripts/data_preparation/MLAAD/MLAAD_Final.parquet",
]

REPO_ID = "DeepFense/Labeling"
FOLDER_NAME = "gender"

def main():
    # Login: use HF_TOKEN env var if set (e.g. HF_TOKEN=xxx python upload_to_hf.py)
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if token:
        login(token=token)
    api = HfApi()
    
    # Create repo if it doesn't exist (private)
    try:
        api.create_repo(
            repo_id=REPO_ID,
            repo_type="dataset",
            private=True,
            exist_ok=True
        )
        print(f"Repository {REPO_ID} ready (private)")
    except Exception as e:
        print(f"Note: {e}")
    
    print(f"Uploading to {REPO_ID}/{FOLDER_NAME}/")
    print(f"Files to upload: {len(PARQUET_FILES)}")
    print()
    
    for filepath in PARQUET_FILES:
        if not os.path.exists(filepath):
            print(f"WARNING: File not found: {filepath}")
            continue
        
        filename = os.path.basename(filepath)
        path_in_repo = f"{FOLDER_NAME}/{filename}"
        
        print(f"Uploading: {filename} -> {path_in_repo}")
        
        try:
            api.upload_file(
                path_or_fileobj=filepath,
                path_in_repo=path_in_repo,
                repo_id=REPO_ID,
                repo_type="dataset",
            )
            print(f"  ✓ Uploaded successfully")
        except Exception as e:
            print(f"  ✗ Error: {e}")
    
    print()
    print("Done!")

if __name__ == "__main__":
    main()
