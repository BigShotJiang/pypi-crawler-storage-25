import argparse
import os
from pathlib import Path

import pandas as pd

# Configuration
PROTOCOL_DIR = "/netscratch/yelkheir/DeepFense/Distillation/protocols/asv19"
DEFAULT_OUTPUT_DIR = "/netscratch/yelkheir/DeepFense/DeepFense/deepfense/config/parquets"

TRAIN_ROOT = "/ds/audio/LA_19/ASVspoof2019_LA_train/flac"
DEV_ROOT = "/ds/audio/LA_19/ASVspoof2019_LA_dev/flac"
EVAL_ROOT = "/ds/audio/LA_19/ASVspoof2019_LA_eval/flac"


def process_protocol(txt_file, root_dir, output_path, dataset_name="ASVSpoof19"):
    print(f"Processing {txt_file}...")
    data = []
    with open(txt_file, "r") as f:
        for line in f:
            parts = line.strip().split()
            if not parts:
                continue
            audio_id = parts[1]
            label = parts[-1]
            if label not in ["bonafide", "spoof"]:
                continue
            file_path = os.path.join(root_dir, f"{audio_id}.flac")
            data.append({
                "ID": audio_id,
                "path": file_path,
                "label": label,
                "dataset_name": dataset_name,
            })
    df = pd.DataFrame(data)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(output_path, index=False)
    print(f"Saved {len(df)} rows to {output_path}")
    return df


def main():
    parser = argparse.ArgumentParser(description="Generate ASVspoof19 train/val/test parquets.")
    parser.add_argument(
        "--output_dir",
        type=str,
        default=DEFAULT_OUTPUT_DIR,
        help="Directory for asvspoof19_train.parquet, asvspoof19_val.parquet, asvspoof19_test.parquet",
    )
    parser.add_argument("--protocol_dir", type=str, default=PROTOCOL_DIR)
    args = parser.parse_args()
    out = Path(args.output_dir)
    proto = Path(args.protocol_dir)

    process_protocol(
        proto / "asvspoof19.txt",
        TRAIN_ROOT,
        out / "asvspoof19_train.parquet",
    )
    process_protocol(
        proto / "asvspoof19.dev.txt",
        DEV_ROOT,
        out / "asvspoof19_val.parquet",
    )
    process_protocol(
        proto / "asvspoof19.eval.txt",
        EVAL_ROOT,
        out / "asvspoof19_test.parquet",
    )


if __name__ == "__main__":
    main()

