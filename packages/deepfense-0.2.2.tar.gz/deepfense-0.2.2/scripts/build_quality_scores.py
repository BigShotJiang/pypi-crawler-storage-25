#!/usr/bin/env python3
"""
Build quality CSV results for selected DeepFense models.

Models:
- 8: 4 frontends × AASIST × {ASV19, CodecFake} (Seed2)
- +1: Wav2Vec2 + MLP + CodecFake + Seed2
- +1: Wav2Vec2 + TCM + Habla (ASV19 Wav2Vec2 TCM Seed2, Habla test set)

For each model we merge predictions with quality metadata where available and
write structured CSVs under quality_results/ (asvspoof21_la_eval for all,
plus primary test set: asvspoof2019_la_eval for ASV19, codecfake_eval for CodecFake).
"""

import os
import pandas as pd
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PREDICTION_SCORES = SCRIPT_DIR / "prediction_scores"
LABELING = SCRIPT_DIR / "Labeling" / "quality"
OUT_DIR = SCRIPT_DIR / "quality_results"

# Model configs: (train_set, model_folder_name, primary_test_set)
# primary_test_set: 'asvspoof2019_la_eval' | 'codecfake_eval' | 'habla_test' (habla has no quality metadata)
MODELS = [
    # 4 frontends × AASIST × ASV19
    ("ASV19", "DeepFense_ASV19_EAT_AASIST_NoAug_Seed2", "asvspoof2019_la_eval"),
    ("ASV19", "DeepFense_ASV19_Hubert_AASIST_NoAug_Seed2", "asvspoof2019_la_eval"),
    ("ASV19", "DeepFense_ASV19_Wav2Vec2_AASIST_NoAug_Seed2", "asvspoof2019_la_eval"),
    ("ASV19", "DeepFense_ASV19_WavLM_AASIST_NoAug_Seed2", "asvspoof2019_la_eval"),
    # 4 frontends × AASIST × CodecFake
    ("CodecFake", "DeepFense_CodecFake_EAT_AASIST_NoAug_Seed2", "codecfake_eval"),
    ("CodecFake", "DeepFense_CodecFake_Hubert_AASIST_NoAug_Seed2", "codecfake_eval"),
    ("CodecFake", "DeepFense_CodecFake_Wav2Vec2_AASIST_NoAug_Seed2", "codecfake_eval"),
    ("CodecFake", "DeepFense_CodecFake_WavLM_AASIST_NoAug_Seed2", "codecfake_eval"),
    # Wav2Vec2 + MLP + CodecFake + Seed2
    ("CodecFake", "DeepFense_CodecFake_Wav2Vec2_MLP_NoAug_Seed2", "codecfake_eval"),
    # Wav2Vec2 + TCM + Habla (ASV19-trained, Habla test; no quality for Habla)
    ("ASV19", "DeepFense_ASV19_Wav2Vec2_TCM_NoAug_Seed2", "habla_test"),
]

# Quality metadata file per test set (file_id column used for merge)
# DF21 = asvspoof21_df_eval, ASV5 = asvspoof5_test, MLAAD_all uses MLAAD_final predictions
QUALITY_FILES = {
    "asvspoof21_la_eval": LABELING / "ASV21LA_eval_quality_metadata.csv",
    "asvspoof2019_la_eval": LABELING / "ASV19LA_eval_quality_metadata.csv",
    "codecfake_eval": LABELING / "CodecFake_eval_quality_metadata.csv",
    "asvspoof21_df_eval": LABELING / "ASV21DF_eval_quality_metadata.csv",
    "asvspoof5_test": LABELING / "ASV5_eval_quality_metadata.csv",
    "mlaad_all_eval": LABELING / "MLAAD_all_eval_quality_metadata.csv",
}
# For mlaad_all_eval we use MLAAD_final prediction folder/file (same file_id = stem)
PREDICTION_MAP = {
    "mlaad_all_eval": ("MLAAD_final", "MLAAD_final_predictions.txt"),
}


def load_predictions(pred_path: Path, score_prefix: str = "score") -> pd.DataFrame:
    """Load predictions CSV (ID_audio, label, score_class0, score_class1)."""
    df = pd.read_csv(pred_path)
    df = df.rename(columns={
        "ID_audio": "file_id",
        "label": f"{score_prefix}_pred_label",
        "score_class0": f"{score_prefix}_class0",
        "score_class1": f"{score_prefix}_class1",
    })
    return df


def load_quality(quality_path: Path) -> pd.DataFrame:
    """Load quality metadata CSV."""
    return pd.read_csv(quality_path, low_memory=False)


def merge_and_save(pred_df: pd.DataFrame, quality_df: pd.DataFrame, out_path: Path) -> None:
    """Merge predictions with quality on file_id (pred columns already prefixed)."""
    merged = quality_df.merge(pred_df, on="file_id", how="inner")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(out_path, index=False)


def main():
    # Load quality metadata once per dataset
    quality_dfs = {}
    for name, p in QUALITY_FILES.items():
        if p.exists():
            quality_dfs[name] = load_quality(p)
        else:
            quality_dfs[name] = None

    for train_set, model_folder, primary_test in MODELS:
        base = PREDICTION_SCORES / train_set / model_folder
        short_name = model_folder  # e.g. DeepFense_ASV19_EAT_AASIST_NoAug_Seed2

        # 1) asvspoof21_la_eval: all models have this; merge with ASV21LA quality
        pred_21 = base / f"{model_folder}_asvspoof21_la_eval" / "results" / "predictions" / "asvspoof21_la_eval_predictions.txt"
        if pred_21.exists() and quality_dfs.get("asvspoof21_la_eval") is not None:
            df_pred = load_predictions(pred_21, score_prefix="asvspoof21_la_eval")
            out_path = OUT_DIR / "asvspoof21_la_eval" / f"{short_name}.csv"
            merge_and_save(df_pred, quality_dfs["asvspoof21_la_eval"].copy(), out_path)
            print(f"Wrote {out_path}")

        # 2) Extra quality sets: ASV19, CodecFake, DF21, ASV5, MLAAD_all (LA21 in block 1); habla in 2b
        for test_set in ("asvspoof2019_la_eval", "codecfake_eval", "asvspoof21_df_eval", "asvspoof5_test", "mlaad_all_eval"):
            if quality_dfs.get(test_set) is None:
                continue
            if test_set in PREDICTION_MAP:
                pred_folder, pred_fname = PREDICTION_MAP[test_set]
                pred_path = base / f"{model_folder}_{pred_folder}" / "results" / "predictions" / pred_fname
            else:
                pred_path = base / f"{model_folder}_{test_set}" / "results" / "predictions" / f"{test_set}_predictions.txt"
            if not pred_path.exists():
                continue
            df_extra = load_predictions(pred_path, score_prefix=test_set)
            if test_set == "mlaad_all_eval":
                df_extra = df_extra.drop_duplicates(subset=["file_id"], keep="first")
            out_path = OUT_DIR / test_set / f"{short_name}.csv"
            merge_and_save(df_extra, quality_dfs[test_set].copy(), out_path)
            print(f"Wrote {out_path}")

        # 2b) habla_test: no quality metadata; write predictions for every model that has them
        habla_pred = base / f"{model_folder}_habla_test" / "results" / "predictions" / "habla_test_predictions.txt"
        if habla_pred.exists():
            df_habla = load_predictions(habla_pred, score_prefix="habla_test")
            out_path = OUT_DIR / "habla_test" / f"{short_name}.csv"
            out_path.parent.mkdir(parents=True, exist_ok=True)
            df_habla.to_csv(out_path, index=False)
            print(f"Wrote {out_path} (habla_test, predictions only)")

    print(f"\nDone. Results under {OUT_DIR}")


if __name__ == "__main__":
    main()
