"""
wavesimpro - A Python client library for RayfosJobServer and RayfosMachineService

This package provides a simple interface to interact with RayfosJobServer,
supporting both cloud and local deployment modes, as well as direct interaction
with RayfosMachineService via its REST API.
"""

from .client import RayfosClient
from .config import ClientConfig
from .exceptions import (
    RayfosAPIError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
    ServerError,
    ConfigurationError,
)
from .binary_utils import (
    upload_array_as_binary,
    upload_array_as_binary_zipped,
    upload_source_field_as_binary,
    upload_source_field_as_binary_zipped,
    read_binary_field,
    write_array_to_binary,
    write_monitor_binary,
    read_monitor_binary,
    is_rmon_file,
    VoxelDataFormat,
)
from .validate import validate_parameters, ParameterValidationError
from .execute import execute_via_api
from .simulate import simulate, simulate_pro, configure
from .json_helper import (
    create_simulation_domain,
    create_stl_primitive,
    create_box_primitive,
    create_medium,
    create_point_source,
    create_plane_wave_source,
    create_gaussian_beam_source,
    create_voxels_model_primitive,
    create_custom_field_source,
    create_custom_from_file_source,
    create_field_monitor,
    create_flux_monitor,
    create_permittivity_monitor,
    create_wavesim_properties,
    parse_progress_data,
)

__version__ = "0.12.0"
__all__ = [
    # Client
    "RayfosClient",
    "ClientConfig",
    # Exceptions
    "RayfosAPIError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "ConfigurationError",
    "ParameterValidationError",
    # Binary utilities
    "upload_array_as_binary",
    "upload_array_as_binary_zipped",
    "upload_source_field_as_binary",
    "upload_source_field_as_binary_zipped",
    "read_binary_field",
    "write_array_to_binary",
    "write_monitor_binary",
    "read_monitor_binary",
    "is_rmon_file",
    "VoxelDataFormat",
    # Validation
    "validate_parameters",
    # High-level execution
    "execute_via_api",
    "simulate",
    "configure",
    # JSON helpers
    "create_simulation_domain",
    "create_stl_primitive",
    "create_box_primitive",
    "create_medium",
    "create_point_source",
    "create_plane_wave_source",
    "create_gaussian_beam_source",
    "create_voxels_model_primitive",
    "create_custom_field_source",
    "create_custom_from_file_source",
    "create_field_monitor",
    "create_flux_monitor",
    "create_permittivity_monitor",
    "create_wavesim_properties",
    "parse_progress_data",
]
