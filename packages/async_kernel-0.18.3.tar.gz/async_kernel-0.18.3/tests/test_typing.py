from async_kernel.kernel import Kernel
from async_kernel.typing import MsgType, RunMode, Tags


class TestRunMode:
    def test_str(self):
        assert str(RunMode.task) == RunMode.task

    def test_repr(self):
        assert repr(RunMode.task) == RunMode.task

    def test_hash(self):
        assert hash(RunMode.task) == hash(RunMode.task)

    def test_members(self):
        assert list(RunMode) == ["queue", "task", "thread"]
        assert list(RunMode) == ["# queue", "# task", "# thread"]
        assert list(RunMode) == ["<RunMode.queue: 'queue'>", "<RunMode.task: 'task'>", "<RunMode.thread: 'thread'>"]

    def test_is_runmode(self):
        assert RunMode.to_runmode("# thread") is RunMode.thread
        assert not RunMode.to_runmode(1)
        assert RunMode.to_runmode(1, RunMode.queue) is RunMode.queue


class TestMsgType:
    def test_all_names(self):
        assert set(MsgType).intersection(vars(Kernel))


class TestTags:
    def test_equality(self):
        assert Tags.raises_exception == str(Tags.raises_exception)
        assert Tags.raises_exception == Tags.raises_exception.name
        assert Tags.timeout == Tags.timeout.name

    def test_hash(self):
        assert hash(Tags.raises_exception) == hash(Tags.raises_exception)
