from __future__ import annotations

import enum
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any, Generic, Literal, NotRequired, ParamSpec, Self, TypedDict, TypeVar

from typing_extensions import Sentinel, get_annotations, override

if TYPE_CHECKING:
    import datetime
    import logging

    import zmq


__all__ = [
    "Backend",
    "CallerCreateOptions",
    "CallerState",
    "Channel",
    "Content",
    "DebugMessage",
    "ExecuteContent",
    "FixedCreate",
    "FixedCreated",
    "HandlerType",
    "Hosts",
    "Job",
    "Message",
    "MsgHeader",
    "MsgType",
    "NoValue",
    "RunMode",
    "RunSettings",
    "Tags",
]

NoValue = Sentinel("NoValue")
"A sentinel to indicate a value has not been provided."


S = TypeVar("S")
T = TypeVar("T")
D = TypeVar("D", bound=dict)
P = ParamSpec("P")


class Backend(enum.StrEnum):
    "An enum of library names corresponding to anyio."

    asyncio = "asyncio"
    "An asyncio style event loop."

    trio = "trio"
    "A trio style event loop."


class Hosts(enum.StrEnum):
    "An enum of event loop names that available to start using [detail][async_kernel.event_loop.run.run]."

    tk = "tk"
    "An eventloop for [tkinter][]."

    qt = "qt"
    "An event loop for [Qt](https://wiki.qt.io/Qt_for_Python)."

    custom = "custom"
    "A custom host."


class Channel(enum.StrEnum):
    "An enum of channel names [Ref](https://jupyter-client.readthedocs.io/en/stable/messaging.html#introduction)."

    heartbeat = "hb"
    ""
    shell = "shell"
    ""
    stdin = "stdin"
    ""
    control = "control"
    ""
    iopub = "iopub"
    ""


class RunMode(enum.StrEnum):
    """
    An Enum of the run modes available for handling `execute_request` messages.

    Cell overrides:
        The user can also specify an execution mode in execute requests.

        Top line comment:
            ```python
            # task
            ```
            or

            ```python
            # thread
            ```
    """

    @override
    def __str__(self):
        return f"# {self.name}"

    @override
    def __eq__(self, value: object, /) -> bool:
        return str(value) in {self.name, str(self), repr(self)}

    @override
    def __hash__(self) -> int:
        return hash(self.name)

    @classmethod
    def to_runmode(cls, value: Any, default: T = None, /) -> Self | T | CallerCreateOptions:
        """
        Converts value to `Runmode`, `CallerCreateOptions` or  default where it is not possible.

        `CallerCreateOptions` will only return when a string is passed specifying a thread and options.

        Example:
            `value = "# thread name='My exeecutor' backend=trio`
        """
        try:
            return cls(value)
        except ValueError:
            if isinstance(value, str):
                if value.startswith(("# ", "##")):
                    return cls.to_runmode(value[2:].strip(), default)
                if value.startswith("thread"):
                    return cls.line_to_options(value.removeprefix("thread"))
            return default

    @classmethod
    def line_to_options(cls, line: str, /) -> CallerCreateOptions:
        "Convert the line string to CallerCreateOptions."
        import shlex  # noqa: PLC0415

        items = CallerCreateOptions()
        for v in shlex.split(line):
            k, val = v.split("=", maxsplit=1)
            try:
                items[k] = eval(val)
            except Exception:
                items[k] = val
        if items and not items.get("name"):
            msg = "'name' must be specified when providing settings!"
            raise ValueError(msg)
        if invalid := set(items).difference(get_annotations(CallerCreateOptions)):
            msg = f"One or more invalid options found! valid={list(get_annotations(CallerCreateOptions))} invalid={list(invalid)}"
            raise ValueError(msg)
        return items

    queue = "queue"
    "Run the message handler using [async_kernel.caller.Caller.queue_call][]."

    task = "task"
    "Run the message handler using [async_kernel.caller.Caller.call_soon][]."

    thread = "thread"
    "Run the message handler using [async_kernel.caller.Caller.to_thread][]."


class MsgType(enum.StrEnum):
    """
    An enumeration of Message `msg_type` for [shell and control messages]( https://jupyter-client.readthedocs.io/en/stable/messaging.html#messages-on-the-shell-router-dealer-channel).

    Some message types are on the [control channel](https://jupyter-client.readthedocs.io/en/stable/messaging.html#messages-on-the-control-router-dealer-channel) only.
    """

    kernel_info_request = "kernel_info_request"
    "[async_kernel.kernel.Kernel.kernel_info_request][]"

    comm_info_request = "comm_info_request"
    "[async_kernel.kernel.Kernel.comm_info_request][]"

    execute_request = "execute_request"
    "[async_kernel.kernel.Kernel.execute_request][]"

    complete_request = "complete_request"
    "[async_kernel.kernel.Kernel.complete_request][]"

    is_complete_request = "is_complete_request"
    "[async_kernel.kernel.Kernel.is_complete_request][]"

    inspect_request = "inspect_request"
    "[async_kernel.kernel.Kernel.inspect_request][]"

    history_request = "history_request"
    "[async_kernel.kernel.Kernel.history_request][]"

    comm_open = "comm_open"
    "[async_kernel.kernel.Kernel.comm_open][]"

    comm_msg = "comm_msg"
    "[async_kernel.kernel.Kernel.comm_msg][]"

    comm_close = "comm_close"
    "[async_kernel.kernel.Kernel.comm_close][]"

    # Control
    interrupt_request = "interrupt_request"
    "[async_kernel.kernel.Kernel.interrupt_request][] (control channel only)"

    shutdown_request = "shutdown_request"
    "[async_kernel.kernel.Kernel.shutdown_request][] (control channel only)"

    debug_request = "debug_request"
    "[async_kernel.kernel.Kernel.debug_request][] (control channel only)"

    create_subshell_request = "create_subshell_request"
    "[async_kernel.kernel.Kernel.create_subshell_request][] (control channel only)"

    delete_subshell_request = "delete_subshell_request"
    "[async_kernel.kernel.Kernel.delete_subshell_request][] (control channel only)"

    list_subshell_request = "list_subshell_request"
    "[async_kernel.kernel.Kernel.debug_request][] (control channel only)"


class Tags(enum.StrEnum):
    """
    Tags recognised by the [shell][async_kernel.asyncshell.AsyncInteractiveShell].

    Info:
        Tags are can be added per cell.

        - Jupyter: via the [right side bar](https://jupyterlab.readthedocs.io/en/stable/user/interface.html#left-and-right-sidebar).
        - VS Code: via [Jupyter variables explorer](https://code.visualstudio.com/docs/python/jupyter-support-py#_variables-explorer-and-data-viewer)
    """

    @override
    def __eq__(self, value: object, /) -> bool:
        return str(value).replace("-", "_").split("=")[0] == self.name

    @override
    def __hash__(self) -> int:
        return hash(self.name)

    @classmethod
    def get_bool(cls, value: str | Tags, default: bool = True) -> bool:
        try:
            return value.split("=")[1].lower() == "true"
        except Exception:
            return default

    @classmethod
    def get_float(cls, value: str | Tags, default: float = 0.0) -> float:
        try:
            return float(value.split("=")[1])
        except Exception:
            return default

    @classmethod
    def get_string(cls, value: str | Tags, default: str = "") -> str:
        try:
            return value.split("=")[1].strip()
        except Exception:
            return default

    raises_exception = "raises-exception"
    """
    Indicates the cell should expect an exception to be raised. 
    
    Notes:
        - When an exception is raised, stop_on_error is False/
        - When an exception is **not** raised an exception will be raise and stop_on_error is True.
    """

    stop_on_error = "stop-on-error"
    """
    Override `stop_on_error`.

    Examples:

        - True
            - stop_on_error=true
            - stop_on_error=True
        - False
            - stop_on_error=False
    """

    timeout = "timeout="
    """
    Specify a timeout in seconds for code execution to complete.

    Examples:

        - timeout=0.0 (no timeout)
        - timeout=0.1 (100 ms)
    """


class CallerState(enum.Enum):
    "The State of a [async_kernel.caller.Caller][]."

    initial = enum.auto()
    start_sync = enum.auto()
    running = enum.auto()
    stopping = enum.auto()
    stopped = enum.auto()


class MsgHeader(TypedDict):
    "A [message header](https://jupyter-client.readthedocs.io/en/stable/messaging.html#message-header)."

    msg_id: str
    ""
    session: str
    ""
    username: str
    ""
    date: str | datetime.datetime
    ""
    msg_type: MsgType | str
    ""
    version: str
    ""
    subshell_id: NotRequired[str | None]
    ""


class Message(TypedDict, Generic[T]):
    "A [message](https://jupyter-client.readthedocs.io/en/stable/messaging.html#general-message-format)."

    channel: Channel
    "The channel of the message."

    header: MsgHeader
    "[ref](https://jupyter-client.readthedocs.io/en/stable/messaging.html#message-header)"

    parent_header: MsgHeader | None
    "[ref](https://jupyter-client.readthedocs.io/en/stable/messaging.html#parent-header)"

    metadata: dict[str, Any]
    "[ref](https://jupyter-client.readthedocs.io/en/stable/messaging.html#metadata)"

    content: T | Content
    """[ref](https://jupyter-client.readthedocs.io/en/stable/messaging.html#metadata)
    
    See also:
        - [ExecuteContent][]
    """
    buffers: list[bytearray | bytes]
    ""


class Job(TypedDict, Generic[T]):
    "A `Message` bundle."

    msg: Message[T]
    "The message received over the socket."

    ident: bytes | list[bytes]
    "The ident associated with the message and its origin."

    received_time: float
    "The time the message was received."


class ExecuteContent(TypedDict):
    "[Ref](https://jupyter-client.readthedocs.io/en/stable/messaging.html#execute)."

    code: str
    "The code to execute."
    silent: bool
    ""
    store_history: bool
    ""
    user_expressions: dict[str, str]
    ""
    allow_stdin: bool
    ""
    stop_on_error: bool
    ""


class FixedCreate(TypedDict, Generic[S]):
    "A TypedDict relevant to Fixed."

    name: str
    ""
    owner: S
    ""


class FixedCreated(TypedDict, Generic[S, T]):
    "A TypedDict relevant to Fixed."

    name: str
    ""
    owner: S
    ""
    obj: T
    ""


class RunSettings(TypedDict):
    "A dict of settings to use with [async_kernel.event_loop.run][]."

    backend: NotRequired[Backend | Literal["asyncio", "trio"]]
    "The backend to use for the caller."

    backend_options: NotRequired[dict | None]
    "The backend options to specify for [anyio.run][] (or `start_guest_run` when a loop is specified)."

    host: NotRequired[Hosts | None | Literal["tk", "qt"]]
    "The type of host where the backend will run."

    "Options to use when starting the host."
    host_options: NotRequired[dict | None]


class CallerCreateOptions(RunSettings):
    "Options to use when creating an instance of a [Caller][async_kernel.caller.Caller]."

    name: NotRequired[str]
    "The name for the new caller instance."

    log: NotRequired[logging.LoggerAdapter]
    "A logging adapter to use for the caller."

    "Options to pass when calling [anyio.run][]."
    protected: NotRequired[bool]
    "The caller should be protected against accidental closure (default=`False`)."

    zmq_context: NotRequired[zmq.Context[Any] | None]
    "A zmq Context to use."

    no_debug: NotRequired[bool]
    "Disable debugpy in the thread if a new thread is created."


DebugMessage = dict[str, Any]
"""
A TypeAlias for a debug message.
"""

Content = dict[str, Any]
"""
A TypeAlias for the content in `Message`.

Notes:
    - The content of a message handler can provide 'buffers'. When present, 
        the buffers are extracted from dict and handled separately by the interface.
"""

HandlerType = Callable[[Job], Awaitable[Content | None]]
"""
A TypeAlias for the handler of message requests.
"""
