"""OntologyGraph — manages entity type definitions in a separate FalkorDB graph.

Stores entity types with three-tier status: seed → provisional → confirmed.
Separate from the data graph so ontology reads never contend with data writes.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from typing_extensions import deprecated

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# SELF-IMPROVE-9 S01/S0M: source-tiered confidence ceiling for ruler patterns.
# Keyed off the source strings actually written in-tree (Codex R2/C7):
#   worker → "llm_discovery"; PatternManager default → "code_index";
#   pack install → "seed-pack"; built-in seeds → "seed"; spaCy → "entity_ruler";
#   learned ruler → "entity_ruler_learned"; manual NER correction → "manual_ner".
_USER_SOURCES = frozenset({"user", "manual_ner"})
_SEED_SOURCES = frozenset({"seed", "seed-pack"})
_USER_CONFIDENCE_CAP = 1.0
_SEED_CONFIDENCE_CAP = 0.95
_RULER_CONFIDENCE_CAP = 0.85  # auto-learned/extracted — never fully certain
_unknown_source_warned: set[str] = set()

# SELF-IMPROVE-9 S01: monotonic bounded reinforcement (replaces (existing+new)/2).
# Each MATCH moves confidence a fixed fraction of the remaining distance to the
# source cap: c <- c + alpha*(cap - c). Strictly increasing, asymptotic to cap,
# never exceeds it. _CONFIDENCE_BASE is the assumed prior when a legacy node has
# no stored confidence (so the first reinforcement still climbs, not resets).
_CONFIDENCE_ALPHA = 0.3
_CONFIDENCE_BASE = 0.5


def _cap_for_source(source: str | None) -> float:
    """Maximum confidence an auto-written pattern of this source may reach.

    User-curated patterns are trusted (1.0); seeds are near-certain (0.95);
    everything auto-discovered is capped at 0.85 so reinforcement can climb
    but never assert false certainty. Unknown sources fall back to the ruler
    cap (safe default) and WARN once — no silent miscategorisation.
    """
    s = (source or "").strip()
    if s in _USER_SOURCES:
        return _USER_CONFIDENCE_CAP
    if s in _SEED_SOURCES:
        return _SEED_CONFIDENCE_CAP
    if s in {"llm_discovery", "code_index", "entity_ruler", "entity_ruler_learned", "bootstrap_scan"}:
        return _RULER_CONFIDENCE_CAP
    if s and s not in _unknown_source_warned:
        logger.warning("Unknown pattern source %r — applying ruler cap %.2f (SELF-IMPROVE-9)", s, _RULER_CONFIDENCE_CAP)
        _unknown_source_warned.add(s)
    return _RULER_CONFIDENCE_CAP


# Seed entity types shipped with SmartMemory
SEED_TYPES: List[str] = [
    "Person",
    "Organization",
    "Technology",
    "Concept",
    "Event",
    "Activity",  # CORE-EVENT-EXTRACT-1 — common-noun activities, hobbies, outings
    "Location",
    "Document",
    "Tool",
    "Skill",
    "Decision",
    "Claim",
    "Action",
    "Metric",
    "Process",
    "Agent",  # CORE-AGENT-1 — AI agent entity
    "Environment",  # CORE-AGENT-1 — agent operating context
]

VALID_STATUSES = {"seed", "provisional", "confirmed", "rejected"}


# Seed relation types derived from canonical relation vocabulary (ONTO-PUB-3)
def _load_seed_relation_types() -> list[str]:
    try:
        from smartmemory.relations.schema import CANONICAL_RELATION_TYPES

        return list(CANONICAL_RELATION_TYPES.keys())
    except ImportError:
        return []


SEED_RELATION_TYPES: list[str] = _load_seed_relation_types()


class OntologyGraph:
    """Manage entity type definitions in a dedicated FalkorDB graph.

    The ontology graph is named ``ws_{workspace_id}_ontology`` and stores
    ``EntityType`` nodes with ``name`` and ``status`` properties.

    Usage::

        og = OntologyGraph(workspace_id="acme")
        og.seed_types()   # idempotent — seeds 16 base types
        og.add_provisional("Metric")
        og.promote("Metric")
        types = og.get_entity_types()
    """

    def __init__(self, workspace_id: str = "default", backend=None):
        """
        Args:
            workspace_id: Workspace identifier for graph naming.
            backend: Optional FalkorDB backend instance. If None, resolved from config.
        """
        self.workspace_id = workspace_id
        self._graph_name = f"ws_{workspace_id}_ontology"
        self._backend = backend

    def _get_backend(self):
        """Lazy-load or return injected backend."""
        if self._backend is not None:
            return self._backend
        try:
            from smartmemory.graph.backends.falkordb import FalkorDBBackend

            self._backend = FalkorDBBackend(graph_name=self._graph_name)
            return self._backend
        except Exception as e:
            logger.error("Failed to initialize ontology graph backend: %s", e)
            raise

    def seed_types(self, types: Optional[List[str]] = None) -> int:
        """Seed initial entity types with status='seed'. Idempotent.

        Returns:
            Number of types actually created (skips existing).
        """
        types_to_seed = types or SEED_TYPES
        backend = self._get_backend()
        created = 0

        for type_name in types_to_seed:
            try:
                existing = self._query_type(backend, type_name)
                if existing:
                    continue
                self._create_type(backend, type_name, "seed")
                created += 1
            except Exception as e:
                logger.warning("Failed to seed type '%s': %s", type_name, e)

        logger.info("Seeded %d/%d entity types in %s", created, len(types_to_seed), self._graph_name)
        return created

    def get_entity_types(self) -> List[Dict[str, Any]]:
        """Return all entity types with their status."""
        backend = self._get_backend()
        try:
            result = backend.query(
                "MATCH (t:OntologyType) WHERE NOT t:Concept RETURN t.name AS name, t.status AS status ORDER BY t.name",
                graph_name=self._graph_name,
            )
            return [{"name": row[0], "status": row[1]} for row in (result or [])]
        except Exception as e:
            logger.warning("Failed to query entity types: %s", e)
            return []

    def get_type_status(self, name: str) -> Optional[str]:
        """Return the status of a type, or None if not found."""
        backend = self._get_backend()
        existing = self._query_type(backend, name)
        if existing:
            return existing[0][1]  # status column
        return None

    def add_provisional(self, name: str) -> bool:
        """Add a new type with status='provisional'. No-op if already exists.

        Returns:
            True if created, False if already existed.
        """
        backend = self._get_backend()
        existing = self._query_type(backend, name)
        if existing:
            return False
        self._create_type(backend, name, "provisional")
        return True

    def promote(self, name: str) -> bool:
        """Promote a type to 'confirmed'. Returns False if type not found."""
        backend = self._get_backend()
        try:
            backend.query(
                "MATCH (t:OntologyType {name: $name}) WHERE NOT t:Concept SET t.status = 'confirmed'",
                params={"name": name},
                graph_name=self._graph_name,
            )
            return True
        except Exception as e:
            logger.warning("Failed to promote type '%s': %s", name, e)
            return False

    def reject(self, name: str) -> bool:
        """Reject a type — sets status to 'rejected'. Returns False if type not found."""
        backend = self._get_backend()
        try:
            backend.query(
                "MATCH (t:OntologyType {name: $name}) WHERE NOT t:Concept SET t.status = 'rejected'",
                params={"name": name},
                graph_name=self._graph_name,
            )
            return True
        except Exception as e:
            logger.warning("Failed to reject type '%s': %s", name, e)
            return False

    # ------------------------------------------------------------------ #
    # Frequency tracking & entity patterns (Phase 4)
    # ------------------------------------------------------------------ #

    def increment_frequency(self, name: str, confidence: float) -> None:
        """Atomically increment type frequency and update running avg confidence."""
        backend = self._get_backend()
        try:
            backend.query(
                # Dual-label MERGE — matches the ONTO-PATTERN-MIGRATE-1 pattern at
                # line 409 so this write is forward-compatible with Task 11 (legacy
                # :EntityType label drop). Single-label MERGE here would leave new
                # nodes invisible to ontology_graph.py readers that match :OntologyType.
                "MERGE (t:EntityType:OntologyType {name: $name}) "
                "SET t.frequency = COALESCE(t.frequency, 0) + 1, "
                "t.avg_confidence = (COALESCE(t.avg_confidence, 0) * COALESCE(t.frequency, 0) + $conf) "
                "/ (COALESCE(t.frequency, 0) + 1)",
                params={"name": name, "conf": confidence},
                graph_name=self._graph_name,
            )
        except Exception as e:
            logger.warning("Failed to increment frequency for '%s': %s", name, e)

    def get_frequency(self, name: str) -> int:
        """Return the frequency count for a type, or 0 if not found."""
        backend = self._get_backend()
        try:
            result = backend.query(
                "MATCH (t:OntologyType {name: $name}) WHERE NOT t:Concept RETURN COALESCE(t.frequency, 0)",
                params={"name": name},
                graph_name=self._graph_name,
            )
            if result and result[0]:
                return int(result[0][0])
        except Exception as e:
            logger.warning("Failed to get frequency for '%s': %s", name, e)
        return 0

    def get_all_frequencies(self) -> Dict[str, int]:
        """Return frequency counts for all types in a single query."""
        backend = self._get_backend()
        try:
            result = backend.query(
                "MATCH (t:OntologyType) WHERE NOT t:Concept RETURN t.name, COALESCE(t.frequency, 0)",
                graph_name=self._graph_name,
            )
            return {row[0]: int(row[1]) for row in (result or [])}
        except Exception as e:
            logger.warning("Failed to get all frequencies: %s", e)
            return {}

    def get_type_assignments(self, entity_name: str) -> List[Dict]:
        """Query EntityPattern nodes for this entity name, return [{type, count}]."""
        backend = self._get_backend()
        try:
            result = backend.query(
                "MATCH (p:EntityPattern {name: $name})-[:IS_INSTANCE_OF]->(t:OntologyType) "
                "WHERE NOT t:Concept "
                "RETURN t.name AS type, COALESCE(p.count, 1) AS count",
                params={"name": entity_name},
                graph_name=self._graph_name,
            )
            return [{"type": row[0], "count": int(row[1])} for row in (result or [])]
        except Exception as e:
            logger.warning("Failed to get type assignments for '%s': %s", entity_name, e)
            return []

    @deprecated(
        "Use _upsert_inline_ontology_pattern() — writes dual-labelled "
        ":EntityType:OntologyType parent. Removed in ONTO-RECONCILE-1 Task 11."
    )
    def add_entity_pattern(
        self,
        name: str,
        label: str,
        confidence: float,
        workspace_id: str | None = None,
        is_global: bool = False,
        source: str = "llm_discovery",
        initial_count: int = 1,
        registry_id: str | None = None,
    ) -> bool:
        """Create an EntityPattern node linked to its EntityType via :IS_INSTANCE_OF.

        Args:
            initial_count: Starting count for new patterns. Use 2 for AST-validated
                code patterns to bypass the ``count >= 2`` discovery threshold in
                ``get_entity_patterns()``. Default 1 preserves the existing threshold
                for LLM-discovered patterns.
            registry_id: Optional registry scope. When provided, the pattern is
                stamped with this registry and will only surface in queries that
                filter by the same registry_id. When omitted, the pattern is
                workspace-wide (legacy behavior) and shared across all registries
                in the workspace.

        Returns:
            True if created, False on error.
        """
        # SELF-IMPROVE-9 S00/T1 (Codex R1/C3): delegate to the single write
        # chokepoint. The legacy body duplicated the confidence-averaging bug
        # AND wrote a single-label :EntityType parent — the
        # ONTO-PATTERN-MIGRATE-1 inconsistency. Zero live callers verified
        # (core + service + client + maya + common); the @deprecated warning
        # above is preserved. Cap/monotonic-confidence (T2) lands once in
        # _upsert_inline_ontology_pattern and now covers this path too.
        return self._upsert_inline_ontology_pattern(
            name,
            label,
            confidence,
            workspace_id=workspace_id,
            is_global=is_global,
            source=source,
            initial_count=initial_count,
            registry_id=registry_id,
        )

    def _upsert_inline_ontology_pattern(
        self,
        name: str,
        label: str,
        confidence: float,
        workspace_id: str | None = None,
        is_global: bool = False,
        source: str = "llm_discovery",
        initial_count: int = 1,
        registry_id: str | None = None,
    ) -> bool:
        """Single-Cypher upsert for inline pattern observations targeting
        dual-labelled `:EntityType:OntologyType` parent.

        ONTO-PATTERN-MIGRATE-1 (2026-05-04): replaces ``add_entity_pattern``'s
        single-label `:EntityType` parent with a dual-label
        `:EntityType:OntologyType` MERGE. Unblocks ONTO-RECONCILE-1 Task 11
        (drop legacy `:EntityType` label) — without this rewrite, every
        ingest after the drop would fail to find the parent node.

        Dual-labelling rationale: a single-label `:OntologyType` MERGE for
        a never-before-seen entity_type label would create an
        `:OntologyType`-only parent invisible to 8+ legacy `:EntityType`
        read sites in this module (lines 124, 158, 172, 190, 205, 220, 233,
        742, 2805) during the soak window. Dual-labelling is idempotent
        against migrated nodes (Pass 1 of `migrate_ontology_unify.py`
        already added `:OntologyType` to every `:EntityType`) and
        forwards-compat for new ones. Task 11 strips `:EntityType` in one
        sweep.

        Preserves the legacy semantics from ``add_entity_pattern`` exactly:
        - count >= 2 frequency gate: applied in ``get_entity_patterns()``
          Cypher (NOT in this primitive — same as before).
        - confidence on MATCH: SELF-IMPROVE-9 S01 monotonic bounded
          reinforcement — ``c <- c + alpha*(cap - c)`` toward a
          source-tiered cap (``_cap_for_source``). Strictly increasing,
          asymptotic to the cap, never exceeds it. ON CREATE clamps the
          incoming confidence to the cap. Replaces the pre-SI-9
          ``(existing+new)/2`` half-average, which pinned confidence to the
          latest input and never accumulated repeated evidence.
        - source preservation: ON MATCH does NOT touch ``p.source`` (first
          writer wins — write-once provenance).
        - registry scoping: explicit existence-check + branch (FalkorDB
          MERGE on (name, label, registry_id) cannot scope by registry_id).
        """
        if not name or not label:
            return False
        backend = self._get_backend()
        try:
            ws = workspace_id or self.workspace_id
            name_lc = name.lower()
            # SELF-IMPROVE-9 S01: source-tiered cap + monotonic reinforcement.
            # FalkorDB has no LEAST(); clamp the create-time value in Python.
            cap = _cap_for_source(source)
            conf_capped = min(confidence, cap)
            if registry_id is None:
                backend.query(
                    "MERGE (t:EntityType:OntologyType {name: $label}) "
                    "MERGE (p:EntityPattern {name: $name, label: $label}) "
                    "ON CREATE SET p.confidence = $conf_capped, p.workspace_id = $ws, "
                    "p.is_global = $glob, p.source = $source, p.discovered_at = timestamp(), "
                    "p.count = $initial_count "
                    "ON MATCH SET p.count = COALESCE(p.count, 1) + 1, "
                    "p.confidence = CASE "
                    "WHEN COALESCE(p.confidence, $base) >= $cap THEN $cap "
                    "ELSE COALESCE(p.confidence, $base) + $alpha * ($cap - COALESCE(p.confidence, $base)) "
                    "END "
                    "MERGE (p)-[:IS_INSTANCE_OF]->(t)",
                    params={
                        "name": name_lc,
                        "label": label,
                        "conf_capped": conf_capped,
                        "cap": cap,
                        "alpha": _CONFIDENCE_ALPHA,
                        "base": _CONFIDENCE_BASE,
                        "ws": ws,
                        "glob": is_global,
                        "source": source,
                        "initial_count": initial_count,
                    },
                    graph_name=self._graph_name,
                )
            else:
                existing = backend.query(
                    "MATCH (p:EntityPattern {name: $name, label: $label}) "
                    "WHERE p.registry_id = $rid "
                    "RETURN id(p) LIMIT 1",
                    params={"name": name_lc, "label": label, "rid": registry_id},
                    graph_name=self._graph_name,
                )
                if existing:
                    backend.query(
                        "MATCH (p:EntityPattern {name: $name, label: $label}) "
                        "WHERE p.registry_id = $rid "
                        "SET p.count = COALESCE(p.count, 1) + 1, "
                        "p.confidence = CASE "
                        "WHEN COALESCE(p.confidence, $base) >= $cap THEN $cap "
                        "ELSE COALESCE(p.confidence, $base) + $alpha * ($cap - COALESCE(p.confidence, $base)) "
                        "END",
                        params={
                            "name": name_lc,
                            "label": label,
                            "rid": registry_id,
                            "cap": cap,
                            "alpha": _CONFIDENCE_ALPHA,
                            "base": _CONFIDENCE_BASE,
                        },
                        graph_name=self._graph_name,
                    )
                else:
                    backend.query(
                        "MERGE (t:EntityType:OntologyType {name: $label}) "
                        "CREATE (p:EntityPattern {name: $name, label: $label, "
                        "registry_id: $rid, workspace_id: $ws, is_global: $glob, "
                        "confidence: $conf_capped, source: $source, "
                        "discovered_at: timestamp(), count: $initial_count}) "
                        "MERGE (p)-[:IS_INSTANCE_OF]->(t)",
                        params={
                            "name": name_lc,
                            "label": label,
                            "conf_capped": conf_capped,
                            "cap": cap,
                            "ws": ws,
                            "glob": is_global,
                            "source": source,
                            "initial_count": initial_count,
                            "rid": registry_id,
                        },
                        graph_name=self._graph_name,
                    )
            return True
        except Exception as e:
            logger.warning("Failed to upsert inline ontology pattern '%s' -> '%s': %s", name, label, e)
            return False

    def get_entity_patterns(
        self,
        workspace_id: str | None = None,
        registry_id: str | None = None,
    ) -> List[Dict]:
        """Load patterns for a workspace (including global patterns).

        When ``registry_id`` is provided, the result includes patterns whose
        ``registry_id`` matches OR is NULL (legacy workspace-wide patterns
        stay visible to every registry until they are re-stamped). When
        ``registry_id`` is omitted, the legacy behavior applies — return
        every pattern visible to the workspace regardless of registry.
        """
        backend = self._get_backend()
        ws = workspace_id or self.workspace_id
        try:
            if registry_id is not None:
                cypher = (
                    "MATCH (p:EntityPattern) "
                    "WHERE (p.is_global = true OR p.workspace_id = $ws) "
                    "AND (p.registry_id IS NULL OR p.registry_id = $rid) "
                    "AND COALESCE(p.count, 1) >= 2 "
                    "RETURN p.name, p.label, COALESCE(p.confidence, 0.5), p.source"
                )
                params = {"ws": ws, "rid": registry_id}
            else:
                cypher = (
                    "MATCH (p:EntityPattern) "
                    "WHERE (p.is_global = true OR p.workspace_id = $ws) "
                    "AND COALESCE(p.count, 1) >= 2 "
                    "RETURN p.name, p.label, COALESCE(p.confidence, 0.5), p.source"
                )
                params = {"ws": ws}
            result = backend.query(cypher, params=params, graph_name=self._graph_name)
            return [
                {"name": row[0], "label": row[1], "confidence": float(row[2]), "source": row[3]}
                for row in (result or [])
            ]
        except Exception as e:
            logger.warning("Failed to get entity patterns for workspace '%s': %s", ws, e)
            return []

    def get_entity_patterns_for_conflict_map(
        self,
        workspace_id: str | None = None,
        registry_id: str | None = None,
    ) -> List[Dict]:
        """Unfiltered sibling of :meth:`get_entity_patterns` for conflict
        arbitration ONLY — NOT for ruler surfacing (SELF-IMPROVE-9C).

        A faithful mirror of ``get_entity_patterns`` — same workspace/global
        scoping, same ``registry_id`` semantics (match OR NULL when provided;
        registry-agnostic when omitted), same projection — **minus** the
        ``COALESCE(p.count,1) >= 2`` discovery gate, so
        ``PatternManager.add_patterns`` precedence can see below-threshold
        (``count = 1``) incumbents. Dropping ``registry_id`` would let a
        registry-scoped pattern wrongly arbitrate against another registry
        (Codex SELF-IMPROVE-9C #2). Surfacing one-shot rows to the
        EntityRuler would pollute NER, which is why the gate stays on the
        ruler-build read path; precedence must see every durable row.
        """
        backend = self._get_backend()
        ws = workspace_id or self.workspace_id
        try:
            if registry_id is not None:
                cypher = (
                    "MATCH (p:EntityPattern) "
                    "WHERE (p.is_global = true OR p.workspace_id = $ws) "
                    "AND (p.registry_id IS NULL OR p.registry_id = $rid) "
                    "RETURN p.name, p.label, COALESCE(p.confidence, 0.5), p.source"
                )
                params = {"ws": ws, "rid": registry_id}
            else:
                cypher = (
                    "MATCH (p:EntityPattern) "
                    "WHERE (p.is_global = true OR p.workspace_id = $ws) "
                    "RETURN p.name, p.label, COALESCE(p.confidence, 0.5), p.source"
                )
                params = {"ws": ws}
            result = backend.query(cypher, params=params, graph_name=self._graph_name)
            return [
                {"name": row[0], "label": row[1], "confidence": float(row[2]), "source": row[3]}
                for row in (result or [])
            ]
        except Exception as e:
            logger.warning("Failed to get conflict-map entity patterns for workspace '%s': %s", ws, e)
            return []

    def seed_entity_patterns(self, patterns: Dict[str, str] | None = None) -> int:
        """Seed common entity patterns for seed types. Idempotent.

        Args:
            patterns: Optional dict of {entity_name: entity_type}. Defaults to common entities.

        Returns:
            Number of patterns created.
        """
        defaults: Dict[str, str] = {
            "python": "Technology",
            "javascript": "Technology",
            "typescript": "Technology",
            "react": "Technology",
            "docker": "Technology",
            "kubernetes": "Technology",
            "aws": "Organization",
            "google": "Organization",
            "microsoft": "Organization",
            "github": "Organization",
            "openai": "Organization",
        }
        to_seed = patterns or defaults
        created = 0
        for name, label in to_seed.items():
            if self._upsert_inline_ontology_pattern(name, label, 0.95, is_global=True, source="seed", initial_count=2):
                created += 1
        return created

    def get_pattern_stats(self) -> Dict[str, int]:
        """Return counts of patterns by source layer: {seed, promoted, llm_discovery}."""
        backend = self._get_backend()
        try:
            result = backend.query(
                "MATCH (p:EntityPattern) RETURN p.source, count(p) ORDER BY p.source",
                graph_name=self._graph_name,
            )
            stats: Dict[str, int] = {"seed": 0, "promoted": 0, "llm_discovery": 0}
            for row in result or []:
                source = row[0] or "llm_discovery"
                stats[source] = int(row[1])
            return stats
        except Exception as e:
            logger.warning("Failed to get pattern stats: %s", e)
            return {"seed": 0, "promoted": 0, "llm_discovery": 0}

    # ------------------------------------------------------------------ #
    # Pipeline config storage (Phase 5)
    # ------------------------------------------------------------------ #

    def save_pipeline_config(self, name: str, config_json: str, workspace_id: str, description: str = "") -> bool:
        """Save or update a named pipeline config as a PipelineConfig node.

        Returns:
            True if saved successfully.
        """
        backend = self._get_backend()
        try:
            backend.query(
                "MERGE (c:PipelineConfig {name: $name, workspace_id: $ws}) "
                "ON CREATE SET c.config_json = $cfg, c.description = $desc, "
                "c.created_at = timestamp(), c.updated_at = timestamp() "
                "ON MATCH SET c.config_json = $cfg, c.description = $desc, "
                "c.updated_at = timestamp()",
                params={"name": name, "ws": workspace_id, "cfg": config_json, "desc": description},
                graph_name=self._graph_name,
            )
            return True
        except Exception as e:
            logger.warning("Failed to save pipeline config '%s': %s", name, e)
            return False

    def get_pipeline_config(self, name: str, workspace_id: str) -> Dict[str, Any] | None:
        """Load a named pipeline config by name and workspace.

        Returns:
            Config dict with name, description, config_json, workspace_id, created_at, updated_at.
            None if not found.
        """
        backend = self._get_backend()
        try:
            result = backend.query(
                "MATCH (c:PipelineConfig {name: $name, workspace_id: $ws}) "
                "RETURN c.name, c.description, c.config_json, c.workspace_id, "
                "c.created_at, c.updated_at",
                params={"name": name, "ws": workspace_id},
                graph_name=self._graph_name,
            )
            if not result:
                return None
            row = result[0]
            return {
                "name": row[0],
                "description": row[1] or "",
                "config_json": row[2],
                "workspace_id": row[3],
                "created_at": str(row[4]) if row[4] else "",
                "updated_at": str(row[5]) if row[5] else "",
            }
        except Exception as e:
            logger.warning("Failed to get pipeline config '%s': %s", name, e)
            return None

    def list_pipeline_configs(self, workspace_id: str) -> List[Dict[str, Any]]:
        """List all pipeline configs for a workspace."""
        backend = self._get_backend()
        try:
            result = backend.query(
                "MATCH (c:PipelineConfig {workspace_id: $ws}) "
                "RETURN c.name, c.description, c.config_json, c.workspace_id, "
                "c.created_at, c.updated_at ORDER BY c.name",
                params={"ws": workspace_id},
                graph_name=self._graph_name,
            )
            return [
                {
                    "name": row[0],
                    "description": row[1] or "",
                    "config_json": row[2],
                    "workspace_id": row[3],
                    "created_at": str(row[4]) if row[4] else "",
                    "updated_at": str(row[5]) if row[5] else "",
                }
                for row in (result or [])
            ]
        except Exception as e:
            logger.warning("Failed to list pipeline configs for workspace '%s': %s", workspace_id, e)
            return []

    def delete_pipeline_config(self, name: str, workspace_id: str) -> bool:
        """Delete a named pipeline config. Returns True if deleted."""
        backend = self._get_backend()
        try:
            backend.query(
                "MATCH (c:PipelineConfig {name: $name, workspace_id: $ws}) DELETE c",
                params={"name": name, "ws": workspace_id},
                graph_name=self._graph_name,
            )
            return True
        except Exception as e:
            logger.warning("Failed to delete pipeline config '%s': %s", name, e)
            return False

    # ------------------------------------------------------------------ #
    # Entity pattern deletion (Phase 5)
    # ------------------------------------------------------------------ #

    def delete_entity_pattern(
        self,
        name: str,
        label: str,
        workspace_id: str | None = None,
        force_global: bool = False,
        registry_id: str | None = None,
    ) -> bool:
        """Delete an EntityPattern node by name and label.

        By default only the current workspace's pattern is deleted. Global
        (seed) patterns shared across workspaces are protected — pass
        ``force_global=True`` from admin/migration code to also remove
        ``is_global=true`` patterns. Tenant-facing routes must leave this
        default so one workspace can't wipe shared reference patterns.

        When ``registry_id`` is supplied, the delete is scoped to patterns
        whose ``registry_id`` matches, so deleting a pattern from one
        registry never cascades into other registries that share the same
        name+label. When omitted, any non-global workspace pattern with
        the matching name+label is deleted (legacy behavior).

        Returns:
            True if deleted successfully.
        """
        backend = self._get_backend()
        ws = workspace_id or self.workspace_id
        clauses = []
        if force_global:
            clauses.append("(p.workspace_id = $ws OR p.is_global = true)")
        else:
            # coalesce() per FalkorDB null-handling rule — `p.is_global <> true`
            # would silently skip rows where is_global IS NULL.
            clauses.append("p.workspace_id = $ws AND coalesce(p.is_global, false) = false")
        if registry_id is not None:
            # Match both registry-scoped patterns AND legacy workspace-wide
            # patterns (NULL registry_id) — a registry-scoped list surfaces
            # both, so a registry-scoped delete must be able to remove
            # either. Callers that want to preserve legacy patterns can
            # filter the list itself before issuing the delete.
            clauses.append("(p.registry_id = $rid OR p.registry_id IS NULL)")
        where = "WHERE " + " AND ".join(clauses)
        params: Dict[str, Any] = {"name": name.lower(), "label": label, "ws": ws}
        if registry_id is not None:
            params["rid"] = registry_id
        try:
            # Count matches first so we can report an honest True/False
            # based on whether a row was actually removed — the route layer
            # uses this to distinguish "nothing to delete" from "delete
            # succeeded".
            pre = backend.query(
                f"MATCH (p:EntityPattern {{name: $name, label: $label}}) {where} RETURN count(p) AS n",
                params=params,
                graph_name=self._graph_name,
            )
            match_count = 0
            if pre:
                row = pre[0] if isinstance(pre, list) else pre
                match_count = int(row[0]) if isinstance(row, (list, tuple)) and row else int(row)
            if match_count == 0:
                return False
            backend.query(
                f"MATCH (p:EntityPattern {{name: $name, label: $label}}) {where} DETACH DELETE p",
                params=params,
                graph_name=self._graph_name,
            )
            return True
        except Exception as e:
            logger.warning("Failed to delete entity pattern '%s' -> '%s': %s", name, label, e)
            return False

    # ------------------------------------------------------------------ #
    # Relation type management (ONTO-PUB-3)
    # ------------------------------------------------------------------ #

    def seed_relation_types(self) -> int:
        """Seed canonical relation types as RelationType nodes. Idempotent.

        Returns:
            Number of types actually created (skips existing).
        """
        try:
            from smartmemory.relations.schema import CANONICAL_RELATION_TYPES
        except ImportError:
            logger.warning("smartmemory.relations.schema not available; skipping relation type seeding")
            return 0

        backend = self._get_backend()
        created = 0

        for name, typedef in CANONICAL_RELATION_TYPES.items():
            try:
                existing = backend.query(
                    "MATCH (t:RelationType {name: $name}) RETURN t.name",
                    params={"name": name},
                    graph_name=self._graph_name,
                )
                if existing:
                    continue
                backend.query(
                    "CREATE (t:RelationType {name: $name, status: 'seed', category: $category})",
                    params={"name": name, "category": typedef.category},
                    graph_name=self._graph_name,
                )
                created += 1
            except Exception as e:
                logger.warning("Failed to seed relation type '%s': %s", name, e)

        logger.info("Seeded %d/%d relation types in %s", created, len(CANONICAL_RELATION_TYPES), self._graph_name)
        return created

    def get_relation_types(self, status: str | None = None) -> list[dict]:
        """Return all relation types, optionally filtered by status.

        Returns dicts with: name, status, category, aliases (list), type_pairs (list),
        frequency (int), promoted_at (str|None).
        """
        backend = self._get_backend()
        try:
            fields = (
                "t.name AS name, t.status AS status, t.category AS category, "
                "t.aliases AS aliases, t.type_pairs AS type_pairs, "
                "t.frequency AS frequency, t.promoted_at AS promoted_at"
            )
            if status:
                result = backend.query(
                    f"MATCH (t:RelationType {{status: $status}}) RETURN {fields} ORDER BY t.name",
                    params={"status": status},
                    graph_name=self._graph_name,
                )
            else:
                result = backend.query(
                    f"MATCH (t:RelationType) RETURN {fields} ORDER BY t.name",
                    graph_name=self._graph_name,
                )
            types = []
            for row in result or []:
                types.append(
                    {
                        "name": row[0],
                        "status": row[1],
                        "category": row[2],
                        "aliases": json.loads(row[3]) if row[3] else [],
                        "type_pairs": json.loads(row[4]) if row[4] else [],
                        "frequency": int(row[5]) if row[5] is not None else 0,
                        "promoted_at": row[6],
                    }
                )
            return types
        except Exception as e:
            logger.warning("Failed to query relation types: %s", e)
            return []

    def add_provisional_relation_type(self, name: str, category: str = "unknown") -> bool:
        """Add a provisional relation type. No-op if already exists.

        Returns:
            True if created, False if already existed.
        """
        backend = self._get_backend()
        try:
            existing = backend.query(
                "MATCH (t:RelationType {name: $name}) RETURN t.name",
                params={"name": name},
                graph_name=self._graph_name,
            )
            if existing:
                return False
            backend.query(
                "CREATE (t:RelationType {name: $name, status: 'provisional', category: $category})",
                params={"name": name, "category": category},
                graph_name=self._graph_name,
            )
            return True
        except Exception as e:
            logger.warning("Failed to add provisional relation type '%s': %s", name, e)
            return False

    def seed_type_pair_edges(self) -> int:
        """Ensure VALID_FOR edges exist between EntityType nodes for type-pair priors.

        Graph model: EntityType -[VALID_FOR {relation: "works_at"}]-> EntityType
        Wildcard pairs ("*", "*") are skipped — they apply universally.

        Uses MERGE (idempotent) — safe to call repeatedly.

        Returns:
            Number of edges ensured (includes already-existing edges).
        """
        try:
            from smartmemory.relations.schema import CANONICAL_RELATION_TYPES
        except ImportError:
            return 0

        backend = self._get_backend()
        ensured = 0

        for name, typedef in CANONICAL_RELATION_TYPES.items():
            for src, tgt in typedef.type_pairs:
                if src == "*" or tgt == "*":
                    continue  # wildcards are implicit, not stored as edges
                try:
                    backend.query(
                        "MERGE (s:EntityType {name: $src}) "
                        "MERGE (t:EntityType {name: $tgt}) "
                        "MERGE (s)-[r:VALID_FOR {relation: $rel}]->(t)",
                        params={"src": src.title(), "tgt": tgt.title(), "rel": name},
                        graph_name=self._graph_name,
                    )
                    ensured += 1
                except Exception as e:
                    logger.warning("Failed to ensure VALID_FOR edge %s->%s for '%s': %s", src, tgt, name, e)

        logger.info("Ensured %d type-pair edges in %s", ensured, self._graph_name)
        return ensured

    # ------------------------------------------------------------------ #
    # Relation frequency & novel label tracking (CORE-EXT-1c)
    # ------------------------------------------------------------------ #

    def increment_relation_frequency(self, name: str, confidence: float) -> None:
        """Atomically increment frequency on a RelationType node and update last_seen."""
        backend = self._get_backend()
        try:
            backend.query(
                "MERGE (t:RelationType {name: $name}) "
                "SET t.frequency = COALESCE(t.frequency, 0) + 1, "
                "t.last_seen = $now",
                params={"name": name, "now": _now_iso()},
                graph_name=self._graph_name,
            )
        except Exception as e:
            logger.warning("Failed to increment relation frequency for '%s': %s", name, e)

    def add_novel_relation_label(
        self,
        name: str,
        raw_examples: list[str] | None = None,
        source_types: list[str] | None = None,
        target_types: list[str] | None = None,
        workspace_id: str | None = None,
    ) -> bool:
        """Track a novel relation label. Increments frequency if exists.

        Returns True if this is a new label (created), False if updated.
        """
        backend = self._get_backend()
        try:
            existing = backend.query(
                "MATCH (n:NovelRelationLabel {name: $name}) RETURN n.name, n.frequency",
                params={"name": name},
                graph_name=self._graph_name,
            )
            if existing:
                backend.query(
                    "MATCH (n:NovelRelationLabel {name: $name}) SET n.frequency = n.frequency + 1, n.last_seen = $now",
                    params={"name": name, "now": _now_iso()},
                    graph_name=self._graph_name,
                )
                return False
            backend.query(
                "CREATE (n:NovelRelationLabel {"
                "name: $name, frequency: 1, status: 'tracking', "
                "raw_examples: $raw_examples, source_types: $source_types, "
                "target_types: $target_types, workspace_id: $ws, "
                "first_seen: $now, last_seen: $now})",
                params={
                    "name": name,
                    "raw_examples": json.dumps((raw_examples or [])[:10]),
                    "source_types": json.dumps(source_types or []),
                    "target_types": json.dumps(target_types or []),
                    "ws": workspace_id or "",
                    "now": _now_iso(),
                },
                graph_name=self._graph_name,
            )
            return True
        except Exception as e:
            logger.warning("Failed to track novel relation label '%s': %s", name, e)
            return False

    def get_novel_relation_labels(self, min_frequency: int = 1, status: str | None = None) -> list[dict]:
        """Query NovelRelationLabel nodes above a frequency threshold."""
        backend = self._get_backend()
        try:
            where = "WHERE n.frequency >= $min_freq"
            params: dict = {"min_freq": min_frequency}
            if status:
                where += " AND n.status = $status"
                params["status"] = status
            result = backend.query(
                f"MATCH (n:NovelRelationLabel) {where} "
                "RETURN n.name, n.frequency, n.status, n.raw_examples, "
                "n.source_types, n.target_types, n.workspace_id, n.first_seen, n.last_seen "
                "ORDER BY n.frequency DESC",
                params=params,
                graph_name=self._graph_name,
            )
            return [
                {
                    "name": row[0],
                    "frequency": row[1],
                    "status": row[2],
                    "raw_examples": json.loads(row[3] or "[]"),
                    "source_types": json.loads(row[4] or "[]"),
                    "target_types": json.loads(row[5] or "[]"),
                    "workspace_id": row[6],
                    "first_seen": row[7],
                    "last_seen": row[8],
                }
                for row in (result or [])
            ]
        except Exception as e:
            logger.warning("Failed to query novel relation labels: %s", e)
            return []

    def promote_relation_type(
        self,
        name: str,
        category: str = "discovered",
        aliases: list[str] | None = None,
        type_pairs: list[tuple[str, str]] | None = None,
    ) -> bool:
        """Promote a novel label to a confirmed canonical relation type.

        Creates or updates a RelationType node with status='confirmed' and
        marks the corresponding NovelRelationLabel as 'promoted' if it exists.
        """
        backend = self._get_backend()
        try:
            backend.query(
                "MERGE (t:RelationType {name: $name}) "
                "SET t.status = 'confirmed', t.category = $category, "
                "t.aliases = $aliases, t.type_pairs = $type_pairs, "
                "t.promoted_at = $now",
                params={
                    "name": name,
                    "category": category,
                    "aliases": json.dumps(aliases or []),
                    "type_pairs": json.dumps(type_pairs or []),
                    "now": _now_iso(),
                },
                graph_name=self._graph_name,
            )
            backend.query(
                "MATCH (n:NovelRelationLabel {name: $name}) SET n.status = 'promoted'",
                params={"name": name},
                graph_name=self._graph_name,
            )
            return True
        except Exception as e:
            logger.warning("Failed to promote relation type '%s': %s", name, e)
            return False

    # ------------------------------------------------------------------ #
    # ONTO-RECONCILE-1 Task 2 — Unified `:OntologyType` storage
    # ------------------------------------------------------------------ #
    #
    # New storage label `:OntologyType` lives alongside the legacy
    # `:EntityType` / `:RelationType` labels in the per-workspace
    # `ws_{workspace_id}_ontology` graph. These are the only methods the
    # `OntologyService` calls into; nothing outside `service.py` may read
    # or write `:OntologyType` directly. See ONTO-RECONCILE-1 plan.md
    # "Load-Bearing Discipline" and Task 2.

    # Tier rank for monotonic upsert. Never demotes: a re-MERGE with a
    # lower-rank tier leaves the existing tier untouched.
    _ONTO_TYPE_TIER_RANK = {"working": 1, "proposed": 2, "confirmed": 3, "retired": 4}

    # Collection-typed fields on OntologyType. Stored as JSON strings on
    # FalkorDB nodes (FalkorDB list/dict properties don't auto-deserialize
    # on read — see project memory feedback_falkordb_list_prop_read_deserialize_gap).
    _ONTO_TYPE_LIST_FIELDS = (
        "aliases",
        "examples",
        "parent_types",
        "equivalent_types",
        "evidence",
        "equivalent_iris",
    )
    _ONTO_TYPE_DICT_FIELDS = ("properties_schema",)
    _ONTO_TYPE_SET_FIELDS = ("required_properties",)

    def ensure_ontology_type_indexes(self) -> None:
        """Create idempotent indexes for `:OntologyType`. Mirrors the
        `FalkorDBGraphService._create_indexes()` style (CREATE INDEX +
        per-statement try/except so re-runs and partial state are safe).

        Composite indexes are not emitted; FalkorDB's support varies by
        version and the single-prop indexes cover Task 2 access patterns.
        """
        backend = self._get_backend()
        statements = [
            "CREATE INDEX FOR (n:OntologyType) ON (n.name)",
            "CREATE INDEX FOR (n:OntologyType) ON (n.iri)",
            "CREATE INDEX FOR (n:OntologyType) ON (n.wikidata_qid)",
            "CREATE INDEX FOR (n:OntologyType) ON (n.tier)",
            "CREATE INDEX FOR (n:OntologyType) ON (n.layer)",
            "CREATE INDEX FOR (n:OntologyType) ON (n.pack_id)",
            # Phase 4 Task 14 audit: workspace_id is the multi-tenancy
            # boundary; almost every query in the substrate filters by
            # it. pack_version pairs with pack_id for version-scoped
            # uninstall/list paths.
            "CREATE INDEX FOR (n:OntologyType) ON (n.workspace_id)",
            "CREATE INDEX FOR (n:OntologyType) ON (n.pack_version)",
        ]
        for stmt in statements:
            try:
                backend.query(stmt, graph_name=self._graph_name)
            except Exception as e:
                logger.debug("OntologyType index already present or unsupported: %s", e)

    def _ot_encode_props(self, ot) -> Dict[str, Any]:
        """Serialize an OntologyType dataclass to FalkorDB-friendly props.

        List/dict/set fields go to JSON strings; scalars pass through;
        `None` values are dropped so `prop IS NULL` filters work.
        """
        from dataclasses import asdict

        raw = asdict(ot)
        # `required_properties: set` → asdict yields a set, which is not
        # JSON-serializable. Convert to a sorted list for stable output.
        if isinstance(raw.get("required_properties"), set):
            raw["required_properties"] = sorted(raw["required_properties"])

        props: Dict[str, Any] = {}
        for k, v in raw.items():
            if v is None:
                continue
            if k in self._ONTO_TYPE_LIST_FIELDS or k in self._ONTO_TYPE_DICT_FIELDS or k in self._ONTO_TYPE_SET_FIELDS:
                props[k] = json.dumps(v)
            elif isinstance(v, datetime):
                props[k] = v.isoformat()
            else:
                props[k] = v
        return props

    def _ot_decode_row(self, row: List[Any], cols: List[str]):
        """Reconstruct an OntologyType from a Cypher RETURN row."""
        from smartmemory.ontology.types import OntologyType

        data: Dict[str, Any] = dict(zip(cols, row, strict=False))
        # Decode JSON-string properties back to their typed shape.
        for f in self._ONTO_TYPE_LIST_FIELDS:
            v = data.get(f)
            data[f] = json.loads(v) if v else []
        for f in self._ONTO_TYPE_DICT_FIELDS:
            v = data.get(f)
            data[f] = json.loads(v) if v else {}
        for f in self._ONTO_TYPE_SET_FIELDS:
            v = data.get(f)
            data[f] = set(json.loads(v)) if v else set()

        # Drop unset scalars so dataclass defaults apply.
        clean = {k: v for k, v in data.items() if v is not None}
        # `name` is required; if it is missing the row was malformed.
        if "name" not in clean:
            return None
        return OntologyType(**clean)

    _ONTO_TYPE_RETURN = (
        "n.name AS name, n.iri AS iri, n.wikidata_qid AS wikidata_qid, "
        "n.display_name AS display_name, n.definition AS definition, "
        "n.description AS description, n.aliases AS aliases, n.examples AS examples, "
        "n.parent_types AS parent_types, n.equivalent_types AS equivalent_types, "
        "n.equivalent_iris AS equivalent_iris, n.properties_schema AS properties_schema, "
        "n.required_properties AS required_properties, n.tier AS tier, "
        "n.trust_origin AS trust_origin, n.layer AS layer, n.pack_id AS pack_id, "
        "n.pack_version AS pack_version, n.workspace_id AS workspace_id, "
        "n.source AS source, n.evidence AS evidence, n.confidence AS confidence, "
        "n.frequency AS frequency, n.disambiguator AS disambiguator, "
        "n.created_by AS created_by, n.created_at AS created_at, "
        "n.updated_at AS updated_at"
    )
    _ONTO_TYPE_COLS = [
        "name",
        "iri",
        "wikidata_qid",
        "display_name",
        "definition",
        "description",
        "aliases",
        "examples",
        "parent_types",
        "equivalent_types",
        "equivalent_iris",
        "properties_schema",
        "required_properties",
        "tier",
        "trust_origin",
        "layer",
        "pack_id",
        "pack_version",
        "workspace_id",
        "source",
        "evidence",
        "confidence",
        "frequency",
        "disambiguator",
        "created_by",
        "created_at",
        "updated_at",
    ]

    def _ot_match_clause_by_identity(
        self,
        identifier: str,
        layer: Optional[str],
        workspace_id: Optional[str],
        pack_id: Optional[str] = None,
    ):
        """Build a `MATCH (n:OntologyType) WHERE …` fragment that resolves
        an identifier per the identity rule (iri → qid → composite name).

        Returns `(where, params)`. The composite branch only matches when
        `iri IS NULL AND wikidata_qid IS NULL` so an iri-anchored type is
        never accidentally fetched by name.
        """
        params: Dict[str, Any] = {"id": identifier}
        clauses = ["(n.iri = $id OR n.wikidata_qid = $id"]
        # Composite-name branch: only when the node has no iri/qid; layer
        # and workspace_id must match for the composite key to apply.
        composite_extras = ["n.iri IS NULL", "n.wikidata_qid IS NULL", "n.name = $id"]
        if layer is not None:
            composite_extras.append("n.layer = $layer")
            params["layer"] = layer
        if workspace_id is not None:
            composite_extras.append("n.workspace_id = $workspace_id")
            params["workspace_id"] = workspace_id
        if pack_id is not None:
            composite_extras.append("coalesce(n.pack_id, '') = $pack_id")
            params["pack_id"] = pack_id
        clauses.append(" OR (" + " AND ".join(composite_extras) + "))")
        where = "".join(clauses)
        return where, params

    def _upsert_ontology_type(self, ot) -> None:
        """MERGE an `:OntologyType` per the identity rule.

        Identity priority: `iri` → `wikidata_qid` → `(name, layer, workspace_id, pack_id)`.
        Tier never demotes (see `_ONTO_TYPE_TIER_RANK`). Same external
        identifier (iri or qid) bound to a different `name` within
        `(layer, workspace_id, pack_id)` is rejected with ValueError —
        `name` is immutable per `OntologyType` contract.

        **Concurrency:** This is read-then-write, not transactionally
        atomic. Two concurrent upserts on the same slot can both observe
        `existing is None` and each `CREATE` a node. Today's substrate
        invokes `OntologyService` per-request inside a single workspace
        writer, so the race is theoretical. Bulk/transactional upsert
        with workspace-scoped locking lands with `apply_changeset`
        (Task 8); a single-row dedupe sweep is the planned recovery.
        """
        backend = self._get_backend()
        props = self._ot_encode_props(ot)
        # Default workspace_id to the graph's bound workspace so callers
        # that omit it on the dataclass still get correct slot semantics.
        if not props.get("workspace_id"):
            props["workspace_id"] = self.workspace_id
        layer = props.get("layer", "private")
        pack_id = props.get("pack_id")

        # Resolve existing node, if any, using whichever identity key is set.
        existing = None
        if ot.iri:
            rows = backend.query(
                "MATCH (n:OntologyType {iri: $iri, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(n.pack_id, '') = $pack_id "
                f"RETURN {self._ONTO_TYPE_RETURN}",
                params={
                    "iri": ot.iri,
                    "layer": layer,
                    "ws": props["workspace_id"],
                    "pack_id": pack_id or "",
                },
                graph_name=self._graph_name,
            )
            if rows:
                existing = self._ot_decode_row(rows[0], self._ONTO_TYPE_COLS)
                if existing and existing.name != ot.name:
                    raise ValueError(
                        f"iri {ot.iri!r} already bound to type {existing.name!r} "
                        f"in slot (layer={layer}, workspace={props['workspace_id']}, "
                        f"pack_id={pack_id}); refusing to bind to {ot.name!r}"
                    )
        elif ot.wikidata_qid:
            rows = backend.query(
                "MATCH (n:OntologyType {wikidata_qid: $qid, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(n.pack_id, '') = $pack_id "
                f"RETURN {self._ONTO_TYPE_RETURN}",
                params={
                    "qid": ot.wikidata_qid,
                    "layer": layer,
                    "ws": props["workspace_id"],
                    "pack_id": pack_id or "",
                },
                graph_name=self._graph_name,
            )
            if rows:
                existing = self._ot_decode_row(rows[0], self._ONTO_TYPE_COLS)
                # Mirror the iri-collision guard: a qid is also a stable
                # external identifier; binding it to a different `name`
                # would silently rename the existing type and break the
                # `name is immutable` contract from types.py.
                if existing and existing.name != ot.name:
                    raise ValueError(
                        f"wikidata_qid {ot.wikidata_qid!r} already bound to type "
                        f"{existing.name!r} in slot (layer={layer}, "
                        f"workspace={props['workspace_id']}, pack_id={pack_id}); "
                        f"refusing to bind to {ot.name!r}"
                    )
        else:
            rows = backend.query(
                "MATCH (n:OntologyType {name: $name, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(n.pack_id, '') = $pack_id "
                "AND n.iri IS NULL AND n.wikidata_qid IS NULL "
                f"RETURN {self._ONTO_TYPE_RETURN}",
                params={
                    "name": ot.name,
                    "layer": layer,
                    "ws": props["workspace_id"],
                    "pack_id": pack_id or "",
                },
                graph_name=self._graph_name,
            )
            if rows:
                existing = self._ot_decode_row(rows[0], self._ONTO_TYPE_COLS)

        # Tier monotonicity: keep the higher-rank tier on the node.
        if existing is not None:
            existing_rank = self._ONTO_TYPE_TIER_RANK.get(existing.tier, 0)
            new_rank = self._ONTO_TYPE_TIER_RANK.get(ot.tier, 0)
            if existing_rank > new_rank:
                props["tier"] = existing.tier

        if existing is None:
            # CREATE — let FalkorDB assign a new node.
            backend.query(
                "CREATE (n:OntologyType) SET n = $props",
                params={"props": props},
                graph_name=self._graph_name,
            )
        else:
            # UPDATE in place — match by the same identity we resolved on.
            if ot.iri:
                backend.query(
                    "MATCH (n:OntologyType {iri: $iri, layer: $layer, workspace_id: $ws}) "
                    "WHERE coalesce(n.pack_id, '') = $pack_id SET n += $props",
                    params={
                        "iri": ot.iri,
                        "layer": layer,
                        "ws": props["workspace_id"],
                        "pack_id": pack_id or "",
                        "props": props,
                    },
                    graph_name=self._graph_name,
                )
            elif ot.wikidata_qid:
                backend.query(
                    "MATCH (n:OntologyType {wikidata_qid: $qid, layer: $layer, workspace_id: $ws}) "
                    "WHERE coalesce(n.pack_id, '') = $pack_id SET n += $props",
                    params={
                        "qid": ot.wikidata_qid,
                        "layer": layer,
                        "ws": props["workspace_id"],
                        "pack_id": pack_id or "",
                        "props": props,
                    },
                    graph_name=self._graph_name,
                )
            else:
                backend.query(
                    "MATCH (n:OntologyType {name: $name, layer: $layer, workspace_id: $ws}) "
                    "WHERE coalesce(n.pack_id, '') = $pack_id "
                    "AND n.iri IS NULL AND n.wikidata_qid IS NULL "
                    "SET n += $props",
                    params={
                        "name": ot.name,
                        "layer": layer,
                        "ws": props["workspace_id"],
                        "pack_id": pack_id or "",
                        "props": props,
                    },
                    graph_name=self._graph_name,
                )

    def _audit_workspace_id(self, fallback_ws_id: str) -> str | None:
        """Return the workspace_id `_write_audit_entry` would use.

        ONTO-AUDIT-WS-1 wired audit-row tenant scoping through
        `backend.scope_provider.get_write_context()`. The bulk helpers
        must read from the same source so audit-by-tenant queries
        return identical sets across per-row and bulk paths.

        Returns ``None`` only when no scope_provider is bound AND no
        fallback was supplied (matches `_write_audit_entry`'s NULL
        semantics for OSS / system-internal calls).
        """
        backend = self._get_backend()
        scope_provider = getattr(backend, "scope_provider", None)
        if scope_provider is not None:
            try:
                write_ctx = scope_provider.get_write_context() or {}
                ws = write_ctx.get("workspace_id")
                if ws:
                    return ws
            except Exception:
                # Mirror `_write_audit_entry`'s defensive swallow.
                pass
        return fallback_ws_id

    def _apply_changeset_types_atomic(
        self,
        types: list,  # list[OntologyType]
        *,
        actor: str,
        evidence_ref: str,
    ) -> tuple[int, int]:
        """Bulk UNWIND upsert for the type + audit category.

        Returns ``(types_created, audit_rows_written)``.

        Closes Codex Phase 3 Round 1 Finding F (audit-write atomicity gap)
        for the ``apply_changeset`` type category. Two GRAPH.QUERY calls
        per category — each is one atomicity unit on FalkorDB; combined
        they replace the per-row Python loop (was 2-3 round-trips per
        concept):

          Query 1: OPTIONAL MATCH existing + conditional CREATE-new or
                   never-demote SET-existing. RETURN ``(name, was_created)``
                   tuples.
          Query 2: UNWIND the newly-created names + bulk CREATE
                   :OntologyAudit rows.

        Replay is a true no-op against audit: query 1 all-hits the
        ON MATCH branch → query 2 receives an empty list → zero audit
        leak. The per-row Finding F divergence (graph row commits, audit
        write fails) is impossible within a single concept because the
        type upsert is its own atomic boundary.

        Identity matches the apply_changeset path's composite shape:
        ``(workspace_id, name, layer, coalesce(pack_id, ''))``. iri/qid
        are never populated on this path (see ONTO-RECONCILE-1 Tier 4
        plan Appendix A Finding S1 retraction), so the existing-row
        filter pins ``iri IS NULL AND wikidata_qid IS NULL`` to mirror
        ``_upsert_ontology_type``'s composite-name branch (:1325-1336).

        **Bulk-vs-per-row identity-resolution divergence (Codex R2
        F7).** The per-row helper resolves identity in priority order
        iri → qid → composite-name and would CREATE a sibling row if a
        new iri-bearing concept arrives for a slot whose existing row
        is composite-name-only. This bulk helper matches the composite
        slot ONLY and then refreshes its iri/wikidata_qid in place via
        ``SET e += row.props_refresh``. The bulk path therefore
        "upgrades" the slot with the new external identifier rather
        than forking. This is the established design of the bulk
        helper (and was the implicit pre-Tier-4 behavior too — Tier 4's
        F1 fix only made it observable for the iri/qid fields). Callers
        relying on per-row-equivalent identity semantics should use
        ``_upsert_ontology_type`` directly; ``apply_changeset`` is the
        bulk-upgrade path.
        """
        if not types:
            return (0, 0)

        from uuid import uuid4

        backend = self._get_backend()
        graph_name = self._graph_name

        # Build $rows: per-type dict with all scalars Cypher needs.
        # `props` is the full props (used by ON CREATE for new nodes).
        # `props_refresh` is props with tier/tier_rank stripped (used by
        # ON MATCH branch to refresh aliases/confidence/description/etc.
        # without touching tier — never-demote runs in a separate SET
        # below). The split addresses F1: the per-row helper executed
        # `SET n += $props` on existing rows, refreshing every field;
        # the bulk helper must preserve that semantic so pack reinstall
        # with refined synonyms continues to refresh the stored row.
        rows: list[dict] = []
        for ot in types:
            props = self._ot_encode_props(ot)
            if not props.get("workspace_id"):
                props["workspace_id"] = self.workspace_id
            tier_rank = self._ONTO_TYPE_TIER_RANK.get(ot.tier, 0)
            # tier_rank rides on the node so subsequent applies' Cypher
            # CASE compares against the stored ordinal directly.
            props["tier_rank"] = tier_rank
            props_refresh = {k: v for k, v in props.items() if k not in ("tier", "tier_rank")}
            layer = props.get("layer", "private")
            pack_id_key = props.get("pack_id") or ""
            rows.append({
                "props": props,
                "props_refresh": props_refresh,
                "name": props["name"],
                "workspace_id": props["workspace_id"],
                "layer": layer,
                "pack_id_key": pack_id_key,
                "tier": ot.tier,
                "tier_rank": tier_rank,
                "after_json": json.dumps({
                    "tier": ot.tier,
                    "trust_origin": ot.trust_origin,
                    "layer": layer,
                }),
            })

        # Query 1: atomic bulk upsert with never-demote semantics.
        # OPTIONAL MATCH binds existing-or-NULL; two FOREACH blocks do
        # conditional CREATE / conditional SET without branching the
        # query. The composite-name filter mirrors `_upsert_ontology_type`
        # so we don't accidentally match iri/qid-bearing rows from a
        # different write path.
        upsert_query = """
        UNWIND $rows AS row
        OPTIONAL MATCH (existing:OntologyType {
            name: row.name,
            layer: row.layer,
            workspace_id: row.workspace_id
        })
        WHERE coalesce(existing.pack_id, '') = row.pack_id_key
          AND existing.iri IS NULL
          AND existing.wikidata_qid IS NULL
        FOREACH (_ IN CASE WHEN existing IS NULL THEN [1] ELSE [] END |
            CREATE (n:OntologyType)
            SET n = row.props
        )
        FOREACH (e IN CASE WHEN existing IS NOT NULL THEN [existing] ELSE [] END |
            SET e += row.props_refresh,
                e.tier = CASE WHEN row.tier_rank > coalesce(e.tier_rank, 0)
                              THEN row.tier ELSE coalesce(e.tier, row.tier) END,
                e.tier_rank = CASE WHEN row.tier_rank > coalesce(e.tier_rank, 0)
                                   THEN row.tier_rank
                                   ELSE coalesce(e.tier_rank, row.tier_rank) END
        )
        RETURN row.name AS name, existing IS NULL AS was_created
        """
        result_rows = backend.query(
            upsert_query, params={"rows": rows}, graph_name=graph_name
        ) or []

        # Newly-created names drive query 2's audit bulk-create.
        # F5 nit: duplicate names within one bulk input are collapsed
        # (only the first is audited). Callers building IRs are
        # responsible for de-duplicating concepts upstream — duplicate
        # concept IDs in a single changeset is a caller-error condition
        # the substrate does not normalize.
        created_names: list[str] = []
        seen: set[str] = set()
        for r in result_rows:
            # FalkorDB returns rows as positional lists.
            name, was_created = r[0], r[1]
            if was_created and name not in seen:
                seen.add(name)
                created_names.append(name)

        types_created = len(created_names)

        if not created_names:
            return (0, 0)

        # Build audit rows. UUID + timestamp generated Python-side so
        # the query is deterministic given $audit_rows.
        ts = _now_iso()
        # Map name → after_json from the input rows for audit content.
        after_json_by_name = {r["name"]: r["after_json"] for r in rows}
        # F2: prefer the backend scope_provider's write context (same
        # source `_write_audit_entry` uses) so bulk and per-row audit
        # rows agree on workspace_id under ONTO-AUDIT-WS-1 semantics.
        # Fall back to the row's workspace_id when no provider is bound.
        ws_id = self._audit_workspace_id(rows[0]["workspace_id"])
        audit_rows = [
            {
                "audit_id": str(uuid4()),
                "ts": ts,
                "actor": actor,
                "target_type_id": name,
                "after_json": after_json_by_name.get(name, ""),
                "evidence_ref": evidence_ref or "",
                "workspace_id": ws_id,
            }
            for name in created_names
        ]

        # Query 2: bulk CREATE audit rows. Mirrors `_write_audit_entry`'s
        # node shape (audit_id, timestamp, actor, action, target_type_id,
        # target_relation_id=NULL, target_pack_id=NULL, ...).
        audit_query = """
        UNWIND $audit_rows AS row
        CREATE (a:OntologyAudit {
            audit_id: row.audit_id,
            timestamp: row.ts,
            actor: row.actor,
            action: 'changeset_applied',
            target_type_id: row.target_type_id,
            target_relation_id: NULL,
            target_pack_id: NULL,
            target_pack_version: NULL,
            before_json: NULL,
            after_json: row.after_json,
            evidence_ref: row.evidence_ref,
            workspace_id: row.workspace_id
        })
        """
        backend.query(
            audit_query, params={"audit_rows": audit_rows}, graph_name=graph_name
        )

        return (types_created, len(audit_rows))

    def _apply_changeset_relations_atomic(
        self,
        relations: list,  # list[OntologyRelation]
        *,
        actor: str,
        evidence_ref: str,
    ) -> tuple[int, int]:
        """Bulk UNWIND upsert for the relation + audit category.

        Mirror of `_apply_changeset_types_atomic` against
        `:OntologyRelation`. Identity rule swaps ``wikidata_qid`` →
        ``wikidata_pid`` (P-prefixed Wikidata properties). Tier rank
        re-uses ``_ONTO_TYPE_TIER_RANK`` per the existing per-row
        helper (`_upsert_ontology_relation` lines 2069-2070).

        Returns ``(relations_created, audit_rows_written)``. Same
        two-query atomic shape as the types helper; see that
        method's docstring for the full rationale.

        Per the Tier 4 plan acceptance criterion, the per-row
        callsites of ``_upsert_ontology_relation`` (single-row
        observations, inline pattern upserts) are unchanged — this
        helper is a parallel path used only by ``apply_changeset``.

        **Bulk-vs-per-row identity-resolution divergence (Codex R2
        F7).** See ``_apply_changeset_types_atomic`` docstring for the
        same caveat — the bulk path "upgrades" composite-name slots
        with new iri/wikidata_pid identifiers in place rather than
        forking, while the per-row helper would CREATE a sibling.
        """
        if not relations:
            return (0, 0)

        from uuid import uuid4

        backend = self._get_backend()
        graph_name = self._graph_name

        # See `_apply_changeset_types_atomic` for the props/props_refresh
        # split rationale (F1: per-row helper executed SET n += $props on
        # existing rows; bulk must preserve that semantic).
        rows: list[dict] = []
        for rel in relations:
            props = self._or_encode_props(rel)
            if not props.get("workspace_id"):
                props["workspace_id"] = self.workspace_id
            tier_rank = self._ONTO_TYPE_TIER_RANK.get(rel.tier, 0)
            props["tier_rank"] = tier_rank
            props_refresh = {k: v for k, v in props.items() if k not in ("tier", "tier_rank")}
            layer = props.get("layer", "private")
            pack_id_key = props.get("pack_id") or ""
            rows.append({
                "props": props,
                "props_refresh": props_refresh,
                "name": props["name"],
                "workspace_id": props["workspace_id"],
                "layer": layer,
                "pack_id_key": pack_id_key,
                "tier": rel.tier,
                "tier_rank": tier_rank,
                "after_json": json.dumps({
                    "tier": rel.tier,
                    "trust_origin": rel.trust_origin,
                    "layer": layer,
                    "kind": "relation",
                }),
            })

        # Query 1: atomic bulk upsert. Filter pins composite-name
        # branch (iri/pid both NULL) — mirrors `_upsert_ontology_relation`
        # line 1325-1336 equivalent for the relation node.
        upsert_query = """
        UNWIND $rows AS row
        OPTIONAL MATCH (existing:OntologyRelation {
            name: row.name,
            layer: row.layer,
            workspace_id: row.workspace_id
        })
        WHERE coalesce(existing.pack_id, '') = row.pack_id_key
          AND existing.iri IS NULL
          AND existing.wikidata_pid IS NULL
        FOREACH (_ IN CASE WHEN existing IS NULL THEN [1] ELSE [] END |
            CREATE (n:OntologyRelation)
            SET n = row.props
        )
        FOREACH (e IN CASE WHEN existing IS NOT NULL THEN [existing] ELSE [] END |
            SET e += row.props_refresh,
                e.tier = CASE WHEN row.tier_rank > coalesce(e.tier_rank, 0)
                              THEN row.tier ELSE coalesce(e.tier, row.tier) END,
                e.tier_rank = CASE WHEN row.tier_rank > coalesce(e.tier_rank, 0)
                                   THEN row.tier_rank
                                   ELSE coalesce(e.tier_rank, row.tier_rank) END
        )
        RETURN row.name AS name, existing IS NULL AS was_created
        """
        result_rows = backend.query(
            upsert_query, params={"rows": rows}, graph_name=graph_name
        ) or []

        created_names: list[str] = []
        seen: set[str] = set()
        for r in result_rows:
            name, was_created = r[0], r[1]
            if was_created and name not in seen:
                seen.add(name)
                created_names.append(name)

        relations_created = len(created_names)
        if not created_names:
            return (0, 0)

        ts = _now_iso()
        after_json_by_name = {r["name"]: r["after_json"] for r in rows}
        ws_id = self._audit_workspace_id(rows[0]["workspace_id"])
        # Per existing per-row code (service.py:1010-1024), relation
        # audit uses `target_type_id=rel.name` (NOT target_relation_id).
        # The contract is "target_type_id is the name of whatever was
        # audited"; relations identify themselves via after_json's
        # `"kind": "relation"` field. Preserving the contract bit-for-bit
        # so downstream queries that filter on target_type_id continue
        # to work.
        audit_rows = [
            {
                "audit_id": str(uuid4()),
                "ts": ts,
                "actor": actor,
                "target_type_id": name,
                "after_json": after_json_by_name.get(name, ""),
                "evidence_ref": evidence_ref or "",
                "workspace_id": ws_id,
            }
            for name in created_names
        ]
        audit_query = """
        UNWIND $audit_rows AS row
        CREATE (a:OntologyAudit {
            audit_id: row.audit_id,
            timestamp: row.ts,
            actor: row.actor,
            action: 'changeset_applied',
            target_type_id: row.target_type_id,
            target_relation_id: NULL,
            target_pack_id: NULL,
            target_pack_version: NULL,
            before_json: NULL,
            after_json: row.after_json,
            evidence_ref: row.evidence_ref,
            workspace_id: row.workspace_id
        })
        """
        backend.query(
            audit_query, params={"audit_rows": audit_rows}, graph_name=graph_name
        )

        return (relations_created, len(audit_rows))

    def _apply_changeset_taxonomy_atomic(
        self,
        edges: list,  # list[tuple[str, str]] — (parent_name, child_name)
        *,
        workspace_id: str,
        source: str,
        actor: str,
        evidence_ref: str,
    ) -> tuple[int, int, list[tuple[str, str]]]:
        """Bulk UNWIND upsert for the taxonomy + audit category.

        Returns ``(edges_created, audit_rows_written, endpoint_missing)``
        where ``endpoint_missing`` is the list of ``(parent, child)``
        pairs whose endpoints don't both exist in ``workspace_id``.

        Three-phase shape (the only Tier 4 helper that needs three
        phases — endpoint validity must be checked before the MERGE
        to avoid FalkorDB silently creating placeholder
        ``:OntologyType`` nodes via `MERGE` semantics):

          Query 1 (read): bulk endpoint-existence check via UNWIND +
                          two MATCHes per row. Partition rows into
                          OK / endpoint-missing in Python so the caller
                          can surface missing-endpoint warnings per
                          ``feedback_no_silent_fallbacks``.
          Query 2 (atomic write): bulk OPTIONAL MATCH existing edge +
                                  conditional CREATE for new edges only.
          Query 3 (atomic audit): bulk CREATE audit rows for newly-
                                  created edges.

        Per-edge Finding F divergence (edge committed, audit fails)
        is impossible within a single row because each query is one
        atomic GRAPH.QUERY. Replay is a true no-op: query 2 finds all
        edges already exist → created_pairs is empty → query 3
        unwinds empty.

        Per the Tier 4 plan acceptance criterion, the per-row
        ``_upsert_taxonomy_edge`` is unchanged — this helper is a
        parallel bulk path used only by ``apply_changeset``.
        """
        if not edges:
            return (0, 0, [])

        from uuid import uuid4

        backend = self._get_backend()
        graph_name = self._graph_name

        # Query 1: bulk endpoint-existence check. Returns per-row
        # parent/child names plus booleans for whether each endpoint
        # exists in the workspace. Cypher emits NULL when a MATCH
        # binds nothing in an OPTIONAL MATCH; we count the matched
        # nodes to derive the boolean.
        check_rows = [
            {"parent": p, "child": c, "ws": workspace_id}
            for (p, c) in edges
        ]
        check_query = """
        UNWIND $rows AS row
        OPTIONAL MATCH (p:OntologyType {name: row.parent, workspace_id: row.ws})
        WITH row, count(p) AS pn
        OPTIONAL MATCH (c:OntologyType {name: row.child, workspace_id: row.ws})
        RETURN row.parent AS parent, row.child AS child, pn AS pn, count(c) AS cn
        """
        check_result = backend.query(
            check_query, params={"rows": check_rows}, graph_name=graph_name
        ) or []

        ok_edges: list[tuple[str, str]] = []
        endpoint_missing: list[tuple[str, str]] = []
        for r in check_result:
            parent, child, pn, cn = r[0], r[1], int(r[2]), int(r[3])
            if pn >= 1 and cn >= 1:
                ok_edges.append((parent, child))
            else:
                endpoint_missing.append((parent, child))

        if not ok_edges:
            return (0, 0, endpoint_missing)

        # Query 2: atomic bulk MERGE for taxonomy edges.
        merge_rows = [
            {
                "parent": p,
                "child": c,
                "ws": workspace_id,
                "source": source,
                "evidence_ref": evidence_ref or "",
            }
            for (p, c) in ok_edges
        ]
        # OPTIONAL MATCH existing edge first; FOREACH-conditional CREATE
        # for new only. Direction matches `_upsert_taxonomy_edge`:
        # (child)-[:IS_A]->(parent).
        merge_query = """
        UNWIND $rows AS row
        MATCH (c:OntologyType {name: row.child, workspace_id: row.ws})
        MATCH (p:OntologyType {name: row.parent, workspace_id: row.ws})
        OPTIONAL MATCH (c)-[existing:IS_A]->(p)
        FOREACH (_ IN CASE WHEN existing IS NULL THEN [1] ELSE [] END |
            CREATE (c)-[:IS_A {source: row.source, evidence_ref: row.evidence_ref}]->(p)
        )
        RETURN row.parent AS parent, row.child AS child, existing IS NULL AS was_created
        """
        merge_result = backend.query(
            merge_query, params={"rows": merge_rows}, graph_name=graph_name
        ) or []

        created_pairs: list[tuple[str, str]] = []
        seen: set[tuple[str, str]] = set()
        for r in merge_result:
            parent, child, was_created = r[0], r[1], r[2]
            key = (parent, child)
            if was_created and key not in seen:
                seen.add(key)
                created_pairs.append(key)

        edges_created = len(created_pairs)
        if not created_pairs:
            return (0, 0, endpoint_missing)

        # Query 3: bulk audit CREATE for newly-created edges.
        # Mirrors per-row action='taxonomy_added' / target_type_id=child.
        ts = _now_iso()
        # F2: pull audit workspace_id from the bound scope_provider when
        # available so audit-by-tenant queries match the per-row helper's
        # scoping; fall back to the caller-passed workspace_id.
        audit_ws_id = self._audit_workspace_id(workspace_id)
        audit_rows = [
            {
                "audit_id": str(uuid4()),
                "ts": ts,
                "actor": actor,
                "target_type_id": child,
                # F6: json.dumps over f-string concatenation — inherits
                # escape-correctness for parent/child names containing
                # quotes or backslashes (rare but contractually possible).
                "after_json": json.dumps({
                    "parent": parent,
                    "child": child,
                    "edge_kind": "IS_A",
                }),
                "evidence_ref": evidence_ref or "",
                "workspace_id": audit_ws_id,
            }
            for (parent, child) in created_pairs
        ]
        audit_query = """
        UNWIND $audit_rows AS row
        CREATE (a:OntologyAudit {
            audit_id: row.audit_id,
            timestamp: row.ts,
            actor: row.actor,
            action: 'taxonomy_added',
            target_type_id: row.target_type_id,
            target_relation_id: NULL,
            target_pack_id: NULL,
            target_pack_version: NULL,
            before_json: NULL,
            after_json: row.after_json,
            evidence_ref: row.evidence_ref,
            workspace_id: row.workspace_id
        })
        """
        backend.query(
            audit_query, params={"audit_rows": audit_rows}, graph_name=graph_name
        )

        return (edges_created, len(audit_rows), endpoint_missing)

    # Per-branch Cypher for `_get_ontology_type` and the any-pack variant.
    # Keeping them as a class-level dict so the constrained-branch path and
    # the auto-branch path read from the same source of truth.
    @classmethod
    def _ot_lookup_cypher_in_slot(cls, branch: str) -> str:
        return {
            "iri": "MATCH (n:OntologyType {iri: $id, layer: $layer, workspace_id: $ws}) "
            "WHERE coalesce(n.pack_id, '') = $pack_id "
            f"RETURN {cls._ONTO_TYPE_RETURN} LIMIT 1",
            "qid": "MATCH (n:OntologyType {wikidata_qid: $id, layer: $layer, workspace_id: $ws}) "
            "WHERE coalesce(n.pack_id, '') = $pack_id "
            f"RETURN {cls._ONTO_TYPE_RETURN} LIMIT 1",
            "name": "MATCH (n:OntologyType {name: $id, layer: $layer, workspace_id: $ws}) "
            "WHERE n.iri IS NULL AND n.wikidata_qid IS NULL "
            "AND coalesce(n.pack_id, '') = $pack_id "
            f"RETURN {cls._ONTO_TYPE_RETURN} LIMIT 1",
        }[branch]

    @classmethod
    def _ot_lookup_cypher_any_pack(cls, branch: str) -> str:
        # ORDER BY n.pack_id is the determinism anchor when multiple packs
        # contribute the same identifier within a layer — without it the
        # FalkorDB result order is implementation-defined.
        return {
            "iri": "MATCH (n:OntologyType {iri: $id, layer: $layer, workspace_id: $ws}) "
            f"RETURN {cls._ONTO_TYPE_RETURN} ORDER BY n.pack_id LIMIT 1",
            "qid": "MATCH (n:OntologyType {wikidata_qid: $id, layer: $layer, workspace_id: $ws}) "
            f"RETURN {cls._ONTO_TYPE_RETURN} ORDER BY n.pack_id LIMIT 1",
            "name": "MATCH (n:OntologyType {name: $id, layer: $layer, workspace_id: $ws}) "
            "WHERE n.iri IS NULL AND n.wikidata_qid IS NULL "
            f"RETURN {cls._ONTO_TYPE_RETURN} ORDER BY n.pack_id LIMIT 1",
        }[branch]

    def _get_ontology_type(
        self,
        identifier: str,
        layer: str,
        workspace_id: str,
        pack_id: Optional[str] = None,
        *,
        key: Optional[str] = None,
    ):
        """Resolve a single `:OntologyType` within an EXACT slot.

        Slot = `(layer, workspace_id, pack_id)`. `pack_id=None` matches
        the no-pack slot (rows whose `pack_id` is NULL or empty). To
        search across all packs in a layer, use
        `_get_ontology_type_any_pack`; that is the resolver's domain
        path when no `installed_packs` is supplied.

        `key` constrains the identity branch:
        - `None` (default): try iri → qid → name in priority order.
        - `"iri"` / `"qid"` / `"name"`: only that branch. Required by
          `LayerResolver.resolve_by_identity` so an iri lookup can never
          fall through to qid or composite-name.
        """
        backend = self._get_backend()
        branches = (key,) if key is not None else ("iri", "qid", "name")
        params: Dict[str, Any] = {
            "id": identifier,
            "layer": layer,
            "ws": workspace_id,
            "pack_id": pack_id or "",
        }
        for branch in branches:
            cypher = self._ot_lookup_cypher_in_slot(branch)
            try:
                rows = backend.query(cypher, params=params, graph_name=self._graph_name)
            except Exception as e:
                logger.debug("OntologyType lookup by %s failed: %s", branch, e)
                continue
            if rows:
                return self._ot_decode_row(rows[0], self._ONTO_TYPE_COLS)
        return None

    def _get_ontology_type_any_pack(
        self,
        identifier: str,
        layer: str,
        workspace_id: str,
        *,
        key: Optional[str] = None,
    ):
        """Resolve a `:OntologyType` in a layer, ignoring `pack_id` slot.

        Used by `LayerResolver` for the domain-layer read when the caller
        supplies `installed_packs=None` (transitional, until Task 2e
        ships `:PackInstallation`). Result is deterministic via
        `ORDER BY n.pack_id`.
        """
        backend = self._get_backend()
        branches = (key,) if key is not None else ("iri", "qid", "name")
        params: Dict[str, Any] = {
            "id": identifier,
            "layer": layer,
            "ws": workspace_id,
        }
        for branch in branches:
            cypher = self._ot_lookup_cypher_any_pack(branch)
            try:
                rows = backend.query(cypher, params=params, graph_name=self._graph_name)
            except Exception as e:
                logger.debug("OntologyType any-pack lookup by %s failed: %s", branch, e)
                continue
            if rows:
                return self._ot_decode_row(rows[0], self._ONTO_TYPE_COLS)
        return None

    def _list_ontology_types_for_priming(
        self,
        *,
        workspace_id: str,
        tier: str = "confirmed",
        limit: int,
    ) -> List[Dict[str, Any]]:
        """Projected, frequency-ranked list for `priming_payload`.

        Codex Phase 3 Round 3 Finding K (Task 12f). Returns ONLY the
        fields priming needs (`name`, `wikidata_qid`, `aliases`,
        `frequency`, `tier`) rather than full `OntologyType` rows, and
        applies `ORDER BY frequency DESC, name ASC LIMIT $limit` at the
        Cypher layer so call cost is bounded by `limit`, not the full
        confirmed-tier set. Decode is local — `aliases` is JSON-encoded
        on write per the FalkorDB list-prop convention
        (`feedback_falkordb_list_prop_read_deserialize_gap`).

        Returns a list of dicts keyed by the priming-payload contract
        (`name`, `iri`, `qid`, `aliases`, `tier`). The dicts mirror
        what `OntologyService.priming_payload` would produce after
        serialization, so callers can use the rows verbatim.
        """
        backend = self._get_backend()
        params = {"tier": tier, "workspace_id": workspace_id}
        cypher = (
            "MATCH (n:OntologyType) "
            "WHERE n.tier = $tier AND n.workspace_id = $workspace_id "
            "RETURN n.name AS name, n.iri AS iri, n.wikidata_qid AS qid, "
            "n.aliases AS aliases, n.tier AS tier, "
            "COALESCE(n.frequency, 0) AS frequency "
            "ORDER BY frequency DESC, n.name ASC "
            f"LIMIT {int(limit)}"
        )
        try:
            rows = backend.query(cypher, params=params, graph_name=self._graph_name)
        except Exception as e:
            logger.warning("Failed to list priming OntologyType rows: %s", e)
            return []
        # Codex Phase 4 Task 12f Round 1 Finding M: validate projected
        # rows explicitly per `feedback_no_silent_fallbacks`. Malformed
        # rows (wrong shape, missing/empty `name`) are dropped with a
        # WARNING — silent skip would hide storage corruption and
        # leak empty-name types into LLM prompts. Alias JSON-decode
        # failures also log at WARNING rather than substituting `[]`
        # silently.
        out: List[Dict[str, Any]] = []
        for row in rows or []:
            try:
                name, iri, qid, aliases_raw, tier_val, _freq = row
            except (TypeError, ValueError) as e:
                logger.warning(
                    "priming row malformed (expected 6 columns, got %r): %s",
                    row,
                    e,
                )
                continue
            # Codex Phase 4 Task 12f Round 2 Finding P: tighten name
            # validation. `if not name` catches None / "" but lets
            # whitespace-only ("   ") through, which would render as
            # an empty bullet in the LLM prompt. Reject when stripped
            # name is empty.
            if name is None or not str(name).strip():
                logger.warning(
                    "priming row dropped: missing/empty/whitespace-only name in workspace %r (raw=%r)",
                    workspace_id,
                    name,
                )
                continue
            aliases: List[str] = []
            # Codex Phase 4 Task 12f Round 2 Finding P: branch on
            # `is not None` rather than truthiness so empty-string
            # alias payloads are caught and warned about rather than
            # silently normalized to []. JSON-encoded lists are never
            # empty strings — that's storage corruption.
            if aliases_raw is not None:
                if isinstance(aliases_raw, str) and not aliases_raw.strip():
                    logger.warning(
                        "priming row %r: empty/whitespace aliases_raw — treating as no aliases (storage corruption?)",
                        name,
                    )
                else:
                    try:
                        decoded = json.loads(aliases_raw) if isinstance(aliases_raw, str) else aliases_raw
                        if isinstance(decoded, list):
                            for a in decoded:
                                if isinstance(a, str):
                                    aliases.append(a)
                                else:
                                    logger.warning(
                                        "priming row %r: dropping non-string alias element of type %s",
                                        name,
                                        type(a).__name__,
                                    )
                        else:
                            logger.warning(
                                "priming row %r: aliases decoded to non-list %r; ignoring",
                                name,
                                type(decoded).__name__,
                            )
                    except (json.JSONDecodeError, TypeError) as e:
                        logger.warning(
                            "priming row %r: aliases JSON decode failed (%s); ignoring",
                            name,
                            e,
                        )
            out.append(
                {
                    "name": name,
                    "iri": iri,
                    "qid": qid,
                    "aliases": aliases,
                    "tier": tier_val or tier,
                    "frequency": _freq or 0,
                }
            )
        return out

    def _list_ontology_types(
        self,
        *,
        tier: Optional[str] = None,
        layer: Optional[str] = None,
        pack_id: Optional[str] = None,
        workspace_id: Optional[str] = None,
        has_iri: Optional[bool] = None,
        limit: Optional[int] = None,
    ) -> List[Any]:
        """Index-backed list of `:OntologyType` rows with filter combinations.

        `has_iri`: True → only iri-anchored; False → only local-identity
        (no iri); None → no filter. Matches the `OntologyService.list_types`
        public surface.
        """
        backend = self._get_backend()
        clauses: List[str] = []
        params: Dict[str, Any] = {}
        if tier is not None:
            clauses.append("n.tier = $tier")
            params["tier"] = tier
        if layer is not None:
            clauses.append("n.layer = $layer")
            params["layer"] = layer
        if pack_id is not None:
            clauses.append("coalesce(n.pack_id, '') = $pack_id")
            params["pack_id"] = pack_id
        if workspace_id is not None:
            clauses.append("n.workspace_id = $workspace_id")
            params["workspace_id"] = workspace_id
        if has_iri is True:
            clauses.append("n.iri IS NOT NULL")
        elif has_iri is False:
            clauses.append("n.iri IS NULL")
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        cypher = f"MATCH (n:OntologyType) {where} RETURN {self._ONTO_TYPE_RETURN} ORDER BY n.name"
        if limit is not None:
            cypher += f" LIMIT {int(limit)}"
        try:
            rows = backend.query(cypher, params=params, graph_name=self._graph_name)
        except Exception as e:
            logger.warning("Failed to list OntologyType rows: %s", e)
            return []
        out = []
        for row in rows or []:
            decoded = self._ot_decode_row(row, self._ONTO_TYPE_COLS)
            if decoded is not None:
                out.append(decoded)
        return out

    def _increment_frequency(self, identifier: str, weight: int = 1) -> None:
        """Atomically increment `frequency` on the type matching `identifier`.

        Resolves identifier via the same identity rule as `_get_ontology_type`.
        Workspace defaults to the graph's bound workspace; intra-graph
        ambiguity (same identifier in multiple layers/packs) updates every
        match — frequency tracks total observations regardless of slot.
        """
        backend = self._get_backend()
        try:
            backend.query(
                "MATCH (n:OntologyType) "
                "WHERE n.iri = $id OR n.wikidata_qid = $id "
                "OR (n.iri IS NULL AND n.wikidata_qid IS NULL AND n.name = $id) "
                "SET n.frequency = coalesce(n.frequency, 0) + $w",
                params={"id": identifier, "w": int(weight)},
                graph_name=self._graph_name,
            )
        except Exception as e:
            logger.warning("Failed to increment OntologyType frequency for '%s': %s", identifier, e)

    def _drop_pack_version(self, pack_id: str, pack_version: str) -> int:
        """Remove every `:OntologyType` whose `(pack_id, pack_version)` matches.

        Returns the number of nodes removed (best-effort — on error returns 0
        and logs). Used by pack upgrade flow to vacate the old version
        before the new one is installed.
        """
        backend = self._get_backend()
        try:
            pre = backend.query(
                "MATCH (n:OntologyType {pack_id: $pid, pack_version: $pv}) RETURN count(n) AS n",
                params={"pid": pack_id, "pv": pack_version},
                graph_name=self._graph_name,
            )
            count = 0
            if pre:
                row = pre[0] if isinstance(pre, list) else pre
                count = int(row[0]) if isinstance(row, (list, tuple)) and row else int(row)
            backend.query(
                "MATCH (n:OntologyType {pack_id: $pid, pack_version: $pv}) DETACH DELETE n",
                params={"pid": pack_id, "pv": pack_version},
                graph_name=self._graph_name,
            )
            return count
        except Exception as e:
            logger.warning("Failed to drop OntologyType pack version %s/%s: %s", pack_id, pack_version, e)
            return 0

    # ------------------------------------------------------------------ #
    # ONTO-RECONCILE-1 Phase 4 Task 12b — IS_A taxonomy edges
    # ------------------------------------------------------------------ #

    def _upsert_taxonomy_edge(
        self,
        *,
        parent_name: str,
        child_name: str,
        workspace_id: str,
        source: str,
        evidence_ref: str | None = None,
    ) -> bool:
        """MERGE an IS_A edge between two `:OntologyType` nodes.

        Phase 4 Task 12b — Codex Phase 3 Round 1 Finding B follow-up.
        Replaces the `taxonomy_unmaterialized` warning from Phase 3
        with a substrate write. The edge direction is `child -> parent`
        (a `Dog` IS_A `Mammal`), matching the Wikidata P279 "subclass
        of" convention.

        Idempotent: MERGE semantics dedupe; calling twice with the
        same endpoints yields one edge. Returns `True` if the edge was
        newly created in this call, `False` if it already existed
        (replay path).

        If either endpoint is missing in the bound workspace, raises
        ValueError so the caller can surface the gap as a warning per
        `feedback_no_silent_fallbacks`. The substrate does NOT
        auto-create the endpoint nodes — callers must upsert types
        first (apply_changeset already does this for in-IR concepts).

        Args:
            parent_name: name of the parent `:OntologyType` node.
            child_name: name of the child `:OntologyType` node.
            workspace_id: scoping workspace; both endpoints must
                belong to it.
            source: provenance label written on the edge
                (`"batch"`, `"manual"`, `"imported_owl"`, etc).
            evidence_ref: optional reference (registry_id, doc_id)
                stored on the edge for audit.

        Returns:
            True if a new edge was created; False if it already
            existed.

        Raises:
            ValueError: if either endpoint is not present in the
                workspace.
        """
        backend = self._get_backend()
        # Pre-check: both endpoints must exist. Without this, MERGE on
        # a non-existent endpoint creates an empty `:OntologyType` node
        # (FalkorDB MERGE creates everything in the pattern). That
        # would silently corrupt the graph with placeholder rows.
        endpoint_check = backend.query(
            "MATCH (p:OntologyType {name: $parent, workspace_id: $ws}) "
            "MATCH (c:OntologyType {name: $child, workspace_id: $ws}) "
            "RETURN count(p) AS pn, count(c) AS cn",
            params={"parent": parent_name, "child": child_name, "ws": workspace_id},
            graph_name=self._graph_name,
        )
        if not endpoint_check or not endpoint_check[0] or endpoint_check[0][0] == 0 or endpoint_check[0][1] == 0:
            raise ValueError(
                f"_upsert_taxonomy_edge: endpoint missing in workspace "
                f"{workspace_id!r} (parent={parent_name!r}, child={child_name!r})"
            )

        # Detect existing edge first — needed to report `created` accurately.
        # MERGE alone gives no easy way to distinguish create vs match in
        # FalkorDB without ON CREATE timestamp introspection.
        existing = backend.query(
            "MATCH (c:OntologyType {name: $child, workspace_id: $ws})"
            "-[r:IS_A]->"
            "(p:OntologyType {name: $parent, workspace_id: $ws}) "
            "RETURN count(r) AS n",
            params={"parent": parent_name, "child": child_name, "ws": workspace_id},
            graph_name=self._graph_name,
        )
        already_present = bool(existing and existing[0] and existing[0][0] > 0)
        if already_present:
            return False

        backend.query(
            "MATCH (c:OntologyType {name: $child, workspace_id: $ws}) "
            "MATCH (p:OntologyType {name: $parent, workspace_id: $ws}) "
            "MERGE (c)-[r:IS_A]->(p) "
            "ON CREATE SET r.source = $source, r.evidence_ref = $evidence_ref, "
            "r.workspace_id = $ws, r.created_at = timestamp()",
            params={
                "parent": parent_name,
                "child": child_name,
                "ws": workspace_id,
                "source": source,
                "evidence_ref": evidence_ref or "",
            },
            graph_name=self._graph_name,
        )
        return True

    # ------------------------------------------------------------------ #
    # ONTO-RECONCILE-1 Task 2c — Unified `:OntologyRelation` storage
    # ------------------------------------------------------------------ #
    #
    # Mirror of the Task 2 block for relation types. Identity rule swaps
    # `wikidata_qid` → `wikidata_pid`; tier rank, JSON encoding, slot
    # semantics, branch constraint via `key=`, and any-pack determinism
    # all carry over identically. DOMAIN/RANGE/INVERSE_OF/SUB_PROPERTY_OF
    # graph edges (per plan Task 2c "Edges:") are deferred to Task 8
    # (apply_changeset) where types and relations land together — Task
    # 2c stores the linkages as JSON list properties on the relation node
    # (already in the dataclass: `domain`, `range`, `parent_relations`,
    # `inverse_of`).

    _ONTO_REL_LIST_FIELDS = (
        "aliases",
        "examples",
        "domain",
        "range",
        "parent_relations",
        "equivalent_relations",
        "evidence",
        "equivalent_iris",
    )
    _ONTO_REL_DICT_FIELDS = ("properties_schema",)

    def ensure_ontology_relation_indexes(self) -> None:
        """Create idempotent indexes for `:OntologyRelation`. Mirror of
        `ensure_ontology_type_indexes` with `wikidata_pid` in place of
        `wikidata_qid`."""
        backend = self._get_backend()
        statements = [
            "CREATE INDEX FOR (n:OntologyRelation) ON (n.name)",
            "CREATE INDEX FOR (n:OntologyRelation) ON (n.iri)",
            "CREATE INDEX FOR (n:OntologyRelation) ON (n.wikidata_pid)",
            "CREATE INDEX FOR (n:OntologyRelation) ON (n.tier)",
            "CREATE INDEX FOR (n:OntologyRelation) ON (n.layer)",
            "CREATE INDEX FOR (n:OntologyRelation) ON (n.pack_id)",
            # Phase 4 Task 14 audit: same gaps as :OntologyType.
            "CREATE INDEX FOR (n:OntologyRelation) ON (n.workspace_id)",
            "CREATE INDEX FOR (n:OntologyRelation) ON (n.pack_version)",
        ]
        for stmt in statements:
            try:
                backend.query(stmt, graph_name=self._graph_name)
            except Exception as e:
                logger.debug("OntologyRelation index already present or unsupported: %s", e)

    def _or_encode_props(self, rel) -> Dict[str, Any]:
        """Serialize an OntologyRelation dataclass to FalkorDB-friendly props."""
        from dataclasses import asdict

        raw = asdict(rel)
        props: Dict[str, Any] = {}
        for k, v in raw.items():
            if v is None:
                continue
            if k in self._ONTO_REL_LIST_FIELDS or k in self._ONTO_REL_DICT_FIELDS:
                props[k] = json.dumps(v)
            elif isinstance(v, datetime):
                props[k] = v.isoformat()
            else:
                props[k] = v
        return props

    def _or_decode_row(self, row: List[Any], cols: List[str]):
        """Reconstruct an OntologyRelation from a Cypher RETURN row."""
        from smartmemory.ontology.types import OntologyRelation

        data: Dict[str, Any] = dict(zip(cols, row, strict=False))
        for f in self._ONTO_REL_LIST_FIELDS:
            v = data.get(f)
            data[f] = json.loads(v) if v else []
        for f in self._ONTO_REL_DICT_FIELDS:
            v = data.get(f)
            data[f] = json.loads(v) if v else {}
        clean = {k: v for k, v in data.items() if v is not None}
        if "name" not in clean:
            return None
        return OntologyRelation(**clean)

    _ONTO_REL_RETURN = (
        "n.name AS name, n.iri AS iri, n.wikidata_pid AS wikidata_pid, "
        "n.display_name AS display_name, n.definition AS definition, "
        "n.description AS description, n.aliases AS aliases, n.examples AS examples, "
        "n.domain AS domain, n.range AS range, n.inverse_of AS inverse_of, "
        "n.cardinality AS cardinality, n.temporal AS temporal, "
        "n.properties_schema AS properties_schema, "
        "n.transitive AS transitive, n.symmetric AS symmetric, n.reflexive AS reflexive, "
        "n.parent_relations AS parent_relations, "
        "n.equivalent_relations AS equivalent_relations, "
        "n.equivalent_iris AS equivalent_iris, n.tier AS tier, "
        "n.trust_origin AS trust_origin, n.layer AS layer, n.pack_id AS pack_id, "
        "n.pack_version AS pack_version, n.workspace_id AS workspace_id, "
        "n.source AS source, n.evidence AS evidence, n.confidence AS confidence, "
        "n.frequency AS frequency, n.disambiguator AS disambiguator, "
        "n.created_by AS created_by, n.created_at AS created_at, "
        "n.updated_at AS updated_at"
    )
    _ONTO_REL_COLS = [
        "name",
        "iri",
        "wikidata_pid",
        "display_name",
        "definition",
        "description",
        "aliases",
        "examples",
        "domain",
        "range",
        "inverse_of",
        "cardinality",
        "temporal",
        "properties_schema",
        "transitive",
        "symmetric",
        "reflexive",
        "parent_relations",
        "equivalent_relations",
        "equivalent_iris",
        "tier",
        "trust_origin",
        "layer",
        "pack_id",
        "pack_version",
        "workspace_id",
        "source",
        "evidence",
        "confidence",
        "frequency",
        "disambiguator",
        "created_by",
        "created_at",
        "updated_at",
    ]

    @classmethod
    def _or_lookup_cypher_in_slot(cls, branch: str) -> str:
        return {
            "iri": "MATCH (n:OntologyRelation {iri: $id, layer: $layer, workspace_id: $ws}) "
            "WHERE coalesce(n.pack_id, '') = $pack_id "
            f"RETURN {cls._ONTO_REL_RETURN} LIMIT 1",
            "pid": "MATCH (n:OntologyRelation {wikidata_pid: $id, layer: $layer, workspace_id: $ws}) "
            "WHERE coalesce(n.pack_id, '') = $pack_id "
            f"RETURN {cls._ONTO_REL_RETURN} LIMIT 1",
            "name": "MATCH (n:OntologyRelation {name: $id, layer: $layer, workspace_id: $ws}) "
            "WHERE n.iri IS NULL AND n.wikidata_pid IS NULL "
            "AND coalesce(n.pack_id, '') = $pack_id "
            f"RETURN {cls._ONTO_REL_RETURN} LIMIT 1",
        }[branch]

    @classmethod
    def _or_lookup_cypher_any_pack(cls, branch: str) -> str:
        return {
            "iri": "MATCH (n:OntologyRelation {iri: $id, layer: $layer, workspace_id: $ws}) "
            f"RETURN {cls._ONTO_REL_RETURN} ORDER BY n.pack_id LIMIT 1",
            "pid": "MATCH (n:OntologyRelation {wikidata_pid: $id, layer: $layer, workspace_id: $ws}) "
            f"RETURN {cls._ONTO_REL_RETURN} ORDER BY n.pack_id LIMIT 1",
            "name": "MATCH (n:OntologyRelation {name: $id, layer: $layer, workspace_id: $ws}) "
            "WHERE n.iri IS NULL AND n.wikidata_pid IS NULL "
            f"RETURN {cls._ONTO_REL_RETURN} ORDER BY n.pack_id LIMIT 1",
        }[branch]

    def _upsert_ontology_relation(self, rel) -> None:
        """MERGE an `:OntologyRelation` per the identity rule.

        Identity priority: `iri` → `wikidata_pid` → composite
        `(name, layer, workspace_id, pack_id)`. Tier never demotes.
        Same external identifier (iri or pid) bound to a different
        `name` within the slot is rejected with ValueError.

        Same concurrency caveat as `_upsert_ontology_type`: read-then-
        write is not transactionally atomic. Bulk transactional path
        ships with Task 8 (`apply_changeset`).
        """
        backend = self._get_backend()
        props = self._or_encode_props(rel)
        if not props.get("workspace_id"):
            props["workspace_id"] = self.workspace_id
        layer = props.get("layer", "private")
        pack_id = props.get("pack_id")

        existing = None
        if rel.iri:
            rows = backend.query(
                "MATCH (n:OntologyRelation {iri: $iri, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(n.pack_id, '') = $pack_id "
                f"RETURN {self._ONTO_REL_RETURN}",
                params={
                    "iri": rel.iri,
                    "layer": layer,
                    "ws": props["workspace_id"],
                    "pack_id": pack_id or "",
                },
                graph_name=self._graph_name,
            )
            if rows:
                existing = self._or_decode_row(rows[0], self._ONTO_REL_COLS)
                if existing and existing.name != rel.name:
                    raise ValueError(
                        f"iri {rel.iri!r} already bound to relation {existing.name!r} "
                        f"in slot (layer={layer}, workspace={props['workspace_id']}, "
                        f"pack_id={pack_id}); refusing to bind to {rel.name!r}"
                    )
        elif rel.wikidata_pid:
            rows = backend.query(
                "MATCH (n:OntologyRelation {wikidata_pid: $pid, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(n.pack_id, '') = $pack_id "
                f"RETURN {self._ONTO_REL_RETURN}",
                params={
                    "pid": rel.wikidata_pid,
                    "layer": layer,
                    "ws": props["workspace_id"],
                    "pack_id": pack_id or "",
                },
                graph_name=self._graph_name,
            )
            if rows:
                existing = self._or_decode_row(rows[0], self._ONTO_REL_COLS)
                if existing and existing.name != rel.name:
                    raise ValueError(
                        f"wikidata_pid {rel.wikidata_pid!r} already bound to relation "
                        f"{existing.name!r} in slot (layer={layer}, "
                        f"workspace={props['workspace_id']}, pack_id={pack_id}); "
                        f"refusing to bind to {rel.name!r}"
                    )
        else:
            rows = backend.query(
                "MATCH (n:OntologyRelation {name: $name, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(n.pack_id, '') = $pack_id "
                "AND n.iri IS NULL AND n.wikidata_pid IS NULL "
                f"RETURN {self._ONTO_REL_RETURN}",
                params={
                    "name": rel.name,
                    "layer": layer,
                    "ws": props["workspace_id"],
                    "pack_id": pack_id or "",
                },
                graph_name=self._graph_name,
            )
            if rows:
                existing = self._or_decode_row(rows[0], self._ONTO_REL_COLS)

        # Tier monotonicity (reuses the type tier rank — same DAG).
        if existing is not None:
            existing_rank = self._ONTO_TYPE_TIER_RANK.get(existing.tier, 0)
            new_rank = self._ONTO_TYPE_TIER_RANK.get(rel.tier, 0)
            if existing_rank > new_rank:
                props["tier"] = existing.tier

        if existing is None:
            backend.query(
                "CREATE (n:OntologyRelation) SET n = $props",
                params={"props": props},
                graph_name=self._graph_name,
            )
        else:
            if rel.iri:
                backend.query(
                    "MATCH (n:OntologyRelation {iri: $iri, layer: $layer, workspace_id: $ws}) "
                    "WHERE coalesce(n.pack_id, '') = $pack_id SET n += $props",
                    params={
                        "iri": rel.iri,
                        "layer": layer,
                        "ws": props["workspace_id"],
                        "pack_id": pack_id or "",
                        "props": props,
                    },
                    graph_name=self._graph_name,
                )
            elif rel.wikidata_pid:
                backend.query(
                    "MATCH (n:OntologyRelation {wikidata_pid: $pid, layer: $layer, workspace_id: $ws}) "
                    "WHERE coalesce(n.pack_id, '') = $pack_id SET n += $props",
                    params={
                        "pid": rel.wikidata_pid,
                        "layer": layer,
                        "ws": props["workspace_id"],
                        "pack_id": pack_id or "",
                        "props": props,
                    },
                    graph_name=self._graph_name,
                )
            else:
                backend.query(
                    "MATCH (n:OntologyRelation {name: $name, layer: $layer, workspace_id: $ws}) "
                    "WHERE coalesce(n.pack_id, '') = $pack_id "
                    "AND n.iri IS NULL AND n.wikidata_pid IS NULL "
                    "SET n += $props",
                    params={
                        "name": rel.name,
                        "layer": layer,
                        "ws": props["workspace_id"],
                        "pack_id": pack_id or "",
                        "props": props,
                    },
                    graph_name=self._graph_name,
                )

    def _get_ontology_relation(
        self,
        identifier: str,
        layer: str,
        workspace_id: str,
        pack_id: Optional[str] = None,
        *,
        key: Optional[str] = None,
    ):
        """Resolve a single `:OntologyRelation` within an EXACT slot.

        Same slot semantics as `_get_ontology_type`. `key`:
        `None` (auto: iri → pid → name) | `"iri"` | `"pid"` | `"name"`.
        """
        backend = self._get_backend()
        branches = (key,) if key is not None else ("iri", "pid", "name")
        params: Dict[str, Any] = {
            "id": identifier,
            "layer": layer,
            "ws": workspace_id,
            "pack_id": pack_id or "",
        }
        for branch in branches:
            cypher = self._or_lookup_cypher_in_slot(branch)
            try:
                rows = backend.query(cypher, params=params, graph_name=self._graph_name)
            except Exception as e:
                logger.debug("OntologyRelation lookup by %s failed: %s", branch, e)
                continue
            if rows:
                return self._or_decode_row(rows[0], self._ONTO_REL_COLS)
        return None

    def _get_ontology_relation_any_pack(
        self,
        identifier: str,
        layer: str,
        workspace_id: str,
        *,
        key: Optional[str] = None,
    ):
        """Resolve a `:OntologyRelation` in a layer, ignoring `pack_id` slot.

        Used by `LayerResolver.resolve_relation_*` when no `installed_packs`
        is supplied. Result is deterministic via `ORDER BY n.pack_id`.
        """
        backend = self._get_backend()
        branches = (key,) if key is not None else ("iri", "pid", "name")
        params: Dict[str, Any] = {
            "id": identifier,
            "layer": layer,
            "ws": workspace_id,
        }
        for branch in branches:
            cypher = self._or_lookup_cypher_any_pack(branch)
            try:
                rows = backend.query(cypher, params=params, graph_name=self._graph_name)
            except Exception as e:
                logger.debug("OntologyRelation any-pack lookup by %s failed: %s", branch, e)
                continue
            if rows:
                return self._or_decode_row(rows[0], self._ONTO_REL_COLS)
        return None

    def _list_ontology_relations(
        self,
        *,
        tier: Optional[str] = None,
        layer: Optional[str] = None,
        pack_id: Optional[str] = None,
        workspace_id: Optional[str] = None,
        has_iri: Optional[bool] = None,
        limit: Optional[int] = None,
    ) -> List[Any]:
        """Index-backed list of `:OntologyRelation` rows. Mirror of
        `_list_ontology_types`; `has_iri` is the only iri-aware filter
        (no `has_pid` — Task 2c keeps the surface symmetrical with types
        and adds Wikidata-specific filters only if a real caller needs
        them)."""
        backend = self._get_backend()
        clauses: List[str] = []
        params: Dict[str, Any] = {}
        if tier is not None:
            clauses.append("n.tier = $tier")
            params["tier"] = tier
        if layer is not None:
            clauses.append("n.layer = $layer")
            params["layer"] = layer
        if pack_id is not None:
            clauses.append("coalesce(n.pack_id, '') = $pack_id")
            params["pack_id"] = pack_id
        if workspace_id is not None:
            clauses.append("n.workspace_id = $workspace_id")
            params["workspace_id"] = workspace_id
        if has_iri is True:
            clauses.append("n.iri IS NOT NULL")
        elif has_iri is False:
            clauses.append("n.iri IS NULL")
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        cypher = f"MATCH (n:OntologyRelation) {where} RETURN {self._ONTO_REL_RETURN} ORDER BY n.name"
        if limit is not None:
            cypher += f" LIMIT {int(limit)}"
        try:
            rows = backend.query(cypher, params=params, graph_name=self._graph_name)
        except Exception as e:
            logger.warning("Failed to list OntologyRelation rows: %s", e)
            return []
        out = []
        for row in rows or []:
            decoded = self._or_decode_row(row, self._ONTO_REL_COLS)
            if decoded is not None:
                out.append(decoded)
        return out

    def _upsert_inline_ontology_relation_observation(self, name: str, confidence: float) -> None:
        """Single-Cypher upsert for hot-path inline relation observations.

        ONTO-RELFREQ-MIGRATE-1 (2026-05-04): replaces the legacy two-call
        pair (`add_provisional_relation_type` + `increment_relation_frequency`)
        which wrote `:RelationType`. Inline observations have only a name
        — no `iri` or `wikidata_pid` until grounding fires — so identity
        is `(name, layer='private', workspace_id)`.

        Frequency semantic matches the legacy
        `OntologyGraph.increment_relation_frequency` exactly: `+1` per
        observation, regardless of `confidence`. The `confidence`
        parameter is preserved for signature compatibility with the
        legacy contract and is currently unused (mirrors
        `SQLiteOntologyStore.increment_relation_frequency`). Storing
        confidence as a separate field is deferred — there's no consumer
        that reads it today.

        Schema on first create:
            tier='working', source='inline', layer='private',
            workspace_id=self.workspace_id, frequency=1, last_seen=now.

        Schema on subsequent calls:
            frequency = coalesce(existing, 0) + 1, last_seen = now.
            tier/source/layer/workspace_id are never re-set (tier
            monotonicity preserved, identity stable).
        """
        if not name:
            return
        _ = confidence  # accepted for legacy-signature parity; intentionally unused
        backend = self._get_backend()
        try:
            backend.query(
                "MERGE (n:OntologyRelation {"
                "name: $name, layer: 'private', workspace_id: $ws"
                "}) "
                "ON CREATE SET n.tier = 'working', n.source = 'inline', "
                "    n.frequency = 1, n.last_seen = $now "
                "ON MATCH SET n.frequency = coalesce(n.frequency, 0) + 1, "
                "    n.last_seen = $now",
                params={
                    "name": name,
                    "ws": self.workspace_id,
                    "now": _now_iso(),
                },
                graph_name=self._graph_name,
            )
        except Exception as e:
            logger.warning(
                "Failed to upsert inline OntologyRelation observation for '%s': %s",
                name,
                e,
            )

    def _increment_relation_frequency(self, identifier: str, weight: int = 1) -> None:
        """Atomically increment `frequency` on the relation matching `identifier`.

        Resolves identifier via the same identity rule as
        `_get_ontology_relation`. Mirror of `_increment_frequency` with
        `wikidata_pid` in place of `wikidata_qid`.
        """
        backend = self._get_backend()
        try:
            backend.query(
                "MATCH (n:OntologyRelation) "
                "WHERE n.iri = $id OR n.wikidata_pid = $id "
                "OR (n.iri IS NULL AND n.wikidata_pid IS NULL AND n.name = $id) "
                "SET n.frequency = coalesce(n.frequency, 0) + $w",
                params={"id": identifier, "w": int(weight)},
                graph_name=self._graph_name,
            )
        except Exception as e:
            logger.warning("Failed to increment OntologyRelation frequency for '%s': %s", identifier, e)

    def _drop_relation_pack_version(self, pack_id: str, pack_version: str) -> int:
        """Remove every `:OntologyRelation` whose `(pack_id, pack_version)` matches."""
        backend = self._get_backend()
        try:
            pre = backend.query(
                "MATCH (n:OntologyRelation {pack_id: $pid, pack_version: $pv}) RETURN count(n) AS n",
                params={"pid": pack_id, "pv": pack_version},
                graph_name=self._graph_name,
            )
            count = 0
            if pre:
                row = pre[0] if isinstance(pre, list) else pre
                count = int(row[0]) if isinstance(row, (list, tuple)) and row else int(row)
            backend.query(
                "MATCH (n:OntologyRelation {pack_id: $pid, pack_version: $pv}) DETACH DELETE n",
                params={"pid": pack_id, "pv": pack_version},
                graph_name=self._graph_name,
            )
            return count
        except Exception as e:
            logger.warning("Failed to drop OntologyRelation pack version %s/%s: %s", pack_id, pack_version, e)
            return 0

    # ------------------------------------------------------------------ #
    # ONTO-RECONCILE-1 Task 2d — :Entity ↔ :OntologyType linkage
    # ------------------------------------------------------------------ #
    #
    # FalkorDB graphs are isolated databases — `:Entity` lives in the data
    # graph, `:OntologyType` lives in this per-workspace ontology graph.
    # Cross-graph edges aren't possible. The substrate mirrors a minimal
    # `:Entity {item_id, workspace_id}` stub here and creates the
    # `INSTANCE_OF` edge intra-graph. The real entity in the data graph
    # is untouched. This mirrors the legacy
    # `:EntityPattern -[:IS_INSTANCE_OF]-> :EntityType` shape but with
    # the unified label and a cleaner edge name.

    def _link_entity_to_type(self, entity_id: str, type_obj) -> None:
        """MERGE `(:Entity {item_id})-[:INSTANCE_OF]->(:OntologyType {…})`.

        `type_obj` is an already-resolved `OntologyType` dataclass — the
        service does layer/identity resolution before calling. We use the
        resolved type's strongest identity key (iri → qid → composite
        slot) to anchor the MATCH so the edge always points at exactly
        the row the resolver picked.

        Idempotent: replay creates no duplicate edges.
        """
        backend = self._get_backend()
        ws = type_obj.workspace_id or self.workspace_id
        layer = type_obj.layer or "private"
        pack_id = type_obj.pack_id or ""

        # Choose the MATCH clause that pins the type by its strongest
        # identity. Every branch keeps the slot guard so we never link
        # to a same-iri/same-qid row in a different slot.
        if type_obj.iri:
            match_type = (
                "MATCH (t:OntologyType {iri: $iri, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(t.pack_id, '') = $pack_id"
            )
            params: Dict[str, Any] = {
                "iri": type_obj.iri,
                "layer": layer,
                "ws": ws,
                "pack_id": pack_id,
            }
        elif type_obj.wikidata_qid:
            match_type = (
                "MATCH (t:OntologyType {wikidata_qid: $qid, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(t.pack_id, '') = $pack_id"
            )
            params = {
                "qid": type_obj.wikidata_qid,
                "layer": layer,
                "ws": ws,
                "pack_id": pack_id,
            }
        else:
            match_type = (
                "MATCH (t:OntologyType {name: $name, layer: $layer, workspace_id: $ws}) "
                "WHERE t.iri IS NULL AND t.wikidata_qid IS NULL "
                "AND coalesce(t.pack_id, '') = $pack_id"
            )
            params = {
                "name": type_obj.name,
                "layer": layer,
                "ws": ws,
                "pack_id": pack_id,
            }

        params["eid"] = entity_id
        params["entity_ws"] = ws
        # `WITH t LIMIT 1` defends against degenerate duplicate-row state in
        # the same slot (the documented non-atomic upsert race in
        # `_upsert_ontology_type`). Without it, a MATCH that bound N rows
        # would MERGE N parallel INSTANCE_OF edges. The LIMIT pins the edge
        # to exactly one type per call. The duplicate case itself is a
        # storage bug Task 8's transactional path will eliminate; this is
        # defense-in-depth.
        cypher = (
            f"{match_type} "
            "WITH t LIMIT 1 "
            "MERGE (e:Entity {item_id: $eid}) "
            "ON CREATE SET e.workspace_id = $entity_ws "
            "MERGE (e)-[:INSTANCE_OF]->(t)"
        )
        # No try/except wrapper. The service's `link_instance_to_type`
        # already absorbs the "type absent" case via resolver pre-check;
        # backend write failures are real errors and must propagate so
        # callers can decide (retry, surface to UI). Conflating the two
        # would silence real outages.
        backend.query(cypher, params=params, graph_name=self._graph_name)

    # ------------------------------------------------------------------ #
    # ONTO-RECONCILE-1 Task 3 — tier-update by identity
    # ------------------------------------------------------------------ #

    def _set_ontology_type_tier(self, type_obj, new_tier: str) -> None:
        """SET `tier = $new_tier` on the row matching `type_obj`'s identity.

        Mirror of `_link_entity_to_type`'s identity-pinning pattern:
        the caller (OntologyService.transition) has already resolved
        the type via LayerResolver, so we MATCH on whatever its
        strongest identity is (iri → qid → composite slot). `WITH t
        LIMIT 1` defends against degenerate duplicate-row state from
        the documented non-atomic upsert race.

        No try/except — backend write failures propagate per Task 2d's
        no-silent-swallow rule. The service does the validator pre-
        check so "illegal transition" never reaches this method.
        """
        backend = self._get_backend()
        ws = type_obj.workspace_id or self.workspace_id
        layer = type_obj.layer or "private"
        pack_id = type_obj.pack_id or ""

        if type_obj.iri:
            match_type = (
                "MATCH (t:OntologyType {iri: $iri, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(t.pack_id, '') = $pack_id"
            )
            params: Dict[str, Any] = {
                "iri": type_obj.iri,
                "layer": layer,
                "ws": ws,
                "pack_id": pack_id,
            }
        elif type_obj.wikidata_qid:
            match_type = (
                "MATCH (t:OntologyType {wikidata_qid: $qid, layer: $layer, workspace_id: $ws}) "
                "WHERE coalesce(t.pack_id, '') = $pack_id"
            )
            params = {
                "qid": type_obj.wikidata_qid,
                "layer": layer,
                "ws": ws,
                "pack_id": pack_id,
            }
        else:
            match_type = (
                "MATCH (t:OntologyType {name: $name, layer: $layer, workspace_id: $ws}) "
                "WHERE t.iri IS NULL AND t.wikidata_qid IS NULL "
                "AND coalesce(t.pack_id, '') = $pack_id"
            )
            params = {
                "name": type_obj.name,
                "layer": layer,
                "ws": ws,
                "pack_id": pack_id,
            }

        params["new_tier"] = new_tier
        backend.query(
            f"{match_type} WITH t LIMIT 1 SET t.tier = $new_tier",
            params=params,
            graph_name=self._graph_name,
        )

    # ------------------------------------------------------------------ #
    # ONTO-RECONCILE-1 Task 3b — Evidence accumulation on :OntologyType
    # ------------------------------------------------------------------ #
    #
    # The unified Promoter (`smartmemory/ontology/promoter.py`) reads
    # accumulated evidence to decide whether a type can promote from
    # `working` → `proposed`. Evidence is stored as additional properties
    # on the same `:OntologyType` row (no `:Evidence` proliferation):
    #
    #   frequency               (int — already maintained by Task 2)
    #   confidence_sum          (float — running sum of LLM confidences)
    #   confidence_count        (int — observations contributing to sum)
    #   mention_distribution_json (JSON dict {entity_mention: count})
    #   evidence_refs_json      (JSON list of caller-supplied refs)
    #   hearst_hits_json        (JSON list of dict)
    #   cohesion                (float — corpus-level batch signal)
    #
    # Same identity-resolution rule as `_increment_frequency`
    # (iri OR qid OR composite-name within slot). Same documented race
    # window on read-then-write of JSON-string properties — bulk
    # transactional path lands with Task 8.
    #
    # Workspace + layer pinning: evidence is always private-layer for the
    # bound workspace. Cross-workspace observations don't aggregate.

    _EVIDENCE_DEFAULTS = {
        "frequency": 0,
        "confidence_sum": 0.0,
        "confidence_count": 0,
        "mention_distribution": {},
        "evidence_refs": [],
        "hearst_hits": [],
        "cohesion": None,
    }

    def _evidence_match_clause(self, identifier: str, workspace_id: str) -> tuple[str, Dict[str, Any]]:
        """Build a private-layer MATCH for an OntologyType by identifier.

        Mirrors `_increment_frequency`'s identifier disjunction so the
        Promoter can read/write evidence by whichever identity branch the
        observation supplied. Pinned to `layer = "private"` because evidence
        is workspace-local — domain/public layers are read-only at the
        ontology level (their evidence belongs to whoever owns the pack).
        """
        cypher = (
            "MATCH (n:OntologyType) "
            "WHERE n.layer = 'private' AND n.workspace_id = $ws "
            "AND (n.iri = $id OR n.wikidata_qid = $id "
            "     OR (n.iri IS NULL AND n.wikidata_qid IS NULL AND n.name = $id))"
        )
        return cypher, {"id": identifier, "ws": workspace_id}

    def _record_observation_evidence(
        self,
        identifier: str,
        *,
        workspace_id: str,
        mention: str | None = None,
        confidence: float = 0.0,
        evidence_ref: str | None = None,
        hearst_evidence: Dict[str, Any] | None = None,
    ) -> None:
        """Accumulate one observation's signals on the matching OntologyType.

        Reads current evidence props, mutates in-process, writes back.
        NOT atomic — concurrent observations on the same identifier can
        race. Same caveat as `_upsert_ontology_type`. Bulk transactional
        path lands with Task 8 (`apply_changeset`).
        """
        backend = self._get_backend()
        match, params = self._evidence_match_clause(identifier, workspace_id)

        # Read current state.
        rows = backend.query(
            match + " RETURN n.frequency AS frequency, n.confidence_sum AS confidence_sum, "
            "n.confidence_count AS confidence_count, "
            "n.mention_distribution_json AS mention_distribution_json, "
            "n.evidence_refs_json AS evidence_refs_json, "
            "n.hearst_hits_json AS hearst_hits_json LIMIT 1",
            params=params,
            graph_name=self._graph_name,
        )
        if not rows:
            # No matching private-layer row in this workspace — silent skip
            # is wrong here because the promoter's evidence is being
            # discarded. Log a warning per `feedback_no_silent_fallbacks`.
            logger.warning(
                "evidence: no private-layer OntologyType for identifier %r in workspace %r",
                identifier,
                workspace_id,
            )
            return
        row = rows[0]
        cur_freq = int(row[0] or 0)
        cur_sum = float(row[1] or 0.0)
        cur_count = int(row[2] or 0)
        cur_dist = json.loads(row[3]) if row[3] else {}
        cur_refs = json.loads(row[4]) if row[4] else []
        cur_hearst = json.loads(row[5]) if row[5] else []

        new_freq = cur_freq + 1
        new_sum = cur_sum + float(confidence or 0.0)
        new_count = cur_count + 1
        if mention:
            cur_dist[mention] = int(cur_dist.get(mention, 0)) + 1
        if evidence_ref:
            cur_refs.append(evidence_ref)
        if hearst_evidence:
            cur_hearst.append(hearst_evidence)

        write_params = {
            **params,
            "frequency": new_freq,
            "confidence_sum": new_sum,
            "confidence_count": new_count,
            "mention_distribution_json": json.dumps(cur_dist),
            "evidence_refs_json": json.dumps(cur_refs),
            "hearst_hits_json": json.dumps(cur_hearst),
        }
        backend.query(
            match + " WITH n LIMIT 1 SET n.frequency = $frequency, "
            "n.confidence_sum = $confidence_sum, "
            "n.confidence_count = $confidence_count, "
            "n.mention_distribution_json = $mention_distribution_json, "
            "n.evidence_refs_json = $evidence_refs_json, "
            "n.hearst_hits_json = $hearst_hits_json",
            params=write_params,
            graph_name=self._graph_name,
        )

    def _set_cohesion(self, identifier: str, *, workspace_id: str, cohesion: float) -> None:
        """Set the corpus-level cohesion score on the matching type.

        Used by the BatchObserver path — cohesion is a corpus signal
        (cluster compactness), not a per-observation accumulator.
        """
        backend = self._get_backend()
        match, params = self._evidence_match_clause(identifier, workspace_id)
        params["cohesion"] = float(cohesion)
        backend.query(
            match + " WITH n LIMIT 1 SET n.cohesion = $cohesion",
            params=params,
            graph_name=self._graph_name,
        )

    def _get_evidence_for_type(self, identifier: str, *, workspace_id: str) -> Dict[str, Any]:
        """Return the accumulated evidence dict, decoded.

        Returns a dict with keys matching `_EVIDENCE_DEFAULTS`. When the
        type doesn't exist (no matching private-layer row), returns the
        defaults — the Promoter then sees `frequency=0`/`confidence_count=0`
        and rejects on `min_frequency`. This is NOT a silent fallback in
        the bad sense: the promoter's gate is the explicit signal that
        evidence is insufficient.
        """
        backend = self._get_backend()
        match, params = self._evidence_match_clause(identifier, workspace_id)
        rows = backend.query(
            match + " RETURN n.frequency AS frequency, n.confidence_sum AS confidence_sum, "
            "n.confidence_count AS confidence_count, "
            "n.mention_distribution_json AS mention_distribution_json, "
            "n.evidence_refs_json AS evidence_refs_json, "
            "n.hearst_hits_json AS hearst_hits_json, "
            "n.cohesion AS cohesion LIMIT 1",
            params=params,
            graph_name=self._graph_name,
        )
        if not rows:
            return dict(self._EVIDENCE_DEFAULTS)
        r = rows[0]
        return {
            "frequency": int(r[0] or 0),
            "confidence_sum": float(r[1] or 0.0),
            "confidence_count": int(r[2] or 0),
            "mention_distribution": json.loads(r[3]) if r[3] else {},
            "evidence_refs": json.loads(r[4]) if r[4] else [],
            "hearst_hits": json.loads(r[5]) if r[5] else [],
            "cohesion": float(r[6]) if r[6] is not None else None,
        }

    # ------------------------------------------------------------------ #
    # ONTO-RECONCILE-1 Task 2e — :PackInstallation manifest
    # ------------------------------------------------------------------ #
    #
    # Records which packs (pack_id, pack_version) are installed in a
    # workspace. Pack CONTENT (`:OntologyType`/`:OntologyRelation` rows
    # with pack_id/pack_version) is separate — this label is only the
    # workspace-scoped manifest. Decoupling content from manifest lets
    # pack content be deduplicated across workspaces (future) without
    # changing the manifest model.
    #
    # `LayerResolver` consumes this manifest via the service's auto-
    # resolve path (OntologyService._installed_packs_for_workspace),
    # so callers don't need to pass installed_packs explicitly.

    def ensure_pack_installation_indexes(self) -> None:
        """Create idempotent indexes for `:PackInstallation`."""
        backend = self._get_backend()
        statements = [
            "CREATE INDEX FOR (n:PackInstallation) ON (n.workspace_id)",
            "CREATE INDEX FOR (n:PackInstallation) ON (n.pack_id)",
            # Phase 4 Task 14 audit: install_pack queries match on the
            # full (workspace_id, pack_id, pack_version) triple for
            # idempotency; install/uninstall paths benefit from
            # version-keyed lookup when multiple pack versions coexist.
            "CREATE INDEX FOR (n:PackInstallation) ON (n.pack_version)",
        ]
        for stmt in statements:
            try:
                backend.query(stmt, graph_name=self._graph_name)
            except Exception as e:
                logger.debug("PackInstallation index already present or unsupported: %s", e)

    def _record_pack_installation(
        self,
        workspace_id: str,
        pack_id: str,
        pack_version: str,
        *,
        installed_by: str,
        source: str,
    ) -> None:
        """MERGE a `:PackInstallation {workspace_id, pack_id, pack_version}`.

        `ON CREATE SET` writes installed_at/installed_by/source so a
        replay leaves the original installer's audit fields untouched
        (the original installation is the audit-relevant fact, not the
        replay). Mirrors the `Task 2d` ON CREATE SET pattern for the
        :Entity stub.
        """
        backend = self._get_backend()
        backend.query(
            "MERGE (p:PackInstallation {workspace_id: $ws, pack_id: $pid, pack_version: $pv}) "
            "ON CREATE SET p.installed_at = $ts, p.installed_by = $by, p.source = $source",
            params={
                "ws": workspace_id,
                "pid": pack_id,
                "pv": pack_version,
                "ts": _now_iso(),
                "by": installed_by,
                "source": source,
            },
            graph_name=self._graph_name,
        )

    def _remove_pack_installation(self, workspace_id: str, pack_id: str, pack_version: str) -> bool:
        """DETACH DELETE the matching `:PackInstallation` row.

        Returns True if a row was actually removed, False if no matching
        row existed (no-op). The service uses this signal to skip the
        audit write on a no-op uninstall — audit reflects what actually
        landed in the graph, not attempts.
        """
        backend = self._get_backend()
        # Pre-count so we can report an honest True/False without a
        # second round-trip to interpret the DELETE result.
        pre = backend.query(
            "MATCH (p:PackInstallation {workspace_id: $ws, pack_id: $pid, pack_version: $pv}) RETURN count(p) AS n",
            params={"ws": workspace_id, "pid": pack_id, "pv": pack_version},
            graph_name=self._graph_name,
        )
        match_count = 0
        if pre:
            row = pre[0] if isinstance(pre, list) else pre
            match_count = int(row[0]) if isinstance(row, (list, tuple)) and row else int(row)
        if match_count == 0:
            return False
        backend.query(
            "MATCH (p:PackInstallation {workspace_id: $ws, pack_id: $pid, pack_version: $pv}) DETACH DELETE p",
            params={"ws": workspace_id, "pid": pack_id, "pv": pack_version},
            graph_name=self._graph_name,
        )
        return True

    def _list_workspace_installations(self, workspace_id: str) -> List[Dict[str, Any]]:
        """Return rows for the workspace's installed packs.

        Each row: `{pack_id, pack_version, installed_at, installed_by, source}`.
        Ordered by pack_id then pack_version for deterministic output.
        """
        backend = self._get_backend()
        try:
            rows = backend.query(
                "MATCH (p:PackInstallation {workspace_id: $ws}) "
                "RETURN p.pack_id AS pack_id, p.pack_version AS pack_version, "
                "p.installed_at AS installed_at, p.installed_by AS installed_by, "
                "p.source AS source ORDER BY p.pack_id, p.pack_version",
                params={"ws": workspace_id},
                graph_name=self._graph_name,
            )
        except Exception as e:
            logger.warning("Failed to list pack installations for workspace '%s': %s", workspace_id, e)
            return []
        return [
            {
                "pack_id": r[0],
                "pack_version": r[1],
                "installed_at": r[2],
                "installed_by": r[3],
                "source": r[4],
            }
            for r in (rows or [])
        ]

    # ------------------------------------------------------------------ #
    # ONTO-RECONCILE-1 Task 2f — :OntologyAudit append-only log
    # ------------------------------------------------------------------ #
    #
    # Append-only by construction: `_write_audit_entry` uses CREATE,
    # never MERGE; there is no UPDATE/DELETE helper. PR-review enforces
    # the discipline at the call sites — no direct Cypher against
    # `:OntologyAudit` from outside `smartmemory/ontology/service.py`.
    # The substrate is the contract; mistakes can't accidentally rewrite
    # history because the substrate doesn't expose a write-update path.

    _ONTO_AUDIT_RETURN = (
        "a.audit_id AS audit_id, a.timestamp AS timestamp, "
        "a.actor AS actor, a.action AS action, "
        "a.target_type_id AS target_type_id, "
        "a.target_relation_id AS target_relation_id, "
        "a.target_pack_id AS target_pack_id, "
        "a.target_pack_version AS target_pack_version, "
        "a.before_json AS before_json, a.after_json AS after_json, "
        "a.evidence_ref AS evidence_ref"
    )
    _ONTO_AUDIT_COLS = [
        "audit_id",
        "timestamp",
        "actor",
        "action",
        "target_type_id",
        "target_relation_id",
        "target_pack_id",
        "target_pack_version",
        "before_json",
        "after_json",
        "evidence_ref",
    ]

    def ensure_ontology_audit_indexes(self) -> None:
        """Create idempotent indexes for `:OntologyAudit`."""
        backend = self._get_backend()
        statements = [
            "CREATE INDEX FOR (n:OntologyAudit) ON (n.timestamp)",
            "CREATE INDEX FOR (n:OntologyAudit) ON (n.actor)",
            "CREATE INDEX FOR (n:OntologyAudit) ON (n.target_type_id)",
            "CREATE INDEX FOR (n:OntologyAudit) ON (n.target_relation_id)",
            "CREATE INDEX FOR (n:OntologyAudit) ON (n.target_pack_id)",
            # Phase 4 Task 14 audit: pack-version-scoped audit queries
            # (install_pack history per version) match on the
            # (target_pack_id, target_pack_version) pair.
            "CREATE INDEX FOR (n:OntologyAudit) ON (n.target_pack_version)",
        ]
        for stmt in statements:
            try:
                backend.query(stmt, graph_name=self._graph_name)
            except Exception as e:
                logger.debug("OntologyAudit index already present or unsupported: %s", e)

    def _write_audit_entry(
        self,
        actor: str,
        action: str,
        *,
        target_type_id: Optional[str] = None,
        target_relation_id: Optional[str] = None,
        target_pack_id: Optional[str] = None,
        target_pack_version: Optional[str] = None,
        before_json: Optional[str] = None,
        after_json: Optional[str] = None,
        evidence_ref: Optional[str] = None,
    ) -> str:
        """CREATE one `:OntologyAudit` row. Returns the audit_id.

        Append-only: this is the ONLY write path, and it uses CREATE,
        never MERGE. There is no `_update_audit_entry` or
        `_delete_audit_entry` — by construction, a service call that
        accidentally wants to modify history has nothing to call.
        """
        backend = self._get_backend()
        from uuid import uuid4

        audit_id = str(uuid4())
        # `_now_iso()` is the same timestamp helper used elsewhere in
        # this module (relation frequency, novel labels), so audit
        # timestamps sort consistently with frequency last_seen.
        ts = _now_iso()
        # ONTO-AUDIT-WS-1 (2026-05-09): scope audit-log entries by tenant.
        # OntologyAudit was previously written without workspace_id, making
        # audit history cross-tenant by default. Filed during the
        # INSIGHTS-PROGRESS-MIGRATE-1 T2.0 audit (Category E: low-impact
        # gap — Insights does not surface audit logs per-tenant today,
        # but cross-tenant audit history will leak if/when it does).
        # NULL on OSS / system-internal calls is intentional: those are
        # global by design and should remain visible to all tenants.
        write_ctx = {}
        scope_provider = getattr(backend, "scope_provider", None)
        if scope_provider is not None:
            try:
                write_ctx = scope_provider.get_write_context() or {}
            except Exception:
                write_ctx = {}
        ws_id = write_ctx.get("workspace_id")
        # CREATE only — no MERGE/SET. None values are emitted as NULL
        # via Cypher's parameter binding so they aren't searchable
        # under `WHERE prop = 'something'` accidentally.
        backend.query(
            "CREATE (a:OntologyAudit {"
            "audit_id: $audit_id, timestamp: $ts, actor: $actor, action: $action, "
            "target_type_id: $tt, target_relation_id: $tr, "
            "target_pack_id: $tp, target_pack_version: $tpv, "
            "before_json: $bj, after_json: $aj, evidence_ref: $ev, "
            "workspace_id: $ws"
            "})",
            params={
                "audit_id": audit_id,
                "ts": ts,
                "actor": actor,
                "action": action,
                "tt": target_type_id,
                "tr": target_relation_id,
                "tp": target_pack_id,
                "tpv": target_pack_version,
                "bj": before_json,
                "aj": after_json,
                "ev": evidence_ref,
                "ws": ws_id,
            },
            graph_name=self._graph_name,
        )
        return audit_id

    def _decode_audit_row(self, row: List[Any]) -> Dict[str, Any]:
        return dict(zip(self._ONTO_AUDIT_COLS, row, strict=False))

    def _get_audit_for_type(self, type_id: str) -> List[Dict[str, Any]]:
        """Read audit entries targeting a specific type identifier.

        Returns chronologically-ordered list (oldest first). The
        `target_type_id` is whatever string the caller passed at write
        time (name/iri/qid) — substrate doesn't normalize, so the
        reader queries by the same identifier.
        """
        backend = self._get_backend()
        try:
            rows = backend.query(
                "MATCH (a:OntologyAudit {target_type_id: $tid}) "
                f"RETURN {self._ONTO_AUDIT_RETURN} ORDER BY a.timestamp",
                params={"tid": type_id},
                graph_name=self._graph_name,
            )
        except Exception as e:
            logger.warning("Failed to read audit for type '%s': %s", type_id, e)
            return []
        return [self._decode_audit_row(r) for r in (rows or [])]

    def _get_audit_for_relation(self, relation_id: str) -> List[Dict[str, Any]]:
        """Mirror of `_get_audit_for_type` for relation targets."""
        backend = self._get_backend()
        try:
            rows = backend.query(
                "MATCH (a:OntologyAudit {target_relation_id: $rid}) "
                f"RETURN {self._ONTO_AUDIT_RETURN} ORDER BY a.timestamp",
                params={"rid": relation_id},
                graph_name=self._graph_name,
            )
        except Exception as e:
            logger.warning("Failed to read audit for relation '%s': %s", relation_id, e)
            return []
        return [self._decode_audit_row(r) for r in (rows or [])]

    def _get_audit_for_pack(self, pack_id: str, pack_version: Optional[str] = None) -> List[Dict[str, Any]]:
        """Audit entries for a pack. `pack_version=None` matches every version."""
        backend = self._get_backend()
        if pack_version is None:
            cypher = (
                "MATCH (a:OntologyAudit {target_pack_id: $pid}) "
                f"RETURN {self._ONTO_AUDIT_RETURN} ORDER BY a.timestamp"
            )
            params: Dict[str, Any] = {"pid": pack_id}
        else:
            cypher = (
                "MATCH (a:OntologyAudit {target_pack_id: $pid, target_pack_version: $pv}) "
                f"RETURN {self._ONTO_AUDIT_RETURN} ORDER BY a.timestamp"
            )
            params = {"pid": pack_id, "pv": pack_version}
        try:
            rows = backend.query(cypher, params=params, graph_name=self._graph_name)
        except Exception as e:
            logger.warning("Failed to read audit for pack '%s': %s", pack_id, e)
            return []
        return [self._decode_audit_row(r) for r in (rows or [])]

    def _get_audit_summary(
        self,
        *,
        since: str,
        until: Optional[str] = None,
        recent_limit: int = 50,
    ) -> Dict[str, Any]:
        """ONTO-RECONCILE-1 Phase 6 — bounded audit aggregation over a time window.

        Lite-mode parity: this method re-raises ``UnsupportedBackendError``
        so the service-layer wrapper can surface the empty shape with a
        WARNING (per ``no-silent-degradation.md``).

        Two queries: a counts query grouped by ``(action, actor)``, and a
        bounded recent-actions query (``ORDER BY timestamp DESC LIMIT N``).
        The combined ``count + collect`` shape was rejected at design
        time because unbounded ``collect(...)`` materializes every
        matching row in memory before Python trims, which OOMs on
        workspaces with millions of audit rows.

        ``before_json``, ``after_json``, and ``evidence_ref`` are
        deliberately NOT projected — all three are caller-supplied
        content (e.g. ``evidence_ref`` carries ``verdict.reason``,
        ``entity_id``, ``registry_id``, or free-text reasons; see
        ``ontology/service.py`` write sites). Only metadata-shaped
        identifiers (``target_*_id``, ``timestamp``, ``actor``,
        ``action``) reach the response.

        Parameters
        ----------
        since : str
            ISO-8601 timestamp lower bound (inclusive).
        until : str | None
            ISO-8601 upper bound (inclusive). ``None`` for open-ended.
        recent_limit : int
            Cap on ``recent_actions`` rows. Default 50.

        Returns
        -------
        dict
            ``{"total_rows": int, "by_action": {action: n},
              "by_actor": {actor: n}, "recent_actions": [...],
              "since": str, "until": str | None}``
        """
        from smartmemory.backends.unsupported import UnsupportedBackendError  # local import — keeps top-level lean

        backend = self._get_backend()

        # Counts query — grouped by (action, actor) jointly.
        # The Python helper folds rows into total_rows / by_action /
        # by_actor with explicit accumulation (sum, not overwrite) so
        # one action split across multiple actors aggregates correctly.
        if until is None:
            counts_cypher = (
                "MATCH (a:OntologyAudit) "
                "WHERE a.timestamp >= $since "
                "RETURN a.action AS action, a.actor AS actor, count(a) AS n"
            )
            counts_params: Dict[str, Any] = {"since": since}
        else:
            counts_cypher = (
                "MATCH (a:OntologyAudit) "
                "WHERE a.timestamp >= $since AND a.timestamp <= $until "
                "RETURN a.action AS action, a.actor AS actor, count(a) AS n"
            )
            counts_params = {"since": since, "until": until}

        try:
            count_rows = backend.query(counts_cypher, params=counts_params, graph_name=self._graph_name)
        except UnsupportedBackendError:
            # Re-raise so the service layer's LITE-mode degradation handler
            # surfaces the empty shape with a WARNING (Codex round 1 #5).
            # Without this re-raise, the broad `except Exception` below
            # swallows it and the service-layer handler becomes dead code.
            raise
        except Exception as e:
            logger.warning("Failed counts query in _get_audit_summary: %s", e)
            count_rows = []

        total_rows = 0
        by_action: Dict[str, int] = {}
        by_actor: Dict[str, int] = {}
        for r in count_rows or []:
            if isinstance(r, dict):
                action = r.get("action") or ""
                actor = r.get("actor") or ""
                n = int(r.get("n") or 0)
            elif isinstance(r, list):
                action = r[0] if len(r) > 0 else ""
                actor = r[1] if len(r) > 1 else ""
                n = int(r[2]) if len(r) > 2 else 0
            else:
                continue
            total_rows += n
            by_action[action] = by_action.get(action, 0) + n
            by_actor[actor] = by_actor.get(actor, 0) + n

        # Recent-actions query — bounded LIMIT, projection excludes
        # caller-supplied content (no before_json / after_json / evidence_ref).
        # LIMIT inlined as a literal: FalkorDB historically rejects parameterized
        # LIMIT in some versions (Codex review round 1 finding #3). The
        # `int()` cast prevents injection; the route layer additionally
        # caps at 500 via Pydantic validation.
        lim = max(0, int(recent_limit))
        if until is None:
            recent_cypher = (
                "MATCH (a:OntologyAudit) "
                "WHERE a.timestamp >= $since "
                "RETURN a.action AS action, a.actor AS actor, a.timestamp AS timestamp, "
                "a.target_type_id AS target_type_id, "
                "a.target_relation_id AS target_relation_id, "
                "a.target_pack_id AS target_pack_id "
                f"ORDER BY a.timestamp DESC LIMIT {lim}"
            )
            recent_params: Dict[str, Any] = {"since": since}
        else:
            recent_cypher = (
                "MATCH (a:OntologyAudit) "
                "WHERE a.timestamp >= $since AND a.timestamp <= $until "
                "RETURN a.action AS action, a.actor AS actor, a.timestamp AS timestamp, "
                "a.target_type_id AS target_type_id, "
                "a.target_relation_id AS target_relation_id, "
                "a.target_pack_id AS target_pack_id "
                f"ORDER BY a.timestamp DESC LIMIT {lim}"
            )
            recent_params = {"since": since, "until": until}

        try:
            recent_raw = backend.query(recent_cypher, params=recent_params, graph_name=self._graph_name)
        except UnsupportedBackendError:
            raise
        except Exception as e:
            logger.warning("Failed recent_actions query in _get_audit_summary: %s", e)
            recent_raw = []

        recent_actions: List[Dict[str, Any]] = []
        recent_cols = ["action", "actor", "timestamp", "target_type_id", "target_relation_id", "target_pack_id"]
        for r in recent_raw or []:
            if isinstance(r, dict):
                recent_actions.append({k: r.get(k) for k in recent_cols})
            elif isinstance(r, list):
                recent_actions.append({k: (r[i] if i < len(r) else None) for i, k in enumerate(recent_cols)})

        return {
            "total_rows": total_rows,
            "by_action": by_action,
            "by_actor": by_actor,
            "recent_actions": recent_actions,
            "since": since,
            "until": until,
        }

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _query_type(self, backend, name: str):
        """Query a single type by name."""
        try:
            return backend.query(
                "MATCH (t:OntologyType {name: $name}) WHERE NOT t:Concept RETURN t.name, t.status",
                params={"name": name},
                graph_name=self._graph_name,
            )
        except Exception:
            return None

    def _create_type(self, backend, name: str, status: str):
        """Create an EntityType node."""
        backend.query(
            "CREATE (t:EntityType {name: $name, status: $status})",
            params={"name": name, "status": status},
            graph_name=self._graph_name,
        )
