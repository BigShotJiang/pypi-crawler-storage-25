"""
SmartGraph Search Operations Module

Handles all search-related operations for the SmartGraph system.
"""
import logging
import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


SYSTEM_NODE_TYPES = frozenset({"Version", "entity", "relation"})

# CORE-PROPS-1 Phase 2: staleness demotion factor for search ranking
_STALE_DEMOTION = float(os.environ.get("SMARTMEMORY_STALE_DEMOTION", "0.5"))

# Strip possessives, trailing punctuation, and common noise from search tokens.
_POSSESSIVE_RE = re.compile(r"['']s$")
_PUNCT_RE = re.compile(r"[''\"?!.,;:()]+")

# Common English stop words that should not contribute to token overlap scoring.
# Without this, "What is Django?" matches every memory containing "is".
# Only function words with no semantic content.  Negation (not, no, nor),
# exclusivity (only, just), and similar meaning-bearing words are kept.
_STOP_WORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "shall",
    "should", "may", "might", "must", "can", "could",
    "i", "me", "my", "we", "our", "you", "your", "he", "she", "it", "its",
    "they", "them", "their", "this", "that", "these", "those",
    "what", "which", "who", "whom", "how", "when", "where", "why",
    "and", "or", "but", "if", "then", "so",
    "in", "on", "at", "to", "for", "of", "with", "by", "from", "as",
    "into", "about", "between", "through", "after", "before", "during",
    "up", "down", "out", "off", "over", "under", "again", "further",
    "also", "very", "too", "now", "here", "there",
})


def _normalize_tokens(text: str) -> set[str]:
    """Split text into lowercase tokens with punctuation and possessives stripped.

    Handles possessives (Sarah's → sarah), trailing punctuation (work? → work),
    and other noise that breaks exact-match keyword search.
    """
    raw = text.lower().split()
    tokens = set()
    for w in raw:
        w = _POSSESSIVE_RE.sub("", w)  # Sarah's → Sarah
        w = _PUNCT_RE.sub("", w)       # work? → work
        if w:
            tokens.add(w)
    return tokens


def _content_tokens(text: str) -> set[str]:
    """Normalize tokens from text, keeping stop words (for content matching)."""
    return _normalize_tokens(text)


def _query_tokens(text: str) -> set[str]:
    """Normalize tokens from a search query, removing stop words."""
    return _normalize_tokens(text) - _STOP_WORDS


class SmartGraphSearch:
    """Handles all search-related operations for SmartGraph."""

    def __init__(self, backend, nodes_module, enable_caching=True, cache_size=1000, smart_memory=None):
        self.backend = backend
        self.nodes = nodes_module  # Reference to nodes module for conversion
        self.enable_caching = enable_caching
        self.cache_size = cache_size
        self._search_cache = {} if enable_caching else None
        self.smart_memory = smart_memory  # Optional SmartMemory instance for SSG

    def search_nodes(self, query: Dict[str, Any]):
        """
        Search for nodes matching the query dict using simple equality filters.
        
        Args:
            query: Dictionary of property filters (e.g., {"type": "note", "status": "active"})
        
        Returns:
            List of MemoryItem objects matching the query
            
        Note:
            For OR queries (e.g., type OR tags), use backend.search_nodes_by_type_or_tag() directly.
        """
        nodes = self.backend.search_nodes(query)
        return [self.nodes._from_node_dict(self.nodes.item_cls, n) for n in nodes]

    def search(self, query_str: str, top_k: int = 5, use_ssg: Optional[bool] = None, **kwargs):
        """
        Enhanced search method using vector embeddings as primary method with text-based fallbacks.
        Provides semantic similarity search for better relevance.

        Args:
            query_str: Search query string
            top_k: Maximum number of results to return (clamped to >=1 to prevent segfaults)
            use_ssg: Use Similarity Graph Traversal (SSG) for better multi-hop reasoning.
                    If None, uses config default. If True, uses SSG. If False, uses basic vector search.
            **kwargs: Additional arguments passed to search methods
        """
        # Clamp top_k to prevent segfaults in C extensions (usearch)
        top_k = max(1, top_k)

        # Determine if SSG should be used
        if use_ssg is None:
            from smartmemory.utils import get_config
            ssg_config = get_config('ssg') or {}
            use_ssg = ssg_config.get('enabled', True)
        
        # Multi-level fallback strategy
        # Text-first: simple_contains and keyword matching are deterministic and correct.
        # Vector search on low-quality embeddings (spaCy 96-dim) returns false positives.
        # Put text methods first, vector/SSG as enhancement for large corpora.
        is_text_only_backend = self._is_text_only_backend()

        if is_text_only_backend:
            # Graph-first + semantic fill: entity lookup is exact, vector
            # search supplements with semantically related memories that
            # don't have direct entity edges.
            graph_results = self._search_with_graph_entities(query_str, top_k, **kwargs) or []
            if len(graph_results) < top_k:
                # Fill: graph first (done above), then text (precise), then
                # vector (semantic, 0.5 threshold filters irrelevant hits).
                seen_ids = {getattr(r, "item_id", None) for r in graph_results}
                for fill_method in [
                    self._search_with_simple_contains,
                    self._search_with_keyword_matching,
                    self._search_with_vector_embeddings,
                ]:
                    try:
                        fill = fill_method(query_str, top_k, **kwargs)
                        if fill:
                            for item in fill:
                                iid = getattr(item, "item_id", None)
                                if iid not in seen_ids:
                                    seen_ids.add(iid)
                                    graph_results.append(item)
                                    if len(graph_results) >= top_k:
                                        break
                        if len(graph_results) >= top_k:
                            break
                    except Exception as e:
                        logger.warning("Fill method %s failed: %s", fill_method.__name__, e)
                        continue
            # Text-only path: results are already in precision order
            # (graph-first, then text, then vector). Skip confidence reranking —
            # it would let vector fills outrank graph hits.
            return self._postprocess_results(graph_results, top_k, skip_confidence_ranking=True, **kwargs)
        else:
            # CORE-SEARCH-2: FalkorDB mode — hybrid or legacy path
            enable_hybrid = kwargs.get("enable_hybrid", True)

            if enable_hybrid:
                # CORE-SEARCH-2 Phase 1+2: Named channel collection + weighted RRF.
                # All strategies always run — RRF fusion preserves all signals.
                # CORE-SEARCH-2a: Named channels with per-query weight overrides.
                from smartmemory.search.channels import CHANNEL_DEFAULTS, SearchChannel, validate_weight

                if use_ssg:
                    named_strategies = [
                        ("entity-graph", self._search_with_entity_cypher),
                        ("spreading-activation", self._search_with_spreading_activation),
                        ("ssg-traversal", self._search_with_ssg_traversal),
                        ("semantic", self._search_with_vector_embeddings),
                        ("regex-text", self._search_with_regex),
                        ("contains", self._search_with_simple_contains),
                        ("keyword-bm25", self._search_with_keyword_matching),
                    ]
                else:
                    named_strategies = [
                        ("entity-graph", self._search_with_entity_cypher),
                        ("spreading-activation", self._search_with_spreading_activation),
                        ("semantic", self._search_with_vector_embeddings),
                        ("regex-text", self._search_with_regex),
                        ("contains", self._search_with_simple_contains),
                        ("keyword-bm25", self._search_with_keyword_matching),
                    ]

                # Resolve weights: caller override > channel defaults.
                # Validate against CHANNEL_DEFAULTS (global registry), not active list.
                _cw = kwargs.get("channel_weights")
                caller_weights = _cw if _cw is not None else {}

                # Warn about truly unknown channel names (not in registry at all)
                for name in caller_weights:
                    if name not in CHANNEL_DEFAULTS:
                        logger.warning("Unknown channel name in channel_weights: %s", name)

                # Collect results with resolved weights
                result_lists = []
                active_weights = []
                for name, strategy_fn in named_strategies:
                    default_w = CHANNEL_DEFAULTS.get(name, SearchChannel(name)).default_weight
                    w = validate_weight(caller_weights.get(name, default_w), default_w)
                    try:
                        results = strategy_fn(query_str, top_k, **kwargs)
                        if results:
                            result_lists.append(results)
                            active_weights.append(w)
                    except Exception as e:
                        logger.warning("Strategy %s failed: %s", name, e)

                if not result_lists:
                    logger.error("All search strategies returned empty for query: %s", query_str)
                    return []

                # When sort_by="recency", overfetch from RRF so the recency sort
                # in _postprocess_results has a large enough candidate pool.
                _rrf_k = top_k * 4 if kwargs.get("sort_by") == "recency" else top_k

                if len(result_lists) == 1:
                    # Single channel — no RRF overhead
                    merged = result_lists[0]
                else:
                    from smartmemory.search.rrf_merge import rrf_merge
                    merged = rrf_merge(result_lists, top_k=_rrf_k, weights=active_weights)

                # Skip confidence reranking — RRF order is authoritative
                return self._postprocess_results(merged, top_k, skip_confidence_ranking=True, **kwargs)

            else:
                # Legacy sequential fallback (enable_hybrid=False) — backward compatible.
                # Entity Cypher is NOT included to preserve exact original behavior.
                if use_ssg:
                    legacy_strategies = [
                        self._search_with_ssg_traversal,
                        self._search_with_vector_embeddings,
                        self._search_with_regex,
                        self._search_with_simple_contains,
                        self._search_with_keyword_matching,
                    ]
                else:
                    legacy_strategies = [
                        self._search_with_vector_embeddings,
                        self._search_with_regex,
                        self._search_with_simple_contains,
                        self._search_with_keyword_matching,
                    ]

                for i, fallback_method in enumerate(legacy_strategies):
                    try:
                        results = fallback_method(query_str, top_k, **kwargs)
                        if results is not None and len(results) > 0:
                            if i > 0:
                                logger.info("Search succeeded using fallback method %d: %s", i, fallback_method.__name__)
                            return self._postprocess_results(results, top_k, **kwargs)
                        elif results is not None:
                            logger.debug("Fallback method %d (%s) returned empty results", i, fallback_method.__name__)
                    except Exception as e:
                        logger.warning("Search fallback %d failed (%s): %s", i, fallback_method.__name__, e)
                        continue

                logger.error("All search fallbacks failed for query: %s", query_str)
                return []

    @staticmethod
    def _mark_expired_stale(results: list) -> list:
        """CORE-PROPS-1 Phase 2: Mark temporally expired items as stale at query time.

        Checks valid_end_time < now. Handles strings, naive datetimes, and aware datetimes.
        This is a query-time side-effect — does NOT persist to the database.
        """
        if not results:
            return results
        now = datetime.now(timezone.utc)
        for item in results:
            valid_end = getattr(item, "valid_end_time", None)
            if valid_end is None:
                continue
            try:
                if isinstance(valid_end, str):
                    valid_end = datetime.fromisoformat(valid_end)
                if valid_end.tzinfo is None:
                    valid_end = valid_end.replace(tzinfo=timezone.utc)
                if valid_end < now:
                    item.stale = True
            except (ValueError, TypeError, AttributeError):
                continue
        return results

    def _postprocess_results(self, results: list, top_k: int, skip_confidence_ranking: bool = False, **kwargs) -> list:
        """Post-process search results: filter, mark stale, rank, truncate.

        Consolidates the common post-processing steps shared by text-only and
        FalkorDB search paths (CORE-SEARCH-2).

        Args:
            results: Raw search results from one or more strategies.
            top_k: Maximum results to return.
            skip_confidence_ranking: If True, preserve input order (RRF or precision order).
                Text-only and RRF paths skip confidence reranking because their ordering
                is already meaningful.
            **kwargs: Must include ``include_reference`` and ``sort_by`` when applicable.
        """
        if not results:
            return []

        # Filter system-internal nodes
        results = [
            r for r in results
            if getattr(r, "memory_type", None) not in SYSTEM_NODE_TYPES
        ]
        if not results:
            return []

        # CORE-PROPS-1 Phase 2: mark temporally expired items stale
        results = self._mark_expired_stale(results)

        # CORE-PROPS-1 Phase 6: exclude reference data by default
        if not kwargs.get("include_reference", False):
            results = [r for r in results if not getattr(r, "reference", False)]

        # Sort: recency or confidence ranking
        sort_by = kwargs.get("sort_by")
        if sort_by == "recency":
            def _recency_key(r):
                v = getattr(r, "created_at", None)
                if v is None:
                    return "0000-00-00"
                return v.isoformat() if hasattr(v, "isoformat") else str(v)
            results.sort(key=_recency_key, reverse=True)
        elif not skip_confidence_ranking:
            results = self._apply_confidence_ranking(results)

        return results[:top_k]

    def _apply_confidence_ranking(self, results: list) -> list:
        """Re-rank results by multiplying implicit relevance by confidence.

        Items earlier in the list have higher implicit relevance (rank-based).
        Confidence weighting demotes low-confidence items.
        CORE-PROPS-1 Phase 2: also demotes stale items by configurable factor.
        """
        if not results:
            return results
        scored = []
        for rank, item in enumerate(results):
            relevance = 1.0 / (rank + 1)
            confidence = getattr(item, "confidence", 1.0)
            if not isinstance(confidence, (int, float)):
                confidence = 1.0
            # CORE-PROPS-1 Phase 2: staleness demotion
            stale = getattr(item, "stale", False)
            stale_factor = _STALE_DEMOTION if stale else 1.0
            scored.append((item, relevance * confidence * stale_factor))
        scored.sort(key=lambda x: x[1], reverse=True)
        return [item for item, _ in scored]

    def _is_text_only_backend(self) -> bool:
        """Return True when the backend only supports text-based local fallbacks.

        Lite/SQLite backends do not expose the FalkorDB-style ``_query`` method used
        by regex/native text search. Detecting by capability avoids importing a
        concrete backend class inside ``search()`` and keeps future text-only
        backends on the safe chain automatically.
        """
        return not callable(getattr(self.backend, "_query", None))

    def _search_with_ssg_traversal(self, query_str: str, top_k: int = 5, **kwargs):
        """
        SSG-based search using graph traversal algorithms.
        Superior to basic vector search for multi-hop reasoning and contextual retrieval.
        """
        try:
            from smartmemory.retrieval.ssg_traversal import SimilarityGraphTraversal
            from smartmemory.utils import get_config
            
            # Get SSG configuration
            ssg_config = get_config('ssg') or {}
            if not ssg_config.get('enabled', True):
                logger.debug("SSG is disabled in config, skipping")
                return None
            
            # Get algorithm from config or kwargs
            algorithm = kwargs.get('ssg_algorithm') or ssg_config.get('default_algorithm', 'query_traversal')
            
            # Need SmartMemory instance - get from parent if available
            # Tenant isolation is handled by the SmartMemory's scope_provider
            smart_memory = getattr(self, 'smart_memory', None)
            if smart_memory is None:
                logger.debug("No SmartMemory instance available, cannot use SSG")
                return None
            
            # Create SSG instance
            ssg = SimilarityGraphTraversal(smart_memory)
            
            # Execute selected algorithm
            if algorithm == "query_traversal":
                results = ssg.query_traversal(query_str, max_results=top_k)
            elif algorithm == "triangulation_fulldim":
                results = ssg.triangulation_fulldim(query_str, max_results=top_k)
            else:
                logger.warning(f"Unknown SSG algorithm: {algorithm}, falling back to query_traversal")
                results = ssg.query_traversal(query_str, max_results=top_k)
            
            if results:
                logger.info(f"SSG {algorithm} search found {len(results)} results for query: {query_str}")
            
            return results
            
        except Exception as e:
            logger.warning(f"SSG traversal search failed: {e}", exc_info=True)
            return None  # Fallback to next method
    
    def _search_with_graph_entities(self, query_str: str, top_k: int = 5, **kwargs):
        """Graph-first search: find entity nodes matching query tokens, traverse edges to memories.

        This is the most precise search method — entity matches are exact, not
        probabilistic. "What is Django?" → entity node "Django" → MENTIONED_IN
        edges → linked memory items.
        """
        if query_str in ["*", "", None]:
            return None  # Wildcard handled by simple_contains

        if not hasattr(self.backend, "get_all_nodes") or not hasattr(self.backend, "get_edges_for_node"):
            return None  # Backend doesn't support graph traversal

        q_tokens = _query_tokens(query_str)
        if not q_tokens:
            return None  # All stop words

        try:
            # Find entity nodes whose content matches any query token
            all_nodes = self.backend.get_all_nodes()
            # Score entities by token overlap ratio — specific matches rank higher.
            # "LGBTQ support group" matching 3/4 query tokens beats "Caroline" matching 1/4.
            matched_entities = []  # (entity_id, overlap_ratio)
            for node in all_nodes:
                mt = node.get("memory_type", "")
                if mt not in ("entity", "relation"):
                    continue
                content = (node.get("content") or node.get("name") or "").lower()
                entity_tokens = _content_tokens(content)
                overlap = q_tokens & entity_tokens
                if overlap:
                    # Ratio of query tokens covered by this entity
                    overlap_ratio = len(overlap) / len(q_tokens)
                    matched_entities.append((node.get("item_id"), overlap_ratio))

            # Sort by overlap ratio descending — most specific entities first
            matched_entities.sort(key=lambda x: -x[1])
            matched_entity_ids = [eid for eid, _ in matched_entities]

            if not matched_entity_ids:
                logger.debug("No entity nodes match query tokens %s", q_tokens)
                return None  # Fall through to vector search

            # Traverse entities in specificity order — most-specific first.
            # Score each memory by the best entity overlap that links to it.
            # This prevents generic entities (e.g., "Caroline" in every turn)
            # from flooding results when a specific entity ("LGBTQ support group")
            # matches the query more precisely.
            memory_scores = {}  # target_id → best overlap_ratio
            candidate_items = {}  # target_id → MemoryItem
            for entity_id, overlap_ratio in matched_entities:
                edges = self.backend.get_edges_for_node(entity_id)
                for edge in edges:
                    edge_type = edge.get("edge_type", "")
                    if edge_type == "MENTIONED_IN":
                        target_id = edge.get("target_id")
                    elif edge_type == "CONTAINS_ENTITY":
                        target_id = edge.get("source_id")
                    else:
                        continue

                    if not target_id or target_id == entity_id:
                        continue

                    edge_conf = (edge.get("properties") or {}).get("confidence", 0.5)
                    # Score = entity specificity × edge confidence
                    score = overlap_ratio * edge_conf
                    if target_id in memory_scores:
                        memory_scores[target_id] = max(memory_scores[target_id], score)
                    else:
                        try:
                            item = self.nodes.get_node(target_id)
                            if item and getattr(item, "memory_type", "") not in ("entity", "relation"):
                                candidate_items[target_id] = item
                                memory_scores[target_id] = score
                        except Exception:
                            continue

            if candidate_items:
                # Sort by specificity-weighted score (desc)
                ranked = sorted(memory_scores.items(), key=lambda x: (-x[1], x[0]))
                memory_items = [candidate_items[tid] for tid, _ in ranked[:top_k]]
                logger.info("Graph entity search found %d memories via %d entities for: %s",
                            len(memory_items), len(matched_entities), query_str)
                return memory_items
            return None

        except Exception as e:
            logger.warning("Graph entity search failed: %s", e)
            return None

    def _search_with_entity_cypher(self, query_str: str, top_k: int = 5, **kwargs):
        """CORE-SEARCH-2 Phase 2: Entity lookup via Cypher (FalkorDB only).

        Delegates to ``backend.search_by_entity()`` which pushes token matching
        into the database (O(index) vs O(n) for get_all_nodes). Mirrors the
        behavior of ``_search_with_graph_entities()`` used by text-only backends.
        """
        if query_str in ["*", "", None]:
            return None

        if not callable(getattr(self.backend, "search_by_entity", None)):
            return None  # Backend doesn't support entity search

        q_tokens = _query_tokens(query_str)
        if not q_tokens:
            return None  # All stop words

        try:
            raw_results = self.backend.search_by_entity(list(q_tokens), top_k=top_k)
            if not raw_results:
                return None

            # Convert dicts to MemoryItems
            memory_items = []
            for props in raw_results:
                try:
                    item = self.nodes._from_node_dict(self.nodes.item_cls, props)
                    if item:
                        memory_items.append(item)
                except Exception:
                    continue

            if memory_items:
                logger.info("Entity Cypher search found %d memories for: %s",
                            len(memory_items), query_str)
            return memory_items or None

        except Exception as e:
            logger.warning("Entity Cypher search failed: %s", e)
            return None

    def _search_with_spreading_activation(self, query_str: str, top_k: int = 5, **kwargs):
        """NEURO-1d: Spreading activation through entity graph edges (2+ hops).

        Finds memory nodes reachable through multi-hop entity paths. Seeds
        from token-matched entities, then traverses 2+ edges with exponential
        decay scoring. 1-hop results are excluded (already in entity-graph).
        """
        if query_str in ["*", "", None]:
            return None

        if not callable(getattr(self.backend, "search_by_activation", None)):
            return None  # Backend doesn't support spreading activation

        q_tokens = _query_tokens(query_str)
        if not q_tokens:
            return None  # All stop words

        try:
            raw_results = self.backend.search_by_activation(list(q_tokens), top_k=top_k)
            if not raw_results:
                return None

            # Convert dicts to MemoryItems
            memory_items = []
            for props in raw_results:
                try:
                    item = self.nodes._from_node_dict(self.nodes.item_cls, props)
                    if item:
                        memory_items.append(item)
                except Exception:
                    continue

            if memory_items:
                logger.info("Spreading activation search found %d memories for: %s",
                            len(memory_items), query_str)
            return memory_items or None

        except Exception as e:
            logger.warning("Spreading activation search failed: %s", e)
            return None

    def _search_with_vector_embeddings(self, query_str: str, top_k: int = 5, **kwargs):
        """Primary search method using vector embeddings for semantic similarity."""
        try:
            # Import required modules
            from smartmemory.stores.vector.vector_store import VectorStore
            from smartmemory.plugins.embedding import create_embeddings

            # Get vector store instance
            vector_store = VectorStore()

            # Generate embedding for the query
            query_embedding = create_embeddings(query_str)
            if query_embedding is None:
                logger.warning("Failed to generate query embedding")
                return None

            # Convert to list if numpy array
            if hasattr(query_embedding, 'tolist'):
                query_embedding = query_embedding.tolist()

            # Pure vector similarity only — do NOT pass query_text. Passing it
            # activates RRF fusion inside VectorStore.search which overwrites
            # the cosine similarity with a tiny rank-fusion score (~0.016),
            # which the MIN_SIMILARITY filter below then always rejects.
            # BM25/keyword matching is contributed independently by the outer
            # SmartGraphSearch channels, so nothing is lost here.
            vector_results = vector_store.search(query_embedding, top_k=top_k * 2)  # Get more for filtering

            if not vector_results:
                logger.debug(f"No vector results found for query: {query_str}, triggering fallback")
                return None  # Return None to trigger fallback chain

            # Filter below minimum similarity. Without this, vector search
            # returns top_k results regardless of relevance on small corpora.
            # 0.5 cosine similarity is conservative — relevant hits score 0.7+,
            # irrelevant cross-topic content scores 0.3-0.45.
            MIN_SIMILARITY = 0.5
            vector_results = [r for r in vector_results if r.get("score", 0.0) >= MIN_SIMILARITY]
            if not vector_results:
                logger.debug("All vector results below similarity threshold %.2f", MIN_SIMILARITY)
                return None

            # Convert vector results to MemoryItems by retrieving from graph
            memory_items = []
            for result in vector_results[:top_k]:
                node_id = result.get('id')
                if node_id:
                    try:
                        # Retrieve the full MemoryItem from the graph
                        item = self.nodes.get_node(node_id)
                        if item:
                            # Surface the retrieval similarity so downstream
                            # consumers (e.g. ProcedureMatcher) can threshold
                            # on it. Mirrors CrossEncoderReranker._rerank_score.
                            try:
                                item._search_score = float(result.get('score', 0.0))
                            except (AttributeError, TypeError, ValueError):
                                pass
                            memory_items.append(item)
                            logger.debug(f"Retrieved item {node_id} with score {result.get('score', 'unknown')}")
                    except Exception as e:
                        logger.warning(f"Failed to retrieve node {node_id}: {e}")
                        continue

            # If we got vector results but couldn't retrieve any items, trigger fallback
            if not memory_items:
                logger.debug("Vector results found but items not retrievable, triggering fallback")
                return None

            logger.info(f"Vector search found {len(memory_items)} results for query: {query_str}")
            return memory_items

        except ImportError as e:
            # Missing dependency (e.g. vector store not installed) — legitimate fallback
            logger.warning(f"Vector embedding search unavailable (missing dependency): {e}")
            return None
        except Exception as e:
            # Embedding model failures, dimension mismatches, etc. — fail loud
            logger.error(f"Vector embedding search failed: {e}")
            raise

    def _search_with_regex(self, query_str: str, top_k: int = 5, **kwargs):
        """Primary search method using FalkorDB/Cypher-compatible text search."""
        # Handle wildcard or empty queries
        if query_str in ["*", "", None]:
            # Return all nodes for wildcard queries
            results = self.backend.search_nodes({})
        else:
            # Use FalkorDB's text search capabilities
            results = self._search_text_falkordb(query_str)

        # Convert to MemoryItem objects — skip infrastructure nodes (Vec store, etc.)
        # that have no memory_type; _from_node_dict would mint a random UUID for them,
        # causing any subsequent per-id operation (update_properties, get) to fail.
        memory_items = [
            self.nodes._from_node_dict(self.nodes.item_cls, node)
            for node in results
            if self._is_user_node(node)
        ]
        return memory_items[:top_k] if top_k else memory_items

    def _search_text_falkordb(self, query_str: str):
        """FalkorDB-compatible text search using CONTAINS operator with multi-word support."""
        # Split query into individual terms for better matching
        terms = [term.strip() for term in query_str.split() if term.strip()]

        if not terms:
            return []

        # Build dynamic query for multiple terms
        # Use OR logic for individual terms to be more permissive
        where_conditions = []
        params = {}

        for i, term in enumerate(terms):
            param_name = f"term{i}"
            params[param_name] = term

            # Add condition for this term across multiple fields
            term_condition = "("
            term_condition += f"toLower(n.content) CONTAINS toLower(${param_name}) OR "
            term_condition += f"toLower(n.title) CONTAINS toLower(${param_name}) OR "
            term_condition += f"toLower(n.description) CONTAINS toLower(${param_name})"
            term_condition += ")"

            where_conditions.append(term_condition)

        # Combine conditions with OR for broader matching
        where_clause = " OR ".join(where_conditions)

        cypher = f"""
        MATCH (n) 
        WHERE {where_clause}
        RETURN n
        """

        res = self.backend._query(cypher, params)

        result = []
        for record in res:
            node = record[0]
            if hasattr(node, 'properties'):
                props = dict(node.properties)
            else:
                # Fallback to direct attribute access
                props = {k: v for k, v in vars(node).items()
                         if not k.startswith('_') and k != 'properties'}

            # Remove internal properties
            props.pop('is_global', None)
            result.append(props)

        return result

    def _search_with_simple_contains(self, query_str: str, top_k: int = 5, **kwargs):
        """Fallback search using simple contains logic."""
        if query_str in ["*", "", None]:
            # Get all nodes — collect ALL user nodes so the caller can sort
            # (e.g. by recency) before truncating. Truncating early would
            # return arbitrary nodes instead of the most recent ones.
            if hasattr(self.backend, 'get_all_nodes'):
                nodes = self.backend.get_all_nodes()
                results = []
                for n in nodes:
                    if not self._is_user_node(n):
                        continue
                    try:
                        item = self.nodes._from_node_dict(self.nodes.item_cls, n)
                        if item:
                            results.append(item)
                    except Exception as e:
                        logger.warning(f"Failed to convert node to MemoryItem: {e}")
                        continue
                # When sort_by is requested (e.g. recency), return all so the
                # caller can sort the full set before truncating to top_k.
                # Otherwise cap for safety.
                if kwargs.get("sort_by"):
                    return results
                return results[:max(top_k * 4, 200)]
            return []

        # Get all nodes and filter manually
        if hasattr(self.backend, 'get_all_nodes'):
            nodes = self.backend.get_all_nodes()
            filtered_nodes = []
            query_lower = query_str.lower()

            logger.info(f"Searching through {len(nodes)} nodes for query: {query_str}")

            for node in nodes:
                if not self._is_user_node(node):
                    continue
                try:
                    # Convert node to MemoryItem
                    node_dict = self.nodes._from_node_dict(self.nodes.item_cls, node)
                    if not node_dict:
                        continue

                    # Extract searchable text from the MemoryItem
                    content = getattr(node_dict, 'content', '') or ''
                    metadata = getattr(node_dict, 'metadata', {}) or {}

                    # Build searchable text
                    searchable_text = str(content)
                    if isinstance(metadata, dict):
                        # Add metadata values to searchable text
                        for key, value in metadata.items():
                            if isinstance(value, str):
                                searchable_text += f" {value}"

                    # Check if query matches (case-insensitive, punctuation-tolerant).
                    # First try exact substring, then try normalized token overlap
                    # so "Sarah's" matches content containing "Sarah".
                    searchable_lower = searchable_text.lower()
                    if query_lower in searchable_lower:
                        filtered_nodes.append(node_dict)
                    else:
                        q_tokens = _query_tokens(query_str)
                        text_tokens = _content_tokens(searchable_text)
                        if not q_tokens:
                            # Query was entirely stop words — skip token overlap
                            continue
                        overlap = len(q_tokens & text_tokens)
                        if overlap >= max(1, len(q_tokens) // 2):
                            filtered_nodes.append(node_dict)
                        logger.debug(f"Found match: {getattr(node_dict, 'item_id', 'No ID')}")
                        if len(filtered_nodes) >= top_k:
                            break

                except Exception as e:
                    logger.warning(f"Error processing node during search: {e}")
                    continue

            logger.info(f"Search found {len(filtered_nodes)} matches")
            return filtered_nodes
        return []

    def _search_with_keyword_matching(self, query_str: str, top_k: int = 5, **kwargs):
        """Fallback search using keyword matching."""
        if query_str in ["*", "", None]:
            return None  # Let next fallback handle this

        # Get all nodes and use keyword matching
        if hasattr(self.backend, 'get_all_nodes'):
            nodes = self.backend.get_all_nodes()
            query_words = _query_tokens(query_str)
            if not query_words:
                return None  # All stop words — let next fallback handle
            scored_nodes = []

            for node in nodes:
                if not self._is_user_node(node):
                    continue
                node_dict = self.nodes._from_node_dict(self.nodes.item_cls, node)
                content = getattr(node_dict, 'content', '').lower()
                title = getattr(node_dict, 'metadata', {}).get('title', '').lower()
                description = getattr(node_dict, 'metadata', {}).get('description', '').lower()

                all_text = f"{content} {title} {description}"
                text_words = _content_tokens(all_text)

                if query_words and text_words:
                    intersection = len(query_words & text_words)
                    union = len(query_words | text_words)
                    score = intersection / union if union > 0 else 0.0

                    if score > 0.1:  # Only include reasonable matches
                        scored_nodes.append((node_dict, score))

            # Sort by score and return top_k
            scored_nodes.sort(key=lambda x: x[1], reverse=True)
            return [node for node, score in scored_nodes[:top_k]]

        return None

    @staticmethod
    def _is_user_node(node_dict) -> bool:
        """Return False for system-internal nodes (Version, vector store nodes, etc.) that should
        not appear in search results.

        The FalkorDB vector-index stores one ``Vec_<graph_name>`` label node per embedded memory.
        These nodes share properties (including ``memory_type``) with the memory node they index
        but have ``item_id=None`` and ``node_category=None``.  If included, ``_from_node_dict``
        would mint a new random UUID for the Vec node, causing any subsequent per-id operation
        (``update_properties``, ``get``) to fail with "Node not found in graph."

        Discrimination rule: a valid user node MUST have a non-None ``item_id`` stored in the
        graph.  Vec/infrastructure nodes always have ``item_id=None`` (or absent).
        """
        # Must have a stored item_id — Vec and other infra nodes have item_id=None
        if not node_dict.get("item_id"):
            return False
        mt = node_dict.get("memory_type") or node_dict.get("type") or ""
        return mt not in SYSTEM_NODE_TYPES

    def _get_all_nodes_fallback(self, query_str: str, top_k: int = 5, **kwargs):
        """Final fallback - just return all available nodes."""
        if hasattr(self.backend, 'get_all_nodes'):
            nodes = self.backend.get_all_nodes()
            user_nodes = [n for n in nodes if self._is_user_node(n)]
            return [self.nodes._from_node_dict(self.nodes.item_cls, n) for n in user_nodes[:top_k]]
        return []

    def _manage_cache_size(self):
        """Manage cache size by removing oldest entries when cache is full."""
        if not self.enable_caching:
            return

        if len(self._search_cache) >= self.cache_size:
            # Remove 20% of oldest entries
            remove_count = max(1, self.cache_size // 5)
            oldest_keys = list(self._search_cache.keys())[:remove_count]
            for key in oldest_keys:
                del self._search_cache[key]

    def clear_cache(self):
        """Clear search cache."""
        if self.enable_caching:
            self._search_cache.clear()

    def set_smart_memory(self, smart_memory):
        """
        Set SmartMemory instance for SSG traversal.
        Called after SmartMemory initialization to avoid circular dependency.
        """
        self.smart_memory = smart_memory
        logger.debug("SmartMemory instance set for SSG traversal")
    
    def get_cache_stats(self):
        """Get search cache performance statistics."""
        if not self.enable_caching:
            return {"caching_enabled": False}

        return {
            "caching_enabled": True,
            "search_cache_size": len(self._search_cache),
            "max_cache_size": self.cache_size
        }
