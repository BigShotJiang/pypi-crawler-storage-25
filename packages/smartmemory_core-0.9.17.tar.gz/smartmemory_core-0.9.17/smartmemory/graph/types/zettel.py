import logging
from typing import Optional, Any, Dict, List

from smartmemory.graph.base import BaseMemoryGraph
from smartmemory.graph.types.interfaces import MemoryGraphInterface
from smartmemory.models.memory_item import MemoryItem
from smartmemory.stores.converters.zettel_converter import ZettelConverter
from smartmemory.stores.mixins import (
    GraphErrorHandlingMixin, GraphLoggingMixin,
    GraphValidationMixin, GraphPerformanceMixin
)

logger = logging.getLogger(__name__)


class ZettelMemoryGraph(
    BaseMemoryGraph,
    MemoryGraphInterface,
    GraphErrorHandlingMixin,
    GraphLoggingMixin,
    GraphValidationMixin,
    GraphPerformanceMixin
):
    """
    Store layer for ZettelMemory. Handles all graph operations for notes, tags, links, and dynamic relations.
    
    Implements hybrid architecture with:
    - Standard interface (MemoryGraphInterface)
    - Optional mixins for common functionality
    - Type-specific converter for Zettelkasten processing
    """

    def __init__(self, *args, **kwargs):
        # Initialize mixins first
        super().__init__(*args, **kwargs)

        # Initialize converter for Zettelkasten-specific transformations
        self.converter = ZettelConverter()

    def add(self, item, key: str = None, **kwargs):
        """
        Add a note using converter and mixins.
        """
        with self.performance_context("zettel_add"):
            # Convert dict to MemoryItem if needed, then use converter
            if isinstance(item, dict):
                memory_item = MemoryItem(
                    content=item.get('content', item.get('zettel_body', '')),
                    metadata=item,
                    item_id=item.get('item_id', key)
                )
            else:
                memory_item = item

            # Use converter to prepare item for Zettelkasten storage
            graph_data = self.converter.to_graph_data(memory_item)

            # Validate using mixin
            if not self.validate_item(memory_item):
                return self.handle_error(f"Validation failed for note {key or graph_data.node_id}")

            try:
                # Add main note node
                note_node = self.graph.add_node(
                    item_id=graph_data.node_id,
                    properties=graph_data.node_properties,
                    memory_type="zettel"
                )

                # Add extracted relations using converter
                for relation in graph_data.relations:
                    # Create target nodes for tags and concepts if they don't exist
                    if relation.relation_type == "TAGGED_WITH":
                        tag_name = relation.properties.get('tag_name', relation.target_id.replace('tag_', ''))
                        tag_node = self.graph.add_node(
                            item_id=relation.target_id,
                            properties={"name": tag_name, "label": "Tag"},
                            memory_type="tag"
                        )
                    elif relation.relation_type == "MENTIONS":
                        concept_name = relation.properties.get('concept_name', relation.target_id.replace('concept_', ''))
                        concept_node = self.graph.add_node(
                            item_id=relation.target_id,
                            properties={
                                "name": concept_name,
                                "title": concept_name,
                                "content": f"Concept: {concept_name}",
                                "label": "Concept"
                            },
                            memory_type="concept"
                        )
                    elif relation.relation_type in ["LINKS_TO", "LINKS_TO_BACK"]:
                        # CRITICAL FIX: Create placeholder nodes for wikilink targets that don't exist yet
                        target_exists = self.graph.get_node(relation.target_id) is not None
                        if not target_exists:
                            # Create placeholder note node for the wikilink target
                            placeholder_node = self.graph.add_node(
                                item_id=relation.target_id,
                                properties={
                                    "item_id": relation.target_id,
                                    "content": f"# {relation.target_id}\n\nPlaceholder note created for wikilink reference.",
                                    "title": relation.target_id,
                                    "name": relation.target_id,
                                    "label": "Note",
                                    "placeholder": True,
                                    "created_by_wikilink": True
                                },
                                memory_type="zettel"
                            )

                    # Add the relation
                    self._add_edge_safe(
                        source_id=relation.source_id,
                        target_id=relation.target_id,
                        edge_type=relation.relation_type,
                        properties=relation.properties,
                        memory_type="zettel"
                    )

                self.log_operation("add", f"Added Zettelkasten note {graph_data.node_id}")
                return note_node

            except Exception as e:
                return self.handle_error(f"Failed to add Zettelkasten note {graph_data.node_id}: {e}")

    # Inherited get() method from BaseMemoryGraph provides consistent implementation

    # Inherited remove() method from BaseMemoryGraph provides consistent implementation

    def search(self, query: str, top_k: int = 5, **kwargs) -> list:
        """
        Search for notes by query string. Returns a list of dicts.
        """
        try:
            # SmartGraph does not implement search yet; stub with find_nodes by content substring
            notes = self.graph.search_nodes({"label": "Note"})
            filtered = [n for n in notes if query.lower() in n["properties"].get("content", "").lower()]
            return [{"key": n.get("item_id"), "content": n["properties"].get("content")} for n in filtered[:top_k]]
        except Exception as e:
            logger.error(f"Failed to search notes for query '{query}': {e}")
            return []

    def add_dynamic_relation(self, source_id: Any, target_id: Any, relation_type: str, properties: Optional[Dict[str, Any]] = None):
        try:
            self._add_edge_safe(source_id, target_id, edge_type=relation_type,
                                properties=properties or {}, memory_type="dynamic")
        except Exception as e:
            logger.error(f"Failed to add dynamic relation {relation_type}: {e}")

    def _scoped_neighbors(
        self, item_id: str, edge_type: str, direction: str = "both"
    ) -> List[MemoryItem]:
        """Workspace-scoped neighbor traversal.

        Returns MemoryItem list. ``direction`` is 'outgoing', 'incoming', or 'both'.
        """
        from smartmemory.graph.backends import codec

        backend = self.graph.nodes.backend
        ws_id = backend._get_workspace_id()
        rel = f"[r:{edge_type}]"
        if direction == "outgoing":
            pattern = f"-{rel}->"
        elif direction == "incoming":
            pattern = f"<-{rel}-"
        else:
            pattern = f"-{rel}-"
        query = (
            f"MATCH (n){pattern}(m) "
            f"WHERE n.item_id = $item_id AND m.workspace_id = $ws_id "
            f"RETURN DISTINCT m"
        )
        results = backend._query(query, {"item_id": item_id, "ws_id": ws_id})
        items = []
        for record in results:
            node = record[0]
            if hasattr(node, "properties"):
                props = codec.hydrate_and_unflatten(dict(node.properties))
            elif isinstance(node, dict):
                props = codec.hydrate_and_unflatten(node)
            else:
                continue
            items.append(MemoryItem(
                content=props.get("content", ""),
                metadata={k: v for k, v in props.items() if k not in ("content", "item_id")},
                item_id=props.get("item_id"),
            ))
        return items

    def find_notes_by_tag(self, tag_name: str) -> list:
        # ZETTEL-RESCUE-1 RC-2 (Phase 3, 2026-05-20): the previous
        # `(:Tag)` + `TAGGED_WITH` traversal walked node/edge shapes the
        # pipeline never creates, so this endpoint always returned []. Live
        # FalkorDB trace shows `ZettelMemory._add_impl` (zettel_memory.py:269)
        # stores `tags` as a top-level native Cypher list on the [Zettel] row.
        #
        # The graph-level `search_nodes_by_member("tags", ...)` primitive can't
        # be used here: it scans every node in the workspace, and any non-zettel
        # row in the corpus that stores `tags` as a String (legacy / different
        # producer) raises FalkorDB `Type mismatch: expected List or Null but
        # was String` for the whole query. The fix is a label-scoped Cypher
        # against `(n:Zettel)` so heterogeneous `tags` storage on sibling
        # node classes can't poison this read path. Mirrors `notes_mentioning`.
        try:
            backend = self.graph.nodes.backend
            ws_id = backend._get_workspace_id()
            query = (
                "MATCH (n:Zettel) "
                "WHERE n.workspace_id = $ws_id "
                "AND $tag IN n.tags "
                "RETURN n"
            )
            results = backend._query(query, {"tag": tag_name, "ws_id": ws_id})
        except Exception as e:
            logger.error(f"Failed to find notes by tag '{tag_name}': {e}")
            return []

        from smartmemory.graph.backends import codec
        items = []
        for record in results:
            node = record[0]
            if hasattr(node, "properties"):
                props = codec.hydrate_and_unflatten(dict(node.properties))
            elif isinstance(node, dict):
                props = codec.hydrate_and_unflatten(node)
            else:
                continue
            items.append(MemoryItem(
                content=props.get("content", ""),
                metadata={k: v for k, v in props.items() if k not in ("content", "item_id")},
                item_id=props.get("item_id"),
            ))
        return items

    def find_notes_by_property(self, key: str, value: Any) -> list:
        # ZETTEL-RESCUE-1 RC-3 (2026-05-20): the pipeline labels zettel rows
        # `Zettel` (or carries memory_type="zettel"); querying `label:"Note"`
        # never matched anything in practice and the endpoint always returned
        # []. Use the memory_type predicate which is stable across both the
        # `[Zettel]` label and any future label rename.
        try:
            return self.graph.search_nodes({"memory_type": "zettel", key: value})
        except Exception as e:
            logger.error(f"Failed to find notes by {key}={value}: {e}")
            return []

    def notes_linked_to(self, note_id: Any) -> list:
        try:
            return self._scoped_neighbors(note_id, "LINKED_TO")
        except Exception as e:
            logger.error(f"Failed to find notes linked to {note_id}: {e}")
            return []

    def notes_mentioning(self, entity_id: Any) -> list:
        """Find memory nodes connected to an entity via CONTAINS_ENTITY or MENTIONED_IN.

        Accepts entity item_id OR entity name. Scopes results to the current
        workspace via the backend's scope_provider.
        """
        try:
            backend = self.graph.nodes.backend
            ws_id = backend._get_workspace_id()
            query = (
                "MATCH (m)-[:CONTAINS_ENTITY|MENTIONED_IN]-(e) "
                "WHERE (e.item_id = $entity_id OR e.name = $entity_id) "
                "AND m.workspace_id = $ws_id "
                "RETURN DISTINCT m"
            )
            results = backend._query(query, {"entity_id": str(entity_id), "ws_id": ws_id})
            from smartmemory.graph.backends import codec
            items = []
            for record in results:
                node = record[0]
                if hasattr(node, "properties"):
                    props = codec.hydrate_and_unflatten(dict(node.properties))
                elif isinstance(node, dict):
                    props = codec.hydrate_and_unflatten(node)
                else:
                    continue
                item = MemoryItem(
                    content=props.get("content", ""),
                    metadata={k: v for k, v in props.items() if k not in ("content", "item_id")},
                    item_id=props.get("item_id"),
                )
                items.append(item)
            return items
        except Exception as e:
            logger.error(f"Failed to find notes mentioning {entity_id}: {e}")
            return []

    def query_by_dynamic_relation(self, source_id: Any, relation_type: str) -> list:
        try:
            return self._scoped_neighbors(str(source_id), relation_type.upper(), direction="outgoing")
        except Exception as e:
            logger.error(f"Failed to query relation {relation_type} from {source_id}: {e}")
            return []
