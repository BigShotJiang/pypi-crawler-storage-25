"""ManagedType declaration for the `constraint` memory type.

Constraints are durable hard limits — compliance, security, infra, SLA.
INDEXED, queryable by status/domain.

See smart-memory-docs/docs/features/CORE-EXPERTISE-1/phase-2-constraint-learned/spec.md
"""

from __future__ import annotations

from datetime import datetime

from smartmemory.managed import Field, ManagedType


def _constraint_first_class(instance) -> dict:
    """Lift confidence to MemoryItem first-class."""
    return {"confidence": instance.confidence}


_CONSTRAINT_TYPE = ManagedType(
    name="constraint",
    fields={
        "domain": Field(str, optional=True, indexed=True),
        "source": Field(str, optional=True),
        "expires_at": Field(datetime, optional=True),
    },
    default_confidence=1.0,
    origin="user:constraint",
    handler_origin="structured:constraint",
    lifecycle="standard",
    id_field="constraint_id",
    id_prefix="con",
    first_class_fn=_constraint_first_class,
    index_specs=[
        "CREATE INDEX IF NOT EXISTS idx_constraint_status "
        "ON nodes(json_extract(properties, '$.status')) WHERE memory_type='constraint'",
        "CREATE INDEX IF NOT EXISTS idx_constraint_domain "
        "ON nodes(json_extract(properties, '$.domain')) WHERE memory_type='constraint'",
    ],
    describe_summary=(
        "Constraint records — durable hard limits (compliance, security, infra). "
        "INDEXED, queryable by status/domain."
    ),
)


_ConstraintBase, _ConstraintHandlerBase, _ConstraintManagerBase, _ConstraintQueriesBase = (
    _CONSTRAINT_TYPE.derive()
)
