"""Constraint memory type — durable hard limits.

Public API: Constraint, ConstraintHandler, ConstraintManager, ConstraintQueries.
All four are derived from `_CONSTRAINT_TYPE` in declaration.py — no subclass needed.
"""

from smartmemory.constraints.declaration import (
    _ConstraintBase as Constraint,
    _ConstraintHandlerBase as ConstraintHandler,
    _ConstraintManagerBase as ConstraintManager,
    _ConstraintQueriesBase as ConstraintQueries,
)

__all__ = ["Constraint", "ConstraintHandler", "ConstraintManager", "ConstraintQueries"]
