"""ManagedType declaration for the `pattern` memory type (CORE-ADHERENCE-1).

Adherence patterns — coding rules / architectural conventions / project-specific
constraints that an AI coding agent should respect. Stored as MemoryItems with
``memory_type="pattern"``. Read-only over MCP, full CRUD over REST.

The companion enforcement feature lives in Compose (`COMP-POLICY-CHECK`).
SmartMemory ships the substrate (catalog + query surface); Compose enforces.

See smart-memory-docs/docs/features/CORE-ADHERENCE-1/.
"""

from __future__ import annotations

from smartmemory.managed import Field, ManagedType


VALID_SEVERITIES = {"info", "warn", "error"}


def _severity_validator(val) -> bool:
    return isinstance(val, str) and val in VALID_SEVERITIES


def _scope_validator(val) -> bool:
    # scope is a list of glob/path fragments; empty list = repo-wide.
    return isinstance(val, list) and all(isinstance(s, str) for s in val)


def _examples_validator(val) -> bool:
    if not isinstance(val, list):
        return False
    for ex in val:
        if not isinstance(ex, dict):
            return False
        kind = ex.get("kind")
        if kind not in ("positive", "negative"):
            return False
        if not isinstance(ex.get("code", ""), str):
            return False
    return True


def _pattern_first_class(instance) -> dict:
    """Lift confidence to MemoryItem first-class (mirrors learned/decision)."""
    return {"confidence": instance.confidence}


_PATTERN_TYPE = ManagedType(
    name="pattern",
    fields={
        "title": Field(str),
        "severity": Field(str, default="warn", indexed=True, validator=_severity_validator),
        "scope": Field(list, default=None, list_of=str, validator=_scope_validator),
        "examples": Field(list, default=None, list_of=dict, validator=_examples_validator),
        "rationale": Field(str, optional=True, default=""),
        "source": Field(str, optional=True, default="user", indexed=True),
        "version": Field(int, optional=True, default=1),
    },
    default_confidence=1.0,
    origin="user:pattern",
    handler_origin="structured:pattern",
    lifecycle="standard",
    id_field="pattern_id",
    id_prefix="pat",
    first_class_fn=_pattern_first_class,
    index_specs=[
        "CREATE INDEX IF NOT EXISTS idx_pattern_severity "
        "ON nodes(json_extract(properties, '$.severity')) WHERE memory_type='pattern'",
        "CREATE INDEX IF NOT EXISTS idx_pattern_source "
        "ON nodes(json_extract(properties, '$.source')) WHERE memory_type='pattern'",
        "CREATE INDEX IF NOT EXISTS idx_pattern_status "
        "ON nodes(json_extract(properties, '$.status')) WHERE memory_type='pattern'",
    ],
    describe_summary=(
        "Adherence pattern — a coding rule / architectural convention / project "
        "constraint that an AI coding agent should respect. Read-only over MCP "
        "(security: agents shouldn't mutate the rule catalog); full CRUD over REST."
    ),
)


_PatternBase, _PatternHandlerBase, _PatternManagerBase, _PatternQueriesBase = (
    _PATTERN_TYPE.derive()
)
