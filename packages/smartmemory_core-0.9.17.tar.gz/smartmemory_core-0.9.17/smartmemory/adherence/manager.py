"""PatternManager + PatternQueries — extends the framework-derived bases.

The ``ManagedType`` framework gives us ``create / get / supersede / retract`` and
a generic ``get_active(filters=...)`` query helper. Patterns also need:

- ``query(scope=?, severity=?, free_text=?)`` — the canonical MCP read surface.
- ``update(pattern_id, **fields)`` — REST PUT with version bump.
- ``delete(pattern_id, reason)`` — REST DELETE → retraction.
- ``queries_for_seed()`` — flat iteration for the seed helper's dedup pass.

Patterns are not semantically searched today (INDEXED type, no embedding), so
``query`` matches scope via glob fragment substring, severity via equality, and
free_text via case-insensitive substring on title + content + rationale. This
mirrors ``AnchorQueries`` style — direct, predictable, no LLM in the loop.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Iterable, Optional

from smartmemory.adherence.declaration import (
    _PatternBase as Pattern,
    _PatternManagerBase as _GeneratedPatternManager,
    _PatternQueriesBase as _GeneratedPatternQueries,
)

if TYPE_CHECKING:
    from smartmemory.smart_memory import SmartMemory

logger = logging.getLogger(__name__)


def _matches_scope(pattern_scope: list[str] | None, scope_filter: str) -> bool:
    """Return True when ``scope_filter`` overlaps ``pattern_scope``.

    Empty/None pattern_scope means repo-wide and matches any filter.
    Otherwise we do a case-insensitive substring match either way:
    pattern declared ``"**/*.py"`` matches a filter ``".py"`` and vice-versa.
    """
    if not pattern_scope:
        return True
    sf = scope_filter.lower()
    for s in pattern_scope:
        sl = s.lower()
        if sf in sl or sl in sf:
            return True
    return False


def _matches_free_text(p: Pattern, needle: str) -> bool:
    n = needle.lower()
    haystack = " ".join([
        getattr(p, "title", "") or "",
        getattr(p, "content", "") or "",
        getattr(p, "rationale", "") or "",
    ]).lower()
    return n in haystack


class PatternQueries(_GeneratedPatternQueries):  # type: ignore[misc, valid-type]
    """Read-only queries for adherence patterns.

    INDEXED types have no embeddings, so the framework's generic
    ``_broad_search`` (which calls ``memory.search(query='*')``) is unreliable —
    on FalkorDB it returns whatever vector nearest-neighbours the empty query
    happens to land on, which is rarely the pattern containers themselves. We
    follow the ``AnchorQueries`` pattern: direct property-equality queries
    against the backend, falling back gracefully when a backend is unfamiliar.
    """

    def _list_active_direct(self, limit: int) -> list[Pattern]:
        """Backend-direct fetch of active patterns. Returns list of Pattern instances."""
        backend = self.memory._graph.backend  # type: ignore[attr-defined]

        # SQLite path — direct SQL on the nodes table.
        try:
            from smartmemory.graph.backends.sqlite import SQLiteBackend
            if isinstance(backend, SQLiteBackend):
                return self._list_sqlite(backend, limit)
        except Exception:
            pass

        # Generic fallback — search_nodes by property equality. Pull all rows
        # for this memory_type (status filter applied per-row below), so we can
        # deduplicate ghost rows that lack a top-level ``item_id`` — FalkorDB's
        # content-dedup path can leave a second node with the same logical id
        # but a stale ``status='active'`` snapshot.
        try:
            rows = backend.search_nodes({"memory_type": "pattern"})
        except Exception as e:
            logger.warning("pattern search_nodes failed: %s", e)
            return []
        # Group by pattern_id; prefer the row with a real item_id (the canonical
        # node retract() actually wrote to). Drop ghost rows.
        canonical: dict[str, dict] = {}
        for node in rows:
            data = dict(node) if not isinstance(node, dict) else node
            pid = data.get("item_id") or data.get("pattern_id")
            if not pid:
                continue
            existing = canonical.get(pid)
            if existing is None or (not existing.get("item_id") and data.get("item_id")):
                canonical[pid] = data
        out: list[Pattern] = []
        for pid, data in canonical.items():
            if data.get("status", "active") != "active":
                continue
            try:
                inst = Pattern.from_dict(data)  # type: ignore[attr-defined]
            except Exception:
                # Hydrate via memory.get to recover when search_nodes returns a
                # partial shape (e.g. only top-level node props, no metadata).
                item = self.memory.get(pid)
                if item is None:
                    continue
                metadata = dict(getattr(item, "metadata", None) or {})
                if not metadata.get("content"):
                    metadata["content"] = getattr(item, "content", "") or ""
                try:
                    inst = Pattern.from_dict(metadata)  # type: ignore[attr-defined]
                except Exception as e:
                    logger.debug("Pattern hydrate failed for %s: %s", pid, e)
                    continue
            if getattr(inst, "status", "active") != "active":
                continue
            out.append(inst)
            if len(out) >= limit:
                break
        return out

    def _list_sqlite(self, backend, limit: int) -> list[Pattern]:
        import json as _json
        sql = (
            "SELECT item_id, properties FROM nodes "
            "WHERE memory_type = 'pattern' "
            "AND COALESCE(json_extract(properties, '$.status'), 'active') = 'active' "
            "LIMIT ?"
        )
        with backend._lock:
            rows = backend._conn.execute(sql, [limit]).fetchall()
        out: list[Pattern] = []
        for item_id, props_str in rows:
            props = _json.loads(props_str) if props_str else {}
            props.setdefault("pattern_id", item_id)
            try:
                inst = Pattern.from_dict(props)  # type: ignore[attr-defined]
            except Exception as e:
                logger.debug("Pattern hydrate failed for %s: %s", item_id, e)
                continue
            out.append(inst)
        return out

    def query(
        self,
        scope: Optional[str] = None,
        severity: Optional[str] = None,
        free_text: Optional[str] = None,
        limit: int = 100,
    ) -> list[Pattern]:
        """Filter active patterns by scope glob, severity, and/or free text.

        All filters are conjunctive. Returns ``Pattern`` instances (active only).
        """
        candidates = self._list_active_direct(limit=max(limit * 4, 100))
        out: list[Pattern] = []
        for p in candidates:
            if severity is not None and getattr(p, "severity", None) != severity:
                continue
            if scope is not None and not _matches_scope(getattr(p, "scope", None), scope):
                continue
            if free_text is not None and not _matches_free_text(p, free_text):
                continue
            out.append(p)
            if len(out) >= limit:
                break
        return out

    def list_all(self, limit: int = 200) -> list[Pattern]:
        """Return every active pattern (no filters)."""
        return self._list_active_direct(limit=limit)


class PatternManager(_GeneratedPatternManager):  # type: ignore[misc, valid-type]
    """Lifecycle manager for adherence patterns."""

    def __init__(self, memory: "SmartMemory", graph: Any = None) -> None:
        super().__init__(memory, graph)
        self._queries = PatternQueries(memory, graph)

    @property
    def queries(self) -> PatternQueries:
        return self._queries

    def queries_for_seed(self) -> Iterable[Pattern]:
        """Iterate every active pattern — used by the seed helper for dedup."""
        try:
            return list(self._queries.list_all(limit=1000))
        except Exception as e:
            logger.debug("queries_for_seed: list_all failed (%s); returning empty", e)
            return []

    def query(
        self,
        scope: Optional[str] = None,
        severity: Optional[str] = None,
        free_text: Optional[str] = None,
        limit: int = 100,
    ) -> list[Pattern]:
        """Convenience pass-through to ``self.queries.query``."""
        return self._queries.query(scope=scope, severity=severity, free_text=free_text, limit=limit)

    def update(self, pattern_id: str, **fields) -> Pattern:
        """REST PUT: mutate fields on an active pattern, bump version, persist.

        Refuses to mutate ``pattern_id``, ``status``, ``superseded_by``,
        ``created_at`` — those are lifecycle-managed. ``version`` auto-increments
        unless explicitly overridden. Raises ValueError when the pattern is not
        found or not active.
        """
        instance = self._hydrate(pattern_id)  # type: ignore[attr-defined]
        if instance is None:
            raise ValueError(f"pattern {pattern_id!r} not found")
        if getattr(instance, "status", "active") != "active":
            raise ValueError(
                f"pattern {pattern_id!r} is in status "
                f"{getattr(instance, 'status', '?')!r}; only 'active' can be updated"
            )

        protected = {"pattern_id", "status", "superseded_by", "created_at"}
        bad = [k for k in fields if k in protected]
        if bad:
            raise ValueError(f"cannot mutate protected field(s) via update(): {bad}")

        bumped_version = False
        for k, v in fields.items():
            if not hasattr(instance, k):
                raise ValueError(f"unknown field {k!r} for pattern")
            setattr(instance, k, v)
            if k != "version":
                bumped_version = True

        if bumped_version and "version" not in fields:
            instance.version = (getattr(instance, "version", 1) or 1) + 1
        instance.updated_at = datetime.now(timezone.utc)
        self._update_instance(instance)  # type: ignore[attr-defined]
        return instance

    def delete(self, pattern_id: str, reason: str = "deleted via REST") -> None:
        """REST DELETE → retraction (status='retracted'). Soft delete; auditable."""
        self.retract(pattern_id, reason=reason)  # type: ignore[attr-defined]
