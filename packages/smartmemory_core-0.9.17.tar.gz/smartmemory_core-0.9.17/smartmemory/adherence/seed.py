"""Seed helper — bootstrap a workspace pattern catalog from a MEMORY.md index.

The Claude Code per-project memory dir keeps a top-level ``MEMORY.md`` index
that points at ``feedback_*.md`` rule files. Each entry has the shape:

    - [Short title here](feedback_xxx.md) — one-line description.

The accompanying file (when present) holds the full rationale. This helper
walks the index, pairs each link with its file body when readable, and
creates a ``Pattern`` per entry. Section headers in MEMORY.md become the
``source`` tag (e.g. ``"memory_md:Quality Rules"``); severity defaults to
``warn`` (caller can post-edit).

Pure parsing — no enforcement, no auto-classification beyond "this came from
MEMORY.md". Designed to be run once per workspace at onboarding.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from smartmemory.adherence.declaration import _PatternManagerBase as PatternManager

logger = logging.getLogger(__name__)


# Match a markdown bullet of the shape:  - [Title](path.md) — description
# The em-dash (—) and the ASCII -- separator both occur in practice.
_LINK_LINE = re.compile(
    r"^\s*-\s+\[(?P<title>[^\]]+)\]\((?P<path>[^)]+)\)\s*[—\-:]+\s*(?P<desc>.+?)\s*$"
)
_SECTION_HEADER = re.compile(r"^##\s+(?P<header>.+?)\s*$")


def _read_text_safely(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception as e:
        logger.debug("seed_patterns: could not read %s: %s", path, e)
        return ""


def _classify_severity(section: str, title: str, body: str) -> str:
    """Heuristic severity from section name + content.

    'Quality Rules' / 'never' / 'must' → error. 'Workflow Rules' →
    warn (default). Anything else stays warn.
    """
    blob = f"{section} {title} {body}".lower()
    if any(s in blob for s in ("never ", "must ", "must not", "forbidden", "banned")):
        return "error"
    if "info" in section.lower() or "tooling" in section.lower():
        return "info"
    return "warn"


def seed_patterns_from_memory_md(
    manager: "PatternManager",
    path: str | Path,
    *,
    source_prefix: str = "memory_md",
    skip_if_title_exists: bool = True,
) -> list[str]:
    """Parse a MEMORY.md index file and create one Pattern per linked rule.

    Args:
        manager: a bound ``PatternManager`` (already tenant-scoped).
        path: filesystem path to the MEMORY.md index.
        source_prefix: prefix for the ``source`` field on created patterns.
            The current section header is appended (``memory_md:Quality Rules``).
        skip_if_title_exists: when True, look up existing patterns by title
            and skip duplicates. Lets the helper run safely on re-import.

    Returns:
        List of newly created ``pattern_id`` strings.

    Raises:
        FileNotFoundError: if the MEMORY.md path doesn't exist.
    """
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f"MEMORY.md not found at {p}")

    text = p.read_text(encoding="utf-8")
    base_dir = p.parent

    existing_titles: set[str] = set()
    if skip_if_title_exists:
        try:
            for inst in manager.queries_for_seed():  # type: ignore[attr-defined]
                existing_titles.add(getattr(inst, "title", ""))
        except Exception:
            # Fall back to no-dedup; manager may not expose the helper.
            pass

    created: list[str] = []
    current_section = "general"

    for line in text.splitlines():
        m_section = _SECTION_HEADER.match(line)
        if m_section:
            current_section = m_section.group("header").strip()
            continue

        m = _LINK_LINE.match(line)
        if not m:
            continue

        title = m.group("title").strip()
        rel_path = m.group("path").strip()
        desc = m.group("desc").strip()

        if title in existing_titles:
            continue

        # Read the linked rule body when present; fall back to the line desc.
        rule_path = (base_dir / rel_path) if not rel_path.startswith("/") else Path(rel_path)
        body = _read_text_safely(rule_path) if rule_path.suffix == ".md" else ""
        rationale = body.strip() if body else desc

        severity = _classify_severity(current_section, title, body)
        source = f"{source_prefix}:{current_section}"

        try:
            inst = manager.create(
                content=desc,
                title=title,
                severity=severity,
                scope=[],  # repo-wide by default; caller refines
                examples=[],
                rationale=rationale,
                source=source,
                version=1,
            )
            created.append(inst.pattern_id)
        except Exception as e:
            logger.warning("seed_patterns: failed to create pattern %r: %s", title, e)

    logger.info("seed_patterns_from_memory_md: created %d patterns from %s", len(created), p)
    return created
