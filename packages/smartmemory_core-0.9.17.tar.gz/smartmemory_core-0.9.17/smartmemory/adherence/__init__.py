"""Adherence pattern catalog (CORE-ADHERENCE-1).

Public API: ``Pattern``, ``PatternHandler``, ``PatternManager``, ``PatternQueries``,
plus the ``seed_patterns_from_memory_md`` helper for bootstrapping a workspace
catalog from an existing Claude Code MEMORY.md index.
"""

from smartmemory.adherence.declaration import (
    _PatternBase as Pattern,
    _PatternHandlerBase as PatternHandler,
    _PatternQueriesBase as _PatternQueriesGenerated,
)
from smartmemory.adherence.manager import PatternManager, PatternQueries
from smartmemory.adherence.seed import seed_patterns_from_memory_md

__all__ = [
    "Pattern",
    "PatternHandler",
    "PatternManager",
    "PatternQueries",
    "seed_patterns_from_memory_md",
]
