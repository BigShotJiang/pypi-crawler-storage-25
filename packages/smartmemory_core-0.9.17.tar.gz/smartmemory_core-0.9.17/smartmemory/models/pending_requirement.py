"""PendingRequirement — what's needed to complete a pending Decision.

Extracted from `models/decision.py` (Path C, CORE-MANAGED-TYPE-FRAMEWORK-1 Phase 2)
to break a circular import: the framework declaration in `decisions/declaration.py`
needs PendingRequirement, and `models/decision.py` needs the framework-derived
base. Splitting this leaf class into its own module breaks the cycle.

`models/decision.py` re-exports PendingRequirement for backward compatibility.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from smartmemory.models.base import MemoryBaseModel


@dataclass
class PendingRequirement(MemoryBaseModel):
    """What's needed to complete a pending decision."""

    requirement_id: str = ""
    description: str = ""
    requirement_type: str = "evidence"  # evidence, confirmation, data
    query_hint: str | None = None
    resolved: bool = False
    resolved_by: str | None = None
    resolved_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "requirement_id": self.requirement_id,
            "description": self.description,
            "requirement_type": self.requirement_type,
            "query_hint": self.query_hint,
            "resolved": self.resolved,
            "resolved_by": self.resolved_by,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "PendingRequirement":
        resolved_at = d.get("resolved_at")
        if isinstance(resolved_at, str):
            resolved_at = datetime.fromisoformat(resolved_at)
        return cls(
            requirement_id=d.get("requirement_id", ""),
            description=d.get("description", ""),
            requirement_type=d.get("requirement_type", "evidence"),
            query_hint=d.get("query_hint"),
            resolved=d.get("resolved", False),
            resolved_by=d.get("resolved_by"),
            resolved_at=resolved_at,
        )
