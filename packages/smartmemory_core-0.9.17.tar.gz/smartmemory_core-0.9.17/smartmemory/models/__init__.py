# Node type imports for smartmemory.graph.nodes

# Memory types constant
from smartmemory.models.memory_item import MEMORY_TYPES, MemoryItem

# Reasoning trace models (System 2 Memory - Phase 2)
from smartmemory.models.reasoning import (
    ReasoningStep,
    ReasoningTrace,
    ReasoningEvaluation,
    TaskContext,
)

# Opinion/Observation models (Synthesis Memory - Phase 3)
from smartmemory.models.opinion import (
    OpinionMetadata,
    ObservationMetadata,
    Disposition,
)

# Decision models (Decision Memory - Phase 4)
# Lazy via __getattr__ below — eager import would create a cycle:
# smartmemory.models -> models.decision -> decisions.declaration -> ... -> back to models package init.

# Library / Document models (Input Management)
from smartmemory.models.library import Library, Document

# CFS-4: Self-Healing Procedures
from smartmemory.models.schema_snapshot import SchemaSnapshot
from smartmemory.models.drift_event import DriftEvent


def __getattr__(name: str):
    """Lazy attribute lookup for managed types — breaks the framework import cycle.

    The CORE-EXPERTISE-1 Phase 3 managed dataclasses (Opinion, Observation,
    Reasoning) live under their own packages and the framework needs MemoryItem
    at import time, so we expose them lazily here so callers can keep using
    ``from smartmemory.models import Opinion`` without triggering the cycle.
    """
    if name == "Decision":
        from smartmemory.models.decision import Decision

        return Decision
    if name == "Constraint":
        from smartmemory.constraints import Constraint

        return Constraint
    if name == "Learned":
        from smartmemory.learned import Learned

        return Learned
    if name == "Opinion":
        from smartmemory.opinions import Opinion

        return Opinion
    if name == "Observation":
        from smartmemory.observations import Observation

        return Observation
    if name == "Reasoning":
        from smartmemory.reasoning import Reasoning

        return Reasoning
    raise AttributeError(f"module 'smartmemory.models' has no attribute {name!r}")


__all__ = [
    "MEMORY_TYPES",
    "MemoryItem",
    # Phase 2: Reasoning
    "ReasoningStep",
    "ReasoningTrace",
    "ReasoningEvaluation",
    "TaskContext",
    "Reasoning",
    # Phase 3: Opinion/Observation
    "OpinionMetadata",
    "ObservationMetadata",
    "Disposition",
    "Opinion",
    "Observation",
    # Phase 4: Decision
    "Decision",
    # CORE-EXPERTISE-1 Phase 2
    "Constraint",
    "Learned",
    # Input Management
    "Library",
    "Document",
    # CFS-4: Self-Healing Procedures
    "SchemaSnapshot",
    "DriftEvent",
]
