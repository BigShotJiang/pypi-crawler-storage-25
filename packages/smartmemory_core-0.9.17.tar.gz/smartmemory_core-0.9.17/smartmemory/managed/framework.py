"""Schema-driven framework for managed memory types (CORE-MANAGED-TYPE-FRAMEWORK-1).

A `ManagedType` declaration produces four classes — Dataclass, Handler, Manager,
Queries — that together implement the Handler+Manager+Queries triad documented
in `smart-memory-core/CLAUDE.md`. The framework targets *decision-like* managed
types: those with `create / get / supersede / retract / (extended:
reinforce / contradict)` public surface and semantic-search-based queries.

Anchor and Plan stay handwritten — their public surfaces don't fit this shape.
See `smart-memory-docs/docs/features/CORE-MANAGED-TYPE-FRAMEWORK-1/` for the
design + blueprint + plan that drove this implementation.
"""

from __future__ import annotations

import dataclasses
import logging
import typing
import uuid
from dataclasses import dataclass, make_dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Literal

# NOTE: `IngestionStrategy` and `MemoryItem` are deliberately NOT imported at
# module load. Doing so triggers `smartmemory/models/__init__.py`, which eagerly
# imports `Decision`, which needs `_DecisionBase` from this package. Lazy import
# inside the builders breaks the cycle.


def _ensure_list(val: Any, default: list | None = None) -> list:
    """Coerce a value to a list, tolerating FalkorDB JSON-string serialization.

    Inlined here (rather than imported from `smartmemory.models.decision`) to
    avoid a circular import: framework → models.decision → decisions.declaration → framework.
    """
    import json

    if default is None:
        default = []
    if isinstance(val, str):
        try:
            val = json.loads(val)
        except (json.JSONDecodeError, TypeError):
            return default
    return val if isinstance(val, list) else default


logger = logging.getLogger(__name__)


# --- Sentinels & errors -----------------------------------------------------


class _UnsetType:
    """Sentinel distinct from None so `default=None` is a valid explicit default."""

    _instance: "_UnsetType | None" = None

    def __new__(cls) -> "_UnsetType":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:  # pragma: no cover
        return "_UNSET"

    def __bool__(self) -> bool:  # so `if field.default:` semantics are sane
        return False


_UNSET = _UnsetType()


class _KeepDefaultOriginType:
    """Sentinel meaning 'do not pass origin= to MemoryItem; let its dataclass default win'.

    Distinct from None (which means 'use f"managed:{name}"') and from a string
    (which is a literal origin value). Used by managed types like Decision whose
    Manager-path nodes must keep MemoryItem.origin at its default ("unknown")
    while the Handler-path uses an explicit "structured:{name}" origin.
    """

    _instance: "_KeepDefaultOriginType | None" = None

    def __new__(cls) -> "_KeepDefaultOriginType":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:  # pragma: no cover
        return "_KEEP_DEFAULT_ORIGIN"


_KEEP_DEFAULT_ORIGIN = _KeepDefaultOriginType()


class FrameworkConfigError(Exception):
    """Raised when a ManagedType / Field declaration is malformed."""


# --- Field ------------------------------------------------------------------


@dataclass(frozen=True)
class Field:
    """Declares a single field on a ManagedType.

    Attributes:
        type: The field's Python type. Generic aliases like `list[str]` are
            unpacked: `type=list, list_of=str`.
        optional: If True, the field is allowed to be missing from input data.
        default: Default value when not provided. `_UNSET` means "no default —
            field is required at validate() time unless `optional=True`".
        indexed: Hint to Handler.get_indexes — when True and no explicit
            index_specs are provided, an index DDL is auto-generated.
        validator: Optional callable run at Handler.validate() time.
        list_of: For list-typed fields, the element type — drives `_ensure_list`
            normalization on from_dict.
        serializer: Per-field hook called at to_dict() time. Required for
            nested-class fields (e.g. `pending_requirements: list[PendingRequirement]`).
        deserializer: Per-field hook called at from_dict() time. Pairs with
            `serializer`.
        carry_forward_on_supersede: When True, Manager.supersede copies the
            value (or appends old.id, for list_of fields) from old → new.
            Used for Decision's `evidence_ids`.
    """

    type: type
    optional: bool = False
    default: Any = _UNSET
    indexed: bool = False
    validator: Callable[[Any], bool] | None = None
    list_of: type | None = None
    serializer: Callable[[Any], Any] | None = None
    deserializer: Callable[[Any], Any] | None = None
    carry_forward_on_supersede: bool = False

    def __post_init__(self) -> None:
        # Resolve generic alias `list[X]` → (type=list, list_of=X)
        origin = typing.get_origin(self.type)
        if origin is list:
            args = typing.get_args(self.type)
            if args:
                # frozen dataclass: object.__setattr__ to bypass frozen guard
                object.__setattr__(self, "type", list)
                if self.list_of is None:
                    object.__setattr__(self, "list_of", args[0])
            else:
                object.__setattr__(self, "type", list)
        elif not isinstance(self.type, type):
            raise FrameworkConfigError(f"Field.type must be a type, got {self.type!r} ({type(self.type).__name__})")


# --- ManagedType ------------------------------------------------------------


_ALLOWED_STATUSES = ("active", "superseded", "retracted", "pending")


_RESERVED_STANDARD = {
    "content",
    "confidence",
    "status",
    "superseded_by",
    "created_at",
    "updated_at",
}
_RESERVED_EXTENDED = _RESERVED_STANDARD | {
    "reinforcement_count",
    "contradiction_count",
    "last_reinforced_at",
    "last_contradicted_at",
}


class ManagedType:
    """A declaration of a managed memory type.

    Call `derive()` to obtain `(DataclassType, HandlerType, ManagerType, QueriesType)`.
    """

    def __init__(
        self,
        name: str,
        fields: dict[str, Field],
        default_confidence: float = 0.8,
        origin: "str | _KeepDefaultOriginType | None" = None,
        handler_origin: str | None = None,
        content_strip: bool = True,
        lifecycle: Literal["standard", "extended"] = "standard",
        produced_allowed_target: bool = False,  # noqa: ARG002 — surface for future evolver wiring
        challengeable: bool = False,  # noqa: ARG002 — surface for AssertionChallenger wiring
        id_field: str = "id",
        id_prefix: str | None = None,
        edge_fn: Callable[[dict, str], list[tuple[str, str, str, dict]]] | None = None,
        index_specs: list[str] | None = None,
        describe_summary: str | None = None,
        extra_manager_methods: dict[str, Callable] | None = None,
        first_class_fn: Callable[[Any], dict] | None = None,
        # Phase 3 knobs (CORE-EXPERTISE-1)
        computed_properties: dict[str, Callable[[Any], Any]] | None = None,
        reinforce_extra: Callable[[Any, str], None] | None = None,
        contradict_extra: Callable[[Any, str], None] | None = None,
        id_generator: Callable[[dict], str] | None = None,
    ):
        if lifecycle not in ("standard", "extended"):
            raise FrameworkConfigError(f"lifecycle must be 'standard' or 'extended', got {lifecycle!r}")
        # Phase 3 Knob C: collision check — id_generator and explicit id_prefix are mutually exclusive
        if id_generator is not None and id_prefix is not None:
            raise ValueError(
                f"ManagedType({name!r}): id_generator and id_prefix are mutually exclusive; set exactly one"
            )
        # Phase 3 Knob A: collision check — computed_properties keys must not shadow declared fields
        if computed_properties:
            overlap = set(computed_properties) & set((fields or {}).keys())
            if overlap:
                raise ValueError(
                    f"ManagedType({name!r}): computed_properties keys collide with declared fields: {sorted(overlap)}"
                )

        self.name = name
        self.fields = dict(fields)
        self.default_confidence = default_confidence
        # Path C knob 1: origin can be a string, None (→ "managed:{name}"), or
        # _KEEP_DEFAULT_ORIGIN (→ leave MemoryItem.origin at its dataclass default).
        if origin is _KEEP_DEFAULT_ORIGIN:
            self.origin = _KEEP_DEFAULT_ORIGIN
        else:
            self.origin = origin if origin is not None else f"managed:{name}"
        # handler_origin always resolves to a real string. Defaults to origin (or
        # to f"managed:{name}" when origin is the sentinel).
        if handler_origin is not None:
            self.handler_origin = handler_origin
        elif self.origin is _KEEP_DEFAULT_ORIGIN:
            self.handler_origin = f"managed:{name}"
        else:
            self.handler_origin = self.origin
        # Path C knob 2: when True (default), reject content that is whitespace-only.
        self.content_strip = content_strip
        self.lifecycle = lifecycle
        self.id_field = id_field
        self.id_prefix = id_prefix if id_prefix is not None else name[:3]
        self.edge_fn = edge_fn
        self.index_specs = index_specs
        self.describe_summary = describe_summary
        self.extra_manager_methods = dict(extra_manager_methods or {})
        # Path C addition: optional callable returning a dict of MemoryItem
        # first-class field overrides (e.g. {"confidence": ..., "derived_from": ...}).
        # Called from `_store_instance` with the dataclass instance. Skip it for
        # types where metadata-only storage is sufficient.
        self.first_class_fn = first_class_fn
        # Phase 3 knobs
        self.computed_properties = dict(computed_properties or {})
        self.reinforce_extra = reinforce_extra
        self.contradict_extra = contradict_extra
        self.id_generator = id_generator

        # Validate no field name collides with reserved or id_field
        reserved = _RESERVED_EXTENDED if lifecycle == "extended" else _RESERVED_STANDARD
        reserved = reserved | {self.id_field}
        collisions = [n for n in self.fields if n in reserved]
        if collisions:
            raise FrameworkConfigError(
                f"ManagedType({name!r}): field name(s) {collisions!r} collide with reserved or id_field"
            )

        self._derived: tuple[type, type, type, type] | None = None

    def derive(self) -> tuple[type, type, type, type]:
        """Build (Dataclass, Handler, Manager, Queries) — cached after first call."""
        if self._derived is None:
            dc = _build_dataclass(self)
            handler = _build_handler(self, dc)
            manager = _build_manager(self, dc, handler)
            queries = _build_queries(self, dc)
            self._derived = (dc, handler, manager, queries)
        return self._derived


# --- Dataclass builder ------------------------------------------------------


def _build_dataclass(mt: ManagedType) -> type:
    """Construct the data class via dataclasses.make_dataclass and bind methods."""
    field_specs: list[tuple] = []

    # Canonical id (named per id_field), content, confidence
    field_specs.append((mt.id_field, str, dataclasses.field(default="")))
    field_specs.append(("content", str, dataclasses.field(default="")))
    field_specs.append(("confidence", float, dataclasses.field(default=mt.default_confidence)))

    # User-declared fields
    for fname, fspec in mt.fields.items():
        field_specs.append((fname, fspec.type, _make_dc_field(fspec)))

    # Standard tail
    field_specs.append(("status", str, dataclasses.field(default="active")))
    # Optional → use type Any to allow None alongside str
    field_specs.append(("superseded_by", typing.Optional[str], dataclasses.field(default=None)))
    field_specs.append(
        (
            "created_at",
            datetime,
            dataclasses.field(default_factory=lambda: datetime.now(timezone.utc)),
        )
    )
    field_specs.append(("updated_at", typing.Optional[datetime], dataclasses.field(default=None)))

    if mt.lifecycle == "extended":
        field_specs.append(("reinforcement_count", int, dataclasses.field(default=0)))
        field_specs.append(("contradiction_count", int, dataclasses.field(default=0)))
        field_specs.append(("last_reinforced_at", typing.Optional[datetime], dataclasses.field(default=None)))
        field_specs.append(("last_contradicted_at", typing.Optional[datetime], dataclasses.field(default=None)))

    cls_name = mt.name[:1].upper() + mt.name[1:]
    Dataclass = make_dataclass(cls_name, field_specs)

    # Bind methods
    Dataclass.to_dict = _make_to_dict(mt)
    Dataclass.from_dict = classmethod(_make_from_dict(mt))
    Dataclass.generate_id = staticmethod(_make_generate_id(mt))

    # Phase 3 Knob A: bind computed_properties as @property descriptors
    for prop_name, prop_fn in mt.computed_properties.items():
        setattr(Dataclass, prop_name, property(prop_fn))

    if mt.lifecycle == "extended":
        Dataclass.reinforce = _model_reinforce
        Dataclass.contradict = _model_contradict

    Dataclass.__managed_type__ = mt  # back-pointer for introspection
    return Dataclass


def _make_dc_field(fspec: Field) -> Any:
    """Translate a Field spec into a dataclasses.field(...) call."""
    if fspec.default is not _UNSET:
        return dataclasses.field(default=fspec.default)
    if fspec.type is list:
        return dataclasses.field(default_factory=list)
    if fspec.type is dict:
        return dataclasses.field(default_factory=dict)
    if fspec.optional:
        return dataclasses.field(default=None)
    # Required + no default — use a sentinel that to_dict/validate will check
    return dataclasses.field(default=None)


def _make_to_dict(mt: ManagedType) -> Callable:
    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for f in dataclasses.fields(self):
            val = getattr(self, f.name)
            fspec = mt.fields.get(f.name)
            if fspec is not None and fspec.serializer is not None:
                out[f.name] = fspec.serializer(val)
            elif isinstance(val, datetime):
                out[f.name] = val.isoformat()
            elif dataclasses.is_dataclass(val) and not isinstance(val, type):
                out[f.name] = dataclasses.asdict(val)
            else:
                out[f.name] = val
        # Phase 3 Knob A: emit computed properties (read-only; from_dict ignores them)
        for prop_name, prop_fn in mt.computed_properties.items():
            try:
                out[prop_name] = prop_fn(self)
            except Exception:
                # Computed property errors are non-fatal during serialization;
                # fields are already captured. Caller can still inspect partial output.
                pass
        return out

    return to_dict


def _make_from_dict(mt: ManagedType) -> Callable:
    def from_dict(cls, d: dict[str, Any]):
        kwargs: dict[str, Any] = {}
        for f in dataclasses.fields(cls):
            if f.name not in d:
                continue
            val = d[f.name]
            fspec = mt.fields.get(f.name)
            if fspec is not None and fspec.deserializer is not None:
                kwargs[f.name] = fspec.deserializer(val)
            elif fspec is not None and fspec.list_of is not None:
                kwargs[f.name] = _ensure_list(val)
            elif f.type is datetime or f.type == "datetime" or "datetime" in str(f.type):
                if isinstance(val, str):
                    try:
                        kwargs[f.name] = datetime.fromisoformat(val)
                    except (ValueError, TypeError) as e:
                        raise ValueError(
                            f"{cls.__name__}.from_dict: field {f.name!r} expected ISO datetime string, got {val!r}"
                        ) from e
                else:
                    kwargs[f.name] = val
            else:
                kwargs[f.name] = val
        return cls(**kwargs)

    return from_dict


def _make_generate_id(mt: ManagedType) -> Callable:
    def generate_id(fields: dict | None = None) -> str:
        # Phase 3 Knob C: when id_generator is set and fields are provided, defer to it.
        # Falls back to the prefix-based default for callers that have no field data
        # (e.g. supersede uses instance.to_dict() to provide them; legacy no-arg callers
        # still get a uuid-based ID).
        if mt.id_generator is not None and fields:
            return mt.id_generator(fields)
        return f"{mt.id_prefix}_{uuid.uuid4().hex[:12]}"

    return generate_id


def _model_reinforce(self, evidence_id: str) -> None:  # noqa: ARG001 — evidence_id may be tracked by Manager
    """Confidence math copied from Decision.reinforce (smartmemory/models/decision.py:174-181)."""
    self.reinforcement_count = (self.reinforcement_count or 0) + 1
    self.confidence = min(1.0, self.confidence + (1.0 - self.confidence) * 0.1)
    self.last_reinforced_at = datetime.now(timezone.utc)


def _model_contradict(self, evidence_id: str) -> None:  # noqa: ARG001
    """Confidence math copied from Decision.contradict (smartmemory/models/decision.py:183-190)."""
    self.contradiction_count = (self.contradiction_count or 0) + 1
    self.confidence = max(0.0, self.confidence - self.confidence * 0.15)
    self.last_contradicted_at = datetime.now(timezone.utc)


# --- Handler builder --------------------------------------------------------


def _build_handler(mt: ManagedType, Dataclass: type) -> type:
    """Build the StructuredHandler-shaped class for this managed type."""
    # Lazy imports — see module-load NOTE.
    from smartmemory.models.ingestion_strategy import IngestionStrategy
    from smartmemory.models.memory_item import MemoryItem

    def __init__(self) -> None:
        pass

    def validate(self, data: dict) -> bool:
        if not isinstance(data, dict):
            return False
        content = data.get("content")
        if not content:
            return False
        # Path C knob 2: reject whitespace-only content when content_strip=True (default).
        if mt.content_strip and isinstance(content, str) and not content.strip():
            return False
        for fname, fspec in mt.fields.items():
            present = fname in data and data[fname] is not None
            # list/dict fields auto-default to empty containers (Decision precedent),
            # so they're never "required" in the validate() sense.
            container_type = fspec.type in (list, dict)
            if not present and not fspec.optional and fspec.default is _UNSET and not container_type:
                return False
            if present and fspec.validator is not None:
                if not fspec.validator(data[fname]):
                    return False
        return True

    def to_memory_item(self, data: dict) -> MemoryItem:
        instance = Dataclass.from_dict(data)  # type: ignore[attr-defined]
        # Phase 3 Knob C: pass input data so id_generator (if set) can use field values
        item_id = getattr(instance, mt.id_field) or Dataclass.generate_id(data)  # type: ignore[attr-defined]
        if not getattr(instance, mt.id_field):
            setattr(instance, mt.id_field, item_id)
        payload = instance.to_dict()
        # Path C knob 1: handler-path origin is always a real string (handler_origin).
        item_kwargs: dict[str, Any] = dict(
            content=payload.get("content", ""),
            memory_type=mt.name,
            item_id=item_id,
            metadata=payload,
            origin=mt.handler_origin,
        )
        # Path C knob 3: per-type first-class field lift (e.g. confidence,
        # derived_from). Same hook the manager path uses — keeps the two paths
        # producing equivalent MemoryItem shapes.
        if mt.first_class_fn is not None:
            item_kwargs.update(mt.first_class_fn(instance))
        return MemoryItem(**item_kwargs)

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        if mt.edge_fn is None:
            return []
        return mt.edge_fn(data, item_id)

    def get_indexes(self) -> list[str]:
        if mt.index_specs is not None:
            return list(mt.index_specs)
        out: list[str] = []
        for fname, fspec in mt.fields.items():
            if fspec.indexed:
                out.append(f"CREATE INDEX IF NOT EXISTS idx_{mt.name}_{fname} ON {mt.name}({fname})")
        return out

    def describe(self) -> dict:
        # DescribableHandler contract (structured.py:52) — the shape the
        # `schemas describe`/`schemas list` CLI consumes (cli.py:116,140):
        # {description, required, optional, edge_types}. The managed-type
        # framework previously emitted its own {name,lifecycle,summary,
        # fields} shape, silently dropping DescribableHandler conformance
        # for every .derive()-produced handler (CORE-STRUCT-CLI-2,
        # regression of CORE-STRUCT-CLI-1). Sourced from declaration
        # metadata; per-field human descriptions don't exist on Field(),
        # so synthesize a type-based string. edge_types is [] — edges are
        # computed dynamically via mt.edge_fn(data,item_id), there is no
        # static edge-type declaration to advertise (accurate, not a
        # swallowed value).
        def _field_desc(fspec) -> str:
            tname = getattr(fspec.type, "__name__", str(fspec.type))
            return f"{tname} (indexed)" if fspec.indexed else tname

        # `content` is the universal primary input: validate() (this file)
        # rejects any payload without it for every managed-derived handler,
        # so it is genuinely required even though it is not a declared
        # Field. The pre-framework CORE-STRUCT-CLI-1 handlers listed it
        # too — omitting it makes `schemas describe` misleading.
        required: dict[str, str] = {"content": "non-empty string (the record body)"}
        optional: dict[str, str] = {}
        for fname, fspec in mt.fields.items():
            # Mirror validate()'s requiredness rule EXACTLY (see validate()
            # in this file): a field is required only when it is not
            # optional AND has no default AND is not a list/dict container
            # (containers auto-default to empty). Anything else is optional
            # — otherwise `schemas describe` lies about what callers must
            # supply (Codex review, CORE-STRUCT-CLI-2).
            container_type = fspec.type in (list, dict)
            is_required = (
                not fspec.optional
                and fspec.default is _UNSET
                and not container_type
            )
            (required if is_required else optional)[fname] = _field_desc(fspec)
        return {
            "description": mt.describe_summary or "",
            "required": required,
            "optional": optional,
            "edge_types": [],
        }

    Handler = type(
        f"{mt.name[:1].upper() + mt.name[1:]}Handler",
        (object,),
        {
            "__init__": __init__,
            "strategy": IngestionStrategy.INDEXED,
            "schema_name": mt.name,
            "embed": None,
            "validate": validate,
            "to_memory_item": to_memory_item,
            "get_edges": get_edges,
            "get_indexes": get_indexes,
            "describe": describe,
        },
    )
    Handler.__managed_type__ = mt
    return Handler


# --- Manager builder --------------------------------------------------------


def _build_manager(mt: ManagedType, Dataclass: type, Handler: type) -> type:
    # Lazy import — see module-load NOTE.
    from smartmemory.models.memory_item import MemoryItem

    id_field = mt.id_field
    handler = Handler()  # singleton; validate() is stateless

    def __init__(self, memory: Any, graph: Any = None) -> None:
        self.memory = memory
        self.graph = graph if graph is not None else getattr(memory, "_graph", None)

    def _store_instance(self, instance, origin_override: str | None = None) -> str:
        item_id = getattr(instance, id_field)
        if not item_id:
            item_id = Dataclass.generate_id(instance.to_dict())  # type: ignore[attr-defined]
            setattr(instance, id_field, item_id)
        payload = instance.to_dict()
        # Path C knob 1: when origin is the sentinel, omit the kwarg so MemoryItem's
        # dataclass default ("unknown") wins. Otherwise pass the configured origin.
        # Phase 3 Knob D (CORE-EXPERTISE-1): a per-call ``origin_override`` lets
        # producers like opinion_synthesis attribute the write to a specific
        # source (``evolver:opinion_synthesis``) without changing the type-level
        # default. The override always wins when set.
        item_kwargs: dict[str, Any] = dict(
            content=payload.get("content", ""),
            memory_type=mt.name,
            item_id=item_id,
            metadata=payload,
        )
        if origin_override is not None:
            item_kwargs["origin"] = origin_override
        elif mt.origin is not _KEEP_DEFAULT_ORIGIN:
            item_kwargs["origin"] = mt.origin
        # Path C: per-type first-class field lift (e.g. confidence, derived_from).
        if mt.first_class_fn is not None:
            item_kwargs.update(mt.first_class_fn(instance))
        item = MemoryItem(**item_kwargs)
        self.memory.add(item)
        return item_id

    def _update_instance(self, instance) -> None:
        instance.updated_at = datetime.now(timezone.utc)
        item_id = getattr(instance, id_field)
        self.memory.update_properties(item_id, instance.to_dict())

    def _hydrate(self, item_id: str):
        item = self.memory.get(item_id)
        if item is None:
            return None
        # Backends sometimes return MemoryItem with first-class `content` populated
        # but metadata['content'] empty (storage round-trip). Fall back so the
        # dataclass round-trip preserves content.
        metadata = dict(item.metadata or {})
        if not metadata.get("content"):
            metadata["content"] = getattr(item, "content", "") or ""
        # Phase 3 T10 defensive restore: legacy-persisted rows (created via
        # raw memory.add(MemoryItem) before the ManagedType framework existed)
        # don't carry <type>_id in metadata. Without this restore, _hydrate
        # produces an instance with an empty id_field, _update_instance reads
        # that empty string and writes to a non-existent node. Generalizes
        # the per-method restore T11 added inside ObservationManager._add_source.
        if not metadata.get(id_field):
            source_id = getattr(item, "item_id", "") or item_id
            if source_id:
                metadata[id_field] = source_id
        # Phase 3 T10: invert `first_class_fn`. The Manager's write path lifts
        # certain dataclass fields to top-level MemoryItem attributes (e.g.
        # `confidence` for opinions, via `_opinion_first_class`). Storage
        # backends often DROP those keys from metadata once they're stored as
        # node properties. Without this restore, hydrate falls back to the
        # dataclass defaults — silently losing the persisted value and
        # corrupting downstream math (e.g. reinforce starting from 0.5 instead
        # of 0.6). Mirrors the id_field restore directly above.
        if mt.first_class_fn is not None:
            try:
                first_class_keys = list(mt.first_class_fn(Dataclass()).keys())  # type: ignore[call-arg]
            except Exception:
                first_class_keys = []
            for key in first_class_keys:
                if metadata.get(key) is None:
                    val = getattr(item, key, None)
                    if val is not None:
                        metadata[key] = val
        return Dataclass.from_dict(metadata)  # type: ignore[attr-defined]

    def create(self, content: str, *, origin: str | None = None, **fields):
        """Create and persist an instance.

        Phase 3 Knob D (CORE-EXPERTISE-1): the keyword-only ``origin`` arg
        overrides the type-level default for this call only. Used by producer
        sites like ``opinion_synthesis.py`` that need to attribute the write to
        a specific source (``evolver:opinion_synthesis``) without changing the
        type's user-facing default origin.
        """
        valid = {f.name for f in dataclasses.fields(Dataclass)}
        unknown = [k for k in fields if k not in valid]
        if unknown:
            raise TypeError(f"{mt.name}.create() got unexpected field(s): {unknown!r}")
        if "status" in fields and fields["status"] not in _ALLOWED_STATUSES:
            raise ValueError(f"status must be one of {_ALLOWED_STATUSES}, got {fields['status']!r}")
        # Run handler validation against the input shape before instantiating.
        validation_payload = dict(fields)
        validation_payload["content"] = content
        if not handler.validate(validation_payload):
            raise ValueError(f"{mt.name}.create(): validation failed for payload {validation_payload!r}")
        kwargs = dict(fields)
        kwargs["content"] = content
        instance = Dataclass(**kwargs)
        if not getattr(instance, id_field):
            # Phase 3 Knob C: kwargs (with content) carries enough field data for id_generator
            setattr(instance, id_field, Dataclass.generate_id(kwargs))  # type: ignore[attr-defined]
        item_id = self._store_instance(instance, origin_override=origin)
        if mt.edge_fn is not None and self.graph is not None:
            for src, tgt, rel, props in mt.edge_fn(instance.to_dict(), item_id):
                self.graph.add_edge(src, tgt, rel, props)
        return instance

    def get(self, item_id: str):
        return self._hydrate(item_id)

    def supersede(self, old_id: str, new_instance, reason: str):
        old = self._hydrate(old_id)
        if old is None:
            raise ValueError(f"{mt.name} {old_id!r} not found")
        if old.status != "active":
            raise ValueError(f"{mt.name} {old_id!r} is in status {old.status!r}; only 'active' items can be superseded")

        if not getattr(new_instance, id_field):
            setattr(new_instance, id_field, Dataclass.generate_id(new_instance.to_dict()))  # type: ignore[attr-defined]

        # Carry-forward fields
        for fname, fspec in mt.fields.items():
            if not fspec.carry_forward_on_supersede:
                continue
            old_val = getattr(old, fname, None)
            new_val = getattr(new_instance, fname, None)
            if fspec.list_of is not None:
                # Append old.id (deduplicated) to new.<field>
                if new_val is None:
                    new_val = []
                if old_id not in new_val:
                    new_val.append(old_id)
                setattr(new_instance, fname, new_val)
            else:
                # Scalar: copy from old only when new is empty
                if not new_val and old_val is not None:
                    setattr(new_instance, fname, old_val)

        new_id = self._store_instance(new_instance)

        old.status = "superseded"
        old.superseded_by = new_id
        self._update_instance(old)

        if self.graph is not None:
            self.graph.add_edge(new_id, old_id, "SUPERSEDES", {"reason": reason})

        return new_instance

    def retract(self, item_id: str, reason: str) -> None:
        instance = self._hydrate(item_id)
        if instance is None:
            raise ValueError(f"{mt.name} {item_id!r} not found")
        instance.status = "retracted"
        # Persist via update_properties; include retraction_reason in payload
        instance.updated_at = datetime.now(timezone.utc)
        payload = instance.to_dict()
        payload["retraction_reason"] = reason
        self.memory.update_properties(item_id, payload)

    namespace = {
        "__init__": __init__,
        "_store_instance": _store_instance,
        "_update_instance": _update_instance,
        "_hydrate": _hydrate,
        "create": create,
        "get": get,
        "supersede": supersede,
        "retract": retract,
    }

    if mt.lifecycle == "extended":

        def reinforce(self, item_id: str, evidence_id: str):
            instance = self._hydrate(item_id)
            if instance is None:
                raise ValueError(f"{mt.name} {item_id!r} not found")
            instance.reinforce(evidence_id)
            # Phase 3 Knob B: invoke reinforce_extra AFTER base math, BEFORE _update_instance
            # so the hook sees post-math state and any mutations land in the persisted payload.
            if mt.reinforce_extra is not None:
                mt.reinforce_extra(instance, evidence_id)
            self._update_instance(instance)
            if self.graph is not None:
                self.graph.add_edge(item_id, evidence_id, "DERIVED_FROM", {})
            return instance

        def contradict(self, item_id: str, evidence_id: str):
            instance = self._hydrate(item_id)
            if instance is None:
                raise ValueError(f"{mt.name} {item_id!r} not found")
            instance.contradict(evidence_id)
            # Phase 3 Knob B: contradict_extra runs AFTER base math, BEFORE persistence.
            if mt.contradict_extra is not None:
                mt.contradict_extra(instance, evidence_id)
            self._update_instance(instance)
            if self.graph is not None:
                # Direction: evidence contradicts item (matches DecisionManager.contradict)
                self.graph.add_edge(evidence_id, item_id, "CONTRADICTS", {})
            return instance

        namespace["reinforce"] = reinforce
        namespace["contradict"] = contradict

    # Bind escape-hatch extra methods last so user can override standard ones if they really want
    namespace.update(mt.extra_manager_methods)

    Manager = type(
        f"{mt.name[:1].upper() + mt.name[1:]}Manager",
        (object,),
        namespace,
    )
    Manager.__managed_type__ = mt
    return Manager


# --- Queries builder --------------------------------------------------------


def _build_queries(mt: ManagedType, Dataclass: type) -> type:
    def __init__(self, memory: Any, graph: Any = None) -> None:
        self.memory = memory
        self.graph = graph if graph is not None else getattr(memory, "_graph", None)

    def _hydrate(self, item) -> Any:
        try:
            metadata = dict(getattr(item, "metadata", None) or {})
            if not metadata.get("content"):
                metadata["content"] = getattr(item, "content", "") or ""
            return Dataclass.from_dict(metadata)  # type: ignore[attr-defined]
        except Exception as e:
            logger.warning("Failed to hydrate %s from MemoryItem: %s", mt.name, e)
            return None

    def _broad_search(self, top_k: int) -> list:
        try:
            return self.memory.search(query="*", memory_type=mt.name, top_k=top_k)
        except Exception:
            try:
                return self.memory.search(query=mt.name, memory_type=mt.name, top_k=top_k)
            except Exception as e:
                logger.warning("Failed to search for %s: %s", mt.name, e)
                return []

    def get_active(self, filters: dict | None = None, limit: int = 50):
        items = self._broad_search(limit * 2)
        out = []
        filters = filters or {}
        for item in items:
            inst = self._hydrate(item)
            if inst is None:
                continue
            if getattr(inst, "status", "active") != "active":
                continue
            ok = True
            for k, v in filters.items():
                if getattr(inst, k, None) != v:
                    ok = False
                    break
            if not ok:
                continue
            out.append(inst)
            if len(out) >= limit:
                break
        return out

    def get_by_id(self, item_id: str):
        item = self.memory.get(item_id)
        if item is None:
            return None
        return self._hydrate(item)

    def get_about(self, topic: str, limit: int = 20):
        try:
            items = self.memory.search(query=topic, memory_type=mt.name, top_k=limit * 2)
        except Exception as e:
            logger.warning("Failed to search %s about %r: %s", mt.name, topic, e)
            return []
        out = []
        for item in items:
            inst = self._hydrate(item)
            if inst is None:
                continue
            if getattr(inst, "status", "active") != "active":
                continue
            out.append(inst)
            if len(out) >= limit:
                break
        return out

    Queries = type(
        f"{mt.name[:1].upper() + mt.name[1:]}Queries",
        (object,),
        {
            "__init__": __init__,
            "_hydrate": _hydrate,
            "_broad_search": _broad_search,
            "get_active": get_active,
            "get_by_id": get_by_id,
            "get_about": get_about,
        },
    )
    Queries.__managed_type__ = mt
    return Queries
