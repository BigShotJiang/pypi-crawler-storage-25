"""Exception types raised by managed-type Managers (CORE-EXPERTISE-1 Phase 3 T2).

These are NOT input-validation errors (which still raise ValueError from
Manager.create). They surface domain-level Manager rejections — for example,
a quality gate failing on a reasoning trace at create_trace() time.
"""

from __future__ import annotations


class ManagedTypeError(Exception):
    """Base for managed-type Manager-level errors that are NOT input validation."""


class QualityGateRejected(ManagedTypeError):
    """A quality gate refused to admit an instance to the store.

    Used by ReasoningManager.create_trace() when the trace fails its
    evaluation gate and the caller did not pass bypass=True.
    """

    def __init__(self, trace_id: str, reasons: list[str]) -> None:
        super().__init__(f"trace {trace_id} rejected: {'; '.join(reasons)}")
        self.trace_id = trace_id
        self.reasons = list(reasons)
