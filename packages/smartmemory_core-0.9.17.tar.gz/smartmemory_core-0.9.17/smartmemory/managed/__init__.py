"""Schema-driven framework for managed memory types.

See `smartmemory.managed.framework` for the implementation and
`smart-memory-docs/docs/features/CORE-MANAGED-TYPE-FRAMEWORK-1/` for the design.
"""

from smartmemory.managed.framework import (
    Field,
    FrameworkConfigError,
    ManagedType,
    _KEEP_DEFAULT_ORIGIN,
)

__all__ = ["ManagedType", "Field", "FrameworkConfigError", "_KEEP_DEFAULT_ORIGIN"]
