"""Learned memory type — durable lessons from incidents/experiences.

Public API: Learned, LearnedHandler, LearnedManager, LearnedQueries.
All four are derived from `_LEARNED_TYPE` in declaration.py — no subclass needed.
"""

from smartmemory.learned.declaration import (
    _LearnedBase as Learned,
    _LearnedHandlerBase as LearnedHandler,
    _LearnedManagerBase as LearnedManager,
    _LearnedQueriesBase as LearnedQueries,
)

__all__ = ["Learned", "LearnedHandler", "LearnedManager", "LearnedQueries"]
