"""ManagedType declaration for the `learned` memory type.

Lessons learned from incidents/experiences. Structured replacement for the
`feedback_*.md` files. INDEXED, queryable by status/category.

See smart-memory-docs/docs/features/CORE-EXPERTISE-1/phase-2-constraint-learned/spec.md
"""

from __future__ import annotations

from smartmemory.managed import Field, ManagedType


def _learned_first_class(instance) -> dict:
    """Lift confidence to MemoryItem first-class."""
    return {"confidence": instance.confidence}


_LEARNED_TYPE = ManagedType(
    name="learned",
    fields={
        "category": Field(str, optional=True, indexed=True),
        "incident_link": Field(str, optional=True),
    },
    default_confidence=0.9,
    origin="user:learned",
    handler_origin="structured:learned",
    lifecycle="standard",
    id_field="learned_id",
    id_prefix="lrn",
    first_class_fn=_learned_first_class,
    index_specs=[
        "CREATE INDEX IF NOT EXISTS idx_learned_status "
        "ON nodes(json_extract(properties, '$.status')) WHERE memory_type='learned'",
        "CREATE INDEX IF NOT EXISTS idx_learned_category "
        "ON nodes(json_extract(properties, '$.category')) WHERE memory_type='learned'",
    ],
    describe_summary=(
        "Lessons-learned records — durable lessons from incidents/experiences. "
        "INDEXED, queryable by status/category."
    ),
)


_LearnedBase, _LearnedHandlerBase, _LearnedManagerBase, _LearnedQueriesBase = (
    _LEARNED_TYPE.derive()
)
