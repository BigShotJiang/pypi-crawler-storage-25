"""TimelineEntryHandler — derived FS-canonical timeline index (APP-VAULT-SYNC-1 Phase 1).

Strategy: APPEND — a derived index over the vault's FS-canonical
``## Timeline`` blocks. Never embedded, never entity-extracted: the file is
the system of record, these nodes are a rebuildable graph projection of it.

Identity is occurrence-indexed content ``(entity_id, raw_line_sha1,
occurrence_index)`` — position-independent (survives mid-block inserts) and
duplicate-safe (two byte-identical lines are distinct occurrences). One
``PART_OF`` edge links the entry to its source entity node.
"""

from __future__ import annotations

from typing import Optional

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class TimelineEntryHandler:
    """Structured handler for FS-canonical timeline index entries."""

    strategy = IngestionStrategy.APPEND
    schema_name = "timeline_entry"
    embed: Optional[bool] = None

    def validate(self, data: dict) -> bool:
        """Require a verbatim ``raw_line`` and the owning ``entity_id``."""
        return (
            isinstance(data.get("raw_line"), str)
            and len(data["raw_line"]) > 0
            and isinstance(data.get("entity_id"), str)
            and len(data["entity_id"]) > 0
        )

    def to_memory_item(self, data: dict) -> MemoryItem:
        return MemoryItem(
            content=data["raw_line"],
            memory_type="timeline_entry",
            origin=data.get("origin", "import:vault"),
            metadata={
                "entity_id": data["entity_id"],
                "raw_line_sha1": data.get("raw_line_sha1"),
                "occurrence_index": data.get("occurrence_index", 0),
                "line_ordinal": data.get("line_ordinal"),
                "source": data.get("source", "fs"),
                "ts": data.get("ts"),
                "event": data.get("event"),
                "explanation": data.get("explanation"),
                "detached": data.get("detached", False),
            },
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        """One ``PART_OF`` edge: timeline entry -> source entity node."""
        return [
            (
                item_id,
                data["entity_id"],
                "PART_OF",
                {"origin": "import:vault", "confidence": 1.0},
            )
        ]

    def get_indexes(self) -> list[str]:
        return [
            "CREATE INDEX IF NOT EXISTS idx_timeline_entry_entity "
            "ON nodes(json_extract(properties, '$.entity_id')) WHERE memory_type='timeline_entry'",
            "CREATE INDEX IF NOT EXISTS idx_timeline_entry_hash "
            "ON nodes(json_extract(properties, '$.raw_line_sha1')) WHERE memory_type='timeline_entry'",
        ]

    def describe(self) -> dict:
        return {
            "description": (
                "Derived FS-canonical timeline index — APPEND, occurrence-indexed "
                "content identity, PART_OF the source entity. Rebuildable from the vault."
            ),
            "required": {
                "raw_line": "verbatim timeline line (canonical value)",
                "entity_id": "owning entity node id",
            },
            "optional": {
                "raw_line_sha1": "sha1(raw_line)",
                "occurrence_index": "int — k-th byte-identical line for the entity",
                "line_ordinal": "int — informational only, never keys",
                "source": "'graph' | 'fs'",
                "ts": "str", "event": "str", "explanation": "str",
                "detached": "bool — set when an fs entry vanished from the file",
            },
            "edge_types": ["PART_OF"],
        }
