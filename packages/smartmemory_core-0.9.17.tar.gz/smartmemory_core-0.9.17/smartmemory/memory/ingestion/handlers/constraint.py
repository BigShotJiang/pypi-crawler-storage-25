"""ConstraintHandler — re-export of the framework-derived handler.

Origin (`structured:constraint`), whitespace-strip validation, first-class
confidence lift, and SQLite indexes are all handled by the ManagedType
declaration in `smartmemory.constraints.declaration`.
"""

from smartmemory.constraints.declaration import _ConstraintHandlerBase as ConstraintHandler

__all__ = ["ConstraintHandler"]
