"""StructuredHandler shim for the `reasoning` memory type (Phase 3 T5)."""

from smartmemory.reasoning.declaration import _ReasoningHandlerBase as ReasoningHandler

__all__ = ["ReasoningHandler"]
