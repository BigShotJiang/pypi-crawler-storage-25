"""DecisionHandler — structured ingestion for decision records.

Path C migration (CORE-MANAGED-TYPE-FRAMEWORK-1 Phase 2 → Phase 3 polish):
DecisionHandler is now the framework-derived handler from `_DECISION_TYPE.derive()`,
re-exported under its public name. Origin (`structured:decision`) and
whitespace-stripped validation are handled by framework knobs 1+2; first-class
`confidence`/`derived_from` lift is handled by knob 3 (`first_class_fn`).
No subclass needed.
"""

from smartmemory.decisions.declaration import _DecisionHandlerBase as DecisionHandler

__all__ = ["DecisionHandler"]
