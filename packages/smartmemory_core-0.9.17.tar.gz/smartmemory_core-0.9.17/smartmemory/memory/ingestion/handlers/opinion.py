"""StructuredHandler shim for the `opinion` memory type (Phase 3 T3).

Re-exports the framework-derived OpinionHandler so structured.py registration
can find it at a stable import path.
"""

from smartmemory.opinions.declaration import _OpinionHandlerBase as OpinionHandler

__all__ = ["OpinionHandler"]
