"""LearnedHandler — re-export of the framework-derived handler."""

from smartmemory.learned.declaration import _LearnedHandlerBase as LearnedHandler

__all__ = ["LearnedHandler"]
