"""PatternHandler — re-export of the framework-derived handler (CORE-ADHERENCE-1)."""

from smartmemory.adherence.declaration import _PatternHandlerBase as PatternHandler

__all__ = ["PatternHandler"]
