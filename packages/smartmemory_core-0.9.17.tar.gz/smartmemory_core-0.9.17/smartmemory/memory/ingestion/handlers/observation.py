"""StructuredHandler shim for the `observation` memory type (Phase 3 T4)."""

from smartmemory.observations.declaration import _ObservationHandlerBase as ObservationHandler

__all__ = ["ObservationHandler"]
