"""
Search component for SmartMemory system.
Provides unified search interface across all memory types using enhanced similarity framework.
"""

import logging
import re
from collections.abc import Iterable
from typing import List, Optional, Dict, Any, cast

from smartmemory.models.memory_item import MemoryItem
from smartmemory.similarity.framework import EnhancedSimilarityFramework

# Cypher identifier guard for `search_by_metadata`. Storage flattens metadata
# with `__` (see MemoryItemSerializer.to_storage), so nested keys like
# `metadata.bot_topic` land as the top-level prop `bot_topic`. We accept
# `[a-zA-Z_][\w]*` (Cypher-safe) and translate any caller-supplied `.` to `__`
# so callers can write `nested.key` and have it match the flattened prop.
_SAFE_METADATA_KEY = re.compile(r"^[a-zA-Z_][\w]*$")

logger = logging.getLogger(__name__)

# System-internal node types that should never appear in user-facing search results.
_SYSTEM_NODE_TYPES = frozenset({"Version"})


class Search:
    """Search component for SmartMemory system."""

    def __init__(self, graph):
        """Initialize search component with graph backend."""
        self.graph = graph
        self.similarity_framework = EnhancedSimilarityFramework()

    def search(self, query: str, top_k: int = 5, memory_type: Optional[str] = None, **kwargs) -> List[MemoryItem]:
        """
        Search for memory items using enhanced similarity framework.
        
        Args:
            query: Search query string
            top_k: Maximum number of results to return
            memory_type: Optional filter by memory type
            **kwargs: Additional search options (e.g. enable_hybrid=True)
            
        Returns:
            List of MemoryItems ranked by similarity
        """
        query_text = query or ""

        # Initialize cache variable
        cache = None

        # Try Redis cache first for performance improvement
        try:
            from smartmemory.utils.cache import get_cache
            cache = get_cache()

            # Check cache for existing search results
            cached_results = cache.get_search_results(query_text, top_k, memory_type)
            if cached_results is not None:
                logger.debug(f"Cache hit for search: {query_text[:50]}...")
                return cached_results

            logger.debug(f"Cache miss for search: {query_text[:50]}...")
        except Exception as cache_error:
            logger.warning(f"Redis cache unavailable for search: {cache_error}")
            cache = None
        # First try SmartGraph's built-in search which is optimized
        try:
            graph_search = getattr(self.graph, 'search', None)
            search_fn = None
            if callable(graph_search):
                search_fn = graph_search
            else:
                candidate = getattr(graph_search, 'search', None)
                if callable(candidate):
                    search_fn = candidate

            if search_fn:
                results = search_fn(query_text, top_k=top_k * 2, **kwargs)
                if results:
                    results = list(cast(Iterable[MemoryItem], results))
                else:
                    results = []

                # Exclude system-internal nodes (Version, etc.)
                if results:
                    results = [
                        item for item in results
                        if getattr(item, 'memory_type', None) not in _SYSTEM_NODE_TYPES
                    ]

                # Filter by memory type if specified
                if memory_type and results:
                    results = [item for item in results if getattr(item, 'memory_type', None) == memory_type]

                # Apply recency sort if requested (recall uses this)
                if results and kwargs.get("sort_by") == "recency":
                    results.sort(key=lambda item: getattr(item, "created_at", None) or "0000-00-00", reverse=True)

                # Return top_k results if we got matches
                if results:
                    return results[:top_k]
                # Empty results — fall through to manual search
        except Exception as e:
            # Log the error but continue with fallback
            logger.warning(f"SmartGraph search failed: {e}, falling back to manual search", exc_info=True)

        # Fallback: Get all items manually and apply similarity
        all_items = []
        try:
            if hasattr(self.graph, 'get_all_node_ids'):
                # Get all node IDs and retrieve each node
                node_ids = self.graph.get_all_node_ids()
                for node_id in node_ids:
                    try:
                        item = self.graph.get_node(node_id)
                        if item and isinstance(item, MemoryItem):
                            all_items.append(item)
                    except Exception:
                        # Skip nodes that can't be retrieved
                        continue
        except Exception as e:
            logger.warning(f"Search fallback failed, returning empty results: {e}")
            return []

        # Exclude system-internal nodes (Version, etc.)
        all_items = [item for item in all_items if getattr(item, 'memory_type', None) not in _SYSTEM_NODE_TYPES]

        # Filter by memory type if specified
        if memory_type:
            all_items = [item for item in all_items if getattr(item, 'memory_type', None) == memory_type]

        # If no items found, return empty
        if not all_items:
            return []

        if kwargs.get("sort_by") == "recency":
            all_items.sort(key=lambda item: getattr(item, "created_at", None) or "0000-00-00", reverse=True)
            return all_items[:top_k]

        # Create query item for similarity comparison
        query_item = MemoryItem(
            content=query_text,
            memory_type="query",
            metadata={}
        )

        # Calculate similarities and rank results
        scored_items = []
        for item in all_items:
            try:
                similarity = self.similarity_framework.calculate_similarity(query_item, item)
                scored_items.append((similarity, item))
            except Exception as e:
                # Log similarity calculation errors - they may indicate data quality issues
                logger.warning(f"Similarity calculation failed for item {getattr(item, 'item_id', 'unknown')}: {e}")
                # Continue processing other items, but don't silently ignore the error
                continue

        # Filter by similarity threshold — never return irrelevant results
        min_threshold = 0.3  # Minimum relevance to be worth returning
        scored_items = [(score, item) for score, item in scored_items if score >= min_threshold]

        # Sort by similarity (descending) and return top_k
        scored_items.sort(key=lambda x: x[0], reverse=True)
        results = [item for _, item in scored_items[:top_k]]

        # Cache the results for future use
        if cache is not None and results:
            try:
                cache.set_search_results(query_text, top_k, results, memory_type)
                logger.debug(f"Cached search results for: {query_text[:50]}...")
            except Exception as cache_error:
                logger.warning(f"Failed to cache search results: {cache_error}")

        return results

    def embeddings_search(self, embedding, top_k: int = 5) -> List[MemoryItem]:
        """
        Search for memory items most similar to the given embedding using the vector store.
        Provides proper abstraction for vector store operations.
        
        Args:
            embedding: Query embedding vector
            top_k: Maximum number of results to return
            
        Returns:
            List of MemoryItems ranked by embedding similarity
        """
        try:
            from smartmemory.stores.vector.vector_store import VectorStore
            vector_store = VectorStore()
            hits = vector_store.search(embedding, top_k=top_k)
            results = []
            for hit in hits:
                # Use the graph to get the full MemoryItem
                item = self.graph.get_node(hit['id'])
                if item:
                    results.append(item)
            return results
        except Exception as e:
            logger.warning(f"Vector store search failed: {e}")
            return []

    def search_by_embedding(self, embedding: List[float], top_k: int = 5) -> List[MemoryItem]:
        """
        Search using embedding vector.
        
        Args:
            embedding: Query embedding vector
            top_k: Maximum number of results to return
            
        Returns:
            List of MemoryItems ranked by embedding similarity
        """
        return self.embeddings_search(embedding, top_k=top_k)

    def search_by_metadata(self, metadata_filters: Dict[str, Any], top_k: int = 5) -> List[MemoryItem]:
        """Search by metadata filters using a parameterized graph query.

        Replaces the prior get-all-items scan, which depended on a
        `get_all_items` method that does not exist on `SmartGraph` and silently
        returned `[]` for every call (see `.claude/rules/no-silent-degradation.md`).

        Storage flattens metadata into top-level node properties via
        `MemoryItemSerializer.to_storage` (separator `__`). So a write of
        `{metadata: {bot_topic: "ml-research"}}` lands as the node prop
        `n.bot_topic`. This method queries those flat props directly via
        `backend._query`, with safety:

        - Key names are guarded by `_SAFE_METADATA_KEY` (alphanumeric + `_`)
          before interpolation into the Cypher string; unsafe keys are silently
          dropped from the filter set.
        - A caller-supplied `.` in a key is translated to `__` so the public
          nested syntax (`metadata.subkey`) matches the flattened storage.
        - All values are passed as bound parameters, never interpolated.
        - The backend is required; missing `_query` raises rather than silently
          returning `[]`.

        Args:
            metadata_filters: Dictionary of metadata key-value pairs to match
                (AND semantics across all pairs)
            top_k: Maximum number of results to return

        Returns:
            List of MemoryItems matching every filter, length <= top_k.

        Raises:
            RuntimeError: If the graph backend doesn't expose `_query()`.
        """
        if not metadata_filters:
            return []

        backend = getattr(self.graph, "backend", None)
        if backend is None or not hasattr(backend, "_query"):
            raise RuntimeError(
                "search_by_metadata requires a graph backend exposing _query(); "
                f"got {type(self.graph).__name__} with backend={type(backend).__name__}"
            )

        where_parts: List[str] = []
        params: Dict[str, Any] = {}

        # SECURITY: scope to the current workspace at the Cypher level when a
        # workspace is actually configured. Defense-in-depth —
        # `SecureSmartMemory.search_by_metadata` also post-filters via
        # `scope_provider.owns_item`, but that path has a documented
        # fallback-on-user_id branch that can leak across workspaces for shared
        # service accounts (e.g. user_id=tenant=workspace name). By filtering
        # here we guarantee no cross-workspace items ever leave the graph
        # layer, regardless of wrapper behavior. Matches the pattern in
        # `smartmemory.graph.types.zettel.notes_mentioning`.
        #
        # OSS mode: when no scope_provider is configured (workspace_id is
        # None), we deliberately do NOT add a workspace filter — writes don't
        # stamp workspace_id either, so the items are tagged as
        # "unscoped" and must be findable. This matches `search()` semantics.
        scope = getattr(backend, "scope_provider", None)
        scope_ws = getattr(scope, "workspace_id", None) if scope is not None else None
        if scope_ws:
            where_parts.append("n.workspace_id = $_ws_id")
            params["_ws_id"] = scope_ws

        for i, (key, value) in enumerate(metadata_filters.items()):
            flat_key = key.replace(".", "__")
            if not _SAFE_METADATA_KEY.match(flat_key):
                logger.warning(
                    "search_by_metadata: dropping unsafe metadata key %r "
                    "(must match %s after `.` -> `__` translation)",
                    key, _SAFE_METADATA_KEY.pattern,
                )
                continue
            pname = f"v{i}"
            where_parts.append(f"n.{flat_key} = ${pname}")
            params[pname] = value

        if not where_parts or all(p.startswith("n.workspace_id") for p in where_parts):
            # All caller-supplied filters were rejected. Returning [] rather
            # than running an unscoped MATCH that would dump everything in the
            # workspace.
            return []

        cypher = (
            f"MATCH (n) WHERE {' AND '.join(where_parts)} "
            f"RETURN n LIMIT {int(top_k)}"
        )

        result = backend._query(cypher, params)
        rows = getattr(result, "result_set", None) or result or []

        items: List[MemoryItem] = []
        for row in rows:
            node = row[0] if isinstance(row, (list, tuple)) else row
            if hasattr(node, "properties"):
                node_dict = dict(node.properties)
            elif isinstance(node, dict):
                node_dict = dict(node)
            else:
                logger.warning(
                    "search_by_metadata: skipping row with unexpected node "
                    "type %s", type(node).__name__,
                )
                continue
            items.append(MemoryItem.from_node(node_dict))

        return items
