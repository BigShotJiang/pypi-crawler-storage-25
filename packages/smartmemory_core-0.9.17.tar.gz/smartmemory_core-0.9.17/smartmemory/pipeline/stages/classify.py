"""Classify stage — wraps MemoryIngestionFlow.classify_item()."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from smartmemory.pipeline.state import PipelineState

if TYPE_CHECKING:
    from smartmemory.pipeline.config import PipelineConfig

# Deterministic priority order for memory_type selection from a classify result set.
# classify_item() returns a set-derived list with non-deterministic ordering; picking
# [0] from that list is hash-seed-dependent. This tuple defines the canonical order:
# specific types (decision, reasoning, zettel) override generic defaults (semantic).
# Any type not listed here falls to the end of priority.
#
# ZETTEL-RESCUE-1 Phase 2 (2026-05-20): "zettel" elevated from "routing-only flag"
# to first-class storage memory_type. Previously this lookup excluded zettel and
# stripped it from the storage label, but downstream consumers (RC-3
# `find_notes_by_property` filter, `/zettel/by-tag/{tag}` route, `find_notes_by_tag`,
# discord-bot queries) all require `memory_type:"zettel"` to be queryable on the
# persisted node. The drift had already happened in callers; this change aligns
# the producer with how the system actually uses the field.
_TYPE_PRIORITY: tuple = ("decision", "reasoning", "zettel", "episodic", "procedural", "semantic")


class ClassifyStage:
    """Determine memory types for the incoming text."""

    def __init__(self, ingestion_flow):
        """Args: ingestion_flow — a MemoryIngestionFlow instance (has classify_item)."""
        self._flow = ingestion_flow

    @property
    def name(self) -> str:
        return "classify"

    def execute(self, state: PipelineState, config: PipelineConfig) -> PipelineState:
        from smartmemory.models.memory_item import MemoryItem
        from smartmemory.memory.pipeline.config import ClassificationConfig

        # Build a MemoryItem so classify_item can inspect metadata
        item = MemoryItem(
            content=state.text,
            memory_type=state.memory_type or "semantic",
            metadata=dict(state.raw_metadata),
        )

        # Map v2 config → legacy ClassificationConfig
        legacy_conf = ClassificationConfig(
            content_analysis_enabled=config.classify.content_analysis_enabled,
            default_confidence=config.classify.default_confidence,
            inferred_confidence=config.classify.inferred_confidence,
        )

        types = self._flow.classify_item(item, legacy_conf)

        # Determine memory_type for storage.
        #
        # ZETTEL-RESCUE-1 Phase 2 (2026-05-20): explicit user-supplied memory_type
        # wins unconditionally. Three sources, in priority:
        #   1. state.memory_type set on the initial PipelineState (most direct)
        #   2. raw_metadata["memory_type"] (carries user intent via meta-setdefault
        #      at smart_memory.py:1266; survives even when stage-construction
        #      drops state.memory_type)
        #   3. classify_item() inferred — pick the highest-priority type
        explicit_mt = state.memory_type or (state.raw_metadata or {}).get("memory_type")
        if explicit_mt and explicit_mt != "semantic":
            # "semantic" is the catch-all default; treat it as "no explicit intent"
            # so the classifier can still upgrade to a more specific type.
            mt = explicit_mt
        elif state.memory_type:
            mt = state.memory_type
        else:
            # Use deterministic priority rather than set iteration order.
            # classify_item() returns list(set(...)) which is hash-seed-dependent;
            # picking [0] is nondeterministic across processes.
            mt = next(
                (t for t in _TYPE_PRIORITY if t in types),
                next(iter(types), "semantic") if types else "semantic",
            )

        return replace(
            state,
            classified_types=types,
            memory_type=mt,
        )

    def undo(self, state: PipelineState) -> PipelineState:
        return replace(state, classified_types=[], memory_type=None)
