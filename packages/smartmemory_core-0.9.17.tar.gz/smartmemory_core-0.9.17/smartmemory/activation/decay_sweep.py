"""Activation decay-sweep — batched per-workspace decay recompute.

Callable as a pure function; the worker wraps it in an
``ActivationDecaySweepJob(BaseScheduledJob)`` that holds the Redis advisory
lock ``sm:activation:decay-lock:{workspace_id}``.

Reads each item's nested ``metadata["activation"]``, re-computes the current
score via ``compute_activation_score``, and writes it back as a normalized
full-dict shape. Idempotent — a second immediate run is effectively a no-op
(decay deltas below ``MIN_WRITE_DELTA`` are skipped).

**Pagination:** ``memory.search()`` does not expose an offset/cursor, so this
function iterates by re-querying with a growing ``top_k`` until the returned
set stops growing — a brute-force substitute until proper pagination lands
(tracked as an M2b follow-up). ``MAX_SWEEP_ITEMS`` caps total work per call
to keep sweep latency bounded; workspaces exceeding the cap are fully
covered across multiple hourly cycles.
"""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from smartmemory.activation.boost import normalize_activation_dict
from smartmemory.activation.constants import (
    DEFAULT_CAPACITY_CAP,
    DEFAULT_INHIBITION_FACTOR,
    DEFAULT_INHIBITION_PERCENTILE,
    LAST_BOOST_KEY,
    NAMESPACE,
    SCORE_KEY,
)
from smartmemory.activation.score import compute_activation_score

logger = logging.getLogger(__name__)

# Avoid write amplification — only persist when decay moves score by this much.
MIN_WRITE_DELTA: float = 0.001
DEFAULT_BATCH_SIZE: int = 500
# Upper bound on items processed per sweep call. Larger workspaces sweep
# progressively across successive hourly runs.
MAX_SWEEP_ITEMS: int = 10_000


def run_decay_sweep(
    memory: Any,
    batch_size: int = DEFAULT_BATCH_SIZE,
    now: Optional[datetime] = None,
    max_items: int = MAX_SWEEP_ITEMS,
    capacity_cap: Optional[int] = DEFAULT_CAPACITY_CAP,
    inhibition_factor: float = DEFAULT_INHIBITION_FACTOR,
    inhibition_percentile: float = DEFAULT_INHIBITION_PERCENTILE,
) -> Dict[str, int]:
    """Recompute activation score across a workspace's items.

    Args:
        memory: Scoped SmartMemory instance (workspace-scoped).
        batch_size: Items per ``memory.search()`` call. Defaults to 500.
        now: Reference time. Defaults to ``datetime.now(utc)``.
        max_items: Hard upper bound on items processed per sweep (keeps
            latency bounded on huge workspaces). Defaults to 10_000.
        capacity_cap: CORE-MEMORY-DYNAMICS-1 M2b Slice C — when the
            workspace's node count exceeds this threshold, apply
            competitive inhibition to the bottom-percentile activation
            scores. ``None`` (default) disables capacity enforcement
            entirely; the sweep behaves identically to M2a.
        inhibition_factor: Multiplier applied to the newly computed score
            for items below the percentile cutoff when over-cap. 0.7 by
            default (30% one-shot penalty).
        inhibition_percentile: Fraction of items penalised when over-cap.
            0.20 by default (bottom 20%).

    Returns:
        Stats dict with ``scanned``, ``updated``, ``skipped``, ``cap_hit``,
        ``over_cap``, and ``inhibited`` keys.
    """
    now = now or datetime.now(timezone.utc)
    scanned = 0
    updated = 0
    skipped = 0
    cap_hit = 0
    inhibited = 0
    over_cap = 0
    seen_ids: set[str] = set()

    # Single-pass fast path when capacity enforcement is disabled — matches
    # the M2a pre-M2b behaviour byte-for-byte (no buffering, no extra reads).
    # This is the default because ``DEFAULT_CAPACITY_CAP = None``.
    if capacity_cap is None:
        return _run_single_pass(
            memory=memory,
            batch_size=batch_size,
            now=now,
            max_items=max_items,
        )

    # Two-pass path: buffer (item_id, new_score, raw_activation) triples so
    # we can compute the bottom-percentile cutoff across the whole pass
    # before any writes. Writes happen after the percentile decision.
    buffered: list[tuple[str, float, dict]] = []

    # Pagination substitute: keep growing top_k until the result set
    # stops expanding (indicating exhaustion). Cap at max_items to bound
    # latency. Proper offset/cursor lands in M2b when memory.search exposes it.
    top_k = batch_size
    while top_k <= max_items:
        try:
            items = memory.search(query="*", top_k=top_k) or []
        except Exception as exc:
            logger.warning("run_decay_sweep: search failed at top_k=%d — %s", top_k, exc)
            break

        batch_len = len(items)
        if batch_len == 0:
            break

        new_ids: list[Any] = []
        for item in items:
            item_id = getattr(item, "item_id", None)
            if not item_id or item_id in seen_ids:
                continue
            new_ids.append(item)

        if not new_ids:
            # No new items returned at this cap — we've seen everything.
            break

        for item in new_ids:
            item_id = getattr(item, "item_id", None)
            seen_ids.add(item_id)
            scanned += 1

            md = getattr(item, "metadata", None)
            if not isinstance(md, dict):
                skipped += 1
                continue
            # CORE-USER-SEED-1: pinned items are exempt from decay-driven
            # inhibition. The User seed and other identity-anchor nodes set
            # is_pinned=True; this guard keeps their activation score
            # untouched even under capacity-cap pressure.
            if md.get("is_pinned") is True:
                skipped += 1
                continue
            activation = md.get(NAMESPACE)
            if not isinstance(activation, dict) or SCORE_KEY not in activation:
                # Un-migrated item — nothing to decay. Migration script owns seeding.
                skipped += 1
                continue

            try:
                stored = float(activation.get(SCORE_KEY, 0.0))
            except (TypeError, ValueError):
                stored = 0.0
            current = compute_activation_score(item, now=now)

            if abs(stored - current) < MIN_WRITE_DELTA:
                skipped += 1
                continue

            # Buffer instead of writing inline — we need the full set of
            # computed scores before we can decide which ones get the
            # bottom-percentile inhibition penalty.
            buffered.append((item_id, current, activation))

        # If the backend returned fewer items than we asked for, it's
        # exhausted — no need to increase top_k further.
        if batch_len < top_k:
            break

        # Otherwise grow and loop. Cap-hit path logged once below.
        next_top_k = top_k * 2
        if next_top_k > max_items:
            if batch_len == top_k:
                cap_hit = 1
            break
        top_k = next_top_k

    # Capacity-cap decision: probe whether THIS workspace exceeds its cap
    # using the workspace-scoped search path. The previous implementation
    # used backend.get_node_count() which on FalkorDB is an unscoped
    # ``MATCH (n) RETURN count(n)`` — a large workspace A would push
    # unrelated small workspace B over-cap, triggering inhibition on B's
    # items even though B's own corpus was tiny (Codex final r1). Using
    # memory.search here reuses the scope provider and bounds cost at
    # capacity_cap + 1 items, regardless of workspace size.
    over_cap_detected, node_count = _safe_scoped_over_cap(memory, capacity_cap)
    if capacity_cap is not None and over_cap_detected:
        over_cap = 1
        inhibit_count = _rank_based_inhibit_count(
            total=len(buffered),
            percentile=inhibition_percentile,
        )
        if inhibit_count > 0:
            # Rank by score ascending, then by id for stable ordering under
            # ties (so the inhibition set is deterministic across runs).
            ranked = sorted(
                range(len(buffered)),
                key=lambda i: (buffered[i][1], buffered[i][0]),
            )
            inhibit_indices = set(ranked[:inhibit_count])
            penalised: list[tuple[str, float, dict]] = []
            for idx, (iid, score, activation) in enumerate(buffered):
                if idx in inhibit_indices:
                    new_score = max(0.0, score * float(inhibition_factor))
                    penalised.append((iid, new_score, activation))
                    inhibited += 1
                else:
                    penalised.append((iid, score, activation))
            buffered = penalised

    # Write phase — honour MIN_WRITE_DELTA against the originally stored
    # score so inhibition doesn't force a no-op write.
    for item_id, new_score, activation in buffered:
        try:
            stored = float(activation.get(SCORE_KEY, 0.0))
        except (TypeError, ValueError):
            stored = 0.0
        if abs(stored - new_score) < MIN_WRITE_DELTA:
            skipped += 1
            continue
        normalized = normalize_activation_dict(activation)
        normalized[SCORE_KEY] = new_score
        normalized[LAST_BOOST_KEY] = now.isoformat()
        try:
            memory.update_properties(item_id, {NAMESPACE: normalized})
            updated += 1
        except Exception as exc:
            logger.warning(
                "run_decay_sweep: update failed for %s — %s", item_id, exc
            )
            skipped += 1

    if cap_hit:
        logger.info(
            "run_decay_sweep: workspace exceeded max_items=%d; remaining "
            "items will be refreshed on subsequent sweep cycles.",
            max_items,
        )
    if over_cap:
        logger.info(
            "run_decay_sweep: over-cap (node_count=%s > cap=%d); "
            "inhibited %d item(s) at factor=%.2f percentile=%.2f",
            node_count, capacity_cap, inhibited, inhibition_factor,
            inhibition_percentile,
        )

    logger.info(
        "run_decay_sweep: scanned=%d updated=%d skipped=%d cap_hit=%d "
        "over_cap=%d inhibited=%d",
        scanned, updated, skipped, cap_hit, over_cap, inhibited,
    )
    return {
        "scanned": scanned,
        "updated": updated,
        "skipped": skipped,
        "cap_hit": cap_hit,
        "over_cap": over_cap,
        "inhibited": inhibited,
    }


# ---------------------------------------------------------------------------
# Helpers — single-pass fast path + capacity-cap utilities
# ---------------------------------------------------------------------------


def _run_single_pass(
    memory: Any,
    batch_size: int,
    now: datetime,
    max_items: int,
) -> Dict[str, int]:
    """Pre-M2b single-pass decay (no buffering, no capacity cap).

    Preserves byte-for-byte behavior when ``capacity_cap is None`` so M2b
    Slice C introduces zero risk to workspaces that don't opt into capacity
    enforcement.
    """
    scanned = 0
    updated = 0
    skipped = 0
    cap_hit = 0
    seen_ids: set[str] = set()

    top_k = batch_size
    while top_k <= max_items:
        try:
            items = memory.search(query="*", top_k=top_k) or []
        except Exception as exc:
            logger.warning("run_decay_sweep: search failed at top_k=%d — %s", top_k, exc)
            break

        batch_len = len(items)
        if batch_len == 0:
            break

        new_ids: list[Any] = []
        for item in items:
            item_id = getattr(item, "item_id", None)
            if not item_id or item_id in seen_ids:
                continue
            new_ids.append(item)

        if not new_ids:
            break

        for item in new_ids:
            item_id = getattr(item, "item_id", None)
            seen_ids.add(item_id)
            scanned += 1

            md = getattr(item, "metadata", None)
            if not isinstance(md, dict):
                skipped += 1
                continue
            # CORE-USER-SEED-1: pinned items skip decay (mirrors guard above).
            if md.get("is_pinned") is True:
                skipped += 1
                continue
            activation = md.get(NAMESPACE)
            if not isinstance(activation, dict) or SCORE_KEY not in activation:
                skipped += 1
                continue

            try:
                stored = float(activation.get(SCORE_KEY, 0.0))
            except (TypeError, ValueError):
                stored = 0.0
            current = compute_activation_score(item, now=now)

            if abs(stored - current) < MIN_WRITE_DELTA:
                skipped += 1
                continue

            normalized = normalize_activation_dict(activation)
            normalized[SCORE_KEY] = current
            normalized[LAST_BOOST_KEY] = now.isoformat()

            try:
                memory.update_properties(item_id, {NAMESPACE: normalized})
                updated += 1
            except Exception as exc:
                logger.warning(
                    "run_decay_sweep: update failed for %s — %s", item_id, exc
                )
                skipped += 1

        if batch_len < top_k:
            break
        next_top_k = top_k * 2
        if next_top_k > max_items:
            if batch_len == top_k:
                cap_hit = 1
            break
        top_k = next_top_k

    if cap_hit:
        logger.info(
            "run_decay_sweep: workspace exceeded max_items=%d; remaining "
            "items will be refreshed on subsequent sweep cycles.",
            max_items,
        )
    logger.info(
        "run_decay_sweep (single-pass): scanned=%d updated=%d skipped=%d cap_hit=%d",
        scanned, updated, skipped, cap_hit,
    )
    return {
        "scanned": scanned,
        "updated": updated,
        "skipped": skipped,
        "cap_hit": cap_hit,
        "over_cap": 0,
        "inhibited": 0,
    }


def _safe_scoped_over_cap(
    memory: Any, capacity_cap: Optional[int]
) -> tuple[bool, Optional[int]]:
    """Workspace-scoped over-cap probe.

    Uses ``memory.search(query='*', top_k=capacity_cap + 1)`` because search
    is scoped via the ScopeProvider, whereas backend.get_node_count() is
    unscoped on FalkorDB (``MATCH (n) RETURN count(n)``). Cost is bounded
    at capacity_cap + 1 items regardless of workspace size — we only need
    to answer the yes/no "strictly more than cap?" question.

    Returns:
        ``(over_cap, count)`` where:
        - ``over_cap`` is True when scoped search returned > capacity_cap items
        - ``count`` is the observed item count (<= capacity_cap + 1) or None
          when cap enforcement is disabled / probe failed
    """
    if capacity_cap is None:
        return False, None
    searcher = getattr(memory, "search", None)
    if not callable(searcher):
        return False, None
    try:
        probe = searcher(query="*", top_k=capacity_cap + 1) or []
    except Exception as exc:
        logger.debug("run_decay_sweep: scoped over-cap probe failed — %s", exc)
        return False, None
    observed = len(probe)
    return observed > capacity_cap, observed


def _rank_based_inhibit_count(total: int, percentile: float) -> int:
    """Return how many items should receive inhibition — exact rank count.

    Uses round() on ``total * percentile`` so a 20% ask against 10 items
    picks exactly 2, not "<= the cutoff score" (which would over-penalize
    ties at the boundary — Codex Slice C r1). When the product rounds to
    zero but ``percentile > 0`` and there's at least one item, returns 1 —
    preserves the "at least one item when over cap" contract from the
    original helper (Codex Slice C r2). Clamped to ``[0, total]``.
    """
    if total <= 0:
        return 0
    try:
        pct = max(0.0, min(1.0, float(percentile)))
    except (TypeError, ValueError):
        pct = 0.20
    if pct == 0.0:
        return 0
    count = int(round(total * pct))
    if count == 0:
        # Sparse-pass guarantee: over-cap workspace with 1-2 changed items
        # still penalises the weakest-ranked change. Otherwise steady-state
        # sweeps with few dirty items would silently drop inhibition.
        count = 1
    return max(0, min(total, count))
