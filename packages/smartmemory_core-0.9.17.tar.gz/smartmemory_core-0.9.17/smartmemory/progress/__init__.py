"""Unified progress event bus for SmartMemory.

Public API
----------
bind(run_id, scope)
    Set the context for the current task/thread.  Must be called before emit().
    Resets the per-run_id seq counter.

emit(*, kind, status, stage=None, payload=None)
    Write a ProgressEvent to the workspace Redis Stream.
    Raises ProgressContextError if bind() has not been called in this context.

Stream layout (from progress-event-contract.json StreamLayout)
--------------------------------------------------------------
  Key  : sm:progress:<workspace_id>
  MAXLEN: ~10_000 (approximate, amortised trimming via XADD MAXLEN ~)
  DB   : Redis DB 1 (same logical DB as observability events.py)

Kind format validation
----------------------
  Kinds must match \w+(\.\w+)+ — i.e. at least two dot-separated segments of
  word characters.  Examples: "pipeline.stage", "evolver.result", "sweep.iter".
"""

from __future__ import annotations

import logging
import os
import re
import threading
import time
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Iterator, Optional

from smartmemory.progress.event import ProgressEvent

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Redis DB for progress streams — same as observability/events.py DB 1
# ---------------------------------------------------------------------------
_PROGRESS_REDIS_DB = 1

# Approximate max length per stream (amortised trimming).
# Override via SMARTMEMORY_PROGRESS_MAXLEN for workspaces running chatty
# workloads (batch ingest of 1000+ items × 11 stages × ~5 events each can
# exceed the default before a reconnect replay window closes). 10k is safe
# for single-doc ingests. Ops should bump to ~50k-100k for batch-heavy
# deployments and monitor Redis memory.
_STREAM_MAXLEN = int(os.environ.get("SMARTMEMORY_PROGRESS_MAXLEN", "10000"))

# Kind format: at least two dot-separated word-character segments
_KIND_RE = re.compile(r"^\w+(\.\w+)+$")


# ---------------------------------------------------------------------------
# Custom exception
# ---------------------------------------------------------------------------

class ProgressContextError(RuntimeError):
    """Raised when emit() is called without a prior bind() in the current context."""


# ---------------------------------------------------------------------------
# ContextVars — one set per asyncio Task / thread
# ---------------------------------------------------------------------------

_run_id: ContextVar[Optional[str]] = ContextVar("progress_run_id", default=None)
_scope: ContextVar[Optional[str]] = ContextVar("progress_scope", default=None)


# ---------------------------------------------------------------------------
# Per-run monotonic seq counter (global dict, guarded by a lock)
# ---------------------------------------------------------------------------

_seq_lock = threading.Lock()
_seq_counters: dict[str, int] = {}


def _next_seq(run_id: str) -> int:
    """Return the next seq value for run_id and increment the counter."""
    with _seq_lock:
        seq = _seq_counters.get(run_id, 0)
        _seq_counters[run_id] = seq + 1
        return seq


def _reset_seq(run_id: str) -> None:
    """Reset the seq counter for run_id (called from bind())."""
    with _seq_lock:
        _seq_counters[run_id] = 0


# ---------------------------------------------------------------------------
# Redis client (module-level singleton, lazy-initialised)
# ---------------------------------------------------------------------------

_redis_client = None
_redis_client_lock = threading.Lock()


def _get_redis():
    """Return a cached Redis client using the same bootstrap as events.py."""
    global _redis_client
    if _redis_client is not None:
        return _redis_client
    with _redis_client_lock:
        if _redis_client is not None:
            return _redis_client
        try:
            import redis as _redis
            from smartmemory.utils import get_config

            config = get_config()
            rc = config.cache.redis
            _redis_client = _redis.Redis(
                host=rc.host,
                port=int(rc.port),
                db=_PROGRESS_REDIS_DB,
                decode_responses=True,
            )
        except Exception as exc:
            logger.warning("progress: Redis client unavailable: %s", exc)
            _redis_client = None
    return _redis_client


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def bind(run_id: str, scope: str) -> None:
    """Bind run_id and scope to the current asyncio task / thread context.

    Resets the seq counter for this run_id so each new run starts from 0.
    Must be called before the first emit() for a given run.

    Args:
        run_id: UUID string identifying the parent operation.
        scope:  Must match "workspace:<id>" pattern.
    """
    _run_id.set(run_id)
    _scope.set(scope)
    _reset_seq(run_id)


def unbind() -> None:
    """Clear run_id and scope from the current context (call in finally block)."""
    _run_id.set(None)
    _scope.set(None)


@contextmanager
def bound_progress(*, run_id: str, scope: str) -> Iterator[None]:
    """Context-managed form of bind()/unbind().

    Use in background helpers and long-running tasks where contextvars must
    reset on exit even if the caller raises. Equivalent to::

        bind(run_id=run_id, scope=scope)
        try:
            yield
        finally:
            unbind()

    Background tasks scheduled via FastAPI ``BackgroundTasks.add_task``,
    ``asyncio.create_task``, or ``threading.Thread`` run in a fresh context
    and must call ``bound_progress`` (or ``bind``+``unbind``) inside the task
    body — bindings in the scheduling request handler do not propagate.
    """
    bind(run_id=run_id, scope=scope)
    try:
        yield
    finally:
        unbind()


def emit(
    *,
    kind: str,
    status: str,
    stage: Optional[str] = None,
    payload: Optional[dict] = None,
    _ts: Optional[float] = None,
) -> None:
    """Write a ProgressEvent to the workspace Redis Stream.

    Args:
        kind:    Dotted kind tag, e.g. "pipeline.stage". Must match \\w+(\\.\\w+)+.
        status:  One of: started | progress | ok | warn | error.
        stage:   Pipeline stage name (optional).
        payload: Kind-specific data dict (optional; defaults to empty dict).
        _ts:     Override the event timestamp (epoch seconds). Internal use only —
                 allows callers that know the exact emission epoch (e.g. span close
                 time) to pin ts so that payload.original_ts == ts holds exactly
                 per PayloadConventions in the contract.

    Raises:
        ProgressContextError: If bind() has not been called in this context.
        ValueError:           If kind does not match the required format.
        ValueError:           If status is not a recognised value.
    """
    run_id = _run_id.get()
    scope = _scope.get()

    if run_id is None or scope is None:
        raise ProgressContextError(
            "progress.emit() called without a prior progress.bind(). "
            "Call progress.bind(run_id=..., scope=...) before emitting events. "
            f"run_id={run_id!r}, scope={scope!r}"
        )

    if not _KIND_RE.match(kind):
        raise ValueError(
            f"Invalid kind {kind!r}. "
            "Kind must match \\w+(\\.\\w+)+ — e.g. 'pipeline.stage', 'evolver.result'."
        )

    # Extract workspace_id from scope — format is "workspace:<id>"
    if not scope.startswith("workspace:"):
        raise ValueError(
            f"scope must start with 'workspace:' per the contract, got {scope!r}"
        )
    workspace_id = scope[len("workspace:"):]
    stream_name = f"sm:progress:{workspace_id}"

    ts = _ts if _ts is not None else time.time()
    seq = _next_seq(run_id)
    # INSIGHTS-PROGRESS-MIGRATE-1 Phase 0: when the caller is inside an active
    # trace_span whose dotted prefix matches the emit's kind, inherit span
    # identity (span_id/parent_span_id/name/trace_id) into payload so consumers
    # can correlate drip/progress events with the enclosing span. Caller-provided
    # payload keys win to allow explicit overrides.
    #
    # The kind-prefix guard prevents stale-context leakage across asyncio.create_task
    # boundaries: ContextVars copy into child tasks, so a child that emits
    # `pipeline.stage` while a non-pipeline outer span is "active" must not be
    # stamped with that span's identity. We require the active span's name to share
    # the kind's first dotted segment (e.g. `pipeline.*` event inherits only from a
    # `pipeline.*` span). This is necessary but not sufficient for full safety;
    # callers in async fan-out paths should bind a fresh span before emitting.
    effective_payload = dict(payload) if payload is not None else {}
    try:
        from smartmemory.observability.tracing import _current_span as _cs
        active = _cs.get()
        if active is not None and active.span_id and active.name:
            kind_prefix = kind.split(".", 1)[0]
            name_prefix = active.name.split(".", 1)[0]
            if kind_prefix == name_prefix:
                effective_payload.setdefault("span_id", active.span_id)
                effective_payload.setdefault("parent_span_id", active.parent_span_id)
                effective_payload.setdefault("name", active.name)
                effective_payload.setdefault("trace_id", active.trace_id)
    except Exception:
        pass
    event = ProgressEvent(
        run_id=run_id,
        scope=scope,
        seq=seq,
        ts=ts,
        kind=kind,
        stage=stage,
        status=status,
        payload=effective_payload,
    )

    redis = _get_redis()
    if redis is None:
        logger.warning(
            "progress: Redis unavailable — event not emitted (run_id=%s seq=%d kind=%s status=%s)",
            run_id,
            seq,
            kind,
            status,
        )
        return

    try:
        # Flatten ProgressEvent to a string dict for Redis Streams
        wire = event.to_dict()
        stream_fields = {
            "run_id": wire["run_id"],
            "scope": wire["scope"],
            "seq": str(wire["seq"]),
            "ts": str(wire["ts"]),
            "kind": wire["kind"],
            "status": wire["status"],
            "payload": __import__("json").dumps(wire["payload"]),
        }
        if "stage" in wire:
            stream_fields["stage"] = wire["stage"]

        redis.xadd(stream_name, stream_fields, maxlen=_STREAM_MAXLEN, approximate=True)
    except Exception as exc:
        logger.warning(
            "progress: Failed to write to stream %s: %s (run_id=%s seq=%d)",
            stream_name,
            exc,
            run_id,
            seq,
        )


__all__ = ["ProgressEvent", "ProgressContextError", "bind", "unbind", "bound_progress", "emit"]
