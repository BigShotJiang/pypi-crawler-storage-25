"""BootstrapScan — retroactive EntityRuler pattern backfill (SELF-IMPROVE-9B).

Workspaces created before the EntityRuler self-learning loop (CORE-EXT-1,
hardened by SELF-IMPROVE-9) existed have zero learned patterns: the live
loop only learns from *new* extractions. This one-time, per-workspace
backfill scans a workspace's already-stored entities, derives
``(name, label)`` patterns from the ones mentioned by >= ``min_freq``
distinct workspace memories, and inserts them through the *hardened*
write path so they inherit source-tiered caps, precedence and decay.

Source is ``bootstrap_scan`` — a distinct ruler-tier provenance (cap
0.85, same epistemic class as ``entity_ruler_learned``) so the decay
sweep / observability / audits can isolate backfilled patterns and the
backfill can never outrank user/seed data.

Idempotency is by construction: an unfiltered ``(name, label)`` existence
prefilter drops pairs that already exist, so the scan's writes only ever
hit ``ON CREATE`` — re-runs are idempotent *and* incremental. A live-loop
write racing between prefilter and insert can still produce one benign
monotonic reinforcement; that is tolerated, not prevented.

Driven on a cron via ``smartmemory-core bootstrap-scan`` (pull model,
mirroring ``PatternDecaySweep`` / the metrics+ruler-drain consumers); no
daemon thread in core.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from smartmemory.graph.ontology_graph import OntologyGraph
from smartmemory.summary.queries import _MEMORY_NODE_WHERE

logger = logging.getLogger(__name__)

BOOTSTRAP_SOURCE = "bootstrap_scan"


@dataclass
class ScanResult:
    """All client-side scan tallies (no hidden state; ``run()`` reads
    these straight off and adds only the write-side counts)."""

    rows: list[tuple[str, str, int]] = field(default_factory=list)
    scanned: int = 0
    below_threshold: int = 0
    skipped_no_type: int = 0


class BootstrapScan:
    """Retroactive per-workspace EntityRuler pattern backfill."""

    def __init__(
        self,
        workspace_id: str = "default",
        *,
        min_freq: int = 2,
        dry_run: bool = False,
        main_graph_backend=None,
        ontology_graph: OntologyGraph | None = None,
        pattern_manager=None,
    ):
        self.workspace_id = workspace_id
        self.min_freq = min_freq
        self.dry_run = dry_run
        # The scan/enumerator handle on the shared main 'smartmemory' graph
        # (FalkorDBBackend with no graph_name → resolve_main_graph_name).
        if main_graph_backend is None:
            from smartmemory.graph.backends.falkordb import FalkorDBBackend

            main_graph_backend = FalkorDBBackend()
        self._main_graph_backend = main_graph_backend
        # The write target — a *different* graph (ws_<id>_ontology).
        self._ontology_graph = ontology_graph or OntologyGraph(workspace_id=workspace_id)
        self._pattern_manager = pattern_manager

    # -- scan -------------------------------------------------------------

    def _scan(self) -> ScanResult:
        """Read the workspace's stored entities from the main graph and
        partition client-side. No server-side freq/label filter — every
        summary count must be truthfully derivable here.
        """
        cypher = (
            "MATCH (e)-[:MENTIONED_IN|CONTAINS_ENTITY]-(m) "
            "WHERE (e.node_category = 'entity' OR e.memory_type = 'entity') "
            "  AND coalesce(e.node_category, 'entity') <> 'alias' "
            f"  AND {_MEMORY_NODE_WHERE} "
            "  AND m.workspace_id = $ws "
            "WITH coalesce(e.name, e.content, e.item_id) AS nm, "
            "     e.entity_type AS lbl, "
            "     count(DISTINCT m) AS freq "
            "RETURN nm, lbl, freq"
        )
        records = self._main_graph_backend.query(cypher, {"ws": self.workspace_id}) or []

        result = ScanResult()
        result.scanned = len(records)
        for nm, lbl, freq in records:
            if freq < self.min_freq:
                result.below_threshold += 1
                continue
            if not lbl or not str(lbl).strip():
                result.skipped_no_type += 1
                continue
            result.rows.append((nm, lbl, int(freq)))
        if result.skipped_no_type:
            logger.warning(
                "BootstrapScan[%s]: skipped %d entit%s with empty entity_type "
                "(no graph-label fallback — SELF-IMPROVE-9B C1)",
                self.workspace_id,
                result.skipped_no_type,
                "y" if result.skipped_no_type == 1 else "ies",
            )
        return result

    # -- existence prefilter ---------------------------------------------

    def _existing(self) -> set[tuple[str, str]]:
        """All ``(name, label)`` patterns already in this workspace's
        ontology graph. UNFILTERED — deliberately NOT
        ``OntologyGraph.get_entity_patterns`` (it gates ``count >= 2``,
        so below-threshold rows would be invisible and a re-run would
        wrongly hit ON MATCH and lose the ``initial_count`` signal).
        """
        rows = (
            self._ontology_graph._get_backend().query(
                "MATCH (p:EntityPattern) WHERE p.workspace_id = $ws OR p.is_global RETURN p.name, p.label",
                {"ws": self.workspace_id},
            )
            or []
        )
        return {(str(n).lower(), lbl) for n, lbl in rows}

    def _get_pattern_manager(self):
        if self._pattern_manager is None:
            from smartmemory.ontology.falkordb_pattern_store import FalkorDBPatternStore
            from smartmemory.ontology.pattern_manager import PatternManager

            store = FalkorDBPatternStore(self._ontology_graph)
            self._pattern_manager = PatternManager(store, workspace_id=self.workspace_id)
        return self._pattern_manager

    # -- enumeration ------------------------------------------------------

    @staticmethod
    def enumerate_workspaces(main_graph_backend) -> list[str]:
        """All workspace_ids that have stored *memory* content in the
        shared main graph. Deliberately UNSCOPED and label-free, gated by
        the shipped readers' memory-side exclusion predicate (entities
        also carry workspace_id, so a bare filter over-enumerates). NOT
        smartmemory:active_workspaces (observability-only, excludes the
        dormant pre-loop workspaces this backfill targets) and NOT
        GRAPH.LIST (workspaces share one graph).
        """
        rows = (
            main_graph_backend.query(
                f"MATCH (m) WHERE {_MEMORY_NODE_WHERE} AND m.workspace_id IS NOT NULL RETURN DISTINCT m.workspace_id"
            )
            or []
        )
        return [r[0] for r in rows if r and r[0]]

    # -- run --------------------------------------------------------------

    def run(self) -> dict[str, int]:
        """Scan → existence-prefilter → frequency-bucketed insert.

        ``inserted`` is strictly the summed ``add_patterns`` return
        (net-new). ``not_inserted = eligible - inserted`` is an
        explicitly NON-ATTRIBUTED remainder (blocklist/short-name OR
        cross-label precedence loss/win — ``add_patterns`` gives no
        per-row reason). No counter is claimed to partition ``scanned``.
        """
        scan = self._scan()
        existing = self._existing()
        # Names already represented under ANY label, at ANY count. The
        # set is unfiltered, so this also covers below-threshold
        # (count=1) incumbents that PatternManager's count>=2-gated
        # conflict map cannot see — without this, a cross-label backfill
        # would create a latent dual row (Codex impl-review iter-3). 9B
        # defers to the existing pattern entirely: a ruler-tier backfill
        # must never create a competing row for a name the graph already
        # knows. The deeper PatternManager gate is a separate follow-up.
        existing_names: set[str] = {n for (n, _lbl) in existing}

        survivors: list[tuple[str, str, int]] = []
        cross_label_deferred = 0
        for nm, lbl, freq in scan.rows:
            key = nm.lower()
            if (key, lbl) in existing:
                continue  # exact dupe — idempotent skip
            if key in existing_names:
                cross_label_deferred += 1  # different label, same name
                continue
            survivors.append((nm, lbl, freq))
        skipped_existing = len(scan.rows) - len(survivors)
        eligible = len(survivors)

        if cross_label_deferred:
            logger.warning(
                "BootstrapScan[%s]: deferred %d cross-label candidate(s) — "
                "name already has a pattern under a different label; backfill "
                "must not create a competing dual row (SELF-IMPROVE-9B)",
                self.workspace_id,
                cross_label_deferred,
            )

        # Strongest-evidence-first. add_patterns keeps the incumbent on
        # equal source/confidence ties (all bootstrap rows share both), so
        # without this the intra-scan conflict winner would be decided by
        # raw FalkorDB row order, not frequency (Codex impl-review). Sort
        # freq DESC so the higher-evidence label is written first and wins.
        survivors.sort(key=lambda r: r[2], reverse=True)

        inserted = 0
        if not self.dry_run and survivors:
            pm = self._get_pattern_manager()
            # One add_patterns call per (name, label). A name-keyed batch
            # dict would silently collapse same-name/different-label
            # candidates (e.g. jaguar→Animal vs jaguar→Car) before the
            # shared precedence logic ever sees them — a no-silent-
            # degradation violation (Codex impl-review). Per-pattern calls
            # preserve initial_count=freq AND let precedence/conflict
            # handling arbitrate every candidate. Backfill is a one-time
            # cron job, so the extra calls are an acceptable cost.
            for nm, lbl, freq in survivors:
                inserted += pm.add_patterns({nm: lbl}, source=BOOTSTRAP_SOURCE, initial_count=freq)

        return {
            "scanned": scan.scanned,
            "below_threshold": scan.below_threshold,
            "skipped_no_type": scan.skipped_no_type,
            "skipped_existing": skipped_existing,
            "eligible": eligible,
            "inserted": inserted,
            "not_inserted": eligible - inserted,
            "failed_workspaces": 0,
        }
