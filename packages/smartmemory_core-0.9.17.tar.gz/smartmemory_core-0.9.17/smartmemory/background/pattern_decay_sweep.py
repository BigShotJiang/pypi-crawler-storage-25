"""PatternDecaySweep — age out unused learned entity patterns.

SELF-IMPROVE-9 S04b (9.3). A ruler-learned pattern that stops matching is
probably stale (renamed entity, one-off extraction noise). This sweep
lowers the confidence of ruler-sourced :EntityPattern nodes whose last
ruler match (``last_matched_at``, stamped by S04a) is older than a TTL,
and prunes nodes that fall below a floor.

Source-tiered exemption (reuses the S01 source taxonomy): ``seed`` /
``seed-pack`` / ``user`` / ``manual_ner`` patterns are NEVER decayed —
curated/reference data does not rot from disuse. Only ruler-tier sources
(and unknown sources, which default to ruler) decay.

Driven on a cron via ``smartmemory-core pattern-decay`` with its own
interval (Spike 2: a distinct cadence from the snapshot/retention
sweepers — it must not contend with them). Pull model, mirroring the
metrics/ruler-drain consumers; no daemon thread in core.
"""

from __future__ import annotations

import logging
import os
import time

from smartmemory.graph.ontology_graph import _SEED_SOURCES, _USER_SOURCES, OntologyGraph

logger = logging.getLogger(__name__)

DEFAULT_TTL_DAYS = 90
PATTERN_DECAY_FLOOR = 0.3  # below this a decayed pattern is pruned
PATTERN_DECAY_FACTOR = 0.8  # confidence multiplier per overdue sweep

# Curated sources are decay-exempt (S01/S02 taxonomy).
_EXEMPT_SOURCES = sorted(_USER_SOURCES | _SEED_SOURCES)


class PatternDecaySweep:
    """Decay + prune stale ruler-learned entity patterns for one workspace."""

    def __init__(
        self,
        workspace_id: str = "default",
        ttl_days: int | None = None,
        floor: float = PATTERN_DECAY_FLOOR,
        factor: float = PATTERN_DECAY_FACTOR,
        ontology_graph: OntologyGraph | None = None,
    ):
        self.workspace_id = workspace_id
        if ttl_days is None:
            ttl_days = int(os.getenv("SMARTMEMORY_PATTERN_DECAY_TTL_DAYS", str(DEFAULT_TTL_DAYS)))
        self.ttl_days = ttl_days
        self.floor = floor
        self.factor = factor
        self._og = ontology_graph or OntologyGraph(workspace_id=workspace_id)

    def run(self) -> dict[str, int]:
        """Decay overdue ruler patterns, prune those below the floor.

        Returns {"decayed": n, "pruned": m}. Errors are logged and surfaced
        as zero counts — never silently swallowed.
        """
        backend = self._og._get_backend()
        gname = self._og._graph_name
        # FalkorDB timestamp() is epoch-ms; last_matched_at/discovered_at use it.
        now_ms = int(time.time() * 1000)
        cutoff_ms = now_ms - self.ttl_days * 86400 * 1000

        # "Overdue" = no/old ruler match. Fall back to discovered_at for
        # patterns matched before S04a stamping existed.
        overdue = (
            "MATCH (p:EntityPattern) "
            "WHERE (p.source IS NULL OR NOT p.source IN $exempt) "
            "AND COALESCE(p.last_matched_at, p.discovered_at, 0) < $cutoff "
        )
        try:
            decayed = backend.query(
                overdue + "SET p.confidence = COALESCE(p.confidence, 0) * $factor RETURN count(p)",
                params={"exempt": _EXEMPT_SOURCES, "cutoff": cutoff_ms, "factor": self.factor},
                graph_name=gname,
            )
            decayed_n = int(decayed[0][0]) if decayed else 0
        except Exception as exc:
            logger.warning("PatternDecaySweep: decay query failed: %s", exc)
            return {"decayed": 0, "pruned": 0}

        try:
            # Prune what decayed below the floor (same exemption — a curated
            # pattern can never reach here anyway, but keep the guard explicit).
            # Codex R1/#3: prune must be staleness-gated too. Without the
            # overdue clause a freshly-created low-confidence ruler pattern
            # (matched recently) would be deleted before it is ever stale.
            prune_where = (
                "MATCH (p:EntityPattern) "
                "WHERE (p.source IS NULL OR NOT p.source IN $exempt) "
                "AND COALESCE(p.last_matched_at, p.discovered_at, 0) < $cutoff "
                "AND COALESCE(p.confidence, 0) < $floor "
            )
            prune_params = {
                "exempt": _EXEMPT_SOURCES,
                "floor": self.floor,
                "cutoff": cutoff_ms,
            }
            cnt = backend.query(prune_where + "RETURN count(p)", params=prune_params, graph_name=gname)
            pruned_n = int(cnt[0][0]) if cnt else 0
            if pruned_n:
                backend.query(prune_where + "DETACH DELETE p", params=prune_params, graph_name=gname)
        except Exception as exc:
            logger.warning("PatternDecaySweep: prune query failed: %s", exc)
            pruned_n = 0

        if decayed_n or pruned_n:
            logger.info(
                "PatternDecaySweep[%s]: decayed=%d pruned=%d (ttl=%dd floor=%.2f)",
                self.workspace_id,
                decayed_n,
                pruned_n,
                self.ttl_days,
                self.floor,
            )
        return {"decayed": decayed_n, "pruned": pruned_n}
