"""EntityRulerConsumer — async application of learned-pattern writes.

SELF-IMPROVE-9 S03 (9.6). The extraction worker used to call
``OntologyGraph._upsert_inline_ontology_pattern()`` inline on the ingest
path, blocking ingestion on graph I/O and coupling pattern durability to
the request. This consumer decouples that: the worker *enqueues* a
``pattern.upsert`` (or ``pattern.used``, S04) event onto a Redis Stream;
this consumer drains the stream, applies the capped/monotonic upsert
(SELF-IMPROVE-9 S01), and *then* publishes the ruler hot-reload so
PatternManager caches refresh (Spike 3 order: persist → publish).

Pull-consumer model, mirroring ``MetricsConsumer``: cursor-tracked
``xrange`` batches, db=1 cursor connection, idempotent resume. Driven by
the CLI and the background sweep scheduler — not a daemon thread in core.

Failure isolation (no-silent-degradation):
- Worker enqueue failure → WARNING, ingestion proceeds (handled worker-side).
- Per-message apply failure → WARNING, cursor still advances so one poison
  message cannot wedge the stream; the loss is logged, never silent.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import redis

from smartmemory.ontology.pattern_manager import PatternManager
from smartmemory.utils import get_config

PATTERN_STREAM = "smartmemory:patterns:update"
_CURSOR_PREFIX = "smartmemory:patterns:cursor"

logger = logging.getLogger(__name__)


class EntityRulerConsumer:
    """Consume pattern-update events and apply them to the ontology graph."""

    def __init__(
        self,
        redis_client: "redis.Redis | None" = None,
        stream_name: str = PATTERN_STREAM,
    ):
        self._redis_available = False
        self.stream_name = stream_name
        self._last_id = "0-0"
        self._graphs: dict[str, Any] = {}  # workspace_id → OntologyGraph (per-ws cache)

        if redis_client is not None:
            self.redis = redis_client
            self._redis_available = True
        else:
            try:
                import redis as _redis

                config = get_config()
                rc = config.cache.redis
                self.redis = _redis.Redis(host=rc.host, port=int(rc.port), db=1, decode_responses=True)
                self._redis_available = True
            except (ImportError, Exception) as exc:
                logger.debug("Redis unavailable for entity-ruler consumer: %s", exc)
                self.redis = None

        if self._redis_available:
            self._restore_cursor()

    # -- cursor persistence --------------------------------------------------

    def _cursor_key(self) -> str:
        return f"{_CURSOR_PREFIX}:{self.stream_name}"

    def _restore_cursor(self) -> None:
        try:
            saved = self.redis.get(self._cursor_key())
            if saved:
                self._last_id = saved
        except Exception:
            pass

    def _save_cursor(self) -> None:
        try:
            self.redis.set(self._cursor_key(), self._last_id)
        except Exception:
            pass

    # -- enqueue (called by the worker) --------------------------------------

    @staticmethod
    def enqueue(redis_client: Any, event: dict[str, Any], stream_name: str = PATTERN_STREAM) -> None:
        """Append a pattern event to the stream. Raises on failure so the
        caller can WARN — never swallow here (no-silent-degradation)."""
        redis_client.xadd(stream_name, {"data": json.dumps(event)})

    # -- graph resolution ----------------------------------------------------

    def _graph_for(self, workspace_id: str):
        g = self._graphs.get(workspace_id)
        if g is None:
            from smartmemory.graph.ontology_graph import OntologyGraph

            g = OntologyGraph(workspace_id=workspace_id)
            self._graphs[workspace_id] = g
        return g

    # -- run loop ------------------------------------------------------------

    def _lock_key(self) -> str:
        return f"{_CURSOR_PREFIX}:lock:{self.stream_name}"

    _LOCK_TTL = 300
    # Atomic compare-and-delete: only release the lock if WE still hold it.
    # Mirrors the CORE-SUMMARY-1 Redis Lua-CAD lock pattern.
    _UNLOCK_LUA = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end"

    def run(self, max_iterations: int | None = None) -> int:
        """Drain pending pattern events. Returns count processed.

        Codex R1/#2: the upsert/used handlers are NON-idempotent (count++,
        match_hits++). Two overlapping drains would both restore the same
        cursor and double-apply. A Redis SET NX EX lock makes concurrent
        invocations (cron overlap, multi-replica) safe — a second caller
        returns 0 rather than corrupting counters.
        """
        if not self._redis_available:
            return 0

        import uuid as _uuid

        lock_key = self._lock_key()
        lock_token = _uuid.uuid4().hex
        try:
            got = self.redis.set(lock_key, lock_token, nx=True, ex=self._LOCK_TTL)
        except Exception:
            got = None
        if not got:
            logger.debug("EntityRulerConsumer: another drain holds %s; skipping", lock_key)
            return 0

        try:
            return self._drain(
                max_iterations, batch_size=100, reload_workspaces=set(), lock_key=lock_key, lock_token=lock_token
            )
        finally:
            # Atomic compare-and-delete — never delete a lock we no longer
            # own (Codex R2/#1: GET-then-DEL had a TTL-expiry race).
            try:
                self.redis.eval(self._UNLOCK_LUA, 1, lock_key, lock_token)
            except Exception:
                pass

    def _drain(
        self,
        max_iterations: int | None,
        batch_size: int,
        reload_workspaces: set[str],
        lock_key: str | None = None,
        lock_token: str | None = None,
    ) -> int:
        processed = 0
        while True:
            if max_iterations is not None and processed >= max_iterations:
                break
            try:
                messages = self.redis.xrange(self.stream_name, min=f"({self._last_id}", max="+", count=batch_size)
            except Exception:
                logger.exception("Failed to read pattern stream %s", self.stream_name)
                break
            if not messages:
                break

            # Refresh our lock TTL each batch so a large backlog drain keeps
            # the lock (atomic CAS-extend). Codex R3/#1: if the extend shows
            # we no longer hold the lease (TTL lapsed and another consumer
            # reacquired), STOP — continuing would double-apply the
            # non-idempotent count/match_hits writes.
            if lock_key and lock_token:
                try:
                    still_ours = self.redis.eval(
                        "if redis.call('get', KEYS[1]) == ARGV[1] "
                        "then return redis.call('expire', KEYS[1], ARGV[2]) else return 0 end",
                        1,
                        lock_key,
                        lock_token,
                        self._LOCK_TTL,
                    )
                except Exception:
                    still_ours = 1  # transient redis error — don't abort on uncertainty
                if not still_ours:
                    logger.warning(
                        "EntityRulerConsumer: lock lease lost mid-drain on %s; stopping to avoid double-apply",
                        self.stream_name,
                    )
                    break

            for msg_id, fields in messages:
                try:
                    ws = self._process_message(fields)
                    if ws:
                        reload_workspaces.add(ws)
                except Exception as exc:
                    # Advance the cursor anyway — one bad message must not wedge
                    # the stream — but never silently: log the loss.
                    logger.warning(
                        "EntityRulerConsumer: dropping unprocessable message %s: %s",
                        msg_id,
                        exc,
                    )
                self._last_id = msg_id
                processed += 1
                if max_iterations is not None and processed >= max_iterations:
                    break

        self._save_cursor()
        # Spike 3: publish reload only AFTER persistence + cursor save.
        for ws in reload_workspaces:
            self._publish_reload(ws)
        return processed

    def _process_message(self, fields: dict[str, str]) -> str | None:
        """Apply one pattern event. Returns the workspace_id to reload, or None."""
        raw = fields.get("data")
        event = json.loads(raw) if raw else dict(fields)
        kind = event.get("kind", "pattern.upsert")
        ws = event.get("workspace_id") or "default"

        if kind == "pattern.upsert":
            graph = self._graph_for(ws)
            graph._upsert_inline_ontology_pattern(
                name=event["name"],
                label=event["label"],
                confidence=float(event.get("confidence", 0.0)),
                workspace_id=ws,
                is_global=bool(event.get("is_global", False)),
                source=event.get("source", "llm_discovery"),
                initial_count=int(event.get("initial_count", 1)),
                registry_id=event.get("registry_id"),
            )
            return ws

        if kind == "pattern.used":
            # SELF-IMPROVE-9 S04/C2: stamp usage. match_hits is distinct from
            # p.count (extraction-frequency) — this is ruler-match recency,
            # the decay sweep's input. No reload (cache-irrelevant).
            graph = self._graph_for(ws)
            graph._get_backend().query(
                "MATCH (p:EntityPattern {name: $name, label: $label}) "
                "SET p.last_matched_at = timestamp(), "
                "p.match_hits = COALESCE(p.match_hits, 0) + 1",
                params={"name": event["name"], "label": event["label"]},
                graph_name=graph._graph_name,
            )
            return None

        # Unknown kinds are a no-op but logged so an unrecognised producer is
        # never silently ignored (no-silent-degradation).
        logger.warning("EntityRulerConsumer: unknown event kind %r", kind)
        return None

    # -- reload pub/sub ------------------------------------------------------

    def _publish_reload(self, workspace_id: str) -> None:
        """Notify PatternManager subscribers to refresh their cache.

        Redis pub/sub is global (not db-scoped); a PUBLISH from the cursor
        connection is a normal command and does not block it. The matching
        SUBSCRIBE lives on its own connection inside PatternManager
        (``.pubsub()``), which is the C4 fix in smart_memory.py.
        """
        channel = f"{PatternManager.RELOAD_CHANNEL_PREFIX}:{workspace_id}"
        try:
            self.redis.publish(channel, "reload")
            logger.debug("EntityRulerConsumer: published ruler reload on %s", channel)
        except Exception as exc:
            logger.warning("EntityRulerConsumer: failed to publish reload on %s: %s", channel, exc)
