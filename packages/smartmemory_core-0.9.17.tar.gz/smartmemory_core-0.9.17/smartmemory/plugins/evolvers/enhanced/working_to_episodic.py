"""Enhanced working → episodic evolver.

Same intent as the basic `working_to_episodic` evolver but with:
- Adaptive threshold based on content length / recency (higher cognitive load
  → lower promotion threshold)
- Semantic + temporal clustering, so a single large working batch becomes
  multiple episodic summaries instead of one monolithic blob
- Recency-weighted summaries (recent items emphasized)

Uses the unified SmartMemory API — no `memory.working` / `memory.episodic`
accessors. Reads working items via search, writes summaries via add, archives
source items via update_properties.
"""
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata
from smartmemory.vault.guard import check_in_place_rewrite


@dataclass
class EnhancedWorkingToEpisodicConfig(MemoryBaseModel):
    base_threshold: int = 40


@dataclass
class EnhancedWorkingToEpisodicRequest(StageRequest):
    base_threshold: int = 40
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class EnhancedWorkingToEpisodicEvolver(EvolverPlugin):
    """Adaptive, clustering-aware promotion of working memory into episodic summaries."""

    def __init__(self, config: Optional[EnhancedWorkingToEpisodicConfig] = None):
        self.config = config or EnhancedWorkingToEpisodicConfig()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="enhanced_working_to_episodic",
            version="2.0.0",
            author="SmartMemory",
            description="Cognitively-informed promotion from working to episodic memory",
            plugin_type="evolver",
            tags=["enhanced", "working", "episodic", "promote"],
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        memory_id = getattr(memory, "item_id", None)
        with trace_span(
            "pipeline.evolve.enhanced_working_to_episodic",
            {"memory_id": memory_id},
        ):
            return self._evolve_impl(memory, logger)

    def _evolve_impl(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(EnhancedWorkingToEpisodicConfig)
        cfg = self.config
        base_threshold = int(cfg.base_threshold)

        working_items = _load_active_pending(memory)
        if len(working_items) < base_threshold:
            return EvolverResult(
                stats={"working_items": len(working_items), "base_threshold": base_threshold},
                notes=[f"below base_threshold ({len(working_items)} < {base_threshold})"],
            )

        adaptive_threshold = _calculate_adaptive_threshold(working_items, base_threshold)
        if len(working_items) < adaptive_threshold:
            return EvolverResult(
                stats={"working_items": len(working_items), "adaptive_threshold": adaptive_threshold},
                notes=[f"below adaptive_threshold ({len(working_items)} < {adaptive_threshold})"],
            )

        clusters = _semantic_temporal_clustering(working_items)

        created_ids: list[str] = []
        archived_ids: list[str] = []
        archive_ts = datetime.now(timezone.utc).isoformat()
        for cluster in clusters:
            summary = _create_enhanced_summary(cluster)
            summary_id = memory.add(summary)
            created_ids.append(summary_id)
            if logger:
                logger.info(
                    f"Promoted {len(cluster)} working items to episodic cluster {summary_id}"
                )

            archive_reason = f"promoted_to_episodic:{summary_id}"
            for item in cluster:
                if not item.item_id:
                    continue
                # APP-VAULT-SYNC-1 P2 S5: guard the in-place archive write so a
                # higher-precedence (e.g. import:vault) working item is not
                # silently mutated by the evolver.
                if not check_in_place_rewrite(
                    memory,
                    item.item_id,
                    evolver_origin="evolver:enhanced_working_to_episodic",
                ):
                    continue
                memory.update_properties(
                    item.item_id,
                    {
                        "archived": True,
                        "archive_reason": archive_reason,
                        "archive_timestamp": archive_ts,
                    },
                )
                archived_ids.append(item.item_id)

        if logger:
            logger.info(
                f"enhanced_working_to_episodic: built {len(created_ids)} clusters "
                f"from {len(working_items)} working items"
            )
        return EvolverResult(
            created_ids=created_ids,
            updated_ids=archived_ids,
            stats={
                "working_items": len(working_items),
                "clusters": len(clusters),
                "adaptive_threshold": adaptive_threshold,
            },
        )


# ---------------------------------------------------------------------------
# Helpers (module-level so they're trivially testable)
# ---------------------------------------------------------------------------


def _load_active_pending(memory: Any) -> List[MemoryItem]:
    results = memory.search(query="*", memory_type="pending", top_k=10000) or []
    return [r for r in results if not _is_archived(r)]


def _calculate_adaptive_threshold(items: List[MemoryItem], base_threshold: int) -> int:
    """Lower the base threshold when cognitive load is high.

    Load signals:
    - Average content length (longer → higher load)
    - Recency concentration (many items from the last hour → higher load)
    """
    if not items:
        return base_threshold

    content_lengths = [len(item.content or "") for item in items]
    avg_length = sum(content_lengths) / len(content_lengths)
    complexity_factor = min(1.5, avg_length / 100)

    now = datetime.now(timezone.utc)
    recent_items = [
        item for item in items
        if (now - _get_item_time(item)).total_seconds() < 3600
    ]
    recency_factor = len(recent_items) / len(items)

    load_factor = (complexity_factor + recency_factor) / 2
    adaptive_threshold = int(base_threshold * (1 - 0.3 * load_factor))
    return max(10, adaptive_threshold)


def _semantic_temporal_clustering(items: List[MemoryItem]) -> List[List[MemoryItem]]:
    """Greedy clustering by word-overlap similarity + temporal proximity."""
    if not items:
        return []

    clusters: List[List[MemoryItem]] = []
    processed = set()

    for i, item in enumerate(items):
        if i in processed:
            continue
        cluster = [item]
        processed.add(i)
        for j in range(i + 1, len(items)):
            if j in processed:
                continue
            other = items[j]
            similarity = _calculate_similarity(item, other)
            temporal_proximity = _calculate_temporal_proximity(item, other)
            if similarity > 0.3 and temporal_proximity > 0.5:
                cluster.append(other)
                processed.add(j)
        clusters.append(cluster)
    return clusters


def _calculate_similarity(a: MemoryItem, b: MemoryItem) -> float:
    words_a = set((a.content or "").lower().split())
    words_b = set((b.content or "").lower().split())
    if not words_a or not words_b:
        return 0.0
    intersection = len(words_a & words_b)
    union = len(words_a | words_b)
    return intersection / union if union else 0.0


def _calculate_temporal_proximity(a: MemoryItem, b: MemoryItem) -> float:
    t_a = _get_item_time(a)
    t_b = _get_item_time(b)
    diff = abs((t_a - t_b).total_seconds())
    return math.exp(-diff / 3600)


def _create_enhanced_summary(cluster: List[MemoryItem]) -> MemoryItem:
    now = datetime.now(timezone.utc)
    weighted_lines: List[str] = []
    for item in cluster:
        age_hours = (now - _get_item_time(item)).total_seconds() / 3600
        weight = math.exp(-age_hours / 24)
        if weight > 0.1:
            weighted_lines.append(f"[w={weight:.2f}] {item.content}")

    summary = MemoryItem(
        content="\n".join(weighted_lines),
        memory_type="episodic",
        origin="evolver:enhanced_working_to_episodic",
        derived_from=cluster[0].item_id if cluster else None,
        metadata={
            "summarized": True,
            "source_count": len(cluster),
            "source_ids": [i.item_id for i in cluster if i.item_id],
            "consolidation_type": "working_to_episodic",
            "consolidation_time": now.isoformat(),
            "cluster_coherence": _calculate_cluster_coherence(cluster),
        },
    )
    return summary


def _calculate_cluster_coherence(cluster: List[MemoryItem]) -> float:
    if len(cluster) <= 1:
        return 1.0
    similarities = []
    for i in range(len(cluster)):
        for j in range(i + 1, len(cluster)):
            similarities.append(_calculate_similarity(cluster[i], cluster[j]))
    return sum(similarities) / len(similarities) if similarities else 0.0


def _get_item_time(item: MemoryItem) -> datetime:
    """Return a timezone-aware datetime for an item.

    Prefers `transaction_time` (the canonical field on MemoryItem), then
    `metadata.created_at` / `metadata.reference_time`, finally `now`.
    """
    tx = getattr(item, "transaction_time", None)
    if isinstance(tx, datetime):
        return tx if tx.tzinfo else tx.replace(tzinfo=timezone.utc)

    meta = getattr(item, "metadata", None) or {}
    for key in ("created_at", "reference_time"):
        val = meta.get(key)
        if isinstance(val, datetime):
            return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
        if isinstance(val, str):
            try:
                parsed = datetime.fromisoformat(val)
                return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
            except ValueError:
                pass
    return datetime.now(timezone.utc)


def _is_archived(item: MemoryItem) -> bool:
    meta = getattr(item, "metadata", None) or {}
    return bool(meta.get("archived", False))
