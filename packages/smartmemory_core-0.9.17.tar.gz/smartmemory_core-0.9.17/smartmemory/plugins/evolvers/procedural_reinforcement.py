"""Procedural reinforcement evolver (CORE-MEMORY-DYNAMICS-1 M2a Slice C C.2).

For each procedural memory with a non-empty ``retrieval__profile``, fires an
activation boost through ``boost_activation`` so that actively-invoked
procedures accumulate activation score and surface more readily on future
``get_working_context`` calls.

**No new storage.** This evolver is a pure feeder into the activation
pipeline (``boost_activation`` → Redis INCRBYFLOAT → worker
``ActivationFlushJob`` → ``metadata["activation"]["score"]``). The procedural
items themselves are unchanged.

Reason tag on the boost is ``procedure_invoked`` so activation telemetry
distinguishes reinforcement writes from ordinary retrieval-side boosts.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from smartmemory.activation.boost import boost_activation
from smartmemory.activation.constants import BOOST_SIZE_RETRIEVE
from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata

logger = logging.getLogger(__name__)


@dataclass
class ProceduralReinforcementConfig(MemoryBaseModel):
    max_memories: int = 500
    min_retrieval_count: int = 1


@dataclass
class ProceduralReinforcementRequest(StageRequest):
    max_memories: int = 500
    min_retrieval_count: int = 1
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class ProceduralReinforcementEvolver(EvolverPlugin):
    """Fire activation boosts on procedural items with recent retrieval activity."""

    def __init__(self, config: Optional[ProceduralReinforcementConfig] = None):
        self.config = config or ProceduralReinforcementConfig()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="procedural_reinforcement",
            version="1.0.0",
            author="SmartMemory Team",
            description="Boost activation on procedural items that have been invoked recently",
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.1.0",
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(ProceduralReinforcementConfig)
        cfg = self.config
        cap = int(cfg.max_memories)
        min_count = max(1, int(cfg.min_retrieval_count))

        with trace_span(
            "pipeline.evolve.procedural_reinforcement",
            {"cap": cap, "min_retrieval_count": min_count},
        ):
            try:
                items = memory.search(query="*", memory_type="procedural", top_k=cap) or []
            except Exception as exc:
                if logger:
                    logger.warning("procedural_reinforcement: search failed — %s", exc)
                return EvolverResult(stats={"error": str(exc)})

            boosted_ids: list[str] = []
            attempted_ids: list[str] = []
            skipped = 0
            fallback_boosts = 0
            for item in items:
                item_id = getattr(item, "item_id", None)
                if not item_id:
                    skipped += 1
                    continue

                profile = _deserialize_profile(item)
                count = _profile_retrieval_count(profile)
                if count < min_count:
                    skipped += 1
                    continue

                attempted_ids.append(str(item_id))
                try:
                    # boost_activation returns True on the Redis INCRBYFLOAT
                    # success path, False on fallback / no-workspace / silent
                    # failure. Only credit the Redis path as a confirmed boost
                    # so stats don't over-report. The fallback path did mutate
                    # metadata in most cases but we expose it separately for
                    # telemetry fidelity.
                    took_redis = boost_activation(
                        memory,
                        str(item_id),
                        BOOST_SIZE_RETRIEVE,
                        reason="procedure_invoked",
                    )
                    if took_redis:
                        boosted_ids.append(str(item_id))
                    else:
                        fallback_boosts += 1
                except Exception as exc:
                    # boost_activation itself is documented never-raise, but a
                    # contextvar/workspace-resolution glitch could still surface.
                    if logger:
                        logger.warning(
                            "procedural_reinforcement: boost failed for %s — %s",
                            item_id, exc,
                        )
                    skipped += 1

            if logger:
                logger.info(
                    "procedural_reinforcement: procedural=%d attempted=%d "
                    "boosted_via_redis=%d fallback=%d skipped=%d",
                    len(items), len(attempted_ids), len(boosted_ids),
                    fallback_boosts, skipped,
                )
            return EvolverResult(
                updated_ids=boosted_ids,
                stats={
                    "procedural_scanned": len(items),
                    "attempted": len(attempted_ids),
                    "boosted": len(boosted_ids),
                    "fallback": fallback_boosts,
                    "skipped": skipped,
                    "min_retrieval_count": min_count,
                },
            )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _deserialize_profile(item: Any) -> Optional[dict]:
    """Read the retrieval profile dict written by RetrievalFlushConsumer.

    The writer calls ``update_properties(id, {"retrieval__profile": dict_value})``.
    ``flatten_dict`` explodes the dict-valued write into top-level dunder keys
    (``retrieval__profile__total_count`` etc.) and ``unflatten_dict`` on read
    splits every ``__``, so the value lands at ``metadata.retrieval.profile``,
    NOT at ``metadata["retrieval__profile"]``.

    CORE-RETRIEVAL-PROFILE-1 (2026-04-25): readers updated to look at the
    nested path. Falls back to the legacy flat-key location for any in-memory
    test paths that bypass the flatten/unflatten cycle.
    """
    try:
        md = getattr(item, "metadata", None) or {}
        # Primary: nested form produced by from_vector_store unflatten.
        retrieval = md.get("retrieval")
        if isinstance(retrieval, dict):
            profile = retrieval.get("profile")
            if isinstance(profile, dict):
                return profile
            if isinstance(profile, str):
                return json.loads(profile)
        # Fallback: legacy literal-dunder key (in-memory/test paths only).
        raw = md.get("retrieval__profile")
        if isinstance(raw, dict):
            return raw
        if isinstance(raw, str):
            return json.loads(raw)
        return None
    except Exception:
        return None


def _profile_retrieval_count(profile: Optional[dict]) -> int:
    """Extract the retrieval count from a profile dict.

    ``RetrievalFlushConsumer`` writes ``total_count`` plus per-source counts.
    Prefer ``total_count`` as the canonical field; fall back to summing
    per-source counters for robustness.
    """
    if not isinstance(profile, dict):
        return 0
    try:
        total = int(profile.get("total_count", 0) or 0)
    except (TypeError, ValueError):
        total = 0
    if total > 0:
        return total
    # Robustness: sum anything that looks like a per-source count.
    fallback = 0
    for k, v in profile.items():
        if not isinstance(k, str):
            continue
        if k.endswith("_count"):
            try:
                fallback += int(v or 0)
            except (TypeError, ValueError):
                pass
    return fallback
