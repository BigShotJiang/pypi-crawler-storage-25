"""Citation-ready formatting for recall/search results (RECALL-CITATIONS-1).

Thin formatting layer over existing search results. The consuming agent
(Claude Code, Cursor, Codex) uses this to footnote results in its reply
to the human user, fulfilling the launch-post "audit recall" promise.

No new memory type, no new pipeline stage, no LLM synthesis. Just
turning the top-N results into a stable, paste-ready footnote block.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional

# Default cap for citations array length. The full result list is unchanged;
# only the citations summary is limited.
DEFAULT_MAX_CITATIONS = 3
# Hard cap on preview text used in citations (chars).
PREVIEW_CHAR_LIMIT = 200
# Footnote inline preview hard cap (chars), shorter than the preview field.
FOOTNOTE_PREVIEW_CHARS = 80


@dataclass(frozen=True)
class Citation:
    """A single citation entry. 1-indexed.

    Returned in the ``citations`` array on search responses when ``cite=True``.
    Stable, additive shape — never replaces ``results``.
    """

    n: int                 # 1-indexed position in the citation block
    item_id: str
    item_type: str         # MemoryItem.memory_type (e.g. "semantic")
    preview: str           # ≤ PREVIEW_CHAR_LIMIT chars of content
    score: float           # search relevance score (0.0 if missing)
    footnote_marker: str   # e.g. "[^1]"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _coerce_item(item: Any) -> Dict[str, Any]:
    """Accept dicts (formatted API results) or MemoryItem-like objects."""
    if isinstance(item, dict):
        return item
    # MemoryItem or duck-typed object
    return {
        "item_id": getattr(item, "item_id", "") or "",
        "memory_type": getattr(item, "memory_type", "semantic") or "semantic",
        "content": getattr(item, "content", "") or "",
        "score": getattr(item, "score", None),
    }


def _preview_text(content: Optional[str], limit: int = PREVIEW_CHAR_LIMIT) -> str:
    """Trim content to ``limit`` chars, single-line, ellipsis-suffixed."""
    if not content:
        return ""
    s = " ".join(str(content).split())  # collapse whitespace, single line
    if len(s) <= limit:
        return s
    # Ellipsis included in limit
    return s[: max(1, limit - 1)].rstrip() + "…"


def build_citations(
    items: List[Any],
    max_citations: int = DEFAULT_MAX_CITATIONS,
) -> List[Citation]:
    """Build the ``citations`` array from the top-N search results.

    Args:
        items: search results (dicts from ``_format_memory_item`` or MemoryItem objects).
        max_citations: cap on citation count (default 3).

    Returns:
        List of ``Citation`` (length min(max_citations, len(items))).
        Empty list if ``items`` is empty — never raises, never omits.
    """
    if max_citations < 0:
        raise ValueError(f"max_citations must be >= 0, got {max_citations}")
    out: List[Citation] = []
    for n, raw in enumerate(items[:max_citations], start=1):
        d = _coerce_item(raw)
        item_id = str(d.get("item_id") or "")
        if not item_id:
            # Skip malformed items rather than emit a citation with no anchor
            continue
        score_val = d.get("score")
        try:
            score_f = float(score_val) if score_val is not None else 0.0
        except (TypeError, ValueError):
            score_f = 0.0
        out.append(
            Citation(
                n=n,
                item_id=item_id,
                item_type=str(d.get("memory_type") or "semantic"),
                preview=_preview_text(d.get("content"), PREVIEW_CHAR_LIMIT),
                score=score_f,
                footnote_marker=f"[^{n}]",
            )
        )
    # Re-number if any were skipped, so markers stay 1..N contiguous
    if any(c.n != i + 1 for i, c in enumerate(out)):
        out = [
            Citation(
                n=i + 1,
                item_id=c.item_id,
                item_type=c.item_type,
                preview=c.preview,
                score=c.score,
                footnote_marker=f"[^{i + 1}]",
            )
            for i, c in enumerate(out)
        ]
    return out


def format_for_citation(item: Any, n: int) -> str:
    """Render a single result as a markdown footnote line.

    The consuming agent pastes these verbatim as the footnote section
    of its reply, then references ``[^n]`` inline naturally.

    Format::

        [^1]: <item_type> · <preview first 80 chars>… (id: <item_id>, score: 0.87)
    """
    if n < 1:
        raise ValueError(f"n must be >= 1, got {n}")
    d = _coerce_item(item)
    item_id = str(d.get("item_id") or "")
    item_type = str(d.get("memory_type") or "semantic")
    preview = _preview_text(d.get("content"), FOOTNOTE_PREVIEW_CHARS)
    score_val = d.get("score")
    try:
        score_f = float(score_val) if score_val is not None else 0.0
    except (TypeError, ValueError):
        score_f = 0.0
    return f"[^{n}]: {item_type} · {preview} (id: {item_id}, score: {score_f:.2f})"


def build_footnote_block(items: List[Any], max_citations: int = DEFAULT_MAX_CITATIONS) -> str:
    """Build the full footnote block ready to paste into an agent reply.

    Returns a newline-joined string of ``format_for_citation`` lines.
    Returns empty string when ``items`` is empty (caller distinguishes
    "no results" from "no citations requested" by passing ``cite=True``).
    """
    lines = [format_for_citation(it, i + 1) for i, it in enumerate(items[:max_citations])]
    return "\n".join(lines)


__all__ = [
    "Citation",
    "DEFAULT_MAX_CITATIONS",
    "PREVIEW_CHAR_LIMIT",
    "FOOTNOTE_PREVIEW_CHARS",
    "build_citations",
    "build_footnote_block",
    "format_for_citation",
]
