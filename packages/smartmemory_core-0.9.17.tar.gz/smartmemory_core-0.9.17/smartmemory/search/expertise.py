"""Expertise recall filter and per-bucket boost (CORE-EXPERTISE-1 Phase 4a).

`filter_and_boost` groups expertise-typed memory items into a typed dict keyed
by memory type, then reorders each bucket using a recency + confidence boost
applied over a rank-derived baseline (or `_rerank_score` when present).

This module is pure: no SmartMemory dependency, no I/O. It operates on whatever
ranked sequence the caller passes in.

Contract: docs/features/CORE-EXPERTISE-1/expertise-search-contract.json
"""

from __future__ import annotations

import math
from datetime import datetime
from typing import Iterable, Sequence

EXPERTISE_TYPES: tuple[str, ...] = (
    "decision",
    "constraint",
    "learned",
    "opinion",
    "reasoning",
    "observation",
)

RRF_K: int = 60
RECENCY_TAU_DAYS: float = 30.0
RECENCY_ALPHA: float = 0.3
CONFIDENCE_BETA: float = 0.2

_DEFAULT_CONFIDENCE: float = 0.5


def _baseline_score(item, input_rank: int) -> float:
    """Rank-derived baseline, or `_rerank_score` if the cross-encoder attached one.

    `input_rank` is 1-based: the first item in the fused result list has rank 1.
    """
    rerank = getattr(item, "_rerank_score", None)
    if isinstance(rerank, (int, float)):
        return float(rerank)
    return 1.0 / (RRF_K + input_rank)


def _recency_factor(item, now: datetime, tau_days: float, alpha: float) -> float:
    ts = getattr(item, "transaction_time", None)
    if ts is None:
        return 1.0
    try:
        age_days = max(0.0, (now - ts).total_seconds() / 86400.0)
    except (TypeError, ValueError):
        return 1.0
    return 1.0 + alpha * math.exp(-age_days / tau_days)


def _get_status(item) -> str | None:
    """Read lifecycle status from either top-level attribute or metadata."""
    status = getattr(item, "status", None)
    if isinstance(status, str):
        return status
    metadata = getattr(item, "metadata", None) or {}
    if isinstance(metadata, dict):
        s = metadata.get("status")
        if isinstance(s, str):
            return s
    return None


def _confidence_factor(item, beta: float) -> float:
    confidence = getattr(item, "confidence", None)
    if not isinstance(confidence, (int, float)):
        confidence = _DEFAULT_CONFIDENCE
    return 1.0 + beta * float(confidence)


def filter_and_boost(
    results: Iterable,
    *,
    now: datetime,
    top_k: int,
    boost_overrides: dict | None = None,
) -> dict[str, list]:
    """Group expertise-typed results into a typed dict, apply boost, cap per bucket.

    Args:
        results: An ordered iterable of `MemoryItem`-shaped objects (input rank
            == position in iteration order). Non-expertise items are dropped.
        now: Reference time for the recency factor — caller-supplied so the
            function stays testable.
        top_k: Per-bucket cap. Each bucket of the returned dict holds at most
            `top_k` items, ranked by boosted score descending.
        boost_overrides: Optional dict overriding any of `recency_tau_days`,
            `recency_alpha`, `confidence_beta`. Unknown keys are ignored.

    Returns:
        A dict with all six `EXPERTISE_TYPES` keys present, each mapping to a
        list of items (possibly empty).
    """
    overrides = boost_overrides or {}
    tau_days = float(overrides.get("recency_tau_days", RECENCY_TAU_DAYS))
    alpha = float(overrides.get("recency_alpha", RECENCY_ALPHA))
    beta = float(overrides.get("confidence_beta", CONFIDENCE_BETA))

    buckets: dict[str, list[tuple[float, object]]] = {k: [] for k in EXPERTISE_TYPES}

    for input_rank, item in enumerate(results, start=1):
        mt = getattr(item, "memory_type", None)
        if mt not in buckets:
            continue
        # Defensive supersession/retraction filter: managed types (DecisionManager
        # etc.) write status='superseded'/'retracted' to metadata. The upstream
        # search() include_superseded filter only catches SupersedeStage-marked
        # items, not Manager-marked ones. Drop both here so the expertise channel
        # honours either marking.
        status = _get_status(item)
        if status in ("superseded", "retracted"):
            continue
        baseline = _baseline_score(item, input_rank)
        score = baseline * _recency_factor(item, now, tau_days, alpha) * _confidence_factor(item, beta)
        buckets[mt].append((score, item))

    return {
        mt: [item for _, item in sorted(scored, key=lambda x: x[0], reverse=True)[:top_k]]
        for mt, scored in buckets.items()
    }


__all__: Sequence[str] = (
    "EXPERTISE_TYPES",
    "RRF_K",
    "RECENCY_TAU_DAYS",
    "RECENCY_ALPHA",
    "CONFIDENCE_BETA",
    "filter_and_boost",
)
