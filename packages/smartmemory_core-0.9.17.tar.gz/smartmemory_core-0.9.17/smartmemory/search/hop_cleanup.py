"""Per-hop entity cleanup for multi-hop retrieval (SEARCH-MULTIHOP-CLEANUP-1).

Cleanup pass that runs between hops in :class:`MultiHopSearch`. For each result's
``metadata['entities']`` dict, builds a canonical key from ``(name, entity_type)``
and asks the graph to resolve it to a canonical entity node. Annotates the
entity dict in-place with ``canonical_id`` on hit, emits a :class:`CleanupRefusal`
on miss.

Read-only against the graph (no edges written). This is what distinguishes
cleanup from the ``ground`` ingest stage, which writes ``GROUNDED_IN`` edges.

Refusal type is interim until ``PIPELINE-REFUSAL-1`` ships ``StageRefusal``.
"""

from __future__ import annotations

import copy
import logging
from dataclasses import dataclass, field
from typing import Any, Iterable, Literal, Optional

from smartmemory.utils.deduplication import get_canonical_key

logger = logging.getLogger(__name__)


@dataclass
class CleanupRefusal:
    """A reason a single entity mention could not be resolved to a canonical id.

    Forward-compatible with PIPELINE-REFUSAL-1's ``StageRefusal`` — when that
    ships, ``CleanupRefusal`` becomes a thin alias / subclass.
    """

    surface_form: str
    reason_code: Literal["unresolvable_entity", "ambiguous"]
    detail: str


@dataclass
class _CleanupCounters:
    resolved: int = 0
    unresolved: int = 0
    ambiguous: int = 0
    refusals: list[CleanupRefusal] = field(default_factory=list)

    def to_metadata(self) -> dict[str, Any]:
        return {
            "resolved_count": self.resolved,
            "unresolved_count": self.unresolved,
            "ambiguous_count": self.ambiguous,
            "refusals": [
                {
                    "surface_form": r.surface_form,
                    "reason_code": r.reason_code,
                    "detail": r.detail,
                }
                for r in self.refusals
            ],
        }


def _is_blank(s: Any) -> bool:
    return not isinstance(s, str) or not s.strip()


def cleanup_results(
    results: Iterable,
    graph,
    *,
    key_to_id_cache: Optional[dict[str, Optional[str]]] = None,
) -> tuple[list, list[CleanupRefusal]]:
    """Resolve entity mentions in result metadata to canonical graph IDs.

    For each result's ``metadata['entities']`` dict:

    1. If ``name`` or ``entity_type`` is blank → :class:`CleanupRefusal` with
       ``reason_code='ambiguous'`` (no graph call).
    2. Else build canonical key via :func:`smartmemory.utils.deduplication.get_canonical_key`.
    3. Look up via ``graph.find_entity_by_canonical_key(key)`` — None → refusal
       ``reason_code='unresolvable_entity'``; dict hit → annotate the entity
       dict in-place with ``entity['canonical_id'] = result['item_id']``.
    4. Per-result, attach a ``metadata['cleanup']`` summary with counts and
       refusals.

    Args:
        results: Iterable of :class:`MemoryItem`-shaped objects with ``metadata`` dict.
        graph: Anything implementing ``find_entity_by_canonical_key(key) -> dict | None``.
            In production this is :class:`SmartGraph`; in tests it can be a stub.
        key_to_id_cache: Optional cross-call cache. Caller (``MultiHopSearch.execute``)
            shares one cache across all hops in a search. ``None`` → entries cached
            for unresolvable keys, preventing re-query within the same call.

    Returns:
        ``(results, refusals)`` — same results list (annotated in place) and a flat
        refusal list aggregated across all results.
    """
    # SEARCH-MULTIHOP-CLEANUP-1 (Codex iter 2): defensively clone each result before
    # mutating. ``MemoryItem`` instances are shared across the in-process node cache
    # (smart-memory-core/smartmemory/graph/core/nodes.py:175). Without isolation, a
    # ``cleanup=True`` search would poison cached objects so a later ``cleanup=False``
    # search would still surface ``metadata['cleanup']`` and per-entity ``canonical_id``
    # annotations — breaking the documented backward-compat contract.
    cloned_results = []
    for r in results:
        try:
            r_clone = copy.copy(r)
            md = getattr(r, "metadata", None)
            r_clone.metadata = copy.deepcopy(md) if isinstance(md, dict) else (md if md is None else dict(md))
            cloned_results.append(r_clone)
        except Exception:
            # Result type doesn't permit copy/metadata mutation — skip isolation,
            # caller accepts whatever leakage results. Logged at debug.
            logger.debug("cleanup_results: could not clone %r, falling back to in-place", r)
            cloned_results.append(r)
    results_list = cloned_results

    if key_to_id_cache is None:
        key_to_id_cache = {}

    aggregated_refusals: list[CleanupRefusal] = []

    for result in results_list:
        counters = _CleanupCounters()
        metadata = getattr(result, "metadata", None)
        if metadata is None:
            metadata = {}
            try:
                result.metadata = metadata
            except AttributeError:
                # Result type doesn't allow metadata mutation — skip cleanup
                continue

        entities: list = metadata.get("entities") or []

        for entity in entities:
            if not isinstance(entity, dict):
                continue

            name = entity.get("name") or entity.get("content")
            entity_type = entity.get("entity_type")

            if _is_blank(name) or _is_blank(entity_type):
                refusal = CleanupRefusal(
                    surface_form=str(name or "").strip() or "<unknown>",
                    reason_code="ambiguous",
                    detail=(
                        "missing entity_type" if not _is_blank(name) else "missing name"
                    ),
                )
                counters.ambiguous += 1
                counters.refusals.append(refusal)
                aggregated_refusals.append(refusal)
                logger.warning(
                    "hop_cleanup: refusing %s — %s", refusal.surface_form, refusal.detail
                )
                continue

            key = get_canonical_key(name, entity_type)

            if key in key_to_id_cache:
                resolved_id = key_to_id_cache[key]
            else:
                hit = graph.find_entity_by_canonical_key(key)
                resolved_id = hit["item_id"] if hit and "item_id" in hit else None
                key_to_id_cache[key] = resolved_id

            if resolved_id is None:
                refusal = CleanupRefusal(
                    surface_form=name,
                    reason_code="unresolvable_entity",
                    detail=f"no graph entity for canonical_key={key!r}",
                )
                counters.unresolved += 1
                counters.refusals.append(refusal)
                aggregated_refusals.append(refusal)
                logger.warning(
                    "hop_cleanup: unresolvable entity %s (key=%s)", name, key
                )
            else:
                entity["canonical_id"] = resolved_id
                counters.resolved += 1

        metadata["cleanup"] = counters.to_metadata()

    return results_list, aggregated_refusals
