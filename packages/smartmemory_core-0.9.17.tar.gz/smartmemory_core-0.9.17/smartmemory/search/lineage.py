"""CORE-RECALL-LINEAGE-1 Phase 3 — lineage roots walker.

Resolves a search result item's canonical source(s) by walking three
lineage signals back to their origin:

- ``n.derived_from`` scalar — the primary lineage edge, written by every
  evolver and by the auto-edge code at ``smart_memory.py:1912``
- ``n.metadata.derived_from_ids`` list — multi-source derivations
  (``SemanticToProceduralEvolver`` writes the first source to
  ``derived_from`` and remaining sources to this list)
- reverse ``HAS_VERSION`` edge — ``version_*`` rows back to their canonical

Output is a non-empty list of canonical ``item_id`` strings. Self-
reference (``[item_id]``) when no upstream signals exist.

Invariants (per design.md S3 + Phase 3 Codex review):

- **Workspace-scoped.** Reads go through the originating ``SmartMemory``
  facade's ``get(item_id)`` so the ``ScopeProvider`` enforces tenant
  isolation. Cross-workspace root_ids never appear in the result.
- **Depth-capped** at 5 hops. Procedural derivations are shallow in
  practice; the cap prevents pathological data corruption (or future
  cascade evolvers) from causing unbounded walks.
- **Visited-set** cycle detection. A → B → A terminates immediately.
- **Multi-root.** A K-source derivation returns ``K`` root_ids
  (deduplicated, order-preserved by first-visit). Self-references are
  filtered out — if every upstream signal is exhausted, the walker may
  emit the deepest visited node as a "frontier root" when the depth cap
  fires before reaching a true terminal.
"""

from __future__ import annotations

import logging
from collections import deque
from typing import Any, Iterable, List, Optional, Sequence

logger = logging.getLogger(__name__)

DEFAULT_MAX_HOPS = 5


def resolve_lineage_roots(
    memory: Any,
    item_id: str,
    *,
    max_hops: int = DEFAULT_MAX_HOPS,
) -> List[str]:
    """Walk lineage edges from ``item_id`` to its canonical source(s).

    Args:
        memory: A ``SmartMemory`` or ``SecureSmartMemory`` instance. The
            walker calls ``memory.get(item_id)`` (scoped) for each visit
            and ``memory._graph.backend.get_neighbors`` for the reverse
            ``HAS_VERSION`` traversal.
        item_id: The starting item.
        max_hops: Depth cap (default 5).

    Returns:
        A non-empty list of canonical ``item_id`` strings. Order is by
        first-visit (BFS). Self-reference (``[item_id]``) when the start
        item has no upstream.
    """
    if not item_id:
        return []

    # Resolve the caller's workspace once for scope filtering on every
    # upstream candidate. ``SmartMemory.get`` / ``CRUD.get`` are NOT
    # workspace-scoped today (they delegate to ``backend.get_node`` which
    # is item-id-keyed), so the walker enforces scoping by comparing each
    # candidate's ``workspace_id`` against this one. ``None`` here means
    # the caller is unscoped (test or admin); the walker permits all reads.
    expected_ws: Optional[str] = None
    scope_provider = getattr(memory, "scope_provider", None)
    if scope_provider is not None:
        expected_ws = getattr(scope_provider, "workspace_id", None)

    # Scope-check the start node before seeding. Without this, a scoped
    # caller passing a foreign item_id would receive ``[foreign_id]`` back
    # — violating the "no cross-tenant root_ids" invariant on the very
    # first step. Service callers feed only in-scope IDs in practice, but
    # the walker's contract enforces it independently. ``expected_ws=None``
    # (unscoped / admin) skips the check as before.
    if expected_ws is not None:
        try:
            start_item = memory.get(item_id)
        except Exception as exc:  # noqa: BLE001
            logger.debug("lineage walker: start-node scope check for %r failed: %s", item_id, exc)
            return []
        if start_item is None:
            return []
        start_ws = (
            getattr(start_item, "workspace_id", None)
            or (
                start_item.metadata.get("workspace_id")
                if hasattr(start_item, "metadata") and hasattr(start_item.metadata, "get")
                else None
            )
        )
        if start_ws != expected_ws:
            logger.debug(
                "lineage walker: start node %r workspace %r != caller %r — refusing to resolve",
                item_id,
                start_ws,
                expected_ws,
            )
            return []

    roots: List[str] = []
    seen: set[str] = set()
    queue: deque[tuple[str, int]] = deque([(item_id, 0)])

    while queue:
        node_id, depth = queue.popleft()
        if node_id in seen:
            continue
        seen.add(node_id)

        upstream = _collect_upstream(memory, node_id)
        if not upstream:
            # No further upstream — this is a canonical root.
            if node_id not in roots:
                roots.append(node_id)
            continue

        if depth >= max_hops:
            # Depth cap reached; treat the current node as a frontier root
            # rather than silently dropping. Better to surface a
            # too-deep-to-resolve canonical than nothing.
            if node_id not in roots:
                roots.append(node_id)
            continue

        for up_id in upstream:
            if not up_id or up_id == node_id or up_id in seen:
                continue
            # Workspace-scope check: backend.get_neighbors / get_node are
            # item-id-keyed and unscoped. We resolve the candidate and
            # compare its ``workspace_id`` to the caller's. If they differ,
            # drop the candidate — never let a cross-tenant root_id leak
            # into the returned list. ``expected_ws=None`` means the
            # caller is unscoped (admin / lite mode), and all reads pass.
            if expected_ws is not None:
                try:
                    candidate = memory.get(up_id)
                except Exception as exc:  # noqa: BLE001
                    logger.debug(
                        "lineage walker: scope check for %r failed: %s", up_id, exc
                    )
                    continue
                if candidate is None:
                    continue
                candidate_ws = (
                    getattr(candidate, "workspace_id", None)
                    or (
                        candidate.metadata.get("workspace_id")
                        if hasattr(candidate, "metadata") and hasattr(candidate.metadata, "get")
                        else None
                    )
                )
                # Strict: under a scoped caller, REQUIRE the candidate's
                # workspace_id to match. A candidate with no hydrated
                # workspace_id is treated as inaccessible — temporal/
                # relationships.py:136,390 enforce the same strict shape
                # for tenant-sensitive traversals.
                if candidate_ws != expected_ws:
                    logger.debug(
                        "lineage walker: dropping upstream %r — workspace %r != caller %r",
                        up_id,
                        candidate_ws,
                        expected_ws,
                    )
                    continue
            queue.append((up_id, depth + 1))

    if not roots:
        # Fallback: walker visited only the start and found nothing
        # upstream (shouldn't happen given the early-return for empty
        # upstream above, but defend against unexpected backend states).
        return [item_id]
    return roots


def _collect_upstream(memory: Any, item_id: str) -> List[str]:
    """Return the immediate upstream item_ids for ``item_id``.

    Looks at three signals in order:

    1. ``item.derived_from`` (scalar property on the MemoryItem)
    2. ``item.metadata.derived_from_ids`` (list of additional sources)
    3. incoming ``HAS_VERSION`` edges (for ``version_*`` shadow rows
       whose canonical lives on the OTHER end of an outgoing edge from
       the canonical — so from a version row, the canonical is reached
       via an INCOMING HAS_VERSION edge to the version row, i.e. the
       canonical is the source of the edge)

    Empty list means "this is a root" — the walker stops here.
    """
    upstream: List[str] = []
    backend = memory._graph.backend

    # Scoped read via the SmartMemory facade — workspace isolation applies.
    item = None
    try:
        item = memory.get(item_id)
    except Exception as exc:  # noqa: BLE001
        logger.debug("lineage walker: memory.get(%r) failed: %s", item_id, exc)
        item = None

    if item is not None:
        # ``derived_from`` is a first-class MemoryItem field but the
        # NodeTypeProcessor strips it from persisted node properties (see
        # the comment at smart_memory.py:1757). The lineage signal lives
        # in the DERIVED_FROM graph edge created by _create_lineage_edges
        # at smart_memory.py:1912. Read the attribute first (cheap, works
        # for in-flight items pre-store-flush); fall back to the edge.
        scalar = getattr(item, "derived_from", None)
        if scalar:
            upstream.append(str(scalar))

        # metadata can be either a dict or a Mapping-like proxy. Different
        # evolvers historically wrote multi-source provenance under different
        # keys — until the producer-side gap (filed as CORE-PROVENANCE-NORM-1)
        # standardizes them, the walker reads ALL of them defensively:
        #   - metadata.derived_from_ids — SemanticToProceduralEvolver
        #   - metadata.source_ids       — memory_consolidation,
        #                                  observation_synthesis (reflector path),
        #                                  enhanced_working_to_episodic
        #   - metadata.formed_from      — opinion_synthesis evidence list
        metadata = getattr(item, "metadata", None) or {}
        if hasattr(metadata, "get"):
            for key in ("derived_from_ids", "source_ids", "formed_from"):
                bucket = metadata.get(key) or []
                if isinstance(bucket, (list, tuple)):
                    for src in bucket:
                        src = str(src)
                        if src and src not in upstream:
                            upstream.append(src)

    # Outgoing provenance edges. DERIVED_FROM is the canonical type, but
    # memory_consolidation writes CONSOLIDATED_FROM and never sets
    # derived_from; we read both until the producer-side gap is closed.
    for edge_type in ("DERIVED_FROM", "CONSOLIDATED_FROM"):
        try:
            neighbors = backend.get_neighbors(item_id, edge_type=edge_type, direction="outgoing")
            for n in neighbors or []:
                if isinstance(n, tuple) and n and isinstance(n[0], dict):
                    nid = n[0].get("item_id")
                elif isinstance(n, dict):
                    nid = n.get("item_id")
                else:
                    nid = getattr(n, "item_id", None)
                if nid and nid != item_id and nid not in upstream:
                    upstream.append(str(nid))
        except Exception as exc:  # noqa: BLE001
            logger.debug("lineage walker: %s lookup for %r failed: %s", edge_type, item_id, exc)

    # Reverse HAS_VERSION: from a version_* node, the canonical sits at
    # the OTHER end of the edge — incoming relative to the version row.
    if item_id.startswith("version_"):
        try:
            neighbors = backend.get_neighbors(item_id, edge_type="HAS_VERSION", direction="incoming")
            for n in neighbors or []:
                if isinstance(n, tuple) and n and isinstance(n[0], dict):
                    nid = n[0].get("item_id")
                elif isinstance(n, dict):
                    nid = n.get("item_id")
                else:
                    nid = getattr(n, "item_id", None)
                if nid and nid != item_id and nid not in upstream:
                    upstream.append(str(nid))
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "lineage walker: HAS_VERSION lookup for %r failed: %s", item_id, exc
            )

    return upstream
