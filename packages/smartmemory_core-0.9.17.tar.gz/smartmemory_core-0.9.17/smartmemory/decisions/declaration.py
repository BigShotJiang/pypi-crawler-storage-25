"""ManagedType declaration for the Decision memory type.

Internal — produces the four base classes (Dataclass, Handler, Manager, Queries)
that `smartmemory.decisions.{manager,queries}` and `smartmemory.models.decision`
subclass for Decision-specific behavior.

See smart-memory-docs/docs/features/CORE-MANAGED-TYPE-FRAMEWORK-1/phase-2-decision/
for the design + blueprint + plan that drove this declaration.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from smartmemory.managed import Field, ManagedType, _KEEP_DEFAULT_ORIGIN
from smartmemory.models.pending_requirement import PendingRequirement


# --- Nested-field hooks for pending_requirements ----------------------------


def _serialize_pending(lst: list[PendingRequirement]) -> list[dict]:
    """Serialize each PendingRequirement via its own to_dict (preserves key order)."""
    return [r.to_dict() for r in (lst or [])]


def _deserialize_pending(raw: Any) -> list[PendingRequirement]:
    """Deserialize a list of PendingRequirements with FalkorDB JSON-string tolerance.

    Verbatim port of smartmemory/models/decision.py:245-262 (pre-Path-C).
    """
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return []
    out: list[PendingRequirement] = []
    for r in (raw or []):
        if isinstance(r, str):
            try:
                r = json.loads(r)
            except (json.JSONDecodeError, TypeError):
                continue
        if isinstance(r, dict):
            out.append(PendingRequirement.from_dict(r))
    return out


# --- Edge fn at create() time -----------------------------------------------


def _decision_first_class(instance) -> dict:
    """Lift `confidence` and `derived_from` from a Decision to MemoryItem first-class fields.

    Used by the framework's `_store_instance` to build the MemoryItem.
    Mirrors legacy `DecisionManager._store_decision` (decisions/manager.py:290-299 pre-Path-C).
    """
    return {
        "confidence": instance.confidence,
        "derived_from": instance.evidence_ids[0] if instance.evidence_ids else None,
    }


def _decision_edges(data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
    """Emit PRODUCED + DERIVED_FROM edges at decision-create time.

    Mirrors DecisionManager.create() lines 93-103 (pre-Path-C).
    """
    edges: list[tuple[str, str, str, dict]] = []
    ts = datetime.now(timezone.utc).isoformat()

    src_trace = data.get("source_trace_id")
    if src_trace:
        edges.append(
            (
                src_trace,
                item_id,
                "PRODUCED",
                {"confidence": 0.5, "timestamp": ts, "origin": "evolver:decision"},
            )
        )

    for eid in (data.get("evidence_ids") or []):
        edges.append(
            (
                item_id,
                eid,
                "DERIVED_FROM",
                {"role": "evidence", "origin": "evolver:decision", "confidence": 0.5},
            )
        )

    return edges


# --- ManagedType declaration ------------------------------------------------


_DECISION_TYPE = ManagedType(
    name="decision",
    fields={
        "decision_type": Field(str, default="inference"),
        "evidence_ids": Field(list[str], carry_forward_on_supersede=True),
        "contradicting_ids": Field(list[str]),
        # reinforcement_count, contradiction_count, last_reinforced_at,
        # last_contradicted_at are auto-added by lifecycle="extended" — see
        # framework.py:222-225.
        "source_type": Field(str, default="inferred"),
        "source_trace_id": Field(str, optional=True),
        "source_session_id": Field(str, optional=True),
        "context_snapshot": Field(dict, optional=True),
        "agent_id": Field(str, optional=True, indexed=True),
        "domain": Field(str, optional=True, indexed=True),
        "tags": Field(list[str]),
        "rejected_alternatives": Field(list[str]),
        "rationale": Field(str, optional=True),
        "constraints": Field(list[str]),
        "pending_requirements": Field(
            list,
            # list_of intentionally omitted: deserializer wins in _make_from_dict
            # (framework.py:284-285), and pending_requirements has no
            # carry_forward_on_supersede, so list_of would be dead code.
            serializer=_serialize_pending,
            deserializer=_deserialize_pending,
        ),
    },
    default_confidence=0.8,
    # Path C knob 1: Manager-path leaves MemoryItem.origin at default ("unknown");
    # Handler-path explicitly stamps "structured:decision".
    origin=_KEEP_DEFAULT_ORIGIN,
    handler_origin="structured:decision",
    lifecycle="extended",
    id_field="decision_id",
    id_prefix="dec",
    edge_fn=_decision_edges,
    first_class_fn=_decision_first_class,
    index_specs=[
        "CREATE INDEX IF NOT EXISTS idx_decision_status "
        "ON nodes(json_extract(properties, '$.status')) WHERE memory_type='decision'",
        "CREATE INDEX IF NOT EXISTS idx_decision_domain "
        "ON nodes(json_extract(properties, '$.domain')) WHERE memory_type='decision'",
        "CREATE INDEX IF NOT EXISTS idx_decision_type "
        "ON nodes(json_extract(properties, '$.decision_type')) WHERE memory_type='decision'",
        "CREATE INDEX IF NOT EXISTS idx_decision_agent_id "
        "ON nodes(json_extract(properties, '$.agent_id')) WHERE memory_type='decision'",
    ],
    describe_summary=(
        "Decision records — INDEXED, queryable by status/domain/decision_type. "
        "Discrete conclusions/inferences/choices with full provenance."
    ),
)


_DecisionBase, _DecisionHandlerBase, _DecisionManagerBase, _DecisionQueriesBase = (
    _DECISION_TYPE.derive()
)
