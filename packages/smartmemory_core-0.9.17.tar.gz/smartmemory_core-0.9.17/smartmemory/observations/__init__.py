"""ManagedType-derived Observation artifacts (CORE-EXPERTISE-1 Phase 3 T4)."""

from smartmemory.observations.declaration import (
    _ObservationBase as Observation,
    _ObservationHandlerBase as ObservationHandler,
    _ObservationManagerBase as ObservationManager,
    _ObservationQueriesBase as ObservationQueries,
)

__all__ = [
    "Observation",
    "ObservationHandler",
    "ObservationManager",
    "ObservationQueries",
]
