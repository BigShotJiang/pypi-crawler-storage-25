"""ManagedType declaration for the `observation` memory type.

Observations are synthesized entity summaries — coherent descriptions built
from multiple facts about an entity. Entity-keyed deterministic IDs let
producers idempotently update the same observation as new facts arrive.

See smart-memory-docs/docs/features/CORE-EXPERTISE-1/phase-3-backfill-managers/
plan.md (T4).
"""

from __future__ import annotations

import hashlib
from typing import Any

from smartmemory.managed import Field, ManagedType


def _sha12(s: str | None) -> str:
    return hashlib.sha256((s or "").encode("utf-8")).hexdigest()[:12]


def _observation_id_generator(fields: dict[str, Any]) -> str:
    entity_id = fields.get("entity_id") or ""
    return f"obs_{_sha12(entity_id)}"


def _completeness(inst) -> float:
    aspects = getattr(inst, "aspects_covered", None) or []
    return min(1.0, len(aspects) * 0.2)


def _observation_edges(data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
    """OBSERVES edge from observation node to entity_id (when present).

    Framework adds the edge unconditionally. The producer is responsible for
    ensuring the entity node exists upstream — this is consistent with how
    decisions, constraints, and learned items already declare cross-references.
    """
    entity_id = data.get("entity_id")
    if not entity_id:
        return []
    return [(item_id, entity_id, "OBSERVES", {})]


def _observation_first_class(instance) -> dict:
    return {"confidence": instance.confidence}


_OBSERVATION_TYPE = ManagedType(
    name="observation",
    fields={
        "entity_id": Field(str, indexed=True),
        "entity_name": Field(str, optional=True),
        "entity_type": Field(str, optional=True),
        "source_facts": Field(list),
        "aspects_covered": Field(list),
    },
    default_confidence=0.7,
    origin="user:observation",
    handler_origin="evolver:observation",
    lifecycle="extended",
    id_field="observation_id",
    id_generator=_observation_id_generator,
    edge_fn=_observation_edges,
    computed_properties={"completeness": _completeness},
    first_class_fn=_observation_first_class,
    describe_summary=(
        "Observation records — synthesized entity summaries; entity-keyed "
        "deterministic IDs; add_source() folds new facts into the same row."
    ),
)


_ObservationBase, _ObservationHandlerBase, _ObservationManagerBase, _ObservationQueriesBase = (
    _OBSERVATION_TYPE.derive()
)


# --- Custom add_source method bound onto the Manager class ------------------
# The framework Manager.create() shape isn't quite right for the legacy
# add_source(entity_id, fact_id, aspect) signature, so we attach a method.

def _add_source(self, entity_id: str, fact_id: str, aspect: str | None = None):
    """Idempotent fold: get-or-create observation by entity_id, append fact + aspect.

    Returns the (possibly updated) Observation instance.
    """
    obs_id = f"obs_{_sha12(entity_id)}"
    instance = self._hydrate(obs_id)
    if instance is None:
        # Create a minimal observation; content is the entity_id placeholder
        # (callers can edit later via update_properties).
        content = f"observation:{entity_id}"
        instance = self.create(content, entity_id=entity_id)
    elif not getattr(instance, "observation_id", None):
        # Backward-compat: legacy-persisted observations have item_id on the
        # MemoryItem but no observation_id in their metadata. Without this
        # restore, _update_instance issues update_properties("", ...) and
        # the graph lookup fails. Restore the id_field from the deterministic
        # entity-derived ID so the Manager can write through cleanly.
        instance.observation_id = obs_id

    facts = list(instance.source_facts or [])
    if fact_id and fact_id not in facts:
        facts.append(fact_id)
    instance.source_facts = facts

    aspects = list(instance.aspects_covered or [])
    if aspect and aspect not in aspects:
        aspects.append(aspect)
    instance.aspects_covered = aspects

    self._update_instance(instance)
    return instance


_ObservationManagerBase.add_source = _add_source
