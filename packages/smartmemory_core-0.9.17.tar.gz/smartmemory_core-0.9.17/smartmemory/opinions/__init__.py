"""ManagedType-derived Opinion artifacts (CORE-EXPERTISE-1 Phase 3 T3).

Re-exports the framework-derived Opinion dataclass + Handler + Manager + Queries.
The legacy `smartmemory.models.opinion.OpinionMetadata` (a richer in-memory
metadata holder used by the existing evolvers) is preserved for back-compat.
The migrations in T9-T10 route producers through OpinionManager instead.

T10 extends the framework Queries class with ``OpinionQueries.list_for_evolver``
(see ``opinions/queries.py``) — a classmethod that normalizes
``ctx.search(memory_type="opinion")`` rows into typed Opinion dataclasses.
"""

from smartmemory.opinions.declaration import (
    _OpinionBase as Opinion,
    _OpinionHandlerBase as OpinionHandler,
    _OpinionManagerBase as OpinionManager,
)
from smartmemory.opinions.queries import OpinionQueries

__all__ = ["Opinion", "OpinionHandler", "OpinionManager", "OpinionQueries"]
