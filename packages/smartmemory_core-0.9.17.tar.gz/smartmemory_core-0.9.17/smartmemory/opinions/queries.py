"""Evolver-facing read helpers for the `opinion` managed type.

Subclasses the framework-derived ``_OpinionQueriesBase`` to add a
``list_for_evolver`` classmethod that normalizes an ``EvolutionContext.search``
result set into typed ``Opinion`` instances.

Background (CORE-EXPERTISE-1 Phase 3 T10): the live-evolver path
(``opinion_reinforcement.evolve_incremental``) calls ``ctx.search(memory_type=...)``
which can return any of:

  - raw FalkorDB node dicts (top-level `subject`, `confidence`, `item_id`)
  - "MemoryItem-like" dicts (a `metadata` sub-dict carrying the typed fields)
  - actual ``MemoryItem`` instances

Pre-migration the evolver did dict-only field access with two-level fallbacks.
This helper centralizes the normalization so every evolver consumer sees
hydrated dataclasses and can rely on field access.
"""

from __future__ import annotations

import logging
from typing import Any

from smartmemory.opinions.declaration import _OpinionBase as Opinion
from smartmemory.opinions.declaration import _OpinionQueriesBase

logger = logging.getLogger(__name__)


class OpinionQueries(_OpinionQueriesBase):
    """Opinion read helper, extended with evolver-specific normalization."""

    @classmethod
    def list_for_evolver(cls, ctx: Any) -> list[Opinion]:
        """Return typed ``Opinion`` instances for evolver consumption.

        Normalizes ``ctx.search(memory_type="opinion")`` rows that may be raw
        node dicts, MemoryItem-like dicts, or MemoryItem objects. Rows that
        fail to hydrate (missing required fields, malformed metadata) are
        skipped with a warning rather than raised — the live-evolver path
        must remain resilient to a single bad row.

        The constructor is bypassed because we don't need ``self.memory`` or
        ``self.graph``; ``ctx`` carries everything.
        """
        try:
            rows = ctx.search(memory_type="opinion") or []
        except Exception as e:  # noqa: BLE001 — ctx may be a thin shim with arbitrary errors
            logger.warning("ctx.search(memory_type='opinion') failed: %s", e)
            return []

        out: list[Opinion] = []
        for row in rows:
            payload = _to_payload(row)
            if not payload:
                continue
            try:
                out.append(Opinion.from_dict(payload))  # type: ignore[attr-defined]
            except Exception as e:  # noqa: BLE001 — partial migration data may surface
                logger.debug("OpinionQueries.list_for_evolver: skipping unhydratable row: %s", e)
                continue
        return out


def _to_payload(row: Any) -> dict | None:
    """Coerce a heterogeneous row into a dict suitable for ``Opinion.from_dict``.

    First-class MemoryItem fields (``confidence``, ``content``) and ``item_id``
    are lifted to the top level on storage and may be missing from ``metadata``
    after a roundtrip — restore them from the row's top-level when absent.
    Pre-migration evolve_incremental explicitly preferred the top-level
    ``confidence`` over ``metadata.confidence``; preserving that here avoids
    silently falling back to the dataclass default 0.5 and overwriting the
    persisted value.
    """
    if isinstance(row, dict):
        meta = row.get("metadata")
        if isinstance(meta, dict) and meta:
            payload = dict(meta)
            if not payload.get("content"):
                payload["content"] = row.get("content") or payload.get("content") or ""
            if not payload.get("opinion_id"):
                payload["opinion_id"] = row.get("item_id") or row.get("opinion_id") or ""
            if payload.get("confidence") is None and row.get("confidence") is not None:
                payload["confidence"] = row["confidence"]
            return payload
        # Flat node dict — already has the typed fields at top level.
        payload = dict(row)
        if not payload.get("opinion_id") and payload.get("item_id"):
            payload["opinion_id"] = payload["item_id"]
        return payload

    # MemoryItem-shaped object
    meta = getattr(row, "metadata", None) or {}
    if not isinstance(meta, dict):
        return None
    payload = dict(meta)
    if not payload.get("content"):
        payload["content"] = getattr(row, "content", "") or ""
    if not payload.get("opinion_id"):
        payload["opinion_id"] = getattr(row, "item_id", "") or ""
    if payload.get("confidence") is None:
        top_conf = getattr(row, "confidence", None)
        if top_conf is not None:
            payload["confidence"] = top_conf
    return payload
