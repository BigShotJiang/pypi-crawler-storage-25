"""
Reasoning module for SmartMemory.

Provides:
- AssertionChallenger: Detect contradictions between new and existing facts
- Detection strategies: LLM, Graph, Embedding, Heuristic
- Resolution strategies: Wikipedia, LLM, Grounding, Recency
- ConfidenceManager: Confidence decay and history tracking

Phase 3 (CORE-EXPERTISE-1) additions — managed Reasoning type:
- Reasoning: framework-derived dataclass for persisted reasoning traces
- ReasoningHandler / ReasoningManager / ReasoningQueries: lifecycle classes
"""

from .models import (
    ChallengeResult,
    Conflict,
    ConflictType,
    DetectionMethod,
    ResolutionStrategy,
)
from .challenger import (
    AssertionChallenger,
    should_challenge,
    FACTUAL_PATTERNS,
    SKIP_PATTERNS,
    CHALLENGEABLE_MEMORY_TYPES,
)
from .declaration import (
    _ReasoningBase as Reasoning,
    _ReasoningHandlerBase as ReasoningHandler,
    _ReasoningManagerBase as ReasoningManager,
    _ReasoningQueriesBase as ReasoningQueries,
)

__all__ = [
    'AssertionChallenger',
    'ChallengeResult',
    'Conflict',
    'ConflictType',
    'ResolutionStrategy',
    'DetectionMethod',
    'should_challenge',
    'FACTUAL_PATTERNS',
    'SKIP_PATTERNS',
    'CHALLENGEABLE_MEMORY_TYPES',
    # Phase 3
    'Reasoning',
    'ReasoningHandler',
    'ReasoningManager',
    'ReasoningQueries',
]
