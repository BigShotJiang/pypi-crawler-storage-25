"""ManagedType declaration for the `reasoning` memory type (Phase 3 T5).

Reasoning traces are chain-of-thought captures with steps, task context, and
quality evaluation. Stored as INDEXED with deterministic IDs so producers can
upsert. The Manager exposes a custom `create_trace(trace, source_item_id, ...)`
method that enforces the quality gate from `ReasoningEvaluation.should_store`.

Coexists with legacy `smartmemory.models.reasoning.ReasoningTrace`: the legacy
class produces the input `trace` for create_trace; the managed dataclass holds
the persisted shape.
"""

from __future__ import annotations

import json
from typing import Any

from smartmemory.managed import Field, ManagedType
from smartmemory.managed.exceptions import QualityGateRejected
from smartmemory.models.reasoning import (
    ReasoningEvaluation,
    ReasoningStep,
    ReasoningTrace,
    TaskContext,
)


# --- Per-field serializers/deserializers (Pattern 3) -----------------------


def _serialize_steps(lst):
    if not lst:
        return []
    return [s.to_dict() if hasattr(s, "to_dict") else s for s in lst]


def _deserialize_steps(raw):
    if raw is None:
        return []
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return []
    if not isinstance(raw, list):
        return []
    return [ReasoningStep.from_dict(r) if isinstance(r, dict) else r for r in raw]


def _serialize_task_context(tc):
    if tc is None:
        return None
    if isinstance(tc, dict):
        return tc
    return tc.to_dict()


def _deserialize_task_context(raw):
    if raw is None:
        return None
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return None
    if isinstance(raw, dict):
        return TaskContext.from_dict(raw)
    return raw


def _serialize_evaluation(ev):
    if ev is None:
        return None
    if isinstance(ev, dict):
        return ev
    return ev.to_dict()


def _deserialize_evaluation(raw):
    if raw is None:
        return None
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return None
    if isinstance(raw, dict):
        return ReasoningEvaluation.from_dict(raw)
    return raw


# --- Helpers ---------------------------------------------------------------


def _content_from_trace(trace: ReasoningTrace) -> str:
    """Assemble searchable content from goal + steps. Mirrors legacy
    ReasoningTrace.content for parity in vector embeddings."""
    parts: list[str] = []
    if trace.task_context and trace.task_context.goal:
        parts.append(f"Goal: {trace.task_context.goal}")
    if trace.task_context and trace.task_context.input:
        parts.append(f"Input: {trace.task_context.input[:200]}")
    for step in trace.steps:
        parts.append(f"{str(step.type).capitalize()}: {step.content}")
    return "\n".join(parts)


def _reasoning_id_generator(fields: dict[str, Any]) -> str:
    """Use the trace_id field as the persistent ID (callers supply via create_trace).

    When trace_id is empty, fall back to a uuid-based ID so framework still gets
    a non-empty value. (`create_trace` always supplies a trace_id, so the
    fallback only fires for direct framework callers.)
    """
    import uuid as _uuid

    tid = fields.get("trace_id")
    if tid:
        return tid
    return f"rea_{_uuid.uuid4().hex[:12]}"


def _reasoning_edges(data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
    """PRODUCED edge: reasoning_trace -> source_item_id.

    Direction matches the codebase's canonical PRODUCED convention:
    schema_validator.py:591 (source={reasoning}, target={decision, semantic, ...}),
    decisions/declaration.py:80 (reasoning -> decision), and consumers like
    decisions/queries.py:125 which read PRODUCED as incoming-to-the-artifact.

    Codex-corrected twice:
      - T5: edge_fn signature is (data: dict, item_id: str), not (instance)
      - T12: direction was reversed (was `(src, item_id, ...)` — only T13 had
        shipped using this edge_fn, and T13 doesn't pass source_item_id, so
        the wrong direction never made it onto the graph until T12 became the
        first real caller)
    """
    src = data.get("source_item_id")
    if not src:
        return []
    return [(item_id, src, "PRODUCED", {})]


def _reasoning_first_class(instance) -> dict:
    return {"confidence": instance.confidence}


# --- ManagedType declaration -----------------------------------------------


_REASONING_TYPE = ManagedType(
    name="reasoning",
    fields={
        "trace_id": Field(str, indexed=True),
        "source_item_id": Field(str, optional=True, indexed=True),
        "session_id": Field(str, optional=True),
        "has_explicit_markup": Field(bool, default=False),
        "artifact_ids": Field(list),
        "steps": Field(
            list,
            serializer=_serialize_steps,
            deserializer=_deserialize_steps,
        ),
        "task_context": Field(
            TaskContext,
            optional=True,
            serializer=_serialize_task_context,
            deserializer=_deserialize_task_context,
        ),
        "evaluation": Field(
            ReasoningEvaluation,
            optional=True,
            serializer=_serialize_evaluation,
            deserializer=_deserialize_evaluation,
        ),
    },
    default_confidence=0.7,
    origin="user:reasoning",
    handler_origin="evolver:reasoning",
    lifecycle="standard",
    id_field="reasoning_id",
    id_generator=_reasoning_id_generator,
    edge_fn=_reasoning_edges,
    first_class_fn=_reasoning_first_class,
    describe_summary=(
        "Reasoning trace records — chain-of-thought captures with steps + task context + quality evaluation."
    ),
)


_ReasoningBase, _ReasoningHandlerBase, _ReasoningManagerBase, _ReasoningQueriesBase = _REASONING_TYPE.derive()


# --- Custom Manager method: create_trace -----------------------------------


def _create_trace(
    self,
    trace: ReasoningTrace,
    source_item_id: str | None = None,
    origin: str | None = None,
    bypass: bool = False,
):
    """Persist a ReasoningTrace, enforcing the quality gate by default.

    Args:
        trace: The ReasoningTrace to persist
        source_item_id: Optional ID of the memory item that produced this reasoning
        origin: Override the default origin (e.g., "pipeline:reasoning_extract")
        bypass: If True, skip the quality gate (default False)

    Raises:
        QualityGateRejected: When evaluation.should_store is False and bypass=False.
    """
    if not bypass and trace.evaluation is not None and not trace.evaluation.should_store:
        reasons = []
        if trace.evaluation.quality_score < 0.4:
            reasons.append(f"quality_score {trace.evaluation.quality_score:.2f} < 0.4")
        for issue in trace.evaluation.issues:
            if issue.get("severity") == "high":
                reasons.append(issue.get("description", "high-severity issue"))
        raise QualityGateRejected(trace_id=trace.trace_id, reasons=reasons or ["evaluation rejected"])

    fields = {
        "trace_id": trace.trace_id,
        "source_item_id": source_item_id or "",
        "session_id": trace.session_id or "",
        "has_explicit_markup": trace.has_explicit_markup,
        "artifact_ids": list(trace.artifact_ids or []),
        "steps": list(trace.steps or []),
        "task_context": trace.task_context,
        "evaluation": trace.evaluation,
    }
    content = _content_from_trace(trace)
    # Phase 3 Knob D: origin override threads through the framework so the
    # configured value lands on the persisted node, not just on an in-memory
    # MemoryItem the caller would never see.
    instance = self.create(content, origin=origin, **fields)
    return instance


_ReasoningManagerBase.create_trace = _create_trace
