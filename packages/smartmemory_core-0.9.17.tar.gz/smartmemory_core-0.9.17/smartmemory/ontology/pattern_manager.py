"""PatternManager — hot-reloadable dictionary of learned entity patterns.

Design: dictionary scan (O(n) in text length), not spaCy EntityRuler pipe rebuild.
Patterns are stored as EntityPattern nodes in the ontology graph and cached in-memory
as a dict[str, str] of name.lower() → entity_type.
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING, Dict, NamedTuple, Protocol, runtime_checkable

from smartmemory.observability.tracing import trace_span
from smartmemory.ontology.blocklist import COMMON_WORD_BLOCKLIST
from smartmemory.utils.pattern_precedence import pattern_precedence

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class PatternRow(NamedTuple):
    """SELF-IMPROVE-9 S0M: widened load() row carrying provenance metadata.

    NamedTuple so legacy 2-tuple consumers that did ``for name, label in rows``
    still need updating (4 fields won't unpack to 2) — _build_patterns is the
    only in-tree consumer and is updated alongside. External PatternStore
    implementations (e.g. wrapper-repo JSONLPatternStore) may still yield bare
    ``(name, label)`` tuples during migration; _build_patterns tolerates both.
    """

    name: str
    label: str
    source: str
    confidence: float


class PatternMeta(NamedTuple):
    """Parallel cache value: provenance kept beside the frozen name→label dict."""

    source: str
    confidence: float


class ConflictEntry(NamedTuple):
    """SELF-IMPROVE-9C: a durable incumbent visible to conflict arbitration
    but possibly below the ``count >= 2`` ruler-surfacing gate (so absent
    from ``_patterns``). Carries the label so ``add_patterns`` can detect a
    cross-label collision before it writes a competing dual row."""

    label: str
    source: str
    confidence: float


@runtime_checkable
class PatternStore(Protocol):
    """Persistence backend for EntityRuler patterns.

    PatternManager is responsible for in-memory caching, quality gating
    (blocklist + length filter), and thread safety. The store handles
    durable I/O only.
    """

    def load(self, workspace_id: str) -> list[PatternRow]:
        """Return PatternRow(name, label, source, confidence) for patterns past
        the quality threshold (SELF-IMPROVE-9 S0M — widened from (name,label)).

        Implementations apply their own threshold internally (FalkorDB: count >= 2
        in Cypher; JSONL: frequency >= 2 filter on read). Returns only patterns
        ready for the EntityRuler — PatternManager does not re-filter.

        Migration tolerance: implementations not yet updated may still yield bare
        ``(name, label)`` 2-tuples; PatternManager._build_patterns accepts both
        and WARNs once on the legacy shape (no silent degradation).
        """
        ...

    # SELF-IMPROVE-9C: ``load_conflict_map(workspace_id) -> list[PatternRow]``
    # is an OPTIONAL capability, deliberately NOT a required Protocol member.
    # Adding it here would make this @runtime_checkable Protocol reject every
    # store that predates 9C (legacy/JSONL/in-memory) — contradicting the
    # documented degrade path and breaking isinstance(...) for them.
    # PatternManager probes ``hasattr(store, "load_conflict_map")`` and falls
    # back to :meth:`load` with a WARNING when absent (never silent).
    # Concrete implementation lives on FalkorDBPatternStore.

    def save(
        self,
        name: str,
        label: str,
        confidence: float,
        count: int,
        workspace_id: str,
        source: str = "unknown",
    ) -> bool:
        """Persist a pattern. count = initial occurrence count.

        Use count=2 to immediately pass the quality threshold on next load().
        source is a provenance tag stored on CREATE only — not overwritten on
        update (preserves original discovery context, matching FalkorDB semantics).

        Returns True on success, False on a handled failure (SELF-IMPROVE-9
        Codex R2/#2 — the durable conflict swap must observe save success
        before deleting the losing row).
        """
        ...

    def delete(self, name: str, label: str, workspace_id: str) -> bool:
        """Remove a pattern by name and label. Returns True on success,
        False on a handled failure (surfaced by the caller, never silent)."""
        ...


class PatternManager:
    """Manage learned entity patterns with hot-reload via Redis pub/sub.

    Usage::

        store = FalkorDBPatternStore(ontology_graph)
        pm = PatternManager(store, workspace_id="acme")
        patterns = pm.get_patterns()  # {"python": "Technology", "react": "Technology"}

    EntityRulerStage scans tokens against this dict after running spaCy NER.
    """

    RELOAD_CHANNEL_PREFIX = "smartmemory:patterns:reload"

    def __init__(
        self,
        store: PatternStore,
        workspace_id: str = "default",
        redis_client=None,
    ):
        self._store = store
        self._workspace_id = workspace_id
        self._redis = redis_client
        self._patterns: Dict[str, str] = {}
        self._meta: Dict[str, PatternMeta] = {}  # S0M: provenance beside frozen name→label
        # SELF-IMPROVE-9C: unfiltered incumbent view for cross-label
        # arbitration — includes below-gate (count=1) durable rows that
        # _patterns cannot see.
        self._conflict: Dict[str, ConflictEntry] = {}
        self._version = 0
        self._lock = threading.Lock()
        self._subscriber_thread: threading.Thread | None = None

        # Initial load
        self._build_patterns()

        # Start subscriber if Redis is available
        if self._redis is not None:
            self._subscribe_for_reload()

    def get_patterns(self) -> Dict[str, str]:
        """Return cached name→type dict."""
        with self._lock:
            return dict(self._patterns)

    def add_patterns(self, patterns: Dict[str, str], *, source: str = "code_index", initial_count: int = 1) -> int:
        """Merge additional name→type patterns into the in-memory cache.

        Filters short names and common word blocklist entries before accepting.
        Persists accepted patterns to the ontology graph (best-effort) so they
        survive restarts.

        Args:
            patterns: Mapping of entity name to entity type label.
            source: Provenance tag stored on the EntityPattern node.
            initial_count: Starting count for new patterns. Use 2 for AST-validated
                code patterns to bypass the ``count >= 2`` discovery threshold.

        Returns:
            Number of net-new patterns accepted (duplicates excluded).
        """
        accepted = 0
        incoming_conf = 0.9  # add_patterns persists at this confidence
        for name, label in patterns.items():
            if not name or not label:
                continue
            key = name.lower().strip()
            if key in COMMON_WORD_BLOCKLIST or len(key) < 2:
                continue
            persist = False
            superseded_label: str | None = None  # old durable row to delete on win
            conflict: tuple[str, str, str] | None = None  # (existing, cached_src, winner)
            # Codex R3/#2: remember pre-mutation state so a persist failure
            # can roll the in-memory cache back — otherwise memory and durable
            # state diverge forever (the existing==label fast path means no
            # future call ever retries).
            rb_was_new = False
            rb_prev_label: str | None = None
            rb_prev_meta: PatternMeta | None = None
            rb_prev_conflict: ConflictEntry | None = None  # 9C: revert _conflict on save fail
            rb_conflict_touched = False
            with self._lock:
                existing = self._patterns.get(key)
                if existing is None:
                    # SELF-IMPROVE-9C: a durable incumbent may exist below the
                    # count>=2 ruler gate (absent from _patterns, present in
                    # _conflict). Arbitrate BEFORE writing, else a competing
                    # different-label row forms and flips on reload.
                    incumbent = self._conflict.get(key)
                    if incumbent is not None and incumbent.label != label:
                        inc_prec = pattern_precedence(source)
                        cached_prec = pattern_precedence(incumbent.source)
                        incoming_wins = inc_prec > cached_prec or (
                            inc_prec == cached_prec and incoming_conf > incumbent.confidence
                        )
                        if incoming_wins:
                            rb_prev_conflict = incumbent
                            rb_conflict_touched = True
                            self._patterns[key] = label
                            self._meta[key] = PatternMeta(source=source, confidence=incoming_conf)
                            self._conflict[key] = ConflictEntry(label, source, incoming_conf)
                            self._version += 1
                            accepted += 1
                            persist = True
                            rb_was_new = True
                            # Delete the losing durable row + persist winner at
                            # count>=2 so it clears the discovery gate (reuses
                            # the save-first/delete-loser path below).
                            superseded_label = incumbent.label
                            winner_label = label
                        else:
                            winner_label = incumbent.label  # incumbent wins; NO competing row
                        conflict = (incumbent.label, incumbent.source, winner_label)
                    else:
                        # Net-new, or a below-gate same-label reinforcement
                        # (persist's ON MATCH increments count → helps it
                        # cross the gate). Either way: accept + persist.
                        self._patterns[key] = label
                        self._meta[key] = PatternMeta(source=source, confidence=incoming_conf)
                        self._version += 1
                        accepted += 1
                        persist = True
                        rb_was_new = True
                elif existing == label:
                    continue  # true duplicate — idempotent, no persistence
                else:
                    # SELF-IMPROVE-9 S02: type conflict — resolve by the shared
                    # precedence rule instead of the old type-blind silent skip
                    # (no-silent-degradation: never drop a conflicting label
                    # without a signal).
                    cached_meta = self._meta.get(key)
                    cached_src = cached_meta.source if cached_meta else "unknown"
                    cached_conf = cached_meta.confidence if cached_meta else 0.0
                    inc_prec = pattern_precedence(source)
                    cached_prec = pattern_precedence(cached_src)
                    incoming_wins = inc_prec > cached_prec or (inc_prec == cached_prec and incoming_conf > cached_conf)
                    if incoming_wins:
                        rb_prev_label = existing
                        rb_prev_meta = cached_meta
                        self._patterns[key] = label
                        self._meta[key] = PatternMeta(source=source, confidence=incoming_conf)
                        self._version += 1
                        accepted += 1
                        persist = True
                        winner_label = label
                        # Codex R1/#1: the old (name, old_label) node must be
                        # deleted durably, else get_entity_patterns() returns
                        # BOTH rows and _build_patterns() (no ORDER BY) can
                        # flip the winner back nondeterministically on reload.
                        superseded_label = existing
                    else:
                        winner_label = existing  # incumbent wins (incl. equal-precedence tie)
                    conflict = (existing, cached_src, winner_label)
            # WARNING + metric outside the lock (no I/O under lock).
            if conflict is not None:
                existing_label, cached_src, winner_label = conflict
                logger.warning(
                    "Pattern conflict %r: %s(%s) vs %s(%s) → %s",
                    key,
                    existing_label,
                    cached_src,
                    label,
                    source,
                    winner_label,
                )
                with trace_span(
                    "pattern.conflict",
                    {
                        "key": key,
                        "existing_label": existing_label,
                        "existing_source": cached_src,
                        "incoming_label": label,
                        "incoming_source": source,
                        "winner_label": winner_label,
                    },
                ):
                    pass
            if persist:
                save_failed = False
                try:
                    # Codex R2/#2: save-first, then delete-the-loser only if
                    # the save actually succeeded. The winner of a conflict
                    # against an established (visible) pattern must clear the
                    # count>=2 discovery gate.
                    persist_count = max(initial_count, 2) if superseded_label else initial_count
                    saved = self._store.save(
                        name=key,
                        label=label,
                        confidence=incoming_conf,
                        count=persist_count,
                        workspace_id=self._workspace_id,
                        source=source,
                    )
                    if saved is False:
                        save_failed = True
                    elif superseded_label is not None:
                        removed = self._store.delete(
                            name=key,
                            label=superseded_label,
                            workspace_id=self._workspace_id,
                        )
                        if removed is False:
                            logger.warning(
                                "Pattern %r: superseded row %r not removed; transient dual row until next reconcile",
                                key,
                                superseded_label,
                            )
                except Exception as exc:
                    save_failed = True
                    logger.warning("Failed to persist pattern '%s': %s", key, exc)

                if save_failed:
                    # Codex R3/#2: the winner save did not land. Roll the
                    # in-memory cache back so memory == durable — otherwise
                    # the existing==label fast path means no future call ever
                    # retries and the intended winner is lost on reload.
                    with self._lock:
                        if rb_was_new:
                            if self._patterns.get(key) == label:
                                self._patterns.pop(key, None)
                                self._meta.pop(key, None)
                        elif rb_prev_label is not None and self._patterns.get(key) == label:
                            self._patterns[key] = rb_prev_label
                            if rb_prev_meta is not None:
                                self._meta[key] = rb_prev_meta
                            else:
                                self._meta.pop(key, None)
                        # 9C: a below-gate-incumbent win mutated _conflict;
                        # restore it so the next call re-arbitrates instead
                        # of treating the failed winner as the incumbent.
                        if rb_conflict_touched and rb_prev_conflict is not None:
                            self._conflict[key] = rb_prev_conflict
                        self._version += 1
                    accepted = max(0, accepted - 1)
                    logger.warning(
                        "Pattern %r: winner save failed; reverted in-memory to "
                        "stay consistent with durable state (will retry next call)",
                        key,
                    )
        return accepted

    def _build_patterns(self) -> None:
        """Reload patterns + provenance from the backing store (S0M).

        Builds the frozen name→label cache AND the parallel _meta cache so
        source/confidence survive reload (Codex R2/C6). Tolerates stores that
        still yield legacy (name, label) 2-tuples — WARNs once, meta defaults.
        """
        try:
            raw = self._store.load(self._workspace_id)
            new_patterns: Dict[str, str] = {}
            new_meta: Dict[str, PatternMeta] = {}
            legacy_warned = False
            for row in raw:
                if isinstance(row, PatternRow) or len(row) == 4:
                    name, label, source, confidence = row
                else:  # legacy (name, label) — external store not yet migrated
                    name, label = row
                    source, confidence = "unknown", 0.0
                    if not legacy_warned:
                        logger.warning(
                            "PatternStore.load returned legacy 2-tuples for workspace '%s'; "
                            "source/confidence unavailable until the store is migrated to "
                            "PatternRow (SELF-IMPROVE-9 S0M)",
                            self._workspace_id,
                        )
                        legacy_warned = True
                key = name.lower().strip()
                if not key or not label:
                    continue
                if key in COMMON_WORD_BLOCKLIST:
                    continue
                if len(key) < 2:
                    continue
                new_patterns[key] = label
                new_meta[key] = PatternMeta(source=source, confidence=float(confidence))

            # SELF-IMPROVE-9C: unfiltered incumbent view for arbitration.
            # Degrade (never silent): stores without load_conflict_map
            # (legacy/JSONL/in-memory) reuse the gated rows — below-gate
            # incumbents stay invisible there, but the limitation is logged.
            new_conflict: Dict[str, ConflictEntry] = {}
            if hasattr(self._store, "load_conflict_map"):
                conflict_rows = self._store.load_conflict_map(self._workspace_id)
            else:
                conflict_rows = raw
                logger.warning(
                    "PatternStore for workspace '%s' has no load_conflict_map; "
                    "cross-label arbitration falls back to the count>=2 gated "
                    "view — below-threshold incumbents will be invisible "
                    "(SELF-IMPROVE-9C)",
                    self._workspace_id,
                )
            for row in conflict_rows:
                if isinstance(row, PatternRow) or len(row) == 4:
                    cname, clabel, csource, cconf = row
                else:  # legacy (name, label)
                    cname, clabel = row
                    csource, cconf = "unknown", 0.0
                ckey = cname.lower().strip()
                if not ckey or not clabel:
                    continue
                if ckey in COMMON_WORD_BLOCKLIST or len(ckey) < 2:
                    continue
                new_conflict[ckey] = ConflictEntry(label=clabel, source=csource, confidence=float(cconf))

            with self._lock:
                self._patterns = new_patterns
                self._meta = new_meta
                self._conflict = new_conflict
                self._version += 1
            logger.debug("Loaded %d entity patterns for workspace '%s'", len(new_patterns), self._workspace_id)
        except Exception as e:
            logger.warning("Failed to build entity patterns: %s", e)

    def reload(self) -> None:
        """Force reload patterns from graph."""
        self._build_patterns()

    def notify_reload(self, workspace_id: str | None = None) -> None:
        """Publish reload notification via Redis pub/sub."""
        if self._redis is None:
            return
        ws = workspace_id or self._workspace_id
        channel = f"{self.RELOAD_CHANNEL_PREFIX}:{ws}"
        try:
            self._redis.publish(channel, "reload")
        except Exception as e:
            logger.debug("Failed to publish reload notification: %s", e)

    def _subscribe_for_reload(self) -> None:
        """Background thread subscribing to reload channel."""
        channel = f"{self.RELOAD_CHANNEL_PREFIX}:{self._workspace_id}"

        def _listener():
            try:
                pubsub = self._redis.pubsub()
                pubsub.subscribe(channel)
                for message in pubsub.listen():
                    if message.get("type") == "message":
                        self._build_patterns()
            except Exception as e:
                logger.debug("Pattern reload subscriber stopped: %s", e)

        self._subscriber_thread = threading.Thread(target=_listener, daemon=True, name="pattern-reload")
        self._subscriber_thread.start()

    @property
    def version(self) -> int:
        """Current pattern version (incremented on each reload)."""
        return self._version

    @property
    def pattern_count(self) -> int:
        """Number of active patterns."""
        with self._lock:
            return len(self._patterns)
