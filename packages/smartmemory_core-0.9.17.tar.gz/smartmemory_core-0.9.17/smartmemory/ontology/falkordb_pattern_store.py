"""FalkorDB-backed PatternStore — thin adapter over OntologyGraph."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from smartmemory.ontology.pattern_manager import PatternRow

if TYPE_CHECKING:
    from smartmemory.graph.ontology_graph import OntologyGraph

logger = logging.getLogger(__name__)


class FalkorDBPatternStore:
    """PatternStore backed by FalkorDB EntityPattern nodes via OntologyGraph.

    Delegates all persistence to OntologyGraph methods — no new Cypher here.
    The count >= 2 quality threshold is applied inside OntologyGraph.get_entity_patterns()
    Cypher; this store does not re-filter.
    """

    def __init__(self, ontology_graph: OntologyGraph) -> None:
        self._ontology = ontology_graph

    def load(self, workspace_id: str) -> list[PatternRow]:
        """Load quality-filtered patterns from FalkorDB (SELF-IMPROVE-9 S0M).

        OntologyGraph.get_entity_patterns() already returns List[Dict] with
        name/label/confidence/source and applies count >= 2 in Cypher. Previously
        this adapter dropped confidence/source (Codex R2/C6); now it forwards
        them as PatternRow so PatternManager._meta survives reload.
        """
        try:
            raw = self._ontology.get_entity_patterns(workspace_id)
            return [
                PatternRow(
                    name=p["name"],
                    label=p["label"],
                    source=p.get("source") or "unknown",
                    confidence=float(p.get("confidence") or 0.0),
                )
                for p in raw
                if p.get("name") and p.get("label")
            ]
        except Exception as exc:
            logger.warning("FalkorDBPatternStore.load failed for workspace '%s': %s", workspace_id, exc)
            return []

    def load_conflict_map(self, workspace_id: str) -> list[PatternRow]:
        """Unfiltered patterns for conflict arbitration (SELF-IMPROVE-9C).

        Mirrors :meth:`load` row-shaping but calls
        ``OntologyGraph.get_entity_patterns_for_conflict_map`` (no
        ``count >= 2`` gate) so PatternManager precedence sees
        below-threshold incumbents.
        """
        try:
            raw = self._ontology.get_entity_patterns_for_conflict_map(workspace_id)
            return [
                PatternRow(
                    name=p["name"],
                    label=p["label"],
                    source=p.get("source") or "unknown",
                    confidence=float(p.get("confidence") or 0.0),
                )
                for p in raw
                if p.get("name") and p.get("label")
            ]
        except Exception as exc:
            logger.warning("FalkorDBPatternStore.load_conflict_map failed for workspace '%s': %s", workspace_id, exc)
            return []

    def save(
        self,
        name: str,
        label: str,
        confidence: float,
        count: int,
        workspace_id: str,
        source: str = "unknown",
    ) -> bool:
        """Persist pattern via OntologyGraph._upsert_inline_ontology_pattern().

        ONTO-PATTERN-MIGRATE-1 (2026-05-04): rewired from add_entity_pattern()
        to the unified primitive that writes dual-labelled
        :EntityType:OntologyType parent. source is forwarded to p.source for
        provenance/stats queries; the primitive preserves original source on
        MATCH (write-once provenance).
        """
        try:
            ok = self._ontology._upsert_inline_ontology_pattern(
                name=name,
                label=label,
                confidence=confidence,
                workspace_id=workspace_id,
                source=source,
                initial_count=count,
            )
            return bool(ok)
        except Exception as exc:
            logger.warning("FalkorDBPatternStore.save failed for '%s': %s", name, exc)
            return False

    def delete(self, name: str, label: str, workspace_id: str) -> bool:
        """Remove pattern via OntologyGraph.delete_entity_pattern()."""
        try:
            ok = self._ontology.delete_entity_pattern(name=name, label=label, workspace_id=workspace_id)
            return bool(ok)
        except Exception as exc:
            logger.warning("FalkorDBPatternStore.delete failed for '%s': %s", name, exc)
            return False
