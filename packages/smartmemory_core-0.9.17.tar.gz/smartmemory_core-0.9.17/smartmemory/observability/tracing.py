"""Unified observability via trace_span() -- single API for all event emission."""

import logging
import os
import threading
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from time import perf_counter
from typing import Any, Dict, Generator, Optional

logger = logging.getLogger(__name__)


@dataclass
class SpanContext:
    """Context for a single traced span."""

    trace_id: str = ""
    span_id: str = ""
    parent_span_id: Optional[str] = None
    name: str = ""
    start_time: float = 0.0
    attributes: Dict[str, Any] = field(default_factory=dict)

    def emit_event(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        """Emit a point-in-time span event attached to this span.

        Unlike trace_span(), records an instantaneous occurrence with no duration.
        Inherits trace_id from this span; uses this span's span_id as parent reference.

        Args:
            name: Event name in dot notation (e.g., "graph.add_node").
            attributes: Key-value payload for the event.
        """
        # No-op when observability is disabled AND no in-process sink is active.
        # When _current_sink is set (lite mode), we must proceed so graph mutation
        # events reach the WebSocket broadcaster even with observability=False.
        from smartmemory.observability.events import _current_sink

        if not self.trace_id and _current_sink.get() is None:
            return
        resolved_component = name.split(".")[0] if name else "unknown"
        operation = name.split(".", 1)[1] if "." in name else name
        event_data = {
            **(attributes or {}),
            "event_type": "span_event",
            "component": resolved_component,
            "operation": operation,
            "name": name,
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id,
        }
        try:
            _emit_span(event_data)
        except Exception:
            pass


_current_span: ContextVar[Optional[SpanContext]] = ContextVar("_current_span", default=None)

# CORE-DI-1: per-call observability override (None = use env var fallback)
_observability_ctx: ContextVar[Optional[bool]] = ContextVar("_observability_ctx", default=None)


def _is_enabled() -> bool:
    """Read observability toggle from env at call time.

    Per-instance override (CORE-DI-1): if _observability_ctx is set by
    SmartMemory._di_context(), it takes priority over the env var.
    Default: enabled. Set SMARTMEMORY_OBSERVABILITY=false to disable globally.
    """
    ctx = _observability_ctx.get()
    if ctx is not None:
        return ctx
    return os.environ.get("SMARTMEMORY_OBSERVABILITY", "true").strip().lower() not in (
        "false",
        "0",
        "no",
        "off",
    )


_spooler = None
_spooler_lock = threading.Lock()
_SPOOLER_FAILED = object()  # Sentinel: distinguishes "never tried" from "tried and failed"


def _get_spooler():
    global _spooler
    if _spooler is _SPOOLER_FAILED:
        return None
    if _spooler is not None:
        return _spooler
    with _spooler_lock:
        if _spooler is _SPOOLER_FAILED:
            return None
        if _spooler is not None:
            return _spooler
        try:
            from smartmemory.observability.events import EventSpooler

            _spooler = EventSpooler()
            return _spooler
        except Exception as e:
            logger.debug(f"Could not create EventSpooler: {e}")
            _spooler = _SPOOLER_FAILED
            return None


def _emit_span(event_data: dict) -> None:
    # DIST-LITE-3: dispatch to in-process sink when one is active (lite mode).
    # This path is sink-only — the Redis spooler is never reached when a sink is set.
    from smartmemory.observability.events import _current_sink

    sink = _current_sink.get()
    if sink is not None:
        sink.emit(event_data.get("event_type", "span"), event_data)
        return

    # PLAT-PROGRESS-1: When a progress context is active (run_id + scope bound by
    # ingest entry), route pipeline.* spans to progress.emit() on the workspace stream.
    # This replaces the retired smartmemory:events XADD path for pipeline telemetry.
    try:
        from smartmemory.progress import _run_id as _p_run_id
        from smartmemory.progress import _scope as _p_scope
        from smartmemory.progress import emit as progress_emit
        from smartmemory.progress import ProgressContextError

        _run_id_val = _p_run_id.get()
        _scope_val = _p_scope.get()

        if _run_id_val is not None and _scope_val is not None:
            # We are inside an ingest() with progress context bound.
            span_name = event_data.get("name", "")
            # Only route spans with a pipeline.* kind — other spans (graph, search, etc.)
            # are not pipeline stage boundaries.
            if span_name.startswith("pipeline."):
                stage_name = span_name[len("pipeline."):]  # "classify", "store", etc.
                status = event_data.get("status", "ok")
                duration_ms = event_data.get("duration_ms")
                start_epoch: float = event_data.get("_span_start_epoch") or event_data.get("_span_end_epoch") or __import__("time").time()
                end_epoch: float = event_data.get("_span_end_epoch") or __import__("time").time()
                # INSIGHTS-PROGRESS-MIGRATE-1 Phase 0: include full span ancestry
                # in payload so trace consumers (Insights /Traces) can reconstruct
                # the parent/child tree without depending on top-level Stream fields.
                span_id_val = event_data.get("span_id")
                parent_span_id_val = event_data.get("parent_span_id")
                span_name_val = event_data.get("name")
                terminal_payload: dict = {
                    "original_ts": end_epoch,
                    "trace_id": event_data.get("trace_id"),
                    "span_id": span_id_val,
                    "parent_span_id": parent_span_id_val,
                    "name": span_name_val,
                }
                if duration_ms is not None:
                    terminal_payload["duration_ms"] = duration_ms
                if status == "error":
                    error_str = event_data.get("error", "")
                    terminal_payload["error"] = {"type": "Exception", "message": str(error_str)}
                # Emit paired started + terminal events. Both carry span_id so
                # consumers can correlate the pair without timestamp matching.
                try:
                    progress_emit(
                        kind="pipeline.stage",
                        status="started",
                        stage=stage_name,
                        payload={
                            "original_ts": start_epoch,
                            "span_id": span_id_val,
                            "parent_span_id": parent_span_id_val,
                            "name": span_name_val,
                            "trace_id": event_data.get("trace_id"),
                        },
                        _ts=start_epoch,
                    )
                    terminal_payload["original_ts"] = end_epoch
                    progress_emit(
                        kind="pipeline.stage",
                        status=status if status in {"ok", "warn", "error"} else "ok",
                        stage=stage_name,
                        payload=terminal_payload,
                        _ts=end_epoch,
                    )
                except ProgressContextError:
                    # Context was unbound between our check and the emit (race condition
                    # in finally cleanup) — log and skip, never raise.
                    logger.debug(
                        "PLAT-PROGRESS-1: progress context unbound during _emit_span for %s",
                        span_name,
                    )
                return
    except ImportError:
        pass  # progress module not yet available (bootstrap edge case)
    except Exception as exc:
        logger.debug("PLAT-PROGRESS-1: _emit_span progress routing failed: %s", exc)

    # Legacy path: spooler writes to smartmemory:events.
    # PLAT-PROGRESS-1 migration: this path is only reached for non-pipeline spans
    # (graph mutations, search, etc.) and for spans emitted outside an ingest context.
    spooler = _get_spooler()
    if spooler is None:
        return
    try:
        spooler.emit_event(
            event_type=event_data.get("event_type", "span"),
            component=event_data.get("component", "unknown"),
            operation=event_data.get("operation", event_data.get("name", "unknown")),
            data=event_data,
            # CORE-OBS-2: promote trace fields to top-level Stream fields
            name=event_data.get("name"),
            trace_id=event_data.get("trace_id"),
            span_id=event_data.get("span_id"),
            parent_span_id=event_data.get("parent_span_id"),
            duration_ms=event_data.get("duration_ms"),
        )
    except Exception as e:
        logger.debug(f"Failed to emit span: {e}")


@contextmanager
def trace_span(
    name: str,
    attributes: Optional[Dict[str, Any]] = None,
    component: Optional[str] = None,
) -> Generator[SpanContext, None, None]:
    """Create a traced span with automatic parent-child nesting.

    Args:
        name: Span name using dot notation (e.g., "pipeline.classify").
              First segment used as component if component not specified.
        attributes: Key-value pairs attached to the span event.
        component: Override component name (default: derived from name).

    Yields:
        SpanContext with mutable attributes dict. Add attributes during
        the span and they will be included in the emitted event.
    """
    if not _is_enabled():
        yield SpanContext()
        return

    parent = _current_span.get()
    trace_id = parent.trace_id if parent else uuid.uuid4().hex[:16]
    span_id = uuid.uuid4().hex[:12]
    parent_span_id = parent.span_id if parent else None

    span = SpanContext(
        trace_id=trace_id,
        span_id=span_id,
        parent_span_id=parent_span_id,
        name=name,
        start_time=perf_counter(),
        attributes=dict(attributes) if attributes else {},
    )

    token = _current_span.set(span)
    error_info = None

    try:
        yield span
    except Exception as e:
        error_info = e
        raise
    finally:
        import time as _time_mod
        end_epoch = _time_mod.time()
        duration_ms = (perf_counter() - span.start_time) * 1000.0
        # Estimate span start epoch from end epoch and wall-clock duration
        start_epoch = end_epoch - duration_ms / 1000.0
        resolved_component = component or (name.split(".")[0] if name else "unknown")
        operation = name.split(".", 1)[1] if "." in name else name

        # Spread user attributes first, then structural fields on top
        # to prevent user-provided keys from clobbering span identity.
        event_data = {
            **span.attributes,
            "event_type": "span",
            "component": resolved_component,
            "operation": operation,
            "name": name,
            "trace_id": trace_id,
            "span_id": span_id,
            "parent_span_id": parent_span_id,
            "duration_ms": round(duration_ms, 2),
            # PLAT-PROGRESS-1: pass span start epoch for original_ts on started events
            "_span_start_epoch": start_epoch,
            "_span_end_epoch": end_epoch,
        }

        if error_info is not None:
            event_data["error"] = str(error_info)
            event_data["status"] = "error"

        try:
            _emit_span(event_data)
        except Exception:
            pass

        _current_span.reset(token)


def current_trace_id() -> Optional[str]:
    """Return the active trace_id, or None if no span is active."""
    span = _current_span.get()
    return span.trace_id if span else None


def current_span() -> Optional[SpanContext]:
    """Return the active SpanContext, or None if no span is active."""
    return _current_span.get()


def trace_log(name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
    """Emit a standalone log record with current span trace context.

    Unlike trace_span(), records an instantaneous occurrence with no duration
    and does not require a parent span.  Inherits trace_id / span_id from the
    active span when one exists, so log records are correlatable to the
    pipeline stage that emitted them.

    Args:
        name: Log name in dot notation (e.g., "pipeline.log").
              First segment used as component.
        attributes: Key-value payload for the log record.
    """
    if not _is_enabled():
        return
    span = _current_span.get()
    resolved_component = name.split(".")[0] if name else "unknown"
    operation = name.split(".", 1)[1] if "." in name else name
    event_data = {
        **(attributes or {}),
        "event_type": "log",
        "component": resolved_component,
        "operation": operation,
        "name": name,
        "trace_id": span.trace_id if span else "",
        "span_id": span.span_id if span else "",
        "parent_span_id": span.parent_span_id if span else None,
    }
    try:
        _emit_span(event_data)
    except Exception:
        pass


__all__ = ["trace_span", "trace_log", "current_trace_id", "current_span", "SpanContext"]
