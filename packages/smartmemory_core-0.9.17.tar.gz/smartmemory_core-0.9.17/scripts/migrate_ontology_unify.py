"""ONTO-RECONCILE-1 Phase 4 Tier 3 Task 10 — Ontology unification migration.

Migrates legacy `:EntityType` + `:Concept` + `:RelationType` graphs onto the
unified `:OntologyType` / `:OntologyRelation` substrate shipped in Phases 1-3.

Concurrency model (blueprint §6 decision #4): runs in a scheduled
maintenance window with ingest paused. Idempotent — partial-failure
recovery via re-run is supported through `:MigrationState` checkpoints.

Plan: smart-memory-docs/docs/features/ONTO-RECONCILE-1/plan.md §317-342.

Passes
------
0  pre-migration audit (registry vs graph delta report + HITL queue)
1  :EntityType    → set :OntologyType label + tier/source/layer
2  :Concept       → set :OntologyType label + tier/source/layer
3  name-conflict resolution: PRESERVE OVER MERGE (HITL queue)
4  :RELATES_TO / :IS_A relation-type-defs → :OntologyRelation
4b :VALID_FOR edge endpoint relabel (preserve {relation} property)
5  :Entity   → :OntologyType   :INSTANCE_OF edges (single-pass, checkpointed)
6  public-layer seed bootstrap from PublicKnowledgeStore
7  :OntologyAudit log seed (one row per migrated node)

CLI
---
    python scripts/migrate_ontology_unify.py --dry-run
    python scripts/migrate_ontology_unify.py --apply --workspace <id>
    python scripts/migrate_ontology_unify.py --apply --pass 1     # one pass
    python scripts/migrate_ontology_unify.py --status             # show :MigrationState

Direct-Cypher exemption
-----------------------
The substrate's "no Cypher outside OntologyService" rule (Task 1 contract)
is relaxed for THIS script only. Direct-Cypher sites are tagged
`MIGRATION-EXEMPT` so the CI grep can allowlist by exact line. After
Task 11 (legacy label drop), this script is retired and the exemption
goes with it.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from smartmemory.graph.ontology_graph import OntologyGraph  # noqa: E402
from smartmemory.ontology.tiers import tier_for_status  # noqa: E402

logger = logging.getLogger("migrate_ontology_unify")

PASS_IDS: tuple[str, ...] = (
    "0_audit",
    "1_entity_types",
    "2_concepts",
    "3_conflicts",
    "4_relations",
    "4b_valid_for",
    "5_instance_edges",
    "6_public_seed",
    "7_audit_log",
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# Result + state types
# ---------------------------------------------------------------------------


@dataclass
class PassResult:
    pass_id: str
    rows_inspected: int = 0
    rows_migrated: int = 0
    rows_skipped: int = 0
    hitl_queued: int = 0
    warnings: list[str] = field(default_factory=list)
    dry_run: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "pass_id": self.pass_id,
            "rows_inspected": self.rows_inspected,
            "rows_migrated": self.rows_migrated,
            "rows_skipped": self.rows_skipped,
            "hitl_queued": self.hitl_queued,
            "warnings": list(self.warnings),
            "dry_run": self.dry_run,
        }


@dataclass
class MigrationReport:
    started_at: str
    finished_at: str | None = None
    workspace_id: str | None = None
    dry_run: bool = False
    passes: dict[str, PassResult] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "workspace_id": self.workspace_id,
            "dry_run": self.dry_run,
            "passes": {k: v.to_dict() for k, v in self.passes.items()},
        }


@dataclass
class HealthReport:
    """ONTO-RECONCILE-1 Phase 6 — substrate health probe output.

    The operator's daily soak-monitoring signal. `soak_healthy` is the
    derived go/no-go for Task 11 (drop legacy labels) eligibility. The
    `checks` dict provides per-signal diagnosis when soak is unhealthy.
    """

    workspace_id: str
    as_of: str
    soak_healthy: bool
    checks: dict[str, dict[str, Any]] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "workspace_id": self.workspace_id,
            "as_of": self.as_of,
            "soak_healthy": self.soak_healthy,
            "checks": dict(self.checks),
            "warnings": list(self.warnings),
        }


# ---------------------------------------------------------------------------
# :MigrationState helpers (idempotency checkpoint)
# ---------------------------------------------------------------------------


def _read_completed_passes(graph: OntologyGraph, workspace_id: str) -> set[str]:
    """Return the set of pass_ids already marked complete for the workspace.

    Stored on a single `:MigrationState {workspace_id}` node; the `passes`
    property is a JSON-encoded list (FalkorDB doesn't support set/list
    values reliably across versions, see `feedback_falkordb_null_coalesce`
    + `feedback_list_prop_read_deserialize_gap`).
    """
    backend = graph._get_backend()  # MIGRATION-EXEMPT
    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (m:MigrationState {workspace_id: $ws, kind: 'ontology_unify'}) "
        "RETURN m.passes AS passes LIMIT 1",
        params={"ws": workspace_id},
        graph_name=graph._graph_name,
    )
    payload = _first_value(rows, "passes")
    if not payload:
        return set()
    try:
        return set(json.loads(payload))
    except (TypeError, ValueError):
        return set()


# ---------------------------------------------------------------------------
# Phase 6 — `compute_health_report` substrate health probe
# ---------------------------------------------------------------------------
#
# Derived soak-healthy contract. See
# `smart-memory-docs/docs/features/ONTO-RECONCILE-1/phase-6/design.md` §4.
# Six checks compose into `soak_healthy`; `instance_of_coverage` is
# warning-bearing only (data-quality skips don't block soak).
# All Cypher in this section is # MIGRATION-EXEMPT — operator probe path
# distinct from substrate write paths.


def _scalar_count(graph: OntologyGraph, cypher: str, params: dict[str, Any]) -> int:
    """Run a `RETURN count(...) AS c` query and extract the scalar."""
    backend = graph._get_backend()  # MIGRATION-EXEMPT
    rows = backend.query(cypher, params=params, graph_name=graph._graph_name)  # MIGRATION-EXEMPT
    head = rows[0] if rows else None
    if isinstance(head, dict):
        return int(head.get("c") or 0)
    if isinstance(head, list) and head:
        return int(head[0] or 0)
    return 0


def compute_health_report(
    graph: OntologyGraph, workspace_id: str, *, hitl_days: int = 7
) -> HealthReport:
    """ONTO-RECONCILE-1 Phase 6 — substrate health probe.

    Returns a `HealthReport` answering "is the migration soak healthy"
    for `workspace_id`. `soak_healthy` is the derived AND of six checks;
    `instance_of_coverage` is warning-bearing only (data-quality skips
    are permanent and shouldn't block the soak signal).

    Parameters
    ----------
    graph : OntologyGraph
        Substrate handle (the function calls `graph._get_backend()`).
    workspace_id : str
        Workspace to probe.
    hitl_days : int, default 7
        Window for the HITL-stability check. "No new HITL entries in
        the last `hitl_days` days" is the substrate-level proxy for
        "no unresolved curator work" since `:OntologyHITLQueue` has no
        consumer at the time of writing (filed as ONTO-HITL-CONSUMER-1).

    Contract
    --------
    `graph` MUST be bound to the workspace's graph_name (i.e.
    constructed via `OntologyGraph(workspace_id=workspace_id)`).
    `:OntologyAudit` rows now carry `workspace_id` (ONTO-AUDIT-WS-1,
    2026-05-09); historical rows persisted before that fix have NULL.
    The workspace boundary is also enforced by FalkorDB graph_name
    isolation, so counts within a workspace's graph are tenant-correct
    regardless. The precondition check below catches a non-bound graph.
    """
    # Precondition check — graph must be workspace-bound. Codex review
    # round 2 defense-in-depth: catch the misuse before producing a
    # report that would mislead the operator.
    if getattr(graph, "workspace_id", None) != workspace_id:
        raise ValueError(
            f"compute_health_report requires graph bound to workspace_id={workspace_id!r} "
            f"(got graph.workspace_id={getattr(graph, 'workspace_id', None)!r}). "
            "Construct via OntologyGraph(workspace_id=workspace_id)."
        )
    from datetime import datetime, timezone, timedelta

    now_dt = datetime.now(timezone.utc)
    as_of = now_dt.isoformat(timespec="seconds")
    cutoff = (now_dt - timedelta(days=hitl_days)).isoformat(timespec="seconds")

    checks: dict[str, dict[str, Any]] = {}
    warnings: list[str] = []

    # 1. completed_passes — every PASS_ID checkpointed
    completed = _read_completed_passes(graph, workspace_id)
    completed_ok = set(completed) >= set(PASS_IDS)
    checks["completed_passes"] = {
        "ok": completed_ok,
        "value": sorted(completed),
        "expected": list(PASS_IDS),
    }

    # 2. ingest_paused — must be false on a healthy soak
    paused = is_ingest_paused(graph, workspace_id)
    checks["ingest_paused"] = {"ok": paused is False, "value": bool(paused)}

    # 3. stale_pass3_markers — recovery Cypher needed if non-zero
    try:
        stale = _scalar_count(
            graph,
            "MATCH (n:OntologyType) "  # MIGRATION-EXEMPT
            "WHERE n.workspace_id = $ws AND "
            "(n._pass3_survivor IS NOT NULL OR n._pass3_drop IS NOT NULL) "
            "RETURN count(n) AS c",
            {"ws": workspace_id},
        )
        checks["stale_pass3_markers"] = {"ok": stale == 0, "value": stale}
    except Exception as e:  # noqa: BLE001
        checks["stale_pass3_markers"] = {"ok": False, "value": None, "error": str(e)}

    # 4. audit_invariant — Pass 7 contract
    # count(:OntologyType WHERE migrated_at) == count(:OntologyAudit migrated)
    migrated_types = _scalar_count(
        graph,
        "MATCH (t:OntologyType) "  # MIGRATION-EXEMPT
        "WHERE t.workspace_id = $ws AND t.migrated_at IS NOT NULL "
        "RETURN count(t) AS c",
        {"ws": workspace_id},
    )
    # `:OntologyAudit` rows now carry `workspace_id` (ONTO-AUDIT-WS-1,
    # 2026-05-09 — `_write_audit_entry` reads `scope_provider.get_write_context()`).
    # Workspace boundary is enforced both by FalkorDB graph_name isolation
    # and the persisted property; either alone is sufficient for tenant
    # correctness within this query because the precondition check above
    # confirms the graph is workspace-bound.
    migrated_audits = _scalar_count(
        graph,
        "MATCH (a:OntologyAudit) "  # MIGRATION-EXEMPT
        "WHERE a.action = 'migrated' AND a.actor = 'migration_script' "
        "RETURN count(a) AS c",
        {},
    )
    checks["audit_invariant"] = {
        "ok": migrated_types == migrated_audits,
        "migrated_types": migrated_types,
        "migrated_audits": migrated_audits,
    }

    # 5. hitl_stability — no new entries in window
    open_count = _scalar_count(
        graph,
        "MATCH (h:OntologyHITLQueue) "  # MIGRATION-EXEMPT  TODO ONTO-HITL-CONSUMER-1: add index
        "WHERE h.workspace_id = $ws AND h.status = 'open' "
        "RETURN count(h) AS c",
        {"ws": workspace_id},
    )
    new_in_window = _scalar_count(
        graph,
        "MATCH (h:OntologyHITLQueue) "  # MIGRATION-EXEMPT
        "WHERE h.workspace_id = $ws AND h.created_at >= $cutoff "
        "RETURN count(h) AS c",
        {"ws": workspace_id, "cutoff": cutoff},
    )
    checks["hitl_stability"] = {
        "ok": new_in_window == 0,
        "open_count": open_count,
        "new_in_window": new_in_window,
        "window_days": hitl_days,
    }

    # 6. residual_legacy_labels — Pass 1/2/4 must have relabeled everything
    residual_entity = _scalar_count(
        graph,
        "MATCH (n:EntityType) "  # MIGRATION-EXEMPT
        "WHERE n.workspace_id = $ws AND NOT (n:OntologyType) "
        "RETURN count(n) AS c",
        {"ws": workspace_id},
    )
    residual_concept = _scalar_count(
        graph,
        "MATCH (n:Concept) "  # MIGRATION-EXEMPT
        "WHERE n.workspace_id = $ws AND NOT (n:OntologyType) "
        "RETURN count(n) AS c",
        {"ws": workspace_id},
    )
    residual_relation = _scalar_count(
        graph,
        "MATCH (n:RelationType) "  # MIGRATION-EXEMPT
        "WHERE n.workspace_id = $ws AND NOT (n:OntologyRelation) "
        "RETURN count(n) AS c",
        {"ws": workspace_id},
    )
    checks["residual_legacy_labels"] = {
        "ok": residual_entity == 0 and residual_concept == 0 and residual_relation == 0,
        "entity_type": residual_entity,
        "concept": residual_concept,
        "relation_type": residual_relation,
    }

    # 7. instance_of_coverage — WARNING-bearing only, not part of soak_healthy
    entities_total = _scalar_count(
        graph,
        "MATCH (e:Entity) WHERE e.workspace_id = $ws RETURN count(e) AS c",  # MIGRATION-EXEMPT
        {"ws": workspace_id},
    )
    entities_with_inst = _scalar_count(
        graph,
        "MATCH (e:Entity)-[:INSTANCE_OF]->(:OntologyType) "  # MIGRATION-EXEMPT
        "WHERE e.workspace_id = $ws "
        "RETURN count(DISTINCT e) AS c",
        {"ws": workspace_id},
    )
    missing_type_prop = _scalar_count(
        graph,
        "MATCH (e:Entity) "  # MIGRATION-EXEMPT
        "WHERE e.workspace_id = $ws AND e.type IS NULL "
        "RETURN count(e) AS c",
        {"ws": workspace_id},
    )
    coverage_ok = entities_total == 0 or entities_with_inst == entities_total
    checks["instance_of_coverage"] = {
        "ok": coverage_ok,
        "entities_total": entities_total,
        "entities_with_instance_of": entities_with_inst,
        "missing_type_property": missing_type_prop,
    }
    if missing_type_prop:
        warnings.append(
            f"{missing_type_prop} :Entity row(s) missing `type` property — "
            f"Pass 5 permanent skip; not blocking soak"
        )
    if entities_with_inst < entities_total - missing_type_prop:
        warnings.append(
            f"{entities_total - missing_type_prop - entities_with_inst} "
            f":Entity rows have `type` but no :INSTANCE_OF edge — possible Pass 5 gap"
        )

    soak_healthy = (
        checks["completed_passes"]["ok"]
        and checks["ingest_paused"]["ok"]
        and checks["stale_pass3_markers"]["ok"]
        and checks["audit_invariant"]["ok"]
        and checks["hitl_stability"]["ok"]
        and checks["residual_legacy_labels"]["ok"]
    )
    # instance_of_coverage deliberately NOT in soak_healthy — see design §5

    return HealthReport(
        workspace_id=workspace_id,
        as_of=as_of,
        soak_healthy=soak_healthy,
        checks=checks,
        warnings=warnings,
    )


# ---------------------------------------------------------------------------
# Ingest-pause toggle (plan §340)
# ---------------------------------------------------------------------------
#
# During the migration window we want SmartMemory.ingest() to refuse new
# work, so live writes don't interleave with the relabel passes and
# corrupt the schema (e.g. a write creating an `:EntityType` row halfway
# through Pass 1's :OntologyType relabel). The flag is a property on the
# same `:MigrationState` node used for pass-completion checkpoints.
#
# Producer:  this script flips `ingest_paused = true` at start of an
#            apply run and clears it at end. CLI flags `--pause-ingest`
#            and `--unpause-ingest` allow manual control.
# Consumer:  SmartMemory._is_ingest_paused() reads the flag at the top
#            of ingest() / ingest_batch_sync() / ingest_conversation_sync()
#            / ingest_structured() and raises IngestPausedError when set.


def is_ingest_paused(graph: OntologyGraph, workspace_id: str) -> bool:
    """Return True if the migration window is currently active for this workspace."""
    backend = graph._get_backend()  # MIGRATION-EXEMPT
    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (m:MigrationState {workspace_id: $ws, kind: 'ontology_unify'}) "
        "RETURN m.ingest_paused AS paused LIMIT 1",
        params={"ws": workspace_id},
        graph_name=graph._graph_name,
    )
    val = _first_value(rows, "paused")
    return bool(val)


def pause_ingest(graph: OntologyGraph, workspace_id: str) -> None:
    """Flip the flag on. Idempotent."""
    backend = graph._get_backend()  # MIGRATION-EXEMPT
    backend.query(  # MIGRATION-EXEMPT
        "MERGE (m:MigrationState {workspace_id: $ws, kind: 'ontology_unify'}) "
        "SET m.ingest_paused = true, m.paused_at = $now",
        params={"ws": workspace_id, "now": _now_iso()},
        graph_name=graph._graph_name,
    )


def unpause_ingest(graph: OntologyGraph, workspace_id: str) -> None:
    """Clear the flag. Idempotent — safe to call when not paused."""
    backend = graph._get_backend()  # MIGRATION-EXEMPT
    backend.query(  # MIGRATION-EXEMPT
        "MERGE (m:MigrationState {workspace_id: $ws, kind: 'ontology_unify'}) "
        "SET m.ingest_paused = false, m.unpaused_at = $now",
        params={"ws": workspace_id, "now": _now_iso()},
        graph_name=graph._graph_name,
    )


def _mark_pass_complete(
    graph: OntologyGraph, workspace_id: str, pass_id: str, *, dry_run: bool
) -> None:
    if dry_run:
        return
    completed = _read_completed_passes(graph, workspace_id)
    completed.add(pass_id)
    payload = json.dumps(sorted(completed))
    backend = graph._get_backend()  # MIGRATION-EXEMPT
    backend.query(  # MIGRATION-EXEMPT
        "MERGE (m:MigrationState {workspace_id: $ws, kind: 'ontology_unify'}) "
        "SET m.passes = $payload, m.updated_at = $now",
        params={"ws": workspace_id, "payload": payload, "now": _now_iso()},
        graph_name=graph._graph_name,
    )


def _first_value(rows: Any, key: str) -> Any:
    if not rows:
        return None
    if isinstance(rows, list) and rows:
        head = rows[0]
        if isinstance(head, dict):
            return head.get(key)
        if isinstance(head, list) and head:
            return head[0]
    return None


# ---------------------------------------------------------------------------
# HITL queue writer
# ---------------------------------------------------------------------------


def _enqueue_hitl(
    graph: OntologyGraph,
    workspace_id: str,
    *,
    kind: str,
    target: str,
    detail: dict[str, Any],
    dry_run: bool,
) -> None:
    """Write one `:OntologyHITLQueue` node for curator review.

    Schema kept minimal — full HITL UI consumes via list-by-workspace
    queries in CRUD-1. We intentionally don't reuse the
    `OntologyGovernor.violations` queue; this is migration-specific
    provenance ("recovered from migration" / "name conflict").
    """
    if dry_run:
        return
    backend = graph._get_backend()  # MIGRATION-EXEMPT
    backend.query(  # MIGRATION-EXEMPT
        "CREATE (h:OntologyHITLQueue {"
        "workspace_id: $ws, kind: $kind, target: $target, "
        "detail_json: $detail, created_at: $now, status: 'open'"
        "})",
        params={
            "ws": workspace_id,
            "kind": kind,
            "target": target,
            "detail": json.dumps(detail, default=str),
            "now": _now_iso(),
        },
        graph_name=graph._graph_name,
    )


# ---------------------------------------------------------------------------
# Pass 0 — Pre-migration audit
# ---------------------------------------------------------------------------


def pass_0_audit(
    graph: OntologyGraph,
    workspace_id: str,
    *,
    registry_concepts: list[dict[str, Any]] | None = None,
    delta_report_dir: Path | None = None,
    dry_run: bool,
) -> PassResult:
    """Walk registry concepts and graph rows; emit a delta report.

    `registry_concepts` is the materialized list from `OntologyManager.storage`
    (per plan correction #1 — not `manager.add_entity_type`, that's on the
    `Ontology` model). Caller supplies it; we don't reach into Mongo here
    so the script stays graph-only and easier to fixture in tests.

    Expected shape per concept: ``{"name": str, "status": str}``.

    Asymmetries flagged:
      A. registry status=approved AND missing from graph
         → silently-failed `try/except` in route handler. Queues HITL.
      B. graph row not in registry → orphan from earlier code paths.
         Queues HITL.
    """
    result = PassResult(pass_id="0_audit", dry_run=dry_run)

    # Build registry index (case-insensitive on name)
    reg_by_name: dict[str, dict[str, Any]] = {}
    for c in (registry_concepts or []):
        nm = (c.get("name") or "").strip()
        if nm:
            reg_by_name[nm.lower()] = c

    # Read graph EntityType rows
    backend = graph._get_backend()  # MIGRATION-EXEMPT
    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (n:EntityType) RETURN n.name AS name, n.status AS status",
        params={},
        graph_name=graph._graph_name,
    )
    graph_rows: list[dict[str, Any]] = []
    for row in (rows or []):
        if isinstance(row, dict):
            graph_rows.append({"name": row.get("name"), "status": row.get("status")})
        elif isinstance(row, list) and len(row) >= 2:
            graph_rows.append({"name": row[0], "status": row[1]})
    graph_by_name: dict[str, dict[str, Any]] = {
        (r["name"] or "").strip().lower(): r for r in graph_rows if r.get("name")
    }

    result.rows_inspected = len(reg_by_name) + len(graph_by_name)

    # A. Registry approved & missing from graph
    for nm, c in reg_by_name.items():
        if c.get("status") == "approved" and nm not in graph_by_name:
            _enqueue_hitl(
                graph,
                workspace_id,
                kind="missing_in_graph",
                target=c.get("name") or nm,
                detail={"registry_status": c.get("status"), "source": "registry_only"},
                dry_run=dry_run,
            )
            result.hitl_queued += 1

    # B. Graph rows not in registry
    for nm, r in graph_by_name.items():
        if nm not in reg_by_name:
            _enqueue_hitl(
                graph,
                workspace_id,
                kind="missing_in_registry",
                target=r.get("name") or nm,
                detail={"graph_status": r.get("status"), "source": "graph_only"},
                dry_run=dry_run,
            )
            result.hitl_queued += 1

    # Delta report
    if delta_report_dir is not None and not dry_run:
        delta_report_dir.mkdir(parents=True, exist_ok=True)
        report_path = delta_report_dir / f"migration_audit_{int(datetime.now(timezone.utc).timestamp())}.json"
        report_path.write_text(
            json.dumps(
                {
                    "workspace_id": workspace_id,
                    "generated_at": _now_iso(),
                    "registry_count": len(reg_by_name),
                    "graph_count": len(graph_by_name),
                    "missing_in_graph": [
                        c["name"] for nm, c in reg_by_name.items()
                        if c.get("status") == "approved" and nm not in graph_by_name
                    ],
                    "missing_in_registry": [
                        r["name"] for nm, r in graph_by_name.items() if nm not in reg_by_name
                    ],
                },
                indent=2,
            )
        )

    return result


# ---------------------------------------------------------------------------
# Pass 1 — :EntityType → :OntologyType
# ---------------------------------------------------------------------------


def pass_1_entity_types(
    graph: OntologyGraph,
    workspace_id: str,
    *,
    dry_run: bool,
) -> PassResult:
    """Add `:OntologyType` label to existing `:EntityType` rows + fill schema.

    Idempotency: re-runs see rows already carrying `:OntologyType` and skip
    them via the `WHERE NOT n:OntologyType` guard. MERGE-style relabel
    is what FalkorDB supports today (label-add via SET; label-remove on
    legacy nodes happens in Task 11 after the soak window).

    Tier mapping uses `tier_for_status` (Task 3 unified mapping which
    covers DEPRECATED → retired).

    `:EntityPattern -[:IS_INSTANCE_OF]-> :EntityType` edges keep working
    because the underlying nodes still carry `:EntityType` (we only
    ADD `:OntologyType`). After Task 11 drops `:EntityType`, the
    pattern queries already use `:OntologyType` lookups via the
    substrate.
    """
    result = PassResult(pass_id="1_entity_types", dry_run=dry_run)
    backend = graph._get_backend()  # MIGRATION-EXEMPT

    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (n:EntityType) WHERE NOT n:OntologyType "
        "RETURN n.name AS name, n.status AS status",
        params={},
        graph_name=graph._graph_name,
    )
    candidates: list[tuple[str, str | None]] = []
    for row in (rows or []):
        if isinstance(row, dict):
            candidates.append((row.get("name"), row.get("status")))
        elif isinstance(row, list) and len(row) >= 2:
            candidates.append((row[0], row[1]))

    result.rows_inspected = len(candidates)

    if dry_run:
        result.rows_migrated = len(candidates)
        return result

    for name, status in candidates:
        if not name:
            result.rows_skipped += 1
            continue
        try:
            tier = tier_for_status(status or "proposed")
        except Exception as e:
            result.warnings.append(f"tier_for_status({status!r}) failed for {name!r}: {e}")
            tier = "working"
        backend.query(  # MIGRATION-EXEMPT
            "MATCH (n:EntityType {name: $name}) "
            "SET n:OntologyType, "
            "    n.tier = COALESCE(n.tier, $tier), "
            "    n.source = COALESCE(n.source, 'inline'), "
            "    n.layer = COALESCE(n.layer, 'private'), "
            "    n.workspace_id = COALESCE(n.workspace_id, $ws), "
            "    n.migrated_at = $now",
            params={"name": name, "tier": tier, "ws": workspace_id, "now": _now_iso()},
            graph_name=graph._graph_name,
        )
        result.rows_migrated += 1

    return result


# ---------------------------------------------------------------------------
# Pass 2 — :Concept → :OntologyType
# ---------------------------------------------------------------------------


def pass_2_concepts(graph: OntologyGraph, workspace_id: str, *, dry_run: bool) -> PassResult:
    """Add `:OntologyType` label to `:Concept` rows. Mirror of Pass 1.

    Source = 'batch' (Path B). Layer defaults to 'private' unless the
    concept already carries a layer hint (e.g. from a domain pack
    import — those rows arrive with `layer='domain'` already set, and
    the COALESCE preserves it). Tier mapping via `tier_for_status`.
    """
    result = PassResult(pass_id="2_concepts", dry_run=dry_run)
    backend = graph._get_backend()  # MIGRATION-EXEMPT

    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (n:Concept) WHERE NOT n:OntologyType "
        "RETURN n.name AS name, n.status AS status",
        params={},
        graph_name=graph._graph_name,
    )
    candidates: list[tuple[str, str | None]] = []
    for row in (rows or []):
        if isinstance(row, dict):
            candidates.append((row.get("name"), row.get("status")))
        elif isinstance(row, list) and len(row) >= 2:
            candidates.append((row[0], row[1]))

    result.rows_inspected = len(candidates)

    if dry_run:
        result.rows_migrated = len(candidates)
        return result

    for name, status in candidates:
        if not name:
            result.rows_skipped += 1
            continue
        try:
            tier = tier_for_status(status or "proposed")
        except Exception as e:
            result.warnings.append(f"tier_for_status({status!r}) failed for {name!r}: {e}")
            tier = "working"
        backend.query(  # MIGRATION-EXEMPT
            "MATCH (n:Concept {name: $name}) "
            "SET n:OntologyType, "
            "    n.tier = COALESCE(n.tier, $tier), "
            "    n.source = COALESCE(n.source, 'batch'), "
            "    n.layer = COALESCE(n.layer, 'private'), "
            "    n.workspace_id = COALESCE(n.workspace_id, $ws), "
            "    n.migrated_at = $now",
            params={"name": name, "tier": tier, "ws": workspace_id, "now": _now_iso()},
            graph_name=graph._graph_name,
        )
        result.rows_migrated += 1

    return result


# ---------------------------------------------------------------------------
# Pass 3 — Name-conflict resolution (preserve over merge)
# ---------------------------------------------------------------------------


# Source preference for canonical-winner selection during auto-merge.
# Path A (inline / EntityType origin) outranks Path B (batch / Concept origin)
# because inline rows carry the registry-approved promotions; batch rows are
# proposals that haven't been reconciled yet. `migration_recovered` and
# `public` round out the order for completeness.
_PASS3_SOURCE_RANK: dict[str, int] = {
    "inline": 0,
    "batch": 1,
    "migration_recovered": 2,
    "public": 3,
}

_PASS3_TIER_RANK: dict[str, int] = {
    "confirmed": 0,
    "working": 1,
    "proposed": 2,
    "retired": 3,
}

# Edge types that may already exist at Pass 3 time (post Pass 1/2, pre Pass 4/5).
# `:VALID_FOR` survives Pass 1's label-only relabel; `:IS_INSTANCE_OF` carries
# `:EntityPattern` rows (correction #7); `:IS_A` is materialized by Tier 1
# Task 12b's taxonomy edge writer.
_PASS3_REDIRECT_EDGE_TYPES: tuple[str, ...] = (
    "VALID_FOR",
    "IS_INSTANCE_OF",
    "IS_A",
)


def _pass3_resolve_disambiguator_name(
    graph: OntologyGraph,
    base_name: str,
    suffix: str,
) -> str:
    """Pick a disambiguator name that doesn't collide with an existing
    `:OntologyType.name`.

    Codex review #R3-2 (2026-05-04): the bare `SET n.name = $new_name`
    in Pass 3's rename branches has no preflight check. If a Pass 1/2
    type happens to be named the same as a Pass 3 disambiguator suffix
    (e.g. an existing type is literally `Apple_25cc3d66`), Pass 3
    silently creates a duplicate. Fix: check existence; on collision,
    append an ordinal until we find a free slot.

    Returns the chosen name (`<base>_<suffix>` if free, else
    `<base>_<suffix>_<n>` with the smallest free `n`).
    """
    backend = graph._get_backend()  # MIGRATION-EXEMPT
    base_candidate = f"{base_name}_{suffix}"
    candidate = base_candidate
    ordinal = 0
    while True:
        rows = backend.query(  # MIGRATION-EXEMPT
            "MATCH (n:OntologyType {name: $name}) RETURN count(n) AS c",
            params={"name": candidate},
            graph_name=graph._graph_name,
        )
        head = rows[0] if rows else None
        existing = int(head.get("c") if isinstance(head, dict) else (head[0] if head else 0))
        if existing == 0:
            return candidate
        ordinal += 1
        candidate = f"{base_candidate}_{ordinal}"
        # Defensive cap — if 1000 collisions exist for the same suffix
        # we have a much bigger problem than this loop.
        if ordinal > 1000:
            raise RuntimeError(
                f"pass_3_conflicts: gave up resolving disambiguator name "
                f"after 1000 collisions on prefix {base_candidate!r}"
            )


def _pass3_short_iri_hash(iri: str) -> str:
    """Stable 8-char hex disambiguator suffix derived from an iri.

    8 chars of md5 ≈ 4.3B values — collisions only matter within a single
    `name` group, where 8 chars is overkill. Lowercase hex matches the
    `len(suffix) == 8 and all(c in "0123456789abcdef")` test invariant.
    """
    return hashlib.md5(iri.encode("utf-8")).hexdigest()[:8]


def _pass3_bucket_identity(
    bucket: list[dict[str, Any]],
    winner: dict[str, Any],
) -> tuple[str, str]:
    """Derive canonical (iri, qid) for an auto-merge bucket.

    Codex review #R3-1 (2026-05-04): the ranked winner's iri/qid alone
    isn't sufficient — when collapsing by qid, the winner may have empty
    iri while a loser has a real iri (or vice-versa for iri-collapse).
    With WITH n LIMIT 1's arbitrary physical pick, the survivor's
    identity ends up non-deterministic.

    Strategy: prefer the ranked winner's value when non-empty; otherwise
    fall back to the first non-empty value found across the rest of the
    bucket. This makes the canonical identity bucket-derived rather
    than winner-derived, so a loser-side non-empty iri/qid is always
    preserved on the survivor.
    """
    canonical_iri = winner.get("iri") or ""
    canonical_qid = winner.get("qid") or ""
    if not canonical_iri:
        for r in bucket:
            if r.get("iri"):
                canonical_iri = r["iri"]
                break
    if not canonical_qid:
        for r in bucket:
            if r.get("qid"):
                canonical_qid = r["qid"]
                break
    return canonical_iri, canonical_qid


def _pass3_canonical_rank(row: dict[str, Any]) -> tuple[int, int]:
    """Sort key for picking the canonical winner of a Pass 3 collision.

    Lower-rank rows win. The ordering is (source_rank, tier_rank), so
    'inline' beats 'batch' regardless of tier; among same-source rows,
    'confirmed' beats 'working'.

    Known limitation (Codex review #6, 2026-05-04): when two rows tie
    on BOTH source and tier (e.g. two ``source='batch', tier='working'``
    rows from independent BatchObserver runs that produced same-name
    same-iri concepts), the surviving physical row is whichever
    ``WITH n LIMIT 1`` returns from FalkorDB — non-deterministic across
    runs. Only the canonical source/tier is overwritten on the survivor;
    every other property (timestamps, confidence, layer, etc.) is
    arbitrary. This is acceptable for the migration's audit-recovery
    use case (the survivor is "one of the originals" and Pass 7 records
    the migration provenance), but is NOT a strong contract for
    callers expecting deterministic identity.
    """
    src = row.get("source") or ""
    tier = row.get("tier") or ""
    return (
        _PASS3_SOURCE_RANK.get(src, 99),
        _PASS3_TIER_RANK.get(tier, 99),
    )


def _pass3_collapse_bucket(
    graph: OntologyGraph,
    *,
    name: str,
    match_dim: str,
    match_value: str,
    winner_source: str | None,
    winner_tier: str | None,
    winner_iri: str | None = None,
    winner_qid: str | None = None,
) -> int:
    """Collapse all `:OntologyType {name}` rows whose `match_dim` equals
    `match_value` down to one canonical row.

    `match_dim` is the SINGLE property that defines the bucket — either
    'iri' or 'wikidata_qid'. We deliberately do NOT compose iri + qid:
    Codex review #1 (2026-05-04) caught a bug where matching on both
    silently dropped rows that shared iri but had divergent qid (or
    vice-versa), then their disambiguator-branch fallback produced
    same-hash suffixes and the collision survived.

    Strategy: when N rows share `name + match_value`, we still can't
    distinguish them via Cypher WHERE clauses if all other props are
    also equal, so we use `WITH n LIMIT 1` to mark exactly one survivor
    and tag the rest. The transient marker properties (`_pass3_survivor`
    / `_pass3_drop`) are cleared in a try/finally — Codex review #2
    (2026-05-04) caught that a mid-pass exception would otherwise leak
    them onto live rows and cause a subsequent rerun's global
    DETACH-DELETE to hit stale marked rows from the failed bucket.

    Returns the number of rows removed (== merges performed).

    The canonical row inherits the winner's source/tier (highest-rank
    row found across the entire bucket — Path A inline > Path B batch).
    Edges of the dropped rows are redirected onto the survivor for the
    three edge types that may exist at Pass 3 time.
    """
    if match_dim not in ("iri", "wikidata_qid"):
        raise ValueError(
            f"_pass3_collapse_bucket: match_dim must be 'iri' or "
            f"'wikidata_qid', got {match_dim!r}"
        )

    backend = graph._get_backend()  # MIGRATION-EXEMPT
    where = f"COALESCE(n.{match_dim}, '') = $val"

    # Step 1: how many rows match the bucket criteria?
    count_rows = backend.query(  # MIGRATION-EXEMPT
        f"MATCH (n:OntologyType {{name: $name}}) WHERE {where} "
        f"RETURN count(n) AS c",
        params={"name": name, "val": match_value},
        graph_name=graph._graph_name,
    )
    head = count_rows[0] if count_rows else None
    bucket_size = int(head.get("c") if isinstance(head, dict) else (head[0] if head else 0))
    if bucket_size < 2:
        return 0

    try:
        # Step 2: pick exactly one survivor via WITH n LIMIT 1; tag the rest.
        backend.query(  # MIGRATION-EXEMPT
            f"MATCH (n:OntologyType {{name: $name}}) WHERE {where} "
            f"WITH n LIMIT 1 "
            f"SET n._pass3_survivor = true",
            params={"name": name, "val": match_value},
            graph_name=graph._graph_name,
        )
        backend.query(  # MIGRATION-EXEMPT
            f"MATCH (n:OntologyType {{name: $name}}) WHERE {where} "
            f"  AND n._pass3_survivor IS NULL "
            f"SET n._pass3_drop = true",
            params={"name": name, "val": match_value},
            graph_name=graph._graph_name,
        )

        # Step 3: redirect edges from drop-tagged rows onto the survivor.
        for edge_type in _PASS3_REDIRECT_EDGE_TYPES:
            backend.query(  # MIGRATION-EXEMPT
                f"MATCH (a)-[r:{edge_type}]->(loser:OntologyType {{_pass3_drop: true}}) "
                f"MATCH (winner:OntologyType {{_pass3_survivor: true}}) "
                f"WITH a, winner, r, properties(r) AS p "
                f"MERGE (a)-[nr:{edge_type}]->(winner) "
                f"SET nr += p "
                f"DELETE r",
                params={},
                graph_name=graph._graph_name,
            )
            backend.query(  # MIGRATION-EXEMPT
                f"MATCH (loser:OntologyType {{_pass3_drop: true}})-[r:{edge_type}]->(b) "
                f"MATCH (winner:OntologyType {{_pass3_survivor: true}}) "
                f"WITH winner, b, r, properties(r) AS p "
                f"MERGE (winner)-[nr:{edge_type}]->(b) "
                f"SET nr += p "
                f"DELETE r",
                params={},
                graph_name=graph._graph_name,
            )

        # Step 4: drop the extras.
        backend.query(  # MIGRATION-EXEMPT
            "MATCH (n:OntologyType {_pass3_drop: true}) DETACH DELETE n",
            params={},
            graph_name=graph._graph_name,
        )

        # Step 5: promote the survivor to the canonical winner's identity.
        # Codex review #R2-1 (2026-05-04): WITH n LIMIT 1 picks an
        # arbitrary physical survivor — possibly the loser. We must
        # explicitly propagate the winner's identity fields (iri,
        # wikidata_qid) AND the canonical source/tier so the survivor is
        # truly the winner regardless of FalkorDB's row ordering. iri/
        # qid are passed through from the caller (which already ranked
        # the bucket); empty-string winners do not overwrite a non-empty
        # surviving value (only-when-better promotion semantics).
        backend.query(  # MIGRATION-EXEMPT
            "MATCH (n:OntologyType {_pass3_survivor: true}) "
            "SET n.source = COALESCE($source, n.source), "
            "    n.tier = COALESCE($tier, n.tier), "
            "    n.iri = CASE WHEN $iri IS NULL OR $iri = '' "
            "                 THEN COALESCE(n.iri, '') "
            "                 ELSE $iri END, "
            "    n.wikidata_qid = CASE WHEN $qid IS NULL OR $qid = '' "
            "                          THEN COALESCE(n.wikidata_qid, '') "
            "                          ELSE $qid END, "
            "    n.migrated_at = $now",
            params={
                "source": winner_source,
                "tier": winner_tier,
                "iri": winner_iri,
                "qid": winner_qid,
                "now": _now_iso(),
            },
            graph_name=graph._graph_name,
        )

        return bucket_size - 1
    finally:
        # Always clear transient markers, even on exception. Cleanup
        # failure is RAISED (not just logged) because subsequent buckets
        # in the same pass would bind to stale markers and mutate the
        # wrong nodes — Codex review #R2-2 (2026-05-04) caught that
        # silently swallowing here means Pass 3 reports "success" while
        # invisibly corrupting the graph. The raised exception is
        # chained from the original (if any) via Python's implicit
        # exception chaining (`__context__`), so the operator sees both.
        try:
            backend.query(  # MIGRATION-EXEMPT
                "MATCH (n:OntologyType) WHERE n._pass3_survivor IS NOT NULL "
                "OR n._pass3_drop IS NOT NULL "
                "REMOVE n._pass3_survivor, n._pass3_drop",
                params={},
                graph_name=graph._graph_name,
            )
        except Exception as cleanup_err:  # noqa: BLE001
            logger.error(
                "pass_3_conflicts: marker cleanup failed (%s); ABORTING the "
                "pass to prevent stale _pass3_drop / _pass3_survivor markers "
                "from misrouting subsequent bucket operations. Recovery: "
                "run `MATCH (n:OntologyType) REMOVE n._pass3_survivor, "
                "n._pass3_drop` directly against FalkorDB before re-running",
                cleanup_err,
            )
            raise


def pass_3_conflicts(graph: OntologyGraph, workspace_id: str, *, dry_run: bool) -> PassResult:
    """Resolve `name` collisions across :OntologyType rows.

    Plan §328 policy:
      * iri match (or wikidata_qid match) ⟶ auto-merge into the canonical
        row (preferred source/tier wins; edges redirected from losers).
      * iri mismatch (any row has iri but they differ) ⟶ disambiguator
        suffix `<name>_<short_iri_hash>` for every row in the group.
        Does NOT queue HITL — disambiguation is deterministic when iris
        differ; curator only needs HITL when there's nothing to disambiguate by.
      * No iri AND no wikidata_qid on any row in the group ⟶ append a
        rank-position suffix (`<name>_<rank_hash>`) AND queue an
        `:OntologyHITLQueue` entry for curator review (curator merges via
        CRUD-1 merge tooling once they decide which row is canonical).
    """
    result = PassResult(pass_id="3_conflicts", dry_run=dry_run)
    backend = graph._get_backend()  # MIGRATION-EXEMPT

    # Pull every (:OntologyType) row's identifying props. We could group in
    # Cypher, but FalkorDB's `collect(n)` over node references is fragile;
    # in-Python grouping is straightforward and the row volume is bounded
    # by the legacy graph's type-cardinality (sub-thousand).
    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (n:OntologyType) "
        "RETURN n.name AS name, "
        "       COALESCE(n.iri, '') AS iri, "
        "       COALESCE(n.wikidata_qid, '') AS qid, "
        "       n.source AS source, "
        "       n.tier AS tier",
        params={},
        graph_name=graph._graph_name,
    )

    parsed: list[dict[str, Any]] = []
    for row in rows or []:
        if isinstance(row, dict):
            parsed.append({
                "name": row.get("name"),
                "iri": row.get("iri") or "",
                "qid": row.get("qid") or "",
                "source": row.get("source"),
                "tier": row.get("tier"),
            })
        elif isinstance(row, list) and len(row) >= 5:
            parsed.append({
                "name": row[0],
                "iri": row[1] or "",
                "qid": row[2] or "",
                "source": row[3],
                "tier": row[4],
            })

    # Group by `name`; only collisions (size >= 2) need work.
    by_name: dict[str, list[dict[str, Any]]] = {}
    for r in parsed:
        nm = r.get("name")
        if not nm:
            continue
        by_name.setdefault(nm, []).append(r)

    collision_groups = {n: g for n, g in by_name.items() if len(g) >= 2}
    result.rows_inspected = sum(len(g) for g in collision_groups.values())

    if dry_run:
        # In dry-run, rows_migrated reflects how many rows would change
        # (every row in every collision group ends up either merged-out
        # or renamed).
        result.rows_migrated = result.rows_inspected
        return result

    for name, group in collision_groups.items():
        # Auto-merge buckets keyed by iri (then qid). Rows in a bucket of
        # size >= 2 collapse to one canonical row; bucket-size 1 is a
        # standalone row inside a multi-bucket group (handled by the
        # disambiguator branch below).
        iri_buckets: dict[str, list[dict[str, Any]]] = {}
        qid_buckets: dict[str, list[dict[str, Any]]] = {}
        for r in group:
            if r["iri"]:
                iri_buckets.setdefault(r["iri"], []).append(r)
            if r["qid"]:
                qid_buckets.setdefault(r["qid"], []).append(r)

        # Step 1: collapse iri-matching duplicates. All rows in an
        # iri-bucket share name+iri but may have different qid; collapse
        # them by name+iri ALONE so divergent qids don't split the bucket.
        # (Codex review #1, 2026-05-04: matching on name+iri+qid silently
        # dropped same-iri/different-qid rows from the merge.)
        for iri_val, bucket in iri_buckets.items():
            if len(bucket) < 2:
                continue
            bucket_sorted = sorted(bucket, key=_pass3_canonical_rank)
            winner = bucket_sorted[0]
            canonical_iri, canonical_qid = _pass3_bucket_identity(bucket, winner)
            removed = _pass3_collapse_bucket(
                graph,
                name=name,
                match_dim="iri",
                match_value=iri_val,
                winner_source=winner.get("source"),
                winner_tier=winner.get("tier"),
                winner_iri=canonical_iri,
                winner_qid=canonical_qid,
            )
            result.rows_migrated += removed

        # Re-fetch the surviving rows for this `name` after iri-merge so
        # the qid branch and the disambiguator branch operate on truth.
        survivors = backend.query(  # MIGRATION-EXEMPT
            "MATCH (n:OntologyType {name: $name}) "
            "RETURN COALESCE(n.iri, '') AS iri, "
            "       COALESCE(n.wikidata_qid, '') AS qid, "
            "       n.source AS source, n.tier AS tier",
            params={"name": name},
            graph_name=graph._graph_name,
        )
        group = []
        for sr in survivors or []:
            if isinstance(sr, dict):
                group.append({
                    "iri": sr.get("iri") or "",
                    "qid": sr.get("qid") or "",
                    "source": sr.get("source"),
                    "tier": sr.get("tier"),
                })
            elif isinstance(sr, list) and len(sr) >= 4:
                group.append({
                    "iri": sr[0] or "",
                    "qid": sr[1] or "",
                    "source": sr[2],
                    "tier": sr[3],
                })

        if len(group) < 2:
            continue  # iri-merge fully resolved this group

        # Step 2: collapse qid-matching duplicates among survivors
        qid_buckets_after: dict[str, list[dict[str, Any]]] = {}
        for r in group:
            if r["qid"]:
                qid_buckets_after.setdefault(r["qid"], []).append(r)
        for qid_val, bucket in qid_buckets_after.items():
            if len(bucket) < 2:
                continue
            bucket_sorted = sorted(bucket, key=_pass3_canonical_rank)
            winner = bucket_sorted[0]
            canonical_iri, canonical_qid = _pass3_bucket_identity(bucket, winner)
            removed = _pass3_collapse_bucket(
                graph,
                name=name,
                match_dim="wikidata_qid",
                match_value=qid_val,
                winner_source=winner.get("source"),
                winner_tier=winner.get("tier"),
                winner_iri=canonical_iri,
                winner_qid=canonical_qid,
            )
            result.rows_migrated += removed

        # Step 3: re-fetch survivors a second time and disambiguate any
        # remaining collisions.
        survivors2 = backend.query(  # MIGRATION-EXEMPT
            "MATCH (n:OntologyType {name: $name}) "
            "RETURN COALESCE(n.iri, '') AS iri, "
            "       COALESCE(n.wikidata_qid, '') AS qid",
            params={"name": name},
            graph_name=graph._graph_name,
        )
        remaining: list[dict[str, str]] = []
        for sr in survivors2 or []:
            if isinstance(sr, dict):
                remaining.append({"iri": sr.get("iri") or "", "qid": sr.get("qid") or ""})
            elif isinstance(sr, list) and len(sr) >= 2:
                remaining.append({"iri": sr[0] or "", "qid": sr[1] or ""})

        if len(remaining) < 2:
            continue

        any_iri = any(r["iri"] for r in remaining)
        any_qid = any(r["qid"] for r in remaining)

        if any_iri or any_qid:
            # Disambiguate. Two sub-cases:
            #   (a) row has iri or qid → deterministic hash of that key,
            #       WHERE clause uniquely identifies the row.
            #   (b) row has neither iri nor qid (mixed group with at
            #       least one row that DOES have one) → ordinal-based
            #       suffix via WITH n LIMIT 1 SET (same pattern as the
            #       pure-blank branch below) AND HITL queue entry.
            #       Codex review #R2-3 (2026-05-04): without the
            #       per-row WITH n LIMIT 1, multiple blank rows hashed
            #       to the same `<name>|no-iri-or-qid` key and the
            #       WHERE iri='' AND qid='' WHERE clause matched all
            #       of them in one shot — collision survived.
            blank_ordinal = 0
            for r in remaining:
                key = r["iri"] or r["qid"]
                if key:
                    # Sub-case (a) — keyed disambiguation.
                    suffix = _pass3_short_iri_hash(key)
                    new_name = _pass3_resolve_disambiguator_name(graph, name, suffix)
                    backend.query(  # MIGRATION-EXEMPT
                        "MATCH (n:OntologyType {name: $name}) "
                        "WHERE COALESCE(n.iri, '') = $iri "
                        "  AND COALESCE(n.wikidata_qid, '') = $qid "
                        "SET n.name = $new_name, n.disambiguator = $suffix, "
                        "    n.migrated_at = $now",
                        params={
                            "name": name,
                            "iri": r["iri"],
                            "qid": r["qid"],
                            "new_name": new_name,
                            "suffix": suffix,
                            "now": _now_iso(),
                        },
                        graph_name=graph._graph_name,
                    )
                    result.rows_migrated += 1
                else:
                    # Sub-case (b) — blank row in mixed group. Same
                    # ordinal-rename + HITL pattern as the pure-blank
                    # branch below.
                    seed = f"{name}|mixed-blank|{blank_ordinal}"
                    suffix = _pass3_short_iri_hash(seed)
                    new_name = _pass3_resolve_disambiguator_name(graph, name, suffix)
                    backend.query(  # MIGRATION-EXEMPT
                        "MATCH (n:OntologyType {name: $name}) "
                        "WHERE COALESCE(n.iri, '') = '' "
                        "  AND COALESCE(n.wikidata_qid, '') = '' "
                        "WITH n LIMIT 1 "
                        "SET n.name = $new_name, n.disambiguator = $suffix, "
                        "    n.migrated_at = $now",
                        params={
                            "name": name,
                            "new_name": new_name,
                            "suffix": suffix,
                            "now": _now_iso(),
                        },
                        graph_name=graph._graph_name,
                    )
                    result.rows_migrated += 1
                    _enqueue_hitl(
                        graph,
                        workspace_id,
                        kind="name_conflict_unresolvable",
                        target=new_name,
                        detail={
                            "original_name": name,
                            "reason": "no iri or wikidata_qid in a mixed "
                                      "collision group — manual disambiguation "
                                      "required",
                            "suffix": suffix,
                            "ordinal": blank_ordinal,
                        },
                        dry_run=False,
                    )
                    blank_ordinal += 1
        else:
            # No iri, no qid — unresolvable. Suffix by rank position AND
            # queue HITL for curator review. The hash is a stable digest
            # of name + ordinal so re-runs are deterministic.
            for ordinal, _r in enumerate(remaining):
                # Use FalkorDB internal ordering for determinism in test
                # contexts; in production the rows are independent enough
                # that any deterministic order works for naming.
                seed = f"{name}|unresolvable|{ordinal}"
                suffix = _pass3_short_iri_hash(seed)
                new_name = _pass3_resolve_disambiguator_name(graph, name, suffix)
                # Apply to the FIRST surviving row currently named `name`;
                # successive renames remove that row from the match set so
                # we keep targeting the next bare-name row each iteration.
                backend.query(  # MIGRATION-EXEMPT
                    "MATCH (n:OntologyType {name: $name}) "
                    "WITH n LIMIT 1 "
                    "SET n.name = $new_name, n.disambiguator = $suffix, "
                    "    n.migrated_at = $now",
                    params={
                        "name": name,
                        "new_name": new_name,
                        "suffix": suffix,
                        "now": _now_iso(),
                    },
                    graph_name=graph._graph_name,
                )
                result.rows_migrated += 1
                _enqueue_hitl(
                    graph,
                    workspace_id,
                    kind="name_conflict_unresolvable",
                    target=new_name,
                    detail={
                        "original_name": name,
                        "reason": "no iri or wikidata_qid available to disambiguate",
                        "suffix": suffix,
                        "ordinal": ordinal,
                    },
                    dry_run=False,
                )

    return result


# ---------------------------------------------------------------------------
# Pass 4 — Relations → :OntologyRelation
# ---------------------------------------------------------------------------


def pass_4_relations(graph: OntologyGraph, workspace_id: str, *, dry_run: bool) -> PassResult:
    """Convert `:RelationType` definitions into the unified `:OntologyRelation`
    label, then derive `:DOMAIN` / `:RANGE` edges from existing
    `:VALID_FOR` priors.

    Two-step shape:

    1. **Relabel** every `:RelationType` row with the unified
       `:OntologyRelation` label and fill the unified schema (tier from
       legacy `status`, source='inline', layer='private',
       workspace_id, migrated_at). Mirrors Pass 1/2 for the type side.
    2. **Derive `:DOMAIN`/`:RANGE`** from `:VALID_FOR`. Each
       `(src:OntologyType)-[:VALID_FOR {relation: R}]->(dst:OntologyType)`
       row implies `(:OntologyRelation {name: R})-[:DOMAIN]->(src)` and
       `(:OntologyRelation {name: R})-[:RANGE]->(dst)`. MERGE-based;
       idempotent. The original `:VALID_FOR` edge is preserved (Pass 4b
       still needs it as the entity-pair prior).

    Taxonomy edges (`:IS_A` between `:OntologyType`) are written elsewhere
    (Tier 1 Task 12b in `OntologyGraph._upsert_taxonomy_edge`); this pass
    does not touch them.
    """
    result = PassResult(pass_id="4_relations", dry_run=dry_run)
    backend = graph._get_backend()  # MIGRATION-EXEMPT

    # Step 1: gather every :RelationType candidate not yet relabeled.
    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (n:RelationType) WHERE NOT n:OntologyRelation "
        "RETURN n.name AS name, n.status AS status",
        params={},
        graph_name=graph._graph_name,
    )
    candidates: list[tuple[str | None, str | None]] = []
    for row in (rows or []):
        if isinstance(row, dict):
            candidates.append((row.get("name"), row.get("status")))
        elif isinstance(row, list) and len(row) >= 2:
            candidates.append((row[0], row[1]))

    result.rows_inspected = len(candidates)

    if dry_run:
        result.rows_migrated = len(candidates)
        return result

    # Step 2: relabel.
    for name, status in candidates:
        if not name:
            result.rows_skipped += 1
            continue
        try:
            tier = tier_for_status(status or "provisional")
        except Exception as e:
            result.warnings.append(f"tier_for_status({status!r}) failed for {name!r}: {e}")
            tier = "working"
        backend.query(  # MIGRATION-EXEMPT
            "MATCH (n:RelationType {name: $name}) "
            "SET n:OntologyRelation, "
            "    n.tier = COALESCE(n.tier, $tier), "
            "    n.source = COALESCE(n.source, 'inline'), "
            "    n.layer = COALESCE(n.layer, 'private'), "
            "    n.workspace_id = COALESCE(n.workspace_id, $ws), "
            "    n.migrated_at = $now",
            params={"name": name, "tier": tier, "ws": workspace_id, "now": _now_iso()},
            graph_name=graph._graph_name,
        )
        result.rows_migrated += 1

    # Step 3: detect :VALID_FOR edges whose `relation` name has no
    # corresponding :OntologyRelation row. Codex review #R2-4 (2026-05-04):
    # the MERGE step's MATCH would silently skip those edges, so Pass 4
    # checkpointed clean despite incomplete derivation. Surface a warning
    # per missing relation name so the orchestrator's "warnings ⇒ no
    # checkpoint" rule keeps the pass open until the operator either
    # creates the missing :OntologyRelation rows or removes the orphan
    # :VALID_FOR edges.
    # FalkorDB doesn't support Neo4j 5's `EXISTS { ... }` subquery, so
    # use OPTIONAL MATCH + WHERE rel IS NULL to find :VALID_FOR edges
    # whose `relation` name has no corresponding :OntologyRelation row.
    orphan_rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (:OntologyType)-[v:VALID_FOR]->(:OntologyType) "
        "OPTIONAL MATCH (rel:OntologyRelation {name: v.relation}) "
        "WITH v.relation AS relation, rel "
        "WHERE rel IS NULL "
        "RETURN DISTINCT relation",
        params={},
        graph_name=graph._graph_name,
    )
    orphans: list[str] = []
    for row in (orphan_rows or []):
        if isinstance(row, dict):
            n = row.get("relation")
        elif isinstance(row, list) and row:
            n = row[0]
        else:
            n = None
        if n:
            orphans.append(n)
    for relation_name in orphans:
        result.rows_skipped += 1
        msg = (
            f":VALID_FOR edge references relation {relation_name!r} but no "
            f":OntologyRelation row exists with that name — :DOMAIN/:RANGE "
            f"derivation skipped for this relation"
        )
        result.warnings.append(msg)
        logger.warning("pass_4_relations: %s", msg)

    # Step 4: derive :DOMAIN / :RANGE edges from existing :VALID_FOR priors.
    # We MATCH on :OntologyType endpoints (Pass 1/2 already relabeled them);
    # if Pass 1/2 hasn't run, no :VALID_FOR edges have :OntologyType endpoints
    # yet and this step is a no-op (Pass 4b separately surfaces that case).
    backend.query(  # MIGRATION-EXEMPT
        "MATCH (src:OntologyType)-[v:VALID_FOR]->(dst:OntologyType) "
        "MATCH (rel:OntologyRelation {name: v.relation}) "
        "MERGE (rel)-[:DOMAIN]->(src) "
        "MERGE (rel)-[:RANGE]->(dst)",
        params={},
        graph_name=graph._graph_name,
    )

    return result


# ---------------------------------------------------------------------------
# Pass 4b — :VALID_FOR endpoint relabel (correction #8)
# ---------------------------------------------------------------------------


def pass_4b_valid_for(graph: OntologyGraph, workspace_id: str, *, dry_run: bool) -> PassResult:
    """Existing shape: `(:EntityType)-[:VALID_FOR {relation: name}]->(:EntityType)`
    (created by `seed_type_pair_edges()` at ontology_graph.py:712-748).
    Preserve the shape: relabel both endpoints (Pass 1 already did this
    via additive label set), keep the `:VALID_FOR` edge with its
    `{relation: ...}` property. Do NOT convert to `:DOMAIN`/`:RANGE` —
    those are different (relation-type-level constraints on
    `:OntologyRelation`, not entity-pair priors).

    This pass is a verification + count step; the actual relabel was
    done in Pass 1 because the endpoints ARE `:EntityType` rows.

    Endpoints that still lack `:OntologyType` (Pass 1 not yet run, or a
    new `:VALID_FOR` row appeared between passes) are surfaced as a
    warning. Per the orchestrator's "warnings ⇒ no checkpoint" rule
    this leaves Pass 4b incomplete so a follow-up run picks it up after
    Pass 1 catches up. Per `feedback_no_silent_fallbacks` — never silent.
    """
    result = PassResult(pass_id="4b_valid_for", dry_run=dry_run)
    backend = graph._get_backend()  # MIGRATION-EXEMPT

    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (a:EntityType)-[r:VALID_FOR]->(b:EntityType) "
        "RETURN a.name AS src, b.name AS dst, "
        "       a:OntologyType AS src_relabeled, "
        "       b:OntologyType AS dst_relabeled",
        params={},
        graph_name=graph._graph_name,
    )

    inspected: list[tuple[str, str, bool, bool]] = []
    for row in (rows or []):
        if isinstance(row, dict):
            inspected.append((
                row.get("src"),
                row.get("dst"),
                bool(row.get("src_relabeled")),
                bool(row.get("dst_relabeled")),
            ))
        elif isinstance(row, list) and len(row) >= 4:
            inspected.append((row[0], row[1], bool(row[2]), bool(row[3])))

    result.rows_inspected = len(inspected)

    for src, dst, src_ok, dst_ok in inspected:
        if src_ok and dst_ok:
            result.rows_migrated += 1
            continue
        result.rows_skipped += 1
        missing = []
        if not src_ok:
            missing.append(f"src={src!r}")
        if not dst_ok:
            missing.append(f"dst={dst!r}")
        msg = (
            f"VALID_FOR endpoint missing :OntologyType ({', '.join(missing)}) — "
            "run Pass 1 / Pass 2 first"
        )
        result.warnings.append(msg)
        logger.warning("pass_4b_valid_for: %s", msg)

    return result


# ---------------------------------------------------------------------------
# Pass 5 — Instance edges
# ---------------------------------------------------------------------------


def pass_5_instance_edges(graph: OntologyGraph, workspace_id: str, *, dry_run: bool) -> PassResult:
    """Walk `:Entity` nodes; create `(:Entity)-[:INSTANCE_OF]->(:OntologyType)`
    edges by resolving type-name strings (idempotent — uses MERGE).

    Single-pass with `:MigrationState.passes_5_progress` checkpoint
    (workspace partitioning deferred per status.md decision).

    An `:Entity` is eligible if:
      - It carries a `type` string property naming an existing
        `:OntologyType` (post Pass 1/2). The match is by `name`.
      - It has no existing `:INSTANCE_OF` edge to that target (MERGE handles it).

    Skipped (no edge, surfaced as warning):
      - `:Entity` without a `type` property.
      - `:Entity` whose `type` doesn't resolve to any `:OntologyType.name`.

    Per `feedback_no_silent_fallbacks`, every skip emits a warning so
    the orchestrator's "warnings ⇒ no checkpoint" rule keeps the pass
    incomplete while there's data the operator should look at.
    """
    result = PassResult(pass_id="5_instance_edges", dry_run=dry_run)
    backend = graph._get_backend()  # MIGRATION-EXEMPT

    # Step 1: enumerate entities and their declared type-name string.
    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (e:Entity) RETURN e.name AS name, e.type AS type_name",
        params={},
        graph_name=graph._graph_name,
    )
    entities: list[tuple[str | None, str | None]] = []
    for row in (rows or []):
        if isinstance(row, dict):
            entities.append((row.get("name"), row.get("type_name")))
        elif isinstance(row, list) and len(row) >= 2:
            entities.append((row[0], row[1]))

    result.rows_inspected = len(entities)

    if dry_run:
        # In dry-run we report inspected but don't try to resolve types
        # (resolving would still touch the graph for the MATCH; counting
        # alone is the right shape).
        result.rows_migrated = sum(1 for _, t in entities if t)
        return result

    # Step 2: enumerate :OntologyType names once; resolution is in-Python.
    type_rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (t:OntologyType) RETURN t.name AS name",
        params={},
        graph_name=graph._graph_name,
    )
    known_types: set[str] = set()
    for r in (type_rows or []):
        if isinstance(r, dict):
            n = r.get("name")
        elif isinstance(r, list) and r:
            n = r[0]
        else:
            n = None
        if n:
            known_types.add(n)

    for entity_name, type_name in entities:
        if not entity_name:
            result.rows_skipped += 1
            continue
        if not type_name:
            result.rows_skipped += 1
            msg = f"entity {entity_name!r} has no `type` property — skipping :INSTANCE_OF"
            result.warnings.append(msg)
            logger.warning("pass_5_instance_edges: %s", msg)
            continue
        if type_name not in known_types:
            result.rows_skipped += 1
            msg = (
                f"entity {entity_name!r} declares type {type_name!r} but no "
                f":OntologyType row resolves that name — unresolvable, skipping"
            )
            result.warnings.append(msg)
            logger.warning("pass_5_instance_edges: %s", msg)
            continue

        # MERGE creates the edge if absent; idempotent across re-runs.
        # Layer-ranked LIMIT 1 picks a single deterministic target when
        # multiple :OntologyType rows share the type-name (e.g. a
        # private-layer 'Person' from Pass 1 plus a public-layer
        # 'Person' from Pass 6). Codex review #5 (2026-05-04): without
        # the layer-ranked LIMIT, Pass 5 would create N edges per entity
        # (one per matching type), which violates the layer-policy
        # contract (effective resolution = private > domain > public).
        # Track whether MERGE actually created a new edge by counting
        # before vs after (FalkorDB doesn't return create-vs-match).
        before = backend.query(  # MIGRATION-EXEMPT
            "MATCH (e:Entity {name: $en})-[r:INSTANCE_OF]->(:OntologyType {name: $tn}) "
            "RETURN count(r) AS c",
            params={"en": entity_name, "tn": type_name},
            graph_name=graph._graph_name,
        )
        head = before[0] if before else None
        before_c = int(head.get("c") if isinstance(head, dict) else (head[0] if head else 0))

        backend.query(  # MIGRATION-EXEMPT
            "MATCH (e:Entity {name: $en}) "
            "MATCH (t:OntologyType {name: $tn}) "
            "WITH e, t "
            "ORDER BY CASE COALESCE(t.layer, 'public') "
            "         WHEN 'private' THEN 0 "
            "         WHEN 'domain' THEN 1 "
            "         WHEN 'public' THEN 2 "
            "         ELSE 3 END "
            "LIMIT 1 "
            "MERGE (e)-[:INSTANCE_OF]->(t)",
            params={"en": entity_name, "tn": type_name},
            graph_name=graph._graph_name,
        )

        if before_c == 0:
            result.rows_migrated += 1
        else:
            result.rows_skipped += 1  # already linked, MERGE was a no-op

    # Step 3: write/update intra-pass progress checkpoint. Single-pass
    # implementation (per status.md decision #1, workspace partitioning
    # deferred), but we record completion-of-walk so re-runs can detect
    # "Pass 5 already swept this workspace once" if they want richer
    # idempotency than MERGE alone provides.
    backend.query(  # MIGRATION-EXEMPT
        "MERGE (m:MigrationState {workspace_id: $ws, kind: 'ontology_unify'}) "
        "SET m.passes_5_progress = $now",
        params={"ws": workspace_id, "now": _now_iso()},
        graph_name=graph._graph_name,
    )

    return result


# ---------------------------------------------------------------------------
# Pass 6 — Public-layer seed
# ---------------------------------------------------------------------------


def pass_6_public_seed(graph: OntologyGraph, workspace_id: str, *, dry_run: bool) -> PassResult:
    """Bootstrap `:OntologyType` nodes from `PublicKnowledgeStore` outputs
    (Wikidata-derived, with QIDs and IRIs populated).

    This wraps `OntologyService.bootstrap_wikidata_seed()` behind the
    migration's `:MigrationState` checkpoint. The bootstrap method is
    itself idempotent (`_upsert_ontology_type` is never-demote per the
    Task 2 contract), so replays produce the same row set without
    clobbering operator-promoted seeds.

    Dry-run reports the projected row count from `WIKIDATA_TYPE_MAP`
    without invoking the bootstrap.
    """
    result = PassResult(pass_id="6_public_seed", dry_run=dry_run)
    from smartmemory.grounding.type_map import WIKIDATA_TYPE_MAP

    projected = len(set(WIKIDATA_TYPE_MAP.values()))
    result.rows_inspected = projected

    if dry_run:
        result.rows_migrated = projected
        return result

    # Construct a minimally-bound OntologyService for the bootstrap.
    # `ontology_registry` is unused by `bootstrap_wikidata_seed`. The
    # scope provider supplies `workspace_id` for the drift-check read.
    from smartmemory.ontology.service import OntologyService  # MIGRATION-EXEMPT (orchestration)
    from smartmemory.scope_provider import DefaultScopeProvider  # MIGRATION-EXEMPT (orchestration)

    service = OntologyService(
        scope_provider=DefaultScopeProvider(workspace_id=workspace_id, user_id="migration_script"),
        ontology_graph=graph,
        ontology_registry=None,
    )
    try:
        written = service.bootstrap_wikidata_seed()
    except Exception as e:
        msg = f"bootstrap_wikidata_seed failed: {e}"
        result.warnings.append(msg)
        logger.warning("pass_6_public_seed: %s", msg)
        return result

    result.rows_migrated = int(written)
    return result


# ---------------------------------------------------------------------------
# Pass 7 — Audit log seed
# ---------------------------------------------------------------------------


def pass_7_audit_log(graph: OntologyGraph, workspace_id: str, *, dry_run: bool) -> PassResult:
    """Synthesize one `:OntologyAudit` entry per migrated node (action='migrated',
    actor='migration_script', evidence_ref=<delta_report_id>).

    Targets nodes with `n.migrated_at IS NOT NULL` and no prior audit
    entry with `action='migrated'` (idempotent on re-run)."""
    result = PassResult(pass_id="7_audit_log", dry_run=dry_run)
    backend = graph._get_backend()  # MIGRATION-EXEMPT

    rows = backend.query(  # MIGRATION-EXEMPT
        "MATCH (n:OntologyType) WHERE n.migrated_at IS NOT NULL "
        "RETURN n.name AS name, n.tier AS tier, n.source AS source, "
        "n.layer AS layer, n.migrated_at AS migrated_at",
        params={},
        graph_name=graph._graph_name,
    )
    targets: list[dict[str, Any]] = []
    for row in (rows or []):
        if isinstance(row, dict):
            targets.append({k: row.get(k) for k in ("name", "tier", "source", "layer", "migrated_at")})
        elif isinstance(row, list) and len(row) >= 5:
            targets.append({"name": row[0], "tier": row[1], "source": row[2], "layer": row[3], "migrated_at": row[4]})
    result.rows_inspected = len(targets)

    if dry_run:
        result.rows_migrated = len(targets)
        return result

    # Idempotency: skip if an audit row with action='migrated' already
    # exists for this target.
    for t in targets:
        nm = t.get("name")
        if not nm:
            result.rows_skipped += 1
            continue
        existing = backend.query(  # MIGRATION-EXEMPT
            "MATCH (a:OntologyAudit {target_type_id: $tid, action: 'migrated'}) "
            "RETURN a LIMIT 1",
            params={"tid": nm},
            graph_name=graph._graph_name,
        )
        if existing:
            result.rows_skipped += 1
            continue
        after_json = json.dumps(
            {"tier": t.get("tier"), "source": t.get("source"), "layer": t.get("layer")}
        )
        # ONTO-AUDIT-WS-1 follow-up (Codex 2026-05-09 finding #2): scope
        # migration audit rows by workspace_id, matching the per-tenant
        # invariant `_write_audit_entry()` persists for runtime writes.
        backend.query(  # MIGRATION-EXEMPT
            "CREATE (a:OntologyAudit {"
            "actor: 'migration_script', action: 'migrated', "
            "target_type_id: $tid, after_json: $after, "
            "evidence_ref: $evidence, ts: $now, workspace_id: $ws"
            "})",
            params={
                "tid": nm,
                "after": after_json,
                "evidence": f"workspace={workspace_id} migrated_at={t.get('migrated_at')}",
                "now": _now_iso(),
                "ws": workspace_id,
            },
            graph_name=graph._graph_name,
        )
        result.rows_migrated += 1

    return result


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


PASS_FUNCS = {
    "0_audit": pass_0_audit,
    "1_entity_types": pass_1_entity_types,
    "2_concepts": pass_2_concepts,
    "3_conflicts": pass_3_conflicts,
    "4_relations": pass_4_relations,
    "4b_valid_for": pass_4b_valid_for,
    "5_instance_edges": pass_5_instance_edges,
    "6_public_seed": pass_6_public_seed,
    "7_audit_log": pass_7_audit_log,
}


def run_migration(
    graph: OntologyGraph,
    workspace_id: str,
    *,
    only_pass: str | None = None,
    registry_concepts: list[dict[str, Any]] | None = None,
    delta_report_dir: Path | None = None,
    dry_run: bool = True,
) -> MigrationReport:
    """Execute migration passes in order, honoring `:MigrationState`
    checkpoints. Re-runs skip already-completed passes (unless
    `only_pass` is set, which forces re-run of just that one).
    """
    report = MigrationReport(
        started_at=_now_iso(), workspace_id=workspace_id, dry_run=dry_run
    )
    completed = _read_completed_passes(graph, workspace_id)
    selected = (only_pass,) if only_pass else PASS_IDS

    # Auto-pause ingest for apply runs that touch the live graph (plan §340).
    # Dry-runs never mutate, so they do not pause. Single-pass apply runs
    # (only_pass) DO pause — partial migrations still need exclusivity from
    # live writes, since they leave the schema half-relabeled.
    if not dry_run:
        pause_ingest(graph, workspace_id)

    try:
        _run_passes_inner(graph, workspace_id, selected, completed, only_pass,
                          registry_concepts, delta_report_dir, dry_run, report)
    finally:
        # Always unpause on exit, even if a pass raised. The unpause is
        # wrapped in its own try/except so that if the unpause itself
        # fails (FalkorDB unreachable, transient backend error), it
        # neither masks the original pass exception nor leaves the
        # operator with no way to recover. Codex review #4 (2026-05-04):
        # an unguarded `finally: unpause_ingest(...)` would replace the
        # real error with the unpause's error AND still leave
        # ingest_paused=true on the last committed state.
        if not dry_run:
            try:
                unpause_ingest(graph, workspace_id)
            except Exception as unpause_err:  # noqa: BLE001
                logger.error(
                    "run_migration: unpause_ingest failed for workspace %r "
                    "(%s); ingest may be left paused — recover via "
                    "`scripts/migrate_ontology_unify.py --unpause-ingest "
                    "--workspace %s`",
                    workspace_id, unpause_err, workspace_id,
                )
                # Do NOT re-raise — preserve the original exception
                # propagating out of the try block (if any).

    report.finished_at = _now_iso()
    return report


def _run_passes_inner(
    graph: OntologyGraph,
    workspace_id: str,
    selected: tuple[str, ...],
    completed: set[str],
    only_pass: str | None,
    registry_concepts: list[dict[str, Any]] | None,
    delta_report_dir: Path | None,
    dry_run: bool,
    report: MigrationReport,
) -> None:
    """Inner pass-execution loop, factored out so the auto-pause try/finally
    in `run_migration` stays readable."""
    for pid in selected:
        if pid not in PASS_FUNCS:
            logger.warning("Unknown pass_id: %s — skipping", pid)
            continue
        if pid in completed and only_pass is None:
            logger.info("Pass %s already complete — skipping", pid)
            continue
        logger.info("Running pass %s (dry_run=%s)", pid, dry_run)
        kwargs: dict[str, Any] = {"dry_run": dry_run}
        if pid == "0_audit":
            kwargs["registry_concepts"] = registry_concepts
            kwargs["delta_report_dir"] = delta_report_dir
        try:
            result = PASS_FUNCS[pid](graph, workspace_id, **kwargs)
        except NotImplementedError as e:
            logger.warning("Pass %s not yet implemented: %s", pid, e)
            result = PassResult(pass_id=pid, dry_run=dry_run)
            result.warnings.append(f"not_implemented: {e}")
        report.passes[pid] = result
        if not result.warnings:
            _mark_pass_complete(graph, workspace_id, pid, dry_run=dry_run)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--workspace", required=True, help="Workspace ID to migrate")
    parser.add_argument("--apply", action="store_true", help="Apply changes (default: dry-run)")
    parser.add_argument("--dry-run", action="store_true", help="Explicit dry-run (default behavior)")
    parser.add_argument("--pass", dest="only_pass", help="Run a single pass id (e.g. 1_entity_types)")
    parser.add_argument("--status", action="store_true", help="Show :MigrationState and exit")
    parser.add_argument("--report-dir", default="./migration_reports", help="Delta report output dir")
    parser.add_argument(
        "--pause-ingest",
        action="store_true",
        help="Set :MigrationState.ingest_paused=true and exit "
             "(use to manually open a maintenance window)",
    )
    parser.add_argument(
        "--unpause-ingest",
        action="store_true",
        help="Clear :MigrationState.ingest_paused and exit "
             "(recovery from interrupted migration)",
    )
    parser.add_argument(
        "--health",
        action="store_true",
        help="Phase 6: print substrate soak-health JSON and exit "
             "(operator daily probe during Task 10 soak window)",
    )
    parser.add_argument(
        "--health-hitl-days",
        type=int,
        default=7,
        help="HITL stability window in days (default 7) — soak unhealthy "
             "if any :OntologyHITLQueue row newer than this exists",
    )
    parser.add_argument(
        "--audit-summary",
        action="store_true",
        help="Phase 6: print :OntologyAudit aggregation JSON over [--since, --until] window and exit",
    )
    parser.add_argument(
        "--since",
        help="ISO-8601 lower bound for --audit-summary (inclusive). Required with --audit-summary.",
    )
    parser.add_argument(
        "--until",
        help="ISO-8601 upper bound for --audit-summary (inclusive). Default open-ended.",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    graph = OntologyGraph()

    if args.status:
        completed = _read_completed_passes(graph, args.workspace)
        paused = is_ingest_paused(graph, args.workspace)
        # Codex review #R2-6 (2026-05-04): surface stale Pass-3 markers
        # so operators don't have to know the recovery Cypher by heart.
        # A non-zero count here means a previous Pass 3 attempt's cleanup
        # failed; recovery is the Cypher in the cleanup error log.
        try:
            backend = graph._get_backend()
            stale_rows = backend.query(
                "MATCH (n:OntologyType) "
                "WHERE n._pass3_survivor IS NOT NULL OR n._pass3_drop IS NOT NULL "
                "RETURN count(n) AS c",
                graph_name=graph._graph_name,
            )
            head = stale_rows[0] if stale_rows else None
            stale_count = int(head.get("c") if isinstance(head, dict) else (head[0] if head else 0))
        except Exception:  # noqa: BLE001
            stale_count = None
        print(json.dumps({
            "workspace_id": args.workspace,
            "completed_passes": sorted(completed),
            "ingest_paused": paused,
            "stale_pass3_markers": stale_count,
        }, indent=2))
        return 0

    if args.pause_ingest:
        pause_ingest(graph, args.workspace)
        print(json.dumps({"workspace_id": args.workspace, "ingest_paused": True}))
        return 0

    if args.unpause_ingest:
        unpause_ingest(graph, args.workspace)
        print(json.dumps({"workspace_id": args.workspace, "ingest_paused": False}))
        return 0

    if args.health:
        # Bind graph to per-workspace graph_name so audit_invariant + residual
        # checks query the correct FalkorDB graph (Codex review #2 — top-level
        # `OntologyGraph()` has no workspace and would fall back to the default
        # graph, masking real audit-row counts).
        ws_graph = OntologyGraph(workspace_id=args.workspace)
        report = compute_health_report(ws_graph, args.workspace, hitl_days=args.health_hitl_days)
        print(json.dumps(report.to_dict(), indent=2))
        return 0

    if args.audit_summary:
        if not args.since:
            print(json.dumps({"error": "--audit-summary requires --since=<ISO-8601>"}), file=sys.stderr)
            return 2
        from smartmemory.ontology.service import OntologyService
        from smartmemory.scope_provider import DefaultScopeProvider
        # Service-layer call — substrate is bound to the operator's workspace.
        # Re-bind the graph to the per-workspace graph_name (the default
        # `OntologyGraph()` constructed at top of `main` lacks workspace_id;
        # see the workspace-scoped test fixtures in
        # `test_migration_ontology_unify_health.py`).
        ws_graph = OntologyGraph(workspace_id=args.workspace)
        scope = DefaultScopeProvider(workspace_id=args.workspace)
        service = OntologyService(
            scope_provider=scope,
            ontology_graph=ws_graph,
            ontology_registry=None,
            layer_resolver=None,
        )
        try:
            result = service.get_audit_summary(since=args.since, until=args.until)
        except ValueError as e:
            print(json.dumps({"error": str(e)}), file=sys.stderr)
            return 2
        result["workspace_id"] = args.workspace
        print(json.dumps(result, indent=2))
        return 0

    dry = not args.apply
    report = run_migration(
        graph,
        args.workspace,
        only_pass=args.only_pass,
        delta_report_dir=Path(args.report_dir),
        dry_run=dry,
    )
    print(json.dumps(report.to_dict(), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
