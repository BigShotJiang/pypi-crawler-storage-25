#!/usr/bin/env python3
"""
ONTO-TEST-1 — Cutover validation harness for ONTO-RECONCILE-1 Task 11.

Replaces the calendar-based soak with an active probe: seed N synthetic
workspaces with dual-labeled :EntityType:OntologyType nodes, run Task 11's
label-drop locally per workspace, probe every known ontology read path,
then run real SmartMemory.ingest() to confirm post-cutover write paths
still function. If green across all probes, fleet-wide Task 11 may proceed.

Design: smart-memory-docs/docs/features/ONTO-TEST-1/design.md

Key architectural fact verified during design (review iteration 2):
workspace isolation is by graph NAME (`ws_<id>_ontology`), not by
workspace_id property on type/concept nodes. Cypher MUST target the
per-workspace graph, not filter by property — property-filter would
match zero rows on type nodes and the script would silently green.

Usage:
    python scripts/test_cutover_onto_reconcile_1.py
    python scripts/test_cutover_onto_reconcile_1.py --workspaces 1 --skip-real-ingest
    python scripts/test_cutover_onto_reconcile_1.py --keep-on-failure
"""

from __future__ import annotations

import argparse
import logging
import sys
import uuid
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("onto-test-1")

# 6 distinct entity types × 5 occurrences each = 30 writes/workspace.
# 5x repetition triggers frequency-based tier promotion past tier-1.
SEED_ENTITY_TYPES: list[tuple[str, str]] = [
    ("espresso machine", "Appliance"),
    ("Lisbon", "Location"),
    ("Pragmatic Programmer", "Book"),
    ("Tagus river", "Location"),
    ("FalkorDB", "Technology"),
    ("Maya", "Project"),
]
SEED_REPETITIONS = 5

POST_INGEST_MEMORIES = [
    "Booked a return trip to Porto for September.",
    "The new espresso machine pulls a 30-second double shot consistently.",
    "Started reading 'A Philosophy of Software Design' on the flight.",
    "FalkorDB 4.6 ships graph-level statistics in EXPLAIN output.",
    "Maya's onboarding flow now stores anchor on first session start.",
]


@dataclass
class WorkspaceResult:
    workspace_id: str
    graph_name: str
    seed_writes: int = 0
    pre_legacy_count: int = 0
    pre_unified_count: int = 0
    pre_dual_count: int = 0
    pre_concept_count: int = 0
    pre_unmigrated_count: int = 0
    cutover_labels_removed: int = 0
    post_legacy_count: int = 0
    post_unified_count: int = 0
    probe_results: dict[str, Any] = field(default_factory=dict)
    post_ingest_count: int = 0
    bleed_check_passed: bool | None = None
    teardown_ok: bool | None = None
    failures: list[str] = field(default_factory=list)

    @property
    def green(self) -> bool:
        return not self.failures


def _make_workspace_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def seed_workspace(og, backend, graph_name: str,
                   name_label_pairs: list[tuple[str, str]], reps: int, ws_id: str) -> int:
    """Direct dual-labeled writes via the migration's canonical primitive.

    After bulk MERGE, set `tier='confirmed'` on every type node so the
    seed shape matches post-migration production state (Pass 1 of
    migrate_ontology_unify.py adds :OntologyType + tier via tier_for_status;
    the inline primitive only does the dual-label MERGE).
    """
    writes = 0
    for _ in range(reps):
        for name, label in name_label_pairs:
            ok = og._upsert_inline_ontology_pattern(
                name=name,
                label=label,
                confidence=0.9,
                workspace_id=ws_id,
                is_global=False,
                source="onto-test-1-seed",
                initial_count=1,
            )
            if ok:
                writes += 1
    # Set tier on the type nodes to mirror post-migration shape
    cypher(backend, graph_name,
           "MATCH (t:EntityType:OntologyType) WHERE t.tier IS NULL "
           "SET t.tier = 'confirmed'")
    return writes


def cypher(backend, graph_name: str, query: str, params: dict | None = None) -> Any:
    """Wrapper that returns the raw FalkorDB response so we can read counters."""
    return backend.query(query, params=params or {}, graph_name=graph_name)


def count_label_state(backend, graph_name: str, ws_label: str = "EntityType") -> dict[str, int]:
    """Pre/post snapshot of the label partition for one workspace graph.

    Returns counts for {legacy_only, unified_only, dual, concept, untiered}.
    """
    out = {}
    # Legacy-only (would-be stragglers if any)
    r = cypher(backend, graph_name,
               f"MATCH (n:{ws_label}) WHERE NOT n:OntologyType RETURN count(n) AS c")
    out["legacy_only"] = _scalar(r)
    # Unified-only (post-cutover state)
    r = cypher(backend, graph_name,
               f"MATCH (n:OntologyType) WHERE NOT n:{ws_label} AND NOT n:Concept RETURN count(n) AS c")
    out["unified_only"] = _scalar(r)
    # Dual-labeled (pre-cutover state)
    r = cypher(backend, graph_name,
               f"MATCH (n:{ws_label}:OntologyType) RETURN count(n) AS c")
    out["dual"] = _scalar(r)
    # :Concept (must remain visible in concept_count)
    r = cypher(backend, graph_name,
               "MATCH (n:Concept) RETURN count(n) AS c")
    out["concept"] = _scalar(r)
    # Untiered (no silent drops — feedback_no_silent_fallbacks)
    r = cypher(backend, graph_name,
               "MATCH (n:OntologyType) WHERE n.tier IS NULL AND NOT n:Concept RETURN count(n) AS c")
    out["untiered"] = _scalar(r)
    return out


def _scalar(falkor_result) -> int:
    """Pull the first scalar from a FalkorDB query response."""
    if not falkor_result:
        return 0
    rows = falkor_result if isinstance(falkor_result, list) else getattr(falkor_result, "result_set", [])
    if not rows:
        return 0
    first = rows[0]
    if isinstance(first, list) and first:
        return int(first[0])
    if isinstance(first, dict):
        for v in first.values():
            return int(v)
    try:
        return int(first)
    except Exception:
        return 0


def run_task_11_locally(backend, graph_name: str) -> int:
    """Strip :EntityType / :Concept from dual-labeled nodes in this workspace graph.

    Returns the total count of nodes that lost a legacy label, computed via
    count-before-vs-count-after diff. We don't try to parse FalkorDB's
    `Labels removed: N` stat line because `backend.query()` strips it; the
    diff approach is more robust and the same effective signal.

    A zero result is a hard failure — silent no-op is the failure mode
    this whole feature exists to catch.
    """
    removed = 0
    for legacy_label in ("EntityType", "Concept"):
        # WHERE n:OntologyType ensures we never strip from un-migrated rows.
        before = _count(backend, graph_name,
                        f"MATCH (n:{legacy_label}) WHERE n:OntologyType RETURN count(n) AS c")
        cypher(backend, graph_name,
               f"MATCH (n:{legacy_label}) WHERE n:OntologyType REMOVE n:{legacy_label}")
        after = _count(backend, graph_name,
                       f"MATCH (n:{legacy_label}) WHERE n:OntologyType RETURN count(n) AS c")
        removed += (before - after)
    return removed


def _count(backend, graph_name: str, q: str) -> int:
    return _scalar(cypher(backend, graph_name, q))


def probe_read_paths(og, backend, graph_name: str, ws_id: str) -> dict[str, Any]:
    """Run every known ontology reader and assert it returns sensible results.

    These are the readers listed in the design's step 5. If any returns
    an empty result where we just seeded data, post-cutover read path is
    broken and Task 11 is unsafe to roll fleet-wide.
    """
    results: dict[str, Any] = {}

    # Reader 1: OntologyGraph.get_entity_types() — legacy adapter, must
    # still find data via the dual-labeled MATCH despite stripped labels.
    try:
        types = og.get_entity_types()
        results["get_entity_types_count"] = len(types) if types else 0
        results["get_entity_types_sample"] = [t.get("name") for t in (types or [])[:3]]
    except Exception as e:
        results["get_entity_types_error"] = repr(e)

    # Reader 2: type assignments for one of our seeded labels
    try:
        assigns = og.get_type_assignments("Lisbon")
        results["get_type_assignments_count"] = len(assigns) if assigns else 0
    except Exception as e:
        results["get_type_assignments_error"] = repr(e)

    # Reader 3: raw label probe — dual-labeled MATCH should still return data
    # (this validates the production read fallback path in ontology_graph.py)
    r = cypher(backend, graph_name,
               "MATCH (t:EntityType:OntologyType) RETURN t.name AS name LIMIT 5")
    rows = r if isinstance(r, list) else getattr(r, "result_set", [])
    results["dual_match_probe_count"] = len(rows or [])

    # Reader 4: pure :OntologyType MATCH should pick up the now-stripped nodes
    r = cypher(backend, graph_name,
               "MATCH (t:OntologyType) WHERE NOT t:Concept RETURN count(t) AS c")
    results["unified_match_count"] = _scalar(r)

    return results


def cross_tenant_bleed_check(backend, ws_prefix: str) -> bool:
    """Ensure no test-prefixed nodes leaked into shared graphs.

    Hits `ontology` and `smartmemory` — the two known shared graphs.
    """
    for shared in ("ontology", "smartmemory"):
        try:
            r = cypher(backend, shared,
                       f"MATCH (n) WHERE n.workspace_id STARTS WITH '{ws_prefix}' "
                       f"RETURN count(n) AS c")
            if _scalar(r) > 0:
                logger.error("BLEED: %s rows with prefix %r in shared graph %r",
                             _scalar(r), ws_prefix, shared)
                return False
        except Exception as e:
            logger.warning("Bleed check skipped on %s: %s", shared, e)
    return True


def teardown_workspace(backend, graph_name: str) -> bool:
    """Atomic graph drop via the falkordb-py client.

    `backend.graph.delete()` calls the underlying FalkorDB GRAPH.DELETE
    on the graph the backend was initialized with. Atomic, label-agnostic,
    drops indices too.
    """
    try:
        backend.graph.delete()
        return True
    except Exception as e:
        logger.error("Teardown failed for %s: %s", graph_name, e)
        return False


def run_workspace(prefix: str, skip_real_ingest: bool) -> WorkspaceResult:
    from smartmemory.graph.backends.falkordb import FalkorDBBackend
    from smartmemory.graph.ontology_graph import OntologyGraph

    ws_id = _make_workspace_id(prefix)
    graph_name = f"ws_{ws_id}_ontology"
    res = WorkspaceResult(workspace_id=ws_id, graph_name=graph_name)
    logger.info("=== workspace %s (graph %s) ===", ws_id, graph_name)

    backend = FalkorDBBackend(graph_name=graph_name)
    og = OntologyGraph(workspace_id=ws_id, backend=backend)

    # 1. Seed
    res.seed_writes = seed_workspace(og, backend, graph_name,
                                     SEED_ENTITY_TYPES, SEED_REPETITIONS, ws_id)
    logger.info("  seeded %d writes", res.seed_writes)
    if res.seed_writes == 0:
        res.failures.append("seed produced 0 writes")
        return res

    # 2. Pre-cutover snapshot
    pre = count_label_state(backend, graph_name)
    res.pre_legacy_count = pre["legacy_only"]
    res.pre_unified_count = pre["unified_only"]
    res.pre_dual_count = pre["dual"]
    res.pre_concept_count = pre["concept"]
    res.pre_unmigrated_count = pre["legacy_only"]
    logger.info("  pre-cutover: %s", pre)
    if pre["dual"] == 0:
        res.failures.append("pre-cutover dual-label count is 0 — seed didn't dual-label")
        return res

    # 3. Local Task 11
    res.cutover_labels_removed = run_task_11_locally(backend, graph_name)
    logger.info("  cutover removed %d labels", res.cutover_labels_removed)
    if res.cutover_labels_removed == 0:
        res.failures.append(
            "Task 11 removed 0 labels — silent-success failure mode "
            "(would have shipped fleet-wide as 'green' without doing anything)"
        )
        return res

    # 4. Post-cutover snapshot
    post = count_label_state(backend, graph_name)
    res.post_legacy_count = post["legacy_only"]
    res.post_unified_count = post["unified_only"]
    logger.info("  post-cutover: %s", post)
    if post["legacy_only"] > 0:
        res.failures.append(f"post-cutover has {post['legacy_only']} legacy-only nodes (Task 11 incomplete)")
    if post["dual"] > 0:
        res.failures.append(f"post-cutover has {post['dual']} dual-labeled nodes (Task 11 incomplete)")

    # 5. Read-path probes (must work post-cutover)
    res.probe_results = probe_read_paths(og, backend, graph_name, ws_id)
    logger.info("  probes: %s", res.probe_results)
    # Acceptance: get_entity_types() returns one row per UNIQUE type label
    # (not per seeded tuple — duplicate labels in the seed coalesce on MERGE).
    expected_unique_types = len({label for _, label in SEED_ENTITY_TYPES})
    if res.probe_results.get("get_entity_types_count", 0) < expected_unique_types:
        res.failures.append(
            f"get_entity_types() returned "
            f"{res.probe_results.get('get_entity_types_count', 0)} "
            f"after cutover (expected ≥{expected_unique_types} unique type labels)"
        )
    if res.probe_results.get("unified_match_count", 0) == 0:
        res.failures.append("unified :OntologyType MATCH returned 0 rows post-cutover")

    # 6. Post-cutover real ingest (the one place we hit the LLM)
    if skip_real_ingest:
        logger.info("  skipping real-ingest probe (--skip-real-ingest)")
    else:
        try:
            from smartmemory import SmartMemory
            sm = SmartMemory(workspace_id=ws_id)
            for memory_text in POST_INGEST_MEMORIES:
                sm.ingest(memory_text)
                res.post_ingest_count += 1
            logger.info("  real ingest: %d successes", res.post_ingest_count)
        except Exception as e:
            res.failures.append(f"post-cutover ingest failed: {e!r}")

    return res


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspaces", type=int, default=3)
    parser.add_argument("--prefix", type=str, default="onto-test")
    parser.add_argument("--skip-real-ingest", action="store_true",
                        help="Skip post-cutover real LLM ingest (for fast iteration)")
    parser.add_argument("--keep-on-failure", action="store_true",
                        help="Don't tear down test graphs if anything fails (for debugging)")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    logger.info("ONTO-TEST-1 starting: %d workspaces, prefix=%s, real_ingest=%s",
                args.workspaces, args.prefix, not args.skip_real_ingest)

    results: list[WorkspaceResult] = []
    for _ in range(args.workspaces):
        results.append(run_workspace(args.prefix, args.skip_real_ingest))

    # Cross-tenant bleed check (against shared graphs)
    from smartmemory.graph.backends.falkordb import FalkorDBBackend
    bleed_backend = FalkorDBBackend(graph_name="ontology")
    bleed_ok = cross_tenant_bleed_check(bleed_backend, args.prefix)
    for r in results:
        r.bleed_check_passed = bleed_ok
        if not bleed_ok:
            r.failures.append("cross-tenant bleed detected")

    # Teardown (skip for failed workspaces if --keep-on-failure)
    for r in results:
        if r.failures and args.keep_on_failure:
            logger.warning("KEEPING %s for debugging (use GRAPH.DELETE %s to clean)",
                           r.workspace_id, r.graph_name)
            r.teardown_ok = None
            continue
        r.teardown_ok = teardown_workspace(
            FalkorDBBackend(graph_name=r.graph_name), r.graph_name
        )
        logger.info("  teardown %s: %s", r.workspace_id,
                    "OK" if r.teardown_ok else "FAILED")

    # Summary
    print("\n" + "=" * 70)
    print(f"ONTO-TEST-1 RESULTS — {len(results)} workspace(s)")
    print("=" * 70)
    for r in results:
        status = "GREEN" if r.green else "RED"
        print(f"  [{status}] {r.workspace_id}")
        print(f"    seed={r.seed_writes} dual={r.pre_dual_count} "
              f"removed={r.cutover_labels_removed} "
              f"post_unified={r.post_unified_count} "
              f"post_ingest={r.post_ingest_count} "
              f"teardown={'OK' if r.teardown_ok else 'SKIP/FAIL'}")
        for f in r.failures:
            print(f"    ! {f}")

    all_green = all(r.green for r in results)
    print("=" * 70)
    print("VERDICT: " + ("GO — Task 11 may roll fleet-wide" if all_green
                         else "NO-GO — see failures above"))
    print("=" * 70)
    sys.exit(0 if all_green else 1)


if __name__ == "__main__":
    main()
