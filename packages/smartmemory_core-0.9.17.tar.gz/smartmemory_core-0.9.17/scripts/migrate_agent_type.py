"""CORE-AGENT-1: Migration script — seed Agent/Environment types and create AGENT entity nodes.

Two operations:
1. Seed 'Agent' and 'Environment' entity types into all existing ontology graphs.
2. Create :Agent entity nodes for existing active agents in MongoDB.
3. Create EntityPatterns for each migrated agent.

Idempotent — safe to run multiple times.

Usage:
    python scripts/migrate_agent_type.py
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
from datetime import datetime, timezone

# Ensure smartmemory is importable when running standalone
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from smartmemory.graph.ontology_graph import OntologyGraph
from smartmemory.graph.smartgraph import SmartGraph
from smartmemory.scope_provider import DefaultScopeProvider
from smartmemory.utils.deduplication import get_canonical_key

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)


def _get_mongo_db():
    """Connect to MongoDB using env vars."""
    from pymongo import MongoClient

    host = os.getenv("MONGODB_HOST", "localhost")
    port = int(os.getenv("MONGODB_PORT", "9013"))
    client = MongoClient(host, port)
    return client.smartmemory


def _get_workspace_ids(db) -> list[str]:
    """Get distinct workspace/team IDs from existing agents."""
    team_ids = db.users.distinct("tenant_id", {"user_type": "agent", "is_active": True})
    # Also get workspace IDs from teams collection if available
    all_ids = set()
    for tid in team_ids:
        # Find teams for this tenant
        teams = db.teams.find({"tenant_id": tid})
        for team in teams:
            ws_id = team.get("id") or team.get("team_id")
            if ws_id:
                all_ids.add(ws_id)
    if not all_ids:
        # Fallback: use tenant_ids as workspace_ids
        all_ids = set(team_ids)
    return list(all_ids)


def seed_entity_types(workspace_ids: list[str]) -> int:
    """Seed Agent and Environment types into all ontology graphs."""
    total_seeded = 0
    for ws_id in workspace_ids:
        try:
            og = OntologyGraph(workspace_id=ws_id)
            created = og.seed_types(["Agent", "Environment"])
            total_seeded += created
            if created > 0:
                logger.info("Seeded %d new entity types in workspace %s", created, ws_id)
            else:
                logger.info("Entity types already exist in workspace %s", ws_id)
        except Exception as e:
            logger.warning("Failed to seed entity types in workspace %s: %s", ws_id, e)
    return total_seeded


def migrate_agents(db) -> tuple[int, int]:
    """Create AGENT entity nodes and EntityPatterns for existing agents."""
    agents = list(db.users.find({"user_type": "agent", "is_active": True}))
    migrated = 0
    errors = 0

    for agent in agents:
        agent_id = agent["id"]
        agent_name = agent.get("full_name", agent_id)
        tenant_id = agent.get("tenant_id")

        # Determine workspace_id: prefer default_team_id, derive from tenant_id pattern.
        # Never use raw tenant_id as workspace_id — the service treats team_id as workspace_id.
        workspace_id = agent.get("default_team_id")
        if not workspace_id:
            if not tenant_id:
                logger.warning("Skipping agent %s — no workspace_id or tenant_id available", agent_id)
                errors += 1
                continue
            # Derive default team ID using the same pattern as auth_service.py
            tenant_suffix = tenant_id.split("_")[1] if "_" in tenant_id else tenant_id[:8]
            workspace_id = f"team_{tenant_suffix}"
            logger.info("Agent %s: derived workspace_id=%s from tenant_id=%s", agent_id, workspace_id, tenant_id)

        try:
            scope_provider = DefaultScopeProvider(
                user_id=agent_id,
                workspace_id=workspace_id,
                tenant_id=tenant_id,
                user_type="agent",
            )
            graph = SmartGraph(scope_provider=scope_provider)

            agent_item_id = hashlib.sha256(f"agent:{agent_id}".encode()).hexdigest()
            now_iso = datetime.now(timezone.utc).isoformat()

            graph.nodes.add_node(
                item_id=agent_item_id,
                properties={
                    "name": agent_name,
                    "agent_id": agent_id,
                    "entity_type": "agent",
                    "node_category": "entity",
                    "canonical_key": get_canonical_key(agent_name, "agent"),
                    "model": agent.get("agent_config", {}).get("model", ""),
                    "capabilities": json.dumps(agent.get("agent_config", {}).get("capabilities", [])),
                    "description": agent.get("description", ""),
                    "status": "active",
                    "created_at": now_iso,
                    "updated_at": now_iso,
                },
                memory_type="agent",
            )

            # Create EntityPattern in ontology graph
            og = OntologyGraph(workspace_id=workspace_id)
            og._upsert_inline_ontology_pattern(
                name=agent_name,
                label="Agent",
                confidence=1.0,
                workspace_id=workspace_id,
                source="registration",
                initial_count=2,
            )

            migrated += 1
            logger.info("Migrated agent %s (%s) in workspace %s", agent_id, agent_name, workspace_id)
        except Exception as e:
            logger.warning("Failed to migrate agent %s: %s", agent_id, e)
            errors += 1

    return migrated, errors


def main():
    logger.info("CORE-AGENT-1: Starting agent entity type migration")

    db = _get_mongo_db()

    # Step 1: Get all workspace IDs
    workspace_ids = _get_workspace_ids(db)
    logger.info("Found %d workspaces", len(workspace_ids))

    # Step 2: Seed entity types
    seeded = seed_entity_types(workspace_ids)
    logger.info("Seeded %d new entity types total", seeded)

    # Step 3: Migrate existing agents
    migrated, errors = migrate_agents(db)
    logger.info("Migration complete: %d agents migrated, %d errors", migrated, errors)

    if errors > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
