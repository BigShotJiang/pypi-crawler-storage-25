"""CORE-RECALL-LINEAGE-1 Phase 2 — memory_type round-trip diagnostic.

Probes each layer between version_tracker._store_version and the search
response to determine where ``memory_type="Version"`` is lost on read.
Per plan.md Phase 2's 5-layer enumeration:

    (a) add_node persistence (FalkorDB)
    (b) FalkorDB :Version label vs n.memory_type property
    (c) MemoryItemSerializer rehydration
    (d) ``or "semantic"`` defaults in smart_memory.py (10 sites)
    (e) backend.search_nodes({"memory_type": "Version"}) — version_tracker.py:416

Run::

    PYTHONPATH=. python scripts/diagnose_version_memory_type.py

Output is fixed-format so it can be pasted directly into
docs/features/CORE-RECALL-LINEAGE-1/diagnostic-trace.md.
"""

from __future__ import annotations

import json
import sys
from textwrap import indent

from smartmemory import MemoryItem, SmartMemory
from smartmemory.tools.factory import create_server_memory
from smartmemory.utils.cache import NoOpCache


def _fmt(value) -> str:
    try:
        return json.dumps(value, default=str, sort_keys=True)
    except Exception:
        return repr(value)


def main() -> int:
    import uuid

    graph_name = f"diag_phase2_{uuid.uuid4().hex[:10]}"
    print(f"# diagnostic graph_name: {graph_name}", file=sys.stderr)
    memory: SmartMemory = create_server_memory(graph_name=graph_name, cache=NoOpCache())

    try:
        # Seed canonical row first so HAS_VERSION has a source.
        v1 = MemoryItem(
            content="Phase 2 diagnostic canonical row",
            metadata={"diag": "canonical"},
        )
        v1_id = memory.add(v1)
        print(f"\n## canonical v1_id = {v1_id}")

        # Create one version directly via the writer under test.
        version = memory.version_tracker.create_version(
            item_id=v1_id,
            content="Phase 2 diagnostic version row",
            metadata={"diag": "version"},
            change_reason="Phase 2 diagnostic probe",
        )
        version_id = f"version_{v1_id}_{version.version_number}"
        print(f"## version_id        = {version_id}\n")

        backend = memory._graph.backend

        # ─────────────────────────────────────────────────────────────────
        # Layer A — raw FalkorDB query for the labels of the version node
        # ─────────────────────────────────────────────────────────────────
        print("## Layer A — raw Cypher: labels(n) and n.memory_type")
        try:
            rows = backend._query(
                "MATCH (n {item_id: $id}) RETURN labels(n), n.memory_type",
                {"id": version_id},
            )
            print(indent(_fmt(list(rows or [])), "    "))
        except Exception as exc:  # noqa: BLE001
            print(f"    ERROR: {exc!r}")

        # ─────────────────────────────────────────────────────────────────
        # Layer B — backend.get_node returns properties dict
        # ─────────────────────────────────────────────────────────────────
        print("\n## Layer B — backend.get_node(version_id)")
        raw = backend.get_node(version_id)
        if raw is None:
            print("    (None)")
        else:
            print(f"    has 'memory_type' key? {'memory_type' in raw}")
            print(f"    'memory_type' value : {raw.get('memory_type')!r}")
            print(f"    origin value        : {raw.get('origin')!r}")
            print(f"    keys                : {sorted(raw.keys())}")

        # ─────────────────────────────────────────────────────────────────
        # Layer C — SmartGraph.get_node returns a higher-level object
        # ─────────────────────────────────────────────────────────────────
        print("\n## Layer C — memory._graph.get_node(version_id)")
        try:
            obj = memory._graph.get_node(version_id)
            print(f"    type                : {type(obj).__name__}")
            print(f"    memory_type attr    : {getattr(obj, 'memory_type', '<missing>')!r}")
        except Exception as exc:  # noqa: BLE001
            print(f"    ERROR: {exc!r}")

        # ─────────────────────────────────────────────────────────────────
        # Layer D — what /memory/search would report (the `or 'semantic'` site)
        # ─────────────────────────────────────────────────────────────────
        print("\n## Layer D — search response memory_type for version row")
        # Search with origin override to BYPASS the Phase 1 tier filter so
        # we can see what shape the version row would take if it were not
        # being hidden by tier-4. include_consolidated/superseded irrelevant.
        results = memory.search(
            "Phase 2 diagnostic version row",
            top_k=10,
            origin="version:snapshot",  # explicit prefix bypasses tier default
        )
        leak_found = False
        for r in results:
            rid = getattr(r, "item_id", None) or (r.get("item_id") if isinstance(r, dict) else None)
            mt = getattr(r, "memory_type", None) or (r.get("memory_type") if isinstance(r, dict) else None)
            if rid and rid.startswith("version_"):
                print(f"    {rid!r}: memory_type={mt!r}")
                leak_found = True
        if not leak_found:
            print("    (no version_* row in results — the tier filter or"
                  " indexer dropped it before this layer)")

        # ─────────────────────────────────────────────────────────────────
        # Layer E — backend.search_nodes property-based query
        # (mirrors version_tracker.py:428 fallback)
        # ─────────────────────────────────────────────────────────────────
        print("\n## Layer E — backend.search_nodes({'memory_type': 'Version'})")
        try:
            rows = backend.search_nodes({"memory_type": "Version"})
            print(f"    rows returned       : {len(rows or [])}")
            if rows:
                for row in rows[:3]:
                    if isinstance(row, tuple):
                        d = row[0] if isinstance(row[0], dict) else {}
                    else:
                        d = row
                    print(f"      item_id={d.get('item_id')!r}"
                          f" memory_type={d.get('memory_type')!r}")
        except Exception as exc:  # noqa: BLE001
            print(f"    ERROR: {exc!r}")

        print("\n## Layer E.b — search_nodes({'ref_item_id': v1, 'memory_type': 'Version'})")
        print("    (mirrors version_tracker.py:428 fallback path)")
        try:
            rows = backend.search_nodes({"ref_item_id": v1_id, "memory_type": "Version"})
            print(f"    rows returned       : {len(rows or [])}")
        except Exception as exc:  # noqa: BLE001
            print(f"    ERROR: {exc!r}")

        return 0
    finally:
        try:
            memory.clear()
        finally:
            memory.close()


if __name__ == "__main__":
    sys.exit(main())
