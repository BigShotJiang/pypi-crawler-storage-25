"""SmartMemory benchmark scenarios.

Real-backend perf and scenario harnesses for SmartMemory features. Each
benchmark script is standalone-runnable (`python benchmarks/<name>.py`)
and importable for pytest gates (`from benchmarks.<name> import ...`).

Existing scenarios:
- `bitemporal_scenario.py` — CORE-BITEMPORAL-1 belief-as-of + supersession audit
- `ontology_constrain_perf.py` — ONTO-RECONCILE-1 Phase 6 Task 15 on/off A/B
"""
