"""CORE-BITEMPORAL-1 benchmark scenario — belief-as-of-date + supersession-audit.

Runnable SmartMemory-only scenario for the CA-180 / IDEA-229 / IDEA-285
benchmark retarget. Produces REAL accuracy numbers on the production graph
backend (FalkorDB) for the two query classes a flat-list + timestamp-metadata
model cannot serve by construction:

  1. belief-as-of-date  — "what did the system believe was true on date X,
                            given only what it knew then"
  2. supersession-audit — "what did this decision replace, on what evidence,
                            when" (ordered, reconstructable chain)

This is NOT a competitive harness — it produces SmartMemory's own numbers
honestly. Competitor numbers (CC native /memory, Copilot Memory, claude-mem,
Mem0) are UNVERIFIED in this environment (no competitor harness access) and
are deliberately NOT fabricated. See the benchmark plan:
  smart-memory-docs/docs/plans/2026-05-16-bitemporal-benchmark-retarget-plan.md

Run:
  cd smart-memory-core && python benchmarks/bitemporal_scenario.py

Requires FalkorDB (9010) + Redis (9012).
"""

from __future__ import annotations

import sys
import time
from datetime import datetime, timezone, timedelta

from smartmemory.decisions.manager import DecisionManager
from smartmemory.models.decision import Decision
from smartmemory.temporal.queries import TemporalQueries
from smartmemory.temporal.version_tracker import VersionTracker
from smartmemory.tools.factory import create_server_memory


# Each case: a decision that evolves once. We probe belief at a time BEFORE the
# supersession (must return the old belief) and AFTER (must return the new one),
# then assert the audit chain reconstructs the ordered, evidenced history.
CASES = [
    {
        "domain": "auth",
        "v1": "Auth uses server-side session cookies",
        "v1_probe": "session cookies",
        "v2": "Auth uses stateless JWT bearer tokens",
        "v2_probe": "JWT",
        "reason": "Migrated to stateless auth for horizontal scaling",
    },
    {
        "domain": "storage",
        "v1": "Primary datastore is a single Postgres instance",
        "v1_probe": "single Postgres",
        "v2": "Primary datastore is a Postgres + read-replica cluster",
        "v2_probe": "read-replica",
        "reason": "Read load exceeded single-instance capacity",
    },
    {
        "domain": "deploy",
        "v1": "Deploys are manual via SSH",
        "v1_probe": "manual via SSH",
        "v2": "Deploys run through the GitHub Actions CI pipeline",
        "v2_probe": "GitHub Actions",
        "reason": "Manual deploys caused three prod incidents",
    },
]


def _ok(cond: bool, label: str) -> bool:
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}")
    return cond


def main() -> int:
    sm = create_server_memory(graph_name="bench_bitemporal")
    backend_name = type(sm._graph.backend).__name__
    print(f"backend: {backend_name}")
    if backend_name != "FalkorDBBackend":
        print("REFUSING: as-of timing precision requires FalkorDB "
              "(SQLite does not round-trip decision.created_at). "
              "Run against the server stack (:9010).")
        return 2

    dm = DecisionManager(sm)
    tq = TemporalQueries(sm)
    vt = VersionTracker(sm._graph)

    asof_total = asof_pass = 0
    audit_total = audit_pass = 0
    latencies_ms: list[float] = []

    for c in CASES:
        print(f"\n=== {c['domain']} ===")
        old = dm.create(content=c["v1"], domain=c["domain"])
        old_id = old.decision_id

        time.sleep(0.05)
        t_before = datetime.now(timezone.utc)
        time.sleep(0.05)

        new = Decision(content=c["v2"], domain=c["domain"])
        dm.supersede(old_id, new, reason=c["reason"])
        t_after = datetime.now(timezone.utc) + timedelta(seconds=1)

        # --- belief-as-of-date ---
        t0 = time.perf_counter()
        v_before = vt.get_version_at_time(old_id, t_before, time_type="transaction")
        v_after = vt.get_version_at_time(old_id, t_after, time_type="transaction")
        latencies_ms.append((time.perf_counter() - t0) * 1000.0)

        asof_total += 2
        p1 = _ok(v_before is not None and c["v1_probe"] in (v_before.content or ""),
                 f"as-of(before) -> v1 belief ({c['v1_probe']!r})")
        p2 = _ok(v_after is not None and c["v2_probe"] in (v_after.content or ""),
                 f"as-of(after)  -> v2 belief ({c['v2_probe']!r})")
        asof_pass += int(p1) + int(p2)

        # --- supersession-audit ---
        chain = tq.get_supersession_audit(old_id)
        audit_total += 1
        contiguous = (
            len(chain) >= 2
            and chain[0]["transaction_time_end"] is not None
            and chain[-1]["transaction_time_end"] is None
            and chain[0]["transaction_time_end"] == chain[1]["transaction_time_start"]
        )
        evidence_ok = old_id in (chain[-1]["evidence_ids"] if chain else [])
        ordered = [e["version"] for e in chain] == sorted(e["version"] for e in chain)
        audit_pass += int(
            _ok(contiguous and evidence_ok and ordered,
                f"audit chain: {len(chain)} versions, contiguous boundary, "
                f"evidence carries old id, oldest-first")
        )

    print("\n" + "=" * 56)
    print("CORE-BITEMPORAL-1 SCENARIO RESULTS (SmartMemory, FalkorDB)")
    print("=" * 56)
    asof_acc = asof_pass / asof_total if asof_total else 0.0
    audit_acc = audit_pass / audit_total if audit_total else 0.0
    p50 = sorted(latencies_ms)[len(latencies_ms) // 2] if latencies_ms else 0.0
    print(f"belief-as-of-date accuracy : {asof_pass}/{asof_total} = {asof_acc:.0%}")
    print(f"supersession-audit accuracy: {audit_pass}/{audit_total} = {audit_acc:.0%}")
    print(f"as-of resolution p50 latency: {p50:.2f} ms")
    print("competitor numbers: UNVERIFIED — no competitor harness in this "
          "environment; not fabricated (see benchmark plan).")

    sm.clear()
    sm.close()
    return 0 if (asof_acc == 1.0 and audit_acc == 1.0) else 1


if __name__ == "__main__":
    sys.exit(main())
