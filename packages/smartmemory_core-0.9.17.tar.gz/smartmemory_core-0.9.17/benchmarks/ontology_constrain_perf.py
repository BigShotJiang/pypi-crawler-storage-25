"""ONTO-RECONCILE-1 Phase 6 Task 15 — Ontology on/off A/B benchmark.

Compares total per-ingest duration between SmartMemory(enable_ontology=True)
and SmartMemory(enable_ontology=False) over a fixed corpus. Outputs mean /
p50 / p95 / p99 per leg + a mean delta, and asserts the no-LLM-on-stage
invariant for ontology_constrain.

Per smart-memory-docs/docs/features/ONTO-RECONCILE-1/phase-6-verification/
design.md §Task 15 (Codex round 2 reshape):

- 100 docs per leg (20 warmup + 80 measured); warmup discarded
- Construction must NOT pass ontology_store= (force-enables the stage
  regardless of the flag, per smart_memory.py:234-238)
- Mean total duration_ms is the gated metric; ≤ 5% delta passes
- p99 reported but not gated (small-sample noise dominates)
- Stage-level: ontology_constrain duration_ms reported; LLM tokens MUST
  be zero on every ontology_constrain StageTrace row

Run standalone:
    cd smart-memory-core && python benchmarks/ontology_constrain_perf.py

Run via pytest (slow + integration tier — local only, not in CI):
    PYTHONPATH=. pytest -m slow tests/integration/test_ontology_constrain_perf.py -v

Requires FalkorDB (9010) + Redis (9012) + OPENAI_API_KEY (real LLM extract).
"""

from __future__ import annotations

import argparse
import json
import os
import statistics
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from uuid import uuid4


# Fixed corpus — 100 short documents in the style of
# tests/integration/golden/test_migration_roundtrip.py:21-27. Mix of
# people, languages, projects, and events so the ontology_constrain
# stage has real :OntologyType candidates to read against, not just
# trivial single-type repetition.
_CORPUS_TEMPLATES = [
    "Alan Turing proposed the imitation game in 1950.",
    "Ada Lovelace wrote the first algorithm intended for a mechanical computer.",
    "Grace Hopper developed the first compiler.",
    "Donald Knuth authored The Art of Computer Programming.",
    "Edsger Dijkstra introduced the shortest-path algorithm.",
    "Python was created by Guido van Rossum in 1991.",
    "Rust is a systems programming language designed at Mozilla Research.",
    "Go was designed at Google by Robert Griesemer, Rob Pike, and Ken Thompson.",
    "Haskell is a purely functional programming language.",
    "OCaml is a general-purpose functional language with strong static typing.",
    "The Manhattan Project developed the first nuclear weapons.",
    "The Apollo program landed the first humans on the Moon in 1969.",
    "ARPANET was the precursor to the modern Internet.",
    "The Human Genome Project sequenced the first human genome.",
    "The Large Hadron Collider is located near Geneva.",
    "Marie Curie discovered radium and polonium in Paris.",
    "Albert Einstein published the theory of general relativity in 1915.",
    "Niels Bohr formulated a model of the atom.",
    "Richard Feynman developed the path integral formulation of quantum mechanics.",
    "Linus Pauling won two Nobel Prizes in different fields.",
]


def build_corpus(n: int) -> List[str]:
    """Build n documents from the template pool, cycling for repetition.

    Cycling is intentional — confirmed-tier types get reinforced across
    repeats, which exercises the OntologyConstrainStage's read-back path
    (matching against existing types) rather than just type creation.
    """
    return [_CORPUS_TEMPLATES[i % len(_CORPUS_TEMPLATES)] for i in range(n)]


@dataclass
class StageMeasurement:
    """Per-ingest timing snapshot for one stage."""

    stage_name: str
    duration_ms: float
    prompt_tokens: int = 0
    completion_tokens: int = 0


@dataclass
class IngestMeasurement:
    """One ingest call worth of trajectory data."""

    total_duration_ms: float
    stages: List[StageMeasurement] = field(default_factory=list)


@dataclass
class LegStats:
    """Aggregated stats for one config leg (on or off)."""

    config: str  # "on" | "off"
    measured_count: int
    total_mean: float
    total_p50: float
    total_p95: float
    total_p99: float
    ontology_constrain_mean: Optional[float]  # None when leg=off
    ontology_constrain_p99: Optional[float]
    llm_extract_mean: Optional[float]
    raw_totals: List[float] = field(default_factory=list)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "config": self.config,
            "measured_count": self.measured_count,
            "total_mean_ms": round(self.total_mean, 2),
            "total_p50_ms": round(self.total_p50, 2),
            "total_p95_ms": round(self.total_p95, 2),
            "total_p99_ms": round(self.total_p99, 2),
            "ontology_constrain_mean_ms": (
                round(self.ontology_constrain_mean, 2)
                if self.ontology_constrain_mean is not None
                else None
            ),
            "ontology_constrain_p99_ms": (
                round(self.ontology_constrain_p99, 2)
                if self.ontology_constrain_p99 is not None
                else None
            ),
            "llm_extract_mean_ms": (
                round(self.llm_extract_mean, 2)
                if self.llm_extract_mean is not None
                else None
            ),
        }


def _percentile(values: List[float], p: float) -> float:
    """Linear interpolation percentile; falls back to max for tiny samples.

    statistics.quantiles requires n>=2; we want a single number, so we
    inline a small implementation. p is in [0, 1].
    """
    if not values:
        return 0.0
    if len(values) == 1:
        return values[0]
    sv = sorted(values)
    k = (len(sv) - 1) * p
    f = int(k)
    c = min(f + 1, len(sv) - 1)
    return sv[f] + (sv[c] - sv[f]) * (k - f)


def _trajectory_to_measurement(traj) -> IngestMeasurement:
    """Convert a PipelineTrajectory to our flat measurement shape."""
    # StageTrace fields per smartmemory/pipeline/trajectory.py:34 — `name`,
    # not `stage_name`. Verified live during the round-1 smoke run.
    stages = [
        StageMeasurement(
            stage_name=s.name,
            duration_ms=float(s.duration_ms),
            prompt_tokens=int(s.prompt_tokens or 0),
            completion_tokens=int(s.completion_tokens or 0),
        )
        for s in traj.stages
    ]
    return IngestMeasurement(
        total_duration_ms=float(traj.total_duration_ms),
        stages=stages,
    )


def _run_leg(enable_ontology: bool, corpus: List[str], warmup: int) -> List[IngestMeasurement]:
    """Construct a fresh SmartMemory, ingest the corpus, return measurements.

    The warmup window is discarded by the caller (we return everything;
    aggregation drops the first `warmup` entries). Construction explicitly
    does NOT pass ontology_store= — that would force-enable the stage
    regardless of `enable_ontology` per smart_memory.py:234-238.
    """
    from smartmemory.tools.factory import create_server_memory

    graph_name = f"test_ontoperf_{uuid4().hex[:10]}"
    memory = create_server_memory(
        graph_name=graph_name,
        enable_ontology=enable_ontology,
    )
    measurements: List[IngestMeasurement] = []
    try:
        for text in corpus:
            memory.ingest(text, memory_type="semantic")
            traj = memory.last_trajectory
            if traj is None:
                # Stage may not produce a trajectory in degraded modes;
                # surface loudly rather than silently dropping.
                raise RuntimeError(
                    f"memory.last_trajectory is None after ingest (config={enable_ontology}). "
                    "Trajectory logging may be disabled."
                )
            measurements.append(_trajectory_to_measurement(traj))
    finally:
        try:
            memory.clear()
        except Exception:
            pass
    return measurements


def _aggregate(config: str, measurements: List[IngestMeasurement], warmup: int) -> LegStats:
    """Drop warmup, compute stats."""
    measured = measurements[warmup:]
    totals = [m.total_duration_ms for m in measured]

    constrain_durations: List[float] = []
    llm_durations: List[float] = []
    for m in measured:
        for s in m.stages:
            if s.stage_name == "ontology_constrain":
                constrain_durations.append(s.duration_ms)
            elif s.stage_name == "llm_extract":
                llm_durations.append(s.duration_ms)

    return LegStats(
        config=config,
        measured_count=len(measured),
        total_mean=statistics.mean(totals) if totals else 0.0,
        total_p50=_percentile(totals, 0.50),
        total_p95=_percentile(totals, 0.95),
        total_p99=_percentile(totals, 0.99),
        ontology_constrain_mean=(
            statistics.mean(constrain_durations) if constrain_durations else None
        ),
        ontology_constrain_p99=(
            _percentile(constrain_durations, 0.99) if constrain_durations else None
        ),
        llm_extract_mean=(
            statistics.mean(llm_durations) if llm_durations else None
        ),
        raw_totals=totals,
    )


def _assert_no_llm_tokens_on_constrain_stage(measurements: List[IngestMeasurement]) -> None:
    """No-LLM-on-stage invariant: ontology_constrain is a constraint check, not an extractor."""
    for i, m in enumerate(measurements):
        for s in m.stages:
            if s.stage_name == "ontology_constrain":
                if s.prompt_tokens or s.completion_tokens:
                    raise AssertionError(
                        f"ontology_constrain StageTrace at ingest {i} carries "
                        f"prompt_tokens={s.prompt_tokens} / completion_tokens={s.completion_tokens}; "
                        f"the stage must NOT call any LLM."
                    )


def run_benchmark(*, warmup: int = 20, measured: int = 80) -> Dict[str, Any]:
    """Run the A/B benchmark. Returns a dict consumable by the pytest gate.

    Total ingests per leg = warmup + measured. Default 20 + 80 = 100 per
    leg = 200 total ingests.
    """
    total = warmup + measured
    corpus = build_corpus(total)

    # Run BOTH legs from a clean state. Construction order doesn't matter
    # because each leg uses a fresh UUID-named FalkorDB graph.
    on_raw = _run_leg(enable_ontology=True, corpus=corpus, warmup=warmup)
    off_raw = _run_leg(enable_ontology=False, corpus=corpus, warmup=warmup)

    # Invariant: ontology_constrain has no LLM tokens. Only meaningful on
    # the `on` leg (off leg won't have ontology_constrain rows at all).
    _assert_no_llm_tokens_on_constrain_stage(on_raw[warmup:])

    on_stats = _aggregate("on", on_raw, warmup)
    off_stats = _aggregate("off", off_raw, warmup)

    # Mean total delta as a percentage of the off-leg baseline. We report
    # the signed delta (positive = on slower than off, which is expected
    # because the stage runs). The 5% gate is on absolute(delta).
    if off_stats.total_mean > 0:
        mean_delta_pct = (
            (on_stats.total_mean - off_stats.total_mean) / off_stats.total_mean * 100.0
        )
    else:
        mean_delta_pct = 0.0

    return {
        "on": on_stats.as_dict(),
        "off": off_stats.as_dict(),
        "mean_delta_pct": round(mean_delta_pct, 2),
        "warmup": warmup,
        "measured": measured,
    }


def _format_summary(result: Dict[str, Any]) -> str:
    on, off = result["on"], result["off"]
    return (
        f"\nONTO-RECONCILE-1 Phase 6 Task 15 — ontology_constrain A/B\n"
        f"=========================================================\n"
        f"Warmup={result['warmup']}  Measured={result['measured']}\n"
        f"\n"
        f"                            ON              OFF\n"
        f"  total mean_ms       {on['total_mean_ms']:>10}    {off['total_mean_ms']:>10}\n"
        f"  total p50_ms        {on['total_p50_ms']:>10}    {off['total_p50_ms']:>10}\n"
        f"  total p95_ms        {on['total_p95_ms']:>10}    {off['total_p95_ms']:>10}\n"
        f"  total p99_ms        {on['total_p99_ms']:>10}    {off['total_p99_ms']:>10}\n"
        f"  llm_extract mean_ms {on['llm_extract_mean_ms']!s:>10}    {off['llm_extract_mean_ms']!s:>10}\n"
        f"  ontology_constrain mean_ms  {on['ontology_constrain_mean_ms']!s:>10}    (n/a)\n"
        f"  ontology_constrain p99_ms   {on['ontology_constrain_p99_ms']!s:>10}    (n/a)\n"
        f"\n"
        f"  Mean total delta:  {result['mean_delta_pct']:+.2f}%  (gate: |delta| <= 5%)\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--warmup", type=int, default=20)
    parser.add_argument("--measured", type=int, default=80)
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of human-readable")
    args = parser.parse_args()

    result = run_benchmark(warmup=args.warmup, measured=args.measured)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(_format_summary(result))
    delta = abs(result["mean_delta_pct"])
    return 0 if delta <= 5.0 else 1


if __name__ == "__main__":
    sys.exit(main())
