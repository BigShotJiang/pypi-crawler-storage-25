# fisica_dutra

Librería desarrollada para el uso en cursos de física, orientada a la enseñanza de la cinemática mediante herramientas computacionales.

Incluye simulaciones interactivas y actividades que permiten explorar conceptos físicos de forma visual y dinámica.

---

## Descripción

La librería `fisica_dutra` permite trabajar con movimientos rectilíneos a partir de listas de tiempo, posición, velocidad y aceleración.

Incluye herramientas para:

- visualizar movimientos mediante simulaciones  
- analizar gráficas de $x(t)$, $v(t)$ y $a(t)$  
- interactuar con actividades y desafíos de cinemática  

---

## Instalación

```bash
pip install fisica_dutra
```

---

## Funciones disponibles

### Simulación de movimientos

Las siguientes funciones permiten visualizar el movimiento a partir de listas de datos:

- `simular_pos(t, x)`  
- `simular_vel_y_pos(t, v, x)`  
- `simular_a_vel_y_pos(t, a, v, x)`  

#### Ejemplo de uso

Un primer ejemplo sencillo permite visualizar un movimiento a partir de listas ya construidas:

```python
from fisica_dutra import simular_pos

t = [0, 1, 2, 3]
x = [0, 2, 4, 6]

simular_pos(t, x)
```
Este enfoque es útil para comenzar, pero tiene una limitación importante: al tener pocos valores, la simulación se ve “cortada”. El objeto solo aparece en los instantes de tiempo definidos, por lo que el movimiento se percibe más como una sucesión de posiciones (como fotos) que como un movimiento continuo.

En realidad, esto ocurre en cualquier simulación basada en listas discretas. La diferencia es que, si se utilizan más puntos, el movimiento se percibe como más fluido.

Una alternativa más completa consiste en generar las listas paso a paso a partir de condiciones iniciales y relaciones físicas:
```python
from fisica_dutra import simular_a_vel_y_pos

t_i = 0
t_f = 5
dt = 0.2
x_i = 0
v_i = 0
a_i = 2

t = [t_i]
v = [v_i]
x = [x_i]
a = [a_i]

while t[-1] < t_f:
    t.append(t[-1] + dt)
    a.append(a[-1])
    v.append(v[-1] + a[-1]*dt)
    x.append(x[-1] + v[-2]*dt)

simular_a_vel_y_pos(t, a, v, x)
```

Una vez construidas las listas:

- `simular_pos(t, x)` muestra únicamente la evolución de la posición.  
- `simular_vel_y_pos(t, v, x)` muestra la posición y la velocidad.  
- `simular_a_vel_y_pos(t, a, v, x)` muestra la posición, la velocidad y la aceleración.  

---

## Actividades y juegos

### desafio_MRU(t, x, grupo)

Actividad interactiva en la que el objetivo es reconstruir un movimiento a partir de su gráfica x(t).

Se proporciona una gráfica de referencia y el desafío consiste en construir listas de tiempo y posición que reproduzcan ese movimiento.

---

### Cómo jugar

1. Crear una lista de tiempos con paso dt = 0.1 
2. Crear la lista de posiciones correspondiente  
3. Ejecutar:

```python
from fisica_dutra import desafio_MRU

desafio_MRU(t, x, grupo)
```

donde `grupo` es un número entero correspondiente al número de grupo.

---

### Qué muestra el programa

- Azul → movimiento objetivo  
- Naranja → tu propuesta  

En la simulación:

- Color → tu movimiento  
- Blanco y negro → movimiento objetivo  

---

### Condiciones para ganar

- La posición inicial debe diferir en menos de 1m  
- La velocidad debe diferir en menos de 1m/s  

---

### Sistema de puntaje

- Se asigna un puntaje según qué tan cerca estés del movimiento objetivo  
- Podés intentar todas las veces que quieras  
- El objetivo es maximizar tu puntaje  

---

## Gráficas por grupo

Cada grupo recibe una gráfica distinta:

### Grupo 1
![Grupo 1](assets/Grafica Grupo 1.png)

### Grupo 2
![Grupo 2](assets/Grafica Grupo 2.png)

### Grupo 3
![Grupo 3](assets/Grafica Grupo 3.png)

### Grupo 4
![Grupo 4](assets/Grafica Grupo 4.png)

### Grupo 5
![Grupo 5](assets/Grafica Grupo 5.png)

### Grupo 6
![Grupo 6](assets/Grafica Grupo 6.png)

### Grupo 7
![Grupo 7](assets/Grafica Grupo 7.png)

### Grupo 8
![Grupo 8](assets/Grafica Grupo 8.png)

### Grupo 9
![Grupo 9](assets/Grafica Grupo 9.png)

---

### juego_cinematica()

Juego interactivo para explorar conceptos de cinemática.

```python
from fisica_dutra import juego_cinematica

juego_cinematica()
```
En el juego, debés mover a una persona utilizando el mouse para intentar replicar una gráfica de posición en función del tiempo x(t) que se muestra en pantalla.

El objetivo es que tu movimiento coincida lo mejor posible con la gráfica dada.

El juego cuenta con tres niveles de dificultad:

Nivel fácil: movimientos con velocidad constante
Nivel medio: movimientos con aceleración constante
Nivel difícil: movimientos que combinan tramos de distintos movimientos

## Objetivo

El objetivo de esta librería es facilitar la integración entre la física y la programación en contextos educativos, promoviendo la exploración de modelos de movimiento mediante simulaciones y herramientas computacionales. 

La librería propone utilizar el código como una forma de modelización, donde las leyes físicas se traducen en reglas simples que permiten construir, visualizar y analizar el comportamiento de los sistemas.