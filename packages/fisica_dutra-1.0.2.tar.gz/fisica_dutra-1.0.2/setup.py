import pathlib
from setuptools import find_packages, setup

HERE = pathlib.Path(__file__).parent

VERSION = '1.0.2' 
PACKAGE_NAME = 'fisica_dutra' 
AUTHOR = 'Mateo Dutra' 
AUTHOR_EMAIL = 'mateodutrafisica@gmail.com'

LICENSE = 'MIT' #Tipo de licencia
DESCRIPTION = 'Librería con funciones para usar en cursos de física'
LONG_DESCRIPTION = (HERE / "README.md").read_text(encoding='utf-8')
LONG_DESC_TYPE = "text/markdown"

INSTALL_REQUIRES = [
      'matplotlib', 'pygame'
      ]

setup(
    name=PACKAGE_NAME,
    version=VERSION,
    description=DESCRIPTION,
    #long_description=LONG_DESCRIPTION,
    long_description_content_type=LONG_DESC_TYPE,
    author=AUTHOR,
    author_email=AUTHOR_EMAIL,
    install_requires=INSTALL_REQUIRES,
    license=LICENSE,
    packages=find_packages(),
    include_package_data=True
)
