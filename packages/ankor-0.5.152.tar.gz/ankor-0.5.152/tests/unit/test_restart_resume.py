"""Tests for server-crash resume: node/workflow restart_on_failure_check and
node-skip-on-resume behaviour in make_node_wrapper.

These tests inject fake resume context directly into the ContextVar so no live
DB is needed (_SessionLocal is None in the test environment, making all DB
helpers no-ops that return early).
"""

from __future__ import annotations

import pytest

from ankor.decorator._context import _active_node_slot, _active_run_ctx
from ankor.decorator.node import make_node_wrapper
from ankor.models import RunNode, WorkflowStatus

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_node_row(
    node_id: int,
    name: str,
    status: WorkflowStatus,
    outputs: dict | None = None,
    parent_node_id: int | None = None,
) -> RunNode:
    return RunNode(
        id=node_id,
        run_id=1,
        parent_node_id=parent_node_id,
        name=name,
        status=status,
        duration_ms=0,
        data={"outputs": outputs or {}, "inputs": {}},
    )


def _resume_ctx(by_parent: dict) -> dict:
    return {
        "run_id": 1,
        "_run_meta": {"id": 1, "name": "test_workflow"},
        "_executed_names": set(),
        "_is_resume": True,
        "_resumed_by_parent": by_parent,
        "logs": [],
        "_row_history": {},
    }


async def _call_wrapper(wrapper, inputs: dict, ctx: dict) -> object:
    """Call *wrapper* inside the given run context."""
    ctx_token = _active_run_ctx.set(ctx)
    slot_token = _active_node_slot.set(None)
    try:
        return await wrapper(inputs)
    finally:
        _active_run_ctx.reset(ctx_token)
        _active_node_slot.reset(slot_token)


# ---------------------------------------------------------------------------
# Tests: skipping already-completed nodes
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_skip_success_node_returns_stored_output():
    """A node marked success in the resume queue should be skipped and its stored output returned."""
    stored_outputs = {"result": "cached"}
    node_row = _make_node_row(10, "my_node", WorkflowStatus.success, stored_outputs)

    executed = []

    async def my_node(inputs: dict) -> dict:
        executed.append(inputs)
        return {"result": "fresh"}

    wrapper = make_node_wrapper(my_node)
    ctx = _resume_ctx({None: [node_row]})

    result = await _call_wrapper(wrapper, {"x": 1}, ctx)

    assert result == stored_outputs
    assert (
        executed == []
    ), "node function must NOT be called for already-completed nodes"


@pytest.mark.asyncio
async def test_skip_success_node_adds_to_executed_names():
    """A skipped node should be added to _executed_names."""
    node_row = _make_node_row(10, "my_node", WorkflowStatus.success)

    async def my_node(inputs: dict) -> dict:
        return {}

    wrapper = make_node_wrapper(my_node)
    ctx = _resume_ctx({None: [node_row]})

    await _call_wrapper(wrapper, {}, ctx)

    assert "my_node" in ctx["_executed_names"]


@pytest.mark.asyncio
async def test_skip_pops_node_from_queue():
    """After skipping, the node row should be removed from the queue."""
    node_row = _make_node_row(10, "my_node", WorkflowStatus.success)

    async def my_node(inputs: dict) -> dict:
        return {}

    wrapper = make_node_wrapper(my_node)
    ctx = _resume_ctx({None: [node_row]})

    await _call_wrapper(wrapper, {}, ctx)

    assert ctx["_resumed_by_parent"][None] == []


@pytest.mark.asyncio
async def test_non_resume_context_executes_normally():
    """Without _is_resume, the node should execute normally regardless of any resume data."""
    executed = []

    async def my_node(inputs: dict) -> dict:
        executed.append(inputs)
        return {"done": True}

    wrapper = make_node_wrapper(my_node)
    ctx = {
        "run_id": 1,
        "_run_meta": {"id": 1, "name": "wf"},
        "_executed_names": set(),
        "logs": [],
        "_row_history": {},
        # No _is_resume key
    }
    ctx_token = _active_run_ctx.set(ctx)
    slot_token = _active_node_slot.set(None)
    try:
        result = await wrapper({"v": 42})
    finally:
        _active_run_ctx.reset(ctx_token)
        _active_node_slot.reset(slot_token)

    assert result == {"done": True}
    assert executed == [{"v": 42}]


# ---------------------------------------------------------------------------
# Tests: interrupted node (status=running) without restart_on_failure_check
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_interrupted_node_reruns_without_check():
    """An interrupted node (running in queue) should be re-executed when no check is provided."""
    node_row = _make_node_row(10, "my_node", WorkflowStatus.running)

    executed = []

    async def my_node(inputs: dict) -> dict:
        executed.append(inputs)
        return {"fresh": True}

    wrapper = make_node_wrapper(my_node)
    ctx = _resume_ctx({None: [node_row]})

    result = await _call_wrapper(wrapper, {"y": 2}, ctx)

    assert result == {"fresh": True}
    assert executed == [{"y": 2}]


@pytest.mark.asyncio
async def test_interrupted_node_adds_to_executed_names():
    node_row = _make_node_row(10, "my_node", WorkflowStatus.running)

    async def my_node(inputs: dict) -> dict:
        return {}

    wrapper = make_node_wrapper(my_node)
    ctx = _resume_ctx({None: [node_row]})

    await _call_wrapper(wrapper, {}, ctx)

    assert "my_node" in ctx["_executed_names"]


# ---------------------------------------------------------------------------
# Tests: restart_on_failure_check on interrupted node
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_check_returns_data_skips_rerun():
    """When check returns a dict, the node should NOT be re-executed and the dict should be returned."""
    node_row = _make_node_row(10, "my_node", WorkflowStatus.running)

    checked = []
    executed = []

    async def check_fn(inputs: dict) -> dict | None:
        checked.append(inputs)
        return {"recovered": True}

    async def my_node(inputs: dict) -> dict:
        executed.append(inputs)
        return {"fresh": True}

    wrapper = make_node_wrapper(my_node, restart_on_failure_check=check_fn)
    ctx = _resume_ctx({None: [node_row]})

    result = await _call_wrapper(wrapper, {"k": "v"}, ctx)

    assert result == {"recovered": True}
    assert checked == [{"k": "v"}]
    assert executed == [], "node must NOT execute when check returns data"


@pytest.mark.asyncio
async def test_check_returns_none_reruns_node():
    """When check returns None, the node should be re-executed normally."""
    node_row = _make_node_row(10, "my_node", WorkflowStatus.running)

    executed = []

    async def check_fn(inputs: dict) -> dict | None:
        return None  # node needs to re-run

    async def my_node(inputs: dict) -> dict:
        executed.append(inputs)
        return {"fresh": True}

    wrapper = make_node_wrapper(my_node, restart_on_failure_check=check_fn)
    ctx = _resume_ctx({None: [node_row]})

    result = await _call_wrapper(wrapper, {"q": 1}, ctx)

    assert result == {"fresh": True}
    assert executed == [{"q": 1}]


@pytest.mark.asyncio
async def test_check_result_added_to_executed_names():
    """A confirmed-success node should be added to _executed_names."""
    node_row = _make_node_row(10, "my_node", WorkflowStatus.running)

    async def check_fn(inputs: dict) -> dict | None:
        return {"ok": True}

    async def my_node(inputs: dict) -> dict:
        return {}

    wrapper = make_node_wrapper(my_node, restart_on_failure_check=check_fn)
    ctx = _resume_ctx({None: [node_row]})

    await _call_wrapper(wrapper, {}, ctx)

    assert "my_node" in ctx["_executed_names"]


# ---------------------------------------------------------------------------
# Tests: node NOT in queue runs normally (new nodes after interruption point)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_node_not_in_queue_runs_normally():
    """If the queue has a different name at front, this node should be treated as new."""
    other_row = _make_node_row(10, "other_node", WorkflowStatus.success)

    executed = []

    async def my_node(inputs: dict) -> dict:
        executed.append(inputs)
        return {"new": True}

    wrapper = make_node_wrapper(my_node)
    ctx = _resume_ctx({None: [other_row]})

    result = await _call_wrapper(wrapper, {"z": 9}, ctx)

    assert result == {"new": True}
    assert executed == [{"z": 9}]
    # other_row was NOT popped — it belongs to a different node
    assert len(ctx["_resumed_by_parent"][None]) == 1


@pytest.mark.asyncio
async def test_empty_queue_runs_normally():
    """An empty resume queue means no prior state — the node should run as usual."""
    executed = []

    async def my_node(inputs: dict) -> dict:
        executed.append(inputs)
        return {"brand_new": True}

    wrapper = make_node_wrapper(my_node)
    ctx = _resume_ctx({None: []})

    result = await _call_wrapper(wrapper, {}, ctx)

    assert result == {"brand_new": True}
    assert executed


# ---------------------------------------------------------------------------
# Tests: sequential nodes — first completed, second interrupted
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_sequential_skip_then_rerun():
    """Two nodes called in sequence: the first (completed) should be skipped, the second (interrupted) should be re-executed."""
    row_a = _make_node_row(10, "node_a", WorkflowStatus.success, {"a": 1})
    row_b = _make_node_row(11, "node_b", WorkflowStatus.running)

    exec_order = []

    async def node_a(inputs: dict) -> dict:
        exec_order.append("a")
        return {"a": "fresh"}

    async def node_b(inputs: dict) -> dict:
        exec_order.append("b")
        return {"b": 2}

    wrapper_a = make_node_wrapper(node_a)
    wrapper_b = make_node_wrapper(node_b)

    ctx = _resume_ctx({None: [row_a, row_b]})
    ctx_token = _active_run_ctx.set(ctx)
    slot_token = _active_node_slot.set(None)
    try:
        result_a = await wrapper_a({})
        result_b = await wrapper_b({})
    finally:
        _active_run_ctx.reset(ctx_token)
        _active_node_slot.reset(slot_token)

    assert result_a == {"a": 1}, "node_a should return stored output"
    assert result_b == {"b": 2}, "node_b should execute and return fresh output"
    assert exec_order == ["b"], "only node_b was actually executed"
