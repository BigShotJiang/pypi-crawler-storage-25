"""Tests for data table CSV value coercion and query helpers."""

from __future__ import annotations

import json
from datetime import date, datetime

import pytest

from ankor.db_store import _coerce_for_write, _normalize_row, coerce_csv_value

# ---------------------------------------------------------------------------
# coerce_csv_value — pure function tests (no DB needed)
# ---------------------------------------------------------------------------


class TestCoerceCsvValue:
    def test_empty_string_returns_none(self):
        for col_type in ("text", "integer", "boolean", "date", "select", "json"):
            assert coerce_csv_value("", col_type) is None

    def test_text_passthrough(self):
        assert coerce_csv_value("hello world", "text") == "hello world"
        assert coerce_csv_value("42", "text") == "42"

    def test_select_passthrough(self):
        assert coerce_csv_value("draft", "select") == "draft"

    def test_number_integer(self):
        assert coerce_csv_value("42", "integer") == 42
        assert isinstance(coerce_csv_value("42", "integer"), int)

    def test_number_float(self):
        result = coerce_csv_value("3.14", "integer")
        assert result == 3
        assert isinstance(result, int)

    def test_number_zero(self):
        assert coerce_csv_value("0", "integer") == 0

    def test_number_negative(self):
        assert coerce_csv_value("-7", "integer") == -7

    def test_number_invalid_returns_none(self):
        assert coerce_csv_value("abc", "integer") is None

    def test_float_simple(self):
        result = coerce_csv_value("123.45", "float")
        assert abs(result - 123.45) < 1e-9
        assert isinstance(result, float)

    def test_float_integer_string(self):
        result = coerce_csv_value("42", "float")
        assert abs(result - 42.0) < 1e-9

    def test_float_negative(self):
        result = coerce_csv_value("-9.99", "float")
        assert abs(result - (-9.99)) < 1e-9

    def test_float_scientific(self):
        result = coerce_csv_value("1.5e3", "float")
        assert abs(result - 1500.0) < 1e-9

    def test_float_empty_returns_none(self):
        assert coerce_csv_value("", "float") is None

    def test_float_invalid_returns_none(self):
        assert coerce_csv_value("not_a_float", "float") is None

    def test_boolean_true_variants(self):
        for val in ("true", "True", "TRUE", "1", "yes", "Yes", "on", "ON"):
            assert (
                coerce_csv_value(val, "boolean") is True
            ), f"Expected True for {val!r}"

    def test_boolean_false_variants(self):
        for val in ("false", "False", "FALSE", "0", "no", "No", "off", "OFF"):
            assert (
                coerce_csv_value(val, "boolean") is False
            ), f"Expected False for {val!r}"

    def test_boolean_unknown_returns_none(self):
        assert coerce_csv_value("maybe", "boolean") is None

    def test_date_plain(self):
        from datetime import date

        assert coerce_csv_value("2026-04-09", "date") == date(2026, 4, 9)
        assert coerce_csv_value("  2026-01-01  ", "date") == date(2026, 1, 1)

    def test_date_iso_datetime_string(self):
        from datetime import date

        # Full ISO datetime (e.g. from CRM exports) is truncated to date
        assert coerce_csv_value("2023-12-06T09:33:40.609Z", "date") == date(2023, 12, 6)
        assert coerce_csv_value("2024-01-01T00:00:00.000Z", "date") == date(2024, 1, 1)

    def test_date_invalid_returns_none(self):
        assert coerce_csv_value("not-a-date", "date") is None

    def test_date_empty_returns_none(self):
        assert coerce_csv_value("", "date") is None

    def test_json_valid(self):
        assert coerce_csv_value('{"key": 1}', "json") == {"key": 1}
        assert coerce_csv_value("[1, 2, 3]", "json") == [1, 2, 3]

    def test_json_invalid_returns_raw(self):
        assert coerce_csv_value("not json", "json") == "not json"


# ---------------------------------------------------------------------------
# _coerce_for_write — pure function tests (no DB needed)
# ---------------------------------------------------------------------------


class TestCoerceForWrite:
    def test_none_passthrough(self):
        assert _coerce_for_write(None, "text") is None
        assert _coerce_for_write(None, "date") is None
        assert _coerce_for_write(None, "json") is None

    def test_date_plain_string(self):
        assert _coerce_for_write("2026-04-09", "date") == date(2026, 4, 9)

    def test_date_iso_datetime_string(self):
        assert _coerce_for_write("2025-09-04T11:40:06.492Z", "date") == date(2025, 9, 4)

    def test_date_already_date_object(self):
        d = date(2026, 1, 1)
        assert _coerce_for_write(d, "date") == d

    def test_date_datetime_object_truncated(self):
        dt = datetime(2026, 1, 1, 12, 0, 0)
        assert _coerce_for_write(dt, "date") == date(2026, 1, 1)

    def test_date_invalid_string_returns_none(self):
        assert _coerce_for_write("not-a-date", "date") is None

    def test_json_dict_serialized_to_string(self):
        result = _coerce_for_write({"key": 1}, "json")
        assert isinstance(result, str)
        assert json.loads(result) == {"key": 1}

    def test_json_list_serialized_to_string(self):
        result = _coerce_for_write([1, 2, 3], "json")
        assert isinstance(result, str)
        assert json.loads(result) == [1, 2, 3]

    def test_json_string_passthrough(self):
        assert _coerce_for_write('{"key": 1}', "json") == '{"key": 1}'

    def test_text_passthrough(self):
        assert _coerce_for_write("hello", "text") == "hello"

    def test_number_passthrough(self):
        assert _coerce_for_write(42, "integer") == 42


# ---------------------------------------------------------------------------
# _normalize_row — pure function tests (no DB needed)
# ---------------------------------------------------------------------------


class TestNormalizeRow:
    def test_json_string_parsed_with_col_types(self):
        col_types = {"data": "json"}
        result = _normalize_row({"id": 1, "data": '{"key": "value"}'}, col_types)
        assert result["data"] == {"key": "value"}

    def test_json_invalid_string_kept_as_string(self):
        col_types = {"data": "json"}
        result = _normalize_row({"id": 1, "data": "not json"}, col_types)
        assert result["data"] == "not json"

    def test_json_string_not_parsed_without_col_types(self):
        result = _normalize_row({"id": 1, "data": '{"key": "value"}'})
        assert result["data"] == '{"key": "value"}'

    def test_json_dict_passthrough_with_col_types(self):
        col_types = {"data": "json"}
        result = _normalize_row({"id": 1, "data": {"key": "value"}}, col_types)
        assert result["data"] == {"key": "value"}

    def test_date_serialized_to_isoformat(self):
        result = _normalize_row({"id": 1, "birthday": date(2026, 4, 9)})
        assert result["birthday"] == "2026-04-09"

    def test_decimal_to_float(self):
        from decimal import Decimal

        result = _normalize_row({"id": 1, "score": Decimal("3.14")})
        assert abs(result["score"] - 3.14) < 1e-9
        assert isinstance(result["score"], float)


# ---------------------------------------------------------------------------
# RowFilter / _build_where tests
# ---------------------------------------------------------------------------

from datetime import date as _date  # noqa: E402
from ankor.db_store import RowFilter, _build_where  # noqa: E402


class TestBuildWhere:
    def test_empty_filters_returns_empty(self):
        sql, params = _build_where([])
        assert sql == ""
        assert params == {}

    def test_invalid_op_raises(self):
        with pytest.raises(ValueError, match="Unknown filter op"):
            _build_where([RowFilter("col", "like", "x")])

    # --- number ---

    def test_number_eq(self):
        sql, params = _build_where([RowFilter("score", "eq", 42)])
        assert '"score" = :fp0' in sql
        assert params == {"fp0": 42}

    def test_number_neq(self):
        sql, params = _build_where([RowFilter("score", "neq", 0)])
        assert '"score" != :fp0' in sql
        assert params == {"fp0": 0}

    def test_number_gt(self):
        sql, params = _build_where([RowFilter("score", "gt", 100)])
        assert '"score" > :fp0' in sql
        assert params == {"fp0": 100}

    def test_number_gte(self):
        sql, params = _build_where([RowFilter("score", "gte", 50)])
        assert '"score" >= :fp0' in sql
        assert params == {"fp0": 50}

    def test_number_lt(self):
        sql, params = _build_where([RowFilter("score", "lt", 200)])
        assert '"score" < :fp0' in sql
        assert params == {"fp0": 200}

    def test_number_lte(self):
        sql, params = _build_where([RowFilter("score", "lte", 99)])
        assert '"score" <= :fp0' in sql
        assert params == {"fp0": 99}

    # --- float ---

    def test_float_gt(self):
        sql, params = _build_where([RowFilter("rating", "gt", 3.5)])
        assert '"rating" > :fp0' in sql
        assert params == {"fp0": 3.5}

    def test_float_lte(self):
        sql, params = _build_where([RowFilter("rating", "lte", 10.0)])
        assert '"rating" <= :fp0' in sql
        assert params == {"fp0": 10.0}

    def test_float_eq(self):
        sql, params = _build_where([RowFilter("rating", "eq", 4.75)])
        assert '"rating" = :fp0' in sql
        assert params == {"fp0": 4.75}

    # --- boolean ---

    def test_boolean_eq_true(self):
        sql, params = _build_where([RowFilter("active", "eq", True)])
        assert '"active" = :fp0' in sql
        assert params == {"fp0": True}

    def test_boolean_eq_false(self):
        sql, params = _build_where([RowFilter("active", "eq", False)])
        assert '"active" = :fp0' in sql
        assert params == {"fp0": False}

    def test_boolean_neq(self):
        sql, params = _build_where([RowFilter("active", "neq", True)])
        assert '"active" != :fp0' in sql
        assert params == {"fp0": True}

    # --- text / select ---

    def test_text_eq(self):
        sql, params = _build_where([RowFilter("name", "eq", "Alice")])
        assert '"name" = :fp0' in sql
        assert params == {"fp0": "Alice"}

    def test_text_neq(self):
        sql, params = _build_where([RowFilter("status", "neq", "archived")])
        assert '"status" != :fp0' in sql
        assert params == {"fp0": "archived"}

    def test_text_contains(self):
        sql, params = _build_where([RowFilter("name", "contains", "müller")])
        assert '"name" ILIKE :fp0' in sql
        assert params == {"fp0": "%müller%"}

    def test_text_starts_with(self):
        sql, params = _build_where([RowFilter("name", "starts_with", "Max")])
        assert '"name" ILIKE :fp0' in sql
        assert params == {"fp0": "Max%"}

    def test_text_ends_with(self):
        sql, params = _build_where([RowFilter("email", "ends_with", "@example.com")])
        assert '"email" ILIKE :fp0' in sql
        assert params == {"fp0": "%@example.com"}

    # --- date ---

    def test_date_eq(self):
        sql, params = _build_where([RowFilter("birthday", "eq", _date(2000, 1, 15))])
        assert '"birthday" = :fp0' in sql
        assert params == {"fp0": _date(2000, 1, 15)}

    def test_date_neq(self):
        sql, params = _build_where([RowFilter("birthday", "neq", _date(2020, 6, 1))])
        assert '"birthday" != :fp0' in sql

    def test_date_gt(self):
        sql, params = _build_where([RowFilter("birthday", "gt", _date(2000, 1, 1))])
        assert '"birthday" > :fp0' in sql
        assert params == {"fp0": _date(2000, 1, 1)}

    def test_date_gte(self):
        sql, params = _build_where([RowFilter("created_at", "gte", _date(2024, 1, 1))])
        assert '"created_at" >= :fp0' in sql

    def test_date_lt(self):
        sql, params = _build_where([RowFilter("birthday", "lt", _date(2026, 4, 9))])
        assert '"birthday" < :fp0' in sql

    def test_date_lte(self):
        sql, params = _build_where([RowFilter("birthday", "lte", _date(2025, 12, 31))])
        assert '"birthday" <= :fp0' in sql
        assert params == {"fp0": _date(2025, 12, 31)}

    # --- multiple filters combined ---

    def test_multiple_filters_joined_with_and(self):
        sql, params = _build_where(
            [
                RowFilter("score", "gt", 50),
                RowFilter("active", "eq", True),
            ]
        )
        assert " AND " in sql
        assert '"score" > :fp0' in sql
        assert '"active" = :fp1' in sql
        assert params == {"fp0": 50, "fp1": True}

    def test_three_filters(self):
        sql, params = _build_where(
            [
                RowFilter("score", "gte", 10),
                RowFilter("score", "lte", 100),
                RowFilter("name", "contains", "test"),
            ]
        )
        assert sql.count(" AND ") == 2
        assert len(params) == 3

    # --- hyphenated column ids ---

    def test_hyphenated_column_id_quoted(self):
        sql, params = _build_where([RowFilter("col-2", "eq", "active")])
        assert '"col-2" = :fp0' in sql
        assert params == {"fp0": "active"}

    # --- WHERE prefix ---

    def test_where_clause_prefix(self):
        sql, _ = _build_where([RowFilter("x", "eq", 1)])
        assert sql.startswith(" WHERE ")


# ---------------------------------------------------------------------------
