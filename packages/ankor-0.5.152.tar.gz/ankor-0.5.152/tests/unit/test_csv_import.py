"""Automated tests for ankor.csv_import — parsing and type coercion."""

import json
import textwrap
from datetime import date

import pytest

from ankor.csv_import import parse_csv

# ── shared column schema (mirrors the sample CSV in the issue) ────────────────

COLUMNS = [
    {"id": "deal_id", "name": "deal_id", "type": "integer"},
    {"id": "amount", "name": "amount", "type": "float"},
    {"id": "dealname", "name": "dealname", "type": "text"},
    {"id": "last_touch_at", "name": "last_touch_at", "type": "date"},
    {"id": "data", "name": "data", "type": "json"},
    {"id": "engagement_status", "name": "engagement_status", "type": "text"},
    {"id": "status", "name": "status", "type": "select"},
    {"id": "score", "name": "score", "type": "float"},
    {"id": "has_feedback", "name": "has_feedback", "type": "boolean"},
    {"id": "last_reply_at", "name": "last_reply_at", "type": "date"},
]


# ═══════════════════════════════════════════════════════════════════════════════
# parse_csv integration tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestParseCsv:

    # ── exact sample from the issue ───────────────────────────────────────────
    # The JSON blob in the 'data' column uses RFC 4180 double-quote escaping:
    # inner " → "" and the whole field is wrapped in "..."

    SAMPLE_CSV = (
        "deal_id,amount,dealname,last_touch_at,data,engagement_status,status,score,has_feedback,last_reply_at\n"
        "100001,123.23,Müller GmbH (Demo Deal),2023-12-06T09:33:40.609Z,"
        '"{""crm_data"":{""deal"":{""id"":200001}}}",active,open,0.87,true,2023-11-30T08:00:00.000Z\n'
    )

    def test_sample_row_count(self):
        rows, errors = parse_csv(self.SAMPLE_CSV, COLUMNS)
        assert len(rows) == 1
        assert not errors

    def test_sample_deal_id(self):
        rows, _ = parse_csv(self.SAMPLE_CSV, COLUMNS)
        assert rows[0]["deal_id"] == 100001

    def test_sample_amount_float(self):
        rows, _ = parse_csv(self.SAMPLE_CSV, COLUMNS)
        assert rows[0]["amount"] == pytest.approx(123.23)

    def test_sample_score_float(self):
        rows, _ = parse_csv(self.SAMPLE_CSV, COLUMNS)
        assert rows[0]["score"] == pytest.approx(0.87)

    def test_sample_dealname_unicode(self):
        rows, _ = parse_csv(self.SAMPLE_CSV, COLUMNS)
        assert rows[0]["dealname"] == "Müller GmbH (Demo Deal)"

    def test_sample_date(self):
        rows, _ = parse_csv(self.SAMPLE_CSV, COLUMNS)
        assert rows[0]["last_touch_at"] == date(2023, 12, 6)

    def test_sample_json_parsed(self):
        rows, _ = parse_csv(self.SAMPLE_CSV, COLUMNS)
        data = rows[0]["data"]
        assert isinstance(data, dict)
        assert data["crm_data"]["deal"]["id"] == 200001

    def test_sample_boolean(self):
        rows, _ = parse_csv(self.SAMPLE_CSV, COLUMNS)
        assert rows[0]["has_feedback"] is True

    def test_sample_text_columns(self):
        rows, _ = parse_csv(self.SAMPLE_CSV, COLUMNS)
        assert rows[0]["engagement_status"] == "active"
        assert rows[0]["status"] == "open"

    # ── multi-row ─────────────────────────────────────────────────────────────

    MULTI_CSV = textwrap.dedent("""\
        deal_id,amount,dealname,last_touch_at,data,engagement_status,status,score,has_feedback,last_reply_at
        1,10.0,Alpha,2024-01-01T00:00:00.000Z,"{}",active,open,1.5,true,2024-01-01T00:00:00.000Z
        2,20.5,Beta,2024-02-01T00:00:00.000Z,"{}",inactive,closed,2.0,false,2024-02-01T00:00:00.000Z
        3,0.99,Gamma,2024-03-01T00:00:00.000Z,"{}",active,open,0.1,1,2024-03-01T00:00:00.000Z
    """)

    def test_multi_row_count(self):
        rows, errors = parse_csv(self.MULTI_CSV, COLUMNS)
        assert len(rows) == 3
        assert not errors

    def test_multi_row_amounts(self):
        rows, _ = parse_csv(self.MULTI_CSV, COLUMNS)
        assert [r["amount"] for r in rows] == pytest.approx([10.0, 20.5, 0.99])

    def test_multi_row_scores(self):
        rows, _ = parse_csv(self.MULTI_CSV, COLUMNS)
        assert [r["score"] for r in rows] == pytest.approx([1.5, 2.0, 0.1])

    def test_multi_row_bool_from_1(self):
        rows, _ = parse_csv(self.MULTI_CSV, COLUMNS)
        assert rows[2]["has_feedback"] is True  # "1" → True

    # ── empty / null values ───────────────────────────────────────────────────

    NULL_CSV = textwrap.dedent("""\
        deal_id,amount,dealname,last_touch_at,data,engagement_status,status,score,has_feedback,last_reply_at
        99,,Empty row,,,,,,,
    """)

    def test_empty_float_is_none(self):
        rows, _ = parse_csv(self.NULL_CSV, COLUMNS)
        assert rows[0]["amount"] is None
        assert rows[0]["score"] is None

    def test_empty_json_is_none(self):
        rows, _ = parse_csv(self.NULL_CSV, COLUMNS)
        assert rows[0]["data"] is None

    def test_empty_date_is_none(self):
        rows, _ = parse_csv(self.NULL_CSV, COLUMNS)
        assert rows[0]["last_touch_at"] is None
        assert rows[0]["last_reply_at"] is None

    def test_present_number_still_parsed(self):
        rows, _ = parse_csv(self.NULL_CSV, COLUMNS)
        assert rows[0]["deal_id"] == 99

    # ── quoting edge-cases ────────────────────────────────────────────────────

    def test_embedded_comma(self):
        csv = 'deal_id,dealname\n1,"Smith, John"\n'
        cols = [
            {"id": "deal_id", "type": "integer"},
            {"id": "dealname", "type": "text"},
        ]
        rows, _ = parse_csv(csv, cols)
        assert rows[0]["dealname"] == "Smith, John"

    def test_embedded_newline(self):
        csv = 'deal_id,dealname\n1,"Line one\nLine two"\n'
        cols = [
            {"id": "deal_id", "type": "integer"},
            {"id": "dealname", "type": "text"},
        ]
        rows, _ = parse_csv(csv, cols)
        assert rows[0]["dealname"] == "Line one\nLine two"

    def test_double_quote_escape_in_text(self):
        csv = 'deal_id,dealname\n1,"Say ""hello"""\n'
        cols = [
            {"id": "deal_id", "type": "integer"},
            {"id": "dealname", "type": "text"},
        ]
        rows, _ = parse_csv(csv, cols)
        assert rows[0]["dealname"] == 'Say "hello"'

    # ── large JSON blob ───────────────────────────────────────────────────────

    def test_large_json_blob(self):
        payload = {
            "crm_data": {
                "deal": {"id": 200002},
                "contact": {"name": "Demo User"},
                "items": list(range(50)),
            }
        }
        # Produce RFC 4180 escaped JSON: inner " → ""
        escaped = json.dumps(payload).replace('"', '""')
        csv_text = f'deal_id,data\n1,"{escaped}"\n'
        cols = [{"id": "deal_id", "type": "integer"}, {"id": "data", "type": "json"}]
        rows, errors = parse_csv(csv_text, cols)
        assert not errors
        assert rows[0]["data"]["crm_data"]["deal"]["id"] == 200002
        assert len(rows[0]["data"]["crm_data"]["items"]) == 50

    # ── header mapping ────────────────────────────────────────────────────────

    def test_display_name_mapping(self):
        """Headers matching column 'name' (not 'id') should map correctly."""
        csv = "Deal ID,Amount\n123,45.6\n"
        cols = [
            {"id": "deal_id", "name": "Deal ID", "type": "integer"},
            {"id": "amount", "name": "Amount", "type": "float"},
        ]
        rows, _ = parse_csv(csv, cols)
        assert rows[0]["deal_id"] == 123
        assert rows[0]["amount"] == pytest.approx(45.6)

    def test_unknown_column_passthrough(self):
        csv = "deal_id,mystery_col\n1,surprise\n"
        cols = [{"id": "deal_id", "type": "integer"}]
        rows, _ = parse_csv(csv, cols)
        assert rows[0]["mystery_col"] == "surprise"

    # ── BOM stripping (caller responsibility, but verify no crash) ────────────

    def test_bom_stripped_before_parse(self):
        """Simulate what the router does: decode with utf-8-sig, strip BOM."""
        raw = "\ufeffdeal_id,amount\n1,2.5\n"
        stripped = raw.lstrip("\ufeff")
        cols = [{"id": "deal_id", "type": "integer"}, {"id": "amount", "type": "float"}]
        rows, _ = parse_csv(stripped, cols)
        assert rows[0]["deal_id"] == 1
        assert rows[0]["amount"] == pytest.approx(2.5)

    # ── Windows CRLF line endings ─────────────────────────────────────────────

    def test_crlf_line_endings(self):
        csv = "deal_id,amount\r\n1,3.14\r\n2,2.72\r\n"
        cols = [{"id": "deal_id", "type": "integer"}, {"id": "amount", "type": "float"}]
        rows, errors = parse_csv(csv, cols)
        assert not errors
        assert len(rows) == 2
        assert rows[1]["amount"] == pytest.approx(2.72)

    # ── float-specific precision ──────────────────────────────────────────────

    @pytest.mark.parametrize(
        "raw,expected",
        [
            ("0.1", 0.1),
            ("0.000001", 0.000001),
            ("999999.999", 999999.999),
            ("-0.5", -0.5),
            ("1e-10", 1e-10),
        ],
    )
    def test_float_precision(self, raw, expected):
        csv = f"v\n{raw}\n"
        cols = [{"id": "v", "type": "float"}]
        rows, _ = parse_csv(csv, cols)
        assert rows[0]["v"] == pytest.approx(expected)
