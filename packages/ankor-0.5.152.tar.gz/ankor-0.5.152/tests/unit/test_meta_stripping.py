"""Tests for _meta stripping in make_node_wrapper.

By default, _meta is stripped from the value returned to the caller while
being preserved in the outputs stored to the DB.  When return_meta=True the
caller receives _meta as well.
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, patch

from ankor.decorator._context import _active_node_slot, _active_run_ctx
from ankor.decorator.node import make_node_wrapper, _strip_meta
from ankor.models import RunNode, WorkflowStatus

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_ctx() -> dict:
    return {
        "logs": [],
        "run_id": 1,
        "_executed_names": set(),
        "_row_history": {},
        "_run_meta": {"id": 1, "name": "test_wf"},
    }


async def _run(wrapper, inputs: dict, ctx: dict):
    ctx_token = _active_run_ctx.set(ctx)
    slot_token = _active_node_slot.set(None)
    try:
        return await wrapper(inputs)
    finally:
        _active_run_ctx.reset(ctx_token)
        _active_node_slot.reset(slot_token)


def _make_node_row(outputs: dict) -> RunNode:
    return RunNode(
        id=10,
        run_id=1,
        parent_node_id=None,
        name="my_node",
        status=WorkflowStatus.success,
        duration_ms=0,
        data={"outputs": outputs, "inputs": {}},
    )


@pytest.fixture(autouse=True)
def _patch_db():
    with patch(
        "ankor.decorator.node.insert_run_node", new_callable=AsyncMock, return_value=99
    ):
        with patch("ankor.decorator.node.update_run_node", new_callable=AsyncMock):
            with patch(
                "ankor.decorator.node.broadcast_node_update", new_callable=AsyncMock
            ):
                yield


# ---------------------------------------------------------------------------
# _strip_meta unit tests
# ---------------------------------------------------------------------------


def test_strip_meta_removes_meta_key():
    d = {"a": 1, "_meta": {"views": []}, "b": 2}
    assert _strip_meta(d) == {"a": 1, "b": 2}


def test_strip_meta_no_meta_key_unchanged():
    d = {"a": 1, "b": 2}
    assert _strip_meta(d) == {"a": 1, "b": 2}


def test_strip_meta_returns_shallow_copy():
    d = {"a": 1, "_meta": {}}
    result = _strip_meta(d)
    assert result is not d


# ---------------------------------------------------------------------------
# Default (return_meta=False): _meta stripped from caller return value
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_meta_stripped_by_default():
    async def my_node(inputs: dict) -> dict:
        return {"data": "hello", "_meta": {"views": [{"key": "data", "type": "md"}]}}

    wrapper = make_node_wrapper(my_node)
    result = await _run(wrapper, {}, _make_ctx())

    assert "_meta" not in result
    assert result == {"data": "hello"}


@pytest.mark.asyncio
async def test_meta_stripped_when_no_meta_present():
    async def my_node(inputs: dict) -> dict:
        return {"data": "hello"}

    wrapper = make_node_wrapper(my_node)
    result = await _run(wrapper, {}, _make_ctx())

    assert result == {"data": "hello"}


# ---------------------------------------------------------------------------
# return_meta=True: _meta passed through to caller
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_return_meta_true_preserves_meta():
    meta = {"views": [{"key": "result", "type": "json"}]}

    async def my_node(inputs: dict) -> dict:
        return {"result": 42, "_meta": meta}

    wrapper = make_node_wrapper(my_node, return_meta=True)
    result = await _run(wrapper, {}, _make_ctx())

    assert result == {"result": 42, "_meta": meta}


# ---------------------------------------------------------------------------
# Resume path: _meta stripped from stored outputs on skip
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_resume_skip_strips_meta():
    """When a node is skipped on resume, _meta should be stripped from stored outputs."""
    stored = {"data": "cached", "_meta": {"views": []}}
    node_row = _make_node_row(stored)

    async def my_node(inputs: dict) -> dict:
        return {"data": "fresh"}  # should not be called

    wrapper = make_node_wrapper(my_node)

    ctx = {
        "logs": [],
        "run_id": 1,
        "_executed_names": set(),
        "_row_history": {},
        "_run_meta": {},
        "_is_resume": True,
        "_resumed_by_parent": {None: [node_row]},
    }
    result = await _run(wrapper, {}, ctx)

    assert "_meta" not in result
    assert result == {"data": "cached"}


@pytest.mark.asyncio
async def test_resume_skip_return_meta_true_preserves_meta():
    """With return_meta=True, _meta should be kept in resumed stored outputs."""
    stored = {"data": "cached", "_meta": {"views": []}}
    node_row = _make_node_row(stored)

    async def my_node(inputs: dict) -> dict:
        return {}

    wrapper = make_node_wrapper(my_node, return_meta=True)

    ctx = {
        "logs": [],
        "run_id": 1,
        "_executed_names": set(),
        "_row_history": {},
        "_run_meta": {},
        "_is_resume": True,
        "_resumed_by_parent": {None: [node_row]},
    }
    result = await _run(wrapper, {}, ctx)

    assert "_meta" in result
    assert result == stored
