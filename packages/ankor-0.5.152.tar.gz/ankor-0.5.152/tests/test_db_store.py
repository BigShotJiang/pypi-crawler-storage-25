"""Unit tests for DbStore pure helper functions.

Covers:
- _build_order_by   — pure function, no DB required
- _build_select_cols — pure function, no DB required
"""

from __future__ import annotations

import pytest

from ankor import OrderBy
from ankor.db_store import _build_order_by, _build_select_cols

# ---------------------------------------------------------------------------
# _build_order_by — pure function tests
# ---------------------------------------------------------------------------


class TestBuildOrderBy:
    def test_none_defaults_to_id(self):
        assert _build_order_by(None) == '"id"'

    def test_asc_direction(self):
        result = _build_order_by(OrderBy("amount", "asc"))
        assert result == '"amount" ASC'

    def test_desc_direction(self):
        result = _build_order_by(OrderBy("amount", "desc"))
        assert result == '"amount" DESC'

    def test_direction_case_insensitive_asc(self):
        result = _build_order_by(OrderBy("name", "ASC"))
        assert result == '"name" ASC'

    def test_direction_case_insensitive_desc(self):
        result = _build_order_by(OrderBy("name", "DESC"))
        assert result == '"name" DESC'

    def test_direction_mixed_case(self):
        result = _build_order_by(OrderBy("name", "Desc"))
        assert result == '"name" DESC'

    def test_default_direction_is_asc(self):
        result = _build_order_by(OrderBy("name"))
        assert result == '"name" ASC'

    def test_invalid_direction_raises(self):
        with pytest.raises(ValueError, match="Invalid order direction"):
            _build_order_by(OrderBy("name", "random"))

    def test_invalid_direction_empty_raises(self):
        with pytest.raises(ValueError, match="Invalid order direction"):
            _build_order_by(OrderBy("name", ""))

    def test_hyphenated_column_quoted(self):
        result = _build_order_by(OrderBy("col-2", "asc"))
        assert result == '"col-2" ASC'

    def test_hyphenated_column_desc(self):
        result = _build_order_by(OrderBy("col-name", "desc"))
        assert result == '"col-name" DESC'

    # --- one test per column type to confirm all work ---

    def test_text_column(self):
        result = _build_order_by(OrderBy("name", "asc"))
        assert result == '"name" ASC'

    def test_integer_column(self):
        result = _build_order_by(OrderBy("score", "desc"))
        assert result == '"score" DESC'

    def test_float_column(self):
        result = _build_order_by(OrderBy("rating", "asc"))
        assert result == '"rating" ASC'

    def test_boolean_column(self):
        result = _build_order_by(OrderBy("active", "desc"))
        assert result == '"active" DESC'

    def test_date_column(self):
        result = _build_order_by(OrderBy("created_on", "asc"))
        assert result == '"created_on" ASC'

    def test_json_column_asc(self):
        result = _build_order_by(OrderBy("metadata", "asc"))
        assert result == '"metadata" ASC'

    def test_select_column(self):
        result = _build_order_by(OrderBy("status", "desc"))
        assert result == '"status" DESC'

    def test_column_with_spaces_quoted(self):
        result = _build_order_by(OrderBy("first name", "asc"))
        assert result == '"first name" ASC'

    def test_column_with_double_quotes_escaped(self):
        result = _build_order_by(OrderBy('col"weird', "asc"))
        assert result == '"col""weird" ASC'

    def test_output_contains_no_order_by_keyword(self):
        # The function returns only the expression, not the full clause
        result = _build_order_by(OrderBy("amount", "desc"))
        assert not result.startswith("ORDER BY")

    def test_system_column_updated_at(self):
        result = _build_order_by(OrderBy("updated_at", "desc"))
        assert result == '"updated_at" DESC'

    def test_system_column_created_at(self):
        result = _build_order_by(OrderBy("created_at", "asc"))
        assert result == '"created_at" ASC'


# ---------------------------------------------------------------------------
# _build_select_cols — pure function tests
# ---------------------------------------------------------------------------


class TestBuildSelectCols:
    def test_none_returns_star(self):
        assert _build_select_cols(None) == "*"

    def test_empty_list_returns_star(self):
        assert _build_select_cols([]) == "*"

    def test_single_column_includes_id(self):
        result = _build_select_cols(["name"])
        assert result == '"id", "name"'

    def test_multiple_columns_includes_id(self):
        result = _build_select_cols(["name", "score"])
        assert result == '"id", "name", "score"'

    def test_id_in_columns_not_duplicated(self):
        result = _build_select_cols(["id", "name"])
        assert result == '"id", "name"'
        assert result.count('"id"') == 1

    def test_id_only_not_duplicated(self):
        result = _build_select_cols(["id"])
        assert result == '"id"'

    def test_hyphenated_columns_quoted(self):
        result = _build_select_cols(["col-2", "col-3"])
        assert result == '"id", "col-2", "col-3"'

    def test_single_hyphenated_column(self):
        result = _build_select_cols(["col-1"])
        assert result == '"id", "col-1"'

    def test_order_preserved(self):
        result = _build_select_cols(["zzz", "aaa"])
        assert result == '"id", "zzz", "aaa"'

    def test_three_columns(self):
        result = _build_select_cols(["amount", "status", "created_on"])
        assert result == '"id", "amount", "status", "created_on"'

    def test_column_with_spaces_quoted(self):
        result = _build_select_cols(["first name"])
        assert result == '"id", "first name"'

    def test_column_with_double_quotes_escaped(self):
        result = _build_select_cols(['col"x'])
        assert result == '"id", "col""x"'

    def test_system_column_created_at(self):
        result = _build_select_cols(["created_at"])
        assert result == '"id", "created_at"'

    def test_system_column_updated_at(self):
        result = _build_select_cols(["updated_at"])
        assert result == '"id", "updated_at"'

    def test_duplicate_non_id_column_deduplicated(self):
        result = _build_select_cols(["amount", "amount"])
        assert result == '"id", "amount"'

    def test_all_system_cols(self):
        result = _build_select_cols(["id", "created_at", "updated_at"])
        assert '"id"' in result
        assert '"created_at"' in result
        assert '"updated_at"' in result
        assert result.count('"id"') == 1
