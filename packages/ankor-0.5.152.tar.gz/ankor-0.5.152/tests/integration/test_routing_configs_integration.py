"""Integration tests for config CRUD endpoints.

Tests GET /configs, POST /configs, PATCH /configs/{id}, DELETE /configs/{id}
against a real PostgreSQL database.

HTTP client: httpx.AsyncClient + ASGITransport.
"""

from __future__ import annotations

import uuid

from httpx import ASGITransport, AsyncClient
from sqlalchemy import delete as _sa_delete

from ankor.models import ConfigRecord


def _unique_key(prefix: str = "KEY") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:6].upper()}"


async def _create_config(real_db, key: str, value: str = "some-value") -> ConfigRecord:
    async with real_db() as session:
        cfg = ConfigRecord(key=key, value=value, type="string")
        session.add(cfg)
        await session.commit()
        await session.refresh(cfg)
        return cfg


async def _cleanup_config(real_db, cfg_id: int) -> None:
    async with real_db() as session:
        await session.execute(_sa_delete(ConfigRecord).where(ConfigRecord.id == cfg_id))
        await session.commit()


async def test_list_configs_empty(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/configs")
    assert resp.status_code == 200
    assert resp.json() == []


async def test_list_configs_returns_all(real_db, make_test_app):
    key1, key2 = _unique_key("A"), _unique_key("B")
    cfg1 = await _create_config(real_db, key1)
    cfg2 = await _create_config(real_db, key2)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/configs")
        assert resp.status_code == 200
        keys = {c["key"] for c in resp.json()}
        assert key1 in keys
        assert key2 in keys
    finally:
        await _cleanup_config(real_db, cfg1.id)
        await _cleanup_config(real_db, cfg2.id)


async def test_list_configs_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/configs")
    assert resp.status_code == 401


async def test_create_config_returns_201(real_db, make_test_app):
    key = _unique_key("NEW")
    app = make_test_app()
    created_id = None
    try:
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/configs", json={"key": key, "value": "v", "type": "string"}
            )
        assert resp.status_code == 201
        body = resp.json()
        assert body["key"] == key
        created_id = body["id"]
    finally:
        if created_id:
            await _cleanup_config(real_db, created_id)


async def test_create_config_persisted_in_db(real_db, make_test_app):
    key = _unique_key("PERSIST")
    app = make_test_app()
    created_id = None
    try:
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/configs",
                json={"key": key, "value": "persisted", "type": "string"},
            )
        created_id = resp.json()["id"]

        async with real_db() as session:
            cfg = await session.get(ConfigRecord, created_id)
        assert cfg is not None
        assert cfg.value == "persisted"
    finally:
        if created_id:
            await _cleanup_config(real_db, created_id)


async def test_create_config_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/api/configs", json={"key": "K", "value": "v", "type": "string"}
        )
    assert resp.status_code == 401


async def test_update_config_not_found(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.patch("/api/configs/999999", json={"value": "new"})
    assert resp.status_code == 404


async def test_update_config_success(real_db, make_test_app):
    cfg = await _create_config(real_db, _unique_key("UPD"))
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.patch(
                f"/api/configs/{cfg.id}", json={"value": "updated"}
            )
        assert resp.status_code == 200
        assert resp.json()["value"] == "updated"

        # Verify persisted in DB
        async with real_db() as session:
            db_cfg = await session.get(ConfigRecord, cfg.id)
        assert db_cfg.value == "updated"
    finally:
        await _cleanup_config(real_db, cfg.id)


async def test_delete_config_not_found(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.delete("/api/configs/999999")
    assert resp.status_code == 404


async def test_delete_config_removes_row(real_db, make_test_app):
    cfg = await _create_config(real_db, _unique_key("DEL"))
    app = make_test_app()

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.delete(f"/api/configs/{cfg.id}")
    assert resp.status_code == 204

    async with real_db() as session:
        db_cfg = await session.get(ConfigRecord, cfg.id)
    assert db_cfg is None
