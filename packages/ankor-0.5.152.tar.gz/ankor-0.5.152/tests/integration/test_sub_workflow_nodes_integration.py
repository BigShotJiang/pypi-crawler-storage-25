"""Integration tests for sub-workflow node tracking.

When a workflow wrapper runs inside a parent workflow's execution context,
a RunNode row representing the child run must be inserted into the parent's
WorkflowRun.

Tests use a real PostgreSQL database via the real_db fixture; the
_SessionLocal bindings are patched by real_db to use the test engine.
"""

from __future__ import annotations

import uuid
from unittest.mock import patch

from sqlalchemy import delete as _sa_delete
from sqlmodel import select

import ankor.decorator as dec
from ankor.decorator.workflow import make_workflow_wrapper
from ankor.models import RunNode, Workflow, WorkflowRun, WorkflowStatus


def _unique_name(prefix: str = "subwf") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _cleanup(real_db, *wf_names: str) -> None:
    async with real_db() as session:
        for name in wf_names:
            wf = (
                await session.exec(select(Workflow).where(Workflow.name == name))
            ).first()
            if wf:
                runs = (
                    await session.exec(
                        select(WorkflowRun).where(WorkflowRun.workflow_id == wf.id)
                    )
                ).all()
                for run in runs:
                    await session.execute(
                        _sa_delete(RunNode).where(RunNode.run_id == run.id)
                    )
                # Delete child runs first (those referencing parent via parent_id)
                for run in runs:
                    await session.execute(
                        _sa_delete(WorkflowRun).where(WorkflowRun.parent_id == run.id)
                    )
                await session.execute(
                    _sa_delete(WorkflowRun).where(WorkflowRun.workflow_id == wf.id)
                )
                await session.execute(_sa_delete(Workflow).where(Workflow.id == wf.id))
        await session.commit()


async def test_sub_workflow_appends_run_node_to_parent(real_db):
    """When a child workflow runs inside a parent ctx, a RunNode row should be inserted for the parent."""
    parent_wf_name = _unique_name("parent")
    child_wf_name = _unique_name("child")

    async def child_fn(inputs: dict) -> dict:
        return {"result": "child_done"}

    child_fn.__name__ = child_wf_name
    child_wrapper = make_workflow_wrapper(child_fn)

    # Simulate a running parent workflow by setting an active run context
    parent_run_ctx: dict = {
        "logs": [],
        "run_id": None,  # will be set after parent run is created
        "_executed_names": set(),
        "_row_history": {},
        "_run_meta": {},
    }

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):
            # Create a real parent WorkflowRun first
            async def parent_fn(inputs: dict) -> dict:
                # Run child from inside parent context
                child_result = await child_wrapper(inputs)
                return child_result

            parent_fn.__name__ = parent_wf_name
            parent_wrapper = make_workflow_wrapper(parent_fn)
            result = await parent_wrapper({"x": 1})

        assert result == {"result": "child_done"}

        # Verify the parent WorkflowRun has a RunNode pointing to the child run
        async with real_db() as session:
            parent_wf = (
                await session.exec(
                    select(Workflow).where(Workflow.name == parent_wf_name)
                )
            ).first()
            assert parent_wf is not None

            parent_run = (
                await session.exec(
                    select(WorkflowRun).where(WorkflowRun.workflow_id == parent_wf.id)
                )
            ).first()
            assert parent_run is not None

            nodes = (
                await session.exec(
                    select(RunNode).where(RunNode.run_id == parent_run.id)
                )
            ).all()
            assert len(nodes) == 1
            child_node = nodes[0]
            assert child_node.child_run_id is not None

            # Verify the child_run_id points to a real WorkflowRun
            child_run = await session.get(WorkflowRun, child_node.child_run_id)
            assert child_run is not None

            child_wf = (
                await session.exec(
                    select(Workflow).where(Workflow.name == child_wf_name)
                )
            ).first()
            assert child_wf is not None
            assert child_run.workflow_id == child_wf.id
    finally:
        await _cleanup(real_db, parent_wf_name, child_wf_name)


async def test_sub_workflow_node_carries_inputs_and_outputs(real_db):
    """The RunNode inserted for the child run should store the inputs and outputs."""
    parent_wf_name = _unique_name("parent_io")
    child_wf_name = _unique_name("child_io")

    async def child_fn(inputs: dict) -> dict:
        return {"value": inputs.get("x", 0) * 2}

    child_fn.__name__ = child_wf_name
    child_wrapper = make_workflow_wrapper(child_fn)

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):

            async def parent_fn(inputs: dict) -> dict:
                return await child_wrapper({"x": 5})

            parent_fn.__name__ = parent_wf_name
            parent_wrapper = make_workflow_wrapper(parent_fn)
            await parent_wrapper({})

        async with real_db() as session:
            parent_wf = (
                await session.exec(
                    select(Workflow).where(Workflow.name == parent_wf_name)
                )
            ).first()
            parent_run = (
                await session.exec(
                    select(WorkflowRun).where(WorkflowRun.workflow_id == parent_wf.id)
                )
            ).first()
            node = (
                await session.exec(
                    select(RunNode).where(RunNode.run_id == parent_run.id)
                )
            ).first()

        assert node is not None
        assert (node.data or {}).get("inputs") == {"x": 5}
        assert (node.data or {}).get("outputs") == {"value": 10}
    finally:
        await _cleanup(real_db, parent_wf_name, child_wf_name)


async def test_sub_workflow_node_status_reflects_failure(real_db):
    """A failing child workflow should result in a RunNode with status=failed."""
    parent_wf_name = _unique_name("parent_fail")
    child_wf_name = _unique_name("child_fail")

    async def child_fn(inputs: dict) -> dict:
        raise RuntimeError("boom")

    child_fn.__name__ = child_wf_name
    child_wrapper = make_workflow_wrapper(child_fn)

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):

            async def parent_fn(inputs: dict) -> dict:
                return await child_wrapper(inputs)

            parent_fn.__name__ = parent_wf_name
            parent_wrapper = make_workflow_wrapper(parent_fn)
            try:
                await parent_wrapper({})
            except RuntimeError:
                pass  # expected

        async with real_db() as session:
            parent_wf = (
                await session.exec(
                    select(Workflow).where(Workflow.name == parent_wf_name)
                )
            ).first()
            parent_run = (
                await session.exec(
                    select(WorkflowRun).where(WorkflowRun.workflow_id == parent_wf.id)
                )
            ).first()
            node = (
                await session.exec(
                    select(RunNode).where(RunNode.run_id == parent_run.id)
                )
            ).first()

        assert node is not None
        assert node.status == WorkflowStatus.failed
    finally:
        await _cleanup(real_db, parent_wf_name, child_wf_name)


async def test_top_level_workflow_creates_no_parent_node(real_db):
    """When called as a top-level workflow (no parent ctx), no RunNode should be created in any parent."""
    wf_name = _unique_name("standalone")

    async def fn(inputs: dict) -> dict:
        return {"done": True}

    fn.__name__ = wf_name

    try:
        assert dec._active_run_ctx.get() is None  # confirm no parent context

        with patch("ankor.decorator.workflow._ensure_drain_task"):
            result = await make_workflow_wrapper(fn)({"y": 2})

        assert result == {"done": True}

        async with real_db() as session:
            wf = (
                await session.exec(select(Workflow).where(Workflow.name == wf_name))
            ).first()
            run = (
                await session.exec(
                    select(WorkflowRun).where(WorkflowRun.workflow_id == wf.id)
                )
            ).first()
            nodes = (
                await session.exec(select(RunNode).where(RunNode.run_id == run.id))
            ).all()

        # No RunNode rows — this was a top-level run with no child nodes
        assert nodes == []
    finally:
        await _cleanup(real_db, wf_name)


async def test_child_run_id_in_node_matches_actual_child_run(real_db):
    """The child_run_id stored in the parent RunNode should match the WorkflowRun id of the child."""
    parent_wf_name = _unique_name("parent_id")
    child_wf_name = _unique_name("child_id")

    child_ctx_run_ids: list[int] = []

    async def child_fn(inputs: dict) -> dict:
        ctx = dec._active_run_ctx.get()
        if ctx:
            child_ctx_run_ids.append(ctx["run_id"])
        return {}

    child_fn.__name__ = child_wf_name
    child_wrapper = make_workflow_wrapper(child_fn)

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):

            async def parent_fn(inputs: dict) -> dict:
                return await child_wrapper(inputs)

            parent_fn.__name__ = parent_wf_name
            parent_wrapper = make_workflow_wrapper(parent_fn)
            await parent_wrapper({})

        assert len(child_ctx_run_ids) == 1
        child_run_id = child_ctx_run_ids[0]

        async with real_db() as session:
            parent_wf = (
                await session.exec(
                    select(Workflow).where(Workflow.name == parent_wf_name)
                )
            ).first()
            parent_run = (
                await session.exec(
                    select(WorkflowRun).where(WorkflowRun.workflow_id == parent_wf.id)
                )
            ).first()
            node = (
                await session.exec(
                    select(RunNode).where(RunNode.run_id == parent_run.id)
                )
            ).first()

        assert node.child_run_id == child_run_id
    finally:
        await _cleanup(real_db, parent_wf_name, child_wf_name)
