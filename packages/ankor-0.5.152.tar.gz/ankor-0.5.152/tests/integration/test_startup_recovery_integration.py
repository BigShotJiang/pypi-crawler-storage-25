"""Integration tests for _recover_from_restart against a real PostgreSQL database.

Verifies that startup recovery actually writes correct status values to the DB,
rather than just checking mock call counts.  Resume/drain helpers are still
patched since those code paths are covered by test_resume_integration.py.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from sqlalchemy import delete as _sa_delete

from ankor._startup import _recover_from_restart
from ankor.decorator.restart import ServerRestartLogic
from ankor.models import TriggerType, Workflow, WorkflowRun, WorkflowStatus

_RESUME = "ankor.decorator._resume_existing_run"
_DRAIN_ENSURE = "ankor.decorator._ensure_drain_task"
_DRAIN_NOTIFY = "ankor.decorator._notify_drain"


def _unique_name(prefix: str = "wf") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _create_workflow(real_db, name: str) -> int:
    """Insert a Workflow row and return its id."""
    async with real_db() as session:
        wf = Workflow(name=name)
        session.add(wf)
        await session.commit()
        await session.refresh(wf)
        return wf.id


async def _create_run(real_db, wf_id: int, status: WorkflowStatus) -> int:
    """Insert a WorkflowRun row and return its id."""
    async with real_db() as session:
        run = WorkflowRun(
            workflow_id=wf_id,
            status=status,
            triggered_by=TriggerType.manual,
            data={"inputs": {}, "outputs": {}, "actions": []},
        )
        session.add(run)
        await session.commit()
        await session.refresh(run)
        return run.id


async def _cleanup(real_db, *, wf_ids: list[int], run_ids: list[int]) -> None:
    async with real_db() as session:
        if run_ids:
            await session.execute(
                _sa_delete(WorkflowRun).where(WorkflowRun.id.in_(run_ids))
            )
        if wf_ids:
            await session.execute(_sa_delete(Workflow).where(Workflow.id.in_(wf_ids)))
        await session.commit()


async def test_unregistered_running_run_cancelled_in_db(real_db):
    """A running run for an unregistered workflow should be set to cancelled in the DB."""
    wf_name = _unique_name("unreg")
    wf_id = await _create_workflow(real_db, wf_name)
    run_id = await _create_run(real_db, wf_id, WorkflowStatus.running)

    try:
        async with real_db() as session:
            with patch(_RESUME), patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
                await _recover_from_restart(session, wrappers={})

        async with real_db() as session:
            run = await session.get(WorkflowRun, run_id)
            assert run.status == WorkflowStatus.cancelled
            assert run.finished_at is not None
    finally:
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=[run_id])


async def test_cancelled_run_finished_at_is_set(real_db):
    """finished_at should be written to the DB when a run is bulk-cancelled."""
    wf_name = _unique_name("cancel_ts")
    wf_id = await _create_workflow(real_db, wf_name)
    run_id = await _create_run(real_db, wf_id, WorkflowStatus.running)

    before = datetime.now(timezone.utc)
    try:
        async with real_db() as session:
            with patch(_RESUME), patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
                await _recover_from_restart(session, wrappers={})

        async with real_db() as session:
            run = await session.get(WorkflowRun, run_id)
            assert run.finished_at is not None
            assert run.finished_at >= before
    finally:
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=[run_id])


async def test_multiple_unregistered_runs_all_cancelled(real_db):
    """All orphaned runs without matching wrappers should be bulk-cancelled in one pass."""
    wf_name = _unique_name("multi_cancel")
    wf_id = await _create_workflow(real_db, wf_name)
    run_ids = [
        await _create_run(real_db, wf_id, WorkflowStatus.running) for _ in range(4)
    ]

    try:
        async with real_db() as session:
            with patch(_RESUME), patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
                await _recover_from_restart(session, wrappers={})

        async with real_db() as session:
            for rid in run_ids:
                run = await session.get(WorkflowRun, rid)
                assert run.status == WorkflowStatus.cancelled
    finally:
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=run_ids)


async def test_registered_running_run_not_cancelled(real_db):
    """A running run for a registered workflow must NOT be cancelled."""
    wf_name = _unique_name("resumable")
    wf_id = await _create_workflow(real_db, wf_name)
    run_id = await _create_run(real_db, wf_id, WorkflowStatus.running)

    async def my_fn(inputs: dict) -> dict:
        return {}

    try:
        async with real_db() as session:
            with patch(_RESUME), patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
                await _recover_from_restart(session, wrappers={wf_name: my_fn})

        async with real_db() as session:
            run = await session.get(WorkflowRun, run_id)
            assert run.status == WorkflowStatus.running
            assert run.finished_at is None
    finally:
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=[run_id])


async def test_resume_task_scheduled_for_resumable_run(real_db):
    """_resume_existing_run should be called as an asyncio task for each resumable run."""
    wf_name = _unique_name("task_sched")
    wf_id = await _create_workflow(real_db, wf_name)
    run_id = await _create_run(real_db, wf_id, WorkflowStatus.running)

    async def raw_fn(inputs: dict) -> dict:
        return {}

    resume_calls: list = []

    async def _fake_resume(*args, **kwargs):
        resume_calls.append(args)

    try:
        async with real_db() as session:
            with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
                with patch(_RESUME, side_effect=_fake_resume):
                    await _recover_from_restart(session, wrappers={wf_name: raw_fn})
                    await asyncio.sleep(0)  # let the created task execute

        assert len(resume_calls) == 1
        assert resume_calls[0][0] is raw_fn
        assert resume_calls[0][1] == run_id
        assert resume_calls[0][2] == wf_name
    finally:
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=[run_id])


async def test_wrapper_with_gtm_fn_passes_raw_fn_to_resume(real_db):
    """If the wrapper has a _gtm_fn attribute, the raw underlying fn should be passed to resume."""
    wf_name = _unique_name("gtm_fn")
    wf_id = await _create_workflow(real_db, wf_name)
    run_id = await _create_run(real_db, wf_id, WorkflowStatus.running)

    async def raw_fn(inputs: dict) -> dict:
        return {}

    wrapper = MagicMock()
    wrapper._gtm_fn = raw_fn
    del wrapper._restart_on_failure_check  # ensure getattr falls back to None
    del wrapper._server_restart_logic  # ensure getattr falls back to None

    resume_calls: list = []

    async def _fake_resume(*args, **kwargs):
        resume_calls.append(args)

    try:
        async with real_db() as session:
            with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
                with patch(_RESUME, side_effect=_fake_resume):
                    await _recover_from_restart(session, wrappers={wf_name: wrapper})
                    await asyncio.sleep(0)

        assert len(resume_calls) == 1
        assert resume_calls[0][0] is raw_fn
    finally:
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=[run_id])


async def test_restart_on_failure_check_forwarded_to_resume(real_db):
    """restart_on_failure_check should be converted to ServerRestartLogic and forwarded to _resume_existing_run."""
    wf_name = _unique_name("rfc")
    wf_id = await _create_workflow(real_db, wf_name)
    run_id = await _create_run(real_db, wf_id, WorkflowStatus.running)

    async def raw_fn(inputs: dict) -> dict:
        return {}

    async def check_fn(inputs: dict):
        return None

    wrapper = MagicMock()
    wrapper._gtm_fn = raw_fn
    wrapper._server_restart_logic = None
    wrapper._restart_on_failure_check = check_fn

    resume_calls: list = []

    async def _fake_resume(*args, **kwargs):
        resume_calls.append(args)

    try:
        async with real_db() as session:
            with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
                with patch(_RESUME, side_effect=_fake_resume):
                    await _recover_from_restart(session, wrappers={wf_name: wrapper})
                    await asyncio.sleep(0)

        assert len(resume_calls) == 1
        assert resume_calls[0][0] is raw_fn
        assert resume_calls[0][1] == run_id
        assert resume_calls[0][2] == wf_name
        logic = resume_calls[0][3]
        assert isinstance(logic, ServerRestartLogic)
        assert logic.mode == "mock_on_side_effect"
        assert logic.side_effect_check is check_fn
    finally:
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=[run_id])


async def test_mixed_cancel_and_resume(real_db):
    """Unregistered runs should be cancelled; registered runs should remain running."""
    unreg_name = _unique_name("unreg_mix")
    reg_name = _unique_name("reg_mix")
    unreg_wf_id = await _create_workflow(real_db, unreg_name)
    reg_wf_id = await _create_workflow(real_db, reg_name)
    unreg_run_id = await _create_run(real_db, unreg_wf_id, WorkflowStatus.running)
    reg_run_id = await _create_run(real_db, reg_wf_id, WorkflowStatus.running)

    async def reg_fn(inputs: dict) -> dict:
        return {}

    try:
        async with real_db() as session:
            with patch(_RESUME), patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
                await _recover_from_restart(session, wrappers={reg_name: reg_fn})

        async with real_db() as session:
            unreg_run = await session.get(WorkflowRun, unreg_run_id)
            reg_run = await session.get(WorkflowRun, reg_run_id)
            assert unreg_run.status == WorkflowStatus.cancelled
            assert unreg_run.finished_at is not None
            assert reg_run.status == WorkflowStatus.running
            assert reg_run.finished_at is None
    finally:
        await _cleanup(
            real_db,
            wf_ids=[unreg_wf_id, reg_wf_id],
            run_ids=[unreg_run_id, reg_run_id],
        )


async def test_pending_run_starts_drain_task(real_db):
    """A pending run for a registered workflow should trigger drain task startup."""
    wf_name = _unique_name("pending_drain")
    wf_id = await _create_workflow(real_db, wf_name)
    run_id = await _create_run(real_db, wf_id, WorkflowStatus.pending)

    async def my_fn(inputs: dict) -> dict:
        return {}

    try:
        with patch(_DRAIN_ENSURE) as mock_ensure, patch(
            _DRAIN_NOTIFY
        ) as mock_notify, patch(_RESUME):
            async with real_db() as session:
                await _recover_from_restart(session, wrappers={wf_name: my_fn})

        mock_ensure.assert_called_once_with(wf_name, my_fn)
        mock_notify.assert_called_once_with(wf_name)
    finally:
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=[run_id])


async def test_pending_run_for_unregistered_workflow_skipped(real_db):
    """Pending runs for a workflow not in wrappers should not start a drain task."""
    wf_name = _unique_name("pending_unreg")
    wf_id = await _create_workflow(real_db, wf_name)
    run_id = await _create_run(real_db, wf_id, WorkflowStatus.pending)

    try:
        with patch(_DRAIN_ENSURE) as mock_ensure, patch(
            _DRAIN_NOTIFY
        ) as mock_notify, patch(_RESUME):
            async with real_db() as session:
                await _recover_from_restart(session, wrappers={})

        mock_ensure.assert_not_called()
        mock_notify.assert_not_called()
    finally:
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=[run_id])


async def test_multiple_pending_workflows_all_drained(real_db):
    """Each pending workflow should get its own drain task."""
    names = [_unique_name("multi_pend") for _ in range(3)]
    wf_ids = [await _create_workflow(real_db, n) for n in names]
    run_ids = [
        await _create_run(real_db, wf_id, WorkflowStatus.pending) for wf_id in wf_ids
    ]

    fns = {n: (lambda inputs: {}) for n in names}

    try:
        with patch(_DRAIN_ENSURE) as mock_ensure, patch(
            _DRAIN_NOTIFY
        ) as mock_notify, patch(_RESUME):
            async with real_db() as session:
                await _recover_from_restart(session, wrappers=fns)

        assert mock_ensure.call_count == 3
        assert mock_notify.call_count == 3
    finally:
        await _cleanup(real_db, wf_ids=wf_ids, run_ids=run_ids)


async def test_clean_state_is_noop(real_db):
    """When there are no running or pending runs, nothing should be cancelled and no drain tasks should start."""
    with patch(_DRAIN_ENSURE) as mock_ensure, patch(
        _DRAIN_NOTIFY
    ) as mock_notify, patch(_RESUME):
        async with real_db() as session:
            await _recover_from_restart(session, wrappers={})

    mock_ensure.assert_not_called()
    mock_notify.assert_not_called()


async def test_child_runs_not_independently_resumed(real_db):
    """Child runs (parent_id IS NOT NULL) should not be independently scheduled for resume.

    Only the top-level parent run should be scheduled; child runs are handled
    recursively through their parent's resume.
    """
    wf_name = _unique_name("child_excl")
    wf_id = await _create_workflow(real_db, wf_name)
    parent_run_id = await _create_run(real_db, wf_id, WorkflowStatus.running)

    async with real_db() as session:
        child_run = WorkflowRun(
            workflow_id=wf_id,
            status=WorkflowStatus.running,
            triggered_by=TriggerType.manual,
            parent_id=parent_run_id,
            data={"inputs": {}, "outputs": {}, "actions": []},
        )
        session.add(child_run)
        await session.commit()
        await session.refresh(child_run)
        child_run_id = child_run.id

    async def raw_fn(inputs: dict) -> dict:
        return {}

    wrapper = MagicMock()
    wrapper._gtm_fn = raw_fn
    del wrapper._server_restart_logic
    del wrapper._restart_on_failure_check

    resume_calls: list = []

    async def _fake_resume(*args, **kwargs):
        resume_calls.append(args)

    try:
        async with real_db() as session:
            with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
                with patch(_RESUME, side_effect=_fake_resume):
                    await _recover_from_restart(session, wrappers={wf_name: wrapper})
                    await asyncio.sleep(0)

        assert len(resume_calls) == 1, "only the top-level parent run should be resumed"
        assert resume_calls[0][1] == parent_run_id
    finally:
        # Delete child before parent to satisfy the self-referential FK.
        await _cleanup(real_db, wf_ids=[], run_ids=[child_run_id])
        await _cleanup(real_db, wf_ids=[wf_id], run_ids=[parent_run_id])
