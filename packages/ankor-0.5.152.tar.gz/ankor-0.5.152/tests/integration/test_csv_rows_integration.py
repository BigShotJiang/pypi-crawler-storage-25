"""Integration tests for CSV import/export and paginated rows endpoint.

Tests use a real PostgreSQL database via the real_db fixture.
HTTP client: httpx.AsyncClient + ASGITransport.
"""

from __future__ import annotations

import csv
import io
import json
import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from sqlalchemy import delete as _sa_delete
from sqlalchemy import text

from ankor.database import get_session
from ankor.deps import get_current_user
from ankor.models import DataTable
from ankor.router import create_router
from ankor.db_helpers import _pg_table


def _unique_name(prefix: str = "csv") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def _make_app(real_db) -> FastAPI:
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    async def _override_session():
        async with real_db() as session:
            yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")
    return app


async def _create_full_table(
    real_db, table_name: str, extra_cols: list[dict] | None = None
) -> DataTable:
    """Register a DataTable and create its physical table via the actual create API."""
    app = _make_app(real_db)
    columns = [{"id": "name", "name": "name", "type": "text"}]
    if extra_cols:
        columns.extend(extra_cols)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/api/db-tables",
            json={"name": table_name, "columns": columns},
        )
    assert resp.status_code == 201, resp.text
    return DataTable(id=resp.json()["id"], name=table_name)


async def _cleanup_table(real_db, dt: DataTable) -> None:
    async with real_db() as session:
        await session.execute(text(f"DROP TABLE IF EXISTS {_pg_table(dt.id)}"))
        await session.execute(
            text("DELETE FROM data_table_column_meta WHERE table_id = :tid"),
            {"tid": dt.id},
        )
        await session.execute(_sa_delete(DataTable).where(DataTable.id == dt.id))
        await session.commit()


def _csv_bytes(content: str) -> bytes:
    return content.encode("utf-8")


async def test_export_empty_table_returns_header_only(real_db):
    """Exporting an empty table should return just the CSV header."""
    table_name = _unique_name("export_empty")
    dt = await _create_full_table(real_db, table_name)
    try:
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/db-tables/{dt.id}/export")
        assert resp.status_code == 200
        lines = resp.text.strip().splitlines()
        assert len(lines) == 1  # header only
        assert "id" in lines[0]
        assert "name" in lines[0]
    finally:
        await _cleanup_table(real_db, dt)


async def test_export_table_with_rows(real_db):
    """Exporting a table with rows should return one data row per inserted row."""
    table_name = _unique_name("export_rows")
    dt = await _create_full_table(real_db, table_name)
    try:
        # Insert two rows via CSV import
        csv_content = "id,name\n1,Alice\n2,Bob\n"
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.post(
                f"/api/db-tables/{dt.id}/import",
                files=[("file", ("data.csv", _csv_bytes(csv_content), "text/csv"))],
            )
            resp = await client.get(f"/api/db-tables/{dt.id}/export")
        assert resp.status_code == 200
        reader = csv.DictReader(io.StringIO(resp.text))
        rows = list(reader)
        assert len(rows) == 2
        names = {r["name"] for r in rows}
        assert names == {"Alice", "Bob"}
    finally:
        await _cleanup_table(real_db, dt)


async def test_export_unknown_table_returns_404(real_db):
    app = _make_app(real_db)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/db-tables/999999/export")
    assert resp.status_code == 404


async def test_export_returns_csv_content_type(real_db):
    table_name = _unique_name("export_ct")
    dt = await _create_full_table(real_db, table_name)
    try:
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/db-tables/{dt.id}/export")
        assert "text/csv" in resp.headers.get("content-type", "")
    finally:
        await _cleanup_table(real_db, dt)


async def test_import_rows_appear_in_table(real_db):
    """Imported CSV rows should be persisted in the physical table."""
    table_name = _unique_name("import_persist")
    dt = await _create_full_table(real_db, table_name)
    try:
        csv_content = "id,name\n1,Alice\n2,Bob\n"
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                f"/api/db-tables/{dt.id}/import",
                files=[("file", ("data.csv", _csv_bytes(csv_content), "text/csv"))],
            )
        assert resp.status_code == 200
        assert resp.json()["imported"] == 2

        # Verify the rows are in the DB
        async with real_db() as session:
            result = await session.execute(
                text(f"SELECT id, name FROM {_pg_table(dt.id)} ORDER BY id")
            )
            rows = result.fetchall()
        assert len(rows) == 2
        assert rows[0][1] == "Alice"
        assert rows[1][1] == "Bob"
    finally:
        await _cleanup_table(real_db, dt)


async def test_import_empty_csv_returns_zero_imported(real_db):
    """Importing a CSV with headers only should return imported=0."""
    table_name = _unique_name("import_empty")
    dt = await _create_full_table(real_db, table_name)
    try:
        csv_content = "id,name\n"
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                f"/api/db-tables/{dt.id}/import",
                files=[("file", ("data.csv", _csv_bytes(csv_content), "text/csv"))],
            )
        assert resp.status_code == 200
        assert resp.json()["imported"] == 0
    finally:
        await _cleanup_table(real_db, dt)


async def test_import_unknown_table_returns_404(real_db):
    csv_content = "id,name\n1,Alice\n"
    app = _make_app(real_db)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/api/db-tables/999999/import",
            files=[("file", ("data.csv", _csv_bytes(csv_content), "text/csv"))],
        )
    assert resp.status_code == 404


async def test_import_utf8_bom_handled(real_db):
    """CSV files with UTF-8 BOM (from Excel) should be decoded correctly."""
    table_name = _unique_name("import_bom")
    dt = await _create_full_table(real_db, table_name)
    try:
        bom_content = "\ufeffid,name\n1,Alice\n"
        bom_bytes = bom_content.encode("utf-8-sig")
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                f"/api/db-tables/{dt.id}/import",
                files=[("file", ("data.csv", bom_bytes, "text/csv"))],
            )
        assert resp.status_code == 200
        assert resp.json()["imported"] == 1
    finally:
        await _cleanup_table(real_db, dt)


async def test_import_float_column(real_db):
    """Float columns should be coerced correctly during CSV import."""
    table_name = _unique_name("import_float")
    dt = await _create_full_table(
        real_db,
        table_name,
        extra_cols=[{"id": "rating", "name": "rating", "type": "float"}],
    )
    try:
        csv_content = "id,name,rating\n1,Demo,4.75\n2,Other,0.5\n"
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                f"/api/db-tables/{dt.id}/import",
                files=[("file", ("data.csv", _csv_bytes(csv_content), "text/csv"))],
            )
        assert resp.status_code == 200
        assert resp.json()["imported"] == 2

        async with real_db() as session:
            result = await session.execute(
                text(f"SELECT rating FROM {_pg_table(dt.id)} ORDER BY id")
            )
            ratings = [r[0] for r in result.fetchall()]
        assert abs(float(ratings[0]) - 4.75) < 0.001
        assert abs(float(ratings[1]) - 0.5) < 0.001
    finally:
        await _cleanup_table(real_db, dt)


async def test_import_system_columns_ignored(real_db):
    """created_at / updated_at fields in the CSV should not cause errors and should not overwrite existing values."""
    table_name = _unique_name("import_syscol")
    dt = await _create_full_table(real_db, table_name)
    try:
        csv_content = "id,name,created_at,updated_at\n1,Alice,2026-01-01,2026-01-02\n"
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                f"/api/db-tables/{dt.id}/import",
                files=[("file", ("data.csv", _csv_bytes(csv_content), "text/csv"))],
            )
        assert resp.status_code == 200
        assert resp.json()["imported"] == 1
    finally:
        await _cleanup_table(real_db, dt)


async def test_rows_returns_rows_and_total(real_db):
    """GET /rows should return total count and a list of rows."""
    table_name = _unique_name("rows_basic")
    dt = await _create_full_table(real_db, table_name)
    try:
        # Import some rows
        csv_content = "id,name\n1,Alice\n2,Bob\n"
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.post(
                f"/api/db-tables/{dt.id}/import",
                files=[("file", ("data.csv", _csv_bytes(csv_content), "text/csv"))],
            )
            resp = await client.get(f"/api/db-tables/{dt.id}/rows")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["rows"]) == 2
    finally:
        await _cleanup_table(real_db, dt)


async def test_rows_empty_table_returns_zero(real_db):
    table_name = _unique_name("rows_empty")
    dt = await _create_full_table(real_db, table_name)
    try:
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/db-tables/{dt.id}/rows")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert data["rows"] == []
    finally:
        await _cleanup_table(real_db, dt)


async def test_rows_unknown_table_returns_404(real_db):
    app = _make_app(real_db)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/db-tables/999999/rows")
    assert resp.status_code == 404


async def test_rows_invalid_filter_json_returns_422(real_db):
    table_name = _unique_name("rows_bad_filter")
    dt = await _create_full_table(real_db, table_name)
    try:
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(
                f"/api/db-tables/{dt.id}/rows?filter=not_valid_json"
            )
        assert resp.status_code == 422
    finally:
        await _cleanup_table(real_db, dt)


async def test_rows_page_size_clamped_to_1000(real_db):
    table_name = _unique_name("rows_pgsize")
    dt = await _create_full_table(real_db, table_name)
    try:
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/db-tables/{dt.id}/rows?page_size=99999")
        assert resp.status_code == 200
    finally:
        await _cleanup_table(real_db, dt)


async def test_rows_negative_page_clamped(real_db):
    table_name = _unique_name("rows_negpage")
    dt = await _create_full_table(real_db, table_name)
    try:
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/db-tables/{dt.id}/rows?page=-5")
        assert resp.status_code == 200
    finally:
        await _cleanup_table(real_db, dt)


async def test_rows_pagination_total_reflects_full_set(real_db):
    """The total field should always reflect the full row count, not just the current page."""
    table_name = _unique_name("rows_pgtotal")
    dt = await _create_full_table(real_db, table_name)
    try:
        # Insert 5 rows
        csv_content = (
            "id,name\n" + "\n".join(f"{i},Name{i}" for i in range(1, 6)) + "\n"
        )
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.post(
                f"/api/db-tables/{dt.id}/import",
                files=[("file", ("data.csv", _csv_bytes(csv_content), "text/csv"))],
            )
            # Request page 1 with page_size=2 — total should still be 5
            resp = await client.get(f"/api/db-tables/{dt.id}/rows?page=1&page_size=2")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 5
    finally:
        await _cleanup_table(real_db, dt)


async def test_rows_valid_filter_accepted(real_db):
    """A valid filter JSON should be accepted and filter rows correctly."""
    table_name = _unique_name("rows_filter")
    dt = await _create_full_table(real_db, table_name)
    try:
        csv_content = "id,name\n1,Alice\n2,Bob\n3,Alice2\n"
        filter_val = json.dumps(
            [{"field": "name", "operator": "contains", "value": "Alice"}]
        )
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.post(
                f"/api/db-tables/{dt.id}/import",
                files=[("file", ("data.csv", _csv_bytes(csv_content), "text/csv"))],
            )
            resp = await client.get(f"/api/db-tables/{dt.id}/rows?filter={filter_val}")
        assert resp.status_code == 200
        data = resp.json()
        # Both "Alice" and "Alice2" match the contains filter
        assert data["total"] == 2
    finally:
        await _cleanup_table(real_db, dt)


async def test_rows_unknown_filter_field_skipped(real_db):
    """Filter items referencing unknown columns should be silently skipped."""
    table_name = _unique_name("rows_unk_field")
    dt = await _create_full_table(real_db, table_name)
    try:
        filter_val = json.dumps(
            [{"field": "nonexistent_col", "operator": "contains", "value": "x"}]
        )
        app = _make_app(real_db)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/db-tables/{dt.id}/rows?filter={filter_val}")
        assert resp.status_code == 200
    finally:
        await _cleanup_table(real_db, dt)
