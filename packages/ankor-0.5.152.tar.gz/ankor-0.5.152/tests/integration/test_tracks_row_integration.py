"""Integration tests for the tracks_row=True node feature.

Verifies that when a node with tracks_row=True completes (or fails), a history
entry is actually written to the physical DB row — not just that
flush_single_row_history was called with the right arguments.

All tests use a real PostgreSQL database via the real_db fixture.
"""

from __future__ import annotations

import json
import uuid

import pytest
from sqlalchemy import delete as _sa_delete
from sqlalchemy import text

import ankor.decorator as dec
from ankor.decorator.node import make_node_wrapper
from ankor.decorator.workflow import make_workflow_wrapper
from ankor.db_helpers import _pg_table
from ankor.models import DataTable, Workflow, WorkflowRun
from ankor.trigger_context import TriggerContext


def _unique_name(prefix: str = "trt") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _create_table_with_history(real_db, table_name: str) -> DataTable:
    """Create a DataTable registry row and physical table with history column."""
    async with real_db() as session:
        dt = DataTable(name=table_name)
        session.add(dt)
        await session.flush()
        await session.refresh(dt)
        tbl = _pg_table(dt.id)
        await session.execute(
            text(
                f"CREATE TABLE {tbl} ("
                "  id BIGINT PRIMARY KEY,"
                "  label TEXT,"
                "  history JSONB DEFAULT '[]',"
                "  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),"
                "  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()"
                ")"
            )
        )
        await session.commit()
        await session.refresh(dt)
    return dt


async def _insert_row(real_db, tbl_name: str, row_id: int, label: str = "test") -> None:
    async with real_db() as session:
        await session.execute(
            text(f"INSERT INTO {tbl_name} (id, label) VALUES (:id, :label)"),
            {"id": row_id, "label": label},
        )
        await session.commit()


async def _get_history(real_db, tbl_name: str, row_id: int) -> list:
    """Return the parsed history JSONB list for a physical table row."""
    async with real_db() as session:
        result = await session.execute(
            text(f"SELECT history FROM {tbl_name} WHERE id = :id"),
            {"id": row_id},
        )
        row = result.first()
        if row is None:
            return []
        val = row[0]
        if isinstance(val, str):
            val = json.loads(val)
        return val or []


async def _drop_table(real_db, dt: DataTable) -> None:
    async with real_db() as session:
        await session.execute(text(f"DROP TABLE IF EXISTS {_pg_table(dt.id)}"))
        await session.execute(_sa_delete(DataTable).where(DataTable.id == dt.id))
        await session.commit()


def _make_tc(table_id: int, row_ids: list[int]) -> TriggerContext:
    return TriggerContext(
        "manual",
        {},
        metadata={
            "table_action_context": {
                "table_id": table_id,
                "table_name": "TestTable",
                "row_ids": row_ids,
            }
        },
    )


async def test_tracks_row_success_writes_history(real_db):
    """A tracks_row=True node that succeeds should write a history entry to the DB row."""
    table_name = _unique_name()
    dt = await _create_table_with_history(real_db, table_name)
    tbl = _pg_table(dt.id)
    await _insert_row(real_db, tbl, row_id=1)

    async def process_row(inputs: dict) -> dict:
        return {"ok": True}

    node = make_node_wrapper(process_row, tracks_row=True)

    async def my_workflow(inputs: dict) -> dict:
        return await node(inputs)

    wrapped = make_workflow_wrapper(my_workflow)
    tc = _make_tc(dt.id, [1])

    try:
        await wrapped({"row_id": 1}, _ctx=tc)

        history = await _get_history(real_db, tbl, row_id=1)
        assert len(history) == 1
        entry = history[0]
        assert "wr_id" in entry
        assert entry.get("wf_name") == "my_workflow"
        assert "status" not in entry  # success entries have no status key
    finally:
        await _drop_table(real_db, dt)
        async with real_db() as session:
            wf = (
                await session.execute(
                    text("SELECT id FROM workflows WHERE name = 'my_workflow'")
                )
            ).first()
            if wf:
                await session.execute(
                    text("DELETE FROM workflow_runs WHERE workflow_id = :wid"),
                    {"wid": wf[0]},
                )
                await session.execute(
                    text("DELETE FROM workflows WHERE id = :wid"), {"wid": wf[0]}
                )
            await session.commit()


async def test_tracks_row_failure_writes_failed_history(real_db):
    """A tracks_row=True node that raises should write a history entry with status=failed."""
    table_name = _unique_name()
    dt = await _create_table_with_history(real_db, table_name)
    tbl = _pg_table(dt.id)
    await _insert_row(real_db, tbl, row_id=2)

    async def failing_node(inputs: dict) -> dict:
        raise ValueError("processing error")

    node = make_node_wrapper(failing_node, tracks_row=True)

    async def fail_workflow(inputs: dict) -> None:
        await node(inputs)

    wrapped = make_workflow_wrapper(fail_workflow)
    tc = _make_tc(dt.id, [2])

    try:
        # Workflow fails — that's expected
        try:
            await wrapped({"row_id": 2}, _ctx=tc)
        except (ValueError, Exception):
            pass  # expected — workflow raised

        history = await _get_history(real_db, tbl, row_id=2)
        assert len(history) == 1
        entry = history[0]
        assert entry.get("status") == "failed"
        assert "error" in entry
        assert "ValueError" in entry["error"]
    finally:
        await _drop_table(real_db, dt)
        async with real_db() as session:
            wf = (
                await session.execute(
                    text("SELECT id FROM workflows WHERE name = 'fail_workflow'")
                )
            ).first()
            if wf:
                await session.execute(
                    text("DELETE FROM workflow_runs WHERE workflow_id = :wid"),
                    {"wid": wf[0]},
                )
                await session.execute(
                    text("DELETE FROM workflows WHERE id = :wid"), {"wid": wf[0]}
                )
            await session.commit()


async def test_tracks_row_coerces_string_row_id(real_db):
    """String row_id in inputs should be coerced to int before writing history."""
    table_name = _unique_name()
    dt = await _create_table_with_history(real_db, table_name)
    tbl = _pg_table(dt.id)
    await _insert_row(real_db, tbl, row_id=8)

    async def node_fn(inputs: dict) -> dict:
        return {}

    node = make_node_wrapper(node_fn, tracks_row=True)

    async def str_rowid_workflow(inputs: dict) -> dict:
        return await node(inputs)

    wrapped = make_workflow_wrapper(str_rowid_workflow)
    tc = _make_tc(dt.id, [8])

    try:
        await wrapped({"row_id": "8"}, _ctx=tc)  # string row_id

        history = await _get_history(real_db, tbl, row_id=8)
        assert len(history) == 1  # history was written to row 8
    finally:
        await _drop_table(real_db, dt)
        async with real_db() as session:
            wf = (
                await session.execute(
                    text("SELECT id FROM workflows WHERE name = 'str_rowid_workflow'")
                )
            ).first()
            if wf:
                await session.execute(
                    text("DELETE FROM workflow_runs WHERE workflow_id = :wid"),
                    {"wid": wf[0]},
                )
                await session.execute(
                    text("DELETE FROM workflows WHERE id = :wid"), {"wid": wf[0]}
                )
            await session.commit()


async def test_tracks_row_no_op_when_row_id_missing(real_db):
    """When row_id is absent from inputs, no history should be written."""
    table_name = _unique_name()
    dt = await _create_table_with_history(real_db, table_name)
    tbl = _pg_table(dt.id)
    await _insert_row(real_db, tbl, row_id=5)

    async def node_fn(inputs: dict) -> dict:
        return {}

    node = make_node_wrapper(node_fn, tracks_row=True)

    async def no_rowid_workflow(inputs: dict) -> dict:
        return await node(inputs)  # no row_id in inputs

    wrapped = make_workflow_wrapper(no_rowid_workflow)
    tc = _make_tc(dt.id, [5])

    try:
        await wrapped({}, _ctx=tc)  # no row_id in inputs

        history = await _get_history(real_db, tbl, row_id=5)
        # Pre-registration via table_action_context writes an entry, but not from node flush
        # Check that the history list contains no entries with node_run_id (node was not tracked)
        node_entries = [e for e in history if e.get("node_run_id") is not None]
        assert node_entries == []
    finally:
        await _drop_table(real_db, dt)
        async with real_db() as session:
            wf = (
                await session.execute(
                    text("SELECT id FROM workflows WHERE name = 'no_rowid_workflow'")
                )
            ).first()
            if wf:
                await session.execute(
                    text("DELETE FROM workflow_runs WHERE workflow_id = :wid"),
                    {"wid": wf[0]},
                )
                await session.execute(
                    text("DELETE FROM workflows WHERE id = :wid"), {"wid": wf[0]}
                )
            await session.commit()


async def test_tracks_row_no_op_without_table_action_context(real_db):
    """A tracks_row=True node outside a table-action workflow should write no history."""
    table_name = _unique_name()
    dt = await _create_table_with_history(real_db, table_name)
    tbl = _pg_table(dt.id)
    await _insert_row(real_db, tbl, row_id=11)

    async def node_fn(inputs: dict) -> dict:
        return {}

    node = make_node_wrapper(node_fn, tracks_row=True)

    async def no_tac_workflow(inputs: dict) -> dict:
        return await node(inputs)

    wrapped = make_workflow_wrapper(no_tac_workflow)
    # TriggerContext with NO table_action_context
    tc = TriggerContext("manual", {"row_id": 11})

    try:
        await wrapped({"row_id": 11}, _ctx=tc)

        history = await _get_history(real_db, tbl, row_id=11)
        # No table_action_context → no pre-registration, no flush
        assert history == [] or all(e.get("node_run_id") is None for e in history)
    finally:
        await _drop_table(real_db, dt)
        async with real_db() as session:
            wf = (
                await session.execute(
                    text("SELECT id FROM workflows WHERE name = 'no_tac_workflow'")
                )
            ).first()
            if wf:
                await session.execute(
                    text("DELETE FROM workflow_runs WHERE workflow_id = :wid"),
                    {"wid": wf[0]},
                )
                await session.execute(
                    text("DELETE FROM workflows WHERE id = :wid"), {"wid": wf[0]}
                )
            await session.commit()


async def test_sub_node_does_not_write_history(real_db):
    """Inner node B (tracks_row=False) called by outer A (tracks_row=True) — only A should write history."""
    table_name = _unique_name()
    dt = await _create_table_with_history(real_db, table_name)
    tbl = _pg_table(dt.id)
    await _insert_row(real_db, tbl, row_id=7)

    async def b_fn(inputs: dict) -> dict:
        return {"b": "done"}

    node_b = make_node_wrapper(b_fn, tracks_row=False)

    async def a_fn(inputs: dict) -> dict:
        await node_b({"x": 1})
        await node_b({"x": 2})
        return {"a": "done"}

    node_a = make_node_wrapper(a_fn, tracks_row=True)

    async def sub_node_workflow(inputs: dict) -> dict:
        return await node_a(inputs)

    wrapped = make_workflow_wrapper(sub_node_workflow)
    tc = _make_tc(dt.id, [7])

    try:
        await wrapped({"row_id": 7}, _ctx=tc)

        history = await _get_history(real_db, tbl, row_id=7)
        # Exactly one history entry — from node A, not from B
        node_entries = [e for e in history if e.get("node_run_id") is not None]
        assert len(node_entries) == 1
    finally:
        await _drop_table(real_db, dt)
        async with real_db() as session:
            wf = (
                await session.execute(
                    text("SELECT id FROM workflows WHERE name = 'sub_node_workflow'")
                )
            ).first()
            if wf:
                await session.execute(
                    text("DELETE FROM workflow_runs WHERE workflow_id = :wid"),
                    {"wid": wf[0]},
                )
                await session.execute(
                    text("DELETE FROM workflows WHERE id = :wid"), {"wid": wf[0]}
                )
            await session.commit()


async def test_cascaded_failure_writes_failed_history(real_db):
    """When inner node B fails inside A (tracks_row=True), the history entry should have status=failed."""
    table_name = _unique_name()
    dt = await _create_table_with_history(real_db, table_name)
    tbl = _pg_table(dt.id)
    await _insert_row(real_db, tbl, row_id=9)

    async def b_fn(inputs: dict) -> dict:
        raise RuntimeError("B broke")

    node_b = make_node_wrapper(b_fn, tracks_row=False)

    async def a_fn(inputs: dict) -> dict:
        await node_b({"x": 1})
        return {}

    node_a = make_node_wrapper(a_fn, tracks_row=True)

    async def cascade_fail_workflow(inputs: dict) -> None:
        await node_a(inputs)

    wrapped = make_workflow_wrapper(cascade_fail_workflow)
    tc = _make_tc(dt.id, [9])

    try:
        try:
            await wrapped({"row_id": 9}, _ctx=tc)
        except (RuntimeError, Exception):
            pass  # expected — workflow raised

        history = await _get_history(real_db, tbl, row_id=9)
        node_entries = [e for e in history if e.get("node_run_id") is not None]
        assert len(node_entries) == 1
        assert node_entries[0].get("status") == "failed"
        assert "RuntimeError" in node_entries[0].get("error", "")
    finally:
        await _drop_table(real_db, dt)
        async with real_db() as session:
            wf = (
                await session.execute(
                    text(
                        "SELECT id FROM workflows WHERE name = 'cascade_fail_workflow'"
                    )
                )
            ).first()
            if wf:
                await session.execute(
                    text("DELETE FROM workflow_runs WHERE workflow_id = :wid"),
                    {"wid": wf[0]},
                )
                await session.execute(
                    text("DELETE FROM workflows WHERE id = :wid"), {"wid": wf[0]}
                )
            await session.commit()
