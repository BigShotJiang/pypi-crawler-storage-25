"""Integration tests for user, API-token, and webhook-token endpoints.

Tests GET/POST/DELETE /users, PATCH /users/{username}/password,
GET/POST/DELETE /tokens, GET/POST /webhook-token against a real PostgreSQL
database.

HTTP client: httpx.AsyncClient + ASGITransport.
"""

from __future__ import annotations

import uuid

from httpx import ASGITransport, AsyncClient
from sqlalchemy import delete as _sa_delete

import ankor.auth as auth_module
from ankor.models import ApiToken, User, UserRole, WebhookToken

# Stable secret so create_api_token / decode_token work in tests.
auth_module.configure("test-secret")


def _unique_name(prefix: str = "u") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _create_user(real_db, username: str, password: str = "pw") -> User:
    async with real_db() as session:
        user = User(
            username=username,
            hashed_password=auth_module.hash_password(password),
            role=UserRole.admin,
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return user


async def _delete_user(real_db, username: str) -> None:
    async with real_db() as session:
        await session.execute(_sa_delete(User).where(User.username == username))
        await session.commit()


async def _delete_token(real_db, token_id: int) -> None:
    async with real_db() as session:
        await session.execute(_sa_delete(ApiToken).where(ApiToken.id == token_id))
        await session.commit()


async def _delete_webhook_token(real_db) -> None:
    async with real_db() as session:
        await session.execute(_sa_delete(WebhookToken))
        await session.commit()


async def test_list_users_returns_users(real_db, make_test_app):
    u1 = _unique_name("alice")
    u2 = _unique_name("bob")
    await _create_user(real_db, u1)
    await _create_user(real_db, u2)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/users")
        assert resp.status_code == 200
        usernames = {u["username"] for u in resp.json()}
        assert u1 in usernames
        assert u2 in usernames
    finally:
        await _delete_user(real_db, u1)
        await _delete_user(real_db, u2)


async def test_list_users_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/users")
    assert resp.status_code == 401


async def test_create_user_success(real_db, make_test_app):
    username = _unique_name("new")
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/users", json={"username": username, "password": "pw"}
            )
        assert resp.status_code == 201
        assert resp.json()["username"] == username
    finally:
        await _delete_user(real_db, username)


async def test_create_user_duplicate_returns_409(real_db, make_test_app):
    username = _unique_name("dup")
    await _create_user(real_db, username)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/users", json={"username": username, "password": "pw"}
            )
        assert resp.status_code == 409
    finally:
        await _delete_user(real_db, username)


async def test_delete_own_user_is_forbidden(real_db, make_test_app):
    username = _unique_name("self")
    await _create_user(real_db, username)
    try:
        app = make_test_app(username=username)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.delete(f"/api/users/{username}")
        assert resp.status_code == 400
    finally:
        await _delete_user(real_db, username)


async def test_delete_user_not_found(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.delete("/api/users/ghost_nobody_xyz")
    assert resp.status_code == 404


async def test_delete_user_success(real_db, make_test_app):
    admin = _unique_name("admin_del")
    target = _unique_name("target")
    await _create_user(real_db, admin)
    await _create_user(real_db, target)
    try:
        app = make_test_app(username=admin)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.delete(f"/api/users/{target}")
        assert resp.status_code == 204

        async with real_db() as session:
            db_user = await session.get(User, target)
        assert db_user is None
    finally:
        await _delete_user(real_db, admin)
        await _delete_user(real_db, target)


async def test_update_password_not_found(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.patch(
            "/api/users/ghost_nobody_xyz/password", json={"password": "new"}
        )
    assert resp.status_code == 404


async def test_update_password_success(real_db, make_test_app):
    username = _unique_name("pw_update")
    await _create_user(real_db, username, password="old-pw")
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.patch(
                f"/api/users/{username}/password", json={"password": "new-pw"}
            )
        assert resp.status_code == 204
    finally:
        await _delete_user(real_db, username)


async def test_list_tokens_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/tokens")
    assert resp.status_code == 401


async def test_list_tokens_returns_own_tokens(real_db, make_test_app):
    username = _unique_name("tk_owner")
    await _create_user(real_db, username)
    token_id = None
    try:
        app = make_test_app(username=username)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            create_resp = await client.post("/api/tokens", json={"name": "ci-token"})
            token_id = create_resp.json()["id"]
            resp = await client.get("/api/tokens")
        assert resp.status_code == 200
        assert len(resp.json()) >= 1
        assert any(t["name"] == "ci-token" for t in resp.json())
    finally:
        if token_id:
            await _delete_token(real_db, token_id)
        await _delete_user(real_db, username)


async def test_create_token_returns_token_string(real_db, make_test_app):
    username = _unique_name("tk_create")
    await _create_user(real_db, username)
    token_id = None
    try:
        app = make_test_app(username=username)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/tokens", json={"name": "ci-token"})
        assert resp.status_code == 201
        body = resp.json()
        assert "token" in body
        assert body["name"] == "ci-token"
        token_id = body["id"]
    finally:
        if token_id:
            await _delete_token(real_db, token_id)
        await _delete_user(real_db, username)


async def test_create_token_with_expiry(real_db, make_test_app):
    username = _unique_name("tk_expiry")
    await _create_user(real_db, username)
    token_id = None
    try:
        app = make_test_app(username=username)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/tokens", json={"name": "short-lived", "expiresDays": 30}
            )
        assert resp.status_code == 201
        token_id = resp.json()["id"]
    finally:
        if token_id:
            await _delete_token(real_db, token_id)
        await _delete_user(real_db, username)


async def test_revoke_token_not_found(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.delete("/api/tokens/999999")
    assert resp.status_code == 404


async def test_revoke_token_belonging_to_other_user_is_404(real_db, make_test_app):
    """A token owned by someone else should appear as not-found (security measure)."""
    owner = _unique_name("tk_owner2")
    requester = _unique_name("tk_req")
    await _create_user(real_db, owner)
    token_id = None
    try:
        owner_app = make_test_app(username=owner)
        async with AsyncClient(
            transport=ASGITransport(owner_app), base_url="http://test"
        ) as client:
            create_resp = await client.post("/api/tokens", json={"name": "owner-token"})
        token_id = create_resp.json()["id"]

        req_app = make_test_app(username=requester)
        async with AsyncClient(
            transport=ASGITransport(req_app), base_url="http://test"
        ) as client:
            resp = await client.delete(f"/api/tokens/{token_id}")
        assert resp.status_code == 404
    finally:
        if token_id:
            await _delete_token(real_db, token_id)
        await _delete_user(real_db, owner)


async def test_revoke_token_success(real_db, make_test_app):
    username = _unique_name("tk_revoke")
    await _create_user(real_db, username)
    token_id = None
    try:
        app = make_test_app(username=username)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            create_resp = await client.post("/api/tokens", json={"name": "my-token"})
            token_id = create_resp.json()["id"]
            resp = await client.delete(f"/api/tokens/{token_id}")
        assert resp.status_code == 204

        async with real_db() as session:
            db_token = await session.get(ApiToken, token_id)
        assert db_token is None
        token_id = None
    finally:
        if token_id:
            await _delete_token(real_db, token_id)
        await _delete_user(real_db, username)


async def test_get_webhook_token_not_found(real_db, make_test_app):
    await _delete_webhook_token(real_db)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/webhook-token")
        assert resp.status_code == 404
    finally:
        await _delete_webhook_token(real_db)


async def test_get_webhook_token_found(real_db, make_test_app):
    await _delete_webhook_token(real_db)
    async with real_db() as session:
        wt = WebhookToken(token="abc123_test")
        session.add(wt)
        await session.commit()
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/webhook-token")
        assert resp.status_code == 200
        assert resp.json()["token"] == "abc123_test"
    finally:
        await _delete_webhook_token(real_db)


async def test_rotate_webhook_token_creates_new_when_absent(real_db, make_test_app):
    await _delete_webhook_token(real_db)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/webhook-token/rotate")
        assert resp.status_code == 200
        body = resp.json()
        assert "token" in body
        assert len(body["token"]) > 0
    finally:
        await _delete_webhook_token(real_db)


async def test_rotate_webhook_token_updates_existing(real_db, make_test_app):
    await _delete_webhook_token(real_db)
    async with real_db() as session:
        wt = WebhookToken(token="old-token-12345")
        session.add(wt)
        await session.commit()
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/webhook-token/rotate")
        assert resp.status_code == 200
        assert resp.json()["token"] != "old-token-12345"
    finally:
        await _delete_webhook_token(real_db)
