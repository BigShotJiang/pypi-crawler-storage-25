"""Integration tests for workflow-runs read endpoints.

Tests GET /workflow-runs/stats, GET /workflow-runs, GET /workflow-runs/{id},
GET /execution-buckets, GET /workflow-runs/{id}/nodes, GET /nodes/{id} against
a real PostgreSQL database.

HTTP client: httpx.AsyncClient + ASGITransport.
"""

from __future__ import annotations

import uuid

from httpx import ASGITransport, AsyncClient
from sqlalchemy import delete as _sa_delete

from ankor.models import RunNode, TriggerType, Workflow, WorkflowRun, WorkflowStatus


def _unique_name(prefix: str = "runs") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _create_wf_and_run(
    real_db,
    status: WorkflowStatus = WorkflowStatus.success,
) -> tuple[int, int]:
    wf_name = _unique_name()
    async with real_db() as session:
        wf = Workflow(name=wf_name)
        session.add(wf)
        await session.flush()
        await session.refresh(wf)
        run = WorkflowRun(
            workflow_id=wf.id,
            status=status,
            triggered_by=TriggerType.manual,
            data={"trigger_context": {}, "inputs": {}, "outputs": {}},
        )
        session.add(run)
        await session.commit()
        await session.refresh(run)
        return wf.id, run.id


async def _create_node(real_db, run_id: int, name: str = "fetch_data") -> int:
    async with real_db() as session:
        node = RunNode(
            run_id=run_id,
            parent_node_id=None,
            name=name,
            slug=None,
            status=WorkflowStatus.success,
            duration_ms=100,
            child_run_id=None,
            data={
                "inputs": {"query": "SELECT 1"},
                "outputs": {"result": 42},
                "logs": [],
            },
        )
        session.add(node)
        await session.commit()
        await session.refresh(node)
        return node.id


async def _cleanup(real_db, wf_id: int, run_id: int | None = None) -> None:
    async with real_db() as session:
        if run_id is not None:
            await session.execute(_sa_delete(RunNode).where(RunNode.run_id == run_id))
            await session.execute(
                _sa_delete(WorkflowRun).where(WorkflowRun.id == run_id)
            )
        await session.execute(_sa_delete(Workflow).where(Workflow.id == wf_id))
        await session.commit()


async def test_get_stats_returns_200(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflow-runs/stats")
    assert resp.status_code == 200
    body = resp.json()
    assert "pending" in body["counts"]
    assert "running" in body["counts"]
    assert "success" in body["counts"]
    assert "failed" in body["counts"]
    assert "cancelled" in body["counts"]
    assert "active" in body
    assert "recent" in body


async def test_get_stats_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflow-runs/stats")
    assert resp.status_code == 401


async def test_list_runs_empty(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflow-runs")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


async def test_list_runs_returns_x_total_count_header(real_db, make_test_app):
    wf_id, run_id = await _create_wf_and_run(real_db)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/workflow-runs")
        assert resp.status_code == 200
        assert "X-Total-Count" in resp.headers
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_list_runs_pagination_params_accepted(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflow-runs?offset=0&limit=10")
    assert resp.status_code == 200


async def test_list_runs_status_filter_accepted(real_db, make_test_app):
    wf_id, run_id = await _create_wf_and_run(real_db, WorkflowStatus.success)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/workflow-runs?status=success")
        assert resp.status_code == 200
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_list_runs_workflow_name_filter_accepted(real_db, make_test_app):
    wf_id, run_id = await _create_wf_and_run(real_db)
    try:
        async with real_db() as session:
            wf = await session.get(Workflow, wf_id)
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/workflow-runs?workflow_name={wf.name}")
        assert resp.status_code == 200
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_list_runs_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflow-runs")
    assert resp.status_code == 401


async def test_get_run_by_id_found(real_db, make_test_app):
    wf_id, run_id = await _create_wf_and_run(real_db, WorkflowStatus.success)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/workflow-runs/{run_id}")
        assert resp.status_code == 200
        body = resp.json()
        assert body["id"] == run_id
        assert body["status"] == "success"
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_get_run_by_id_not_found(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflow-runs/999999")
    assert resp.status_code == 404


async def test_get_run_by_id_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflow-runs/1")
    assert resp.status_code == 401


async def test_execution_buckets_returns_200(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/execution-buckets?from=0&to=60000&step=10000")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


async def test_execution_buckets_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/execution-buckets?from=0&to=60000&step=10000")
    assert resp.status_code == 401


async def test_get_run_nodes_empty(real_db, make_test_app):
    wf_id, run_id = await _create_wf_and_run(real_db)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/workflow-runs/{run_id}/nodes")
        assert resp.status_code == 200
        assert resp.json() == []
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_get_run_nodes_returns_slim_data(real_db, make_test_app):
    """The list endpoint should return a slim summary — inputs/outputs/logs should be excluded."""
    wf_id, run_id = await _create_wf_and_run(real_db)
    node_id = await _create_node(real_db, run_id, name="fetch_data")
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/workflow-runs/{run_id}/nodes")
        assert resp.status_code == 200
        body = resp.json()
        assert len(body) == 1
        n = body[0]
        assert n["id"] == node_id
        assert n["name"] == "fetch_data"
        assert n["status"] == "success"
        assert n["durationMs"] == 100
        assert "inputs" not in n
        assert "outputs" not in n
        assert "logs" not in n
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_get_run_nodes_not_found(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflow-runs/999999/nodes")
    assert resp.status_code == 404


async def test_get_run_nodes_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflow-runs/1/nodes")
    assert resp.status_code == 401


async def test_get_node_detail_returns_full_data(real_db, make_test_app):
    """GET /nodes/{id} should return the full node payload including inputs/outputs/logs."""
    wf_id, run_id = await _create_wf_and_run(real_db)
    async with real_db() as session:
        node = RunNode(
            run_id=run_id,
            parent_node_id=None,
            name="fetch_data",
            slug=None,
            status=WorkflowStatus.success,
            duration_ms=100,
            child_run_id=None,
            data={
                "inputs": {"query": "SELECT 1"},
                "outputs": {"result": 42},
                "logs": [
                    {
                        "timestamp": "2026-04-16T10:00:00+00:00",
                        "body": "ok",
                        "type": "info",
                        "json": False,
                    }
                ],
            },
        )
        session.add(node)
        await session.commit()
        await session.refresh(node)
        node_id = node.id

    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/nodes/{node_id}")
        assert resp.status_code == 200
        body = resp.json()
        assert body["id"] == node_id
        assert body["name"] == "fetch_data"
        assert body["status"] == "success"
        assert body["inputs"] == {"query": "SELECT 1"}
        assert body["outputs"] == {"result": 42}
        assert len(body["logs"]) == 1
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_get_node_detail_not_found(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/nodes/999999")
    assert resp.status_code == 404


async def test_get_node_detail_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/nodes/1")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# Subtree isolation & include_history tests (Change 1 + Change 2)
# ---------------------------------------------------------------------------


async def _create_node_full(
    real_db,
    run_id: int,
    name: str = "node",
    parent_node_id: int | None = None,
    data: dict | None = None,
) -> int:
    """Create a RunNode with custom parent/data and return its id."""
    async with real_db() as session:
        node = RunNode(
            run_id=run_id,
            parent_node_id=parent_node_id,
            name=name,
            slug=None,
            status=WorkflowStatus.success,
            duration_ms=50,
            child_run_id=None,
            data=data
            or {
                "inputs": {},
                "outputs": {},
                "logs": [],
            },
        )
        session.add(node)
        await session.commit()
        await session.refresh(node)
        return node.id


async def test_get_node_detail_only_returns_subtree(real_db, make_test_app):
    """GET /nodes/{id} must return only the target node's subtree.

    Sibling nodes that share the same run_id but are not descendants of the
    requested node must be absent from the response.
    """
    wf_id, run_id = await _create_wf_and_run(real_db)

    # root_a → child_a (two-level branch)
    root_a_id = await _create_node_full(real_db, run_id, name="root_a")
    child_a_id = await _create_node_full(
        real_db, run_id, name="child_a", parent_node_id=root_a_id
    )
    # root_b — sibling root (different branch, same run)
    root_b_id = await _create_node_full(real_db, run_id, name="root_b")

    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/nodes/{root_a_id}")

        assert resp.status_code == 200
        body = resp.json()
        assert body["id"] == root_a_id

        # The child should appear nested under root_a.
        child_ids = [c["id"] for c in body.get("children", [])]
        assert child_a_id in child_ids

        # The sibling root must NOT appear anywhere in the response.
        def _all_ids(node: dict) -> list[int]:
            ids = [node["id"]]
            for c in node.get("children", []):
                ids.extend(_all_ids(c))
            return ids

        all_ids = _all_ids(body)
        assert root_b_id not in all_ids
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_get_node_detail_strips_history_when_excluded(real_db, make_test_app):
    """GET /nodes/{id}?include_history=false must strip 'history' keys from I/O."""
    wf_id, run_id = await _create_wf_and_run(real_db)
    node_id = await _create_node_full(
        real_db,
        run_id,
        name="node_with_history",
        data={
            "inputs": {"row": {"id": 1, "name": "Alice", "history": [{"v": 0}]}},
            "outputs": {"row": {"id": 1, "name": "Alice", "history": [{"v": 1}]}},
            "logs": [],
        },
    )

    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/nodes/{node_id}?include_history=false")

        assert resp.status_code == 200
        body = resp.json()
        assert "history" not in body["inputs"]["row"]
        assert "history" not in body["outputs"]["row"]
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_get_node_detail_keeps_history_when_included(real_db, make_test_app):
    """GET /nodes/{id}?include_history=true must preserve 'history' keys in I/O."""
    wf_id, run_id = await _create_wf_and_run(real_db)
    node_id = await _create_node_full(
        real_db,
        run_id,
        name="node_with_history",
        data={
            "inputs": {"row": {"id": 1, "history": [{"v": 0}]}},
            "outputs": {"row": {"id": 1, "history": [{"v": 1}]}},
            "logs": [],
        },
    )

    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/nodes/{node_id}?include_history=true")

        assert resp.status_code == 200
        body = resp.json()
        assert "history" in body["inputs"]["row"]
        assert "history" in body["outputs"]["row"]
    finally:
        await _cleanup(real_db, wf_id, run_id)


# ---------------------------------------------------------------------------
# GET /nodes/{id}/children tests (Change 4)
# ---------------------------------------------------------------------------


async def test_get_node_children_returns_immediate_children(real_db, make_test_app):
    """GET /nodes/{id}/children returns direct children with childrenCount populated."""
    wf_id, run_id = await _create_wf_and_run(real_db)

    parent_id = await _create_node_full(real_db, run_id, name="parent")
    child1_id = await _create_node_full(
        real_db, run_id, name="child1", parent_node_id=parent_id
    )
    child2_id = await _create_node_full(
        real_db, run_id, name="child2", parent_node_id=parent_id
    )
    # Grandchild under child1 (so child1 childrenCount == 1, child2 == 0).
    await _create_node_full(
        real_db, run_id, name="grandchild", parent_node_id=child1_id
    )

    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/nodes/{parent_id}/children")

        assert resp.status_code == 200
        body = resp.json()
        assert len(body) == 2

        by_id = {n["id"]: n for n in body}
        assert child1_id in by_id
        assert child2_id in by_id
        assert by_id[child1_id]["childrenCount"] == 1
        assert by_id[child2_id]["childrenCount"] == 0
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_get_run_nodes_includes_children_count(real_db, make_test_app):
    """GET /workflow-runs/{id}/nodes includes childrenCount on each node summary."""
    wf_id, run_id = await _create_wf_and_run(real_db)

    parent_id = await _create_node_full(real_db, run_id, name="parent")
    await _create_node_full(real_db, run_id, name="child", parent_node_id=parent_id)

    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get(f"/api/workflow-runs/{run_id}/nodes")

        assert resp.status_code == 200
        body = resp.json()
        parent_node = next((n for n in body if n["id"] == parent_id), None)
        assert parent_node is not None
        assert "childrenCount" in parent_node
        assert parent_node["childrenCount"] >= 1
    finally:
        await _cleanup(real_db, wf_id, run_id)
