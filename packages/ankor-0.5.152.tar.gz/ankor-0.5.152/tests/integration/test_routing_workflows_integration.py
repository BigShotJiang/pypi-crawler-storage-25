"""Integration tests for workflow definition HTTP endpoints (list, get, patch, trigger).

Tests `GET/PATCH/POST /workflows` and `POST /workflow-runs/{id}/rerun` against
a real PostgreSQL database.  Verifies that PATCH actually persists Workflow rows
and that the trigger endpoint respects the enabled/disabled state stored in the DB.

HTTP client: httpx.AsyncClient + ASGITransport
"""

from __future__ import annotations

import uuid
from typing import Any
from unittest.mock import AsyncMock

from httpx import ASGITransport, AsyncClient
from sqlalchemy import delete as _sa_delete

from ankor.models import Workflow, WorkflowRun
from ankor.trigger_context import TriggerContext

_WORKFLOW_META = {
    "my_wf": {
        "trigger_type": "manual",
        "schedule": None,
        "is_webhook": False,
        "webhook_path": None,
        "input_schema": [],
        "description": None,
        "folder": None,
        "table_action": None,
        "examples": [],
        "how_it_works": None,
        "output_example": None,
    }
}


def _unique_wf_name(prefix: str = "wf") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _make_client(make_test_app, workflow_meta: dict, invoke=None) -> AsyncClient:
    app = make_test_app(workflow_meta=workflow_meta, invoke=invoke)
    return AsyncClient(transport=ASGITransport(app=app), base_url="http://test")


async def _cleanup_wf(real_db, name: str) -> None:
    async with real_db() as session:
        wf = (
            await session.execute(
                __import__("sqlalchemy").text(
                    "SELECT id FROM workflows WHERE name = :n"
                ),
                {"n": name},
            )
        ).first()
        if wf:
            await session.execute(
                _sa_delete(WorkflowRun).where(WorkflowRun.workflow_id == wf[0])
            )
            await session.execute(_sa_delete(Workflow).where(Workflow.id == wf[0]))
        await session.commit()


async def test_list_workflows_returns_registered_entries(make_test_app):
    async with await _make_client(make_test_app, _WORKFLOW_META) as client:
        resp = await client.get("/api/workflows")
    assert resp.status_code == 200
    body = resp.json()
    assert isinstance(body, list)
    assert any(w["name"] == "my_wf" for w in body)


async def test_list_workflows_empty_when_no_meta(make_test_app):
    async with await _make_client(make_test_app, {}) as client:
        resp = await client.get("/api/workflows")
    assert resp.status_code == 200
    assert resp.json() == []


async def test_list_workflows_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app(workflow_meta=_WORKFLOW_META)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflows")
    assert resp.status_code == 401


async def test_get_workflow_found(make_test_app):
    async with await _make_client(make_test_app, _WORKFLOW_META) as client:
        resp = await client.get("/api/workflows/my_wf")
    assert resp.status_code == 200
    assert resp.json()["name"] == "my_wf"


async def test_get_workflow_not_found(make_test_app):
    async with await _make_client(make_test_app, _WORKFLOW_META) as client:
        resp = await client.get("/api/workflows/unknown_wf")
    assert resp.status_code == 404


async def test_get_workflow_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app(workflow_meta=_WORKFLOW_META)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/workflows/my_wf")
    assert resp.status_code == 401


async def test_patch_workflow_not_found_returns_404(make_test_app):
    async with await _make_client(make_test_app, _WORKFLOW_META) as client:
        resp = await client.patch("/api/workflows/unknown_wf", json={"enabled": False})
    assert resp.status_code == 404


async def test_patch_workflow_creates_row_when_absent(real_db, make_test_app):
    """PATCH on a registered workflow with no existing DB row should create one."""
    wf_name = _unique_wf_name("patch_create")
    meta = {
        wf_name: {
            "trigger_type": "manual",
            "schedule": None,
            "is_webhook": False,
            "webhook_path": None,
            "input_schema": [],
            "description": None,
            "folder": None,
            "table_action": None,
            "examples": [],
            "how_it_works": None,
            "output_example": None,
        }
    }
    try:
        async with await _make_client(make_test_app, meta) as client:
            resp = await client.patch(
                f"/api/workflows/{wf_name}", json={"enabled": False}
            )

        assert resp.status_code == 200
        assert resp.json()["name"] == wf_name
        assert resp.json()["enabled"] is False

        # Verify the row was actually written to the DB
        from sqlmodel import select

        async with real_db() as session:
            db_wf = (
                await session.exec(select(Workflow).where(Workflow.name == wf_name))
            ).first()
            assert db_wf is not None
            assert db_wf.enabled is False
    finally:
        await _cleanup_wf(real_db, wf_name)


async def test_patch_workflow_updates_existing_row(real_db, make_test_app):
    """PATCH should persist changes to an existing Workflow DB row."""
    wf_name = _unique_wf_name("patch_update")
    meta = {
        wf_name: {
            "trigger_type": "manual",
            "schedule": None,
            "is_webhook": False,
            "webhook_path": None,
            "input_schema": [],
            "description": None,
            "folder": None,
            "table_action": None,
            "examples": [],
            "how_it_works": None,
            "output_example": None,
        }
    }
    try:
        async with await _make_client(make_test_app, meta) as client:
            # First PATCH: set enabled=False
            r1 = await client.patch(
                f"/api/workflows/{wf_name}", json={"enabled": False}
            )
            assert r1.status_code == 200

            # Second PATCH: re-enable
            r2 = await client.patch(f"/api/workflows/{wf_name}", json={"enabled": True})
            assert r2.status_code == 200
            assert r2.json()["enabled"] is True

        from sqlmodel import select

        async with real_db() as session:
            db_wf = (
                await session.exec(select(Workflow).where(Workflow.name == wf_name))
            ).first()
            assert db_wf.enabled is True
    finally:
        await _cleanup_wf(real_db, wf_name)


async def test_patch_workflow_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app(workflow_meta=_WORKFLOW_META)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.patch("/api/workflows/my_wf", json={"enabled": False})
    assert resp.status_code == 401


async def test_trigger_workflow_not_found_returns_404(make_test_app):
    async with await _make_client(make_test_app, _WORKFLOW_META) as client:
        resp = await client.post(
            "/api/workflows/unknown_wf/trigger", json={"inputs": {}}
        )
    assert resp.status_code == 404


async def test_trigger_workflow_disabled_returns_409(real_db, make_test_app):
    """Trigger should return 409 when the workflow's DB row has enabled=False."""
    wf_name = _unique_wf_name("trig_dis")
    meta = {
        wf_name: {
            "trigger_type": "manual",
            "schedule": None,
            "is_webhook": False,
            "webhook_path": None,
            "input_schema": [],
            "description": None,
            "folder": None,
            "table_action": None,
            "examples": [],
            "how_it_works": None,
            "output_example": None,
        }
    }
    try:
        # First PATCH to disable
        async with await _make_client(make_test_app, meta) as client:
            patch_resp = await client.patch(
                f"/api/workflows/{wf_name}", json={"enabled": False}
            )
            assert patch_resp.status_code == 200

            # Now trigger — must be 409
            resp = await client.post(
                f"/api/workflows/{wf_name}/trigger", json={"inputs": {}}
            )
            assert resp.status_code == 409
            assert "disabled" in resp.json()["detail"].lower()
    finally:
        await _cleanup_wf(real_db, wf_name)


async def test_trigger_workflow_enabled_returns_202(real_db, make_test_app):
    """Trigger should return 202 when the workflow is enabled in the DB."""
    wf_name = _unique_wf_name("trig_en")
    meta = {
        wf_name: {
            "trigger_type": "manual",
            "schedule": None,
            "is_webhook": False,
            "webhook_path": None,
            "input_schema": [],
            "description": None,
            "folder": None,
            "table_action": None,
            "examples": [],
            "how_it_works": None,
            "output_example": None,
        }
    }
    captured: dict = {}

    async def capturing_invoke(name: str, ctx: TriggerContext) -> None:
        captured["name"] = name
        captured["ctx"] = ctx

    try:
        async with await _make_client(
            make_test_app, meta, invoke=capturing_invoke
        ) as client:
            resp = await client.post(
                f"/api/workflows/{wf_name}/trigger",
                json={"inputs": {"key": "val"}},
            )

        assert resp.status_code == 202
        assert resp.json() == {"status": "accepted"}
        assert captured["name"] == wf_name
        assert captured["ctx"].inputs == {"key": "val"}
        assert captured["ctx"].type == "manual"
    finally:
        await _cleanup_wf(real_db, wf_name)


async def test_trigger_no_db_row_defaults_to_enabled(real_db, make_test_app):
    """A workflow with no DB row should be treated as enabled by default."""
    wf_name = _unique_wf_name("trig_norow")
    meta = {
        wf_name: {
            "trigger_type": "manual",
            "schedule": None,
            "is_webhook": False,
            "webhook_path": None,
            "input_schema": [],
            "description": None,
            "folder": None,
            "table_action": None,
            "examples": [],
            "how_it_works": None,
            "output_example": None,
        }
    }
    captured: dict = {}

    async def capturing_invoke(name: str, ctx: TriggerContext) -> None:
        captured["name"] = name

    try:
        async with await _make_client(
            make_test_app, meta, invoke=capturing_invoke
        ) as client:
            resp = await client.post(
                f"/api/workflows/{wf_name}/trigger", json={"inputs": {}}
            )

        assert resp.status_code == 202
        assert captured["name"] == wf_name
    finally:
        await _cleanup_wf(real_db, wf_name)


async def test_trigger_workflow_requires_auth(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app(workflow_meta=_WORKFLOW_META)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/api/workflows/my_wf/trigger", json={"inputs": {}})
    assert resp.status_code == 401


async def test_patch_then_trigger_respects_persisted_state(real_db, make_test_app):
    """After PATCH enabled=False, a subsequent trigger should see the persisted state and return 409."""
    wf_name = _unique_wf_name("patch_then_trigger")
    meta = {
        wf_name: {
            "trigger_type": "manual",
            "schedule": None,
            "is_webhook": False,
            "webhook_path": None,
            "input_schema": [],
            "description": None,
            "folder": None,
            "table_action": None,
            "examples": [],
            "how_it_works": None,
            "output_example": None,
        }
    }
    try:
        async with await _make_client(make_test_app, meta) as client:
            # Disable in DB
            await client.patch(f"/api/workflows/{wf_name}", json={"enabled": False})
            # Trigger in the same app (real DB) → must be 409
            resp = await client.post(
                f"/api/workflows/{wf_name}/trigger", json={"inputs": {}}
            )
        assert resp.status_code == 409
    finally:
        await _cleanup_wf(real_db, wf_name)


_SCHEMA_META = {
    "my_workflow": {
        "trigger_type": "manual",
        "schedule": None,
        "is_webhook": False,
        "webhook_path": None,
        "input_schema": [
            {"key": "limit", "type": "number", "label": "Limit", "default": 10},
            {"key": "dry_run", "type": "boolean", "label": "Dry run", "default": False},
            {
                "key": "mode",
                "type": "select",
                "label": "Mode",
                "options": ["fast", "slow"],
                "required": True,
            },
        ],
        "description": "Run this to enrich contacts.",
        "folder": None,
        "table_action": None,
        "examples": [],
        "how_it_works": None,
        "output_example": None,
    },
    "bare_workflow": {
        "trigger_type": "manual",
        "schedule": None,
        "is_webhook": False,
        "webhook_path": None,
        "input_schema": [],
        "description": None,
        "folder": None,
        "table_action": None,
        "examples": [],
        "how_it_works": None,
        "output_example": None,
    },
}


async def test_list_workflows_includes_input_schema(make_test_app):
    async with await _make_client(make_test_app, _SCHEMA_META) as client:
        resp = await client.get("/api/workflows")
    assert resp.status_code == 200
    body = resp.json()
    my_wf = next(w for w in body if w["name"] == "my_workflow")
    schema = my_wf["inputSchema"]
    assert len(schema) == 3

    limit_field = next(f for f in schema if f["key"] == "limit")
    assert limit_field["type"] == "number"
    assert limit_field["label"] == "Limit"
    assert limit_field["default"] == 10

    mode_field = next(f for f in schema if f["key"] == "mode")
    assert mode_field["options"] == ["fast", "slow"]
    assert mode_field.get("required") is True


async def test_list_workflows_includes_description(make_test_app):
    async with await _make_client(make_test_app, _SCHEMA_META) as client:
        resp = await client.get("/api/workflows")
    assert resp.status_code == 200
    body = resp.json()
    my_wf = next(w for w in body if w["name"] == "my_workflow")
    assert my_wf["description"] == "Run this to enrich contacts."


async def test_bare_workflow_has_empty_schema_and_no_description(make_test_app):
    async with await _make_client(make_test_app, _SCHEMA_META) as client:
        resp = await client.get("/api/workflows")
    assert resp.status_code == 200
    body = resp.json()
    bare = next(w for w in body if w["name"] == "bare_workflow")
    assert bare["inputSchema"] == []
    assert bare["description"] is None
