"""Integration tests for the POST /workflow-runs/{id}/rerun endpoint.

Inserts real WorkflowRun rows with specific trigger_context JSONB, then calls
the rerun endpoint and verifies that TriggerContext is correctly reconstructed.

HTTP client: httpx.AsyncClient + ASGITransport.
"""

from __future__ import annotations

import uuid

from httpx import ASGITransport, AsyncClient
from sqlalchemy import delete as _sa_delete

from ankor.models import TriggerType, Workflow, WorkflowRun, WorkflowStatus
from ankor.trigger_context import TriggerContext


def _unique_name(prefix: str = "rr") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _create_workflow_and_run(
    real_db,
    wf_name: str,
    triggered_by: str,
    trigger_context: dict,
) -> tuple[int, int]:
    """Insert Workflow + WorkflowRun rows, return (wf_id, run_id)."""
    from sqlmodel import select

    async with real_db() as session:
        wf = Workflow(name=wf_name)
        session.add(wf)
        await session.flush()
        await session.refresh(wf)
        run = WorkflowRun(
            workflow_id=wf.id,
            status=WorkflowStatus.success,
            triggered_by=TriggerType(triggered_by),
            data={
                "trigger_context": trigger_context,
                "inputs": {},
                "outputs": {},
            },
        )
        session.add(run)
        await session.commit()
        await session.refresh(run)
        return wf.id, run.id


async def _cleanup(real_db, wf_id: int, run_id: int) -> None:
    async with real_db() as session:
        await session.execute(_sa_delete(WorkflowRun).where(WorkflowRun.id == run_id))
        await session.execute(_sa_delete(Workflow).where(Workflow.id == wf_id))
        await session.commit()


async def test_rerun_run_not_found(real_db, make_test_app):
    captured: dict = {}

    async def invoke(name: str, ctx: TriggerContext) -> None:
        captured.update(name=name, ctx=ctx)

    app = make_test_app(invoke=invoke)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/api/workflow-runs/999999/rerun")
    assert resp.status_code == 404


async def test_rerun_unregistered_workflow_returns_404(real_db, make_test_app):
    """If invoke raises KeyError (workflow not registered), the endpoint should return 404."""
    wf_name = _unique_name("gone")
    tc = {"type": "manual", "inputs": {}}
    wf_id, run_id = await _create_workflow_and_run(real_db, wf_name, "manual", tc)

    async def invoke(name: str, ctx: TriggerContext) -> None:
        raise KeyError(name)

    try:
        app = make_test_app(invoke=invoke)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(f"/api/workflow-runs/{run_id}/rerun")
        assert resp.status_code == 404
        assert wf_name in resp.json()["detail"]
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_rerun_manual_success(real_db, make_test_app):
    """Rerunning a manual run should build the correct TriggerContext from the stored trigger_context."""
    wf_name = _unique_name("manual")
    tc = {"type": "manual", "inputs": {"foo": "bar"}}
    wf_id, run_id = await _create_workflow_and_run(real_db, wf_name, "manual", tc)

    captured: dict = {}

    async def invoke(name: str, ctx: TriggerContext) -> None:
        captured.update(name=name, ctx=ctx)

    try:
        app = make_test_app(invoke=invoke)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(f"/api/workflow-runs/{run_id}/rerun")
        assert resp.status_code == 202
        assert resp.json() == {"status": "accepted"}

        ctx: TriggerContext = captured["ctx"]
        assert ctx.type == "rerun"
        assert ctx.inputs == {"foo": "bar"}
        assert ctx.metadata["originalType"] == "manual"
        assert ctx.metadata["originalRunId"] == str(run_id)
        assert captured["name"] == wf_name
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_rerun_webhook_preserves_body_and_headers(real_db, make_test_app):
    """Rerunning a webhook run should preserve the body and headers from the original run."""
    wf_name = _unique_name("webhook")
    tc = {
        "type": "webhook",
        "inputs": {
            "body": {"email": "x@x.com"},
            "headers": {"content-type": "application/json", "x-trace-id": "abc"},
        },
    }
    wf_id, run_id = await _create_workflow_and_run(real_db, wf_name, "webhook", tc)

    captured: dict = {}

    async def invoke(name: str, ctx: TriggerContext) -> None:
        captured["ctx"] = ctx

    try:
        app = make_test_app(invoke=invoke)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(f"/api/workflow-runs/{run_id}/rerun")
        assert resp.status_code == 202

        ctx: TriggerContext = captured["ctx"]
        assert ctx.type == "rerun"
        assert ctx.inputs["body"]["email"] == "x@x.com"
        assert ctx.inputs["headers"]["x-trace-id"] == "abc"
        assert ctx.metadata["originalType"] == "webhook"
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_rerun_schedule_preserves_schedule(real_db, make_test_app):
    """Rerunning a schedule-triggered run should preserve the schedule string."""
    wf_name = _unique_name("schedule")
    tc = {
        "type": "schedule",
        "inputs": {},
        "schedule": "0 9 * * 1-5",
    }
    wf_id, run_id = await _create_workflow_and_run(real_db, wf_name, "schedule", tc)

    captured: dict = {}

    async def invoke(name: str, ctx: TriggerContext) -> None:
        captured["ctx"] = ctx

    try:
        app = make_test_app(invoke=invoke)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(f"/api/workflow-runs/{run_id}/rerun")
        assert resp.status_code == 202

        ctx: TriggerContext = captured["ctx"]
        assert ctx.metadata["schedule"] == "0 9 * * 1-5"
        assert ctx.metadata["originalType"] == "schedule"
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_rerun_legacy_run_empty_trigger_context(real_db, make_test_app):
    """Runs with an empty trigger_context should fall back to triggered_by as the originalType."""
    wf_name = _unique_name("legacy")
    tc: dict = {}  # legacy: no trigger_context field
    wf_id, run_id = await _create_workflow_and_run(real_db, wf_name, "webhook", tc)

    captured: dict = {}

    async def invoke(name: str, ctx: TriggerContext) -> None:
        captured["ctx"] = ctx

    try:
        app = make_test_app(invoke=invoke)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(f"/api/workflow-runs/{run_id}/rerun")
        assert resp.status_code == 202

        ctx: TriggerContext = captured["ctx"]
        assert ctx.metadata["originalType"] == "webhook"
        assert ctx.inputs == {}
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_rerun_dispatches_correct_workflow_name(real_db, make_test_app):
    """The correct workflow name should be dispatched to invoke."""
    wf_name = _unique_name("enrich_leads")
    tc = {"type": "manual", "inputs": {}}
    wf_id, run_id = await _create_workflow_and_run(real_db, wf_name, "manual", tc)

    captured: dict = {}

    async def invoke(name: str, ctx: TriggerContext) -> None:
        captured["name"] = name

    try:
        app = make_test_app(invoke=invoke)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.post(f"/api/workflow-runs/{run_id}/rerun")
        assert captured["name"] == wf_name
    finally:
        await _cleanup(real_db, wf_id, run_id)
