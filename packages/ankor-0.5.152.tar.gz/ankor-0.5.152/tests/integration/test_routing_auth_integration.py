"""Integration tests for auth router endpoints.

Tests GET /health, GET/POST /auth/setup-status, POST /auth/setup,
POST /auth/token (login), and POST /auth/register against a real PostgreSQL
database.

HTTP client: httpx.AsyncClient + ASGITransport.
"""

from __future__ import annotations

import uuid

from httpx import ASGITransport, AsyncClient
from sqlalchemy import delete as _sa_delete

import ankor.auth as auth_module
from ankor.models import User, UserRole

# Stable JWT secret so tokens generated in tests are verifiable.
auth_module.configure("test-secret")


def _unique_name(prefix: str = "u") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _create_user(real_db, username: str, password: str = "pw") -> User:
    async with real_db() as session:
        user = User(
            username=username,
            hashed_password=auth_module.hash_password(password),
            role=UserRole.admin,
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return user


async def _delete_user(real_db, username: str) -> None:
    async with real_db() as session:
        await session.execute(_sa_delete(User).where(User.username == username))
        await session.commit()


async def test_health(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


async def test_setup_status_required_when_no_users(make_unauthenticated_test_app):
    """With no users in DB, setupRequired must be True."""
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/api/auth/setup-status")
    assert resp.status_code == 200
    assert resp.json()["setupRequired"] is True


async def test_setup_status_not_required_when_users_exist(
    real_db, make_unauthenticated_test_app
):
    username = _unique_name("setup")
    await _create_user(real_db, username)
    try:
        app = make_unauthenticated_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/auth/setup-status")
        assert resp.status_code == 200
        assert resp.json()["setupRequired"] is False
    finally:
        await _delete_user(real_db, username)


async def test_setup_creates_admin_when_empty(real_db, make_unauthenticated_test_app):
    username = _unique_name("setup_admin")
    try:
        app = make_unauthenticated_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/auth/setup",
                json={"username": username, "password": "secret", "email": "a@b.com"},
            )
        assert resp.status_code == 201
        assert resp.json()["username"] == username
    finally:
        await _delete_user(real_db, username)


async def test_setup_conflicts_when_already_configured(
    real_db, make_unauthenticated_test_app
):
    username = _unique_name("existing")
    await _create_user(real_db, username)
    try:
        app = make_unauthenticated_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/auth/setup",
                json={"username": "newadmin", "password": "secret", "email": "b@b.com"},
            )
        assert resp.status_code == 409
    finally:
        await _delete_user(real_db, username)


async def test_login_valid_credentials(real_db, make_unauthenticated_test_app):
    username = _unique_name("login")
    await _create_user(real_db, username, password="correct-pw")
    try:
        app = make_unauthenticated_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/auth/token",
                data={"username": username, "password": "correct-pw"},
            )
        assert resp.status_code == 200
        body = resp.json()
        assert "access_token" in body
        assert body["token_type"] == "bearer"
    finally:
        await _delete_user(real_db, username)


async def test_login_wrong_password(real_db, make_unauthenticated_test_app):
    username = _unique_name("wrongpw")
    await _create_user(real_db, username, password="correct-pw")
    try:
        app = make_unauthenticated_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/auth/token",
                data={"username": username, "password": "wrong-pw"},
            )
        assert resp.status_code == 401
    finally:
        await _delete_user(real_db, username)


async def test_login_unknown_user(make_unauthenticated_test_app):
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/api/auth/token",
            data={"username": "nobody_xyz", "password": "pw"},
        )
    assert resp.status_code == 401


async def test_register_new_user(real_db, make_test_app):
    admin = _unique_name("admin")
    new_user = _unique_name("newuser")
    await _create_user(real_db, admin)
    try:
        app = make_test_app(username=admin)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/auth/register",
                data={"username": new_user, "password": "pw"},
            )
        assert resp.status_code == 201
        assert resp.json()["username"] == new_user
    finally:
        await _delete_user(real_db, admin)
        await _delete_user(real_db, new_user)


async def test_register_duplicate_user(real_db, make_test_app):
    existing = _unique_name("bob")
    await _create_user(real_db, existing)
    try:
        app = make_test_app(username="admin")
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/api/auth/register",
                data={"username": existing, "password": "pw"},
            )
        assert resp.status_code == 409
    finally:
        await _delete_user(real_db, existing)


async def test_register_requires_authentication(make_unauthenticated_test_app):
    """Without auth override, /auth/register should return 401."""
    app = make_unauthenticated_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/api/auth/register",
            data={"username": "x", "password": "y"},
        )
    assert resp.status_code == 401
