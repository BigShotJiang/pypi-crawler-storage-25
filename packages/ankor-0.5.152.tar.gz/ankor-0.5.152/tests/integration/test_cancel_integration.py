"""Integration tests for cancel workflow-run endpoints.

Tests POST /workflow-runs/{id}/cancel, cancel-pending, and cancel-all against
a real PostgreSQL database.

HTTP client: httpx.AsyncClient + ASGITransport.
"""

from __future__ import annotations

import uuid
from unittest.mock import MagicMock

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy import delete as _sa_delete
from sqlmodel import select

import ankor.decorator as dec
from ankor.models import TriggerType, Workflow, WorkflowRun, WorkflowStatus


def _unique_name(prefix: str = "cancel") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _create_wf_and_run(real_db, status: WorkflowStatus) -> tuple[int, int]:
    """Insert a Workflow + WorkflowRun, return (wf_id, run_id)."""
    wf_name = _unique_name()
    async with real_db() as session:
        wf = Workflow(name=wf_name)
        session.add(wf)
        await session.flush()
        await session.refresh(wf)
        run = WorkflowRun(
            workflow_id=wf.id,
            status=status,
            triggered_by=TriggerType.manual,
            data={"trigger_context": {}, "inputs": {}, "outputs": {}},
        )
        session.add(run)
        await session.commit()
        await session.refresh(run)
        return wf.id, run.id


async def _cleanup(real_db, wf_id: int, run_id: int | None = None) -> None:
    async with real_db() as session:
        if run_id is not None:
            await session.execute(
                _sa_delete(WorkflowRun).where(WorkflowRun.id == run_id)
            )
        await session.execute(_sa_delete(Workflow).where(Workflow.id == wf_id))
        await session.commit()


async def _get_run(real_db, run_id: int) -> WorkflowRun | None:
    async with real_db() as session:
        return await session.get(WorkflowRun, run_id)


async def test_cancel_run_not_found(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/api/workflow-runs/999999/cancel")
    assert resp.status_code == 404


@pytest.mark.parametrize(
    "terminal_status",
    [
        WorkflowStatus.success,
        WorkflowStatus.failed,
        WorkflowStatus.cancelled,
    ],
)
async def test_cancel_run_already_terminal(real_db, terminal_status, make_test_app):
    wf_id, run_id = await _create_wf_and_run(real_db, terminal_status)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(f"/api/workflow-runs/{run_id}/cancel")
        assert resp.status_code == 409
        assert "terminal" in resp.json()["detail"].lower()
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_cancel_pending_run_updates_db(real_db, make_test_app):
    wf_id, run_id = await _create_wf_and_run(real_db, WorkflowStatus.pending)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(f"/api/workflow-runs/{run_id}/cancel")
        assert resp.status_code == 200
        assert resp.json() == {"status": "cancelled"}

        run = await _get_run(real_db, run_id)
        assert run.status == WorkflowStatus.cancelled
        assert run.finished_at is not None
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_cancel_running_run_updates_db(real_db, make_test_app):
    wf_id, run_id = await _create_wf_and_run(real_db, WorkflowStatus.running)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post(f"/api/workflow-runs/{run_id}/cancel")
        assert resp.status_code == 200

        run = await _get_run(real_db, run_id)
        assert run.status == WorkflowStatus.cancelled
        assert run.finished_at is not None
    finally:
        await _cleanup(real_db, wf_id, run_id)


async def test_cancel_running_run_cancels_live_task(real_db, make_test_app):
    """If a live asyncio task is registered for the run, it should be cancelled."""
    wf_id, run_id = await _create_wf_and_run(real_db, WorkflowStatus.running)
    mock_task = MagicMock()
    mock_task.done.return_value = False
    dec._running_tasks[run_id] = mock_task
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.post(f"/api/workflow-runs/{run_id}/cancel")
        mock_task.cancel.assert_called_once()
    finally:
        dec._running_tasks.pop(run_id, None)
        await _cleanup(real_db, wf_id, run_id)


async def test_cancel_pending_no_pending_runs(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/api/workflow-runs/cancel-pending")
    assert resp.status_code == 200
    assert resp.json()["cancelled"] == 0


async def test_cancel_pending_cancels_all_pending(real_db, make_test_app):
    # Create 3 pending runs across 2 workflows
    wf_ids: list[int] = []
    run_ids: list[int] = []
    for _ in range(3):
        wf_id, run_id = await _create_wf_and_run(real_db, WorkflowStatus.pending)
        wf_ids.append(wf_id)
        run_ids.append(run_id)

    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/workflow-runs/cancel-pending")
        assert resp.status_code == 200
        assert resp.json()["cancelled"] == 3

        for run_id in run_ids:
            run = await _get_run(real_db, run_id)
            assert run.status == WorkflowStatus.cancelled
            assert run.finished_at is not None
    finally:
        for wf_id, run_id in zip(wf_ids, run_ids):
            await _cleanup(real_db, wf_id, run_id)


async def test_cancel_pending_does_not_affect_running_runs(real_db, make_test_app):
    wf_id_p, run_id_p = await _create_wf_and_run(real_db, WorkflowStatus.pending)
    wf_id_r, run_id_r = await _create_wf_and_run(real_db, WorkflowStatus.running)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/workflow-runs/cancel-pending")
        assert resp.json()["cancelled"] == 1

        pending_run = await _get_run(real_db, run_id_p)
        running_run = await _get_run(real_db, run_id_r)
        assert pending_run.status == WorkflowStatus.cancelled
        assert running_run.status == WorkflowStatus.running
    finally:
        await _cleanup(real_db, wf_id_p, run_id_p)
        await _cleanup(real_db, wf_id_r, run_id_r)


async def test_cancel_all_no_active_runs(make_test_app):
    app = make_test_app()
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/api/workflow-runs/cancel-all")
    assert resp.status_code == 200
    assert resp.json()["cancelled"] == 0


async def test_cancel_all_cancels_pending_and_running(real_db, make_test_app):
    wf_id_p, run_id_p = await _create_wf_and_run(real_db, WorkflowStatus.pending)
    wf_id_r, run_id_r = await _create_wf_and_run(real_db, WorkflowStatus.running)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/workflow-runs/cancel-all")
        assert resp.status_code == 200
        assert resp.json()["cancelled"] == 2

        for run_id in (run_id_p, run_id_r):
            run = await _get_run(real_db, run_id)
            assert run.status == WorkflowStatus.cancelled
            assert run.finished_at is not None
    finally:
        await _cleanup(real_db, wf_id_p, run_id_p)
        await _cleanup(real_db, wf_id_r, run_id_r)


async def test_cancel_all_does_not_affect_terminal_runs(real_db, make_test_app):
    wf_id_s, run_id_s = await _create_wf_and_run(real_db, WorkflowStatus.success)
    wf_id_p, run_id_p = await _create_wf_and_run(real_db, WorkflowStatus.pending)
    try:
        app = make_test_app()
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/workflow-runs/cancel-all")
        assert resp.json()["cancelled"] == 1

        success_run = await _get_run(real_db, run_id_s)
        assert success_run.status == WorkflowStatus.success
    finally:
        await _cleanup(real_db, wf_id_s, run_id_s)
        await _cleanup(real_db, wf_id_p, run_id_p)
