"""Integration tests for DbStore CRUD operations against a real PostgreSQL database.

Tests that methods correctly persist and retrieve data, enforce constraints, and
handle error paths. All tests use a real PostgreSQL instance via the real_db fixture.

Marked ``db`` — run sequentially.
"""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy import delete as _sa_delete
from sqlalchemy import text

from ankor import OrderBy, RowFilter
from ankor.db_helpers import _pg_table
from ankor.db_store import DbStore
from ankor.models import DataTable


def _unique_table(prefix: str = "test_tbl") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _create_test_table(real_db, table_name: str) -> DataTable:
    """Register a DataTable and create its physical table with label (TEXT) and count (BIGINT) columns."""
    async with real_db() as session:
        dt = DataTable(name=table_name)
        session.add(dt)
        await session.flush()
        await session.refresh(dt)
        tbl = _pg_table(dt.id)
        await session.execute(
            text(
                f"CREATE TABLE {tbl} ("
                "  id BIGINT PRIMARY KEY,"
                "  label TEXT,"
                "  count BIGINT,"
                "  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),"
                "  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()"
                ")"
            )
        )
        await session.commit()
        await session.refresh(dt)
    return dt


async def _drop_test_table(real_db, dt: DataTable) -> None:
    """Drop the physical table and remove the DataTable registry row."""
    async with real_db() as session:
        await session.execute(text(f"DROP TABLE IF EXISTS {_pg_table(dt.id)}"))
        await session.execute(_sa_delete(DataTable).where(DataTable.id == dt.id))
        await session.commit()


@pytest.mark.db
async def test_add_row_and_get_row_round_trip(real_db):
    """add_row should persist data to the DB and get_row should return the same values."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        added = await db.add_row(table_name, {"label": "hello", "count": 5})

        assert added["label"] == "hello"
        assert added["count"] == 5
        assert "id" in added

        fetched = await db.get_row(table_name, added["id"])
        assert fetched is not None
        assert fetched["id"] == added["id"]
        assert fetched["label"] == "hello"
        assert fetched["count"] == 5
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_get_row_not_found_returns_none(real_db):
    """get_row should return None for a row ID that does not exist."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        result = await db.get_row(table_name, 9999)
        assert result is None
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_add_row_assigns_sequential_ids(real_db):
    """add_row should assign incrementing IDs to each new row."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        r1 = await db.add_row(table_name, {"label": "first"})
        r2 = await db.add_row(table_name, {"label": "second"})
        r3 = await db.add_row(table_name, {"label": "third"})
        assert r1["id"] < r2["id"] < r3["id"]
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_rows_returns_all_inserted_rows(real_db):
    """rows() should return all rows present in the table."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        await db.add_row(table_name, {"label": "alpha", "count": 1})
        await db.add_row(table_name, {"label": "beta", "count": 2})
        await db.add_row(table_name, {"label": "gamma", "count": 3})

        all_rows = await db.rows(table_name)
        assert len(all_rows) == 3
        assert {r["label"] for r in all_rows} == {"alpha", "beta", "gamma"}
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_rows_with_filter(real_db):
    """rows() with a filter should return only matching rows."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        await db.add_row(table_name, {"label": "low", "count": 2})
        await db.add_row(table_name, {"label": "mid", "count": 5})
        await db.add_row(table_name, {"label": "high", "count": 10})

        high_rows = await db.rows(table_name, filters=[RowFilter("count", "gt", 4)])
        assert len(high_rows) == 2
        assert {r["label"] for r in high_rows} == {"mid", "high"}
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_rows_with_columns_selection(real_db):
    """rows() with columns= should return only those fields (plus id)."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        await db.add_row(table_name, {"label": "row1", "count": 99})

        result = await db.rows(table_name, columns=["label"])
        assert len(result) == 1
        assert "id" in result[0]
        assert "label" in result[0]
        assert "count" not in result[0]
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_rows_with_order_by(real_db):
    """rows() with order_by= should return rows in the specified order."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        await db.add_row(table_name, {"label": "c", "count": 3})
        await db.add_row(table_name, {"label": "a", "count": 1})
        await db.add_row(table_name, {"label": "b", "count": 2})

        asc_rows = await db.rows(table_name, order_by=OrderBy("count", "asc"))
        assert [r["label"] for r in asc_rows] == ["a", "b", "c"]

        desc_rows = await db.rows(table_name, order_by=OrderBy("count", "desc"))
        assert [r["label"] for r in desc_rows] == ["c", "b", "a"]
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_rows_unknown_column_raises_value_error(real_db):
    """rows() raises ValueError when an unknown column is requested."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        with pytest.raises(ValueError, match="Unknown columns"):
            await db.rows(table_name, columns=["nonexistent"])
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_row_merges_data(real_db):
    """update_row should merge new values into the row; unchanged columns should be preserved."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        row = await db.add_row(table_name, {"label": "original", "count": 1})
        result = await db.update_row(table_name, row["id"], {"label": "updated"})

        assert result["old"]["label"] == "original"
        assert result["new"]["label"] == "updated"
        assert result["new"]["count"] == 1  # unchanged column preserved

        fetched = await db.get_row(table_name, row["id"])
        assert fetched["label"] == "updated"
        assert fetched["count"] == 1
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_row_returns_old_and_new_with_meta(real_db):
    """update_row should return {old, new, _meta} with a diff view in _meta."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        row = await db.add_row(table_name, {"label": "before", "count": 7})
        result = await db.update_row(table_name, row["id"], {"count": 42})

        assert "old" in result
        assert "new" in result
        assert "_meta" in result
        view_keys = [v["key"] for v in result["_meta"]["views"]]
        assert "diff" in view_keys
        assert "old" in view_keys
        assert "new" in view_keys
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_row_not_found_raises_key_error(real_db):
    """update_row raises KeyError when the row ID does not exist."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        with pytest.raises(KeyError):
            await db.update_row(table_name, 9999, {"label": "ghost"})
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_row_unknown_column_silently_ignored(real_db):
    """update_row should silently drop keys not present as table columns."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        row = await db.add_row(table_name, {"label": "original", "count": 5})
        result = await db.update_row(table_name, row["id"], {"nonexistent_col": "x"})

        assert result["old"]["label"] == result["new"]["label"]
        assert result["old"]["count"] == result["new"]["count"]
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_row_empty_data_is_no_op(real_db):
    """update_row with {} should return old == new and should not mutate the DB row."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        row = await db.add_row(table_name, {"label": "unchanged", "count": 3})
        result = await db.update_row(table_name, row["id"], {})

        assert result["old"] == result["new"]
        assert "diff" not in [v["key"] for v in result["_meta"]["views"]]

        fetched = await db.get_row(table_name, row["id"])
        assert fetched["label"] == "unchanged"
        assert fetched["count"] == 3
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_delete_row_removes_from_db(real_db):
    """delete_row should remove the row; a subsequent get_row should return None."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        row = await db.add_row(table_name, {"label": "to-delete", "count": 99})
        await db.delete_row(table_name, row["id"])

        fetched = await db.get_row(table_name, row["id"])
        assert fetched is None
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_delete_row_not_found_raises_key_error(real_db):
    """delete_row raises KeyError when the row ID does not exist."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        with pytest.raises(KeyError):
            await db.delete_row(table_name, 9999)
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_note_appends_to_row_history(real_db):
    """note() should add a note action to the row's history column."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        row = await db.add_row(table_name, {"label": "annotated", "count": 1})
        await db.note(table_name, row["id"], "my note text")

        fetched = await db.get_row(table_name, row["id"])
        assert "history" in fetched
        history = fetched["history"]
        assert isinstance(history, list)
        assert len(history) == 1
        actions = history[0]["actions"]
        assert any(a["type"] == "note" and a["data"] == "my note text" for a in actions)
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_note_not_found_raises_key_error(real_db):
    """note() raises KeyError when the row ID does not exist."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        with pytest.raises(KeyError):
            await db.note(table_name, 9999, "ghost note")
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_rows_updates_all_provided_rows(real_db):
    """update_rows should update every row in the list and return the count."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        r1 = await db.add_row(table_name, {"label": "a", "count": 1})
        r2 = await db.add_row(table_name, {"label": "b", "count": 2})
        r3 = await db.add_row(table_name, {"label": "c", "count": 3})

        updated = await db.update_rows(
            table_name,
            [
                {"id": r1["id"], "label": "x"},
                {"id": r2["id"], "label": "y"},
                {"id": r3["id"], "label": "z"},
            ],
        )
        assert updated == 3

        assert (await db.get_row(table_name, r1["id"]))["label"] == "x"
        assert (await db.get_row(table_name, r2["id"]))["label"] == "y"
        assert (await db.get_row(table_name, r3["id"]))["label"] == "z"
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_rows_only_touches_specified_columns(real_db):
    """update_rows must not modify columns that are absent from the input dicts."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        r1 = await db.add_row(table_name, {"label": "keep", "count": 42})
        r2 = await db.add_row(table_name, {"label": "keep2", "count": 99})

        await db.update_rows(
            table_name,
            [
                {"id": r1["id"], "label": "changed"},
                {"id": r2["id"], "label": "changed2"},
            ],
        )

        f1 = await db.get_row(table_name, r1["id"])
        f2 = await db.get_row(table_name, r2["id"])
        assert f1["count"] == 42
        assert f2["count"] == 99
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_rows_empty_list_is_no_op(real_db):
    """update_rows with an empty list should return 0 and leave the table unchanged."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        r = await db.add_row(table_name, {"label": "stable", "count": 7})
        result = await db.update_rows(table_name, [])
        assert result == 0

        fetched = await db.get_row(table_name, r["id"])
        assert fetched["label"] == "stable"
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_rows_unknown_columns_silently_ignored(real_db):
    """update_rows should silently drop keys not present as table columns."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        r = await db.add_row(table_name, {"label": "original", "count": 5})
        result = await db.update_rows(table_name, [{"id": r["id"], "nonexistent": "x"}])
        assert result == 0

        fetched = await db.get_row(table_name, r["id"])
        assert fetched["label"] == "original"
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_rows_missing_id_raises_value_error(real_db):
    """update_rows raises ValueError when a dict is missing the 'id' key."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        with pytest.raises(ValueError, match="id"):
            await db.update_rows(table_name, [{"label": "no-id"}])
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_rows_mismatched_columns_raises_value_error(real_db):
    """update_rows raises ValueError when dicts have different column sets."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        r1 = await db.add_row(table_name, {"label": "a", "count": 1})
        r2 = await db.add_row(table_name, {"label": "b", "count": 2})

        with pytest.raises(ValueError, match="same set of columns"):
            await db.update_rows(
                table_name,
                [
                    {"id": r1["id"], "label": "x"},
                    {"id": r2["id"], "count": 9},
                ],
            )
    finally:
        await _drop_test_table(real_db, dt)


@pytest.mark.db
async def test_update_rows_nonexistent_ids_are_skipped(real_db):
    """update_rows should not raise for non-existent IDs; count reflects actual updates."""
    table_name = _unique_table()
    dt = await _create_test_table(real_db, table_name)
    db = DbStore()

    try:
        r = await db.add_row(table_name, {"label": "real", "count": 1})
        updated = await db.update_rows(
            table_name,
            [
                {"id": r["id"], "label": "updated"},
                {"id": 99999, "label": "ghost"},
            ],
        )
        assert updated == 1
        assert (await db.get_row(table_name, r["id"]))["label"] == "updated"
    finally:
        await _drop_test_table(real_db, dt)
