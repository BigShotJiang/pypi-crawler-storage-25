"""Integration tests for ServerRestartLogic — real DB outcomes.

Covers all three modes (rerun, mock_on_side_effect, skip) at both node and
workflow level, recursive sub-workflow resume, _force_fresh cascade, and the
kitchen-sink nested tree scenario.

Marked ``db`` — runs against a real PostgreSQL instance.
"""

from __future__ import annotations

import dataclasses
import uuid
from datetime import datetime, timezone
from typing import Any

import pytest
from sqlalchemy import delete as _sa_delete, update as _sa_update
from sqlmodel import select

from ankor.decorator._drain import _resume_existing_run
from ankor.decorator.node import make_node_wrapper
from ankor.decorator.restart import ServerRestartLogic
from ankor.decorator.workflow import make_workflow_wrapper
from ankor.models import RunNode, TriggerType, Workflow, WorkflowRun, WorkflowStatus


def _unique_name(prefix: str = "test_wf") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def _run_data(inputs: dict | None = None) -> dict:
    return {"inputs": inputs or {}, "outputs": {}, "logs": [], "trigger_context": {}}


def _node_data(outputs: dict | None = None) -> dict:
    return {"inputs": {}, "outputs": outputs or {}}


@dataclasses.dataclass
class _Scenario:
    """Creates and tracks test rows; handles cleanup including dynamically-created child runs."""

    sl: Any
    _wf_ids: list[int] = dataclasses.field(default_factory=list)
    _run_ids: list[int] = dataclasses.field(default_factory=list)
    _extra_wf_names: list[str] = dataclasses.field(default_factory=list)

    async def create_workflow(self, name: str) -> Workflow:
        async with self.sl() as session:
            wf = Workflow(name=name)
            session.add(wf)
            await session.flush()
            await session.refresh(wf)
            self._wf_ids.append(wf.id)
            await session.commit()
        return wf

    async def create_run(
        self,
        workflow_id: int,
        *,
        status: WorkflowStatus = WorkflowStatus.running,
        inputs: dict | None = None,
        parent_id: int | None = None,
    ) -> WorkflowRun:
        async with self.sl() as session:
            run = WorkflowRun(
                workflow_id=workflow_id,
                status=status,
                triggered_by=TriggerType.manual,
                started_at=datetime.now(timezone.utc),
                parent_id=parent_id,
                data=_run_data(inputs),
            )
            session.add(run)
            await session.flush()
            await session.refresh(run)
            self._run_ids.append(run.id)
            await session.commit()
        return run

    async def create_node(
        self,
        run_id: int,
        *,
        name: str,
        status: WorkflowStatus,
        outputs: dict | None = None,
        parent_node_id: int | None = None,
        child_run_id: int | None = None,
    ) -> RunNode:
        async with self.sl() as session:
            node = RunNode(
                run_id=run_id,
                name=name,
                status=status,
                duration_ms=0,
                started_at=datetime.now(timezone.utc),
                parent_node_id=parent_node_id,
                child_run_id=child_run_id,
                data=_node_data(outputs),
            )
            session.add(node)
            await session.flush()
            await session.refresh(node)
            await session.commit()
        return node

    async def get_run(self, run_id: int) -> WorkflowRun:
        async with self.sl() as session:
            return await session.get(WorkflowRun, run_id)

    async def get_nodes(self, run_id: int) -> list[RunNode]:
        async with self.sl() as session:
            rows = (
                await session.exec(
                    select(RunNode).where(RunNode.run_id == run_id).order_by(RunNode.id)
                )
            ).all()
            return list(rows)

    async def cleanup(self) -> None:
        async with self.sl() as session:
            if self._extra_wf_names:
                extra_wfs = list(
                    (
                        await session.exec(
                            select(Workflow).where(
                                Workflow.name.in_(self._extra_wf_names)
                            )
                        )
                    ).all()
                )
                extra_wf_ids = [w.id for w in extra_wfs]
                if extra_wf_ids:
                    await session.execute(
                        _sa_delete(WorkflowRun).where(
                            WorkflowRun.workflow_id.in_(extra_wf_ids)
                        )
                    )
                    await session.execute(
                        _sa_delete(Workflow).where(Workflow.id.in_(extra_wf_ids))
                    )

            if self._run_ids:
                await session.execute(
                    _sa_update(WorkflowRun)
                    .where(WorkflowRun.parent_id.in_(self._run_ids))
                    .values(parent_id=None)
                )
                await session.execute(
                    _sa_delete(WorkflowRun).where(WorkflowRun.id.in_(self._run_ids))
                )

            if self._wf_ids:
                await session.execute(
                    _sa_delete(Workflow).where(Workflow.id.in_(self._wf_ids))
                )

            await session.commit()


@pytest.mark.db
async def test_node_skip_mode_marks_success_and_continues(real_db):
    """A node with mode=skip should not execute its body; it should be marked success with empty outputs.

    The next node in the workflow should still run normally.
    """
    call_log: list[str] = []
    wf_name = _unique_name("node_skip")
    scenario = _Scenario(real_db)

    async def node_a(inputs: dict) -> dict:
        call_log.append("node_a")
        return {"a": "fresh"}

    async def node_b(inputs: dict) -> dict:
        call_log.append("node_b")
        return {"b": "done"}

    node_a_w = make_node_wrapper(
        node_a, server_restart_logic=ServerRestartLogic(mode="skip")
    )
    node_b_w = make_node_wrapper(node_b)

    async def workflow(inputs: dict) -> dict:
        out_a = await node_a_w(inputs)
        out_b = await node_b_w(inputs)
        return {**out_a, **out_b}

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        node_a_row = await scenario.create_node(
            run.id, name="node_a", status=WorkflowStatus.running
        )

        await _resume_existing_run(workflow, run.id, wf_name)

        assert "node_a" not in call_log, "node_a body must not execute in skip mode"
        assert "node_b" in call_log, "node_b should run normally"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success

        nodes = await scenario.get_nodes(run.id)
        by_name = {n.name: n for n in nodes}
        assert by_name["node_a"].id == node_a_row.id
        assert by_name["node_a"].status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_node_rerun_mode_reruns_node_body(real_db):
    """A node with mode=rerun should re-execute its body even though it was interrupted."""
    call_log: list[str] = []
    wf_name = _unique_name("node_rerun")
    scenario = _Scenario(real_db)

    async def node_a(inputs: dict) -> dict:
        call_log.append("node_a")
        return {"a": "recomputed"}

    node_a_w = make_node_wrapper(
        node_a, server_restart_logic=ServerRestartLogic(mode="rerun")
    )

    async def workflow(inputs: dict) -> dict:
        return await node_a_w(inputs)

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        await scenario.create_node(run.id, name="node_a", status=WorkflowStatus.running)

        await _resume_existing_run(workflow, run.id, wf_name)

        assert call_log == ["node_a"], "node_a must re-execute in rerun mode"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_node_rerun_mode_cascades_to_nested_nodes(real_db):
    """When a node has mode=rerun, nested nodes inside its body should also run fresh.

    Even if an inner node appears as success in the DB, _force_fresh bypasses the
    resume queue so the inner node executes again.
    """
    call_log: list[str] = []
    wf_name = _unique_name("cascade_rerun")
    scenario = _Scenario(real_db)

    async def inner_node(inputs: dict) -> dict:
        call_log.append("inner_node")
        return {"inner": "fresh"}

    async def outer_node(inputs: dict) -> dict:
        call_log.append("outer_node")
        result = await inner_node_w(inputs)
        return {**result, "outer": "done"}

    inner_node_w = make_node_wrapper(inner_node)
    outer_node_w = make_node_wrapper(
        outer_node, server_restart_logic=ServerRestartLogic(mode="rerun")
    )

    async def workflow(inputs: dict) -> dict:
        return await outer_node_w(inputs)

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        outer_row = await scenario.create_node(
            run.id, name="outer_node", status=WorkflowStatus.running
        )
        # inner_node appears as success in DB — but should still rerun due to cascade
        await scenario.create_node(
            run.id,
            name="inner_node",
            status=WorkflowStatus.success,
            parent_node_id=outer_row.id,
            outputs={"inner": "cached"},
        )

        await _resume_existing_run(workflow, run.id, wf_name)

        assert "outer_node" in call_log, "outer_node must rerun"
        assert (
            "inner_node" in call_log
        ), "inner_node must rerun due to _force_fresh cascade"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_node_mock_on_side_effect_check_returns_data(real_db):
    """When mode=mock_on_side_effect and check returns data, the node body should not run."""
    call_log: list[str] = []
    wf_name = _unique_name("mock_se_data")
    scenario = _Scenario(real_db)

    async def node_a(inputs: dict) -> dict:
        call_log.append("node_a")
        return {"a": "fresh"}

    async def check_fn(inputs: dict) -> dict | None:
        return {"a": "already_done"}

    node_a_w = make_node_wrapper(
        node_a,
        server_restart_logic=ServerRestartLogic(
            mode="mock_on_side_effect", side_effect_check=check_fn
        ),
    )

    async def workflow(inputs: dict) -> dict:
        return await node_a_w(inputs)

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        original_node = await scenario.create_node(
            run.id, name="node_a", status=WorkflowStatus.running
        )

        await _resume_existing_run(workflow, run.id, wf_name)

        assert call_log == [], "node body must not run when check confirms completion"

        nodes = await scenario.get_nodes(run.id)
        assert len(nodes) == 1
        assert nodes[0].id == original_node.id
        assert nodes[0].status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_node_mock_on_side_effect_check_returns_none_reruns(real_db):
    """When mode=mock_on_side_effect and check returns None, the node body should execute."""
    call_log: list[str] = []
    wf_name = _unique_name("mock_se_none")
    scenario = _Scenario(real_db)

    async def node_a(inputs: dict) -> dict:
        call_log.append("node_a")
        return {"a": "recomputed"}

    async def check_fn(inputs: dict) -> dict | None:
        return None

    node_a_w = make_node_wrapper(
        node_a,
        server_restart_logic=ServerRestartLogic(
            mode="mock_on_side_effect", side_effect_check=check_fn
        ),
    )

    async def workflow(inputs: dict) -> dict:
        return await node_a_w(inputs)

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        await scenario.create_node(run.id, name="node_a", status=WorkflowStatus.running)

        await _resume_existing_run(workflow, run.id, wf_name)

        assert call_log == ["node_a"], "node must rerun when check returns None"
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_workflow_skip_mode_cancels_run(real_db):
    """A workflow with mode=skip should be set to cancelled without executing the function."""
    called = False
    wf_name = _unique_name("wf_skip")
    scenario = _Scenario(real_db)

    async def workflow(inputs: dict) -> dict:
        nonlocal called
        called = True
        return {}

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)

        await _resume_existing_run(
            workflow, run.id, wf_name, ServerRestartLogic(mode="skip")
        )

        assert not called, "workflow body must not execute in skip mode"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.cancelled
        assert final_run.finished_at is not None
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_workflow_rerun_mode_ignores_prior_nodes(real_db):
    """A workflow with mode=rerun should re-execute all nodes regardless of their DB state."""
    call_log: list[str] = []
    wf_name = _unique_name("wf_rerun")
    scenario = _Scenario(real_db)

    async def node_a(inputs: dict) -> dict:
        call_log.append("node_a")
        return {"a": "fresh"}

    async def node_b(inputs: dict) -> dict:
        call_log.append("node_b")
        return {"b": "fresh"}

    node_a_w = make_node_wrapper(node_a)
    node_b_w = make_node_wrapper(node_b)

    async def workflow(inputs: dict) -> dict:
        out_a = await node_a_w(inputs)
        out_b = await node_b_w(inputs)
        return {**out_a, **out_b}

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        # node_a was success, node_b was running — in normal resume node_a would be skipped
        await scenario.create_node(
            run.id,
            name="node_a",
            status=WorkflowStatus.success,
            outputs={"a": "cached"},
        )
        await scenario.create_node(run.id, name="node_b", status=WorkflowStatus.running)

        await _resume_existing_run(
            workflow, run.id, wf_name, ServerRestartLogic(mode="rerun")
        )

        assert "node_a" in call_log, "node_a should rerun — prior success ignored"
        assert "node_b" in call_log, "node_b should rerun"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_workflow_mock_on_side_effect_check_returns_data(real_db):
    """When workflow mode=mock_on_side_effect and check returns data, the workflow body should not run."""
    called = False
    wf_name = _unique_name("wf_mock_data")
    scenario = _Scenario(real_db)

    async def check_fn(inputs: dict) -> dict | None:
        return {"result": "already_done"}

    async def workflow(inputs: dict) -> dict:
        nonlocal called
        called = True
        return {}

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)

        await _resume_existing_run(
            workflow,
            run.id,
            wf_name,
            ServerRestartLogic(mode="mock_on_side_effect", side_effect_check=check_fn),
        )

        assert (
            not called
        ), "workflow body must not execute when check confirms completion"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success
        assert (final_run.data or {}).get("outputs") == {"result": "already_done"}
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_workflow_mock_on_side_effect_check_returns_none_resumes(real_db):
    """When workflow mode=mock_on_side_effect and check returns None, normal resume should proceed."""
    call_log: list[str] = []
    wf_name = _unique_name("wf_mock_none")
    scenario = _Scenario(real_db)

    async def check_fn(inputs: dict) -> dict | None:
        return None

    async def node_a(inputs: dict) -> dict:
        call_log.append("node_a")
        return {"a": "done"}

    node_a_w = make_node_wrapper(node_a)

    async def workflow(inputs: dict) -> dict:
        return await node_a_w(inputs)

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        await scenario.create_node(run.id, name="node_a", status=WorkflowStatus.running)

        await _resume_existing_run(
            workflow,
            run.id,
            wf_name,
            ServerRestartLogic(mode="mock_on_side_effect", side_effect_check=check_fn),
        )

        assert (
            "node_a" in call_log
        ), "workflow should resume normally when check returns None"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_workflow_rerun_cancels_orphaned_child_runs(real_db):
    """When workflow mode=rerun, any child runs still in running state should be cancelled."""
    wf_name = _unique_name("wf_rerun_child")
    child_wf_name = _unique_name("child_wf")
    scenario = _Scenario(real_db)

    async def workflow(inputs: dict) -> dict:
        return {}

    try:
        wf = await scenario.create_workflow(wf_name)
        child_wf = await scenario.create_workflow(child_wf_name)
        run = await scenario.create_run(wf.id)
        child_run = await scenario.create_run(
            child_wf.id, status=WorkflowStatus.running, parent_id=run.id
        )

        await _resume_existing_run(
            workflow, run.id, wf_name, ServerRestartLogic(mode="rerun")
        )

        final_child = await scenario.get_run(child_run.id)
        assert (
            final_child.status == WorkflowStatus.cancelled
        ), "orphaned child run should be cancelled on parent rerun"
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_sub_workflow_success_skipped_and_outputs_returned(real_db):
    """A sub-workflow that succeeded before the crash should be skipped during parent resume.

    Its stored outputs should be returned to the parent function as-is.
    """
    call_log: list[str] = []
    parent_wf_name = _unique_name("parent_sw_skip")
    sub_wf_name = _unique_name("sub_wf_success")
    scenario = _Scenario(real_db)

    async def sub_wf_raw(inputs: dict) -> dict:
        call_log.append("sub_wf")
        return {"result": "fresh"}

    sub_wf_wrapped = make_workflow_wrapper(sub_wf_raw)
    wrappers = {sub_wf_name: sub_wf_wrapped}

    received_from_sub: dict = {}

    async def parent_raw(inputs: dict) -> dict:
        nonlocal received_from_sub
        received_from_sub = await sub_wf_wrapped(inputs)
        return received_from_sub

    try:
        parent_wf = await scenario.create_workflow(parent_wf_name)
        sub_wf = await scenario.create_workflow(sub_wf_name)
        parent_run = await scenario.create_run(parent_wf.id)
        sub_run = await scenario.create_run(
            sub_wf.id, status=WorkflowStatus.success, parent_id=parent_run.id
        )
        # The RunNode in the parent representing the sub-workflow call
        await scenario.create_node(
            parent_run.id,
            name=sub_wf_raw.__name__,
            status=WorkflowStatus.success,
            outputs={"result": "cached"},
            child_run_id=sub_run.id,
        )

        await _resume_existing_run(
            parent_raw, parent_run.id, parent_wf_name, wrappers=wrappers
        )

        assert call_log == [], "sub_wf body must not run when it already succeeded"
        assert received_from_sub == {
            "result": "cached"
        }, "parent should receive the cached outputs from the sub-workflow"

        final_run = await scenario.get_run(parent_run.id)
        assert final_run.status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_sub_workflow_running_recursively_resumed(real_db):
    """A sub-workflow that was running when the crash happened should be recursively resumed.

    Nodes that had already completed inside the sub-workflow should be skipped;
    nodes that were interrupted or never started should execute.
    """
    call_log: list[str] = []
    parent_wf_name = _unique_name("parent_sw_resume")
    sub_wf_name = _unique_name("sub_wf_running")
    scenario = _Scenario(real_db)

    async def node_done(inputs: dict) -> dict:
        call_log.append("node_done")
        return {"done": "value"}

    async def node_interrupted(inputs: dict) -> dict:
        call_log.append("node_interrupted")
        return {"interrupted": "recomputed"}

    async def node_fresh(inputs: dict) -> dict:
        call_log.append("node_fresh")
        return {"fresh": "value"}

    node_done_w = make_node_wrapper(node_done)
    node_interrupted_w = make_node_wrapper(node_interrupted)
    node_fresh_w = make_node_wrapper(node_fresh)

    async def sub_wf_raw(inputs: dict) -> dict:
        r1 = await node_done_w(inputs)
        r2 = await node_interrupted_w(inputs)
        r3 = await node_fresh_w(inputs)
        return {**r1, **r2, **r3}

    sub_wf_wrapped = make_workflow_wrapper(sub_wf_raw)
    wrappers = {sub_wf_raw.__name__: sub_wf_wrapped}

    async def parent_raw(inputs: dict) -> dict:
        return await sub_wf_wrapped(inputs)

    try:
        parent_wf = await scenario.create_workflow(parent_wf_name)
        sub_wf = await scenario.create_workflow(sub_wf_name)
        parent_run = await scenario.create_run(parent_wf.id)
        sub_run = await scenario.create_run(
            sub_wf.id, status=WorkflowStatus.running, parent_id=parent_run.id
        )
        sub_node_in_parent = await scenario.create_node(
            parent_run.id,
            name=sub_wf_raw.__name__,
            status=WorkflowStatus.running,
            child_run_id=sub_run.id,
        )
        # Inside sub_run: node_done succeeded, node_interrupted was mid-run
        await scenario.create_node(
            sub_run.id,
            name="node_done",
            status=WorkflowStatus.success,
            outputs={"done": "value"},
        )
        await scenario.create_node(
            sub_run.id, name="node_interrupted", status=WorkflowStatus.running
        )

        await _resume_existing_run(
            parent_raw, parent_run.id, parent_wf_name, wrappers=wrappers
        )

        assert (
            "node_done" not in call_log
        ), "node_done already succeeded — must be skipped"
        assert (
            "node_interrupted" in call_log
        ), "node_interrupted was running — must rerun"
        assert "node_fresh" in call_log, "node_fresh never ran — must run fresh"

        final_parent = await scenario.get_run(parent_run.id)
        assert final_parent.status == WorkflowStatus.success

        final_sub = await scenario.get_run(sub_run.id)
        assert final_sub.status == WorkflowStatus.success

        parent_nodes = await scenario.get_nodes(parent_run.id)
        sub_node_updated = next(
            n for n in parent_nodes if n.id == sub_node_in_parent.id
        )
        assert sub_node_updated.status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_kitchen_sink_nested_resume(real_db):
    """Full nested tree: success sub-workflow skipped, running sub-workflow recursively resumed.

    Tree state at crash:
        parent_workflow (running)
          sub_wf_a (success)        <- skipped, stored outputs returned
            node_1 (success)
            node_2 (success)
          sub_wf_b (running)        <- recursively resumed
            node_3 (success)        <- skipped
            node_a (running)        <- rerun
            node_b, node_c (not in DB) <- run fresh
          sub_wf_c (not in DB)      <- runs fresh
          sub_wf_d (not in DB)      <- runs fresh

    After resume the parent run and all sub-runs should be success.
    """
    call_log: list[str] = []
    parent_wf_name = _unique_name("ks_parent")
    sub_a_wf_name = _unique_name("ks_sub_a")
    sub_b_wf_name = _unique_name("ks_sub_b")
    sub_c_raw_name = f"ks_sub_c_{uuid.uuid4().hex[:8]}"
    sub_d_raw_name = f"ks_sub_d_{uuid.uuid4().hex[:8]}"
    scenario = _Scenario(real_db)
    scenario._extra_wf_names = [sub_c_raw_name, sub_d_raw_name]

    async def node_1(inputs: dict) -> dict:
        return {"n1": "stored"}

    async def node_2(inputs: dict) -> dict:
        return {"n2": "stored"}

    async def node_3(inputs: dict) -> dict:
        return {"n3": "stored"}

    async def node_a(inputs: dict) -> dict:
        call_log.append("node_a")
        return {"na": "fresh"}

    async def node_b(inputs: dict) -> dict:
        call_log.append("node_b")
        return {"nb": "fresh"}

    async def node_c(inputs: dict) -> dict:
        call_log.append("node_c")
        return {"nc": "fresh"}

    node_1_w = make_node_wrapper(node_1)
    node_2_w = make_node_wrapper(node_2)
    node_3_w = make_node_wrapper(node_3)
    node_a_w = make_node_wrapper(node_a)
    node_b_w = make_node_wrapper(node_b)
    node_c_w = make_node_wrapper(node_c)

    async def sub_wf_a_raw(inputs: dict) -> dict:
        r1 = await node_1_w(inputs)
        r2 = await node_2_w(inputs)
        return {**r1, **r2}

    async def sub_wf_b_raw(inputs: dict) -> dict:
        r3 = await node_3_w(inputs)
        ra = await node_a_w(inputs)
        rb = await node_b_w(inputs)
        rc = await node_c_w(inputs)
        return {**r3, **ra, **rb, **rc}

    # sub_c and sub_d are named to match scenario._extra_wf_names for cleanup
    async def sub_wf_c_fn(inputs: dict) -> dict:
        call_log.append("sub_wf_c")
        return {"swc": "fresh"}

    async def sub_wf_d_fn(inputs: dict) -> dict:
        call_log.append("sub_wf_d")
        return {"swd": "fresh"}

    # Rename the functions to match what _try_resume_sub_workflow uses (fn.__name__)
    sub_wf_c_fn.__name__ = sub_c_raw_name
    sub_wf_c_fn.__qualname__ = sub_c_raw_name
    sub_wf_d_fn.__name__ = sub_d_raw_name
    sub_wf_d_fn.__qualname__ = sub_d_raw_name

    sub_wf_a_wrapped = make_workflow_wrapper(sub_wf_a_raw)
    sub_wf_b_wrapped = make_workflow_wrapper(sub_wf_b_raw)
    sub_wf_c_wrapped = make_workflow_wrapper(sub_wf_c_fn)
    sub_wf_d_wrapped = make_workflow_wrapper(sub_wf_d_fn)

    wrappers = {
        sub_wf_a_raw.__name__: sub_wf_a_wrapped,
        sub_wf_b_raw.__name__: sub_wf_b_wrapped,
        sub_c_raw_name: sub_wf_c_wrapped,
        sub_d_raw_name: sub_wf_d_wrapped,
    }

    async def parent_raw(inputs: dict) -> dict:
        ra = await sub_wf_a_wrapped(inputs)
        rb = await sub_wf_b_wrapped(inputs)
        rc = await sub_wf_c_wrapped(inputs)
        rd = await sub_wf_d_wrapped(inputs)
        return {**ra, **rb, **rc, **rd}

    try:
        parent_wf = await scenario.create_workflow(parent_wf_name)
        sub_a_wf = await scenario.create_workflow(sub_a_wf_name)
        sub_b_wf = await scenario.create_workflow(sub_b_wf_name)

        parent_run = await scenario.create_run(parent_wf.id)

        sub_a_run = await scenario.create_run(
            sub_a_wf.id, status=WorkflowStatus.success, parent_id=parent_run.id
        )
        await scenario.create_node(
            parent_run.id,
            name=sub_wf_a_raw.__name__,
            status=WorkflowStatus.success,
            outputs={"n1": "stored", "n2": "stored"},
            child_run_id=sub_a_run.id,
        )
        await scenario.create_node(
            sub_a_run.id,
            name="node_1",
            status=WorkflowStatus.success,
            outputs={"n1": "stored"},
        )
        await scenario.create_node(
            sub_a_run.id,
            name="node_2",
            status=WorkflowStatus.success,
            outputs={"n2": "stored"},
        )

        sub_b_run = await scenario.create_run(
            sub_b_wf.id, status=WorkflowStatus.running, parent_id=parent_run.id
        )
        await scenario.create_node(
            parent_run.id,
            name=sub_wf_b_raw.__name__,
            status=WorkflowStatus.running,
            child_run_id=sub_b_run.id,
        )
        await scenario.create_node(
            sub_b_run.id,
            name="node_3",
            status=WorkflowStatus.success,
            outputs={"n3": "stored"},
        )
        await scenario.create_node(
            sub_b_run.id, name="node_a", status=WorkflowStatus.running
        )

        await _resume_existing_run(
            parent_raw, parent_run.id, parent_wf_name, wrappers=wrappers
        )

        assert "node_a" in call_log, "node_a was interrupted — should rerun"
        assert "node_b" in call_log, "node_b never ran — should run fresh"
        assert "node_c" in call_log, "node_c never ran — should run fresh"
        assert "sub_wf_c" in call_log, "sub_wf_c never ran — should run fresh"
        assert "sub_wf_d" in call_log, "sub_wf_d never ran — should run fresh"

        assert "node_3" not in call_log, "node_3 already succeeded — should be skipped"
        assert (
            call_log.count("node_1") == 0
        ), "sub_wf_a was success — node_1 must not rerun"
        assert (
            call_log.count("node_2") == 0
        ), "sub_wf_a was success — node_2 must not rerun"

        final_parent = await scenario.get_run(parent_run.id)
        assert final_parent.status == WorkflowStatus.success

        final_sub_b = await scenario.get_run(sub_b_run.id)
        assert final_sub_b.status == WorkflowStatus.success

    finally:
        await scenario.cleanup()
