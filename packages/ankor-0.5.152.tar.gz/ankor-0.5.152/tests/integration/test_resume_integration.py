"""Integration tests for server-crash resume — real DB outcomes.

Exercises _resume_existing_run end-to-end against a live PostgreSQL database
so that the full chain (load nodes → skip/rerun logic → DB writes → final state)
is verified.  Each test owns its data and cleans up on teardown.

Complement to test_restart_resume.py which tests node-wrapper logic in isolation
(no DB) and test_startup_recovery.py which tests the startup routing layer
(mock session, interaction-only).

Marked ``db`` — run sequentially against a real PostgreSQL instance.
The ``real_db`` fixture (conftest.py) truncates workflow tables once at session
start to eliminate interference from dev/seed data.
"""

from __future__ import annotations

import dataclasses
import uuid
from datetime import datetime, timezone
from typing import Any

import pytest

from ankor.decorator._drain import _resume_existing_run
from ankor.decorator.node import make_node_wrapper
from ankor.models import RunNode, TriggerType, Workflow, WorkflowRun, WorkflowStatus
from sqlalchemy import delete as _sa_delete
from sqlmodel import select


def _unique_name(prefix: str = "test_wf") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def _run_data(inputs: dict | None = None) -> dict:
    return {
        "inputs": inputs or {},
        "outputs": {},
        "logs": [],
        "trigger_context": {},
    }


def _node_data(outputs: dict | None = None) -> dict:
    return {"inputs": {}, "outputs": outputs or {}}


@dataclasses.dataclass
class _Scenario:
    """Creates and tracks test rows; cleans up on teardown."""

    sl: Any
    _wf_ids: list[int] = dataclasses.field(default_factory=list)
    _run_ids: list[int] = dataclasses.field(default_factory=list)

    async def create_workflow(self, name: str) -> Workflow:
        async with self.sl() as session:
            wf = Workflow(name=name)
            session.add(wf)
            await session.flush()
            await session.refresh(wf)
            self._wf_ids.append(wf.id)
            await session.commit()
        return wf

    async def create_run(
        self,
        workflow_id: int,
        *,
        status: WorkflowStatus = WorkflowStatus.running,
        inputs: dict | None = None,
    ) -> WorkflowRun:
        async with self.sl() as session:
            run = WorkflowRun(
                workflow_id=workflow_id,
                status=status,
                triggered_by=TriggerType.manual,
                started_at=datetime.now(timezone.utc),
                data=_run_data(inputs),
            )
            session.add(run)
            await session.flush()
            await session.refresh(run)
            self._run_ids.append(run.id)
            await session.commit()
        return run

    async def create_node(
        self,
        run_id: int,
        *,
        name: str,
        status: WorkflowStatus,
        outputs: dict | None = None,
        parent_node_id: int | None = None,
    ) -> RunNode:
        async with self.sl() as session:
            node = RunNode(
                run_id=run_id,
                name=name,
                status=status,
                duration_ms=0,
                started_at=datetime.now(timezone.utc),
                parent_node_id=parent_node_id,
                data=_node_data(outputs),
            )
            session.add(node)
            await session.flush()
            await session.refresh(node)
            await session.commit()
        return node

    async def get_run(self, run_id: int) -> WorkflowRun:
        async with self.sl() as session:
            run = await session.get(WorkflowRun, run_id)
            return run

    async def get_nodes(self, run_id: int) -> list[RunNode]:
        async with self.sl() as session:
            rows = (
                await session.exec(
                    select(RunNode).where(RunNode.run_id == run_id).order_by(RunNode.id)
                )
            ).all()
            return list(rows)

    async def cleanup(self) -> None:
        # Runs must be deleted before workflows (FK: workflow_runs.workflow_id).
        # RunNode rows are removed automatically via ON DELETE CASCADE from WorkflowRun.
        async with self.sl() as session:
            if self._run_ids:
                await session.execute(
                    _sa_delete(WorkflowRun).where(WorkflowRun.id.in_(self._run_ids))
                )
            if self._wf_ids:
                await session.execute(
                    _sa_delete(Workflow).where(Workflow.id.in_(self._wf_ids))
                )
            await session.commit()


@pytest.mark.db
async def test_success_nodes_skipped_on_resume(real_db):
    """A node that already succeeded before the crash should not run again on resume."""
    executed = []
    wf_name = _unique_name()
    scenario = _Scenario(real_db)

    async def node_fn(inputs: dict) -> dict:
        executed.append("ran")
        return {"value": "fresh"}

    node = make_node_wrapper(node_fn)

    async def workflow(inputs: dict) -> dict:
        return await node(inputs)

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        original_node = await scenario.create_node(
            run.id,
            name="node_fn",
            status=WorkflowStatus.success,
            outputs={"value": "cached"},
        )

        await _resume_existing_run(workflow, run.id, wf_name)

        assert executed == [], "node body must not run when already succeeded"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success
        assert final_run.finished_at is not None

        nodes = await scenario.get_nodes(run.id)
        assert len(nodes) == 1, "no new RunNode rows should be inserted"
        assert nodes[0].id == original_node.id
        assert nodes[0].status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_interrupted_node_rerun_on_resume(real_db):
    """A node that was mid-execution when the server crashed should be re-executed on resume.

    The existing RunNode row should be updated in place from running to success — no new row should be inserted.
    """
    executed = []
    wf_name = _unique_name()
    scenario = _Scenario(real_db)

    async def node_fn(inputs: dict) -> dict:
        executed.append("ran")
        return {"value": "recomputed"}

    node = make_node_wrapper(node_fn)

    async def workflow(inputs: dict) -> dict:
        return await node(inputs)

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        original_node = await scenario.create_node(
            run.id,
            name="node_fn",
            status=WorkflowStatus.running,
        )

        await _resume_existing_run(workflow, run.id, wf_name)

        assert executed == ["ran"], "interrupted node must be re-executed"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success
        assert final_run.finished_at is not None

        nodes = await scenario.get_nodes(run.id)
        assert len(nodes) == 1, "interrupted node reuses existing row — no duplicates"
        assert nodes[0].id == original_node.id
        assert nodes[0].status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_failure_check_marks_node_done_without_rerun(real_db):
    """When restart_on_failure_check returns data, the node body should not run again.

    The existing RunNode row should be marked as success using the check's return value.
    """
    executed = []
    wf_name = _unique_name()
    scenario = _Scenario(real_db)

    async def node_fn(inputs: dict) -> dict:
        executed.append("ran")
        return {"value": "fresh"}

    async def check_fn(inputs: dict) -> dict | None:
        return {"value": "already_done"}

    node = make_node_wrapper(node_fn, restart_on_failure_check=check_fn)

    async def workflow(inputs: dict) -> dict:
        return await node(inputs)

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        original_node = await scenario.create_node(
            run.id,
            name="node_fn",
            status=WorkflowStatus.running,
        )

        await _resume_existing_run(workflow, run.id, wf_name)

        assert executed == [], "node body must not run when check confirms completion"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success

        nodes = await scenario.get_nodes(run.id)
        assert len(nodes) == 1
        assert nodes[0].id == original_node.id
        assert nodes[0].status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_failure_check_returning_none_causes_rerun(real_db):
    """When restart_on_failure_check returns None, the node body should be called again normally."""
    executed = []
    wf_name = _unique_name()
    scenario = _Scenario(real_db)

    async def node_fn(inputs: dict) -> dict:
        executed.append("ran")
        return {"value": "recomputed"}

    async def check_fn(inputs: dict) -> dict | None:
        return None  # side effect didn't complete — must re-run

    node = make_node_wrapper(node_fn, restart_on_failure_check=check_fn)

    async def workflow(inputs: dict) -> dict:
        return await node(inputs)

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        original_node = await scenario.create_node(
            run.id,
            name="node_fn",
            status=WorkflowStatus.running,
        )

        await _resume_existing_run(workflow, run.id, wf_name)

        assert executed == ["ran"], "node must re-run when check returns None"

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success
        assert final_run.finished_at is not None

        nodes = await scenario.get_nodes(run.id)
        assert len(nodes) == 1
        assert nodes[0].id == original_node.id
        assert nodes[0].status == WorkflowStatus.success
    finally:
        await scenario.cleanup()


@pytest.mark.db
async def test_mixed_resume_scenario(real_db):
    """A three-step workflow should resume correctly after a mid-run crash.

    step_a had already succeeded before the crash — should not run again.
    step_b was in flight when the crash happened — should be re-executed.
    step_c had not started yet — should execute normally.

    After resume, all three nodes and the run should be in a success state.
    """
    call_log: list[str] = []
    wf_name = _unique_name()
    scenario = _Scenario(real_db)

    async def step_a(inputs: dict) -> dict:
        call_log.append("step_a")
        return {"a": "fresh"}

    async def step_b(inputs: dict) -> dict:
        call_log.append("step_b")
        return {"b": "computed"}

    async def step_c(inputs: dict) -> dict:
        call_log.append("step_c")
        return {"c": "new"}

    node_a = make_node_wrapper(step_a)
    node_b = make_node_wrapper(step_b)
    node_c = make_node_wrapper(step_c)

    async def workflow(inputs: dict) -> dict:
        out_a = await node_a(inputs)
        out_b = await node_b(inputs)
        out_c = await node_c(inputs)
        return {**out_a, **out_b, **out_c}

    try:
        wf = await scenario.create_workflow(wf_name)
        run = await scenario.create_run(wf.id)
        node_a_row = await scenario.create_node(
            run.id,
            name="step_a",
            status=WorkflowStatus.success,
            outputs={"a": "cached"},
        )
        node_b_row = await scenario.create_node(
            run.id,
            name="step_b",
            status=WorkflowStatus.running,
        )

        await _resume_existing_run(workflow, run.id, wf_name)

        # step_a was already done — must not re-execute
        assert "step_a" not in call_log
        # step_b was interrupted — must re-execute
        assert "step_b" in call_log
        # step_c is new — must execute normally
        assert "step_c" in call_log

        final_run = await scenario.get_run(run.id)
        assert final_run.status == WorkflowStatus.success
        assert final_run.finished_at is not None

        nodes = await scenario.get_nodes(run.id)
        assert len(nodes) == 3

        by_name = {n.name: n for n in nodes}
        assert by_name["step_a"].id == node_a_row.id
        assert by_name["step_a"].status == WorkflowStatus.success
        assert by_name["step_b"].id == node_b_row.id
        assert by_name["step_b"].status == WorkflowStatus.success
        assert by_name["step_c"].status == WorkflowStatus.success
    finally:
        await scenario.cleanup()
