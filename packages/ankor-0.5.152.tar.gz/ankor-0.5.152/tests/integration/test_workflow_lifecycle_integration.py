"""Integration tests for make_workflow_wrapper — full workflow run lifecycle.

Verifies end-to-end DB outcomes: WorkflowRun rows created, status transitions,
RunNode rows inserted, and concurrency enforcement.

Marked ``db`` — run sequentially against a real PostgreSQL instance.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from unittest.mock import patch

import pytest
from sqlalchemy import delete as _sa_delete
from sqlmodel import select

from ankor.decorator._context import _running_tasks
from ankor.decorator._drain import (
    _drain_events,
    _drain_loop,
    _execute_existing_run,
    _get_drain_event,
)
from ankor.decorator.node import make_node_wrapper
from ankor.decorator.workflow import make_workflow_wrapper
from ankor.models import RunNode, TriggerType, Workflow, WorkflowRun, WorkflowStatus


def _unique_name(prefix: str = "wf") -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


async def _cleanup_workflow(real_db, wf_name: str) -> None:
    """Delete the Workflow row and its WorkflowRun rows (RunNode rows cascade automatically)."""
    async with real_db() as session:
        wf = (
            await session.exec(select(Workflow).where(Workflow.name == wf_name))
        ).first()
        if wf:
            # Runs must be deleted before the workflow (no DB-level CASCADE on workflow_id FK).
            await session.execute(
                _sa_delete(WorkflowRun).where(WorkflowRun.workflow_id == wf.id)
            )
            await session.execute(_sa_delete(Workflow).where(Workflow.id == wf.id))
            await session.commit()


@pytest.mark.db
async def test_simple_run_succeeds(real_db):
    """make_workflow_wrapper should create a WorkflowRun, execute the fn, and mark it success."""
    wf_name = _unique_name()
    called = []

    async def fn(inputs: dict) -> dict:
        called.append(inputs)
        return {"result": "ok"}

    fn.__name__ = wf_name

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):
            output = await make_workflow_wrapper(fn)({"x": 1})

        assert output == {"result": "ok"}
        assert len(called) == 1

        async with real_db() as session:
            wf = (
                await session.exec(select(Workflow).where(Workflow.name == wf_name))
            ).first()
            assert wf is not None
            runs = list(
                (
                    await session.exec(
                        select(WorkflowRun).where(WorkflowRun.workflow_id == wf.id)
                    )
                ).all()
            )
            assert len(runs) == 1
            run = runs[0]
            assert run.status == WorkflowStatus.success
            assert run.finished_at is not None
            assert run.data["inputs"] == {"x": 1}
            assert run.data["outputs"] == {"result": "ok"}
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_run_with_node_creates_run_node_row(real_db):
    """A node inside the workflow should create a RunNode row with status=success."""
    wf_name = _unique_name()

    async def compute(inputs: dict) -> dict:
        return {"computed": True}

    node = make_node_wrapper(compute)

    async def fn(inputs: dict) -> dict:
        return await node(inputs)

    fn.__name__ = wf_name

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):
            await make_workflow_wrapper(fn)({})

        async with real_db() as session:
            wf = (
                await session.exec(select(Workflow).where(Workflow.name == wf_name))
            ).first()
            runs = list(
                (
                    await session.exec(
                        select(WorkflowRun).where(WorkflowRun.workflow_id == wf.id)
                    )
                ).all()
            )
            assert len(runs) == 1
            nodes = list(
                (
                    await session.exec(
                        select(RunNode).where(RunNode.run_id == runs[0].id)
                    )
                ).all()
            )
            assert len(nodes) == 1
            assert nodes[0].name == "compute"
            assert nodes[0].status == WorkflowStatus.success
            assert nodes[0].data["outputs"] == {"computed": True}
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_failed_run_sets_failed_status(real_db):
    """When the workflow fn raises, WorkflowRun.status should be set to failed and finished_at should be set."""
    wf_name = _unique_name()

    async def fn(inputs: dict) -> dict:
        raise ValueError("boom")

    fn.__name__ = wf_name

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):
            with pytest.raises(ValueError, match="boom"):
                await make_workflow_wrapper(fn)({})

        async with real_db() as session:
            wf = (
                await session.exec(select(Workflow).where(Workflow.name == wf_name))
            ).first()
            runs = list(
                (
                    await session.exec(
                        select(WorkflowRun).where(WorkflowRun.workflow_id == wf.id)
                    )
                ).all()
            )
            assert len(runs) == 1
            assert runs[0].status == WorkflowStatus.failed
            assert runs[0].finished_at is not None
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_max_concurrent_at_limit_queues_pending_run(real_db):
    """When at max_concurrent_runs limit, a pending WorkflowRun should be inserted in the DB."""
    wf_name = _unique_name()
    called = []

    async def fn(inputs: dict) -> dict:
        called.append("ran")
        return {}

    fn.__name__ = wf_name

    try:
        async with real_db() as session:
            wf = Workflow(name=wf_name, max_concurrent_runs=1)
            session.add(wf)
            await session.flush()
            await session.refresh(wf)
            # Occupy the one available slot with a running run.
            running = WorkflowRun(
                workflow_id=wf.id,
                status=WorkflowStatus.running,
                triggered_by=TriggerType.manual,
                started_at=datetime.now(timezone.utc),
                data={"inputs": {}, "outputs": {}, "trigger_context": {}},
            )
            session.add(running)
            await session.commit()
            await session.refresh(wf)
            wf_id = wf.id

        with patch("ankor.decorator.workflow._ensure_drain_task"):
            result = await make_workflow_wrapper(fn)({})

        assert result is None, "queued run must not execute immediately"
        assert called == [], "fn body must not run when at concurrency limit"

        async with real_db() as session:
            runs = list(
                (
                    await session.exec(
                        select(WorkflowRun).where(WorkflowRun.workflow_id == wf_id)
                    )
                ).all()
            )
            pending = [r for r in runs if r.status == WorkflowStatus.pending]
            assert len(pending) == 1, "exactly one pending run must be queued in DB"
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_max_concurrent_zero_skips_run_entirely(real_db):
    """max_concurrent_runs=0 disables the workflow — no WorkflowRun should be created."""
    wf_name = _unique_name()

    async def fn(inputs: dict) -> dict:
        return {}

    fn.__name__ = wf_name

    try:
        async with real_db() as session:
            wf = Workflow(name=wf_name, max_concurrent_runs=0)
            session.add(wf)
            await session.commit()
            await session.refresh(wf)
            wf_id = wf.id

        with patch("ankor.decorator.workflow._ensure_drain_task"):
            result = await make_workflow_wrapper(fn)({})

        assert result is None

        async with real_db() as session:
            runs = list(
                (
                    await session.exec(
                        select(WorkflowRun).where(WorkflowRun.workflow_id == wf_id)
                    )
                ).all()
            )
            assert (
                len(runs) == 0
            ), "no WorkflowRun should be created when max_concurrent_runs=0"
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_no_limit_in_config_always_runs(real_db):
    """Workflow config with max_concurrent_runs=None should run regardless of how many runs are active."""
    wf_name = _unique_name()
    called = []

    async def fn(inputs: dict) -> dict:
        called.append(inputs)
        return {"ok": True}

    fn.__name__ = wf_name

    try:
        async with real_db() as session:
            wf = Workflow(name=wf_name, max_concurrent_runs=None)
            session.add(wf)
            await session.flush()
            await session.refresh(wf)
            for _ in range(3):
                session.add(
                    WorkflowRun(
                        workflow_id=wf.id,
                        status=WorkflowStatus.running,
                        triggered_by=TriggerType.manual,
                        started_at=datetime.now(timezone.utc),
                        data={"inputs": {}, "outputs": {}, "trigger_context": {}},
                    )
                )
            await session.commit()

        with patch("ankor.decorator.workflow._ensure_drain_task"):
            output = await make_workflow_wrapper(fn)({})

        assert output == {"ok": True}
        assert len(called) == 1
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_execute_existing_run_transitions_pending_to_success(real_db):
    """_execute_existing_run should pick up a pending run, execute the fn, and mark it success."""
    wf_name = _unique_name()
    called_with = []

    async def fn(inputs: dict) -> dict:
        called_with.append(inputs)
        return {"done": True}

    fn.__name__ = wf_name

    try:
        async with real_db() as session:
            wf = Workflow(name=wf_name)
            session.add(wf)
            await session.flush()
            await session.refresh(wf)
            run = WorkflowRun(
                workflow_id=wf.id,
                status=WorkflowStatus.pending,
                triggered_by=TriggerType.manual,
                started_at=datetime.now(timezone.utc),
                data={"inputs": {"key": "val"}, "outputs": {}, "trigger_context": {}},
            )
            session.add(run)
            await session.flush()
            await session.refresh(run)
            run_id = run.id
            await session.commit()

        await _execute_existing_run(fn, run_id, wf_name)

        assert called_with == [{"key": "val"}]

        async with real_db() as session:
            final_run = await session.get(WorkflowRun, run_id)
        assert final_run.status == WorkflowStatus.success
        assert final_run.finished_at is not None
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_drain_loop_fills_all_free_slots(real_db):
    """The drain loop should launch all pending runs up to the concurrency limit simultaneously."""
    wf_name = _unique_name("drain")
    call_log: list[int] = []
    _drain_events.pop(wf_name, None)

    async def fn(inputs: dict) -> dict:
        call_log.append(inputs.get("i"))
        return {}

    fn.__name__ = wf_name

    try:
        async with real_db() as session:
            wf = Workflow(name=wf_name, max_concurrent_runs=4)
            session.add(wf)
            await session.flush()
            await session.refresh(wf)
            wf_id = wf.id

            # 1 already running → occupies 1 slot; 3 pending → all 3 should launch
            session.add(
                WorkflowRun(
                    workflow_id=wf.id,
                    status=WorkflowStatus.running,
                    triggered_by=TriggerType.manual,
                    started_at=datetime.now(timezone.utc),
                    data={"inputs": {}, "outputs": {}, "trigger_context": {}},
                )
            )
            for i in range(3):
                session.add(
                    WorkflowRun(
                        workflow_id=wf.id,
                        status=WorkflowStatus.pending,
                        triggered_by=TriggerType.manual,
                        started_at=datetime.now(timezone.utc),
                        data={"inputs": {"i": i}, "outputs": {}, "trigger_context": {}},
                    )
                )
            await session.commit()

        drain_task = asyncio.create_task(_drain_loop(wf_name, fn))
        _get_drain_event(wf_name).set()

        # Poll until the drain loop has created all 3 run tasks (DB queries take real time)
        run_tasks: set = set()
        for _ in range(200):
            await asyncio.sleep(0.01)
            run_tasks = {
                t
                for t in asyncio.all_tasks()
                if t.get_name().startswith(f"gtm_run_{wf_name}_")
            }
            if len(run_tasks) == 3:
                break

        if run_tasks:
            await asyncio.gather(*run_tasks, return_exceptions=True)

        drain_task.cancel()
        try:
            await drain_task
        except asyncio.CancelledError:
            pass

        _drain_events.pop(wf_name, None)

        async with real_db() as session:
            runs = list(
                (
                    await session.exec(
                        select(WorkflowRun).where(WorkflowRun.workflow_id == wf_id)
                    )
                ).all()
            )

        succeeded = [r for r in runs if r.status == WorkflowStatus.success]
        still_running = [r for r in runs if r.status == WorkflowStatus.running]

        assert (
            len(succeeded) == 3
        ), f"all 3 pending runs should have completed, got {len(succeeded)}"
        assert len(still_running) == 1, "pre-existing running run must stay unchanged"
        assert len(call_log) == 3
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_cancelled_run_decorator_skips_db_write(real_db):
    """When the inner fn task is cancelled, the decorator should not overwrite run status."""
    wf_name = _unique_name()

    async def slow_fn(inputs: dict) -> dict:
        await asyncio.sleep(9999)
        return {}

    slow_fn.__name__ = wf_name
    run_id: int | None = None

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):
            wrapper = make_workflow_wrapper(slow_fn)
            outer_task = asyncio.create_task(wrapper({}))

            # Poll until the run is committed to DB
            for _ in range(100):
                await asyncio.sleep(0.01)
                async with real_db() as session:
                    wf = (
                        await session.exec(
                            select(Workflow).where(Workflow.name == wf_name)
                        )
                    ).first()
                    if wf:
                        run = (
                            await session.exec(
                                select(WorkflowRun).where(
                                    WorkflowRun.workflow_id == wf.id
                                )
                            )
                        ).first()
                        if run:
                            run_id = run.id
                            break

            assert run_id is not None, "run was never created in DB"

            inner_task = _running_tasks.get(run_id)
            if inner_task:
                inner_task.cancel()

            try:
                await outer_task
            except (asyncio.CancelledError, Exception):
                pass

        async with real_db() as session:
            final_run = await session.get(WorkflowRun, run_id)
        assert final_run.status == WorkflowStatus.running
        assert final_run.finished_at is None
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_cancelled_run_removed_from_running_tasks(real_db):
    """After the fn task is cancelled, the run ID should be cleaned up from _running_tasks."""
    wf_name = _unique_name()

    async def slow_fn(inputs: dict) -> dict:
        await asyncio.sleep(9999)
        return {}

    slow_fn.__name__ = wf_name
    run_id: int | None = None

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):
            wrapper = make_workflow_wrapper(slow_fn)
            outer_task = asyncio.create_task(wrapper({}))

            # Poll until the task appears in _running_tasks
            for _ in range(100):
                await asyncio.sleep(0.01)
                if _running_tasks:
                    run_id = next(iter(_running_tasks))
                    break

            assert run_id is not None, "run never registered in _running_tasks"

            inner_task = _running_tasks.get(run_id)
            if inner_task:
                inner_task.cancel()

            try:
                await outer_task
            except (asyncio.CancelledError, Exception):
                pass

        assert run_id not in _running_tasks
    finally:
        await _cleanup_workflow(real_db, wf_name)


@pytest.mark.db
async def test_meta_preserved_in_db_outputs(real_db):
    """_meta must be kept in RunNode.data["outputs"] even when stripped from return value."""
    from ankor.decorator.node import make_node_wrapper

    wf_name = _unique_name("meta_db")

    async def my_node(inputs: dict) -> dict:
        return {"result": 42, "_meta": {"views": [{"key": "result", "type": "json"}]}}

    node = make_node_wrapper(my_node)

    async def fn(inputs: dict) -> dict:
        return await node(inputs)

    fn.__name__ = wf_name

    try:
        with patch("ankor.decorator.workflow._ensure_drain_task"):
            result = await make_workflow_wrapper(fn)({})

        # Caller does NOT see _meta
        assert "_meta" not in result

        # DB RunNode row DOES have _meta in outputs
        async with real_db() as session:
            wf = (
                await session.exec(select(Workflow).where(Workflow.name == wf_name))
            ).first()
            run = (
                await session.exec(
                    select(WorkflowRun).where(WorkflowRun.workflow_id == wf.id)
                )
            ).first()
            node_row = (
                await session.exec(select(RunNode).where(RunNode.run_id == run.id))
            ).first()
            assert node_row is not None
            outputs = (node_row.data or {}).get("outputs", {})
            assert "_meta" in outputs
            assert outputs["result"] == 42
    finally:
        await _cleanup_workflow(real_db, wf_name)
