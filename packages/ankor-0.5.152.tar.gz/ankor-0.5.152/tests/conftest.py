"""Shared pytest fixtures for api tests."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from dotenv import load_dotenv

# Require a dedicated test database configured in example/.env.test.
# This keeps integration tests isolated from dev data and allows truncating
# the entire schema safely.  Run  once to create the schema.
_env_test = Path(__file__).parent.parent / ".env.test"
if not _env_test.exists():
    raise FileNotFoundError(
        "example/.env.test not found. "
        "Create a dedicated test database and add example/.env.test with "
        "GTM_DB_URL pointing at it, then run: make migrate-test"
    )

# override=True so .env.test wins even if GTM_DB_URL is already set in the shell.
load_dotenv(_env_test, override=True)

import pytest  # noqa: E402
import pytest_asyncio  # noqa: E402
from fastapi import FastAPI  # noqa: E402
from sqlalchemy import text  # noqa: E402
from sqlalchemy.ext.asyncio import create_async_engine  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402
from sqlalchemy.pool import NullPool  # noqa: E402
from sqlmodel.ext.asyncio.session import AsyncSession  # noqa: E402

import ankor.database as _gtm_db  # noqa: E402
import ankor.decorator._drain as _gtm_dec_drain  # noqa: E402
import ankor.decorator._persistence as _gtm_dec_pers  # noqa: E402
import ankor.decorator.workflow as _gtm_dec_wf  # noqa: E402
from ankor.database import get_session  # noqa: E402
from ankor.deps import get_current_user  # noqa: E402
from ankor.router import create_router  # noqa: E402

# setup_engine() populates _clean_async_url. In api/tests there is no app
# import to trigger this, so we call it explicitly.
_gtm_db.setup_engine(os.environ["GTM_DB_URL"])

# Single shared engine with NullPool: created once per process.
# NullPool means connections are never reused across calls -- each
# `async with _sl()` gets a fresh connection in the current event loop,
# which avoids the "Future attached to a different loop" error that occurs
# when a pooled asyncpg connection is reused across function-scoped loops.
_db_engine = create_async_engine(
    _gtm_db._clean_async_url,
    echo=False,
    poolclass=NullPool,
    connect_args={"prepared_statement_cache_size": 0},
)
_sl = sessionmaker(_db_engine, class_=AsyncSession, expire_on_commit=False)


@pytest.fixture(scope="session")
def _db_setup() -> None:
    """Truncate all tables once at session start -- deterministic clean slate.

    Uses TRUNCATE ... RESTART IDENTITY CASCADE so FK ordering is handled by
    Postgres and sequences reset to 1 (cleaner IDs in failure output).
    Runs via asyncio.run() to stay outside pytest-asyncio event loop scope.
    """

    async def _truncate() -> None:
        async with _sl() as session:
            await session.execute(
                text(
                    "TRUNCATE run_nodes, workflow_runs, workflows, "
                    "users, api_tokens, webhook_tokens, "
                    "config_records, data_table_column_meta, data_tables "
                    "RESTART IDENTITY CASCADE"
                )
            )
            await session.commit()

    asyncio.run(_truncate())


@pytest_asyncio.fixture
async def real_db(_db_setup):
    """Function-scoped real PostgreSQL fixture.

    - Patches _SessionLocal in every ankor sub-module so all DB writes hit the
      real DB.
    - Mocks broadcast.manager to avoid WebSocket errors.
    - Restores original module state after each test.

    Yields the SessionLocal factory; tests open sessions via `async with real_db()`.
    """
    prev = {
        "db_sl": _gtm_db._SessionLocal,
        "db_engine": _gtm_db._engine,
        "wf_sl": _gtm_dec_wf._SessionLocal,
        "pers_sl": _gtm_dec_pers._SessionLocal,
        "drain_sl": _gtm_dec_drain._SessionLocal,
    }

    _gtm_db._SessionLocal = _sl
    _gtm_db._engine = _db_engine
    _gtm_dec_wf._SessionLocal = _sl
    _gtm_dec_pers._SessionLocal = _sl
    _gtm_dec_drain._SessionLocal = _sl

    mock_manager = MagicMock()
    mock_manager.broadcast = AsyncMock()

    with patch("ankor.broadcast.manager", mock_manager):
        yield _sl

    _gtm_db._SessionLocal = prev["db_sl"]
    _gtm_db._engine = prev["db_engine"]
    _gtm_dec_wf._SessionLocal = prev["wf_sl"]
    _gtm_dec_pers._SessionLocal = prev["pers_sl"]
    _gtm_dec_drain._SessionLocal = prev["drain_sl"]


def _build_test_app(real_db, workflow_meta: dict, invoke) -> FastAPI:
    """Build a FastAPI test app wired to real_db, without any auth override."""
    app = FastAPI()
    router = create_router(workflow_meta, invoke=invoke)
    app.include_router(router, prefix="/api")

    async def _session():
        async with real_db() as session:
            yield session

    app.dependency_overrides[get_session] = _session
    return app


@pytest.fixture
def make_test_app(real_db):
    """Factory for an authenticated test app wired to the real test DB."""

    def _make(
        *, workflow_meta: dict | None = None, invoke=None, username: str = "admin"
    ) -> FastAPI:
        app = _build_test_app(real_db, workflow_meta or {}, invoke or AsyncMock())
        app.dependency_overrides[get_current_user] = lambda: MagicMock(
            username=username
        )
        return app

    return _make


@pytest.fixture
def make_unauthenticated_test_app(real_db):
    """Factory for a test app with real auth (no get_current_user override)."""

    def _make(*, workflow_meta: dict | None = None, invoke=None) -> FastAPI:
        return _build_test_app(real_db, workflow_meta or {}, invoke or AsyncMock())

    return _make
