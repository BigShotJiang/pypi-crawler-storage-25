"""Shared seed data helpers used across seed_data sub-modules."""

from __future__ import annotations

import math
from datetime import datetime, timezone


NOW = datetime.now(timezone.utc)


def _seeded(n: int) -> float:
    x = math.sin(n + 1) * 10000
    return x - math.floor(x)


def _make_data(
    triggered_by: str,
    nodes: list,
    inputs: dict | None = None,
    outputs: dict | None = None,
    logs: list | None = None,
) -> dict:
    """Build the WorkflowRun.data payload from seed-friendly args."""
    inp = inputs or {}
    return {
        "trigger_context": {"type": triggered_by, "inputs": inp},
        "nodes": nodes,
        "inputs": inp,
        "outputs": outputs or {},
        "logs": logs or [],
    }
