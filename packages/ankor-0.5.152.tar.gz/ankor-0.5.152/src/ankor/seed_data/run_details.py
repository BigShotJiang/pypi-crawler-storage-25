"""Detailed run fixtures for seed data (workflow runs with full node/log data)."""

from __future__ import annotations

from datetime import timedelta

from .utils import NOW, _make_data

_DETAILED_RUNS = [
    {
        "name": "enrich_leads",
        "status": "success",
        "triggered_by": "schedule",
        "started_at": NOW - timedelta(hours=2),
        "finished_at": NOW - timedelta(hours=2) + timedelta(seconds=38),
        "created_at": NOW - timedelta(hours=2),
        "data": _make_data(
            "schedule",
            [
                {
                    "id": 1,
                    "name": "Fetch Contacts",
                    "status": "success",
                    "inputs": {"limit": 10},
                    "outputs": {"count": 10},
                    "duration_ms": 320,
                },
                {
                    "id": 2,
                    "name": "Enrich via Clearbit",
                    "status": "success",
                    "inputs": {"emails": 10},
                    "outputs": {"enriched": 10},
                    "duration_ms": 12_000,
                },
                {
                    "id": 3,
                    "name": "Trigger Catalog Sync",
                    "status": "success",
                    "inputs": {},
                    "outputs": {},
                    "duration_ms": 12,
                    "is_sub_workflow_trigger": True,
                },
            ],
            inputs={"limit": 10},
            outputs={"enriched": 10},
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=2)).isoformat(),
                    "body": "Starting lead enrichment — limit=10",
                    "type": "info",
                    "json": False,
                },
                {
                    "timestamp": (NOW - timedelta(hours=2, seconds=-8)).isoformat(),
                    "body": "All 10 contacts enriched successfully",
                    "type": "info",
                    "json": False,
                },
            ],
        ),
    },
    {
        "name": "daily_report",
        "status": "failed",
        "triggered_by": "schedule",
        "started_at": NOW - timedelta(hours=5),
        "finished_at": NOW - timedelta(hours=5) + timedelta(seconds=72),
        "created_at": NOW - timedelta(hours=5),
        "data": _make_data(
            "schedule",
            [
                {
                    "id": 1,
                    "name": "Aggregate Sales Data",
                    "status": "success",
                    "inputs": {"region": "EU"},
                    "outputs": {"total": 48200},
                    "duration_ms": 520,
                },
                {
                    "id": 2,
                    "name": "Generate PDF",
                    "status": "failed",
                    "inputs": {"template": "daily_v2"},
                    "outputs": {"error": "missing field `growth_rate`"},
                    "duration_ms": 92,
                    "logs": [
                        {
                            "timestamp": (
                                NOW - timedelta(hours=5, seconds=72)
                            ).isoformat(),
                            "body": "Variable 'growth_rate' not found",
                            "type": "warning",
                            "json": False,
                        },
                        {
                            "timestamp": (
                                NOW - timedelta(hours=5, seconds=71)
                            ).isoformat(),
                            "body": "TemplateRenderError: failed to render template daily_v2",
                            "type": "error",
                            "json": False,
                        },
                    ],
                },
            ],
            inputs={"region": "EU"},
            outputs={},
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=5)).isoformat(),
                    "body": "Daily report started for region=EU",
                    "type": "info",
                    "json": False,
                },
                {
                    "timestamp": (NOW - timedelta(hours=5, seconds=-5)).isoformat(),
                    "body": "PDF generation failed — aborting",
                    "type": "error",
                    "json": False,
                },
            ],
        ),
    },
    {
        "name": "sync_catalog",
        "status": "success",
        "triggered_by": "webhook",
        "started_at": NOW - timedelta(hours=14),
        "finished_at": NOW - timedelta(hours=14) + timedelta(minutes=4),
        "created_at": NOW - timedelta(hours=14),
        "data": _make_data(
            "webhook",
            [
                {
                    "id": 1,
                    "name": "Fetch from ERP",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"products": 50},
                    "duration_ms": 1230,
                },
                {
                    "id": 2,
                    "name": "Push to Shopify",
                    "status": "success",
                    "inputs": {"batch_size": 25},
                    "outputs": {"synced": 50, "errors": 0},
                    "duration_ms": 2520,
                },
            ],
            outputs={"synced": 50},
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=14)).isoformat(),
                    "body": "Fetching products from ERP",
                    "type": "info",
                    "json": False,
                },
                {
                    "timestamp": (NOW - timedelta(hours=14, seconds=-2)).isoformat(),
                    "body": "Pushing 50 products to Shopify",
                    "type": "info",
                    "json": False,
                },
            ],
        ),
    },
    {
        "name": "renewal_check",
        "status": "success",
        "triggered_by": "schedule",
        "started_at": NOW - timedelta(hours=26),
        "finished_at": NOW - timedelta(hours=26) + timedelta(minutes=2),
        "created_at": NOW - timedelta(hours=26),
        "data": _make_data(
            "schedule",
            [
                {
                    "id": 1,
                    "name": "Query Expiring",
                    "status": "success",
                    "inputs": {"days": 7},
                    "outputs": {"count": 14},
                    "duration_ms": 380,
                },
                {
                    "id": 2,
                    "name": "Send Reminders",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"sent": 14},
                    "duration_ms": 1920,
                },
            ],
            inputs={"days": 7},
            outputs={"sent": 14},
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=26)).isoformat(),
                    "body": "Querying contracts expiring in 7 days",
                    "type": "info",
                    "json": False,
                },
                {
                    "timestamp": (NOW - timedelta(hours=26, seconds=-1)).isoformat(),
                    "body": "Sending reminders to 14 accounts",
                    "type": "info",
                    "json": False,
                },
            ],
        ),
    },
    {
        "name": "churn_scoring",
        "status": "success",
        "triggered_by": "schedule",
        "started_at": NOW - timedelta(hours=30),
        "finished_at": NOW - timedelta(hours=30) + timedelta(minutes=5),
        "created_at": NOW - timedelta(hours=30),
        "data": _make_data(
            "schedule",
            [
                {
                    "id": 1,
                    "name": "Load Activity",
                    "status": "success",
                    "inputs": {"lookback_days": 30},
                    "outputs": {"users": 822},
                    "duration_ms": 1100,
                },
                {
                    "id": 2,
                    "name": "Run ML Model",
                    "status": "success",
                    "inputs": {"threshold": 0.75},
                    "outputs": {"high_risk": 38},
                    "duration_ms": 2840,
                },
                {
                    "id": 3,
                    "name": "Write Scores",
                    "status": "success",
                    "inputs": {},
                    "outputs": {
                        "summary": "# Churn Scores Written\n\n**822 users** updated in the database.\n\n- High-risk flagged: **38**\n- Score threshold: 0.75\n\n> Next run scheduled in 24 h."
                    },
                    "duration_ms": 560,
                },
            ],
            inputs={"lookback_days": 30, "threshold": 0.75},
            outputs={
                "report": "## Churn Analysis — April 2026\n\n**822 users** scored, **38 at high risk** (threshold: 0.75).\n\n### Risk Distribution\n\n| Level | Count |\n|-------|-------|\n| High | 38 |\n| Medium | 194 |\n| Low | 590 |\n\n> Recommend immediate outreach to high-risk accounts."
            },
            logs=[
                {
                    "timestamp": (NOW - timedelta(hours=30)).isoformat(),
                    "body": "Scored 822 users — 38 high-risk",
                    "type": "info",
                    "json": False,
                },
            ],
        ),
    },
]

# Child runs — seeded after _DETAILED_RUNS so parent IDs are available.
# "parent_started_at" identifies the parent run from _DETAILED_RUNS.
_CHILD_RUNS = [
    # enrich_leads completes → immediately kicks off a catalog sync
    {
        "parent_started_at": NOW - timedelta(hours=2),
        # The node in the parent run that triggered this child run.
        # node_name must match an entry in the parent's data["nodes"] list.
        "trigger_node_name": "Trigger Catalog Sync",
        "name": "sync_catalog",
        "status": "success",
        "triggered_by": "rerun",
        "started_at": NOW - timedelta(hours=2) + timedelta(seconds=40),
        "finished_at": NOW
        - timedelta(hours=2)
        + timedelta(seconds=40)
        + timedelta(minutes=3, seconds=12),
        "created_at": NOW - timedelta(hours=2) + timedelta(seconds=40),
        "data": _make_data(
            "rerun",
            [
                {
                    "id": 1,
                    "name": "Fetch from ERP",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"products": 53},
                    "duration_ms": 980,
                },
                {
                    "id": 2,
                    "name": "Push to Shopify",
                    "status": "success",
                    "inputs": {"batch_size": 25},
                    "outputs": {"synced": 53, "errors": 0},
                    "duration_ms": 2180,
                },
                {
                    "id": 3,
                    "name": "Trigger Churn Scoring",
                    "status": "success",
                    "inputs": {},
                    "outputs": {},
                    "duration_ms": 11,
                    "is_sub_workflow_trigger": True,
                },
            ],
            outputs={"synced": 53},
        ),
    },
    # daily_report fails → operator manually reruns it (manual rerun, no trigger node)
    {
        "parent_started_at": NOW - timedelta(hours=5),
        "name": "daily_report",
        "status": "success",
        "triggered_by": "manual",
        "started_at": NOW - timedelta(hours=4, minutes=30),
        "finished_at": NOW - timedelta(hours=4, minutes=30) + timedelta(seconds=58),
        "created_at": NOW - timedelta(hours=4, minutes=30),
        "data": _make_data(
            "manual",
            [
                {
                    "id": 1,
                    "name": "Aggregate Sales Data",
                    "status": "success",
                    "inputs": {"region": "EU"},
                    "outputs": {"total": 48200},
                    "duration_ms": 495,
                },
                {
                    "id": 2,
                    "name": "Generate Report",
                    "status": "success",
                    "inputs": {"template": "daily_v2"},
                    "outputs": {
                        "report": "# Daily Report — April 7, 2026\n\n**Region:** EU\n\n**Total Sales:** €48,200\n\n### Highlights\n\n- Revenue up **12%** vs prior week\n- Top product: _Enterprise Plan_\n- 14 contracts renewed\n\n> Generated at 03:30 UTC"
                    },
                    "duration_ms": 1760,
                },
            ],
            inputs={"region": "EU"},
            outputs={
                "report": "# Daily Report — April 7, 2026\n\n**Region:** EU\n\n**Total Sales:** €48,200\n\n### Highlights\n\n- Revenue up **12%** vs prior week\n- Top product: _Enterprise Plan_\n- 14 contracts renewed\n\n> Generated at 03:30 UTC"
            },
        ),
    },
]

# Grandchild runs — seeded after _CHILD_RUNS so child IDs are available.
# "parent_started_at" identifies the parent run from _CHILD_RUNS.
_GRANDCHILD_RUNS = [
    # sync_catalog finishes → churn scores refreshed with updated product data
    {
        "parent_started_at": NOW - timedelta(hours=2) + timedelta(seconds=40),
        "trigger_node_name": "Trigger Churn Scoring",
        "name": "churn_scoring",
        "status": "success",
        "triggered_by": "rerun",
        "started_at": NOW
        - timedelta(hours=2)
        + timedelta(seconds=40)
        + timedelta(minutes=3, seconds=15),
        "finished_at": NOW
        - timedelta(hours=2)
        + timedelta(seconds=40)
        + timedelta(minutes=7, seconds=42),
        "created_at": NOW
        - timedelta(hours=2)
        + timedelta(seconds=40)
        + timedelta(minutes=3, seconds=15),
        "data": _make_data(
            "rerun",
            [
                {
                    "id": 1,
                    "name": "Load Activity",
                    "status": "success",
                    "inputs": {"lookback_days": 30},
                    "outputs": {"users": 845},
                    "duration_ms": 870,
                },
                {
                    "id": 2,
                    "name": "Run ML Model",
                    "status": "success",
                    "inputs": {"threshold": 0.75},
                    "outputs": {"high_risk": 41},
                    "duration_ms": 2590,
                },
                {
                    "id": 3,
                    "name": "Write Scores",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"rows": 845},
                    "duration_ms": 390,
                },
            ],
            inputs={"lookback_days": 30, "threshold": 0.75},
            outputs={"high_risk": 41, "rows": 845},
        ),
    },
    # daily_report rerun succeeds → renewal reminders go out (manual rerun, no trigger node)
    {
        "parent_started_at": NOW - timedelta(hours=4, minutes=30),
        "name": "renewal_check",
        "status": "success",
        "triggered_by": "rerun",
        "started_at": NOW - timedelta(hours=4, minutes=30) + timedelta(minutes=1),
        "finished_at": NOW
        - timedelta(hours=4, minutes=30)
        + timedelta(minutes=3, seconds=10),
        "created_at": NOW - timedelta(hours=4, minutes=30) + timedelta(minutes=1),
        "data": _make_data(
            "rerun",
            [
                {
                    "id": 1,
                    "name": "Query Expiring",
                    "status": "success",
                    "inputs": {"days": 7},
                    "outputs": {"count": 14},
                    "duration_ms": 340,
                },
                {
                    "id": 2,
                    "name": "Send Reminders",
                    "status": "success",
                    "inputs": {},
                    "outputs": {"sent": 14},
                    "duration_ms": 1780,
                },
            ],
            inputs={"days": 7},
            outputs={"sent": 14},
        ),
    },
]
