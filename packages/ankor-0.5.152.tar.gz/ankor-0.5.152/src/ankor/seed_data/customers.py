"""Customer fixture data and demo table definitions."""

from __future__ import annotations

from .utils import _seeded


_CUSTOMER_FIRST_NAMES = [
    "Alice",
    "Bob",
    "Clara",
    "David",
    "Emma",
    "Felix",
    "Grace",
    "Henry",
    "Isabelle",
    "Jack",
    "Kate",
    "Liam",
    "Maria",
    "Noah",
    "Olivia",
    "Paul",
    "Quinn",
    "Rachel",
    "Samuel",
    "Tara",
    "Uma",
    "Victor",
    "Wendy",
    "Xander",
    "Yara",
    "Zoe",
    "Adrian",
    "Beatrice",
    "Carlos",
    "Diana",
]

_CUSTOMER_LAST_NAMES = [
    "Martin",
    "Strauss",
    "Ng",
    "Johnson",
    "Williams",
    "Brown",
    "Jones",
    "Garcia",
    "Miller",
    "Davis",
    "Wilson",
    "Taylor",
    "Anderson",
    "Thomas",
    "Jackson",
    "White",
    "Harris",
    "Sanchez",
    "Clark",
    "Lewis",
    "Robinson",
    "Walker",
    "Young",
    "Allen",
    "King",
    "Wright",
    "Scott",
    "Torres",
    "Hill",
    "Reed",
]

_CUSTOMER_EMAIL_DOMAINS = [
    "example.com",
    "techcorp.de",
    "startup.io",
    "acme.co",
    "globalinc.net",
    "devstudio.org",
    "cloudbase.io",
    "enterprise.com",
    "scale.ai",
    "b2b.co",
]

_PLANS = ["free", "pro", "enterprise"]
_PLAN_IDS = {"free": 1, "pro": 2, "enterprise": 3}
_PLAN_MRR = {"free": 0, "pro": 149, "enterprise": 599}


def _make_customer_rows(n: int = 250) -> list[dict]:
    rows = []

    for i in range(n):
        first = _CUSTOMER_FIRST_NAMES[
            int(_seeded(i * 7 + 1) * len(_CUSTOMER_FIRST_NAMES))
        ]
        last = _CUSTOMER_LAST_NAMES[int(_seeded(i * 7 + 2) * len(_CUSTOMER_LAST_NAMES))]
        plan = _PLANS[int(_seeded(i * 7 + 3) * len(_PLANS))]
        active = _seeded(i * 7 + 4) > 0.2
        domain = _CUSTOMER_EMAIL_DOMAINS[
            int(_seeded(i * 7 + 5) * len(_CUSTOMER_EMAIL_DOMAINS))
        ]
        email = f"{first.lower()}.{last.lower()}{i + 1}@{domain}"
        rows.append(
            {
                "id": i + 1,
                "name": f"{first} {last}",
                "email": email,
                "plan": _PLAN_IDS[plan],
                "mrr": _PLAN_MRR[plan],
                "active": active,
            }
        )

    return rows


_TABLES = [
    {
        "name": "Customers",
        "description": "All registered customers",
        "columns": [
            {"id": "name", "name": "name", "type": "text"},
            {"id": "email", "name": "email", "type": "text"},
            {
                "id": "plan",
                "name": "plan",
                "type": "select",
                "selectOptions": [
                    {"id": 1, "label": "free", "color": "#64748b"},
                    {"id": 2, "label": "pro", "color": "#3b82f6"},
                    {"id": 3, "label": "enterprise", "color": "#a855f7"},
                ],
            },
            {"id": "mrr", "name": "mrr", "type": "integer"},
            {"id": "active", "name": "active", "type": "boolean"},
        ],
        "rows": _make_customer_rows(),
    },
]


