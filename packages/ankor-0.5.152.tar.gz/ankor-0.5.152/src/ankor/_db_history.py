"""History-flush helpers for DB table rows during/after workflow runs."""

from __future__ import annotations

import json
from datetime import datetime, timezone

from sqlalchemy import text

from .db_helpers import _normalize_row, _pg_table, _read_col_types


async def flush_single_row_history(
    ctx: dict,
    table_id: int,
    row_id: int,
    *,
    node_slot: dict | None = None,
    failed_exc: Exception | None = None,
) -> None:
    """Write a run-pointer history entry for *one* row immediately.

    Called by a ``tracks_row=True`` node wrapper when the node finishes so that
    the history badge appears right away — before the whole workflow ends.

    Marks the corresponding ``_row_history`` entry as ``_flushed`` so that
    :func:`flush_row_history` skips it (no duplicates).
    """
    from .database import _SessionLocal
    from .broadcast import manager

    if _SessionLocal is None:
        return

    run_id: int | None = ctx.get("run_id")
    row_history: dict = ctx.setdefault("_row_history", {})
    key = (table_id, row_id)
    entry = row_history.get(key)

    if entry is not None and entry.get("_flushed"):
        return  # Already flushed — nothing to do.

    # Build the minimal pointer entry.
    node_run_id: int | None = node_slot.get("_db_id") if node_slot else None
    run_meta: dict = ctx.get("_run_meta") or {}
    wf_name: str | None = run_meta.get("name")

    db_entry: dict = {
        "wr_id": run_id,
        "node_run_id": node_run_id,
        "started_at": run_meta.get("startedAt"),
        "finished_at": datetime.now(timezone.utc).isoformat(),
    }

    if wf_name:
        db_entry["wf_name"] = wf_name

    if failed_exc is not None:
        db_entry["status"] = "failed"
        db_entry["error"] = f"{type(failed_exc).__name__}: {failed_exc}"

    tbl = _pg_table(table_id)
    async with _SessionLocal() as session:
        # TODO: decide whether to deduplicate history entries on resume.
        # if node_run_id is not None:
        #     # If this node already wrote a history entry (e.g. the server crashed
        #     # and the failed node is being retried on resume), replace the existing
        #     # entry in-place rather than appending a duplicate.
        #     await session.execute(
        #         text(
        #             f"UPDATE {tbl} SET "
        #             "history = CASE "
        #             "  WHEN history IS NOT NULL AND EXISTS ("
        #             "    SELECT 1 FROM jsonb_array_elements(history) AS h "
        #             "    WHERE (h->>'node_run_id')::int = :nrid"
        #             "  ) THEN ("
        #             "    SELECT jsonb_agg(CASE WHEN (h->>'node_run_id')::int = :nrid "
        #             "      THEN CAST(:entry AS jsonb) ELSE h END) "
        #             "    FROM jsonb_array_elements(history) AS h"
        #             "  ) "
        #             "  ELSE COALESCE(history, '[]'::jsonb) || CAST(:entry AS jsonb) "
        #             "END, "
        #             "updated_at = NOW() "
        #             "WHERE id = :row_id"
        #         ),
        #         {"entry": json.dumps(db_entry), "nrid": node_run_id, "row_id": row_id},
        #     )
        # else:
        await session.execute(
            text(
                f"UPDATE {tbl} SET "
                "history = COALESCE(history, '[]'::jsonb) || CAST(:entry AS jsonb), "
                "updated_at = NOW() "
                "WHERE id = :row_id"
            ),
            {"entry": json.dumps([db_entry]), "row_id": row_id},
        )
        await session.commit()

        col_types = await _read_col_types(session, tbl)

        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )

        row = result.first()

        if row is not None:
            normalized = _normalize_row(row._mapping, col_types)
            changed_cols: set | None = entry.get("_changed_cols") if entry else None

            if changed_cols:
                broadcast_row = {
                    k: v
                    for k, v in normalized.items()
                    if k in {"id", "history"} or k in changed_cols
                }
            else:
                json_col_ids = {k for k, v in col_types.items() if v == "json"}
                broadcast_row = {
                    k: v for k, v in normalized.items() if k not in json_col_ids
                }

            msg: dict = {"type": "row_updated", "row": broadcast_row}

            if run_id is not None:
                msg["run_id"] = run_id
            await manager.broadcast(f"table:{table_id}", msg)

    # Mark flushed *after* successful DB write so a retry is safe.
    if entry is None:
        row_history[key] = {"wr_id": run_id, "_flushed": True}
    else:
        entry["_flushed"] = True


async def flush_row_history(ctx: dict, *, failed_exc: Exception | None = None) -> None:
    """Write a run-pointer history entry for rows touched during a workflow run.

    Rows whose history was already flushed by :func:`flush_single_row_history`
    (i.e. ``_flushed`` is True) are skipped to avoid duplicates.
    """
    from .database import _SessionLocal
    from .broadcast import manager

    if _SessionLocal is None:
        return
    row_history: dict = ctx.get("_row_history", {})
    if not row_history:
        return

    run_id: int | None = ctx.get("run_id")
    run_meta: dict = ctx.get("_run_meta") or {}
    wf_name: str | None = run_meta.get("name")
    error_str = f"{type(failed_exc).__name__}: {failed_exc}" if failed_exc else None
    finished_at = datetime.now(timezone.utc).isoformat()

    # Group pending entries by table so we can batch the DB writes and
    # send one WS event per table instead of one per row.
    from collections import defaultdict

    by_table: dict[int, list[tuple[int, dict]]] = defaultdict(list)
    for (table_id, row_id), entry in row_history.items():
        if not entry.get("_flushed"):
            by_table[table_id].append((row_id, entry))

    async with _SessionLocal() as session:
        for table_id, pending in by_table.items():
            tbl = _pg_table(table_id)
            col_types = await _read_col_types(session, tbl)
            json_col_ids = {k for k, v in col_types.items() if v == "json"}

            updated_rows: list[dict] = []
            for row_id, entry in pending:
                db_entry: dict = {
                    "wr_id": entry.get("wr_id"),
                    "node_run_id": entry.get("_node_db_id"),
                    "started_at": run_meta.get("startedAt"),
                    "finished_at": finished_at,
                }
                if wf_name:
                    db_entry["wf_name"] = wf_name
                if failed_exc is not None:
                    db_entry["status"] = "failed"
                    db_entry["error"] = error_str

                await session.execute(
                    text(
                        f"UPDATE {tbl} SET "
                        "history = COALESCE(history, '[]'::jsonb) || CAST(:entry AS jsonb), "
                        "updated_at = NOW() "
                        "WHERE id = :row_id"
                    ),
                    {"entry": json.dumps([db_entry]), "row_id": row_id},
                )

            await session.commit()

            # Fetch all updated rows for this table in one query.
            row_id_to_entry = {row_id: entry for row_id, entry in pending}
            row_ids = list(row_id_to_entry.keys())

            result = await session.execute(
                text(f"SELECT * FROM {tbl} WHERE id = ANY(:ids)"),
                {"ids": row_ids},
            )

            for row in result:
                normalized = _normalize_row(row._mapping, col_types)
                row_entry = row_id_to_entry.get(normalized.get("id"))
                changed_cols: set | None = (
                    row_entry.get("_changed_cols") if row_entry else None
                )

                if changed_cols:
                    broadcast_row = {
                        k: v
                        for k, v in normalized.items()
                        if k in {"id", "history"} or k in changed_cols
                    }
                else:
                    broadcast_row = {
                        k: v for k, v in normalized.items() if k not in json_col_ids
                    }
                updated_rows.append(broadcast_row)

            if updated_rows:
                msg: dict = {"type": "rows_bulk_updated", "rows": updated_rows}

                if run_id is not None:
                    msg["run_id"] = run_id

                await manager.broadcast(f"table:{table_id}", msg)
