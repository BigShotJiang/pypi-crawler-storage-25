"""Seed demo data.

When ``auto_seed`` (GTM_SEED env var) is enabled, always truncates all
tables and re-inserts fresh demo data on every startup.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from .seed_data.run_details import _CHILD_RUNS, _DETAILED_RUNS, _GRANDCHILD_RUNS
from .seed_data.customers import _TABLES
from .seed_data.utils import NOW, _make_data, _seeded

_WORKFLOW_NAMES = [
    "enrich_leads",
    "daily_report",
    "sync_catalog",
    "renewal_check",
    "churn_scoring",
]

_WORKFLOW_FOLDERS: dict[str, str] = {
    "enrich_leads": "CRM/Enrichment",
    "daily_report": "Reporting",
    "sync_catalog": "E-Commerce",
    "renewal_check": "CRM/Notifications",
    "churn_scoring": "Analytics",
}


_HISTORICAL_DATA: dict[str, dict] = {
    "enrich_leads": {
        "inputs": {"limit": 10},
        "outputs": {"enriched": 10},
        "nodes": [
            {
                "id": 1,
                "name": "Fetch Contacts",
                "status": "success",
                "inputs": {"limit": 10},
                "outputs": {"count": 10},
                "duration_ms": 310,
            },
            {
                "id": 2,
                "name": "Enrich via Clearbit",
                "status": "success",
                "inputs": {"emails": 10},
                "outputs": {"enriched": 10},
                "duration_ms": 11_500,
            },
        ],
    },
    "daily_report": {
        "inputs": {"region": "EU"},
        "outputs": {"total": 48200},
        "nodes": [
            {
                "id": 1,
                "name": "Aggregate Sales Data",
                "status": "success",
                "inputs": {"region": "EU"},
                "outputs": {"total": 48200},
                "duration_ms": 510,
            },
            {
                "id": 2,
                "name": "Generate PDF",
                "status": "success",
                "inputs": {"template": "daily_v2"},
                "outputs": {"path": "/reports/daily.pdf"},
                "duration_ms": 1750,
            },
        ],
    },
    "sync_catalog": {
        "inputs": {},
        "outputs": {"synced": 50},
        "nodes": [
            {
                "id": 1,
                "name": "Fetch from ERP",
                "status": "success",
                "inputs": {},
                "outputs": {"products": 50},
                "duration_ms": 1100,
            },
            {
                "id": 2,
                "name": "Push to Shopify",
                "status": "success",
                "inputs": {"batch_size": 25},
                "outputs": {"synced": 50, "errors": 0},
                "duration_ms": 2400,
            },
        ],
    },
    "renewal_check": {
        "inputs": {"days": 7},
        "outputs": {"sent": 14},
        "nodes": [
            {
                "id": 1,
                "name": "Query Expiring",
                "status": "success",
                "inputs": {"days": 7},
                "outputs": {"count": 14},
                "duration_ms": 360,
            },
            {
                "id": 2,
                "name": "Send Reminders",
                "status": "success",
                "inputs": {},
                "outputs": {"sent": 14},
                "duration_ms": 1850,
            },
        ],
    },
    "churn_scoring": {
        "inputs": {"lookback_days": 30, "threshold": 0.75},
        "outputs": {"high_risk": 38, "rows": 822},
        "nodes": [
            {
                "id": 1,
                "name": "Load Activity",
                "status": "success",
                "inputs": {"lookback_days": 30},
                "outputs": {"users": 822},
                "duration_ms": 1050,
            },
            {
                "id": 2,
                "name": "Run ML Model",
                "status": "success",
                "inputs": {"threshold": 0.75},
                "outputs": {"high_risk": 38},
                "duration_ms": 2700,
            },
            {
                "id": 3,
                "name": "Write Scores",
                "status": "success",
                "inputs": {},
                "outputs": {"rows": 822},
                "duration_ms": 530,
            },
        ],
    },
}


def _make_historical_runs() -> list[dict]:
    """~120 runs spread over the last 30 days — used to populate the activity chart."""
    runs: list[dict] = []
    base = NOW - timedelta(days=4)
    hour_ms = 3_600_000
    t = int(base.timestamp() * 1000)
    end = int((NOW - timedelta(days=2)).timestamp() * 1000)
    slot = 0

    while t <= end:
        d = datetime.fromtimestamp(t / 1000, tz=timezone.utc)
        is_biz = 8 <= d.hour <= 18 and d.weekday() < 5
        count = int(_seeded(slot) * (12 if is_biz else 3))

        for i in range(count):
            failed = _seeded(slot * 100 + i + 77) < 0.13
            started = datetime.fromtimestamp(t / 1000, tz=timezone.utc)
            finished = started + timedelta(seconds=int(_seeded(slot + i) * 120) + 5)
            wf = _WORKFLOW_NAMES[int(_seeded(slot + i + 3) * len(_WORKFLOW_NAMES))]
            stub = _HISTORICAL_DATA[wf]
            nodes = [
                {
                    **n,
                    "status": (
                        "failed"
                        if (failed and j == len(stub["nodes"]) - 1)
                        else "success"
                    ),
                }
                for j, n in enumerate(stub["nodes"])
            ]
            runs.append(
                {
                    "name": wf,
                    "status": "failed" if failed else "success",
                    "triggered_by": "schedule",
                    "started_at": started,
                    "finished_at": finished,
                    "created_at": started,
                    "data": _make_data(
                        "schedule",
                        nodes,
                        inputs=stub["inputs"],
                        outputs={} if failed else stub["outputs"],
                    ),
                }
            )
        t += hour_ms
        slot += 1

    return runs


_CONFIGS = [
    {
        "key": "app.name",
        "value": "ANKOR",
        "type": "string",
        "folder": "System",
        "description": "Application display name",
    },
    {
        "key": "max.retries",
        "value": "3",
        "type": "number",
        "folder": "System",
        "description": "Maximum retry attempts for failed workflows",
    },
    {
        "key": "maintenance.date",
        "value": "2026-05-01",
        "type": "date",
        "folder": "Infrastructure",
        "description": "Next scheduled maintenance window",
    },
    {
        "key": "digest.send.time",
        "value": "08:00",
        "type": "time",
        "folder": "Notifications",
        "description": "Daily digest delivery time",
    },
    {
        "key": "default.region",
        "value": "EU",
        "type": "select",
        "select_options": ["EU", "US", "APAC"],
        "folder": "Infrastructure",
        "description": "Default region for data processing",
    },
    {
        "key": "feature.flags",
        "value": json.dumps(
            {"darkMode": True, "betaWorkflows": False, "analyticsV2": True}, indent=2
        ),
        "type": "json",
        "folder": "System",
        "description": "Feature toggle flags",
    },
]


async def seed_demo_data() -> None:
    """Clear all demo tables and re-insert fresh seed data.

    Always runs a full replace so the DB state is predictable after every call.
    """
    from sqlalchemy import text
    from sqlmodel import select

    from .database import get_session
    from .db_helpers import _pg_table, _PG_TYPE_MAP, _qi, _upsert_row
    from .models import (
        ConfigRecord,
        DataTable,
        RunNode,
        TriggerType,
        Workflow,
        WorkflowRun,
        WorkflowStatus,
    )

    async for session in get_session():
        # Clear in dependency order (workflow_runs self-references via parent_id)
        await session.execute(text("DELETE FROM workflow_runs"))
        await session.execute(text("DELETE FROM workflows"))
        await session.execute(text("DELETE FROM config_records"))
        existing_ids = [
            r[0]
            for r in (
                await session.execute(text("SELECT id FROM data_tables"))
            ).fetchall()
        ]

        for tbl_id in existing_ids:
            await session.execute(text(f"DROP TABLE IF EXISTS data_table_{tbl_id}"))
        await session.execute(text("DELETE FROM data_table_column_meta"))
        await session.execute(text("TRUNCATE data_tables RESTART IDENTITY CASCADE"))
        await session.execute(text("DELETE FROM users"))

        # Seed Workflow rows and build name→id map for run association.
        for wf_name in _WORKFLOW_NAMES:
            session.add(Workflow(name=wf_name, folder=_WORKFLOW_FOLDERS.get(wf_name)))
        await session.commit()
        wf_id_map: dict[str, int] = {
            wf.name: wf.id for wf in (await session.exec(select(Workflow))).all()
        }

        historical = _make_historical_runs()

        for row in historical:
            wf_name = row.pop("name")
            triggered_by = row.pop("triggered_by", "schedule")
            row["workflow_id"] = wf_id_map[wf_name]
            row["triggered_by"] = TriggerType(triggered_by)
            session.add(WorkflowRun(**row))

        # Keep references to detailed run objects so we can read their IDs after commit.
        detailed_objs: dict[datetime, WorkflowRun] = {}

        for row in list(
            _DETAILED_RUNS
        ):  # iterate a copy so we don't mutate the module-level list
            row = dict(row)
            wf_name = row.pop("name")
            triggered_by = row.pop("triggered_by", "schedule")
            row["workflow_id"] = wf_id_map[wf_name]
            row["triggered_by"] = TriggerType(triggered_by)
            obj = WorkflowRun(**row)
            session.add(obj)
            detailed_objs[obj.started_at] = obj
        await session.commit()

        for obj in detailed_objs.values():
            await session.refresh(obj)

        # Children — linked to detailed runs via parent_id.
        child_objs: dict[datetime, WorkflowRun] = {}

        for row in list(_CHILD_RUNS):
            row = dict(row)
            parent_started = row.pop("parent_started_at")
            row.pop("trigger_node_name", None)
            wf_name = row.pop("name")
            triggered_by = row.pop("triggered_by", "rerun")
            row["workflow_id"] = wf_id_map[wf_name]
            row["triggered_by"] = TriggerType(triggered_by)
            row["parent_id"] = detailed_objs[parent_started].id
            obj = WorkflowRun(**row)
            session.add(obj)
            child_objs[obj.started_at] = obj
        await session.commit()

        for obj in child_objs.values():
            await session.refresh(obj)

        # Grandchildren — linked to child runs via parent_id.
        grandchild_objs: dict[datetime, WorkflowRun] = {}
        for row in list(_GRANDCHILD_RUNS):
            row = dict(row)
            parent_started = row.pop("parent_started_at")
            row.pop("trigger_node_name", None)
            wf_name = row.pop("name")
            triggered_by = row.pop("triggered_by", "rerun")
            row["workflow_id"] = wf_id_map[wf_name]
            row["triggered_by"] = TriggerType(triggered_by)
            row["parent_id"] = child_objs[parent_started].id
            obj = WorkflowRun(**row)
            session.add(obj)
            grandchild_objs[obj.started_at] = obj
        await session.commit()

        for obj in grandchild_objs.values():
            await session.refresh(obj)

        # Build a lookup: (parent_run_id, trigger_node_name) → child_run_id
        trigger_to_child: dict[tuple[int, str], int] = {}
        for row in _CHILD_RUNS:
            trigger_name = row.get("trigger_node_name")
            if trigger_name:
                parent_obj = detailed_objs[row["parent_started_at"]]
                child_obj = child_objs[row["started_at"]]
                trigger_to_child[(parent_obj.id, trigger_name)] = child_obj.id
        for row in _GRANDCHILD_RUNS:
            trigger_name = row.get("trigger_node_name")
            if trigger_name:
                parent_obj = child_objs[row["parent_started_at"]]
                grandchild_obj = grandchild_objs[row["started_at"]]
                trigger_to_child[(parent_obj.id, trigger_name)] = grandchild_obj.id

        # Insert RunNode rows for all detailed, child, and grandchild runs so that
        # sub-workflow node trees are visible in the UI.
        def _seed_nodes_for_run(run_obj: WorkflowRun) -> None:
            nodes = (run_obj.data or {}).get("nodes", [])
            for n in nodes:
                child_run_id = trigger_to_child.get((run_obj.id, n["name"]))
                session.add(
                    RunNode(
                        run_id=run_obj.id,
                        name=n["name"],
                        status=WorkflowStatus(n["status"]),
                        duration_ms=n.get("duration_ms", 0),
                        started_at=run_obj.started_at,
                        child_run_id=child_run_id,
                        data={
                            "inputs": n.get("inputs", {}),
                            "outputs": n.get("outputs", {}),
                            "logs": n.get("logs", []),
                        },
                    )
                )

        for obj in detailed_objs.values():
            _seed_nodes_for_run(obj)
        for obj in child_objs.values():
            _seed_nodes_for_run(obj)
        for obj in grandchild_objs.values():
            _seed_nodes_for_run(obj)

        total = (
            len(historical)
            + len(_DETAILED_RUNS)
            + len(_CHILD_RUNS)
            + len(_GRANDCHILD_RUNS)
        )
        print(
            f"ankor: seeded {total} demo workflow runs ({len(_CHILD_RUNS)} children, {len(_GRANDCHILD_RUNS)} grandchildren)"
        )

        for cfg in _CONFIGS:
            session.add(ConfigRecord(**cfg))
        print(f"ankor: seeded {len(_CONFIGS)} config records")

        for tbl_data in _TABLES:
            t = DataTable(
                name=tbl_data["name"],
                description=tbl_data.get("description"),
            )
            session.add(t)
            await session.flush()
            tbl = _pg_table(t.id)
            col_defs = [
                "id INTEGER NOT NULL",
                "created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
                "updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
                "history JSONB NOT NULL DEFAULT '[]'",
            ] + [
                f"{_qi(col['id'])} {_PG_TYPE_MAP.get(col.get('type', 'text'), 'TEXT')}"
                for col in tbl_data["columns"]
            ]
            await session.execute(
                text(f"CREATE TABLE {tbl} ({', '.join(col_defs)}, PRIMARY KEY (id))")
            )

            for col in tbl_data["columns"]:
                if col.get("type") == "select":
                    await session.execute(
                        text(
                            "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                            "VALUES (:tid, :cn, CAST(:opts AS json))"
                        ),
                        {
                            "tid": t.id,
                            "cn": col["id"],
                            "opts": json.dumps(col.get("selectOptions") or []),
                        },
                    )
            col_ids = [c["id"] for c in tbl_data["columns"]]

            for row in tbl_data.get("rows", []):
                await _upsert_row(session, tbl, row, col_ids)
        print(f"ankor: seeded {len(_TABLES)} demo db tables")

        await session.commit()
        print("ankor: seed complete.")
        break  # get_session is a generator; one iteration is all we need
