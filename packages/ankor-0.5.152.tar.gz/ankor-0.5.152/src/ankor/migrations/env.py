"""Alembic migration environment for ankor package."""

from __future__ import annotations

import asyncio
import os
import sys
from logging.config import fileConfig
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from alembic import context
from sqlalchemy.ext.asyncio import create_async_engine
from sqlmodel import SQLModel

# Make ankor importable when running alembic from the api/ directory
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import ankor.models  # noqa: F401 — registers all SQLModel tables

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = SQLModel.metadata


def _get_url() -> tuple[str, dict]:
    """Return (clean_async_url, connect_args) for the configured DB URL.

    Strips libpq-style ``?sslmode=`` from the URL and translates it to the
    native asyncpg ``ssl`` connect_arg so that asyncpg doesn't reject it.
    """
    url = (
        os.environ.get("GTM_DB_URL")
        or os.environ.get("DATABASE_URL")
        or config.get_main_option("sqlalchemy.url", "")
    )
    if not url:
        raise RuntimeError(
            "No database URL found. Set GTM_DB_URL or DATABASE_URL, "
            "or add sqlalchemy.url to alembic.ini."
        )
    if url.startswith("postgresql://"):
        url = url.replace("postgresql://", "postgresql+asyncpg://", 1)
    elif url.startswith("postgresql+psycopg2://"):
        url = url.replace("postgresql+psycopg2://", "postgresql+asyncpg://", 1)

    # asyncpg doesn't accept libpq-style sslmode= — strip and translate.
    parsed = urlparse(url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    sslmode = params.pop("sslmode", [None])[0]
    clean_url = urlunparse(
        parsed._replace(query=urlencode({k: v[0] for k, v in params.items()}))
    )

    connect_args: dict = {}
    if sslmode == "require":
        connect_args["ssl"] = "require"
    elif sslmode in ("verify-ca", "verify-full"):
        import ssl as _ssl

        connect_args["ssl"] = _ssl.create_default_context()

    return clean_url, connect_args


def run_migrations_offline() -> None:
    url, _ = _get_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection):
    context.configure(connection=connection, target_metadata=target_metadata)
    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online() -> None:
    url, connect_args = _get_url()
    engine = create_async_engine(url, connect_args=connect_args)
    async with engine.connect() as connection:
        await connection.run_sync(do_run_migrations)
    await engine.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
