"""Add col_type column to data_table_column_meta for type overrides (e.g. url).

Revision ID: 0030
Revises: 0029
Create Date: 2026-04-26
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0030"
down_revision: Union[str, None] = "0029"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "data_table_column_meta",
        sa.Column("col_type", sa.String(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("data_table_column_meta", "col_type")
