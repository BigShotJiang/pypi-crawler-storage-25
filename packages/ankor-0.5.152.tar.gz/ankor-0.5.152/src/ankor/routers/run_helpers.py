from __future__ import annotations

import json
from collections import defaultdict
from typing import Any

from sqlalchemy import func
from sqlmodel.ext.asyncio.session import AsyncSession

from ..models import RunNode, WorkflowRun
from .schemas import (
    WorkflowNodeRead,
    WorkflowNodeSummary,
    WorkflowRunChild,
    WorkflowRunRead,
    WorkflowRunSummary,
)


def _strip_history(obj: Any) -> Any:
    """Recursively remove all 'history' keys from dicts in a nested structure.

    Called when building node responses with include_history=False so that
    row dicts embedded in inputs/outputs don't carry the full history array.
    """
    if isinstance(obj, dict):
        return {k: _strip_history(v) for k, v in obj.items() if k != "history"}

    if isinstance(obj, list):
        return [_strip_history(item) for item in obj]

    return obj


def _status_str(node: RunNode) -> str:
    st = node.status
    return (st.value if hasattr(st, "value") else st) or "pending"


def _node_row_to_slim(
    node: RunNode,
    children_map: dict[int, list[RunNode]],
    run_roots_map: dict[int, list[RunNode]] | None = None,
    depth: int = 0,
    max_depth: int = 2,
) -> WorkflowNodeSummary:
    """Build a slim WorkflowNodeSummary from a RunNode row, recursing into children."""
    direct = children_map.get(node.id, [])
    via_sub = (
        run_roots_map.get(node.child_run_id, [])
        if node.child_run_id and run_roots_map
        else []
    )
    children_count = len(direct) + len(via_sub)

    children: list[WorkflowNodeSummary] = []

    if depth < max_depth:
        for c in direct:
            children.append(
                _node_row_to_slim(c, children_map, run_roots_map, depth + 1, max_depth)
            )

        for c in via_sub:
            children.append(
                _node_row_to_slim(c, children_map, run_roots_map, depth + 1, max_depth)
            )

    return WorkflowNodeSummary(
        id=node.id,
        name=node.name or "",
        slug=node.slug,
        status=_status_str(node),
        duration_ms=node.duration_ms or 0,
        started_at=node.started_at,
        child_run_id=node.child_run_id,
        children=children,
        children_count=children_count,
    )


def _node_row_to_full(
    node: RunNode,
    all_nodes: list[RunNode],
    *,
    include_history: bool = True,
) -> WorkflowNodeRead:
    """Build a full WorkflowNodeRead from a RunNode row.

    Only the root node carries full inputs/outputs/logs.  All children are
    serialised as slim WorkflowNodeSummary objects (id, name, status, etc.) —
    the same projection returned by GET /workflow-runs/{id}/nodes and
    GET /nodes/{id}/children.  This prevents multi-MB responses when a node
    has hundreds of children each with large I/O payloads.
    """
    d = node.data or {}
    inputs = d.get("inputs") or {}
    outputs = d.get("outputs") or {}

    if not include_history:
        inputs = _strip_history(inputs)
        outputs = _strip_history(outputs)

    # Build children_map from the flat all_nodes list so _node_row_to_slim can
    # recurse without further DB queries.
    children_map: dict[int, list[RunNode]] = {}
    for n in all_nodes:
        if n.parent_node_id is not None:
            children_map.setdefault(n.parent_node_id, []).append(n)

    direct_children = children_map.get(node.id, [])
    children_count = len(direct_children)

    slim_children: list[WorkflowNodeSummary] = [
        _node_row_to_slim(c, children_map) for c in direct_children
    ]

    return WorkflowNodeRead(
        id=node.id,
        name=node.name or "",
        slug=node.slug,
        status=_status_str(node),
        inputs=inputs,
        outputs=outputs,
        duration_ms=node.duration_ms or 0,
        started_at=node.started_at,
        logs=d.get("logs"),
        child_run_id=node.child_run_id,
        children=slim_children,
        children_count=children_count,
    )


def _to_summary(
    run: WorkflowRun, cm: dict[int, list[WorkflowRun]], wf_names: dict[int, str]
) -> WorkflowRunSummary:
    d = run.data or {}
    return WorkflowRunSummary(
        id=run.id,
        name=wf_names.get(run.workflow_id, ""),
        status=run.status.value,
        triggered_by=(
            run.triggered_by.value
            if hasattr(run.triggered_by, "value")
            else run.triggered_by
        ),
        trigger_context=d.get("trigger_context", {}),
        inputs=d.get("inputs", {}),
        outputs=d.get("outputs", {}),
        logs=d.get("logs", []),
        started_at=run.started_at,
        finished_at=run.finished_at,
        created_at=run.created_at,
        parent_id=run.parent_id,
        children=[_to_summary(c, cm, wf_names) for c in cm.get(run.id, [])],
    )


# Columns that are sufficient for list/stats views — excludes the heavy `data` JSONB column.
# We include a slim JSON-path extract of table_action_context so the list endpoint
# can expose row_ids / table_id without loading the entire data payload.
_SLIM_COLS = (
    WorkflowRun.id,
    WorkflowRun.workflow_id,
    WorkflowRun.status,
    WorkflowRun.triggered_by,
    WorkflowRun.started_at,
    WorkflowRun.finished_at,
    WorkflowRun.created_at,
    WorkflowRun.parent_id,
    func.json_extract_path_text(
        WorkflowRun.data, "trigger_context", "table_action_context"
    ).label("tac_json"),
)


def _row_to_summary(
    row: Any, cm: dict[int, list[Any]], wf_names: dict[int, str]
) -> WorkflowRunSummary:
    st, tb = row.status, row.triggered_by
    tac_raw = getattr(row, "tac_json", None)
    tac: dict = {}
    if tac_raw:
        try:
            tac = json.loads(tac_raw)
        except (ValueError, TypeError):
            pass
    return WorkflowRunSummary(
        id=row.id,
        name=wf_names.get(row.workflow_id, ""),
        status=st.value if hasattr(st, "value") else st,
        triggered_by=tb.value if hasattr(tb, "value") else tb,
        trigger_context={},
        inputs={},
        outputs={},
        logs=[],
        started_at=row.started_at,
        finished_at=row.finished_at,
        created_at=row.created_at,
        parent_id=row.parent_id,
        row_ids=tac.get("row_ids") or None,
        table_id=tac.get("table_id"),
        children=[_row_to_summary(c, cm, wf_names) for c in cm.get(row.id, [])],
    )


def _build_summary_tree(
    rows: list[Any], wf_names: dict[int, str]
) -> list[WorkflowRunSummary]:
    cm: dict[int, list[Any]] = defaultdict(list)
    roots: list[Any] = []
    for r in rows:
        if r.parent_id:
            cm[r.parent_id].append(r)
        else:
            roots.append(r)
    return [_row_to_summary(r, cm, wf_names) for r in roots]


def _to_child(
    run: WorkflowRun, cm: dict[int, list[WorkflowRun]], wf_names: dict[int, str]
) -> WorkflowRunChild:
    """Minimal child-run entry embedded in a parent WorkflowRunRead."""
    st = run.status
    return WorkflowRunChild(
        id=run.id,
        name=wf_names.get(run.workflow_id, ""),
        status=st.value if hasattr(st, "value") else st,
        started_at=run.started_at,
        finished_at=run.finished_at,
        created_at=run.created_at,
        parent_id=run.parent_id,
        children=[_to_child(c, cm, wf_names) for c in cm.get(run.id, [])],
    )


def _run_to_read(
    run: WorkflowRun, cm: dict[int, list[WorkflowRun]], wf_names: dict[int, str]
) -> WorkflowRunRead:
    d = run.data or {}
    tac: dict = d.get("trigger_context", {}) or {}
    return WorkflowRunRead(
        id=run.id,
        name=wf_names.get(run.workflow_id, ""),
        status=run.status.value,
        triggered_by=(
            run.triggered_by.value
            if hasattr(run.triggered_by, "value")
            else run.triggered_by
        ),
        trigger_context=tac,
        inputs=d.get("inputs", {}),
        outputs=d.get("outputs", {}),
        logs=d.get("logs", []),
        started_at=run.started_at,
        finished_at=run.finished_at,
        created_at=run.created_at,
        parent_id=run.parent_id,
        row_ids=tac.get("row_ids") or None,
        table_id=tac.get("table_id"),
        actions=[],
        children=[_to_child(c, cm, wf_names) for c in cm.get(run.id, [])],
    )


def _build_tree(
    runs: list[WorkflowRun], wf_names: dict[int, str]
) -> list[WorkflowRunRead]:
    cm: dict[int, list[WorkflowRun]] = defaultdict(list)
    roots: list[WorkflowRun] = []
    for r in runs:
        if r.parent_id:
            cm[r.parent_id].append(r)
        else:
            roots.append(r)
    return [_run_to_read(r, cm, wf_names) for r in roots]
