from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Callable, Coroutine

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from ..database import get_session
from ..deps import get_current_user
from ..models import User, Workflow, WorkflowConfig, WorkflowRun, WorkflowStatus
from ..trigger_context import TriggerContext
from .schemas import (
    InputFieldDef,
    TableActionConfig,
    TableActionValidation,
    WorkflowConfigUpdate,
    WorkflowDefinitionRead,
    WorkflowTriggerRequest,
)


async def _build_workflow_definition(
    name: str,
    meta: dict,
    cfg: Workflow | None,
    session: AsyncSession,
) -> WorkflowDefinitionRead:
    wf = (await session.exec(select(Workflow).where(Workflow.name == name))).first()
    wf_id = wf.id if wf else None

    if wf_id is not None:
        total: int = (
            await session.execute(
                select(func.count(WorkflowRun.id)).where(
                    WorkflowRun.workflow_id == wf_id, WorkflowRun.parent_id == None
                )  # noqa: E711
            )
        ).scalar_one()

        failed: int = (
            await session.execute(
                select(func.count(WorkflowRun.id)).where(
                    WorkflowRun.workflow_id == wf_id,
                    WorkflowRun.parent_id == None,  # noqa: E711
                    WorkflowRun.status == WorkflowStatus.failed,
                )
            )
        ).scalar_one()

        last_run = (
            await session.exec(
                select(WorkflowRun)
                .where(
                    WorkflowRun.workflow_id == wf_id, WorkflowRun.parent_id == None
                )  # noqa: E711
                .order_by(WorkflowRun.created_at.desc())
                .limit(1)
            )
        ).first()
    else:
        total = 0
        failed = 0
        last_run = None

    recent_nodes: list[str] = []

    if last_run and last_run.data:
        all_actions = last_run.data.get("actions") or last_run.data.get("nodes", [])
        recent_nodes = [n["name"] for n in all_actions if n.get("status") != "pending"]

    table_action_raw = meta.get("table_action") or {}
    validation_raw = table_action_raw.get("validation") or []

    return WorkflowDefinitionRead(
        name=name,
        folder=meta.get("folder"),
        trigger_type=meta["trigger_type"],
        schedule=meta.get("schedule"),
        is_webhook=meta["is_webhook"],
        webhook_path=meta["webhook_path"],
        enabled=cfg.enabled if cfg else True,
        schedule_override=cfg.schedule_override if cfg else None,
        timeout_seconds=cfg.timeout_seconds if cfg else None,
        max_concurrent_runs=cfg.max_concurrent_runs if cfg else None,
        recent_nodes=recent_nodes,
        last_run_at=last_run.started_at if last_run else None,
        last_run_status=last_run.status.value if last_run else None,
        total_runs=total,
        failure_rate=round(failed / total, 4) if total > 0 else 0.0,
        input_schema=[InputFieldDef(**f) for f in meta.get("input_schema", [])],
        examples=meta.get("examples", []),
        description=meta.get("description"),
        how_it_works=meta.get("how_it_works"),
        output_example=meta.get("output_example"),
        table_action=TableActionConfig(
            enabled=table_action_raw.get("enabled", False),
            selected_only=table_action_raw.get("selected_only", False),
            validation=[
                TableActionValidation(
                    column_name=v["column_name"],
                    type=v["type"],
                    why_needed=v.get("why_needed", ""),
                )
                for v in validation_raw
            ],
        ),
    )


def create_workflows_router(
    workflow_meta: dict,
    invoke: Callable[..., Coroutine[Any, Any, Any]],
    wrappers: dict | None,
) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/workflows",
        response_model=list[WorkflowDefinitionRead],
        response_model_by_alias=True,
        tags=["workflows"],
    )
    async def list_workflow_definitions(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        cfgs: dict[str, Workflow] = {
            r.name: r for r in (await session.exec(select(Workflow))).all()
        }
        return [
            await _build_workflow_definition(name, meta, cfgs.get(name), session)
            for name, meta in workflow_meta.items()
        ]

    @router.get(
        "/workflows/{name}",
        response_model=WorkflowDefinitionRead,
        response_model_by_alias=True,
        tags=["workflows"],
    )
    async def get_workflow_definition(
        name: str,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        if name not in workflow_meta:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found"
            )
        cfg = (
            await session.exec(select(Workflow).where(Workflow.name == name))
        ).first()

        return await _build_workflow_definition(name, workflow_meta[name], cfg, session)

    @router.patch(
        "/workflows/{name}",
        response_model=WorkflowDefinitionRead,
        response_model_by_alias=True,
        tags=["workflows"],
    )
    async def update_workflow_config(
        name: str,
        body: WorkflowConfigUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        if name not in workflow_meta:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found"
            )
        cfg = (
            await session.exec(select(Workflow).where(Workflow.name == name))
        ).first()

        if cfg is None:
            cfg = Workflow(name=name)
            session.add(cfg)

        for field, value in body.model_dump(exclude_unset=True, by_alias=False).items():
            setattr(cfg, field, value)
        cfg.updated_at = datetime.now(timezone.utc)
        session.add(cfg)
        await session.commit()
        await session.refresh(cfg)

        if "max_concurrent_runs" in body.model_dump(exclude_unset=True, by_alias=False):
            from ..decorator import _ensure_drain_task, _notify_drain

            if wrappers and name in wrappers:
                raw_fn = getattr(wrappers[name], "_gtm_fn", wrappers[name])
                _ensure_drain_task(name, raw_fn)
                _notify_drain(name)

        return await _build_workflow_definition(name, workflow_meta[name], cfg, session)

    @router.post("/workflows/{name}/trigger", status_code=202, tags=["workflows"])
    async def trigger_workflow(
        name: str,
        body: WorkflowTriggerRequest,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        if name not in workflow_meta:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found"
            )
        cfg = (
            await session.exec(select(Workflow).where(Workflow.name == name))
        ).first()

        if cfg is not None and not cfg.enabled:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT, detail="Workflow is disabled"
            )
        metadata: dict = {}

        if body.table_action_context is not None:
            metadata["table_action_context"] = body.table_action_context.model_dump()
        ctx = TriggerContext("manual", body.inputs, metadata)
        await invoke(name, ctx)

        return {"status": "accepted"}

    return router
