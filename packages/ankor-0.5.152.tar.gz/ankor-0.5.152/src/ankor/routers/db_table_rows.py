"""Row CRUD endpoints for data tables."""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import text
from sqlmodel.ext.asyncio.session import AsyncSession

from ..broadcast import manager
from ..database import get_session
from ..db_helpers import (
    _coerce_for_write,
    _get_column_names,
    _normalize_row,
    _pg_table,
    _qi,
    _read_col_types,
    _read_columns,
    _upsert_row,
)
from ..deps import get_current_user
from ..models import DataTable, User
from .schemas import DbRowsPage

_MAX_PAGE_SIZE = 1000


def _build_mui_filter_sql(
    filter_items: list[dict],
    logic: str,
    col_types: dict[str, str],
) -> tuple[str, dict]:
    """Translate a MUI DataGrid filter model into a SQL WHERE clause fragment."""
    _SYSTEM_COLS = {
        "id": "integer",
        "created_at": "date",
        "updated_at": "date",
        "history": "json",
    }
    if not filter_items:
        return "", {}
    parts: list[str] = []
    params: dict[str, Any] = {}
    for i, item in enumerate(filter_items):
        field = item.get("field", "")
        operator = item.get("operator", "")
        value = item.get("value")
        if not field or not operator:
            continue
        col_type = col_types.get(field) or _SYSTEM_COLS.get(field)
        if col_type is None:
            continue  # unknown field — skip to prevent injection
        qi = _qi(field)
        p = f"fp{i}"
        clause = _mui_filter_clause(qi, operator, value, col_type, p, params)
        if clause:
            parts.append(f"({clause})")
    if not parts:
        return "", {}
    connector = " OR " if logic.lower() == "or" else " AND "
    return " WHERE " + connector.join(parts), params


def _mui_filter_clause(
    qi: str, operator: str, value: Any, col_type: str, p: str, params: dict
) -> str | None:
    if operator == "isEmpty":
        return f"{qi} IS NULL OR CAST({qi} AS TEXT) = ''"
    if operator == "isNotEmpty":
        return f"{qi} IS NOT NULL AND CAST({qi} AS TEXT) != ''"
    if col_type in ("integer", "float"):
        cast = "BIGINT" if col_type == "integer" else "DOUBLE PRECISION"
        if operator == "isAnyOf" and isinstance(value, list) and value:
            keys = [f"{p}_{j}" for j in range(len(value))]
            cast_fn = int if col_type == "integer" else float
            params.update({k: cast_fn(v) for k, v in zip(keys, value)})
            return f"CAST({qi} AS {cast}) IN ({', '.join(':' + k for k in keys)})"
        if value is None:
            return None
        try:
            num = int(value) if col_type == "integer" else float(value)
        except (ValueError, TypeError):
            return None
        params[p] = num
        op_map = {"=": "=", "!=": "!=", ">": ">", ">=": ">=", "<": "<", "<=": "<="}
        sql_op = op_map.get(operator)
        return f"CAST({qi} AS {cast}) {sql_op} :{p}" if sql_op else None
    if col_type == "boolean":
        if operator == "is":
            params[p] = value is True or value == "true"
            return f"{qi} = :{p}"
        return None
    if col_type == "date":
        if not value:
            return None
        params[p] = str(value)
        date_ops = {
            "is": "=",
            "not": "!=",
            "after": ">",
            "onOrAfter": ">=",
            "before": "<",
            "onOrBefore": "<=",
        }
        sql_op = date_ops.get(operator)
        return f"CAST({qi} AS DATE) {sql_op} CAST(:{p} AS DATE)" if sql_op else None
    # text / select / json — cast to text for string ops
    if operator == "isAnyOf" and isinstance(value, list) and value:
        keys = [f"{p}_{j}" for j in range(len(value))]
        params.update({k: str(v) for k, v in zip(keys, value)})
        return f"LOWER(CAST({qi} AS TEXT)) IN ({', '.join('LOWER(:' + k + ')' for k in keys)})"
    if not value:
        return None
    str_val = str(value)
    if operator == "contains":
        params[p] = f"%{str_val}%"
        return f"CAST({qi} AS TEXT) ILIKE :{p}"
    if operator == "notContains":
        params[p] = f"%{str_val}%"
        return f"CAST({qi} AS TEXT) NOT ILIKE :{p}"
    if operator == "equals" or operator == "is":
        params[p] = str_val
        return f"LOWER(CAST({qi} AS TEXT)) = LOWER(:{p})"
    if operator == "notEquals" or operator == "not":
        params[p] = str_val
        return f"LOWER(CAST({qi} AS TEXT)) != LOWER(:{p})"
    if operator == "startsWith":
        params[p] = f"{str_val}%"
        return f"CAST({qi} AS TEXT) ILIKE :{p}"
    if operator == "endsWith":
        params[p] = f"%{str_val}"
        return f"CAST({qi} AS TEXT) ILIKE :{p}"
    return None


def create_rows_router() -> APIRouter:
    router = APIRouter()

    @router.get(
        "/db-tables/{id}/rows",
        response_model=DbRowsPage,
        response_model_by_alias=True,
        tags=["db-tables"],
    )
    async def get_db_table_rows(
        id: int,
        page: int = 0,
        page_size: int = 100,
        filter: str | None = None,
        filter_logic: str = "and",
        sort_by: str | None = None,
        sort_dir: str = "asc",
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        page = max(0, page)
        page_size = max(1, min(page_size, _MAX_PAGE_SIZE))
        tbl = _pg_table(id)
        columns = await _read_columns(session, id)
        col_types = {c["id"]: c["type"] for c in columns}
        filter_items: list[dict] = []
        if filter:
            try:
                filter_items = json.loads(filter)
            except (ValueError, TypeError):
                raise HTTPException(status_code=422, detail="Invalid filter JSON")
        where_sql, params = _build_mui_filter_sql(filter_items, filter_logic, col_types)
        total: int = (
            await session.scalar(text(f"SELECT COUNT(*) FROM {tbl}{where_sql}"), params)
        ) or 0
        # Exclude JSON columns from the list query — they can be very large.
        # A NULL placeholder is returned instead; the full value is only fetched
        # when a single row is opened for editing.
        json_col_ids = {c["id"] for c in columns if c["type"] == "json"}
        system_col_ids = ["id", "created_at", "updated_at", "history"]
        col_select = ", ".join(
            "NULL" if col_id in json_col_ids else _qi(col_id)
            for col_id in [
                *system_col_ids,
                *[c["id"] for c in columns],
            ]
        )
        # Build ORDER BY — validate sort_by against known columns to prevent injection.
        _allowed_sort_cols = {c["id"] for c in columns} | {
            "id",
            "created_at",
            "updated_at",
        }
        if sort_by and sort_by in _allowed_sort_cols:
            _dir = "DESC" if sort_dir.lower() == "desc" else "ASC"
            order_sql = f"ORDER BY {_qi(sort_by)} {_dir} NULLS LAST"
        else:
            order_sql = "ORDER BY id"
        result = await session.execute(
            text(
                f"SELECT {col_select} FROM {tbl}{where_sql} {order_sql} LIMIT :lim OFFSET :off"
            ),
            {**params, "lim": page_size, "off": page * page_size},
        )
        col_names = [*system_col_ids, *[c["id"] for c in columns]]
        rows = [_normalize_row(dict(zip(col_names, r)), col_types) for r in result]
        return DbRowsPage(rows=rows, total=total)

    @router.post(
        "/db-tables/{id}/rows", status_code=status.HTTP_201_CREATED, tags=["db-tables"]
    )
    async def add_db_table_row(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        col_ids = await _get_column_names(session, tbl)
        col_types = await _read_col_types(session, tbl)
        max_id: int = (
            await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))
        ) or 0
        new_id = max_id + 1
        await _upsert_row(session, tbl, {"id": new_id}, col_ids)
        await session.commit()
        await manager.broadcast(f"table:{id}", {"type": "rows_changed"})
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": new_id}
        )
        row = result.first()
        return _normalize_row(row._mapping, col_types)

    @router.get("/db-tables/{id}/rows/{row_id}", tags=["db-tables"])
    async def get_db_table_row(
        id: int,
        row_id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        col_types = await _read_col_types(session, tbl)
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        row = result.first()
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Row not found"
            )
        return _normalize_row(row._mapping, col_types)

    @router.patch("/db-tables/{id}/rows/{row_id}", tags=["db-tables"])
    async def update_db_table_row(
        id: int,
        row_id: int,
        body: dict[str, Any],
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        col_ids = await _get_column_names(session, tbl)
        col_types = await _read_col_types(session, tbl)
        existing = await session.execute(
            text(f"SELECT id FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        if not existing.first():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Row not found"
            )
        coerced = {
            k: _coerce_for_write(v, col_types.get(k, "text")) for k, v in body.items()
        }
        await _upsert_row(session, tbl, {**coerced, "id": row_id}, col_ids)
        await session.commit()
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        row = result.first()
        normalized = _normalize_row(row._mapping, col_types)
        json_col_ids = {k for k, v in col_types.items() if v == "json"}
        broadcast_row = {k: v for k, v in normalized.items() if k not in json_col_ids}
        await manager.broadcast(
            f"table:{id}", {"type": "row_updated", "row": broadcast_row}
        )
        return normalized

    @router.post(
        "/db-tables/{id}/rows/{row_id}/restore/{history_index}", tags=["db-tables"]
    )
    async def restore_db_table_row(
        id: int,
        row_id: int,
        history_index: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        """Restore a row to the state recorded at *history_index* and clear all history."""
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        col_types = await _read_col_types(session, tbl)
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        row = result.first()
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Row not found"
            )
        row_dict = _normalize_row(row._mapping, col_types)
        history: list[dict] = row_dict.get("history") or []
        if history_index < 0 or history_index >= len(history):
            raise HTTPException(status_code=422, detail="history_index out of range")
        # Find the state from the first row_update action in this history item.
        history_item = history[history_index]
        state: dict | None = None
        for action in history_item.get("actions") or []:
            if action.get("type") == "row_update":
                state = action.get("state") or {}
                break
        if state is None:
            raise HTTPException(
                status_code=422,
                detail="No restorable row state found in this history item.",
            )
        update_data = {
            k: _coerce_for_write(v, col_types.get(k, "text"))
            for k, v in state.items()
            if k in col_types
        }
        params: dict[str, Any] = {"row_id": row_id}
        set_clauses = ["history = '[]'::jsonb", "updated_at = NOW()"]
        for i, (k, v) in enumerate(update_data.items()):
            set_clauses.append(f"{_qi(k)} = :v{i}")
            params[f"v{i}"] = v
        await session.execute(
            text(f"UPDATE {tbl} SET {', '.join(set_clauses)} WHERE id = :row_id"),
            params,
        )
        await session.commit()
        result = await session.execute(
            text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
        )
        updated = result.first()
        normalized = _normalize_row(updated._mapping, col_types)
        json_col_ids = {k for k, v in col_types.items() if v == "json"}
        broadcast_row = {k: v for k, v in normalized.items() if k not in json_col_ids}
        await manager.broadcast(
            f"table:{id}", {"type": "row_updated", "row": broadcast_row}
        )
        return normalized

    @router.delete(
        "/db-tables/{id}/rows",
        status_code=status.HTTP_204_NO_CONTENT,
        tags=["db-tables"],
    )
    async def delete_db_table_rows(
        id: int,
        ids: str,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        try:
            row_ids = [int(i.strip()) for i in ids.split(",") if i.strip()]
        except ValueError:
            raise HTTPException(
                status_code=422, detail="ids must be a comma-separated list of integers"
            )
        if row_ids:
            id_list = ", ".join(str(i) for i in row_ids)
            await session.execute(
                text(f"DELETE FROM {_pg_table(id)} WHERE id IN ({id_list})")
            )
            await session.commit()
            await manager.broadcast(f"table:{id}", {"type": "rows_changed"})

    @router.delete(
        "/db-tables/{id}/rows/history",
        status_code=status.HTTP_204_NO_CONTENT,
        tags=["db-tables"],
    )
    async def clear_db_table_rows_history(
        id: int,
        ids: str,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        """Clear the history column for the specified rows (comma-separated ids)."""
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        try:
            row_ids = [int(i.strip()) for i in ids.split(",") if i.strip()]
        except ValueError:
            raise HTTPException(
                status_code=422, detail="ids must be a comma-separated list of integers"
            )
        if row_ids:
            tbl = _pg_table(id)
            id_list = ", ".join(str(i) for i in row_ids)
            await session.execute(
                text(f"UPDATE {tbl} SET history = '[]'::jsonb WHERE id IN ({id_list})")
            )
            await session.commit()
            await manager.broadcast(f"table:{id}", {"type": "rows_changed"})

    return router
