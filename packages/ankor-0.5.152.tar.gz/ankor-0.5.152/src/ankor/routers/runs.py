from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Callable, Coroutine

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy import (
    BigInteger,
    Text,
    and_,
    cast,
    func,
    literal_column,
    nullslast,
    or_,
)
from sqlalchemy.orm import defer
from sqlalchemy import text as sa_text
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from ..broadcast import manager
from ..database import get_session
from ..decorator import _running_tasks, _ws_run_list_event, _ws_run_status
from ..deps import get_current_user
from ..models import RunNode, User, Workflow, WorkflowRun, WorkflowStatus
from ..trigger_context import TriggerContext
from .schemas import (
    WorkflowNodeRead,
    WorkflowNodeSummary,
    WorkflowRunChild,
    WorkflowRunRead,
    WorkflowRunSummary,
    WorkflowStats,
)


from .run_helpers import (
    _SLIM_COLS,
    _build_summary_tree,
    _build_tree,
    _node_row_to_full,
    _node_row_to_slim,
    _row_to_summary,
    _run_to_read,
    _status_str,
    _to_child,
    _to_summary,
)

_SUBTREE_CTE = """
    WITH RECURSIVE subtree AS (
        SELECT id FROM run_nodes WHERE id = :node_id
        UNION ALL
        SELECT rn.id FROM run_nodes rn JOIN subtree s ON rn.parent_node_id = s.id
    )
    SELECT id FROM subtree
"""


def create_runs_router(invoke: Callable[..., Coroutine[Any, Any, Any]]) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/workflow-runs/stats",
        response_model=WorkflowStats,
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def get_workflow_stats(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        raw = await session.execute(
            select(WorkflowRun.status, func.count(WorkflowRun.id)).group_by(
                WorkflowRun.status
            )
        )
        counts: dict[str, int] = {
            (s.value if hasattr(s, "value") else str(s)): c for s, c in raw.all()
        }
        for s in WorkflowStatus:
            counts.setdefault(s.value, 0)

        active_rows = (
            await session.execute(
                select(*_SLIM_COLS).where(WorkflowRun.status == WorkflowStatus.running)
            )
        ).all()

        recent_rows = (
            await session.execute(
                select(*_SLIM_COLS)
                .where(WorkflowRun.status != WorkflowStatus.running)
                .order_by(WorkflowRun.created_at.desc())
                .limit(5)
            )
        ).all()

        wf_ids = {r.workflow_id for r in list(active_rows) + list(recent_rows)}
        wf_entries = (
            (await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))).all()
            if wf_ids
            else []
        )
        wf_names = {w.id: w.name for w in wf_entries}

        return WorkflowStats(
            counts=counts,
            active=[_row_to_summary(r, {}, wf_names) for r in active_rows],
            recent=[_row_to_summary(r, {}, wf_names) for r in recent_rows],
        )

    @router.get(
        "/workflow-runs",
        response_model=list[WorkflowRunSummary],
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def list_workflow_runs(
        fastapi_response: Response,
        offset: int = 0,
        limit: int = 50,
        search: str = "",
        status: list[str] = Query(default=[]),
        workflow_name: list[str] = Query(default=[]),
        date_from: datetime | None = None,
        date_to: datetime | None = None,
        triggered_by: list[str] = Query(default=[]),
        original_run_id: str | None = None,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        conds = [WorkflowRun.parent_id == None]  # noqa: E711
        if search:
            conds.append(
                or_(
                    WorkflowRun.workflow_id.in_(
                        select(Workflow.id).where(Workflow.name.ilike(f"%{search}%"))
                    ),
                    cast(WorkflowRun.id, Text).ilike(f"%{search}%"),
                    literal_column("workflow_runs.data::text").ilike(f"%{search}%"),
                    WorkflowRun.id.in_(
                        select(RunNode.run_id).where(
                            literal_column("run_nodes.data::text").ilike(f"%{search}%")
                        )
                    ),
                )
            )
        if status:
            conds.append(WorkflowRun.status.in_(status))  # type: ignore[arg-type]
        if workflow_name:
            conds.append(
                WorkflowRun.workflow_id.in_(
                    select(Workflow.id).where(Workflow.name.in_(workflow_name))
                )
            )
        if date_from:
            conds.append(WorkflowRun.created_at >= date_from)
        if date_to:
            conds.append(WorkflowRun.created_at <= date_to)
        if triggered_by:
            conds.append(WorkflowRun.triggered_by.in_(triggered_by))
        if original_run_id:
            # Handle both camelCase (current) and snake_case (legacy) key names
            conds.append(
                or_(
                    func.json_extract_path_text(
                        WorkflowRun.data, "trigger_context", "originalRunId"
                    )
                    == original_run_id,
                    func.json_extract_path_text(
                        WorkflowRun.data, "trigger_context", "original_run_id"
                    )
                    == original_run_id,
                )
            )
        where = and_(*conds)

        total = (
            await session.execute(select(func.count(WorkflowRun.id)).where(where))
        ).scalar_one()
        fastapi_response.headers["X-Total-Count"] = str(total)

        roots = (
            await session.execute(
                select(*_SLIM_COLS)
                .where(where)
                .order_by(WorkflowRun.created_at.desc(), WorkflowRun.id.desc())
                .offset(offset)
                .limit(limit)
            )
        ).all()

        if not roots:
            return []

        root_ids = [r.id for r in roots]
        children = (
            await session.execute(
                select(*_SLIM_COLS).where(WorkflowRun.parent_id.in_(root_ids))
            )
        ).all()

        grandchildren: list[Any] = []
        if children:
            child_ids = [c.id for c in children]
            grandchildren = (
                await session.execute(
                    select(*_SLIM_COLS).where(WorkflowRun.parent_id.in_(child_ids))
                )
            ).all()

        all_rows = list(roots) + list(children) + list(grandchildren)
        wf_ids = {r.workflow_id for r in all_rows}
        wf_entries = (
            await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))
        ).all()
        wf_names = {w.id: w.name for w in wf_entries}

        return _build_summary_tree(all_rows, wf_names)

    @router.get(
        "/workflow-runs/{id}",
        response_model=WorkflowRunRead,
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def get_workflow_run(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found"
            )

        children = list(
            (
                await session.exec(
                    select(WorkflowRun)
                    .where(WorkflowRun.parent_id == id)
                    .options(defer(WorkflowRun.data))
                )
            ).all()
        )
        grandchildren: list[WorkflowRun] = []
        if children:
            child_ids = [c.id for c in children]
            grandchildren = list(
                (
                    await session.exec(
                        select(WorkflowRun)
                        .where(WorkflowRun.parent_id.in_(child_ids))
                        .options(defer(WorkflowRun.data))
                    )
                ).all()
            )

        cm: dict[int, list[WorkflowRun]] = defaultdict(list)
        for r in children + grandchildren:
            cm[r.parent_id].append(r)

        wf_ids = {run.workflow_id} | {r.workflow_id for r in children + grandchildren}
        wf_entries = (
            await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))
        ).all()
        wf_names = {w.id: w.name for w in wf_entries}

        return _run_to_read(run, cm, wf_names)

    @router.get(
        "/workflow-runs/{id}/nodes",
        response_model=list[WorkflowNodeSummary],
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def get_workflow_run_nodes(
        id: int,
        max_depth: int = 2,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run_id = (
            await session.execute(select(WorkflowRun.id).where(WorkflowRun.id == id))
        ).scalar_one_or_none()
        if run_id is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found"
            )
        # BFS: collect nodes for the root run and all nested sub-workflow runs.
        all_nodes: list[RunNode] = []
        visited_runs: set[int] = {id}
        queue: list[int] = [id]

        while queue:
            batch = list(
                (
                    await session.execute(
                        select(RunNode)
                        .where(RunNode.run_id.in_(queue))
                        .options(defer(RunNode.data))
                        .order_by(RunNode.id)
                    )
                )
                .scalars()
                .all()
            )
            all_nodes.extend(batch)
            new_run_ids = [
                n.child_run_id
                for n in batch
                if n.child_run_id and n.child_run_id not in visited_runs
            ]

            for rid in new_run_ids:
                visited_runs.add(rid)

            queue = list(dict.fromkeys(new_run_ids))

        children_map: dict[int, list[RunNode]] = defaultdict(list)
        run_roots_map: dict[int, list[RunNode]] = defaultdict(list)

        for n in all_nodes:
            if n.parent_node_id is not None:
                children_map[n.parent_node_id].append(n)
            else:
                run_roots_map[n.run_id].append(n)

        roots = run_roots_map[id]
        return [
            _node_row_to_slim(n, children_map, run_roots_map, max_depth=max_depth)
            for n in roots
        ]

    @router.get(
        "/nodes/{id}",
        response_model=WorkflowNodeRead,
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def get_node(
        id: int,
        include_history: bool = True,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        node = await session.get(RunNode, id)
        if not node:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Node not found"
            )
        # Use a recursive CTE to fetch only the node's own subtree, not all
        # siblings in the same run. For large workflows (e.g. 2k-row bulk runs)
        # this avoids loading thousands of unrelated RunNode rows.
        subtree_ids = [
            row[0]
            for row in (
                await session.execute(sa_text(_SUBTREE_CTE), {"node_id": id})
            ).all()
        ]
        all_nodes = list(
            (
                await session.exec(
                    select(RunNode)
                    .where(RunNode.id.in_(subtree_ids))
                    .order_by(nullslast(RunNode.started_at), RunNode.id)
                )
            ).all()
        )
        return _node_row_to_full(node, all_nodes, include_history=include_history)

    @router.get(
        "/nodes/{id}/children",
        response_model=list[WorkflowNodeSummary],
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def get_node_children(
        id: int,
        limit: int = 100,
        offset: int = 0,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        """Return the immediate children of a node as slim summaries.

        Used by the frontend to lazily expand depth-truncated tree nodes.
        Each returned summary includes children_count so the UI can show
        further expand buttons without another round-trip.

        offset supports pagination: pass offset=N to skip the first N children.
        """

        node = await session.get(RunNode, id)
        if not node:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Node not found"
            )
        direct = list(
            (
                await session.execute(
                    select(RunNode)
                    .where(RunNode.parent_node_id == id)
                    .options(defer(RunNode.data))
                    .order_by(RunNode.id)
                )
            )
            .scalars()
            .all()
        )
        sub_roots: list[RunNode] = []

        if node.child_run_id:
            sub_roots = list(
                (
                    await session.execute(
                        select(RunNode)
                        .where(
                            RunNode.run_id == node.child_run_id,
                            RunNode.parent_node_id == None,  # noqa: E711
                        )
                        .options(defer(RunNode.data))
                        .order_by(RunNode.id)
                    )
                )
                .scalars()
                .all()
            )

        all_children = direct + sub_roots

        if not all_children:
            return []

        all_children = all_children[offset : offset + limit]

        if not all_children:
            return []

        child_ids = [c.id for c in all_children]
        grandchild_counts: dict[int, int] = dict(
            (
                await session.execute(
                    select(RunNode.parent_node_id, func.count(RunNode.id))
                    .where(RunNode.parent_node_id.in_(child_ids))
                    .group_by(RunNode.parent_node_id)
                )
            ).all()
        )

        result: list[WorkflowNodeSummary] = []

        for c in all_children:
            result.append(
                WorkflowNodeSummary(
                    id=c.id,
                    name=c.name or "",
                    slug=c.slug,
                    status=_status_str(c),
                    duration_ms=c.duration_ms or 0,
                    started_at=c.started_at,
                    child_run_id=c.child_run_id,
                    children=[],
                    children_count=grandchild_counts.get(c.id, 0),
                )
            )

        return result

    @router.post("/workflow-runs/{id}/rerun", status_code=202, tags=["workflow-runs"])
    async def rerun_workflow_run(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found"
            )

        stored = (run.data or {}).get("trigger_context") or {}
        if not stored:
            stored = {
                "type": (
                    run.triggered_by.value
                    if hasattr(run.triggered_by, "value")
                    else run.triggered_by
                ),
                "inputs": {},
            }
        original_ctx = TriggerContext.from_db(stored)
        rerun_ctx = TriggerContext(
            type="rerun",
            inputs=original_ctx.inputs,
            metadata={
                **original_ctx.metadata,
                "originalType": original_ctx.type,
                "originalRunId": str(id),
            },
        )

        wf = await session.get(Workflow, run.workflow_id)
        workflow_name = wf.name if wf else ""
        try:
            await invoke(workflow_name, rerun_ctx)
        except KeyError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Workflow '{workflow_name}' is not registered in this process",
            )

        return {"status": "accepted"}

    @router.post("/workflow-runs/{id}/cancel", status_code=200, tags=["workflow-runs"])
    async def cancel_workflow_run(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found"
            )
        if run.status not in (WorkflowStatus.pending, WorkflowStatus.running):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Run is already in a terminal state",
            )

        wf = await session.get(Workflow, run.workflow_id)
        workflow_name = wf.name if wf else ""

        run.status = WorkflowStatus.cancelled
        run.finished_at = datetime.now(timezone.utc)
        session.add(run)
        await session.commit()

        await manager.broadcast(
            "workflow_list",
            {"type": "run_updated", "data": _ws_run_list_event(run, workflow_name)},
        )
        await manager.broadcast(
            f"workflow_detail:{run.id}",
            {"type": "run_updated", "data": _ws_run_status(run)},
        )

        live_task = _running_tasks.get(id)
        if live_task is not None and not live_task.done():
            live_task.cancel()

        return {"status": "cancelled"}

    @router.post(
        "/workflow-runs/cancel-pending", status_code=200, tags=["workflow-runs"]
    )
    async def cancel_pending_runs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        pending = list(
            (
                await session.exec(
                    select(WorkflowRun).where(
                        WorkflowRun.status == WorkflowStatus.pending
                    )
                )
            ).all()
        )

        if not pending:
            return {"cancelled": 0}

        wf_ids = {r.workflow_id for r in pending}
        wf_entries = (
            await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))
        ).all()
        wf_names = {w.id: w.name for w in wf_entries}

        now = datetime.now(timezone.utc)
        for run in pending:
            run.status = WorkflowStatus.cancelled
            run.finished_at = now
            session.add(run)

        await session.commit()

        for run in pending:
            name = wf_names.get(run.workflow_id, "")
            await manager.broadcast(
                "workflow_list",
                {"type": "run_updated", "data": _ws_run_list_event(run, name)},
            )
            await manager.broadcast(
                f"workflow_detail:{run.id}",
                {"type": "run_updated", "data": _ws_run_status(run)},
            )

        return {"cancelled": len(pending)}

    @router.post("/workflow-runs/cancel-all", status_code=200, tags=["workflow-runs"])
    async def cancel_all_runs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        """Cancel all pending and running (root-level) workflow runs."""
        runs = list(
            (
                await session.exec(
                    select(WorkflowRun).where(
                        WorkflowRun.status.in_(
                            [WorkflowStatus.pending, WorkflowStatus.running]
                        ),
                        WorkflowRun.parent_id == None,  # noqa: E711
                    )
                )
            ).all()
        )

        if not runs:
            return {"cancelled": 0}

        wf_ids = {r.workflow_id for r in runs}
        wf_entries = (
            await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))
        ).all()
        wf_names = {w.id: w.name for w in wf_entries}

        now = datetime.now(timezone.utc)
        for run in runs:
            run.status = WorkflowStatus.cancelled
            run.finished_at = now
            session.add(run)

        await session.commit()

        for run in runs:
            name = wf_names.get(run.workflow_id, "")
            await manager.broadcast(
                "workflow_list",
                {"type": "run_updated", "data": _ws_run_list_event(run, name)},
            )
            await manager.broadcast(
                f"workflow_detail:{run.id}",
                {"type": "run_updated", "data": _ws_run_status(run)},
            )
            live_task = _running_tasks.get(run.id)
            if live_task is not None and not live_task.done():
                live_task.cancel()

        return {"cancelled": len(runs)}

    @router.get(
        "/execution-buckets", response_model=list[dict], tags=["execution-buckets"]
    )
    async def get_execution_buckets(
        from_ms: int = Query(..., alias="from"),
        to_ms: int = Query(..., alias="to"),
        step_ms: int = Query(..., alias="step"),
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        dt_from = datetime.fromtimestamp(from_ms / 1000, tz=timezone.utc)
        dt_to = datetime.fromtimestamp(to_ms / 1000, tz=timezone.utc)
        step_secs = step_ms / 1000

        # Push bucketing into the DB — avoids loading any row data into Python.
        slot_expr = (
            func.floor(func.extract("epoch", WorkflowRun.started_at) / step_secs)
            * step_secs
            * 1000
        ).cast(BigInteger)

        rows = (
            await session.execute(
                select(
                    slot_expr.label("slot"),
                    func.count().label("y"),
                    func.bool_or(WorkflowRun.status == WorkflowStatus.failed).label(
                        "has_failed"
                    ),
                )
                .where(
                    WorkflowRun.started_at.is_not(None),
                    WorkflowRun.started_at >= dt_from,
                    WorkflowRun.started_at <= dt_to,
                )
                .group_by(slot_expr)
                .order_by(slot_expr)
            )
        ).all()

        # Index non-empty buckets then fill the full range (so the chart has a
        # continuous series with zero-count buckets).
        filled: dict[int, dict] = {
            int(r.slot): {"x": int(r.slot), "y": r.y, "hasFailed": r.has_failed}
            for r in rows
        }
        output = []
        slot = (from_ms // step_ms) * step_ms
        last = (to_ms // step_ms) * step_ms
        while slot <= last:
            output.append(filled.get(slot, {"x": slot, "y": 0, "hasFailed": False}))
            slot += step_ms
        return output

    return router
