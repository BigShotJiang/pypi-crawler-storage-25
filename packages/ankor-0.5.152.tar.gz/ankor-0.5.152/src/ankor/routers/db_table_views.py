"""View management endpoints for data tables."""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel.ext.asyncio.session import AsyncSession

from ..database import get_session
from ..deps import get_current_user
from ..models import DataTable, User
from .schemas import DbTableView, DbTableViewCreate, DbTableViewsReorder


def create_views_router() -> APIRouter:
    router = APIRouter()

    @router.post(
        "/db-tables/{id}/views",
        response_model=DbTableView,
        response_model_by_alias=True,
        status_code=status.HTTP_201_CREATED,
        tags=["db-tables"],
    )
    async def create_db_table_view(
        id: int,
        body: DbTableViewCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        existing: list[dict] = list(t.views or [])
        if any(v.get("name") == body.name for v in existing):
            raise HTTPException(
                status_code=409,
                detail=f"A view named '{body.name}' already exists.",
            )
        new_view = DbTableView(
            id=str(uuid4()),
            name=body.name,
            filter_model=body.filter_model,
        )
        existing.append(new_view.model_dump(by_alias=False))
        t.views = existing
        t.updated_at = datetime.now(timezone.utc)
        await session.commit()
        return new_view

    @router.delete(
        "/db-tables/{id}/views/{view_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        tags=["db-tables"],
    )
    async def delete_db_table_view(
        id: int,
        view_id: str,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        t.views = [v for v in (t.views or []) if v.get("id") != view_id]
        t.updated_at = datetime.now(timezone.utc)
        await session.commit()

    @router.patch(
        "/db-tables/{id}/views/{view_id}",
        response_model=DbTableView,
        response_model_by_alias=True,
        tags=["db-tables"],
    )
    async def update_db_table_view(
        id: int,
        view_id: str,
        body: DbTableViewCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        views: list[dict] = list(t.views or [])
        idx = next((i for i, v in enumerate(views) if v.get("id") == view_id), None)
        if idx is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="View not found"
            )
        updated_view = DbTableView(
            id=view_id,
            name=body.name,
            filter_model=body.filter_model,
        )
        views[idx] = updated_view.model_dump(by_alias=False)
        t.views = views
        t.updated_at = datetime.now(timezone.utc)
        await session.commit()
        return updated_view

    @router.put(
        "/db-tables/{id}/views/reorder",
        status_code=status.HTTP_204_NO_CONTENT,
        tags=["db-tables"],
    )
    async def reorder_db_table_views(
        id: int,
        body: DbTableViewsReorder,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        views_by_id = {v["id"]: v for v in (t.views or [])}
        t.views = [views_by_id[vid] for vid in body.ids if vid in views_by_id]
        t.updated_at = datetime.now(timezone.utc)
        await session.commit()

    return router
