"""Table management endpoints (CRUD for tables and columns).

Row, view, and CSV operations live in their respective sub-modules:
- :mod:`db_table_rows`  — row CRUD
- :mod:`db_table_views` — view management
- :mod:`db_table_csv`   — CSV import/export
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import text
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from ..broadcast import manager
from ..database import get_session
from ..db_helpers import (
    _get_column_names,
    _normalize_row,
    _normalize_select_opts,
    _pg_table,
    _PG_TYPE_MAP,
    _qi,
    _read_columns,
    _upsert_row,
)
from ..deps import get_current_user
from ..models import DataTable, User
from .db_table_csv import create_csv_router
from .db_table_rows import create_rows_router
from .db_table_views import create_views_router
from .schemas import (
    DbTableCreate,
    DbTableRead,
    DbTableUpdate,
    DbTableView,
    DbAddColumnsRequest,
)

_VALID_COL_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,62}$")
_RESERVED_COL_NAMES = frozenset({"id", "history"})


def _validate_column_id(col_id: str) -> None:
    """Raise 422 if col_id is empty, reserved, or not a valid PostgreSQL identifier."""
    if not col_id or not col_id.strip():
        raise HTTPException(status_code=422, detail="Column name cannot be empty.")
    if col_id in _RESERVED_COL_NAMES:
        raise HTTPException(
            status_code=422, detail=f"Column name '{col_id}' is reserved."
        )
    if not _VALID_COL_NAME.match(col_id):
        raise HTTPException(
            status_code=422,
            detail=(
                f"Column name '{col_id}' is invalid. Use only letters, digits, and underscores, "
                "starting with a letter or underscore (max 63 characters)."
            ),
        )


async def _tbl_read(
    t: DataTable, session: AsyncSession, include_rows: bool = True
) -> DbTableRead:
    columns = await _read_columns(session, t.id)
    rows: list[dict] = []
    if include_rows:
        tbl = _pg_table(t.id)
        col_types = {c["id"]: c["type"] for c in columns}
        result = await session.execute(text(f"SELECT * FROM {tbl} ORDER BY id"))
        rows = [_normalize_row(r._mapping, col_types) for r in result]
    views = [DbTableView(**v) for v in (t.views or [])]
    return DbTableRead(
        id=t.id,
        name=t.name,
        description=t.description,
        actions=t.actions,
        views=views,
        columns=columns,
        rows=rows,
        created_at=t.created_at,
        updated_at=t.updated_at,
    )


def create_db_tables_router() -> APIRouter:
    router = APIRouter()

    @router.get(
        "/db-tables",
        response_model=list[DbTableRead],
        response_model_by_alias=True,
        tags=["db-tables"],
    )
    async def list_db_tables(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        tables = (await session.exec(select(DataTable))).all()
        return [await _tbl_read(t, session, include_rows=False) for t in tables]

    @router.post(
        "/db-tables",
        response_model=DbTableRead,
        response_model_by_alias=True,
        status_code=status.HTTP_201_CREATED,
        tags=["db-tables"],
    )
    async def create_db_table(
        body: DbTableCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        seen_ids: set[str] = set()
        for col in body.columns or []:
            col_id = col.get("id", "")
            _validate_column_id(col_id)
            if col_id in seen_ids:
                raise HTTPException(
                    status_code=422, detail=f"Duplicate column name '{col_id}'."
                )
            seen_ids.add(col_id)

        existing_name = (
            await session.exec(select(DataTable).where(DataTable.name == body.name))
        ).first()
        if existing_name:
            raise HTTPException(
                status_code=409, detail=f"A table named '{body.name}' already exists."
            )

        t = DataTable(
            name=body.name, description=body.description, actions=body.actions
        )
        session.add(t)
        await session.flush()
        tbl = _pg_table(t.id)
        col_defs = [
            "id INTEGER NOT NULL",
            "history JSONB NOT NULL DEFAULT '[]'",
            "created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
            "updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
        ] + [
            f"{_qi(col['id'])} {_PG_TYPE_MAP.get(col.get('type', 'text'), 'TEXT')}"
            for col in (body.columns or [])
        ]
        await session.execute(
            text(f"CREATE TABLE {tbl} ({', '.join(col_defs)}, PRIMARY KEY (id))")
        )
        for col in body.columns or []:
            if col.get("type") == "select":
                await session.execute(
                    text(
                        "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                        "VALUES (:tid, :cn, CAST(:opts AS json))"
                    ),
                    {
                        "tid": t.id,
                        "cn": col["id"],
                        "opts": json.dumps(
                            _normalize_select_opts(col.get("selectOptions"))
                        ),
                    },
                )
            elif col.get("type") == "url":
                await session.execute(
                    text(
                        "INSERT INTO data_table_column_meta (table_id, column_name, col_type) "
                        "VALUES (:tid, :cn, 'url') "
                        "ON CONFLICT (table_id, column_name) DO UPDATE SET col_type = 'url'"
                    ),
                    {"tid": t.id, "cn": col["id"]},
                )
        col_ids = [c["id"] for c in (body.columns or [])]
        max_id = 0
        for row in body.rows or []:
            row_id = row.get("id")
            if not isinstance(row_id, int) or row_id <= 0:
                max_id += 1
                row = {**{k: v for k, v in row.items() if k != "id"}, "id": max_id}
            else:
                max_id = max(max_id, row_id)
            await _upsert_row(session, tbl, row, col_ids)
        await session.commit()
        await session.refresh(t)
        await manager.broadcast("table_list", {"type": "table_created", "id": t.id})
        return await _tbl_read(t, session)

    @router.patch(
        "/db-tables/{id}",
        response_model=DbTableRead,
        response_model_by_alias=True,
        tags=["db-tables"],
    )
    async def update_db_table(
        id: int,
        body: DbTableUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        patch = body.model_dump(exclude_unset=True, by_alias=False)
        if "name" in patch and patch["name"] != t.name:
            clash = (
                await session.exec(
                    select(DataTable).where(DataTable.name == patch["name"])
                )
            ).first()
            if clash:
                raise HTTPException(
                    status_code=409,
                    detail=f"A table named '{patch['name']}' already exists.",
                )
            t.name = patch["name"]
        if "description" in patch:
            t.description = patch["description"]
        if "actions" in patch:
            t.actions = patch["actions"]
        if "columns" in patch:
            new_columns: list[dict] = patch["columns"] or []
            seen_ids: set[str] = set()
            for col in new_columns:
                col_id = col.get("id", "")
                _validate_column_id(col_id)
                if col_id in seen_ids:
                    raise HTTPException(
                        status_code=422, detail=f"Duplicate column name '{col_id}'."
                    )
                seen_ids.add(col_id)
            old_cols = await _read_columns(session, id)
            old_col_map = {c["id"]: c for c in old_cols}
            new_col_map = {c["id"]: c for c in new_columns}
            for col_id in set(new_col_map) - set(old_col_map):
                pg_type = _PG_TYPE_MAP.get(
                    new_col_map[col_id].get("type", "text"), "TEXT"
                )
                try:
                    await session.execute(
                        text(f"ALTER TABLE {tbl} ADD COLUMN {_qi(col_id)} {pg_type}")
                    )
                except Exception as exc:
                    err_str = str(exc).lower()
                    if "already exists" in err_str:
                        await session.rollback()
                        raise HTTPException(
                            status_code=409, detail=f"Column '{col_id}' already exists."
                        )
                    raise
            for col_id in set(old_col_map) - set(new_col_map):
                await session.execute(
                    text(f"ALTER TABLE {tbl} DROP COLUMN {_qi(col_id)}")
                )
                await session.execute(
                    text(
                        "DELETE FROM data_table_column_meta WHERE table_id = :tid AND column_name = :cn"
                    ),
                    {"tid": id, "cn": col_id},
                )
            for col_id in set(old_col_map) & set(new_col_map):
                old_pg = _PG_TYPE_MAP.get(
                    old_col_map[col_id].get("type", "text"), "TEXT"
                )
                new_pg = _PG_TYPE_MAP.get(
                    new_col_map[col_id].get("type", "text"), "TEXT"
                )
                if old_pg != new_pg:
                    await session.execute(
                        text(
                            f"ALTER TABLE {tbl} ALTER COLUMN {_qi(col_id)} TYPE {new_pg} "
                            f"USING CAST({_qi(col_id)} AS {new_pg})"
                        )
                    )
            for col_id, col in new_col_map.items():
                description = col.get("description") or None
                if col.get("type") == "select":
                    await session.execute(
                        text(
                            "INSERT INTO data_table_column_meta (table_id, column_name, select_options, description) "
                            "VALUES (:tid, :cn, CAST(:opts AS json), :desc) "
                            "ON CONFLICT (table_id, column_name) DO UPDATE SET select_options = EXCLUDED.select_options, col_type = NULL, description = EXCLUDED.description"
                        ),
                        {
                            "tid": id,
                            "cn": col_id,
                            "opts": json.dumps(
                                _normalize_select_opts(col.get("selectOptions"))
                            ),
                            "desc": description,
                        },
                    )
                elif col.get("type") == "url":
                    await session.execute(
                        text(
                            "INSERT INTO data_table_column_meta (table_id, column_name, col_type, description) "
                            "VALUES (:tid, :cn, 'url', :desc) "
                            "ON CONFLICT (table_id, column_name) DO UPDATE SET col_type = 'url', select_options = NULL, description = EXCLUDED.description"
                        ),
                        {"tid": id, "cn": col_id, "desc": description},
                    )
                elif description:
                    await session.execute(
                        text(
                            "INSERT INTO data_table_column_meta (table_id, column_name, description) "
                            "VALUES (:tid, :cn, :desc) "
                            "ON CONFLICT (table_id, column_name) DO UPDATE SET description = EXCLUDED.description, select_options = NULL, col_type = NULL"
                        ),
                        {"tid": id, "cn": col_id, "desc": description},
                    )
                else:
                    await session.execute(
                        text(
                            "DELETE FROM data_table_column_meta WHERE table_id = :tid AND column_name = :cn"
                        ),
                        {"tid": id, "cn": col_id},
                    )
        if "rows" in patch:
            col_ids = await _get_column_names(session, tbl)
            max_id: int = (
                await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))
            ) or 0
            normalized: list[dict] = []
            for row in patch["rows"] or []:
                row_id = row.get("id")
                if not isinstance(row_id, int) or row_id <= 0:
                    max_id += 1
                    normalized.append(
                        {**{k: v for k, v in row.items() if k != "id"}, "id": max_id}
                    )
                else:
                    max_id = max(max_id, row_id)
                    normalized.append(row)
            new_ids = [r["id"] for r in normalized]
            if new_ids:
                id_list = ", ".join(str(i) for i in new_ids)
                await session.execute(
                    text(f"DELETE FROM {tbl} WHERE id NOT IN ({id_list})")
                )
            else:
                await session.execute(text(f"DELETE FROM {tbl}"))
            for row in normalized:
                await _upsert_row(session, tbl, row, col_ids)
        t.updated_at = datetime.now(timezone.utc)
        session.add(t)
        await session.commit()
        await session.refresh(t)
        await manager.broadcast(f"table:{id}", {"type": "schema_changed"})
        return await _tbl_read(t, session)

    @router.post(
        "/db-tables/{id}/add-columns",
        response_model=DbTableRead,
        response_model_by_alias=True,
        tags=["db-tables"],
    )
    async def add_table_columns(
        id: int,
        body: DbAddColumnsRequest,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        existing_cols = await _read_columns(session, id)
        existing_col_ids = {c["id"] for c in existing_cols}

        for col in body.columns:
            col_id = col.get("id", "")
            _validate_column_id(col_id)
            if col_id in existing_col_ids:
                continue
            pg_type = _PG_TYPE_MAP.get(col.get("type", "text"), "TEXT")
            await session.execute(
                text(f"ALTER TABLE {tbl} ADD COLUMN {_qi(col_id)} {pg_type}")
            )
            if col.get("type") == "select":
                await session.execute(
                    text(
                        "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                        "VALUES (:tid, :cn, CAST(:opts AS json)) "
                        "ON CONFLICT (table_id, column_name) DO UPDATE SET select_options = EXCLUDED.select_options"
                    ),
                    {
                        "tid": id,
                        "cn": col_id,
                        "opts": json.dumps(
                            _normalize_select_opts(col.get("selectOptions"))
                        ),
                    },
                )
            elif col.get("type") == "url":
                await session.execute(
                    text(
                        "INSERT INTO data_table_column_meta (table_id, column_name, col_type) "
                        "VALUES (:tid, :cn, 'url') "
                        "ON CONFLICT (table_id, column_name) DO UPDATE SET col_type = 'url'"
                    ),
                    {"tid": id, "cn": col_id},
                )

        t.updated_at = datetime.now(timezone.utc)
        session.add(t)
        await session.commit()
        await session.refresh(t)
        await manager.broadcast(f"table:{id}", {"type": "schema_changed"})
        return await _tbl_read(t, session)

    @router.delete(
        "/db-tables/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["db-tables"]
    )
    async def delete_db_table(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        await session.execute(text(f"DROP TABLE IF EXISTS {_pg_table(id)}"))
        await session.delete(t)
        await session.commit()
        await manager.broadcast("table_list", {"type": "table_deleted", "id": id})

    router.include_router(create_rows_router())
    router.include_router(create_views_router())
    router.include_router(create_csv_router())

    return router
