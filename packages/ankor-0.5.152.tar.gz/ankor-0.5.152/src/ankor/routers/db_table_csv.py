"""CSV import/export endpoints and helper functions for data tables."""

from __future__ import annotations

import csv
import io
import json
import os
import re
from typing import Any

import httpx
from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Response,
    UploadFile,
    status,
)
from sqlalchemy import text
from sqlmodel.ext.asyncio.session import AsyncSession

from ..broadcast import manager
from ..database import get_session
from ..db_helpers import (
    _get_column_names,
    _normalize_row,
    _normalize_select_opts,
    _pg_table,
    _PG_TYPE_MAP,
    _qi,
    _read_col_types,
    _read_columns,
    _upsert_row,
    coerce_csv_value,
)
from ..deps import get_current_user
from ..models import DataTable, User

_VALID_COL_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,62}$")
_GEMINI_SAMPLE_ROWS = 12
_GEMINI_MAPPING_SCHEMA: dict = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "csv_header": {"type": "string"},
            "target_col_id": {"type": "string", "nullable": True},
            "is_new": {"type": "boolean"},
        },
        "required": ["csv_header", "target_col_id", "is_new"],
        "propertyOrdering": ["csv_header", "target_col_id", "is_new"],
    },
}
csv.field_size_limit(10 * 1024 * 1024)  # 10 MB — handles large JSON blobs in cells


def _decode_csv_content(content: bytes) -> str:
    """Decode raw CSV bytes, handling BOM and latin-1 fallback."""
    try:
        return content.decode("utf-8-sig")
    except UnicodeDecodeError:
        return content.decode("latin-1")


def _simple_csv_mapping(
    csv_headers: list[str],
    table_columns: list[dict],
) -> list[dict]:
    """Heuristic mapping when Gemini is unavailable.

    Tries the following steps in order, stopping at the first match:
    1. Exact match on column id (case-insensitive).
    2. Case-insensitive match on column display name.
    3. Space/underscore equivalence: "Lead ID" → "lead id" matches "lead_id".
    4. Common affix stripping: "email_address" → "email", "quality_score" → "score".

    Unmatched headers get ``is_new=True``.
    """
    col_by_id = {c["id"].lower(): c["id"] for c in table_columns}
    col_by_name = {c["name"].lower(): c["id"] for c in table_columns}
    # "Lead ID" → "lead id" should match column id "lead_id"
    col_by_id_spaced = {
        c["id"].lower().replace("_", " "): c["id"] for c in table_columns
    }

    # Common suffixes and prefixes to strip when looking for a base match.
    _STRIP_SUFFIXES = (
        "_address",
        "_name",
        "_id",
        "_code",
        "_no",
        "_num",
        "_score",
        "_data",
    )
    _STRIP_PREFIXES = (
        "address_",
        "name_",
        "id_",
        "quality_",
        "extra_",
        "is_",
        "has_",
        "num_",
    )

    def _lookup(key: str) -> str | None:
        return col_by_id.get(key) or col_by_name.get(key) or col_by_id_spaced.get(key)

    result = []
    for header in csv_headers:
        normalized = header.strip().lower()
        col_id = _lookup(normalized)
        if col_id is None:
            for suffix in _STRIP_SUFFIXES:
                if normalized.endswith(suffix):
                    col_id = _lookup(normalized[: -len(suffix)])
                    if col_id is not None:
                        break
        if col_id is None:
            for prefix in _STRIP_PREFIXES:
                if normalized.startswith(prefix):
                    col_id = _lookup(normalized[len(prefix) :])
                    if col_id is not None:
                        break
        result.append(
            {
                "csv_header": header,
                "target_col_id": col_id,
                "is_new": col_id is None,
            }
        )
    return result


async def _suggest_mapping_with_gemini(
    csv_headers: list[str],
    table_columns: list[dict],
    sample_rows: list[dict] | None = None,
) -> list[dict]:
    """Call Gemini with structured output to suggest CSV header → table column mapping.

    Passes up to _GEMINI_SAMPLE_ROWS rows so Gemini can infer column semantics
    from actual data values (e.g. domain strings vs. company names).
    Falls back to :func:`_simple_csv_mapping` if the API key is missing or the
    call fails.
    """
    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not api_key:
        return _simple_csv_mapping(csv_headers, table_columns)

    cols_summary = [
        {"id": c["id"], "name": c.get("name", c["id"]), "type": c.get("type", "text")}
        for c in table_columns
    ]
    sample_block = (
        f"\n\nSample CSV rows ({len(sample_rows)}):\n{json.dumps(sample_rows, default=str)}"
        if sample_rows
        else ""
    )
    prompt = (
        "You are a data mapping assistant. Given CSV column headers, database table columns, "
        "and a sample of CSV rows, map each CSV header to the best matching table column.\n\n"
        f"CSV headers: {json.dumps(csv_headers)}\n"
        f"Table columns: {json.dumps(cols_summary)}"
        f"{sample_block}\n\n"
        "Rules:\n"
        "- Prefer exact id matches, then display-name matches, then semantic similarity.\n"
        "- Use the sample row values to understand what the data represents "
        "(e.g. if values look like domain names, map to a *_domain column rather than a *_name column).\n"
        "- Only set target_col_id to null if there is truly no reasonable match.\n"
        "- Skip system columns (id, created_at, updated_at, history).\n"
        "- Return exactly one entry per CSV header."
    )

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
                params={"key": api_key},
                json={
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {
                        "responseMimeType": "application/json",
                        "responseSchema": _GEMINI_MAPPING_SCHEMA,
                    },
                },
            )
            if not resp.is_success:
                return _simple_csv_mapping(csv_headers, table_columns)

            data = resp.json()
            text_out = data["candidates"][0]["content"]["parts"][0]["text"]
            parsed: list[dict] = json.loads(text_out)

            # Sanitise: validate target_col_id against real column ids (model may hallucinate)
            # Also prevent many-to-one: each table column can absorb at most one CSV header.
            col_ids = {c["id"] for c in table_columns}
            sanitised = []
            seen_headers: set[str] = set()
            claimed_col_ids: set[str] = set()
            for entry in parsed:
                h = entry.get("csv_header")
                if h not in csv_headers or h in seen_headers:
                    continue
                seen_headers.add(h)
                tid = entry.get("target_col_id")
                if tid is not None and (tid not in col_ids or tid in claimed_col_ids):
                    tid = None
                if tid is not None:
                    claimed_col_ids.add(tid)
                sanitised.append(
                    {"csv_header": h, "target_col_id": tid, "is_new": tid is None}
                )

            # Ensure every header is represented (model may omit some)
            covered = {e["csv_header"] for e in sanitised}
            for h in csv_headers:
                if h not in covered:
                    sanitised.append(
                        {"csv_header": h, "target_col_id": None, "is_new": True}
                    )

            return sanitised

    except Exception:  # noqa: BLE001
        return _simple_csv_mapping(csv_headers, table_columns)


def create_csv_router() -> APIRouter:
    router = APIRouter()

    @router.get("/db-tables/{id}/export", tags=["db-tables"])
    async def export_db_table_csv(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)
        columns = await _read_columns(session, id)
        col_ids = [c["id"] for c in columns]
        col_types = {c["id"]: c["type"] for c in columns}

        # Build id→label lookup for every select column.
        select_labels: dict[str, dict[int | str, str]] = {}
        for col in columns:
            if col.get("type") == "select":
                opts = _normalize_select_opts(col.get("selectOptions", []))
                select_labels[col["id"]] = {o["id"]: o["label"] for o in opts}

        result = await session.execute(text(f"SELECT * FROM {tbl} ORDER BY id"))
        rows = [_normalize_row(r._mapping, col_types) for r in result]

        buf = io.StringIO()
        writer = csv.writer(buf)
        headers = ["id"] + col_ids + ["created_at", "updated_at"]
        writer.writerow(headers)
        for row in rows:

            def _cell(h: str) -> Any:
                v = row.get(h)
                if v is None:
                    return ""
                if isinstance(v, (dict, list)):
                    return json.dumps(v)
                if h in select_labels and v is not None:
                    return select_labels[h].get(v, v)
                return v

            writer.writerow([_cell(h) for h in headers])

        filename = re.sub(r"[^a-zA-Z0-9_-]", "_", t.name)
        return Response(
            content=buf.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{filename}.csv"'},
        )

    @router.post(
        "/db-tables/{id}/csv-analyze",
        status_code=status.HTTP_200_OK,
        tags=["db-tables"],
    )
    async def analyze_csv_headers(
        id: int,
        file: UploadFile = File(...),
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        """Read a CSV file's headers and return a suggested column mapping.

        Uses Gemini (if ``GEMINI_API_KEY`` is set) to intelligently map CSV
        headers to existing table columns; otherwise falls back to a simple
        name-matching heuristic.
        """
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )

        columns = await _read_columns(session, id)

        content = await file.read()
        reader = csv.DictReader(io.StringIO(_decode_csv_content(content)))
        if reader.fieldnames is None:
            raise HTTPException(
                status_code=422, detail="CSV file is empty or has no header row"
            )

        csv_headers = [
            h.strip()
            for h in reader.fieldnames
            if h and h.strip() not in ("id", "created_at", "updated_at", "history")
        ]

        sample_rows: list[dict] = []
        for row in reader:
            if len(sample_rows) >= _GEMINI_SAMPLE_ROWS:
                break
            sample_rows.append({h: row[h] for h in csv_headers if h in row})

        mapping = await _suggest_mapping_with_gemini(csv_headers, columns, sample_rows)
        return {
            "csv_headers": csv_headers,
            "table_columns": columns,
            "mapping": mapping,
        }

    @router.post(
        "/db-tables/{id}/import", status_code=status.HTTP_200_OK, tags=["db-tables"]
    )
    async def import_db_table_csv(
        id: int,
        file: UploadFile = File(...),
        mapping: str | None = Form(None),
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        """Import rows from a CSV file.

        When *mapping* (a JSON string) is provided it should be an array of::

            {
              "csv_header": "<original header>",
              "target_col_id": "<existing col id>" | null,
              "skip": true | false,          # omit or false to include
              "is_new": true | false,         # true → create a new column
              "new_col_name": "<display name>",
              "new_col_type": "text"|"integer"|"float"|"boolean"|"date"|"select"|"json"
            }

        When *mapping* is absent the legacy behaviour (match by header name) is
        used for backward compatibility.
        """
        t = await session.get(DataTable, id)
        if not t:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Table not found"
            )
        tbl = _pg_table(id)

        content = await file.read()
        reader = csv.DictReader(io.StringIO(_decode_csv_content(content)))
        if reader.fieldnames is None:
            raise HTTPException(
                status_code=422, detail="CSV file is empty or has no header row"
            )

        columns = await _read_columns(session, id)
        col_type_map = {c["id"]: c["type"] for c in columns}
        col_ids = [c["id"] for c in columns]

        if mapping is not None:
            # ── Mapped import path ────────────────────────────────────────────
            try:
                mapping_items: list[dict] = json.loads(mapping)
            except json.JSONDecodeError as exc:
                raise HTTPException(
                    status_code=422, detail=f"Invalid mapping JSON: {exc}"
                ) from exc

            # Create any new columns requested in the mapping
            for item in mapping_items:
                if item.get("skip") or not item.get("is_new"):
                    continue
                raw_id = (
                    item.get("new_col_name") or item.get("csv_header") or ""
                ).strip()
                # Slugify: replace spaces/special chars with underscores, lowercase
                new_col_id = re.sub(r"[^a-zA-Z0-9_]", "_", raw_id).lower().strip("_")
                if not new_col_id:
                    continue
                # Truncate to 63 chars
                new_col_id = new_col_id[:63]
                if new_col_id in ("id", "history", "created_at", "updated_at"):
                    continue
                if not _VALID_COL_NAME.match(new_col_id):
                    continue
                if new_col_id not in col_ids:
                    new_col_type = item.get("new_col_type") or "text"
                    pg_type = _PG_TYPE_MAP.get(new_col_type, "TEXT")
                    await session.execute(
                        text(
                            f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS {_qi(new_col_id)} {pg_type}"
                        )
                    )
                    col_ids.append(new_col_id)
                    col_type_map[new_col_id] = new_col_type
                # Resolve the mapping item to the created column id
                item["_resolved_col_id"] = new_col_id

            # Build header → col_id lookup from the mapping
            header_to_col_id: dict[str, str] = {}
            for item in mapping_items:
                if item.get("skip"):
                    continue
                h = item.get("csv_header", "")
                col_id = item.get("_resolved_col_id") or item.get("target_col_id")
                if col_id:
                    header_to_col_id[h] = col_id

        else:
            # ── Legacy path: match by column id / name ───────────────────────
            csv_headers = [h.strip() for h in (reader.fieldnames or [])]
            header_to_col_id = {h: h for h in col_ids}
            col_name_to_id = {c["name"]: c["id"] for c in columns}
            header_to_col_id.update(
                {
                    name: col_id
                    for name, col_id in col_name_to_id.items()
                    if name in csv_headers
                }
            )

        # Refresh col_ids / col_type_map in case new columns were added
        columns = await _read_columns(session, id)
        col_type_map = {c["id"]: c["type"] for c in columns}
        col_ids = [c["id"] for c in columns]

        # Re-apply explicit new-column types from the mapping.  PostgreSQL's
        # information_schema may not reflect uncommitted DDL within the same
        # transaction, so newly-added columns can fall back to "text" above.
        if mapping is not None:
            for item in mapping_items:
                if item.get("is_new") and not item.get("skip"):
                    resolved = item.get("_resolved_col_id")
                    if resolved:
                        col_type_map[resolved] = item.get("new_col_type") or "text"
                        if resolved not in col_ids:
                            col_ids.append(resolved)

        # Build select option label → ID lookups (label matching is case-insensitive).
        # We keep a mutable copy of each select column's options so new labels can be
        # appended on-the-fly and persisted once after the import loop.
        select_options_raw: dict[str, list[dict]] = {}  # col_id → mutable options list
        select_opts_by_col: dict[str, dict[str, int]] = {}  # col_id → {label_lower: id}
        modified_select_cols: set[str] = set()
        for col in columns:
            if col["type"] == "select":
                opts = list(col.get("selectOptions") or [])
                select_options_raw[col["id"]] = opts
                select_opts_by_col[col["id"]] = {
                    o["label"].lower(): o["id"] for o in opts if "label" in o
                }

        max_id: int = (
            await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))
        ) or 0
        imported = 0
        for csv_row in reader:
            row: dict[str, Any] = {}
            raw_id = (csv_row.get("id") or "").strip()
            if raw_id and raw_id.isdigit():
                row["id"] = int(raw_id)
            else:
                max_id += 1
                row["id"] = max_id
            max_id = max(max_id, row["id"])

            for header, value in csv_row.items():
                if header is None:
                    continue
                header = header.strip()
                if header in ("id", "created_at", "updated_at"):
                    continue
                col_id = header_to_col_id.get(header)
                if col_id is None:
                    continue
                col_type = col_type_map.get(col_id, "text")
                if col_type == "select":
                    label = (value or "").strip()
                    if not label:
                        row[col_id] = None
                    else:
                        label_lower = label.lower()
                        opt_map = select_opts_by_col.setdefault(col_id, {})
                        opt_id = opt_map.get(label_lower)
                        if opt_id is None:
                            # Create a new option for this unseen label
                            existing = select_options_raw.setdefault(col_id, [])
                            new_id = max((o["id"] for o in existing), default=0) + 1
                            existing.append({"id": new_id, "label": label})
                            opt_map[label_lower] = new_id
                            modified_select_cols.add(col_id)
                            opt_id = new_id
                        row[col_id] = opt_id
                else:
                    row[col_id] = coerce_csv_value(value or "", col_type)

            await _upsert_row(session, tbl, row, col_ids)
            imported += 1

        # Persist any select columns that received new options during this import
        for col_id in modified_select_cols:
            await session.execute(
                text(
                    "UPDATE data_table_column_meta SET select_options = CAST(:opts AS json) "
                    "WHERE table_id = :tid AND column_name = :cn"
                ),
                {
                    "tid": id,
                    "cn": col_id,
                    "opts": json.dumps(select_options_raw[col_id]),
                },
            )

        await session.commit()
        await manager.broadcast(f"table:{id}", {"type": "rows_changed"})
        return {"imported": imported}

    return router
