from __future__ import annotations

from datetime import datetime

from sqlalchemy import nullslast, update as sa_update
from sqlmodel import select

from ..models import RunNode, WorkflowStatus
from ._serialization import _json_safe

# May be overridden by tests via: import ankor.decorator._persistence as m; m._SessionLocal = sl
_SessionLocal = None


def _get_session_local():
    """Return the active session factory (set by setup_engine or patched by tests)."""
    return globals().get("_SessionLocal")


__all__ = [
    "insert_run_node",
    "update_run_node",
    "broadcast_node_update",
    "_cancel_running_descendants",
    "_reset_node_for_rerun",
]


async def insert_run_node(
    run_id: int,
    parent_db_id: int | None,
    name: str,
    slug: str | None,
    inputs: dict,
    started_at: datetime,
    *,
    child_run_id: int | None = None,
    node_status: WorkflowStatus = WorkflowStatus.running,
    duration_ms: int = 0,
    outputs: dict | None = None,
    logs: list | None = None,
) -> int:
    """INSERT a new RunNode row and return its DB primary key.

    Returns -1 when the DB is not configured (e.g. in unit tests).
    """
    if _get_session_local() is None:
        return -1
    data: dict = {"inputs": _json_safe(inputs)}
    if outputs is not None:
        data["outputs"] = _json_safe(outputs)
    if logs is not None:
        data["logs"] = _json_safe(logs)
    async with _get_session_local()() as session:
        node = RunNode(
            run_id=run_id,
            parent_node_id=parent_db_id,
            name=name,
            slug=slug,
            status=node_status,
            duration_ms=duration_ms,
            started_at=started_at,
            child_run_id=child_run_id,
            data=data,
        )
        session.add(node)
        await session.flush()
        db_id: int = node.id  # type: ignore[assignment]
        await session.commit()
    return db_id


async def update_run_node(
    node_db_id: int,
    *,
    node_status: WorkflowStatus,
    duration_ms: int,
    inputs: dict,
    outputs: dict,
    logs: list | None,
) -> None:
    """UPDATE an existing RunNode row once a node completes."""
    if _get_session_local() is None or node_db_id < 0:
        return
    async with _get_session_local()() as session:
        await session.execute(
            sa_update(RunNode)
            .where(RunNode.id == node_db_id)
            .values(
                status=node_status,
                duration_ms=duration_ms,
                data={
                    "inputs": _json_safe(inputs),
                    "outputs": _json_safe(outputs),
                    "logs": _json_safe(logs),
                },
            )
        )
        await session.commit()


async def broadcast_node_update(
    run_id: int,
    db_id: int,
    name: str,
    slug: "str | None",
    status: str,
    duration_ms: int,
    started_at: "datetime | None",
    *,
    parent_node_id: "int | None" = None,
    child_run_id: "int | None" = None,
    parent_run_id: "int | None" = None,
) -> None:
    """Broadcast a ``node_updated`` event to ``workflow_detail:{run_id}``.

    When *parent_run_id* is set (sub-workflow), also broadcasts to
    ``workflow_detail:{parent_run_id}`` so the parent's detail page receives
    child-run node updates without needing a late subscription.
    """
    if _get_session_local() is None or db_id < 0:
        return
    from ..broadcast import manager
    from ._serialization import _ws_node_event

    payload = {
        "type": "node_updated",
        "data": _ws_node_event(
            db_id,
            run_id,
            name,
            slug,
            status,
            duration_ms,
            started_at,
            parent_node_id,
            child_run_id,
        ),
    }
    await manager.broadcast(f"workflow_detail:{run_id}", payload)
    if parent_run_id is not None:
        await manager.broadcast(f"workflow_detail:{parent_run_id}", payload)


async def _cancel_running_descendants(parent_node_id: int) -> None:
    """Cancel all running direct and indirect child nodes of *parent_node_id* (BFS)."""
    if _get_session_local() is None:
        return
    async with _get_session_local()() as session:
        all_to_cancel: list[int] = []
        search_ids = [parent_node_id]
        while search_ids:
            children = list(
                (
                    await session.exec(
                        select(RunNode).where(RunNode.parent_node_id.in_(search_ids))
                    )
                ).all()
            )
            next_ids: list[int] = []
            for child in children:
                if child.status == WorkflowStatus.running:
                    all_to_cancel.append(child.id)  # type: ignore[arg-type]
                next_ids.append(child.id)  # type: ignore[arg-type]
            search_ids = next_ids
        if all_to_cancel:
            await session.execute(
                sa_update(RunNode)
                .where(RunNode.id.in_(all_to_cancel))
                .values(status=WorkflowStatus.cancelled)
            )
            await session.commit()


async def _reset_node_for_rerun(node_db_id: int, started_at: datetime) -> None:
    """Reset an interrupted RunNode record so it can be re-executed in-place."""
    if _get_session_local() is None:
        return
    async with _get_session_local()() as session:
        await session.execute(
            sa_update(RunNode)
            .where(RunNode.id == node_db_id)
            .values(started_at=started_at, status=WorkflowStatus.running)
        )
        await session.commit()
