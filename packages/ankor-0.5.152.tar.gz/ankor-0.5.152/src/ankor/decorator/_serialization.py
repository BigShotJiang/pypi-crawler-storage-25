from __future__ import annotations

from datetime import date, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models import RunNode, WorkflowRun


def _json_safe(obj):
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    return obj


def _build_children_map(nodes: "list[RunNode]") -> "dict[int, list[RunNode]]":
    """Pre-build parent_id → children list for O(n) tree traversal."""
    result: dict = {}
    for node in nodes:
        if node.parent_node_id is not None:
            result.setdefault(node.parent_node_id, []).append(node)
    return result


def _serialize_db_node(
    node: "RunNode", children_map: "dict[int, list[RunNode]]", depth: int = 0
) -> dict:
    """Serialise a persisted RunNode (with DB id) for HTTP endpoints."""
    d = node.data or {}
    children: list[dict] = []
    if depth < 5:
        children = [
            _serialize_db_node(c, children_map, depth + 1)
            for c in children_map.get(node.id, [])
        ]
    st = node.status
    return {
        "id": node.id,  # DB primary key — canonical identifier
        "name": node.name,
        "slug": node.slug,
        "status": st.value if hasattr(st, "value") else st,
        "inputs": d.get("inputs") or {},
        "outputs": d.get("outputs") or {},
        "durationMs": node.duration_ms or 0,
        "startedAt": node.started_at.isoformat() if node.started_at else None,
        "logs": d.get("logs"),
        "childRunId": node.child_run_id,
        "children": children,
    }


# ── WebSocket event helpers ───────────────────────────────────────────────────
# These produce minimal payloads for live WS pushes. The frontend updates state
# in-place and fetches full data via REST only when the user opens a detail view.


def _ws_run_list_event(run: "WorkflowRun", workflow_name: str) -> dict:
    """Minimal run payload for the ``workflow_list`` WS channel.

    Omits ``inputs`` / ``outputs`` / ``logs`` — those can be large and are
    never needed by the list view.
    """
    d = run.data or {}
    tc = d.get("trigger_context", {}) or {}
    tac = tc.get("table_action_context") or {}
    return {
        "id": run.id,
        "name": workflow_name,
        "status": run.status.value,
        "triggeredBy": (
            run.triggered_by.value
            if hasattr(run.triggered_by, "value")
            else run.triggered_by
        ),
        "triggerContext": tc,
        "startedAt": run.started_at.isoformat() if run.started_at else None,
        "finishedAt": run.finished_at.isoformat() if run.finished_at else None,
        "createdAt": run.created_at.isoformat(),
        "parentId": run.parent_id,
        "rowIds": tac.get("row_ids") or None,
        "tableId": tac.get("table_id"),
    }


def _ws_run_status(run: "WorkflowRun") -> dict:
    """Minimal run update for the ``workflow_detail:{id}`` WS channel."""
    return {
        "id": run.id,
        "status": run.status.value,
        "finishedAt": run.finished_at.isoformat() if run.finished_at else None,
    }


def _ws_node_event(
    db_id: int,
    run_id: int,
    name: str,
    slug: "str | None",
    status: str,
    duration_ms: int,
    started_at: "datetime | None",
    parent_node_id: "int | None" = None,
    child_run_id: "int | None" = None,
) -> dict:
    """Node status update for the ``workflow_detail:{run_id}`` WS channel."""
    return {
        "id": db_id,
        "runId": run_id,
        "parentId": parent_node_id,
        "name": name,
        "slug": slug,
        "status": status,
        "durationMs": duration_ms,
        "startedAt": started_at.isoformat() if started_at else None,
        "childRunId": child_run_id,
    }
