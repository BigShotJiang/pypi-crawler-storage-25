from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from ..models import RunNode, Workflow, WorkflowRun, WorkflowStatus
from ._context import _active_node_slot, _active_run_ctx, _running_tasks
from ._execution import _RunExecState, _execute_fn_task
from ._serialization import (
    _json_safe,
    _ws_run_list_event,
    _ws_run_status,
)

if TYPE_CHECKING:
    from .restart import ServerRestartLogic

# May be overridden by tests via: import ankor.decorator._drain as m; m._SessionLocal = sl
_SessionLocal = None


def _get_session_local():
    """Return the active session factory (set by setup_engine or patched by tests)."""
    return globals().get("_SessionLocal")


_drain_tasks: dict[str, asyncio.Task] = {}
_drain_events: dict[str, asyncio.Event] = {}


def _get_drain_event(name: str) -> asyncio.Event:
    if name not in _drain_events:
        _drain_events[name] = asyncio.Event()
    return _drain_events[name]


def _notify_drain(name: str) -> None:
    event = _drain_events.get(name)
    if event is not None:
        event.set()


def _ensure_drain_task(name: str, fn) -> None:
    task = _drain_tasks.get(name)
    if task is None or task.done():
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        _drain_tasks[name] = loop.create_task(
            _drain_loop(name, fn), name=f"gtm_drain_{name}"
        )


async def _drain_loop(name: str, fn) -> None:
    """Drain pending runs for *name*, respecting the concurrency limit.

    On each wake-up, fires off all newly-available slots in parallel.
    """
    from sqlalchemy import func as _func
    from sqlmodel import select

    event = _get_drain_event(name)
    while True:
        await event.wait()
        event.clear()
        if _get_session_local() is None:
            continue
        async with _get_session_local()() as session:
            cfg = (
                await session.exec(select(Workflow).where(Workflow.name == name))
            ).first()

            if cfg is None:
                continue

            if cfg.max_concurrent_runs is not None and cfg.max_concurrent_runs > 0:
                running_count: int = (
                    await session.execute(
                        select(_func.count(WorkflowRun.id)).where(
                            WorkflowRun.workflow_id == cfg.id,
                            WorkflowRun.status == WorkflowStatus.running,
                            WorkflowRun.parent_id == None,  # noqa: E711
                        )
                    )
                ).scalar_one()
                free_slots = max(0, cfg.max_concurrent_runs - running_count)
            else:
                free_slots = None

            if free_slots == 0:
                continue

            q = (
                select(WorkflowRun)
                .join(Workflow, WorkflowRun.workflow_id == Workflow.id)
                .where(
                    Workflow.name == name, WorkflowRun.status == WorkflowStatus.pending
                )
                .order_by(WorkflowRun.created_at)
            )
            if free_slots is not None:
                q = q.limit(free_slots)

            pending_list = list((await session.exec(q)).all())

        if not pending_list:
            continue

        for run in pending_list:
            asyncio.create_task(
                _execute_existing_run(fn, run.id, name),
                name=f"gtm_run_{name}_{run.id}",
            )


async def _execute_existing_run(fn, run_id: int, workflow_name: str) -> None:
    """Transition a pending run to running and execute it.

    Called by the drain loop. Calls _notify_drain when done so the drain loop
    picks up the next pending run.
    """
    from sqlalchemy import func as _func
    from sqlmodel import select

    from ..broadcast import manager

    if _get_session_local() is None:
        return

    async with _get_session_local()() as session:
        run = await session.get(WorkflowRun, run_id)
        if run is None or run.status != WorkflowStatus.pending:
            _notify_drain(workflow_name)
            return

        cfg = (
            await session.exec(select(Workflow).where(Workflow.id == run.workflow_id))
        ).first()

        if (
            cfg is not None
            and cfg.max_concurrent_runs is not None
            and cfg.max_concurrent_runs > 0
        ):
            running_count: int = (
                await session.exec(
                    select(_func.count(WorkflowRun.id)).where(
                        WorkflowRun.workflow_id == cfg.id,
                        WorkflowRun.status == WorkflowStatus.running,
                        WorkflowRun.parent_id == None,  # noqa: E711
                    )
                )
            ).one()
            if running_count >= cfg.max_concurrent_runs:
                return

        inputs = (run.data or {}).get("inputs", {})
        run.status = WorkflowStatus.running
        run.started_at = datetime.now(timezone.utc)
        session.add(run)
        await session.commit()
        await session.refresh(run)

        await manager.broadcast(
            "workflow_list",
            {"type": "run_updated", "data": _ws_run_list_event(run, workflow_name)},
        )

        ctx: dict = {
            "logs": [],
            "run_id": run.id,
            "_executed_names": set(),
            "_row_history": {},
            "_run_meta": {
                "id": run.id,
                "name": workflow_name,
                "triggeredBy": (
                    run.triggered_by.value
                    if hasattr(run.triggered_by, "value")
                    else run.triggered_by
                ),
                "triggerContext": (run.data or {}).get("trigger_context", {}),
                "inputs": inputs,
                "outputs": {},
                "startedAt": run.started_at.isoformat() if run.started_at else None,
                "finishedAt": None,
                "createdAt": run.created_at.isoformat(),
                "parentId": run.parent_id,
                "children": [],
            },
        }
        ctx_token = _active_run_ctx.set(ctx)
        slot_token = _active_node_slot.set(None)
        timeout = cfg.timeout_seconds if cfg else None
        coro = fn(inputs)
        fn_task = asyncio.create_task(
            asyncio.wait_for(coro, timeout=timeout) if timeout else coro
        )
        _running_tasks[run.id] = fn_task
        state = _RunExecState(
            run=run,
            inputs=inputs,
            name=workflow_name,
            ctx=ctx,
            ctx_token=ctx_token,
            slot_token=slot_token,
        )
        _, was_cancelled, failure_exc = await _execute_fn_task(fn_task, state)

        if not was_cancelled:
            run.finished_at = datetime.now(timezone.utc)
            session.add(run)
            await session.commit()
            await manager.broadcast(
                "workflow_list",
                {"type": "run_updated", "data": _ws_run_list_event(run, workflow_name)},
            )
            await manager.broadcast(
                f"workflow_detail:{run.id}",
                {"type": "run_updated", "data": _ws_run_status(run)},
            )

    _notify_drain(workflow_name)


async def _cancel_running_child_runs(parent_run_id: int, session) -> None:
    """Cancel all direct child WorkflowRuns still in running state."""
    from sqlalchemy import update as _sa_update
    from datetime import datetime, timezone

    await session.execute(
        _sa_update(WorkflowRun)
        .where(
            WorkflowRun.parent_id == parent_run_id,
            WorkflowRun.status == WorkflowStatus.running,
        )
        .values(status=WorkflowStatus.cancelled, finished_at=datetime.now(timezone.utc))
    )


async def _resume_existing_run(
    fn,
    run_id: int,
    workflow_name: str,
    server_restart_logic: "ServerRestartLogic | None" = None,
    *,
    wrappers: dict | None = None,
) -> dict | None:
    """Resume a workflow run that was mid-execution when the server crashed.

    Re-executes the workflow function with resume context so already-completed nodes
    are skipped and interrupted nodes are handled per server_restart_logic.
    Returns the run's outputs on success, or None on failure, cancellation, or skip.
    """
    from sqlmodel import select

    if _get_session_local() is None:
        return None

    from ..broadcast import manager

    async with _get_session_local()() as session:
        run = await session.get(WorkflowRun, run_id)
        if run is None or run.status != WorkflowStatus.running:
            _notify_drain(workflow_name)
            return None

        cfg = (
            await session.exec(select(Workflow).where(Workflow.id == run.workflow_id))
        ).first()

        inputs = (run.data or {}).get("inputs", {})

        if server_restart_logic is not None and server_restart_logic.mode == "skip":
            run.status = WorkflowStatus.cancelled
            run.finished_at = datetime.now(timezone.utc)
            session.add(run)
            await session.commit()
            await manager.broadcast(
                "workflow_list",
                {"type": "run_updated", "data": _ws_run_list_event(run, workflow_name)},
            )
            _notify_drain(workflow_name)
            return None

        if (
            server_restart_logic is not None
            and server_restart_logic.mode == "mock_on_side_effect"
            and server_restart_logic.side_effect_check is not None
        ):
            check_result = await server_restart_logic.side_effect_check(inputs)
            if check_result is not None:
                run.status = WorkflowStatus.success
                run.finished_at = datetime.now(timezone.utc)
                run.data = {**run.data, "outputs": _json_safe(check_result)}
                session.add(run)
                await session.commit()
                await manager.broadcast(
                    "workflow_list",
                    {
                        "type": "run_updated",
                        "data": _ws_run_list_event(run, workflow_name),
                    },
                )
                _notify_drain(workflow_name)
                return check_result

        is_rerun = (
            server_restart_logic is not None and server_restart_logic.mode == "rerun"
        )

        if is_rerun:
            await _cancel_running_child_runs(run_id, session)
            await session.commit()

        if not is_rerun:
            from sqlalchemy.orm import defer as _defer

            all_nodes = list(
                (
                    await session.execute(
                        select(RunNode)
                        .where(RunNode.run_id == run_id)
                        .options(_defer(RunNode.data))
                        .order_by(RunNode.id)
                    )
                )
                .scalars()
                .all()
            )
            success_ids = [
                n.id for n in all_nodes if n.status == WorkflowStatus.success
            ]
            success_data: dict[int, dict] = {}
            if success_ids:
                success_data = {
                    row.id: row.data
                    for row in (
                        await session.execute(
                            select(RunNode.id, RunNode.data).where(
                                RunNode.id.in_(success_ids)
                            )
                        )
                    ).all()
                }
            await session.refresh(run)
            for n in all_nodes:
                session.expunge(n)
        else:
            all_nodes = []
            success_data = {}
            await session.refresh(run)

    for node in all_nodes:
        node.data = success_data.get(node.id) or {}

    by_parent: dict = {}
    for node in all_nodes:
        by_parent.setdefault(node.parent_node_id, []).append(node)

    trigger_type_val = (
        run.triggered_by.value
        if hasattr(run.triggered_by, "value")
        else run.triggered_by
    )
    ctx: dict = {
        "logs": list((run.data or {}).get("logs", [])),
        "run_id": run.id,
        "_executed_names": set(),
        "_row_history": {},
        "_wrappers": wrappers or {},
        "_run_meta": {
            "id": run.id,
            "name": workflow_name,
            "triggeredBy": trigger_type_val,
            "triggerContext": (run.data or {}).get("trigger_context", {}),
            "inputs": inputs,
            "outputs": {},
            "startedAt": run.started_at.isoformat() if run.started_at else None,
            "finishedAt": None,
            "createdAt": run.created_at.isoformat(),
            "parentId": run.parent_id,
            "children": [],
        },
        "_is_resume": not is_rerun,
        "_resumed_by_parent": by_parent,
    }

    await manager.broadcast(
        "workflow_list",
        {"type": "run_updated", "data": _ws_run_list_event(run, workflow_name)},
    )

    ctx_token = _active_run_ctx.set(ctx)
    slot_token = _active_node_slot.set(None)
    timeout = cfg.timeout_seconds if cfg else None
    coro = fn(inputs)
    fn_task = asyncio.create_task(
        asyncio.wait_for(coro, timeout=timeout) if timeout else coro
    )
    _running_tasks[run.id] = fn_task
    state = _RunExecState(
        run=run,
        inputs=inputs,
        name=workflow_name,
        ctx=ctx,
        ctx_token=ctx_token,
        slot_token=slot_token,
    )
    _, was_cancelled, _ = await _execute_fn_task(fn_task, state)

    if not was_cancelled:
        run.finished_at = datetime.now(timezone.utc)
        async with _get_session_local()() as session:
            await _cancel_running_child_runs(run_id, session)
            await session.merge(run)
            await session.commit()
        await manager.broadcast(
            "workflow_list",
            {"type": "run_updated", "data": _ws_run_list_event(run, workflow_name)},
        )
        await manager.broadcast(
            f"workflow_detail:{run.id}",
            {"type": "run_updated", "data": _ws_run_status(run)},
        )

    _notify_drain(workflow_name)

    if run.status == WorkflowStatus.success:
        return (run.data or {}).get("outputs") or {}
    return None
