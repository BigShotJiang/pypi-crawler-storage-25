from __future__ import annotations

import dataclasses
from typing import Awaitable, Callable, Literal


@dataclasses.dataclass
class ServerRestartLogic:
    """Controls how a workflow run or node interrupted by a server crash is handled on restart.

    Attributes:
        mode:
            ``rerun`` — re-execute from scratch, ignoring all prior node results.
            ``mock_on_side_effect`` — call ``side_effect_check``; use its return value
            as the result when non-None, otherwise re-execute normally.
            ``skip`` — cancel the run/node without re-executing; the parent workflow
            continues as if this step succeeded with empty outputs.
        side_effect_check:
            Required when ``mode="mock_on_side_effect"``.  Receives the original inputs
            and returns the outputs dict if the operation already completed, or ``None``
            if it must be re-run.
    """

    mode: Literal["rerun", "mock_on_side_effect", "skip"]
    side_effect_check: Callable[[dict], Awaitable[dict | None]] | None = None
