from __future__ import annotations

import asyncio
import functools
from datetime import datetime, timezone
from typing import TYPE_CHECKING


def _get_session_local():
    """Return the active session factory (set by setup_engine or patched by tests)."""
    return globals().get("_SessionLocal")


_SessionLocal = None  # may be overridden by tests or setup_engine
from ..models import TriggerType, Workflow, WorkflowRun, WorkflowStatus
from ..trigger_context import TriggerContext
from ._context import _active_node_slot, _active_run_ctx, _running_tasks
from ._drain import _ensure_drain_task, _notify_drain
from ._execution import _RunExecState, _execute_fn_task
from ._persistence import broadcast_node_update, insert_run_node, update_run_node
from ._serialization import (
    _json_safe,
    _ws_node_event,
    _ws_run_list_event,
    _ws_run_status,
)
from ..types import WorkflowFn

if TYPE_CHECKING:
    from .restart import ServerRestartLogic

_RESUME_NOT_FOUND: object = object()


async def _try_resume_sub_workflow(fn, inputs: dict, parent_ctx: dict) -> object:
    """Check parent's resume queue for an existing record of this sub-workflow call.

    Returns outputs dict if the sub-workflow was handled (skipped or recursively
    resumed), or _RESUME_NOT_FOUND if no prior record exists and normal execution
    should proceed.
    """
    from ._drain import _resume_existing_run

    parent_slot = _active_node_slot.get()
    parent_db_id: int | None = (
        parent_slot["_db_id"] if parent_slot is not None else None
    )
    resume_queue: list = parent_ctx.get("_resumed_by_parent", {}).get(parent_db_id, [])

    if not resume_queue or resume_queue[0].name != fn.__name__:
        return _RESUME_NOT_FOUND

    prev_row = resume_queue.pop(0)
    parent_ctx.setdefault("_executed_names", set()).add(fn.__name__)
    parent_run_id = parent_ctx.get("run_id")

    if prev_row.status == WorkflowStatus.success:
        if parent_run_id is not None:
            await broadcast_node_update(
                run_id=parent_run_id,
                db_id=prev_row.id,
                name=fn.__name__,
                slug=None,
                status=WorkflowStatus.success.value,
                duration_ms=0,
                started_at=prev_row.started_at,
                parent_node_id=prev_row.parent_node_id,
                child_run_id=prev_row.child_run_id,
            )
        return (prev_row.data or {}).get("outputs", {})

    if prev_row.status == WorkflowStatus.running and prev_row.child_run_id is not None:
        wrappers = parent_ctx.get("_wrappers", {})
        child_wrapper = wrappers.get(fn.__name__)
        child_fn_raw = (
            getattr(child_wrapper, "_gtm_fn", fn) if child_wrapper is not None else fn
        )
        child_logic = (
            getattr(child_wrapper, "_server_restart_logic", None)
            if child_wrapper is not None
            else None
        )

        outputs = await _resume_existing_run(
            child_fn_raw,
            prev_row.child_run_id,
            fn.__name__,
            child_logic,
            wrappers=wrappers,
        )
        final_outputs = outputs or {}
        final_status = (
            WorkflowStatus.success if outputs is not None else WorkflowStatus.failed
        )

        await update_run_node(
            prev_row.id,
            node_status=final_status,
            duration_ms=0,
            inputs=inputs,
            outputs=final_outputs,
            logs=None,
        )

        if parent_run_id is not None:
            await broadcast_node_update(
                run_id=parent_run_id,
                db_id=prev_row.id,
                name=fn.__name__,
                slug=None,
                status=final_status.value,
                duration_ms=0,
                started_at=prev_row.started_at,
                parent_node_id=prev_row.parent_node_id,
                child_run_id=prev_row.child_run_id,
            )

        return final_outputs

    if prev_row.status == WorkflowStatus.failed:
        # Sub-workflow already failed before the crash — skip re-execution,
        # broadcast the existing failed status, and raise so the parent
        # workflow handles it the same way as the original failure.
        if parent_run_id is not None:
            await broadcast_node_update(
                run_id=parent_run_id,
                db_id=prev_row.id,
                name=fn.__name__,
                slug=None,
                status=WorkflowStatus.failed.value,
                duration_ms=0,
                started_at=prev_row.started_at,
                parent_node_id=prev_row.parent_node_id,
                child_run_id=prev_row.child_run_id,
            )
        error_msg = (prev_row.data or {}).get(
            "error", f"sub-workflow '{fn.__name__}' failed before server restart"
        )
        raise RuntimeError(error_msg)

    return _RESUME_NOT_FOUND


def make_workflow_wrapper(
    fn,
    *,
    restart_on_failure_check=None,
    server_restart_logic: "ServerRestartLogic | None" = None,
) -> WorkflowFn:
    from .restart import ServerRestartLogic as _SRL

    _effective_logic: ServerRestartLogic | None = server_restart_logic
    if _effective_logic is None and restart_on_failure_check is not None:
        _effective_logic = _SRL(
            mode="mock_on_side_effect", side_effect_check=restart_on_failure_check
        )

    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, _ctx: TriggerContext | None = None):
        if _ctx is None:
            _ctx = TriggerContext("manual", inputs)

        _SessionLocal = _get_session_local()
        if _SessionLocal is None:
            return await fn(inputs)

        from ..broadcast import manager
        from sqlmodel import func, select

        _parent_ctx = _active_run_ctx.get()
        _parent_run_id: int | None = _parent_ctx.get("run_id") if _parent_ctx else None

        # Sub-workflow resume intercept: when the parent is in resume mode and
        # this sub-workflow has a prior record in the parent's queue, handle it
        # here instead of creating a new WorkflowRun.
        if (
            _parent_ctx is not None
            and _parent_ctx.get("_is_resume")
            and not _parent_ctx.get("_force_fresh")
        ):
            intercept_result = await _try_resume_sub_workflow(fn, inputs, _parent_ctx)
            if intercept_result is not _RESUME_NOT_FOUND:
                return intercept_result

        # --- Phase 1: short session — read config, create WorkflowRun, release connection ---
        async with _get_session_local()() as session:
            cfg = (
                await session.exec(select(Workflow).where(Workflow.name == fn.__name__))
            ).first()

            if cfg is not None and cfg.max_concurrent_runs is not None:
                if cfg.max_concurrent_runs == 0:
                    return None
                running_count: int = (
                    await session.execute(
                        select(func.count(WorkflowRun.id)).where(
                            WorkflowRun.workflow_id == cfg.id,
                            WorkflowRun.status == WorkflowStatus.running,
                            WorkflowRun.parent_id == None,  # noqa: E711
                        )
                    )
                ).scalar_one()
                if running_count >= cfg.max_concurrent_runs:
                    trigger_type = (
                        TriggerType(_ctx.type)
                        if _ctx.type in TriggerType._value2member_map_
                        else TriggerType.manual
                    )
                    queued = WorkflowRun(
                        workflow_id=cfg.id,
                        status=WorkflowStatus.pending,
                        triggered_by=trigger_type,
                        data={
                            "trigger_context": _ctx.to_db(),
                            "inputs": inputs,
                            "outputs": {},
                        },
                    )
                    session.add(queued)
                    await session.commit()
                    await session.refresh(queued)
                    await manager.broadcast(
                        "workflow_list",
                        {
                            "type": "run_created",
                            "data": _ws_run_list_event(queued, fn.__name__),
                        },
                    )
                    _ensure_drain_task(fn.__name__, fn)
                    return None

            if cfg is None:
                cfg = Workflow(name=fn.__name__)
                session.add(cfg)
                await session.commit()
                await session.refresh(cfg)

            trigger_type = (
                TriggerType(_ctx.type)
                if _ctx.type in TriggerType._value2member_map_
                else TriggerType.manual
            )
            timeout = cfg.timeout_seconds if cfg else None
            run = WorkflowRun(
                workflow_id=cfg.id,
                status=WorkflowStatus.running,
                triggered_by=trigger_type,
                parent_id=_parent_run_id,
                data={
                    "trigger_context": _ctx.to_db(),
                    "inputs": inputs,
                    "outputs": {},
                },
                started_at=datetime.now(timezone.utc),
            )
            session.add(run)
            await session.commit()
            await session.refresh(run)
        # connection returned to pool here

        await manager.broadcast(
            "workflow_list",
            {"type": "run_created", "data": _ws_run_list_event(run, fn.__name__)},
        )

        # Insert a "running" node in the parent run immediately so the frontend
        # can show the sub-workflow trigger node while it's still executing.
        _parent_trigger_node_db_id: int | None = None
        if _parent_ctx is not None and _parent_run_id is not None:
            parent_slot = _active_node_slot.get()
            parent_db_id: int | None = (
                parent_slot["_db_id"] if parent_slot is not None else None
            )
            _parent_trigger_node_db_id = await insert_run_node(
                run_id=_parent_run_id,
                parent_db_id=parent_db_id,
                name=fn.__name__,
                slug=None,
                inputs=inputs,
                started_at=run.started_at or datetime.now(timezone.utc),
                child_run_id=run.id,
                node_status=WorkflowStatus.running,
                duration_ms=0,
            )
            await broadcast_node_update(
                run_id=_parent_run_id,
                db_id=_parent_trigger_node_db_id,
                name=fn.__name__,
                slug=None,
                status=WorkflowStatus.running.value,
                duration_ms=0,
                started_at=run.started_at,
                parent_node_id=parent_db_id,
                child_run_id=run.id,
            )

        # --- Execute workflow — no DB connection held during LLM/API calls ---
        ctx: dict = {
            "logs": [],
            "run_id": run.id,
            "parent_run_id": _parent_run_id,
            "_executed_names": set(),
            "_row_history": {},
            "_run_meta": {
                "id": run.id,
                "name": fn.__name__,
                "triggeredBy": trigger_type.value,
                "triggerContext": _ctx.to_db(),
                "inputs": inputs,
                "outputs": {},
                "startedAt": run.started_at.isoformat() if run.started_at else None,
                "finishedAt": None,
                "createdAt": run.created_at.isoformat(),
                "parentId": _parent_run_id,
                "children": [],
            },
        }
        # Pre-register rows for table-action triggered workflows so they always
        # get a history entry, even when no db.update_row is called on them.
        table_action_ctx = (_ctx.metadata or {}).get("table_action_context")
        if table_action_ctx:
            ta_table_id = table_action_ctx.get("table_id")
            ta_row_ids = table_action_ctx.get("row_ids") or []
            if ta_table_id is not None:
                for rid in ta_row_ids:
                    key = (ta_table_id, int(rid))
                    ctx["_row_history"][key] = {"wr_id": run.id}
        ctx_token = _active_run_ctx.set(ctx)
        slot_token = _active_node_slot.set(None)
        coro = fn(inputs)
        fn_task = asyncio.create_task(
            asyncio.wait_for(coro, timeout=timeout) if timeout else coro
        )
        _running_tasks[run.id] = fn_task
        state = _RunExecState(
            run=run,
            inputs=inputs,
            name=fn.__name__,
            ctx=ctx,
            ctx_token=ctx_token,
            slot_token=slot_token,
        )
        result, was_cancelled, failure_exc = await _execute_fn_task(fn_task, state)

        # --- Phase 2: short session — persist final status, release connection ---
        if not was_cancelled:
            run.finished_at = datetime.now(timezone.utc)
            async with _get_session_local()() as session:
                await session.merge(run)
                await session.commit()

            await manager.broadcast(
                "workflow_list",
                {"type": "run_updated", "data": _ws_run_list_event(run, fn.__name__)},
            )
            await manager.broadcast(
                f"workflow_detail:{run.id}",
                {"type": "run_updated", "data": _ws_run_status(run)},
            )

            if _parent_ctx is not None and _parent_run_id is not None:
                duration_ms = (
                    int((run.finished_at - run.started_at).total_seconds() * 1000)
                    if run.started_at
                    else 0
                )
                if _parent_trigger_node_db_id is not None:
                    # Update the "running" node we inserted at sub-workflow start.
                    await update_run_node(
                        _parent_trigger_node_db_id,
                        node_status=run.status,
                        duration_ms=duration_ms,
                        inputs=inputs,
                        outputs=_json_safe((run.data or {}).get("outputs", {})),
                        logs=None,
                    )
                    await broadcast_node_update(
                        run_id=_parent_run_id,
                        db_id=_parent_trigger_node_db_id,
                        name=fn.__name__,
                        slug=None,
                        status=run.status.value,
                        duration_ms=duration_ms,
                        started_at=run.started_at,
                        child_run_id=run.id,
                    )
                else:
                    # Fallback: start node was never inserted (e.g. _get_session_local
                    # returned None during startup). Insert it now as completed.
                    parent_slot = _active_node_slot.get()
                    parent_db_id_fb: int | None = (
                        parent_slot["_db_id"] if parent_slot is not None else None
                    )
                    fb_id = await insert_run_node(
                        run_id=_parent_run_id,
                        parent_db_id=parent_db_id_fb,
                        name=fn.__name__,
                        slug=None,
                        inputs=inputs,
                        started_at=run.started_at or datetime.now(timezone.utc),
                        child_run_id=run.id,
                        node_status=run.status,
                        duration_ms=duration_ms,
                        outputs=_json_safe((run.data or {}).get("outputs", {})),
                    )
                    await broadcast_node_update(
                        run_id=_parent_run_id,
                        db_id=fb_id,
                        name=fn.__name__,
                        slug=None,
                        status=run.status.value,
                        duration_ms=duration_ms,
                        started_at=run.started_at,
                        child_run_id=run.id,
                    )

        # Flush buffered row-history entries for all rows touched (or pre-registered
        # as table-action targets) during this workflow run.  This sends a final
        # row_updated broadcast for rows that were registered but never updated,
        # ensuring the frontend clears any stale optimistic state.
        if not was_cancelled:
            from ..db_store import flush_row_history

            await flush_row_history(ctx, failed_exc=failure_exc)

        _notify_drain(fn.__name__)

        if failure_exc is not None:
            raise failure_exc

        return result

    wrapper._gtm_fn = fn
    wrapper._restart_on_failure_check = restart_on_failure_check
    wrapper._server_restart_logic = _effective_logic
    return wrapper
