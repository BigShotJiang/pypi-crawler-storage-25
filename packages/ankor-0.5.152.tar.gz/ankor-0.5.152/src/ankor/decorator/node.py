from __future__ import annotations

import asyncio
import dataclasses
import functools
import traceback
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Callable

from ._context import _active_node_logs, _active_node_slot, _active_run_ctx
from .._debug import dlog
from ._persistence import (
    _cancel_running_descendants,
    _reset_node_for_rerun,
    broadcast_node_update,
    insert_run_node,
    update_run_node,
)
from ..models import WorkflowStatus
from ..types import NodeFn
from ..db_store import flush_single_row_history

if TYPE_CHECKING:
    from .restart import ServerRestartLogic


@dataclasses.dataclass
class DbActionRecord:
    inputs: dict
    outputs: dict
    duration_ms: int


def log(message: str, *, type: str = "info", json: bool = False) -> None:
    """Append a structured log entry to the active log buffer.

    When inside a node, writes to the node's log buffer. When inside a workflow
    but outside any node, writes to the run's top-level logs. Silently dropped
    when called outside a workflow.
    """
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "body": str(message),
        "type": type,
        "json": json,
    }
    node_buf = _active_node_logs.get()
    if node_buf is not None:
        node_buf.append(entry)
        return
    run_ctx = _active_run_ctx.get()
    if run_ctx is not None:
        run_ctx["logs"].append(entry)


async def _insert_db_action_node(
    run_id: int,
    parent_db_id: int | None,
    op: str,
    table: str,
    record: "DbActionRecord",
    run_meta: dict,
    started_at: datetime,
    parent_run_id: int | None = None,
) -> None:
    """INSERT a RunNode for a DB operation and broadcast a node_updated event."""
    from ._serialization import _json_safe

    db_id = await insert_run_node(
        run_id=run_id,
        parent_db_id=parent_db_id,
        name=f"{op}: {table}",
        slug=None,
        inputs=_json_safe(record.inputs),
        started_at=started_at,
        node_status=WorkflowStatus.success,
        duration_ms=record.duration_ms,
        outputs=_json_safe(record.outputs),
    )
    await broadcast_node_update(
        run_id=run_id,
        db_id=db_id,
        name=f"{op}: {table}",
        slug=None,
        status=WorkflowStatus.success.value,
        duration_ms=record.duration_ms,
        started_at=started_at,
        parent_node_id=parent_db_id,
        parent_run_id=parent_run_id,
    )


def record_db_action(op: str, table: str, record: DbActionRecord) -> None:
    """Record a data-table operation as a child action of the current context.

    Called automatically by DbStore methods. No-op outside a workflow run.
    """
    ctx = _active_run_ctx.get()
    if ctx is None:
        return
    parent_slot = _active_node_slot.get()
    parent_db_id: int | None = (
        parent_slot["_db_id"] if parent_slot is not None else None
    )
    run_id = ctx.get("run_id")
    parent_run_id: int | None = ctx.get("parent_run_id")
    run_meta = ctx.get("_run_meta")
    if run_id is not None and run_meta is not None:
        # Capture started_at NOW (synchronously) so it reflects when the DB
        # operation actually ran, not when the deferred async task executes.
        started_at = datetime.now(timezone.utc)
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(
                _insert_db_action_node(
                    run_id,
                    parent_db_id,
                    op,
                    table,
                    record,
                    run_meta,
                    started_at,
                    parent_run_id,
                )
            )
        except RuntimeError:
            pass


async def _broadcast_row_status(
    table_id: int,
    row_id: int,
    run_id: int,
    status: str,
    *,
    wf_name: str | None = None,
) -> None:
    """Broadcast a row-level run status event on the table WebSocket channel."""
    from ..broadcast import manager

    payload: dict = {
        "type": "row_run_status",
        "runId": run_id,
        "rowId": row_id,
        "status": status,
    }
    if wf_name:
        payload["wfName"] = wf_name

    try:
        loop = asyncio.get_running_loop()
        loop.create_task(manager.broadcast(f"table:{table_id}", payload))
    except RuntimeError:
        pass


def _strip_meta(result: dict) -> dict:
    """Return a shallow copy of *result* with the ``_meta`` key removed."""
    return {k: v for k, v in result.items() if k != "_meta"}


def make_node_wrapper(
    fn,
    *,
    tracks_row: bool = False,
    restart_on_failure_check=None,
    server_restart_logic: "ServerRestartLogic | None" = None,
    return_meta: bool = False,
) -> NodeFn:
    from .restart import ServerRestartLogic as _SRL

    _effective_logic: ServerRestartLogic | None = server_restart_logic
    if _effective_logic is None and restart_on_failure_check is not None:
        _effective_logic = _SRL(
            mode="mock_on_side_effect", side_effect_check=restart_on_failure_check
        )

    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, slug: str | None = None):
        ctx = _active_run_ctx.get()
        if ctx is None:
            return await fn(inputs)

        # ── RESUME LOGIC ─────────────────────────────────────────────────────
        # When re-executing a workflow that was interrupted, nodes that already
        # completed must be skipped (returning stored output) and interrupted
        # nodes are handled per _effective_logic.
        # _force_fresh bypasses this entire block when an ancestor node is in
        # "rerun" mode, ensuring its subtree executes fresh regardless of DB state.
        if ctx.get("_is_resume") and not ctx.get("_force_fresh"):
            resume_parent_slot = _active_node_slot.get()
            resume_parent_db_id: int | None = (
                resume_parent_slot["_db_id"] if resume_parent_slot is not None else None
            )
            resume_queue: list = ctx.get("_resumed_by_parent", {}).get(
                resume_parent_db_id, []
            )

            if resume_queue and resume_queue[0].name == fn.__name__:
                prev_node_row = resume_queue[0]

                if prev_node_row.status == WorkflowStatus.success:
                    # Already completed — skip execution, return stored output.
                    resume_queue.pop(0)
                    ctx.setdefault("_executed_names", set()).add(fn.__name__)
                    skip_slot: dict = {"_db_id": prev_node_row.id, "name": fn.__name__}
                    skip_token = _active_node_slot.set(skip_slot)
                    try:
                        stored = (prev_node_row.data or {}).get("outputs", {})
                        return stored if return_meta else _strip_meta(stored)
                    finally:
                        _active_node_slot.reset(skip_token)

                elif prev_node_row.status == WorkflowStatus.running:
                    # Node was mid-execution when server crashed.
                    if _effective_logic is not None and _effective_logic.mode == "skip":
                        resume_queue.pop(0)
                        ctx.setdefault("_executed_names", set()).add(fn.__name__)
                        await update_run_node(
                            prev_node_row.id,
                            node_status=WorkflowStatus.success,
                            duration_ms=0,
                            inputs=inputs,
                            outputs={},
                            logs=None,
                        )
                        skipped_slot: dict = {
                            "_db_id": prev_node_row.id,
                            "name": fn.__name__,
                        }
                        skipped_token = _active_node_slot.set(skipped_slot)
                        try:
                            run_id_for_broadcast = ctx.get("run_id")
                            if run_id_for_broadcast is not None:
                                await broadcast_node_update(
                                    run_id=run_id_for_broadcast,
                                    db_id=prev_node_row.id,
                                    name=fn.__name__,
                                    slug=slug,
                                    status=WorkflowStatus.success.value,
                                    duration_ms=0,
                                    started_at=prev_node_row.started_at,
                                    parent_node_id=prev_node_row.parent_node_id,
                                    parent_run_id=ctx.get("parent_run_id"),
                                )
                            return {} if return_meta else {}
                        finally:
                            _active_node_slot.reset(skipped_token)

                    if (
                        _effective_logic is not None
                        and _effective_logic.mode == "mock_on_side_effect"
                        and _effective_logic.side_effect_check is not None
                    ):
                        check_result = await _effective_logic.side_effect_check(inputs)
                        if check_result is not None:
                            resume_queue.pop(0)
                            ctx.setdefault("_executed_names", set()).add(fn.__name__)
                            await update_run_node(
                                prev_node_row.id,
                                node_status=WorkflowStatus.success,
                                duration_ms=0,
                                inputs=inputs,
                                outputs=check_result,
                                logs=None,
                            )
                            checked_slot: dict = {
                                "_db_id": prev_node_row.id,
                                "name": fn.__name__,
                            }
                            checked_token = _active_node_slot.set(checked_slot)
                            try:
                                run_id_for_broadcast = ctx.get("run_id")
                                if run_id_for_broadcast is not None:
                                    await broadcast_node_update(
                                        run_id=run_id_for_broadcast,
                                        db_id=prev_node_row.id,
                                        name=fn.__name__,
                                        slug=slug,
                                        status=WorkflowStatus.success.value,
                                        duration_ms=0,
                                        started_at=prev_node_row.started_at,
                                        parent_node_id=prev_node_row.parent_node_id,
                                        parent_run_id=ctx.get("parent_run_id"),
                                    )
                                return (
                                    check_result
                                    if return_meta
                                    else _strip_meta(check_result)
                                )
                            finally:
                                _active_node_slot.reset(checked_token)

                    # "rerun" mode, no logic, or mock_on_side_effect returning None:
                    # re-execute the node body.
                    # For "rerun" mode, flag all nested nodes/sub-workflows to also
                    # run fresh (not consult the resume queue).
                    if (
                        _effective_logic is not None
                        and _effective_logic.mode == "rerun"
                    ):
                        ctx["_set_force_fresh"] = True

                    resume_queue.pop(0)
                    await _cancel_running_descendants(prev_node_row.id)
                    ctx["_reuse_node_db_id"] = prev_node_row.id
                elif prev_node_row.status == WorkflowStatus.failed:
                    # Node already failed before the crash — skip re-execution
                    # and re-raise the stored error so callers handle it the same
                    # way as the original failure. The history badge was already
                    # written; we don't touch it again.
                    resume_queue.pop(0)
                    ctx.setdefault("_executed_names", set()).add(fn.__name__)
                    skip_slot_f: dict = {
                        "_db_id": prev_node_row.id,
                        "name": fn.__name__,
                    }
                    skip_token_f = _active_node_slot.set(skip_slot_f)
                    try:
                        error_msg = (prev_node_row.data or {}).get(
                            "error",
                            f"node '{fn.__name__}' failed before server restart",
                        )
                        raise RuntimeError(error_msg)
                    finally:
                        _active_node_slot.reset(skip_token_f)

        # ── END RESUME LOGIC ─────────────────────────────────────────────────

        node_start = datetime.now(timezone.utc)
        node_logs: list[dict] = []
        logs_token = _active_node_logs.set(node_logs)

        parent_slot = _active_node_slot.get()
        parent_db_id: int | None = (
            parent_slot["_db_id"] if parent_slot is not None else None
        )

        run_id = ctx.get("run_id")
        parent_run_id: int | None = ctx.get("parent_run_id")
        run_meta = ctx.get("_run_meta")

        # INSERT a new row or reuse the existing row for a re-run node.
        _reuse_db_id: int | None = ctx.pop("_reuse_node_db_id", None)
        _force_fresh_for_this_node: bool = ctx.pop("_set_force_fresh", False)
        if _force_fresh_for_this_node:
            ctx["_force_fresh"] = True

        if _reuse_db_id is not None:
            db_id = _reuse_db_id
            await _reset_node_for_rerun(_reuse_db_id, node_start)
        else:
            db_id = await insert_run_node(
                run_id=run_id,
                parent_db_id=parent_db_id,
                name=fn.__name__,
                slug=slug,
                inputs=inputs,
                started_at=node_start,
            )

        # Thin slot: carries DB id so child nodes can reference it as parent.
        slot: dict = {"_db_id": db_id, "name": fn.__name__}
        slot_token = _active_node_slot.set(slot)
        ctx.setdefault("_executed_names", set()).add(fn.__name__)

        if run_id is not None:
            await broadcast_node_update(
                run_id=run_id,
                db_id=db_id,
                name=fn.__name__,
                slug=slug,
                status=WorkflowStatus.running.value,
                duration_ms=0,
                started_at=node_start,
                parent_node_id=parent_db_id,
                parent_run_id=parent_run_id,
            )

        # Resolve row-tracking context once, before execution starts.
        _row_table_id: int | None = None
        _row_id: int | None = None
        if tracks_row and run_id is not None:
            tac = (
                (ctx.get("_run_meta") or {})
                .get("triggerContext", {})
                .get("table_action_context")
            )
            if tac:
                _row_table_id = tac.get("table_id")
                _row_id = inputs.get("row_id")
                if not isinstance(_row_id, int):
                    try:
                        _row_id = int(_row_id)
                    except (TypeError, ValueError):
                        _row_id = None

        # Broadcast a per-row "running" status so the frontend can show a loading
        # badge immediately when this node starts processing its row.  This covers
        # the case where the workflow was triggered without pre-selected rowIds
        # (e.g. selected_only=False with no rows checked), where run_created
        # alone cannot tell the frontend which rows will be affected.
        if _row_table_id is not None and _row_id is not None and run_id is not None:
            wf_name_for_broadcast: str | None = (ctx.get("_run_meta") or {}).get("name")
            from ..broadcast import manager as _mgr

            await _mgr.broadcast(
                f"table:{_row_table_id}",
                {
                    "type": "row_run_status",
                    "runId": run_id,
                    "rowId": _row_id,
                    "status": "running",
                    **(
                        {"wfName": wf_name_for_broadcast}
                        if wf_name_for_broadcast
                        else {}
                    ),
                },
            )

        _exc: Exception | None = None
        _result = None
        final_status: WorkflowStatus = WorkflowStatus.running
        final_outputs: dict = {}
        final_logs: list | None = None

        try:
            _result = await fn(inputs)
            final_status = WorkflowStatus.success
            if isinstance(_result, dict):
                final_outputs = _result
            elif _result is not None:
                final_outputs = {"result": _result}
            final_logs = node_logs if node_logs else None
        except Exception as exc:
            _exc = exc
            final_status = WorkflowStatus.failed
            final_logs = [
                *node_logs,
                {
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "body": traceback.format_exc(),
                    "type": "error",
                    "json": False,
                },
            ]
        finally:
            if _force_fresh_for_this_node:
                ctx["_force_fresh"] = False
            duration_ms = int(
                (datetime.now(timezone.utc) - node_start).total_seconds() * 1000
            )
            dlog(
                "NODE",
                fn.__name__,
                duration_ms,
                extra=f"status={final_status.value}"
                + (f" slug={slug}" if slug else ""),
            )
            _active_node_logs.reset(logs_token)
            _active_node_slot.reset(slot_token)

            if final_status != WorkflowStatus.running and run_id is not None:
                await update_run_node(
                    db_id,
                    node_status=final_status,
                    duration_ms=duration_ms,
                    inputs=inputs,
                    outputs=final_outputs,
                    logs=final_logs,
                )
                if _row_table_id is not None and _row_id is not None:
                    await flush_single_row_history(
                        ctx,
                        _row_table_id,
                        _row_id,
                        node_slot=slot,
                        failed_exc=_exc,
                    )

            if run_id is not None:
                await broadcast_node_update(
                    run_id=run_id,
                    db_id=db_id,
                    name=fn.__name__,
                    slug=slug,
                    status=final_status.value,
                    duration_ms=duration_ms,
                    started_at=node_start,
                    parent_node_id=parent_db_id,
                    parent_run_id=parent_run_id,
                )

        if _exc is not None:
            raise _exc
        if not return_meta and isinstance(_result, dict) and "_meta" in _result:
            return _strip_meta(_result)
        return _result

    wrapper._gtm_fn = fn
    wrapper._server_restart_logic = _effective_logic
    return wrapper
