from __future__ import annotations

import asyncio
from typing import Any


async def _recover_from_restart(session: Any, wrappers: dict) -> None:
    """Resume interrupted running runs, then kick off pending ones.

    Workflow runs left in ``running`` state from a crashed server are re-executed
    starting from the node that was interrupted.  Runs whose workflow is no longer
    registered (no wrapper) are cancelled instead.  Pending runs are re-queued by
    starting the drain loop for each affected workflow.
    """
    from datetime import datetime, timezone

    from sqlmodel import select

    from sqlalchemy import update as _sa_update

    from .decorator import _ensure_drain_task, _notify_drain, _resume_existing_run
    from .models import Workflow, WorkflowRun, WorkflowStatus

    now = datetime.now(timezone.utc)

    # ── Query 1: find orphaned running runs (slim columns — skip data JSONB) ───
    # Only top-level runs (parent_id IS NULL) are independently resumed; child
    # runs are handled recursively through their parent's resume.
    orphaned_rows = list(
        (
            await session.execute(
                select(WorkflowRun.id, WorkflowRun.workflow_id).where(
                    WorkflowRun.status == WorkflowStatus.running,
                    WorkflowRun.parent_id == None,  # noqa: E711
                )
            )
        ).all()
    )

    cancel_ids: list[int] = []
    to_resume: list[tuple[int, str]] = []  # (run_id, wf_name)

    if orphaned_rows:
        # ── Query 2: look up workflow names for orphaned runs ──────────────────
        wf_ids = list({row.workflow_id for row in orphaned_rows})
        wf_list = list(
            (await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))).all()
        )
        wf_id_to_name = {wf.id: wf.name for wf in wf_list}

        for row in orphaned_rows:
            wf_name = wf_id_to_name.get(row.workflow_id)
            if wf_name is not None and wf_name in wrappers:
                to_resume.append((row.id, wf_name))
            else:
                cancel_ids.append(row.id)

    if cancel_ids:
        await session.execute(
            _sa_update(WorkflowRun)
            .where(WorkflowRun.id.in_(cancel_ids))
            .values(status=WorkflowStatus.cancelled, finished_at=now)
        )
        await session.commit()

    # Schedule resume tasks (runs as asyncio tasks after startup completes).
    for run_id, wf_name in to_resume:
        wrapper = wrappers[wf_name]
        fn = getattr(wrapper, "_gtm_fn", wrapper)
        restart_logic = getattr(wrapper, "_server_restart_logic", None)
        if restart_logic is None:
            from .decorator.restart import ServerRestartLogic

            old_check = getattr(wrapper, "_restart_on_failure_check", None)
            if old_check is not None:
                restart_logic = ServerRestartLogic(
                    mode="mock_on_side_effect", side_effect_check=old_check
                )
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(
                _resume_existing_run(
                    fn, run_id, wf_name, restart_logic, wrappers=wrappers
                ),
                name=f"gtm_resume_{wf_name}_{run_id}",
            )
        except RuntimeError:
            pass

    # ── Query 3: pending runs — re-queue drain loops ───────────────────────────
    pending_wf_names = list(
        (
            await session.exec(
                select(Workflow.name)
                .join(WorkflowRun, WorkflowRun.workflow_id == Workflow.id)
                .where(WorkflowRun.status == WorkflowStatus.pending)
                .distinct()
            )
        ).all()
    )

    for wf_name in pending_wf_names:
        if wf_name in wrappers:
            raw_fn = getattr(wrappers[wf_name], "_gtm_fn", wrappers[wf_name])
            _ensure_drain_task(wf_name, raw_fn)
            _notify_drain(wf_name)
