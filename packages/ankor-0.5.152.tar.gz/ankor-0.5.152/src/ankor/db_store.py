"""Programmatic read/write access to the DB tables.

Exposed as ``ak.db`` on a ``ankor`` instance so that workflow and node
functions can query and mutate table rows without going through the HTTP API.

Each table is identified by its **name** (the ``name`` column of the
``data_tables`` registry). Rows are plain ``dict`` objects that always
contain an ``"id"`` key (integer) alongside any column values.

Example::

    @ak.workflow
    async def sync_customers(inputs: dict):
        rows = await ak.db.rows("Customers")
        for row in rows:
            if not row.get("col-6"):   # active == False
                await ak.db.update_row("Customers", row["id"], {"col-6": True})
        new = await ak.db.add_row("Customers", {"col-2": "Dana Lee", "col-6": True})
        return {"processed": len(rows), "new_id": new["id"]}
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import text

from ._debug import dlog, _sizeof
from .db_helpers import (
    OrderBy,
    RowFilter,
    _build_order_by,
    _build_select_cols,
    _build_where,
    _coerce_for_write,
    _ensure_tables,
    _normalize_row,
    _pg_table,
    _read_col_types,
    _read_select_opts_lookup,
    _SYSTEM_COLS,
    _upsert_row,
    _qi,
    coerce_csv_value,
)

from ._db_history import flush_row_history, flush_single_row_history

# Re-export public types so callers can still do `from .db_store import RowFilter, OrderBy`
__all__ = [
    "DbStore",
    "OrderBy",
    "RowFilter",
    "coerce_csv_value",
    "flush_single_row_history",
    "flush_row_history",
    "_ensure_tables",
    "_pg_table",
]


def _record_db_action(
    op: str, table: str, inputs: dict, outputs: dict, duration_ms: int
) -> None:
    from .decorator import DbActionRecord, record_db_action

    dlog("DB", f"{op}({table})", duration_ms, _sizeof(outputs))
    record_db_action(op, table, DbActionRecord(inputs, outputs, duration_ms))


class DbStore:
    """Thin async wrapper around real PostgreSQL data tables.

    Attached to ``ankor`` as ``ak.db``.
    """

    @staticmethod
    async def _fetch_registry(session: Any, table_name: str) -> Any:
        from sqlmodel import select

        from .models import DataTable

        result = await session.exec(
            select(DataTable).where(DataTable.name == table_name)
        )
        table = result.first()
        if table is None:
            raise KeyError(f"Table {table_name!r} not found.")
        return table

    async def rows(
        self,
        table_name: str,
        filters: list[RowFilter] | None = None,
        columns: list[str] | None = None,
        order_by: "OrderBy | None" = None,
    ) -> list[dict]:
        """Return rows from the named table as a list of plain ``dict``\\s.

        Pass *filters* to restrict which rows are returned::

            from ankor import RowFilter

            rows = await ak.db.rows("Deals", filters=[
                RowFilter("amount", "gt", 1000),
                RowFilter("status", "eq", "active"),
            ])

        Pass *columns* to return only specific fields (``id`` is always included)::

            rows = await ak.db.rows("Deals", columns=["amount", "status"])

        Pass *order_by* to control sort order::

            from ankor import OrderBy

            rows = await ak.db.rows("Deals", order_by=OrderBy("amount", "desc"))
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            return []
        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            tbl = _pg_table(t.id)
            col_types = await _read_col_types(session, tbl)
            if columns:
                valid_cols = set(col_types) | _SYSTEM_COLS
                invalid = [c for c in columns if c not in valid_cols]
                if invalid:
                    raise ValueError(
                        f"Unknown columns: {invalid!r}. "
                        f"Valid columns: {sorted(valid_cols)}"
                    )
            where_sql, params = _build_where(filters or [])
            select_sql = _build_select_cols(columns)
            order_sql = _build_order_by(order_by)
            sql = f"SELECT {select_sql} FROM {tbl}{where_sql} ORDER BY {order_sql}"
            result = await session.execute(text(sql), params)
            rows = [_normalize_row(r._mapping, col_types) for r in result]
        _record_db_action(
            "rows",
            table_name,
            {
                "filters": len(filters or []),
                "columns": columns,
                "order_by": order_by.column if order_by else None,
            },
            {"rows": rows, "count": len(rows)},
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        return rows

    async def get_row(self, table_name: str, row_id: int) -> dict | None:
        """Return a single row by its ``id``, or ``None`` if not found."""
        from .database import _SessionLocal

        if _SessionLocal is None:
            return None
        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            tbl = _pg_table(t.id)
            col_types = await _read_col_types(session, tbl)
            result = await session.execute(
                text(f"SELECT * FROM {tbl} WHERE id = :row_id"),
                {"row_id": row_id},
            )
            row = result.first()
            found = _normalize_row(row._mapping, col_types) if row else None
        _record_db_action(
            "get_row",
            table_name,
            {"id": row_id},
            {"row": found},
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        return found

    async def add_row(self, table_name: str, data: dict[str, Any]) -> dict:
        """Append a new row to the named table.

        A unique integer ``id`` is assigned automatically. Returns the stored row dict.
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            col_types = await _read_col_types(session, tbl)
            select_opts = await _read_select_opts_lookup(session, table_id)
            for _sc in select_opts:
                if _sc in col_types:
                    col_types[_sc] = "select"
            max_id: int = (
                await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))
            ) or 0
            new_id = max_id + 1
            row = {
                "id": new_id,
                **{
                    k: _coerce_for_write(
                        v, col_types.get(k, "text"), select_opts.get(k)
                    )
                    for k, v in data.items()
                    if k != "id"
                },
            }
            await _upsert_row(session, tbl, row, list(col_types.keys()))
            result = await session.execute(
                text(f"SELECT * FROM {tbl} WHERE id = :row_id"), {"row_id": new_id}
            )
            stored = result.first()
            await session.commit()
            stored_row = _normalize_row(stored._mapping, col_types) if stored else row
        _record_db_action(
            "add_row",
            table_name,
            {k: v for k, v in data.items() if k != "id"},
            stored_row,
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        from .broadcast import manager

        await manager.broadcast(f"table:{table_id}", {"type": "rows_changed"})
        return stored_row

    async def add_rows(self, table_name: str, rows: list[dict[str, Any]]) -> list[dict]:
        """Bulk-insert multiple rows in a single DB round-trip.

        IDs are assigned sequentially from the current maximum. Returns the
        stored row dicts in insertion order.
        """
        if not rows:
            return []

        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )

        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            col_types = await _read_col_types(session, tbl)
            select_opts = await _read_select_opts_lookup(session, table_id)

            for _sc in select_opts:
                if _sc in col_types:
                    col_types[_sc] = "select"

            max_id: int = (
                await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))
            ) or 0

            # Ordered union of column keys across all rows, restricted to known DB columns
            col_keys = [
                k
                for k in dict.fromkeys(k for r in rows for k in r if k != "id")
                if k in col_types
            ]
            col_q = [_qi(k) for k in col_keys]

            params: dict[str, Any] = {}
            value_rows = []

            for ri, data in enumerate(rows):
                params[f"id{ri}"] = max_id + 1 + ri
                for ci, k in enumerate(col_keys):
                    params[f"v{ri}_{ci}"] = _coerce_for_write(
                        data.get(k), col_types.get(k, "text"), select_opts.get(k)
                    )
                col_phs = ", ".join(f":v{ri}_{ci}" for ci in range(len(col_keys)))
                value_rows.append(
                    f"(:id{ri}, NOW(), NOW(), {col_phs})"
                    if col_phs
                    else f"(:id{ri}, NOW(), NOW())"
                )

            col_header = (
                f"id, created_at, updated_at, {', '.join(col_q)}"
                if col_q
                else "id, created_at, updated_at"
            )
            sql = f"INSERT INTO {tbl} ({col_header}) VALUES {', '.join(value_rows)} RETURNING *"
            result = await session.execute(text(sql), params)
            stored = [_normalize_row(r._mapping, col_types) for r in result]
            await session.commit()

        _record_db_action(
            "add_rows",
            table_name,
            {"count": len(rows)},
            {"rows": stored, "count": len(stored)},
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        from .broadcast import manager

        await manager.broadcast(f"table:{table_id}", {"type": "rows_changed"})
        return stored

    async def update_row(
        self,
        table_name: str,
        row_id: int,
        data: dict[str, Any],
    ) -> dict:
        """Merge *data* into an existing row and return ``{"old": ..., "new": ..., "_meta": ...}``.

        Raises :class:`KeyError` if *row_id* is not found.
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        from .decorator._context import _active_run_ctx

        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            # Lazy-add history column for tables created before this feature.
            await session.execute(
                text(
                    f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS "
                    f"history JSONB NOT NULL DEFAULT '[]'"
                )
            )
            col_types = await _read_col_types(session, tbl)
            select_opts = await _read_select_opts_lookup(session, table_id)
            for _sc in select_opts:
                if _sc in col_types:
                    col_types[_sc] = "select"
            old_result = await session.execute(
                text(f"SELECT * FROM {tbl} WHERE id = :row_id"), {"row_id": row_id}
            )
            old_row_raw = old_result.first()
            if old_row_raw is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")
            old_row = _normalize_row(old_row_raw._mapping, col_types)
            update_data = {
                k: _coerce_for_write(v, col_types.get(k, "text"), select_opts.get(k))
                for k, v in data.items()
                if k in col_types
            }
            if not update_data:
                return {
                    "old": old_row,
                    "new": old_row,
                    "_meta": {
                        "views": [
                            {"key": "old", "type": "json"},
                            {"key": "new", "type": "json"},
                        ]
                    },
                }

            run_ctx = _active_run_ctx.get()

            params: dict[str, Any] = {"row_id": row_id}
            set_clauses = ["updated_at = NOW()"]
            for i, (k, v) in enumerate(update_data.items()):
                set_clauses.append(f"{_qi(k)} = :v{i}")
                params[f"v{i}"] = v

            now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
            if run_ctx is not None:
                # Inside a workflow run — register the row so flush_row_history writes
                # a history entry at the end.  No actions accumulated any more.
                from .decorator._context import _active_node_slot

                _active_slot = _active_node_slot.get()
                _node_db_id: int | None = (
                    _active_slot.get("_db_id") if _active_slot else None
                )
                row_history: dict = run_ctx.setdefault("_row_history", {})
                key = (table_id, row_id)
                row_history.setdefault(
                    key, {"wr_id": run_ctx.get("run_id"), "_node_db_id": _node_db_id}
                )
                row_history[key].setdefault("_changed_cols", set()).update(
                    update_data.keys()
                )
                result = await session.execute(
                    text(
                        f"UPDATE {tbl} SET {', '.join(set_clauses)} WHERE id = :row_id RETURNING *"
                    ),
                    params,
                )
            else:
                # Called outside a workflow — write history pointer immediately.
                history_entry = {
                    "wr_id": None,
                    "node_run_id": None,
                    "actions": [{"type": "row_update", "state": old_row}],
                }
                set_clauses.append(
                    "history = COALESCE(history, '[]'::jsonb) || CAST(:history_entry AS jsonb)"
                )
                params["history_entry"] = json.dumps([history_entry])
                result = await session.execute(
                    text(
                        f"UPDATE {tbl} SET {', '.join(set_clauses)} WHERE id = :row_id RETURNING *"
                    ),
                    params,
                )

            updated = result.first()
            if updated is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")
            await session.commit()
            updated_row = _normalize_row(updated._mapping, col_types)
        output = {
            "old": old_row,
            "new": updated_row,
            "_meta": {
                "views": [
                    {"key": "diff", "type": "diff", "from": "old", "to": "new"},
                    {"key": "old", "type": "json"},
                    {"key": "new", "type": "json"},
                ]
            },
        }
        _record_db_action(
            "update_row",
            table_name,
            {"id": row_id, "data": data},
            output,
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        from .broadcast import manager

        json_col_ids = {k for k, v in col_types.items() if v == "json"}
        broadcast_row = {k: v for k, v in updated_row.items() if k not in json_col_ids}
        await manager.broadcast(
            f"table:{table_id}", {"type": "row_updated", "row": broadcast_row}
        )
        return output

    async def update_rows(
        self,
        table_name: str,
        rows: list[dict[str, Any]],
    ) -> int:
        """Update multiple rows in a single SQL statement using a VALUES list.

        Each dict in *rows* must contain an ``"id"`` key plus the columns to
        update.  All dicts must share the same set of columns (aside from
        ``"id"``).  Returns the number of rows actually updated.

        Example::

            await ak.db.update_rows("Employees", [
                {"id": 1, "salary": 95000, "department": "Engineering"},
                {"id": 2, "salary": 82000, "department": "Marketing"},
            ])
        """
        if not rows:
            return 0

        # Validate that every dict has "id" and collect column names.
        col_names: list[str] | None = None
        for r in rows:
            if "id" not in r:
                raise ValueError("Every row dict must contain an 'id' key.")
            cols = [k for k in r if k != "id"]
            if col_names is None:
                col_names = cols
            elif set(cols) != set(col_names):
                raise ValueError("All row dicts must have the same set of columns.")

        if not col_names:
            return 0

        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        from .decorator._context import _active_run_ctx

        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            await session.execute(
                text(
                    f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS "
                    f"history JSONB NOT NULL DEFAULT '[]'"
                )
            )
            col_types = await _read_col_types(session, tbl)
            select_opts = await _read_select_opts_lookup(session, table_id)
            for _sc in select_opts:
                if _sc in col_types:
                    col_types[_sc] = "select"

            # Filter to only known columns.
            valid_cols = [c for c in col_names if c in col_types]
            if not valid_cols:
                return 0

            # Map internal col types to Postgres type names for CAST().
            # Only the first VALUES row needs casts — Postgres uses it to infer
            # types for the whole VALUES list.
            _PG_TYPE: dict[str, str] = {
                "integer": "bigint",
                "select": "bigint",
                "float": "double precision",
                "boolean": "boolean",
                "date": "date",
                "json": "jsonb",
            }

            # Build VALUES placeholders: (id, col0, col1, ...)
            value_rows = []
            params: dict[str, Any] = {}
            for ri, row in enumerate(rows):
                coerced_id = int(row["id"])
                id_ph_key = f"r{ri}_id"
                params[id_ph_key] = coerced_id
                if ri == 0:
                    id_expr = f"CAST(:{id_ph_key} AS bigint)"
                else:
                    id_expr = f":{id_ph_key}"
                placeholders = [id_expr]
                for ci, col in enumerate(valid_cols):
                    ph_key = f"r{ri}_c{ci}"
                    params[ph_key] = _coerce_for_write(
                        row.get(col), col_types.get(col, "text"), select_opts.get(col)
                    )
                    if ri == 0 and col_types.get(col) in _PG_TYPE:
                        placeholders.append(
                            f"CAST(:{ph_key} AS {_PG_TYPE[col_types[col]]})"
                        )
                    else:
                        placeholders.append(f":{ph_key}")
                value_rows.append(f"({', '.join(placeholders)})")

            col_defs = ", ".join([f"{_qi(c)}" for c in ["id"] + valid_cols])
            set_clauses = (
                ", ".join([f"{_qi(c)} = v.{_qi(c)}" for c in valid_cols])
                + ", updated_at = NOW()"
            )

            run_ctx = _active_run_ctx.get()
            if run_ctx is not None:
                from .decorator._context import _active_node_slot

                _active_slot = _active_node_slot.get()
                _node_db_id: int | None = (
                    _active_slot.get("_db_id") if _active_slot else None
                )
                row_history: dict = run_ctx.setdefault("_row_history", {})
                for row in rows:
                    key = (table_id, int(row["id"]))
                    row_history.setdefault(
                        key,
                        {"wr_id": run_ctx.get("run_id"), "_node_db_id": _node_db_id},
                    )
                    row_history[key].setdefault("_changed_cols", set()).update(
                        valid_cols
                    )

            sql = (
                f"UPDATE {tbl} SET {set_clauses} "
                f"FROM (VALUES {', '.join(value_rows)}) "
                f"AS v({col_defs}) "
                f"WHERE {tbl}.id = v.id"
            )
            result = await session.execute(text(sql), params)
            updated_count: int = result.rowcount
            await session.commit()

        _record_db_action(
            "update_rows",
            table_name,
            {"count": len(rows), "columns": valid_cols},
            {"updated": updated_count},
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        from .broadcast import manager

        await manager.broadcast(
            f"table:{table_id}", {"type": "rows_updated", "count": updated_count}
        )
        return updated_count

    async def note(self, table_name: str, row_id: int, text_: str) -> None:
        """Append a note to a row's history without modifying any column values.

        Raises :class:`KeyError` if *row_id* is not found.
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        from .decorator._context import _active_run_ctx

        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            await session.execute(
                text(
                    f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS "
                    f"history JSONB NOT NULL DEFAULT '[]'"
                )
            )
            col_types = await _read_col_types(session, tbl)
            result = await session.execute(
                text(f"SELECT id FROM {tbl} WHERE id = :row_id"), {"row_id": row_id}
            )
            if result.first() is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")

            run_ctx = _active_run_ctx.get()
            now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)

            if run_ctx is not None:
                # Inside a workflow run — register the row so flush_row_history
                # writes a history entry at the end.
                from .decorator._context import _active_node_slot

                _active_slot = _active_node_slot.get()
                _node_db_id: int | None = (
                    _active_slot.get("_db_id") if _active_slot else None
                )
                row_history: dict = run_ctx.setdefault("_row_history", {})
                key = (table_id, row_id)
                row_history.setdefault(
                    key, {"wr_id": run_ctx.get("run_id"), "_node_db_id": _node_db_id}
                )
                await session.close()
            else:
                # Outside a workflow — write history pointer immediately.
                history_entry = {
                    "wr_id": None,
                    "node_run_id": None,
                    "actions": [{"type": "note", "data": text_}],
                }
                await session.execute(
                    text(
                        f"UPDATE {tbl} SET "
                        "history = COALESCE(history, '[]'::jsonb) || CAST(:entry AS jsonb), "
                        "updated_at = NOW() "
                        "WHERE id = :row_id"
                    ),
                    {"entry": json.dumps([history_entry]), "row_id": row_id},
                )
                await session.commit()
                # Fetch updated row for broadcast
                updated_result = await session.execute(
                    text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
                )
                updated_raw = updated_result.first()
                if updated_raw is not None:
                    from .broadcast import manager

                    json_col_ids = {k for k, v in col_types.items() if v == "json"}
                    normalized = _normalize_row(updated_raw._mapping, col_types)
                    broadcast_row = {
                        k: v for k, v in normalized.items() if k not in json_col_ids
                    }
                    await manager.broadcast(
                        f"table:{table_id}",
                        {"type": "row_updated", "row": broadcast_row},
                    )
        _record_db_action(
            "note",
            table_name,
            {"id": row_id, "note": text_},
            {},
            int((datetime.now() - t0).total_seconds() * 1000),
        )

    async def delete_row(self, table_name: str, row_id: int) -> None:
        """Remove a row by its ``id``.  Raises :class:`KeyError` if not found."""
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            result = await session.execute(
                text(f"DELETE FROM {tbl} WHERE id = :row_id RETURNING id"),
                {"row_id": row_id},
            )
            deleted = result.first()
            if deleted is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")
            await session.commit()
        _record_db_action(
            "delete_row",
            table_name,
            {"id": row_id},
            {},
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        from .broadcast import manager

        await manager.broadcast(f"table:{table_id}", {"type": "rows_changed"})
