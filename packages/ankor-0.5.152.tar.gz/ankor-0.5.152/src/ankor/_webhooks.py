from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from fastapi import Request
from fastapi.responses import JSONResponse, Response

if TYPE_CHECKING:
    from fastapi import FastAPI

_TYPE_MAP = {
    "string": {"type": "string"},
    "text": {"type": "string"},
    "number": {"type": "number"},
    "boolean": {"type": "boolean"},
}


def _build_body_schema(input_schema: list[dict]) -> dict | None:
    if not input_schema:
        return None

    properties: dict = {}
    required: list[str] = []

    for field in input_schema:
        key = field["key"]
        ftype = field.get("type", "string")

        prop: dict = dict(_TYPE_MAP.get(ftype, {}))

        if field.get("label"):
            prop["title"] = field["label"]
        if field.get("description"):
            prop["description"] = field["description"]
        if field.get("default") is not None:
            prop["default"] = field["default"]
        if ftype == "select" and field.get("options"):
            prop["type"] = "string"
            prop["enum"] = field["options"]

        properties[key] = prop

        if field.get("required"):
            required.append(key)

    schema: dict = {"type": "object", "properties": properties}

    if required:
        schema["required"] = required

    return schema


def register_webhook(
    app: "FastAPI",
    name: str,
    wrapper: Any,
    webhook_workflows: dict,
    background: Any = False,
    description: str | None = None,
    input_schema: list[dict] | None = None,
) -> None:
    """Mount POST /api/webhooks/{name} that calls the workflow.

    Sync mode (default, ``background=False``):
        The HTTP connection stays open until the function finishes.
        The function's return value drives the response:
        - ``None``     → ``200 {"status": "success"}``
        - ``dict``     → ``200`` with that dict as the JSON body
        - ``Response`` → passed through as-is (full control over status/headers)

    Background mode (``background=True | dict | Response``):
        Responds immediately; the workflow runs as an asyncio task.
        - ``True``       → ``202 {"status": "accepted"}``
        - ``dict``       → ``202`` with that dict as the JSON body
        - ``Response``   → exactly that response
        The function's return value is ignored.
    """
    path = f"/api/webhooks/{name}"

    _body_schema = _build_body_schema(input_schema or [])
    _openapi_extra: dict | None = (
        {
            "requestBody": {
                "required": True,
                "content": {"application/json": {"schema": _body_schema}},
            }
        }
        if _body_schema
        else None
    )
    _post_kwargs: dict = {"tags": ["webhooks"]}
    if description:
        _post_kwargs["summary"] = description
    if _openapi_extra:
        _post_kwargs["openapi_extra"] = _openapi_extra

    async def _auth_ok(request: Request) -> bool:
        from .auth import verify_webhook_token
        from .database import _SessionLocal
        from .models import WebhookToken

        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return False
        provided = auth[7:]
        if _SessionLocal is None:
            return False
        async with _SessionLocal() as _s:
            wt = await _s.get(WebhookToken, "default")
        return wt is not None and verify_webhook_token(provided, wt.token)

    if background is not False:
        # Resolve the immediate response once at decoration time.
        if isinstance(background, Response):
            _imm = background
        elif isinstance(background, dict):
            _imm = JSONResponse(content=background, status_code=202)
        else:  # True
            _imm = JSONResponse(content={"status": "accepted"}, status_code=202)

        @app.post(path, **_post_kwargs)
        async def _webhook_handler_bg(request: Request) -> Response:
            if not await _auth_ok(request):
                return JSONResponse(status_code=401, content={"error": "Unauthorized"})
            from .database import _SessionLocal
            from .models import WorkflowConfig
            from .trigger_context import TriggerContext, _safe_headers

            if _SessionLocal is not None:
                from sqlmodel import select as _select

                async with _SessionLocal() as _s:
                    _cfg = (
                        await _s.exec(
                            _select(WorkflowConfig).where(WorkflowConfig.name == name)
                        )
                    ).first()
                    if _cfg is not None and not _cfg.enabled:
                        return JSONResponse(
                            status_code=503,
                            content={"error": "Workflow is disabled"},
                        )
            try:
                body = await request.json()
            except Exception:
                body = {}
            inputs = {"body": body, "headers": _safe_headers(request.headers)}
            ctx = TriggerContext("webhook", inputs)

            async def _run() -> None:
                try:
                    await wrapper(inputs, _ctx=ctx)
                except Exception:
                    pass  # already recorded in DB by make_workflow_wrapper

            asyncio.create_task(_run())
            return _imm

    else:

        @app.post(path, **_post_kwargs)
        async def _webhook_handler(request: Request) -> Response:
            if not await _auth_ok(request):
                return JSONResponse(status_code=401, content={"error": "Unauthorized"})
            from .database import _SessionLocal
            from .models import WorkflowConfig
            from .trigger_context import TriggerContext, _safe_headers

            if _SessionLocal is not None:
                from sqlmodel import select as _select

                async with _SessionLocal() as _s:
                    _cfg = (
                        await _s.exec(
                            _select(WorkflowConfig).where(WorkflowConfig.name == name)
                        )
                    ).first()
                    if _cfg is not None and not _cfg.enabled:
                        return JSONResponse(
                            status_code=503,
                            content={"error": "Workflow is disabled"},
                        )
            try:
                body = await request.json()
            except Exception:
                body = {}
            inputs = {"body": body, "headers": _safe_headers(request.headers)}
            ctx = TriggerContext("webhook", inputs)
            try:
                result = await wrapper(inputs, _ctx=ctx)
            except Exception as exc:
                return JSONResponse(status_code=500, content={"error": str(exc)})
            if isinstance(result, Response):
                return result
            if isinstance(result, dict):
                return JSONResponse(content=result)
            return JSONResponse(content={"status": "success"})

    webhook_workflows[name] = wrapper
