from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from .types import NodeFn, WorkflowFn
from ._debug import patch_httpx
from ._startup import _recover_from_restart
from ._webhooks import register_webhook

if TYPE_CHECKING:
    from fastapi import FastAPI

STATIC_DIR = Path(__file__).parent / "static"


class ankor:
    def __init__(
        self,
        app: "FastAPI",
        db_url: str,
        secret: str,
        dev: bool = False,
        auto_seed: bool = False,
        tables: list[dict] | None = None,
        show_docs: bool = True,
    ) -> None:
        from .auth import configure
        from .database import setup_engine

        configure(secret)
        setup_engine(db_url)

        # Decorator sub-modules hold their own _SessionLocal reference that
        # defaults to None (so unit tests that don't create DB rows stay safe).
        # Push the live factory now that the engine is ready.
        import ankor.decorator.workflow as _wf
        import ankor.decorator._persistence as _pers
        import ankor.decorator._drain as _drn
        from .database import _SessionLocal as _sl

        _wf._SessionLocal = _sl
        _pers._SessionLocal = _sl
        _drn._SessionLocal = _sl

        patch_httpx()
        self._tables_schema = tables or []

        from .config_store import ConfigStore
        from .db_store import DbStore

        self.config = ConfigStore()
        """Programmatic access to the Config store (``await ak.config.get(key)``)."""
        self.db = DbStore()
        """Programmatic access to the lightweight DB tables (``await ak.db.rows(table)``)."""

        self._workflows: dict = {}
        self._wrappers: dict = {}  # name -> wrapped fn (for re-run dispatch)
        self._scheduled_workflows: list[dict] = []  # [{fn, schedule, name}]
        self._webhook_workflows: dict[str, Any] = {}  # name -> fn
        self._workflow_meta: dict[str, dict] = (
            {}
        )  # name -> {trigger_type, schedule, is_webhook}
        self._app = app

        async def _startup() -> None:
            from .auth import generate_webhook_token
            from .database import _SessionLocal, run_migrations
            from .db_helpers import _ensure_tables
            from .models import Workflow, WebhookToken

            await run_migrations()

            if self._tables_schema:
                await _ensure_tables(self._tables_schema)

            if _SessionLocal is not None:
                from sqlmodel import select

                async with _SessionLocal() as _s:
                    if not await _s.get(WebhookToken, "default"):
                        _s.add(WebhookToken(token=generate_webhook_token()))
                        await _s.commit()

                    # Upsert a workflows row for every registered workflow so that
                    # workflow_runs can reference it via workflow_id.
                    for wf_name in self._workflow_meta:
                        existing = (
                            await _s.exec(
                                select(Workflow).where(Workflow.name == wf_name)
                            )
                        ).first()
                        meta = self._workflow_meta[wf_name]
                        if existing is None:
                            _s.add(
                                Workflow(
                                    name=wf_name,
                                    max_concurrent_runs=meta.get("max_concurrent_runs"),
                                    folder=meta.get("folder"),
                                )
                            )
                        else:
                            existing.folder = meta.get("folder")
                            _s.add(existing)
                    await _s.commit()

                    await _recover_from_restart(_s, self._wrappers)

            if auto_seed:
                from .seed import seed_demo_data

                await seed_demo_data()

            self._start_scheduler()

        app.router.on_startup.append(_startup)
        self._register_router(app, secret)
        self._mount_dashboard(app, dev)
        self._register_docs(app, show_docs)

    def _start_scheduler(self) -> None:
        if not self._scheduled_workflows:
            return

        try:
            from apscheduler.schedulers.asyncio import AsyncIOScheduler
            from apscheduler.triggers.cron import CronTrigger
        except ImportError as exc:
            raise ImportError(
                "APScheduler is required for schedule= workflows. "
                "Install it with: pip install apscheduler"
            ) from exc

        scheduler = AsyncIOScheduler()

        for entry in self._scheduled_workflows:
            fn = entry["fn"]
            name = entry["name"]
            schedule_expr = entry["schedule"]

            fields = schedule_expr.split()
            if len(fields) == 6:
                # Extended 6-field format: second minute hour day month day_of_week
                second, minute, hour, day, month, day_of_week = fields
                trigger = CronTrigger(
                    second=second,
                    minute=minute,
                    hour=hour,
                    day=day,
                    month=month,
                    day_of_week=day_of_week,
                )
            elif len(fields) == 5:
                # Standard 5-field format: minute hour day month day_of_week
                minute, hour, day, month, day_of_week = fields
                trigger = CronTrigger(
                    minute=minute,
                    hour=hour,
                    day=day,
                    month=month,
                    day_of_week=day_of_week,
                )
            else:
                raise ValueError(
                    f"schedule= for '{name}' must have 5 fields "
                    f"(minute hour day month day_of_week) or 6 fields "
                    f"(second minute hour day month day_of_week), got: {schedule_expr!r}"
                )

            async def _schedule_job(_fn=fn, _name=name, _schedule=schedule_expr):
                from .database import _SessionLocal
                from .models import Workflow
                from .trigger_context import TriggerContext

                if _SessionLocal is not None:
                    async with _SessionLocal() as _s:
                        from sqlmodel import select

                        _cfg = (
                            await _s.exec(
                                select(Workflow).where(Workflow.name == _name)
                            )
                        ).first()
                        if _cfg is not None and not _cfg.enabled:
                            return
                ctx = TriggerContext("schedule", {}, {"schedule": _schedule})
                await _fn({}, _ctx=ctx)

            scheduler.add_job(_schedule_job, trigger=trigger, id=f"schedule_{name}")

        scheduler.start()

    def _register_router(self, app: "FastAPI", secret: str) -> None:
        from .routers import create_router
        from .trigger_context import TriggerContext

        async def _invoke(name: str, ctx: TriggerContext) -> None:
            wrapper = self._wrappers.get(name)
            if wrapper is None:
                raise KeyError(name)
            asyncio.create_task(wrapper(ctx.inputs, _ctx=ctx))

        router = create_router(
            workflow_meta=self._workflow_meta, invoke=_invoke, wrappers=self._wrappers
        )
        app.include_router(router, prefix="/api", include_in_schema=False)

    def _register_docs(self, app: "FastAPI", show_docs: bool) -> None:
        import os
        import secrets as _secrets

        # Remove any default docs routes FastAPI registered during __init__.
        _docs_paths = {"/docs", "/redoc", "/openapi.json"}
        app.routes[:] = [
            r for r in app.routes if getattr(r, "path", "") not in _docs_paths
        ]

        if not show_docs:
            return

        user = os.environ.get("ANKOR_DOCS_USER", "")
        password = os.environ.get("ANKOR_DOCS_PASSWORD", "")
        if not user or not password:
            return

        from fastapi import Depends, HTTPException
        from fastapi.openapi.docs import get_swagger_ui_html
        from fastapi.responses import HTMLResponse, JSONResponse
        from fastapi.security import HTTPBasic, HTTPBasicCredentials

        _security = HTTPBasic()

        def _auth(credentials: HTTPBasicCredentials = Depends(_security)) -> None:
            valid = _secrets.compare_digest(
                credentials.username, user
            ) and _secrets.compare_digest(credentials.password, password)
            if not valid:
                raise HTTPException(
                    status_code=401,
                    headers={"WWW-Authenticate": "Basic"},
                )

        @app.get("/docs", include_in_schema=False, dependencies=[Depends(_auth)])
        async def _swagger() -> HTMLResponse:
            return get_swagger_ui_html(openapi_url="/openapi.json", title="API Docs")

        @app.get(
            "/openapi.json", include_in_schema=False, dependencies=[Depends(_auth)]
        )
        async def _openapi_json() -> JSONResponse:
            return JSONResponse(app.openapi())

    def _mount_dashboard(self, app: "FastAPI", dev: bool) -> None:
        if dev:
            self._mount_dev_proxy(app)
        elif STATIC_DIR.exists():
            from fastapi.responses import FileResponse

            @app.get("/admin/{path:path}", include_in_schema=False)
            async def _serve_dashboard(path: str) -> FileResponse:
                candidate = STATIC_DIR / path
                if candidate.is_file():
                    return FileResponse(candidate)
                return FileResponse(STATIC_DIR / "index.html")

    def _mount_dev_proxy(self, app: "FastAPI") -> None:
        import os
        import httpx
        from fastapi import Request
        from fastapi.responses import StreamingResponse

        vite_port = os.environ.get("VITE_PORT", "5173")

        @app.api_route("/admin/{path:path}", methods=["GET"])
        async def _proxy(path: str, request: Request) -> StreamingResponse:
            async with httpx.AsyncClient() as client:
                url = f"http://localhost:{vite_port}/admin/{path}"
                if request.url.query:
                    url = f"{url}?{request.url.query}"
                resp = await client.get(url, headers=dict(request.headers))
                return StreamingResponse(
                    content=iter([resp.content]),
                    status_code=resp.status_code,
                    media_type=resp.headers.get("content-type"),
                )

    def workflow(
        self,
        fn=None,
        *,
        schedule: str | None = None,
        webhook: bool = False,
        background=False,
        input_schema: list[dict] | None = None,
        examples: list[dict] | None = None,
        output_example: Any | None = None,
        description: str | None = None,
        how_it_works: str | None = None,
        instructions: str | None = None,
        max_concurrent_runs: int | None = None,
        folder: str | None = None,
        table_action: dict | None = None,
        restart_on_failure_check=None,
        server_restart_logic=None,
    ) -> WorkflowFn | Callable[[Any], WorkflowFn]:
        """Decorator that registers a workflow function.

        Pass ``restart_on_failure_check`` to handle server-crash recovery at the
        workflow level.  The callable receives ``inputs: dict`` and must return
        ``dict | None``: ``None`` means re-run the workflow; a ``dict`` means the
        workflow already succeeded and that dict is used as its output.

        Usage:
            @ak.workflow
            async def my_workflow(inputs): ...

            @ak.workflow(schedule="0 9 * * 1-5")   # every weekday at 09:00
            async def daily_workflow(inputs): ...

            @ak.workflow(schedule="*/10 * * * * *")  # every 10 seconds (6-field)
            async def frequent_workflow(inputs): ...

            @ak.workflow(webhook=True)
            async def webhook_workflow(inputs): ...

            @ak.workflow(
                input_schema=[
                    {"key": "limit", "type": "number", "label": "Limit", "default": 10},
                    {"key": "dry_run", "type": "boolean", "label": "Dry run", "default": False},
                ],
                description="Fetches contacts and enriches each one.",
            )
            async def my_workflow(inputs): ...
        """

        def _decorate(func):
            from .decorator import make_workflow_wrapper

            wrapper = make_workflow_wrapper(
                func,
                restart_on_failure_check=restart_on_failure_check,
                server_restart_logic=server_restart_logic,
            )
            self._workflows[func.__name__] = func
            self._wrappers[func.__name__] = wrapper

            trigger_type = "manual"
            if schedule:
                trigger_type = "schedule"
            elif webhook:
                trigger_type = "webhook"

            self._workflow_meta[func.__name__] = {
                "trigger_type": trigger_type,
                "schedule": schedule,
                "is_webhook": webhook,
                "webhook_path": f"/api/webhooks/{func.__name__}" if webhook else None,
                "input_schema": input_schema or [],
                "examples": examples or [],
                "output_example": output_example,
                "description": description,
                "how_it_works": how_it_works or instructions,
                "max_concurrent_runs": max_concurrent_runs,
                "folder": folder,
                "table_action": table_action or {},
            }

            if schedule:
                self._scheduled_workflows.append(
                    {
                        "fn": wrapper,
                        "schedule": schedule,
                        "name": func.__name__,
                    }
                )

            if webhook:
                self._register_webhook(
                    func.__name__,
                    wrapper,
                    background=background,
                    description=description,
                    input_schema=input_schema or [],
                )

            return wrapper

        if fn is not None:
            return _decorate(fn)

        return _decorate

    def _register_webhook(
        self,
        name: str,
        wrapper,
        background=False,
        description: str | None = None,
        input_schema: list | None = None,
    ) -> None:
        register_webhook(
            self._app,
            name,
            wrapper,
            self._webhook_workflows,
            background,
            description=description,
            input_schema=input_schema,
        )

    def log(self, message: str, *, type: str = "info", json: bool = False) -> None:
        """Append a structured log entry to the currently executing node's log buffer.

        Call from inside a ``@ak.node`` function.  If called outside a node
        the message is silently dropped.

        Args:
            message: The log message text.
            type:    ``"info"`` (default), ``"warning"``, or ``"error"``.
            json:    Set to ``True`` when *message* is a JSON string.
        """
        from .decorator import log as _log

        _log(message, type=type, json=json)

    def node(
        self,
        fn=None,
        *,
        tracks_row: bool = False,
        restart_on_failure_check=None,
        server_restart_logic=None,
        return_meta: bool = False,
    ) -> NodeFn | Callable[[Any], NodeFn]:
        """Decorator that wraps a function as a tracked workflow node.

        Each call is recorded as an individual step in the active workflow run,
        with its own inputs, outputs, timing, and logs.  When called outside a
        workflow the function executes transparently with no tracking overhead.

        Pass ``tracks_row=True`` to automatically broadcast per-row loading state
        when this node is called inside a table-action workflow.  Ankor reads
        ``inputs["row_id"]`` and emits *processing* when the node starts,
        *completed* on return, and *failed* on an unhandled exception.  The
        loading badge for that specific row in the Data Tables page is updated
        immediately — rather than waiting for the whole workflow run to finish.

        Pass ``return_meta=True`` to include the ``_meta`` key in the value
        returned to the caller.  By default ``_meta`` is stripped from the
        return value so downstream nodes and ``db.update_row`` calls never see
        it; ``_meta`` is always preserved in the DB for dashboard visualisation.
        occurs mid-node and the node may have already produced side-effects.  The
        callable receives ``inputs: dict`` and must return ``dict | None``:
        ``None`` means the node should be re-run; a ``dict`` means the node
        already succeeded and that dict is used as its output.

        Usage:
            @ak.node
            async def my_step(inputs: dict) -> dict: ...

            @ak.node(tracks_row=True)
            async def process_contact(inputs: dict) -> dict:
                # inputs["row_id"] is tracked automatically
                ...

            async def _check_lead_saved(inputs: dict) -> dict | None:
                row = await db.find_row("Leads", metadata={"node_run_inputs": inputs})
                return row  # None → re-run; dict → already done

            @ak.node(restart_on_failure_check=_check_lead_saved)
            async def save_lead(inputs: dict) -> dict: ...
        """

        def _decorate(func):
            from .decorator import make_node_wrapper

            return make_node_wrapper(
                func,
                tracks_row=tracks_row,
                restart_on_failure_check=restart_on_failure_check,
                server_restart_logic=server_restart_logic,
                return_meta=return_meta,
            )

        if fn is not None:
            return _decorate(fn)

        return _decorate
