"""Low-level SQL utility helpers for data table access.

This module contains private helpers, public dataclasses (``RowFilter``,
``OrderBy``), type maps, and the schema-migration function ``_ensure_tables``.
They are used internally by :mod:`db_store`, :mod:`routers.db_tables`, and
:mod:`seed`.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from decimal import Decimal
from datetime import date, datetime
from typing import Any

from sqlalchemy import text


def _normalize_select_opts(opts: list | None) -> list[dict]:
    """Normalize select options to ``[{id, label, color?}]`` format.

    Accepts legacy plain-string lists ``["a", "b"]`` or partially-formed
    objects ``[{"label": "a"}]`` and always returns fully-formed objects.
    ``None`` or empty input returns ``[]``.
    """
    if not opts:
        return []
    result: list[dict] = []
    for i, opt in enumerate(opts):
        if isinstance(opt, str):
            result.append({"id": i + 1, "label": opt})
        elif isinstance(opt, dict):
            if "id" not in opt:
                result.append({**opt, "id": i + 1})
            else:
                result.append(opt)
    return result


@dataclass
class RowFilter:
    """A single filter clause for :meth:`DbStore.rows`.

    Supported operators:

    - ``eq`` / ``neq`` — equality / inequality (all types)
    - ``gt`` / ``gte`` / ``lt`` / ``lte`` — comparison (number, float, date)
    - ``contains`` / ``starts_with`` / ``ends_with`` — case-insensitive substring matching (text, select)
    """

    column: str
    op: str
    value: Any


@dataclass
class OrderBy:
    """Sort clause for :meth:`DbStore.rows`.

    ``direction`` must be ``"asc"`` or ``"desc"`` (case-insensitive).
    Defaults to ascending order.

    Example::

        from ankor import OrderBy

        rows = await ak.db.rows("Deals", order_by=OrderBy("amount", "desc"))
    """

    column: str
    direction: str = "asc"


_FILTER_OPS: dict[str, str] = {
    "eq": "=",
    "neq": "!=",
    "gt": ">",
    "gte": ">=",
    "lt": "<",
    "lte": "<=",
}
_LIKE_OPS: frozenset[str] = frozenset({"contains", "starts_with", "ends_with"})
_ALL_FILTER_OPS: frozenset[str] = frozenset(_FILTER_OPS) | _LIKE_OPS
_ORDER_DIRECTIONS: frozenset[str] = frozenset({"asc", "desc"})


def _build_where(filters: list[RowFilter]) -> tuple[str, dict]:
    if not filters:
        return "", {}
    parts: list[str] = []
    params: dict[str, Any] = {}
    for i, f in enumerate(filters):
        if f.op not in _ALL_FILTER_OPS:
            raise ValueError(
                f"Unknown filter op {f.op!r}. Valid ops: {sorted(_ALL_FILTER_OPS)}"
            )
        col_q = _qi(f.column)
        p = f"fp{i}"
        if f.op in _FILTER_OPS:
            parts.append(f"{col_q} {_FILTER_OPS[f.op]} :{p}")
            params[p] = f.value
        elif f.op == "contains":
            parts.append(f"{col_q} ILIKE :{p}")
            params[p] = f"%{f.value}%"
        elif f.op == "starts_with":
            parts.append(f"{col_q} ILIKE :{p}")
            params[p] = f"{f.value}%"
        else:
            parts.append(f"{col_q} ILIKE :{p}")
            params[p] = f"%{f.value}"
    return " WHERE " + " AND ".join(parts), params


def _build_order_by(order_by: "OrderBy | None") -> str:
    """Return the ORDER BY expression (without the ORDER BY keyword)."""
    if order_by is None:
        return _qi("id")
    direction = order_by.direction.lower()
    if direction not in _ORDER_DIRECTIONS:
        raise ValueError(
            f"Invalid order direction {order_by.direction!r}. Use 'asc' or 'desc'."
        )
    return f"{_qi(order_by.column)} {direction.upper()}"


def _build_select_cols(columns: list[str] | None) -> str:
    """Return the SELECT column list. id is always included when columns are specified."""
    if not columns:
        return "*"
    # Preserve caller order; deduplicate id if explicitly passed
    seen: set[str] = {"id"}
    parts = [_qi("id")]
    for col in columns:
        if col not in seen:
            parts.append(_qi(col))
            seen.add(col)
    return ", ".join(parts)


def _qi(s: str) -> str:
    """Double-quote a PostgreSQL identifier to handle hyphens and special chars."""
    return '"' + s.replace('"', '""') + '"'


def _pg_table(table_id: int) -> str:
    return f"data_table_{table_id}"


_PG_TYPE_MAP: dict[str, str] = {
    "text": "TEXT",
    "url": "TEXT",
    "integer": "BIGINT",
    "float": "DOUBLE PRECISION",
    "boolean": "BOOLEAN",
    "date": "DATE",
    "select": "BIGINT",
    "json": "JSONB",
}

_UDT_TO_FRONTEND_TYPE: dict[str, str] = {
    "text": "text",
    "varchar": "text",
    "bpchar": "text",
    "numeric": "integer",
    "int2": "integer",
    "int4": "integer",
    "int8": "integer",
    "float4": "float",
    "float8": "float",
    "bool": "boolean",
    "date": "date",
    "jsonb": "json",
    "json": "json",
}


def _normalize_row(mapping: Any, col_types: dict[str, str] | None = None) -> dict:
    result: dict[str, Any] = {}
    for k, v in mapping.items():
        if isinstance(v, Decimal):
            result[k] = float(v)
        elif isinstance(v, datetime):
            result[k] = v.isoformat()
        elif isinstance(v, date):
            result[k] = v.isoformat()
        elif isinstance(v, str) and (
            k == "history" or (col_types and col_types.get(k) == "json")
        ):
            try:
                result[k] = json.loads(v)
            except (json.JSONDecodeError, ValueError):
                result[k] = v
        else:
            result[k] = v
    return result


_SYSTEM_COLS = frozenset({"id", "created_at", "updated_at", "history"})

_BOOL_TRUE = frozenset({"true", "1", "yes", "on"})
_BOOL_FALSE = frozenset({"false", "0", "no", "off"})


def coerce_csv_value(raw: str, col_type: str) -> Any:
    """Coerce a raw CSV string to the Python type implied by col_type."""
    if raw == "":
        return None
    if col_type in ("text", "url", "string", "select"):
        return raw
    if col_type == "integer":
        try:
            return int(raw) if "." not in raw else round(float(raw))
        except ValueError:
            return None
    if col_type == "float":
        try:
            return float(raw)
        except ValueError:
            return None
    if col_type == "boolean":
        lower = raw.strip().lower()
        if lower in _BOOL_TRUE:
            return True
        if lower in _BOOL_FALSE:
            return False
        return None
    if col_type == "date":
        s = raw.strip()
        try:
            return (
                datetime.fromisoformat(s.rstrip("Z")).date()
                if "T" in s
                else date.fromisoformat(s)
            )
        except ValueError:
            return None
    if col_type == "json":
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return raw.strip()
    return raw


async def _get_column_names(session: Any, tbl: str) -> list[str]:
    result = await session.execute(
        text(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name = :tbl AND table_schema = 'public' "
            "AND column_name NOT IN ('id', 'created_at', 'updated_at', 'history') "
            "ORDER BY ordinal_position"
        ),
        {"tbl": tbl},
    )
    return [row[0] for row in result]


async def _read_col_types(session: Any, tbl: str) -> dict[str, str]:
    """Return ``{column_name: frontend_type}`` for all non-system columns."""
    result = await session.execute(
        text(
            "SELECT column_name, udt_name FROM information_schema.columns "
            "WHERE table_name = :tbl AND table_schema = 'public' "
            "AND column_name NOT IN ('id', 'created_at', 'updated_at', 'history') "
            "ORDER BY ordinal_position"
        ),
        {"tbl": tbl},
    )
    return {row[0]: _UDT_TO_FRONTEND_TYPE.get(row[1], "text") for row in result}


async def _read_select_opts_lookup(
    session: Any, table_id: int
) -> dict[str, dict[str, int]]:
    """Return ``{col_name: {label_lower: id}}`` for all select columns in a table.

    Used to resolve option label strings (e.g. ``"ready"``) to their integer IDs
    at write time so callers don't have to look up numeric IDs manually.
    """
    result = await session.execute(
        text(
            "SELECT column_name, select_options FROM data_table_column_meta "
            "WHERE table_id = :tid AND select_options IS NOT NULL"
        ),
        {"tid": table_id},
    )
    lookup: dict[str, dict[str, int]] = {}
    for row in result:
        col_name, opts_raw = row[0], row[1]
        opts = _normalize_select_opts(opts_raw if isinstance(opts_raw, list) else [])
        lookup[col_name] = {
            o["label"].lower(): o["id"] for o in opts if "label" in o and "id" in o
        }
    return lookup


def _coerce_for_write(
    value: Any,
    col_type: str,
    select_opts: dict[str, int] | None = None,
) -> Any:
    """Coerce a Python value to the appropriate type for a PostgreSQL write.

    For ``select`` columns, *select_opts* should be ``{label_lower: id}`` so that
    string values like ``"ready"`` are automatically resolved to their integer IDs.
    """
    if value is None:
        return None
    if col_type in ("integer", "select") and isinstance(value, str):
        try:
            return int(value)
        except (ValueError, TypeError):
            if col_type == "select" and select_opts:
                resolved = select_opts.get(value.lower())
                if resolved is not None:
                    return resolved
            return value
    if col_type == "float" and isinstance(value, str):
        try:
            return float(value)
        except (ValueError, TypeError):
            return value
    if col_type == "date":
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, str):
            s = value.strip()
            try:
                return (
                    datetime.fromisoformat(s.rstrip("Z")).date()
                    if "T" in s
                    else date.fromisoformat(s)
                )
            except ValueError:
                return None
    if col_type == "json" and isinstance(value, (dict, list)):
        return json.dumps(value)
    return value


async def _read_columns(session: Any, table_id: int) -> list[dict[str, Any]]:
    tbl = _pg_table(table_id)
    col_result = await session.execute(
        text(
            "SELECT column_name, udt_name FROM information_schema.columns "
            "WHERE table_name = :tbl AND table_schema = 'public' "
            "AND column_name NOT IN ('id', 'created_at', 'updated_at', 'history') "
            "ORDER BY ordinal_position"
        ),
        {"tbl": tbl},
    )
    pg_cols = col_result.fetchall()
    meta_result = await session.execute(
        text(
            "SELECT column_name, select_options, col_type, description "
            "FROM data_table_column_meta WHERE table_id = :tid"
        ),
        {"tid": table_id},
    )
    meta_map: dict[str, dict] = {}
    for row in meta_result:
        meta_map[row[0]] = {
            "select_options": row[1],
            "col_type": row[2],
            "description": row[3],
        }
    cols: list[dict[str, Any]] = []
    for col in pg_cols:
        col_name, udt = col[0], col[1]
        meta = meta_map.get(col_name, {})
        opts = meta.get("select_options")
        col_type_override = meta.get("col_type")
        description = meta.get("description")
        col_type = (
            col_type_override
            if col_type_override is not None
            else (
                "select" if opts is not None else _UDT_TO_FRONTEND_TYPE.get(udt, "text")
            )
        )
        entry: dict[str, Any] = {"id": col_name, "name": col_name, "type": col_type}
        if opts is not None:
            entry["selectOptions"] = _normalize_select_opts(opts)
        if description:
            entry["description"] = description
        cols.append(entry)
    return cols


async def _upsert_row(
    session: Any, tbl_name: str, row: dict, col_ids: list[str]
) -> None:
    """INSERT ... ON CONFLICT (id) DO UPDATE for a single row.

    System columns created_at and updated_at are managed automatically:
    created_at is set on first insert only; updated_at is always refreshed.
    """
    known = set(col_ids)
    data = {k: v for k, v in row.items() if k != "id" and k in known}
    params: dict[str, Any] = {"row_id": int(row["id"])}
    col_q, val_ph, update_parts = [], [], []
    for i, (k, v) in enumerate(data.items()):
        qk = _qi(k)
        col_q.append(qk)
        val_ph.append(f":v{i}")
        update_parts.append(f"{qk} = EXCLUDED.{qk}")
        params[f"v{i}"] = v
    sys_update = "updated_at = NOW()"
    if col_q:
        sql = (
            f"INSERT INTO {tbl_name} (id, created_at, updated_at, {', '.join(col_q)}) "
            f"VALUES (:row_id, NOW(), NOW(), {', '.join(val_ph)}) "
            f"ON CONFLICT (id) DO UPDATE SET {sys_update}, {', '.join(update_parts)}"
        )
    else:
        sql = (
            f"INSERT INTO {tbl_name} (id, created_at, updated_at) VALUES (:row_id, NOW(), NOW()) "
            f"ON CONFLICT (id) DO UPDATE SET {sys_update}"
        )
    await session.execute(text(sql), params)


async def _ensure_tables(schema: list[dict]) -> None:
    """Idempotently create or migrate tables declared in the ankor `tables=` config.

    Each entry in *schema* is a dict with keys:
        name        str                     required
        description str | None              optional
        columns     list[dict]              required — each has {id, name, type, selectOptions?}

    For each declared table:
    - If the table does not exist in the registry, it is created (physical table + metadata row).
    - If the table already exists, any declared columns that are missing are added (ALTER TABLE ADD COLUMN).
    - Existing columns are never dropped or modified (safe forward-only migration).
    """
    from .database import _SessionLocal

    if _SessionLocal is None:
        return

    from sqlmodel import select
    from .models import DataTable

    async with _SessionLocal() as session:
        for entry in schema:
            name: str = entry["name"]
            description: str | None = entry.get("description")
            actions: list[str] | None = entry.get("actions")
            declared_cols: list[dict] = entry.get("columns") or []

            existing = (
                await session.exec(select(DataTable).where(DataTable.name == name))
            ).first()

            if existing is None:
                t = DataTable(name=name, description=description, actions=actions)
                session.add(t)
                await session.flush()
                tbl = _pg_table(t.id)
                col_defs = [
                    "id INTEGER NOT NULL",
                    "history JSONB NOT NULL DEFAULT '[]'",
                    "created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
                    "updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
                ] + [
                    f"{_qi(col['id'])} {_PG_TYPE_MAP.get(col.get('type', 'text'), 'TEXT')}"
                    for col in declared_cols
                ]
                await session.execute(
                    text(
                        f"CREATE TABLE {tbl} ({', '.join(col_defs)}, PRIMARY KEY (id))"
                    )
                )
                for col in declared_cols:
                    if col.get("type") == "select":
                        await session.execute(
                            text(
                                "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                                "VALUES (:tid, :cn, CAST(:opts AS json))"
                            ),
                            {
                                "tid": t.id,
                                "cn": col["id"],
                                "opts": json.dumps(
                                    _normalize_select_opts(col.get("selectOptions"))
                                ),
                            },
                        )
            else:
                tbl = _pg_table(existing.id)
                if actions is not None:
                    existing.actions = actions
                    session.add(existing)
                result = await session.execute(
                    text(
                        "SELECT column_name FROM information_schema.columns "
                        "WHERE table_name = :tbl AND table_schema = 'public'"
                    ),
                    {"tbl": tbl},
                )
                existing_cols = {row[0] for row in result}
                if "history" not in existing_cols:
                    await session.execute(
                        text(
                            f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS "
                            f"history JSONB NOT NULL DEFAULT '[]'"
                        )
                    )
                for col in declared_cols:
                    col_id = col["id"]
                    if col_id not in existing_cols:
                        pg_type = _PG_TYPE_MAP.get(col.get("type", "text"), "TEXT")
                        await session.execute(
                            text(
                                f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS {_qi(col_id)} {pg_type}"
                            )
                        )
                    if col.get("type") == "select":
                        await session.execute(
                            text(
                                "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                                "VALUES (:tid, :cn, CAST(:opts AS json)) "
                                "ON CONFLICT (table_id, column_name) DO UPDATE SET select_options = EXCLUDED.select_options"
                            ),
                            {
                                "tid": existing.id,
                                "cn": col_id,
                                "opts": json.dumps(
                                    _normalize_select_opts(col.get("selectOptions"))
                                ),
                            },
                        )

        await session.commit()
