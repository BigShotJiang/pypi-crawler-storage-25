# ankor

Workflow monitoring and management for FastAPI apps.

`ankor` adds a self-hosted dashboard and run-tracking API to **any FastAPI application**. Decorate Python functions with `@ak.workflow` and choose how they are triggered: manually, on a schedule, or via a webhook.

## Install

```bash
pip install ankor

# Required for scheduled workflows:
pip install apscheduler
```

## Quick start

```python
import os
from fastapi import FastAPI
from ankor import ankor

app = FastAPI()

ak = ankor(
    app,
    db_url=os.environ["GTM_DB_URL"],
    secret=os.environ["GTM_SECRET"],
)

@ak.workflow
async def enrich_leads(inputs: dict):
    results = call_some_api(inputs["leads"])
    return {"enriched": results}

@ak.workflow(schedule="0 9 * * 1-5")
async def daily_sync(inputs: dict):
    return {"synced": sync_database()}

@ak.workflow(webhook=True)
async def process_event(inputs: dict):
    return handle(inputs)
```

This mounts the dashboard at `/admin/` and the REST API at `/api/*` on your FastAPI app. See [docs/DOCS.md](../docs/DOCS.md) for the full reference — constructor options, workflow decorator options, nodes, config store, data tables (including row filtering with `RowFilter`, column selection, and ordering with `OrderBy`), and deployment.

## API Routes

See [docs/API-ROUTES.md](docs/API-ROUTES.md) for the full route reference.

## Package structure

See [docs/PACKAGE-STRUCTURE.md](docs/PACKAGE-STRUCTURE.md) for the full source layout.

> Additional docs live in [`api/docs/`](docs/).

## Local development

For first-time setup (dependencies, `.env`, migrations) see the [repo root README](../README.md).

```bash
uv run python seed.py   # Optional: seed demo data
```

For dev server commands see the repo root [README.md](../README.md).

## Requirements

- Python 3.11+
- PostgreSQL database (Supabase, Neon, or self-hosted)
- FastAPI app
