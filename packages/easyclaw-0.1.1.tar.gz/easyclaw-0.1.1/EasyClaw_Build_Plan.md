# EasyClaw Autonomous Agent — Build Plan

---

## Phase 0 — Foundation & Scaffolding (Days 1–3)

**Goal:** Get EasyClaw running as a standalone daemon alongside OpenClaw with zero functionality beyond "alive and watching."

**Tasks:**

1. Create the `easyclaw/` project directory mirroring OpenClaw's structure (Python, same venv or shared deps).
2. Build the core daemon loop — a simple `asyncio` event loop that starts, logs a heartbeat, and gracefully shuts down on SIGTERM/SIGINT.
3. Wire up shared environment loading — EasyClaw reads the same `.env` / config files as OpenClaw (OPENROUTER_API_KEY, paths, etc.) so there's zero config duplication.
4. Add a systemd user service (or a simple `tmux`/`screen` launcher script for WSL2) so EasyClaw auto-starts alongside OpenClaw.
5. Implement the **failsafe contract**: EasyClaw wraps its entire main loop in a top-level try/except so it never takes OpenClaw down. If it crashes, it logs the error and exits cleanly.

**Deliverable:** `easyclaw` process starts, prints heartbeat every 30s, reads OpenClaw's env, and dies gracefully.

---

## Phase 1 — The Doctor: Log Tailing & Error Detection (Days 4–8)

**Goal:** EasyClaw watches OpenClaw's logs in real-time and classifies events.

**Tasks:**

1. Identify OpenClaw's log output paths (stdout log, memory extraction logs, error logs). Set up async file tailing using `aiofiles` or `asyncio.subprocess` tailing `tail -F`.
2. Build an **Event Classifier** — a rules-based engine (start simple, no LLM yet) that pattern-matches against known error signatures: Python tracebacks, `ConnectionRefusedError`, OOM kills, stalled processes, API 429s/500s.
3. Create an **Event Queue** — detected events get pushed to an internal `asyncio.Queue` with severity levels (INFO, WARNING, CRITICAL).
4. Build the **Alert Pipeline** — CRITICAL events trigger a user notification (simple approach: write to a `~/.easyclaw/alerts.log` that OpenClaw can surface, or send a webhook to your n8n instance for Telegram/Discord notification).
5. Add process health monitoring — poll OpenClaw's PID at intervals, detect if it's hung (CPU spike with no log output for X minutes) or dead.

**Deliverable:** EasyClaw detects OpenClaw crashes, stuck loops, and common errors in real-time and logs/alerts them.

---

## Phase 2 — The Doctor: Self-Healing Execution (Days 9–14)

**Goal:** EasyClaw doesn't just detect problems — it fixes them.

**Tasks:**

1. Build a **Remediation Registry** — a local JSON/YAML file mapping error signatures to fix actions. Example entries:
   - `"ConnectionRefusedError.*OpenRouter"` → retry after 30s, then check API key validity
   - `"MemoryError"` or OOM → clear OpenClaw's BM25 cache, restart process
   - `"stalled_process"` → SIGTERM → wait 5s → SIGKILL → restart
2. Implement a **Command Executor** — a sandboxed shell execution layer (subprocess with timeout, capped output capture, no interactive commands). This is EasyClaw's "hands."
3. Build the **Restart Manager** — knows how to cleanly stop and start OpenClaw (respecting its memory save hooks so you don't corrupt the BM25 index). Sequence: signal graceful shutdown → wait for memory flush → kill if needed → restart.
4. Add a **Fix Ledger** — every action EasyClaw takes gets logged with timestamp, error hash, action taken, and outcome. This becomes your audit trail and feeds future optimization.
5. Implement **circuit breaker logic** — if EasyClaw has restarted OpenClaw 3+ times in 10 minutes, stop auto-fixing and escalate to user (prevents restart loops).

**Deliverable:** EasyClaw auto-recovers from the top 5–10 most common OpenClaw failure modes without user intervention.

---

## Phase 3 — MCP Client Integration (Days 15–22)

**Goal:** Connect EasyClaw to a proprietary MCP server for dynamic knowledge retrieval.

**Tasks:**

1. **Build the MCP server** — since you already have n8n MCP experience, start with a lightweight MCP server (Python FastMCP or Node MCP SDK) hosted on your Hostinger VPS. Initial tools to expose:
   - `get_known_issues(error_signature)` → returns fix instructions from a curated knowledge base
   - `get_latest_docs(topic)` → returns current OpenClaw docs/changelogs
   - `check_for_updates()` → returns version info and available patches
   - `report_incident(event_data)` → logs incidents centrally for multi-instance tracking
2. **Build the MCP client in EasyClaw** — implement the MCP client protocol (SSE transport to your VPS endpoint). Add secure token auth via a shared secret in the env file.
3. **Wire MCP into the Doctor pipeline** — when the local Remediation Registry doesn't have a match for an error, EasyClaw queries the MCP's `get_known_issues` tool. If a fix is returned, execute it and add it to the local registry as a cache.
4. **Implement push-pull updates** — EasyClaw polls `check_for_updates()` on a schedule (e.g., every 6 hours). If a hotfix is flagged, download and apply during detected idle windows.
5. **Populate the MCP knowledge base** — create the initial content store (markdown files + JSON schemas) covering OpenClaw's current known issues, config reference, and dependency list. This can live in a Git repo on the VPS that the MCP server reads from.

**Deliverable:** EasyClaw queries a remote MCP for fixes it doesn't know locally, and can receive pushed hotfixes.

---

## Phase 4 — The Personal Trainer: Optimization (Days 23–30)

**Goal:** Proactive maintenance — keep OpenClaw running at peak performance, not just alive.

**Tasks:**

1. **Context/Memory Monitor** — periodically check the size of OpenClaw's memory files (BM25 index, conversation logs). If they exceed thresholds, trigger archival (compress and move old data, keeping the 15K token budget lean).
2. **Temp File Cleanup** — scan OpenClaw's working directories for stale temp files, orphaned downloads, and bloated log files. Rotate/compress on schedule.
3. **Dependency Auditor** — compare OpenClaw's installed packages against a "known good" manifest from the MCP. Flag version mismatches or missing deps.
4. **Environment Validator** — on a schedule (daily or on OpenClaw restart), validate that API keys return 200s, database connections are live (Postgres/Qdrant on VPS), and webhook endpoints (n8n) respond to pings.
5. **Resource Monitor** — track OpenClaw's CPU/RAM usage over time. If it trends upward (memory leak pattern), proactively restart during idle window before it crashes.

**Deliverable:** EasyClaw proactively maintains OpenClaw's health, preventing issues before they become errors.

---

## Phase 5 — Hardening & User-Readiness (Days 31–38)

**Goal:** Make EasyClaw production-ready for distribution via easyclaw.help.

**Tasks:**

1. **Installer script** — a single `curl | bash` or guided install that drops EasyClaw into an existing OpenClaw environment, detects the OS (WSL2/Linux), sets up the service, and connects to the MCP.
2. **Resource capping** — enforce the <5–10% CPU/RAM budget using cgroups (Linux) or process priority/nice values (WSL2). Measure and tune.
3. **Security sandboxing** — EasyClaw's elevated permissions should be scoped. It can restart OpenClaw and edit OpenClaw's config files only. Use a dedicated service account or capability-based permissions.
4. **Dashboard/status endpoint** — a simple local HTTP endpoint (localhost:PORT/status) returning JSON health data: uptime, last fix applied, current OpenClaw status, MCP connection status. This feeds into future UI.
5. **KPI instrumentation** — wire up MTTR tracking (timestamp of error detection → timestamp of successful fix), intervention rate (auto-fixed vs. escalated), and uptime percentage. Store in the Fix Ledger and expose via the status endpoint.

**Deliverable:** Installable, measurable, distributable EasyClaw with clear KPI tracking.

---

## Architecture Summary

```
┌─────────────────────────────────────────────┐
│              Host (WSL2 / Linux)             │
│                                              │
│  ┌──────────┐         ┌──────────────────┐  │
│  │ OpenClaw │◄─logs──►│    EasyClaw      │  │
│  │ (user-   │ restart │  ┌────────────┐  │  │
│  │  facing) │◄────────│  │  Doctor    │  │  │
│  └──────────┘         │  │  (heal)    │  │  │
│                       │  ├────────────┤  │  │
│  Shared: .env,        │  │  Trainer   │  │  │
│  filesystem, API keys │  │  (optimize)│  │  │
│                       │  ├────────────┤  │  │
│                       │  │ MCP Client │──┼──┼──► Proprietary MCP
│                       │  └────────────┘  │  │   (Hostinger VPS)
│                       └──────────────────┘  │
└─────────────────────────────────────────────┘
```

---

## Key Technical Decisions to Lock Down Early

1. **LLM usage in EasyClaw itself** — does EasyClaw use `llm_call()` via OpenRouter for complex diagnosis, or stay purely rules-based? Recommendation: start rules-based (Phase 1–2) and add LLM-assisted diagnosis in Phase 3 when the MCP is live, keeping costs predictable.

2. **IPC between EasyClaw and OpenClaw** — start with file-based (logs + shared files). If you later need real-time bidirectional communication, add a Unix socket or lightweight local pub/sub.

3. **MCP server hosting** — the Hostinger VPS is the obvious home. The question is whether to run it as a standalone service or as an n8n workflow with MCP endpoints. Standalone gives more control; n8n gives faster prototyping.
