#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────
# EasyClaw Installer — curl -sL easyclaw.help/install | bash
#
# Installs EasyClaw, the autonomous monitoring sidecar for OpenClaw.
# Supports Linux, macOS, and WSL2. Safe to run multiple times.
#
# Usage:
#   curl -sL easyclaw.help/install | bash              # install
#   curl -sL easyclaw.help/install | bash -s -- --uninstall  # remove
# ──────────────────────────────────────────────────────────────────────
set -euo pipefail

EASYCLAW_HOME="${EASYCLAW_HOME:-$HOME/.easyclaw}"
REQUIRED_PY_MINOR=10

# ── Colors & output helpers ──────────────────────────────────────────

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

info()    { echo -e "  ${CYAN}::${NC} $*"; }
ok()      { echo -e "  ${GREEN}✓${NC}  $*"; }
warn()    { echo -e "  ${YELLOW}!${NC}  $*"; }
fail()    { echo -e "  ${RED}✗${NC}  $*" >&2; }
die()     { fail "$*"; exit 1; }
step()    { echo -e "\n${BOLD}$*${NC}"; }

# ── Banner ───────────────────────────────────────────────────────────

banner() {
    echo -e "${CYAN}"
    cat << 'ART'
    ______                 ______
   / ____/___ ________  __/ ____/ /__ _      __
  / __/ / __ `/ ___/ / / / /   / / _ `| /| / /
 / /___/ /_/ (__  ) /_/ / /___/ / /_/ /| |/ /
/_____/\__,_/____/\__, /\____/_/\__,_/ |__/
                 /____/
ART
    echo -e "${NC}"
    echo -e "  ${DIM}Autonomous monitoring for OpenClaw${NC}"
    echo ""
}

# ── Uninstall ────────────────────────────────────────────────────────

uninstall() {
    banner
    step "Uninstalling EasyClaw..."

    # Stop daemon if running
    if command -v easyclaw &>/dev/null; then
        info "Stopping daemon..."
        easyclaw stop 2>/dev/null || true
    fi

    # Remove systemd service if present
    local service_file="$HOME/.config/systemd/user/easyclaw.service"
    if [[ -f "$service_file" ]]; then
        info "Removing systemd service..."
        systemctl --user stop easyclaw.service 2>/dev/null || true
        systemctl --user disable easyclaw.service 2>/dev/null || true
        rm -f "$service_file"
        systemctl --user daemon-reload 2>/dev/null || true
        ok "Systemd service removed"
    fi

    # Remove launchd plist if present (macOS)
    local plist_file="$HOME/Library/LaunchAgents/com.easyclaw.daemon.plist"
    if [[ -f "$plist_file" ]]; then
        info "Removing launchd service..."
        launchctl unload "$plist_file" 2>/dev/null || true
        rm -f "$plist_file"
        ok "Launchd service removed"
    fi

    # Uninstall pip package
    if python3 -m pip show easyclaw &>/dev/null 2>&1; then
        info "Uninstalling pip package..."
        python3 -m pip uninstall -y easyclaw >/dev/null 2>&1
        ok "Package removed"
    fi

    # Remove data directory
    if [[ -d "$EASYCLAW_HOME" ]]; then
        echo ""
        warn "Data directory exists: ${BOLD}$EASYCLAW_HOME${NC}"
        warn "Contains config, logs, and state files."
        echo ""

        # When piped from curl, stdin is the script — can't prompt interactively
        if [[ -t 0 ]]; then
            read -r -p "  Delete $EASYCLAW_HOME? [y/N] " answer
            if [[ "$answer" =~ ^[Yy]$ ]]; then
                rm -rf "$EASYCLAW_HOME"
                ok "Data directory removed"
            else
                info "Kept $EASYCLAW_HOME"
            fi
        else
            info "Run ${BOLD}rm -rf $EASYCLAW_HOME${NC} manually to remove data."
        fi
    fi

    echo ""
    ok "EasyClaw uninstalled."
    exit 0
}

# ── Parse flags ──────────────────────────────────────────────────────

for arg in "$@"; do
    case "$arg" in
        --uninstall) uninstall ;;
        --help|-h)
            echo "Usage: curl -sL easyclaw.help/install | bash"
            echo "       curl -sL easyclaw.help/install | bash -s -- --uninstall"
            exit 0
            ;;
    esac
done

# ── Main install flow ────────────────────────────────────────────────

banner

# ── 1. Detect OS ─────────────────────────────────────────────────────

step "[1/6] Detecting operating system"

OS="$(uname -s)"
PLATFORM=""
IS_WSL=false

case "$OS" in
    Linux)
        if grep -qi microsoft /proc/version 2>/dev/null; then
            IS_WSL=true
            PLATFORM="wsl2"
            ok "Linux (WSL2)"
        else
            PLATFORM="linux"
            ok "Linux"
        fi
        ;;
    Darwin)
        PLATFORM="macos"
        ok "macOS $(sw_vers -productVersion 2>/dev/null || echo '')"
        ;;
    MINGW*|MSYS*|CYGWIN*)
        die "Windows is not supported. Install inside WSL2 instead."
        ;;
    *)
        die "Unsupported operating system: $OS"
        ;;
esac

# ── 2. Check prerequisites ──────────────────────────────────────────

step "[2/6] Checking prerequisites"

# Python 3
if ! command -v python3 &>/dev/null; then
    fail "Python 3 not found."
    echo ""
    case "$PLATFORM" in
        linux|wsl2) info "Install with: ${BOLD}sudo apt install python3 python3-pip${NC}" ;;
        macos)      info "Install with: ${BOLD}brew install python3${NC}" ;;
    esac
    exit 1
fi

PY_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PY_MAJOR=$(echo "$PY_VERSION" | cut -d. -f1)
PY_MINOR=$(echo "$PY_VERSION" | cut -d. -f2)

if [[ "$PY_MAJOR" -lt 3 ]] || { [[ "$PY_MAJOR" -eq 3 ]] && [[ "$PY_MINOR" -lt "$REQUIRED_PY_MINOR" ]]; }; then
    die "Python 3.${REQUIRED_PY_MINOR}+ required (found ${PY_VERSION})"
fi
ok "Python ${PY_VERSION}"

# pip
if ! python3 -m pip --version &>/dev/null; then
    fail "pip not found."
    echo ""
    case "$PLATFORM" in
        linux|wsl2) info "Install with: ${BOLD}sudo apt install python3-pip${NC}" ;;
        macos)      info "Install with: ${BOLD}python3 -m ensurepip --upgrade${NC}" ;;
    esac
    exit 1
fi
ok "pip $(python3 -m pip --version 2>/dev/null | awk '{print $2}')"

# OpenClaw (informational — not required)
if [[ -d "$HOME/.openclaw" ]]; then
    ok "OpenClaw found at ~/.openclaw"
else
    warn "OpenClaw not found at ~/.openclaw — EasyClaw will run in standby mode"
fi

# ── 3. Install EasyClaw ──────────────────────────────────────────────

step "[3/6] Installing EasyClaw"

# Determine install source
if [[ -f "pyproject.toml" ]] && grep -q 'name.*=.*"easyclaw"' pyproject.toml 2>/dev/null; then
    info "Installing from local source..."
    python3 -m pip install --user -q . 2>&1 | tail -1 || true
else
    info "Installing from PyPI..."
    python3 -m pip install --user -q easyclaw 2>&1 | tail -1 || {
        warn "PyPI install failed — trying git source..."
        # Fallback: install from GitHub (uncomment when repo exists)
        # python3 -m pip install --user -q "git+https://github.com/easyclaw/easyclaw.git"
        die "Could not install easyclaw. Check network and try again."
    }
fi

# Ensure ~/.local/bin is on PATH for this session
if ! command -v easyclaw &>/dev/null; then
    export PATH="$HOME/.local/bin:$PATH"
fi

if ! command -v easyclaw &>/dev/null; then
    fail "'easyclaw' binary not found in PATH after install."
    echo ""
    info "Add this to your shell profile (~/.bashrc or ~/.zshrc):"
    echo ""
    echo "    export PATH=\"\$HOME/.local/bin:\$PATH\""
    echo ""
    info "Then restart your shell and run this installer again."
    exit 1
fi

INSTALLED_VERSION=$(easyclaw --version 2>/dev/null || echo "unknown")
ok "EasyClaw ${INSTALLED_VERSION} installed"

# ── 4. Create directories & default config ───────────────────────────

step "[4/6] Setting up configuration"

mkdir -p "$EASYCLAW_HOME"/{logs,state}
ok "Data directory: $EASYCLAW_HOME"

CONFIG_FILE="$EASYCLAW_HOME/config.yaml"
if [[ -f "$CONFIG_FILE" ]]; then
    ok "Config exists: $CONFIG_FILE (not overwritten)"
else
    cat > "$CONFIG_FILE" << 'YAML'
# EasyClaw configuration
# Docs: https://easyclaw.help/docs/configuration

# How often the daemon logs a heartbeat (seconds)
heartbeat_interval: 30

# How often to check OpenClaw process health (seconds)
health_check_interval: 60

# Days to keep log files before rotation
log_retention_days: 7

# Circuit breaker: max restarts before backing off
max_restart_attempts: 3

# Circuit breaker: time window in seconds (10 min)
restart_window: 600

# OpenClaw gateway port (for health checks)
gateway_port: 18789

# Webhook URL for critical alerts (n8n, Telegram, Slack, etc.)
# alert_webhook: https://your-n8n.example.com/webhook/easyclaw

# MCP server endpoint for cloud knowledge base
# mcp_endpoint: http://your-server:8002
# mcp_token: your-subscription-token

# How often to check MCP for updates (seconds, default 6 hours)
update_check_interval: 21600

# Agent brain (Phase 6) — LLM-powered reasoning via OpenRouter
# openrouter_api_key: sk-or-v1-YOUR-KEY
# openrouter_model: z-ai/glm-4.7-flash
agent_enabled: true
agent_batch_window: 10
agent_cooldown: 30
agent_max_turns: 10
agent_temperature: 0.1

# Telegram bot (Phase 7)
# telegram_bot_token: YOUR-BOT-TOKEN
# telegram_chat_ids: []
telegram_alert_severity: CRITICAL
YAML
    ok "Default config written: $CONFIG_FILE"
fi

# ── 5. Set up init system ────────────────────────────────────────────

step "[5/6] Configuring auto-start"

SERVICE_INSTALLED=false

if command -v systemctl &>/dev/null && systemctl --user status &>/dev/null 2>&1; then
    # systemd (Linux / WSL2 with systemd)
    SERVICE_DIR="$HOME/.config/systemd/user"
    SERVICE_FILE="$SERVICE_DIR/easyclaw.service"
    mkdir -p "$SERVICE_DIR"

    # Resolve the actual easyclaw binary path for ExecStart
    EASYCLAW_BIN=$(command -v easyclaw)

    cat > "$SERVICE_FILE" << UNIT
[Unit]
Description=EasyClaw — OpenClaw autonomous monitoring daemon
After=network.target openclaw-gateway.service
Wants=openclaw-gateway.service

[Service]
Type=simple
ExecStart=${EASYCLAW_BIN} start --foreground
Restart=on-failure
RestartSec=10
StartLimitIntervalSec=60
StartLimitBurst=3
CPUQuota=10%
MemoryMax=256M
Environment=EASYCLAW_HOME=${EASYCLAW_HOME}

[Install]
WantedBy=default.target
UNIT

    systemctl --user daemon-reload
    systemctl --user enable easyclaw.service >/dev/null 2>&1
    SERVICE_INSTALLED=true
    ok "Systemd user service installed and enabled"

elif [[ "$PLATFORM" == "macos" ]]; then
    # launchd (macOS)
    PLIST_DIR="$HOME/Library/LaunchAgents"
    PLIST_FILE="$PLIST_DIR/com.easyclaw.daemon.plist"
    mkdir -p "$PLIST_DIR"

    EASYCLAW_BIN=$(command -v easyclaw)

    cat > "$PLIST_FILE" << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.easyclaw.daemon</string>
    <key>ProgramArguments</key>
    <array>
        <string>${EASYCLAW_BIN}</string>
        <string>start</string>
        <string>--foreground</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <dict>
        <key>SuccessfulExit</key>
        <false/>
    </dict>
    <key>ThrottleInterval</key>
    <integer>10</integer>
    <key>EnvironmentVariables</key>
    <dict>
        <key>EASYCLAW_HOME</key>
        <string>${EASYCLAW_HOME}</string>
    </dict>
    <key>StandardOutPath</key>
    <string>${EASYCLAW_HOME}/logs/launchd-stdout.log</string>
    <key>StandardErrorPath</key>
    <string>${EASYCLAW_HOME}/logs/launchd-stderr.log</string>
</dict>
</plist>
PLIST

    SERVICE_INSTALLED=true
    ok "launchd service installed: $PLIST_FILE"
    info "Load with: ${BOLD}launchctl load $PLIST_FILE${NC}"

else
    warn "No supported init system detected (systemd or launchd)"
    info "Start EasyClaw manually with: ${BOLD}easyclaw start${NC}"
fi

# ── 6. Run doctor ────────────────────────────────────────────────────

step "[6/6] Running diagnostics"
echo ""
easyclaw doctor || true

# ── Summary ──────────────────────────────────────────────────────────

echo ""
echo -e "${GREEN}${BOLD}────────────────────────────────────────────${NC}"
echo -e "${GREEN}${BOLD}  EasyClaw installed successfully!${NC}"
echo -e "${GREEN}${BOLD}────────────────────────────────────────────${NC}"
echo ""
echo -e "  ${BOLD}Version:${NC}  ${INSTALLED_VERSION}"
echo -e "  ${BOLD}Config:${NC}   ${CONFIG_FILE}"
echo -e "  ${BOLD}Logs:${NC}     ${EASYCLAW_HOME}/logs/"
echo -e "  ${BOLD}Platform:${NC} ${PLATFORM}"
echo ""
echo -e "  ${BOLD}Quick start:${NC}"

if [[ "$SERVICE_INSTALLED" == true ]]; then
    if [[ "$PLATFORM" == "macos" ]]; then
        echo -e "    launchctl load ~/Library/LaunchAgents/com.easyclaw.daemon.plist"
    else
        echo -e "    systemctl --user start easyclaw"
    fi
    echo ""
    echo -e "  ${BOLD}Or run in foreground:${NC}"
fi

echo -e "    easyclaw start -f"
echo ""
echo -e "  ${BOLD}Other commands:${NC}"
echo -e "    easyclaw status        ${DIM}# check daemon & OpenClaw health${NC}"
echo -e "    easyclaw doctor        ${DIM}# full environment diagnostics${NC}"
echo -e "    easyclaw stop          ${DIM}# graceful shutdown${NC}"
echo ""
echo -e "  ${BOLD}Configure:${NC}"
echo -e "    ${DIM}Edit ${CONFIG_FILE}${NC}"
echo -e "    ${DIM}Docs: https://easyclaw.help/docs/configuration${NC}"
echo ""
echo -e "  ${BOLD}Uninstall:${NC}"
echo -e "    curl -sL easyclaw.help/install | bash -s -- --uninstall"
echo ""
