# Changelog

All notable changes to EasyClaw will be documented in this file.

## [0.1.0] - 2026-03-30

### Added
- **Phase 0 — Foundation:** asyncio daemon, heartbeat, CLI (`start|stop|status|doctor`), auto-discovery, systemd/launchd service templates, `curl|bash` installer
- **Phase 1 — The Doctor:** real-time log tailing (file + journalctl), 13 built-in classification rules, alert pipeline with 5-min dedup, webhook notifications
- **Phase 2 — Self-Healing:** 11 built-in remediations, sandboxed command executor, OpenClaw restart manager, JSONL fix ledger, circuit breaker (3 restarts / 10 min)
- **Phase 3 — MCP Client:** HTTP client for proprietary MCP knowledge server (17 tools, 29+ articles), retry/backoff/cache, incident reporting, periodic update polling
- **Phase 4 — Personal Trainer:** context monitor (home dir size tracking), temp file cleaner, dependency auditor, environment validator (API keys, connectivity), CPU/RAM trend tracking with OOM projection
- **Phase 5 — Hardening:** security sandbox (command validation, path restrictions), resource capping (nice + systemd limits), async HTTP status dashboard on `localhost:18790`, KPI tracker (MTTR, uptime, auto-fix rate)
- **Phase 6 — Agent Brain:** LLM-powered reasoning loop via OpenRouter (GLM-4.7-Flash), 10 tools (4 local + 6 MCP), event-triggered with 10s batch window and 30s cooldown, graceful fallback to rules-based healer
- **Phase 7 — Telegram Bot:** two-way conversational interface via python-telegram-bot, `/status` `/logs` `/stats` `/help` commands, CRITICAL alert forwarding with 10-min dedup, chat authorization
- **MCP Server v2:** 17 tools, SQLite + FTS5 backend, 25+ seed articles, 20+ AI model catalog, 25+ error diagnostic patterns, 7 config templates, security audit checklists, n8n auto-update workflow (6h interval)
