"""MCP client — connects EasyClaw to the proprietary MCP knowledge server.

Uses HTTP to call MCP server tools. Keeps things lightweight with no
additional SDK dependencies — just urllib from stdlib + optional aiohttp.
"""

from __future__ import annotations

import asyncio
import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Optional

from easyclaw.logging import get_logger

log = get_logger("mcp_client")

# Retry config
MAX_RETRIES = 2
RETRY_DELAY = 3.0          # seconds between retries
REQUEST_TIMEOUT = 15        # seconds per request


@dataclass
class MCPResponse:
    """Parsed response from an MCP tool call."""

    success: bool
    data: dict = field(default_factory=dict)
    error: Optional[str] = None
    latency: float = 0.0


class MCPClient:
    """Client for the EasyClaw proprietary MCP server.

    Calls server tools via HTTP POST (JSON-RPC style).
    Falls back gracefully when the server is unreachable.
    """

    def __init__(
        self,
        endpoint: Optional[str] = None,
        token: Optional[str] = None,
    ):
        self.endpoint = endpoint       # e.g., "http://31.220.49.171:8002"
        self.token = token or ""
        self._available = endpoint is not None
        self._last_check: float = 0.0
        self._consecutive_failures: int = 0

    @property
    def is_configured(self) -> bool:
        return self._available and self.endpoint is not None

    async def diagnose_issue(self, error_text: str, context: str = "") -> MCPResponse:
        """Query the MCP to diagnose an error using pattern matching."""
        return await self._call_tool("diagnose_issue", {
            "error_text": error_text,
            "context": context,
            "client_token": self.token,
        })

    async def get_full_guide(self, topic: str) -> MCPResponse:
        """Fetch a complete guide by slug or topic search."""
        return await self._call_tool("get_full_guide", {
            "topic": topic,
            "client_token": self.token,
        })

    async def search_knowledge(self, query: str, category: str = "", limit: int = 10) -> MCPResponse:
        """Full-text search across the entire knowledge base."""
        return await self._call_tool("search_knowledge", {
            "query": query,
            "category": category,
            "limit": limit,
            "client_token": self.token,
        })

    async def check_for_updates(self, current_version: str) -> MCPResponse:
        """Check if updates or hotfixes are available."""
        return await self._call_tool("check_for_updates", {
            "current_version": current_version,
            "client_token": self.token,
        })

    async def report_incident(
        self,
        error_type: str,
        error_hash: str,
        severity: str,
        details: str,
        auto_fixed: bool = False,
    ) -> MCPResponse:
        """Report an incident to the central MCP for tracking."""
        return await self._call_tool("report_incident", {
            "error_type": error_type,
            "error_hash": error_hash,
            "severity": severity,
            "details": details,
            "client_token": self.token,
            "auto_fixed": auto_fixed,
        })

    async def validate_subscription(self) -> MCPResponse:
        """Check if the configured token is valid."""
        return await self._call_tool("validate_subscription", {
            "client_token": self.token,
        })

    async def _call_tool(self, tool_name: str, arguments: dict[str, Any]) -> MCPResponse:
        """Call an MCP server tool via HTTP POST.

        Uses JSON-RPC 2.0 format over HTTP, which is compatible with
        FastMCP's HTTP transport.
        """
        if not self.is_configured:
            return MCPResponse(success=False, error="MCP not configured")

        # Back off if too many consecutive failures
        if self._consecutive_failures >= 5:
            elapsed = time.time() - self._last_check
            if elapsed < 300:  # 5 min backoff
                return MCPResponse(
                    success=False,
                    error=f"MCP unavailable (backoff, {self._consecutive_failures} failures)",
                )
            # Reset and try again
            self._consecutive_failures = 0

        url = f"{self.endpoint}/call-tool"
        payload = json.dumps({
            "params": {
                "name": tool_name,
                "arguments": arguments,
            }
        }).encode("utf-8")

        for attempt in range(MAX_RETRIES + 1):
            start = time.monotonic()
            try:
                req = urllib.request.Request(
                    url,
                    data=payload,
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {self.token}",
                    },
                    method="POST",
                )

                loop = asyncio.get_running_loop()
                response = await loop.run_in_executor(
                    None,
                    lambda: urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT),
                )

                body = response.read().decode("utf-8")
                latency = time.monotonic() - start

                data = json.loads(body)

                # Parse MCP response — tool results are in content array
                content = data.get("content", [])
                if content and isinstance(content, list):
                    # First text content block
                    for block in content:
                        if block.get("type") == "text":
                            try:
                                tool_result = json.loads(block["text"])
                                self._consecutive_failures = 0
                                return MCPResponse(
                                    success=True,
                                    data=tool_result,
                                    latency=latency,
                                )
                            except json.JSONDecodeError:
                                self._consecutive_failures = 0
                                return MCPResponse(
                                    success=True,
                                    data={"raw": block["text"]},
                                    latency=latency,
                                )

                # Fallback: return the raw response
                self._consecutive_failures = 0
                return MCPResponse(success=True, data=data, latency=latency)

            except urllib.error.HTTPError as e:
                latency = time.monotonic() - start
                error_body = ""
                try:
                    error_body = e.read().decode("utf-8")[:500]
                except Exception:
                    pass
                log.warning(
                    "MCP HTTP %d for %s (%.1fs): %s",
                    e.code, tool_name, latency, error_body[:100],
                )
                if e.code in (401, 403):
                    # Auth failure — don't retry
                    self._consecutive_failures += 1
                    return MCPResponse(
                        success=False,
                        error=f"Auth failed (HTTP {e.code})",
                        latency=latency,
                    )

            except (urllib.error.URLError, OSError, TimeoutError) as e:
                latency = time.monotonic() - start
                log.warning(
                    "MCP connection error for %s (attempt %d/%d, %.1fs): %s",
                    tool_name, attempt + 1, MAX_RETRIES + 1, latency, e,
                )

            except json.JSONDecodeError as e:
                latency = time.monotonic() - start
                log.warning("MCP response parse error for %s: %s", tool_name, e)
                self._consecutive_failures += 1
                return MCPResponse(
                    success=False,
                    error=f"Invalid JSON response: {e}",
                    latency=latency,
                )

            # Retry delay
            if attempt < MAX_RETRIES:
                await asyncio.sleep(RETRY_DELAY)

        self._consecutive_failures += 1
        self._last_check = time.time()
        return MCPResponse(
            success=False,
            error=f"MCP unreachable after {MAX_RETRIES + 1} attempts",
        )


class MCPKnowledgeCache:
    """Local cache for MCP responses to reduce server load and provide offline fallback.

    Caches get_known_issues results so repeated lookups for the same error
    don't hit the server.
    """

    def __init__(self, ttl_seconds: float = 3600.0):
        self.ttl = ttl_seconds
        self._cache: dict[str, tuple[float, dict]] = {}

    def get(self, key: str) -> Optional[dict]:
        entry = self._cache.get(key)
        if entry is None:
            return None
        cached_at, data = entry
        if time.time() - cached_at > self.ttl:
            del self._cache[key]
            return None
        return data

    def put(self, key: str, data: dict) -> None:
        self._cache[key] = (time.time(), data)

    def clear(self) -> None:
        self._cache.clear()
