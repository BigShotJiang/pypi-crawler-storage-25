"""Local HTTP status dashboard — exposes EasyClaw health data as JSON.

Lightweight async HTTP server using only asyncio (no framework).
Binds to 127.0.0.1 only — never exposed externally.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from datetime import datetime, timezone
from typing import Any, Optional

from easyclaw import __version__
from easyclaw.logging import get_logger

log = get_logger("dashboard")


class DashboardServer:
    """Minimal async HTTP server that serves EasyClaw status as JSON.

    Endpoints:
        GET /status  — full status payload (EasyClaw, OpenClaw, MCP, health, KPIs)
        GET /health  — simple healthcheck: {"status": "ok"}
        *            — 404
    """

    def __init__(self, port: int = 18790) -> None:
        self.port = port
        self._server: Optional[asyncio.AbstractServer] = None

        # Subsystem references — set via set_context() after daemon init
        self._config: Any = None
        self._alert_pipeline: Any = None
        self._ledger: Any = None
        self._breaker: Any = None
        self._mcp_client: Any = None
        self._kpi_tracker: Any = None
        self._start_time: float = time.time()

    def set_context(
        self,
        config: Any,
        alert_pipeline: Any,
        ledger: Any,
        breaker: Any,
        mcp_client: Any,
        kpi_tracker: Any,
        start_time: float,
    ) -> None:
        """Provide references to live subsystem objects.

        Called by the daemon after all subsystems are initialized so the
        dashboard can pull live data from them.

        Args:
            config: EasyClawConfig instance.
            alert_pipeline: AlertPipeline with recent_alerts.
            ledger: FixLedger with get_stats().
            breaker: CircuitBreaker with is_tripped.
            mcp_client: MCPClient (may be None if not configured).
            kpi_tracker: KPITracker with get_kpis().
            start_time: Daemon start timestamp (time.time()).
        """
        self._config = config
        self._alert_pipeline = alert_pipeline
        self._ledger = ledger
        self._breaker = breaker
        self._mcp_client = mcp_client
        self._kpi_tracker = kpi_tracker
        self._start_time = start_time

    async def run(self, shutdown: asyncio.Event) -> None:
        """Start the TCP server and block until shutdown is signaled.

        Args:
            shutdown: asyncio.Event that signals daemon shutdown.
        """
        try:
            self._server = await asyncio.start_server(
                self._handle_request,
                host="127.0.0.1",
                port=self.port,
            )
        except OSError as e:
            log.error("Dashboard server failed to bind on port %d: %s", self.port, e)
            return

        log.info("Dashboard server listening on http://127.0.0.1:%d", self.port)

        try:
            # Wait for shutdown signal
            await shutdown.wait()
        finally:
            self._server.close()
            await self._server.wait_closed()
            log.info("Dashboard server stopped")

    async def _handle_request(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Parse an HTTP request and route to the appropriate handler."""
        try:
            # Read the request line (e.g., "GET /status HTTP/1.1\r\n")
            request_line = await asyncio.wait_for(
                reader.readline(), timeout=5.0,
            )
            request_text = request_line.decode("utf-8", errors="replace").strip()

            if not request_text:
                writer.close()
                await writer.wait_closed()
                return

            parts = request_text.split()
            method = parts[0] if len(parts) >= 1 else ""
            path = parts[1] if len(parts) >= 2 else "/"

            # Consume remaining headers (we don't need them)
            while True:
                header_line = await asyncio.wait_for(
                    reader.readline(), timeout=5.0,
                )
                if header_line in (b"\r\n", b"\n", b""):
                    break

            # Route
            if method != "GET":
                await self._send_response(writer, 405, {"error": "Method not allowed"})
            elif path == "/status":
                body = self._build_status()
                await self._send_response(writer, 200, body)
            elif path == "/health":
                await self._send_response(writer, 200, {"status": "ok"})
            else:
                await self._send_response(writer, 404, {"error": "Not found"})

        except asyncio.TimeoutError:
            log.debug("Dashboard request timed out")
        except Exception:
            log.exception("Dashboard request handler error")
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def _send_response(
        self,
        writer: asyncio.StreamWriter,
        status_code: int,
        body: dict,
    ) -> None:
        """Write an HTTP/1.1 JSON response."""
        status_messages = {
            200: "OK",
            404: "Not Found",
            405: "Method Not Allowed",
            500: "Internal Server Error",
        }
        status_text = status_messages.get(status_code, "Unknown")

        body_bytes = json.dumps(body, indent=2, default=str).encode("utf-8")

        response = (
            f"HTTP/1.1 {status_code} {status_text}\r\n"
            f"Content-Type: application/json\r\n"
            f"Content-Length: {len(body_bytes)}\r\n"
            f"Connection: close\r\n"
            f"\r\n"
        ).encode("utf-8") + body_bytes

        writer.write(response)
        await writer.drain()

    def _build_status(self) -> dict:
        """Assemble the full status payload from live subsystem data."""
        return {
            "easyclaw": self._build_easyclaw_section(),
            "openclaw": self._build_openclaw_section(),
            "mcp": self._build_mcp_section(),
            "health": self._build_health_section(),
            "kpis": self._build_kpi_section(),
        }

    def _build_easyclaw_section(self) -> dict:
        """EasyClaw daemon info."""
        platform_str = ""
        if self._config is not None:
            platform_str = str(self._config.platform.value) if hasattr(self._config.platform, "value") else str(self._config.platform)

        return {
            "version": __version__,
            "status": "running",
            "uptime_seconds": round(time.time() - self._start_time, 1),
            "platform": platform_str,
            "pid": os.getpid(),
        }

    def _build_openclaw_section(self) -> dict:
        """OpenClaw detection status."""
        if self._config is None or self._config.openclaw is None:
            return {
                "detected": False,
                "pid": None,
                "home_dir": None,
                "service": None,
                "gateway_port": None,
            }

        oc = self._config.openclaw
        return {
            "detected": True,
            "pid": getattr(oc, "pid", None),
            "home_dir": str(getattr(oc, "home_dir", None)),
            "service": getattr(oc, "service", None),
            "gateway_port": self._config.settings.get("gateway_port", 18789),
        }

    def _build_mcp_section(self) -> dict:
        """MCP server connection status."""
        if self._mcp_client is None:
            return {
                "configured": False,
                "endpoint": None,
                "available": False,
            }

        return {
            "configured": self._mcp_client.is_configured,
            "endpoint": self._mcp_client.endpoint,
            "available": self._mcp_client.is_configured and self._mcp_client._consecutive_failures == 0,
        }

    def _build_health_section(self) -> dict:
        """Alert and fix statistics."""
        # Alerts in the last hour
        alerts_last_hour = 0
        last_alert_info = None
        if self._alert_pipeline is not None and hasattr(self._alert_pipeline, "recent_alerts"):
            cutoff = time.time() - 3600.0
            for alert in self._alert_pipeline.recent_alerts:
                if alert.timestamp > cutoff:
                    alerts_last_hour += 1

            # Most recent alert
            if self._alert_pipeline.recent_alerts:
                last = self._alert_pipeline.recent_alerts[-1]
                last_alert_info = {
                    "type": last.event_type,
                    "severity": last.severity,
                    "time": datetime.fromtimestamp(
                        last.timestamp, tz=timezone.utc,
                    ).isoformat(),
                }

        # Fix stats from ledger
        fixes_attempted = 0
        fixes_succeeded = 0
        fix_success_rate = 0.0
        if self._ledger is not None:
            stats = self._ledger.get_stats()
            fixes_attempted = stats.get("total", 0)
            fixes_succeeded = stats.get("success", 0)
            if fixes_attempted > 0:
                fix_success_rate = round(
                    fixes_succeeded / fixes_attempted * 100.0, 1,
                )

        # Circuit breaker
        breaker_tripped = False
        if self._breaker is not None:
            breaker_tripped = self._breaker.is_tripped

        return {
            "alerts_last_hour": alerts_last_hour,
            "fixes_attempted": fixes_attempted,
            "fixes_succeeded": fixes_succeeded,
            "fix_success_rate": fix_success_rate,
            "last_alert": last_alert_info,
            "circuit_breaker_tripped": breaker_tripped,
        }

    def _build_kpi_section(self) -> dict:
        """Computed KPI metrics."""
        if self._kpi_tracker is None:
            return {
                "mttr_seconds": 0.0,
                "intervention_rate_per_day": 0.0,
                "uptime_percent": 0.0,
                "auto_fix_rate": 0.0,
                "total_incidents": 0,
            }

        return self._kpi_tracker.get_kpis()
