"""EasyClaw agent brain — LLM-powered reasoning loop via OpenRouter.

Copies OpenClaw's agent architecture: system prompt -> model call -> parse
tool_calls -> execute tools -> loop.  Sits on top of the existing
detection/alerting/healing infrastructure as the decision maker.

Model: GLM-4.7-Flash via OpenRouter (~$0.10/M in, $0.30/M out).
Fallback: rules-based Healer when no API key or OpenRouter is unreachable.
"""

from __future__ import annotations

import asyncio
import json
import time
import urllib.error
import urllib.request
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Optional, Union

from easyclaw.classifier import Event, Severity
from easyclaw.logging import get_logger

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from easyclaw.alerts import AlertPipeline
    from easyclaw.config import EasyClawConfig
    from easyclaw.discovery import OpenClawInstance
    from easyclaw.executor import CommandExecutor
    from easyclaw.healer import Healer
    from easyclaw.kpi import KPITracker
    from easyclaw.ledger import CircuitBreaker, FixLedger
    from easyclaw.mcp_client import MCPClient
    from easyclaw.restart import RestartManager
    from easyclaw.sandbox import SecuritySandbox

log = get_logger("agent")

# ── Constants ──────────────────────────────────────────────────────────

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_MODEL = "z-ai/glm-4.7-flash"
MAX_TOKENS = 2048
MAX_RESULT_CHARS = 4096  # cap tool result text sent back to model


# ── Data structures ────────────────────────────────────────────────────

@dataclass
class InvocationSummary:
    """Record of a single agent invocation for recent-history context."""
    timestamp: float
    event_types: list[str]
    actions_taken: list[str]
    outcome: str  # "success", "partial", "failed", "fallback"
    duration: float = 0.0


# ── Local tool definitions (OpenAI function-calling format) ────────────

LOCAL_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "execute_shell_command",
            "description": (
                "Run a shell command on the host. All commands are validated "
                "by a security sandbox before execution. Dangerous commands "
                "(rm -rf /, package installs, etc.) will be blocked."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The shell command to execute",
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout in seconds (default 30, max 120)",
                    },
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": (
                "Read the contents of a file on disk. Useful for inspecting "
                "OpenClaw config files, logs, or error outputs."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Absolute path to the file",
                    },
                    "max_lines": {
                        "type": "integer",
                        "description": "Maximum lines to read (default 100)",
                    },
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "restart_openclaw",
            "description": (
                "Restart the OpenClaw service or process. Checks the circuit "
                "breaker first — will refuse if too many recent restarts."
            ),
            "parameters": {
                "type": "object",
                "properties": {},
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_recent_logs",
            "description": (
                "Get the last N lines from an OpenClaw log file. "
                "Useful for seeing what happened before an error."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "source": {
                        "type": "string",
                        "description": "Log file name (e.g. 'extraction.log')",
                    },
                    "lines": {
                        "type": "integer",
                        "description": "Number of lines to return (default 50, max 200)",
                    },
                },
                "required": ["source"],
            },
        },
    },
]

# ── MCP tool definitions ──────────────────────────────────────────────

MCP_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "mcp_diagnose_issue",
            "description": (
                "Query the MCP knowledge base for error diagnosis. Returns "
                "matched error patterns, root causes, and fix steps."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "error_text": {
                        "type": "string",
                        "description": "The error message or log line to diagnose",
                    },
                    "context": {
                        "type": "string",
                        "description": "Additional context about what was happening",
                    },
                },
                "required": ["error_text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp_search_knowledge",
            "description": (
                "Full-text search across the entire OpenClaw knowledge base. "
                "Returns matching articles ranked by relevance."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query",
                    },
                    "category": {
                        "type": "string",
                        "description": "Optional category filter (e.g. 'troubleshooting', 'configuration')",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp_get_full_guide",
            "description": (
                "Fetch a complete troubleshooting or configuration guide by topic."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "topic": {
                        "type": "string",
                        "description": "Topic or slug of the guide to fetch",
                    },
                },
                "required": ["topic"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp_troubleshoot_gateway",
            "description": (
                "Symptom-based troubleshooting for the OpenClaw gateway. "
                "Provide a symptom and get diagnostic steps."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "symptom": {
                        "type": "string",
                        "description": "The symptom to troubleshoot (e.g. 'connection refused', 'slow responses')",
                    },
                },
                "required": ["symptom"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp_search_web",
            "description": (
                "Search the web for solutions via SearXNG. Use when the "
                "knowledge base doesn't have an answer."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Web search query",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "mcp_report_incident",
            "description": (
                "Report an incident to central tracking after fixing or "
                "escalating a problem."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "error_type": {
                        "type": "string",
                        "description": "Type of error (e.g. 'process_oom', 'connection_refused')",
                    },
                    "severity": {
                        "type": "string",
                        "description": "Severity level: INFO, WARNING, or CRITICAL",
                    },
                    "details": {
                        "type": "string",
                        "description": "Description of what happened and what was done",
                    },
                    "auto_fixed": {
                        "type": "boolean",
                        "description": "Whether the issue was automatically fixed",
                    },
                },
                "required": ["error_type", "severity", "details", "auto_fixed"],
            },
        },
    },
]


# ── System prompt builder ──────────────────────────────────────────────

def _build_system_prompt(
    config: "EasyClawConfig",
    openclaw: Optional["OpenClawInstance"],
    breaker: "CircuitBreaker",
    mcp_client: Optional["MCPClient"],
    kpi_tracker: Optional["KPITracker"],
    recent_history: list[InvocationSummary],
) -> str:
    """Build a fresh system prompt with current state for the agent."""

    # OpenClaw status
    oc_status = "not detected"
    oc_details = ""
    if openclaw:
        if openclaw.pid:
            try:
                import psutil
                proc = psutil.Process(openclaw.pid)
                cpu = proc.cpu_percent(interval=0.1)
                mem = proc.memory_info().rss / (1024 * 1024)
                uptime = time.time() - proc.create_time()
                oc_status = f"running (PID {openclaw.pid})"
                oc_details = f"CPU: {cpu:.1f}% | RAM: {mem:.0f}MB | uptime: {uptime:.0f}s"
            except Exception:
                oc_status = f"PID {openclaw.pid} (status unknown)"
        else:
            oc_status = "detected but not running"

    # Circuit breaker
    cb_status = "TRIPPED - restarts blocked" if breaker.is_tripped else "OK"

    # MCP
    mcp_status = "connected" if (mcp_client and mcp_client.is_configured) else "disconnected"

    # KPIs
    kpi_line = "Not available"
    if kpi_tracker:
        try:
            kpis = kpi_tracker.snapshot()
            kpi_line = (
                f"MTTR: {kpis.get('mttr', 0):.1f}s | "
                f"Uptime: {kpis.get('uptime_pct', 0):.1f}% | "
                f"Auto-fix rate: {kpis.get('auto_fix_rate', 0):.1f}% | "
                f"Incidents today: {kpis.get('incidents_today', 0)}"
            )
        except Exception:
            pass

    # Recent history
    history_lines = []
    for h in recent_history[-5:]:
        ts = time.strftime("%H:%M:%S", time.localtime(h.timestamp))
        events = ", ".join(h.event_types[:3])
        actions = ", ".join(h.actions_taken[:3]) or "none"
        history_lines.append(
            f"- [{ts}] Events: {events}. Actions: {actions}. Result: {h.outcome} ({h.duration:.1f}s)"
        )
    history_block = "\n".join(history_lines) if history_lines else "No recent interventions."

    return f"""You are EasyClaw, an autonomous monitoring and self-healing agent for OpenClaw (an AI coding agent platform). You run as a lightweight background daemon on the user's server.

Your job: analyze incoming error events, diagnose root causes, and apply fixes using your tools. You have access to shell commands, the MCP knowledge base (comprehensive OpenClaw documentation and diagnostics), and the ability to restart OpenClaw.

## CURRENT STATE
OpenClaw: {oc_status}
{oc_details}
Circuit breaker: {cb_status}
MCP server: {mcp_status}
Platform: {config.platform.system}{' (WSL)' if config.platform.is_wsl else ''}

## RECENT HISTORY
{history_block}

## KPIs
{kpi_line}

## RULES
1. SAFETY FIRST: All shell commands are validated by a security sandbox. Dangerous commands will be blocked automatically. Never attempt to work around the sandbox.
2. MINIMAL INTERVENTION: Prefer the lightest fix. Clear a lock file before restarting. Restart before reinstalling. One targeted command beats a shotgun approach.
3. CIRCUIT BREAKER: If the circuit breaker is TRIPPED, do NOT attempt restarts. Report the situation clearly.
4. USE KNOWLEDGE: Before guessing at a fix, query mcp_diagnose_issue or mcp_search_knowledge to find the documented solution.
5. REPORT: After fixing an issue, call mcp_report_incident to log the outcome centrally.
6. EXPLAIN: End your final response with a brief 1-2 sentence summary of what happened and what you did.
7. EFFICIENCY: You are a lightweight daemon. Use as few tool calls as necessary. Don't make redundant queries.
8. SCOPE: You can only fix OpenClaw-related issues. If the problem is outside your scope (hardware, OS, network infrastructure), say so clearly."""


# ── Agent brain class ──────────────────────────────────────────────────

class AgentBrain:
    """LLM-powered agent that reasons about events and decides on actions.

    Copies OpenClaw's agent loop pattern:
    system prompt -> model call -> parse tool_calls -> execute -> loop

    Event-triggered with batching: collects events for batch_window seconds,
    then invokes the LLM to reason about the batch. Cooldown between invocations
    prevents excessive API calls.

    Falls back to the rules-based Healer when:
    - No OpenRouter API key configured
    - OpenRouter is unreachable
    - Agent invocation raises an unexpected exception
    """

    def __init__(
        self,
        config: "EasyClawConfig",
        executor: "CommandExecutor",
        restart_mgr: "RestartManager",
        ledger: "FixLedger",
        breaker: "CircuitBreaker",
        alert_pipeline: "AlertPipeline",
        openclaw: Optional["OpenClawInstance"] = None,
        mcp_client: Optional["MCPClient"] = None,
        sandbox: Optional["SecuritySandbox"] = None,
        kpi_tracker: Optional["KPITracker"] = None,
    ):
        self.config = config
        self.executor = executor
        self.restart_mgr = restart_mgr
        self.ledger = ledger
        self.breaker = breaker
        self.alert_pipeline = alert_pipeline
        self.openclaw = openclaw
        self.mcp = mcp_client
        self.sandbox = sandbox
        self.kpi = kpi_tracker

        # Config
        settings = config.settings
        self._api_key: str = settings.get("openrouter_api_key") or ""
        self._model: str = settings.get("openrouter_model") or DEFAULT_MODEL
        self._enabled: bool = settings.get("agent_enabled", True)
        self._batch_window: float = float(settings.get("agent_batch_window", 10))
        self._cooldown: float = float(settings.get("agent_cooldown", 30))
        self._max_turns: int = int(settings.get("agent_max_turns", 10))
        self._temperature: float = float(settings.get("agent_temperature", 0.1))

        # State
        self._event_queue: asyncio.Queue[Event] = asyncio.Queue(maxsize=100)
        # Conversation history per chat_id (Telegram user)
        self._chat_history: dict[Union[int, str], deque[dict[str, str]]] = {}
        self._chat_last_active: dict[Union[int, str], float] = {}
        self._chat_history_max: int = 20  # max message pairs to keep
        self._chat_ttl: float = 3600.0  # clear history after 1 hour of inactivity
        self._recent_history: deque[InvocationSummary] = deque(maxlen=10)
        self._fallback_healer: Optional["Healer"] = None
        self._disabled_reason: Optional[str] = None

    @property
    def is_available(self) -> bool:
        """True if the agent brain is configured and enabled."""
        return (
            self._enabled
            and bool(self._api_key)
            and self._disabled_reason is None
        )

    def set_fallback_healer(self, healer: "Healer") -> None:
        """Set the rules-based healer as fallback for when LLM is unavailable."""
        self._fallback_healer = healer

    def enqueue(self, event: Event) -> None:
        """Submit an event for agent processing."""
        if event.severity in (Severity.WARNING, Severity.CRITICAL):
            try:
                self._event_queue.put_nowait(event)
            except asyncio.QueueFull:
                log.warning("Agent event queue full — dropping event: %s", event.event_type.value)

    async def run(self, shutdown: asyncio.Event) -> None:
        """Main agent loop — collect event batches and invoke LLM."""
        if not self.is_available:
            reason = self._disabled_reason or "no API key"
            log.info("Agent brain not available (%s) — events will use rules-based healer", reason)
            return

        log.info("Agent brain started (model=%s)", self._model)

        while not shutdown.is_set():
            # Collect a batch of events
            events = await self._collect_batch(shutdown)
            if not events:
                continue

            start = time.monotonic()
            try:
                await self._invoke_agent(events)
            except Exception:
                log.exception("Agent invocation failed — falling back to rules-based healer")
                self._fallback_events(events)

            # Cooldown between invocations
            try:
                await asyncio.wait_for(shutdown.wait(), timeout=self._cooldown)
                break  # shutdown was set
            except asyncio.TimeoutError:
                pass

        log.info("Agent brain stopped")

    async def _collect_batch(self, shutdown: asyncio.Event) -> list[Event]:
        """Wait for events, then drain the queue within the batch window."""
        # Wait for the first event (or shutdown)
        try:
            first = await asyncio.wait_for(
                self._event_queue.get(), timeout=5.0,
            )
        except asyncio.TimeoutError:
            return []

        events = [first]

        # Drain remaining events within batch window
        deadline = time.monotonic() + self._batch_window
        while time.monotonic() < deadline and len(events) < 10:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                event = await asyncio.wait_for(
                    self._event_queue.get(), timeout=min(remaining, 1.0),
                )
                events.append(event)
            except asyncio.TimeoutError:
                break

        log.info("Collected %d events for agent invocation", len(events))
        return events

    async def _invoke_agent(self, events: list[Event]) -> None:
        """Run the agent reasoning loop for a batch of events."""
        start = time.monotonic()
        actions_taken: list[str] = []

        # Build messages
        system_prompt = _build_system_prompt(
            config=self.config,
            openclaw=self.openclaw,
            breaker=self.breaker,
            mcp_client=self.mcp,
            kpi_tracker=self.kpi,
            recent_history=list(self._recent_history),
        )

        user_message = self._format_events(events)

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]

        tools = self._get_tool_definitions()

        # Agent loop: call model, execute tools, repeat
        for turn in range(self._max_turns):
            response = await self._call_openrouter(messages, tools)
            if response is None:
                # API failure — fall back
                self._fallback_events(events)
                self._record_history(events, actions_taken, "fallback", time.monotonic() - start)
                return

            message = response.get("choices", [{}])[0].get("message", {})

            # Append assistant message to conversation
            messages.append({"role": "assistant", **self._clean_message(message)})

            tool_calls = message.get("tool_calls")
            if not tool_calls:
                # No more tool calls — agent is done reasoning
                break

            # Execute each tool call
            for tc in tool_calls:
                fn = tc.get("function", {})
                fn_name = fn.get("name", "")
                try:
                    fn_args = json.loads(fn.get("arguments", "{}"))
                except json.JSONDecodeError:
                    fn_args = {}

                log.info("Agent calling tool: %s(%s)", fn_name, _truncate(json.dumps(fn_args), 100))
                result = await self._execute_tool(fn_name, fn_args)
                actions_taken.append(fn_name)

                # Append tool result to conversation
                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.get("id", ""),
                    "content": result[:MAX_RESULT_CHARS],
                })

        # Determine outcome
        duration = time.monotonic() - start
        outcome = "success" if actions_taken else "no_action"

        # Log agent's final response
        final_text = messages[-1].get("content", "") if messages[-1].get("role") == "assistant" else ""
        if final_text:
            log.info("Agent summary: %s", _truncate(final_text, 200))

        self._record_history(events, actions_taken, outcome, duration)
        log.info("Agent invocation complete: %d tools called in %.1fs", len(actions_taken), duration)

    def _format_events(self, events: list[Event]) -> str:
        """Format a batch of events into the user message for the LLM."""
        lines = ["The following events were detected and need your attention:\n"]
        for i, event in enumerate(events, 1):
            ctx = "\n".join(f"  > {l}" for l in event.context_lines[-3:]) if event.context_lines else "  (no context)"
            lines.append(
                f"### Event {i}: [{event.severity.value}] {event.event_type.value}\n"
                f"- Source: {event.source}\n"
                f"- Pattern: {event.pattern_name}\n"
                f"- Log line: {event.line[:300]}\n"
                f"- Context:\n{ctx}\n"
            )
        return "\n".join(lines)

    def _get_tool_definitions(self) -> list[dict]:
        """Return all available tool definitions."""
        tools = list(LOCAL_TOOLS)
        if self.mcp and self.mcp.is_configured:
            tools.extend(MCP_TOOLS)
        return tools

    def _clean_message(self, message: dict) -> dict:
        """Clean a message dict for re-injection into conversation."""
        cleaned: dict[str, Any] = {}
        if message.get("content"):
            cleaned["content"] = message["content"]
        if message.get("tool_calls"):
            cleaned["tool_calls"] = message["tool_calls"]
        if message.get("role"):
            cleaned["role"] = message["role"]
        return cleaned

    # ── OpenRouter HTTP client ─────────────────────────────────────────

    async def _call_openrouter(
        self,
        messages: list[dict],
        tools: list[dict],
    ) -> Optional[dict]:
        """Call OpenRouter API (non-streaming). Returns parsed response or None on failure."""
        payload = json.dumps({
            "model": self._model,
            "messages": messages,
            "tools": tools if tools else None,
            "tool_choice": "auto",
            "max_tokens": MAX_TOKENS,
            "temperature": self._temperature,
        }).encode("utf-8")

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._api_key}",
            "HTTP-Referer": "https://easyclaw.help",
            "X-Title": "EasyClaw Agent",
        }

        req = urllib.request.Request(
            OPENROUTER_URL,
            data=payload,
            headers=headers,
            method="POST",
        )

        loop = asyncio.get_running_loop()

        try:
            response = await loop.run_in_executor(
                None,
                lambda: urllib.request.urlopen(req, timeout=60),
            )
            body = response.read().decode("utf-8")
            data = json.loads(body)

            # Check for OpenRouter error responses
            if "error" in data:
                err = data["error"]
                err_msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
                log.error("OpenRouter error: %s", err_msg)
                return None

            return data

        except urllib.error.HTTPError as e:
            error_body = ""
            try:
                error_body = e.read().decode("utf-8")[:500]
            except Exception:
                pass

            if e.code == 429:
                log.warning("OpenRouter rate limited (429) — will retry next invocation")
            elif e.code in (401, 403):
                log.error("OpenRouter auth failed (HTTP %d) — disabling agent brain", e.code)
                self._disabled_reason = f"Auth failed (HTTP {e.code})"
            else:
                log.error("OpenRouter HTTP %d: %s", e.code, error_body[:200])
            return None

        except (urllib.error.URLError, OSError, TimeoutError) as e:
            log.warning("OpenRouter connection error: %s", e)
            return None

        except json.JSONDecodeError as e:
            log.error("OpenRouter response parse error: %s", e)
            return None

    # ── Tool execution ─────────────────────────────────────────────────

    async def _execute_tool(self, name: str, args: dict) -> str:
        """Route a tool call to the appropriate handler."""
        try:
            if name == "execute_shell_command":
                return await self._tool_shell(args)
            elif name == "read_file":
                return await self._tool_read_file(args)
            elif name == "restart_openclaw":
                return await self._tool_restart()
            elif name == "list_recent_logs":
                return await self._tool_recent_logs(args)
            elif name.startswith("mcp_"):
                return await self._tool_mcp(name, args)
            else:
                return json.dumps({"error": f"Unknown tool: {name}"})
        except Exception as e:
            log.exception("Tool execution error: %s", name)
            return json.dumps({"error": str(e)})

    async def _tool_shell(self, args: dict) -> str:
        """Execute a shell command through the sandbox."""
        command = args.get("command", "")
        timeout = min(int(args.get("timeout", 30)), 120)

        if not command:
            return json.dumps({"error": "No command provided"})

        # Sandbox validation
        if self.sandbox:
            allowed, reason = self.sandbox.validate_command(command)
            if not allowed:
                log.warning("Sandbox blocked agent command: %s — %s", command, reason)
                return json.dumps({"blocked": True, "reason": reason})

        result = await self.executor.execute(command, timeout=timeout)

        # Record to ledger
        from easyclaw.ledger import LedgerEntry
        self.ledger.record(LedgerEntry(
            timestamp=time.time(),
            error_hash="agent_cmd",
            event_type="agent_action",
            pattern_name="agent",
            severity="INFO",
            action_name=f"agent_shell",
            action_type="command",
            success=result.return_code == 0,
            duration=result.duration,
            commands_run=[command],
            output=result.stdout[:500] if result.stdout else "",
            error=result.stderr[:200] if result.stderr else None,
            restart_performed=False,
        ))

        if self.kpi and result.return_code == 0:
            self.kpi.record_fix(result.duration, True)

        return json.dumps({
            "return_code": result.return_code,
            "stdout": result.stdout[:2000] if result.stdout else "",
            "stderr": result.stderr[:500] if result.stderr else "",
            "timed_out": result.timed_out,
            "duration": round(result.duration, 2),
        })

    async def _tool_read_file(self, args: dict) -> str:
        """Read a file's contents."""
        path = args.get("path", "")
        max_lines = min(int(args.get("max_lines", 100)), 500)

        if not path:
            return json.dumps({"error": "No path provided"})

        # Validate read is safe (only OpenClaw/EasyClaw paths)
        if self.sandbox:
            allowed, reason = self.sandbox.validate_command(f"cat {path}")
            if not allowed:
                return json.dumps({"blocked": True, "reason": reason})

        try:
            with open(path, "r", errors="replace") as f:
                lines = []
                for i, line in enumerate(f):
                    if i >= max_lines:
                        break
                    lines.append(line.rstrip())
            return "\n".join(lines)
        except FileNotFoundError:
            return json.dumps({"error": f"File not found: {path}"})
        except PermissionError:
            return json.dumps({"error": f"Permission denied: {path}"})
        except OSError as e:
            return json.dumps({"error": str(e)})

    async def _tool_restart(self) -> str:
        """Restart OpenClaw."""
        if self.breaker.is_tripped:
            return json.dumps({
                "error": "Circuit breaker is TRIPPED — too many recent restarts. Manual intervention required.",
            })

        if self.openclaw is None:
            return json.dumps({"error": "No OpenClaw instance detected — cannot restart."})

        if self.breaker.check_and_trip():
            return json.dumps({
                "error": "Circuit breaker tripped by this restart attempt.",
            })

        log.info("Agent triggering OpenClaw restart")
        result = await self.restart_mgr.restart(self.openclaw)

        # Record to ledger
        from easyclaw.ledger import LedgerEntry
        self.ledger.record(LedgerEntry(
            timestamp=time.time(),
            error_hash="agent_restart",
            event_type="agent_action",
            pattern_name="agent",
            severity="WARNING",
            action_name="agent_restart",
            action_type="restart",
            success=result.success,
            duration=result.duration,
            commands_run=[],
            output=f"Restart {'succeeded' if result.success else 'failed'} in {result.duration:.1f}s",
            error=result.error if not result.success else None,
            restart_performed=True,
        ))

        if self.kpi:
            self.kpi.record_fix(result.duration, result.success)

        return json.dumps({
            "success": result.success,
            "duration": round(result.duration, 2),
            "error": result.error,
        })

    async def _tool_recent_logs(self, args: dict) -> str:
        """Read recent lines from an OpenClaw log file."""
        source = args.get("source", "extraction.log")
        lines_count = min(int(args.get("lines", 50)), 200)

        if self.openclaw is None or self.openclaw.log_dir is None:
            return json.dumps({"error": "OpenClaw log directory not found"})

        log_file = self.openclaw.log_dir / source
        if not log_file.is_file():
            return json.dumps({"error": f"Log file not found: {source}"})

        try:
            with open(log_file, "r", errors="replace") as f:
                all_lines = f.readlines()
            tail = all_lines[-lines_count:]
            return "".join(tail)
        except OSError as e:
            return json.dumps({"error": str(e)})

    async def _tool_mcp(self, name: str, args: dict) -> str:
        """Route MCP tool calls to the MCP client."""
        if not self.mcp or not self.mcp.is_configured:
            return json.dumps({"error": "MCP server not configured"})

        # Strip mcp_ prefix to get the actual tool name
        tool_name = name[4:]  # "mcp_diagnose_issue" -> "diagnose_issue"

        if tool_name == "diagnose_issue":
            resp = await self.mcp.diagnose_issue(
                error_text=args.get("error_text", ""),
                context=args.get("context", ""),
            )
        elif tool_name == "search_knowledge":
            resp = await self.mcp.search_knowledge(
                query=args.get("query", ""),
                category=args.get("category", ""),
            )
        elif tool_name == "get_full_guide":
            resp = await self.mcp.get_full_guide(
                topic=args.get("topic", ""),
            )
        elif tool_name == "troubleshoot_gateway":
            # troubleshoot_gateway uses the generic _call_tool
            resp = await self.mcp._call_tool("troubleshoot_gateway", {
                "symptom": args.get("symptom", ""),
                "client_token": self.mcp.token,
            })
        elif tool_name == "search_web":
            resp = await self.mcp._call_tool("search_web", {
                "query": args.get("query", ""),
                "client_token": self.mcp.token,
            })
        elif tool_name == "report_incident":
            resp = await self.mcp.report_incident(
                error_type=args.get("error_type", ""),
                error_hash="agent_report",
                severity=args.get("severity", "WARNING"),
                details=args.get("details", ""),
                auto_fixed=args.get("auto_fixed", False),
            )
        else:
            return json.dumps({"error": f"Unknown MCP tool: {tool_name}"})

        if resp.success:
            return json.dumps(resp.data, default=str)[:MAX_RESULT_CHARS]
        else:
            return json.dumps({"error": resp.error or "MCP call failed"})

    # ── Conversational interface (Telegram) ──────────────────────────────

    async def chat(self, user_message: str, chat_id: Union[int, str] = "default") -> str:
        """Handle a conversational message (from Telegram).

        Routes through the same OpenRouter LLM + tool-calling loop as event
        handling, but with a conversational system prompt and persistent
        conversation history per chat_id. Returns the agent's text response.
        """
        if not self.is_available:
            return "EasyClaw agent brain is not available (no API key configured)."

        now = time.time()

        # Expire stale conversations
        self._expire_chat_history(now)

        # Get or create history for this chat
        if chat_id not in self._chat_history:
            self._chat_history[chat_id] = deque(maxlen=self._chat_history_max)
        history = self._chat_history[chat_id]
        self._chat_last_active[chat_id] = now

        system_prompt = self._build_chat_system_prompt()

        # Build messages: system prompt + conversation history + new message
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_prompt},
        ]
        for hist_msg in history:
            messages.append(hist_msg)
        messages.append({"role": "user", "content": user_message})

        tools = self._get_tool_definitions()
        assistant_text = ""

        for turn in range(self._max_turns):
            response = await self._call_openrouter(messages, tools)
            if response is None:
                return "Sorry, I couldn't reach the AI service right now. Try again in a moment."

            message = response.get("choices", [{}])[0].get("message", {})
            messages.append({"role": "assistant", **self._clean_message(message)})

            tool_calls = message.get("tool_calls")
            if not tool_calls:
                # Done — return the text response
                assistant_text = message.get("content", "") or "(no response)"
                break

            # Execute tool calls and continue the loop
            for tc in tool_calls:
                fn = tc.get("function", {})
                fn_name = fn.get("name", "")
                try:
                    fn_args = json.loads(fn.get("arguments", "{}"))
                except json.JSONDecodeError:
                    fn_args = {}

                log.info("Chat tool call: %s(%s)", fn_name, _truncate(json.dumps(fn_args), 100))
                result = await self._execute_tool(fn_name, fn_args)

                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.get("id", ""),
                    "content": result[:MAX_RESULT_CHARS],
                })
        else:
            # Hit max turns — grab last assistant text
            for msg in reversed(messages):
                if msg.get("role") == "assistant" and msg.get("content"):
                    assistant_text = msg["content"]
                    break
            if not assistant_text:
                assistant_text = "I ran out of reasoning steps. Please try a simpler question."

        # Save to conversation history (user + assistant only, not tool calls)
        history.append({"role": "user", "content": user_message})
        history.append({"role": "assistant", "content": assistant_text})

        return assistant_text

    def _expire_chat_history(self, now: float) -> None:
        """Remove conversation histories that have been inactive past the TTL."""
        expired = [
            cid for cid, last in self._chat_last_active.items()
            if now - last > self._chat_ttl
        ]
        for cid in expired:
            self._chat_history.pop(cid, None)
            self._chat_last_active.pop(cid, None)
            log.debug("Expired chat history for %s", cid)

    def _build_chat_system_prompt(self) -> str:
        """Build system prompt for conversational use (Telegram)."""
        base = _build_system_prompt(
            config=self.config,
            openclaw=self.openclaw,
            breaker=self.breaker,
            mcp_client=self.mcp,
            kpi_tracker=self.kpi,
            recent_history=list(self._recent_history),
        )

        chat_addendum = """

## CONVERSATION MODE
The user is messaging you via Telegram. You have conversation history — you remember what was said earlier in this chat session.

CRITICAL BEHAVIOR RULES:
1. INVESTIGATE FIRST, RESPOND SECOND: When the user reports a problem, immediately use your tools (read logs, check config, run commands) to diagnose it. Do NOT ask the user for information you can look up yourself.
2. NEVER ask "can you share the error message?" or "what does the log say?" — YOU read the logs. NEVER ask "where is the config?" — YOU find it.
3. ACT, THEN EXPLAIN: Run diagnostics, attempt a fix, then tell the user what you found and what you did.
4. DO NOT ask the user to repeat themselves. You have conversation history. If they already told you something, use that context.
5. Keep responses under 500 words. Use plain text, not markdown.
6. Be direct and action-oriented. The user is a busy admin — they want fixes, not questions."""

        return base + chat_addendum

    # ── Helpers ─────────────────────────────────────────────────────────

    def _fallback_events(self, events: list[Event]) -> None:
        """Send events to the rules-based healer as fallback."""
        if not self._fallback_healer:
            log.warning("No fallback healer configured — %d events dropped", len(events))
            return
        for event in events:
            self._fallback_healer.enqueue(event)
        log.info("Passed %d events to rules-based healer (fallback)", len(events))

    def _record_history(
        self,
        events: list[Event],
        actions: list[str],
        outcome: str,
        duration: float,
    ) -> None:
        """Record an invocation summary for recent-history context."""
        self._recent_history.append(InvocationSummary(
            timestamp=time.time(),
            event_types=[e.event_type.value for e in events],
            actions_taken=actions,
            outcome=outcome,
            duration=duration,
        ))


def _truncate(text: str, max_len: int) -> str:
    """Truncate text with ellipsis if needed."""
    if len(text) <= max_len:
        return text
    return text[:max_len - 3] + "..."
