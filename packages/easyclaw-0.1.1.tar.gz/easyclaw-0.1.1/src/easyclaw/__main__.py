"""Allow running EasyClaw as `python -m easyclaw`."""

from easyclaw.cli import main

if __name__ == "__main__":
    main()
