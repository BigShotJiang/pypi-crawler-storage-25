"""EasyClaw — Autonomous doctor and personal trainer for OpenClaw agents."""

__version__ = "0.1.1"
