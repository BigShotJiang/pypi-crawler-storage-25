"""Structured logging for EasyClaw — file + console output."""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


class JSONFormatter(logging.Formatter):
    """Emit log records as single-line JSON for machine parsing."""

    def format(self, record: logging.LogRecord) -> str:
        entry: Dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "module": record.module,
            "msg": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0] is not None:
            entry["exc"] = self.formatException(record.exc_info)
        # Merge any extra fields passed via `extra={"data": {...}}`
        if hasattr(record, "data") and isinstance(record.data, dict):
            entry["data"] = record.data
        return json.dumps(entry, default=str)


class ConsoleFormatter(logging.Formatter):
    """Human-friendly console output."""

    LEVEL_COLORS = {
        "DEBUG": "\033[36m",     # cyan
        "INFO": "\033[32m",      # green
        "WARNING": "\033[33m",   # yellow
        "ERROR": "\033[31m",     # red
        "CRITICAL": "\033[1;31m",  # bold red
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        ts = datetime.now().strftime("%H:%M:%S")
        color = self.LEVEL_COLORS.get(record.levelname, "")
        reset = self.RESET if color else ""
        level = record.levelname[0]  # single char: I, W, E, C, D
        return f"{ts} {color}{level}{reset} [{record.module}] {record.getMessage()}"


def setup_logging(
    log_dir: Path,
    level: str = "INFO",
    console: bool = True,
) -> logging.Logger:
    """Configure EasyClaw's root logger.

    - JSON log file at log_dir/easyclaw.log (rotated by date in filename)
    - Optional colored console output
    """
    logger = logging.getLogger("easyclaw")
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.handlers.clear()

    # File handler — JSON lines
    today = datetime.now().strftime("%Y-%m-%d")
    log_file = log_dir / f"easyclaw-{today}.log"
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(JSONFormatter())
    logger.addHandler(fh)

    # Console handler
    if console:
        ch = logging.StreamHandler(sys.stderr)
        ch.setFormatter(ConsoleFormatter())
        logger.addHandler(ch)

    return logger


def get_logger(name: str = "easyclaw") -> logging.Logger:
    """Get a child logger under the easyclaw namespace."""
    return logging.getLogger(f"easyclaw.{name}")
