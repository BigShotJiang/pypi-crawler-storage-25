"""EasyClaw daemon — asyncio event loop with heartbeat, log monitoring, and graceful shutdown."""

from __future__ import annotations

import asyncio
import os
import signal
import sys
import time
from pathlib import Path
from typing import Optional

from easyclaw.config import EasyClawConfig, load_config
from easyclaw.logging import get_logger, setup_logging

log = get_logger("daemon")


class EasyClawDaemon:
    """Core daemon that runs the heartbeat loop and orchestrates subsystems."""

    def __init__(self, config: EasyClawConfig):
        self.config = config
        self._shutdown_event = asyncio.Event()
        self._start_time: float = 0.0

    @property
    def uptime(self) -> float:
        """Seconds since daemon started."""
        if self._start_time == 0.0:
            return 0.0
        return time.monotonic() - self._start_time

    def _write_pidfile(self) -> None:
        """Write PID file so CLI can check if daemon is running."""
        pidfile = self.config.state_dir / "daemon.pid"
        pidfile.write_text(str(os.getpid()))

    def _remove_pidfile(self) -> None:
        pidfile = self.config.state_dir / "daemon.pid"
        pidfile.unlink(missing_ok=True)

    def _write_state(self, status: str, extra: Optional[dict] = None) -> None:
        """Write a simple state file for the CLI status command."""
        import json
        from datetime import datetime, timezone

        state = {
            "pid": os.getpid(),
            "status": status,
            "started_at": datetime.now(timezone.utc).isoformat(),
            "uptime_seconds": round(self.uptime, 1),
            "openclaw_detected": self.config.openclaw is not None,
            "openclaw_pid": self.config.openclaw.pid if self.config.openclaw else None,
            "platform": self.config.platform.system,
            "is_wsl": self.config.platform.is_wsl,
        }
        if extra:
            state.update(extra)
        state_file = self.config.state_dir / "daemon.json"
        state_file.write_text(json.dumps(state, indent=2))

    def _install_signal_handlers(self, loop: asyncio.AbstractEventLoop) -> None:
        """Register SIGTERM/SIGINT for graceful shutdown."""
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(sig, self._request_shutdown, sig)
            except NotImplementedError:
                # Windows doesn't support add_signal_handler — use fallback
                signal.signal(sig, lambda s, f: self._request_shutdown(s))

    def _request_shutdown(self, sig: signal.Signals) -> None:
        log.info("Received %s — shutting down gracefully", sig.name if hasattr(sig, 'name') else sig)
        self._shutdown_event.set()

    def _setup_log_sources(self):
        """Configure log tailers based on discovered OpenClaw installation."""
        from easyclaw.tailer import LogAggregator

        aggregator = LogAggregator()
        oc = self.config.openclaw

        if oc is None:
            return aggregator

        # Tail OpenClaw's log directory
        if oc.log_dir and oc.log_dir.is_dir():
            # Main log files in /tmp/openclaw/
            for log_file in oc.log_dir.glob("*.log"):
                aggregator.add_file(f"file:{log_file.name}", log_file)
                log.info("Tailing log file: %s", log_file)

            # Also tail any new .log files that appear
            # For now, we tail extraction.log specifically since it's a known path
            extraction_log = oc.log_dir / "extraction.log"
            if extraction_log.is_file() and not any(
                name == "file:extraction.log" for name, _ in aggregator._sources
            ):
                aggregator.add_file("file:extraction.log", extraction_log)

        # Tail systemd journal for the OpenClaw service
        if oc.service_name and self.config.platform.init_system == "systemd":
            aggregator.add_journal(f"journal:{oc.service_name}", oc.service_name)
            log.info("Tailing journal for: %s", oc.service_name)

        return aggregator

    async def _heartbeat_loop(self, alert_pipeline=None, ledger=None) -> None:
        """Periodic heartbeat log + state file update."""
        interval = self.config.settings.get("heartbeat_interval", 30)
        tick = 0
        while not self._shutdown_event.is_set():
            tick += 1
            oc = self.config.openclaw
            oc_status = "detected" if oc else "not found"
            if oc and oc.pid:
                oc_status = f"running (PID {oc.pid})"

            extra = {}
            if alert_pipeline:
                recent = alert_pipeline.recent_alerts
                extra["recent_alerts"] = len(recent)
                if recent:
                    last = recent[-1]
                    extra["last_alert"] = {
                        "type": last.event_type,
                        "severity": last.severity,
                        "time": last.timestamp,
                    }
            if ledger:
                extra["fix_stats"] = ledger.get_stats()

            fixes = extra.get("fix_stats", {})
            log.info(
                "heartbeat #%d | uptime=%.0fs | openclaw=%s | alerts=%d | fixes=%d/%d",
                tick,
                self.uptime,
                oc_status,
                extra.get("recent_alerts", 0),
                fixes.get("success", 0),
                fixes.get("total", 0),
            )
            self._write_state("running", extra)

            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(),
                    timeout=interval,
                )
            except asyncio.TimeoutError:
                pass  # normal — just loop again

    async def run(self) -> None:
        """Main entry point — run the daemon until shutdown is requested."""
        self._start_time = time.monotonic()
        loop = asyncio.get_running_loop()
        self._install_signal_handlers(loop)
        self._write_pidfile()
        self._write_state("starting")

        oc = self.config.openclaw
        log.info("EasyClaw v%s starting", _get_version())
        log.info(
            "Platform: %s%s | init: %s",
            self.config.platform.system,
            " (WSL)" if self.config.platform.is_wsl else "",
            self.config.platform.init_system or "none",
        )
        if oc:
            log.info("OpenClaw found at %s", oc.home_dir)
            if oc.pid:
                log.info("OpenClaw process running — PID %d", oc.pid)
            if oc.service_name:
                log.info("OpenClaw service: %s", oc.service_name)
        else:
            log.warning("OpenClaw installation not found — running in standby mode")

        # ── Phase 5: Hardening (early init — needed by other subsystems) ──
        from easyclaw.capping import ResourceCap
        from easyclaw.dashboard import DashboardServer
        from easyclaw.kpi import KPITracker
        from easyclaw.sandbox import SecuritySandbox

        kpi_tracker = KPITracker()

        resource_cap = ResourceCap(
            nice_value=self.config.settings.get("nice_value", 10),
            max_memory_mb=self.config.settings.get("max_memory_mb", 256),
            max_cpu_percent=self.config.settings.get("max_cpu_percent", 10.0),
        )
        resource_cap.apply_nice()

        sandbox = SecuritySandbox(
            openclaw_home=oc.home_dir if oc else None,
            easyclaw_home=self.config.home_dir,
        )

        dashboard_port = self.config.settings.get("dashboard_port", 18790)
        dashboard = DashboardServer(port=dashboard_port)

        # ── Phase 1: Detection subsystems ─────────────────────────────
        from easyclaw.alerts import AlertPipeline
        from easyclaw.classifier import EventClassifier
        from easyclaw.health import HealthMonitor

        classifier = EventClassifier()
        alert_pipeline = AlertPipeline(
            alert_log_dir=self.config.home_dir / "logs",
            webhook_url=self.config.settings.get("alert_webhook"),
        )
        health_monitor = HealthMonitor(
            check_interval=self.config.settings.get("health_check_interval", 60),
            kpi_tracker=kpi_tracker,
        )

        # Log aggregator — tails OpenClaw's log sources
        aggregator = self._setup_log_sources()

        # ── Phase 2: Self-healing subsystems ──────────────────────────
        from easyclaw.executor import CommandExecutor
        from easyclaw.healer import Healer
        from easyclaw.ledger import CircuitBreaker, FixLedger
        from easyclaw.remediation import RemediationRegistry
        from easyclaw.restart import RestartManager

        user_remediation_file = self.config.home_dir / "remediations.yaml"
        registry = RemediationRegistry(user_file=user_remediation_file)
        executor = CommandExecutor()
        restart_mgr = RestartManager(executor)
        ledger = FixLedger(self.config.state_dir)
        breaker = CircuitBreaker(
            ledger,
            max_attempts=self.config.settings.get("max_restart_attempts", 3),
            window_seconds=self.config.settings.get("restart_window", 600),
        )

        # ── Phase 4: Personal Trainer ─────────────────────────────────
        from easyclaw.context_monitor import ContextMonitor
        from easyclaw.temp_cleaner import TempCleaner
        from easyclaw.dep_auditor import DepAuditor
        from easyclaw.env_validator import EnvValidator
        from easyclaw.resource_monitor import ResourceMonitor

        context_monitor = ContextMonitor(
            check_interval=self.config.settings.get("context_check_interval", 3600),
            state_dir=self.config.state_dir,
        )
        temp_cleaner = TempCleaner(
            cleanup_interval=self.config.settings.get("cleanup_interval", 21600),
            log_retention_days=self.config.settings.get("log_retention_days", 7),
        )
        dep_auditor = DepAuditor(
            audit_interval=self.config.settings.get("audit_interval", 86400),
        )
        env_validator = EnvValidator(
            check_interval=self.config.settings.get("env_check_interval", 43200),
        )
        resource_monitor = ResourceMonitor(
            sample_interval=self.config.settings.get("resource_sample_interval", 60),
            ram_warn_mb=self.config.settings.get("ram_warn_mb", 2048),
            ram_critical_mb=self.config.settings.get("ram_critical_mb", 4096),
        )

        # ── Phase 3: MCP client ──────────────────────────────────────
        from easyclaw.mcp_client import MCPClient
        from easyclaw.updater import UpdateChecker

        mcp_endpoint = self.config.settings.get("mcp_endpoint")
        mcp_token = self.config.settings.get("mcp_token")
        mcp_client = MCPClient(endpoint=mcp_endpoint, token=mcp_token or "")

        if mcp_client.is_configured:
            log.info("MCP client configured: %s", mcp_endpoint)
        else:
            log.info("MCP not configured — running in local-only mode")

        updater = UpdateChecker(
            mcp_client=mcp_client,
            current_version=_get_version(),
            check_interval=self.config.settings.get("update_check_interval", 6 * 3600),
        )

        healer = Healer(
            registry=registry,
            executor=executor,
            restart_mgr=restart_mgr,
            ledger=ledger,
            breaker=breaker,
            alert_pipeline=alert_pipeline,
            openclaw=oc,
            mcp_client=mcp_client,
            sandbox=sandbox,
            kpi_tracker=kpi_tracker,
        )

        # ── Phase 6: Agent Brain (LLM via OpenRouter) ─────────────────
        from easyclaw.agent import AgentBrain

        agent_brain = AgentBrain(
            config=self.config,
            executor=executor,
            restart_mgr=restart_mgr,
            ledger=ledger,
            breaker=breaker,
            alert_pipeline=alert_pipeline,
            openclaw=oc,
            mcp_client=mcp_client,
            sandbox=sandbox,
            kpi_tracker=kpi_tracker,
        )
        agent_brain.set_fallback_healer(healer)

        if agent_brain.is_available:
            log.info("Agent brain enabled (model=%s)", self.config.settings.get("openrouter_model", "glm-4.7-flash"))
        else:
            log.info("Agent brain not available — using rules-based healer only")

        # Wire dashboard context for /status endpoint
        dashboard.set_context(
            config=self.config,
            alert_pipeline=alert_pipeline,
            ledger=ledger,
            breaker=breaker,
            mcp_client=mcp_client,
            kpi_tracker=kpi_tracker,
            start_time=time.time(),
        )

        # Callback: when a log line arrives, classify → alert + agent (or healer)
        def on_log_line(source: str, line: str) -> None:
            health_monitor.notify_log_activity()
            event = classifier.classify(source, line)
            if event is not None:
                alert_pipeline.enqueue(event)
                if agent_brain.is_available:
                    agent_brain.enqueue(event)
                else:
                    healer.enqueue(event)

        # ── Launch all subsystems concurrently ─────────────────────
        tasks = []

        try:
            # Alert pipeline (consumes event queue)
            tasks.append(asyncio.create_task(
                alert_pipeline.run(self._shutdown_event),
                name="alert_pipeline",
            ))

            # Log aggregator (produces log lines → classifier → event queue)
            tasks.append(asyncio.create_task(
                aggregator.stream(self._shutdown_event, on_log_line),
                name="log_aggregator",
            ))

            # Health monitor (periodic process checks → event queue)
            sessions_dir = oc.sessions_dir if oc else None

            def emit_health_event(event):
                alert_pipeline.enqueue(event)
                if agent_brain.is_available:
                    agent_brain.enqueue(event)
                else:
                    healer.enqueue(event)

            tasks.append(asyncio.create_task(
                health_monitor.run(
                    self._shutdown_event,
                    emit_health_event,
                    sessions_dir,
                ),
                name="health_monitor",
            ))

            # Healer (consumes heal queue → executes remediations)
            # Always runs — serves as fallback when agent brain is active
            tasks.append(asyncio.create_task(
                healer.run(self._shutdown_event),
                name="healer",
            ))

            # Agent brain (LLM reasoning loop — Phase 6)
            if agent_brain.is_available:
                tasks.append(asyncio.create_task(
                    agent_brain.run(self._shutdown_event),
                    name="agent_brain",
                ))

            # Update checker (periodic MCP polling for updates/hotfixes)
            tasks.append(asyncio.create_task(
                updater.run(self._shutdown_event),
                name="update_checker",
            ))

            # Phase 4: Personal Trainer subsystems
            def emit_event(event):
                alert_pipeline.enqueue(event)
                if agent_brain.is_available:
                    agent_brain.enqueue(event)
                else:
                    healer.enqueue(event)

            tasks.append(asyncio.create_task(
                context_monitor.run(self._shutdown_event, emit_event, oc),
                name="context_monitor",
            ))

            tasks.append(asyncio.create_task(
                temp_cleaner.run(self._shutdown_event, emit_event, oc, self.config.log_dir),
                name="temp_cleaner",
            ))

            tasks.append(asyncio.create_task(
                dep_auditor.run(self._shutdown_event, emit_event),
                name="dep_auditor",
            ))

            tasks.append(asyncio.create_task(
                env_validator.run(self._shutdown_event, emit_event, self.config),
                name="env_validator",
            ))

            tasks.append(asyncio.create_task(
                resource_monitor.run(self._shutdown_event, emit_event),
                name="resource_monitor",
            ))

            # Phase 5: Hardening subsystems
            tasks.append(asyncio.create_task(
                kpi_tracker.run(self._shutdown_event, self.config.state_dir),
                name="kpi_tracker",
            ))

            tasks.append(asyncio.create_task(
                dashboard.run(self._shutdown_event),
                name="dashboard",
            ))

            tasks.append(asyncio.create_task(
                resource_cap.run(self._shutdown_event),
                name="resource_cap",
            ))

            # Phase 7: Telegram bot
            from easyclaw.telegram import TelegramBridge

            telegram_bridge = TelegramBridge(
                config=self.config,
                agent_brain=agent_brain,
                alert_pipeline=alert_pipeline,
                kpi_tracker=kpi_tracker,
                breaker=breaker,
            )

            if telegram_bridge.is_configured:
                tasks.append(asyncio.create_task(
                    telegram_bridge.run(self._shutdown_event),
                    name="telegram_bot",
                ))
                log.info("Telegram bot enabled")
            else:
                log.info("Telegram bot not configured — skipping")

            # Heartbeat (status logging)
            tasks.append(asyncio.create_task(
                self._heartbeat_loop(alert_pipeline, ledger),
                name="heartbeat",
            ))

            # Wait for any task to complete (usually due to shutdown)
            done, pending = await asyncio.wait(
                tasks,
                return_when=asyncio.FIRST_EXCEPTION,
            )

            # Check for unexpected exceptions
            for task in done:
                if task.exception() and not self._shutdown_event.is_set():
                    log.error(
                        "Subsystem '%s' crashed: %s",
                        task.get_name(),
                        task.exception(),
                    )

        except Exception:
            log.exception("Fatal error in daemon loop")
        finally:
            # Signal all subsystems to stop
            self._shutdown_event.set()
            for task in tasks:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

            self._write_state("stopped")
            self._remove_pidfile()
            log.info("EasyClaw shut down cleanly (uptime=%.0fs)", self.uptime)


def _get_version() -> str:
    try:
        from easyclaw import __version__
        return __version__
    except ImportError:
        return "unknown"


def run_daemon(foreground: bool = True) -> None:
    """Load config and start the daemon.

    Args:
        foreground: If True, run with console logging. If False, log to file only.
    """
    try:
        config = load_config()
    except Exception as exc:
        print(f"[EasyClaw] Failed to load config: {exc}", file=sys.stderr)
        sys.exit(1)

    setup_logging(config.log_dir, console=foreground)
    log_root = get_logger()

    # Top-level failsafe: EasyClaw must never take OpenClaw down
    try:
        daemon = EasyClawDaemon(config)
        asyncio.run(daemon.run())
    except KeyboardInterrupt:
        pass
    except Exception:
        log_root.exception("EasyClaw crashed — exiting cleanly to protect OpenClaw")
        sys.exit(1)
