"""Fix ledger — audit trail of every remediation action taken."""

from __future__ import annotations

import json
import time
from collections import deque
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

from easyclaw.logging import get_logger

log = get_logger("ledger")


@dataclass
class LedgerEntry:
    """A single recorded remediation action."""

    timestamp: float
    error_hash: str
    event_type: str
    pattern_name: str
    severity: str
    action_name: str
    action_type: str
    success: bool
    duration: float                     # seconds the fix took
    commands_run: list[str] = field(default_factory=list)
    output: str = ""                    # truncated stdout/stderr
    error: Optional[str] = None        # failure reason if not success
    restart_performed: bool = False

    def to_json(self) -> str:
        return json.dumps(asdict(self), default=str)


class FixLedger:
    """Persists every action EasyClaw takes for auditing and KPI tracking.

    Writes to a JSONL file and keeps a ring buffer in memory for quick access.
    """

    def __init__(self, ledger_dir: Path, max_memory: int = 200):
        self.ledger_dir = ledger_dir
        self.ledger_dir.mkdir(parents=True, exist_ok=True)
        self._file = self.ledger_dir / "fix-ledger.jsonl"
        self._recent: deque[LedgerEntry] = deque(maxlen=max_memory)

    def record(self, entry: LedgerEntry) -> None:
        """Write an entry to the ledger file and memory buffer."""
        self._recent.append(entry)
        try:
            with open(self._file, "a") as f:
                f.write(entry.to_json() + "\n")
        except OSError as e:
            log.error("Failed to write ledger: %s", e)

        status = "OK" if entry.success else "FAILED"
        log.info(
            "Ledger: [%s] %s via %s (%.1fs) | error_hash=%s",
            status,
            entry.event_type,
            entry.action_name,
            entry.duration,
            entry.error_hash,
        )

    @property
    def recent_entries(self) -> list[LedgerEntry]:
        return list(self._recent)

    def count_restarts_in_window(self, window_seconds: float) -> int:
        """Count how many restarts occurred in the last N seconds."""
        cutoff = time.time() - window_seconds
        return sum(
            1 for e in self._recent
            if e.restart_performed and e.timestamp > cutoff
        )

    def get_stats(self) -> dict:
        """Return summary stats from the in-memory buffer."""
        if not self._recent:
            return {"total": 0, "success": 0, "failed": 0, "restarts": 0}

        total = len(self._recent)
        success = sum(1 for e in self._recent if e.success)
        restarts = sum(1 for e in self._recent if e.restart_performed)
        return {
            "total": total,
            "success": success,
            "failed": total - success,
            "restarts": restarts,
        }


class CircuitBreaker:
    """Prevents restart loops by tracking restart frequency.

    If OpenClaw has been restarted `max_attempts` times within
    `window_seconds`, the breaker trips and blocks further restarts
    until the window expires.
    """

    def __init__(
        self,
        ledger: FixLedger,
        max_attempts: int = 3,
        window_seconds: float = 600.0,     # 10 minutes
    ):
        self.ledger = ledger
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self._tripped = False
        self._trip_time: float = 0.0

    @property
    def is_tripped(self) -> bool:
        """Check if the breaker is currently tripped."""
        if self._tripped:
            # Auto-reset after window expires
            if time.time() - self._trip_time > self.window_seconds:
                log.info("Circuit breaker reset — window expired")
                self._tripped = False
                return False
            return True
        return False

    def check_and_trip(self) -> bool:
        """Check if we should trip the breaker. Returns True if tripped (restart blocked).

        Call this BEFORE performing a restart.
        """
        if self.is_tripped:
            return True

        count = self.ledger.count_restarts_in_window(self.window_seconds)
        if count >= self.max_attempts:
            self._tripped = True
            self._trip_time = time.time()
            log.critical(
                "Circuit breaker TRIPPED — %d restarts in %.0fs (max %d). "
                "Blocking further auto-restarts. Manual intervention required.",
                count,
                self.window_seconds,
                self.max_attempts,
            )
            return True

        return False
