"""Healer orchestrator — connects classified events to remediation actions."""

from __future__ import annotations

import asyncio
import time
from typing import Optional

from easyclaw.alerts import AlertPipeline
from easyclaw.classifier import Event, Severity
from easyclaw.discovery import OpenClawInstance
from easyclaw.executor import CommandExecutor
from easyclaw.ledger import CircuitBreaker, FixLedger, LedgerEntry
from easyclaw.logging import get_logger
from easyclaw.mcp_client import MCPClient, MCPKnowledgeCache
from easyclaw.remediation import FixAction, RemediationEntry, RemediationRegistry
from easyclaw.restart import RestartManager

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from easyclaw.kpi import KPITracker
    from easyclaw.sandbox import SecuritySandbox

log = get_logger("healer")


class Healer:
    """Orchestrates the self-healing pipeline.

    Flow:
    1. Receives events from the alert pipeline's queue
    2. Looks up remediation in the local registry
    3. If no local match, queries MCP server for known issues
    4. Checks circuit breaker
    5. Executes fix actions (commands or restart)
    6. Records outcome in the fix ledger
    7. Reports incident to MCP for central tracking
    8. Escalates to user if all actions fail
    """

    def __init__(
        self,
        registry: RemediationRegistry,
        executor: CommandExecutor,
        restart_mgr: RestartManager,
        ledger: FixLedger,
        breaker: CircuitBreaker,
        alert_pipeline: AlertPipeline,
        openclaw: Optional[OpenClawInstance] = None,
        mcp_client: Optional[MCPClient] = None,
        sandbox: Optional["SecuritySandbox"] = None,
        kpi_tracker: Optional["KPITracker"] = None,
    ):
        self.registry = registry
        self.executor = executor
        self.restart_mgr = restart_mgr
        self.ledger = ledger
        self.breaker = breaker
        self.alert_pipeline = alert_pipeline
        self.openclaw = openclaw
        self.mcp = mcp_client
        self.sandbox = sandbox
        self.kpi = kpi_tracker
        self._mcp_cache = MCPKnowledgeCache(ttl_seconds=3600)

        self._heal_queue: asyncio.Queue[Event] = asyncio.Queue()

    def enqueue(self, event: Event) -> None:
        """Submit an event for potential remediation."""
        # Only heal WARNING and CRITICAL events
        if event.severity in (Severity.WARNING, Severity.CRITICAL):
            try:
                self._heal_queue.put_nowait(event)
            except asyncio.QueueFull:
                log.warning("Heal queue full — dropping event: %s", event.event_type.value)

    async def run(self, shutdown: asyncio.Event) -> None:
        """Process heal queue until shutdown."""
        log.info("Healer started")

        while not shutdown.is_set():
            try:
                event = await asyncio.wait_for(self._heal_queue.get(), timeout=5.0)
            except asyncio.TimeoutError:
                continue

            try:
                await self._handle_event(event)
            except Exception:
                log.exception("Healer failed processing event: %s", event.event_type.value)

        log.info("Healer stopped")

    async def _handle_event(self, event: Event) -> None:
        """Look up and execute remediation for an event."""
        entry = self.registry.lookup(event.pattern_name, event.event_type.value)

        # If no local match, query MCP for known issues
        if entry is None and self.mcp and self.mcp.is_configured:
            entry = await self._query_mcp_for_fix(event)

        if entry is None:
            log.debug("No remediation found for: %s / %s", event.pattern_name, event.event_type.value)
            # Still report to MCP for tracking
            await self._report_to_mcp(event, auto_fixed=False)
            return

        log.info(
            "Remediating: %s — %s (%d actions)",
            event.event_type.value,
            entry.description,
            len(entry.actions),
        )

        all_failed = True

        for action in entry.actions:
            success = await self._execute_action(event, action)
            if success:
                all_failed = False
                break  # First successful action is enough

        # Report outcome to MCP
        await self._report_to_mcp(event, auto_fixed=not all_failed)

        if all_failed and entry.escalate_on_failure:
            log.error(
                "All remediation actions failed for %s — escalating to user",
                event.event_type.value,
            )
            escalation = Event(
                event_type=event.event_type,
                severity=Severity.CRITICAL,
                source="healer",
                line=f"Auto-remediation failed for {event.event_type.value}: {event.line[:200]}",
                pattern_name=f"escalation_{event.pattern_name}",
            )
            self.alert_pipeline.enqueue(escalation)

    async def _query_mcp_for_fix(self, event: Event) -> Optional[RemediationEntry]:
        """Query the MCP server for a known fix when local registry has no match."""
        cache_key = f"issue:{event.pattern_name}"
        cached = self._mcp_cache.get(cache_key)
        if cached is not None:
            if not cached.get("matched"):
                return None
            return await self._diagnose_response_to_entry(event, cached)

        log.info("Querying MCP for diagnosis: %s", event.line[:80])
        context = "\n".join(event.context_lines[-3:])
        response = await self.mcp.diagnose_issue(event.line[:200], context)

        if not response.success:
            log.debug("MCP diagnose_issue failed: %s", response.error)
            return None

        self._mcp_cache.put(cache_key, response.data)

        if not response.data.get("matched"):
            return None

        return await self._diagnose_response_to_entry(event, response.data)

    async def _diagnose_response_to_entry(self, event: Event, data: dict) -> Optional[RemediationEntry]:
        """Convert an MCP diagnose_issue response into a RemediationEntry.

        The v2 diagnose_issue tool returns patterns with fix_steps (string
        instructions).  We extract executable commands from those steps first,
        then fall back to fetching a full guide and parsing markdown code blocks.
        """
        patterns = data.get("patterns", [])
        if not patterns:
            return None

        pattern = patterns[0]
        fix_steps = pattern.get("fix_steps", [])

        # Try to extract shell commands from fix_steps strings
        commands = self._extract_commands_from_steps(fix_steps)

        # Fallback: fetch a related guide and extract bash blocks
        if not commands:
            guides = data.get("related_guides", [])
            if guides and self.mcp and self.mcp.is_configured:
                slug = guides[0].get("slug", "")
                if slug:
                    log.info("Fetching full guide for additional fix commands: %s", slug)
                    guide_resp = await self.mcp.get_full_guide(slug)
                    if guide_resp.success:
                        content = guide_resp.data.get("content", "")
                        commands = self._extract_commands_from_markdown(content)

        if not commands:
            log.info("MCP returned diagnosis but no executable commands")
            return None

        pattern_id = pattern.get("id", pattern.get("name", "unknown"))
        log.info("MCP provided %d fix commands for: %s", len(commands), event.pattern_name)

        entry = RemediationEntry(
            pattern_name=event.pattern_name,
            event_type=event.event_type.value,
            description=f"MCP fix: {pattern_id}",
            actions=[
                FixAction(
                    name=f"mcp_fix_{pattern_id}",
                    description="Fix from MCP knowledge base",
                    action_type="command",
                    commands=commands[:5],  # Cap at 5 commands for safety
                    timeout=30,
                ),
            ],
            escalate_on_failure=True,
        )

        # Register locally in registry for future reuse
        self.registry._register(entry)
        log.info("Cached MCP remediation locally: %s", event.pattern_name)

        return entry

    def _extract_commands_from_steps(self, fix_steps: list[str]) -> list[str]:
        """Extract executable shell commands from fix_steps strings.

        fix_steps are human-readable instructions like:
          "Run: sudo systemctl restart openclaw-gateway"
          "Delete stale lock files with: find ~/.openclaw -name '*.lock' -delete"
        We look for lines that start with common shell commands or contain
        pipes/redirects, which indicate executable commands.
        """
        import re

        command_prefixes = (
            "rm", "find", "kill", "killall", "pkill",
            "systemctl", "service", "sudo",
            "curl", "wget", "chmod", "chown",
            "mv", "cp", "mkdir", "ln",
            "npm", "node", "pip", "python",
            "docker", "journalctl", "cat", "grep",
        )
        pipe_redirect_re = re.compile(r"[|><]")

        commands: list[str] = []
        for step in fix_steps:
            step = step.strip()
            if not step:
                continue
            # Strip leading instruction text like "Run: " or "Execute: "
            for prefix in ("Run:", "Execute:", "Run ", "Execute "):
                if step.startswith(prefix):
                    step = step[len(prefix):].strip()
                    break
            # Check if it looks like a shell command
            first_word = step.split()[0] if step.split() else ""
            if first_word in command_prefixes or pipe_redirect_re.search(step):
                commands.append(step)
        return commands[:5]

    def _extract_commands_from_markdown(self, text: str) -> list[str]:
        """Extract shell commands from markdown ```bash code blocks."""
        import re

        commands: list[str] = []
        for block in re.findall(r"```(?:bash|sh)?\n(.*?)```", text, re.DOTALL):
            for line in block.strip().splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    commands.append(line)
        return commands[:5]

    async def _report_to_mcp(self, event: Event, auto_fixed: bool) -> None:
        """Report an incident to the MCP for central tracking. Best-effort, non-blocking."""
        if not self.mcp or not self.mcp.is_configured:
            return

        try:
            await self.mcp.report_incident(
                error_type=event.event_type.value,
                error_hash=event.error_hash,
                severity=event.severity.value,
                details=f"{event.line[:500]}\n\nContext:\n" + "\n".join(event.context_lines[-3:]),
                auto_fixed=auto_fixed,
            )
        except Exception:
            log.debug("Failed to report incident to MCP (non-critical)")

    async def _execute_action(self, event: Event, action: FixAction) -> bool:
        """Execute a single FixAction and record the result."""
        start_time = time.time()
        success = False
        output = ""
        error = None
        commands_run: list[str] = []
        restart_performed = False

        # ── Sandbox: validate commands before execution ────────
        if self.sandbox and action.commands:
            for cmd in action.commands:
                allowed, reason = self.sandbox.validate_command(cmd)
                if not allowed:
                    log.warning("Sandbox blocked command: %s — %s", cmd, reason)
                    error = f"Sandbox blocked: {reason}"
                    duration = time.time() - start_time
                    self.ledger.record(LedgerEntry(
                        timestamp=time.time(),
                        error_hash=event.error_hash,
                        event_type=event.event_type.value,
                        pattern_name=event.pattern_name,
                        severity=event.severity.value,
                        action_name=action.name,
                        action_type=action.action_type,
                        success=False,
                        duration=duration,
                        commands_run=[],
                        output="",
                        error=error,
                        restart_performed=False,
                    ))
                    if self.kpi:
                        self.kpi.record_fix(duration, False)
                    return False

        for attempt in range(max(action.max_retries, 1)):
            if attempt > 0:
                log.info(
                    "Retry %d/%d for %s (waiting %ds)",
                    attempt + 1, action.max_retries, action.name, action.retry_after,
                )
                await asyncio.sleep(action.retry_after)

            # ── Handle restart actions ─────────────────────────────
            if action.requires_restart:
                if self.breaker.check_and_trip():
                    error = "Circuit breaker tripped — restart blocked"
                    log.warning(error)
                    break

                if self.openclaw is None:
                    error = "No OpenClaw instance to restart"
                    log.error(error)
                    break

                # Run any pre-restart commands first
                if action.commands:
                    results = await self.executor.execute_sequence(
                        action.commands,
                        timeout=action.timeout,
                        stop_on_failure=False,  # pre-restart commands are best-effort
                    )
                    commands_run.extend(r.command for r in results)
                    output = "\n".join(r.stdout for r in results if r.stdout)

                log.info("Performing restart: %s", action.description)
                restart_result = await self.restart_mgr.restart(self.openclaw)
                restart_performed = True
                success = restart_result.success
                if not success:
                    error = restart_result.error or "Restart failed"
                else:
                    output += f"\nRestart completed in {restart_result.duration:.1f}s"

            # ── Handle command actions ─────────────────────────────
            elif action.commands:
                results = await self.executor.execute_sequence(
                    action.commands,
                    timeout=action.timeout,
                    stop_on_failure=True,
                )
                commands_run.extend(r.command for r in results)
                output = "\n".join(
                    f"[rc={r.return_code}] {r.stdout}" for r in results if r.stdout
                )

                # Success if all commands returned 0
                success = all(r.return_code == 0 and not r.timed_out for r in results)
                if not success:
                    failed = next((r for r in results if r.return_code != 0), None)
                    error = failed.stderr[:200] if failed else "Command failed"

            else:
                # No-op action (e.g., log_only)
                success = True

            if success:
                break

        duration = time.time() - start_time

        # Record to ledger
        self.ledger.record(LedgerEntry(
            timestamp=time.time(),
            error_hash=event.error_hash,
            event_type=event.event_type.value,
            pattern_name=event.pattern_name,
            severity=event.severity.value,
            action_name=action.name,
            action_type=action.action_type,
            success=success,
            duration=duration,
            commands_run=commands_run,
            output=output[:500],
            error=error,
            restart_performed=restart_performed,
        ))

        # Record to KPI tracker
        if self.kpi:
            self.kpi.record_fix(duration, success)

        return success
