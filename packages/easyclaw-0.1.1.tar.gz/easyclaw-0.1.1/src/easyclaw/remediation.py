"""Remediation registry — maps error signatures to fix actions."""

from __future__ import annotations

import yaml
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from easyclaw.logging import get_logger

log = get_logger("remediation")


@dataclass
class FixAction:
    """A single remediation action to execute."""

    name: str
    description: str
    action_type: str            # "command", "restart", "clear_cache", "kill_stale_locks"
    commands: list[str] = field(default_factory=list)  # shell commands to run
    timeout: int = 30           # seconds per command
    retry_after: int = 0        # seconds to wait before retry
    max_retries: int = 1
    requires_restart: bool = False


@dataclass
class RemediationEntry:
    """Maps an error pattern to one or more fix actions."""

    pattern_name: str           # matches classifier Rule.name
    event_type: str             # matches EventType.value
    description: str
    actions: list[FixAction] = field(default_factory=list)
    escalate_on_failure: bool = True  # alert user if all actions fail


# Built-in remediations for known OpenClaw failure modes
BUILTIN_REMEDIATIONS: list[RemediationEntry] = [
    RemediationEntry(
        pattern_name="connection_refused",
        event_type="connection_refused",
        description="Upstream service connection refused — retry after delay",
        actions=[
            FixAction(
                name="wait_and_check",
                description="Wait 30s for transient network issue to resolve",
                action_type="command",
                commands=["sleep 5"],
                retry_after=30,
                max_retries=2,
            ),
        ],
        escalate_on_failure=True,
    ),
    RemediationEntry(
        pattern_name="node_fatal",
        event_type="node_error",
        description="Node.js fatal error (heap OOM, uncaught exception) — restart OpenClaw",
        actions=[
            FixAction(
                name="restart_openclaw",
                description="Gracefully restart the OpenClaw gateway",
                action_type="restart",
                requires_restart=True,
            ),
        ],
    ),
    RemediationEntry(
        pattern_name="oom_killed",
        event_type="process_oom",
        description="Out of memory — clear caches and restart",
        actions=[
            FixAction(
                name="clear_bm25_cache",
                description="Remove stale BM25 index cache to free memory",
                action_type="clear_cache",
                commands=[
                    "find ~/.openclaw/workspace/memory/ -name '*.cache' -delete 2>/dev/null || true",
                ],
                timeout=10,
            ),
            FixAction(
                name="restart_openclaw",
                description="Restart OpenClaw after clearing cache",
                action_type="restart",
                requires_restart=True,
            ),
        ],
    ),
    RemediationEntry(
        pattern_name="session_locked",
        event_type="session_locked",
        description="Stale session lock file — remove lock and retry",
        actions=[
            FixAction(
                name="kill_stale_locks",
                description="Remove .lock files from sessions directory",
                action_type="kill_stale_locks",
                commands=[
                    "find ~/.openclaw/agents/main/sessions/ -name '*.lock' -mmin +5 -delete 2>/dev/null || true",
                ],
                timeout=10,
            ),
        ],
        escalate_on_failure=True,
    ),
    RemediationEntry(
        pattern_name="python_traceback",
        event_type="python_traceback",
        description="Python traceback in OpenClaw subsystem — log and monitor",
        actions=[
            FixAction(
                name="log_only",
                description="Log the traceback for analysis — no automatic action",
                action_type="command",
                commands=["true"],  # no-op, just record it
                timeout=5,
            ),
        ],
        escalate_on_failure=False,
    ),
    RemediationEntry(
        pattern_name="segfault",
        event_type="process_crash",
        description="Process crash (segfault/abort) — restart OpenClaw",
        actions=[
            FixAction(
                name="restart_openclaw",
                description="Restart OpenClaw after crash",
                action_type="restart",
                requires_restart=True,
            ),
        ],
    ),
    RemediationEntry(
        pattern_name="dns_failure",
        event_type="dns_failure",
        description="DNS resolution failure — restore resolv.conf and retry",
        actions=[
            FixAction(
                name="check_dns",
                description="Verify DNS resolution is working",
                action_type="command",
                commands=[
                    "nslookup google.com 8.8.8.8 >/dev/null 2>&1",
                ],
                timeout=10,
                retry_after=15,
                max_retries=2,
            ),
        ],
        escalate_on_failure=True,
    ),
    RemediationEntry(
        pattern_name="compaction_fail",
        event_type="compaction_failure",
        description="Session compaction failure — may lead to token overflow",
        actions=[
            FixAction(
                name="restart_openclaw",
                description="Restart OpenClaw to reset compaction state",
                action_type="restart",
                requires_restart=True,
            ),
        ],
    ),
    RemediationEntry(
        pattern_name="stalled_process",
        event_type="process_stalled",
        description="OpenClaw appears stalled — no log output for extended period",
        actions=[
            FixAction(
                name="restart_openclaw",
                description="Restart the stalled OpenClaw process",
                action_type="restart",
                requires_restart=True,
            ),
        ],
    ),
    RemediationEntry(
        pattern_name="process_disappeared",
        event_type="process_crash",
        description="OpenClaw process disappeared — restart it",
        actions=[
            FixAction(
                name="restart_openclaw",
                description="Start the OpenClaw gateway service",
                action_type="restart",
                requires_restart=True,
            ),
        ],
    ),
    RemediationEntry(
        pattern_name="session_bloat",
        event_type="session_bloat",
        description="Session directory is bloated — clean up deleted and stale files",
        actions=[
            FixAction(
                name="clean_deleted_sessions",
                description="Remove soft-deleted session files",
                action_type="command",
                commands=[
                    "find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' -delete 2>/dev/null || true",
                    "find ~/.openclaw/agents/main/sessions/ -name '*.lock' -mmin +30 -delete 2>/dev/null || true",
                ],
                timeout=15,
            ),
        ],
        escalate_on_failure=False,
    ),
]


class RemediationRegistry:
    """Lookup remediation entries by pattern name or event type.

    Loads built-in remediations and optionally merges user-defined ones from a YAML file.
    """

    def __init__(self, user_file: Optional[Path] = None):
        self._by_pattern: dict[str, RemediationEntry] = {}
        self._by_event_type: dict[str, RemediationEntry] = {}

        # Load builtins
        for entry in BUILTIN_REMEDIATIONS:
            self._register(entry)

        # Merge user overrides
        if user_file and user_file.is_file():
            self._load_user_file(user_file)

    def _register(self, entry: RemediationEntry) -> None:
        self._by_pattern[entry.pattern_name] = entry
        self._by_event_type[entry.event_type] = entry

    def lookup(self, pattern_name: str, event_type: str) -> Optional[RemediationEntry]:
        """Find a remediation entry. Pattern name takes priority over event type."""
        return self._by_pattern.get(pattern_name) or self._by_event_type.get(event_type)

    def _load_user_file(self, path: Path) -> None:
        """Load user-defined remediations from YAML, merging with builtins."""
        try:
            with open(path, "r") as f:
                data = yaml.safe_load(f)
            if not isinstance(data, dict) or "remediations" not in data:
                return

            for item in data["remediations"]:
                actions = []
                for act in item.get("actions", []):
                    actions.append(FixAction(
                        name=act.get("name", "custom"),
                        description=act.get("description", ""),
                        action_type=act.get("action_type", "command"),
                        commands=act.get("commands", []),
                        timeout=act.get("timeout", 30),
                        retry_after=act.get("retry_after", 0),
                        max_retries=act.get("max_retries", 1),
                        requires_restart=act.get("requires_restart", False),
                    ))

                entry = RemediationEntry(
                    pattern_name=item["pattern_name"],
                    event_type=item.get("event_type", ""),
                    description=item.get("description", ""),
                    actions=actions,
                    escalate_on_failure=item.get("escalate_on_failure", True),
                )
                self._register(entry)
                log.info("Loaded user remediation: %s", entry.pattern_name)

        except Exception:
            log.exception("Failed to load user remediations from %s", path)
