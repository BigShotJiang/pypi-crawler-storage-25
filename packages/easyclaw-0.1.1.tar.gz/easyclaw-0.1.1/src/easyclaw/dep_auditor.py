"""Dependency auditor — checks that required packages and binaries are present."""

from __future__ import annotations

import asyncio
import shutil
from typing import Optional

from easyclaw.classifier import Event, EventType, Severity
from easyclaw.logging import get_logger

log = get_logger("dep_auditor")

# Required Python packages: (name, min_version)
REQUIRED_DEPS = [
    ("psutil", "5.9"),
    ("pyyaml", "6.0"),
    ("aiofiles", "24.1"),
]

# Mapping of PyPI names to importlib.metadata names (when they differ)
PACKAGE_NAMES = {
    "pyyaml": "PyYAML",
}


def _parse_version(version_str: str) -> tuple[int, ...]:
    """Parse a version string into a comparable tuple of ints.

    Handles versions like '5.9.8', '6.0', '24.1.0'.
    Non-numeric parts are ignored (e.g., '5.9.8.post1' -> (5, 9, 8)).
    """
    parts = []
    for part in version_str.split("."):
        # Strip non-numeric suffixes
        digits = ""
        for ch in part:
            if ch.isdigit():
                digits += ch
            else:
                break
        if digits:
            parts.append(int(digits))
    return tuple(parts)


def _version_gte(installed: str, minimum: str) -> bool:
    """Check if installed version >= minimum version."""
    return _parse_version(installed) >= _parse_version(minimum)


class DepAuditor:
    """Audits that EasyClaw's required dependencies are installed and sufficient.

    Checks:
    - Python packages (psutil, pyyaml, aiofiles) exist and meet minimum versions
    - OpenClaw binary exists and is executable
    """

    def __init__(self, audit_interval: float = 86400.0):
        self.audit_interval = audit_interval

    def audit_now(self) -> list[dict]:
        """Run a synchronous dependency audit. Returns list of check results.

        Each result is a dict with:
            name: str — dependency name
            status: str — "ok", "missing", "outdated", "error"
            detail: str — human-readable detail
        """
        results = []

        # ── Check Python packages ─────────────────────────────────────
        for pkg_name, min_version in REQUIRED_DEPS:
            result = self._check_python_package(pkg_name, min_version)
            results.append(result)

        # ── Check OpenClaw binary ─────────────────────────────────────
        results.append(self._check_openclaw_binary())

        return results

    def _check_python_package(self, pkg_name: str, min_version: str) -> dict:
        """Check a single Python package."""
        import importlib.metadata

        # Use the correct metadata name (e.g., pyyaml -> PyYAML)
        metadata_name = PACKAGE_NAMES.get(pkg_name, pkg_name)

        try:
            installed_version = importlib.metadata.version(metadata_name)
        except importlib.metadata.PackageNotFoundError:
            return {
                "name": pkg_name,
                "status": "missing",
                "detail": f"{pkg_name} is not installed (need >={min_version})",
            }
        except Exception as e:
            return {
                "name": pkg_name,
                "status": "error",
                "detail": f"Failed to check {pkg_name}: {e}",
            }

        if _version_gte(installed_version, min_version):
            return {
                "name": pkg_name,
                "status": "ok",
                "detail": f"{pkg_name}=={installed_version} (need >={min_version})",
            }
        else:
            return {
                "name": pkg_name,
                "status": "outdated",
                "detail": f"{pkg_name}=={installed_version} is below minimum {min_version}",
            }

    def _check_openclaw_binary(self) -> dict:
        """Check that the openclaw binary is available."""
        binary = shutil.which("openclaw")
        if binary is not None:
            return {
                "name": "openclaw",
                "status": "ok",
                "detail": f"Found at {binary}",
            }
        else:
            return {
                "name": "openclaw",
                "status": "missing",
                "detail": "openclaw binary not found in PATH",
            }

    async def run(
        self,
        shutdown: asyncio.Event,
        emit_event,
    ) -> None:
        """Periodic dependency audit loop.

        Args:
            shutdown: asyncio.Event to signal stop.
            emit_event: callable(Event) to push detected events.
        """
        log.info("Dependency auditor started (interval=%ds)", self.audit_interval)

        while not shutdown.is_set():
            try:
                await self._audit_cycle(emit_event)
            except Exception:
                log.exception("Dependency audit cycle failed")

            try:
                await asyncio.wait_for(shutdown.wait(), timeout=self.audit_interval)
            except asyncio.TimeoutError:
                pass

        log.info("Dependency auditor stopped")

    async def _audit_cycle(self, emit_event) -> None:
        """Run one audit cycle."""
        loop = asyncio.get_running_loop()
        results = await loop.run_in_executor(None, self.audit_now)

        for result in results:
            if result["status"] == "ok":
                log.debug("Dep check OK: %s — %s", result["name"], result["detail"])
            elif result["status"] == "missing":
                log.warning("Dep MISSING: %s — %s", result["name"], result["detail"])
                emit_event(Event(
                    event_type=EventType.GENERIC_ERROR,
                    severity=Severity.WARNING,
                    source="dep_auditor",
                    line=result["detail"],
                    pattern_name="dep_missing",
                ))
            elif result["status"] == "outdated":
                log.warning("Dep OUTDATED: %s — %s", result["name"], result["detail"])
                emit_event(Event(
                    event_type=EventType.GENERIC_ERROR,
                    severity=Severity.WARNING,
                    source="dep_auditor",
                    line=result["detail"],
                    pattern_name="dep_outdated",
                ))
            elif result["status"] == "error":
                log.warning("Dep ERROR: %s — %s", result["name"], result["detail"])
                emit_event(Event(
                    event_type=EventType.GENERIC_ERROR,
                    severity=Severity.WARNING,
                    source="dep_auditor",
                    line=result["detail"],
                    pattern_name="dep_check_error",
                ))
