"""Environment validator — checks external service connectivity and API key health."""

from __future__ import annotations

import asyncio
import socket
import re
from typing import Optional
from urllib.request import Request, urlopen
from urllib.error import URLError

from easyclaw.classifier import Event, EventType, Severity
from easyclaw.logging import get_logger

log = get_logger("env_validator")

# API key endpoints: env_var_name -> (host, port, is_primary)
# "primary" keys trigger CRITICAL if unreachable (vs WARNING for others)
API_KEY_ENDPOINTS = {
    "ANTHROPIC_API_KEY": ("api.anthropic.com", 443, True),
    "OPENAI_API_KEY": ("api.openai.com", 443, False),
    "OPENROUTER_API_KEY": ("openrouter.ai", 443, False),
}

# Pattern for placeholder API keys that aren't real
PLACEHOLDER_PATTERN = re.compile(r"^sk-xxx|^sk-\.{3}|^your[_-]|^CHANGE[_-]ME|^placeholder", re.IGNORECASE)


def _tcp_connect(host: str, port: int, timeout: float = 5.0) -> bool:
    """Attempt a TCP socket connect. Returns True if successful."""
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        sock.close()
        return True
    except (socket.timeout, socket.error, OSError):
        return False


def _http_get_ok(url: str, timeout: float = 5.0) -> bool:
    """Attempt an HTTP GET and return True if status is 2xx."""
    try:
        req = Request(url, method="GET")
        resp = urlopen(req, timeout=timeout)
        return 200 <= resp.status < 300
    except (URLError, OSError, ValueError):
        return False


class EnvValidator:
    """Validates external service connectivity and API key health.

    Checks:
    - API key endpoints are reachable (TCP connect)
    - API keys are non-empty and not placeholders
    - MCP endpoint health (if configured)
    - Gateway port is listening (if OpenClaw detected)
    """

    def __init__(self, check_interval: float = 43200.0):
        self.check_interval = check_interval

    def validate_now(self, config) -> list[dict]:
        """Run a synchronous validation. Returns list of check results.

        Each result is a dict with:
            check: str — what was checked
            status: str — "ok", "warning", "critical", "skipped"
            detail: str — human-readable detail

        Args:
            config: EasyClawConfig instance.
        """
        results = []

        openclaw_env = getattr(config, "openclaw_env", {}) or {}

        # ── Check known API key endpoints ─────────────────────────────
        for env_var, (host, port, is_primary) in API_KEY_ENDPOINTS.items():
            key_value = openclaw_env.get(env_var, "")

            if not key_value:
                results.append({
                    "check": env_var,
                    "status": "skipped",
                    "detail": f"{env_var} not set — skipping",
                })
                continue

            # Check for placeholder values
            if PLACEHOLDER_PATTERN.match(key_value):
                results.append({
                    "check": env_var,
                    "status": "warning",
                    "detail": f"{env_var} appears to be a placeholder value",
                })
                continue

            # TCP connect to the API endpoint
            reachable = _tcp_connect(host, port)
            if reachable:
                results.append({
                    "check": env_var,
                    "status": "ok",
                    "detail": f"{host}:{port} reachable",
                })
            else:
                status = "critical" if is_primary else "warning"
                results.append({
                    "check": env_var,
                    "status": status,
                    "detail": f"Cannot reach {host}:{port}",
                })

        # ── Check other *_API_KEY / *_TOKEN env vars ──────────────────
        for key, value in openclaw_env.items():
            if key in API_KEY_ENDPOINTS:
                continue  # Already checked above

            if key.endswith("_API_KEY") or key.endswith("_TOKEN"):
                if not value:
                    results.append({
                        "check": key,
                        "status": "warning",
                        "detail": f"{key} is empty",
                    })
                elif PLACEHOLDER_PATTERN.match(value):
                    results.append({
                        "check": key,
                        "status": "warning",
                        "detail": f"{key} appears to be a placeholder value",
                    })
                else:
                    results.append({
                        "check": key,
                        "status": "ok",
                        "detail": f"{key} is set ({len(value)} chars)",
                    })

        # ── Check MCP endpoint ────────────────────────────────────────
        settings = getattr(config, "settings", {}) or {}
        mcp_endpoint = settings.get("mcp_endpoint")
        if mcp_endpoint:
            health_url = mcp_endpoint.rstrip("/") + "/health"
            ok = _http_get_ok(health_url)
            if ok:
                results.append({
                    "check": "mcp_endpoint",
                    "status": "ok",
                    "detail": f"MCP server healthy at {mcp_endpoint}",
                })
            else:
                results.append({
                    "check": "mcp_endpoint",
                    "status": "warning",
                    "detail": f"MCP server unreachable at {health_url}",
                })
        else:
            results.append({
                "check": "mcp_endpoint",
                "status": "skipped",
                "detail": "MCP endpoint not configured",
            })

        # ── Check gateway port ────────────────────────────────────────
        openclaw = getattr(config, "openclaw", None)
        if openclaw and openclaw.pid:
            gateway_port = getattr(openclaw, "gateway_port", None) or settings.get("gateway_port", 18789)
            reachable = _tcp_connect("127.0.0.1", gateway_port, timeout=3.0)
            if reachable:
                results.append({
                    "check": "gateway_port",
                    "status": "ok",
                    "detail": f"Gateway listening on port {gateway_port}",
                })
            else:
                results.append({
                    "check": "gateway_port",
                    "status": "warning",
                    "detail": f"Gateway port {gateway_port} not responding",
                })
        else:
            results.append({
                "check": "gateway_port",
                "status": "skipped",
                "detail": "OpenClaw not running — gateway check skipped",
            })

        return results

    async def run(
        self,
        shutdown: asyncio.Event,
        emit_event,
        config,
    ) -> None:
        """Periodic environment validation loop.

        Args:
            shutdown: asyncio.Event to signal stop.
            emit_event: callable(Event) to push detected events.
            config: EasyClawConfig instance.
        """
        log.info("Environment validator started (interval=%ds)", self.check_interval)

        while not shutdown.is_set():
            try:
                await self._validate_cycle(emit_event, config)
            except Exception:
                log.exception("Environment validation cycle failed")

            try:
                await asyncio.wait_for(shutdown.wait(), timeout=self.check_interval)
            except asyncio.TimeoutError:
                pass

        log.info("Environment validator stopped")

    async def _validate_cycle(self, emit_event, config) -> None:
        """Run one validation cycle."""
        loop = asyncio.get_running_loop()
        results = await loop.run_in_executor(None, self.validate_now, config)

        for result in results:
            status = result["status"]
            check = result["check"]
            detail = result["detail"]

            if status == "ok":
                log.debug("Env check OK: %s — %s", check, detail)
            elif status == "skipped":
                log.debug("Env check SKIPPED: %s — %s", check, detail)
            elif status == "critical":
                log.error("Env check CRITICAL: %s — %s", check, detail)
                emit_event(Event(
                    event_type=EventType.GENERIC_ERROR,
                    severity=Severity.CRITICAL,
                    source="env_validator",
                    line=detail,
                    pattern_name="env_unreachable_primary",
                ))
            elif status == "warning":
                log.warning("Env check WARNING: %s — %s", check, detail)
                emit_event(Event(
                    event_type=EventType.GENERIC_ERROR,
                    severity=Severity.WARNING,
                    source="env_validator",
                    line=detail,
                    pattern_name="env_check_warning",
                ))
