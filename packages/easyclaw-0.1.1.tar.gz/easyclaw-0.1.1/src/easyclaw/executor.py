"""Command executor — sandboxed shell execution with timeout and output capture."""

from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from easyclaw.logging import get_logger

log = get_logger("executor")

# Hard limits to prevent runaway commands
MAX_OUTPUT_BYTES = 64 * 1024   # 64 KB per command
MAX_TIMEOUT = 120              # 2 minutes absolute max


@dataclass
class CommandResult:
    """Result of a single command execution."""

    command: str
    return_code: int
    stdout: str
    stderr: str
    duration: float         # seconds
    timed_out: bool = False
    error: Optional[str] = None  # internal error (e.g., command not found)


class CommandExecutor:
    """Execute shell commands in a sandboxed manner.

    Safety constraints:
    - All commands run with a timeout (capped at MAX_TIMEOUT)
    - Output is capped at MAX_OUTPUT_BYTES
    - No interactive commands (stdin is /dev/null)
    - Runs as the current user (no privilege escalation)
    - Expandable home dir paths (~/) are resolved
    """

    def __init__(self, working_dir: Optional[Path] = None):
        self.working_dir = working_dir or Path.home()

    async def execute(self, command: str, timeout: int = 30) -> CommandResult:
        """Execute a single shell command asynchronously.

        Args:
            command: Shell command string to execute.
            timeout: Max seconds to wait (capped at MAX_TIMEOUT).

        Returns:
            CommandResult with return code, output, and timing.
        """
        timeout = min(timeout, MAX_TIMEOUT)
        # Expand ~ in command
        command = command.replace("~/", str(Path.home()) + "/")

        log.debug("Executing: %s (timeout=%ds)", command, timeout)
        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.DEVNULL,
                cwd=str(self.working_dir),
                env=self._safe_env(),
            )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                duration = time.monotonic() - start
                log.warning("Command timed out after %.1fs: %s", duration, command)
                return CommandResult(
                    command=command,
                    return_code=-1,
                    stdout="",
                    stderr="",
                    duration=duration,
                    timed_out=True,
                )

            duration = time.monotonic() - start
            stdout = stdout_bytes[:MAX_OUTPUT_BYTES].decode("utf-8", errors="replace")
            stderr = stderr_bytes[:MAX_OUTPUT_BYTES].decode("utf-8", errors="replace")

            result = CommandResult(
                command=command,
                return_code=proc.returncode or 0,
                stdout=stdout.strip(),
                stderr=stderr.strip(),
                duration=duration,
            )

            if result.return_code != 0:
                log.debug(
                    "Command failed (rc=%d): %s | stderr: %s",
                    result.return_code,
                    command,
                    result.stderr[:200],
                )
            else:
                log.debug("Command succeeded (%.1fs): %s", duration, command)

            return result

        except FileNotFoundError:
            duration = time.monotonic() - start
            return CommandResult(
                command=command,
                return_code=-1,
                stdout="",
                stderr="",
                duration=duration,
                error="Command not found or shell unavailable",
            )
        except Exception as e:
            duration = time.monotonic() - start
            return CommandResult(
                command=command,
                return_code=-1,
                stdout="",
                stderr="",
                duration=duration,
                error=str(e),
            )

    async def execute_sequence(
        self,
        commands: list[str],
        timeout: int = 30,
        stop_on_failure: bool = True,
    ) -> list[CommandResult]:
        """Execute a list of commands sequentially.

        Args:
            commands: List of shell commands.
            timeout: Timeout per command.
            stop_on_failure: If True, stop after first non-zero return code.

        Returns:
            List of CommandResults (may be shorter than commands if stopped early).
        """
        results = []
        for cmd in commands:
            result = await self.execute(cmd, timeout)
            results.append(result)
            if stop_on_failure and (result.return_code != 0 or result.timed_out):
                break
        return results

    def _safe_env(self) -> dict[str, str]:
        """Build a safe environment — inherit current env but strip dangerous vars."""
        env = dict(os.environ)
        # Don't pass through vars that could cause unexpected behavior
        for key in ("SUDO_ASKPASS", "SSH_ASKPASS", "DISPLAY"):
            env.pop(key, None)
        return env
