"""EasyClaw CLI — start, stop, status, doctor commands."""

from __future__ import annotations

import argparse
import json
import os
import signal
import sys
from pathlib import Path
from typing import Optional

from easyclaw import __version__


def _get_state_dir() -> Path:
    home = Path(os.environ.get("EASYCLAW_HOME", str(Path.home() / ".easyclaw")))
    return home / "state"


def _read_daemon_state() -> Optional[dict]:
    state_file = _get_state_dir() / "daemon.json"
    if not state_file.is_file():
        return None
    try:
        return json.loads(state_file.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def _read_pid() -> Optional[int]:
    pidfile = _get_state_dir() / "daemon.pid"
    if not pidfile.is_file():
        return None
    try:
        pid = int(pidfile.read_text().strip())
        # Verify process is alive
        os.kill(pid, 0)
        return pid
    except (ValueError, OSError):
        # Stale pidfile
        pidfile.unlink(missing_ok=True)
        return None


def _is_running() -> tuple[bool, Optional[int]]:
    pid = _read_pid()
    return (pid is not None, pid)


def cmd_start(args: argparse.Namespace) -> None:
    """Start the EasyClaw daemon."""
    running, pid = _is_running()
    if running:
        print(f"EasyClaw is already running (PID {pid})")
        sys.exit(1)

    if args.foreground:
        print("Starting EasyClaw in foreground mode...")
        from easyclaw.daemon import run_daemon
        run_daemon(foreground=True)
    else:
        # Daemonize: re-exec self detached from terminal
        import subprocess
        proc = subprocess.Popen(
            [sys.executable, "-m", "easyclaw", "start", "--foreground"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        print(f"EasyClaw started (PID {proc.pid})")


def cmd_stop(args: argparse.Namespace) -> None:
    """Stop the running EasyClaw daemon."""
    running, pid = _is_running()
    if not running:
        print("EasyClaw is not running")
        sys.exit(1)

    print(f"Stopping EasyClaw (PID {pid})...")
    try:
        os.kill(pid, signal.SIGTERM)
        print("Stop signal sent — EasyClaw will shut down gracefully")
    except OSError as e:
        print(f"Failed to stop: {e}")
        sys.exit(1)


def cmd_status(args: argparse.Namespace) -> None:
    """Show EasyClaw daemon status."""
    running, pid = _is_running()
    state = _read_daemon_state()

    if not running:
        print("EasyClaw: not running")
        if state and state.get("status") == "stopped":
            uptime = state.get("uptime_seconds", 0)
            print(f"  Last run: {_format_uptime(uptime)} uptime")
        return

    print(f"EasyClaw: running (PID {pid})")
    if state:
        print(f"  Status:   {state.get('status', 'unknown')}")
        print(f"  Uptime:   {_format_uptime(state.get('uptime_seconds', 0))}")
        print(f"  Platform: {state.get('platform', '?')}{' (WSL)' if state.get('is_wsl') else ''}")
        oc = state.get("openclaw_detected", False)
        if oc:
            oc_pid = state.get("openclaw_pid")
            oc_str = f"detected (PID {oc_pid})" if oc_pid else "detected (not running)"
            print(f"  OpenClaw: {oc_str}")
        else:
            print("  OpenClaw: not found")


def cmd_doctor(args: argparse.Namespace) -> None:
    """Run diagnostics on the EasyClaw + OpenClaw environment."""
    from easyclaw.config import load_config

    print("EasyClaw Doctor")
    print("=" * 40)

    config = load_config()
    checks_passed = 0
    checks_failed = 0

    def check(name: str, ok: bool, detail: str = "") -> None:
        nonlocal checks_passed, checks_failed
        icon = "OK" if ok else "FAIL"
        msg = f"  [{icon}] {name}"
        if detail:
            msg += f" — {detail}"
        print(msg)
        if ok:
            checks_passed += 1
        else:
            checks_failed += 1

    # Platform
    p = config.platform
    check("Platform detected", True, f"{p.system}{' (WSL)' if p.is_wsl else ''}")
    check("Init system", p.init_system is not None, p.init_system or "none found")
    check("Python version", True, p.python_version)

    # EasyClaw dirs
    check("EasyClaw home", config.home_dir.is_dir(), str(config.home_dir))
    check("Config file", config.config_file.is_file(), str(config.config_file))
    check("Log directory", config.log_dir.is_dir(), str(config.log_dir))

    # OpenClaw
    oc = config.openclaw
    check("OpenClaw installed", oc is not None, str(oc.home_dir) if oc else "~/.openclaw not found")
    if oc:
        check("OpenClaw config", oc.config_file is not None and oc.config_file.is_file())
        check("OpenClaw env file", oc.env_file is not None and oc.env_file.is_file())
        check("OpenClaw sessions dir", oc.sessions_dir is not None and oc.sessions_dir.is_dir())
        check("OpenClaw logs dir", oc.log_dir is not None and oc.log_dir.is_dir())
        check("OpenClaw binary", oc.bin_path is not None, str(oc.bin_path) if oc.bin_path else "not in PATH")
        check("OpenClaw service", oc.service_name is not None, oc.service_name or "no systemd service found")
        check("OpenClaw process", oc.pid is not None, f"PID {oc.pid}" if oc.pid else "not running")

    # Env vars
    env_keys = list(config.openclaw_env.keys())
    check(
        "OpenClaw env vars loaded",
        len(env_keys) > 0,
        f"{len(env_keys)} vars" if env_keys else "no env file or empty",
    )

    # MCP
    mcp_endpoint = config.settings.get("mcp_endpoint")
    mcp_token = config.settings.get("mcp_token")
    check("MCP endpoint configured", mcp_endpoint is not None, mcp_endpoint or "not set in config.yaml")
    check("MCP token configured", mcp_token is not None and len(mcp_token) > 0, "set" if mcp_token else "not set")

    # Fix ledger
    ledger_file = config.state_dir / "fix-ledger.jsonl"
    if ledger_file.is_file():
        line_count = sum(1 for _ in open(ledger_file))
        check("Fix ledger", True, f"{line_count} entries")
    else:
        check("Fix ledger", True, "no entries yet")

    # Daemon status
    running, pid = _is_running()
    check("EasyClaw daemon", running, f"PID {pid}" if running else "not running")

    # Phase 4: Dependency audit
    print()
    print("Dependency Audit")
    print("-" * 40)
    from easyclaw.dep_auditor import DepAuditor
    auditor = DepAuditor()
    for result in auditor.audit_now():
        ok = result["status"] == "ok"
        check(result["name"], ok, result["detail"])

    # Phase 4: Environment validation
    print()
    print("Environment Validation")
    print("-" * 40)
    from easyclaw.env_validator import EnvValidator
    validator = EnvValidator()
    for result in validator.validate_now(config):
        ok = result["status"] in ("ok", "skipped")
        check(result["check"], ok, result["detail"])

    print("=" * 40)
    print(f"  {checks_passed} passed, {checks_failed} failed")


def _format_uptime(seconds: float) -> str:
    s = int(seconds)
    if s < 60:
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m {s % 60}s"
    h = s // 3600
    m = (s % 3600) // 60
    return f"{h}h {m}m"


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="easyclaw",
        description="EasyClaw — Autonomous doctor and personal trainer for OpenClaw",
    )
    parser.add_argument("--version", action="version", version=f"easyclaw {__version__}")

    sub = parser.add_subparsers(dest="command")

    # start
    p_start = sub.add_parser("start", help="Start the EasyClaw daemon")
    p_start.add_argument("--foreground", "-f", action="store_true", help="Run in foreground (don't daemonize)")
    p_start.set_defaults(func=cmd_start)

    # stop
    p_stop = sub.add_parser("stop", help="Stop the EasyClaw daemon")
    p_stop.set_defaults(func=cmd_stop)

    # status
    p_status = sub.add_parser("status", help="Show daemon status")
    p_status.set_defaults(func=cmd_status)

    # doctor
    p_doctor = sub.add_parser("doctor", help="Run environment diagnostics")
    p_doctor.set_defaults(func=cmd_doctor)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
