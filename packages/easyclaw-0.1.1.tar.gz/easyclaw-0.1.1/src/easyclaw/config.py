"""EasyClaw configuration — loads its own config and discovers OpenClaw's env."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

from easyclaw.discovery import OpenClawInstance, Platform, detect_platform, discover_openclaw

# Default EasyClaw home — overridable via EASYCLAW_HOME env var
DEFAULT_HOME = Path.home() / ".easyclaw"

DEFAULT_CONFIG = {
    "heartbeat_interval": 30,       # seconds between heartbeat logs
    "health_check_interval": 60,    # seconds between OpenClaw health checks
    "log_retention_days": 7,
    "max_restart_attempts": 3,      # circuit breaker threshold
    "restart_window": 600,          # circuit breaker window in seconds (10 min)
    "gateway_port": 18789,
    "alert_webhook": None,          # optional n8n/Telegram webhook URL
    "mcp_endpoint": None,           # proprietary MCP server URL (Phase 3)
    "mcp_token": None,              # MCP auth token (Phase 3)

    # Agent brain (Phase 6)
    "openrouter_api_key": None,     # OpenRouter API key for LLM agent brain
    "openrouter_model": "z-ai/glm-4.7-flash",  # Model ID on OpenRouter
    "agent_enabled": True,          # enable/disable agent brain
    "agent_batch_window": 10,       # seconds to batch events before invoking agent
    "agent_cooldown": 30,           # minimum seconds between agent invocations
    "agent_max_turns": 10,          # max tool-call round trips per invocation
    "agent_temperature": 0.1,       # low for deterministic behavior

    # Telegram bot (Phase 7)
    "telegram_bot_token": None,     # bot token from @BotFather
    "telegram_chat_ids": [],        # authorized chat IDs (list of integers)
    "telegram_alert_severity": "CRITICAL",  # minimum severity to push alerts to Telegram
}


@dataclass
class EasyClawConfig:
    """Resolved runtime configuration."""

    # Paths
    home_dir: Path
    config_file: Path
    log_dir: Path
    state_dir: Path

    # Platform
    platform: Platform

    # OpenClaw
    openclaw: Optional[OpenClawInstance]

    # Settings (from config.yaml merged with defaults)
    settings: Dict[str, Any] = field(default_factory=dict)

    # Environment variables loaded from OpenClaw's env file
    openclaw_env: Dict[str, str] = field(default_factory=dict)


def _ensure_dirs(home: Path) -> tuple[Path, Path, Path]:
    """Create EasyClaw's directory structure and return (log_dir, state_dir, config_file)."""
    log_dir = home / "logs"
    state_dir = home / "state"
    config_file = home / "config.yaml"

    home.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(exist_ok=True)
    state_dir.mkdir(exist_ok=True)

    return log_dir, state_dir, config_file


def _load_yaml_config(config_file: Path) -> Dict[str, Any]:
    """Load config.yaml, returning empty dict if missing or invalid."""
    if not config_file.is_file():
        return {}
    try:
        with open(config_file, "r") as f:
            data = yaml.safe_load(f)
        return data if isinstance(data, dict) else {}
    except (yaml.YAMLError, OSError):
        return {}


def _write_default_config(config_file: Path) -> None:
    """Write default config.yaml if it doesn't exist."""
    if config_file.exists():
        return
    with open(config_file, "w") as f:
        yaml.dump(
            DEFAULT_CONFIG,
            f,
            default_flow_style=False,
            sort_keys=False,
        )


def _load_openclaw_env(openclaw: Optional[OpenClawInstance]) -> Dict[str, str]:
    """Parse OpenClaw's env file (KEY=VALUE format) into a dict."""
    if openclaw is None or openclaw.env_file is None:
        return {}

    env = {}
    try:
        with open(openclaw.env_file, "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip("'\"")
                    if key:
                        env[key] = value
    except OSError:
        pass
    return env


def load_config() -> EasyClawConfig:
    """Load and resolve the full EasyClaw configuration.

    Discovery order:
    1. EASYCLAW_HOME env var (or default ~/.easyclaw)
    2. Create dirs if missing
    3. Load/create config.yaml
    4. Auto-discover OpenClaw installation
    5. Load OpenClaw's env file
    """
    home = Path(os.environ.get("EASYCLAW_HOME", str(DEFAULT_HOME)))
    log_dir, state_dir, config_file = _ensure_dirs(home)

    # Write default config if first run
    _write_default_config(config_file)

    # Load user config and merge with defaults
    user_config = _load_yaml_config(config_file)
    settings = {**DEFAULT_CONFIG, **user_config}

    # Detect platform
    plat = detect_platform()

    # Discover OpenClaw
    openclaw = discover_openclaw()

    # Load OpenClaw env vars
    openclaw_env = _load_openclaw_env(openclaw)

    return EasyClawConfig(
        home_dir=home,
        config_file=config_file,
        log_dir=log_dir,
        state_dir=state_dir,
        platform=plat,
        openclaw=openclaw,
        settings=settings,
        openclaw_env=openclaw_env,
    )
