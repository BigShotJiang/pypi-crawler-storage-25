"""Security sandbox — validates and constrains EasyClaw's actions."""

from __future__ import annotations

import re
import shlex
from pathlib import Path
from typing import Optional, Tuple

from easyclaw.logging import get_logger

log = get_logger("sandbox")

# Commands that are never allowed, regardless of arguments
BLOCKED_COMMANDS = frozenset({
    "dd", "mkfs", "reboot", "shutdown", "poweroff", "halt",
    "passwd", "useradd", "userdel", "usermod", "groupadd",
    "iptables", "ip6tables", "nft", "ufw",
    "mount", "umount", "fdisk", "parted",
    "chown", "chmod",  # broad filesystem permission changes
})

# Patterns that indicate dangerous package management
BLOCKED_PATTERNS = [
    re.compile(r"\bpip\s+install\b"),
    re.compile(r"\bpip\s+uninstall\b"),
    re.compile(r"\bpip3\s+install\b"),
    re.compile(r"\bpip3\s+uninstall\b"),
    re.compile(r"\bnpm\s+install\s+-g\b"),
    re.compile(r"\bnpm\s+uninstall\s+-g\b"),
    re.compile(r"\bapt\s+"),
    re.compile(r"\bapt-get\s+"),
    re.compile(r"\byum\s+"),
    re.compile(r"\bdnf\s+"),
    re.compile(r"\bpacman\s+"),
    re.compile(r"\bbrew\s+install\b"),
    re.compile(r"\bbrew\s+uninstall\b"),
    re.compile(r"\brm\s+-rf\s+/\s*$"),       # rm -rf /
    re.compile(r"\brm\s+-rf\s+/[^.]"),        # rm -rf /anything (not relative)
    re.compile(r"\brm\s+-rf\s+/\*"),          # rm -rf /*
    re.compile(r">\s*/dev/sd"),               # writing to block devices
    re.compile(r"\bcurl\b.*\|\s*(?:ba)?sh"),  # curl pipe to shell
    re.compile(r"\bwget\b.*\|\s*(?:ba)?sh"),  # wget pipe to shell
]

# Paths that should never be written to or deleted from
BLOCKED_PATH_PREFIXES = (
    "/etc", "/usr", "/boot", "/sys", "/proc", "/sbin", "/bin",
    "/lib", "/lib64", "/var/lib", "/var/spool",
)


class SecuritySandbox:
    """Validates and constrains EasyClaw's actions to prevent unintended damage.

    Rules:
    1. Commands can only target OpenClaw-related paths/processes
    2. No write access outside ~/.easyclaw/ and OpenClaw dirs
    3. No network commands except localhost health checks
    4. No package install/uninstall commands
    5. Restart only targets OpenClaw service
    6. File deletion restricted to safe paths (tmp, logs, locks)
    """

    def __init__(
        self,
        openclaw_home: Optional[Path] = None,
        easyclaw_home: Optional[Path] = None,
    ):
        home = Path.home()
        self.openclaw_home = openclaw_home or home / ".openclaw"
        self.easyclaw_home = easyclaw_home or home / ".easyclaw"
        self.tmp_dir = Path("/tmp/openclaw")

        # All directories EasyClaw is allowed to write to / delete from
        self._writable_paths = [
            self.easyclaw_home,
            self.openclaw_home,
            self.tmp_dir,
            Path("/tmp"),
        ]
        # Broader set for read access (basically everything)
        self._readable_paths: list[Path] = []  # empty = allow all reads

        # Allowed service names for restart operations
        self._allowed_services = frozenset({
            "openclaw-gateway",
            "openclaw",
        })

        log.debug(
            "Sandbox initialized: openclaw=%s easyclaw=%s",
            self.openclaw_home, self.easyclaw_home,
        )

    def validate_command(self, command: str) -> Tuple[bool, str]:
        """Check whether a shell command is allowed.

        Returns:
            (allowed, reason) — reason explains why it was blocked or allowed.
        """
        cmd_lower = command.lower().strip()

        # ── Check for blocked base commands ──────────────────────
        try:
            tokens = shlex.split(cmd_lower)
        except ValueError:
            tokens = cmd_lower.split()

        if not tokens:
            return (False, "Empty command")

        base_cmd = tokens[0].rsplit("/", 1)[-1]  # strip path prefix

        if base_cmd in BLOCKED_COMMANDS:
            log.warning("Blocked command (dangerous base): %s", command)
            return (False, f"Command '{base_cmd}' is blocked for safety")

        # ── Check for sudo (only allow sudo systemctl for openclaw) ──
        if base_cmd == "sudo":
            if len(tokens) >= 3 and tokens[1] == "systemctl":
                service = self._extract_service_from_systemctl(tokens[2:])
                if service and service in self._allowed_services:
                    return (True, f"Allowed: sudo systemctl for {service}")
                return (False, f"sudo systemctl only allowed for services: {', '.join(self._allowed_services)}")
            log.warning("Blocked sudo command: %s", command)
            return (False, "sudo is only allowed for 'sudo systemctl' targeting OpenClaw services")

        # ── Check for blocked patterns ───────────────────────────
        for pattern in BLOCKED_PATTERNS:
            if pattern.search(cmd_lower):
                log.warning("Blocked command (pattern match): %s", command)
                return (False, f"Command matches blocked pattern: {pattern.pattern}")

        # ── Check systemctl targets ──────────────────────────────
        if base_cmd == "systemctl":
            service = self._extract_service_from_systemctl(tokens[1:])
            if service and service not in self._allowed_services:
                return (False, f"systemctl only allowed for services: {', '.join(self._allowed_services)}")
            return (True, "Allowed: systemctl for OpenClaw service")

        # ── Check kill/pkill targets ─────────────────────────────
        if base_cmd in ("kill", "pkill", "killall"):
            if "openclaw" in cmd_lower or "easyclaw" in cmd_lower:
                return (True, "Allowed: kill targeting OpenClaw/EasyClaw process")
            return (False, "kill/pkill only allowed for OpenClaw-related processes")

        # ── Check rm commands ────────────────────────────────────
        if base_cmd == "rm":
            return self._validate_rm(command, tokens)

        # ── Check find ... -delete ───────────────────────────────
        if base_cmd == "find" and "-delete" in cmd_lower:
            return self._validate_find_delete(command, tokens)

        # ── Check for writes to blocked paths ────────────────────
        for prefix in BLOCKED_PATH_PREFIXES:
            # Check if command references blocked paths with write intent
            if prefix in cmd_lower and any(
                op in cmd_lower for op in (">", ">>", "tee ", "mv ", "cp ")
            ):
                return (False, f"Write operations to {prefix} are not allowed")

        return (True, "Command passed all safety checks")

    def validate_file_operation(
        self, path: Path, operation: str
    ) -> Tuple[bool, str]:
        """Check if a file operation is within allowed scope.

        Args:
            path: Target file path.
            operation: One of "read", "write", "delete".

        Returns:
            (allowed, reason).
        """
        resolved = path.resolve()

        if operation == "read":
            return (True, "Read operations are always allowed")

        if operation == "write":
            if self._is_within_allowed_paths(resolved):
                return (True, f"Write allowed within {resolved}")
            return (
                False,
                f"Write to {resolved} denied — only allowed in: "
                f"{', '.join(str(p) for p in self._writable_paths)}",
            )

        if operation == "delete":
            # Deletion is more restrictive — only tmp, logs, locks
            safe_suffixes = {".log", ".lock", ".tmp", ".pid"}
            if resolved.suffix in safe_suffixes and self._is_within_allowed_paths(resolved):
                return (True, f"Delete allowed for {resolved.suffix} file within safe path")
            if self._is_within_tmp(resolved):
                return (True, f"Delete allowed within tmp directory")
            return (
                False,
                f"Delete of {resolved} denied — only .log/.lock/.tmp/.pid files "
                f"within allowed paths, or files in /tmp",
            )

        return (False, f"Unknown operation: {operation}")

    def validate_restart_target(self, service_name: str) -> Tuple[bool, str]:
        """Check if a service is allowed to be restarted.

        Returns:
            (allowed, reason).
        """
        name = service_name.strip().lower()
        if name in self._allowed_services:
            return (True, f"Restart allowed for service: {name}")
        return (
            False,
            f"Restart denied for '{name}' — only allowed services: "
            f"{', '.join(self._allowed_services)}",
        )

    def is_safe_path(self, path: Path) -> bool:
        """Check if a path is within allowed directories."""
        return self._is_within_allowed_paths(path.resolve())

    def get_allowed_paths(self) -> list[Path]:
        """Return the list of directories EasyClaw can write to."""
        return list(self._writable_paths)

    # ── Private helpers ──────────────────────────────────────────

    def _is_within_allowed_paths(self, resolved: Path) -> bool:
        """Check if resolved path is under any allowed directory."""
        for allowed in self._writable_paths:
            try:
                resolved.relative_to(allowed)
                return True
            except ValueError:
                continue
        return False

    def _is_within_tmp(self, resolved: Path) -> bool:
        """Check if resolved path is under /tmp."""
        try:
            resolved.relative_to(Path("/tmp"))
            return True
        except ValueError:
            return False

    def _extract_service_from_systemctl(self, args: list[str]) -> Optional[str]:
        """Extract the service name from systemctl arguments."""
        # systemctl [--user] <action> <service>
        # Filter out flags
        positional = [a for a in args if not a.startswith("-")]
        if len(positional) >= 2:
            # Last positional is typically the service name
            service = positional[-1].replace(".service", "")
            return service
        if len(positional) == 1:
            # Might be just the service name or just the action
            candidate = positional[0].replace(".service", "")
            if candidate in ("start", "stop", "restart", "status", "enable", "disable"):
                return None
            return candidate
        return None

    def _validate_rm(self, command: str, tokens: list[str]) -> Tuple[bool, str]:
        """Validate that rm only targets allowed paths."""
        # Extract paths from rm command (skip flags)
        paths = [t for t in tokens[1:] if not t.startswith("-")]
        if not paths:
            return (False, "rm with no target paths")

        for p in paths:
            expanded = Path(p).expanduser().resolve()
            if not self._is_within_allowed_paths(expanded):
                return (False, f"rm target '{p}' is outside allowed directories")

        return (True, "rm targets are within allowed paths")

    def _validate_find_delete(self, command: str, tokens: list[str]) -> Tuple[bool, str]:
        """Validate that find -delete only targets allowed paths."""
        # The search path is typically the second token
        if len(tokens) < 2:
            return (False, "find command too short to validate")

        search_path = tokens[1]
        if search_path.startswith("-"):
            # No explicit path means cwd — could be anywhere
            return (False, "find -delete must specify an explicit search path")

        expanded = Path(search_path).expanduser().resolve()
        if not self._is_within_allowed_paths(expanded):
            return (False, f"find -delete search path '{search_path}' is outside allowed directories")

        return (True, "find -delete target is within allowed paths")
