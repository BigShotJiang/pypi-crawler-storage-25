"""Update checker — periodically polls the MCP for available updates and hotfixes."""

from __future__ import annotations

import asyncio
from typing import Optional

from easyclaw.logging import get_logger
from easyclaw.mcp_client import MCPClient

log = get_logger("updater")

# Default: check every 6 hours
DEFAULT_CHECK_INTERVAL = 6 * 3600


class UpdateChecker:
    """Polls the MCP server for updates and hotfixes on a schedule."""

    def __init__(
        self,
        mcp_client: MCPClient,
        current_version: str,
        check_interval: float = DEFAULT_CHECK_INTERVAL,
    ):
        self.mcp = mcp_client
        self.current_version = current_version
        self.check_interval = check_interval
        self.last_check_result: Optional[dict] = None

    async def run(self, shutdown: asyncio.Event) -> None:
        """Periodic update check loop."""
        if not self.mcp.is_configured:
            log.info("MCP not configured — update checker disabled")
            return

        log.info("Update checker started (interval=%.0fh)", self.check_interval / 3600)

        # Initial check after a short delay
        try:
            await asyncio.wait_for(shutdown.wait(), timeout=30)
            return  # shutdown during startup delay
        except asyncio.TimeoutError:
            pass

        while not shutdown.is_set():
            await self._check_once()

            try:
                await asyncio.wait_for(shutdown.wait(), timeout=self.check_interval)
                break  # shutdown signaled
            except asyncio.TimeoutError:
                pass  # time for next check

        log.info("Update checker stopped")

    async def _check_once(self) -> None:
        """Run a single update check."""
        try:
            response = await self.mcp.check_for_updates(self.current_version)

            if not response.success:
                log.debug("Update check failed: %s", response.error)
                return

            self.last_check_result = response.data

            if response.data.get("update_available"):
                server_version = response.data.get("current_server_version", "?")
                log.warning(
                    "Update available: %s → %s",
                    self.current_version,
                    server_version,
                )

            hotfix_count = response.data.get("hotfix_count", 0)
            if hotfix_count > 0:
                log.warning(
                    "%d active hotfix(es) available — check MCP for details",
                    hotfix_count,
                )
                for hf in response.data.get("hotfixes", []):
                    log.info("Hotfix: %s", hf.get("id", "unknown"))

            if not response.data.get("update_available") and hotfix_count == 0:
                log.info(
                    "Update check: up to date (v%s, %.1fs)",
                    self.current_version,
                    response.latency,
                )

        except Exception:
            log.exception("Update check failed")
