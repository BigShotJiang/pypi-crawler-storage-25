"""Restart manager — clean stop/start of OpenClaw respecting memory save hooks."""

from __future__ import annotations

import asyncio
import time
from typing import Optional

from easyclaw.discovery import OpenClawInstance, detect_platform
from easyclaw.executor import CommandExecutor, CommandResult
from easyclaw.logging import get_logger

log = get_logger("restart")

# Timing constants
GRACEFUL_STOP_TIMEOUT = 15      # seconds to wait for graceful stop
FORCE_KILL_TIMEOUT = 5          # seconds to wait after SIGKILL
POST_RESTART_SETTLE = 5         # seconds to wait after start before declaring success


class RestartManager:
    """Manages the OpenClaw restart lifecycle.

    Sequence:
    1. Signal graceful shutdown (systemctl stop or SIGTERM)
    2. Wait for memory flush / session save
    3. Kill if still alive after timeout
    4. Start the service again
    5. Verify it came back up
    """

    def __init__(self, executor: CommandExecutor):
        self.executor = executor

    async def restart(self, openclaw: OpenClawInstance) -> RestartResult:
        """Perform a full restart of OpenClaw.

        Returns a RestartResult with success status, timing, and logs.
        """
        start_time = time.time()
        steps: list[str] = []

        # ── Step 1: Stop ───────────────────────────────────────────
        stop_result = await self._stop(openclaw, steps)
        if not stop_result:
            return RestartResult(
                success=False,
                duration=time.time() - start_time,
                steps=steps,
                error="Failed to stop OpenClaw",
            )

        # Brief pause to let resources release
        await asyncio.sleep(2)

        # ── Step 2: Start ──────────────────────────────────────────
        start_result = await self._start(openclaw, steps)
        if not start_result:
            return RestartResult(
                success=False,
                duration=time.time() - start_time,
                steps=steps,
                error="Failed to start OpenClaw",
            )

        # ── Step 3: Verify ─────────────────────────────────────────
        await asyncio.sleep(POST_RESTART_SETTLE)
        alive = await self._verify_running(openclaw, steps)

        duration = time.time() - start_time
        if alive:
            log.info("OpenClaw restarted successfully in %.1fs", duration)
        else:
            log.error("OpenClaw restart completed but process not detected after %.1fs", duration)

        return RestartResult(
            success=alive,
            duration=duration,
            steps=steps,
        )

    async def stop_only(self, openclaw: OpenClawInstance) -> bool:
        """Stop OpenClaw without restarting."""
        steps: list[str] = []
        return await self._stop(openclaw, steps)

    async def start_only(self, openclaw: OpenClawInstance) -> bool:
        """Start OpenClaw (assumes it's already stopped)."""
        steps: list[str] = []
        return await self._start(openclaw, steps)

    async def _stop(self, oc: OpenClawInstance, steps: list[str]) -> bool:
        """Gracefully stop OpenClaw, escalating to kill if needed."""
        plat = detect_platform()

        if oc.service_name and plat.init_system == "systemd":
            # Preferred: systemd stop
            steps.append(f"systemctl --user stop {oc.service_name}")
            log.info("Stopping via systemd: %s", oc.service_name)
            result = await self.executor.execute(
                f"systemctl --user stop {oc.service_name}",
                timeout=GRACEFUL_STOP_TIMEOUT,
            )
            if result.return_code == 0:
                steps.append("Graceful stop succeeded")
                return True

            steps.append(f"systemctl stop failed (rc={result.return_code}): {result.stderr[:100]}")
            log.warning("systemctl stop failed, falling back to PID kill")

        # Fallback: find and kill the process
        pid = oc.pid or self._find_pid()
        if pid is None:
            steps.append("No OpenClaw process found — already stopped")
            return True

        # SIGTERM first
        steps.append(f"Sending SIGTERM to PID {pid}")
        log.info("Sending SIGTERM to OpenClaw PID %d", pid)
        result = await self.executor.execute(f"kill {pid}", timeout=5)

        # Wait for graceful shutdown
        for _ in range(GRACEFUL_STOP_TIMEOUT):
            if not self._is_pid_alive(pid):
                steps.append("Process exited after SIGTERM")
                return True
            await asyncio.sleep(1)

        # SIGKILL as last resort
        steps.append(f"SIGTERM timeout — sending SIGKILL to PID {pid}")
        log.warning("SIGTERM timeout — sending SIGKILL to PID %d", pid)
        result = await self.executor.execute(f"kill -9 {pid}", timeout=5)

        for _ in range(FORCE_KILL_TIMEOUT):
            if not self._is_pid_alive(pid):
                steps.append("Process exited after SIGKILL")
                return True
            await asyncio.sleep(1)

        steps.append("Failed to kill process")
        return False

    async def _start(self, oc: OpenClawInstance, steps: list[str]) -> bool:
        """Start OpenClaw."""
        plat = detect_platform()

        if oc.service_name and plat.init_system == "systemd":
            steps.append(f"systemctl --user start {oc.service_name}")
            log.info("Starting via systemd: %s", oc.service_name)
            result = await self.executor.execute(
                f"systemctl --user start {oc.service_name}",
                timeout=15,
            )
            if result.return_code == 0:
                steps.append("Service start succeeded")
                return True

            steps.append(f"systemctl start failed (rc={result.return_code}): {result.stderr[:100]}")
            log.error("Failed to start OpenClaw service: %s", result.stderr[:200])
            return False

        # Fallback: direct binary launch
        if oc.bin_path:
            cmd = f"nohup {oc.bin_path} gateway start > /dev/null 2>&1 &"
            steps.append(f"Starting via binary: {cmd}")
            result = await self.executor.execute(cmd, timeout=10)
            if result.return_code == 0:
                steps.append("Binary launch succeeded")
                return True
            steps.append(f"Binary launch failed: {result.stderr[:100]}")

        steps.append("No method available to start OpenClaw")
        return False

    async def _verify_running(self, oc: OpenClawInstance, steps: list[str]) -> bool:
        """Check that OpenClaw is actually running after restart."""
        plat = detect_platform()

        if oc.service_name and plat.init_system == "systemd":
            result = await self.executor.execute(
                f"systemctl --user is-active {oc.service_name}",
                timeout=5,
            )
            alive = result.stdout.strip() == "active"
            steps.append(f"Post-restart check: {'alive' if alive else 'not active'}")
            return alive

        # Fallback: check PID
        pid = self._find_pid()
        alive = pid is not None
        steps.append(f"Post-restart PID check: {'alive (PID ' + str(pid) + ')' if alive else 'not found'}")
        return alive

    def _find_pid(self) -> Optional[int]:
        try:
            import psutil
            for proc in psutil.process_iter(["pid", "cmdline"]):
                try:
                    cmdline = proc.info.get("cmdline") or []
                    if "openclaw" in " ".join(cmdline).lower():
                        return proc.info["pid"]
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except ImportError:
            pass
        return None

    def _is_pid_alive(self, pid: int) -> bool:
        try:
            import psutil
            return psutil.pid_exists(pid)
        except ImportError:
            import os
            try:
                os.kill(pid, 0)
                return True
            except OSError:
                return False


class RestartResult:
    """Outcome of a restart operation."""

    def __init__(
        self,
        success: bool,
        duration: float,
        steps: list[str],
        error: Optional[str] = None,
    ):
        self.success = success
        self.duration = duration
        self.steps = steps
        self.error = error

    def __repr__(self) -> str:
        status = "OK" if self.success else "FAILED"
        return f"RestartResult({status}, {self.duration:.1f}s, steps={len(self.steps)})"
