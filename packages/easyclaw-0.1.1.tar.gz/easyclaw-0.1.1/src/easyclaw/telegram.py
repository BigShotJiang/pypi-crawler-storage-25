"""Telegram bot bridge — direct two-way communication with EasyClaw.

Connects to the Telegram Bot API via polling. Inbound messages are routed
through the agent brain LLM for intelligent conversational responses.
Outbound alerts are pushed to authorized chat IDs automatically.

No n8n middleman — direct daemon integration.
Library: python-telegram-bot v21+ (async-native).
"""

from __future__ import annotations

import asyncio
import time
from typing import Optional

from easyclaw.logging import get_logger

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from easyclaw.agent import AgentBrain
    from easyclaw.alerts import AlertPipeline
    from easyclaw.config import EasyClawConfig
    from easyclaw.discovery import OpenClawInstance
    from easyclaw.kpi import KPITracker
    from easyclaw.ledger import CircuitBreaker

log = get_logger("telegram")

# Telegram message limit
MAX_MESSAGE_LEN = 4096


class TelegramBridge:
    """Daemon subsystem that bridges EasyClaw to Telegram.

    Features:
    - Inbound: user messages routed through AgentBrain.chat() for LLM responses
    - Outbound: CRITICAL alerts pushed to authorized chat IDs
    - Commands: /status, /logs, /stats, /help for quick structured responses
    """

    def __init__(
        self,
        config: "EasyClawConfig",
        agent_brain: "AgentBrain",
        alert_pipeline: "AlertPipeline",
        kpi_tracker: Optional["KPITracker"] = None,
        breaker: Optional["CircuitBreaker"] = None,
    ):
        self.config = config
        self.agent = agent_brain
        self.alerts = alert_pipeline
        self.kpi = kpi_tracker
        self.breaker = breaker

        settings = config.settings
        self._bot_token: str = settings.get("telegram_bot_token") or ""
        self._chat_ids: list[int] = [
            int(cid) for cid in (settings.get("telegram_chat_ids") or [])
        ]
        self._alert_severity: str = settings.get("telegram_alert_severity", "CRITICAL")

        # Track last alert sent to avoid duplicates
        self._last_alert_check: float = time.time()
        self._sent_alert_hashes: dict[str, float] = {}  # error_hash -> last_sent_time
        self._alert_dedup_window: float = 600.0  # 10 minutes

    @property
    def is_configured(self) -> bool:
        """True if bot token is set."""
        return bool(self._bot_token)

    async def run(self, shutdown: asyncio.Event) -> None:
        """Main Telegram bot loop."""
        if not self.is_configured:
            log.info("Telegram bot not configured — skipping")
            return

        try:
            from telegram import Update
            from telegram.ext import (
                Application,
                CommandHandler,
                MessageHandler,
                filters,
            )
        except ImportError:
            log.warning(
                "python-telegram-bot not installed — run: pip install python-telegram-bot"
            )
            return

        log.info("Telegram bot starting (authorized chats: %s)", self._chat_ids or "any")

        # Build the application
        app = Application.builder().token(self._bot_token).build()

        # Register handlers
        app.add_handler(CommandHandler("start", self._cmd_start))
        app.add_handler(CommandHandler("help", self._cmd_help))
        app.add_handler(CommandHandler("status", self._cmd_status))
        app.add_handler(CommandHandler("logs", self._cmd_logs))
        app.add_handler(CommandHandler("stats", self._cmd_stats))
        app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            self._handle_message,
        ))

        # Initialize and start polling
        await app.initialize()
        await app.start()
        await app.updater.start_polling(drop_pending_updates=True)

        log.info("Telegram bot polling started")

        try:
            # Run alert forwarding loop alongside polling
            while not shutdown.is_set():
                try:
                    await self._forward_alerts(app)
                except Exception:
                    log.exception("Alert forwarding error")

                try:
                    await asyncio.wait_for(shutdown.wait(), timeout=30.0)
                    break
                except asyncio.TimeoutError:
                    pass
        finally:
            log.info("Telegram bot stopping")
            await app.updater.stop()
            await app.stop()
            await app.shutdown()
            log.info("Telegram bot stopped")

    # ── Authorization ──────────────────────────────────────────────────

    def _is_authorized(self, chat_id: int) -> bool:
        """Check if a chat ID is authorized. Empty list = allow all."""
        if not self._chat_ids:
            return True
        return chat_id in self._chat_ids

    # ── Command handlers ───────────────────────────────────────────────

    async def _cmd_start(self, update, context) -> None:
        """Handle /start command."""
        if not self._is_authorized(update.effective_chat.id):
            return

        await update.message.reply_text(
            "EasyClaw bot active. I monitor and heal your OpenClaw instance.\n\n"
            "Commands:\n"
            "/status - OpenClaw & EasyClaw status\n"
            "/logs - Recent OpenClaw log lines\n"
            "/stats - KPI summary\n"
            "/help - Show this help\n\n"
            "Or just send me a message and I'll use AI to help you."
        )

    async def _cmd_help(self, update, context) -> None:
        """Handle /help command."""
        if not self._is_authorized(update.effective_chat.id):
            return

        await update.message.reply_text(
            "EasyClaw Commands:\n\n"
            "/status - OpenClaw status (running/stopped, PID, CPU, RAM)\n"
            "/logs - Last 20 lines from OpenClaw logs\n"
            "/stats - KPI summary (MTTR, uptime, auto-fix rate)\n"
            "/help - This message\n\n"
            "Free-form messages:\n"
            "Ask me anything about your OpenClaw instance. Examples:\n"
            '- "What happened overnight?"\n'
            '- "Why did OpenClaw restart?"\n'
            '- "Search the knowledge base for connection refused"\n'
            '- "Check if there are any updates available"'
        )

    async def _cmd_status(self, update, context) -> None:
        """Handle /status command — quick structured status."""
        if not self._is_authorized(update.effective_chat.id):
            return

        oc = self.config.openclaw
        lines = ["EasyClaw Status\n"]

        # OpenClaw
        if oc:
            if oc.pid:
                try:
                    import psutil
                    proc = psutil.Process(oc.pid)
                    cpu = proc.cpu_percent(interval=0.1)
                    mem = proc.memory_info().rss / (1024 * 1024)
                    lines.append(f"OpenClaw: running (PID {oc.pid})")
                    lines.append(f"  CPU: {cpu:.1f}% | RAM: {mem:.0f}MB")
                except Exception:
                    lines.append(f"OpenClaw: PID {oc.pid} (status unknown)")
            else:
                lines.append("OpenClaw: detected but not running")
        else:
            lines.append("OpenClaw: not detected")

        # Circuit breaker
        if self.breaker:
            cb = "TRIPPED" if self.breaker.is_tripped else "OK"
            lines.append(f"Circuit breaker: {cb}")

        # Recent alerts
        recent = self.alerts.recent_alerts if self.alerts else []
        lines.append(f"Recent alerts: {len(recent)}")
        if recent:
            last = recent[-1]
            lines.append(f"  Last: [{last.severity}] {last.event_type}")

        # Agent brain
        lines.append(f"Agent brain: {'active' if self.agent.is_available else 'inactive'}")

        await update.message.reply_text("\n".join(lines))

    async def _cmd_logs(self, update, context) -> None:
        """Handle /logs command — last 20 lines from OpenClaw logs."""
        if not self._is_authorized(update.effective_chat.id):
            return

        oc = self.config.openclaw
        if not oc or not oc.log_dir:
            await update.message.reply_text("OpenClaw log directory not found.")
            return

        log_file = oc.log_dir / "extraction.log"
        if not log_file.is_file():
            await update.message.reply_text("No extraction.log found.")
            return

        try:
            with open(log_file, "r", errors="replace") as f:
                all_lines = f.readlines()
            tail = all_lines[-20:]
            text = "".join(tail)
            if not text.strip():
                text = "(log file is empty)"
            # Truncate for Telegram
            if len(text) > MAX_MESSAGE_LEN - 50:
                text = text[-(MAX_MESSAGE_LEN - 50):]
            await update.message.reply_text(f"Last 20 log lines:\n\n{text}")
        except OSError as e:
            await update.message.reply_text(f"Error reading logs: {e}")

    async def _cmd_stats(self, update, context) -> None:
        """Handle /stats command — KPI summary."""
        if not self._is_authorized(update.effective_chat.id):
            return

        if not self.kpi:
            await update.message.reply_text("KPI tracker not available.")
            return

        try:
            kpis = self.kpi.snapshot()
            text = (
                "EasyClaw KPIs\n\n"
                f"MTTR: {kpis.get('mttr', 0):.1f}s\n"
                f"Uptime: {kpis.get('uptime_pct', 0):.1f}%\n"
                f"Auto-fix rate: {kpis.get('auto_fix_rate', 0):.1f}%\n"
                f"Total fixes: {kpis.get('total_fixes', 0)}\n"
                f"Successful fixes: {kpis.get('successful_fixes', 0)}\n"
                f"Incidents today: {kpis.get('incidents_today', 0)}"
            )
            await update.message.reply_text(text)
        except Exception as e:
            await update.message.reply_text(f"Error fetching KPIs: {e}")

    # ── Conversational message handler ─────────────────────────────────

    async def _handle_message(self, update, context) -> None:
        """Handle free-form text messages — route through agent brain LLM."""
        if not self._is_authorized(update.effective_chat.id):
            return

        user_text = update.message.text
        if not user_text:
            return

        log.info("Telegram message from %d: %s", update.effective_chat.id, user_text[:100])

        # Show typing indicator
        await update.effective_chat.send_action("typing")

        try:
            response = await self.agent.chat(user_text, chat_id=update.effective_chat.id)
        except Exception:
            log.exception("Agent chat failed for Telegram message")
            response = "Sorry, I encountered an error processing your message."

        # Send response, splitting if needed
        await self._send_long_message(update.effective_chat.id, response, context)

    # ── Alert forwarding ───────────────────────────────────────────────

    async def _forward_alerts(self, app) -> None:
        """Check for new alerts and push to Telegram."""
        if not self._chat_ids:
            return  # No chat IDs to send to

        recent = self.alerts.recent_alerts if self.alerts else []
        now = time.time()

        # Clean old dedup entries
        self._sent_alert_hashes = {
            h: t for h, t in self._sent_alert_hashes.items()
            if now - t < self._alert_dedup_window
        }

        for alert in recent:
            # Only forward alerts newer than our last check
            if alert.timestamp <= self._last_alert_check:
                continue

            # Severity filter
            if self._alert_severity == "CRITICAL" and alert.severity != "CRITICAL":
                continue

            # Dedup
            if alert.error_hash in self._sent_alert_hashes:
                continue

            # Format and send
            text = (
                f"ALERT [{alert.severity}] {alert.event_type}\n\n"
                f"{alert.line[:500] if hasattr(alert, 'line') else alert.details[:500]}"
            )

            for chat_id in self._chat_ids:
                try:
                    await app.bot.send_message(chat_id=chat_id, text=text[:MAX_MESSAGE_LEN])
                except Exception:
                    log.warning("Failed to send alert to chat %d", chat_id)

            self._sent_alert_hashes[alert.error_hash] = now

        self._last_alert_check = now

    # ── Helpers ────────────────────────────────────────────────────────

    async def _send_long_message(self, chat_id: int, text: str, context) -> None:
        """Send a message, splitting into chunks if it exceeds Telegram's limit."""
        if not text:
            text = "(empty response)"

        if len(text) <= MAX_MESSAGE_LEN:
            await context.bot.send_message(chat_id=chat_id, text=text)
            return

        # Split into chunks at newline boundaries
        chunks = []
        while text:
            if len(text) <= MAX_MESSAGE_LEN:
                chunks.append(text)
                break
            # Find a good split point
            split_at = text.rfind("\n", 0, MAX_MESSAGE_LEN)
            if split_at == -1:
                split_at = MAX_MESSAGE_LEN
            chunks.append(text[:split_at])
            text = text[split_at:].lstrip("\n")

        for chunk in chunks:
            await context.bot.send_message(chat_id=chat_id, text=chunk)
