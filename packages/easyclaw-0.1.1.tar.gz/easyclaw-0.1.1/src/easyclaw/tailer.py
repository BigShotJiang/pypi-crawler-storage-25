"""Async log tailing — watches OpenClaw log files and journalctl output."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import AsyncIterator, Callable, Optional

from easyclaw.logging import get_logger

log = get_logger("tailer")


class FileTailer:
    """Tail a single log file asynchronously, yielding new lines as they appear.

    Handles file rotation (truncation or replacement) by detecting size decreases.
    """

    def __init__(self, path: Path, poll_interval: float = 1.0):
        self.path = path
        self.poll_interval = poll_interval
        self._offset: int = 0

    async def tail(self, shutdown: asyncio.Event) -> AsyncIterator[str]:
        """Yield new lines from the file until shutdown is set.

        Starts from the current end of file (doesn't replay history).
        """
        # Wait for file to exist
        while not self.path.is_file():
            if shutdown.is_set():
                return
            await asyncio.sleep(self.poll_interval)

        # Seek to end
        try:
            self._offset = self.path.stat().st_size
        except OSError:
            self._offset = 0

        while not shutdown.is_set():
            try:
                stat = self.path.stat()
            except OSError:
                # File disappeared — wait for it to come back
                await asyncio.sleep(self.poll_interval)
                continue

            # Detect rotation (file got smaller)
            if stat.st_size < self._offset:
                log.info("Log file rotated: %s", self.path.name)
                self._offset = 0

            if stat.st_size > self._offset:
                try:
                    with open(self.path, "r", errors="replace") as f:
                        f.seek(self._offset)
                        data = f.read()
                        self._offset = f.tell()

                    for line in data.splitlines():
                        line = line.strip()
                        if line:
                            yield line
                except OSError:
                    pass

            try:
                await asyncio.wait_for(shutdown.wait(), timeout=self.poll_interval)
            except asyncio.TimeoutError:
                pass


class JournalTailer:
    """Tail systemd journal for a specific user unit via journalctl subprocess."""

    def __init__(self, unit: str, poll_interval: float = 2.0):
        self.unit = unit
        self.poll_interval = poll_interval

    async def tail(self, shutdown: asyncio.Event) -> AsyncIterator[str]:
        """Stream journal lines for the unit. Falls back gracefully if journalctl unavailable."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "journalctl",
                "--user",
                "-u", self.unit,
                "--follow",
                "--no-pager",
                "-o", "cat",        # plain text, no metadata prefix
                "--since", "now",   # only new entries
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
        except FileNotFoundError:
            log.warning("journalctl not found — skipping journal tailing for %s", self.unit)
            return

        if proc.stdout is None:
            return

        log.info("Tailing journal for unit: %s", self.unit)

        try:
            while not shutdown.is_set():
                try:
                    line_bytes = await asyncio.wait_for(
                        proc.stdout.readline(),
                        timeout=self.poll_interval,
                    )
                except asyncio.TimeoutError:
                    continue

                if not line_bytes:
                    # Process ended
                    break

                line = line_bytes.decode("utf-8", errors="replace").strip()
                if line:
                    yield line
        finally:
            try:
                proc.terminate()
                await asyncio.wait_for(proc.wait(), timeout=5)
            except (ProcessLookupError, asyncio.TimeoutError):
                proc.kill()


class LogAggregator:
    """Aggregates multiple log sources into a single async stream.

    Each line is tagged with its source name for the classifier.
    """

    def __init__(self):
        self._sources: list[tuple[str, object]] = []  # (name, tailer)

    def add_file(self, name: str, path: Path, poll_interval: float = 1.0) -> None:
        self._sources.append((name, FileTailer(path, poll_interval)))

    def add_journal(self, name: str, unit: str, poll_interval: float = 2.0) -> None:
        self._sources.append((name, JournalTailer(unit, poll_interval)))

    async def stream(
        self,
        shutdown: asyncio.Event,
        callback: Callable[[str, str], None],
    ) -> None:
        """Run all tailers concurrently, calling callback(source, line) for each line.

        Runs until shutdown is set.
        """
        if not self._sources:
            log.warning("No log sources configured — nothing to tail")
            return

        async def _run_source(name: str, tailer) -> None:
            try:
                async for line in tailer.tail(shutdown):
                    callback(name, line)
            except Exception:
                log.exception("Tailer crashed for source: %s", name)

        tasks = [
            asyncio.create_task(_run_source(name, tailer))
            for name, tailer in self._sources
        ]

        # Wait for shutdown or all tasks to complete
        done, pending = await asyncio.wait(
            tasks,
            return_when=asyncio.FIRST_COMPLETED,
        )

        # If shutdown triggered, cancel remaining
        if shutdown.is_set():
            for t in pending:
                t.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
