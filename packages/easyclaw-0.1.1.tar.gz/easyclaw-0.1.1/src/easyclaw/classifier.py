"""Event classifier — pattern-matches log lines against known error signatures."""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Severity(Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


class EventType(Enum):
    # Process-level
    PROCESS_CRASH = "process_crash"
    PROCESS_STALLED = "process_stalled"
    PROCESS_OOM = "process_oom"

    # Network / API
    CONNECTION_REFUSED = "connection_refused"
    API_RATE_LIMIT = "api_rate_limit"
    API_SERVER_ERROR = "api_server_error"
    DNS_FAILURE = "dns_failure"

    # OpenClaw-specific
    SESSION_BLOAT = "session_bloat"
    SESSION_LOCKED = "session_locked"
    CRON_STORM = "cron_storm"
    COMPACTION_FAILURE = "compaction_failure"
    TOKEN_OVERFLOW = "token_overflow"

    # General
    PYTHON_TRACEBACK = "python_traceback"
    NODE_ERROR = "node_error"
    GENERIC_ERROR = "generic_error"


@dataclass
class Event:
    """A classified log event."""

    event_type: EventType
    severity: Severity
    source: str               # which log source produced this
    line: str                 # the raw log line that triggered it
    pattern_name: str         # which rule matched
    timestamp: float = field(default_factory=time.time)
    context_lines: list[str] = field(default_factory=list)  # surrounding lines for diagnosis

    @property
    def error_hash(self) -> str:
        """Short hash for deduplication and the fix ledger."""
        import hashlib
        key = f"{self.event_type.value}:{self.pattern_name}"
        return hashlib.md5(key.encode()).hexdigest()[:10]


@dataclass
class Rule:
    """A single classification rule: regex pattern -> event type + severity."""

    name: str
    pattern: re.Pattern
    event_type: EventType
    severity: Severity
    description: str = ""


# ── Built-in rules ─────────────────────────────────────────────────
# These cover the known OpenClaw failure modes from the exploration report.

BUILTIN_RULES: list[Rule] = [
    # ── Process crashes ────────────────────────────────────────────
    Rule(
        name="python_traceback",
        pattern=re.compile(r"Traceback \(most recent call last\)", re.IGNORECASE),
        event_type=EventType.PYTHON_TRACEBACK,
        severity=Severity.CRITICAL,
        description="Python traceback detected",
    ),
    Rule(
        name="node_fatal",
        pattern=re.compile(r"(FATAL ERROR|unhandledRejection|uncaughtException)", re.IGNORECASE),
        event_type=EventType.NODE_ERROR,
        severity=Severity.CRITICAL,
        description="Node.js fatal error",
    ),
    Rule(
        name="segfault",
        pattern=re.compile(r"(segmentation fault|SIGSEGV|SIGABRT)", re.IGNORECASE),
        event_type=EventType.PROCESS_CRASH,
        severity=Severity.CRITICAL,
        description="Process segfault or abort signal",
    ),

    # ── OOM ────────────────────────────────────────────────────────
    Rule(
        name="oom_killed",
        pattern=re.compile(r"(Out of memory|oom-kill|OOMKilled|MemoryError|ENOMEM|heap out of memory)", re.IGNORECASE),
        event_type=EventType.PROCESS_OOM,
        severity=Severity.CRITICAL,
        description="Out of memory / OOM kill",
    ),

    # ── Network / API ──────────────────────────────────────────────
    Rule(
        name="connection_refused",
        pattern=re.compile(r"(ConnectionRefusedError|ECONNREFUSED|connect ECONNREFUSED)", re.IGNORECASE),
        event_type=EventType.CONNECTION_REFUSED,
        severity=Severity.WARNING,
        description="Connection refused to upstream service",
    ),
    Rule(
        name="api_429",
        pattern=re.compile(r"(429|rate.?limit|too many requests)", re.IGNORECASE),
        event_type=EventType.API_RATE_LIMIT,
        severity=Severity.WARNING,
        description="API rate limit hit",
    ),
    Rule(
        name="api_5xx",
        pattern=re.compile(r"(status[:\s]*5\d{2}|HTTP\s+5\d{2}|Internal Server Error|502 Bad Gateway|503 Service Unavailable)", re.IGNORECASE),
        event_type=EventType.API_SERVER_ERROR,
        severity=Severity.WARNING,
        description="API server error (5xx)",
    ),
    Rule(
        name="dns_failure",
        pattern=re.compile(r"(EAI_AGAIN|ENOTFOUND|getaddrinfo|DNS resolution failed|resolve host)", re.IGNORECASE),
        event_type=EventType.DNS_FAILURE,
        severity=Severity.WARNING,
        description="DNS resolution failure",
    ),

    # ── OpenClaw-specific ──────────────────────────────────────────
    Rule(
        name="session_locked",
        pattern=re.compile(r"session (file )?locked", re.IGNORECASE),
        event_type=EventType.SESSION_LOCKED,
        severity=Severity.WARNING,
        description="OpenClaw session file is locked",
    ),
    Rule(
        name="token_overflow",
        pattern=re.compile(r"(token.*(overflow|exceed|limit)|context.*(overflow|too large|exceeded))", re.IGNORECASE),
        event_type=EventType.TOKEN_OVERFLOW,
        severity=Severity.CRITICAL,
        description="Token/context window overflow",
    ),
    Rule(
        name="compaction_fail",
        pattern=re.compile(r"(compaction.*(fail|error|skip)|safeguard.*(block|prevent))", re.IGNORECASE),
        event_type=EventType.COMPACTION_FAILURE,
        severity=Severity.CRITICAL,
        description="Session compaction failure — may overflow context",
    ),

    # ── Generic catch-all (lower priority) ─────────────────────────
    Rule(
        name="generic_error",
        pattern=re.compile(r"(?<!\w)(error|exception|failed|failure)(?!\w)", re.IGNORECASE),
        event_type=EventType.GENERIC_ERROR,
        severity=Severity.INFO,
        description="Generic error keyword detected",
    ),
]


class EventClassifier:
    """Classify log lines against a set of rules. First match wins (rules are priority-ordered)."""

    def __init__(self, rules: Optional[list[Rule]] = None):
        self.rules = rules if rules is not None else list(BUILTIN_RULES)
        self._context_buffer: dict[str, list[str]] = {}  # source -> recent lines
        self._context_size = 5

    def _buffer_line(self, source: str, line: str) -> list[str]:
        """Keep a rolling buffer of recent lines per source for context."""
        buf = self._context_buffer.setdefault(source, [])
        buf.append(line)
        if len(buf) > self._context_size:
            buf.pop(0)
        return list(buf)

    def classify(self, source: str, line: str) -> Optional[Event]:
        """Classify a single log line. Returns an Event if a rule matches, else None.

        Rules are evaluated in order — first match wins. This means CRITICAL rules
        should be listed before INFO catch-alls.
        """
        context = self._buffer_line(source, line)

        for rule in self.rules:
            if rule.pattern.search(line):
                return Event(
                    event_type=rule.event_type,
                    severity=rule.severity,
                    source=source,
                    line=line,
                    pattern_name=rule.name,
                    context_lines=context,
                )

        return None
