"""Temp cleaner — removes stale temp files and rotates EasyClaw logs."""

from __future__ import annotations

import asyncio
import gzip
import os
import time
from pathlib import Path
from typing import Optional

from easyclaw.classifier import Event, EventType, Severity
from easyclaw.logging import get_logger

log = get_logger("temp_cleaner")

# Safety: never delete files younger than this (seconds)
MIN_FILE_AGE = 60

# Safety: never delete files with these extensions
PROTECTED_EXTENSIONS = {".json", ".yaml", ".yml", ".toml"}


class TempCleaner:
    """Cleans stale temp files from OpenClaw directories and rotates EasyClaw logs.

    Safety rules:
    - Never delete .json config files
    - Never delete files less than 60 seconds old
    - Never delete directories
    """

    def __init__(
        self,
        cleanup_interval: float = 21600.0,   # 6 hours
        temp_retention_days: int = 3,
        workspace_retention_days: int = 7,
        log_retention_days: int = 7,
    ):
        self.cleanup_interval = cleanup_interval
        self.temp_retention_days = temp_retention_days
        self.workspace_retention_days = workspace_retention_days
        self.log_retention_days = log_retention_days

    def _is_safe_to_delete(self, path: Path) -> bool:
        """Check whether a file is safe to delete."""
        if not path.is_file():
            return False

        # Never delete protected config files
        if path.suffix.lower() in PROTECTED_EXTENSIONS:
            return False

        # Never delete files younger than MIN_FILE_AGE
        try:
            mtime = path.stat().st_mtime
            if (time.time() - mtime) < MIN_FILE_AGE:
                return False
        except OSError:
            return False

        return True

    def _is_older_than_days(self, path: Path, days: int) -> bool:
        """Check if a file's mtime is older than N days."""
        try:
            mtime = path.stat().st_mtime
            return (time.time() - mtime) > (days * 86400)
        except OSError:
            return False

    def _clean_directory(self, directory: Optional[Path], retention_days: int) -> tuple[int, int]:
        """Remove stale files from a directory. Returns (files_removed, bytes_freed)."""
        if directory is None or not directory.is_dir():
            return 0, 0

        files_removed = 0
        bytes_freed = 0

        try:
            for entry in directory.iterdir():
                if not entry.is_file():
                    continue
                if not self._is_safe_to_delete(entry):
                    continue
                if not self._is_older_than_days(entry, retention_days):
                    continue

                try:
                    size = entry.stat().st_size
                    entry.unlink()
                    files_removed += 1
                    bytes_freed += size
                    log.debug("Deleted stale file: %s (%d bytes)", entry, size)
                except OSError as e:
                    log.debug("Failed to delete %s: %s", entry, e)
        except OSError:
            pass

        return files_removed, bytes_freed

    def _rotate_logs(self, easyclaw_log_dir: Path) -> tuple[int, int]:
        """Gzip-compress EasyClaw log files older than retention period.

        Returns (files_rotated, bytes_freed).
        """
        if not easyclaw_log_dir.is_dir():
            return 0, 0

        files_rotated = 0
        bytes_freed = 0

        try:
            for entry in easyclaw_log_dir.iterdir():
                if not entry.is_file():
                    continue

                # Only rotate .log files (skip already-compressed .gz files)
                if entry.suffix.lower() != ".log":
                    continue

                if not self._is_older_than_days(entry, self.log_retention_days):
                    continue

                # Compress to .log.gz
                gz_path = entry.with_suffix(entry.suffix + ".gz")
                try:
                    original_size = entry.stat().st_size
                    with open(entry, "rb") as f_in:
                        with gzip.open(gz_path, "wb") as f_out:
                            # Read and write in chunks to handle large files
                            while True:
                                chunk = f_in.read(65536)
                                if not chunk:
                                    break
                                f_out.write(chunk)

                    # Delete the original after successful compression
                    compressed_size = gz_path.stat().st_size
                    entry.unlink()

                    saved = original_size - compressed_size
                    bytes_freed += max(saved, 0)
                    files_rotated += 1
                    log.debug(
                        "Rotated log: %s -> %s (saved %d bytes)",
                        entry.name, gz_path.name, saved,
                    )
                except OSError as e:
                    log.warning("Failed to rotate %s: %s", entry, e)
                    # Clean up partial gz file on failure
                    if gz_path.exists():
                        try:
                            gz_path.unlink()
                        except OSError:
                            pass
        except OSError:
            pass

        return files_rotated, bytes_freed

    async def run(
        self,
        shutdown: asyncio.Event,
        emit_event,
        openclaw,
        easyclaw_log_dir: Path,
    ) -> None:
        """Periodic cleanup loop.

        Args:
            shutdown: asyncio.Event to signal stop.
            emit_event: callable(Event) to push detected events.
            openclaw: OpenClawInstance (needs log_dir, workspace_dir).
            easyclaw_log_dir: path to EasyClaw's own log directory.
        """
        log.info(
            "Temp cleaner started (interval=%ds, temp_retain=%dd, workspace_retain=%dd, log_retain=%dd)",
            self.cleanup_interval,
            self.temp_retention_days,
            self.workspace_retention_days,
            self.log_retention_days,
        )

        while not shutdown.is_set():
            try:
                await self._cleanup_cycle(emit_event, openclaw, easyclaw_log_dir)
            except Exception:
                log.exception("Temp cleaner cycle failed")

            try:
                await asyncio.wait_for(shutdown.wait(), timeout=self.cleanup_interval)
            except asyncio.TimeoutError:
                pass

        log.info("Temp cleaner stopped")

    async def _cleanup_cycle(self, emit_event, openclaw, easyclaw_log_dir: Path) -> None:
        """Run one cleanup cycle."""
        loop = asyncio.get_running_loop()

        # Clean OpenClaw temp/log dir
        oc_log_dir = openclaw.log_dir if openclaw else None
        temp_removed, temp_freed = await loop.run_in_executor(
            None, self._clean_directory, oc_log_dir, self.temp_retention_days,
        )

        # Clean OpenClaw workspace dir
        oc_workspace = openclaw.workspace_dir if openclaw else None
        ws_removed, ws_freed = await loop.run_in_executor(
            None, self._clean_directory, oc_workspace, self.workspace_retention_days,
        )

        # Rotate EasyClaw logs
        logs_rotated, log_freed = await loop.run_in_executor(
            None, self._rotate_logs, easyclaw_log_dir,
        )

        total_removed = temp_removed + ws_removed
        total_freed = temp_freed + ws_freed + log_freed

        if total_removed > 0 or logs_rotated > 0:
            freed_mb = total_freed / (1024 * 1024)
            summary = (
                f"Cleanup complete: {total_removed} files deleted, "
                f"{logs_rotated} logs rotated, "
                f"{freed_mb:.1f}MB freed"
            )
            log.info(summary)
            emit_event(Event(
                event_type=EventType.GENERIC_ERROR,
                severity=Severity.INFO,
                source="temp_cleaner",
                line=summary,
                pattern_name="cleanup_complete",
            ))
        else:
            log.debug("Cleanup cycle: nothing to clean")
