"""Event queue and alert pipeline — routes classified events to notifications."""

from __future__ import annotations

import asyncio
import json
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from easyclaw.classifier import Event, Severity
from easyclaw.logging import get_logger

log = get_logger("alerts")


@dataclass
class AlertRecord:
    """Persisted alert entry for the alerts log."""

    event_type: str
    severity: str
    source: str
    line: str
    pattern_name: str
    error_hash: str
    timestamp: float
    context_lines: list[str]

    def to_json(self) -> str:
        return json.dumps(self.__dict__, default=str)


class DedupFilter:
    """Suppress duplicate alerts within a cooldown window.

    Same error_hash won't fire again within `cooldown_seconds`.
    """

    def __init__(self, cooldown_seconds: float = 300.0):
        self.cooldown = cooldown_seconds
        self._seen: dict[str, float] = {}  # error_hash -> last_alert_time

    def should_alert(self, event: Event) -> bool:
        now = time.time()
        last = self._seen.get(event.error_hash, 0.0)
        if now - last < self.cooldown:
            return False
        self._seen[event.error_hash] = now
        return True

    def cleanup(self) -> None:
        """Remove expired entries to prevent unbounded growth."""
        now = time.time()
        self._seen = {
            h: t for h, t in self._seen.items()
            if now - t < self.cooldown * 2
        }


class AlertPipeline:
    """Consumes events from the queue, deduplicates, logs, and notifies."""

    def __init__(
        self,
        alert_log_dir: Path,
        webhook_url: Optional[str] = None,
        cooldown_seconds: float = 300.0,
    ):
        self.queue: asyncio.Queue[Event] = asyncio.Queue()
        self.alert_log_dir = alert_log_dir
        self.webhook_url = webhook_url
        self._dedup = DedupFilter(cooldown_seconds)
        self._recent: deque[AlertRecord] = deque(maxlen=100)  # in-memory ring buffer

    @property
    def recent_alerts(self) -> list[AlertRecord]:
        return list(self._recent)

    def enqueue(self, event: Event) -> None:
        """Non-blocking put onto the event queue."""
        try:
            self.queue.put_nowait(event)
        except asyncio.QueueFull:
            log.warning("Alert queue full — dropping event: %s", event.event_type.value)

    async def run(self, shutdown: asyncio.Event) -> None:
        """Process events from the queue until shutdown."""
        log.info("Alert pipeline started")

        while not shutdown.is_set():
            try:
                event = await asyncio.wait_for(self.queue.get(), timeout=5.0)
            except asyncio.TimeoutError:
                continue

            await self._handle_event(event)

        # Drain remaining events
        while not self.queue.empty():
            try:
                event = self.queue.get_nowait()
                await self._handle_event(event)
            except asyncio.QueueEmpty:
                break

        log.info("Alert pipeline stopped")

    async def _handle_event(self, event: Event) -> None:
        """Process a single event: filter, log, notify."""
        # Always log INFO events to file but don't alert
        record = AlertRecord(
            event_type=event.event_type.value,
            severity=event.severity.value,
            source=event.source,
            line=event.line,
            pattern_name=event.pattern_name,
            error_hash=event.error_hash,
            timestamp=event.timestamp,
            context_lines=event.context_lines,
        )

        if event.severity == Severity.INFO:
            # Log to file only, no alert
            self._write_log(record)
            return

        # Dedup check for WARNING and CRITICAL
        if not self._dedup.should_alert(event):
            log.debug("Suppressed duplicate alert: %s (%s)", event.event_type.value, event.error_hash)
            return

        # Persist and notify
        self._write_log(record)
        self._recent.append(record)

        severity_label = event.severity.value
        log.warning(
            "[%s] %s — %s | source=%s",
            severity_label,
            event.event_type.value,
            event.line[:120],
            event.source,
        )

        if event.severity == Severity.CRITICAL and self.webhook_url:
            await self._send_webhook(record)

    def _write_log(self, record: AlertRecord) -> None:
        """Append event to the alerts log file."""
        self.alert_log_dir.mkdir(parents=True, exist_ok=True)
        log_file = self.alert_log_dir / "alerts.log"
        try:
            with open(log_file, "a") as f:
                f.write(record.to_json() + "\n")
        except OSError as e:
            log.error("Failed to write alert log: %s", e)

    async def _send_webhook(self, record: AlertRecord) -> None:
        """Send a CRITICAL alert to the configured webhook (n8n, Telegram, etc.)."""
        if not self.webhook_url:
            return

        import urllib.request
        import urllib.error

        payload = json.dumps({
            "text": (
                f"[EasyClaw CRITICAL] {record.event_type}\n"
                f"Pattern: {record.pattern_name}\n"
                f"Source: {record.source}\n"
                f"Line: {record.line[:200]}"
            ),
            "event": record.__dict__,
        }).encode("utf-8")

        try:
            req = urllib.request.Request(
                self.webhook_url,
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            # Run in executor to avoid blocking the event loop
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                None,
                lambda: urllib.request.urlopen(req, timeout=10),
            )
            log.info("Webhook alert sent for: %s", record.event_type)
        except Exception as e:
            log.error("Webhook alert failed: %s", e)
