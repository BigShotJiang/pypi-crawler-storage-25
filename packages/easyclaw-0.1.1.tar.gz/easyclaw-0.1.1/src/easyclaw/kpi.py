"""KPI instrumentation — tracks performance metrics over time.

Computes MTTR, intervention rate, uptime percentage, auto-fix rate,
and total incident counts. Persists snapshots to disk for continuity
across daemon restarts.
"""

from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from typing import Optional

from easyclaw.logging import get_logger

log = get_logger("kpi")


class KPITracker:
    """Tracks key performance indicators for EasyClaw operations.

    Metrics:
        - MTTR (Mean Time To Repair) — average duration of successful fixes
        - Intervention rate — remediation attempts per day
        - Uptime percentage — OpenClaw alive checks vs total checks
        - Auto-fix rate — successful fixes vs total fix attempts
        - Total incidents — running count of all fix attempts
    """

    def __init__(self) -> None:
        self._fix_durations: list[float] = []   # durations of successful fixes
        self._total_fixes: int = 0
        self._successful_fixes: int = 0
        self._alive_checks: int = 0
        self._alive_true: int = 0
        self._start_time: float = time.time()

    def record_fix(self, duration: float, success: bool) -> None:
        """Record a remediation attempt.

        Called by the healer after each fix attempt completes.

        Args:
            duration: How long the fix took in seconds.
            success: Whether the fix resolved the issue.
        """
        self._total_fixes += 1
        if success:
            self._successful_fixes += 1
            self._fix_durations.append(duration)
            log.debug("KPI: fix recorded — %.2fs (success)", duration)
        else:
            log.debug("KPI: fix recorded — %.2fs (failure)", duration)

    def record_openclaw_alive(self, alive: bool) -> None:
        """Record an OpenClaw alive check result.

        Called by the health monitor each check cycle.

        Args:
            alive: Whether OpenClaw was running at check time.
        """
        self._alive_checks += 1
        if alive:
            self._alive_true += 1

    def get_kpis(self) -> dict:
        """Compute and return current KPI values.

        Returns:
            Dict with keys: mttr_seconds, intervention_rate_per_day,
            uptime_percent, auto_fix_rate, total_incidents.
        """
        # MTTR — mean of successful fix durations
        if self._fix_durations:
            mttr = sum(self._fix_durations) / len(self._fix_durations)
        else:
            mttr = 0.0

        # Intervention rate — fixes per day
        elapsed_days = (time.time() - self._start_time) / 86400.0
        if elapsed_days > 0:
            intervention_rate = self._total_fixes / elapsed_days
        else:
            intervention_rate = 0.0

        # Uptime — percentage of alive checks that were True
        uptime = self._alive_true / max(self._alive_checks, 1) * 100.0

        # Auto-fix rate — successful fixes as percentage of total
        auto_fix_rate = self._successful_fixes / max(self._total_fixes, 1) * 100.0

        return {
            "mttr_seconds": round(mttr, 2),
            "intervention_rate_per_day": round(intervention_rate, 2),
            "uptime_percent": round(uptime, 2),
            "auto_fix_rate": round(auto_fix_rate, 2),
            "total_incidents": self._total_fixes,
        }

    async def run(self, shutdown: asyncio.Event, state_dir: Path) -> None:
        """Periodic snapshot saver.

        Saves KPI state to disk every 300 seconds for continuity across
        daemon restarts. Loads any existing snapshot on startup.

        Args:
            shutdown: asyncio.Event signaling daemon shutdown.
            state_dir: Directory for persisting kpi-snapshot.json.
        """
        state_dir.mkdir(parents=True, exist_ok=True)
        self._load_snapshot(state_dir)
        log.info("KPI tracker started (snapshot interval=300s)")

        while not shutdown.is_set():
            try:
                await asyncio.wait_for(shutdown.wait(), timeout=300.0)
            except asyncio.TimeoutError:
                pass

            try:
                self._save_snapshot(state_dir)
            except Exception:
                log.exception("Failed to save KPI snapshot")

        # Final save on shutdown
        try:
            self._save_snapshot(state_dir)
            log.info("KPI tracker stopped — final snapshot saved")
        except Exception:
            log.exception("Failed to save final KPI snapshot")

    def _load_snapshot(self, state_dir: Path) -> None:
        """Load persisted KPI state from disk."""
        snapshot_file = state_dir / "kpi-snapshot.json"
        if not snapshot_file.is_file():
            log.debug("No existing KPI snapshot found — starting fresh")
            return

        try:
            data = json.loads(snapshot_file.read_text())

            self._fix_durations = data.get("fix_durations", [])
            self._total_fixes = data.get("total_fixes", 0)
            self._successful_fixes = data.get("successful_fixes", 0)
            self._alive_checks = data.get("alive_checks", 0)
            self._alive_true = data.get("alive_true", 0)

            # Restore start time — use persisted value for accurate rate calc
            saved_start = data.get("start_time")
            if saved_start and isinstance(saved_start, (int, float)):
                self._start_time = saved_start

            log.info(
                "KPI snapshot loaded — %d fixes, %d alive checks, start=%s",
                self._total_fixes,
                self._alive_checks,
                time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self._start_time)),
            )
        except (json.JSONDecodeError, OSError) as e:
            log.warning("Failed to load KPI snapshot: %s — starting fresh", e)

    def _save_snapshot(self, state_dir: Path) -> None:
        """Persist current KPI state to disk."""
        snapshot_file = state_dir / "kpi-snapshot.json"
        data = {
            "fix_durations": self._fix_durations[-500:],  # cap to last 500
            "total_fixes": self._total_fixes,
            "successful_fixes": self._successful_fixes,
            "alive_checks": self._alive_checks,
            "alive_true": self._alive_true,
            "start_time": self._start_time,
            "saved_at": time.time(),
            "computed_kpis": self.get_kpis(),
        }

        try:
            snapshot_file.write_text(json.dumps(data, indent=2))
            log.debug("KPI snapshot saved — %d fixes tracked", self._total_fixes)
        except OSError as e:
            log.error("Failed to write KPI snapshot: %s", e)
