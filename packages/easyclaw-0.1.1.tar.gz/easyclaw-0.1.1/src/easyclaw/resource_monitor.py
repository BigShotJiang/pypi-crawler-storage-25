"""Resource monitor — tracks CPU/RAM trends for the OpenClaw process."""

from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass
from typing import Optional

from easyclaw.classifier import Event, EventType, Severity
from easyclaw.logging import get_logger

log = get_logger("resource_monitor")


@dataclass
class ResourceSample:
    """Single point-in-time resource measurement."""

    timestamp: float
    cpu_percent: float
    ram_mb: float
    system_free_mb: float


class ResourceMonitor:
    """Tracks OpenClaw CPU/RAM usage over a rolling window and alerts on anomalies.

    Features:
    - Rolling deque of samples (default 60 = 1 hour at 60s intervals)
    - Average CPU and RAM calculations
    - Linear regression on RAM to predict OOM
    - System-wide free memory checks
    - Periodic summary logging
    """

    def __init__(
        self,
        sample_interval: float = 60.0,
        window_size: int = 60,
        report_interval: float = 300.0,
        ram_warn_mb: float = 2048.0,
        ram_critical_mb: float = 4096.0,
    ):
        self.sample_interval = sample_interval
        self.window_size = window_size
        self.report_interval = report_interval
        self.ram_warn_mb = ram_warn_mb
        self.ram_critical_mb = ram_critical_mb

        self._samples: deque[ResourceSample] = deque(maxlen=window_size)
        self._last_report: float = 0.0

    def _find_openclaw_pid(self) -> Optional[int]:
        """Locate the current OpenClaw PID via psutil."""
        try:
            import psutil
            for proc in psutil.process_iter(["pid", "cmdline"]):
                try:
                    cmdline = proc.info.get("cmdline") or []
                    cmdline_str = " ".join(cmdline).lower()
                    if "openclaw" in cmdline_str and "easyclaw" not in cmdline_str:
                        return proc.info["pid"]
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except ImportError:
            pass
        return None

    def _take_sample(self, pid: int) -> Optional[ResourceSample]:
        """Take a single resource sample for the given PID."""
        try:
            import psutil

            # Process metrics
            proc = psutil.Process(pid)
            with proc.oneshot():
                cpu = proc.cpu_percent(interval=0.1)
                ram = proc.memory_info().rss / (1024 * 1024)

            # System-wide free memory
            vm = psutil.virtual_memory()
            free_mb = vm.available / (1024 * 1024)

            return ResourceSample(
                timestamp=time.time(),
                cpu_percent=cpu,
                ram_mb=ram,
                system_free_mb=free_mb,
            )
        except Exception:
            return None

    def _avg_cpu(self) -> float:
        """Average CPU% across all samples in the window."""
        if not self._samples:
            return 0.0
        return sum(s.cpu_percent for s in self._samples) / len(self._samples)

    def _avg_ram(self) -> float:
        """Average RAM (MB) across all samples in the window."""
        if not self._samples:
            return 0.0
        return sum(s.ram_mb for s in self._samples) / len(self._samples)

    def _ram_trend_mb_per_hour(self) -> Optional[float]:
        """Simple linear regression slope for RAM over time.

        Returns the slope in MB/hour, or None if insufficient data.
        Needs at least 5 samples to produce meaningful results.
        """
        if len(self._samples) < 5:
            return None

        samples = list(self._samples)
        n = len(samples)

        # Use timestamps relative to first sample (for numerical stability)
        t0 = samples[0].timestamp
        xs = [(s.timestamp - t0) / 3600.0 for s in samples]  # hours
        ys = [s.ram_mb for s in samples]

        # Linear regression: slope = (n*sum(xy) - sum(x)*sum(y)) / (n*sum(x^2) - (sum(x))^2)
        sum_x = sum(xs)
        sum_y = sum(ys)
        sum_xy = sum(x * y for x, y in zip(xs, ys))
        sum_x2 = sum(x * x for x in xs)

        denominator = n * sum_x2 - sum_x * sum_x
        if abs(denominator) < 1e-10:
            return None

        slope = (n * sum_xy - sum_x * sum_y) / denominator
        return slope

    def _hours_to_oom(self, current_ram: float, slope_mb_per_hour: float) -> Optional[float]:
        """Estimate hours until OOM based on current RAM and growth rate.

        Uses ram_critical_mb as the OOM threshold. Returns None if RAM
        is shrinking or already above threshold.
        """
        if slope_mb_per_hour <= 0:
            return None  # Not growing

        remaining_mb = self.ram_critical_mb - current_ram
        if remaining_mb <= 0:
            return 0.0  # Already above threshold

        return remaining_mb / slope_mb_per_hour

    async def run(
        self,
        shutdown: asyncio.Event,
        emit_event,
    ) -> None:
        """Periodic resource monitoring loop.

        Args:
            shutdown: asyncio.Event to signal stop.
            emit_event: callable(Event) to push detected events.
        """
        log.info(
            "Resource monitor started (sample=%ds, window=%d, warn=%dMB, critical=%dMB)",
            self.sample_interval,
            self.window_size,
            self.ram_warn_mb,
            self.ram_critical_mb,
        )

        while not shutdown.is_set():
            try:
                await self._sample_cycle(emit_event)
            except Exception:
                log.exception("Resource monitor cycle failed")

            try:
                await asyncio.wait_for(shutdown.wait(), timeout=self.sample_interval)
            except asyncio.TimeoutError:
                pass

        log.info("Resource monitor stopped")

    async def _sample_cycle(self, emit_event) -> None:
        """Take one sample and check for anomalies."""
        loop = asyncio.get_running_loop()
        pid = await loop.run_in_executor(None, self._find_openclaw_pid)

        if pid is None:
            log.debug("OpenClaw process not found — skipping resource sample")
            return

        sample = await loop.run_in_executor(None, self._take_sample, pid)
        if sample is None:
            log.debug("Failed to sample PID %d — process may have exited", pid)
            return

        self._samples.append(sample)

        # ── Periodic summary log ──────────────────────────────────────
        now = time.time()
        if now - self._last_report >= self.report_interval:
            self._last_report = now
            avg_cpu = self._avg_cpu()
            avg_ram = self._avg_ram()
            trend = self._ram_trend_mb_per_hour()
            trend_str = f"{trend:+.1f}MB/h" if trend is not None else "n/a"
            log.info(
                "Resource summary: PID=%d avg_cpu=%.1f%% avg_ram=%.0fMB "
                "current_ram=%.0fMB sys_free=%.0fMB trend=%s (%d samples)",
                pid,
                avg_cpu,
                avg_ram,
                sample.ram_mb,
                sample.system_free_mb,
                trend_str,
                len(self._samples),
            )

        # ── Check thresholds ──────────────────────────────────────────

        # RAM critical
        if sample.ram_mb > self.ram_critical_mb:
            log.error(
                "OpenClaw RAM CRITICAL: %.0fMB (threshold: %dMB)",
                sample.ram_mb,
                self.ram_critical_mb,
            )
            emit_event(Event(
                event_type=EventType.GENERIC_ERROR,
                severity=Severity.CRITICAL,
                source="resource_monitor",
                line=f"OpenClaw RAM usage critical: {sample.ram_mb:.0f}MB (threshold: {self.ram_critical_mb}MB)",
                pattern_name="ram_critical",
            ))
        elif self._avg_ram() > self.ram_warn_mb and len(self._samples) >= 3:
            log.warning(
                "OpenClaw avg RAM high: %.0fMB (threshold: %dMB)",
                self._avg_ram(),
                self.ram_warn_mb,
            )
            emit_event(Event(
                event_type=EventType.GENERIC_ERROR,
                severity=Severity.WARNING,
                source="resource_monitor",
                line=f"OpenClaw average RAM: {self._avg_ram():.0f}MB (threshold: {self.ram_warn_mb}MB)",
                pattern_name="ram_high",
            ))

        # CPU high
        avg_cpu = self._avg_cpu()
        if avg_cpu > 80.0 and len(self._samples) >= 3:
            log.warning("OpenClaw avg CPU high: %.1f%%", avg_cpu)
            emit_event(Event(
                event_type=EventType.GENERIC_ERROR,
                severity=Severity.WARNING,
                source="resource_monitor",
                line=f"OpenClaw average CPU: {avg_cpu:.1f}% (threshold: 80%)",
                pattern_name="cpu_high",
            ))

        # System free memory
        if sample.system_free_mb < 200:
            log.error(
                "System free memory CRITICAL: %.0fMB",
                sample.system_free_mb,
            )
            emit_event(Event(
                event_type=EventType.GENERIC_ERROR,
                severity=Severity.CRITICAL,
                source="resource_monitor",
                line=f"System free memory critically low: {sample.system_free_mb:.0f}MB",
                pattern_name="system_mem_critical",
            ))
        elif sample.system_free_mb < 500:
            log.warning(
                "System free memory low: %.0fMB",
                sample.system_free_mb,
            )
            emit_event(Event(
                event_type=EventType.GENERIC_ERROR,
                severity=Severity.WARNING,
                source="resource_monitor",
                line=f"System free memory low: {sample.system_free_mb:.0f}MB",
                pattern_name="system_mem_low",
            ))

        # RAM trend — predict OOM
        slope = self._ram_trend_mb_per_hour()
        if slope is not None and slope > 0:
            hours_left = self._hours_to_oom(sample.ram_mb, slope)
            if hours_left is not None and hours_left < 2.0:
                log.warning(
                    "RAM trend projects OOM in %.1f hours (slope: %.1fMB/h, current: %.0fMB)",
                    hours_left,
                    slope,
                    sample.ram_mb,
                )
                emit_event(Event(
                    event_type=EventType.GENERIC_ERROR,
                    severity=Severity.WARNING,
                    source="resource_monitor",
                    line=f"RAM trend projects OOM in {hours_left:.1f}h (growing {slope:.1f}MB/h, current {sample.ram_mb:.0f}MB)",
                    pattern_name="ram_oom_projection",
                ))
