"""Process health monitor — watches OpenClaw's process state and resource usage."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from easyclaw.classifier import Event, EventType, Severity
from easyclaw.logging import get_logger

log = get_logger("health")


@dataclass
class ProcessSnapshot:
    """Point-in-time snapshot of a process's health."""

    pid: int
    alive: bool
    cpu_percent: float = 0.0
    memory_mb: float = 0.0
    uptime_seconds: float = 0.0
    timestamp: float = 0.0


@dataclass
class SessionStats:
    """Stats about OpenClaw's session directory."""

    total_files: int = 0
    total_size_mb: float = 0.0
    lock_files: int = 0
    deleted_files: int = 0


class HealthMonitor:
    """Monitors OpenClaw process health and generates events on anomalies."""

    def __init__(
        self,
        check_interval: float = 60.0,
        stall_threshold: float = 300.0,    # 5 min with no log output = stalled
        session_size_warn_mb: float = 500.0,
        kpi_tracker=None,
    ):
        self.check_interval = check_interval
        self.stall_threshold = stall_threshold
        self.session_size_warn_mb = session_size_warn_mb
        self.kpi = kpi_tracker

        self._last_log_activity: float = time.time()
        self._last_pid: Optional[int] = None
        self._was_alive: bool = True

    def notify_log_activity(self) -> None:
        """Called by the tailer/classifier whenever a log line is seen."""
        self._last_log_activity = time.time()

    def _get_process_snapshot(self, pid: int) -> ProcessSnapshot:
        """Get CPU, memory, and uptime for a PID."""
        try:
            import psutil
            proc = psutil.Process(pid)
            with proc.oneshot():
                cpu = proc.cpu_percent(interval=0.1)
                mem = proc.memory_info().rss / (1024 * 1024)
                create_time = proc.create_time()
                uptime = time.time() - create_time

            return ProcessSnapshot(
                pid=pid,
                alive=True,
                cpu_percent=cpu,
                memory_mb=mem,
                uptime_seconds=uptime,
                timestamp=time.time(),
            )
        except Exception:
            return ProcessSnapshot(pid=pid, alive=False, timestamp=time.time())

    def _check_sessions(self, sessions_dir: Optional[Path]) -> Optional[SessionStats]:
        """Scan OpenClaw's session directory for bloat indicators."""
        if sessions_dir is None or not sessions_dir.is_dir():
            return None

        stats = SessionStats()
        try:
            for entry in sessions_dir.iterdir():
                if not entry.is_file():
                    continue
                stats.total_files += 1
                size = entry.stat().st_size
                stats.total_size_mb += size / (1024 * 1024)

                name = entry.name.lower()
                if name.endswith(".lock"):
                    stats.lock_files += 1
                if ".deleted." in name:
                    stats.deleted_files += 1
        except OSError:
            pass

        return stats

    def _find_openclaw_pid(self) -> Optional[int]:
        """Locate the current OpenClaw PID via psutil."""
        try:
            import psutil
            for proc in psutil.process_iter(["pid", "cmdline"]):
                try:
                    cmdline = proc.info.get("cmdline") or []
                    cmdline_str = " ".join(cmdline).lower()
                    if "openclaw" in cmdline_str and "easyclaw" not in cmdline_str:
                        return proc.info["pid"]
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except ImportError:
            pass
        return None

    async def run(
        self,
        shutdown: asyncio.Event,
        emit_event,
        sessions_dir: Optional[Path] = None,
    ) -> None:
        """Periodic health check loop.

        Args:
            shutdown: asyncio.Event to signal stop.
            emit_event: callable(Event) to push detected events.
            sessions_dir: path to OpenClaw's sessions directory.
        """
        log.info("Health monitor started (interval=%ds)", self.check_interval)

        while not shutdown.is_set():
            try:
                await self._check_cycle(emit_event, sessions_dir)
            except Exception:
                log.exception("Health check cycle failed")

            try:
                await asyncio.wait_for(shutdown.wait(), timeout=self.check_interval)
            except asyncio.TimeoutError:
                pass

        log.info("Health monitor stopped")

    async def _check_cycle(self, emit_event, sessions_dir: Optional[Path]) -> None:
        """Run one health check cycle."""
        pid = self._find_openclaw_pid()

        # ── Process alive check ────────────────────────────────────
        if pid is None:
            if self.kpi:
                self.kpi.record_openclaw_alive(False)
            if self._was_alive:
                log.error("OpenClaw process not found — may have crashed")
                emit_event(Event(
                    event_type=EventType.PROCESS_CRASH,
                    severity=Severity.CRITICAL,
                    source="health_monitor",
                    line="OpenClaw process not found",
                    pattern_name="process_disappeared",
                ))
                self._was_alive = False
            return

        # Process came back
        if not self._was_alive:
            log.info("OpenClaw process recovered — PID %d", pid)
            self._was_alive = True

        if self.kpi:
            self.kpi.record_openclaw_alive(True)

        self._last_pid = pid

        # ── Resource snapshot ──────────────────────────────────────
        snapshot = self._get_process_snapshot(pid)
        if not snapshot.alive:
            emit_event(Event(
                event_type=EventType.PROCESS_CRASH,
                severity=Severity.CRITICAL,
                source="health_monitor",
                line=f"OpenClaw PID {pid} is no longer alive",
                pattern_name="process_dead",
            ))
            self._was_alive = False
            return

        log.debug(
            "OpenClaw health: PID=%d cpu=%.1f%% mem=%.0fMB uptime=%.0fs",
            pid, snapshot.cpu_percent, snapshot.memory_mb, snapshot.uptime_seconds,
        )

        # ── Stall detection ────────────────────────────────────────
        silence = time.time() - self._last_log_activity
        if silence > self.stall_threshold:
            log.warning(
                "OpenClaw appears stalled — no log output for %.0fs",
                silence,
            )
            emit_event(Event(
                event_type=EventType.PROCESS_STALLED,
                severity=Severity.WARNING,
                source="health_monitor",
                line=f"No log output for {silence:.0f}s (threshold: {self.stall_threshold:.0f}s)",
                pattern_name="stalled_process",
            ))

        # ── Session bloat check ────────────────────────────────────
        stats = self._check_sessions(sessions_dir)
        if stats:
            if stats.total_size_mb > self.session_size_warn_mb:
                log.warning(
                    "Session directory bloat: %.0fMB across %d files (%d locks, %d deleted)",
                    stats.total_size_mb, stats.total_files, stats.lock_files, stats.deleted_files,
                )
                emit_event(Event(
                    event_type=EventType.SESSION_BLOAT,
                    severity=Severity.WARNING,
                    source="health_monitor",
                    line=f"Session dir: {stats.total_size_mb:.0f}MB, {stats.total_files} files, {stats.lock_files} locks",
                    pattern_name="session_bloat",
                ))
