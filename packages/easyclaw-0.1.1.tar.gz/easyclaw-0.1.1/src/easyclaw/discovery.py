"""Discover OpenClaw installation, logs, config, and process state."""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class OpenClawInstance:
    """Represents a discovered OpenClaw installation."""

    home_dir: Path                          # ~/.openclaw
    config_file: Optional[Path] = None      # ~/.openclaw/openclaw.json
    env_file: Optional[Path] = None         # ~/.openclaw_env
    sessions_dir: Optional[Path] = None     # ~/.openclaw/agents/main/sessions
    log_dir: Optional[Path] = None          # /tmp/openclaw
    cron_file: Optional[Path] = None        # ~/.openclaw/cron/jobs.json
    workspace_dir: Optional[Path] = None    # ~/.openclaw/workspace
    bin_path: Optional[Path] = None         # path to `openclaw` binary
    service_name: Optional[str] = None      # systemd unit name
    pid: Optional[int] = None               # running process PID
    gateway_port: int = 18789


@dataclass
class Platform:
    """Host platform details."""

    system: str         # Linux, Darwin, Windows
    is_wsl: bool = False
    init_system: Optional[str] = None   # systemd, launchd, None
    python_version: str = ""
    hostname: str = ""


def detect_platform() -> Platform:
    """Detect the host OS, init system, and WSL status."""
    system = platform.system()
    hostname = platform.node()
    python_version = platform.python_version()
    is_wsl = False
    init_system = None

    if system == "Linux":
        # Check for WSL
        try:
            with open("/proc/version", "r") as f:
                proc_version = f.read().lower()
            is_wsl = "microsoft" in proc_version or "wsl" in proc_version
        except OSError:
            pass

        # Check init system
        if shutil.which("systemctl"):
            init_system = "systemd"

    elif system == "Darwin":
        init_system = "launchd"

    return Platform(
        system=system,
        is_wsl=is_wsl,
        init_system=init_system,
        python_version=python_version,
        hostname=hostname,
    )


def _resolve_user_home() -> Path:
    """Get the real user home directory, handling sudo and WSL."""
    sudo_user = os.environ.get("SUDO_USER")
    if sudo_user:
        return Path(f"/home/{sudo_user}")
    return Path.home()


def _find_openclaw_binary() -> Optional[Path]:
    """Locate the openclaw CLI binary."""
    # Check PATH first
    binary = shutil.which("openclaw")
    if binary:
        return Path(binary)

    # Common npm global install locations
    home = _resolve_user_home()
    candidates = [
        home / ".npm-global" / "bin" / "openclaw",
        home / ".nvm" / "versions",  # nvm — would need to glob
        Path("/usr/local/bin/openclaw"),
        Path("/usr/bin/openclaw"),
    ]
    for candidate in candidates:
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return candidate

    return None


def _find_openclaw_home() -> Optional[Path]:
    """Locate the ~/.openclaw directory."""
    home = _resolve_user_home()
    openclaw_home = home / ".openclaw"
    if openclaw_home.is_dir():
        return openclaw_home
    return None


def _detect_service_name(plat: Platform) -> Optional[str]:
    """Detect the systemd service name for OpenClaw."""
    if plat.init_system != "systemd":
        return None

    # Check common service names
    candidates = ["openclaw-gateway", "openclaw"]
    for name in candidates:
        try:
            result = subprocess.run(
                ["systemctl", "--user", "is-enabled", name],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 or "enabled" in result.stdout:
                return name
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    return None


def _find_running_pid() -> Optional[int]:
    """Find the PID of a running OpenClaw process."""
    try:
        import psutil
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                cmdline = proc.info.get("cmdline") or []
                cmdline_str = " ".join(cmdline).lower()
                if "openclaw" in cmdline_str and "easyclaw" not in cmdline_str:
                    return proc.info["pid"]
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    except ImportError:
        pass
    return None


def discover_openclaw() -> Optional[OpenClawInstance]:
    """Auto-discover an OpenClaw installation on the current host.

    Returns None if no installation is found.
    """
    home_dir = _find_openclaw_home()
    if home_dir is None:
        return None

    plat = detect_platform()
    user_home = _resolve_user_home()

    instance = OpenClawInstance(home_dir=home_dir)

    # Config file
    config_file = home_dir / "openclaw.json"
    if config_file.is_file():
        instance.config_file = config_file

    # Env file
    env_file = user_home / ".openclaw_env"
    if env_file.is_file():
        instance.env_file = env_file

    # Sessions directory
    sessions_dir = home_dir / "agents" / "main" / "sessions"
    if sessions_dir.is_dir():
        instance.sessions_dir = sessions_dir

    # Log directory
    log_dir = Path("/tmp/openclaw")
    if log_dir.is_dir():
        instance.log_dir = log_dir

    # Cron file
    cron_file = home_dir / "cron" / "jobs.json"
    if cron_file.is_file():
        instance.cron_file = cron_file

    # Workspace
    workspace_dir = home_dir / "workspace"
    if workspace_dir.is_dir():
        instance.workspace_dir = workspace_dir

    # Binary
    instance.bin_path = _find_openclaw_binary()

    # Service
    instance.service_name = _detect_service_name(plat)

    # Running PID
    instance.pid = _find_running_pid()

    return instance
