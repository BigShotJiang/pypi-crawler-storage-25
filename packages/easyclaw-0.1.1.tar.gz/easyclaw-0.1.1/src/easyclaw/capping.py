"""Resource capping — self-limits EasyClaw's CPU and memory consumption."""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from typing import Optional, Tuple

from easyclaw.logging import get_logger

log = get_logger("capping")

# systemd unit template
_SYSTEMD_UNIT_TEMPLATE = """\
[Unit]
Description=EasyClaw - OpenClaw Doctor & Personal Trainer
After=network.target

[Service]
Type=simple
ExecStart={exec_command}
Restart=on-failure
RestartSec=10

# Resource limits
CPUQuota={cpu_quota}%
MemoryMax={memory_max}M
MemoryHigh={memory_high}M
Nice={nice_value}

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=/home/%u/.easyclaw /tmp/openclaw
PrivateTmp=true

[Install]
WantedBy=default.target
"""


class ResourceCap:
    """Self-limits EasyClaw's resource consumption.

    Uses os.nice() for CPU priority and monitors own memory usage.
    Also generates the systemd service file with appropriate resource limits.
    """

    def __init__(
        self,
        nice_value: int = 10,
        max_memory_mb: int = 256,
        max_cpu_percent: float = 10.0,
    ):
        self.nice_value = nice_value
        self.max_memory_mb = max_memory_mb
        self.max_cpu_percent = max_cpu_percent

    def apply_nice(self) -> None:
        """Set process niceness via os.nice().

        Only increases niceness (lower priority). Logs the result.
        Catches and logs PermissionError gracefully.
        """
        try:
            current = os.nice(0)
            if current >= self.nice_value:
                log.debug(
                    "Niceness already %d (>= target %d), no change needed",
                    current, self.nice_value,
                )
                return

            increment = self.nice_value - current
            new_nice = os.nice(increment)
            log.info("Set process niceness to %d (was %d)", new_nice, current)
        except PermissionError:
            log.warning(
                "Cannot set niceness to %d — permission denied (running as non-root is expected)",
                self.nice_value,
            )
        except AttributeError:
            # os.nice() not available on Windows
            log.debug("os.nice() not available on this platform — skipping")
        except OSError as e:
            log.warning("Failed to set niceness: %s", e)

    def check_self_usage(self) -> dict:
        """Check EasyClaw's own CPU% and memory RSS.

        Returns:
            Dict with pid, cpu_percent, memory_mb, nice, within_limits.
        """
        pid = os.getpid()
        result = {
            "pid": pid,
            "cpu_percent": 0.0,
            "memory_mb": 0.0,
            "nice": 0,
            "within_limits": True,
        }

        try:
            import psutil
            proc = psutil.Process(pid)
            with proc.oneshot():
                result["cpu_percent"] = proc.cpu_percent(interval=0.1)
                result["memory_mb"] = proc.memory_info().rss / (1024 * 1024)
                try:
                    result["nice"] = proc.nice()
                except (psutil.AccessDenied, AttributeError):
                    pass

            # Check limits
            mem_over = result["memory_mb"] > self.max_memory_mb
            cpu_over = result["cpu_percent"] > self.max_cpu_percent
            result["within_limits"] = not (mem_over or cpu_over)

        except ImportError:
            log.debug("psutil not available — cannot check self usage")
        except Exception as e:
            log.warning("Failed to check self usage: %s", e)

        return result

    def generate_systemd_unit(
        self, exec_command: str = "easyclaw start -f"
    ) -> str:
        """Generate a systemd service unit file string with resource limits.

        Args:
            exec_command: The command to run EasyClaw.

        Returns:
            Complete systemd unit file content as a string.
        """
        return _SYSTEMD_UNIT_TEMPLATE.format(
            exec_command=exec_command,
            cpu_quota=int(self.max_cpu_percent),
            memory_max=self.max_memory_mb,
            memory_high=int(self.max_memory_mb * 0.8),
            nice_value=self.nice_value,
        )

    def install_systemd_service(
        self, exec_command: Optional[str] = None
    ) -> Tuple[bool, str]:
        """Write the unit file and reload systemd.

        Args:
            exec_command: Command for ExecStart. Defaults to
                ``sys.executable -m easyclaw start -f``.

        Returns:
            (success, message).
        """
        if exec_command is None:
            exec_command = f"{sys.executable} -m easyclaw start -f"

        unit_dir = Path.home() / ".config" / "systemd" / "user"
        unit_file = unit_dir / "easyclaw.service"

        try:
            unit_dir.mkdir(parents=True, exist_ok=True)
            content = self.generate_systemd_unit(exec_command)
            unit_file.write_text(content, encoding="utf-8")
            log.info("Wrote systemd unit to %s", unit_file)
        except OSError as e:
            msg = f"Failed to write systemd unit: {e}"
            log.error(msg)
            return (False, msg)

        # Reload systemd
        import subprocess

        try:
            subprocess.run(
                ["systemctl", "--user", "daemon-reload"],
                check=True,
                capture_output=True,
                timeout=15,
            )
            log.info("systemd user daemon reloaded")
        except FileNotFoundError:
            msg = "systemctl not found — systemd not available on this platform"
            log.warning(msg)
            return (False, msg)
        except subprocess.CalledProcessError as e:
            msg = f"daemon-reload failed: {e.stderr.decode('utf-8', errors='replace').strip()}"
            log.error(msg)
            return (False, msg)
        except subprocess.TimeoutExpired:
            msg = "daemon-reload timed out after 15s"
            log.error(msg)
            return (False, msg)

        return (True, f"Service installed at {unit_file} and daemon reloaded")

    async def run(self, shutdown: asyncio.Event) -> None:
        """Periodic self-monitoring loop.

        Logs own resource usage every 60 seconds. Warns if memory exceeds
        the configured max — does not auto-kill, just warns.

        Args:
            shutdown: asyncio.Event to signal stop.
        """
        interval = 60.0
        log.info(
            "Resource cap monitor started (mem_limit=%dMB, cpu_limit=%.0f%%, nice=%d)",
            self.max_memory_mb, self.max_cpu_percent, self.nice_value,
        )

        while not shutdown.is_set():
            try:
                usage = self.check_self_usage()

                log.debug(
                    "EasyClaw self-usage: PID=%d cpu=%.1f%% mem=%.1fMB nice=%d within_limits=%s",
                    usage["pid"],
                    usage["cpu_percent"],
                    usage["memory_mb"],
                    usage["nice"],
                    usage["within_limits"],
                )

                if usage["memory_mb"] > self.max_memory_mb:
                    log.warning(
                        "EasyClaw memory usage %.1fMB exceeds limit %dMB — "
                        "consider restarting EasyClaw",
                        usage["memory_mb"],
                        self.max_memory_mb,
                    )

                if usage["cpu_percent"] > self.max_cpu_percent:
                    log.warning(
                        "EasyClaw CPU usage %.1f%% exceeds limit %.0f%%",
                        usage["cpu_percent"],
                        self.max_cpu_percent,
                    )

            except Exception:
                log.exception("Resource cap check failed")

            try:
                await asyncio.wait_for(shutdown.wait(), timeout=interval)
            except asyncio.TimeoutError:
                pass

        log.info("Resource cap monitor stopped")
