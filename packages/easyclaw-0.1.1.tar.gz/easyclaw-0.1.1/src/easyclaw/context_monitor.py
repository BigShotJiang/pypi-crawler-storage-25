"""Context monitor — tracks OpenClaw's memory/context file sizes over time."""

from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from typing import Optional

from easyclaw.classifier import Event, EventType, Severity
from easyclaw.logging import get_logger

log = get_logger("context_monitor")

# Max snapshots to keep (7 days at 1/hour)
MAX_SNAPSHOTS = 168


class ContextMonitor:
    """Monitors OpenClaw's home directory for file size bloat and growth trends.

    Periodically scans all files under openclaw.home_dir, records total size
    and largest file, and emits warnings when thresholds are exceeded or
    growth rate is abnormal.
    """

    def __init__(
        self,
        check_interval: float = 3600.0,
        context_warn_mb: float = 500.0,
        file_warn_mb: float = 50.0,
        growth_warn_mb_per_day: float = 100.0,
        state_dir: Optional[Path] = None,
    ):
        self.check_interval = check_interval
        self.context_warn_mb = context_warn_mb
        self.file_warn_mb = file_warn_mb
        self.growth_warn_mb_per_day = growth_warn_mb_per_day
        self._state_dir = state_dir
        self._snapshots_file: Optional[Path] = None

    def _resolve_snapshots_file(self, state_dir: Path) -> Path:
        """Resolve the snapshots file path, using provided state_dir or fallback."""
        if self._state_dir is not None:
            self._state_dir.mkdir(parents=True, exist_ok=True)
            return self._state_dir / "context-snapshots.json"
        state_dir.mkdir(parents=True, exist_ok=True)
        return state_dir / "context-snapshots.json"

    def _load_snapshots(self) -> list[dict]:
        """Load existing snapshots from disk."""
        if self._snapshots_file is None or not self._snapshots_file.is_file():
            return []
        try:
            with open(self._snapshots_file, "r") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
        except (json.JSONDecodeError, OSError):
            pass
        return []

    def _save_snapshots(self, snapshots: list[dict]) -> None:
        """Save snapshots to disk, trimming to MAX_SNAPSHOTS."""
        if self._snapshots_file is None:
            return
        # Keep only the most recent snapshots
        trimmed = snapshots[-MAX_SNAPSHOTS:]
        try:
            with open(self._snapshots_file, "w") as f:
                json.dump(trimmed, f)
        except OSError:
            log.warning("Failed to write context snapshots to %s", self._snapshots_file)

    def _scan_directory(self, home_dir: Path) -> dict:
        """Recursively scan a directory and return a snapshot dict."""
        total_bytes = 0
        largest_file = ""
        largest_bytes = 0

        try:
            for entry in home_dir.rglob("*"):
                try:
                    if not entry.is_file():
                        continue
                    size = entry.stat().st_size
                    total_bytes += size
                    if size > largest_bytes:
                        largest_bytes = size
                        largest_file = str(entry)
                except OSError:
                    continue
        except OSError:
            pass

        total_mb = total_bytes / (1024 * 1024)
        largest_mb = largest_bytes / (1024 * 1024)

        return {
            "timestamp": time.time(),
            "total_mb": round(total_mb, 2),
            "largest_file": largest_file,
            "largest_mb": round(largest_mb, 2),
        }

    def _calc_growth_rate(self, snapshots: list[dict]) -> Optional[float]:
        """Calculate growth rate in MB/day from snapshots.

        Uses the oldest and newest snapshots to compute a simple rate.
        Returns None if insufficient data (need at least 2 snapshots spanning > 1 hour).
        """
        if len(snapshots) < 2:
            return None

        oldest = snapshots[0]
        newest = snapshots[-1]
        elapsed_seconds = newest["timestamp"] - oldest["timestamp"]

        # Need at least 1 hour of data
        if elapsed_seconds < 3600:
            return None

        elapsed_days = elapsed_seconds / 86400
        delta_mb = newest["total_mb"] - oldest["total_mb"]
        return delta_mb / elapsed_days

    async def run(
        self,
        shutdown: asyncio.Event,
        emit_event,
        openclaw,
    ) -> None:
        """Periodic context monitoring loop.

        Args:
            shutdown: asyncio.Event to signal stop.
            emit_event: callable(Event) to push detected events.
            openclaw: OpenClawInstance (needs home_dir).
        """
        if openclaw is None or openclaw.home_dir is None:
            log.warning("OpenClaw not discovered — context monitor disabled")
            return

        # Resolve state dir from the openclaw discovery or fallback
        state_dir = self._state_dir or Path.home() / ".easyclaw" / "state"
        self._snapshots_file = self._resolve_snapshots_file(state_dir)

        log.info(
            "Context monitor started (interval=%ds, warn=%dMB, file_warn=%dMB)",
            self.check_interval,
            self.context_warn_mb,
            self.file_warn_mb,
        )

        while not shutdown.is_set():
            try:
                await self._check_cycle(emit_event, openclaw)
            except Exception:
                log.exception("Context monitor check cycle failed")

            try:
                await asyncio.wait_for(shutdown.wait(), timeout=self.check_interval)
            except asyncio.TimeoutError:
                pass

        log.info("Context monitor stopped")

    async def _check_cycle(self, emit_event, openclaw) -> None:
        """Run one context monitoring cycle."""
        home_dir = openclaw.home_dir
        if not home_dir.is_dir():
            return

        # Run the blocking scan in a thread to avoid blocking the event loop
        loop = asyncio.get_running_loop()
        snapshot = await loop.run_in_executor(None, self._scan_directory, home_dir)

        log.debug(
            "Context scan: total=%.1fMB, largest=%.1fMB (%s)",
            snapshot["total_mb"],
            snapshot["largest_mb"],
            snapshot["largest_file"],
        )

        # Load existing snapshots, append new one, save
        snapshots = self._load_snapshots()
        snapshots.append(snapshot)
        self._save_snapshots(snapshots)

        # ── Check total size ──────────────────────────────────────────
        if snapshot["total_mb"] > self.context_warn_mb:
            log.warning(
                "Context directory bloat: %.1fMB (threshold: %dMB)",
                snapshot["total_mb"],
                self.context_warn_mb,
            )
            emit_event(Event(
                event_type=EventType.GENERIC_ERROR,
                severity=Severity.WARNING,
                source="context_monitor",
                line=f"OpenClaw home directory is {snapshot['total_mb']:.1f}MB (threshold: {self.context_warn_mb}MB)",
                pattern_name="context_bloat",
            ))

        # ── Check single file size ────────────────────────────────────
        if snapshot["largest_mb"] > self.file_warn_mb:
            log.warning(
                "Large file detected: %s (%.1fMB, threshold: %dMB)",
                snapshot["largest_file"],
                snapshot["largest_mb"],
                self.file_warn_mb,
            )
            emit_event(Event(
                event_type=EventType.GENERIC_ERROR,
                severity=Severity.WARNING,
                source="context_monitor",
                line=f"Large file: {snapshot['largest_file']} ({snapshot['largest_mb']:.1f}MB, threshold: {self.file_warn_mb}MB)",
                pattern_name="context_large_file",
            ))

        # ── Check growth rate ─────────────────────────────────────────
        growth_rate = self._calc_growth_rate(snapshots)
        if growth_rate is not None and growth_rate > self.growth_warn_mb_per_day:
            log.warning(
                "Context growing rapidly: %.1fMB/day (threshold: %dMB/day)",
                growth_rate,
                self.growth_warn_mb_per_day,
            )
            emit_event(Event(
                event_type=EventType.GENERIC_ERROR,
                severity=Severity.WARNING,
                source="context_monitor",
                line=f"Context growth rate: {growth_rate:.1f}MB/day (threshold: {self.growth_warn_mb_per_day}MB/day)",
                pattern_name="context_rapid_growth",
            ))
