"""Security Audit & Deployment Validation Checklists.

Used by security_audit, validate_deployment, and troubleshoot_gateway tools.
"""

from __future__ import annotations


# ── Security Audit Checklist ──────────────────────────────────────

SECURITY_CHECKS = [
    # ── Critical ──────────────────────────────────────────────────
    {
        "id": "api_key_exposure",
        "severity": "critical",
        "category": "secrets",
        "check": "API keys are not hardcoded in config files or committed to git",
        "fix": "Move all keys to ~/.openclaw_env. Add *.env to .gitignore. Rotate any exposed keys immediately.",
        "command": "grep -r 'sk-or-\\|sk-ant-\\|OPENROUTER_API_KEY=' ~/.openclaw/ --include='*.json' --include='*.md' 2>/dev/null",
    },
    {
        "id": "env_file_permissions",
        "severity": "critical",
        "category": "secrets",
        "check": "~/.openclaw_env has restrictive permissions (600 or 640)",
        "fix": "chmod 600 ~/.openclaw_env",
        "command": "stat -c '%a' ~/.openclaw_env 2>/dev/null || echo 'FILE NOT FOUND'",
    },
    {
        "id": "gateway_bind_address",
        "severity": "critical",
        "category": "network",
        "check": "Gateway binds to 127.0.0.1 (not 0.0.0.0) unless behind reverse proxy",
        "fix": "Set bind to '127.0.0.1' in openclaw.json unless you need external access behind a proxy.",
        "command": "grep -o '\"bind\"[[:space:]]*:[[:space:]]*\"[^\"]*\"' ~/.openclaw/openclaw.json 2>/dev/null",
    },
    {
        "id": "rate_limiting",
        "severity": "high",
        "category": "network",
        "check": "Rate limiting is enabled on the gateway",
        "fix": "Add rateLimit config: {\"windowMs\": 60000, \"maxRequests\": 60}",
        "command": "grep -c 'rateLimit' ~/.openclaw/openclaw.json 2>/dev/null",
    },
    {
        "id": "cors_config",
        "severity": "high",
        "category": "network",
        "check": "CORS is not set to allow all origins (*) in production",
        "fix": "Set specific allowed origins or disable CORS if gateway is not accessed from browsers.",
        "command": None,
    },
    {
        "id": "auth_required",
        "severity": "critical",
        "category": "auth",
        "check": "API key authentication is required for gateway access",
        "fix": "Set apiKeyRequired: true in security config section.",
        "command": "grep -c 'apiKeyRequired' ~/.openclaw/openclaw.json 2>/dev/null",
    },
    {
        "id": "session_data_permissions",
        "severity": "high",
        "category": "data",
        "check": "Session directory has restrictive permissions (700)",
        "fix": "chmod -R 700 ~/.openclaw/agents/main/sessions/",
        "command": "stat -c '%a' ~/.openclaw/agents/main/sessions/ 2>/dev/null",
    },
    {
        "id": "log_file_permissions",
        "severity": "medium",
        "category": "data",
        "check": "Log files are not world-readable (may contain sensitive data)",
        "fix": "chmod 600 /tmp/openclaw/*.log",
        "command": "stat -c '%a' /tmp/openclaw/*.log 2>/dev/null | head -3",
    },
    {
        "id": "workspace_secrets",
        "severity": "high",
        "category": "secrets",
        "check": "Workspace files (SOUL.md, MEMORY.md) don't contain API keys or passwords",
        "fix": "Audit workspace files and remove any embedded credentials.",
        "command": "grep -ri 'password\\|secret\\|api_key\\|token' ~/.openclaw/workspace/ --include='*.md' 2>/dev/null | head -5",
    },
    {
        "id": "docker_socket",
        "severity": "high",
        "category": "system",
        "check": "Docker socket is not exposed to OpenClaw (no --privileged, no /var/run/docker.sock mount)",
        "fix": "Remove Docker socket mounts from OpenClaw container config.",
        "command": None,
    },
    {
        "id": "node_version",
        "severity": "medium",
        "category": "system",
        "check": "Node.js version is current LTS (no known CVEs)",
        "fix": "Update Node.js: `nvm install --lts`",
        "command": "node --version 2>/dev/null",
    },
    {
        "id": "npm_audit",
        "severity": "medium",
        "category": "system",
        "check": "No high/critical npm vulnerabilities in OpenClaw dependencies",
        "fix": "Run: `cd ~/.openclaw && npm audit fix`",
        "command": "cd ~/.openclaw && npm audit --json 2>/dev/null | python3 -c \"import sys,json; d=json.load(sys.stdin); print(f'High: {d.get(\"metadata\",{}).get(\"vulnerabilities\",{}).get(\"high\",0)}, Critical: {d.get(\"metadata\",{}).get(\"vulnerabilities\",{}).get(\"critical\",0)}')\" 2>/dev/null",
    },
    {
        "id": "cloudflare_tunnel_auth",
        "severity": "high",
        "category": "network",
        "check": "Cloudflare tunnel uses Access policies (not open to public)",
        "fix": "Add Cloudflare Access policy to restrict who can reach the tunnel.",
        "command": None,
    },
    {
        "id": "backup_exists",
        "severity": "medium",
        "category": "data",
        "check": "Configuration and workspace files are backed up",
        "fix": "Set up automated backup of ~/.openclaw/ to cloud storage or another drive.",
        "command": None,
    },
]


# ── Deployment Validation Checklist ───────────────────────────────

DEPLOYMENT_CHECKS = {
    "linux": [
        {"id": "os_supported", "check": "Running Linux kernel 5.x+ or WSL2", "command": "uname -r"},
        {"id": "node_installed", "check": "Node.js 18+ installed", "command": "node --version"},
        {"id": "npm_installed", "check": "npm 9+ installed", "command": "npm --version"},
        {"id": "python_installed", "check": "Python 3.10+ installed", "command": "python3 --version"},
        {"id": "docker_installed", "check": "Docker engine installed", "command": "docker --version"},
        {"id": "docker_running", "check": "Docker daemon is running", "command": "docker info > /dev/null 2>&1 && echo OK"},
        {"id": "systemd_available", "check": "systemd is available for service management", "command": "systemctl --version > /dev/null 2>&1 && echo OK"},
        {"id": "openclaw_installed", "check": "OpenClaw binary is in PATH", "command": "which openclaw 2>/dev/null || echo NOT FOUND"},
        {"id": "openclaw_dir", "check": "~/.openclaw/ directory exists", "command": "test -d ~/.openclaw && echo OK || echo MISSING"},
        {"id": "config_valid", "check": "openclaw.json is valid JSON", "command": "python3 -m json.tool ~/.openclaw/openclaw.json > /dev/null 2>&1 && echo VALID || echo INVALID"},
        {"id": "env_file", "check": "~/.openclaw_env exists", "command": "test -f ~/.openclaw_env && echo OK || echo MISSING"},
        {"id": "api_connectivity", "check": "Can reach OpenRouter API", "command": "curl -s -o /dev/null -w '%{http_code}' https://openrouter.ai/api/v1/models"},
        {"id": "dns_works", "check": "DNS resolution is working", "command": "nslookup google.com > /dev/null 2>&1 && echo OK || echo FAIL"},
        {"id": "port_free", "check": "Gateway port 18789 is available", "command": "ss -tlnp | grep -c 18789 || echo FREE"},
        {"id": "gateway_starts", "check": "Gateway service starts cleanly", "command": "systemctl --user start openclaw-gateway 2>&1"},
        {"id": "gateway_health", "check": "Gateway health endpoint responds", "command": "curl -s -o /dev/null -w '%{http_code}' http://localhost:18789/health"},
        {"id": "easyclaw_installed", "check": "EasyClaw is installed", "command": "easyclaw --version 2>/dev/null || echo NOT INSTALLED"},
        {"id": "easyclaw_doctor", "check": "EasyClaw doctor passes core checks", "command": "easyclaw doctor 2>&1 | tail -5"},
    ],
    "macos": [
        {"id": "os_supported", "check": "Running macOS 12+ (Monterey or newer)", "command": "sw_vers -productVersion"},
        {"id": "node_installed", "check": "Node.js 18+ installed", "command": "node --version"},
        {"id": "npm_installed", "check": "npm 9+ installed", "command": "npm --version"},
        {"id": "python_installed", "check": "Python 3.10+ installed", "command": "python3 --version"},
        {"id": "homebrew", "check": "Homebrew is installed", "command": "brew --version 2>/dev/null || echo NOT FOUND"},
        {"id": "openclaw_installed", "check": "OpenClaw binary is in PATH", "command": "which openclaw 2>/dev/null || echo NOT FOUND"},
        {"id": "openclaw_dir", "check": "~/.openclaw/ directory exists", "command": "test -d ~/.openclaw && echo OK || echo MISSING"},
        {"id": "config_valid", "check": "openclaw.json is valid JSON", "command": "python3 -m json.tool ~/.openclaw/openclaw.json > /dev/null 2>&1 && echo VALID || echo INVALID"},
        {"id": "env_file", "check": "~/.openclaw_env exists", "command": "test -f ~/.openclaw_env && echo OK || echo MISSING"},
        {"id": "api_connectivity", "check": "Can reach OpenRouter API", "command": "curl -s -o /dev/null -w '%{http_code}' https://openrouter.ai/api/v1/models"},
        {"id": "port_free", "check": "Gateway port 18789 is available", "command": "lsof -i :18789 > /dev/null 2>&1 && echo IN_USE || echo FREE"},
        {"id": "launchd_service", "check": "OpenClaw launchd service configured", "command": "launchctl list | grep -c openclaw 2>/dev/null || echo NOT FOUND"},
        {"id": "easyclaw_installed", "check": "EasyClaw is installed", "command": "easyclaw --version 2>/dev/null || echo NOT INSTALLED"},
    ],
    "wsl2": [
        {"id": "wsl_version", "check": "Running WSL2 (not WSL1)", "command": "wsl.exe -l -v 2>/dev/null || cat /proc/version"},
        {"id": "node_installed", "check": "Node.js 18+ installed in WSL2", "command": "node --version"},
        {"id": "python_installed", "check": "Python 3.10+ installed", "command": "python3 --version"},
        {"id": "docker_installed", "check": "Docker available in WSL2", "command": "docker --version"},
        {"id": "docker_running", "check": "Docker daemon running", "command": "docker info > /dev/null 2>&1 && echo OK"},
        {"id": "mount_rshared", "check": "Mount propagation is rshared (required for Docker bind mounts)", "command": "findmnt -n -o PROPAGATION / 2>/dev/null"},
        {"id": "wsl_conf_boot", "check": "/etc/wsl.conf has mount --make-rshared boot command", "command": "grep -c 'rshared' /etc/wsl.conf 2>/dev/null || echo MISSING"},
        {"id": "resolv_conf", "check": "DNS is properly configured (not auto-generated garbage)", "command": "cat /etc/resolv.conf | grep -v '^#' | head -3"},
        {"id": "openclaw_installed", "check": "OpenClaw binary is in PATH", "command": "which openclaw 2>/dev/null || echo NOT FOUND"},
        {"id": "openclaw_dir", "check": "~/.openclaw/ directory exists", "command": "test -d ~/.openclaw && echo OK || echo MISSING"},
        {"id": "config_valid", "check": "openclaw.json is valid JSON", "command": "python3 -m json.tool ~/.openclaw/openclaw.json > /dev/null 2>&1 && echo VALID || echo INVALID"},
        {"id": "env_file", "check": "~/.openclaw_env exists", "command": "test -f ~/.openclaw_env && echo OK || echo MISSING"},
        {"id": "api_connectivity", "check": "Can reach OpenRouter API from WSL2", "command": "curl -s -o /dev/null -w '%{http_code}' https://openrouter.ai/api/v1/models"},
        {"id": "port_free", "check": "Gateway port 18789 is available", "command": "ss -tlnp | grep -c 18789 || echo FREE"},
        {"id": "ollama_reachable", "check": "Ollama is reachable at localhost:11434 (if local model configured)", "command": "curl -s -o /dev/null -w '%{http_code}' http://localhost:11434/api/tags"},
        {"id": "windows_firewall", "check": "Windows firewall is not blocking WSL2 ports", "command": "curl -s -o /dev/null -w '%{http_code}' http://localhost:18789/health 2>/dev/null || echo NOT_REACHABLE"},
        {"id": "easyclaw_installed", "check": "EasyClaw is installed", "command": "easyclaw --version 2>/dev/null || echo NOT INSTALLED"},
    ],
}


def security_audit() -> dict:
    """Return the full security audit checklist."""
    by_severity = {"critical": [], "high": [], "medium": []}
    by_category = {}

    for check in SECURITY_CHECKS:
        sev = check["severity"]
        cat = check["category"]
        entry = {
            "id": check["id"],
            "check": check["check"],
            "fix": check["fix"],
            "command": check.get("command"),
        }
        by_severity.setdefault(sev, []).append(entry)
        by_category.setdefault(cat, []).append(entry)

    return {
        "total_checks": len(SECURITY_CHECKS),
        "by_severity": by_severity,
        "by_category": by_category,
        "severity_counts": {k: len(v) for k, v in by_severity.items()},
        "instructions": "Run each check command to verify. Fix critical issues first.",
    }


def validate_deployment(os_type: str = "linux") -> dict:
    """Return deployment validation checklist for the given OS."""
    os_type = os_type.lower().strip()

    if os_type not in DEPLOYMENT_CHECKS:
        return {
            "error": f"Unknown OS type: {os_type}",
            "available": list(DEPLOYMENT_CHECKS.keys()),
        }

    checks = DEPLOYMENT_CHECKS[os_type]
    return {
        "os_type": os_type,
        "total_checks": len(checks),
        "checks": checks,
        "instructions": "Run each command to verify. All checks should pass before going live.",
    }


# ── Gateway Troubleshooting ──────────────────────────────────────

GATEWAY_SYMPTOMS = {
    "not_starting": {
        "title": "Gateway Won't Start",
        "possible_causes": [
            {"cause": "Port already in use", "check": "ss -tlnp | grep 18789", "fix": "Kill the process using the port or change port in config"},
            {"cause": "Config file invalid", "check": "python3 -m json.tool ~/.openclaw/openclaw.json", "fix": "Fix JSON syntax errors"},
            {"cause": "Missing dependencies", "check": "cd ~/.openclaw && npm ls 2>&1 | grep ERR", "fix": "npm install"},
            {"cause": "Environment not loaded", "check": "echo $OPENROUTER_API_KEY", "fix": "source ~/.openclaw_env"},
            {"cause": "Node.js not found", "check": "which node", "fix": "Install Node.js 18+"},
        ],
    },
    "crashing": {
        "title": "Gateway Keeps Crashing",
        "possible_causes": [
            {"cause": "Heap out of memory", "check": "journalctl --user -u openclaw-gateway | grep -i 'heap\\|memory' | tail -5", "fix": "Clean sessions, clear cache, restart"},
            {"cause": "Unhandled exception", "check": "journalctl --user -u openclaw-gateway | grep -i 'error\\|fatal' | tail -10", "fix": "Check logs for specific error, apply fix"},
            {"cause": "Segmentation fault", "check": "journalctl --user -u openclaw-gateway | grep -i 'segfault\\|SIGSEGV'", "fix": "Reinstall node modules: npm rebuild"},
            {"cause": "Resource limits hit", "check": "systemctl --user status openclaw-gateway | grep -i 'limit\\|oom'", "fix": "Increase MemoryMax in systemd service"},
        ],
    },
    "slow": {
        "title": "Gateway Is Slow",
        "possible_causes": [
            {"cause": "API provider latency", "check": "curl -w '%{time_total}' https://openrouter.ai/api/v1/models", "fix": "Switch to faster model or local Ollama"},
            {"cause": "Large session context", "check": "du -sh ~/.openclaw/agents/main/sessions/", "fix": "Clean old sessions, reduce compaction threshold"},
            {"cause": "CPU throttled", "check": "cat /sys/fs/cgroup/user.slice/cpu.max 2>/dev/null", "fix": "Increase CPUQuota in systemd service"},
            {"cause": "Disk I/O bottleneck", "check": "iostat -x 1 3", "fix": "Move sessions/logs to faster storage"},
            {"cause": "Too many concurrent requests", "check": "ss -s | grep ESTAB", "fix": "Reduce maxConcurrent cron jobs, add rate limiting"},
        ],
    },
    "no_response": {
        "title": "Gateway Not Responding",
        "possible_causes": [
            {"cause": "Service not running", "check": "systemctl --user status openclaw-gateway", "fix": "systemctl --user start openclaw-gateway"},
            {"cause": "Wrong bind address", "check": "grep 'bind' ~/.openclaw/openclaw.json", "fix": "Set bind to 127.0.0.1 for local, 0.0.0.0 for remote"},
            {"cause": "Firewall blocking", "check": "sudo iptables -L -n | grep 18789", "fix": "Open port: sudo ufw allow 18789"},
            {"cause": "Process hung", "check": "ps aux | grep openclaw", "fix": "Kill and restart: systemctl --user restart openclaw-gateway"},
        ],
    },
    "502_errors": {
        "title": "502 Bad Gateway Errors",
        "possible_causes": [
            {"cause": "Backend crashed", "check": "systemctl --user status openclaw-gateway", "fix": "Restart the gateway service"},
            {"cause": "Cloudflare tunnel disconnected", "check": "systemctl status cloudflared", "fix": "Restart cloudflared"},
            {"cause": "Upstream API down", "check": "curl -s https://openrouter.ai/api/v1/models | head -1", "fix": "Wait for provider recovery or switch to fallback"},
            {"cause": "Timeout exceeded", "check": "Check Cloudflare tunnel timeout settings", "fix": "Increase timeout in cloudflared config"},
        ],
    },
    "auth_errors": {
        "title": "Authentication Errors",
        "possible_causes": [
            {"cause": "API key expired", "check": "Test key at provider dashboard", "fix": "Regenerate key, update ~/.openclaw_env"},
            {"cause": "Key not loaded", "check": "echo $OPENROUTER_API_KEY", "fix": "source ~/.openclaw_env, restart gateway"},
            {"cause": "Wrong key format", "check": "Check key prefix (sk-or- for OpenRouter)", "fix": "Verify key at provider dashboard"},
            {"cause": "Auth profile corrupted", "check": "python3 -m json.tool ~/.openclaw/agents/main/agent/auth-profiles.json", "fix": "Regenerate via OpenClaw setup"},
        ],
    },
}


def troubleshoot_gateway(symptom: str) -> dict:
    """Get troubleshooting guide for a gateway symptom."""
    symptom_lower = symptom.lower().strip().replace(" ", "_")

    # Try exact match first
    guide = GATEWAY_SYMPTOMS.get(symptom_lower)

    # Fuzzy match
    if not guide:
        for key, val in GATEWAY_SYMPTOMS.items():
            if symptom_lower in key or key in symptom_lower:
                guide = val
                break
            # Match against title
            if symptom.lower() in val["title"].lower():
                guide = val
                break

    if not guide:
        # Try keyword matching
        keywords = symptom.lower().split()
        for key, val in GATEWAY_SYMPTOMS.items():
            title_words = val["title"].lower().split()
            if any(kw in title_words or kw in key for kw in keywords):
                guide = val
                break

    if not guide:
        return {
            "matched": False,
            "message": f"No troubleshooting guide for symptom: {symptom}",
            "available_symptoms": list(GATEWAY_SYMPTOMS.keys()),
            "descriptions": {k: v["title"] for k, v in GATEWAY_SYMPTOMS.items()},
        }

    return {
        "matched": True,
        "title": guide["title"],
        "possible_causes": guide["possible_causes"],
        "general_advice": "Work through causes top to bottom. Run the check command first, then apply fix if needed.",
    }
