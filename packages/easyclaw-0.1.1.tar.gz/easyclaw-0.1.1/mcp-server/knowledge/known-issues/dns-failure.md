# DNS Resolution Failure

## Symptoms
- `EAI_AGAIN` errors in Node.js
- `ENOTFOUND` for known domains
- `getaddrinfo` failures

## Common Causes
1. **Tailscale overwrote resolv.conf** — Tailscale on WSL2 replaces DNS settings
2. **WSL2 DNS auto-generation** — Windows generates bad resolv.conf on restart
3. **Network connectivity** — WiFi/Ethernet disconnected

## Fix Steps
```bash
# Check current DNS
cat /etc/resolv.conf

# Restore known-good DNS
sudo bash -c 'cat > /etc/resolv.conf << EOF
nameserver 8.8.8.8
nameserver 1.1.1.1
nameserver 8.8.4.4
EOF'

# Verify resolution works
nslookup google.com 8.8.8.8

# Prevent WSL2 from overwriting (permanent fix)
# Add to /etc/wsl.conf:
# [network]
# generateResolvConf = false
```

## Auto-Remediation
- Test DNS with nslookup
- If failing: restore static DNS config
- If persistent: escalate to user (likely network issue)
