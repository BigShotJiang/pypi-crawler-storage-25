# Session Directory Bloat

## Symptoms
- `~/.openclaw/agents/main/sessions/` exceeds 500MB
- Many `.deleted.*` and `.lock` files accumulating
- Slow session operations, eventual OOM crash

## Common Causes
1. **Soft deletes not cleaned** — OpenClaw marks sessions as deleted but doesn't remove files
2. **Stale lock files** — Crashed processes leave behind lock files
3. **Cron sessions** — Each cron job creates a session; without cleanup they accumulate

## Fix Steps
```bash
# Check current size
du -sh ~/.openclaw/agents/main/sessions/
ls ~/.openclaw/agents/main/sessions/ | wc -l

# Remove soft-deleted files
find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' -delete

# Remove stale locks (older than 30 min)
find ~/.openclaw/agents/main/sessions/ -name '*.lock' -mmin +30 -delete

# Count remaining
ls ~/.openclaw/agents/main/sessions/ | wc -l
```

## Auto-Remediation
- Clean `.deleted.*` and stale `.lock` files automatically
- No restart required
- Schedule periodic cleanup (every 6 hours)
