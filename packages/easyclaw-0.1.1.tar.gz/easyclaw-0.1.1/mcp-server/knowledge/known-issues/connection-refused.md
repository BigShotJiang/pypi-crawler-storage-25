# ConnectionRefusedError

## Symptoms
- `ConnectionRefusedError: [Errno 111] Connect call failed`
- `ECONNREFUSED` in Node.js logs
- Upstream service (OpenRouter, Ollama, n8n) unreachable

## Common Causes
1. **Ollama container stopped** — Docker container crashed or wasn't started after WSL restart
2. **OpenRouter API outage** — Rare but happens; check status.openrouter.ai
3. **n8n service down** — VPS Docker container stopped
4. **Port not forwarded** — WSL2 networking issue after Windows update

## Fix Steps

### Ollama (localhost:11434)
```bash
# Check if Ollama is running
docker ps | grep ollama
# Restart if needed
docker start ollama
```

### OpenRouter
```bash
# Test API connectivity
curl -s -o /dev/null -w "%{http_code}" https://openrouter.ai/api/v1/models
# If 200 — it's fine, retry the failed request
# If not 200 — wait 60s and retry, or switch to local Ollama fallback
```

### n8n Webhooks
```bash
# Test from WSL2
curl -s -o /dev/null -w "%{http_code}" https://n8n.srv1071455.hstgr.cloud/healthz
```

## Auto-Remediation
- Wait 30s for transient issues to resolve
- If Ollama: restart Docker container
- If persistent: escalate to user
