# JavaScript Heap Out of Memory

## Symptoms
- `FATAL ERROR: CALL_AND_RETRY_LAST Allocation failed - JavaScript heap out of memory`
- `FATAL ERROR: Reached heap limit Allocation failed`
- Node.js process exits with code 134 (SIGABRT)

## Common Causes
1. **Session bloat** — Too many active sessions or oversized session files in `~/.openclaw/agents/main/sessions/`
2. **Compaction failure** — Auto-compaction bug in OpenClaw v2026.3.13 causes sessions to grow unbounded (223k+ tokens)
3. **Cron storm** — All cron jobs fire simultaneously after WSL2 restart, spiking memory
4. **Memory leak** — Long-running process without restart accumulates garbage

## Fix Steps

### Immediate
```bash
# Check session directory size
du -sh ~/.openclaw/agents/main/sessions/

# Clean up soft-deleted files
find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' -delete

# Clean up stale lock files
find ~/.openclaw/agents/main/sessions/ -name '*.lock' -mmin +5 -delete
```

### Prevention
```bash
# Reset cron states before restarting to prevent cron storm
cd ~/.openclaw/cron && python3 -c "
import json
with open('jobs.json') as f: jobs = json.load(f)
for j in jobs: j['lastRun'] = None
with open('jobs.json', 'w') as f: json.dump(jobs, f, indent=2)
"

# Apply compaction safeguard patch (required after every npm update)
# See OpenClaw CLAUDE.md lines 298-318
```

## Auto-Remediation
- Clear BM25 cache files
- Clean deleted session files and stale locks
- Restart OpenClaw gateway
- If recurring: escalate — likely needs compaction patch
