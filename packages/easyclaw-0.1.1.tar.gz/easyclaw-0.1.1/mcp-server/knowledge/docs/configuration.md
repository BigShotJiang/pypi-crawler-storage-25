# OpenClaw Configuration Reference

## Main Config
**Path:** `~/.openclaw/openclaw.json`

Contains model selection, gateway settings, and trusted proxies.

## Environment Variables
**Path:** `~/.openclaw_env`

Key variables:
- `OPENROUTER_API_KEY` — API key for OpenRouter model access
- `TRANSCRIPTAPI_KEY` — Transcription service API key

## Auth Profiles
**Path:** `~/.openclaw/agents/main/agent/auth-profiles.json`

Contains API tokens organized by profile. The `openrouter:default` profile holds the primary API token.

## Workspace
**Path:** `~/.openclaw/workspace/`

Core files:
- `SOUL.md` — Agent personality and behavior instructions
- `AGENTS.md` — Agent definitions
- `TOOLS.md` — Available tools configuration
- `MEMORY.md` — Persistent memory index
- `memory/facts.jsonl` — Extracted facts database
- `memory/projects/INDEX.md` — Project tracking

## Cron
**Path:** `~/.openclaw/cron/jobs.json`

Cron job definitions with schedules, last run timestamps, and session isolation settings.

## Gateway
- **Port:** 18789 (default)
- **Service:** `openclaw-gateway` (systemd user service)
- **Dashboard:** Accessible via Cloudflare tunnel
