"""EasyClaw Knowledge Database — SQLite + FTS5 full-text search.

Stores all knowledge articles, guides, troubleshooting docs, model data,
and learned solutions in a searchable SQLite database with FTS5 indexing.
"""

from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


DEFAULT_DB_PATH = Path("./data/easyclaw_knowledge.db")


class KnowledgeDB:
    """SQLite-backed knowledge base with FTS5 full-text search."""

    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or DEFAULT_DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @contextmanager
    def _conn(self):
        """Context manager for database connections."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self):
        """Create tables and FTS5 virtual table if they don't exist."""
        with self._conn() as conn:
            conn.executescript("""
                -- Main knowledge articles table
                CREATE TABLE IF NOT EXISTS articles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    slug TEXT UNIQUE NOT NULL,
                    title TEXT NOT NULL,
                    category TEXT NOT NULL,
                    subcategory TEXT DEFAULT '',
                    content TEXT NOT NULL,
                    tags TEXT DEFAULT '',
                    source TEXT DEFAULT 'builtin',
                    source_url TEXT DEFAULT '',
                    severity TEXT DEFAULT '',
                    platform TEXT DEFAULT 'all',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                -- FTS5 virtual table for full-text search
                CREATE VIRTUAL TABLE IF NOT EXISTS articles_fts USING fts5(
                    title, content, tags, category,
                    content='articles',
                    content_rowid='id',
                    tokenize='porter unicode61'
                );

                -- Triggers to keep FTS in sync
                CREATE TRIGGER IF NOT EXISTS articles_ai AFTER INSERT ON articles BEGIN
                    INSERT INTO articles_fts(rowid, title, content, tags, category)
                    VALUES (new.id, new.title, new.content, new.tags, new.category);
                END;

                CREATE TRIGGER IF NOT EXISTS articles_ad AFTER DELETE ON articles BEGIN
                    INSERT INTO articles_fts(articles_fts, rowid, title, content, tags, category)
                    VALUES ('delete', old.id, old.title, old.content, old.tags, old.category);
                END;

                CREATE TRIGGER IF NOT EXISTS articles_au AFTER UPDATE ON articles BEGIN
                    INSERT INTO articles_fts(articles_fts, rowid, title, content, tags, category)
                    VALUES ('delete', old.id, old.title, old.content, old.tags, old.category);
                    INSERT INTO articles_fts(rowid, title, content, tags, category)
                    VALUES (new.id, new.title, new.content, new.tags, new.category);
                END;

                -- Incidents table
                CREATE TABLE IF NOT EXISTS incidents (
                    id TEXT PRIMARY KEY,
                    timestamp TEXT NOT NULL,
                    error_type TEXT NOT NULL,
                    error_hash TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    details TEXT NOT NULL,
                    auto_fixed INTEGER DEFAULT 0,
                    client_token TEXT DEFAULT 'anonymous',
                    resolution TEXT DEFAULT ''
                );

                -- Model catalog
                CREATE TABLE IF NOT EXISTS models (
                    id TEXT PRIMARY KEY,
                    provider TEXT NOT NULL,
                    name TEXT NOT NULL,
                    category TEXT NOT NULL,
                    context_window INTEGER DEFAULT 0,
                    input_cost_per_mtok REAL DEFAULT 0,
                    output_cost_per_mtok REAL DEFAULT 0,
                    speed_tier TEXT DEFAULT 'medium',
                    quality_tier TEXT DEFAULT 'medium',
                    supports_tools INTEGER DEFAULT 1,
                    supports_vision INTEGER DEFAULT 0,
                    notes TEXT DEFAULT '',
                    updated_at TEXT NOT NULL
                );

                -- External source tracking (for n8n auto-updates)
                CREATE TABLE IF NOT EXISTS source_updates (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source TEXT NOT NULL,
                    query TEXT DEFAULT '',
                    last_checked TEXT NOT NULL,
                    items_found INTEGER DEFAULT 0,
                    items_added INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'success',
                    details TEXT DEFAULT ''
                );

                -- Indexes
                CREATE INDEX IF NOT EXISTS idx_articles_category ON articles(category);
                CREATE INDEX IF NOT EXISTS idx_articles_tags ON articles(tags);
                CREATE INDEX IF NOT EXISTS idx_articles_source ON articles(source);
                CREATE INDEX IF NOT EXISTS idx_incidents_type ON incidents(error_type);
                CREATE INDEX IF NOT EXISTS idx_incidents_severity ON incidents(severity);
                CREATE INDEX IF NOT EXISTS idx_models_category ON models(category);
                CREATE INDEX IF NOT EXISTS idx_models_provider ON models(provider);
            """)

    # ── Article CRUD ──────────────────────────────────────────────

    def upsert_article(
        self,
        slug: str,
        title: str,
        category: str,
        content: str,
        subcategory: str = "",
        tags: str = "",
        source: str = "builtin",
        source_url: str = "",
        severity: str = "",
        platform: str = "all",
    ) -> int:
        """Insert or update a knowledge article. Returns the article ID."""
        now = datetime.now(timezone.utc).isoformat()
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO articles
                   (slug, title, category, subcategory, content, tags, source,
                    source_url, severity, platform, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(slug) DO UPDATE SET
                     title=excluded.title, category=excluded.category,
                     subcategory=excluded.subcategory, content=excluded.content,
                     tags=excluded.tags, source=excluded.source,
                     source_url=excluded.source_url, severity=excluded.severity,
                     platform=excluded.platform, updated_at=excluded.updated_at
                """,
                (slug, title, category, subcategory, content, tags, source,
                 source_url, severity, platform, now, now),
            )
            row = conn.execute(
                "SELECT id FROM articles WHERE slug = ?", (slug,)
            ).fetchone()
            return row["id"] if row else 0

    @staticmethod
    def _sanitize_fts_query(query: str) -> str:
        """Sanitize a query string for FTS5 MATCH.

        FTS5 treats colons, parentheses, quotes, etc. as operators.
        We strip them and keep only alphanumeric words.
        """
        import re
        words = re.findall(r"[a-zA-Z0-9_]+", query)
        return " ".join(words)

    def search(self, query: str, category: str = "", limit: int = 10) -> list[dict]:
        """Full-text search across all articles."""
        safe_query = self._sanitize_fts_query(query)
        if not safe_query.strip():
            return []

        with self._conn() as conn:
            try:
                if category:
                    rows = conn.execute(
                        """SELECT a.*, rank
                           FROM articles_fts fts
                           JOIN articles a ON a.id = fts.rowid
                           WHERE articles_fts MATCH ? AND a.category = ?
                           ORDER BY rank
                           LIMIT ?""",
                        (safe_query, category, limit),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        """SELECT a.*, rank
                           FROM articles_fts fts
                           JOIN articles a ON a.id = fts.rowid
                           WHERE articles_fts MATCH ?
                           ORDER BY rank
                           LIMIT ?""",
                        (safe_query, limit),
                    ).fetchall()
                return [dict(r) for r in rows]
            except Exception:
                # FTS5 can still fail on edge cases — fall back to LIKE search
                return []

    def get_by_slug(self, slug: str) -> Optional[dict]:
        """Get a single article by slug."""
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM articles WHERE slug = ?", (slug,)
            ).fetchone()
            return dict(row) if row else None

    def get_by_category(self, category: str, limit: int = 50) -> list[dict]:
        """Get all articles in a category."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM articles WHERE category = ? ORDER BY title LIMIT ?",
                (category, limit),
            ).fetchall()
            return [dict(r) for r in rows]

    def list_categories(self) -> list[dict]:
        """List all categories with article counts."""
        with self._conn() as conn:
            rows = conn.execute(
                """SELECT category, COUNT(*) as count
                   FROM articles GROUP BY category ORDER BY count DESC"""
            ).fetchall()
            return [dict(r) for r in rows]

    # ── Incidents ─────────────────────────────────────────────────

    def record_incident(
        self,
        error_type: str,
        error_hash: str,
        severity: str,
        details: str,
        auto_fixed: bool = False,
        client_token: str = "anonymous",
    ) -> str:
        """Record an incident. Returns the incident ID."""
        incident_id = f"inc-{int(time.time())}-{error_hash[:6]}"
        now = datetime.now(timezone.utc).isoformat()
        token_masked = client_token[:8] + "..." if client_token else "anonymous"
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO incidents
                   (id, timestamp, error_type, error_hash, severity, details, auto_fixed, client_token)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (incident_id, now, error_type, error_hash, severity,
                 details[:4000], int(auto_fixed), token_masked),
            )
        return incident_id

    def get_incident_stats(self) -> dict:
        """Get incident statistics."""
        with self._conn() as conn:
            total = conn.execute("SELECT COUNT(*) FROM incidents").fetchone()[0]
            by_type = conn.execute(
                "SELECT error_type, COUNT(*) as cnt FROM incidents GROUP BY error_type ORDER BY cnt DESC LIMIT 10"
            ).fetchall()
            by_severity = conn.execute(
                "SELECT severity, COUNT(*) as cnt FROM incidents GROUP BY severity"
            ).fetchall()
            auto_fixed = conn.execute(
                "SELECT COUNT(*) FROM incidents WHERE auto_fixed = 1"
            ).fetchone()[0]
            return {
                "total": total,
                "auto_fixed": auto_fixed,
                "auto_fix_rate": round(auto_fixed / max(total, 1) * 100, 1),
                "by_type": [dict(r) for r in by_type],
                "by_severity": [dict(r) for r in by_severity],
            }

    # ── Models ────────────────────────────────────────────────────

    def upsert_model(self, model_data: dict) -> None:
        """Insert or update a model entry."""
        now = datetime.now(timezone.utc).isoformat()
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO models
                   (id, provider, name, category, context_window,
                    input_cost_per_mtok, output_cost_per_mtok,
                    speed_tier, quality_tier, supports_tools, supports_vision,
                    notes, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(id) DO UPDATE SET
                     provider=excluded.provider, name=excluded.name,
                     category=excluded.category, context_window=excluded.context_window,
                     input_cost_per_mtok=excluded.input_cost_per_mtok,
                     output_cost_per_mtok=excluded.output_cost_per_mtok,
                     speed_tier=excluded.speed_tier, quality_tier=excluded.quality_tier,
                     supports_tools=excluded.supports_tools,
                     supports_vision=excluded.supports_vision,
                     notes=excluded.notes, updated_at=excluded.updated_at
                """,
                (
                    model_data["id"], model_data["provider"], model_data["name"],
                    model_data["category"], model_data.get("context_window", 0),
                    model_data.get("input_cost_per_mtok", 0),
                    model_data.get("output_cost_per_mtok", 0),
                    model_data.get("speed_tier", "medium"),
                    model_data.get("quality_tier", "medium"),
                    int(model_data.get("supports_tools", True)),
                    int(model_data.get("supports_vision", False)),
                    model_data.get("notes", ""), now,
                ),
            )

    def get_models_by_category(self, category: str) -> list[dict]:
        """Get models filtered by use-case category."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM models WHERE category = ? ORDER BY quality_tier DESC, name",
                (category,),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_all_models(self) -> list[dict]:
        """Get all models."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM models ORDER BY provider, name"
            ).fetchall()
            return [dict(r) for r in rows]

    def search_models(self, query: str) -> list[dict]:
        """Search models by name or provider."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM models WHERE name LIKE ? OR provider LIKE ? OR notes LIKE ?",
                (f"%{query}%", f"%{query}%", f"%{query}%"),
            ).fetchall()
            return [dict(r) for r in rows]

    # ── Source tracking ───────────────────────────────────────────

    def record_source_update(
        self, source: str, query: str = "", items_found: int = 0,
        items_added: int = 0, status: str = "success", details: str = "",
    ) -> None:
        """Record an external source update check."""
        now = datetime.now(timezone.utc).isoformat()
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO source_updates
                   (source, query, last_checked, items_found, items_added, status, details)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (source, query, now, items_found, items_added, status, details),
            )

    def get_source_status(self) -> list[dict]:
        """Get the latest update status for each source."""
        with self._conn() as conn:
            rows = conn.execute(
                """SELECT source, MAX(last_checked) as last_checked,
                          SUM(items_added) as total_added
                   FROM source_updates
                   GROUP BY source
                   ORDER BY last_checked DESC"""
            ).fetchall()
            return [dict(r) for r in rows]

    # ── Stats ─────────────────────────────────────────────────────

    def get_stats(self) -> dict:
        """Get overall database statistics."""
        with self._conn() as conn:
            articles = conn.execute("SELECT COUNT(*) FROM articles").fetchone()[0]
            incidents = conn.execute("SELECT COUNT(*) FROM incidents").fetchone()[0]
            models = conn.execute("SELECT COUNT(*) FROM models").fetchone()[0]
            categories = self.list_categories()
            return {
                "total_articles": articles,
                "total_incidents": incidents,
                "total_models": models,
                "categories": categories,
            }
