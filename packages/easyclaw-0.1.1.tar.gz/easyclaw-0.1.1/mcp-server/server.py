"""EasyClaw MCP Server v2 — comprehensive knowledge, diagnostics, and operations hub.

Runs on Hostinger VPS (port 8002). Exposes 17 tools via FastMCP.

Tools:
─── Knowledge ──────────────────────────────────────────────
  search_knowledge       Full-text search across the knowledge base
  get_full_guide         Retrieve a complete guide by topic slug
  learn_solution         Write new knowledge entries to the database
─── Models & Cost ──────────────────────────────────────────
  get_model_recommendation   AI model selection guidance with pricing
  estimate_cost              Monthly cost estimation with comparison tables
─── Configuration ──────────────────────────────────────────
  validate_config        Configuration checklist covering all config domains
  generate_config        Complete openclaw.json generation from templates
  get_foreman_config     Full validated config generation (config + systemd)
─── Diagnostics ────────────────────────────────────────────
  diagnose_issue         Pattern-matched error diagnosis with 25+ patterns
  security_audit         Security checklist with severity levels and fix commands
  validate_deployment    Post-deployment health verification checklist
  troubleshoot_gateway   Symptom-based gateway troubleshooting
─── Skills & Search ────────────────────────────────────────
  recommend_skills       Skill pack recommendations by use case
  search_web             Web search via private SearXNG instance
─── Operations ─────────────────────────────────────────────
  check_for_updates      Version info and available patches
  report_incident        Accept incident reports from clients
  validate_subscription  Check if a client token is valid
"""

from __future__ import annotations

import json
import os
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from db import KnowledgeDB
from models_catalog import MODELS, get_recommendation, estimate_monthly_cost
from error_patterns import diagnose
from config_templates import (
    generate_config as _generate_config,
    validate_config as _validate_config,
    generate_foreman_config as _generate_foreman_config,
)
from checklists import (
    security_audit as _security_audit,
    validate_deployment as _validate_deployment,
    troubleshoot_gateway as _troubleshoot_gateway,
)

# ── Configuration ─────────────────────────────────────────────────

DB_PATH = Path(os.environ.get("EASYCLAW_DB_PATH", "./data/easyclaw_knowledge.db"))
AUTH_TOKENS_FILE = Path(os.environ.get("EASYCLAW_TOKENS_FILE", "./tokens.json"))
SEARXNG_URL = os.environ.get("EASYCLAW_SEARXNG_URL", "http://localhost:8181")
CURRENT_VERSION = "2.0.0"

# ── Initialize database ──────────────────────────────────────────

db = KnowledgeDB(DB_PATH)

# Auto-seed on first run
stats = db.get_stats()
if stats["total_articles"] == 0:
    from seed_knowledge import seed_all
    counts = seed_all(db)
    print(f"[init] Seeded database: {counts['articles']} articles, {counts['models']} models")

# ── Server setup ──────────────────────────────────────────────────

mcp = FastMCP("EasyClaw Knowledge Hub")

# ── Auth helpers ──────────────────────────────────────────────────

def _load_tokens() -> dict:
    if not AUTH_TOKENS_FILE.is_file():
        return {}
    try:
        return json.loads(AUTH_TOKENS_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _is_valid_token(token: str) -> bool:
    tokens = _load_tokens()
    entry = tokens.get(token)
    if not entry:
        return False
    expires = entry.get("expires")
    if expires and datetime.fromisoformat(expires) < datetime.now(timezone.utc):
        return False
    return entry.get("active", False)


# ══════════════════════════════════════════════════════════════════
# ── KNOWLEDGE TOOLS ──────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════


@mcp.tool()
def search_knowledge(query: str, category: str = "", limit: int = 10) -> str:
    """Full-text search across the entire EasyClaw/OpenClaw knowledge base.

    Searches article titles, content, and tags using SQLite FTS5 (Porter stemming).
    Returns ranked results with snippets.

    Args:
        query: Search terms (e.g., "connection refused", "ollama setup", "cron storm").
        category: Optional category filter (troubleshooting, documentation, guides, installation, security, skills).
        limit: Maximum results to return (default 10).

    Returns:
        JSON with matching articles ranked by relevance.
    """
    results = db.search(query, category=category, limit=limit)

    if not results:
        # Fallback: try substring search on titles
        all_articles = []
        for cat in db.list_categories():
            all_articles.extend(db.get_by_category(cat["category"]))
        query_lower = query.lower()
        results = [
            a for a in all_articles
            if query_lower in a.get("title", "").lower()
            or query_lower in a.get("tags", "").lower()
        ][:limit]

    if not results:
        categories = db.list_categories()
        return json.dumps({
            "found": False,
            "query": query,
            "message": f"No results for: {query}",
            "available_categories": [c["category"] for c in categories],
            "suggestion": "Try broader search terms or browse by category.",
        })

    return json.dumps({
        "found": True,
        "query": query,
        "count": len(results),
        "results": [
            {
                "slug": r.get("slug", ""),
                "title": r.get("title", ""),
                "category": r.get("category", ""),
                "tags": r.get("tags", ""),
                "snippet": r.get("content", "")[:300] + "..." if len(r.get("content", "")) > 300 else r.get("content", ""),
                "source": r.get("source", ""),
            }
            for r in results
        ],
    })


@mcp.tool()
def get_full_guide(topic: str) -> str:
    """Retrieve a complete guide or article by topic slug or title search.

    Use search_knowledge first to find the slug, then this tool to get full content.

    Args:
        topic: Article slug (e.g., "guide-ollama-setup") or topic keyword to search.

    Returns:
        JSON with the full article content.
    """
    # Try exact slug match first
    article = db.get_by_slug(topic)
    if article:
        return json.dumps({
            "found": True,
            "title": article["title"],
            "category": article["category"],
            "content": article["content"],
            "tags": article.get("tags", ""),
            "source": article.get("source", ""),
            "updated_at": article.get("updated_at", ""),
        })

    # Try search
    results = db.search(topic, limit=1)
    if results:
        article = results[0]
        return json.dumps({
            "found": True,
            "title": article["title"],
            "category": article["category"],
            "content": article["content"],
            "tags": article.get("tags", ""),
            "source": article.get("source", ""),
            "note": f"Matched via search (slug: {article.get('slug', '')})",
        })

    return json.dumps({
        "found": False,
        "topic": topic,
        "message": f"No guide found for: {topic}",
        "suggestion": "Use search_knowledge to find available guides.",
    })


@mcp.tool()
def learn_solution(topic: str, title: str, solution: str, category: str = "community", tags: str = "", source: str = "user-submitted", source_url: str = "") -> str:
    """Write a new knowledge entry to the database.

    Used to add new solutions, guides, or troubleshooting articles discovered
    from external sources or user experience. Also used by the n8n auto-update
    workflow to ingest content from GitHub, HuggingFace, arXiv, Reddit, etc.

    Args:
        topic: URL-friendly slug (e.g., "fix-ollama-cuda-error").
        title: Human-readable title.
        solution: Full content in markdown format.
        category: Category (troubleshooting, guides, documentation, community, research).
        tags: Comma-separated tags.
        source: Where this knowledge came from (user-submitted, github, huggingface, arxiv, reddit, clawhub, n8n-auto).
        source_url: URL of the original source.

    Returns:
        JSON confirmation with the article ID.
    """
    article_id = db.upsert_article(
        slug=topic,
        title=title,
        category=category,
        content=solution,
        tags=tags,
        source=source,
        source_url=source_url,
    )

    return json.dumps({
        "success": True,
        "article_id": article_id,
        "slug": topic,
        "message": f"Knowledge entry '{title}' saved successfully.",
    })


# ══════════════════════════════════════════════════════════════════
# ── MODEL & COST TOOLS ───────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════


@mcp.tool()
def get_model_recommendation(use_case: str) -> str:
    """AI model selection guidance with pricing for a specific use case.

    Provides recommended models, budget alternatives, and local options
    with pricing and capability comparison.

    Args:
        use_case: What you'll use the model for. Options: coding, general, fast, cheap, reasoning, vision, local.

    Returns:
        JSON with recommended models, budget alternatives, and local options with pricing.
    """
    result = get_recommendation(use_case)
    return json.dumps(result)


@mcp.tool()
def estimate_cost(model: str, daily_messages: int, avg_input_tokens: int = 2000, avg_output_tokens: int = 1000) -> str:
    """Estimate monthly API cost for a model given usage patterns.

    Calculates projected monthly spend with comparison table across models.

    Args:
        model: Model ID (e.g., "anthropic/claude-sonnet-4-6") or partial name (e.g., "sonnet").
        daily_messages: Average number of messages per day.
        avg_input_tokens: Average input tokens per message (default 2000).
        avg_output_tokens: Average output tokens per message (default 1000).

    Returns:
        JSON with cost breakdown and comparison table.
    """
    result = estimate_monthly_cost(model, daily_messages, avg_input_tokens, avg_output_tokens)
    return json.dumps(result)


# ══════════════════════════════════════════════════════════════════
# ── CONFIGURATION TOOLS ──────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════


@mcp.tool()
def validate_config() -> str:
    """Configuration validation checklist covering all config domains.

    Returns a comprehensive checklist of 20 config validation checks across
    config, auth, model, gateway, sessions, workspace, cron, system, network,
    and logging domains. Each check includes severity and fix instructions.

    Returns:
        JSON with validation checklist organized by domain and severity.
    """
    result = _validate_config()
    return json.dumps(result)


@mcp.tool()
def generate_config(template: str) -> str:
    """Generate a complete openclaw.json configuration from a template.

    Templates are pre-built configurations optimized for specific use cases.

    Args:
        template: Template name. Options: developer, business, production, budget, local, hybrid, automation.

    Returns:
        JSON with the complete config, environment vars, install instructions, and cost estimate.
    """
    result = _generate_config(template)
    return json.dumps(result, indent=2)


@mcp.tool()
def get_foreman_config(model: str = "anthropic/claude-sonnet-4-6", channel: str = "stable", bind: str = "127.0.0.1") -> str:
    """Generate full validated gateway configuration including systemd service file.

    Produces a complete deployment package: openclaw.json + systemd unit file +
    installation commands.

    Args:
        model: Model ID (e.g., "anthropic/claude-sonnet-4-6", "ollama/glm-4.7-flash").
        channel: Update channel (stable, beta, nightly).
        bind: Bind address (127.0.0.1 for local, 0.0.0.0 for remote behind proxy).

    Returns:
        JSON with config, systemd unit, and install commands.
    """
    result = _generate_foreman_config(model, channel, bind)
    return json.dumps(result, indent=2)


# ══════════════════════════════════════════════════════════════════
# ── DIAGNOSTIC TOOLS ─────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════


@mcp.tool()
def diagnose_issue(error_text: str, context: str = "") -> str:
    """Pattern-matched error diagnosis with 25+ built-in error patterns.

    Matches error text against known patterns across categories: network,
    memory, api, process, sessions, config, gateway, cron, docker, permissions.
    Returns diagnosis, likely causes, and fix steps.

    Args:
        error_text: The error message or log line to diagnose.
        context: Optional additional context (e.g., what was happening when the error occurred).

    Returns:
        JSON with matched patterns, diagnoses, causes, and fix steps.
    """
    result = diagnose(error_text, context)

    # Also search knowledge base for additional context
    # Sanitize for FTS5: extract meaningful words only
    import re as _re
    safe_query = " ".join(_re.findall(r"[a-zA-Z_]{3,}", error_text))[:200]
    kb_results = db.search(safe_query, category="troubleshooting", limit=3) if safe_query.strip() else []
    if kb_results:
        result["related_guides"] = [
            {"slug": r.get("slug", ""), "title": r.get("title", "")}
            for r in kb_results
        ]

    return json.dumps(result)


@mcp.tool()
def security_audit() -> str:
    """Security checklist with severity levels and fix commands.

    Returns a comprehensive security audit covering secrets, network, auth,
    data, and system categories. Each check includes a verification command
    and fix instructions.

    Returns:
        JSON with security checks organized by severity and category.
    """
    result = _security_audit()
    return json.dumps(result)


@mcp.tool()
def validate_deployment(os_type: str = "linux") -> str:
    """Post-deployment health verification checklist.

    Platform-specific deployment validation with commands to run.

    Args:
        os_type: Operating system type. Options: linux, macos, wsl2.

    Returns:
        JSON with ordered verification checks and commands.
    """
    result = _validate_deployment(os_type)
    return json.dumps(result)


@mcp.tool()
def troubleshoot_gateway(symptom: str) -> str:
    """Symptom-based gateway troubleshooting guide.

    Given a symptom, returns possible causes with diagnostic commands and fixes.

    Args:
        symptom: What's happening. Options: not_starting, crashing, slow, no_response, 502_errors, auth_errors.

    Returns:
        JSON with possible causes, check commands, and fixes.
    """
    result = _troubleshoot_gateway(symptom)
    return json.dumps(result)


# ══════════════════════════════════════════════════════════════════
# ── SKILLS & SEARCH TOOLS ────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════


@mcp.tool()
def recommend_skills(use_case: str) -> str:
    """Skill pack recommendations by use case.

    Returns recommended skill configurations for different user types.

    Args:
        use_case: User type or use case. Options: developer, business, automation, research, creative, devops.

    Returns:
        JSON with recommended skills, configuration, and model suggestions.
    """
    # Search knowledge base for skill articles
    results = db.search(f"skills {use_case}", category="skills", limit=3)

    if results:
        return json.dumps({
            "use_case": use_case,
            "found": True,
            "recommendations": [
                {
                    "slug": r.get("slug", ""),
                    "title": r.get("title", ""),
                    "content": r.get("content", ""),
                }
                for r in results
            ],
        })

    # Fallback — generic recommendations
    generic = {
        "developer": ["code-review", "git-workflow", "testing", "docs", "refactor", "debug"],
        "business": ["meeting-summarizer", "email-drafter", "data-analyst", "research", "docs"],
        "automation": ["web-monitor", "report-gen", "notifications", "data-pipeline", "scheduler"],
        "research": ["deep-research", "paper-analyzer", "fact-checker", "knowledge-graph"],
        "creative": ["writing-assistant", "brainstorm", "content-gen", "social-media"],
        "devops": ["system-monitor", "incident-response", "log-analyzer", "deployment", "security-scan"],
    }

    skills = generic.get(use_case.lower(), [])
    if not skills:
        return json.dumps({
            "use_case": use_case,
            "error": f"Unknown use case. Available: {', '.join(generic.keys())}",
        })

    return json.dumps({
        "use_case": use_case,
        "recommended_skills": skills,
        "note": "Search the knowledge base for detailed skill configuration guides.",
    })


@mcp.tool()
def search_web(query: str, engines: str = "google,bing,duckduckgo") -> str:
    """Web search via private SearXNG instance.

    Searches the web using the self-hosted SearXNG metasearch engine.
    Returns results from multiple search engines.

    Args:
        query: Search query string.
        engines: Comma-separated search engines to use (default: google,bing,duckduckgo).

    Returns:
        JSON with search results from SearXNG.
    """
    params = urllib.parse.urlencode({
        "q": query,
        "format": "json",
        "engines": engines,
    })
    url = f"{SEARXNG_URL}/search?{params}"

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "EasyClaw-MCP/2.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode())

        results = data.get("results", [])[:10]
        return json.dumps({
            "query": query,
            "engines": engines,
            "count": len(results),
            "results": [
                {
                    "title": r.get("title", ""),
                    "url": r.get("url", ""),
                    "content": r.get("content", "")[:300],
                    "engine": r.get("engine", ""),
                }
                for r in results
            ],
        })
    except urllib.error.URLError as e:
        return json.dumps({
            "error": True,
            "message": f"SearXNG search failed: {e}",
            "suggestion": "Ensure SearXNG is running at the configured URL.",
            "searxng_url": SEARXNG_URL,
        })
    except Exception as e:
        return json.dumps({
            "error": True,
            "message": f"Search failed: {e}",
        })


# ══════════════════════════════════════════════════════════════════
# ── OPERATIONS TOOLS ─────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════


@mcp.tool()
def check_for_updates(current_version: str = "") -> str:
    """Check if updates or hotfixes are available.

    Args:
        current_version: The client's current EasyClaw version (e.g., "0.1.0").

    Returns:
        JSON with update availability, version info, and any hotfixes.
    """
    # Check knowledge base for hotfix announcements
    hotfixes = db.search("hotfix active", category="hotfixes", limit=5)

    update_available = current_version and current_version != CURRENT_VERSION

    # Get source update status
    source_status = db.get_source_status()

    return json.dumps({
        "current_server_version": CURRENT_VERSION,
        "client_version": current_version,
        "update_available": update_available,
        "hotfixes": [
            {"slug": h.get("slug", ""), "title": h.get("title", ""), "content": h.get("content", "")[:500]}
            for h in hotfixes
        ],
        "hotfix_count": len(hotfixes),
        "knowledge_sources": source_status,
        "db_stats": db.get_stats(),
    })


@mcp.tool()
def report_incident(
    error_type: str,
    error_hash: str,
    severity: str,
    details: str,
    auto_fixed: bool = False,
    client_token: str = "",
) -> str:
    """Report an incident from an EasyClaw client for central tracking.

    Args:
        error_type: The classified error type (e.g., "connection_refused").
        error_hash: The error's dedup hash from the classifier.
        severity: Event severity (INFO, WARNING, CRITICAL).
        details: Error details including the log line and context.
        auto_fixed: Whether EasyClaw auto-remediated this issue.
        client_token: Client subscription token.

    Returns:
        JSON acknowledgment with incident ID and stats.
    """
    incident_id = db.record_incident(
        error_type=error_type,
        error_hash=error_hash,
        severity=severity,
        details=details,
        auto_fixed=auto_fixed,
        client_token=client_token,
    )

    incident_stats = db.get_incident_stats()

    return json.dumps({
        "acknowledged": True,
        "incident_id": incident_id,
        "message": "Incident recorded. Thank you for reporting.",
        "stats": incident_stats,
    })


@mcp.tool()
def validate_subscription(client_token: str) -> str:
    """Validate a client's subscription token.

    Args:
        client_token: The subscription token to validate.

    Returns:
        JSON with subscription status, tier, features, and expiration.
    """
    tokens = _load_tokens()
    entry = tokens.get(client_token)

    if not entry:
        return json.dumps({
            "valid": False,
            "message": "Token not found. Visit easyclaw.help to subscribe.",
        })

    if not entry.get("active", False):
        return json.dumps({
            "valid": False,
            "message": "Subscription is inactive. Renew at easyclaw.help.",
        })

    expires = entry.get("expires")
    if expires and datetime.fromisoformat(expires) < datetime.now(timezone.utc):
        return json.dumps({
            "valid": False,
            "message": "Subscription has expired. Renew at easyclaw.help.",
        })

    return json.dumps({
        "valid": True,
        "tier": entry.get("tier", "standard"),
        "expires": expires,
        "features": entry.get("features", ["detection", "healing", "updates"]),
        "owner": entry.get("owner", ""),
    })


# ══════════════════════════════════════════════════════════════════
# ── HTTP REST API (for EasyClaw client) ──────────────────────────
# ══════════════════════════════════════════════════════════════════

import inspect
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

# Map tool names → functions for HTTP dispatch
TOOL_MAP = {
    "search_knowledge": search_knowledge,
    "get_full_guide": get_full_guide,
    "learn_solution": learn_solution,
    "get_model_recommendation": get_model_recommendation,
    "estimate_cost": estimate_cost,
    "validate_config": validate_config,
    "generate_config": generate_config,
    "get_foreman_config": get_foreman_config,
    "diagnose_issue": diagnose_issue,
    "security_audit": security_audit,
    "validate_deployment": validate_deployment,
    "troubleshoot_gateway": troubleshoot_gateway,
    "recommend_skills": recommend_skills,
    "search_web": search_web,
    "check_for_updates": check_for_updates,
    "report_incident": report_incident,
    "validate_subscription": validate_subscription,
}

# Cache function signatures for parameter filtering
_TOOL_PARAMS = {
    name: set(inspect.signature(func).parameters.keys())
    for name, func in TOOL_MAP.items()
}


class _Handler(BaseHTTPRequestHandler):
    """Handles /call-tool POST and /health GET for EasyClaw clients."""

    def do_POST(self):
        if self.path != "/call-tool":
            self._send_json(404, {"error": f"Not found: {self.path}"})
            return

        try:
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length)) if length else {}
        except (json.JSONDecodeError, ValueError) as e:
            self._send_json(400, {"error": f"Invalid JSON: {e}"})
            return

        params = body.get("params", {})
        tool_name = params.get("name", "")
        arguments = dict(params.get("arguments", {}))

        func = TOOL_MAP.get(tool_name)
        if not func:
            self._send_json(404, {"error": f"Unknown tool: {tool_name}", "available": list(TOOL_MAP.keys())})
            return

        # Filter arguments to only those the function accepts
        valid_params = _TOOL_PARAMS[tool_name]
        filtered_args = {k: v for k, v in arguments.items() if k in valid_params}

        try:
            result = func(**filtered_args)
            # Wrap in MCP-compatible response format
            self._send_json(200, {"content": [{"type": "text", "text": result}]})
        except Exception as e:
            self._send_json(500, {"error": f"Tool execution failed: {e}"})

    def do_GET(self):
        if self.path == "/health":
            stats = db.get_stats()
            self._send_json(200, {
                "status": "ok",
                "version": CURRENT_VERSION,
                "tools": len(TOOL_MAP),
                "articles": stats["total_articles"],
                "models": stats["total_models"],
                "incidents": stats["total_incidents"],
            })
        else:
            self._send_json(404, {"error": f"Not found: {self.path}"})

    def _send_json(self, code: int, data: dict):
        body = json.dumps(data).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        # Quieter logging — only errors
        if args and isinstance(args[0], str) and args[0].startswith("2"):
            return  # suppress 2xx logs
        print(f"[http] {fmt % args}")


class _ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


# ── Entry point ───────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("EASYCLAW_PORT", "8002"))
    print(f"EasyClaw Knowledge Hub v{CURRENT_VERSION}")
    print(f"Database: {DB_PATH}")
    print(f"SearXNG: {SEARXNG_URL}")
    print(f"Tools: {len(TOOL_MAP)}")
    print(f"Listening on 0.0.0.0:{port}")

    server = _ThreadedHTTPServer(("0.0.0.0", port), _Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        server.shutdown()
