"""Seed the EasyClaw knowledge database with comprehensive content.

Run once on first startup or with --reseed flag to rebuild.
Imports existing markdown files + adds comprehensive built-in knowledge.
"""

from __future__ import annotations

import sys
from pathlib import Path

from db import KnowledgeDB
from models_catalog import MODELS


def seed_all(db: KnowledgeDB) -> dict:
    """Seed all knowledge into the database. Returns counts."""
    counts = {"articles": 0, "models": 0}

    # ── Import existing markdown knowledge files ──────────────────
    knowledge_dir = Path(__file__).parent / "knowledge"
    if knowledge_dir.is_dir():
        for md_file in knowledge_dir.rglob("*.md"):
            rel = md_file.relative_to(knowledge_dir)
            parts = rel.parts
            category = parts[0] if len(parts) > 1 else "general"
            # Map directory names to categories
            cat_map = {"known-issues": "troubleshooting", "docs": "documentation"}
            category = cat_map.get(category, category)
            slug = f"legacy-{md_file.stem}"
            content = md_file.read_text(encoding="utf-8")
            db.upsert_article(
                slug=slug,
                title=md_file.stem.replace("-", " ").title(),
                category=category,
                content=content,
                source="builtin-legacy",
                tags=md_file.stem.replace("-", ","),
            )
            counts["articles"] += 1

    # ── Comprehensive knowledge articles ──────────────────────────

    articles = [
        # ── Installation & Setup ──────────────────────────────────
        {
            "slug": "install-linux",
            "title": "Installing OpenClaw on Linux",
            "category": "installation",
            "tags": "install,linux,ubuntu,debian,setup",
            "content": """# Installing OpenClaw on Linux

## Prerequisites
- Node.js 18+ (LTS recommended)
- npm 9+
- Python 3.10+ (for EasyClaw)
- systemd (for service management)

## Quick Install
```bash
# Install Node.js via nvm (recommended)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install --lts

# Install OpenClaw
npm install -g openclaw

# Verify installation
openclaw --version
```

## Post-Install Setup
```bash
# Initialize OpenClaw
openclaw init

# Create environment file
cat > ~/.openclaw_env << 'EOF'
export OPENROUTER_API_KEY="sk-or-your-key-here"
EOF
chmod 600 ~/.openclaw_env
echo 'source ~/.openclaw_env' >> ~/.bashrc

# Start the gateway
openclaw gateway start

# Set up systemd service for auto-start
openclaw service install
systemctl --user enable openclaw-gateway
```

## Verify
```bash
curl http://localhost:18789/health
# Should return: {"status": "ok"}
```
""",
        },
        {
            "slug": "install-wsl2",
            "title": "Installing OpenClaw on WSL2",
            "category": "installation",
            "tags": "install,wsl2,windows,setup",
            "content": """# Installing OpenClaw on WSL2

## Prerequisites
- Windows 10/11 with WSL2 enabled
- Ubuntu 22.04+ in WSL2
- Docker Desktop (optional, for containerized services)

## WSL2-Specific Setup
```bash
# Fix mount propagation (required for Docker bind mounts)
sudo bash -c 'cat >> /etc/wsl.conf << EOF
[boot]
command="mount --make-rshared /"
EOF'

# Fix DNS (prevents Tailscale/WSL2 DNS conflicts)
sudo bash -c 'cat > /etc/resolv.conf << EOF
nameserver 8.8.8.8
nameserver 1.1.1.1
EOF'
sudo bash -c 'cat >> /etc/wsl.conf << EOF
[network]
generateResolvConf = false
EOF'
```

## Install OpenClaw
```bash
# Install Node.js
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install --lts

# Install OpenClaw
npm install -g openclaw
openclaw init

# Create env file
cat > ~/.openclaw_env << 'EOF'
export OPENROUTER_API_KEY="sk-or-your-key-here"
EOF
chmod 600 ~/.openclaw_env
source ~/.openclaw_env

# Start gateway
openclaw gateway start
```

## Docker Services in WSL2
```bash
# Start Docker Desktop, then in WSL2:
docker info  # Verify Docker works

# Ollama for local models
docker run -d --gpus all -v ollama:/root/.ollama -p 11434:11434 --name ollama ollama/ollama
docker exec -it ollama ollama pull glm-4.7-flash:q4_K_M
```

## Common WSL2 Issues
- **DNS breaks after restart**: Apply the resolv.conf fix above permanently
- **Docker mount errors**: Apply the rshared mount fix above
- **Port conflicts**: WSL2 shares ports with Windows — check both sides
- **Clock skew**: `sudo ntpdate -s time.nist.gov` fixes SSL errors from clock drift
""",
        },
        {
            "slug": "install-macos",
            "title": "Installing OpenClaw on macOS",
            "category": "installation",
            "tags": "install,macos,mac,setup",
            "content": """# Installing OpenClaw on macOS

## Prerequisites
- macOS 12+ (Monterey or newer)
- Homebrew
- Node.js 18+

## Install
```bash
# Install Homebrew (if not already)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Node.js
brew install node@20

# Install OpenClaw
npm install -g openclaw
openclaw init

# Environment
cat > ~/.openclaw_env << 'EOF'
export OPENROUTER_API_KEY="sk-or-your-key-here"
EOF
chmod 600 ~/.openclaw_env
echo 'source ~/.openclaw_env' >> ~/.zshrc

# Start
source ~/.openclaw_env
openclaw gateway start
```

## launchd Service (auto-start on login)
```bash
openclaw service install  # Creates launchd plist
launchctl load ~/Library/LaunchAgents/com.openclaw.gateway.plist
```

## Local Models with Ollama
```bash
brew install ollama
ollama serve &
ollama pull glm-4.7-flash:q4_K_M
```
""",
        },
        {
            "slug": "install-docker",
            "title": "Running OpenClaw in Docker",
            "category": "installation",
            "tags": "install,docker,container,compose",
            "content": """# Running OpenClaw in Docker

## Docker Compose
```yaml
version: '3.8'
services:
  openclaw:
    image: openclaw/openclaw:latest
    ports:
      - "18789:18789"
    volumes:
      - openclaw-data:/root/.openclaw
      - openclaw-workspace:/root/.openclaw/workspace
    environment:
      - OPENROUTER_API_KEY=${OPENROUTER_API_KEY}
      - NODE_ENV=production
    restart: unless-stopped
    mem_limit: 1g
    cpus: 0.8

  easyclaw:
    image: easyclaw/easyclaw:latest
    volumes:
      - openclaw-data:/root/.openclaw:ro
      - easyclaw-data:/root/.easyclaw
      - /tmp/openclaw:/tmp/openclaw:ro
    environment:
      - EASYCLAW_MCP_ENDPOINT=http://mcp:8002
      - EASYCLAW_MCP_TOKEN=${EASYCLAW_TOKEN}
    depends_on:
      - openclaw
    restart: unless-stopped
    mem_limit: 256m
    cpus: 0.1

volumes:
  openclaw-data:
  openclaw-workspace:
  easyclaw-data:
```

## Run
```bash
# Create .env file
echo "OPENROUTER_API_KEY=sk-or-your-key" > .env
echo "EASYCLAW_TOKEN=ec_your_token" >> .env

docker compose up -d
docker compose logs -f
```
""",
        },
        # ── Configuration Guides ──────────────────────────────────
        {
            "slug": "config-reference",
            "title": "OpenClaw Configuration Reference",
            "category": "documentation",
            "tags": "config,configuration,openclaw.json,settings",
            "content": """# OpenClaw Configuration Reference

## Config File Location
`~/.openclaw/openclaw.json`

## Full Schema

### model
| Field | Type | Default | Description |
|-------|------|---------|-------------|
| provider | string | "openrouter" | Model provider: openrouter, ollama, anthropic, openai |
| model | string | "anthropic/claude-sonnet-4-6" | Model identifier |
| temperature | float | 0.7 | Response randomness (0.0-1.0) |
| maxTokens | int | 8192 | Maximum output tokens per response |
| baseUrl | string | provider default | Custom API base URL (for Ollama: http://localhost:11434) |

### gateway
| Field | Type | Default | Description |
|-------|------|---------|-------------|
| port | int | 18789 | Gateway listen port |
| bind | string | "127.0.0.1" | Bind address (use 0.0.0.0 for remote access behind proxy) |
| cors | bool | true | Enable CORS headers |
| rateLimit.windowMs | int | 60000 | Rate limit window in milliseconds |
| rateLimit.maxRequests | int | 60 | Max requests per window |

### sessions
| Field | Type | Default | Description |
|-------|------|---------|-------------|
| maxAge | string | "7d" | Auto-delete sessions older than this |
| compaction | bool | true | Enable auto-compaction of long sessions |
| compactionThreshold | int | 50000 | Token count trigger for compaction |
| autoCleanup | bool | true | Auto-remove .deleted and .lock files |

### cron
| Field | Type | Default | Description |
|-------|------|---------|-------------|
| enabled | bool | true | Enable cron job scheduler |
| maxConcurrent | int | 2 | Max simultaneous cron jobs |
| defaultTimeout | int | 300 | Default job timeout in seconds |

### logging
| Field | Type | Default | Description |
|-------|------|---------|-------------|
| level | string | "info" | Log level: debug, info, warn, error |
| file | bool | true | Write logs to file |
| console | bool | true | Write logs to console |
| maxFileSize | string | "10MB" | Max log file size before rotation |
| maxFiles | int | 5 | Number of rotated log files to keep |

### security
| Field | Type | Default | Description |
|-------|------|---------|-------------|
| apiKeyRequired | bool | true | Require API key for gateway access |
| trustedProxies | array | [] | IP addresses of trusted reverse proxies |
| helmet | bool | true | Enable security headers |

## Environment Variables (~/.openclaw_env)
| Variable | Required | Description |
|----------|----------|-------------|
| OPENROUTER_API_KEY | Yes (if using OpenRouter) | OpenRouter API key |
| ANTHROPIC_API_KEY | Yes (if using Anthropic direct) | Anthropic API key |
| TRANSCRIPTAPI_KEY | No | Transcription service key |

## File Paths
| Path | Description |
|------|-------------|
| ~/.openclaw/openclaw.json | Main configuration |
| ~/.openclaw_env | Environment variables / API keys |
| ~/.openclaw/agents/main/agent/auth-profiles.json | API tokens by profile |
| ~/.openclaw/agents/main/sessions/ | Session data |
| ~/.openclaw/workspace/ | Workspace files (SOUL.md, MEMORY.md, etc.) |
| ~/.openclaw/cron/jobs.json | Cron job definitions |
| /tmp/openclaw/ | Runtime logs |
""",
        },
        {
            "slug": "config-env-vars",
            "title": "Environment Variables Reference",
            "category": "documentation",
            "tags": "env,environment,variables,api-key,secrets",
            "content": """# Environment Variables

## Location
`~/.openclaw_env` — sourced by shell profile and systemd service.

## Required Variables
```bash
# Primary API key (pick one provider)
export OPENROUTER_API_KEY="sk-or-v1-..."      # OpenRouter (recommended — access all providers)
# OR
export ANTHROPIC_API_KEY="sk-ant-..."           # Anthropic direct
# OR
export OPENAI_API_KEY="sk-..."                  # OpenAI direct
```

## Optional Variables
```bash
export TRANSCRIPTAPI_KEY="..."                  # Transcription API
export EASYCLAW_MCP_ENDPOINT="http://..."       # EasyClaw MCP server URL
export EASYCLAW_MCP_TOKEN="ec_..."              # EasyClaw subscription token
export NODE_ENV="production"                    # Node.js environment
export OLLAMA_HOST="http://localhost:11434"      # Ollama endpoint (if not default)
```

## Security
- File permissions MUST be 600: `chmod 600 ~/.openclaw_env`
- Never commit to git — add to .gitignore
- Rotate keys if exposed
- Use separate keys for dev vs production
""",
        },
        {
            "slug": "config-workspace",
            "title": "Workspace Configuration Guide",
            "category": "documentation",
            "tags": "workspace,soul,memory,agents,tools",
            "content": """# Workspace Configuration

## Directory: ~/.openclaw/workspace/

### Core Files
| File | Purpose |
|------|---------|
| SOUL.md | Agent personality, behavior rules, system prompt |
| AGENTS.md | Sub-agent definitions and routing rules |
| TOOLS.md | Available tools and their configuration |
| MEMORY.md | Persistent memory index |
| memory/facts.jsonl | Extracted facts database |
| memory/projects/INDEX.md | Project tracking |

### SOUL.md Tips
- Keep under 4000 tokens for efficiency
- Put most important instructions first (models prioritize early context)
- Use clear, imperative language
- Avoid redundancy — each instruction should be unique
- Test changes with a fresh session

### Memory System
- facts.jsonl stores extracted facts from conversations
- MEMORY.md is the index — keep it concise
- Memory files are loaded into every session context
- Large memory files increase token usage and cost

### Best Practices
- Regularly trim workspace files (remove outdated content)
- Total workspace size should stay under 15KB for optimal performance
- Back up workspace files before major changes
""",
        },
        {
            "slug": "config-cron",
            "title": "Cron Jobs Configuration",
            "category": "documentation",
            "tags": "cron,scheduling,automation,jobs",
            "content": """# Cron Jobs

## Config: ~/.openclaw/cron/jobs.json

### Job Schema
```json
{
  "id": "unique-job-id",
  "name": "Human-readable name",
  "schedule": "0 */6 * * *",
  "prompt": "The task to execute",
  "enabled": true,
  "timeout": 300,
  "isolatedSession": true,
  "lastRun": null,
  "lastResult": null
}
```

### Schedule Format (cron syntax)
```
┌───────────── minute (0-59)
│ ┌───────────── hour (0-23)
│ │ ┌───────────── day of month (1-31)
│ │ │ ┌───────────── month (1-12)
│ │ │ │ ┌───────────── day of week (0-7, 0=Sun)
│ │ │ │ │
* * * * *
```

### Common Schedules
| Schedule | Meaning |
|----------|---------|
| `*/30 * * * *` | Every 30 minutes |
| `0 */6 * * *` | Every 6 hours |
| `0 9 * * *` | Daily at 9 AM |
| `0 9 * * 1-5` | Weekdays at 9 AM |
| `0 0 * * 0` | Weekly on Sunday midnight |

### Cron Storm Prevention
After a WSL2 restart, all cron timers reset and may fire simultaneously. To prevent:
```bash
# Reset lastRun timestamps before starting
cd ~/.openclaw/cron && python3 -c "
import json
from datetime import datetime
with open('jobs.json') as f: jobs = json.load(f)
now = datetime.utcnow().isoformat()
for j in jobs: j['lastRun'] = now
with open('jobs.json', 'w') as f: json.dump(jobs, f, indent=2)
"
```

### Best Practices
- Use `isolatedSession: true` to prevent cron jobs from polluting main session
- Set reasonable timeouts (don't let jobs run forever)
- Limit `maxConcurrent` in config to prevent resource exhaustion
- Monitor cron logs: `grep 'cron' /tmp/openclaw/*.log`
""",
        },
        # ── Troubleshooting Guides ────────────────────────────────
        {
            "slug": "troubleshoot-connection-refused",
            "title": "Troubleshooting ConnectionRefusedError",
            "category": "troubleshooting",
            "tags": "connection,refused,econnrefused,network,ollama,openrouter",
            "content": """# ConnectionRefusedError

## Quick Diagnosis
```bash
# Check which services are running
docker ps
systemctl --user status openclaw-gateway
curl -s http://localhost:11434/api/tags  # Ollama
curl -s https://openrouter.ai/api/v1/models | head -1  # OpenRouter
```

## By Service

### Ollama (localhost:11434)
```bash
docker ps | grep ollama         # Check if running
docker start ollama             # Start if stopped
docker logs ollama --tail 20    # Check for errors
```

### OpenRouter API
```bash
curl -s -o /dev/null -w "%{http_code}" https://openrouter.ai/api/v1/models
# 200 = fine, retry failed request
# Other = provider issue, wait or switch to local model
```

### n8n Webhooks
```bash
curl -s -o /dev/null -w "%{http_code}" https://your-n8n-instance/healthz
docker ps | grep n8n
docker restart n8n
```

### OpenClaw Gateway
```bash
systemctl --user status openclaw-gateway
systemctl --user restart openclaw-gateway
curl http://localhost:18789/health
```

## Auto-Remediation
EasyClaw will automatically:
1. Wait 30 seconds for transient issues
2. Attempt to restart Docker containers (Ollama)
3. Escalate to user if issue persists after 2 retries
""",
        },
        {
            "slug": "troubleshoot-oom",
            "title": "Troubleshooting Out of Memory Errors",
            "category": "troubleshooting",
            "tags": "oom,memory,heap,crash,kill",
            "content": """# Out of Memory Errors

## Types of OOM

### 1. JavaScript Heap OOM (Node.js)
```
FATAL ERROR: CALL_AND_RETRY_LAST Allocation failed - JavaScript heap out of memory
```
Exit code: 134 (SIGABRT)

**Fix:**
```bash
# Clean sessions
find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' -delete
find ~/.openclaw/agents/main/sessions/ -name '*.lock' -mmin +5 -delete
rm -f ~/.openclaw/workspace/memory/*.cache

# Restart with more heap (temporary)
NODE_OPTIONS="--max-old-space-size=4096" openclaw gateway start

# Permanent: reduce compaction threshold in openclaw.json
```

### 2. Linux OOM Killer
```
Out of memory: Killed process XXXX (node)
```

**Fix:**
```bash
# Check what was killed
dmesg | grep -i 'oom\|killed' | tail -20

# Check memory
free -h
docker stats --no-stream

# Add swap
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab

# Reduce Ollama memory usage
# Lower context window or unload unused models
curl http://localhost:11434/api/generate -d '{"model":"glm-4.7-flash:q4_K_M","keep_alive":"0"}'
```

### 3. Docker Container OOM
```bash
docker inspect <container> | grep -i oom
docker logs <container> --tail 50
# Set memory limits in docker-compose.yml: mem_limit: 1g
```
""",
        },
        {
            "slug": "troubleshoot-dns",
            "title": "Troubleshooting DNS Issues",
            "category": "troubleshooting",
            "tags": "dns,eai_again,enotfound,resolv,network",
            "content": """# DNS Resolution Failures

## Symptoms
- `EAI_AGAIN` errors
- `ENOTFOUND` for known domains
- `getaddrinfo` failures

## Quick Fix
```bash
# Test current DNS
nslookup google.com

# If failing, restore known-good DNS
sudo bash -c 'cat > /etc/resolv.conf << EOF
nameserver 8.8.8.8
nameserver 1.1.1.1
nameserver 8.8.4.4
EOF'

# Verify
nslookup google.com 8.8.8.8
```

## Permanent Fix (WSL2)
```bash
# Prevent WSL2 from overwriting resolv.conf
sudo bash -c 'cat >> /etc/wsl.conf << EOF
[network]
generateResolvConf = false
EOF'

# Restart WSL from PowerShell:
# wsl --shutdown
```

## Common Causes
1. **Tailscale** overwrites resolv.conf when it connects
2. **WSL2** auto-generates resolv.conf on every restart
3. **VPN** software changes DNS settings
4. **Network disconnection** — check WiFi/Ethernet
""",
        },
        {
            "slug": "troubleshoot-session-bloat",
            "title": "Troubleshooting Session Bloat",
            "category": "troubleshooting",
            "tags": "sessions,bloat,disk,cleanup,lock",
            "content": """# Session Directory Bloat

## Check Current State
```bash
du -sh ~/.openclaw/agents/main/sessions/
ls ~/.openclaw/agents/main/sessions/ | wc -l
find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' | wc -l
find ~/.openclaw/agents/main/sessions/ -name '*.lock' | wc -l
```

## Cleanup
```bash
# Remove soft-deleted files
find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' -delete

# Remove stale locks (older than 30 min)
find ~/.openclaw/agents/main/sessions/ -name '*.lock' -mmin +30 -delete

# Remove very old sessions (older than 7 days)
find ~/.openclaw/agents/main/sessions/ -type f -mtime +7 -delete

# Verify
du -sh ~/.openclaw/agents/main/sessions/
```

## Prevention
- Set `sessions.autoCleanup: true` in config
- Reduce `sessions.maxAge` (e.g., "3d" instead of "7d")
- Use `isolatedSession: true` for cron jobs
- Schedule periodic cleanup with EasyClaw
""",
        },
        {
            "slug": "troubleshoot-api-rate-limit",
            "title": "Troubleshooting API Rate Limits",
            "category": "troubleshooting",
            "tags": "429,rate-limit,throttle,api,quota",
            "content": """# API Rate Limiting (429 Errors)

## Immediate Actions
1. **Wait** — most rate limits reset within 60 seconds
2. **Reduce concurrency** — lower `cron.maxConcurrent` in config
3. **Add delays** between rapid-fire requests

## Provider-Specific Limits

### OpenRouter
- Free tier: 20 requests/minute
- Paid: varies by plan
- Check: https://openrouter.ai/settings/limits

### Anthropic Direct
- Tier 1: 60 RPM
- Tier 2: 1000 RPM
- Check: https://console.anthropic.com/settings/limits

### OpenAI Direct
- Varies by model and tier
- Check: https://platform.openai.com/settings/limits

## Solutions
```bash
# Reduce cron concurrency
# In ~/.openclaw/openclaw.json:
{
  "cron": {
    "maxConcurrent": 1,
    "defaultTimeout": 120
  }
}

# Switch to cheaper/faster model with higher limits
# Budget models often have more generous rate limits
```

## Long-term
- Upgrade API tier if consistently hitting limits
- Use local Ollama models for high-volume tasks
- Implement request queuing in cron configuration
""",
        },
        {
            "slug": "troubleshoot-cloudflare-tunnel",
            "title": "Troubleshooting Cloudflare Tunnel",
            "category": "troubleshooting",
            "tags": "cloudflare,tunnel,cloudflared,502,remote-access",
            "content": """# Cloudflare Tunnel Issues

## Check Status
```bash
# Linux
systemctl status cloudflared

# Windows
# Check Services panel for "cloudflared" or "Cloudflare Tunnel"

# Check tunnel info
cloudflared tunnel info
```

## 502 Bad Gateway
1. Backend not running: `curl http://localhost:18789/health`
2. Tunnel disconnected: restart cloudflared
3. Wrong config: verify `~/.cloudflared/config.yml` points to correct port

## Tunnel Config Example
```yaml
# ~/.cloudflared/config.yml
tunnel: your-tunnel-id
credentials-file: ~/.cloudflared/your-tunnel-id.json
ingress:
  - hostname: yourdomain.com
    service: http://localhost:18789
  - service: http_status:404
```

## Common Fixes
```bash
# Restart tunnel
sudo systemctl restart cloudflared

# Re-login (if credentials expired)
cloudflared tunnel login

# Check DNS
# CNAME: yourdomain.com -> your-tunnel-id.cfargotunnel.com
```
""",
        },
        # ── Ollama & Local Models ─────────────────────────────────
        {
            "slug": "guide-ollama-setup",
            "title": "Setting Up Ollama for Local Inference",
            "category": "guides",
            "tags": "ollama,local,gpu,models,setup",
            "content": """# Ollama Setup Guide

## Docker Installation (Recommended)
```bash
# With GPU support
docker run -d \\
  --gpus all \\
  -v ollama:/root/.ollama \\
  -p 11434:11434 \\
  --name ollama \\
  -e OLLAMA_FLASH_ATTENTION=1 \\
  -e OLLAMA_KEEP_ALIVE=24h \\
  --restart unless-stopped \\
  ollama/ollama

# Without GPU (CPU only)
docker run -d \\
  -v ollama:/root/.ollama \\
  -p 11434:11434 \\
  --name ollama \\
  --restart unless-stopped \\
  ollama/ollama
```

## Pull Models
```bash
# Recommended for 24GB VRAM (3090 Ti, 4090)
docker exec -it ollama ollama pull glm-4.7-flash:q4_K_M    # 19GB, 98 tok/s
docker exec -it ollama ollama pull qwen3:32b-q4_K_M          # 20GB, slower but higher quality

# For 8-12GB VRAM (3060, 3070, 4060)
docker exec -it ollama ollama pull qwen3:8b                   # 5GB
docker exec -it ollama ollama pull llama3.1:8b                # 5GB

# For CPU-only or low VRAM
docker exec -it ollama ollama pull phi3:mini                  # 2GB
```

## Configure OpenClaw for Ollama
```json
{
  "model": {
    "provider": "ollama",
    "model": "glm-4.7-flash:q4_K_M",
    "baseUrl": "http://localhost:11434",
    "temperature": 0.7,
    "maxTokens": 4096
  }
}
```

## Performance Tuning
- `OLLAMA_FLASH_ATTENTION=1` — enables flash attention for faster inference
- `OLLAMA_KEEP_ALIVE=24h` — keeps model in VRAM (avoids reload delay)
- Context window: set in `num_ctx` parameter. Higher = more VRAM. 40960 ≈ 730MB on top of model.
- Quantization: Q4_K_M is best balance of quality/speed/VRAM

## VRAM Requirements
| Model | Q4_K_M | Q8_0 | FP16 |
|-------|--------|------|------|
| 7-8B  | ~5GB   | ~8GB | ~16GB |
| 13-14B | ~8GB  | ~14GB | ~28GB |
| 32-34B | ~20GB | ~34GB | ~64GB |
| 70B | ~40GB | ~70GB | ~140GB |
""",
        },
        {
            "slug": "guide-openrouter",
            "title": "Using OpenRouter as Model Provider",
            "category": "guides",
            "tags": "openrouter,api,models,provider,cloud",
            "content": """# OpenRouter Guide

## What is OpenRouter?
A unified API gateway that provides access to 200+ AI models from Anthropic, OpenAI, Google, Meta, and more through a single API key.

## Setup
1. Create account at https://openrouter.ai
2. Add credits (pay-as-you-go)
3. Generate API key at https://openrouter.ai/keys

## Configuration
```bash
# Add to ~/.openclaw_env
export OPENROUTER_API_KEY="sk-or-v1-your-key-here"
```

```json
// ~/.openclaw/openclaw.json
{
  "model": {
    "provider": "openrouter",
    "model": "anthropic/claude-sonnet-4-6",
    "temperature": 0.7,
    "maxTokens": 8192
  }
}
```

## Popular Models on OpenRouter
| Model | Cost (in/out per MTok) | Best For |
|-------|----------------------|----------|
| anthropic/claude-sonnet-4-6 | $3/$15 | Coding, general |
| google/gemini-2.5-flash | $0.15/$0.60 | Cheap + fast |
| openai/gpt-4.1 | $2/$8 | Large context |
| deepseek/deepseek-chat-v3 | $0.27/$1.10 | Budget |
| qwen/qwen3-235b-a22b | $0.20/$0.60 | Coding (cheap) |

## Monitoring Usage
- Dashboard: https://openrouter.ai/activity
- Check remaining credits: https://openrouter.ai/settings/credits
- Set spending limits at: https://openrouter.ai/settings/limits
""",
        },
        # ── EasyClaw Guides ───────────────────────────────────────
        {
            "slug": "guide-easyclaw-setup",
            "title": "EasyClaw Setup and Configuration",
            "category": "guides",
            "tags": "easyclaw,setup,install,configure,sidecar",
            "content": """# EasyClaw Setup Guide

## Installation

### Via pip
```bash
pip install easyclaw
```

### Via installer script
```bash
curl -sL easyclaw.help/install | bash
```

### Via Docker (sidecar)
```yaml
# Add to your docker-compose.yml
easyclaw:
  image: easyclaw/easyclaw:latest
  volumes:
    - ~/.openclaw:/root/.openclaw:ro
    - ~/.easyclaw:/root/.easyclaw
    - /tmp/openclaw:/tmp/openclaw:ro
  restart: unless-stopped
  mem_limit: 256m
```

## Configuration
```yaml
# ~/.easyclaw/config.yaml
heartbeat_interval: 30
health_check_interval: 60
log_retention_days: 7
max_restart_attempts: 3
restart_window: 600
gateway_port: 18789
alert_webhook: null            # Optional: n8n/Telegram webhook URL
mcp_endpoint: null             # Optional: MCP server URL
mcp_token: null                # Optional: subscription token
update_check_interval: 21600   # 6 hours
```

## CLI Commands
```bash
easyclaw start            # Start daemon (background)
easyclaw start -f         # Start in foreground (debugging)
easyclaw stop             # Graceful shutdown
easyclaw status           # Show daemon + OpenClaw status
easyclaw doctor           # Run 19-point diagnostic
```

## What EasyClaw Does
1. **Monitors** OpenClaw logs for errors (13 built-in patterns)
2. **Classifies** events by severity (INFO/WARNING/CRITICAL)
3. **Auto-heals** known issues (11 built-in remediation actions)
4. **Alerts** on critical events (webhook integration)
5. **Audits** fixes in a JSONL ledger for review
6. **Circuit breaks** to prevent restart loops (3 restarts/10 min max)
""",
        },
        {
            "slug": "guide-remote-access",
            "title": "Setting Up Remote Access",
            "category": "guides",
            "tags": "remote,cloudflare,tunnel,tailscale,access",
            "content": """# Remote Access Guide

## Option 1: Cloudflare Tunnel (Recommended)
Secure, no port forwarding, free tier available.

```bash
# Install cloudflared
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared
chmod +x /usr/local/bin/cloudflared

# Create tunnel
cloudflared tunnel login
cloudflared tunnel create openclaw

# Configure
cat > ~/.cloudflared/config.yml << 'EOF'
tunnel: <tunnel-id>
credentials-file: ~/.cloudflared/<tunnel-id>.json
ingress:
  - hostname: openclaw.yourdomain.com
    service: http://localhost:18789
  - service: http_status:404
EOF

# Add DNS record
cloudflared tunnel route dns <tunnel-id> openclaw.yourdomain.com

# Run as service
sudo cloudflared service install
sudo systemctl enable cloudflared
sudo systemctl start cloudflared
```

## Option 2: Tailscale (Private Network)
Access from your own devices only. No public exposure.

```bash
# Install
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up

# Access from any device on your Tailnet:
# http://<tailscale-ip>:18789
```

## Option 3: SSH Tunnel (Quick & Dirty)
```bash
# From your remote machine:
ssh -L 18789:localhost:18789 user@your-server
# Then access: http://localhost:18789
```

## Security Notes
- Always use HTTPS (Cloudflare provides this automatically)
- Set `gateway.bind: "127.0.0.1"` — let the tunnel handle external access
- Enable API key auth in security config
- Consider Cloudflare Access for additional authentication
""",
        },
        # ── Skills & Use Cases ────────────────────────────────────
        {
            "slug": "skills-developer",
            "title": "Developer Skill Pack Recommendations",
            "category": "skills",
            "tags": "skills,developer,coding,programming",
            "content": """# Developer Skill Pack

## Recommended Skills
1. **Code Review** — Automated PR review with style and security checks
2. **Git Workflow** — Branch management, commit messages, PR creation
3. **Testing** — Test generation, coverage analysis, test runner integration
4. **Documentation** — Auto-generate docs, API references, README updates
5. **Refactoring** — Code quality analysis, dead code detection, simplification
6. **Debug Assistant** — Stack trace analysis, log correlation, root cause analysis
7. **Dependency Audit** — Check for outdated packages, vulnerabilities, license issues

## Configuration
```json
{
  "skills": {
    "enabled": ["code-review", "git-workflow", "testing", "docs", "refactor"],
    "code-review": {
      "auto_review_prs": true,
      "style_guide": "standard"
    }
  }
}
```

## Model Recommendations for Developers
- **Primary**: Claude Sonnet 4.6 (best coding model overall)
- **Sub-agents**: Claude Haiku 4.5 (fast, cheap, good for search/triage)
- **Local fallback**: GLM-4.7 Flash (free, fast, decent coding)
""",
        },
        {
            "slug": "skills-automation",
            "title": "Automation Skill Pack Recommendations",
            "category": "skills",
            "tags": "skills,automation,cron,workflow,n8n",
            "content": """# Automation Skill Pack

## Recommended Skills
1. **Web Monitor** — Track websites for changes, price drops, availability
2. **Report Generator** — Scheduled reports from data sources
3. **Email/Notification** — Smart alerts via email, Slack, Telegram
4. **Data Pipeline** — ETL from APIs, databases, files
5. **Social Media** — Auto-post, engagement tracking, content scheduling
6. **System Monitor** — Server health, uptime, resource usage

## n8n Integration
OpenClaw cron jobs can trigger n8n workflows via webhooks:
```json
{
  "id": "daily-report",
  "schedule": "0 9 * * 1-5",
  "prompt": "Generate daily report and send to n8n webhook",
  "isolatedSession": true
}
```

## Model Recommendations for Automation
- **Primary**: Claude Haiku 4.5 (fast, cheap — most automation is simple)
- **Complex analysis**: Claude Sonnet 4.6 (when quality matters)
- **High volume**: Gemini 2.5 Flash (cheapest per token)
- **Zero cost**: GLM-4.7 Flash local (unlimited, free)
""",
        },
        {
            "slug": "skills-business",
            "title": "Business Skill Pack Recommendations",
            "category": "skills",
            "tags": "skills,business,analysis,reports,productivity",
            "content": """# Business Skill Pack

## Recommended Skills
1. **Meeting Summarizer** — Transcribe and summarize meetings
2. **Email Drafter** — Professional email composition
3. **Data Analyst** — CSV/spreadsheet analysis, charts, insights
4. **Research Assistant** — Web research, competitive analysis
5. **Document Generator** — Reports, proposals, SOPs
6. **Calendar Manager** — Scheduling, reminders, availability

## Model Recommendations for Business
- **Primary**: GPT-4.1 or Claude Sonnet 4.6 (reliable, well-rounded)
- **Document drafting**: Claude Sonnet 4.6 (best writing quality)
- **Data analysis**: Claude Sonnet 4.6 or o4-mini (strong reasoning)
- **Budget**: Gemini 2.5 Flash (good enough for most business tasks)
""",
        },
        {
            "slug": "skills-research",
            "title": "Research Skill Pack Recommendations",
            "category": "skills",
            "tags": "skills,research,academic,analysis,deep-research",
            "content": """# Research Skill Pack

## Recommended Skills
1. **Deep Research** — Multi-source web research with synthesis
2. **Paper Analyzer** — Read and summarize academic papers
3. **Citation Manager** — Track sources, generate bibliographies
4. **Fact Checker** — Verify claims against multiple sources
5. **Knowledge Graph** — Build and query knowledge graphs from research

## Web Search Integration
OpenClaw can integrate with SearXNG for private web search:
```json
{
  "tools": {
    "web_search": {
      "provider": "searxng",
      "endpoint": "http://localhost:8181",
      "engines": ["google", "bing", "duckduckgo", "wikipedia"]
    }
  }
}
```

## Model Recommendations for Research
- **Deep analysis**: Claude Opus 4.6 or o3 (best reasoning)
- **Fast research**: Claude Sonnet 4.6 (balanced)
- **Bulk processing**: Gemini 2.5 Flash (cheap, 1M context for long papers)
""",
        },
        # ── Security ──────────────────────────────────────────────
        {
            "slug": "guide-security-hardening",
            "title": "Security Hardening Guide",
            "category": "security",
            "tags": "security,hardening,production,api-key,permissions",
            "content": """# Security Hardening Guide

## Critical Steps
1. **Protect API keys** — chmod 600 ~/.openclaw_env, never commit to git
2. **Bind locally** — gateway.bind = "127.0.0.1" (use tunnel for remote)
3. **Enable rate limiting** — prevent abuse and runaway costs
4. **Enable auth** — apiKeyRequired = true
5. **Restrict file permissions** — chmod 700 sessions, chmod 600 env files

## File Permission Checklist
```bash
chmod 600 ~/.openclaw_env
chmod 600 ~/.openclaw/agents/main/agent/auth-profiles.json
chmod 700 ~/.openclaw/agents/main/sessions/
chmod 600 /tmp/openclaw/*.log 2>/dev/null
chmod 700 ~/.easyclaw/
```

## Network Security
- Use Cloudflare Tunnel (free TLS, DDoS protection)
- Add Cloudflare Access for authentication
- Never expose port 18789 directly to the internet
- Use VPN (Tailscale) for private access

## Monitoring
- Set up alert webhooks for CRITICAL events
- Review fix-ledger.jsonl regularly
- Monitor API spending with provider dashboards
- Use EasyClaw's security_audit tool for automated checks
""",
        },
        # ── Performance ───────────────────────────────────────────
        {
            "slug": "guide-performance-tuning",
            "title": "Performance Tuning Guide",
            "category": "guides",
            "tags": "performance,speed,optimization,tuning,tokens",
            "content": """# Performance Tuning

## Reduce Token Usage (= Lower Cost + Faster)
1. **Trim SOUL.md** — Remove redundant instructions, keep under 4000 tokens
2. **Trim MEMORY.md** — Regularly prune outdated entries
3. **Lower compactionThreshold** — Compact sessions earlier (e.g., 30000 tokens)
4. **Reduce maxTokens** — Limit output length (e.g., 4096 instead of 16384)
5. **Use shorter session maxAge** — Auto-delete old sessions

## Speed Up Response Time
1. **Use faster models** — Haiku 4.5, Gemini 2.5 Flash, or local GLM Flash
2. **Reduce context** — Less workspace content = faster processing
3. **Local models** — Zero network latency with Ollama
4. **Enable flash attention** — `OLLAMA_FLASH_ATTENTION=1` for Ollama
5. **Keep models loaded** — `OLLAMA_KEEP_ALIVE=24h` avoids reload delay

## Resource Limits
```ini
# systemd service limits
CPUQuota=80%
MemoryMax=1G

# Docker limits
mem_limit: 1g
cpus: 0.8
```

## Monitoring
```bash
# Check gateway memory usage
ps aux | grep openclaw | awk '{print $4"%"}'

# Check session sizes
du -sh ~/.openclaw/agents/main/sessions/

# Check disk usage
df -h /
```
""",
        },
    ]

    for article in articles:
        db.upsert_article(
            slug=article["slug"],
            title=article["title"],
            category=article["category"],
            content=article["content"],
            tags=article.get("tags", ""),
            source="builtin",
        )
        counts["articles"] += 1

    # ── Seed model catalog ────────────────────────────────────────
    for model in MODELS:
        db.upsert_model(model)
        counts["models"] += 1

    return counts


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Seed EasyClaw knowledge database")
    parser.add_argument("--db", default=None, help="Database path")
    parser.add_argument("--reseed", action="store_true", help="Force reseed (delete existing DB)")
    args = parser.parse_args()

    db_path = Path(args.db) if args.db else None
    if args.reseed and db_path and db_path.exists():
        db_path.unlink()
        print(f"Deleted existing database: {db_path}")

    db = KnowledgeDB(db_path)
    counts = seed_all(db)
    print(f"Seeded: {counts['articles']} articles, {counts['models']} models")
    print(f"Database: {db.db_path}")

    stats = db.get_stats()
    print(f"\nCategories:")
    for cat in stats["categories"]:
        print(f"  {cat['category']}: {cat['count']} articles")
