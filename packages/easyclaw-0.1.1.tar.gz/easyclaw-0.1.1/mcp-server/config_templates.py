"""Configuration Templates & Validation — for generate_config and validate_config tools.

Provides pre-built openclaw.json templates for different use cases,
configuration validation checklists, and gateway config generation.
"""

from __future__ import annotations

import copy

# ── Base Configuration ────────────────────────────────────────────

BASE_CONFIG = {
    "model": {
        "provider": "openrouter",
        "model": "anthropic/claude-sonnet-4-6",
        "temperature": 0.7,
        "maxTokens": 8192,
    },
    "gateway": {
        "port": 18789,
        "bind": "127.0.0.1",
        "cors": True,
        "rateLimit": {
            "windowMs": 60000,
            "maxRequests": 60,
        },
    },
    "sessions": {
        "maxAge": "7d",
        "compaction": True,
        "compactionThreshold": 50000,
        "autoCleanup": True,
    },
    "cron": {
        "enabled": True,
        "maxConcurrent": 2,
        "defaultTimeout": 300,
    },
    "logging": {
        "level": "info",
        "file": True,
        "console": True,
        "maxFileSize": "10MB",
        "maxFiles": 5,
    },
    "workspace": {
        "path": "~/.openclaw/workspace",
        "memoryEnabled": True,
        "maxMemorySize": "50MB",
    },
    "security": {
        "apiKeyRequired": True,
        "trustedProxies": [],
        "helmet": True,
    },
}


# ── Template Overrides ────────────────────────────────────────────

TEMPLATES = {
    "developer": {
        "description": "Optimized for software development — high-quality model, large context, fast iteration",
        "overrides": {
            "model": {
                "provider": "openrouter",
                "model": "anthropic/claude-sonnet-4-6",
                "temperature": 0.3,
                "maxTokens": 16384,
            },
            "sessions": {
                "compactionThreshold": 80000,
            },
            "cron": {
                "maxConcurrent": 3,
            },
        },
        "recommended_env": {
            "OPENROUTER_API_KEY": "<your-openrouter-key>",
        },
        "estimated_monthly_cost": "$15-50 depending on usage",
    },
    "business": {
        "description": "Balanced for business use — reliable model, cost-conscious, good defaults",
        "overrides": {
            "model": {
                "provider": "openrouter",
                "model": "openai/gpt-4.1",
                "temperature": 0.5,
                "maxTokens": 8192,
            },
            "sessions": {
                "maxAge": "30d",
                "compactionThreshold": 40000,
            },
            "cron": {
                "maxConcurrent": 2,
            },
            "logging": {
                "level": "warn",
            },
        },
        "recommended_env": {
            "OPENROUTER_API_KEY": "<your-openrouter-key>",
        },
        "estimated_monthly_cost": "$10-30 depending on usage",
    },
    "production": {
        "description": "Hardened for production — security-first, monitoring, resource limits",
        "overrides": {
            "model": {
                "provider": "openrouter",
                "model": "anthropic/claude-sonnet-4-6",
                "temperature": 0.3,
                "maxTokens": 8192,
            },
            "gateway": {
                "bind": "0.0.0.0",
                "rateLimit": {
                    "windowMs": 60000,
                    "maxRequests": 30,
                },
            },
            "sessions": {
                "maxAge": "3d",
                "compactionThreshold": 30000,
                "autoCleanup": True,
            },
            "cron": {
                "maxConcurrent": 1,
                "defaultTimeout": 120,
            },
            "logging": {
                "level": "warn",
                "maxFiles": 10,
            },
            "security": {
                "apiKeyRequired": True,
                "trustedProxies": ["127.0.0.1"],
                "helmet": True,
            },
        },
        "recommended_env": {
            "OPENROUTER_API_KEY": "<your-openrouter-key>",
            "NODE_ENV": "production",
        },
        "estimated_monthly_cost": "$10-40 depending on usage",
    },
    "budget": {
        "description": "Minimum cost — cheapest models, aggressive cleanup, low limits",
        "overrides": {
            "model": {
                "provider": "openrouter",
                "model": "google/gemini-2.5-flash",
                "temperature": 0.5,
                "maxTokens": 4096,
            },
            "sessions": {
                "maxAge": "1d",
                "compactionThreshold": 20000,
                "autoCleanup": True,
            },
            "cron": {
                "maxConcurrent": 1,
                "defaultTimeout": 60,
            },
        },
        "recommended_env": {
            "OPENROUTER_API_KEY": "<your-openrouter-key>",
        },
        "estimated_monthly_cost": "$1-5 depending on usage",
    },
    "local": {
        "description": "Fully local with Ollama — zero API cost, private, offline-capable",
        "overrides": {
            "model": {
                "provider": "ollama",
                "model": "glm-4.7-flash:q4_K_M",
                "temperature": 0.7,
                "maxTokens": 4096,
                "baseUrl": "http://localhost:11434",
            },
            "sessions": {
                "compactionThreshold": 20000,
            },
            "cron": {
                "maxConcurrent": 1,
            },
        },
        "recommended_env": {},
        "estimated_monthly_cost": "$0 (local inference only)",
        "hardware_requirements": "NVIDIA GPU with 8GB+ VRAM recommended. CPU inference possible but slow.",
    },
    "hybrid": {
        "description": "Local primary + cloud fallback — cost-effective with quality backup",
        "overrides": {
            "model": {
                "provider": "ollama",
                "model": "glm-4.7-flash:q4_K_M",
                "temperature": 0.7,
                "maxTokens": 4096,
                "baseUrl": "http://localhost:11434",
                "fallback": {
                    "provider": "openrouter",
                    "model": "anthropic/claude-haiku-4-5",
                },
            },
            "sessions": {
                "compactionThreshold": 30000,
            },
        },
        "recommended_env": {
            "OPENROUTER_API_KEY": "<your-openrouter-key>",
        },
        "estimated_monthly_cost": "$0-10 (mostly local, cloud for fallback)",
    },
    "automation": {
        "description": "Optimized for cron/automation — fast model, many concurrent jobs, aggressive cleanup",
        "overrides": {
            "model": {
                "provider": "openrouter",
                "model": "anthropic/claude-haiku-4-5",
                "temperature": 0.3,
                "maxTokens": 4096,
            },
            "sessions": {
                "maxAge": "1d",
                "compactionThreshold": 20000,
                "autoCleanup": True,
            },
            "cron": {
                "enabled": True,
                "maxConcurrent": 5,
                "defaultTimeout": 180,
            },
        },
        "recommended_env": {
            "OPENROUTER_API_KEY": "<your-openrouter-key>",
        },
        "estimated_monthly_cost": "$5-20 depending on job count",
    },
}


def generate_config(template_name: str) -> dict:
    """Generate a complete openclaw.json from a template."""
    template_name = template_name.lower().strip()

    if template_name not in TEMPLATES:
        return {
            "error": f"Unknown template: {template_name}",
            "available": list(TEMPLATES.keys()),
            "descriptions": {k: v["description"] for k, v in TEMPLATES.items()},
        }

    template = TEMPLATES[template_name]
    config = copy.deepcopy(BASE_CONFIG)

    # Deep merge overrides
    def _deep_merge(base: dict, override: dict) -> dict:
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                _deep_merge(base[key], value)
            else:
                base[key] = value
        return base

    _deep_merge(config, template["overrides"])

    return {
        "template": template_name,
        "description": template["description"],
        "config": config,
        "recommended_env": template.get("recommended_env", {}),
        "estimated_monthly_cost": template.get("estimated_monthly_cost", "varies"),
        "hardware_requirements": template.get("hardware_requirements"),
        "instructions": [
            f"Save the config below to ~/.openclaw/openclaw.json",
            f"Set environment variables in ~/.openclaw_env",
            f"Restart OpenClaw: systemctl --user restart openclaw-gateway",
        ],
    }


# ── Configuration Validation ─────────────────────────────────────

VALIDATION_CHECKS = [
    {
        "id": "config_file_exists",
        "domain": "config",
        "check": "~/.openclaw/openclaw.json exists and is valid JSON",
        "severity": "critical",
        "fix": "Create config file: easyclaw generate-config developer > ~/.openclaw/openclaw.json",
    },
    {
        "id": "env_file_exists",
        "domain": "config",
        "check": "~/.openclaw_env exists and is sourced",
        "severity": "critical",
        "fix": "Create: touch ~/.openclaw_env && echo 'source ~/.openclaw_env' >> ~/.bashrc",
    },
    {
        "id": "api_key_set",
        "domain": "auth",
        "check": "OPENROUTER_API_KEY (or provider key) is set and non-empty",
        "severity": "critical",
        "fix": "Add to ~/.openclaw_env: export OPENROUTER_API_KEY='sk-or-...'",
    },
    {
        "id": "api_key_valid",
        "domain": "auth",
        "check": "API key returns 200 from provider health endpoint",
        "severity": "critical",
        "fix": "Regenerate key at provider dashboard, update ~/.openclaw_env",
    },
    {
        "id": "auth_profiles_exist",
        "domain": "auth",
        "check": "~/.openclaw/agents/main/agent/auth-profiles.json exists and has valid tokens",
        "severity": "high",
        "fix": "Recreate auth profiles via OpenClaw setup wizard",
    },
    {
        "id": "model_accessible",
        "domain": "model",
        "check": "Configured model is accessible (API responds or Ollama has it pulled)",
        "severity": "critical",
        "fix": "For OpenRouter: verify model ID at openrouter.ai. For Ollama: `ollama pull <model>`",
    },
    {
        "id": "model_supports_tools",
        "domain": "model",
        "check": "Configured model supports tool/function calling",
        "severity": "high",
        "fix": "Switch to a model that supports tools (see get_model_recommendation)",
    },
    {
        "id": "gateway_port_free",
        "domain": "gateway",
        "check": "Gateway port (default 18789) is not in use by another process",
        "severity": "critical",
        "fix": "Kill conflicting process: `ss -tlnp | grep 18789` then kill PID, or change port in config",
    },
    {
        "id": "gateway_running",
        "domain": "gateway",
        "check": "OpenClaw gateway service is active and responding",
        "severity": "critical",
        "fix": "Start: `systemctl --user start openclaw-gateway`",
    },
    {
        "id": "gateway_health",
        "domain": "gateway",
        "check": "Gateway health endpoint returns 200",
        "severity": "high",
        "fix": "Restart: `systemctl --user restart openclaw-gateway`",
    },
    {
        "id": "sessions_dir_exists",
        "domain": "sessions",
        "check": "~/.openclaw/agents/main/sessions/ directory exists and is writable",
        "severity": "high",
        "fix": "Create: `mkdir -p ~/.openclaw/agents/main/sessions/`",
    },
    {
        "id": "sessions_not_bloated",
        "domain": "sessions",
        "check": "Session directory is under 500MB and has fewer than 200 files",
        "severity": "warning",
        "fix": "Clean: `find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' -delete`",
    },
    {
        "id": "workspace_exists",
        "domain": "workspace",
        "check": "~/.openclaw/workspace/ directory exists with SOUL.md",
        "severity": "high",
        "fix": "Verify OpenClaw installation or recreate workspace files",
    },
    {
        "id": "cron_config_valid",
        "domain": "cron",
        "check": "~/.openclaw/cron/jobs.json is valid JSON",
        "severity": "warning",
        "fix": "Validate: `python3 -m json.tool ~/.openclaw/cron/jobs.json`",
    },
    {
        "id": "disk_space",
        "domain": "system",
        "check": "Root filesystem has >1GB free space",
        "severity": "warning",
        "fix": "Free space: `docker system prune -f` and clean old logs",
    },
    {
        "id": "dns_resolution",
        "domain": "network",
        "check": "DNS resolution works (can resolve google.com)",
        "severity": "critical",
        "fix": "Fix DNS: `echo 'nameserver 8.8.8.8' | sudo tee /etc/resolv.conf`",
    },
    {
        "id": "docker_running",
        "domain": "system",
        "check": "Docker daemon is running (if Docker-based setup)",
        "severity": "high",
        "fix": "Start Docker: `sudo systemctl start docker` or open Docker Desktop",
    },
    {
        "id": "systemd_service",
        "domain": "system",
        "check": "openclaw-gateway systemd user service is enabled",
        "severity": "warning",
        "fix": "Enable: `systemctl --user enable openclaw-gateway`",
    },
    {
        "id": "log_dir_writable",
        "domain": "logging",
        "check": "/tmp/openclaw/ log directory exists and is writable",
        "severity": "warning",
        "fix": "Create: `mkdir -p /tmp/openclaw/ && chmod 755 /tmp/openclaw/`",
    },
    {
        "id": "cloudflare_tunnel",
        "domain": "network",
        "check": "Cloudflare tunnel is running (if configured for remote access)",
        "severity": "warning",
        "fix": "Start tunnel: `systemctl restart cloudflared` or Windows Services > cloudflared",
    },
]


def validate_config() -> dict:
    """Return the full configuration validation checklist."""
    domains = {}
    for check in VALIDATION_CHECKS:
        domain = check["domain"]
        if domain not in domains:
            domains[domain] = []
        domains[domain].append({
            "id": check["id"],
            "check": check["check"],
            "severity": check["severity"],
            "fix": check["fix"],
        })

    return {
        "total_checks": len(VALIDATION_CHECKS),
        "domains": domains,
        "severity_counts": {
            "critical": sum(1 for c in VALIDATION_CHECKS if c["severity"] == "critical"),
            "high": sum(1 for c in VALIDATION_CHECKS if c["severity"] == "high"),
            "warning": sum(1 for c in VALIDATION_CHECKS if c["severity"] == "warning"),
        },
        "instructions": "Run each check manually or use `easyclaw doctor` for automated validation.",
    }


# ── Gateway / Foreman Config Generation ──────────────────────────

def generate_foreman_config(
    model: str = "anthropic/claude-sonnet-4-6",
    channel: str = "stable",
    bind: str = "127.0.0.1",
) -> dict:
    """Generate full validated gateway configuration including systemd service."""
    systemd_unit = f"""[Unit]
Description=OpenClaw Gateway
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/openclaw gateway --port 18789 --bind {bind}
Restart=on-failure
RestartSec=5
Environment=NODE_ENV=production
EnvironmentFile=%h/.openclaw_env
CPUQuota=80%
MemoryMax=1G

[Install]
WantedBy=default.target
"""

    config = {
        "model": {
            "provider": "openrouter" if "/" in model else "ollama",
            "model": model,
            "temperature": 0.3,
            "maxTokens": 8192,
        },
        "gateway": {
            "port": 18789,
            "bind": bind,
            "cors": True,
            "rateLimit": {
                "windowMs": 60000,
                "maxRequests": 60,
            },
        },
        "channel": channel,
    }

    return {
        "config": config,
        "systemd_unit": systemd_unit,
        "systemd_path": "~/.config/systemd/user/openclaw-gateway.service",
        "install_commands": [
            f"# Save config",
            f"cat > ~/.openclaw/openclaw.json << 'EOF'\n{config}\nEOF",
            f"# Install systemd service",
            f"mkdir -p ~/.config/systemd/user/",
            f"cat > ~/.config/systemd/user/openclaw-gateway.service << 'EOF'\n{systemd_unit}EOF",
            f"systemctl --user daemon-reload",
            f"systemctl --user enable openclaw-gateway",
            f"systemctl --user start openclaw-gateway",
        ],
    }
