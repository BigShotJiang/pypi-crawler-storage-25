"""Error Diagnostic Patterns — 25+ patterns for diagnose_issue tool.

Each pattern has a regex, severity, category, diagnosis, and fix steps.
Used by the diagnose_issue MCP tool for pattern-matched error diagnosis.
"""

from __future__ import annotations

import re
from typing import Optional


# ── Error Pattern Definitions ─────────────────────────────────────

PATTERNS: list[dict] = [
    # ── Connection & Network ──────────────────────────────────────
    {
        "id": "connection_refused",
        "pattern": r"(?i)(ConnectionRefusedError|ECONNREFUSED|connect call failed|connection refused)",
        "severity": "CRITICAL",
        "category": "network",
        "title": "Connection Refused",
        "diagnosis": "An upstream service (Ollama, OpenRouter, n8n, or database) is not accepting connections.",
        "likely_causes": [
            "Docker container stopped or crashed",
            "Service not started after system reboot",
            "Port not exposed or firewall blocking",
            "Wrong host/port in configuration",
        ],
        "fix_steps": [
            "Check which service is down: `docker ps` or `systemctl status <service>`",
            "Restart the service: `docker start <container>` or `systemctl start <service>`",
            "Verify port is listening: `ss -tlnp | grep <port>`",
            "Check configuration for correct host:port values",
        ],
        "auto_remediation": "wait_and_retry",
    },
    {
        "id": "dns_failure",
        "pattern": r"(?i)(EAI_AGAIN|ENOTFOUND|getaddrinfo|DNS resolution|name resolution failed)",
        "severity": "CRITICAL",
        "category": "network",
        "title": "DNS Resolution Failure",
        "diagnosis": "DNS resolution is failing. Cannot resolve hostnames to IP addresses.",
        "likely_causes": [
            "Tailscale overwrote /etc/resolv.conf (WSL2)",
            "WSL2 auto-generated bad DNS config on restart",
            "Network disconnected (WiFi/Ethernet)",
            "DNS server unreachable",
        ],
        "fix_steps": [
            "Check current DNS: `cat /etc/resolv.conf`",
            "Restore static DNS: `echo 'nameserver 8.8.8.8\\nnameserver 1.1.1.1' | sudo tee /etc/resolv.conf`",
            "Verify: `nslookup google.com 8.8.8.8`",
            "Permanent fix: add `[network]\\ngenerateResolvConf = false` to /etc/wsl.conf",
        ],
        "auto_remediation": "fix_dns",
    },
    {
        "id": "timeout",
        "pattern": r"(?i)(ETIMEDOUT|ESOCKETTIMEDOUT|timeout.*exceeded|request timed out|AbortError.*timeout)",
        "severity": "WARNING",
        "category": "network",
        "title": "Request Timeout",
        "diagnosis": "A network request timed out. The upstream service is reachable but too slow to respond.",
        "likely_causes": [
            "API provider experiencing high load",
            "Large request payload (too many tokens)",
            "Network latency/congestion",
            "Model inference taking too long (large context)",
        ],
        "fix_steps": [
            "Retry the request — often transient",
            "Reduce context window or message count",
            "Check API provider status page",
            "Switch to a faster model if recurring",
        ],
        "auto_remediation": "wait_and_retry",
    },
    {
        "id": "ssl_error",
        "pattern": r"(?i)(SSL_ERROR|CERT_HAS_EXPIRED|unable to verify|certificate|ERR_CERT|self.signed)",
        "severity": "WARNING",
        "category": "network",
        "title": "SSL/TLS Certificate Error",
        "diagnosis": "TLS certificate validation failed. Likely expired or self-signed cert.",
        "likely_causes": [
            "System clock out of sync (common in WSL2)",
            "Expired SSL certificate on upstream service",
            "Corporate proxy intercepting TLS",
            "Self-signed cert without proper CA trust",
        ],
        "fix_steps": [
            "Sync system clock: `sudo ntpdate -s time.nist.gov` or `sudo hwclock -s`",
            "Check cert expiry: `echo | openssl s_client -connect <host>:443 2>/dev/null | openssl x509 -noout -dates`",
            "Update CA certificates: `sudo update-ca-certificates`",
        ],
        "auto_remediation": None,
    },
    # ── Memory & Resources ────────────────────────────────────────
    {
        "id": "heap_oom",
        "pattern": r"(?i)(FATAL ERROR.*heap|heap out of memory|Allocation failed|CALL_AND_RETRY_LAST)",
        "severity": "CRITICAL",
        "category": "memory",
        "title": "JavaScript Heap Out of Memory",
        "diagnosis": "Node.js ran out of heap memory. Process will crash with exit code 134.",
        "likely_causes": [
            "Session bloat — too many/large sessions in ~/.openclaw/agents/main/sessions/",
            "Compaction bug (v2026.3.13) — sessions grow unbounded to 223k+ tokens",
            "Cron storm — all cron jobs fire simultaneously after restart",
            "Memory leak in long-running process",
        ],
        "fix_steps": [
            "Check session dir size: `du -sh ~/.openclaw/agents/main/sessions/`",
            "Clean deleted files: `find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' -delete`",
            "Clean stale locks: `find ~/.openclaw/agents/main/sessions/ -name '*.lock' -mmin +5 -delete`",
            "Clear BM25 cache: `rm -f ~/.openclaw/workspace/memory/*.cache`",
            "Restart OpenClaw: `systemctl --user restart openclaw-gateway`",
            "If recurring: apply compaction safeguard patch",
        ],
        "auto_remediation": "clear_cache_and_restart",
    },
    {
        "id": "oom_killed",
        "pattern": r"(?i)(OOM.?kill|Out of memory.*kill|oom_reaper|Killed process|cannot allocate memory)",
        "severity": "CRITICAL",
        "category": "memory",
        "title": "Process OOM Killed",
        "diagnosis": "Linux kernel OOM killer terminated the process. System-wide memory exhaustion.",
        "likely_causes": [
            "Multiple large models loaded in Ollama simultaneously",
            "Too many Docker containers competing for memory",
            "Node.js + Ollama + other services exceeding total RAM",
            "Memory leak accumulated over hours/days",
        ],
        "fix_steps": [
            "Check what was killed: `dmesg | grep -i 'oom\\|killed' | tail -20`",
            "Check memory usage: `free -h && docker stats --no-stream`",
            "Reduce Ollama memory: lower context window or unload unused models",
            "Add swap: `sudo fallocate -l 4G /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile`",
            "Set resource limits in docker-compose.yml",
        ],
        "auto_remediation": "restart_service",
    },
    {
        "id": "disk_full",
        "pattern": r"(?i)(ENOSPC|No space left|disk full|cannot write|write failed.*space)",
        "severity": "CRITICAL",
        "category": "resources",
        "title": "Disk Space Exhausted",
        "diagnosis": "Filesystem is full. Cannot write logs, sessions, or temp files.",
        "likely_causes": [
            "Log files grew unbounded",
            "Docker images/volumes consuming space",
            "Session files accumulating without cleanup",
            "Large model downloads filling /tmp",
        ],
        "fix_steps": [
            "Check disk: `df -h /`",
            "Find large files: `du -sh /* 2>/dev/null | sort -rh | head -10`",
            "Clean Docker: `docker system prune -f`",
            "Clean old logs: `find ~/.easyclaw/logs/ -name '*.log' -mtime +7 -delete`",
            "Clean session files: `find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' -delete`",
        ],
        "auto_remediation": "clean_disk",
    },
    # ── API & Authentication ──────────────────────────────────────
    {
        "id": "rate_limited",
        "pattern": r"(?i)(429|rate.?limit|too many requests|quota exceeded|RateLimitError)",
        "severity": "WARNING",
        "category": "api",
        "title": "API Rate Limited (429)",
        "diagnosis": "API rate limit hit. Too many requests in the time window.",
        "likely_causes": [
            "Cron jobs making too many concurrent API calls",
            "Sub-agents spawning parallel requests",
            "Rate limit tier too low for usage pattern",
            "Retry loops hammering the API",
        ],
        "fix_steps": [
            "Wait and retry with exponential backoff",
            "Check provider dashboard for rate limit tier",
            "Reduce concurrent cron jobs",
            "Add delay between sub-agent calls",
            "Consider switching to a provider with higher limits",
        ],
        "auto_remediation": "wait_and_retry",
    },
    {
        "id": "auth_failure",
        "pattern": r"(?i)(401|403|Unauthorized|Forbidden|invalid.*key|authentication failed|auth.*error)",
        "severity": "CRITICAL",
        "category": "api",
        "title": "Authentication Failure",
        "diagnosis": "API key or token is invalid, expired, or lacks permissions.",
        "likely_causes": [
            "API key expired or revoked",
            "Wrong key in ~/.openclaw_env",
            "Key doesn't have required permissions",
            "Environment variable not loaded (source ~/.openclaw_env missing)",
        ],
        "fix_steps": [
            "Check key is set: `grep -c API_KEY ~/.openclaw_env`",
            "Test key directly: `curl -H 'Authorization: Bearer $KEY' https://api.example.com/test`",
            "Regenerate key at provider dashboard",
            "Ensure ~/.openclaw_env is sourced in shell profile",
        ],
        "auto_remediation": None,
    },
    {
        "id": "server_error",
        "pattern": r"(?i)(500|502|503|504|Internal Server Error|Bad Gateway|Service Unavailable|Gateway Timeout)",
        "severity": "WARNING",
        "category": "api",
        "title": "Upstream Server Error (5xx)",
        "diagnosis": "The API provider returned a server error. Their infrastructure is having issues.",
        "likely_causes": [
            "API provider outage or degraded performance",
            "Request too large for server to handle",
            "Temporary infrastructure issue",
        ],
        "fix_steps": [
            "Wait 30-60 seconds and retry",
            "Check provider status page",
            "If persistent: switch to alternative provider or local model",
        ],
        "auto_remediation": "wait_and_retry",
    },
    {
        "id": "invalid_api_response",
        "pattern": r"(?i)(unexpected.*response|invalid.*json|JSON\.parse|SyntaxError.*JSON|malformed.*response)",
        "severity": "WARNING",
        "category": "api",
        "title": "Malformed API Response",
        "diagnosis": "Received invalid JSON or unexpected response format from API.",
        "likely_causes": [
            "API endpoint changed or deprecated",
            "Proxy/CDN returning HTML error page",
            "Response truncated due to timeout",
            "Wrong API version or endpoint URL",
        ],
        "fix_steps": [
            "Check the raw response with curl to see what's returned",
            "Verify API endpoint URL is correct",
            "Check if API version has been deprecated",
            "Retry — may be transient",
        ],
        "auto_remediation": "wait_and_retry",
    },
    # ── OpenClaw Process ──────────────────────────────────────────
    {
        "id": "segfault",
        "pattern": r"(?i)(Segmentation fault|SIGSEGV|signal 11|core dumped)",
        "severity": "CRITICAL",
        "category": "process",
        "title": "Segmentation Fault",
        "diagnosis": "Process crashed with a segmentation fault. Memory corruption or native module issue.",
        "likely_causes": [
            "Native Node.js module incompatibility",
            "Corrupted npm installation",
            "System library mismatch after OS update",
        ],
        "fix_steps": [
            "Restart OpenClaw: `systemctl --user restart openclaw-gateway`",
            "Reinstall node modules: `cd ~/.openclaw && npm rebuild`",
            "Check for core dump: `ls /tmp/core.*`",
            "If recurring: reinstall OpenClaw",
        ],
        "auto_remediation": "restart_service",
    },
    {
        "id": "node_fatal",
        "pattern": r"(?i)(FATAL ERROR|node.*fatal|process\.exit|unhandledRejection|uncaughtException)",
        "severity": "CRITICAL",
        "category": "process",
        "title": "Node.js Fatal Error",
        "diagnosis": "Node.js encountered a fatal error and will exit.",
        "likely_causes": [
            "Unhandled promise rejection in async code",
            "Fatal V8 error (heap, stack overflow)",
            "Missing required dependency",
            "Corrupt configuration file",
        ],
        "fix_steps": [
            "Check full error in logs: `tail -50 /tmp/openclaw/*.log`",
            "Restart: `systemctl --user restart openclaw-gateway`",
            "Validate config: `cat ~/.openclaw/openclaw.json | python3 -m json.tool`",
            "Check for broken deps: `cd ~/.openclaw && npm ls 2>&1 | grep ERR`",
        ],
        "auto_remediation": "restart_service",
    },
    {
        "id": "stall_detected",
        "pattern": r"(?i)(stall.*detect|no.*output.*minutes|process.*hung|deadlock|not responding)",
        "severity": "WARNING",
        "category": "process",
        "title": "Process Stall Detected",
        "diagnosis": "Process appears hung — no output for extended period.",
        "likely_causes": [
            "Waiting for API response that will never come",
            "Deadlock in async operations",
            "Blocked on I/O operation",
            "Infinite loop in agent logic",
        ],
        "fix_steps": [
            "Check if process is still alive: `ps aux | grep openclaw`",
            "Check what it's waiting on: `strace -p <PID> -c` (brief)",
            "Graceful restart: `systemctl --user restart openclaw-gateway`",
        ],
        "auto_remediation": "restart_service",
    },
    # ── Sessions & Data ───────────────────────────────────────────
    {
        "id": "session_lock",
        "pattern": r"(?i)(session.*lock|locked.*session|EEXIST.*lock|lock file|resource busy.*lock)",
        "severity": "WARNING",
        "category": "sessions",
        "title": "Session Lock Contention",
        "diagnosis": "A session lock file is preventing access. Usually from a crashed process.",
        "likely_causes": [
            "Previous process crashed without cleaning up lock",
            "Multiple OpenClaw instances running simultaneously",
            "NFS/network filesystem lock issue",
        ],
        "fix_steps": [
            "Remove stale locks: `find ~/.openclaw/agents/main/sessions/ -name '*.lock' -mmin +5 -delete`",
            "Check for multiple processes: `pgrep -a openclaw`",
            "Kill duplicates: `pkill -f openclaw && systemctl --user start openclaw-gateway`",
        ],
        "auto_remediation": "clean_locks",
    },
    {
        "id": "session_bloat",
        "pattern": r"(?i)(session.*bloat|sessions.*large|session.*size.*exceed|too many sessions)",
        "severity": "WARNING",
        "category": "sessions",
        "title": "Session Directory Bloat",
        "diagnosis": "Session directory has grown too large, consuming disk and memory.",
        "likely_causes": [
            "Soft-deleted files not cleaned up",
            "Cron jobs creating sessions without cleanup",
            "Stale lock files accumulating",
        ],
        "fix_steps": [
            "Check size: `du -sh ~/.openclaw/agents/main/sessions/`",
            "Clean deleted: `find ~/.openclaw/agents/main/sessions/ -name '*.deleted.*' -delete`",
            "Clean old locks: `find ~/.openclaw/agents/main/sessions/ -name '*.lock' -mmin +30 -delete`",
            "Count remaining: `ls ~/.openclaw/agents/main/sessions/ | wc -l`",
        ],
        "auto_remediation": "clean_sessions",
    },
    {
        "id": "token_overflow",
        "pattern": r"(?i)(token.*overflow|context.*exceed|maximum.*context|token.*limit|context.*length.*exceed)",
        "severity": "WARNING",
        "category": "sessions",
        "title": "Token/Context Overflow",
        "diagnosis": "A session or request exceeded the model's context window limit.",
        "likely_causes": [
            "Conversation grew too long without compaction",
            "Large file included in context (SOUL.md, MEMORY.md)",
            "Compaction not triggering properly",
            "Model's context window too small for the task",
        ],
        "fix_steps": [
            "Check session sizes: `ls -lhS ~/.openclaw/agents/main/sessions/ | head -5`",
            "Force compaction: restart the session",
            "Reduce workspace file sizes (trim MEMORY.md, SOUL.md)",
            "Switch to a model with larger context window",
        ],
        "auto_remediation": None,
    },
    {
        "id": "compaction_fail",
        "pattern": r"(?i)(compaction.*fail|compact.*error|failed.*compact|summariz.*fail)",
        "severity": "WARNING",
        "category": "sessions",
        "title": "Session Compaction Failure",
        "diagnosis": "Auto-compaction of session history failed. Session will continue growing.",
        "likely_causes": [
            "API error during compaction request",
            "Session too large for compaction model's context",
            "Compaction bug in OpenClaw version",
        ],
        "fix_steps": [
            "Restart the session (forces new compaction)",
            "Check OpenClaw version for known compaction bugs",
            "Clear the specific session and start fresh",
            "Apply compaction safeguard patch if available",
        ],
        "auto_remediation": "restart_service",
    },
    # ── Configuration ─────────────────────────────────────────────
    {
        "id": "config_parse_error",
        "pattern": r"(?i)(config.*parse|invalid.*config|YAML.*error|JSON.*parse.*config|config.*invalid|bad.*configuration)",
        "severity": "CRITICAL",
        "category": "config",
        "title": "Configuration Parse Error",
        "diagnosis": "Configuration file has invalid syntax and cannot be loaded.",
        "likely_causes": [
            "Manually edited config with syntax errors",
            "Truncated file from interrupted write",
            "Wrong format (YAML vs JSON mismatch)",
        ],
        "fix_steps": [
            "Validate JSON: `python3 -m json.tool ~/.openclaw/openclaw.json`",
            "Validate YAML: `python3 -c \"import yaml; yaml.safe_load(open('~/.easyclaw/config.yaml'))\" `",
            "Restore from backup or regenerate default config",
            "Use `easyclaw doctor` to validate all config files",
        ],
        "auto_remediation": None,
    },
    {
        "id": "missing_env",
        "pattern": r"(?i)(missing.*env|environment.*not.*set|undefined.*API_KEY|env.*variable.*required)",
        "severity": "CRITICAL",
        "category": "config",
        "title": "Missing Environment Variable",
        "diagnosis": "A required environment variable is not set.",
        "likely_causes": [
            "~/.openclaw_env not sourced in shell profile",
            "Variable removed or renamed",
            "Docker container missing env var in compose file",
            "Systemd service file missing Environment= line",
        ],
        "fix_steps": [
            "Check if file exists: `cat ~/.openclaw_env`",
            "Source it: `source ~/.openclaw_env`",
            "Add to shell profile: `echo 'source ~/.openclaw_env' >> ~/.bashrc`",
            "For systemd: add `EnvironmentFile=%h/.openclaw_env` to service file",
        ],
        "auto_remediation": None,
    },
    # ── Gateway & Port ────────────────────────────────────────────
    {
        "id": "port_in_use",
        "pattern": r"(?i)(EADDRINUSE|address already in use|port.*already.*bound|listen.*failed)",
        "severity": "CRITICAL",
        "category": "gateway",
        "title": "Port Already in Use",
        "diagnosis": "The gateway port is already bound by another process.",
        "likely_causes": [
            "Previous OpenClaw instance still running",
            "Another service using the same port",
            "Zombie process holding the port",
        ],
        "fix_steps": [
            "Find what's using the port: `ss -tlnp | grep 18789`",
            "Kill the conflicting process or change the port",
            "Check for zombie OpenClaw: `pgrep -a openclaw`",
            "Change port in openclaw.json if needed",
        ],
        "auto_remediation": None,
    },
    {
        "id": "gateway_unreachable",
        "pattern": r"(?i)(gateway.*unreachable|cannot.*connect.*gateway|gateway.*down|18789.*refused)",
        "severity": "CRITICAL",
        "category": "gateway",
        "title": "Gateway Unreachable",
        "diagnosis": "OpenClaw gateway is not responding on its configured port.",
        "likely_causes": [
            "Gateway service not running",
            "Gateway crashed and didn't restart",
            "Firewall blocking the port",
            "Wrong bind address (127.0.0.1 vs 0.0.0.0)",
        ],
        "fix_steps": [
            "Check service: `systemctl --user status openclaw-gateway`",
            "Restart: `systemctl --user restart openclaw-gateway`",
            "Check port: `ss -tlnp | grep 18789`",
            "Check bind address in openclaw.json",
        ],
        "auto_remediation": "restart_service",
    },
    {
        "id": "cloudflare_tunnel",
        "pattern": r"(?i)(tunnel.*error|cloudflared|ERR.*tunnel|tunnel.*disconnect|502.*cloudflare)",
        "severity": "WARNING",
        "category": "gateway",
        "title": "Cloudflare Tunnel Error",
        "diagnosis": "Cloudflare tunnel is down or misconfigured.",
        "likely_causes": [
            "cloudflared service stopped",
            "Tunnel credentials expired",
            "Backend service (gateway) not running",
            "DNS records not pointing to tunnel",
        ],
        "fix_steps": [
            "Check tunnel: `systemctl status cloudflared` (Linux) or Services panel (Windows)",
            "Restart tunnel: `systemctl restart cloudflared`",
            "Verify backend is up: `curl http://localhost:18789/health`",
            "Check tunnel status: `cloudflared tunnel info`",
        ],
        "auto_remediation": None,
    },
    # ── Cron & Scheduling ─────────────────────────────────────────
    {
        "id": "cron_storm",
        "pattern": r"(?i)(cron.*storm|all.*cron.*fired|simultaneous.*cron|cron.*burst|multiple.*cron.*same)",
        "severity": "WARNING",
        "category": "cron",
        "title": "Cron Storm",
        "diagnosis": "Multiple cron jobs fired simultaneously, overwhelming resources.",
        "likely_causes": [
            "WSL2 restart — all cron timers reset, everything fires at once",
            "System clock jump forward triggering catch-up",
            "Missing stagger/jitter in cron schedules",
        ],
        "fix_steps": [
            "Reset cron states to prevent catch-up firing",
            "Add jitter to cron schedules (stagger by 5-10 min)",
            "Reduce number of concurrent cron jobs",
            "Set `maxConcurrent` in cron config if supported",
        ],
        "auto_remediation": None,
    },
    {
        "id": "cron_failure",
        "pattern": r"(?i)(cron.*fail|scheduled.*task.*error|job.*failed|cron.*error)",
        "severity": "WARNING",
        "category": "cron",
        "title": "Cron Job Failure",
        "diagnosis": "A scheduled cron job failed to execute.",
        "likely_causes": [
            "API key expired or missing",
            "Network connectivity issue during job execution",
            "Job script has syntax error",
            "Resource limits (memory, disk) hit during execution",
        ],
        "fix_steps": [
            "Check cron logs: `grep 'cron' /tmp/openclaw/*.log | tail -20`",
            "Verify environment: `source ~/.openclaw_env && env | grep API`",
            "Run the job manually to see the error",
            "Check job definition in ~/.openclaw/cron/jobs.json",
        ],
        "auto_remediation": None,
    },
    # ── Docker ────────────────────────────────────────────────────
    {
        "id": "docker_error",
        "pattern": r"(?i)(docker.*error|container.*exit|docker.*fail|cannot connect.*docker|docker daemon)",
        "severity": "CRITICAL",
        "category": "docker",
        "title": "Docker Error",
        "diagnosis": "Docker daemon or container error.",
        "likely_causes": [
            "Docker daemon not running",
            "Container OOM killed",
            "Image pull failure",
            "Volume mount issue (especially WSL2 → Windows paths)",
        ],
        "fix_steps": [
            "Check Docker: `docker info`",
            "Check containers: `docker ps -a`",
            "Restart container: `docker restart <container>`",
            "Check logs: `docker logs <container> --tail 50`",
            "For WSL2: ensure Docker Desktop is running",
        ],
        "auto_remediation": None,
    },
    {
        "id": "wsl2_mount",
        "pattern": r"(?i)(not a shared.*mount|mount propagation|rshared|permission denied.*/mnt)",
        "severity": "CRITICAL",
        "category": "docker",
        "title": "WSL2 Mount Propagation Error",
        "diagnosis": "Docker bind mounts failing due to WSL2 mount propagation.",
        "likely_causes": [
            "WSL2 default mount propagation is 'private' not 'shared'",
            "Missing `mount --make-rshared /` after WSL restart",
            "/etc/wsl.conf missing the boot command fix",
        ],
        "fix_steps": [
            "Immediate fix: `sudo mount --make-rshared /`",
            "Permanent fix: add to /etc/wsl.conf under [boot]: `command=\"mount --make-rshared /\"`",
            "Restart WSL: `wsl --shutdown` from PowerShell, then reopen",
        ],
        "auto_remediation": None,
    },
    # ── Permissions ───────────────────────────────────────────────
    {
        "id": "permission_denied",
        "pattern": r"(?i)(EACCES|Permission denied|EPERM|operation not permitted|access denied)",
        "severity": "WARNING",
        "category": "permissions",
        "title": "Permission Denied",
        "diagnosis": "Operation blocked by filesystem or OS permissions.",
        "likely_causes": [
            "File owned by root, process running as user",
            "SELinux or AppArmor blocking access",
            "Windows NTFS permissions on WSL2 mounted drive",
            "Docker volume permissions mismatch",
        ],
        "fix_steps": [
            "Check ownership: `ls -la <path>`",
            "Fix ownership: `sudo chown -R $USER:$USER <path>`",
            "For Docker volumes: match UID/GID in container",
            "For WSL2 Windows mounts: check /etc/wsl.conf [automount] metadata option",
        ],
        "auto_remediation": None,
    },
]


def diagnose(error_text: str, context: str = "") -> dict:
    """Match error text against all known patterns and return diagnosis."""
    combined = f"{error_text} {context}".strip()
    matches = []

    for pattern in PATTERNS:
        if re.search(pattern["pattern"], combined):
            matches.append({
                "pattern_id": pattern["id"],
                "title": pattern["title"],
                "severity": pattern["severity"],
                "category": pattern["category"],
                "diagnosis": pattern["diagnosis"],
                "likely_causes": pattern["likely_causes"],
                "fix_steps": pattern["fix_steps"],
                "auto_remediation": pattern["auto_remediation"],
            })

    if not matches:
        return {
            "matched": False,
            "message": "No known error pattern matched. This may be a new issue.",
            "suggestion": "Use learn_solution to add this error pattern to the knowledge base.",
            "error_text": error_text[:500],
        }

    # Sort by severity (CRITICAL first)
    severity_order = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
    matches.sort(key=lambda m: severity_order.get(m["severity"], 99))

    return {
        "matched": True,
        "count": len(matches),
        "diagnoses": matches,
    }
