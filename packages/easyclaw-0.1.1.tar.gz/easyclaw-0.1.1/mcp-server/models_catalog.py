"""AI Model Catalog — pricing, capabilities, and recommendations.

Comprehensive model database covering OpenRouter, Ollama local, and
direct API providers. Used by get_model_recommendation and estimate_cost tools.
"""

from __future__ import annotations

# ── Model Catalog ─────────────────────────────────────────────────
# Categories: coding, general, fast, cheap, vision, reasoning, local
# Speed tiers: fast, medium, slow
# Quality tiers: low, medium, high, frontier

MODELS = [
    # ── Anthropic (via OpenRouter) ────────────────────────────────
    {
        "id": "anthropic/claude-sonnet-4-6",
        "provider": "anthropic",
        "name": "Claude Sonnet 4.6",
        "category": "coding",
        "context_window": 200000,
        "input_cost_per_mtok": 3.0,
        "output_cost_per_mtok": 15.0,
        "speed_tier": "medium",
        "quality_tier": "high",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Best overall coding model. Strong tool use, vision, long context. Recommended default for OpenClaw.",
    },
    {
        "id": "anthropic/claude-opus-4-6",
        "provider": "anthropic",
        "name": "Claude Opus 4.6",
        "category": "reasoning",
        "context_window": 200000,
        "input_cost_per_mtok": 15.0,
        "output_cost_per_mtok": 75.0,
        "speed_tier": "slow",
        "quality_tier": "frontier",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Most capable model. Best for complex reasoning, architecture decisions, difficult bugs. Expensive.",
    },
    {
        "id": "anthropic/claude-haiku-4-5",
        "provider": "anthropic",
        "name": "Claude Haiku 4.5",
        "category": "fast",
        "context_window": 200000,
        "input_cost_per_mtok": 0.8,
        "output_cost_per_mtok": 4.0,
        "speed_tier": "fast",
        "quality_tier": "medium",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Fast and cheap. Good for simple tasks, triage, quick lookups. Good sub-agent model.",
    },
    # ── OpenAI (via OpenRouter) ───────────────────────────────────
    {
        "id": "openai/gpt-4.1",
        "provider": "openai",
        "name": "GPT-4.1",
        "category": "coding",
        "context_window": 1047576,
        "input_cost_per_mtok": 2.0,
        "output_cost_per_mtok": 8.0,
        "speed_tier": "medium",
        "quality_tier": "high",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Strong coding model with massive 1M context. Good instruction following.",
    },
    {
        "id": "openai/gpt-4.1-mini",
        "provider": "openai",
        "name": "GPT-4.1 Mini",
        "category": "fast",
        "context_window": 1047576,
        "input_cost_per_mtok": 0.4,
        "output_cost_per_mtok": 1.6,
        "speed_tier": "fast",
        "quality_tier": "medium",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Very cheap with huge context. Good for bulk processing, summarization.",
    },
    {
        "id": "openai/o3",
        "provider": "openai",
        "name": "o3",
        "category": "reasoning",
        "context_window": 200000,
        "input_cost_per_mtok": 10.0,
        "output_cost_per_mtok": 40.0,
        "speed_tier": "slow",
        "quality_tier": "frontier",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Advanced reasoning model. Best for math, science, complex logic. Slow but very capable.",
    },
    {
        "id": "openai/o4-mini",
        "provider": "openai",
        "name": "o4-mini",
        "category": "reasoning",
        "context_window": 200000,
        "input_cost_per_mtok": 1.1,
        "output_cost_per_mtok": 4.4,
        "speed_tier": "medium",
        "quality_tier": "high",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Fast reasoning model. Great balance of cost and capability for analytical tasks.",
    },
    # ── Google (via OpenRouter) ───────────────────────────────────
    {
        "id": "google/gemini-2.5-pro",
        "provider": "google",
        "name": "Gemini 2.5 Pro",
        "category": "coding",
        "context_window": 1048576,
        "input_cost_per_mtok": 1.25,
        "output_cost_per_mtok": 10.0,
        "speed_tier": "medium",
        "quality_tier": "high",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Google's best model. Massive 1M context, strong coding, competitive pricing.",
    },
    {
        "id": "google/gemini-2.5-flash",
        "provider": "google",
        "name": "Gemini 2.5 Flash",
        "category": "fast",
        "context_window": 1048576,
        "input_cost_per_mtok": 0.15,
        "output_cost_per_mtok": 0.60,
        "speed_tier": "fast",
        "quality_tier": "medium",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Extremely cheap with 1M context. Best price-to-performance for high-volume use.",
    },
    # ── DeepSeek (via OpenRouter) ─────────────────────────────────
    {
        "id": "deepseek/deepseek-r1",
        "provider": "deepseek",
        "name": "DeepSeek R1",
        "category": "reasoning",
        "context_window": 164000,
        "input_cost_per_mtok": 0.55,
        "output_cost_per_mtok": 2.19,
        "speed_tier": "slow",
        "quality_tier": "high",
        "supports_tools": False,
        "supports_vision": False,
        "notes": "Open-source reasoning model. Very cheap. No tool use — use for analysis only.",
    },
    {
        "id": "deepseek/deepseek-chat-v3-0324",
        "provider": "deepseek",
        "name": "DeepSeek V3",
        "category": "cheap",
        "context_window": 164000,
        "input_cost_per_mtok": 0.27,
        "output_cost_per_mtok": 1.10,
        "speed_tier": "fast",
        "quality_tier": "medium",
        "supports_tools": True,
        "supports_vision": False,
        "notes": "Cheapest capable model. Good for bulk tasks. MoE architecture.",
    },
    # ── Meta (via OpenRouter) ─────────────────────────────────────
    {
        "id": "meta-llama/llama-4-maverick",
        "provider": "meta",
        "name": "Llama 4 Maverick",
        "category": "general",
        "context_window": 1048576,
        "input_cost_per_mtok": 0.20,
        "output_cost_per_mtok": 0.60,
        "speed_tier": "fast",
        "quality_tier": "medium",
        "supports_tools": True,
        "supports_vision": True,
        "notes": "Open-source, very cheap, 1M context. Good for general tasks.",
    },
    # ── Qwen (via OpenRouter) ─────────────────────────────────────
    {
        "id": "qwen/qwen3-235b-a22b",
        "provider": "qwen",
        "name": "Qwen 3 235B",
        "category": "coding",
        "context_window": 131072,
        "input_cost_per_mtok": 0.20,
        "output_cost_per_mtok": 0.60,
        "speed_tier": "medium",
        "quality_tier": "high",
        "supports_tools": True,
        "supports_vision": False,
        "notes": "Alibaba's best. MoE (22B active). Very strong coding at rock-bottom prices.",
    },
    {
        "id": "qwen/qwen3-32b",
        "provider": "qwen",
        "name": "Qwen 3 32B",
        "category": "cheap",
        "context_window": 131072,
        "input_cost_per_mtok": 0.10,
        "output_cost_per_mtok": 0.30,
        "speed_tier": "fast",
        "quality_tier": "medium",
        "supports_tools": True,
        "supports_vision": False,
        "notes": "Small but capable. Runs well locally on Ollama. Good for sub-agents.",
    },
    # ── Local Ollama Models ───────────────────────────────────────
    {
        "id": "ollama/glm-4.7-flash",
        "provider": "ollama",
        "name": "GLM-4.7 Flash (Q4_K_M)",
        "category": "local",
        "context_window": 40960,
        "input_cost_per_mtok": 0.0,
        "output_cost_per_mtok": 0.0,
        "speed_tier": "fast",
        "quality_tier": "medium",
        "supports_tools": True,
        "supports_vision": False,
        "notes": "30B MoE (3B active), 98 tok/s on 3090 Ti. $0 cost. Currently running on Rick's setup.",
    },
    {
        "id": "ollama/qwen3-32b",
        "provider": "ollama",
        "name": "Qwen 3 32B (Q4_K_M)",
        "category": "local",
        "context_window": 32768,
        "input_cost_per_mtok": 0.0,
        "output_cost_per_mtok": 0.0,
        "speed_tier": "medium",
        "quality_tier": "medium",
        "supports_tools": True,
        "supports_vision": False,
        "notes": "32B dense model. Slower than GLM Flash but higher quality. Good for complex local tasks.",
    },
    {
        "id": "ollama/qwen3-8b",
        "provider": "ollama",
        "name": "Qwen 3 8B",
        "category": "local",
        "context_window": 32768,
        "input_cost_per_mtok": 0.0,
        "output_cost_per_mtok": 0.0,
        "speed_tier": "fast",
        "quality_tier": "low",
        "supports_tools": True,
        "supports_vision": False,
        "notes": "Small and fast. Good for simple local tasks, classification, routing.",
    },
    {
        "id": "ollama/llama3.1-8b",
        "provider": "ollama",
        "name": "Llama 3.1 8B",
        "category": "local",
        "context_window": 131072,
        "input_cost_per_mtok": 0.0,
        "output_cost_per_mtok": 0.0,
        "speed_tier": "fast",
        "quality_tier": "low",
        "supports_tools": True,
        "supports_vision": False,
        "notes": "Meta's workhorse. Large context for local model. Good baseline.",
    },
    {
        "id": "ollama/deepseek-coder-v2",
        "provider": "ollama",
        "name": "DeepSeek Coder V2 (16B)",
        "category": "local",
        "context_window": 131072,
        "input_cost_per_mtok": 0.0,
        "output_cost_per_mtok": 0.0,
        "speed_tier": "medium",
        "quality_tier": "medium",
        "supports_tools": False,
        "supports_vision": False,
        "notes": "Specialized coding model. Strong at code generation and completion.",
    },
]


# ── Recommendation Logic ─────────────────────────────────────────

USE_CASE_MAP = {
    "coding": {
        "description": "Software development, code generation, debugging, refactoring",
        "recommended": ["anthropic/claude-sonnet-4-6", "google/gemini-2.5-pro", "qwen/qwen3-235b-a22b"],
        "budget": ["qwen/qwen3-32b", "deepseek/deepseek-chat-v3-0324"],
        "local": ["ollama/glm-4.7-flash", "ollama/deepseek-coder-v2"],
    },
    "general": {
        "description": "Everyday tasks, writing, conversation, Q&A",
        "recommended": ["anthropic/claude-sonnet-4-6", "openai/gpt-4.1"],
        "budget": ["meta-llama/llama-4-maverick", "google/gemini-2.5-flash"],
        "local": ["ollama/qwen3-32b", "ollama/glm-4.7-flash"],
    },
    "fast": {
        "description": "Speed-critical tasks, real-time responses, sub-agents",
        "recommended": ["anthropic/claude-haiku-4-5", "google/gemini-2.5-flash"],
        "budget": ["openai/gpt-4.1-mini", "deepseek/deepseek-chat-v3-0324"],
        "local": ["ollama/glm-4.7-flash", "ollama/qwen3-8b"],
    },
    "cheap": {
        "description": "Cost-sensitive, high-volume, bulk processing",
        "recommended": ["google/gemini-2.5-flash", "deepseek/deepseek-chat-v3-0324"],
        "budget": ["qwen/qwen3-32b", "meta-llama/llama-4-maverick"],
        "local": ["ollama/glm-4.7-flash", "ollama/qwen3-8b"],
    },
    "reasoning": {
        "description": "Complex analysis, math, science, multi-step logic",
        "recommended": ["anthropic/claude-opus-4-6", "openai/o3"],
        "budget": ["openai/o4-mini", "deepseek/deepseek-r1"],
        "local": ["ollama/qwen3-32b"],
    },
    "vision": {
        "description": "Image analysis, screenshots, diagrams, OCR",
        "recommended": ["anthropic/claude-sonnet-4-6", "openai/gpt-4.1"],
        "budget": ["google/gemini-2.5-flash", "anthropic/claude-haiku-4-5"],
        "local": [],
    },
    "local": {
        "description": "Offline, private, zero-cost inference via Ollama",
        "recommended": ["ollama/glm-4.7-flash", "ollama/qwen3-32b"],
        "budget": ["ollama/qwen3-8b", "ollama/llama3.1-8b"],
        "local": ["ollama/glm-4.7-flash", "ollama/qwen3-32b", "ollama/qwen3-8b"],
    },
}


def get_recommendation(use_case: str, models_list: list[dict] = MODELS) -> dict:
    """Get model recommendations for a use case."""
    use_case_lower = use_case.lower().strip()

    mapping = USE_CASE_MAP.get(use_case_lower)
    if not mapping:
        # Try fuzzy match
        for key, val in USE_CASE_MAP.items():
            if use_case_lower in key or key in use_case_lower:
                mapping = val
                use_case_lower = key
                break

    if not mapping:
        return {
            "use_case": use_case,
            "error": f"Unknown use case. Available: {', '.join(USE_CASE_MAP.keys())}",
        }

    models_by_id = {m["id"]: m for m in models_list}

    def _enrich(model_ids: list[str]) -> list[dict]:
        result = []
        for mid in model_ids:
            m = models_by_id.get(mid)
            if m:
                cost_str = "FREE (local)" if m["input_cost_per_mtok"] == 0 else (
                    f"${m['input_cost_per_mtok']:.2f} / ${m['output_cost_per_mtok']:.2f} per MTok"
                )
                result.append({
                    "id": m["id"],
                    "name": m["name"],
                    "provider": m["provider"],
                    "cost": cost_str,
                    "speed": m["speed_tier"],
                    "quality": m["quality_tier"],
                    "context": m["context_window"],
                    "notes": m["notes"],
                })
        return result

    return {
        "use_case": use_case_lower,
        "description": mapping["description"],
        "recommended": _enrich(mapping["recommended"]),
        "budget_alternatives": _enrich(mapping["budget"]),
        "local_options": _enrich(mapping["local"]),
    }


def estimate_monthly_cost(
    model_id: str,
    daily_messages: int,
    avg_input_tokens: int = 2000,
    avg_output_tokens: int = 1000,
    models_list: list[dict] = MODELS,
) -> dict:
    """Estimate monthly cost for a model given usage pattern."""
    models_by_id = {m["id"]: m for m in models_list}
    model = models_by_id.get(model_id)

    if not model:
        # Try partial match
        for m in models_list:
            if model_id.lower() in m["id"].lower() or model_id.lower() in m["name"].lower():
                model = m
                break

    if not model:
        return {"error": f"Model not found: {model_id}. Use get_model_recommendation to see available models."}

    monthly_messages = daily_messages * 30
    monthly_input_tokens = monthly_messages * avg_input_tokens
    monthly_output_tokens = monthly_messages * avg_output_tokens

    input_cost = (monthly_input_tokens / 1_000_000) * model["input_cost_per_mtok"]
    output_cost = (monthly_output_tokens / 1_000_000) * model["output_cost_per_mtok"]
    total_cost = input_cost + output_cost

    # Comparison table
    comparisons = []
    for m in sorted(models_list, key=lambda x: x["input_cost_per_mtok"]):
        if m["input_cost_per_mtok"] == 0 and m["provider"] == "ollama":
            continue  # Skip local models in cost comparison
        m_input = (monthly_input_tokens / 1_000_000) * m["input_cost_per_mtok"]
        m_output = (monthly_output_tokens / 1_000_000) * m["output_cost_per_mtok"]
        comparisons.append({
            "model": m["name"],
            "monthly_cost": round(m_input + m_output, 2),
            "quality": m["quality_tier"],
        })

    return {
        "model": model["name"],
        "provider": model["provider"],
        "daily_messages": daily_messages,
        "monthly_messages": monthly_messages,
        "avg_input_tokens": avg_input_tokens,
        "avg_output_tokens": avg_output_tokens,
        "monthly_input_tokens": monthly_input_tokens,
        "monthly_output_tokens": monthly_output_tokens,
        "input_cost": round(input_cost, 2),
        "output_cost": round(output_cost, 2),
        "total_monthly_cost": round(total_cost, 2),
        "is_local": model["provider"] == "ollama",
        "note": "FREE — local Ollama model, no API costs" if model["provider"] == "ollama" else None,
        "comparisons": comparisons[:8],
    }
