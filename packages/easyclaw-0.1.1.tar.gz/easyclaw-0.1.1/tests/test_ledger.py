"""Tests for the fix ledger and circuit breaker."""

import time
import json
import pytest
from easyclaw.ledger import FixLedger, LedgerEntry, CircuitBreaker


@pytest.fixture
def ledger(tmp_easyclaw_home):
    return FixLedger(tmp_easyclaw_home / "state")


def make_entry(success=True, restart=False, ts=None):
    return LedgerEntry(
        timestamp=ts or time.time(),
        error_hash="abc123",
        event_type="connection_refused",
        pattern_name="connection_refused",
        severity="WARNING",
        action_name="wait_and_check",
        action_type="command",
        success=success,
        duration=1.5,
        commands_run=["sleep 5"],
        output="ok",
        restart_performed=restart,
    )


class TestFixLedger:

    def test_record_and_retrieve(self, ledger):
        entry = make_entry()
        ledger.record(entry)
        assert len(ledger.recent_entries) == 1
        assert ledger.recent_entries[0].success is True

    def test_persists_to_file(self, ledger):
        entry = make_entry()
        ledger.record(entry)
        ledger_file = ledger.ledger_dir / "fix-ledger.jsonl"
        assert ledger_file.exists()
        data = json.loads(ledger_file.read_text().strip())
        assert data["event_type"] == "connection_refused"
        assert data["success"] is True

    def test_multiple_entries(self, ledger):
        for _ in range(5):
            ledger.record(make_entry())
        assert len(ledger.recent_entries) == 5

    def test_stats_empty(self, ledger):
        stats = ledger.get_stats()
        assert stats["total"] == 0
        assert stats["success"] == 0

    def test_stats_mixed(self, ledger):
        ledger.record(make_entry(success=True))
        ledger.record(make_entry(success=False))
        ledger.record(make_entry(success=True, restart=True))
        stats = ledger.get_stats()
        assert stats["total"] == 3
        assert stats["success"] == 2
        assert stats["failed"] == 1
        assert stats["restarts"] == 1

    def test_count_restarts_in_window(self, ledger):
        now = time.time()
        ledger.record(make_entry(restart=True, ts=now - 100))
        ledger.record(make_entry(restart=True, ts=now - 50))
        ledger.record(make_entry(restart=True, ts=now - 700))  # outside window
        assert ledger.count_restarts_in_window(600) == 2

    def test_ring_buffer_max(self, tmp_easyclaw_home):
        ledger = FixLedger(tmp_easyclaw_home / "state", max_memory=3)
        for _ in range(5):
            ledger.record(make_entry())
        assert len(ledger.recent_entries) == 3

    def test_entry_to_json(self):
        entry = make_entry()
        data = json.loads(entry.to_json())
        assert "timestamp" in data
        assert "commands_run" in data


class TestCircuitBreaker:

    def test_not_tripped_initially(self, ledger):
        breaker = CircuitBreaker(ledger, max_attempts=3, window_seconds=600)
        assert not breaker.is_tripped

    def test_trips_after_max_restarts(self, ledger):
        now = time.time()
        for i in range(3):
            ledger.record(make_entry(restart=True, ts=now - i))
        breaker = CircuitBreaker(ledger, max_attempts=3, window_seconds=600)
        assert breaker.check_and_trip() is True
        assert breaker.is_tripped

    def test_does_not_trip_below_threshold(self, ledger):
        now = time.time()
        for i in range(2):
            ledger.record(make_entry(restart=True, ts=now - i))
        breaker = CircuitBreaker(ledger, max_attempts=3, window_seconds=600)
        assert breaker.check_and_trip() is False

    def test_auto_resets_after_window(self, ledger):
        now = time.time()
        for i in range(3):
            ledger.record(make_entry(restart=True, ts=now - i))
        breaker = CircuitBreaker(ledger, max_attempts=3, window_seconds=600)
        breaker.check_and_trip()
        assert breaker.is_tripped
        # Simulate window expiring
        breaker._trip_time = now - 700
        assert not breaker.is_tripped
