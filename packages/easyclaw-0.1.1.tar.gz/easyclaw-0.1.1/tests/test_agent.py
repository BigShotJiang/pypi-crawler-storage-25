"""Tests for the agent brain (Phase 6)."""

import asyncio
import json
import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from easyclaw.agent import (
    AgentBrain,
    InvocationSummary,
    _build_system_prompt,
    _truncate,
    LOCAL_TOOLS,
    MCP_TOOLS,
    MAX_RESULT_CHARS,
)
from easyclaw.classifier import Event, EventType, Severity
from easyclaw.ledger import CircuitBreaker, FixLedger, LedgerEntry


# ── Fixtures ──────────────────────────────────────────────────────────


def _make_config(overrides=None):
    """Create a minimal mock config."""
    settings = {
        "openrouter_api_key": "sk-test-key",
        "openrouter_model": "z-ai/glm-4.7-flash",
        "agent_enabled": True,
        "agent_batch_window": 1,
        "agent_cooldown": 1,
        "agent_max_turns": 5,
        "agent_temperature": 0.1,
    }
    if overrides:
        settings.update(overrides)

    config = MagicMock()
    config.settings = settings
    config.platform.system = "Linux"
    config.platform.is_wsl = False
    return config


def _make_event(
    event_type=EventType.PROCESS_CRASH,
    severity=Severity.CRITICAL,
    line="FATAL ERROR: heap out of memory",
    pattern_name="oom_pattern",
    source="extraction.log",
):
    return Event(
        event_type=event_type,
        severity=severity,
        source=source,
        line=line,
        pattern_name=pattern_name,
        context_lines=["line1", "line2"],
    )


@pytest.fixture
def agent(tmp_easyclaw_home):
    config = _make_config()
    executor = MagicMock()
    restart_mgr = MagicMock()
    ledger = FixLedger(tmp_easyclaw_home / "state")
    breaker = CircuitBreaker(ledger, max_attempts=3, window_seconds=600)
    alert_pipeline = MagicMock()
    sandbox = MagicMock()
    sandbox.validate_command.return_value = (True, "")

    return AgentBrain(
        config=config,
        executor=executor,
        restart_mgr=restart_mgr,
        ledger=ledger,
        breaker=breaker,
        alert_pipeline=alert_pipeline,
        sandbox=sandbox,
    )


@pytest.fixture
def agent_no_key(tmp_easyclaw_home):
    config = _make_config({"openrouter_api_key": ""})
    ledger = FixLedger(tmp_easyclaw_home / "state")
    breaker = CircuitBreaker(ledger, max_attempts=3, window_seconds=600)
    return AgentBrain(
        config=config,
        executor=MagicMock(),
        restart_mgr=MagicMock(),
        ledger=ledger,
        breaker=breaker,
        alert_pipeline=MagicMock(),
    )


# ── Availability tests ───────────────────────────────────────────────


class TestAgentAvailability:
    def test_available_with_key(self, agent):
        assert agent.is_available is True

    def test_not_available_without_key(self, tmp_easyclaw_home):
        config = _make_config({"openrouter_api_key": ""})
        ledger = FixLedger(tmp_easyclaw_home / "state")
        breaker = CircuitBreaker(ledger, max_attempts=3, window_seconds=600)
        a = AgentBrain(
            config=config, executor=MagicMock(), restart_mgr=MagicMock(),
            ledger=ledger, breaker=breaker, alert_pipeline=MagicMock(),
        )
        assert a.is_available is False

    def test_not_available_when_disabled(self, tmp_easyclaw_home):
        config = _make_config({"agent_enabled": False})
        ledger = FixLedger(tmp_easyclaw_home / "state")
        breaker = CircuitBreaker(ledger, max_attempts=3, window_seconds=600)
        a = AgentBrain(
            config=config, executor=MagicMock(), restart_mgr=MagicMock(),
            ledger=ledger, breaker=breaker, alert_pipeline=MagicMock(),
        )
        assert a.is_available is False

    def test_not_available_after_auth_failure(self, agent):
        agent._disabled_reason = "Auth failed (HTTP 401)"
        assert agent.is_available is False


# ── Event enqueue tests ──────────────────────────────────────────────


class TestEventEnqueue:
    def test_enqueue_critical_event(self, agent):
        event = _make_event(severity=Severity.CRITICAL)
        agent.enqueue(event)
        assert agent._event_queue.qsize() == 1

    def test_enqueue_warning_event(self, agent):
        event = _make_event(severity=Severity.WARNING)
        agent.enqueue(event)
        assert agent._event_queue.qsize() == 1

    def test_skip_info_events(self, agent):
        event = _make_event(severity=Severity.INFO)
        agent.enqueue(event)
        assert agent._event_queue.qsize() == 0

    def test_queue_full_drops_event(self, agent):
        # Fill the queue
        for _ in range(100):
            agent._event_queue.put_nowait(
                _make_event(severity=Severity.CRITICAL)
            )
        # 101st should be dropped (no exception)
        agent.enqueue(_make_event(severity=Severity.CRITICAL))
        assert agent._event_queue.qsize() == 100


# ── Tool definitions tests ───────────────────────────────────────────


class TestToolDefinitions:
    def test_local_tools_count(self):
        assert len(LOCAL_TOOLS) == 4

    def test_mcp_tools_count(self):
        assert len(MCP_TOOLS) == 6

    def test_tool_names_unique(self):
        all_tools = LOCAL_TOOLS + MCP_TOOLS
        names = [t["function"]["name"] for t in all_tools]
        assert len(names) == len(set(names))

    def test_get_tools_without_mcp(self, agent):
        agent.mcp = None
        tools = agent._get_tool_definitions()
        assert len(tools) == len(LOCAL_TOOLS)

    def test_get_tools_with_mcp(self, agent):
        agent.mcp = MagicMock()
        agent.mcp.is_configured = True
        tools = agent._get_tool_definitions()
        assert len(tools) == len(LOCAL_TOOLS) + len(MCP_TOOLS)


# ── Event formatting tests ───────────────────────────────────────────


class TestEventFormatting:
    def test_format_single_event(self, agent):
        event = _make_event()
        result = agent._format_events([event])
        assert "Event 1" in result
        assert "CRITICAL" in result
        assert "process_crash" in result
        assert "heap out of memory" in result

    def test_format_multiple_events(self, agent):
        events = [
            _make_event(event_type=EventType.PROCESS_CRASH),
            _make_event(event_type=EventType.CONNECTION_REFUSED),
        ]
        result = agent._format_events(events)
        assert "Event 1" in result
        assert "Event 2" in result

    def test_format_includes_context_lines(self, agent):
        event = _make_event()
        result = agent._format_events([event])
        assert "line2" in result


# ── Tool execution tests ─────────────────────────────────────────────


class TestToolExecution:
    @pytest.mark.asyncio
    async def test_shell_command_success(self, agent):
        from easyclaw.executor import CommandResult
        agent.executor.execute = AsyncMock(return_value=CommandResult(
            command="echo hello",
            return_code=0,
            stdout="hello\n",
            stderr="",
            duration=0.1,
        ))

        result = await agent._execute_tool("execute_shell_command", {"command": "echo hello"})
        data = json.loads(result)
        assert data["return_code"] == 0
        assert "hello" in data["stdout"]

    @pytest.mark.asyncio
    async def test_shell_command_blocked_by_sandbox(self, agent):
        agent.sandbox.validate_command.return_value = (False, "dangerous command")

        result = await agent._execute_tool(
            "execute_shell_command", {"command": "rm -rf /"}
        )
        data = json.loads(result)
        assert data["blocked"] is True
        assert "dangerous" in data["reason"]

    @pytest.mark.asyncio
    async def test_shell_no_command(self, agent):
        result = await agent._execute_tool("execute_shell_command", {})
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_read_file_success(self, agent, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("line1\nline2\nline3\n")
        agent.sandbox.validate_command.return_value = (True, "")

        result = await agent._execute_tool("read_file", {"path": str(test_file)})
        assert "line1" in result
        assert "line3" in result

    @pytest.mark.asyncio
    async def test_read_file_not_found(self, agent):
        agent.sandbox.validate_command.return_value = (True, "")
        result = await agent._execute_tool("read_file", {"path": "/nonexistent/file.txt"})
        data = json.loads(result)
        assert "error" in data
        assert "not found" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_restart_blocked_by_circuit_breaker(self, agent):
        agent.openclaw = MagicMock()  # must have an OpenClaw instance
        agent.breaker._tripped = True
        agent.breaker._trip_time = time.time()  # prevent auto-reset
        result = await agent._execute_tool("restart_openclaw", {})
        data = json.loads(result)
        assert "TRIPPED" in data["error"]

    @pytest.mark.asyncio
    async def test_restart_no_openclaw(self, agent):
        agent.openclaw = None
        result = await agent._execute_tool("restart_openclaw", {})
        data = json.loads(result)
        assert "cannot restart" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_recent_logs_no_openclaw(self, agent):
        agent.openclaw = None
        result = await agent._execute_tool(
            "list_recent_logs", {"source": "extraction.log"}
        )
        data = json.loads(result)
        assert "error" in data

    @pytest.mark.asyncio
    async def test_unknown_tool(self, agent):
        result = await agent._execute_tool("unknown_tool", {})
        data = json.loads(result)
        assert "Unknown tool" in data["error"]

    @pytest.mark.asyncio
    async def test_mcp_tool_not_configured(self, agent):
        agent.mcp = None
        result = await agent._execute_tool("mcp_diagnose_issue", {"error_text": "test"})
        data = json.loads(result)
        assert "not configured" in data["error"]


# ── Chat interface tests ─────────────────────────────────────────────


class TestChatInterface:
    @pytest.mark.asyncio
    async def test_chat_not_available(self, tmp_easyclaw_home):
        config = _make_config({"openrouter_api_key": ""})
        ledger = FixLedger(tmp_easyclaw_home / "state")
        breaker = CircuitBreaker(ledger, max_attempts=3, window_seconds=600)
        a = AgentBrain(
            config=config, executor=MagicMock(), restart_mgr=MagicMock(),
            ledger=ledger, breaker=breaker, alert_pipeline=MagicMock(),
        )
        result = await a.chat("hello")
        assert "not available" in result.lower()

    @pytest.mark.asyncio
    async def test_chat_api_failure(self, agent):
        with patch.object(agent, "_call_openrouter", return_value=None):
            result = await agent.chat("hello")
            assert "couldn't reach" in result.lower()

    @pytest.mark.asyncio
    async def test_chat_simple_response(self, agent):
        mock_response = {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": "OpenClaw is running fine.",
                }
            }]
        }
        with patch.object(agent, "_call_openrouter", return_value=mock_response):
            result = await agent.chat("How is OpenClaw?")
            assert result == "OpenClaw is running fine."

    @pytest.mark.asyncio
    async def test_chat_system_prompt_includes_conversation_mode(self, agent):
        prompt = agent._build_chat_system_prompt()
        assert "CONVERSATION MODE" in prompt
        assert "INVESTIGATE FIRST" in prompt

    @pytest.mark.asyncio
    async def test_chat_history_persists_across_calls(self, agent):
        """Conversation history should accumulate across multiple chat() calls."""
        mock_response = {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": "Response 1",
                }
            }]
        }
        with patch.object(agent, "_call_openrouter", return_value=mock_response):
            await agent.chat("Message 1", chat_id=123)
            await agent.chat("Message 2", chat_id=123)

        # Should have 4 entries: user1, assistant1, user2, assistant2
        assert len(agent._chat_history[123]) == 4
        assert agent._chat_history[123][0]["role"] == "user"
        assert agent._chat_history[123][0]["content"] == "Message 1"
        assert agent._chat_history[123][1]["role"] == "assistant"
        assert agent._chat_history[123][2]["role"] == "user"
        assert agent._chat_history[123][2]["content"] == "Message 2"

    @pytest.mark.asyncio
    async def test_chat_history_isolated_per_chat_id(self, agent):
        """Different chat_ids should have separate histories."""
        mock_response = {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": "OK",
                }
            }]
        }
        with patch.object(agent, "_call_openrouter", return_value=mock_response):
            await agent.chat("From user A", chat_id=100)
            await agent.chat("From user B", chat_id=200)

        assert len(agent._chat_history[100]) == 2
        assert len(agent._chat_history[200]) == 2
        assert agent._chat_history[100][0]["content"] == "From user A"
        assert agent._chat_history[200][0]["content"] == "From user B"

    @pytest.mark.asyncio
    async def test_chat_history_expires(self, agent):
        """History should be cleared after TTL expires."""
        mock_response = {
            "choices": [{
                "message": {"role": "assistant", "content": "OK"}
            }]
        }
        with patch.object(agent, "_call_openrouter", return_value=mock_response):
            await agent.chat("Old message", chat_id=999)

        # Simulate time passing beyond TTL
        agent._chat_last_active[999] = time.time() - agent._chat_ttl - 1
        agent._expire_chat_history(time.time())

        assert 999 not in agent._chat_history
        assert 999 not in agent._chat_last_active

    @pytest.mark.asyncio
    async def test_chat_history_included_in_messages(self, agent):
        """Prior history should be sent to the LLM on subsequent calls."""
        call_count = 0
        captured_messages = []

        async def mock_call(messages, tools):
            nonlocal call_count
            call_count += 1
            captured_messages.append(list(messages))
            return {
                "choices": [{
                    "message": {"role": "assistant", "content": f"Reply {call_count}"}
                }]
            }

        with patch.object(agent, "_call_openrouter", side_effect=mock_call):
            await agent.chat("First question", chat_id=42)
            await agent.chat("Follow-up question", chat_id=42)

        # Second call should include history from first exchange
        second_call_msgs = captured_messages[1]
        # system + history(user, assistant) + new user message = 4
        assert len(second_call_msgs) == 4
        assert second_call_msgs[0]["role"] == "system"
        assert second_call_msgs[1]["content"] == "First question"
        assert second_call_msgs[2]["content"] == "Reply 1"
        assert second_call_msgs[3]["content"] == "Follow-up question"


# ── System prompt tests ──────────────────────────────────────────────


class TestSystemPrompt:
    def test_system_prompt_basic(self):
        config = _make_config()
        breaker = MagicMock()
        breaker.is_tripped = False

        prompt = _build_system_prompt(
            config=config,
            openclaw=None,
            breaker=breaker,
            mcp_client=None,
            kpi_tracker=None,
            recent_history=[],
        )

        assert "EasyClaw" in prompt
        assert "not detected" in prompt
        assert "SAFETY FIRST" in prompt

    def test_system_prompt_with_tripped_breaker(self):
        config = _make_config()
        breaker = MagicMock()
        breaker.is_tripped = True

        prompt = _build_system_prompt(
            config=config, openclaw=None, breaker=breaker,
            mcp_client=None, kpi_tracker=None, recent_history=[],
        )

        assert "TRIPPED" in prompt

    def test_system_prompt_with_history(self):
        config = _make_config()
        breaker = MagicMock()
        breaker.is_tripped = False

        history = [InvocationSummary(
            timestamp=time.time(),
            event_types=["process_crash"],
            actions_taken=["execute_shell_command"],
            outcome="success",
            duration=2.5,
        )]

        prompt = _build_system_prompt(
            config=config, openclaw=None, breaker=breaker,
            mcp_client=None, kpi_tracker=None, recent_history=history,
        )

        assert "process_crash" in prompt
        assert "success" in prompt

    def test_system_prompt_mcp_connected(self):
        config = _make_config()
        breaker = MagicMock()
        breaker.is_tripped = False
        mcp = MagicMock()
        mcp.is_configured = True

        prompt = _build_system_prompt(
            config=config, openclaw=None, breaker=breaker,
            mcp_client=mcp, kpi_tracker=None, recent_history=[],
        )

        assert "connected" in prompt


# ── Fallback tests ───────────────────────────────────────────────────


class TestFallback:
    def test_fallback_to_healer(self, agent):
        healer = MagicMock()
        agent.set_fallback_healer(healer)

        events = [_make_event(), _make_event()]
        agent._fallback_events(events)

        assert healer.enqueue.call_count == 2

    def test_fallback_no_healer(self, agent):
        # Should not raise even without a healer
        agent._fallback_events([_make_event()])


# ── History tracking tests ───────────────────────────────────────────


class TestHistoryTracking:
    def test_record_history(self, agent):
        events = [_make_event()]
        agent._record_history(events, ["execute_shell_command"], "success", 1.5)

        assert len(agent._recent_history) == 1
        summary = agent._recent_history[0]
        assert summary.outcome == "success"
        assert summary.duration == 1.5
        assert "process_crash" in summary.event_types

    def test_history_max_length(self, agent):
        for i in range(15):
            agent._record_history([_make_event()], [], "success", 0.1)

        assert len(agent._recent_history) == 10  # maxlen=10


# ── Utility tests ────────────────────────────────────────────────────


class TestUtils:
    def test_truncate_short(self):
        assert _truncate("hello", 10) == "hello"

    def test_truncate_long(self):
        result = _truncate("a" * 100, 20)
        assert len(result) == 20
        assert result.endswith("...")

    def test_truncate_exact(self):
        assert _truncate("hello", 5) == "hello"


# ── Message cleaning tests ───────────────────────────────────────────


class TestMessageCleaning:
    def test_clean_message_content_only(self, agent):
        msg = {"role": "assistant", "content": "hello", "extra": "ignored"}
        cleaned = agent._clean_message(msg)
        assert cleaned == {"role": "assistant", "content": "hello"}

    def test_clean_message_with_tool_calls(self, agent):
        msg = {"role": "assistant", "tool_calls": [{"id": "1"}]}
        cleaned = agent._clean_message(msg)
        assert "tool_calls" in cleaned
