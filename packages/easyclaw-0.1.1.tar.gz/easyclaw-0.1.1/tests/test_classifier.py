"""Tests for the event classifier."""

import pytest
from easyclaw.classifier import EventClassifier, EventType, Severity, Event


@pytest.fixture
def classifier():
    return EventClassifier()


class TestClassifierMatching:
    """Test that known error patterns are correctly classified."""

    def test_python_traceback(self, classifier):
        event = classifier.classify("test.log", "Traceback (most recent call last):")
        assert event is not None
        assert event.event_type == EventType.PYTHON_TRACEBACK
        assert event.severity == Severity.CRITICAL

    def test_node_fatal(self, classifier):
        event = classifier.classify("test.log", "FATAL ERROR: Reached heap limit")
        assert event is not None
        assert event.event_type == EventType.NODE_ERROR
        assert event.severity == Severity.CRITICAL

    def test_segfault(self, classifier):
        event = classifier.classify("test.log", "Segmentation fault (core dumped)")
        assert event is not None
        assert event.event_type == EventType.PROCESS_CRASH
        assert event.severity == Severity.CRITICAL

    def test_oom(self, classifier):
        event = classifier.classify("test.log", "Out of memory: killed process 1234")
        assert event is not None
        assert event.event_type == EventType.PROCESS_OOM
        assert event.severity == Severity.CRITICAL

    def test_oom_memoryerror(self, classifier):
        event = classifier.classify("test.log", "MemoryError: unable to allocate")
        assert event is not None
        assert event.event_type == EventType.PROCESS_OOM

    def test_connection_refused(self, classifier):
        event = classifier.classify("test.log", "ConnectionRefusedError: [Errno 111]")
        assert event is not None
        assert event.event_type == EventType.CONNECTION_REFUSED
        assert event.severity == Severity.WARNING

    def test_econnrefused(self, classifier):
        event = classifier.classify("test.log", "connect ECONNREFUSED 127.0.0.1:18789")
        assert event is not None
        assert event.event_type == EventType.CONNECTION_REFUSED

    def test_rate_limit_429(self, classifier):
        event = classifier.classify("test.log", "HTTP 429 Too Many Requests")
        assert event is not None
        assert event.event_type == EventType.API_RATE_LIMIT

    def test_rate_limit_keyword(self, classifier):
        event = classifier.classify("test.log", "rate limit exceeded, retrying in 60s")
        assert event is not None
        assert event.event_type == EventType.API_RATE_LIMIT

    def test_api_5xx(self, classifier):
        event = classifier.classify("test.log", "HTTP 502 Bad Gateway")
        assert event is not None
        assert event.event_type == EventType.API_SERVER_ERROR

    def test_api_503(self, classifier):
        event = classifier.classify("test.log", "503 Service Unavailable")
        assert event is not None
        assert event.event_type == EventType.API_SERVER_ERROR

    def test_dns_failure(self, classifier):
        event = classifier.classify("test.log", "getaddrinfo EAI_AGAIN api.anthropic.com")
        assert event is not None
        assert event.event_type == EventType.DNS_FAILURE

    def test_session_locked(self, classifier):
        event = classifier.classify("test.log", "session file locked by another process")
        assert event is not None
        assert event.event_type == EventType.SESSION_LOCKED

    def test_token_overflow(self, classifier):
        event = classifier.classify("test.log", "token limit exceeded: 200k > 128k")
        assert event is not None
        assert event.event_type == EventType.TOKEN_OVERFLOW
        assert event.severity == Severity.CRITICAL

    def test_compaction_failure(self, classifier):
        event = classifier.classify("test.log", "compaction failed: safeguard blocked")
        assert event is not None
        assert event.event_type == EventType.COMPACTION_FAILURE

    def test_generic_error(self, classifier):
        event = classifier.classify("test.log", "something failed unexpectedly")
        assert event is not None
        assert event.event_type == EventType.GENERIC_ERROR
        assert event.severity == Severity.INFO


class TestClassifierNoMatch:
    """Test that normal log lines don't trigger events."""

    def test_normal_line(self, classifier):
        assert classifier.classify("test.log", "Starting OpenClaw agent...") is None

    def test_empty_line(self, classifier):
        assert classifier.classify("test.log", "") is None

    def test_info_line(self, classifier):
        assert classifier.classify("test.log", "Session started at 2026-03-30") is None


class TestClassifierPriority:
    """Test that higher-priority rules match before lower-priority ones."""

    def test_oom_beats_generic(self, classifier):
        # "Out of memory" contains "error" implicitly via context, but OOM rule is higher priority
        event = classifier.classify("test.log", "Out of memory error occurred")
        assert event is not None
        assert event.event_type == EventType.PROCESS_OOM  # not GENERIC_ERROR

    def test_node_fatal_beats_generic(self, classifier):
        event = classifier.classify("test.log", "FATAL ERROR: unhandled exception")
        assert event is not None
        assert event.event_type == EventType.NODE_ERROR


class TestEventProperties:
    """Test Event dataclass properties."""

    def test_error_hash_deterministic(self, classifier):
        e1 = classifier.classify("a.log", "ConnectionRefusedError: [Errno 111]")
        e2 = classifier.classify("b.log", "ConnectionRefusedError: different message")
        # Same event_type + pattern_name => same hash
        assert e1.error_hash == e2.error_hash

    def test_error_hash_different_types(self, classifier):
        e1 = classifier.classify("a.log", "ConnectionRefusedError: [Errno 111]")
        e2 = classifier.classify("a.log", "Traceback (most recent call last):")
        assert e1.error_hash != e2.error_hash

    def test_context_lines_buffered(self, classifier):
        classifier.classify("src", "line one")
        classifier.classify("src", "line two")
        event = classifier.classify("src", "Traceback (most recent call last):")
        assert len(event.context_lines) == 3
        assert "line one" in event.context_lines
