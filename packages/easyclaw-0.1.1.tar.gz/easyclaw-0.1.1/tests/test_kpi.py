"""Tests for the KPI tracker."""

import json
import time
import pytest
from easyclaw.kpi import KPITracker


@pytest.fixture
def kpi():
    return KPITracker()


class TestKPITracker:

    def test_initial_kpis(self, kpi):
        result = kpi.get_kpis()
        assert result["mttr_seconds"] == 0.0
        assert result["total_incidents"] == 0
        assert result["uptime_percent"] == 0.0
        assert result["auto_fix_rate"] == 0.0

    def test_record_successful_fix(self, kpi):
        kpi.record_fix(duration=2.5, success=True)
        result = kpi.get_kpis()
        assert result["mttr_seconds"] == 2.5
        assert result["total_incidents"] == 1
        assert result["auto_fix_rate"] == 100.0

    def test_record_failed_fix(self, kpi):
        kpi.record_fix(duration=5.0, success=False)
        result = kpi.get_kpis()
        assert result["mttr_seconds"] == 0.0  # no successful fixes
        assert result["total_incidents"] == 1
        assert result["auto_fix_rate"] == 0.0

    def test_mttr_average(self, kpi):
        kpi.record_fix(duration=2.0, success=True)
        kpi.record_fix(duration=4.0, success=True)
        kpi.record_fix(duration=6.0, success=True)
        result = kpi.get_kpis()
        assert result["mttr_seconds"] == 4.0

    def test_auto_fix_rate_mixed(self, kpi):
        kpi.record_fix(duration=1.0, success=True)
        kpi.record_fix(duration=1.0, success=True)
        kpi.record_fix(duration=1.0, success=False)
        result = kpi.get_kpis()
        assert abs(result["auto_fix_rate"] - 66.67) < 0.1

    def test_uptime_tracking(self, kpi):
        kpi.record_openclaw_alive(True)
        kpi.record_openclaw_alive(True)
        kpi.record_openclaw_alive(False)
        kpi.record_openclaw_alive(True)
        result = kpi.get_kpis()
        assert result["uptime_percent"] == 75.0

    def test_uptime_all_alive(self, kpi):
        for _ in range(10):
            kpi.record_openclaw_alive(True)
        assert kpi.get_kpis()["uptime_percent"] == 100.0

    def test_uptime_all_dead(self, kpi):
        for _ in range(10):
            kpi.record_openclaw_alive(False)
        assert kpi.get_kpis()["uptime_percent"] == 0.0

    def test_snapshot_save_and_load(self, tmp_easyclaw_home):
        kpi1 = KPITracker()
        kpi1.record_fix(duration=3.0, success=True)
        kpi1.record_fix(duration=1.0, success=False)
        kpi1.record_openclaw_alive(True)
        kpi1.record_openclaw_alive(True)
        kpi1.record_openclaw_alive(False)

        state_dir = tmp_easyclaw_home / "state"
        kpi1._save_snapshot(state_dir)

        # Verify file exists
        snapshot = state_dir / "kpi-snapshot.json"
        assert snapshot.exists()
        data = json.loads(snapshot.read_text())
        assert data["total_fixes"] == 2
        assert data["successful_fixes"] == 1
        assert data["alive_checks"] == 3

        # Load into new tracker
        kpi2 = KPITracker()
        kpi2._load_snapshot(state_dir)
        assert kpi2._total_fixes == 2
        assert kpi2._successful_fixes == 1
        assert kpi2._alive_checks == 3

    def test_intervention_rate(self, kpi):
        # Record fixes and check rate is positive
        kpi.record_fix(duration=1.0, success=True)
        kpi.record_fix(duration=1.0, success=True)
        result = kpi.get_kpis()
        assert result["intervention_rate_per_day"] > 0
