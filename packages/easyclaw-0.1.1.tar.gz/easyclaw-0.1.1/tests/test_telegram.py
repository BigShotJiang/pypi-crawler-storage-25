"""Tests for the Telegram bridge (Phase 7)."""

import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from easyclaw.telegram import TelegramBridge, MAX_MESSAGE_LEN


# ── Fixtures ──────────────────────────────────────────────────────────


def _make_config(overrides=None):
    settings = {
        "telegram_bot_token": "123456:ABC-DEF",
        "telegram_chat_ids": [111, 222],
        "telegram_alert_severity": "CRITICAL",
    }
    if overrides:
        settings.update(overrides)
    config = MagicMock()
    config.settings = settings
    config.openclaw = None
    return config


def _make_bridge(config=None, **kwargs):
    config = config or _make_config()
    agent = kwargs.get("agent", MagicMock())
    alerts = kwargs.get("alerts", MagicMock())
    alerts.recent_alerts = []
    kpi = kwargs.get("kpi", MagicMock())
    breaker = kwargs.get("breaker", MagicMock())
    breaker.is_tripped = False

    return TelegramBridge(
        config=config,
        agent_brain=agent,
        alert_pipeline=alerts,
        kpi_tracker=kpi,
        breaker=breaker,
    )


def _make_alert(severity="CRITICAL", event_type="process_crash", error_hash="abc123", ts=None):
    alert = MagicMock()
    alert.severity = severity
    alert.event_type = event_type
    alert.error_hash = error_hash
    alert.timestamp = ts or time.time()
    alert.line = "FATAL ERROR: heap out of memory"
    alert.details = "heap out of memory"
    return alert


# ── Configuration tests ──────────────────────────────────────────────


class TestConfiguration:
    def test_is_configured_with_token(self):
        bridge = _make_bridge()
        assert bridge.is_configured is True

    def test_not_configured_without_token(self):
        config = _make_config({"telegram_bot_token": ""})
        bridge = _make_bridge(config=config)
        assert bridge.is_configured is False

    def test_not_configured_none_token(self):
        config = _make_config({"telegram_bot_token": None})
        bridge = _make_bridge(config=config)
        assert bridge.is_configured is False

    def test_chat_ids_parsed(self):
        bridge = _make_bridge()
        assert bridge._chat_ids == [111, 222]

    def test_empty_chat_ids(self):
        config = _make_config({"telegram_chat_ids": []})
        bridge = _make_bridge(config=config)
        assert bridge._chat_ids == []


# ── Authorization tests ──────────────────────────────────────────────


class TestAuthorization:
    def test_authorized_chat_id(self):
        bridge = _make_bridge()
        assert bridge._is_authorized(111) is True
        assert bridge._is_authorized(222) is True

    def test_unauthorized_chat_id(self):
        bridge = _make_bridge()
        assert bridge._is_authorized(999) is False

    def test_empty_chat_ids_allows_all(self):
        config = _make_config({"telegram_chat_ids": []})
        bridge = _make_bridge(config=config)
        assert bridge._is_authorized(999) is True
        assert bridge._is_authorized(12345) is True


# ── Alert forwarding tests ───────────────────────────────────────────


class TestAlertForwarding:
    @pytest.mark.asyncio
    async def test_forward_critical_alert(self):
        bridge = _make_bridge()
        bridge._last_alert_check = time.time() - 60

        alert = _make_alert(severity="CRITICAL", ts=time.time())
        bridge.alerts.recent_alerts = [alert]

        app = MagicMock()
        app.bot.send_message = AsyncMock()

        await bridge._forward_alerts(app)

        assert app.bot.send_message.call_count == 2  # sent to both chat IDs

    @pytest.mark.asyncio
    async def test_skip_non_critical_when_filter_critical(self):
        bridge = _make_bridge()
        bridge._last_alert_check = time.time() - 60

        alert = _make_alert(severity="WARNING", ts=time.time())
        bridge.alerts.recent_alerts = [alert]

        app = MagicMock()
        app.bot.send_message = AsyncMock()

        await bridge._forward_alerts(app)

        app.bot.send_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_dedup_prevents_duplicate_alerts(self):
        bridge = _make_bridge()
        bridge._last_alert_check = time.time() - 60

        alert = _make_alert(severity="CRITICAL", error_hash="dup123", ts=time.time())
        bridge.alerts.recent_alerts = [alert]

        app = MagicMock()
        app.bot.send_message = AsyncMock()

        # First call should send
        await bridge._forward_alerts(app)
        assert app.bot.send_message.call_count == 2

        # Second call with same hash — should not send again
        app.bot.send_message.reset_mock()
        bridge._last_alert_check = time.time() - 60
        alert2 = _make_alert(severity="CRITICAL", error_hash="dup123", ts=time.time())
        bridge.alerts.recent_alerts = [alert2]
        await bridge._forward_alerts(app)
        app.bot.send_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_old_dedup_entries_cleaned(self):
        bridge = _make_bridge()
        bridge._sent_alert_hashes = {
            "old_hash": time.time() - 700,  # older than 10 min window
            "recent_hash": time.time() - 10,
        }
        bridge._last_alert_check = time.time() - 60
        bridge.alerts.recent_alerts = []

        app = MagicMock()
        app.bot.send_message = AsyncMock()

        await bridge._forward_alerts(app)

        assert "old_hash" not in bridge._sent_alert_hashes
        assert "recent_hash" in bridge._sent_alert_hashes

    @pytest.mark.asyncio
    async def test_no_forwarding_without_chat_ids(self):
        config = _make_config({"telegram_chat_ids": []})
        bridge = _make_bridge(config=config)

        app = MagicMock()
        app.bot.send_message = AsyncMock()

        await bridge._forward_alerts(app)

        app.bot.send_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_skip_old_alerts(self):
        bridge = _make_bridge()
        bridge._last_alert_check = time.time()

        # Alert with timestamp before our last check
        alert = _make_alert(ts=time.time() - 120)
        bridge.alerts.recent_alerts = [alert]

        app = MagicMock()
        app.bot.send_message = AsyncMock()

        await bridge._forward_alerts(app)

        app.bot.send_message.assert_not_called()


# ── Message splitting tests ──────────────────────────────────────────


class TestMessageSplitting:
    @pytest.mark.asyncio
    async def test_short_message(self):
        bridge = _make_bridge()
        context = MagicMock()
        context.bot.send_message = AsyncMock()

        await bridge._send_long_message(111, "hello", context)

        context.bot.send_message.assert_called_once_with(chat_id=111, text="hello")

    @pytest.mark.asyncio
    async def test_empty_message(self):
        bridge = _make_bridge()
        context = MagicMock()
        context.bot.send_message = AsyncMock()

        await bridge._send_long_message(111, "", context)

        context.bot.send_message.assert_called_once_with(
            chat_id=111, text="(empty response)"
        )

    @pytest.mark.asyncio
    async def test_long_message_splits(self):
        bridge = _make_bridge()
        context = MagicMock()
        context.bot.send_message = AsyncMock()

        long_text = ("x" * 4000 + "\n") * 3  # > 4096 chars
        await bridge._send_long_message(111, long_text, context)

        assert context.bot.send_message.call_count > 1


# ── Run method tests ─────────────────────────────────────────────────


class TestRunMethod:
    @pytest.mark.asyncio
    async def test_run_skips_when_not_configured(self):
        config = _make_config({"telegram_bot_token": ""})
        bridge = _make_bridge(config=config)

        shutdown = MagicMock()
        await bridge.run(shutdown)
        # Should return immediately without error

    @pytest.mark.asyncio
    async def test_run_skips_when_telegram_not_installed(self):
        bridge = _make_bridge()
        shutdown = MagicMock()

        with patch.dict("sys.modules", {"telegram": None, "telegram.ext": None}):
            # Should handle ImportError gracefully
            await bridge.run(shutdown)
