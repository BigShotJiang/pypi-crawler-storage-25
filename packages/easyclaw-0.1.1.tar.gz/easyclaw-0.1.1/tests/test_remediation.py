"""Tests for the remediation registry."""

import pytest
from easyclaw.remediation import RemediationRegistry, BUILTIN_REMEDIATIONS


@pytest.fixture
def registry():
    return RemediationRegistry()


class TestRemediationRegistry:

    def test_builtin_count(self, registry):
        # Should have all 11 built-in remediations loaded
        assert len(BUILTIN_REMEDIATIONS) == 11

    def test_lookup_by_pattern_name(self, registry):
        entry = registry.lookup("connection_refused", "connection_refused")
        assert entry is not None
        assert entry.pattern_name == "connection_refused"
        assert len(entry.actions) > 0

    def test_lookup_by_event_type(self, registry):
        entry = registry.lookup("nonexistent", "process_oom")
        assert entry is not None
        assert entry.event_type == "process_oom"

    def test_lookup_missing(self, registry):
        entry = registry.lookup("nonexistent", "nonexistent")
        assert entry is None

    def test_pattern_priority_over_event_type(self, registry):
        entry = registry.lookup("oom_killed", "process_crash")
        assert entry is not None
        assert entry.pattern_name == "oom_killed"  # pattern wins

    def test_all_builtins_have_actions(self, registry):
        for rem in BUILTIN_REMEDIATIONS:
            assert len(rem.actions) > 0, f"{rem.pattern_name} has no actions"

    def test_restart_entries_have_flag(self, registry):
        for rem in BUILTIN_REMEDIATIONS:
            for action in rem.actions:
                if action.action_type == "restart":
                    assert action.requires_restart, (
                        f"{rem.pattern_name}/{action.name} is restart type but requires_restart=False"
                    )

    def test_user_file_override(self, tmp_path):
        user_file = tmp_path / "remediations.yaml"
        user_file.write_text("""
remediations:
  - pattern_name: custom_error
    event_type: custom_event
    description: Custom remediation
    actions:
      - name: custom_fix
        description: Run custom fix
        action_type: command
        commands:
          - echo fixed
        timeout: 10
""")
        registry = RemediationRegistry(user_file=user_file)
        entry = registry.lookup("custom_error", "custom_event")
        assert entry is not None
        assert entry.description == "Custom remediation"
        assert entry.actions[0].commands == ["echo fixed"]

    def test_user_file_missing_no_error(self, tmp_path):
        # Non-existent file should not raise
        registry = RemediationRegistry(user_file=tmp_path / "missing.yaml")
        assert registry.lookup("connection_refused", "") is not None
