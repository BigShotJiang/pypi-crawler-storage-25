"""Tests for the alert pipeline and dedup filter."""

import time
import json
import asyncio
import pytest
from pathlib import Path
from easyclaw.classifier import Event, EventType, Severity
from easyclaw.alerts import DedupFilter, AlertPipeline


def make_event(
    event_type=EventType.CONNECTION_REFUSED,
    severity=Severity.WARNING,
    pattern_name="connection_refused",
):
    return Event(
        event_type=event_type,
        severity=severity,
        source="test.log",
        line="ConnectionRefusedError: [Errno 111]",
        pattern_name=pattern_name,
    )


class TestDedupFilter:

    def test_first_event_passes(self):
        f = DedupFilter(cooldown_seconds=300)
        event = make_event()
        assert f.should_alert(event) is True

    def test_duplicate_suppressed(self):
        f = DedupFilter(cooldown_seconds=300)
        event = make_event()
        f.should_alert(event)
        assert f.should_alert(event) is False

    def test_different_types_pass(self):
        f = DedupFilter(cooldown_seconds=300)
        e1 = make_event(event_type=EventType.CONNECTION_REFUSED)
        e2 = make_event(event_type=EventType.PROCESS_OOM, pattern_name="oom_killed")
        assert f.should_alert(e1) is True
        assert f.should_alert(e2) is True

    def test_cooldown_expires(self):
        f = DedupFilter(cooldown_seconds=1)
        event = make_event()
        f.should_alert(event)
        # Manually expire
        f._seen[event.error_hash] = time.time() - 2
        assert f.should_alert(event) is True

    def test_cleanup(self):
        f = DedupFilter(cooldown_seconds=1)
        event = make_event()
        f.should_alert(event)
        f._seen[event.error_hash] = time.time() - 10
        f.cleanup()
        assert event.error_hash not in f._seen


class TestAlertPipeline:

    def test_enqueue_and_count(self, tmp_easyclaw_home):
        pipeline = AlertPipeline(tmp_easyclaw_home / "logs")
        event = make_event()
        pipeline.enqueue(event)
        assert pipeline.queue.qsize() == 1

    @pytest.mark.asyncio
    async def test_processes_events(self, tmp_easyclaw_home):
        pipeline = AlertPipeline(tmp_easyclaw_home / "logs", cooldown_seconds=0)
        shutdown = asyncio.Event()

        # Enqueue a WARNING event
        pipeline.enqueue(make_event(severity=Severity.WARNING))

        # Run pipeline briefly
        async def stop_soon():
            await asyncio.sleep(0.2)
            shutdown.set()

        await asyncio.gather(pipeline.run(shutdown), stop_soon())

        # Should have written to alerts log
        alerts_file = tmp_easyclaw_home / "logs" / "alerts.log"
        assert alerts_file.exists()
        data = json.loads(alerts_file.read_text().strip().split("\n")[-1])
        assert data["event_type"] == "connection_refused"

    @pytest.mark.asyncio
    async def test_info_events_logged_not_alerted(self, tmp_easyclaw_home):
        pipeline = AlertPipeline(tmp_easyclaw_home / "logs")
        shutdown = asyncio.Event()

        pipeline.enqueue(make_event(severity=Severity.INFO))

        async def stop_soon():
            await asyncio.sleep(0.2)
            shutdown.set()

        await asyncio.gather(pipeline.run(shutdown), stop_soon())

        # Should log but not appear in recent_alerts (INFO is file-only)
        assert len(pipeline.recent_alerts) == 0
