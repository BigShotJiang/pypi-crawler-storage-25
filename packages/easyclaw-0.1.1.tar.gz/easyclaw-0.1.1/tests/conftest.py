"""Shared fixtures for EasyClaw tests."""

import pytest
from pathlib import Path


@pytest.fixture
def tmp_easyclaw_home(tmp_path):
    """Create a temporary EasyClaw home directory structure."""
    home = tmp_path / ".easyclaw"
    (home / "logs").mkdir(parents=True)
    (home / "state").mkdir(parents=True)
    return home


@pytest.fixture
def tmp_openclaw_home(tmp_path):
    """Create a temporary OpenClaw home directory structure."""
    home = tmp_path / ".openclaw"
    home.mkdir()
    (home / "agents" / "main" / "sessions").mkdir(parents=True)
    (home / "workspace").mkdir()
    return home
