# EasyClaw MCP Server: A Knowledge-Augmented Tooling Layer for AI Agent Deployment

**White Paper — March 2026**
**Version 3.1.0**

---

## Abstract

EasyClaw MCP Server is a production Model Context Protocol (MCP) service that provides AI agents with structured diagnostic tools, searchable knowledge, and actionable configuration guidance for deploying and managing OpenClaw instances. Built on the FastMCP framework with Streamable HTTP transport, it exposes 14 tools and a 20-entry full-text-searchable knowledge base behind a tiered authentication system. This paper describes the server's architecture, protocol implementation, tool design, knowledge management strategy, and integration model.

---

## 1. Introduction

### 1.1 The Problem

Deploying an AI agent stack on a bare Linux server involves dozens of configuration decisions — model selection, channel integration, security hardening, cost optimization, and ongoing diagnostics. Traditional documentation addresses these topics statically. When an AI agent encounters an error or needs to make a configuration decision during deployment, it cannot efficiently consume a documentation site.

### 1.2 The Solution

EasyClaw MCP Server bridges this gap by exposing operational knowledge as structured MCP tools. Rather than parsing documentation, an AI agent calls `diagnose_issue(error_text="gateway timeout")` and receives a ranked list of causes, fix commands, and contextual warnings. The server acts as a **knowledge-augmented tooling layer** — part diagnostic engine, part configuration generator, part searchable reference.

### 1.3 What Is MCP?

The Model Context Protocol (MCP) is an open standard that enables AI models to interact with external tools and data sources through a unified JSON-RPC 2.0 interface. MCP defines how tools are discovered (`tools/list`), invoked (`tools/call`), and how results are returned — giving any MCP-compatible client access to server capabilities without custom integration code.

---

## 2. Architecture

### 2.1 System Overview

```
Internet
   |
   v
Traefik (reverse proxy, automatic TLS)
   |
   +-- easyclaw.help          -> nginx (marketing site + dashboard)
   |
   +-- mcp.easyclaw.help      -> FastMCP Server (Python 3.12, port 8000)
                                    |
                                    +-- SQLite (knowledge, subscriptions, usage)
                                    +-- SearXNG (private web search backend)
```

The MCP server runs as a Docker container (`python:3.12-slim`) behind Traefik, which handles TLS termination and certificate renewal. It shares a Docker network with SearXNG for web search capabilities and with n8n for workflow automation.

### 2.2 Core Components

| Component | File | Responsibility |
|-----------|------|----------------|
| **MCP Server** | `server.py` | FastMCP tool definitions, admin REST API, ASGI middleware |
| **Database** | `database.py` | SQLite schema, FTS5 search, subscription management, usage tracking |
| **Auth** | `auth.py` | Bearer token validation, rate limiting, tier enforcement |
| **Guides** | `guides/*.json` | Extended knowledge entries loaded at startup |

### 2.3 Transport Layer

The server implements two MCP transports:

1. **Streamable HTTP (primary)** — `POST /mcp` with JSON-RPC 2.0 payloads. Stateless, one request per tool call. This is the MCP 2.0 standard transport.
2. **SSE fallback** — `GET /sse` for clients that require Server-Sent Events. Maintains a persistent connection for streaming responses.

Session tracking uses the `Mcp-Session-Id` header, though the server operates statelessly — no server-side session state is maintained between requests.

---

## 3. Authentication and Authorization

### 3.1 API Key Model

Every MCP request requires a Bearer token in the `Authorization` header:

```
Authorization: Bearer ec_live_8da748750eca47cd968b69fd057e359d
```

Keys are prefixed with `ec_live_` for identification. The server stores only SHA-256 hashes of API keys — plaintext keys are never persisted after initial generation.

### 3.2 Tier System

Tools are gated by subscription tier. The tier hierarchy determines which tools a subscriber can access:

| Tier | Daily Limit | Tool Access |
|------|-------------|-------------|
| **Starter** | 100 calls | 9 tools (search, guides, recommendations, config generation, cost estimation) |
| **Subscriber** | 5,000 calls | All 14 tools (adds diagnostics, deployment validation, troubleshooting, knowledge authoring) |

Tier enforcement happens at the middleware layer before tool execution. Rate limiting is tracked per API key hash in the `usage_logs` table and resets at midnight UTC.

### 3.3 Admin API

A separate set of REST endpoints (authenticated via `X-Admin-Secret` header) supports user management, subscription provisioning, knowledge CRUD, and OTP-based dashboard authentication. These endpoints are consumed by n8n workflows for Stripe webhook processing and dashboard login flows.

---

## 4. Tool Design

### 4.1 Design Principles

Each tool follows three principles:

1. **Actionable output** — Every response includes commands the agent can execute, not just explanations.
2. **Context-aware** — Tools accept parameters that narrow results to the caller's specific situation (OS type, error text, symptom category).
3. **Self-contained** — Each tool response is complete. The agent does not need to chain multiple calls to get a usable answer.

### 4.2 Tool Catalog

#### Starter Tier (9 tools)

| Tool | Purpose | Key Parameters |
|------|---------|----------------|
| `search_knowledge` | Full-text search across the knowledge base | `query` |
| `get_full_guide` | Retrieve a complete guide by topic | `topic` |
| `get_model_recommendation` | AI model selection guidance with pricing | `use_case` (coding, general, fast, cheap, etc.) |
| `validate_config` | Configuration checklist covering all config domains | — |
| `search_web` | Web search via private SearXNG instance | `query`, `engines` |
| `recommend_skills` | Skill pack recommendations by use case | `use_case` (developer, business, automation, etc.) |
| `generate_config` | Complete `openclaw.json` generation from templates | `template` (developer, business, production, etc.) |
| `security_audit` | Security checklist with severity levels and fix commands | — |
| `estimate_cost` | Monthly cost estimation with comparison tables | `model`, `daily_messages` |

#### Subscriber Tier (5 additional tools)

| Tool | Purpose | Key Parameters |
|------|---------|----------------|
| `diagnose_issue` | Pattern-matched error diagnosis with 20+ error patterns | `error_text`, `context` |
| `validate_deployment` | Post-deployment health verification checklist | `os_type` |
| `get_foreman_config` | Full validated configuration generation (config + systemd + templates) | `model`, `channel`, `bind` |
| `troubleshoot_gateway` | Symptom-based gateway troubleshooting | `symptom` |
| `learn_solution` | Write new knowledge entries to the database | `topic`, `title`, `solution` |

### 4.3 Tool Implementation Pattern

Each tool is registered with the FastMCP framework using Python decorators. The server uses Starlette context variables to pass authenticated subscription data into tool handlers without parameter pollution:

```python
@mcp.tool()
async def diagnose_issue(error_text: str, context: str = "general") -> str:
    sub = current_subscription.get()
    if not check_tier(sub, "subscriber"):
        return "This tool requires a subscriber tier."
    # Pattern matching against 20+ error signatures
    # Returns: cause, fix commands, related gotchas
```

Tool responses are plain text (not JSON) by design — they are meant to be consumed directly by an LLM agent, which processes natural language more effectively than structured data.

---

## 5. Knowledge Base

### 5.1 Storage Architecture

Knowledge entries are stored in SQLite with FTS5 (Full-Text Search 5) indexing:

```sql
CREATE TABLE knowledge_entries (
    topic TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    source TEXT DEFAULT 'manual',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE VIRTUAL TABLE knowledge_fts
USING fts5(topic, title, content, tokenize='porter unicode61');
```

The FTS5 virtual table uses Porter stemming and Unicode-aware tokenization, enabling queries like "telegram bot setup" to match entries containing "Telegram," "bots," and "setting up."

### 5.2 Knowledge Inventory (20 Entries)

The knowledge base covers the full lifecycle of an OpenClaw deployment:

**Getting Started**
- `quick_start` — Installation, onboarding wizard, model setup, channel pairing, verification
- `onboarding_wizard` — Interactive setup flow, template selection

**Configuration & Models**
- `openrouter_models` — Model catalog with pricing tiers, tool-calling ratings, context windows
- `configuration_reference` — All config keys, validation schema, common errors
- `cost_optimization` — Thinking modes, token caching, sub-agent economics, budget caps

**Channels**
- `telegram_bot_setup` — Complete Telegram bot setup (BotFather, config, troubleshooting)
- `whatsapp_evolution_api` — WhatsApp via Evolution API (Docker build, Redis, QR pairing)

**Agent Capabilities**
- `persistent_memory` — SOUL.md/USER.md/MEMORY.md architecture, memory search
- `sub_agents` — Spawning, model selection, concurrency, stateless execution
- `automation_crons` — Scheduled tasks, cron syntax, environment variables
- `browser_automation` — Playwright integration, SSRF protection
- `voice_tts` — Text-to-speech, voice capture, real-time streaming

**Skills & Integrations**
- `clawhub_skills_detailed` — 50+ skill catalog with installation and testing
- `mcp_integration` — MCP server setup, tool registration, transport configuration

**Deployment & Security**
- `docker_deployment` — Docker/Compose setup, health checks, persistent volumes
- `security_hardening` — 10+ hardening steps, sandbox mode, audit log review

**Operations**
- `easyclaw_code_guide` — Code style, security rules, error handling for AI agents

Plus 3 dynamically created entries via the `learn_solution` tool.

### 5.3 Search Behavior

The `search_knowledge` tool queries the FTS5 index and returns up to 5 matches with 600-character content previews. If the FTS5 query syntax fails (e.g., special characters), it falls back to a `LIKE`-based search. If no matches are found, it returns a list of all available topics so the agent can select the closest match.

### 5.4 Dynamic Knowledge

The `learn_solution` tool (subscriber tier) allows agents to contribute new knowledge entries at runtime. When a solution is saved, the FTS5 index is rebuilt to include the new content immediately. This creates a feedback loop where agents that encounter and solve novel problems can persist those solutions for future use.

---

## 6. Database Schema

### 6.1 Entity Model

```
users (1) -----> (N) subscriptions (1) -----> (N) usage_logs
  |                      |
  +----> (N) guide_purchases
  +----> (N) otp_codes
```

### 6.2 Tables

| Table | Purpose | Key Fields |
|-------|---------|------------|
| `users` | Account identity | `id`, `email` |
| `subscriptions` | Billing + auth | `api_key_hash`, `tier`, `status`, `daily_limit`, Stripe IDs |
| `usage_logs` | Per-call tracking | `api_key_hash`, `tool_name`, `timestamp`, `response_time_ms` |
| `guide_purchases` | One-time purchases | `download_token`, `stripe_session_id` |
| `knowledge_entries` | Knowledge content | `topic` (PK), `title`, `content`, `source` |
| `knowledge_fts` | FTS5 search index | Virtual table over knowledge_entries |
| `otp_codes` | Dashboard login | `email`, `code`, `expires_at` |

API keys are stored as SHA-256 hashes only. Usage logs are indexed on `(api_key_hash, timestamp)` for efficient daily limit checks.

---

## 7. Client Integration

### 7.1 MCP Client (Installer)

The EasyClaw installer includes a synchronous MCP client (`mcp/client.py`) that connects to the server during deployment:

```
Installer Agent (Johnny 5)
    |
    +-- AgentBrain (OpenRouter LLM)
    |       |
    |       +-- MCPToolRegistry
    |               |
    |               +-- MCPClient
    |                       |
    |                       +-- POST https://mcp.easyclaw.help/mcp
```

**Transport auto-detection:** The client first attempts Streamable HTTP. If the server returns a non-200 response, it falls back to SSE transport.

**Tool registration:** The `MCPToolRegistry` fetches the server's tool list via `tools/list`, converts each tool definition to OpenAI function-calling format (prefixed with `mcp_`), and registers them with the agent brain. This allows the LLM to call MCP tools using the same interface as local tools.

### 7.2 OpenClaw Native Integration

Post-installation, OpenClaw instances connect to the MCP server via the `mcporter` CLI:

```bash
mcporter connect https://mcp.easyclaw.help \
  --key ec_live_... \
  --transport streamable-http
```

This gives the deployed OpenClaw agent persistent access to all 14 tools for ongoing diagnostics, configuration changes, and knowledge queries.

### 7.3 Dashboard

The web dashboard (`easyclaw.help/dashboard.html`) authenticates users via email OTP, then displays:

- Subscription tier and status
- API key (revealed on demand)
- Daily usage statistics with visual charts
- MCP integration instructions with copy-paste commands

---

## 8. Operational Infrastructure

### 8.1 Web Search

The `search_web` tool routes queries through a private SearXNG instance running on the same Docker network. This provides web search without exposing user queries to third-party search APIs. Default engines are Google and DuckDuckGo, configurable per request.

### 8.2 Health Monitoring

The `/health` endpoint returns server status and is polled by Traefik for container health checks. The endpoint verifies database connectivity and returns uptime metadata.

### 8.3 n8n Workflow Integration

Five n8n workflows interact with the MCP server's admin API:

| Workflow | Function |
|----------|----------|
| **Checkout Creator** | Generates Stripe checkout sessions, provisions subscriptions via admin API |
| **Stripe Webhook Handler** | Processes payment events, updates subscription status |
| **Dashboard Auth** | Generates and verifies OTP codes via admin endpoints |
| **Knowledge Scanner** | Daily scan for knowledge freshness (3am UTC) |
| **Version Checker** | Weekly OpenClaw version check, updates version manifest |

### 8.4 CORS and Security

CORS is configured for `easyclaw.help` and the n8n instance domain. Admin endpoints require an `X-Admin-Secret` header. All traffic is TLS-terminated at Traefik with automatically renewed Let's Encrypt certificates.

---

## 9. Performance Characteristics

| Metric | Value |
|--------|-------|
| Cold start | ~2s (SQLite init + FTS5 index build) |
| Tool call latency | 50-200ms (local tools), 1-3s (`search_web` via SearXNG) |
| Knowledge search | <50ms (FTS5 query) |
| Concurrent sessions | Stateless — limited only by uvicorn workers |
| Database size | ~5MB (knowledge + subscriptions + usage logs) |
| Memory footprint | ~80MB (Python process + SQLite in-memory cache) |

---

## 10. Design Decisions and Trade-offs

### 10.1 Plain Text Over Structured JSON

Tool responses return formatted plain text rather than JSON objects. This is intentional: LLM agents process natural language more effectively than nested data structures. Commands are embedded inline with markdown code blocks, making them directly executable.

### 10.2 SQLite Over PostgreSQL

SQLite was chosen for its zero-configuration deployment, single-file backup, and FTS5 support. The server handles one-at-a-time writes (WAL mode), which is sufficient for the current request volume. If write contention becomes a bottleneck, migration to PostgreSQL is straightforward since the schema uses standard SQL.

### 10.3 Tiered Tools Over Tiered Data

Rather than restricting which knowledge entries a tier can access, the system restricts which *tools* are available. All subscribers can search and read the full knowledge base. Advanced tools like `diagnose_issue` and `troubleshoot_gateway` — which provide more opinionated, actionable guidance — are gated behind the subscriber tier.

### 10.4 Server-Side Knowledge Over Client-Side Bundling

Knowledge lives on the server, not bundled with the installer. This means updates to guides, error patterns, and model recommendations are available immediately to all connected agents without a client update. The `learn_solution` tool extends this further by allowing the knowledge base to grow from agent contributions.

---

## 11. Future Directions

- **Context-aware diagnostics** — Accept log snippets and system state as tool input for more precise diagnosis
- **Multi-agent knowledge sharing** — Allow `learn_solution` entries from one deployment to benefit others (with opt-in)
- **Proactive alerts** — Push notifications to connected agents when new vulnerabilities or breaking changes are detected
- **Expanded channel guides** — Discord, Slack, SMS, and email channel setup guides
- **Usage analytics dashboard** — Expose tool call patterns and common error categories to administrators

---

## 12. Conclusion

EasyClaw MCP Server demonstrates that the Model Context Protocol is well-suited for building knowledge-augmented tooling services. By encoding operational expertise as callable tools rather than static documentation, AI agents gain the ability to self-diagnose, self-configure, and self-heal — reducing the expertise required to deploy and maintain an AI agent stack. The architecture is deliberately simple (FastMCP + SQLite + Docker) to match the single-server deployment model of its users, while the protocol layer (MCP 2.0 Streamable HTTP) ensures compatibility with the broader MCP ecosystem.

---

*EasyClaw MCP Server v3.1.0 — 14 tools, 20 knowledge entries, Streamable HTTP + SSE transport*
*Deployed at mcp.easyclaw.help*
