# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Value formatting and pandas import helpers for adapters."""

from __future__ import annotations

import types
from typing import Any

import numpy as np


def format_value(value: Any) -> str:
    """Format a single array value for text display.

    Rules:

    * Floats (Python ``float`` or ``np.floating``) render with 6
      significant digits (``f"{value:.6g}"``).  ``NaN`` renders as
      ``"NaN"``; ``inf`` / ``-inf`` render as ``"inf"`` / ``"-inf"``
      (via the same ``:.6g`` formatter).
    * Integers (Python ``int`` or ``np.integer``) render as their
      decimal representation.
    * Bytes (``bytes`` or ``np.bytes_``) are decoded with
      ``errors="replace"``.
    * Everything else (strings, ``datetime64``, ``timedelta64``,
      complex numbers, ndarrays of size 1 that weren't flattened, ...)
      falls through to ``str(value)``.

    Callers needing bespoke formatting should not monkeypatch this
    helper; convert the cell values upstream (via a computed column or
    ``set_column_labels`` on a pre-formatted field) instead.
    """
    if isinstance(value, (np.floating, float)):
        if np.isnan(value):
            return "NaN"
        return f"{value:.6g}"
    if isinstance(value, (np.integer, int)):
        return str(int(value))
    if isinstance(value, (bytes, np.bytes_)):
        return value.decode(errors="replace")
    return str(value)


def import_pandas() -> types.ModuleType:
    """Import pandas or raise a helpful error.

    Returns:
        The pandas module.

    Raises:
        ImportError: If pandas is not installed.
    """
    try:
        import pandas as pd
    except ImportError:
        raise ImportError(
            "pandas is required for this method. Install with: pip install vcti-array-view[pandas]"
        ) from None
    return pd
