# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Dtype flattening helpers.

Maps original multi-component fields to their flattened scalar column names
after ``flatten_record_dtype`` has expanded vector/matrix fields.
"""

from __future__ import annotations

import math

import numpy as np


def build_field_components(
    original_dtype: np.dtype,
    flattened_dtype: np.dtype,
) -> dict[str, list[str]]:
    """Map original multi-component fields to their flattened column names.

    Walks both dtypes positionally: scalar fields consume one slot,
    vector/matrix fields consume ``prod(shape)`` slots.

    Args:
        original_dtype: Dtype before flattening.
        flattened_dtype: Dtype after flattening.

    Returns:
        Dict mapping original field name to list of flattened column names.
        Only includes fields that were actually expanded (shape != ()).
    """
    if flattened_dtype.names is None:
        raise TypeError("flattened_dtype must be a structured dtype with named fields")
    if original_dtype.names is None:
        raise TypeError("original_dtype must be a structured dtype with named fields")
    flat_names = list(flattened_dtype.names)
    result: dict[str, list[str]] = {}
    idx = 0
    for name in original_dtype.names:
        shape = original_dtype[name].shape
        n_components = max(math.prod(shape), 1)
        if n_components > 1:
            result[name] = flat_names[idx : idx + n_components]
        idx += n_components
    return result
