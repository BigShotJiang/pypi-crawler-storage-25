# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""ArrayView — pipeline-style presentation layer for NumPy arrays.

Think of an ArrayView as a small pipeline::

    SOURCE                    OPERATIONS                        OUTPUT
    ArrayView(array)     -->  .exclude_patterns(...)       -->  .to_table()
                              .set_view_columns(...)            .to_dataframe()
                              .add_column_group(...)            .to_html()
                              .add_enum_columns(...)
                              .set_index(...)
                              .slice(head=..., tail=...)

Operations return ``self`` and compose in any order, any number of times.
Output methods return their result (text, DataFrame, or HTML) without
consuming state — the ArrayView instance stays live and mutable, so you
can re-slice, reshape, and render again.

Displaying 10M rows as a table is nonsense; the pipeline is built so you
can point at a large array for identity and render only a bounded window.
"""

from __future__ import annotations

import copy
import itertools
import logging
from collections.abc import Sequence
from types import MappingProxyType
from typing import Any, NamedTuple

import numpy as np
from vcti.nputils import flatten_record_dtype

from ._flattening import build_field_components
from ._formatting import format_value, import_pandas
from ._normalization import to_structured_view
from ._patterns import ColumnPattern, matches_any

logger = logging.getLogger(__name__)


class EnumMapping(NamedTuple):
    """Typed specification for a single entry passed to :meth:`ArrayView.add_enum_columns`.

    Using ``EnumMapping(id_col=..., mapping=...)`` is equivalent to the
    plain ``(id_col, mapping)`` tuple form but gives better IDE hints
    and readable error messages.
    """

    id_col: str
    mapping: dict[int, str]


class FrozenViewError(RuntimeError):
    """Raised when a configuration method is called on a frozen ArrayView.

    :meth:`ArrayView.freeze` locks an ArrayView's configuration — column
    shaping, labels, groups, index, and dtype reshaping all refuse further
    changes.  Slicing, rendering, and ``copy()`` remain available.
    Callers who need a modifiable branch should invoke ``copy()`` on the
    frozen view.
    """


class ArrayView:
    """Pipeline-style presentation layer for NumPy arrays.

    Wraps an array (structured, plain 1-D, or plain 2-D) without copying.
    Operations configure how the array will be rendered; output methods
    materialize a bounded, formatted view.

    All operations (``set_view_columns``, ``exclude_patterns``,
    ``add_column_group``, ``set_index``, ``slice``, ...) return ``self``,
    so you can chain them or call them independently.  Output methods
    (``to_table``, ``to_dataframe``, ``to_html``) return their result
    without consuming state — call them as many times as you like,
    reconfigure between calls, render again.

    Attributes:
        array: Underlying structured array — a *reference* to the input,
            not a copy.  Writes through ``view.array[...] = ...`` mutate
            the original input array.  Plain 1-D/2-D inputs are
            reinterpreted zero-copy as structured.
        original_dtype: Dtype of the input before internal flattening.

    Thread safety:
        ``ArrayView`` is not thread-safe.  Configuration methods
        (``slice``, ``set_index``, ``drop_view_columns``, ...) mutate
        shared state, so concurrent calls from multiple threads on the
        same instance can race.  For concurrent rendering, use
        :meth:`copy` to branch a per-thread view — the underlying array
        is shared, but configuration state is isolated.
    """

    def __init__(self, array: np.ndarray | None = None) -> None:
        """Create an ArrayView over *array*.

        The array is the only construction-time concern.  Everything about
        how it is displayed — which columns, labels, grouping, row index,
        slicing, output format — is configured via operations after
        construction.

        Args:
            array: NumPy array.  Structured arrays are used as-is.  Plain
                1-D becomes a 1-field structured view (field ``"value"``);
                plain 2-D of shape ``(N, K)`` becomes a K-field structured
                view with auto-generated field names ``col_0, col_1, ...``.
                To use meaningful dtype-level names, construct a
                structured array upfront with numpy idioms.

        Raises:
            TypeError: If *array* is not an ``np.ndarray`` or ``None``.
            ValueError: If a plain array is non-contiguous or has
                ``ndim > 2``.
        """
        self.array: np.ndarray | None = None
        self.original_dtype: np.dtype | None = None
        self._view_columns: list[str] = []
        self._enum_columns: dict[str, tuple[str, dict[int, str]]] = {}
        # Flattened-field grouping: top-level dtype field -> its flattened
        # dtype component names (e.g., "position" -> ["position_0", ...]).
        self._field_components: dict[str, list[str]] = {}
        # Display labels for top-level dtype fields (optional).
        self._column_labels: dict[str, str] = {}
        # Display labels for flattened components, one list per field.
        # Defaults to ["0", "1", ...] at construction; overridden by
        # set_component_names.
        self._component_labels: dict[str, list[str]] = {}
        # User-declared visual column groups: name -> tuple of member columns.
        self._column_groups: dict[str, tuple[str, ...]] = {}
        # Row identifier — str (dtype field or group name), ndarray, or None.
        self._index: str | np.ndarray | None = None
        # Slice configuration — None means full range.
        self._slice: dict[str, Any] | None = None
        # Frozen flag — True blocks configuration mutations; slicing and
        # rendering remain available.
        self._frozen: bool = False

        if array is None:
            return
        if not isinstance(array, np.ndarray):
            raise TypeError(f"Expected np.ndarray or None, got {type(array).__name__}")

        normalized = to_structured_view(array)
        self.original_dtype = normalized.dtype
        if normalized.ndim == 1:
            flat_dt, _ = flatten_record_dtype(normalized.dtype)
            self.array = normalized.view(flat_dt)
            self._field_components = build_field_components(normalized.dtype, flat_dt)
            self._component_labels = {
                field: [str(i) for i in range(len(comps))]
                for field, comps in self._field_components.items()
            }
        else:
            self.array = normalized
        self._view_columns = list(self.array.dtype.names or ())

    # -- Read-only properties ---------------------------------------------------

    @property
    def view_columns(self) -> list[str]:
        """Ordered list of visible columns using dtype-level names.

        These are the identifiers other operations accept.  To see the
        display labels, check :attr:`column_labels` and
        :attr:`component_labels`, or render via :meth:`to_table`.
        """
        return list(self._view_columns)

    @property
    def enum_columns(self) -> MappingProxyType[str, tuple[str, dict[int, str]]]:
        """Enum mapping recipes ``{name: (id_col, {int: str})}`` (read-only view)."""
        return MappingProxyType(self._enum_columns)

    @property
    def column_labels(self) -> MappingProxyType[str, str]:
        """Display labels for top-level dtype fields (read-only view)."""
        return MappingProxyType(self._column_labels)

    @property
    def component_labels(self) -> MappingProxyType[str, tuple[str, ...]]:
        """Component labels per flattened field (read-only view)."""
        return MappingProxyType({k: tuple(v) for k, v in self._component_labels.items()})

    @property
    def field_components(self) -> MappingProxyType[str, tuple[str, ...]]:
        """Flattened field grouping ``{field: (dtype_col, ...)}`` (read-only view)."""
        return MappingProxyType({k: tuple(v) for k, v in self._field_components.items()})

    @property
    def column_groups(self) -> MappingProxyType[str, tuple[str, ...]]:
        """User-declared column groups ``{name: (col, ...)}`` (read-only view)."""
        return MappingProxyType(self._column_groups)

    @property
    def index(self) -> str | np.ndarray | None:
        """Current row identifier: column/group name, ndarray, or None."""
        return self._index

    @property
    def is_frozen(self) -> bool:
        """True if this view has been frozen via :meth:`freeze`.

        A frozen view rejects all configuration changes but still supports
        slicing, rendering, and ``copy()`` (the copy is unfrozen).
        """
        return self._frozen

    # -- Internal guards --------------------------------------------------------

    def _check_mutable(self, method_name: str) -> None:
        """Raise :class:`FrozenViewError` if this view is frozen."""
        if self._frozen:
            raise FrozenViewError(
                f"cannot call {method_name}() on a frozen ArrayView.  "
                "freeze() locks configuration (columns, labels, groups, "
                "index, enum/join mappings); slicing and rendering still "
                "work.  Use .copy() to branch a modifiable view."
            )

    # -- Dtype reshaping --------------------------------------------------------

    def join_fields(
        self,
        fields: list[str],
        *,
        name: str,
        dtype: np.dtype | str,
    ) -> ArrayView:
        """Merge contiguous dtype fields into one via zero-copy reinterpretation.

        Useful when a structured array splits what is logically one field
        across multiple physical fields — for example, two ``S4`` fields
        produced by a C++ struct packing that should be rendered as a
        single ``S8`` string.  The merge is a zero-copy
        ``ndarray.view(new_dtype)`` — same memory, different dtype layout.

        Args:
            fields: Dtype field names to merge, in memory order.  Must be
                contiguous in memory (no padding between them).
            name: Name for the merged field.  Replaces the source fields
                in the view; must not collide with any remaining dtype
                field name.
            dtype: Target dtype for the merged field.  Its itemsize must
                equal the sum of the source fields' itemsizes.

        Returns:
            self, for chaining.

        Raises:
            ValueError: If no array is set, any source field is unknown,
                the fields aren't in memory order or are not contiguous,
                the target dtype itemsize doesn't match, *name* collides,
                or any source is referenced by a label / component
                labels / column group / enum / index configuration (clear
                those first).
            FrozenViewError: If the view is frozen.

        Example:
            >>> import numpy as np
            >>> from vcti.arrayview import ArrayView
            >>> arr = np.zeros(1, dtype=[("label_lo", "S4"), ("label_hi", "S4")])
            >>> arr["label_lo"] = b"abcd"
            >>> arr["label_hi"] = b"efgh"
            >>> view = ArrayView(arr).join_fields(
            ...     ["label_lo", "label_hi"], name="label", dtype="S8"
            ... )
            >>> view.view_columns
            ['label']
            >>> view.array["label"][0]
            np.bytes_(b'abcdefgh')
        """
        self._check_mutable("join_fields")
        if self.array is None:
            raise ValueError("No array set")
        if not fields:
            raise ValueError("join_fields requires at least one source field")

        dtype_names = list(self.array.dtype.names or ())
        unknown = [f for f in fields if f not in dtype_names]
        if unknown:
            raise ValueError(
                f"Unknown field(s): {sorted(set(unknown))}. Available: {sorted(dtype_names)}"
            )

        # Must be specified in memory order.
        memory_order = sorted(fields, key=lambda f: self.array.dtype.fields[f][1])
        if memory_order != fields:
            raise ValueError(
                f"fields must be in memory order; got {fields}, memory order is {memory_order}"
            )

        # Contiguity check.
        for cur, nxt in itertools.pairwise(fields):
            cur_offset = self.array.dtype.fields[cur][1]
            cur_size = self.array.dtype[cur].itemsize
            nxt_offset = self.array.dtype.fields[nxt][1]
            if cur_offset + cur_size != nxt_offset:
                raise ValueError(
                    f"join_fields: '{cur}' and '{nxt}' are not contiguous "
                    f"(offset {cur_offset} + size {cur_size} != offset {nxt_offset})"
                )

        target_dtype = np.dtype(dtype)
        total_size = sum(self.array.dtype[f].itemsize for f in fields)
        if target_dtype.itemsize != total_size:
            raise ValueError(
                f"dtype itemsize {target_dtype.itemsize} does not match "
                f"sum of source itemsizes {total_size}"
            )

        fields_set = set(fields)
        if name in set(dtype_names) - fields_set:
            raise ValueError(f"name '{name}' collides with an existing dtype field")

        # Downstream references — reject with a clear message.
        conflicts: list[str] = []
        for f in fields:
            if f in self._column_labels:
                conflicts.append(f"column_labels['{f}']")
            if f in self._field_components:
                conflicts.append(f"field_components['{f}']")
            for field_key, comps in self._field_components.items():
                if f in comps:
                    conflicts.append(f"component of field_components['{field_key}']")
            for group_name, members in self._column_groups.items():
                if f in members:
                    conflicts.append(f"member of column_groups['{group_name}']")
            for en_name, (id_col, _) in self._enum_columns.items():
                if f == id_col:
                    conflicts.append(f"id_col of enum_columns['{en_name}']")
        if isinstance(self._index, str) and self._index in fields:
            conflicts.append(f"index = '{self._index}'")
        if conflicts:
            raise ValueError(
                f"Cannot join fields {fields}: referenced by other configuration "
                f"({', '.join(conflicts)}). Clear those first."
            )

        # Build new dtype: replace the run of joined fields with the merged one.
        new_fields: list[tuple[str, np.dtype]] = []
        i = 0
        while i < len(dtype_names):
            n = dtype_names[i]
            if n == fields[0]:
                new_fields.append((name, target_dtype))
                i += len(fields)
            else:
                new_fields.append((n, self.array.dtype[n]))
                i += 1
        new_dtype = np.dtype(new_fields)

        # Zero-copy reinterpretation.
        self.array = self.array.view(new_dtype)

        # Update view_columns: replace the run with the merged name at the
        # first joined field's position.
        new_view: list[str] = []
        for col in self._view_columns:
            if col == fields[0]:
                new_view.append(name)
            elif col in fields_set:
                continue
            else:
                new_view.append(col)
        self._view_columns = new_view
        return self

    # -- Column shaping ---------------------------------------------------------

    def exclude_patterns(self, patterns: Sequence[ColumnPattern]) -> ArrayView:
        """Drop columns from the view that match any pattern.

        Operates on the current view: columns already hidden stay hidden;
        matching columns are removed from the visible list.

        Args:
            patterns: Sequence of ``ColumnPattern`` — exact name, regex, or
                ``callable(name, dtype) -> bool``.

        Returns:
            self, for chaining.

        Raises:
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("exclude_patterns")
        if self.array is None or not patterns:
            return self
        dt = self.array.dtype
        kept: list[str] = []
        for col in self._view_columns:
            if col in (dt.names or ()) and matches_any(col, dt[col], patterns):
                continue
            kept.append(col)
        self._view_columns = kept
        return self

    def set_view_columns(
        self,
        view_columns: list[str] | None = None,
    ) -> ArrayView:
        """Replace the visible column list.

        Provide a whitelist of dtype-level column names.  Pass ``None``
        (or no argument) to reset the view to all dtype columns.

        For pattern-based filtering, compose with
        :meth:`exclude_patterns`:

            view.set_view_columns().exclude_patterns([...])

        Args:
            view_columns: Whitelist of dtype-level column names.  Each
                must exist in the current dtype.  ``None`` resets the
                view to all dtype columns.

        Returns:
            self, for chaining.

        Raises:
            ValueError: If no array is set (when a whitelist is
                provided), if any entry is not in the dtype, or if the
                whitelist contains duplicate entries.
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("set_view_columns")
        if self.array is None:
            if view_columns:
                raise ValueError("No array set")
            self._view_columns = []
            return self

        if view_columns is not None:
            valid = set(self.array.dtype.names or ())
            missing = [c for c in view_columns if c not in valid]
            if missing:
                raise ValueError(f"Unknown view columns: {missing}. Available: {sorted(valid)}")
            duplicates = sorted({c for c in view_columns if view_columns.count(c) > 1})
            if duplicates:
                raise ValueError(f"view_columns contains duplicates: {duplicates}")
            self._view_columns = list(view_columns)
            return self

        if self.array.dtype.names is None:
            raise TypeError("Array has no named fields")
        self._view_columns = list(self.array.dtype.names)
        return self

    def include_view_columns(self, columns: list[str]) -> ArrayView:
        """Append columns to the end of the visible list.

        Args:
            columns: Literal dtype column names.  Each must exist in the
                dtype and must not already be in the visible list.

        Returns:
            self, for chaining.

        Raises:
            ValueError: If any entry is unknown, the input contains
                duplicates, or any entry is already in the visible list.
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("include_view_columns")
        if self.array is None:
            return self
        valid = set(self.array.dtype.names or ())
        missing = [c for c in columns if c not in valid]
        if missing:
            raise ValueError(f"Unknown columns: {missing}. Available: {sorted(valid)}")
        duplicates = sorted({c for c in columns if columns.count(c) > 1})
        if duplicates:
            raise ValueError(f"columns contains duplicates: {duplicates}")
        already_visible = [c for c in columns if c in self._view_columns]
        if already_visible:
            raise ValueError(f"already in view: {sorted(set(already_visible))}")
        self._view_columns.extend(columns)
        return self

    def drop_view_columns(self, columns: list[str]) -> ArrayView:
        """Remove specific columns from the visible list.

        Args:
            columns: Literal column names to drop.  Missing entries are
                ignored silently.

        Returns:
            self, for chaining.

        Raises:
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("drop_view_columns")
        drop = set(columns)
        self._view_columns = [c for c in self._view_columns if c not in drop]
        return self

    # -- Label / value shaping --------------------------------------------------

    def set_column_labels(self, labels: dict[str, str]) -> ArrayView:
        """Set display labels for top-level dtype columns.

        The dtype name is the column's identity — the label only affects
        how the column is rendered in :meth:`to_table`, :meth:`to_dataframe`,
        and :meth:`to_html`.  Other operations (``drop_view_columns``,
        ``include_view_columns``, ``set_view_columns``, ``add_column_group``,
        ``set_index``, ``exclude_patterns``) always refer to dtype names.

        Keys must be top-level dtype field names.  To relabel the
        components of a multi-component field, use
        :meth:`set_component_names` instead.  To relabel a user-declared
        column group or a name column, choose a different name when
        registering it (the chosen name is the display label).

        Args:
            labels: ``{dtype_field_name: display_label}``.

        Returns:
            self, for chaining.

        Raises:
            ValueError: If no array is set, or if any key is not a
                top-level dtype field.
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("set_column_labels")
        if self.array is None:
            if labels:
                raise ValueError("No array set")
            return self
        if self.original_dtype is None or self.original_dtype.names is None:
            raise TypeError("Array has no named fields")
        valid = set(self.original_dtype.names)
        for key in labels:
            if key not in valid:
                if key in {c for comps in self._field_components.values() for c in comps}:
                    raise ValueError(
                        f"'{key}' is a flattened component. "
                        f"Use set_component_names('<field>', [...]) to label components."
                    )
                raise ValueError(
                    f"'{key}' is not a top-level dtype field. Available: {sorted(valid)}"
                )
        self._column_labels.update(labels)
        return self

    def set_component_names(self, field: str, names: list[str]) -> ArrayView:
        """Set component labels for a flattened multi-component field.

        A field like ``position`` with shape ``(3,)`` is flattened
        internally into scalar columns for rendering.  By default the
        components render with labels ``"0", "1", ...``; this method sets
        custom labels such as ``["x", "y", "z"]`` that appear as the
        level-2 header under the field's name.

        Args:
            field: Top-level dtype field name.
            names: Component labels — one per component.

        Returns:
            self, for chaining.

        Raises:
            ValueError: If *field* has no flattened components or the name
                count doesn't match.
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("set_component_names")
        if field not in self._field_components:
            raise ValueError(
                f"Field '{field}' has no flattened components. "
                f"Available: {list(self._field_components)}"
            )
        current = self._field_components[field]
        if len(names) != len(current):
            raise ValueError(
                f"Field '{field}' has {len(current)} components, got {len(names)} names"
            )
        self._component_labels[field] = list(names)
        return self

    def add_column_group(self, name: str, columns: list[str]) -> ArrayView:
        """Register a visual column group (level-1 header label).

        The group spans *columns* in ``to_table()`` and can be used by name
        in ``set_index()`` as a composite row identifier.

        Args:
            name: Group label.  Must not collide with a dtype field or
                existing group.
            columns: Ordered list of dtype field names to group.

        Returns:
            self, for chaining.

        Raises:
            ValueError: If no array is set, *columns* is empty or contains
                duplicates, *name* conflicts with a dtype field or
                existing group, or any column is not in the dtype.
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("add_column_group")
        if self.array is None:
            raise ValueError("No array set")
        if not columns:
            raise ValueError("column group requires at least one column")
        if len(set(columns)) != len(columns):
            raise ValueError("column group columns must not contain duplicates")
        dtype_names = set(self.array.dtype.names or ())
        if name in dtype_names:
            raise ValueError(f"column group name '{name}' conflicts with a dtype field name")
        if name in self._column_groups:
            raise ValueError(f"column group '{name}' already exists")
        for col in columns:
            if col not in dtype_names:
                raise ValueError(
                    f"column '{col}' not found in dtype. Available: {sorted(dtype_names)}"
                )
        self._column_groups[name] = tuple(columns)
        return self

    def remove_column_group(self, name: str) -> ArrayView:
        """Remove a previously registered column group.

        Silently no-ops if *name* is not registered.  If the group is the
        current index source, the index is cleared as well.

        Returns:
            self, for chaining.

        Raises:
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("remove_column_group")
        if self._index == name:
            self._index = None
        self._column_groups.pop(name, None)
        return self

    def add_enum_columns(self, enum_columns: dict[str, tuple[str, dict[int, str]]]) -> ArrayView:
        """Attach virtual columns that decode integer codes to names.

        Each entry registers a virtual string column that replaces an
        existing integer id column in the view.  Mapping is applied only
        when an output method materializes a bounded slice — for a 10M-row
        array with a 20-row window, only 20 lookups happen.

        Values not present in the mapping fall back to the string
        representation of the integer code (e.g., an id value of ``5``
        with a mapping ``{1: "A"}`` renders as ``"5"``).  Validate your
        mappings upstream if strict decoding is required.

        Args:
            enum_columns: ``{name_column: (id_column, {int: str})}`` — the
                *name_column* key becomes both the identifier and the
                displayed header for the decoded column.

        Returns:
            self, for chaining.

        Raises:
            ValueError: If no array is set, or if any *id_column* is not a
                dtype field.
            FrozenViewError: If the view is frozen.

        Example:
            >>> import numpy as np
            >>> from vcti.arrayview import ArrayView, EnumMapping
            >>> arr = np.zeros(2, dtype=[("element_type", "i4")])
            >>> arr["element_type"] = [1, 2]
            >>> view = ArrayView(arr).add_enum_columns({
            ...     "element_type_name": ("element_type", {1: "QUAD", 2: "HEX"}),
            ... })
            >>> "element_type_name" in view.view_columns
            True

            For clearer code, the tuple form also accepts a typed
            :class:`EnumMapping` NamedTuple:

            >>> view = ArrayView(arr).add_enum_columns({
            ...     "element_type_name": EnumMapping(
            ...         id_col="element_type",
            ...         mapping={1: "QUAD", 2: "HEX"},
            ...     ),
            ... })
            >>> view.enum_columns["element_type_name"].id_col
            'element_type'
        """
        self._check_mutable("add_enum_columns")
        if self.array is None:
            if enum_columns:
                raise ValueError("No array set")
            return self
        dtype_names = set(self.array.dtype.names or ())
        unknown = [id_col for _, (id_col, _) in enum_columns.items() if id_col not in dtype_names]
        if unknown:
            raise ValueError(
                f"Unknown id column(s): {sorted(set(unknown))}. Available: {sorted(dtype_names)}"
            )
        self._enum_columns.update(enum_columns)
        replacement_map = {v[0]: k for k, v in enum_columns.items()}
        # Swap id_col -> name_col directly; decoding happens via the
        # _enum_columns lookup at render time.
        for i, col in enumerate(self._view_columns):
            if col in replacement_map:
                self._view_columns[i] = replacement_map[col]
        return self

    # -- Row shaping ------------------------------------------------------------

    def set_index(self, source: str | np.ndarray) -> ArrayView:
        """Designate row identity.

        Args:
            source: Row identifier source:

                * ``str`` — a dtype field name (single-column index) or a
                  registered column group name (multi-column index).
                * ``np.ndarray`` — external 1-D row-aligned array,
                  structured or plain.  A structured dtype exposes each
                  field as its own index column; plain uses ``"id"``.

        Returns:
            self, for chaining.

        Raises:
            TypeError: If *source* is neither str nor ndarray.
            ValueError: If no array is set, the source is unknown, or the
                ndarray is the wrong ndim/length.
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("set_index")
        if self.array is None:
            raise ValueError("No array set")
        if isinstance(source, str):
            dtype_names = set(self.array.dtype.names or ())
            if source not in dtype_names and source not in self._column_groups:
                raise ValueError(
                    f"index source '{source}' is not a dtype field or column group. "
                    f"Available fields: {sorted(dtype_names)}; "
                    f"available groups: {sorted(self._column_groups)}"
                )
            self._index = source
            return self
        if isinstance(source, np.ndarray):
            if source.ndim != 1:
                raise ValueError(f"index array must be 1-D, got ndim={source.ndim}")
            if len(source) != len(self.array):
                raise ValueError(
                    f"index length ({len(source)}) does not match array length ({len(self.array)})"
                )
            dtype_names = set(self.array.dtype.names or ())
            if source.dtype.names is None and "id" in dtype_names:
                raise ValueError(
                    "Plain ndarray index would render under the name 'id', which "
                    "is already a dtype field.  Wrap it in a structured dtype with "
                    "a distinct field name, e.g. "
                    "np.array(values, dtype=[('my_id', values.dtype)])."
                )
            self._index = source
            return self
        raise TypeError(
            f"Expected str or np.ndarray for index source, got {type(source).__name__}"
        )

    def clear_index(self) -> ArrayView:
        """Remove the current row identifier, if any.

        Returns:
            self, for chaining.

        Raises:
            FrozenViewError: If the view is frozen.
        """
        self._check_mutable("clear_index")
        self._index = None
        return self

    def slice(
        self,
        *,
        head: int | None = None,
        tail: int | None = None,
        mask: np.ndarray | None = None,
        indices: np.ndarray | None = None,
    ) -> ArrayView:
        """Configure a bounded row window for subsequent output calls.

        Replaces any prior slice configuration.  Output methods render
        only within this window.  This is the recommended way to keep
        large arrays tractable — displaying 10M rows is meaningless;
        rendering a configured head/tail is what users actually want.

        Args:
            head: Rows from the start.
            tail: Rows from the end.
            mask: Boolean mask array.
            indices: Explicit integer index array.

        Returns:
            self, for chaining.

        Raises:
            ValueError: If *indices* is combined with other parameters,
                *mask* is combined with head/tail, *head*/*tail* is
                negative, *mask* is not boolean or the wrong length, or
                *indices* is not an integer array.
        """
        has_head_tail = head is not None or tail is not None
        if indices is not None and (mask is not None or has_head_tail):
            raise ValueError("Cannot combine 'indices' with other slicing parameters")
        if mask is not None and has_head_tail:
            raise ValueError("Cannot combine 'mask' with 'head'/'tail'")
        if head is not None and head < 0:
            raise ValueError(f"'head' must be non-negative, got {head}")
        if tail is not None and tail < 0:
            raise ValueError(f"'tail' must be non-negative, got {tail}")
        if mask is not None:
            if mask.dtype != np.bool_:
                raise ValueError(f"'mask' must be a boolean array, got dtype {mask.dtype}")
            if self.array is not None and len(mask) != len(self.array):
                raise ValueError(
                    f"'mask' length ({len(mask)}) does not match array length ({len(self.array)})"
                )
        if indices is not None and not np.issubdtype(indices.dtype, np.integer):
            raise ValueError(f"'indices' must be an integer array, got dtype {indices.dtype}")
        if head is None and tail is None and mask is None and indices is None:
            self._slice = None
        else:
            self._slice = {"head": head, "tail": tail, "mask": mask, "indices": indices}
        return self

    def clear_slice(self) -> ArrayView:
        """Clear the slice configuration (output methods render the full range).

        Returns:
            self, for chaining.
        """
        self._slice = None
        return self

    def compute_slice(self) -> np.ndarray:
        """Return the integer index array for the current slice configuration.

        When no slice is configured, returns ``np.arange(len(array))``.

        Returns:
            Integer index array of dtype ``np.intp``.

        Raises:
            ValueError: If no array is set.
        """
        if self.array is None:
            raise ValueError("No array set")
        return self._resolve_slice()

    # -- Output methods ---------------------------------------------------------

    def to_table(
        self,
        *,
        max_col_width: int = 30,
        grouped_headers: bool | None = None,
    ) -> str:
        """Render a text table over the current slice (pure numpy).

        Two-level headers render automatically when any visible column has
        a non-empty group label (from ``add_column_group``, the implicit
        field grouping of flattened components, or a group used as the
        row index).  Pass ``grouped_headers=True``/``False`` to force.

        When no slice is configured, defaults to head=20 / tail=5 so large
        arrays remain readable.

        Args:
            max_col_width: Maximum column display width in characters.
            grouped_headers: Force grouped vs single-level rendering.
                ``None`` (default) auto-selects.

        Returns:
            Formatted text table string.
        """
        if self.array is None or not self._view_columns:
            return repr(self)

        n = len(self.array)

        id_cols = list(self._resolve_index_columns())
        cols = id_cols + [c for c in self._view_columns if c not in id_cols]

        if self._slice is not None:
            indices = self._resolve_slice()
            blocks: list[np.ndarray | None] = [indices]
        elif n > 25:
            blocks = [np.arange(min(20, n)), None, np.arange(max(0, n - 5), n)]
        else:
            blocks = [np.arange(n)]

        str_rows: list[list[str] | None] = []
        for block in blocks:
            if block is None:
                str_rows.append(None)
                continue
            col_values = {col: self._resolve_column_values(col, block) for col in cols}
            for i in range(len(block)):
                str_rows.append([format_value(col_values[col][i]) for col in cols])

        col_headers = [self._column_header(col) for col in cols]

        col_widths: list[int] = []
        for ci, header in enumerate(col_headers):
            max_val = max(
                (len(row[ci]) for row in str_rows if row is not None),
                default=0,
            )
            col_widths.append(min(max(len(header), max_val), max_col_width))

        dt = self.array.dtype
        dtype_names = set(dt.names or ())
        id_col_set = set(id_cols)

        def _is_numeric(col: str) -> bool:
            if self._index_is_external() and col in id_col_set:
                idx_arr: np.ndarray = self._index  # type: ignore[assignment]
                if idx_arr.dtype.names:
                    return np.issubdtype(idx_arr[col].dtype, np.number)
                return np.issubdtype(idx_arr.dtype, np.number)
            if col in self._enum_columns:
                return False
            return col in dtype_names and np.issubdtype(dt[col], np.number)

        col_numeric = [_is_numeric(col) for col in cols]

        def fmt(val: str, ci: int) -> str:
            w = col_widths[ci]
            if len(val) > w:
                val = val[: w - 1] + "\u2026"
            return val.rjust(w) if col_numeric[ci] else val.ljust(w)

        # Level-1 labels: flattened fields (label or field name) and user
        # column groups (group name is the label). Later wins.
        col_to_group: dict[str, str] = {}
        for field, components in self._field_components.items():
            field_label = self._column_labels.get(field, field)
            for c in components:
                col_to_group[c] = field_label
        for name, members in self._column_groups.items():
            for c in members:
                col_to_group[c] = name

        any_label = any(col_to_group.get(c) for c in cols)
        use_grouped = grouped_headers if grouped_headers is not None else any_label

        sep = " | "
        lines: list[str] = []

        if use_grouped:
            self._widen_for_groups(cols, col_widths, col_to_group, max_col_width)
            level1_parts: list[str] = []
            i = 0
            while i < len(cols):
                group = col_to_group.get(cols[i])
                j = i
                while j < len(cols) and col_to_group.get(cols[j]) == group:
                    j += 1
                span_width = sum(col_widths[i:j]) + len(sep) * (j - i - 1)
                level1_parts.append((group or "").center(span_width))
                i = j
            lines.append(sep.join(level1_parts))

        lines.append(
            sep.join(h.ljust(col_widths[ci])[: col_widths[ci]] for ci, h in enumerate(col_headers))
        )
        lines.append("-+-".join("-" * w for w in col_widths))

        for row in str_rows:
            if row is None:
                lines.append(sep.join("...".center(col_widths[ci]) for ci in range(len(cols))))
            else:
                lines.append(sep.join(fmt(row[ci], ci) for ci in range(len(cols))))

        lines.append(f"\n[{n} rows x {len(cols)} columns]")
        return "\n".join(lines)

    def to_dataframe(self, *, resolve_names: bool = True) -> Any:
        """Convert the current slice to a pandas DataFrame.

        When an index is set:

        * ``str`` source — the named column(s) become the pandas
          Index/MultiIndex and are dropped from the data columns.
        * ``ndarray`` source — the external array becomes the
          Index/MultiIndex directly.

        When no slice is configured, the full array is materialized.

        Args:
            resolve_names: If True, materialize enum name columns.

        Returns:
            pandas DataFrame with the configured view columns.

        Raises:
            ImportError: If pandas is not installed.
        """
        pd = import_pandas()

        if self.array is None:
            return pd.DataFrame()

        indices = self._resolve_slice() if self._slice is not None else None
        if indices is None and len(self.array) >= 1_000:
            logger.debug(
                "to_dataframe materializing %d rows with no slice configured; "
                "consider view.slice(head=...) for bounded inspection.",
                len(self.array),
            )
        arr = self.array if indices is None else self.array[indices]
        df = pd.DataFrame(arr)

        cols = self._view_columns

        if resolve_names:
            for name_col, (id_col, mapping) in self._enum_columns.items():
                if name_col in cols:
                    df[name_col] = pd.Categorical(df[id_col].map(mapping))
            data_cols = list(cols)
        else:
            data_cols = [self._enum_columns[c][0] if c in self._enum_columns else c for c in cols]

        df_final, idx_fields = self._apply_index(df, data_cols, indices, pd)
        display_cols = [c for c in data_cols if c not in idx_fields]
        df_final = df_final[display_cols]

        label_map = self._df_label_map(display_cols)
        if label_map:
            df_final = df_final.rename(columns=label_map)
        return df_final

    def _df_label_map(self, cols: list[str]) -> dict[str, str]:
        """Build the {dtype-col -> display-label} map for DataFrame columns.

        Flattened components combine level-1 and level-2 labels as
        ``"{field_label}_{component_label}"`` to keep names unique and
        mirror the two-level text-table header in a flat column space.
        """
        mapping: dict[str, str] = {}
        field_of: dict[str, tuple[str, int]] = {
            c: (field, idx)
            for field, comps in self._field_components.items()
            for idx, c in enumerate(comps)
        }
        for col in cols:
            if col in self._enum_columns:
                continue
            if col in field_of:
                field, idx = field_of[col]
                field_label = self._column_labels.get(field, field)
                comp_labels = self._component_labels.get(field)
                comp_label = comp_labels[idx] if comp_labels is not None else str(idx)
                new = f"{field_label}_{comp_label}"
                if new != col:
                    mapping[col] = new
                continue
            label = self._column_labels.get(col)
            if label is not None and label != col:
                mapping[col] = label
        return mapping

    def _apply_index(
        self,
        df: Any,
        data_cols: list[str],
        indices: np.ndarray | None,
        pd: Any,
    ) -> tuple[Any, list[str]]:
        """Apply the configured row index to *df*; returns (df, idx_fields).

        *idx_fields* is the list of columns that became the index (to be
        excluded from the data columns by the caller).
        """
        if self._index is None:
            return df, []

        if isinstance(self._index, str):
            idx_fields = list(self._resolve_index_columns())
            if len(idx_fields) == 1:
                pd_index = pd.Index(df[idx_fields[0]], name=idx_fields[0])
            else:
                pd_index = pd.MultiIndex.from_frame(df[idx_fields], names=idx_fields)
            return df.set_axis(pd_index, axis=0), idx_fields

        idx_arr: np.ndarray = self._index
        idx_values = idx_arr if indices is None else idx_arr[indices]
        if idx_arr.dtype.names:
            field_names = list(idx_arr.dtype.names)
            if len(field_names) == 1:
                pd_index = pd.Index(idx_values[field_names[0]], name=field_names[0])
            else:
                pd_index = pd.MultiIndex.from_arrays(
                    [idx_values[f] for f in field_names], names=field_names
                )
        else:
            pd_index = pd.Index(idx_values, name="id")
        return df.set_axis(pd_index, axis=0), []

    def to_html(self, **table_kwargs: Any) -> str:
        """Render the current slice as an HTML table string.

        When no slice is configured, behaves like pandas: the full array
        is materialized but pandas truncates visually based on
        ``display.max_rows``.  For a bounded render, configure a slice
        first via ``.slice(head=..., tail=...)``.

        Args:
            **table_kwargs: Forwarded to :meth:`pandas.DataFrame.to_html`
                — e.g. ``table_id``, ``classes``, ``escape``, ``border``,
                ``na_rep``.  Defaults are ``index=<truthy iff index set>``
                and ``na_rep="NaN"``; caller overrides win.

        Returns:
            HTML string (table + a trailing row count paragraph).
        """
        if self.array is None or not self._view_columns:
            return ""

        try:
            pd = import_pandas()
        except ImportError:
            return f"<pre>{self.to_table()}</pre>"

        n = len(self.array)
        has_index = self._index is not None

        if self._slice is not None:
            df = self.to_dataframe()
        else:
            max_rows = pd.get_option("display.max_rows") or 60
            if n <= max_rows:
                df = self.to_dataframe()
            else:
                half = max_rows // 2
                head_view = self.copy().slice(head=half)
                tail_view = self.copy().slice(tail=half)
                head_df = head_view.to_dataframe()
                tail_df = tail_view.to_dataframe()
                ellipsis_data = {col: ["\u22ee"] for col in head_df.columns}
                ellipsis_df = pd.DataFrame(ellipsis_data)
                if has_index:
                    df = pd.concat([head_df, ellipsis_df, tail_df])
                else:
                    df = pd.concat([head_df, ellipsis_df, tail_df], ignore_index=True)

        effective_kwargs: dict[str, Any] = {"index": has_index, "na_rep": "NaN"}
        effective_kwargs.update(table_kwargs)
        html = df.to_html(**effective_kwargs)
        return f"{html}\n<p>{n} rows \u00d7 {len(self._view_columns)} columns</p>"

    def _repr_html_(self) -> str | None:
        """Jupyter rich-display hook — delegates to ``to_html()``."""
        if self.array is None or not self._view_columns:
            return None
        return self.to_html()

    # -- Internal helpers -------------------------------------------------------

    def _resolve_index_columns(self) -> tuple[str, ...]:
        """Return the column names the current index represents."""
        if self._index is None:
            return ()
        if isinstance(self._index, str):
            if self._index in self._column_groups:
                return self._column_groups[self._index]
            return (self._index,)
        return self._index.dtype.names or ("id",)

    def _index_is_external(self) -> bool:
        """True if the current index was supplied as an external ndarray."""
        return isinstance(self._index, np.ndarray)

    def _resolve_slice(self) -> np.ndarray:
        """Materialize the integer index array for the current slice config."""
        if self.array is None:
            return np.array([], dtype=np.intp)
        n = len(self.array)
        if self._slice is None:
            return np.arange(n)
        head = self._slice["head"]
        tail = self._slice["tail"]
        mask = self._slice["mask"]
        indices = self._slice["indices"]
        if indices is not None:
            return np.asarray(indices, dtype=np.intp)
        if mask is not None:
            return np.where(mask)[0]
        if head is not None and tail is not None:
            h = np.arange(min(head, n))
            t = np.arange(max(0, n - tail), n)
            return np.unique(np.concatenate([h, t]))
        if head is not None:
            return np.arange(min(head, n))
        if tail is not None:
            return np.arange(max(0, n - tail), n)
        return np.arange(n)

    def _resolve_column_values(self, col: str, indices: np.ndarray) -> np.ndarray:
        """Resolve column values for a bounded set of row indices."""
        if self.array is None:
            raise ValueError("No array set")
        if self._index_is_external() and col in self._resolve_index_columns():
            idx_arr: np.ndarray = self._index  # type: ignore[assignment]
            if idx_arr.dtype.names:
                return idx_arr[col][indices]
            return idx_arr[indices]
        if col in self._enum_columns:
            id_col, mapping = self._enum_columns[col]
            id_values = self.array[id_col][indices]
            return np.array([mapping.get(int(x), str(x)) for x in id_values])
        return self.array[col][indices]

    def _column_header(self, col: str) -> str:
        """Display header for a column (level-2, used in the header row)."""
        # Flattened component — look up via parent field and component index.
        for field, components in self._field_components.items():
            if col in components:
                idx = components.index(col)
                labels = self._component_labels.get(field)
                if labels is not None:
                    return labels[idx]
                return str(idx)
        # Name columns and external-index columns use their key directly.
        if col in self._enum_columns:
            return col
        if self._index_is_external() and col in self._resolve_index_columns():
            return col
        # Top-level scalar field — apply label if set.
        return self._column_labels.get(col, col)

    @staticmethod
    def _widen_for_groups(
        cols: list[str],
        col_widths: list[int],
        col_to_group: dict[str, str],
        max_col_width: int,
    ) -> None:
        """Widen columns so level-1 group labels fit across their segment."""
        i = 0
        sep_len = 3
        while i < len(cols):
            group = col_to_group.get(cols[i])
            j = i
            while j < len(cols) and col_to_group.get(cols[j]) == group:
                j += 1
            if group:
                span_width = sum(col_widths[i:j]) + sep_len * (j - i - 1)
                needed = len(group)
                if needed > span_width:
                    extra = needed - span_width
                    n_cols = j - i
                    per_col = (extra + n_cols - 1) // n_cols
                    for k in range(i, j):
                        col_widths[k] = min(col_widths[k] + per_col, max_col_width)
            i = j

    # -- Misc -------------------------------------------------------------------

    def copy(self) -> ArrayView:
        """Branch the current view.

        Creates an independent ArrayView over the same underlying array
        (no copy of the array).  Configuration state is deep-copied so
        subsequent mutations don't bleed across branches.  The returned
        copy is always **unfrozen** — if this view was frozen via
        :meth:`freeze`, the copy is modifiable.  That's the idiomatic
        way to "unfreeze": branch a fresh view with ``copy()``.
        """
        new = ArrayView.__new__(ArrayView)
        new.array = self.array
        new.original_dtype = self.original_dtype
        new._view_columns = list(self._view_columns)
        new._enum_columns = copy.deepcopy(self._enum_columns)
        new._field_components = copy.deepcopy(self._field_components)
        new._column_labels = dict(self._column_labels)
        new._component_labels = copy.deepcopy(self._component_labels)
        new._column_groups = dict(self._column_groups)
        new._index = self._index
        new._slice = dict(self._slice) if self._slice is not None else None
        new._frozen = False
        return new

    def freeze(self) -> ArrayView:
        """Freeze this view's configuration.

        After ``freeze()``, all configuration methods — column shaping,
        labels, groups, index, enum mappings, and ``join_fields`` — raise
        :class:`FrozenViewError`.  Slicing, rendering (``to_table`` /
        ``to_dataframe`` / ``to_html``), and ``copy()`` continue to work.

        Freezing is **permanent** for this instance.  To produce a
        modifiable branch, call :meth:`copy` — the copy is always
        unfrozen.

        Returns:
            self, for chaining.

        Example:
            >>> import numpy as np
            >>> from vcti.arrayview import ArrayView, FrozenViewError
            >>> view = ArrayView(np.zeros(3, dtype=[("id", "i4")])).freeze()
            >>> view.is_frozen
            True
            >>> try:
            ...     view.set_index("id")
            ... except FrozenViewError:
            ...     print("blocked")
            blocked
            >>> _ = view.slice(head=2)  # slicing still works
        """
        self._frozen = True
        return self

    def __len__(self) -> int:
        if self.array is None:
            return 0
        return len(self.array)

    def __repr__(self) -> str:
        n_rows = len(self)
        n_cols = len(self._view_columns)
        parts = [f"rows={n_rows}", f"cols={n_cols}"]
        if self._field_components:
            parts.append(f"flattened={len(self._field_components)}")
        if self._enum_columns:
            parts.append(f"enums={len(self._enum_columns)}")
        if self._column_groups:
            parts.append(f"groups={len(self._column_groups)}")
        if self._column_labels:
            parts.append(f"labels={len(self._column_labels)}")
        non_default_comp_labels = sum(
            1
            for field, labels in self._component_labels.items()
            if labels != [str(i) for i in range(len(self._field_components.get(field, [])))]
        )
        if non_default_comp_labels:
            parts.append(f"comp_labels={non_default_comp_labels}")
        if self._index is not None:
            if isinstance(self._index, str):
                parts.append(f"index={self._index}")
            else:
                parts.append("index=<ndarray>")
        if self._slice is not None:
            parts.append("slice=set")
        return f"ArrayView({', '.join(parts)})"

    def __str__(self) -> str:
        parts = ["ArrayView:"]
        if self.array is not None:
            parts.append(f"  Shape: {self.array.shape}")
            parts.append(f"  Dtype: {self.array.dtype}")
            parts.append(f"  View columns ({len(self._view_columns)}):")
            for col in self._view_columns[:10]:
                parts.append(f"    - {col}")
            if len(self._view_columns) > 10:
                parts.append(f"    ... and {len(self._view_columns) - 10} more")
        else:
            parts.append("  Array: None")
        if self._field_components:
            parts.append(f"  Flattened fields: {len(self._field_components)}")
        if self._enum_columns:
            parts.append(f"  Enum mappings: {len(self._enum_columns)}")
        if self._column_groups:
            parts.append(f"  Column groups ({len(self._column_groups)}):")
            for name, members in self._column_groups.items():
                parts.append(f"    - {name}: {list(members)}")
        if self._index is not None:
            if isinstance(self._index, str):
                parts.append(f"  Index: '{self._index}' -> {list(self._resolve_index_columns())}")
            else:
                parts.append(
                    f"  Index: <ndarray> with fields {list(self._resolve_index_columns())}"
                )
        if self._slice is not None:
            parts.append("  Slice: configured")
        return "\n".join(parts)
