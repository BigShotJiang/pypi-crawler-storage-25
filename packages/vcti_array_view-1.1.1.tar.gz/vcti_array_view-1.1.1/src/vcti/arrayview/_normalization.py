# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Input normalization — reinterpret plain arrays as structured arrays.

For a C-contiguous 1-D or 2-D plain array, the same bytes can be viewed as a
structured array without copying.  This mirrors the ``flatten_dtype`` trick
in reverse: instead of expanding structured vector fields into scalar fields,
we expand scalar-dtype columns of a 2-D array into named fields.
"""

from __future__ import annotations

import numpy as np


def to_structured_view(
    arr: np.ndarray,
    field_names: list[str] | None = None,
    field_name_prefix: str = "col",
) -> np.ndarray:
    """Return a structured-array view of *arr* (zero-copy when possible).

    Args:
        arr: Input array.  Structured arrays pass through unchanged.  Plain
            1-D arrays become 1-field structured; plain 2-D arrays of shape
            ``(N, K)`` become K-field structured of length N.
        field_names: Optional explicit field names.  For 1-D input, must have
            length 1; for 2-D input, must have length equal to the number of
            columns.  If None, defaults are generated.
        field_name_prefix: Prefix for auto-generated field names on 2-D
            input.  Names are ``f"{prefix}_0"``, ``f"{prefix}_1"``, ...
            Ignored for 1-D input (which defaults to ``["value"]``) and for
            structured input.

    Returns:
        A structured-dtype view.  For contiguous input, this shares memory
        with *arr*; no data is copied.

    Raises:
        ValueError: If the array is non-contiguous, has ``ndim > 2``, the
            number of field names doesn't match the column count, or
            ``field_names`` contains duplicates.
    """
    if arr.dtype.names is not None:
        return arr

    if arr.ndim == 1:
        names = list(field_names) if field_names is not None else ["value"]
        if len(names) != 1:
            raise ValueError(f"1-D array expects exactly 1 field name, got {len(names)}")
        if not arr.flags["C_CONTIGUOUS"]:
            arr = np.ascontiguousarray(arr)
        return arr.view(np.dtype([(names[0], arr.dtype)]))

    if arr.ndim == 2:
        if not arr.flags["C_CONTIGUOUS"]:
            raise ValueError(
                "2-D arrays must be C-contiguous for zero-copy view. "
                "Call np.ascontiguousarray(arr) first if you accept the copy cost."
            )
        n_cols = arr.shape[1]
        if field_names is not None:
            names = list(field_names)
            if len(names) != n_cols:
                raise ValueError(
                    f"field_names has {len(names)} entries, array has {n_cols} columns"
                )
            if len(set(names)) != len(names):
                raise ValueError("field_names must not contain duplicates")
        else:
            names = [f"{field_name_prefix}_{i}" for i in range(n_cols)]

        struct_dt = np.dtype([(n, arr.dtype) for n in names])
        return arr.view(struct_dt).reshape(arr.shape[0])

    raise ValueError(
        f"Plain arrays must have ndim 1 or 2, got {arr.ndim}-D. "
        "Reshape to 2-D if appropriate (e.g., arr.reshape(n_rows, -1))."
    )
