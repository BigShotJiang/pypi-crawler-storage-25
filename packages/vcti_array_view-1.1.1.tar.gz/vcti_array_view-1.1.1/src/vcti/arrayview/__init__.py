# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti.arrayview — pipeline-style presentation layer for NumPy arrays."""

from importlib.metadata import version

from ._patterns import FILLER_COLUMNS, LENGTH_COLUMNS, VOID_COLUMNS, ColumnPattern
from .array_view import ArrayView, EnumMapping, FrozenViewError

__version__ = version("vcti-array-view")

__all__ = [
    "FILLER_COLUMNS",
    "LENGTH_COLUMNS",
    "VOID_COLUMNS",
    "ArrayView",
    "ColumnPattern",
    "EnumMapping",
    "FrozenViewError",
    "__version__",
]
