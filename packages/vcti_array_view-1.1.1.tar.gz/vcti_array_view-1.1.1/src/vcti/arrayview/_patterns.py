# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Column pattern rules and pre-built patterns.

Patterns match a column by name (exact), regex, or a callable predicate
that receives both the column name and its dtype.  Used by
``exclude_patterns()`` to drop columns without enumerating them.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Sequence

import numpy as np

type ColumnPattern = str | re.Pattern[str] | Callable[[str, np.dtype], bool]
"""A single column-matching rule:

- ``str`` — exact column name match.
- ``re.Pattern`` — regex matched against the column name.
- ``callable(name: str, dtype: np.dtype) -> bool`` — predicate receiving
  both the column name and its dtype, for filtering based on type,
  shape, or any combination.
"""

FILLER_COLUMNS: re.Pattern[str] = re.compile(r"^f\d+$")
"""Matches C++ memory-alignment filler fields by name (f0, f3, f123, ...)."""

LENGTH_COLUMNS: re.Pattern[str] = re.compile(r"_len$")
"""Matches internal string-length columns by name (label_len, name_len, ...)."""


def VOID_COLUMNS(name: str, dtype: np.dtype) -> bool:
    """Exclude all void-dtype fields (C++ alignment padding by dtype)."""
    return dtype.kind == "V"


def matches_any(name: str, dtype: np.dtype, patterns: Sequence[ColumnPattern]) -> bool:
    """Test whether a column name/dtype matches any pattern in *patterns*.

    Args:
        name: Column name to test.
        dtype: Column's dtype.
        patterns: Sequence of pattern rules.

    Returns:
        True if the column matches at least one pattern.
    """
    for rule in patterns:
        if isinstance(rule, str) and name == rule:
            return True
        if isinstance(rule, re.Pattern) and rule.search(name) is not None:
            return True
        if callable(rule) and rule(name, dtype):
            return True
    return False
