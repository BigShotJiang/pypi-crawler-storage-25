# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Stability guard for the package's public import surface.

A failure in this file means something in :mod:`vcti.arrayview`'s
``__all__`` changed — rename, add, or remove a public symbol.  That's
typically a breaking change and should be reflected in CHANGELOG.md.
"""

import vcti.arrayview as av

EXPECTED_ALL = {
    "FILLER_COLUMNS",
    "LENGTH_COLUMNS",
    "VOID_COLUMNS",
    "ArrayView",
    "ColumnPattern",
    "EnumMapping",
    "FrozenViewError",
    "__version__",
}


def test_all_matches_expected() -> None:
    assert set(av.__all__) == EXPECTED_ALL, (
        "The public surface of vcti.arrayview changed.  "
        "Update EXPECTED_ALL in tests/test_public_api.py and document "
        "the change in CHANGELOG.md."
    )


def test_all_symbols_importable() -> None:
    for name in av.__all__:
        assert hasattr(av, name), f"__all__ lists '{name}' but it's not importable"


def test_arrayview_is_exported() -> None:
    from vcti.arrayview import ArrayView

    assert ArrayView is av.ArrayView


def test_enum_mapping_is_namedtuple() -> None:
    from vcti.arrayview import EnumMapping

    em = EnumMapping(id_col="x", mapping={1: "a"})
    assert em.id_col == "x"
    assert em.mapping == {1: "a"}
    # Tuple compat — NamedTuple subclasses tuple.
    assert tuple(em) == ("x", {1: "a"})
