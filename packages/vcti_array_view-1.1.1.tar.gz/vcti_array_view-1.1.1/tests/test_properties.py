# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Property-based tests for ArrayView invariants.

These verify high-level contracts that hold regardless of which
specific inputs a user picks — complementing the example-based tests
in ``test_array_view.py``.
"""

import numpy as np
from hypothesis import given
from hypothesis import strategies as st

from vcti.arrayview import ArrayView

# Fixed pool of candidate field names — small, valid identifiers.
NAME_POOL = [
    "id",
    "value",
    "name",
    "type",
    "tag",
    "score",
    "count",
    "flag",
    "x",
    "y",
]

FIELD_NAMES = st.lists(st.sampled_from(NAME_POOL), min_size=1, max_size=5, unique=True)
KINDS = st.lists(st.sampled_from(["i4", "f8"]), min_size=1, max_size=5)
ROW_COUNT = st.integers(min_value=1, max_value=32)


@st.composite
def _simple_scalar_dtype(draw: st.DrawFn) -> np.dtype:
    """Build a small structured dtype of scalar fields with unique names."""
    names = draw(FIELD_NAMES)
    kinds = draw(st.lists(st.sampled_from(["i4", "f8"]), min_size=len(names), max_size=len(names)))
    return np.dtype(list(zip(names, kinds, strict=True)))


@st.composite
def _array_and_view(draw: st.DrawFn) -> tuple[np.ndarray, ArrayView]:
    dt = draw(_simple_scalar_dtype())
    n = draw(ROW_COUNT)
    arr = np.zeros(n, dtype=dt)
    return arr, ArrayView(arr)


@given(_array_and_view())
def test_view_columns_matches_dtype_names_at_construction(
    pair: tuple[np.ndarray, ArrayView],
) -> None:
    arr, view = pair
    assert view.view_columns == list(arr.dtype.names or ())


@given(_array_and_view())
def test_set_view_columns_whitelist_is_preserved(pair: tuple[np.ndarray, ArrayView]) -> None:
    arr, view = pair
    dtype_names = list(arr.dtype.names or ())
    # Pick a non-empty unique subset in an arbitrary order.
    subset = list(reversed(dtype_names[: max(1, len(dtype_names) // 2)]))
    view.set_view_columns(subset)
    assert view.view_columns == subset


@given(_array_and_view())
def test_drop_then_include_restores_column(pair: tuple[np.ndarray, ArrayView]) -> None:
    arr, view = pair
    dtype_names = list(arr.dtype.names or ())
    target = dtype_names[0]
    view.drop_view_columns([target])
    assert target not in view.view_columns
    view.include_view_columns([target])
    assert target in view.view_columns


@given(_array_and_view())
def test_dtype_identity_preserved_across_shaping(pair: tuple[np.ndarray, ArrayView]) -> None:
    arr, view = pair
    original_names = arr.dtype.names
    dtype_names = list(original_names or ())
    if len(dtype_names) >= 2:
        view.set_column_labels({dtype_names[0]: "relabeled"})
        view.drop_view_columns([dtype_names[1]])
    assert view.array is not None
    assert view.array.dtype.names == original_names


@given(_array_and_view(), st.integers(min_value=0, max_value=64))
def test_compute_slice_head_is_bounded(pair: tuple[np.ndarray, ArrayView], head: int) -> None:
    arr, view = pair
    idx = view.slice(head=head).compute_slice()
    assert len(idx) == min(head, len(arr))
    assert idx.dtype == np.intp


@given(_array_and_view())
def test_copy_is_independent(pair: tuple[np.ndarray, ArrayView]) -> None:
    arr, view = pair
    dtype_names = list(arr.dtype.names or ())
    view.set_column_labels({dtype_names[0]: "alpha"})
    branch = view.copy()
    if len(dtype_names) >= 2:
        branch.drop_view_columns([dtype_names[1]])
    # Underlying array shared.
    assert branch.array is view.array
    # Config independent: original view_columns unchanged.
    assert dtype_names[1] in view.view_columns if len(dtype_names) >= 2 else True


@given(FIELD_NAMES, ROW_COUNT)
def test_set_column_labels_never_changes_view_columns(field_names: list[str], n: int) -> None:
    dt = np.dtype([(name, "f8") for name in field_names])
    view = ArrayView(np.zeros(n, dtype=dt))
    original_cols = view.view_columns
    view.set_column_labels({field_names[0]: "X"})
    # Identity unchanged — only display label updated.
    assert view.view_columns == original_cols
    assert view.column_labels[field_names[0]] == "X"
