# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for vcti.arrayview — builder/pipeline API."""

import re

import numpy as np
import pytest

from vcti.arrayview import (
    FILLER_COLUMNS,
    LENGTH_COLUMNS,
    VOID_COLUMNS,
    ArrayView,
    ColumnPattern,
    EnumMapping,
    FrozenViewError,
)
from vcti.arrayview._patterns import matches_any

# -- Helper dtypes -----------------------------------------------------------

BASIC_DT = np.dtype([("id", "i4"), ("value", "f8"), ("name", "U10")])
FILLER_DT = np.dtype([("id", "i4"), ("f0", "V4"), ("value", "f8"), ("f3", "V8")])
LEN_DT = np.dtype([("id", "i4"), ("label", "U20"), ("label_len", "i4")])
VECTOR_DT = np.dtype([("id", "i4"), ("coords", "f8", (3,))])
ENUM_DT = np.dtype([("id", "i4"), ("type", "i4"), ("value", "f8")])


def _make_basic(n: int = 3) -> np.ndarray:
    arr = np.zeros(n, dtype=BASIC_DT)
    arr["id"] = np.arange(n)
    arr["value"] = np.arange(n, dtype=float) * 1.5
    return arr


def _make_filler(n: int = 3) -> np.ndarray:
    return np.zeros(n, dtype=FILLER_DT)


def _make_enum(n: int = 6) -> np.ndarray:
    arr = np.zeros(n, dtype=ENUM_DT)
    arr["id"] = np.arange(n)
    arr["type"] = np.tile([1, 2], n // 2)
    arr["value"] = np.arange(n, dtype=float) * 10.0
    return arr


# -- matches_any / pattern types ---------------------------------------------


class TestPatternMatching:
    """Unit tests for matches_any() and pre-built column patterns."""

    _dt = np.dtype("i4")
    _vdt = np.dtype("V4")

    def test_exact_string_match(self):
        assert matches_any("debug", self._dt, ["debug"]) is True
        assert matches_any("value", self._dt, ["debug"]) is False

    def test_regex_pattern(self):
        assert matches_any("f0", self._dt, [FILLER_COLUMNS]) is True
        assert matches_any("f123", self._dt, [FILLER_COLUMNS]) is True
        assert matches_any("force", self._dt, [FILLER_COLUMNS]) is False
        assert matches_any("f", self._dt, [FILLER_COLUMNS]) is False

    def test_length_pattern(self):
        assert matches_any("label_len", self._dt, [LENGTH_COLUMNS]) is True
        assert matches_any("label", self._dt, [LENGTH_COLUMNS]) is False

    def test_callable_name_only(self):
        assert matches_any("_private", self._dt, [lambda n, d: n.startswith("_")]) is True
        assert matches_any("public", self._dt, [lambda n, d: n.startswith("_")]) is False

    def test_callable_dtype_based(self):
        assert matches_any("f0", self._vdt, [lambda n, d: d.kind == "V"]) is True
        assert matches_any("id", self._dt, [lambda n, d: d.kind == "V"]) is False

    def test_void_columns(self):
        assert matches_any("f0", self._vdt, [VOID_COLUMNS]) is True
        assert matches_any("anything", self._vdt, [VOID_COLUMNS]) is True
        assert matches_any("id", self._dt, [VOID_COLUMNS]) is False

    def test_mixed_rules(self):
        rules = [FILLER_COLUMNS, LENGTH_COLUMNS, "debug", lambda n, d: n.startswith("_")]
        assert matches_any("f0", self._dt, rules) is True
        assert matches_any("label_len", self._dt, rules) is True
        assert matches_any("debug", self._dt, rules) is True
        assert matches_any("_internal", self._dt, rules) is True
        assert matches_any("value", self._dt, rules) is False

    def test_custom_regex(self):
        pattern = re.compile(r"^internal_")
        assert matches_any("internal_state", self._dt, [pattern]) is True
        assert matches_any("state", self._dt, [pattern]) is False

    def test_empty_rules(self):
        assert matches_any("anything", self._dt, []) is False

    def test_filler_edge_cases(self):
        assert matches_any("", self._dt, [FILLER_COLUMNS]) is False
        assert matches_any("F0", self._dt, [FILLER_COLUMNS]) is False
        assert matches_any("f0x", self._dt, [FILLER_COLUMNS]) is False

    def test_column_pattern_type_exists(self):
        # ColumnPattern is a type alias; this smoke-test ensures it imports.
        _: ColumnPattern = "name"
        _: ColumnPattern = re.compile(r".*")
        _: ColumnPattern = lambda n, d: True  # noqa: E731


# -- Construction ------------------------------------------------------------


class TestConstruction:
    """Constructor accepts only `array`; everything else is post-construction."""

    def test_no_array(self):
        view = ArrayView()
        assert view.array is None
        assert view.view_columns == []
        assert len(view) == 0

    def test_none_array(self):
        view = ArrayView(None)
        assert view.array is None

    def test_structured_array(self):
        arr = _make_basic()
        view = ArrayView(arr)
        assert view.array is not None
        assert view.view_columns == ["id", "value", "name"]
        assert len(view) == 3

    def test_plain_1d_array(self):
        arr = np.array([1.0, 2.0, 3.0])
        view = ArrayView(arr)
        assert view.view_columns == ["value"]
        assert len(view) == 3

    def test_plain_2d_array(self):
        arr = np.zeros((4, 3), dtype=np.float64)
        view = ArrayView(arr)
        assert view.view_columns == ["col_0", "col_1", "col_2"]
        assert len(view) == 4

    def test_reject_non_ndarray(self):
        with pytest.raises(TypeError, match=r"Expected np\.ndarray"):
            ArrayView([1, 2, 3])

    def test_reject_non_contiguous_2d(self):
        arr = np.zeros((4, 6), dtype=np.float64)
        non_contig = arr[:, ::2]
        with pytest.raises(ValueError, match="C-contiguous"):
            ArrayView(non_contig)

    def test_reject_3d(self):
        arr = np.zeros((2, 3, 4), dtype=np.float64)
        with pytest.raises(ValueError, match="ndim 1 or 2"):
            ArrayView(arr)

    def test_empty_structured_array(self):
        arr = np.zeros(0, dtype=BASIC_DT)
        view = ArrayView(arr)
        assert len(view) == 0
        assert view.view_columns == ["id", "value", "name"]
        # Output methods on a zero-row array should not crash.
        text = view.to_table()
        assert "0 rows" in text

    def test_empty_1d_plain_array(self):
        view = ArrayView(np.array([], dtype=np.float64))
        assert len(view) == 0
        assert view.view_columns == ["value"]

    def test_2d_structured_array_passes_through(self):
        # 2-D structured arrays are used as-is without internal flattening.
        arr = np.zeros((2, 3), dtype=[("x", "i4")])
        view = ArrayView(arr)
        assert view.array is not None
        assert view.array.shape == (2, 3)
        assert view.view_columns == ["x"]


# -- Builder chaining --------------------------------------------------------


class TestBuilderChaining:
    """All mutation methods return self for fluent chaining."""

    def test_full_pipeline_chain(self):
        arr = _make_enum()
        result = (
            ArrayView(arr)
            .exclude_patterns([FILLER_COLUMNS])
            .set_column_labels({"value": "val"})
            .add_enum_columns({"type_name": ("type", {1: "A", 2: "B"})})
            .set_index("id")
            .slice(head=3)
        )
        assert isinstance(result, ArrayView)
        assert result.view_columns == ["id", "type_name", "value"]
        assert result.column_labels["value"] == "val"
        assert result.index == "id"

    def test_exclude_patterns_returns_self(self):
        view = ArrayView(_make_basic())
        assert view.exclude_patterns([]) is view

    def test_set_view_columns_returns_self(self):
        view = ArrayView(_make_basic())
        assert view.set_view_columns(["id", "value"]) is view

    def test_include_view_columns_returns_self(self):
        view = ArrayView(_make_basic()).set_view_columns(["id"])
        assert view.include_view_columns(["value"]) is view

    def test_drop_view_columns_returns_self(self):
        view = ArrayView(_make_basic())
        assert view.drop_view_columns(["value"]) is view

    def test_set_column_labels_returns_self(self):
        view = ArrayView(_make_basic())
        assert view.set_column_labels({"value": "val"}) is view

    def test_add_column_group_returns_self(self):
        view = ArrayView(_make_basic())
        assert view.add_column_group("g", ["id", "value"]) is view

    def test_remove_column_group_returns_self(self):
        view = ArrayView(_make_basic()).add_column_group("g", ["id"])
        assert view.remove_column_group("g") is view

    def test_add_enum_columns_returns_self(self):
        view = ArrayView(_make_enum())
        assert view.add_enum_columns({"tn": ("type", {1: "A"})}) is view

    def test_set_index_returns_self(self):
        view = ArrayView(_make_basic())
        assert view.set_index("id") is view

    def test_clear_index_returns_self(self):
        view = ArrayView(_make_basic()).set_index("id")
        assert view.clear_index() is view

    def test_slice_returns_self(self):
        view = ArrayView(_make_basic())
        assert view.slice(head=2) is view

    def test_clear_slice_returns_self(self):
        view = ArrayView(_make_basic()).slice(head=2)
        assert view.clear_slice() is view

    def test_set_component_names_returns_self(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr)
        assert view.set_component_names("coords", ["x", "y", "z"]) is view


# -- Implicit flatten --------------------------------------------------------


class TestImplicitFlatten:
    """Multi-component fields auto-flatten on construction (implementation detail)."""

    def test_vector_field_flattens(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        arr["coords"] = np.arange(9, dtype=float).reshape(3, 3)
        view = ArrayView(arr)
        # The array's dtype is flattened (vector field expanded to scalars)
        assert view.array is not None
        assert len(view.array.dtype.names) == 4  # id + 3 flattened components
        # field_components tracks the grouping under the original field name
        assert "coords" in view.field_components
        assert len(view.field_components["coords"]) == 3

    def test_scalar_only_dtype_no_flatten(self):
        view = ArrayView(_make_basic())
        assert view.field_components == {}

    def test_original_dtype_preserved(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr)
        assert view.original_dtype == VECTOR_DT


# -- set_component_names -----------------------------------------------------


class TestSetComponentNames:
    def test_set_component_labels(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        arr["coords"] = np.arange(9, dtype=float).reshape(3, 3)
        view = ArrayView(arr).set_component_names("coords", ["x", "y", "z"])
        # view_columns keeps dtype names; labels live in component_labels.
        assert view.component_labels["coords"] == ("x", "y", "z")
        # field_components stays as dtype-level names (what numpy sees).
        flat_names = view.field_components["coords"]
        assert len(flat_names) == 3
        for n in flat_names:
            assert n in view.view_columns

    def test_component_labels_default_numeric(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr)
        assert view.component_labels["coords"] == ("0", "1", "2")

    def test_unknown_field_rejected(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="no flattened components"):
            view.set_component_names("nope", ["a"])

    def test_wrong_name_count_rejected(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr)
        with pytest.raises(ValueError, match="3 components, got 2"):
            view.set_component_names("coords", ["x", "y"])


# -- Column shaping ----------------------------------------------------------


class TestColumnShaping:
    def test_exclude_patterns_drops_fillers(self):
        view = ArrayView(_make_filler()).exclude_patterns([FILLER_COLUMNS])
        assert view.view_columns == ["id", "value"]

    def test_exclude_patterns_multiple(self):
        arr = np.zeros(3, dtype=LEN_DT)
        view = ArrayView(arr).exclude_patterns([LENGTH_COLUMNS])
        assert view.view_columns == ["id", "label"]

    def test_exclude_patterns_void(self):
        view = ArrayView(_make_filler()).exclude_patterns([VOID_COLUMNS])
        assert "f0" not in view.view_columns
        assert "f3" not in view.view_columns

    def test_exclude_patterns_empty_is_noop(self):
        view = ArrayView(_make_basic()).exclude_patterns([])
        assert view.view_columns == ["id", "value", "name"]

    def test_set_view_columns_whitelist(self):
        view = ArrayView(_make_basic()).set_view_columns(["id", "value"])
        assert view.view_columns == ["id", "value"]

    def test_set_view_columns_reorders(self):
        view = ArrayView(_make_basic()).set_view_columns(["value", "id"])
        assert view.view_columns == ["value", "id"]

    def test_set_view_columns_reset_then_exclude(self):
        # Pattern-based filtering composes via exclude_patterns.
        view = ArrayView(_make_filler()).set_view_columns().exclude_patterns([FILLER_COLUMNS])
        assert view.view_columns == ["id", "value"]

    def test_set_view_columns_rejects_unknown_column(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="Unknown view columns"):
            view.set_view_columns(["id", "nope"])

    def test_set_view_columns_rejects_duplicates(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="duplicates"):
            view.set_view_columns(["id", "id"])

    def test_include_view_columns_rejects_duplicates(self):
        view = ArrayView(_make_basic()).set_view_columns(["id"])
        with pytest.raises(ValueError, match="duplicates"):
            view.include_view_columns(["value", "value"])

    def test_include_view_columns_rejects_already_visible(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="already in view"):
            view.include_view_columns(["id"])

    def test_set_view_columns_rejects_no_array(self):
        view = ArrayView()
        with pytest.raises(ValueError, match="No array set"):
            view.set_view_columns(["id"])

    def test_set_view_columns_empty_noop_with_no_array(self):
        # No array + no arguments is a legal no-op.
        view = ArrayView().set_view_columns()
        assert view.view_columns == []

    def test_set_view_columns_component_name_not_accepted(self):
        # Flattened component dtype names are valid view column names.
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr).set_component_names("coords", ["x", "y", "z"])
        # A flattened dtype name is valid (it IS a dtype field after flatten).
        dtype_comp = view.field_components["coords"][0]
        view.set_view_columns(["id", dtype_comp])
        assert view.view_columns == ["id", dtype_comp]

    def test_include_view_columns(self):
        view = ArrayView(_make_basic()).set_view_columns(["id"])
        view.include_view_columns(["value"])
        assert view.view_columns == ["id", "value"]

    def test_include_view_columns_rejects_unknown(self):
        view = ArrayView(_make_basic()).set_view_columns(["id"])
        with pytest.raises(ValueError, match="Unknown columns"):
            view.include_view_columns(["nope"])

    def test_include_view_columns_no_array_is_noop(self):
        view = ArrayView()
        assert view.include_view_columns(["x"]) is view
        assert view.view_columns == []

    def test_drop_view_columns(self):
        view = ArrayView(_make_basic()).drop_view_columns(["value"])
        assert view.view_columns == ["id", "name"]

    def test_drop_view_columns_missing_ignored(self):
        view = ArrayView(_make_basic()).drop_view_columns(["nope"])
        assert view.view_columns == ["id", "value", "name"]

    def test_set_column_labels_leaves_view_columns_alone(self):
        # view_columns holds dtype names; labels are a separate concern.
        view = ArrayView(_make_basic()).set_column_labels({"value": "val"})
        assert view.view_columns == ["id", "value", "name"]
        assert view.column_labels["value"] == "val"

    def test_set_column_labels_does_not_alter_dtype(self):
        view = ArrayView(_make_basic()).set_column_labels({"value": "val"})
        assert "value" in (view.array.dtype.names or ())

    def test_labeled_column_renders_in_table(self):
        view = ArrayView(_make_basic()).set_column_labels({"value": "val"})
        text = view.to_table()
        assert "val" in text
        assert "1.5" in text

    def test_labeled_column_renders_in_dataframe(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic()).set_column_labels({"value": "val"})
        df = view.to_dataframe()
        assert "val" in df.columns
        assert "value" not in df.columns

    def test_set_column_labels_rejects_flattened_component(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr)
        flat_name = view.field_components["coords"][0]
        with pytest.raises(ValueError, match="flattened component"):
            view.set_column_labels({flat_name: "X"})

    def test_set_column_labels_empty_noop_no_array(self):
        view = ArrayView()
        assert view.set_column_labels({}) is view

    def test_set_column_labels_rejects_when_no_array(self):
        view = ArrayView()
        with pytest.raises(ValueError, match="No array set"):
            view.set_column_labels({"x": "X"})

    def test_set_column_labels_rejects_unknown_field(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="top-level dtype field"):
            view.set_column_labels({"nope": "whatever"})

    def test_label_persists_across_view_changes(self):
        # Drop and re-include: the label still applies.
        view = ArrayView(_make_basic()).set_column_labels({"value": "val"})
        view.drop_view_columns(["value"]).include_view_columns(["value"])
        assert "value" in view.view_columns
        assert view.column_labels["value"] == "val"


# -- Column groups -----------------------------------------------------------


class TestColumnGroups:
    def test_add_group(self):
        view = ArrayView(_make_basic()).add_column_group("pair", ["id", "value"])
        assert dict(view.column_groups) == {"pair": ("id", "value")}

    def test_remove_group(self):
        view = ArrayView(_make_basic()).add_column_group("pair", ["id", "value"])
        view.remove_column_group("pair")
        assert dict(view.column_groups) == {}

    def test_remove_missing_group_is_noop(self):
        view = ArrayView(_make_basic())
        view.remove_column_group("nope")  # no error

    def test_remove_group_clears_index(self):
        view = ArrayView(_make_basic()).add_column_group("pair", ["id", "value"]).set_index("pair")
        assert view.index == "pair"
        view.remove_column_group("pair")
        assert view.index is None

    def test_add_group_rejects_dtype_name_collision(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="conflicts with a dtype field"):
            view.add_column_group("id", ["value"])

    def test_add_group_rejects_duplicate_group(self):
        view = ArrayView(_make_basic()).add_column_group("g", ["id"])
        with pytest.raises(ValueError, match="already exists"):
            view.add_column_group("g", ["value"])

    def test_add_group_rejects_unknown_column(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="not found in dtype"):
            view.add_column_group("g", ["nope"])

    def test_add_group_rejects_empty_columns(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="at least one column"):
            view.add_column_group("g", [])

    def test_add_group_rejects_duplicate_columns(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="duplicates"):
            view.add_column_group("g", ["id", "id"])

    def test_add_group_requires_array(self):
        view = ArrayView()
        with pytest.raises(ValueError, match="No array set"):
            view.add_column_group("g", ["id"])

    def test_group_label_unaffected_by_column_label(self):
        # Group members are dtype names; labeling a column doesn't touch the
        # group's membership or its label.
        view = (
            ArrayView(_make_basic())
            .add_column_group("pair", ["id", "value"])
            .set_column_labels({"value": "val"})
        )
        text = view.to_table()
        first_line = text.splitlines()[0]
        assert "pair" in first_line
        # The labeled value column header reads as "val".
        assert "val" in text

    def test_group_over_flattened_components_with_labels(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr)
        comp_dtype_names = view.field_components["coords"]
        view.add_column_group("vec", list(comp_dtype_names))
        view.set_component_names("coords", ["x", "y", "z"])
        text = view.to_table()
        first_line = text.splitlines()[0]
        # "vec" overrides the field-level "coords" grouping.
        assert "vec" in first_line


# -- Enum mapping ------------------------------------------------------------


class TestEnumMapping:
    def test_add_enum_columns_replaces_id_in_view(self):
        view = ArrayView(_make_enum()).add_enum_columns({"type_name": ("type", {1: "A", 2: "B"})})
        assert "type_name" in view.view_columns
        assert "type" not in view.view_columns

    def test_enum_columns_read_only(self):
        view = ArrayView(_make_enum()).add_enum_columns({"type_name": ("type", {1: "A"})})
        mapping = view.enum_columns
        with pytest.raises(TypeError):
            mapping["new"] = ("x", {})

    def test_resolution_is_lazy(self):
        # Resolution happens only when an output method runs.  Here we
        # verify the recipe is stored; actual resolution tested via to_dataframe.
        view = ArrayView(_make_enum()).add_enum_columns({"type_name": ("type", {1: "A", 2: "B"})})
        assert view.enum_columns["type_name"] == ("type", {1: "A", 2: "B"})

    def test_add_enum_columns_rejects_unknown_id_col(self):
        view = ArrayView(_make_enum())
        with pytest.raises(ValueError, match="Unknown id column"):
            view.add_enum_columns({"type_name": ("nope", {1: "A"})})

    def test_add_enum_columns_rejects_when_no_array(self):
        view = ArrayView()
        with pytest.raises(ValueError, match="No array set"):
            view.add_enum_columns({"type_name": ("type", {1: "A"})})

    def test_add_enum_columns_empty_noop_no_array(self):
        view = ArrayView()
        assert view.add_enum_columns({}) is view

    def test_unbounded_dataframe_over_threshold_logs_debug(self, caplog):
        pytest.importorskip("pandas")
        import logging

        arr = _make_basic(1_500)
        view = ArrayView(arr)
        with caplog.at_level(logging.DEBUG, logger="vcti.arrayview.array_view"):
            view.to_dataframe()
        assert any("no slice configured" in rec.message for rec in caplog.records)

    def test_unbounded_dataframe_below_threshold_does_not_log(self, caplog):
        pytest.importorskip("pandas")
        import logging

        arr = _make_basic(500)
        view = ArrayView(arr)
        with caplog.at_level(logging.DEBUG, logger="vcti.arrayview.array_view"):
            view.to_dataframe()
        assert not any("no slice configured" in rec.message for rec in caplog.records)

    def test_add_enum_columns_accepts_enum_mapping_namedtuple(self):
        view = ArrayView(_make_enum()).add_enum_columns(
            {"type_name": EnumMapping(id_col="type", mapping={1: "A", 2: "B"})}
        )
        assert "type_name" in view.view_columns
        # Stored value is a tuple-compatible EnumMapping.
        stored = view.enum_columns["type_name"]
        assert stored[0] == "type"
        assert stored[1] == {1: "A", 2: "B"}

    def test_unmapped_enum_falls_back_to_str(self):
        # Documented behavior: unmapped codes render as str(int_value).
        arr = _make_enum(6)
        view = ArrayView(arr).add_enum_columns(
            {"type_name": ("type", {1: "A"})}  # type=2 unmapped
        )
        text = view.to_table()
        assert " 2 " in text or text.count("2") > 0  # raw "2" appears


# -- Row index ---------------------------------------------------------------


class TestRowIndex:
    def test_set_index_string(self):
        view = ArrayView(_make_basic()).set_index("id")
        assert view.index == "id"

    def test_clear_index(self):
        view = ArrayView(_make_basic()).set_index("id")
        view.clear_index()
        assert view.index is None

    def test_set_index_via_group(self):
        view = ArrayView(_make_basic()).add_column_group("pair", ["id", "value"]).set_index("pair")
        assert view.index == "pair"

    def test_set_index_external_ndarray(self):
        # Plain external ndarray uses "id" as its label, so the dtype
        # must not already have an "id" field.
        arr = np.zeros(3, dtype=[("a", "i4"), ("b", "f8")])
        ext = np.arange(len(arr), dtype=np.int64)
        view = ArrayView(arr).set_index(ext)
        assert isinstance(view.index, np.ndarray)

    def test_set_index_plain_ndarray_rejects_id_collision(self):
        arr = _make_basic()  # has dtype field "id"
        ext = np.arange(len(arr), dtype=np.int64)
        with pytest.raises(ValueError, match="'id'"):
            ArrayView(arr).set_index(ext)

    def test_set_index_external_structured_ndarray(self):
        arr = _make_basic()
        ext = np.zeros(len(arr), dtype=[("a", "i4"), ("b", "i4")])
        view = ArrayView(arr).set_index(ext)
        assert isinstance(view.index, np.ndarray)

    def test_set_index_rejects_unknown_source(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="not a dtype field or column group"):
            view.set_index("nope")

    def test_set_index_rejects_2d_ndarray(self):
        arr = _make_basic()
        view = ArrayView(arr)
        with pytest.raises(ValueError, match="must be 1-D"):
            view.set_index(np.zeros((3, 2)))

    def test_set_index_rejects_length_mismatch(self):
        arr = _make_basic(3)
        view = ArrayView(arr)
        with pytest.raises(ValueError, match="does not match array length"):
            view.set_index(np.arange(5))

    def test_set_index_rejects_bad_type(self):
        view = ArrayView(_make_basic())
        with pytest.raises(TypeError, match=r"Expected str or np\.ndarray"):
            view.set_index(42)

    def test_set_index_requires_array(self):
        view = ArrayView()
        with pytest.raises(ValueError, match="No array set"):
            view.set_index("id")


# -- Slice -------------------------------------------------------------------


class TestSlice:
    def test_slice_head(self):
        view = ArrayView(_make_basic(10)).slice(head=3)
        idx = view.compute_slice()
        assert list(idx) == [0, 1, 2]

    def test_slice_tail(self):
        view = ArrayView(_make_basic(10)).slice(tail=3)
        idx = view.compute_slice()
        assert list(idx) == [7, 8, 9]

    def test_slice_head_and_tail(self):
        view = ArrayView(_make_basic(10)).slice(head=2, tail=2)
        idx = view.compute_slice()
        assert list(idx) == [0, 1, 8, 9]

    def test_slice_mask(self):
        view = ArrayView(_make_basic(5))
        mask = np.array([True, False, True, False, True])
        view.slice(mask=mask)
        idx = view.compute_slice()
        assert list(idx) == [0, 2, 4]

    def test_slice_indices_passthrough(self):
        view = ArrayView(_make_basic(5))
        explicit = np.array([1, 3], dtype=np.intp)
        view.slice(indices=explicit)
        assert np.array_equal(view.compute_slice(), explicit)

    def test_compute_slice_returns_intp_even_for_non_intp_indices(self):
        # Documented contract: compute_slice returns np.intp.  User-supplied
        # integer arrays of any width are cast.
        view = ArrayView(_make_basic(5))
        view.slice(indices=np.array([1, 3], dtype=np.int32))
        out = view.compute_slice()
        assert out.dtype == np.intp
        assert list(out) == [1, 3]

    def test_slice_rejects_indices_with_head(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="Cannot combine 'indices'"):
            view.slice(indices=np.array([0]), head=1)

    def test_slice_rejects_mask_with_head(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="Cannot combine 'mask' with 'head'"):
            view.slice(mask=np.array([True]), head=1)

    def test_slice_rejects_negative_head(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="'head' must be non-negative"):
            view.slice(head=-1)

    def test_slice_rejects_negative_tail(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="'tail' must be non-negative"):
            view.slice(tail=-3)

    def test_slice_rejects_non_bool_mask(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="'mask' must be a boolean array"):
            view.slice(mask=np.array([0, 1, 0], dtype=np.int32))

    def test_slice_rejects_mismatched_mask_length(self):
        view = ArrayView(_make_basic(3))
        with pytest.raises(ValueError, match="does not match array length"):
            view.slice(mask=np.array([True, False]))

    def test_slice_rejects_non_integer_indices(self):
        view = ArrayView(_make_basic())
        with pytest.raises(ValueError, match="'indices' must be an integer array"):
            view.slice(indices=np.array([0.5, 1.5]))

    def test_clear_slice(self):
        view = ArrayView(_make_basic(5)).slice(head=2).clear_slice()
        idx = view.compute_slice()
        assert list(idx) == [0, 1, 2, 3, 4]

    def test_slice_no_args_clears(self):
        view = ArrayView(_make_basic(5)).slice(head=2).slice()
        idx = view.compute_slice()
        assert list(idx) == [0, 1, 2, 3, 4]

    def test_slice_replaces_prior_config(self):
        view = ArrayView(_make_basic(10)).slice(head=3).slice(tail=2)
        idx = view.compute_slice()
        assert list(idx) == [8, 9]

    def test_compute_slice_without_config(self):
        view = ArrayView(_make_basic(5))
        idx = view.compute_slice()
        assert list(idx) == [0, 1, 2, 3, 4]

    def test_compute_slice_requires_array(self):
        view = ArrayView()
        with pytest.raises(ValueError, match="No array set"):
            view.compute_slice()


# -- to_table ----------------------------------------------------------------


class TestToTable:
    def test_basic(self):
        view = ArrayView(_make_basic(3))
        text = view.to_table()
        assert "id" in text
        assert "value" in text
        assert "3 rows" in text

    def test_empty_array(self):
        view = ArrayView()
        text = view.to_table()
        # Empty view falls back to repr
        assert "ArrayView" in text

    def test_with_slice(self):
        view = ArrayView(_make_basic(50)).slice(head=5)
        text = view.to_table()
        assert "50 rows" in text

    def test_large_array_auto_truncates(self):
        view = ArrayView(_make_basic(100))
        text = view.to_table()
        assert "..." in text
        assert "100 rows" in text

    def test_small_array_no_ellipsis(self):
        view = ArrayView(_make_basic(5))
        text = view.to_table()
        assert "..." not in text

    def test_with_index(self):
        view = ArrayView(_make_basic(3)).set_index("id")
        text = view.to_table()
        # id should appear as first column
        lines = text.splitlines()
        header = next(line for line in lines if "id" in line)
        assert header.index("id") < header.index("value")

    def test_grouped_headers_from_vector(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        arr["coords"] = np.arange(9, dtype=float).reshape(3, 3)
        view = ArrayView(arr).set_component_names("coords", ["x", "y", "z"])
        text = view.to_table()
        assert "coords" in text

    def test_grouped_headers_from_group(self):
        view = ArrayView(_make_basic()).add_column_group("g", ["id", "value"])
        text = view.to_table()
        assert "g" in text

    def test_grouped_headers_force_off(self):
        view = ArrayView(_make_basic()).add_column_group("g", ["id", "value"])
        text = view.to_table(grouped_headers=False)
        # The group label row shouldn't appear
        first_line = text.splitlines()[0]
        assert "g" not in first_line.strip() or first_line.strip().startswith("id")

    def test_name_column_resolves_lazily_in_table(self):
        view = ArrayView(_make_enum()).add_enum_columns({"type_name": ("type", {1: "A", 2: "B"})})
        text = view.to_table()
        assert "A" in text or "B" in text

    def test_external_index_renders(self):
        arr = np.zeros(3, dtype=[("a", "i4"), ("b", "f8")])
        ext = np.array([100, 200, 300], dtype=np.int64)
        view = ArrayView(arr).set_index(ext)
        text = view.to_table()
        assert "100" in text

    def test_structured_external_index_numeric_alignment(self):
        # Structured external-index column should render right-aligned
        # (numeric dtype) when the index's field is numeric.
        arr = np.zeros(3, dtype=[("a", "i4")])
        ext = np.zeros(3, dtype=[("num_id", "i4"), ("label", "U4")])
        ext["num_id"] = [10, 20, 30]
        ext["label"] = ["x", "y", "z"]
        view = ArrayView(arr).set_index(ext)
        text = view.to_table()
        assert "10" in text and "20" in text

    def test_long_value_truncated_with_ellipsis(self):
        arr = np.zeros(1, dtype=[("text", "U50")])
        arr["text"] = "a" * 50
        view = ArrayView(arr).to_table(max_col_width=10)
        assert "\u2026" in view


# -- to_dataframe ------------------------------------------------------------


class TestToDataFrame:
    def test_basic(self):
        pd = pytest.importorskip("pandas")
        view = ArrayView(_make_basic(3))
        df = view.to_dataframe()
        assert list(df.columns) == ["id", "value", "name"]
        assert len(df) == 3
        assert isinstance(df, pd.DataFrame)

    def test_empty(self):
        pytest.importorskip("pandas")
        view = ArrayView()
        df = view.to_dataframe()
        assert len(df) == 0

    def test_with_slice(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(10)).slice(head=3)
        df = view.to_dataframe()
        assert len(df) == 3

    def test_with_string_index(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(3)).set_index("id")
        df = view.to_dataframe()
        assert df.index.name == "id"
        assert "id" not in df.columns

    def test_with_group_index(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(3)).add_column_group("pair", ["id", "name"]).set_index("pair")
        df = view.to_dataframe()
        assert df.index.names == ["id", "name"]

    def test_with_external_index_plain(self):
        pytest.importorskip("pandas")
        arr = np.zeros(3, dtype=[("a", "i4"), ("b", "f8")])
        ext = np.array([100, 200, 300], dtype=np.int64)
        view = ArrayView(arr).set_index(ext)
        df = view.to_dataframe()
        assert list(df.index) == [100, 200, 300]
        assert df.index.name == "id"

    def test_with_external_index_structured(self):
        pytest.importorskip("pandas")
        arr = _make_basic(3)
        ext = np.zeros(3, dtype=[("a", "i4"), ("b", "i4")])
        ext["a"] = [1, 2, 3]
        ext["b"] = [10, 20, 30]
        view = ArrayView(arr).set_index(ext)
        df = view.to_dataframe()
        assert df.index.names == ["a", "b"]

    def test_external_index_with_slice(self):
        pytest.importorskip("pandas")
        arr = np.zeros(5, dtype=[("a", "i4"), ("b", "f8")])
        ext = np.arange(100, 105, dtype=np.int64)
        view = ArrayView(arr).set_index(ext).slice(head=3)
        df = view.to_dataframe()
        assert list(df.index) == [100, 101, 102]

    def test_enum_resolved(self):
        pd = pytest.importorskip("pandas")
        view = ArrayView(_make_enum()).add_enum_columns({"type_name": ("type", {1: "A", 2: "B"})})
        df = view.to_dataframe()
        assert "type_name" in df.columns
        assert isinstance(df["type_name"].dtype, pd.CategoricalDtype)

    def test_enum_not_resolved_when_flag_off(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_enum()).add_enum_columns({"type_name": ("type", {1: "A", 2: "B"})})
        df = view.to_dataframe(resolve_names=False)
        assert "type_name" not in df.columns
        assert "type" in df.columns


# -- to_html -----------------------------------------------------------------


class TestToHtml:
    def test_basic(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(3))
        html = view.to_html()
        assert "<table" in html
        assert "3 rows" in html

    def test_empty(self):
        view = ArrayView()
        assert view.to_html() == ""

    def test_with_slice(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(10)).slice(head=3)
        html = view.to_html()
        assert "<table" in html
        assert "10 rows" in html

    def test_large_array_truncated(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(500))
        html = view.to_html()
        assert "&#8942;" in html or "\u22ee" in html
        assert "500 rows" in html

    def test_repr_html_delegates(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(3))
        assert view._repr_html_() == view.to_html()

    def test_to_html_forwards_table_kwargs(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(3))
        html = view.to_html(table_id="mytbl", classes="my-class")
        assert 'id="mytbl"' in html
        assert "my-class" in html

    def test_to_html_kwargs_override_defaults(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(3)).set_index("id")
        # Override the default index=has_index.
        html = view.to_html(index=False)
        # "id" header should not appear (index was suppressed).
        assert "thead" in html

    def test_repr_html_none_for_empty(self):
        view = ArrayView()
        assert view._repr_html_() is None


# -- Read-only properties ----------------------------------------------------


class TestReadOnlyProperties:
    def test_view_columns_is_defensive_copy(self):
        view = ArrayView(_make_basic())
        cols = view.view_columns
        cols.append("hacked")
        assert "hacked" not in view.view_columns

    def test_enum_columns_is_read_only(self):
        view = ArrayView(_make_enum()).add_enum_columns({"type_name": ("type", {1: "A"})})
        with pytest.raises(TypeError):
            view.enum_columns["new"] = ("x", {})

    def test_field_components_is_read_only(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr)
        with pytest.raises(TypeError):
            view.field_components["new"] = ["a", "b"]

    def test_field_components_values_are_immutable(self):
        # Values are returned as tuples — mutation attempts fail.
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr)
        with pytest.raises(AttributeError):
            view.field_components["coords"].append("coords_w")  # type: ignore[attr-defined]

    def test_column_groups_is_read_only(self):
        view = ArrayView(_make_basic()).add_column_group("g", ["id"])
        with pytest.raises(TypeError):
            view.column_groups["h"] = ("value",)

    def test_index_property(self):
        view = ArrayView(_make_basic())
        assert view.index is None
        view.set_index("id")
        assert view.index == "id"


# -- copy --------------------------------------------------------------------


class TestCopy:
    def test_copy_independent_view_columns(self):
        view = ArrayView(_make_basic())
        branch = view.copy()
        branch.drop_view_columns(["value"])
        assert "value" in view.view_columns
        assert "value" not in branch.view_columns

    def test_copy_shares_array(self):
        view = ArrayView(_make_basic())
        branch = view.copy()
        assert view.array is branch.array

    def test_copy_independent_groups(self):
        view = ArrayView(_make_basic()).add_column_group("g", ["id"])
        branch = view.copy()
        branch.remove_column_group("g")
        assert "g" in view.column_groups
        assert "g" not in branch.column_groups

    def test_copy_independent_slice(self):
        view = ArrayView(_make_basic(10)).slice(head=3)
        branch = view.copy().slice(tail=2)
        assert list(view.compute_slice()) == [0, 1, 2]
        assert list(branch.compute_slice()) == [8, 9]

    def test_copy_preserves_index(self):
        view = ArrayView(_make_basic()).set_index("id")
        branch = view.copy()
        assert branch.index == "id"


# -- __repr__ / __str__ ------------------------------------------------------


class TestReprStr:
    def test_repr_empty(self):
        view = ArrayView()
        r = repr(view)
        assert "ArrayView" in r
        assert "rows=0" in r

    def test_repr_with_features(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr).add_column_group("g", ["id"]).set_index("id").slice(head=2)
        r = repr(view)
        assert "flattened=1" in r
        assert "groups=1" in r
        assert "index=id" in r
        assert "slice=set" in r

    def test_repr_labels_counter(self):
        view = ArrayView(_make_basic()).set_column_labels({"value": "val"})
        r = repr(view)
        assert "labels=1" in r

    def test_repr_comp_labels_counter(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr)
        # Default numeric component labels — not counted.
        assert "comp_labels" not in repr(view)
        view.set_component_names("coords", ["x", "y", "z"])
        assert "comp_labels=1" in repr(view)

    def test_repr_external_index(self):
        arr = np.zeros(3, dtype=[("a", "i4"), ("b", "f8")])
        view = ArrayView(arr).set_index(np.arange(len(arr)))
        r = repr(view)
        assert "index=<ndarray>" in r

    def test_str_empty(self):
        view = ArrayView()
        s = str(view)
        assert "Array: None" in s

    def test_str_with_array(self):
        arr = np.zeros(3, dtype=VECTOR_DT)
        view = ArrayView(arr).add_column_group("g", ["id"]).set_index("id")
        s = str(view)
        assert "Shape:" in s
        assert "Dtype:" in s
        assert "Column groups" in s
        assert "Index:" in s

    def test_str_truncates_long_column_list(self):
        # 15 columns > 10-line truncation threshold
        n_cols = 15
        dt = np.dtype([(f"c{i}", "f8") for i in range(n_cols)])
        arr = np.zeros(3, dtype=dt)
        view = ArrayView(arr)
        s = str(view)
        assert "and 5 more" in s


# -- Index + view_columns interaction ----------------------------------------


class TestIndexViewInteraction:
    def test_index_column_not_in_data_cols_dataframe(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic()).set_index("id")
        df = view.to_dataframe()
        assert "id" not in df.columns
        assert df.index.name == "id"

    def test_index_column_appears_first_in_table(self):
        view = ArrayView(_make_basic()).set_index("value")
        text = view.to_table()
        header_line = next(line for line in text.splitlines() if "value" in line and "id" in line)
        assert header_line.index("value") < header_line.index("id")


# -- Plain array edge cases --------------------------------------------------


class TestPlainArrays:
    def test_1d_default_name(self):
        view = ArrayView(np.array([1.0, 2.0, 3.0]))
        assert view.view_columns == ["value"]

    def test_2d_default_names(self):
        view = ArrayView(np.zeros((3, 4)))
        assert view.view_columns == ["col_0", "col_1", "col_2", "col_3"]

    def test_2d_label_via_method(self):
        view = ArrayView(np.zeros((3, 2))).set_column_labels({"col_0": "x", "col_1": "y"})
        # view_columns stays as dtype names; labels live in column_labels.
        assert view.view_columns == ["col_0", "col_1"]
        assert view.column_labels["col_0"] == "x"
        assert view.column_labels["col_1"] == "y"

    def test_2d_non_contiguous_rejected(self):
        arr = np.zeros((4, 6))
        non_contig = arr[:, ::2]
        with pytest.raises(ValueError, match="C-contiguous"):
            ArrayView(non_contig)


# -- Internal helper coverage ------------------------------------------------


class TestInternals:
    """Cover internal helper branches not exercised through the public ctor."""

    def test_format_value_nan(self):
        from vcti.arrayview._formatting import format_value

        assert format_value(float("nan")) == "NaN"

    def test_format_value_bytes(self):
        from vcti.arrayview._formatting import format_value

        assert format_value(b"hello") == "hello"

    def test_format_value_int(self):
        from vcti.arrayview._formatting import format_value

        assert format_value(np.int32(42)) == "42"

    def test_format_value_string_passthrough(self):
        from vcti.arrayview._formatting import format_value

        assert format_value("hello") == "hello"
        assert format_value(np.str_("world")) == "world"

    def test_format_value_datetime64(self):
        from vcti.arrayview._formatting import format_value

        dt_val = np.datetime64("2026-04-18")
        assert "2026-04-18" in format_value(dt_val)

    def test_format_value_complex(self):
        from vcti.arrayview._formatting import format_value

        # Complex scalars fall through to str(); just verify it doesn't crash.
        assert isinstance(format_value(complex(1, 2)), str)

    def test_to_structured_view_1d_with_name(self):
        from vcti.arrayview._normalization import to_structured_view

        arr = np.array([1.0, 2.0, 3.0])
        view = to_structured_view(arr, field_names=["x"])
        assert view.dtype.names == ("x",)

    def test_to_structured_view_1d_wrong_name_count(self):
        from vcti.arrayview._normalization import to_structured_view

        with pytest.raises(ValueError, match="1-D array expects exactly 1 field name"):
            to_structured_view(np.array([1.0, 2.0]), field_names=["x", "y"])

    def test_to_structured_view_1d_non_contiguous_copies(self):
        from vcti.arrayview._normalization import to_structured_view

        arr = np.arange(10, dtype=np.float64)[::2]
        view = to_structured_view(arr)
        assert view.dtype.names == ("value",)

    def test_to_structured_view_2d_wrong_name_count(self):
        from vcti.arrayview._normalization import to_structured_view

        arr = np.zeros((3, 4), dtype=np.float64)
        with pytest.raises(ValueError, match="has 2 entries, array has 4 columns"):
            to_structured_view(arr, field_names=["a", "b"])

    def test_to_structured_view_2d_duplicate_names(self):
        from vcti.arrayview._normalization import to_structured_view

        arr = np.zeros((3, 3), dtype=np.float64)
        with pytest.raises(ValueError, match="must not contain duplicates"):
            to_structured_view(arr, field_names=["x", "y", "x"])

    def test_to_structured_view_2d_custom_names(self):
        from vcti.arrayview._normalization import to_structured_view

        arr = np.zeros((3, 2), dtype=np.float64)
        view = to_structured_view(arr, field_names=["a", "b"])
        assert view.dtype.names == ("a", "b")

    def test_build_field_components_requires_structured(self):
        from vcti.arrayview._flattening import build_field_components

        with pytest.raises(TypeError, match="must be a structured dtype"):
            build_field_components(np.dtype("f8"), np.dtype([("a", "f8")]))
        with pytest.raises(TypeError, match="must be a structured dtype"):
            build_field_components(np.dtype([("a", "f8")]), np.dtype("f8"))


# -- join_fields ------------------------------------------------------------


class TestJoinFields:
    def test_join_two_adjacent_s4_to_s8(self):
        arr = np.zeros(2, dtype=[("lo", "S4"), ("hi", "S4"), ("tag", "i4")])
        arr["lo"] = [b"abcd", b"1234"]
        arr["hi"] = [b"efgh", b"5678"]
        view = ArrayView(arr).join_fields(["lo", "hi"], name="label", dtype="S8")
        assert view.view_columns == ["label", "tag"]
        assert view.array.dtype.names == ("label", "tag")
        assert view.array["label"][0] == b"abcdefgh"
        assert view.array["label"][1] == b"12345678"

    def test_join_fields_returns_self(self):
        arr = np.zeros(1, dtype=[("a", "S4"), ("b", "S4")])
        view = ArrayView(arr)
        assert view.join_fields(["a", "b"], name="ab", dtype="S8") is view

    def test_join_fields_rejects_empty(self):
        arr = np.zeros(1, dtype=[("a", "i4"), ("b", "i4")])
        view = ArrayView(arr)
        with pytest.raises(ValueError, match="at least one source field"):
            view.join_fields([], name="x", dtype="i8")

    def test_join_fields_rejects_unknown_field(self):
        arr = np.zeros(1, dtype=[("a", "i4"), ("b", "i4")])
        view = ArrayView(arr)
        with pytest.raises(ValueError, match="Unknown field"):
            view.join_fields(["a", "nope"], name="x", dtype="i8")

    def test_join_fields_rejects_out_of_order(self):
        arr = np.zeros(1, dtype=[("a", "i4"), ("b", "i4")])
        view = ArrayView(arr)
        with pytest.raises(ValueError, match="memory order"):
            view.join_fields(["b", "a"], name="x", dtype="i8")

    def test_join_fields_rejects_non_contiguous(self):
        # Two i4s with an f8 between them — not adjacent.
        arr = np.zeros(1, dtype=[("a", "i4"), ("gap", "f8"), ("b", "i4")])
        view = ArrayView(arr)
        with pytest.raises(ValueError, match="not contiguous"):
            view.join_fields(["a", "b"], name="x", dtype="i8")

    def test_join_fields_rejects_size_mismatch(self):
        arr = np.zeros(1, dtype=[("a", "S4"), ("b", "S4")])
        view = ArrayView(arr)
        with pytest.raises(ValueError, match="itemsize"):
            view.join_fields(["a", "b"], name="x", dtype="S4")

    def test_join_fields_rejects_name_collision(self):
        arr = np.zeros(1, dtype=[("a", "S4"), ("b", "S4"), ("other", "i4")])
        view = ArrayView(arr)
        with pytest.raises(ValueError, match="collides"):
            view.join_fields(["a", "b"], name="other", dtype="S8")

    def test_join_fields_rejects_when_label_references_source(self):
        arr = np.zeros(1, dtype=[("a", "S4"), ("b", "S4")])
        view = ArrayView(arr).set_column_labels({"a": "Alpha"})
        with pytest.raises(ValueError, match="column_labels\\['a'\\]"):
            view.join_fields(["a", "b"], name="ab", dtype="S8")

    def test_join_fields_rejects_when_index_references_source(self):
        arr = np.zeros(1, dtype=[("a", "S4"), ("b", "S4")])
        view = ArrayView(arr).set_index("a")
        with pytest.raises(ValueError, match="index"):
            view.join_fields(["a", "b"], name="ab", dtype="S8")

    def test_join_fields_rejects_when_group_references_source(self):
        arr = np.zeros(1, dtype=[("a", "S4"), ("b", "S4"), ("c", "i4")])
        view = ArrayView(arr).add_column_group("g", ["a", "c"])
        with pytest.raises(ValueError, match="column_groups"):
            view.join_fields(["a", "b"], name="ab", dtype="S8")

    def test_join_fields_requires_array(self):
        view = ArrayView()
        with pytest.raises(ValueError, match="No array set"):
            view.join_fields(["a", "b"], name="x", dtype="S8")


# -- freeze ------------------------------------------------------------------


class TestFreeze:
    def test_freeze_returns_self(self):
        view = ArrayView(_make_basic())
        assert view.freeze() is view

    def test_is_frozen_flag(self):
        view = ArrayView(_make_basic())
        assert view.is_frozen is False
        view.freeze()
        assert view.is_frozen is True

    def test_freeze_blocks_set_index(self):
        view = ArrayView(_make_basic()).freeze()
        with pytest.raises(FrozenViewError, match="set_index"):
            view.set_index("id")

    def test_freeze_blocks_drop_view_columns(self):
        view = ArrayView(_make_basic()).freeze()
        with pytest.raises(FrozenViewError, match="drop_view_columns"):
            view.drop_view_columns(["value"])

    def test_freeze_blocks_set_column_labels(self):
        view = ArrayView(_make_basic()).freeze()
        with pytest.raises(FrozenViewError, match="set_column_labels"):
            view.set_column_labels({"value": "val"})

    def test_freeze_blocks_add_enum_columns(self):
        view = ArrayView(_make_enum()).freeze()
        with pytest.raises(FrozenViewError, match="add_enum_columns"):
            view.add_enum_columns({"tn": ("type", {1: "A"})})

    def test_freeze_blocks_join_fields(self):
        arr = np.zeros(1, dtype=[("a", "S4"), ("b", "S4")])
        view = ArrayView(arr).freeze()
        with pytest.raises(FrozenViewError, match="join_fields"):
            view.join_fields(["a", "b"], name="ab", dtype="S8")

    def test_freeze_allows_slicing(self):
        view = ArrayView(_make_basic(10)).freeze()
        view.slice(head=3)
        assert list(view.compute_slice()) == [0, 1, 2]

    def test_freeze_allows_clear_slice(self):
        view = ArrayView(_make_basic(10)).slice(head=3).freeze()
        view.clear_slice()  # no raise
        assert list(view.compute_slice()) == list(range(10))

    def test_freeze_allows_to_table(self):
        view = ArrayView(_make_basic(3)).freeze()
        text = view.to_table()
        assert "id" in text

    def test_freeze_allows_to_dataframe(self):
        pytest.importorskip("pandas")
        view = ArrayView(_make_basic(3)).freeze()
        df = view.to_dataframe()
        assert len(df) == 3

    def test_copy_is_always_unfrozen(self):
        view = ArrayView(_make_basic()).freeze()
        branch = view.copy()
        assert branch.is_frozen is False
        # Branch is now modifiable.
        branch.drop_view_columns(["value"])
        assert "value" not in branch.view_columns

    def test_frozen_view_error_is_runtimeerror(self):
        view = ArrayView(_make_basic()).freeze()
        try:
            view.set_index("id")
        except RuntimeError:
            pass
        else:
            pytest.fail("FrozenViewError should be catchable as RuntimeError")


# -- Regression: full pipeline smoke test ------------------------------------


class TestFullPipeline:
    def test_end_to_end(self):
        pd = pytest.importorskip("pandas")
        dt = np.dtype(
            [
                ("node_id", "i4"),
                ("f0", "V4"),
                ("element_type", "i4"),
                ("label", "U10"),
                ("label_len", "i4"),
                ("position", "f8", (3,)),
            ]
        )
        rng = np.random.default_rng(42)
        n = 20
        arr = np.zeros(n, dtype=dt)
        arr["node_id"] = np.arange(1, n + 1)
        arr["element_type"] = rng.choice([1, 2, 3], size=n)
        arr["position"] = rng.standard_normal((n, 3))

        view = (
            ArrayView(arr)
            .exclude_patterns([FILLER_COLUMNS, LENGTH_COLUMNS])
            .set_component_names("position", ["x", "y", "z"])
            .add_enum_columns(
                {"element_type_name": ("element_type", {1: "QUAD", 2: "HEX", 3: "TRI"})}
            )
            .set_index("node_id")
            .slice(head=5)
        )

        text = view.to_table()
        assert "position" in text
        assert "element_type_name" in text

        df = view.to_dataframe()
        assert df.index.name == "node_id"
        assert "element_type_name" in df.columns
        assert isinstance(df["element_type_name"].dtype, pd.CategoricalDtype)
        assert "position_x" in df.columns
        assert len(df) == 5

        html = view.to_html()
        assert "<table" in html

        # Pipeline re-rendering: change slice, render again
        view.slice(tail=3)
        df2 = view.to_dataframe()
        assert len(df2) == 3
