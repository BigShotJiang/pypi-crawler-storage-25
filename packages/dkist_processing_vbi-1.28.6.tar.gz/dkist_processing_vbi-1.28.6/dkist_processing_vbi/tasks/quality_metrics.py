"""VBI specific quality metrics."""

from typing import Iterable

from dkist_processing_common.tasks.quality_metrics import QualityL0Metrics

__all__ = ["VbiQualityL0Metrics"]


class VbiQualityL0Metrics(QualityL0Metrics):
    """
    Task class for collecting VBI L0 quality metrics.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs

    """

    @property
    def modstate_list(self) -> Iterable[int] | None:
        """Define modstates over which to compute L0 metrics. VBI has none because it is not polarimetric."""
        # Yes, this is just the default, but by explicitly calling it out here we're resistant to any upstream change.
        return None
