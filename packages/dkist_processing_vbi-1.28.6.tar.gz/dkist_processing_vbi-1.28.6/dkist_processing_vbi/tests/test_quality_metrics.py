from pathlib import Path

import numpy as np
import pytest
from dkist_data_simulator.spec122 import Spec122Dataset
from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.codecs.basemodel import basemodel_decoder
from dkist_processing_common.codecs.fits import fits_array_encoder
from dkist_processing_common.models.quality import QualityMetric
from dkist_processing_common.models.tags import Tag
from dkist_processing_common.models.task_name import TaskName

from dkist_processing_vbi.models.tags import VbiTag
from dkist_processing_vbi.tasks.quality_metrics import VbiQualityL0Metrics


class BaseSpec214Dataset(Spec122Dataset):
    def __init__(self, instrument="vbi"):
        self.array_shape = (1, 10, 10)
        super().__init__(
            dataset_shape=(2, 10, 10),
            array_shape=self.array_shape,
            time_delta=1,
            instrument=instrument,
            file_schema="level0_spec214",
        )


@pytest.fixture()
def l0_quality_task_types() -> list[str]:
    # The task types we want to build l0 metrics for
    return [TaskName.lamp_gain.value, TaskName.dark.value]


@pytest.fixture()
def dataset_task_types(l0_quality_task_types: list[str]) -> list[str]:
    # The task types that exist in the dataset, i.e. a larger set than we want to build metrics for.
    return l0_quality_task_types + [TaskName.solar_gain.value, TaskName.observe.value]


@pytest.fixture
def vbi_l0_quality_task(
    recipe_run_id: int, tmp_path: Path, l0_quality_task_types: list[str]
) -> VbiQualityL0Metrics:

    class TestVbiQualityL0Metrics(VbiQualityL0Metrics):
        """Only process l0_quality_task_types"""

        @property
        def quality_task_types(self) -> list[str]:
            return l0_quality_task_types

    with TestVbiQualityL0Metrics(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        task.scratch = WorkflowFileSystem(scratch_base_path=tmp_path, recipe_run_id=recipe_run_id)

        yield task
        task._purge()


@pytest.fixture
def write_l0_task_frames_to_task(dataset_task_types):
    def writer(task):
        for task_type in dataset_task_types:
            ds = BaseSpec214Dataset()
            for modstate, frame in enumerate(ds, start=1):
                header = frame.header()
                data = np.ones(ds.array_shape)
                tags = [VbiTag.input(), VbiTag.frame(), VbiTag.task(task_type)]
                task.write(
                    data=data,
                    header=header,
                    tags=tags,
                    encoder=fits_array_encoder,
                )

    return writer


def test_l0_quality_task(
    vbi_l0_quality_task: VbiQualityL0Metrics,
    write_l0_task_frames_to_task,
    l0_quality_task_types: list[str],
):
    """
    Given: A `VbiQualityL0Metrics` task and some INPUT frames tagged with their task type and modstate
    When: Running the task
    Then: The expected L0 quality metric files exist
    """
    # NOTE: We rely on the unit tests in `*-common` to verify the correct format/data of the metric files
    # Given
    task = vbi_l0_quality_task
    write_l0_task_frames_to_task(task)

    # When
    task()

    # Then
    tags = [Tag.quality("GENERIC")]
    metrics: list[QualityMetric] = list(
        task.read(tags=tags, decoder=basemodel_decoder, model=QualityMetric)
    )
    dataset_metric_codes = ["DATASET_AVERAGE", "DATASET_RMS"]
    frame_metric_codes = ["FRAME_AVERAGE", "FRAME_RMS"]
    dataset_metrics = [metric for metric in metrics if metric.metric_code in dataset_metric_codes]
    frame_metrics = [metric for metric in metrics if metric.metric_code in frame_metric_codes]
    # 2 metrics, no segregation by task
    assert len(dataset_metrics) == 2
    for metric_code in dataset_metric_codes:
        # make sure one metric code of each type
        assert len([metric for metric in dataset_metrics if metric.metric_code == metric_code]) == 1
    # 2 metrics, 2 task types (LAMP_GAIN and DARK)
    assert len(frame_metrics) == 2 * 2
    for metric_code in frame_metric_codes:
        # make sure two metric codes of each type
        assert len([metric for metric in frame_metrics if metric.metric_code == metric_code]) == 2
    for facet in l0_quality_task_types:
        # make sure two facets of each type
        assert len([metric for metric in frame_metrics if metric.facet == facet]) == 2
