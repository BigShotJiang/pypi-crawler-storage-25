from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from qblog import prepare_articles


class PrepareArticlesPruneTests(unittest.TestCase):
    def test_missing_markdown_source_prunes_generated_qmd_and_images(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            (root / "_quarto.yml").write_text(
                "project:\n  type: website\n",
                encoding="utf-8",
            )
            source_dir = root / "public" / "md"
            image_dir = source_dir / "img"
            qmd_dir = root / "public" / "qmd"
            private_md_dir = root / "private" / "md"
            private_qmd_dir = root / "private" / "qmd"
            image_dir.mkdir(parents=True)
            qmd_dir.mkdir(parents=True)
            private_md_dir.mkdir(parents=True)
            private_qmd_dir.mkdir(parents=True)

            (image_dir / "plot.png").write_bytes(b"png")
            source = source_dir / "demo.md"
            source.write_text("# Demo\n\n![](img/plot.png)\n", encoding="utf-8")

            prepare_articles.main(["--root", str(root)])
            self.assertTrue((root / "public" / "qmd" / "demo.qmd").exists())
            self.assertTrue((root / "public" / "fig" / "plot.png").exists())

            source.unlink()

            prepare_articles.main(["--root", str(root)])
            self.assertFalse((root / "public" / "qmd" / "demo.qmd").exists())
            self.assertFalse((root / "public" / "fig" / "plot.png").exists())

    def test_missing_markdown_source_keeps_images_used_by_other_posts(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            (root / "_quarto.yml").write_text(
                "project:\n  type: website\n",
                encoding="utf-8",
            )
            source_dir = root / "public" / "md"
            qmd_dir = root / "public" / "qmd"
            private_md_dir = root / "private" / "md"
            private_qmd_dir = root / "private" / "qmd"
            source_dir.mkdir(parents=True)
            qmd_dir.mkdir(parents=True)
            private_md_dir.mkdir(parents=True)
            private_qmd_dir.mkdir(parents=True)

            fig_dir = root / "public" / "fig"
            fig_dir.mkdir(parents=True)
            (fig_dir / "shared.png").write_bytes(b"png")
            first_source = source_dir / "first.md"
            second_source = source_dir / "second.md"
            first_source.write_text("# First\n\n![](../fig/shared.png)\n", encoding="utf-8")
            second_source.write_text("# Second\n\n![](../fig/shared.png)\n", encoding="utf-8")

            prepare_articles.main(["--root", str(root)])
            first_source.unlink()

            prepare_articles.main(["--root", str(root)])
            self.assertFalse((root / "public" / "qmd" / "first.qmd").exists())
            self.assertTrue((root / "public" / "qmd" / "second.qmd").exists())
            self.assertTrue((root / "public" / "fig" / "shared.png").exists())

    def test_image_syntax_inside_code_fence_is_not_rewritten(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            (root / "_quarto.yml").write_text(
                "project:\n  type: website\n",
                encoding="utf-8",
            )
            source_dir = root / "public" / "md"
            qmd_dir = root / "public" / "qmd"
            private_md_dir = root / "private" / "md"
            private_qmd_dir = root / "private" / "qmd"
            source_dir.mkdir(parents=True)
            qmd_dir.mkdir(parents=True)
            private_md_dir.mkdir(parents=True)
            private_qmd_dir.mkdir(parents=True)

            source = source_dir / "demo.md"
            source.write_text(
                "# Demo\n\n```markdown\n![](figures/example.png)\n```\n",
                encoding="utf-8",
            )

            prepare_articles.main(["--root", str(root)])
            qmd = (root / "public" / "qmd" / "demo.qmd").read_text(
                encoding="utf-8"
            )
            self.assertIn("![](figures/example.png)", qmd)


if __name__ == "__main__":
    unittest.main()
