#!/usr/bin/env python3
"""Sync Markdown sources into public/private Quarto output folders.

The default layout is:

  public/md/*.md   -> public/qmd/*.qmd + public/fig/
  private/md/*.md  -> private/qmd/*.qmd + private/fig/

Local image links are copied into the matching collection-level fig folder.
Source Markdown and generated qmd files both link to that folder with relative
../fig/ paths. Each qmd folder keeps its own manifest so stale copied images and
generated files can be pruned when a source Markdown file is removed.
"""

from __future__ import annotations

import argparse
from datetime import datetime
import filecmp
import json
import os
import random
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import unquote, urlparse


MANIFEST_NAME = ".qblog-prepare.json"
GITIGNORE_BEGIN = "# BEGIN qblog-prepare generated files"
GITIGNORE_END = "# END qblog-prepare generated files"

IMAGE_LINK_RE = re.compile(r"(!\[[^\]]*\]\()([^\n)]*)(\))")
H1_RE = re.compile(r"^#\s+(.+?)\s*$", re.MULTILINE)
FRONT_MATTER_RE = re.compile(r"^---\r?\n(.*?)\r?\n---\r?\n?", re.DOTALL)
CATEGORY_LINE_RE = re.compile(
    r"^(?P<key>tag|tags|cat|category|categories)\s*:\s*(?P<value>.+?)\s*$",
    re.IGNORECASE,
)
FENCE_RE = re.compile(r"^\s*(```|~~~)")
CATEGORY_SCAN_FIRST_LINE = 2
CATEGORY_SCAN_LAST_LINE = 5
IMAGE_EXTENSIONS = {
    ".apng",
    ".avif",
    ".gif",
    ".jpeg",
    ".jpg",
    ".png",
    ".svg",
    ".webp",
}


@dataclass(frozen=True)
class Collection:
    name: str
    md_dir: Path
    qmd_dir: Path
    ignore_generated: bool


@dataclass(frozen=True)
class SourcePost:
    collection: Collection
    source: Path
    slug: str
    qmd_path: Path


@dataclass(frozen=True)
class RewriteResult:
    markdown: str
    source_markdown: str
    missing_images: list[Path]
    managed_images: set[Path]


def find_project_root(start: Path | None = None) -> Path:
    if env_root := os.environ.get("QBLOG_ROOT"):
        return Path(env_root).expanduser().resolve()

    current = (start or Path.cwd()).resolve()
    for candidate in (current, *current.parents):
        if (candidate / "_quarto.yml").exists():
            return candidate
    return Path(__file__).resolve().parents[1]


def slugify(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip().lower()).strip("-")
    return slug or "article"


def title_from_slug(slug: str) -> str:
    return re.sub(r"[-_]+", " ", slug).strip().title()


def as_repo_path(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def path_from_repo(root: Path, value: str) -> Path:
    return (root / value).resolve()


def is_under(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
    except ValueError:
        return False
    return True


def require_under_root(path: Path, root: Path, label: str) -> None:
    if not is_under(path, root):
        raise ValueError(f"{label} must be inside the project root: {path}")


def modified_datetime(timestamp: float) -> str:
    return (
        datetime.fromtimestamp(timestamp)
        .astimezone()
        .replace(microsecond=0)
        .isoformat(timespec="seconds")
    )


def category_values(raw_value: str) -> list[str]:
    value = raw_value.strip()
    if value.startswith("[") and value.endswith("]"):
        value = value[1:-1].strip()

    values = []
    seen = set()
    for item in value.split(","):
        category = item.strip().strip("\"'")
        if not category or category in seen:
            continue
        seen.add(category)
        values.append(category)
    return values


def dedupe(values: list[str]) -> list[str]:
    deduped = []
    seen = set()
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped


def extract_category_line(markdown: str) -> tuple[str, list[str]]:
    lines = markdown.splitlines(keepends=True)
    updated_lines = []
    in_fence = False
    categories = []

    for line_number, line in enumerate(lines, start=1):
        if FENCE_RE.match(line):
            in_fence = not in_fence
            updated_lines.append(line)
            continue

        if (
            CATEGORY_SCAN_FIRST_LINE <= line_number <= CATEGORY_SCAN_LAST_LINE
            and not in_fence
            and (match := CATEGORY_LINE_RE.match(line.strip()))
        ):
            categories.extend(category_values(match.group("value")))
            updated_lines.extend(lines[line_number:])
            break

        updated_lines.append(line)

    updated = "".join(updated_lines)
    updated = re.sub(r"\n{3,}", "\n\n", updated)
    return updated, dedupe(categories)


def update_front_matter(front_matter: str, date: str, categories: list[str]) -> str:
    lines = []
    for line in front_matter.splitlines():
        if re.match(r"^date\s*:", line, flags=re.IGNORECASE):
            continue
        if categories and CATEGORY_LINE_RE.match(line.strip()):
            continue
        lines.append(line)

    if categories:
        lines.append(f"categories: {json.dumps(categories)}")
    lines.append(f"date: {json.dumps(date)}")
    return "\n".join(line for line in lines if line.strip())


def ensure_front_matter(markdown: str, slug: str, date: str) -> str:
    markdown, categories = extract_category_line(markdown)

    if match := FRONT_MATTER_RE.match(markdown):
        updated = update_front_matter(match.group(1), date, categories)
        body = markdown[match.end():]
        return f"---\n{updated}\n---\n\n{body.lstrip()}"

    match = H1_RE.search(markdown)
    if match:
        title = match.group(1).strip()
        markdown = markdown[: match.start()] + markdown[match.end() :].lstrip("\r\n")
    else:
        title = title_from_slug(slug)

    category_line = f"categories: {json.dumps(categories)}\n" if categories else ""
    return f"---\ntitle: {json.dumps(title)}\n{category_line}date: {json.dumps(date)}\n---\n\n{markdown.lstrip()}"


def is_external_or_anchor(link: str) -> bool:
    parsed = urlparse(link)
    return bool(
        (parsed.scheme and parsed.scheme != "file")
        or parsed.netloc
        or link.startswith("#")
    )


def linked_image_paths(
    raw_link: str,
    source_dir: Path,
    output_dir: Path,
    fig_dir: Path,
) -> tuple[list[Path], str] | None:
    link = raw_link.strip()
    if link.startswith("<") and link.endswith(">"):
        link = link[1:-1].strip()
    if is_external_or_anchor(link):
        return None

    parsed = urlparse(link)
    tail = ""
    if parsed.query:
        tail += f"?{parsed.query}"
    if parsed.fragment:
        tail += f"#{parsed.fragment}"

    if parsed.scheme == "file":
        link = parsed.path
    elif parsed.path:
        link = parsed.path

    image_path = Path(unquote(link)).expanduser()
    if image_path.is_absolute():
        candidates = [image_path]
    else:
        candidates = [
            source_dir / image_path,
            output_dir / image_path,
            fig_dir / image_path.name,
            source_dir.parent / image_path,
            output_dir.parent / image_path,
        ]

    resolved = []
    seen = set()
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in seen:
            continue
        seen.add(candidate)
        resolved.append(candidate)
    return resolved, tail


def copied_image_name(
    source: Path,
    fig_dir: Path,
    previous_images: set[Path],
    current_images: set[Path],
) -> str:
    candidate = source.name
    candidate_path = fig_dir / candidate
    if (
        not candidate_path.exists()
        or candidate_path.resolve() in previous_images - current_images
        or filecmp.cmp(source, candidate_path, shallow=False)
    ):
        return candidate

    stem = source.stem
    suffix = source.suffix
    counter = 2
    while True:
        candidate = f"{stem}-{counter}{suffix}"
        candidate_path = fig_dir / candidate
        if (
            not candidate_path.exists()
            or candidate_path.resolve() in previous_images - current_images
            or filecmp.cmp(source, candidate_path, shallow=False)
        ):
            return candidate
        counter += 1


def relative_path(path: Path, start: Path) -> str:
    return Path(os.path.relpath(path.resolve(), start.resolve())).as_posix()


def fenced_code_ranges(markdown: str) -> list[tuple[int, int]]:
    ranges: list[tuple[int, int]] = []
    in_fence = False
    fence_start = 0
    position = 0

    for line in markdown.splitlines(keepends=True):
        if FENCE_RE.match(line):
            if in_fence:
                ranges.append((fence_start, position + len(line)))
                in_fence = False
            else:
                fence_start = position
                in_fence = True
        position += len(line)

    if in_fence:
        ranges.append((fence_start, len(markdown)))

    return ranges


def rewrite_images(
    markdown: str,
    source_dir: Path,
    output_dir: Path,
    fig_dir: Path,
    previous_images: set[Path],
) -> RewriteResult:
    missing_images: list[Path] = []
    managed_images: set[Path] = set()
    qmd_chunks = []
    source_chunks = []
    last_end = 0
    fenced_ranges = fenced_code_ranges(markdown)
    fenced_range_index = 0

    def replacements(match: re.Match[str]) -> tuple[str, str]:
        _prefix, raw_link, suffix = match.groups()
        image_ref = linked_image_paths(raw_link, source_dir, output_dir, fig_dir)
        if image_ref is None:
            return match.group(0), match.group(0)

        image_paths, tail = image_ref
        if not image_paths or image_paths[0].suffix.lower() not in IMAGE_EXTENSIONS:
            return match.group(0), match.group(0)

        image_path = next((path for path in image_paths if path.exists()), image_paths[0])
        if not image_path.exists():
            missing_images.append(image_path)
            return match.group(0), match.group(0)

        fig_dir.mkdir(parents=True, exist_ok=True)
        image_name = copied_image_name(image_path, fig_dir, previous_images, managed_images)
        target_path = (fig_dir / image_name).resolve()
        managed_images.add(target_path)
        if image_path != target_path:
            shutil.copy2(image_path, target_path)

        qmd_link = relative_path(target_path, output_dir)
        source_link = relative_path(target_path, source_dir)
        return f"![]({qmd_link}{tail}{suffix}", f"![]({source_link}{tail}{suffix}"

    for match in IMAGE_LINK_RE.finditer(markdown):
        qmd_chunks.append(markdown[last_end : match.start()])
        source_chunks.append(markdown[last_end : match.start()])
        while (
            fenced_range_index < len(fenced_ranges)
            and fenced_ranges[fenced_range_index][1] <= match.start()
        ):
            fenced_range_index += 1

        if (
            fenced_range_index < len(fenced_ranges)
            and fenced_ranges[fenced_range_index][0]
            <= match.start()
            < fenced_ranges[fenced_range_index][1]
        ):
            qmd_chunks.append(match.group(0))
            source_chunks.append(match.group(0))
            last_end = match.end()
            continue

        qmd_replacement, source_replacement = replacements(match)
        qmd_chunks.append(qmd_replacement)
        source_chunks.append(source_replacement)
        last_end = match.end()

    qmd_chunks.append(markdown[last_end:])
    source_chunks.append(markdown[last_end:])
    return RewriteResult(
        "".join(qmd_chunks),
        "".join(source_chunks),
        missing_images,
        managed_images,
    )


def manifest_entries(manifest: dict) -> dict:
    manifest.setdefault("entries", {})
    return manifest["entries"]


def load_manifest(qmd_dir: Path) -> dict:
    manifest_path = qmd_dir / MANIFEST_NAME
    if not manifest_path.exists():
        return {"version": 1, "entries": {}}

    with manifest_path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    manifest.setdefault("version", 1)
    manifest_entries(manifest)
    return manifest


def save_manifest(qmd_dir: Path, manifest: dict) -> None:
    manifest_path = qmd_dir / MANIFEST_NAME
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def load_banner_manifest(manifest_path: Path) -> dict:
    if not manifest_path.exists():
        return {"files": [], "articles": {}}

    with manifest_path.open(encoding="utf-8") as handle:
        manifest = json.load(handle)
    manifest.setdefault("files", [])
    manifest.setdefault("articles", {})
    return manifest


def save_banner_manifest(manifest_path: Path, manifest: dict) -> None:
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def qmd_files_for_collection(collection: Collection) -> list[Path]:
    if not collection.qmd_dir.exists():
        return []

    qmd_files = []
    for qmd_path in collection.qmd_dir.rglob("*.qmd"):
        if not qmd_path.is_file():
            continue
        relative_parts = qmd_path.relative_to(collection.qmd_dir).parts
        if any(part.startswith(".") for part in relative_parts):
            continue
        qmd_files.append(qmd_path)
    return sorted(qmd_files)


def qmd_has_date(markdown: str) -> bool:
    match = FRONT_MATTER_RE.match(markdown)
    if not match:
        return False

    return any(
        re.match(r"^date\s*:", line, flags=re.IGNORECASE)
        for line in match.group(1).splitlines()
    )


def ensure_qmd_date(qmd_path: Path) -> bool:
    markdown = qmd_path.read_text(encoding="utf-8")
    if qmd_has_date(markdown):
        return False

    qmd_stat = qmd_path.stat()
    date_line = f"date: {json.dumps(modified_datetime(qmd_stat.st_mtime))}"

    if match := FRONT_MATTER_RE.match(markdown):
        front_matter = match.group(1).rstrip()
        updated_front_matter = "\n".join(
            part for part in [front_matter, date_line] if part
        )
        body = markdown[match.end():]
        separator = "" if body.startswith("\n") else "\n"
        updated = f"---\n{updated_front_matter}\n---\n{separator}{body}"
    else:
        updated = f"---\n{date_line}\n---\n\n{markdown.lstrip()}"

    qmd_path.write_text(updated, encoding="utf-8")
    os.utime(qmd_path, ns=(qmd_stat.st_atime_ns, qmd_stat.st_mtime_ns))
    return True


def ensure_collection_qmd_dates(root: Path, collections: list[Collection]) -> None:
    for collection in collections:
        for qmd_path in qmd_files_for_collection(collection):
            if ensure_qmd_date(qmd_path):
                print(f"Added date to {qmd_path.relative_to(root)}")


def banner_key_for_qmd(qmd_path: Path, root: Path) -> str:
    page_path = (
        qmd_path.parent if qmd_path.name == "index.qmd" else qmd_path.with_suffix("")
    )
    return f"{as_repo_path(page_path, root)}/"


def assign_collection_banners(
    root: Path,
    collection: Collection,
    banner_files: list[str],
) -> None:
    manifest_path = collection.qmd_dir.parent / "manifest.json"
    banner_manifest = load_banner_manifest(manifest_path)
    articles = banner_manifest.setdefault("articles", {})
    old_banner_files = banner_manifest.get("files")
    banner_manifest["files"] = banner_files

    expected_keys = set()
    changed = False
    for qmd_path in qmd_files_for_collection(collection):
        key = banner_key_for_qmd(qmd_path, root)
        expected_keys.add(key)
        if articles.get(key) in banner_files:
            continue

        articles[key] = random.choice(banner_files)
        changed = True
        print(f"Assigned banner {articles[key]} -> {key}")

    for key in list(articles):
        if key.startswith(f"{collection.qmd_dir.relative_to(root).as_posix()}/") and key not in expected_keys:
            del articles[key]
            changed = True

    if changed or old_banner_files != banner_files:
        save_banner_manifest(manifest_path, banner_manifest)


def assign_missing_banners(root: Path, collections: list[Collection]) -> None:
    banners_dir = root / "assets" / "banners"
    if not banners_dir.exists():
        return

    banner_files = sorted(
        path.name
        for path in banners_dir.iterdir()
        if path.is_file() and path.suffix.lower() == ".png"
    )
    if not banner_files:
        return

    for collection in collections:
        assign_collection_banners(
            root,
            collection,
            banner_files,
        )


def previous_managed_images(entry: dict | None, root: Path) -> set[Path]:
    if not entry:
        return set()
    return {
        path_from_repo(root, image_path)
        for image_path in entry.get("managed_images", [])
    }


def source_slug(source: Path, md_dir: Path) -> str:
    source = source.resolve()
    md_dir = md_dir.resolve()

    if is_under(source, md_dir):
        return slugify(source.parent.name if source.name == "index.md" else source.stem)

    return slugify(source.stem)


def source_for_path(source: Path, collection: Collection) -> SourcePost:
    source = source.resolve()
    slug = source_slug(source, collection.md_dir)
    return SourcePost(
        collection=collection,
        source=source,
        slug=slug,
        qmd_path=collection.qmd_dir / f"{slug}.qmd",
    )


def collection_for_source(source: Path, collections: list[Collection]) -> Collection | None:
    for collection in collections:
        if is_under(source, collection.md_dir):
            return collection
    return None


def discover_sources(
    root: Path,
    collections: list[Collection],
    explicit_sources: list[str],
    manifests: dict[str, dict],
    cwd: Path,
) -> list[SourcePost]:
    candidates: dict[Path, SourcePost] = {}

    def add_candidate(source_post: SourcePost) -> None:
        qmd_key = source_post.qmd_path.resolve()
        existing = candidates.get(qmd_key)
        if existing and existing.source.resolve() != source_post.source.resolve():
            raise ValueError(
                "Multiple Markdown sources resolve to the same qmd path: "
                f"{as_repo_path(existing.source, root)} and "
                f"{as_repo_path(source_post.source, root)} -> "
                f"{as_repo_path(source_post.qmd_path, root)}"
            )
        candidates[qmd_key] = source_post

    for source_arg in explicit_sources:
        source = Path(source_arg).expanduser()
        if not source.is_absolute():
            source = cwd / source
        source = source.resolve()
        require_under_root(source, root, "Markdown source")

        collection = collection_for_source(source, collections)
        if collection is None:
            dirs = ", ".join(as_repo_path(collection.md_dir, root) for collection in collections)
            raise ValueError(f"Markdown source must be under one of: {dirs}")
        add_candidate(source_for_path(source, collection))

    if explicit_sources:
        return sorted(candidates.values(), key=lambda item: as_repo_path(item.qmd_path, root))

    for collection in collections:
        entries = manifest_entries(manifests[collection.name])
        for entry in entries.values():
            source = path_from_repo(root, entry["source"])
            if source.exists() and is_under(source, collection.md_dir):
                add_candidate(source_for_path(source, collection))

        if not collection.md_dir.exists():
            continue

        for source in sorted(collection.md_dir.glob("*.md")):
            if source.name.lower() == "readme.md":
                continue
            add_candidate(source_for_path(source, collection))

        for source in sorted(collection.md_dir.glob("*/index.md")):
            add_candidate(source_for_path(source, collection))

    return sorted(candidates.values(), key=lambda item: as_repo_path(item.qmd_path, root))


def managed_images_for_other_entries(manifest: dict, root: Path, slug: str) -> set[Path]:
    images: set[Path] = set()
    for other_slug, entry in manifest_entries(manifest).items():
        if other_slug == slug:
            continue
        images.update(previous_managed_images(entry, root))
    return images


def remove_stale_images(
    previous_images: set[Path],
    keep_images: set[Path],
    other_images: set[Path],
    root: Path,
) -> None:
    for image_path in sorted(previous_images - keep_images - other_images):
        if image_path.exists():
            image_path.unlink()
            print(f"Removed stale image {image_path.relative_to(root)}")


def remove_generated_entry(
    root: Path,
    entry: dict,
    keep_qmd: Path | None = None,
    keep_images: set[Path] | None = None,
    other_images: set[Path] | None = None,
) -> None:
    keep_images = keep_images or set()
    other_images = other_images or set()

    if generated_qmd := entry.get("generated_qmd"):
        qmd_path = path_from_repo(root, generated_qmd)
        if qmd_path.exists() and (keep_qmd is None or qmd_path.resolve() != keep_qmd.resolve()):
            qmd_path.unlink()
            print(f"Removed stale generated post {qmd_path.relative_to(root)}")

    remove_stale_images(previous_managed_images(entry, root), keep_images, other_images, root)


def prune_missing_sources(root: Path, collection: Collection, manifest: dict, enabled: bool) -> None:
    if not enabled:
        return

    entries = manifest_entries(manifest)
    for slug, entry in list(entries.items()):
        source = path_from_repo(root, entry["source"])
        if source.exists():
            continue

        other_images = managed_images_for_other_entries(manifest, root, slug)
        remove_generated_entry(root, entry, other_images=other_images)
        del entries[slug]


def update_qmd_gitignore(qmd_dir: Path, root: Path, manifest: dict) -> None:
    gitignore_path = qmd_dir / ".gitignore"
    existing = gitignore_path.read_text(encoding="utf-8") if gitignore_path.exists() else ""
    before, _, rest = existing.partition(GITIGNORE_BEGIN)
    _, _, after = rest.partition(GITIGNORE_END)

    entries = []
    for entry in manifest_entries(manifest).values():
        if generated_qmd := entry.get("generated_qmd"):
            qmd_path = path_from_repo(root, generated_qmd)
            if qmd_path.parent.resolve() == qmd_dir.resolve():
                entries.append(f"/{qmd_path.name}")
        for image_path in entry.get("managed_images", []):
            image = path_from_repo(root, image_path)
            if is_under(image, qmd_dir):
                entries.append(f"/{image.relative_to(qmd_dir).as_posix()}")

    block = "\n".join([GITIGNORE_BEGIN, *sorted(set(entries)), GITIGNORE_END])
    parts = [before.rstrip(), block, after.lstrip()]
    updated = "\n".join(part for part in parts if part).rstrip() + "\n"
    gitignore_path.write_text(updated, encoding="utf-8")


def remove_qmd_gitignore_block(qmd_dir: Path) -> None:
    gitignore_path = qmd_dir / ".gitignore"
    if not gitignore_path.exists():
        return

    existing = gitignore_path.read_text(encoding="utf-8")
    before, marker, rest = existing.partition(GITIGNORE_BEGIN)
    if not marker:
        return

    _, _, after = rest.partition(GITIGNORE_END)
    updated = "\n".join(
        part for part in [before.rstrip(), after.lstrip()] if part
    ).rstrip()
    if updated:
        gitignore_path.write_text(f"{updated}\n", encoding="utf-8")
    else:
        gitignore_path.unlink()


def sync_post(source_post: SourcePost, root: Path, manifest: dict) -> None:
    source = source_post.source
    if not source.exists():
        raise FileNotFoundError(f"Markdown source not found: {source}")
    if source.suffix.lower() != ".md":
        raise ValueError(f"Expected a Markdown source file: {source}")

    qmd_path = source_post.qmd_path
    qmd_path.parent.mkdir(parents=True, exist_ok=True)

    entries = manifest_entries(manifest)
    previous_entry = entries.get(source_post.slug)
    previous_images = previous_managed_images(previous_entry, root)

    source_stat = source.stat()
    source_date = modified_datetime(source_stat.st_mtime)
    markdown = source.read_text(encoding="utf-8")
    rewritten = rewrite_images(
        markdown,
        source.parent,
        qmd_path.parent,
        source_post.collection.md_dir.parent / "fig",
        previous_images,
    )
    if rewritten.missing_images:
        for image_path in rewritten.missing_images:
            print(f"Missing local image referenced by {source.relative_to(root)}: {image_path}")
        raise SystemExit(1)

    if rewritten.source_markdown != markdown:
        source.write_text(rewritten.source_markdown, encoding="utf-8")
        os.utime(source, ns=(source_stat.st_atime_ns, source_stat.st_mtime_ns))
        print(f"Updated image paths in {source.relative_to(root)}")

    qmd = ensure_front_matter(
        rewritten.markdown,
        source_post.slug,
        source_date,
    )
    qmd_path.write_text(qmd, encoding="utf-8")

    if previous_entry:
        other_images = managed_images_for_other_entries(manifest, root, source_post.slug)
        remove_generated_entry(
            root,
            previous_entry,
            keep_qmd=qmd_path,
            keep_images=rewritten.managed_images,
            other_images=other_images,
        )

    entries[source_post.slug] = {
        "source": as_repo_path(source, root),
        "generated_qmd": as_repo_path(qmd_path, root),
        "managed_images": [
            as_repo_path(image_path, root)
            for image_path in sorted(rewritten.managed_images)
        ],
    }
    print(f"Prepared {source.relative_to(root)} -> {qmd_path.relative_to(root)}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qblog-prepare",
        description="Sync public/private Markdown sources into qmd output folders.",
    )
    parser.add_argument(
        "sources",
        nargs="*",
        help="Optional Markdown files under public/md or private/md to import or resync.",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=None,
        help="Project root. Defaults to the nearest parent containing _quarto.yml.",
    )
    parser.add_argument(
        "--public-md-dir",
        default=os.environ.get("PUBLIC_MD_DIR", "public/md"),
        help="Public Markdown source directory. Default: public/md.",
    )
    parser.add_argument(
        "--public-qmd-dir",
        default=os.environ.get("PUBLIC_QMD_DIR", "public/qmd"),
        help="Public Quarto output directory. Default: public/qmd.",
    )
    parser.add_argument(
        "--private-md-dir",
        default=os.environ.get("PRIVATE_MD_DIR", "private/md"),
        help="Private Markdown source directory. Default: private/md.",
    )
    parser.add_argument(
        "--private-qmd-dir",
        default=os.environ.get("PRIVATE_QMD_DIR", "private/qmd"),
        help="Private Quarto output directory. Default: private/qmd.",
    )
    parser.add_argument(
        "--no-prune",
        action="store_true",
        help="Do not remove generated files whose source Markdown file is missing.",
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    root = (args.root.expanduser().resolve() if args.root else find_project_root())
    cwd = Path.cwd().resolve()
    collections = [
        Collection(
            name="public",
            md_dir=(root / args.public_md_dir).resolve(),
            qmd_dir=(root / args.public_qmd_dir).resolve(),
            ignore_generated=True,
        ),
        Collection(
            name="private",
            md_dir=(root / args.private_md_dir).resolve(),
            qmd_dir=(root / args.private_qmd_dir).resolve(),
            ignore_generated=False,
        ),
    ]

    manifests: dict[str, dict] = {}
    for collection in collections:
        collection.md_dir.mkdir(parents=True, exist_ok=True)
        collection.qmd_dir.mkdir(parents=True, exist_ok=True)
        manifests[collection.name] = load_manifest(collection.qmd_dir)
        prune_missing_sources(
            root,
            collection,
            manifests[collection.name],
            enabled=not args.no_prune,
        )

    sources = discover_sources(root, collections, args.sources, manifests, cwd)
    if not sources:
        print("No Markdown sources found. Add public/md/<name>.md or private/md/<name>.md.")

    for source_post in sources:
        sync_post(source_post, root, manifests[source_post.collection.name])

    ensure_collection_qmd_dates(root, collections)
    assign_missing_banners(root, collections)

    for collection in collections:
        manifest = manifests[collection.name]
        save_manifest(collection.qmd_dir, manifest)
        if collection.ignore_generated:
            update_qmd_gitignore(collection.qmd_dir, root, manifest)
        else:
            remove_qmd_gitignore_block(collection.qmd_dir)


if __name__ == "__main__":
    main()
