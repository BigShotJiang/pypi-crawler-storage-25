#!/usr/bin/env python3
"""Clone qblog, customize site metadata, and enable local git hooks."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path


DEFAULT_REPO_URL = "https://github.com/sky1ove/qblog.git"
DEFAULT_AUTHOR = "Lily"
DEFAULT_GITHUB_USER = "sky1ove"
DEFAULT_SITE_BASE_URL = f"https://{DEFAULT_GITHUB_USER}.github.io"


def run(command: list[str], cwd: Path | None = None) -> None:
    subprocess.run(command, cwd=cwd, check=True)


def maybe_git_root(start: Path) -> Path | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(start), "rev-parse", "--show-toplevel"],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError:
        return None
    return Path(result.stdout.strip()).resolve()


def git_root(start: Path) -> Path:
    root = maybe_git_root(start)
    if root is None:
        raise SystemExit(f"Not a git repository: {start}")
    return root


def clone_repo(repo_url: str, target: Path, branch: str | None) -> tuple[Path, bool]:
    if target.exists():
        existing_root = maybe_git_root(target)
        if existing_root is not None:
            print(f"Using existing git repo: {existing_root}")
            return existing_root, False
        if any(target.iterdir()):
            raise SystemExit(f"Target exists and is not empty: {target}")

    command = ["git", "clone"]
    if branch:
        command.extend(["--branch", branch])
    command.extend([repo_url, str(target)])
    run(command)
    return git_root(target), True


def reinitialize_git_repo(repo_dir: Path) -> None:
    git_dir = repo_dir / ".git"
    if git_dir.exists():
        shutil.rmtree(git_dir)
    run(["git", "init"], cwd=repo_dir)
    run(["git", "branch", "-M", "main"], cwd=repo_dir)
    print("Initialized a fresh git repository.")


def install_hooks(repo_dir: Path) -> Path:
    repo_dir = git_root(repo_dir)
    hook = repo_dir / ".githooks" / "pre-push"
    if not hook.exists():
        raise SystemExit(f"Missing hook file: {hook}")

    hook.chmod(hook.stat().st_mode | 0o111)
    run(["git", "config", "core.hooksPath", ".githooks"], cwd=repo_dir)
    print(f"Installed git hooks for {repo_dir}")
    return repo_dir


def run_prepare(repo_dir: Path) -> None:
    if shutil.which("uv"):
        run(["uv", "run", "qblog-prepare"], cwd=repo_dir)
    elif shutil.which("qblog-prepare"):
        run(["qblog-prepare"], cwd=repo_dir)
    else:
        run(["python3", "-m", "qblog.prepare_articles"], cwd=repo_dir)


def default_site_url(repo_name: str) -> str:
    if repo_name == f"{DEFAULT_GITHUB_USER}.github.io":
        return DEFAULT_SITE_BASE_URL
    return f"{DEFAULT_SITE_BASE_URL}/{repo_name}"


def yaml_scalar(value: str) -> str:
    return json.dumps(value)


def rewrite_yaml_values(path: Path, replacements: dict[str, str]) -> None:
    if not replacements:
        return
    if not path.exists():
        raise SystemExit(f"Missing YAML file: {path}")

    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    found: set[str] = set()
    section: str | None = None

    for index, line in enumerate(lines):
        stripped = line.lstrip(" ")
        if not stripped.strip() or stripped.startswith("#"):
            continue

        indent = len(line) - len(stripped)
        key_part = stripped.split(":", 1)[0]
        if not key_part.replace("-", "").replace("_", "").isalnum():
            continue

        if indent == 0:
            path_key = key_part
            section = key_part if stripped.rstrip().endswith(":") else None
        elif indent == 2 and section is not None:
            path_key = f"{section}.{key_part}"
        else:
            continue

        if path_key not in replacements:
            continue

        newline = "\n" if line.endswith("\n") else ""
        lines[index] = (
            f"{' ' * indent}{key_part}: "
            f"{yaml_scalar(replacements[path_key])}{newline}"
        )
        found.add(path_key)

    missing = sorted(set(replacements) - found)
    if missing:
        raise SystemExit(f"Could not find {', '.join(missing)} in {path}")

    path.write_text("".join(lines), encoding="utf-8")


def customize_site(
    repo_dir: Path,
    *,
    title: str | None,
    author: str | None,
    site_url: str | None,
    description: str | None,
) -> None:
    quarto_replacements: dict[str, str] = {}
    metadata_replacements: dict[str, str] = {}

    if title is not None:
        quarto_replacements["website.title"] = title
    if author is not None:
        quarto_replacements["author"] = author
        metadata_replacements["author"] = author
    if site_url is not None:
        quarto_replacements["website.site-url"] = site_url
    if description is not None:
        quarto_replacements["website.description"] = description

    rewrite_yaml_values(repo_dir / "_quarto.yml", quarto_replacements)

    for metadata_path in [
        repo_dir / "public" / "qmd" / "_metadata.yml",
        repo_dir / "private" / "qmd" / "_metadata.yml",
    ]:
        rewrite_yaml_values(metadata_path, metadata_replacements)

    if quarto_replacements or metadata_replacements:
        print("Updated site metadata.")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qblog-init",
        description=(
            "Clone qblog into a local folder, customize site metadata, "
            "and install git hooks."
        ),
    )
    parser.add_argument(
        "target",
        nargs="?",
        default=None,
        help="Target folder to clone into, or an existing qblog checkout. Default: current checkout when inside one, otherwise ./qblog.",
    )
    parser.add_argument(
        "--repo",
        default=DEFAULT_REPO_URL,
        help=f"Repository URL to clone. Default: {DEFAULT_REPO_URL}",
    )
    parser.add_argument(
        "--branch",
        default=None,
        help="Optional branch to clone.",
    )
    parser.add_argument(
        "--title",
        default=None,
        help="Website title to write into _quarto.yml.",
    )
    parser.add_argument(
        "--author",
        default=DEFAULT_AUTHOR,
        help="Site author to write into _quarto.yml and article metadata.",
    )
    parser.add_argument(
        "--site-url",
        default=None,
        help="Published site URL to write into _quarto.yml.",
    )
    parser.add_argument(
        "--description",
        default=None,
        help="Website description to write into _quarto.yml.",
    )
    parser.add_argument(
        "--keep-template-git",
        action="store_true",
        help=(
            "Keep the cloned template repository history and origin remote. "
            "By default, customized new blogs start with fresh local git history."
        ),
    )
    parser.add_argument(
        "--no-prepare",
        action="store_true",
        help="Install hooks without running qblog-prepare after cloning.",
    )
    return parser


def build_install_hooks_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qblog-install-hooks",
        description="Install qblog git hooks in an existing checkout.",
    )
    parser.add_argument(
        "target",
        nargs="?",
        default=".",
        help="Existing qblog checkout or a path inside it. Default: current directory.",
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    if args.target is None:
        cwd_root = maybe_git_root(Path.cwd())
        if cwd_root is not None and (cwd_root / ".githooks" / "pre-push").exists():
            target = cwd_root
        else:
            target = (Path.cwd() / "qblog").resolve()
    else:
        target = Path(args.target).expanduser().resolve()

    site_url = args.site_url or default_site_url(target.name)

    repo_dir, cloned = clone_repo(args.repo, target, args.branch)
    if cloned and not args.keep_template_git:
        reinitialize_git_repo(repo_dir)

    customize_site(
        repo_dir,
        title=args.title,
        author=args.author,
        site_url=site_url,
        description=args.description,
    )
    install_hooks(repo_dir)

    if not args.no_prepare:
        run_prepare(repo_dir)

    print("qblog is ready.")


def install_hooks_main(argv: list[str] | None = None) -> None:
    args = build_install_hooks_parser().parse_args(argv)
    target = Path(args.target).expanduser().resolve()
    install_hooks(target)


if __name__ == "__main__":
    main()
