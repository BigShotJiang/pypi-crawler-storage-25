# qblog

CLI helpers for preparing this Quarto blog.

## Commands

```bash
qblog-prepare
qblog-install-hooks
qblog-init
```

Put Markdown article sources in `public/md/<name>.md` or
`private/md/<name>.md`, then run `qblog-prepare`. The command writes
Quarto-ready files to `public/qmd/<slug>.qmd` or
`private/qmd/<slug>.qmd`, and copies local images into the matching
collection-level `public/fig/` or `private/fig/` folder. Markdown and QMD
image links are rewritten to `../fig/<image>`.

For example:

```bash
qblog-prepare public/md/my-note.md
```

Without arguments, `qblog-prepare` resyncs Markdown files in `public/md/` and
`private/md/`.
If a source Markdown file is removed, `qblog-prepare` removes its generated QMD
file and managed images unless those images are still used by another source.

Generated QMD files always use the source Markdown file's last modified timestamp, to the second.
Hand-written QMD files in `public/qmd/` and `private/qmd/` are also scanned by
`qblog-prepare`; files without a `date` field get one based on their last
modified timestamp, and all QMD pages are added to the banner manifests.
Banner assignments live in `public/manifest.json` and `private/manifest.json`;
both are tracked because this repository is private. `private/qmd/` uses
`draft: true`; the website renders those pages with `draft-mode: unlinked`, so
they are generated without being added to normal listings.

`qblog-install-hooks` installs the repository's `.githooks/pre-push` hook in an
existing checkout.

`qblog-init` clones the blog repository, installs the hook, and runs the
preparation step.

To create a new blog from this template locally:

```bash
qblog-init <repo_name> --title "<web title name>"
```

`<repo_name>` is the local folder name and expected GitHub repository name.
`<web title name>` is the website title written to `_quarto.yml`.

For example:

```bash
qblog-init chem-notes --title "Chem Notes"
```

This creates a local folder named `chem-notes`, writes `Chem Notes` as the
website title, and derives the GitHub Pages URL
`https://sky1ove.github.io/chem-notes`.

`qblog-init` uses `Lily` as the author by default. A newly cloned target starts
with fresh local git history instead of keeping this template repository's
`origin`. Pass `--site-url` or `--keep-template-git` only when you need to
override those defaults.
