# src2md

[![PyPI](https://img.shields.io/pypi/v/src2md)](https://pypi.org/project/src2md/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

Sometimes you just want to paste a codebase into a chatbot. **src2md** converts a source code directory into a single Markdown file -- that's it.

No frameworks. No token optimizers. No LLM integrations. Just your code in a format any LLM can read.

## Install

```bash
pip install src2md
```

## Usage

```bash
# Output to stdout (pipe to clipboard, redirect to file, etc.)
src2md /path/to/project | pbcopy
src2md /path/to/project > output.md

# Or save to a file directly
src2md /path/to/project -o output.md

# Include recent git history for extra context
src2md /path/to/project --log
```

That gives you a Markdown file with every matching file in fenced code blocks with syntax highlighting, respecting your `.gitignore` automatically.

### Options

```
src2md path [options]

-o, --out FILE            Output file (default: stdout)
--include PATTERN ...     File patterns to include (default: common extensions)
--exclude PATTERN ...     File/dir patterns to exclude (default: .* hidden files)
--log [N]                 Include recent git history (default: 25 commits)
```

### Examples

```bash
# Only Python files
src2md . --include '*.py'

# Everything except tests and docs
src2md . --exclude tests docs

# Python files with last 50 commits of history
src2md . --include '*.py' --log 50
```

### .gitignore

If your project is a git repo, `src2md` automatically respects `.gitignore`. No need to configure anything -- `node_modules/`, `__pycache__/`, `dist/`, etc. are excluded if your `.gitignore` says so.

For non-git directories, use `--exclude` to skip what you don't need.

### Supported languages

Python, C/C++, JavaScript/TypeScript, Java, Go, Ruby, PHP, Swift, Kotlin, Rust, R, Bash, SQL, HTML, CSS, SCSS, JSON, XML, YAML, TOML, Markdown, LaTeX, Lua, Zig, Nim, Elixir, Erlang, Haskell, OCaml, Scala, Clojure, Dart, Vue, Svelte, and more.

## Why?

Agentic coding tools (Claude Code, Cursor, etc.) can browse your repo directly.
But sometimes you're just talking to a plain chatbot -- ChatGPT, Claude.ai, etc. -- and you want to give it your whole project as context. Copy-pasting files one by one is tedious. `src2md` does it in one command.

This can also breathe some life into older or smaller LLMs for coding tasks -- give them the full project context they'd otherwise never see. Just be aware that `src2md` does nothing smart about context limits. A large repo produces a large file. If your LLM has a small context window, use `--include` and `--exclude` to narrow things down.

## License

MIT
