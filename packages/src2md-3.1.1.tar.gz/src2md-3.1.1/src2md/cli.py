"""
src2md - Convert a source code directory into a single Markdown file.

Primarily used to give an LLM chatbot (ChatGPT, Claude.ai, etc.) context
about your project in a single paste. Respects .gitignore automatically.

Usage:
    src2md path/to/source                        # output to stdout
    src2md path/to/source -o output.md           # output to file
    src2md path/to/source --include '*.py'       # only Python files
    src2md path/to/source --exclude tests docs   # skip directories
    src2md path/to/source --log                  # include recent git history
    src2md path/to/source --log 50               # last 50 commits
"""
import argparse
import fnmatch
import os
import subprocess
import sys
from pathlib import Path


LANGS = {
    '.py': 'python',
    '.c': 'c',
    '.h': 'c',
    '.cpp': 'cpp',
    '.cxx': 'cpp',
    '.cc': 'cpp',
    '.hpp': 'cpp',
    '.cs': 'csharp',
    '.js': 'javascript',
    '.jsx': 'javascript',
    '.ts': 'typescript',
    '.tsx': 'typescript',
    '.java': 'java',
    '.go': 'go',
    '.rb': 'ruby',
    '.php': 'php',
    '.swift': 'swift',
    '.kt': 'kotlin',
    '.rs': 'rust',
    '.r': 'r',
    '.sh': 'bash',
    '.bash': 'bash',
    '.bat': 'batch',
    '.ps1': 'powershell',
    '.sql': 'sql',
    '.html': 'html',
    '.css': 'css',
    '.scss': 'scss',
    '.json': 'json',
    '.xml': 'xml',
    '.yaml': 'yaml',
    '.yml': 'yaml',
    '.toml': 'toml',
    '.ini': 'ini',
    '.cfg': 'ini',
    '.md': 'markdown',
    '.rst': 'rst',
    '.tex': 'latex',
    '.lark': 'lark',
    '.dockerfile': 'dockerfile',
    '.lua': 'lua',
    '.zig': 'zig',
    '.nim': 'nim',
    '.ex': 'elixir',
    '.exs': 'elixir',
    '.erl': 'erlang',
    '.hs': 'haskell',
    '.ml': 'ocaml',
    '.scala': 'scala',
    '.clj': 'clojure',
    '.dart': 'dart',
    '.vue': 'vue',
    '.svelte': 'svelte',
}

DEFAULT_INCLUDE = [f"*{ext}" for ext in LANGS]


def _matches_any(name, patterns):
    return any(fnmatch.fnmatch(name, pat) for pat in patterns)


def _git(path, *args):
    """Run a git subcommand in `path`. Return stdout on success, None on any failure."""
    try:
        result = subprocess.run(
            ['git', *args], cwd=path,
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            return result.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _git_files(path):
    out = _git(path, 'ls-files', '--cached', '--others', '--exclude-standard')
    return None if out is None else [f for f in out.splitlines() if f]


def _git_log(path, n=25):
    out = _git(path, 'log', '--format=%h %ad %s', '--date=short', f'-n{n}')
    return out.strip() if out and out.strip() else None


def _iter_files(path, include_pat, exclude_pat):
    """Yield relative file paths, using git when available."""
    path = Path(path)

    git_files = _git_files(path)
    if git_files is not None:
        for rel in sorted(git_files):
            parts = Path(rel).parts
            if any(_matches_any(p, exclude_pat) for p in parts):
                continue
            if not _matches_any(parts[-1], include_pat):
                continue
            yield rel
    else:
        for root, dirs, files in os.walk(path):
            dirs[:] = sorted(d for d in dirs if not _matches_any(d, exclude_pat))
            for fname in sorted(files):
                if _matches_any(fname, exclude_pat):
                    continue
                if not _matches_any(fname, include_pat):
                    continue
                yield (Path(root) / fname).relative_to(path).as_posix()


def generate_markdown(path, include_pat, exclude_pat, log=None):
    """Walk directory, return Markdown string with all matching files in fenced code blocks."""
    out = []
    path = Path(path)
    out.append(f"# {path.resolve().name}\n\n")

    if log is not None:
        history = _git_log(path, n=log)
        if history:
            out.append(f"## Recent History\n\n```\n{history}\n```\n\n")

    for rel in _iter_files(path, include_pat, exclude_pat):
        file_path = path / rel

        try:
            content = file_path.read_text(encoding='utf-8')
        except FileNotFoundError:
            continue  # tracked by git but deleted from disk
        except (IOError, UnicodeDecodeError) as e:
            print(f"Warning: skipping {rel}: {e}", file=sys.stderr)
            continue

        lang = LANGS.get(file_path.suffix.lower(), '')
        out.append(f"## {rel}\n\n")
        out.append(f"```{lang}\n{content}\n```\n\n")

    return ''.join(out)


def main():
    parser = argparse.ArgumentParser(
        description="Convert a source code directory into a single Markdown file."
    )
    parser.add_argument("path", help="Path to the source directory")
    parser.add_argument("-o", "--out", default=None, help="Output file (default: stdout)")
    parser.add_argument(
        "--include", nargs='+', default=DEFAULT_INCLUDE,
        help="File patterns to include (default: common source/doc extensions)"
    )
    parser.add_argument(
        "--exclude", nargs='+', default=['.*'],
        help="File/directory patterns to exclude (default: .* hidden files)"
    )
    parser.add_argument(
        "--log", nargs='?', type=int, const=25, default=None, metavar='N',
        help="Include recent git history (default: 25 commits)"
    )

    args = parser.parse_args()

    path = Path(args.path)
    if not path.is_dir():
        print(f"Error: {args.path} is not a valid directory.", file=sys.stderr)
        sys.exit(1)

    markdown = generate_markdown(path, args.include, args.exclude, log=args.log)

    if args.out:
        try:
            with open(args.out, 'w', encoding='utf-8') as f:
                f.write(markdown)
        except IOError as e:
            print(f"Error writing to {args.out}: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        sys.stdout.write(markdown)


if __name__ == "__main__":
    main()
