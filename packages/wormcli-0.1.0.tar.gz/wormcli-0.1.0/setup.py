from setuptools import setup, find_packages

setup(
    name="wormcli",
    version="0.1.0",
    description="🐍 AI-powered terminal assistant with hybrid rule-based + LLM engine",
    author="WormStudio",
    author_email="wormstudio@proton.me",
    url="https://github.com/WormStudio-s/wormcli",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "wormcli=wormcli.cli:main",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
