# 🐍 WormCLI — AI-ассистент в терминале

Гибридный движок: rule-based (как thefuck) + опциональная LLM через Ollama.

## Установка (< 2 минут)

```bash
pip install wormcli
```

Использование

```bash
# Базовое исправление (rule-based, 50ms)
worm "apt install python3"

# Режим вопрос-ответ (безопасно)
worm ask "как найти все файлы .log больше 100MB"

# LLM режим (требует Ollama)
worm --ollama "найти процесс на порту 3000"
```

Shell hook

```bash
eval "$(worm hook)"
# Теперь ошибочные команды будут предлагать исправления
```

Лицензия

MIT
