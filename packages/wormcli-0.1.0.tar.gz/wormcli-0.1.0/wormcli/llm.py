import subprocess
from typing import Optional

class LLMBackend:
    def __init__(self, model: str = "phi:2.7b"):
        self.model = model
        self.available = self._check_ollama()
    
    def _check_ollama(self) -> bool:
        try:
            result = subprocess.run(["ollama", "--version"], capture_output=True, text=True, timeout=2)
            return result.returncode == 0
        except:
            return False
    
    def is_available(self) -> bool:
        return self.available
    
    def generate(self, prompt: str, timeout: int = 10) -> Optional[str]:
        if not self.available:
            return None
        try:
            result = subprocess.run(
                ["ollama", "run", self.model, prompt],
                capture_output=True, text=True, timeout=timeout
            )
            if result.returncode == 0 and result.stdout:
                return result.stdout.strip()
        except:
            pass
        return None
    
    def explain(self, error: str, command: str, timeout: int = 15) -> Optional[str]:
        if not self.available:
            return None
        return self.generate(f"Explain error: command={command}, error={error}", timeout)
