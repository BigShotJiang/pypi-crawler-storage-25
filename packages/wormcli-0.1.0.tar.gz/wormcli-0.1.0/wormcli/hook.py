def generate_hook() -> str:
    return '''# WormCLI hook for bash/zsh
wormcli_fix() {
    local last_command=$(fc -ln -1)
    local fix=$(wormcli "$last_command" --quiet 2>/dev/null)
    if [ -n "$fix" ] && [ "$fix" != "$last_command" ]; then
        echo -e "\\n🐍 WormCLI suggests: $fix"
        read -p "Apply? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            eval "$fix"
        fi
    fi
}

if ! command -v thefuck &> /dev/null; then
    PROMPT_COMMAND="${PROMPT_COMMAND:+$PROMPT_COMMAND; }wormcli_fix"
fi
'''
