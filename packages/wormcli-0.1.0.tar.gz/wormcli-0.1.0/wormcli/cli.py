#!/usr/bin/env python3
import argparse
import sys
import re
import signal
from typing import Optional

from .rules import RuleEngine
from .llm import LLMBackend
from .ask import ask_question
from .hook import generate_hook

class TimeoutError(Exception):
    pass

def timeout_handler(signum, frame):
    raise TimeoutError()

def confirm_dangerous(command: str, quiet: bool = False) -> bool:
    """Запросить подтверждение для опасной команды"""
    if quiet:
        return False
    
    print("\n" + "=" * 50)
    print("⚠️  WARNING: POTENTIALLY DANGEROUS COMMAND DETECTED  ⚠️")
    print("=" * 50)
    print(f"Command: {command}")
    print("=" * 50)
    
    response = input("Do you want to execute this command? (yes/NO): ").strip().lower()
    return response == 'yes'

def main():
    parser = argparse.ArgumentParser(description="🐍 WormCLI — AI-ассистент в терминале")
    parser.add_argument("command", nargs="?", help="Команда или вопрос для исправления")
    parser.add_argument("--fix", action="store_true", help="Исправить последнюю команду")
    parser.add_argument("--explain-last", action="store_true", help="Объяснить последнюю ошибку")
    parser.add_argument("--ask", action="store_true", help="Режим вопрос-ответ (без выполнения)")
    parser.add_argument("--ollama", action="store_true", help="Использовать Ollama (если доступна)")
    parser.add_argument("--quiet", action="store_true", help="Тихий режим (только команда)")
    parser.add_argument("--timeout", type=int, default=10, help="Таймаут для LLM (секунды)")
    
    args = parser.parse_args()
    
    # Генерация hook
    if args.command == "hook":
        print(generate_hook())
        return
    
    # Инициализация компонентов
    rules = RuleEngine()
    llm = LLMBackend() if args.ollama else None
    
    # Режим ask (вопрос-ответ)
    if args.ask and args.command:
        result = ask_question(args.command, llm, timeout=args.timeout)
        print(result)
        return
    
    # Объяснение последней ошибки (требует LLM)
    if args.explain_last:
        if not llm or not llm.is_available():
            print("❌ Режим --explain-last требует Ollama с моделью phi:2.7b")
            print("   Установите: https://ollama.ai && ollama pull phi:2.7b")
            return
        
        print("⚠️ Shell hook в разработке. Пока используйте: wormcli ask 'объясни ошибку'")
        return
    
    # Исправление команды
    if args.command:
        # 1. Rule-based
        fix = rules.apply(args.command)
        if fix and fix.confidence > 0.7:
            if fix.dangerous:
                if not args.quiet:
                    print(f"⚠️ {fix.reason}")
                    print(f"🐍 Suggested command: {fix.command}")
                if confirm_dangerous(fix.command, args.quiet):
                    print(fix.command)
                else:
                    print("❌ Command rejected by user")
                    sys.exit(1)
            else:
                if not args.quiet:
                    print(f"🐍 {fix.reason}")
                print(fix.command)
            return
        
        # 2. LLM (если включена)
        if llm and llm.is_available():
            cmd = llm.generate(args.command, timeout=args.timeout)
            if cmd:
                dangerous = rules.is_dangerous(cmd)
                if dangerous:
                    if confirm_dangerous(cmd, args.quiet):
                        print(cmd)
                    else:
                        print("❌ Command rejected by user")
                        sys.exit(1)
                else:
                    if not args.quiet:
                        print("🐍 LLM suggestion (check before run):")
                    print(cmd)
                return
        
        # 3. Fallback
        if not args.quiet:
            print("🐍 Could not generate command. Try:")
            print(f"   wormcli ask \"{args.command}\"")
            print(f"   or install Ollama for better results: https://ollama.ai")
        sys.exit(1)
    
    parser.print_help()

if __name__ == "__main__":
    main()
