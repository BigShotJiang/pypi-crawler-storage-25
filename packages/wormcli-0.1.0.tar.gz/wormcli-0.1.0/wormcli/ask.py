from typing import Optional
from .llm import LLMBackend

def ask_question(question: str, llm: Optional[LLMBackend] = None, timeout: int = 15) -> str:
    if llm and llm.is_available():
        response = llm.generate(question, timeout=timeout)
        if response:
            return f"💡 {response}\n\n⚠️ Проверьте команду перед выполнением!"
    
    return f"""❌ Не удалось сгенерировать команду.

Установите Ollama (https://ollama.ai) и запустите:
  ollama pull phi:2.7b
  wormcli ask "{question}"

Или попробуйте: wormcli "{question}"
"""
