import re
from typing import Optional, List, Tuple
from dataclasses import dataclass

@dataclass
class Fix:
    command: str
    confidence: float
    reason: str
    dangerous: bool = False

class RuleEngine:
    def __init__(self):
        self.rules: List[Tuple[str, str, float]] = [
            (r"apt install", "sudo apt install", 0.95),
            (r"apt update", "sudo apt update", 0.95),
            (r"apt remove", "sudo apt remove", 0.95),
            (r"pip install", "python -m pip install", 0.9),
            (r"python ([a-z_]+\.py)", r"python3 \1", 0.6),
            (r"git push --force", "git push --force-with-lease", 0.95),
            (r"docker ps -a --filter", "docker ps -a --filter status=exited", 0.95),
            (r"npm install -g", "npm install --global", 0.9),
        ]
    
    def is_dangerous(self, command: str) -> bool:
        dangerous_patterns = [
            r"rm\s+-rf\s+/",
            r"dd\s+if=",
            r":\(\)\{ :\|:& \};:",
            r"mkfs\.",
        ]
        for pattern in dangerous_patterns:
            if re.search(pattern, command, re.IGNORECASE):
                return True
        return False
    
    def apply(self, failed_cmd: str, error: str = "") -> Optional[Fix]:
        for pattern, replacement, confidence in self.rules:
            if re.search(pattern, failed_cmd, re.IGNORECASE):
                new_cmd = re.sub(pattern, replacement, failed_cmd, flags=re.IGNORECASE)
                if new_cmd != failed_cmd:
                    return Fix(
                        command=new_cmd,
                        confidence=confidence,
                        reason=f"Rule-based fix",
                        dangerous=self.is_dangerous(new_cmd)
                    )
        return None
