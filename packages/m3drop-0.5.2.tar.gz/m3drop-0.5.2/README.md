# M3Drop

M3Drop
A Python implementation of the M3Drop single-cell RNA-seq analysis tool, originally developed as an R package.

⚠️ This package is under active development. Documentation is incomplete. Install command and usage examples are coming in a future release.

## History
M3Drop 0.0 - Direct, non-HPC conversion from R. (Aug, 2025)

M3Drop 1.0 - Proof of Concept experimenting with out-of-core chunking. (Aug, 2025)

M3Drop 2.0 - ControlDevice Mechanism + implementation of basic HPC principles [DOC TO BE WRITTEN - COMPLETE MAR 2026]. (Feb, 2026)

M3Drop 3.0 - ControlDevice + A more systematic approach to implementation of HPC principles and architecture [COMPLETE - MAR 2026].

M3Drop 3.0 - BENCHMARKING [APR 2026 ONWARDS]

M3Drop 3.0 - CPU PIPELINE RDY [MAY 2026]; Layer 1 validation check complete for CPU and GPU pipelines.

M3Drop 4.0 - Docker + Wrapper function for ease of use and improved user accesibility? [To be decided]

Do not run this on Merfish & Xenium & Smart-seq-2

20260411 UPDATE - Reference Manuals require an update. ModelDiagnosticsGPU.py is now redundant and have merged with Feature Selection.

## Previous Repos
https://github.com/Anthony-121/M3DropGPU

https://github.com/PragalvhaSharma/M3Drop-PY/tree/main

## Original R Package

This Python implementation is based on the M3Drop R package developed by Dr. Tallulah Andrews.

## Citation

- Andrews, T.S. and Hemberg, M. (2019). M3Drop: Dropout-based feature selection for scRNASeq. Bioinformatics, 35(16), 2865-2867.
