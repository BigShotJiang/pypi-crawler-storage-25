
import math
import os
import queue
import sys
import threading
import time

import numpy as np
import h5py

try:
    import psutil
except ImportError:
    psutil = None


class ControlDeviceCPU:

    def __init__(
        self,
        indptr:        np.ndarray,
        total_rows:    int,
        n_genes:       int,
        mode:          str   = "auto",
        manual_target: int   = 5000,
        data_path:     str   = 'X',
        bytes_per_item: int  = 16,
        **kwargs
    ):

        if not isinstance(indptr, np.ndarray) or indptr.ndim != 1 or len(indptr) < 2:
            raise ValueError(
                "indptr must be a 1-D numpy array with at least 2 elements."
            )
        if int(indptr[0]) != 0:
            raise ValueError(
                "indptr[0] must be 0 -- invalid CSR format."
            )

        self.indptr        = indptr
        self.total_rows    = total_rows
        self.n_genes       = n_genes
        self.mode          = mode.lower()
        self.manual_target = manual_target
        self.data_path     = data_path
        self.bytes_per_item = bytes_per_item


        self.sys_ram_limit_mb     = self._detect_real_memory_limit()
        self.sys_ram_available_mb = self._detect_available_memory()


        _FULL_THRESH     = 0.50
        _MODERATE_THRESH = 0.20
        _avail_ratio     = self.sys_ram_available_mb / max(self.sys_ram_limit_mb, 1.0)

        if _avail_ratio >= _FULL_THRESH:
            headroom_mb   = max(2048.0, self.sys_ram_limit_mb * 0.12)
            safe_mb       = max(0.0, self.sys_ram_available_mb - headroom_mb)
            _budget_basis = "Tier 1: FULL"

        elif _avail_ratio >= _MODERATE_THRESH:
            _blend           = (_FULL_THRESH - _avail_ratio) / (_FULL_THRESH - _MODERATE_THRESH)
            headroom_mb      = max(2048.0, self.sys_ram_limit_mb * 0.12)
            safe_avail_mb    = max(0.0, self.sys_ram_available_mb - headroom_mb)
            hard_overhead_mb = max(4096.0, self.sys_ram_limit_mb * 0.28)
            safe_total_mb    = max(0.0, self.sys_ram_limit_mb - hard_overhead_mb)
            safe_mb          = (1.0 - _blend) * safe_avail_mb + _blend * safe_total_mb
            _budget_basis    = "Tier 2: MODERATE"

        else:
            hard_overhead_mb = max(4096.0, self.sys_ram_limit_mb * 0.28)
            safe_mb          = max(0.0, self.sys_ram_limit_mb - hard_overhead_mb)
            _budget_basis    = "Tier 3: MINIMAL"

        self.safe_mb = float(safe_mb)


        self.working_mem_budget_bytes = self.safe_mb * 0.30 * 1024 * 1024


        self._acc_mem_reserved: int = 0


        if self.sys_ram_limit_mb >= 32768:
            payload_cap_mb = 2048.0
        elif self.sys_ram_limit_mb >= 15360:
            payload_cap_mb = 1024.0
        elif self.sys_ram_limit_mb >= 8192:
            payload_cap_mb =  512.0
        else:
            payload_cap_mb =  256.0

        _working_budget_mb = self.working_mem_budget_bytes / (1024 * 1024)

        if self.mode == "manual":
            target_mb        = float(self.manual_target)
            self._max_q_size = 2 if self.sys_ram_limit_mb > 8192 else 1
        else:
            target_mb        = min(_working_budget_mb, payload_cap_mb)
            target_mb        = max(128.0, target_mb)
            raw_depth        = int(safe_mb / target_mb)
            self._max_q_size = max(1, min(2, raw_depth))

        self.payload_sparse_target_bytes = target_mb * 1024 * 1024
        self.payload_dense_target_bytes  = target_mb * 1024 * 1024


        self.prefetch_queue:  queue.Queue        = None
        self.prefetch_thread: threading.Thread   = None
        self._stop_event:     threading.Event    = threading.Event()


        _data_label_map = {
            'X':             'X',
            'raw/X':         'raw.X',
            'layers/counts': 'layers.counts',
        }
        display_data = _data_label_map.get(
            self.data_path,
            (self.data_path or "Unknown").replace('/', '.')
        )

        print(f"\n-------------- CONTROL DEVICE (CPU) --------------")
        print(f"  > Data:    {display_data}")
        print(f"  > Mode:    {'MANUAL' if self.mode == 'manual' else 'AUTO'}")
        print(f"  > RAM:     {self.sys_ram_available_mb:.0f} MB avail  /  {self.sys_ram_limit_mb:.0f} MB total"
              f"  [{_budget_basis}]")
        print(f"  > Working: {_working_budget_mb:.0f} MB budget  ({self.safe_mb:.0f} MB safe)")
        print(f"  > Payload: {target_mb:.0f} MB/chunk")
        print(f"  > Buffer:  {target_mb:.0f} MB/chunk  x  depth {self._max_q_size}"
              f"  =  {target_mb * self._max_q_size:.0f} MB  [budget: {safe_mb:.0f} MB]")
        print(f"--------------------------------------------------\n")


    def _detect_real_memory_limit(self) -> float:
        limits = []
        if 'SLURM_MEM_PER_NODE' in os.environ:
            try:
                limits.append(float(os.environ['SLURM_MEM_PER_NODE']))
            except Exception:
                pass
        if 'SLURM_MEM_PER_CPU' in os.environ and 'SLURM_CPUS_ON_NODE' in os.environ:
            try:
                limits.append(float(os.environ['SLURM_MEM_PER_CPU']) *
                              float(os.environ['SLURM_CPUS_ON_NODE']))
            except Exception:
                pass
        for cg in ('/sys/fs/cgroup/memory/memory.limit_in_bytes',
                   '/sys/fs/cgroup/memory.max'):
            if os.path.exists(cg):
                try:
                    with open(cg) as f:
                        v = f.read().strip()
                    if v != 'max':
                        val = float(v)
                        if val < 1e15:
                            limits.append(val / (1024 ** 2))
                except Exception:
                    pass
        if psutil:
            limits.append(psutil.virtual_memory().total / (1024 ** 2))
        return min(limits) if limits else 4096.0

    def _detect_available_memory(self) -> float:
        if 'SLURM_MEM_PER_NODE' in os.environ or 'SLURM_MEM_PER_CPU' in os.environ:
            return self.sys_ram_limit_mb

        if (os.path.exists('/sys/fs/cgroup/memory.current') and
                os.path.exists('/sys/fs/cgroup/memory.max')):
            try:
                with open('/sys/fs/cgroup/memory.current') as f:
                    current = float(f.read().strip())
                with open('/sys/fs/cgroup/memory.max') as f:
                    v = f.read().strip()
                if v != 'max':
                    return max(0.0, (float(v) - current) / (1024 ** 2))
            except Exception:
                pass

        if psutil:
            return psutil.virtual_memory().available / (1024 ** 2)

        return self.sys_ram_limit_mb * 0.50


    def compute_block_size(self, n_genes: int, n_methods: int = 1) -> int:
        n_methods  = max(1, n_methods)
        acc_budget = self.safe_mb * 1024 * 1024 * 0.25
        coeff      = n_methods * 3 * 8

        best_bs  = 64
        start_bs = max(((n_genes + 31) // 32) * 32, 64)

        for bs in range(start_bs, 63, -32):
            nb       = math.ceil(n_genes / bs)
            acc_mem  = nb * coeff * bs * bs
            if acc_mem <= acc_budget:
                best_bs = bs
                break

        num_blocks              = math.ceil(n_genes / best_bs)
        self._acc_mem_reserved  = int(num_blocks * coeff * best_bs * best_bs)

        warn = ""
        if self._acc_mem_reserved > acc_budget:
            warn = "  [WARN: acc exceeds 25% safe_mb -- minimum bs=64 enforced]"

        print(f"  > Block:   {best_bs} genes/block  x  {num_blocks} blocks  |  "
              f"Acc RAM: {self._acc_mem_reserved / (1024**3):.2f} GB{warn}")
        return best_bs

    def get_coex_overhead(self, block_size: int, raw_n_genes: int) -> float:
        return max(1.2, 1.0 + 14.0 * block_size / raw_n_genes)


    @classmethod
    def from_h5ad(
        cls, filepath: str, mode: str = "auto",
        manual_target: int = 5000, data_path: str = 'X', **kwargs
    ):
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
        with h5py.File(filepath, "r") as f:
            if (data_path in f and isinstance(f[data_path], h5py.Group)
                    and 'indptr' in f[data_path]):
                indptr_loaded = f[data_path]['indptr'][:]
                if 'shape' in f[data_path].attrs:
                    shape      = f[data_path].attrs['shape']
                    total_rows = int(shape[0])
                    n_genes    = int(shape[1])
                else:
                    total_rows = len(indptr_loaded) - 1
                    var_path   = 'raw/var' if data_path == 'raw/X' else 'var'
                    n_genes    = len(f[var_path]) if var_path in f else 1


                try:
                    val_bytes = f[data_path]['data'].dtype.itemsize
                    idx_bytes = f[data_path]['indices'].dtype.itemsize
                    bpi       = val_bytes + idx_bytes + 4
                except Exception:
                    bpi = 16

                return cls(
                    indptr=indptr_loaded, total_rows=total_rows, n_genes=n_genes,
                    mode=mode, manual_target=manual_target, data_path=data_path,
                    bytes_per_item=bpi, **kwargs
                )
            else:
                raise ValueError(
                    f"ControlDeviceCPU requires SPARSE (CSR) data at '{data_path}'. "
                    f"Key 'indptr' not found."
                )


    def get_next_chunk(
        self,
        start_row:           int,
        mode:                str   = 'sparse',
        overhead_multiplier: float = 1.0,
        mem_reserve:         int   = 0,

        vram_reserve:        int   = None,
    ) -> int:
        if vram_reserve is not None and mem_reserve == 0:
            mem_reserve = vram_reserve

        if start_row >= self.total_rows:
            return None

        overhead_multiplier = max(overhead_multiplier, 1.0)
        effective_mem       = max(
            self.working_mem_budget_bytes - mem_reserve,
            self.working_mem_budget_bytes * 0.10
        )


        if self.mode == "manual" and self.manual_target > 0:
            active_target = float(self.manual_target) * 1024 * 1024
        else:
            active_target = (self.payload_dense_target_bytes if mode == 'dense'
                             else self.payload_sparse_target_bytes)

        if mode == 'dense':
            bytes_per_row = self.n_genes * 8.0 * overhead_multiplier
            target_rows   = max(1, int(active_target / bytes_per_row))
            end_row       = start_row + target_rows
        else:
            max_items  = int((active_target / overhead_multiplier) / self.bytes_per_item)
            curr_ptr   = int(self.indptr[start_row])
            target_ptr = curr_ptr + max_items
            soft_limit = int(np.searchsorted(self.indptr, target_ptr, side='right')) - 1
            soft_limit = max(soft_limit, start_row + 1)
            end_row    = soft_limit

        end_row = min(end_row, self.total_rows)


        count = end_row - start_row
        if count > 32:
            end_row = start_row + (count // 32) * 32
        end_row = max(end_row, start_row + 1)


        chunk_rows = end_row - start_row

        if mode == 'dense':
            mem_cost = chunk_rows * self.n_genes * 8.0 * overhead_multiplier
            if mem_cost > effective_mem:
                bpr      = self.n_genes * 8.0 * overhead_multiplier
                max_rows = max(1, int(effective_mem / bpr))
                end_row  = start_row + max_rows
                count    = end_row - start_row
                if count > 32:
                    end_row = start_row + (count // 32) * 32
                end_row = max(end_row, start_row + 1)
        else:
            end_clamped = min(end_row, self.total_rows)
            actual_nnz  = int(self.indptr[end_clamped]) - int(self.indptr[start_row])
            sparse_cost = actual_nnz * 16.0 * overhead_multiplier
            if sparse_cost > effective_mem:
                ratio   = effective_mem / max(sparse_cost, 1.0)
                new_cnt = max(32, int(chunk_rows * ratio))
                end_row = start_row + new_cnt
                count   = end_row - start_row
                if count > 32:
                    end_row = start_row + (count // 32) * 32
                end_row = max(end_row, start_row + 1)

        return int(min(end_row, self.total_rows))


    def start_prefetcher(
        self,
        filepath:            str,
        fetch_mode:          str   = 'sparse',
        overhead_multiplier: float = 1.1,
        mem_reserve:         int   = 0,
        vram_reserve:        int   = None,
        silent:              bool  = False
    ):
        if vram_reserve is not None and mem_reserve == 0:
            mem_reserve = vram_reserve

        self._stop_event.clear()

        q                   = queue.Queue(maxsize=self._max_q_size)
        self.prefetch_queue = q

        active_target = (
            self.manual_target * 1024 * 1024 if self.mode == "manual"
            else (self.payload_sparse_target_bytes if fetch_mode == 'sparse'
                  else self.payload_dense_target_bytes)
        )
        chunk_mb = active_target / (1024 ** 2)

        if not silent:
            print(f"  > [Prefetcher]: {fetch_mode.upper()} | "
                  f"Depth: {self._max_q_size} | "
                  f"Buffer budget: {int(chunk_mb * self._max_q_size)} MB RAM")

        self.prefetch_thread = threading.Thread(
            target=self._prefetch_worker,
            args=(filepath, fetch_mode, overhead_multiplier, mem_reserve, q),
            daemon=True
        )
        self.prefetch_thread.start()

    def _prefetch_worker(
        self,
        filepath:            str,
        fetch_mode:          str,
        overhead_multiplier: float,
        mem_reserve:         int,
        out_queue:           queue.Queue
    ):
        try:
            with h5py.File(filepath, 'r') as f_in:
                h5_indptr  = f_in[self.data_path]['indptr']
                h5_data    = f_in[self.data_path]['data']
                h5_indices = f_in[self.data_path]['indices']

                curr_row = 0
                while curr_row < self.total_rows:
                    if self._stop_event.is_set():
                        break

                    next_row = self.get_next_chunk(
                        curr_row, mode=fetch_mode,
                        overhead_multiplier=overhead_multiplier,
                        mem_reserve=mem_reserve
                    )
                    if next_row is None or next_row <= curr_row:
                        break

                    s_idx      = int(h5_indptr[curr_row])
                    e_idx      = int(h5_indptr[next_row])
                    chunk_nnz  = int(e_idx - s_idx)
                    chunk_rows = int(next_row - curr_row) + 1

                    if chunk_nnz > 0:

                        data_buf = np.empty(chunk_nnz,  dtype=h5_data.dtype)
                        idx_buf  = np.empty(chunk_nnz,  dtype=h5_indices.dtype)
                        ptr_buf  = np.empty(chunk_rows, dtype=h5_indptr.dtype)


                        _t_read_start = time.perf_counter()
                        h5_data.read_direct(   data_buf, np.s_[s_idx:e_idx],          np.s_[:chunk_nnz])
                        h5_indices.read_direct(idx_buf,  np.s_[s_idx:e_idx],          np.s_[:chunk_nnz])
                        h5_indptr.read_direct( ptr_buf,  np.s_[curr_row:next_row + 1], np.s_[:chunk_rows])
                        _read_seconds = time.perf_counter() - _t_read_start

                        _read_bytes = (
                            data_buf.nbytes + idx_buf.nbytes + ptr_buf.nbytes
                        )

                        ptr_buf -= ptr_buf[0]

                        payload = {
                            'status':       'OK',
                            'curr_row':     int(curr_row),
                            'next_row':     int(next_row),
                            'nnz':          chunk_nnz,
                            'rows':         chunk_rows,
                            'data':         data_buf,
                            'indices':      idx_buf,
                            'indptr':       ptr_buf,
                            'read_seconds': float(_read_seconds),
                            'read_bytes':   int(_read_bytes),
                        }
                    else:
                        payload = {
                            'status':       'OK',
                            'curr_row':     int(curr_row),
                            'next_row':     int(next_row),
                            'nnz':          0,
                            'rows':         chunk_rows,
                            'read_seconds': 0.0,
                            'read_bytes':   0,
                        }

                    out_queue.put(payload)
                    curr_row = next_row

            out_queue.put({'status': 'DONE'})

        except Exception as exc:
            try:
                out_queue.put({'status': 'ERROR', 'error': exc})
            except Exception:
                pass

    def get_prefetched_chunk(self) -> dict:
        if self.prefetch_queue is None:
            raise RuntimeError("Prefetcher not started -- call start_prefetcher() first.")
        payload = self.prefetch_queue.get()
        if payload['status'] == 'ERROR':
            raise payload['error']
        if payload['status'] == 'DONE':
            return None
        return payload


    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.shutdown()
        return False


    def shutdown(self):
        self._stop_event.set()
        if self.prefetch_thread and self.prefetch_thread.is_alive():
            try:
                while True:
                    self.prefetch_queue.get_nowait()
            except (queue.Empty, AttributeError):
                pass
            self.prefetch_thread.join(timeout=5.0)


ControlDevice = ControlDeviceCPU
