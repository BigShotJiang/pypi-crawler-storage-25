__version__ = "0.5.0"

try:
    from .ComputeBlockCPU import RunComputeBlockCPU
    from .FeatureSelectionCPU import RunFeatureSelectionCPU
    from .NormalizationCPU import RunNormalizationCPU
    from .CoexpressionCPU import RunCoexpressionCPU
except ImportError:
    pass

try:
    from .ComputeBlockGPU import RunComputeBlockGPU
    from .FeatureSelectionGPU import RunFeatureSelectionGPU
    from .NormalizationGPU import RunNormalizationGPU
    from .CoexpressionGPU import RunCoexpressionGPU
except ImportError:
    pass
