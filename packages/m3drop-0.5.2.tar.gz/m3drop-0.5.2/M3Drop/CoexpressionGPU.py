import os
import time
import math
import tempfile
import h5py
import numpy as np
import sys
import anndata

try:
    import cupy as cp
    from cupy.sparse import csr_matrix as cp_csr_matrix
except ImportError:
    raise ImportError("CRITICAL ERROR: CuPy not found. This script requires a GPU.")

from .ControlDeviceGPU import ControlDevice
from .ComputeBlockGPU import (
    ComputeBlockA,
    ComputeBlockB,
    detect_data_path,
)


calc_p_kernel = cp.ElementwiseKernel(
    'float64 ti, float64 tj, float64 size, float64 total',
    'float64 P',
    '''
    double mu   = (ti * tj) / total;
    double base = (mu / size) + 1.0;
    if (base < 1e-12) base = 1e-12;
    P = pow(base, -size);
    if (isnan(P))      P = 0.0;
    else if (isinf(P)) P = (P > 0) ? 1.0 : 0.0;
    ''',
    'calc_p_kernel'
)


def NBumiCoexpressionGPU(
    raw_filename:  str,
    out_filename:  str,
    block_data:    dict,
    methods:       list = ["both"],
    mode:          str  = "auto",
    manual_target: int  = 3000,
):
    start_time = time.perf_counter()
    print(f"\nFUNCTION: NBumiCoexpressionGPU()")

    if not methods:
        print("WARNING: No methods provided. Exiting module.")
        return


    nc          = block_data['nc']
    ng_filtered = block_data['ng']
    total       = cp.float64(block_data['total'])
    data_path   = block_data.get('data_path', 'X')

    tjs   = cp.asarray(block_data['tjs'],   dtype=cp.float64)
    tis   = cp.asarray(block_data['tis'],   dtype=cp.float64)
    sizes = cp.asarray(block_data['sizes'], dtype=cp.float64)

    mask_cpu   = block_data['mask']
    mask_gpu   = cp.asarray(mask_cpu)
    indptr_cpu = block_data['indptr']
    raw_ng     = len(mask_cpu)

    need_off  = 'off'  in methods
    need_on   = 'on'   in methods
    need_both = 'both' in methods


    device = ControlDevice(
        indptr=indptr_cpu, total_rows=nc, n_genes=raw_ng,
        mode=mode, manual_target=manual_target, data_path=data_path,
    )

    BLOCK_SIZE    = device.compute_block_size(ng_filtered, len(methods))
    num_blocks    = math.ceil(ng_filtered / BLOCK_SIZE)
    overhead_mult = device.get_coex_overhead(BLOCK_SIZE, raw_ng)

    acc_vram_max  = device._acc_vram_reserved


    out_dir = os.path.dirname(os.path.abspath(out_filename)) or '.'
    _fd, temp_h5_file = tempfile.mkstemp(
        suffix='.h5', prefix='_coex_tmp_', dir=out_dir
    )
    os.close(_fd)

    try:

        with h5py.File(temp_h5_file, 'w') as f_temp:
            for m in methods:
                for stat in ('Obs', 'E', 'E2'):
                    f_temp.create_dataset(
                        f'{stat}_{m}',
                        shape=(ng_filtered, ng_filtered),
                        chunks=(BLOCK_SIZE, BLOCK_SIZE),
                        dtype='float64',
                    )


        print("Coexpression - Phase 1 & 2: P/Q calculation and dot-product accumulation")

        for i in range(num_blocks):
            start_i = i * BLOCK_SIZE
            end_i   = min(start_i + BLOCK_SIZE, ng_filtered)
            len_i   = end_i - start_i

            tjs_A   = tjs[start_i:end_i]
            sizes_A = sizes[start_i:end_i]


            j_ranges = []
            for j in range(i, num_blocks):
                s_j = j * BLOCK_SIZE
                e_j = min(s_j + BLOCK_SIZE, ng_filtered)
                j_ranges.append((j, s_j, e_j, e_j - s_j))


            n_j           = len(j_ranges)
            coeff         = len(methods) * 3 * 8
            acc_vram_here = int(n_j * coeff * BLOCK_SIZE * BLOCK_SIZE)


            acc = {}
            for j, s_j, e_j, len_j in j_ranges:
                acc[j] = {
                    m: {
                        'Obs': cp.zeros((len_i, len_j), dtype=cp.float64),
                        'E':   cp.zeros((len_i, len_j), dtype=cp.float64),
                        'E2':  cp.zeros((len_i, len_j), dtype=cp.float64),
                    }
                    for m in methods
                }


            device.start_prefetcher(
                raw_filename,
                fetch_mode='dense',
                overhead_multiplier=overhead_mult,
                vram_reserve=acc_vram_here,
                silent=(i > 0),
            )

            try:
                active_payload = device.get_prefetched_chunk()

                while active_payload is not None:
                    chunk_size = active_payload['rows'] - 1
                    curr_row   = active_payload['curr_row']
                    next_row   = active_payload['next_row']
                    nnz        = active_payload['nnz']

                    print(
                        f"  > i {i+1}/{num_blocks} | rows {next_row}/{nc} | "
                        f"{n_j} j-blocks in pass{' '*10}",
                        end='\r', flush=True
                    )

                    if nnz > 0:

                        data_gpu    = cp.asarray(active_payload['data'],    dtype=cp.float64)
                        indices_gpu = cp.asarray(active_payload['indices'])
                        indptr_gpu  = cp.asarray(active_payload['indptr'])

                        chunk_gpu = cp_csr_matrix(
                            (data_gpu, indices_gpu, indptr_gpu),
                            shape=(chunk_size, raw_ng),
                        )
                        chunk_gpu      = chunk_gpu[:, mask_gpu]
                        chunk_gpu.data = cp.ceil(chunk_gpu.data)

                        tis_chunk = tis[curr_row:next_row][:, None]


                        chunk_A = chunk_gpu[:, start_i:end_i].todense()

                        M_A  = (chunk_A == 0.0).astype(cp.float64) if (need_off or need_both) else None
                        O_A  = (chunk_A > 0.0).astype(cp.float64)  if (need_on  or need_both) else None
                        del chunk_A

                        P_A  = cp.empty((chunk_size, len_i), dtype=cp.float64)
                        calc_p_kernel(tis_chunk, tjs_A[None, :], sizes_A[None, :], total, P_A)

                        Q_A  = (1.0 - P_A)  if (need_on  or need_both) else None
                        P_A2 = (P_A * P_A)  if (need_off or need_both) else None
                        Q_A2 = (Q_A * Q_A)  if Q_A is not None        else None


                        for j, s_j, e_j, len_j in j_ranges:
                            tjs_B   = tjs[s_j:e_j]
                            sizes_B = sizes[s_j:e_j]

                            if i == j:

                                if need_off:
                                    acc[j]['off']['Obs'] += cp.dot(M_A.T, M_A)
                                    acc[j]['off']['E']   += cp.dot(P_A.T, P_A)
                                    acc[j]['off']['E2']  += cp.dot(P_A2.T, P_A2)
                                if need_on:
                                    acc[j]['on']['Obs']  += cp.dot(O_A.T, O_A)
                                    acc[j]['on']['E']    += cp.dot(Q_A.T, Q_A)
                                    acc[j]['on']['E2']   += cp.dot(Q_A2.T, Q_A2)
                                if need_both:
                                    acc[j]['both']['Obs'] += cp.dot(M_A.T, M_A) + cp.dot(O_A.T, O_A)
                                    acc[j]['both']['E']   += cp.dot(P_A.T, P_A)  + cp.dot(Q_A.T, Q_A)
                                    acc[j]['both']['E2']  += cp.dot(P_A2.T, P_A2) + cp.dot(Q_A2.T, Q_A2)
                            else:
                                chunk_B = chunk_gpu[:, s_j:e_j].todense()

                                M_B  = (chunk_B == 0.0).astype(cp.float64) if (need_off or need_both) else None
                                O_B  = (chunk_B > 0.0).astype(cp.float64)  if (need_on  or need_both) else None
                                del chunk_B

                                P_B  = cp.empty((chunk_size, len_j), dtype=cp.float64)
                                calc_p_kernel(tis_chunk, tjs_B[None, :], sizes_B[None, :], total, P_B)

                                Q_B  = (1.0 - P_B)  if (need_on  or need_both) else None
                                P_B2 = (P_B * P_B)  if (need_off or need_both) else None
                                Q_B2 = (Q_B * Q_B)  if Q_B is not None        else None

                                if need_off:
                                    acc[j]['off']['Obs'] += cp.dot(M_A.T, M_B)
                                    acc[j]['off']['E']   += cp.dot(P_A.T, P_B)
                                    acc[j]['off']['E2']  += cp.dot(P_A2.T, P_B2)
                                if need_on:
                                    acc[j]['on']['Obs']  += cp.dot(O_A.T, O_B)
                                    acc[j]['on']['E']    += cp.dot(Q_A.T, Q_B)
                                    acc[j]['on']['E2']   += cp.dot(Q_A2.T, Q_B2)
                                if need_both:
                                    acc[j]['both']['Obs'] += cp.dot(M_A.T, M_B) + cp.dot(O_A.T, O_B)
                                    acc[j]['both']['E']   += cp.dot(P_A.T, P_B)  + cp.dot(Q_A.T, Q_B)
                                    acc[j]['both']['E2']  += cp.dot(P_A2.T, P_B2) + cp.dot(Q_A2.T, Q_B2)

                                del M_B, O_B, P_B, Q_B, P_B2, Q_B2


                        del M_A, O_A, P_A, Q_A, P_A2, Q_A2
                        del data_gpu, indices_gpu, indptr_gpu, chunk_gpu, tis_chunk
                        cp.get_default_memory_pool().free_all_blocks()
                        if hasattr(cp, 'get_default_pinned_memory_pool'):
                            cp.get_default_pinned_memory_pool().free_all_blocks()

                    del active_payload
                    active_payload = device.get_prefetched_chunk()

            finally:

                device.shutdown()


            with h5py.File(temp_h5_file, 'a') as f_temp:
                for j, s_j, e_j, _ in j_ranges:
                    for m in methods:
                        f_temp[f'Obs_{m}'][start_i:end_i, s_j:e_j] = acc[j][m]['Obs'].get()
                        f_temp[f'E_{m}'][start_i:end_i,   s_j:e_j] = acc[j][m]['E'].get()
                        f_temp[f'E2_{m}'][start_i:end_i,  s_j:e_j] = acc[j][m]['E2'].get()


            del acc
            cp.get_default_memory_pool().free_all_blocks()

        print(f"\n  > COMPLETE")


        print("Coexpression - Phase 3: Variance and Z-score computation")

        adata_in = anndata.read_h5ad(raw_filename, backed='r')
        if data_path == 'raw/X' and hasattr(adata_in, 'raw') and adata_in.raw is not None:
            filtered_var = adata_in.raw.var[mask_cpu]
        else:
            filtered_var = adata_in.var[mask_cpu]

        if os.path.exists(out_filename):
            adata_out = anndata.read_h5ad(out_filename)
            adata_out.var = filtered_var
        else:
            adata_out = anndata.AnnData(var=filtered_var)

        adata_out.write_h5ad(out_filename, compression=None)

        with h5py.File(out_filename, 'a') as f_out:
            if 'varp' not in f_out:
                f_out.create_group('varp')

            for m in methods:
                ds = f'Z_{m}'
                if ds in f_out['varp']:
                    del f_out['varp'][ds]
                f_out['varp'].create_dataset(
                    ds,
                    shape=(ng_filtered, ng_filtered),
                    chunks=(BLOCK_SIZE, BLOCK_SIZE),
                    dtype='float64',
                )

            with h5py.File(temp_h5_file, 'r') as f_temp:
                for i in range(num_blocks):
                    start_i = i * BLOCK_SIZE
                    end_i   = min(start_i + BLOCK_SIZE, ng_filtered)

                    for j in range(i, num_blocks):
                        start_j = j * BLOCK_SIZE
                        end_j   = min(start_j + BLOCK_SIZE, ng_filtered)

                        for m in methods:

                            Obs_gpu = cp.asarray(
                                f_temp[f'Obs_{m}'][start_i:end_i, start_j:end_j],
                                dtype=cp.float64
                            )
                            E_gpu   = cp.asarray(
                                f_temp[f'E_{m}'][start_i:end_i,  start_j:end_j],
                                dtype=cp.float64
                            )
                            E2_gpu  = cp.asarray(
                                f_temp[f'E2_{m}'][start_i:end_i, start_j:end_j],
                                dtype=cp.float64
                            )

                            V_gpu = cp.maximum(E_gpu - E2_gpu, cp.float64(1e-12))
                            Z_gpu = (Obs_gpu - E_gpu) / cp.sqrt(V_gpu)

                            if i == j:
                                cp.fill_diagonal(Z_gpu, cp.float64(0.0))

                            Z_cpu = Z_gpu.get()
                            f_out['varp'][f'Z_{m}'][start_i:end_i, start_j:end_j] = Z_cpu
                            if i != j:
                                f_out['varp'][f'Z_{m}'][start_j:end_j, start_i:end_i] = Z_cpu.T

                            del Obs_gpu, E_gpu, E2_gpu, V_gpu, Z_gpu

        print("  > COMPLETE")

    finally:

        if os.path.exists(temp_h5_file):
            os.remove(temp_h5_file)

    print(f"\nTotal Module time: {time.perf_counter() - start_time:.2f} seconds.")


_COEX_METHOD_MAP = {
    0: ["off", "on", "both"],
    1: ["off"],
    2: ["on"],
    3: ["both"],
}

_COEX_METHOD_LABELS = {
    0: "ALL (Z_off + Z_on + Z_both)",
    1: "Co-Dropout (Z_off)",
    2: "Co-Expression (Z_on)",
    3: "Combined (Z_both)  [default]",
}


def RunCoexpressionGPU(raw_data,
                 output_dir=None,
                 method=3,
                 manual_payload=None,
                 block_data=None):

    if not isinstance(raw_data, str):
        raise TypeError(
            f"raw_data must be a string path. Got: {type(raw_data).__name__}"
        )

    if not os.path.exists(raw_data):
        raise FileNotFoundError(
            f"Input file not found: '{raw_data}'. "
            f"Check the path and your current working directory."
        )

    if method not in _COEX_METHOD_MAP:
        raise ValueError(
            f"method must be 0 (all), 1 (off), 2 (on), or 3 (both). "
            f"Got: {method}"
        )

    if manual_payload is not None:
        if not isinstance(manual_payload, int) or manual_payload <= 0:
            raise ValueError(
                f"manual_payload must be a positive integer (MB) or None. "
                f"Got: {manual_payload}"
            )

    if block_data is not None and not isinstance(block_data, dict):
        raise TypeError(
            f"block_data must be a dict from RunComputeBlockGPU() or None. "
            f"Got: {type(block_data).__name__}"
        )


    methods_list = _COEX_METHOD_MAP[method]


    raw_data_abs = os.path.abspath(raw_data)
    input_folder = os.path.dirname(raw_data_abs)

    if output_dir is None:
        output_dir = input_folder
    else:
        output_dir = os.path.abspath(output_dir)
        os.makedirs(output_dir, exist_ok=True)

    basename = os.path.basename(raw_data_abs)
    if basename.lower().endswith('.h5ad'):
        basename = basename[:-5]

    output_h5ad = os.path.join(output_dir, f"{basename}_coexpression.h5ad")


    if manual_payload is None:
        mode          = "auto"
        manual_target = 2048
    else:
        mode          = "manual"
        manual_target = manual_payload


    print(f"\n{'#'*60}")
    print(f"   RunCoexpressionGPU()")
    print(f"   Input:       {raw_data_abs}")
    print(f"   Output dir:  {output_dir}")
    print(f"   Method:      {method}  ({_COEX_METHOD_LABELS[method]})")
    print(f"   Mode:        {mode.upper()}"
          + (f"  (payload: {manual_target} MB)" if mode == "manual" else ""))
    print(f"   Block data:  {'provided (reused)' if block_data is not None else 'computed internally'}")
    print(f"{'#'*60}")


    if block_data is None:
        data_path, var_path = detect_data_path(raw_data_abs)
        if data_path == 'unknown':
            raise ValueError(
                f"None of 'raw/X', 'layers/counts', or 'X' found in '{raw_data}'. "
                f"File may be corrupted or not a valid .h5ad."
            )


        block_data = ComputeBlockA(
            raw_filename=raw_data_abs,
            calc_djs=False,
            mode=mode,
            manual_target=manual_target,
            data_path=data_path,
            var_path=var_path,
        )
    else:
        required_keys = ['mask', 'sizes', 'tjs', 'tis', 'total', 'indptr',
                         'nc', 'ng']
        missing = [k for k in required_keys if k not in block_data]
        if missing:
            raise ValueError(
                f"block_data is missing required keys for Coexpression: "
                f"{missing}. Pass a block prepared via RunComputeBlockGPU()."
            )


    NBumiCoexpressionGPU(
        raw_filename=raw_data_abs,
        out_filename=output_h5ad,
        block_data=block_data,
        methods=methods_list,
        mode=mode,
        manual_target=manual_target,
    )

    print(f"\n>>> RunCoexpressionGPU complete.")
    print(f">>> Output: {output_h5ad}")
    return output_h5ad