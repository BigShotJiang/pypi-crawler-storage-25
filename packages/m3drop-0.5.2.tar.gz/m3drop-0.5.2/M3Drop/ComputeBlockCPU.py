
import os
import sys
import time

import numpy as np
import h5py
import pandas as pd
import statsmodels.api as sm

import scipy.sparse as sps

try:
    import numba as nb
    from numba import njit, prange
except ImportError:
    raise ImportError("CRITICAL ERROR: numba not found.  Install with `pip install numba`.")

from .ControlDeviceCPU import ControlDevice


def detect_data_path(filename: str):
    if not os.path.exists(filename):
        return 'unknown', 'unknown'
    try:
        with h5py.File(filename, 'r') as f:
            if 'raw' in f and 'X' in f['raw']:
                return 'raw/X', 'raw/var'
            elif 'layers' in f and 'counts' in f['layers']:
                return 'layers/counts', 'var'
            elif 'X' in f:
                return 'X', 'var'
            else:
                return 'unknown', 'unknown'
    except Exception:
        return 'unknown', 'unknown'


@njit(cache=True, fastmath=False, boundscheck=False)
def _fused_csr_accumulation_numba(
    data,
    indices,
    indptr,
    tis,
    tjs,
    sum_x_sq,
    sum_x_ti,
    gene_non_zeros,
    num_rows,
    calc_djs,
):
    for row in range(num_rows):
        start    = indptr[row]
        end      = indptr[row + 1]
        local_ti = 0.0

        for i in range(start, end):
            local_ti += data[i]
        tis[row] = local_ti

        for i in range(start, end):
            col = indices[i]
            val = data[i]
            tjs[col]      += val
            sum_x_sq[col] += val * val
            sum_x_ti[col] += val * local_ti
            if calc_djs == 1 and val > 0.0:
                gene_non_zeros[col] += 1


@njit(cache=True, parallel=True, fastmath=False, boundscheck=False)
def _fused_dropout_accumulation_numba(
    tis,
    tjs,
    exp_sizes,
    row_ps,
    row_p_var,
    total,
    num_rows,
    num_genes,
):
    for col in prange(num_genes):
        tj       = tjs[col]
        exp_size = exp_sizes[col]

        col_sum_p   = 0.0
        col_sum_var = 0.0

        for row in range(num_rows):
            ti   = tis[row]
            mu   = (tj * ti) / total
            base = (mu / exp_size) + 1.0
            if base < 1e-12:
                base = 1e-12

            p = base ** (-exp_size)

            if np.isnan(p):
                p = 0.0
            elif np.isinf(p):
                p = 1.0 if p > 0.0 else 0.0

            col_sum_p   += p
            col_sum_var += (p - (p * p))

        row_ps[col]    += col_sum_p
        row_p_var[col] += col_sum_var


def CalculateExpectedDropoutsCPU(
    raw_filename: str,
    exp_size_cpu: np.ndarray,
    block_a_data: dict,
    mode: str = "auto",
    manual_target: int = 3000,
    custom_tis_val: float = None,
) -> dict:
    start_time = time.perf_counter()

    nc        = block_a_data['nc']
    ng        = block_a_data['ng']
    total     = float(block_a_data['total'])
    data_path = block_a_data.get('data_path', 'X')

    tjs_cpu      = np.asarray(block_a_data['tjs'], dtype=np.float64)
    exp_size_arr = np.asarray(exp_size_cpu,        dtype=np.float64)

    row_ps    = np.zeros(ng, dtype=np.float64)
    row_p_var = np.zeros(ng, dtype=np.float64)

    if custom_tis_val is None:
        tis_full = np.asarray(block_a_data['tis'], dtype=np.float64)


    dummy_indptr = np.zeros(2, dtype=np.int32)
    device = ControlDevice(
        indptr=dummy_indptr, total_rows=nc, n_genes=ng,
        mode=mode, manual_target=manual_target, data_path=data_path
    )

    bytes_per_row = ng * 8

    if mode == "manual" and manual_target > 0:
        active_target_bytes = manual_target * 1024 * 1024
    else:
        active_target_bytes = device.payload_dense_target_bytes

    safe_chunk_rows = int(active_target_bytes / bytes_per_row)

    mem_cost_per_chunk = safe_chunk_rows * bytes_per_row
    if mem_cost_per_chunk > device.working_mem_budget_bytes:
        safe_chunk_rows = int(device.working_mem_budget_bytes / bytes_per_row)

    if safe_chunk_rows < 1:
        safe_chunk_rows = 1

    curr_row = 0
    while curr_row < nc:
        end_row    = min(curr_row + safe_chunk_rows, nc)
        chunk_size = end_row - curr_row

        if custom_tis_val is not None:
            tis_chunk = np.full(chunk_size, float(custom_tis_val), dtype=np.float64)
        else:
            tis_chunk = np.ascontiguousarray(
                tis_full[curr_row:end_row], dtype=np.float64
            )

        _fused_dropout_accumulation_numba(
            tis_chunk, tjs_cpu, exp_size_arr,
            row_ps, row_p_var,
            float(total), np.int64(chunk_size), np.int64(ng),
        )

        curr_row = end_row
        print(
            f"  > Processing {end_row} of {nc} | Payload: {chunk_size} rows{' ' * 15}",
            end='\r'
        )

    print(f"\n  > COMPLETE")
    return {
        'expected_dropouts':     row_ps,
        'expected_dropouts_var': row_p_var,
    }


def ComputeBlockA(
    raw_filename:  str,
    calc_djs:      bool = False,
    mode:          str  = "auto",
    manual_target: int  = 3000,
    data_path:     str  = 'X',
    var_path:      str  = 'var',
) -> dict:
    start_time = time.perf_counter()
    print(f"\nFUNCTION: ComputeBlockA() | FILE: {raw_filename}")

    with h5py.File(raw_filename, 'r') as f:
        indptr_cpu = f[data_path]['indptr'][:]
        total_rows = len(indptr_cpu) - 1
        raw_ng     = (f[data_path].attrs['shape'][1]
                      if 'shape' in f[data_path].attrs
                      else len(f[var_path]))

    device = ControlDevice(
        indptr=indptr_cpu, total_rows=total_rows, n_genes=raw_ng,
        mode=mode, manual_target=manual_target, data_path=data_path
    )
    nc = device.total_rows

    print("Compute Block A - Phase 1: Single-Pass Core Statistics")

    tis_cpu_full       = np.zeros(nc,     dtype=np.float64)
    tjs_total          = np.zeros(raw_ng, dtype=np.float64)
    sum_x_sq_total     = np.zeros(raw_ng, dtype=np.float64)
    sum_x_ti_total     = np.zeros(raw_ng, dtype=np.float64)
    gene_non_zeros_tot = (np.zeros(raw_ng, dtype=np.int64)
                          if calc_djs else np.zeros(1, dtype=np.int64))
    calc_djs_int       = np.int64(1 if calc_djs else 0)

    try:
        device.start_prefetcher(raw_filename, fetch_mode='sparse',
                                overhead_multiplier=1.1)
        active_payload = device.get_prefetched_chunk()

        while active_payload is not None:
            nnz        = active_payload['nnz']
            chunk_size = active_payload['rows'] - 1
            curr_row   = active_payload['curr_row']
            next_row   = active_payload['next_row']

            if nnz > 0:


                data_f64 = np.asarray(active_payload['data'], dtype=np.float64)
                np.ceil(data_f64, out=data_f64)
                indices_arr = np.asarray(active_payload['indices'])
                indptr_arr  = np.asarray(active_payload['indptr'])

                tis_chunk = np.zeros(chunk_size, dtype=np.float64)

                _fused_csr_accumulation_numba(
                    data_f64, indices_arr, indptr_arr,
                    tis_chunk,
                    tjs_total, sum_x_sq_total, sum_x_ti_total,
                    gene_non_zeros_tot,
                    np.int64(chunk_size), calc_djs_int,
                )

                tis_cpu_full[curr_row:next_row] = tis_chunk


                _rb = active_payload.get('read_bytes', 0)
                ssd_ram_mb = _rb / (1024 ** 2)

                print(
                    f"  > Processing {next_row} of {nc} | "
                    f"Payload: {next_row - curr_row} rows | "
                    f"SSD-RAM: {ssd_ram_mb:.1f} MB{' ' * 15}",
                    end='\r'
                )

            active_payload = device.get_prefetched_chunk()

        print(f"\n  > COMPLETE")

    finally:
        device.shutdown()


    mask_cpu    = tjs_total > 0
    ng_filtered = int(np.sum(mask_cpu))

    tjs      = np.ascontiguousarray(tjs_total[mask_cpu],    dtype=np.float64)
    sum_x_sq = np.ascontiguousarray(sum_x_sq_total[mask_cpu], dtype=np.float64)
    sum_x_ti = np.ascontiguousarray(sum_x_ti_total[mask_cpu], dtype=np.float64)

    total_reads       = float(np.sum(tjs))
    sum_tis_sq_scalar = float(np.sum(tis_cpu_full ** 2))

    djs_cpu = None
    if calc_djs:
        gene_nz_filt = gene_non_zeros_tot[mask_cpu]
        djs_cpu      = (nc - gene_nz_filt).astype(np.int64)

    print("Compute Block A - Phase 2: Empirical Dispersion Derivation")


    sum_2xmu   = 2.0 * (tjs / total_reads) * sum_x_ti
    sum_mu_sq  = (tjs ** 2 / total_reads ** 2) * sum_tis_sq_scalar
    sum_sq_dev = sum_x_sq - sum_2xmu + sum_mu_sq


    numerator   = (tjs ** 2 / total_reads ** 2) * sum_tis_sq_scalar
    denominator = sum_sq_dev - tjs

    with np.errstate(divide='ignore', invalid='ignore'):
        size_raw = numerator / denominator

    clamp_mask = ~(np.isfinite(size_raw) & (size_raw > 0))


    stable_sizes = size_raw[~clamp_mask]
    if stable_sizes.size > 0:
        max_size_val = np.float64(10.0) * np.float64(np.max(stable_sizes))
    else:
        max_size_val = np.float64(1e10)

    sizes = np.where(clamp_mask, max_size_val, size_raw).astype(np.float64, copy=False)


    sizes = np.where(sizes < np.float64(1e-10), np.float64(1e-10), sizes
                     ).astype(np.float64, copy=False)

    end_time = time.perf_counter()
    print(f"\nTotal time: {end_time - start_time:.2f} seconds.")

    return {
        "mask":       mask_cpu,
        "nc":         nc,
        "ng":         ng_filtered,
        "total":      total_reads,
        "tjs":        tjs,
        "sizes":      sizes,
        "size_raw":   size_raw,
        "clamp_mask": clamp_mask,
        "max_size":   float(max_size_val),
        "djs":        djs_cpu,
        "tis":        tis_cpu_full,
        "indptr":     indptr_cpu,
        "data_path":  data_path,
        "var_path":   var_path,
    }


def ComputeBlockB(
    raw_filename:  str,
    block_a_data:  dict,
    mode:          str = "auto",
    manual_target: int = 3000,
) -> dict:
    start_time = time.perf_counter()
    print(f"\nFUNCTION: ComputeBlockB()")

    print("Compute Block B - Phase 1: Mean-Dispersion Regression")
    nc    = block_a_data['nc']
    tjs   = np.asarray(block_a_data['tjs'],   dtype=np.float64)
    sizes = np.asarray(block_a_data['sizes'], dtype=np.float64)

    mean_expression = (tjs / nc).astype(np.float64, copy=False)


    clamp_mask = block_a_data.get('clamp_mask')
    if clamp_mask is not None:
        forfit = (~clamp_mask) & (mean_expression > 1e-3)
    else:

        forfit = np.isfinite(sizes) & (sizes > 0) & (mean_expression > 1e-3)

    with np.errstate(divide='ignore'):
        log2_mean_expr = np.log2(mean_expression, where=(mean_expression > 0))
    higher = log2_mean_expr > 4
    if np.sum(higher & forfit) > 2000:
        forfit = higher & forfit

    y = np.log(sizes[forfit])
    x = np.log(mean_expression[forfit])

    X      = sm.add_constant(x)
    model  = sm.OLS(y, X).fit()
    coeffs = model.params

    with np.errstate(divide='ignore'):
        log_mean_expression = np.log(mean_expression)
        log_mean_expression[np.isneginf(log_mean_expression)] = 0
        exp_size = np.exp(coeffs[0] + coeffs[1] * log_mean_expression
                          ).astype(np.float64, copy=False)

    block_a_data['exp_size']          = exp_size
    block_a_data['regression_coeffs'] = coeffs

    print("Compute Block B - Phase 2: Expected Dropouts and Variance")
    dropout_data = CalculateExpectedDropoutsCPU(
        raw_filename=raw_filename,
        exp_size_cpu=exp_size,
        block_a_data=block_a_data,
        mode=mode,
        manual_target=manual_target,
    )

    block_a_data['expected_dropouts']     = dropout_data['expected_dropouts']
    block_a_data['expected_dropouts_var'] = dropout_data['expected_dropouts_var']

    end_time = time.perf_counter()
    print(f"\nTotal time: {end_time - start_time:.2f} seconds.")
    return block_a_data


def RunComputeBlockCPU(raw_data, manual_payload=None):
    if not isinstance(raw_data, str):
        raise TypeError(
            f"raw_data must be a string path. Got: {type(raw_data).__name__}"
        )
    if not os.path.exists(raw_data):
        raise FileNotFoundError(
            f"Input file not found: '{raw_data}'. "
            f"Check the path and your current working directory."
        )
    if manual_payload is not None:
        if not isinstance(manual_payload, int) or manual_payload <= 0:
            raise ValueError(
                f"manual_payload must be a positive integer (MB) or None. "
                f"Got: {manual_payload}"
            )

    if manual_payload is None:
        mode          = "auto"
        manual_target = 2048
    else:
        mode          = "manual"
        manual_target = manual_payload

    data_path, var_path = detect_data_path(raw_data)
    if data_path == 'unknown':
        raise ValueError(
            f"None of 'raw/X', 'layers/counts', or 'X' found in '{raw_data}'. "
            f"File may be corrupted or not a valid .h5ad."
        )

    raw_data_abs = os.path.abspath(raw_data)

    print(f"\n{'#'*60}")
    print(f"   RunComputeBlockCPU()")
    print(f"   Input: {raw_data_abs}")
    print(f"   Mode:  {mode.upper()}"
          + (f"  (payload: {manual_target} MB)" if mode == "manual" else ""))
    print(f"{'#'*60}")

    block_data = ComputeBlockA(
        raw_filename=raw_data_abs,
        calc_djs=True,
        mode=mode,
        manual_target=manual_target,
        data_path=data_path,
        var_path=var_path,
    )

    block_data = ComputeBlockB(
        raw_filename=raw_data_abs,
        block_a_data=block_data,
        mode=mode,
        manual_target=manual_target,
    )

    print(">>> RunComputeBlockCPU complete. Block ready for any module.")
    return block_data
