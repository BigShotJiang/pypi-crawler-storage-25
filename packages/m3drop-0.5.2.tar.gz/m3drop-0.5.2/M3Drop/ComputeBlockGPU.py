import time
import os
import h5py
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys

try:
    import cupy as cp
    from cupy.sparse import csr_matrix as cp_csr_matrix
except ImportError:
    raise ImportError("WARNING: CuPy not found. This script requires a GPU.")

from .ControlDeviceGPU import ControlDevice


def detect_data_path(filename: str):
    if not os.path.exists(filename):
        return 'unknown', 'unknown'
    try:
        with h5py.File(filename, 'r') as f:
            if 'raw' in f and 'X' in f['raw']:
                return 'raw/X', 'raw/var'
            elif 'layers' in f and 'counts' in f['layers']:
                return 'layers/counts', 'var'
            elif 'X' in f:
                return 'X', 'var'
            else:
                return 'unknown', 'unknown'
    except Exception:
        return 'unknown', 'unknown'


fused_csr_accumulation_kernel = cp.RawKernel(r'''
extern "C" __global__
void fused_csr_accumulation(
    const double* data,
    const int* indices,
    const int* indptr,
    double* tis,
    double* tjs,
    double* sum_x_sq,
    double* sum_x_ti,
    int* gene_non_zeros,
    int num_rows,
    int calc_djs
) {
    int row = blockDim.x * blockIdx.x + threadIdx.x;
    if (row < num_rows) {
        int start = indptr[row];
        int end = indptr[row + 1];
        
        double local_ti = 0.0;
        
        for (int i = start; i < end; i++) {
            local_ti += data[i];
        }
        tis[row] = local_ti;

        for (int i = start; i < end; i++) {
            int col = indices[i];
            double val = data[i];

            atomicAdd(&tjs[col], val);
            atomicAdd(&sum_x_sq[col], val * val);
            atomicAdd(&sum_x_ti[col], val * local_ti);

            if (calc_djs > 0 && val > 0.0) {
                atomicAdd(&gene_non_zeros[col], 1);
            }
        }
    }
}
''', 'fused_csr_accumulation')


fused_dropout_kernel = cp.RawKernel(r'''
extern "C" __global__
void fused_dropout_accumulation(
    const double* tis,
    const double* tjs,
    const double* exp_sizes,
    double* row_ps_gpu,
    double* row_p_var_gpu,
    double total,
    int num_rows,
    int num_genes
) {
    int col = blockDim.x * blockIdx.x + threadIdx.x;
    
    // Each thread handles exactly one gene, eliminating atomic conflicts
    if (col < num_genes) {
        double tj = tjs[col];
        double exp_size = exp_sizes[col];
        
        // Accumulate in fast thread registers
        double col_sum_p = 0.0;
        double col_sum_var = 0.0;
        
        for (int row = 0; row < num_rows; row++) {
            double ti = tis[row];
            double mu = (tj * ti) / total;
            double base = (mu / exp_size) + 1.0;
            if (base < 1e-12) base = 1e-12;
            
            double p = pow(base, -exp_size);
            
            if (isnan(p)) p = 0.0;
            else if (isinf(p)) p = (p > 0.0) ? 1.0 : 0.0;
            
            col_sum_p += p;
            col_sum_var += (p - (p * p));
        }
        
        // Direct write to global memory (no atomicAdd required)
        row_ps_gpu[col] += col_sum_p;
        row_p_var_gpu[col] += col_sum_var;
    }
}
''', 'fused_dropout_accumulation')


def CalculateExpectedDropoutsGPU(
    raw_filename: str,
    exp_size_cpu: np.ndarray,
    block_a_data: dict,
    mode: str = "auto",
    manual_target: int = 3000,
    custom_tis_val: float = None
) -> dict:
    start_time = time.perf_counter()

    nc       = block_a_data['nc']
    ng       = block_a_data['ng']
    total    = block_a_data['total']
    data_path = block_a_data.get('data_path', 'X')

    tjs_gpu      = cp.asarray(block_a_data['tjs'], dtype=cp.float64)
    exp_size_gpu = cp.asarray(exp_size_cpu,        dtype=cp.float64)

    row_ps_gpu    = cp.zeros(ng, dtype=cp.float64)
    row_p_var_gpu = cp.zeros(ng, dtype=cp.float64)

    if custom_tis_val is None:
        tis_full_cpu = block_a_data['tis']

    dummy_indptr = np.zeros(2, dtype=np.int32)
    device = ControlDevice(
        indptr=dummy_indptr, total_rows=nc, n_genes=ng,
        mode=mode, manual_target=manual_target, data_path=data_path
    )


    bytes_per_row = ng * 8

    if mode == "manual" and manual_target > 0:
        active_target_bytes = manual_target * 1024 * 1024
    else:
        active_target_bytes = device.pcie_dense_target_bytes

    safe_chunk_rows = int(active_target_bytes / bytes_per_row)

    vram_cost_per_chunk = safe_chunk_rows * bytes_per_row
    if vram_cost_per_chunk > device.vram_budget_bytes:
        safe_chunk_rows = int(device.vram_budget_bytes / bytes_per_row)

    if safe_chunk_rows < 1:
        safe_chunk_rows = 1

    curr_row          = 0
    threads_per_block = 256
    blocks_per_grid   = (ng + threads_per_block - 1) // threads_per_block


    _ev_sync = cp.cuda.Event()

    while curr_row < nc:
        end_row    = min(curr_row + safe_chunk_rows, nc)
        chunk_size = end_row - curr_row

        if custom_tis_val is not None:
            tis_chunk_gpu = cp.full(chunk_size, custom_tis_val, dtype=cp.float64)
        else:
            tis_chunk_gpu = cp.asarray(tis_full_cpu[curr_row:end_row], dtype=cp.float64)

        fused_dropout_kernel(
            (blocks_per_grid,), (threads_per_block,),
            (tis_chunk_gpu, tjs_gpu, exp_size_gpu, row_ps_gpu, row_p_var_gpu,
             total, chunk_size, ng)
        )
        _ev_sync.record()
        _ev_sync.synchronize()

        del tis_chunk_gpu
        curr_row = end_row

        print(
            f"  > Processing {end_row} of {nc} | Payload: {chunk_size} rows{' ' * 15}",
            end='\r'
        )

    print(f"\n  > COMPLETE")
    return {
        'expected_dropouts':     cp.asnumpy(row_ps_gpu),
        'expected_dropouts_var': cp.asnumpy(row_p_var_gpu)
    }


def ComputeBlockA(
    raw_filename: str,
    calc_djs: bool = False,
    mode: str = "auto",
    manual_target: int = 3000,
    data_path: str = 'X',
    var_path: str = 'var'
) -> dict:
    start_time = time.perf_counter()
    print(f"\nFUNCTION: ComputeBlockA() | FILE: {raw_filename}")

    with h5py.File(raw_filename, 'r') as f:
        indptr_cpu = f[data_path]['indptr'][:]
        total_rows = len(indptr_cpu) - 1
        raw_ng     = (f[data_path].attrs['shape'][1]
                      if 'shape' in f[data_path].attrs
                      else len(f[var_path]))

    device = ControlDevice(
        indptr=indptr_cpu, total_rows=total_rows, n_genes=raw_ng,
        mode=mode, manual_target=manual_target, data_path=data_path
    )
    nc = device.total_rows


    print("Compute Block A - Phase 1: Single-Pass Core Statistics")

    tis_cpu_full = np.zeros(nc, dtype=np.float64)

    tjs_gpu_raw    = [cp.zeros(raw_ng, dtype=cp.float64),
                      cp.zeros(raw_ng, dtype=cp.float64)]
    sum_x_sq_gpu_raw = [cp.zeros(raw_ng, dtype=cp.float64),
                        cp.zeros(raw_ng, dtype=cp.float64)]
    sum_x_ti_gpu_raw = [cp.zeros(raw_ng, dtype=cp.float64),
                        cp.zeros(raw_ng, dtype=cp.float64)]
    gene_non_zeros_gpu = ([cp.zeros(raw_ng, dtype=cp.int32),
                           cp.zeros(raw_ng, dtype=cp.int32)]
                          if calc_djs else [None, None])
    dummy_int32 = cp.zeros(1, dtype=cp.int32)

    streams      = [cp.cuda.Stream(non_blocking=True),
                    cp.cuda.Stream(non_blocking=True)]
    start_events = [cp.cuda.Event(), cp.cuda.Event()]
    end_events   = [cp.cuda.Event(), cp.cuda.Event()]

    pending_tis           = [None, None]
    pending_bounds        = [(0, 0), (0, 0)]
    pending_bytes         = [0, 0]
    pending_read_seconds  = [0.0, 0.0]
    pending_read_bytes    = [0, 0]
    pending_cleanup       = [None, None]
    active_payloads       = [None, None]

    try:
        device.start_prefetcher(raw_filename, fetch_mode='sparse',
                                overhead_multiplier=1.1)
        active_payloads[0] = device.get_prefetched_chunk()

        idx = 0
        while active_payloads[idx] is not None:
            payload    = active_payloads[idx]
            nnz        = payload['nnz']
            chunk_size = payload['rows'] - 1
            curr_row   = payload['curr_row']
            next_row   = payload['next_row']

            if nnz > 0:
                pending_bytes[idx]        = (nnz * 12) + (payload['rows'] * 4)
                pending_read_seconds[idx] = payload.get('read_seconds', 0.0)
                pending_read_bytes[idx]   = payload.get('read_bytes',   0)

                start_events[idx].record(streams[idx])

                data_gpu_native = cp.empty(nnz, dtype=payload['data'].dtype)
                indices_gpu     = cp.empty(nnz, dtype=payload['indices'].dtype)
                indptr_gpu      = cp.empty(payload['rows'], dtype=payload['indptr'].dtype)

                data_gpu_native.set(payload['data'],    stream=streams[idx])
                indices_gpu.set(payload['indices'],     stream=streams[idx])
                indptr_gpu.set(payload['indptr'],       stream=streams[idx])

                with streams[idx]:
                    data_gpu = data_gpu_native.astype(cp.float64, copy=False)
                    cp.ceil(data_gpu, out=data_gpu)

                    end_events[idx].record(streams[idx])

                    chunk_gpu = cp_csr_matrix(
                        (data_gpu, indices_gpu, indptr_gpu),
                        shape=(chunk_size, raw_ng)
                    )

                    tis_chunk_gpu = cp.zeros(chunk_size, dtype=cp.float64)

                    threads_per_block = 256
                    blocks_per_grid   = (chunk_size + threads_per_block - 1) // threads_per_block

                    ptr_gene_non_zeros = gene_non_zeros_gpu[idx] if calc_djs else dummy_int32
                    calc_djs_flag      = 1 if calc_djs else 0

                    fused_csr_accumulation_kernel(
                        (blocks_per_grid,), (threads_per_block,),
                        (chunk_gpu.data, chunk_gpu.indices, chunk_gpu.indptr,
                         tis_chunk_gpu,
                         tjs_gpu_raw[idx], sum_x_sq_gpu_raw[idx],
                         sum_x_ti_gpu_raw[idx],
                         ptr_gene_non_zeros, chunk_size, calc_djs_flag)
                    )

                    pending_tis[idx]    = tis_chunk_gpu
                    pending_bounds[idx] = (curr_row, next_row)


                pending_cleanup[idx] = [data_gpu_native, indices_gpu,
                                        indptr_gpu, data_gpu, chunk_gpu]

            next_idx = 1 - idx


            active_payloads[idx] = None
            del payload

            active_payloads[next_idx] = device.get_prefetched_chunk()
            streams[next_idx].synchronize()


            pending_cleanup[next_idx] = None

            if pending_tis[next_idx] is not None:
                r_start, r_end = pending_bounds[next_idx]
                tis_cpu_full[r_start:r_end] = pending_tis[next_idx].get()
                pending_tis[next_idx] = None

                elapsed_ms = cp.cuda.get_elapsed_time(
                    start_events[next_idx], end_events[next_idx]
                )
                if elapsed_ms > 0:
                    ssd_ram_mb  = pending_read_bytes[next_idx] / (1024 ** 2)
                    ram_vram_mb = pending_bytes[next_idx]      / (1024 ** 2)
                    print(
                        f"  > Processing {r_end} of {nc} | "
                        f"Payload: {r_end - r_start} rows | "
                        f"SSD-RAM: {ssd_ram_mb:.1f} MB | "
                        f"RAM-VRAM: {ram_vram_mb:.1f} MB{' ' * 15}",
                        end='\r'
                    )

            idx = next_idx

        streams[0].synchronize()
        streams[1].synchronize()


        pending_cleanup[0] = None
        pending_cleanup[1] = None

        for i in range(2):
            if pending_tis[i] is not None:
                r_start, r_end = pending_bounds[i]
                tis_cpu_full[r_start:r_end] = pending_tis[i].get()

                elapsed_ms = cp.cuda.get_elapsed_time(start_events[i], end_events[i])
                if elapsed_ms > 0:
                    ssd_ram_mb  = pending_read_bytes[i] / (1024 ** 2)
                    ram_vram_mb = pending_bytes[i]      / (1024 ** 2)
                    print(
                        f"  > Processing {r_end} of {nc} | "
                        f"Payload: {r_end - r_start} rows | "
                        f"SSD-RAM: {ssd_ram_mb:.1f} MB | "
                        f"RAM-VRAM: {ram_vram_mb:.1f} MB{' ' * 15}",
                        end='\r'
                    )

        print(f"\n  > COMPLETE")

    finally:
        device.shutdown()

    tjs_gpu_raw_total    = tjs_gpu_raw[0]    + tjs_gpu_raw[1]
    sum_x_sq_gpu_total   = sum_x_sq_gpu_raw[0] + sum_x_sq_gpu_raw[1]
    sum_x_ti_gpu_total   = sum_x_ti_gpu_raw[0] + sum_x_ti_gpu_raw[1]

    mask_gpu    = tjs_gpu_raw_total > 0
    mask_cpu    = cp.asnumpy(mask_gpu)
    ng_filtered = int(cp.sum(mask_gpu))

    tjs_gpu      = tjs_gpu_raw_total[mask_gpu]
    sum_x_sq_gpu = sum_x_sq_gpu_total[mask_gpu]
    sum_x_ti_gpu = sum_x_ti_gpu_total[mask_gpu]

    total_reads      = float(cp.sum(tjs_gpu))
    sum_tis_sq_scalar = float(np.sum(tis_cpu_full ** 2))

    djs_cpu = None
    if calc_djs:
        gene_non_zeros_total = gene_non_zeros_gpu[0] + gene_non_zeros_gpu[1]
        gene_non_zeros_total = gene_non_zeros_total[mask_gpu]
        djs_cpu = cp.asnumpy(nc - gene_non_zeros_total)


    cp.get_default_memory_pool().free_all_blocks()

    print("Compute Block A - Phase 2: Empirical Dispersion Derivation")
    sum_2xmu_gpu    = 2.0 * (tjs_gpu / total_reads) * sum_x_ti_gpu
    sum_mu_sq_gpu   = (tjs_gpu ** 2 / total_reads ** 2) * sum_tis_sq_scalar
    sum_sq_dev_gpu  = sum_x_sq_gpu - sum_2xmu_gpu + sum_mu_sq_gpu


    numerator_gpu   = (tjs_gpu ** 2 / total_reads ** 2) * sum_tis_sq_scalar
    denominator_gpu = sum_sq_dev_gpu - tjs_gpu


    size_raw_gpu = numerator_gpu / denominator_gpu


    clamp_mask_gpu = ~(cp.isfinite(size_raw_gpu) & (size_raw_gpu > 0))


    _stable_sizes = size_raw_gpu[~clamp_mask_gpu]
    if _stable_sizes.size > 0:
        max_size_val = cp.float64(10.0) * cp.max(_stable_sizes)
    else:
        max_size_val = cp.float64(1e10)

    sizes_gpu = cp.where(clamp_mask_gpu, max_size_val, size_raw_gpu)


    sizes_gpu = cp.where(sizes_gpu < cp.float64(1e-10),
                         cp.float64(1e-10),
                         sizes_gpu)

    end_time = time.perf_counter()
    print(f"\nTotal time: {end_time - start_time:.2f} seconds.")

    return {
        "mask":       mask_cpu,
        "nc":         nc,
        "ng":         ng_filtered,
        "total":      total_reads,
        "tjs":        cp.asnumpy(tjs_gpu),
        "sizes":      cp.asnumpy(sizes_gpu),
        "size_raw":   cp.asnumpy(size_raw_gpu),
        "clamp_mask": cp.asnumpy(clamp_mask_gpu),
        "max_size":   float(max_size_val),
        "djs":        djs_cpu,
        "tis":        tis_cpu_full,
        "indptr":     indptr_cpu,
        "data_path":  data_path,
        "var_path":   var_path
    }


def ComputeBlockB(
    raw_filename: str,
    block_a_data: dict,
    mode: str = "auto",
    manual_target: int = 3000
) -> dict:
    start_time = time.perf_counter()
    print(f"\nFUNCTION: ComputeBlockB()")

    print("Compute Block B - Phase 1: Mean-Dispersion Regression")
    nc    = block_a_data['nc']
    tjs   = block_a_data['tjs']
    sizes = block_a_data['sizes']

    mean_expression = tjs / nc


    clamp_mask = block_a_data.get('clamp_mask')
    if clamp_mask is not None:
        forfit = (~clamp_mask) & (mean_expression > 1e-3)
    else:

        forfit = np.isfinite(sizes) & (sizes > 0) & (mean_expression > 1e-3)

    log2_mean_expr = np.log2(mean_expression, where=(mean_expression > 0))
    higher = log2_mean_expr > 4
    if np.sum(higher & forfit) > 2000:
        forfit = higher & forfit

    y = np.log(sizes[forfit])
    x = np.log(mean_expression[forfit])

    X      = sm.add_constant(x)
    model  = sm.OLS(y, X).fit()
    coeffs = model.params

    with np.errstate(divide='ignore'):
        log_mean_expression = np.log(mean_expression)
        log_mean_expression[np.isneginf(log_mean_expression)] = 0
        exp_size = np.exp(coeffs[0] + coeffs[1] * log_mean_expression)

    block_a_data['exp_size']          = exp_size
    block_a_data['regression_coeffs'] = coeffs

    print("Compute Block B - Phase 2: Expected Dropouts and Variance")
    dropout_data = CalculateExpectedDropoutsGPU(
        raw_filename=raw_filename,
        exp_size_cpu=exp_size,
        block_a_data=block_a_data,
        mode=mode,
        manual_target=manual_target
    )

    block_a_data['expected_dropouts']     = dropout_data['expected_dropouts']
    block_a_data['expected_dropouts_var'] = dropout_data['expected_dropouts_var']

    end_time = time.perf_counter()
    print(f"\nTotal time: {end_time - start_time:.2f} seconds.")
    return block_a_data


def RunComputeBlockGPU(raw_data, manual_payload=None):

    if not isinstance(raw_data, str):
        raise TypeError(
            f"raw_data must be a string path. Got: {type(raw_data).__name__}"
        )
    if not os.path.exists(raw_data):
        raise FileNotFoundError(
            f"Input file not found: '{raw_data}'. "
            f"Check the path and your current working directory."
        )
    if manual_payload is not None:
        if not isinstance(manual_payload, int) or manual_payload <= 0:
            raise ValueError(
                f"manual_payload must be a positive integer (MB) or None. "
                f"Got: {manual_payload}"
            )


    if manual_payload is None:
        mode          = "auto"
        manual_target = 2048
    else:
        mode          = "manual"
        manual_target = manual_payload


    data_path, var_path = detect_data_path(raw_data)
    if data_path == 'unknown':
        raise ValueError(
            f"None of 'raw/X', 'layers/counts', or 'X' found in '{raw_data}'. "
            f"File may be corrupted or not a valid .h5ad."
        )

    raw_data_abs = os.path.abspath(raw_data)


    print(f"\n{'#'*60}")
    print(f"   RunComputeBlockGPU()")
    print(f"   Input: {raw_data_abs}")
    print(f"   Mode:  {mode.upper()}"
          + (f"  (payload: {manual_target} MB)" if mode == "manual" else ""))
    print(f"{'#'*60}")


    block_data = ComputeBlockA(
        raw_filename=raw_data_abs,
        calc_djs=True,
        mode=mode,
        manual_target=manual_target,
        data_path=data_path,
        var_path=var_path,
    )


    block_data = ComputeBlockB(
        raw_filename=raw_data_abs,
        block_a_data=block_data,
        mode=mode,
        manual_target=manual_target,
    )

    print(">>> RunComputeBlockGPU complete. Block ready for any module.")
    return block_data