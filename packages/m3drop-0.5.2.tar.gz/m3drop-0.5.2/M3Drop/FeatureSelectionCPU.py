import os
import sys
import time

import numpy as np
import h5py
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests
import scipy.sparse as sps

try:
    import numba as nb
    from numba import njit, prange
except ImportError:
    raise ImportError("CRITICAL ERROR: numba not found.  Install with `pip install numba`.")

from .ControlDeviceCPU import ControlDevice
from .ComputeBlockCPU import (
    CalculateExpectedDropoutsCPU,
    ComputeBlockA,
    ComputeBlockB,
    detect_data_path,
)


@njit(cache=True, fastmath=False, boundscheck=False)
def _fused_norm_aggregate_numba(
    data,
    indices,
    indptr,
    size_factors,
    filter_idx,
    sum_norm_x,
    sum_norm_sq,
    num_rows,
):
    for row in range(num_rows):
        sf    = size_factors[row]
        if sf == 0.0:
            sf = 1.0
        start = indptr[row]
        end   = indptr[row + 1]
        for i in range(start, end):
            col_raw  = indices[i]
            col_filt = filter_idx[col_raw]
            if col_filt < 0:
                continue


            v_ceil = np.ceil(data[i])


            v_norm = round(v_ceil / sf)
            sum_norm_x[col_filt]  += v_norm
            sum_norm_sq[col_filt] += v_norm * v_norm


def FeatureSelectionHighVar(sizes: np.ndarray, exp_sizes: np.ndarray) -> np.ndarray:
    sizes     = np.asarray(sizes,     dtype=np.float64)
    exp_sizes = np.asarray(exp_sizes, dtype=np.float64)
    with np.errstate(divide='ignore', invalid='ignore'):
        log_obs = np.log(sizes)
        log_exp = np.log(exp_sizes)

        log_obs[np.isinf(log_obs) | np.isnan(log_obs)] = 0.0
        log_exp[np.isinf(log_exp) | np.isnan(log_exp)] = 0.0

        res = (log_obs - log_exp).astype(np.float64, copy=False)
    return res


def RunFeatureSelection(
    block_data:    dict,
    gene_names:    np.ndarray,
    high_var_csv:  str = "high_variance_genes.csv",
):
    start_time = time.perf_counter()
    print("\nFUNCTION: RunFeatureSelection()")

    sizes               = block_data['sizes']
    exp_sizes           = block_data['exp_size']
    filtered_gene_names = gene_names[block_data['mask']]

    print("Feature Selection - Phase 1: High Variance Residuals")
    var_residuals = FeatureSelectionHighVar(sizes, exp_sizes)

    df_var = pd.DataFrame({
        'Gene':     filtered_gene_names,
        'Residual': var_residuals,
    }).sort_values(by='Residual', ascending=True)

    df_var.to_csv(high_var_csv, index=False)

    print(f"\nTotal Module time: {time.perf_counter() - start_time:.2f} seconds.")
    return df_var


def ExportMeanDispersion(
    block_data:     dict,
    gene_names:     np.ndarray,
    mean_disp_csv:  str = "mean_dispersion.csv",
):
    print("\nFUNCTION: ExportMeanDispersion()")

    nc              = block_data['nc']
    mean_expression = (np.asarray(block_data['tjs'], dtype=np.float64) / nc
                       ).astype(np.float64, copy=False)
    sizes           = np.asarray(block_data['sizes'], dtype=np.float64)
    filtered_gene_names = gene_names[block_data['mask']]

    df = pd.DataFrame({
        'Gene':            filtered_gene_names,
        'mean_expression': mean_expression,
        'dispersion':      sizes,
    })

    df.to_csv(mean_disp_csv, index=False)
    print(f"  > Exported Mean/Dispersion: {mean_disp_csv}")

    return df


def PlotDispVsMean(
    block_data:     dict,
    plot_filename:  str  = None,
    suppress_plot:  bool = False,
):
    print("\nFUNCTION: PlotDispVsMean()")

    nc              = block_data['nc']
    mean_expression = (np.asarray(block_data['tjs'], dtype=np.float64) / nc
                       ).astype(np.float64, copy=False)
    sizes           = np.asarray(block_data['sizes'], dtype=np.float64)
    coeffs          = block_data['regression_coeffs']
    intercept, slope = coeffs[0], coeffs[1]

    log_mean_expr_range = np.linspace(
        np.log(mean_expression[mean_expression > 0].min()),
        np.log(mean_expression.max()),
        100,
    )
    fitted_sizes = np.exp(intercept + slope * log_mean_expr_range)

    clamp_mask = block_data.get('clamp_mask')
    if clamp_mask is not None:
        mask_viz = ~clamp_mask
    else:
        mask_viz = np.isfinite(sizes) & (sizes > 0)
    mean_expr_clean = mean_expression[mask_viz]
    sizes_clean     = sizes[mask_viz]

    plt.figure(figsize=(8, 6))
    plt.scatter(mean_expr_clean, sizes_clean,
                label='Observed Dispersion', alpha=0.5, s=8)
    plt.plot(np.exp(log_mean_expr_range), fitted_sizes,
             color='red', label='Regression Fit', linewidth=2)

    plt.xscale('log')
    plt.yscale('log')
    plt.xlabel('Mean Expression')
    plt.ylabel('Dispersion Parameter (Sizes)')
    plt.title('Dispersion vs. Mean Expression')
    plt.legend()
    plt.grid(True, which="both", linestyle='--', alpha=0.6)

    if plot_filename:
        plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
        print(f"Saving plot to: {plot_filename}")

    if not suppress_plot:
        plt.show()

    plt.close()


def FitBasicModelCPU(
    raw_filename:  str,
    block_data:    dict,
    mode:          str = "auto",
    manual_target: int = 3000,
):
    print("Model Diagnostics - Phase 1: Basic Model Normalization and Dispersion")

    nc          = block_data['nc']
    mask_cpu    = np.asarray(block_data['mask'])
    filtered_ng = block_data['ng']
    data_path   = block_data.get('data_path', 'X')
    var_path    = block_data.get('var_path',  'var')

    indptr_cpu = block_data['indptr']
    total_rows = len(indptr_cpu) - 1

    with h5py.File(raw_filename, 'r') as f:
        raw_ng = (f[data_path].attrs['shape'][1]
                  if 'shape' in f[data_path].attrs
                  else len(f[var_path]))

    device = ControlDevice(
        indptr=indptr_cpu, total_rows=total_rows, n_genes=raw_ng,
        mode=mode, manual_target=manual_target, data_path=data_path,
    )

    tis_full_cpu = np.asarray(block_data['tis'], dtype=np.float64)
    median_sum   = float(np.median(tis_full_cpu[tis_full_cpu > 0]))

    sum_norm_x  = np.zeros(filtered_ng, dtype=np.float64)
    sum_norm_sq = np.zeros(filtered_ng, dtype=np.float64)


    filter_idx = np.full(raw_ng, -1, dtype=np.int64)
    filter_idx[mask_cpu] = np.arange(filtered_ng, dtype=np.int64)

    try:
        device.start_prefetcher(raw_filename, fetch_mode='dense',
                                overhead_multiplier=1.2)
        active_payload = device.get_prefetched_chunk()

        while active_payload is not None:
            nnz        = active_payload['nnz']
            chunk_size = active_payload['rows'] - 1
            curr_row   = active_payload['curr_row']
            next_row   = active_payload['next_row']

            if nnz > 0:
                data_f64    = np.asarray(active_payload['data'], dtype=np.float64)
                indices_arr = np.asarray(active_payload['indices'])
                indptr_arr  = np.asarray(active_payload['indptr'])

                tis_chunk_cpu      = tis_full_cpu[curr_row:next_row]
                size_factors_chunk = (tis_chunk_cpu / median_sum
                                      ).astype(np.float64, copy=True)

                size_factors_chunk[size_factors_chunk == 0] = 1.0

                _fused_norm_aggregate_numba(
                    data_f64, indices_arr, indptr_arr,
                    size_factors_chunk, filter_idx,
                    sum_norm_x, sum_norm_sq,
                    np.int64(chunk_size),
                )

                _rb = active_payload.get('read_bytes', 0)
                ssd_ram_mb = _rb / (1024 ** 2)
                print(
                    f"  > Processing {next_row} of {nc} | "
                    f"Payload: {next_row - curr_row} rows | "
                    f"SSD-RAM: {ssd_ram_mb:.1f} MB{' ' * 15}",
                    end='\r',
                )

            active_payload = device.get_prefetched_chunk()

    finally:
        device.shutdown()

    mean_norm    = (sum_norm_x  / nc).astype(np.float64, copy=False)
    mean_sq_norm = (sum_norm_sq / nc).astype(np.float64, copy=False)
    var_norm     = (mean_sq_norm - mean_norm ** 2).astype(np.float64, copy=False)
    denom        = (var_norm - mean_norm).astype(np.float64, copy=False)


    with np.errstate(divide='ignore', invalid='ignore'):
        size_raw_basic = (mean_norm * mean_norm / denom).astype(np.float64,
                                                                 copy=False)

    basic_clamp_mask = ~(np.isfinite(size_raw_basic) & (denom > 0))


    max_mu       = float(np.max(mean_norm))
    max_size_val = max_mu * max_mu
    if (not np.isfinite(max_size_val)) or max_size_val == 0.0:
        max_size_val = 1e6

    size_arr = np.where(basic_clamp_mask, np.float64(max_size_val), size_raw_basic
                        ).astype(np.float64, copy=False)
    size_arr = np.where(size_arr < np.float64(1e-10),
                        np.float64(1e-10), size_arr
                        ).astype(np.float64, copy=False)

    print(f"\n  > COMPLETE")
    return size_arr, basic_clamp_mask


def RunModelComparison(
    raw_filename:             str,
    block_data:               dict,
    filtered_gene_names:      np.ndarray = None,
    combined_drop_csv:        str = None,
    plot_filename_original:   str = None,
    plot_filename_modified:   str = None,
    plot_filename_residuals:  str = None,
    suppress_plot:            bool = False,
    mode:                     str = "auto",
    manual_target:            int = 3000,
):
    pipeline_start_time = time.perf_counter()
    print("\nFUNCTION: RunModelComparison()")
    nc = block_data['nc']

    adj_dropout_counts = np.asarray(block_data['expected_dropouts'],
                                    dtype=np.float64)

    basic_sizes, basic_clamp_mask = FitBasicModelCPU(
        raw_filename, block_data, mode, manual_target,
    )

    print("Model Diagnostics - Phase 2: Combined Dropout Significance & Basic Model Regression")

    mean_expr = (np.asarray(block_data['tjs'], dtype=np.float64) / nc
                 ).astype(np.float64, copy=False)
    forfit    = (~basic_clamp_mask) & (mean_expr > 1e-3)
    y         = np.log(basic_sizes[forfit])
    x         = np.log(mean_expr[forfit])
    X         = sm.add_constant(x)
    basic_coeffs = sm.OLS(y, X).fit().params

    with np.errstate(divide='ignore'):
        log_mean_expr = np.log(mean_expr)
        log_mean_expr[np.isneginf(log_mean_expr)] = 0
        basic_exp_size = np.exp(basic_coeffs[0] + basic_coeffs[1] * log_mean_expr
                                ).astype(np.float64, copy=False)

    mean_depth = float(block_data['total']) / nc

    bas_dropout_data = CalculateExpectedDropoutsCPU(
        raw_filename=raw_filename,
        exp_size_cpu=basic_exp_size,
        block_a_data=block_data,
        mode=mode,
        manual_target=manual_target,
        custom_tis_val=mean_depth,
    )
    bas_dropout_counts = np.asarray(bas_dropout_data['expected_dropouts'],
                                    dtype=np.float64)


    djs              = np.asarray(block_data['djs'], dtype=np.float64)
    observed_dropout = (djs / nc).astype(np.float64, copy=False)
    adj_dropout_fit  = (adj_dropout_counts / nc).astype(np.float64, copy=False)
    bas_dropout_fit  = (bas_dropout_counts / nc).astype(np.float64, copy=False)

    err_adj = float(np.sum(np.abs(adj_dropout_fit - observed_dropout)))
    err_bas = float(np.sum(np.abs(bas_dropout_fit - observed_dropout)))

    exp_drop_var_counts = np.asarray(block_data['expected_dropouts_var'],
                                     dtype=np.float64)
    droprate_exp_err    = np.sqrt(exp_drop_var_counts / (nc ** 2)
                                  ).astype(np.float64, copy=False)

    with np.errstate(divide='ignore', invalid='ignore'):
        effect_size  = (observed_dropout - adj_dropout_fit
                        ).astype(np.float64, copy=False)
        combined_err = np.sqrt(droprate_exp_err ** 2 +
                               (observed_dropout * (1.0 - observed_dropout) / nc)
                               ).astype(np.float64, copy=False)
        z_scores = (effect_size / combined_err).astype(np.float64, copy=False)

    p_values = norm.sf(z_scores).astype(np.float64, copy=False)
    p_values[np.isnan(p_values)] = 1.0

    _, q_values, _, _ = multipletests(p_values, method='fdr_bh')
    q_values = np.asarray(q_values, dtype=np.float64)
    sig_mask = q_values < 0.05

    if filtered_gene_names is not None and combined_drop_csv is not None:
        df_drop = pd.DataFrame({
            'Gene':        filtered_gene_names,
            'p.value':     p_values,
            'effect_size': effect_size,
            'q.value':     q_values,
        }).sort_values(by='p.value')

        df_drop.to_csv(combined_drop_csv, index=False)
        print(f"  > Exported Combined Dropout Data: {combined_drop_csv}")


    if plot_filename_original:
        plt.figure(figsize=(10, 6))
        sorted_idx = np.argsort(mean_expr)
        plt.scatter(mean_expr[sorted_idx], observed_dropout[sorted_idx],
                    c='black', s=3, alpha=0.6, label='Observed')
        plt.plot(mean_expr[sorted_idx], bas_dropout_fit[sorted_idx],
                 c='goldenrod', linewidth=2.5,
                 label=f'Basic Fit (Error: {err_bas:.2f})')
        plt.plot(mean_expr[sorted_idx], adj_dropout_fit[sorted_idx],
                 c='#1E90FF', linewidth=2.5,
                 label=f'Depth-Adjusted Fit (Error: {err_adj:.2f})')

        plt.xscale('log')
        plt.xlabel("Mean Expression")
        plt.ylabel("Dropout Rate")
        plt.title("M3Drop Model Comparison (Original)")
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.3)

        plt.savefig(plot_filename_original, dpi=300, bbox_inches='tight')
        print(f"Saving Graph 1 to: {plot_filename_original}")
        if not suppress_plot:
            plt.show()
        plt.close()


    if plot_filename_modified:
        plt.figure(figsize=(10, 6))
        sorted_idx = np.argsort(mean_expr)

        plt.scatter(mean_expr[~sig_mask], observed_dropout[~sig_mask],
                    c='black', s=3, alpha=0.5, label='Observed')
        plt.scatter(mean_expr[sig_mask],  observed_dropout[sig_mask],
                    c='red',   s=3, alpha=0.5, label='Observed (FDR < 0.05)')
        plt.plot(mean_expr[sorted_idx], adj_dropout_fit[sorted_idx],
                 c='#1E90FF', linewidth=2.5,
                 label=f'Depth-Adjusted Fit (Error: {err_adj:.2f})')

        plt.xscale('log')
        plt.xlabel("Mean Expression")
        plt.ylabel("Dropout Rate")
        plt.title("M3Drop Model Comparison (FDR Highlighted)")
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.3)

        plt.savefig(plot_filename_modified, dpi=300, bbox_inches='tight')
        print(f"Saving Graph 2 to: {plot_filename_modified}")
        if not suppress_plot:
            plt.show()
        plt.close()


    if plot_filename_residuals:
        plt.figure(figsize=(10, 6))

        plt.scatter(mean_expr[~sig_mask], effect_size[~sig_mask],
                    c='black', s=3, alpha=0.5, label='Residuals')
        plt.scatter(mean_expr[sig_mask],  effect_size[sig_mask],
                    c='red',   s=3, alpha=0.5, label='Residuals (FDR < 0.05)')
        plt.axhline(0, color='black', linestyle='-', linewidth=1.0,
                    label='Zero Error Baseline')

        plt.xscale('log')
        plt.xlabel("Mean Expression")
        plt.ylabel("Residual Dropout (Observed - Expected)")
        plt.title("M3Drop Residual Dropouts")
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.3)

        plt.savefig(plot_filename_residuals, dpi=300, bbox_inches='tight')
        print(f"Saving Graph 3 to: {plot_filename_residuals}")
        if not suppress_plot:
            plt.show()
        plt.close()

    print(f"\nTotal Module time: {time.perf_counter() - pipeline_start_time:.2f} seconds.")

    return {
        "errors": {"Depth-Adjusted": err_adj, "Basic": err_bas},
        "comparison_df": pd.DataFrame({
            'mean_expr': mean_expr,
            'observed':  observed_dropout,
            'adj_fit':   adj_dropout_fit,
            'bas_fit':   bas_dropout_fit,
        }),
    }


def RunFeatureSelectionCPU(raw_data,
                           output_dir=None,
                           plots=0,
                           manual_payload=None,
                           block_data=None):
    if not isinstance(raw_data, str):
        raise TypeError(
            f"raw_data must be a string path. Got: {type(raw_data).__name__}"
        )

    if not os.path.exists(raw_data):
        raise FileNotFoundError(
            f"Input file not found: '{raw_data}'. "
            f"Check the path and your current working directory."
        )

    if plots not in (0, 1):
        raise ValueError(f"plots must be 0 or 1. Got: {plots}")

    if manual_payload is not None:
        if not isinstance(manual_payload, int) or manual_payload <= 0:
            raise ValueError(
                f"manual_payload must be a positive integer (MB) or None. "
                f"Got: {manual_payload}"
            )

    if block_data is not None and not isinstance(block_data, dict):
        raise TypeError(
            f"block_data must be a dict from RunComputeBlockCPU() or None. "
            f"Got: {type(block_data).__name__}"
        )

    raw_data_abs = os.path.abspath(raw_data)
    input_folder = os.path.dirname(raw_data_abs)

    if output_dir is None:
        output_dir = input_folder
    else:
        output_dir = os.path.abspath(output_dir)
        os.makedirs(output_dir, exist_ok=True)

    basename = os.path.basename(raw_data_abs)
    if basename.lower().endswith('.h5ad'):
        basename = basename[:-5]

    high_var_csv      = os.path.join(output_dir, f"{basename}_FEATSEL_high_variance_genes.csv")
    combined_drop_csv = os.path.join(output_dir, f"{basename}_FEATSEL_combined_dropout_genes.csv")
    mean_disp_csv     = os.path.join(output_dir, f"{basename}_FEATSEL_mean_dispersion.csv")

    plot_disp_vs_mean  = (os.path.join(output_dir, f"{basename}_FEATSEL_disp_vs_mean.png")
                          if plots else None)
    plot_model_orig    = (os.path.join(output_dir, f"{basename}_FEATSEL_NBumiCompareModels.png")
                          if plots else None)
    plot_model_mod     = (os.path.join(output_dir, f"{basename}_FEATSEL_NBumiCompareModels_FDR.png")
                          if plots else None)
    plot_residuals     = (os.path.join(output_dir, f"{basename}_FEATSEL_ResidualDropouts.png")
                          if plots else None)

    if manual_payload is None:
        mode          = "auto"
        manual_target = 2048
    else:
        mode          = "manual"
        manual_target = manual_payload

    print(f"\n{'#'*60}")
    print(f"   RunFeatureSelectionCPU()")
    print(f"   Input:       {raw_data_abs}")
    print(f"   Output dir:  {output_dir}")
    print(f"   Plots:       {'ON' if plots else 'OFF'}")
    print(f"   Mode:        {mode.upper()}"
          + (f"  (payload: {manual_target} MB)" if mode == "manual" else ""))
    print(f"   Block data:  {'provided (reused)' if block_data is not None else 'computed internally'}")
    print(f"{'#'*60}")

    data_path, var_path = detect_data_path(raw_data_abs)
    if data_path == 'unknown':
        raise ValueError(
            f"None of 'raw/X', 'layers/counts', or 'X' found in '{raw_data}'. "
            f"File may be corrupted or not a valid .h5ad."
        )

    if block_data is None:
        block_data = ComputeBlockA(
            raw_filename=raw_data_abs,
            calc_djs=True,
            mode=mode,
            manual_target=manual_target,
            data_path=data_path,
            var_path=var_path,
        )
        block_data = ComputeBlockB(
            raw_filename=raw_data_abs,
            block_a_data=block_data,
            mode=mode,
            manual_target=manual_target,
        )
    else:
        required_keys = ['mask', 'sizes', 'exp_size', 'regression_coeffs',
                         'expected_dropouts', 'djs']
        missing = [k for k in required_keys if k not in block_data]
        if missing:
            raise ValueError(
                f"block_data is missing required keys for Feature Selection: "
                f"{missing}. Pass a block prepared via RunComputeBlockCPU() "
                f"(not a bare ComputeBlockA result)."
            )

    with h5py.File(raw_data_abs, 'r') as f:
        if var_path in f and '_index' in f[var_path]:
            gene_names_raw = f[var_path]['_index'][:]
            gene_names = np.array([
                g.decode('utf-8') if isinstance(g, bytes) else g
                for g in gene_names_raw
            ])
        else:
            n_total = block_data['ng'] + len(np.where(~block_data['mask'])[0])
            gene_names = np.arange(n_total).astype(str)

    filtered_gene_names = gene_names[block_data['mask']]

    RunFeatureSelection(
        block_data=block_data,
        gene_names=gene_names,
        high_var_csv=high_var_csv,
    )

    ExportMeanDispersion(
        block_data=block_data,
        gene_names=gene_names,
        mean_disp_csv=mean_disp_csv,
    )

    if plots:
        PlotDispVsMean(
            block_data=block_data,
            plot_filename=plot_disp_vs_mean,
            suppress_plot=True,
        )

    RunModelComparison(
        raw_filename=raw_data_abs,
        block_data=block_data,
        filtered_gene_names=filtered_gene_names,
        combined_drop_csv=combined_drop_csv,
        plot_filename_original=plot_model_orig,
        plot_filename_modified=plot_model_mod,
        plot_filename_residuals=plot_residuals,
        suppress_plot=True,
        mode=mode,
        manual_target=manual_target,
    )

    print(f"\n>>> RunFeatureSelectionCPU complete.")
    print(f">>> High-variance CSV: {high_var_csv}")
    print(f">>> Combined dropout CSV: {combined_drop_csv}")
    print(f">>> Mean/Dispersion CSV: {mean_disp_csv}")

    result = {
        "high_var_csv":      high_var_csv,
        "combined_drop_csv": combined_drop_csv,
        "mean_disp_csv":     mean_disp_csv,
    }
    if plots:
        result["plots"] = {
            "disp_vs_mean":   plot_disp_vs_mean,
            "model_original": plot_model_orig,
            "model_modified": plot_model_mod,
            "residuals":      plot_residuals,
        }
    return result