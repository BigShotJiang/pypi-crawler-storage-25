
import os
import sys
import time
import threading
import queue
import gc

import numpy as np
import h5py
import matplotlib.pyplot as plt
import scipy.sparse as sps

from .ControlDeviceCPU import ControlDevice
from .ComputeBlockCPU import ComputeBlockA, detect_data_path


def _drop_page_cache(filepath):
    try:
        fd = os.open(filepath, os.O_RDONLY)
        os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
        os.close(fd)
    except (OSError, AttributeError):
        pass


def _pearson_approx_inplace(counts, tjs_row, tis_col, total, out, mu_buf):

    np.multiply(tjs_row, tis_col, out=mu_buf)
    np.divide(mu_buf, total, out=mu_buf)


    np.subtract(counts, mu_buf, out=out)
    np.sqrt(mu_buf, out=mu_buf)
    with np.errstate(divide='ignore', invalid='ignore'):
        np.divide(out, mu_buf, out=out)

    out[mu_buf < 1e-12] = 0.0
    return out


def _approx_to_full_inplace(approx, tjs_row, tis_col, theta_row, total, out,
                             mu_buf):

    np.multiply(tjs_row, tis_col, out=mu_buf)
    np.divide(mu_buf, total, out=mu_buf)

    np.divide(mu_buf, theta_row, out=mu_buf)

    np.add(mu_buf, np.float64(1.0), out=mu_buf)

    np.sqrt(mu_buf, out=mu_buf)
    with np.errstate(divide='ignore', invalid='ignore'):
        np.divide(approx, mu_buf, out=out)
    out[mu_buf < 1e-12] = 0.0
    return out


def _pearson_std_nb(counts, mean_j_row, denom_j_row, out):
    np.subtract(counts, mean_j_row, out=out)
    with np.errstate(divide='ignore', invalid='ignore'):
        np.divide(out, denom_j_row, out=out)

    mask_g = denom_j_row[0] < 1e-12
    if np.any(mask_g):
        out[:, mask_g] = 0.0
    return out


def _sum_axis0(arr):
    return np.sum(arr, axis=0, dtype=np.float64)


def _sum_square_axis0(arr):
    return np.einsum('ij,ij->j', arr, arr, optimize=True, dtype=np.float64)


def _scaffold_h5ad_pure_h5py(output_filename, raw_filename, data_path,
                              mask_cpu, nc, ng_filtered, safe_chunk_rows):
    with h5py.File(raw_filename, 'r') as f_raw, h5py.File(output_filename, 'w') as f_out:

        f_out.attrs['encoding-type']    = 'anndata'
        f_out.attrs['encoding-version'] = '0.1.0'

        f_out.create_dataset('X', shape=(nc, ng_filtered), dtype='float64',
                             chunks=(safe_chunk_rows, ng_filtered), fillvalue=0.0)

        if 'obs' in f_raw:
            f_raw.copy(f_raw['obs'], f_out, 'obs')
        else:
            obs_grp = f_out.create_group('obs')
            obs_grp.attrs['encoding-type']    = 'dataframe'
            obs_grp.attrs['encoding-version'] = '0.2.0'
            obs_grp.attrs['_index']           = '_index'
            obs_grp.attrs['column-order']     = []

        var_grp = f_out.create_group('var')
        var_grp.attrs['encoding-type']    = 'dataframe'
        var_grp.attrs['encoding-version'] = '0.2.0'

        var_path = 'raw/var' if data_path == 'raw/X' else 'var'
        if var_path in f_raw:
            src_var = f_raw[var_path]

            if '_index' in src_var:
                raw_index      = src_var['_index'][:]
                filtered_index = raw_index[mask_cpu]
                var_grp.create_dataset('_index', data=filtered_index)
                var_grp.attrs['_index'] = '_index'

            if 'column-order' in src_var.attrs:
                var_grp.attrs['column-order'] = src_var.attrs['column-order']
            else:
                col_names = [k for k in src_var.keys()
                             if k != '_index' and k != '__categories']
                var_grp.attrs['column-order'] = col_names

            for key in src_var:
                if key == '_index':
                    continue
                if key == '__categories':
                    f_raw.copy(src_var[key], var_grp, key)
                    continue
                ds = src_var[key]
                if isinstance(ds, h5py.Dataset):
                    raw_data = ds[:]
                    if len(raw_data) == len(mask_cpu):
                        var_grp.create_dataset(key, data=raw_data[mask_cpu])
                    else:
                        var_grp.create_dataset(key, data=raw_data)
                    for attr_key in ds.attrs:
                        var_grp[key].attrs[attr_key] = ds.attrs[attr_key]
                elif isinstance(ds, h5py.Group):
                    f_raw.copy(ds, var_grp, key)

            for attr_key in src_var.attrs:
                if attr_key not in var_grp.attrs:
                    var_grp.attrs[attr_key] = src_var.attrs[attr_key]
        else:
            gene_names = np.array([f'Gene_{i}' for i in range(ng_filtered)], dtype='S')
            var_grp.create_dataset('_index', data=gene_names)
            var_grp.attrs['_index']       = '_index'
            var_grp.attrs['column-order'] = []


def NBumiPearsonResidualsCombinedCPU(
    raw_filename:           str,
    output_filename:        str,
    block_data:             dict,
    plot_summary_filename:  str = None,
    plot_std_nb_filename:   str = None,
    mode:                   str = "auto",
    manual_target:          int = 3000,
):
    start_time = time.perf_counter()
    print(f"\nFUNCTION: NBumiPearsonResidualsCombinedCPU()")

    mask_cpu    = np.asarray(block_data['mask'])
    ng_filtered = block_data['ng']
    nc          = block_data['nc']
    data_path   = block_data.get('data_path', 'X')

    total     = float(block_data['total'])
    tjs       = np.asarray(block_data['tjs'],   dtype=np.float64)
    tis       = np.asarray(block_data['tis'],   dtype=np.float64)
    sizes     = np.asarray(block_data['sizes'], dtype=np.float64)

    indptr_cpu = block_data['indptr']


    mean_j   = (tjs / np.float64(nc)).astype(np.float64, copy=False)
    nb_var_j = (mean_j + (mean_j ** 2) / sizes).astype(np.float64, copy=False)
    denom_j  = np.sqrt(nb_var_j).astype(np.float64, copy=False)


    tjs_row     = tjs.reshape(1, -1)
    sizes_row   = sizes.reshape(1, -1)
    mean_j_row  = mean_j.reshape(1, -1)
    denom_j_row = denom_j.reshape(1, -1)

    device = ControlDevice(
        indptr=indptr_cpu, total_rows=nc, n_genes=ng_filtered,
        mode=mode, manual_target=manual_target, data_path=data_path,
    )

    print("Normalization - Phase 1: Approximate Poisson Residuals")
    print("Normalization - Phase 2: Depth-Adjusted Negative Binomial Pearson Residuals")
    print("Normalization - Phase 3: Standard Negative Binomial Residuals")

    bytes_per_row           = ng_filtered * 8
    governor_bytes          = device.payload_dense_target_bytes
    dynamic_hdf5_chunk_rows = min(nc, max(1, int(governor_bytes / bytes_per_row)))
    safe_chunk_rows         = min(256, dynamic_hdf5_chunk_rows)

    _scaffold_h5ad_pure_h5py(output_filename, raw_filename, data_path,
                              mask_cpu, nc, ng_filtered, safe_chunk_rows)
    gc.collect()

    TARGET_SAMPLES = 5_000_000
    total_points   = nc * ng_filtered
    sampling_rate  = (1.0 if total_points <= TARGET_SAMPLES
                      else TARGET_SAMPLES / total_points)


    acc_raw_sum    = np.zeros(ng_filtered, dtype=np.float64)
    acc_approx_sum = np.zeros(ng_filtered, dtype=np.float64)
    acc_approx_sq  = np.zeros(ng_filtered, dtype=np.float64)
    acc_full_sum   = np.zeros(ng_filtered, dtype=np.float64)
    acc_full_sq    = np.zeros(ng_filtered, dtype=np.float64)
    acc_std_sum    = np.zeros(ng_filtered, dtype=np.float64)
    acc_std_sq     = np.zeros(ng_filtered, dtype=np.float64)

    viz_approx_samples        = []
    viz_full_samples          = []
    viz_std_samples           = []
    viz_samples_collected     = 0
    viz_std_samples_collected = 0


    std_nb_buf = None


    mu_buf = None

    with h5py.File(output_filename, 'a') as f_out:
        out_x = f_out['X']

        write_queue = queue.Queue(maxsize=2)

        def hdf5_writer_worker():
            while True:
                payload = write_queue.get()
                if payload is None:
                    write_queue.task_done()
                    break
                r_start, r_end, full_data = payload
                out_x[r_start:r_end, :] = full_data
                f_out.flush()
                _drop_page_cache(output_filename)
                del full_data, payload
                write_queue.task_done()

        writer_thread = threading.Thread(target=hdf5_writer_worker, daemon=True)
        writer_thread.start()

        try:
            device.start_prefetcher(raw_filename, fetch_mode='dense',
                                    overhead_multiplier=1.2)
            active_payload = device.get_prefetched_chunk()

            while active_payload is not None:
                nnz        = active_payload['nnz']
                chunk_size = active_payload['rows'] - 1
                curr_row   = active_payload['curr_row']
                next_row   = active_payload['next_row']

                if nnz > 0:

                    data_f64    = np.asarray(active_payload['data'],
                                              dtype=np.float64)
                    indices_arr = np.asarray(active_payload['indices'])
                    indptr_arr  = np.asarray(active_payload['indptr'])

                    chunk = sps.csr_matrix(
                        (data_f64, indices_arr, indptr_arr),
                        shape=(chunk_size, len(mask_cpu)),
                    )
                    chunk = chunk[:, mask_cpu]
                    np.ceil(chunk.data, out=chunk.data)

                    counts_dense = chunk.toarray().astype(np.float64, copy=False)
                    tis_chunk    = tis[curr_row:next_row].reshape(-1, 1)


                    acc_raw_sum += _sum_axis0(counts_dense)


                    if std_nb_buf is None or std_nb_buf.shape != counts_dense.shape:
                        std_nb_buf = np.empty_like(counts_dense)
                    _pearson_std_nb(counts_dense, mean_j_row, denom_j_row,
                                     out=std_nb_buf)

                    acc_std_sum += _sum_axis0(std_nb_buf)
                    acc_std_sq  += _sum_square_axis0(std_nb_buf)

                    chunk_total_items_std = (next_row - curr_row) * ng_filtered
                    n_samples_std         = int(chunk_total_items_std *
                                                sampling_rate)
                    if (n_samples_std > 0 and
                            viz_std_samples_collected < TARGET_SAMPLES):
                        flat_std       = std_nb_buf.ravel()
                        sample_idx_cpu = np.random.randint(
                            0, int(chunk_total_items_std), size=n_samples_std
                        )
                        viz_std_samples.append(flat_std[sample_idx_cpu].copy())
                        viz_std_samples_collected += n_samples_std
                        del flat_std, sample_idx_cpu


                    if mu_buf is None or mu_buf.shape != counts_dense.shape:
                        mu_buf = np.empty_like(counts_dense)
                    _pearson_approx_inplace(counts_dense, tjs_row, tis_chunk,
                                             total, out=counts_dense,
                                             mu_buf=mu_buf)

                    acc_approx_sum += _sum_axis0(counts_dense)
                    acc_approx_sq  += _sum_square_axis0(counts_dense)


                    chunk_items   = (next_row - curr_row) * ng_filtered
                    n_samp        = int(chunk_items * sampling_rate)
                    should_sample = (n_samp > 0 and
                                     viz_samples_collected < TARGET_SAMPLES)
                    if should_sample:
                        sample_idx_cpu = np.random.randint(
                            0, int(chunk_items), size=n_samp
                        )
                        viz_approx_samples.append(
                            counts_dense.ravel()[sample_idx_cpu].copy()
                        )


                    _approx_to_full_inplace(
                        counts_dense, tjs_row, tis_chunk, sizes_row, total,
                        out=counts_dense, mu_buf=mu_buf,
                    )

                    acc_full_sum += _sum_axis0(counts_dense)
                    acc_full_sq  += _sum_square_axis0(counts_dense)

                    if should_sample:
                        viz_full_samples.append(
                            counts_dense.ravel()[sample_idx_cpu].copy()
                        )
                        viz_samples_collected += n_samp
                        del sample_idx_cpu


                    write_queue.join()
                    write_queue.put((curr_row, next_row, counts_dense.copy()))


                    del data_f64, indices_arr, indptr_arr, chunk, counts_dense

                    _rb = active_payload.get('read_bytes', 0)
                    ssd_ram_mb = _rb / (1024 ** 2)
                    print(
                        f"  > Processing {next_row} of {nc} | "
                        f"Payload: {next_row - curr_row} rows | "
                        f"SSD-RAM: {ssd_ram_mb:.1f} MB{' ' * 15}",
                        end='\r', flush=True,
                    )

                active_payload = device.get_prefetched_chunk()

            write_queue.put(None)
            write_queue.join()
            writer_thread.join()

            print(f"\n  > COMPLETE")

        finally:
            device.shutdown()
            try:
                write_queue.put_nowait(None)
            except Exception:
                pass
            writer_thread.join(timeout=10.0)

    print("  > Metadata attached during scaffold phase.")
    gc.collect()


    any_plot = plot_summary_filename or plot_std_nb_filename

    if any_plot:
        mean_raw  = (acc_raw_sum  / nc).astype(np.float64, copy=False)
        mean_full = (acc_full_sum / nc).astype(np.float64, copy=False)
        var_full  = ((acc_full_sq / nc) - mean_full ** 2
                     ).astype(np.float64, copy=False)

        flat_full = (np.concatenate(viz_full_samples)
                     if viz_full_samples else np.array([], dtype=np.float64))
        del viz_full_samples
        gc.collect()

    if plot_summary_filename:
        mean_approx = (acc_approx_sum / nc).astype(np.float64, copy=False)
        var_approx  = ((acc_approx_sq / nc) - mean_approx ** 2
                       ).astype(np.float64, copy=False)

        flat_approx = (np.concatenate(viz_approx_samples)
                       if viz_approx_samples else np.array([], dtype=np.float64))
        del viz_approx_samples
        gc.collect()

        fig1, ax1 = plt.subplots(1, 2, figsize=(16, 7))

        ax = ax1[0]
        ax.scatter(mean_raw, var_approx, s=2, alpha=0.5, color='red',
                   label='Approx (Poisson)')
        ax.scatter(mean_raw, var_full,   s=2, alpha=0.5, color='blue',
                   label='Full (NB Pearson)')
        ax.axhline(1.0, color='black', linestyle='--', linewidth=1)
        ax.set_xscale('log')
        ax.set_yscale('log')
        ax.set_title("Variance Stabilization Check")
        ax.set_xlabel("Mean Raw Expression (log)")
        ax.set_ylabel("Variance of Residuals (log)")
        ax.legend()
        ax.grid(True, which='both', linestyle='--', alpha=0.5)
        ax.text(0.5, -0.15, "Goal: Blue dots should form a flat line at y=1",
                transform=ax.transAxes, ha='center', fontsize=9,
                bbox=dict(facecolor='#f0f0f0', edgecolor='black', alpha=0.7))

        ax = ax1[1]
        if len(flat_approx) > 100:
            x_lo_s = min(float(flat_approx.min()), float(flat_full.min()))
            x_hi_s = max(float(flat_approx.max()), float(flat_full.max()))

            LINTHRESH = 5.0
            central   = np.linspace(max(x_lo_s, -LINTHRESH),
                                    min(x_hi_s,  LINTHRESH), 51)
            parts     = [central]
            if x_hi_s > LINTHRESH:
                parts.append(np.geomspace(LINTHRESH, x_hi_s, 76)[1:])
            if x_lo_s < -LINTHRESH:
                parts.insert(0, -np.geomspace(LINTHRESH, -x_lo_s, 26)[::-1][:-1])
            bins = np.concatenate(parts)

            ax.hist(flat_approx, bins=bins, histtype='stepfilled', color='#E63946',
                    alpha=0.25, edgecolor='#E63946', linewidth=2.0, density=True,
                    label='Approx (Poisson)')
            ax.hist(flat_full,   bins=bins, histtype='stepfilled', color='#1D70B8',
                    alpha=0.25, edgecolor='#1D70B8', linewidth=2.0, density=True,
                    label='Full (NB Pearson)')

            ax.set_xlim(-max(abs(x_lo_s), abs(x_hi_s)),
                         max(abs(x_lo_s), abs(x_hi_s)))

        ax.set_xscale('symlog', linthresh=5.0)
        ax.set_yscale('log')
        ax.set_ylim(bottom=0.001)
        ax.set_title("Distribution of Residuals (Symlog X, Log Y)")
        ax.set_xlabel("Residual Value  [linear in (-5, 5), log beyond]")
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.text(0.5, -0.15, "Goal: Blue histogram should be tighter (narrower) than Red",
                transform=ax.transAxes, ha='center', fontsize=9,
                bbox=dict(facecolor='#f0f0f0', edgecolor='black', alpha=0.7))

        plt.tight_layout()
        plt.savefig(plot_summary_filename, dpi=120)
        print(f"Saving plot to: {plot_summary_filename}")
        plt.close()
        del flat_approx

    if plot_std_nb_filename:
        mean_std = (acc_std_sum / nc).astype(np.float64, copy=False)
        var_std  = ((acc_std_sq / nc) - mean_std ** 2
                    ).astype(np.float64, copy=False)

        flat_std = (np.concatenate(viz_std_samples)
                    if viz_std_samples else np.array([], dtype=np.float64))
        del viz_std_samples
        gc.collect()

        fig3, ax3 = plt.subplots(1, 2, figsize=(16, 7))

        ax = ax3[0]
        ax.scatter(mean_raw, var_std,  s=2, alpha=0.5, color='red',
                   label='Standard NB')
        ax.scatter(mean_raw, var_full, s=2, alpha=0.5, color='blue',
                   label='DANB (Depth-Adjusted)')
        ax.axhline(1.0, color='black', linestyle='--', linewidth=1)
        ax.set_xscale('log')
        ax.set_yscale('log')
        ax.set_title("Variance Stabilization: Standard NB vs DANB")
        ax.set_xlabel("Mean Raw Expression (log)")
        ax.set_ylabel("Variance of Residuals (log)")
        ax.legend()
        ax.grid(True, which='both', linestyle='--', alpha=0.5)
        ax.text(0.5, -0.15, "Goal: Blue dots should form a flat line at y=1",
                transform=ax.transAxes, ha='center', fontsize=9,
                bbox=dict(facecolor='#f0f0f0', edgecolor='black', alpha=0.7))

        ax = ax3[1]
        if len(flat_std) > 100:
            x_lo_nb = min(float(flat_std.min()), float(flat_full.min()))
            x_hi_nb = max(float(flat_std.max()), float(flat_full.max()))

            LINTHRESH = 5.0
            central   = np.linspace(max(x_lo_nb, -LINTHRESH),
                                    min(x_hi_nb,  LINTHRESH), 51)
            parts     = [central]
            if x_hi_nb > LINTHRESH:
                parts.append(np.geomspace(LINTHRESH, x_hi_nb, 76)[1:])
            if x_lo_nb < -LINTHRESH:
                parts.insert(0, -np.geomspace(LINTHRESH, -x_lo_nb, 26)[::-1][:-1])
            bins = np.concatenate(parts)

            ax.hist(flat_std,  bins=bins, histtype='stepfilled', color='#E63946',
                    alpha=0.25, edgecolor='#E63946', linewidth=2.0, density=True,
                    label='Standard NB')
            ax.hist(flat_full, bins=bins, histtype='stepfilled', color='#1D70B8',
                    alpha=0.25, edgecolor='#1D70B8', linewidth=2.0, density=True,
                    label='DANB (Depth-Adjusted)')

            combined_nb = np.concatenate([flat_std, flat_full])
            view_abs_nb = max(abs(float(np.percentile(combined_nb, 0.1))),
                              abs(float(np.percentile(combined_nb, 99.9))))
            del combined_nb
            ax.set_xlim(-view_abs_nb, view_abs_nb)

        ax.set_xscale('symlog', linthresh=5.0)
        ax.set_yscale('log')
        ax.set_ylim(bottom=0.001)
        ax.set_title("Distribution of Residuals: Standard NB vs DANB (Symlog X, Log Y)")
        ax.set_xlabel("Residual Value  [linear in (-5, 5), log beyond]")
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.text(0.5, -0.15, "Goal: Blue histogram should be tighter (narrower) than Red",
                transform=ax.transAxes, ha='center', fontsize=9,
                bbox=dict(facecolor='#f0f0f0', edgecolor='black', alpha=0.7))

        plt.tight_layout()
        plt.savefig(plot_std_nb_filename, dpi=120)
        print(f"Saving plot to: {plot_std_nb_filename}")
        plt.close()
        del flat_std

    if any_plot:
        del flat_full

    print(f"\nTotal Module time: {time.perf_counter() - start_time:.2f} seconds.")


def RunNormalizationCPU(raw_data,
                        output_dir=None,
                        plots=0,
                        manual_payload=None,
                        block_data=None):
    if not isinstance(raw_data, str):
        raise TypeError(
            f"raw_data must be a string path. Got: {type(raw_data).__name__}"
        )

    if not os.path.exists(raw_data):
        raise FileNotFoundError(
            f"Input file not found: '{raw_data}'. "
            f"Check the path and your current working directory."
        )

    if plots not in (0, 1):
        raise ValueError(f"plots must be 0 or 1. Got: {plots}")

    if manual_payload is not None:
        if not isinstance(manual_payload, int) or manual_payload <= 0:
            raise ValueError(
                f"manual_payload must be a positive integer (MB) or None. "
                f"Got: {manual_payload}"
            )

    if block_data is not None and not isinstance(block_data, dict):
        raise TypeError(
            f"block_data must be a dict from RunComputeBlockCPU() or None. "
            f"Got: {type(block_data).__name__}"
        )

    raw_data_abs = os.path.abspath(raw_data)
    input_folder = os.path.dirname(raw_data_abs)

    if output_dir is None:
        output_dir = input_folder
    else:
        output_dir = os.path.abspath(output_dir)
        os.makedirs(output_dir, exist_ok=True)

    basename = os.path.basename(raw_data_abs)
    if basename.lower().endswith('.h5ad'):
        basename = basename[:-5]

    output_h5ad  = os.path.join(output_dir, f"{basename}_pearson_residuals.h5ad")
    plot_summary = (os.path.join(output_dir, f"{basename}_ApproxPearson_vs_DANB.png")
                    if plots else None)
    plot_std_nb  = (os.path.join(output_dir, f"{basename}_Std_NB_vs_DANB.png")
                    if plots else None)

    if manual_payload is None:
        mode          = "auto"
        manual_target = 2048
    else:
        mode          = "manual"
        manual_target = manual_payload

    print(f"\n{'#'*60}")
    print(f"   RunNormalizationCPU()")
    print(f"   Input:         {raw_data_abs}")
    print(f"   Output dir:    {output_dir}")
    print(f"   Plots:         {'ON' if plots else 'OFF'}")
    print(f"   Mode:          {mode.upper()}"
          + (f"  (payload: {manual_target} MB)" if mode == "manual" else ""))
    print(f"   Block data:    {'provided (reused)' if block_data is not None else 'computed internally'}")
    print(f"{'#'*60}")

    if block_data is None:
        data_path, var_path = detect_data_path(raw_data_abs)
        if data_path == 'unknown':
            raise ValueError(
                f"None of 'raw/X', 'layers/counts', or 'X' found in '{raw_data}'. "
                f"File may be corrupted or not a valid .h5ad."
            )
        block_data = ComputeBlockA(
            raw_filename=raw_data_abs,
            calc_djs=False,
            mode=mode,
            manual_target=manual_target,
            data_path=data_path,
            var_path=var_path,
        )

    NBumiPearsonResidualsCombinedCPU(
        raw_filename=raw_data_abs,
        output_filename=output_h5ad,
        block_data=block_data,
        plot_summary_filename=plot_summary,
        plot_std_nb_filename=plot_std_nb,
        mode=mode,
        manual_target=manual_target,
    )

    print(f"\n>>> RunNormalizationCPU complete.")
    print(f">>> Output: {output_h5ad}")
    return output_h5ad
