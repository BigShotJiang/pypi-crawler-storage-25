import math
import numpy as np
import h5py
import os
import subprocess
import threading
import queue
import sys
import time


try:
    import cupy
    HAS_CUPY = True
    from cupyx import empty_pinned
except ImportError:
    cupy        = None
    HAS_CUPY    = False
    empty_pinned = None

try:
    import psutil
except ImportError:
    psutil = None


try:
    _PCIE_GEN = int(subprocess.check_output(
        ["nvidia-smi", "--query-gpu=pcie.link.gen.max", "--format=csv,noheader,nounits"],
        encoding="utf-8"
    ).strip().split('\n')[0])
except Exception:
    _PCIE_GEN = 3


class ControlDevice:

    def __init__(
        self,
        indptr:        np.ndarray,
        total_rows:    int,
        n_genes:       int,
        vram_limit_mb: float = None,
        mode:          str   = "auto",
        manual_target: int   = 5000,
        data_path:     str   = 'X',
        bytes_per_item: int  = 16,
        **kwargs
    ):

        if not isinstance(indptr, np.ndarray) or indptr.ndim != 1 or len(indptr) < 2:
            raise ValueError(
                "indptr must be a 1-D numpy array with at least 2 elements."
            )
        if int(indptr[0]) != 0:
            raise ValueError(
                "indptr[0] must be 0 -- invalid CSR format."
            )

        self.indptr        = indptr
        self.total_rows    = total_rows
        self.n_genes       = n_genes
        self.mode          = mode.lower()
        self.manual_target = manual_target
        self.data_path     = data_path


        self.sys_ram_limit_mb     = self._detect_real_memory_limit()
        self.sys_ram_available_mb = self._detect_available_memory()

        self.vram_limit_mb = vram_limit_mb if vram_limit_mb is not None else self._detect_vram()


        if self.vram_limit_mb < 8_000:
            _haircut_pct = 0.08
        elif self.vram_limit_mb < 20_000:
            _haircut_pct = 0.05
        elif self.vram_limit_mb < 48_000:
            _haircut_pct = 0.03
        else:
            _haircut_pct = 0.02
        _haircut_mb = max(512.0, self.vram_limit_mb * _haircut_pct)
        self.vram_budget_bytes = (self.vram_limit_mb - _haircut_mb) * 1024 * 1024


        self._acc_vram_reserved: int = 0

        self.bytes_per_item = bytes_per_item


        if _PCIE_GEN >= 5:
            pcie_target_mb = 2048.0
        elif _PCIE_GEN >= 3:
            pcie_target_mb = 1024.0
        else:
            pcie_target_mb = 512.0


        _FULL_THRESH     = 0.50
        _MODERATE_THRESH = 0.20
        _avail_ratio     = self.sys_ram_available_mb / max(self.sys_ram_limit_mb, 1.0)

        if _avail_ratio >= _FULL_THRESH:

            headroom_mb   = max(2048.0, self.sys_ram_limit_mb * 0.12)
            safe_mb       = max(0.0, self.sys_ram_available_mb - headroom_mb)
            _budget_basis = "Tier 1: FULL"

        elif _avail_ratio >= _MODERATE_THRESH:

            _blend           = (_FULL_THRESH - _avail_ratio) / (_FULL_THRESH - _MODERATE_THRESH)
            headroom_mb      = max(2048.0, self.sys_ram_limit_mb * 0.12)
            safe_avail_mb    = max(0.0, self.sys_ram_available_mb - headroom_mb)
            hard_overhead_mb = max(4096.0, self.sys_ram_limit_mb * 0.28)
            safe_total_mb    = max(0.0, self.sys_ram_limit_mb - hard_overhead_mb)
            safe_mb          = (1.0 - _blend) * safe_avail_mb + _blend * safe_total_mb
            _budget_basis    = "Tier 2: MODERATE"

        else:

            hard_overhead_mb = max(4096.0, self.sys_ram_limit_mb * 0.28)
            safe_mb          = max(0.0, self.sys_ram_limit_mb - hard_overhead_mb)
            _budget_basis    = "Tier 3: MINIMAL"


        _vram_budget_mb = self.vram_budget_bytes / (1024 * 1024)

        if self.sys_ram_limit_mb >= 32768:
            _ram_payload_cap = 2048.0
        elif self.sys_ram_limit_mb >= 15360:
            _ram_payload_cap = 1024.0
        elif self.sys_ram_limit_mb >= 8192:
            _ram_payload_cap =  512.0
        else:
            _ram_payload_cap =  256.0

        if self.mode == "manual":
            target_mb        = float(self.manual_target)
            self._max_q_size = 2 if self.sys_ram_limit_mb > 8192 else 1
        else:
            target_mb        = min(pcie_target_mb, _vram_budget_mb, _ram_payload_cap)
            target_mb        = max(128.0, target_mb)

            raw_depth        = int(safe_mb / target_mb)
            self._max_q_size = max(1, min(4, raw_depth))

        self.pcie_sparse_target_bytes = target_mb * 1024 * 1024
        self.pcie_dense_target_bytes  = target_mb * 1024 * 1024


        self.prefetch_queue:  queue.Queue        = None
        self.prefetch_thread: threading.Thread   = None
        self._stop_event:     threading.Event    = threading.Event()


        vram_budget_mb = self.vram_budget_bytes / (1024 ** 2)
        _data_label_map = {
            'X':             'X',
            'raw/X':         'raw.X',
            'layers/counts': 'layers.counts',
        }
        display_data = _data_label_map.get(
            self.data_path,
            (self.data_path or "Unknown").replace('/', '.')
        )

        print(f"\n-------------- CONTROL DEVICE --------------")
        print(f"  > Data:    {display_data}")
        print(f"  > Mode:    {'MANUAL' if self.mode == 'manual' else 'AUTO'}")
        print(f"  > PCIe:    Gen {_PCIE_GEN}")
        print(f"  > RAM:     {self.sys_ram_available_mb:.0f} MB avail  /  {self.sys_ram_limit_mb:.0f} MB total"
              f"  [{_budget_basis}]")
        print(f"  > VRAM:    {vram_budget_mb:.0f} MB budget  /  {self.vram_limit_mb:.0f} MB total"
              f"  [{_haircut_pct*100:.0f}% @ {_haircut_mb:.0f}MB]")
        print(f"  > Payload: {target_mb:.0f} MB/chunk")
        print(f"  > Pinned:  {target_mb:.0f} MB/chunk  x  depth {self._max_q_size}"
              f"  =  {target_mb * self._max_q_size:.0f} MB  [budget: {safe_mb:.0f} MB]")
        print(f"--------------------------------------------\n")


    def _detect_real_memory_limit(self) -> float:
        limits = []
        if 'SLURM_MEM_PER_NODE' in os.environ:
            try:   limits.append(float(os.environ['SLURM_MEM_PER_NODE']))
            except: pass
        if 'SLURM_MEM_PER_CPU' in os.environ and 'SLURM_CPUS_ON_NODE' in os.environ:
            try:   limits.append(float(os.environ['SLURM_MEM_PER_CPU']) *
                                 float(os.environ['SLURM_CPUS_ON_NODE']))
            except: pass
        for cg in ('/sys/fs/cgroup/memory/memory.limit_in_bytes',
                   '/sys/fs/cgroup/memory.max'):
            if os.path.exists(cg):
                try:
                    with open(cg) as f:
                        v = f.read().strip()
                    if v != 'max':
                        val = float(v)
                        if val < 1e15:
                            limits.append(val / (1024 ** 2))
                except: pass
        if psutil:
            limits.append(psutil.virtual_memory().total / (1024 ** 2))
        return min(limits) if limits else 4096.0

    def _detect_available_memory(self) -> float:
        if 'SLURM_MEM_PER_NODE' in os.environ or 'SLURM_MEM_PER_CPU' in os.environ:
            return self.sys_ram_limit_mb

        if (os.path.exists('/sys/fs/cgroup/memory.current') and
                os.path.exists('/sys/fs/cgroup/memory.max')):
            try:
                with open('/sys/fs/cgroup/memory.current') as f:
                    current = float(f.read().strip())
                with open('/sys/fs/cgroup/memory.max') as f:
                    v = f.read().strip()
                if v != 'max':
                    return max(0.0, (float(v) - current) / (1024 ** 2))
            except: pass

        if psutil:
            return psutil.virtual_memory().available / (1024 ** 2)

        return self.sys_ram_limit_mb * 0.50

    def _detect_vram(self) -> float:
        if HAS_CUPY:
            try:
                cupy.get_default_memory_pool().free_all_blocks()
                return float(cupy.cuda.Device(0).mem_info[1]) / (1024 * 1024)
            except: pass
        try:
            result = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
                encoding="utf-8"
            )
            return float(result.strip().split('\n')[0])
        except: return 4000.0


    def compute_block_size(self, n_genes: int, n_methods: int = 1) -> int:
        n_methods  = max(1, n_methods)
        acc_budget = self.vram_budget_bytes * 0.40
        coeff      = n_methods * 3 * 8

        best_bs = 64
        start_bs = max(((n_genes + 31) // 32) * 32, 64)

        for bs in range(start_bs, 63, -32):
            nb       = math.ceil(n_genes / bs)
            acc_vram = nb * coeff * bs * bs
            if acc_vram <= acc_budget:
                best_bs = bs
                break

        num_blocks               = math.ceil(n_genes / best_bs)
        self._acc_vram_reserved  = int(num_blocks * coeff * best_bs * best_bs)

        warn = ""
        if self._acc_vram_reserved > acc_budget:
            warn = "  [WARN: acc exceeds 40% budget -- minimum bs=64 enforced]"

        print(f"  > Block:   {best_bs} genes/block  x  {num_blocks} blocks  |  "
              f"Acc VRAM: {self._acc_vram_reserved / (1024**3):.2f} GB{warn}")
        return best_bs

    def get_coex_overhead(self, block_size: int, raw_n_genes: int) -> float:
        return max(1.2, 1.0 + 14.0 * block_size / raw_n_genes)


    @classmethod
    def from_h5ad(
        cls, filepath: str, mode: str = "auto",
        manual_target: int = 5000, data_path: str = 'X', **kwargs
    ):
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
        with h5py.File(filepath, "r") as f:
            if (data_path in f and isinstance(f[data_path], h5py.Group)
                    and 'indptr' in f[data_path]):
                indptr_loaded = f[data_path]['indptr'][:]
                if 'shape' in f[data_path].attrs:
                    shape      = f[data_path].attrs['shape']
                    total_rows = int(shape[0])
                    n_genes    = int(shape[1])
                else:
                    total_rows = len(indptr_loaded) - 1
                    var_path   = 'raw/var' if data_path == 'raw/X' else 'var'
                    n_genes    = len(f[var_path]) if var_path in f else 1


                try:
                    val_bytes = f[data_path]['data'].dtype.itemsize
                    idx_bytes = f[data_path]['indices'].dtype.itemsize
                    bpi       = val_bytes + idx_bytes + 4
                except Exception:
                    bpi = 16

                return cls(
                    indptr=indptr_loaded, total_rows=total_rows, n_genes=n_genes,
                    mode=mode, manual_target=manual_target, data_path=data_path,
                    bytes_per_item=bpi, **kwargs
                )
            else:
                raise ValueError(
                    f"ControlDevice requires SPARSE (CSR) data at '{data_path}'. "
                    f"Key 'indptr' not found."
                )


    def get_next_chunk(
        self,
        start_row:           int,
        mode:                str   = 'sparse',
        overhead_multiplier: float = 1.0,
        vram_reserve:        int   = 0
    ) -> int:
        if start_row >= self.total_rows:
            return None

        overhead_multiplier = max(overhead_multiplier, 1.0)
        effective_vram      = max(
            self.vram_budget_bytes - vram_reserve,
            self.vram_budget_bytes * 0.10
        )


        if self.mode == "manual" and self.manual_target > 0:
            active_target = float(self.manual_target) * 1024 * 1024
        else:
            active_target = (self.pcie_dense_target_bytes  if mode == 'dense'
                             else self.pcie_sparse_target_bytes)

        if mode == 'dense':
            bytes_per_row = self.n_genes * 8.0 * overhead_multiplier
            target_rows   = max(1, int(active_target / bytes_per_row))
            end_row       = start_row + target_rows
        else:
            max_items  = int((active_target / overhead_multiplier) / self.bytes_per_item)
            curr_ptr   = int(self.indptr[start_row])
            target_ptr = curr_ptr + max_items
            soft_limit = int(np.searchsorted(self.indptr, target_ptr, side='right')) - 1
            soft_limit = max(soft_limit, start_row + 1)
            end_row    = soft_limit

        end_row = min(end_row, self.total_rows)


        count = end_row - start_row
        if count > 32:
            end_row = start_row + (count // 32) * 32
        end_row = max(end_row, start_row + 1)


        chunk_rows = end_row - start_row

        if mode == 'dense':
            vram_cost = chunk_rows * self.n_genes * 8.0 * overhead_multiplier
            if vram_cost > effective_vram:
                bpr      = self.n_genes * 8.0 * overhead_multiplier
                max_rows = max(1, int(effective_vram / bpr))
                end_row  = start_row + max_rows
                count    = end_row - start_row
                if count > 32:
                    end_row = start_row + (count // 32) * 32
                end_row = max(end_row, start_row + 1)
        else:
            end_clamped = min(end_row, self.total_rows)
            actual_nnz  = int(self.indptr[end_clamped]) - int(self.indptr[start_row])
            sparse_cost = actual_nnz * 16.0 * overhead_multiplier
            if sparse_cost > effective_vram:
                ratio   = effective_vram / max(sparse_cost, 1.0)
                new_cnt = max(32, int(chunk_rows * ratio))
                end_row = start_row + new_cnt
                count   = end_row - start_row
                if count > 32:
                    end_row = start_row + (count // 32) * 32
                end_row = max(end_row, start_row + 1)

        return int(min(end_row, self.total_rows))


    def start_prefetcher(
        self,
        filepath:            str,
        fetch_mode:          str   = 'sparse',
        overhead_multiplier: float = 1.1,
        vram_reserve:        int   = 0,
        silent:              bool  = False
    ):
        self._stop_event.clear()

        q                    = queue.Queue(maxsize=self._max_q_size)
        self.prefetch_queue  = q

        active_target = (
            self.manual_target * 1024 * 1024 if self.mode == "manual"
            else (self.pcie_sparse_target_bytes if fetch_mode == 'sparse'
                  else self.pcie_dense_target_bytes)
        )
        chunk_mb = active_target / (1024 ** 2)

        if not silent:
            print(f"  > [Prefetcher]: {fetch_mode.upper()} | "
                  f"Depth: {self._max_q_size} | "
                  f"Pinned budget: {int(chunk_mb * self._max_q_size)} MB RAM")

        self.prefetch_thread = threading.Thread(
            target=self._prefetch_worker,
            args=(filepath, fetch_mode, overhead_multiplier, vram_reserve, q),
            daemon=True
        )
        self.prefetch_thread.start()

    def _prefetch_worker(
        self,
        filepath:            str,
        fetch_mode:          str,
        overhead_multiplier: float,
        vram_reserve:        int,
        out_queue:           queue.Queue
    ):
        try:
            with h5py.File(filepath, 'r') as f_in:
                h5_indptr  = f_in[self.data_path]['indptr']
                h5_data    = f_in[self.data_path]['data']
                h5_indices = f_in[self.data_path]['indices']

                curr_row = 0
                while curr_row < self.total_rows:


                    if self._stop_event.is_set():
                        break

                    next_row = self.get_next_chunk(
                        curr_row, mode=fetch_mode,
                        overhead_multiplier=overhead_multiplier,
                        vram_reserve=vram_reserve
                    )
                    if next_row is None or next_row <= curr_row:
                        break

                    s_idx      = int(h5_indptr[curr_row])
                    e_idx      = int(h5_indptr[next_row])
                    chunk_nnz  = int(e_idx - s_idx)
                    chunk_rows = int(next_row - curr_row) + 1

                    if chunk_nnz > 0:
                        alloc    = empty_pinned if empty_pinned is not None else np.empty
                        data_buf = alloc(chunk_nnz,  dtype=h5_data.dtype)
                        idx_buf  = alloc(chunk_nnz,  dtype=h5_indices.dtype)
                        ptr_buf  = alloc(chunk_rows,  dtype=h5_indptr.dtype)


                        _t_read_start = time.perf_counter()
                        h5_data.read_direct(   data_buf, np.s_[s_idx:e_idx],          np.s_[:chunk_nnz])
                        h5_indices.read_direct(idx_buf,  np.s_[s_idx:e_idx],          np.s_[:chunk_nnz])
                        h5_indptr.read_direct( ptr_buf,  np.s_[curr_row:next_row + 1], np.s_[:chunk_rows])
                        _read_seconds = time.perf_counter() - _t_read_start

                        _read_bytes = (
                            data_buf.nbytes + idx_buf.nbytes + ptr_buf.nbytes
                        )

                        ptr_buf -= ptr_buf[0]

                        payload = {
                            'status':       'OK',
                            'curr_row':     int(curr_row),
                            'next_row':     int(next_row),
                            'nnz':          chunk_nnz,
                            'rows':         chunk_rows,
                            'data':         data_buf,
                            'indices':      idx_buf,
                            'indptr':       ptr_buf,
                            'read_seconds': float(_read_seconds),
                            'read_bytes':   int(_read_bytes),
                        }
                    else:
                        payload = {
                            'status':       'OK',
                            'curr_row':     int(curr_row),
                            'next_row':     int(next_row),
                            'nnz':          0,
                            'rows':         chunk_rows,
                            'read_seconds': 0.0,
                            'read_bytes':   0,
                        }


                    out_queue.put(payload)
                    curr_row = next_row

            out_queue.put({'status': 'DONE'})

        except Exception as exc:
            try:
                out_queue.put({'status': 'ERROR', 'error': exc})
            except Exception:
                pass

    def get_prefetched_chunk(self) -> dict:
        if self.prefetch_queue is None:
            raise RuntimeError("Prefetcher not started -- call start_prefetcher() first.")
        payload = self.prefetch_queue.get()
        if payload['status'] == 'ERROR':
            raise payload['error']
        if payload['status'] == 'DONE':
            return None
        return payload


    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.shutdown()
        return False


    def shutdown(self):
        self._stop_event.set()
        if self.prefetch_thread and self.prefetch_thread.is_alive():

            try:
                while True:
                    self.prefetch_queue.get_nowait()
            except (queue.Empty, AttributeError):
                pass
            self.prefetch_thread.join(timeout=5.0)