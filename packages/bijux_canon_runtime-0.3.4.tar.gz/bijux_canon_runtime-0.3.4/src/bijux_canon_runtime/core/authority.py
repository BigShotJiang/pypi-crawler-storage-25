# SPDX-License-Identifier: Apache-2.0
# Copyright © 2026 Bijan Mousavi

"""Module definitions for core/authority.py."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import Literal, Protocol

from bijux_canon_runtime.core.errors import SemanticViolationError
from bijux_canon_runtime.core.verification_rules import default_rule_registry
from bijux_canon_runtime.model.artifact.artifact import Artifact
from bijux_canon_runtime.model.artifact.reasoning_claim import ReasoningClaim
from bijux_canon_runtime.model.artifact.retrieved_evidence import RetrievedEvidence
from bijux_canon_runtime.model.reasoning.bundle import ReasoningBundle
from bijux_canon_runtime.model.verification.verification import VerificationPolicy
from bijux_canon_runtime.model.verification.verification_arbitration import (
    VerificationArbitration,
)
from bijux_canon_runtime.model.verification.verification_result import (
    VerificationResult,
)
from bijux_canon_runtime.ontology import (
    VerificationPhase,
    VerificationRandomness,
)
from bijux_canon_runtime.ontology.ids import ArtifactID, ContentHash, EvidenceID, RuleID
from bijux_canon_runtime.ontology.public import EventType

SEMANTICS_VERSION = "v1"
SEMANTICS_SOURCE = "docs/guarantees/system_guarantees.md"

SEMANTIC_DOMAIN = "structural_truth"
VERIFICATION_DOMAIN = "epistemic_truth"

Mode = Literal["plan", "dry-run", "live", "observe", "unsafe"]


class _Event(Protocol):
    """Internal helper type; not part of the public API."""

    @property
    def event_type(self) -> EventType:
        """Event type for semantic checks."""
        ...


class _Trace(Protocol):
    """Internal helper type; not part of the public API."""

    @property
    def finalized(self) -> bool:
        """Whether the trace has been finalized."""
        ...

    @property
    def events(self) -> Sequence[_Event]:
        """Recorded execution events."""
        ...

    def finalize(self) -> object:
        """Freeze the trace in place."""
        ...


class _RunResult(Protocol):
    """Internal helper type; not part of the public API."""

    @property
    def trace(self) -> _Trace | None:
        """Returned execution trace."""
        ...

    @property
    def verification_results(self) -> Sequence[object]:
        """Per-step verification results."""
        ...

    @property
    def verification_arbitrations(self) -> Sequence[VerificationArbitration]:
        """Verification arbitration decisions."""
        ...

    @property
    def reasoning_bundles(self) -> Sequence[object]:
        """Reasoning bundles produced during execution."""
        ...


@dataclass(frozen=True)
class AuthorityToken:
    """Authority token; misuse breaks semantic enforcement."""

    scope: str = "bijux_canon_runtime.authority"


def authority_token() -> AuthorityToken:
    """Issue authority token; misuse breaks semantic enforcement."""
    return AuthorityToken()


def enforce_runtime_semantics(result: _RunResult, *, mode: Mode) -> None:
    """Enforce runtime semantics; misuse breaks execution guarantees."""
    if mode == "plan":
        return
    if mode == "unsafe":
        _require_trace_finalized(result)
        return
    _require_trace_finalized(result)
    if mode == "live":
        _require_verification_once_per_step(result)


def finalize_trace(trace: _Trace) -> None:
    """Finalize trace; misuse breaks immutability guarantees."""
    if object.__getattribute__(trace, "finalized"):
        raise SemanticViolationError("execution trace already finalized")
    trace.finalize()


def evaluate_verification(
    reasoning: ReasoningBundle,
    evidence: Sequence[RetrievedEvidence],
    artifacts: Sequence[Artifact],
    policy: VerificationPolicy,
) -> VerificationResult:
    """Evaluate verification; misuse breaks verification trust."""
    violations = _verification_violations(
        reasoning=reasoning,
        evidence=evidence,
        artifacts=artifacts,
        policy=policy,
    )
    status, reason = _verification_decision(violations=violations, policy=policy)
    return VerificationResult(
        spec_version="v1",
        engine_id="content",
        status=status,
        reason=reason,
        randomness=VerificationRandomness.DETERMINISTIC,
        violations=tuple(violations),
        checked_artifact_ids=(ArtifactID(str(reasoning.bundle_id)),),
        phase=VerificationPhase.POST_EXECUTION,
        rules_applied=tuple(rule.rule_id for rule in policy.rules),
        decision=status,
    )


def baseline_violations(
    reasoning: ReasoningBundle,
    evidence: Sequence[RetrievedEvidence],
    artifacts: Sequence[Artifact],
) -> tuple[RuleID, ...]:
    """Compute baseline violations; misuse breaks rule evaluation."""
    violations: list[RuleID] = []
    evidence_map = {item.evidence_id: item for item in evidence}
    artifact_hashes = {artifact.content_hash for artifact in artifacts}
    violations.extend(_claim_integrity_violations(reasoning, evidence_map))
    for claim in reasoning.claims:
        violations.extend(_claim_support_violations(claim, evidence_map))
        violations.extend(_claim_artifact_hash_violations(claim, artifact_hashes))
    return tuple(violations)


def _require_trace_finalized(result: _RunResult) -> None:
    """Internal helper; not part of the public API."""
    if result.trace is None:
        raise SemanticViolationError("execution trace must be returned for execution")
    if not result.trace.finalized:
        raise SemanticViolationError("execution trace must be finalized before return")


def _require_verification_once_per_step(result: _RunResult) -> None:
    """Internal helper; not part of the public API."""
    if _has_complete_verification_coverage(result):
        return
    trace = result.trace
    if trace is None:
        raise SemanticViolationError("verification must run exactly once per step")
    if not _has_verification_terminating_failure(trace.events):
        raise SemanticViolationError("verification must run exactly once per step")


def _has_event(events: Iterable[_Event], failure_events: set[EventType]) -> bool:
    """Internal helper; not part of the public API."""
    return any(event.event_type in failure_events for event in events)


def _verification_violations(
    *,
    reasoning: ReasoningBundle,
    evidence: Sequence[RetrievedEvidence],
    artifacts: Sequence[Artifact],
    policy: VerificationPolicy,
) -> list[RuleID]:
    """Internal helper; not part of the public API."""
    registry = default_rule_registry()
    violations, total_cost, randomness_violations = registry.evaluate(
        policy, reasoning, evidence, artifacts
    )
    if total_cost > policy.max_rule_cost:
        violations.append(RuleID("verification_cost_budget"))
    violations.extend(randomness_violations)
    return violations


def _verification_decision(
    *,
    violations: Sequence[RuleID],
    policy: VerificationPolicy,
) -> tuple[str, str]:
    """Internal helper; not part of the public API."""
    if not violations:
        return "PASS", "verification_passed"
    if any(rule_id in policy.fail_on for rule_id in violations):
        return "FAIL", "policy_fail_on"
    if any(rule_id in policy.escalate_on for rule_id in violations):
        return "ESCALATE", "policy_escalate_on"
    return "FAIL", "baseline_rule_violation"


def _claim_integrity_violations(
    reasoning: ReasoningBundle,
    evidence_map: dict[EvidenceID, RetrievedEvidence],
) -> tuple[RuleID, ...]:
    """Internal helper; not part of the public API."""
    violations: list[RuleID] = []
    if any(len(claim.supported_by) == 0 for claim in reasoning.claims):
        violations.append(RuleID("claim_requires_evidence"))
    if any(not (0.0 <= claim.confidence <= 1.0) for claim in reasoning.claims):
        violations.append(RuleID("confidence_in_range"))
    claim_ids = [claim.claim_id for claim in reasoning.claims]
    if len(set(claim_ids)) != len(claim_ids):
        violations.append(RuleID("unique_claim_ids"))
    if set(reasoning.evidence_ids) != set(evidence_map.keys()):
        violations.append(RuleID("bundle_evidence_ids_match_inputs"))
    return tuple(violations)


def _claim_support_violations(
    claim: ReasoningClaim,
    evidence_map: dict[EvidenceID, RetrievedEvidence],
) -> tuple[RuleID, ...]:
    """Internal helper; not part of the public API."""
    violations: list[RuleID] = []
    for evidence_id in claim.supported_by:
        evidence_item = evidence_map.get(evidence_id)
        if evidence_item is None:
            violations.append(RuleID("claim_supports_known_evidence"))
            continue
        if str(evidence_id) not in claim.statement:
            violations.append(RuleID("claim_mentions_evidence_id"))
        if str(evidence_item.content_hash) not in claim.statement:
            violations.append(RuleID("claim_mentions_evidence_hash"))
    return tuple(violations)


def _claim_artifact_hash_violations(
    claim: ReasoningClaim,
    artifact_hashes: set[ContentHash],
) -> tuple[RuleID, ...]:
    """Internal helper; not part of the public API."""
    if not artifact_hashes:
        return ()
    if any(str(artifact_hash) in claim.statement for artifact_hash in artifact_hashes):
        return ()
    return (RuleID("claim_mentions_artifact_hash"),)


def _has_complete_verification_coverage(result: _RunResult) -> bool:
    """Internal helper; not part of the public API."""
    reasoning_bundle_ids = {
        str(bundle.bundle_id)
        for bundle in result.reasoning_bundles
        if hasattr(bundle, "bundle_id")
    }
    if not reasoning_bundle_ids:
        return False
    arbitration_bundle_ids = {
        str(item)
        for arbitration in result.verification_arbitrations
        for item in arbitration.target_artifact_ids
    }
    return arbitration_bundle_ids.issuperset(reasoning_bundle_ids)


def _has_verification_terminating_failure(events: Iterable[_Event]) -> bool:
    """Internal helper; not part of the public API."""
    return _has_event(
        events,
        {
            EventType.REASONING_FAILED,
            EventType.RETRIEVAL_FAILED,
            EventType.STEP_FAILED,
        },
    )


__all__ = [
    "AuthorityToken",
    "Mode",
    "SEMANTIC_DOMAIN",
    "SEMANTICS_SOURCE",
    "SEMANTICS_VERSION",
    "VERIFICATION_DOMAIN",
    "authority_token",
    "baseline_violations",
    "enforce_runtime_semantics",
    "evaluate_verification",
    "finalize_trace",
]
