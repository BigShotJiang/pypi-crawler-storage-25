from __future__ import annotations

import pytest
import respx
import httpx


SAMPLE_PRODUCT = {
    "product_id": "us_sec",
    "display_name": "US SEC Filings",
    "category": "finance",
    "country": "us",
    "description": "SEC EDGAR filings",
    "record_count": 1000000,
    "is_active": True,
    "search_fields": ["company_name", "ticker"],
    "filter_fields": ["form_type", "year"],
}

SAMPLE_SCHEMA = {
    "product_id": "us_sec",
    "output_schema": [{"name": "company_name", "type": "string"}],
    "search_fields": ["company_name"],
    "filter_fields": ["form_type"],
}

SAMPLE_GROUP = {
    "group_id": "us_compliance",
    "display_name": "US Compliance",
    "description": "US compliance datasets",
    "products": ["us_sec", "us_edgar"],
}

SAMPLE_SEARCH_RESPONSE = {
    "status": "ok",
    "request_id": "req-123",
    "data": [{"id": "1", "name": "Tesla Inc"}],
    "_meta": {
        "total": 100,
        "returned": 1,
        "cursor": "next-cursor",
        "source": "upstream",
        "cached": False,
        "response_time_ms": 42,
    },
}

SAMPLE_SEARCH_LAST_PAGE = {
    "status": "ok",
    "request_id": "req-124",
    "data": [{"id": "2", "name": "Apple Inc"}],
    "_meta": {
        "total": 100,
        "returned": 1,
        "cursor": None,
        "source": "upstream",
        "cached": False,
        "response_time_ms": 38,
    },
}


def ok_response(data: object) -> dict:
    return {"status": "ok", "request_id": "req-abc", "data": data}


def error_response(code: str, message: str = "Error") -> dict:
    return {
        "status": "error",
        "request_id": "req-err",
        "error": {"code": code, "message": message, "details": {}},
    }


BASE_URL = "https://opendata.best/api/v1/data"
