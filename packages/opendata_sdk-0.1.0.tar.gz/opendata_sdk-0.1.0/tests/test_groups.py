from __future__ import annotations

import pytest
import respx
import httpx

from opendata import OpenData
from opendata.types import ProductGroup
from tests.conftest import BASE_URL, SAMPLE_GROUP, SAMPLE_SEARCH_RESPONSE, ok_response


@respx.mock
def test_groups_list() -> None:
    respx.get(f"{BASE_URL}/groups").mock(
        return_value=httpx.Response(200, json=ok_response([SAMPLE_GROUP]))
    )
    client = OpenData(api_key="pk_live_test")
    groups = client.groups.list()
    assert len(groups) == 1
    assert isinstance(groups[0], ProductGroup)
    assert groups[0].group_id == "us_compliance"


@respx.mock
def test_groups_get() -> None:
    respx.get(f"{BASE_URL}/groups/us_compliance").mock(
        return_value=httpx.Response(200, json=ok_response(SAMPLE_GROUP))
    )
    client = OpenData(api_key="pk_live_test")
    group = client.groups.get("us_compliance")
    assert isinstance(group, ProductGroup)
    assert group.display_name == "US Compliance"
    assert "us_sec" in group.products


@respx.mock
def test_groups_search() -> None:
    respx.get(f"{BASE_URL}/groups/us_compliance/search").mock(
        return_value=httpx.Response(200, json=SAMPLE_SEARCH_RESPONSE)
    )
    client = OpenData(api_key="pk_live_test")
    result = client.groups.search("us_compliance", q="bank")
    assert len(result.data) == 1
    assert result.meta.cursor == "next-cursor"


@respx.mock
def test_groups_list_empty() -> None:
    respx.get(f"{BASE_URL}/groups").mock(
        return_value=httpx.Response(200, json=ok_response([]))
    )
    client = OpenData(api_key="pk_live_test")
    assert client.groups.list() == []
