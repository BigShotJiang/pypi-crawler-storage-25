from __future__ import annotations

import pytest
import respx
import httpx

from opendata import OpenData
from opendata._exceptions import (
    AuthenticationError,
    PermissionError,
    NotFoundError,
    RateLimitError,
    UpstreamError,
    APIError,
    OpenDataError,
)
from tests.conftest import BASE_URL, error_response


ERROR_CODE_CASES = [
    ("AUTH_REQUIRED", 401, AuthenticationError),
    ("AUTH_INVALID", 401, AuthenticationError),
    ("PRODUCT_ACCESS_DENIED", 403, PermissionError),
    ("EXPORT_NOT_ENABLED", 403, PermissionError),
    ("PRODUCT_NOT_FOUND", 404, NotFoundError),
    ("QUOTA_EXCEEDED_DAILY", 429, RateLimitError),
    ("QUOTA_EXCEEDED_MONTHLY", 429, RateLimitError),
    ("UPSTREAM_ERROR", 502, UpstreamError),
    ("UPSTREAM_TIMEOUT", 504, UpstreamError),
    ("UPSTREAM_RATE_LIMITED", 429, UpstreamError),
    ("UPSTREAM_UNAVAILABLE", 503, UpstreamError),
    ("INTERNAL_ERROR", 500, APIError),
]


@pytest.mark.parametrize("code,status,exc_class", ERROR_CODE_CASES)
@respx.mock
def test_error_mapping(code: str, status: int, exc_class: type) -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(status, json=error_response(code, f"{code} error"))
    )
    client = OpenData(api_key="pk_live_test", max_retries=0)
    with pytest.raises(exc_class) as exc_info:
        client.products.list()
    assert exc_info.value.message == f"{code} error"
    assert exc_info.value.request_id == "req-err"


@respx.mock
def test_rate_limit_daily_quota_type() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(429, json=error_response("QUOTA_EXCEEDED_DAILY"))
    )
    client = OpenData(api_key="pk_live_test", max_retries=0)
    with pytest.raises(RateLimitError) as exc_info:
        client.products.list()
    assert exc_info.value.quota_type == "daily"


@respx.mock
def test_rate_limit_monthly_quota_type() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(429, json=error_response("QUOTA_EXCEEDED_MONTHLY"))
    )
    client = OpenData(api_key="pk_live_test", max_retries=0)
    with pytest.raises(RateLimitError) as exc_info:
        client.products.list()
    assert exc_info.value.quota_type == "monthly"


@respx.mock
def test_rate_limit_retry_after_header() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(
            429,
            json=error_response("QUOTA_EXCEEDED_DAILY"),
            headers={"Retry-After": "60"},
        )
    )
    client = OpenData(api_key="pk_live_test", max_retries=0)
    with pytest.raises(RateLimitError) as exc_info:
        client.products.list()
    assert exc_info.value.retry_after == 60.0


@respx.mock
def test_api_error_includes_status_code() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(500, json=error_response("INTERNAL_ERROR", "Server blew up"))
    )
    client = OpenData(api_key="pk_live_test", max_retries=0)
    with pytest.raises(APIError) as exc_info:
        client.products.list()
    assert exc_info.value.status_code == 500


@respx.mock
def test_unknown_error_code_raises_api_error() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(500, json=error_response("UNKNOWN_CODE"))
    )
    client = OpenData(api_key="pk_live_test", max_retries=0)
    with pytest.raises(APIError):
        client.products.list()


@respx.mock
def test_all_errors_are_opendata_error_subclass() -> None:
    for code, status, exc_class in ERROR_CODE_CASES:
        respx.get(f"{BASE_URL}/products").mock(
            return_value=httpx.Response(status, json=error_response(code))
        )
        client = OpenData(api_key="pk_live_test", max_retries=0)
        with pytest.raises(OpenDataError):
            client.products.list()
