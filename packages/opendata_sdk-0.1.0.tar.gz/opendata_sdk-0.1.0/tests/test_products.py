from __future__ import annotations

import pytest
import respx
import httpx

from opendata import OpenData
from opendata.types import Product, ProductSchema
from tests.conftest import (
    BASE_URL,
    SAMPLE_PRODUCT,
    SAMPLE_SCHEMA,
    SAMPLE_SEARCH_RESPONSE,
    ok_response,
)


@respx.mock
def test_products_list_returns_products() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(200, json=ok_response([SAMPLE_PRODUCT]))
    )
    client = OpenData(api_key="pk_live_test")
    products = client.products.list()
    assert len(products) == 1
    assert isinstance(products[0], Product)
    assert products[0].product_id == "us_sec"
    assert products[0].display_name == "US SEC Filings"


@respx.mock
def test_products_list_empty() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(200, json=ok_response([]))
    )
    client = OpenData(api_key="pk_live_test")
    assert client.products.list() == []


@respx.mock
def test_products_get_returns_product() -> None:
    respx.get(f"{BASE_URL}/products/us_sec").mock(
        return_value=httpx.Response(200, json=ok_response(SAMPLE_PRODUCT))
    )
    client = OpenData(api_key="pk_live_test")
    product = client.products.get("us_sec")
    assert isinstance(product, Product)
    assert product.product_id == "us_sec"
    assert product.country == "us"


@respx.mock
def test_products_schema() -> None:
    respx.get(f"{BASE_URL}/products/us_sec/schema").mock(
        return_value=httpx.Response(200, json=ok_response(SAMPLE_SCHEMA))
    )
    client = OpenData(api_key="pk_live_test")
    schema = client.products.schema("us_sec")
    assert isinstance(schema, ProductSchema)
    assert schema.product_id == "us_sec"
    assert "company_name" in schema.search_fields


@respx.mock
def test_products_search_returns_result() -> None:
    respx.get(f"{BASE_URL}/products/us_sec/search").mock(
        return_value=httpx.Response(200, json=SAMPLE_SEARCH_RESPONSE)
    )
    client = OpenData(api_key="pk_live_test")
    result = client.products.search("us_sec", q="Tesla")
    assert len(result.data) == 1
    assert result.data[0]["name"] == "Tesla Inc"
    assert result.meta.total == 100
    assert result.meta.cursor == "next-cursor"


@respx.mock
def test_products_search_passes_query_params() -> None:
    respx.get(f"{BASE_URL}/products/us_sec/search").mock(
        return_value=httpx.Response(200, json=SAMPLE_SEARCH_RESPONSE)
    )
    client = OpenData(api_key="pk_live_test")
    client.products.search("us_sec", q="Tesla", limit=25, cursor="abc123")
    request = respx.calls.last.request
    url = str(request.url)
    assert "q=Tesla" in url
    assert "limit=25" in url
    assert "cursor=abc123" in url


@respx.mock
def test_products_export() -> None:
    records = [{"id": "1"}, {"id": "2"}]
    respx.get(f"{BASE_URL}/products/us_sec/export").mock(
        return_value=httpx.Response(200, json=ok_response(records))
    )
    client = OpenData(api_key="pk_live_test")
    data = client.products.export("us_sec", format="json", limit=100)
    assert len(data) == 2
