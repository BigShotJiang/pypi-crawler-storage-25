from __future__ import annotations

import pytest
import respx
import httpx

from opendata import OpenData, AsyncOpenData
from opendata._constants import DEFAULT_BASE_URL, USER_AGENT
from tests.conftest import BASE_URL, ok_response


def test_client_init_requires_api_key() -> None:
    with pytest.raises((ValueError, TypeError)):
        OpenData(api_key="")  # type: ignore[arg-type]


def test_client_default_base_url() -> None:
    client = OpenData(api_key="pk_live_test")
    assert client._config.base_url == DEFAULT_BASE_URL


def test_client_custom_base_url() -> None:
    custom = "https://staging.opendata.best/api/v1/data"
    client = OpenData(api_key="pk_live_test", base_url=custom)
    assert client._config.base_url == custom


def test_client_strips_trailing_slash() -> None:
    client = OpenData(api_key="pk_live_test", base_url="https://opendata.best/api/v1/data/")
    assert not client._config.base_url.endswith("/")


@respx.mock
def test_auth_header_sent() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(200, json=ok_response([]))
    )
    client = OpenData(api_key="pk_live_mykey")
    client.products.list()
    request = respx.calls.last.request
    assert request.headers["X-API-Key"] == "pk_live_mykey"


@respx.mock
def test_user_agent_sent() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(200, json=ok_response([]))
    )
    client = OpenData(api_key="pk_live_mykey")
    client.products.list()
    request = respx.calls.last.request
    assert request.headers["User-Agent"] == USER_AGENT


@respx.mock
def test_quota_updated_from_headers() -> None:
    headers = {
        "X-RateLimit-Limit-Daily": "200",
        "X-RateLimit-Remaining-Daily": "198",
        "X-RateLimit-Limit-Monthly": "2000",
        "X-RateLimit-Remaining-Monthly": "1995",
        "X-RateLimit-Plan": "starter",
    }
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(200, json=ok_response([]), headers=headers)
    )
    client = OpenData(api_key="pk_live_test")
    client.products.list()
    assert client.quota is not None
    assert client.quota.daily_limit == 200
    assert client.quota.daily_remaining == 198
    assert client.quota.monthly_limit == 2000
    assert client.quota.monthly_remaining == 1995
    assert client.quota.plan == "starter"


def test_context_manager_closes_client() -> None:
    with OpenData(api_key="pk_live_test") as client:
        assert client._http is not None
    # just ensure no exception is raised


@pytest.mark.asyncio
async def test_async_context_manager() -> None:
    async with AsyncOpenData(api_key="pk_live_test") as client:
        assert client._http is not None
