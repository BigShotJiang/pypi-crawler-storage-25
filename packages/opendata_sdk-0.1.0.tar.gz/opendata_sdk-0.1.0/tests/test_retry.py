from __future__ import annotations

import pytest
import respx
import httpx
from unittest.mock import patch

from opendata import OpenData
from opendata._exceptions import APIError
from tests.conftest import BASE_URL, ok_response, error_response


@respx.mock
def test_retries_on_500() -> None:
    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            return httpx.Response(500, json=error_response("INTERNAL_ERROR"))
        return httpx.Response(200, json=ok_response([]))

    respx.get(f"{BASE_URL}/products").mock(side_effect=handler)

    with patch("time.sleep"):
        client = OpenData(api_key="pk_live_test", max_retries=3)
        result = client.products.list()

    assert result == []
    assert call_count == 3


@respx.mock
def test_retries_on_502() -> None:
    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(502, json={"status": "error"})
        return httpx.Response(200, json=ok_response([]))

    respx.get(f"{BASE_URL}/products").mock(side_effect=handler)

    with patch("time.sleep"):
        client = OpenData(api_key="pk_live_test", max_retries=3)
        client.products.list()

    assert call_count == 2


@respx.mock
def test_retries_on_429() -> None:
    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(
                429,
                json=error_response("QUOTA_EXCEEDED_DAILY"),
                headers={"Retry-After": "1"},
            )
        return httpx.Response(200, json=ok_response([]))

    respx.get(f"{BASE_URL}/products").mock(side_effect=handler)

    with patch("time.sleep"):
        client = OpenData(api_key="pk_live_test", max_retries=3)
        client.products.list()

    assert call_count == 2


@respx.mock
def test_no_retry_on_404() -> None:
    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        return httpx.Response(404, json=error_response("PRODUCT_NOT_FOUND"))

    respx.get(f"{BASE_URL}/products/missing").mock(side_effect=handler)

    from opendata._exceptions import NotFoundError
    client = OpenData(api_key="pk_live_test", max_retries=3)
    with pytest.raises(NotFoundError):
        client.products.get("missing")

    assert call_count == 1


@respx.mock
def test_no_retry_on_401() -> None:
    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        return httpx.Response(401, json=error_response("AUTH_INVALID"))

    respx.get(f"{BASE_URL}/products").mock(side_effect=handler)

    from opendata._exceptions import AuthenticationError
    client = OpenData(api_key="pk_live_test", max_retries=3)
    with pytest.raises(AuthenticationError):
        client.products.list()

    assert call_count == 1


@respx.mock
def test_exhausted_retries_raises_last_error() -> None:
    respx.get(f"{BASE_URL}/products").mock(
        return_value=httpx.Response(500, json=error_response("INTERNAL_ERROR", "still broken"))
    )

    with patch("time.sleep"):
        client = OpenData(api_key="pk_live_test", max_retries=2)
        with pytest.raises(APIError) as exc_info:
            client.products.list()

    assert exc_info.value.message == "still broken"


def test_timeout_raises_after_retries() -> None:
    with respx.mock:
        respx.get(f"{BASE_URL}/products").mock(side_effect=httpx.ReadTimeout("timed out"))

        with patch("time.sleep"):
            client = OpenData(api_key="pk_live_test", max_retries=2)
            with pytest.raises(httpx.ReadTimeout):
                client.products.list()
