from __future__ import annotations

import pytest
import respx
import httpx

from opendata import OpenData
from tests.conftest import BASE_URL, SAMPLE_SEARCH_RESPONSE, SAMPLE_SEARCH_LAST_PAGE


@respx.mock
def test_search_all_iterates_multiple_pages() -> None:
    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(200, json=SAMPLE_SEARCH_RESPONSE)
        return httpx.Response(200, json=SAMPLE_SEARCH_LAST_PAGE)

    respx.get(f"{BASE_URL}/products/us_sec/search").mock(side_effect=handler)

    client = OpenData(api_key="pk_live_test")
    items = list(client.products.search_all("us_sec", q="Tesla"))
    assert len(items) == 2
    assert items[0]["name"] == "Tesla Inc"
    assert items[1]["name"] == "Apple Inc"
    assert call_count == 2


@respx.mock
def test_search_all_stops_on_null_cursor() -> None:
    single_page = {
        "status": "ok",
        "request_id": "req-1",
        "data": [{"id": "1"}],
        "_meta": {"total": 1, "returned": 1, "cursor": None},
    }
    respx.get(f"{BASE_URL}/products/us_sec/search").mock(
        return_value=httpx.Response(200, json=single_page)
    )
    client = OpenData(api_key="pk_live_test")
    items = list(client.products.search_all("us_sec"))
    assert len(items) == 1


@respx.mock
def test_search_all_passes_cursor_on_subsequent_pages() -> None:
    responses = [
        {
            "status": "ok",
            "request_id": "r1",
            "data": [{"id": "1"}],
            "_meta": {"total": 2, "returned": 1, "cursor": "page2cursor"},
        },
        {
            "status": "ok",
            "request_id": "r2",
            "data": [{"id": "2"}],
            "_meta": {"total": 2, "returned": 1, "cursor": None},
        },
    ]
    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        resp = responses[call_count]
        call_count += 1
        return httpx.Response(200, json=resp)

    respx.get(f"{BASE_URL}/products/us_sec/search").mock(side_effect=handler)

    client = OpenData(api_key="pk_live_test")
    items = list(client.products.search_all("us_sec"))
    assert len(items) == 2
    # Verify second call had cursor in query
    second_call_url = str(respx.calls[1].request.url)
    assert "cursor=page2cursor" in second_call_url


@respx.mock
def test_groups_search_all_paginates() -> None:
    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(200, json=SAMPLE_SEARCH_RESPONSE)
        return httpx.Response(200, json=SAMPLE_SEARCH_LAST_PAGE)

    respx.get(f"{BASE_URL}/groups/us_compliance/search").mock(side_effect=handler)

    client = OpenData(api_key="pk_live_test")
    items = list(client.groups.search_all("us_compliance", q="bank"))
    assert len(items) == 2
    assert call_count == 2


@pytest.mark.asyncio
@respx.mock
async def test_async_search_all_paginates() -> None:
    from opendata import AsyncOpenData

    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(200, json=SAMPLE_SEARCH_RESPONSE)
        return httpx.Response(200, json=SAMPLE_SEARCH_LAST_PAGE)

    respx.get(f"{BASE_URL}/products/us_sec/search").mock(side_effect=handler)

    async with AsyncOpenData(api_key="pk_live_test") as client:
        items = [item async for item in client.products.search_all("us_sec", q="Tesla")]

    assert len(items) == 2
    assert call_count == 2
