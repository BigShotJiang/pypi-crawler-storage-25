# opendata-sdk — Python

Official Python SDK for the [opendata.best](https://opendata.best) data API.

## Installation

```bash
pip install opendata-sdk
```

## Quick Start

```python
from opendata import OpenData

client = OpenData(api_key="pk_live_xxx")

# List products
products = client.products.list()

# Search
page = client.products.search("us_sec", q="Tesla", limit=50)
print(page.meta.total)  # total results
for item in page.data:
    print(item)

# Auto-paginate
for record in client.products.search_all("us_sec", q="Tesla"):
    print(record)

# Export
data = client.products.export("us_sec", format="json", limit=5000)

# Groups
groups = client.groups.list()
results = client.groups.search("us_compliance", q="bank")

# Quota info
print(client.quota)
```

## Async

```python
from opendata import AsyncOpenData

async with AsyncOpenData(api_key="pk_live_xxx") as client:
    products = await client.products.list()

    async for item in client.products.search_all("us_sec", q="Tesla"):
        print(item)
```

## Error Handling

```python
from opendata import OpenData
from opendata import AuthenticationError, NotFoundError, RateLimitError

client = OpenData(api_key="pk_live_xxx")

try:
    product = client.products.get("unknown")
except NotFoundError as e:
    print(f"Not found: {e.message}")
except RateLimitError as e:
    print(f"Quota exceeded ({e.quota_type}), retry after {e.retry_after}s")
except AuthenticationError as e:
    print(f"Auth failed: {e.message}")
```

## License

MIT
