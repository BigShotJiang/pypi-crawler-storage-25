from __future__ import annotations

from typing import Any, Optional


class OpenDataError(Exception):
    """Base error for all SDK errors."""

    message: str
    request_id: Optional[str]

    def __init__(self, message: str, request_id: Optional[str] = None) -> None:
        super().__init__(message)
        self.message = message
        self.request_id = request_id

    def __repr__(self) -> str:
        return f"{type(self).__name__}(message={self.message!r}, request_id={self.request_id!r})"


class AuthenticationError(OpenDataError):
    """Raised for AUTH_REQUIRED and AUTH_INVALID errors."""


class PermissionError(OpenDataError):
    """Raised for PRODUCT_ACCESS_DENIED and EXPORT_NOT_ENABLED errors."""


class NotFoundError(OpenDataError):
    """Raised when the requested product or resource is not found."""


class RateLimitError(OpenDataError):
    """Raised when a quota is exceeded (daily or monthly)."""

    retry_after: Optional[float]
    quota_type: str  # "daily" | "monthly"

    def __init__(
        self,
        message: str,
        request_id: Optional[str] = None,
        retry_after: Optional[float] = None,
        quota_type: str = "daily",
    ) -> None:
        super().__init__(message, request_id)
        self.retry_after = retry_after
        self.quota_type = quota_type


class UpstreamError(OpenDataError):
    """Raised for upstream provider errors (timeout, rate-limited, unavailable)."""


class APIError(OpenDataError):
    """Raised for internal errors or unexpected API responses."""

    status_code: int

    def __init__(
        self,
        message: str,
        status_code: int,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message, request_id)
        self.status_code = status_code


_ERROR_CODE_MAP: dict[str, type[OpenDataError]] = {
    "AUTH_REQUIRED": AuthenticationError,
    "AUTH_INVALID": AuthenticationError,
    "PRODUCT_ACCESS_DENIED": PermissionError,
    "EXPORT_NOT_ENABLED": PermissionError,
    "PRODUCT_NOT_FOUND": NotFoundError,
    "QUOTA_EXCEEDED_DAILY": RateLimitError,
    "QUOTA_EXCEEDED_MONTHLY": RateLimitError,
    "UPSTREAM_ERROR": UpstreamError,
    "UPSTREAM_TIMEOUT": UpstreamError,
    "UPSTREAM_RATE_LIMITED": UpstreamError,
    "UPSTREAM_UNAVAILABLE": UpstreamError,
    "INTERNAL_ERROR": APIError,
}


def map_error(
    code: str,
    message: str,
    status_code: int,
    request_id: Optional[str] = None,
    retry_after: Optional[float] = None,
) -> OpenDataError:
    """Map an API error code to the appropriate exception class.

    Args:
        code: The API error code string.
        message: Human-readable error message.
        status_code: HTTP status code of the response.
        request_id: Request ID from response, if available.
        retry_after: Seconds to wait before retrying, if applicable.

    Returns:
        An instance of the appropriate OpenDataError subclass.
    """
    cls = _ERROR_CODE_MAP.get(code, APIError)
    if cls is RateLimitError:
        quota_type = "monthly" if "MONTHLY" in code else "daily"
        return RateLimitError(
            message,
            request_id=request_id,
            retry_after=retry_after,
            quota_type=quota_type,
        )
    if cls is APIError:
        return APIError(message, status_code=status_code, request_id=request_id)
    return cls(message, request_id=request_id)
