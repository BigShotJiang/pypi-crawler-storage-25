from __future__ import annotations

from typing import Any, Optional
from pydantic import BaseModel, Field


class ErrorDetail(BaseModel):
    """Structured error detail from the API."""

    code: str
    message: str
    details: dict[str, Any] = Field(default_factory=dict)


class ApiResponse(BaseModel):
    """Generic API response envelope."""

    status: str
    request_id: Optional[str] = None
    data: Optional[Any] = None
    error: Optional[ErrorDetail] = None


class QuotaInfo(BaseModel):
    """Rate-limit quota information extracted from response headers."""

    daily_limit: Optional[int] = None
    daily_remaining: Optional[int] = None
    monthly_limit: Optional[int] = None
    monthly_remaining: Optional[int] = None
    plan: Optional[str] = None


class PaginatedResponse(BaseModel):
    """Generic paginated response."""

    data: list[Any] = Field(default_factory=list)
    meta: dict[str, Any] = Field(default_factory=dict)
