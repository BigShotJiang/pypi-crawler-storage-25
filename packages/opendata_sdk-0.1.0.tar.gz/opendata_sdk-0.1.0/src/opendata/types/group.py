from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class ProductGroup(BaseModel):
    """A named group of related data products."""

    group_id: str
    display_name: str
    description: Optional[str] = None
    products: list[str] = Field(default_factory=list)
