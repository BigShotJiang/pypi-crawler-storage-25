from __future__ import annotations

from typing import Any, Optional
from pydantic import BaseModel, Field


class SearchMeta(BaseModel):
    """Pagination and performance metadata for a search response."""

    total: Optional[int] = None
    returned: int = 0
    cursor: Optional[str] = None
    source: Optional[str] = None
    cached: bool = False
    response_time_ms: Optional[int] = None
    data_freshness: Optional[str] = None
    api_version: Optional[str] = None


class SearchResult(BaseModel):
    """A page of search results with pagination metadata."""

    data: list[dict[str, Any]] = Field(default_factory=list)
    meta: SearchMeta = Field(default_factory=SearchMeta)
