from __future__ import annotations

from typing import Any, Optional
from pydantic import BaseModel, Field


class Product(BaseModel):
    """Metadata for a single data product."""

    product_id: str
    display_name: str
    category: Optional[str] = None
    country: Optional[str] = None
    description: Optional[str] = None
    record_count: Optional[int] = None
    is_active: bool = True
    search_fields: list[str] = Field(default_factory=list)
    filter_fields: list[str] = Field(default_factory=list)


class ProductSchema(BaseModel):
    """Schema and filter metadata for a data product."""

    product_id: str
    output_schema: list[dict[str, Any]] = Field(default_factory=list)
    search_fields: list[str] = Field(default_factory=list)
    filter_fields: list[str] = Field(default_factory=list)


class ProductStats(BaseModel):
    """Usage statistics for a data product."""

    product_id: str
    total_requests: Optional[int] = None
    last_accessed: Optional[str] = None
