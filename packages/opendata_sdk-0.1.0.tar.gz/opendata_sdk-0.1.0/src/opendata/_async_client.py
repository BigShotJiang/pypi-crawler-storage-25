from __future__ import annotations

import asyncio
from typing import Any, Optional

import httpx

from ._base_client import BaseClientConfig, _retry_delay
from ._constants import DEFAULT_BASE_URL, DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT
from .resources.products import AsyncProducts
from .resources.groups import AsyncGroups
from .types.common import QuotaInfo


class AsyncOpenData:
    """Asynchronous client for the opendata.best API.

    Args:
        api_key: Your API key (e.g. ``pk_live_xxx``).
        base_url: Override the default API base URL.
        timeout: Request timeout in seconds (default: 30).
        max_retries: Maximum retry attempts on transient errors (default: 3).

    Example::

        async with AsyncOpenData(api_key="pk_live_xxx") as client:
            products = await client.products.list()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._config = BaseClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.AsyncClient(timeout=timeout)
        self.products = AsyncProducts(self)
        self.groups = AsyncGroups(self)

    @property
    def quota(self) -> Optional[QuotaInfo]:
        """Last known quota information from response headers."""
        return self._config.quota

    async def _request(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
        raw: bool = False,
    ) -> Any:
        """Execute an async HTTP request with retry logic.

        Args:
            method: HTTP method string (e.g. ``"GET"``).
            path: URL path relative to the base URL.
            params: Optional query parameters.
            raw: If True return the full parsed JSON body.

        Returns:
            Parsed response data.
        """
        url = f"{self._config.base_url}{path}"
        headers = self._config._build_headers()
        clean_params = {k: v for k, v in (params or {}).items() if v is not None}

        last_exc: Optional[Exception] = None
        for attempt in range(self._config.max_retries + 1):
            try:
                response = await self._http.request(
                    method,
                    url,
                    params=clean_params or None,
                    headers=headers,
                )
            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < self._config.max_retries:
                    await asyncio.sleep(_retry_delay(attempt))
                    continue
                raise

            if self._config._should_retry(response) and attempt < self._config.max_retries:
                retry_after = self._config._get_retry_after(response)
                await asyncio.sleep(_retry_delay(attempt, retry_after))
                continue

            return self._config._parse_response(response, raw=raw)

        if last_exc is not None:
            raise last_exc
        raise RuntimeError("Unexpected retry loop exit")  # pragma: no cover

    async def close(self) -> None:
        """Close the underlying async HTTP client."""
        await self._http.aclose()

    async def __aenter__(self) -> AsyncOpenData:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
