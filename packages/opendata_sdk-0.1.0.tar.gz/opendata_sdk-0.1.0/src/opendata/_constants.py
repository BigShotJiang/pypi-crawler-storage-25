from __future__ import annotations

from ._version import __version__

DEFAULT_BASE_URL = "https://opendata.best/api/v1/data"
VERSION = __version__
USER_AGENT = f"opendata-sdk-python/{VERSION}"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3
RETRY_STATUS_CODES = {429, 500, 502, 503}
NO_RETRY_STATUS_CODES = {400, 401, 403, 404}
