from __future__ import annotations

import time
import random
import logging
from typing import Any, Optional

import httpx

from ._constants import DEFAULT_BASE_URL, DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT, RETRY_STATUS_CODES, USER_AGENT
from ._exceptions import APIError, map_error
from .types.common import QuotaInfo

logger = logging.getLogger("opendata")


def _build_quota_info(headers: httpx.Headers) -> QuotaInfo:
    """Extract quota information from rate-limit response headers.

    Args:
        headers: HTTP response headers.

    Returns:
        A QuotaInfo instance populated from available headers.
    """

    def _int(key: str) -> Optional[int]:
        val = headers.get(key)
        try:
            return int(val) if val is not None else None
        except (ValueError, TypeError):
            return None

    return QuotaInfo(
        daily_limit=_int("X-RateLimit-Limit-Daily"),
        daily_remaining=_int("X-RateLimit-Remaining-Daily"),
        monthly_limit=_int("X-RateLimit-Limit-Monthly"),
        monthly_remaining=_int("X-RateLimit-Remaining-Monthly"),
        plan=headers.get("X-RateLimit-Plan"),
    )


def _retry_delay(attempt: int, retry_after: Optional[float] = None) -> float:
    """Calculate exponential backoff delay with jitter.

    Args:
        attempt: Zero-based retry attempt number.
        retry_after: Optional server-provided retry delay in seconds.

    Returns:
        Seconds to wait before the next attempt.
    """
    if retry_after is not None:
        return retry_after
    base = 0.5 * (2 ** attempt)
    jitter = random.uniform(0, base * 0.1)
    return base + jitter


class BaseClientConfig:
    """Shared configuration for sync and async clients.

    Args:
        api_key: API key used for authentication.
        base_url: Base URL for the API.
        timeout: Request timeout in seconds.
        max_retries: Maximum number of retry attempts on transient errors.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        if not api_key:
            raise ValueError("api_key must not be empty")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._quota: Optional[QuotaInfo] = None

    @property
    def quota(self) -> Optional[QuotaInfo]:
        """Last known quota information extracted from response headers."""
        return self._quota

    def _build_headers(self) -> dict[str, str]:
        return {
            "X-API-Key": self.api_key,
            "Accept": "application/json",
            "User-Agent": USER_AGENT,
        }

    def _parse_response(
        self,
        response: httpx.Response,
        raw: bool = False,
    ) -> Any:
        """Parse an httpx.Response, update quota info, and raise on errors.

        Args:
            response: The HTTP response to parse.
            raw: If True, return the full parsed JSON dict rather than ``data``.

        Returns:
            The ``data`` field of a successful response, or the full dict when raw=True.

        Raises:
            Various OpenDataError subclasses on error responses.
        """
        self._quota = _build_quota_info(response.headers)

        try:
            body: dict[str, Any] = response.json()
        except Exception as exc:
            raise APIError(
                f"Failed to parse response body: {exc}",
                status_code=response.status_code,
            ) from exc

        request_id: Optional[str] = body.get("request_id")

        if body.get("status") == "error":
            error = body.get("error") or {}
            code = error.get("code", "INTERNAL_ERROR")
            message = error.get("message", "Unknown error")
            retry_after: Optional[float] = None
            ra_header = response.headers.get("Retry-After")
            if ra_header:
                try:
                    retry_after = float(ra_header)
                except (ValueError, TypeError):
                    pass
            raise map_error(
                code=code,
                message=message,
                status_code=response.status_code,
                request_id=request_id,
                retry_after=retry_after,
            )

        if response.status_code >= 400:
            raise APIError(
                f"HTTP {response.status_code}",
                status_code=response.status_code,
                request_id=request_id,
            )

        if raw:
            return body

        return body.get("data")

    def _should_retry(self, response: httpx.Response) -> bool:
        return response.status_code in RETRY_STATUS_CODES

    def _get_retry_after(self, response: httpx.Response) -> Optional[float]:
        ra = response.headers.get("Retry-After")
        if ra:
            try:
                return float(ra)
            except (ValueError, TypeError):
                pass
        return None
