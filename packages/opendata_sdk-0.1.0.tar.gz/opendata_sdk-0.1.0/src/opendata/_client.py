from __future__ import annotations

from typing import Any, Optional

import httpx

from ._base_client import BaseClientConfig, _retry_delay
from ._constants import DEFAULT_BASE_URL, DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT
from .resources.products import Products
from .resources.groups import Groups
from .types.common import QuotaInfo


class OpenData:
    """Synchronous client for the opendata.best API.

    Args:
        api_key: Your API key (e.g. ``pk_live_xxx``).
        base_url: Override the default API base URL.
        timeout: Request timeout in seconds (default: 30).
        max_retries: Maximum retry attempts on transient errors (default: 3).

    Example::

        client = OpenData(api_key="pk_live_xxx")
        products = client.products.list()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._config = BaseClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.Client(timeout=timeout)
        self.products = Products(self)
        self.groups = Groups(self)

    @property
    def quota(self) -> Optional[QuotaInfo]:
        """Last known quota information from response headers."""
        return self._config.quota

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
        raw: bool = False,
    ) -> Any:
        """Execute an HTTP request with retry logic.

        Args:
            method: HTTP method string (e.g. ``"GET"``).
            path: URL path relative to the base URL.
            params: Optional query parameters.
            raw: If True return the full parsed JSON body.

        Returns:
            Parsed response data.
        """
        url = f"{self._config.base_url}{path}"
        headers = self._config._build_headers()
        clean_params = {k: v for k, v in (params or {}).items() if v is not None}

        last_exc: Optional[Exception] = None
        for attempt in range(self._config.max_retries + 1):
            try:
                response = self._http.request(
                    method,
                    url,
                    params=clean_params or None,
                    headers=headers,
                )
            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < self._config.max_retries:
                    import time
                    time.sleep(_retry_delay(attempt))
                    continue
                raise

            if self._config._should_retry(response) and attempt < self._config.max_retries:
                retry_after = self._config._get_retry_after(response)
                import time
                time.sleep(_retry_delay(attempt, retry_after))
                continue

            return self._config._parse_response(response, raw=raw)

        if last_exc is not None:
            raise last_exc
        raise RuntimeError("Unexpected retry loop exit")  # pragma: no cover

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> OpenData:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
