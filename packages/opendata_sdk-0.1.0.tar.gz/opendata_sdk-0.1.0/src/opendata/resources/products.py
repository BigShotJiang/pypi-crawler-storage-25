from __future__ import annotations

from typing import Any, Iterator, Optional, TYPE_CHECKING

from ..types.product import Product, ProductSchema
from ..types.search import SearchMeta, SearchResult

if TYPE_CHECKING:
    from .._client import OpenData
    from .._async_client import AsyncOpenData


class Products:
    """Synchronous Products resource.

    Provides access to data product listings, metadata, search, and export.

    Args:
        client: The parent :class:`~opendata.OpenData` client instance.
    """

    def __init__(self, client: OpenData) -> None:
        self._client = client

    def list(self) -> list[Product]:
        """List all products in the catalog.

        Returns:
            A list of :class:`~opendata.types.Product` instances.
        """
        data = self._client._request("GET", "/products")
        if isinstance(data, list):
            return [Product.model_validate(item) for item in data]
        return []

    def get(self, product_id: str) -> Product:
        """Get metadata for a single product.

        Args:
            product_id: The product identifier.

        Returns:
            A :class:`~opendata.types.Product` instance.
        """
        data = self._client._request("GET", f"/products/{product_id}")
        return Product.model_validate(data)

    def schema(self, product_id: str) -> ProductSchema:
        """Get schema and filter metadata for a product.

        Args:
            product_id: The product identifier.

        Returns:
            A :class:`~opendata.types.ProductSchema` instance.
        """
        data = self._client._request("GET", f"/products/{product_id}/schema")
        return ProductSchema.model_validate(data)

    def search(
        self,
        product_id: str,
        q: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
        **filters: Any,
    ) -> SearchResult:
        """Search records in a product.

        Args:
            product_id: The product identifier.
            q: Full-text query string.
            since: ISO 8601 date filter (records updated since this date).
            limit: Number of results per page (1–200, default 50).
            cursor: Pagination cursor from a previous response.
            **filters: Additional dynamic filter fields supported by the product.

        Returns:
            A :class:`~opendata.types.SearchResult` with data and pagination meta.
        """
        params: dict[str, Any] = {"q": q, "since": since, "limit": limit, "cursor": cursor, **filters}
        body = self._client._request("GET", f"/products/{product_id}/search", params=params, raw=True)
        raw_meta = body.get("_meta") or {}
        return SearchResult(
            data=body.get("data") or [],
            meta=SearchMeta.model_validate(raw_meta),
        )

    def search_all(
        self,
        product_id: str,
        q: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 50,
        **filters: Any,
    ) -> Iterator[dict[str, Any]]:
        """Iterate over all records across pages using cursor pagination.

        Args:
            product_id: The product identifier.
            q: Full-text query string.
            since: ISO 8601 date filter.
            limit: Page size (1–200, default 50).
            **filters: Additional dynamic filter fields.

        Yields:
            Individual record dicts from successive pages.
        """
        cursor: Optional[str] = None
        while True:
            result = self.search(product_id, q=q, since=since, limit=limit, cursor=cursor, **filters)
            yield from result.data
            cursor = result.meta.cursor
            if cursor is None:
                break

    def export(
        self,
        product_id: str,
        format: str = "json",
        q: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        """Export records from a product.

        Args:
            product_id: The product identifier.
            format: Export format: ``"json"`` or ``"csv"``.
            q: Full-text query string.
            since: ISO 8601 date filter.
            limit: Maximum records to export (1–10000, default 1000).

        Returns:
            A list of record dicts.
        """
        params: dict[str, Any] = {"format": format, "q": q, "since": since, "limit": limit}
        data = self._client._request("GET", f"/products/{product_id}/export", params=params)
        if isinstance(data, list):
            return data
        return []


class AsyncProducts:
    """Asynchronous Products resource.

    Provides async access to data product listings, metadata, search, and export.

    Args:
        client: The parent :class:`~opendata.AsyncOpenData` client instance.
    """

    def __init__(self, client: AsyncOpenData) -> None:
        self._client = client

    async def list(self) -> list[Product]:
        """List all products in the catalog.

        Returns:
            A list of :class:`~opendata.types.Product` instances.
        """
        data = await self._client._request("GET", "/products")
        if isinstance(data, list):
            return [Product.model_validate(item) for item in data]
        return []

    async def get(self, product_id: str) -> Product:
        """Get metadata for a single product.

        Args:
            product_id: The product identifier.

        Returns:
            A :class:`~opendata.types.Product` instance.
        """
        data = await self._client._request("GET", f"/products/{product_id}")
        return Product.model_validate(data)

    async def schema(self, product_id: str) -> ProductSchema:
        """Get schema and filter metadata for a product.

        Args:
            product_id: The product identifier.

        Returns:
            A :class:`~opendata.types.ProductSchema` instance.
        """
        data = await self._client._request("GET", f"/products/{product_id}/schema")
        return ProductSchema.model_validate(data)

    async def search(
        self,
        product_id: str,
        q: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
        **filters: Any,
    ) -> SearchResult:
        """Search records in a product.

        Args:
            product_id: The product identifier.
            q: Full-text query string.
            since: ISO 8601 date filter.
            limit: Page size (1–200, default 50).
            cursor: Pagination cursor.
            **filters: Additional dynamic filter fields.

        Returns:
            A :class:`~opendata.types.SearchResult` with data and pagination meta.
        """
        params: dict[str, Any] = {"q": q, "since": since, "limit": limit, "cursor": cursor, **filters}
        body = await self._client._request("GET", f"/products/{product_id}/search", params=params, raw=True)
        raw_meta = body.get("_meta") or {}
        return SearchResult(
            data=body.get("data") or [],
            meta=SearchMeta.model_validate(raw_meta),
        )

    async def search_all(
        self,
        product_id: str,
        q: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 50,
        **filters: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """Async iterate over all records across pages.

        Args:
            product_id: The product identifier.
            q: Full-text query string.
            since: ISO 8601 date filter.
            limit: Page size (1–200, default 50).
            **filters: Additional dynamic filter fields.

        Yields:
            Individual record dicts from successive pages.
        """
        cursor: Optional[str] = None
        while True:
            result = await self.search(product_id, q=q, since=since, limit=limit, cursor=cursor, **filters)
            for item in result.data:
                yield item
            cursor = result.meta.cursor
            if cursor is None:
                break


# Deferred import to avoid circular references
from typing import AsyncIterator  # noqa: E402
