from __future__ import annotations

from typing import Any, Iterator, Optional, TYPE_CHECKING

from ..types.group import ProductGroup
from ..types.search import SearchMeta, SearchResult

if TYPE_CHECKING:
    from .._client import OpenData
    from .._async_client import AsyncOpenData


class Groups:
    """Synchronous Groups resource.

    Provides access to product group listings, metadata, and cross-group search.

    Args:
        client: The parent :class:`~opendata.OpenData` client instance.
    """

    def __init__(self, client: OpenData) -> None:
        self._client = client

    def list(self) -> list[ProductGroup]:
        """List all product groups.

        Returns:
            A list of :class:`~opendata.types.ProductGroup` instances.
        """
        data = self._client._request("GET", "/groups")
        if isinstance(data, list):
            return [ProductGroup.model_validate(item) for item in data]
        return []

    def get(self, group_id: str) -> ProductGroup:
        """Get metadata for a single product group.

        Args:
            group_id: The group identifier.

        Returns:
            A :class:`~opendata.types.ProductGroup` instance.
        """
        data = self._client._request("GET", f"/groups/{group_id}")
        return ProductGroup.model_validate(data)

    def search(
        self,
        group_id: str,
        q: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
    ) -> SearchResult:
        """Search records across all products in a group.

        Args:
            group_id: The group identifier.
            q: Full-text query string.
            since: ISO 8601 date filter.
            limit: Page size (1–200, default 50).
            cursor: Pagination cursor.

        Returns:
            A :class:`~opendata.types.SearchResult` with data and pagination meta.
        """
        params: dict[str, Any] = {"q": q, "since": since, "limit": limit, "cursor": cursor}
        body = self._client._request("GET", f"/groups/{group_id}/search", params=params, raw=True)
        raw_meta = body.get("_meta") or {}
        return SearchResult(
            data=body.get("data") or [],
            meta=SearchMeta.model_validate(raw_meta),
        )

    def search_all(
        self,
        group_id: str,
        q: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 50,
    ) -> Iterator[dict[str, Any]]:
        """Iterate over all records across pages for a group search.

        Args:
            group_id: The group identifier.
            q: Full-text query string.
            since: ISO 8601 date filter.
            limit: Page size (1–200, default 50).

        Yields:
            Individual record dicts from successive pages.
        """
        cursor: Optional[str] = None
        while True:
            result = self.search(group_id, q=q, since=since, limit=limit, cursor=cursor)
            yield from result.data
            cursor = result.meta.cursor
            if cursor is None:
                break


class AsyncGroups:
    """Asynchronous Groups resource.

    Provides async access to product group listings, metadata, and cross-group search.

    Args:
        client: The parent :class:`~opendata.AsyncOpenData` client instance.
    """

    def __init__(self, client: AsyncOpenData) -> None:
        self._client = client

    async def list(self) -> list[ProductGroup]:
        """List all product groups.

        Returns:
            A list of :class:`~opendata.types.ProductGroup` instances.
        """
        data = await self._client._request("GET", "/groups")
        if isinstance(data, list):
            return [ProductGroup.model_validate(item) for item in data]
        return []

    async def get(self, group_id: str) -> ProductGroup:
        """Get metadata for a single product group.

        Args:
            group_id: The group identifier.

        Returns:
            A :class:`~opendata.types.ProductGroup` instance.
        """
        data = await self._client._request("GET", f"/groups/{group_id}")
        return ProductGroup.model_validate(data)

    async def search(
        self,
        group_id: str,
        q: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 50,
        cursor: Optional[str] = None,
    ) -> SearchResult:
        """Search records across all products in a group.

        Args:
            group_id: The group identifier.
            q: Full-text query string.
            since: ISO 8601 date filter.
            limit: Page size (1–200, default 50).
            cursor: Pagination cursor.

        Returns:
            A :class:`~opendata.types.SearchResult` with data and pagination meta.
        """
        params: dict[str, Any] = {"q": q, "since": since, "limit": limit, "cursor": cursor}
        body = await self._client._request("GET", f"/groups/{group_id}/search", params=params, raw=True)
        raw_meta = body.get("_meta") or {}
        return SearchResult(
            data=body.get("data") or [],
            meta=SearchMeta.model_validate(raw_meta),
        )

    async def search_all(
        self,
        group_id: str,
        q: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 50,
    ) -> AsyncIterator[dict[str, Any]]:
        """Async iterate over all records across pages for a group search.

        Args:
            group_id: The group identifier.
            q: Full-text query string.
            since: ISO 8601 date filter.
            limit: Page size (1–200, default 50).

        Yields:
            Individual record dicts from successive pages.
        """
        cursor: Optional[str] = None
        while True:
            result = await self.search(group_id, q=q, since=since, limit=limit, cursor=cursor)
            for item in result.data:
                yield item
            cursor = result.meta.cursor
            if cursor is None:
                break


from typing import AsyncIterator  # noqa: E402
