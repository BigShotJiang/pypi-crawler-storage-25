from __future__ import annotations

from ._version import __version__
from ._client import OpenData
from ._async_client import AsyncOpenData
from ._exceptions import (
    OpenDataError,
    AuthenticationError,
    PermissionError,
    NotFoundError,
    RateLimitError,
    UpstreamError,
    APIError,
)
from .types import (
    Product,
    ProductSchema,
    ProductStats,
    SearchMeta,
    SearchResult,
    ProductGroup,
    QuotaInfo,
)

__all__ = [
    "__version__",
    "OpenData",
    "AsyncOpenData",
    # Errors
    "OpenDataError",
    "AuthenticationError",
    "PermissionError",
    "NotFoundError",
    "RateLimitError",
    "UpstreamError",
    "APIError",
    # Types
    "Product",
    "ProductSchema",
    "ProductStats",
    "SearchMeta",
    "SearchResult",
    "ProductGroup",
    "QuotaInfo",
]
