# Changelog

## 0.1.0 — Initial Release

- Sync client (`OpenData`) and async client (`AsyncOpenData`)
- Products resource: `list`, `get`, `schema`, `search`, `search_all`, `export`
- Groups resource: `list`, `get`, `search`, `search_all`
- Cursor-based auto-pagination via `search_all`
- Exponential backoff retry on 429/500/502/503
- Pydantic v2 typed models for all responses
- Quota tracking from rate-limit headers
- Full error hierarchy with 12 API error codes mapped
