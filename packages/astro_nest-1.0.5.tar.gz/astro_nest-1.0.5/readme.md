A python package that provides Neural Networks to estimate ages of stars.

Based on [Boin et al. 2026](https://www.aanda.org/articles/aa/full_html/2026/04/aa58436-25/aa58436-25.html).

If you use **NEST** for your research, please acknowledge this by citing

    @article{ Boin26,
        author = {{Boin, T.} and {Casamiquela, L.} and {Haywood, M.} and {Di Matteo, P.} and {Lebreton, Y.} and {Uddin, M.} and {Reese, D. R.}},
        title = {Stellar age determination using deep neural networks - Isochrone ages for 1.3 million stars, based on BaSTI, MIST, PARSEC, Dartmouth, and SYCLIST evolutionary grids},
        DOI= "10.1051/0004-6361/202558436",
        url= "https://doi.org/10.1051/0004-6361/202558436",
        journal = {A\&A},
        year = 2026,
        volume = 708,
        pages = "A215",
    }

# Dependencies:
- numpy
- scikit (optional but recommended for speed)
- tqdm (optional)
- matplotlib (optional)

The [documentation website](https://star-age.github.io/NEST-docs/) guides you through the package usage.

A [Web interface](https://star-age.github.io/) of the project is available to quickly test the Neural Networks:

![image](https://star-age.github.io/NEST-docs/_images/website.png)