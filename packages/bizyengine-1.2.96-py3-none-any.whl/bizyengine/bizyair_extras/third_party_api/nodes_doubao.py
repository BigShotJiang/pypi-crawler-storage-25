import io

from bizyengine.bizyair_extras.utils.audio import save_audio

from .trd_nodes_base import BizyAirTrdApiBaseNode


# 组装火山引擎工具配置项
class DoubaoToolConfig(BizyAirTrdApiBaseNode):
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("tools",)
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Doubao Tool Config"
    FUNCTION = "execute"  # 覆盖api_call

    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "web_search": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "开启后，模型将根据输入情况按需进行联网搜索",
                    },
                )
            }
        }

    def execute(self, **kwargs):
        web_search = kwargs.pop("web_search", True)
        tools = []
        if web_search:
            tools.append("web_search")
        return (tools,)

    # Return: data, model, prompt
    def handle_inputs(self, headers, prompt_id, **kwargs):
        pass

    # Return: videos, images, texts, output urls(as a json string of url string array)
    def handle_outputs(self, outputs):
        pass


class Seedream4(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "IMAGE",
        "STRING",
        """{"doubao-seedream-4-0-250828": "doubao-seedream-4-0-250828"}""",
    )
    RETURN_NAMES = ("images", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Seedream4"

    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "size": (
                    [
                        "1K Square (1024x1024)",
                        "2K Square (2048x2048)",
                        "4K Square (4096x4096)",
                        "HD 16:9 (1920x1080)",
                        "2K 16:9 (2560x1440)",
                        "4K 16:9 (3840x2160)",
                        "Portrait 9:16 (1080x1920)",
                        "Portrait 3:4 (1536x2048)",
                        "Landscape 4:3 (2048x1536)",
                        "Ultra-wide 21:9 (3440x1440)",
                        "Custom",
                    ],
                    {
                        "default": "HD 16:9 (1920x1080)",
                    },
                ),
                "custom_width": ("INT", {"default": 1920, "min": 1024, "max": 4096}),
                "custom_height": ("INT", {"default": 1080, "min": 1024, "max": 4096}),
                "model": (
                    ["doubao-seedream-4-0-250828"],
                    {"default": "doubao-seedream-4-0-250828"},
                ),
            },
            "optional": {
                "image": ("IMAGE",),
                "image2": ("IMAGE",),
                "image3": ("IMAGE",),
                "image4": ("IMAGE",),
                "image5": ("IMAGE",),
                "image6": ("IMAGE",),
                "image7": ("IMAGE",),
                "image8": ("IMAGE",),
                "image9": ("IMAGE",),
                "image10": ("IMAGE",),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = kwargs.get("model", "doubao-seedream-4-0-250828")
        prompt = kwargs.get("prompt", "")
        size = kwargs.get("size", "1K Square (1024x1024)")

        match size:
            case "1K Square (1024x1024)":
                width = 1024
                height = 1024
            case "2K Square (2048x2048)":
                width = 2048
                height = 2048
            case "4K Square (4096x4096)":
                width = 4096
                height = 4096
            case "HD 16:9 (1920x1080)":
                width = 1920
                height = 1080
            case "2K 16:9 (2560x1440)":
                width = 2560
                height = 1440
            case "4K 16:9 (3840x2160)":
                width = 3840
                height = 2160
            case "Portrait 9:16 (1080x1920)":
                width = 1080
                height = 1920
            case "Portrait 3:4 (1536x2048)":
                width = 1536
                height = 2048
            case "Landscape 4:3 (2048x1536)":
                width = 2048
                height = 1536
            case "Ultra-wide 21:9 (3440x1440)":
                width = 3440
                height = 1440
            case "Custom":
                width = kwargs.get("custom_width", 1920)
                height = kwargs.get("custom_height", 1080)

            case _:
                raise ValueError(f"Invalid size: {size}")

        sizeStr = f"{width}x{height}"

        images = []
        total_size = 0
        single_image_size_limit = 10 * 1024 * 1024
        for i, img in enumerate(
            [
                kwargs.get("image", None),
                kwargs.get("image2", None),
                kwargs.get("image3", None),
                kwargs.get("image4", None),
                kwargs.get("image5", None),
                kwargs.get("image6", None),
                kwargs.get("image7", None),
                kwargs.get("image8", None),
                kwargs.get("image9", None),
                kwargs.get("image10", None),
            ],
            1,
        ):
            if img is not None:
                # 都当作PNG就行
                bio = self.compress_image(
                    image=img,
                    total_pixels=6000 * 6000,
                    max_size=single_image_size_limit,
                )
                length = bio.getbuffer().nbytes
                if length > single_image_size_limit:
                    raise ValueError(
                        "Image size is too large, Seedream 4.0 only supports up to 10MB"
                    )
                total_size += length
                if total_size > 50 * 1024 * 1024:
                    raise ValueError(
                        "Total size of images is too large, BizyAir only supports up to 50MB"
                    )
                images.append(self.upload_file(bio, f"{prompt_id}_{i}.webp", headers))

        data = {
            "prompt": prompt,
            "size": sizeStr,
            "image": images,
            "model": model,
            "watermark": False,
            "response_format": "url",
        }

        return data, model

    def handle_outputs(self, outputs):
        images = self.combine_images(outputs[1])
        urls_str = outputs[3]
        return (images, urls_str, "")


class Seedream4_5(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "IMAGE",
        "STRING",
        """{"doubao-seedream-4-5-251128": "doubao-seedream-4-5-251128"}""",
    )
    RETURN_NAMES = ("images", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Seedream 4.5"
    INPUT_IS_LIST = True

    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "model": (
                    ["doubao-seedream-4-5-251128"],
                    {"default": "doubao-seedream-4-5-251128"},
                ),
                "size": (
                    [
                        "2K",
                        "4K",
                        "Custom",
                    ],
                    {
                        "default": "2K",
                    },
                ),
                "custom_width": (
                    "INT",
                    {
                        "default": 2048,
                        "min": 480,
                        "max": 4096,
                        "tooltip": "总像素取值范围 [2560x1440=3686400, 4096x4096=16777216], 宽高比取值范围：[1/16, 16]",
                    },
                ),
                "custom_height": (
                    "INT",
                    {
                        "default": 2048,
                        "min": 480,
                        "max": 4096,
                        "tooltip": "总像素取值范围 [2560x1440=3686400, 4096x4096=16777216], 宽高比取值范围：[1/16, 16]",
                    },
                ),
                "max_images": (
                    "INT",
                    {
                        "default": 1,
                        "min": 1,
                        "max": 15,
                        "tooltip": "实际可生成的图片数量，除受到 max_images 影响外，还受到输入的参考图数量影响。输入的参考图数量+最终生成的图片数量≤15张。",
                    },
                ),
                "optimize_prompt": (
                    ["disabled", "standard"],
                    {
                        "default": "disabled",
                        "tooltip": "提示词优化功能的配置。standard：标准模式，生成内容的质量更高，耗时较长。",
                    },
                ),
            },
            "optional": {
                "images": (
                    "IMAGE",
                    {"tooltip": "参考图，数量不超过14张。会影响组图生成数量"},
                ),
                "inputcount": (
                    "INT",
                    {
                        "default": 1,
                        "min": 1,
                        "max": 14,
                        "tooltip": "动态控制输入的参考图数量，范围1-14，点击Update inputs按钮刷新",
                    },
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        # up to 14 ref images
        # 10mb each
        # custom total pixels [3686400, 16777216]
        # custom size ratio [1/16, 16]
        model = kwargs.get("model", ["doubao-seedream-4-0-250828"])[0]
        prompt = kwargs.get("prompt", [""])[0]
        size = kwargs.get("size", ["2K"])[0]
        images = kwargs.get("images", [])
        optimize_prompt = kwargs.get("optimize_prompt", ["disabled"])[0]
        max_images = kwargs.get("max_images", [1])[0]

        # 多图的情况可以认为图片输入都是List[Image Batch]
        total_input_images = 0
        for _, img_batch in enumerate(images if images is not None else []):
            if img_batch is not None:
                total_input_images += img_batch.shape[0]
        extra_images, total_extra_images = self.get_extra_images(**kwargs)
        total_input_images += total_extra_images
        if total_input_images > 14:
            raise ValueError("Total number of input images is too large, maximum is 14")

        if size == "Custom":
            width = kwargs.get("custom_width", [2048])[0]
            height = kwargs.get("custom_height", [2048])[0]
            if width * height < 3686400 or width * height > 16777216:
                raise ValueError("Total pixels must be between 3686400 and 16777216")
            if width / height < 1 / 16 or width / height > 16:
                raise ValueError("Width/height ratio must be between 1/16 and 16")
            size = f"{width}x{height}"

        parts = []
        index = 1
        single_image_size_limit = 10 * 1024 * 1024
        for _, img_batch in enumerate(images if images is not None else []):
            for _, img in enumerate(img_batch if img_batch is not None else []):
                if img is not None:
                    bio = self.compress_image(
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    length = bio.getbuffer().nbytes
                    if length > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, Seedream 4.5 only supports up to 10MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_{index}.webp",
                        headers,
                    )
                    parts.append(url)
                    index += 1
        for _, img_batch in enumerate(extra_images):
            for _, img in enumerate(img_batch if img_batch is not None else []):
                if img is not None:
                    bio = self.compress_image(
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    length = bio.getbuffer().nbytes
                    if length > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, Seedream 4.5 only supports up to 10MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_{index}.webp",
                        headers,
                    )
                    parts.append(url)
                    index += 1

        data = {
            "prompt": prompt,
            "size": size,
            "model": model,
            "max_images": max_images,
        }
        if len(parts) > 0:
            data["image"] = parts
        if optimize_prompt != "disabled":
            data["optimize_prompt"] = optimize_prompt

        return data, model

    def handle_outputs(self, outputs):
        images = self.combine_images(outputs[1])
        urls_str = outputs[3]
        return (images, urls_str, "")


class Seedream5(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "IMAGE",
        "STRING",
        """{"doubao-seedream-5-0-260128": "doubao-seedream-5-0-260128"}""",
    )
    RETURN_NAMES = ("images", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Seedream 5.0"
    INPUT_IS_LIST = True

    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "model": (
                    ["doubao-seedream-5-0-260128"],
                    {"default": "doubao-seedream-5-0-260128"},
                ),
                "size": (
                    [
                        "2K",
                        "3K",
                        "Custom",
                    ],
                    {
                        "default": "2K",
                    },
                ),
                "custom_width": (
                    "INT",
                    {
                        "default": 2048,
                        "min": 480,
                        "max": 12800,
                        "tooltip": "总像素取值范围 [2560x1440=3686400, 3072x3072x1.1025=10404496], 宽高比取值范围：[1/16, 16]",
                    },
                ),
                "custom_height": (
                    "INT",
                    {
                        "default": 2048,
                        "min": 480,
                        "max": 12800,
                        "tooltip": "总像素取值范围 [2560x1440=3686400, 3072x3072x1.1025=10404496], 宽高比取值范围：[1/16, 16]",
                    },
                ),
                "tools": (
                    "STRING",
                    {
                        "default": "",
                        "tooltip": "豆包模型支持的工具选项，请使用BizyAir Doubao Tool Config节点配置",
                    },
                ),
                "max_images": (
                    "INT",
                    {
                        "default": 1,
                        "min": 1,
                        "max": 15,
                        "tooltip": "实际可生成的图片数量，除受到 max_images 影响外，还受到输入的参考图数量影响。输入的参考图数量+最终生成的图片数量≤15张。",
                    },
                ),
                "optimize_prompt": (
                    ["disabled", "standard"],
                    {
                        "default": "disabled",
                        "tooltip": "提示词优化功能的配置。standard：标准模式，生成内容的质量更高，耗时较长。",
                    },
                ),
            },
            "optional": {
                "images": (
                    "IMAGE",
                    {"tooltip": "参考图，数量不超过14张。会影响组图生成数量"},
                ),
                "inputcount": (
                    "INT",
                    {
                        "default": 1,
                        "min": 1,
                        "max": 14,
                        "tooltip": "动态控制输入的参考图数量，范围1-14，点击Update inputs按钮刷新",
                    },
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        # up to 14 ref images
        # 10mb each
        # custom total pixels <= 6000x6000=36000000
        # custom size ratio [1/16, 16]
        model = kwargs.get("model", ["doubao-seedream-5-0-260128"])[0]
        prompt = kwargs.get("prompt", [""])[0]
        size = kwargs.get("size", ["2K"])[0]
        images = kwargs.get("images", [])
        optimize_prompt = kwargs.get("optimize_prompt", ["disabled"])[0]
        max_images = kwargs.get("max_images", [1])[0]
        tools = kwargs.get("tools", [])  # 本身就期望list[string]
        tools = list(filter(None, tools))

        # 多图的情况可以认为图片输入都是List[Image Batch]
        total_input_images = 0
        for _, img_batch in enumerate(images if images is not None else []):
            if img_batch is not None:
                total_input_images += img_batch.shape[0]
        extra_images, total_extra_images = self.get_extra_images(**kwargs)
        total_input_images += total_extra_images
        if total_input_images > 14:
            raise ValueError("Total number of input images is too large, maximum is 14")

        if size == "Custom":
            width = kwargs.get("custom_width", [2048])[0]
            height = kwargs.get("custom_height", [2048])[0]
            if width * height < 3686400 or width * height > 10404496:
                raise ValueError("Total pixels must be between 3686400 and 10404496")
            if width / height < 1 / 16 or width / height > 16:
                raise ValueError("Width/height ratio must be between 1/16 and 16")
            size = f"{width}x{height}"

        parts = []
        index = 1
        single_image_size_limit = 10 * 1024 * 1024
        for _, img_batch in enumerate(images if images is not None else []):
            for _, img in enumerate(img_batch if img_batch is not None else []):
                if img is not None:
                    bio = self.compress_image(
                        mime_type="image/webp",
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    length = bio.getbuffer().nbytes
                    if length > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, Seedream 5.0 only supports up to 10MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_{index}.webp",
                        headers,
                    )
                    parts.append(url)
                    index += 1
        for _, img_batch in enumerate(extra_images):
            for _, img in enumerate(img_batch if img_batch is not None else []):
                if img is not None:
                    bio = self.compress_image(
                        mime_type="image/webp",
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    length = bio.getbuffer().nbytes
                    if length > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, Seedream 5.0 only supports up to 10MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_{index}.webp",
                        headers,
                    )
                    parts.append(url)
                    index += 1

        data = {
            "prompt": prompt,
            "size": size,
            "model": model,
            "max_images": max_images,
        }
        if len(parts) > 0:
            data["image"] = parts
        if optimize_prompt != "disabled":
            data["optimize_prompt"] = optimize_prompt
        if len(tools) > 0:
            data["tools"] = tools

        return data, model

    def handle_outputs(self, outputs):
        images = self.combine_images(outputs[1])
        urls_str = outputs[3]
        return (images, urls_str, "")


class Seededit3(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "IMAGE",
        "STRING",
        """{"doubao-seededit-3-0-i2i-250628": "doubao-seededit-3-0-i2i-250628"}""",
    )
    RETURN_NAMES = ("image", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Seededit3"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "model": (
                    ["doubao-seededit-3-0-i2i-250628"],
                    {"default": "doubao-seededit-3-0-i2i-250628"},
                ),
                "seed": ("INT", {"default": -1, "min": -1, "max": 2147483647}),
                "guidance_scale": ("FLOAT", {"default": 5.5, "min": 1.0, "max": 10.0}),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = kwargs.get("model", "doubao-seededit-3-0-i2i-250628")
        prompt = kwargs.get("prompt", "")
        image = kwargs.get("image", None)
        seed = kwargs.get("seed", -1)
        guidance_scale = kwargs.get("guidance_scale", 5.5)
        if image is None:
            raise ValueError("Image is required")
        # 上传图片
        image_url = self.upload_file(
            self.compress_image(
                image=image, total_pixels=6000 * 6000, max_size=10 * 1024 * 1024
            ),
            f"{prompt_id}.webp",
            headers,
        )
        data = {
            "prompt": prompt,
            "model": model,
            "image": image_url,
            "seed": seed,
            "guidance_scale": guidance_scale,
            "size": "adaptive",
            "response_format": "url",
            "watermark": False,
        }
        return data, model

    def handle_outputs(self, outputs):
        images = self.combine_images(outputs[1])
        urls_str = outputs[3]
        return (images, urls_str, "")


class Seedance_1_0_T2V_API(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"doubao-seedance-1-0-pro-250528": "doubao-seedance-1-0","doubao-seedance-1-0-pro-fast-251015": "doubao-seedance-1-0"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Seedance 1.0 Pro Text To Video"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "model": (
                    [
                        "doubao-seedance-1-0-pro-250528",
                        "doubao-seedance-1-0-pro-fast-251015",
                    ],
                    {"default": "doubao-seedance-1-0-pro-250528"},
                ),
                "resolution": (
                    ["480p", "720p", "1080p"],
                    {
                        "default": "1080p",
                        "tooltip": "分辨率+比例共同决定视频尺寸，具体尺寸请参考官方文档说明",
                    },
                ),
                "ratio": (
                    ["16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "adaptive"],
                    {
                        "default": "adaptive",
                        "tooltip": "比例+分辨率共同决定视频尺寸，具体尺寸请参考官方文档说明",
                    },
                ),
                "duration": ("INT", {"default": 12, "min": 2, "max": 12}),
                "fps": (
                    [24],
                    {
                        "default": 24,
                        "tooltip": "帧率固定24",
                    },
                ),
                "camerafixed": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "平台可能在提示词中追加固定摄像机指令（效果不保证）",
                    },
                ),
                "seed": ("INT", {"default": -1, "min": -1, "max": 2147483647}),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = kwargs.get("model", "doubao-seedance-1-0-pro-250528")
        prompt = kwargs.get("prompt", "")
        resolution = kwargs.get("resolution", "1080p")
        ratio = kwargs.get("ratio", "adaptive")
        duration = kwargs.get("duration", 12)
        camerafixed = kwargs.get("camerafixed", False)
        seed = kwargs.get("seed", -1)
        if prompt is None or prompt.strip() == "":
            raise ValueError("Prompt is required")
        data = {
            "prompt": prompt,
            "model": model,
            "resolution": resolution,
            "ratio": ratio,
            "duration": duration,
            "camerafixed": camerafixed,
            "seed": seed,
            "watermark": False,
            "fps": 24,
        }
        return data, "doubao-seedance-1-0"

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Seedance_1_0_I2V_API(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"doubao-seedance-1-0-pro-250528": "doubao-seedance-1-0","doubao-seedance-1-0-pro-fast-251015": "doubao-seedance-1-0"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Seedance 1.0 Pro Image To Video"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "first_frame_image": ("IMAGE",),
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "model": (
                    [
                        "doubao-seedance-1-0-pro-250528",
                        "doubao-seedance-1-0-pro-fast-251015",
                    ],
                    {"default": "doubao-seedance-1-0-pro-250528"},
                ),
                "resolution": (
                    ["480p", "720p", "1080p"],
                    {
                        "default": "1080p",
                        "tooltip": "分辨率+比例共同决定视频尺寸，具体尺寸请参考官方文档说明",
                    },
                ),
                "ratio": (
                    ["16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "adaptive"],
                    {
                        "default": "adaptive",
                        "tooltip": "比例+分辨率共同决定视频尺寸，具体尺寸请参考官方文档说明",
                    },
                ),
                "duration": ("INT", {"default": 12, "min": 2, "max": 12}),
                "fps": (
                    [24],
                    {
                        "default": 24,
                        "tooltip": "帧率固定24",
                    },
                ),
                "camerafixed": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "平台可能在提示词中追加固定摄像机指令（效果不保证）",
                    },
                ),
                "seed": ("INT", {"default": -1, "min": -1, "max": 2147483647}),
            },
            "optional": {
                "last_frame_image": ("IMAGE",),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = kwargs.get("model", "doubao-seedance-1-0-pro-250528")
        prompt = kwargs.get("prompt", "")
        resolution = kwargs.get("resolution", "1080p")
        ratio = kwargs.get("ratio", "adaptive")
        duration = kwargs.get("duration", 12)
        camerafixed = kwargs.get("camerafixed", False)
        seed = kwargs.get("seed", -1)
        first_frame_image = kwargs.get("first_frame_image", None)
        last_frame_image = kwargs.get("last_frame_image", None)
        if first_frame_image is None:
            raise ValueError("First frame image is required")
        else:
            w_to_h = float(first_frame_image.shape[2]) / float(
                first_frame_image.shape[1]
            )
            if w_to_h < 0.4 or w_to_h > 2.5:
                raise ValueError(
                    "First frame image aspect ratio must be between 0.4 and 2.5"
                )
        if last_frame_image is not None:
            if model == "doubao-seedance-1-0-pro-fast-251015":
                raise ValueError(
                    "Last frame image is not supported for doubao-seedance-1-0-pro-fast-251015"
                )
            w_to_h = float(last_frame_image.shape[2]) / float(last_frame_image.shape[1])
            if w_to_h < 0.4 or w_to_h > 2.5:
                raise ValueError(
                    "Last frame image aspect ratio must be between 0.4 and 2.5"
                )
        first_frame_image_url = self.upload_file(
            self.compress_image(
                image=first_frame_image,
                total_pixels=6000 * 6000,
                max_size=30 * 1024 * 1024,
            ),
            f"{prompt_id}_first.webp",
            headers,
        )
        data = {
            "prompt": prompt,
            "model": model,
            "resolution": resolution,
            "ratio": ratio,
            "duration": duration,
            "camerafixed": camerafixed,
            "seed": seed,
            "watermark": False,
            "fps": 24,
            "first_frame_image": first_frame_image_url,
        }
        if last_frame_image is not None:
            last_frame_image_url = self.upload_file(
                self.compress_image(
                    image=last_frame_image,
                    total_pixels=6000 * 6000,
                    max_size=30 * 1024 * 1024,
                ),
                f"{prompt_id}_last.webp",
                headers,
            )
            data["last_frame_image"] = last_frame_image_url
        return data, "doubao-seedance-1-0"

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Seedance_1_5_T2V_API(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"doubao-seedance-1-5-pro-251215": "doubao-seedance-1-5-pro"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Seedance 1.5 Pro Text To Video"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "model": (
                    ["doubao-seedance-1-5-pro-251215"],
                    {"default": "doubao-seedance-1-5-pro-251215"},
                ),
                "resolution": (
                    ["480p", "720p", "1080p"],
                    {
                        "default": "1080p",
                        "tooltip": "分辨率+比例共同决定视频尺寸，具体尺寸请参考官方文档说明",
                    },
                ),
                "ratio": (
                    ["16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "adaptive"],
                    {
                        "default": "adaptive",
                        "tooltip": "比例+分辨率共同决定视频尺寸，具体尺寸请参考官方文档说明",
                    },
                ),
                "duration": ("INT", {"default": 12, "min": 4, "max": 12}),
                "fps": (
                    [24],
                    {
                        "default": 24,
                        "tooltip": "帧率固定24",
                    },
                ),
                "camerafixed": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "平台可能在提示词中追加固定摄像机指令（效果不保证）",
                    },
                ),
                "generate_audio": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "影响计费。控制生成的视频是否包含与画面同步的声音，Seedance 1.5 pro 能够基于文本提示词与视觉内容，自动生成与之匹配的人声、音效及背景音乐。建议将对话部分置于双引号内，以优化音频生成效果。例如：男人叫住女人说：“你记住，以后不可以用手指指月亮。”",
                    },
                ),
                "seed": ("INT", {"default": -1, "min": -1, "max": 2147483647}),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = kwargs.get("model", "doubao-seedance-1-5-pro-251215")
        prompt = kwargs.get("prompt", "")
        resolution = kwargs.get("resolution", "1080p")
        ratio = kwargs.get("ratio", "adaptive")
        duration = kwargs.get("duration", 12)
        camerafixed = kwargs.get("camerafixed", False)
        generate_audio = kwargs.get("generate_audio", False)
        seed = kwargs.get("seed", -1)
        if prompt is None or prompt.strip() == "":
            raise ValueError("Prompt is required")
        data = {
            "prompt": prompt,
            "model": model,
            "resolution": resolution,
            "ratio": ratio,
            "duration": duration,
            "camerafixed": camerafixed,
            "seed": seed,
            "watermark": False,
            "fps": 24,
            "generate_audio": generate_audio,
        }
        return data, "doubao-seedance-1-5-pro"

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Seedance_1_5_I2V_API(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"doubao-seedance-1-5-pro-251215": "doubao-seedance-1-5-pro"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Seedance 1.5 Pro Image To Video"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "first_frame_image": ("IMAGE",),
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "model": (
                    ["doubao-seedance-1-5-pro-251215"],
                    {"default": "doubao-seedance-1-5-pro-251215"},
                ),
                "resolution": (
                    ["480p", "720p", "1080p"],
                    {
                        "default": "1080p",
                        "tooltip": "分辨率+比例共同决定视频尺寸，具体尺寸请参考官方文档说明",
                    },
                ),
                "ratio": (
                    ["16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "adaptive"],
                    {
                        "default": "adaptive",
                        "tooltip": "比例+分辨率共同决定视频尺寸，具体尺寸请参考官方文档说明",
                    },
                ),
                "duration": ("INT", {"default": 12, "min": 4, "max": 12}),
                "fps": (
                    [24],
                    {
                        "default": 24,
                        "tooltip": "帧率固定24",
                    },
                ),
                "camerafixed": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "平台可能在提示词中追加固定摄像机指令（效果不保证）",
                    },
                ),
                "generate_audio": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "影响计费。控制生成的视频是否包含与画面同步的声音，Seedance 1.5 pro 能够基于文本提示词与视觉内容，自动生成与之匹配的人声、音效及背景音乐。建议将对话部分置于双引号内，以优化音频生成效果。例如：男人叫住女人说：“你记住，以后不可以用手指指月亮。”",
                    },
                ),
                "seed": ("INT", {"default": -1, "min": -1, "max": 2147483647}),
            },
            "optional": {
                "last_frame_image": ("IMAGE",),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = kwargs.get("model", "doubao-seedance-1-5-pro-251215")
        prompt = kwargs.get("prompt", "")
        resolution = kwargs.get("resolution", "1080p")
        ratio = kwargs.get("ratio", "adaptive")
        duration = kwargs.get("duration", 12)
        camerafixed = kwargs.get("camerafixed", False)
        generate_audio = kwargs.get("generate_audio", False)
        seed = kwargs.get("seed", -1)
        first_frame_image = kwargs.get("first_frame_image", None)
        last_frame_image = kwargs.get("last_frame_image", None)
        if first_frame_image is None:
            raise ValueError("First frame image is required")
        else:
            w_to_h = float(first_frame_image.shape[2]) / float(
                first_frame_image.shape[1]
            )
            if w_to_h < 0.4 or w_to_h > 2.5:
                raise ValueError(
                    "First frame image aspect ratio must be between 0.4 and 2.5"
                )
        if last_frame_image is not None:
            w_to_h = float(last_frame_image.shape[2]) / float(last_frame_image.shape[1])
            if w_to_h < 0.4 or w_to_h > 2.5:
                raise ValueError(
                    "Last frame image aspect ratio must be between 0.4 and 2.5"
                )
        first_frame_image_url = self.upload_file(
            self.compress_image(
                image=first_frame_image,
                total_pixels=6000 * 6000,
                max_size=30 * 1024 * 1024,
            ),
            f"{prompt_id}_first.webp",
            headers,
        )
        data = {
            "prompt": prompt,
            "model": model,
            "resolution": resolution,
            "ratio": ratio,
            "duration": duration,
            "camerafixed": camerafixed,
            "seed": seed,
            "watermark": False,
            "fps": 24,
            "first_frame_image": first_frame_image_url,
            "generate_audio": generate_audio,
        }
        if last_frame_image is not None:
            last_frame_image_url = self.upload_file(
                self.compress_image(
                    image=last_frame_image,
                    total_pixels=6000 * 6000,
                    max_size=30 * 1024 * 1024,
                ),
                f"{prompt_id}_last.webp",
                headers,
            )
            data["last_frame_image"] = last_frame_image_url
        return data, "doubao-seedance-1-5-pro"

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


# class Seedance_2_0_I2V_API(BizyAirTrdApiBaseNode):
#     RETURN_TYPES = (
#         "VIDEO",
#         "STRING",
#         """{"doubao-seedance-2-0-260128": "doubao-seedance-2-0"}""",
#     )
#     RETURN_NAMES = ("video", "urls", "bizyair_model_name")
#     CATEGORY = "☁️BizyAir/External APIs/Doubao"
#     NODE_DISPLAY_NAME = "Seedance 2.0 First & Last Frame To Video"

#     @classmethod
#     def INPUT_TYPES(cls):
#         return {
#             "required": {
#                 "first_frame_image": ("IMAGE",),
#                 "last_frame_image": ("IMAGE",), # TODO: optional or not?
#                 "prompt": (
#                     "STRING",
#                     {
#                         "multiline": True,
#                         "default": "",
#                     },
#                 ),
#                 "model": (
#                     ["doubao-seedance-2-0-260128"],
#                     {"default": "doubao-seedance-2-0-260128"},
#                 ),
#                 "resolution": (
#                     ["480p", "720p"],
#                     {
#                         "default": "720p",
#                         "tooltip": "分辨率+比例共同决定视频尺寸，具体尺寸请参考官方文档说明",
#                     },
#                 ),
#                 "ratio": (
#                     ["16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "adaptive"],
#                     {
#                         "default": "adaptive",
#                         "tooltip": "比例+分辨率共同决定视频尺寸，具体尺寸请参考官方文档说明",
#                     },
#                 ),
#                 "duration": ("INT", {"default": 5, "min": 4, "max": 15}),
#                 "auto_duration": ("BOOLEAN", {"default": False, "tooltip": "是否让模型智能决定生成视频时长。会覆盖duration参数，请谨慎使用"}),
#                 "generate_audio": (
#                     "BOOLEAN",
#                     {
#                         "default": True,
#                         "tooltip": "是否生成带音频的视频",
#                     },
#                 ),
#                 "tools": ("STRING", {"default": "", "tooltip": "豆包模型支持的工具选项，请使用BizyAir Doubao Tool Config节点配置"}),
#                 "seed": ("INT", {"default": -1, "min": -1, "max": 2147483647}),
#             },
#             "optional": {
#             },
#         }

#     def handle_inputs(self, headers, prompt_id, **kwargs):
#         model = kwargs.get("model", "doubao-seedance-2-0-260128")
#         prompt = kwargs.get("prompt", "")
#         resolution = kwargs.get("resolution", "720p")
#         ratio = kwargs.get("ratio", "adaptive")
#         duration = kwargs.get("duration", 5)
#         auto_duration = kwargs.get("auto_duration", False)
#         generate_audio = kwargs.get("generate_audio", True)
#         seed = kwargs.get("seed", -1)
#         first_frame_image = kwargs.get("first_frame_image", None)
#         last_frame_image = kwargs.get("last_frame_image", None)
#         tools = kwargs.get("tools", [])
#         if type(tools) is str:
#             tools = [tools]
#         tools = list(filter(None, tools))

#         if first_frame_image is None:
#             raise ValueError("First frame image is required")
#         if last_frame_image is not None:
#             raise ValueError("Last frame image is required")
#         first_frame_image_url = self.upload_file(
#             tensor_to_bytesio(image=first_frame_image, total_pixels=4096 * 4096),
#             f"{prompt_id}_first.png",
#             headers,
#         )
#         data = {
#             "prompt": prompt,
#             "model": model,
#             "resolution": resolution,
#             "ratio": ratio,
#             "duration": duration,
#             "auto_duration": auto_duration,
#             "seed": seed,
#             "watermark": False,
#             "first_frame_image": first_frame_image_url,
#             "generate_audio": generate_audio,
#         }
#         if last_frame_image is not None:
#             last_frame_image_url = self.upload_file(
#                 tensor_to_bytesio(image=last_frame_image, total_pixels=4096 * 4096),
#                 f"{prompt_id}_last.png",
#                 headers,
#             )
#             data["last_frame_image"] = last_frame_image_url
#         if len(tools) > 0:
#             data["tools"] = tools
#         return data, model

#     def handle_outputs(self, outputs):
#         urls_str = outputs[3]
#         return (outputs[0][0], urls_str, "")


class Seedance_2_0_REF_API(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"doubao-seedance-2-0-260128": "seedance-2-0"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Seedance 2.0 References To Video"
    INPUT_IS_LIST = True

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        # TODO: example & user manual as default prompt
                        "default": "",
                    },
                ),
                "model": (
                    ["doubao-seedance-2-0-260128"],
                    {"default": "doubao-seedance-2-0-260128"},
                ),
                "ratio": (
                    ["16:9", "4:3", "3:4", "9:16"],
                    {
                        "default": "16:9",
                        # "tooltip": "比例+分辨率共同决定视频尺寸，具体尺寸请参考官方文档说明",
                    },
                ),
                "duration": ([5, 10, 15], {"default": 5}),
            },
            "optional": {
                "images": ("IMAGE",),
                "inputcount": (
                    "INT",
                    {
                        "default": 1,
                        "min": 1,
                        "max": 4,
                        "tooltip": "动态控制输入的参考图数量，范围1-4，点击Update inputs按钮刷新",
                    },
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        model = kwargs.get("model", ["doubao-seedance-2-0-260128"])[0]
        prompt = kwargs.get("prompt", [""])[0]
        ratio = kwargs.get("ratio", ["adaptive"])[0]
        duration = kwargs.get("duration", [5])[0]
        images = kwargs.get("images", [None])

        # 多图的情况可以认为图片输入都是List[Image Batch]
        total_input_images = 0
        for _, img_batch in enumerate(images if images is not None else []):
            if img_batch is not None:
                total_input_images += img_batch.shape[0]
        extra_images, total_extra_images = self.get_extra_images(**kwargs)
        total_input_images += total_extra_images
        if total_input_images > 4:
            raise ValueError(
                "Total number of input images is too large, current maximum is 4"
            )

        data = {
            "prompt": prompt,
            "model": model,
            "ratio": ratio,
            "duration": duration,
        }

        parts = []
        index = 1
        single_image_size_limit = 10 * 1024 * 1024
        for _, img_batch in enumerate(images if images is not None else []):
            for _, img in enumerate(img_batch if img_batch is not None else []):
                if img is not None:
                    bio = self.compress_image(
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    length = bio.getbuffer().nbytes
                    if length > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, Seedance 2.0 only supports up to 10MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_{index}.webp",
                        headers,
                    )
                    parts.append(url)
                    index += 1
        for _, img_batch in enumerate(extra_images):
            for _, img in enumerate(img_batch if img_batch is not None else []):
                if img is not None:
                    bio = self.compress_image(
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    length = bio.getbuffer().nbytes
                    if length > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, Seedance 2.0 only supports up to 10MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_{index}.webp",
                        headers,
                    )
                    parts.append(url)
                    index += 1

        data["images"] = parts

        # TODO: replace placeholder in prompt with rich text, and validate if such input exists
        # TODO: append unused input res to prompt as rich text
        return data, "seedance-2-0"

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Seedance_2_0_JIMENG_DREAMACTOR_API(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "VIDEO",
        """{"dreamactor-2-0": "dreamactor-2-0"}""",
    )
    RETURN_NAMES = ("video", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "Jimeng Dreamactor M20 (动作模仿2.0)"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": (
                    ["dreamactor-2-0"],
                    {"default": "dreamactor-2-0"},
                ),
                "image": ("IMAGE",),
                "video": ("VIDEO",),
            }
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        image = kwargs.get("image", None)
        video = kwargs.get("video", None)
        if image is None:
            raise ValueError("Image is required")
        if video is None:
            raise ValueError("Video is required")
        # 预校验标准：视频长度不超过30秒，分辨率[200x200, 2048x1440]；图片大小小于4.7MB
        if hasattr(video, "get_duration") and callable(
            getattr(video, "get_duration", None)
        ):
            duration = video.get_duration()
            if duration > 30:
                raise ValueError("Video duration must not exceed 30 seconds")
        if duration is None:
            raise ValueError("Cannot get video duration, please check your video input")
        if hasattr(video, "get_dimensions") and callable(
            getattr(video, "get_dimensions", None)
        ):
            dimensions = video.get_dimensions()
            pixels = dimensions[0] * dimensions[1]
            if pixels < 200 * 200 or pixels > 2048 * 1440:
                raise ValueError(
                    "Video resolution must be between 200x200 and 2048x1440"
                )
        bio = self.compress_image(
            image=image,
            total_pixels=4096 * 4096,
            max_size=4.7 * 1024 * 1024,
        )
        length = bio.getbuffer().nbytes
        if length > 4.7 * 1024 * 1024:
            raise ValueError("Image size is too large, must be less than 4.7MB")
        image_url = self.upload_file(
            bio,
            f"{prompt_id}_image.webp",
            headers,
        )
        video_bytes_io = io.BytesIO()
        format_to_use = getattr(video, "container", "mp4")
        codec_to_use = getattr(video, "codec", "h264")
        video.save_to(video_bytes_io, format=format_to_use, codec=codec_to_use)
        video_bytes_io.seek(0)
        video_url = self.upload_file(
            video_bytes_io,
            f"{prompt_id}_video.{format_to_use}",
            headers,
        )

        data = {"image": image_url, "video": video_url, "duration": duration}
        return data, "dreamactor-2-0"

    def handle_outputs(self, outputs):
        return (outputs[0][0], "")


# class Seedance_2_0_JIMENG_DREAMACTOR_API(BizyAirTrdApiBaseNode):
#     RETURN_TYPES = (
#         "VIDEO",
#         """{"jimeng_dreamactor_m20_gen_video": "jimeng_dreamactor_m20_gen_video"}""",
#     )
#     RETURN_NAMES = ("video", "bizyair_model_name")
#     CATEGORY = "☁️BizyAir/External APIs/Doubao"
#     NODE_DISPLAY_NAME = "Jimeng Dreamactor M20 (动作模仿2.0)"

#     @classmethod
#     def INPUT_TYPES(cls):
#         return {
#             "required": {
#                 "model": (["jimeng_dreamactor_m20_gen_video"], {"default": "jimeng_dreamactor_m20_gen_video"}),
#                 "image": ("IMAGE",),
#                 "video": ("VIDEO",),
#             }
#         }

#     def handle_inputs(self, headers, prompt_id, **kwargs):
#         image = kwargs.get("image", None)
#         video = kwargs.get("video", None)
#         if image is None:
#             raise ValueError("Image is required")
#         if video is None:
#             raise ValueError("Video is required")
#         # 预校验标准：视频长度不超过30秒，分辨率[200x200, 2048x1440]；图片大小小于4.7MB
#         if hasattr(video, 'get_duration') and callable(getattr(video, 'get_duration', None)):
#             duration = video.get_duration()
#             if duration > 30:
#                 raise ValueError("Video duration must not exceed 30 seconds")
#         if hasattr(video, 'get_dimensions') and callable(getattr(video, 'get_dimensions', None)):
#             dimensions = video.get_dimensions()
#             pixels = dimensions[0] * dimensions[1]
#             if pixels < 200 * 200 or pixels > 2048 * 1440:
#                 raise ValueError("Video resolution must be between 200x200 and 2048x1440")
#         bio = tensor_to_bytesio(image=image, total_pixels=4096 * 4096)
#         length = bio.getbuffer().nbytes
#         if length > 4.7 * 1024 * 1024:
#             raise ValueError(
#                 "Image size is too large, must be less than 4.7MB"
#             )
#         image_url = self.upload_file(
#             bio,
#             f"{prompt_id}_image.png",
#             headers,
#         )
#         video_bytes_io = io.BytesIO()
#         format_to_use = getattr(video, "container", "mp4")
#         codec_to_use = getattr(video, "codec", "h264")
#         video.save_to(video_bytes_io, format=format_to_use, codec=codec_to_use)
#         video_bytes_io.seek(0)
#         video_url = self.upload_file(
#             video_bytes_io,
#             f"{prompt_id}_video.{format_to_use}",
#             headers,
#         )

#         data = {
#             "image": image_url,
#             "video": video_url,
#         }
#         return data, "jimeng_dreamactor_m20_gen_video"

#     def handle_outputs(self, outputs):
#         return (outputs[0][0], "")


class Seedance_2_0_T2V_API(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"seedance-2-0-t2v": "seedance-2-0"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "超能视频 2.0 Text To Video"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "mode": (["std", "fast"], {"default": "std"}),
                "resolution": (["480p", "720p"], {"default": "720p"}),
                "duration": ("INT", {"default": 5, "min": 4, "max": 15}),
            },
            "optional": {
                "generateAudio": (
                    "BOOLEAN",
                    {"default": False, "tooltip": "是否生成视频音频"},
                ),
                "ratio": (
                    ["adaptive", "16:9", "9:16", "1:1", "4:3", "3:4", "21:9"],
                    {"default": "adaptive", "tooltip": "视频宽高比"},
                ),
                "webSearch": (
                    "BOOLEAN",
                    {"default": False, "tooltip": "启用联网搜索增强"},
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        prompt = kwargs.get("prompt", "")
        mode = kwargs.get("mode", "std")
        resolution = kwargs.get("resolution", "720p")
        duration = kwargs.get("duration", 5)
        generateAudio = kwargs.get("generateAudio", False)
        ratio = kwargs.get("ratio", "adaptive")

        data = {
            "prompt": prompt,
            "mode": mode,
            "resolution": resolution,
            "duration": duration,
            "generateAudio": generateAudio,
            "ratio": ratio,
            "model": "text-to-video",
        }

        if mode == "std":
            node = "seedance-2-0-std"
        else:
            node = "seedance-2-0-fast"
        return data, node

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Seedance_2_0_I2V_API(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"seedance-2-0-i2v": "seedance-2-0"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "超能视频 2.0 Image To Video"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "mode": (
                    ["std", "fast"],
                    {"default": "std"},
                ),
                "first_frame_image": (
                    "IMAGE",
                    {
                        "tooltip": "首帧图片",
                    },
                ),
                "resolution": (
                    ["480p", "720p"],
                    {"default": "720p", "tooltip": "视频分辨率"},
                ),
                "duration": (
                    "INT",
                    {
                        "default": 5,
                        "min": 4,
                        "max": 15,
                        "tooltip": "视频时长",
                    },
                ),
            },
            "optional": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "视频生成提示词",
                    },
                ),
                "last_frame_image": (
                    "IMAGE",
                    {
                        "tooltip": "尾帧图片",
                    },
                ),
                "generateAudio": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否生成视频音频",
                    },
                ),
                "ratio": (
                    ["adaptive", "16:9", "4:3", "1:1", "3:4", "9:16", "21:9"],
                    {
                        "default": "adaptive",
                        "tooltip": "视频宽高比",
                    },
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        prompt = kwargs.get("prompt", "")
        mode = kwargs.get("mode", "std")
        resolution = kwargs.get("resolution", "720p")
        duration = kwargs.get("duration", 5)
        generate_audio = kwargs.get("generateAudio", True)
        ratio = kwargs.get("ratio", "adaptive")
        first_frame_image = kwargs.get("first_frame_image", None)
        last_frame_image = kwargs.get("last_frame_image", None)

        if first_frame_image is None:
            raise ValueError("First frame image is required")

        # 上传首帧图片
        first_frame_image_url = self.upload_file(
            self.compress_image(image=first_frame_image, total_pixels=4096 * 4096),
            f"{prompt_id}_first.webp",
            headers,
        )

        data = {
            "prompt": prompt,
            "mode": mode,
            "resolution": resolution,
            "duration": str(duration),
            "firstFrameUrl": first_frame_image_url,
            "generateAudio": generate_audio,
            "ratio": ratio,
            "model": "image-to-video",
        }

        # 仅当尾帧图片存在时才上传并加入 payload
        if last_frame_image is not None:
            last_frame_image_url = self.upload_file(
                self.compress_image(image=last_frame_image, total_pixels=4096 * 4096),
                f"{prompt_id}_last.webp",
                headers,
            )
            data["lastFrameUrl"] = last_frame_image_url

        if mode == "std":
            node = "seedance-2-0-std"
        else:
            node = "seedance-2-0-fast"
        return data, node

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")


class Seedance_2_0_Multimodal_API(BizyAirTrdApiBaseNode):
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"seedance-2-0-multimodal": "seedance-2-0"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Doubao"
    NODE_DISPLAY_NAME = "超能视频 2.0 Multimodal To Video"
    INPUT_IS_LIST = True

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "mode": (
                    ["std", "fast"],
                    {"default": "std"},
                ),
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "视频生成提示词",
                    },
                ),
                "resolution": (
                    ["480p", "720p"],
                    {"default": "720p", "tooltip": "视频分辨率"},
                ),
                "duration": (
                    "INT",
                    {
                        "default": 5,
                        "min": 4,
                        "max": 15,
                        "tooltip": "视频时长（秒）",
                    },
                ),
            },
            "optional": {
                "images": ("IMAGE",),
                "inputcount": (
                    "INT",
                    {
                        "default": 1,
                        "min": 1,
                        "max": 9,
                        "tooltip": "动态控制输入的参考图数量，范围1-9，点击Update inputs按钮刷新",
                    },
                ),
                "video_1": ("VIDEO",),
                "video_2": ("VIDEO",),
                "video_3": ("VIDEO",),
                "audio_1": ("AUDIO",),
                "audio_2": ("AUDIO",),
                "audio_3": ("AUDIO",),
                "generateAudio": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "是否生成视频音频",
                    },
                ),
                "ratio": (
                    ["adaptive", "16:9", "4:3", "1:1", "3:4", "9:16", "21:9"],
                    {
                        "default": "adaptive",
                        "tooltip": "视频宽高比",
                    },
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        prompt = kwargs.get("prompt", [""])[0]
        mode = kwargs.get("mode", ["std"])[0]
        resolution = kwargs.get("resolution", ["720p"])[0]
        duration = kwargs.get("duration", [5])[0]
        generate_audio = kwargs.get("generateAudio", [True])[0]
        ratio = kwargs.get("ratio", ["adaptive"])[0]
        images = kwargs.get("images", [None])

        # 图片上传
        total_input_images = 0
        for img_batch in images if images is not None else []:
            if img_batch is not None:
                total_input_images += img_batch.shape[0]
        extra_images, total_extra_images = self.get_extra_images(**kwargs)
        total_input_images += total_extra_images
        if total_input_images > 9:
            raise ValueError(
                "Total number of input images is too large, current maximum is 9"
            )

        single_image_size_limit = 30 * 1024 * 1024  # 30MB
        image_urls = []
        index = 1

        for img_batch in images if images is not None else []:
            for img in img_batch if img_batch is not None else []:
                if img is not None:
                    bio = self.compress_image(
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    if bio.getbuffer().nbytes > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, maximum supported size is 30MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_image_{index}.webp",
                        headers,
                    )
                    image_urls.append(url)
                    index += 1

        for img_batch in extra_images:
            for img in img_batch if img_batch is not None else []:
                if img is not None:
                    bio = self.compress_image(
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    if bio.getbuffer().nbytes > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, maximum supported size is 30MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_image_{index}.webp",
                        headers,
                    )
                    image_urls.append(url)
                    index += 1

        # 视频上传（固定最多3个）
        video_urls = []
        for v_index in range(1, 4):
            ref_video_list = kwargs.get(f"video_{v_index}", [None])
            ref_video = ref_video_list[0] if ref_video_list else None
            if ref_video is not None:
                video_bytes_io = io.BytesIO()
                format_to_use = getattr(ref_video, "container", "mp4")
                codec_to_use = getattr(ref_video, "codec", "h264")
                ref_video.save_to(
                    video_bytes_io, format=format_to_use, codec=codec_to_use
                )
                video_bytes_io.seek(0)
                url = self.upload_file(
                    video_bytes_io,
                    f"{prompt_id}_video_{v_index}.{format_to_use}",
                    headers,
                )
                video_urls.append(url)

        # 音频上传（固定最多3个）
        audio_urls = []
        for a_index in range(1, 4):
            ref_audio_list = kwargs.get(f"audio_{a_index}", [None])
            ref_audio = ref_audio_list[0] if ref_audio_list else None
            if ref_audio is not None:
                url = self.upload_file(
                    save_audio(audio=ref_audio, format="mp3"),
                    f"{prompt_id}_audio_{a_index}.mp3",
                    headers,
                )
                audio_urls.append(url)

        data = {
            "prompt": prompt,
            "mode": mode,
            "resolution": resolution,
            "duration": str(duration),
            "generateAudio": generate_audio,
            "ratio": ratio,
            "model": "multimodal-to-video",
        }
        if image_urls:
            data["imageUrls"] = image_urls
        if video_urls:
            data["videoUrls"] = video_urls
        if audio_urls:
            data["audioUrls"] = audio_urls

        if mode == "std":
            node = "seedance-2-0-std"
        else:
            node = "seedance-2-0-fast"
        return data, node

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "")
