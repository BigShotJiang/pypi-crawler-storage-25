# vpterm-vp

`vpterm-vp` is a small terminal UI library for Python CLIs.

It provides:

- ANSI styling helpers
- panels and tables
- key-value line builders
- progress bars
- terminal helpers for live-updating blocks

Install:

```bash
pip install vpterm-vp
```

Import:

```python
import vpterm
```
