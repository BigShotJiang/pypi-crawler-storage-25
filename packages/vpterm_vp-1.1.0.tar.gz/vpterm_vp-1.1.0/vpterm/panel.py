"""Panel rendering — bordered boxes for grouped content."""

from __future__ import annotations

from vpterm.style import Style, visible_length

BOX_TOP_LEFT = "╭"
BOX_TOP_RIGHT = "╮"
BOX_BOTTOM_LEFT = "╰"
BOX_BOTTOM_RIGHT = "╯"
BOX_HORIZONTAL = "─"
BOX_VERTICAL = "│"


class Panel:
    """Bordered panel for grouping related output.

    Usage:
        panel = Panel(title="Training")
        panel.add_line("epoch 1/10  batch 50/3139")
        panel.add_line("loss=3.14  lr=0.001")
        print(panel.render())
    """

    def __init__(self, title: str = "", width: int = 0, min_width: int = 60) -> None:
        self.title = title
        self.requested_width = width
        self.min_width = min_width
        self.lines: list[str] = []

    def add_line(self, text: str) -> Panel:
        """Add a content line to the panel."""
        self.lines.append(text)
        return self

    def add_blank(self) -> Panel:
        """Add an empty line."""
        self.lines.append("")
        return self

    def add_section(self, title: str) -> Panel:
        """Add a section header inside the panel."""
        self.lines.append(Style.bold(Style.cyan(title)))
        return self

    def add_kv(self, key: str, value: str, key_width: int = 14) -> Panel:
        """Add an indented key-value pair."""
        padded = key.ljust(key_width)
        self.lines.append(f"  {Style.label(padded)} {value}")
        return self

    def _compute_width(self) -> int:
        if self.requested_width > 0:
            return self.requested_width
        max_content = max((visible_length(line) for line in self.lines), default=0)
        title_len = visible_length(f" {self.title} ") + 3 if self.title else 0
        return max(self.min_width, max_content + 4, title_len)

    def render(self) -> str:
        """Render the panel as a multi-line string."""
        width = self._compute_width()
        inner_width = width - 2
        output_lines: list[str] = []

        if self.title:
            title_display = f" {self.title} "
            title_width = visible_length(title_display)
            bar_len = max(0, inner_width - title_width - 1)
            top = f"{BOX_TOP_LEFT}{BOX_HORIZONTAL}{title_display}{BOX_HORIZONTAL * bar_len}{BOX_TOP_RIGHT}"
        else:
            top = f"{BOX_TOP_LEFT}{BOX_HORIZONTAL * inner_width}{BOX_TOP_RIGHT}"
        output_lines.append(Style.dim(top))

        for line in self.lines:
            padding = max(0, inner_width - visible_length(line) - 1)
            output_lines.append(f"{Style.dim(BOX_VERTICAL)} {line}{' ' * padding}{Style.dim(BOX_VERTICAL)}")

        bottom = f"{BOX_BOTTOM_LEFT}{BOX_HORIZONTAL * inner_width}{BOX_BOTTOM_RIGHT}"
        output_lines.append(Style.dim(bottom))

        return "\n".join(output_lines)

    def __str__(self) -> str:
        return self.render()
