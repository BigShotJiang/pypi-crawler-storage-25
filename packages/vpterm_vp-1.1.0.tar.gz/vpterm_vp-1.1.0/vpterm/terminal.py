"""Terminal abstraction — write styled output to stdout.

Supports live blocks that overwrite themselves for progress-style displays.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from vpterm.style import Style, visible_length

CURSOR_UP = "\033[{n}A"
ERASE_TO_END = "\033[J"


class Terminal:
    """Output controller for terminal rendering.

    Manages writing styled lines, live-updating blocks, and detecting terminal width.
    """

    def __init__(self, stream: object | None = None) -> None:
        self.stream = stream or sys.stdout
        self._live_line_count: int = 0

    def width(self) -> int:
        """Get terminal width in columns."""
        try:
            return os.get_terminal_size(self.stream.fileno()).columns
        except (AttributeError, ValueError, OSError):
            return 120

    def _is_tty(self) -> bool:
        """Check if stream is an interactive terminal."""
        return hasattr(self.stream, "isatty") and self.stream.isatty()

    def poll_ctrl_o(self) -> bool:
        """Poll for Ctrl+O on Windows terminals.

        Returns True once when the shortcut is detected. On unsupported
        platforms or non-interactive streams, returns False.
        """
        if not self._is_tty() or sys.platform != "win32":
            return False
        try:
            import msvcrt
        except ImportError:
            return False

        requested = False
        while msvcrt.kbhit():
            if msvcrt.getwch() == "\x0f":
                requested = True
        return requested

    def open_path(self, path: Path) -> bool:
        """Open a path with the OS default application."""
        try:
            if sys.platform == "win32":
                subprocess.Popen(["cmd", "/c", "start", "", str(path)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except OSError:
            return False
        return True

    def write(self, text: str) -> None:
        """Write text to stream."""
        self.stream.write(text)
        self.stream.flush()

    def writeln(self, text: str = "") -> None:
        """Write text followed by newline."""
        self.stream.write(text + "\n")
        self.stream.flush()

    def blank_line(self) -> None:
        """Write an empty line."""
        self.writeln()

    def clear_lines(self, count: int) -> None:
        """Move cursor up and erase lines. No-op if not a TTY."""
        if count <= 0 or not self._is_tty():
            return
        self.stream.write(CURSOR_UP.format(n=count))
        self.stream.write(ERASE_TO_END)
        self.stream.flush()

    def write_live(self, text: str) -> None:
        """Write a live block that overwrites itself on next call.

        Each call erases the previous live block and writes new content.
        Call end_live() to finalize the block (stop overwriting).
        """
        if self._live_line_count > 0:
            self.clear_lines(self._live_line_count)
        lines = text.rstrip("\n").split("\n")
        self._live_line_count = len(lines)
        for line in lines:
            self.writeln(line)

    def end_live(self) -> None:
        """End the current live block — next write_live starts fresh."""
        self._live_line_count = 0

    def overwrite_line(self, text: str) -> None:
        """Overwrite the current line (carriage return)."""
        width = self.width()
        padded = text + " " * max(0, width - visible_length(text))
        self.stream.write(f"\r{padded}")
        self.stream.flush()

    def separator(self, char: str = "─", label: str = "") -> None:
        """Draw a horizontal separator line."""
        width = self.width()
        if label:
            styled_label = f" {label} "
            label_len = len(styled_label)
            left = char * 2
            right = char * max(0, width - 4 - label_len)
            line = f"{left}{Style.bold(styled_label)}{right}"
        else:
            line = char * width
        self.writeln(Style.dim(line) if not label else line)

    def header(self, title: str) -> None:
        """Print a styled header with separators."""
        self.separator("─", title)

    def section(self, title: str) -> None:
        """Print a section header."""
        self.writeln(Style.bold(Style.cyan(f"▸ {title}")))

    def kv_pair(self, key: str, value: str, key_width: int = 0) -> None:
        """Print a key=value pair with styling."""
        padded_key = key.ljust(key_width) if key_width > 0 else key
        self.writeln(f"  {Style.label(padded_key)}  {Style.value(value)}")

    def metric(self, name: str, value: str | float, precision: int = 4) -> str:
        """Format a metric as styled string (does not print)."""
        if isinstance(value, float):
            formatted = f"{value:.{precision}f}"
        else:
            formatted = str(value)
        return f"{Style.metric_name(name)}{Style.dim('=')}{Style.metric_value(formatted)}"

    def status(self, message: str, kind: str = "info") -> None:
        """Print a status message."""
        prefixes = {
            "info": Style.cyan("ℹ"),
            "success": Style.success("✓"),
            "warning": Style.warning("⚠"),
            "error": Style.error("✗"),
            "start": Style.blue("▶"),
            "stop": Style.yellow("■"),
        }
        prefix = prefixes.get(kind, Style.dim("·"))
        self.writeln(f" {prefix} {message}")


_default_terminal: Terminal | None = None


def get_terminal() -> Terminal:
    """Get the global Terminal instance."""
    global _default_terminal
    if _default_terminal is None:
        _default_terminal = Terminal()
    return _default_terminal
