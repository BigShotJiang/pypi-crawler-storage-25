"""Key-value line formatting for structured log output."""

from __future__ import annotations

from vpterm.style import Style


class KeyValue:
    """Builder for key=value formatted lines.

    Usage:
        line = KeyValue()
        line.add("epoch", "1/10")
        line.add("loss", 3.1415, precision=4)
        print(line.render())
    """

    def __init__(self, separator: str = "  ") -> None:
        self.parts: list[str] = []
        self.separator = separator

    def add(self, key: str, value: str | int | float, precision: int = 4) -> KeyValue:
        """Add a key=value pair."""
        if isinstance(value, float):
            formatted = f"{value:.{precision}f}"
        else:
            formatted = str(value)
        self.parts.append(
            f"{Style.metric_name(key)}{Style.dim('=')}{Style.metric_value(formatted)}"
        )
        return self

    def add_raw(self, text: str) -> KeyValue:
        """Add pre-formatted text."""
        self.parts.append(text)
        return self

    def render(self) -> str:
        """Render all pairs as a single line."""
        return self.separator.join(self.parts)

    def __str__(self) -> str:
        return self.render()


def kv_line(**kwargs: str | int | float) -> str:
    """Quick helper to render key=value pairs from keyword arguments."""
    builder = KeyValue()
    for key, value in kwargs.items():
        builder.add(key, value)
    return builder.render()
