"""Progress bar and time formatting for training loops."""

from __future__ import annotations

from vpterm.style import Style


def format_duration(total_seconds: float) -> str:
    """Format seconds into human-readable HH:MM:SS."""
    rounded = max(0, int(total_seconds))
    hours, remainder = divmod(rounded, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def format_number(value: int) -> str:
    """Format integer with thousands separator."""
    return f"{value:,}"


class ProgressBar:
    """Text-based progress bar.

    Usage:
        bar = ProgressBar(total=100, width=30)
        print(bar.render(current=42))
        # ████████████░░░░░░░░░░░░░░░░░░  42%
    """

    FILL = "█"
    EMPTY = "░"

    def __init__(self, total: int, width: int = 30) -> None:
        self.total = max(1, total)
        self.width = width

    def render(self, current: int) -> str:
        """Render progress bar for the given current value."""
        fraction = min(1.0, max(0.0, current / self.total))
        filled = int(self.width * fraction)
        empty = self.width - filled
        bar = self.FILL * filled + self.EMPTY * empty
        percent = f"{fraction * 100:.0f}%"

        if fraction < 0.33:
            colored_bar = Style.red(bar)
        elif fraction < 0.66:
            colored_bar = Style.yellow(bar)
        else:
            colored_bar = Style.green(bar)

        return f"{colored_bar} {Style.bold(percent)}"

    def render_with_label(self, current: int, label: str = "") -> str:
        """Render progress bar with optional label and count."""
        bar = self.render(current)
        count = Style.dim(f"{format_number(current)}/{format_number(self.total)}")
        if label:
            return f"{Style.label(label)} {bar} {count}"
        return f"{bar} {count}"
