"""ANSI terminal styling — colors, bold, dim, underline.

Supports auto-detection of terminal capabilities and graceful
fallback to plain text when colors are not supported.
"""

from __future__ import annotations

import os
import re
import sys

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
ITALIC = "\033[3m"
UNDERLINE = "\033[4m"

FG_BLACK = "\033[30m"
FG_RED = "\033[31m"
FG_GREEN = "\033[32m"
FG_YELLOW = "\033[33m"
FG_BLUE = "\033[34m"
FG_MAGENTA = "\033[35m"
FG_CYAN = "\033[36m"
FG_WHITE = "\033[37m"

FG_BRIGHT_BLACK = "\033[90m"
FG_BRIGHT_RED = "\033[91m"
FG_BRIGHT_GREEN = "\033[92m"
FG_BRIGHT_YELLOW = "\033[93m"
FG_BRIGHT_BLUE = "\033[94m"
FG_BRIGHT_MAGENTA = "\033[95m"
FG_BRIGHT_CYAN = "\033[96m"
FG_BRIGHT_WHITE = "\033[97m"

BG_RED = "\033[41m"
BG_GREEN = "\033[42m"
BG_YELLOW = "\033[43m"
BG_BLUE = "\033[44m"

_STRIP_ANSI = re.compile(r"\033\[[0-9;]*m")

_colors_enabled: bool | None = None


def _detect_color_support() -> bool:
    """Detect if terminal supports ANSI colors."""
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    if not hasattr(sys.stdout, "isatty") or not sys.stdout.isatty():
        return False
    if sys.platform == "win32":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return os.environ.get("TERM") is not None
    return True


def colors_enabled() -> bool:
    """Check if ANSI colors are enabled for this session."""
    global _colors_enabled
    if _colors_enabled is None:
        _colors_enabled = _detect_color_support()
    return _colors_enabled


def set_colors_enabled(enabled: bool) -> None:
    """Force enable or disable colors."""
    global _colors_enabled
    _colors_enabled = enabled
    
def strip_ansi(text: str) -> str:
    """Remove all ANSI escape sequences from text."""
    return _STRIP_ANSI.sub("", text)


def visible_length(text: str) -> int:
    """Compute visible length of text (excluding ANSI codes)."""
    return len(strip_ansi(text))


class Style:
    """Named style presets for consistent theming."""

    @staticmethod
    def _wrap(codes: str, text: str) -> str:
        if not colors_enabled():
            return text
        return f"{codes}{text}{RESET}"

    @staticmethod
    def bold(text: str) -> str:
        return Style._wrap(BOLD, text)

    @staticmethod
    def dim(text: str) -> str:
        return Style._wrap(DIM, text)

    @staticmethod
    def red(text: str) -> str:
        return Style._wrap(FG_RED, text)

    @staticmethod
    def green(text: str) -> str:
        return Style._wrap(FG_GREEN, text)

    @staticmethod
    def yellow(text: str) -> str:
        return Style._wrap(FG_YELLOW, text)

    @staticmethod
    def blue(text: str) -> str:
        return Style._wrap(FG_BLUE, text)

    @staticmethod
    def magenta(text: str) -> str:
        return Style._wrap(FG_MAGENTA, text)

    @staticmethod
    def cyan(text: str) -> str:
        return Style._wrap(FG_CYAN, text)

    @staticmethod
    def white(text: str) -> str:
        return Style._wrap(FG_WHITE, text)

    @staticmethod
    def bright_black(text: str) -> str:
        return Style._wrap(FG_BRIGHT_BLACK, text)

    @staticmethod
    def bright_green(text: str) -> str:
        return Style._wrap(FG_BRIGHT_GREEN, text)

    @staticmethod
    def bright_yellow(text: str) -> str:
        return Style._wrap(FG_BRIGHT_YELLOW, text)

    @staticmethod
    def bright_cyan(text: str) -> str:
        return Style._wrap(FG_BRIGHT_CYAN, text)

    @staticmethod
    def bright_red(text: str) -> str:
        return Style._wrap(FG_BRIGHT_RED, text)

    @staticmethod
    def success(text: str) -> str:
        return Style._wrap(FG_GREEN + BOLD, text)

    @staticmethod
    def warning(text: str) -> str:
        return Style._wrap(FG_YELLOW + BOLD, text)

    @staticmethod
    def error(text: str) -> str:
        return Style._wrap(FG_RED + BOLD, text)

    @staticmethod
    def info(text: str) -> str:
        return Style._wrap(FG_CYAN, text)

    @staticmethod
    def label(text: str) -> str:
        return Style._wrap(FG_BRIGHT_BLACK, text)

    @staticmethod
    def value(text: str) -> str:
        return Style._wrap(FG_WHITE + BOLD, text)

    @staticmethod
    def metric_name(text: str) -> str:
        return Style._wrap(FG_CYAN, text)

    @staticmethod
    def metric_value(text: str) -> str:
        return Style._wrap(FG_BRIGHT_YELLOW, text)

    @staticmethod
    def improved(text: str) -> str:
        return Style._wrap(FG_GREEN + BOLD, text)

    @staticmethod
    def degraded(text: str) -> str:
        return Style._wrap(FG_RED, text)

    @staticmethod
    def timestamp(text: str) -> str:
        return Style._wrap(DIM, text)


def style(text: str, *codes: str) -> str:
    """Apply arbitrary ANSI codes to text."""
    if not colors_enabled():
        return text
    combined = "".join(codes)
    return f"{combined}{text}{RESET}"
