"""Simple table rendering for terminal output."""

from __future__ import annotations

from vpterm.style import Style, visible_length


class Table:
    """Minimal table renderer with column alignment.

    Usage:
        table = Table(["Component", "Params", "Trainable"])
        table.add_row(["universal", "45,000,000", "yes"])
        table.add_row(["family/slavic", "7,200,000", "no"])
        print(table.render())
    """

    def __init__(self, headers: list[str], padding: int = 2) -> None:
        self.headers = headers
        self.rows: list[list[str]] = []
        self.padding = padding

    def add_row(self, values: list[str]) -> Table:
        """Add a data row. Must have same number of columns as headers."""
        self.rows.append(values)
        return self

    def _compute_widths(self) -> list[int]:
        widths = [visible_length(header) for header in self.headers]
        for row in self.rows:
            for col_idx, cell in enumerate(row):
                if col_idx < len(widths):
                    widths[col_idx] = max(widths[col_idx], visible_length(cell))
        return widths

    def render(self) -> str:
        """Render the table as a multi-line string."""
        widths = self._compute_widths()
        pad = " " * self.padding
        lines: list[str] = []

        header_cells = []
        for idx, header in enumerate(self.headers):
            header_cells.append(Style.bold(header.ljust(widths[idx])))
        lines.append(pad.join(header_cells))

        separator_cells = [Style.dim("─" * width) for width in widths]
        lines.append(pad.join(separator_cells))

        for row in self.rows:
            cells = []
            for col_idx, cell in enumerate(row):
                width = widths[col_idx] if col_idx < len(widths) else 0
                cell_padding = max(0, width - visible_length(cell))
                cells.append(cell + " " * cell_padding)
            lines.append(pad.join(cells))

        return "\n".join(lines)

    def __str__(self) -> str:
        return self.render()
