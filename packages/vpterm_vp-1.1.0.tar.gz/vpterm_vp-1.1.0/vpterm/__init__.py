"""VP Terminal — rich console output library.

Provides colors, styled text, panels, key-value formatting,
progress bars, and tables for terminal applications.
"""

from vpterm.style import Style, style, strip_ansi
from vpterm.panel import Panel
from vpterm.table import Table
from vpterm.kv import KeyValue, kv_line
from vpterm.progress import ProgressBar
from vpterm.terminal import Terminal, get_terminal

__version__: str = "1.1.0"
