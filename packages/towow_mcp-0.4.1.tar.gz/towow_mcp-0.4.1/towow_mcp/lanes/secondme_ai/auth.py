"""SecondMe-specific runtime defaults for Python Towow MCP shells."""

from __future__ import annotations

from dataclasses import dataclass

from ...config import get_auth_lane, get_consumer_kind, get_entry_surface, get_scene_id

LANE_NAME = "secondme_ai"

ENTRY_SURFACE_TO_SCENE_ID = {
    "clawopc": "craw-opc",
    "hackthon": "hackathon-observer",
    "shrimphack": "shrimp-hackathon",
    "gigshrimp": "ai-gig-market",
}
_CONSUMER_KINDS = {"codex", "claude_code", "openclaw", "other"}


@dataclass(slots=True, frozen=True)
class SecondMeAIRuntimeContext:
    scene_id: str
    entry_surface: str
    consumer_kind: str


def secondme_ai_lane_enabled() -> bool:
    return (get_auth_lane() or "").strip() == LANE_NAME


def resolve_runtime_context(
    *,
    scene_id: str | None = None,
    entry_surface: str | None = None,
    consumer_kind: str | None = None,
) -> SecondMeAIRuntimeContext:
    resolved_scene_id = (scene_id or get_scene_id() or "").strip()
    if not resolved_scene_id:
        raise ValueError("scene_id is required for secondme_ai auth")

    resolved_entry_surface = (entry_surface or get_entry_surface() or "").strip()
    if not resolved_entry_surface:
        raise ValueError("entry_surface is required for secondme_ai auth")

    expected_scene_id = ENTRY_SURFACE_TO_SCENE_ID.get(resolved_entry_surface)
    if expected_scene_id is None:
        raise ValueError(f"Unsupported entry_surface: {resolved_entry_surface}")
    if expected_scene_id != resolved_scene_id:
        raise ValueError(
            f"entry_surface {resolved_entry_surface} does not match scene_id {resolved_scene_id}"
        )

    resolved_consumer_kind = (consumer_kind or get_consumer_kind() or "").strip()
    if not resolved_consumer_kind:
        raise ValueError("consumer_kind is required for secondme_ai auth")
    if resolved_consumer_kind not in _CONSUMER_KINDS:
        raise ValueError(f"Unsupported consumer_kind: {resolved_consumer_kind}")

    return SecondMeAIRuntimeContext(
        scene_id=resolved_scene_id,
        entry_surface=resolved_entry_surface,
        consumer_kind=resolved_consumer_kind,
    )
