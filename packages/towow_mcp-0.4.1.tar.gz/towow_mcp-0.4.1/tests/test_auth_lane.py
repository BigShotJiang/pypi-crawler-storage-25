"""Tests for the Python MCP SecondMe auth lane runtime."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from mcp.server.fastmcp.exceptions import ToolError

from towow_mcp import config as runtime_config
from towow_mcp import server

pytestmark = pytest.mark.asyncio

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_CONTRACT = json.loads(
    (_REPO_ROOT / "tests" / "fixtures" / "mcp_auth_contract.json").read_text(encoding="utf-8")
)
_EXPECTED_CONSUMER_KIND = _CONTRACT["runtime_defaults"]["consumer_kind"]


class FakeTowowClient:
    def __init__(
        self,
        *,
        create_result: dict | None = None,
        status_result: dict | None = None,
        exchange_result: dict | None = None,
    ) -> None:
        self.create_result = dict(create_result or {})
        self.status_result = dict(status_result or {})
        self.exchange_result = dict(exchange_result or {})
        self.create_calls: list[dict] = []
        self.status_calls: list[str] = []
        self.exchange_calls: list[str] = []

    async def create_consumer_auth_session(
        self,
        *,
        lane: str,
        scene_id: str,
        entry_surface: str,
        consumer_kind: str,
    ) -> dict:
        self.create_calls.append(
            {
                "lane": lane,
                "scene_id": scene_id,
                "entry_surface": entry_surface,
                "consumer_kind": consumer_kind,
            }
        )
        return dict(self.create_result)

    async def get_consumer_auth_session_status(self, auth_session_id: str) -> dict:
        self.status_calls.append(auth_session_id)
        return dict(self.status_result)

    async def exchange_consumer_auth_session(self, auth_session_id: str) -> dict:
        self.exchange_calls.append(auth_session_id)
        return dict(self.exchange_result)

    async def close(self) -> None:
        return None


@pytest.fixture
def isolated_runtime_config(tmp_path, monkeypatch):
    config_dir = tmp_path / ".towow"
    config_file = config_dir / "config.json"
    monkeypatch.setattr(runtime_config, "CONFIG_DIR", config_dir)
    monkeypatch.setattr(runtime_config, "CONFIG_FILE", config_file)
    return config_file


def _write_runtime_config(path, data: dict) -> None:
    runtime_config._write_config(data, path=path)


async def test_towow_auth_begin_uses_secondme_lane_defaults_from_config(
    isolated_runtime_config,
    monkeypatch,
):
    _write_runtime_config(
        isolated_runtime_config,
        {
            "auth_lane": "secondme_ai",
            "scene_id": "craw-opc",
            "entry_surface": "clawopc",
        },
    )
    fake_client = FakeTowowClient(
        create_result={
            "status": "AUTH_REQUIRED",
            "lane": "secondme_ai",
            "scene_id": "craw-opc",
            "entry_surface": "clawopc",
            "auth_session_id": "sess-1",
            "authorize_url": "https://develop.second.me/oauth/authorize?state=sess-1",
            "poll_url": "https://towow.example/protocol/auth/consumer-sessions/sess-1",
            "expires_at": "2026-03-18T13:00:00Z",
        }
    )
    monkeypatch.setattr(server, "_get_client", lambda: fake_client)

    payload = json.loads(await server.towow_auth_begin())

    assert payload["lane"] == "secondme_ai"
    assert payload["scene_id"] == "craw-opc"
    assert payload["entry_surface"] == "clawopc"
    assert fake_client.create_calls == [
        {
            "lane": "secondme_ai",
            "scene_id": "craw-opc",
            "entry_surface": "clawopc",
            "consumer_kind": _EXPECTED_CONSUMER_KIND,
        }
    ]


async def test_towow_auth_status_adds_next_tool_when_completed(monkeypatch):
    fake_client = FakeTowowClient(
        status_result={
            "status": "completed",
            "lane": "secondme_ai",
            "scene_id": "craw-opc",
            "entry_surface": "clawopc",
            "auth_session_id": "sess-2",
            "expires_at": "2026-03-18T13:00:00Z",
            "completed_at": "2026-03-18T12:30:00Z",
        }
    )
    monkeypatch.setattr(server, "_get_client", lambda: fake_client)

    payload = json.loads(await server.towow_auth_status("sess-2"))

    assert payload["status"] == "completed"
    assert payload["next_tool"] == "towow_auth_exchange"
    assert fake_client.status_calls == ["sess-2"]


async def test_towow_auth_exchange_persists_session_agent_and_scene(
    isolated_runtime_config,
    monkeypatch,
):
    _write_runtime_config(
        isolated_runtime_config,
        {
            "auth_lane": "secondme_ai",
            "entry_surface": "clawopc",
            "scene_id": "hackathon-observer",
            "scene_display_name": "Old Scene",
        },
    )
    fake_client = FakeTowowClient(
        exchange_result={
            "session_token": "tok-123",
            "account_id": "acct-1",
            "default_agent_id": "agent-1",
            "email": "user@example.com",
            "name": "Towow Tester",
            "expires_at": "2026-03-25T13:00:00Z",
            "scene_id": "craw-opc",
            "entry_surface": "clawopc",
            "auth_lane": "secondme_ai",
        }
    )
    monkeypatch.setattr(server, "_get_client", lambda: fake_client)

    payload = json.loads(await server.towow_auth_exchange("sess-3"))
    stored = runtime_config._read_config(path=isolated_runtime_config)

    assert "session_token" not in payload
    assert payload["selected_agent"] == {
        "agent_id": "agent-1",
        "display_name": "Towow Tester",
    }
    assert stored["session_token"] == "tok-123"
    assert stored["agent_id"] == "agent-1"
    assert stored["display_name"] == "Towow Tester"
    assert stored["scene_id"] == "craw-opc"
    assert "scene_display_name" not in stored
    assert fake_client.exchange_calls == ["sess-3"]


async def test_protected_tool_returns_auth_required_payload_when_lane_enabled(
    isolated_runtime_config,
    monkeypatch,
):
    _write_runtime_config(
        isolated_runtime_config,
        {
            "auth_lane": "secondme_ai",
            "scene_id": "craw-opc",
            "entry_surface": "clawopc",
        },
    )
    fake_client = FakeTowowClient(
        create_result={
            "status": "AUTH_REQUIRED",
            "lane": "secondme_ai",
            "scene_id": "craw-opc",
            "entry_surface": "clawopc",
            "auth_session_id": "sess-4",
            "authorize_url": "https://develop.second.me/oauth/authorize?state=sess-4",
            "poll_url": "https://towow.example/protocol/auth/consumer-sessions/sess-4",
            "expires_at": "2026-03-18T13:00:00Z",
        }
    )
    monkeypatch.setattr(server, "_get_client", lambda: fake_client)

    payload = json.loads(await server.towow_agents())

    assert payload["status"] == "AUTH_REQUIRED"
    assert payload["next_tool"] == "towow_auth_status"
    assert payload["auth_session_id"] == "sess-4"
    assert fake_client.create_calls == [
        {
            "lane": "secondme_ai",
            "scene_id": "craw-opc",
            "entry_surface": "clawopc",
            "consumer_kind": _EXPECTED_CONSUMER_KIND,
        }
    ]


async def test_protected_tool_keeps_legacy_error_without_lane(isolated_runtime_config):
    _write_runtime_config(isolated_runtime_config, {})

    with pytest.raises(ToolError, match="Not logged in\\. Call towow_login or towow_register first\\."):
        await server.towow_agents()


async def test_lane_metadata_is_optional_for_generic_runtime_config_reads(isolated_runtime_config):
    _write_runtime_config(
        isolated_runtime_config,
        {
            "backend_url": "http://127.0.0.1:8080",
            "session_token": "tok-keep",
            "auth_lane": "secondme_ai",
            "entry_surface": "clawopc",
            "scene_id": "craw-opc",
            "scene_display_name": "Scene",
        },
    )
    config = runtime_config._read_config(path=isolated_runtime_config)
    for key in ("auth_lane", "entry_surface", "scene_id", "scene_display_name"):
        config.pop(key, None)
    runtime_config._write_config(config, path=isolated_runtime_config)

    assert runtime_config.get_backend_url() == "http://127.0.0.1:8080"
    assert runtime_config.get_session_token() == "tok-keep"
    assert runtime_config.get_auth_lane() is None
    assert runtime_config.get_entry_surface() is None
    assert runtime_config.get_scene_id() is None
    assert runtime_config.get_scene_display_name() is None
