"""Regression tests for MCP ANP verify key propagation."""

from __future__ import annotations

import json

import httpx
import pytest

from towow_mcp import server
from towow_mcp.client import TowowClient

pytestmark = pytest.mark.asyncio


def _json_response(payload: dict[str, object]) -> httpx.Response:
    return httpx.Response(
        200,
        json=payload,
        headers={"content-type": "application/json"},
    )


async def test_anp_verify_client_includes_signing_public_key() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content.decode("utf-8"))
        return _json_response({"ok": True, "session_token": "sess-1"})

    client = TowowClient(
        backend_url="http://localhost:8000",
        transport=httpx.MockTransport(handler),
    )

    try:
        payload = await client.anp_verify(
            "did:anp:test",
            "challenge-1",
            "signature-1",
            signing_public_key="pubkey-1",
        )
    finally:
        await client.close()

    assert payload["session_token"] == "sess-1"
    assert captured == {
        "method": "POST",
        "url": "http://localhost:8000/protocol/auth/anp/verify",
        "body": {
            "did": "did:anp:test",
            "challenge": "challenge-1",
            "signature": "signature-1",
            "signing_public_key": "pubkey-1",
        },
    }


class FakeTowowClient:
    def __init__(self) -> None:
        self.verify_calls: list[dict[str, str | None]] = []

    async def anp_verify(
        self,
        did: str,
        challenge: str,
        signature: str,
        signing_public_key: str | None = None,
    ) -> dict[str, object]:
        self.verify_calls.append(
            {
                "did": did,
                "challenge": challenge,
                "signature": signature,
                "signing_public_key": signing_public_key,
            }
        )
        return {"ok": True, "session_token": "sess-2"}

    async def close(self) -> None:
        return None


async def test_towow_anp_verify_tool_passes_signing_public_key(monkeypatch: pytest.MonkeyPatch) -> None:
    fake_client = FakeTowowClient()
    monkeypatch.setattr(server, "_get_client", lambda: fake_client)

    payload = json.loads(
        await server.towow_anp_verify(
            did="did:anp:test",
            challenge="challenge-2",
            signature="signature-2",
            signing_public_key="pubkey-2",
        )
    )

    assert payload == {"ok": True, "session_token": "sess-2"}
    assert fake_client.verify_calls == [
        {
            "did": "did:anp:test",
            "challenge": "challenge-2",
            "signature": "signature-2",
            "signing_public_key": "pubkey-2",
        }
    ]
