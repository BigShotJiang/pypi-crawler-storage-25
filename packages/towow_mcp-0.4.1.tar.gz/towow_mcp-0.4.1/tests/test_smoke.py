"""Smoke tests — 验证测试基础设施可用。"""

import json
import stat

import httpx
import pytest

from towow_mcp.config import (
    MCP_SESSION_TTL_SECONDS,
    _read_config,
    _write_config,
    clear_scene,
    clear_session_token,
    get_scene_display_name,
    get_scene_id,
    get_session_token,
    save_scene,
    save_session_token,
)


# ── config 读写 ────────────────────────────────────────────

def test_write_config_sets_permissions(tmp_path):
    """_write_config 创建文件后权限必须是 600。"""
    path = tmp_path / "config.json"
    _write_config({"key": "value"}, path=path)

    mode = path.stat().st_mode & 0o777
    assert mode == 0o600, f"expected 0o600, got {oct(mode)}"


def test_read_write_roundtrip(tmp_path):
    """config 写入后可以正确读回。"""
    path = tmp_path / "config.json"
    data = {"agent_id": "a1", "display_name": "测试"}
    _write_config(data, path=path)

    loaded = _read_config(path=path)
    assert loaded == data


def test_read_missing_config(tmp_path):
    """不存在的配置文件应返回空 dict。"""
    path = tmp_path / "nonexistent.json"
    assert _read_config(path=path) == {}


# ── session token 管理 ─────────────────────────────────────

def test_save_and_get_session_token(tmp_path):
    """save_session_token → get_session_token 应往返一致。"""
    path = tmp_path / "config.json"
    save_session_token("my-secret-token", path=path)

    assert get_session_token(path=path) == "my-secret-token"
    # 文件权限必须是 600
    mode = path.stat().st_mode & 0o777
    assert mode == 0o600


def test_clear_session_token(tmp_path):
    """clear_session_token 后 get 应返回 None。"""
    path = tmp_path / "config.json"
    save_session_token("token-to-remove", path=path)
    clear_session_token(path=path)

    assert get_session_token(path=path) is None


def test_get_session_token_missing(tmp_path):
    """无配置文件时 get_session_token 应返回 None。"""
    path = tmp_path / "nonexistent.json"
    assert get_session_token(path=path) is None


def test_save_session_token_preserves_other_keys(tmp_path):
    """save_session_token 不应丢失其他配置项。"""
    path = tmp_path / "config.json"
    _write_config({"backend_url": "http://custom"}, path=path)
    save_session_token("tok", path=path)

    config = _read_config(path=path)
    assert config["backend_url"] == "http://custom"
    assert config["session_token"] == "tok"


def test_save_get_and_clear_scene(tmp_path):
    """scene 配置应能独立持久化并清除。"""
    path = tmp_path / "config.json"
    save_scene("startup-hub", "AI 创业组队平台", path=path)

    assert get_scene_id(path=path) == "startup-hub"
    assert get_scene_display_name(path=path) == "AI 创业组队平台"

    clear_scene(path=path)
    assert get_scene_id(path=path) is None
    assert get_scene_display_name(path=path) is None


# ── MCP TTL ────────────────────────────────────────────────

def test_mcp_session_ttl_default():
    """默认 TTL 应为 7 天 = 604800 秒。"""
    assert MCP_SESSION_TTL_SECONDS == 7 * 86400


# ── fixture 可用性 ─────────────────────────────────────────

def test_tmp_config_fixture(tmp_config):
    """tmp_config fixture 应返回可读的配置文件。"""
    data = json.loads(tmp_config.read_text())
    assert "session_token" in data
    assert data["session_token"] == "test-tok"


def test_mock_sse_handler_fixture(mock_sse_handler):
    """mock_sse_handler 应返回 SSE 响应。"""
    transport = mock_sse_handler(["data: hello\n\n"])
    client = httpx.Client(transport=transport)
    resp = client.get("http://test/events")
    assert resp.status_code == 200
    assert resp.headers["content-type"] == "text/event-stream"
    assert "hello" in resp.text

# ── async test 可运行 ──────────────────────────────────────

@pytest.mark.asyncio
async def test_async_works():
    """验证 pytest-asyncio 配置正确，async test 可执行。"""
    result = await _async_add(1, 2)
    assert result == 3


async def _async_add(a: int, b: int) -> int:
    return a + b
