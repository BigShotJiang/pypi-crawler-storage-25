"""
sshDCommander license validation client.

Implements the client-side license flow:
- License key activation via API
- Ed25519 token signature verification
- 7-day re-validation with 72-hour offline grace
- 5-day trial mode with local countdown
- Token storage at ~/.sshdcommander/license.token

SECURITY: Never log, print, or expose license keys or tokens.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from cryptography.exceptions import InvalidSignature

from config import CONFIG_DIR

log = logging.getLogger("sshdcommander.license")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

API_BASE_URL = "https://api.sshdcommander.com/api"
LICENSE_TOKEN_FILE: Path = CONFIG_DIR / "license.token"
TRIAL_STATE_FILE: Path = CONFIG_DIR / "trial.json"

REVALIDATION_INTERVAL_SECONDS = 7 * 24 * 60 * 60   # 7 days
GRACE_PERIOD_SECONDS = 72 * 60 * 60                 # 72 hours
TRIAL_DURATION_SECONDS = 5 * 24 * 60 * 60           # 5 days

RENEWAL_URL = "https://sshdcommander.com/pricing"

# Three-tier Ed25519 public keys for token signature verification.
# These keys are embedded in the compiled binary (.pyd/.so).
# The corresponding private keys are stored separately per tier:
#   Tier 1 (hot):  Active signing key, on the API server
#   Tier 2 (warm): Emergency key, stored offline (accidental hot key exposure)
#   Tier 3 (cold): Recovery key, generated on air-gapped machine (full server compromise)
#
# Format: raw 32-byte public key, base64-encoded.
# IMPORTANT: Replace with production keys before release.
#
# After Scenario A (hot key compromise) or Scenario B (server compromise)
# activation, push a replacement binary to PyPI within 48 hours.
_ED25519_PUBLIC_KEYS = (
    "rCUYvplRrusDINcp5s4ZFmmhuk9e586Q7yPN+MFRIJM=",  # Tier 1: hot (daily signing)
    "QrvqfGjhPj/jxcE03qZ0HSAfegAlj+Faa7LUA02kZns=",  # Tier 2: warm (emergency, accidental hot key exposure)
    "GGawA8tsptN8IEc8Gifn9C9wAMjz+DYAemmgjpzh6fQ=",  # Tier 3: cold (recovery, full server compromise)
)

REVOKED_KEYS_FILE: Path = CONFIG_DIR / "revoked_keys.json"


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class LicenseTokenPayload:
    """Decoded license token payload."""
    lid: str    # License ID
    tier: str   # 'base' or 'base+mcp'
    exp: int    # Expiry (Unix timestamp)
    iat: int    # Issued-at (Unix timestamp)
    sub: str    # Customer ID


@dataclass
class LicenseStatus:
    """Current license state for daemon startup decision."""
    valid: bool
    mode: str           # 'licensed', 'trial', 'expired', 'none'
    tier: str           # 'base', 'base+mcp', 'trial', ''
    message: str        # Human-readable status
    expires_at: int     # Unix timestamp (0 if not applicable)
    needs_revalidation: bool  # True if online check needed


# ---------------------------------------------------------------------------
# Ed25519 verification
# ---------------------------------------------------------------------------

def _load_revoked_keys() -> list[int]:
    """Load the list of revoked key indices from disk."""
    if not REVOKED_KEYS_FILE.is_file():
        return []
    try:
        data = json.loads(REVOKED_KEYS_FILE.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return [i for i in data if isinstance(i, int)]
    except (json.JSONDecodeError, OSError):
        pass
    return []


def _store_revoked_keys(indices: list[int]) -> None:
    """Store revoked key indices to disk."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    REVOKED_KEYS_FILE.write_text(
        json.dumps(sorted(set(indices)), ensure_ascii=False),
        encoding="utf-8",
    )


def _clear_revoked_keys() -> None:
    """Remove the revoked keys file."""
    try:
        REVOKED_KEYS_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _verify_token_signature(token: str) -> Optional[LicenseTokenPayload]:
    """Verify an Ed25519-signed compact token.

    Token format: base64(payload_json) + "." + base64(signature)
    Tries each embedded public key in order (hot, warm, cold),
    skipping any keys whose indices appear in the local revocation list.
    Returns the decoded payload if valid, None otherwise.
    """
    parts = token.split(".")
    if len(parts) != 2:
        return None

    import base64
    try:
        payload_bytes = base64.b64decode(parts[0])
        signature = base64.b64decode(parts[1])
    except Exception:
        return None

    revoked = _load_revoked_keys()

    for idx, pub_key_b64 in enumerate(_ED25519_PUBLIC_KEYS):
        if idx in revoked:
            continue
        try:
            raw_bytes = base64.b64decode(pub_key_b64)
            public_key = Ed25519PublicKey.from_public_bytes(raw_bytes)
            public_key.verify(signature, payload_bytes)
            # Signature verified with key at index idx
            break
        except (InvalidSignature, Exception):
            continue
    else:
        # No key verified the signature
        return None

    try:
        data = json.loads(payload_bytes.decode("utf-8"))
        return LicenseTokenPayload(
            lid=data["lid"],
            tier=data["tier"],
            exp=data["exp"],
            iat=data["iat"],
            sub=data["sub"],
        )
    except (json.JSONDecodeError, KeyError, UnicodeDecodeError):
        return None


# ---------------------------------------------------------------------------
# Token storage
# ---------------------------------------------------------------------------

def _store_token(token: str) -> None:
    """Store the license token to disk."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    LICENSE_TOKEN_FILE.write_text(token, encoding="utf-8")
    log.debug("License token stored.")


def _load_token() -> Optional[str]:
    """Load the license token from disk."""
    if not LICENSE_TOKEN_FILE.is_file():
        return None
    try:
        return LICENSE_TOKEN_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return None


def _remove_token() -> None:
    """Remove the stored license token."""
    try:
        LICENSE_TOKEN_FILE.unlink(missing_ok=True)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Trial mode
# ---------------------------------------------------------------------------

def _load_trial_state() -> Optional[dict]:
    """Load trial state from disk."""
    if not TRIAL_STATE_FILE.is_file():
        return None
    try:
        data = json.loads(TRIAL_STATE_FILE.read_text(encoding="utf-8"))
        return data
    except (json.JSONDecodeError, OSError):
        return None


def _save_trial_state(state: dict) -> None:
    """Save trial state to disk."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TRIAL_STATE_FILE.write_text(
        json.dumps(state, ensure_ascii=False),
        encoding="utf-8",
    )


def start_trial() -> LicenseStatus:
    """Start a local trial (5 days, no license key needed).

    If a trial was already used, returns expired status.
    """
    existing = _load_trial_state()
    if existing is not None:
        # Trial already started — check if still valid
        expires_at = existing.get("expires_at", 0)
        now = int(time.time())
        if now < expires_at:
            remaining = expires_at - now
            days = remaining // 86400
            hours = (remaining % 86400) // 3600
            return LicenseStatus(
                valid=True,
                mode="trial",
                tier="trial",
                message=f"Trial active: {days}d {hours}h remaining.",
                expires_at=expires_at,
                needs_revalidation=False,
            )
        else:
            return LicenseStatus(
                valid=False,
                mode="expired",
                tier="",
                message=f"Trial expired. Purchase at {RENEWAL_URL}",
                expires_at=expires_at,
                needs_revalidation=False,
            )

    # Start new trial
    now = int(time.time())
    expires_at = now + TRIAL_DURATION_SECONDS
    _save_trial_state({
        "started_at": now,
        "expires_at": expires_at,
    })

    return LicenseStatus(
        valid=True,
        mode="trial",
        tier="trial",
        message="Trial started: 5 days of full access.",
        expires_at=expires_at,
        needs_revalidation=False,
    )


def _check_trial() -> Optional[LicenseStatus]:
    """Check if there is an active trial. Returns None if no trial exists."""
    state = _load_trial_state()
    if state is None:
        return None

    expires_at = state.get("expires_at", 0)
    now = int(time.time())

    if now < expires_at:
        remaining = expires_at - now
        days = remaining // 86400
        hours = (remaining % 86400) // 3600
        return LicenseStatus(
            valid=True,
            mode="trial",
            tier="trial",
            message=f"Trial active: {days}d {hours}h remaining.",
            expires_at=expires_at,
            needs_revalidation=False,
        )
    else:
        return LicenseStatus(
            valid=False,
            mode="expired",
            tier="",
            message=f"Trial expired. Purchase at {RENEWAL_URL}",
            expires_at=expires_at,
            needs_revalidation=False,
        )


# ---------------------------------------------------------------------------
# API communication
# ---------------------------------------------------------------------------

def _api_activate(key: str, email: str) -> dict:
    """Call the license activation API endpoint.

    Returns the API response dict on success.
    Raises RuntimeError on failure.
    """
    import httpx

    url = f"{API_BASE_URL}/licenses/activate"
    try:
        response = httpx.post(
            url,
            json={"key": key, "email": email},
            timeout=30.0,
            headers={"Content-Type": "application/json"},
        )
    except httpx.ConnectError:
        raise RuntimeError(
            "Cannot reach license server. Check your internet connection."
        )
    except httpx.TimeoutException:
        raise RuntimeError(
            "License server did not respond in time. Try again later."
        )

    if response.status_code == 200:
        data = response.json()
        if data.get("success") and data.get("token"):
            return data
        raise RuntimeError("Unexpected response from license server.")

    # Handle error responses
    try:
        error_data = response.json()
        message = error_data.get("message", "Unknown error")
    except Exception:
        message = f"HTTP {response.status_code}"

    if response.status_code == 403:
        raise RuntimeError(f"Activation failed: {message}")
    elif response.status_code == 404:
        raise RuntimeError("Invalid license key.")
    elif response.status_code == 429:
        raise RuntimeError("Too many activation attempts. Please wait and try again.")
    else:
        raise RuntimeError(f"License server error: {message}")


def _api_validate(token: str) -> Optional[dict]:
    """Call the license validation API endpoint for token refresh.

    Returns the API response dict on success, None on failure.
    Does not raise — network errors return None (grace period applies).

    The server may include a ``revoked_keys`` list in the response (indices
    0-2 indicating which embedded public keys are revoked).  When present,
    the client stores them locally so that tokens signed by revoked keys
    are rejected even when offline.
    """
    import httpx

    url = f"{API_BASE_URL}/licenses/validate"
    try:
        response = httpx.post(
            url,
            json={"token": token},
            timeout=30.0,
            headers={"Content-Type": "application/json"},
        )
    except (httpx.ConnectError, httpx.TimeoutException):
        log.debug("License validation API unreachable (grace period applies).")
        return None

    if response.status_code == 200:
        data = response.json()
        # Process key revocation info if present (backward compatible)
        revoked = data.get("revoked_keys")
        if isinstance(revoked, list) and revoked:
            _store_revoked_keys([i for i in revoked if isinstance(i, int)])
        return data

    log.debug("License validation failed: HTTP %d", response.status_code)
    return None


def _api_deactivate(key: str, email: str) -> bool:
    """Call the license deactivation API endpoint.

    Returns True on success, raises RuntimeError on failure.
    """
    import httpx

    url = f"{API_BASE_URL}/licenses/deactivate"
    try:
        response = httpx.post(
            url,
            json={"key": key, "email": email},
            timeout=30.0,
            headers={"Content-Type": "application/json"},
        )
    except (httpx.ConnectError, httpx.TimeoutException):
        raise RuntimeError(
            "Cannot reach license server. Check your internet connection."
        )

    if response.status_code == 200:
        return True

    try:
        error_data = response.json()
        message = error_data.get("message", "Unknown error")
    except Exception:
        message = f"HTTP {response.status_code}"

    raise RuntimeError(f"Deactivation failed: {message}")


# ---------------------------------------------------------------------------
# Activation
# ---------------------------------------------------------------------------

def activate(key: str, email: str) -> LicenseStatus:
    """Activate a license key.

    Sends key + email to the API, receives a signed token, stores it locally.
    """
    # Validate key format: SSHDCMD-XXXX-XXXX-XXXX-XXXX
    if not _validate_key_format(key):
        return LicenseStatus(
            valid=False,
            mode="none",
            tier="",
            message="Invalid license key format. Expected: SSHDCMD-XXXX-XXXX-XXXX-XXXX",
            expires_at=0,
            needs_revalidation=False,
        )

    try:
        result = _api_activate(key, email)
    except RuntimeError as exc:
        return LicenseStatus(
            valid=False,
            mode="none",
            tier="",
            message=str(exc),
            expires_at=0,
            needs_revalidation=False,
        )

    token = result["token"]

    # Verify the received token signature locally
    payload = _verify_token_signature(token)
    if payload is None:
        return LicenseStatus(
            valid=False,
            mode="none",
            tier="",
            message="Received token has invalid signature. Contact support.",
            expires_at=0,
            needs_revalidation=False,
        )

    # Store the token
    _store_token(token)

    # Remove trial state if it exists (upgraded to licensed)
    try:
        TRIAL_STATE_FILE.unlink(missing_ok=True)
    except OSError:
        pass

    return LicenseStatus(
        valid=True,
        mode="licensed",
        tier=payload.tier,
        message=f"License activated. Tier: {payload.tier}.",
        expires_at=payload.exp,
        needs_revalidation=False,
    )


def deactivate(key: str, email: str) -> LicenseStatus:
    """Deactivate a license (unbind from this machine)."""
    if not _validate_key_format(key):
        return LicenseStatus(
            valid=False,
            mode="none",
            tier="",
            message="Invalid license key format.",
            expires_at=0,
            needs_revalidation=False,
        )

    try:
        _api_deactivate(key, email)
    except RuntimeError as exc:
        return LicenseStatus(
            valid=False,
            mode="none",
            tier="",
            message=str(exc),
            expires_at=0,
            needs_revalidation=False,
        )

    _remove_token()

    return LicenseStatus(
        valid=True,
        mode="none",
        tier="",
        message="License deactivated. You can activate on another machine.",
        expires_at=0,
        needs_revalidation=False,
    )


# ---------------------------------------------------------------------------
# Validation (daemon startup)
# ---------------------------------------------------------------------------

def check_license() -> LicenseStatus:
    """Check the current license status. Called at daemon startup.

    Order of checks:
    1. Stored token -> verify signature -> check expiry -> check revalidation
    2. Active trial -> check countdown
    3. No license -> return 'none'
    """
    # 1. Check for stored token
    token = _load_token()
    if token is not None:
        payload = _verify_token_signature(token)
        if payload is not None:
            now = int(time.time())

            # Check if license itself has expired
            if now >= payload.exp:
                return LicenseStatus(
                    valid=False,
                    mode="expired",
                    tier="",
                    message=f"License expired. Renew at {RENEWAL_URL}",
                    expires_at=payload.exp,
                    needs_revalidation=False,
                )

            # Check if re-validation is needed (every 7 days)
            age = now - payload.iat
            if age >= REVALIDATION_INTERVAL_SECONDS:
                # Try online re-validation
                result = _api_validate(token)
                if result is not None and result.get("valid"):
                    # Got fresh token
                    fresh_token = result.get("token")
                    if fresh_token:
                        fresh_payload = _verify_token_signature(fresh_token)
                        if fresh_payload is not None:
                            _store_token(fresh_token)
                            return LicenseStatus(
                                valid=True,
                                mode="licensed",
                                tier=fresh_payload.tier,
                                message=f"License valid. Tier: {fresh_payload.tier}.",
                                expires_at=fresh_payload.exp,
                                needs_revalidation=False,
                            )
                    # API said valid but didn't return a usable token — keep current
                    return LicenseStatus(
                        valid=True,
                        mode="licensed",
                        tier=payload.tier,
                        message=f"License valid (re-validation partial). Tier: {payload.tier}.",
                        expires_at=payload.exp,
                        needs_revalidation=False,
                    )

                elif result is not None and not result.get("valid"):
                    # Server explicitly said invalid
                    server_msg = result.get("message", "License is no longer valid")
                    _remove_token()
                    return LicenseStatus(
                        valid=False,
                        mode="expired",
                        tier="",
                        message=f"{server_msg}. Renew at {RENEWAL_URL}",
                        expires_at=payload.exp,
                        needs_revalidation=False,
                    )

                else:
                    # API unreachable — apply grace period
                    grace_deadline = payload.iat + REVALIDATION_INTERVAL_SECONDS + GRACE_PERIOD_SECONDS
                    if now < grace_deadline:
                        remaining = grace_deadline - now
                        hours = remaining // 3600
                        return LicenseStatus(
                            valid=True,
                            mode="licensed",
                            tier=payload.tier,
                            message=(
                                f"License valid (offline grace: {hours}h remaining). "
                                f"Tier: {payload.tier}."
                            ),
                            expires_at=payload.exp,
                            needs_revalidation=True,
                        )
                    else:
                        # Grace period expired
                        return LicenseStatus(
                            valid=False,
                            mode="expired",
                            tier="",
                            message=(
                                f"License validation failed: offline too long. "
                                f"Connect to the internet and restart. "
                                f"Renew at {RENEWAL_URL}"
                            ),
                            expires_at=payload.exp,
                            needs_revalidation=True,
                        )

            # Token is fresh enough — valid
            return LicenseStatus(
                valid=True,
                mode="licensed",
                tier=payload.tier,
                message=f"License valid. Tier: {payload.tier}.",
                expires_at=payload.exp,
                needs_revalidation=False,
            )

        else:
            # Token exists but signature invalid.
            # If there are revoked keys, the failure may be because the
            # token was signed by a now-revoked key.  Force online
            # re-validation to get a fresh token signed by the new active key.
            revoked = _load_revoked_keys()
            if revoked:
                log.info("Token verification failed with revoked keys present — forcing re-validation.")
                result = _api_validate(token)
                if result is not None and result.get("valid"):
                    fresh_token = result.get("token")
                    if fresh_token:
                        fresh_payload = _verify_token_signature(fresh_token)
                        if fresh_payload is not None:
                            _store_token(fresh_token)
                            return LicenseStatus(
                                valid=True,
                                mode="licensed",
                                tier=fresh_payload.tier,
                                message=f"License re-validated after key rotation. Tier: {fresh_payload.tier}.",
                                expires_at=fresh_payload.exp,
                                needs_revalidation=False,
                            )

            log.warning("Stored license token has invalid signature.")
            _remove_token()

    # 2. Check for trial
    trial_status = _check_trial()
    if trial_status is not None:
        return trial_status

    # 3. No license
    return LicenseStatus(
        valid=False,
        mode="none",
        tier="",
        message=(
            "No license found. Activate with: sshdctl activate <KEY> --email <EMAIL>\n"
            f"Or start a trial: sshdctl trial\n"
            f"Purchase at {RENEWAL_URL}"
        ),
        expires_at=0,
        needs_revalidation=False,
    )


# ---------------------------------------------------------------------------
# License status display
# ---------------------------------------------------------------------------

def format_status() -> str:
    """Return a human-readable license status string for CLI display."""
    status = check_license()
    lines = [f"License:  {status.mode.upper()}"]

    if status.mode == "licensed":
        lines.append(f"Tier:     {status.tier}")
        import datetime
        exp_dt = datetime.datetime.fromtimestamp(status.expires_at, tz=datetime.timezone.utc)
        lines.append(f"Expires:  {exp_dt.strftime('%Y-%m-%d')}")
        if status.needs_revalidation:
            lines.append("Status:   Needs online re-validation")
        else:
            lines.append("Status:   Valid")
    elif status.mode == "trial":
        remaining = status.expires_at - int(time.time())
        days = remaining // 86400
        hours = (remaining % 86400) // 3600
        lines.append(f"Remaining: {days}d {hours}h")
    elif status.mode == "expired":
        lines.append(f"Message:  {status.message}")
    elif status.mode == "none":
        lines.append(f"Message:  {status.message}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Key format validation
# ---------------------------------------------------------------------------

def _validate_key_format(key: str) -> bool:
    """Validate license key format: SSHDCMD-XXXX-XXXX-XXXX-XXXX.

    Each X block is 4 Base32 characters (A-Z, 2-7).
    """
    if not key.startswith("SSHDCMD-"):
        return False
    rest = key[8:]  # Remove prefix
    blocks = rest.split("-")
    if len(blocks) != 4:
        return False
    _BASE32_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567")
    for block in blocks:
        if len(block) != 4:
            return False
        if not all(c in _BASE32_CHARS for c in block):
            return False
    return True
