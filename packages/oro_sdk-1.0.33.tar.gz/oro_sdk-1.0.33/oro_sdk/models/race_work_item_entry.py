from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="RaceWorkItemEntry")


@_attrs_define
class RaceWorkItemEntry:
    """A work item in a race.

    Attributes:
        agent_version_id (UUID): Agent version ID
        phase (str): Evaluation phase
        is_closed (bool): Whether work is complete
        is_cancelled (bool): Whether work was cancelled
        included_success_count (int): Successful evaluations
        active_count (int): Active evaluations
        required_successes (int): Required successful evaluations
        agent_name (None | str | Unset): Agent name
    """

    agent_version_id: UUID
    phase: str
    is_closed: bool
    is_cancelled: bool
    included_success_count: int
    active_count: int
    required_successes: int
    agent_name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        phase = self.phase

        is_closed = self.is_closed

        is_cancelled = self.is_cancelled

        included_success_count = self.included_success_count

        active_count = self.active_count

        required_successes = self.required_successes

        agent_name: None | str | Unset
        if isinstance(self.agent_name, Unset):
            agent_name = UNSET
        else:
            agent_name = self.agent_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "phase": phase,
                "is_closed": is_closed,
                "is_cancelled": is_cancelled,
                "included_success_count": included_success_count,
                "active_count": active_count,
                "required_successes": required_successes,
            }
        )
        if agent_name is not UNSET:
            field_dict["agent_name"] = agent_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        phase = d.pop("phase")

        is_closed = d.pop("is_closed")

        is_cancelled = d.pop("is_cancelled")

        included_success_count = d.pop("included_success_count")

        active_count = d.pop("active_count")

        required_successes = d.pop("required_successes")

        def _parse_agent_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        agent_name = _parse_agent_name(d.pop("agent_name", UNSET))

        race_work_item_entry = cls(
            agent_version_id=agent_version_id,
            phase=phase,
            is_closed=is_closed,
            is_cancelled=is_cancelled,
            included_success_count=included_success_count,
            active_count=active_count,
            required_successes=required_successes,
            agent_name=agent_name,
        )

        race_work_item_entry.additional_properties = d
        return race_work_item_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
