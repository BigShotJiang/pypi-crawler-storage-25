from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateSuiteRequest")


@_attrs_define
class CreateSuiteRequest:
    """Request to create a new problem suite.

    Attributes:
        problem_suite_uri (str): URI to the problem suite definition
        is_public (bool | Unset): Whether this suite is queryable via public API Default: True.
    """

    problem_suite_uri: str
    is_public: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        problem_suite_uri = self.problem_suite_uri

        is_public = self.is_public

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "problem_suite_uri": problem_suite_uri,
            }
        )
        if is_public is not UNSET:
            field_dict["is_public"] = is_public

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        problem_suite_uri = d.pop("problem_suite_uri")

        is_public = d.pop("is_public", UNSET)

        create_suite_request = cls(
            problem_suite_uri=problem_suite_uri,
            is_public=is_public,
        )

        create_suite_request.additional_properties = d
        return create_suite_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
