from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.race_summary import RaceSummary


T = TypeVar("T", bound="CurrentRacesResponse")


@_attrs_define
class CurrentRacesResponse:
    """Response for current race state.

    Attributes:
        races (list[RaceSummary]): Active races
    """

    races: list[RaceSummary]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        races = []
        for races_item_data in self.races:
            races_item = races_item_data.to_dict()
            races.append(races_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "races": races,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.race_summary import RaceSummary

        d = dict(src_dict)
        races = []
        _races = d.pop("races")
        for races_item_data in _races:
            races_item = RaceSummary.from_dict(races_item_data)

            races.append(races_item)

        current_races_response = cls(
            races=races,
        )

        current_races_response.additional_properties = d
        return current_races_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
