from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="RaceSummary")


@_attrs_define
class RaceSummary:
    """Summary of a race for the current state view.

    Attributes:
        race_id (UUID): Race ID
        suite_id (int): Problem suite ID
        status (str): Current race status
        race_number (int | None | Unset):
        qualifying_closes_at (datetime.datetime | None | Unset):
        race_started_at (datetime.datetime | None | Unset):
        race_completed_at (datetime.datetime | None | Unset):
        winner_agent_version_id (None | Unset | UUID):
        winner_score (float | None | Unset):
        qualifier_count (int | Unset): Number of qualifiers Default: 0.
        work_item_count (int | Unset): Number of work items Default: 0.
    """

    race_id: UUID
    suite_id: int
    status: str
    race_number: int | None | Unset = UNSET
    qualifying_closes_at: datetime.datetime | None | Unset = UNSET
    race_started_at: datetime.datetime | None | Unset = UNSET
    race_completed_at: datetime.datetime | None | Unset = UNSET
    winner_agent_version_id: None | Unset | UUID = UNSET
    winner_score: float | None | Unset = UNSET
    qualifier_count: int | Unset = 0
    work_item_count: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        race_id = str(self.race_id)

        suite_id = self.suite_id

        status = self.status

        race_number: int | None | Unset
        if isinstance(self.race_number, Unset):
            race_number = UNSET
        else:
            race_number = self.race_number

        qualifying_closes_at: None | str | Unset
        if isinstance(self.qualifying_closes_at, Unset):
            qualifying_closes_at = UNSET
        elif isinstance(self.qualifying_closes_at, datetime.datetime):
            qualifying_closes_at = self.qualifying_closes_at.isoformat()
        else:
            qualifying_closes_at = self.qualifying_closes_at

        race_started_at: None | str | Unset
        if isinstance(self.race_started_at, Unset):
            race_started_at = UNSET
        elif isinstance(self.race_started_at, datetime.datetime):
            race_started_at = self.race_started_at.isoformat()
        else:
            race_started_at = self.race_started_at

        race_completed_at: None | str | Unset
        if isinstance(self.race_completed_at, Unset):
            race_completed_at = UNSET
        elif isinstance(self.race_completed_at, datetime.datetime):
            race_completed_at = self.race_completed_at.isoformat()
        else:
            race_completed_at = self.race_completed_at

        winner_agent_version_id: None | str | Unset
        if isinstance(self.winner_agent_version_id, Unset):
            winner_agent_version_id = UNSET
        elif isinstance(self.winner_agent_version_id, UUID):
            winner_agent_version_id = str(self.winner_agent_version_id)
        else:
            winner_agent_version_id = self.winner_agent_version_id

        winner_score: float | None | Unset
        if isinstance(self.winner_score, Unset):
            winner_score = UNSET
        else:
            winner_score = self.winner_score

        qualifier_count = self.qualifier_count

        work_item_count = self.work_item_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "race_id": race_id,
                "suite_id": suite_id,
                "status": status,
            }
        )
        if race_number is not UNSET:
            field_dict["race_number"] = race_number
        if qualifying_closes_at is not UNSET:
            field_dict["qualifying_closes_at"] = qualifying_closes_at
        if race_started_at is not UNSET:
            field_dict["race_started_at"] = race_started_at
        if race_completed_at is not UNSET:
            field_dict["race_completed_at"] = race_completed_at
        if winner_agent_version_id is not UNSET:
            field_dict["winner_agent_version_id"] = winner_agent_version_id
        if winner_score is not UNSET:
            field_dict["winner_score"] = winner_score
        if qualifier_count is not UNSET:
            field_dict["qualifier_count"] = qualifier_count
        if work_item_count is not UNSET:
            field_dict["work_item_count"] = work_item_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        race_id = UUID(d.pop("race_id"))

        suite_id = d.pop("suite_id")

        status = d.pop("status")

        def _parse_race_number(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        race_number = _parse_race_number(d.pop("race_number", UNSET))

        def _parse_qualifying_closes_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                qualifying_closes_at_type_0 = isoparse(data)

                return qualifying_closes_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        qualifying_closes_at = _parse_qualifying_closes_at(d.pop("qualifying_closes_at", UNSET))

        def _parse_race_started_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                race_started_at_type_0 = isoparse(data)

                return race_started_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        race_started_at = _parse_race_started_at(d.pop("race_started_at", UNSET))

        def _parse_race_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                race_completed_at_type_0 = isoparse(data)

                return race_completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        race_completed_at = _parse_race_completed_at(d.pop("race_completed_at", UNSET))

        def _parse_winner_agent_version_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                winner_agent_version_id_type_0 = UUID(data)

                return winner_agent_version_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        winner_agent_version_id = _parse_winner_agent_version_id(d.pop("winner_agent_version_id", UNSET))

        def _parse_winner_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        winner_score = _parse_winner_score(d.pop("winner_score", UNSET))

        qualifier_count = d.pop("qualifier_count", UNSET)

        work_item_count = d.pop("work_item_count", UNSET)

        race_summary = cls(
            race_id=race_id,
            suite_id=suite_id,
            status=status,
            race_number=race_number,
            qualifying_closes_at=qualifying_closes_at,
            race_started_at=race_started_at,
            race_completed_at=race_completed_at,
            winner_agent_version_id=winner_agent_version_id,
            winner_score=winner_score,
            qualifier_count=qualifier_count,
            work_item_count=work_item_count,
        )

        race_summary.additional_properties = d
        return race_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
