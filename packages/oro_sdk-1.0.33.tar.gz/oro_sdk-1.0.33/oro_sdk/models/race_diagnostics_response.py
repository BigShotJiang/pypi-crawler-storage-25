from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.race_qualifier_entry import RaceQualifierEntry
    from ..models.race_work_item_entry import RaceWorkItemEntry


T = TypeVar("T", bound="RaceDiagnosticsResponse")


@_attrs_define
class RaceDiagnosticsResponse:
    """Detailed diagnostics for a specific race.

    Attributes:
        race_id (UUID): Race ID
        suite_id (int): Problem suite ID
        status (str): Current race status
        race_number (int | None | Unset):
        qualifying_closes_at (datetime.datetime | None | Unset):
        race_started_at (datetime.datetime | None | Unset):
        race_completed_at (datetime.datetime | None | Unset):
        winner_agent_version_id (None | Unset | UUID):
        winner_score (float | None | Unset):
        qualifying_threshold (float | None | Unset):
        incumbent_agent_version_id (None | Unset | UUID):
        problem_seed (None | str | Unset):
        problem_count (int | Unset): Number of race problems Default: 0.
        qualifiers (list[RaceQualifierEntry] | Unset):
        work_items (list[RaceWorkItemEntry] | Unset):
    """

    race_id: UUID
    suite_id: int
    status: str
    race_number: int | None | Unset = UNSET
    qualifying_closes_at: datetime.datetime | None | Unset = UNSET
    race_started_at: datetime.datetime | None | Unset = UNSET
    race_completed_at: datetime.datetime | None | Unset = UNSET
    winner_agent_version_id: None | Unset | UUID = UNSET
    winner_score: float | None | Unset = UNSET
    qualifying_threshold: float | None | Unset = UNSET
    incumbent_agent_version_id: None | Unset | UUID = UNSET
    problem_seed: None | str | Unset = UNSET
    problem_count: int | Unset = 0
    qualifiers: list[RaceQualifierEntry] | Unset = UNSET
    work_items: list[RaceWorkItemEntry] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        race_id = str(self.race_id)

        suite_id = self.suite_id

        status = self.status

        race_number: int | None | Unset
        if isinstance(self.race_number, Unset):
            race_number = UNSET
        else:
            race_number = self.race_number

        qualifying_closes_at: None | str | Unset
        if isinstance(self.qualifying_closes_at, Unset):
            qualifying_closes_at = UNSET
        elif isinstance(self.qualifying_closes_at, datetime.datetime):
            qualifying_closes_at = self.qualifying_closes_at.isoformat()
        else:
            qualifying_closes_at = self.qualifying_closes_at

        race_started_at: None | str | Unset
        if isinstance(self.race_started_at, Unset):
            race_started_at = UNSET
        elif isinstance(self.race_started_at, datetime.datetime):
            race_started_at = self.race_started_at.isoformat()
        else:
            race_started_at = self.race_started_at

        race_completed_at: None | str | Unset
        if isinstance(self.race_completed_at, Unset):
            race_completed_at = UNSET
        elif isinstance(self.race_completed_at, datetime.datetime):
            race_completed_at = self.race_completed_at.isoformat()
        else:
            race_completed_at = self.race_completed_at

        winner_agent_version_id: None | str | Unset
        if isinstance(self.winner_agent_version_id, Unset):
            winner_agent_version_id = UNSET
        elif isinstance(self.winner_agent_version_id, UUID):
            winner_agent_version_id = str(self.winner_agent_version_id)
        else:
            winner_agent_version_id = self.winner_agent_version_id

        winner_score: float | None | Unset
        if isinstance(self.winner_score, Unset):
            winner_score = UNSET
        else:
            winner_score = self.winner_score

        qualifying_threshold: float | None | Unset
        if isinstance(self.qualifying_threshold, Unset):
            qualifying_threshold = UNSET
        else:
            qualifying_threshold = self.qualifying_threshold

        incumbent_agent_version_id: None | str | Unset
        if isinstance(self.incumbent_agent_version_id, Unset):
            incumbent_agent_version_id = UNSET
        elif isinstance(self.incumbent_agent_version_id, UUID):
            incumbent_agent_version_id = str(self.incumbent_agent_version_id)
        else:
            incumbent_agent_version_id = self.incumbent_agent_version_id

        problem_seed: None | str | Unset
        if isinstance(self.problem_seed, Unset):
            problem_seed = UNSET
        else:
            problem_seed = self.problem_seed

        problem_count = self.problem_count

        qualifiers: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.qualifiers, Unset):
            qualifiers = []
            for qualifiers_item_data in self.qualifiers:
                qualifiers_item = qualifiers_item_data.to_dict()
                qualifiers.append(qualifiers_item)

        work_items: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.work_items, Unset):
            work_items = []
            for work_items_item_data in self.work_items:
                work_items_item = work_items_item_data.to_dict()
                work_items.append(work_items_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "race_id": race_id,
                "suite_id": suite_id,
                "status": status,
            }
        )
        if race_number is not UNSET:
            field_dict["race_number"] = race_number
        if qualifying_closes_at is not UNSET:
            field_dict["qualifying_closes_at"] = qualifying_closes_at
        if race_started_at is not UNSET:
            field_dict["race_started_at"] = race_started_at
        if race_completed_at is not UNSET:
            field_dict["race_completed_at"] = race_completed_at
        if winner_agent_version_id is not UNSET:
            field_dict["winner_agent_version_id"] = winner_agent_version_id
        if winner_score is not UNSET:
            field_dict["winner_score"] = winner_score
        if qualifying_threshold is not UNSET:
            field_dict["qualifying_threshold"] = qualifying_threshold
        if incumbent_agent_version_id is not UNSET:
            field_dict["incumbent_agent_version_id"] = incumbent_agent_version_id
        if problem_seed is not UNSET:
            field_dict["problem_seed"] = problem_seed
        if problem_count is not UNSET:
            field_dict["problem_count"] = problem_count
        if qualifiers is not UNSET:
            field_dict["qualifiers"] = qualifiers
        if work_items is not UNSET:
            field_dict["work_items"] = work_items

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.race_qualifier_entry import RaceQualifierEntry
        from ..models.race_work_item_entry import RaceWorkItemEntry

        d = dict(src_dict)
        race_id = UUID(d.pop("race_id"))

        suite_id = d.pop("suite_id")

        status = d.pop("status")

        def _parse_race_number(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        race_number = _parse_race_number(d.pop("race_number", UNSET))

        def _parse_qualifying_closes_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                qualifying_closes_at_type_0 = isoparse(data)

                return qualifying_closes_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        qualifying_closes_at = _parse_qualifying_closes_at(d.pop("qualifying_closes_at", UNSET))

        def _parse_race_started_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                race_started_at_type_0 = isoparse(data)

                return race_started_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        race_started_at = _parse_race_started_at(d.pop("race_started_at", UNSET))

        def _parse_race_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                race_completed_at_type_0 = isoparse(data)

                return race_completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        race_completed_at = _parse_race_completed_at(d.pop("race_completed_at", UNSET))

        def _parse_winner_agent_version_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                winner_agent_version_id_type_0 = UUID(data)

                return winner_agent_version_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        winner_agent_version_id = _parse_winner_agent_version_id(d.pop("winner_agent_version_id", UNSET))

        def _parse_winner_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        winner_score = _parse_winner_score(d.pop("winner_score", UNSET))

        def _parse_qualifying_threshold(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        qualifying_threshold = _parse_qualifying_threshold(d.pop("qualifying_threshold", UNSET))

        def _parse_incumbent_agent_version_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                incumbent_agent_version_id_type_0 = UUID(data)

                return incumbent_agent_version_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        incumbent_agent_version_id = _parse_incumbent_agent_version_id(d.pop("incumbent_agent_version_id", UNSET))

        def _parse_problem_seed(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        problem_seed = _parse_problem_seed(d.pop("problem_seed", UNSET))

        problem_count = d.pop("problem_count", UNSET)

        _qualifiers = d.pop("qualifiers", UNSET)
        qualifiers: list[RaceQualifierEntry] | Unset = UNSET
        if _qualifiers is not UNSET:
            qualifiers = []
            for qualifiers_item_data in _qualifiers:
                qualifiers_item = RaceQualifierEntry.from_dict(qualifiers_item_data)

                qualifiers.append(qualifiers_item)

        _work_items = d.pop("work_items", UNSET)
        work_items: list[RaceWorkItemEntry] | Unset = UNSET
        if _work_items is not UNSET:
            work_items = []
            for work_items_item_data in _work_items:
                work_items_item = RaceWorkItemEntry.from_dict(work_items_item_data)

                work_items.append(work_items_item)

        race_diagnostics_response = cls(
            race_id=race_id,
            suite_id=suite_id,
            status=status,
            race_number=race_number,
            qualifying_closes_at=qualifying_closes_at,
            race_started_at=race_started_at,
            race_completed_at=race_completed_at,
            winner_agent_version_id=winner_agent_version_id,
            winner_score=winner_score,
            qualifying_threshold=qualifying_threshold,
            incumbent_agent_version_id=incumbent_agent_version_id,
            problem_seed=problem_seed,
            problem_count=problem_count,
            qualifiers=qualifiers,
            work_items=work_items,
        )

        race_diagnostics_response.additional_properties = d
        return race_diagnostics_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
