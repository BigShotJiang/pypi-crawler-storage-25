from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.race_public import RacePublic
    from ..models.race_qualifier_public import RaceQualifierPublic


T = TypeVar("T", bound="RaceCurrentResponse")


@_attrs_define
class RaceCurrentResponse:
    """Response for current race state.

    Attributes:
        race (None | RacePublic | Unset): Active race, if any
        qualifiers (list[RaceQualifierPublic] | Unset): Qualifiers for the active race
    """

    race: None | RacePublic | Unset = UNSET
    qualifiers: list[RaceQualifierPublic] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.race_public import RacePublic

        race: dict[str, Any] | None | Unset
        if isinstance(self.race, Unset):
            race = UNSET
        elif isinstance(self.race, RacePublic):
            race = self.race.to_dict()
        else:
            race = self.race

        qualifiers: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.qualifiers, Unset):
            qualifiers = []
            for qualifiers_item_data in self.qualifiers:
                qualifiers_item = qualifiers_item_data.to_dict()
                qualifiers.append(qualifiers_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if race is not UNSET:
            field_dict["race"] = race
        if qualifiers is not UNSET:
            field_dict["qualifiers"] = qualifiers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.race_public import RacePublic
        from ..models.race_qualifier_public import RaceQualifierPublic

        d = dict(src_dict)

        def _parse_race(data: object) -> None | RacePublic | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                race_type_0 = RacePublic.from_dict(data)

                return race_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RacePublic | Unset, data)

        race = _parse_race(d.pop("race", UNSET))

        _qualifiers = d.pop("qualifiers", UNSET)
        qualifiers: list[RaceQualifierPublic] | Unset = UNSET
        if _qualifiers is not UNSET:
            qualifiers = []
            for qualifiers_item_data in _qualifiers:
                qualifiers_item = RaceQualifierPublic.from_dict(qualifiers_item_data)

                qualifiers.append(qualifiers_item)

        race_current_response = cls(
            race=race,
            qualifiers=qualifiers,
        )

        race_current_response.additional_properties = d
        return race_current_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
