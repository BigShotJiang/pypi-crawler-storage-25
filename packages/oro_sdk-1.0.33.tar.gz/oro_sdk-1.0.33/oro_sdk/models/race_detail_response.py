from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.race_public import RacePublic
    from ..models.race_qualifier_public import RaceQualifierPublic


T = TypeVar("T", bound="RaceDetailResponse")


@_attrs_define
class RaceDetailResponse:
    """Detailed view of a single race.

    Attributes:
        race (RacePublic): Public view of a race — extends RaceBase with public-facing fields.
        qualifiers (list[RaceQualifierPublic] | Unset): Qualifiers with scores
    """

    race: RacePublic
    qualifiers: list[RaceQualifierPublic] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        race = self.race.to_dict()

        qualifiers: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.qualifiers, Unset):
            qualifiers = []
            for qualifiers_item_data in self.qualifiers:
                qualifiers_item = qualifiers_item_data.to_dict()
                qualifiers.append(qualifiers_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "race": race,
            }
        )
        if qualifiers is not UNSET:
            field_dict["qualifiers"] = qualifiers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.race_public import RacePublic
        from ..models.race_qualifier_public import RaceQualifierPublic

        d = dict(src_dict)
        race = RacePublic.from_dict(d.pop("race"))

        _qualifiers = d.pop("qualifiers", UNSET)
        qualifiers: list[RaceQualifierPublic] | Unset = UNSET
        if _qualifiers is not UNSET:
            qualifiers = []
            for qualifiers_item_data in _qualifiers:
                qualifiers_item = RaceQualifierPublic.from_dict(qualifiers_item_data)

                qualifiers.append(qualifiers_item)

        race_detail_response = cls(
            race=race,
            qualifiers=qualifiers,
        )

        race_detail_response.additional_properties = d
        return race_detail_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
