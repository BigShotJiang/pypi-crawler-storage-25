"""
EscanApp - Aplicación de escaneo moderna para Windows
Con detección automática y recorte de fotografías (10x15 en folio A4)

Requiere: pip install Pillow pywin32 opencv-python numpy
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import os
from datetime import datetime
from pathlib import Path

try:
    from PIL import Image, ImageTk, ImageOps
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import cv2
    import numpy as np
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

# ── Paleta ─────────────────────────────────────────────────────────────────────
BG_DARK      = "#0f0f13"
BG_CARD      = "#1a1a22"
BG_SIDEBAR   = "#141418"
ACCENT       = "#6c63ff"
ACCENT_LIGHT = "#8b84ff"
ACCENT_DIM   = "#3d3880"
TEXT_WHITE   = "#f0eeff"
TEXT_GREY    = "#7a7a9a"
TEXT_DIM     = "#4a4a6a"
SUCCESS      = "#4ecca3"
WARNING      = "#ffcc44"
DANGER       = "#ff6b6b"

FONT_HEAD    = ("Segoe UI", 13, "bold")
FONT_BODY    = ("Segoe UI", 10)
FONT_SMALL   = ("Segoe UI", 9)
FONT_MONO    = ("Consolas", 9)
FONT_BIG_BTN = ("Segoe UI", 12, "bold")


# ══════════════════════════════════════════════════════════════════════════════
#  AUTO-RECORTE DE FOTOGRAFÍA
# ══════════════════════════════════════════════════════════════════════════════

def pil_to_cv2(pil_img):
    arr = np.array(pil_img.convert("RGB"))
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)

def cv2_to_pil(cv2_img):
    rgb = cv2.cvtColor(cv2_img, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb)

def order_points(pts):
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect

def four_point_transform(image, pts):
    rect = order_points(pts)
    (tl, tr, br, bl) = rect
    widthA  = np.linalg.norm(br - bl)
    widthB  = np.linalg.norm(tr - tl)
    maxW    = max(int(widthA), int(widthB))
    heightA = np.linalg.norm(tr - br)
    heightB = np.linalg.norm(tl - bl)
    maxH    = max(int(heightA), int(heightB))
    dst = np.array([[0,0],[maxW-1,0],[maxW-1,maxH-1],[0,maxH-1]],
                   dtype="float32")
    M = cv2.getPerspectiveTransform(rect, dst)
    return cv2.warpPerspective(image, M, (maxW, maxH))

def auto_crop_photo(pil_img, margin_px=0):
    """
    Detecta la fotografía dentro del folio y la devuelve recortada.
    Devuelve (imagen_pil, mensaje_str).
    """
    if not CV2_AVAILABLE:
        return pil_img, "OpenCV no disponible — recorte manual necesario"

    cv_img = pil_to_cv2(pil_img)
    h, w   = cv_img.shape[:2]

    # Pre-proceso
    gray  = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    blur  = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 0, 255,
                              cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15))
    closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    # Contornos
    cnts, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL,
                                cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return pil_img, "No se encontró ningún objeto — imagen original"

    total_area = h * w
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)
    best_cnt = None
    for cnt in cnts:
        area = cv2.contourArea(cnt)
        if area < total_area * 0.05:
            break
        if area > total_area * 0.92:
            continue
        best_cnt = cnt
        break

    if best_cnt is None:
        best_cnt = cnts[0]

    # Intentar cuadrilátero
    peri   = cv2.arcLength(best_cnt, True)
    approx = cv2.approxPolyDP(best_cnt, 0.02 * peri, True)

    if len(approx) == 4:
        pts     = approx.reshape(4, 2).astype("float32")
        cropped = four_point_transform(cv_img, pts)
        method  = "corrección de perspectiva"
    else:
        x, y, bw, bh = cv2.boundingRect(best_cnt)
        x1 = max(0, x - margin_px)
        y1 = max(0, y - margin_px)
        x2 = min(w, x + bw + margin_px)
        y2 = min(h, y + bh + margin_px)
        cropped = cv_img[y1:y2, x1:x2]
        method  = "bounding-box"

    result = cv2_to_pil(cropped)
    rw, rh = result.size
    return result, f"✓ Foto recortada automáticamente ({rw}×{rh}px) — {method}"


def auto_crop_two_photos(pil_img, margin_px=0):
    """
    Detecta las DOS fotografías dentro del folio y las devuelve recortadas.
    Devuelve (img1, img2, msg) — img2 puede ser None si solo hay una foto.
    """
    if not CV2_AVAILABLE:
        return pil_img, None, "OpenCV no disponible — recorte manual necesario"

    cv_img = pil_to_cv2(pil_img)
    h, w   = cv_img.shape[:2]
    total_area = h * w

    gray  = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    blur  = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 0, 255,
                              cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15))
    closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    cnts, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL,
                                cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return pil_img, None, "No se encontró ningún objeto — imagen original"

    # Filtrar contornos válidos (entre 4 % y 70 % del área total)
    valid = [c for c in cnts
             if total_area * 0.04 < cv2.contourArea(c) < total_area * 0.70]
    valid.sort(key=cv2.contourArea, reverse=True)

    def crop_one(cnt):
        peri   = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
        if len(approx) == 4:
            pts = approx.reshape(4, 2).astype("float32")
            return cv2_to_pil(four_point_transform(cv_img, pts))
        x, y, bw, bh = cv2.boundingRect(cnt)
        x1 = max(0, x - margin_px); y1 = max(0, y - margin_px)
        x2 = min(w, x + bw + margin_px); y2 = min(h, y + bh + margin_px)
        return cv2_to_pil(cv_img[y1:y2, x1:x2])

    img1 = crop_one(valid[0]) if len(valid) >= 1 else pil_img
    img2 = crop_one(valid[1]) if len(valid) >= 2 else None

    n = min(len(valid), 2)
    msg = f"✓ {n} foto{'s' if n>1 else ''} detectada{'s' if n>1 else ''} y recortada{'s' if n>1 else ''}"
    return img1, img2, msg


# ══════════════════════════════════════════════════════════════════════════════
#  WIA
# ══════════════════════════════════════════════════════════════════════════════

def get_wia_scanners():
    try:
        import win32com.client, pythoncom
        pythoncom.CoInitialize()
        try:
            wia = win32com.client.Dispatch("WIA.DeviceManager")
            devices = []
            for info in wia.DeviceInfos:
                if info.Type == 1:
                    devices.append((info.Properties("Name").Value, info.DeviceID))
            return devices
        finally:
            pythoncom.CoUninitialize()
    except Exception:
        return []

def scan_with_wia(device_id=None, dpi=300, color_mode="Color"):
    import win32com.client, tempfile, pythoncom
    pythoncom.CoInitialize()
    try:
        wia = win32com.client.Dispatch("WIA.DeviceManager")
        device_info = None
        for info in wia.DeviceInfos:
            if info.Type == 1:
                if device_id is None or info.DeviceID == device_id:
                    device_info = info
                    break
        if device_info is None:
            raise RuntimeError("No se encontró ningún escáner WIA conectado.")
        device = device_info.Connect()
        item   = device.Items(1)
        color_map = {"Color": 4, "Grayscale": 2, "BlackWhite": 1}
        def set_prop(it, pid, val):
            try: it.Properties(pid).Value = val
            except Exception: pass
        set_prop(item, 6147, dpi)
        set_prop(item, 6148, dpi)
        set_prop(item, 4103, color_map.get(color_mode, 4))
        img_file = item.Transfer("{B96B3CAB-0728-11D3-9D7B-0000F81EF32E}")
        tmp = tempfile.mktemp(suffix=".png")
        img_file.SaveFile(tmp)
        pil_img = Image.open(tmp).copy()
        os.remove(tmp)
        return pil_img
    finally:
        pythoncom.CoUninitialize()


# ══════════════════════════════════════════════════════════════════════════════
#  TOOLTIP
# ══════════════════════════════════════════════════════════════════════════════

class Tooltip:
    def __init__(self, widget, text):
        self.widget = widget; self.text = text; self.tip = None
        widget.bind("<Enter>", self.show); widget.bind("<Leave>", self.hide)
    def show(self, _=None):
        x = self.widget.winfo_rootx() + 30
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry(f"+{x}+{y}")
        tk.Label(self.tip, text=self.text, bg="#2a2a3a", fg=TEXT_WHITE,
                 font=FONT_SMALL, padx=8, pady=4, relief="flat").pack()
    def hide(self, _=None):
        if self.tip: self.tip.destroy(); self.tip = None


# ══════════════════════════════════════════════════════════════════════════════
#  APP
# ══════════════════════════════════════════════════════════════════════════════

class EscanApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("EscanApp")
        self.geometry("1350x760")
        self.minsize(1100, 620)
        self.configure(bg=BG_DARK)

        self.scanned_raw     = None
        # Foto 1
        self.photo1          = None
        self.tk_image_1      = None
        self.zoom_level_1    = 1.0
        # Foto 2
        self.photo2          = None
        self.tk_image_2      = None
        self.zoom_level_2    = 1.0

        self.scan_history    = []
        self.history_idx     = -1
        self.scanner_list    = []

        self.scan_var_dpi      = tk.IntVar(value=300)
        self.scan_var_color    = tk.StringVar(value="Color")
        self.scan_var_device   = tk.StringVar(value="")
        self.scan_var_autocrop = tk.BooleanVar(value=True)
        self.status_text       = tk.StringVar(value="Listo para escanear")

        if not PIL_AVAILABLE:
            messagebox.showerror("Error", "Instala Pillow:\npip install Pillow")
            self.destroy(); return

        self._build_ui()
        self._refresh_scanners()
        self._animate_dot()

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self._build_sidebar()
        self._build_main()
        self._build_statusbar()

    # ── Sidebar ───────────────────────────────────────────────────────────────
    def _build_sidebar(self):
        sb = tk.Frame(self, bg=BG_SIDEBAR, width=270)
        sb.grid(row=0, column=0, sticky="ns")
        sb.grid_propagate(False)
        sb.columnconfigure(0, weight=1)

        tk.Label(sb, text="⬡  EscanApp", font=("Segoe UI", 16, "bold"),
                 bg=BG_SIDEBAR, fg=ACCENT_LIGHT, pady=18
                 ).grid(row=0, column=0, sticky="ew", padx=20)
        self._sep(sb, 1)

        r = 2
        self._sec(sb, r, "ESCÁNER"); r += 1
        self.device_combo = ttk.Combobox(sb, textvariable=self.scan_var_device,
                                         state="readonly", font=FONT_SMALL)
        self.device_combo.grid(row=r, column=0, sticky="ew", padx=16, pady=(0,4))
        r += 1
        tk.Button(sb, text="↻  Actualizar lista", font=FONT_SMALL,
                  bg=BG_CARD, fg=TEXT_GREY,
                  activebackground=ACCENT_DIM, activeforeground=TEXT_WHITE,
                  relief="flat", bd=0, pady=6, cursor="hand2",
                  command=self._refresh_scanners
                  ).grid(row=r, column=0, sticky="ew", padx=16, pady=(0,10))
        r += 1
        self._sep(sb, r); r += 1

        # Resolución
        self._sec(sb, r, "RESOLUCIÓN (DPI)"); r += 1
        dpi_f = tk.Frame(sb, bg=BG_SIDEBAR)
        dpi_f.grid(row=r, column=0, sticky="ew", padx=16, pady=(0,10))
        dpi_f.columnconfigure((0,1,2), weight=1)
        for i, d in enumerate([150, 300, 600]):
            tk.Radiobutton(dpi_f, text=str(d), variable=self.scan_var_dpi,
                           value=d, bg=BG_SIDEBAR, fg=TEXT_WHITE,
                           selectcolor=ACCENT_DIM, activebackground=BG_SIDEBAR,
                           activeforeground=TEXT_WHITE, font=FONT_SMALL,
                           indicator=0, relief="flat", padx=6, pady=4,
                           highlightthickness=0, cursor="hand2"
                           ).grid(row=0, column=i, padx=2)
        r += 1

        # Modo color
        self._sec(sb, r, "MODO DE COLOR"); r += 1
        for mode, lbl in [("Color","🎨  Color"),
                           ("Grayscale","▣  Escala de grises"),
                           ("BlackWhite","◈  Blanco y negro")]:
            tk.Radiobutton(sb, text=lbl, variable=self.scan_var_color,
                           value=mode, bg=BG_SIDEBAR, fg=TEXT_WHITE,
                           selectcolor=ACCENT_DIM, activebackground=BG_SIDEBAR,
                           activeforeground=TEXT_WHITE, font=FONT_SMALL,
                           anchor="w", highlightthickness=0, cursor="hand2"
                           ).grid(row=r, column=0, sticky="ew", padx=20, pady=1)
            r += 1
        self._sep(sb, r); r += 1

        # ══ AUTO-RECORTE ══════════════════════════════════════════════════════
        # Cabecera con icono
        hdr = tk.Frame(sb, bg=BG_SIDEBAR)
        hdr.grid(row=r, column=0, sticky="ew", padx=16, pady=(6,4))
        hdr.columnconfigure(0, weight=1)
        tk.Label(hdr, text="✂  AUTO-RECORTE DE FOTO",
                 font=("Segoe UI", 8, "bold"),
                 bg=BG_SIDEBAR, fg=ACCENT_LIGHT, anchor="w"
                 ).grid(row=0, column=0, sticky="w")
        r += 1

        # Tarjeta
        card = tk.Frame(sb, bg=BG_CARD)
        card.grid(row=r, column=0, sticky="ew", padx=16, pady=(0,8))
        card.columnconfigure(0, weight=1)
        r += 1

        toggle_row = tk.Frame(card, bg=BG_CARD, pady=8)
        toggle_row.grid(row=0, column=0, sticky="ew", padx=10)
        toggle_row.columnconfigure(0, weight=1)
        tk.Label(toggle_row, text="Recorte automático al escanear",
                 font=FONT_SMALL, bg=BG_CARD, fg=TEXT_WHITE, anchor="w"
                 ).grid(row=0, column=0, sticky="w")
        tk.Checkbutton(toggle_row, variable=self.scan_var_autocrop,
                       bg=BG_CARD, fg=ACCENT_LIGHT,
                       selectcolor=ACCENT_DIM, activebackground=BG_CARD,
                       cursor="hand2", onvalue=True, offvalue=False,
                       command=self._on_crop_toggle
                       ).grid(row=0, column=1, padx=4)

        tk.Label(card,
                 text="Detecta la foto en el folio escaneado,\n"
                      "corrige la perspectiva y la recorta\n"
                      "automáticamente. Sin tocar nada.",
                 font=("Segoe UI", 8), bg=BG_CARD, fg=TEXT_GREY,
                 justify="left", padx=10, pady=6
                 ).grid(row=1, column=0, sticky="w", pady=(0,8))

        # Botones recorte manual / restaurar
        self.crop_now_btn = tk.Button(sb,
            text="✂  Recortar ahora",
            font=FONT_SMALL, bg=ACCENT_DIM, fg=TEXT_WHITE,
            activebackground=ACCENT, activeforeground=TEXT_WHITE,
            relief="flat", bd=0, pady=7, cursor="hand2",
            command=self._manual_crop, state="disabled")
        self.crop_now_btn.grid(row=r, column=0, sticky="ew",
                                padx=16, pady=(0,4))
        r += 1

        self.restore_btn = tk.Button(sb,
            text="↩  Restaurar original",
            font=FONT_SMALL, bg=BG_CARD, fg=TEXT_GREY,
            activebackground="#2a2a36", activeforeground=TEXT_WHITE,
            relief="flat", bd=0, pady=7, cursor="hand2",
            command=self._restore_original, state="disabled")
        self.restore_btn.grid(row=r, column=0, sticky="ew",
                               padx=16, pady=(0,10))
        r += 1
        self._sep(sb, r); r += 1

        # ESCANEAR
        tk.Button(sb, text="▶  ESCANEAR", font=FONT_BIG_BTN,
                  bg=ACCENT, fg=TEXT_WHITE,
                  activebackground=ACCENT_LIGHT, activeforeground=TEXT_WHITE,
                  relief="flat", bd=0, pady=14, cursor="hand2",
                  command=self._start_scan
                  ).grid(row=r, column=0, sticky="ew", padx=16, pady=(0,6))
        r += 1

        sb.rowconfigure(r, weight=1); r += 1

        # Historial
        self._sec(sb, r, "HISTORIAL"); r += 1
        hf = tk.Frame(sb, bg=BG_SIDEBAR)
        hf.grid(row=r, column=0, sticky="ew", padx=16, pady=(0,16))
        hf.columnconfigure((0,1), weight=1)
        for col, (lbl, cmd) in enumerate([
                ("← Anterior", self._history_prev),
                ("Siguiente →", self._history_next)]):
            tk.Button(hf, text=lbl, font=FONT_SMALL,
                      bg=BG_CARD, fg=TEXT_GREY,
                      activebackground="#2a2a36", activeforeground=TEXT_WHITE,
                      relief="flat", bd=0, pady=6, cursor="hand2",
                      command=cmd).grid(
                          row=0, column=col,
                          padx=(0,3) if col==0 else (3,0), sticky="ew")

    def _sep(self, p, r):
        tk.Frame(p, bg=TEXT_DIM, height=1).grid(
            row=r, column=0, sticky="ew", padx=16, pady=(0,10))

    def _sec(self, p, r, text):
        tk.Label(p, text=text, font=("Segoe UI", 8, "bold"),
                 bg=BG_SIDEBAR, fg=TEXT_DIM
                 ).grid(row=r, column=0, sticky="w", padx=20, pady=(6,3))

    # ── Panel central (dos columnas) ──────────────────────────────────────────
    def _build_main(self):
        main = tk.Frame(self, bg=BG_DARK)
        main.grid(row=0, column=1, sticky="nsew")
        main.columnconfigure(0, weight=1)
        main.columnconfigure(1, weight=1)
        main.rowconfigure(1, weight=1)

        # ── Toolbar compartida ────────────────────────────────────────────────
        tb = tk.Frame(main, bg=BG_CARD, pady=8)
        tb.grid(row=0, column=0, columnspan=2, sticky="ew")

        def tb_btn(text, cmd, tip=None):
            b = tk.Button(tb, text=text, font=("Segoe UI", 12),
                          bg=BG_CARD, fg=TEXT_GREY,
                          activebackground=ACCENT_DIM, activeforeground=TEXT_WHITE,
                          relief="flat", bd=0, padx=10, cursor="hand2", command=cmd)
            b.pack(side="left", padx=1)
            if tip: Tooltip(b, tip)
            return b

        tk.Label(tb, text="Zoom:", font=FONT_SMALL,
                 bg=BG_CARD, fg=TEXT_GREY).pack(side="left", padx=(16,4))
        tb_btn("−", self._zoom_out)
        self.zoom_label = tk.Label(tb, text="100%", font=FONT_MONO,
                                   bg=BG_CARD, fg=ACCENT_LIGHT, width=5)
        self.zoom_label.pack(side="left")
        tb_btn("+", self._zoom_in)
        tb_btn("⊡ Ajustar", self._zoom_fit)
        tk.Frame(tb, bg=TEXT_DIM, width=1).pack(side="left", fill="y", padx=12, pady=4)
        tb_btn("↺", lambda: self._rotate(-90), "Rotar izquierda 90°")
        tb_btn("↻", lambda: self._rotate(90),  "Rotar derecha 90°")

        # ── Panel FOTO 1 ──────────────────────────────────────────────────────
        p1 = tk.Frame(main, bg=BG_DARK)
        p1.grid(row=1, column=0, sticky="nsew", padx=(16,8), pady=(12,4))
        p1.columnconfigure(0, weight=1)
        p1.rowconfigure(1, weight=1)

        hdr1 = tk.Frame(p1, bg=BG_CARD, pady=4)
        hdr1.grid(row=0, column=0, columnspan=2, sticky="ew")
        hdr1.columnconfigure(0, weight=1)
        tk.Label(hdr1, text="📷  FOTO 1", font=("Segoe UI", 9, "bold"),
                 bg=BG_CARD, fg=ACCENT_LIGHT, anchor="w", padx=10
                 ).grid(row=0, column=0, sticky="w")
        self.info_label_1 = tk.Label(hdr1, text="Sin imagen", font=FONT_SMALL,
                                     bg=BG_CARD, fg=TEXT_DIM, anchor="e", padx=10)
        self.info_label_1.grid(row=0, column=1, sticky="e")

        self.canvas1 = tk.Canvas(p1, bg="#12121a",
                                 highlightthickness=0, cursor="crosshair")
        self.canvas1.grid(row=1, column=0, sticky="nsew")
        vb1 = ttk.Scrollbar(p1, orient="vertical",   command=self.canvas1.yview)
        vb1.grid(row=1, column=1, sticky="ns")
        hb1 = ttk.Scrollbar(p1, orient="horizontal", command=self.canvas1.xview)
        hb1.grid(row=2, column=0, sticky="ew")
        self.canvas1.configure(yscrollcommand=vb1.set, xscrollcommand=hb1.set)
        self.canvas1.bind("<Configure>", lambda e: self._on_resize(1))

        self.save_btn_1 = tk.Button(p1, text="💾  Guardar Foto 1",
            font=FONT_BODY, bg=BG_CARD, fg=TEXT_WHITE,
            activebackground="#2a2a36", activeforeground=TEXT_WHITE,
            relief="flat", bd=0, pady=8, cursor="hand2",
            command=lambda: self._save_image(1), state="disabled")
        self.save_btn_1.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(6,0))

        # ── Separador vertical ────────────────────────────────────────────────
        tk.Frame(main, bg=TEXT_DIM, width=1).grid(
            row=1, column=0, sticky="ns", padx=(0,0))

        # ── Panel FOTO 2 ──────────────────────────────────────────────────────
        p2 = tk.Frame(main, bg=BG_DARK)
        p2.grid(row=1, column=1, sticky="nsew", padx=(8,16), pady=(12,4))
        p2.columnconfigure(0, weight=1)
        p2.rowconfigure(1, weight=1)

        hdr2 = tk.Frame(p2, bg=BG_CARD, pady=4)
        hdr2.grid(row=0, column=0, columnspan=2, sticky="ew")
        hdr2.columnconfigure(0, weight=1)
        tk.Label(hdr2, text="📷  FOTO 2", font=("Segoe UI", 9, "bold"),
                 bg=BG_CARD, fg=ACCENT_LIGHT, anchor="w", padx=10
                 ).grid(row=0, column=0, sticky="w")
        self.info_label_2 = tk.Label(hdr2, text="Sin imagen", font=FONT_SMALL,
                                     bg=BG_CARD, fg=TEXT_DIM, anchor="e", padx=10)
        self.info_label_2.grid(row=0, column=1, sticky="e")

        self.canvas2 = tk.Canvas(p2, bg="#12121a",
                                 highlightthickness=0, cursor="crosshair")
        self.canvas2.grid(row=1, column=0, sticky="nsew")
        vb2 = ttk.Scrollbar(p2, orient="vertical",   command=self.canvas2.yview)
        vb2.grid(row=1, column=1, sticky="ns")
        hb2 = ttk.Scrollbar(p2, orient="horizontal", command=self.canvas2.xview)
        hb2.grid(row=2, column=0, sticky="ew")
        self.canvas2.configure(yscrollcommand=vb2.set, xscrollcommand=hb2.set)
        self.canvas2.bind("<Configure>", lambda e: self._on_resize(2))

        self.save_btn_2 = tk.Button(p2, text="💾  Guardar Foto 2",
            font=FONT_BODY, bg=BG_CARD, fg=TEXT_WHITE,
            activebackground="#2a2a36", activeforeground=TEXT_WHITE,
            relief="flat", bd=0, pady=8, cursor="hand2",
            command=lambda: self._save_image(2), state="disabled")
        self.save_btn_2.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(6,0))

        self._draw_placeholder(1)
        self._draw_placeholder(2)

    def _build_statusbar(self):
        bar = tk.Frame(self, bg=BG_SIDEBAR, pady=5)
        bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        bar.columnconfigure(1, weight=1)
        self.dot_lbl = tk.Label(bar, text="●", font=FONT_SMALL,
                                bg=BG_SIDEBAR, fg=SUCCESS)
        self.dot_lbl.grid(row=0, column=0, padx=(16,4))
        tk.Label(bar, textvariable=self.status_text, font=FONT_SMALL,
                 bg=BG_SIDEBAR, fg=TEXT_GREY, anchor="w"
                 ).grid(row=0, column=1, sticky="ew")
        self.progress = ttk.Progressbar(bar, mode="indeterminate", length=120)
        self.progress.grid(row=0, column=2, padx=16)

    # ── Escaneo ───────────────────────────────────────────────────────────────
    def _refresh_scanners(self):
        self.scanner_list = get_wia_scanners()
        names = [n for n, _ in self.scanner_list]
        self.device_combo["values"] = names or ["(ningún escáner detectado)"]
        if names:
            self.scan_var_device.set(names[0])
            self.status_text.set(f"Escáner encontrado: {names[0]}")
        else:
            self.scan_var_device.set("(ningún escáner detectado)")
            self.status_text.set("No se detectó ningún escáner WIA")

    def _start_scan(self):
        if not self.scanner_list:
            messagebox.showwarning("Sin escáner",
                "Comprueba que el escáner está encendido y pulsa 'Actualizar lista'.")
            return
        self.status_text.set("Escaneando…")
        self.progress.start(10)
        threading.Thread(target=self._do_scan, daemon=True).start()

    def _do_scan(self):
        try:
            sel = self.scan_var_device.get()
            did = next((d for n, d in self.scanner_list if n == sel), None)
            img = scan_with_wia(device_id=did,
                                dpi=self.scan_var_dpi.get(),
                                color_mode=self.scan_var_color.get())
            self.after(0, self._scan_done, img)
        except Exception as e:
            self.after(0, self._scan_error, str(e))

    def _scan_done(self, img):
        self.progress.stop()
        self.scanned_raw = img
        ts   = datetime.now().strftime("%H:%M:%S")
        dpi  = self.scan_var_dpi.get()
        mode = self.scan_var_color.get()

        if self.scan_var_autocrop.get():
            self.status_text.set("Detectando y recortando fotos…")
            img1, img2, msg = auto_crop_two_photos(img)
        else:
            img1, img2, msg = img, None, "✓ Escaneo completado"

        self.photo1 = img1
        self.photo2 = img2

        # Info panel 1
        w1, h1 = img1.size
        self.info_label_1.config(
            text=f"{w1}×{h1}px  ·  {dpi} DPI  ·  {ts}", fg=ACCENT_LIGHT)
        self.save_btn_1.config(state="normal")
        self.zoom_level_1 = 1.0
        self._zoom_fit(1)

        # Info panel 2
        if img2:
            w2, h2 = img2.size
            self.info_label_2.config(
                text=f"{w2}×{h2}px  ·  {dpi} DPI  ·  {ts}", fg=ACCENT_LIGHT)
            self.save_btn_2.config(state="normal")
            self.zoom_level_2 = 1.0
            self._zoom_fit(2)
        else:
            self.info_label_2.config(text="No detectada", fg=WARNING)
            self._draw_placeholder(2)

        self.scan_history.append((img1, img2))
        self.history_idx = len(self.scan_history) - 1
        self.status_text.set(msg)
        self.crop_now_btn.config(state="normal")
        self.restore_btn.config(state="normal")

    def _scan_error(self, msg):
        self.progress.stop()
        self.status_text.set("Error al escanear")
        messagebox.showerror("Error de escaneo",
            f"No se pudo completar el escaneo:\n\n{msg}\n\n"
            "Comprueba que el escáner está listo.")

    # ── Recorte ───────────────────────────────────────────────────────────────
    def _on_crop_toggle(self):
        if not CV2_AVAILABLE and self.scan_var_autocrop.get():
            messagebox.showwarning("OpenCV no instalado",
                "Para el auto-recorte instala:\n\npip install opencv-python numpy\n\n"
                "El recorte se ha desactivado.")
            self.scan_var_autocrop.set(False)

    def _manual_crop(self):
        if not self.scanned_raw: return
        if not CV2_AVAILABLE:
            messagebox.showwarning("OpenCV no instalado",
                "pip install opencv-python numpy")
            return
        self.status_text.set("Recortando…")
        def _do():
            img1, img2, msg = auto_crop_two_photos(self.scanned_raw)
            self.after(0, self._crop_done, img1, img2, msg)
        threading.Thread(target=_do, daemon=True).start()

    def _crop_done(self, img1, img2, msg):
        self.photo1 = img1
        self.photo2 = img2
        w1, h1 = img1.size
        self.info_label_1.config(text=f"{w1}×{h1}px (recortada)", fg=SUCCESS)
        self.zoom_level_1 = 1.0
        self._zoom_fit(1)
        if img2:
            w2, h2 = img2.size
            self.info_label_2.config(text=f"{w2}×{h2}px (recortada)", fg=SUCCESS)
            self.save_btn_2.config(state="normal")
            self.zoom_level_2 = 1.0
            self._zoom_fit(2)
        else:
            self.info_label_2.config(text="No detectada", fg=WARNING)
            self._draw_placeholder(2)
        self.status_text.set(msg)

    def _restore_original(self):
        if not self.scanned_raw: return
        raw = self.scanned_raw
        self.photo1 = raw
        self.photo2 = None
        w, h = raw.size
        self.info_label_1.config(text=f"{w}×{h}px (original)", fg=WARNING)
        self.info_label_2.config(text="Sin imagen", fg=TEXT_DIM)
        self.save_btn_2.config(state="disabled")
        self.zoom_level_1 = 1.0
        self._zoom_fit(1)
        self._draw_placeholder(2)
        self.status_text.set("Imagen original restaurada")

    # ── Canvas ────────────────────────────────────────────────────────────────
    def _canvas(self, n):
        return self.canvas1 if n == 1 else self.canvas2

    def _photo(self, n):
        return self.photo1 if n == 1 else self.photo2

    def _draw_placeholder(self, n=1):
        cv = self._canvas(n)
        cv.delete("all")
        w  = cv.winfo_width()  or 500
        h  = cv.winfo_height() or 380
        cx, cy = w//2, h//2
        for x in range(0, w, 30):
            for y in range(0, h, 30):
                cv.create_oval(x-1, y-1, x+1, y+1, fill="#1e1e2e", outline="")
        cv.create_text(cx, cy-30, text="⬡",
                       font=("Segoe UI", 48), fill=ACCENT_DIM)
        cv.create_text(cx, cy+22,
                       text=f"Foto {n} aparecerá aquí ✂",
                       font=("Segoe UI", 11), fill=TEXT_DIM)

    def _on_resize(self, n):
        if self._photo(n):
            self._show_image(n)
        else:
            self._draw_placeholder(n)

    def _show_image(self, n):
        img = self._photo(n)
        if not img: return
        cv  = self._canvas(n)
        zl  = self.zoom_level_1 if n == 1 else self.zoom_level_2
        ow, oh = img.size
        nw = max(1, int(ow * zl))
        nh = max(1, int(oh * zl))
        resized = img.resize((nw, nh), Image.LANCZOS)
        tk_img  = ImageTk.PhotoImage(resized)
        # Keep reference alive
        if n == 1: self.tk_image_1 = tk_img
        else:      self.tk_image_2 = tk_img
        cv.delete("all")
        cv.config(scrollregion=(0, 0, nw, nh))
        cw = cv.winfo_width();  ch = cv.winfo_height()
        x  = max(nw//2, cw//2);  y  = max(nh//2, ch//2)
        cv.create_image(x, y, image=tk_img, anchor="center")
        self.zoom_label.config(text=f"{int(zl*100)}%")

    def _zoom_fit(self, n=None):
        targets = [1, 2] if n is None else [n]
        self.update_idletasks()
        for i in targets:
            img = self._photo(i)
            if not img: continue
            cv  = self._canvas(i)
            cw  = cv.winfo_width();  ch = cv.winfo_height()
            iw, ih = img.size
            if iw and ih:
                zl = min((cw-20)/iw, (ch-20)/ih, 1.0)
                if i == 1: self.zoom_level_1 = zl
                else:      self.zoom_level_2 = zl
                self._show_image(i)

    def _zoom_in(self):
        if self.photo1:
            self.zoom_level_1 = min(self.zoom_level_1 * 1.25, 8.0)
            self._show_image(1)
        if self.photo2:
            self.zoom_level_2 = min(self.zoom_level_2 * 1.25, 8.0)
            self._show_image(2)

    def _zoom_out(self):
        if self.photo1:
            self.zoom_level_1 = max(self.zoom_level_1 / 1.25, 0.05)
            self._show_image(1)
        if self.photo2:
            self.zoom_level_2 = max(self.zoom_level_2 / 1.25, 0.05)
            self._show_image(2)

    def _rotate(self, deg):
        if self.photo1:
            self.photo1 = self.photo1.rotate(-deg, expand=True)
            self._show_image(1)
        if self.photo2:
            self.photo2 = self.photo2.rotate(-deg, expand=True)
            self._show_image(2)

    # ── Historial ─────────────────────────────────────────────────────────────
    def _history_prev(self):
        if self.history_idx > 0:
            self.history_idx -= 1; self._load_history()

    def _history_next(self):
        if self.history_idx < len(self.scan_history)-1:
            self.history_idx += 1; self._load_history()

    def _load_history(self):
        img1, img2 = self.scan_history[self.history_idx]
        self.photo1 = img1; self.photo2 = img2
        self._zoom_fit(1)
        if img2: self._zoom_fit(2)
        else: self._draw_placeholder(2)
        self.status_text.set(
            f"Historial {self.history_idx+1}/{len(self.scan_history)}")

    # ── Guardar ───────────────────────────────────────────────────────────────
    def _save_image(self, n):
        img = self.photo1 if n == 1 else self.photo2
        if not img:
            messagebox.showinfo("Sin imagen", f"Primero escanea para obtener la Foto {n}.")
            return
        ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(
            defaultextension=".jpg",
            filetypes=[("JPEG","*.jpg"),("PNG","*.png"),
                       ("PDF","*.pdf"),("TIFF","*.tiff")],
            initialfile=f"foto{n}_{ts}", title=f"Guardar Foto {n}")
        if not path: return
        ext = Path(path).suffix.lower()
        if ext in (".jpg",".jpeg"):
            img.convert("RGB").save(path, "JPEG", quality=96)
        elif ext == ".pdf":
            img.convert("RGB").save(path, "PDF",
                                    resolution=self.scan_var_dpi.get())
        elif ext == ".tiff":
            img.save(path, "TIFF")
        else:
            img.save(path, "PNG")
        self.status_text.set(f"✓ Foto {n} guardada: {Path(path).name}")
        messagebox.showinfo("Guardado", f"Foto {n} guardada en:\n{path}")

    # ── Dot ───────────────────────────────────────────────────────────────────
    def _animate_dot(self):
        colors = [SUCCESS, ACCENT_LIGHT, TEXT_DIM]
        c = getattr(self, "_dot_c", 0)
        st = self.status_text.get()
        if "Listo" in st or "✓" in st:
            self.dot_lbl.config(fg=colors[c % len(colors)])
            self._dot_c = c + 1
        self.after(900, self._animate_dot)


# ══════════════════════════════════════════════════════════════════════════════
def main():
    app = EscanApp()
    app.mainloop()

if __name__ == "__main__":
    main()
