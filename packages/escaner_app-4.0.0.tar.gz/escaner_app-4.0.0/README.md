<div align="center">
  <img src="logo.png" alt="EscanApp Logo" width="120"/>

  # EscanApp

  **Aplicación de escaneo inteligente de fotos para Windows**

  Escanea entre 1 y 2 fotos a la vez, con auto-recorte automático y directamente desde tu escáner.

  ![Python](https://img.shields.io/badge/Python-3.9%2B-blue?logo=python&logoColor=white)
  ![Windows](https://img.shields.io/badge/Windows-10%2F11-0078D6?logo=windows&logoColor=white)
  ![PyPI](https://img.shields.io/badge/PyPI-escaner--app-orange?logo=pypi&logoColor=white)
  ![Licencia](https://img.shields.io/badge/Licencia-MIT-green)

</div>

---

## Contenido

- [¿Qué hace esta app?](#qué-hace-esta-app)
- [Instalación rápida (sin Python)](#instalación-rápida-sin-python)
- [Instalación con pip](#instalación-con-pip-si-ya-tienes-python)
- [Primer uso](#primer-uso)
- [Funcionalidades](#funcionalidades)
- [Requisitos del sistema](#requisitos-del-sistema)
- [Solución de problemas](#solución-de-problemas)

---

## ¿Qué hace esta app?

EscanApp se conecta a tu escáner a través del sistema WIA de Windows (el mismo que usa la aplicación de escáner de Windows o el driver de tu impresora) y añade encima:

- **Auto-recorte** — detecta cada foto sobre el cristal y la recorta sola
- **Mejora de imagen** — balance de blancos, contraste automático y nitidez equivalente al driver profesional
- **Multi-foto** — escanea hasta 5 fotos en un solo pasado
- **Guardado de calidad** — JPEG a 98 de calidad con metadatos DPI correctos, PNG, TIFF y PDF

---

## Instalación rápida (sin Python)

> Sigue estos pasos si **no tienes Python instalado** en tu ordenador.

### Paso 1 — Instala Python

1. Ve a [python.org/downloads](https://www.python.org/downloads/)
2. Descarga la última versión de **Python 3** (botón amarillo grande)
3. Ejecuta el instalador
4. **MUY IMPORTANTE:** marca la casilla **"Add Python to PATH"** antes de pulsar Install

   ```
   ☑ Add Python to PATH      ← Esta casilla, imprescindible
   ```

5. Pulsa **"Install Now"** y espera a que termine

### Paso 2 — Instala EscanApp

Abre el **Símbolo del sistema** (CMD):
- Pulsa `Win + R`, escribe `cmd` y pulsa Enter

Ejecuta este comando:

```cmd
pip install escaner-app
```

Espera a que termine (descargará e instalará todo automáticamente).

### Paso 3 — Ejecuta la aplicación

En la misma ventana de CMD escribe:

```cmd
escaner
```

Se abrirá la ventana de EscanApp. ¡Listo!

> **Nota:** a partir de ahora solo necesitas escribir `escaner` en CMD para abrir la app. No hace falta repetir los pasos anteriores.

---

## Instalación con pip (si ya tienes Python)

Si ya tienes Python 3.9 o superior instalado:

```cmd
pip install escaner-app
```

Para ejecutar:

```cmd
escaner
```

Para actualizar a la última versión:

```cmd
pip install --upgrade escaner-app
```

Para desinstalar:

```cmd
pip uninstall escaner-app
```

---

## Primer uso

1. **Conecta tu escáner** al ordenador y enciéndelo
2. Abre la app escribiendo `escaner` en CMD
3. En la barra lateral izquierda, pulsa **"Actualizar lista"** — debería aparecer tu escáner
4. Coloca tus fotos boca abajo sobre el cristal
5. Indica cuántas fotos has puesto (botones 1–5)
6. Elige la resolución: **300 DPI** para fotos normales, **600 DPI** para máxima calidad
7. Pulsa **ESCANEAR**
8. La app detectará cada foto, la recortará
9. Pulsa **"Guardar Foto"** en cada panel para guardar en tu ordenador

---

## Funcionalidades

| Función | Descripción |
|---|---|
| Multi-foto | Hasta 5 fotos por escaneo en un solo pasado |
| Auto-recorte | Detecta los bordes de cada foto y elimina el fondo blanco |
| Zoom y rotación | Visualiza y rota las fotos antes de guardar |
| Historial | Navega entre escaneos anteriores de la sesión |
| Formatos de guardado | JPEG (calidad 98), PNG, TIFF (LZW), PDF |
| Metadatos DPI | Los archivos guardados incluyen la resolución correcta |

---

## Requisitos del sistema

| Requisito | Mínimo |
|---|---|
| Sistema operativo | Windows 10 / Windows 11 |
| Python | 3.9 o superior |
| Escáner | Cualquiera compatible con WIA (la mayoría de HP, Canon, Epson, Brother...) |
| RAM | 4 GB recomendado |

Las dependencias se instalan automáticamente con pip:

- `Pillow` — procesamiento de imagen
- `pywin32` — comunicación con WIA de Windows
- `opencv-python` — detección y recorte de fotos
- `numpy` — cálculos de imagen

---

## Solución de problemas

**"No se detectó ningún escáner WIA"**
- Comprueba que el escáner está encendido y conectado por USB o red
- Abre la app de Escáner de Windows para verificar que Windows lo reconoce
- Pulsa "Actualizar lista" en EscanApp

**"pip no se reconoce como comando"**
- Python no se añadió al PATH durante la instalación
- Desinstala Python y vuelve a instalarlo marcando la casilla **"Add Python to PATH"**

**"escaner no se reconoce como comando"**
- Cierra CMD y ábrelo de nuevo tras instalar
- Si sigue sin funcionar: `python -m escaner`

**La foto sale borrosa o con mal color**
- Activa las opciones de mejora en la barra lateral: Balance de blancos, Contraste automático y Nitidez
- Sube la resolución a 300 o 600 DPI

**El recorte no detecta bien las fotos**
- Asegúrate de que las fotos no se tocan entre sí sobre el cristal
- Indica el número correcto de fotos en los botones 1–5
- Usa el botón "Recortar ahora" para reintentar el recorte

---

## Licencia y Reconocimientos

MIT License — Copyright (c) 2025 Hector Cubel Garcia-Moreno

Puedes usar, modificar y distribuir libremente este software.
Ver el archivo [LICENSE](LICENSE) para el texto completo.

---

### Desarrollo Asistido por IA
Este proyecto ha sido desarrollado de forma independiente por el autor humano, contando con la asistencia y soporte técnico de **Claude** (modelo de lenguaje desarrollado por **Anthropic**). 

De acuerdo con los términos de servicio de Anthropic, todos los derechos, títulos e intereses sobre el código generado pertenecen exclusivamente al autor. Se incluye esta mención como transparencia y reconocimiento al proceso de desarrollo asistido.


---

<div align="center">
  Hecho con Python y Tkinter · Compatible con Windows 10/11
</div>
