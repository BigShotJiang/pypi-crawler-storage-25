"""
Prompt handling utility for VEXIS AI Agent
Provides consistent prompt handling with --no-prompt support
"""

from typing import Optional


class PromptHandler:
    """Handles user prompts with support for non-interactive mode"""
    
    def __init__(self, no_prompt: bool = False):
        self.no_prompt = no_prompt
    
    def input(self, prompt: str, default: str = "") -> str:
        """
        Get user input or return default if no_prompt is enabled
        
        Args:
            prompt: The prompt message to display
            default: Default value to return when no_prompt is True
            
        Returns:
            User input string or default value
        """
        if self.no_prompt:
            return default
        
        try:
            return input(prompt)
        except (EOFError, KeyboardInterrupt):
            return default
    
    def confirm(self, prompt: str, default: bool = False) -> bool:
        """
        Ask for confirmation or return default if no_prompt is enabled
        
        Args:
            prompt: The confirmation prompt message
            default: Default value to return when no_prompt is True
            
        Returns:
            True if confirmed, False otherwise
        """
        if self.no_prompt:
            return default
        
        suffix = " [Y/n]: " if default else " [y/N]: "
        try:
            response = input(f"{prompt}{suffix}").strip().lower()
            if not response:
                return default
            return response in ('y', 'yes', 'true', '1')
        except (EOFError, KeyboardInterrupt):
            return default
    
    def select(self, prompt: str, options: list, default_index: int = 0) -> Optional[int]:
        """
        Ask user to select from options or return default if no_prompt is enabled
        
        Args:
            prompt: The selection prompt message
            options: List of option strings
            default_index: Default option index when no_prompt is True
            
        Returns:
            Selected index or None if cancelled
        """
        if self.no_prompt:
            return default_index if 0 <= default_index < len(options) else None
        
        print(f"\n{prompt}")
        for i, option in enumerate(options, 1):
            print(f"  {i}. {option}")
        
        try:
            response = input("Select option (number): ").strip()
            if not response:
                return default_index if 0 <= default_index < len(options) else None
            
            selected = int(response) - 1
            if 0 <= selected < len(options):
                return selected
            else:
                print("Invalid selection, using default")
                return default_index if 0 <= default_index < len(options) else None
        except ValueError:
            print("Invalid input, using default")
            return default_index if 0 <= default_index < len(options) else None
        except (EOFError, KeyboardInterrupt):
            return None


# Global prompt handler instance
_prompt_handler: Optional[PromptHandler] = None


def set_prompt_handler(no_prompt: bool = False) -> PromptHandler:
    """Set up the global prompt handler"""
    global _prompt_handler
    _prompt_handler = PromptHandler(no_prompt=no_prompt)
    return _prompt_handler


def get_prompt_handler() -> PromptHandler:
    """Get the global prompt handler (creates default if not set)"""
    global _prompt_handler
    if _prompt_handler is None:
        _prompt_handler = PromptHandler(no_prompt=False)
    return _prompt_handler


def user_input(prompt: str, default: str = "") -> str:
    """Convenience function for user input"""
    return get_prompt_handler().input(prompt, default)


def user_confirm(prompt: str, default: bool = False) -> bool:
    """Convenience function for user confirmation"""
    return get_prompt_handler().confirm(prompt, default)


def user_select(prompt: str, options: list, default_index: int = 0) -> Optional[int]:
    """Convenience function for user selection"""
    return get_prompt_handler().select(prompt, options, default_index)
