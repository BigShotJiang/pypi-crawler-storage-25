# -*- coding: utf-8 -*-
"""Hypothesis Superposition - Quantum-inspired reasoning with delayed collapse.

Inspired by Penrose's Orch-OR theory:
- Quantum superposition: multiple states coexist until observed
- Objective collapse: external signal triggers state selection
- Non-algorithmic: the collapse is not deterministic

Engineering approximation:
- Multiple hypotheses maintained simultaneously
- Each hypothesis has amplitude (confidence) and phase (context)
- Collapse triggered by external signals (user, verification, timeout)
- Amplitude = confidence * verification_rate * freshness_decay
"""

from __future__ import annotations

import json
import logging
import math
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_SUPERPOSITION_DIR = Path.home() / ".xingzierai" / "hypothesis"


class HypothesisState(str, Enum):
    SUPERPOSED = "superposed"
    COLLAPSING = "collapsing"
    COLLAPSED = "collapsed"
    ABANDONED = "abandoned"


class CollapseTrigger(str, Enum):
    USER_CONFIRMATION = "user_confirmation"
    VERIFICATION_RESULT = "verification_result"
    TIME_BUDGET = "time_budget"
    CONFIDENCE_THRESHOLD = "confidence_threshold"
    MANUAL = "manual"


@dataclass
class Hypothesis:
    hypothesis_id: str
    content: str
    amplitude: float = 0.5
    phase: float = 0.0
    confidence: float = 0.5
    verification_rate: float = 0.0
    verification_count: int = 0
    created_at: float = field(default_factory=time.time)
    state: HypothesisState = HypothesisState.SUPERPOSED
    source: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def effective_amplitude(self) -> float:
        age = time.time() - self.created_at
        freshness = math.exp(-0.01 * age)
        return self.amplitude * max(self.verification_rate, 0.1) * freshness

    def to_dict(self) -> Dict[str, Any]:
        return {
            "hypothesis_id": self.hypothesis_id,
            "content": self.content[:200],
            "amplitude": round(self.amplitude, 4),
            "effective_amplitude": round(self.effective_amplitude, 4),
            "confidence": round(self.confidence, 4),
            "verification_rate": round(self.verification_rate, 4),
            "verification_count": self.verification_count,
            "state": self.state.value,
            "source": self.source,
        }


@dataclass
class SuperpositionState:
    question: str
    hypotheses: List[Hypothesis] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    collapsed_at: Optional[float] = None
    collapsed_hypothesis_id: Optional[str] = None
    collapse_trigger: Optional[CollapseTrigger] = None
    coherence: float = 1.0
    max_superposition_time: float = 30.0

    @property
    def is_collapsed(self) -> bool:
        return self.collapsed_hypothesis_id is not None

    @property
    def age(self) -> float:
        return time.time() - self.created_at

    @property
    def should_auto_collapse(self) -> bool:
        return self.age >= self.max_superposition_time

    def to_dict(self) -> Dict[str, Any]:
        return {
            "question": self.question[:200],
            "hypotheses": [h.to_dict() for h in self.hypotheses],
            "created_at": self.created_at,
            "collapsed_at": self.collapsed_at,
            "collapsed_hypothesis_id": self.collapsed_hypothesis_id,
            "coherence": round(self.coherence, 4),
            "age": round(self.age, 2),
            "is_collapsed": self.is_collapsed,
        }


@dataclass
class SuperpositionStats:
    total_superpositions: int = 0
    total_hypotheses: int = 0
    collapsed: int = 0
    auto_collapsed: int = 0
    avg_hypotheses_per_question: float = 0.0
    avg_collapse_time_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_superpositions": self.total_superpositions,
            "total_hypotheses": self.total_hypotheses,
            "collapsed": self.collapsed,
            "auto_collapsed": self.auto_collapsed,
            "avg_hypotheses_per_question": round(self.avg_hypotheses_per_question, 2),
            "avg_collapse_time_ms": round(self.avg_collapse_time_ms, 2),
        }


class HypothesisSuperposition:
    """Quantum-inspired hypothesis superposition for reasoning.

    Maintains multiple hypotheses simultaneously, delaying the decision
    until an external signal triggers collapse. This prevents premature
    commitment to a single answer.

    Usage:
        hs = HypothesisSuperposition()

        # Create superposition for a question
        state = hs.create("What is the best approach?")
        hs.add_hypothesis(state, "Approach A", confidence=0.7)
        hs.add_hypothesis(state, "Approach B", confidence=0.5)

        # Collapse when ready
        result = hs.collapse(state, trigger=CollapseTrigger.USER_CONFIRMATION)
    """

    def __init__(self, superposition_dir: Optional[str] = None):
        self._dir = Path(superposition_dir) if superposition_dir else _SUPERPOSITION_DIR
        self._states: Dict[str, SuperpositionState] = {}
        self._stats = SuperpositionStats()
        self._load()

    def create(self, question: str, max_time: float = 30.0) -> SuperpositionState:
        """Create a new superposition state for a question."""
        state = SuperpositionState(
            question=question,
            max_superposition_time=max_time,
        )
        state_id = f"sp_{int(time.time())}_{hash(question) % 10000:04d}"
        self._states[state_id] = state
        self._stats.total_superpositions += 1
        return state

    def add_hypothesis(
        self,
        state: SuperpositionState,
        content: str,
        confidence: float = 0.5,
        source: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Hypothesis:
        """Add a hypothesis to the superposition."""
        h_id = f"h_{len(state.hypotheses)}_{int(time.time() * 1000) % 100000:05d}"
        hypothesis = Hypothesis(
            hypothesis_id=h_id,
            content=content,
            amplitude=confidence,
            confidence=confidence,
            source=source,
            metadata=metadata or {},
        )
        state.hypotheses.append(hypothesis)
        self._stats.total_hypotheses += 1
        self._update_coherence(state)
        return hypothesis

    def verify_hypothesis(
        self, state: SuperpositionState, hypothesis_id: str, passed: bool,
    ) -> None:
        """Update hypothesis verification status."""
        for h in state.hypotheses:
            if h.hypothesis_id == hypothesis_id:
                h.verification_count += 1
                if passed:
                    current_rate = h.verification_rate
                    new_pass = current_rate * (h.verification_count - 1) + 1
                    h.verification_rate = new_pass / h.verification_count
                    h.amplitude = min(h.amplitude * 1.1, 1.0)
                else:
                    current_rate = h.verification_rate
                    new_pass = current_rate * (h.verification_count - 1)
                    h.verification_rate = new_pass / h.verification_count
                    h.amplitude = max(h.amplitude * 0.8, 0.01)
                break

    def collapse(
        self,
        state: SuperpositionState,
        trigger: CollapseTrigger = CollapseTrigger.MANUAL,
        preferred_id: Optional[str] = None,
    ) -> Optional[Hypothesis]:
        """Collapse the superposition to a single hypothesis.

        Args:
            state: The superposition state to collapse
            trigger: What triggered the collapse
            preferred_id: If specified, collapse to this hypothesis

        Returns:
            The winning hypothesis, or None if no hypotheses
        """
        if not state.hypotheses:
            return None

        if state.is_collapsed:
            for h in state.hypotheses:
                if h.hypothesis_id == state.collapsed_hypothesis_id:
                    return h
            return None

        if preferred_id:
            winner = None
            for h in state.hypotheses:
                if h.hypothesis_id == preferred_id:
                    winner = h
                    break
        else:
            winner = max(state.hypotheses, key=lambda h: h.effective_amplitude)

        if winner is None:
            winner = state.hypotheses[0]

        winner.state = HypothesisState.COLLAPSED
        state.collapsed_hypothesis_id = winner.hypothesis_id
        state.collapsed_at = time.time()
        state.collapse_trigger = trigger

        for h in state.hypotheses:
            if h.hypothesis_id != winner.hypothesis_id:
                h.state = HypothesisState.ABANDONED

        self._stats.collapsed += 1
        if trigger == CollapseTrigger.TIME_BUDGET:
            self._stats.auto_collapsed += 1

        collapse_time = (state.collapsed_at - state.created_at) * 1000
        self._stats.avg_collapse_time_ms = (
            (self._stats.avg_collapse_time_ms * (self._stats.collapsed - 1) + collapse_time)
            / self._stats.collapsed
        )

        self._save()
        return winner

    def check_auto_collapse(self) -> List[str]:
        """Check and auto-collapse expired superpositions.

        Returns:
            List of collapsed state IDs
        """
        collapsed_ids = []
        for state_id, state in self._states.items():
            if not state.is_collapsed and state.should_auto_collapse:
                self.collapse(state, trigger=CollapseTrigger.TIME_BUDGET)
                collapsed_ids.append(state_id)
        return collapsed_ids

    def get_state(self, state_id: str) -> Optional[SuperpositionState]:
        return self._states.get(state_id)

    def get_active_superpositions(self) -> List[Dict[str, Any]]:
        """Get all active (non-collapsed) superpositions."""
        return [
            s.to_dict() for s in self._states.values()
            if not s.is_collapsed
        ]

    def get_stats(self) -> Dict[str, Any]:
        if self._stats.total_superpositions > 0:
            self._stats.avg_hypotheses_per_question = (
                self._stats.total_hypotheses / self._stats.total_superpositions
            )
        return self._stats.to_dict()

    def _update_coherence(self, state: SuperpositionState) -> None:
        if len(state.hypotheses) < 2:
            state.coherence = 1.0
            return

        amplitudes = [h.effective_amplitude for h in state.hypotheses]
        total = sum(amplitudes)
        if total == 0:
            state.coherence = 0.0
            return

        probs = [a / total for a in amplitudes]
        entropy = -sum(p * math.log2(max(p, 1e-10)) for p in probs if p > 0)
        max_entropy = math.log2(len(state.hypotheses))
        state.coherence = 1.0 - (entropy / max_entropy if max_entropy > 0 else 0)

    def _save(self) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            data = {"stats": self._stats.to_dict()}
            path = self._dir / "superposition_data.json"
            path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            logger.debug("Failed to save superposition data: %s", e)

    def _load(self) -> None:
        try:
            path = self._dir / "superposition_data.json"
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            stats = data.get("stats", {})
            self._stats = SuperpositionStats(
                total_superpositions=stats.get("total_superpositions", 0),
                total_hypotheses=stats.get("total_hypotheses", 0),
                collapsed=stats.get("collapsed", 0),
                auto_collapsed=stats.get("auto_collapsed", 0),
                avg_collapse_time_ms=stats.get("avg_collapse_time_ms", 0),
            )
        except Exception as e:
            logger.debug("Failed to load superposition data: %s", e)
