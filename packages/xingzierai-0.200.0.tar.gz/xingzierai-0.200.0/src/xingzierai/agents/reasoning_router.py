# -*- coding: utf-8 -*-
"""Three-Tier Reasoning Router - Intelligence First Principle.

From AGI Whitepaper (2026-05-16):
  Current: User input -> LLM call (90%) -> Output
  Target:  User input -> L0 rules (60%) -> L1 symbolic (25%) -> L2 synthesis (10%) -> L3 LLM (5%)

Core principle: Use rules when possible, symbolic reasoning when rules fail,
program synthesis when symbols fail, LLM only as last resort.

Decision tree: Rule -> Symbolic Reasoning -> Program Synthesis -> LLM

Iron Laws (V7.4):
  16. LLM call decreasing principle
  17. Experience executable principle
  18. Rule internalization priority principle
  19. Evolution direction verification principle
  20. Intelligence measurement principle
"""

from __future__ import annotations

import inspect
import json
import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_METRICS_DIR = Path.home() / ".xingzierai" / "reasoning_metrics"


class ReasoningTier(str, Enum):
    L0_RULE = "L0"
    L1_SYMBOLIC = "L1"
    L2_SYNTHESIS = "L2"
    L3_LLM = "L3"


@dataclass
class RoutingResult:
    tier: ReasoningTier
    output: str
    confidence: float = 0.0
    latency_ms: float = 0.0
    token_cost: int = 0
    rule_id: str = ""
    skill_name: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_llm_free(self) -> bool:
        return self.tier in (ReasoningTier.L0_RULE, ReasoningTier.L1_SYMBOLIC)


@dataclass
class RuntimeRule:
    id: str
    name: str
    pattern: str
    category: str
    action: str
    priority: int = 0
    confidence: float = 1.0
    token_cost: int = 0
    latency_budget_ms: float = 1.0
    success_count: int = 0
    failure_count: int = 0
    _compiled_pattern: Optional[re.Pattern] = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        try:
            self._compiled_pattern = re.compile(self.pattern)
        except re.error:
            self._compiled_pattern = None

    def matches(self, text: str) -> bool:
        if self._compiled_pattern is None:
            return False
        return bool(self._compiled_pattern.search(text))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "name": self.name, "pattern": self.pattern,
            "category": self.category, "action": self.action,
            "priority": self.priority, "confidence": self.confidence,
            "token_cost": self.token_cost, "latency_budget_ms": self.latency_budget_ms,
            "success_count": self.success_count, "failure_count": self.failure_count,
        }


@dataclass
class TierMetrics:
    total_requests: int = 0
    hit_count: int = 0
    total_latency_ms: float = 0.0
    total_tokens: int = 0
    success_count: int = 0
    failure_count: int = 0

    @property
    def hit_rate(self) -> float:
        return self.hit_count / max(self.total_requests, 1)

    @property
    def avg_latency_ms(self) -> float:
        return self.total_latency_ms / max(self.hit_count, 1)

    @property
    def success_rate(self) -> float:
        return self.success_count / max(self.hit_count, 1)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_requests": self.total_requests,
            "hit_count": self.hit_count,
            "hit_rate": round(self.hit_rate, 4),
            "avg_latency_ms": round(self.avg_latency_ms, 2),
            "total_tokens": self.total_tokens,
            "success_rate": round(self.success_rate, 4),
        }


BUILTIN_RUNTIME_RULES: List[RuntimeRule] = [
    RuntimeRule(
        id="RR-001", name="greeting_response", pattern="^(hi|hello|hey|你好|嗨|您好)",
        category="greeting", action="greeting_reply", priority=100, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-002", name="time_query", pattern="(几点|时间|what time|current time)",
        category="time", action="get_time", priority=90, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-003", name="status_check", pattern="(状态|status|健康|health|运行|running)",
        category="status", action="check_status", priority=80, confidence=0.90,
    ),
    RuntimeRule(
        id="RR-004", name="version_query", pattern="(版本|version|v\\d+\\.\\d+)",
        category="version", action="get_version", priority=80, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-005", name="help_request", pattern="(帮助|help|怎么用|how to|使用说明)",
        category="help", action="show_help", priority=85, confidence=0.90,
    ),
    RuntimeRule(
        id="RR-006", name="list_query", pattern="(列出|list|显示所有|show all|有哪些)",
        category="list", action="list_items", priority=70, confidence=0.80,
    ),
    RuntimeRule(
        id="RR-007", name="simple_yes_no", pattern="^(是|否|yes|no|对|不对|好的|不行)$",
        category="confirmation", action="confirm_reply", priority=95, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-008", name="clear_command", pattern="^(清空|clear|重置|reset|清除)$",
        category="command", action="clear_context", priority=90, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-009", name="cancel_command", pattern="^(取消|cancel|停止|stop|abort)$",
        category="command", action="cancel_action", priority=90, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-010", name="thank_you", pattern="(谢谢|thank|thanks|感谢|多谢)",
        category="greeting", action="acknowledge_thanks", priority=95, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-011", name="bug_pattern_check", pattern="(bug|缺陷|错误模式|bug pattern|BP-\\d+)",
        category="debug", action="lookup_bug_pattern", priority=60, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-012", name="evolution_status", pattern="(进化状态|evolution status|轮次|round)",
        category="evolution", action="evolution_status", priority=60, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-013", name="date_query", pattern="(日期|今天|date|today|星期|周几)",
        category="time", action="get_date", priority=90, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-014", name="weather_query", pattern="(天气|weather|温度|temperature|下雨|rain)",
        category="weather", action="weather_reply", priority=60, confidence=0.60,
    ),
    RuntimeRule(
        id="RR-015", name="calculator_simple", pattern="^(\\d+\\s*[+\\-*/]\\s*\\d+)$",
        category="math", action="simple_calculate", priority=95, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-016", name="agent_list", pattern="(agent|智能体|代理).*(列表|list|有哪些|show)",
        category="agent", action="list_agents", priority=75, confidence=0.85,
    ),
    RuntimeRule(
        id="RR-017", name="model_list", pattern="(模型|model).*(列表|list|有哪些|show)",
        category="model", action="list_models", priority=75, confidence=0.85,
    ),
    RuntimeRule(
        id="RR-018", name="skill_list", pattern="(技能|skill|能力).*(列表|list|有哪些|show)",
        category="skill", action="list_skills", priority=75, confidence=0.85,
    ),
    RuntimeRule(
        id="RR-019", name="kappa_stats", pattern="(经验|kappa|experience).*(统计|stats|状态)",
        category="kappa", action="kappa_stats", priority=70, confidence=0.80,
    ),
    RuntimeRule(
        id="RR-020", name="safety_stats", pattern="(安全|safety|guard).*(统计|stats|状态)",
        category="safety", action="safety_stats", priority=70, confidence=0.80,
    ),
    RuntimeRule(
        id="RR-021", name="evolution_trigger", pattern="^(进化|自进化|evolve|开始进化)$",
        category="evolution", action="trigger_evolution", priority=95, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-022", name="quick_evolution", pattern="^(快速进化|快速升级|quick evolve)$",
        category="evolution", action="trigger_quick_evolution", priority=95, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-023", name="research_trigger", pattern="^(调研|技术调研|research)$",
        category="evolution", action="trigger_research", priority=95, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-024", name="competitor_research", pattern="^(竞品调研|竞品分析|技术对标)$",
        category="evolution", action="trigger_competitor_research", priority=95, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-025", name="audit_trigger", pattern="^(审计|代码审计|audit)$",
        category="evolution", action="trigger_audit", priority=95, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-026", name="test_trigger", pattern="^(测试|系统测试|test|run tests)$",
        category="testing", action="trigger_test", priority=95, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-027", name="stability_test", pattern="^(稳定性测试|压力测试|stability test)$",
        category="testing", action="trigger_stability_test", priority=95, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-028", name="data_sync", pattern="^(数据同步|飞轮同步|data sync)$",
        category="data", action="trigger_data_sync", priority=90, confidence=0.90,
    ),
    RuntimeRule(
        id="RR-029", name="safety_eval", pattern="^(安全检查|安全评估|safety eval)$",
        category="safety", action="trigger_safety_eval", priority=90, confidence=0.90,
    ),
    RuntimeRule(
        id="RR-030", name="goodbye", pattern="^(再见|bye|goodbye|拜拜|下次见|回见)$",
        category="greeting", action="goodbye_reply", priority=100, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-031", name="who_are_you", pattern="(你是谁|who are you|你叫什么|what are you|介绍你自己)",
        category="identity", action="self_introduce", priority=95, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-032", name="capability_query", pattern="(你能做什么|你能干什么|what can you do|capabilities)",
        category="identity", action="show_capabilities", priority=95, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-033", name="architecture_query", pattern="(架构|architecture|系统设计|system design|三级推理)",
        category="architecture", action="explain_architecture", priority=80, confidence=0.85,
    ),
    RuntimeRule(
        id="RR-034", name="reasoning_tier_query", pattern="(推理层级|reasoning tier|L0|L1|L2|L3|规则命中率)",
        category="architecture", action="explain_reasoning_tiers", priority=80, confidence=0.85,
    ),
    RuntimeRule(
        id="RR-035", name="iron_law_query", pattern="(铁律|iron law|防偏移|V7\\.4|白皮书|whitepaper)",
        category="architecture", action="explain_iron_laws", priority=75, confidence=0.80,
    ),
    RuntimeRule(
        id="RR-036", name="competitor_gap_query", pattern="(竞品差距|competitor gap|CG-\\d+|差距追踪)",
        category="evolution", action="show_competitor_gaps", priority=70, confidence=0.75,
    ),
    RuntimeRule(
        id="RR-037", name="intelligence_metrics", pattern="(智能度量|intelligence metric|Token效率|规则命中率|零样本)",
        category="metrics", action="show_intelligence_metrics", priority=70, confidence=0.75,
    ),
    RuntimeRule(
        id="RR-038", name="emergency_stop", pattern="^(紧急停止|emergency stop|紧急制动)$",
        category="command", action="emergency_stop", priority=100, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-039", name="rollback_request", pattern="^(回滚|rollback|撤回|undo)$",
        category="command", action="rollback_action", priority=90, confidence=0.90,
    ),
    RuntimeRule(
        id="RR-040", name="config_query", pattern="(配置|config|设置|setting).*(查看|show|get|当前)",
        category="config", action="show_config", priority=70, confidence=0.75,
    ),
    RuntimeRule(
        id="RR-041", name="log_query", pattern="(日志|log|记录|record).*(查看|show|get|最近)",
        category="log", action="show_recent_log", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-042", name="memory_query", pattern="(内存|memory|RAM|使用率|usage)",
        category="system", action="show_memory_usage", priority=70, confidence=0.75,
    ),
    RuntimeRule(
        id="RR-043", name="disk_query", pattern="(磁盘|disk|存储|storage|空间|space)",
        category="system", action="show_disk_usage", priority=70, confidence=0.75,
    ),
    RuntimeRule(
        id="RR-044", name="network_query", pattern="(网络|network|连接|connection|端口|port)",
        category="system", action="show_network_status", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-045", name="process_query", pattern="(进程|process|PID|线程|thread)",
        category="system", action="show_process_info", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-046", name="env_query", pattern="(环境|environment|env|Python版本|node版本)",
        category="system", action="show_environment", priority=70, confidence=0.75,
    ),
    RuntimeRule(
        id="RR-047", name="api_endpoint_list", pattern="(API|接口|endpoint).*(列表|list|有哪些)",
        category="api", action="list_api_endpoints", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-048", name="token_economics", pattern="(token|token消耗|token成本|cost|费用|用量)",
        category="metrics", action="show_token_economics", priority=70, confidence=0.75,
    ),
    RuntimeRule(
        id="RR-049", name="feature_flag_query", pattern="(feature flag|功能开关|特性标志|灰度)",
        category="config", action="show_feature_flags", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-050", name="deployment_info", pattern="(部署|deploy|发布|release|上线)",
        category="deployment", action="show_deployment_info", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-051", name="changelog_query", pattern="(变更|changelog|更新日志|更新记录|changes)",
        category="log", action="show_changelog", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-052", name="knowledge_graph_query", pattern="(知识图谱|knowledge graph|KG|图谱)",
        category="knowledge", action="show_knowledge_graph_status", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-053", name="population_evolution_query", pattern="(种群|population|进化档案|archive|变体|variant)",
        category="evolution", action="show_population_status", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-054", name="local_model_query", pattern="(本地模型|local model|小模型|ollama|蒸馏)",
        category="model", action="show_local_model_status", priority=70, confidence=0.75,
    ),
    RuntimeRule(
        id="RR-055", name="repeat_request", pattern="^(再说一遍|repeat|重复|再说一次)$",
        category="command", action="repeat_last", priority=85, confidence=0.90,
    ),
    RuntimeRule(
        id="RR-056", name="affirmation", pattern="^(好的|嗯|行|OK|ok|可以|没问题|是的|对|没错|确实)$",
        category="confirmation", action="acknowledge_affirm", priority=95, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-057", name="negation", pattern="^(不|不是|不对|不行|no|No|NO|不要|别)$",
        category="confirmation", action="acknowledge_negate", priority=95, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-058", name="compliment", pattern="(厉害|棒|牛|awesome|great|amazing|excellent|nice|good job|做得好|太强了)",
        category="greeting", action="accept_compliment", priority=90, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-059", name="complaint", pattern="(差|烂|垃圾|terrible|bad|awful|sucks|不好用|难用|慢|卡)",
        category="feedback", action="handle_complaint", priority=85, confidence=0.85,
    ),
    RuntimeRule(
        id="RR-060", name="language_switch", pattern="^(说英文|speak english|用英语|switch to english|英文模式)$",
        category="command", action="switch_language_en", priority=90, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-061", name="language_switch_cn", pattern="^(说中文|说汉语|speak chinese|用中文|switch to chinese|中文模式)$",
        category="command", action="switch_language_cn", priority=90, confidence=0.95,
    ),
    RuntimeRule(
        id="RR-062", name="summarize_request", pattern="(总结|摘要|summarize|summary|概括|归纳|要点)",
        category="task", action="summarize_hint", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-063", name="translate_request", pattern="(翻译|translate|翻成|译成|中译英|英译中)",
        category="task", action="translate_hint", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-064", name="code_explain", pattern="(解释代码|explain code|这段代码|什么意思|代码分析|code review)",
        category="task", action="code_explain_hint", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-065", name="debug_request", pattern="(调试|debug|报错|错误|error|exception|traceback|修bug)",
        category="task", action="debug_hint", priority=70, confidence=0.75,
    ),
    RuntimeRule(
        id="RR-066", name="emoji_greeting", pattern="^(👋|🙏|🤝|😊|😄|🥰|💕)$",
        category="greeting", action="emoji_greeting_reply", priority=95, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-067", name="emoji_thanks", pattern="^(👍|❤️|💖|💯|🎉|🎊|👏)$",
        category="greeting", action="emoji_thanks_reply", priority=95, confidence=0.99,
    ),
    RuntimeRule(
        id="RR-068", name="search_request", pattern="(搜索|查找|search|find|查找一下|搜一下|检索)",
        category="task", action="search_hint", priority=60, confidence=0.65,
    ),
    RuntimeRule(
        id="RR-069", name="compare_request", pattern="(对比|比较|compare|vs|versus|区别|差异|哪个好)",
        category="task", action="compare_hint", priority=60, confidence=0.65,
    ),
    RuntimeRule(
        id="RR-070", name="list_request", pattern="(列出|列举|list|有哪些|都有什么|清单|列表)",
        category="task", action="list_hint", priority=60, confidence=0.65,
    ),
    RuntimeRule(
        id="RR-071", name="explain_request", pattern="(解释|explain|什么是|是什么|介绍一下|说明|阐述)",
        category="task", action="explain_hint", priority=60, confidence=0.65,
    ),
    RuntimeRule(
        id="RR-072", name="write_request", pattern="(写|编写|write|创作|生成|起草|draft|compose)",
        category="task", action="write_hint", priority=55, confidence=0.60,
    ),
    RuntimeRule(
        id="RR-073", name="optimize_request", pattern="(优化|optimize|改进|提升|改善|提速|加速)",
        category="task", action="optimize_hint", priority=60, confidence=0.65,
    ),
    RuntimeRule(
        id="RR-074", name="test_request", pattern="(测试|test|验证|verify|检查|check|单元测试|集成测试)",
        category="task", action="test_hint", priority=60, confidence=0.65,
    ),
    RuntimeRule(
        id="RR-075", name="deploy_request", pattern="(部署|deploy|发布|release|上线|发布版本)",
        category="task", action="deploy_hint", priority=60, confidence=0.65,
    ),
    RuntimeRule(
        id="RR-076", name="security_request", pattern="(安全|security|漏洞|vulnerability|加密|encrypt|认证|auth)",
        category="task", action="security_hint", priority=65, confidence=0.70,
    ),
    RuntimeRule(
        id="RR-077", name="performance_request", pattern="(性能|performance|延迟|latency|吞吐|throughput|并发|concurrent)",
        category="task", action="performance_hint", priority=60, confidence=0.65,
    ),
    RuntimeRule(
        id="RR-078", name="data_request", pattern="(数据|data|数据库|database|存储|storage|查询|query)",
        category="task", action="data_hint", priority=55, confidence=0.60,
    ),
    RuntimeRule(
        id="RR-079", name="api_request", pattern="(接口|api|endpoint|rest|graphql|请求|request|响应|response)",
        category="task", action="api_hint", priority=55, confidence=0.60,
    ),
    RuntimeRule(
        id="RR-080", name="config_request", pattern="(配置|config|设置|setting|参数|parameter|环境变量|env)",
        category="task", action="config_hint", priority=60, confidence=0.65,
    ),
]


class ReasoningRouter:
    """Three-Tier Reasoning Router.

    Routes user input through L0->L1->L2->L3 cascade:
    - L0: Deterministic rules (0 tokens, <1ms)
    - L1: Symbolic reasoning / knowledge graph lookup (few tokens, <100ms)
    - L2: Program synthesis / executable skills (moderate tokens, <5s)
    - L3: Full LLM call (many tokens, seconds)

    Target distribution: L0:60% + L1:25% + L2:10% + L3:5%
    """

    _METRICS_SAVE_INTERVAL = 100

    TARGET_DISTRIBUTION = {
        ReasoningTier.L0_RULE: 0.60,
        ReasoningTier.L1_SYMBOLIC: 0.25,
        ReasoningTier.L2_SYNTHESIS: 0.10,
        ReasoningTier.L3_LLM: 0.05,
    }

    def __init__(
        self,
        knowledge_graph=None,
        kappa_engine=None,
        skill_manager=None,
        bug_pattern_kb=None,
        custom_rules: Optional[List[RuntimeRule]] = None,
        metrics_dir: Optional[str] = None,
    ):
        self._kg = knowledge_graph
        self._kappa = kappa_engine
        self._skills = skill_manager
        self._bug_kb = bug_pattern_kb
        self._refinement_loop = None
        try:
            from .refinement_loop import RefinementLoop, create_data_transform_generator, create_data_transform_revisor
            self._refinement_loop = RefinementLoop()
            self._refinement_loop.register_generator("data_transform", create_data_transform_generator())
            self._refinement_loop.register_revisor("data_transform", create_data_transform_revisor())
        except Exception as exc:
            logger.warning("RefinementLoop init skipped: %s", exc)

        self._auto_upgrade_kappa()

        self._rules: Dict[str, RuntimeRule] = {}
        for rule in BUILTIN_RUNTIME_RULES:
            self._rules[rule.id] = rule
        if custom_rules:
            for rule in custom_rules:
                self._rules[rule.id] = rule

        self._sorted_rules: List[RuntimeRule] = []
        self._rebuild_sorted_rules()

        self._action_handlers: Dict[str, Callable] = {
            "greeting_reply": self._action_greeting,
            "get_time": self._action_get_time,
            "check_status": self._action_check_status,
            "get_version": self._action_get_version,
            "show_help": self._action_show_help,
            "list_items": self._action_list_items,
            "confirm_reply": self._action_confirm,
            "clear_context": self._action_clear,
            "cancel_action": self._action_cancel,
            "acknowledge_thanks": self._action_thanks,
            "lookup_bug_pattern": self._action_bug_pattern,
            "evolution_status": self._action_evolution_status,
            "get_date": self._action_get_date,
            "weather_reply": self._action_weather,
            "simple_calculate": self._action_calculate,
            "list_agents": self._action_list_agents,
            "list_models": self._action_list_models,
            "list_skills": self._action_list_skills,
            "kappa_stats": self._action_kappa_stats,
            "safety_stats": self._action_safety_stats,
            "trigger_evolution": self._action_trigger_evolution,
            "trigger_quick_evolution": self._action_trigger_quick_evolution,
            "trigger_research": self._action_trigger_research,
            "trigger_competitor_research": self._action_trigger_competitor_research,
            "trigger_audit": self._action_trigger_audit,
            "trigger_test": self._action_trigger_test,
            "trigger_stability_test": self._action_trigger_stability_test,
            "trigger_data_sync": self._action_trigger_data_sync,
            "trigger_safety_eval": self._action_trigger_safety_eval,
            "goodbye_reply": self._action_goodbye,
            "self_introduce": self._action_self_introduce,
            "show_capabilities": self._action_show_capabilities,
            "explain_architecture": self._action_explain_architecture,
            "explain_reasoning_tiers": self._action_explain_reasoning_tiers,
            "explain_iron_laws": self._action_explain_iron_laws,
            "show_competitor_gaps": self._action_show_competitor_gaps,
            "show_intelligence_metrics": self._action_show_intelligence_metrics,
            "emergency_stop": self._action_emergency_stop,
            "rollback_action": self._action_rollback,
            "show_config": self._action_show_config,
            "show_recent_log": self._action_show_recent_log,
            "show_memory_usage": self._action_show_memory_usage,
            "show_disk_usage": self._action_show_disk_usage,
            "show_network_status": self._action_show_network_status,
            "show_process_info": self._action_show_process_info,
            "show_environment": self._action_show_environment,
            "list_api_endpoints": self._action_list_api_endpoints,
            "show_token_economics": self._action_show_token_economics,
            "show_feature_flags": self._action_show_feature_flags,
            "show_deployment_info": self._action_show_deployment_info,
            "show_changelog": self._action_show_changelog,
            "show_knowledge_graph_status": self._action_show_kg_status,
            "show_population_status": self._action_show_population_status,
            "show_local_model_status": self._action_show_local_model_status,
            "repeat_last": self._action_repeat_last,
            "acknowledge_affirm": self._action_acknowledge_affirm,
            "acknowledge_negate": self._action_acknowledge_negate,
            "accept_compliment": self._action_accept_compliment,
            "handle_complaint": self._action_handle_complaint,
            "switch_language_en": self._action_switch_language_en,
            "switch_language_cn": self._action_switch_language_cn,
            "summarize_hint": self._action_summarize_hint,
            "translate_hint": self._action_translate_hint,
            "code_explain_hint": self._action_code_explain_hint,
            "debug_hint": self._action_debug_hint,
            "emoji_greeting_reply": self._action_emoji_greeting_reply,
            "emoji_thanks_reply": self._action_emoji_thanks_reply,
            "search_hint": self._action_search_hint,
            "compare_hint": self._action_compare_hint,
            "list_hint": self._action_list_hint,
            "explain_hint": self._action_explain_hint,
            "write_hint": self._action_write_hint,
            "optimize_hint": self._action_optimize_hint,
            "test_hint": self._action_test_hint,
            "deploy_hint": self._action_deploy_hint,
            "security_hint": self._action_security_hint,
            "performance_hint": self._action_performance_hint,
            "data_hint": self._action_data_hint,
            "api_hint": self._action_api_hint,
            "config_hint": self._action_config_hint,
        }

        self._metrics: Dict[ReasoningTier, TierMetrics] = {
            tier: TierMetrics() for tier in ReasoningTier
        }
        self._total_routed = 0
        self._llm_calls_avoided = 0
        self._metrics_since_last_save = 0

        self._metrics_dir = Path(metrics_dir) if metrics_dir else _METRICS_DIR
        self._load_metrics()

        self._auto_learner = None
        try:
            from .rule_auto_learner import RuleAutoLearner
            self._auto_learner = RuleAutoLearner()
            self._load_learned_rules()
        except Exception as exc:
            logger.warning("RuleAutoLearner init skipped: %s", exc)

        self._coverage_tracker = None
        try:
            from .rule_coverage_tracker import RuleCoverageTracker
            self._coverage_tracker = RuleCoverageTracker()
        except Exception as exc:
            logger.warning("RuleCoverageTracker init skipped: %s", exc)

        self._entropy_tracker = None
        try:
            from .entropy_tracker import EntropyReductionTracker
            self._entropy_tracker = EntropyReductionTracker()
        except Exception as exc:
            logger.warning("EntropyReductionTracker init skipped: %s", exc)

        self._l3_miner = None
        try:
            from .l3_pattern_miner import L3PatternMiner
            self._l3_miner = L3PatternMiner()
        except Exception as exc:
            logger.warning("L3PatternMiner init skipped: %s", exc)

        self._kappa_allowed_categories: set = {"debug", "fix", "pattern"}

    def _rebuild_sorted_rules(self) -> None:
        self._sorted_rules = sorted(self._rules.values(), key=lambda r: -r.priority)

    def _auto_upgrade_kappa(self) -> None:
        if not self._kappa:
            return
        try:
            stats = self._kappa.get_stats()
            total = stats.get("total_packs", 0)
            executable = stats.get("executable_packs", 0)
            if total > 0 and executable < total:
                self._kappa.batch_upgrade_to_executable(
                    min_confidence=0.5,
                    min_success_count=1,
                )
                logger.debug("Auto-upgraded Kappa packs: total=%d, was_executable=%d", total, executable)
        except Exception as exc:
            logger.warning("Auto-upgrade Kappa failed: %s", exc)

    def add_rule(self, rule: RuntimeRule) -> None:
        self._rules[rule.id] = rule
        self._rebuild_sorted_rules()

    def add_action_handler(self, action: str, handler: Callable) -> None:
        self._action_handlers[action] = handler

    async def route(self, user_input: str, context: Optional[Dict[str, Any]] = None) -> RoutingResult:
        """Route user input through L0->L1->L2->L3 cascade.

        Returns the first tier that can handle the input.
        """
        self._total_routed += 1
        ctx = context or {}

        l0_result = await self._try_l0(user_input, ctx)
        if l0_result is not None:
            self._record_metric(l0_result)
            self._record_to_learner(user_input, l0_result)
            self._record_coverage(user_input, l0_result)
            return l0_result

        l1_result = await self._try_l1(user_input, ctx)
        if l1_result is not None:
            self._record_metric(l1_result)
            self._record_to_learner(user_input, l1_result)
            self._record_coverage(user_input, l1_result)
            return l1_result

        l2_result = await self._try_l2(user_input, ctx)
        if l2_result is not None:
            self._record_metric(l2_result)
            self._record_to_learner(user_input, l2_result)
            self._record_coverage(user_input, l2_result)
            return l2_result

        l3_result = self._fallback_l3(user_input, ctx)
        self._record_metric(l3_result)
        self._record_to_learner(user_input, l3_result)
        self._record_coverage(user_input, l3_result)
        return l3_result

    def _record_to_learner(self, user_input: str, result: RoutingResult) -> None:
        if self._auto_learner is None:
            return
        try:
            from .rule_auto_learner import InteractionRecord
            self._auto_learner.record_interaction(InteractionRecord(
                user_input=user_input,
                tier=result.tier.value,
                output=result.output,
                rule_id=result.rule_id,
                confidence=result.confidence,
            ))
        except Exception as exc:
            logger.warning("Record to learner failed: %s", exc)

    def _record_coverage(self, user_input: str, result: RoutingResult) -> None:
        if self._coverage_tracker is None:
            return
        try:
            category = result.metadata.get("rule_name", "")
            if not category:
                category = result.metadata.get("source", "")
            self._coverage_tracker.record(
                user_input=user_input,
                tier=result.tier.value,
                rule_id=result.rule_id,
                category=category,
                confidence=result.confidence,
            )
            if self._entropy_tracker and result.tier.value in ("L0", "L1") and result.rule_id:
                self._entropy_tracker.record_rule_hit(result.rule_id)
            if self._l3_miner and result.tier.value == "L3":
                self._l3_miner.record_l3_interaction(
                    user_input=user_input,
                    output=result.output[:200] if result.output else "",
                    category=category,
                )
        except Exception as exc:
            logger.warning("Record coverage failed: %s", exc)

    def get_coverage_report(self) -> Dict[str, Any]:
        """Get L0 rule coverage report."""
        if self._coverage_tracker is None:
            return {"status": "coverage_tracker_not_available"}
        return self._coverage_tracker.get_report()

    def _load_learned_rules(self) -> None:
        if self._auto_learner is None:
            return
        try:
            for lr in self._auto_learner.get_learned_rules():
                if lr.id not in self._rules:
                    rt_rule = RuntimeRule(
                        id=lr.id,
                        name=f"learned_{lr.category}_{lr.id}",
                        pattern=lr.pattern,
                        category=lr.category,
                        action=lr.action,
                        priority=lr.priority,
                        confidence=lr.confidence,
                    )
                    self._rules[lr.id] = rt_rule
                    handler = self._auto_learner.create_action_handler(lr)
                    self._action_handlers[lr.action] = handler
        except Exception as exc:
            logger.warning("Load learned rules failed: %s", exc)

    async def _try_l0(self, user_input: str, context: Dict[str, Any]) -> Optional[RoutingResult]:
        """L0: Deterministic rules (0 tokens, <1ms)."""
        start = time.monotonic()
        self._metrics[ReasoningTier.L0_RULE].total_requests += 1

        input_stripped = user_input.strip()
        if not input_stripped:
            return None

        input_lower = input_stripped.lower()

        for rule in self._sorted_rules:
            try:
                if rule.matches(input_lower):
                    handler = self._action_handlers.get(rule.action)
                    if handler:
                        enriched_ctx = {"task": input_stripped, **context}
                        output = await self._invoke_handler(handler, enriched_ctx)
                        latency = (time.monotonic() - start) * 1000

                        result = RoutingResult(
                            tier=ReasoningTier.L0_RULE,
                            output=output,
                            confidence=rule.confidence,
                            latency_ms=latency,
                            token_cost=0,
                            rule_id=rule.id,
                            metadata={"rule_name": rule.name, "pattern": rule.pattern},
                        )

                        rule.success_count += 1
                        self._llm_calls_avoided += 1
                        return result
            except Exception as e:
                logger.debug("L0 rule %s failed: %s", rule.id, e)
                continue

        return None

    async def _try_l1(self, user_input: str, context: Dict[str, Any]) -> Optional[RoutingResult]:
        """L1: Symbolic reasoning / knowledge graph lookup (few tokens, <100ms)."""
        start = time.monotonic()
        self._metrics[ReasoningTier.L1_SYMBOLIC].total_requests += 1

        if self._kappa:
            try:
                packs = self._kappa.find_relevant(user_input, min_confidence=0.6, max_results=3)
                if packs:
                    best = packs[0]
                    if best.confidence >= 0.7 and best.status.value in ("validated", "active"):
                        output = best.solution

                        if best.is_executable:
                            pack_category = getattr(best.category, "value", str(best.category))
                            if pack_category not in self._kappa_allowed_categories:
                                logger.warning(
                                    "Kappa executable pack %s category '%s' not in allowed set, skipping execution",
                                    best.id, pack_category,
                                )
                            else:
                                try:
                                    exec_result = await self._kappa.execute_pack(
                                        best.id, {"task": user_input, **context},
                                    )
                                    if exec_result and exec_result.get("success") and exec_result.get("output"):
                                        output = exec_result["output"]
                                except Exception as exec_err:
                                    logger.debug("L1 Kappa executable failed, using text: %s", exec_err)

                        latency = (time.monotonic() - start) * 1000

                        result = RoutingResult(
                            tier=ReasoningTier.L1_SYMBOLIC,
                            output=output,
                            confidence=best.confidence,
                            latency_ms=latency,
                            token_cost=0,
                            metadata={
                                "kappa_pack_id": best.id,
                                "kappa_pack_name": best.name,
                                "category": best.category.value,
                                "executable": best.is_executable,
                            },
                        )
                        self._llm_calls_avoided += 1
                        return result
            except Exception as e:
                logger.debug("L1 Kappa lookup failed: %s", e)

        if self._kg:
            try:
                from xingzierai.knowledge_graph.retriever import SubgraphRetriever
                if isinstance(self._kg, SubgraphRetriever):
                    subgraph = self._kg.retrieve(user_input, max_tokens=500)
                    if subgraph and subgraph.strip():
                        latency = (time.monotonic() - start) * 1000
                        result = RoutingResult(
                            tier=ReasoningTier.L1_SYMBOLIC,
                            output=subgraph,
                            confidence=0.6,
                            latency_ms=latency,
                            token_cost=0,
                            metadata={"source": "knowledge_graph"},
                        )
                        self._llm_calls_avoided += 1
                        return result
            except Exception as e:
                logger.debug("L1 KG lookup failed: %s", e)

        if self._bug_kb:
            try:
                matches = self._bug_kb.lookup(user_input)
                if matches:
                    best = matches[0]
                    latency = (time.monotonic() - start) * 1000
                    result = RoutingResult(
                        tier=ReasoningTier.L1_SYMBOLIC,
                        output=best.get("fix_method", best.get("description", "")),
                        confidence=0.8,
                        latency_ms=latency,
                        token_cost=0,
                        rule_id=best.get("id", ""),
                        metadata={"source": "bug_pattern_kb"},
                    )
                    self._llm_calls_avoided += 1
                    return result
            except Exception as e:
                logger.debug("L1 Bug KB lookup failed: %s", e)

        return None

    async def _try_l2(self, user_input: str, context: Dict[str, Any]) -> Optional[RoutingResult]:
        """L2: Program synthesis / executable skills (moderate tokens, <5s)."""
        start = time.monotonic()
        self._metrics[ReasoningTier.L2_SYNTHESIS].total_requests += 1

        if self._skills:
            try:
                skill_name = self._skills.find_skill(user_input)
                if skill_name:
                    exec_context = {
                        "task": user_input,
                        **context,
                    }
                    result = await self._skills.execute_skill(skill_name, exec_context)
                    latency = (time.monotonic() - start) * 1000

                    if result.get("success", False):
                        routing_result = RoutingResult(
                            tier=ReasoningTier.L2_SYNTHESIS,
                            output=result.get("output", ""),
                            confidence=0.8,
                            latency_ms=latency,
                            token_cost=0,
                            skill_name=skill_name,
                            metadata={"source": "executable_skill"},
                        )
                        self._llm_calls_avoided += 1
                        return routing_result
            except Exception as e:
                logger.debug("L2 skill execution failed: %s", e)

        if self._refinement_loop:
            try:
                problem_type = self._classify_synthesis_problem(user_input)
                if problem_type:
                    from .refinement_loop import TestCase
                    test_cases = []

                    test_output = context.get("expected_output")
                    if test_output is not None:
                        test_cases.append(TestCase(
                            name="user_test",
                            input_data=context.get("test_input", user_input),
                            expected_output=test_output,
                        ))

                    refine_result = await self._refinement_loop.refine(
                        problem_type=problem_type,
                        problem_description=user_input,
                        test_cases=test_cases,
                        max_iterations=2,
                    )

                    if refine_result.status.value in ("passed", "max_iterations") and refine_result.solution:
                        latency = (time.monotonic() - start) * 1000
                        tr = refine_result.test_results
                        tr_passed = sum(1 for t in (tr if isinstance(tr, list) else []) if t.get("passed"))
                        tr_total = len(tr) if isinstance(tr, list) else 0
                        routing_result = RoutingResult(
                            tier=ReasoningTier.L2_SYNTHESIS,
                            output=refine_result.solution,
                            confidence=0.6 if refine_result.status.value == "max_iterations" else 0.85,
                            latency_ms=latency,
                            token_cost=0,
                            metadata={
                                "source": "refinement_loop",
                                "problem_type": problem_type,
                                "iterations": refine_result.iterations,
                                "test_passed": tr_passed,
                                "test_total": tr_total,
                            },
                        )
                        self._llm_calls_avoided += 1
                        return routing_result
            except Exception as e:
                logger.debug("L2 refinement loop failed: %s", e)

        return None

    def _classify_synthesis_problem(self, user_input: str) -> Optional[str]:
        input_lower = user_input.lower()
        synthesis_patterns = {
            "data_transform": [
                r"(排序|sort|排列|从小到大|从大到小)",
                r"(去重|去重复|dedup|unique|distinct)",
                r"(反转|reverse|倒序|逆序)",
                r"(过滤|filter|筛选|提取)",
                r"(转换|transform|映射|map)",
                r"(分组|group|分类|归类)",
            ],
        }
        for problem_type, patterns in synthesis_patterns.items():
            for pattern in patterns:
                if re.search(pattern, input_lower):
                    return problem_type
        return None

    def _fallback_l3(self, user_input: str, context: Dict[str, Any]) -> RoutingResult:
        """L3: Full LLM call (many tokens, seconds). Last resort."""
        self._metrics[ReasoningTier.L3_LLM].total_requests += 1
        return RoutingResult(
            tier=ReasoningTier.L3_LLM,
            output="",
            confidence=0.0,
            latency_ms=0.0,
            token_cost=0,
            metadata={"fallback": True, "pending_llm_call": True, "reason": "L0/L1/L2 all missed"},
        )

    async def _invoke_handler(self, handler: Callable, context: Dict[str, Any]) -> str:
        if inspect.iscoroutinefunction(handler):
            return await handler(context)
        return handler(context)

    def _record_metric(self, result: RoutingResult) -> None:
        metrics = self._metrics[result.tier]
        metrics.hit_count += 1
        metrics.total_latency_ms += result.latency_ms
        metrics.total_tokens += result.token_cost
        if result.confidence >= 0.5:
            metrics.success_count += 1
        else:
            metrics.failure_count += 1
        self._metrics_since_last_save += 1
        if self._metrics_since_last_save >= self._METRICS_SAVE_INTERVAL:
            self._save_metrics()
            self._metrics_since_last_save = 0

    def get_metrics(self) -> Dict[str, Any]:
        total = max(self._total_routed, 1)
        tier_metrics = {}
        for tier, m in self._metrics.items():
            tier_metrics[tier.value] = {
                **m.to_dict(),
                "distribution": round(m.hit_count / total, 4),
                "target": self.TARGET_DISTRIBUTION[tier],
                "gap_to_target": round(self.TARGET_DISTRIBUTION[tier] - m.hit_count / total, 4),
            }

        l0_l1_rate = (
            self._metrics[ReasoningTier.L0_RULE].hit_count
            + self._metrics[ReasoningTier.L1_SYMBOLIC].hit_count
        ) / total

        return {
            "total_routed": self._total_routed,
            "llm_calls_avoided": self._llm_calls_avoided,
            "llm_avoidance_rate": round(self._llm_calls_avoided / total, 4),
            "l0_l1_hit_rate": round(l0_l1_rate, 4),
            "target_l0_l1_rate": 0.85,
            "tier_metrics": tier_metrics,
        }

    def verify_evolution_direction(self) -> Dict[str, bool]:
        """V7.4 Iron Law 19: Evolution direction verification.

        Must answer 3 questions:
        1. Does this evolution make the system less dependent on LLM?
        2. Does it add internalizable rules/symbolic reasoning capability?
        3. Is it moving toward the three-tier architecture target?
        """
        metrics = self.get_metrics()
        l3_rate = metrics["tier_metrics"].get("L3", {}).get("distribution", 1.0)
        l0_l1_rate = metrics["l0_l1_hit_rate"]

        return {
            "less_llm_dependent": l3_rate < 0.5,
            "increased_internalization": l0_l1_rate > 0.1,
            "toward_three_tier": l0_l1_rate > 0.3,
            "l3_distribution": l3_rate,
            "l0_l1_distribution": l0_l1_rate,
        }

    def _save_metrics(self) -> None:
        try:
            self._metrics_dir.mkdir(parents=True, exist_ok=True)
            data = self.get_metrics()
            path = self._metrics_dir / "latest.json"
            path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e:
            logger.warning("Failed to save metrics: %s", e)

    def _load_metrics(self) -> None:
        try:
            path = self._metrics_dir / "latest.json"
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                self._total_routed = data.get("total_routed", 0)
                self._llm_calls_avoided = data.get("llm_calls_avoided", 0)
                for tier_key, tier_data in data.get("tier_metrics", {}).items():
                    tier = ReasoningTier(tier_key)
                    if tier in self._metrics:
                        m = self._metrics[tier]
                        m.hit_count = tier_data.get("hit_count", 0)
                        m.total_latency_ms = tier_data.get("total_latency_ms", 0.0)
                        m.total_tokens = tier_data.get("total_tokens", 0)
                        m.success_count = tier_data.get("success_count", 0)
                        m.failure_count = tier_data.get("failure_count", 0)
                        m.total_requests = tier_data.get("total_requests", 0)
        except Exception as e:
            logger.warning("Failed to load metrics: %s", e)

    # --- L0 Action Handlers ---

    @staticmethod
    def _action_greeting(context: Dict[str, Any]) -> str:
        return "你好！我是 XINGZIER AI，有什么可以帮你的吗？"

    @staticmethod
    def _action_get_time(context: Dict[str, Any]) -> str:
        from datetime import datetime
        now = datetime.now()
        return f"当前时间：{now.strftime('%Y-%m-%d %H:%M:%S')}"

    @staticmethod
    def _action_check_status(context: Dict[str, Any]) -> str:
        return "系统运行正常。所有服务健康。"

    @staticmethod
    def _action_get_version(context: Dict[str, Any]) -> str:
        return "XINGZIER AI V7.4 - 三级推理架构已启用"

    @staticmethod
    def _action_show_help(context: Dict[str, Any]) -> str:
        return (
            "可用命令：\n"
            "- 进化/自进化：启动完整进化流程\n"
            "- 快速进化：跳过调研直接执行\n"
            "- 调研/技术调研：仅执行技术调研\n"
            "- 竞品调研：4维度竞品分析\n"
            "- 审计/代码审计：仅执行源码审计\n"
            "- 测试/系统测试：全栈系统测试\n"
            "- 稳定性测试：Playwright 600轮深度测试"
        )

    @staticmethod
    def _action_list_items(context: Dict[str, Any]) -> str:
        return "请指定要列出的内容类型（如：列出所有Agent/列出所有模型/列出所有技能）。"

    @staticmethod
    def _action_confirm(context: Dict[str, Any]) -> str:
        return "收到确认。"

    @staticmethod
    def _action_clear(context: Dict[str, Any]) -> str:
        return "上下文已清空。"

    @staticmethod
    def _action_cancel(context: Dict[str, Any]) -> str:
        return "操作已取消。"

    @staticmethod
    def _action_thanks(context: Dict[str, Any]) -> str:
        return "不客气！有需要随时找我。"

    @staticmethod
    def _action_bug_pattern(context: Dict[str, Any]) -> str:
        return "Bug模式知识库查询：请提供具体的Bug模式ID（如BP-001）或描述。"

    @staticmethod
    def _action_evolution_status(context: Dict[str, Any]) -> str:
        return "进化状态查询：请说'进化'查看详细状态。"

    @staticmethod
    def _action_get_date(context: Dict[str, Any]) -> str:
        from datetime import datetime
        now = datetime.now()
        weekdays = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        wd = weekdays[now.weekday()]
        return f"今天是 {now.strftime('%Y年%m月%d日')} {wd}"

    @staticmethod
    def _action_weather(context: Dict[str, Any]) -> str:
        return "天气查询需要外部数据源，暂时无法提供实时天气信息。"

    @staticmethod
    def _action_calculate(context: Dict[str, Any]) -> str:
        task = context.get("task", "")
        match = re.match(r"^(\d+)\s*([+\-*/])\s*(\d+)$", task.strip())
        if match:
            a, op, b = int(match.group(1)), match.group(2), int(match.group(3))
            try:
                if op == "+":
                    result = a + b
                elif op == "-":
                    result = a - b
                elif op == "*":
                    result = a * b
                elif op == "/":
                    result = a / b if b != 0 else "错误：除数不能为零"
                else:
                    result = "不支持的操作"
                return f"{a} {op} {b} = {result}"
            except Exception:
                return "计算出错"
        return "无法解析计算表达式"

    @staticmethod
    def _action_list_agents(context: Dict[str, Any]) -> str:
        return "可用Agent列表：\n1. ReactAgent - 主推理Agent\n2. OrchestratorWorkers - 多Agent编排\n3. EvolutionEngine - 进化引擎"

    @staticmethod
    def _action_list_models(context: Dict[str, Any]) -> str:
        return "模型列表请通过 /api/models 接口查询，或说'模型列表'获取详细信息。"

    @staticmethod
    def _action_list_skills(context: Dict[str, Any]) -> str:
        return "可用技能：\n- 进化/自进化：完整进化流程\n- 快速进化：跳过调研\n- 调研：技术调研\n- 竞品调研：竞品分析\n- 审计：代码审计\n- 测试：系统测试\n- 稳定性测试：深度测试"

    @staticmethod
    def _action_kappa_stats(context: Dict[str, Any]) -> str:
        return "Kappa经验包统计请通过 /api/enterprise/dispatch/kappa-stats 接口查询。"

    @staticmethod
    def _action_safety_stats(context: Dict[str, Any]) -> str:
        return "安全防护统计请通过 /api/enterprise/dispatch/safety-guard-stats 接口查询。"

    @staticmethod
    def _action_trigger_evolution(context: Dict[str, Any]) -> str:
        return "[TRIGGER:evolve] 正在启动完整进化流程..."

    @staticmethod
    def _action_trigger_quick_evolution(context: Dict[str, Any]) -> str:
        return "[TRIGGER:quick_evolve] 正在启动快速进化..."

    @staticmethod
    def _action_trigger_research(context: Dict[str, Any]) -> str:
        return "[TRIGGER:research] 正在启动技术调研..."

    @staticmethod
    def _action_trigger_competitor_research(context: Dict[str, Any]) -> str:
        return "[TRIGGER:competitor_research] 正在启动竞品调研..."

    @staticmethod
    def _action_trigger_audit(context: Dict[str, Any]) -> str:
        return "[TRIGGER:audit] 正在启动代码审计..."

    @staticmethod
    def _action_trigger_test(context: Dict[str, Any]) -> str:
        return "[TRIGGER:test] 正在启动系统测试..."

    @staticmethod
    def _action_trigger_stability_test(context: Dict[str, Any]) -> str:
        return "[TRIGGER:stability_test] 正在启动稳定性测试..."

    @staticmethod
    def _action_trigger_data_sync(context: Dict[str, Any]) -> str:
        return "[TRIGGER:data_sync] 正在启动数据飞轮同步..."

    @staticmethod
    def _action_trigger_safety_eval(context: Dict[str, Any]) -> str:
        return "[TRIGGER:safety_eval] 正在启动安全评估..."

    @staticmethod
    def _action_goodbye(context: Dict[str, Any]) -> str:
        return "再见！随时回来找我。"

    @staticmethod
    def _action_self_introduce(context: Dict[str, Any]) -> str:
        return (
            "我是 XINGZIER AI，一个具备自进化能力的智能系统。\n"
            "核心特性：\n"
            "- 三级推理架构（L0规则→L1符号→L2合成→L3 LLM）\n"
            "- 自进化引擎（V7.4，5条防偏移铁律）\n"
            "- 知识图谱 + Kappa经验包\n"
            "- 种群进化 + 代码热替换\n"
            "- 智能度量追踪"
        )

    @staticmethod
    def _action_show_capabilities(context: Dict[str, Any]) -> str:
        return (
            "我能做什么：\n"
            "🔍 信息查询：时间/日期/状态/版本/配置\n"
            "🧬 自进化：完整进化/快速进化/调研/审计\n"
            "🧪 测试：系统测试/稳定性测试/SSE流测试\n"
            "📊 度量：Token效率/规则命中率/智能指标\n"
            "🛡️ 安全：安全评估/数据同步/回滚\n"
            "💬 对话：复杂问题分析/代码生成/任务执行"
        )

    @staticmethod
    def _action_explain_architecture(context: Dict[str, Any]) -> str:
        return (
            "XINGZIER AI 架构：\n"
            "┌─────────────────────────────────────┐\n"
            "│ 用户输入                              │\n"
            "│   ↓                                   │\n"
            "│ L0 确定性规则 (60%, 0 Token, <1ms)   │\n"
            "│   ↓ 未命中                            │\n"
            "│ L1 符号推理 (25%, 少量Token, <100ms) │\n"
            "│   ↓ 未命中                            │\n"
            "│ L2 程序合成 (10%, 中等Token, <5s)    │\n"
            "│   ↓ 未命中                            │\n"
            "│ L3 LLM调用 (5%, 大量Token, 秒级)     │\n"
            "│   ↓                                   │\n"
            "│ 输出                                  │\n"
            "└─────────────────────────────────────┘"
        )

    @staticmethod
    def _action_explain_reasoning_tiers(context: Dict[str, Any]) -> str:
        return (
            "三级推理架构（V7.4铁律18）：\n"
            "L0 确定性规则：正则匹配+动作分发，0 Token\n"
            "L1 符号推理：Kappa经验包+知识图谱推导，0 Token\n"
            "L2 程序合成：ExecutableSkill执行，0 Token\n"
            "L3 LLM调用：仅L0/L1/L2全部未命中时触发\n"
            "目标分布：L0:60% + L1:25% + L2:10% + L3:5%"
        )

    @staticmethod
    def _action_explain_iron_laws(context: Dict[str, Any]) -> str:
        return (
            "V7.4 防偏移铁律（源自AGI白皮书）：\n"
            "16. LLM调用递减原则\n"
            "17. 经验可执行化原则\n"
            "18. 规则内化优先原则\n"
            "19. 进化方向校验原则\n"
            "20. 智能度量原则\n"
            "核心论点：真正的智能不是调用更强的LLM，而是让系统越来越不需要调用LLM。"
        )

    @staticmethod
    def _action_show_competitor_gaps(context: Dict[str, Any]) -> str:
        return "竞品差距追踪请通过 state.json 的 competitor_gaps 查看，或说'竞品调研'获取最新分析。"

    @staticmethod
    def _action_show_intelligence_metrics(context: Dict[str, Any]) -> str:
        return (
            "智能度量（V7.4铁律20）：\n"
            "1. 技能获取效率：解决新问题所需交互次数\n"
            "2. Token效率：每任务Token消耗\n"
            "3. 规则命中率：L0+L1占总推理比例\n"
            "4. 零样本解决率：未见任务首次成功率\n"
            "详细数据请通过 /api/enterprise/dispatch/evolution-metrics 查看。"
        )

    @staticmethod
    def _action_emergency_stop(context: Dict[str, Any]) -> str:
        return "[EMERGENCY_STOP] 所有进化活动已停止。"

    @staticmethod
    def _action_rollback(context: Dict[str, Any]) -> str:
        return "[ROLLBACK] 回滚请求已记录。请通过 /api/enterprise/dispatch/dispatch-rollback 执行。"

    @staticmethod
    def _action_show_config(context: Dict[str, Any]) -> str:
        return "当前配置请通过 /api/version 和 state.json 查看。"

    @staticmethod
    def _action_show_recent_log(context: Dict[str, Any]) -> str:
        return "最近日志请查看 ~/.xingzierai/ 目录下的日志文件。"

    @staticmethod
    def _action_show_memory_usage(context: Dict[str, Any]) -> str:
        try:
            import psutil
            mem = psutil.virtual_memory()
            return f"内存使用：{mem.percent}% ({mem.used // 1024 // 1024}MB / {mem.total // 1024 // 1024}MB)"
        except ImportError:
            return "内存查询需要 psutil 库。"

    @staticmethod
    def _action_show_disk_usage(context: Dict[str, Any]) -> str:
        try:
            import psutil
            disk = psutil.disk_usage("/")
            return f"磁盘使用：{disk.percent}% ({disk.used // 1024 // 1024 // 1024}GB / {disk.total // 1024 // 1024 // 1024}GB)"
        except ImportError:
            return "磁盘查询需要 psutil 库。"

    @staticmethod
    def _action_show_network_status(context: Dict[str, Any]) -> str:
        return "网络状态：服务运行在 8565(后端) / 8555(前端) / 8580(Daemon) 端口。"

    @staticmethod
    def _action_show_process_info(context: Dict[str, Any]) -> str:
        import os
        return f"当前进程 PID: {os.getpid()}"

    @staticmethod
    def _action_show_environment(context: Dict[str, Any]) -> str:
        import sys
        import platform
        return f"Python {sys.version.split()[0]} | {platform.system()} {platform.release()} | {platform.machine()}"

    @staticmethod
    def _action_list_api_endpoints(context: Dict[str, Any]) -> str:
        return (
            "主要API端点：\n"
            "- GET /api/version\n"
            "- GET /api/agents\n"
            "- GET /api/models\n"
            "- GET /api/enterprise/dispatch/evolution-metrics\n"
            "- GET /api/enterprise/dispatch/safety-guard-stats\n"
            "- GET /api/enterprise/dispatch/kappa-stats\n"
            "- POST /api/enterprise/dispatch/bridge-sync"
        )

    @staticmethod
    def _action_show_token_economics(context: Dict[str, Any]) -> str:
        return "Token经济追踪请通过 /api/enterprise/dispatch/evolution-metrics 查看。"

    @staticmethod
    def _action_show_feature_flags(context: Dict[str, Any]) -> str:
        return "功能开关配置请查看项目配置文件。"

    @staticmethod
    def _action_show_deployment_info(context: Dict[str, Any]) -> str:
        return "部署信息请通过 /api/version 和 CHANGELOG.md 查看。"

    @staticmethod
    def _action_show_changelog(context: Dict[str, Any]) -> str:
        return "变更日志请查看 CHANGELOG.md 文件。"

    @staticmethod
    def _action_show_kg_status(context: Dict[str, Any]) -> str:
        return "知识图谱状态：基于Graphify的RAG子图检索系统，Token消耗降低71.5倍。"

    @staticmethod
    def _action_show_population_status(context: Dict[str, Any]) -> str:
        return "种群进化状态：基于DGM(ICLR 2026)的多种群并行进化引擎，最多200个变体。"

    @staticmethod
    def _action_show_local_model_status(context: Dict[str, Any]) -> str:
        return "本地模型状态：LocalModelDispatcher自动训练小模型，SmartLLMClient三级模型优先级。"

    @staticmethod
    def _action_repeat_last(context: Dict[str, Any]) -> str:
        return "重复功能需要上下文支持，暂不可用。"

    @staticmethod
    def _action_acknowledge_affirm(context: Dict[str, Any]) -> str:
        return "好的，收到！有什么需要我帮忙的吗？"

    @staticmethod
    def _action_acknowledge_negate(context: Dict[str, Any]) -> str:
        return "了解，请告诉我您想要什么。"

    @staticmethod
    def _action_accept_compliment(context: Dict[str, Any]) -> str:
        return "谢谢认可！我会继续努力提供更好的服务。"

    @staticmethod
    def _action_handle_complaint(context: Dict[str, Any]) -> str:
        return "抱歉给您带来不好的体验，我会记录您的反馈并持续改进。请具体描述遇到的问题，我会尽力解决。"

    @staticmethod
    def _action_switch_language_en(context: Dict[str, Any]) -> str:
        return "Switched to English mode. How can I help you?"

    @staticmethod
    def _action_switch_language_cn(context: Dict[str, Any]) -> str:
        return "已切换到中文模式。有什么可以帮您的吗？"

    @staticmethod
    def _action_summarize_hint(context: Dict[str, Any]) -> str:
        return "请提供需要总结的内容，我会为您提取要点。"

    @staticmethod
    def _action_translate_hint(context: Dict[str, Any]) -> str:
        return "请提供需要翻译的文本和目标语言，我会为您翻译。"

    @staticmethod
    def _action_code_explain_hint(context: Dict[str, Any]) -> str:
        return "请提供需要解释的代码片段，我会为您分析其功能和逻辑。"

    @staticmethod
    def _action_debug_hint(context: Dict[str, Any]) -> str:
        return "请提供报错信息和相关代码，我会帮您定位问题并提供修复建议。"

    @staticmethod
    def _action_emoji_greeting_reply(context: Dict[str, Any]) -> str:
        return "👋 你好！有什么可以帮你的吗？"

    @staticmethod
    def _action_emoji_thanks_reply(context: Dict[str, Any]) -> str:
        return "😊 不客气！随时为你效劳。"

    @staticmethod
    def _action_search_hint(context: Dict[str, Any]) -> str:
        return "请告诉我您要搜索的内容，我会帮您查找相关信息。"

    @staticmethod
    def _action_compare_hint(context: Dict[str, Any]) -> str:
        return "请提供需要对比的两个或多个对象，我会为您分析差异和优劣。"

    @staticmethod
    def _action_list_hint(context: Dict[str, Any]) -> str:
        return "请告诉我您需要列举的内容类型，我会为您整理清单。"

    @staticmethod
    def _action_explain_hint(context: Dict[str, Any]) -> str:
        return "请提供需要解释的概念或术语，我会为您详细说明。"

    @staticmethod
    def _action_write_hint(context: Dict[str, Any]) -> str:
        return "请描述您需要编写的内容类型和要求，我会为您起草。"

    @staticmethod
    def _action_optimize_hint(context: Dict[str, Any]) -> str:
        return "请提供需要优化的代码或系统描述，我会给出改进建议。"

    @staticmethod
    def _action_test_hint(context: Dict[str, Any]) -> str:
        return "请提供需要测试的代码或功能描述，我会帮您设计测试方案。"

    @staticmethod
    def _action_deploy_hint(context: Dict[str, Any]) -> str:
        return "请描述您的部署需求和环境，我会提供部署方案建议。"

    @staticmethod
    def _action_security_hint(context: Dict[str, Any]) -> str:
        return "请描述您的安全需求或关注点，我会提供安全建议和最佳实践。"

    @staticmethod
    def _action_performance_hint(context: Dict[str, Any]) -> str:
        return "请描述性能瓶颈或优化目标，我会提供性能分析和优化建议。"

    @staticmethod
    def _action_data_hint(context: Dict[str, Any]) -> str:
        return "请描述您的数据处理需求，我会提供方案建议。"

    @staticmethod
    def _action_api_hint(context: Dict[str, Any]) -> str:
        return "请描述您的API设计或调用需求，我会提供接口方案建议。"

    @staticmethod
    def _action_config_hint(context: Dict[str, Any]) -> str:
        return "请描述您的配置需求，我会提供配置方案建议。"


def create_reasoning_router(
    knowledge_graph=None,
    kappa_engine=None,
    skill_manager=None,
    bug_pattern_kb=None,
    custom_rules: Optional[List[RuntimeRule]] = None,
) -> ReasoningRouter:
    """Factory function to create a ReasoningRouter with optional dependencies."""
    return ReasoningRouter(
        knowledge_graph=knowledge_graph,
        kappa_engine=kappa_engine,
        skill_manager=skill_manager,
        bug_pattern_kb=bug_pattern_kb,
        custom_rules=custom_rules,
    )
