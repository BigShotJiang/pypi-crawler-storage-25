# -*- coding: utf-8 -*-
# pylint: disable=too-many-branches
"""Memory Manager for XINGZIER AI agents.

Extends ReMeLight to provide memory management capabilities including:
- Message compaction with configurable ratio
- Memory summarization with tool support
- Vector and full-text search integration
- Embedding configuration from environment variables
"""
import json
import logging
import os
import platform
import uuid
from pathlib import Path

from xingzierai.agentscope_core.formatter import FormatterBase
from xingzierai.agentscope_core.message import Msg, TextBlock
from xingzierai.agentscope_core.model import ChatModelBase
from xingzierai.agentscope_core.tool import Toolkit, ToolResponse

from xingzierai.agents.model_factory import create_model_and_formatter
from xingzierai.agents.tools import read_file, write_file, edit_file
from xingzierai.agents.utils import get_xingzierai_token_counter
from xingzierai.config import load_config
from xingzierai.config.config import load_agent_config

logger = logging.getLogger(__name__)

# Try to import reme, log warning if it fails
try:
    from xingzierai.reme_sdk.reme.reme_light import ReMeLight

    _REME_AVAILABLE = True

except ImportError as e:
    _REME_AVAILABLE = False
    logger.warning(f"reme package not installed. {e}")

    class ReMeLight:  # type: ignore
        """Placeholder when reme is not available."""

        async def start(self) -> None:
            """No-op start when reme is unavailable."""

        def get_in_memory_memory(self, **kwargs):
            """No-op when reme is unavailable."""
            return None


class MemoryManager(ReMeLight):
    """Memory manager that extends ReMeLight for XINGZIER AI agents.

    This class provides memory management capabilities including:
    - Memory compaction for long conversations via compact_memory()
    - Memory summarization with file operation tools via summary_memory()
    - In-memory memory retrieval via get_in_memory_memory()
    - Configurable vector search and full-text search backends
    """

    def __init__(
        self,
        working_dir: str,
        agent_id: str,
    ):
        """Initialize MemoryManager with ReMeLight configuration.

        Args:
            working_dir: Working directory path for memory storage
            agent_id: Agent ID for loading configuration

        Embedding Config:
            api_key, base_url, model_name: config > env var > default
            Other params: from embedding_config only

        Environment Variables:
            EMBEDDING_API_KEY: API key (fallback if not in config)
            EMBEDDING_BASE_URL: Base URL (fallback if not in config)
            EMBEDDING_MODEL_NAME: Model name (fallback if not in config)
            FTS_ENABLED: Enable full-text search (default: true)
            MEMORY_STORE_BACKEND: Memory backend
            - auto/local/chroma (default: auto)

        Note:
            Vector search requires api_key, base_url, and model_name.
        """
        # Extract configuration from agent_config
        self.agent_id: str = agent_id
        self._initialized: bool = False

        if not _REME_AVAILABLE:
            logger.warning(
                "reme package not available, memory features will be limited",
            )
            return

        # Get embedding config (supports hot-reload)
        emb_config = self.get_embedding_config()

        # Determine if vector search should be enabled based on configuration
        # Vector search requires base_url and model_name
        vector_enabled = bool(emb_config["base_url"]) and bool(
            emb_config["model_name"],
        )

        # Log embedding config (mask api_key for security)
        log_cfg = {
            **emb_config,
            "api_key": self.mask_key(emb_config["api_key"]),
        }
        logger.info(
            f"Embedding config: {log_cfg}, vector_enabled={vector_enabled}",
        )

        # When api_key is still empty after all fallbacks, check if the
        # base_url points to a free provider that does not require
        # authentication.  For such providers, inject a placeholder so
        # that ReMeLight can still initialize.
        if not emb_config.get("api_key"):
            base = emb_config.get("base_url", "")
            free_provider_patterns = [
                "opencode.ai",
                "localhost",
                "127.0.0.1",
                "0.0.0.0",
            ]
            if any(p in base for p in free_provider_patterns):
                emb_config["api_key"] = "not-required"
                logger.info(
                    "Embedding api_key set to placeholder for free "
                    "provider (%s)",
                    base,
                )
            else:
                logger.warning(
                    "Embedding api_key is empty, skipping ReMeLight "
                    "initialization. Memory features (compaction, vector "
                    "search) will be disabled. Configure api_key in "
                    "agent.json, set EMBEDDING_API_KEY environment "
                    "variable, or configure an LLM provider with an "
                    "api_key to enable memory features.",
                )
                return

        # Check if full-text search (FTS) is enabled via environment variable
        fts_enabled = os.environ.get("FTS_ENABLED", "true").lower() == "true"

        # Determine the memory store backend to use
        # "auto" selects based on platform
        # (local for Windows, chroma otherwise)
        memory_store_backend = os.environ.get("MEMORY_STORE_BACKEND", "auto")
        if memory_store_backend == "auto":
            memory_backend = (
                "local" if platform.system() == "Windows" else "chroma"
            )
        else:
            memory_backend = memory_store_backend

        # Initialize parent ReMeXingzierAI class
        super().__init__(
            working_dir=working_dir,
            default_embedding_model_config=emb_config,
            default_file_store_config={
                "backend": memory_backend,
                "store_name": "xingzierai",
                "vector_enabled": vector_enabled,
                "fts_enabled": fts_enabled,
            },
        )

        self.summary_toolkit = Toolkit()
        self.summary_toolkit.register_tool_function(read_file)
        self.summary_toolkit.register_tool_function(write_file)
        self.summary_toolkit.register_tool_function(edit_file)

        self.chat_model: ChatModelBase | None = None
        self.formatter: FormatterBase | None = None
        self._initialized: bool = True

    async def start(self) -> None:
        """Start the MemoryManager service.

        Safely handles the case where __init__ skipped ReMeLight
        initialization due to missing credentials.
        """
        if not getattr(self, "_initialized", False):
            logger.warning(
                "MemoryManager not initialized, skipping start. "
                "This usually means embedding api_key was empty.",
            )
            return
        try:
            await super().start()
        except Exception as e:
            logger.warning(
                f"MemoryManager.start() failed: {e}. "
                f"Memory features will be disabled.",
            )

    @staticmethod
    def mask_key(key: str) -> str:
        """Mask API key, showing first 5 chars and masking rest with *."""
        if not key:
            return ""
        if len(key) <= 5:
            return key
        return key[:5] + "*" * (len(key) - 5)

    def get_embedding_config(self) -> dict:
        """Get embedding config. Priority: config > env var > active provider > default."""
        cfg = load_agent_config(self.agent_id).running.embedding_config

        api_key = cfg.api_key or os.getenv("EMBEDDING_API_KEY", "")
        base_url = cfg.base_url or os.getenv("EMBEDDING_BASE_URL", "")
        model_name = cfg.model_name or os.getenv("EMBEDDING_MODEL_NAME", "")

        if not api_key or not base_url:
            inherited = self._inherit_from_active_provider()
            if not api_key and inherited.get("api_key"):
                api_key = inherited["api_key"]
                logger.info(
                    "Embedding api_key inherited from active LLM provider",
                )
            if not base_url and inherited.get("base_url"):
                base_url = inherited["base_url"]
                logger.info(
                    "Embedding base_url inherited from active LLM provider",
                )
            if not model_name and inherited.get("model_name"):
                model_name = inherited["model_name"]
                logger.info(
                    "Embedding model_name set to default: %s",
                    inherited["model_name"],
                )

        return {
            "backend": cfg.backend,
            "api_key": api_key,
            "base_url": base_url,
            "model_name": model_name,
            "dimensions": cfg.dimensions,
            "enable_cache": cfg.enable_cache,
            "use_dimensions": cfg.use_dimensions,
            "max_cache_size": cfg.max_cache_size,
            "max_input_length": cfg.max_input_length,
            "max_batch_size": cfg.max_batch_size,
        }

    @staticmethod
    def _inherit_from_active_provider() -> dict:
        """Try to inherit embedding credentials from the active LLM provider.

        When the user has already configured an LLM provider (e.g. OpenAI,
        DeepSeek, etc.) with an api_key and base_url, those same credentials
        can typically be used for the embedding endpoint as well.  This
        eliminates the need for a separate embedding configuration for the
        majority of users.

        Returns:
            A dict with keys ``api_key``, ``base_url``, ``model_name``
            (values may be empty strings if inheritance fails).
        """
        result = {"api_key": "", "base_url": "", "model_name": ""}
        try:
            from xingzierai.providers import ProviderManager

            manager = ProviderManager.get_instance()
            active_model = manager.get_active_model()
            if not active_model or not active_model.provider_id:
                return result

            provider = manager.get_provider(active_model.provider_id)
            if provider is None:
                return result

            if provider.api_key:
                result["api_key"] = provider.api_key
            if provider.base_url:
                result["base_url"] = provider.base_url

            provider_id = active_model.provider_id.lower()
            default_models = {
                "openai": "text-embedding-3-small",
                "deepseek": "text-embedding-3-small",
                "dashscope": "text-embedding-v3",
                "zhipu": "embedding-3",
                "moonshot": "text-embedding-3-small",
                "siliconflow": "BAAI/bge-large-zh-v1.5",
                "modelscope": "text-embedding-v3",
            }
            for key, default_model in default_models.items():
                if key in provider_id:
                    result["model_name"] = default_model
                    break
            else:
                result["model_name"] = "text-embedding-3-small"

        except Exception as e:
            logger.debug(
                f"Could not inherit embedding config from active provider: {e}",
            )

        return result

    def prepare_model_formatter(self) -> None:
        """Prepare and initialize the chat model and formatter.

        Lazily initializes the chat_model and formatter attributes if they
        haven't been set yet. This method is called before compaction or
        summarization operations that require model access.

        Note:
            Logs a warning if the model and formatter are not already
            initialized, as this indicates a potential configuration issue.
        """
        if self.chat_model is None or self.formatter is None:
            logger.warning("Model and formatter not initialized.")
            chat_model, formatter = create_model_and_formatter(self.agent_id)
            if self.chat_model is None:
                self.chat_model = chat_model
            if self.formatter is None:
                self.formatter = formatter

    async def restart_embedding_model(self):
        """Restart the embedding model with current config."""
        emb_config = self.get_embedding_config()
        restart_config = {
            "embedding_models": {
                "default": emb_config,
            },
        }
        await self.restart(restart_config=restart_config)

    async def check_context(
        self,
        messages: list[Msg],
        memory_compact_threshold: int,
        memory_compact_reserve: int,
        as_token_counter=None,
    ) -> tuple[list[Msg], str, bool]:
        """Check if context exceeds the compaction threshold.

        Args:
            messages: List of Msg objects to check
            memory_compact_threshold: Token threshold to trigger compaction
            memory_compact_reserve: Token reserve to keep after compaction
            as_token_counter: Token counter instance

        Returns:
            Tuple of (messages_to_compact, summary, is_valid)
        """
        if not messages:
            return [], "", True

        if as_token_counter is None:
            agent_config = load_agent_config(self.agent_id)
            as_token_counter = get_xingzierai_token_counter(agent_config)

        total_tokens = 0
        for msg in messages:
            try:
                text_content = msg.get_text_content() or ""
                if text_content:
                    msg_tokens = await as_token_counter.count(
                        messages=[], text=text_content,
                    )
                    total_tokens += msg_tokens
            except Exception as _token_err:
                logger.debug("Token counting fallback used: %s", _token_err)
                total_tokens += len(str(msg.content or "")) // 4

        if total_tokens < memory_compact_threshold:
            return [], "", True

        logger.info(
            "check_context: total_tokens=%d exceeds threshold=%d, "
            "compaction needed (reserve=%d)",
            total_tokens,
            memory_compact_threshold,
            memory_compact_reserve,
        )

        messages_to_compact = list(messages)
        is_valid = True

        return messages_to_compact, "", is_valid

    async def compact_memory(
        self,
        messages: list[Msg],
        previous_summary: str = "",
        **_kwargs,
    ) -> str:
        """Compact a list of messages into a condensed summary.

        Args:
            messages: List of Msg objects to compact
            previous_summary: Optional previous summary to incorporate
            **_kwargs: Additional keyword arguments (ignored)

        Returns:
            str: Condensed summary of the messages, empty string if invalid
        """
        if not self._initialized:
            logger.warning("MemoryManager not initialized, skipping compact_memory")
            return ""

        self.prepare_model_formatter()

        agent_config = load_agent_config(self.agent_id)
        token_counter = get_xingzierai_token_counter(agent_config)
        add_thinking_block = agent_config.running.compact_with_thinking_block
        workspace_dir = agent_config.workspace_dir or "/tmp"

        result = await super().compact_memory(
            messages=messages,
            as_llm=self.chat_model,
            as_llm_formatter=self.formatter,
            as_token_counter=token_counter,
            language=agent_config.language,
            max_input_length=agent_config.running.max_input_length,
            compact_ratio=agent_config.running.memory_compact_ratio,
            previous_summary=previous_summary,
            return_dict=True,
            add_thinking_block=add_thinking_block,
        )

        # Handle unexpected str return (should be dict)
        if isinstance(result, str):
            logger.error(
                f"compact_memory returned str instead of dict, "
                f"result: {result[:200]}... "
                "Please install the latest reme package.",
            )
            return result

        # result is dict
        is_valid: bool = result.get("is_valid", True)
        if not is_valid:
            # Save invalid result to file
            unique_id = uuid.uuid4().hex[:8]
            filename = f"compact_invalid_{unique_id}.json"
            filepath = os.path.join(workspace_dir, filename)

            try:
                tmp = Path(filepath + ".tmp")
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
                tmp.replace(Path(filepath))
                logger.error(
                    f"Invalid compact result saved to {filepath}. "
                    f"user_msg: {result.get('user_message', '')[:200]}..., "
                    "history_compact: "
                    f"{result.get('history_compact', '')[:200]}...",
                )
                logger.error(
                    "Please upload the log to the community: "
                    "https://github.com/agentscope-ai/XINGZIER AI/issues",
                )
            except Exception as _e:
                logger.error(f"Failed to save invalid compact result: {_e}")

            return ""

        return result.get("history_compact", "")

    def add_async_summary_task(self, messages: list[Msg]) -> None:
        """Queue messages for async summary data collection.

        This is a lightweight hook that collects compaction I/O as training
        data for future local model fine-tuning. It does NOT block the
        compaction flow — failures are silently ignored.

        Args:
            messages: List of Msg objects that were compacted.
        """
        try:
            from ..local_model_dispatcher import LocalModelDispatcher
            dispatcher = LocalModelDispatcher.get_instance()
            input_text = "\n".join(
                f"{getattr(m, 'role', '?')}: {getattr(m, 'get_text_content', lambda: '')()[:200]}"
                for m in messages[:20]
            )
            if input_text.strip():
                dispatcher.collect_training_data(
                    task_type="memory_compact",
                    input_text=input_text,
                    output_text="[summary_task]",
                )
        except Exception as _task_err:
            logger.debug("add_async_summary_task skipped: %s", _task_err)

    async def compact_tool_result(
        self,
        messages: list[Msg],
        recent_n: int = 1,
        old_threshold: int = 1000,
        recent_threshold: int = 30000,
        retention_days: int = 3,
    ) -> None:
        """Compact tool results in messages by truncating long outputs.

        Args:
            messages: List of Msg objects to process
            recent_n: Number of recent messages to use recent_threshold for
            old_threshold: Character threshold for old messages
            recent_threshold: Character threshold for recent messages
            retention_days: Number of days to retain tool result files
        """
        from datetime import datetime, timezone
        import copy

        now = datetime.now(timezone.utc)
        total_messages = len(messages)

        for i, msg in enumerate(messages):
            is_recent = (total_messages - i) <= recent_n
            threshold = recent_threshold if is_recent else old_threshold

            content = getattr(msg, "content", None)
            if not content or not isinstance(content, list):
                continue

            new_content = []
            for block in content:
                if not isinstance(block, dict):
                    new_content.append(block)
                    continue
                if block.get("type") != "tool_result":
                    new_content.append(block)
                    continue

                result_text = block.get("content", "")
                if isinstance(result_text, str) and len(result_text) > threshold:
                    new_block = copy.copy(block)
                    truncated = result_text[:threshold]
                    new_block["content"] = (
                        truncated
                        + f"\n\n... [truncated, original length: {len(result_text)} chars]"
                    )
                    new_content.append(new_block)
                else:
                    new_content.append(block)

            if new_content != content:
                msg.content = new_content

    async def summary_memory(self, messages: list[Msg], **_kwargs) -> str:
        """Generate a comprehensive summary of the given messages.

        Uses file operation tools (read_file, write_file, edit_file) to support
        the summarization process.

        Args:
            messages: List of Msg objects to summarize
            **_kwargs: Additional keyword arguments (ignored)

        Returns:
            str: Comprehensive summary of the messages
        """
        if not self._initialized:
            logger.warning("MemoryManager not initialized, skipping summary_memory")
            return ""
        self.prepare_model_formatter()

        agent_config = load_agent_config(self.agent_id)
        token_counter = get_xingzierai_token_counter(agent_config)
        add_thinking_block = agent_config.running.compact_with_thinking_block
        user_tz = load_config().user_timezone or None

        return await super().summary_memory(
            messages=messages,
            as_llm=self.chat_model,
            as_llm_formatter=self.formatter,
            as_token_counter=token_counter,
            toolkit=self.summary_toolkit,
            language=agent_config.language,
            max_input_length=agent_config.running.max_input_length,
            compact_ratio=agent_config.running.memory_compact_ratio,
            timezone=user_tz,
            add_thinking_block=add_thinking_block,
        )

    async def memory_search(
        self,
        query: str,
        max_results: int = 5,
        min_score: float = 0.1,
    ) -> ToolResponse:
        """Search through stored memories for relevant content.

        Performs a search across the memory store using vector similarity
        and/or full-text search depending on configuration.

        Args:
            query: The search query string
            max_results: Maximum number of results to return (default: 5)
            min_score: Minimum relevance score threshold (default: 0.1)

        Returns:
            ToolResponse containing the search results as TextBlock content,
            or an error message if ReMe has not been started.
        """
        if not self._initialized:
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text="Memory manager not initialized (missing API key). "
                        "Configure embedding api_key to enable memory search.",
                    ),
                ],
            )
        if not getattr(self, '_started', False):
            return ToolResponse(
                content=[
                    TextBlock(
                        type="text",
                        text="ReMe is not started, report github issue!",
                    ),
                ],
            )

        return await super().memory_search(
            query=query,
            max_results=max_results,
            min_score=min_score,
        )

    def get_in_memory_memory(self, **_kwargs):
        """Retrieve in-memory memory content.

        Args:
            **_kwargs: Additional keyword arguments (passed to parent)

        Returns:
            The in-memory memory content with token counting support,
            or None if MemoryManager was not fully initialized.
        """
        if not self._initialized:
            return None

        agent_config = load_agent_config(self.agent_id)
        token_counter = get_xingzierai_token_counter(agent_config)

        return super().get_in_memory_memory(
            as_token_counter=token_counter,
        )
