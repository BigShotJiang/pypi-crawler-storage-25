# -*- coding: utf-8 -*-
"""Cross-Agent Mutual Verification - Breaking self-referential loops.

Inspired by Godel's Incompleteness Theorem:
- A single formal system cannot prove its own consistency
- Different formal systems can verify each other
- Cross-agent verification breaks the self-referential loop

When Agent A and Agent B disagree, HumanOracle serves as the
final arbiter - the "outside observer" that Godel's theorem requires.
"""

from __future__ import annotations

import json
import logging
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_CROSS_VERIFY_DIR = Path.home() / ".xingzierai" / "cross_verification"


class VerificationVerdict(str, Enum):
    AGREE = "agree"
    DISAGREE = "disagree"
    UNCERTAIN = "uncertain"


class DisputeResolution(str, Enum):
    AGENT_A_CORRECT = "agent_a_correct"
    AGENT_B_CORRECT = "agent_b_correct"
    BOTH_WRONG = "both_wrong"
    BOTH_PARTIALLY_CORRECT = "both_partially_correct"
    PENDING = "pending"


@dataclass
class VerificationPair:
    verifier_agent: str
    subject_agent: str
    subject_output: str
    verifier_verdict: str
    verifier_confidence: float = 0.0
    verifier_reasoning: str = ""
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "verifier_agent": self.verifier_agent,
            "subject_agent": self.subject_agent,
            "verifier_verdict": self.verifier_verdict,
            "verifier_confidence": round(self.verifier_confidence, 4),
            "verifier_reasoning": self.verifier_reasoning[:200],
            "timestamp": self.timestamp,
        }


@dataclass
class DisputeRecord:
    dispute_id: str
    agent_a: str
    agent_b: str
    agent_a_verdict: str
    agent_b_verdict: str
    subject: str
    resolution: DisputeResolution = DisputeResolution.PENDING
    resolved_by: str = ""
    resolution_note: str = ""
    created_at: float = field(default_factory=time.time)
    resolved_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "dispute_id": self.dispute_id,
            "agent_a": self.agent_a,
            "agent_b": self.agent_b,
            "agent_a_verdict": self.agent_a_verdict,
            "agent_b_verdict": self.agent_b_verdict,
            "resolution": self.resolution.value,
            "resolved_by": self.resolved_by,
            "created_at": self.created_at,
        }


@dataclass
class CrossVerifyStats:
    total_verifications: int = 0
    agreements: int = 0
    disagreements: int = 0
    uncertain: int = 0
    disputes_resolved: int = 0
    disputes_pending: int = 0
    consistency_rate: float = 0.0
    dispute_type_distribution: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_verifications": self.total_verifications,
            "agreements": self.agreements,
            "disagreements": self.disagreements,
            "uncertain": self.uncertain,
            "disputes_resolved": self.disputes_resolved,
            "disputes_pending": self.disputes_pending,
            "consistency_rate": round(self.consistency_rate, 4),
            "dispute_type_distribution": self.dispute_type_distribution,
        }


class CrossVerifier:
    """Cross-agent mutual verification to break self-referential loops.

    Usage:
        cv = CrossVerifier()

        # Agent A verifies Agent B's output
        pair = cv.verify(agent_a="agent_1", agent_b="agent_2",
                         subject="output_123", verdict_a="approve",
                         verdict_b="reject", confidence_a=0.9, confidence_b=0.8)

        # If disagreement, escalate to human oracle
        if pair.verdict == VerificationVerdict.DISAGREE:
            cv.escalate_to_human(dispute)
    """

    def __init__(self, verify_dir: Optional[str] = None):
        self._dir = Path(verify_dir) if verify_dir else _CROSS_VERIFY_DIR
        self._pairs: List[VerificationPair] = []
        self._disputes: Dict[str, DisputeRecord] = {}
        self._stats = CrossVerifyStats()
        self._agent_reliability: Dict[str, Dict[str, float]] = defaultdict(
            lambda: {"correct": 0, "total": 0, "reliability": 0.5}
        )
        self._load()

    def verify(
        self,
        agent_a: str,
        agent_b: str,
        subject: str,
        verdict_a: str,
        verdict_b: str,
        confidence_a: float = 1.0,
        confidence_b: float = 1.0,
        reasoning_a: str = "",
        reasoning_b: str = "",
    ) -> VerificationVerdict:
        """Perform cross-verification between two agents.

        Args:
            agent_a: First agent's ID
            agent_b: Second agent's ID
            subject: Subject being verified (output ID, etc.)
            verdict_a: Agent A's verdict on the subject
            verdict_b: Agent B's verdict on the subject
            confidence_a: Agent A's confidence
            confidence_b: Agent B's confidence
            reasoning_a: Agent A's reasoning
            reasoning_b: Agent B's reasoning

        Returns:
            VerificationVerdict indicating agreement status
        """
        self._stats.total_verifications += 1

        pair_a = VerificationPair(
            verifier_agent=agent_a,
            subject_agent=agent_b,
            subject_output=subject,
            verifier_verdict=verdict_a,
            verifier_confidence=confidence_a,
            verifier_reasoning=reasoning_a,
        )
        pair_b = VerificationPair(
            verifier_agent=agent_b,
            subject_agent=agent_a,
            subject_output=subject,
            verifier_verdict=verdict_b,
            verifier_confidence=confidence_b,
            verifier_reasoning=reasoning_b,
        )
        self._pairs.extend([pair_a, pair_b])

        if verdict_a == verdict_b:
            self._stats.agreements += 1
            result = VerificationVerdict.AGREE
        elif self._is_compatible(verdict_a, verdict_b):
            self._stats.uncertain += 1
            result = VerificationVerdict.UNCERTAIN
        else:
            self._stats.disagreements += 1
            result = VerificationVerdict.DISAGREE
            self._create_dispute(
                agent_a, agent_b, verdict_a, verdict_b, subject,
            )

        self._update_consistency_rate()
        self._save()
        return result

    def escalate_to_human(self, dispute_id: str) -> Optional[Any]:
        """Escalate a dispute to HumanOracle for final arbitration.

        Args:
            dispute_id: The dispute ID to escalate

        Returns:
            HumanOracle request if created, None otherwise
        """
        dispute = self._disputes.get(dispute_id)
        if dispute is None:
            return None

        try:
            from xingzierai.agents.human_oracle import get_human_oracle
            oracle = get_human_oracle()
            return oracle.should_request_human_review(
                subject_type="cross_verification",
                subject_id=dispute_id,
                confidence=0.0,
                is_core_module=False,
            )
        except Exception as e:
            logger.debug("Failed to escalate to human oracle: %s", e)
            return None

    def resolve_dispute(
        self,
        dispute_id: str,
        resolution: DisputeResolution,
        resolved_by: str = "human",
        note: str = "",
    ) -> Optional[DisputeRecord]:
        """Resolve a dispute with a final verdict.

        Args:
            dispute_id: The dispute ID
            resolution: The resolution verdict
            resolved_by: Who resolved it
            note: Optional note

        Returns:
            Updated DisputeRecord
        """
        dispute = self._disputes.get(dispute_id)
        if dispute is None:
            return None

        dispute.resolution = resolution
        dispute.resolved_by = resolved_by
        dispute.resolution_note = note
        dispute.resolved_at = time.time()

        self._stats.disputes_resolved += 1
        self._stats.disputes_pending -= 1

        self._update_agent_reliability(dispute, resolution)
        self._save()
        return dispute

    def get_disputes(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get disputes, optionally filtered by status."""
        results = []
        for d in self._disputes.values():
            if status is None or d.resolution.value == status:
                results.append(d.to_dict())
        return results

    def get_stats(self) -> Dict[str, Any]:
        return self._stats.to_dict()

    def get_agent_reliability(self, agent_id: str) -> Dict[str, float]:
        return dict(self._agent_reliability.get(agent_id, {
            "correct": 0, "total": 0, "reliability": 0.5,
        }))

    def _is_compatible(self, verdict_a: str, verdict_b: str) -> bool:
        compatible_pairs = {
            ("approve", "needs_revision"),
            ("needs_revision", "approve"),
            ("approve", "uncertain"),
            ("uncertain", "approve"),
        }
        return (verdict_a, verdict_b) in compatible_pairs

    def _create_dispute(
        self,
        agent_a: str,
        agent_b: str,
        verdict_a: str,
        verdict_b: str,
        subject: str,
    ) -> None:
        dispute_id = f"dispute_{int(time.time())}_{hash(subject) % 10000:04d}"
        dispute = DisputeRecord(
            dispute_id=dispute_id,
            agent_a=agent_a,
            agent_b=agent_b,
            agent_a_verdict=verdict_a,
            agent_b_verdict=verdict_b,
            subject=subject,
        )
        self._disputes[dispute_id] = dispute
        self._stats.disputes_pending += 1

        dispute_type = f"{verdict_a}_vs_{verdict_b}"
        self._stats.dispute_type_distribution[dispute_type] = (
            self._stats.dispute_type_distribution.get(dispute_type, 0) + 1
        )

    def _update_consistency_rate(self) -> None:
        total = self._stats.agreements + self._stats.disagreements + self._stats.uncertain
        if total > 0:
            self._stats.consistency_rate = self._stats.agreements / total

    def _update_agent_reliability(
        self, dispute: DisputeRecord, resolution: DisputeResolution,
    ) -> None:
        for agent_id, verdict in [
            (dispute.agent_a, dispute.agent_a_verdict),
            (dispute.agent_b, dispute.agent_b_verdict),
        ]:
            rel = self._agent_reliability[agent_id]
            rel["total"] += 1

            if resolution == DisputeResolution.AGENT_A_CORRECT and agent_id == dispute.agent_a:
                rel["correct"] += 1
            elif resolution == DisputeResolution.AGENT_B_CORRECT and agent_id == dispute.agent_b:
                rel["correct"] += 1
            elif resolution == DisputeResolution.BOTH_WRONG:
                pass
            elif resolution == DisputeResolution.BOTH_PARTIALLY_CORRECT:
                rel["correct"] += 0.5

            if rel["total"] > 0:
                rel["reliability"] = rel["correct"] / rel["total"]

    def _save(self) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            data = {
                "stats": self._stats.to_dict(),
                "disputes": {
                    k: v.to_dict() for k, v in self._disputes.items()
                    if v.resolution == DisputeResolution.PENDING
                },
            }
            path = self._dir / "cross_verify_data.json"
            path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            logger.debug("Failed to save cross-verify data: %s", e)

    def _load(self) -> None:
        try:
            path = self._dir / "cross_verify_data.json"
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            stats = data.get("stats", {})
            self._stats = CrossVerifyStats(
                total_verifications=stats.get("total_verifications", 0),
                agreements=stats.get("agreements", 0),
                disagreements=stats.get("disagreements", 0),
                uncertain=stats.get("uncertain", 0),
                disputes_resolved=stats.get("disputes_resolved", 0),
                disputes_pending=stats.get("disputes_pending", 0),
                consistency_rate=stats.get("consistency_rate", 0),
            )
        except Exception as e:
            logger.debug("Failed to load cross-verify data: %s", e)
