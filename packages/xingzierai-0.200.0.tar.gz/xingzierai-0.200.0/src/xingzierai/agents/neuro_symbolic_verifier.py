# -*- coding: utf-8 -*-
"""Neuro-Symbolic Output Verifier - Whitepaper Stream 3.

Inspired by AWS Automated Reasoning (Neuro-Symbolic Fusion):
- LLM output is verified by symbolic rules before returning to user
- Hallucination rate drops from 12% to 0.3%
- Deterministic constraints catch what LLM misses

This is the L1 (Symbolic Reasoning) verification layer.
It runs AFTER L3 (LLM) generates output, providing a safety net
that catches hallucinations, contradictions, and format violations.
"""

from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class VerificationSeverity(str, Enum):
    PASS = "pass"
    WARNING = "warning"
    FAIL = "fail"
    CRITICAL = "critical"


@dataclass
class VerificationCheck:
    name: str
    description: str
    check_fn: Callable[[str, Dict[str, Any]], VerificationSeverity]
    severity_on_fail: VerificationSeverity = VerificationSeverity.FAIL
    category: str = "general"


@dataclass
class VerificationResult:
    output: str
    passed: bool
    checks: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    corrections: List[str] = field(default_factory=list)
    total_latency_ms: float = 0.0

    @property
    def is_safe(self) -> bool:
        return self.passed and not any(
            c.get("severity") == VerificationSeverity.CRITICAL.value for c in self.checks
        )


class NeuroSymbolicVerifier:
    """Neuro-Symbolic Output Verifier.

    Whitepaper Stream 3 (AWS Automated Reasoning):
    LLM output -> Symbolic verification -> Safe output

    Checks:
    1. Format compliance (JSON, code, markdown)
    2. Factual consistency (no contradictions)
    3. Safety constraints (no dangerous code)
    4. Architecture compliance (follows iron laws)
    5. Completeness (no truncated outputs)
    """

    def __init__(self):
        self._checks: List[VerificationCheck] = []
        self._stats = {
            "total_verifications": 0,
            "passed": 0,
            "failed": 0,
            "warnings": 0,
            "corrections_applied": 0,
        }
        self._register_builtin_checks()

    def _register_builtin_checks(self) -> None:
        self._checks.append(VerificationCheck(
            name="empty_output",
            description="Output must not be empty",
            check_fn=self._check_empty,
            severity_on_fail=VerificationSeverity.CRITICAL,
            category="completeness",
        ))
        self._checks.append(VerificationCheck(
            name="truncated_output",
            description="Output must not be truncated",
            check_fn=self._check_truncated,
            severity_on_fail=VerificationSeverity.WARNING,
            category="completeness",
        ))
        self._checks.append(VerificationCheck(
            name="dangerous_code",
            description="Output must not contain dangerous code patterns",
            check_fn=self._check_dangerous_code,
            severity_on_fail=VerificationSeverity.CRITICAL,
            category="safety",
        ))
        self._checks.append(VerificationCheck(
            name="json_validity",
            description="If output claims to be JSON, it must be valid",
            check_fn=self._check_json_validity,
            severity_on_fail=VerificationSeverity.WARNING,
            category="format",
        ))
        self._checks.append(VerificationCheck(
            name="contradiction_check",
            description="Output must not contradict itself",
            check_fn=self._check_contradiction,
            severity_on_fail=VerificationSeverity.WARNING,
            category="consistency",
        ))
        self._checks.append(VerificationCheck(
            name="architecture_compliance",
            description="Code suggestions must follow architecture iron laws",
            check_fn=self._check_architecture_compliance,
            severity_on_fail=VerificationSeverity.WARNING,
            category="architecture",
        ))
        self._checks.append(VerificationCheck(
            name="pii_leakage",
            description="Output must not contain PII (emails, phone numbers, API keys)",
            check_fn=self._check_pii_leakage,
            severity_on_fail=VerificationSeverity.CRITICAL,
            category="privacy",
        ))
        self._checks.append(VerificationCheck(
            name="hallucinated_url",
            description="Output must not contain hallucinated URLs",
            check_fn=self._check_hallucinated_url,
            severity_on_fail=VerificationSeverity.WARNING,
            category="accuracy",
        ))
        self._checks.append(VerificationCheck(
            name="code_injection",
            description="Output must not contain SQL injection or XSS patterns",
            check_fn=self._check_code_injection,
            severity_on_fail=VerificationSeverity.CRITICAL,
            category="security",
        ))

    def add_check(self, check: VerificationCheck) -> None:
        self._checks.append(check)

    def verify(
        self,
        output: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> VerificationResult:
        """Verify LLM output through symbolic checks.

        Args:
            output: The LLM-generated output to verify
            context: Additional context (e.g., original query, constraints)

        Returns:
            VerificationResult with pass/fail status and any corrections
        """
        start = time.monotonic()
        ctx = context or {}
        self._stats["total_verifications"] += 1

        checks_results = []
        warnings = []
        corrections = []
        has_critical = False
        has_fail = False

        for check in self._checks:
            try:
                severity = check.check_fn(output, ctx)
                check_result = {
                    "name": check.name,
                    "category": check.category,
                    "severity": severity.value,
                    "description": check.description,
                }
                checks_results.append(check_result)

                if severity == VerificationSeverity.CRITICAL:
                    has_critical = True
                    has_fail = True
                elif severity == VerificationSeverity.FAIL:
                    has_fail = True
                elif severity == VerificationSeverity.WARNING:
                    warnings.append(f"{check.name}: {check.description}")

            except Exception as e:
                checks_results.append({
                    "name": check.name,
                    "category": check.category,
                    "severity": VerificationSeverity.WARNING.value,
                    "description": f"Check error: {str(e)[:100]}",
                })
                warnings.append(f"{check.name}: check error")

        corrected_output = output
        if has_critical:
            corrected_output = self._apply_corrections(output, checks_results, corrections)

        passed = not has_critical and not has_fail
        if passed:
            self._stats["passed"] += 1
        else:
            self._stats["failed"] += 1
        self._stats["warnings"] += len(warnings)
        if corrections:
            self._stats["corrections_applied"] += 1

        latency = (time.monotonic() - start) * 1000

        return VerificationResult(
            output=corrected_output,
            passed=passed,
            checks=checks_results,
            warnings=warnings,
            corrections=corrections,
            total_latency_ms=latency,
        )

    def _check_empty(self, output: str, ctx: Dict[str, Any]) -> VerificationSeverity:
        if not output or not output.strip():
            return VerificationSeverity.CRITICAL
        return VerificationSeverity.PASS

    def _check_truncated(self, output: str, ctx: Dict[str, Any]) -> VerificationSeverity:
        truncation_markers = [
            "...(truncated)",
            "[output truncated]",
            "```...", 
            "\n...\n",
        ]
        for marker in truncation_markers:
            if marker in output:
                return VerificationSeverity.WARNING
        if output.rstrip().endswith(("```", "...", "…")):
            return VerificationSeverity.WARNING
        return VerificationSeverity.PASS

    def _check_dangerous_code(self, output: str, ctx: Dict[str, Any]) -> VerificationSeverity:
        dangerous_patterns = [
            r"os\.system\s*\(",
            r"subprocess\.call\s*\(",
            r"subprocess\.Popen\s*\(",
            r"shutil\.rmtree\s*\(",
            r"__import__\s*\(",
            r"eval\s*\(",
            r"exec\s*\(",
            r"rm\s+-rf\s+/",
        ]
        for pattern in dangerous_patterns:
            if re.search(pattern, output):
                return VerificationSeverity.CRITICAL
        return VerificationSeverity.PASS

    def _check_json_validity(self, output: str, ctx: Dict[str, Any]) -> VerificationSeverity:
        json_indicators = ['{"', '"[', '":']
        if any(ind in output[:100] for ind in json_indicators):
            try:
                json.loads(output)
            except json.JSONDecodeError:
                try:
                    json_code = re.search(r'```json\s*(.*?)\s*```', output, re.DOTALL)
                    if json_code:
                        json.loads(json_code.group(1))
                    else:
                        return VerificationSeverity.WARNING
                except json.JSONDecodeError:
                    return VerificationSeverity.WARNING
        return VerificationSeverity.PASS

    def _check_contradiction(self, output: str, ctx: Dict[str, Any]) -> VerificationSeverity:
        contradiction_pairs = [
            ("是正确的", "是错误的"),
            ("是安全的", "是危险的"),
            ("推荐使用", "不推荐使用"),
            ("can", "cannot"),
            ("should", "should not"),
        ]
        lower = output.lower()
        for pos, neg in contradiction_pairs:
            if pos in lower and neg in lower:
                return VerificationSeverity.WARNING
        return VerificationSeverity.PASS

    def _check_architecture_compliance(self, output: str, ctx: Dict[str, Any]) -> VerificationSeverity:
        code_indicators = ["def ", "class ", "import ", "from ", "async def "]
        if not any(ind in output for ind in code_indicators):
            return VerificationSeverity.PASS

        violations = []
        if "global " in output and "=" in output:
            violations.append("global_mutable_state")

        if len(violations) > 0:
            return VerificationSeverity.WARNING
        return VerificationSeverity.PASS

    def _check_pii_leakage(self, output: str, ctx: Dict[str, Any]) -> VerificationSeverity:
        pii_patterns = [
            r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            r'(?:sk|pk|api[_-]?key)[_-][a-zA-Z0-9]{20,}',
            r'(?:password|passwd|pwd)\s*[=:]\s*["\']?[^\s"\']{8,}',
            r'1[3-9]\d{9}',
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        ]
        for pattern in pii_patterns:
            if re.search(pattern, output, re.IGNORECASE):
                return VerificationSeverity.CRITICAL
        return VerificationSeverity.PASS

    def _check_hallucinated_url(self, output: str, ctx: Dict[str, Any]) -> VerificationSeverity:
        url_pattern = r'https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}[/\w.-]*'
        urls = re.findall(url_pattern, output)
        known_safe_domains = [
            "github.com", "docs.python.org", "arxiv.org", "pypi.org",
            "stackoverflow.com", "wikipedia.org", "openai.com", "anthropic.com",
        ]
        for url in urls:
            domain = re.search(r'https?://([a-zA-Z0-9.-]+)', url)
            if domain:
                d = domain.group(1).lower()
                is_known = any(safe in d for safe in known_safe_domains)
                is_localhost = "localhost" in d or "127.0.0.1" in d
                if not is_known and not is_localhost and not d.startswith("example."):
                    return VerificationSeverity.WARNING
        return VerificationSeverity.PASS

    def _check_code_injection(self, output: str, ctx: Dict[str, Any]) -> VerificationSeverity:
        injection_patterns = [
            r"(?:UNION\s+ALL\s+SELECT|OR\s+1\s*=\s*1|DROP\s+TABLE)",
            r"<script[^>]*>.*?</script>",
            r"javascript\s*:",
            r"on(?:error|load|click|mouseover)\s*=",
            r"(?:document\.(?:cookie|location)|window\.(?:location|open))",
        ]
        for pattern in injection_patterns:
            if re.search(pattern, output, re.IGNORECASE | re.DOTALL):
                return VerificationSeverity.CRITICAL
        return VerificationSeverity.PASS

    def _apply_corrections(
        self,
        output: str,
        checks: List[Dict[str, Any]],
        corrections: List[str],
    ) -> str:
        """Apply automatic corrections to failed output."""
        for check in checks:
            if check["severity"] != VerificationSeverity.CRITICAL.value:
                continue

            if check["name"] == "empty_output":
                corrections.append("Replaced empty output with fallback message")
                return "[系统提示] 输出为空，请重新提问。"

            if check["name"] == "dangerous_code":
                corrections.append("Removed dangerous code patterns")
                dangerous_patterns = [
                    (r"os\.system\s*\([^)]*\)", "# [REMOVED: os.system call]"),
                    (r"subprocess\.(call|Popen)\s*\([^)]*\)", "# [REMOVED: subprocess call]"),
                    (r"shutil\.rmtree\s*\([^)]*\)", "# [REMOVED: shutil.rmtree call]"),
                    (r"eval\s*\([^)]*\)", "# [REMOVED: eval call]"),
                    (r"exec\s*\([^)]*\)", "# [REMOVED: exec call]"),
                ]
                corrected = output
                for pattern, replacement in dangerous_patterns:
                    corrected = re.sub(pattern, replacement, corrected)
                return corrected

            if check["name"] == "pii_leakage":
                corrections.append("Masked PII data")
                corrected = output
                corrected = re.sub(
                    r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
                    '[EMAIL REDACTED]', corrected,
                )
                corrected = re.sub(
                    r'(?:sk|pk|api[_-]?key)[_-][a-zA-Z0-9]{20,}',
                    '[API_KEY REDACTED]', corrected, flags=re.IGNORECASE,
                )
                corrected = re.sub(
                    r'(?:password|passwd|pwd)\s*[=:]\s*["\']?[^\s"\']{8,}',
                    'password=[REDACTED]', corrected, flags=re.IGNORECASE,
                )
                return corrected

            if check["name"] == "code_injection":
                corrections.append("Removed code injection patterns")
                corrected = output
                corrected = re.sub(
                    r"<script[^>]*>.*?</script>", "[SCRIPT REMOVED]", corrected,
                    flags=re.DOTALL | re.IGNORECASE,
                )
                corrected = re.sub(
                    r"javascript\s*:", "[JAVASCRIPT_URL REMOVED]", corrected,
                    flags=re.IGNORECASE,
                )
                return corrected

        return output

    def get_stats(self) -> Dict[str, Any]:
        total = max(self._stats["total_verifications"], 1)
        return {
            **self._stats,
            "pass_rate": round(self._stats["passed"] / total, 4),
            "check_count": len(self._checks),
        }
