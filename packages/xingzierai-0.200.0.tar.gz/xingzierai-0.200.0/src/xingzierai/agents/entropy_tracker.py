# -*- coding: utf-8 -*-
"""Entropy Reduction Tracker - Quantifying negative entropy from rules and verification.

Core insight from Penrose + Schrodinger:
- Life is negative entropy (Schrodinger, "What is Life?")
- AI cannot produce consciousness, but CAN produce negative entropy
- Evolution metric should be entropy reduction, not LLM call volume

Entropy reduction dimensions:
1. Rule entropy reduction: L3 uncertainty -> L0 certainty
2. Verification entropy reduction: Errors caught * severity
3. Internalization entropy reduction: L3 -> L0 token savings
4. Calibration entropy reduction: Brier score improvement
"""

from __future__ import annotations

import json
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_ENTROPY_DIR = Path.home() / ".xingzierai" / "entropy_metrics"


@dataclass
class EntropyEvent:
    event_type: str  # rule_hit, verification_block, internalization, calibration
    entropy_reduction: float
    description: str = ""
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DailyEntropyReport:
    date: str
    total_entropy_reduction: float = 0.0
    rule_entropy_reduction: float = 0.0
    verification_entropy_reduction: float = 0.0
    internalization_entropy_reduction: float = 0.0
    calibration_entropy_reduction: float = 0.0
    rule_hits: int = 0
    verification_blocks: int = 0
    internalizations: int = 0
    l3_tokens_avoided: int = 0
    rule_roi: Dict[str, float] = field(default_factory=dict)
    system_negative_entropy_rate: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "date": self.date,
            "total_entropy_reduction": round(self.total_entropy_reduction, 4),
            "rule_entropy_reduction": round(self.rule_entropy_reduction, 4),
            "verification_entropy_reduction": round(self.verification_entropy_reduction, 4),
            "internalization_entropy_reduction": round(self.internalization_entropy_reduction, 4),
            "calibration_entropy_reduction": round(self.calibration_entropy_reduction, 4),
            "rule_hits": self.rule_hits,
            "verification_blocks": self.verification_blocks,
            "internalizations": self.internalizations,
            "l3_tokens_avoided": self.l3_tokens_avoided,
            "system_negative_entropy_rate": round(self.system_negative_entropy_rate, 4),
        }


@dataclass
class EntropyStats:
    total_events: int = 0
    total_entropy_reduction: float = 0.0
    events_by_type: Dict[str, int] = field(default_factory=dict)
    daily_reports: Dict[str, DailyEntropyReport] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_events": self.total_events,
            "total_entropy_reduction": round(self.total_entropy_reduction, 4),
            "events_by_type": self.events_by_type,
            "daily_reports_count": len(self.daily_reports),
        }


L3_TOKEN_COST = 500  # Average tokens per L3 call
SEVERITY_WEIGHTS = {
    "critical": 10.0,
    "high": 5.0,
    "medium": 2.0,
    "low": 1.0,
    "warning": 0.5,
}


class EntropyReductionTracker:
    """Track entropy reduction from rules, verification, and internalization.

    Usage:
        tracker = EntropyReductionTracker()

        # Record rule hit (L0 instead of L3)
        tracker.record_rule_hit("RR-001", tokens_avoided=500)

        # Record verification block
        tracker.record_verification_block("dangerous_code", severity="critical")

        # Record internalization (L3 -> L0)
        tracker.record_internalization("status", tokens_avoided=5000)

        # Get report
        report = tracker.get_daily_report()
    """

    def __init__(self, entropy_dir: Optional[str] = None):
        self._dir = Path(entropy_dir) if entropy_dir else _ENTROPY_DIR
        self._events: List[EntropyEvent] = []
        self._stats = EntropyStats()
        self._rule_cumulative: Dict[str, float] = defaultdict(float)
        self._load()

    def record_rule_hit(
        self, rule_id: str, tokens_avoided: int = L3_TOKEN_COST,
    ) -> None:
        """Record an L0 rule hit that avoided an L3 call."""
        entropy_reduction = tokens_avoided / 1000.0
        event = EntropyEvent(
            event_type="rule_hit",
            entropy_reduction=entropy_reduction,
            description=f"Rule {rule_id} hit, avoided {tokens_avoided} L3 tokens",
            metadata={"rule_id": rule_id, "tokens_avoided": tokens_avoided},
        )
        self._record_event(event)
        self._rule_cumulative[rule_id] += entropy_reduction

    def record_verification_block(
        self, check_name: str, severity: str = "high",
    ) -> None:
        """Record a verification that blocked a potential error."""
        weight = SEVERITY_WEIGHTS.get(severity, 1.0)
        entropy_reduction = weight
        event = EntropyEvent(
            event_type="verification_block",
            entropy_reduction=entropy_reduction,
            description=f"Verification {check_name} blocked ({severity})",
            metadata={"check_name": check_name, "severity": severity},
        )
        self._record_event(event)

    def record_internalization(
        self, keyword: str, tokens_avoided: int = 0,
    ) -> None:
        """Record an L3 -> L0 rule internalization."""
        entropy_reduction = max(tokens_avoided / 1000.0, 1.0)
        event = EntropyEvent(
            event_type="internalization",
            entropy_reduction=entropy_reduction,
            description=f"Internalized '{keyword}' from L3 to L0",
            metadata={"keyword": keyword, "tokens_avoided": tokens_avoided},
        )
        self._record_event(event)

    def record_calibration_improvement(
        self, brier_before: float, brier_after: float,
    ) -> None:
        """Record a calibration improvement."""
        entropy_reduction = max(brier_before - brier_after, 0)
        if entropy_reduction > 0:
            event = EntropyEvent(
                event_type="calibration",
                entropy_reduction=entropy_reduction,
                description=f"Calibration improved: {brier_before:.3f} -> {brier_after:.3f}",
                metadata={"brier_before": brier_before, "brier_after": brier_after},
            )
            self._record_event(event)

    def get_daily_report(self, date: Optional[str] = None) -> Dict[str, Any]:
        """Get entropy reduction report for a specific date."""
        if date is None:
            date = time.strftime("%Y-%m-%d")

        if date in self._stats.daily_reports:
            return self._stats.daily_reports[date].to_dict()

        day_events = [
            e for e in self._events
            if time.strftime("%Y-%m-%d", time.localtime(e.timestamp)) == date
        ]

        report = DailyEntropyReport(date=date)
        for event in day_events:
            report.total_entropy_reduction += event.entropy_reduction
            if event.event_type == "rule_hit":
                report.rule_entropy_reduction += event.entropy_reduction
                report.rule_hits += 1
                report.l3_tokens_avoided += event.metadata.get("tokens_avoided", 0)
            elif event.event_type == "verification_block":
                report.verification_entropy_reduction += event.entropy_reduction
                report.verification_blocks += 1
            elif event.event_type == "internalization":
                report.internalization_entropy_reduction += event.entropy_reduction
                report.internalizations += 1
                report.l3_tokens_avoided += event.metadata.get("tokens_avoided", 0)
            elif event.event_type == "calibration":
                report.calibration_entropy_reduction += event.entropy_reduction

        report.rule_roi = {
            k: round(v, 4) for k, v in sorted(
                self._rule_cumulative.items(),
                key=lambda x: -x[1],
            )[:20]
        }

        return report.to_dict()

    def get_stats(self) -> Dict[str, Any]:
        return self._stats.to_dict()

    def get_rule_roi(self, top_n: int = 20) -> Dict[str, float]:
        """Get rule ROI (cumulative entropy reduction per rule)."""
        sorted_roi = sorted(
            self._rule_cumulative.items(),
            key=lambda x: -x[1],
        )[:top_n]
        return {k: round(v, 4) for k, v in sorted_roi}

    def _record_event(self, event: EntropyEvent) -> None:
        self._events.append(event)
        self._stats.total_events += 1
        self._stats.total_entropy_reduction += event.entropy_reduction
        self._stats.events_by_type[event.event_type] = (
            self._stats.events_by_type.get(event.event_type, 0) + 1
        )

        if len(self._events) > 10000:
            self._events = self._events[-5000:]

        if self._stats.total_events % 100 == 0:
            self._save()

    def _save(self) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            data = {
                "stats": self._stats.to_dict(),
                "rule_cumulative": dict(self._rule_cumulative),
            }
            path = self._dir / "entropy_data.json"
            path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            logger.debug("Failed to save entropy data: %s", e)

    def _load(self) -> None:
        try:
            path = self._dir / "entropy_data.json"
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            stats = data.get("stats", {})
            self._stats = EntropyStats(
                total_events=stats.get("total_events", 0),
                total_entropy_reduction=stats.get("total_entropy_reduction", 0),
                events_by_type=stats.get("events_by_type", {}),
            )
            self._rule_cumulative = defaultdict(
                float, data.get("rule_cumulative", {}),
            )
        except Exception as e:
            logger.debug("Failed to load entropy data: %s", e)
