# -*- coding: utf-8 -*-
"""Policy Engine - Declarative policy-based execution control for agent operations.

Inspired by PraisonAI's PolicyEngine with enhancements for XINGZIER AI:
- Rule-based control with pattern matching (allow/deny/ask)
- Priority system (higher priority policies take precedence)
- Strict mode (deny unknown operations by default)
- Serialization (save/load policies as JSON)
- Convenience functions (read-only, deny-tools, allow-tools)
- Integration with existing ToolGuardMixin and RuleEngine

Usage:
    from xingzierai.agents.policy import PolicyEngine, Policy, PolicyRule, PolicyAction

    engine = PolicyEngine()
    engine.add_policy(Policy(
        name="no_delete",
        rules=[PolicyRule(action=PolicyAction.DENY, resource="tool:delete_*")]
    ))

    result = engine.check("tool:delete_file")
    if not result.allowed:
        print(f"Blocked: {result.reason}")
"""

from __future__ import annotations

import fnmatch
import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class PolicyAction(Enum):
    ALLOW = "allow"
    DENY = "deny"
    ASK = "ask"


@dataclass
class PolicyCheckResult:
    allowed: bool = True
    action: PolicyAction = PolicyAction.ALLOW
    reason: str = ""
    policy_name: str = ""
    rule_name: str = ""
    matched_resource: str = ""

    def to_dict(self) -> dict:
        return {
            "allowed": self.allowed,
            "action": self.action.value,
            "reason": self.reason,
            "policy_name": self.policy_name,
            "rule_name": self.rule_name,
            "matched_resource": self.matched_resource,
        }


@dataclass
class PolicyRule:
    action: PolicyAction = PolicyAction.DENY
    resource: str = ""
    reason: str = ""
    name: str = ""
    priority: int = 0
    conditions: Dict[str, Any] = field(default_factory=dict)

    def matches(self, resource: str, context: Optional[Dict[str, Any]] = None) -> bool:
        if not self.resource:
            return False

        if self._pattern_match(self.resource, resource):
            if self.conditions and context:
                return self._check_conditions(context)
            return True
        return False

    def _pattern_match(self, pattern: str, resource: str) -> bool:
        if pattern == "*":
            return True
        if "*" in pattern or "?" in pattern or "[" in pattern:
            return fnmatch.fnmatch(resource, pattern)
        return pattern == resource

    def _check_conditions(self, context: Dict[str, Any]) -> bool:
        for key, expected in self.conditions.items():
            actual = context.get(key)
            if isinstance(expected, list):
                if actual not in expected:
                    return False
            elif actual != expected:
                return False
        return True

    def to_dict(self) -> dict:
        return {
            "action": self.action.value,
            "resource": self.resource,
            "reason": self.reason,
            "name": self.name,
            "priority": self.priority,
            "conditions": self.conditions,
        }

    @classmethod
    def from_dict(cls, data: dict) -> PolicyRule:
        return cls(
            action=PolicyAction(data.get("action", "deny")),
            resource=data.get("resource", ""),
            reason=data.get("reason", ""),
            name=data.get("name", ""),
            priority=data.get("priority", 0),
            conditions=data.get("conditions", {}),
        )


@dataclass
class Policy:
    name: str = ""
    description: str = ""
    priority: int = 0
    rules: List[PolicyRule] = field(default_factory=list)
    enabled: bool = True

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "priority": self.priority,
            "rules": [r.to_dict() for r in self.rules],
            "enabled": self.enabled,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Policy:
        rules = [PolicyRule.from_dict(r) for r in data.get("rules", [])]
        return cls(
            name=data.get("name", ""),
            description=data.get("description", ""),
            priority=data.get("priority", 0),
            rules=rules,
            enabled=data.get("enabled", True),
        )


@dataclass
class PolicyConfig:
    strict_mode: bool = False
    default_action: PolicyAction = PolicyAction.ALLOW
    log_decisions: bool = True


class PolicyEngine:
    """Declarative policy engine for agent operation control.

    Features:
    - Rule-based control with pattern matching
    - Priority system (higher priority policies/rules take precedence)
    - Strict mode (deny unknown operations by default)
    - Serialization (save/load policies as JSON)
    - Zero performance impact when not checked
    """

    def __init__(self, config: Optional[PolicyConfig] = None):
        self._config = config or PolicyConfig()
        self._policies: List[Policy] = []
        self._decision_log: List[dict] = []
        self._max_log_size = 200

    @property
    def policies(self) -> List[Policy]:
        return self._policies

    @property
    def config(self) -> PolicyConfig:
        return self._config

    def add_policy(self, policy: Policy) -> None:
        self._policies.append(policy)
        self._policies.sort(key=lambda p: p.priority, reverse=True)

    def remove_policy(self, name: str) -> bool:
        before = len(self._policies)
        self._policies = [p for p in self._policies if p.name != name]
        return len(self._policies) < before

    def check(
        self,
        resource: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> PolicyCheckResult:
        """Check if an operation on a resource is allowed.

        Args:
            resource: Resource identifier (e.g., "tool:delete_file", "file:/etc/passwd")
            context: Optional context for condition evaluation

        Returns:
            PolicyCheckResult with allowed/denied decision and reason
        """
        if not self._policies:
            if self._config.strict_mode:
                result = PolicyCheckResult(
                    allowed=False,
                    action=PolicyAction.DENY,
                    reason="Strict mode: no policies defined, denying by default",
                    policy_name="__strict_mode__",
                )
            else:
                result = PolicyCheckResult(
                    allowed=self._config.default_action == PolicyAction.ALLOW,
                    action=self._config.default_action,
                )
            self._log_decision(resource, result)
            return result

        best_match: Optional[PolicyRule] = None
        best_policy: Optional[Policy] = None
        best_priority = -1

        for policy in self._policies:
            if not policy.enabled:
                continue
            for rule in policy.rules:
                if rule.matches(resource, context):
                    rule_priority = policy.priority * 1000 + rule.priority
                    if rule_priority > best_priority:
                        best_priority = rule_priority
                        best_match = rule
                        best_policy = policy

        if best_match is not None and best_policy is not None:
            allowed = best_match.action == PolicyAction.ALLOW
            result = PolicyCheckResult(
                allowed=allowed,
                action=best_match.action,
                reason=best_match.reason,
                policy_name=best_policy.name,
                rule_name=best_match.name,
                matched_resource=best_match.resource,
            )
        elif self._config.strict_mode:
            result = PolicyCheckResult(
                allowed=False,
                action=PolicyAction.DENY,
                reason=f"Strict mode: no policy rule matches '{resource}'",
                policy_name="__strict_mode__",
            )
        else:
            result = PolicyCheckResult(
                allowed=self._config.default_action == PolicyAction.ALLOW,
                action=self._config.default_action,
                reason="No matching policy rule, using default action",
            )

        self._log_decision(resource, result)
        return result

    def is_allowed(self, resource: str, context: Optional[Dict[str, Any]] = None) -> bool:
        return self.check(resource, context).allowed

    def is_denied(self, resource: str, context: Optional[Dict[str, Any]] = None) -> bool:
        return not self.check(resource, context).allowed

    def needs_approval(self, resource: str, context: Optional[Dict[str, Any]] = None) -> bool:
        return self.check(resource, context).action == PolicyAction.ASK

    def _log_decision(self, resource: str, result: PolicyCheckResult) -> None:
        if not self._config.log_decisions:
            return
        self._decision_log.append({
            "resource": resource,
            "allowed": result.allowed,
            "action": result.action.value,
            "reason": result.reason,
            "policy": result.policy_name,
        })
        if len(self._decision_log) > self._max_log_size:
            self._decision_log = self._decision_log[-self._max_log_size:]

    def get_decision_log(self, limit: int = 50) -> List[dict]:
        return self._decision_log[-limit:]

    def get_stats(self) -> dict:
        total = len(self._decision_log)
        allowed = sum(1 for d in self._decision_log if d.get("allowed"))
        denied = total - allowed
        return {
            "total_policies": len(self._policies),
            "total_rules": sum(len(p.rules) for p in self._policies),
            "total_decisions": total,
            "allowed_count": allowed,
            "denied_count": denied,
            "strict_mode": self._config.strict_mode,
        }

    def save_to_file(self, filepath: str) -> None:
        resolved = Path(filepath).resolve()
        if not str(resolved).startswith(str(Path.home())) and not str(resolved).startswith(str(Path.cwd())):
            raise ValueError(f"Policy file path must be within home or working directory: {filepath}")
        data = {
            "config": {
                "strict_mode": self._config.strict_mode,
                "default_action": self._config.default_action.value,
                "log_decisions": self._config.log_decisions,
            },
            "policies": [p.to_dict() for p in self._policies],
        }
        resolved.parent.mkdir(parents=True, exist_ok=True)
        resolved.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    def load_from_file(self, filepath: str) -> None:
        resolved = Path(filepath).resolve()
        if not str(resolved).startswith(str(Path.home())) and not str(resolved).startswith(str(Path.cwd())):
            raise ValueError(f"Policy file path must be within home or working directory: {filepath}")
        if not resolved.exists():
            raise FileNotFoundError(f"Policy file not found: {filepath}")
        data = json.loads(resolved.read_text(encoding="utf-8"))
        config_data = data.get("config", {})
        self._config = PolicyConfig(
            strict_mode=config_data.get("strict_mode", False),
            default_action=PolicyAction(config_data.get("default_action", "allow")),
            log_decisions=config_data.get("log_decisions", True),
        )
        self._policies = [Policy.from_dict(p) for p in data.get("policies", [])]
        self._policies.sort(key=lambda p: p.priority, reverse=True)


def create_read_only_policy() -> Policy:
    return Policy(
        name="read_only",
        description="Block all write operations",
        priority=100,
        rules=[
            PolicyRule(
                action=PolicyAction.DENY,
                resource="tool:write_*",
                reason="Write operations blocked in read-only mode",
                name="block_writes",
            ),
            PolicyRule(
                action=PolicyAction.DENY,
                resource="tool:edit_*",
                reason="Edit operations blocked in read-only mode",
                name="block_edits",
            ),
            PolicyRule(
                action=PolicyAction.DENY,
                resource="tool:delete_*",
                reason="Delete operations blocked in read-only mode",
                name="block_deletes",
            ),
            PolicyRule(
                action=PolicyAction.DENY,
                resource="tool:execute_*",
                reason="Execute operations blocked in read-only mode",
                name="block_execute",
            ),
            PolicyRule(
                action=PolicyAction.DENY,
                resource="tool:shell_*",
                reason="Shell operations blocked in read-only mode",
                name="block_shell",
            ),
        ],
    )


def create_deny_tools_policy(
    tool_patterns: List[str],
    reason: str = "Tool blocked by policy",
) -> Policy:
    rules = [
        PolicyRule(
            action=PolicyAction.DENY,
            resource=f"tool:{pattern}",
            reason=reason,
            name=f"deny_{pattern}",
        )
        for pattern in tool_patterns
    ]
    return Policy(
        name="deny_tools",
        description=f"Block specific tools: {', '.join(tool_patterns)}",
        priority=50,
        rules=rules,
    )


def create_allow_tools_policy(
    tool_patterns: List[str],
    reason: str = "Only allowed tools can be used",
) -> Policy:
    allow_rules = [
        PolicyRule(
            action=PolicyAction.ALLOW,
            resource=f"tool:{pattern}",
            reason=f"Explicitly allowed: {pattern}",
            name=f"allow_{pattern}",
        )
        for pattern in tool_patterns
    ]
    deny_all = PolicyRule(
        action=PolicyAction.DENY,
        resource="tool:*",
        reason=reason,
        name="deny_all_other",
        priority=-1,
    )
    return Policy(
        name="allow_tools",
        description=f"Allow only specific tools: {', '.join(tool_patterns)}",
        priority=50,
        rules=allow_rules + [deny_all],
    )


def create_safety_policy() -> Policy:
    return Policy(
        name="safety",
        description="Core safety rules for agent operations",
        priority=200,
        rules=[
            PolicyRule(
                action=PolicyAction.DENY,
                resource="tool:execute_shell_command",
                reason="Shell commands require approval in safety mode",
                name="shell_approval",
                conditions={"env": "production"},
            ),
            PolicyRule(
                action=PolicyAction.ASK,
                resource="file:/etc/*",
                reason="System file access requires approval",
                name="system_files",
            ),
            PolicyRule(
                action=PolicyAction.DENY,
                resource="file:*/.env",
                reason="Environment files contain secrets",
                name="env_files",
            ),
            PolicyRule(
                action=PolicyAction.DENY,
                resource="file:*/id_rsa",
                reason="SSH private keys are protected",
                name="ssh_keys",
            ),
            PolicyRule(
                action=PolicyAction.ASK,
                resource="tool:*_model",
                reason="Model training operations require approval",
                name="model_ops",
            ),
        ],
    )


_global_policy_engine: Optional[PolicyEngine] = None


def get_policy_engine() -> PolicyEngine:
    global _global_policy_engine
    if _global_policy_engine is None:
        _global_policy_engine = PolicyEngine()
        _global_policy_engine.add_policy(create_safety_policy())
    return _global_policy_engine
