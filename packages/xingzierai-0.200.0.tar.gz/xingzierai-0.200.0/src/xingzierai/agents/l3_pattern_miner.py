# -*- coding: utf-8 -*-
"""L3 Pattern Miner - Mine internalizable patterns from L3 (LLM) interactions.

Inspired by Penrose's Cerebellum Argument:
- Computation throughput != understanding
- The most valuable rules come from L3 (where LLM was needed)
- Repeated successful L3 patterns should be internalized to L0

Internalization pipeline:
L3 interaction -> Semantic clustering -> Candidate rule generation
-> Low confidence registration -> Gradual verification -> Official rule

This is the inverse of the L0->L3 cascade: we mine L3 to strengthen L0.
"""

from __future__ import annotations

import json
import logging
import re
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

_MINER_DIR = Path.home() / ".xingzierai" / "l3_pattern_miner"


@dataclass
class L3Interaction:
    user_input: str
    output: str
    user_rating: int = 0
    category: str = ""
    timestamp: float = field(default_factory=time.time)
    session_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "user_input": self.user_input[:200],
            "output": self.output[:200],
            "user_rating": self.user_rating,
            "category": self.category,
            "timestamp": self.timestamp,
        }


@dataclass
class PatternCluster:
    cluster_id: str
    keyword: str
    interactions: List[L3Interaction] = field(default_factory=list)
    output_consistency: float = 0.0
    most_common_output: str = ""
    category: str = ""
    candidate_rule_created: bool = False
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cluster_id": self.cluster_id,
            "keyword": self.keyword,
            "interaction_count": len(self.interactions),
            "output_consistency": round(self.output_consistency, 4),
            "most_common_output": self.most_common_output[:100],
            "category": self.category,
            "candidate_rule_created": self.candidate_rule_created,
        }


@dataclass
class CandidateRule:
    rule_id: str
    keyword: str
    pattern: str
    output_template: str
    category: str
    confidence: float = 0.5
    verification_count: int = 0
    verification_passes: int = 0
    promoted: bool = False
    created_at: float = field(default_factory=time.time)
    promoted_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "keyword": self.keyword,
            "pattern": self.pattern,
            "output_template": self.output_template[:100],
            "category": self.category,
            "confidence": round(self.confidence, 4),
            "verification_count": self.verification_count,
            "verification_passes": self.verification_passes,
            "promoted": self.promoted,
        }


@dataclass
class MinerStats:
    total_l3_interactions: int = 0
    high_quality_interactions: int = 0
    clusters_formed: int = 0
    candidate_rules_created: int = 0
    rules_promoted: int = 0
    l3_calls_avoided: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_l3_interactions": self.total_l3_interactions,
            "high_quality_interactions": self.high_quality_interactions,
            "clusters_formed": self.clusters_formed,
            "candidate_rules_created": self.candidate_rules_created,
            "rules_promoted": self.rules_promoted,
            "l3_calls_avoided": self.l3_calls_avoided,
        }


class L3PatternMiner:
    """Mine internalizable patterns from L3 interactions.

    The key insight: if the same type of question keeps being sent to L3
    and gets consistently good answers, that pattern should become an L0 rule.
    """

    MIN_CLUSTER_SIZE = 5
    MIN_OUTPUT_CONSISTENCY = 0.6
    MIN_RATING = 4
    PROMOTION_VERIFICATIONS = 10
    PROMOTION_PASS_RATE = 0.8
    PROMOTION_CONFIDENCE = 0.7
    MAX_CLUSTERS = 200
    MAX_CANDIDATES = 100
    MAX_INTERACTIONS = 5000

    def __init__(self, miner_dir: Optional[str] = None):
        self._dir = Path(miner_dir) if miner_dir else _MINER_DIR
        self._interactions: List[L3Interaction] = []
        self._clusters: Dict[str, PatternCluster] = {}
        self._candidates: Dict[str, CandidateRule] = {}
        self._stats = MinerStats()
        self._keyword_index: Dict[str, List[str]] = defaultdict(list)
        self._load()

    def record_l3_interaction(
        self,
        user_input: str,
        output: str,
        user_rating: int = 0,
        category: str = "",
        session_id: str = "",
    ) -> None:
        """Record an L3 interaction for mining.

        Args:
            user_input: The user's input that was routed to L3
            output: The L3 (LLM) output
            user_rating: User satisfaction rating (1-5), >=4 is high quality
            category: Optional category label
            session_id: Optional session identifier
        """
        interaction = L3Interaction(
            user_input=user_input,
            output=output,
            user_rating=user_rating,
            category=category,
            session_id=session_id,
        )

        self._interactions.append(interaction)
        self._stats.total_l3_interactions += 1

        if user_rating >= self.MIN_RATING:
            self._stats.high_quality_interactions += 1
            self._try_cluster(interaction)

        if len(self._interactions) > self.MAX_INTERACTIONS:
            self._interactions = self._interactions[-self.MAX_INTERACTIONS // 2:]

        if self._stats.total_l3_interactions % 50 == 0:
            self._try_create_candidates()
            self._try_promote_candidates()
            self._save()

    def verify_candidate(self, keyword: str, output: str) -> None:
        """Verify a candidate rule against actual output.

        Called when a candidate rule's pattern matches a new interaction.
        """
        for candidate in self._candidates.values():
            if candidate.keyword == keyword and not candidate.promoted:
                candidate.verification_count += 1
                if self._output_matches_template(output, candidate.output_template):
                    candidate.verification_passes += 1
                self._try_promote_candidate(candidate)

    def get_candidate_rules(self) -> List[Dict[str, Any]]:
        """Get all candidate rules (not yet promoted)."""
        return [
            c.to_dict() for c in self._candidates.values()
            if not c.promoted
        ]

    def get_promoted_rules(self) -> List[Dict[str, Any]]:
        """Get all promoted rules ready for L0 integration."""
        return [
            c.to_dict() for c in self._candidates.values()
            if c.promoted
        ]

    def get_stats(self) -> Dict[str, Any]:
        return self._stats.to_dict()

    def get_clusters(self) -> List[Dict[str, Any]]:
        return [c.to_dict() for c in self._clusters.values()]

    def _try_cluster(self, interaction: L3Interaction) -> None:
        words = re.findall(r"[a-zA-Z\u4e00-\u9fff]+", interaction.user_input.lower())
        if not words:
            return

        for word in words[:3]:
            if len(word) < 2:
                continue

            if word in self._keyword_index:
                cluster_id = self._keyword_index[word][0]
                if cluster_id in self._clusters:
                    cluster = self._clusters[cluster_id]
                    cluster.interactions.append(interaction)
                    self._update_cluster_consistency(cluster)
                    continue

            if len(self._clusters) >= self.MAX_CLUSTERS:
                continue

            cluster_id = f"cluster_{int(time.time())}_{hash(word) % 10000:04d}"
            cluster = PatternCluster(
                cluster_id=cluster_id,
                keyword=word,
                interactions=[interaction],
                category=interaction.category,
            )
            self._clusters[cluster_id] = cluster
            self._keyword_index[word].append(cluster_id)
            self._stats.clusters_formed += 1

    def _update_cluster_consistency(self, cluster: PatternCluster) -> None:
        if len(cluster.interactions) < 2:
            return

        output_prefixes = [
            i.output[:80] for i in cluster.interactions
        ]
        counter = Counter(output_prefixes)
        most_common, count = counter.most_common(1)[0]
        cluster.output_consistency = count / len(cluster.interactions)
        cluster.most_common_output = most_common

    def _try_create_candidates(self) -> None:
        for cluster in self._clusters.values():
            if cluster.candidate_rule_created:
                continue
            if len(cluster.interactions) < self.MIN_CLUSTER_SIZE:
                continue
            if cluster.output_consistency < self.MIN_OUTPUT_CONSISTENCY:
                continue
            if len(self._candidates) >= self.MAX_CANDIDATES:
                continue

            rule_id = f"LR3_{int(time.time())}_{hash(cluster.keyword) % 10000:04d}"
            pattern = rf"\b{re.escape(cluster.keyword)}\b"

            candidate = CandidateRule(
                rule_id=rule_id,
                keyword=cluster.keyword,
                pattern=pattern,
                output_template=cluster.most_common_output,
                category=cluster.category or "learned",
                confidence=0.5,
            )

            self._candidates[rule_id] = candidate
            cluster.candidate_rule_created = True
            self._stats.candidate_rules_created += 1
            logger.info(
                "Created candidate rule %s from L3 cluster '%s' (consistency=%.2f)",
                rule_id, cluster.keyword, cluster.output_consistency,
            )

    def _try_promote_candidates(self) -> None:
        for candidate in self._candidates.values():
            if not candidate.promoted:
                self._try_promote_candidate(candidate)

    def _try_promote_candidate(self, candidate: CandidateRule) -> None:
        if candidate.promoted:
            return
        if candidate.verification_count < self.PROMOTION_VERIFICATIONS:
            return

        pass_rate = candidate.verification_passes / max(candidate.verification_count, 1)
        if pass_rate >= self.PROMOTION_PASS_RATE:
            candidate.promoted = True
            candidate.promoted_at = time.time()
            candidate.confidence = self.PROMOTION_CONFIDENCE
            self._stats.rules_promoted += 1
            self._stats.l3_calls_avoided += candidate.verification_count
            logger.info(
                "Promoted candidate rule %s (pass_rate=%.2f, verifications=%d)",
                candidate.rule_id, pass_rate, candidate.verification_count,
            )

    def _output_matches_template(self, output: str, template: str) -> bool:
        if not output or not template:
            return False
        output_prefix = output[:80]
        template_prefix = template[:80]
        if output_prefix == template_prefix:
            return True
        output_words = set(re.findall(r"\w+", output_prefix.lower()))
        template_words = set(re.findall(r"\w+", template_prefix.lower()))
        if not output_words or not template_words:
            return False
        overlap = len(output_words & template_words) / max(
            len(output_words | template_words), 1,
        )
        return overlap >= 0.5

    def _save(self) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            data = {
                "stats": self._stats.to_dict(),
                "clusters": {
                    k: v.to_dict() for k, v in self._clusters.items()
                },
                "candidates": {
                    k: v.to_dict() for k, v in self._candidates.items()
                },
            }
            path = self._dir / "miner_data.json"
            path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            logger.debug("Failed to save miner data: %s", e)

    def _load(self) -> None:
        try:
            path = self._dir / "miner_data.json"
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            stats = data.get("stats", {})
            self._stats = MinerStats(
                total_l3_interactions=stats.get("total_l3_interactions", 0),
                high_quality_interactions=stats.get("high_quality_interactions", 0),
                clusters_formed=stats.get("clusters_formed", 0),
                candidate_rules_created=stats.get("candidate_rules_created", 0),
                rules_promoted=stats.get("rules_promoted", 0),
                l3_calls_avoided=stats.get("l3_calls_avoided", 0),
            )
            for k, v in data.get("candidates", {}).items():
                self._candidates[k] = CandidateRule(
                    rule_id=v.get("rule_id", k),
                    keyword=v.get("keyword", ""),
                    pattern=v.get("pattern", ""),
                    output_template=v.get("output_template", ""),
                    category=v.get("category", "learned"),
                    confidence=v.get("confidence", 0.5),
                    verification_count=v.get("verification_count", 0),
                    verification_passes=v.get("verification_passes", 0),
                    promoted=v.get("promoted", False),
                )
        except Exception as e:
            logger.debug("Failed to load miner data: %s", e)
