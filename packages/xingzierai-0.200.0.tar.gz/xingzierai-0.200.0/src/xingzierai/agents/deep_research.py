# -*- coding: utf-8 -*-
"""Deep Research Agent - Multi-step autonomous research with citations.

Inspired by PraisonAI's DeepResearchAgent, adapted for XINGZIER AI:
- Multi-step research with web search
- Structured citation extraction
- Streaming reasoning summaries
- Auto provider detection from model name
- Integration with SmartLLMClient for model routing

Usage:
    from xingzierai.agents.deep_research import DeepResearchAgent

    agent = DeepResearchAgent(model="o4-mini-deep-research")
    result = agent.research("What are the latest AI trends?")
    print(result.report)
    print(f"Citations: {len(result.citations)}")
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ResearchProvider(Enum):
    OPENAI = "openai"
    GEMINI = "gemini"
    GENERIC = "generic"


class ResearchStatus(Enum):
    PENDING = "pending"
    SEARCHING = "searching"
    REASONING = "reasoning"
    SYNTHESIZING = "synthesizing"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Citation:
    title: str = ""
    url: str = ""
    snippet: str = ""
    source: str = ""

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "source": self.source,
        }


@dataclass
class WebSearch:
    query: str = ""
    results_count: int = 0
    timestamp: float = 0.0


@dataclass
class ReasoningStep:
    summary: str = ""
    step_type: str = "reasoning"
    timestamp: float = 0.0


@dataclass
class ResearchResult:
    report: str = ""
    citations: List[Citation] = field(default_factory=list)
    web_searches: List[WebSearch] = field(default_factory=list)
    reasoning_steps: List[ReasoningStep] = field(default_factory=list)
    interaction_id: str = ""
    status: ResearchStatus = ResearchStatus.PENDING
    error: str = ""
    duration_seconds: float = 0.0

    def to_dict(self) -> dict:
        return {
            "report": self.report,
            "citations": [c.to_dict() for c in self.citations],
            "web_searches": [{"query": w.query, "results_count": w.results_count} for w in self.web_searches],
            "reasoning_steps": [{"summary": r.summary, "type": r.step_type} for r in self.reasoning_steps],
            "interaction_id": self.interaction_id,
            "status": self.status.value,
            "duration_seconds": round(self.duration_seconds, 2),
        }


OPENAI_DEEP_MODELS = frozenset({
    "o3-deep-research", "o4-mini-deep-research",
})

GEMINI_DEEP_MODELS = frozenset({
    "deep-research-pro", "gemini-deep-research",
})


def _detect_provider(model: str) -> ResearchProvider:
    model_lower = model.lower()
    for m in OPENAI_DEEP_MODELS:
        if m in model_lower:
            return ResearchProvider.OPENAI
    for m in GEMINI_DEEP_MODELS:
        if m in model_lower:
            return ResearchProvider.GEMINI
    return ResearchProvider.GENERIC


def _extract_citations_from_text(text: str) -> List[Citation]:
    citations = []
    url_pattern = re.compile(
        r'https?://[^\s<>\(\)\[\]"\',;]+'
    )
    seen_urls = set()
    for match in url_pattern.finditer(text):
        url = match.group()
        if url in seen_urls:
            continue
        seen_urls.add(url)
        start = max(0, match.start() - 100)
        end = min(len(text), match.end() + 100)
        context = text[start:end].strip()
        title_match = re.search(r'(?:^|\n|\.)\s*([A-Z][^.!?\n]{5,80})', context)
        title = title_match.group(1).strip() if title_match else url[:60]
        citations.append(Citation(
            title=title,
            url=url,
            snippet=context[:200],
            source="web",
        ))
    return citations


class DeepResearchAgent:
    """Multi-step autonomous research agent with citations.

    Supports:
    - OpenAI deep research models (o3-deep-research, o4-mini-deep-research)
    - Gemini deep research models (deep-research-pro)
    - Generic models with multi-step search+synthesize pipeline

    The agent performs:
    1. Query analysis and decomposition
    2. Multi-round web searches
    3. Reasoning over search results
    4. Synthesis into a comprehensive report with citations
    """

    def __init__(
        self,
        model: str = "o4-mini-deep-research",
        instructions: str = "",
        poll_interval: int = 5,
        max_wait_time: int = 3600,
        max_search_rounds: int = 3,
        max_results_per_search: int = 5,
    ):
        self._model = model
        self._provider = _detect_provider(model)
        self._instructions = instructions or (
            "You are a professional researcher. Focus on:\n"
            "- Data-rich insights with specific figures\n"
            "- Reliable sources and citations\n"
            "- Clear, structured responses\n"
            "- Comprehensive coverage of the topic"
        )
        self._poll_interval = poll_interval
        self._max_wait_time = max_wait_time
        self._max_search_rounds = max_search_rounds
        self._max_results_per_search = max_results_per_search
        self._interaction_id = ""

    @property
    def provider(self) -> ResearchProvider:
        return self._provider

    def research(self, query: str, stream: bool = True) -> ResearchResult:
        """Execute deep research on a query.

        Args:
            query: Research query to investigate.
            stream: Whether to stream reasoning steps (default True).

        Returns:
            ResearchResult with report, citations, and metadata.
        """
        start_time = time.time()
        result = ResearchResult(status=ResearchStatus.PENDING)

        try:
            if self._provider == ResearchProvider.OPENAI:
                result = self._research_openai(query, stream)
            elif self._provider == ResearchProvider.GEMINI:
                result = self._research_gemini(query, stream)
            else:
                result = self._research_generic(query, stream)
        except Exception as e:
            logger.error("[DeepResearch] research failed: %s", e, exc_info=True)
            result.status = ResearchStatus.FAILED
            result.error = str(e)

        result.duration_seconds = time.time() - start_time
        return result

    async def aresearch(self, query: str, stream: bool = True) -> ResearchResult:
        """Async version of research."""
        return await asyncio.get_running_loop().run_in_executor(
            None, self.research, query, stream
        )

    def _research_openai(self, query: str, stream: bool) -> ResearchResult:
        """Research using OpenAI deep research API."""
        result = ResearchResult(status=ResearchStatus.SEARCHING)

        try:
            import openai
            client = openai.OpenAI()

            if stream:
                result.reasoning_steps.append(ReasoningStep(
                    summary=f"Starting OpenAI deep research: {query}",
                    step_type="start",
                    timestamp=time.time(),
                ))

            response = client.responses.create(
                model=self._model,
                input=query,
                instructions=self._instructions,
            )

            result.status = ResearchStatus.REASONING

            output_text = ""
            for event in response:
                if hasattr(event, 'type') and event.type == "response.output_text.delta":
                    output_text += event.delta
                    if stream:
                        result.reasoning_steps.append(ReasoningStep(
                            summary=event.delta[:200],
                            step_type="streaming",
                            timestamp=time.time(),
                        ))
                elif hasattr(event, 'type') and event.type == "response.web_search_call":
                    result.web_searches.append(WebSearch(
                        query=getattr(event, 'query', ''),
                        timestamp=time.time(),
                    ))
                    if stream:
                        result.reasoning_steps.append(ReasoningStep(
                            summary=f"Web search: {getattr(event, 'query', '')}",
                            step_type="search",
                            timestamp=time.time(),
                        ))

            result.report = output_text
            result.citations = _extract_citations_from_text(output_text)
            result.status = ResearchStatus.COMPLETED

        except ImportError:
            logger.warning("[DeepResearch] openai package not installed, falling back to generic")
            return self._research_generic(query, stream)
        except Exception as e:
            logger.warning("[DeepResearch] OpenAI deep research failed: %s, falling back to generic", e)
            return self._research_generic(query, stream)

        return result

    def _research_gemini(self, query: str, stream: bool) -> ResearchResult:
        """Research using Gemini deep research API."""
        result = ResearchResult(status=ResearchStatus.SEARCHING)

        try:
            import google.generativeai as genai

            model = genai.GenerativeModel(self._model)

            result.reasoning_steps.append(ReasoningStep(
                summary=f"Starting Gemini deep research: {query}",
                step_type="start",
                timestamp=time.time(),
            ))

            chat = model.start_chat()
            response = chat.send_message(
                f"{self._instructions}\n\nResearch query: {query}\n\n"
                "Provide a comprehensive research report with citations and sources."
            )

            output_text = response.text
            result.report = output_text
            result.citations = _extract_citations_from_text(output_text)
            result.web_searches.append(WebSearch(
                query=query,
                results_count=len(result.citations),
                timestamp=time.time(),
            ))
            result.status = ResearchStatus.COMPLETED

        except ImportError:
            logger.warning("[DeepResearch] google-generativeai package not installed, falling back to generic")
            return self._research_generic(query, stream)
        except Exception as e:
            logger.warning("[DeepResearch] Gemini deep research failed: %s, falling back to generic", e)
            return self._research_generic(query, stream)

        return result

    def _research_generic(self, query: str, stream: bool) -> ResearchResult:
        """Research using generic multi-step search+synthesize pipeline.

        This is the fallback when no deep research API is available.
        Uses XINGZIER AI's SmartLLMClient for model routing.
        """
        result = ResearchResult(status=ResearchStatus.SEARCHING)

        try:
            from ..smart_llm_client import SmartLLMClient
            llm = SmartLLMClient()
            search_results = []
            all_citations = []

            search_queries = self._decompose_query(query, llm)

            for i, search_query in enumerate(search_queries[:self._max_search_rounds]):
                result.reasoning_steps.append(ReasoningStep(
                    summary=f"Search round {i+1}: {search_query}",
                    step_type="search",
                    timestamp=time.time(),
                ))

                round_results = self._execute_search(search_query)
                search_results.extend(round_results)
                result.web_searches.append(WebSearch(
                    query=search_query,
                    results_count=len(round_results),
                    timestamp=time.time(),
                ))

                for sr in round_results:
                    all_citations.append(Citation(
                        title=sr.get("title", ""),
                        url=sr.get("url", ""),
                        snippet=sr.get("snippet", ""),
                        source="web_search",
                    ))

            result.status = ResearchStatus.SYNTHESIZING
            result.reasoning_steps.append(ReasoningStep(
                summary="Synthesizing research findings into report",
                step_type="synthesis",
                timestamp=time.time(),
            ))

            report = self._synthesize(query, search_results, all_citations, llm)
            result.report = report
            result.citations = all_citations
            result.status = ResearchStatus.COMPLETED

        except Exception as e:
            logger.error("[DeepResearch] generic research failed: %s", e, exc_info=True)
            result.status = ResearchStatus.FAILED
            result.error = str(e)

        return result

    def _decompose_query(self, query: str, llm: Any) -> List[str]:
        """Decompose a research query into sub-queries for multi-round search."""
        try:
            prompt = (
                f"Decompose the following research query into 3-5 specific search queries "
                f"that would help gather comprehensive information:\n\n"
                f"Query: {query}\n\n"
                f"Return ONLY a JSON array of search query strings, nothing else."
            )
            response = llm.chat(prompt)
            if isinstance(response, str):
                match = re.search(r'\[.*\]', response, re.DOTALL)
                if match:
                    queries = json.loads(match.group())
                    if isinstance(queries, list):
                        return [str(q) for q in queries[:5]]
        except Exception as e:
            logger.debug("[DeepResearch] query decomposition failed: %s", e)

        return [query]

    def _execute_search(self, query: str) -> List[dict]:
        """Execute a web search and return results."""
        try:
            from ..tools.browser_control import browser_use
            search_url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
            result = browser_use(
                action="navigate",
                url=search_url,
                goal=f"Extract search results for: {query}",
            )
            if isinstance(result, str):
                return [{"title": query, "snippet": result[:500], "url": search_url}]
        except Exception as e:
            logger.debug("[DeepResearch] browser search failed: %s", e)

        try:
            import urllib.request
            import urllib.parse
            encoded_query = urllib.parse.quote(query, safe='')
            search_url = f"https://api.duckduckgo.com/?q={encoded_query}&format=json&no_html=1"
            req = urllib.request.Request(search_url, headers={"User-Agent": "XingzierAI/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                results = []
                for topic in data.get("RelatedTopics", [])[:self._max_results_per_search]:
                    if isinstance(topic, dict) and "Text" in topic:
                        results.append({
                            "title": topic.get("Text", "")[:100],
                            "snippet": topic.get("Text", ""),
                            "url": topic.get("FirstURL", ""),
                        })
                return results
        except Exception as e:
            logger.debug("[DeepResearch] duckduckgo search failed: %s", e)

        return []

    def _synthesize(
        self,
        query: str,
        search_results: List[dict],
        citations: List[Citation],
        llm: Any,
    ) -> str:
        """Synthesize search results into a comprehensive research report."""
        results_text = "\n\n".join(
            f"Source {i+1}: {r.get('title', 'Untitled')}\n"
            f"URL: {r.get('url', 'N/A')}\n"
            f"Content: {r.get('snippet', 'No content')}"
            for i, r in enumerate(search_results)
        )

        citations_text = "\n".join(
            f"[{i+1}] {c.title} - {c.url}"
            for i, c in enumerate(citations)
        )

        prompt = (
            f"{self._instructions}\n\n"
            f"Research Query: {query}\n\n"
            f"Search Results:\n{results_text}\n\n"
            f"Available Citations:\n{citations_text}\n\n"
            f"Please write a comprehensive research report that:\n"
            f"1. Addresses the research query thoroughly\n"
            f"2. Cites sources using [N] notation\n"
            f"3. Includes specific data and figures\n"
            f"4. Provides a clear structure with sections\n"
            f"5. Lists all references at the end\n"
        )

        try:
            response = llm.chat(prompt)
            if isinstance(response, str):
                return response
            return str(response)
        except Exception as e:
            logger.error("[DeepResearch] synthesis failed: %s", e)
            return f"Research synthesis failed: {e}\n\nRaw search results:\n{results_text}"


_global_research_agent: Optional[DeepResearchAgent] = None


def get_deep_research_agent(model: str = "o4-mini-deep-research") -> DeepResearchAgent:
    global _global_research_agent
    if _global_research_agent is None:
        _global_research_agent = DeepResearchAgent(model=model)
    return _global_research_agent
