# -*- coding: utf-8 -*-
"""Unified Priority Queue System with /stop command support.

This module provides a unified priority queue system for managing
concurrent requests across channels and sessions, with support for
the /stop command to cancel ongoing tasks.

Inspired by XINGZIER AI's unified priority queue system.
"""

import asyncio
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

_BACKGROUND_TASKS: set = set()


def _track_background_task(task: asyncio.Task) -> None:
    _BACKGROUND_TASKS.add(task)
    task.add_done_callback(_BACKGROUND_TASKS.discard)


class Priority(Enum):
    """Task priority levels."""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    URGENT = 3
    INTERRUPT = 4


class TaskStatus(Enum):
    """Task execution status."""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    INTERRUPTED = "interrupted"


@dataclass
class QueuedTask:
    """A task in the priority queue."""
    task_id: str
    priority: Priority
    task_fn: Optional[Callable] = field(default=None, repr=False)
    status: TaskStatus = TaskStatus.PENDING
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    channel: str = "default"
    session_id: str = "default"
    user_id: str = "default"
    metadata: Dict[str, Any] = field(default_factory=dict)
    _cancel_event: Optional[asyncio.Event] = field(default=None, repr=False)


@dataclass
class QueueStats:
    """Queue statistics."""
    total_tasks: int = 0
    completed_tasks: int = 0
    failed_tasks: int = 0
    cancelled_tasks: int = 0
    current_running: int = 0
    total_wait_time: float = 0.0
    total_execution_time: float = 0.0


class PriorityQueue:
    """
    Unified priority queue system.

    Features:
    - Priority-based task ordering
    - Per-channel, per-session queues
    - /stop command support to cancel tasks
    - Task timeout handling
    - Resource budgets (token/cost/duration)

    Usage:
        queue = PriorityQueue()
        task_id = await queue.enqueue(task_fn, priority=Priority.HIGH)
        await queue.stop(task_id)  # Cancel the task
    """

    def __init__(
        self,
        max_concurrent: int = 5,
        default_timeout: Optional[float] = None,
    ):
        """Initialize the priority queue.

        Args:
            max_concurrent: Maximum concurrent tasks.
            default_timeout: Default task timeout in seconds.
        """
        self._queues: Dict[str, List[QueuedTask]] = defaultdict(list)
        self._running_tasks: Dict[str, QueuedTask] = {}
        self._completed_tasks: Dict[str, QueuedTask] = {}
        self._lock = asyncio.Lock()
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._max_concurrent = max_concurrent
        self._default_timeout = default_timeout
        self._stats = QueueStats()
        self._stop_events: Dict[str, asyncio.Event] = {}
        self._task_handles: Dict[str, asyncio.Task] = {}
        self._MAX_COMPLETED = 200

    async def enqueue(
        self,
        task_fn: Callable,
        priority: Priority = Priority.NORMAL,
        channel: str = "default",
        session_id: str = "default",
        user_id: str = "default",
        timeout: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Enqueue a task for execution.

        Args:
            task_fn: Async function to execute.
            priority: Task priority level.
            channel: Channel identifier.
            session_id: Session identifier.
            user_id: User identifier.
            timeout: Task timeout in seconds.
            metadata: Additional task metadata.

        Returns:
            Task ID.
        """
        task_id = f"task_{uuid.uuid4().hex[:12]}"
        queue_key = f"{channel}:{session_id}"

        task = QueuedTask(
            task_id=task_id,
            priority=priority,
            task_fn=task_fn,
            channel=channel,
            session_id=session_id,
            user_id=user_id,
            metadata=metadata or {},
        )
        task._cancel_event = asyncio.Event()
        task.timeout = timeout or self._default_timeout

        async with self._lock:
            self._queues[queue_key].append(task)
            self._queues[queue_key].sort(
                key=lambda t: (t.priority.value, t.created_at),
                reverse=True,
            )
            self._stop_events[task_id] = asyncio.Event()
            self._stats.total_tasks += 1

        logger.info(
            f"Enqueued task {task_id} with priority {priority.name} "
            f"for {channel}:{session_id}"
        )

        task = asyncio.create_task(self._process_queue(queue_key))
        _track_background_task(task)

        return task_id

    async def _process_queue(self, queue_key: str) -> None:
        """Process tasks in the queue."""
        while True:
            async with self._lock:
                if not self._queues[queue_key]:
                    del self._queues[queue_key]
                    return

                task = self._queues[queue_key].pop(0)
                task.status = TaskStatus.RUNNING
                task.started_at = time.time()
                self._running_tasks[task.task_id] = task
                self._stats.current_running += 1

            try:
                await self._execute_task(task)
            finally:
                async with self._lock:
                    self._stats.current_running -= 1

    async def _execute_task(self, task: QueuedTask) -> None:
        """Execute a task with cancellation support."""
        cancel_event = self._stop_events.get(task.task_id)
        if not cancel_event:
            cancel_event = asyncio.Event()

        stop_task = asyncio.create_task(cancel_event.wait())

        try:
            result = await asyncio.shield(
                asyncio.wait_for(
                    task.task_fn(task),
                    timeout=task.timeout,
                ),
                timeout=task.timeout + 5,
            )

            async with self._lock:
                task.status = TaskStatus.COMPLETED
                task.result = result
                task.completed_at = time.time()
                self._completed_tasks[task.task_id] = task
                self._stats.completed_tasks += 1
                self._stats.total_execution_time += (
                    task.completed_at - task.started_at
                )
                self._cleanup_completed()

            logger.info(f"Task {task.task_id} completed successfully")

        except asyncio.CancelledError:
            async with self._lock:
                if task.status == TaskStatus.RUNNING:
                    task.status = TaskStatus.INTERRUPTED
                    task.completed_at = time.time()
                    self._stats.cancelled_tasks += 1
                self._stop_events.pop(task.task_id, None)
                self._task_handles.pop(task.task_id, None)

            logger.info(f"Task {task.task_id} was interrupted")

        except asyncio.TimeoutError:
            async with self._lock:
                task.status = TaskStatus.FAILED
                task.error = "Task timed out"
                task.completed_at = time.time()
                self._completed_tasks[task.task_id] = task
                self._stats.failed_tasks += 1

            logger.warning(f"Task {task.task_id} timed out")

        except Exception as e:
            async with self._lock:
                task.status = TaskStatus.FAILED
                task.error = str(e)
                task.completed_at = time.time()
                self._completed_tasks[task.task_id] = task
                self._stats.failed_tasks += 1

            logger.error(f"Task {task.task_id} failed: {e}")

        finally:
            stop_task.cancel()
            async with self._lock:
                self._running_tasks.pop(task.task_id, None)
                self._task_handles.pop(task.task_id, None)

    async def stop(
        self,
        task_id: str,
        reason: str = "User requested stop",
    ) -> bool:
        """Stop a running or queued task.

        Args:
            task_id: The task ID to stop.
            reason: Reason for stopping.

        Returns:
            True if task was found and will be stopped.
        """
        async with self._lock:
            cancel_event = self._stop_events.get(task_id)
            if cancel_event:
                cancel_event.set()

            for queue_key, queue in self._queues.items():
                for i, task in enumerate(queue):
                    if task.task_id == task_id:
                        task.status = TaskStatus.CANCELLED
                        task.error = reason
                        task.completed_at = time.time()
                        queue.pop(i)
                        self._completed_tasks[task_id] = task
                        self._stats.cancelled_tasks += 1
                        logger.info(f"Task {task_id} cancelled: {reason}")
                        return True

            if task_id in self._running_tasks:
                task = self._running_tasks[task_id]
                task.status = TaskStatus.CANCELLED
                task.error = reason
                task.completed_at = time.time()
                self._stats.cancelled_tasks += 1
                logger.info(f"Running task {task_id} marked for cancellation")
                return True

        return False

    async def stop_session(
        self,
        channel: str,
        session_id: str,
        reason: str = "Session stopped",
    ) -> List[str]:
        """Stop all tasks for a session.

        Args:
            channel: Channel identifier.
            session_id: Session identifier.
            reason: Reason for stopping.

        Returns:
            List of stopped task IDs.
        """
        queue_key = f"{channel}:{session_id}"
        stopped = []

        async with self._lock:
            queue = self._queues.get(queue_key, [])
            for task in queue:
                task.status = TaskStatus.CANCELLED
                task.error = reason
                task.completed_at = time.time()
                self._completed_tasks[task.task_id] = task
                self._stats.cancelled_tasks += 1
                stopped.append(task.task_id)

                cancel_event = self._stop_events.get(task.task_id)
                if cancel_event:
                    cancel_event.set()

            self._queues[queue_key] = []

        logger.info(
            f"Stopped {len(stopped)} tasks for {channel}:{session_id}"
        )
        return stopped

    async def stop_channel(
        self,
        channel: str,
        reason: str = "Channel stopped",
    ) -> List[str]:
        """Stop all tasks for a channel.

        Args:
            channel: Channel identifier.
            reason: Reason for stopping.

        Returns:
            List of stopped task IDs.
        """
        stopped = []

        async with self._lock:
            queue_keys = [
                k for k in self._queues.keys() if k.startswith(f"{channel}:")
            ]

            for queue_key in queue_keys:
                queue = self._queues.get(queue_key, [])
                for task in queue:
                    task.status = TaskStatus.CANCELLED
                    task.error = reason
                    task.completed_at = time.time()
                    self._completed_tasks[task.task_id] = task
                    self._stats.cancelled_tasks += 1
                    stopped.append(task.task_id)

                    cancel_event = self._stop_events.get(task.task_id)
                    if cancel_event:
                        cancel_event.set()

                self._queues[queue_key] = []

        logger.info(f"Stopped {len(stopped)} tasks for channel {channel}")
        return stopped

    def get_task_status(self, task_id: str) -> Optional[TaskStatus]:
        """Get the status of a task.

        Args:
            task_id: The task ID.

        Returns:
            TaskStatus or None if not found.
        """
        for queue in self._queues.values():
            for task in queue:
                if task.task_id == task_id:
                    return task.status

        if task_id in self._running_tasks:
            return self._running_tasks[task_id].status

        if task_id in self._completed_tasks:
            return self._completed_tasks[task_id].status

        return None

    def _cleanup_completed(self):
        if len(self._completed_tasks) > self._MAX_COMPLETED:
            sorted_ids = sorted(
                self._completed_tasks.keys(),
                key=lambda tid: self._completed_tasks[tid].completed_at or 0,
            )
            for tid in sorted_ids[:len(self._completed_tasks) - self._MAX_COMPLETED]:
                del self._completed_tasks[tid]
                self._stop_events.pop(tid, None)
                self._task_handles.pop(tid, None)

    def get_queue_info(self) -> Dict[str, Any]:
        """Get queue information.

        Returns:
            Dict with queue statistics and state.
        """
        return {
            "max_concurrent": self._max_concurrent,
            "current_running": self._stats.current_running,
            "total_pending": sum(len(q) for q in self._queues.values()),
            "total_completed": len(self._completed_tasks),
            "queues": {
                key: len(queue)
                for key, queue in self._queues.items()
            },
            "stats": {
                "total_tasks": self._stats.total_tasks,
                "completed": self._stats.completed_tasks,
                "failed": self._stats.failed_tasks,
                "cancelled": self._stats.cancelled_tasks,
            },
        }

    def get_session_queue_info(
        self,
        channel: str,
        session_id: str,
    ) -> Dict[str, Any]:
        """Get queue info for a specific session.

        Args:
            channel: Channel identifier.
            session_id: Session identifier.

        Returns:
            Dict with session queue info.
        """
        queue_key = f"{channel}:{session_id}"
        queue = self._queues.get(queue_key, [])

        return {
            "channel": channel,
            "session_id": session_id,
            "pending_count": len(queue),
            "tasks": [
                {
                    "task_id": t.task_id,
                    "priority": t.priority.name,
                    "status": t.status.value,
                    "created_at": t.created_at,
                }
                for t in queue
            ],
        }


class StopCommandMixin:
    """
    Mixin to add /stop command support to agent.

    Usage:
        class MyAgent(StopCommandMixin, ReActAgent):
            def __init__(self, ...):
                super().__init__(...)
                self._init_stop_command(queue=my_queue)
    """

    _STOP_COMMAND = "stop"

    def _init_stop_command(
        self,
        queue: Optional[PriorityQueue] = None,
    ) -> None:
        """Initialize stop command support.

        Args:
            queue: The priority queue to use. If None, uses global queue.
        """
        if queue:
            self._stop_queue = queue
        else:
            self._stop_queue = get_global_stop_queue()

        self._command_handler.SYSTEM_COMMANDS = frozenset(
            self._command_handler.SYSTEM_COMMANDS | {self._STOP_COMMAND}
        )

    async def _process_stop(
        self,
        messages: list,
        args: str = "",
    ) -> Any:
        """Process /stop command.

        Args:
            messages: Current messages.
            args: Command arguments (task_id or session).

        Returns:
            System message with stop result.
        """
        from xingzierai.agentscope_core.message import Msg, TextBlock

        if not args:
            return Msg(
                name=self.name,
                role="assistant",
                content=[TextBlock(
                    type="text",
                    text="**Usage:**\n\n- `/stop` - Stop current task\n- `/stop <task_id>` - Stop specific task\n- `/stop session` - Stop all tasks in current session\n",
                )],
            )

        if args == "session":
            session_id = self._request_context.get("session_id", "default")
            channel = self._request_context.get("channel", "default")
            stopped = await self._stop_queue.stop_session(channel, session_id)
            return Msg(
                name=self.name,
                role="assistant",
                content=[TextBlock(
                    type="text",
                    text=f"**Stopped {len(stopped)} task(s)** in session {session_id}",
                )],
            )

        if args == "all":
            channel = self._request_context.get("channel", "default")
            stopped = await self._stop_queue.stop_channel(channel)
            return Msg(
                name=self.name,
                role="assistant",
                content=[TextBlock(
                    type="text",
                    text=f"**Stopped {len(stopped)} task(s)** in channel {channel}",
                )],
            )

        success = await self._stop_queue.stop(args)
        if success:
            return Msg(
                name=self.name,
                role="assistant",
                content=[TextBlock(
                    type="text",
                    text=f"**Task {args}** has been stopped",
                )],
            )
        else:
            return Msg(
                name=self.name,
                role="assistant",
                content=[TextBlock(
                    type="text",
                    text=f"**Task {args}** not found or already completed",
                )],
            )


_global_queue: Optional[PriorityQueue] = None


def get_global_stop_queue() -> PriorityQueue:
    """Get the global stop queue instance."""
    global _global_queue
    if _global_queue is None:
        _global_queue = PriorityQueue()
    return _global_queue


def set_global_stop_queue(queue: PriorityQueue) -> None:
    """Set the global stop queue instance."""
    global _global_queue
    _global_queue = queue


__all__ = [
    "PriorityQueue",
    "Priority",
    "TaskStatus",
    "QueuedTask",
    "QueueStats",
    "StopCommandMixin",
    "get_global_stop_queue",
    "set_global_stop_queue",
]
