# -*- coding: utf-8 -*-
"""Core Evolution Engine - Code hot-swap with backup and rollback."""

from __future__ import annotations

import importlib
import importlib.util
import logging
import os
import shutil
import sys
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from threading import Lock
from typing import Any, Callable, Dict, Optional, Type

logger = logging.getLogger(__name__)


class EngineStatus(str, Enum):
    IDLE = "idle"
    APPLYING = "applying"
    RELOADING = "reloading"
    ROLLING_BACK = "rolling_back"
    ERROR = "error"
    EMERGENCY_STOP = "emergency_stop"


@dataclass
class PatchResult:
    success: bool
    file_path: str
    backup_path: Optional[str] = None
    error_message: Optional[str] = None
    traceback_str: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    reverted: bool = False


class CodeEvolutionEngine:
    """Core engine for applying code patches with automatic rollback.

    This class provides:
    - Backup of original files before modification
    - Atomic code hot-swap with importlib.reload()
    - Automatic rollback on load error or runtime error
    - Change logging to CHANGELOG.md
    """

    MAX_BACKUPS_PER_FILE = 10
    MAX_CACHED_MODULES = 100
    MAX_PATCHES_PER_HOUR = 20
    MAX_PATCHES_PER_DAY = 100
    RATE_LIMIT_WINDOW_SECONDS = 3600

    def __init__(
        self,
        workspace_dir: Path | None = None,
        backup_dir: str = "backups",
        changelog_path: str = "docs/CHANGELOG.md",
    ):
        self.workspace_dir = workspace_dir or Path.cwd()
        self.backup_dir = self.workspace_dir / backup_dir
        self.changelog_path = self.workspace_dir / changelog_path
        self._status = EngineStatus.IDLE
        self._module_cache: Dict[str, Type] = {}
        self._lock = Lock()
        self._recent_patches: list = []
        self._emergency_stop_active = False
        self._rollback_chain = None
        try:
            from xingzierai.agents.rollback_chain import RollbackChain
            self._rollback_chain = RollbackChain(workspace_dir=str(self.workspace_dir))
        except ImportError:
            pass
        self._reflection_engine = None
        try:
            from xingzierai.agents.reflection_engine import ReflectionEngine
            self._reflection_engine = ReflectionEngine()
        except ImportError:
            pass
        self._competitor_gap_tracker = None
        try:
            from xingzierai.agents.competitor_gap_tracker import CompetitorGapTracker
            self._competitor_gap_tracker = CompetitorGapTracker()
        except ImportError:
            pass
        self._constitutional_core = None
        try:
            from xingzierai.agents.constitutional_core import get_constitutional_core
            self._constitutional_core = get_constitutional_core()
        except Exception:
            pass
        self._governor = None
        try:
            from xingzierai.agents.evolution.governor import EvolutionGovernor
            self._governor = EvolutionGovernor(workspace_dir=self.workspace_dir)
        except Exception:
            pass
        self._safety_guard = None
        try:
            from xingzierai.agents.evolution.safety_guard import ModificationGuard
            self._safety_guard = ModificationGuard()
        except Exception:
            pass

    def emergency_stop(self) -> None:
        """Emergency stop all evolution activities."""
        self._emergency_stop_active = True
        self._status = EngineStatus.EMERGENCY_STOP
        logger.warning("Evolution engine emergency stop activated")

    def reset_emergency_stop(self) -> None:
        """Reset emergency stop flag."""
        self._emergency_stop_active = False
        if self._status == EngineStatus.EMERGENCY_STOP:
            self._status = EngineStatus.IDLE
        logger.info("Evolution engine emergency stop reset")

    def _can_apply_patch(self) -> tuple[bool, str]:
        """Check if a new patch can be applied based on rate limits.

        Returns:
            (can_apply, reason_if_not)
        """
        if self._emergency_stop_active:
            return False, "Emergency stop is active"

        now = time.time()
        self._recent_patches = [
            ts for ts in self._recent_patches
            if now - ts < self.RATE_LIMIT_WINDOW_SECONDS
        ]

        hourly_count = len(self._recent_patches)
        if hourly_count >= self.MAX_PATCHES_PER_HOUR:
            return False, f"Rate limit exceeded: {hourly_count} patches in last hour (max {self.MAX_PATCHES_PER_HOUR})"

        daily_count = sum(1 for ts in self._recent_patches if now - ts < 86400)
        if daily_count >= self.MAX_PATCHES_PER_DAY:
            return False, f"Daily limit exceeded: {daily_count} patches in last 24h (max {self.MAX_PATCHES_PER_DAY})"

        return True, ""

    def _check_constitutional(self, file_path: str, new_code: str):
        """Check proposed patch against Constitutional Core.

        Returns ConstitutionalCheckResult. If constitutional core is not
        available, defaults to ALLOW (fail-open for backward compatibility).
        """
        if self._constitutional_core is None:
            try:
                from xingzierai.agents.constitutional_core import ConstitutionalCheckResult
                return ConstitutionalCheckResult(allowed=True, details="Constitutional core not loaded")
            except ImportError:
                from types import SimpleNamespace
                return SimpleNamespace(allowed=True, details="Constitutional core not loaded", violations=[])

        old_code = None
        try:
            resolved = self._resolve_path(file_path)
            if resolved.exists():
                old_code = resolved.read_text(encoding="utf-8")
        except Exception:
            pass

        return self._constitutional_core.check_mutation(file_path, new_code, old_code)

    def _check_governance(self, file_path: str, new_code: str) -> Optional[PatchResult]:
        """Check with EvolutionGovernor for patch strategy.

        Returns PatchResult if rejected, None if allowed or governor not available.
        """
        if self._governor is None:
            return None

        try:
            patch_request = self._governor.determine_patch_strategy(
                file_path, new_code=new_code,
            )
            if patch_request.strategy.value == "rejected":
                logger.warning(
                    "Patch rejected by Governor: %s", patch_request.reason,
                )
                return PatchResult(
                    success=False,
                    file_path=file_path,
                    error_message=f"Governor rejected: {patch_request.reason}",
                )
            if patch_request.strategy.value == "review_required":
                logger.info(
                    "Patch requires review (Governor): %s", patch_request.reason,
                )
        except Exception as e:
            logger.debug("Governor check failed (allowing): %s", e)
        return None

    def _check_safety_guard(self, file_path: str, new_code: str) -> Optional[PatchResult]:
        """Check with EvolutionSafetyGuard for dangerous patterns.

        Returns PatchResult if denied, None if allowed or guard not available.
        Safety Guard's DENY is final and cannot be overridden.
        """
        if self._safety_guard is None:
            return None

        try:
            from xingzierai.agents.evolution.safety_guard import (
                ModificationRequest, ModificationType, ModificationVerdict,
            )

            old_code = ""
            try:
                resolved = self._resolve_path(file_path)
                if resolved.exists():
                    old_code = resolved.read_text(encoding="utf-8")
            except Exception:
                pass

            lines_added = new_code.count("\n") - old_code.count("\n") if old_code else new_code.count("\n")

            request = ModificationRequest(
                id=f"safety_{hash(file_path) % 100000:05d}",
                target_path=file_path,
                modification_type=ModificationType.CODE_CHANGE,
                description=f"Patch to {file_path}",
                diff_summary=new_code[:2000],
                lines_added=max(lines_added, 0),
                requester="evolution_engine",
            )

            verdict, checks_passed, checks_failed = self._safety_guard.evaluate(request)

            if verdict == ModificationVerdict.DENY:
                logger.critical(
                    "Patch DENIED by Safety Guard: %s", "; ".join(checks_failed),
                )
                return PatchResult(
                    success=False,
                    file_path=file_path,
                    error_message=f"Safety Guard DENIED: {'; '.join(checks_failed)}",
                )

            if verdict == ModificationVerdict.REQUIRE_APPROVAL:
                logger.warning(
                    "Patch requires approval (Safety Guard): %s",
                    "; ".join(checks_failed),
                )

        except Exception as e:
            logger.debug("Safety guard check failed (allowing): %s", e)
        return None

    @property
    def status(self) -> EngineStatus:
        return self._status

    def apply_patch(
        self,
        file_path: str,
        new_code: str,
        target_module: Optional[str] = None,
    ) -> PatchResult:
        """Apply a code patch to a file with backup and automatic rollback.

        Args:
            file_path: Path to the file to patch (absolute or relative)
            new_code: New code content to write
            target_module: Optional module name for importlib.reload()
                       If None, attempts to infer from file_path

        Returns:
            PatchResult with success status and details
        """
        can_apply, reason = self._can_apply_patch()
        if not can_apply:
            logger.warning(f"Patch rejected: {reason}")
            return PatchResult(
                success=False,
                file_path=file_path,
                error_message=f"Patch rejected: {reason}",
            )

        constitutional_result = self._check_constitutional(file_path, new_code)
        if not constitutional_result.allowed:
            logger.critical(
                "Patch rejected by Constitutional Core: %s",
                "; ".join(constitutional_result.violations),
            )
            return PatchResult(
                success=False,
                file_path=file_path,
                error_message=(
                    f"Constitutional violation: "
                    f"{'; '.join(constitutional_result.violations)}"
                ),
            )

        governance_result = self._check_governance(file_path, new_code)
        if governance_result is not None:
            return governance_result

        safety_result = self._check_safety_guard(file_path, new_code)
        if safety_result is not None:
            return safety_result

        self._status = EngineStatus.APPLYING
        with self._lock:
            return self._apply_patch_impl(file_path, new_code, target_module)

    def _apply_patch_impl(self, file_path: str, new_code: str, target_module: Optional[str] = None) -> PatchResult:
        file_path_obj = self._resolve_path(file_path)

        if not file_path_obj.exists():
            return PatchResult(
                success=False,
                file_path=str(file_path_obj),
                error_message=f"File does not exist: {file_path_obj}",
            )

        backup_path = self._create_backup(file_path_obj)
        module_name = target_module or self._infer_module_name(file_path_obj)

        is_valid_syntax, syntax_error = self.verify_syntax(new_code)
        if not is_valid_syntax:
            logger.error(f"Syntax error in new code: {syntax_error}")
            return self._rollback(
                file_path_obj,
                backup_path,
                module_name,
                f"Syntax error before write: {syntax_error}",
            )

        try:
            tmp_path = str(file_path_obj) + ".tmp"
            Path(tmp_path).write_text(new_code, encoding="utf-8")
            os.replace(tmp_path, str(file_path_obj))
            logger.info(f"Applied patch to {file_path_obj}")

            if module_name and module_name in sys.modules:
                self._status = EngineStatus.RELOADING
                reload_result = self._reload_module(module_name)
                if not reload_result:
                    return self._rollback(
                        file_path_obj,
                        backup_path,
                        module_name,
                        "Module reload failed after patch",
                    )

            self._status = EngineStatus.IDLE
            self._recent_patches.append(time.time())
            return PatchResult(
                success=True,
                file_path=str(file_path_obj),
                backup_path=str(backup_path),
            )

        except SyntaxError as e:
            logger.error(f"Syntax error in patched code: {e}")
            return self._rollback(
                file_path_obj,
                backup_path,
                module_name,
                f"Syntax error: {e}",
            )
        except Exception as e:
            logger.error(f"Error applying patch: {e}")
            return self._rollback(
                file_path_obj,
                backup_path,
                module_name,
                str(e),
            )

    def _resolve_path(self, file_path: str) -> Path:
        if Path(file_path).is_absolute():
            return Path(file_path)
        return self.workspace_dir / file_path

    def _infer_module_name(self, file_path: Path) -> Optional[str]:
        try:
            spec = importlib.util.spec_from_file_location(
                "temp_module", file_path
            )
            if spec and spec.origin:
                module_info = importlib.util.module_from_spec(spec)
                return getattr(module_info, "__name__", None)
        except Exception as _import_err:
            logger.debug("Failed to infer module name from %s: %s", file_path, _import_err)
            pass

        rel_path = file_path.relative_to(self.workspace_dir)
        parts = list(rel_path.parts)
        if parts[-1] == "__init__.py":
            parts = parts[:-1]
        elif parts[-1].endswith(".py"):
            parts[-1] = parts[-1][:-3]
        return ".".join(parts)

    def _create_backup(self, file_path: Path) -> Path:
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{file_path.stem}_{timestamp}{file_path.suffix}"
        backup_path = self.backup_dir / backup_name
        shutil.copy2(file_path, backup_path)
        logger.info(f"Created backup at {backup_path}")
        self._rotate_backups(file_path)
        return backup_path

    def _rotate_backups(self, file_path: Path) -> None:
        existing = sorted(
            self.backup_dir.glob(f"{file_path.stem}_*{file_path.suffix}"),
            key=lambda p: p.stat().st_mtime,
        )
        if len(existing) > self.MAX_BACKUPS_PER_FILE:
            for old_backup in existing[:len(existing) - self.MAX_BACKUPS_PER_FILE]:
                old_backup.unlink(missing_ok=True)
                logger.debug("Rotated old backup: %s", old_backup)

    def _enforce_cache_limit(self) -> None:
        if len(self._module_cache) <= self.MAX_CACHED_MODULES:
            return
        keys_to_remove = list(self._module_cache.keys())[:len(self._module_cache) - self.MAX_CACHED_MODULES]
        for key in keys_to_remove:
            self._module_cache.pop(key, None)

    def _reload_module(self, module_name: str) -> bool:
        try:
            if module_name in sys.modules:
                old_module = sys.modules[module_name]
                old_code = getattr(old_module, "__loader__", None)
                old_file = getattr(old_code, "file_path", None) if old_code else None

                importlib.reload(old_module)

                if module_name in sys.modules:
                    new_module = sys.modules[module_name]
                    self._module_cache[module_name] = new_module
                    self._enforce_cache_limit()
                    logger.info(f"Reloaded module: {module_name}")
                    return True

            spec = importlib.util.find_spec(module_name)
            if spec and spec.loader:
                module = importlib.import_module(module_name)
                self._module_cache[module_name] = module
                self._enforce_cache_limit()
                logger.info(f"Imported module: {module_name}")
                return True

            return False

        except Exception as e:
            logger.error(f"Failed to reload module {module_name}: {e}")
            traceback.print_exc()
            return False

    def _rollback(
        self,
        file_path: Path,
        backup_path: Path,
        module_name: Optional[str],
        error_message: str,
    ) -> PatchResult:
        self._status = EngineStatus.ROLLING_BACK

        if self._reflection_engine:
            try:
                items = self._reflection_engine.reflect({
                    "goal": f"Patch to {file_path}",
                    "outcome": "failure",
                    "changes": [str(file_path)],
                    "errors": [error_message],
                    "metrics": {},
                })
                if items:
                    self._reflection_engine.auto_convert(items)
            except Exception:
                pass

        try:
            if backup_path.exists():
                shutil.copy2(backup_path, file_path)
                logger.info(f"Rolled back {file_path}")

                if module_name and module_name in sys.modules:
                    importlib.reload(sys.modules[module_name])

            self._status = EngineStatus.ERROR
            return PatchResult(
                success=False,
                file_path=str(file_path),
                backup_path=str(backup_path),
                error_message=error_message,
                traceback_str=traceback.format_exc(),
                reverted=True,
            )
        except Exception as rollback_error:
            self._status = EngineStatus.ERROR
            return PatchResult(
                success=False,
                file_path=str(file_path),
                backup_path=str(backup_path),
                error_message=f"Rollback failed: {rollback_error}. Original error: {error_message}",
                traceback_str=traceback.format_exc(),
                reverted=False,
            )

    def record_change(
        self,
        description: str,
        file_path: Optional[str] = None,
        change_type: str = "code_update",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Record a change to the CHANGELOG.md file.

        Args:
            description: Human-readable description of the change
            file_path: Optional path to the file that was changed
            change_type: Type of change (code_update, config_update, etc.)
            metadata: Optional additional metadata to record
        """
        self.changelog_path.parent.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().isoformat()
        entry_lines = [
            f"## [{timestamp}] {change_type}",
            "",
            f"**Description**: {description}",
            "",
        ]

        if file_path:
            entry_lines.append(f"**File**: `{file_path}`")
            entry_lines.append("")

        if metadata:
            entry_lines.append("**Metadata**:")
            for key, value in metadata.items():
                entry_lines.append(f"- {key}: {value}")
            entry_lines.append("")

        entry_lines.append("---")
        entry_lines.append("")

        if self.changelog_path.exists():
            existing_content = self.changelog_path.read_text(encoding="utf-8")
            if existing_content.strip():
                self.changelog_path.write_text(
                    existing_content + "\n".join(entry_lines),
                    encoding="utf-8",
                )
                return

        self.changelog_path.write_text(
            "# Changelog\n\n" + "\n".join(entry_lines),
            encoding="utf-8",
        )
        logger.info(f"Recorded change in {self.changelog_path}")

        self._append_to_daily_report(
            change_type=change_type,
            description=description,
            file_path=file_path,
            metadata=metadata,
        )

        if self._reflection_engine:
            try:
                items = self._reflection_engine.reflect({
                    "goal": description,
                    "outcome": "success" if change_type != "rollback" else "failure",
                    "changes": [file_path] if file_path else [],
                    "errors": [],
                    "metrics": metadata or {},
                })
                if items:
                    self._reflection_engine.auto_convert(items)
                    logger.info("ReflectionEngine generated %d actionable items", len(items))
            except Exception as e:
                logger.debug("ReflectionEngine integration error: %s", e)

    def _append_to_daily_report(
        self,
        change_type: str,
        description: str,
        file_path: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Append an entry to today's evolution report."""
        try:
            today = datetime.now().strftime("%Y-%m-%d")
            report_dir = self.changelog_path.parent.parent / "evolution_reports"
            report_dir.mkdir(parents=True, exist_ok=True)
            report_path = report_dir / f"{today}.md"

            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            entry = f"\n## [{timestamp}] {change_type}\n\n"
            entry += f"**{description}**\n\n"

            if file_path:
                entry += f"- File: `{file_path}`\n"

            if metadata:
                for key, value in metadata.items():
                    entry += f"- {key}: {value}\n"

            entry += "\n---\n"

            if report_path.exists():
                existing = report_path.read_text(encoding="utf-8")
                report_path.write_text(existing + entry, encoding="utf-8")
            else:
                header = f"# 📊 XINGZIER-AI 进化报告\n\n**日期**: {today}\n\n---\n"
                report_path.write_text(header + entry, encoding="utf-8")

            logger.debug(f"Appended to daily report: {report_path}")

        except Exception as e:
            logger.warning(f"Failed to append to daily report: {e}")

    def verify_syntax(self, code: str) -> tuple[bool, Optional[str]]:
        """Verify Python syntax without writing to disk.

        Args:
            code: Python code to verify

        Returns:
            Tuple of (is_valid, error_message)
        """
        try:
            compile(code, "<string>", "exec")
            return True, None
        except SyntaxError as e:
            return False, f"Line {e.lineno}: {e.msg}"

    def get_loaded_module(self, module_name: str) -> Optional[Type]:
        """Get a currently loaded module from cache.

        Args:
            module_name: Name of the module

        Returns:
            The module class if found in cache, None otherwise
        """
        return self._module_cache.get(module_name)

    def list_backups(self) -> list[Dict[str, Any]]:
        """List all backup files in the backup directory.

        Returns:
            List of backup file info dicts
        """
        if not self.backup_dir.exists():
            return []

        backups = []
        for f in self.backup_dir.iterdir():
            if f.is_file():
                backups.append({
                    "name": f.name,
                    "path": str(f),
                    "size": f.stat().st_size,
                    "modified": datetime.fromtimestamp(
                        f.stat().st_mtime
                    ).isoformat(),
                })

        return sorted(backups, key=lambda x: x["modified"], reverse=True)

    def restore_backup(self, backup_name: str, target_path: Optional[str] = None) -> bool:
        """Restore a specific backup file.

        Args:
            backup_name: Name of the backup file
            target_path: Optional target path to restore to

        Returns:
            True if successful, False otherwise
        """
        backup_path = self.backup_dir / backup_name
        if not backup_path.exists():
            logger.error(f"Backup not found: {backup_path}")
            return False

        try:
            dest_path = Path(target_path) if target_path else None
            if dest_path is None:
                return False

            shutil.copy2(backup_path, dest_path)
            logger.info(f"Restored backup {backup_name} to {dest_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to restore backup: {e}")
            return False


def apply_patch(
    file_path: str,
    new_code: str,
    target_module: Optional[str] = None,
    workspace_dir: Optional[Path] = None,
) -> PatchResult:
    """Convenience function to apply a patch using a singleton engine.

    Args:
        file_path: Path to the file to patch
        new_code: New code content
        target_module: Optional module name for reload
        workspace_dir: Optional workspace directory

    Returns:
        PatchResult with success status
    """
    engine = CodeEvolutionEngine(workspace_dir=workspace_dir)
    return engine.apply_patch(file_path, new_code, target_module)


def record_change(
    description: str,
    file_path: Optional[str] = None,
    workspace_dir: Optional[Path] = None,
) -> None:
    """Convenience function to record a change.

    Args:
        description: Change description
        file_path: Optional file path
        workspace_dir: Optional workspace directory
    """
    engine = CodeEvolutionEngine(workspace_dir=workspace_dir)
    engine.record_change(description, file_path)
