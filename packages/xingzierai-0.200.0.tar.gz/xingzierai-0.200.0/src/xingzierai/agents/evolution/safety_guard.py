# -*- coding: utf-8 -*-
"""Self-Modification Safety Framework - Inspired by SISF (2025).

SISF (Self-Improving Safety Framework) key insight:
- Continuous Self-Adaptation: system autonomously learns from detected breaches
- Generates and deploys new defense policies in response to novel attacks
- Pre-modification checks, modification validation, post-modification verification

This module provides:
1. ModificationGuard: Evaluate and guard self-modification requests
2. SafetyPolicy: Configurable safety policy for self-modifications
3. ModificationAudit: Audit trail for all self-modifications
4. GuardLevel: Permissive/Standard/Strict/Prohibited levels
"""

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from ._utils import atomic_write

logger = logging.getLogger(__name__)


class GuardLevel(str, Enum):
    PERMISSIVE = "permissive"
    STANDARD = "standard"
    STRICT = "strict"
    PROHIBITED = "prohibited"


class ModificationType(str, Enum):
    CODE = "code"
    CONFIGURATION = "configuration"
    BEHAVIOR = "behavior"
    KNOWLEDGE = "knowledge"
    GOALS = "goals"
    PROMPT = "prompt"


class ModificationVerdict(str, Enum):
    ALLOW = "allow"
    REQUIRE_REVIEW = "require_review"
    REQUIRE_APPROVAL = "require_approval"
    DENY = "deny"


@dataclass
class SafetyPolicy:
    guard_level: GuardLevel = GuardLevel.STANDARD
    protected_paths: Set[str] = field(default_factory=lambda: {
        "agents/react_agent.py",
        "agents/managed_agent.py",
        "security/tool_guard/engine.py",
        "agents/evolution/governor.py",
    })
    protected_patterns: Set[str] = field(default_factory=lambda: {
        "eval(", "exec(", "os.system(", "subprocess.",
        "__import__", "open(", "shutil.rmtree",
    })
    max_lines_per_modification: int = 200
    max_files_per_modification: int = 5
    require_test_pass: bool = True
    require_rollback_plan: bool = True
    allowed_modification_types: Set[ModificationType] = field(
        default_factory=lambda: {ModificationType.CODE, ModificationType.CONFIGURATION, ModificationType.PROMPT}
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "guard_level": self.guard_level.value,
            "protected_paths": list(self.protected_paths),
            "max_lines_per_modification": self.max_lines_per_modification,
            "max_files_per_modification": self.max_files_per_modification,
            "require_test_pass": self.require_test_pass,
            "require_rollback_plan": self.require_rollback_plan,
        }


@dataclass
class ModificationRequest:
    id: str = ""
    target_path: str = ""
    modification_type: ModificationType = ModificationType.CODE
    description: str = ""
    diff_summary: str = ""
    lines_added: int = 0
    lines_removed: int = 0
    source: str = ""
    rollback_plan: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ModificationAuditEntry:
    request_id: str = ""
    target_path: str = ""
    modification_type: str = ""
    verdict: str = ""
    guard_level: str = ""
    checks_passed: List[str] = field(default_factory=list)
    checks_failed: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    reviewer: str = "auto"
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "target_path": self.target_path,
            "modification_type": self.modification_type,
            "verdict": self.verdict,
            "guard_level": self.guard_level,
            "checks_passed": self.checks_passed,
            "checks_failed": self.checks_failed,
            "timestamp": self.timestamp,
            "reviewer": self.reviewer,
            "details": self.details,
        }


class ModificationGuard:
    """Evaluate and guard self-modification requests.

    Inspired by SISF's continuous self-adaptation:
    - Pre-modification checks
    - Modification validation
    - Post-modification verification
    - Automatic policy learning from breaches

    Usage:
        guard = ModificationGuard()
        request = ModificationRequest(target_path="agents/react_agent.py", ...)
        verdict, checks = guard.evaluate(request)
        if verdict == ModificationVerdict.ALLOW:
            guard.execute_with_verification(request, apply_fn)
    """

    MAX_AUDIT_ENTRIES = 2000
    MAX_LEARNED_PATTERNS = 200
    MAX_AUDIT_FILE_LINES = 5000

    def __init__(
        self,
        policy: Optional[SafetyPolicy] = None,
        storage_dir: Optional[str] = None,
    ):
        self.policy = policy or SafetyPolicy()
        if storage_dir:
            self._storage_dir = Path(storage_dir)
        else:
            self._storage_dir = Path.home() / ".xingzierai" / "modification_audit"
        self._storage_dir.mkdir(parents=True, exist_ok=True)

        self._audit: List[ModificationAuditEntry] = []
        self._learned_dangerous_patterns: Set[str] = set()
        self._ast_analyzer = None
        try:
            from .ast_safety import ASTSafetyAnalyzer
            self._ast_analyzer = ASTSafetyAnalyzer()
        except Exception:
            pass
        self._load_audit()

    def evaluate(
        self,
        request: ModificationRequest,
    ) -> tuple:
        checks_passed: List[str] = []
        checks_failed: List[str] = []

        if request.modification_type not in self.policy.allowed_modification_types:
            checks_failed.append(f"modification_type_not_allowed:{request.modification_type.value}")
        else:
            checks_passed.append(f"modification_type_allowed:{request.modification_type.value}")

        if request.target_path in self.policy.protected_paths:
            checks_failed.append(f"protected_path:{request.target_path}")
        else:
            checks_passed.append("path_not_protected")

        if request.lines_added > self.policy.max_lines_per_modification:
            checks_failed.append(f"lines_exceeded:{request.lines_added}>{self.policy.max_lines_per_modification}")
        else:
            checks_passed.append("lines_within_limit")

        if request.diff_summary:
            for pattern in self.policy.protected_patterns:
                if pattern in request.diff_summary:
                    checks_failed.append(f"dangerous_pattern:{pattern}")
                    break
            else:
                checks_passed.append("no_dangerous_patterns")

        for pattern in self._learned_dangerous_patterns:
            if pattern in request.diff_summary.lower() or pattern in request.description.lower():
                checks_failed.append(f"learned_dangerous:{pattern}")
                break

        if self._ast_analyzer and request.diff_summary:
            ast_result = self._ast_analyzer.analyze(request.diff_summary)
            if not ast_result.is_safe:
                critical_findings = [
                    f for f in ast_result.findings
                    if f.level.value in ("high", "critical")
                ]
                if critical_findings:
                    for finding in critical_findings[:3]:
                        checks_failed.append(
                            f"ast_threat:{finding.threat}:{finding.level.value}"
                        )
                else:
                    checks_passed.append("ast_analysis_medium_or_low")
            else:
                checks_passed.append("ast_analysis_safe")

        if self.policy.guard_level == GuardLevel.PROHIBITED:
            verdict = ModificationVerdict.DENY
        elif self.policy.guard_level == GuardLevel.STRICT:
            if checks_failed:
                verdict = ModificationVerdict.DENY
            elif request.modification_type in (ModificationType.GOALS, ModificationType.BEHAVIOR):
                verdict = ModificationVerdict.REQUIRE_APPROVAL
            else:
                verdict = ModificationVerdict.REQUIRE_REVIEW
        elif self.policy.guard_level == GuardLevel.STANDARD:
            if any("protected_path" in f or "dangerous_pattern" in f for f in checks_failed):
                verdict = ModificationVerdict.REQUIRE_APPROVAL
            elif checks_failed:
                verdict = ModificationVerdict.REQUIRE_REVIEW
            else:
                verdict = ModificationVerdict.ALLOW
        else:  # PERMISSIVE
            if any("dangerous_pattern" in f for f in checks_failed):
                verdict = ModificationVerdict.REQUIRE_REVIEW
            else:
                verdict = ModificationVerdict.ALLOW

        audit_entry = ModificationAuditEntry(
            request_id=request.id,
            target_path=request.target_path,
            modification_type=request.modification_type.value,
            verdict=verdict.value,
            guard_level=self.policy.guard_level.value,
            checks_passed=checks_passed,
            checks_failed=checks_failed,
            details={"description": request.description[:200]},
        )
        self._record_audit(audit_entry)

        return verdict, checks_passed, checks_failed

    def learn_from_breach(self, pattern: str, description: str = "") -> None:
        if not pattern or len(pattern) < 2 or len(pattern) > 200:
            logger.warning("Invalid pattern length for learn_from_breach: %d", len(pattern) if pattern else 0)
            return
        import re
        try:
            re.compile(pattern)
        except re.error:
            logger.warning("Invalid regex pattern in learn_from_breach: %s", pattern)
            return
        self._learned_dangerous_patterns.add(pattern.lower())
        if len(self._learned_dangerous_patterns) > self.MAX_LEARNED_PATTERNS:
            oldest = sorted(self._learned_dangerous_patterns)[:len(self._learned_dangerous_patterns) - self.MAX_LEARNED_PATTERNS]
            self._learned_dangerous_patterns -= set(oldest)
        logger.info("Learned dangerous pattern: %s (%s)", pattern, description)
        self._persist_learned_patterns()

    def remove_learned_pattern(self, pattern: str) -> bool:
        pattern_lower = pattern.lower()
        if pattern_lower in self._learned_dangerous_patterns:
            self._learned_dangerous_patterns.discard(pattern_lower)
            self._persist_learned_patterns()
            logger.info("Removed learned pattern: %s", pattern)
            return True
        return False

    def get_audit_trail(self, limit: int = 50) -> List[Dict[str, Any]]:
        recent = self._audit[-limit:]
        return [e.to_dict() for e in reversed(recent)]

    def get_stats(self) -> Dict[str, Any]:
        if not self._audit:
            return {
                "total_evaluations": 0,
                "guard_level": self.policy.guard_level.value,
                "learned_patterns": len(self._learned_dangerous_patterns),
            }

        by_verdict: Dict[str, int] = {}
        for entry in self._audit:
            by_verdict[entry.verdict] = by_verdict.get(entry.verdict, 0) + 1

        common_failures: Dict[str, int] = {}
        for entry in self._audit:
            for f in entry.checks_failed:
                common_failures[f] = common_failures.get(f, 0) + 1

        return {
            "total_evaluations": len(self._audit),
            "guard_level": self.policy.guard_level.value,
            "by_verdict": by_verdict,
            "common_failures": dict(sorted(common_failures.items(), key=lambda x: -x[1])[:10]),
            "learned_patterns": len(self._learned_dangerous_patterns),
            "protected_paths": len(self.policy.protected_paths),
        }

    def _record_audit(self, entry: ModificationAuditEntry) -> None:
        self._audit.append(entry)
        if len(self._audit) > self.MAX_AUDIT_ENTRIES:
            self._audit = self._audit[-self.MAX_AUDIT_ENTRIES:]
        self._persist_audit_entry(entry)

    def _persist_audit_entry(self, entry: ModificationAuditEntry) -> None:
        try:
            filepath = self._storage_dir / "audit_trail.jsonl"
            if filepath.exists() and filepath.stat().st_size > 10 * 1024 * 1024:
                lines = filepath.read_text(encoding="utf-8").strip().split("\n")
                trimmed = lines[-self.MAX_AUDIT_FILE_LINES:]
                atomic_write(filepath, "\n".join(trimmed) + "\n")
            with open(filepath, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")
        except Exception as e:
            logger.warning("Failed to persist audit entry: %s", e)

    def _persist_learned_patterns(self) -> None:
        try:
            filepath = self._storage_dir / "learned_patterns.json"
            atomic_write(filepath, json.dumps(list(self._learned_dangerous_patterns), ensure_ascii=False))
        except Exception as e:
            logger.warning("Failed to persist learned patterns: %s", e)

    def _load_audit(self) -> None:
        patterns_file = self._storage_dir / "learned_patterns.json"
        if patterns_file.exists():
            try:
                data = json.loads(patterns_file.read_text(encoding="utf-8"))
                self._learned_dangerous_patterns = set(data)
            except Exception as e:
                logger.warning("Failed to load learned patterns: %s", e)

        audit_file = self._storage_dir / "audit_trail.jsonl"
        if audit_file.exists():
            try:
                lines = audit_file.read_text(encoding="utf-8").strip().split("\n")
                for line in lines[-self.MAX_AUDIT_ENTRIES:]:
                    if line.strip():
                        data = json.loads(line)
                        entry = ModificationAuditEntry(
                            request_id=data.get("request_id", ""),
                            target_path=data.get("target_path", ""),
                            modification_type=data.get("modification_type", ""),
                            verdict=data.get("verdict", ""),
                            guard_level=data.get("guard_level", ""),
                            checks_passed=data.get("checks_passed", []),
                            checks_failed=data.get("checks_failed", []),
                            timestamp=data.get("timestamp", ""),
                            reviewer=data.get("reviewer", "auto"),
                            details=data.get("details", {}),
                        )
                        self._audit.append(entry)
            except Exception as e:
                logger.warning("Failed to load audit trail: %s", e)


_guard_instance: Optional[ModificationGuard] = None


def get_modification_guard() -> ModificationGuard:
    global _guard_instance
    if _guard_instance is None:
        _guard_instance = ModificationGuard()
    return _guard_instance
