# -*- coding: utf-8 -*-
"""Evolution Orchestrator - End-to-end evolution pipeline coordination.

Ties together all evolution components into a single automated pipeline:
Signal Detection -> Governance -> Constitutional Core -> Safety Guard
-> AST Analysis -> Engine -> Meta Verification -> Introspection
-> Calibration -> Coverage Tracking -> L3 Pattern Mining

Each step has a clear rollback path on failure.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class OrchestrationStep(str, Enum):
    SIGNAL_DETECTION = "signal_detection"
    GOVERNANCE = "governance"
    CONSTITUTIONAL_CHECK = "constitutional_check"
    SAFETY_GUARD = "safety_guard"
    AST_ANALYSIS = "ast_analysis"
    ENGINE_APPLY = "engine_apply"
    META_VERIFICATION = "meta_verification"
    INTROSPECTION = "introspection"
    CALIBRATION = "calibration"
    COVERAGE_TRACKING = "coverage_tracking"
    L3_MINING = "l3_mining"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class StepResult:
    step: OrchestrationStep
    success: bool
    message: str = ""
    duration_ms: float = 0.0
    data: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step.value,
            "success": self.success,
            "message": self.message[:200],
            "duration_ms": round(self.duration_ms, 2),
        }


@dataclass
class OrchestrationResult:
    orchestration_id: str
    file_path: str
    new_code: str
    steps: List[StepResult] = field(default_factory=list)
    overall_success: bool = False
    failure_step: Optional[OrchestrationStep] = None
    failure_reason: str = ""
    started_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    total_duration_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "orchestration_id": self.orchestration_id,
            "file_path": self.file_path,
            "overall_success": self.overall_success,
            "failure_step": self.failure_step.value if self.failure_step else None,
            "failure_reason": self.failure_reason[:200],
            "steps": [s.to_dict() for s in self.steps],
            "total_duration_ms": round(self.total_duration_ms, 2),
        }


@dataclass
class OrchestrationStats:
    total_orchestrations: int = 0
    successful: int = 0
    failed: int = 0
    failure_by_step: Dict[str, int] = field(default_factory=dict)
    avg_duration_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_orchestrations": self.total_orchestrations,
            "successful": self.successful,
            "failed": self.failed,
            "failure_by_step": self.failure_by_step,
            "avg_duration_ms": round(self.avg_duration_ms, 2),
        }


class EvolutionOrchestrator:
    """End-to-end evolution pipeline orchestrator.

    Coordinates all evolution components in a serial pipeline with
    clear rollback paths on failure.
    """

    def __init__(self):
        self._engine = None
        self._governor = None
        self._safety_guard = None
        self._constitutional_core = None
        self._meta_verifier = None
        self._coverage_tracker = None
        self._l3_miner = None
        self._stats = OrchestrationStats()
        self._load_components()

    def _load_components(self) -> None:
        try:
            from xingzierai.agents.evolution.engine import CodeEvolutionEngine
            self._engine = CodeEvolutionEngine()
        except Exception as e:
            logger.debug("Engine load failed: %s", e)

        try:
            from xingzierai.agents.constitutional_core import get_constitutional_core
            self._constitutional_core = get_constitutional_core()
        except Exception as e:
            logger.debug("Constitutional core load failed: %s", e)

        try:
            from xingzierai.agents.meta_verifier import MetaVerifier
            self._meta_verifier = MetaVerifier()
        except Exception as e:
            logger.debug("Meta verifier load failed: %s", e)

        try:
            from xingzierai.agents.rule_coverage_tracker import RuleCoverageTracker
            self._coverage_tracker = RuleCoverageTracker()
        except Exception as e:
            logger.debug("Coverage tracker load failed: %s", e)

        try:
            from xingzierai.agents.l3_pattern_miner import L3PatternMiner
            self._l3_miner = L3PatternMiner()
        except Exception as e:
            logger.debug("L3 miner load failed: %s", e)

    def orchestrate(
        self,
        file_path: str,
        new_code: str,
        task_id: Optional[str] = None,
    ) -> OrchestrationResult:
        """Run the full evolution orchestration pipeline.

        Args:
            file_path: Target file path for the patch
            new_code: New code content to apply
            task_id: Optional task ID

        Returns:
            OrchestrationResult with step-by-step results
        """
        orch_id = f"orch_{int(time.time())}_{hash(file_path) % 10000:04d}"
        result = OrchestrationResult(
            orchestration_id=orch_id,
            file_path=file_path,
            new_code=new_code,
        )

        start = time.monotonic()

        # Step 1: Constitutional Check
        step_result = self._step_constitutional(file_path, new_code)
        result.steps.append(step_result)
        if not step_result.success:
            result.failure_step = step_result.step
            result.failure_reason = step_result.message
            self._finalize(result, start, False)
            return result

        # Step 2: Governance
        step_result = self._step_governance(file_path, new_code)
        result.steps.append(step_result)
        if not step_result.success:
            result.failure_step = step_result.step
            result.failure_reason = step_result.message
            self._finalize(result, start, False)
            return result

        # Step 3: Safety Guard + AST Analysis
        step_result = self._step_safety(file_path, new_code)
        result.steps.append(step_result)
        if not step_result.success:
            result.failure_step = step_result.step
            result.failure_reason = step_result.message
            self._finalize(result, start, False)
            return result

        # Step 4: Engine Apply
        step_result = self._step_engine_apply(file_path, new_code)
        result.steps.append(step_result)
        if not step_result.success:
            result.failure_step = step_result.step
            result.failure_reason = step_result.message
            self._finalize(result, start, False)
            return result

        # Step 5: Meta Verification (post-apply)
        step_result = self._step_meta_verification()
        result.steps.append(step_result)

        # Step 6: Coverage Tracking
        step_result = self._step_coverage(file_path, "L0")
        result.steps.append(step_result)

        # Step 7: L3 Mining
        step_result = self._step_l3_mining()
        result.steps.append(step_result)

        result.overall_success = True
        self._finalize(result, start, True)
        return result

    def get_stats(self) -> Dict[str, Any]:
        return self._stats.to_dict()

    def _step_constitutional(self, file_path: str, new_code: str) -> StepResult:
        start = time.monotonic()
        if self._constitutional_core is None:
            return StepResult(
                step=OrchestrationStep.CONSTITUTIONAL_CHECK,
                success=True,
                message="Constitutional core not available, skipping",
                duration_ms=(time.monotonic() - start) * 1000,
            )

        old_code = None
        try:
            resolved = Path(file_path)
            if resolved.exists():
                old_code = resolved.read_text(encoding="utf-8")
        except Exception:
            pass

        check_result = self._constitutional_core.check_mutation(
            file_path, new_code, old_code,
        )
        return StepResult(
            step=OrchestrationStep.CONSTITUTIONAL_CHECK,
            success=check_result.allowed,
            message="; ".join(check_result.violations) if not check_result.allowed else "Constitutional check passed",
            duration_ms=(time.monotonic() - start) * 1000,
        )

    def _step_governance(self, file_path: str, new_code: str) -> StepResult:
        start = time.monotonic()
        if self._engine is None or self._engine._governor is None:
            return StepResult(
                step=OrchestrationStep.GOVERNANCE,
                success=True,
                message="Governor not available, skipping",
                duration_ms=(time.monotonic() - start) * 1000,
            )

        try:
            patch_request = self._engine._governor.determine_patch_strategy(
                file_path, new_code=new_code,
            )
            if patch_request.strategy.value == "rejected":
                return StepResult(
                    step=OrchestrationStep.GOVERNANCE,
                    success=False,
                    message=f"Governor rejected: {patch_request.reason}",
                    duration_ms=(time.monotonic() - start) * 1000,
                )
            return StepResult(
                step=OrchestrationStep.GOVERNANCE,
                success=True,
                message=f"Governor: {patch_request.strategy.value}",
                duration_ms=(time.monotonic() - start) * 1000,
            )
        except Exception as e:
            return StepResult(
                step=OrchestrationStep.GOVERNANCE,
                success=True,
                message=f"Governor error (allowing): {e}",
                duration_ms=(time.monotonic() - start) * 1000,
            )

    def _step_safety(self, file_path: str, new_code: str) -> StepResult:
        start = time.monotonic()
        if self._engine is None or self._engine._safety_guard is None:
            return StepResult(
                step=OrchestrationStep.SAFETY_GUARD,
                success=True,
                message="Safety guard not available, skipping",
                duration_ms=(time.monotonic() - start) * 1000,
            )

        try:
            from xingzierai.agents.evolution.safety_guard import (
                ModificationRequest, ModificationType, ModificationVerdict,
            )

            old_code = ""
            try:
                resolved = Path(file_path)
                if resolved.exists():
                    old_code = resolved.read_text(encoding="utf-8")
            except Exception:
                pass

            lines_added = max(new_code.count("\n") - old_code.count("\n"), 0) if old_code else new_code.count("\n")

            request = ModificationRequest(
                id=f"orch_{hash(file_path) % 100000:05d}",
                target_path=file_path,
                modification_type=ModificationType.CODE,
                description=f"Orchestrated patch to {file_path}",
                diff_summary=new_code[:2000],
                lines_added=lines_added,
            )

            verdict, passed, failed = self._engine._safety_guard.evaluate(request)

            if verdict == ModificationVerdict.DENY:
                return StepResult(
                    step=OrchestrationStep.SAFETY_GUARD,
                    success=False,
                    message=f"Safety Guard DENIED: {'; '.join(failed)}",
                    duration_ms=(time.monotonic() - start) * 1000,
                )

            return StepResult(
                step=OrchestrationStep.SAFETY_GUARD,
                success=True,
                message=f"Safety Guard: {verdict.value}",
                duration_ms=(time.monotonic() - start) * 1000,
            )
        except Exception as e:
            return StepResult(
                step=OrchestrationStep.SAFETY_GUARD,
                success=True,
                message=f"Safety guard error (allowing): {e}",
                duration_ms=(time.monotonic() - start) * 1000,
            )

    def _step_engine_apply(self, file_path: str, new_code: str) -> StepResult:
        start = time.monotonic()
        if self._engine is None:
            return StepResult(
                step=OrchestrationStep.ENGINE_APPLY,
                success=False,
                message="Engine not available",
                duration_ms=(time.monotonic() - start) * 1000,
            )

        patch_result = self._engine.apply_patch(file_path, new_code)
        return StepResult(
            step=OrchestrationStep.ENGINE_APPLY,
            success=patch_result.success,
            message=patch_result.error_message or "Patch applied successfully",
            duration_ms=(time.monotonic() - start) * 1000,
        )

    def _step_meta_verification(self) -> StepResult:
        start = time.monotonic()
        if self._meta_verifier is None:
            return StepResult(
                step=OrchestrationStep.META_VERIFICATION,
                success=True,
                message="Meta verifier not available, skipping",
                duration_ms=(time.monotonic() - start) * 1000,
            )

        try:
            from xingzierai.agents.neuro_symbolic_verifier import NeuroSymbolicVerifier
            verifier = NeuroSymbolicVerifier()
            report = self._meta_verifier.run_verification(verifier)
            return StepResult(
                step=OrchestrationStep.META_VERIFICATION,
                success=True,
                message=f"Meta verification: {report.checks_passed}/{report.total_checks_verified} checks passed",
                duration_ms=(time.monotonic() - start) * 1000,
            )
        except Exception as e:
            return StepResult(
                step=OrchestrationStep.META_VERIFICATION,
                success=True,
                message=f"Meta verification error (non-blocking): {e}",
                duration_ms=(time.monotonic() - start) * 1000,
            )

    def _step_coverage(self, file_path: str, tier: str) -> StepResult:
        start = time.monotonic()
        if self._coverage_tracker is None:
            return StepResult(
                step=OrchestrationStep.COVERAGE_TRACKING,
                success=True,
                message="Coverage tracker not available",
                duration_ms=(time.monotonic() - start) * 1000,
            )

        self._coverage_tracker.record(file_path, tier=tier)
        return StepResult(
            step=OrchestrationStep.COVERAGE_TRACKING,
            success=True,
            message="Coverage tracked",
            duration_ms=(time.monotonic() - start) * 1000,
        )

    def _step_l3_mining(self) -> StepResult:
        start = time.monotonic()
        if self._l3_miner is None:
            return StepResult(
                step=OrchestrationStep.L3_MINING,
                success=True,
                message="L3 miner not available",
                duration_ms=(time.monotonic() - start) * 1000,
            )

        return StepResult(
            step=OrchestrationStep.L3_MINING,
            success=True,
            message=f"L3 miner stats: {self._l3_miner.get_stats()['total_l3_interactions']} interactions",
            duration_ms=(time.monotonic() - start) * 1000,
        )

    def _finalize(
        self, result: OrchestrationResult, start: float, success: bool,
    ) -> None:
        result.completed_at = time.time()
        result.total_duration_ms = (time.monotonic() - start) * 1000

        self._stats.total_orchestrations += 1
        if success:
            self._stats.successful += 1
        else:
            self._stats.failed += 1
            if result.failure_step:
                step_name = result.failure_step.value
                self._stats.failure_by_step[step_name] = (
                    self._stats.failure_by_step.get(step_name, 0) + 1
                )

        if self._stats.total_orchestrations > 0:
            self._stats.avg_duration_ms = (
                (self._stats.avg_duration_ms * (self._stats.total_orchestrations - 1)
                 + result.total_duration_ms)
                / self._stats.total_orchestrations
            )
