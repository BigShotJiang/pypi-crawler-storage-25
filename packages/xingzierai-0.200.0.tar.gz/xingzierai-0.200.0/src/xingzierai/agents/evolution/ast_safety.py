# -*- coding: utf-8 -*-
"""AST-Level Safety Analyzer - Code analysis beyond string matching.

Current Safety Guard uses string matching for dangerous patterns, which can
be bypassed via:
- getattr(__builtins__, 'exec')(...)
- import os; os.system(...)
- __import__('subprocess').run(...)

This module uses Python's ast module to perform structural code analysis,
detecting dangerous patterns regardless of how they're invoked.
"""

from __future__ import annotations

import ast
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


class ASTThreatLevel(str, Enum):
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ASTFinding:
    threat: str
    level: ASTThreatLevel
    line: int = 0
    col: int = 0
    description: str = ""
    code_snippet: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "threat": self.threat,
            "level": self.level.value,
            "line": self.line,
            "col": self.col,
            "description": self.description,
            "code_snippet": self.code_snippet[:100],
        }


@dataclass
class ASTAnalysisResult:
    findings: List[ASTFinding] = field(default_factory=list)
    is_safe: bool = True
    max_threat_level: ASTThreatLevel = ASTThreatLevel.SAFE
    analysis_time_ms: float = 0.0
    parse_error: Optional[str] = None
    lines_analyzed: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "findings": [f.to_dict() for f in self.findings],
            "is_safe": self.is_safe,
            "max_threat_level": self.max_threat_level.value,
            "analysis_time_ms": round(self.analysis_time_ms, 2),
            "parse_error": self.parse_error,
            "lines_analyzed": self.lines_analyzed,
        }


DANGEROUS_FUNCTIONS = {
    "eval": ASTThreatLevel.CRITICAL,
    "exec": ASTThreatLevel.CRITICAL,
    "compile": ASTThreatLevel.HIGH,
    "__import__": ASTThreatLevel.HIGH,
    "getattr": ASTThreatLevel.MEDIUM,
    "setattr": ASTThreatLevel.MEDIUM,
    "delattr": ASTThreatLevel.MEDIUM,
    "globals": ASTThreatLevel.MEDIUM,
    "locals": ASTThreatLevel.MEDIUM,
    "vars": ASTThreatLevel.LOW,
    "dir": ASTThreatLevel.LOW,
    "type": ASTThreatLevel.LOW,
    "open": ASTThreatLevel.MEDIUM,
}

DANGEROUS_MODULES = {
    "os.system": ASTThreatLevel.CRITICAL,
    "os.popen": ASTThreatLevel.CRITICAL,
    "os.spawn": ASTThreatLevel.HIGH,
    "os.exec": ASTThreatLevel.CRITICAL,
    "os.remove": ASTThreatLevel.HIGH,
    "os.unlink": ASTThreatLevel.HIGH,
    "os.rmdir": ASTThreatLevel.HIGH,
    "subprocess.run": ASTThreatLevel.HIGH,
    "subprocess.call": ASTThreatLevel.HIGH,
    "subprocess.Popen": ASTThreatLevel.HIGH,
    "subprocess.check_output": ASTThreatLevel.HIGH,
    "shutil.rmtree": ASTThreatLevel.CRITICAL,
    "shutil.copy": ASTThreatLevel.MEDIUM,
    "shutil.move": ASTThreatLevel.MEDIUM,
    "socket.socket": ASTThreatLevel.MEDIUM,
    "pickle.loads": ASTThreatLevel.HIGH,
    "pickle.load": ASTThreatLevel.HIGH,
    "yaml.load": ASTThreatLevel.HIGH,
    "marshal.loads": ASTThreatLevel.HIGH,
}

DANGEROUS_IMPORTS = {
    "subprocess": ASTThreatLevel.HIGH,
    "shutil": ASTThreatLevel.MEDIUM,
    "socket": ASTThreatLevel.MEDIUM,
    "pickle": ASTThreatLevel.HIGH,
    "marshal": ASTThreatLevel.HIGH,
    "ctypes": ASTThreatLevel.HIGH,
    "multiprocessing": ASTThreatLevel.LOW,
}

ATTRIBUTE_ACCESS_PATTERNS = {
    ("__builtins__",): ASTThreatLevel.HIGH,
    ("__import__",): ASTThreatLevel.HIGH,
    ("__class__", "__bases__"): ASTThreatLevel.MEDIUM,
    ("__class__", "__dict__"): ASTThreatLevel.MEDIUM,
    ("__subclasses__",): ASTThreatLevel.MEDIUM,
    ("__globals__",): ASTThreatLevel.HIGH,
    ("__code__",): ASTThreatLevel.MEDIUM,
}


class ASTSafetyAnalyzer:
    """Analyze Python code at AST level for security threats.

    Detects dangerous patterns that string matching misses:
    - Dynamic code execution via eval/exec/compile
    - File system operations via os/subprocess/shutil
    - Network operations via socket
    - Reflection attacks via getattr/__import__/__builtins__
    - Type tampering via __bases__/__dict__/__subclasses__
    """

    ANALYSIS_TIMEOUT_MS = 2000

    def __init__(self):
        self._cache: Dict[str, ASTAnalysisResult] = {}

    def analyze(self, code: str) -> ASTAnalysisResult:
        """Analyze code for security threats at AST level.

        Args:
            code: Python source code to analyze

        Returns:
            ASTAnalysisResult with findings and threat assessment
        """
        start = time.monotonic()

        cache_key = str(hash(code))
        if cache_key in self._cache:
            return self._cache[cache_key]

        result = ASTAnalysisResult()

        try:
            tree = ast.parse(code)
            result.lines_analyzed = code.count("\n") + 1
        except SyntaxError as e:
            result.parse_error = str(e)
            result.is_safe = False
            result.max_threat_level = ASTThreatLevel.LOW
            result.analysis_time_ms = (time.monotonic() - start) * 1000
            return result

        self._visit_tree(tree, code, result)

        unsafe_levels = {ASTThreatLevel.HIGH, ASTThreatLevel.CRITICAL}
        result.is_safe = result.max_threat_level not in unsafe_levels

        result.analysis_time_ms = (time.monotonic() - start) * 1000

        if len(self._cache) < 1000:
            self._cache[cache_key] = result

        return result

    def _visit_tree(self, tree: ast.AST, code: str, result: ASTAnalysisResult) -> None:
        for node in ast.walk(tree):
            self._check_node(node, code, result)

    def _check_node(self, node: ast.AST, code: str, result: ASTAnalysisResult) -> None:
        if isinstance(node, ast.Call):
            self._check_call(node, code, result)
        elif isinstance(node, ast.Import):
            self._check_import(node, code, result)
        elif isinstance(node, ast.ImportFrom):
            self._check_import_from(node, code, result)
        elif isinstance(node, ast.Attribute):
            self._check_attribute(node, code, result)
        elif isinstance(node, ast.Assign):
            self._check_assignment(node, code, result)

    def _check_call(self, node: ast.Call, code: str, result: ASTAnalysisResult) -> None:
        func_name = self._get_func_name(node)
        if func_name:
            if func_name in DANGEROUS_FUNCTIONS:
                level = DANGEROUS_FUNCTIONS[func_name]
                self._add_finding(result, ASTFinding(
                    threat=f"dangerous_function:{func_name}",
                    level=level,
                    line=node.lineno,
                    col=node.col_offset,
                    description=f"Call to dangerous function: {func_name}",
                    code_snippet=self._get_code_line(code, node.lineno),
                ))

            for mod_func, level in DANGEROUS_MODULES.items():
                if func_name.endswith("." + mod_func.split(".")[-1]):
                    if self._call_matches_module(node, mod_func):
                        self._add_finding(result, ASTFinding(
                            threat=f"dangerous_module_call:{mod_func}",
                            level=level,
                            line=node.lineno,
                            col=node.col_offset,
                            description=f"Call to dangerous module function: {mod_func}",
                            code_snippet=self._get_code_line(code, node.lineno),
                        ))

        if isinstance(node.func, ast.Attribute):
            attr = node.func.attr
            if attr.startswith("__") and attr.endswith("__"):
                self._add_finding(result, ASTFinding(
                    threat=f"dunder_access:{attr}",
                    level=ASTThreatLevel.MEDIUM,
                    line=node.lineno,
                    col=node.col_offset,
                    description=f"Access to dunder attribute: {attr}",
                    code_snippet=self._get_code_line(code, node.lineno),
                ))

    def _check_import(self, node: ast.Import, code: str, result: ASTAnalysisResult) -> None:
        for alias in node.names:
            if alias.name in DANGEROUS_IMPORTS:
                level = DANGEROUS_IMPORTS[alias.name]
                self._add_finding(result, ASTFinding(
                    threat=f"dangerous_import:{alias.name}",
                    level=level,
                    line=node.lineno,
                    col=node.col_offset,
                    description=f"Import of dangerous module: {alias.name}",
                    code_snippet=self._get_code_line(code, node.lineno),
                ))

    def _check_import_from(self, node: ast.ImportFrom, code: str, result: ASTAnalysisResult) -> None:
        if node.module and node.module in DANGEROUS_IMPORTS:
            level = DANGEROUS_IMPORTS[node.module]
            self._add_finding(result, ASTFinding(
                threat=f"dangerous_from_import:{node.module}",
                level=level,
                line=node.lineno,
                col=node.col_offset,
                description=f"From-import of dangerous module: {node.module}",
                code_snippet=self._get_code_line(code, node.lineno),
            ))

    def _check_attribute(self, node: ast.Attribute, code: str, result: ASTAnalysisResult) -> None:
        attr_chain = self._get_attr_chain(node)
        for pattern, level in ATTRIBUTE_ACCESS_PATTERNS.items():
            if self._chain_matches_pattern(attr_chain, pattern):
                self._add_finding(result, ASTFinding(
                    threat=f"sensitive_attribute:{'.'.join(attr_chain)}",
                    level=level,
                    line=node.lineno,
                    col=node.col_offset,
                    description=f"Access to sensitive attribute chain: {'.'.join(attr_chain)}",
                    code_snippet=self._get_code_line(code, node.lineno),
                ))

    def _check_assignment(self, node: ast.Assign, code: str, result: ASTAnalysisResult) -> None:
        for target in node.targets:
            if isinstance(target, ast.Attribute):
                if target.attr.startswith("__") and target.attr.endswith("__"):
                    self._add_finding(result, ASTFinding(
                        threat=f"dunder_modification:{target.attr}",
                        level=ASTThreatLevel.HIGH,
                        line=node.lineno,
                        col=node.col_offset,
                        description=f"Modification of dunder attribute: {target.attr}",
                        code_snippet=self._get_code_line(code, node.lineno),
                    ))

    def _get_func_name(self, node: ast.Call) -> Optional[str]:
        if isinstance(node.func, ast.Name):
            return node.func.id
        if isinstance(node.func, ast.Attribute):
            parts = self._get_attr_chain(node.func)
            return ".".join(parts)
        return None

    def _get_attr_chain(self, node: ast.AST) -> List[str]:
        chain = []
        current = node
        while isinstance(current, ast.Attribute):
            chain.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            chain.append(current.id)
        chain.reverse()
        return chain

    def _call_matches_module(self, node: ast.Call, mod_func: str) -> bool:
        parts = mod_func.split(".")
        if len(parts) != 2:
            return False
        if not isinstance(node.func, ast.Attribute):
            return False
        if node.func.attr != parts[1]:
            return False
        if isinstance(node.func.value, ast.Name):
            return node.func.value.id == parts[0]
        return False

    def _chain_matches_pattern(self, chain: List[str], pattern: Tuple[str, ...]) -> bool:
        if len(chain) < len(pattern):
            return False
        for i, p in enumerate(pattern):
            if chain[-(len(pattern) - i)] != p:
                return False
        return True

    def _get_code_line(self, code: str, lineno: int) -> str:
        try:
            lines = code.split("\n")
            if 0 < lineno <= len(lines):
                return lines[lineno - 1].strip()
        except Exception:
            pass
        return ""

    def _add_finding(self, result: ASTAnalysisResult, finding: ASTFinding) -> None:
        result.findings.append(finding)
        level_order = {
            ASTThreatLevel.SAFE: 0,
            ASTThreatLevel.LOW: 1,
            ASTThreatLevel.MEDIUM: 2,
            ASTThreatLevel.HIGH: 3,
            ASTThreatLevel.CRITICAL: 4,
        }
        if level_order.get(finding.level, 0) > level_order.get(result.max_threat_level, 0):
            result.max_threat_level = finding.level
