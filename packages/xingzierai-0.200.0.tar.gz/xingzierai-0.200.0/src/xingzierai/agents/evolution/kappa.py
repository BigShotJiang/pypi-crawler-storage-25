# -*- coding: utf-8 -*-
"""Kappa Experience Pack System - Self-evolving knowledge from failures.

From Hermes Agent's Kappa system:
- Workflow: Task failure → Auto reflection → Extract experience → Generate structured skill doc
- After forming "experience packs", similar problems are solved directly without re-reasoning
- Enterprise deployment: skill library auto-expands with use, reducing 30%+ maintenance cost

This integrates with the existing evolution engine to create
a feedback loop: failure → reflection → experience → skill → reuse.
"""

import asyncio
import json
import logging
import math
import os
import time
import uuid
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from ._utils import atomic_write

logger = logging.getLogger(__name__)


class ExperienceCategory(str, Enum):
    """Categories of experience packs."""
    ERROR_RECOVERY = "error_recovery"
    TOOL_USAGE = "tool_usage"
    TASK_PATTERN = "task_pattern"
    OPTIMIZATION = "optimization"
    WORKFLOW = "workflow"
    ANTI_PATTERN = "anti_pattern"


class ExperienceStatus(str, Enum):
    """Status of an experience pack."""
    DRAFT = "draft"
    VALIDATED = "validated"
    ACTIVE = "active"
    DEPRECATED = "deprecated"


@dataclass
class ExperiencePack:
    """A structured experience pack extracted from task outcomes.

    Key innovation from Kappa: Instead of re-reasoning every time,
    the agent can directly apply learned experience for similar problems.

    V7.4 Upgrade (Iron Law 17): Experience packs now support executable
    function format. When executable_code is set, the pack can be
    directly executed as a Python function via ExecutableSkillManager,
    eliminating the need for LLM re-reasoning.

    Format: def solve(context) -> result  (not "when X, do Y")
    """
    id: str = field(default_factory=lambda: f"exp_{uuid.uuid4().hex[:8]}")
    name: str = ""
    category: ExperienceCategory = ExperienceCategory.TASK_PATTERN
    status: ExperienceStatus = ExperienceStatus.DRAFT
    description: str = ""
    trigger_conditions: List[str] = field(default_factory=list)
    solution: str = ""
    anti_patterns: List[str] = field(default_factory=list)
    pre_conditions: List[str] = field(default_factory=list)
    post_conditions: List[str] = field(default_factory=list)
    source_task_id: Optional[str] = None
    source_error: Optional[str] = None
    success_count: int = 0
    failure_count: int = 0
    confidence: float = 0.0
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    executable_code: Optional[str] = None
    executable_skill_name: Optional[str] = None

    @property
    def is_executable(self) -> bool:
        return self.executable_code is not None and len(self.executable_code.strip()) > 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "category": self.category.value,
            "status": self.status.value,
            "description": self.description,
            "trigger_conditions": self.trigger_conditions,
            "solution": self.solution,
            "anti_patterns": self.anti_patterns,
            "pre_conditions": self.pre_conditions,
            "post_conditions": self.post_conditions,
            "source_task_id": self.source_task_id,
            "source_error": self.source_error,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "confidence": self.confidence,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "metadata": self.metadata,
            "executable_code": self.executable_code,
            "executable_skill_name": self.executable_skill_name,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExperiencePack":
        return cls(
            id=data.get("id", f"exp_{uuid.uuid4().hex[:8]}"),
            name=data.get("name", ""),
            category=ExperienceCategory(data.get("category", "task_pattern")),
            status=ExperienceStatus(data.get("status", "draft")),
            description=data.get("description", ""),
            trigger_conditions=data.get("trigger_conditions", []),
            solution=data.get("solution", ""),
            anti_patterns=data.get("anti_patterns", []),
            pre_conditions=data.get("pre_conditions", []),
            post_conditions=data.get("post_conditions", []),
            source_task_id=data.get("source_task_id"),
            source_error=data.get("source_error"),
            success_count=data.get("success_count", 0),
            failure_count=data.get("failure_count", 0),
            confidence=data.get("confidence", 0.0),
            metadata=data.get("metadata", {}),
            executable_code=data.get("executable_code"),
            executable_skill_name=data.get("executable_skill_name"),
        )


@dataclass
class ReflectionResult:
    """Result of a reflection on a failed task."""
    root_cause: str = ""
    lessons_learned: List[str] = field(default_factory=list)
    trigger_conditions: List[str] = field(default_factory=list)
    proposed_solution: str = ""
    anti_patterns: List[str] = field(default_factory=list)
    confidence: float = 0.0


class KappaEngine:
    """Kappa Self-Evolution Engine.

    Workflow:
    1. Task fails → Trigger reflection
    2. Auto reflection → Extract root cause and lessons
    3. Generate structured experience pack
    4. Validate experience pack
    5. On similar task → Directly apply experience

    This creates a virtuous cycle:
    - More usage → More experience → Better performance
    - Enterprise: 30%+ maintenance cost reduction

    Usage:
        engine = KappaEngine(storage_dir="./experience_packs")

        # Record a failure and reflect
        pack = await engine.reflect_and_create(
            task="Deploy the application",
            error="Port 8080 already in use",
            context={"port": 8080, "service": "web"},
        )

        # Look up relevant experience for a new task
        packs = engine.find_relevant("Deploy the service")
    """

    def __init__(
        self,
        storage_dir: Optional[str] = None,
        llm_fn: Optional[Callable] = None,
        auto_validate_threshold: int = 3,
    ):
        """Initialize Kappa engine.

        Args:
            storage_dir: Directory for persisting experience packs
            llm_fn: LLM function for reflection
            auto_validate_threshold: Successes needed to auto-validate
        """
        if storage_dir:
            self._storage_dir = Path(storage_dir)
        else:
            current = os.path.dirname(os.path.abspath(__file__))
            for _ in range(5):
                parent = os.path.dirname(current)
                if parent == current:
                    break
                if os.path.isfile(os.path.join(current, "pyproject.toml")):
                    break
                current = parent
            self._storage_dir = Path(current) / ".xingzierai" / "experience_packs"

        self.llm_fn = llm_fn
        self.auto_validate_threshold = auto_validate_threshold
        self._packs: Dict[str, ExperiencePack] = {}
        self._embedding_model = self._try_load_embedding_model()
        self._embedding_cache: Dict[str, Any] = {}
        self._tfidf_scorer = None
        self._load_packs()

    MAX_PACKS = 500
    MAX_EMBEDDING_CACHE = 200

    def _enforce_max_packs(self) -> None:
        if len(self._packs) <= self.MAX_PACKS:
            return
        deprecated = [p for p in self._packs.values() if p.status == ExperienceStatus.DEPRECATED]
        deprecated.sort(key=lambda p: p.updated_at)
        for pack in deprecated[:len(self._packs) - self.MAX_PACKS]:
            self._packs.pop(pack.id, None)
            pack_file = self._storage_dir / f"{pack.id}.json"
            if pack_file.exists():
                pack_file.unlink(missing_ok=True)
        if len(self._packs) > self.MAX_PACKS:
            low_conf = sorted(
                [p for p in self._packs.values() if p.status == ExperienceStatus.DRAFT],
                key=lambda p: p.confidence,
            )
            for pack in low_conf[:len(self._packs) - self.MAX_PACKS]:
                self._packs.pop(pack.id, None)

    def _try_load_embedding_model(self):
        try:
            from ..embedding_loader import get_embedder
            loader = get_embedder()
            loader.preload("all-MiniLM-L6-v2")
            if loader.is_available:
                logger.info("Loaded embedding model via EmbeddingLoader (backend=%s)", loader.backend.value)
                return loader
            logger.info("No embedding backend available, using TF-IDF + keyword fallback")
            return None
        except Exception as e:
            logger.debug("Failed to load embedding model: %s", e)
            return None

    def _load_packs(self) -> None:
        """Load experience packs from storage."""
        if not self._storage_dir.exists():
            return

        for filepath in self._storage_dir.glob("*.json"):
            try:
                data = json.loads(filepath.read_text(encoding="utf-8"))
                pack = ExperiencePack.from_dict(data)
                self._packs[pack.id] = pack
            except Exception as e:
                logger.warning(f"Failed to load pack {filepath}: {e}")

        logger.info(f"Loaded {len(self._packs)} experience packs")

    def _save_pack(self, pack: ExperiencePack) -> None:
        self._storage_dir.mkdir(parents=True, exist_ok=True)
        filepath = self._storage_dir / f"{pack.id}.json"
        atomic_write(filepath, json.dumps(pack.to_dict(), indent=2, ensure_ascii=False))
        self._enforce_max_packs()

    async def reflect_and_create(
        self,
        task: str,
        error: str,
        context: Optional[Dict[str, Any]] = None,
        task_id: Optional[str] = None,
    ) -> ExperiencePack:
        """Reflect on a failure and create an experience pack.

        This is the core Kappa workflow:
        Task failure → Auto reflection → Extract experience → Generate structured skill doc

        Args:
            task: Original task description
            error: Error that occurred
            context: Additional context
            task_id: Optional task ID for traceability

        Returns:
            Created experience pack
        """
        reflection = await self._reflect(task, error, context)

        pack = ExperiencePack(
            name=self._generate_name(task, error),
            category=self._categorize(error, reflection),
            status=ExperienceStatus.DRAFT,
            description=reflection.root_cause,
            trigger_conditions=reflection.trigger_conditions,
            solution=reflection.proposed_solution,
            anti_patterns=reflection.anti_patterns,
            pre_conditions=reflection.lessons_learned[:3],
            source_task_id=task_id,
            source_error=error,
            confidence=reflection.confidence,
        )

        self._packs[pack.id] = pack
        self._save_pack(pack)

        logger.info(f"Created experience pack: {pack.name} ({pack.id})")
        return pack

    async def _reflect(
        self,
        task: str,
        error: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> ReflectionResult:
        """Perform reflection on a failure.

        Args:
            task: Original task
            error: Error that occurred
            context: Additional context

        Returns:
            Reflection result
        """
        if self.llm_fn:
            try:
                prompt = (
                    f"Analyze this task failure and extract lessons:\n\n"
                    f"Task: {task}\n"
                    f"Error: {error}\n"
                    f"Context: {json.dumps(context or {}, ensure_ascii=False)}\n\n"
                    f"Provide:\n"
                    f"1. Root cause\n"
                    f"2. Trigger conditions (when would this happen again?)\n"
                    f"3. Proposed solution\n"
                    f"4. Anti-patterns to avoid\n"
                    f"5. Lessons learned\n\n"
                    f"Output as JSON with keys: root_cause, trigger_conditions, "
                    f"proposed_solution, anti_patterns, lessons_learned"
                )

                if asyncio.iscoroutinefunction(self.llm_fn):
                    response = await self.llm_fn(prompt)
                else:
                    response = self.llm_fn(prompt)

                result = self._parse_reflection_response(str(response))
                if result:
                    return result

            except Exception as e:
                logger.warning(f"LLM reflection failed: {e}")

        # Heuristic reflection
        return self._heuristic_reflect(task, error, context)

    def _parse_reflection_response(self, response: str) -> Optional[ReflectionResult]:
        """Parse LLM reflection response."""
        try:
            start = response.find("{")
            end = response.rfind("}") + 1
            if start >= 0 and end > start:
                data = json.loads(response[start:end])
                return ReflectionResult(
                    root_cause=data.get("root_cause", ""),
                    lessons_learned=data.get("lessons_learned", []),
                    trigger_conditions=data.get("trigger_conditions", []),
                    proposed_solution=data.get("proposed_solution", ""),
                    anti_patterns=data.get("anti_patterns", []),
                    confidence=0.7,
                )
        except (json.JSONDecodeError, Exception):
            pass
        return None

    def _heuristic_reflect(
        self,
        task: str,
        error: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> ReflectionResult:
        """Heuristic-based reflection without LLM."""
        error_lower = error.lower()

        trigger_conditions = [f"Task involves: {task[:50]}"]
        anti_patterns = []
        lessons = []

        if "timeout" in error_lower:
            trigger_conditions.append("Long-running operations")
            anti_patterns.append("Assuming operations complete quickly")
            lessons.append("Add timeout handling and retry logic")

        elif "permission" in error_lower or "access" in error_lower:
            trigger_conditions.append("File or resource access operations")
            anti_patterns.append("Assuming permissions are granted")
            lessons.append("Check permissions before accessing resources")

        elif "not found" in error_lower or "404" in error_lower:
            trigger_conditions.append("Resource lookups")
            anti_patterns.append("Assuming resources exist")
            lessons.append("Verify resource existence before use")

        elif "syntax" in error_lower or "parse" in error_lower:
            trigger_conditions.append("Code generation or parsing")
            anti_patterns.append("Generating code without syntax validation")
            lessons.append("Always validate syntax before execution")

        else:
            trigger_conditions.append(f"Similar context to: {error[:50]}")
            lessons.append(f"Handle error: {error[:100]}")

        return ReflectionResult(
            root_cause=error,
            lessons_learned=lessons,
            trigger_conditions=trigger_conditions,
            proposed_solution=f"Add error handling for: {error[:100]}",
            anti_patterns=anti_patterns,
            confidence=0.3,
        )

    def find_relevant(
        self,
        task: str,
        category: Optional[ExperienceCategory] = None,
        min_confidence: float = 0.3,
        max_results: int = 5,
    ) -> List[ExperiencePack]:
        """Find relevant experience packs for a task using semantic retrieval.

        Retrieval strategy (3-tier fallback):
        1. sentence-transformers embedding similarity (if available)
        2. TF-IDF cosine similarity (always available)
        3. Keyword overlap (ultimate fallback)

        Args:
            task: Task description
            category: Optional category filter
            min_confidence: Minimum confidence threshold
            max_results: Maximum results

        Returns:
            List of relevant experience packs
        """
        candidates = [
            p for p in self._packs.values()
            if p.status != ExperienceStatus.DEPRECATED
            and (not category or p.category == category)
            and p.confidence >= min_confidence
        ]

        if not candidates:
            return []

        scored = self._semantic_score(task, candidates)
        scored.sort(key=lambda x: x[1], reverse=True)
        return [pack for pack, _ in scored[:max_results]]

    def _semantic_score(
        self,
        task: str,
        candidates: List[ExperiencePack],
    ) -> List[Tuple[ExperiencePack, float]]:
        if self._embedding_model is not None:
            return self._score_with_embeddings(task, candidates)
        return self._score_with_tfidf(task, candidates)

    def _score_with_embeddings(
        self,
        task: str,
        candidates: List[ExperiencePack],
    ) -> List[Tuple[ExperiencePack, float]]:
        try:
            if task in self._embedding_cache:
                task_emb = self._embedding_cache[task]
            else:
                task_emb = self._embedding_model.encode(task)
                if len(self._embedding_cache) < self.MAX_EMBEDDING_CACHE:
                    self._embedding_cache[task] = task_emb
            scored = []
            for pack in candidates:
                doc = f"{pack.name} {' '.join(pack.trigger_conditions)} {pack.description} {pack.solution}"
                if doc in self._embedding_cache:
                    doc_emb = self._embedding_cache[doc]
                else:
                    doc_emb = self._embedding_model.encode(doc)
                    if len(self._embedding_cache) < self.MAX_EMBEDDING_CACHE:
                        self._embedding_cache[doc] = doc_emb
                sim = self._cosine_sim(task_emb, doc_emb)
                quality = pack.confidence * (pack.success_count / max(pack.success_count + pack.failure_count, 1))
                score = sim * 0.7 + quality * 0.3
                if score > 0:
                    scored.append((pack, score))
            return scored
        except Exception as e:
            logger.debug("Embedding scoring failed, falling back to TF-IDF: %s", e)
            return self._score_with_tfidf(task, candidates)

    def _score_with_tfidf(
        self,
        task: str,
        candidates: List[ExperiencePack],
    ) -> List[Tuple[ExperiencePack, float]]:
        task_tokens = self._tokenize(task)
        if not task_tokens:
            return [(p, p.confidence * 0.5) for p in candidates]

        doc_texts = []
        for pack in candidates:
            doc = f"{pack.name} {' '.join(pack.trigger_conditions)} {pack.description} {pack.solution}"
            doc_texts.append(doc)

        tfidf = _TfidfScorer(doc_texts + [task])
        task_vec = tfidf.vector(len(doc_texts))

        scored = []
        for i, pack in enumerate(candidates):
            doc_vec = tfidf.vector(i)
            sim = self._cosine_sim_sparse(task_vec, doc_vec)

            quality = pack.confidence * (pack.success_count / max(pack.success_count + pack.failure_count, 1))
            score = sim * 0.7 + quality * 0.3

            if score > 0:
                scored.append((pack, score))

        if not scored:
            return self._score_with_keywords(task, candidates)

        return scored

    def _score_with_keywords(
        self,
        task: str,
        candidates: List[ExperiencePack],
    ) -> List[Tuple[ExperiencePack, float]]:
        task_lower = task.lower()
        task_words = set(task_lower.split())
        scored = []

        for pack in candidates:
            score = 0.0
            for condition in pack.trigger_conditions:
                cond_words = set(condition.lower().split())
                overlap = task_words & cond_words
                score += len(overlap) * 0.5
            if pack.name.lower() in task_lower:
                score += 2.0
            for word in task_words:
                if word in pack.description.lower():
                    score += 0.3
            score += pack.confidence * pack.success_count / max(pack.success_count + pack.failure_count, 1)
            if score > 0:
                scored.append((pack, score))

        return scored

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        return [w for w in text.lower().split() if len(w) > 1]

    @staticmethod
    def _cosine_sim(a: List[float], b: List[float]) -> float:
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(x * x for x in b))
        return dot / (na * nb) if na > 0 and nb > 0 else 0.0

    @staticmethod
    def _cosine_sim_sparse(a: Dict[str, float], b: Dict[str, float]) -> float:
        dot = sum(a.get(k, 0) * v for k, v in b.items())
        na = math.sqrt(sum(v * v for v in a.values()))
        nb = math.sqrt(sum(v * v for v in b.values()))
        return dot / (na * nb) if na > 0 and nb > 0 else 0.0

    def record_success(self, pack_id: str) -> None:
        """Record a successful application of an experience pack.

        Args:
            pack_id: Experience pack ID
        """
        pack = self._packs.get(pack_id)
        if not pack:
            return

        pack.success_count += 1
        pack.updated_at = datetime.now()
        pack.confidence = pack.success_count / (pack.success_count + pack.failure_count)

        if pack.status == ExperienceStatus.DRAFT and pack.success_count >= self.auto_validate_threshold:
            pack.status = ExperienceStatus.VALIDATED
            logger.info(f"Experience pack validated: {pack.name}")

        if pack.status == ExperienceStatus.VALIDATED and pack.success_count >= self.auto_validate_threshold * 2:
            pack.status = ExperienceStatus.ACTIVE
            logger.info(f"Experience pack activated: {pack.name}")

        self._save_pack(pack)

    def record_failure(self, pack_id: str) -> None:
        """Record a failed application of an experience pack.

        Args:
            pack_id: Experience pack ID
        """
        pack = self._packs.get(pack_id)
        if not pack:
            return

        pack.failure_count += 1
        pack.updated_at = datetime.now()
        pack.confidence = pack.success_count / max(pack.success_count + pack.failure_count, 1)

        if pack.confidence < 0.2 and pack.success_count + pack.failure_count >= 5:
            pack.status = ExperienceStatus.DEPRECATED
            logger.info(f"Experience pack deprecated: {pack.name}")

        self._save_pack(pack)

    def _generate_name(self, task: str, error: str) -> str:
        """Generate a name for an experience pack."""
        task_short = task[:30].strip()
        error_short = error[:30].strip()
        return f"{task_short} → {error_short}"

    def _categorize(
        self,
        error: str,
        reflection: ReflectionResult,
    ) -> ExperienceCategory:
        """Categorize an experience pack."""
        error_lower = error.lower()

        if any(w in error_lower for w in ["timeout", "deadline", "slow"]):
            return ExperienceCategory.OPTIMIZATION
        if any(w in error_lower for w in ["permission", "access", "denied", "forbidden"]):
            return ExperienceCategory.ANTI_PATTERN
        if any(w in error_lower for w in ["tool", "function", "call"]):
            return ExperienceCategory.TOOL_USAGE
        if any(w in error_lower for w in ["error", "exception", "fail"]):
            return ExperienceCategory.ERROR_RECOVERY
        if any(w in error_lower for w in ["workflow", "step", "process"]):
            return ExperienceCategory.WORKFLOW

        return ExperienceCategory.TASK_PATTERN

    def get_all_packs(self) -> List[ExperiencePack]:
        """Get all experience packs."""
        return list(self._packs.values())

    def get_pack(self, pack_id: str) -> Optional[ExperiencePack]:
        """Get an experience pack by ID."""
        return self._packs.get(pack_id)

    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about experience packs."""
        packs = list(self._packs.values())
        return {
            "total": len(packs),
            "active": sum(1 for p in packs if p.status == ExperienceStatus.ACTIVE),
            "validated": sum(1 for p in packs if p.status == ExperienceStatus.VALIDATED),
            "draft": sum(1 for p in packs if p.status == ExperienceStatus.DRAFT),
            "deprecated": sum(1 for p in packs if p.status == ExperienceStatus.DEPRECATED),
            "total_successes": sum(p.success_count for p in packs),
            "total_failures": sum(p.failure_count for p in packs),
            "semantic_retrieval": self._embedding_model is not None,
            "executable_packs": sum(1 for p in packs if p.is_executable),
            "text_only_packs": sum(1 for p in packs if not p.is_executable),
        }

    def upgrade_to_executable(
        self,
        pack_id: str,
        executable_code: str,
        skill_manager: Optional[Any] = None,
    ) -> Optional[ExperiencePack]:
        """V7.4 Iron Law 17: Upgrade a text experience pack to executable format.

        Converts "when X, do Y" text descriptions into def solve(context) -> result
        executable Python functions. This eliminates LLM re-reasoning for known patterns.

        Args:
            pack_id: Experience pack ID to upgrade
            executable_code: Python code implementing def solve(context) -> result
            skill_manager: Optional ExecutableSkillManager for auto-registration

        Returns:
            Updated experience pack, or None if not found
        """
        pack = self._packs.get(pack_id)
        if not pack:
            return None

        try:
            compile(executable_code, f"<kappa_{pack_id}>", "exec")
        except SyntaxError as e:
            logger.warning("Kappa upgrade_to_executable: syntax error in code: %s", e)
            return None

        pack.executable_code = executable_code
        pack.updated_at = datetime.now()

        if skill_manager is not None:
            try:
                safe_name = f"kappa_{pack.id.replace('-', '_')}"
                meta = skill_manager.upgrade_from_kappa(
                    experience_id=pack.id,
                    name=safe_name,
                    category=pack.category.value,
                    triggers=pack.trigger_conditions,
                    description=pack.description,
                    code=executable_code,
                )
                pack.executable_skill_name = meta.name
                logger.info("Kappa: upgraded pack %s to executable skill '%s'", pack_id, meta.name)
            except Exception as e:
                logger.warning("Kappa: skill registration failed for %s: %s", pack_id, e)

        self._save_pack(pack)
        return pack

    async def execute_pack(
        self,
        pack_id: str,
        context: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        """V7.4: Execute an experience pack's executable code directly.

        If the pack has executable_code, run it directly without LLM.
        Falls back to returning the text solution if not executable.

        Args:
            pack_id: Experience pack ID
            context: Execution context

        Returns:
            Result dict with success/output/error keys, or None if pack not found
        """
        pack = self._packs.get(pack_id)
        if not pack:
            return None

        if pack.is_executable:
            try:
                local_ns: Dict[str, Any] = {}
                exec(pack.executable_code, local_ns)
                solve_fn = local_ns.get("solve")
                if solve_fn is None:
                    return {"success": False, "error": "No solve() function in executable_code", "output": ""}

                if asyncio.iscoroutinefunction(solve_fn):
                    result = await solve_fn(context)
                else:
                    result = solve_fn(context)

                self.record_success(pack_id)
                return {"success": True, "output": str(result), "error": None}

            except Exception as e:
                self.record_failure(pack_id)
                return {"success": False, "error": str(e), "output": ""}

        return {"success": True, "output": pack.solution, "error": None}

    def auto_generate_executable_code(self, pack_id: str) -> Optional[str]:
        """V7.4: Auto-generate executable code from a text-based experience pack.

        Converts text solution patterns into simple if-then Python functions.
        This is a heuristic approach - for complex patterns, use upgrade_to_executable()
        with manually written code.

        Args:
            pack_id: Experience pack ID

        Returns:
            Generated executable code string, or None if not applicable
        """
        pack = self._packs.get(pack_id)
        if not pack or pack.is_executable:
            return None

        if pack.category == ExperienceCategory.ERROR_RECOVERY:
            code = self._generate_error_recovery_code(pack)
        elif pack.category == ExperienceCategory.OPTIMIZATION:
            code = self._generate_optimization_code(pack)
        elif pack.category == ExperienceCategory.TOOL_USAGE:
            code = self._generate_tool_usage_code(pack)
        elif pack.category == ExperienceCategory.TASK_PATTERN:
            code = self._generate_task_pattern_code(pack)
        elif pack.category == ExperienceCategory.WORKFLOW:
            code = self._generate_workflow_code(pack)
        elif pack.category == ExperienceCategory.ANTI_PATTERN:
            code = self._generate_anti_pattern_code(pack)
        else:
            code = self._generate_generic_code(pack)

        if code:
            pack.executable_code = code
            pack.updated_at = datetime.now()
            self._save_pack(pack)

        return code

    def _generate_error_recovery_code(self, pack: ExperiencePack) -> str:
        triggers = pack.trigger_conditions[:3]
        trigger_checks = " or ".join(f'"{t}" in task_lower' for t in triggers)
        anti_checks = " and ".join(f'"{a}" not in task_lower' for a in pack.anti_patterns[:3]) if pack.anti_patterns else "True"
        pre_checks = " and ".join(f'context.get("{p}", False)' for p in pack.pre_conditions[:3]) if pack.pre_conditions else "True"
        return (
            f'def solve(context):\n'
            f'    task = context.get("task", "")\n'
            f'    task_lower = task.lower()\n'
            f'    if ({trigger_checks}) and ({anti_checks}) and ({pre_checks}):\n'
            f'        return {repr(pack.solution)}\n'
            f'    return None\n'
        )

    def _generate_optimization_code(self, pack: ExperiencePack) -> str:
        triggers = pack.trigger_conditions[:3]
        trigger_checks = " or ".join(f'"{t}" in task_lower' for t in triggers)
        return (
            f'def solve(context):\n'
            f'    task = context.get("task", "")\n'
            f'    task_lower = task.lower()\n'
            f'    if {trigger_checks}:\n'
            f'        return {repr(pack.solution)}\n'
            f'    return None\n'
        )

    def _generate_tool_usage_code(self, pack: ExperiencePack) -> str:
        triggers = pack.trigger_conditions[:3]
        trigger_checks = " or ".join(f'"{t}" in task_lower' for t in triggers)
        return (
            f'def solve(context):\n'
            f'    task = context.get("task", "")\n'
            f'    task_lower = task.lower()\n'
            f'    if {trigger_checks}:\n'
            f'        return {repr(pack.solution)}\n'
            f'    return None\n'
        )

    def _generate_task_pattern_code(self, pack: ExperiencePack) -> str:
        triggers = pack.trigger_conditions[:3]
        trigger_checks = " or ".join(f'"{t}" in task_lower' for t in triggers)
        anti_checks = " and ".join(f'"{a}" not in task_lower' for a in pack.anti_patterns[:3]) if pack.anti_patterns else "True"
        return (
            f'def solve(context):\n'
            f'    task = context.get("task", "")\n'
            f'    task_lower = task.lower()\n'
            f'    if ({trigger_checks}) and ({anti_checks}):\n'
            f'        return {repr(pack.solution)}\n'
            f'    return None\n'
        )

    def _generate_workflow_code(self, pack: ExperiencePack) -> str:
        triggers = pack.trigger_conditions[:3]
        trigger_checks = " or ".join(f'"{t}" in task_lower' for t in triggers)
        steps = pack.solution.split("\n") if pack.solution else []
        steps_list = repr([s.strip() for s in steps if s.strip()][:5])
        return (
            f'def solve(context):\n'
            f'    task = context.get("task", "")\n'
            f'    task_lower = task.lower()\n'
            f'    if {trigger_checks}:\n'
            f'        return {steps_list}\n'
            f'    return None\n'
        )

    def _generate_anti_pattern_code(self, pack: ExperiencePack) -> str:
        anti_checks = " or ".join(f'"{a}" in task_lower' for a in pack.anti_patterns[:3]) if pack.anti_patterns else "False"
        return (
            f'def solve(context):\n'
            f'    task = context.get("task", "")\n'
            f'    task_lower = task.lower()\n'
            f'    if {anti_checks}:\n'
            f'        return {repr(pack.solution)}\n'
            f'    return None\n'
        )

    def _generate_generic_code(self, pack: ExperiencePack) -> str:
        triggers = pack.trigger_conditions[:3]
        trigger_checks = " or ".join(f'"{t}" in task_lower' for t in triggers)
        return (
            f'def solve(context):\n'
            f'    task = context.get("task", "")\n'
            f'    task_lower = task.lower()\n'
            f'    if {trigger_checks}:\n'
            f'        return {repr(pack.solution)}\n'
            f'    return None\n'
        )

    def batch_upgrade_to_executable(
        self,
        min_confidence: float = 0.5,
        min_success_count: int = 1,
        categories: Optional[List[ExperienceCategory]] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """V7.4 Iron Law 17: Batch upgrade text experience packs to executable format.

        Scans all non-executable packs that meet quality thresholds and
        auto-generates executable code for them.

        Args:
            min_confidence: Minimum confidence to qualify for upgrade
            min_success_count: Minimum success count to qualify for upgrade
            categories: Optional filter by category
            dry_run: If True, only report what would be upgraded

        Returns:
            Summary of batch upgrade results
        """
        candidates = []
        for pack in self._packs.values():
            if pack.is_executable:
                continue
            if pack.confidence < min_confidence:
                continue
            if pack.success_count < min_success_count:
                continue
            if categories and pack.category not in categories:
                continue
            candidates.append(pack)

        upgraded = []
        failed = []
        skipped = []

        for pack in candidates:
            if dry_run:
                skipped.append({"id": pack.id, "name": pack.name, "category": pack.category.value})
                continue

            code = self.auto_generate_executable_code(pack.id)
            if code:
                upgraded.append({
                    "id": pack.id,
                    "name": pack.name,
                    "category": pack.category.value,
                    "code_length": len(code),
                })
            else:
                failed.append({"id": pack.id, "name": pack.name, "reason": "auto_generation_failed"})

        return {
            "total_candidates": len(candidates),
            "upgraded": len(upgraded),
            "failed": len(failed),
            "skipped_dry_run": len(skipped),
            "details": {
                "upgraded": upgraded,
                "failed": failed,
                "skipped": skipped,
            },
        }


class _TfidfScorer:
    """Lightweight TF-IDF scorer for semantic similarity without external deps."""

    def __init__(self, documents: List[str]):
        self._docs = [self._tokenize(d) for d in documents]
        self._df: Dict[str, int] = defaultdict(int)
        self._tf: List[Dict[str, float]] = []
        n = len(self._docs)
        for tokens in self._docs:
            tf: Dict[str, float] = {}
            token_counts = Counter(tokens)
            total = len(tokens) if tokens else 1
            for token, count in token_counts.items():
                tf[token] = count / total
            self._tf.append(tf)
            for token in set(tokens):
                self._df[token] += 1
        self._idf: Dict[str, float] = {}
        for token, df in self._df.items():
            self._idf[token] = math.log((n + 1) / (df + 1)) + 1.0

    def vector(self, doc_idx: int) -> Dict[str, float]:
        tf = self._tf[doc_idx]
        vec: Dict[str, float] = {}
        for token, tf_val in tf.items():
            vec[token] = tf_val * self._idf.get(token, 1.0)
        return vec

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        return [w for w in text.lower().split() if len(w) > 1]
