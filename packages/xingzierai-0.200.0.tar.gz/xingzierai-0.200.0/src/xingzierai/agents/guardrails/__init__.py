# -*- coding: utf-8 -*-
"""LLM-based Guardrails - Natural language validation criteria evaluated by LLM.

Inspired by PraisonAI's Guardrails system with enhancements for XINGZIER AI:
- Function guardrails: Python functions that programmatically validate outputs
- LLM guardrails: Natural language criteria evaluated by an LLM
- Automatic retries with feedback when validation fails
- Integration with existing ToolGuardMixin and outcomes_evaluator

Usage:
    from xingzierai.agents.guardrails import GuardrailResult, LLMGuardrail, FunctionGuardrail

    # Function guardrail
    def validate_length(output: str) -> GuardrailResult:
        if 100 <= len(output) <= 500:
            return GuardrailResult(success=True)
        return GuardrailResult(success=False, error=f"Output length {len(output)} not in [100, 500]")

    # LLM guardrail
    guardrail = LLMGuardrail(
        criteria="Check if professional, no offensive language, includes 3+ benefits"
    )
    result = guardrail.validate("Some output text...")
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union

logger = logging.getLogger(__name__)


class GuardrailType(Enum):
    FUNCTION = "function"
    LLM = "llm"
    STRING = "string"


@dataclass
class GuardrailResult:
    success: bool = True
    error: str = ""
    message: str = ""
    modified_output: Optional[str] = None
    score: float = 1.0
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "error": self.error,
            "message": self.message,
            "score": self.score,
            "details": self.details,
        }

    @classmethod
    def pass_result(cls, message: str = "", score: float = 1.0) -> GuardrailResult:
        return cls(success=True, message=message, score=score)

    @classmethod
    def fail_result(cls, error: str, score: float = 0.0) -> GuardrailResult:
        return cls(success=False, error=error, score=score)

    @classmethod
    def modify_result(cls, modified_output: str, message: str = "") -> GuardrailResult:
        return cls(success=True, message=message, modified_output=modified_output)


class FunctionGuardrail:
    """Validate output using a Python function.

    The function should accept the output string and return a GuardrailResult
    or a tuple of (success: bool, result_or_error: str).
    """

    def __init__(
        self,
        fn: Callable[[str], Union[GuardrailResult, tuple]],
        name: str = "",
        max_retries: int = 0,
    ):
        self._fn = fn
        self._name = name or fn.__name__
        self._max_retries = max_retries

    @property
    def name(self) -> str:
        return self._name

    @property
    def guardrail_type(self) -> GuardrailType:
        return GuardrailType.FUNCTION

    def validate(self, output: str) -> GuardrailResult:
        try:
            result = self._fn(output)
            if isinstance(result, GuardrailResult):
                return result
            if isinstance(result, tuple) and len(result) == 2:
                success, data = result
                if success:
                    if isinstance(data, str):
                        return GuardrailResult(success=True, modified_output=data)
                    return GuardrailResult(success=True, message=str(data))
                return GuardrailResult(success=False, error=str(data))
            return GuardrailResult(success=bool(result))
        except Exception as e:
            logger.error("[FunctionGuardrail] %s validation error: %s", self._name, e)
            return GuardrailResult(success=False, error=f"Validation error: {e}")


class LLMGuardrail:
    """Validate output using natural language criteria evaluated by an LLM.

    The LLM receives the criteria and the output, then returns a structured
    validation result with pass/fail, score, and feedback.
    """

    def __init__(
        self,
        criteria: str,
        llm_model: str = "gpt-4o-mini",
        temperature: float = 0.1,
        max_tokens: int = 200,
        name: str = "",
    ):
        self._criteria = criteria
        self._llm_model = llm_model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._name = name or f"llm_guardrail_{id(self) % 10000}"

    @property
    def name(self) -> str:
        return self._name

    @property
    def guardrail_type(self) -> GuardrailType:
        return GuardrailType.LLM

    @property
    def criteria(self) -> str:
        return self._criteria

    def validate(self, output: str) -> GuardrailResult:
        try:
            llm_response = self._call_llm(output)
            return self._parse_llm_response(llm_response)
        except Exception as e:
            logger.error("[LLMGuardrail] %s validation error: %s", self._name, e)
            return GuardrailResult(success=False, error=f"LLM validation error: {e}")

    async def avalidate(self, output: str) -> GuardrailResult:
        try:
            llm_response = await self._acall_llm(output)
            return self._parse_llm_response(llm_response)
        except Exception as e:
            logger.error("[LLMGuardrail] %s async validation error: %s", self._name, e)
            return GuardrailResult(success=False, error=f"LLM async validation error: {e}")

    def _call_llm(self, output: str) -> str:
        prompt = self._build_prompt(output)

        try:
            from ..smart_llm_client import SmartLLMClient
            llm = SmartLLMClient()
            response = llm.chat(prompt)
            return str(response) if response else ""
        except ImportError:
            pass

        try:
            import openai
            client = openai.OpenAI()
            response = client.chat.completions.create(
                model=self._llm_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=self._temperature,
                max_tokens=self._max_tokens,
            )
            return response.choices[0].message.content or ""
        except Exception as e:
            logger.warning("[LLMGuardrail] OpenAI call failed: %s", e)
            return ""

    async def _acall_llm(self, output: str) -> str:
        prompt = self._build_prompt(output)

        try:
            import openai
            client = openai.AsyncOpenAI()
            response = await client.chat.completions.create(
                model=self._llm_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=self._temperature,
                max_tokens=self._max_tokens,
            )
            return response.choices[0].message.content or ""
        except Exception as e:
            logger.warning("[LLMGuardrail] Async OpenAI call failed: %s", e)
            return self._call_llm(output)

    def _build_prompt(self, output: str) -> str:
        return (
            "You are a quality assurance evaluator. Evaluate the following output "
            "against the given criteria.\n\n"
            f"CRITERIA:\n{self._criteria}\n\n"
            f"OUTPUT TO EVALUATE:\n{output[:3000]}\n\n"
            "Respond with ONLY a JSON object in this exact format:\n"
            '{"passed": true/false, "score": 0.0-1.0, "feedback": "explanation", '
            '"issues": ["issue1", "issue2"]}\n\n'
            "Do not include any other text besides the JSON object."
        )

    def _parse_llm_response(self, response: str) -> GuardrailResult:
        if not response:
            logger.warning("[LLMGuardrail] %s: LLM returned empty response, defaulting to DENY", self._name)
            return GuardrailResult(
                success=False,
                error="LLM guardrail evaluation failed: empty response",
                score=0.0,
            )

        try:
            brace_depth = 0
            start_idx = -1
            for i, ch in enumerate(response):
                if ch == '{':
                    if brace_depth == 0:
                        start_idx = i
                    brace_depth += 1
                elif ch == '}':
                    brace_depth -= 1
                    if brace_depth == 0 and start_idx >= 0:
                        json_str = response[start_idx:i+1]
                        try:
                            data = json.loads(json_str)
                            break
                        except json.JSONDecodeError:
                            start_idx = -1
                            continue
            else:
                json_str = ""
                data = None

            if data is not None:
                passed = data.get("passed", True)
                score = float(data.get("score", 1.0 if passed else 0.0))
                feedback = data.get("feedback", "")
                issues = data.get("issues", [])

                return GuardrailResult(
                    success=bool(passed),
                    message=feedback,
                    score=score,
                    error="; ".join(issues) if issues else "",
                    details={"issues": issues, "feedback": feedback},
                )
        except (json.JSONDecodeError, ValueError) as e:
            logger.debug("[LLMGuardrail] JSON parse failed: %s", e)

        passed = "passed" in response.lower() or "valid" in response.lower()
        failed = "failed" in response.lower() or "invalid" in response.lower()

        if failed and not passed:
            return GuardrailResult(
                success=False,
                error=response[:500],
                score=0.0,
            )

        return GuardrailResult(
            success=True,
            message=response[:200],
            score=0.7,
        )


class StringGuardrail:
    """Simple string-based guardrail that checks criteria as text patterns."""

    def __init__(self, criteria: str, name: str = ""):
        self._criteria = criteria
        self._name = name or f"string_guardrail_{id(self) % 10000}"

    @property
    def name(self) -> str:
        return self._name

    @property
    def guardrail_type(self) -> GuardrailType:
        return GuardrailType.STRING

    def validate(self, output: str) -> GuardrailResult:
        criteria_lower = self._criteria.lower()
        output_lower = output.lower()

        if "no offensive language" in criteria_lower or "no profanity" in criteria_lower:
            offensive_words_en = ["fuck", "shit", "damn", "ass", "bitch", "crap"]
            offensive_words_zh = ["操", "靠", "妈的", "他妈", "卧槽", "草泥马"]
            output_lower_check = output.lower()
            for word in offensive_words_en:
                if word in output_lower_check:
                    return GuardrailResult(
                        success=False,
                        error=f"Offensive language detected: '{word}'",
                        score=0.0,
                    )
            for word in offensive_words_zh:
                if word in output:
                    return GuardrailResult(
                        success=False,
                        error=f"Offensive language detected",
                        score=0.0,
                    )

        if "professional" in criteria_lower:
            informal_patterns = [r'\blol\b', r'\bomg\b', r'\brofl\b', r'😂{3,}']
            for pattern in informal_patterns:
                if re.search(pattern, output_lower):
                    return GuardrailResult(
                        success=False,
                        error="Output is not professional",
                        score=0.3,
                    )

        if "includes" in criteria_lower:
            numbers = re.findall(r'(\d+)\+', criteria_lower)
            for n in numbers:
                required = int(n)
                if "benefit" in criteria_lower:
                    benefit_patterns = [r'\d+\.', r'- ', r'•']
                    count = sum(len(re.findall(p, output)) for p in benefit_patterns)
                    if count < required:
                        return GuardrailResult(
                            success=False,
                            error=f"Expected {required}+ items, found {count}",
                            score=0.5,
                        )

        return GuardrailResult(success=True, score=1.0)


class GuardrailPipeline:
    """Run multiple guardrails in sequence with retry support.

    Usage:
        pipeline = GuardrailPipeline([
            FunctionGuardrail(validate_length),
            LLMGuardrail("Check if professional and well-structured"),
        ], max_retries=2)

        result = pipeline.validate("Some output text...")
    """

    def __init__(
        self,
        guardrails: List[Union[FunctionGuardrail, LLMGuardrail, StringGuardrail]],
        max_retries: int = 3,
    ):
        self._guardrails = guardrails
        self._max_retries = max_retries
        self._validation_history: List[dict] = []

    def validate(self, output: str) -> GuardrailResult:
        """Validate output through all guardrails.

        Returns the first failing result, or the last passing result.
        """
        best_result = GuardrailResult(success=True)

        for guardrail in self._guardrails:
            result = guardrail.validate(output)

            self._validation_history.append({
                "guardrail": guardrail.name,
                "type": guardrail.guardrail_type.value,
                "success": result.success,
                "score": result.score,
                "timestamp": time.time(),
            })

            if not result.success:
                return result

            if result.modified_output:
                output = result.modified_output

            best_result = result

        if len(self._validation_history) > 200:
            self._validation_history = self._validation_history[-200:]

        return best_result

    async def avalidate(self, output: str) -> GuardrailResult:
        best_result = GuardrailResult(success=True)

        for guardrail in self._guardrails:
            if isinstance(guardrail, LLMGuardrail):
                result = await guardrail.avalidate(output)
            else:
                result = guardrail.validate(output)

            if not result.success:
                return result

            if result.modified_output:
                output = result.modified_output

            best_result = result

        return best_result

    def get_stats(self) -> dict:
        if not self._validation_history:
            return {"total_validations": 0}

        total = len(self._validation_history)
        passed = sum(1 for v in self._validation_history if v.get("success"))
        avg_score = sum(v.get("score", 0) for v in self._validation_history) / max(total, 1)

        return {
            "total_validations": total,
            "passed": passed,
            "failed": total - passed,
            "pass_rate": round(passed / max(total, 1), 3),
            "avg_score": round(avg_score, 3),
            "guardrails": [g.name for g in self._guardrails],
        }


def create_length_guardrail(min_length: int = 10, max_length: int = 10000) -> FunctionGuardrail:
    def validate_length(output: str) -> GuardrailResult:
        length = len(output)
        if min_length <= length <= max_length:
            return GuardrailResult(success=True, score=1.0)
        if length < min_length:
            return GuardrailResult(success=False, error=f"Output too short: {length} < {min_length}")
        return GuardrailResult(success=False, error=f"Output too long: {length} > {max_length}")

    return FunctionGuardrail(validate_length, name="length_guardrail")


def create_format_guardrail(expected_format: str = "json") -> FunctionGuardrail:
    def validate_format(output: str) -> GuardrailResult:
        if expected_format == "json":
            try:
                json.loads(output)
                return GuardrailResult(success=True, score=1.0)
            except json.JSONDecodeError as e:
                return GuardrailResult(success=False, error=f"Invalid JSON: {e}")
        elif expected_format == "markdown":
            if "#" in output or "**" in output or "-" in output:
                return GuardrailResult(success=True, score=0.8)
            return GuardrailResult(success=False, error="Output doesn't appear to be markdown")
        return GuardrailResult(success=True)

    return FunctionGuardrail(validate_format, name=f"{expected_format}_format_guardrail")


def create_content_safety_guardrail() -> LLMGuardrail:
    return LLMGuardrail(
        criteria=(
            "Ensure the content is safe and appropriate:\n"
            "1. No personal attacks or harassment\n"
            "2. No discriminatory or biased statements\n"
            "3. No instructions for harmful activities\n"
            "4. No exposure of private/sensitive information\n"
            "5. Maintains respectful tone throughout"
        ),
        name="content_safety",
    )


def create_quality_guardrail() -> LLMGuardrail:
    return LLMGuardrail(
        criteria=(
            "Evaluate the output quality:\n"
            "1. Is it accurate and factually correct?\n"
            "2. Is it complete and addresses the request?\n"
            "3. Is it clear and well-structured?\n"
            "4. Is the tone appropriate?\n"
            "5. Are there any logical inconsistencies?"
        ),
        name="quality_check",
    )
