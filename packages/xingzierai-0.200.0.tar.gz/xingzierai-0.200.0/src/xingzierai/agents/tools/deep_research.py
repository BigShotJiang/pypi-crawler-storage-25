# -*- coding: utf-8 -*-
"""Deep Research Tool - Expose deep research as an agent tool."""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


def deep_research(query: str, model: str = "o4-mini-deep-research") -> str:
    """Conduct deep multi-step research on a topic with citations.

    This tool performs autonomous research including:
    - Query decomposition into sub-queries
    - Multi-round web searches
    - Reasoning over search results
    - Synthesis into a comprehensive report with citations

    Args:
        query: The research question or topic to investigate.
        model: The deep research model to use (default: o4-mini-deep-research).
            Options: o3-deep-research, o4-mini-deep-research, deep-research-pro

    Returns:
        A comprehensive research report with citations and sources.
    """
    from ..deep_research import DeepResearchAgent

    try:
        agent = DeepResearchAgent(model=model)
        result = agent.research(query, stream=False)

        if result.status.value == "failed":
            return f"Deep research failed: {result.error}"

        output_parts = [result.report]

        if result.citations:
            output_parts.append("\n\n---\n## References / 参考文献\n")
            for i, citation in enumerate(result.citations, 1):
                output_parts.append(
                    f"[{i}] {citation.title}\n"
                    f"    URL: {citation.url}\n"
                    f"    {citation.snippet[:100]}\n"
                )

        if result.web_searches:
            output_parts.append(
                f"\n---\n*Research completed in {result.duration_seconds:.1f}s "
                f"with {len(result.web_searches)} search rounds "
                f"and {len(result.citations)} citations.*\n"
            )

        return "\n".join(output_parts)

    except Exception as e:
        logger.error("[DeepResearchTool] failed: %s", e, exc_info=True)
        return f"Deep research error: {e}"
