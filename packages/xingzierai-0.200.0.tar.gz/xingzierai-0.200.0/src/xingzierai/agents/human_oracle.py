# -*- coding: utf-8 -*-
"""Human Oracle - Out-of-system verification by human observers.

Inspired by Godel's Incompleteness Theorem:
- Any formal system has truths it cannot prove about itself
- Humans can "step outside the system" to see what AI cannot
- Human oracle provides the external perspective that Godel requires

Three trigger modes:
1. FORCED: Core module patches must be human-confirmed
2. CONFIDENCE: SkepticEvaluator confidence < 0.5 triggers human review
3. SAMPLING: Random 5% of APPROVE results sampled for human review
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_ORACLE_DIR = Path.home() / ".xingzierai" / "human_oracle"


class OracleTrigger(str, Enum):
    FORCED = "forced"
    CONFIDENCE = "confidence"
    SAMPLING = "sampling"


class OracleStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


@dataclass
class OracleRequest:
    request_id: str
    trigger: OracleTrigger
    subject_type: str  # "patch", "evaluation", "verification"
    subject_id: str
    subject_description: str
    subject_content: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    status: OracleStatus = OracleStatus.PENDING
    created_at: float = field(default_factory=time.time)
    resolved_at: Optional[float] = None
    resolver: Optional[str] = None
    resolution_note: str = ""
    resolution_verdict: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "trigger": self.trigger.value,
            "subject_type": self.subject_type,
            "subject_id": self.subject_id,
            "subject_description": self.subject_description,
            "status": self.status.value,
            "created_at": self.created_at,
            "resolved_at": self.resolved_at,
            "resolver": self.resolver,
            "resolution_note": self.resolution_note,
            "resolution_verdict": self.resolution_verdict,
        }


@dataclass
class OracleStats:
    total_requests: int = 0
    pending: int = 0
    approved: int = 0
    rejected: int = 0
    expired: int = 0
    forced_requests: int = 0
    confidence_requests: int = 0
    sampling_requests: int = 0
    human_verdict_consistency: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_requests": self.total_requests,
            "pending": self.pending,
            "approved": self.approved,
            "rejected": self.rejected,
            "expired": self.expired,
            "forced_requests": self.forced_requests,
            "confidence_requests": self.confidence_requests,
            "sampling_requests": self.sampling_requests,
            "human_verdict_consistency": round(self.human_verdict_consistency, 4),
        }


class HumanOracle:
    """Human out-of-system oracle for verification.

    Provides the external perspective that Godel's theorem requires.
    Humans can see truths that the system cannot prove about itself.
    """

    CONFIDENCE_THRESHOLD = 0.5
    SAMPLING_RATE = 0.05
    REQUEST_TTL = 86400 * 7  # 7 days

    def __init__(self, oracle_dir: Optional[str] = None):
        self._dir = Path(oracle_dir) if oracle_dir else _ORACLE_DIR
        self._requests: Dict[str, OracleRequest] = {}
        self._stats = OracleStats()
        self._calibration_feedback: List[Dict[str, Any]] = []
        self._load()

    def should_request_human_review(
        self,
        subject_type: str,
        subject_id: str,
        confidence: float = 1.0,
        is_core_module: bool = False,
    ) -> Optional[OracleRequest]:
        """Determine if human review is needed and create request.

        Args:
            subject_type: Type of subject ("patch", "evaluation", "verification")
            subject_id: ID of the subject
            confidence: System's confidence in its decision (0-1)
            is_core_module: Whether the subject involves a core module

        Returns:
            OracleRequest if human review needed, None otherwise
        """
        trigger = None

        if is_core_module:
            trigger = OracleTrigger.FORCED
        elif confidence < self.CONFIDENCE_THRESHOLD:
            trigger = OracleTrigger.CONFIDENCE
        else:
            import random
            if random.random() < self.SAMPLING_RATE:
                trigger = OracleTrigger.SAMPLING

        if trigger is None:
            return None

        request_id = f"oracle_{int(time.time())}_{hash(subject_id) % 10000:04d}"
        request = OracleRequest(
            request_id=request_id,
            trigger=trigger,
            subject_type=subject_type,
            subject_id=subject_id,
            subject_description=f"{subject_type}:{subject_id}",
        )

        self._requests[request_id] = request
        self._stats.total_requests += 1
        self._stats.pending += 1

        if trigger == OracleTrigger.FORCED:
            self._stats.forced_requests += 1
        elif trigger == OracleTrigger.CONFIDENCE:
            self._stats.confidence_requests += 1
        else:
            self._stats.sampling_requests += 1

        self._save()
        return request

    def submit_review(
        self,
        request_id: str,
        verdict: str,
        resolver: str = "human",
        note: str = "",
    ) -> Optional[OracleRequest]:
        """Submit human review for a pending request.

        Args:
            request_id: The oracle request ID
            verdict: "approve" or "reject"
            resolver: Who resolved this (default: "human")
            note: Optional note from the reviewer

        Returns:
            Updated OracleRequest, or None if not found
        """
        request = self._requests.get(request_id)
        if request is None:
            return None

        if request.status != OracleStatus.PENDING:
            return request

        request.resolver = resolver
        request.resolution_note = note
        request.resolution_verdict = verdict
        request.resolved_at = time.time()

        if verdict == "approve":
            request.status = OracleStatus.APPROVED
            self._stats.approved += 1
        else:
            request.status = OracleStatus.REJECTED
            self._stats.rejected += 1

        self._stats.pending -= 1

        self._calibration_feedback.append({
            "request_id": request_id,
            "trigger": request.trigger.value,
            "verdict": verdict,
            "timestamp": time.time(),
        })

        self._update_consistency()
        self._save()
        return request

    def get_pending(self, limit: int = 50) -> List[OracleRequest]:
        """Get pending oracle requests."""
        pending = [
            r for r in self._requests.values()
            if r.status == OracleStatus.PENDING
        ]
        return sorted(pending, key=lambda r: r.created_at)[:limit]

    def get_request(self, request_id: str) -> Optional[OracleRequest]:
        return self._requests.get(request_id)

    def get_stats(self) -> OracleStats:
        return self._stats

    def get_calibration_data(self) -> List[Dict[str, Any]]:
        """Get calibration feedback for ConfidenceCalibrator integration."""
        return self._calibration_feedback[-100:]

    def expire_old_requests(self) -> int:
        """Expire requests older than TTL."""
        now = time.time()
        expired = 0
        for request in self._requests.values():
            if (
                request.status == OracleStatus.PENDING
                and now - request.created_at > self.REQUEST_TTL
            ):
                request.status = OracleStatus.EXPIRED
                self._stats.pending -= 1
                self._stats.expired += 1
                expired += 1
        if expired > 0:
            self._save()
        return expired

    def _update_consistency(self) -> None:
        if len(self._calibration_feedback) < 5:
            return
        recent = self._calibration_feedback[-50:]
        verdict_counts: Dict[str, int] = {}
        for fb in recent:
            v = fb.get("verdict", "")
            verdict_counts[v] = verdict_counts.get(v, 0) + 1
        total = sum(verdict_counts.values())
        if total > 0:
            max_count = max(verdict_counts.values())
            self._stats.human_verdict_consistency = max_count / total

    def _save(self) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            data = {
                "requests": {
                    k: v.to_dict() for k, v in self._requests.items()
                    if v.status == OracleStatus.PENDING
                },
                "stats": self._stats.to_dict(),
                "calibration_feedback": self._calibration_feedback[-100:],
            }
            path = self._dir / "oracle_data.json"
            path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            logger.debug("Failed to save oracle data: %s", e)

    def _load(self) -> None:
        try:
            path = self._dir / "oracle_data.json"
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            for k, v in data.get("requests", {}).items():
                self._requests[k] = OracleRequest(
                    request_id=v.get("request_id", k),
                    trigger=OracleTrigger(v.get("trigger", "forced")),
                    subject_type=v.get("subject_type", ""),
                    subject_id=v.get("subject_id", ""),
                    subject_description=v.get("subject_description", ""),
                    status=OracleStatus(v.get("status", "pending")),
                    created_at=v.get("created_at", 0),
                )
            stats = data.get("stats", {})
            self._stats = OracleStats(
                total_requests=stats.get("total_requests", 0),
                pending=stats.get("pending", 0),
                approved=stats.get("approved", 0),
                rejected=stats.get("rejected", 0),
                expired=stats.get("expired", 0),
            )
            self._calibration_feedback = data.get("calibration_feedback", [])
        except Exception as e:
            logger.debug("Failed to load oracle data: %s", e)


_global_oracle: Optional[HumanOracle] = None


def get_human_oracle() -> HumanOracle:
    """Get or create the global HumanOracle singleton."""
    global _global_oracle
    if _global_oracle is None:
        _global_oracle = HumanOracle()
    return _global_oracle
