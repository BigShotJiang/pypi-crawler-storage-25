#!/usr/bin/env python3 -*-
"""Adaptive Thinking - dynamic reasoning depth based on task difficulty.

Inspired by Claude Adaptive Thinking:
- Estimate task difficulty from input characteristics
- Adjust max_iters, tool access, and reasoning budget accordingly
- Simple tasks get fast responses; complex tasks get deep reasoning

Difficulty signals:
- Input length (shorter = easier)
- Keyword analysis (questions vs commands vs analysis)
- Historical complexity (past similar tasks)
- Tool requirement hints
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class ReasoningEffort(str, Enum):
    MINIMAL = "minimal"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class EffortConfig:
    """Configuration for each reasoning effort level."""
    max_iters: int = 10
    allow_tools: bool = False
    max_tool_calls: int = 0
    reasoning_timeout: int = 30
    auto_continue: bool = False
    context_compression: bool = False


EFFORT_PRESETS = {
    ReasoningEffort.MINIMAL: EffortConfig(
        max_iters=100, allow_tools=True, max_tool_calls=2,
        reasoning_timeout=30, auto_continue=False, context_compression=False,
    ),
    ReasoningEffort.LOW: EffortConfig(
        max_iters=500, allow_tools=True, max_tool_calls=5,
        reasoning_timeout=60, auto_continue=False, context_compression=False,
    ),
    ReasoningEffort.MEDIUM: EffortConfig(
        max_iters=2000, allow_tools=True, max_tool_calls=10,
        reasoning_timeout=120, auto_continue=False, context_compression=False,
    ),
    ReasoningEffort.HIGH: EffortConfig(
        max_iters=5000, allow_tools=True, max_tool_calls=30,
        reasoning_timeout=600, auto_continue=True, context_compression=True,
    ),
}


@dataclass
class DifficultySignals:
    """Signals extracted from input for difficulty estimation."""
    input_length: int = 0
    has_code: bool = False
    has_analysis_request: bool = False
    has_creative_request: bool = False
    has_multi_step: bool = False
    has_tool_hint: bool = False
    question_count: int = 0
    is_greeting: bool = False
    is_simple_question: bool = False


COMPLEXITY_KEYWORDS = {
    "analysis": ["分析", "analyze", "评估", "evaluate", "对比", "compare", "研究", "research"],
    "creative": ["写", "write", "创作", "create", "设计", "design", "生成", "generate"],
    "multi_step": ["步骤", "step", "流程", "process", "方案", "plan", "架构", "architecture"],
    "tool_hint": ["搜索", "search", "执行", "execute", "训练", "train", "查找", "find", "运行", "run"],
    "greeting": ["你好", "hello", "hi", "嗨", "早上好", "good morning"],
    "simple_question": ["是什么", "what is", "是什么意思", "what does", "定义", "definition"],
}

CODE_PATTERNS = [
    r"```", r"def\s+", r"class\s+", r"import\s+", r"function\s+",
    r"if\s*\(", r"for\s+", r"while\s+", r"return\s+",
]


class EffortEstimator:
    """Estimates task difficulty and recommends reasoning effort."""

    def __init__(self):
        self._history: Dict[str, List[ReasoningEffort]] = {}

    def estimate(self, user_input: str, session_id: str = "") -> ReasoningEffort:
        signals = self._extract_signals(user_input)
        score = self._compute_difficulty_score(signals)
        effort = self._score_to_effort(score)

        if session_id:
            self._history.setdefault(session_id, []).append(effort)
            if len(self._history[session_id]) > 100:
                self._history[session_id] = self._history[session_id][-50:]

        logger.debug(f"EffortEstimator: score={score:.2f}, effort={effort.value}, signals={signals}")
        return effort

    def get_config(self, effort: ReasoningEffort) -> EffortConfig:
        return EFFORT_PRESETS[effort]

    def _extract_signals(self, text: str) -> DifficultySignals:
        text_lower = text.lower()
        signals = DifficultySignals(input_length=len(text))

        for pattern in CODE_PATTERNS:
            if re.search(pattern, text):
                signals.has_code = True
                break

        for kw in COMPLEXITY_KEYWORDS["analysis"]:
            if kw in text_lower:
                signals.has_analysis_request = True
                break

        for kw in COMPLEXITY_KEYWORDS["creative"]:
            if kw in text_lower:
                signals.has_creative_request = True
                break

        for kw in COMPLEXITY_KEYWORDS["multi_step"]:
            if kw in text_lower:
                signals.has_multi_step = True
                break

        for kw in COMPLEXITY_KEYWORDS["tool_hint"]:
            if kw in text_lower:
                signals.has_tool_hint = True
                break

        for kw in COMPLEXITY_KEYWORDS["greeting"]:
            if kw in text_lower and len(text) < 30:
                signals.is_greeting = True
                break

        for kw in COMPLEXITY_KEYWORDS["simple_question"]:
            if kw in text_lower and len(text) < 50:
                signals.is_simple_question = True
                break

        signals.question_count = text.count("?") + text.count("？")

        return signals

    def _compute_difficulty_score(self, signals: DifficultySignals) -> float:
        score = 0.0

        if signals.is_greeting:
            return 0.0

        if signals.is_simple_question:
            return 0.15

        score += min(signals.input_length / 500, 1.0) * 0.2

        if signals.has_code:
            score += 0.3
        if signals.has_analysis_request:
            score += 0.25
        if signals.has_creative_request:
            score += 0.2
        if signals.has_multi_step:
            score += 0.3
        if signals.has_tool_hint:
            score += 0.2
        if signals.question_count > 1:
            score += 0.15

        return min(score, 1.0)

    def _score_to_effort(self, score: float) -> ReasoningEffort:
        if score < 0.1:
            return ReasoningEffort.MINIMAL
        elif score < 0.25:
            return ReasoningEffort.LOW
        elif score < 0.5:
            return ReasoningEffort.MEDIUM
        else:
            return ReasoningEffort.HIGH


_global_estimator: Optional[EffortEstimator] = None


def get_effort_estimator() -> EffortEstimator:
    global _global_estimator
    if _global_estimator is None:
        _global_estimator = EffortEstimator()
    return _global_estimator
