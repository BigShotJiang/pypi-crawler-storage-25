# -*- coding: utf-8 -*-
"""Rule Coverage Tracker - Measures L0 rule coverage and identifies blind spots.

Inspired by Penrose's Cerebellum Argument:
- Cerebellum has 4x neurons but 0 consciousness
- Computation throughput != understanding
- Rule coverage (not LLM call volume) is the true measure of system intelligence

Key metrics:
- Intent coverage rate: % of user intent categories hit by L0 rules
- Pattern blind spots: Input patterns that consistently fall to L3
- Rule redundancy: Rules completely subsumed by other rules
- Rule decay rate: Rules whose hit rate dropped >20% in 7 days
"""

from __future__ import annotations

import json
import logging
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

_COVERAGE_DIR = Path.home() / ".xingzierai" / "rule_coverage"


@dataclass
class CoverageSnapshot:
    timestamp: float = field(default_factory=time.time)
    total_interactions: int = 0
    l0_hits: int = 0
    l1_hits: int = 0
    l2_hits: int = 0
    l3_hits: int = 0
    l0_hit_rate: float = 0.0
    l0_l1_hit_rate: float = 0.0
    blind_spot_count: int = 0
    redundant_rule_count: int = 0
    decaying_rule_count: int = 0
    intent_categories_covered: int = 0
    intent_categories_total: int = 0
    intent_coverage_rate: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "total_interactions": self.total_interactions,
            "l0_hits": self.l0_hits,
            "l1_hits": self.l1_hits,
            "l2_hits": self.l2_hits,
            "l3_hits": self.l3_hits,
            "l0_hit_rate": round(self.l0_hit_rate, 4),
            "l0_l1_hit_rate": round(self.l0_l1_hit_rate, 4),
            "blind_spot_count": self.blind_spot_count,
            "redundant_rule_count": self.redundant_rule_count,
            "decaying_rule_count": self.decaying_rule_count,
            "intent_categories_covered": self.intent_categories_covered,
            "intent_categories_total": self.intent_categories_total,
            "intent_coverage_rate": round(self.intent_coverage_rate, 4),
        }


@dataclass
class BlindSpot:
    pattern: str
    sample_inputs: List[str] = field(default_factory=list)
    l3_count: int = 0
    first_seen: float = 0.0
    last_seen: float = 0.0
    suggested_category: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pattern": self.pattern,
            "sample_inputs": self.sample_inputs[:5],
            "l3_count": self.l3_count,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "suggested_category": self.suggested_category,
        }


@dataclass
class RuleHealth:
    rule_id: str
    rule_name: str
    category: str
    hit_count_7d: int = 0
    hit_count_prev_7d: int = 0
    hit_rate_change: float = 0.0
    is_decaying: bool = False
    is_redundant: bool = False
    redundant_with: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "rule_name": self.rule_name,
            "category": self.category,
            "hit_count_7d": self.hit_count_7d,
            "hit_count_prev_7d": self.hit_count_prev_7d,
            "hit_rate_change": round(self.hit_rate_change, 4),
            "is_decaying": self.is_decaying,
            "is_redundant": self.is_redundant,
            "redundant_with": self.redundant_with,
        }


INTENT_CATEGORIES = {
    "greeting", "time", "status", "version", "help", "list",
    "confirmation", "command", "debug", "evolution", "weather",
    "math", "agent", "model", "skill", "kappa", "safety",
    "identity", "architecture", "metrics", "config", "log",
    "system", "api", "deployment", "knowledge", "population",
    "local_model", "feedback", "language", "task", "security",
    "performance", "data", "network", "process", "environment",
    "feature_flag", "changelog", "disk", "memory",
}


class RuleCoverageTracker:
    """Tracks L0 rule coverage and identifies blind spots.

    Usage:
        tracker = RuleCoverageTracker()

        # Record each routing result
        tracker.record("hello", tier="L0", rule_id="RR-001", category="greeting")

        # Get coverage report
        report = tracker.get_report()
    """

    MAX_INTERACTIONS = 10000
    MAX_BLIND_SPOTS = 100
    DECAY_THRESHOLD = 0.20
    MIN_HITS_FOR_DECAY = 5

    def __init__(self, coverage_dir: Optional[str] = None):
        self._dir = Path(coverage_dir) if coverage_dir else _COVERAGE_DIR
        self._interactions: List[Dict[str, Any]] = []
        self._rule_hits: Dict[str, List[float]] = defaultdict(list)
        self._category_hits: Dict[str, int] = Counter()
        self._l3_patterns: Dict[str, BlindSpot] = {}
        self._snapshots: List[CoverageSnapshot] = []
        self._load()

    def record(
        self,
        user_input: str,
        tier: str,
        rule_id: str = "",
        category: str = "",
        confidence: float = 0.0,
    ) -> None:
        """Record a routing interaction for coverage tracking."""
        entry = {
            "input": user_input[:200],
            "tier": tier,
            "rule_id": rule_id,
            "category": category,
            "confidence": confidence,
            "timestamp": time.time(),
        }
        self._interactions.append(entry)

        if tier == "L0" and rule_id:
            self._rule_hits[rule_id].append(time.time())

        if category:
            self._category_hits[category] += 1

        if tier == "L3":
            self._track_blind_spot(user_input, category)

        if len(self._interactions) > self.MAX_INTERACTIONS:
            self._interactions = self._interactions[-self.MAX_INTERACTIONS // 2:]

        if len(self._interactions) % 100 == 0:
            self._take_snapshot()
            self._save()

    def get_report(self) -> Dict[str, Any]:
        """Generate comprehensive coverage report."""
        total = len(self._interactions)
        if total == 0:
            return {"status": "no_data", "message": "No interactions recorded yet"}

        l0 = sum(1 for i in self._interactions if i["tier"] == "L0")
        l1 = sum(1 for i in self._interactions if i["tier"] == "L1")
        l2 = sum(1 for i in self._interactions if i["tier"] == "L2")
        l3 = sum(1 for i in self._interactions if i["tier"] == "L3")

        covered_categories = set(self._category_hits.keys())
        intent_coverage = len(covered_categories & INTENT_CATEGORIES) / max(len(INTENT_CATEGORIES), 1)

        rule_health = self._analyze_rule_health()
        blind_spots = list(self._l3_patterns.values())

        return {
            "total_interactions": total,
            "tier_distribution": {
                "L0": {"count": l0, "rate": round(l0 / total, 4)},
                "L1": {"count": l1, "rate": round(l1 / total, 4)},
                "L2": {"count": l2, "rate": round(l2 / total, 4)},
                "L3": {"count": l3, "rate": round(l3 / total, 4)},
            },
            "l0_l1_hit_rate": round((l0 + l1) / total, 4),
            "intent_coverage": {
                "covered_categories": len(covered_categories & INTENT_CATEGORIES),
                "total_categories": len(INTENT_CATEGORIES),
                "coverage_rate": round(intent_coverage, 4),
                "uncovered": sorted(INTENT_CATEGORIES - covered_categories),
            },
            "blind_spots": {
                "count": len(blind_spots),
                "top": [bs.to_dict() for bs in sorted(blind_spots, key=lambda x: -x.l3_count)[:10]],
            },
            "rule_health": {
                "total_rules_tracked": len(rule_health),
                "decaying": sum(1 for r in rule_health.values() if r.is_decaying),
                "redundant": sum(1 for r in rule_health.values() if r.is_redundant),
                "details": [r.to_dict() for r in rule_health.values()
                            if r.is_decaying or r.is_redundant],
            },
            "evolution_direction": self._check_evolution_direction(l0, l1, l3, total),
        }

    def get_blind_spots(self, min_count: int = 3) -> List[BlindSpot]:
        """Get blind spots with at least min_count L3 hits."""
        return [
            bs for bs in self._l3_patterns.values()
            if bs.l3_count >= min_count
        ]

    def get_uncovered_categories(self) -> List[str]:
        """Get intent categories not covered by any L0 rule."""
        covered = set(self._category_hits.keys())
        return sorted(INTENT_CATEGORIES - covered)

    def _track_blind_spot(self, user_input: str, category: str) -> None:
        input_lower = user_input.lower().strip()
        words = input_lower.split()
        if len(words) >= 2:
            pattern = " ".join(words[:2])
        elif words:
            pattern = words[0]
        else:
            return

        if pattern in self._l3_patterns:
            bs = self._l3_patterns[pattern]
            bs.l3_count += 1
            bs.last_seen = time.time()
            if len(bs.sample_inputs) < 5:
                bs.sample_inputs.append(user_input[:100])
        else:
            if len(self._l3_patterns) < self.MAX_BLIND_SPOTS:
                self._l3_patterns[pattern] = BlindSpot(
                    pattern=pattern,
                    sample_inputs=[user_input[:100]],
                    l3_count=1,
                    first_seen=time.time(),
                    last_seen=time.time(),
                    suggested_category=category or "unknown",
                )

    def _analyze_rule_health(self) -> Dict[str, RuleHealth]:
        now = time.time()
        week_ago = now - 7 * 86400
        two_weeks_ago = now - 14 * 86400

        health: Dict[str, RuleHealth] = {}

        for rule_id, timestamps in self._rule_hits.items():
            recent = [t for t in timestamps if t >= week_ago]
            previous = [t for t in timestamps if two_weeks_ago <= t < week_ago]

            recent_count = len(recent)
            prev_count = len(previous)

            hit_rate_change = 0.0
            if prev_count >= self.MIN_HITS_FOR_DECAY:
                hit_rate_change = (recent_count - prev_count) / prev_count

            is_decaying = (
                prev_count >= self.MIN_HITS_FOR_DECAY
                and hit_rate_change < -self.DECAY_THRESHOLD
            )

            category = ""
            name = rule_id
            for i in self._interactions:
                if i.get("rule_id") == rule_id:
                    category = i.get("category", "")
                    name = rule_id
                    break

            health[rule_id] = RuleHealth(
                rule_id=rule_id,
                rule_name=name,
                category=category,
                hit_count_7d=recent_count,
                hit_count_prev_7d=prev_count,
                hit_rate_change=hit_rate_change,
                is_decaying=is_decaying,
            )

        self._check_redundancy(health)
        return health

    def _check_redundancy(self, health: Dict[str, RuleHealth]) -> None:
        rule_categories: Dict[str, List[str]] = defaultdict(list)
        for rule_id, h in health.items():
            if h.category:
                rule_categories[h.category].append(rule_id)

        for cat, rule_ids in rule_categories.items():
            if len(rule_ids) <= 1:
                continue
            for rid in rule_ids:
                others = [r for r in rule_ids if r != rid]
                hits = health[rid].hit_count_7d
                other_hits = sum(health[r].hit_count_7d for r in others)
                if hits > 0 and other_hits > 0 and hits / (hits + other_hits) < 0.05:
                    health[rid].is_redundant = True
                    health[rid].redundant_with = others

    def _check_evolution_direction(
        self, l0: int, l1: int, l3: int, total: int,
    ) -> Dict[str, Any]:
        """V7.4 Iron Law 19: Evolution direction verification."""
        l0_l1_rate = (l0 + l1) / max(total, 1)
        l3_rate = l3 / max(total, 1)

        return {
            "less_llm_dependent": l3_rate < 0.5,
            "increased_internalization": l0_l1_rate > 0.1,
            "toward_three_tier": l0_l1_rate > 0.3,
            "l3_rate": round(l3_rate, 4),
            "l0_l1_rate": round(l0_l1_rate, 4),
            "recommendation": self._get_recommendation(l0_l1_rate, l3_rate),
        }

    def _get_recommendation(self, l0_l1_rate: float, l3_rate: float) -> str:
        if l3_rate > 0.8:
            return "CRITICAL: L3 rate too high. Prioritize rule internalization from L3 patterns."
        if l3_rate > 0.5:
            return "WARNING: L3 rate above 50%. Accelerate L0 rule creation for blind spots."
        if l0_l1_rate > 0.7:
            return "GOOD: Strong L0/L1 coverage. Focus on edge cases and decaying rules."
        if l0_l1_rate > 0.3:
            return "MODERATE: Decent L0/L1 coverage. Continue expanding rule base."
        return "LOW: L0/L1 coverage below 30%. Urgent rule expansion needed."

    def _take_snapshot(self) -> None:
        total = len(self._interactions)
        if total == 0:
            return

        l0 = sum(1 for i in self._interactions if i["tier"] == "L0")
        l1 = sum(1 for i in self._interactions if i["tier"] == "L1")
        covered = set(self._category_hits.keys()) & INTENT_CATEGORIES

        snapshot = CoverageSnapshot(
            total_interactions=total,
            l0_hits=l0,
            l1_hits=l1,
            l2_hits=sum(1 for i in self._interactions if i["tier"] == "L2"),
            l3_hits=sum(1 for i in self._interactions if i["tier"] == "L3"),
            l0_hit_rate=l0 / total,
            l0_l1_hit_rate=(l0 + l1) / total,
            blind_spot_count=len(self._l3_patterns),
            intent_categories_covered=len(covered),
            intent_categories_total=len(INTENT_CATEGORIES),
            intent_coverage_rate=len(covered) / max(len(INTENT_CATEGORIES), 1),
        )

        self._snapshots.append(snapshot)
        if len(self._snapshots) > 1440:
            self._snapshots = self._snapshots[-720:]

    def _save(self) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            data = {
                "interactions_count": len(self._interactions),
                "category_hits": dict(self._category_hits),
                "blind_spots": {
                    k: v.to_dict() for k, v in self._l3_patterns.items()
                },
                "snapshots": [s.to_dict() for s in self._snapshots[-10:]],
            }
            path = self._dir / "coverage_data.json"
            path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            logger.debug("Failed to save coverage data: %s", e)

    def _load(self) -> None:
        try:
            path = self._dir / "coverage_data.json"
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            self._category_hits = Counter(data.get("category_hits", {}))
            for k, v in data.get("blind_spots", {}).items():
                self._l3_patterns[k] = BlindSpot(
                    pattern=v.get("pattern", k),
                    sample_inputs=v.get("sample_inputs", []),
                    l3_count=v.get("l3_count", 0),
                    first_seen=v.get("first_seen", 0),
                    last_seen=v.get("last_seen", 0),
                    suggested_category=v.get("suggested_category", ""),
                )
        except Exception as e:
            logger.debug("Failed to load coverage data: %s", e)
