#!/usr/bin/env python3
"""Code Verification Hook - External validation layer for AI-generated code.

This hook implements the core anti-hallucination mechanism that breaks
the "学渣自测" (bad-student-self-test) loop. After the agent writes
code via write_file or edit_file, this hook:

1. Extracts the written code
2. Runs deterministic external validation (syntax, imports, APIs)
3. If issues found, injects them back into the conversation as a
   structured verification report
4. The agent can then fix the issues in the next reasoning cycle

This is fundamentally different from AI-self-verification because:
- Syntax checks use ast.parse() (deterministic)
- Import checks use importlib.util.find_spec() (deterministic)
- The validation DOES NOT rely on LLM judgment at all
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class CodeVerificationHook:
    """Post-acting hook that validates AI-generated code.

    Registered on XingzierAIAgent, it intercepts write_file and edit_file
    calls, validates the generated code, and injects structured feedback
    back into the conversation.

    Architecture:
        Agent writes code → Hook validates → Issues injected → Agent fixes
        (AI output)      (external checks)    (back to AI)     (AI re-generates)
    """

    CODE_WRITING_TOOLS = {"write_file", "edit_file"}
    CODE_EXTENSIONS = {
        ".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs",
        ".java", ".cpp", ".c", ".h", ".hpp", ".rb", ".php",
        ".swift", ".kt", ".scala", ".sh", ".bash",
    }

    def __init__(
        self,
        enabled: bool = True,
        max_verification_rounds: int = 3,
        auto_fix_on_warning: bool = False,
    ):
        self.enabled = enabled
        self.max_verification_rounds = max_verification_rounds
        self.auto_fix_on_warning = auto_fix_on_warning
        self._round_counts: Dict[str, int] = {}

    async def __call__(
        self,
        agent: Any,
        kwargs: Dict[str, Any],
        output: Any = None,
    ) -> Optional[Dict[str, Any]]:
        if not self.enabled:
            return None

        tool_call = kwargs.get("tool_call", {})
        tool_name = tool_call.get("name", "") if isinstance(tool_call, dict) else ""
        tool_args = tool_call.get("arguments", {}) if isinstance(tool_call, dict) else {}

        if tool_name not in self.CODE_WRITING_TOOLS:
            return None

        file_path = self._extract_file_path(tool_name, tool_args)
        if not file_path:
            return None

        if not self._is_code_file(file_path):
            return None

        code_content = self._extract_code_content(tool_name, tool_args, output)
        if not code_content:
            return None

        session_id = self._get_session_id(agent)
        round_key = f"{session_id}:{file_path}"
        current_round = self._round_counts.get(round_key, 0)
        if current_round >= self.max_verification_rounds:
            return None
        self._round_counts[round_key] = current_round + 1

        try:
            from ..code_validator import CodeValidator
            validator = CodeValidator()

            workspace = getattr(agent, '_workspace_dir', None)
            report = validator.validate(
                code_content,
                project_root=Path(workspace) if workspace else None,
                language=self._detect_language(file_path),
            )

            if report.is_valid and report.error_count == 0:
                logger.debug(
                    "CodeVerificationHook: %s passed all checks (round %d)",
                    file_path, current_round + 1,
                )
                return None

            logger.warning(
                "CodeVerificationHook: %s has %d error(s), %d warning(s) (round %d)",
                file_path, report.error_count, report.warning_count,
                current_round + 1,
            )

            verification_msg = self._build_verification_message(
                file_path, report, current_round + 1,
            )

            if agent and hasattr(agent, 'memory'):
                try:
                    from xingzierai.agentscope_core.message import Msg, TextBlock
                    hint_msg = Msg(
                        "system",
                        [TextBlock(type="text", text=verification_msg)],
                        "system",
                    )
                    await agent.memory.add(hint_msg)
                    logger.info(
                        "CodeVerificationHook: injected verification report for %s",
                        file_path,
                    )
                except Exception as mem_err:
                    logger.debug(
                        "CodeVerificationHook: failed to inject message: %s", mem_err,
                    )

            return {
                "verified": True,
                "file_path": file_path,
                "error_count": report.error_count,
                "warning_count": report.warning_count,
                "is_valid": report.is_valid,
            }

        except Exception as e:
            logger.debug("CodeVerificationHook: validation failed: %s", e)
            return None

    def _extract_file_path(self, tool_name: str, tool_args: Dict) -> Optional[str]:
        if "file_path" in tool_args:
            return tool_args["file_path"]
        if "path" in tool_args:
            return tool_args["path"]
        if "filename" in tool_args:
            return tool_args["filename"]
        if "name" in tool_args:
            name = tool_args["name"]
            if isinstance(name, str) and '.' in name:
                return name
        return None

    def _is_code_file(self, file_path: str) -> bool:
        return any(file_path.endswith(ext) for ext in self.CODE_EXTENSIONS)

    def _extract_code_content(
        self,
        tool_name: str,
        tool_args: Dict,
        output: Any,
    ) -> Optional[str]:
        if tool_name == "write_file":
            return tool_args.get("content") or tool_args.get("text") or tool_args.get("code")

        if tool_name == "edit_file":
            return tool_args.get("new_str") or tool_args.get("replacement")

        text = self._extract_output_text(output)
        if text:
            return text

        return None

    def _extract_output_text(self, output: Any) -> Optional[str]:
        if output is None:
            return None
        if isinstance(output, str):
            return output
        if isinstance(output, dict):
            text = output.get("content", "") or output.get("text", "")
            if text:
                return text
        if hasattr(output, "get_text_content"):
            return output.get_text_content() or None
        return None

    def _detect_language(self, file_path: str) -> str:
        ext_map = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".jsx": "javascript",
            ".tsx": "typescript",
            ".go": "go",
            ".rs": "rust",
            ".java": "java",
            ".cpp": "cpp",
            ".c": "c",
            ".sh": "bash",
            ".bash": "bash",
        }
        return ext_map.get(
            os.path.splitext(file_path)[1].lower(),
            "auto",
        )

    def _get_session_id(self, agent: Any) -> str:
        if hasattr(agent, '_request_context'):
            ctx = agent._request_context or {}
            return ctx.get("session_id", "default")
        return "default"

    def _build_verification_message(
        self,
        file_path: str,
        report: Any,
        round_num: int,
    ) -> str:
        lines = [
            f"## Code Verification Report (Round {round_num}/{self.max_verification_rounds})",
            f"File: `{file_path}`",
            f"",
        ]

        if report.syntax_errors:
            lines.append("### Syntax Errors (MUST FIX)")
            for err in report.syntax_errors[:5]:
                lines.append(f"- {err}")
            lines.append("")

        if report.missing_imports:
            lines.append("### Missing Imports (MUST FIX)")
            for imp in report.missing_imports[:5]:
                lines.append(f"- {imp}")
            lines.append("")

        if report.nonexistent_apis:
            lines.append("### Nonexistent/Hallucinated APIs (MUST FIX)")
            for api in report.nonexistent_apis[:5]:
                lines.append(f"- {api}")
            lines.append("")

        if report.issues:
            error_issues = [i for i in report.issues if i.severity.value == "error"]
            warning_issues = [i for i in report.issues if i.severity.value == "warning"]

            if error_issues:
                lines.append("### Errors")
                for issue in error_issues[:10]:
                    lines.append(f"- [{issue.severity.value.upper()}] {issue.message}")
                    if issue.suggestion:
                        lines.append(f"  Fix: {issue.suggestion}")

            if warning_issues:
                lines.append("### Warnings")
                for issue in warning_issues[:5]:
                    lines.append(f"- [{issue.severity.value.upper()}] {issue.message}")

        lines.append("")
        lines.append(
            "**Action Required**: Fix ALL errors above before proceeding. "
            "Use `read_file` to re-examine the file, `edit_file` to fix issues, "
            "then re-run validation with `execute_shell_command`."
        )

        return "\n".join(lines)


_global_verification_hook: Optional[CodeVerificationHook] = None


def get_verification_hook() -> CodeVerificationHook:
    global _global_verification_hook
    if _global_verification_hook is None:
        _global_verification_hook = CodeVerificationHook()
    return _global_verification_hook


__all__ = [
    "CodeVerificationHook",
    "get_verification_hook",
]