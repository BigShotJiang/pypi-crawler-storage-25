# -*- coding: utf-8 -*-
"""Refinement Loop - Generate -> Verify -> Revise cycle.

Inspired by ARC Prize 2025 and AlphaEvolve (DeepMind):
- Generate a candidate solution
- Verify against deterministic tests
- Revise based on failure feedback
- Repeat until pass or max iterations

This is the L2 (Program Synthesis) layer of the three-tier reasoning architecture.
It synthesizes executable code to solve problems without LLM invocation when possible.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class RefinementStatus(str, Enum):
    PENDING = "pending"
    GENERATING = "generating"
    VERIFYING = "verifying"
    REVISING = "revising"
    PASSED = "passed"
    FAILED = "failed"
    MAX_ITERATIONS = "max_iterations"


@dataclass
class TestCase:
    name: str
    input_data: Any
    expected_output: Any
    check_fn: Optional[Callable] = None

    def verify(self, actual_output: Any) -> bool:
        if self.check_fn:
            return self.check_fn(actual_output, self.expected_output)
        return actual_output == self.expected_output


@dataclass
class RefinementResult:
    status: RefinementStatus
    solution: str
    iterations: int
    test_results: List[Dict[str, Any]] = field(default_factory=list)
    total_latency_ms: float = 0.0
    token_cost: int = 0
    revision_history: List[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return self.status == RefinementStatus.PASSED

    @property
    def pass_rate(self) -> float:
        if not self.test_results:
            return 0.0
        passed = sum(1 for t in self.test_results if t.get("passed", False))
        return passed / len(self.test_results)


class RefinementLoop:
    """Generate -> Verify -> Revise refinement loop.

    Core idea from ARC Prize / AlphaEvolve:
    1. Generate a candidate solution (rule/template-based, no LLM)
    2. Run deterministic test cases
    3. If tests fail, analyze failure and revise
    4. Repeat until all tests pass or max iterations reached

    This is L2 (Program Synthesis) - it creates executable code
    without LLM invocation for structured problems.
    """

    MAX_ITERATIONS = 5

    def __init__(
        self,
        generators: Optional[Dict[str, Callable]] = None,
        revisors: Optional[Dict[str, Callable]] = None,
    ):
        self._generators = generators or {}
        self._revisors = revisors or {}
        self._stats = {
            "total_loops": 0,
            "successful": 0,
            "failed": 0,
            "max_iterations_reached": 0,
            "avg_iterations": 0.0,
            "avg_latency_ms": 0.0,
        }

    def register_generator(self, problem_type: str, generator: Callable) -> None:
        self._generators[problem_type] = generator

    def register_revisor(self, problem_type: str, revisor: Callable) -> None:
        self._revisors[problem_type] = revisor

    async def refine(
        self,
        problem_type: str,
        problem_description: str,
        test_cases: List[TestCase],
        context: Optional[Dict[str, Any]] = None,
        max_iterations: int = 5,
    ) -> RefinementResult:
        """Execute a refinement loop for the given problem.

        Args:
            problem_type: Category of problem (e.g., 'code_generation', 'data_transform')
            problem_description: Natural language description of the problem
            test_cases: Deterministic test cases to verify solutions
            context: Additional context
            max_iterations: Maximum refinement iterations

        Returns:
            RefinementResult with the final solution and verification status
        """
        start = time.monotonic()
        ctx = context or {}

        self._stats["total_loops"] += 1

        generator = self._generators.get(problem_type)
        revisor = self._revisors.get(problem_type)

        if not generator:
            return RefinementResult(
                status=RefinementStatus.FAILED,
                solution="",
                iterations=0,
                total_latency_ms=(time.monotonic() - start) * 1000,
                test_results=[{"name": tc.name, "passed": False, "error": "no_generator"} for tc in test_cases],
            )

        current_solution = ""
        revision_history = []
        all_test_results = []

        for iteration in range(1, max_iterations + 1):
            if iteration == 1:
                current_solution = await self._invoke_fn(generator, problem_description, ctx)
            else:
                if revisor:
                    failure_info = [t for t in all_test_results if not t.get("passed", False)]
                    revision_input = {
                        "solution": current_solution,
                        "failures": failure_info,
                        "problem": problem_description,
                    }
                    current_solution = await self._invoke_fn(revisor, revision_input, ctx)
                else:
                    break

            revision_history.append(f"iter_{iteration}: {current_solution[:100]}")

            test_results = []
            all_passed = True
            for tc in test_cases:
                try:
                    local_ns: Dict[str, Any] = {}
                    exec(current_solution, local_ns)
                    solve_fn = local_ns.get("solve")
                    if solve_fn:
                        if asyncio.iscoroutinefunction(solve_fn):
                            actual = await solve_fn(tc.input_data)
                        else:
                            actual = solve_fn(tc.input_data)
                    else:
                        actual = None

                    passed = tc.verify(actual)
                    test_results.append({
                        "name": tc.name,
                        "passed": passed,
                        "actual": str(actual)[:200],
                        "expected": str(tc.expected_output)[:200],
                    })
                    if not passed:
                        all_passed = False
                except Exception as e:
                    test_results.append({
                        "name": tc.name,
                        "passed": False,
                        "error": str(e)[:200],
                    })
                    all_passed = False

            all_test_results = test_results

            if all_passed:
                latency = (time.monotonic() - start) * 1000
                self._stats["successful"] += 1
                self._update_avg_stats(iteration, latency)
                return RefinementResult(
                    status=RefinementStatus.PASSED,
                    solution=current_solution,
                    iterations=iteration,
                    test_results=test_results,
                    total_latency_ms=latency,
                    token_cost=0,
                    revision_history=revision_history,
                )

        latency = (time.monotonic() - start) * 1000
        if iteration >= max_iterations:
            self._stats["max_iterations_reached"] += 1
            status = RefinementStatus.MAX_ITERATIONS
        else:
            self._stats["failed"] += 1
            status = RefinementStatus.FAILED

        self._update_avg_stats(iteration, latency)

        return RefinementResult(
            status=status,
            solution=current_solution,
            iterations=iteration,
            test_results=all_test_results,
            total_latency_ms=latency,
            token_cost=0,
            revision_history=revision_history,
        )

    async def _invoke_fn(self, fn: Callable, *args) -> str:
        if asyncio.iscoroutinefunction(fn):
            return await fn(*args)
        return fn(*args)

    def _update_avg_stats(self, iterations: int, latency_ms: float) -> None:
        total = self._stats["total_loops"]
        self._stats["avg_iterations"] = (
            (self._stats["avg_iterations"] * (total - 1) + iterations) / total
        )
        self._stats["avg_latency_ms"] = (
            (self._stats["avg_latency_ms"] * (total - 1) + latency_ms) / total
        )

    def get_stats(self) -> Dict[str, Any]:
        total = max(self._stats["total_loops"], 1)
        return {
            **self._stats,
            "success_rate": round(self._stats["successful"] / total, 4),
        }


def create_data_transform_generator() -> Callable:
    """L2 generator for data transformation problems."""
    def generator(problem: str, context: Dict[str, Any]) -> str:
        p = problem.lower()
        if "排序" in p or "sort" in p:
            return (
                "def solve(data):\n"
                "    if isinstance(data, list):\n"
                "        return sorted(data)\n"
                "    return data\n"
            )
        if "去重" in p or "unique" in p or "dedup" in p:
            return (
                "def solve(data):\n"
                "    if isinstance(data, list):\n"
                "        return list(dict.fromkeys(data))\n"
                "    return data\n"
            )
        if "反转" in p or "reverse" in p:
            return (
                "def solve(data):\n"
                "    if isinstance(data, list):\n"
                "        return list(reversed(data))\n"
                "    if isinstance(data, str):\n"
                "        return data[::-1]\n"
                "    return data\n"
            )
        if "过滤" in p or "filter" in p:
            return (
                "def solve(data):\n"
                "    if isinstance(data, list):\n"
                "        return [x for x in data if x]\n"
                "    return data\n"
            )
        if "计数" in p or "count" in p:
            return (
                "def solve(data):\n"
                "    if isinstance(data, list):\n"
                "        from collections import Counter\n"
                "        return dict(Counter(data))\n"
                "    return data\n"
            )
        return (
            "def solve(data):\n"
            "    return data\n"
        )
    return generator


def create_data_transform_revisor() -> Callable:
    """L2 revisor for data transformation problems."""
    def revisor(revision_input: Dict[str, Any], context: Dict[str, Any]) -> str:
        failures = revision_input.get("failures", [])
        current = revision_input.get("solution", "")
        problem = revision_input.get("problem", "").lower()

        if not failures:
            return current

        first_failure = failures[0]
        error = first_failure.get("error", "")
        actual = first_failure.get("actual", "")
        expected = first_failure.get("expected", "")

        if "TypeError" in error:
            return (
                "def solve(data):\n"
                "    try:\n"
                "        if data is None:\n"
                "            return None\n"
                "        if isinstance(data, (list, tuple)):\n"
                "            return list(data)\n"
                "        return data\n"
                "    except Exception:\n"
                "        return data\n"
            )

        if "sort" in problem or "排序" in problem:
            return (
                "def solve(data):\n"
                "    try:\n"
                "        if isinstance(data, list):\n"
                "            return sorted(data, key=lambda x: (isinstance(x, str), x))\n"
                "        return data\n"
                "    except TypeError:\n"
                "        return sorted(data, key=str)\n"
            )

        return current
    return revisor
