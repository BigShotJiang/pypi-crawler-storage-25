#!/usr/bin/env python3
"""Code Validator - External verification layer for AI-generated code.

This module breaks the "学渣自测" (bad-student-self-test) loop by providing
an EXTERNAL verification layer that checks AI-generated code against
real-world constraints:

1. Syntax validation (AST parsing)
2. Import existence check (against installed packages)
3. API/method existence check (against real module introspection)
4. Anti-pattern detection
5. Cross-file consistency check

This is the key to breaking through AI programming accuracy bottlenecks:
instead of relying on the AI to verify its own output (which leads to
the "harness engineering" trap), we use deterministic external checks.
"""

from __future__ import annotations

import ast
import importlib
import importlib.util
import inspect
import logging
import os
import re
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


class ValidationSeverity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class ValidationIssue:
    """A single validation issue found in code."""
    severity: ValidationSeverity
    message: str
    file_path: str = ""
    line_number: int = 0
    code_snippet: str = ""
    suggestion: str = ""


@dataclass
class ValidationReport:
    """Complete validation report for generated code."""
    is_valid: bool = True
    issues: List[ValidationIssue] = field(default_factory=list)
    checked_imports: List[str] = field(default_factory=list)
    missing_imports: List[str] = field(default_factory=list)
    syntax_errors: List[str] = field(default_factory=list)
    nonexistent_apis: List[str] = field(default_factory=list)
    stats: Dict[str, Any] = field(default_factory=dict)

    @property
    def error_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == ValidationSeverity.ERROR)

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == ValidationSeverity.WARNING)

    def summary(self) -> str:
        parts = []
        if self.syntax_errors:
            parts.append(f"Syntax errors: {len(self.syntax_errors)}")
        if self.missing_imports:
            parts.append(f"Missing imports: {len(self.missing_imports)}")
        if self.nonexistent_apis:
            parts.append(f"Nonexistent APIs: {len(self.nonexistent_apis)}")
        if not parts:
            return "All checks passed"
        return "; ".join(parts)


# Known stdlib modules for quick lookup
_STDLIB_MODULES: Set[str] = set()

_KNOWN_NONEXISTENT_APIS: Set[str] = set()


def _init_stdlib_modules():
    """Lazily initialize stdlib module set."""
    global _STDLIB_MODULES
    if _STDLIB_MODULES:
        return
    if hasattr(sys, 'stdlib_module_names'):
        _STDLIB_MODULES = set(sys.stdlib_module_names)
    else:
        common_stdlib = {
            'os', 'sys', 're', 'json', 'math', 'datetime', 'collections',
            'itertools', 'functools', 'random', 'string', 'pathlib',
            'subprocess', 'shutil', 'tempfile', 'logging', 'hashlib',
            'base64', 'csv', 'io', 'time', 'threading', 'multiprocessing',
            'socket', 'http', 'urllib', 'xml', 'html', 'email', 'sqlite3',
            'typing', 'enum', 'dataclasses', 'abc', 'copy', 'pickle',
            'struct', 'textwrap', 'unittest', 'doctest', 'pdb',
            'asyncio', 'concurrent', 'contextlib', 'decimal', 'fractions',
            'statistics', 'traceback', 'warnings', 'weakref', 'argparse',
            'getpass', 'platform', 'signal', 'mmap', 'fnmatch', 'glob',
            'gzip', 'zipfile', 'tarfile', 'configparser', 'secrets',
            'uuid', 'inspect', 'importlib', 'pkgutil', 'ast', 'tokenize',
            'dis', 'opcode', 'symtable', 'builtins', '__future__',
            'array', 'binascii', 'bisect', 'calendar', 'cmath', 'codecs',
            'colorsys', 'crypt', 'difflib', 'filecmp', 'fileinput',
            'getopt', 'gettext', 'grp', 'heapq', 'hmac', 'imaplib',
            'keyword', 'linecache', 'locale', 'lzma', 'mailbox', 'mimetypes',
            'netrc', 'nntplib', 'numbers', 'operator', 'poplib',
            'pprint', 'profile', 'pstats', 'pty', 'pwd', 'py_compile',
            'queue', 'quopri', 'reprlib', 'resource', 'rlcompleter',
            'runpy', 'sched', 'select', 'selectors', 'shelve',
            'site', 'smtplib', 'sndhdr', 'spwd', 'ssl', 'stat',
            'stringprep', 'sysconfig', 'tabnany', 'telnetlib',
            'termios', 'timeit', 'tkinter', 'tty', 'turtle', 'types',
            'unicodedata', 'wave', 'webbrowser', 'winreg', 'winsound',
            'wsgiref', 'xdrlib', 'xmlrpc', 'zipapp', 'zipimport', 'zlib',
        }
        _STDLIB_MODULES = common_stdlib

    if sys.version_info >= (3, 10):
        _STDLIB_MODULES.update({
            'graphlib', 'zoneinfo',
        })


_init_stdlib_modules()


@dataclass
class CodeBlock:
    """A single code block extracted from text."""
    language: str
    code: str
    file_path: str = ""
    line_offset: int = 0


class CodeBlockExtractor:
    """Extract code blocks from markdown/text content."""

    FENCE_PATTERN = re.compile(
        r'```(\w*)\s*\n(.*?)```',
        re.DOTALL,
    )

    FILE_HINT_PATTERNS = [
        re.compile(r'(?:file|文件|path|路径)[:\s]*([^\s\n]+\.\w+)', re.IGNORECASE),
        re.compile(r'([^\s\n`]+\.(?:py|js|ts|jsx|tsx|go|rs|java|cpp|c|h))(?:\s|$|:|：)'),
    ]

    @classmethod
    def extract(cls, text: str) -> List[CodeBlock]:
        blocks = []
        for match in cls.FENCE_PATTERN.finditer(text):
            language = match.group(1).strip() or "text"
            code = match.group(2)
            if code.strip():
                blocks.append(CodeBlock(
                    language=language,
                    code=code,
                    file_path=cls._guess_filename(text, match.start()),
                ))
        return blocks

    @classmethod
    def _guess_filename(cls, text: str, fence_pos: int) -> str:
        context = text[max(0, fence_pos - 200):fence_pos]
        for pattern in cls.FILE_HINT_PATTERNS:
            m = pattern.search(context)
            if m:
                return m.group(1)
        return ""


class PythonSyntaxValidator:
    """Validate Python syntax using AST parsing."""

    @classmethod
    def validate(cls, code: str) -> List[ValidationIssue]:
        issues = []
        try:
            tree = ast.parse(code)
            issues.extend(cls._check_dangerous_patterns(tree, code))
        except SyntaxError as e:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                message=f"Syntax error: {e.msg}",
                line_number=e.lineno or 0,
                code_snippet=code.split('\n')[e.lineno - 1][:80] if e.lineno and e.lineno <= len(code.split('\n')) else "",
                suggestion=f"Fix the syntax error at line {e.lineno}: {e.msg}",
            ))
        return issues

    @classmethod
    def _check_dangerous_patterns(
        cls, tree: ast.AST, code: str,
    ) -> List[ValidationIssue]:
        issues = []
        lines = code.split('\n')

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    if node.func.id == 'eval':
                        issues.append(ValidationIssue(
                            severity=ValidationSeverity.WARNING,
                            message=f"Use of eval() detected - security risk",
                            line_number=node.lineno,
                            code_snippet=lines[node.lineno - 1][:80] if node.lineno <= len(lines) else "",
                            suggestion="Avoid eval(), use safer alternatives like ast.literal_eval() or json.loads()",
                        ))
                    elif node.func.id == 'exec':
                        issues.append(ValidationIssue(
                            severity=ValidationSeverity.WARNING,
                            message=f"Use of exec() detected - security risk",
                            line_number=node.lineno,
                            code_snippet=lines[node.lineno - 1][:80] if node.lineno <= len(lines) else "",
                            suggestion="Avoid exec() in production code",
                        ))

            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == 'os' and cls._has_os_system(tree):
                        issues.append(ValidationIssue(
                            severity=ValidationSeverity.WARNING,
                            message="os.system() detected - consider subprocess.run() instead",
                            line_number=node.lineno,
                            suggestion="Use subprocess.run() with explicit argument lists for security",
                        ))

        return issues

    @staticmethod
    def _has_os_system(tree: ast.AST) -> bool:
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Attribute):
                    if (isinstance(node.func.value, ast.Name) and
                            node.func.value.id == 'os' and
                            node.func.attr == 'system'):
                        return True
        return False


class ImportValidator:
    """Validate that imports in generated code actually exist."""

    _package_cache: Dict[str, bool] = {}
    _module_member_cache: Dict[str, Set[str]] = {}

    @classmethod
    def validate(cls, code: str) -> List[ValidationIssue]:
        issues = []
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return issues

        imports = cls._extract_imports(tree)
        language = cls._detect_language(code)

        if language == "python":
            for module_name, imported_names in imports:
                module_issues = cls._check_python_import(module_name, imported_names)
                issues.extend(module_issues)
        elif language in ("javascript", "typescript"):
            pass

        return issues

    @classmethod
    def _detect_language(cls, code: str) -> str:
        if re.search(r'(?:import\s+\w+|from\s+\w+\s+import|def\s+|class\s+\w+.*:)', code):
            return "python"
        if re.search(r'(?:const\s+|let\s+|var\s+|function\s+|=>|import\s+.*from)', code):
            return "javascript"
        return "unknown"

    @classmethod
    def _extract_imports(
        cls, tree: ast.AST,
    ) -> List[Tuple[str, List[str]]]:
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append((alias.name, []))
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    names = [alias.name for alias in node.names]
                    imports.append((node.module, names))
        return imports

    @classmethod
    def _check_python_import(
        cls, module_name: str, imported_names: List[str],
    ) -> List[ValidationIssue]:
        issues = []
        top_module = module_name.split('.')[0]

        if top_module in _STDLIB_MODULES:
            return cls._check_stdlib_members(module_name, imported_names)

        is_available = cls._is_package_available(top_module)
        if not is_available:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                message=f"Module '{top_module}' is not installed",
                suggestion=f"Install with: pip install {top_module}",
            ))
            return issues

        if imported_names:
            member_issues = cls._check_module_members(module_name, imported_names)
            issues.extend(member_issues)

        return issues

    @classmethod
    def _is_package_available(cls, package_name: str) -> bool:
        if package_name in cls._package_cache:
            return cls._package_cache[package_name]

        if package_name in _STDLIB_MODULES:
            cls._package_cache[package_name] = True
            return True

        spec = importlib.util.find_spec(package_name)
        available = spec is not None
        cls._package_cache[package_name] = available
        return available

    @classmethod
    def _check_stdlib_members(
        cls, module_name: str, imported_names: List[str],
    ) -> List[ValidationIssue]:
        issues = []
        if not imported_names:
            return issues

        try:
            module = importlib.import_module(module_name)
            available = set(dir(module))
        except Exception:
            return issues

        for name in imported_names:
            if name == '*':
                continue
            if name not in available:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    message=f"'{name}' not found in stdlib module '{module_name}'",
                    suggestion=f"Check if '{name}' exists in '{module_name}'. "
                               f"Available: {', '.join(sorted(available)[:20])}...",
                ))

        return issues

    @classmethod
    def _check_module_members(
        cls, module_name: str, imported_names: List[str],
    ) -> List[ValidationIssue]:
        issues = []
        available = cls._get_module_members(module_name)
        if not available:
            return issues

        for name in imported_names:
            if name == '*':
                continue
            if name not in available:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    message=f"'{name}' not found in module '{module_name}'",
                    suggestion=f"Check if '{name}' exists in '{module_name}'",
                ))

        return issues

    @classmethod
    def _get_module_members(cls, module_name: str) -> Set[str]:
        if module_name in cls._module_member_cache:
            return cls._module_member_cache[module_name]

        try:
            module = importlib.import_module(module_name)
            members = set(dir(module))
            cls._module_member_cache[module_name] = members
            return members
        except Exception:
            return set()


class APICallValidator:
    """Validate that API/function calls reference existing functions.

    This detects hallucinated APIs - the #1 cause of AI code errors.
    """

    KNOWN_NONEXISTENT_APIS = {
        'openai.ChatCompletion.create',
        'openai.Completion.create',
        'pandas.read_csvs',
        'numpy.random_normal',
        'torch.tensor.load',
        'transformers.pipeline.load',
        'langchain.LLMChain.run',
        'sklearn.model.fit_transform',
    }

    @classmethod
    def validate(cls, code: str) -> List[ValidationIssue]:
        issues = []
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return issues

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                issue = cls._check_call(node)
                if issue:
                    issues.append(issue)

        return issues

    @classmethod
    def _check_call(cls, node: ast.Call) -> Optional[ValidationIssue]:
        if isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Attribute):
                chain = cls._get_attr_chain(node.func)
                if chain in cls.KNOWN_NONEXISTENT_APIS:
                    return ValidationIssue(
                        severity=ValidationSeverity.ERROR,
                        message=f"API '{chain}' does not exist (commonly hallucinated)",
                        line_number=node.lineno,
                        suggestion=f"'{chain}' is not a real API. Check the library documentation.",
                    )
        return None

    @staticmethod
    def _get_attr_chain(node: ast.Attribute) -> str:
        parts = []
        current = node
        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.append(current.id)
        return '.'.join(reversed(parts))


class CrossFileValidator:
    """Validate cross-file references (imports between project files)."""

    @classmethod
    def validate(
        cls, code: str, project_root: Path, language: str = "python",
    ) -> List[ValidationIssue]:
        issues = []
        if language != "python":
            return issues

        try:
            tree = ast.parse(code)
        except SyntaxError:
            return issues

        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                issue = cls._check_local_import(node, project_root)
                if issue:
                    issues.append(issue)

        return issues

    @classmethod
    def _check_local_import(
        cls, node: ast.AST, project_root: Path,
    ) -> Optional[ValidationIssue]:
        module_name = None
        if isinstance(node, ast.ImportFrom):
            module_name = node.module

        if not module_name:
            return None

        if module_name.startswith('.'):
            return None

        parts = module_name.split('.')
        potential_path = project_root / os.path.join(*parts)

        if potential_path.exists() and potential_path.is_dir():
            return None

        py_path = project_root / f"{os.path.join(*parts)}.py"
        if py_path.exists():
            return None

        init_path = potential_path / "__init__.py"
        if init_path.exists():
            return None

        return ValidationIssue(
            severity=ValidationSeverity.WARNING,
            message=f"Local module '{module_name}' not found in project",
            line_number=node.lineno,
            suggestion=f"Check that '{module_name}' exists in the project structure",
        )


class CodeValidator:
    """Main code validator that orchestrates all validation checks.

    Usage:
        validator = CodeValidator()
        report = validator.validate(generated_text, project_root=Path("/project"))

    This is the central tool for breaking the "学渣自测" cycle.
    Instead of relying on AI to verify AI (which produces errors that
    pass tests but don't work), we use deterministic, external checks.
    """

    def __init__(self):
        self.syntax_validator = PythonSyntaxValidator()
        self.import_validator = ImportValidator()
        self.api_validator = APICallValidator()
        self.cross_file_validator = CrossFileValidator()

    def validate(
        self,
        text: str,
        project_root: Optional[Path] = None,
        language: str = "auto",
    ) -> ValidationReport:
        """Validate AI-generated code in text.

        Args:
            text: The text containing code blocks to validate.
            project_root: Optional project root for cross-file checks.
            language: Target language (auto-detect if "auto").

        Returns:
            ValidationReport with all issues found.
        """
        report = ValidationReport()
        blocks = CodeBlockExtractor.extract(text)

        if not blocks:
            return report

        for block in blocks:
            lang = language if language != "auto" else block.language

            if lang in ("python", "py"):
                self._validate_python_block(block, report, project_root)
            elif lang in ("javascript", "js", "typescript", "ts"):
                self._validate_js_block(block, report)
            elif lang in ("go", "golang"):
                self._validate_go_block(block, report)

        report.is_valid = (
            len(report.syntax_errors) == 0 and
            len(report.missing_imports) == 0 and
            len(report.nonexistent_apis) == 0
        )

        report.stats = {
            "blocks_checked": len(blocks),
            "syntax_errors": len(report.syntax_errors),
            "missing_imports": len(report.missing_imports),
            "nonexistent_apis": len(report.nonexistent_apis),
            "total_issues": len(report.issues),
        }

        return report

    def _validate_python_block(
        self,
        block: CodeBlock,
        report: ValidationReport,
        project_root: Optional[Path] = None,
    ):
        syntax_issues = self.syntax_validator.validate(block.code)
        for issue in syntax_issues:
            issue.file_path = block.file_path
            if issue.message.startswith("Syntax error"):
                report.syntax_errors.append(issue.message)
        report.issues.extend(syntax_issues)

        import_issues = self.import_validator.validate(block.code)
        for issue in import_issues:
            issue.file_path = block.file_path
            if "not installed" in issue.message:
                report.missing_imports.append(issue.message)
            if issue.severity == ValidationSeverity.WARNING:
                report.checked_imports.append(issue.message)
        report.issues.extend(import_issues)

        api_issues = self.api_validator.validate(block.code)
        for issue in api_issues:
            issue.file_path = block.file_path
            report.nonexistent_apis.append(issue.message)
        report.issues.extend(api_issues)

        if project_root and project_root.exists():
            cross_issues = self.cross_file_validator.validate(
                block.code, project_root, "python",
            )
            for issue in cross_issues:
                issue.file_path = block.file_path
            report.issues.extend(cross_issues)

    def _validate_js_block(self, block: CodeBlock, report: ValidationReport):
        js_issues = self._basic_js_check(block.code)
        report.issues.extend(js_issues)

    def _basic_js_check(self, code: str) -> List[ValidationIssue]:
        issues = []
        brace_count = code.count('{') - code.count('}')
        paren_count = code.count('(') - code.count(')')
        bracket_count = code.count('[') - code.count(']')

        if brace_count != 0:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                message=f"Unbalanced braces: {abs(brace_count)} {'missing }' if brace_count > 0 else 'extra }'}",
                suggestion="Check your curly braces",
            ))
        if paren_count != 0:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                message=f"Unbalanced parentheses: {abs(paren_count)} {'missing )' if paren_count > 0 else 'extra )'}",
                suggestion="Check your parentheses",
            ))
        if bracket_count != 0:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                message=f"Unbalanced brackets: {abs(bracket_count)} {'missing ]' if bracket_count > 0 else 'extra ]'}",
                suggestion="Check your square brackets",
            ))

        return issues

    def _validate_go_block(self, block: CodeBlock, report: ValidationReport):
        pass


def validate_generated_code(
    text: str,
    project_root: Optional[str] = None,
    language: str = "auto",
) -> str:
    """Convenience function for validating AI-generated code.

    Returns a human-readable validation report string.

    Args:
        text: The text containing code to validate.
        project_root: Optional project root path.
        language: Language hint.

    Returns:
        A formatted validation report.
    """
    root = Path(project_root) if project_root else None
    validator = CodeValidator()
    report = validator.validate(text, project_root=root, language=language)

    if report.is_valid and not report.issues:
        return "✓ All checks passed - no issues found."

    lines = []
    lines.append(f"= Code Validation Report =")
    lines.append(f"Blocks checked: {report.stats.get('blocks_checked', 0)}")
    lines.append(f"Issues found: {report.stats.get('total_issues', 0)}")
    lines.append("")

    if report.syntax_errors:
        lines.append("## Syntax Errors")
        for err in report.syntax_errors[:10]:
            lines.append(f"  ✗ {err}")
        lines.append("")

    if report.missing_imports:
        lines.append("## Missing Imports")
        for imp in report.missing_imports[:10]:
            lines.append(f"  ✗ {imp}")
        lines.append("")

    if report.nonexistent_apis:
        lines.append("## Nonexistent APIs (Hallucinations)")
        for api in report.nonexistent_apis[:10]:
            lines.append(f"  ✗ {api}")
        lines.append("")

    if report.issues:
        lines.append("## All Issues")
        for issue in report.issues[:20]:
            prefix = {"error": "✗", "warning": "⚠", "info": "ℹ"}.get(
                issue.severity.value, "?"
            )
            loc = f" (line {issue.line_number})" if issue.line_number else ""
            lines.append(f"  {prefix} [{issue.severity.value.upper()}]{loc}: {issue.message}")
            if issue.suggestion:
                lines.append(f"    → {issue.suggestion}")

    return "\n".join(lines)


__all__ = [
    "CodeValidator",
    "validate_generated_code",
    "ValidationReport",
    "ValidationIssue",
    "ValidationSeverity",
    "CodeBlockExtractor",
    "ImportValidator",
    "APICallValidator",
]