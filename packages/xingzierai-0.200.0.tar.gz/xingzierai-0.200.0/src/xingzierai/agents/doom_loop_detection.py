# -*- coding: utf-8 -*-
"""Doom Loop Detection - Detect and break stuck tool-call loops automatically.

Inspired by PraisonAI's loop detection with 3 detectors:
- generic_repeat: Same tool + identical args called N times
- poll_no_progress: Same args AND same result (no progress)
- ping_pong: Alternating A -> B -> A -> B pattern

Integration with XingzierAIAgent:
- Hook into _acting phase to record tool calls
- Warn when threshold reached, block at critical threshold
- Zero overhead when disabled
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class LoopSeverity(Enum):
    NONE = "none"
    WARN = "warn"
    CRITICAL = "critical"


@dataclass
class LoopDetectionResult:
    severity: LoopSeverity = LoopSeverity.NONE
    detector_name: str = ""
    tool_name: str = ""
    call_count: int = 0
    message: str = ""
    suggestion: str = ""


@dataclass
class ToolCallRecord:
    tool_name: str
    args_hash: str
    result_hash: str = ""
    timestamp: float = 0.0

    def to_dict(self) -> dict:
        return {
            "tool_name": self.tool_name,
            "args_hash": self.args_hash,
            "result_hash": self.result_hash,
            "timestamp": self.timestamp,
        }


@dataclass
class LoopDetectionConfig:
    enabled: bool = False
    history_size: int = 30
    warn_threshold: int = 10
    critical_threshold: int = 20
    detectors: Dict[str, bool] = field(default_factory=lambda: {
        "generic_repeat": True,
        "poll_no_progress": True,
        "ping_pong": True,
    })

    def __post_init__(self):
        if self.critical_threshold <= self.warn_threshold:
            self.critical_threshold = self.warn_threshold + 5


POLL_TOOL_KEYWORDS = frozenset({
    "status", "poll", "check", "wait", "ping", "health",
    "get_status", "check_status", "wait_for", "is_ready",
    "is_complete", "is_done", "is_finished", "query",
})


def _hash_args(args: dict) -> str:
    try:
        serialized = json.dumps(args, sort_keys=True, default=str)
        return hashlib.sha256(serialized.encode()).hexdigest()[:16]
    except (TypeError, ValueError):
        return hashlib.sha256(str(args).encode()).hexdigest()[:16]


def _hash_result(result: Any) -> str:
    if result is None:
        return ""
    try:
        if isinstance(result, str):
            text = result[:2000]
        else:
            text = json.dumps(result, sort_keys=True, default=str)[:2000]
        return hashlib.sha256(text.encode()).hexdigest()[:16]
    except (TypeError, ValueError):
        return hashlib.sha256(str(result)[:2000].encode()).hexdigest()[:16]


def _is_poll_tool(tool_name: str) -> bool:
    name_lower = tool_name.lower()
    return any(kw in name_lower for kw in POLL_TOOL_KEYWORDS)


class GenericRepeatDetector:
    """Detect same tool + identical args called N times."""

    name = "generic_repeat"

    def detect(
        self,
        history: deque[ToolCallRecord],
        warn_threshold: int,
        critical_threshold: int,
    ) -> LoopDetectionResult:
        if len(history) < warn_threshold:
            return LoopDetectionResult()

        recent = list(history)
        last = recent[-1]

        count = 0
        for record in reversed(recent):
            if record.tool_name == last.tool_name and record.args_hash == last.args_hash:
                count += 1

        if count >= critical_threshold:
            return LoopDetectionResult(
                severity=LoopSeverity.CRITICAL,
                detector_name=self.name,
                tool_name=last.tool_name,
                call_count=count,
                message=f"Tool '{last.tool_name}' called with identical args {count} times (in {len(recent)} recent calls)",
                suggestion=f"Consider changing approach or adding new parameters to '{last.tool_name}'",
            )

        if count >= warn_threshold:
            return LoopDetectionResult(
                severity=LoopSeverity.WARN,
                detector_name=self.name,
                tool_name=last.tool_name,
                call_count=count,
                message=f"Tool '{last.tool_name}' called with identical args {count} times (in {len(recent)} recent calls)",
                suggestion=f"Review if '{last.tool_name}' is making progress or stuck",
            )

        return LoopDetectionResult()


class PollNoProgressDetector:
    """Detect same args AND same result (polling with no progress)."""

    name = "poll_no_progress"

    def detect(
        self,
        history: deque[ToolCallRecord],
        warn_threshold: int,
        critical_threshold: int,
    ) -> LoopDetectionResult:
        poll_warn = max(warn_threshold // 2, 3)
        if len(history) < poll_warn:
            return LoopDetectionResult()

        recent = list(history)
        last = recent[-1]

        if not _is_poll_tool(last.tool_name):
            return LoopDetectionResult()

        if not last.result_hash:
            return LoopDetectionResult()

        count = 0
        for record in reversed(recent):
            if (record.tool_name == last.tool_name
                    and record.args_hash == last.args_hash
                    and record.result_hash == last.result_hash):
                count += 1
            else:
                break

        poll_warn = max(warn_threshold // 2, 3)
        poll_critical = max(critical_threshold // 2, 5)

        if count >= poll_critical:
            return LoopDetectionResult(
                severity=LoopSeverity.CRITICAL,
                detector_name=self.name,
                tool_name=last.tool_name,
                call_count=count,
                message=f"Polling tool '{last.tool_name}' returning identical results {count} times",
                suggestion=f"Polling is not making progress. Consider increasing poll interval or stopping",
            )

        if count >= poll_warn:
            return LoopDetectionResult(
                severity=LoopSeverity.WARN,
                detector_name=self.name,
                tool_name=last.tool_name,
                call_count=count,
                message=f"Polling tool '{last.tool_name}' returning same result {count} times",
                suggestion=f"Consider waiting longer between polls or checking a different condition",
            )

        return LoopDetectionResult()


class PingPongDetector:
    """Detect alternating A -> B -> A -> B pattern."""

    name = "ping_pong"

    def detect(
        self,
        history: deque[ToolCallRecord],
        warn_threshold: int,
        critical_threshold: int,
    ) -> LoopDetectionResult:
        if len(history) < 4:
            return LoopDetectionResult()

        recent = list(history)
        min_alternations = max(warn_threshold // 2, 3)
        critical_alternations = max(critical_threshold // 2, 5)

        tool_a = recent[-2].tool_name
        tool_b = recent[-1].tool_name

        if tool_a == tool_b:
            return LoopDetectionResult()

        alternation_count = 0
        for i in range(len(recent) - 1, -1, -1):
            expected = tool_a if (len(recent) - 1 - i) % 2 == 1 else tool_b
            if recent[i].tool_name == expected:
                alternation_count += 1
            else:
                break

        if alternation_count >= critical_alternations:
            return LoopDetectionResult(
                severity=LoopSeverity.CRITICAL,
                detector_name=self.name,
                tool_name=f"{tool_a}<->{tool_b}",
                call_count=alternation_count * 2,
                message=f"Tools '{tool_a}' and '{tool_b}' alternating {alternation_count} times",
                suggestion=f"Break the cycle by combining '{tool_a}' and '{tool_b}' into a single step",
            )

        if alternation_count >= min_alternations:
            return LoopDetectionResult(
                severity=LoopSeverity.WARN,
                detector_name=self.name,
                tool_name=f"{tool_a}<->{tool_b}",
                call_count=alternation_count * 2,
                message=f"Tools '{tool_a}' and '{tool_b}' alternating {alternation_count} times",
                suggestion=f"Consider if this back-and-forth is productive or indicates a loop",
            )

        return LoopDetectionResult()


class DoomLoopDetector:
    """Main doom loop detector that runs all enabled detectors.

    Usage:
        config = LoopDetectionConfig(enabled=True, warn_threshold=5, critical_threshold=10)
        detector = DoomLoopDetector(config)

        # Record each tool call
        detector.record_call("read_file", {"path": "/tmp/test.py"}, result="content...")

        # Check for loops
        result = detector.check()
        if result.severity == LoopSeverity.CRITICAL:
            # Block the tool call
            ...
    """

    def __init__(self, config: Optional[LoopDetectionConfig] = None):
        self._config = config or LoopDetectionConfig()
        self._history: deque[ToolCallRecord] = deque(maxlen=self._config.history_size)
        self._detectors: list = []
        self._total_detections = 0
        self._blocked_count = 0

        if self._config.detectors.get("generic_repeat", True):
            self._detectors.append(GenericRepeatDetector())
        if self._config.detectors.get("poll_no_progress", True):
            self._detectors.append(PollNoProgressDetector())
        if self._config.detectors.get("ping_pong", True):
            self._detectors.append(PingPongDetector())

    @property
    def config(self) -> LoopDetectionConfig:
        return self._config

    @property
    def is_enabled(self) -> bool:
        return self._config.enabled

    def record_call(self, tool_name: str, args: dict, result: Any = None) -> None:
        if not self._config.enabled:
            return

        args_hash = _hash_args(args)
        result_hash = _hash_result(result) if result is not None else ""

        record = ToolCallRecord(
            tool_name=tool_name,
            args_hash=args_hash,
            result_hash=result_hash,
            timestamp=time.time(),
        )
        self._history.append(record)

    def check(self) -> LoopDetectionResult:
        if not self._config.enabled:
            return LoopDetectionResult()

        worst_result = LoopDetectionResult()

        for detector in self._detectors:
            result = detector.detect(
                self._history,
                self._config.warn_threshold,
                self._config.critical_threshold,
            )
            if result.severity == LoopSeverity.CRITICAL:
                self._total_detections += 1
                self._blocked_count += 1
                logger.warning(
                    "[DoomLoop] detector=%s tool=%s count=%d msg=%s",
                    result.detector_name, result.tool_name, result.call_count, result.message,
                )
                return result
            elif result.severity == LoopSeverity.WARN:
                self._total_detections += 1
                if result.severity.value > worst_result.severity.value:
                    worst_result = result

        if worst_result.severity == LoopSeverity.WARN:
            logger.info(
                "[DoomLoop] detector=%s tool=%s count=%d msg=%s",
                worst_result.detector_name, worst_result.tool_name,
                worst_result.call_count, worst_result.message,
            )

        return worst_result

    def should_block(self) -> bool:
        if not self._config.enabled:
            return False
        result = self.check()
        return result.severity == LoopSeverity.CRITICAL

    def reset(self) -> None:
        self._history.clear()

    def get_stats(self) -> dict:
        return {
            "enabled": self._config.enabled,
            "history_size": len(self._history),
            "total_detections": self._total_detections,
            "blocked_count": self._blocked_count,
            "detectors": [d.name for d in self._detectors],
            "warn_threshold": self._config.warn_threshold,
            "critical_threshold": self._config.critical_threshold,
        }


_global_detector: Optional[DoomLoopDetector] = None


def get_doom_loop_detector(config: Optional[LoopDetectionConfig] = None) -> DoomLoopDetector:
    global _global_detector
    if config is not None:
        _global_detector = DoomLoopDetector(config)
    elif _global_detector is None:
        _global_detector = DoomLoopDetector()
    return _global_detector
