# -*- coding: utf-8 -*-
"""L0 Rule Auto-Learner - Learn runtime rules from user interactions.

V7.4 Iron Law 16+18: Every successful L0/L1 routing is a learning signal.
When the same user input pattern is routed to L0/L1 multiple times,
the learner extracts a new RuntimeRule so future similar inputs
skip L1/L2/L3 entirely.

This is the self-improving mechanism that makes L0 rules grow over time,
reducing LLM dependency with each interaction.
"""

from __future__ import annotations

import json
import logging
import re
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_LEARNED_RULES_DIR = Path.home() / ".xingzierai" / "learned_rules"


@dataclass
class InteractionRecord:
    user_input: str
    tier: str
    output: str
    rule_id: str = ""
    confidence: float = 0.0
    timestamp: float = field(default_factory=time.time)


@dataclass
class LearnedRule:
    id: str
    pattern: str
    category: str
    action: str
    output_template: str
    source_inputs: List[str] = field(default_factory=list)
    hit_count: int = 0
    confidence: float = 0.5
    created_at: float = field(default_factory=time.time)
    priority: int = 50

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "pattern": self.pattern,
            "category": self.category,
            "action": self.action,
            "output_template": self.output_template,
            "source_inputs": self.source_inputs[:5],
            "hit_count": self.hit_count,
            "confidence": round(self.confidence, 4),
            "created_at": self.created_at,
            "priority": self.priority,
        }


class RuleAutoLearner:
    """L0 Rule Auto-Learner.

    Observes user interactions and extracts patterns that can be
    converted into deterministic L0 rules.

    Learning algorithm:
    1. Record every L0/L1 routing result
    2. Cluster similar inputs by keyword overlap
    3. When a cluster reaches MIN_CLUSTER_SIZE, extract a pattern
    4. Validate the pattern against historical data
    5. If validation passes, register as a new RuntimeRule

    This makes the L0 rule set self-expanding without manual intervention.
    """

    MIN_CLUSTER_SIZE = 3
    MIN_CONFIDENCE = 0.7
    MAX_LEARNED_RULES = 200
    MAX_INTERACTIONS = 5000

    def __init__(self, storage_dir: Optional[str] = None):
        self._storage_dir = Path(storage_dir) if storage_dir else _LEARNED_RULES_DIR
        self._interactions: List[InteractionRecord] = []
        self._learned_rules: Dict[str, LearnedRule] = {}
        self._pattern_counter: Counter = Counter()
        self._next_rule_id = 1
        self._stats = {
            "total_interactions": 0,
            "l0_l1_interactions": 0,
            "rules_learned": 0,
            "rules_applied": 0,
        }
        self._load()

    def record_interaction(self, record: InteractionRecord) -> None:
        """Record a user interaction for learning."""
        self._interactions.append(record)
        self._stats["total_interactions"] += 1

        if record.tier in ("L0", "L1"):
            self._stats["l0_l1_interactions"] += 1
            self._extract_pattern(record)

        if len(self._interactions) > self.MAX_INTERACTIONS:
            self._interactions = self._interactions[-self.MAX_INTERACTIONS:]

    def _extract_pattern(self, record: InteractionRecord) -> None:
        """Extract a keyword pattern from an L0/L1 interaction."""
        words = re.findall(r"[a-zA-Z\u4e00-\u9fff]+", record.user_input.lower())
        if len(words) < 1:
            return

        key_phrases = []
        for w in words:
            if len(w) >= 2:
                key_phrases.append(w)

        if not key_phrases:
            return

        for phrase in key_phrases[:3]:
            pattern_key = (phrase, record.output[:50])
            self._pattern_counter[pattern_key] += 1

            if self._pattern_counter[pattern_key] >= self.MIN_CLUSTER_SIZE:
                self._try_create_rule(phrase, record)

        self._try_bigram_pattern(record)

    def _try_bigram_pattern(self, record: InteractionRecord) -> None:
        """Try to extract bigram (2-word) patterns for more specific rules."""
        words = re.findall(r"[a-zA-Z\u4e00-\u9fff]+", record.user_input.lower())
        if len(words) < 2:
            return

        for i in range(len(words) - 1):
            bigram = f"{words[i]} {words[i+1]}"
            if len(bigram) < 3:
                continue

            pattern_key = (bigram, record.output[:50])
            self._pattern_counter[pattern_key] += 1

            if self._pattern_counter[pattern_key] >= self.MIN_CLUSTER_SIZE:
                self._try_create_rule(bigram.replace(" ", "\\s+"), record)

    def _try_create_rule(self, keyword: str, reference: InteractionRecord) -> None:
        """Try to create a new learned rule from a keyword pattern."""
        for existing in self._learned_rules.values():
            if keyword in existing.pattern:
                return

        if len(self._learned_rules) >= self.MAX_LEARNED_RULES:
            return

        matching_interactions = [
            ir for ir in self._interactions
            if keyword in ir.user_input.lower()
            and ir.tier in ("L0", "L1")
            and ir.confidence >= 0.5
        ]

        if len(matching_interactions) < self.MIN_CLUSTER_SIZE:
            return

        outputs = [ir.output for ir in matching_interactions]
        output_counter = Counter(outputs)
        most_common_output, count = output_counter.most_common(1)[0]
        consistency = count / len(outputs)

        if consistency < self.MIN_CONFIDENCE:
            return

        rule_id = f"LR-{self._next_rule_id:04d}"
        self._next_rule_id += 1

        category = self._infer_category(keyword, most_common_output)

        rule = LearnedRule(
            id=rule_id,
            pattern=re.escape(keyword),
            category=category,
            action=f"learned_{rule_id}",
            output_template=most_common_output,
            source_inputs=[ir.user_input[:50] for ir in matching_interactions[:5]],
            hit_count=count,
            confidence=min(consistency, 0.95),
            priority=max(10, int(50 * consistency)),
        )

        self._learned_rules[rule_id] = rule
        self._stats["rules_learned"] += 1

        logger.info(
            "RuleAutoLearner: learned rule %s pattern='%s' category=%s confidence=%.2f",
            rule_id, keyword, category, consistency,
        )

        self._save()

    def _infer_category(self, keyword: str, output: str) -> str:
        """Infer the category of a learned rule."""
        kw = keyword.lower()
        if any(g in kw for g in ["hi", "hello", "你好", "嗨", "您好", "bye", "再见", "谢谢"]):
            return "greeting"
        if any(t in kw for t in ["时间", "几点", "date", "time", "今天"]):
            return "time"
        if any(s in kw for s in ["状态", "status", "健康", "运行"]):
            return "status"
        if any(h in kw for h in ["帮助", "help", "怎么"]):
            return "help"
        if any(e in kw for e in ["进化", "evolve", "测试", "test", "调研", "audit"]):
            return "evolution"
        return "learned"

    def get_learned_rules(self) -> List[LearnedRule]:
        """Get all learned rules sorted by confidence."""
        return sorted(self._learned_rules.values(), key=lambda r: -r.confidence)

    def get_runtime_rules(self) -> List[Dict[str, Any]]:
        """Get learned rules in RuntimeRule-compatible format."""
        from .reasoning_router import RuntimeRule
        rules = []
        for lr in self._learned_rules.values():
            rules.append(RuntimeRule(
                id=lr.id,
                name=f"learned_{lr.category}_{lr.id}",
                pattern=lr.pattern,
                category=lr.category,
                action=lr.action,
                priority=lr.priority,
                confidence=lr.confidence,
            ))
        return rules

    def create_action_handler(self, rule: LearnedRule) -> Any:
        """Create an action handler for a learned rule."""
        output = rule.output_template

        def handler(context: Dict[str, Any]) -> str:
            rule.hit_count += 1
            self._stats["rules_applied"] += 1
            return output

        return handler

    def get_stats(self) -> Dict[str, Any]:
        return {
            **self._stats,
            "learned_rules_count": len(self._learned_rules),
            "l0_l1_rate": (
                self._stats["l0_l1_interactions"]
                / max(self._stats["total_interactions"], 1)
            ),
        }

    def prune_stale_rules(self, max_age_hours: int = 168, min_hits: int = 2) -> int:
        """Remove learned rules that haven't been used recently.

        Args:
            max_age_hours: Maximum age in hours before a rule is considered stale
            min_hits: Minimum hits required to keep a rule alive

        Returns:
            Number of pruned rules
        """
        now = time.time()
        cutoff = now - (max_age_hours * 3600)
        to_prune = []
        for rule_id, rule in self._learned_rules.items():
            if rule.created_at < cutoff and rule.hit_count < min_hits:
                to_prune.append(rule_id)

        for rule_id in to_prune:
            del self._learned_rules[rule_id]

        if to_prune:
            self._save()
            logger.info("Pruned %d stale learned rules", len(to_prune))

        return len(to_prune)

    def _save(self) -> None:
        try:
            self._storage_dir.mkdir(parents=True, exist_ok=True)
            data = {
                "next_rule_id": self._next_rule_id,
                "learned_rules": {k: v.to_dict() for k, v in self._learned_rules.items()},
                "stats": self._stats,
            }
            path = self._storage_dir / "learned_rules.json"
            path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e:
            logger.debug("Failed to save learned rules: %s", e)

    def _load(self) -> None:
        try:
            path = self._storage_dir / "learned_rules.json"
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            self._next_rule_id = data.get("next_rule_id", 1)
            self._stats = data.get("stats", self._stats)
            for k, v in data.get("learned_rules", {}).items():
                self._learned_rules[k] = LearnedRule(
                    id=v["id"],
                    pattern=v["pattern"],
                    category=v["category"],
                    action=v["action"],
                    output_template=v["output_template"],
                    source_inputs=v.get("source_inputs", []),
                    hit_count=v.get("hit_count", 0),
                    confidence=v.get("confidence", 0.5),
                    priority=v.get("priority", 50),
                )
        except Exception as e:
            logger.debug("Failed to load learned rules: %s", e)
