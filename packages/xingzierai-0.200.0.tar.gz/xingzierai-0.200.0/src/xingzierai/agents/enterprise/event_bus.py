# -*- coding: utf-8 -*-
"""Unified Event Bus - Cross-module communication for enterprise orchestration.

Extends the existing EvolutionEventBus pattern with:
- asyncio.Queue-based local pub/sub (primary)
- Optional Redis Pub/Sub for distributed deployments
- Topic-based routing with wildcard support
- Event persistence for replay and audit
- Back-pressure handling via bounded queues
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Union

logger = logging.getLogger(__name__)


class EnterpriseEventType(str, Enum):
    AGENT_LIFECYCLE = "agent_lifecycle"
    HEARTBEAT_TRIGGERED = "heartbeat_triggered"
    HEARTBEAT_COMPLETED = "heartbeat_completed"
    HEARTBEAT_TIMEOUT = "heartbeat_timeout"
    BUDGET_THRESHOLD = "budget_threshold"
    BUDGET_EXCEEDED = "budget_exceeded"
    TASK_CREATED = "task_created"
    TASK_UPDATED = "task_updated"
    TASK_CHECKED_OUT = "task_checked_out"
    TASK_COMPLETED = "task_completed"
    ORG_CHANGED = "org_changed"
    APPROVAL_REQUESTED = "approval_requested"
    APPROVAL_GRANTED = "approval_granted"
    APPROVAL_REJECTED = "approval_rejected"
    AGENT_PAUSED = "agent_paused"
    AGENT_RESUMED = "agent_resumed"
    AGENT_TERMINATED = "agent_terminated"
    COST_RECORDED = "cost_recorded"
    SCHEDULER_JOB_STARTED = "scheduler_job_started"
    SCHEDULER_JOB_COMPLETED = "scheduler_job_completed"
    SCHEDULER_JOB_FAILED = "scheduler_job_failed"
    DEDUP_BLOCKED = "dedup_blocked"
    THUNDERING_HERD_DETECTED = "thundering_herd_detected"


@dataclass
class EnterpriseEvent:
    event_type: EnterpriseEventType
    source: str
    data: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    event_id: str = ""
    correlation_id: str = ""
    namespace: str = "xz"

    def __post_init__(self):
        if not self.event_id:
            prefix = "xz" if self.namespace == "xz" else "pc"
            self.event_id = f"{prefix}_{self.event_type.value}_{int(self.timestamp * 1000)}_{uuid.uuid4().hex[:8]}"


SyncHandler = Callable[[EnterpriseEvent], None]
AsyncHandler = Callable[[EnterpriseEvent], Any]


@dataclass
class Subscription:
    subscriber_id: str
    topic: str
    handler: Union[SyncHandler, AsyncHandler]
    is_async: bool = False
    created_at: float = field(default_factory=time.time)


class EnterpriseEventBus:
    MAX_HISTORY = 1000
    MAX_HANDLERS_PER_TOPIC = 30
    MAX_QUEUE_SIZE = 5000

    def __init__(self, redis_url: Optional[str] = None):
        self._sync_handlers: Dict[str, List[SyncHandler]] = defaultdict(list)
        self._async_handlers: Dict[str, List[AsyncHandler]] = defaultdict(list)
        self._history: List[EnterpriseEvent] = []
        self._subscribers: Dict[str, Subscription] = {}
        self._queues: Dict[str, asyncio.Queue] = {}
        self._redis_url = redis_url
        self._redis_pub = None
        self._redis_sub = None
        self._redis_task: Optional[asyncio.Task] = None
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        if self._redis_url:
            try:
                import redis.asyncio as aioredis
                self._redis_pub = aioredis.from_url(self._redis_url)
                self._redis_sub = self._redis_pub.pubsub()
                self._redis_task = asyncio.create_task(self._redis_listener())
                logger.info("EnterpriseEventBus started with Redis backend: %s", self._redis_url)
            except ImportError:
                logger.warning("redis.asyncio not available, falling back to local-only mode")
            except Exception as e:
                logger.warning("Redis connection failed: %s, falling back to local-only mode", e)
        else:
            logger.info("EnterpriseEventBus started in local-only mode")

    async def stop(self) -> None:
        if self._redis_task:
            self._redis_task.cancel()
            try:
                await self._redis_task
            except asyncio.CancelledError:
                pass
        if self._redis_pub:
            await self._redis_pub.close()
        self._sync_handlers.clear()
        self._async_handlers.clear()
        self._queues.clear()
        logger.info("EnterpriseEventBus stopped")

    def subscribe(
        self,
        topic: str,
        handler: Union[SyncHandler, AsyncHandler],
        is_async: bool = False,
    ) -> str:
        subscriber_id = f"sub_{uuid.uuid4().hex[:12]}"
        sub = Subscription(
            subscriber_id=subscriber_id,
            topic=topic,
            handler=handler,
            is_async=is_async,
        )
        self._subscribers[subscriber_id] = sub

        if is_async:
            key = topic
            if len(self._async_handlers[key]) >= self.MAX_HANDLERS_PER_TOPIC:
                logger.warning("Max async handlers reached for topic %s", key)
                return ""
            self._async_handlers[key].append(handler)
        else:
            key = topic
            if len(self._sync_handlers[key]) >= self.MAX_HANDLERS_PER_TOPIC:
                logger.warning("Max sync handlers reached for topic %s", key)
                return ""
            self._sync_handlers[key].append(handler)

        return subscriber_id

    def subscribe_queue(self, topic: str, maxsize: int = 0) -> str:
        queue_id = f"q_{uuid.uuid4().hex[:12]}"
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize or self.MAX_QUEUE_SIZE)
        self._queues[queue_id] = q

        async def _queue_handler(event: EnterpriseEvent) -> None:
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                dropped = await q.get()
                logger.warning("Queue %s full, dropped oldest event: %s", queue_id, dropped.event_id)
                q.put_nowait(event)

        self.subscribe(topic, _queue_handler, is_async=True)
        return queue_id

    def get_queue(self, queue_id: str) -> Optional[asyncio.Queue]:
        return self._queues.get(queue_id)

    def unsubscribe(self, subscriber_id: str) -> bool:
        sub = self._subscribers.pop(subscriber_id, None)
        if sub is None:
            return False
        key = sub.topic
        if sub.is_async:
            if sub.handler in self._async_handlers.get(key, []):
                self._async_handlers[key].remove(sub.handler)
        else:
            if sub.handler in self._sync_handlers.get(key, []):
                self._sync_handlers[key].remove(sub.handler)
        return True

    def publish(self, event: EnterpriseEvent) -> int:
        delivered = self._deliver_local(event)
        self._history.append(event)
        if len(self._history) > self.MAX_HISTORY:
            self._history = self._history[-self.MAX_HISTORY:]
        logger.debug(
            "Published event %s from %s to %d handlers",
            event.event_type.value,
            event.source,
            delivered,
        )
        return delivered

    async def publish_async(self, event: EnterpriseEvent) -> int:
        delivered = self._deliver_local(event)

        key = event.event_type.value
        for handler in self._async_handlers.get(key, []):
            try:
                result = handler(event)
                if asyncio.iscoroutine(result):
                    await result
                delivered += 1
            except Exception as e:
                logger.error("Async handler error for %s: %s", key, e)

        for handler in self._async_handlers.get("*", []):
            try:
                result = handler(event)
                if asyncio.iscoroutine(result):
                    await result
                delivered += 1
            except Exception as e:
                logger.error("Wildcard async handler error: %s", e)

        self._history.append(event)
        if len(self._history) > self.MAX_HISTORY:
            self._history = self._history[-self.MAX_HISTORY:]

        if self._redis_pub:
            try:
                await self._redis_pub.publish(
                    f"enterprise:{event.event_type.value}",
                    json.dumps({
                        "event_id": event.event_id,
                        "event_type": event.event_type.value,
                        "source": event.source,
                        "data": event.data,
                        "timestamp": event.timestamp,
                        "namespace": event.namespace,
                    }),
                )
            except Exception as e:
                logger.warning("Redis publish failed: %s", e)

        return delivered

    def _deliver_local(self, event: EnterpriseEvent) -> int:
        delivered = 0
        key = event.event_type.value

        for handler in self._sync_handlers.get(key, []):
            try:
                handler(event)
                delivered += 1
            except Exception as e:
                logger.error("Sync handler error for %s: %s", key, e)

        for handler in self._sync_handlers.get("*", []):
            try:
                handler(event)
                delivered += 1
            except Exception as e:
                logger.error("Wildcard sync handler error: %s", e)

        return delivered

    async def _redis_listener(self) -> None:
        if not self._redis_sub:
            return
        try:
            await self._redis_sub.psubscribe("enterprise:*")
            async for message in self._redis_sub.listen():
                if message["type"] == "pmessage":
                    try:
                        data = json.loads(message["data"])
                        event = EnterpriseEvent(
                            event_type=EnterpriseEventType(data["event_type"]),
                            source=data.get("source", "redis"),
                            data=data.get("data", {}),
                            timestamp=data.get("timestamp", time.time()),
                            event_id=data.get("event_id", ""),
                            namespace=data.get("namespace", "pc"),
                        )
                        self._deliver_local(event)
                    except Exception as e:
                        logger.warning("Redis message parse error: %s", e)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error("Redis listener error: %s", e)

    def get_history(
        self,
        event_type: Optional[EnterpriseEventType] = None,
        source: Optional[str] = None,
        namespace: Optional[str] = None,
        limit: int = 50,
    ) -> List[EnterpriseEvent]:
        events = self._history
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        if source:
            events = [e for e in events if e.source == source]
        if namespace:
            events = [e for e in events if e.namespace == namespace]
        return events[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        by_type: Dict[str, int] = defaultdict(int)
        by_source: Dict[str, int] = defaultdict(int)
        for event in self._history:
            by_type[event.event_type.value] += 1
            by_source[event.source] += 1
        return {
            "total_events": len(self._history),
            "by_type": dict(by_type),
            "by_source": dict(by_source),
            "subscribers": len(self._subscribers),
            "queues": len(self._queues),
            "sync_handler_count": sum(len(v) for v in self._sync_handlers.values()),
            "async_handler_count": sum(len(v) for v in self._async_handlers.values()),
            "redis_enabled": self._redis_pub is not None,
        }

    def clear_history(self) -> None:
        self._history.clear()


_bus_instance: Optional[EnterpriseEventBus] = None


def get_enterprise_bus() -> EnterpriseEventBus:
    global _bus_instance
    if _bus_instance is None:
        _bus_instance = EnterpriseEventBus()
    return _bus_instance


def reset_enterprise_bus() -> None:
    global _bus_instance
    _bus_instance = None
