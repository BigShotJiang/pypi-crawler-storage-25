# -*- coding: utf-8 -*-
"""Enterprise module - Paperclip-inspired enterprise orchestration layer.

Integrates Paperclip's management concepts into XINGZIER AI:
- Organization management (Company Model, Org Chart, Board Governance)
- Heartbeat scheduling (unified heartbeat routing)
- Budget control (multi-level budget coordination)
- Governance & approval (Board approval gates)
- Task hierarchy (Initiative -> Project -> Milestone -> Issue)

All features are controlled by feature flags and default to disabled.

Phase 0 modules (Architecture Prerequisites):
- event_bus: Unified event bus (asyncio.Queue + optional Redis Pub/Sub)
- lifecycle: Agent lifecycle state machine
- heartbeat_router: Unified heartbeat routing across all 4 heartbeat layers
- budget_coordinator: Coordinate TokenBudget (technical) and financial budget (business)
- lock_ordering: Deadlock prevention via strict lock acquisition ordering
- id_namespace: ID collision prevention with xz_/pc_/ent_ prefixes

Phase 2 modules (Core Integration):
- company_model: Company, OrgChart, AgentRole, CapabilityRegistry
- heartbeat_scheduler: Heartbeat scheduling with adapter pattern
- task_hierarchy: Initiative->Project->Milestone->Issue with atomic checkout
- budget_engine: Multi-level budget delegation with billing codes

Phase 3 modules (Governance):
- board_governance: Board governance model with approval queue
"""

from .event_bus import (
    EnterpriseEventBus,
    EnterpriseEventType,
    EnterpriseEvent,
    get_enterprise_bus,
    reset_enterprise_bus,
)
from .lifecycle import (
    AgentLifecycleState,
    LifecycleStateMachine,
    LifecycleManager,
    LifecycleConfig,
    get_lifecycle_manager,
)
from .heartbeat_router import (
    HeartbeatSource,
    HeartbeatPayload,
    HeartbeatRequest,
    HeartbeatResponse,
    HeartbeatRouter,
    HeartbeatRouteConfig,
    get_heartbeat_router,
)
from .budget_coordinator import (
    BudgetDimension,
    BudgetControlLevel,
    FinancialBudgetLevel,
    FinancialBudgetPolicy,
    FinancialBudgetSnapshot,
    BudgetCoordinator,
    BudgetCoordinationConfig,
    get_budget_coordinator,
)
from .lock_ordering import (
    LockLevel,
    OrderedAsyncLock,
    LockOrderValidator,
    get_lock_validator,
)
from .id_namespace import (
    IDNamespace,
    IDType,
    make_id,
    make_agent_id,
    make_company_id,
    make_task_id,
    is_enterprise_id,
    is_xingzier_id,
)
from .company_model import (
    AgentRole,
    AgentStatus,
    CompanyGoal,
    CompanyModel,
    OrgNode,
    OrgChart,
    CapabilityEntry,
    CapabilityRegistry,
)
from .heartbeat_scheduler import (
    AdapterType,
    AgentAdapter,
    AgentAdapterConfig,
    XingzierAIAdapter,
    ProcessAdapter,
    HTTPAdapter,
    HeartbeatScheduleConfig,
    HeartbeatRun,
    HeartbeatScheduler,
)
from .task_hierarchy import (
    TaskType,
    TaskStatus,
    CheckoutStatus,
    TaskComment,
    TaskNode,
    TaskHierarchy,
)
from .budget_engine import (
    BillingCode,
    CostRecord,
    BudgetDelegation,
    BudgetEngine,
)
from .board_governance import (
    ApprovalType,
    ApprovalStatus,
    ApprovalRequest,
    ApprovalQueue,
    BoardGovernance,
)

__all__ = [
    "EnterpriseEventBus",
    "EnterpriseEventType",
    "EnterpriseEvent",
    "get_enterprise_bus",
    "reset_enterprise_bus",
    "AgentLifecycleState",
    "LifecycleStateMachine",
    "LifecycleManager",
    "LifecycleConfig",
    "get_lifecycle_manager",
    "HeartbeatSource",
    "HeartbeatPayload",
    "HeartbeatRequest",
    "HeartbeatResponse",
    "HeartbeatRouter",
    "HeartbeatRouteConfig",
    "get_heartbeat_router",
    "BudgetDimension",
    "BudgetControlLevel",
    "FinancialBudgetLevel",
    "FinancialBudgetPolicy",
    "FinancialBudgetSnapshot",
    "BudgetCoordinator",
    "BudgetCoordinationConfig",
    "get_budget_coordinator",
    "LockLevel",
    "OrderedAsyncLock",
    "LockOrderValidator",
    "get_lock_validator",
    "IDNamespace",
    "IDType",
    "make_id",
    "make_agent_id",
    "make_company_id",
    "make_task_id",
    "is_enterprise_id",
    "is_xingzier_id",
    "AgentRole",
    "AgentStatus",
    "CompanyGoal",
    "CompanyModel",
    "OrgNode",
    "OrgChart",
    "CapabilityEntry",
    "CapabilityRegistry",
    "AdapterType",
    "AgentAdapter",
    "AgentAdapterConfig",
    "XingzierAIAdapter",
    "ProcessAdapter",
    "HTTPAdapter",
    "HeartbeatScheduleConfig",
    "HeartbeatRun",
    "HeartbeatScheduler",
    "TaskType",
    "TaskStatus",
    "CheckoutStatus",
    "TaskComment",
    "TaskNode",
    "TaskHierarchy",
    "BillingCode",
    "CostRecord",
    "BudgetDelegation",
    "BudgetEngine",
    "ApprovalType",
    "ApprovalStatus",
    "ApprovalRequest",
    "ApprovalQueue",
    "BoardGovernance",
]
