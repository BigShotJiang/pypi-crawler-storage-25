# -*- coding: utf-8 -*-
"""ID Namespace Isolation - Prevent ID collisions between XINGZIER AI and Paperclip systems.

Uses prefixes to distinguish IDs from different origins:
- xz_: XINGZIER AI native IDs (existing system)
- pc_: Paperclip-inspired enterprise IDs (new system)
- ent_: Enterprise module IDs (shared infrastructure)

This ensures that IDs from the new enterprise layer never collide
with existing XINGZIER AI IDs, even when both systems operate on
the same agent or task.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class IDNamespace(str, Enum):
    XINGZIER = "xz"
    PAPERCLIP = "pc"
    ENTERPRISE = "ent"


class IDType(str, Enum):
    AGENT = "agent"
    COMPANY = "company"
    ORG_UNIT = "org"
    TASK = "task"
    INITIATIVE = "init"
    PROJECT = "proj"
    MILESTONE = "mile"
    ISSUE = "issue"
    HEARTBEAT = "hb"
    BUDGET = "budget"
    APPROVAL = "appr"
    COST_EVENT = "cost"
    RUN = "run"
    SCHEDULER_JOB = "sjob"


@dataclass
class IDSpec:
    namespace: IDNamespace
    id_type: IDType
    short_id: str = ""

    def generate(self) -> str:
        prefix = f"{self.namespace.value}_{self.id_type.value}"
        if self.short_id:
            return f"{prefix}_{self.short_id}"
        return f"{prefix}_{uuid.uuid4().hex[:12]}"

    @staticmethod
    def parse(id_str: str) -> Optional["IDSpec"]:
        if not id_str or "_" not in id_str:
            return None
        parts = id_str.split("_", 2)
        if len(parts) < 2:
            return None
        try:
            namespace = IDNamespace(parts[0])
            id_type = IDType(parts[1])
            short_id = parts[2] if len(parts) > 2 else ""
            return IDSpec(namespace=namespace, id_type=id_type, short_id=short_id)
        except ValueError:
            return None


def make_id(namespace: IDNamespace, id_type: IDType, short_id: str = "") -> str:
    return IDSpec(namespace=namespace, id_type=id_type, short_id=short_id).generate()


def is_enterprise_id(id_str: str) -> bool:
    return id_str.startswith("ent_") or id_str.startswith("pc_")


def is_xingzier_id(id_str: str) -> bool:
    return id_str.startswith("xz_")


def make_agent_id(agent_name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.AGENT, agent_name)


def make_company_id(company_name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.COMPANY, company_name)


def make_org_id(org_name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.ORG_UNIT, org_name)


def make_task_id(task_name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.TASK, task_name)


def make_initiative_id(name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.INITIATIVE, name)


def make_project_id(name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.PROJECT, name)


def make_milestone_id(name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.MILESTONE, name)


def make_issue_id(name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.ISSUE, name)


def make_heartbeat_id(agent_id: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.HEARTBEAT, agent_id)


def make_budget_id(agent_id: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.BUDGET, agent_id)


def make_approval_id(name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.APPROVAL, name)


def make_cost_event_id(agent_id: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.COST_EVENT, agent_id)


def make_run_id(agent_id: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.RUN, agent_id)


def make_scheduler_job_id(name: str = "") -> str:
    return make_id(IDNamespace.ENTERPRISE, IDType.SCHEDULER_JOB, name)
