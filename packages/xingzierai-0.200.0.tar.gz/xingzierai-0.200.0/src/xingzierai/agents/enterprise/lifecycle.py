# -*- coding: utf-8 -*-
"""Lifecycle State Machine - Unified agent lifecycle management.

Merges XINGZIER AI's existing agent states with Paperclip's lifecycle model:
- initializing → running → pausing → paused → stopping → terminated
- Graceful pause with grace period before forced termination
- Event emission on every state transition
- Thread-safe with asyncio.Lock
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from .event_bus import EnterpriseEvent, EnterpriseEventBus, EnterpriseEventType, get_enterprise_bus

logger = logging.getLogger(__name__)


class AgentLifecycleState(str, Enum):
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSING = "pausing"
    PAUSED = "paused"
    STOPPING = "stopping"
    TERMINATED = "terminated"


_VALID_TRANSITIONS: Dict[AgentLifecycleState, set] = {
    AgentLifecycleState.INITIALIZING: {
        AgentLifecycleState.RUNNING,
        AgentLifecycleState.STOPPING,
        AgentLifecycleState.TERMINATED,
    },
    AgentLifecycleState.RUNNING: {
        AgentLifecycleState.PAUSING,
        AgentLifecycleState.STOPPING,
        AgentLifecycleState.TERMINATED,
    },
    AgentLifecycleState.PAUSING: {
        AgentLifecycleState.PAUSED,
        AgentLifecycleState.RUNNING,
        AgentLifecycleState.STOPPING,
        AgentLifecycleState.TERMINATED,
    },
    AgentLifecycleState.PAUSED: {
        AgentLifecycleState.RUNNING,
        AgentLifecycleState.STOPPING,
        AgentLifecycleState.TERMINATED,
    },
    AgentLifecycleState.STOPPING: {
        AgentLifecycleState.TERMINATED,
    },
    AgentLifecycleState.TERMINATED: set(),
}

_EVENT_MAP: Dict[AgentLifecycleState, Optional[EnterpriseEventType]] = {
    AgentLifecycleState.INITIALIZING: None,
    AgentLifecycleState.RUNNING: None,
    AgentLifecycleState.PAUSING: EnterpriseEventType.AGENT_PAUSED,
    AgentLifecycleState.PAUSED: EnterpriseEventType.AGENT_PAUSED,
    AgentLifecycleState.STOPPING: None,
    AgentLifecycleState.TERMINATED: EnterpriseEventType.AGENT_TERMINATED,
}


@dataclass
class LifecycleTransition:
    from_state: AgentLifecycleState
    to_state: AgentLifecycleState
    timestamp: float = field(default_factory=time.time)
    reason: str = ""
    actor: str = ""


@dataclass
class LifecycleConfig:
    grace_period_seconds: float = 30.0
    max_pause_wait_seconds: float = 60.0
    auto_terminate_on_stuck: bool = True
    stuck_detection_seconds: float = 300.0


StateCallback = Callable[[AgentLifecycleState, AgentLifecycleState, Dict[str, Any]], None]


class LifecycleStateMachine:
    def __init__(
        self,
        agent_id: str,
        config: Optional[LifecycleConfig] = None,
        event_bus: Optional[EnterpriseEventBus] = None,
    ):
        self.agent_id = agent_id
        self.config = config or LifecycleConfig()
        self._state = AgentLifecycleState.INITIALIZING
        self._lock = asyncio.Lock()
        self._history: List[LifecycleTransition] = []
        self._callbacks: List[StateCallback] = []
        self._event_bus = event_bus
        self._entered_at: float = time.time()
        self._metadata: Dict[str, Any] = {}

    @property
    def state(self) -> AgentLifecycleState:
        return self._state

    @property
    def history(self) -> List[LifecycleTransition]:
        return list(self._history)

    @property
    def time_in_state(self) -> float:
        return time.time() - self._entered_at

    def can_transition(self, target: AgentLifecycleState) -> bool:
        return target in _VALID_TRANSITIONS.get(self._state, set())

    def register_callback(self, callback: StateCallback) -> None:
        self._callbacks.append(callback)

    async def transition(
        self,
        target: AgentLifecycleState,
        reason: str = "",
        actor: str = "system",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        async with self._lock:
            if not self.can_transition(target):
                logger.warning(
                    "Invalid transition for agent %s: %s -> %s",
                    self.agent_id,
                    self._state.value,
                    target.value,
                )
                return False

            old_state = self._state
            transition = LifecycleTransition(
                from_state=old_state,
                to_state=target,
                reason=reason,
                actor=actor,
            )
            self._history.append(transition)
            self._state = target
            self._entered_at = time.time()
            if metadata:
                self._metadata.update(metadata)

            logger.info(
                "Agent %s lifecycle: %s -> %s (reason=%s, actor=%s)",
                self.agent_id,
                old_state.value,
                target.value,
                reason,
                actor,
            )

            self._fire_callbacks(old_state, target, metadata or {})

            event_type = _EVENT_MAP.get(target)
            if event_type and self._event_bus:
                event = EnterpriseEvent(
                    event_type=event_type,
                    source=f"lifecycle:{self.agent_id}",
                    data={
                        "agent_id": self.agent_id,
                        "from_state": old_state.value,
                        "to_state": target.value,
                        "reason": reason,
                        "actor": actor,
                    },
                )
                await self._event_bus.publish_async(event)

            return True

    async def start(self, reason: str = "", actor: str = "system") -> bool:
        return await self.transition(AgentLifecycleState.RUNNING, reason=reason, actor=actor)

    async def pause(self, reason: str = "", actor: str = "system") -> bool:
        if not await self.transition(AgentLifecycleState.PAUSING, reason=reason, actor=actor):
            return False
        return True

    async def complete_pause(self, reason: str = "", actor: str = "system") -> bool:
        return await self.transition(AgentLifecycleState.PAUSED, reason=reason, actor=actor)

    async def resume(self, reason: str = "", actor: str = "system") -> bool:
        return await self.transition(AgentLifecycleState.RUNNING, reason=reason, actor=actor)

    async def stop(self, reason: str = "", actor: str = "system") -> bool:
        return await self.transition(AgentLifecycleState.STOPPING, reason=reason, actor=actor)

    async def terminate(self, reason: str = "", actor: str = "system") -> bool:
        return await self.transition(AgentLifecycleState.TERMINATED, reason=reason, actor=actor)

    async def graceful_pause(
        self,
        check_fn: Optional[Callable[[], bool]] = None,
        reason: str = "",
        actor: str = "system",
    ) -> bool:
        if not await self.pause(reason=reason, actor=actor):
            return False

        deadline = time.time() + self.config.grace_period_seconds
        while time.time() < deadline:
            if check_fn and check_fn():
                break
            if self._state == AgentLifecycleState.PAUSED:
                return True
            await asyncio.sleep(0.5)

        if self._state == AgentLifecycleState.PAUSING:
            logger.warning(
                "Agent %s grace period expired, forcing pause",
                self.agent_id,
            )
            return await self.complete_pause(reason="grace_period_expired", actor=actor)

        return self._state == AgentLifecycleState.PAUSED

    async def graceful_stop(
        self,
        stop_fn: Optional[Callable[[], Any]] = None,
        reason: str = "",
        actor: str = "system",
    ) -> bool:
        if not await self.stop(reason=reason, actor=actor):
            return False

        if stop_fn:
            try:
                result = stop_fn()
                if asyncio.iscoroutine(result):
                    await asyncio.wait_for(result, timeout=self.config.grace_period_seconds)
            except asyncio.TimeoutError:
                logger.warning("Agent %s stop_fn timed out", self.agent_id)
            except Exception as e:
                logger.warning("Agent %s stop_fn error: %s", self.agent_id, e)

        return await self.terminate(reason=reason, actor=actor)

    def _fire_callbacks(
        self,
        old_state: AgentLifecycleState,
        new_state: AgentLifecycleState,
        metadata: Dict[str, Any],
    ) -> None:
        for cb in self._callbacks:
            try:
                cb(old_state, new_state, metadata)
            except Exception as e:
                logger.warning("Lifecycle callback error: %s", e)

    def get_snapshot(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "state": self._state.value,
            "time_in_state": self.time_in_state,
            "transition_count": len(self._history),
            "last_transition": (
                {
                    "from": self._history[-1].from_state.value,
                    "to": self._history[-1].to_state.value,
                    "reason": self._history[-1].reason,
                    "actor": self._history[-1].actor,
                    "timestamp": self._history[-1].timestamp,
                }
                if self._history
                else None
            ),
            "metadata": dict(self._metadata),
        }


class LifecycleManager:
    def __init__(
        self,
        event_bus: Optional[EnterpriseEventBus] = None,
        config: Optional[LifecycleConfig] = None,
    ):
        self._machines: Dict[str, LifecycleStateMachine] = {}
        self._lock = asyncio.Lock()
        self._event_bus = event_bus or get_enterprise_bus()
        self._config = config or LifecycleConfig()

    async def register(self, agent_id: str) -> LifecycleStateMachine:
        async with self._lock:
            if agent_id in self._machines:
                return self._machines[agent_id]
            machine = LifecycleStateMachine(
                agent_id=agent_id,
                config=self._config,
                event_bus=self._event_bus,
            )
            self._machines[agent_id] = machine
            return machine

    async def unregister(self, agent_id: str) -> bool:
        async with self._lock:
            machine = self._machines.pop(agent_id, None)
            if machine and machine.state not in (
                AgentLifecycleState.TERMINATED,
                AgentLifecycleState.STOPPING,
            ):
                await machine.terminate(reason="unregistered", actor="lifecycle_manager")
            return machine is not None

    def get(self, agent_id: str) -> Optional[LifecycleStateMachine]:
        return self._machines.get(agent_id)

    def get_all_states(self) -> Dict[str, AgentLifecycleState]:
        return {aid: m.state for aid, m in self._machines.items()}

    def get_by_state(self, state: AgentLifecycleState) -> List[str]:
        return [aid for aid, m in self._machines.items() if m.state == state]

    def get_running(self) -> List[str]:
        return self.get_by_state(AgentLifecycleState.RUNNING)

    def get_paused(self) -> List[str]:
        return self.get_by_state(AgentLifecycleState.PAUSED)


_manager_instance: Optional[LifecycleManager] = None


def get_lifecycle_manager() -> LifecycleManager:
    global _manager_instance
    if _manager_instance is None:
        _manager_instance = LifecycleManager()
    return _manager_instance
