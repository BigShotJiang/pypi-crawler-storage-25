# -*- coding: utf-8 -*-
"""Company Model - Enterprise company and organizational structure.

Paperclip-inspired company model with:
- Company: top-level entity with goals and budget
- Org Chart: strict tree hierarchy (reports_to)
- Agent Roles: CEO/CTO/CMO etc. with defined responsibilities
- Capability Registry: published skills and capabilities per agent
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set

from .id_namespace import (
    IDNamespace,
    IDType,
    make_company_id,
    make_agent_id,
    make_org_id,
)
from .event_bus import EnterpriseEventBus, EnterpriseEventType, get_enterprise_bus

logger = logging.getLogger(__name__)


class AgentRole(str, Enum):
    CEO = "ceo"
    CTO = "cto"
    CMO = "cmo"
    CFO = "cfo"
    COO = "coo"
    ENGINEER = "engineer"
    DESIGNER = "designer"
    PM = "pm"
    ANALYST = "analyst"
    WORKER = "worker"
    CUSTOM = "custom"


class AgentStatus(str, Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    TERMINATED = "terminated"


@dataclass
class CompanyGoal:
    goal_id: str
    title: str
    description: str = ""
    priority: int = 0
    status: str = "active"
    created_at: float = field(default_factory=time.time)


@dataclass
class CompanyModel:
    company_id: str = ""
    name: str = ""
    description: str = ""
    goals: List[CompanyGoal] = field(default_factory=list)
    monthly_budget_cents: int = 0
    spent_monthly_cents: int = 0
    timezone: str = "UTC"
    created_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.company_id:
            self.company_id = make_company_id(self.name.lower().replace(" ", "_") if self.name else "")

    def add_goal(self, title: str, description: str = "", priority: int = 0) -> CompanyGoal:
        goal = CompanyGoal(
            goal_id=f"goal_{int(time.time() * 1000)}_{len(self.goals)}",
            title=title,
            description=description,
            priority=priority,
        )
        self.goals.append(goal)
        return goal

    def to_dict(self) -> Dict[str, Any]:
        return {
            "company_id": self.company_id,
            "name": self.name,
            "description": self.description,
            "goals": [{"goal_id": g.goal_id, "title": g.title, "status": g.status} for g in self.goals],
            "monthly_budget_cents": self.monthly_budget_cents,
            "spent_monthly_cents": self.spent_monthly_cents,
            "timezone": self.timezone,
        }


@dataclass
class OrgNode:
    agent_id: str
    name: str = ""
    role: AgentRole = AgentRole.WORKER
    title: str = ""
    reports_to: Optional[str] = None
    status: AgentStatus = AgentStatus.ACTIVE
    capabilities: List[str] = field(default_factory=list)
    monthly_budget_cents: int = 0
    spent_monthly_cents: int = 0
    children: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def __post_init__(self):
        if not self.agent_id:
            self.agent_id = make_agent_id(self.name.lower().replace(" ", "_") if self.name else "")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "role": self.role.value,
            "title": self.title,
            "reports_to": self.reports_to,
            "status": self.status.value,
            "capabilities": self.capabilities,
            "monthly_budget_cents": self.monthly_budget_cents,
            "spent_monthly_cents": self.spent_monthly_cents,
            "children": self.children,
        }


class OrgChart:
    def __init__(self, company_id: str = ""):
        self.company_id = company_id
        self._nodes: Dict[str, OrgNode] = {}
        self._root_id: Optional[str] = None

    def add_agent(
        self,
        name: str,
        role: AgentRole = AgentRole.WORKER,
        title: str = "",
        reports_to: Optional[str] = None,
        capabilities: Optional[List[str]] = None,
        monthly_budget_cents: int = 0,
    ) -> OrgNode:
        agent_id = make_agent_id(name.lower().replace(" ", "_"))

        if reports_to and reports_to not in self._nodes:
            raise ValueError(f"Reports-to agent {reports_to} not found in org chart")

        if role == AgentRole.CEO:
            if self._root_id and self._root_id != agent_id:
                raise ValueError("Only one CEO allowed in org chart")
            self._root_id = agent_id

        node = OrgNode(
            agent_id=agent_id,
            name=name,
            role=role,
            title=title or role.value.upper(),
            reports_to=reports_to,
            capabilities=capabilities or [],
            monthly_budget_cents=monthly_budget_cents,
        )
        self._nodes[agent_id] = node

        if reports_to and reports_to in self._nodes:
            parent = self._nodes[reports_to]
            if agent_id not in parent.children:
                parent.children.append(agent_id)

        return node

    def remove_agent(self, agent_id: str) -> bool:
        node = self._nodes.get(agent_id)
        if not node:
            return False

        if node.children:
            raise ValueError(f"Cannot remove agent {agent_id} with active reports. Reassign first.")

        if node.reports_to and node.reports_to in self._nodes:
            parent = self._nodes[node.reports_to]
            parent.children = [c for c in parent.children if c != agent_id]

        if self._root_id == agent_id:
            self._root_id = None

        del self._nodes[agent_id]
        return True

    def get_agent(self, agent_id: str) -> Optional[OrgNode]:
        return self._nodes.get(agent_id)

    def get_reports(self, agent_id: str) -> List[OrgNode]:
        node = self._nodes.get(agent_id)
        if not node:
            return []
        return [self._nodes[cid] for cid in node.children if cid in self._nodes]

    def get_all_reports(self, agent_id: str) -> List[OrgNode]:
        result: List[OrgNode] = []
        direct = self.get_reports(agent_id)
        for report in direct:
            result.append(report)
            result.extend(self.get_all_reports(report.agent_id))
        return result

    def get_chain_of_command(self, agent_id: str) -> List[OrgNode]:
        chain: List[OrgNode] = []
        current = self._nodes.get(agent_id)
        while current:
            chain.append(current)
            if current.reports_to:
                current = self._nodes.get(current.reports_to)
            else:
                break
        return chain

    def get_root(self) -> Optional[OrgNode]:
        if self._root_id:
            return self._nodes.get(self._root_id)
        return None

    def get_all_agents(self) -> List[OrgNode]:
        return list(self._nodes.values())

    def get_agents_by_role(self, role: AgentRole) -> List[OrgNode]:
        return [n for n in self._nodes.values() if n.role == role]

    def get_agents_by_capability(self, capability: str) -> List[OrgNode]:
        return [n for n in self._nodes.values() if capability in n.capabilities]

    def validate(self) -> List[str]:
        errors: List[str] = []
        if not self._root_id:
            errors.append("No CEO/root agent defined")
        for agent_id, node in self._nodes.items():
            if node.reports_to and node.reports_to not in self._nodes:
                errors.append(f"Agent {agent_id} reports to non-existent {node.reports_to}")
            for child_id in node.children:
                if child_id not in self._nodes:
                    errors.append(f"Agent {agent_id} has non-existent child {child_id}")
        return errors

    def to_dict(self) -> Dict[str, Any]:
        return {
            "company_id": self.company_id,
            "root_id": self._root_id,
            "agents": {aid: node.to_dict() for aid, node in self._nodes.items()},
        }


@dataclass
class CapabilityEntry:
    agent_id: str
    capability: str
    description: str = ""
    skill_level: str = "proficient"
    registered_at: float = field(default_factory=time.time)


class CapabilityRegistry:
    def __init__(self):
        self._capabilities: Dict[str, List[CapabilityEntry]] = {}

    def register(
        self,
        agent_id: str,
        capability: str,
        description: str = "",
        skill_level: str = "proficient",
    ) -> CapabilityEntry:
        entry = CapabilityEntry(
            agent_id=agent_id,
            capability=capability,
            description=description,
            skill_level=skill_level,
        )
        if capability not in self._capabilities:
            self._capabilities[capability] = []
        self._capabilities[capability].append(entry)
        return entry

    def unregister(self, agent_id: str, capability: str) -> bool:
        entries = self._capabilities.get(capability, [])
        before = len(entries)
        self._capabilities[capability] = [e for e in entries if e.agent_id != agent_id]
        return len(self._capabilities[capability]) < before

    def find_agents(self, capability: str) -> List[CapabilityEntry]:
        return self._capabilities.get(capability, [])

    def get_agent_capabilities(self, agent_id: str) -> List[CapabilityEntry]:
        result: List[CapabilityEntry] = []
        for entries in self._capabilities.values():
            result.extend(e for e in entries if e.agent_id == agent_id)
        return result

    def get_all_capabilities(self) -> Dict[str, int]:
        return {cap: len(entries) for cap, entries in self._capabilities.items()}

    def to_dict(self) -> Dict[str, Any]:
        return {
            cap: [{"agent_id": e.agent_id, "level": e.skill_level, "desc": e.description} for e in entries]
            for cap, entries in self._capabilities.items()
        }
