# -*- coding: utf-8 -*-
"""Heartbeat Scheduler - Enterprise heartbeat scheduling system.

Paperclip-inspired heartbeat system with:
- Scheduled wake-up → check work → execute
- Thin Ping vs Fat Payload context passing
- Adapter pattern for different agent runtimes
- Graceful pause/resume with grace period
- Integrates with HeartbeatRouter for unified routing
"""
from __future__ import annotations

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union

from .event_bus import EnterpriseEvent, EnterpriseEventBus, EnterpriseEventType, get_enterprise_bus
from .heartbeat_router import HeartbeatSource, HeartbeatPayload, HeartbeatRequest, get_heartbeat_router
from .lifecycle import AgentLifecycleState, LifecycleManager, get_lifecycle_manager
from .id_namespace import make_heartbeat_id

logger = logging.getLogger(__name__)


class AdapterType(str, Enum):
    PROCESS = "process"
    HTTP = "http"
    CLAUDE_LOCAL = "claude_local"
    CODEX_LOCAL = "codex_local"
    OPENCODE_LOCAL = "opencode_local"
    PI_LOCAL = "pi_local"
    CURSOR = "cursor"
    OPENCLAW_GATEWAY = "openclaw_gateway"
    HERMES_LOCAL = "hermes_local"
    XINGZIER_INTERNAL = "xingzierai_internal"


@dataclass
class AgentAdapterConfig:
    adapter_type: AdapterType = AdapterType.XINGZIER_INTERNAL
    command: str = ""
    endpoint: str = ""
    env: Dict[str, str] = field(default_factory=dict)
    timeout_seconds: int = 120


class AgentAdapter(ABC):
    @abstractmethod
    async def invoke(self, agent_config: AgentAdapterConfig, context: Optional[Dict[str, Any]] = None) -> Any:
        ...

    @abstractmethod
    async def status(self, agent_config: AgentAdapterConfig) -> str:
        ...

    @abstractmethod
    async def cancel(self, agent_config: AgentAdapterConfig) -> bool:
        ...


class XingzierAIAdapter(AgentAdapter):
    def __init__(self, runner: Any = None, channel_manager: Any = None):
        self._runner = runner
        self._channel_manager = channel_manager
        self._active_tasks: Dict[str, asyncio.Task] = {}

    async def invoke(self, agent_config: AgentAdapterConfig, context: Optional[Dict[str, Any]] = None) -> Any:
        if not self._runner:
            raise RuntimeError("No runner configured for XingzierAI adapter")

        ctx = context or {}
        query_text = ctx.get("query_text", "")
        if not query_text:
            return None

        request = {
            "input": [{"role": "user", "content": [{"type": "text", "text": query_text}]}],
            "session_id": ctx.get("session_id", "heartbeat"),
            "user_id": ctx.get("user_id", "system"),
        }

        result_chunks = []
        async for event in self._runner.stream_query(request):
            result_chunks.append(event)

        return result_chunks

    async def status(self, agent_config: AgentAdapterConfig) -> str:
        return "ready"

    async def cancel(self, agent_config: AgentAdapterConfig) -> bool:
        return True


class ProcessAdapter(AgentAdapter):
    async def invoke(self, agent_config: AgentAdapterConfig, context: Optional[Dict[str, Any]] = None) -> Any:
        if not agent_config.command:
            raise ValueError("No command configured for process adapter")
        proc = await asyncio.create_subprocess_shell(
            agent_config.command,
            env={**agent_config.env},
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=agent_config.timeout_seconds,
            )
            return {"exit_code": proc.returncode, "stdout": stdout.decode(), "stderr": stderr.decode()}
        except asyncio.TimeoutError:
            proc.kill()
            raise

    async def status(self, agent_config: AgentAdapterConfig) -> str:
        return "ready"

    async def cancel(self, agent_config: AgentAdapterConfig) -> bool:
        return True


class HTTPAdapter(AgentAdapter):
    async def invoke(self, agent_config: AgentAdapterConfig, context: Optional[Dict[str, Any]] = None) -> Any:
        import json
        try:
            import aiohttp
        except ImportError:
            raise RuntimeError("aiohttp required for HTTP adapter")

        async with aiohttp.ClientSession() as session:
            async with session.post(
                agent_config.endpoint,
                json=context or {},
                timeout=aiohttp.ClientTimeout(total=agent_config.timeout_seconds),
            ) as resp:
                return await resp.json()

    async def status(self, agent_config: AgentAdapterConfig) -> str:
        return "ready"

    async def cancel(self, agent_config: AgentAdapterConfig) -> bool:
        return True


@dataclass
class HeartbeatScheduleConfig:
    enabled: bool = False
    every: str = "30m"
    payload_type: HeartbeatPayload = HeartbeatPayload.THIN
    adapter_type: AdapterType = AdapterType.XINGZIER_INTERNAL
    active_hours: Optional[Dict[str, str]] = None
    timeout_seconds: int = 120
    grace_period_seconds: float = 30.0


@dataclass
class HeartbeatRun:
    run_id: str
    agent_id: str
    source: HeartbeatSource = HeartbeatSource.ENTERPRISE_SCHEDULER
    status: str = "queued"
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    result: Optional[str] = None
    error: Optional[str] = None


class HeartbeatScheduler:
    def __init__(
        self,
        event_bus: Optional[EnterpriseEventBus] = None,
        lifecycle_manager: Optional[LifecycleManager] = None,
    ):
        self._event_bus = event_bus or get_enterprise_bus()
        self._lifecycle = lifecycle_manager or get_lifecycle_manager()
        self._adapters: Dict[AdapterType, AgentAdapter] = {
            AdapterType.XINGZIER_INTERNAL: XingzierAIAdapter(),
            AdapterType.PROCESS: ProcessAdapter(),
            AdapterType.HTTP: HTTPAdapter(),
        }
        self._schedules: Dict[str, HeartbeatScheduleConfig] = {}
        self._active_runs: Dict[str, HeartbeatRun] = {}
        self._run_history: List[HeartbeatRun] = []
        self._lock = asyncio.Lock()
        self._max_history = 500

    def register_adapter(self, adapter_type: AdapterType, adapter: AgentAdapter) -> None:
        self._adapters[adapter_type] = adapter

    def set_schedule(self, agent_id: str, config: HeartbeatScheduleConfig) -> None:
        self._schedules[agent_id] = config

    def remove_schedule(self, agent_id: str) -> bool:
        return self._schedules.pop(agent_id, None) is not None

    async def trigger_heartbeat(
        self,
        agent_id: str,
        context: Optional[Dict[str, Any]] = None,
        source: HeartbeatSource = HeartbeatSource.ENTERPRISE_SCHEDULER,
    ) -> HeartbeatRun:
        schedule = self._schedules.get(agent_id)
        adapter_type = schedule.adapter_type if schedule else AdapterType.XINGZIER_INTERNAL
        timeout = schedule.timeout_seconds if schedule else 120

        run_id = make_heartbeat_id(agent_id)
        run = HeartbeatRun(
            run_id=run_id,
            agent_id=agent_id,
            source=source,
            status="queued",
        )

        async with self._lock:
            self._active_runs[run_id] = run

        try:
            router = get_heartbeat_router()
            request = HeartbeatRequest(
                agent_id=agent_id,
                source=source,
                payload_type=schedule.payload_type if schedule else HeartbeatPayload.THIN,
                context=context or {},
            )
            response = await router.route(request)

            if not response.accepted:
                run.status = "rejected"
                run.error = response.reason
                return run

            run.status = "running"
            run.started_at = time.time()

            adapter = self._adapters.get(adapter_type)
            if not adapter:
                raise ValueError(f"No adapter registered for type {adapter_type}")

            result = await asyncio.wait_for(
                adapter.invoke(
                    AgentAdapterConfig(adapter_type=adapter_type, timeout_seconds=timeout),
                    context,
                ),
                timeout=timeout,
            )

            run.status = "succeeded"
            run.result = str(result)[:500] if result else None
            run.finished_at = time.time()

            if self._event_bus:
                event = EnterpriseEvent(
                    event_type=EnterpriseEventType.HEARTBEAT_COMPLETED,
                    source=f"heartbeat_scheduler:{agent_id}",
                    data={
                        "agent_id": agent_id,
                        "run_id": run_id,
                        "source": source.value,
                        "duration": run.finished_at - (run.started_at or run.finished_at),
                    },
                )
                await self._event_bus.publish_async(event)

        except asyncio.TimeoutError:
            run.status = "timed_out"
            run.error = f"Heartbeat timed out after {timeout}s"
            run.finished_at = time.time()
            if self._event_bus:
                event = EnterpriseEvent(
                    event_type=EnterpriseEventType.HEARTBEAT_TIMEOUT,
                    source=f"heartbeat_scheduler:{agent_id}",
                    data={"agent_id": agent_id, "run_id": run_id, "timeout": timeout},
                )
                await self._event_bus.publish_async(event)

        except asyncio.CancelledError:
            run.status = "cancelled"
            run.finished_at = time.time()
            raise

        except Exception as e:
            run.status = "failed"
            run.error = str(e)
            run.finished_at = time.time()
            logger.error("Heartbeat failed for agent %s: %s", agent_id, e)

        finally:
            async with self._lock:
                self._active_runs.pop(run_id, None)
                self._run_history.append(run)
                if len(self._run_history) > self._max_history:
                    self._run_history = self._run_history[-self._max_history:]

        return run

    async def pause_agent(self, agent_id: str, reason: str = "", grace_period: float = 30.0) -> bool:
        lifecycle = self._lifecycle.get(agent_id)
        if not lifecycle:
            return False

        if lifecycle.state != AgentLifecycleState.RUNNING:
            return False

        return await lifecycle.graceful_pause(
            check_fn=lambda: agent_id not in [
                r.agent_id for r in self._active_runs.values() if r.status == "running"
            ],
            reason=reason or "paused_by_heartbeat_scheduler",
            actor="heartbeat_scheduler",
        )

    async def resume_agent(self, agent_id: str, reason: str = "") -> bool:
        lifecycle = self._lifecycle.get(agent_id)
        if not lifecycle:
            return False
        return await lifecycle.resume(reason=reason or "resumed_by_heartbeat_scheduler", actor="heartbeat_scheduler")

    def get_active_runs(self) -> List[HeartbeatRun]:
        return list(self._active_runs.values())

    def get_run_history(self, agent_id: Optional[str] = None, limit: int = 50) -> List[HeartbeatRun]:
        runs = self._run_history
        if agent_id:
            runs = [r for r in runs if r.agent_id == agent_id]
        return runs[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        total = len(self._run_history)
        succeeded = sum(1 for r in self._run_history if r.status == "succeeded")
        failed = sum(1 for r in self._run_history if r.status == "failed")
        timed_out = sum(1 for r in self._run_history if r.status == "timed_out")
        return {
            "schedules": len(self._schedules),
            "active_runs": len(self._active_runs),
            "total_runs": total,
            "succeeded": succeeded,
            "failed": failed,
            "timed_out": timed_out,
            "success_rate": succeeded / total if total > 0 else 0,
        }
