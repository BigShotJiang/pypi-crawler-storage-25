# -*- coding: utf-8 -*-
"""Task Hierarchy - Paperclip-inspired hierarchical task structure.

Initiative -> Project -> Milestone -> Issue -> Sub-issue

Key features:
- Atomic checkout: only one agent works on a task at a time
- Billing codes: cost attribution across teams
- Task comments: discussion thread per task
- Cross-team collaboration rules
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

from .id_namespace import make_task_id, make_initiative_id, make_project_id, make_milestone_id, make_issue_id
from .event_bus import EnterpriseEvent, EnterpriseEventType, get_enterprise_bus

logger = logging.getLogger(__name__)


class TaskType(str, Enum):
    INITIATIVE = "initiative"
    PROJECT = "project"
    MILESTONE = "milestone"
    ISSUE = "issue"
    SUB_ISSUE = "sub_issue"


class TaskStatus(str, Enum):
    DRAFT = "draft"
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    IN_REVIEW = "in_review"
    DONE = "done"
    CANCELLED = "cancelled"
    BLOCKED = "blocked"


class CheckoutStatus(str, Enum):
    AVAILABLE = "available"
    CHECKED_OUT = "checked_out"
    LOCKED = "locked"


@dataclass
class TaskComment:
    comment_id: str
    author_id: str
    content: str
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    parent_comment_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "comment_id": self.comment_id,
            "author_id": self.author_id,
            "content": self.content,
            "created_at": self.created_at,
            "parent_comment_id": self.parent_comment_id,
        }


@dataclass
class TaskNode:
    task_id: str = ""
    task_type: TaskType = TaskType.ISSUE
    title: str = ""
    description: str = ""
    status: TaskStatus = TaskStatus.TODO
    parent_id: Optional[str] = None
    children_ids: List[str] = field(default_factory=list)
    assignee_id: Optional[str] = None
    billing_code: str = ""
    initiative_id: Optional[str] = None
    project_id: Optional[str] = None
    milestone_id: Optional[str] = None
    checkout_status: CheckoutStatus = CheckoutStatus.AVAILABLE
    checked_out_by: Optional[str] = None
    checked_out_at: Optional[float] = None
    comments: List[TaskComment] = field(default_factory=list)
    labels: List[str] = field(default_factory=list)
    priority: int = 0
    estimated_cost_cents: int = 0
    actual_cost_cents: int = 0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    due_date: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.task_id:
            type_map = {
                TaskType.INITIATIVE: make_initiative_id,
                TaskType.PROJECT: make_project_id,
                TaskType.MILESTONE: make_milestone_id,
                TaskType.ISSUE: make_issue_id,
                TaskType.SUB_ISSUE: make_issue_id,
            }
            maker = type_map.get(self.task_type, make_task_id)
            self.task_id = maker(self.title.lower().replace(" ", "_")[:30] if self.title else "")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "task_type": self.task_type.value,
            "title": self.title,
            "status": self.status.value,
            "parent_id": self.parent_id,
            "children_ids": self.children_ids,
            "assignee_id": self.assignee_id,
            "billing_code": self.billing_code,
            "checkout_status": self.checkout_status.value,
            "checked_out_by": self.checked_out_by,
            "priority": self.priority,
            "estimated_cost_cents": self.estimated_cost_cents,
            "actual_cost_cents": self.actual_cost_cents,
            "comment_count": len(self.comments),
        }


class TaskHierarchy:
    def __init__(self, event_bus: Optional[EnterpriseEventBus] = None):
        self._event_bus = event_bus or get_enterprise_bus()
        self._tasks: Dict[str, TaskNode] = {}
        self._lock = asyncio.Lock()

    async def create_task(
        self,
        title: str,
        task_type: TaskType = TaskType.ISSUE,
        parent_id: Optional[str] = None,
        assignee_id: Optional[str] = None,
        billing_code: str = "",
        description: str = "",
        priority: int = 0,
        estimated_cost_cents: int = 0,
    ) -> TaskNode:
        if parent_id and parent_id not in self._tasks:
            raise ValueError(f"Parent task {parent_id} not found")

        parent = self._tasks.get(parent_id)
        if parent:
            valid_child_types = {
                TaskType.INITIATIVE: [TaskType.PROJECT],
                TaskType.PROJECT: [TaskType.MILESTONE],
                TaskType.MILESTONE: [TaskType.ISSUE],
                TaskType.ISSUE: [TaskType.SUB_ISSUE],
                TaskType.SUB_ISSUE: [],
            }
            allowed = valid_child_types.get(parent.task_type, [])
            if task_type not in allowed:
                raise ValueError(
                    f"Cannot add {task_type.value} under {parent.task_type.value}. "
                    f"Allowed: {[t.value for t in allowed]}"
                )

        task = TaskNode(
            task_type=task_type,
            title=title,
            description=description,
            parent_id=parent_id,
            assignee_id=assignee_id,
            billing_code=billing_code,
            priority=priority,
            estimated_cost_cents=estimated_cost_cents,
        )

        if parent_id and parent_id in self._tasks:
            self._tasks[parent_id].children_ids.append(task.task_id)

        if task_type == TaskType.ISSUE and parent:
            task.initiative_id = parent.initiative_id
            task.project_id = parent.project_id
            task.milestone_id = parent.milestone_id
        elif task_type == TaskType.MILESTONE and parent:
            task.initiative_id = parent.initiative_id
            task.project_id = parent.project_id
            task.milestone_id = task.task_id
        elif task_type == TaskType.PROJECT and parent:
            task.initiative_id = parent.initiative_id
            task.project_id = task.task_id
        elif task_type == TaskType.INITIATIVE:
            task.initiative_id = task.task_id

        self._tasks[task.task_id] = task

        event = EnterpriseEvent(
            event_type=EnterpriseEventType.TASK_CREATED,
            source=f"task_hierarchy:{task.task_id}",
            data={
                "task_id": task.task_id,
                "task_type": task.task_type.value,
                "title": title,
                "parent_id": parent_id,
                "assignee_id": assignee_id,
                "billing_code": billing_code,
            },
        )
        await self._event_bus.publish_async(event)

        return task

    async def checkout_task(self, task_id: str, agent_id: str) -> bool:
        async with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return False
            if task.checkout_status != CheckoutStatus.AVAILABLE:
                return False

            task.checkout_status = CheckoutStatus.CHECKED_OUT
            task.checked_out_by = agent_id
            task.checked_out_at = time.time()
            task.status = TaskStatus.IN_PROGRESS
            task.assignee_id = agent_id
            task.updated_at = time.time()

        event = EnterpriseEvent(
            event_type=EnterpriseEventType.TASK_CHECKED_OUT,
            source=f"task_hierarchy:{task_id}",
            data={"task_id": task_id, "agent_id": agent_id},
        )
        await self._event_bus.publish_async(event)
        return True

    async def checkin_task(self, task_id: str, agent_id: str, status: TaskStatus = TaskStatus.DONE) -> bool:
        async with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return False
            if task.checked_out_by != agent_id:
                return False

            task.checkout_status = CheckoutStatus.AVAILABLE
            task.checked_out_by = None
            task.checked_out_at = None
            task.status = status
            task.updated_at = time.time()

        event = EnterpriseEvent(
            event_type=EnterpriseEventType.TASK_COMPLETED if status == TaskStatus.DONE else EnterpriseEventType.TASK_UPDATED,
            source=f"task_hierarchy:{task_id}",
            data={"task_id": task_id, "agent_id": agent_id, "status": status.value},
        )
        await self._event_bus.publish_async(event)
        return True

    async def force_release_checkout(self, task_id: str) -> bool:
        async with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return False
            task.checkout_status = CheckoutStatus.AVAILABLE
            task.checked_out_by = None
            task.checked_out_at = None
            task.updated_at = time.time()
        return True

    def add_comment(self, task_id: str, author_id: str, content: str, parent_comment_id: Optional[str] = None) -> Optional[TaskComment]:
        task = self._tasks.get(task_id)
        if not task:
            return None
        comment = TaskComment(
            comment_id=f"cmt_{int(time.time() * 1000)}_{len(task.comments)}",
            author_id=author_id,
            content=content,
            parent_comment_id=parent_comment_id,
        )
        task.comments.append(comment)
        task.updated_at = time.time()
        return comment

    def get_task(self, task_id: str) -> Optional[TaskNode]:
        return self._tasks.get(task_id)

    def get_children(self, task_id: str) -> List[TaskNode]:
        task = self._tasks.get(task_id)
        if not task:
            return []
        return [self._tasks[cid] for cid in task.children_ids if cid in self._tasks]

    def get_task_chain(self, task_id: str) -> List[TaskNode]:
        chain: List[TaskNode] = []
        current = self._tasks.get(task_id)
        while current:
            chain.append(current)
            if current.parent_id:
                current = self._tasks.get(current.parent_id)
            else:
                break
        return chain

    def get_tasks_by_billing_code(self, billing_code: str) -> List[TaskNode]:
        return [t for t in self._tasks.values() if t.billing_code == billing_code]

    def get_tasks_by_assignee(self, agent_id: str) -> List[TaskNode]:
        return [t for t in self._tasks.values() if t.assignee_id == agent_id]

    def get_initiatives(self) -> List[TaskNode]:
        return [t for t in self._tasks.values() if t.task_type == TaskType.INITIATIVE]

    def get_checked_out_tasks(self, agent_id: Optional[str] = None) -> List[TaskNode]:
        tasks = [t for t in self._tasks.values() if t.checkout_status == CheckoutStatus.CHECKED_OUT]
        if agent_id:
            tasks = [t for t in tasks if t.checked_out_by == agent_id]
        return tasks

    def get_stats(self) -> Dict[str, Any]:
        by_type: Dict[str, int] = {}
        by_status: Dict[str, int] = {}
        for t in self._tasks.values():
            by_type[t.task_type.value] = by_type.get(t.task_type.value, 0) + 1
            by_status[t.status.value] = by_status.get(t.status.value, 0) + 1
        return {
            "total_tasks": len(self._tasks),
            "by_type": by_type,
            "by_status": by_status,
            "checked_out": sum(1 for t in self._tasks.values() if t.checkout_status == CheckoutStatus.CHECKED_OUT),
        }
