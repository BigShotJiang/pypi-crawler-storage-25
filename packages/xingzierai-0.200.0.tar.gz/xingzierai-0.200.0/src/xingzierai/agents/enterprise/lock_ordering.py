# -*- coding: utf-8 -*-
"""Lock Ordering Specification - Prevent deadlocks by enforcing lock acquisition order.

Risk analysis from the integration plan identified 6 core risks:
1. TaskTracker._lock vs CronManager._lock deadlock
2. Budget callback re-trigger loops
3. Heartbeat timeout detection and recovery loops
4. SSE queue memory leaks in batch scheduling
5. CronManager heartbeat callback parallel execution races

This module defines a strict lock ordering hierarchy. All code must
acquire locks in the specified order (lowest level first) to prevent
circular wait conditions.

Lock hierarchy (acquire in this order):
Level 0: EnterpriseEventBus._lock (event delivery, no cross-dependencies)
Level 1: LifecycleStateMachine._lock (lifecycle transitions)
Level 2: HeartbeatRouter._lock (heartbeat routing)
Level 3: BudgetCoordinator._lock (budget checks)
Level 4: DedupGuard._lock (dedup checks)
Level 5: ConcurrencyLimiter._lock (concurrency control)
Level 6: TaskTracker._lock (task state management)
Level 7: CronManager._lock (cron scheduling)

NEVER acquire a lower-level lock while holding a higher-level lock.
"""
from __future__ import annotations

import asyncio
import logging
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class LockLevel:
    EVENT_BUS = 0
    LIFECYCLE = 1
    HEARTBEAT_ROUTER = 2
    BUDGET_COORDINATOR = 3
    DEDUP_GUARD = 4
    CONCURRENCY_LIMITER = 5
    TASK_TRACKER = 6
    CRON_MANAGER = 7


LEVEL_NAMES = {
    LockLevel.EVENT_BUS: "EventBus",
    LockLevel.LIFECYCLE: "Lifecycle",
    LockLevel.HEARTBEAT_ROUTER: "HeartbeatRouter",
    LockLevel.BUDGET_COORDINATOR: "BudgetCoordinator",
    LockLevel.DEDUP_GUARD: "DedupGuard",
    LockLevel.CONCURRENCY_LIMITER: "ConcurrencyLimiter",
    LockLevel.TASK_TRACKER: "TaskTracker",
    LockLevel.CRON_MANAGER: "CronManager",
}


@dataclass
class LockAcquisition:
    lock_name: str
    level: int
    holder: str
    thread_id: int
    acquired_at: float = field(default_factory=time.time)


class LockOrderValidator:
    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self._held_locks: Dict[int, List[LockAcquisition]] = {}
        self._violations: List[Dict] = []
        self._max_violations = 100

    def _get_thread_key(self) -> int:
        return threading.get_ident()

    def on_acquire(self, lock_name: str, level: int, holder: str = "") -> None:
        if not self.enabled:
            return

        thread_key = self._get_thread_key()
        acquisition = LockAcquisition(
            lock_name=lock_name,
            level=level,
            holder=holder,
            thread_id=thread_key,
        )

        held = self._held_locks.get(thread_key, [])
        for existing in held:
            if level <= existing.level:
                violation = {
                    "type": "lock_order_violation",
                    "thread": thread_key,
                    "existing_lock": existing.lock_name,
                    "existing_level": existing.level,
                    "new_lock": lock_name,
                    "new_level": level,
                    "holder": holder,
                    "timestamp": time.time(),
                }
                self._violations.append(violation)
                if len(self._violations) > self._max_violations:
                    self._violations = self._violations[-self._max_violations:]
                level_name = LEVEL_NAMES.get(level, f"Level{level}")
                existing_name = LEVEL_NAMES.get(existing.level, f"Level{existing.level}")
                logger.warning(
                    "Lock order violation: acquiring %s (%s, level=%d) while holding %s (level=%d) "
                    "[holder=%s, thread=%d]",
                    lock_name,
                    level_name,
                    level,
                    existing.lock_name,
                    existing.level,
                    holder,
                    thread_key,
                )

        held.append(acquisition)
        self._held_locks[thread_key] = held

    def on_release(self, lock_name: str) -> None:
        if not self.enabled:
            return

        thread_key = self._get_thread_key()
        held = self._held_locks.get(thread_key, [])
        self._held_locks[thread_key] = [
            a for a in held if a.lock_name != lock_name
        ]

    def get_held_locks(self, thread_id: Optional[int] = None) -> List[LockAcquisition]:
        key = thread_id or self._get_thread_key()
        return list(self._held_locks.get(key, []))

    def get_violations(self, limit: int = 20) -> List[Dict]:
        return self._violations[-limit:]

    def clear_violations(self) -> None:
        self._violations.clear()


_validator_instance: Optional[LockOrderValidator] = None


def get_lock_validator() -> LockOrderValidator:
    global _validator_instance
    if _validator_instance is None:
        _validator_instance = LockOrderValidator()
    return _validator_instance


class OrderedAsyncLock:
    def __init__(
        self,
        lock_name: str,
        level: int,
        holder: str = "",
        validator: Optional[LockOrderValidator] = None,
    ):
        self._lock = asyncio.Lock()
        self.lock_name = lock_name
        self.level = level
        self.holder = holder
        self._validator = validator

    async def acquire(self) -> None:
        validator = self._validator or get_lock_validator()
        validator.on_acquire(self.lock_name, self.level, self.holder)
        await self._lock.acquire()

    def release(self) -> None:
        validator = self._validator or get_lock_validator()
        validator.on_release(self.lock_name)
        self._lock.release()

    async def __aenter__(self) -> "OrderedAsyncLock":
        await self.acquire()
        return self

    async def __aexit__(self, *args) -> None:
        self.release()

    @property
    def locked(self) -> bool:
        return self._lock.locked
