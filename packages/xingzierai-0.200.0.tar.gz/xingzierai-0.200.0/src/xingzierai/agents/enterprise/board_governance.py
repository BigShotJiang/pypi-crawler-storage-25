# -*- coding: utf-8 -*-
"""Board Governance - Human oversight and approval system.

Paperclip-inspired governance model:
- Board (human) approval gates for critical decisions
- New Agent hiring approval
- CEO strategic decomposition approval
- Budget change approval
- Human always has full control power
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from .event_bus import EnterpriseEvent, EnterpriseEventBus, EnterpriseEventType, get_enterprise_bus
from .id_namespace import make_approval_id

logger = logging.getLogger(__name__)


class ApprovalType(str, Enum):
    AGENT_HIRE = "agent_hire"
    STRATEGIC_DECOMPOSITION = "strategic_decomposition"
    BUDGET_CHANGE = "budget_change"
    AGENT_TERMINATE = "agent_terminate"
    BUDGET_OVERRIDE = "budget_override"
    TASK_REASSIGN = "task_reassign"
    EVOLUTION_CRITICAL = "evolution_critical"


class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


@dataclass
class ApprovalRequest:
    request_id: str = ""
    approval_type: ApprovalType = ApprovalType.AGENT_HIRE
    title: str = ""
    description: str = ""
    requester_id: str = ""
    target_id: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    status: ApprovalStatus = ApprovalStatus.PENDING
    reviewer_id: str = ""
    review_comment: str = ""
    created_at: float = field(default_factory=time.time)
    reviewed_at: Optional[float] = None
    expires_at: Optional[float] = None
    priority: int = 0

    def __post_init__(self):
        if not self.request_id:
            self.request_id = make_approval_id(
                f"{self.approval_type.value}_{int(self.created_at)}"
            )
        if not self.expires_at:
            self.expires_at = self.created_at + 86400

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "approval_type": self.approval_type.value,
            "title": self.title,
            "description": self.description,
            "requester_id": self.requester_id,
            "target_id": self.target_id,
            "status": self.status.value,
            "reviewer_id": self.reviewer_id,
            "review_comment": self.review_comment,
            "created_at": self.created_at,
            "reviewed_at": self.reviewed_at,
            "priority": self.priority,
        }


ApprovalCallback = Callable[[ApprovalRequest], Any]


class ApprovalQueue:
    def __init__(self, event_bus: Optional[EnterpriseEventBus] = None):
        self._event_bus = event_bus or get_enterprise_bus()
        self._queue: Dict[str, ApprovalRequest] = {}
        self._history: List[ApprovalRequest] = []
        self._callbacks: Dict[ApprovalType, List[ApprovalCallback]] = {}
        self._auto_approve_types: set = set()
        self._lock = asyncio.Lock()
        self._max_history = 500

    def set_auto_approve(self, approval_type: ApprovalType, auto: bool = True) -> None:
        if auto:
            self._auto_approve_types.add(approval_type)
        else:
            self._auto_approve_types.discard(approval_type)

    async def submit(
        self,
        approval_type: ApprovalType,
        title: str,
        description: str = "",
        requester_id: str = "",
        target_id: str = "",
        data: Optional[Dict[str, Any]] = None,
        priority: int = 0,
    ) -> ApprovalRequest:
        request = ApprovalRequest(
            approval_type=approval_type,
            title=title,
            description=description,
            requester_id=requester_id,
            target_id=target_id,
            data=data or {},
            priority=priority,
        )

        if approval_type in self._auto_approve_types:
            request.status = ApprovalStatus.APPROVED
            request.reviewer_id = "auto_approve"
            request.reviewed_at = time.time()
            self._history.append(request)
            await self._notify(request)
            return request

        async with self._lock:
            self._queue[request.request_id] = request

        event = EnterpriseEvent(
            event_type=EnterpriseEventType.APPROVAL_REQUESTED,
            source=f"approval_queue:{request.request_id}",
            data={
                "request_id": request.request_id,
                "approval_type": approval_type.value,
                "title": title,
                "requester_id": requester_id,
                "target_id": target_id,
            },
        )
        await self._event_bus.publish_async(event)

        return request

    async def approve(
        self,
        request_id: str,
        reviewer_id: str = "board",
        comment: str = "",
    ) -> Optional[ApprovalRequest]:
        async with self._lock:
            request = self._queue.pop(request_id, None)
            if not request:
                return None

            request.status = ApprovalStatus.APPROVED
            request.reviewer_id = reviewer_id
            request.review_comment = comment
            request.reviewed_at = time.time()

            self._history.append(request)
            if len(self._history) > self._max_history:
                self._history = self._history[-self._max_history:]

        event = EnterpriseEvent(
            event_type=EnterpriseEventType.APPROVAL_GRANTED,
            source=f"approval_queue:{request_id}",
            data={
                "request_id": request_id,
                "approval_type": request.approval_type.value,
                "reviewer_id": reviewer_id,
            },
        )
        await self._event_bus.publish_async(event)
        await self._notify(request)

        return request

    async def reject(
        self,
        request_id: str,
        reviewer_id: str = "board",
        comment: str = "",
    ) -> Optional[ApprovalRequest]:
        async with self._lock:
            request = self._queue.pop(request_id, None)
            if not request:
                return None

            request.status = ApprovalStatus.REJECTED
            request.reviewer_id = reviewer_id
            request.review_comment = comment
            request.reviewed_at = time.time()

            self._history.append(request)

        event = EnterpriseEvent(
            event_type=EnterpriseEventType.APPROVAL_REJECTED,
            source=f"approval_queue:{request_id}",
            data={
                "request_id": request_id,
                "approval_type": request.approval_type.value,
                "reviewer_id": reviewer_id,
                "comment": comment,
            },
        )
        await self._event_bus.publish_async(event)
        await self._notify(request)

        return request

    def register_callback(self, approval_type: ApprovalType, callback: ApprovalCallback) -> None:
        if approval_type not in self._callbacks:
            self._callbacks[approval_type] = []
        self._callbacks[approval_type].append(callback)

    async def _notify(self, request: ApprovalRequest) -> None:
        callbacks = self._callbacks.get(request.approval_type, [])
        for cb in callbacks:
            try:
                result = cb(request)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.error("Approval callback error: %s", e)

    def get_pending(self, approval_type: Optional[ApprovalType] = None) -> List[ApprovalRequest]:
        requests = [r for r in self._queue.values() if r.status == ApprovalStatus.PENDING]
        if approval_type:
            requests = [r for r in requests if r.approval_type == approval_type]
        return sorted(requests, key=lambda r: (-r.priority, r.created_at))

    def get_request(self, request_id: str) -> Optional[ApprovalRequest]:
        return self._queue.get(request_id) or next(
            (r for r in self._history if r.request_id == request_id), None
        )

    def get_history(
        self,
        approval_type: Optional[ApprovalType] = None,
        status: Optional[ApprovalStatus] = None,
        limit: int = 50,
    ) -> List[ApprovalRequest]:
        requests = self._history
        if approval_type:
            requests = [r for r in requests if r.approval_type == approval_type]
        if status:
            requests = [r for r in requests if r.status == status]
        return requests[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        by_type: Dict[str, int] = {}
        by_status: Dict[str, int] = {}
        for r in self._history:
            by_type[r.approval_type.value] = by_type.get(r.approval_type.value, 0) + 1
            by_status[r.status.value] = by_status.get(r.status.value, 0) + 1
        return {
            "pending_count": len(self._queue),
            "history_count": len(self._history),
            "by_type": by_type,
            "by_status": by_status,
            "auto_approve_types": [t.value for t in self._auto_approve_types],
        }


class BoardGovernance:
    def __init__(
        self,
        company_id: str = "",
        approval_queue: Optional[ApprovalQueue] = None,
        event_bus: Optional[EnterpriseEventBus] = None,
    ):
        self.company_id = company_id
        self._approval_queue = approval_queue or ApprovalQueue(event_bus)
        self._event_bus = event_bus or get_enterprise_bus()
        self._board_members: List[str] = []
        self._human_control_powers = {
            "set_modify_budget": True,
            "pause_resume_agent": True,
            "pause_resume_task": True,
            "full_project_access": True,
            "override_agent_decision": True,
            "modify_any_budget": True,
            "manual_terminate_agent": True,
        }

    @property
    def approval_queue(self) -> ApprovalQueue:
        return self._approval_queue

    def add_board_member(self, member_id: str) -> None:
        if member_id not in self._board_members:
            self._board_members.append(member_id)

    def remove_board_member(self, member_id: str) -> None:
        self._board_members = [m for m in self._board_members if m != member_id]

    async def request_agent_hire(
        self,
        agent_name: str,
        role: str,
        requester_id: str = "",
        justification: str = "",
    ) -> ApprovalRequest:
        return await self._approval_queue.submit(
            approval_type=ApprovalType.AGENT_HIRE,
            title=f"Hire Agent: {agent_name} ({role})",
            description=justification,
            requester_id=requester_id,
            target_id=agent_name,
            data={"agent_name": agent_name, "role": role},
        )

    async def request_strategic_decomposition(
        self,
        initiative_title: str,
        requester_id: str = "",
        description: str = "",
    ) -> ApprovalRequest:
        return await self._approval_queue.submit(
            approval_type=ApprovalType.STRATEGIC_DECOMPOSITION,
            title=f"Strategic Decomposition: {initiative_title}",
            description=description,
            requester_id=requester_id,
            data={"initiative_title": initiative_title},
            priority=10,
        )

    async def request_budget_change(
        self,
        agent_id: str,
        current_budget: int,
        proposed_budget: int,
        requester_id: str = "",
        reason: str = "",
    ) -> ApprovalRequest:
        return await self._approval_queue.submit(
            approval_type=ApprovalType.BUDGET_CHANGE,
            title=f"Budget Change: {agent_id} ({current_budget} -> {proposed_budget} cents)",
            description=reason,
            requester_id=requester_id,
            target_id=agent_id,
            data={
                "agent_id": agent_id,
                "current_budget_cents": current_budget,
                "proposed_budget_cents": proposed_budget,
            },
        )

    def get_powers(self) -> Dict[str, bool]:
        return dict(self._human_control_powers)

    def get_stats(self) -> Dict[str, Any]:
        return {
            "company_id": self.company_id,
            "board_members": len(self._board_members),
            "human_powers": self.get_powers(),
            "approval_queue": self._approval_queue.get_stats(),
        }
