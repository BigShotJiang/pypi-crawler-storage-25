# -*- coding: utf-8 -*-
"""Budget Coordinator - Coordinate between token budget and financial budget.

XINGZIER AI has two budget dimensions:
1. TokenBudget (agent_loop/token_budget.py) - Technical safety, per-session
2. ContextWindowBudgetPlanner (agents/context_manager/budget.py) - Context allocation

Paperclip adds:
3. Monthly financial budget (cents) - Business level, per-agent/company
4. Three-level control: Visibility → Soft Alert → Hard Ceiling (auto-pause)

The coordinator ensures TokenBudget takes priority over financial budget
(safety first), while financial budget provides business-level guardrails.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from .event_bus import EnterpriseEvent, EnterpriseEventBus, EnterpriseEventType, get_enterprise_bus
from .lifecycle import LifecycleManager, get_lifecycle_manager

logger = logging.getLogger(__name__)


class BudgetDimension(str, Enum):
    TOKEN = "token"
    CONTEXT = "context"
    FINANCIAL = "financial"


class BudgetControlLevel(str, Enum):
    VISIBILITY = "visibility"
    SOFT_ALERT = "soft_alert"
    HARD_CEILING = "hard_ceiling"


class FinancialBudgetLevel(str, Enum):
    NORMAL = "normal"
    CAUTION = "caution"
    WARNING = "warning"
    CRITICAL = "critical"
    EXCEEDED = "exceeded"


@dataclass
class FinancialBudgetPolicy:
    monthly_budget_cents: int = 0
    caution_threshold: float = 0.50
    warning_threshold: float = 0.70
    critical_threshold: float = 0.85
    hard_ceiling_threshold: float = 0.95
    timezone: str = "UTC"
    auto_pause_on_exceed: bool = True


@dataclass
class FinancialBudgetSnapshot:
    agent_id: str
    monthly_budget_cents: int = 0
    spent_cents: int = 0
    usage_ratio: float = 0.0
    level: FinancialBudgetLevel = FinancialBudgetLevel.NORMAL
    control_level: BudgetControlLevel = BudgetControlLevel.VISIBILITY
    period_start: Optional[float] = None
    period_end: Optional[float] = None
    timestamp: float = field(default_factory=time.time)


@dataclass
class BudgetCoordinationConfig:
    enabled: bool = False
    token_budget_priority: bool = True
    financial_budget_enabled: bool = False
    monitoring_interval_seconds: float = 0.5
    auto_pause_on_financial_exceed: bool = True


BudgetCallback = Callable[[BudgetDimension, str, Any], None]


class BudgetCoordinator:
    def __init__(
        self,
        config: Optional[BudgetCoordinationConfig] = None,
        event_bus: Optional[EnterpriseEventBus] = None,
        lifecycle_manager: Optional[LifecycleManager] = None,
    ):
        self.config = config or BudgetCoordinationConfig()
        self._event_bus = event_bus or get_enterprise_bus()
        self._lifecycle = lifecycle_manager or get_lifecycle_manager()
        self._financial_policies: Dict[str, FinancialBudgetPolicy] = {}
        self._financial_spent: Dict[str, int] = {}
        self._period_start: Dict[str, float] = {}
        self._callbacks: List[BudgetCallback] = []
        self._lock = asyncio.Lock()
        self._monitoring_tasks: Dict[str, asyncio.Task] = {}
        self._token_budget_refs: Dict[str, Any] = {}

    def set_financial_policy(self, agent_id: str, policy: FinancialBudgetPolicy) -> None:
        self._financial_policies[agent_id] = policy
        self._reset_period(agent_id)

    def register_token_budget(self, agent_id: str, token_budget: Any) -> None:
        self._token_budget_refs[agent_id] = token_budget

    def register_callback(self, callback: BudgetCallback) -> None:
        self._callbacks.append(callback)

    def _reset_period(self, agent_id: str) -> None:
        import calendar
        from datetime import datetime
        from zoneinfo import ZoneInfo

        policy = self._financial_policies.get(agent_id)
        tz_name = policy.timezone if policy else "UTC"
        try:
            tz = ZoneInfo(tz_name)
        except Exception:
            tz = ZoneInfo("UTC")

        now = datetime.now(tz)
        year, month = now.year, now.month
        _, days_in_month = calendar.monthrange(year, month)
        start = datetime(year, month, 1, tzinfo=tz)
        end = datetime(year, month, days_in_month, 23, 59, 59, tzinfo=tz)

        self._period_start[agent_id] = start.timestamp()
        self._financial_spent[agent_id] = 0

    def record_cost(
        self,
        agent_id: str,
        cost_cents: int,
        provider: str = "",
        model: str = "",
        tokens: int = 0,
        task_id: str = "",
    ) -> FinancialBudgetSnapshot:
        self._financial_spent[agent_id] = self._financial_spent.get(agent_id, 0) + cost_cents
        snapshot = self.check_financial_budget(agent_id)

        if self._event_bus:
            event = EnterpriseEvent(
                event_type=EnterpriseEventType.COST_RECORDED,
                source=f"budget_coordinator:{agent_id}",
                data={
                    "agent_id": agent_id,
                    "cost_cents": cost_cents,
                    "provider": provider,
                    "model": model,
                    "tokens": tokens,
                    "task_id": task_id,
                    "total_spent": self._financial_spent.get(agent_id, 0),
                    "level": snapshot.level.value,
                },
            )
            self._event_bus.publish(event)

        return snapshot

    def check_financial_budget(self, agent_id: str) -> FinancialBudgetSnapshot:
        policy = self._financial_policies.get(agent_id)
        if not policy or policy.monthly_budget_cents <= 0:
            return FinancialBudgetSnapshot(agent_id=agent_id)

        spent = self._financial_spent.get(agent_id, 0)
        budget = policy.monthly_budget_cents
        ratio = spent / budget if budget > 0 else 0

        level = FinancialBudgetLevel.NORMAL
        control = BudgetControlLevel.VISIBILITY

        if ratio >= policy.hard_ceiling_threshold:
            level = FinancialBudgetLevel.EXCEEDED
            control = BudgetControlLevel.HARD_CEILING
        elif ratio >= policy.critical_threshold:
            level = FinancialBudgetLevel.CRITICAL
            control = BudgetControlLevel.HARD_CEILING
        elif ratio >= policy.warning_threshold:
            level = FinancialBudgetLevel.WARNING
            control = BudgetControlLevel.SOFT_ALERT
        elif ratio >= policy.caution_threshold:
            level = FinancialBudgetLevel.CAUTION
            control = BudgetControlLevel.VISIBILITY

        return FinancialBudgetSnapshot(
            agent_id=agent_id,
            monthly_budget_cents=budget,
            spent_cents=spent,
            usage_ratio=ratio,
            level=level,
            control_level=control,
            period_start=self._period_start.get(agent_id),
            timestamp=time.time(),
        )

    async def check_all_budgets(self, agent_id: str) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "agent_id": agent_id,
            "token_budget": None,
            "financial_budget": None,
            "should_pause": False,
            "should_stop": False,
            "reasons": [],
        }

        token_budget = self._token_budget_refs.get(agent_id)
        if token_budget:
            try:
                snapshot = token_budget.check()
                result["token_budget"] = snapshot.to_dict() if hasattr(snapshot, "to_dict") else str(snapshot)
                if hasattr(token_budget, "should_stop") and token_budget.should_stop():
                    result["should_stop"] = True
                    result["reasons"].append("token_budget_exceeded")
            except Exception as e:
                logger.warning("Token budget check error for %s: %s", agent_id, e)

        if self.config.financial_budget_enabled:
            fin_snapshot = self.check_financial_budget(agent_id)
            result["financial_budget"] = {
                "spent_cents": fin_snapshot.spent_cents,
                "budget_cents": fin_snapshot.monthly_budget_cents,
                "usage_ratio": fin_snapshot.usage_ratio,
                "level": fin_snapshot.level.value,
                "control_level": fin_snapshot.control_level.value,
            }

            if fin_snapshot.level == FinancialBudgetLevel.EXCEEDED:
                if self.config.auto_pause_on_financial_exceed:
                    result["should_pause"] = True
                    result["reasons"].append("financial_budget_exceeded")
                if self._event_bus:
                    event = EnterpriseEvent(
                        event_type=EnterpriseEventType.BUDGET_EXCEEDED,
                        source=f"budget_coordinator:{agent_id}",
                        data={
                            "agent_id": agent_id,
                            "dimension": "financial",
                            "level": fin_snapshot.level.value,
                            "spent_cents": fin_snapshot.spent_cents,
                            "budget_cents": fin_snapshot.monthly_budget_cents,
                        },
                    )
                    await self._event_bus.publish_async(event)
            elif fin_snapshot.level in (FinancialBudgetLevel.WARNING, FinancialBudgetLevel.CRITICAL):
                if self._event_bus:
                    event = EnterpriseEvent(
                        event_type=EnterpriseEventType.BUDGET_THRESHOLD,
                        source=f"budget_coordinator:{agent_id}",
                        data={
                            "agent_id": agent_id,
                            "dimension": "financial",
                            "level": fin_snapshot.level.value,
                            "usage_ratio": fin_snapshot.usage_ratio,
                        },
                    )
                    await self._event_bus.publish_async(event)

        if self.config.token_budget_priority and result["should_stop"]:
            result["should_pause"] = False

        return result

    async def start_monitoring(self, agent_id: str) -> None:
        if not self.config.enabled:
            return
        if agent_id in self._monitoring_tasks:
            return

        async def _monitor():
            while True:
                try:
                    await asyncio.sleep(self.config.monitoring_interval_seconds)
                    check = await self.check_all_budgets(agent_id)
                    if check["should_pause"]:
                        lifecycle = self._lifecycle.get(agent_id)
                        if lifecycle:
                            await lifecycle.pause(reason="budget_exceeded", actor="budget_coordinator")
                            logger.warning("Agent %s paused due to budget: %s", agent_id, check["reasons"])
                    if check["should_stop"]:
                        lifecycle = self._lifecycle.get(agent_id)
                        if lifecycle:
                            await lifecycle.terminate(reason="budget_exceeded_hard", actor="budget_coordinator")
                            logger.warning("Agent %s terminated due to budget: %s", agent_id, check["reasons"])
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error("Budget monitoring error for %s: %s", agent_id, e)

        self._monitoring_tasks[agent_id] = asyncio.create_task(_monitor())

    async def stop_monitoring(self, agent_id: str) -> None:
        task = self._monitoring_tasks.pop(agent_id, None)
        if task:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    async def stop_all_monitoring(self) -> None:
        for agent_id in list(self._monitoring_tasks.keys()):
            await self.stop_monitoring(agent_id)

    def get_stats(self) -> Dict[str, Any]:
        return {
            "enabled": self.config.enabled,
            "financial_budget_enabled": self.config.financial_budget_enabled,
            "agents_with_financial_policy": len(self._financial_policies),
            "agents_with_token_budget": len(self._token_budget_refs),
            "active_monitoring": len(self._monitoring_tasks),
            "financial_snapshots": {
                aid: {
                    "spent": self._financial_spent.get(aid, 0),
                    "budget": policy.monthly_budget_cents,
                }
                for aid, policy in self._financial_policies.items()
            },
        }


_coordinator_instance: Optional[BudgetCoordinator] = None


def get_budget_coordinator() -> BudgetCoordinator:
    global _coordinator_instance
    if _coordinator_instance is None:
        _coordinator_instance = BudgetCoordinator()
    return _coordinator_instance


def reset_budget_coordinator() -> None:
    global _coordinator_instance
    _coordinator_instance = None
