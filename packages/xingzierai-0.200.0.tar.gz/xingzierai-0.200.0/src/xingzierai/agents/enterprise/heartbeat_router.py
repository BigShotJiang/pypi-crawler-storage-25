# -*- coding: utf-8 -*-
"""Heartbeat Router - Unified heartbeat routing across all heartbeat layers.

Merges XINGZIER AI's existing 4-layer heartbeat system:
- L1: SSE connection layer (15s interval)
- L2: CronManager (APScheduler)
- L3: Frontend monitoring (HeartbeatMonitor)
- L4: Container heartbeat (HeartbeatMixin, Redis distributed lock)

With Paperclip's heartbeat system:
- Scheduled wake-up → check work → execute
- Thin Ping vs Fat Payload context passing
- Graceful pause → grace period → forced termination

The router adds a `source` field to distinguish heartbeat origins and
prevents L2 and Paperclip heartbeats from competing for the same agent.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Union

from .event_bus import EnterpriseEvent, EnterpriseEventBus, EnterpriseEventType, get_enterprise_bus
from .lifecycle import AgentLifecycleState, LifecycleManager, get_lifecycle_manager

logger = logging.getLogger(__name__)


class HeartbeatSource(str, Enum):
    SSE_KEEPALIVE = "sse_keepalive"
    CRON_MANAGER = "cron_manager"
    FRONTEND_MONITOR = "frontend_monitor"
    CONTAINER = "container"
    ENTERPRISE_SCHEDULER = "enterprise_scheduler"
    MANUAL = "manual"


class HeartbeatPayload(str, Enum):
    THIN = "thin"
    FAT = "fat"


@dataclass
class HeartbeatRequest:
    agent_id: str
    source: HeartbeatSource
    payload_type: HeartbeatPayload = HeartbeatPayload.THIN
    context: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    request_id: str = ""
    priority: int = 0

    def __post_init__(self):
        if not self.request_id:
            self.request_id = f"hb_{self.agent_id}_{int(self.timestamp * 1000)}"


@dataclass
class HeartbeatResponse:
    request_id: str
    agent_id: str
    accepted: bool = True
    reason: str = ""
    result: Optional[str] = None
    timestamp: float = field(default_factory=time.time)


@dataclass
class HeartbeatRouteConfig:
    enabled: bool = False
    cooldown_seconds: float = 30.0
    max_concurrent_per_agent: int = 1
    enterprise_scheduler_priority: int = 10
    cron_manager_priority: int = 5
    dedup_window_seconds: float = 10.0
    block_cron_when_enterprise_active: bool = True


HeartbeatHandler = Callable[[HeartbeatRequest], Any]


class HeartbeatRouter:
    def __init__(
        self,
        config: Optional[HeartbeatRouteConfig] = None,
        event_bus: Optional[EnterpriseEventBus] = None,
        lifecycle_manager: Optional[LifecycleManager] = None,
    ):
        self.config = config or HeartbeatRouteConfig()
        self._event_bus = event_bus or get_enterprise_bus()
        self._lifecycle = lifecycle_manager or get_lifecycle_manager()
        self._handlers: Dict[HeartbeatSource, HeartbeatHandler] = {}
        self._active_heartbeats: Dict[str, HeartbeatRequest] = {}
        self._last_heartbeat: Dict[str, float] = {}
        self._lock = asyncio.Lock()
        self._stats = {
            "total_requests": 0,
            "accepted": 0,
            "rejected_cooldown": 0,
            "rejected_concurrent": 0,
            "rejected_lifecycle": 0,
            "blocked_cron": 0,
        }

    def register_handler(self, source: HeartbeatSource, handler: HeartbeatHandler) -> None:
        self._handlers[source] = handler

    async def route(self, request: HeartbeatRequest) -> HeartbeatResponse:
        if not self.config.enabled:
            return await self._passthrough(request)

        async with self._lock:
            self._stats["total_requests"] += 1

            lifecycle = self._lifecycle.get(request.agent_id)
            if lifecycle:
                state = lifecycle.state
                if state in (AgentLifecycleState.PAUSED, AgentLifecycleState.STOPPING, AgentLifecycleState.TERMINATED):
                    self._stats["rejected_lifecycle"] += 1
                    return HeartbeatResponse(
                        request_id=request.request_id,
                        agent_id=request.agent_id,
                        accepted=False,
                        reason=f"Agent in {state.value} state",
                    )

            last_time = self._last_heartbeat.get(request.agent_id, 0)
            if time.time() - last_time < self.config.dedup_window_seconds:
                existing = self._active_heartbeats.get(request.agent_id)
                if existing and existing.source != request.source:
                    if (request.source == HeartbeatSource.CRON_MANAGER
                            and existing.source == HeartbeatSource.ENTERPRISE_SCHEDULER
                            and self.config.block_cron_when_enterprise_active):
                        self._stats["blocked_cron"] += 1
                        return HeartbeatResponse(
                            request_id=request.request_id,
                            agent_id=request.agent_id,
                            accepted=False,
                            reason="Enterprise scheduler heartbeat active, cron blocked",
                        )

            active = self._active_heartbeats.get(request.agent_id)
            if active:
                self._stats["rejected_concurrent"] += 1
                return HeartbeatResponse(
                    request_id=request.request_id,
                    agent_id=request.agent_id,
                    accepted=False,
                    reason=f"Concurrent heartbeat from {active.source.value}",
                )

            self._active_heartbeats[request.agent_id] = request
            self._last_heartbeat[request.agent_id] = time.time()

        try:
            handler = self._handlers.get(request.source)
            if handler:
                result = handler(request)
                if asyncio.iscoroutine(result):
                    result = await result
                response = HeartbeatResponse(
                    request_id=request.request_id,
                    agent_id=request.agent_id,
                    accepted=True,
                    result=str(result) if result else None,
                )
            else:
                response = HeartbeatResponse(
                    request_id=request.request_id,
                    agent_id=request.agent_id,
                    accepted=True,
                    reason="No handler registered, passthrough",
                )

            self._stats["accepted"] += 1

            if self._event_bus:
                event = EnterpriseEvent(
                    event_type=EnterpriseEventType.HEARTBEAT_TRIGGERED,
                    source=f"heartbeat_router:{request.agent_id}",
                    data={
                        "agent_id": request.agent_id,
                        "source": request.source.value,
                        "payload_type": request.payload_type.value,
                        "request_id": request.request_id,
                    },
                )
                await self._event_bus.publish_async(event)

            return response

        except Exception as e:
            logger.error("Heartbeat handler error for agent %s: %s", request.agent_id, e)
            return HeartbeatResponse(
                request_id=request.request_id,
                agent_id=request.agent_id,
                accepted=False,
                reason=f"Handler error: {e}",
            )
        finally:
            async with self._lock:
                self._active_heartbeats.pop(request.agent_id, None)

    async def _passthrough(self, request: HeartbeatRequest) -> HeartbeatResponse:
        handler = self._handlers.get(request.source)
        if handler:
            result = handler(request)
            if asyncio.iscoroutine(result):
                result = await result
            return HeartbeatResponse(
                request_id=request.request_id,
                agent_id=request.agent_id,
                accepted=True,
                result=str(result) if result else None,
            )
        return HeartbeatResponse(
            request_id=request.request_id,
            agent_id=request.agent_id,
            accepted=True,
            reason="Router disabled, no handler",
        )

    async def notify_completion(
        self,
        agent_id: str,
        source: HeartbeatSource,
        success: bool,
        error: Optional[str] = None,
    ) -> None:
        if self._event_bus:
            event_type = (
                EnterpriseEventType.HEARTBEAT_COMPLETED
                if success
                else EnterpriseEventType.HEARTBEAT_TIMEOUT
            )
            event = EnterpriseEvent(
                event_type=event_type,
                source=f"heartbeat_router:{agent_id}",
                data={
                    "agent_id": agent_id,
                    "source": source.value,
                    "success": success,
                    "error": error,
                },
            )
            await self._event_bus.publish_async(event)

    def get_stats(self) -> Dict[str, Any]:
        return {
            **self._stats,
            "active_heartbeats": {
                aid: {"source": req.source.value, "timestamp": req.timestamp}
                for aid, req in self._active_heartbeats.items()
            },
            "enabled": self.config.enabled,
        }

    def get_active_agents(self) -> List[str]:
        return list(self._active_heartbeats.keys())


_router_instance: Optional[HeartbeatRouter] = None


def get_heartbeat_router() -> HeartbeatRouter:
    global _router_instance
    if _router_instance is None:
        _router_instance = HeartbeatRouter()
    return _router_instance


def reset_heartbeat_router() -> None:
    global _router_instance
    _router_instance = None
