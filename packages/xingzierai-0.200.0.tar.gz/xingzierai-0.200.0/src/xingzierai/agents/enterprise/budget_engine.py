# -*- coding: utf-8 -*-
"""Budget Engine - Multi-level budget control with cost tracking.

Paperclip-inspired budget engine with:
- Multi-level budget delegation: Board -> CEO -> Manager -> Agent
- Monthly UTC calendar window
- Three-level control: Visibility -> Soft Alert -> Hard Ceiling
- Token/USD dual-metric cost tracking
- Billing codes for cross-team cost attribution
"""
from __future__ import annotations

import calendar
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
from zoneinfo import ZoneInfo

from .budget_coordinator import (
    BudgetCoordinator,
    BudgetCoordinationConfig,
    FinancialBudgetLevel,
    FinancialBudgetPolicy,
    FinancialBudgetSnapshot,
    get_budget_coordinator,
)
from .event_bus import EnterpriseEventBus, EnterpriseEventType, get_enterprise_bus
from .id_namespace import make_budget_id, make_cost_event_id

logger = logging.getLogger(__name__)


@dataclass
class BillingCode:
    code: str
    name: str
    description: str = ""
    cost_center: str = ""
    team_id: str = ""
    parent_code: str = ""
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "code": self.code,
            "name": self.name,
            "description": self.description,
            "cost_center": self.cost_center,
            "team_id": self.team_id,
            "parent_code": self.parent_code,
        }


@dataclass
class CostRecord:
    record_id: str = ""
    agent_id: str = ""
    task_id: str = ""
    billing_code: str = ""
    provider: str = ""
    model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_cents: int = 0
    recorded_at: float = field(default_factory=time.time)
    attributed_to: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.record_id:
            self.record_id = make_cost_event_id(self.agent_id)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "record_id": self.record_id,
            "agent_id": self.agent_id,
            "task_id": self.task_id,
            "billing_code": self.billing_code,
            "provider": self.provider,
            "model": self.model,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "cost_cents": self.cost_cents,
            "attributed_to": self.attributed_to,
        }


@dataclass
class BudgetDelegation:
    delegator_id: str
    delegate_id: str
    budget_cents: int
    period_start: float
    period_end: float
    spent_cents: int = 0
    level: FinancialBudgetLevel = FinancialBudgetLevel.NORMAL
    created_at: float = field(default_factory=time.time)


class BudgetEngine:
    def __init__(
        self,
        coordinator: Optional[BudgetCoordinator] = None,
        event_bus: Optional[EnterpriseEventBus] = None,
    ):
        self._coordinator = coordinator or get_budget_coordinator()
        self._event_bus = event_bus or get_enterprise_bus()
        self._billing_codes: Dict[str, BillingCode] = {}
        self._cost_records: List[CostRecord] = []
        self._delegations: Dict[str, BudgetDelegation] = {}
        self._max_records = 10000

    def register_billing_code(self, code: str, name: str, **kwargs: Any) -> BillingCode:
        bc = BillingCode(code=code, name=name, **kwargs)
        self._billing_codes[code] = bc
        return bc

    def get_billing_code(self, code: str) -> Optional[BillingCode]:
        return self._billing_codes.get(code)

    def list_billing_codes(self) -> List[BillingCode]:
        return list(self._billing_codes.values())

    def set_agent_budget(
        self,
        agent_id: str,
        monthly_budget_cents: int,
        timezone: str = "UTC",
        caution: float = 0.50,
        warning: float = 0.70,
        critical: float = 0.85,
        hard_ceiling: float = 0.95,
        auto_pause: bool = True,
    ) -> FinancialBudgetPolicy:
        policy = FinancialBudgetPolicy(
            monthly_budget_cents=monthly_budget_cents,
            timezone=timezone,
            caution_threshold=caution,
            warning_threshold=warning,
            critical_threshold=critical,
            hard_ceiling_threshold=hard_ceiling,
            auto_pause_on_exceed=auto_pause,
        )
        self._coordinator.set_financial_policy(agent_id, policy)
        return policy

    def delegate_budget(
        self,
        delegator_id: str,
        delegate_id: str,
        budget_cents: int,
        timezone: str = "UTC",
    ) -> BudgetDelegation:
        now = datetime.now(ZoneInfo(timezone))
        _, days_in_month = calendar.monthrange(now.year, now.month)
        period_start = datetime(now.year, now.month, 1, tzinfo=ZoneInfo(timezone)).timestamp()
        period_end = datetime(now.year, now.month, days_in_month, 23, 59, 59, tzinfo=ZoneInfo(timezone)).timestamp()

        delegation = BudgetDelegation(
            delegator_id=delegator_id,
            delegate_id=delegate_id,
            budget_cents=budget_cents,
            period_start=period_start,
            period_end=period_end,
        )

        key = f"{delegator_id}->{delegate_id}"
        self._delegations[key] = delegation

        self.set_agent_budget(
            agent_id=delegate_id,
            monthly_budget_cents=budget_cents,
            timezone=timezone,
        )

        return delegation

    def record_cost(
        self,
        agent_id: str,
        cost_cents: int,
        task_id: str = "",
        billing_code: str = "",
        provider: str = "",
        model: str = "",
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        attributed_to: str = "",
    ) -> CostRecord:
        record = CostRecord(
            agent_id=agent_id,
            task_id=task_id,
            billing_code=billing_code,
            provider=provider,
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            cost_cents=cost_cents,
            attributed_to=attributed_to or agent_id,
        )

        self._cost_records.append(record)
        if len(self._cost_records) > self._max_records:
            self._cost_records = self._cost_records[-self._max_records:]

        self._coordinator.record_cost(
            agent_id=agent_id,
            cost_cents=cost_cents,
            provider=provider,
            model=model,
            tokens=prompt_tokens + completion_tokens,
            task_id=task_id,
        )

        return record

    def get_agent_budget(self, agent_id: str) -> FinancialBudgetSnapshot:
        return self._coordinator.check_financial_budget(agent_id)

    def get_cost_by_agent(self, agent_id: str, start_time: Optional[float] = None, end_time: Optional[float] = None) -> Dict[str, Any]:
        records = [r for r in self._cost_records if r.agent_id == agent_id]
        if start_time:
            records = [r for r in records if r.recorded_at >= start_time]
        if end_time:
            records = [r for r in records if r.recorded_at <= end_time]

        total_cents = sum(r.cost_cents for r in records)
        total_tokens = sum(r.prompt_tokens + r.completion_tokens for r in records)
        by_model: Dict[str, int] = {}
        for r in records:
            key = f"{r.provider}/{r.model}"
            by_model[key] = by_model.get(key, 0) + r.cost_cents

        return {
            "agent_id": agent_id,
            "record_count": len(records),
            "total_cost_cents": total_cents,
            "total_tokens": total_tokens,
            "by_model": by_model,
        }

    def get_cost_by_billing_code(self, billing_code: str) -> Dict[str, Any]:
        records = [r for r in self._cost_records if r.billing_code == billing_code]
        total_cents = sum(r.cost_cents for r in records)
        by_agent: Dict[str, int] = {}
        for r in records:
            by_agent[r.agent_id] = by_agent.get(r.agent_id, 0) + r.cost_cents

        return {
            "billing_code": billing_code,
            "record_count": len(records),
            "total_cost_cents": total_cents,
            "by_agent": by_agent,
        }

    def get_delegations(self, delegator_id: Optional[str] = None) -> List[BudgetDelegation]:
        if delegator_id:
            return [d for d in self._delegations.values() if d.delegator_id == delegator_id]
        return list(self._delegations.values())

    def get_stats(self) -> Dict[str, Any]:
        return {
            "billing_codes": len(self._billing_codes),
            "cost_records": len(self._cost_records),
            "delegations": len(self._delegations),
            "total_cost_cents": sum(r.cost_cents for r in self._cost_records),
            "total_tokens": sum(r.prompt_tokens + r.completion_tokens for r in self._cost_records),
        }
