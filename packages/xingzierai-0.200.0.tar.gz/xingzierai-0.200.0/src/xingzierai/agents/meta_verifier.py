# -*- coding: utf-8 -*-
"""Meta-Verifier - Verification of verification rules.

Inspired by Godel's Incompleteness Theorem:
- Any formal system has truths it cannot prove about itself
- The verification system itself must be verified
- Meta-verification provides the "meta-level" that Godel requires

This module verifies that NeuroSymbolicVerifier's checks are:
1. Correct (true positive/negative rates on known inputs)
2. Consistent (no contradictions between checks)
3. Complete (coverage of known bug patterns)
4. Sound (no false positives that block valid outputs)
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_META_VERIFICATION_DIR = Path.home() / ".xingzierai" / "meta_verification"


@dataclass
class AdversarialTestCase:
    test_id: str
    check_name: str
    input_text: str
    expected_result: str  # "pass", "warning", "fail", "critical"
    description: str = ""
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CheckVerificationResult:
    check_name: str
    true_positives: int = 0
    true_negatives: int = 0
    false_positives: int = 0
    false_negatives: int = 0
    precision: float = 0.0
    recall: float = 0.0
    f1_score: float = 0.0
    total_tests: int = 0
    passed: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_name": self.check_name,
            "true_positives": self.true_positives,
            "true_negatives": self.true_negatives,
            "false_positives": self.false_positives,
            "false_negatives": self.false_negatives,
            "precision": round(self.precision, 4),
            "recall": round(self.recall, 4),
            "f1_score": round(self.f1_score, 4),
            "total_tests": self.total_tests,
            "passed": self.passed,
        }


@dataclass
class ConsistencyIssue:
    check_a: str
    check_b: str
    issue_type: str
    description: str
    severity: str = "warning"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_a": self.check_a,
            "check_b": self.check_b,
            "issue_type": self.issue_type,
            "description": self.description,
            "severity": self.severity,
        }


@dataclass
class MetaVerificationReport:
    timestamp: float = field(default_factory=time.time)
    total_checks_verified: int = 0
    checks_passed: int = 0
    checks_failed: int = 0
    consistency_issues: List[ConsistencyIssue] = field(default_factory=list)
    coverage_rate: float = 0.0
    overall_passed: bool = False
    details: List[CheckVerificationResult] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "total_checks_verified": self.total_checks_verified,
            "checks_passed": self.checks_passed,
            "checks_failed": self.checks_failed,
            "consistency_issues": [i.to_dict() for i in self.consistency_issues],
            "coverage_rate": round(self.coverage_rate, 4),
            "overall_passed": self.overall_passed,
            "details": [d.to_dict() for d in self.details],
        }


ADVERSARIAL_TEST_CASES: List[AdversarialTestCase] = [
    AdversarialTestCase(
        test_id="AT-001", check_name="empty_output",
        input_text="", expected_result="critical",
        description="Empty string should trigger critical",
    ),
    AdversarialTestCase(
        test_id="AT-002", check_name="empty_output",
        input_text="Hello, this is a valid response.", expected_result="pass",
        description="Non-empty string should pass",
    ),
    AdversarialTestCase(
        test_id="AT-003", check_name="truncated_output",
        input_text="Here is the code:\n```python\ndef foo():\n    pass\n```",
        expected_result="pass",
        description="Complete code block should pass",
    ),
    AdversarialTestCase(
        test_id="AT-004", check_name="truncated_output",
        input_text="Here is the result: [output truncated due to token",
        expected_result="warning",
        description="Truncation indicator should trigger warning",
    ),
    AdversarialTestCase(
        test_id="AT-005", check_name="dangerous_code",
        input_text="You can use os.system('rm -rf /') to clean up",
        expected_result="critical",
        description="os.system with dangerous command should trigger critical",
    ),
    AdversarialTestCase(
        test_id="AT-006", check_name="dangerous_code",
        input_text="import subprocess\nsubprocess.run(['ls', '-la'])",
        expected_result="critical",
        description="subprocess usage should trigger critical",
    ),
    AdversarialTestCase(
        test_id="AT-007", check_name="dangerous_code",
        input_text="def calculate_sum(a, b):\n    return a + b",
        expected_result="pass",
        description="Safe code should pass",
    ),
    AdversarialTestCase(
        test_id="AT-008", check_name="json_validity",
        input_text='{"key": "value", "number": 42}',
        expected_result="pass",
        description="Valid JSON should pass",
    ),
    AdversarialTestCase(
        test_id="AT-009", check_name="json_validity",
        input_text='{"key": "value", "broken": }',
        expected_result="warning",
        description="Invalid JSON should trigger warning",
    ),
    AdversarialTestCase(
        test_id="AT-010", check_name="pii_leakage",
        input_text="My email is test@example.com and my API key is sk-1234567890abcdef",
        expected_result="critical",
        description="PII with email and API key should trigger critical",
    ),
    AdversarialTestCase(
        test_id="AT-011", check_name="pii_leakage",
        input_text="The function returns a string value.",
        expected_result="pass",
        description="No PII should pass",
    ),
    AdversarialTestCase(
        test_id="AT-012", check_name="code_injection",
        input_text="'; DROP TABLE users; --",
        expected_result="critical",
        description="SQL injection should trigger critical",
    ),
    AdversarialTestCase(
        test_id="AT-013", check_name="code_injection",
        input_text="<script>alert('xss')</script>",
        expected_result="critical",
        description="XSS should trigger critical",
    ),
    AdversarialTestCase(
        test_id="AT-014", check_name="code_injection",
        input_text="SELECT * FROM users WHERE id = ?",
        expected_result="pass",
        description="Parameterized query should pass",
    ),
    AdversarialTestCase(
        test_id="AT-015", check_name="hallucinated_url",
        input_text="Visit https://docs.python.org/3/ for more info",
        expected_result="pass",
        description="Known valid URL should pass",
    ),
    AdversarialTestCase(
        test_id="AT-016", check_name="contradiction_check",
        input_text="The answer is yes. However, the answer is also no.",
        expected_result="warning",
        description="Contradictory statements should trigger warning",
    ),
    AdversarialTestCase(
        test_id="AT-017", check_name="architecture_compliance",
        input_text="Use global variable to share state between components",
        expected_result="warning",
        description="Global mutable state should trigger warning",
    ),
    AdversarialTestCase(
        test_id="AT-018", check_name="dangerous_code",
        input_text="exec('print(1)')",
        expected_result="critical",
        description="exec() should trigger critical",
    ),
]

KNOWN_BUG_PATTERNS = [
    "empty_response", "truncated_output", "os_command_injection",
    "subprocess_injection", "exec_injection", "eval_injection",
    "json_parse_error", "pii_email_leak", "pii_api_key_leak",
    "pii_phone_leak", "sql_injection", "xss_injection",
    "hallucinated_url", "contradictory_output", "global_mutable_state",
    "import_hijacking", "path_traversal", "code_obfuscation",
    "token_overflow", "encoding_bypass",
]


class MetaVerifier:
    """Verifies the verification rules themselves.

    Three verification dimensions:
    1. Adversarial Testing: Known inputs with expected outputs
    2. Consistency Checking: No contradictions between checks
    3. Coverage Analysis: Known bug patterns vs check coverage
    """

    MIN_PRECISION = 0.7
    MIN_RECALL = 0.7
    MIN_F1 = 0.7
    MIN_COVERAGE = 0.5

    def __init__(self, meta_dir: Optional[str] = None):
        self._dir = Path(meta_dir) if meta_dir else _META_VERIFICATION_DIR
        self._test_cases: List[AdversarialTestCase] = list(ADVERSARIAL_TEST_CASES)
        self._last_report: Optional[MetaVerificationReport] = None
        self._load()

    def add_test_case(self, case: AdversarialTestCase) -> None:
        self._test_cases.append(case)

    def run_verification(self, verifier=None) -> MetaVerificationReport:
        """Run full meta-verification against a NeuroSymbolicVerifier.

        Args:
            verifier: NeuroSymbolicVerifier instance. If None, creates one.

        Returns:
            MetaVerificationReport with results
        """
        if verifier is None:
            try:
                from xingzierai.agents.neuro_symbolic_verifier import NeuroSymbolicVerifier
                verifier = NeuroSymbolicVerifier()
            except Exception as e:
                logger.error("Cannot create verifier: %s", e)
                return MetaVerificationReport(overall_passed=False)

        report = MetaVerificationReport()

        check_results = self._run_adversarial_tests(verifier)
        report.details = list(check_results.values())
        report.total_checks_verified = len(check_results)
        report.checks_passed = sum(1 for r in check_results.values() if r.passed)
        report.checks_failed = report.total_checks_verified - report.checks_passed

        report.consistency_issues = self._check_consistency(verifier)

        report.coverage_rate = self._check_coverage(verifier)

        report.overall_passed = (
            report.checks_failed == 0
            and len([i for i in report.consistency_issues if i.severity == "critical"]) == 0
            and report.coverage_rate >= self.MIN_COVERAGE
        )

        self._last_report = report
        self._save_report(report)
        return report

    def get_last_report(self) -> Optional[MetaVerificationReport]:
        return self._last_report

    def get_status(self) -> Dict[str, Any]:
        if self._last_report is None:
            return {"status": "no_report", "message": "Run verification first"}
        return {
            "status": "available",
            "overall_passed": self._last_report.overall_passed,
            "checks_verified": self._last_report.total_checks_verified,
            "checks_passed": self._last_report.checks_passed,
            "coverage_rate": self._last_report.coverage_rate,
            "consistency_issues": len(self._last_report.consistency_issues),
        }

    def _run_adversarial_tests(
        self, verifier,
    ) -> Dict[str, CheckVerificationResult]:
        results: Dict[str, CheckVerificationResult] = {}

        cases_by_check: Dict[str, List[AdversarialTestCase]] = {}
        for case in self._test_cases:
            cases_by_check.setdefault(case.check_name, []).append(case)

        for check_name, cases in cases_by_check.items():
            check_result = CheckVerificationResult(check_name=check_name)

            for case in cases:
                try:
                    result = verifier.verify(case.input_text, case.context)
                    actual_severity = "pass"
                    for cr in result.checks:
                        if cr.get("name") == check_name:
                            actual_severity = cr.get("severity", "pass")
                            break

                    expected = case.expected_result
                    if actual_severity == expected:
                        if expected == "pass":
                            check_result.true_negatives += 1
                        else:
                            check_result.true_positives += 1
                    else:
                        if expected == "pass":
                            check_result.false_positives += 1
                        else:
                            check_result.false_negatives += 1
                    check_result.total_tests += 1

                except Exception as e:
                    logger.debug("Test case %s failed: %s", case.test_id, e)
                    check_result.total_tests += 1
                    check_result.false_negatives += 1

            tp = check_result.true_positives
            fp = check_result.false_positives
            fn = check_result.false_negatives
            tn = check_result.true_negatives

            if tp + fp > 0:
                check_result.precision = tp / (tp + fp)
            if tp + fn > 0:
                check_result.recall = tp / (tp + fn)
            if check_result.precision + check_result.recall > 0:
                check_result.f1_score = (
                    2 * check_result.precision * check_result.recall
                    / (check_result.precision + check_result.recall)
                )

            check_result.passed = (
                check_result.precision >= self.MIN_PRECISION
                and check_result.recall >= self.MIN_RECALL
                and check_result.f1_score >= self.MIN_F1
            )

            results[check_name] = check_result

        return results

    def _check_consistency(self, verifier) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []

        check_names = [c.name for c in verifier._checks]
        safety_checks = [c for c in verifier._checks if c.category == "safety"]
        security_checks = [c for c in verifier._checks if c.category == "security"]

        for sc in safety_checks:
            for sec in security_checks:
                if sc.name == sec.name:
                    continue
                overlap = self._check_overlap(sc.check_fn, sec.check_fn)
                if overlap:
                    issues.append(ConsistencyIssue(
                        check_a=sc.name,
                        check_b=sec.name,
                        issue_type="overlap",
                        description=f"Safety and security checks may overlap on dangerous code patterns",
                        severity="warning",
                    ))

        return issues

    def _check_overlap(self, fn_a, fn_b) -> bool:
        test_inputs = [
            "os.system('ls')",
            "exec('code')",
            "eval('expr')",
        ]
        for inp in test_inputs:
            try:
                r_a = fn_a(inp, {})
                r_b = fn_b(inp, {})
                if r_a != "pass" and r_b != "pass":
                    return True
            except Exception:
                pass
        return False

    def _check_coverage(self, verifier) -> float:
        check_categories = set(c.category for c in verifier._checks)
        check_names = set(c.name for c in verifier._checks)

        covered_patterns = set()
        pattern_to_check = {
            "empty_response": "empty_output",
            "truncated_output": "truncated_output",
            "os_command_injection": "dangerous_code",
            "subprocess_injection": "dangerous_code",
            "exec_injection": "dangerous_code",
            "eval_injection": "dangerous_code",
            "json_parse_error": "json_validity",
            "pii_email_leak": "pii_leakage",
            "pii_api_key_leak": "pii_leakage",
            "pii_phone_leak": "pii_leakage",
            "sql_injection": "code_injection",
            "xss_injection": "code_injection",
            "hallucinated_url": "hallucinated_url",
            "contradictory_output": "contradiction_check",
            "global_mutable_state": "architecture_compliance",
        }

        for pattern, check_name in pattern_to_check.items():
            if check_name in check_names:
                covered_patterns.add(pattern)

        return len(covered_patterns) / max(len(KNOWN_BUG_PATTERNS), 1)

    def _save_report(self, report: MetaVerificationReport) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            path = self._dir / "latest_report.json"
            path.write_text(
                json.dumps(report.to_dict(), indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            logger.debug("Failed to save meta-verification report: %s", e)

    def _load(self) -> None:
        try:
            path = self._dir / "latest_report.json"
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                self._last_report = MetaVerificationReport(
                    timestamp=data.get("timestamp", 0),
                    total_checks_verified=data.get("total_checks_verified", 0),
                    checks_passed=data.get("checks_passed", 0),
                    checks_failed=data.get("checks_failed", 0),
                    coverage_rate=data.get("coverage_rate", 0),
                    overall_passed=data.get("overall_passed", False),
                )
        except Exception as e:
            logger.debug("Failed to load meta-verification report: %s", e)
