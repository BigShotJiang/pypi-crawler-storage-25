# -*- coding: utf-8 -*-
"""Mission Mode — autonomous multi-stage task execution.

Adapted for XINGZIER AI.
"""

from .state import (
    create_loop_dir,
    detect_git_context,
    get_active_loop_dir,
    init_progress_txt,
    list_loop_dirs,
    read_loop_config,
    read_prd,
    write_loop_config,
    write_task_md,
)
from .handler import (
    MISSION_COMMANDS,
    handle_mission_command,
    is_mission_command,
)
from .prompts import build_master_prompt

__all__ = [
    "MISSION_COMMANDS",
    "build_master_prompt",
    "create_loop_dir",
    "detect_git_context",
    "get_active_loop_dir",
    "handle_mission_command",
    "init_progress_txt",
    "is_mission_command",
    "list_loop_dirs",
    "read_loop_config",
    "read_prd",
    "write_loop_config",
    "write_task_md",
]
