# -*- coding: utf-8 -*-
"""Constitutional Core - Immutable meta-rules that cannot be modified by self-evolution.

Inspired by Godel's Incompleteness Theorem:
- Any formal system has truths it cannot prove about itself
- AI systems cannot verify their own verification
- Some rules must be axiomatic (unprovable but foundational)

The Constitutional Core protects the system's foundational rules from
being modified by any automated process, including the evolution engine.
These rules serve as the "axioms" of the system - they cannot be
self-validated but must be accepted as foundational truths.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

_CONSTITUTIONAL_DIR = Path.home() / ".xingzierai" / "constitutional"


class ConstitutionalViolationSeverity(str, Enum):
    WARNING = "warning"
    CRITICAL = "critical"
    FATAL = "fatal"


@dataclass
class ConstitutionalRule:
    rule_id: str
    rule_name: str
    category: str
    description: str
    iron_law: str
    severity: str = "BLOCKING"
    protected_symbols: List[str] = field(default_factory=list)
    protected_file_patterns: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "rule_name": self.rule_name,
            "category": self.category,
            "description": self.description,
            "iron_law": self.iron_law,
            "severity": self.severity,
            "protected_symbols": self.protected_symbols,
            "protected_file_patterns": self.protected_file_patterns,
        }


@dataclass
class ConstitutionalCheckResult:
    allowed: bool
    violations: List[str] = field(default_factory=list)
    severity: ConstitutionalViolationSeverity = ConstitutionalViolationSeverity.WARNING
    details: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "allowed": self.allowed,
            "violations": self.violations,
            "severity": self.severity.value,
            "details": self.details,
        }


CONSTITUTIONAL_RULES: List[ConstitutionalRule] = [
    ConstitutionalRule(
        rule_id="CC-001", rule_name="iron_laws_immutable",
        category="architecture",
        description="ARCHITECTURE_IRON_LAWS (AIL-1 through AIL-6) are immutable axioms",
        iron_law="1",
        protected_symbols=[
            "ARCHITECTURE_IRON_LAWS", "AIL-1", "AIL-2", "AIL-3",
            "AIL-4", "AIL-5", "AIL-6",
        ],
        protected_file_patterns=[
            "rule_engine.py", "constitutional_core.py",
        ],
    ),
    ConstitutionalRule(
        rule_id="CC-002", rule_name="red_lines_immutable",
        category="architecture",
        description="ARCHITECTURE_RED_LINES (ARL-1 through ARL-6) are immutable axioms",
        iron_law="2",
        protected_symbols=[
            "ARCHITECTURE_RED_LINES", "ARL-1", "ARL-2", "ARL-3",
            "ARL-4", "ARL-5", "ARL-6",
        ],
        protected_file_patterns=[
            "rule_engine.py", "constitutional_core.py",
        ],
    ),
    ConstitutionalRule(
        rule_id="CC-003", rule_name="constitutional_self_protection",
        category="meta",
        description="ConstitutionalCore itself cannot be modified by evolution",
        iron_law="6",
        protected_symbols=[
            "ConstitutionalCore", "CONSTITUTIONAL_RULES",
            "CC-001", "CC-002", "CC-003", "CC-004", "CC-005",
        ],
        protected_file_patterns=[
            "constitutional_core.py",
        ],
    ),
    ConstitutionalRule(
        rule_id="CC-004", rule_name="evolution_engine_safety_guards",
        category="evolution",
        description="Evolution engine safety mechanisms cannot be weakened",
        iron_law="6",
        protected_symbols=[
            "emergency_stop", "_emergency_stop_active",
            "MAX_PATCHES_PER_HOUR", "MAX_PATCHES_PER_DAY",
            "_can_apply_patch",
        ],
        protected_file_patterns=[
            "engine.py", "safety_guard.py", "governor.py",
        ],
    ),
    ConstitutionalRule(
        rule_id="CC-005", rule_name="compliance_first_enforcement",
        category="compliance",
        description="Compliance > Evaluation > Feature Extension ordering is immutable",
        iron_law="6",
        protected_symbols=[
            "compliance_first", "ComplianceScoringEngine",
        ],
        protected_file_patterns=[
            "scoring.py", "rule_engine.py",
        ],
    ),
]

_PROTECTED_FILE_HASHES: Dict[str, str] = {}


class ConstitutionalCore:
    """Immutable constitutional core protecting foundational rules.

    Design principles from Godel's Incompleteness Theorem:
    1. Some truths cannot be self-proven - they must be axiomatic
    2. The system cannot modify its own axioms
    3. Hash verification detects unauthorized modifications
    4. Emergency stop on constitutional violation
    """

    def __init__(self, constitutional_dir: Optional[str] = None):
        self._dir = Path(constitutional_dir) if constitutional_dir else _CONSTITUTIONAL_DIR
        self._rules: Dict[str, ConstitutionalRule] = {}
        self._hash_registry: Dict[str, str] = {}
        self._violation_log: List[Dict[str, Any]] = []
        self._initialized = False

        for rule in CONSTITUTIONAL_RULES:
            self._rules[rule.rule_id] = rule

        self._load_hash_registry()
        self._initialized = True

    def check_mutation(
        self,
        file_path: str,
        new_code: str,
        old_code: Optional[str] = None,
    ) -> ConstitutionalCheckResult:
        """Check if a proposed mutation violates constitutional rules.

        Args:
            file_path: Target file path for the mutation
            new_code: New code content to be written
            old_code: Current code content (for diff analysis)

        Returns:
            ConstitutionalCheckResult with allowed/violation details
        """
        violations = []
        file_name = Path(file_path).name
        file_path_str = str(file_path)

        for rule in self._rules.values():
            if not self._file_matches_rule(file_name, file_path_str, rule):
                continue

            if self._code_modifies_protected_symbols(new_code, old_code, rule):
                violations.append(
                    f"[{rule.rule_id}] {rule.rule_name}: "
                    f"Attempt to modify protected symbols in {file_name}"
                )

            if old_code and self._code_removes_protected_symbols(new_code, old_code, rule):
                violations.append(
                    f"[{rule.rule_id}] {rule.rule_name}: "
                    f"Attempt to remove protected symbols from {file_name}"
                )

        if not violations:
            return ConstitutionalCheckResult(
                allowed=True,
                details="No constitutional violations detected",
            )

        severity = ConstitutionalViolationSeverity.CRITICAL
        if any("CC-003" in v for v in violations):
            severity = ConstitutionalViolationSeverity.FATAL

        self._log_violation(file_path, violations, severity)

        return ConstitutionalCheckResult(
            allowed=False,
            violations=violations,
            severity=severity,
            details=f"Constitutional violation: {len(violations)} rule(s) breached",
        )

    def verify_integrity(self, source_dir: Optional[str] = None) -> Dict[str, Any]:
        """Verify integrity of protected files by comparing hashes.

        Args:
            source_dir: Source directory to verify (defaults to package dir)

        Returns:
            Dict with integrity check results
        """
        results = {
            "verified_at": time.time(),
            "total_protected": 0,
            "intact": 0,
            "tampered": 0,
            "missing": 0,
            "details": [],
        }

        protected_files = self._get_protected_files(source_dir)

        for file_path, expected_hash in protected_files.items():
            results["total_protected"] += 1
            actual_path = Path(file_path)

            if not actual_path.exists():
                results["missing"] += 1
                results["details"].append({
                    "file": str(actual_path),
                    "status": "missing",
                })
                continue

            actual_hash = self._compute_file_hash(actual_path)

            if expected_hash and actual_hash != expected_hash:
                results["tampered"] += 1
                results["details"].append({
                    "file": str(actual_path),
                    "status": "tampered",
                    "expected_hash": expected_hash[:16],
                    "actual_hash": actual_hash[:16],
                })
                self._log_violation(
                    str(actual_path),
                    ["File hash mismatch - possible unauthorized modification"],
                    ConstitutionalViolationSeverity.FATAL,
                )
            else:
                results["intact"] += 1
                results["details"].append({
                    "file": str(actual_path),
                    "status": "intact",
                    "hash": actual_hash[:16],
                })

        if results["tampered"] > 0:
            logger.critical(
                "Constitutional integrity check FAILED: %d tampered files",
                results["tampered"],
            )

        self._save_report(results)
        return results

    def register_file_hash(self, file_path: str) -> str:
        """Register a file's hash for integrity monitoring.

        Args:
            file_path: Path to the file to register

        Returns:
            SHA256 hash of the file
        """
        path = Path(file_path)
        if not path.exists():
            return ""
        file_hash = self._compute_file_hash(path)
        self._hash_registry[str(path)] = file_hash
        self._save_hash_registry()
        return file_hash

    def get_rules(self) -> List[Dict[str, Any]]:
        """Get all constitutional rules."""
        return [r.to_dict() for r in self._rules.values()]

    def get_violation_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent constitutional violation log."""
        return self._violation_log[-limit:]

    def get_status(self) -> Dict[str, Any]:
        """Get constitutional core status."""
        return {
            "initialized": self._initialized,
            "rule_count": len(self._rules),
            "protected_file_count": len(self._hash_registry),
            "violation_count": len(self._violation_log),
            "rules": self.get_rules(),
        }

    def _file_matches_rule(
        self, file_name: str, file_path: str, rule: ConstitutionalRule,
    ) -> bool:
        for pattern in rule.protected_file_patterns:
            if pattern in file_name or pattern in file_path:
                return True
        return False

    def _code_modifies_protected_symbols(
        self,
        new_code: str,
        old_code: Optional[str],
        rule: ConstitutionalRule,
    ) -> bool:
        for symbol in rule.protected_symbols:
            if old_code is None:
                continue
            if symbol in old_code and symbol not in new_code:
                return True
            if symbol in new_code and symbol not in old_code:
                return True
            if symbol in new_code and symbol in old_code:
                import re
                old_assign = re.search(
                    rf'{re.escape(symbol)}\s*=\s*\[', old_code,
                )
                new_assign = re.search(
                    rf'{re.escape(symbol)}\s*=\s*\[\s*\]', new_code,
                )
                if old_assign and new_assign:
                    return True
        return False

    def _code_removes_protected_symbols(
        self,
        new_code: str,
        old_code: str,
        rule: ConstitutionalRule,
    ) -> bool:
        for symbol in rule.protected_symbols:
            if symbol in old_code and symbol not in new_code:
                return True
        return False

    def _log_violation(
        self,
        file_path: str,
        violations: List[str],
        severity: ConstitutionalViolationSeverity,
    ) -> None:
        entry = {
            "timestamp": time.time(),
            "file_path": file_path,
            "violations": violations,
            "severity": severity.value,
        }
        self._violation_log.append(entry)
        if len(self._violation_log) > 1000:
            self._violation_log = self._violation_log[-500:]

        log_fn = {
            ConstitutionalViolationSeverity.WARNING: logger.warning,
            ConstitutionalViolationSeverity.CRITICAL: logger.critical,
            ConstitutionalViolationSeverity.FATAL: logger.critical,
        }.get(severity, logger.error)

        log_fn(
            "Constitutional violation [%s]: %s - %s",
            severity.value, file_path, "; ".join(violations),
        )

    def _compute_file_hash(self, file_path: Path) -> str:
        try:
            content = file_path.read_bytes()
            return hashlib.sha256(content).hexdigest()
        except Exception:
            return ""

    def _get_protected_files(
        self, source_dir: Optional[str] = None,
    ) -> Dict[str, str]:
        result = {}
        if source_dir:
            base = Path(source_dir)
        else:
            base = Path(__file__).parent

        for rule in self._rules.values():
            for pattern in rule.protected_file_patterns:
                candidates = list(base.rglob(pattern))
                for candidate in candidates:
                    if candidate.is_file():
                        registered_hash = self._hash_registry.get(str(candidate), "")
                        result[str(candidate)] = registered_hash
        return result

    def _save_hash_registry(self) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            path = self._dir / "hash_registry.json"
            path.write_text(
                json.dumps(self._hash_registry, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            logger.debug("Failed to save hash registry: %s", e)

    def _load_hash_registry(self) -> None:
        try:
            path = self._dir / "hash_registry.json"
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                self._hash_registry = data
        except Exception as e:
            logger.debug("Failed to load hash registry: %s", e)

    def _save_report(self, results: Dict[str, Any]) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            path = self._dir / "integrity_report.json"
            path.write_text(
                json.dumps(results, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            logger.debug("Failed to save integrity report: %s", e)


_global_core: Optional[ConstitutionalCore] = None


def get_constitutional_core() -> ConstitutionalCore:
    """Get or create the global ConstitutionalCore singleton."""
    global _global_core
    if _global_core is None:
        _global_core = ConstitutionalCore()
    return _global_core
