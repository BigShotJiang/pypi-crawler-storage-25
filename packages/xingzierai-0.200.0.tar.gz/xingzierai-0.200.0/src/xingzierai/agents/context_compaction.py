# -*- coding: utf-8 -*-
"""Multi-strategy Context Compaction - Enhanced compaction with 4 strategies.

Inspired by PraisonAI's ContextCompaction with 4 strategies:
- truncate: Remove oldest messages first
- sliding_window: Keep most recent messages within token limit
- summarize: Replace old messages with a summary
- smart: Intelligently select which messages to keep

Integrates with existing XINGZIER AI context_manager module.

Usage:
    from xingzierai.agents.context_compaction import (
        ContextCompactor, CompactionStrategy, CompactionConfig
    )

    compactor = ContextCompactor(CompactionConfig(
        strategy=CompactionStrategy.SMART,
        max_tokens=4000,
    ))
    compacted, result = compactor.compact(messages)
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class CompactionStrategy(Enum):
    TRUNCATE = "truncate"
    SLIDING_WINDOW = "sliding_window"
    SUMMARIZE = "summarize"
    SMART = "smart"


@dataclass
class CompactionConfig:
    strategy: CompactionStrategy = CompactionStrategy.SMART
    max_tokens: int = 4000
    preserve_system: bool = True
    preserve_recent: int = 3
    preserve_first: int = 1
    compact_threshold: float = 0.8
    summarize_max_length: int = 200


@dataclass
class CompactionResult:
    original_tokens: int = 0
    compacted_tokens: int = 0
    tokens_saved: int = 0
    compression_ratio: float = 0.0
    messages_kept: int = 0
    messages_removed: int = 0
    was_compacted: bool = False
    strategy_used: CompactionStrategy = CompactionStrategy.SMART

    def to_dict(self) -> dict:
        return {
            "original_tokens": self.original_tokens,
            "compacted_tokens": self.compacted_tokens,
            "tokens_saved": self.tokens_saved,
            "compression_ratio": round(self.compression_ratio, 3),
            "messages_kept": self.messages_kept,
            "messages_removed": self.messages_removed,
            "was_compacted": self.was_compacted,
            "strategy_used": self.strategy_used.value,
        }


def _estimate_tokens(text: str) -> int:
    if not text:
        return 0
    return max(1, len(text) // 4)


def _get_message_text(msg: Any) -> str:
    if isinstance(msg, dict):
        content = msg.get("content", "")
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, dict):
                    parts.append(block.get("text", ""))
                elif isinstance(block, str):
                    parts.append(block)
            return " ".join(parts)
        return str(content)
    content = getattr(msg, "content", "")
    if isinstance(content, list):
        parts = []
        for block in content:
            if hasattr(block, "text"):
                parts.append(block.text)
            elif isinstance(block, dict):
                parts.append(block.get("text", ""))
            elif isinstance(block, str):
                parts.append(block)
        return " ".join(parts)
    return str(content) if content else ""


def _get_message_role(msg: Any) -> str:
    if isinstance(msg, dict):
        return msg.get("role", "")
    return getattr(msg, "role", "")


def _is_system_message(msg: Any) -> bool:
    return _get_message_role(msg) == "system"


def _compute_message_tokens(messages: List[Any]) -> List[int]:
    return [_estimate_tokens(_get_message_text(m)) for m in messages]


class TruncateStrategy:
    """Remove oldest messages first to fit within token budget."""

    def compact(
        self,
        messages: List[Any],
        max_tokens: int,
        preserve_system: bool = True,
        preserve_first: int = 1,
        preserve_recent: int = 3,
    ) -> Tuple[List[Any], CompactionResult]:
        token_counts = _compute_message_tokens(messages)
        total_tokens = sum(token_counts)

        result = CompactionResult(
            original_tokens=total_tokens,
            strategy_used=CompactionStrategy.TRUNCATE,
        )

        if total_tokens <= max_tokens:
            result.compacted_tokens = total_tokens
            result.messages_kept = len(messages)
            return messages, result

        protected_indices = set()

        if preserve_system:
            for i, msg in enumerate(messages):
                if _is_system_message(msg):
                    protected_indices.add(i)

        for i in range(min(preserve_first, len(messages))):
            protected_indices.add(i)

        for i in range(max(0, len(messages) - preserve_recent), len(messages)):
            protected_indices.add(i)

        protected_tokens = sum(token_counts[i] for i in protected_indices)
        remaining_budget = max_tokens - protected_tokens

        removable = [(i, token_counts[i]) for i in range(len(messages)) if i not in protected_indices]
        removable.sort(key=lambda x: x[0], reverse=True)

        kept_removable = []
        used = 0
        for idx, tc in reversed(removable):
            if used + tc <= remaining_budget:
                kept_removable.append(idx)
                used += tc

        kept_indices = sorted(protected_indices | set(kept_removable))
        compacted = [messages[i] for i in kept_indices]

        result.compacted_tokens = sum(_compute_message_tokens(compacted))
        result.tokens_saved = total_tokens - result.compacted_tokens
        result.compression_ratio = result.tokens_saved / max(total_tokens, 1)
        result.messages_kept = len(compacted)
        result.messages_removed = len(messages) - len(compacted)
        result.was_compacted = True

        return compacted, result


class SlidingWindowStrategy:
    """Keep most recent messages within token limit."""

    def compact(
        self,
        messages: List[Any],
        max_tokens: int,
        preserve_system: bool = True,
        preserve_recent: int = 3,
    ) -> Tuple[List[Any], CompactionResult]:
        token_counts = _compute_message_tokens(messages)
        total_tokens = sum(token_counts)

        result = CompactionResult(
            original_tokens=total_tokens,
            strategy_used=CompactionStrategy.SLIDING_WINDOW,
        )

        if total_tokens <= max_tokens:
            result.compacted_tokens = total_tokens
            result.messages_kept = len(messages)
            return messages, result

        system_msgs = []
        other_msgs = []

        for i, msg in enumerate(messages):
            if _is_system_message(msg) and preserve_system:
                system_msgs.append(msg)
            else:
                other_msgs.append(msg)

        system_tokens = sum(_estimate_tokens(_get_message_text(m)) for m in system_msgs)
        remaining_budget = max_tokens - system_tokens

        window = []
        used = 0
        for msg in reversed(other_msgs):
            tc = _estimate_tokens(_get_message_text(msg))
            if used + tc <= remaining_budget:
                window.insert(0, msg)
                used += tc
            else:
                break

        compacted = system_msgs + window

        result.compacted_tokens = sum(_compute_message_tokens(compacted))
        result.tokens_saved = total_tokens - result.compacted_tokens
        result.compression_ratio = result.tokens_saved / max(total_tokens, 1)
        result.messages_kept = len(compacted)
        result.messages_removed = len(messages) - len(compacted)
        result.was_compacted = True

        return compacted, result


class SummarizeStrategy:
    """Replace old messages with a summary."""

    def compact(
        self,
        messages: List[Any],
        max_tokens: int,
        preserve_system: bool = True,
        preserve_recent: int = 3,
        summarize_max_length: int = 200,
    ) -> Tuple[List[Any], CompactionResult]:
        token_counts = _compute_message_tokens(messages)
        total_tokens = sum(token_counts)

        result = CompactionResult(
            original_tokens=total_tokens,
            strategy_used=CompactionStrategy.SUMMARIZE,
        )

        if total_tokens <= max_tokens:
            result.compacted_tokens = total_tokens
            result.messages_kept = len(messages)
            return messages, result

        system_msgs = []
        recent_msgs = []
        old_msgs = []

        for i, msg in enumerate(messages):
            if _is_system_message(msg) and preserve_system:
                system_msgs.append(msg)
            elif i >= len(messages) - preserve_recent:
                recent_msgs.append(msg)
            else:
                old_msgs.append(msg)

        old_texts = [_get_message_text(m) for m in old_msgs]
        summary = self._create_summary(old_texts, summarize_max_length)

        summary_msg = {"role": "system", "content": f"[Summary of previous conversation / 之前对话的摘要]\n{summary}"}

        compacted = system_msgs + [summary_msg] + recent_msgs

        result.compacted_tokens = sum(_compute_message_tokens(compacted))
        result.tokens_saved = total_tokens - result.compacted_tokens
        result.compression_ratio = result.tokens_saved / max(total_tokens, 1)
        result.messages_kept = len(compacted)
        result.messages_removed = len(messages) - len(compacted)
        result.was_compacted = True

        return compacted, result

    def _create_summary(self, texts: List[str], max_length: int) -> str:
        if not texts:
            return ""

        combined = "\n".join(t for t in texts if t.strip())
        if len(combined) <= max_length:
            return combined

        sentences = []
        for text in texts:
            for sentence in text.replace("。", ".\n").replace("！", "!\n").replace("？", "?\n").split("\n"):
                s = sentence.strip()
                if s and len(s) > 10:
                    sentences.append(s)

        if not sentences:
            return combined[:max_length]

        summary_parts = []
        total_len = 0
        for s in sentences:
            if total_len + len(s) + 1 > max_length:
                break
            summary_parts.append(s)
            total_len += len(s) + 1

        return " ".join(summary_parts) if summary_parts else combined[:max_length]


class SmartStrategy:
    """Intelligently select which messages to keep based on importance scoring."""

    def compact(
        self,
        messages: List[Any],
        max_tokens: int,
        preserve_system: bool = True,
        preserve_recent: int = 3,
        preserve_first: int = 1,
    ) -> Tuple[List[Any], CompactionResult]:
        token_counts = _compute_message_tokens(messages)
        total_tokens = sum(token_counts)

        result = CompactionResult(
            original_tokens=total_tokens,
            strategy_used=CompactionStrategy.SMART,
        )

        if total_tokens <= max_tokens:
            result.compacted_tokens = total_tokens
            result.messages_kept = len(messages)
            return messages, result

        scored = []
        for i, msg in enumerate(messages):
            score = self._score_message(msg, i, len(messages))
            scored.append((i, score, token_counts[i]))

        protected = set()
        if preserve_system:
            for i, msg in enumerate(messages):
                if _is_system_message(msg):
                    protected.add(i)
        for i in range(min(preserve_first, len(messages))):
            protected.add(i)
        for i in range(max(0, len(messages) - preserve_recent), len(messages)):
            protected.add(i)

        protected_tokens = sum(token_counts[i] for i in protected)
        remaining_budget = max_tokens - protected_tokens

        removable = [(i, s, tc) for i, s, tc in scored if i not in protected]
        removable.sort(key=lambda x: x[1], reverse=True)

        kept_removable = set()
        used = 0
        for idx, score, tc in removable:
            if used + tc <= remaining_budget:
                kept_removable.add(idx)
                used += tc

        kept_indices = sorted(protected | kept_removable)
        compacted = [messages[i] for i in kept_indices]

        result.compacted_tokens = sum(_compute_message_tokens(compacted))
        result.tokens_saved = total_tokens - result.compacted_tokens
        result.compression_ratio = result.tokens_saved / max(total_tokens, 1)
        result.messages_kept = len(compacted)
        result.messages_removed = len(messages) - len(compacted)
        result.was_compacted = True

        return compacted, result

    def _score_message(self, msg: Any, index: int, total: int) -> float:
        score = 0.0
        role = _get_message_role(msg)
        text = _get_message_text(msg)

        if role == "system":
            score += 10.0
        elif role == "user":
            score += 5.0
        elif role == "assistant":
            score += 3.0
        elif role == "tool":
            score += 1.0

        recency = (index + 1) / max(total, 1)
        score += recency * 5.0

        if "error" in text.lower() or "错误" in text.lower():
            score += 2.0

        if "important" in text.lower() or "重要" in text.lower():
            score += 3.0

        if "```" in text:
            score += 2.0

        if len(text) > 500:
            score += 1.0

        question_marks = text.count("?") + text.count("？")
        score += min(question_marks, 3)

        return score


class ContextCompactor:
    """Main compactor that delegates to strategy implementations.

    Usage:
        compactor = ContextCompactor(CompactionConfig(
            strategy=CompactionStrategy.SMART,
            max_tokens=4000,
        ))
        compacted, result = compactor.compact(messages)
    """

    def __init__(self, config: Optional[CompactionConfig] = None):
        self._config = config or CompactionConfig()
        self._strategies = {
            CompactionStrategy.TRUNCATE: TruncateStrategy(),
            CompactionStrategy.SLIDING_WINDOW: SlidingWindowStrategy(),
            CompactionStrategy.SUMMARIZE: SummarizeStrategy(),
            CompactionStrategy.SMART: SmartStrategy(),
        }
        self._compaction_history: List[dict] = []
        self._max_history = 100

    @property
    def config(self) -> CompactionConfig:
        return self._config

    def compact(self, messages: List[Any]) -> Tuple[List[Any], CompactionResult]:
        """Compact messages using the configured strategy.

        Args:
            messages: List of message objects to compact.

        Returns:
            Tuple of (compacted_messages, compaction_result).
        """
        if not messages:
            return messages, CompactionResult()

        strategy = self._strategies.get(self._config.strategy)
        if strategy is None:
            strategy = self._strategies[CompactionStrategy.SMART]

        if self._config.strategy == CompactionStrategy.TRUNCATE:
            compacted, result = strategy.compact(
                messages,
                self._config.max_tokens,
                preserve_system=self._config.preserve_system,
                preserve_first=self._config.preserve_first,
                preserve_recent=self._config.preserve_recent,
            )
        elif self._config.strategy == CompactionStrategy.SLIDING_WINDOW:
            compacted, result = strategy.compact(
                messages,
                self._config.max_tokens,
                preserve_system=self._config.preserve_system,
                preserve_recent=self._config.preserve_recent,
            )
        elif self._config.strategy == CompactionStrategy.SUMMARIZE:
            compacted, result = strategy.compact(
                messages,
                self._config.max_tokens,
                preserve_system=self._config.preserve_system,
                preserve_recent=self._config.preserve_recent,
                summarize_max_length=self._config.summarize_max_length,
            )
        else:
            compacted, result = strategy.compact(
                messages,
                self._config.max_tokens,
                preserve_system=self._config.preserve_system,
                preserve_recent=self._config.preserve_recent,
                preserve_first=self._config.preserve_first,
            )

        self._record_compaction(result)
        return compacted, result

    def get_stats(self, messages: List[Any]) -> dict:
        token_counts = _compute_message_tokens(messages)
        total_tokens = sum(token_counts)
        return {
            "total_tokens": total_tokens,
            "max_tokens": self._config.max_tokens,
            "needs_compaction": total_tokens > self._config.max_tokens * self._config.compact_threshold,
            "strategy": self._config.strategy.value,
            "message_count": len(messages),
        }

    def _record_compaction(self, result: CompactionResult) -> None:
        self._compaction_history.append({
            "timestamp": time.time(),
            "strategy": result.strategy_used.value,
            "original_tokens": result.original_tokens,
            "compacted_tokens": result.compacted_tokens,
            "compression_ratio": round(result.compression_ratio, 3),
            "messages_removed": result.messages_removed,
        })
        if len(self._compaction_history) > self._max_history:
            self._compaction_history = self._compaction_history[-self._max_history:]

    def get_history(self, limit: int = 20) -> List[dict]:
        return self._compaction_history[-limit:]


_global_compactor: Optional[ContextCompactor] = None


def get_context_compactor(config: Optional[CompactionConfig] = None) -> ContextCompactor:
    global _global_compactor
    if config is not None:
        _global_compactor = ContextCompactor(config)
    elif _global_compactor is None:
        _global_compactor = ContextCompactor()
    return _global_compactor
