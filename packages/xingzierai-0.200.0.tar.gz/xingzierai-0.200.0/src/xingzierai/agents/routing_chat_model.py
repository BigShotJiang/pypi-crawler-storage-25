# -*- coding: utf-8 -*-
"""Intelligent ChatModel router for small+large model collaboration.

- Content-aware routing (not just static mode)
- Free model priority (OpenCode free models first)
- Automatic fallback on failure
- Token budget awareness
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Literal, Type

from xingzierai.agentscope_core.formatter import FormatterBase
from xingzierai.agentscope_core.model import ChatModelBase
from xingzierai.agentscope_core.model._model_response import ChatResponse
from pydantic import BaseModel

from ..config.config import AgentsLLMRoutingConfig

logger = logging.getLogger(__name__)


Route = Literal["local", "cloud", "free"]


_LOW_COMPLEXITY_PATTERNS = re.compile(
    r"(?:翻译|translate)"
    r"|(?:格式|format|转换|convert|json|yaml|xml|csv)"
    r"|(?:是什么|什么是|what is|how to|怎么做)"
    r"|(?:总结一下|briefly|简述|列出|list)"
    r"|(?:等于|等于几|多少)",
    re.IGNORECASE,
)

_HIGH_COMPLEXITY_PATTERNS = re.compile(
    r"(?:设计|架构|architecture|design|系统|system)"
    r"|(?:证明|推导|reasoning|prove|derive)"
    r"|(?:优化|optimize|重构|refactor|性能|performance)"
    r"|(?:详细分析|deep analysis|深入|comprehensive)"
    r"|(?:实现|implement|开发|develop|编写代码|写代码|编程)"
    r"|(?:复杂|complex|困难|difficult)",
    re.IGNORECASE,
)


@dataclass
class RoutingDecision:
    route: Route
    reasons: list[str] = field(default_factory=list)
    confidence: float = 1.0


class IntelligentRoutingPolicy:
    """Content-aware routing policy for small+large
    model collaboration.

    Decision logic:
    1. If a free cloud model is available -> prefer it (zero cost)
    2. If the task is simple -> route to local/free model
    3. If the task is complex -> route to cloud model
    4. If tools are involved -> route to cloud model (local models
       typically lack tool support)
    5. Fallback: cloud_first -> cloud, else -> local
    """

    def __init__(self, cfg: AgentsLLMRoutingConfig):
        self.cfg = cfg
        self.has_free_model = getattr(cfg, "has_free_model", False)

    def decide(
        self,
        *,
        text: str = "",
        channel: str = "",
        tools_available: bool = True,
    ) -> RoutingDecision:
        if self.has_free_model:
            return RoutingDecision(
                route="free",
                reasons=["free_model_available"],
            )

        if tools_available:
            return RoutingDecision(
                route="cloud",
                reasons=["tools_require_cloud"],
            )

        complexity = self._classify_complexity(text)

        if complexity == "low":
            route = "local"
            reasons = ["low_complexity"]
        elif complexity == "high":
            route = "cloud"
            reasons = ["high_complexity"]
        else:
            mode = getattr(self.cfg, "mode", "local_first")
            route = "cloud" if mode == "cloud_first" else "local"
            reasons = [f"mode:{mode}"]

        return RoutingDecision(route=route, reasons=reasons)

    @staticmethod
    def _classify_complexity(text: str) -> str:
        if not text:
            return "medium"
        if _HIGH_COMPLEXITY_PATTERNS.search(text):
            return "high"
        if _LOW_COMPLEXITY_PATTERNS.search(text):
            return "low"
        return "medium"


@dataclass(frozen=True)
class RoutingEndpoint:
    provider_id: str
    model_name: str
    model: ChatModelBase
    formatter: FormatterBase
    formatter_family: Type[FormatterBase]


class RoutingChatModel(ChatModelBase):
    """A ChatModelBase that routes between local, cloud, and free model slots.

    Intelligent switching between on-device and
    cloud models. Supports three slots:
    - local: Ollama / llama.cpp / MLX
    - cloud: Paid cloud API (OpenAI, Anthropic, etc.)
    - free: Free cloud API (OpenCode Zen, OpenRouter free tier)
    """

    _FREE_DOWN_SINCE: float = 0.0
    _FREE_SKIP_SECONDS: float = 120.0

    def __init__(
        self,
        *,
        local_endpoint: RoutingEndpoint | None = None,
        cloud_endpoint: RoutingEndpoint | None = None,
        free_endpoint: RoutingEndpoint | None = None,
        routing_cfg: AgentsLLMRoutingConfig,
    ) -> None:
        super().__init__(
            model_name="routing",
            stream=bool(
                (local_endpoint and getattr(local_endpoint.model, "stream", True))
                or (cloud_endpoint and getattr(cloud_endpoint.model, "stream", True))
                or (free_endpoint and getattr(free_endpoint.model, "stream", True))
            ),
        )
        self.local_endpoint = local_endpoint
        self.cloud_endpoint = cloud_endpoint
        self.free_endpoint = free_endpoint
        self.routing_cfg = routing_cfg

        enhanced_cfg = AgentsLLMRoutingConfig(
            mode=getattr(routing_cfg, "mode", "local_first"),
        )
        enhanced_cfg.has_free_model = free_endpoint is not None
        self.policy = IntelligentRoutingPolicy(enhanced_cfg)

    def __setattr__(self, name: str, value: Any) -> None:
        if name in ('local_endpoint', 'cloud_endpoint', 'free_endpoint',
                     'routing_cfg', 'policy', 'model_name', 'stream'):
            super().__setattr__(name, value)
        else:
            propagated = []
            for ep in (self.local_endpoint, self.cloud_endpoint, self.free_endpoint):
                if ep and hasattr(ep.model, name):
                    setattr(ep.model, name, value)
                    propagated.append(f"{ep.provider_id}/{ep.model_name}")
            if propagated and name == 'reasoning_effort':
                logger.info(
                    "[RoutingChatModel] reasoning_effort=%s propagated to: %s",
                    value, ", ".join(propagated),
                )
            super().__setattr__(name, value)

    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            raise AttributeError(name)
        try:
            local_ep = object.__getattribute__(self, 'local_endpoint')
            cloud_ep = object.__getattribute__(self, 'cloud_endpoint')
            free_ep = object.__getattribute__(self, 'free_endpoint')
        except AttributeError:
            raise AttributeError(name)
        for ep in (local_ep, cloud_ep, free_ep):
            if ep and hasattr(ep.model, name):
                return getattr(ep.model, name)
        raise AttributeError(name)

    def _resolve_endpoint(
        self, decision: RoutingDecision
    ) -> RoutingEndpoint:
        if decision.route == "free" and self.free_endpoint:
            return self.free_endpoint
        if decision.route == "local" and self.local_endpoint:
            return self.local_endpoint
        if decision.route == "cloud" and self.cloud_endpoint:
            return self.cloud_endpoint

        if self.free_endpoint:
            return self.free_endpoint
        if self.cloud_endpoint:
            return self.cloud_endpoint
        if self.local_endpoint:
            return self.local_endpoint

        raise RuntimeError("No routing endpoint available")

    @classmethod
    def _is_free_skipped(cls) -> bool:
        if cls._FREE_DOWN_SINCE <= 0:
            return False
        elapsed = time.monotonic() - cls._FREE_DOWN_SINCE
        if elapsed >= cls._FREE_SKIP_SECONDS:
            cls._FREE_DOWN_SINCE = 0.0
            return False
        return True

    async def _call_with_fallback(
        self,
        endpoint: RoutingEndpoint,
        messages: list[dict],
        tools: list[dict] | None = None,
        tool_choice: Literal["auto", "none", "required"] | str | None = None,
        structured_model: Type[BaseModel] | None = None,
        **kwargs: Any,
    ) -> ChatResponse | AsyncGenerator[ChatResponse, None]:
        try:
            return await endpoint.model(
                messages=messages,
                tools=tools,
                tool_choice=tool_choice,
                structured_model=structured_model,
                **kwargs,
            )
        except Exception as e:
            logger.warning(
                "RoutingChatModel: %s/%s failed: %s, trying fallback",
                endpoint.provider_id,
                endpoint.model_name,
                e,
            )
            raise

    async def __call__(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        tool_choice: Literal["auto", "none", "required"] | str | None = None,
        structured_model: Type[BaseModel] | None = None,
        **kwargs: Any,
    ) -> ChatResponse | AsyncGenerator[ChatResponse, None]:
        text = " ".join(
            message["content"]
            for message in messages
            if message.get("role") == "user"
            and isinstance(message.get("content"), str)
        )
        decision = self.policy.decide(
            text=text,
            tools_available=tools is not None,
        )

        if decision.route == "free" and self._is_free_skipped():
            logger.info(
                "RoutingChatModel: free model DOWN, skipping to cloud/local"
            )
            if self.cloud_endpoint:
                decision = RoutingDecision(route="cloud", reasons=["free_down_fallback"])
            elif self.local_endpoint:
                decision = RoutingDecision(route="local", reasons=["free_down_fallback"])

        primary = self._resolve_endpoint(decision)

        logger.debug(
            "LLM routing: route=%s provider=%s model=%s reasons=%s",
            decision.route,
            primary.provider_id,
            primary.model_name,
            ",".join(decision.reasons),
        )

        try:
            result = await self._call_with_fallback(
                primary, messages, tools, tool_choice, structured_model, **kwargs
            )
            if decision.route == "free":
                RoutingChatModel._FREE_DOWN_SINCE = 0.0
            return result
        except Exception as primary_exc:
            if decision.route == "free":
                RoutingChatModel._FREE_DOWN_SINCE = time.monotonic()
                logger.warning(
                    "RoutingChatModel: free model failed, marking DOWN for %.0fs",
                    RoutingChatModel._FREE_SKIP_SECONDS,
                )
            fallback_order = [self.free_endpoint, self.cloud_endpoint, self.local_endpoint]
            for fb in fallback_order:
                if fb is None or fb is primary:
                    continue
                if fb is self.free_endpoint and self._is_free_skipped():
                    continue
                try:
                    logger.info(
                        "RoutingChatModel: fallback to %s/%s",
                        fb.provider_id,
                        fb.model_name,
                    )
                    return await self._call_with_fallback(
                        fb, messages, tools, tool_choice, structured_model, **kwargs
                    )
                except Exception as _fb_err:
                    logger.debug("Fallback endpoint %s failed: %s", fb, _fb_err)
                    continue
            raise
