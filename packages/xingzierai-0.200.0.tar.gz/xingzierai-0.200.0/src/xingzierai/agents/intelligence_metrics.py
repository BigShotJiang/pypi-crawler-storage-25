# -*- coding: utf-8 -*-
"""Intelligence Metrics Tracker - V7.4 Iron Law 20.

Core insight from AGI Whitepaper: System intelligence is NOT measured by
"feature count", but by:
1. Skill acquisition efficiency (Chollet): interactions needed to solve new problems
2. Token efficiency: tokens consumed per completed task
3. Rule hit rate: L0+L1 proportion of total reasoning
4. Zero-shot solve rate: first-attempt success on unseen task types

These metrics must improve with each evolution cycle, or the evolution
direction must be re-examined (Iron Law 19).
"""

from __future__ import annotations

import json
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_METRICS_DIR = Path.home() / ".xingzierai" / "intelligence_metrics"


class MetricTrend(str, Enum):
    IMPROVING = "improving"
    STABLE = "stable"
    DECLINING = "declining"


@dataclass
class TaskRecord:
    task_type: str
    task_description: str
    tier_used: str
    token_cost: int
    latency_ms: float
    success: bool
    first_attempt: bool = True
    interactions_needed: int = 1
    timestamp: float = field(default_factory=time.time)


@dataclass
class IntelligenceSnapshot:
    timestamp: float = field(default_factory=time.time)
    skill_acquisition_efficiency: float = 0.0
    token_efficiency: float = 0.0
    rule_hit_rate: float = 0.0
    zero_shot_solve_rate: float = 0.0
    l0_distribution: float = 0.0
    l1_distribution: float = 0.0
    l2_distribution: float = 0.0
    l3_distribution: float = 0.0
    total_tasks: int = 0
    llm_calls_avoided: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "skill_acquisition_efficiency": round(self.skill_acquisition_efficiency, 4),
            "token_efficiency": round(self.token_efficiency, 4),
            "rule_hit_rate": round(self.rule_hit_rate, 4),
            "zero_shot_solve_rate": round(self.zero_shot_solve_rate, 4),
            "l0_distribution": round(self.l0_distribution, 4),
            "l1_distribution": round(self.l1_distribution, 4),
            "l2_distribution": round(self.l2_distribution, 4),
            "l3_distribution": round(self.l3_distribution, 4),
            "total_tasks": self.total_tasks,
            "llm_calls_avoided": self.llm_calls_avoided,
        }


class IntelligenceMetrics:
    """V7.4 Iron Law 20: Track intelligence metrics over time.

    Intelligence is measured by 4 core metrics:
    1. Skill acquisition efficiency: 1 / avg(interactions_needed_for_new_tasks)
    2. Token efficiency: tasks_completed / total_tokens_consumed
    3. Rule hit rate: (L0_hits + L1_hits) / total_requests
    4. Zero-shot solve rate: first_attempt_successes / new_task_types

    Each evolution must show improvement in at least one metric,
    or the evolution direction must be re-examined.
    """

    MAX_HISTORY = 100
    MAX_TASK_RECORDS = 1000

    def __init__(self, metrics_dir: Optional[str] = None):
        self._metrics_dir = Path(metrics_dir) if metrics_dir else _METRICS_DIR
        self._task_records: List[TaskRecord] = []
        self._history: List[IntelligenceSnapshot] = []
        self._seen_task_types: Dict[str, int] = defaultdict(int)
        self._first_attempt_successes: Dict[str, int] = defaultdict(int)
        self._first_attempt_totals: Dict[str, int] = defaultdict(int)
        self._load()

    def record_task(self, record: TaskRecord) -> None:
        """Record a completed task for metrics tracking."""
        self._task_records.append(record)
        if len(self._task_records) > self.MAX_TASK_RECORDS:
            self._task_records = self._task_records[-self.MAX_TASK_RECORDS:]

        task_type = record.task_type
        self._seen_task_types[task_type] += 1

        if record.first_attempt:
            self._first_attempt_totals[task_type] += 1
            if record.success:
                self._first_attempt_successes[task_type] += 1

    def take_snapshot(self, router_metrics: Optional[Dict[str, Any]] = None) -> IntelligenceSnapshot:
        """Take a snapshot of current intelligence metrics."""
        recent = self._task_records[-100:] if self._task_records else []

        skill_eff = self._calc_skill_acquisition_efficiency(recent)
        token_eff = self._calc_token_efficiency(recent)
        rule_hit = self._calc_rule_hit_rate(recent)
        zero_shot = self._calc_zero_shot_rate()

        snapshot = IntelligenceSnapshot(
            skill_acquisition_efficiency=skill_eff,
            token_efficiency=token_eff,
            rule_hit_rate=rule_hit,
            zero_shot_solve_rate=zero_shot,
            total_tasks=len(self._task_records),
        )

        if router_metrics:
            tier_m = router_metrics.get("tier_metrics", {})
            snapshot.l0_distribution = tier_m.get("L0", {}).get("distribution", 0.0)
            snapshot.l1_distribution = tier_m.get("L1", {}).get("distribution", 0.0)
            snapshot.l2_distribution = tier_m.get("L2", {}).get("distribution", 0.0)
            snapshot.l3_distribution = tier_m.get("L3", {}).get("distribution", 0.0)
            snapshot.llm_calls_avoided = router_metrics.get("llm_calls_avoided", 0)

        self._history.append(snapshot)
        if len(self._history) > self.MAX_HISTORY:
            self._history = self._history[-self.MAX_HISTORY:]

        self._save()
        return snapshot

    def get_trends(self) -> Dict[str, MetricTrend]:
        """Analyze trends in intelligence metrics."""
        if len(self._history) < 2:
            return {k: MetricTrend.STABLE for k in [
                "skill_acquisition_efficiency", "token_efficiency",
                "rule_hit_rate", "zero_shot_solve_rate",
            ]}

        recent = self._history[-5:]
        older = self._history[-10:-5] if len(self._history) >= 10 else self._history[:len(self._history)//2]

        def avg_field(snapshots: List[IntelligenceSnapshot], field_name: str) -> float:
            vals = [getattr(s, field_name) for s in snapshots]
            return sum(vals) / len(vals) if vals else 0.0

        trends = {}
        for metric in [
            "skill_acquisition_efficiency", "token_efficiency",
            "rule_hit_rate", "zero_shot_solve_rate",
        ]:
            recent_avg = avg_field(recent, metric)
            older_avg = avg_field(older, metric)
            diff = recent_avg - older_avg
            threshold = 0.01

            if diff > threshold:
                trends[metric] = MetricTrend.IMPROVING
            elif diff < -threshold:
                trends[metric] = MetricTrend.DECLINING
            else:
                trends[metric] = MetricTrend.STABLE

        return trends

    def verify_iron_law_20(self) -> Dict[str, Any]:
        """V7.4 Iron Law 20 verification: Are intelligence metrics improving?"""
        trends = self.get_trends()
        snapshot = self._history[-1] if self._history else IntelligenceSnapshot()

        improving_count = sum(1 for t in trends.values() if t == MetricTrend.IMPROVING)
        declining_count = sum(1 for t in trends.values() if t == MetricTrend.DECLINING)

        return {
            "metrics_improving": improving_count > 0,
            "any_declining": declining_count > 0,
            "improving_count": improving_count,
            "declining_count": declining_count,
            "trends": {k: v.value for k, v in trends.items()},
            "current_snapshot": snapshot.to_dict(),
            "recommendation": (
                "Evolution direction OK: metrics improving"
                if improving_count > 0 and declining_count == 0
                else "WARNING: Some metrics declining, re-examine evolution direction"
                if declining_count > 0
                else "STABLE: No significant metric changes"
            ),
        }

    def verify_evolution_direction(self, router_metrics: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """V7.4 Iron Law 19: Verify evolution direction alignment.

        Three mandatory checks:
        1. Is the system less LLM-dependent?
        2. Has internalizable rule/symbolic reasoning increased?
        3. Is the system moving toward the three-tier architecture target?
        """
        snapshot = self._history[-1] if self._history else IntelligenceSnapshot()
        target = {"L0": 0.60, "L1": 0.25, "L2": 0.10, "L3": 0.05}

        current_l3 = snapshot.l3_distribution
        current_l0_l1 = snapshot.l0_distribution + snapshot.l1_distribution

        less_llm = current_l3 <= target["L3"] + 0.15
        increased_rules = current_l0_l1 >= 0.5

        dist_gap = (
            abs(snapshot.l0_distribution - target["L0"])
            + abs(snapshot.l1_distribution - target["L1"])
            + abs(snapshot.l2_distribution - target["L2"])
            + abs(snapshot.l3_distribution - target["L3"])
        )

        toward_target = dist_gap <= 0.5

        checks = {
            "less_llm_dependent": {
                "passed": less_llm,
                "current_l3": round(current_l3, 4),
                "target_l3": target["L3"],
                "detail": "L3 usage should be decreasing toward 5%",
            },
            "increased_internalization": {
                "passed": increased_rules,
                "current_l0_l1": round(current_l0_l1, 4),
                "target_l0_l1": target["L0"] + target["L1"],
                "detail": "L0+L1 hit rate should be increasing toward 85%",
            },
            "toward_three_tier": {
                "passed": toward_target,
                "distribution_gap": round(dist_gap, 4),
                "current": {
                    "L0": round(snapshot.l0_distribution, 4),
                    "L1": round(snapshot.l1_distribution, 4),
                    "L2": round(snapshot.l2_distribution, 4),
                    "L3": round(snapshot.l3_distribution, 4),
                },
                "target": target,
                "detail": "Distribution should converge to L0:60%+L1:25%+L2:10%+L3:5%",
            },
        }

        all_passed = all(c["passed"] for c in checks.values())

        return {
            "all_checks_passed": all_passed,
            "checks": checks,
            "recommendation": (
                "EVOLUTION DIRECTION ALIGNED: All 3 checks passed"
                if all_passed
                else "EVOLUTION DIRECTION MISALIGNED: Re-examine and adjust"
            ),
            "snapshot": snapshot.to_dict(),
        }

    def _calc_skill_acquisition_efficiency(self, records: List[TaskRecord]) -> float:
        if not records:
            return 0.0
        new_type_records = [r for r in records if self._seen_task_types.get(r.task_type, 0) <= 3]
        if not new_type_records:
            return 1.0
        avg_interactions = sum(r.interactions_needed for r in new_type_records) / len(new_type_records)
        return 1.0 / max(avg_interactions, 1.0)

    def _calc_token_efficiency(self, records: List[TaskRecord]) -> float:
        if not records:
            return 0.0
        successful = [r for r in records if r.success]
        if not successful:
            return 0.0
        total_tokens = sum(r.token_cost for r in successful)
        if total_tokens == 0:
            return 1.0
        return len(successful) / total_tokens * 1000

    def _calc_rule_hit_rate(self, records: List[TaskRecord]) -> float:
        if not records:
            return 0.0
        l0_l1_hits = sum(1 for r in records if r.tier_used in ("L0", "L1"))
        return l0_l1_hits / len(records)

    def _calc_zero_shot_rate(self) -> float:
        totals = self._first_attempt_totals
        successes = self._first_attempt_successes
        if not totals:
            return 0.0
        total_first = sum(totals.values())
        total_success = sum(successes.values())
        return total_success / max(total_first, 1)

    def _save(self) -> None:
        try:
            self._metrics_dir.mkdir(parents=True, exist_ok=True)
            data = {
                "history": [s.to_dict() for s in self._history[-20:]],
                "seen_task_types": dict(self._seen_task_types),
                "first_attempt_successes": dict(self._first_attempt_successes),
                "first_attempt_totals": dict(self._first_attempt_totals),
            }
            path = self._metrics_dir / "latest.json"
            path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e:
            logger.debug("Failed to save intelligence metrics: %s", e)

    def _load(self) -> None:
        try:
            path = self._metrics_dir / "latest.json"
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            for s_dict in data.get("history", []):
                snapshot = IntelligenceSnapshot(
                    timestamp=s_dict.get("timestamp", 0),
                    skill_acquisition_efficiency=s_dict.get("skill_acquisition_efficiency", 0),
                    token_efficiency=s_dict.get("token_efficiency", 0),
                    rule_hit_rate=s_dict.get("rule_hit_rate", 0),
                    zero_shot_solve_rate=s_dict.get("zero_shot_solve_rate", 0),
                    l0_distribution=s_dict.get("l0_distribution", 0),
                    l1_distribution=s_dict.get("l1_distribution", 0),
                    l2_distribution=s_dict.get("l2_distribution", 0),
                    l3_distribution=s_dict.get("l3_distribution", 0),
                    total_tasks=s_dict.get("total_tasks", 0),
                    llm_calls_avoided=s_dict.get("llm_calls_avoided", 0),
                )
                self._history.append(snapshot)
            self._seen_task_types = defaultdict(int, data.get("seen_task_types", {}))
            self._first_attempt_successes = defaultdict(int, data.get("first_attempt_successes", {}))
            self._first_attempt_totals = defaultdict(int, data.get("first_attempt_totals", {}))
        except Exception as e:
            logger.debug("Failed to load intelligence metrics: %s", e)
