# -*- coding: utf-8 -*-
"""Proactive trigger logic.

Simplified to work without Workspace abstraction.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Dict, Optional

from .proactive_types import ProactiveConfig

logger = logging.getLogger(__name__)

proactive_configs: Dict[str, ProactiveConfig] = {}
proactive_tasks: Dict[str, asyncio.Task] = {}


def enable_proactive_for_session(
    session_id: str,
    idle_minutes: int = 30,
) -> str:
    config = ProactiveConfig(
        enabled=True,
        idle_minutes=idle_minutes,
        last_user_interaction=datetime.now(timezone.utc),
        mode_enabled_time=datetime.now(timezone.utc),
    )
    proactive_configs[session_id] = config

    if session_id not in proactive_tasks or proactive_tasks[session_id].done():
        task = asyncio.create_task(_run_trigger_loop(session_id))
        proactive_tasks[session_id] = task

    return f"Proactive mode enabled with {idle_minutes} minute idle threshold."


def disable_proactive_for_session(session_id: str) -> str:
    if session_id in proactive_configs:
        proactive_configs[session_id].enabled = False
    if session_id in proactive_tasks and not proactive_tasks[session_id].done():
        proactive_tasks[session_id].cancel()
    return "Proactive mode disabled."


def is_proactive_enabled(session_id: str) -> bool:
    config = proactive_configs.get(session_id)
    return config is not None and config.enabled


def get_proactive_config(session_id: str) -> Optional[ProactiveConfig]:
    return proactive_configs.get(session_id)


def update_last_interaction(session_id: str) -> None:
    config = proactive_configs.get(session_id)
    if config and config.enabled:
        config.last_user_interaction = datetime.now(timezone.utc)


async def _run_trigger_loop(session_id: str) -> None:
    try:
        await proactive_trigger_loop(session_id)
    except Exception as e:
        logger.error("Error in proactive trigger: %s", e)


def _should_trigger_proactive(
    config: ProactiveConfig,
    last_interaction_tz_aware: datetime,
    current_time: datetime,
) -> bool:
    elapsed_minutes = (
        (current_time - last_interaction_tz_aware).total_seconds() / 60.0
    )
    if elapsed_minutes < config.idle_minutes:
        return False
    if not config.mode_enabled_time:
        return True
    mode_enabled_tz = (
        config.mode_enabled_time.replace(tzinfo=timezone.utc)
        if config.mode_enabled_time.tzinfo is None
        else config.mode_enabled_time
    )
    return (
        (current_time - mode_enabled_tz).total_seconds() / 60.0
        >= config.idle_minutes
    )


async def proactive_trigger_loop(session_id: str) -> None:
    last_trigger_attempt: Optional[datetime] = None

    while True:
        try:
            await asyncio.sleep(30)

            if session_id not in proactive_configs:
                continue

            config = proactive_configs[session_id]
            if not config.enabled:
                continue

            if config.last_user_interaction is None:
                continue

            last_interaction_tz = (
                config.last_user_interaction.replace(tzinfo=timezone.utc)
                if config.last_user_interaction.tzinfo is None
                else config.last_user_interaction
            )
            current_time = datetime.now(timezone.utc)

            if not _should_trigger_proactive(
                config, last_interaction_tz, current_time
            ):
                continue

            if config.running_task_id is not None:
                continue

            if last_trigger_attempt is not None:
                time_since = (
                    (current_time - last_trigger_attempt).total_seconds()
                )
                if time_since <= 60:
                    continue

            logger.info(
                "Proactive trigger: session %s idle for %d minutes",
                session_id,
                config.idle_minutes,
            )

            config.running_task_id = (
                f"proactive_{current_time.timestamp()}"
            )
            last_trigger_attempt = current_time

            try:
                logger.info(
                    "Proactive response would be generated for session %s",
                    session_id,
                )
            except Exception as e:
                logger.error("Error in proactive responder: %s", e)
            finally:
                if session_id in proactive_configs:
                    proactive_configs[session_id].running_task_id = None

        except asyncio.CancelledError:
            logger.info("Proactive trigger loop cancelled")
            break
        except Exception as e:
            logger.error("Error in proactive trigger loop: %s", e)
