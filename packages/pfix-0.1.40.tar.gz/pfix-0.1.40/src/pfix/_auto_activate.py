"""
pfix Auto-Activation module.

This module contains the auto-activation logic that is triggered
via pfix_auto.pth during Python startup.
"""

import sys
import os
from pathlib import Path


def _auto_activate_pfix():
    """Auto-activate pfix if configured in pyproject.toml or .env."""
    try:
        # Only activate if pfix is installed
        import pfix
        from pfix.config import get_config

        config = get_config()

        # Check if we should auto-activate
        # 1. Check pyproject.toml settings
        if hasattr(config, 'enabled') and not config.enabled:
            return

        # 2. Check environment (user can disable)
        if os.getenv('PFIX_DISABLE_AUTO', '').lower() in ('true', '1', 'yes'):
            return

        # 3. Check if we have configuration (pyproject.toml or .env)
        # If no config found, don't activate silently
        project_root = Path.cwd()
        has_config = (
            (project_root / "pyproject.toml").exists() or
            any((p / ".env").exists() for p in [project_root] + list(project_root.parents))
        )

        if not has_config:
            return

        # Auto-activate based on configuration
        if config.auto_apply or os.getenv('PFIX_AUTO_APPLY', '').lower() in ('true', '1', 'yes'):
            # Install global exception hook
            from pfix.session import install_pfix_hook
            install_pfix_hook(auto_apply=config.auto_apply)

            # Install import hook for SyntaxError detection
            _install_syntax_error_handler()

            # Check for dev mode
            if os.getenv('PFIX_DEV_MODE', '').lower() == 'true':
                from pfix.dev_mode import install_dev_mode_hook
                install_dev_mode_hook()

    except ImportError:
        pass  # pfix not installed, skip silently
    except Exception:
        pass  # Never break user code


def _install_syntax_error_handler():
    """Install import hook to catch SyntaxError during module loading."""
    try:
        import sys
        import ast
        from pathlib import Path

        class SyntaxErrorFinder:
            """Meta path finder that checks for syntax errors before Python parses."""

            def find_module(self, fullname, path=None):
                return None

            def find_spec(self, fullname, path, target=None):
                return None

        # Wrap the original __import__ to catch SyntaxError
        _original_import = __builtins__.__import__ if hasattr(__builtins__, '__import__') else __builtins__['__import__']

        def _pfix_import(name, *args, **kwargs):
            try:
                return _original_import(name, *args, **kwargs)
            except SyntaxError as e:
                # Try to fix the syntax error using pfix
                _handle_syntax_error(e)
                raise  # Re-raise if fix didn't work or wasn't applied

        if hasattr(__builtins__, '__import__'):
            __builtins__.__import__ = _pfix_import
        else:
            __builtins__['__import__'] = _pfix_import

    except Exception:
        pass  # Never break imports


def _handle_syntax_error(exc):
    """Handle SyntaxError by calling pfix to fix it."""
    try:
        import sys
        from pathlib import Path
        from pfix.types import ErrorContext
        from pfix.llm import request_fix
        from pfix.fixer import apply_fix
        from pfix.config import get_config
        from pfix.session import _clear_pycache
        from rich.console import Console

        console = Console(stderr=True)
        config = get_config()

        if not config.auto_apply:
            return  # Don't fix if not in auto-apply mode

        console.print(f"\n[red]💥 pfix: SyntaxError detected: {exc}[/]")

        # Build context from SyntaxError
        ctx = ErrorContext()
        ctx.exception_type = "SyntaxError"
        ctx.exception_message = str(exc)
        ctx.source_file = exc.filename or ""
        ctx.line_number = exc.lineno or 0
        ctx.failing_line = exc.text or ""
        ctx.python_version = sys.version.split()[0]

        # Read source file
        if ctx.source_file:
            try:
                source_path = Path(ctx.source_file)
                if source_path.exists():
                    ctx.source_code = source_path.read_text(encoding="utf-8")
            except Exception:
                pass

        console.print(f"[dim]Debug: SyntaxError in {ctx.source_file}:{ctx.line_number}[/]")

        # Request fix from LLM
        proposal = request_fix(ctx)
        console.print(f"[dim]Debug: confidence={proposal.confidence}, has_fix={proposal.has_code_fix}[/]")

        if proposal.confidence > 0.1 and proposal.has_code_fix:
            console.print(f"[blue]🔍 Confidence OK ({proposal.confidence:.0%}), applying fix...[/]")
            fixed = apply_fix(ctx, proposal, confirm=False)

            if fixed:
                console.print(f"[green]✓ Fix applied to {ctx.source_file}[/]")
                if config.auto_restart and ctx.source_file:
                    _clear_pycache(Path(ctx.source_file))
                    console.print("[green]🔄 Restarting process...[/]")
                    import os
                    os.execv(sys.executable, [sys.executable] + sys.argv)
        else:
            console.print(f"[yellow]⚠ Confidence too low ({proposal.confidence:.0%}), skipping[/]")

    except Exception:
        pass  # Never break on error handling


# Execute immediately when module is loaded (during Python startup via .pth)
_auto_activate_pfix()
