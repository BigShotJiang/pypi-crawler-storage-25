"""Tests for error classes — sanitization, hierarchy, and renamed classes."""

from huitzo_sdk.errors import (
    CommandTimeoutError,
    CronError,
    HTTPError,
    HTTPSecurityError,
    HuitzoError,
    IntegrationError,
    MCPConnectionError,
    MCPError,
    MCPSchemaError,
    MCPTimeoutError,
    MCPToolError,
    PackPermissionError,
    ValidationError,
)


class TestValidationErrorAttributes:
    """ValidationError redacts sensitive fields; stores others per docs/sdk/error-handling.md."""

    def test_sensitive_field_password_redacted(self) -> None:
        err = ValidationError(field="password", value="secret123", message="too short")
        assert err.value == "<redacted>"

    def test_sensitive_field_secret_redacted(self) -> None:
        err = ValidationError(field="user_secret", value="s3cr3t", message="invalid")
        assert err.value == "<redacted>"

    def test_sensitive_field_token_redacted(self) -> None:
        err = ValidationError(field="api_token", value="tok_abc123", message="expired")
        assert err.value == "<redacted>"

    def test_sensitive_field_api_key_redacted(self) -> None:
        err = ValidationError(field="api_key", value="sk-xyz", message="invalid")
        assert err.value == "<redacted>"

    def test_sensitive_field_credential_redacted(self) -> None:
        err = ValidationError(field="credential", value="cred_abc", message="bad")
        assert err.value == "<redacted>"

    def test_non_sensitive_int_value_stored(self) -> None:
        err = ValidationError(field="count", value=42, message="out of range")
        assert err.value == 42

    def test_non_sensitive_none_value_stored(self) -> None:
        err = ValidationError(field="name", value=None, message="required")
        assert err.value is None

    def test_non_sensitive_list_value_stored(self) -> None:
        err = ValidationError(field="tags", value=["a", "b"], message="too many")
        assert err.value == ["a", "b"]

    def test_field_and_message_preserved(self) -> None:
        err = ValidationError(field="email", value="user@test.com", message="invalid format")
        assert err.field == "email"
        assert err.message == "invalid format"


class TestHTTPErrorSanitization:
    """HTTPERR-BODY: HTTPError must truncate body and strip URL query params."""

    def test_url_query_params_stripped(self) -> None:
        err = HTTPError(
            url="https://api.com/v1?key=secret&token=abc",
            method="GET",
            response_body="ok",
            message="fail",
        )
        assert err.url == "https://api.com/v1"
        assert "secret" not in err.url
        assert "token" not in err.url

    def test_response_body_truncated(self) -> None:
        long_body = "x" * 500
        err = HTTPError(
            url="https://api.com/v1",
            method="GET",
            response_body=long_body,
            message="fail",
        )
        assert len(err.response_body) <= 213  # 200 + len(" [truncated]")
        assert "[truncated]" in err.response_body

    def test_short_response_body_not_truncated(self) -> None:
        err = HTTPError(
            url="https://api.com/v1",
            method="POST",
            response_body="short",
            message="ok",
        )
        assert err.response_body == "short"

    def test_none_response_body_preserved(self) -> None:
        err = HTTPError(
            url="https://api.com/v1",
            method="GET",
            response_body=None,
            message="no body",
        )
        assert err.response_body is None

    def test_method_and_status_preserved(self) -> None:
        err = HTTPError(
            url="https://api.com/v1?secret=leaked",
            method="POST",
            status_code=502,
            response_body="error",
            message="fail",
        )
        assert err.method == "POST"
        assert err.status_code == 502


class TestRenamedErrors:
    """BUILTIN-SHADOW: PermissionError→PackPermissionError, TimeoutError→CommandTimeoutError."""

    def test_pack_permission_error_is_huitzo_error(self) -> None:
        assert issubclass(PackPermissionError, HuitzoError)

    def test_pack_permission_error_code(self) -> None:
        err = PackPermissionError(message="denied")
        assert err.code == "PERMISSION_DENIED"

    def test_command_timeout_error_is_huitzo_error(self) -> None:
        assert issubclass(CommandTimeoutError, HuitzoError)

    def test_command_timeout_error_code(self) -> None:
        err = CommandTimeoutError(timeout_seconds=60, elapsed_seconds=60.0)
        assert err.code == "TIMEOUT"
        assert err.retryable is True

    def test_no_builtin_shadowing(self) -> None:
        """Ensure we don't shadow builtins.PermissionError or builtins.TimeoutError."""
        import builtins

        assert PackPermissionError is not builtins.PermissionError
        assert CommandTimeoutError is not builtins.TimeoutError


class TestMCPErrorHierarchy:
    """MCP errors per docs/sdk/error-handling.md#mcperror hierarchy."""

    def test_mcp_error_is_integration_error(self) -> None:
        assert issubclass(MCPError, IntegrationError)

    def test_mcp_connection_error(self) -> None:
        err = MCPConnectionError(server="my-server", message="refused")
        assert err.code == "MCP_CONNECTION_ERROR"
        assert err.server == "my-server"
        assert isinstance(err, MCPError)

    def test_mcp_tool_error(self) -> None:
        err = MCPToolError(tool="read_file", server="fs-server", message="not found")
        assert err.code == "MCP_TOOL_ERROR"
        assert err.tool == "read_file"
        assert err.server == "fs-server"

    def test_mcp_timeout_error(self) -> None:
        err = MCPTimeoutError(server="slow-server", timeout_seconds=30)
        assert err.code == "MCP_TIMEOUT"
        assert err.retryable is True
        assert err.server == "slow-server"
        assert err.timeout_seconds == 30

    def test_mcp_schema_error(self) -> None:
        err = MCPSchemaError(tool="bad-tool", message="invalid params")
        assert err.code == "MCP_SCHEMA_ERROR"
        assert err.tool == "bad-tool"

    def test_all_mcp_errors_are_huitzo_errors(self) -> None:
        for cls in (MCPError, MCPConnectionError, MCPToolError, MCPTimeoutError, MCPSchemaError):
            assert issubclass(cls, HuitzoError)


class TestCronErrorHierarchy:
    """CronError is an IntegrationError per docs/sdk/error-handling.md."""

    def test_cron_error_is_integration_error(self) -> None:
        assert issubclass(CronError, IntegrationError)

    def test_cron_error_is_huitzo_error(self) -> None:
        assert issubclass(CronError, HuitzoError)

    def test_cron_error_code(self) -> None:
        err = CronError(message="schedule invalid")
        assert err.code == "CRON_ERROR"
        assert err.service == "cron"
        assert "schedule invalid" in str(err)


class TestHTTPSecurityErrorAllowedDomains:
    """HTTPSecurityError.allowed_domains per docs/sdk/integrations.md."""

    def test_allowed_domains_stored(self) -> None:
        err = HTTPSecurityError(domain="evil.com", allowed_domains=["good.com", "safe.org"])
        assert err.domain == "evil.com"
        assert err.allowed_domains == ["good.com", "safe.org"]

    def test_allowed_domains_default_empty(self) -> None:
        err = HTTPSecurityError(domain="evil.com")
        assert err.allowed_domains == []
