"""Tests for the storage interface, InMemoryBackend, and StorageNamespace."""

import time
from uuid import UUID

import pytest

from huitzo_sdk.storage import InMemoryBackend, StorageNamespace


# --- Namespace tests ---


class TestStorageNamespace:
    def setup_method(self) -> None:
        self.ns = StorageNamespace(
            tenant_id=UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
            user_id=UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"),
            pack_id="my-pack",
        )

    def test_user_scope(self) -> None:
        key = self.ns.scope_key("settings", scope="user")
        assert key == (
            "tenant:aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa:"
            "user:bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb:"
            "pack:my-pack:settings"
        )

    def test_tenant_scope(self) -> None:
        key = self.ns.scope_key("shared", scope="tenant")
        assert key == "tenant:aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa:shared"

    def test_pack_scope(self) -> None:
        key = self.ns.scope_key("cache", scope="pack")
        assert key == "tenant:aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa:pack:my-pack:cache"

    def test_pack_scope_tenant_isolation(self) -> None:
        """Two different tenants get different pack-scope keys."""
        ns2 = StorageNamespace(
            tenant_id=UUID("cccccccc-cccc-cccc-cccc-cccccccccccc"),
            user_id=UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"),
            pack_id="my-pack",
        )
        key1 = self.ns.scope_key("cache", scope="pack")
        key2 = ns2.scope_key("cache", scope="pack")
        assert key1 != key2
        assert "aaaaaaaa" in key1
        assert "cccccccc" in key2

    def test_default_scope_is_user(self) -> None:
        assert self.ns.scope_key("k") == self.ns.scope_key("k", scope="user")

    def test_invalid_scope_raises(self) -> None:
        with pytest.raises(ValueError, match="Invalid scope"):
            self.ns.scope_key("k", scope="global")

    def test_scope_prefix(self) -> None:
        prefix = self.ns.scope_prefix("cache:", scope="tenant")
        assert prefix == "tenant:aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa:cache:"

    def test_tenant_scope_is_cross_pack(self) -> None:
        """Two different packs in the same tenant get identical tenant-scope keys.

        This documents the intentional (but dangerous) behaviour: scope='tenant'
        has no pack component, so different packs share the same key space.
        Use unique key prefixes or scope='pack' to avoid collisions.
        """
        ns_other_pack = StorageNamespace(
            tenant_id=UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
            user_id=UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"),
            pack_id="other-pack",
        )
        key_this = self.ns.scope_key("config", scope="tenant")
        key_other = ns_other_pack.scope_key("config", scope="tenant")
        assert key_this == key_other, (
            "tenant scope must be cross-pack; different packs see the same key"
        )

    def test_pack_scope_isolates_across_packs(self) -> None:
        """Two different packs in the same tenant get different pack-scope keys."""
        ns_other_pack = StorageNamespace(
            tenant_id=UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
            user_id=UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"),
            pack_id="other-pack",
        )
        key_this = self.ns.scope_key("config", scope="pack")
        key_other = ns_other_pack.scope_key("config", scope="pack")
        assert key_this != key_other
        assert "my-pack" in key_this
        assert "other-pack" in key_other


# --- InMemoryBackend: core operations ---


class TestInMemoryBackendCore:
    @pytest.fixture()
    def backend(self) -> InMemoryBackend:
        return InMemoryBackend()

    @pytest.mark.asyncio
    async def test_save_and_get(self, backend: InMemoryBackend) -> None:
        await backend.save("k1", {"hello": "world"})
        assert await backend.get("k1") == {"hello": "world"}

    @pytest.mark.asyncio
    async def test_get_missing_returns_default(self, backend: InMemoryBackend) -> None:
        assert await backend.get("missing") is None
        assert await backend.get("missing", default=42) == 42

    @pytest.mark.asyncio
    async def test_save_overwrites(self, backend: InMemoryBackend) -> None:
        await backend.save("k", 1)
        await backend.save("k", 2)
        assert await backend.get("k") == 2

    @pytest.mark.asyncio
    async def test_delete_existing(self, backend: InMemoryBackend) -> None:
        await backend.save("k", "v")
        deleted = await backend.delete("k")
        assert deleted is True
        assert await backend.get("k") is None

    @pytest.mark.asyncio
    async def test_delete_missing(self, backend: InMemoryBackend) -> None:
        deleted = await backend.delete("missing")
        assert deleted is False

    @pytest.mark.asyncio
    async def test_exists(self, backend: InMemoryBackend) -> None:
        assert await backend.exists("k") is False
        await backend.save("k", "v")
        assert await backend.exists("k") is True

    @pytest.mark.asyncio
    async def test_list_with_prefix(self, backend: InMemoryBackend) -> None:
        await backend.save("cache:a", 1)
        await backend.save("cache:b", 2)
        await backend.save("other:c", 3)
        keys = await backend.list(prefix="cache:")
        assert keys == ["cache:a", "cache:b"]

    @pytest.mark.asyncio
    async def test_list_all(self, backend: InMemoryBackend) -> None:
        await backend.save("b", 2)
        await backend.save("a", 1)
        keys = await backend.list()
        assert keys == ["a", "b"]

    @pytest.mark.asyncio
    async def test_list_pagination(self, backend: InMemoryBackend) -> None:
        for i in range(5):
            await backend.save(f"k{i}", i)
        assert await backend.list(limit=2) == ["k0", "k1"]
        assert await backend.list(limit=2, offset=2) == ["k2", "k3"]
        assert await backend.list(limit=2, offset=4) == ["k4"]

    @pytest.mark.asyncio
    async def test_save_returns_key(self, backend: InMemoryBackend) -> None:
        result = await backend.save("mykey", "val")
        assert result == "mykey"


# --- TTL ---


class TestInMemoryBackendTTL:
    @pytest.fixture()
    def backend(self) -> InMemoryBackend:
        return InMemoryBackend()

    @pytest.mark.asyncio
    async def test_ttl_not_expired(self, backend: InMemoryBackend) -> None:
        await backend.save("k", "v", ttl=9999)
        assert await backend.get("k") == "v"
        assert await backend.exists("k") is True

    @pytest.mark.asyncio
    async def test_ttl_expired(self, backend: InMemoryBackend) -> None:
        await backend.save("k", "v", ttl=1)
        # Simulate time passing
        backend._set_expiration_for_testing("k", time.monotonic() - 1)
        assert await backend.get("k") is None
        assert await backend.exists("k") is False

    @pytest.mark.asyncio
    async def test_ttl_expired_not_in_list(self, backend: InMemoryBackend) -> None:
        await backend.save("k", "v", ttl=1)
        backend._set_expiration_for_testing("k", time.monotonic() - 1)
        assert await backend.list() == []


# --- Batch operations ---


class TestInMemoryBackendBatch:
    @pytest.fixture()
    def backend(self) -> InMemoryBackend:
        return InMemoryBackend()

    @pytest.mark.asyncio
    async def test_save_many(self, backend: InMemoryBackend) -> None:
        await backend.save_many({"a": 1, "b": 2, "c": 3})
        assert await backend.get("a") == 1
        assert await backend.get("b") == 2
        assert await backend.get("c") == 3

    @pytest.mark.asyncio
    async def test_get_many(self, backend: InMemoryBackend) -> None:
        await backend.save("a", 1)
        await backend.save("b", 2)
        result = await backend.get_many(["a", "b", "missing"])
        assert result == {"a": 1, "b": 2, "missing": None}

    @pytest.mark.asyncio
    async def test_delete_many(self, backend: InMemoryBackend) -> None:
        await backend.save_many({"a": 1, "b": 2, "c": 3})
        count = await backend.delete_many(["a", "c", "missing"])
        assert count == 2
        assert await backend.exists("b") is True
        assert await backend.exists("a") is False


# --- Query ---


class TestInMemoryBackendQuery:
    @pytest.fixture()
    def backend(self) -> InMemoryBackend:
        return InMemoryBackend()

    @pytest.mark.asyncio
    async def test_query_by_prefix(self, backend: InMemoryBackend) -> None:
        await backend.save("report:1", {"title": "Q1"})
        await backend.save("report:2", {"title": "Q2"})
        await backend.save("other:1", {"title": "X"})
        results = await backend.query(prefix="report:")
        assert len(results) == 2
        assert results[0]["key"] == "report:1"

    @pytest.mark.asyncio
    async def test_query_by_metadata(self, backend: InMemoryBackend) -> None:
        await backend.save(
            "r:1", {"title": "Q1"}, metadata={"type": "financial", "status": "complete"}
        )
        await backend.save(
            "r:2", {"title": "Q2"}, metadata={"type": "financial", "status": "draft"}
        )
        await backend.save("r:3", {"title": "Q3"}, metadata={"type": "sales"})
        results = await backend.query(
            prefix="r:", metadata={"type": "financial", "status": "complete"}
        )
        assert len(results) == 1
        assert results[0]["value"] == {"title": "Q1"}

    @pytest.mark.asyncio
    async def test_query_limit(self, backend: InMemoryBackend) -> None:
        for i in range(10):
            await backend.save(f"k:{i}", i)
        results = await backend.query(prefix="k:", limit=3)
        assert len(results) == 3

    @pytest.mark.asyncio
    async def test_query_skips_expired(self, backend: InMemoryBackend) -> None:
        await backend.save("k:1", "live", ttl=9999)
        await backend.save("k:2", "dead", ttl=1)
        backend._set_expiration_for_testing("k:2", time.monotonic() - 1)
        results = await backend.query(prefix="k:")
        assert len(results) == 1
        assert results[0]["key"] == "k:1"


# --- Transactions ---


class TestInMemoryBackendTransaction:
    @pytest.fixture()
    def backend(self) -> InMemoryBackend:
        return InMemoryBackend()

    @pytest.mark.asyncio
    async def test_transaction_commit(self, backend: InMemoryBackend) -> None:
        await backend.save("balance", 100)
        async with backend.transaction():
            await backend.save("balance", 50)
            await backend.save("transferred", 50)
        assert await backend.get("balance") == 50
        assert await backend.get("transferred") == 50

    @pytest.mark.asyncio
    async def test_transaction_rollback(self, backend: InMemoryBackend) -> None:
        await backend.save("balance", 100)
        with pytest.raises(ValueError, match="insufficient"):
            async with backend.transaction():
                await backend.save("balance", -10)
                raise ValueError("insufficient")
        # Rolled back
        assert await backend.get("balance") == 100

    @pytest.mark.asyncio
    async def test_transaction_rollback_removes_new_keys(self, backend: InMemoryBackend) -> None:
        with pytest.raises(RuntimeError):
            async with backend.transaction():
                await backend.save("new-key", "value")
                raise RuntimeError("abort")
        assert await backend.exists("new-key") is False

    @pytest.mark.asyncio
    async def test_nested_transaction(self, backend: InMemoryBackend) -> None:
        await backend.save("k", 1)
        async with backend.transaction():
            await backend.save("k", 2)
            async with backend.transaction():
                await backend.save("k", 3)
            # Inner committed
            assert await backend.get("k") == 3
        # Outer committed
        assert await backend.get("k") == 3

    @pytest.mark.asyncio
    async def test_nested_transaction_inner_raises_outer_rolls_back(
        self, backend: InMemoryBackend
    ) -> None:
        """Nested tx has no independent snapshot; inner raise propagates to outer rollback."""
        await backend.save("k", "initial")
        with pytest.raises(RuntimeError, match="inner error"):
            async with backend.transaction():  # outer: snapshots k="initial"
                await backend.save("k", "outer-change")
                async with backend.transaction():  # nested: no new snapshot
                    await backend.save("k", "inner-change")
                    raise RuntimeError("inner error")
        # Outer rolled back: k is restored to pre-outer value
        assert await backend.get("k") == "initial"

    @pytest.mark.asyncio
    async def test_nested_transaction_resets_flag_after_inner_raise(
        self, backend: InMemoryBackend
    ) -> None:
        """After a nested-tx rollback, the backend accepts a new transaction."""
        await backend.save("k", "initial")
        with pytest.raises(RuntimeError):
            async with backend.transaction():
                async with backend.transaction():
                    raise RuntimeError("abort")
        # Verify _in_transaction is reset so a new tx can start
        async with backend.transaction():
            await backend.save("k", "new-value")
        assert await backend.get("k") == "new-value"
