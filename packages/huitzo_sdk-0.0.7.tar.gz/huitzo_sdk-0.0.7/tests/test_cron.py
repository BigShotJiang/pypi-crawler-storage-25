"""
Module: tests.test_cron
Description: Tests for CronClient — properties, fast-paths, and async backend delegation.

Implements:
    - docs/sdk/context.md#ctx-cron
    - docs/packs/manifest.md#service-reference
"""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock

import pytest

from huitzo_sdk.integrations.cron import CronClient, CronMetadata


class TestCronClientNoMetadata:
    """Properties return safe defaults when _metadata is None."""

    @pytest.fixture
    def client(self) -> CronClient:
        return CronClient()

    def test_schedule_is_none(self, client: CronClient) -> None:
        assert client.schedule is None

    def test_scheduled_at_is_none(self, client: CronClient) -> None:
        assert client.scheduled_at is None

    def test_is_scheduled_is_false(self, client: CronClient) -> None:
        assert client.is_scheduled is False


class TestCronClientWithMetadata:
    """Properties delegate to _metadata when present."""

    @pytest.fixture
    def now(self) -> datetime:
        return datetime(2026, 4, 26, 8, 0, 0, tzinfo=timezone.utc)

    @pytest.fixture
    def client(self, now: datetime) -> CronClient:
        metadata = CronMetadata(
            schedule="0 8 * * 1-5",
            scheduled_at=now,
            is_scheduled=True,
        )
        return CronClient(_metadata=metadata)

    def test_schedule_delegates(self, client: CronClient) -> None:
        assert client.schedule == "0 8 * * 1-5"

    def test_scheduled_at_delegates(self, client: CronClient, now: datetime) -> None:
        assert client.scheduled_at == now

    def test_is_scheduled_delegates(self, client: CronClient) -> None:
        assert client.is_scheduled is True

    def test_on_demand_metadata(self) -> None:
        metadata = CronMetadata(schedule=None, scheduled_at=None, is_scheduled=False)
        client = CronClient(_metadata=metadata)
        assert client.schedule is None
        assert client.scheduled_at is None
        assert client.is_scheduled is False


class TestCronClientNoBackend:
    """get_next_run and get_last_run return None when _backend is None."""

    @pytest.fixture
    def client(self) -> CronClient:
        return CronClient()

    @pytest.mark.asyncio
    async def test_get_next_run_returns_none(self, client: CronClient) -> None:
        result = await client.get_next_run("my-pack/my-command")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_last_run_returns_none(self, client: CronClient) -> None:
        result = await client.get_last_run("my-pack/my-command")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_next_run_no_namespace_returns_none(self, client: CronClient) -> None:
        result = await client.get_next_run()
        assert result is None

    @pytest.mark.asyncio
    async def test_get_last_run_no_namespace_returns_none(self, client: CronClient) -> None:
        result = await client.get_last_run()
        assert result is None


class TestCronClientWithBackend:
    """Async methods delegate to backend when _backend is set."""

    @pytest.fixture
    def next_run(self) -> datetime:
        return datetime(2026, 4, 27, 8, 0, 0, tzinfo=timezone.utc)

    @pytest.fixture
    def last_run(self) -> datetime:
        return datetime(2026, 4, 26, 8, 0, 0, tzinfo=timezone.utc)

    @pytest.fixture
    def backend(self, next_run: datetime, last_run: datetime) -> AsyncMock:
        mock = AsyncMock()
        mock.get_next_run.return_value = next_run
        mock.get_last_run.return_value = last_run
        return mock

    @pytest.fixture
    def client(self, backend: AsyncMock) -> CronClient:
        return CronClient(_backend=backend, _current_namespace="demo/hello")

    @pytest.mark.asyncio
    async def test_get_next_run_delegates(
        self, client: CronClient, backend: AsyncMock, next_run: datetime
    ) -> None:
        result = await client.get_next_run("demo/hello")
        assert result == next_run
        backend.get_next_run.assert_awaited_once_with("demo/hello")

    @pytest.mark.asyncio
    async def test_get_last_run_delegates(
        self, client: CronClient, backend: AsyncMock, last_run: datetime
    ) -> None:
        result = await client.get_last_run("demo/hello")
        assert result == last_run
        backend.get_last_run.assert_awaited_once_with("demo/hello")

    @pytest.mark.asyncio
    async def test_get_next_run_uses_current_namespace(
        self, client: CronClient, backend: AsyncMock
    ) -> None:
        """Omitting command_namespace falls back to _current_namespace."""
        await client.get_next_run()
        backend.get_next_run.assert_awaited_once_with("demo/hello")

    @pytest.mark.asyncio
    async def test_get_last_run_uses_current_namespace(
        self, client: CronClient, backend: AsyncMock
    ) -> None:
        await client.get_last_run()
        backend.get_last_run.assert_awaited_once_with("demo/hello")

    @pytest.mark.asyncio
    async def test_get_next_run_backend_returns_none(self, backend: AsyncMock) -> None:
        backend.get_next_run.return_value = None
        client = CronClient(_backend=backend, _current_namespace="demo/hello")
        result = await client.get_next_run("demo/hello")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_last_run_backend_returns_none(self, backend: AsyncMock) -> None:
        backend.get_last_run.return_value = None
        client = CronClient(_backend=backend, _current_namespace="demo/hello")
        result = await client.get_last_run("demo/hello")
        assert result is None
