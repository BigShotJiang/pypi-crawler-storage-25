"""Tests for integration clients (LLM, Email, HTTP, Telegram, Files, Secrets)."""

from __future__ import annotations

import builtins
import json
import warnings
from typing import Any, AsyncIterator
from unittest.mock import AsyncMock, MagicMock

import pytest

from huitzo_sdk import Context
from huitzo_sdk.errors import HTTPSecurityError, SecretsError, ValidationError
from huitzo_sdk.integrations.email import EmailClient
from huitzo_sdk.integrations.files import FileClient
from huitzo_sdk.integrations.http import HTTPClient
from huitzo_sdk.integrations.llm import LLMClient
from huitzo_sdk.integrations.log import DevLogBackend, LogClient
from huitzo_sdk.integrations.secrets import EnvSecretsBackend, SecretsClient
from huitzo_sdk.integrations.telegram import TelegramClient


# ---------------------------------------------------------------------------
# LLM
# ---------------------------------------------------------------------------


class TestLLMClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> LLMClient:
        return LLMClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_complete(self, client: LLMClient, backend: AsyncMock) -> None:
        backend.complete.return_value = "Hello world"
        result = await client.complete("Say hello", model="gpt-4o")
        assert result == "Hello world"
        backend.complete.assert_awaited_once()
        call_kwargs = backend.complete.call_args.kwargs
        assert call_kwargs["prompt"] == "Say hello"
        assert call_kwargs["model"] == "gpt-4o"

    @pytest.mark.asyncio
    async def test_complete_defaults(self, client: LLMClient, backend: AsyncMock) -> None:
        backend.complete.return_value = "ok"
        await client.complete("test")
        call_kwargs = backend.complete.call_args.kwargs
        assert call_kwargs["model"] == "gpt-4o-mini"
        assert call_kwargs["temperature"] == 1.0
        assert call_kwargs["system"] is None

    @pytest.mark.asyncio
    async def test_complete_with_options(self, client: LLMClient, backend: AsyncMock) -> None:
        backend.complete.return_value = "result"
        await client.complete(
            "prompt",
            model="claude-3-5-sonnet",
            system="Be helpful",
            temperature=0.5,
            max_tokens=100,
            top_p=0.9,
            stop=["\n"],
            response_format="json",
        )
        kw = backend.complete.call_args.kwargs
        assert kw["system"] == "Be helpful"
        assert kw["temperature"] == 0.5
        assert kw["max_tokens"] == 100
        assert kw["stop"] == ["\n"]
        assert kw["response_format"] == "json"

    @pytest.mark.asyncio
    async def test_stream(self) -> None:
        async def _chunks(**kwargs: Any) -> AsyncIterator[str]:
            yield "Hello "
            yield "world"

        backend = AsyncMock()
        backend.stream = _chunks
        client = LLMClient(_backend=backend)
        stream = client.stream("Say hello")
        chunks = [c async for c in stream]
        assert chunks == ["Hello ", "world"]


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------


class TestEmailClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> EmailClient:
        return EmailClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_send_basic(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send(to="user@example.com", subject="Test", body="Hello")
        backend.send.assert_awaited_once()
        kw = backend.send.call_args.kwargs
        assert kw["to"] == "user@example.com"
        assert kw["subject"] == "Test"
        assert kw["body"] == "Hello"

    @pytest.mark.asyncio
    async def test_send_html(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send(to="a@b.com", subject="S", html="<h1>Hi</h1>")
        kw = backend.send.call_args.kwargs
        assert kw["html"] == "<h1>Hi</h1>"
        assert kw["body"] is None

    @pytest.mark.asyncio
    async def test_send_multiple_recipients(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send(
            to=["a@b.com", "c@d.com"],
            subject="S",
            body="Hi",
            cc=["e@f.com"],
            bcc=["g@h.com"],
        )
        kw = backend.send.call_args.kwargs
        assert kw["to"] == ["a@b.com", "c@d.com"]
        assert kw["cc"] == ["e@f.com"]

    @pytest.mark.asyncio
    async def test_send_template(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send_template(
            to="user@example.com",
            template_id="d-abc123",
            template_data={"name": "John"},
        )
        backend.send_template.assert_awaited_once()
        kw = backend.send_template.call_args.kwargs
        assert kw["template_id"] == "d-abc123"
        assert kw["template_data"] == {"name": "John"}

    @pytest.mark.asyncio
    async def test_send_template_no_data(self, client: EmailClient, backend: AsyncMock) -> None:
        await client.send_template(to="a@b.com", template_id="t-1")
        kw = backend.send_template.call_args.kwargs
        assert kw["template_data"] is None


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------


class TestHTTPClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> HTTPClient:
        """Client with allowed domains configured (required for any request)."""
        return HTTPClient(
            _backend=backend,
            _allowed_domains=["api.example.com", "any-domain.com", "*.trusted.org"],
        )

    @pytest.fixture
    def restricted_client(self, backend: AsyncMock) -> HTTPClient:
        return HTTPClient(_backend=backend, _allowed_domains=["api.example.com", "*.trusted.org"])

    @pytest.mark.asyncio
    async def test_get(self, client: HTTPClient, backend: AsyncMock) -> None:
        backend.request.return_value = {"data": 1}
        result = await client.get("https://api.example.com/data")
        assert result == {"data": 1}
        backend.request.assert_awaited_once()
        args = backend.request.call_args
        assert args[0] == ("GET", "https://api.example.com/data")

    @pytest.mark.asyncio
    async def test_post(self, client: HTTPClient, backend: AsyncMock) -> None:
        backend.request.return_value = {"ok": True}
        result = await client.post("https://api.example.com/submit", json={"key": "val"})
        assert result == {"ok": True}
        kw = backend.request.call_args.kwargs
        assert kw["json"] == {"key": "val"}

    @pytest.mark.asyncio
    async def test_post_with_files(self, client: HTTPClient, backend: AsyncMock) -> None:
        await client.post(
            "https://api.example.com/upload",
            data={"field": "value"},
            files={"document": b"file-data"},
        )
        kw = backend.request.call_args.kwargs
        assert kw["files"] == {"document": b"file-data"}
        assert kw["data"] == {"field": "value"}

    @pytest.mark.asyncio
    async def test_put(self, client: HTTPClient, backend: AsyncMock) -> None:
        await client.put("https://api.example.com/r/1", json={"updated": True})
        args = backend.request.call_args
        assert args[0][0] == "PUT"

    @pytest.mark.asyncio
    async def test_delete(self, client: HTTPClient, backend: AsyncMock) -> None:
        await client.delete("https://api.example.com/r/1")
        args = backend.request.call_args
        assert args[0][0] == "DELETE"

    @pytest.mark.asyncio
    async def test_domain_allowed(self, restricted_client: HTTPClient, backend: AsyncMock) -> None:
        await restricted_client.get("https://api.example.com/data")
        backend.request.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_domain_wildcard_allowed(
        self, restricted_client: HTTPClient, backend: AsyncMock
    ) -> None:
        await restricted_client.get("https://sub.trusted.org/path")
        backend.request.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_domain_wildcard_nested_subdomain(self, backend: AsyncMock) -> None:
        client = HTTPClient(_backend=backend, _allowed_domains=["*.example.com"])
        await client.get("https://deep.api.example.com/path")
        backend.request.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_domain_wildcard_blocks_base_domain(self, backend: AsyncMock) -> None:
        """Wildcard *.example.com should NOT match example.com itself."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*.example.com"])
        with pytest.raises(HTTPSecurityError):
            await client.get("https://example.com/path")

    @pytest.mark.asyncio
    async def test_domain_wildcard_blocks_suffix_attack(self, backend: AsyncMock) -> None:
        """*.example.com must NOT match evilexample.com."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*.example.com"])
        with pytest.raises(HTTPSecurityError):
            await client.get("https://evilexample.com/steal")

    @pytest.mark.asyncio
    async def test_domain_blocked(self, restricted_client: HTTPClient) -> None:
        with pytest.raises(HTTPSecurityError):
            await restricted_client.get("https://evil.com/steal")

    @pytest.mark.asyncio
    async def test_empty_allowed_domains_blocks_all(self, backend: AsyncMock) -> None:
        """Empty _allowed_domains = deny-all (SSRF prevention)."""
        client = HTTPClient(_backend=backend, _allowed_domains=[])
        with pytest.raises(HTTPSecurityError, match="No allowed domains configured"):
            await client.get("https://any-domain.com/anything")

    @pytest.mark.asyncio
    async def test_http_scheme_rejected(self, backend: AsyncMock) -> None:
        """Plain HTTP must be rejected."""
        client = HTTPClient(_backend=backend, _allowed_domains=["api.example.com"])
        with pytest.raises(HTTPSecurityError, match="Only HTTPS is allowed"):
            await client.get("http://api.example.com/data")

    @pytest.mark.asyncio
    async def test_https_scheme_accepted(self, backend: AsyncMock) -> None:
        """HTTPS must be accepted."""
        client = HTTPClient(_backend=backend, _allowed_domains=["api.example.com"])
        backend.request.return_value = {"ok": True}
        result = await client.get("https://api.example.com/data")
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_localhost_allowed_with_flag(self, backend: AsyncMock) -> None:
        """http://localhost allowed when _allow_localhost=True."""
        client = HTTPClient(
            _backend=backend,
            _allowed_domains=["localhost"],
            _allow_localhost=True,
        )
        backend.request.return_value = {"ok": True}
        result = await client.get("http://localhost:8000/api")
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_localhost_blocked_without_flag(self, backend: AsyncMock) -> None:
        """http://localhost blocked when _allow_localhost=False."""
        client = HTTPClient(
            _backend=backend,
            _allowed_domains=["localhost"],
            _allow_localhost=False,
        )
        with pytest.raises(HTTPSecurityError, match="Only HTTPS is allowed"):
            await client.get("http://localhost:8000/api")

    @pytest.mark.asyncio
    async def test_ipv6_loopback_allowed_with_flag(self, backend: AsyncMock) -> None:
        """http://[::1] allowed when _allow_localhost=True."""
        client = HTTPClient(
            _backend=backend,
            _allowed_domains=["*"],
            _allow_localhost=True,
        )
        backend.request.return_value = {"ok": True}
        result = await client.get("http://[::1]:8080/api")
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_ipv6_loopback_blocked_without_flag(self, backend: AsyncMock) -> None:
        """http://[::1] blocked when _allow_localhost=False."""
        client = HTTPClient(
            _backend=backend,
            _allowed_domains=["*"],
            _allow_localhost=False,
        )
        with pytest.raises(HTTPSecurityError, match="Only HTTPS is allowed"):
            await client.get("http://[::1]:8080/api")

    @pytest.mark.asyncio
    async def test_headers_and_params(self, client: HTTPClient, backend: AsyncMock) -> None:
        await client.get(
            "https://api.example.com/data",
            headers={"Authorization": "Bearer tok"},
            params={"page": 1},
            timeout=30,
        )
        kw = backend.request.call_args.kwargs
        assert kw["headers"] == {"Authorization": "Bearer tok"}
        assert kw["params"] == {"page": 1}
        assert kw["timeout"] == 30

    @pytest.mark.asyncio
    async def test_wildcard_allows_all_domains(self, backend: AsyncMock) -> None:
        """Wildcard '*' in allowed_domains permits any HTTPS domain."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*"], _allow_localhost=True)
        backend.request.return_value = {"ok": True}
        result = await client.get("https://any-random-domain.com/path")
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_wildcard_still_enforces_https(self, backend: AsyncMock) -> None:
        """Wildcard '*' still requires HTTPS (unless localhost)."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*"], _allow_localhost=False)
        with pytest.raises(HTTPSecurityError, match="Only HTTPS is allowed"):
            await client.get("http://any-domain.com/path")

    @pytest.mark.asyncio
    async def test_wildcard_allows_localhost_http(self, backend: AsyncMock) -> None:
        """Wildcard '*' with _allow_localhost=True permits http://localhost."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*"], _allow_localhost=True)
        backend.request.return_value = {"ok": True}
        result = await client.get("http://localhost:8080/api")
        assert result == {"ok": True}

    @pytest.mark.asyncio
    @pytest.mark.parametrize(
        "domain",
        ["169.254.169.254", "metadata.google.internal", "100.100.100.200"],
    )
    async def test_metadata_endpoints_blocked_even_with_wildcard(
        self, backend: AsyncMock, domain: str
    ) -> None:
        """Cloud metadata endpoints are blocked even under wildcard mode."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*"])
        with pytest.raises(HTTPSecurityError, match="metadata"):
            await client.get(f"https://{domain}/latest/meta-data/")

    @pytest.mark.asyncio
    async def test_domain_not_allowed_includes_allowed_list(self, backend: AsyncMock) -> None:
        """HTTPSecurityError includes allowed_domains list."""
        client = HTTPClient(_backend=backend, _allowed_domains=["good.com", "safe.org"])
        with pytest.raises(HTTPSecurityError) as exc_info:
            await client.get("https://evil.com/steal")
        assert exc_info.value.allowed_domains == ["good.com", "safe.org"]

    @pytest.mark.asyncio
    async def test_malformed_url_no_hostname_raises(self, backend: AsyncMock) -> None:
        """A URL with no hostname (e.g. 'https:///path') raises HTTPSecurityError."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*"])
        with pytest.raises(HTTPSecurityError, match="no valid hostname"):
            await client.get("https:///path")
        backend.request.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_wildcard_does_not_bypass_empty_domain(self, backend: AsyncMock) -> None:
        """Wildcard '*' must not bypass the empty-hostname guard."""
        client = HTTPClient(_backend=backend, _allowed_domains=["*"])
        with pytest.raises(HTTPSecurityError):
            await client.get("https:///admin")


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------


class TestTelegramClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> TelegramClient:
        return TelegramClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_send(self, client: TelegramClient, backend: AsyncMock) -> None:
        await client.send(chat_id="123", message="Hello")
        backend.send.assert_awaited_once()
        kw = backend.send.call_args.kwargs
        assert kw["chat_id"] == "123"
        assert kw["message"] == "Hello"
        assert kw["parse_mode"] is None

    @pytest.mark.asyncio
    async def test_send_with_parse_mode(self, client: TelegramClient, backend: AsyncMock) -> None:
        await client.send(chat_id="123", message="*bold*", parse_mode="Markdown")
        kw = backend.send.call_args.kwargs
        assert kw["parse_mode"] == "Markdown"

    @pytest.mark.asyncio
    async def test_send_document(self, client: TelegramClient, backend: AsyncMock) -> None:
        await client.send_document(
            chat_id="123", document=b"pdf-data", filename="report.pdf", caption="Report"
        )
        backend.send_document.assert_awaited_once()
        kw = backend.send_document.call_args.kwargs
        assert kw["filename"] == "report.pdf"

    @pytest.mark.asyncio
    async def test_send_photo(self, client: TelegramClient, backend: AsyncMock) -> None:
        await client.send_photo(chat_id="123", photo=b"img-data", caption="Chart")
        backend.send_photo.assert_awaited_once()


# ---------------------------------------------------------------------------
# Files
# ---------------------------------------------------------------------------


class TestFileClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> FileClient:
        return FileClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_read_json(self, client: FileClient, backend: AsyncMock) -> None:
        backend.read.return_value = json.dumps({"key": "val"}).encode()
        result = await client.read_json("data.json")
        assert result == {"key": "val"}

    @pytest.mark.asyncio
    async def test_read_json_invalid_raises_validation_error(
        self, client: FileClient, backend: AsyncMock
    ) -> None:
        """read_json must raise ValidationError (not json.JSONDecodeError) for malformed files."""
        backend.read.return_value = b"not valid json {"
        with pytest.raises(ValidationError, match="invalid JSON"):
            await client.read_json("broken.json")

    @pytest.mark.asyncio
    async def test_write_string(self, client: FileClient, backend: AsyncMock) -> None:
        await client.write("out.txt", "hello")
        backend.write.assert_awaited_once()
        args = backend.write.call_args
        assert args[0] == ("out.txt", b"hello")

    @pytest.mark.asyncio
    async def test_write_bytes(self, client: FileClient, backend: AsyncMock) -> None:
        await client.write("out.bin", b"\x00\x01", binary=True)
        args = backend.write.call_args
        assert args[0] == ("out.bin", b"\x00\x01")

    @pytest.mark.asyncio
    async def test_info(self, client: FileClient, backend: AsyncMock) -> None:
        backend.info.return_value = {"size": 1024, "type": "json"}
        result = await client.info("data.json")
        assert result["size"] == 1024

    @pytest.mark.asyncio
    async def test_list(self, client: FileClient, backend: AsyncMock) -> None:
        backend.list.return_value = [{"name": "a.csv"}, {"name": "b.csv"}]
        result = await client.list("uploads/")
        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_exists(self, client: FileClient, backend: AsyncMock) -> None:
        backend.exists.return_value = True
        assert await client.exists("data.json") is True

    @pytest.mark.asyncio
    async def test_get_url(self, client: FileClient, backend: AsyncMock) -> None:
        backend.get_url.return_value = "https://cdn.example.com/file?sig=abc"
        url = await client.get_url("report.pdf", expires=7200)
        assert "cdn.example.com" in url
        backend.get_url.assert_awaited_once_with("report.pdf", expires=7200)

    @pytest.mark.asyncio
    async def test_read_excel_requires_pandas(
        self, client: FileClient, backend: AsyncMock, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """read_excel raises ImportError when pandas is not installed."""
        backend.read.return_value = b"fake-excel-data"
        real_import = builtins.__import__

        def _mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
            if name == "pandas":
                raise ImportError("No module named 'pandas'")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", _mock_import)
        with pytest.raises(ImportError, match="pandas is required"):
            await client.read_excel("test.xlsx")

    @pytest.mark.asyncio
    async def test_read_csv_requires_pandas(
        self, client: FileClient, backend: AsyncMock, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """read_csv raises ImportError when pandas is not installed."""
        backend.read.return_value = b"a,b\n1,2"
        real_import = builtins.__import__

        def _mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
            if name == "pandas":
                raise ImportError("No module named 'pandas'")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", _mock_import)
        with pytest.raises(ImportError, match="pandas is required"):
            await client.read_csv("test.csv")


# ---------------------------------------------------------------------------
# File path traversal tests
# ---------------------------------------------------------------------------


class TestFilePathTraversal:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> FileClient:
        return FileClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_path_traversal_rejected(self, client: FileClient) -> None:
        with pytest.raises(ValidationError, match="Path traversal not allowed"):
            await client.read_json("../../etc/passwd")

    @pytest.mark.asyncio
    async def test_absolute_path_rejected(self, client: FileClient) -> None:
        with pytest.raises(ValidationError, match="Absolute paths not allowed"):
            await client.read_json("/etc/passwd")

    @pytest.mark.asyncio
    async def test_null_byte_rejected(self, client: FileClient) -> None:
        with pytest.raises(ValidationError, match="Path contains null bytes"):
            await client.read_json("file\x00.json")

    @pytest.mark.asyncio
    async def test_valid_relative_path(self, client: FileClient, backend: AsyncMock) -> None:
        backend.read.return_value = b'{"ok": true}'
        result = await client.read_json("uploads/report.json")
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_nested_relative_path(self, client: FileClient, backend: AsyncMock) -> None:
        backend.read.return_value = b'{"ok": true}'
        result = await client.read_json("data/2026/q1.json")
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_traversal_rejected_in_write(self, client: FileClient) -> None:
        with pytest.raises(ValidationError, match="Path traversal not allowed"):
            await client.write("../escape.txt", "data")

    @pytest.mark.asyncio
    async def test_traversal_rejected_in_exists(self, client: FileClient) -> None:
        with pytest.raises(ValidationError, match="Path traversal not allowed"):
            await client.exists("../../etc/passwd")

    @pytest.mark.asyncio
    async def test_traversal_rejected_in_info(self, client: FileClient) -> None:
        with pytest.raises(ValidationError, match="Path traversal not allowed"):
            await client.info("../secret.txt")

    @pytest.mark.asyncio
    async def test_backslash_traversal_rejected(self, client: FileClient) -> None:
        with pytest.raises(ValidationError, match="Path traversal not allowed"):
            await client.read_json("uploads\\..\\etc\\passwd")


# ---------------------------------------------------------------------------
# Secrets
# ---------------------------------------------------------------------------


class TestSecretsClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        return AsyncMock()

    @pytest.fixture
    def client(self, backend: AsyncMock) -> SecretsClient:
        return SecretsClient(_backend=backend)

    @pytest.mark.asyncio
    async def test_require_returns_value(self, client: SecretsClient, backend: AsyncMock) -> None:
        backend.get.return_value = "my-secret"
        result = await client.require("API_KEY")
        assert result == "my-secret"
        backend.get.assert_awaited_once_with("API_KEY")

    @pytest.mark.asyncio
    async def test_require_raises_secrets_error_when_missing(
        self, client: SecretsClient, backend: AsyncMock
    ) -> None:
        backend.get.return_value = None
        with pytest.raises(SecretsError) as exc_info:
            await client.require("MISSING_KEY")
        assert exc_info.value.secret_name == "MISSING_KEY"

    @pytest.mark.asyncio
    async def test_get_returns_value(self, client: SecretsClient, backend: AsyncMock) -> None:
        backend.get.return_value = "val"
        result = await client.get("KEY")
        assert result == "val"

    @pytest.mark.asyncio
    async def test_get_returns_none_when_missing(
        self, client: SecretsClient, backend: AsyncMock
    ) -> None:
        backend.get.return_value = None
        result = await client.get("KEY")
        assert result is None

    @pytest.mark.asyncio
    async def test_exists_true(self, client: SecretsClient, backend: AsyncMock) -> None:
        backend.get.return_value = "value"
        assert await client.exists("KEY") is True

    @pytest.mark.asyncio
    async def test_exists_false(self, client: SecretsClient, backend: AsyncMock) -> None:
        backend.get.return_value = None
        assert await client.exists("KEY") is False


class TestEnvSecretsBackend:
    @pytest.mark.asyncio
    async def test_get_returns_env_value(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("HUITZO_SECRET_MY_KEY", "secret123")
        backend = EnvSecretsBackend()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = await backend.get("MY_KEY")
        assert result == "secret123"

    @pytest.mark.asyncio
    async def test_get_returns_none_when_missing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("HUITZO_SECRET_ABSENT_KEY", raising=False)
        backend = EnvSecretsBackend()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = await backend.get("ABSENT_KEY")
        assert result is None

    @pytest.mark.asyncio
    async def test_warns_on_first_use(self) -> None:
        backend = EnvSecretsBackend()
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            await backend.get("KEY")
        assert len(w) == 1
        assert "ENV fallback mode" in str(w[0].message)

    @pytest.mark.asyncio
    async def test_warns_only_once(self) -> None:
        backend = EnvSecretsBackend()
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            await backend.get("KEY1")
            await backend.get("KEY2")
        assert len(w) == 1


# ---------------------------------------------------------------------------
# Context wiring
# ---------------------------------------------------------------------------


class TestContextWiring:
    @pytest.mark.asyncio
    async def test_wired_llm(self) -> None:
        backend = AsyncMock()
        backend.complete.return_value = "hi"
        client = LLMClient(_backend=backend)
        ctx = Context(_llm=client)
        result = await ctx.llm.complete("test")
        assert result == "hi"

    @pytest.mark.asyncio
    async def test_wired_email(self) -> None:
        backend = AsyncMock()
        client = EmailClient(_backend=backend)
        ctx = Context(_email=client)
        await ctx.email.send(to="a@b.com", subject="S", body="B")
        backend.send.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_wired_http(self) -> None:
        backend = AsyncMock()
        backend.request.return_value = {"ok": True}
        client = HTTPClient(
            _backend=backend,
            _allowed_domains=["example.com"],
        )
        ctx = Context(_http=client)
        result = await ctx.http.get("https://example.com")
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_wired_telegram(self) -> None:
        backend = AsyncMock()
        client = TelegramClient(_backend=backend)
        ctx = Context(_telegram=client)
        await ctx.telegram.send(chat_id="1", message="hi")
        backend.send.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_wired_files(self) -> None:
        backend = AsyncMock()
        backend.exists.return_value = True
        client = FileClient(_backend=backend)
        ctx = Context(_files=client)
        assert await ctx.files.exists("test.txt") is True

    @pytest.mark.asyncio
    async def test_wired_secrets(self) -> None:
        backend = AsyncMock()
        backend.get.return_value = "secret-value"
        from huitzo_sdk.integrations.secrets import SecretsClient

        client = SecretsClient(_backend=backend)
        ctx = Context(_secrets=client)
        result = await ctx.secrets.require("MY_KEY")
        assert result == "secret-value"
        backend.get.assert_awaited_once_with("MY_KEY")

    def test_wired_log(self) -> None:
        backend = MagicMock()
        client = LogClient(_backend=backend)
        ctx = Context(_log=client)
        ctx.log.info("hello", key="value")
        backend.info.assert_called_once_with("hello", key="value")


# ---------------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------------


class TestLogClient:
    @pytest.fixture
    def backend(self) -> MagicMock:
        return MagicMock()

    @pytest.fixture
    def client(self, backend: MagicMock) -> LogClient:
        return LogClient(_backend=backend)

    def test_info(self, client: LogClient, backend: MagicMock) -> None:
        client.info("Session created", session_id="abc123")
        backend.info.assert_called_once_with("Session created", session_id="abc123")

    def test_error(self, client: LogClient, backend: MagicMock) -> None:
        client.error("LLM call failed", error="timeout")
        backend.error.assert_called_once_with("LLM call failed", error="timeout")

    def test_warning(self, client: LogClient, backend: MagicMock) -> None:
        client.warning("Retry attempt", attempt=2)
        backend.warning.assert_called_once_with("Retry attempt", attempt=2)

    def test_debug(self, client: LogClient, backend: MagicMock) -> None:
        client.debug("Checkpoint reached", step="preprocess")
        backend.debug.assert_called_once_with("Checkpoint reached", step="preprocess")

    def test_no_kwargs(self, client: LogClient, backend: MagicMock) -> None:
        client.info("simple message")
        backend.info.assert_called_once_with("simple message")

    def test_sensitive_field_redacted_in_debug(self, client: LogClient, backend: MagicMock) -> None:
        client.debug("auth attempt", api_key="sk-real-key")
        backend.debug.assert_called_once_with("auth attempt", api_key="<redacted>")

    def test_sensitive_field_redacted_in_info(self, client: LogClient, backend: MagicMock) -> None:
        client.info("user login", password="s3cr3t", user_id="u1")
        backend.info.assert_called_once_with("user login", password="<redacted>", user_id="u1")

    def test_sensitive_field_redacted_in_warning(
        self, client: LogClient, backend: MagicMock
    ) -> None:
        client.warning("token refresh", token="tok-abc")
        backend.warning.assert_called_once_with("token refresh", token="<redacted>")

    def test_sensitive_field_redacted_in_error(self, client: LogClient, backend: MagicMock) -> None:
        client.error("secret leak", secret="my-secret")
        backend.error.assert_called_once_with("secret leak", secret="<redacted>")

    def test_non_sensitive_fields_pass_through(self, client: LogClient, backend: MagicMock) -> None:
        client.info("request processed", session_id="sid123", status=200)
        backend.info.assert_called_once_with("request processed", session_id="sid123", status=200)

    def test_multiple_sensitive_fields_all_redacted(
        self, client: LogClient, backend: MagicMock
    ) -> None:
        client.debug("multi", api_key="k1", token="t1", user="alice")
        backend.debug.assert_called_once_with(
            "multi", api_key="<redacted>", token="<redacted>", user="alice"
        )


class TestDevLogBackend:
    @pytest.fixture
    def backend(self) -> DevLogBackend:
        return DevLogBackend()

    def test_info_writes_json_to_stderr(
        self, backend: DevLogBackend, capsys: pytest.CaptureFixture[str]
    ) -> None:
        backend.info("test message", user_id="u1")
        captured = capsys.readouterr()
        entry = json.loads(captured.err)
        assert entry["level"] == "info"
        assert entry["message"] == "test message"
        assert entry["user_id"] == "u1"

    def test_error_writes_json_to_stderr(
        self, backend: DevLogBackend, capsys: pytest.CaptureFixture[str]
    ) -> None:
        backend.error("something failed", code=500)
        captured = capsys.readouterr()
        entry = json.loads(captured.err)
        assert entry["level"] == "error"
        assert entry["message"] == "something failed"
        assert entry["code"] == 500

    def test_warning_level(
        self, backend: DevLogBackend, capsys: pytest.CaptureFixture[str]
    ) -> None:
        backend.warning("slow response")
        entry = json.loads(capsys.readouterr().err)
        assert entry["level"] == "warning"

    def test_debug_level(self, backend: DevLogBackend, capsys: pytest.CaptureFixture[str]) -> None:
        backend.debug("internal state")
        entry = json.loads(capsys.readouterr().err)
        assert entry["level"] == "debug"

    def test_writes_to_stderr_not_stdout(
        self, backend: DevLogBackend, capsys: pytest.CaptureFixture[str]
    ) -> None:
        backend.info("check stderr")
        captured = capsys.readouterr()
        assert captured.out == ""
        assert captured.err != ""

    def test_non_serializable_values_use_str(
        self, backend: DevLogBackend, capsys: pytest.CaptureFixture[str]
    ) -> None:
        class _Custom:
            def __str__(self) -> str:
                return "custom-repr"

        backend.info("with object", obj=_Custom())
        entry = json.loads(capsys.readouterr().err)
        assert entry["obj"] == "custom-repr"

    def test_satisfies_log_backend_protocol(self, backend: DevLogBackend) -> None:
        from huitzo_sdk.integrations.log import LogBackend

        assert isinstance(backend, LogBackend)
