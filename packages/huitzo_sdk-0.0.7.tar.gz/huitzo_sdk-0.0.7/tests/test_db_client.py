"""Tests for the DBClient — manifest allowlist, DDL gating, timeout caps, transactions."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any
from unittest.mock import AsyncMock

import pytest

from huitzo_sdk.errors import DatabaseError
from huitzo_sdk.integrations.db import (
    DEFAULT_QUERY_TIMEOUT,
    MAX_QUERY_TIMEOUT,
    DBClient,
    DBIntegrationConfig,
    DBTransaction,
)


def _make_target(
    name: str = "primary",
    *,
    integration_type: str = "postgres",
    allow_ddl: bool = False,
    row_limit: int = 10_000,
) -> DBIntegrationConfig:
    return DBIntegrationConfig(
        integration_id=f"int-{name}",
        name=name,
        type=integration_type,
        host="db.example.com",
        port=5432 if integration_type == "postgres" else 3306,
        database="appdb",
        username="app",
        password="hunter2",
        sslmode="require" if integration_type == "postgres" else None,
        ssl_ca=None,
        allow_ddl=allow_ddl,
        row_limit=row_limit,
    )


class _FakeTxnBackend:
    def __init__(self) -> None:
        self.queries: list[tuple[str, tuple[Any, ...]]] = []
        self.executes: list[tuple[str, tuple[Any, ...]]] = []

    async def query(
        self,
        sql: str,
        params: tuple[Any, ...],
        *,
        timeout: int,
        row_limit: int,
    ) -> list[dict[str, Any]]:
        self.queries.append((sql, params))
        return [{"id": 1}]

    async def execute(
        self,
        sql: str,
        params: tuple[Any, ...],
        *,
        timeout: int,
    ) -> int:
        self.executes.append((sql, params))
        return 1


class _FakeBackend:
    def __init__(self) -> None:
        self.query_calls: list[tuple[str, tuple[Any, ...], int, int]] = []
        self.execute_calls: list[tuple[str, tuple[Any, ...], int]] = []
        self.txn_backend: _FakeTxnBackend | None = None
        self.txn_committed = False

    async def query(
        self,
        target: DBIntegrationConfig,
        sql: str,
        params: tuple[Any, ...],
        *,
        timeout: int,
        row_limit: int,
    ) -> list[dict[str, Any]]:
        self.query_calls.append((sql, params, timeout, row_limit))
        return [{"id": 1, "name": "alice"}]

    async def execute(
        self,
        target: DBIntegrationConfig,
        sql: str,
        params: tuple[Any, ...],
        *,
        timeout: int,
    ) -> int:
        self.execute_calls.append((sql, params, timeout))
        return 1

    @asynccontextmanager
    async def transaction(
        self,
        target: DBIntegrationConfig,
        *,
        timeout: int,
    ) -> AsyncIterator[_FakeTxnBackend]:
        self.txn_backend = _FakeTxnBackend()
        yield self.txn_backend
        self.txn_committed = True


@pytest.fixture
def backend() -> _FakeBackend:
    return _FakeBackend()


@pytest.fixture
def client(backend: _FakeBackend) -> DBClient:
    return DBClient(
        _backend=backend,
        _targets={
            "primary": _make_target("primary"),
            "warehouse": _make_target("warehouse", integration_type="mysql"),
        },
        _allowed_integrations=["primary", "warehouse"],
    )


class TestDBClientAllowlist:
    @pytest.mark.asyncio
    async def test_query_allowed(self, client: DBClient, backend: _FakeBackend) -> None:
        rows = await client.query("primary", "SELECT 1")
        assert rows == [{"id": 1, "name": "alice"}]
        assert len(backend.query_calls) == 1

    @pytest.mark.asyncio
    async def test_integration_not_in_allowlist(self, backend: _FakeBackend) -> None:
        client = DBClient(
            _backend=backend,
            _targets={"primary": _make_target("primary")},
            _allowed_integrations=["other"],
        )
        with pytest.raises(DatabaseError, match="not allowed"):
            await client.query("primary", "SELECT 1")
        assert backend.query_calls == []

    @pytest.mark.asyncio
    async def test_empty_allowlist_denies(self, backend: _FakeBackend) -> None:
        client = DBClient(
            _backend=backend,
            _targets={"primary": _make_target("primary")},
            _allowed_integrations=[],
        )
        with pytest.raises(DatabaseError, match="no DB integrations"):
            await client.query("primary", "SELECT 1")

    @pytest.mark.asyncio
    async def test_wildcard_allowlist(self, backend: _FakeBackend) -> None:
        client = DBClient(
            _backend=backend,
            _targets={"primary": _make_target("primary")},
            _allowed_integrations=["*"],
        )
        await client.query("primary", "SELECT 1")
        assert len(backend.query_calls) == 1

    @pytest.mark.asyncio
    async def test_target_not_found(self, backend: _FakeBackend) -> None:
        client = DBClient(
            _backend=backend,
            _targets={},
            _allowed_integrations=["*"],
        )
        with pytest.raises(DatabaseError, match="not found"):
            await client.query("missing", "SELECT 1")


class TestDBClientDDLGate:
    @pytest.mark.parametrize(
        "stmt",
        [
            "CREATE TABLE foo (id int)",
            "drop table foo",
            "  ALTER TABLE foo ADD COLUMN bar int",
            "TRUNCATE foo",
            "RENAME TABLE foo TO bar",
            "GRANT SELECT ON foo TO app",
            "REVOKE ALL ON foo FROM app",
            "COMMENT ON TABLE foo IS 'x'",
        ],
    )
    @pytest.mark.asyncio
    async def test_ddl_rejected_by_default(
        self, client: DBClient, backend: _FakeBackend, stmt: str
    ) -> None:
        with pytest.raises(DatabaseError, match="DDL"):
            await client.query("primary", stmt)
        assert backend.query_calls == []

    @pytest.mark.asyncio
    async def test_ddl_allowed_when_configured(self, backend: _FakeBackend) -> None:
        client = DBClient(
            _backend=backend,
            _targets={"primary": _make_target("primary", allow_ddl=True)},
            _allowed_integrations=["primary"],
        )
        await client.execute("primary", "CREATE TABLE foo (id int)")
        assert len(backend.execute_calls) == 1

    @pytest.mark.asyncio
    async def test_ddl_check_runs_on_execute(self, client: DBClient, backend: _FakeBackend) -> None:
        with pytest.raises(DatabaseError, match="DDL"):
            await client.execute("primary", "DROP TABLE foo")
        assert backend.execute_calls == []

    @pytest.mark.asyncio
    async def test_select_with_create_in_string_allowed(
        self, client: DBClient, backend: _FakeBackend
    ) -> None:
        """Embedded substrings don't trigger the DDL gate — only leading keywords."""
        await client.query("primary", "SELECT 'CREATE TABLE x' AS s")
        assert len(backend.query_calls) == 1

    @pytest.mark.parametrize(
        "stmt",
        [
            "/* hint */ DROP TABLE x",
            "/* multi\nline */CREATE TABLE x (id int)",
            "-- comment\nDROP TABLE x",
            "-- one\n--two\nALTER TABLE foo",
            "  /* a */ /* b */ TRUNCATE foo",
        ],
    )
    @pytest.mark.asyncio
    async def test_ddl_hidden_behind_comments_rejected(
        self, client: DBClient, backend: _FakeBackend, stmt: str
    ) -> None:
        """SQL comments must not bypass the DDL gate (security regression test)."""
        with pytest.raises(DatabaseError, match="DDL"):
            await client.query("primary", stmt)
        assert backend.query_calls == []

    @pytest.mark.parametrize(
        "stmt",
        [
            "INSERT INTO t VALUES (1); DROP TABLE users",
            "SELECT 1; SELECT 2",
            "UPDATE t SET x = 1; SELECT pg_sleep(60)",
            "INSERT INTO t VALUES (1);DROP TABLE x",
        ],
    )
    @pytest.mark.asyncio
    async def test_multi_statement_rejected(
        self, client: DBClient, backend: _FakeBackend, stmt: str
    ) -> None:
        """Multi-statement payloads must be rejected — aiomysql leaves CLIENT.MULTI_STATEMENTS on."""
        with pytest.raises(DatabaseError, match="multi-statement"):
            await client.query("primary", stmt)
        assert backend.query_calls == []

    @pytest.mark.parametrize(
        "stmt",
        [
            "SELECT 1;",
            "SELECT 1;   ",
            "SELECT 1;\n",
            "SELECT ';' AS s",
            'SELECT ";" AS s',
            "SELECT 'foo;bar' AS s",
        ],
    )
    @pytest.mark.asyncio
    async def test_single_statement_with_quoted_or_trailing_semicolon_allowed(
        self, client: DBClient, backend: _FakeBackend, stmt: str
    ) -> None:
        """A trailing ; is OK; ; inside string literals is not a terminator."""
        await client.query("primary", stmt)
        assert len(backend.query_calls) == 1


class TestDBClientTimeouts:
    @pytest.mark.asyncio
    async def test_default_timeout(self, client: DBClient, backend: _FakeBackend) -> None:
        await client.query("primary", "SELECT 1")
        assert backend.query_calls[0][2] == DEFAULT_QUERY_TIMEOUT

    @pytest.mark.asyncio
    async def test_explicit_timeout(self, client: DBClient, backend: _FakeBackend) -> None:
        await client.query("primary", "SELECT 1", timeout=60)
        assert backend.query_calls[0][2] == 60

    @pytest.mark.asyncio
    async def test_zero_timeout_rejected(self, client: DBClient) -> None:
        with pytest.raises(DatabaseError, match="positive"):
            await client.query("primary", "SELECT 1", timeout=0)

    @pytest.mark.asyncio
    async def test_negative_timeout_rejected(self, client: DBClient) -> None:
        with pytest.raises(DatabaseError, match="positive"):
            await client.execute("primary", "INSERT INTO foo VALUES (1)", timeout=-1)

    @pytest.mark.asyncio
    async def test_excessive_timeout_rejected(self, client: DBClient) -> None:
        with pytest.raises(DatabaseError, match="maximum"):
            await client.query("primary", "SELECT 1", timeout=MAX_QUERY_TIMEOUT + 1)


class TestDBClientSQLValidation:
    @pytest.mark.asyncio
    async def test_empty_sql_rejected(self, client: DBClient) -> None:
        with pytest.raises(DatabaseError, match="non-empty"):
            await client.query("primary", "")

    @pytest.mark.asyncio
    async def test_whitespace_sql_rejected(self, client: DBClient) -> None:
        with pytest.raises(DatabaseError, match="non-empty"):
            await client.execute("primary", "   \t\n  ")

    @pytest.mark.asyncio
    async def test_null_byte_rejected(self, client: DBClient) -> None:
        with pytest.raises(DatabaseError, match="null bytes"):
            await client.query("primary", "SELECT 1\x00")


class TestDBClientParams:
    @pytest.mark.asyncio
    async def test_params_passed_through_to_backend(
        self, client: DBClient, backend: _FakeBackend
    ) -> None:
        await client.query("primary", "SELECT * FROM users WHERE id = $1", 42)
        sql, params, _, _ = backend.query_calls[0]
        assert sql == "SELECT * FROM users WHERE id = $1"
        assert params == (42,)

    @pytest.mark.asyncio
    async def test_no_params_yields_empty_tuple(
        self, client: DBClient, backend: _FakeBackend
    ) -> None:
        await client.execute("primary", "DELETE FROM users")
        _, params, _ = backend.execute_calls[0]
        assert params == ()


class TestDBClientRowLimit:
    @pytest.mark.asyncio
    async def test_row_limit_passed_to_backend(self, backend: _FakeBackend) -> None:
        client = DBClient(
            _backend=backend,
            _targets={"primary": _make_target("primary", row_limit=500)},
            _allowed_integrations=["primary"],
        )
        await client.query("primary", "SELECT * FROM users")
        assert backend.query_calls[0][3] == 500


class TestDBClientTransactions:
    @pytest.mark.asyncio
    async def test_transaction_yields_handle(self, client: DBClient, backend: _FakeBackend) -> None:
        async with client.transaction("primary") as txn:
            assert isinstance(txn, DBTransaction)
            rows = await txn.query("SELECT 1")
            assert rows == [{"id": 1}]
            await txn.execute("INSERT INTO foo VALUES (1)")
        assert backend.txn_committed
        assert backend.txn_backend is not None
        assert backend.txn_backend.queries == [("SELECT 1", ())]
        assert backend.txn_backend.executes == [("INSERT INTO foo VALUES (1)", ())]

    @pytest.mark.asyncio
    async def test_transaction_enforces_allowlist(self, backend: _FakeBackend) -> None:
        client = DBClient(
            _backend=backend,
            _targets={"primary": _make_target("primary")},
            _allowed_integrations=["other"],
        )
        with pytest.raises(DatabaseError, match="not allowed"):
            async with client.transaction("primary"):
                pass

    @pytest.mark.asyncio
    async def test_transaction_enforces_ddl_gate(
        self, client: DBClient, backend: _FakeBackend
    ) -> None:
        async with client.transaction("primary") as txn:
            with pytest.raises(DatabaseError, match="DDL"):
                await txn.execute("DROP TABLE foo")


class TestDBIntegrationConfigRedaction:
    def test_repr_redacts_password(self) -> None:
        config = _make_target("primary")
        text = repr(config)
        assert "hunter2" not in text
        assert "<redacted>" in text


class TestDatabaseError:
    def test_carries_integration_name(self) -> None:
        err = DatabaseError(integration="primary", message="boom")
        assert err.integration == "primary"
        assert err.service == "db:primary"

    def test_empty_integration_uses_generic_service(self) -> None:
        err = DatabaseError(message="boom")
        assert err.service == "db"


class TestDBClientWithMockedBackend:
    @pytest.mark.asyncio
    async def test_async_mock_compatible(self) -> None:
        mock = AsyncMock()
        mock.query.return_value = [{"x": 1}]
        client = DBClient(
            _backend=mock,
            _targets={"primary": _make_target("primary")},
            _allowed_integrations=["*"],
        )
        rows = await client.query("primary", "SELECT 1")
        assert rows == [{"x": 1}]
