"""Tests for the CommandsClient intra-pack command execution service."""

import asyncio

import pytest

from huitzo_sdk.commands_service import CommandsClient, MAX_CALL_DEPTH
from huitzo_sdk.errors import (
    CircularCommandError,
    CommandError,
    CommandNotFoundError,
    CommandTimeoutError,
    ConfigurationError,
    MaxCallDepthError,
    StorageError,
)


class FakeBackend:
    """In-memory backend for testing."""

    def __init__(self) -> None:
        self.commands: dict[str, object] = {}
        self.timeouts: dict[str, int] = {}

    def register(self, name: str, func: object, timeout: int = 60) -> None:
        self.commands[name] = func
        self.timeouts[name] = timeout

    def resolve(self, command_name: str) -> object | None:
        return self.commands.get(command_name)

    def get_timeout(self, command_name: str) -> int:
        return self.timeouts.get(command_name, 60)


def _make_client(
    backend: FakeBackend | None = None,
    namespace: str = "@test/pack",
    parent_timeout: float | None = None,
) -> CommandsClient:
    b = backend or FakeBackend()
    client = CommandsClient(
        _backend=b,
        _namespace=namespace,
        _parent_timeout=parent_timeout,
    )
    # Set a dummy context (child commands receive this)
    client._context = object()
    return client


class TestContextGuard:
    @pytest.mark.asyncio
    async def test_execute_raises_when_context_is_none(self) -> None:
        """execute() must raise ConfigurationError before any command resolution when _context is None."""
        backend = FakeBackend()

        async def noop(args: dict, ctx: object) -> dict:
            return {}

        backend.register("noop", noop)
        client = CommandsClient(_backend=backend, _namespace="@test/pack")
        # _context is None (not injected)

        with pytest.raises(ConfigurationError, match="context"):
            await client.execute("noop", {})

    @pytest.mark.asyncio
    async def test_execute_raises_context_error_before_command_resolution(self) -> None:
        """ConfigurationError from missing context fires even for non-existent commands."""
        client = CommandsClient(_backend=FakeBackend(), _namespace="@test/pack")

        with pytest.raises(ConfigurationError):
            await client.execute("no-such-command", {})


class TestCommandsClientHappyPath:
    @pytest.mark.asyncio
    async def test_execute_returns_result(self) -> None:
        backend = FakeBackend()

        async def greet(args: dict, ctx: object) -> dict:
            return {"greeting": f"hello {args['name']}"}

        backend.register("greet", greet)
        client = _make_client(backend)

        result = await client.execute("greet", {"name": "world"})
        assert result == {"greeting": "hello world"}

    @pytest.mark.asyncio
    async def test_execute_passes_parent_context(self) -> None:
        backend = FakeBackend()
        received_ctx = None

        async def capture_ctx(args: dict, ctx: object) -> dict:
            nonlocal received_ctx
            received_ctx = ctx
            return {}

        backend.register("capture", capture_ctx)
        client = _make_client(backend)
        sentinel = object()
        client._context = sentinel

        await client.execute("capture", {})
        assert received_ctx is sentinel

    @pytest.mark.asyncio
    async def test_call_stack_cleaned_after_success(self) -> None:
        backend = FakeBackend()

        async def noop(args: dict, ctx: object) -> dict:
            return {}

        backend.register("noop", noop)
        client = _make_client(backend)

        await client.execute("noop", {})
        assert client._call_stack == []


class TestCommandNotFound:
    @pytest.mark.asyncio
    async def test_raises_command_not_found(self) -> None:
        client = _make_client()
        with pytest.raises(CommandNotFoundError, match="no-such-cmd"):
            await client.execute("no-such-cmd", {})

    @pytest.mark.asyncio
    async def test_error_has_fields(self) -> None:
        client = _make_client(namespace="@acme/claims")
        with pytest.raises(CommandNotFoundError) as exc_info:
            await client.execute("missing", {})
        assert exc_info.value.command_name == "missing"
        assert exc_info.value.pack_namespace == "@acme/claims"


class TestCircularDetection:
    @pytest.mark.asyncio
    async def test_direct_circular_call(self) -> None:
        backend = FakeBackend()
        client = _make_client(backend)

        async def recursive(args: dict, ctx: object) -> dict:
            return await client.execute("recursive", {})

        backend.register("recursive", recursive)

        with pytest.raises(CircularCommandError, match="recursive"):
            await client.execute("recursive", {})

    @pytest.mark.asyncio
    async def test_indirect_circular_call(self) -> None:
        backend = FakeBackend()
        client = _make_client(backend)

        async def cmd_a(args: dict, ctx: object) -> dict:
            return await client.execute("cmd-b", {})

        async def cmd_b(args: dict, ctx: object) -> dict:
            return await client.execute("cmd-a", {})

        backend.register("cmd-a", cmd_a)
        backend.register("cmd-b", cmd_b)

        with pytest.raises(CircularCommandError):
            await client.execute("cmd-a", {})

    @pytest.mark.asyncio
    async def test_max_depth_exceeded(self) -> None:
        backend = FakeBackend()
        client = _make_client(backend)

        # Pre-fill call stack to max depth
        client._call_stack = [f"cmd-{i}" for i in range(MAX_CALL_DEPTH)]

        async def deep(args: dict, ctx: object) -> dict:
            return {}

        backend.register("deep", deep)

        with pytest.raises(MaxCallDepthError) as exc_info:
            await client.execute("deep", {})
        assert exc_info.value.max_depth == MAX_CALL_DEPTH
        assert exc_info.value.command == "deep"

    @pytest.mark.asyncio
    async def test_max_depth_not_confused_with_circular(self) -> None:
        """Depth exhaustion with no repeated command is MaxCallDepthError, not CircularCommandError."""
        backend = FakeBackend()
        client = _make_client(backend)

        # All unique commands — no circular call — but stack is full
        client._call_stack = [f"unique-cmd-{i}" for i in range(MAX_CALL_DEPTH)]

        async def new_cmd(args: dict, ctx: object) -> dict:
            return {}

        backend.register("new-cmd", new_cmd)

        with pytest.raises(MaxCallDepthError):
            await client.execute("new-cmd", {})

    @pytest.mark.asyncio
    async def test_call_stack_cleaned_after_error(self) -> None:
        backend = FakeBackend()

        async def fail(args: dict, ctx: object) -> dict:
            raise ValueError("boom")

        backend.register("fail", fail)
        client = _make_client(backend)

        with pytest.raises(CommandError):
            await client.execute("fail", {})

        assert client._call_stack == []


class TestTimeoutBudget:
    @pytest.mark.asyncio
    async def test_no_parent_timeout_uses_inner(self) -> None:
        backend = FakeBackend()

        async def fast(args: dict, ctx: object) -> dict:
            return {"ok": True}

        backend.register("fast", fast, timeout=30)
        client = _make_client(backend, parent_timeout=None)

        result = await client.execute("fast", {})
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_budget_exhausted_raises_timeout(self) -> None:
        backend = FakeBackend()

        async def slow(args: dict, ctx: object) -> dict:
            await asyncio.sleep(10)
            return {}

        backend.register("slow", slow, timeout=60)
        # Parent timeout already expired (0 remaining)
        client = CommandsClient(
            _backend=backend,
            _namespace="@test/pack",
            _parent_timeout=0.0,
        )
        client._context = object()

        with pytest.raises(CommandTimeoutError):
            await client.execute("slow", {})

    @pytest.mark.asyncio
    async def test_override_timeout(self) -> None:
        backend = FakeBackend()

        async def slow(args: dict, ctx: object) -> dict:
            await asyncio.sleep(10)
            return {}

        backend.register("slow", slow, timeout=60)
        client = _make_client(backend)

        with pytest.raises(CommandTimeoutError):
            await client.execute("slow", {}, timeout=0)


class TestErrorWrapping:
    @pytest.mark.asyncio
    async def test_inner_exception_wrapped_as_command_error(self) -> None:
        backend = FakeBackend()

        async def bad(args: dict, ctx: object) -> dict:
            raise ValueError("unexpected")

        backend.register("bad", bad)
        client = _make_client(backend)

        with pytest.raises(CommandError, match="Intra-pack call to 'bad' failed"):
            await client.execute("bad", {})

    @pytest.mark.asyncio
    async def test_command_error_not_double_wrapped(self) -> None:
        backend = FakeBackend()

        async def raises_cmd_error(args: dict, ctx: object) -> dict:
            raise CommandError(message="original error")

        backend.register("cmd-err", raises_cmd_error)
        client = _make_client(backend)

        with pytest.raises(CommandError, match="original error"):
            await client.execute("cmd-err", {})

    @pytest.mark.asyncio
    async def test_circular_error_not_wrapped(self) -> None:
        backend = FakeBackend()
        client = _make_client(backend)

        async def recursive(args: dict, ctx: object) -> dict:
            return await client.execute("recursive", {})

        backend.register("recursive", recursive)

        with pytest.raises(CircularCommandError):
            await client.execute("recursive", {})

    @pytest.mark.asyncio
    async def test_sdk_error_not_wrapped_as_command_error(self) -> None:
        """HuitzoError subclasses other than CommandError must propagate unchanged."""
        backend = FakeBackend()

        async def raises_storage_error(args: dict, ctx: object) -> dict:
            raise StorageError(operation="get", key="foo", message="disk full")

        backend.register("store-fail", raises_storage_error)
        client = _make_client(backend)

        with pytest.raises(StorageError):
            await client.execute("store-fail", {})
