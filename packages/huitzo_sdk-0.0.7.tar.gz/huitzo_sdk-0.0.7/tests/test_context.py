"""Tests for the Context class."""

import pytest
from uuid import UUID

from huitzo_sdk import Context, DeploymentMode
from huitzo_sdk.context import _UNSET_UUID
from huitzo_sdk.errors import (
    ConfigurationError,
    HuitzoError,
    IntegrationError,
)
from huitzo_sdk.integrations.secrets import EnvSecretsBackend, SecretsClient
from huitzo_sdk.storage import InMemoryBackend, StorageClient, StorageNamespace


class TestContextCreation:
    def test_default_values(self) -> None:
        ctx = Context()
        assert isinstance(ctx.user_id, UUID)
        assert isinstance(ctx.tenant_id, UUID)
        assert isinstance(ctx.session_id, UUID)
        assert isinstance(ctx.correlation_id, str)
        assert ctx.deployment_mode == DeploymentMode.CLOUD

    def test_default_identity_is_sentinel(self) -> None:
        ctx = Context()
        assert ctx.user_id == _UNSET_UUID
        assert ctx.tenant_id == _UNSET_UUID
        assert ctx.session_id == _UNSET_UUID

    def test_correlation_id_is_unique_per_instance(self) -> None:
        ctx1 = Context()
        ctx2 = Context()
        assert ctx1.correlation_id != ctx2.correlation_id

    def test_custom_identity(self) -> None:
        uid = UUID("12345678-1234-1234-1234-123456789abc")
        tid = UUID("abcdefab-abcd-abcd-abcd-abcdefabcdef")
        ctx = Context(user_id=uid, tenant_id=tid)
        assert ctx.user_id == uid
        assert ctx.tenant_id == tid

    def test_command_metadata(self) -> None:
        ctx = Context(
            command_name="test-cmd",
            namespace="demo",
            command_version="2.0.0",
        )
        assert ctx.command_name == "test-cmd"
        assert ctx.namespace == "demo"
        assert ctx.command_version == "2.0.0"

    def test_deployment_mode(self) -> None:
        ctx = Context(deployment_mode=DeploymentMode.SELF_HOSTED)
        assert ctx.deployment_mode == DeploymentMode.SELF_HOSTED
        assert ctx.deployment_mode.value == "self_hosted"


class TestContextStubs:
    """Test that future services raise ConfigurationError (in HuitzoError hierarchy)."""

    STUBBED_SERVICES = [
        "env",
        "config",
        "local_storage",
        "inference_backend",
    ]

    @pytest.mark.parametrize("service", STUBBED_SERVICES)
    def test_stubbed_service_raises_configuration_error(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(ConfigurationError, match=f"ctx.{service}"):
            getattr(ctx, service)

    @pytest.mark.parametrize("service", STUBBED_SERVICES)
    def test_stubbed_service_is_huitzo_error(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(HuitzoError):
            getattr(ctx, service)

    def test_unknown_attribute_raises_attribute_error(self) -> None:
        ctx = Context()
        with pytest.raises(AttributeError):
            _ = ctx.nonexistent_thing


class TestContextIntegrationProperties:
    """Test that integration properties raise IntegrationError when not wired."""

    INTEGRATION_SERVICES = [
        "llm",
        "email",
        "http",
        "telegram",
        "files",
        "storage",
        "commands",
        "secrets",
        "log",
        "mcp",
        "cron",
    ]

    @pytest.mark.parametrize("service", INTEGRATION_SERVICES)
    def test_unwired_integration_raises_integration_error(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(IntegrationError, match=f"ctx.{service}"):
            getattr(ctx, service)

    @pytest.mark.parametrize("service", INTEGRATION_SERVICES)
    def test_unwired_integration_is_huitzo_error(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(HuitzoError):
            getattr(ctx, service)


class TestContextStorageWiring:
    """Test that ctx.storage works when wired with a StorageClient."""

    _TENANT = UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")
    _USER = UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb")

    def _make_client(self) -> StorageClient:
        ns = StorageNamespace(
            tenant_id=self._TENANT,
            user_id=self._USER,
            pack_id="my-pack",
        )
        return StorageClient(InMemoryBackend(), ns)

    def test_storage_returns_client_when_wired(self) -> None:
        client = self._make_client()
        ctx = Context(user_id=self._USER, tenant_id=self._TENANT, _storage=client)
        assert ctx.storage is client

    def test_storage_raises_when_not_wired(self) -> None:
        ctx = Context()
        with pytest.raises(IntegrationError, match="ctx.storage"):
            _ = ctx.storage

    def test_storage_raises_configuration_error_when_identity_unset(self) -> None:
        """Storage access must be blocked when runtime failed to inject identity."""
        client = self._make_client()
        ctx = Context(_storage=client)  # identity fields remain as sentinels
        with pytest.raises(ConfigurationError, match="identity"):
            _ = ctx.storage

    def test_storage_raises_configuration_error_when_only_tenant_unset(self) -> None:
        client = self._make_client()
        ctx = Context(user_id=self._USER, _storage=client)  # tenant_id is sentinel
        with pytest.raises(ConfigurationError, match="identity"):
            _ = ctx.storage

    def test_storage_raises_configuration_error_when_only_user_unset(self) -> None:
        client = self._make_client()
        ctx = Context(tenant_id=self._TENANT, _storage=client)  # user_id is sentinel
        with pytest.raises(ConfigurationError, match="identity"):
            _ = ctx.storage


class TestDeploymentMode:
    def test_all_modes(self) -> None:
        assert DeploymentMode.CLOUD.value == "cloud"
        assert DeploymentMode.SELF_HOSTED.value == "self_hosted"
        assert DeploymentMode.EDGE.value == "edge"

    def test_comparison(self) -> None:
        ctx = Context(deployment_mode=DeploymentMode.EDGE)
        assert ctx.deployment_mode == DeploymentMode.EDGE
        assert ctx.deployment_mode != DeploymentMode.CLOUD


class TestContextSecretsWiring:
    """Test that ctx.secrets works when wired with a SecretsClient."""

    def test_secrets_returns_client_when_wired(self) -> None:
        client = SecretsClient(_backend=EnvSecretsBackend())
        ctx = Context(_secrets=client)
        assert ctx.secrets is client

    def test_secrets_raises_when_not_wired(self) -> None:
        ctx = Context()
        with pytest.raises(IntegrationError, match="ctx.secrets"):
            _ = ctx.secrets


class TestContextExecuteStub:
    """Test that ctx.execute() raises IntegrationError when not wired."""

    @pytest.mark.asyncio
    async def test_execute_raises_integration_error(self) -> None:
        ctx = Context()
        with pytest.raises(IntegrationError, match="ctx.execute"):
            await ctx.execute("other-pack", "some-command")

    @pytest.mark.asyncio
    async def test_execute_is_huitzo_error(self) -> None:
        ctx = Context()
        with pytest.raises(HuitzoError):
            await ctx.execute("other-pack", "some-command")


class TestContextCronWiring:
    """Test that ctx.cron works when wired with a CronClient."""

    def test_cron_returns_client_when_wired(self) -> None:
        from huitzo_sdk.integrations.cron import CronClient, CronMetadata

        metadata = CronMetadata(
            schedule="0 8 * * 1-5",
            scheduled_at=None,
            is_scheduled=True,
        )
        client = CronClient(_metadata=metadata)
        ctx = Context(_cron=client)
        assert ctx.cron is client
        assert ctx.cron.is_scheduled is True
        assert ctx.cron.schedule == "0 8 * * 1-5"

    def test_cron_raises_when_not_wired(self) -> None:
        ctx = Context()
        with pytest.raises(IntegrationError, match="ctx.cron"):
            _ = ctx.cron

    def test_cron_on_demand_metadata(self) -> None:
        from huitzo_sdk.integrations.cron import CronClient, CronMetadata

        metadata = CronMetadata(
            schedule=None,
            scheduled_at=None,
            is_scheduled=False,
        )
        client = CronClient(_metadata=metadata)
        ctx = Context(_cron=client)
        assert ctx.cron.is_scheduled is False
        assert ctx.cron.schedule is None
        assert ctx.cron.scheduled_at is None
