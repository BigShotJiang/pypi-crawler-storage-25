"""
Module: tests.test_demo_mode
Description: Tests for HUITZO_DEMO_MODE short-circuit (demo_mode helpers,
             FixtureLLMBackend, FixtureHTTPBackend, Context auto-wiring).

Implements:
    - docs/sdk/integrations.md
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from huitzo_sdk import (
    HUITZO_DEMO_FIXTURES_DIR_ENV,
    HUITZO_DEMO_MODE_ENV,
    Context,
    fixtures_root,
    is_demo_mode,
    load_fixture,
)
from huitzo_sdk.demo_mode import _clear_cache
from huitzo_sdk.errors import IntegrationError, LLMError
from huitzo_sdk.integrations._fixture_backends import (
    FixtureHTTPBackend,
    FixtureLLMBackend,
    _stable_key,
)


@pytest.fixture(autouse=True)
def _reset_cache() -> None:
    _clear_cache()


# ---------------------------------------------------------------------------
# is_demo_mode
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "value, expected",
    [
        ("1", True),
        ("true", True),
        ("TRUE", True),
        ("True", True),
        ("yes", True),
        ("YES", True),
        ("0", False),
        ("false", False),
        ("no", False),
        ("", False),
        ("anything-else", False),
    ],
)
def test_is_demo_mode_parses_env(
    monkeypatch: pytest.MonkeyPatch, value: str, expected: bool
) -> None:
    monkeypatch.setenv(HUITZO_DEMO_MODE_ENV, value)
    assert is_demo_mode() is expected


def test_is_demo_mode_unset(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(HUITZO_DEMO_MODE_ENV, raising=False)
    assert is_demo_mode() is False


# ---------------------------------------------------------------------------
# fixtures_root
# ---------------------------------------------------------------------------


def test_fixtures_root_returns_path_when_dir_exists(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv(HUITZO_DEMO_FIXTURES_DIR_ENV, str(tmp_path))
    assert fixtures_root() == tmp_path


def test_fixtures_root_none_when_unset(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(HUITZO_DEMO_FIXTURES_DIR_ENV, raising=False)
    assert fixtures_root() is None


def test_fixtures_root_none_when_path_missing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    missing = tmp_path / "does-not-exist"
    monkeypatch.setenv(HUITZO_DEMO_FIXTURES_DIR_ENV, str(missing))
    assert fixtures_root() is None


def test_fixtures_root_none_when_path_is_file(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    file_path = tmp_path / "not-a-dir.txt"
    file_path.write_text("hi")
    monkeypatch.setenv(HUITZO_DEMO_FIXTURES_DIR_ENV, str(file_path))
    assert fixtures_root() is None


# ---------------------------------------------------------------------------
# load_fixture
# ---------------------------------------------------------------------------


def test_load_fixture_reads_json(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv(HUITZO_DEMO_FIXTURES_DIR_ENV, str(tmp_path))
    target = tmp_path / "claims.json"
    target.write_text(json.dumps([{"id": "FNOL-1"}]))
    assert load_fixture("claims.json") == [{"id": "FNOL-1"}]


def test_load_fixture_caches(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv(HUITZO_DEMO_FIXTURES_DIR_ENV, str(tmp_path))
    target = tmp_path / "x.json"
    target.write_text(json.dumps({"v": 1}))
    first = load_fixture("x.json")
    target.write_text(json.dumps({"v": 99}))  # mutate on disk
    second = load_fixture("x.json")
    assert first == second == {"v": 1}


def test_load_fixture_raises_when_root_unset(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(HUITZO_DEMO_FIXTURES_DIR_ENV, raising=False)
    with pytest.raises(FileNotFoundError, match="HUITZO_DEMO_FIXTURES_DIR"):
        load_fixture("anything.json")


def test_load_fixture_raises_when_file_missing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv(HUITZO_DEMO_FIXTURES_DIR_ENV, str(tmp_path))
    with pytest.raises(FileNotFoundError, match="not found"):
        load_fixture("missing.json")


# ---------------------------------------------------------------------------
# FixtureLLMBackend
# ---------------------------------------------------------------------------


def _seed_llm(tmp_path: Path, key: str, content: str) -> Path:
    responses = tmp_path / "llm_responses"
    responses.mkdir(parents=True, exist_ok=True)
    target = responses / f"{key}.json"
    target.write_text(json.dumps({"content": content}))
    return target


@pytest.mark.asyncio
async def test_fixture_llm_chat_returns_canned_content(tmp_path: Path) -> None:
    messages = [{"role": "user", "content": "hello"}]
    key = _stable_key({"kind": "chat", "messages": messages})
    _seed_llm(tmp_path, key, "canned-reply")
    backend = FixtureLLMBackend(fixtures_dir=tmp_path)
    result = await backend.chat(
        messages=messages,
        model="claude",
        temperature=0.0,
        max_tokens=None,
        top_p=None,
        stop=None,
        response_format=None,
        schema=None,
    )
    assert result == "canned-reply"


@pytest.mark.asyncio
async def test_fixture_llm_chat_falls_back_to_default(tmp_path: Path) -> None:
    _seed_llm(tmp_path, "_default", "default-reply")
    backend = FixtureLLMBackend(fixtures_dir=tmp_path)
    result = await backend.chat(
        messages=[{"role": "user", "content": "no-key-match"}],
        model="claude",
        temperature=0.0,
        max_tokens=None,
        top_p=None,
        stop=None,
        response_format=None,
        schema=None,
    )
    assert result == "default-reply"


@pytest.mark.asyncio
async def test_fixture_llm_chat_raises_when_no_fixture(tmp_path: Path) -> None:
    backend = FixtureLLMBackend(fixtures_dir=tmp_path, command_namespace="demo-pack")
    with pytest.raises(LLMError) as exc:
        await backend.chat(
            messages=[{"role": "user", "content": "x"}],
            model="claude",
            temperature=0.0,
            max_tokens=None,
            top_p=None,
            stop=None,
            response_format=None,
            schema=None,
        )
    assert "demo-pack" in str(exc.value)
    assert str(tmp_path / "llm_responses") in str(exc.value)


@pytest.mark.asyncio
async def test_fixture_llm_complete_uses_prompt_key(tmp_path: Path) -> None:
    key = _stable_key({"kind": "complete", "system": None, "prompt": "hi"})
    _seed_llm(tmp_path, key, "completion")
    backend = FixtureLLMBackend(fixtures_dir=tmp_path)
    result = await backend.complete(
        prompt="hi",
        system=None,
        model="m",
        temperature=0.0,
        max_tokens=None,
        top_p=None,
        stop=None,
        response_format=None,
        schema=None,
    )
    assert result == "completion"


def test_fixture_llm_stream_unsupported(tmp_path: Path) -> None:
    backend = FixtureLLMBackend(fixtures_dir=tmp_path)
    with pytest.raises(NotImplementedError):
        backend.stream(
            prompt="x",
            system=None,
            model="m",
            temperature=0.0,
            max_tokens=None,
            top_p=None,
            stop=None,
        )


# ---------------------------------------------------------------------------
# FixtureHTTPBackend
# ---------------------------------------------------------------------------


def _seed_http(tmp_path: Path, name: str, fixture: dict[str, Any]) -> None:
    responses = tmp_path / "http_responses"
    responses.mkdir(parents=True, exist_ok=True)
    (responses / name).write_text(json.dumps(fixture))


@pytest.mark.asyncio
async def test_fixture_http_returns_matching_body(tmp_path: Path) -> None:
    _seed_http(
        tmp_path,
        "01-news.json",
        {
            "method": "GET",
            "url_pattern": r"newsapi\.org/v2/everything",
            "status": 200,
            "body": {"articles": [{"title": "Mock Article"}]},
        },
    )
    backend = FixtureHTTPBackend(fixtures_dir=tmp_path)
    result = await backend.request(
        "GET",
        "https://newsapi.org/v2/everything?q=ai",
        headers=None,
        params=None,
        json=None,
        data=None,
        files=None,
        timeout=None,
    )
    assert result == {"articles": [{"title": "Mock Article"}]}


@pytest.mark.asyncio
async def test_fixture_http_raises_when_no_match(tmp_path: Path) -> None:
    backend = FixtureHTTPBackend(fixtures_dir=tmp_path)
    with pytest.raises(IntegrationError) as exc:
        await backend.request(
            "GET",
            "https://example.com/unknown",
            headers=None,
            params=None,
            json=None,
            data=None,
            files=None,
            timeout=None,
        )
    assert "http_responses" in str(exc.value)
    assert "GET https://example.com/unknown" in str(exc.value)


# ---------------------------------------------------------------------------
# Context auto-wiring
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_context_demo_mode_autowires_llm_and_http(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv(HUITZO_DEMO_MODE_ENV, "1")
    monkeypatch.setenv(HUITZO_DEMO_FIXTURES_DIR_ENV, str(tmp_path))
    _seed_llm(tmp_path, "_default", "demo-content")
    _seed_http(
        tmp_path,
        "01.json",
        {"method": "GET", "url_pattern": ".*", "status": 200, "body": {"ok": True}},
    )

    ctx = Context(namespace="demo-pack")

    chat_result = await ctx.llm.chat(
        messages=[{"role": "user", "content": "anything"}],
    )
    assert chat_result == "demo-content"

    http_result = await ctx.http.get("https://example.com/path")
    assert http_result == {"ok": True}


def test_context_does_not_autowire_when_demo_mode_off(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.delenv(HUITZO_DEMO_MODE_ENV, raising=False)
    monkeypatch.setenv(HUITZO_DEMO_FIXTURES_DIR_ENV, str(tmp_path))
    ctx = Context(namespace="demo-pack")
    with pytest.raises(IntegrationError):
        _ = ctx.llm
    with pytest.raises(IntegrationError):
        _ = ctx.http


def test_context_does_not_autowire_when_fixtures_dir_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(HUITZO_DEMO_MODE_ENV, "1")
    monkeypatch.delenv(HUITZO_DEMO_FIXTURES_DIR_ENV, raising=False)
    ctx = Context(namespace="demo-pack")
    with pytest.raises(IntegrationError):
        _ = ctx.llm
