"""
Module: huitzo_sdk
Description: Huitzo SDK for building Intelligence Packs.

Implements:
    - docs/sdk/overview.md
    - docs/sdk/commands.md
    - docs/sdk/context.md
    - docs/sdk/error-handling.md

See Also:
    - docs/sdk/storage.md
    - docs/sdk/storage-backends.md
    - docs/sdk/integrations.md
"""

from huitzo_sdk.command import HuitzoCommand, command
from huitzo_sdk.commands_service import CommandsBackend, CommandsClient
from huitzo_sdk.context import Context
from huitzo_sdk.demo_mode import (
    HUITZO_DEMO_FIXTURES_DIR_ENV,
    HUITZO_DEMO_MODE_ENV,
    fixtures_root,
    is_demo_mode,
    load_fixture,
)
from huitzo_sdk.errors import (
    CircularCommandError,
    CommandError,
    CommandNotFoundError,
    CommandTimeoutError,
    ConfigurationError,
    CronError,
    DatabaseError,
    EmailError,
    ExternalAPIError,
    HTTPError,
    HTTPSecurityError,
    HuitzoError,
    IntegrationError,
    LLMError,
    MaxCallDepthError,
    MCPConnectionError,
    MCPError,
    MCPSchemaError,
    MCPTimeoutError,
    MCPToolError,
    PackExecutionError,
    PackPermissionError,
    RateLimitError,
    SSHError,
    SecretsError,
    StorageError,
    ValidationError,
)
from huitzo_sdk.integrations import (
    DBBackend,
    DBClient,
    DBIntegrationConfig,
    DBTransaction,
    DBTransactionBackend,
    DevLogBackend,
    EmailClient,
    EnvSecretsBackend,
    FileClient,
    FileStorageBackend,
    HTTPClient,
    LLMClient,
    LogClient,
    SecretsBackend,
    SecretsClient,
    SSHClient,
    TelegramClient,
)
from huitzo_sdk.storage import InMemoryBackend, StorageBackend, StorageClient, StorageNamespace
from huitzo_sdk.types import CommandMetadata, DeploymentMode, Result

__all__ = [
    # Core
    "command",
    "HuitzoCommand",
    "Context",
    # Demo mode
    "HUITZO_DEMO_MODE_ENV",
    "HUITZO_DEMO_FIXTURES_DIR_ENV",
    "is_demo_mode",
    "fixtures_root",
    "load_fixture",
    # Commands
    "CommandsBackend",
    "CommandsClient",
    # Integrations
    "LLMClient",
    "EmailClient",
    "HTTPClient",
    "TelegramClient",
    "SSHClient",
    "DBBackend",
    "DBClient",
    "DBIntegrationConfig",
    "DBTransaction",
    "DBTransactionBackend",
    "FileClient",
    "FileStorageBackend",
    "LogClient",
    "DevLogBackend",
    "SecretsClient",
    "SecretsBackend",
    "EnvSecretsBackend",
    # Storage
    "StorageBackend",
    "StorageClient",
    "InMemoryBackend",
    "StorageNamespace",
    # Types
    "CommandMetadata",
    "DeploymentMode",
    "Result",
    # Errors
    "HuitzoError",
    "CircularCommandError",
    "CommandError",
    "CommandNotFoundError",
    "ValidationError",
    "CommandTimeoutError",
    "MaxCallDepthError",
    "StorageError",
    "SecretsError",
    "ExternalAPIError",
    "DatabaseError",
    "IntegrationError",
    "LLMError",
    "CronError",
    "EmailError",
    "HTTPError",
    "HTTPSecurityError",
    "SSHError",
    "PackExecutionError",
    "PackPermissionError",
    "ConfigurationError",
    "RateLimitError",
    "MCPError",
    "MCPConnectionError",
    "MCPToolError",
    "MCPTimeoutError",
    "MCPSchemaError",
]
