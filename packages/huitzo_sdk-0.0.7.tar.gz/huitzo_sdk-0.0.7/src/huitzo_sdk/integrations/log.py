"""
Module: integrations.log
Description: Structured logging integration client for packs.

Implements:
    - docs/sdk/integrations.md#log-integration

See Also:
    - docs/sdk/context.md (for ctx.log usage)
    - docs/sdk/error-handling.md (for integration errors)
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable

from huitzo_sdk.errors import _SENSITIVE_FIELD_RE


def _scrub_kwargs(kwargs: dict[str, Any]) -> dict[str, Any]:
    return {k: "<redacted>" if _SENSITIVE_FIELD_RE.search(k) else v for k, v in kwargs.items()}


@runtime_checkable
class LogBackend(Protocol):
    """Backend protocol for structured logging providers."""

    def debug(self, message: str, **kwargs: Any) -> None: ...

    def info(self, message: str, **kwargs: Any) -> None: ...

    def warning(self, message: str, **kwargs: Any) -> None: ...

    def error(self, message: str, **kwargs: Any) -> None: ...


@dataclass
class LogClient:
    """Client for structured logging.

    This is the SDK-side interface. The backend injects a real implementation
    at runtime that handles log routing, enrichment, and persistence.
    """

    _backend: LogBackend

    def debug(self, message: str, **kwargs: Any) -> None:
        """Emit a debug-level structured log entry.

        Args:
            message: Human-readable log message.
            **kwargs: Structured fields attached to the log entry
                (e.g. session_id=..., user_id=...).
        """
        self._backend.debug(message, **_scrub_kwargs(kwargs))

    def info(self, message: str, **kwargs: Any) -> None:
        """Emit an info-level structured log entry.

        Args:
            message: Human-readable log message.
            **kwargs: Structured fields attached to the log entry.
        """
        self._backend.info(message, **_scrub_kwargs(kwargs))

    def warning(self, message: str, **kwargs: Any) -> None:
        """Emit a warning-level structured log entry.

        Args:
            message: Human-readable log message.
            **kwargs: Structured fields attached to the log entry.
        """
        self._backend.warning(message, **_scrub_kwargs(kwargs))

    def error(self, message: str, **kwargs: Any) -> None:
        """Emit an error-level structured log entry.

        Args:
            message: Human-readable log message.
            **kwargs: Structured fields attached to the log entry.
        """
        self._backend.error(message, **_scrub_kwargs(kwargs))


class DevLogBackend:
    """Development log backend that writes structured JSON lines to stderr.

    Intended for local development and test environments. The Huitzo backend
    injects a richer structured client at runtime.
    """

    def _emit(self, level: str, message: str, **kwargs: Any) -> None:
        entry: dict[str, Any] = {"level": level, "message": message}
        entry.update(kwargs)
        print(json.dumps(entry, default=str), file=sys.stderr)

    def debug(self, message: str, **kwargs: Any) -> None:
        self._emit("debug", message, **kwargs)

    def info(self, message: str, **kwargs: Any) -> None:
        self._emit("info", message, **kwargs)

    def warning(self, message: str, **kwargs: Any) -> None:
        self._emit("warning", message, **kwargs)

    def error(self, message: str, **kwargs: Any) -> None:
        self._emit("error", message, **kwargs)
