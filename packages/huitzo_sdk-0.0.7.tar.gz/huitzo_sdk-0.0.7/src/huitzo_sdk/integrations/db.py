"""
Module: integrations.db
Description: Database integration client for Postgres / MySQL connectors registered
through the unified Integration registry.

Implements:
    - docs/sdk/integrations.md#database-integration
    - docs/architecture/integrations.md#3-integration-types-catalog
    - docs/architecture/integrations.md#9-security-boundaries

See Also:
    - docs/sdk/error-handling.md (for DatabaseError)
"""

from __future__ import annotations

import re
from collections.abc import AsyncIterator
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from huitzo_sdk.errors import DatabaseError

DEFAULT_QUERY_TIMEOUT = 30
MAX_QUERY_TIMEOUT = 300
DEFAULT_ROW_LIMIT = 10_000

# Statements that mutate schema. Rejected unless integration.config.allow_ddl is True.
_DDL_RE = re.compile(
    r"^\s*(?:CREATE|DROP|ALTER|TRUNCATE|RENAME|GRANT|REVOKE|COMMENT)\b",
    re.IGNORECASE,
)

# SQL block comments and line comments. Stripped before the DDL gate runs so
# pack authors cannot bypass the rejection by hiding DDL behind a comment.
_BLOCK_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)
_LINE_COMMENT_RE = re.compile(r"--[^\n]*")


def _strip_sql_comments(sql: str) -> str:
    """Return *sql* with `/* ... */` and `-- ...` comments removed.

    Used before DDL detection — without this, ``/* hint */ DROP TABLE x`` and
    ``-- comment\\nDROP TABLE x`` would slip past the regex which only skips
    leading whitespace.
    """
    sql = _BLOCK_COMMENT_RE.sub(" ", sql)
    sql = _LINE_COMMENT_RE.sub("", sql)
    return sql


def _has_unquoted_statement_terminator(sql: str) -> bool:
    """Return True if *sql* contains a ``;`` followed by non-whitespace.

    aiomysql 0.x unconditionally enables ``CLIENT.MULTI_STATEMENTS``, so a
    payload like ``INSERT INTO t VALUES (1); DROP TABLE users`` would bypass
    the DDL gate (which only inspects the first token) and execute both
    statements. We reject any multi-statement payload defence-in-depth on both
    engines. A single trailing ``;`` is allowed for ergonomic compatibility
    with copy-pasted SQL.

    The check honours single-quoted, double-quoted, and PostgreSQL-style
    backtick string literals so ``SELECT ';'`` is not mistaken for a
    statement terminator.
    """
    in_single = False
    in_double = False
    in_backtick = False
    i = 0
    n = len(sql)
    while i < n:
        ch = sql[i]
        if in_single:
            if ch == "\\" and i + 1 < n:
                i += 2
                continue
            if ch == "'":
                # SQL-standard escaping: '' inside a single-quoted literal
                if i + 1 < n and sql[i + 1] == "'":
                    i += 2
                    continue
                in_single = False
        elif in_double:
            if ch == "\\" and i + 1 < n:
                i += 2
                continue
            if ch == '"':
                in_double = False
        elif in_backtick:
            if ch == "`":
                in_backtick = False
        else:
            if ch == "'":
                in_single = True
            elif ch == '"':
                in_double = True
            elif ch == "`":
                in_backtick = True
            elif ch == ";":
                # A semicolon followed only by whitespace at the end is OK.
                rest = sql[i + 1 :]
                if rest.strip() == "":
                    return False
                return True
        i += 1
    return False


@dataclass(frozen=True)
class DBIntegrationConfig:
    """Resolved DB integration configuration injected by the runtime.

    Mirrors the postgres / mysql Integration row shape after secret decryption.
    """

    integration_id: str
    name: str
    type: str  # "postgres" | "mysql"
    host: str
    port: int
    database: str
    username: str
    password: str
    sslmode: str | None = None  # postgres
    ssl_ca: str | None = None  # mysql
    allow_ddl: bool = False
    row_limit: int = DEFAULT_ROW_LIMIT

    def __repr__(self) -> str:
        return (
            f"DBIntegrationConfig(integration_id={self.integration_id!r}, "
            f"name={self.name!r}, type={self.type!r}, host={self.host!r}, "
            f"port={self.port!r}, database={self.database!r}, "
            f"username={self.username!r}, password='<redacted>', "
            f"sslmode={self.sslmode!r}, ssl_ca={('<present>' if self.ssl_ca else None)!r}, "
            f"allow_ddl={self.allow_ddl!r}, row_limit={self.row_limit!r})"
        )


@runtime_checkable
class DBBackend(Protocol):
    """Backend protocol for database operations.

    Backends accept a resolved :class:`DBIntegrationConfig` plus the parameterised
    SQL and execute it on the configured engine. Backends MUST raise
    :class:`huitzo_sdk.errors.DatabaseError` on failure.
    """

    async def query(
        self,
        target: DBIntegrationConfig,
        sql: str,
        params: tuple[Any, ...],
        *,
        timeout: int,
        row_limit: int,
    ) -> list[dict[str, Any]]: ...

    async def execute(
        self,
        target: DBIntegrationConfig,
        sql: str,
        params: tuple[Any, ...],
        *,
        timeout: int,
    ) -> int: ...

    def transaction(
        self,
        target: DBIntegrationConfig,
        *,
        timeout: int,
    ) -> AbstractAsyncContextManager["DBTransactionBackend"]: ...


@runtime_checkable
class DBTransactionBackend(Protocol):
    """Backend protocol for in-flight transactions."""

    async def query(
        self,
        sql: str,
        params: tuple[Any, ...],
        *,
        timeout: int,
        row_limit: int,
    ) -> list[dict[str, Any]]: ...

    async def execute(
        self,
        sql: str,
        params: tuple[Any, ...],
        *,
        timeout: int,
    ) -> int: ...


@dataclass
class DBTransaction:
    """Open transaction handle bound to a single integration target."""

    _backend: DBTransactionBackend
    _integration_name: str
    _allow_ddl: bool
    _row_limit: int

    async def query(
        self,
        sql: str,
        *params: Any,
        timeout: int = DEFAULT_QUERY_TIMEOUT,
    ) -> list[dict[str, Any]]:
        timeout = _validate_timeout(timeout)
        _validate_sql(sql, allow_ddl=self._allow_ddl, integration_name=self._integration_name)
        return await self._backend.query(
            sql,
            params,
            timeout=timeout,
            row_limit=self._row_limit,
        )

    async def execute(
        self,
        sql: str,
        *params: Any,
        timeout: int = DEFAULT_QUERY_TIMEOUT,
    ) -> int:
        timeout = _validate_timeout(timeout)
        _validate_sql(sql, allow_ddl=self._allow_ddl, integration_name=self._integration_name)
        return await self._backend.execute(sql, params, timeout=timeout)


@dataclass
class DBClient:
    """Client for executing queries on user-registered database integrations.

    Enforces manifest allowlists, DDL gating, query timeouts, and row caps before
    delegating to the backend.
    """

    _backend: DBBackend
    _targets: dict[str, DBIntegrationConfig] = field(default_factory=dict)
    _allowed_integrations: list[str] = field(default_factory=list)

    def _check_allowed(self, integration: str) -> None:
        if not self._allowed_integrations:
            raise DatabaseError(
                integration=integration,
                message=(
                    f"Integration {integration!r} is not allowed: pack manifest "
                    "declares no DB integrations."
                ),
            )
        if "*" in self._allowed_integrations:
            return
        if integration not in self._allowed_integrations:
            raise DatabaseError(
                integration=integration,
                message=(f"Integration {integration!r} is not allowed by this pack's manifest."),
            )

    def _resolve(self, integration: str) -> DBIntegrationConfig:
        self._check_allowed(integration)
        target = self._targets.get(integration)
        if target is None:
            raise DatabaseError(
                integration=integration,
                message=f"Database integration {integration!r} not found.",
            )
        return target

    async def query(
        self,
        integration: str,
        sql: str,
        *params: Any,
        timeout: int = DEFAULT_QUERY_TIMEOUT,
    ) -> list[dict[str, Any]]:
        """Execute a SELECT-style query and return all rows as dicts.

        Raises:
            DatabaseError: If the integration is not allowed, the SQL violates
                the DDL gate, the query exceeds ``timeout`` seconds, or the
                backend returns more than ``row_limit`` rows.
        """
        target = self._resolve(integration)
        timeout = _validate_timeout(timeout)
        _validate_sql(sql, allow_ddl=target.allow_ddl, integration_name=integration)
        return await self._backend.query(
            target,
            sql,
            params,
            timeout=timeout,
            row_limit=target.row_limit,
        )

    async def execute(
        self,
        integration: str,
        sql: str,
        *params: Any,
        timeout: int = DEFAULT_QUERY_TIMEOUT,
    ) -> int:
        """Execute an INSERT/UPDATE/DELETE statement and return rows affected.

        Raises:
            DatabaseError: As for :meth:`query`.
        """
        target = self._resolve(integration)
        timeout = _validate_timeout(timeout)
        _validate_sql(sql, allow_ddl=target.allow_ddl, integration_name=integration)
        return await self._backend.execute(target, sql, params, timeout=timeout)

    @asynccontextmanager
    async def transaction(
        self,
        integration: str,
        *,
        timeout: int = DEFAULT_QUERY_TIMEOUT,
    ) -> AsyncIterator[DBTransaction]:
        """Open a transaction. Commits on clean exit, rolls back on exception."""
        target = self._resolve(integration)
        timeout = _validate_timeout(timeout)
        async with self._backend.transaction(target, timeout=timeout) as txn_backend:
            yield DBTransaction(
                _backend=txn_backend,
                _integration_name=integration,
                _allow_ddl=target.allow_ddl,
                _row_limit=target.row_limit,
            )


def _validate_timeout(timeout: int) -> int:
    if timeout <= 0:
        raise DatabaseError(
            integration="",
            message=f"timeout must be positive, got {timeout}",
        )
    if timeout > MAX_QUERY_TIMEOUT:
        raise DatabaseError(
            integration="",
            message=f"timeout exceeds maximum of {MAX_QUERY_TIMEOUT}s",
        )
    return timeout


def _validate_sql(sql: str, *, allow_ddl: bool, integration_name: str) -> None:
    if not isinstance(sql, str) or not sql.strip():
        raise DatabaseError(
            integration=integration_name,
            message="SQL statement must be a non-empty string.",
        )
    if "\x00" in sql:
        raise DatabaseError(
            integration=integration_name,
            message="SQL statement must not contain null bytes.",
        )
    # Reject multi-statement payloads on every path. aiomysql 0.x leaves
    # ``CLIENT.MULTI_STATEMENTS`` enabled, so without this defence-in-depth a
    # pack could chain ``INSERT ...; DROP TABLE x`` and slip the second
    # statement past the DDL gate (which only inspects the first token).
    if _has_unquoted_statement_terminator(sql):
        raise DatabaseError(
            integration=integration_name,
            message=(
                "SQL must contain a single statement; multi-statement payloads "
                "(';' followed by additional SQL) are rejected."
            ),
        )
    if not allow_ddl:
        # Strip comments so DDL hidden behind ``/* hint */`` or ``-- ...`` is
        # still detected by the regex.
        sanitized = _strip_sql_comments(sql)
        if _DDL_RE.match(sanitized):
            raise DatabaseError(
                integration=integration_name,
                message=(
                    "DDL statements (CREATE/DROP/ALTER/TRUNCATE/RENAME/GRANT/REVOKE/COMMENT) "
                    "are rejected. Set integration.config.allow_ddl=true to permit DDL."
                ),
            )


__all__ = [
    "DBBackend",
    "DBClient",
    "DBIntegrationConfig",
    "DBTransaction",
    "DBTransactionBackend",
    "DEFAULT_QUERY_TIMEOUT",
    "DEFAULT_ROW_LIMIT",
    "MAX_QUERY_TIMEOUT",
]
