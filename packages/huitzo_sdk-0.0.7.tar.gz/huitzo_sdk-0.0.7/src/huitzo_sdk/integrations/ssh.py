"""
Module: integrations.ssh
Description: SSH integration client for remote command execution on user-registered targets.

Implements:
    - docs/sdk/ssh.md#ctxsshrun
    - docs/architecture/ssh-execution.md#security-model

See Also:
    - docs/sdk/error-handling.md (for SSHError)
    - docs/reference/ssh-targets.md
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable
from uuid import UUID

from huitzo_sdk.errors import SSHError

MAX_COMMAND_LENGTH = 4096
MAX_OUTPUT_BYTES = 1_048_576  # 1 MB

# Characters that enable shell injection when present in user-supplied input.
_SHELL_METACHARS: frozenset[str] = frozenset(";|&`$<>()[]{}\\!")


@dataclass(frozen=True)
class SSHResult:
    """Result of an SSH command execution."""

    stdout: str
    stderr: str
    exit_code: int


@dataclass(frozen=True)
class SSHTargetConfig:
    """Resolved SSH target configuration (decrypted, ready for connection)."""

    target_id: UUID
    name: str
    host: str
    port: int
    username: str
    auth_method: str  # "key" | "password"
    private_key: str | None
    password: str | None
    known_hosts: str | None

    def __repr__(self) -> str:
        return (
            f"SSHTargetConfig(target_id={self.target_id!r}, name={self.name!r}, "
            f"host={self.host!r}, port={self.port!r}, username={self.username!r}, "
            f"auth_method={self.auth_method!r}, "
            f"private_key={('<redacted>' if self.private_key else None)!r}, "
            f"password={('<redacted>' if self.password else None)!r}, "
            f"known_hosts={('<present>' if self.known_hosts else None)!r})"
        )


@runtime_checkable
class SSHBackend(Protocol):
    """Backend protocol for SSH command execution."""

    async def run(
        self,
        target: SSHTargetConfig,
        command: str,
        *,
        timeout: int,
    ) -> SSHResult: ...


@dataclass
class SSHClient:
    """Client for executing commands on user-registered SSH targets.

    Enforces target allowlists from the pack manifest and validates
    commands before delegating to the backend for execution.
    """

    _backend: SSHBackend
    _targets: dict[str, SSHTargetConfig] = field(default_factory=dict)
    _allowed_target_names: list[str] = field(default_factory=list)

    def _check_allowed(self, target: str) -> None:
        """Verify the target is in the pack's allowed list.

        Raises:
            SSHError: If target is not allowed.
        """
        if not self._allowed_target_names:
            raise SSHError(
                target=target,
                message=f"Target '{target}' is not allowed: pack has no SSH targets configured.",
            )
        if "*" in self._allowed_target_names:
            return
        if target not in self._allowed_target_names:
            raise SSHError(
                target=target,
                message=f"Target '{target}' is not allowed by this pack's manifest.",
            )

    @staticmethod
    def _validate_command(command: str) -> None:
        """Validate command string before execution.

        Raises:
            SSHError: If command is invalid.
        """
        if len(command.encode("utf-8")) > MAX_COMMAND_LENGTH:
            raise SSHError(
                message=f"Command exceeds maximum length of {MAX_COMMAND_LENGTH} bytes.",
            )
        if "\x00" in command:
            raise SSHError(message="Command must not contain null bytes.")
        if any(c in command for c in _SHELL_METACHARS):
            raise SSHError(
                message=(
                    "SSH command contains shell metacharacters. "
                    "Only pre-validated, static commands are allowed with ctx.ssh.run(). "
                    "Sanitize user-supplied input before constructing the command."
                ),
            )

    async def run(
        self,
        target: str,
        command: str,
        *,
        timeout: int = 30,
    ) -> SSHResult:
        """Execute a command on a named SSH target.

        Args:
            target: Human-readable target name (e.g., "gpu-cluster").
            command: Shell command to execute on the remote host.
            timeout: Maximum execution time in seconds.

        Returns:
            SSHResult with stdout, stderr, and exit_code.

        Raises:
            SSHError: If target not allowed, not found, connection fails,
                or command validation fails.
        """
        # 1. Check target is in allowed list (before any DB lookup or network call)
        self._check_allowed(target)

        # 2. Validate command
        self._validate_command(command)

        # 3. Look up target config
        config = self._targets.get(target)
        if config is None:
            raise SSHError(
                target=target,
                message=f"SSH target '{target}' not found.",
            )

        # 4. Delegate to backend
        return await self._backend.run(config, command, timeout=timeout)
