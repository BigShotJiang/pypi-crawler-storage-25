"""
Module: integrations._fixture_backends
Description: Fixture-backed backends for HUITZO_DEMO_MODE. Replace LLM and HTTP
             network calls with deterministic file lookups so demos are offline,
             reproducible, and require zero API keys.

Implements:
    - docs/sdk/integrations.md

See Also:
    - huitzo_sdk.demo_mode (env-driven activation)
    - huitzo_sdk.integrations.llm (LLMBackend protocol)
    - huitzo_sdk.integrations.http (HTTPBackend protocol)
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator

from huitzo_sdk.errors import IntegrationError, LLMError


def _stable_key(payload: object) -> str:
    """Return the first 16 hex chars of the SHA256 over a stable JSON dump."""
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _read_response_content(path: Path) -> str:
    """Load a fixture file and return its 'content' field as a string."""
    with path.open(encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict) or "content" not in data:
        raise LLMError(
            provider="fixture",
            message=f"Fixture {path} is missing a 'content' field.",
        )
    content = data["content"]
    if isinstance(content, (dict, list)):
        return json.dumps(content)
    return str(content)


@dataclass
class FixtureLLMBackend:
    """LLM backend that returns canned responses from JSON fixtures.

    Lookup order for `complete()` and `chat()`:
      1. ``<fixtures_dir>/llm_responses/<key>.json`` where ``<key>`` is the
         first 16 hex chars of SHA256 over the stably-serialized input.
      2. ``<fixtures_dir>/llm_responses/_default.json`` as a fallback.

    Each fixture file is ``{"content": "...", "_note": "..."}``; this backend
    returns the ``content`` field as a string. ``stream()`` is not supported.
    """

    fixtures_dir: Path
    command_namespace: str | None = None

    def _responses_dir(self) -> Path:
        return self.fixtures_dir / "llm_responses"

    def _resolve(self, key: str) -> Path:
        candidate = self._responses_dir() / f"{key}.json"
        if candidate.exists():
            return candidate
        default = self._responses_dir() / "_default.json"
        if default.exists():
            return default
        ns = f" (namespace={self.command_namespace})" if self.command_namespace else ""
        raise LLMError(
            provider="fixture",
            message=(
                f"No demo-mode LLM fixture found{ns}. "
                f"Expected {candidate} or {default}. "
                f"Create one of these files with shape "
                f'{{"content": "..."}} to seed the response.'
            ),
        )

    async def complete(
        self,
        *,
        prompt: str,
        system: str | None,
        model: str,
        temperature: float,
        max_tokens: int | None,
        top_p: float | None,
        stop: list[str] | None,
        response_format: str | None,
        schema: type[Any] | None,
    ) -> str:
        key = _stable_key({"kind": "complete", "system": system, "prompt": prompt})
        return _read_response_content(self._resolve(key))

    async def chat(
        self,
        *,
        messages: list[dict[str, str]],
        model: str,
        temperature: float,
        max_tokens: int | None,
        top_p: float | None,
        stop: list[str] | None,
        response_format: str | None,
        schema: type[Any] | None,
    ) -> str:
        key = _stable_key({"kind": "chat", "messages": messages})
        return _read_response_content(self._resolve(key))

    def stream(
        self,
        *,
        prompt: str,
        system: str | None,
        model: str,
        temperature: float,
        max_tokens: int | None,
        top_p: float | None,
        stop: list[str] | None,
    ) -> AsyncIterator[str]:
        raise NotImplementedError("Streaming not supported in demo mode")


@dataclass
class FixtureHTTPBackend:
    """HTTP backend that matches requests against per-file regex fixtures.

    Each file under ``<fixtures_dir>/http_responses/<index>.json`` has shape
    ``{"method": "GET", "url_pattern": "regex", "status": 200, "body": {...}}``.
    First match wins (sorted by filename for determinism). If no fixture matches,
    raise IntegrationError so the demo author sees a missing-fixture error
    rather than a real network call.
    """

    fixtures_dir: Path
    _compiled: list[tuple[str, re.Pattern[str], dict[str, Any]]] = field(
        default_factory=list, init=False, repr=False
    )
    _loaded: bool = field(default=False, init=False, repr=False)

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        responses_dir = self.fixtures_dir / "http_responses"
        if responses_dir.exists():
            for path in sorted(responses_dir.glob("*.json")):
                with path.open(encoding="utf-8") as fh:
                    data = json.load(fh)
                method = str(data.get("method", "GET")).upper()
                pattern = re.compile(str(data.get("url_pattern", "")))
                self._compiled.append((method, pattern, data))
        self._loaded = True

    async def request(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str] | None,
        params: dict[str, Any] | None,
        json: Any | None,
        data: dict[str, Any] | None,
        files: dict[str, bytes] | None,
        timeout: int | None,
    ) -> Any:
        self._ensure_loaded()
        method_upper = method.upper()
        for fixture_method, pattern, fixture in self._compiled:
            if fixture_method == method_upper and pattern.search(url):
                return fixture.get("body", {})
        raise IntegrationError(
            service="http",
            message=(
                f"No demo-mode HTTP fixture matched {method_upper} {url}. "
                f"Add a file under {self.fixtures_dir / 'http_responses'} with shape "
                f'{{"method": "{method_upper}", "url_pattern": "<regex>", "status": 200, "body": {{...}}}} '
                f"to seed the response."
            ),
        )
