"""
Module: integrations.cron
Description: Cron integration client providing schedule metadata to commands.

Implements:
    - docs/sdk/context.md#ctx-cron
    - docs/packs/manifest.md#service-reference

See Also:
    - docs/packs/manifest.md#service-reference (for manifest config)
    - docs/sdk/error-handling.md (for CronError)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol, runtime_checkable


@runtime_checkable
class CronBackend(Protocol):
    """Backend protocol for cron schedule metadata."""

    async def get_schedule(self, command_namespace: str) -> str | None:
        """Get the cron expression for a command.

        Returns:
            Cron expression string (e.g., "0 8 * * 1-5") or None if not scheduled.
        """
        ...

    async def get_next_run(self, command_namespace: str) -> datetime | None:
        """Get the next scheduled run time for a command.

        Returns:
            Next run datetime (UTC) or None if not scheduled.
        """
        ...

    async def get_last_run(self, command_namespace: str) -> datetime | None:
        """Get the last completed run time for a command.

        Returns:
            Last run datetime (UTC) or None if never run.
        """
        ...


@dataclass
class CronMetadata:
    """Metadata about the current scheduled execution.

    Available via ``ctx.cron`` when a command is triggered by the scheduler.
    Contains ``None`` values when the command is invoked on-demand.
    """

    schedule: str | None
    """Cron expression (e.g., '0 8 * * 1-5') or None for on-demand."""

    scheduled_at: datetime | None
    """When this run was scheduled to start (UTC), or None for on-demand."""

    is_scheduled: bool
    """True if this execution was triggered by the cron scheduler."""


@dataclass
class CronClient:
    """Client for accessing cron schedule metadata.

    This is the SDK-side interface. The backend injects schedule metadata
    at runtime when a command is triggered by the scheduler.
    """

    _backend: CronBackend | None = None
    _metadata: CronMetadata | None = None
    _current_namespace: str | None = None

    @property
    def schedule(self) -> str | None:
        """Cron expression for the current command, or None."""
        if self._metadata is not None:
            return self._metadata.schedule
        return None

    @property
    def scheduled_at(self) -> datetime | None:
        """When this run was scheduled (UTC), or None for on-demand."""
        if self._metadata is not None:
            return self._metadata.scheduled_at
        return None

    @property
    def is_scheduled(self) -> bool:
        """Whether this execution was triggered by the scheduler."""
        if self._metadata is not None:
            return self._metadata.is_scheduled
        return False

    async def get_next_run(self, command_namespace: str | None = None) -> datetime | None:
        """Get the next scheduled run time.

        Args:
            command_namespace: Command to query. Defaults to the current command's namespace.

        Returns:
            Next run datetime (UTC) or None if not scheduled.
        """
        if self._backend is None:
            return None
        ns = command_namespace or self._current_namespace or ""
        return await self._backend.get_next_run(ns)

    async def get_last_run(self, command_namespace: str | None = None) -> datetime | None:
        """Get the last completed run time.

        Args:
            command_namespace: Command to query. Defaults to the current command's namespace.

        Returns:
            Last run datetime (UTC) or None if never run.
        """
        if self._backend is None:
            return None
        ns = command_namespace or self._current_namespace or ""
        return await self._backend.get_last_run(ns)
