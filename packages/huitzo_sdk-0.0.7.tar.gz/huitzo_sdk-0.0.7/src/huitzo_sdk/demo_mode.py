"""
Module: demo_mode
Description: Public helpers for HUITZO_DEMO_MODE — env-driven short-circuit so packs
             run end-to-end without API keys, network access, or a real LLM.

Implements:
    - docs/sdk/integrations.md

See Also:
    - huitzo_sdk.integrations._fixture_backends (FixtureLLMBackend, FixtureHTTPBackend)
    - huitzo_sdk.context (Context auto-wires fixture backends when demo mode is on)
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

HUITZO_DEMO_MODE_ENV = "HUITZO_DEMO_MODE"
HUITZO_DEMO_FIXTURES_DIR_ENV = "HUITZO_DEMO_FIXTURES_DIR"

_TRUTHY: frozenset[str] = frozenset({"1", "true", "yes"})

_FIXTURE_CACHE: dict[str, Any] = {}


def is_demo_mode() -> bool:
    """True iff HUITZO_DEMO_MODE is set to '1', 'true', or 'yes' (case-insensitive)."""
    raw = os.environ.get(HUITZO_DEMO_MODE_ENV, "")
    return raw.strip().lower() in _TRUTHY


def fixtures_root() -> Path | None:
    """Return Path from HUITZO_DEMO_FIXTURES_DIR if set and exists, else None."""
    raw = os.environ.get(HUITZO_DEMO_FIXTURES_DIR_ENV, "")
    if not raw:
        return None
    path = Path(raw).expanduser()
    if not path.exists() or not path.is_dir():
        return None
    return path


def load_fixture(relative_path: str) -> Any:
    """Load a JSON fixture relative to fixtures_root().

    Caches in-process by absolute path. Raises FileNotFoundError if either
    the fixtures root is unset or the file does not exist.
    """
    root = fixtures_root()
    if root is None:
        raise FileNotFoundError(
            f"{HUITZO_DEMO_FIXTURES_DIR_ENV} is unset or points at a non-existent directory; "
            f"cannot load fixture {relative_path!r}."
        )
    target = (root / relative_path).resolve()
    cache_key = str(target)
    if cache_key in _FIXTURE_CACHE:
        return _FIXTURE_CACHE[cache_key]
    if not target.exists():
        raise FileNotFoundError(f"Fixture not found at {target}")
    with target.open(encoding="utf-8") as fh:
        data = json.load(fh)
    _FIXTURE_CACHE[cache_key] = data
    return data


def _clear_cache() -> None:
    """Clear the in-process fixture cache. Test-only — not part of the public API."""
    _FIXTURE_CACHE.clear()
