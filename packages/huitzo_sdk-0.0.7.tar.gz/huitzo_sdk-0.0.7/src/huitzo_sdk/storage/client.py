"""
Module: storage.client
Description: Unified storage client combining key scoping with I/O operations.

Implements:
    - docs/sdk/storage.md#overview
    - docs/sdk/storage.md#core-methods
    - docs/sdk/context.md#ctx-storage

See Also:
    - docs/sdk/storage-backends.md (for backend protocol)
    - docs/sdk/storage.md#automatic-scoping (for namespace logic)
"""

from __future__ import annotations

import builtins
import re
from contextlib import AbstractAsyncContextManager
from typing import Any

from huitzo_sdk.storage.namespace import StorageNamespace
from huitzo_sdk.storage.protocol import StorageBackend

# Keys must be 1–256 chars of safe characters (no scope delimiter `:`)
_VALID_KEY_RE = re.compile(r"^[a-zA-Z0-9_\-./]{1,256}$")
_MAX_KEY_LENGTH = 256


class StorageClient:
    """Unified interface for scoped storage operations.

    Wraps a ``StorageBackend`` and ``StorageNamespace`` so that every
    key is automatically scoped by tenant/user/pack before reaching the
    backend.  This is the object exposed as ``ctx.storage``.

    .. note::

        Instances are **not safe for concurrent use** across multiple
        coroutines.  Each command execution receives its own ``Context``
        (and thus its own ``StorageClient``), so this is not an issue
        in normal pack development.

    Usage::

        await ctx.storage.save("my-key", {"data": 1})
        value = await ctx.storage.get("my-key", default={})
        await ctx.storage.delete("my-key")
    """

    __slots__ = ("_backend", "_namespace")

    def __init__(self, backend: StorageBackend, namespace: StorageNamespace) -> None:
        self._backend = backend
        self._namespace = namespace

    # -- read-only accessors --------------------------------------------------

    @property
    def namespace(self) -> StorageNamespace:
        """The underlying namespace used for key scoping."""
        return self._namespace

    @property
    def backend(self) -> StorageBackend:
        """The underlying storage backend."""
        return self._backend

    # -- key validation -------------------------------------------------------

    @staticmethod
    def _validate_key(key: str) -> None:
        """Validate a user-supplied storage key.

        Raises:
            ValueError: If the key is empty, too long, or contains
                illegal characters (including the ``:`` scope delimiter).
        """
        if not key:
            raise ValueError("Storage key must not be empty.")
        if len(key) > _MAX_KEY_LENGTH:
            raise ValueError(f"Storage key exceeds {_MAX_KEY_LENGTH} characters: {len(key)}")
        if not _VALID_KEY_RE.match(key):
            raise ValueError(
                f"Invalid storage key {key!r}: must contain only "
                "alphanumeric, dash, underscore, dot, or slash characters."
            )

    # -- core operations ------------------------------------------------------

    async def save(
        self,
        key: str,
        value: Any,
        *,
        scope: str = "user",
        ttl: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Save a value to scoped storage.

        Args:
            key: The user-provided key (will be auto-scoped).
            value: JSON-serializable value.
            scope: Scope level - ``"user"`` (default), ``"tenant"``, or ``"pack"``.

                .. warning:: ``scope="tenant"`` has **no pack component** in its key.
                   All packs within the same tenant share the same key space for this
                   scope.  Using a common key name (e.g. ``"config"``) with
                   ``scope="tenant"`` will silently overwrite another pack's data.
                   Prefer ``scope="pack"`` for pack-private data, or use a unique
                   pack-prefixed key (e.g. ``"my-pack/config"``) when sharing across
                   packs is intentional.
            ttl: Time-to-live in seconds.
            metadata: Optional metadata for querying.

        Returns:
            The scoped storage key.
        """
        self._validate_key(key)
        scoped = self._namespace.scope_key(key, scope)
        return await self._backend.save(scoped, value, ttl=ttl, metadata=metadata)

    async def get(
        self,
        key: str,
        *,
        scope: str = "user",
        default: Any = None,
    ) -> Any:
        """Retrieve a value from scoped storage.

        Args:
            key: The user-provided key.
            scope: Scope level.
            default: Value returned if key not found.

        Returns:
            The stored value, or *default* if not found.
        """
        self._validate_key(key)
        scoped = self._namespace.scope_key(key, scope)
        return await self._backend.get(scoped, default=default)

    async def delete(self, key: str, *, scope: str = "user") -> bool:
        """Delete a value from scoped storage.

        Returns:
            True if deleted, False if not found.
        """
        self._validate_key(key)
        scoped = self._namespace.scope_key(key, scope)
        return await self._backend.delete(scoped)

    async def exists(self, key: str, *, scope: str = "user") -> bool:
        """Check if a key exists in scoped storage."""
        self._validate_key(key)
        scoped = self._namespace.scope_key(key, scope)
        return await self._backend.exists(scoped)

    async def list(
        self,
        prefix: str = "",
        *,
        scope: str = "user",
        limit: int = 100,
        offset: int = 0,
    ) -> builtins.list[str]:
        """List keys matching a scoped prefix.

        Args:
            prefix: Key prefix to match (will be auto-scoped).
            scope: Scope level.
            limit: Maximum number of keys to return.
            offset: Pagination offset.

        Returns:
            List of fully-scoped keys.
        """
        scoped_prefix = self._namespace.scope_prefix(prefix, scope)
        return await self._backend.list(scoped_prefix, limit=limit, offset=offset)

    # -- batch operations -----------------------------------------------------

    async def save_many(
        self,
        items: dict[str, Any],
        *,
        scope: str = "user",
        ttl: int | None = None,
    ) -> None:
        """Save multiple key-value pairs with automatic scoping."""
        for k in items:
            self._validate_key(k)
        scoped = {self._namespace.scope_key(k, scope): v for k, v in items.items()}
        await self._backend.save_many(scoped, ttl=ttl)

    async def get_many(
        self,
        keys: builtins.list[str],
        *,
        scope: str = "user",
    ) -> dict[str, Any]:
        """Retrieve multiple values with automatic scoping.

        Returns:
            Dictionary mapping *original* (unscoped) keys to values.
        """
        for k in keys:
            self._validate_key(k)
        scoped_keys = [self._namespace.scope_key(k, scope) for k in keys]
        scoped_results = await self._backend.get_many(scoped_keys)
        # Map back to original keys — use .get() for defensive access
        return {orig: scoped_results.get(scoped) for orig, scoped in zip(keys, scoped_keys)}

    async def delete_many(
        self,
        keys: builtins.list[str],
        *,
        scope: str = "user",
    ) -> int:
        """Delete multiple keys with automatic scoping.

        Returns:
            Number of keys actually deleted.
        """
        for k in keys:
            self._validate_key(k)
        scoped_keys = [self._namespace.scope_key(k, scope) for k in keys]
        return await self._backend.delete_many(scoped_keys)

    # -- advanced operations --------------------------------------------------

    async def query(
        self,
        prefix: str = "",
        *,
        scope: str = "user",
        metadata: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> builtins.list[dict[str, Any]]:
        """Query storage by scoped prefix and metadata filters.

        Returns:
            List of records with key, value, and metadata.
        """
        scoped_prefix = self._namespace.scope_prefix(prefix, scope)
        return await self._backend.query(scoped_prefix, metadata=metadata, limit=limit)

    def transaction(self) -> AbstractAsyncContextManager[None]:
        """Begin an atomic transaction on the underlying backend."""
        return self._backend.transaction()

    # -- scoping helpers (delegate to namespace) ------------------------------

    def scope_key(self, key: str, scope: str = "user") -> str:
        """Build a fully-scoped storage key without performing I/O."""
        return self._namespace.scope_key(key, scope)

    def scope_prefix(self, prefix: str, scope: str = "user") -> str:
        """Build a scoped prefix without performing I/O."""
        return self._namespace.scope_prefix(prefix, scope)
