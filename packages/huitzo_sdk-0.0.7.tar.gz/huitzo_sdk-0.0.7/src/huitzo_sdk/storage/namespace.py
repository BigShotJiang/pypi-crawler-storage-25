"""
Module: storage.namespace
Description: Key scoping for tenant-isolated storage.

Implements:
    - docs/sdk/storage.md#automatic-scoping
    - docs/sdk/storage.md#scope-levels

See Also:
    - docs/sdk/storage-backends.md (for backend protocol)
"""

from __future__ import annotations

from dataclasses import dataclass
from uuid import UUID


@dataclass(frozen=True)
class StorageNamespace:
    """Builds scoped storage keys for tenant isolation.

    Keys are scoped as:
        user scope:   tenant:{tenant_id}:user:{user_id}:pack:{pack_id}:{key}
        tenant scope: tenant:{tenant_id}:{key}
        pack scope:   tenant:{tenant_id}:pack:{pack_id}:{key}

    Note: ``tenant`` scope contains **no pack component** — all packs within the
    same tenant share the same key space.  Callers must use unique key prefixes
    or choose ``pack`` scope to avoid cross-pack key collisions.
    """

    tenant_id: UUID
    user_id: UUID
    pack_id: str

    def scope_key(self, key: str, scope: str = "user") -> str:
        """Build a fully-scoped storage key.

        Args:
            key: The user-provided key.
            scope: Scope level - "user" (default), "tenant", or "pack".

        Returns:
            The scoped key string.

        Raises:
            ValueError: If scope is invalid.
        """
        if scope == "user":
            return f"tenant:{self.tenant_id}:user:{self.user_id}:pack:{self.pack_id}:{key}"
        if scope == "tenant":
            return f"tenant:{self.tenant_id}:{key}"
        if scope == "pack":
            return f"tenant:{self.tenant_id}:pack:{self.pack_id}:{key}"
        raise ValueError(f"Invalid scope: {scope!r}. Must be 'user', 'tenant', or 'pack'.")

    def scope_prefix(self, prefix: str, scope: str = "user") -> str:
        """Build a scoped prefix for listing keys.

        Args:
            prefix: The user-provided prefix.
            scope: Scope level.

        Returns:
            The scoped prefix string.
        """
        return self.scope_key(prefix, scope)
