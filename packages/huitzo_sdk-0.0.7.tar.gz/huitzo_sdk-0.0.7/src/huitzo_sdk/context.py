"""
Module: context
Description: Context object passed to every command with identity, metadata, and platform services.

Implements:
    - docs/sdk/context.md#context-properties
    - docs/sdk/context.md#services
    - docs/sdk/integrations.md

See Also:
    - docs/sdk/commands.md (for command patterns)
    - docs/sdk/storage.md (for storage API)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from uuid import UUID, uuid4

from huitzo_sdk.commands_service import CommandsClient
from huitzo_sdk.errors import ConfigurationError, IntegrationError
from huitzo_sdk.integrations.cron import CronClient
from huitzo_sdk.integrations.db import DBClient
from huitzo_sdk.integrations.email import EmailClient
from huitzo_sdk.integrations.files import FileClient
from huitzo_sdk.integrations.http import HTTPClient
from huitzo_sdk.integrations.llm import LLMClient
from huitzo_sdk.integrations.log import LogClient
from huitzo_sdk.integrations.ssh import SSHClient
from huitzo_sdk.integrations.secrets import SecretsClient
from huitzo_sdk.integrations.telegram import TelegramClient
from huitzo_sdk.storage.client import StorageClient
from huitzo_sdk.types import DeploymentMode

# Sentinel UUID used when the runtime has not injected a real identity value.
# Storage access is blocked when any identity field holds this value.
_UNSET_UUID = UUID("00000000-0000-0000-0000-000000000000")


_NOT_WIRED = "not available. This integration is injected by the Huitzo backend at runtime."

# Services not yet available in this SDK version
_FUTURE_STUBS: dict[str, str] = {
    "env": "Environment access is not yet available in this SDK version.",
    "config": "Configuration access is not yet available in this SDK version.",
    "local_storage": "Local storage is not yet available in this SDK version.",
    "inference_backend": "Inference backend is not yet available in this SDK version.",
}


@dataclass
class Context:
    """Context object passed to every command execution.

    Provides identity, metadata, and access to platform services.
    """

    # Identity — injected by the Huitzo runtime. Defaults are sentinels; storage
    # access raises ConfigurationError if the runtime failed to inject real values.
    user_id: UUID = field(default=_UNSET_UUID)
    tenant_id: UUID = field(default=_UNSET_UUID)
    session_id: UUID = field(default=_UNSET_UUID)
    correlation_id: str = field(default_factory=lambda: str(uuid4()))

    # Command metadata
    command_name: str = ""
    namespace: str = ""
    command_version: str = "1.0.0"
    deployment_mode: DeploymentMode = DeploymentMode.CLOUD

    # Integration clients (injected by backend at runtime)
    _llm: LLMClient | None = field(default=None, repr=False)
    _email: EmailClient | None = field(default=None, repr=False)
    _http: HTTPClient | None = field(default=None, repr=False)
    _telegram: TelegramClient | None = field(default=None, repr=False)
    _files: FileClient | None = field(default=None, repr=False)
    _ssh: SSHClient | None = field(default=None, repr=False)
    _db: DBClient | None = field(default=None, repr=False)
    _storage: StorageClient | None = field(default=None, repr=False)
    _commands: CommandsClient | None = field(default=None, repr=False)
    _secrets: SecretsClient | None = field(default=None, repr=False)
    _log: LogClient | None = field(default=None, repr=False)
    _cron: CronClient | None = field(default=None, repr=False)
    _mcp: Any | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        # Auto-wire fixture-backed LLM and HTTP clients when HUITZO_DEMO_MODE is on
        # and a fixtures directory is configured. This lets demo packs run
        # offline without API keys. Production wiring (where backends are
        # explicitly injected) is preserved because we only fill in unset slots.
        from huitzo_sdk.demo_mode import fixtures_root, is_demo_mode

        if not is_demo_mode():
            return
        root = fixtures_root()
        if root is None:
            return

        from huitzo_sdk.integrations._fixture_backends import (
            FixtureHTTPBackend,
            FixtureLLMBackend,
        )

        if self._llm is None:
            self._llm = LLMClient(
                _backend=FixtureLLMBackend(
                    fixtures_dir=root,
                    command_namespace=self.namespace or None,
                )
            )
        if self._http is None:
            self._http = HTTPClient(
                _backend=FixtureHTTPBackend(fixtures_dir=root),
                _allowed_domains=["*"],
                _allow_localhost=True,
            )

    @property
    def cron(self) -> CronClient:
        """Cron schedule metadata client."""
        if self._cron is None:
            raise IntegrationError(service="cron", message=f"ctx.cron is {_NOT_WIRED}")
        return self._cron

    @property
    def llm(self) -> LLMClient:
        """LLM integration client."""
        if self._llm is None:
            raise IntegrationError(service="llm", message=f"ctx.llm is {_NOT_WIRED}")
        return self._llm

    @property
    def email(self) -> EmailClient:
        """Email integration client."""
        if self._email is None:
            raise IntegrationError(service="email", message=f"ctx.email is {_NOT_WIRED}")
        return self._email

    @property
    def http(self) -> HTTPClient:
        """HTTP integration client."""
        if self._http is None:
            raise IntegrationError(service="http", message=f"ctx.http is {_NOT_WIRED}")
        return self._http

    @property
    def telegram(self) -> TelegramClient:
        """Telegram integration client."""
        if self._telegram is None:
            raise IntegrationError(service="telegram", message=f"ctx.telegram is {_NOT_WIRED}")
        return self._telegram

    @property
    def files(self) -> FileClient:
        """File integration client."""
        if self._files is None:
            raise IntegrationError(service="files", message=f"ctx.files is {_NOT_WIRED}")
        return self._files

    @property
    def ssh(self) -> SSHClient:
        """SSH integration client."""
        if self._ssh is None:
            raise IntegrationError(service="ssh", message=f"ctx.ssh is {_NOT_WIRED}")
        return self._ssh

    @property
    def db(self) -> DBClient:
        """Database integration client (Postgres / MySQL).

        Wired by the runtime when the pack manifest declares ``services: [db]``
        and the tenant has at least one ``postgres`` or ``mysql`` Integration row
        visible to the executing user.
        """
        if self._db is None:
            raise IntegrationError(service="db", message=f"ctx.db is {_NOT_WIRED}")
        return self._db

    @property
    def storage(self) -> StorageClient:
        """Unified storage client for scoped key-value operations.

        Returns a ``StorageClient`` that automatically scopes all keys
        by tenant, user, and pack.  Supports ``save``, ``get``,
        ``delete``, ``exists``, ``list``, batch operations, and
        transactions.
        """
        if self._storage is None:
            raise IntegrationError(
                service="storage",
                message=f"ctx.storage is {_NOT_WIRED}",
            )
        if self.tenant_id == _UNSET_UUID or self.user_id == _UNSET_UUID:
            raise ConfigurationError(
                message=(
                    "Context identity (tenant_id, user_id) must be set before accessing storage. "
                    "The runtime failed to inject proper identity fields."
                )
            )
        return self._storage

    @property
    def commands(self) -> CommandsClient:
        """Intra-pack command execution service."""
        if self._commands is None:
            raise IntegrationError(
                service="commands",
                message=f"ctx.commands is {_NOT_WIRED}",
            )
        return self._commands

    @property
    def secrets(self) -> SecretsClient:
        """Secrets integration client for accessing user-configured secrets."""
        if self._secrets is None:
            raise IntegrationError(
                service="secrets",
                message=f"ctx.secrets is {_NOT_WIRED}",
            )
        return self._secrets

    @property
    def log(self) -> LogClient:
        """Structured logging client."""
        if self._log is None:
            raise IntegrationError(
                service="log",
                message=f"ctx.log is {_NOT_WIRED}",
            )
        return self._log

    @property
    def mcp(self) -> Any:
        """MCP (Model Context Protocol) integration client."""
        if self._mcp is None:
            raise IntegrationError(
                service="mcp",
                message=f"ctx.mcp is {_NOT_WIRED}",
            )
        return self._mcp

    async def execute(
        self,
        pack: str,
        command: str,
        args: dict[str, Any] | None = None,
        *,
        timeout: int | None = None,
    ) -> Any:
        """Execute a command in another pack (pack-to-pack execution).

        This is injected by the Huitzo backend at runtime.

        Args:
            pack: Target pack namespace.
            command: Command name within the target pack.
            args: Arguments dict to pass to the command.
            timeout: Optional timeout override in seconds.

        Raises:
            IntegrationError: Always — this method requires the Huitzo runtime.
        """
        raise IntegrationError(
            service="execute",
            message="ctx.execute() is " + _NOT_WIRED,
        )

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(f"'Context' has no attribute '{name}'")
        if name in _FUTURE_STUBS:
            raise ConfigurationError(
                message=f"ctx.{name} is not yet available in this SDK version."
            )
        raise AttributeError(f"'Context' has no attribute '{name}'")
