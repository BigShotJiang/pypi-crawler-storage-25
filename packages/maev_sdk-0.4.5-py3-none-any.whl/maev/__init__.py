"""Maev SDK — two lines to make any AI agent self-healing and self-improving.

Usage::

    import maev
    maev.run(agent)

Set your API key via environment variable (recommended)::

    export MAEV_API_KEY="vl_xxx"

Or pass it directly::

    maev.run(agent, api_key="vl_xxx")

Get your key at: https://home.maev.dev/dashboard/settings
"""

from __future__ import annotations

from typing import Any, List, Optional

__version__ = "0.4.5"
__all__ = ["run", "flush"]


def flush() -> None:
    """Force delivery of all buffered telemetry before process exit.

    Required in serverless environments (AWS Lambda, Google Cloud Functions,
    Vercel Functions) where the process is frozen immediately after the handler
    returns. Safe to call multiple times — only the first call does anything.
    """
    from maev.runner import flush as _flush
    _flush()


def run(
    agent: Any,
    /,
    *args: Any,
    api_key: Optional[str] = None,
    agent_name: Optional[str] = None,
    endpoint: str = "https://home.maev.dev",
    cost_budget: float = 1.0,
    max_calls: int = 50,
    max_duration_s: float = 300.0,
    fallback_models: Optional[List[str]] = None,
    **kwargs: Any,
) -> Any:
    """Wrap any AI agent with observability, self-healing, and self-improving.

    Parameters
    ----------
    agent:
        Any callable or agent framework object (LangChain, CrewAI, custom).
        If callable, Maev executes it with *args/**kwargs and returns the result.
        If an agent object (has .run/.kickoff/.invoke), Maev patches it in-place
        and returns it — the developer still calls it themselves.
    api_key:
        Maev API key (starts with 'vl_'). Required — pass here or set
        MAEV_API_KEY environment variable.
    agent_name:
        Human-readable name shown in the dashboard. Auto-detected if omitted.
        Can also be set via MAEV_AGENT_NAME environment variable.
    endpoint:
        Override the Maev ingest URL. Leave unset unless self-hosting.
    cost_budget:
        Max USD to spend per run before halting. Default $1.00.
    max_calls:
        Max LLM calls per run before halting. Default 50.
    max_duration_s:
        Max wall-clock seconds per run before halting. Default 300.
    fallback_models:
        Ordered list of fallback model IDs to try when the primary fails.
        Example: ["claude-3-5-sonnet-20241022", "gpt-4o-mini"]

    What Maev does automatically
    ----------------------------
    Observability:
        Every LLM call, tool call, token count, cost, and latency is traced
        and visible in the Maev dashboard.

    Self-healing (Level 1 — immediate, no data needed):
        - Automatic retry with exponential backoff on rate limits / transient errors
        - Empty response detection with temperature nudge and retry
        - Cost circuit breaker — halts run if budget is exceeded
        - Call count circuit breaker — halts run if max_calls exceeded
        - Duration circuit breaker — halts run if max_duration_s exceeded
        - Infinite loop detection — halts run if same prompt repeated 3+ times
        - Model fallback — routes to fallback_models on primary model failure

    Self-improving (Level 2 — grows with data, after ~20 runs):
        - Records (prompt_pattern, model, failure_type, strategy, outcome) per call
        - Fetches learned strategies from Maev backend at startup
        - Applies highest-confidence strategies automatically on known failure patterns
        - Strategies scoped: this agent → your org → all Maev agents (global)

    Raises
    ------
    ValueError
        If no valid API key is provided (missing or doesn't start with 'vl_').
    maev.interceptors.circuit.CircuitBrokenError
        If a circuit breaker trips (cost, call count, or duration exceeded).
    maev.interceptors.loop_detector.LoopDetectedError
        If the agent appears stuck in an infinite loop.
    """
    from maev.runner import run as _run

    return _run(
        agent,
        *args,
        api_key=api_key,
        agent_name=agent_name,
        endpoint=endpoint,
        cost_budget=cost_budget,
        max_calls=max_calls,
        max_duration_s=max_duration_s,
        fallback_models=fallback_models,
        **kwargs,
    )
