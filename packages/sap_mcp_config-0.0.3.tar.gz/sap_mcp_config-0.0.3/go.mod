module github.com/Hochfrequenz/sap-mcp-config

go 1.25

require (
	github.com/joho/godotenv v1.5.1
	github.com/stretchr/testify v1.11.1
	gopkg.in/yaml.v3 v3.0.1
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
)
