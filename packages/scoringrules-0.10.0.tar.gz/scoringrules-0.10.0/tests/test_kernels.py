import numpy as np
import pytest
import scoringrules as sr
from scoringrules.backend import backends


ENSEMBLE_SIZE = 11
N = 10
N_VARS = 3

ESTIMATORS = ["nrg", "fair", "akr", "akr_circperm"]


@pytest.mark.parametrize("estimator", ESTIMATORS)
def test_gksuv(estimator, backend):
    obs = np.random.randn(N)
    mu = obs + np.random.randn(N) * 0.1
    sigma = abs(np.random.randn(N)) * 0.3
    fct = np.random.randn(N, ENSEMBLE_SIZE) * sigma[..., None] + mu[..., None]

    # undefined estimator
    with pytest.raises(ValueError):
        est = "undefined_estimator"
        sr.gksuv_ensemble(obs, fct, estimator=est, backend=backend)

    # m_axis keyword
    res = sr.gksuv_ensemble(obs, fct, estimator=estimator, backend=backend)
    res2 = sr.gksuv_ensemble(obs, fct.T, m_axis=0, estimator=estimator, backend=backend)
    assert np.allclose(res, res2)

    if estimator == "nrg":
        # non-negative values
        res = sr.gksuv_ensemble(obs, fct, estimator=estimator, backend=backend)
        res = np.asarray(res)
        assert not np.any(res < 0.0)

        # m_axis keyword
        res = sr.gksuv_ensemble(
            obs,
            np.random.randn(ENSEMBLE_SIZE, N),
            m_axis=0,
            estimator=estimator,
            backend=backend,
        )
        res = np.asarray(res)
        assert not np.any(res < 0.0)

        # approx zero when perfect forecast
        perfect_fct = obs[..., None] + np.random.randn(N, ENSEMBLE_SIZE) * 0.00001
        res = sr.gksuv_ensemble(obs, perfect_fct, estimator=estimator, backend=backend)
        res = np.asarray(res)
        assert not np.any(res - 0.0 > 0.0001)

    # test correctness
    obs, fct = 11.6, np.array([9.8, 8.7, 11.9, 12.1, 13.4])

    if estimator == "nrg":
        res = sr.gksuv_ensemble(obs, fct, estimator=estimator, backend=backend)
        expected = 0.2490516
        assert np.isclose(res, expected)

    elif estimator == "fair":
        res = sr.gksuv_ensemble(obs, fct, estimator=estimator, backend=backend)
        expected = 0.1737752
        assert np.isclose(res, expected)

    elif estimator == "akr":
        res = sr.gksuv_ensemble(obs, fct, estimator=estimator, backend=backend)
        expected = 0.2464915
        assert np.isclose(res, expected)

    elif estimator == "akr_circperm":
        res = sr.gksuv_ensemble(obs, fct, estimator=estimator, backend=backend)
        expected = 0.1010588
        assert np.isclose(res, expected)


@pytest.mark.parametrize("estimator", ESTIMATORS)
def test_gksmv(estimator, backend):
    obs = np.random.randn(N, N_VARS)
    fct = np.expand_dims(obs, axis=-2) + np.random.randn(N, ENSEMBLE_SIZE, N_VARS)

    # undefined estimator
    with pytest.raises(ValueError):
        est = "undefined_estimator"
        sr.gksmv_ensemble(obs, fct, estimator=est, backend=backend)

    res = sr.gksmv_ensemble(obs, fct, estimator=estimator, backend=backend)

    if backend in ["numpy", "numba"]:
        assert isinstance(res, np.ndarray)
    elif backend == "jax":
        assert "jax" in res.__module__

    # approx zero when perfect forecast
    if estimator == "nrg":
        perfect_fct = (
            np.expand_dims(obs, axis=-2)
            + np.random.randn(N, ENSEMBLE_SIZE, N_VARS) * 0.00001
        )
        res = sr.gksmv_ensemble(obs, perfect_fct, estimator=estimator, backend=backend)
        res = np.asarray(res)
        assert not np.any(res - 0.0 > 0.0001)

    # test correctness
    obs = np.array([11.6, -23.1])
    fct = np.array(
        [[9.8, 8.7, 11.9, 12.1, 13.4], [-24.8, -18.5, -29.9, -18.3, -21.0]]
    ).transpose()

    # test exceptions
    with pytest.raises(ValueError):
        est = "undefined_estimator"
        sr.gksmv_ensemble(obs, fct, estimator=est, backend=backend)

    with pytest.raises(ValueError):
        est = "undefined_estimator"
        sr.gksmv_ensemble(obs, fct, estimator=est, backend=backend)

    if estimator == "nrg":
        res = sr.gksmv_ensemble(obs, fct, estimator=estimator, backend=backend)
        expected = 0.5868737
        assert np.isclose(res, expected)

    elif estimator == "fair":
        res = sr.gksmv_ensemble(obs, fct, estimator=estimator, backend=backend)
        expected = 0.4870162
        assert np.isclose(res, expected)

    elif estimator == "akr":
        res = sr.gksmv_ensemble(obs, fct, estimator=estimator, backend=backend)
        expected = 0.4874259
        assert np.isclose(res, expected)

    elif estimator == "akr_circperm":
        res = sr.gksmv_ensemble(obs, fct, estimator=estimator, backend=backend)
        expected = 0.4866066
        assert np.isclose(res, expected)


@pytest.mark.parametrize("estimator", ESTIMATORS)
def test_twgksuv(estimator, backend):
    if backend == "jax":
        pytest.skip("Not implemented in jax backend")
    obs = np.random.randn(N)
    mu = obs + np.random.randn(N) * 0.1
    sigma = abs(np.random.randn(N)) * 0.3
    fct = np.random.randn(N, ENSEMBLE_SIZE) * sigma[..., None] + mu[..., None]

    res = sr.gksuv_ensemble(obs, fct, backend=backend, estimator=estimator)

    # no argument given
    resw = sr.twgksuv_ensemble(obs, fct, estimator=estimator, backend=backend)
    np.testing.assert_allclose(res, resw, rtol=1e-10)

    # a and b
    resw = sr.twgksuv_ensemble(
        obs, fct, a=float("-inf"), b=float("inf"), estimator=estimator, backend=backend
    )
    np.testing.assert_allclose(res, resw, rtol=1e-10)

    # v_func as identity function
    resw = sr.twgksuv_ensemble(
        obs, fct, v_func=lambda x: x, estimator=estimator, backend=backend
    )
    np.testing.assert_allclose(res, resw, rtol=1e-10)

    # test correctness
    fct = np.array(
        [
            [-0.03574194, 0.06873582, 0.03098684, 0.07316138, 0.08498165],
            [-0.11957874, 0.26472238, -0.06324622, 0.43026451, -0.25640457],
            [-1.31340831, -1.43722153, -1.01696021, -0.70790148, -1.20432392],
            [1.26054027, 1.03477874, 0.61688454, 0.75305795, 1.19364529],
            [0.63192933, 0.33521695, 0.20626017, 0.43158264, 0.69518928],
            [0.83305233, 0.71965134, 0.96687378, 1.0000473, 0.82714425],
            [0.0128655, 0.03849841, 0.02459106, -0.02618909, 0.18687008],
            [-0.69399216, -0.59432627, -1.43629972, 0.01979857, -0.3286767],
            [1.92958764, 2.2678255, 1.86036922, 1.84766384, 2.03331138],
            [0.80847492, 1.11265193, 0.58995365, 1.04838184, 1.10439277],
        ]
    )

    obs = np.array(
        [
            0.19640722,
            -0.11300369,
            -1.0400268,
            0.84306533,
            0.36572078,
            0.82487264,
            0.14088773,
            -0.51936113,
            1.70706264,
            0.75985908,
        ]
    )

    def v_func1(x):
        return np.maximum(x, -1.0)

    def v_func2(x):
        return np.minimum(x, 1.85)

    if estimator == "nrg":
        res = np.mean(
            np.float64(
                sr.twgksuv_ensemble(
                    obs, fct, v_func=v_func1, estimator=estimator, backend=backend
                )
            )
        )
        np.testing.assert_allclose(res, 0.01018774, rtol=1e-6)

        res = np.mean(
            np.float64(
                sr.twgksuv_ensemble(
                    obs, fct, a=-1.0, estimator=estimator, backend=backend
                )
            )
        )
        np.testing.assert_allclose(res, 0.01018774, rtol=1e-6)

        res = np.mean(
            np.float64(
                sr.twgksuv_ensemble(
                    obs, fct, v_func=v_func2, estimator=estimator, backend=backend
                )
            )
        )
        np.testing.assert_allclose(res, 0.0089314, rtol=1e-6)

        res = np.mean(
            np.float64(
                sr.twgksuv_ensemble(
                    obs, fct, b=1.85, estimator=estimator, backend=backend
                )
            )
        )
        np.testing.assert_allclose(res, 0.0089314, rtol=1e-6)


def test_twgksmv(backend):
    if backend == "jax":
        pytest.skip("Not implemented in jax backend")
    obs = np.random.randn(N, N_VARS)
    fct = np.expand_dims(obs, axis=-2) + np.random.randn(N, ENSEMBLE_SIZE, N_VARS)

    res0 = sr.gksmv_ensemble(obs, fct, backend=backend)
    res = sr.twgksmv_ensemble(obs, fct, lambda x: x, backend=backend)
    np.testing.assert_allclose(res, res0, rtol=1e-6)

    fct = np.array(
        [[0.79546742, 0.4777960, 0.2164079], [0.02461368, 0.7584595, 0.3181810]]
    ).T
    obs = np.array([0.2743836, 0.8146400])

    def v_func(x):
        return np.maximum(x, 0.2)

    res = sr.twgksmv_ensemble(obs, fct, v_func, backend=backend)
    np.testing.assert_allclose(res, 0.08671498, rtol=1e-6)

    def v_func(x):
        return np.minimum(x, 1)

    res = sr.twgksmv_ensemble(obs, fct, v_func, backend=backend)
    np.testing.assert_allclose(res, 0.1016436, rtol=1e-6)


def test_owgksuv(backend):
    if backend == "jax":
        pytest.skip("Not implemented in jax backend")
    obs = np.random.randn(N)
    mu = obs + np.random.randn(N) * 0.1
    sigma = abs(np.random.randn(N)) * 0.3
    fct = np.random.randn(N, ENSEMBLE_SIZE) * sigma[..., None] + mu[..., None]

    # m_axis keyword
    res = sr.owgksuv_ensemble(
        obs,
        np.random.randn(ENSEMBLE_SIZE, N),
        w_func=lambda x: x * 0.0 + 1.0,
        m_axis=0,
        backend=backend,
    )
    res = np.asarray(res)
    assert not np.any(res < 0.0)

    res = sr.gksuv_ensemble(obs, fct, backend=backend, estimator="nrg")

    # no argument given
    resw = sr.owgksuv_ensemble(obs, fct, backend=backend)
    np.testing.assert_allclose(res, resw, atol=1e-6)

    # a and b
    resw = sr.owgksuv_ensemble(
        obs, fct, a=float("-inf"), b=float("inf"), backend=backend
    )
    np.testing.assert_allclose(res, resw, atol=1e-6)

    # w_func as identity function
    resw = sr.owgksuv_ensemble(
        obs, fct, w_func=lambda x: x * 0.0 + 1.0, backend=backend
    )
    np.testing.assert_allclose(res, resw, atol=1e-6)

    # test correctness
    fct = np.array(
        [
            [-0.03574194, 0.06873582, 0.03098684, 0.07316138, 0.08498165],
            [-0.11957874, 0.26472238, -0.06324622, 0.43026451, -0.25640457],
            [-1.31340831, -1.43722153, -1.01696021, -0.70790148, -1.20432392],
            [1.26054027, 1.03477874, 0.61688454, 0.75305795, 1.19364529],
            [0.63192933, 0.33521695, 0.20626017, 0.43158264, 0.69518928],
            [0.83305233, 0.71965134, 0.96687378, 1.0000473, 0.82714425],
            [0.0128655, 0.03849841, 0.02459106, -0.02618909, 0.18687008],
            [-0.69399216, -0.59432627, -1.43629972, 0.01979857, -0.3286767],
            [1.92958764, 2.2678255, 1.86036922, 1.84766384, 2.03331138],
            [0.80847492, 1.11265193, 0.58995365, 1.04838184, 1.10439277],
        ]
    )

    obs = np.array(
        [
            0.19640722,
            -0.11300369,
            -1.0400268,
            0.84306533,
            0.36572078,
            0.82487264,
            0.14088773,
            -0.51936113,
            1.70706264,
            0.75985908,
        ]
    )

    def w_func(x):
        return (x > -1) * 1.0

    res = np.mean(
        np.float64(sr.owgksuv_ensemble(obs, fct, w_func=w_func, backend=backend))
    )
    np.testing.assert_allclose(res, 0.01036335, rtol=1e-5)

    res = np.mean(np.float64(sr.owgksuv_ensemble(obs, fct, a=-1.0, backend=backend)))
    np.testing.assert_allclose(res, 0.01036335, rtol=1e-5)

    def w_func(x):
        return (x < 1.85) * 1.0

    res = np.mean(
        np.float64(sr.owgksuv_ensemble(obs, fct, w_func=w_func, backend=backend))
    )
    np.testing.assert_allclose(res, 0.008905213, rtol=1e-5)

    res = np.mean(np.float64(sr.owgksuv_ensemble(obs, fct, b=1.85, backend=backend)))
    np.testing.assert_allclose(res, 0.008905213, rtol=1e-5)


def test_owgksmv(backend):
    if backend == "jax":
        pytest.skip("Not implemented in jax backend")
    obs = np.random.randn(N, N_VARS)
    fct = np.expand_dims(obs, axis=-2) + np.random.randn(N, ENSEMBLE_SIZE, N_VARS)

    res0 = sr.gksmv_ensemble(obs, fct, backend=backend)
    res = sr.owgksmv_ensemble(
        obs, fct, lambda x: backends[backend].mean(x) * 0.0 + 1.0, backend=backend
    )
    np.testing.assert_allclose(res, res0, rtol=1e-6)

    fct = np.array(
        [[0.79546742, 0.4777960, 0.2164079], [0.02461368, 0.7584595, 0.3181810]]
    ).T
    obs = np.array([0.2743836, 0.8146400])

    def w_func(x):
        return backends[backend].all(x > 0.2)

    res = sr.owgksmv_ensemble(obs, fct, w_func, backend=backend)
    np.testing.assert_allclose(res, 0.03901075, rtol=1e-5)

    def w_func(x):
        return backends[backend].all(x < 1.0)

    res = sr.owgksmv_ensemble(obs, fct, w_func, backend=backend)
    np.testing.assert_allclose(res, 0.1016436, rtol=1e-6)


def test_vrgksuv(backend):
    if backend == "jax":
        pytest.skip("Not implemented in jax backend")
    obs = np.random.randn(N)
    mu = obs + np.random.randn(N) * 0.1
    sigma = abs(np.random.randn(N)) * 0.3
    fct = np.random.randn(N, ENSEMBLE_SIZE) * sigma[..., None] + mu[..., None]

    # m_axis keyword
    res = sr.vrgksuv_ensemble(
        obs,
        np.random.randn(ENSEMBLE_SIZE, N),
        w_func=lambda x: x * 0.0 + 1.0,
        m_axis=0,
        backend=backend,
    )
    res = np.asarray(res)
    assert not np.any(res < 0.0)

    res = sr.gksuv_ensemble(obs, fct, backend=backend, estimator="nrg")

    # no argument given
    resw = sr.vrgksuv_ensemble(obs, fct, backend=backend)
    np.testing.assert_allclose(res, resw, rtol=1e-5)

    # a and b
    resw = sr.vrgksuv_ensemble(
        obs, fct, a=float("-inf"), b=float("inf"), backend=backend
    )
    np.testing.assert_allclose(res, resw, rtol=1e-5)

    # w_func as identity function
    resw = sr.vrgksuv_ensemble(
        obs, fct, w_func=lambda x: x * 0.0 + 1.0, backend=backend
    )
    np.testing.assert_allclose(res, resw, rtol=1e-5)

    # test correctness
    fct = np.array(
        [
            [-0.03574194, 0.06873582, 0.03098684, 0.07316138, 0.08498165],
            [-0.11957874, 0.26472238, -0.06324622, 0.43026451, -0.25640457],
            [-1.31340831, -1.43722153, -1.01696021, -0.70790148, -1.20432392],
            [1.26054027, 1.03477874, 0.61688454, 0.75305795, 1.19364529],
            [0.63192933, 0.33521695, 0.20626017, 0.43158264, 0.69518928],
            [0.83305233, 0.71965134, 0.96687378, 1.0000473, 0.82714425],
            [0.0128655, 0.03849841, 0.02459106, -0.02618909, 0.18687008],
            [-0.69399216, -0.59432627, -1.43629972, 0.01979857, -0.3286767],
            [1.92958764, 2.2678255, 1.86036922, 1.84766384, 2.03331138],
            [0.80847492, 1.11265193, 0.58995365, 1.04838184, 1.10439277],
        ]
    )

    obs = np.array(
        [
            0.19640722,
            -0.11300369,
            -1.0400268,
            0.84306533,
            0.36572078,
            0.82487264,
            0.14088773,
            -0.51936113,
            1.70706264,
            0.75985908,
        ]
    )

    def w_func(x):
        return (x > -1) * 1.0

    res = np.mean(
        np.float64(sr.vrgksuv_ensemble(obs, fct, w_func=w_func, backend=backend))
    )
    np.testing.assert_allclose(res, 0.01476682, rtol=1e-6)

    res = np.mean(np.float64(sr.vrgksuv_ensemble(obs, fct, a=-1.0, backend=backend)))
    np.testing.assert_allclose(res, 0.01476682, rtol=1e-6)

    def w_func(x):
        return (x < 1.85) * 1.0

    res = np.mean(
        np.float64(sr.vrgksuv_ensemble(obs, fct, w_func=w_func, backend=backend))
    )
    np.testing.assert_allclose(res, 0.04011836, rtol=1e-6)

    res = np.mean(np.float64(sr.vrgksuv_ensemble(obs, fct, b=1.85, backend=backend)))
    np.testing.assert_allclose(res, 0.04011836, rtol=1e-6)


def test_vrgksmv(backend):
    if backend == "jax":
        pytest.skip("Not implemented in jax backend")
    obs = np.random.randn(N, N_VARS)
    fct = np.expand_dims(obs, axis=-2) + np.random.randn(N, ENSEMBLE_SIZE, N_VARS)

    res0 = sr.gksmv_ensemble(obs, fct, backend=backend)
    res = sr.vrgksmv_ensemble(
        obs, fct, lambda x: backends[backend].mean(x) * 0.0 + 1.0, backend=backend
    )
    np.testing.assert_allclose(res, res0, rtol=1e-6)
