import numpy as np
from numba import guvectorize

from scoringrules.core.utils import lazy_gufunc_wrapper_uv


@lazy_gufunc_wrapper_uv
@guvectorize("(),(),(a),(a),(a),(),(a) ->()", cache=True)
def _weighted_interval_score_gufunc(
    obs: np.ndarray,
    median: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    alpha: np.ndarray,
    weight_median: np.ndarray,
    weight_alpha: np.ndarray,
    out: np.ndarray,
):
    """Weighted Interval score (WIS)."""
    K = alpha.shape[0]
    wis = 0
    for low, upp, a, w_a in zip(lower, upper, alpha, weight_alpha):  # noqa: B905
        ws_a = (
            (upp - low)
            + (obs < low) * (2 / a) * (low - obs)
            + (obs > upp) * (2 / a) * (obs - upp)
        )
        wis += w_a * ws_a
    wis += weight_median * np.abs(obs - median)
    wis /= K + 1 / 2
    out[0] = wis
