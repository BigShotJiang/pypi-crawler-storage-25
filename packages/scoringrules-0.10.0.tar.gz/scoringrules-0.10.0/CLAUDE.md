# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

`scoringrules` is a Python library for probabilistic forecast evaluation, providing scoring rules (CRPS, Brier, log score, energy score, variogram score, etc.) across multiple array backends. Originally a Python port of the R package `scoringRules`. Requires Python `>=3.11`.

## Commands

This project uses `uv` (see `uv.lock`).

- Install dev environment with all backends: `uv sync --all-extras`
- Run full test suite (default backends: numpy, numba, jax, torch): `uv run pytest`
- Run a single test: `uv run pytest tests/test_crps.py::test_ensemble`
- Run tests against a subset of backends: `uv run pytest --backend numpy,jax`
- Coverage: `uv run pytest --cov=scoringrules`
- Lint/format: `uv run ruff check .` / `uv run ruff format .` (line-length 88, ignores E741)
- Pre-commit: `pre-commit run --all-files`
- Set `SR_TEST_OUTPUT=1` to write test diagnostic outputs into `tests/output/`.

## Architecture

The library has a layered structure that decouples public API, mathematical core, and array backends.

### Top-level API (`scoringrules/_*.py`)
Files like `_crps.py`, `_brier.py`, `_energy.py`, `_logs.py`, `_kernels.py`, `_quantile.py`, `_variogram.py`, `_dss.py`, `_interval.py`, `_error_spread.py` define the user-facing functions (e.g. `crps_ensemble`, `brier_score`). Each function:
1. Validates inputs via helpers in `scoringrules/core/utils.py` (e.g. `univariate_array_check`, `estimator_check`).
2. Resolves a backend (defaulting to the registry's `active`).
3. Dispatches to a pure mathematical implementation in `scoringrules/core/<topic>/`.

All public functions are re-exported from `scoringrules/__init__.py`.

### Core implementations (`scoringrules/core/`)
Pure-math implementations parameterized by backend. CRPS in particular is split into:
- `_closed.py` — closed-form parametric CRPS (normal, gamma, gev, …).
- `_approx.py` / `_approx_w.py` — ensemble-based approximations and weighted variants.
- `_gufuncs.py` / `_gufuncs_w.py` — numba generalized ufuncs (only used by the `numba` backend; excluded from coverage).

Other domains (`energy/`, `kernels/`, `variogram/`, `dss/`, `interval/`, `error_spread/`) follow the same pattern. Shared helpers live in `core/utils.py`, `core/stats.py`, `core/typing.py`.

### Backends (`scoringrules/backend/`)
`base.py` defines `ArrayBackend`, an abstract array-API surface. Concrete implementations: `numpy.py` (`NumpyBackend`, `NumbaBackend`), `jax.py`, `torch.py`, `tensorflow.py`. The `numba` backend reuses numpy semantics but routes hot paths through `_gufuncs`.

`registry.py` provides `BackendsRegistry`, a lazy dict of registered backends with an `active` selection. `numpy` is always registered; `numba` is auto-registered if importable. Tests in `tests/conftest.py` parametrize the `backend` fixture across available backends, controlled by `--backend name1,name2`.

When adding a new score:
- Put math in `core/<topic>/` and write it against `ArrayBackend` (use `B.method(...)` rather than calling numpy directly).
- Expose the user-facing wrapper in a top-level `_<name>.py` module and re-export from `scoringrules/__init__.py`.
- Add tests in `tests/test_<name>.py`; they are automatically run against all available backends via the `backend` fixture.

### Vendored / visualization
`scoringrules/vendored/` holds third-party code copies. `scoringrules/visualization/` provides plotting utilities (matplotlib is a dev dependency, not runtime).

## Optional extras
`numba`, `jax`, `torch`, `tensorflow` are optional dependency groups in `pyproject.toml`. Code that imports them must be guarded; `tp.TYPE_CHECKING` blocks and `except ImportError` are excluded from coverage.
