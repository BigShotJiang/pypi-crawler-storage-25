"""Dependency graph adapters."""
