"""Report generation."""
