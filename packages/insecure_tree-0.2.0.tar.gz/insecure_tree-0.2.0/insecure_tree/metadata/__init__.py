"""Package metadata resolution."""
