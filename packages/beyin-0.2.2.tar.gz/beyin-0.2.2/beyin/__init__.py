"""beyin — turn your fav content into queryable local memory."""

__version__ = "0.2.2"
