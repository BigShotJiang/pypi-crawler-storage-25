#  Copyright Contributors to the OpenCue Project
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""System tray application for CueNIMBY."""

import logging
import os
import shlex
import subprocess
import sys
from typing import Optional
import shutil

from qtpy import QtCore, QtWidgets, QtGui

from .config import Config
from .monitor import HostMonitor, HostState
from .notifier import Notifier
from .scheduler import NimbyScheduler

logger = logging.getLogger(__name__)


class CueNIMBYTray(QtWidgets.QSystemTrayIcon):
    """System tray application for NIMBY control."""

    # Signals to safely update from monitor thread to Qt main thread
    _state_changed_signal = QtCore.Signal(object, object)
    _frame_started_signal = QtCore.Signal(str, str)

    # Icon for different states
    ICONS = {
        HostState.STARTING:     "opencue-starting.png",
        HostState.AVAILABLE:    "opencue-available.png",
        HostState.WORKING:      "opencue-working.png",
        HostState.NIMBY_LOCKED: "opencue-disabled.png",
        HostState.HOST_DOWN:    "opencue-disabled.png",
        HostState.HOST_LOCKED:  "opencue-disabled.png",
        HostState.NO_HOST:      "opencue-error.png",
        HostState.HOST_LAGGING: "opencue-warning.png",
        HostState.CUEBOT_UNREACHABLE: "opencue-error.png",
        HostState.ERROR:        "opencue-error.png",
        HostState.UNKNOWN:      "opencue-unknown.png",
        HostState.REPAIR:      "opencue-repair.png",

        "DEFAULT":              "opencue-default.png"
    }

    def __init__(self, config: Optional[Config] = None, parent=None):
        """Initialize tray application.

        Args:
            config: Configuration object. If None, uses default.
        """
        # Set up Qt application
        self.app = QtWidgets.QApplication([])
        _icon = QtGui.QIcon(self._get_icon(HostState.STARTING))
        QtWidgets.QSystemTrayIcon.__init__(self, _icon, parent)

        self.menu = QtWidgets.QMenu(parent)
        self.setContextMenu(self.menu)
        self.config = config or Config()
        self.monitor: Optional[HostMonitor] = None
        self.notifier: Optional[Notifier] = None
        self.scheduler: Optional[NimbyScheduler] = None

        # Connect cross-thread signals for state changes and frame starts
        self._state_changed_signal.connect(self._handle_state_change)
        self._frame_started_signal.connect(self._handle_frame_started)

        self._init_components()

        logger.info("CueNIMBY tray initialized")

    def _init_components(self) -> None:
        """Initialize application components."""
        # Initialize notifier
        if self.config.show_notifications:
            self.notifier = Notifier()
            self.notifier.set_tray_icon(self)

        # Initialize monitor
        self.monitor = HostMonitor(
            cuebot_host=self.config.cuebot_host,
            cuebot_port=self.config.cuebot_port,
            hostname=self.config.hostname,
            poll_interval=self.config.poll_interval,
            state_change_callbacks=[self._on_state_change],
            frame_started_callbacks=[self._on_frame_started]
        )

        # Initialize scheduler if enabled
        if self.config.scheduler_enabled and self.config.schedule:
            self.scheduler = NimbyScheduler(self.config.schedule)

    def _get_icon(self, state):
        """Get icon path for given state."""
        _icon_folder = os.path.join(os.path.dirname(__file__), "icons")
        if state not in HostState:
            return QtGui.QPixmap(os.path.join(_icon_folder, self.ICONS["UNKNOWN"]))
        return QtGui.QPixmap(os.path.join(_icon_folder,
                                          self.ICONS.get(state, self.ICONS["DEFAULT"])))

    def _update_icon(self, state: Optional[HostState] = None) -> None:
        """Update tray icon to reflect current state."""
        if state is None:
            state = self.monitor.current_state
        self.setIcon(QtGui.QIcon(self._get_icon(state)))
        self.setToolTip(f"CueNIMBY - {state.value}")

    def _on_state_change(self, old_state: HostState, new_state: HostState) -> None:
        """Handle state change from monitor thread — emit signal to main thread."""
        logger.info("State changed: %s -> %s", old_state.value, new_state.value)
        self._state_changed_signal.emit(old_state, new_state)

    def _handle_state_change(self, old_state: HostState, new_state: HostState) -> None:
        """Handle state change on the Qt main thread (connected via signal)."""
        self._update_icon(state=new_state)

        # Send notifications
        if self.notifier:
            if new_state == HostState.CUEBOT_UNREACHABLE:
                self.notifier.notify_cuebot_unreachable()
            elif new_state == HostState.NIMBY_LOCKED:
                self.notifier.notify_nimby_locked()
            elif new_state in (HostState.HOST_DOWN, HostState.NO_HOST):
                self.notifier.notify_host_down()
            elif new_state == HostState.HOST_LAGGING:
                self.notifier.notify_host_lagging()
            elif new_state == HostState.REPAIR:
                self.notifier.notify_host_repairing()
            elif old_state == HostState.NIMBY_LOCKED:
                if new_state == HostState.AVAILABLE:
                    self.notifier.notify_nimby_unlocked()
                elif new_state == HostState.HOST_LOCKED:
                    self.notifier.notify_manual_lock()
            elif new_state == HostState.AVAILABLE:
                if old_state in (HostState.NIMBY_LOCKED, HostState.HOST_LOCKED):
                    self.notifier.notify_manual_unlock()
                elif old_state in (HostState.HOST_DOWN, HostState.NO_HOST):
                    self.notifier.notify_host_recovered()

    def _on_frame_started(self, job_name: str, frame_name: str) -> None:
        """Handle frame start from monitor thread — emit signal to main thread."""
        self._frame_started_signal.emit(job_name, frame_name)

    def _handle_frame_started(self, job_name: str, frame_name: str) -> None:
        """Handle frame start on the Qt main thread (connected via signal)."""
        logger.info("Frame started: %s/%s", job_name, frame_name)
        if self.notifier:
            self.notifier.notify_job_started(job_name, frame_name)

    def _on_scheduler_state_change(self, desired_state: str) -> None:
        """Handle scheduler state change.

        Args:
            desired_state: Desired state ("available" or "disabled").
        """
        try:
            if desired_state == "disabled":
                self.monitor.lock_host()
            elif desired_state == "available":
                self.monitor.unlock_host()
        except RuntimeError as e:
            logger.error("Scheduler failed to change host state: %s", e)
            if self.notifier:
                self.notifier.notify("Scheduler Error", str(e))

    def _toggle_available(self) -> None:
        """Toggle host availability."""
        current_state = self.monitor.current_state

        try:
            if current_state in (HostState.HOST_LOCKED, HostState.NIMBY_LOCKED):
                # Enable host
                if self.monitor.unlock_host():
                    logger.info("Host enabled by user")
            else:
                # Disable host
                if self.monitor.lock_host():
                    logger.info("Host disabled by user")
        except RuntimeError as e:
            logger.error("Failed to toggle host state: %s", e)
            if self.notifier:
                self.notifier.notify("Error", str(e))

    def _is_available(self) -> bool:
        """Check if host is available (for menu checkbox)."""
        state = self.monitor.current_state
        return state in (HostState.AVAILABLE, HostState.WORKING)

    def _toggle_notifications(self) -> None:
        """Toggle notifications on/off."""
        enabled = not self.config.show_notifications
        self.config.set("show_notifications", enabled)

        if enabled:
            self.notifier = Notifier()
            self.notifier.set_tray_icon(self)
            logger.info("Notifications enabled")
        else:
            self.notifier = None
            logger.info("Notifications disabled")

    def _notifications_enabled(self) -> bool:
        """Check if notifications are enabled (for menu checkbox)."""
        return self.config.show_notifications

    def _toggle_scheduler(self) -> None:
        """Toggle scheduler on/off."""
        enabled = not self.config.scheduler_enabled
        self.config.set("scheduler_enabled", enabled)

        if enabled and self.config.schedule:
            self.scheduler = NimbyScheduler(self.config.schedule)
            self.scheduler.start(self._on_scheduler_state_change)
        elif self.scheduler:
            self.scheduler.stop()
            self.scheduler = None

        logger.info("Scheduler %s", "enabled" if enabled else "disabled")

    def _scheduler_enabled(self) -> bool:
        """Check if scheduler is enabled (for menu checkbox)."""
        return self.config.scheduler_enabled

    # pylint: disable=consider-using-with
    def launch_cuegui(self) -> None:
        """Launch CueGUI application using the command from config."""
        try:
            cmd = self.config.cuegui_command
            subprocess.Popen(cmd)
            logger.info("Launched CueGUI: %s", cmd)
        except Exception as e:
            logger.error("Failed to launch CueGUI: %s", e)
            if self.notifier:
                self.notifier.notify(
                    "Error",
                    f"Failed to launch CueGUI: {e}"
                )

    def _cuegui_available(self) -> bool:
        """Check if CueGUI is available."""
        cmd = self.config.cuegui_command
        return shutil.which(cmd[0]) is not None

    def _show_about(self) -> None:
        """Show about dialog using native platform dialogs."""
        # pylint: disable=import-outside-toplevel
        from . import __version__

        # Always use native dialogs for About (more reliable than notifications)
        about_message = f"CueNIMBY v{__version__}\n\nOpenCue NIMBY Control\n\n"
        about_message += f"Host: {self.monitor.hostname}\n\n"
        about_message += f"Cuebot: {self.monitor.cuebot_host}:{self.monitor.cuebot_port}"
        try:
            if sys.platform == "darwin":  # macOS
                # For AppleScript, use return for newlines
                # Escape quotes and replace newlines with 'return' for AppleScript
                esc_message = about_message.replace('"', '\\"').replace('\n', '" & return & "')
                script = f'display dialog "{esc_message}" with title "About CueNIMBY"'
                script += ' buttons {"OK"} default button "OK"'
                subprocess.run(["osascript", "-e", script], check=False)
                logger.info("About CueNIMBY: %s", about_message)
            elif sys.platform == "win32":  # Windows
                # pylint: disable=import-outside-toplevel
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, about_message, "About CueNIMBY", 0)
                logger.info("About CueNIMBY: %s", about_message)
            else:  # Linux
                # Try zenity or kdialog
                try:
                    subprocess.run(["zenity",
                                    "--info",
                                    "--title=About CueNIMBY",
                                    f"--text={about_message}"],
                                    check=False)
                    logger.info("About CueNIMBY: %s", about_message)
                except FileNotFoundError:
                    try:
                        subprocess.run(["kdialog", "--msgbox",
                                        about_message, "--title", "About CueNIMBY"],
                                        check=False)
                        logger.info("About CueNIMBY: %s", about_message)
                    except FileNotFoundError:
                        # Fallback: use notification if available, otherwise log
                        if self.notifier:
                            self.notifier.notify("About CueNIMBY", about_message)
                        else:
                            logger.warning("No dialog system available.")
                            logger.warning("About CueNIMBY: %s", about_message)
        except Exception as e:
            logger.error("Failed to show about dialog: %s", e)
            # Fallback to console output
            print(f"\nAbout CueNIMBY\n{about_message}\n")

    def _open_config(self) -> None:
        """Open config file in default editor."""
        config_path = str(self.config.config_path)
        try:
            if sys.platform == "darwin":  # macOS
                subprocess.run(["open", config_path], check=True)
            elif sys.platform == "win32":  # Windows
                os.startfile(config_path)
            else:  # Linux and others
                editor = (os.environ.get("VISUAL")
                          or os.environ.get("EDITOR")
                          or shutil.which("gedit")
                          or shutil.which("nano")
                          or "vi")
                editor_cmd = shlex.split(editor)
                editor_name = os.path.basename(editor_cmd[0])
                gui_editors = ("gedit", "kate", "mousepad", "xed")
                if editor_name in gui_editors:
                    # GUI editors launch directly, no terminal needed
                    subprocess.Popen([*editor_cmd, config_path])
                else:
                    # Terminal editors need a terminal emulator
                    terminal = shutil.which("xterm") or shutil.which("gnome-terminal")
                    if terminal and "xterm" in terminal:
                        subprocess.Popen([terminal, "-e", *editor_cmd, config_path])
                    elif terminal:
                        subprocess.Popen([terminal, "--", *editor_cmd, config_path])
                    else:
                        raise RuntimeError("No terminal emulator found to open config")
            logger.info("Opened config file: %s", config_path)
        except Exception as e:
            logger.error("Failed to open config file: %s", e)
            if self.notifier:
                self.notifier.notify(
                    "Error",
                    f"Failed to open config file: {e}"
                )

    def _quit(self) -> None:
        """Quit application."""
        logger.info("Shutting down CueNIMBY")
        self.stop()

    # pylint: disable=attribute-defined-outside-init
    def _create_menu(self) -> None:
        """Create tray menu.

        Returns:
            pystray.Menu object.
        """

        self.activate_action = self.menu.addAction("Available")
        self.activate_action.triggered.connect(self._toggle_available)
        self.activate_action.setCheckable(True)
        self.activate_action.setChecked(self._is_available())
        # self.activate_action.setIcon(QtGui.QIcon(self.AVAILABLE_ICON))

        self.notifications_action = self.menu.addAction("Notifications")
        self.notifications_action.triggered.connect(self._toggle_notifications)
        self.notifications_action.setCheckable(True)
        self.notifications_action.setChecked(self._notifications_enabled())
        # self.notifications_action.setIcon(QtGui.QIcon(self.AVAILABLE_ICON))

        self.scheduler_action = self.menu.addAction("Scheduler")
        self.scheduler_action.triggered.connect(self._toggle_scheduler)
        self.scheduler_action.setCheckable(True)
        self.scheduler_action.setChecked(self._scheduler_enabled())
        # self.scheduler_action.setIcon(QtGui.QIcon(self.AVAILABLE_ICON))

        self.menu.addSeparator()

        self.cuegui_action = self.menu.addAction(self.config.cuegui_label)
        self.cuegui_action.triggered.connect(self.launch_cuegui)
        self.cuegui_action.setEnabled(self._cuegui_available())

        self.menu.addSeparator()

        self.open_config_action = self.menu.addAction("Open Config File")
        self.open_config_action.triggered.connect(self._open_config)

        self.about_action = self.menu.addAction("About")
        self.about_action.triggered.connect(self._show_about)

        self.quit_action = self.menu.addAction("Quit")
        self.quit_action.triggered.connect(self._quit)

        self.menu.aboutToShow.connect(self._update_menu)

    def _update_menu(self) -> None:
        """Update menu items before showing."""
        self.activate_action.setChecked(self._is_available())
        if self.monitor.current_state in (HostState.STARTING, HostState.NO_HOST,
                                          HostState.HOST_LAGGING, HostState.HOST_DOWN,
                                          HostState.CUEBOT_UNREACHABLE, HostState.ERROR,
                                          HostState.UNKNOWN, HostState.REPAIR):
            self.activate_action.setEnabled(False)
            self.activate_action.setText("Available (cannot change at the moment)")
        else:
            self.activate_action.setEnabled(True)
            self.activate_action.setText("Available")

        self.notifications_action.setChecked(self._notifications_enabled())

        self.scheduler_action.setChecked(self._scheduler_enabled())

        label = self.config.cuegui_label
        if self._cuegui_available():
            self.cuegui_action.setEnabled(True)
            self.cuegui_action.setText(label)
        else:
            self.cuegui_action.setEnabled(False)
            self.cuegui_action.setText(f"{label} (not installed)")

    def start(self) -> None:
        """Start the tray application."""
        # Start monitor
        self.monitor.start()

        # Start scheduler if enabled
        if self.scheduler:
            self.scheduler.start(self._on_scheduler_state_change)

        # Initialize menu
        self._create_menu()

        logger.info("CueNIMBY tray started")
        self.show()
        sys.exit(self.app.exec_())

    def stop(self) -> None:
        """Stop the tray application."""
        if self.monitor:
            self.monitor.stop()
        if self.scheduler:
            self.scheduler.stop()
        logger.info("CueNIMBY tray stopped")
        self.app.quit()
