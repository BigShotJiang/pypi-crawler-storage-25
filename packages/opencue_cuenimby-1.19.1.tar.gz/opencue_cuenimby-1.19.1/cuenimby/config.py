#  Copyright Contributors to the OpenCue Project
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""Configuration management for CueNIMBY."""

import json
import logging
import os
from pathlib import Path
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

_DEFAULT_CONFIG_FILE = Path(__file__).parent / "default_cuenimby_config.json"


def _load_default_config() -> Dict[str, Any]:
    """Load default configuration from default_config.json."""
    try:
        with open(_DEFAULT_CONFIG_FILE, 'r', encoding='utf-8') as f:
            config = json.load(f)
    except Exception as e:
        logger.error("Failed to load default config from %s: %s", _DEFAULT_CONFIG_FILE, e)
        config = {}
    # Environment variables override the file defaults
    if os.getenv("CUEBOT_HOST"):
        config["cuebot_host"] = os.getenv("CUEBOT_HOST")
    if os.getenv("CUEBOT_PORT"):
        try:
            config["cuebot_port"] = int(os.getenv("CUEBOT_PORT"))
        except ValueError:
            logger.warning("Invalid CUEBOT_PORT value: %s, using default", os.getenv("CUEBOT_PORT"))
    return config


class Config:
    """Manages CueNIMBY configuration."""

    DEFAULT_CONFIG = _load_default_config()

    def __init__(self, config_path: Optional[str] = None):
        """Initialize configuration.

        Args:
            config_path: Path to config file. If None, uses default location.
        """
        if config_path is None:
            config_dir = Path.home() / ".config/opencue"
            config_dir.mkdir(exist_ok=True)
            config_path = config_dir / "cuenimby.json"

        self.config_path = Path(config_path)
        self.config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create from defaults."""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                # Merge with defaults for any missing keys
                merged_config = self.DEFAULT_CONFIG.copy()
                merged_config.update(config)
                return merged_config
            except Exception as e:
                logger.error("Failed to load config: %s", e)
                return self.DEFAULT_CONFIG.copy()
        else:
            # Seed user config from default_config.json
            self.config = self.DEFAULT_CONFIG.copy()
            self.save()
            if self.config_path.exists():
                logger.info("Created user config at %s", self.config_path)
            return self.config

    def save(self) -> None:
        """Save current configuration to file."""
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            logger.error("Failed to save config: %s", e)

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value."""
        return self.config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set configuration value and save."""
        self.config[key] = value
        self.save()

    @property
    def cuebot_host(self) -> str:
        """Get Cuebot host."""
        return self.config["cuebot_host"]

    @property
    def cuebot_port(self) -> int:
        """Get Cuebot port."""
        return self.config["cuebot_port"]

    @property
    def hostname(self) -> Optional[str]:
        """Get hostname."""
        return self.config["hostname"]

    @property
    def poll_interval(self) -> int:
        """Get poll interval in seconds."""
        return self.config["poll_interval"]

    @property
    def show_notifications(self) -> bool:
        """Check if notifications are enabled."""
        return self.config["show_notifications"]

    @property
    def scheduler_enabled(self) -> bool:
        """Check if scheduler is enabled."""
        return self.config["scheduler_enabled"]

    @property
    def cuegui_command(self) -> list:
        """Get CueGUI launch command."""
        return self.config.get("cuegui_command", ["cuegui"])

    @property
    def cuegui_label(self) -> str:
        """Get CueGUI menu label."""
        return self.config.get("cuegui_label", "Launch CueGUI")

    @property
    def schedule(self) -> Dict[str, Any]:
        """Get schedule configuration."""
        return self.config.get("schedule", {})
