# commands/pipeline_runs_commands.py

import logging
from typing import Any
import uuid

import click
from teaspoons_client import AsyncPipelineRunResponseV2, DataDeliveryReport, PipelineRun  # type: ignore[attr-defined]

from terralab.constants import FAILED_KEY, SUPPORT_EMAIL_TEXT, SUCCEEDED_KEY
from terralab.log import (
    indented,
    add_blankline_before,
    format_table_with_status,
    format_status,
)
from terralab.logic import pipeline_runs_logic, pipelines_logic
from terralab.utils import (
    convert_file_size_to_human_readable,
    handle_api_exceptions,
    process_inputs_to_dict,
    validate_gcs_path,
    validate_job_id,
    format_timestamp,
)

LOGGER = logging.getLogger(__name__)


@click.command(
    short_help="Submit a job",
    context_settings=dict(
        ignore_unknown_options=True,
    ),
)
@click.argument("pipeline_name", type=str)
@click.option("--version", type=int, help="pipeline version, defaults to latest")
@click.option(
    "--description", type=str, default="", help="optional description for the job"
)
@click.argument("inputs", nargs=-1, type=click.UNPROCESSED)
@handle_api_exceptions
def submit(
    pipeline_name: str, version: int, inputs: tuple[str, ...], description: str
) -> None:
    """Submit a job for a PIPELINE_NAME pipeline

    To see the required inputs for a given pipeline, use the `terralab pipelines details` command.
    """
    LOGGER.debug(f"inputs: {inputs}")
    inputs_dict = process_inputs_to_dict(inputs)
    LOGGER.debug(f"inputs processed to dict: {inputs_dict}")

    # validate inputs
    pipelines_logic.validate_pipeline_inputs(pipeline_name, version, inputs_dict)

    submitted_job_id = pipeline_runs_logic.prepare_upload_start_pipeline_run(
        pipeline_name, version, inputs_dict, description
    )

    LOGGER.info(f"Successfully started {pipeline_name} job {submitted_job_id}")


@click.command(short_help="Download all output files from a job")
@click.argument("job_id", type=str)
@click.option(
    "--local_destination",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, writable=True),
    default=".",
    help="optional location to download results to. defaults to the current directory.",
)
@handle_api_exceptions
def download(job_id: str, local_destination: str) -> None:
    """Download all output files from a job with JOB_ID identifier"""
    job_id_uuid: uuid.UUID = validate_job_id(job_id)

    pipeline_runs_logic.get_signed_urls_and_download_pipeline_run_outputs(
        job_id_uuid, local_destination
    )


# JOBS group


@click.group()
def jobs() -> None:
    """Get information about your jobs"""


@jobs.command(short_help="Get the status and details of a job")
@click.argument("job_id", type=str)
@handle_api_exceptions
def details(job_id: str) -> None:
    """Get the status and details of a job with JOB_ID identifier"""
    job_id_uuid: uuid.UUID = validate_job_id(job_id)
    timestamp_format: str = "%Y-%m-%d %H:%M %Z"

    response: AsyncPipelineRunResponseV2 = pipeline_runs_logic.get_pipeline_run_status(
        job_id_uuid
    )

    LOGGER.info(f"Status: {format_status(response.job_report.status)}")

    if response.error_report:
        LOGGER.info(
            add_blankline_before(f"Error message: {response.error_report.message}")
        )

    if response.job_report.status == FAILED_KEY:
        LOGGER.info(add_blankline_before(SUPPORT_EMAIL_TEXT))

    LOGGER.info(add_blankline_before("Details:"))
    LOGGER.info(
        indented(f"Pipeline Name: {response.pipeline_run_report.pipeline_name}")
    )
    LOGGER.info(
        indented(f"Pipeline Version: {response.pipeline_run_report.pipeline_version}")
    )
    LOGGER.info(indented(f"Description: {response.job_report.description}"))

    LOGGER.info(indented("Inputs:"))
    for input_name, input_value in response.pipeline_run_report.user_inputs.items():
        LOGGER.info(indented(f"{input_name}:", n_spaces=4))
        LOGGER.info(indented(input_value, n_spaces=6))

    if response.pipeline_run_report.input_size:
        LOGGER.info(
            indented(
                f"Input size: {response.pipeline_run_report.input_size} {response.pipeline_run_report.input_size_units}"
            )
        )

    LOGGER.info(
        indented(
            f"Submitted: {format_timestamp(response.job_report.submitted, timestamp_format)}"
        )
    )
    if response.job_report.completed:
        LOGGER.info(
            indented(
                f"Completed: {format_timestamp(response.job_report.completed, timestamp_format)}"
            )
        )
        quota_consumed = response.pipeline_run_report.quota_consumed or 0
        LOGGER.info(indented(f"Quota Consumed: {quota_consumed}"))

    if response.job_report.status == SUCCEEDED_KEY:
        display_outputs(response.pipeline_run_report.outputs)
        LOGGER.info(
            indented(
                f"File Download Expiration: {format_timestamp(response.pipeline_run_report.output_expiration_date, timestamp_format)}"
            )
        )

    display_data_delivery(response.pipeline_run_report.data_delivery_report)


def display_outputs(outputs: dict[str, dict[str, Any]] | None) -> None:
    if not outputs:
        return
    LOGGER.info(indented("Outputs:"))
    for (
        output_name,
        output_value,
    ) in outputs.items():
        if "metadata" in output_value and "sizeInBytes" in output_value["metadata"]:
            output_size_string = f"({convert_file_size_to_human_readable(output_value['metadata']['sizeInBytes'])})"
        else:
            output_size_string = ""
        LOGGER.info(
            indented(
                f"{output_name}:",
                n_spaces=4,
            )
        )
        LOGGER.info(
            indented(
                f"{output_value['value']} {output_size_string}",
                n_spaces=6,
            )
        )


def display_data_delivery(data_delivery_report: DataDeliveryReport | None) -> None:
    if not data_delivery_report:
        return
    LOGGER.info(add_blankline_before("Data Delivery:"))
    LOGGER.info(indented(f"Status: {format_status(data_delivery_report.status)}"))
    LOGGER.info(indented(f"Destination: {data_delivery_report.destination}"))


@jobs.command(name="list", short_help="List your jobs")
@click.option(
    "--num_results",
    type=click.IntRange(1, 100),
    default=10,
    help="Number of results to display. Defaults to 10, maximum 100.",
)
@handle_api_exceptions
def list_command(num_results: int) -> None:
    results: list[PipelineRun] = pipeline_runs_logic.get_pipeline_runs(num_results)
    if results:
        # create list of list of strings; first list is headers
        row_list = [
            [
                "Job ID",
                "Pipeline",
                "Status",
                "Submitted",
                "Output Expires",
                "Description",
            ]
        ]
        for pipeline_run in results:
            row_list.append(
                [
                    pipeline_run.job_id,
                    f"{pipeline_run.pipeline_name} v{pipeline_run.pipeline_version}",
                    pipeline_run.status,
                    format_timestamp(pipeline_run.time_submitted),
                    format_timestamp(pipeline_run.output_expiration_date),
                    pipeline_run.description or "",
                ]
            )

        LOGGER.info(format_table_with_status(row_list))


# DELIVER group


@click.command(short_help="Deliver output files from a job to a cloud destination")
@click.argument("job_id", type=str)
@click.argument("destination", type=str)
@handle_api_exceptions
def deliver(job_id: str, destination: str) -> None:
    """Deliver output files from a job with JOB_ID identifier to a DESTINATION GCS path.

    Note: delivering your data to a cloud destination will disable downloading locally.
    """
    job_id_uuid: uuid.UUID = validate_job_id(job_id)
    validated_destination: str = validate_gcs_path(destination)

    pipeline_runs_logic.deliver_pipeline_run_to_cloud(
        job_id_uuid, validated_destination
    )

    LOGGER.info(
        f"Successfully initiated data delivery for job {job_id} to {validated_destination}. Delivery may take a few minutes to complete."
    )
    LOGGER.info(
        add_blankline_before(
            f"You can check the status of the delivery with `terralab jobs details {job_id}`."
        )
    )
