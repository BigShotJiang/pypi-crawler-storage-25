"""Custom exceptions for all Araxys modules."""


from __future__ import annotations


class AraxysError(Exception):
    """Base exception for all Araxys errors."""

    def __init__(self, message: str = "An Araxys security error occurred") -> None:
        self.message = message
        super().__init__(self.message)


class RateLimitExceeded(AraxysError):
    """Raised when a client exceeds the rate limit threshold."""

    def __init__(
        self,
        ip_address: str,
        retry_after: int,
        *,
        message: str | None = None,
    ) -> None:
        self.ip_address = ip_address
        self.retry_after = retry_after
        super().__init__(
            message
            or f"Rate limit exceeded for {ip_address}. Retry after {retry_after}s."
        )


class HoneypotTriggered(AraxysError):
    """Raised when a client accesses a honeypot endpoint."""

    def __init__(self, ip_address: str, path: str) -> None:
        self.ip_address = ip_address
        self.path = path
        super().__init__(f"Honeypot triggered by {ip_address} on {path}")


class InvalidAPIKey(AraxysError):
    """Raised when an API key is invalid, expired, or lacks required scopes."""

    def __init__(self, reason: str = "Invalid API key") -> None:
        self.reason = reason
        super().__init__(reason)


class TokenExpired(AraxysError):
    """Raised when a JWT token has expired."""

    def __init__(self, token_type: str = "access") -> None:
        self.token_type = token_type
        super().__init__(f"{token_type.capitalize()} token has expired")


class TokenInvalid(AraxysError):
    """Raised when a JWT token is malformed or has an invalid signature."""

    def __init__(self, reason: str = "Invalid token") -> None:
        self.reason = reason
        super().__init__(reason)


class TokenRevoked(AraxysError):
    """Raised when a revoked refresh token is used (potential token theft)."""

    def __init__(self) -> None:
        super().__init__("Token has been revoked — possible token theft detected")


class SanitizationError(AraxysError):
    """Raised when a payload contains malicious content."""

    def __init__(self, threat_type: str, value_preview: str = "") -> None:
        self.threat_type = threat_type
        self.value_preview = value_preview
        super().__init__(f"Malicious {threat_type} detected in payload")


class EncryptionError(AraxysError):
    """Raised when audit log encryption or decryption fails."""

    def __init__(self, operation: str = "encryption") -> None:
        self.operation = operation
        super().__init__(f"Audit log {operation} failed")


class CSRFValidationError(AraxysError):
    """Raised when CSRF token validation fails."""

    def __init__(self, reason: str = "CSRF validation failed") -> None:
        self.reason = reason
        super().__init__(reason)


class BruteForceLockedError(AraxysError):
    """Raised when a client is locked out due to too many failed attempts."""

    def __init__(
        self,
        identifier: str,
        retry_after: int,
        *,
        message: str | None = None,
    ) -> None:
        self.identifier = identifier
        self.retry_after = retry_after
        super().__init__(
            message
            or f"Account locked for {identifier}. Retry after {retry_after}s."
        )


class PasswordValidationError(AraxysError):
    """Raised when a password fails validation rules."""

    def __init__(self, failures: list[str]) -> None:
        self.failures = failures
        joined = "; ".join(failures) if failures else "Password validation failed"
        super().__init__(f"Password validation failed: {joined}")


class IPBlockedError(AraxysError):
    """Raised when a request is blocked by IP Access Control."""

    def __init__(
        self,
        ip_address: str,
        *,
        message: str | None = None,
    ) -> None:
        self.ip_address = ip_address
        super().__init__(message or f"IP blocked: {ip_address}")


class ConnectionError(AraxysError):
    """Raised when a database connection cannot be established or pool is exhausted."""

    def __init__(self, message: str = "Database connection error") -> None:
        super().__init__(message)


class TLSConfigurationError(AraxysError):
    """Raised when TLS configuration is invalid or cannot be applied."""

    def __init__(self, message: str = "TLS configuration error") -> None:
        super().__init__(message)
