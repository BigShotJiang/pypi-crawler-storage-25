"""Araxys — Plug & play security library for FastAPI.

Usage::

    from fastapi import FastAPI
    from araxys import AraxysShield, AraxysConfig

    app = FastAPI()
    shield = AraxysShield(
        app,
        AraxysConfig(secret_key="your-32-char-secret-key-here!!!!"),
    )
"""

# v0.3 middleware imports
from araxys.brute_force.limiter import BruteForceBackend, BruteForceMiddleware

# v0.3 module imports
from araxys.brute_force.password_policy import password_policy_dependency
from araxys.core.config import (
    AraxysConfig,
    AuditConfig,
    # v0.3 configs
    BruteForceConfig,
    CORSConfig,
    CSRFConfig,
    HoneypotConfig,
    IPControlConfig,
    JWTConfig,
    MetricsConfig,
    RateLimitConfig,
    SanitizeConfig,
    SecureHeadersConfig,
    SessionConfig,
    TelemetryConfig,
    WebhookConfig,
)
from araxys.core.exceptions import (
    AraxysError,
    # v0.3 exceptions
    BruteForceLockedError,
    CSRFValidationError,
    EncryptionError,
    HoneypotTriggered,
    InvalidAPIKey,
    IPBlockedError,
    PasswordValidationError,
    RateLimitExceeded,
    SanitizationError,
    TokenExpired,
    TokenInvalid,
    TokenRevoked,
)
from araxys.core.types import (
    AuditEntry,
    AuditEventType,
    Scope,
    SecurityContext,
    SecurityEvent,
    SecurityEventType,
)
from araxys.cors.middleware import CORSMiddleware
from araxys.csrf.dependencies import csrf_protected, set_csrf_cookie
from araxys.csrf.tokens import CSRFHandler
from araxys.db_security import (
    ConnectionPool,
    ConnectionStringResolver,
    DatabaseSecurityManager,
    InMemoryPool,
    QueryAuditor,
    RedisPool,
    get_db_pool,
    get_query_auditor,
)
from araxys.ip_access.backends import IPAccessBackend
from araxys.ip_access.middleware import IPAccessMiddleware
from araxys.jwt_auth.dependencies import create_jwks_router
from araxys.jwt_auth.storage import InMemoryJWKSStore, JWKSStore
from araxys.jwt_auth.tokens import JWTManager, TokenPair, TokenPayload
from araxys.metrics.collector import MetricsRegistry
from araxys.sessions.manager import SessionManager
from araxys.sessions.storage import (
    InMemorySessionBackend,
    RedisSessionBackend,
    SessionBackend,
    SessionRecord,
)
from araxys.shield import AraxysShield
from araxys.telemetry.tracer import AraxysTracer
from araxys.webhooks.emitter import SecurityEventBus

__all__ = [
    # Main entry point
    "AraxysShield",
    # Configuration
    "AraxysConfig",
    "AuditConfig",
    "HoneypotConfig",
    "JWTConfig",
    "RateLimitConfig",
    "SanitizeConfig",
    "SecureHeadersConfig",
    # v0.3 configs
    "CORSConfig",
    "IPControlConfig",
    "BruteForceConfig",
    "CSRFConfig",
    "SessionConfig",
    "WebhookConfig",
    "MetricsConfig",
    "TelemetryConfig",
    # Types
    "AuditEntry",
    "AuditEventType",
    "Scope",
    "SecurityContext",
    # v0.3 types
    "SecurityEventType",
    "SecurityEvent",
    # Exceptions
    "AraxysError",
    "EncryptionError",
    "HoneypotTriggered",
    "InvalidAPIKey",
    "RateLimitExceeded",
    "SanitizationError",
    "TokenExpired",
    "TokenInvalid",
    "TokenRevoked",
    # v0.3 exceptions
    "CSRFValidationError",
    "BruteForceLockedError",
    "PasswordValidationError",
    "IPBlockedError",
    # v0.3 modules — middleware
    "CORSMiddleware",
    "IPAccessMiddleware",
    "BruteForceMiddleware",
    # v0.3 modules — handlers
    "CSRFHandler",
    "SessionManager",
    "SecurityEventBus",
    "MetricsRegistry",
    "AraxysTracer",
    # v0.3 modules — dependencies
    "csrf_protected",
    "password_policy_dependency",
    "set_csrf_cookie",
    # v0.3 modules — backends
    "IPAccessBackend",
    "BruteForceBackend",
    "SessionBackend",
    "InMemorySessionBackend",
    "RedisSessionBackend",
    "SessionRecord",
    # v0.3 JWT additions
    "JWTManager",
    "TokenPair",
    "TokenPayload",
    "JWKSStore",
    "InMemoryJWKSStore",
    "create_jwks_router",
    # v0.5 Database Security
    "ConnectionPool",
    "ConnectionStringResolver",
    "DatabaseSecurityManager",
    "InMemoryPool",
    "QueryAuditor",
    "RedisPool",
    "get_db_pool",
    "get_query_auditor",
]
