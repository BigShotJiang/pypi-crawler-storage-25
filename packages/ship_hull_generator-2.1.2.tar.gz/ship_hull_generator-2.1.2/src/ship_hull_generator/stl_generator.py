import sys
import platform
import random
from pathlib import Path
import numpy as np
from tqdm import tqdm
import torch
from uuid import uuid4

# 依存モジュールのインポート
from .Guided_Cond_DDPM_Tools import GuidedDiffusionEnv
from .HullParameterization import Hull_Parameterization as HP

class StlGenerator:
    """
    船舶パラメータから船体形状(STL)を生成するツールクラス
    """
    def __init__(
        self,
        data_dir: str | Path,
        model_dir: str | Path,
        output_dir: str | Path = "./outputs",
        device: str = "cpu",
        num_samples: int = 512,
        num_generate: int = 1,
        resist_min: bool = False,
        geometric_constraint: bool = True,
        meap_threshold: float = 5.0,
        random_seed: int = 42
    ):
        """
        生成ツールの初期化とAIモデルの事前ロードを行います。
        （生成のたびにロードするオーバーヘッドをなくすため、ここで1度だけ実行します）
        """
        self.data_dir = Path(data_dir)
        self.model_dir = Path(model_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 生成パラメータの設定
        self.device = device
        self.num_samples = num_samples
        self.num_generate = num_generate
        self.resist_min = resist_min
        self.geometric_constraint = geometric_constraint
        self.meap_threshold = meap_threshold
        self.random_seed = random_seed
        
        # NumPyの表示設定
        np.set_printoptions(suppress=True)
        
        # シード固定
        self._set_seed(self.random_seed)
        
        # モデルとデータセットのロード
        self.data = self._load_and_preprocess_data()
        self.model_dicts = self._define_model_dictionaries()
        self.t_model = self._initialize_and_load_models()

    def generate(self, input_data: list[float], label: str = "My-Ship-Hull") -> dict:
        """
        入力パラメータからSTLを生成し、評価結果を返します。
        
        Args:
            input_data: [LOA(m), BOA(m), T(m), Dd(m), Vol(m^3), U(m/s)]
            label: 生成するファイル等に付与する識別ラベル
            
        Returns:
            dict: 生成されたSTLのパスと評価指標(MEAP等)を含む辞書
        """
        print(f"\n--- Starting Generation for: {label} ---")
        
        # 内部処理関数を呼び出し
        results, overall_meaps = self._generate_and_process_hulls(
            ship_data=np.array(input_data),
            study_label=label
        )
        
        # 結果を丸めて整形して返す
        return {
            "label": label,
            "hulls": self._round_hulls_data(results),
            "overall_meaps": self._round_dict(overall_meaps),
            "average_meaps": self._round_dict(self._calculate_meap_averages(results))
        }

    # ==========================================
    # 内部メソッド (Private Methods)
    # ==========================================
    def _set_seed(self, seed: int):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
        if torch.backends.mps.is_available():
            torch.manual_seed(seed)

    def _load_and_preprocess_data(self) -> dict:
        print("Loading and Preprocessing Dataset...")
        DesVec = np.load(self.data_dir / 'DesVec_82k.npy', allow_pickle=True)
        DesVec_neg = np.load(self.data_dir / 'Negative_DesVec_82k.npy', allow_pickle=True)
        Y = np.load(self.data_dir / 'GeometricMeasures.npy', allow_pickle=True)
        LenRatios = np.load(self.data_dir / 'Length_Ratios.npy', allow_pickle=True)
        X_LIMITS = np.load(self.data_dir / 'X_LIMITS.npy')

        idx_BBFactors = [33, 34, 35, 36, 37]
        idx_BB = 31
        idx_SBFactors = [38, 39, 40, 41, 42, 43, 44]
        idx_SB = 32

        for i in range(len(DesVec)):
            DesVec[i, idx_BBFactors] = DesVec[i, idx_BB] * DesVec[i, idx_BBFactors]
            DesVec[i, idx_SBFactors] = DesVec[i, idx_SB] * DesVec[i, idx_SBFactors]

        num_WL_Steps = 101
        VolVec = np.log10(Y[:, 1 * num_WL_Steps:2 * num_WL_Steps])
        VolVec[np.isnan(VolVec)] = -6.0

        return {
            'DesVec': DesVec, 'DesVec_neg': DesVec_neg, 'Y': Y, 
            'LenRatios': LenRatios, 'X_LIMITS': X_LIMITS, 
            'VolVec': VolVec, 'BOAVec': np.amax(LenRatios[:, 1:3], axis=1), 
            'DdVec': DesVec[:, 4],
            'X_lower_lim': [X_LIMITS[:, 0].tolist()], 
            'X_upper_lim': [X_LIMITS[:, 1].tolist()],
            'idx_BBFactors': idx_BBFactors, 'idx_BB': idx_BB,
            'idx_SBFactors': idx_SBFactors, 'idx_SB': idx_SB
        }

    def _define_model_dictionaries(self) -> dict:
        xdim_main = self.data['DesVec'].shape[1] - 1
        datalength = self.data['DesVec'].shape[0]
        xdim_full = self.data['DesVec'].shape[1]

        return {
            'DDPM_Dict': {
                'xdim': xdim_main, 'datalength': datalength,
                'X_LL': self.data['X_lower_lim'], 'X_UL': self.data['X_upper_lim'],
                'ydim': 0, 'cdim': 4, 'gamma': 0.2, 'lambda': [0.3, 0.3],
                'tdim': 128, 'net': [1024, 1024, 1024, 1024],
                'batch_size': 1024, 'Training_Epochs': 10000,
                'Diffusion_Timesteps': 1000, 'lr': 0.00025, 'weight_decay': 0.0,
                'device_name': self.device
            },
            'Classify_Dict': {
                'xdim': xdim_main, 'cdim': 1, 'tdim': 128, 'net': [64, 64, 64],
                'Training_Epochs': 150000, 'device_name': self.device
            },
            'Drag_Reg_Dict': {
                'xdim': xdim_main, 'ydim': 1, 'tdim': 512, 'net': [512, 512, 512, 512],
                'Training_Epochs': 50000, 'batch_size': 1024, 
                'Model_Label': 'Regressor_CT', 'lr': 0.001, 'weight_decay': 0.0,
                'device_name': self.device
            },
            'LOA_wBulb_Reg_Dict': {
                'xdim': xdim_main, 'ydim': 1, 'tdim': 256, 'net': [256, 256, 256],
                'Training_Epochs': 150000, 'batch_size': 1024, 
                'Model_Label': 'Regressor_LOA_wBulb', 'lr': 0.001, 'weight_decay': 0.0,
                'device_name': self.device
            },
            'WL_Reg_Dict': {
                "xdim": xdim_full, "ydim": 1, "tdim": 512, "net": [512, 512, 512],
                "Training_Epochs": 30000, "batch_size": 1024, 
                "Model_Label": "Regressor_WL", "lr": 0.001, "weight_decay": 0.0,
                "device_name": self.device
            },
            'Vol_Reg_Dict': {
                "xdim": xdim_full, "ydim": 1, "tdim": 512, "net": [512, 512, 512],
                "Training_Epochs": 30000, "batch_size": 1024, 
                "Model_Label": "Regressor_Vol", "lr": 0.001, "weight_decay": 0.0,
                "device_name": self.device
            }
        }

    def _initialize_and_load_models(self) -> GuidedDiffusionEnv:
        print("Initializing and Loading AI Models (this may take a moment)...")
        T = GuidedDiffusionEnv(
            self.model_dicts['DDPM_Dict'], self.model_dicts['Classify_Dict'],
            self.model_dicts['Drag_Reg_Dict'], self.model_dicts['LOA_wBulb_Reg_Dict'],
            self.model_dicts['WL_Reg_Dict'], self.model_dicts['Vol_Reg_Dict'],
            X=self.data['DesVec'][:, 1:], X_neg=self.data['DesVec_neg'],
            VolVec=self.data['VolVec'], BOAVec=self.data['BOAVec'], DdVec=self.data['DdVec']
        )
        
        T.load_trained_diffusion_model(PATH=self.model_dir / 'CShipGen_diffusion.pth', map_location=self.device)
        T.load_trained_classifier_model(PATH=self.model_dir / 'Constraint_Classifier_150000Epochs.pth', map_location=self.device)
        T.load_trained_Drag_regression_models([
            self.model_dir / 'Regressor_CT.pth', self.model_dir / 'Regressor_LOA_wBulb.pth',
            self.model_dir / 'Regressor_WL.pth', self.model_dir / 'Regressor_Vol.pth'
        ])
        return T

    def _generate_and_process_hulls(self, ship_data: np.ndarray, study_label: str):
        # [元の generate_and_process_hulls 関数のロジックをここに配置]
        # ※ self.num_samples, self.t_model などを参照するように変更します。
        
        LOA, BOA, T_draft, Dd, Vol, U = ship_data
        BoL = BOA / LOA
        ToD = T_draft / Dd
        DoL = Dd / LOA
        Vol_log = np.log10(Vol / LOA**3)

        drag_cond = np.repeat(np.array([[ToD, U, LOA]]), self.num_samples, axis=0)
        geom_cond = np.repeat(np.array([[ToD, BoL, DoL, Vol_log]]), self.num_samples, axis=0)

        # 船体生成
        X_gen_cond, _ = self.t_model.gen_cond_samples(geom_cond)
        X_gen, unnorm = self.t_model.gen_vol_drag_guided_samples(geom_cond, drag_cond)
        Rt_guidance = self.t_model.Predict_Drag(unnorm, drag_cond).flatten()

        # 実現可能性チェックと丸め
        x_samples = X_gen.copy()
        idx_BB, idx_BBFactors = self.data['idx_BB'], self.data['idx_BBFactors']
        idx_SB, idx_SBFactors = self.data['idx_SB'], self.data['idx_SBFactors']

        for i in range(len(x_samples)):
            x_samples[i, idx_BB] = (x_samples[i, idx_BB] + 0.5) // 1
            x_samples[i, idx_SB] = (x_samples[i, idx_SB] + 0.5) // 1
            x_samples[i, idx_BBFactors] = x_samples[i, idx_BB] * x_samples[i, idx_BBFactors]
            x_samples[i, idx_SBFactors] = x_samples[i, idx_SB] * x_samples[i, idx_SBFactors]

        valid_idx = [i for i in range(len(x_samples)) if sum(HP(x_samples[i]).input_Constraints() > 0) == 0]

        # 特性計算とSTL出力のロジック
        idx_to_remove = []

        num_WL = 101
        points_per_WL = 1000

        # 各有効な船体サンプル（valid_idx）に対して体積特性（Volume Properties）などを計算
        # すべての有効なインデックスのデータを一旦格納
        print('Calculating Volume Properties...')
        performance_data_temp = {} 
        for i_enum, original_idx in enumerate(tqdm(valid_idx, desc="Calculating Properties", leave=False)):

            # 船体形状をパラメトライズした入力し、その形状から船体（hull）のインスタンス hull_hp を生成
            hull_hp = HP(x_samples[original_idx])
            try:
                # 体積特性の計算
                # 船体を横断する水線に基づいて、排水体積・水面形状・浮心などの特性を数値積分で計算
                Z = hull_hp.Calc_VolumeProperties(NUM_WL=num_WL, PointsPerWL=points_per_WL)

                # 値の確認
                if not np.all(np.isfinite(hull_hp.Volumes)):
                    raise ValueError("Volumes contain nan or inf — skipping this hull")

                # 目的喫水での排水体積の補間
                volume = HP.interp(hull_hp.Volumes, Z, float(ship_data[2]))

                # 最大幅（Beam）の取得
                # ミッドシップ断面や前方断面（PC: Prismatic Coefficient）での最大幅を計算し、その大きい方を採用
                BOA = max(hull_hp.Calc_Max_Beam_midship(), hull_hp.Calc_Max_Beam_PC())
                
                # 深さ (Depth)
                Dd = hull_hp.Dd

                # 全長（Length Overall）
                LOA = hull_hp.LOA

                # バルバスバウを含めた全長
                LOA_wBulb = hull_hp.Calc_LOA_wBulb()

                # Rt_guidance から抵抗値[N]を取得
                total_resistance = Rt_guidance[original_idx]

                # データをまとめる
                performance_data_temp[original_idx] = {
                    "LOA": float(np.squeeze(LOA)),
                    "LOA_with_bulb": float(np.squeeze(LOA_wBulb)),
                    "beam": float(np.squeeze(BOA)),
                    "depth": float(np.squeeze(Dd)),
                    "volume": float(np.squeeze(volume)),
                    "total_resistance": float(np.squeeze(total_resistance))
                }
            
            # 何らかの計算で失敗した場合
            # この時点での valid_idx 内のインデックスを削除対象として記録
            except Exception as e:
                tqdm.write(f'Error at hull {original_idx} during property calculation: {e}')
                idx_to_remove.append(i_enum) 
                continue

        # 船体形状の評価計算で失敗したサンプルを削除
        # 関連するidを取り除く
        valid_idx_final = np.delete(np.array(valid_idx), idx_to_remove).tolist()
        print(f'Number of valid samples after property calculation: {len(valid_idx_final)}')

        # valid_idx_final に基づいて最終的な performance_data を構築
        # これにより、以降で参照されるデータは、確実に有効かつ特性計算に成功したもののみになる
        performance_data_final = {
            idx: performance_data_temp[idx] for idx in valid_idx_final
        }

        # Saving Data
        np.save(self.output_dir / f'{study_label}_Conditioning_Only_DesVec.npy', X_gen_cond)
        
        # valid_idx_final のインデックスに対応するデータのみを保存
        np.save(self.output_dir / f'{study_label}_Drag_Guidance_DesVec.npy', x_samples[valid_idx_final])
        np.save(self.output_dir / f'{study_label}_Rt_pred.npy', Rt_guidance[valid_idx_final])

        # --------------------------------------------------------------------------------
        # MEAP計算
        # --------------------------------------------------------------------------------
        print('Calculating Dimensional Error in Samples (Overall MAEP):')
        
        # performance_data_final から各性能値のリストを抽出
        # 有効な全ての船体形状のデータを使用
        if performance_data_final:
            sample_LOA = np.array([data["LOA"] for data in performance_data_final.values()])
            sample_LOA_wBulb = np.array([data["LOA_with_bulb"] for data in performance_data_final.values()])
            sample_BOA = np.array([data["beam"] for data in performance_data_final.values()])
            sample_Dd = np.array([data["depth"] for data in performance_data_final.values()])
            sample_vol = np.array([data["volume"] for data in performance_data_final.values()])

            # 設計仕様としてユーザーが入力した目標値 (ship_data)
            target_LOA = ship_data[0]
            target_BOA = ship_data[1]
            target_Dd = ship_data[3]
            target_Vol = ship_data[4]

            # MAEPの計算と表示
            LOAMEAP = np.mean(np.abs(sample_LOA - target_LOA) / target_LOA) * 100
            print(f'  Length MEAP: {LOAMEAP:.2f}%')

            LOA_wBulbMEAP = np.mean(np.abs(sample_LOA_wBulb - target_LOA) / target_LOA) * 100
            print(f'  Length wBulb MEAP: {LOA_wBulbMEAP:.2f}%')

            VolMEAP = np.mean(np.abs(sample_vol - target_Vol) / target_Vol) * 100
            print(f'  Volume MEAP: {VolMEAP:.2f}%')

            BOAMEAP = np.mean(np.abs(sample_BOA - target_BOA) / target_BOA) * 100
            print(f'  Beam MEAP: {BOAMEAP:.2f}%')

            DdMEAP = np.mean(np.abs(sample_Dd - target_Dd) / target_Dd) * 100
            print(f'  Depth MEAP: {DdMEAP:.2f}%')
            
            # これらの全体MAEPを辞書として返す
            overall_meaps_dict = {
                "overall_LOA_MEAP": float(LOAMEAP),
                "overall_LOA_with_bulb_MEAP": float(LOA_wBulbMEAP),
                "overall_beam_MEAP": float(BOAMEAP),
                "overall_depth_MEAP": float(DdMEAP),
                "overall_volume_MEAP": float(VolMEAP),
            }
        else:
            print("  No valid samples to calculate overall MEAP.")
            overall_meaps_dict = {}

        # 実現可能性+うまく性能値を計算できた形状に対しstlデータを作成
        print('Generating STLs...')

        # -----------------------------------------------------------------------
        # STL生成対象のインデックスリストを作成
        # Step1: 幾何拘束フィルタ（geometric_constraint=True の場合のみ）
        # Step2: resist_min=True  → 抵抗値昇順でソート
        #        resist_min=False → ID昇順（フィルタ後の順序を維持）
        # -----------------------------------------------------------------------

        # Step1: 幾何拘束フィルタ（両分岐で共通）
        if self.geometric_constraint:
            target_BOA = ship_data[1]
            target_Dd  = ship_data[3]
            target_Vol = ship_data[4]

            filtered_idx = []
            for idx in valid_idx_final:
                perf = performance_data_final[idx]
                vol_meap = abs(perf["volume"] - target_Vol) / target_Vol * 100
                boa_meap = abs(perf["beam"]   - target_BOA) / target_BOA * 100
                dd_meap  = abs(perf["depth"]  - target_Dd)  / target_Dd  * 100
                if (vol_meap <= self.meap_threshold and
                    boa_meap <= self.meap_threshold and
                    dd_meap  <= self.meap_threshold):
                    filtered_idx.append(idx)

            print(f"  {len(filtered_idx)} / {len(valid_idx_final)} samples passed the geometry constraints (Threshold: {self.meap_threshold}%)")
        else:
            # 閾値チェックなし：全サンプルを対象にする
            filtered_idx = valid_idx_final

        # Step2: resist_min に応じてソート順を決定
        if self.resist_min:
            # 抵抗値昇順にソート
            candidate_idx = sorted(filtered_idx, key=lambda idx: performance_data_final[idx]["total_resistance"])
        else:
            # ID昇順（filtered_idx の順序をそのまま維持）
            candidate_idx = filtered_idx

        # -----------------------------------------------------------------------
        # STL生成ループ（resist_min の True/False によらず共通）
        # -----------------------------------------------------------------------
        stl_results = []
        num_stls_to_generate = min(self.num_generate, len(candidate_idx))
        for i in range(num_stls_to_generate):

            idx  = candidate_idx[i]
            Hull = HP(x_samples[idx])

            try:
                stl_filename   = f"{study_label}_Hull_{i}_{uuid4().hex}"
                strpath        = self.output_dir / stl_filename
                Hull.gen_stl(
                    NUM_WL=100,
                    PointsPerWL=800,
                    bit_AddTransom=1,
                    bit_AddDeckLid=1,
                    namepath=str(strpath)
                )

                stl_local_path = str(strpath.with_suffix('.stl'))
                perf           = performance_data_final[idx]

                stl_results.append({
                    "index":             idx,
                    "stl_local_path":    stl_local_path,
                    **perf,
                    "LOA_MEAP":          float(abs(perf["LOA"]           - ship_data[0]) / ship_data[0] * 100),
                    "LOA_with_bulb_MEAP":float(abs(perf["LOA_with_bulb"] - ship_data[0]) / ship_data[0] * 100),
                    "beam_MEAP":         float(abs(perf["beam"]           - ship_data[1]) / ship_data[1] * 100),
                    "depth_MEAP":        float(abs(perf["depth"]          - ship_data[3]) / ship_data[3] * 100),
                    "volume_MEAP":       float(abs(perf["volume"]         - ship_data[4]) / ship_data[4] * 100),
                })

            except Exception as e:
                tqdm.write(f'Error at hull {i} during STL generation: {e}')
                continue

        return stl_results, overall_meaps_dict


    # ==========================================
    # ヘルパーメソッド (丸め・整形)
    # ==========================================
    def _calculate_meap_averages(self, hulls: list[dict]) -> dict:
        if not hulls: return {}
        keys = ["LOA_MEAP", "LOA_with_bulb_MEAP", "beam_MEAP", "depth_MEAP", "volume_MEAP"]
        result = {}
        for key in keys:
            vals = [h[key] for h in hulls if key in h]
            result[key] = float(np.mean(vals)) if vals else 0.0
        return result

    def _round_hulls_data(self, hulls: list[dict]) -> list[dict]:
        rounded = []
        for h in hulls:
            r = {k: round(v, 3) if isinstance(v, float) else v for k, v in h.items()}
            rounded.append(r)
        return rounded
        
    def _round_dict(self, data: dict) -> dict:
        return {k: round(v, 2) if isinstance(v, float) else v for k, v in data.items()}