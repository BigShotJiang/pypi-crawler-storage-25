"""WebAssembly text format (WAT) emitter that consumes MIR.

Translates MIR basic blocks, instructions, and phi nodes into WebAssembly
text format (.wat). The emitter produces a self-contained WASM module with:

- Linear memory (bump-allocated heap)
- String constant data section
- Imported JS bridge functions (console_log, etc.)
- Exported main function and memory
- Full control flow via structured blocks/loops/br_if

Type mapping (Mapanare -> WASM):
    Int       -> i64
    Float     -> f64
    Bool      -> i32 (0 or 1)
    String    -> i32 (pointer into linear memory)
    List      -> i32 (pointer to heap-allocated {len, cap, data_ptr})
    Map       -> i32 (pointer to heap-allocated hash table)
    Struct    -> i32 (pointer to heap-allocated fields)
    Option    -> i32 (tagged pointer: tag + payload)
    Result    -> i32 (tagged pointer: tag + payload)
    Agent     -> i32 (pointer to agent struct)
    Stream    -> i32 (pointer to stream struct)
    Signal    -> i32 (pointer to signal struct)
    Tensor    -> i32 (pointer to tensor struct)
    Void      -> (no value)

Usage:
    from mapanare.emit_wasm import compile_to_wasm
    wat_text = compile_to_wasm(mir_module)
"""

from __future__ import annotations

import logging
import struct
import subprocess
from dataclasses import dataclass, field
from typing import Any

from mapanare.mir import (
    AgentSend,
    AgentSpawn,
    AgentSync,
    Assert,
    BasicBlock,
    BinOp,
    BinOpKind,
    Branch,
    Call,
    Cast,
    ClosureCall,
    ClosureCreate,
    Const,
    Copy,
    EnumInit,
    EnumPayload,
    EnumTag,
    EnvLoad,
    ExternCall,
    FieldGet,
    FieldSet,
    IndexGet,
    IndexSet,
    Instruction,
    InterpConcat,
    Jump,
    ListInit,
    ListPush,
    MapInit,
    MIRFunction,
    MIRModule,
    MIRType,
    Phi,
    Return,
    SignalComputed,
    SignalGet,
    SignalInit,
    SignalSet,
    SignalSubscribe,
    StreamInit,
    StreamOp,
    StructInit,
    Switch,
    UnaryOp,
    UnaryOpKind,
    Unwrap,
    Value,
    WrapErr,
    WrapNone,
    WrapOk,
    WrapSome,
)
from mapanare.types import TypeKind

_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# WASM type strings
# ---------------------------------------------------------------------------

_WASM_I32 = "i32"
_WASM_I64 = "i64"
_WASM_F64 = "f64"

# Heap layout constants (byte sizes)
_PTR_SIZE = 4  # i32 pointers in wasm32
_I64_SIZE = 8
_F64_SIZE = 8
_I32_SIZE = 4

# String layout: [i32 len][i32 cap][...bytes...]
_STRING_HEADER_SIZE = 8  # len (4) + cap (4)

# List layout: [i32 len][i32 cap][i32 elem_size][i32 data_ptr]
_LIST_HEADER_SIZE = 16

# Option/Result layout: [i32 tag][i64 payload]
_TAGGED_UNION_SIZE = 12  # tag (4) + payload (8)

# Signal layout: [i64 value][i32 subscriber_count][i32 subscribers_ptr]
_SIGNAL_SIZE = 16

# Stream layout: [i32 source_ptr][i32 state][i32 callback_idx]
_STREAM_SIZE = 12

# Agent layout: [i32 state_ptr][i32 inbox_ptr][i32 outbox_ptr][i32 status]
_AGENT_SIZE = 16

# Default linear memory: 1 page = 64 KiB
_INITIAL_MEMORY_PAGES = 1
_MAX_MEMORY_PAGES = 256  # 16 MiB max

# Bump allocator globals
_HEAP_BASE_GLOBAL = "__heap_base"
_HEAP_PTR_GLOBAL = "__heap_ptr"


# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------


@dataclass
class WasmModuleImport:
    """Describes an imported function from another WASM module."""

    module: str  # Source module name (e.g. "math_utils")
    name: str  # Function name in the source module
    params: list[str] = field(default_factory=list)  # WASM param types
    result: str | None = None  # WASM result type, or None for void


@dataclass(slots=True)
class WasmOptions:
    """Configuration for the WASM emitter."""

    module_name: str = "mapanare_module"
    initial_memory_pages: int = _INITIAL_MEMORY_PAGES
    max_memory_pages: int = _MAX_MEMORY_PAGES
    export_all_functions: bool = False
    debug_names: bool = True
    optimize: bool = False
    # Target WASI (wasm32-wasi) instead of browser (wasm32-unknown-unknown)
    wasi: bool = False
    # Cross-module imports: functions this module needs from other modules
    module_imports: list[WasmModuleImport] = field(default_factory=list)


# ---------------------------------------------------------------------------
# String table
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class StringConstant:
    """A string constant stored in the data section."""

    value: str
    offset: int  # Byte offset in linear memory
    byte_length: int  # Length of UTF-8 encoded bytes


# ---------------------------------------------------------------------------
# Struct layout
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class StructLayout:
    """Memory layout for a struct type."""

    name: str
    fields: list[tuple[str, str]]  # (field_name, wasm_type)
    field_offsets: dict[str, int] = field(default_factory=dict)
    total_size: int = 0


# ---------------------------------------------------------------------------
# WasmEmitter
# ---------------------------------------------------------------------------


class WasmEmitter:
    """Emits WebAssembly text format (WAT) from a MIR module.

    The emitter walks MIR functions and basic blocks, translating each
    instruction into WAT instructions. Control flow is restructured from
    the CFG into WASM's structured control flow (block/loop/br/br_if).

    Phi nodes are lowered to local variables with assignments inserted
    in predecessor blocks before branches.
    """

    def __init__(self, options: WasmOptions | None = None) -> None:
        self._options = options or WasmOptions()

        # Module-level state
        self._string_table: list[StringConstant] = []
        self._string_cache: dict[str, int] = {}  # string value -> offset
        self._data_offset: int = 0  # Next free byte in data section
        self._struct_layouts: dict[str, StructLayout] = {}
        self._enum_variants: dict[str, dict[str, int]] = {}  # enum -> {variant: tag}
        self._func_types: dict[str, tuple[list[str], str | None]] = {}  # fn -> (params, ret)
        self._func_indices: dict[str, int] = {}
        self._import_count: int = 0

        # Per-function state
        self._locals: dict[str, str] = {}  # local name -> wasm type
        self._local_indices: dict[str, int] = {}
        self._param_count: int = 0
        self._body_lines: list[str] = []
        self._indent_level: int = 0
        self._block_map: dict[str, BasicBlock] = {}
        self._block_indices: dict[str, int] = {}
        self._phi_locals: dict[str, str] = {}  # phi dest -> wasm type
        self._current_fn: MIRFunction | None = None
        self._visited_blocks: set[str] = set()

        # Instruction dispatch table
        self._dispatch: dict[type, Any] = {}
        self._init_dispatch()

    # ------------------------------------------------------------------
    # Dispatch table
    # ------------------------------------------------------------------

    def _init_dispatch(self) -> None:
        """Build instruction dispatch table mapping MIR types to handlers."""
        d = self._dispatch
        d[Const] = self._emit_const
        d[Copy] = self._emit_copy
        d[Cast] = self._emit_cast
        d[BinOp] = self._emit_binop
        d[UnaryOp] = self._emit_unaryop
        d[Call] = self._emit_call
        d[ExternCall] = self._emit_extern_call
        d[Return] = self._emit_return
        d[Jump] = self._emit_jump
        d[Branch] = self._emit_branch
        d[Switch] = self._emit_switch
        d[StructInit] = self._emit_struct_init
        d[FieldGet] = self._emit_field_get
        d[FieldSet] = self._emit_field_set
        d[ListInit] = self._emit_list_init
        d[ListPush] = self._emit_list_push
        d[IndexGet] = self._emit_index_get
        d[IndexSet] = self._emit_index_set
        d[MapInit] = self._emit_map_init
        d[EnumInit] = self._emit_enum_init
        d[EnumTag] = self._emit_enum_tag
        d[EnumPayload] = self._emit_enum_payload
        d[WrapSome] = self._emit_wrap_some
        d[WrapNone] = self._emit_wrap_none
        d[WrapOk] = self._emit_wrap_ok
        d[WrapErr] = self._emit_wrap_err
        d[Unwrap] = self._emit_unwrap
        d[InterpConcat] = self._emit_interp_concat
        d[AgentSpawn] = self._emit_agent_spawn
        d[AgentSend] = self._emit_agent_send
        d[AgentSync] = self._emit_agent_sync
        d[SignalInit] = self._emit_signal_init
        d[SignalGet] = self._emit_signal_get
        d[SignalSet] = self._emit_signal_set
        d[SignalComputed] = self._emit_signal_computed
        d[SignalSubscribe] = self._emit_signal_subscribe
        d[StreamInit] = self._emit_stream_init
        d[StreamOp] = self._emit_stream_op
        d[ClosureCreate] = self._emit_closure_create
        d[ClosureCall] = self._emit_closure_call
        d[EnvLoad] = self._emit_env_load
        d[Assert] = self._emit_assert
        d[Phi] = self._emit_phi

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def emit(self, module: MIRModule) -> str:
        """Emit a complete WAT module from a MIR module.

        Returns the WebAssembly text format as a string.
        """
        self._reset_module_state()
        self._register_types(module)
        self._collect_strings(module)
        self._collect_function_signatures(module)

        lines: list[str] = []
        lines.append(f"(module ${self._options.module_name}")

        # Imports (JS bridge) — must come before all non-import definitions
        lines.extend(self._emit_import_section())

        # Memory declaration
        lines.extend(self._emit_memory_section())

        # Global variables (heap pointer)
        lines.extend(self._emit_globals_section())

        # Function type declarations
        lines.extend(self._emit_type_section(module))

        # Function bodies
        for mir_fn in module.functions:
            lines.extend(self._emit_function(mir_fn))

        # Bump allocator helper
        lines.extend(self._emit_bump_alloc())

        # Builtin function stubs
        lines.extend(self._emit_builtin_stubs())

        # Data section (string constants)
        lines.extend(self._emit_data_section())

        # Exports
        lines.extend(self._emit_export_section(module))

        lines.append(")")
        return "\n".join(lines) + "\n"

    # ------------------------------------------------------------------
    # Module-level reset
    # ------------------------------------------------------------------

    def _reset_module_state(self) -> None:
        """Reset all module-level state for a fresh emission."""
        self._string_table = []
        self._string_cache = {}
        self._data_offset = _STRING_HEADER_SIZE  # Reserve space for data section header
        self._struct_layouts = {}
        self._enum_variants = {}
        self._func_types = {}
        self._func_indices = {}
        self._import_count = 0

    # ------------------------------------------------------------------
    # Type registration
    # ------------------------------------------------------------------

    def _register_types(self, module: MIRModule) -> None:
        """Register struct and enum layouts from the MIR module."""
        for name, fields in module.structs.items():
            self._register_struct(name, fields)
        for name, variants in module.enums.items():
            self._register_enum(name, variants)

    def _register_struct(self, name: str, fields: list[tuple[str, MIRType]]) -> None:
        """Compute memory layout for a struct type."""
        layout = StructLayout(name=name, fields=[])
        offset = 0
        for field_name, field_type in fields:
            wasm_ty = self._mir_type_to_wasm(field_type)
            size = self._wasm_type_size(wasm_ty)
            # Align to natural boundary
            alignment = size if size <= 8 else 8
            if offset % alignment != 0:
                offset += alignment - (offset % alignment)
            layout.fields.append((field_name, wasm_ty))
            layout.field_offsets[field_name] = offset
            offset += size
        # Round up total size to 8-byte alignment
        if offset % 8 != 0:
            offset += 8 - (offset % 8)
        layout.total_size = max(offset, _PTR_SIZE)
        self._struct_layouts[name] = layout

    def _register_enum(self, name: str, variants: list[tuple[str, list[MIRType]]]) -> None:
        """Register enum variant tags."""
        self._enum_variants[name] = {}
        for tag, (variant_name, _payload_types) in enumerate(variants):
            self._enum_variants[name][variant_name] = tag

    # ------------------------------------------------------------------
    # String collection
    # ------------------------------------------------------------------

    def _collect_strings(self, module: MIRModule) -> None:
        """Scan all MIR functions for string constants and build the string table."""
        for fn in module.functions:
            for bb in fn.blocks:
                for inst in bb.instructions:
                    if isinstance(inst, Const) and isinstance(inst.value, str):
                        self._intern_string(inst.value)
                    elif isinstance(inst, Assert) and inst.message is None:
                        # Default assertion message
                        msg = f"assertion failed at {inst.filename}:{inst.line}"
                        self._intern_string(msg)

    def _intern_string(self, value: str) -> int:
        """Add a string to the constant table, returning its memory offset.

        The string is stored as: [i32 byte_length][UTF-8 bytes]
        The returned offset points to the length prefix.
        """
        if value in self._string_cache:
            return self._string_cache[value]
        encoded = value.encode("utf-8")
        byte_len = len(encoded)
        # Align to 4-byte boundary
        if self._data_offset % 4 != 0:
            self._data_offset += 4 - (self._data_offset % 4)
        offset = self._data_offset
        self._string_table.append(StringConstant(value=value, offset=offset, byte_length=byte_len))
        self._string_cache[value] = offset
        # Layout: [i32 length][bytes...]
        self._data_offset += _I32_SIZE + byte_len
        # Align next entry
        if self._data_offset % 4 != 0:
            self._data_offset += 4 - (self._data_offset % 4)
        return offset

    # ------------------------------------------------------------------
    # Function signature collection
    # ------------------------------------------------------------------

    def _collect_function_signatures(self, module: MIRModule) -> None:
        """Build function type maps from MIR function signatures."""
        idx = self._import_count
        for mir_fn in module.functions:
            param_types = [self._mir_type_to_wasm(p.ty) for p in mir_fn.params]
            ret_type = self._mir_type_to_wasm_ret(mir_fn.return_type)
            self._func_types[mir_fn.name] = (param_types, ret_type)
            self._func_indices[mir_fn.name] = idx
            idx += 1

    # ------------------------------------------------------------------
    # Type mapping
    # ------------------------------------------------------------------

    def _mir_type_to_wasm(self, mir_type: MIRType) -> str:
        """Map a MIR type to a WASM value type string.

        Primitives map to native WASM types. All heap-allocated types
        (String, List, Map, Struct, Agent, etc.) map to i32 pointers.
        """
        kind = mir_type.kind
        if kind == TypeKind.INT:
            return _WASM_I64
        if kind == TypeKind.FLOAT:
            return _WASM_F64
        if kind == TypeKind.BOOL:
            return _WASM_I32
        if kind == TypeKind.CHAR:
            return _WASM_I32
        if kind == TypeKind.VOID:
            return ""  # No WASM type for void
        # All heap-allocated types use i32 pointer
        if kind in (
            TypeKind.STRING,
            TypeKind.LIST,
            TypeKind.MAP,
            TypeKind.STRUCT,
            TypeKind.ENUM,
            TypeKind.OPTION,
            TypeKind.RESULT,
            TypeKind.AGENT,
            TypeKind.SIGNAL,
            TypeKind.STREAM,
            TypeKind.TENSOR,
            TypeKind.PIPE,
            TypeKind.CHANNEL,
            TypeKind.FN,
        ):
            return _WASM_I32
        # Unknown / generic fallback
        if kind == TypeKind.UNKNOWN:
            return _WASM_I64  # Default to i64 for unknown types
        return _WASM_I64

    def _mir_type_to_wasm_ret(self, mir_type: MIRType) -> str | None:
        """Map a MIR return type. Returns None for void."""
        wasm_ty = self._mir_type_to_wasm(mir_type)
        return wasm_ty if wasm_ty else None

    @staticmethod
    def _wasm_type_size(wasm_ty: str) -> int:
        """Return the byte size of a WASM value type."""
        if wasm_ty == _WASM_I64:
            return _I64_SIZE
        if wasm_ty == _WASM_F64:
            return _F64_SIZE
        if wasm_ty == _WASM_I32:
            return _I32_SIZE
        return _I32_SIZE  # Default for pointers

    # ------------------------------------------------------------------
    # Module sections
    # ------------------------------------------------------------------

    def _emit_memory_section(self) -> list[str]:
        """Emit the linear memory declaration."""
        return [
            f'  (memory (export "memory") {self._options.initial_memory_pages}'
            f" {self._options.max_memory_pages})"
        ]

    def _emit_import_section(self) -> list[str]:
        """Emit host imports (JS bridge or WASI depending on target)."""
        lines: list[str] = []
        if self._options.wasi:
            imports: list[tuple[str, str, list[str], str | None]] = [
                (
                    "wasi_snapshot_preview1",
                    "fd_write",
                    [_WASM_I32, _WASM_I32, _WASM_I32, _WASM_I32],
                    _WASM_I32,
                ),
            ]
        else:
            imports = [
                ("env", "console_log_i32", [_WASM_I32], None),
                ("env", "console_log_i64", [_WASM_I64], None),
                ("env", "console_log_f64", [_WASM_F64], None),
                ("env", "console_log_str", [_WASM_I32, _WASM_I32], None),
                ("env", "console_log_newline", [], None),
                ("env", "console_log_bool", [_WASM_I32], None),
                ("env", "abort", [_WASM_I32, _WASM_I32], None),
            ]
        for mod, name, params, ret in imports:
            param_str = " ".join(f"(param {p})" for p in params)
            result_str = f" (result {ret})" if ret else ""
            lines.append(f'  (import "{mod}" "{name}" (func ${name} {param_str}{result_str}))')
            self._func_indices[name] = self._import_count
            self._import_count += 1

        # Cross-module imports (functions from other WASM modules)
        for mod_import in self._options.module_imports:
            param_str = " ".join(f"(param {p})" for p in mod_import.params)
            result_str = f" (result {mod_import.result})" if mod_import.result else ""
            # Namespace by module to avoid collisions when importing same-named
            # functions from different modules
            namespaced = f"{mod_import.module}__{mod_import.name}"
            safe_name = _sanitize_name(namespaced)
            lines.append(
                f'  (import "{mod_import.module}" "{mod_import.name}"'
                f" (func ${safe_name} {param_str}{result_str}))"
            )
            self._func_indices[namespaced] = self._import_count
            self._import_count += 1

        return lines

    def _emit_globals_section(self) -> list[str]:
        """Emit global variables for the bump allocator."""
        # Heap pointer starts after the data section
        # We'll patch this value once we know data section size
        return [
            f"  (global ${_HEAP_PTR_GLOBAL} (mut i32) (i32.const 0))",
        ]

    def _emit_type_section(self, module: MIRModule) -> list[str]:
        """Emit function type declarations and table for indirect calls."""
        lines: list[str] = []
        # Check if we need indirect call support (closures or stream ops with callbacks)
        needs_table = any(
            isinstance(inst, (ClosureCreate, ClosureCall, StreamOp))
            for fn in module.functions
            for bb in fn.blocks
            for inst in bb.instructions
        )
        if needs_table and self._func_indices:
            # Build function table with all known functions for call_indirect.
            # Table size = total number of functions (imports + user-defined).
            total_funcs = len(self._func_indices)
            # Collect function names sorted by their index
            sorted_fns = sorted(self._func_indices.items(), key=lambda x: x[1])
            func_refs = " ".join(f"${_sanitize_name(name)}" for name, _idx in sorted_fns)
            lines.append(f"  (table {total_funcs} funcref)")
            lines.append(f"  (elem (i32.const 0) func {func_refs})")
        return lines

    def _emit_data_section(self) -> list[str]:
        """Emit the data section with string constants."""
        if not self._string_table:
            return []
        lines: list[str] = []
        for sc in self._string_table:
            encoded = sc.value.encode("utf-8")
            # Encode length prefix as little-endian i32
            len_bytes = struct.pack("<I", sc.byte_length)
            all_bytes = len_bytes + encoded
            hex_str = "".join(f"\\{b:02x}" for b in all_bytes)
            lines.append(f'  (data (i32.const {sc.offset}) "{hex_str}")')
        return lines

    def _emit_export_section(self, module: MIRModule) -> list[str]:
        """Emit exports: main function and optionally all public functions."""
        lines: list[str] = []
        # Export main if it exists
        main_fn = module.get_function("main")
        if main_fn is not None:
            lines.append('  (export "main" (func $main))')
        # Export the bump allocator for testing
        lines.append('  (export "__alloc" (func $__alloc))')
        # Export all public or all functions if requested
        if self._options.export_all_functions:
            for fn in module.functions:
                if fn.name != "main":
                    safe_name = _sanitize_name(fn.name)
                    lines.append(f'  (export "{fn.name}" (func ${safe_name}))')
        else:
            for fn in module.functions:
                if fn.is_public and fn.name != "main":
                    safe_name = _sanitize_name(fn.name)
                    lines.append(f'  (export "{fn.name}" (func ${safe_name}))')
        # Start function: initialize heap pointer then call main
        if main_fn is not None:
            lines.append('  (export "_start" (func $_start))')
            start_lines = [
                "  (func $_start",
                f"    (global.set ${_HEAP_PTR_GLOBAL} (i32.const {self._data_offset}))",
                "    (call $main)",
            ]
            # If main returns a value, drop it
            ret = self._mir_type_to_wasm_ret(main_fn.return_type)
            if ret:
                start_lines.append("    drop")
            start_lines.append("  )")
            lines.extend(start_lines)
        else:
            # No main: just an init function for heap
            lines.append('  (export "_initialize" (func $_initialize))')
            lines.append("  (func $_initialize")
            lines.append(f"    (global.set ${_HEAP_PTR_GLOBAL} (i32.const {self._data_offset}))")
            lines.append("  )")
        return lines

    # ------------------------------------------------------------------
    # Bump allocator
    # ------------------------------------------------------------------

    def _emit_bump_alloc(self) -> list[str]:
        """Emit the bump allocator function.

        Signature: __alloc(size: i32, align: i32) -> i32
        Returns a pointer to the allocated block. Bumps the heap pointer
        forward. Does not support freeing.
        """
        return [
            "  (func $__alloc (param $size i32) (param $align i32) (result i32)",
            "    (local $ptr i32)",
            "    ;; Align the current heap pointer",
            "    (local.set $ptr",
            "      (i32.and",
            "        (i32.add",
            f"          (global.get ${_HEAP_PTR_GLOBAL})",
            "          (i32.sub (local.get $align) (i32.const 1))",
            "        )",
            "        (i32.xor (i32.sub (local.get $align) (i32.const 1)) (i32.const -1))",
            "      )",
            "    )",
            "    ;; Bump heap pointer past the allocation",
            f"    (global.set ${_HEAP_PTR_GLOBAL}",
            "      (i32.add (local.get $ptr) (local.get $size))",
            "    )",
            "    ;; Check for OOM (heap exceeds memory size)",
            f"    (if (i32.gt_u (global.get ${_HEAP_PTR_GLOBAL})"
            f" (i32.mul (memory.size) (i32.const 65536)))",
            "      (then",
            "        ;; Try to grow memory",
            "        (if (i32.eq (memory.grow (i32.const 1)) (i32.const -1))",
            "          (then (unreachable))",
            "        )",
            "      )",
            "    )",
            "    (local.get $ptr)",
            "  )",
        ]

    # ------------------------------------------------------------------
    # Builtin stubs
    # ------------------------------------------------------------------

    def _emit_builtin_stubs(self) -> list[str]:
        """Emit builtin function implementations.

        These are WASM-native implementations of Mapanare builtins that
        delegate to imported JS bridge functions or operate on linear memory.
        """
        lines: list[str] = []

        # print(value) — polymorphic, we emit typed variants
        # The MIR-level Call to "print" is dispatched by type at emit time.

        # len(string) -> Int: read i32 length from string pointer
        lines.extend(
            [
                "  (func $__builtin_len_str (param $ptr i32) (result i64)",
                "    (i64.extend_i32_u (i32.load (local.get $ptr)))",
                "  )",
            ]
        )

        # len(list) -> Int: read i32 length from list header
        lines.extend(
            [
                "  (func $__builtin_len_list (param $ptr i32) (result i64)",
                "    (i64.extend_i32_u (i32.load (local.get $ptr)))",
                "  )",
            ]
        )

        # int(float) -> Int: truncate f64 to i64
        lines.extend(
            [
                "  (func $__builtin_int_f64 (param $v f64) (result i64)",
                "    (i64.trunc_f64_s (local.get $v))",
                "  )",
            ]
        )

        # float(int) -> Float: convert i64 to f64
        lines.extend(
            [
                "  (func $__builtin_float_i64 (param $v i64) (result f64)",
                "    (f64.convert_i64_s (local.get $v))",
                "  )",
            ]
        )

        # str(int) -> String: convert integer to string (heap-allocated)
        # Extracts digits least-significant-first, then reverses in place.
        lines.extend(
            [
                "  (func $__builtin_str_i64 (param $v i64) (result i32)",
                "    (local $ptr i32)",
                "    (local $buf i32)",
                "    (local $len i32)",
                "    (local $neg i32)",
                "    (local $digit i64)",
                "    (local $tmp i64)",
                "    (local $i i32)",
                "    (local $lo i32)",
                "    (local $hi i32)",
                "    (local $swap i32)",
                "    ;; Allocate 24 bytes: 4 (len) + 20 (max i64 decimal digits)",
                "    (local.set $ptr (call $__alloc (i32.const 24) (i32.const 4)))",
                "    (local.set $buf (i32.add (local.get $ptr) (i32.const 4)))",
                "    (local.set $tmp (local.get $v))",
                "    ;; Handle negative",
                "    (if (i64.lt_s (local.get $tmp) (i64.const 0))",
                "      (then",
                "        (local.set $neg (i32.const 1))",
                "        (local.set $tmp (i64.sub (i64.const 0) (local.get $tmp)))",
                "      )",
                "    )",
                "    ;; Handle zero",
                "    (if (i64.eqz (local.get $tmp))",
                "      (then",
                "        (i32.store8 (local.get $buf) (i32.const 48))",
                "        (local.set $len (i32.const 1))",
                "      )",
                "      (else",
                "        ;; Extract digits least-significant first",
                "        (local.set $i (i32.const 0))",
                "        (block $done",
                "          (loop $digits",
                "            (br_if $done (i64.eqz (local.get $tmp)))",
                "            (local.set $digit (i64.rem_u (local.get $tmp) (i64.const 10)))",
                "            (i32.store8",
                "              (i32.add (local.get $buf) (local.get $i))",
                "              (i32.add (i32.const 48) (i32.wrap_i64 (local.get $digit)))",
                "            )",
                "            (local.set $tmp (i64.div_u (local.get $tmp) (i64.const 10)))",
                "            (local.set $i (i32.add (local.get $i) (i32.const 1)))",
                "            (br $digits)",
                "          )",
                "        )",
                "        (local.set $len (local.get $i))",
                "        ;; Reverse digits in place: lo=0, hi=len-1",
                "        (local.set $lo (i32.const 0))",
                "        (local.set $hi (i32.sub (local.get $len) (i32.const 1)))",
                "        (block $rev_done",
                "          (loop $rev",
                "            (br_if $rev_done (i32.ge_s (local.get $lo) (local.get $hi)))",
                "            ;; swap buf[lo] and buf[hi]",
                "            (local.set $swap"
                " (i32.load8_u (i32.add (local.get $buf) (local.get $lo))))",
                "            (i32.store8",
                "              (i32.add (local.get $buf) (local.get $lo))",
                "              (i32.load8_u (i32.add (local.get $buf) (local.get $hi)))",
                "            )",
                "            (i32.store8",
                "              (i32.add (local.get $buf) (local.get $hi))",
                "              (local.get $swap)",
                "            )",
                "            (local.set $lo (i32.add (local.get $lo) (i32.const 1)))",
                "            (local.set $hi (i32.sub (local.get $hi) (i32.const 1)))",
                "            (br $rev)",
                "          )",
                "        )",
                "      )",
                "    )",
                "    ;; Prepend '-' if negative: shift digits right and insert",
                "    (if (local.get $neg)",
                "      (then",
                "        ;; Shift all digits one position right",
                "        (local.set $i (local.get $len))",
                "        (block $shift_done",
                "          (loop $shift",
                "            (br_if $shift_done (i32.le_s (local.get $i) (i32.const 0)))",
                "            (i32.store8",
                "              (i32.add (local.get $buf) (local.get $i))",
                "              (i32.load8_u (i32.add (local.get $buf)"
                " (i32.sub (local.get $i) (i32.const 1))))",
                "            )",
                "            (local.set $i (i32.sub (local.get $i) (i32.const 1)))",
                "            (br $shift)",
                "          )",
                "        )",
                "        ;; Write '-' at position 0",
                "        (i32.store8 (local.get $buf) (i32.const 45))",
                "        (local.set $len (i32.add (local.get $len) (i32.const 1)))",
                "      )",
                "    )",
                "    ;; Write length prefix",
                "    (i32.store (local.get $ptr) (local.get $len))",
                "    (local.get $ptr)",
                "  )",
            ]
        )

        if self._options.wasi:
            # WASI: write bytes to stdout via fd_write
            lines.extend(
                [
                    "  (func $__wasi_write (param $ptr i32) (param $len i32)",
                    "    ;; Build iovec at scratch area (heap_ptr)",
                    "    (i32.store (global.get $__heap_ptr) (local.get $ptr))",
                    "    (i32.store (i32.add (global.get $__heap_ptr) (i32.const 4))"
                    " (local.get $len))",
                    "    (drop (call $fd_write",
                    "      (i32.const 1)",
                    "      (global.get $__heap_ptr)",
                    "      (i32.const 1)",
                    "      (i32.add (global.get $__heap_ptr) (i32.const 8))",
                    "    ))",
                    "  )",
                ]
            )
            lines.extend(
                [
                    "  (func $__builtin_print_str (param $ptr i32)",
                    "    (call $__wasi_write",
                    "      (i32.add (local.get $ptr) (i32.const 4))",
                    "      (i32.load (local.get $ptr))",
                    "    )",
                    "  )",
                ]
            )
            lines.extend(
                [
                    "  (func $__wasi_write_newline",
                    "    ;; Store newline byte at scratch+12 (after iovec+nwritten)",
                    "    (i32.store8 (i32.add (global.get $__heap_ptr) (i32.const 12))"
                    " (i32.const 10))",
                    "    (call $__wasi_write",
                    "      (i32.add (global.get $__heap_ptr) (i32.const 12))",
                    "      (i32.const 1)",
                    "    )",
                    "  )",
                ]
            )
            lines.extend(
                [
                    "  (func $__builtin_println_str (param $ptr i32)",
                    "    (call $__builtin_print_str (local.get $ptr))",
                    "    (call $__wasi_write_newline)",
                    "  )",
                ]
            )
        else:
            # Browser: print string via imported console_log_str
            lines.extend(
                [
                    "  (func $__builtin_print_str (param $ptr i32)",
                    "    (call $console_log_str",
                    "      (i32.add (local.get $ptr) (i32.const 4))",
                    "      (i32.load (local.get $ptr))",
                    "    )",
                    "  )",
                ]
            )
            lines.extend(
                [
                    "  (func $__builtin_println_str (param $ptr i32)",
                    "    (call $__builtin_print_str (local.get $ptr))",
                    "    (call $console_log_newline)",
                    "  )",
                ]
            )

        return lines

    # ------------------------------------------------------------------
    # Function emission
    # ------------------------------------------------------------------

    def _emit_function(self, mir_fn: MIRFunction) -> list[str]:
        """Emit a single WASM function from its MIR representation.

        Steps:
        1. Build block map and assign block indices
        2. Collect all SSA values as locals
        3. Lower phi nodes to local assignments
        4. Emit structured control flow
        """
        self._reset_function_state(mir_fn)
        safe_name = _sanitize_name(mir_fn.name)

        # Build param and result type strings
        param_parts: list[str] = []
        for p in mir_fn.params:
            wasm_ty = self._mir_type_to_wasm(p.ty)
            if wasm_ty:
                local_name = _sanitize_name(p.name)
                param_parts.append(f"(param ${local_name} {wasm_ty})")
                self._locals[p.name] = wasm_ty
                self._local_indices[p.name] = len(self._local_indices)
                # Also register with % prefix so MIR instruction references resolve
                pct_name = p.name if p.name.startswith("%") else f"%{p.name}"
                self._locals[pct_name] = wasm_ty

        ret_type = self._mir_type_to_wasm_ret(mir_fn.return_type)
        result_part = f" (result {ret_type})" if ret_type else ""

        # Collect all locals from instructions
        self._collect_locals(mir_fn)

        # Build local declarations (excluding params)
        local_decls: list[str] = []
        param_names = {p.name for p in mir_fn.params} | {
            f"%{p.name}" for p in mir_fn.params if not p.name.startswith("%")
        }
        for local_name, wasm_ty in self._locals.items():
            if local_name not in param_names and wasm_ty:
                safe_local = _sanitize_name(local_name)
                local_decls.append(f"    (local ${safe_local} {wasm_ty})")

        # Header
        param_str = " ".join(param_parts)
        if param_str:
            param_str = " " + param_str
        lines: list[str] = [f"  (func ${safe_name}{param_str}{result_part}"]
        lines.extend(local_decls)

        # Emit body from basic blocks using structured control flow
        body = self._emit_function_body(mir_fn)
        lines.extend(body)

        # Functions with a return type need (unreachable) after the block
        # structure, since WASM requires the function body to produce a value
        # on the stack.  All real paths end with (return), so this is dead code.
        if ret_type:
            lines.append("    (unreachable)")

        lines.append("  )")
        return lines

    def _reset_function_state(self, mir_fn: MIRFunction) -> None:
        """Reset per-function state before emitting a new function."""
        self._locals = {}
        self._local_indices = {}
        self._param_count = len(mir_fn.params)
        self._body_lines = []
        self._indent_level = 2
        self._current_fn = mir_fn
        self._visited_blocks = set()
        self._phi_locals = {}

        # Build block map
        self._block_map = {}
        self._block_indices = {}
        for i, bb in enumerate(mir_fn.blocks):
            self._block_map[bb.label] = bb
            self._block_indices[bb.label] = i

    def _collect_locals(self, mir_fn: MIRFunction) -> None:
        """Scan all instructions and register every dest Value as a local.

        This flattens SSA into WASM locals — phi nodes become regular
        assignments. Each unique Value name gets exactly one local.
        """
        for bb in mir_fn.blocks:
            for inst in bb.instructions:
                dest = getattr(inst, "dest", None)
                if dest is not None and isinstance(dest, Value) and dest.name:
                    if dest.name not in self._locals:
                        wasm_ty = self._mir_type_to_wasm(dest.ty)
                        if not wasm_ty:
                            wasm_ty = _WASM_I64  # Fallback for void-typed dests
                        self._locals[dest.name] = wasm_ty

    # ------------------------------------------------------------------
    # Function body: linearized block emission
    # ------------------------------------------------------------------

    def _emit_function_body(self, mir_fn: MIRFunction) -> list[str]:
        """Emit the function body using a Stackifier approach.

        For each forward branch target, a ``(block $B_target ...)`` wrapper is
        opened before the earliest branch source and closed right before the
        target's code — so ``br $B_target`` exits the wrapper and lands at the
        target.

        For each loop header, a ``(loop $L_header ...)`` wrapper is opened at
        the header and closed after the last loop-body block — so
        ``br $L_header`` re-enters the loop.
        """
        lines: list[str] = []
        if not mir_fn.blocks:
            return lines

        block_order = {bb.label: i for i, bb in enumerate(mir_fn.blocks)}
        num_blocks = len(mir_fn.blocks)

        # Detect loop headers and their body blocks
        loop_headers = self._find_loop_headers(mir_fn)
        loop_bodies = self._compute_loop_bodies(mir_fn)

        # Store metadata for br target resolution
        self._fn_block_order = block_order
        self._fn_block_labels = [bb.label for bb in mir_fn.blocks]
        self._fn_loop_headers = loop_headers

        # ---- Collect forward-branch targets ----
        # Exclude blocks that are inside a loop body — they are reached
        # by fall-through inside the loop, not by forward br.
        loop_body_blocks: set[str] = set()
        for body_set in loop_bodies.values():
            loop_body_blocks.update(body_set)
        # Also track which headers each block belongs to
        self._fn_loop_body_blocks = loop_body_blocks

        fwd_targets: set[str] = set()
        for i, bb in enumerate(mir_fn.blocks):
            for t in self._get_terminator_targets(bb):
                t_idx = block_order.get(t, -1)
                if t_idx > i and t not in loop_body_blocks:
                    fwd_targets.add(t)

        # ---- Build open/close event lists ----
        # All forward-target (block) wrappers open at position 0 to avoid
        # overlapping nesting. Sorted by close position so the longest span
        # is outermost.
        opens_before: dict[int, list[tuple[int, str, str]]] = {}
        closes_before: dict[int, int] = {}

        for target_label in fwd_targets:
            target_idx = block_order[target_label]
            lbl = _sanitize_name(target_label)
            opens_before.setdefault(0, []).append((target_idx, "block", f"$B_{lbl}"))
            closes_before[target_idx] = closes_before.get(target_idx, 0) + 1

        for header_label in loop_headers:
            header_idx = block_order[header_label]
            body = loop_bodies.get(header_label, {header_label})
            last_body_idx = max(block_order[b] for b in body)
            lbl = _sanitize_name(header_label)
            opens_before.setdefault(header_idx, []).append((last_body_idx + 1, "loop", f"$L_{lbl}"))
            closes_before[last_body_idx + 1] = closes_before.get(last_body_idx + 1, 0) + 1

        # Sort opens: longer span (later close) outermost
        for idx in opens_before:
            opens_before[idx].sort(key=lambda x: -x[0])

        # ---- Emit ----
        for i, bb in enumerate(mir_fn.blocks):
            # Close wrappers that end before this block
            for _ in range(closes_before.get(i, 0)):
                lines.append("    )")

            # Open new wrappers
            for _close_idx, wtype, wlabel in opens_before.get(i, []):
                lines.append(f"    ({wtype} {wlabel}")

            # Emit block instructions
            lines.append(f"      ;; -- {bb.label} --")
            for inst in bb.instructions:
                inst_lines = self._emit_instruction(inst, bb.label, mir_fn)
                lines.extend(inst_lines)

        # Close any remaining wrappers (those that close after the last block)
        for _ in range(closes_before.get(num_blocks, 0)):
            lines.append("    )")

        return lines

    def _get_terminator_targets(self, bb: BasicBlock) -> list[str]:
        """Extract branch target labels from a block's terminator instruction."""
        if not bb.instructions:
            return []
        term = bb.instructions[-1]
        if isinstance(term, Jump):
            return [term.target]
        if isinstance(term, Branch):
            return [term.true_block, term.false_block]
        if isinstance(term, Switch):
            targets = [lbl for _, lbl in term.cases]
            if term.default_block:
                targets.append(term.default_block)
            return targets
        return []

    def _compute_loop_bodies(self, mir_fn: MIRFunction) -> dict[str, set[str]]:
        """For each loop header, find the set of blocks in its body."""
        block_order = {bb.label: i for i, bb in enumerate(mir_fn.blocks)}
        loop_bodies: dict[str, set[str]] = {}
        for i, bb in enumerate(mir_fn.blocks):
            for target in self._get_terminator_targets(bb):
                if target in block_order and block_order[target] <= i:
                    header = target
                    header_idx = block_order[header]
                    if header not in loop_bodies:
                        loop_bodies[header] = set()
                    for j in range(header_idx, i + 1):
                        loop_bodies[header].add(mir_fn.blocks[j].label)
        return loop_bodies

    def _resolve_br_target(self, target_label: str, from_label: str) -> str:
        """Get the correct WAT label for ``br`` to reach *target_label*.

        Forward jumps use ``$B_<target>`` (exits the block wrapper).
        Backward jumps use ``$L_<loop_header>`` (re-enters the loop).
        """
        target_idx = self._fn_block_order.get(target_label, -1)
        from_idx = self._fn_block_order.get(from_label, -1)

        if target_idx <= from_idx and target_label in self._fn_loop_headers:
            return f"$L_{_sanitize_name(target_label)}"
        else:
            return f"$B_{_sanitize_name(target_label)}"

    def _find_loop_headers(self, mir_fn: MIRFunction) -> set[str]:
        """Identify basic blocks that are targets of backward edges (loop headers)."""
        headers: set[str] = set()
        block_order = {bb.label: i for i, bb in enumerate(mir_fn.blocks)}
        for i, bb in enumerate(mir_fn.blocks):
            term = bb.instructions[-1] if bb.instructions else None
            if term is None:
                continue
            targets: list[str] = []
            if isinstance(term, Jump):
                targets.append(term.target)
            elif isinstance(term, Branch):
                targets.extend([term.true_block, term.false_block])
            elif isinstance(term, Switch):
                targets.extend(lbl for _, lbl in term.cases)
                if term.default_block:
                    targets.append(term.default_block)
            for target in targets:
                if target in block_order and block_order[target] <= i:
                    headers.add(target)
        return headers

    # ------------------------------------------------------------------
    # Instruction dispatch
    # ------------------------------------------------------------------

    def _emit_instruction(self, inst: Instruction, block_label: str, fn: MIRFunction) -> list[str]:
        """Dispatch a single MIR instruction to its handler."""
        handler = self._dispatch.get(type(inst))
        if handler is not None:
            return list(handler(inst, block_label, fn))
        _logger.warning("Unhandled MIR instruction: %s", type(inst).__name__)
        return [f"      ;; TODO: {type(inst).__name__}", "      (unreachable)"]

    # ------------------------------------------------------------------
    # Instruction emitters
    # ------------------------------------------------------------------

    def _emit_const(self, inst: Const, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a constant load."""
        dest = _sanitize_name(inst.dest.name)
        wasm_ty = self._locals.get(inst.dest.name, _WASM_I64)

        if isinstance(inst.value, bool):
            val = 1 if inst.value else 0
            return [f"      (local.set ${dest} (i32.const {val}))"]

        if isinstance(inst.value, int):
            if wasm_ty == _WASM_I32:
                return [f"      (local.set ${dest} (i32.const {inst.value}))"]
            return [f"      (local.set ${dest} (i64.const {inst.value}))"]

        if isinstance(inst.value, float):
            return [f"      (local.set ${dest} (f64.const {inst.value}))"]

        if isinstance(inst.value, str):
            offset = self._string_cache.get(inst.value, 0)
            return [f"      (local.set ${dest} (i32.const {offset}))"]

        if inst.value is None:
            if wasm_ty == _WASM_F64:
                return [f"      (local.set ${dest} (f64.const 0))"]
            if wasm_ty == _WASM_I32:
                return [f"      (local.set ${dest} (i32.const 0))"]
            return [f"      (local.set ${dest} (i64.const 0))"]

        # Fallback
        return [f"      ;; const {dest} = {inst.value!r} (unsupported type)"]

    def _emit_copy(self, inst: Copy, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a value copy (local.set from local.get)."""
        dest = _sanitize_name(inst.dest.name)
        src = _sanitize_name(inst.src.name)
        src_ty = self._locals.get(inst.src.name, _WASM_I64)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
        lines: list[str] = []
        if src_ty == dest_ty:
            lines.append(f"      (local.set ${dest} (local.get ${src}))")
        else:
            lines.extend(self._emit_type_coerce(src, src_ty, dest, dest_ty))
        return lines

    def _emit_cast(self, inst: Cast, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a type cast."""
        dest = _sanitize_name(inst.dest.name)
        src = _sanitize_name(inst.src.name)
        src_ty = self._locals.get(inst.src.name, _WASM_I64)
        target_wasm = self._mir_type_to_wasm(inst.target_type)
        if not target_wasm:
            target_wasm = _WASM_I64
        return self._emit_type_coerce(src, src_ty, dest, target_wasm)

    def _emit_type_coerce(self, src: str, src_ty: str, dest: str, dest_ty: str) -> list[str]:
        """Emit instructions to coerce a value from one WASM type to another."""
        if src_ty == dest_ty:
            return [f"      (local.set ${dest} (local.get ${src}))"]

        # i64 -> i32
        if src_ty == _WASM_I64 and dest_ty == _WASM_I32:
            return [f"      (local.set ${dest} (i32.wrap_i64 (local.get ${src})))"]

        # i32 -> i64
        if src_ty == _WASM_I32 and dest_ty == _WASM_I64:
            return [f"      (local.set ${dest} (i64.extend_i32_s (local.get ${src})))"]

        # i64 -> f64
        if src_ty == _WASM_I64 and dest_ty == _WASM_F64:
            return [f"      (local.set ${dest} (f64.convert_i64_s (local.get ${src})))"]

        # f64 -> i64
        if src_ty == _WASM_F64 and dest_ty == _WASM_I64:
            return [f"      (local.set ${dest} (i64.trunc_f64_s (local.get ${src})))"]

        # i32 -> f64
        if src_ty == _WASM_I32 and dest_ty == _WASM_F64:
            return [f"      (local.set ${dest} (f64.convert_i32_s (local.get ${src})))"]

        # f64 -> i32
        if src_ty == _WASM_F64 and dest_ty == _WASM_I32:
            return [f"      (local.set ${dest} (i32.trunc_f64_s (local.get ${src})))"]

        # Fallback: reinterpret bits
        return [
            f"      ;; coerce {src_ty} -> {dest_ty}",
            f"      (local.set ${dest} (local.get ${src}))  ;; WARNING: type mismatch",
        ]

    def _emit_binop(self, inst: BinOp, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a binary operation."""
        dest = _sanitize_name(inst.dest.name)
        lhs = _sanitize_name(inst.lhs.name)
        rhs = _sanitize_name(inst.rhs.name)
        lhs_ty = self._locals.get(inst.lhs.name, _WASM_I64)

        # Determine if this is float or integer arithmetic
        is_float = lhs_ty == _WASM_F64

        op_map_i64: dict[BinOpKind, str] = {
            BinOpKind.ADD: "i64.add",
            BinOpKind.SUB: "i64.sub",
            BinOpKind.MUL: "i64.mul",
            BinOpKind.DIV: "i64.div_s",
            BinOpKind.MOD: "i64.rem_s",
            BinOpKind.EQ: "i64.eq",
            BinOpKind.NE: "i64.ne",
            BinOpKind.LT: "i64.lt_s",
            BinOpKind.GT: "i64.gt_s",
            BinOpKind.LE: "i64.le_s",
            BinOpKind.GE: "i64.ge_s",
        }

        op_map_f64: dict[BinOpKind, str] = {
            BinOpKind.ADD: "f64.add",
            BinOpKind.SUB: "f64.sub",
            BinOpKind.MUL: "f64.mul",
            BinOpKind.DIV: "f64.div",
            BinOpKind.EQ: "f64.eq",
            BinOpKind.NE: "f64.ne",
            BinOpKind.LT: "f64.lt",
            BinOpKind.GT: "f64.gt",
            BinOpKind.LE: "f64.le",
            BinOpKind.GE: "f64.ge",
        }

        op_map_i32: dict[BinOpKind, str] = {
            BinOpKind.AND: "i32.and",
            BinOpKind.OR: "i32.or",
            BinOpKind.EQ: "i32.eq",
            BinOpKind.NE: "i32.ne",
        }

        # Boolean operations (AND/OR) use i32
        if inst.op in (BinOpKind.AND, BinOpKind.OR):
            wasm_op = op_map_i32.get(inst.op)
            if wasm_op:
                return [
                    f"      (local.set ${dest} ({wasm_op}"
                    f" (local.get ${lhs}) (local.get ${rhs})))"
                ]

        if is_float:
            wasm_op = op_map_f64.get(inst.op)
            if wasm_op:
                # Comparison ops return i32 in WASM
                dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
                if inst.op in (
                    BinOpKind.EQ,
                    BinOpKind.NE,
                    BinOpKind.LT,
                    BinOpKind.GT,
                    BinOpKind.LE,
                    BinOpKind.GE,
                ):
                    return [
                        f"      (local.set ${dest} ({wasm_op}"
                        f" (local.get ${lhs}) (local.get ${rhs})))"
                    ]
                return [
                    f"      (local.set ${dest} ({wasm_op}"
                    f" (local.get ${lhs}) (local.get ${rhs})))"
                ]
        else:
            wasm_op = op_map_i64.get(inst.op)
            if wasm_op:
                # Comparison ops return i32, but we might need i64 or i32
                dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
                if inst.op in (
                    BinOpKind.EQ,
                    BinOpKind.NE,
                    BinOpKind.LT,
                    BinOpKind.GT,
                    BinOpKind.LE,
                    BinOpKind.GE,
                ):
                    # WASM comparison returns i32
                    if dest_ty == _WASM_I32:
                        return [
                            f"      (local.set ${dest} ({wasm_op}"
                            f" (local.get ${lhs}) (local.get ${rhs})))"
                        ]
                    # Need to extend to i64 if dest is i64
                    return [
                        f"      (local.set ${dest} (i64.extend_i32_u ({wasm_op}"
                        f" (local.get ${lhs}) (local.get ${rhs}))))"
                    ]
                return [
                    f"      (local.set ${dest} ({wasm_op}"
                    f" (local.get ${lhs}) (local.get ${rhs})))"
                ]

        return [f"      ;; TODO: binop {inst.op.value} for {lhs_ty}", "      (unreachable)"]

    def _emit_unaryop(self, inst: UnaryOp, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a unary operation."""
        dest = _sanitize_name(inst.dest.name)
        operand = _sanitize_name(inst.operand.name)
        op_ty = self._locals.get(inst.operand.name, _WASM_I64)

        if inst.op == UnaryOpKind.NEG:
            if op_ty == _WASM_F64:
                return [f"      (local.set ${dest} (f64.neg (local.get ${operand})))"]
            if op_ty == _WASM_I64:
                return [
                    f"      (local.set ${dest} (i64.sub" f" (i64.const 0) (local.get ${operand})))"
                ]
            return [f"      (local.set ${dest} (i32.sub" f" (i32.const 0) (local.get ${operand})))"]

        if inst.op == UnaryOpKind.NOT:
            if op_ty == _WASM_I32:
                return [
                    f"      (local.set ${dest} (i32.xor" f" (local.get ${operand}) (i32.const 1)))"
                ]
            return [
                f"      (local.set ${dest} (i64.extend_i32_u (i32.xor"
                f" (i32.wrap_i64 (local.get ${operand})) (i32.const 1))))"
            ]

        return [f"      ;; TODO: unary {inst.op.value}", "      (unreachable)"]

    def _emit_call(self, inst: Call, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a function call."""
        dest = _sanitize_name(inst.dest.name)
        fn_name = inst.fn_name
        args = [_sanitize_name(a.name) for a in inst.args]

        # Handle builtins
        builtin_lines = self._try_emit_builtin_call(inst, dest, args)
        if builtin_lines is not None:
            return builtin_lines

        # Regular function call
        safe_fn = _sanitize_name(fn_name)
        arg_gets = " ".join(f"(local.get ${a})" for a in args)
        call_expr = f"(call ${safe_fn} {arg_gets})" if arg_gets else f"(call ${safe_fn})"

        ret_type = self._func_types.get(fn_name, ([], None))[1]
        if ret_type:
            return [f"      (local.set ${dest} {call_expr})"]
        else:
            return [f"      {call_expr}"]

    def _try_emit_builtin_call(self, inst: Call, dest: str, args: list[str]) -> list[str] | None:
        """Try to emit a builtin function call. Returns None if not a builtin."""
        fn = inst.fn_name

        if fn == "print" or fn == "println":
            return self._emit_print_call(inst, True)

        if fn == "len":
            if inst.args:
                arg = _sanitize_name(inst.args[0].name)
                arg_ty = self._locals.get(inst.args[0].name, _WASM_I32)
                if arg_ty == _WASM_I32:
                    # Pointer type: could be string or list
                    return [
                        f"      (local.set ${dest} (call $__builtin_len_str (local.get ${arg})))"
                    ]
            return [f"      (local.set ${dest} (i64.const 0))"]

        if fn == "str":
            if inst.args:
                arg = _sanitize_name(inst.args[0].name)
                arg_ty = self._locals.get(inst.args[0].name, _WASM_I64)
                if arg_ty == _WASM_I64:
                    return [
                        f"      (local.set ${dest}"
                        f" (call $__builtin_str_i64 (local.get ${arg})))"
                    ]
            return [f"      (local.set ${dest} (i32.const 0))"]

        if fn == "int":
            if inst.args:
                arg = _sanitize_name(inst.args[0].name)
                arg_ty = self._locals.get(inst.args[0].name, _WASM_F64)
                if arg_ty == _WASM_F64:
                    return [
                        f"      (local.set ${dest}"
                        f" (call $__builtin_int_f64 (local.get ${arg})))"
                    ]
            return [f"      (local.set ${dest} (i64.const 0))"]

        if fn == "float":
            if inst.args:
                arg = _sanitize_name(inst.args[0].name)
                arg_ty = self._locals.get(inst.args[0].name, _WASM_I64)
                if arg_ty == _WASM_I64:
                    return [
                        f"      (local.set ${dest}"
                        f" (call $__builtin_float_i64 (local.get ${arg})))"
                    ]
            return [f"      (local.set ${dest} (f64.const 0))"]

        if fn == "Some":
            # Wrapper: allocate tagged union with tag=1
            if inst.args:
                return self._emit_wrap_some_call(dest, inst.args[0])
            return None

        if fn == "Ok":
            if inst.args:
                return self._emit_wrap_ok_call(dest, inst.args[0])
            return None

        if fn == "Err":
            if inst.args:
                return self._emit_wrap_err_call(dest, inst.args[0])
            return None

        if fn == "signal":
            if inst.args:
                arg = _sanitize_name(inst.args[0].name)
                return [
                    "      ;; signal init",
                    f"      (local.set ${dest}"
                    f" (call $__alloc (i32.const {_SIGNAL_SIZE}) (i32.const 4)))",
                    f"      (i64.store (local.get ${dest}) (local.get ${arg}))",
                ]
            return None

        if fn == "stream":
            if inst.args:
                arg = _sanitize_name(inst.args[0].name)
                return [
                    "      ;; stream init",
                    f"      (local.set ${dest}"
                    f" (call $__alloc (i32.const {_STREAM_SIZE}) (i32.const 4)))",
                    f"      (i32.store (local.get ${dest}) (local.get ${arg}))",
                ]
            return None

        # Range iterator: __mn_range(start, end) → allocate {current, end} in linear memory
        # All values stay i64; use i32.wrap_i64 for memory addresses.
        if fn == "__mn_range" and len(args) >= 2:
            _ = f"${dest}.ptr"  # temp i32 for address (reserved)
            return [
                f"      ;; __mn_range({args[0]}, {args[1]})",
                f"      (local.set ${dest}"
                f" (i64.extend_i32_u (call $__alloc (i32.const 16) (i32.const 8))))",
                f"      (i64.store (i32.wrap_i64 (local.get ${dest}))" f" (local.get ${args[0]}))",
                f"      (i64.store offset=8 (i32.wrap_i64 (local.get ${dest}))"
                f" (local.get ${args[1]}))",
            ]

        # __iter_has_next(iter) → current < end (returns i32 bool)
        if fn == "__iter_has_next" and args:
            return [
                "      ;; __iter_has_next",
                f"      (local.set ${dest}"
                f" (i64.lt_s"
                f" (i64.load (i32.wrap_i64 (local.get ${args[0]})))"
                f" (i64.load offset=8 (i32.wrap_i64 (local.get ${args[0]})))))",
            ]

        # __iter_next(iter) → read current, then current++
        if fn == "__iter_next" and args:
            return [
                "      ;; __iter_next",
                f"      (local.set ${dest}" f" (i64.load (i32.wrap_i64 (local.get ${args[0]}))))",
                f"      (i64.store (i32.wrap_i64 (local.get ${args[0]}))"
                f" (i64.add"
                f" (i64.load (i32.wrap_i64 (local.get ${args[0]})))"
                f" (i64.const 1)))",
            ]

        return None

    def _emit_print_call(self, inst: Call, with_newline: bool) -> list[str]:
        """Emit a print/println call, dispatching by argument type and target."""
        lines: list[str] = []
        for arg_val in inst.args:
            arg = _sanitize_name(arg_val.name)
            arg_ty = self._locals.get(arg_val.name, _WASM_I64)

            if self._options.wasi:
                # WASI: all output goes through fd_write. Strings use __builtin_print_str.
                # Non-string types should already be converted via str() in MIR.
                mir_kind = arg_val.ty.kind if arg_val.ty else TypeKind.UNKNOWN
                if arg_ty == _WASM_I32 and mir_kind == TypeKind.STRING:
                    lines.append(f"      (call $__builtin_print_str (local.get ${arg}))")
                elif arg_ty == _WASM_I32:
                    # i32 as string pointer (generic fallback)
                    lines.append(f"      (call $__builtin_print_str (local.get ${arg}))")
                else:
                    # i64/f64 — convert to string first via __mn_str_from_int/float
                    # These return i32 string pointers in WASM
                    if arg_ty == _WASM_I64:
                        lines.append(
                            f"      (call $__builtin_print_str"
                            f" (call $__mn_str_from_int (local.get ${arg})))"
                        )
                    elif arg_ty == _WASM_F64:
                        lines.append(
                            f"      (call $__builtin_print_str"
                            f" (call $__mn_str_from_float (local.get ${arg})))"
                        )
            else:
                # Browser: use console_log_* host imports
                if arg_ty == _WASM_I64:
                    lines.append(f"      (call $console_log_i64 (local.get ${arg}))")
                elif arg_ty == _WASM_F64:
                    lines.append(f"      (call $console_log_f64 (local.get ${arg}))")
                elif arg_ty == _WASM_I32:
                    mir_kind = arg_val.ty.kind if arg_val.ty else TypeKind.UNKNOWN
                    if mir_kind == TypeKind.BOOL:
                        lines.append(f"      (call $console_log_bool (local.get ${arg}))")
                    elif mir_kind == TypeKind.STRING:
                        lines.append(f"      (call $__builtin_print_str (local.get ${arg}))")
                    else:
                        lines.append(f"      (call $console_log_i32 (local.get ${arg}))")

        if with_newline:
            if self._options.wasi:
                lines.append("      (call $__wasi_write_newline)")
            else:
                lines.append("      (call $console_log_newline)")
        return lines

    def _emit_extern_call(self, inst: ExternCall, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit an external function call (FFI)."""
        dest = _sanitize_name(inst.dest.name)
        safe_fn = _sanitize_name(inst.fn_name)
        args = " ".join(f"(local.get ${_sanitize_name(a.name)})" for a in inst.args)
        call_expr = f"(call ${safe_fn} {args})" if args else f"(call ${safe_fn})"
        dest_ty = self._locals.get(inst.dest.name)
        if dest_ty:
            return [f"      (local.set ${dest} {call_expr})"]
        return [f"      {call_expr}"]

    def _emit_return(self, inst: Return, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a return instruction."""
        if inst.val is not None:
            val = _sanitize_name(inst.val.name)
            return [f"      (return (local.get ${val}))"]
        return ["      (return)"]

    def _emit_jump(self, inst: Jump, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit an unconditional jump as a br to the target block."""
        # Emit phi assignments for the target block before branching
        lines = self._emit_phi_assignments(inst.target, _bl, _fn)

        # If the target is a loop body block that's the next block,
        # we fall through — no br needed.
        if self._is_loop_body_block(inst.target):
            from_idx = self._fn_block_order.get(_bl, -1)
            target_idx = self._fn_block_order.get(inst.target, -1)
            if target_idx == from_idx + 1:
                # Fall-through to next block in loop
                return lines

        br_label = self._resolve_br_target(inst.target, _bl)
        lines.append(f"      (br {br_label})")
        return lines

    def _is_loop_body_block(self, label: str) -> bool:
        """Check if a block is inside a loop body (reached by fall-through)."""
        return label in getattr(self, "_fn_loop_body_blocks", set())

    def _emit_branch(self, inst: Branch, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a conditional branch as br_if / br."""
        cond = _sanitize_name(inst.cond.name)
        cond_ty = self._locals.get(inst.cond.name, _WASM_I32)

        lines: list[str] = []

        # For loop conditions: true=body (fall-through), false=exit (br)
        # When the true target is a loop body block, use fall-through.
        true_is_fallthrough = self._is_loop_body_block(inst.true_block)
        false_is_fallthrough = self._is_loop_body_block(inst.false_block)

        if true_is_fallthrough and not false_is_fallthrough:
            # Loop pattern: if !cond, exit; else fall through to body
            false_br = self._resolve_br_target(inst.false_block, _bl)
            false_phis = self._emit_phi_assignments(inst.false_block, _bl, _fn)
            true_phis = self._emit_phi_assignments(inst.true_block, _bl, _fn)

            # Emit: if (cond) { phis } else { phis; br exit }
            if cond_ty == _WASM_I64:
                lines.append(f"      (if (i32.wrap_i64 (local.get ${cond}))")
            elif cond_ty == _WASM_I32:
                lines.append(f"      (if (local.get ${cond})")
            else:
                lines.append(f"      (if (i32.trunc_f64_s (local.get ${cond}))")
            lines.append("        (then")
            for phi_line in true_phis:
                lines.append(f"    {phi_line}")
            if not true_phis:
                lines.append("          (nop)")
            lines.append("        )")
            lines.append("        (else")
            for phi_line in false_phis:
                lines.append(f"    {phi_line}")
            lines.append(f"          (br {false_br})")
            lines.append("        )")
            lines.append("      )")
            return lines

        # Default: standard if/then/else with explicit branches
        true_br = self._resolve_br_target(inst.true_block, _bl)
        false_br = self._resolve_br_target(inst.false_block, _bl)

        if cond_ty == _WASM_I64:
            lines.append(f"      (if (i32.wrap_i64 (local.get ${cond}))")
        elif cond_ty == _WASM_I32:
            lines.append(f"      (if (local.get ${cond})")
        else:
            lines.append(f"      (if (i32.trunc_f64_s (local.get ${cond}))")

        true_phis = self._emit_phi_assignments(inst.true_block, _bl, _fn)
        lines.append("        (then")
        for phi_line in true_phis:
            lines.append(f"    {phi_line}")
        lines.append(f"          (br {true_br})")
        lines.append("        )")

        false_phis = self._emit_phi_assignments(inst.false_block, _bl, _fn)
        lines.append("        (else")
        for phi_line in false_phis:
            lines.append(f"    {phi_line}")
        lines.append(f"          (br {false_br})")
        lines.append("        )")
        lines.append("      )")

        return lines

    def _emit_switch(self, inst: Switch, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a multi-way branch (match/switch)."""
        tag = _sanitize_name(inst.tag.name)
        tag_ty = self._locals.get(inst.tag.name, _WASM_I32)
        lines: list[str] = []

        # Use nested if-else for small case counts
        for case_val, case_label in inst.cases:
            br_label = self._resolve_br_target(case_label, _bl)
            if tag_ty == _WASM_I64:
                cmp = f"(i64.eq (local.get ${tag}) (i64.const {case_val}))"
                lines.append(f"      (if (i32.wrap_i64 {cmp})")
            else:
                cmp = f"(i32.eq (local.get ${tag}) (i32.const {case_val}))"
                lines.append(f"      (if {cmp}")

            phi_lines = self._emit_phi_assignments(case_label, _bl, _fn)
            lines.append("        (then")
            for pl in phi_lines:
                lines.append(f"    {pl}")
            lines.append(f"          (br {br_label})")
            lines.append("        )")
            lines.append("      )")

        # Default case
        if inst.default_block:
            default_br = self._resolve_br_target(inst.default_block, _bl)
            default_phis = self._emit_phi_assignments(inst.default_block, _bl, _fn)
            for pl in default_phis:
                lines.append(f"      {pl}")
            lines.append(f"      (br {default_br})")

        return lines

    def _emit_phi_assignments(
        self, target_label: str, from_label: str, fn: MIRFunction
    ) -> list[str]:
        """Emit local.set assignments for phi nodes in the target block.

        Phi nodes are lowered by inserting assignments in the predecessor
        block. For each phi in the target, we find the incoming value from
        from_label and emit the assignment.
        """
        target_bb = self._block_map.get(target_label)
        if target_bb is None:
            return []
        lines: list[str] = []
        for inst in target_bb.instructions:
            if not isinstance(inst, Phi):
                break
            for lbl, val in inst.incoming:
                if lbl == from_label:
                    dest = _sanitize_name(inst.dest.name)
                    src = _sanitize_name(val.name)
                    lines.append(f"      (local.set ${dest} (local.get ${src}))")
                    break
        return lines

    def _emit_phi(self, inst: Phi, _bl: str, _fn: MIRFunction) -> list[str]:
        """Phi nodes are handled by _emit_phi_assignments. No-op here."""
        return [f"      ;; phi {inst.dest.name} (handled at branch sites)"]

    # ------------------------------------------------------------------
    # Memory / Aggregate instructions
    # ------------------------------------------------------------------

    def _emit_struct_init(self, inst: StructInit, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit struct construction: allocate and initialize fields."""
        dest = _sanitize_name(inst.dest.name)
        type_name = inst.struct_type.type_info.name if inst.struct_type.type_info.name else ""
        layout = self._struct_layouts.get(type_name)

        lines: list[str] = []
        if layout:
            # Allocate struct on heap
            lines.append(
                f"      (local.set ${dest}"
                f" (call $__alloc (i32.const {layout.total_size}) (i32.const 8)))"
            )
            # Initialize fields
            for field_name, field_val in inst.fields:
                offset = layout.field_offsets.get(field_name, 0)
                val = _sanitize_name(field_val.name)
                val_ty = self._locals.get(field_val.name, _WASM_I32)
                store_op = self._store_op_for_type(val_ty)
                lines.append(
                    f"      ({store_op}"
                    f" (i32.add (local.get ${dest}) (i32.const {offset}))"
                    f" (local.get ${val}))"
                )
        else:
            # Unknown struct: allocate generic block
            size = max(len(inst.fields) * 8, _PTR_SIZE)
            lines.append(
                f"      (local.set ${dest}" f" (call $__alloc (i32.const {size}) (i32.const 8)))"
            )
            for i, (field_name, field_val) in enumerate(inst.fields):
                val = _sanitize_name(field_val.name)
                val_ty = self._locals.get(field_val.name, _WASM_I64)
                store_op = self._store_op_for_type(val_ty)
                lines.append(
                    f"      ({store_op}"
                    f" (i32.add (local.get ${dest}) (i32.const {i * 8}))"
                    f" (local.get ${val}))"
                )
        return lines

    def _emit_field_get(self, inst: FieldGet, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit struct field read."""
        dest = _sanitize_name(inst.dest.name)
        obj = _sanitize_name(inst.obj.name)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
        load_op = self._load_op_for_type(dest_ty)

        # Find field offset from struct layout
        offset = self._resolve_field_offset(inst.obj, inst.field_name)

        return [
            f"      (local.set ${dest} ({load_op}"
            f" (i32.add (local.get ${obj}) (i32.const {offset}))))"
        ]

    def _emit_field_set(self, inst: FieldSet, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit struct field write."""
        obj = _sanitize_name(inst.obj.name)
        val = _sanitize_name(inst.val.name)
        val_ty = self._locals.get(inst.val.name, _WASM_I64)
        store_op = self._store_op_for_type(val_ty)

        offset = self._resolve_field_offset(inst.obj, inst.field_name)

        return [
            f"      ({store_op}"
            f" (i32.add (local.get ${obj}) (i32.const {offset}))"
            f" (local.get ${val}))"
        ]

    def _resolve_field_offset(self, obj: Value, field_name: str) -> int:
        """Resolve the byte offset of a struct field."""
        type_name = obj.ty.type_info.name if obj.ty and obj.ty.type_info.name else ""
        layout = self._struct_layouts.get(type_name)
        if layout and field_name in layout.field_offsets:
            return layout.field_offsets[field_name]
        # Fallback: estimate by field position
        _logger.warning(
            "Unknown struct layout for %s.%s, using generic offset", type_name, field_name
        )
        return 0

    def _emit_list_init(self, inst: ListInit, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit list construction: allocate header + data, store elements."""
        dest = _sanitize_name(inst.dest.name)
        elem_ty = self._mir_type_to_wasm(inst.elem_type)
        elem_size = self._wasm_type_size(elem_ty)
        count = len(inst.elements)
        cap = max(count, 4)  # Minimum capacity of 4

        lines: list[str] = []
        # Allocate header: [len: i32, cap: i32, elem_size: i32, data_ptr: i32]
        lines.append(
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {_LIST_HEADER_SIZE}) (i32.const 4)))"
        )
        # Write header fields
        lines.append(f"      (i32.store (local.get ${dest}) (i32.const {count}))")
        lines.append(
            f"      (i32.store (i32.add (local.get ${dest}) (i32.const 4))" f" (i32.const {cap}))"
        )
        lines.append(
            f"      (i32.store (i32.add (local.get ${dest}) (i32.const 8))"
            f" (i32.const {elem_size}))"
        )

        if count > 0:
            # Allocate data array
            data_size = cap * elem_size
            # We need a temp local for data_ptr
            data_local = f"_list_data_{id(inst) & 0xFFFF}"
            if data_local not in self._locals:
                self._locals[data_local] = _WASM_I32
            safe_data = _sanitize_name(data_local)
            lines.append(
                f"      (local.set ${safe_data}"
                f" (call $__alloc (i32.const {data_size}) (i32.const {elem_size})))"
            )
            # Store data pointer in header
            lines.append(
                f"      (i32.store (i32.add (local.get ${dest}) (i32.const 12))"
                f" (local.get ${safe_data}))"
            )
            # Store each element
            store_op = self._store_op_for_type(elem_ty)
            for i, elem_val in enumerate(inst.elements):
                elem_name = _sanitize_name(elem_val.name)
                offset = i * elem_size
                lines.append(
                    f"      ({store_op}"
                    f" (i32.add (local.get ${safe_data}) (i32.const {offset}))"
                    f" (local.get ${elem_name}))"
                )
        else:
            # Null data pointer for empty list
            lines.append(
                f"      (i32.store (i32.add (local.get ${dest}) (i32.const 12))" f" (i32.const 0))"
            )

        return lines

    def _emit_list_push(self, inst: ListPush, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit list push: append an element, potentially reallocating."""
        dest = _sanitize_name(inst.dest.name)
        list_val = _sanitize_name(inst.list_val.name)
        elem = _sanitize_name(inst.element.name)
        elem_ty = self._locals.get(inst.element.name, _WASM_I64)
        store_op = self._store_op_for_type(elem_ty)
        elem_size = self._wasm_type_size(elem_ty)

        # Simplified push: assume capacity is sufficient (no realloc)
        # A production implementation would check cap and grow if needed.
        return [
            "      ;; list push (simplified, no realloc)",
            f"      (local.set ${dest} (local.get ${list_val}))",
            "      ;; Store element at data[len]",
            f"      ({store_op}",
            "        (i32.add",
            f"          (i32.load (i32.add (local.get ${list_val}) (i32.const 12)))",
            f"          (i32.mul (i32.load (local.get ${list_val}))" f" (i32.const {elem_size}))",
            "        )",
            f"        (local.get ${elem})",
            "      )",
            "      ;; Increment length",
            f"      (i32.store (local.get ${list_val})",
            f"        (i32.add (i32.load (local.get ${list_val})) (i32.const 1))",
            "      )",
        ]

    def _emit_index_get(self, inst: IndexGet, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit list[i] read."""
        dest = _sanitize_name(inst.dest.name)
        obj = _sanitize_name(inst.obj.name)
        index = _sanitize_name(inst.index.name)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
        load_op = self._load_op_for_type(dest_ty)
        elem_size = self._wasm_type_size(dest_ty)

        return [
            f"      (local.set ${dest} ({load_op}",
            "        (i32.add",
            f"          (i32.load (i32.add (local.get ${obj}) (i32.const 12)))",
            f"          (i32.mul (i32.wrap_i64 (local.get ${index}))" f" (i32.const {elem_size}))",
            "        )",
            "      ))",
        ]

    def _emit_index_set(self, inst: IndexSet, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit list[i] write."""
        obj = _sanitize_name(inst.obj.name)
        index = _sanitize_name(inst.index.name)
        val = _sanitize_name(inst.val.name)
        val_ty = self._locals.get(inst.val.name, _WASM_I64)
        store_op = self._store_op_for_type(val_ty)
        elem_size = self._wasm_type_size(val_ty)

        return [
            f"      ({store_op}",
            "        (i32.add",
            f"          (i32.load (i32.add (local.get ${obj}) (i32.const 12)))",
            f"          (i32.mul (i32.wrap_i64 (local.get ${index}))" f" (i32.const {elem_size}))",
            "        )",
            f"        (local.get ${val})",
            "      )",
        ]

    def _emit_map_init(self, inst: MapInit, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit map construction.

        Maps use a simple open-addressing hash table:
        Header: [i32 count, i32 capacity, i32 key_size, i32 val_size, i32 data_ptr]
        """
        dest = _sanitize_name(inst.dest.name)
        count = len(inst.pairs)
        cap = max(count * 2, 8)  # Load factor ~0.5
        header_size = 20  # 5 * i32

        lines: list[str] = []
        lines.append(
            f"      (local.set ${dest}" f" (call $__alloc (i32.const {header_size}) (i32.const 4)))"
        )
        lines.append(f"      (i32.store (local.get ${dest}) (i32.const {count}))")
        lines.append(
            f"      (i32.store (i32.add (local.get ${dest}) (i32.const 4))" f" (i32.const {cap}))"
        )
        # Simplified: store pairs linearly (key, value) in data section
        if count > 0:
            entry_size = 16  # key(8) + value(8)
            data_size = cap * entry_size
            data_local = f"_map_data_{id(inst) & 0xFFFF}"
            if data_local not in self._locals:
                self._locals[data_local] = _WASM_I32
            safe_data = _sanitize_name(data_local)
            lines.append(
                f"      (local.set ${safe_data}"
                f" (call $__alloc (i32.const {data_size}) (i32.const 8)))"
            )
            lines.append(
                f"      (i32.store (i32.add (local.get ${dest}) (i32.const 16))"
                f" (local.get ${safe_data}))"
            )
            for i, (key_val, val_val) in enumerate(inst.pairs):
                key_name = _sanitize_name(key_val.name)
                val_name = _sanitize_name(val_val.name)
                key_ty = self._locals.get(key_val.name, _WASM_I64)
                val_ty = self._locals.get(val_val.name, _WASM_I64)
                key_store = self._store_op_for_type(key_ty)
                val_store = self._store_op_for_type(val_ty)
                base = i * entry_size
                lines.append(
                    f"      ({key_store}"
                    f" (i32.add (local.get ${safe_data}) (i32.const {base}))"
                    f" (local.get ${key_name}))"
                )
                lines.append(
                    f"      ({val_store}"
                    f" (i32.add (local.get ${safe_data}) (i32.const {base + 8}))"
                    f" (local.get ${val_name}))"
                )

        return lines

    # ------------------------------------------------------------------
    # Enum / Tagged Union instructions
    # ------------------------------------------------------------------

    def _emit_enum_init(self, inst: EnumInit, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit enum variant construction."""
        dest = _sanitize_name(inst.dest.name)
        enum_name = inst.enum_type.type_info.name if inst.enum_type.type_info.name else ""
        variants = self._enum_variants.get(enum_name, {})
        tag = variants.get(inst.variant, 0)

        lines: list[str] = []
        # Allocate tagged union: [i32 tag][payload bytes...]
        payload_size = max(len(inst.payload) * 8, 8)
        total = _I32_SIZE + payload_size
        lines.append(
            f"      (local.set ${dest}" f" (call $__alloc (i32.const {total}) (i32.const 4)))"
        )
        # Write tag
        lines.append(f"      (i32.store (local.get ${dest}) (i32.const {tag}))")
        # Write payload
        for i, payload_val in enumerate(inst.payload):
            pname = _sanitize_name(payload_val.name)
            pty = self._locals.get(payload_val.name, _WASM_I64)
            store_op = self._store_op_for_type(pty)
            offset = _I32_SIZE + i * 8
            lines.append(
                f"      ({store_op}"
                f" (i32.add (local.get ${dest}) (i32.const {offset}))"
                f" (local.get ${pname}))"
            )
        return lines

    def _emit_enum_tag(self, inst: EnumTag, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit enum tag extraction."""
        dest = _sanitize_name(inst.dest.name)
        enum_val = _sanitize_name(inst.enum_val.name)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I32)
        if dest_ty == _WASM_I64:
            return [
                f"      (local.set ${dest}"
                f" (i64.extend_i32_u (i32.load (local.get ${enum_val}))))"
            ]
        return [f"      (local.set ${dest} (i32.load (local.get ${enum_val})))"]

    def _emit_enum_payload(self, inst: EnumPayload, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit enum payload extraction."""
        dest = _sanitize_name(inst.dest.name)
        enum_val = _sanitize_name(inst.enum_val.name)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
        load_op = self._load_op_for_type(dest_ty)
        offset = _I32_SIZE + inst.payload_idx * 8
        return [
            f"      (local.set ${dest} ({load_op}"
            f" (i32.add (local.get ${enum_val}) (i32.const {offset}))))"
        ]

    # ------------------------------------------------------------------
    # Option / Result instructions
    # ------------------------------------------------------------------

    def _emit_wrap_some(self, inst: WrapSome, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit Some(val): allocate tagged union with tag=1."""
        return self._emit_wrap_some_call(_sanitize_name(inst.dest.name), inst.val)

    def _emit_wrap_some_call(self, dest: str, val: Value) -> list[str]:
        """Helper for Some() wrapping."""
        val_name = _sanitize_name(val.name)
        val_ty = self._locals.get(val.name, _WASM_I64)
        store_op = self._store_op_for_type(val_ty)
        return [
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {_TAGGED_UNION_SIZE}) (i32.const 4)))",
            f"      (i32.store (local.get ${dest}) (i32.const 1))  ;; tag = Some",
            f"      ({store_op}"
            f" (i32.add (local.get ${dest}) (i32.const {_I32_SIZE}))"
            f" (local.get ${val_name}))",
        ]

    def _emit_wrap_none(self, inst: WrapNone, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit None: allocate tagged union with tag=0."""
        dest = _sanitize_name(inst.dest.name)
        return [
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {_TAGGED_UNION_SIZE}) (i32.const 4)))",
            f"      (i32.store (local.get ${dest}) (i32.const 0))  ;; tag = None",
        ]

    def _emit_wrap_ok(self, inst: WrapOk, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit Ok(val): tag=1."""
        return self._emit_wrap_ok_call(_sanitize_name(inst.dest.name), inst.val)

    def _emit_wrap_ok_call(self, dest: str, val: Value) -> list[str]:
        """Helper for Ok() wrapping."""
        val_name = _sanitize_name(val.name)
        val_ty = self._locals.get(val.name, _WASM_I64)
        store_op = self._store_op_for_type(val_ty)
        return [
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {_TAGGED_UNION_SIZE}) (i32.const 4)))",
            f"      (i32.store (local.get ${dest}) (i32.const 1))  ;; tag = Ok",
            f"      ({store_op}"
            f" (i32.add (local.get ${dest}) (i32.const {_I32_SIZE}))"
            f" (local.get ${val_name}))",
        ]

    def _emit_wrap_err(self, inst: WrapErr, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit Err(val): tag=0."""
        return self._emit_wrap_err_call(_sanitize_name(inst.dest.name), inst.val)

    def _emit_wrap_err_call(self, dest: str, val: Value) -> list[str]:
        """Helper for Err() wrapping."""
        val_name = _sanitize_name(val.name)
        val_ty = self._locals.get(val.name, _WASM_I64)
        store_op = self._store_op_for_type(val_ty)
        return [
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {_TAGGED_UNION_SIZE}) (i32.const 4)))",
            f"      (i32.store (local.get ${dest}) (i32.const 0))  ;; tag = Err",
            f"      ({store_op}"
            f" (i32.add (local.get ${dest}) (i32.const {_I32_SIZE}))"
            f" (local.get ${val_name}))",
        ]

    def _emit_unwrap(self, inst: Unwrap, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit unwrap: extract payload from Option/Result."""
        dest = _sanitize_name(inst.dest.name)
        val = _sanitize_name(inst.val.name)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
        load_op = self._load_op_for_type(dest_ty)
        return [
            f"      (local.set ${dest} ({load_op}"
            f" (i32.add (local.get ${val}) (i32.const {_I32_SIZE}))))"
        ]

    # ------------------------------------------------------------------
    # String interpolation
    # ------------------------------------------------------------------

    def _emit_interp_concat(self, inst: InterpConcat, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit string interpolation concatenation.

        Simplified: concatenate string parts by copying bytes into a new
        heap-allocated buffer. Non-string parts should already be converted
        to strings by the lowering pass.
        """
        dest = _sanitize_name(inst.dest.name)
        if not inst.parts:
            # Empty string
            return [
                f"      (local.set ${dest}" f" (call $__alloc (i32.const 4) (i32.const 4)))",
                f"      (i32.store (local.get ${dest}) (i32.const 0))",
            ]

        # For a single part, just copy the pointer
        if len(inst.parts) == 1:
            part = _sanitize_name(inst.parts[0].name)
            return [f"      (local.set ${dest} (local.get ${part}))"]

        # Multi-part: simplified stub (full impl would compute total length,
        # allocate, and memcpy each part)
        lines: list[str] = [
            f"      ;; interp_concat with {len(inst.parts)} parts (simplified)",
        ]
        # Use first part as result for now
        first = _sanitize_name(inst.parts[0].name)
        lines.append(f"      (local.set ${dest} (local.get ${first}))")
        return lines

    # ------------------------------------------------------------------
    # Agent instructions
    # ------------------------------------------------------------------

    def _emit_agent_spawn(self, inst: AgentSpawn, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit agent spawn: allocate agent struct."""
        dest = _sanitize_name(inst.dest.name)
        return [
            "      ;; agent_spawn",
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {_AGENT_SIZE}) (i32.const 4)))",
            "      ;; Initialize agent status = RUNNING (1)",
            f"      (i32.store (i32.add (local.get ${dest}) (i32.const 12)) (i32.const 1))",
        ]

    def _emit_agent_send(self, inst: AgentSend, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit agent send: write value to agent's inbox."""
        agent = _sanitize_name(inst.agent.name)
        val = _sanitize_name(inst.val.name)
        val_ty = self._locals.get(inst.val.name, _WASM_I64)
        store_op = self._store_op_for_type(val_ty)
        return [
            f"      ;; agent_send {inst.channel}",
            f"      ({store_op}"
            f" (i32.load (i32.add (local.get ${agent}) (i32.const 4)))"
            f" (local.get ${val}))",
        ]

    def _emit_agent_sync(self, inst: AgentSync, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit agent sync: read from agent's outbox."""
        dest = _sanitize_name(inst.dest.name)
        agent = _sanitize_name(inst.agent.name)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
        load_op = self._load_op_for_type(dest_ty)
        return [
            f"      ;; agent_sync {inst.channel}",
            f"      (local.set ${dest} ({load_op}"
            f" (i32.load (i32.add (local.get ${agent}) (i32.const 8)))))",
        ]

    # ------------------------------------------------------------------
    # Signal instructions
    # ------------------------------------------------------------------

    def _emit_signal_init(self, inst: SignalInit, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit signal initialization."""
        dest = _sanitize_name(inst.dest.name)
        init_val = _sanitize_name(inst.initial_val.name)
        val_ty = self._locals.get(inst.initial_val.name, _WASM_I64)
        store_op = self._store_op_for_type(val_ty)
        return [
            "      ;; signal_init",
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {_SIGNAL_SIZE}) (i32.const 8)))",
            f"      ({store_op} (local.get ${dest}) (local.get ${init_val}))",
        ]

    def _emit_signal_get(self, inst: SignalGet, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit signal value read."""
        dest = _sanitize_name(inst.dest.name)
        signal = _sanitize_name(inst.signal.name)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
        load_op = self._load_op_for_type(dest_ty)
        return [f"      (local.set ${dest} ({load_op} (local.get ${signal})))"]

    def _emit_signal_set(self, inst: SignalSet, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit signal value write."""
        signal = _sanitize_name(inst.signal.name)
        val = _sanitize_name(inst.val.name)
        val_ty = self._locals.get(inst.val.name, _WASM_I64)
        store_op = self._store_op_for_type(val_ty)
        return [
            "      ;; signal_set",
            f"      ({store_op} (local.get ${signal}) (local.get ${val}))",
        ]

    def _emit_signal_computed(self, inst: SignalComputed, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit computed signal creation.

        Signal layout: [i64 value (offset 0)][i32 compute_fn_idx (offset 8)][i32 dirty (offset 12)]
        The compute function is called once to get the initial value.
        """
        dest = _sanitize_name(inst.dest.name)
        fn_idx = self._func_indices.get(inst.compute_fn, 0)

        lines: list[str] = [
            "      ;; signal_computed",
            # Allocate signal struct (16 bytes)
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {_SIGNAL_SIZE}) (i32.const 8)))",
            # Store compute function index at offset 8
            f"      (i32.store (i32.add (local.get ${dest}) (i32.const 8))"
            f" (i32.const {fn_idx}))",
            # Mark as not dirty (offset 12)
            f"      (i32.store (i32.add (local.get ${dest}) (i32.const 12))" f" (i32.const 0))",
            # Call compute function to get initial value and store at offset 0
            f"      (i64.store (local.get ${dest})" f" (call ${_sanitize_name(inst.compute_fn)}))",
        ]
        return lines

    def _emit_signal_subscribe(
        self, inst: SignalSubscribe, _bl: str, _fn: MIRFunction
    ) -> list[str]:
        """Emit signal subscription.

        Allocates an 8-byte subscription entry [signal_ptr, subscriber_ptr]
        and appends it to the signal's subscriber list. The signal stores
        subscriber_count at offset 8 and subscribers_ptr at offset 12.
        """
        signal = _sanitize_name(inst.signal.name)
        subscriber = _sanitize_name(inst.subscriber.name)

        # Temp locals for subscription bookkeeping
        count_local = f"_sub_cnt_{id(inst) & 0xFFFF}"
        subs_ptr_local = f"_sub_ptr_{id(inst) & 0xFFFF}"
        for loc_name in (count_local, subs_ptr_local):
            if loc_name not in self._locals:
                self._locals[loc_name] = _WASM_I32
        safe_count = _sanitize_name(count_local)
        safe_subs = _sanitize_name(subs_ptr_local)

        return [
            "      ;; signal_subscribe",
            # Read current subscriber count from signal offset 8
            f"      (local.set ${safe_count}"
            f" (i32.load (i32.add (local.get ${signal}) (i32.const 8))))",
            # Read subscribers_ptr from signal offset 12
            f"      (local.set ${safe_subs}"
            f" (i32.load (i32.add (local.get ${signal}) (i32.const 12))))",
            # If subscribers_ptr is null, allocate initial block (capacity for 4 entries = 32 bytes)
            f"      (if (i32.eqz (local.get ${safe_subs}))",
            "        (then",
            f"          (local.set ${safe_subs}" f" (call $__alloc (i32.const 32) (i32.const 4)))",
            f"          (i32.store (i32.add (local.get ${signal}) (i32.const 12))"
            f" (local.get ${safe_subs}))",
            "        )",
            "      )",
            # Store subscriber pointer at subscribers_ptr[count * 4]
            f"      (i32.store"
            f" (i32.add (local.get ${safe_subs})"
            f" (i32.mul (local.get ${safe_count}) (i32.const 4)))"
            f" (local.get ${subscriber}))",
            # Increment subscriber count
            f"      (i32.store (i32.add (local.get ${signal}) (i32.const 8))"
            f" (i32.add (local.get ${safe_count}) (i32.const 1)))",
        ]

    # ------------------------------------------------------------------
    # Stream instructions
    # ------------------------------------------------------------------

    def _emit_stream_init(self, inst: StreamInit, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit stream initialization from a source list."""
        dest = _sanitize_name(inst.dest.name)
        source = _sanitize_name(inst.source.name)
        return [
            "      ;; stream_init",
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {_STREAM_SIZE}) (i32.const 4)))",
            f"      (i32.store (local.get ${dest}) (local.get ${source}))",
            f"      (i32.store (i32.add (local.get ${dest}) (i32.const 4)) (i32.const 0))",
        ]

    def _emit_stream_op(self, inst: StreamOp, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a stream operation (map, filter, fold, etc.).

        Uses eager evaluation: each operator immediately produces a new list
        by iterating the source stream's underlying list. This is simpler than
        lazy chains and still correct for all operators.

        Stream layout: [i32 source_ptr (list)][i32 position][i32 callback_idx]
        List layout: [i32 len][i32 cap][i32 elem_size][i32 data_ptr]
        """
        from mapanare.mir import StreamOpKind

        dest = _sanitize_name(inst.dest.name)
        source = _sanitize_name(inst.source.name)
        op = inst.op_kind

        if op == StreamOpKind.MAP:
            return self._emit_stream_map(inst, dest, source)
        elif op == StreamOpKind.FILTER:
            return self._emit_stream_filter(inst, dest, source)
        elif op == StreamOpKind.TAKE:
            return self._emit_stream_take(inst, dest, source)
        elif op == StreamOpKind.SKIP:
            return self._emit_stream_skip(inst, dest, source)
        elif op == StreamOpKind.COLLECT:
            return self._emit_stream_collect(inst, dest, source)
        elif op == StreamOpKind.FOLD:
            return self._emit_stream_fold(inst, dest, source)
        else:
            return [
                f"      ;; stream_{op.name.lower()} (unsupported)",
                f"      (local.set ${dest} (local.get ${source}))",
            ]

    def _stream_ensure_locals(self, tag: str) -> tuple[str, str, str, str, str, str]:
        """Create and register temporary locals for stream loop operations.

        Returns sanitized names for: src_list, src_len, src_data, idx, dst_list, dst_data.
        """
        names = {
            "src_list": f"_strm_sl_{tag}",
            "src_len": f"_strm_ln_{tag}",
            "src_data": f"_strm_sd_{tag}",
            "idx": f"_strm_ix_{tag}",
            "dst_list": f"_strm_dl_{tag}",
            "dst_data": f"_strm_dd_{tag}",
        }
        for n in names.values():
            if n not in self._locals:
                self._locals[n] = _WASM_I32
        return tuple(_sanitize_name(n) for n in names.values())  # type: ignore[return-value]

    def _emit_stream_map(self, inst: StreamOp, dest: str, source: str) -> list[str]:
        """Emit stream map: iterate source list, apply fn, build new list.

        Uses call_indirect to invoke the map function for each element.
        """
        tag = f"{id(inst) & 0xFFFF}"
        src_list, src_len, src_data, idx, dst_list, dst_data = self._stream_ensure_locals(tag)
        # Temp for mapped element value
        tmp_val = f"_strm_mv_{tag}"
        if tmp_val not in self._locals:
            self._locals[tmp_val] = _WASM_I64
        safe_tmp = _sanitize_name(tmp_val)

        fn_name = _sanitize_name(inst.fn_name) if inst.fn_name else ""
        blk = f"$strm_map_brk_{tag}"
        lp = f"$strm_map_lp_{tag}"

        lines: list[str] = [
            "      ;; stream_map (eager)",
            # Get source list from stream (offset 0)
            f"      (local.set ${src_list} (i32.load (local.get ${source})))",
            # Read source length
            f"      (local.set ${src_len} (i32.load (local.get ${src_list})))",
            # Read source data pointer
            f"      (local.set ${src_data}"
            f" (i32.load (i32.add (local.get ${src_list}) (i32.const 12))))",
            # Allocate new list header
            f"      (local.set ${dst_list}"
            f" (call $__alloc (i32.const {_LIST_HEADER_SIZE}) (i32.const 4)))",
            # Set new list len = source len, cap = source len, elem_size = 8
            f"      (i32.store (local.get ${dst_list}) (local.get ${src_len}))",
            f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 4))"
            f" (local.get ${src_len}))",
            f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 8))" f" (i32.const 8))",
            # Allocate data array (len * 8)
            f"      (local.set ${dst_data}"
            f" (call $__alloc (i32.mul (local.get ${src_len}) (i32.const 8)) (i32.const 8)))",
            f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 12))"
            f" (local.get ${dst_data}))",
            # Loop over source elements
            f"      (local.set ${idx} (i32.const 0))",
            f"      (block {blk}",
            f"        (loop {lp}",
            f"          (br_if {blk} (i32.ge_u (local.get ${idx}) (local.get ${src_len})))",
        ]
        if fn_name:
            # Call the map function with the source element
            lines.extend(
                [
                    f"          (local.set ${safe_tmp}"
                    f" (call ${fn_name}"
                    f" (i64.load (i32.add (local.get ${src_data})"
                    f" (i32.mul (local.get ${idx}) (i32.const 8))))))",
                ]
            )
        else:
            # No function: identity map
            lines.extend(
                [
                    f"          (local.set ${safe_tmp}"
                    f" (i64.load (i32.add (local.get ${src_data})"
                    f" (i32.mul (local.get ${idx}) (i32.const 8))))))",
                ]
            )
        lines.extend(
            [
                # Store result in destination
                f"          (i64.store (i32.add (local.get ${dst_data})"
                f" (i32.mul (local.get ${idx}) (i32.const 8)))"
                f" (local.get ${safe_tmp}))",
                # Increment index
                f"          (local.set ${idx}" f" (i32.add (local.get ${idx}) (i32.const 1)))",
                f"          (br {lp})",
                "        )",
                "      )",
                # Allocate new stream wrapping the new list
                f"      (local.set ${dest}"
                f" (call $__alloc (i32.const {_STREAM_SIZE}) (i32.const 4)))",
                f"      (i32.store (local.get ${dest}) (local.get ${dst_list}))",
                f"      (i32.store (i32.add (local.get ${dest}) (i32.const 4)) (i32.const 0))",
            ]
        )
        return lines

    def _emit_stream_filter(self, inst: StreamOp, dest: str, source: str) -> list[str]:
        """Emit stream filter: iterate source list, keep elements where fn returns true."""
        tag = f"{id(inst) & 0xFFFF}"
        src_list, src_len, src_data, idx, dst_list, dst_data = self._stream_ensure_locals(tag)
        dst_len_local = f"_strm_fl_{tag}"
        tmp_val = f"_strm_fv_{tag}"
        cond_local = f"_strm_fc_{tag}"
        for loc_name in (dst_len_local, tmp_val, cond_local):
            if loc_name not in self._locals:
                self._locals[loc_name] = _WASM_I32 if loc_name == cond_local else _WASM_I64
        if dst_len_local not in self._locals:
            self._locals[dst_len_local] = _WASM_I32
        safe_dst_len = _sanitize_name(dst_len_local)
        safe_tmp = _sanitize_name(tmp_val)
        safe_cond = _sanitize_name(cond_local)

        fn_name = _sanitize_name(inst.fn_name) if inst.fn_name else ""
        blk = f"$strm_flt_brk_{tag}"
        lp = f"$strm_flt_lp_{tag}"

        lines: list[str] = [
            "      ;; stream_filter (eager)",
            f"      (local.set ${src_list} (i32.load (local.get ${source})))",
            f"      (local.set ${src_len} (i32.load (local.get ${src_list})))",
            f"      (local.set ${src_data}"
            f" (i32.load (i32.add (local.get ${src_list}) (i32.const 12))))",
            # Allocate output list (worst case: same size as input)
            f"      (local.set ${dst_list}"
            f" (call $__alloc (i32.const {_LIST_HEADER_SIZE}) (i32.const 4)))",
            f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 4))"
            f" (local.get ${src_len}))",
            f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 8))" f" (i32.const 8))",
            f"      (local.set ${dst_data}"
            f" (call $__alloc (i32.mul (local.get ${src_len}) (i32.const 8)) (i32.const 8)))",
            f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 12))"
            f" (local.get ${dst_data}))",
            # Initialize output length counter
            f"      (local.set ${safe_dst_len} (i32.const 0))",
            f"      (local.set ${idx} (i32.const 0))",
            f"      (block {blk}",
            f"        (loop {lp}",
            f"          (br_if {blk} (i32.ge_u (local.get ${idx}) (local.get ${src_len})))",
            # Load element
            f"          (local.set ${safe_tmp}"
            f" (i64.load (i32.add (local.get ${src_data})"
            f" (i32.mul (local.get ${idx}) (i32.const 8)))))",
        ]
        if fn_name:
            lines.append(
                f"          (local.set ${safe_cond}"
                f" (i32.wrap_i64 (call ${fn_name} (local.get ${safe_tmp}))))"
            )
        else:
            # No filter function: keep all (identity)
            lines.append(f"          (local.set ${safe_cond} (i32.const 1))")
        lines.extend(
            [
                f"          (if (local.get ${safe_cond})",
                "            (then",
                f"              (i64.store (i32.add (local.get ${dst_data})"
                f" (i32.mul (local.get ${safe_dst_len}) (i32.const 8)))"
                f" (local.get ${safe_tmp}))",
                f"              (local.set ${safe_dst_len}"
                f" (i32.add (local.get ${safe_dst_len}) (i32.const 1)))",
                "            )",
                "          )",
                f"          (local.set ${idx}" f" (i32.add (local.get ${idx}) (i32.const 1)))",
                f"          (br {lp})",
                "        )",
                "      )",
                # Set actual length
                f"      (i32.store (local.get ${dst_list}) (local.get ${safe_dst_len}))",
                # Wrap in stream
                f"      (local.set ${dest}"
                f" (call $__alloc (i32.const {_STREAM_SIZE}) (i32.const 4)))",
                f"      (i32.store (local.get ${dest}) (local.get ${dst_list}))",
                f"      (i32.store (i32.add (local.get ${dest}) (i32.const 4)) (i32.const 0))",
            ]
        )
        return lines

    def _emit_stream_take(self, inst: StreamOp, dest: str, source: str) -> list[str]:
        """Emit stream take: produce a new list with at most N elements from source."""
        tag = f"{id(inst) & 0xFFFF}"
        src_list, src_len, src_data, idx, dst_list, dst_data = self._stream_ensure_locals(tag)
        take_n_local = f"_strm_tn_{tag}"
        if take_n_local not in self._locals:
            self._locals[take_n_local] = _WASM_I32
        safe_take_n = _sanitize_name(take_n_local)

        # The count arg is the first element of inst.args
        count_name = _sanitize_name(inst.args[0].name) if inst.args else "0"
        blk = f"$strm_take_brk_{tag}"
        lp = f"$strm_take_lp_{tag}"

        lines: list[str] = [
            "      ;; stream_take (eager)",
            f"      (local.set ${src_list} (i32.load (local.get ${source})))",
            f"      (local.set ${src_len} (i32.load (local.get ${src_list})))",
            f"      (local.set ${src_data}"
            f" (i32.load (i32.add (local.get ${src_list}) (i32.const 12))))",
        ]
        if inst.args:
            lines.append(
                f"      (local.set ${safe_take_n}" f" (i32.wrap_i64 (local.get ${count_name})))"
            )
        else:
            lines.append(f"      (local.set ${safe_take_n} (i32.const 0))")
        lines.extend(
            [
                # Clamp take_n to source length
                f"      (if (i32.gt_u (local.get ${safe_take_n}) (local.get ${src_len}))",
                f"        (then (local.set ${safe_take_n} (local.get ${src_len})))",
                "      )",
                # Allocate output list
                f"      (local.set ${dst_list}"
                f" (call $__alloc (i32.const {_LIST_HEADER_SIZE}) (i32.const 4)))",
                f"      (i32.store (local.get ${dst_list}) (local.get ${safe_take_n}))",
                f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 4))"
                f" (local.get ${safe_take_n}))",
                f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 8))"
                f" (i32.const 8))",
                f"      (local.set ${dst_data}"
                " (call $__alloc"
                f" (i32.mul (local.get ${safe_take_n}) (i32.const 8))"
                " (i32.const 8)))",
                f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 12))"
                f" (local.get ${dst_data}))",
                # Copy elements
                f"      (local.set ${idx} (i32.const 0))",
                f"      (block {blk}",
                f"        (loop {lp}",
                f"          (br_if {blk} (i32.ge_u (local.get ${idx}) (local.get ${safe_take_n})))",
                f"          (i64.store (i32.add (local.get ${dst_data})"
                f" (i32.mul (local.get ${idx}) (i32.const 8)))"
                f" (i64.load (i32.add (local.get ${src_data})"
                f" (i32.mul (local.get ${idx}) (i32.const 8)))))",
                f"          (local.set ${idx}" f" (i32.add (local.get ${idx}) (i32.const 1)))",
                f"          (br {lp})",
                "        )",
                "      )",
                # Wrap in stream
                f"      (local.set ${dest}"
                f" (call $__alloc (i32.const {_STREAM_SIZE}) (i32.const 4)))",
                f"      (i32.store (local.get ${dest}) (local.get ${dst_list}))",
                f"      (i32.store (i32.add (local.get ${dest}) (i32.const 4)) (i32.const 0))",
            ]
        )
        return lines

    def _emit_stream_skip(self, inst: StreamOp, dest: str, source: str) -> list[str]:
        """Emit stream skip: produce a new list skipping the first N elements."""
        tag = f"{id(inst) & 0xFFFF}"
        src_list, src_len, src_data, idx, dst_list, dst_data = self._stream_ensure_locals(tag)
        skip_n_local = f"_strm_sn_{tag}"
        new_len_local = f"_strm_nl_{tag}"
        for loc_name in (skip_n_local, new_len_local):
            if loc_name not in self._locals:
                self._locals[loc_name] = _WASM_I32
        safe_skip_n = _sanitize_name(skip_n_local)
        safe_new_len = _sanitize_name(new_len_local)

        count_name = _sanitize_name(inst.args[0].name) if inst.args else "0"
        blk = f"$strm_skip_brk_{tag}"
        lp = f"$strm_skip_lp_{tag}"

        lines: list[str] = [
            "      ;; stream_skip (eager)",
            f"      (local.set ${src_list} (i32.load (local.get ${source})))",
            f"      (local.set ${src_len} (i32.load (local.get ${src_list})))",
            f"      (local.set ${src_data}"
            f" (i32.load (i32.add (local.get ${src_list}) (i32.const 12))))",
        ]
        if inst.args:
            lines.append(
                f"      (local.set ${safe_skip_n}" f" (i32.wrap_i64 (local.get ${count_name})))"
            )
        else:
            lines.append(f"      (local.set ${safe_skip_n} (i32.const 0))")
        lines.extend(
            [
                # Clamp skip_n to source length
                f"      (if (i32.gt_u (local.get ${safe_skip_n}) (local.get ${src_len}))",
                f"        (then (local.set ${safe_skip_n} (local.get ${src_len})))",
                "      )",
                # Calculate new length
                f"      (local.set ${safe_new_len}"
                f" (i32.sub (local.get ${src_len}) (local.get ${safe_skip_n})))",
                # Allocate output list
                f"      (local.set ${dst_list}"
                f" (call $__alloc (i32.const {_LIST_HEADER_SIZE}) (i32.const 4)))",
                f"      (i32.store (local.get ${dst_list}) (local.get ${safe_new_len}))",
                f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 4))"
                f" (local.get ${safe_new_len}))",
                f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 8))"
                f" (i32.const 8))",
                f"      (local.set ${dst_data}"
                " (call $__alloc"
                f" (i32.mul (local.get ${safe_new_len}) (i32.const 8))"
                " (i32.const 8)))",
                f"      (i32.store (i32.add (local.get ${dst_list}) (i32.const 12))"
                f" (local.get ${dst_data}))",
                # Copy elements starting from skip_n
                f"      (local.set ${idx} (i32.const 0))",
                f"      (block {blk}",
                f"        (loop {lp}",
                f"          (br_if {blk}"
                f" (i32.ge_u (local.get ${idx}) (local.get ${safe_new_len})))",
                f"          (i64.store (i32.add (local.get ${dst_data})"
                f" (i32.mul (local.get ${idx}) (i32.const 8)))"
                f" (i64.load (i32.add (local.get ${src_data})"
                f" (i32.mul (i32.add (local.get ${idx}) (local.get ${safe_skip_n}))"
                f" (i32.const 8)))))",
                f"          (local.set ${idx}" f" (i32.add (local.get ${idx}) (i32.const 1)))",
                f"          (br {lp})",
                "        )",
                "      )",
                # Wrap in stream
                f"      (local.set ${dest}"
                f" (call $__alloc (i32.const {_STREAM_SIZE}) (i32.const 4)))",
                f"      (i32.store (local.get ${dest}) (local.get ${dst_list}))",
                f"      (i32.store (i32.add (local.get ${dest}) (i32.const 4)) (i32.const 0))",
            ]
        )
        return lines

    def _emit_stream_collect(self, inst: StreamOp, dest: str, source: str) -> list[str]:
        """Emit stream collect: extract the underlying list from the stream.

        Since all operators eagerly produce lists, collect just returns
        the stream's current source list pointer.
        """
        return [
            "      ;; stream_collect (extract list from stream)",
            f"      (local.set ${dest} (i32.load (local.get ${source})))",
        ]

    def _emit_stream_fold(self, inst: StreamOp, dest: str, source: str) -> list[str]:
        """Emit stream fold: reduce all elements using an accumulator function.

        fold(init, fn) where fn(acc, elem) -> acc
        args[0] = initial accumulator value
        fn_name = fold function name
        """
        tag = f"{id(inst) & 0xFFFF}"
        src_list_local = f"_strm_fsl_{tag}"
        src_len_local = f"_strm_fln_{tag}"
        src_data_local = f"_strm_fsd_{tag}"
        idx_local = f"_strm_fix_{tag}"
        acc_local = f"_strm_fac_{tag}"
        for loc_name in (src_list_local, src_len_local, src_data_local, idx_local):
            if loc_name not in self._locals:
                self._locals[loc_name] = _WASM_I32
        if acc_local not in self._locals:
            self._locals[acc_local] = _WASM_I64
        safe_sl = _sanitize_name(src_list_local)
        safe_ln = _sanitize_name(src_len_local)
        safe_sd = _sanitize_name(src_data_local)
        safe_ix = _sanitize_name(idx_local)
        safe_acc = _sanitize_name(acc_local)

        fn_name = _sanitize_name(inst.fn_name) if inst.fn_name else ""
        init_name = _sanitize_name(inst.args[0].name) if inst.args else "0"
        blk = f"$strm_fold_brk_{tag}"
        lp = f"$strm_fold_lp_{tag}"

        lines: list[str] = [
            "      ;; stream_fold (eager)",
            f"      (local.set ${safe_sl} (i32.load (local.get ${source})))",
            f"      (local.set ${safe_ln} (i32.load (local.get ${safe_sl})))",
            f"      (local.set ${safe_sd}"
            f" (i32.load (i32.add (local.get ${safe_sl}) (i32.const 12))))",
        ]
        # Initialize accumulator
        if inst.args:
            init_ty = self._locals.get(inst.args[0].name, _WASM_I64)
            if init_ty == _WASM_I64:
                lines.append(f"      (local.set ${safe_acc} (local.get ${init_name}))")
            else:
                lines.append(
                    f"      (local.set ${safe_acc}" f" (i64.extend_i32_u (local.get ${init_name})))"
                )
        else:
            lines.append(f"      (local.set ${safe_acc} (i64.const 0))")
        lines.extend(
            [
                f"      (local.set ${safe_ix} (i32.const 0))",
                f"      (block {blk}",
                f"        (loop {lp}",
                f"          (br_if {blk} (i32.ge_u (local.get ${safe_ix}) (local.get ${safe_ln})))",
            ]
        )
        if fn_name:
            lines.append(
                f"          (local.set ${safe_acc}"
                f" (call ${fn_name} (local.get ${safe_acc})"
                f" (i64.load (i32.add (local.get ${safe_sd})"
                f" (i32.mul (local.get ${safe_ix}) (i32.const 8))))))"
            )
        lines.extend(
            [
                f"          (local.set ${safe_ix}"
                f" (i32.add (local.get ${safe_ix}) (i32.const 1)))",
                f"          (br {lp})",
                "        )",
                "      )",
                f"      (local.set ${dest} (local.get ${safe_acc}))",
            ]
        )
        return lines

    # ------------------------------------------------------------------
    # Closure instructions
    # ------------------------------------------------------------------

    def _emit_closure_create(self, inst: ClosureCreate, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit closure creation: allocate env struct and store captures."""
        dest = _sanitize_name(inst.dest.name)
        captures = inst.captures
        env_size = max(len(captures) * 8, 8)
        # Closure layout: [i32 fn_index, i32 env_ptr]
        closure_size = 8

        lines: list[str] = []
        lines.append(
            f"      ;; closure_create {inst.fn_name}",
        )
        # Allocate closure struct
        lines.append(
            f"      (local.set ${dest}"
            f" (call $__alloc (i32.const {closure_size}) (i32.const 4)))"
        )
        # Store function index
        fn_idx = self._func_indices.get(inst.fn_name, 0)
        lines.append(f"      (i32.store (local.get ${dest}) (i32.const {fn_idx}))")

        if captures:
            # Allocate and fill environment
            env_local = f"_env_{id(inst) & 0xFFFF}"
            if env_local not in self._locals:
                self._locals[env_local] = _WASM_I32
            safe_env = _sanitize_name(env_local)
            lines.append(
                f"      (local.set ${safe_env}"
                f" (call $__alloc (i32.const {env_size}) (i32.const 8)))"
            )
            lines.append(
                f"      (i32.store (i32.add (local.get ${dest}) (i32.const 4))"
                f" (local.get ${safe_env}))"
            )
            for i, cap_val in enumerate(captures):
                cap_name = _sanitize_name(cap_val.name)
                cap_ty = self._locals.get(cap_val.name, _WASM_I64)
                store_op = self._store_op_for_type(cap_ty)
                lines.append(
                    f"      ({store_op}"
                    f" (i32.add (local.get ${safe_env}) (i32.const {i * 8}))"
                    f" (local.get ${cap_name}))"
                )
        else:
            lines.append(
                f"      (i32.store (i32.add (local.get ${dest}) (i32.const 4))" f" (i32.const 0))"
            )

        return lines

    def _emit_closure_call(self, inst: ClosureCall, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit closure call via call_indirect through the function table.

        Closure layout: [i32 fn_index (offset 0), i32 env_ptr (offset 4)]
        The function is invoked with env_ptr as first argument, followed by
        any additional arguments from inst.args.
        """
        dest = _sanitize_name(inst.dest.name)
        closure = _sanitize_name(inst.closure.name)

        # Temp locals for fn_index and env_ptr extraction
        fn_idx_local = f"_cls_fi_{id(inst) & 0xFFFF}"
        env_ptr_local = f"_cls_ep_{id(inst) & 0xFFFF}"
        for loc_name in (fn_idx_local, env_ptr_local):
            if loc_name not in self._locals:
                self._locals[loc_name] = _WASM_I32
        safe_fi = _sanitize_name(fn_idx_local)
        safe_ep = _sanitize_name(env_ptr_local)

        # Build the type signature for call_indirect
        # Closure functions take (env_ptr: i32, args...) -> result
        param_types = [_WASM_I32]  # env_ptr
        for arg in inst.args:
            arg_ty = self._locals.get(arg.name, _WASM_I64)
            param_types.append(arg_ty)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
        param_str = " ".join(f"(param {p})" for p in param_types)
        result_str = f" (result {dest_ty})" if dest_ty else ""
        type_sig = f"(type ({param_str}{result_str}))"

        # Build argument push sequence
        arg_pushes: list[str] = [f"        (local.get ${safe_ep})"]
        for arg in inst.args:
            arg_name = _sanitize_name(arg.name)
            arg_pushes.append(f"        (local.get ${arg_name})")

        lines: list[str] = [
            "      ;; closure_call (call_indirect)",
            # Extract fn_index from closure offset 0
            f"      (local.set ${safe_fi} (i32.load (local.get ${closure})))",
            # Extract env_ptr from closure offset 4
            f"      (local.set ${safe_ep}"
            f" (i32.load (i32.add (local.get ${closure}) (i32.const 4))))",
            # Call indirect: push args, then fn_index for table lookup
            f"      (local.set ${dest}",
            f"        (call_indirect {type_sig}",
        ]
        lines.extend(arg_pushes)
        lines.extend(
            [
                f"          (local.get ${safe_fi})",
                "        )",
                "      )",
            ]
        )
        return lines

    def _emit_env_load(self, inst: EnvLoad, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit loading a captured variable from the closure environment."""
        dest = _sanitize_name(inst.dest.name)
        env = _sanitize_name(inst.env.name)
        dest_ty = self._locals.get(inst.dest.name, _WASM_I64)
        load_op = self._load_op_for_type(dest_ty)
        offset = inst.index * 8
        return [
            f"      (local.set ${dest} ({load_op}"
            f" (i32.add (local.get ${env}) (i32.const {offset}))))"
        ]

    # ------------------------------------------------------------------
    # Assert instruction
    # ------------------------------------------------------------------

    def _emit_assert(self, inst: Assert, _bl: str, _fn: MIRFunction) -> list[str]:
        """Emit a runtime assertion."""
        cond = _sanitize_name(inst.cond.name)
        cond_ty = self._locals.get(inst.cond.name, _WASM_I32)

        lines: list[str] = []
        # Convert condition to i32 if needed
        if cond_ty == _WASM_I64:
            cond_expr = f"(i32.wrap_i64 (local.get ${cond}))"
        elif cond_ty == _WASM_I32:
            cond_expr = f"(local.get ${cond})"
        else:
            cond_expr = f"(i32.trunc_f64_s (local.get ${cond}))"

        # If condition is false, abort
        lines.append(f"      (if (i32.eqz {cond_expr})")
        lines.append("        (then")

        if inst.message is not None:
            msg = _sanitize_name(inst.message.name)
            lines.append(
                f"          (call $abort"
                f" (i32.add (local.get ${msg}) (i32.const 4))"
                f" (i32.load (local.get ${msg})))"
            )
        else:
            # Use a default message from the string table
            msg_str = f"assertion failed at {inst.filename}:{inst.line}"
            offset = self._string_cache.get(msg_str, 0)
            encoded_len = len(msg_str.encode("utf-8"))
            lines.append(
                f"          (call $abort"
                f" (i32.const {offset + _I32_SIZE})"
                f" (i32.const {encoded_len}))"
            )

        lines.append("        )")
        lines.append("      )")

        return lines

    # ------------------------------------------------------------------
    # Memory operation helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _store_op_for_type(wasm_ty: str) -> str:
        """Return the WASM store instruction for a given type."""
        if wasm_ty == _WASM_I64:
            return "i64.store"
        if wasm_ty == _WASM_F64:
            return "f64.store"
        return "i32.store"

    @staticmethod
    def _load_op_for_type(wasm_ty: str) -> str:
        """Return the WASM load instruction for a given type."""
        if wasm_ty == _WASM_I64:
            return "i64.load"
        if wasm_ty == _WASM_F64:
            return "f64.load"
        return "i32.load"


# ---------------------------------------------------------------------------
# Name sanitization
# ---------------------------------------------------------------------------


def _sanitize_name(name: str) -> str:
    """Sanitize a MIR name for use as a WASM identifier.

    WASM identifiers (after $) allow most printable ASCII characters,
    but we replace problematic ones for safety.
    """
    if not name:
        return "_unnamed"
    # Strip leading % from SSA names
    if name.startswith("%"):
        name = name[1:]
    # Replace characters that could confuse WAT parsers
    result = name.replace(".", "_").replace("-", "_").replace("::", "__")
    result = result.replace(" ", "_").replace("<", "_").replace(">", "_")
    result = result.replace(",", "_").replace("(", "_").replace(")", "_")
    if not result:
        return "_unnamed"
    # Ensure doesn't start with a digit
    if result[0].isdigit():
        result = "v" + result
    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def compile_to_wasm(
    mir_module: MIRModule,
    options: WasmOptions | None = None,
) -> str:
    """Compile a MIR module to WebAssembly text format (WAT).

    Args:
        mir_module: The MIR module to compile.
        options: Optional configuration for the emitter.

    Returns:
        A string containing the complete WAT module.
    """
    emitter = WasmEmitter(options=options)
    return emitter.emit(mir_module)


def compile_to_wasm_binary(
    mir_module: MIRModule,
    options: WasmOptions | None = None,
) -> bytes:
    """Compile a MIR module to WebAssembly binary format (.wasm).

    This first emits WAT text, then invokes ``wat2wasm`` (from the
    WebAssembly Binary Toolkit) to convert it to binary. Raises
    RuntimeError if wat2wasm is not available.

    Args:
        mir_module: The MIR module to compile.
        options: Optional configuration for the emitter.

    Returns:
        The WASM binary as bytes.

    Raises:
        RuntimeError: If wat2wasm is not found or the conversion fails.
    """
    wat_text = compile_to_wasm(mir_module, options=options)

    try:
        result = subprocess.run(
            ["wat2wasm", "-", "--output=-"],
            input=wat_text.encode("utf-8"),
            capture_output=True,
            timeout=30,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "wat2wasm is required for binary WASM output. "
            "Install the WebAssembly Binary Toolkit: "
            "https://github.com/WebAssembly/wabt"
        ) from None

    if result.returncode != 0:
        error_msg = result.stderr.decode("utf-8", errors="replace")
        raise RuntimeError(f"wat2wasm failed:\n{error_msg}")

    return result.stdout
