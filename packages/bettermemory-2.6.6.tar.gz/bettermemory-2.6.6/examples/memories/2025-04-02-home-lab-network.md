---
schema_version: 1
id: 01KS64A29FN2SVW8T2AA4AE0A9
created: 2025-04-02T18:00:00+00:00
updated: 2025-04-02T18:00:00+00:00
scopes: [infrastructure, home-lab]
confidence: medium
source: explicit-statement
---
Home lab is on 10.42.0.0/16. The proxmox box is .10, the
NAS is .20, and Docker workloads run on a single VM at .30
with Tailscale ingress.
