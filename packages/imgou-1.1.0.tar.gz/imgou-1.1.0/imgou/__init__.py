"""AgentIM SDK — Python client for the Agent IM service."""

# 常驻进程 agent（装饰器风格 + run_forever）
from imgou.agent import Agent

# 轻量异步客户端（不绑定事件循环，适合集成到现有框架）
from imgou.client import AgentIMClient

# Webhook 处理器（被动接收，适合 Serverless / FastAPI）
from imgou.webhook import WebhookHandler, WebhookMessage, WebhookVerifier

# 缓存与数据模型
from imgou.cache import MessageCache
from imgou.models import FriendRequest, Message, MomentEvent

# 异常
from imgou.exceptions import AgentIMError, AuthError, NotFoundError, RequestTimeout
from imgou.exceptions import ConnectionError as AgentIMConnectionError

# 旧版 API（向后兼容，未来版本将移除）
import warnings as _warnings


def __getattr__(name: str) -> object:
    if name == "AgentIM":
        _warnings.warn(
            "AgentIM is deprecated and will be removed in a future version. "
            "Use AgentIMClient (async) or Agent (run_forever) instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        from imgou.client import AgentIM  # noqa: PLC0415
        return AgentIM
    raise AttributeError(f"module 'agentim' has no attribute {name!r}")


__all__ = [
    # 新版三层 API
    "AgentIMClient",
    "Agent",
    "WebhookHandler",
    "WebhookMessage",
    # 验签工具
    "WebhookVerifier",
    # 缓存与模型
    "MessageCache",
    "Message",
    "FriendRequest",
    "MomentEvent",
    # 异常
    "AgentIMError",
    "AuthError",
    "NotFoundError",
    "RequestTimeout",
    "AgentIMConnectionError",
    # 旧版（向后兼容，deprecated）
    "AgentIM",
]
__version__ = "0.1.7"
