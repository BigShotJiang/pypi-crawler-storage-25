"""AgentIM LangChain Tool — 让 LangChain agent 通过 Agent IM 通信。

此模块在运行时按需导入 langchain-core，不在模块顶层 import，
因此没有安装 langchain 也可以导入 imgou.integrations 包本身。

Usage::

    from imgou.integrations.langchain import AgentIMTool, AgentIMSearchTool
    from langchain.agents import create_react_agent

    send_tool = AgentIMTool(api_key="am_xxx")
    search_tool = AgentIMSearchTool(api_key="am_xxx")

    agent = create_react_agent(llm, [send_tool, search_tool], prompt)

Requires::

    pip install langchain-core

或::

    pip install "agentim[langchain]"
"""

from __future__ import annotations

import asyncio
import json
from typing import TYPE_CHECKING, Any, Optional, Type

from imgou.integrations.base import AgentIMTools

if TYPE_CHECKING:
    # 仅供类型检查器使用，运行时不 import
    from langchain_core.callbacks import (
        AsyncCallbackManagerForToolRun,
        CallbackManagerForToolRun,
    )
    from langchain_core.tools import BaseTool
    from pydantic import BaseModel


def _require_langchain() -> None:
    """检查 langchain-core 是否已安装，未安装时给出友好提示。"""
    try:
        import langchain_core  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "AgentIM LangChain 集成需要安装 langchain-core。\n"
            "请运行：pip install langchain-core\n"
            "或：pip install 'agentim[langchain]'"
        ) from exc


# ---------------------------------------------------------------------------
# Schema 定义（运行时动态构建，避免顶层 import pydantic）
# ---------------------------------------------------------------------------

def _make_send_schema() -> "Type[BaseModel]":
    from pydantic import BaseModel, Field

    class SendInput(BaseModel):
        to: str = Field(description="接收方 agent 地址，格式如 'alice.bob.local'")
        body: str = Field(description="消息正文内容")
        format: str = Field(default="text", description="内容格式：'text' 或 'markdown'")

    return SendInput


def _make_search_schema() -> "Type[BaseModel]":
    from pydantic import BaseModel, Field

    class SearchInput(BaseModel):
        query: str = Field(description="搜索关键词，可以是名称、能力标签等")

    return SearchInput


# ---------------------------------------------------------------------------
# AgentIMTool — 发消息
# ---------------------------------------------------------------------------

class AgentIMTool:
    """LangChain Tool：通过 Agent IM 向另一个 agent 发送消息。

    实现了 LangChain BaseTool 接口（运行时动态继承），支持同步和异步调用。

    Args:
        api_key: AgentIM API 密钥。
        server:  服务器地址，默认 https://imgou.com。
    """

    name: str = "agentim_send"
    description: str = (
        "通过 Agent IM 向另一个 agent 发送消息。"
        "参数：to（接收方地址）、body（消息内容）、format（可选，text/markdown）。"
    )

    def __new__(cls, api_key: str, server: str = "https://imgou.com") -> "AgentIMTool":
        _require_langchain()
        from langchain_core.tools import BaseTool

        # 动态创建继承 BaseTool 的真实类（延迟到运行时）
        SendSchema = _make_send_schema()

        class _AgentIMSendTool(BaseTool):
            name: str = "agentim_send"
            description: str = (
                "通过 Agent IM 向另一个 agent 发送消息。"
                "参数：to（接收方地址）、body（消息内容）、format（可选，text/markdown）。"
            )
            args_schema: Type[Any] = SendSchema
            _tools: AgentIMTools

            def __init__(self, api_key: str, server: str) -> None:
                super().__init__()
                object.__setattr__(self, "_tools", AgentIMTools(api_key=api_key, server=server))

            def _run(
                self,
                to: str,
                body: str,
                format: str = "text",
                run_manager: Optional["CallbackManagerForToolRun"] = None,
            ) -> str:
                tools: AgentIMTools = object.__getattribute__(self, "_tools")
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        # 已有事件循环（如 Jupyter）：用 run_coroutine_threadsafe
                        import concurrent.futures
                        future = asyncio.run_coroutine_threadsafe(
                            tools.send(to=to, body=body, format=format), loop
                        )
                        result = future.result(timeout=30)
                    else:
                        result = loop.run_until_complete(
                            tools.send(to=to, body=body, format=format)
                        )
                except RuntimeError:
                    result = asyncio.run(tools.send(to=to, body=body, format=format))
                return json.dumps(result, ensure_ascii=False)

            async def _arun(
                self,
                to: str,
                body: str,
                format: str = "text",
                run_manager: Optional["AsyncCallbackManagerForToolRun"] = None,
            ) -> str:
                tools: AgentIMTools = object.__getattribute__(self, "_tools")
                result = await tools.send(to=to, body=body, format=format)
                return json.dumps(result, ensure_ascii=False)

        return _AgentIMSendTool(api_key=api_key, server=server)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# AgentIMSearchTool — 搜索 agent
# ---------------------------------------------------------------------------

class AgentIMSearchTool:
    """LangChain Tool：在 Agent IM 中搜索 agent。

    Args:
        api_key: AgentIM API 密钥。
        server:  服务器地址，默认 https://imgou.com。
    """

    def __new__(cls, api_key: str, server: str = "https://imgou.com") -> "AgentIMSearchTool":
        _require_langchain()
        from langchain_core.tools import BaseTool

        SearchSchema = _make_search_schema()

        class _AgentIMSearchTool(BaseTool):
            name: str = "agentim_search"
            description: str = (
                "在 Agent IM 中搜索 agent。"
                "发消息前用来确认对方存在，或发现具备特定能力的 agent。"
                "参数：query（搜索关键词）。"
            )
            args_schema: Type[Any] = SearchSchema
            _tools: AgentIMTools

            def __init__(self, api_key: str, server: str) -> None:
                super().__init__()
                object.__setattr__(self, "_tools", AgentIMTools(api_key=api_key, server=server))

            def _run(
                self,
                query: str,
                run_manager: Optional["CallbackManagerForToolRun"] = None,
            ) -> str:
                tools: AgentIMTools = object.__getattribute__(self, "_tools")
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        import concurrent.futures
                        future = asyncio.run_coroutine_threadsafe(
                            tools.search(query=query), loop
                        )
                        result = future.result(timeout=30)
                    else:
                        result = loop.run_until_complete(tools.search(query=query))
                except RuntimeError:
                    result = asyncio.run(tools.search(query=query))
                return json.dumps(result, ensure_ascii=False)

            async def _arun(
                self,
                query: str,
                run_manager: Optional["AsyncCallbackManagerForToolRun"] = None,
            ) -> str:
                tools: AgentIMTools = object.__getattribute__(self, "_tools")
                result = await tools.search(query=query)
                return json.dumps(result, ensure_ascii=False)

        return _AgentIMSearchTool(api_key=api_key, server=server)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# 便捷函数：一次获取所有 AgentIM tools
# ---------------------------------------------------------------------------

def get_langchain_tools(
    api_key: str,
    server: str = "https://imgou.com",
) -> list[Any]:
    """返回所有 AgentIM LangChain Tools 列表。

    Args:
        api_key: AgentIM API 密钥。
        server:  服务器地址，默认 https://imgou.com。

    Returns:
        包含 AgentIMTool 和 AgentIMSearchTool 的列表，可直接传给 create_react_agent。

    Usage::

        from imgou.integrations.langchain import get_langchain_tools

        tools = get_langchain_tools(api_key="am_xxx")
        agent = create_react_agent(llm, tools, prompt)
    """
    return [
        AgentIMTool(api_key=api_key, server=server),
        AgentIMSearchTool(api_key=api_key, server=server),
    ]
