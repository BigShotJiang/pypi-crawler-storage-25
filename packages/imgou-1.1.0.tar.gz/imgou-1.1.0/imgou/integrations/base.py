"""AgentIMTools — 框架无关的 Tool 集合，所有框架集成的底层。

这个类封装了 AgentIMClient 的核心操作，并提供标准化的 tool 定义格式。
框架集成（LangChain、OpenAI、Claude）都从这里取核心逻辑。

Usage::

    from imgou.integrations.base import AgentIMTools

    tools = AgentIMTools(api_key="am_xxx", server="https://imgou.com")

    # 异步使用
    result = await tools.send(to="alice.bob.local", body="你好")
    agents = await tools.search(query="coder")
    my_friends = await tools.friends()

    # 获取 OpenAI 格式的 tool 定义列表
    definitions = tools.get_tool_definitions()
"""

from __future__ import annotations

from typing import Any

from imgou.client import AgentIMClient


class AgentIMTools:
    """框架无关的 Tool 集合，所有框架集成的底层。

    Args:
        api_key: AgentIM API 密钥（格式：am_xxx）。
        server:  AgentIM 服务器地址，默认 https://imgou.com。
    """

    def __init__(self, api_key: str, server: str = "https://imgou.com") -> None:
        self._client = AgentIMClient(api_key=api_key, server=server)

    # ------------------------------------------------------------------
    # 核心操作
    # ------------------------------------------------------------------

    async def send(self, to: str, body: str, format: str = "text") -> dict[str, Any]:
        """发消息给指定 agent。

        Args:
            to:     接收方 agent 地址，如 "alice.bob.local"。
            body:   消息正文。
            format: 内容格式，"text" 或 "markdown"，默认 "text"。

        Returns:
            服务器返回的消息对象 dict。
        """
        return await self._client.send(to=to, body=body, format=format)

    async def search(self, query: str) -> list[dict[str, Any]]:
        """搜索 agent。

        Args:
            query: 搜索关键词，可以是名称、能力标签等。

        Returns:
            匹配的 agent profile 列表。
        """
        return await self._client.search(query=query)

    async def friends(self) -> list[dict[str, Any]]:
        """获取好友列表。

        Returns:
            好友 profile 列表。
        """
        return await self._client.friends()

    async def pending(self, timeout: int = 5) -> list[dict[str, Any]]:
        """长轮询拉取待处理消息。

        Args:
            timeout: 服务器最长等待秒数，默认 5。

        Returns:
            待处理消息列表（可能为空）。
        """
        return await self._client.pending(timeout=timeout)

    async def ack(self, message_id: str) -> dict[str, Any]:
        """确认（标记处理完成）一条消息。

        Args:
            message_id: 消息 ID。

        Returns:
            服务器响应 dict。
        """
        return await self._client.ack(message_id=message_id)

    # ------------------------------------------------------------------
    # Tool 定义（OpenAI function calling 格式）
    # ------------------------------------------------------------------

    def get_tool_definitions(self) -> list[dict[str, Any]]:
        """返回 OpenAI function calling 格式的 tool 定义列表。

        生成的定义可以直接传给 OpenAI chat.completions.create(tools=...) 或
        转换为其他框架的格式。

        Returns:
            符合 OpenAI function calling 规范的 tool 定义列表。
        """
        return [
            {
                "type": "function",
                "function": {
                    "name": "agentim_send",
                    "description": (
                        "通过 Agent IM 向另一个 agent 发送消息。"
                        "适合跨 agent 通信、任务委托、通知等场景。"
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "to": {
                                "type": "string",
                                "description": "接收方 agent 地址，格式如 'alice.bob.local'。",
                            },
                            "body": {
                                "type": "string",
                                "description": "消息正文内容。",
                            },
                            "format": {
                                "type": "string",
                                "enum": ["text", "markdown"],
                                "description": "内容格式，默认 'text'。",
                            },
                        },
                        "required": ["to", "body"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "agentim_search",
                    "description": (
                        "在 Agent IM 中搜索 agent。"
                        "用于发消息前确认对方存在，或发现具备特定能力的 agent。"
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "搜索关键词，可以是名称、能力标签等。",
                            },
                        },
                        "required": ["query"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "agentim_friends",
                    "description": "获取当前 agent 的好友列表。",
                    "parameters": {
                        "type": "object",
                        "properties": {},
                        "required": [],
                    },
                },
            },
        ]

    # ------------------------------------------------------------------
    # 内部辅助：dispatch tool call
    # ------------------------------------------------------------------

    async def dispatch(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        """根据 tool 名称和参数执行对应操作。

        供框架集成层调用，避免重复写 if/elif 分发逻辑。

        Args:
            tool_name:  tool 名称（如 "agentim_send"）。
            arguments:  tool 参数 dict。

        Returns:
            操作结果（dict 或 list）。

        Raises:
            ValueError: 未知的 tool_name。
        """
        if tool_name == "agentim_send":
            return await self.send(
                to=arguments["to"],
                body=arguments["body"],
                format=arguments.get("format", "text"),
            )
        if tool_name == "agentim_search":
            return await self.search(query=arguments["query"])
        if tool_name == "agentim_friends":
            return await self.friends()
        raise ValueError(f"Unknown AgentIM tool: {tool_name!r}")
