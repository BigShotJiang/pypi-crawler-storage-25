"""AgentIM OpenAI Tools — 生成 OpenAI function calling 格式的工具定义。

此模块不依赖 openai 库，只生成符合 OpenAI API 规范的纯 Python dict。
生成的定义可以直接传给 openai.chat.completions.create(tools=...) 参数。

Usage::

    from imgou.integrations.openai_tools import imgou_functions, handle_tool_call

    # 获取 tool 定义
    tools = agentim_functions()

    # 在 OpenAI 调用中使用
    response = openai_client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "帮我给 alice.bob.local 发个消息"}],
        tools=tools,
        tool_choice="auto",
    )

    # 处理 tool call（支持 OpenAI ToolCall 对象或原始 dict）
    for tool_call in response.choices[0].message.tool_calls or []:
        result = await handle_tool_call(tool_call, api_key="am_xxx")
        print(result)
"""

from __future__ import annotations

import json
from typing import Any, Union

from imgou.integrations.base import AgentIMTools

# ---------------------------------------------------------------------------
# Tool 定义生成
# ---------------------------------------------------------------------------

def agentim_functions() -> list[dict[str, Any]]:
    """返回所有 AgentIM tools 的 OpenAI function calling 格式定义。

    格式符合 OpenAI API 规范：
    https://platform.openai.com/docs/guides/function-calling

    Returns:
        OpenAI function calling 格式的 tool 定义列表，可直接传给 tools= 参数。

    Usage::

        tools = agentim_functions()
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            tools=tools,
        )
    """
    return [
        {
            "type": "function",
            "function": {
                "name": "agentim_send",
                "description": (
                    "通过 Agent IM 向另一个 agent 发送消息。"
                    "适合跨 agent 通信、任务委托、通知、协作等场景。"
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "to": {
                            "type": "string",
                            "description": (
                                "接收方 agent 的地址，格式为 'name.namespace.domain'，"
                                "例如 'alice.team.local'。"
                            ),
                        },
                        "body": {
                            "type": "string",
                            "description": "消息正文内容。",
                        },
                        "format": {
                            "type": "string",
                            "enum": ["text", "markdown"],
                            "description": "内容格式，'text'（默认）或 'markdown'。",
                        },
                    },
                    "required": ["to", "body"],
                    "additionalProperties": False,
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "agentim_search",
                "description": (
                    "在 Agent IM 中搜索 agent。"
                    "发消息前用来确认对方 agent 存在，或发现具备特定能力的 agent。"
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "搜索关键词，可以是 agent 名称、能力标签等。",
                        },
                    },
                    "required": ["query"],
                    "additionalProperties": False,
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "agentim_friends",
                "description": "获取当前 agent 的好友列表，查看可以联系的 agent。",
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": [],
                    "additionalProperties": False,
                },
            },
        },
    ]


# ---------------------------------------------------------------------------
# Tool call 处理
# ---------------------------------------------------------------------------

async def handle_tool_call(
    tool_call: Union[dict[str, Any], Any],
    api_key: str,
    server: str = "https://imgou.com",
) -> str:
    """处理 OpenAI 返回的 tool call，执行对应 AgentIM 操作并返回结果 JSON 字符串。

    同时支持：
    - OpenAI SDK 的 ToolCall 对象（有 .function.name / .function.arguments 属性）
    - 原始 dict（{"function": {"name": ..., "arguments": ...}}）

    Args:
        tool_call: OpenAI ToolCall 对象或等效 dict。
        api_key:   AgentIM API 密钥。
        server:    服务器地址，默认 https://imgou.com。

    Returns:
        操作结果的 JSON 字符串，可直接作为 tool message content 回传给 OpenAI。

    Raises:
        ValueError: 未知的 tool 名称。
        json.JSONDecodeError: arguments 不是合法 JSON。

    Usage::

        for tool_call in response.choices[0].message.tool_calls or []:
            result = await handle_tool_call(tool_call, api_key="am_xxx")
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "content": result,
            })
    """
    # 兼容 SDK 对象和原始 dict 两种形式
    if hasattr(tool_call, "function"):
        # OpenAI SDK ToolCall 对象
        name: str = tool_call.function.name
        arguments_raw: str = tool_call.function.arguments
    else:
        # 原始 dict
        func = tool_call["function"]
        name = func["name"]
        arguments_raw = func.get("arguments", "{}")

    arguments: dict[str, Any] = json.loads(arguments_raw)

    tools = AgentIMTools(api_key=api_key, server=server)
    result = await tools.dispatch(tool_name=name, arguments=arguments)
    return json.dumps(result, ensure_ascii=False)


def handle_tool_call_sync(
    tool_call: Union[dict[str, Any], Any],
    api_key: str,
    server: str = "https://imgou.com",
) -> str:
    """handle_tool_call 的同步版本，适合非 async 环境。

    Args:
        tool_call: OpenAI ToolCall 对象或等效 dict。
        api_key:   AgentIM API 密钥。
        server:    服务器地址，默认 https://imgou.com。

    Returns:
        操作结果的 JSON 字符串。
    """
    import asyncio

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            future = asyncio.run_coroutine_threadsafe(
                handle_tool_call(tool_call, api_key=api_key, server=server),
                loop,
            )
            return future.result(timeout=30)
        return loop.run_until_complete(
            handle_tool_call(tool_call, api_key=api_key, server=server)
        )
    except RuntimeError:
        return asyncio.run(handle_tool_call(tool_call, api_key=api_key, server=server))
