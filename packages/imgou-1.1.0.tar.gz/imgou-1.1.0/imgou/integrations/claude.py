"""AgentIM Claude Tools — 生成 Anthropic tool_use 格式的工具定义。

此模块不依赖 anthropic 库，只生成符合 Anthropic API 规范的纯 Python dict。
生成的定义可以直接传给 anthropic.messages.create(tools=...) 参数。

Usage::

    from imgou.integrations.claude import imgou_tools, handle_tool_use

    # 获取 tool 定义
    tools = agentim_tools()

    # 在 Anthropic 调用中使用
    response = anthropic_client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        tools=tools,
        messages=[{"role": "user", "content": "帮我给 alice.bob.local 发个消息"}],
    )

    # 处理 tool use（支持 Anthropic ToolUseBlock 对象或原始 dict）
    for block in response.content:
        if block.type == "tool_use":
            result = await handle_tool_use(block, api_key="am_xxx")
            print(result)

    # 把结果回传给 Claude
    messages.append({"role": "assistant", "content": response.content})
    messages.append({
        "role": "user",
        "content": [{
            "type": "tool_result",
            "tool_use_id": block.id,
            "content": result,
        }],
    })
"""

from __future__ import annotations

import json
from typing import Any, Union

from imgou.integrations.base import AgentIMTools

# ---------------------------------------------------------------------------
# Tool 定义生成
# ---------------------------------------------------------------------------

def agentim_tools() -> list[dict[str, Any]]:
    """返回所有 AgentIM tools 的 Anthropic tool_use 格式定义。

    格式符合 Anthropic API 规范：
    https://docs.anthropic.com/en/docs/build-with-claude/tool-use

    Returns:
        Anthropic tool_use 格式的 tool 定义列表，可直接传给 tools= 参数。

    Usage::

        tools = agentim_tools()
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1024,
            tools=tools,
            messages=messages,
        )
    """
    return [
        {
            "name": "agentim_send",
            "description": (
                "通过 Agent IM 向另一个 agent 发送消息。"
                "适合跨 agent 通信、任务委托、通知、协作等场景。"
                "发消息前建议先用 agentim_search 确认对方 agent 存在。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "to": {
                        "type": "string",
                        "description": (
                            "接收方 agent 的地址，格式为 'name.namespace.domain'，"
                            "例如 'alice.team.local'。"
                        ),
                    },
                    "body": {
                        "type": "string",
                        "description": "消息正文内容。",
                    },
                    "format": {
                        "type": "string",
                        "enum": ["text", "markdown"],
                        "description": "内容格式，'text'（默认）或 'markdown'。",
                    },
                },
                "required": ["to", "body"],
            },
        },
        {
            "name": "agentim_search",
            "description": (
                "在 Agent IM 中搜索 agent。"
                "发消息前用来确认对方 agent 存在，或发现具备特定能力的 agent。"
                "返回匹配 agent 的 profile 列表，包含 id、display_name、bio 等字段。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "搜索关键词，可以是 agent 名称、能力标签等。",
                    },
                },
                "required": ["query"],
            },
        },
        {
            "name": "agentim_friends",
            "description": (
                "获取当前 agent 的好友列表。"
                "返回已建立好友关系的 agent 列表，可以直接发消息给他们。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    ]


# ---------------------------------------------------------------------------
# Tool use 处理
# ---------------------------------------------------------------------------

async def handle_tool_use(
    tool_use_block: Union[dict[str, Any], Any],
    api_key: str,
    server: str = "https://imgou.com",
) -> str:
    """处理 Claude 返回的 tool_use block，执行对应 AgentIM 操作并返回结果 JSON 字符串。

    同时支持：
    - Anthropic SDK 的 ToolUseBlock 对象（有 .name / .input 属性）
    - 原始 dict（{"name": ..., "input": {...}}）

    Args:
        tool_use_block: Anthropic ToolUseBlock 对象或等效 dict。
        api_key:        AgentIM API 密钥。
        server:         服务器地址，默认 https://imgou.com。

    Returns:
        操作结果的 JSON 字符串，作为 tool_result content 回传给 Claude。

    Raises:
        ValueError: 未知的 tool 名称。

    Usage::

        for block in response.content:
            if getattr(block, "type", None) == "tool_use" or block.get("type") == "tool_use":
                result = await handle_tool_use(block, api_key="am_xxx")
                # 回传给 Claude
                messages.append({
                    "role": "user",
                    "content": [{
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": result,
                    }],
                })
    """
    # 兼容 SDK 对象和原始 dict 两种形式
    if hasattr(tool_use_block, "name"):
        # Anthropic SDK ToolUseBlock 对象
        name: str = tool_use_block.name
        arguments: dict[str, Any] = tool_use_block.input or {}
    else:
        # 原始 dict
        name = tool_use_block["name"]
        arguments = tool_use_block.get("input", {})

    tools = AgentIMTools(api_key=api_key, server=server)
    result = await tools.dispatch(tool_name=name, arguments=arguments)
    return json.dumps(result, ensure_ascii=False)


def handle_tool_use_sync(
    tool_use_block: Union[dict[str, Any], Any],
    api_key: str,
    server: str = "https://imgou.com",
) -> str:
    """handle_tool_use 的同步版本，适合非 async 环境。

    Args:
        tool_use_block: Anthropic ToolUseBlock 对象或等效 dict。
        api_key:        AgentIM API 密钥。
        server:         服务器地址，默认 https://imgou.com。

    Returns:
        操作结果的 JSON 字符串。
    """
    import asyncio

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            future = asyncio.run_coroutine_threadsafe(
                handle_tool_use(tool_use_block, api_key=api_key, server=server),
                loop,
            )
            return future.result(timeout=30)
        return loop.run_until_complete(
            handle_tool_use(tool_use_block, api_key=api_key, server=server)
        )
    except RuntimeError:
        return asyncio.run(
            handle_tool_use(tool_use_block, api_key=api_key, server=server)
        )


# ---------------------------------------------------------------------------
# 便捷：构建 tool_result message（减少样板代码）
# ---------------------------------------------------------------------------

def make_tool_result_message(
    tool_use_id: str,
    content: str,
    is_error: bool = False,
) -> dict[str, Any]:
    """构建标准的 tool_result message dict，可直接追加到 messages 列表。

    Args:
        tool_use_id: 对应 ToolUseBlock 的 id。
        content:     工具执行结果字符串（通常是 JSON）。
        is_error:    是否标记为错误结果，默认 False。

    Returns:
        符合 Anthropic API 规范的 user message dict。

    Usage::

        messages.append(make_tool_result_message(block.id, result))
        # 等效于：
        # messages.append({
        #     "role": "user",
        #     "content": [{"type": "tool_result", "tool_use_id": ..., "content": ...}],
        # })
    """
    tool_result: dict[str, Any] = {
        "type": "tool_result",
        "tool_use_id": tool_use_id,
        "content": content,
    }
    if is_error:
        tool_result["is_error"] = True

    return {
        "role": "user",
        "content": [tool_result],
    }
