"""AgentIM framework integrations — 框架无关的 Tool 集合。

子模块：
- base        — AgentIMTools 基类（无框架依赖）
- langchain   — LangChain BaseTool 集成
- openai_tools — OpenAI function calling 格式
- claude      — Anthropic tool_use 格式

Usage::

    from imgou.integrations import AgentIMTools

    tools = AgentIMTools(api_key="am_xxx")
    result = await tools.send(to="alice.bob.local", body="你好")
"""

from imgou.integrations.base import AgentIMTools

__all__ = ["AgentIMTools"]
