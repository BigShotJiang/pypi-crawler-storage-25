"""本地消息缓存（SQLite）"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path


class MessageCache:
    """SQLite 本地消息缓存。

    负责：
    1. 消息历史持久化（断电/重启不丢）
    2. 按 thread 查询历史消息
    3. last_seq 持久化（替代 .agentim_seq_xxx 文件）
    4. 本地关键字搜索

    Args:
        db_path: 数据库文件路径。默认为 ~/.agentim/cache_{agent_id}.db。
        agent_id: Agent 标识，用于生成默认数据库路径。
    """

    def __init__(self, db_path: str | None = None, agent_id: str = "default") -> None:
        if db_path is None:
            cache_dir = Path.home() / ".agentim"
            cache_dir.mkdir(exist_ok=True)
            db_path = str(cache_dir / f"cache_{agent_id}.db")
        import threading
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_tables()

    def _init_tables(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                thread_id TEXT,
                from_id TEXT,
                to_id TEXT,
                body TEXT,
                format TEXT DEFAULT 'text',
                seq INTEGER,
                created_at TEXT,
                raw_json TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_msg_thread ON messages(thread_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_msg_seq ON messages(seq);

            CREATE TABLE IF NOT EXISTS kv (
                key TEXT PRIMARY KEY,
                value TEXT
            );
        """)
        self._conn.commit()

    def save_message(self, msg: dict) -> None:
        """保存一条消息（已存在则覆盖）。"""
        content = msg.get("content", {})
        if isinstance(content, dict):
            body = content.get("body", "")
            fmt = content.get("format", "text")
        else:
            body = str(content) if content else ""
            fmt = "text"

        with self._lock:
            self._conn.execute(
            """INSERT OR REPLACE INTO messages
               (id, thread_id, from_id, to_id, body, format, seq, created_at, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                str(msg.get("id", "")),
                str(msg.get("thread_id", "")),
                str(msg.get("from", msg.get("from_id", ""))),
                str(msg.get("to", msg.get("to_id", ""))),
                body,
                fmt,
                msg.get("seq"),
                str(msg.get("created_at", "")),
                json.dumps(msg, ensure_ascii=False),
            ),
        )
        self._conn.commit()

    def save_messages(self, messages: list[dict]) -> None:
        """批量保存消息（单次事务，比逐条 commit 更高效）。"""
        rows = []
        for msg in messages:
            content = msg.get("content", {})
            if isinstance(content, dict):
                body = content.get("body", "")
                fmt = content.get("format", "text")
            else:
                body = str(content) if content else ""
                fmt = "text"
            rows.append((
                str(msg.get("id", "")),
                str(msg.get("thread_id", "")),
                str(msg.get("from", msg.get("from_id", ""))),
                str(msg.get("to", msg.get("to_id", ""))),
                body,
                fmt,
                msg.get("seq"),
                str(msg.get("created_at", "")),
                json.dumps(msg, ensure_ascii=False),
            ))
        with self._lock:
            self._conn.executemany(
                """INSERT OR REPLACE INTO messages
                   (id, thread_id, from_id, to_id, body, format, seq, created_at, raw_json)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                rows,
            )
            self._conn.commit()

    def get_thread_messages(self, thread_id: str, limit: int = 50) -> list[dict]:
        """按时间正序返回某个 thread 的历史消息（最新 limit 条）。"""
        with self._lock:
            rows = self._conn.execute(
                "SELECT raw_json FROM messages WHERE thread_id = ? ORDER BY created_at DESC LIMIT ?",
                (thread_id, limit),
            ).fetchall()
        return [json.loads(r["raw_json"]) for r in reversed(rows)]

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        """按关键字搜索消息正文，结果按时间倒序。"""
        with self._lock:
            rows = self._conn.execute(
                "SELECT raw_json FROM messages WHERE body LIKE ? ORDER BY created_at DESC LIMIT ?",
                (f"%{keyword}%", limit),
            ).fetchall()
        return [json.loads(r["raw_json"]) for r in rows]

    def get_last_seq(self) -> int:
        """读取持久化的 last_seq，不存在时返回 0。"""
        with self._lock:
            row = self._conn.execute(
                "SELECT value FROM kv WHERE key = 'last_seq'"
            ).fetchone()
        return int(row["value"]) if row else 0

    def set_last_seq(self, seq: int) -> None:
        """持久化 last_seq。"""
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO kv (key, value) VALUES ('last_seq', ?)",
                (str(seq),),
            )
            self._conn.commit()

    def close(self) -> None:
        """关闭数据库连接。"""
        self._conn.close()
