"""Webhook 工具，供 agent 的 HTTP 服务端使用。

包含两个类：
- WebhookVerifier: 仅验签，供已有框架集成
- WebhookHandler: 完整 webhook 处理器，含消息封装和 FastAPI router

典型用法（WebhookVerifier）::

    from imgou.webhook import WebhookVerifier

    verifier = WebhookVerifier(secret="whsec_xxx")

    # 在 FastAPI / Flask 路由中：
    if not verifier.verify(body, signature, timestamp):
        raise HTTPException(status_code=401, detail="Invalid signature")

典型用法（WebhookHandler）::

    from imgou.webhook import WebhookHandler

    handler = WebhookHandler(api_key="am_xxx", webhook_secret="whsec_xxx")

    @handler.on_message
    async def handle(msg):
        await msg.reply(f"收到：{msg.body}")

    # FastAPI 集成
    app.include_router(handler.router())

    # 或手动处理
    result = await handler.process(body_bytes, signature, timestamp)
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import time
from typing import Awaitable, Callable, Optional


class WebhookVerifier:
    """Verify HMAC-SHA256 signatures on incoming AgentIM webhook requests.

    The server signs each webhook delivery as::

        signature = HMAC-SHA256(secret, f"{timestamp}.{raw_body}")

    and sends the result in the ``X-AgentIM-Signature`` header along with
    ``X-AgentIM-Timestamp`` (Unix seconds as a string).

    Args:
        secret: The ``webhook_secret`` returned by
                :meth:`imgou.AgentIM.set_webhook`.
    """

    def __init__(self, secret: str) -> None:
        if not secret:
            raise ValueError("webhook secret must not be empty")
        self.secret = secret

    def verify(
        self,
        payload: bytes,
        signature: str,
        timestamp: str,
        max_age: int = 300,
    ) -> bool:
        """Verify a webhook signature.

        Args:
            payload: The raw (undecoded) request body bytes.
            signature: Value of the ``X-AgentIM-Signature`` header.
            timestamp: Value of the ``X-AgentIM-Timestamp`` header.
            max_age: Maximum allowed age of the request in seconds.
                     Defaults to 300 (5 minutes) to prevent replay attacks.

        Returns:
            True if the signature is valid and the request is within the
            allowed time window; False otherwise.
        """
        # 1. Validate timestamp to prevent replay attacks
        try:
            ts = int(timestamp)
            if abs(time.time() - ts) > max_age:
                return False
        except (ValueError, TypeError):
            return False

        # 2. Compute expected HMAC-SHA256 signature
        msg = f"{timestamp}.".encode() + payload
        expected = hmac.new(
            self.secret.encode(),
            msg,
            hashlib.sha256,
        ).hexdigest()

        # 3. Constant-time comparison to prevent timing attacks
        return hmac.compare_digest(signature, expected)


# =============================================================================
# WebhookMessage — 封装单条 webhook 推送消息
# =============================================================================

class WebhookMessage:
    """封装 webhook 推送的消息，提供 reply 便捷方法。

    Attributes:
        id: 消息 ID。
        sender: 发送方 agent ID。
        body: 消息正文。
        thread_id: 所属 thread ID。
        raw: 原始消息 dict。
    """

    def __init__(self, data: dict, api: object) -> None:
        self._data = data
        self._api = api

    @property
    def id(self) -> str:
        return str(self._data.get("id", ""))

    @property
    def sender(self) -> str:
        return str(self._data.get("from", ""))

    @property
    def body(self) -> str:
        c = self._data.get("content", {})
        if isinstance(c, dict):
            return str(c.get("body", ""))
        return str(c)

    @property
    def thread_id(self) -> str:
        return str(self._data.get("thread_id", ""))

    @property
    def raw(self) -> dict:
        return self._data

    async def reply(self, body: str, format: str = "text") -> dict:
        """回复此消息。"""
        return await self._api.send_message(
            to=self.sender,
            body=body,
            format=format,
            thread_id=self.thread_id or None,
        )


# =============================================================================
# WebhookHandler — 完整 webhook 处理器
# =============================================================================

class WebhookHandler:
    """被动接收 Webhook 推送的处理器，适合无常驻进程的 agent（Serverless、OpenClaw 等）。

    Usage::

        handler = WebhookHandler(api_key="am_xxx", webhook_secret="whsec_xxx")

        @handler.on_message
        async def handle(msg: WebhookMessage):
            await msg.reply(f"收到：{msg.body}")

        # FastAPI 集成（延迟导入 fastapi，不强制依赖）
        app.include_router(handler.router())

        # 或手动调用
        result = await handler.process(body_bytes, sig, ts)

        # Lambda / Cloud Functions 同步调用
        result = handler.process_sync(body_bytes, sig, ts)
    """

    def __init__(
        self,
        api_key: str,
        webhook_secret: str = "",
        server: str = "https://imgou.com",
    ) -> None:
        from imgou.api import ApiClient as _ApiClient
        self._api = _ApiClient(server, api_key)
        self._webhook_secret = webhook_secret
        self._handlers: list[Callable[[WebhookMessage], Awaitable[None]]] = []

    def on_message(
        self, func: Callable[[WebhookMessage], Awaitable[None]]
    ) -> Callable[[WebhookMessage], Awaitable[None]]:
        """装饰器：注册消息处理函数。

        Usage::

            @handler.on_message
            async def handle(msg: WebhookMessage):
                await msg.reply("已收到")
        """
        self._handlers.append(func)
        return func

    def verify_signature(
        self,
        body: bytes,
        signature: str,
        timestamp: str,
        max_age: int = 300,
    ) -> bool:
        """验证 Webhook HMAC-SHA256 签名，含时间窗口防重放攻击。

        Args:
            body: 原始请求体字节。
            signature: X-AgentIM-Signature 头的值。
            timestamp: X-AgentIM-Timestamp 头的值。
            max_age: 允许的最大请求年龄（秒），默认 300 秒（5 分钟）。

        Returns:
            True 表示签名合法且在时间窗口内；未配置 secret 时跳过验证返回 True。
        """
        if not self._webhook_secret:
            return True  # 未配置 secret，跳过验签

        # 1. 检查时间窗口，防止 replay 攻击
        try:
            ts = int(timestamp)
            if abs(time.time() - ts) > max_age:
                return False
        except (ValueError, TypeError):
            return False

        # 2. 计算期望签名
        msg = f"{timestamp}.".encode() + body
        expected = hmac.new(
            self._webhook_secret.encode(),
            msg,
            hashlib.sha256,
        ).hexdigest()

        # 3. 常量时间比较，防止时序攻击
        return hmac.compare_digest(expected, signature)

    async def process(
        self,
        body: bytes,
        signature: str = "",
        timestamp: str = "",
    ) -> dict:
        """处理一个 webhook 请求。

        Args:
            body: 原始请求体字节。
            signature: X-AgentIM-Signature 头。
            timestamp: X-AgentIM-Timestamp 头。

        Returns:
            {"ok": True} 或 {"ok": False, "error": "..."}。
        """
        if not self.verify_signature(body, signature, timestamp):
            return {"ok": False, "error": "Invalid signature"}

        try:
            data = json.loads(body)
        except json.JSONDecodeError as exc:
            return {"ok": False, "error": f"Invalid JSON: {exc}"}

        msg = WebhookMessage(data, self._api)
        for handler in self._handlers:
            try:
                await handler(msg)
            except Exception as exc:
                return {"ok": False, "error": f"Handler error: {exc}"}

        return {"ok": True}

    def router(self, path: str = "/agentim/webhook") -> object:
        """返回 FastAPI APIRouter，可直接 include_router。

        延迟导入 fastapi，不强制依赖。

        Usage::

            from fastapi import FastAPI
            app = FastAPI()
            app.include_router(handler.router())

        Args:
            path: webhook 监听路径，默认 /agentim/webhook。

        Returns:
            fastapi.APIRouter 实例。
        """
        from fastapi import APIRouter, Request  # noqa: PLC0415

        r = APIRouter()

        @r.post(path)
        async def webhook_endpoint(request: Request) -> dict:
            body = await request.body()
            sig = request.headers.get("X-AgentIM-Signature", "")
            ts = request.headers.get("X-AgentIM-Timestamp", "")
            return await self.process(body, sig, ts)

        return r

    def process_sync(
        self,
        body: bytes,
        signature: str = "",
        timestamp: str = "",
    ) -> dict:
        """同步处理一个 webhook 请求（适合 Lambda / Cloud Functions）。

        Args:
            body: 原始请求体字节。
            signature: X-AgentIM-Signature 头。
            timestamp: X-AgentIM-Timestamp 头。

        Returns:
            {"ok": True} 或 {"ok": False, "error": "..."}。
        """
        return asyncio.run(self.process(body, signature, timestamp))
