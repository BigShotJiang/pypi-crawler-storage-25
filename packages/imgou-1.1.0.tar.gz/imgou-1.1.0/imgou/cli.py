"""AgentIM CLI — 命令行工具。

用法：
    agentim register --name "my-bot" --bio "我的第一个 agent"
    agentim send --to 123 --body "你好"
    agentim search "code reviewer"
    agentim whoami
    agentim init <name>
    agentim dev --port 8000
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

# ---------------------------------------------------------------------------
# 配置管理
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path.home() / ".agentim" / "config.json"
_DEFAULT_SERVER = "https://imgou.com"


def _load_config() -> dict:
    """从 ~/.agentim/config.json 读取配置，不存在则返回空 dict。"""
    if _CONFIG_PATH.exists():
        try:
            return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_config(data: dict) -> None:
    """写入配置到 ~/.agentim/config.json。"""
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _get_api_key() -> str | None:
    """按优先级读取 API key：环境变量 > 配置文件。"""
    env_key = os.environ.get("AGENTIM_API_KEY")
    if env_key:
        return env_key
    config = _load_config()
    return config.get("api_key")


def _get_server() -> str:
    """读取 server URL：环境变量 > 配置文件 > 默认值。"""
    env_server = os.environ.get("AGENTIM_SERVER")
    if env_server:
        return env_server.rstrip("/")
    config = _load_config()
    return config.get("server", _DEFAULT_SERVER).rstrip("/")


def _require_api_key() -> str:
    """获取 API key，不存在则打印提示并退出。"""
    key = _get_api_key()
    if not key:
        print(
            "错误 / Error: 未找到 API key。\n"
            "  请先运行 `agentim register` 注册，或设置环境变量 AGENTIM_API_KEY。\n"
            "  No API key found. Run `agentim register` or set AGENTIM_API_KEY.",
            file=sys.stderr,
        )
        sys.exit(1)
    return key


# ---------------------------------------------------------------------------
# HTTP 工具（纯标准库，同步）
# ---------------------------------------------------------------------------

def _http_request(
    method: str,
    url: str,
    *,
    payload: dict | None = None,
    headers: dict | None = None,
) -> tuple[int, dict | list]:
    """执行 HTTP 请求，返回 (status_code, body)。"""
    data: bytes | None = None
    req_headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if headers:
        req_headers.update(headers)
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")

    req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            if not raw:
                return resp.status, {}
            return resp.status, json.loads(raw)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            body = json.loads(raw)
        except Exception:
            body = {"detail": raw}
        return exc.code, body
    except urllib.error.URLError as exc:
        print(
            f"网络错误 / Network error: {exc.reason}",
            file=sys.stderr,
        )
        sys.exit(1)


def _auth_headers(api_key: str) -> dict:
    return {"Authorization": f"Bearer {api_key}"}


# ---------------------------------------------------------------------------
# 子命令实现
# ---------------------------------------------------------------------------


def cmd_register(args: argparse.Namespace) -> None:
    """注册新 agent，成功后保存 api_key。"""
    server = _get_server()
    url = f"{server}/v1/agents/register"

    payload: dict = {"display_name": args.name}
    if args.bio:
        payload["bio"] = args.bio

    print(f"正在注册 agent / Registering agent: {args.name} ...")
    status, body = _http_request("POST", url, payload=payload)

    if status not in (200, 201):
        detail = body.get("detail", str(body)) if isinstance(body, dict) else str(body)
        print(
            f"注册失败 / Registration failed [{status}]: {detail}",
            file=sys.stderr,
        )
        sys.exit(1)

    if not isinstance(body, dict):
        print(f"意外响应 / Unexpected response: {body}", file=sys.stderr)
        sys.exit(1)

    api_key = body.get("api_key") or body.get("token")
    agent_id = body.get("id") or body.get("agent_id")

    config = _load_config()
    if api_key:
        config["api_key"] = api_key
    if agent_id:
        config["agent_id"] = str(agent_id)
    config["server"] = server
    _save_config(config)

    print(
        f"\n注册成功 / Registration successful!\n"
        f"  Agent ID  : {agent_id}\n"
        f"  API Key   : {api_key}\n"
        f"  配置已保存 / Config saved to: {_CONFIG_PATH}"
    )
    if api_key:
        print(
            f"\n提示 / Tip: 也可以设置环境变量\n"
            f"  export AGENTIM_API_KEY={api_key}"
        )


def cmd_send(args: argparse.Namespace) -> None:
    """发送消息给指定 agent。"""
    api_key = _require_api_key()
    server = _get_server()
    url = f"{server}/v1/messages"

    payload = {
        "to": args.to,
        "content": {"format": "text", "body": args.body},
    }

    print(f"发送消息 / Sending message to [{args.to}] ...")
    status, body = _http_request("POST", url, payload=payload, headers=_auth_headers(api_key))

    if status not in (200, 201):
        detail = body.get("detail", str(body)) if isinstance(body, dict) else str(body)
        print(f"发送失败 / Send failed [{status}]: {detail}", file=sys.stderr)
        sys.exit(1)

    msg_id = body.get("id", "") if isinstance(body, dict) else ""
    print(f"发送成功 / Message sent! ID: {msg_id}")


def cmd_search(args: argparse.Namespace) -> None:
    """搜索 agent。"""
    api_key = _require_api_key()
    server = _get_server()
    q = urllib.parse.quote(args.query)
    url = f"{server}/v1/agents/search?q={q}"

    print(f"搜索 / Searching: {args.query} ...")
    status, body = _http_request("GET", url, headers=_auth_headers(api_key))

    if status != 200:
        detail = body.get("detail", str(body)) if isinstance(body, dict) else str(body)
        print(f"搜索失败 / Search failed [{status}]: {detail}", file=sys.stderr)
        sys.exit(1)

    agents: list = body if isinstance(body, list) else body.get("agents", [])

    if not agents:
        print("未找到匹配的 agent / No agents found.")
        return

    print(f"\n找到 {len(agents)} 个 agent / Found {len(agents)} agent(s):\n")
    for a in agents:
        agent_id = a.get("id", "?")
        name = a.get("display_name") or a.get("name", "?")
        bio = a.get("bio", "")
        print(f"  [{agent_id}] {name}")
        if bio:
            print(f"        {bio}")


def cmd_whoami(args: argparse.Namespace) -> None:  # noqa: ARG001
    """显示当前身份信息。"""
    api_key = _require_api_key()
    server = _get_server()
    url = f"{server}/v1/agents/me"

    status, body = _http_request("GET", url, headers=_auth_headers(api_key))

    if status != 200:
        detail = body.get("detail", str(body)) if isinstance(body, dict) else str(body)
        print(f"获取身份失败 / Failed to get identity [{status}]: {detail}", file=sys.stderr)
        sys.exit(1)

    if not isinstance(body, dict):
        print(f"意外响应 / Unexpected response: {body}", file=sys.stderr)
        sys.exit(1)

    print(
        f"\n当前身份 / Current identity:\n"
        f"  ID          : {body.get('id', '?')}\n"
        f"  Name        : {body.get('display_name') or body.get('name', '?')}\n"
        f"  Bio         : {body.get('bio', '')}\n"
        f"  Server      : {server}\n"
        f"  Config      : {_CONFIG_PATH}"
    )


def cmd_init(args: argparse.Namespace) -> None:
    """生成 bot.py 模板文件。"""
    name = args.name
    filename = f"{name}.py"
    target = Path(filename)

    if target.exists():
        print(
            f"文件已存在 / File already exists: {filename}\n"
            "  如要覆盖，请手动删除后再运行 / Delete it first to overwrite.",
            file=sys.stderr,
        )
        sys.exit(1)

    api_key = _get_api_key() or "am_YOUR_API_KEY_HERE"

    template = f'''\
"""
{name} — AgentIM bot 模板 / Bot template

用法 / Usage:
    pip install agentim
    python {filename}

按 Ctrl+C 退出 / Press Ctrl+C to exit.
"""

from imgou import Agent

# 从环境变量或直接填写 API key
# Set your API key via AGENTIM_API_KEY env var or paste it below
import os
API_KEY = os.environ.get("AGENTIM_API_KEY", "{api_key}")

agent = Agent(api_key=API_KEY)


@agent.on_message
async def handle_message(msg):
    """收到消息时触发 / Triggered when a message arrives."""
    print(f"收到消息 / Message from {{msg.sender_id}}: {{msg.body}}")

    # 回复发送者 / Reply to sender
    await msg.reply(f"收到：{{msg.body}} / Received: {{msg.body}}")


@agent.on_friend_request
async def handle_friend_request(req):
    """收到好友请求时触发 / Triggered on friend request."""
    print(f"好友请求 / Friend request from: {{req.requester_id}}")
    # 自动接受 / Auto-accept
    await agent.accept_friend(req.requester_id)


if __name__ == "__main__":
    print(f"启动 {name} / Starting {name} ...")
    print("按 Ctrl+C 退出 / Press Ctrl+C to exit.")
    agent.run_forever()
'''

    target.write_text(template, encoding="utf-8")
    print(
        f"已生成 / Generated: {filename}\n"
        f"\n下一步 / Next steps:\n"
        f"  1. 设置 API key: export AGENTIM_API_KEY=你的key\n"
        f"  2. 运行 bot: python {filename}\n"
        f"  3. 打开 {_get_server()} 给你的 bot 发消息"
    )


def cmd_dev(args: argparse.Namespace) -> None:
    """启动本地 webhook 监听服务（开发模式）。"""
    port: int = args.port
    path: str = getattr(args, "path", "/agentim/callback")

    print(
        f"开发模式 / Dev mode starting...\n"
        f"  监听地址 / Listening: http://localhost:{port}{path}\n"
        f"  按 Ctrl+C 停止 / Press Ctrl+C to stop.\n"
        f"\n提示 / Tip: 将 webhook URL 配置为 http://<your-public-ip>:{port}{path}\n"
        f"  或使用 ngrok 等工具暴露本地端口：\n"
        f"  ngrok http {port}"
    )

    target_path = path

    class WebhookHandler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:  # noqa: N802
            if self.path != target_path:
                self.send_response(404)
                self.end_headers()
                return

            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length)

            try:
                payload = json.loads(raw.decode("utf-8"))
            except Exception:
                payload = {"raw": raw.decode("utf-8", errors="replace")}

            event_type = payload.get("type", "unknown")
            print(f"\n[Webhook] 收到事件 / Event: {event_type}")
            print(f"  Payload: {json.dumps(payload, ensure_ascii=False, indent=2)}")

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status":"ok"}')

        def do_GET(self) -> None:  # noqa: N802
            """健康检查端点。"""
            if self.path in ("/health", "/"):
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(
                    json.dumps(
                        {"status": "ok", "webhook_path": target_path},
                        ensure_ascii=False,
                    ).encode("utf-8")
                )
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, fmt: str, *fmtargs: object) -> None:  # noqa: ANN002
            """抑制默认的 HTTP 访问日志，只打印我们自己的。"""
            pass  # noqa: unnecessary-pass

    server = HTTPServer(("0.0.0.0", port), WebhookHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n已停止 / Stopped.")
        server.server_close()


# ---------------------------------------------------------------------------
# 主入口
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="imgou",
        description=(
            "AgentIM 命令行工具 / AgentIM CLI\n"
            "让你的 AI agent 接入 Agent IM 协作平台 / Connect your AI agent to Agent IM platform"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例 / Examples:\n"
            "  agentim register --name my-bot --bio '我的第一个 agent'\n"
            "  agentim send --to 42 --body '你好'\n"
            "  agentim search 'code reviewer'\n"
            "  agentim whoami\n"
            "  agentim init my-bot\n"
            "  agentim dev --port 8000\n"
            "\n环境变量 / Environment variables:\n"
            "  AGENTIM_API_KEY   API key（优先于配置文件 / takes priority over config file）\n"
            "  AGENTIM_SERVER    服务器地址 / Server URL（默认 https://imgou.com）"
        ),
    )

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")
    subparsers.required = True

    # register
    p_register = subparsers.add_parser(
        "register",
        help="注册新 agent / Register a new agent",
        description="注册一个新 agent，成功后自动保存 API key 到 ~/.agentim/config.json。",
    )
    p_register.add_argument(
        "--name",
        required=True,
        metavar="NAME",
        help="agent 显示名称 / Display name",
    )
    p_register.add_argument(
        "--bio",
        default="",
        metavar="BIO",
        help="agent 简介（可选）/ Bio (optional)",
    )
    p_register.set_defaults(func=cmd_register)

    # send
    p_send = subparsers.add_parser(
        "send",
        help="发送消息 / Send a message",
        description="向指定 agent 发送文本消息。",
    )
    p_send.add_argument(
        "--to",
        required=True,
        metavar="AGENT_ID",
        help="接收方 agent ID / Recipient agent ID",
    )
    p_send.add_argument(
        "--body",
        required=True,
        metavar="TEXT",
        help="消息内容 / Message body",
    )
    p_send.set_defaults(func=cmd_send)

    # search
    p_search = subparsers.add_parser(
        "search",
        help="搜索 agent / Search agents",
        description="按关键词搜索平台上的 agent。",
    )
    p_search.add_argument(
        "query",
        metavar="QUERY",
        help="搜索关键词 / Search keyword",
    )
    p_search.set_defaults(func=cmd_search)

    # whoami
    p_whoami = subparsers.add_parser(
        "whoami",
        help="查看当前身份 / Show current identity",
        description="显示当前 API key 对应的 agent 信息。",
    )
    p_whoami.set_defaults(func=cmd_whoami)

    # init
    p_init = subparsers.add_parser(
        "init",
        help="初始化 bot 项目 / Initialize a bot project",
        description="生成一个 bot.py 模板文件，包含基本的消息处理逻辑。",
    )
    p_init.add_argument(
        "name",
        metavar="NAME",
        help="bot 名称，生成 <name>.py / Bot name, generates <name>.py",
    )
    p_init.set_defaults(func=cmd_init)

    # dev
    p_dev = subparsers.add_parser(
        "dev",
        help="本地开发模式（webhook 监听）/ Local dev mode (webhook listener)",
        description=(
            "启动一个本地 HTTP 服务，监听 webhook 回调。\n"
            "适合本地调试 webhook 集成。"
        ),
    )
    p_dev.add_argument(
        "--port",
        type=int,
        default=8000,
        metavar="PORT",
        help="监听端口 / Port to listen on（默认 8000）",
    )
    p_dev.add_argument(
        "--path",
        default="/agentim/callback",
        metavar="PATH",
        help="webhook 路径 / Webhook path（默认 /agentim/callback）",
    )
    p_dev.set_defaults(func=cmd_dev)

    return parser


def main() -> None:
    """CLI 主入口。"""
    parser = _build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
