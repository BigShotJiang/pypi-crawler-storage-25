"""AgentIM SDK — 连接管理器。

连接优先级：WebSocket > 长轮询（HTTP）。
指数退避策略防止失败时频繁重试。
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, AsyncIterator

from imgou.exceptions import AgentIMError, AuthError
from imgou.exceptions import ConnectionError as AgentIMConnectionError

if TYPE_CHECKING:
    from imgou.api import ApiClient

logger = logging.getLogger("imgou.connection")

# 尝试导入 websockets
try:
    import websockets
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False


class WebSocketConnection:
    """基于 WebSocket 的实时连接，自动重连 + 指数退避。"""

    def __init__(self, api: "ApiClient", poll_timeout: int = 30) -> None:
        self._api = api
        self._poll_timeout = poll_timeout
        self._retry_delay = 1.0
        self._max_delay = 60.0
        self._connected = False

        # 连接状态回调（由 Agent 层注入）
        self._on_connect_cb = None
        self._on_disconnect_cb = None

    def set_on_connect(self, cb) -> None:
        self._on_connect_cb = cb

    def set_on_disconnect(self, cb) -> None:
        self._on_disconnect_cb = cb

    def _ws_url(self) -> str:
        """从 HTTP URL 推导 WebSocket URL。"""
        server = self._api._server
        ws = server.replace("https://", "wss://").replace("http://", "ws://")
        return f"{ws}/v1/ws"

    async def _fire_connect(self) -> None:
        if self._on_connect_cb:
            try:
                await self._on_connect_cb()
            except Exception as exc:
                logger.warning("on_connect 回调出错: %s", exc)

    async def _fire_disconnect(self) -> None:
        if self._on_disconnect_cb:
            try:
                await self._on_disconnect_cb()
            except Exception as exc:
                logger.warning("on_disconnect 回调出错: %s", exc)

    async def messages(self) -> AsyncIterator[list[dict]]:
        """异步生成器：每次 yield 一批消息（来自 WebSocket 推送）。"""
        while True:
            try:
                url = self._ws_url()
                async with websockets.connect(
                    url, ping_interval=30, ping_timeout=10,
                    close_timeout=5, open_timeout=10,
                    additional_headers={"Authorization": f"Bearer {self._api._api_key}"},
                ) as ws:
                    self._connected = True
                    self._retry_delay = 1.0  # 重置退避
                    logger.info("WebSocket 已连接")
                    await self._fire_connect()

                    async for raw in ws:
                        try:
                            data = json.loads(raw)
                        except json.JSONDecodeError:
                            continue

                        msg_type = data.get("type")
                        if msg_type == "msg":
                            # 实时消息推送
                            message = data.get("data", {}).get("message")
                            if message:
                                yield [message]
                        elif msg_type == "notifications":
                            # 连接时的通知摘要，不作为消息处理
                            logger.info("收到通知摘要: %s", data.get("data", {}))

            except Exception as e:
                was_connected = self._connected
                self._connected = False
                logger.warning("WebSocket 断开: %s, %.1fs 后重连...", e, self._retry_delay)
                if was_connected:
                    await self._fire_disconnect()
                await asyncio.sleep(self._retry_delay)
                self._retry_delay = min(self._retry_delay * 2, self._max_delay)


class LongPollConnection:
    """基于 HTTP 长轮询的持续连接（WebSocket 不可用时的 fallback）。"""

    def __init__(self, api: "ApiClient", poll_timeout: int = 30) -> None:
        self._api = api
        self._poll_timeout = poll_timeout
        self._retry_delay = 1.0
        self._max_delay = 60.0

        # 连接状态回调（由 Agent 层注入）
        self._on_connect_cb = None
        self._on_disconnect_cb = None

    def set_on_connect(self, cb) -> None:
        self._on_connect_cb = cb

    def set_on_disconnect(self, cb) -> None:
        self._on_disconnect_cb = cb

    async def messages(self) -> AsyncIterator[list[dict]]:
        """异步生成器：每次 yield 一批消息。"""
        while True:
            try:
                msgs = await self._api.poll_messages(timeout=self._poll_timeout)
                self._retry_delay = 1.0  # 重置退避
                if msgs:
                    yield msgs
            except AuthError:
                raise
            except AgentIMError as exc:
                logger.warning("轮询出错: %s, %.1fs 后重试...", exc, self._retry_delay)
                await asyncio.sleep(self._retry_delay)
                self._retry_delay = min(self._retry_delay * 2, self._max_delay)
            except Exception as exc:
                logger.warning("轮询异常: %s, %.1fs 后重试...", exc, self._retry_delay)
                await asyncio.sleep(self._retry_delay)
                self._retry_delay = min(self._retry_delay * 2, self._max_delay)


def create_connection(api: "ApiClient", poll_timeout: int = 30):
    """创建连接：WebSocket 优先，不可用时降级到长轮询。

    优先级说明：
    1. WebSocket（需要 websockets 库）— 实时推送，标准协议
    2. 长轮询 — 无额外依赖，兼容性最佳
    """
    if HAS_WEBSOCKETS:
        logger.info("[AgentIM] 使用 WebSocket 连接（实时推送）")
        return WebSocketConnection(api, poll_timeout)

    logger.info(
        "[AgentIM] 使用长轮询（pip install websockets 可启用 WebSocket）"
    )
    return LongPollConnection(api, poll_timeout)
