"""AgentIM SDK — 异常定义。

每个异常类携带：
  - code  : 唯一错误码，便于程序化处理
  - hint  : 用户友好的修复建议
  - status_code : HTTP 状态码（可选）
  - response    : 服务器原始响应（可选）
"""

from __future__ import annotations


class AgentIMError(Exception):
    """AgentIM API 调用失败时抛出的基类异常。

    Attributes:
        code: 唯一错误码字符串，格式 AGENTIM_<DOMAIN>_<NNN>。
        hint: 面向开发者的修复建议（中英双语）。
        status_code: HTTP 状态码（非 HTTP 错误时为 None）。
        response: 服务器返回的原始 JSON 响应体。
    """

    code: str = "AGENTIM_GENERAL_001"
    hint: str = (
        "请检查服务器地址和网络连接是否正常。\n"
        "Please check the server URL and network connectivity."
    )

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response or {}

    def __str__(self) -> str:
        base = super().__str__()
        return f"[{self.code}] {base}"


class AuthError(AgentIMError):
    """API key 无效、已过期或权限不足。"""

    code = "AGENTIM_AUTH_001"
    hint = (
        "请检查 AGENTIM_API_KEY 环境变量或 ~/.agentim/config.json 中的 api_key 是否正确。\n"
        "如果 key 已过期，请到 https://imgou.com 重新生成。\n"
        "Check your AGENTIM_API_KEY or api_key in ~/.agentim/config.json. "
        "If expired, regenerate it at https://imgou.com."
    )


class ConnectionError(AgentIMError):
    """无法连接到 AgentIM 服务器，或连接中断。"""

    code = "AGENTIM_CONN_001"
    hint = (
        "请检查：\n"
        "  1. 网络是否正常（能否访问 https://imgou.com）\n"
        "  2. AGENTIM_SERVER 环境变量是否设置正确\n"
        "  3. 防火墙/代理是否阻断了连接\n"
        "Troubleshooting:\n"
        "  1. Check network access to https://imgou.com\n"
        "  2. Verify AGENTIM_SERVER env var\n"
        "  3. Check firewall / proxy settings"
    )


class NotFoundError(AgentIMError):
    """请求的资源不存在（404）。"""

    code = "AGENTIM_NOT_FOUND_001"
    hint = (
        "请确认 agent ID 或资源 ID 是否正确。\n"
        "可以用 `agentim search <keyword>` 查找有效的 agent ID。\n"
        "Verify the agent ID or resource ID. "
        "Use `agentim search <keyword>` to find valid agent IDs."
    )


class RequestTimeout(AgentIMError):
    """request() 等待回复超时。

    对方 agent 在指定 timeout 时间内没有返回响应。
    """

    code = "AGENTIM_TIMEOUT_001"
    hint = (
        "对方 agent 未在超时时间内回复。可以：\n"
        "  1. 增大 timeout 参数（默认 30s）\n"
        "  2. 确认对方 agent 是否在线且能正常处理请求\n"
        "  3. 检查对方 agent 的处理逻辑是否有异常\n"
        "The remote agent did not reply in time. Options:\n"
        "  1. Increase the timeout parameter (default 30s)\n"
        "  2. Verify the remote agent is online and healthy\n"
        "  3. Check the remote agent's message handler for errors"
    )


class RateLimitError(AgentIMError):
    """请求频率超过限制（429）。"""

    code = "AGENTIM_RATE_LIMIT_001"
    hint = (
        "请求过于频繁，请稍后再试。\n"
        "建议在发送循环中加入适当延迟（如 asyncio.sleep(1)）。\n"
        "Too many requests. Please retry after a short delay. "
        "Consider adding asyncio.sleep(1) between sends."
    )


class ServerError(AgentIMError):
    """服务器内部错误（5xx）。"""

    code = "AGENTIM_SERVER_001"
    hint = (
        "服务器出现内部错误，请稍后重试。\n"
        "如果错误持续，请到 https://imgou.com 查看服务状态或联系支持。\n"
        "Server error. Please retry later. "
        "If the issue persists, check https://imgou.com/status or contact support."
    )


class MessageFormatError(AgentIMError):
    """消息格式不合法。"""

    code = "AGENTIM_FORMAT_001"
    hint = (
        "消息内容格式有误。\n"
        "  - text / markdown：body 为字符串\n"
        "  - json：body 为可序列化的 dict 或 list\n"
        "Invalid message format. "
        "Use str for text/markdown, and a serializable dict/list for json format."
    )
