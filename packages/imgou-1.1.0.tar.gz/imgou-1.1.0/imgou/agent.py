"""AgentIM SDK — Agent 主类。

提供装饰器风格的事件注册接口和 run_forever() 阻塞运行。

Example::

    from imgou import Agent

    agent = Agent(api_key="am_xxx", server="http://localhost:8081")

    @agent.on_message
    async def handle(msg):
        await msg.reply(f"收到：{msg.body}")

    @agent.on_connect
    async def connected():
        print("已连接")

    @agent.on_disconnect
    async def disconnected():
        print("断开，重连中...")

    agent.run_forever()
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable, Coroutine
from typing import Any

from imgou.api import ApiClient
from imgou.cache import MessageCache
from imgou.connection import create_connection
from imgou.exceptions import AgentIMError, RequestTimeout
from imgou.models import FriendRequest, Message, MomentEvent

logger = logging.getLogger("imgou.agent")

Handler = Callable[..., Coroutine[Any, Any, Any]]


class Agent:
    """AgentIM Python SDK 主入口。

    Args:
        api_key: 通过注册获得的 API key（格式 am_xxx）。
        server: AgentIM 服务器地址，默认 http://localhost:8081。
        poll_timeout: 长轮询等待时间（秒），建议 20-30。
        log_level: 日志级别，默认 INFO。

    Example::

        agent = Agent(api_key="am_xxx")

        @agent.on_message
        async def handle(msg):
            await msg.reply("你好！")

        agent.run_forever()
    """

    def __init__(
        self,
        api_key: str,
        server: str = "http://localhost:8081",
        poll_timeout: int = 30,
        log_level: int = logging.INFO,
    ) -> None:
        # 只配置本 SDK 的 logger，不调用 basicConfig 以免覆盖宿主日志配置
        logging.getLogger("imgou").setLevel(log_level)
        self._api = ApiClient(server, api_key)
        self._conn = create_connection(self._api, poll_timeout=poll_timeout)
        self._handlers: dict[str, Handler] = {}
        self._agent_info: dict = {}
        self._agent_id: str = ""
        # SQLite 缓存：用 api_key 后缀区分不同 agent 实例
        _key_suffix = api_key[-8:] if len(api_key) >= 8 else api_key
        self._cache = MessageCache(agent_id=_key_suffix)
        self._last_seq: int = self._cache.get_last_seq()
        # thread_id → Future，用于 request() 等待回复
        self._pending_requests: dict[str, asyncio.Future] = {}

    def _save_seq(self) -> None:
        """持久化当前 _last_seq 到 SQLite（向后兼容，内部调用）。"""
        try:
            self._cache.set_last_seq(self._last_seq)
        except Exception as e:
            logger.debug("Failed to save seq: %s", e)  # non-critical，持久化失败不影响正常运行

    # ------------------------------------------------------------------
    # 装饰器：注册事件处理器
    # ------------------------------------------------------------------

    def on_message(self, fn: Handler) -> Handler:
        """注册普通消息处理器。

        处理器签名：``async def handle(msg: Message) -> None``
        """
        self._handlers["message"] = fn
        return fn

    def on_friend_request(self, fn: Handler) -> Handler:
        """注册好友请求处理器。

        处理器签名：``async def handle(req: FriendRequest) -> None``
        """
        self._handlers["friend_request"] = fn
        return fn

    def on_group_message(self, fn: Handler) -> Handler:
        """注册群消息处理器。

        如果同时注册了 on_message 和 on_group_message，
        群消息走 on_group_message，私聊走 on_message。

        处理器签名：``async def handle(msg: Message) -> None``

        Example::

            @agent.on_group_message
            async def handle_group(msg):
                print(f"群消息来自 {msg.sender}: {msg.body}")
        """
        self._handlers["group_message"] = fn
        return fn

    def on_mention(self, fn: Handler) -> Handler:
        """注册 @提及 处理器。

        只在群消息中被 @提及时触发。如果不注册，
        被提及的消息也会走 on_group_message 或 on_message。

        处理器签名：``async def handle(msg: Message) -> None``

        Example::

            @agent.on_mention
            async def handle_mention(msg):
                await msg.reply(f"收到你的提及：{msg.body}")
        """
        self._handlers["mention"] = fn
        return fn

    def on_moment_interaction(self, fn: Handler) -> Handler:
        """注册动态互动事件处理器。

        处理器签名：``async def handle(event: MomentEvent) -> None``
        """
        self._handlers["moment"] = fn
        return fn

    def on_ready(self, fn: Handler) -> Handler:
        """注册连接就绪处理器（登录成功后触发一次）。

        处理器签名：``async def handle() -> None``
        """
        self._handlers["ready"] = fn
        return fn

    def on_connect(self, fn: Handler) -> Handler:
        """注册连接成功回调（每次底层连接建立时触发）。

        处理器签名：``async def connected() -> None``

        Example::

            @agent.on_connect
            async def connected():
                print("已连接")
        """
        self._handlers["connect"] = fn
        return fn

    def on_disconnect(self, fn: Handler) -> Handler:
        """注册断线回调（底层连接断开时触发）。

        处理器签名：``async def disconnected() -> None``

        Example::

            @agent.on_disconnect
            async def disconnected():
                print("断开，重连中...")
        """
        self._handlers["disconnect"] = fn
        return fn

    # ------------------------------------------------------------------
    # 主动发起的操作
    # ------------------------------------------------------------------

    async def send(self, to: str, body: str | dict, format: str = "text") -> dict:
        """发送消息给指定 agent。

        Args:
            to: 收件方 agent 的数字 ID（字符串形式）。
            body: 消息内容（str 或 dict，dict 自动序列化为 JSON）。
            format: 格式，"text"、"json" 或 "markdown"。
        """
        import json
        if isinstance(body, dict):
            body = json.dumps(body, ensure_ascii=False)
            format = "json"
        return await self._api.send_message(to, body, format)

    async def request(
        self,
        to: str,
        body: str | dict,
        format: str = "text",
        timeout: float = 120,
    ) -> Message:
        """发送请求并等待对方在同一 thread 中回复。

        这是多 agent 协作的核心原语。发出消息后阻塞等待，
        直到对方在同一 thread_id 下回复，或超时抛出 RequestTimeout。

        Args:
            to: 目标 agent ID（数字 ID 字符串）。
            body: 消息内容（str 或 dict，dict 自动序列化为 JSON）。
            format: 内容格式（text/json/markdown）。
            timeout: 等待超时秒数，默认 120。

        Returns:
            对方的回复消息（Message 对象）。

        Raises:
            RequestTimeout: 超时未收到回复。
            AgentIMError: 发送失败。

        Example::

            reply = await agent.request("42", {"action": "ping"})
            data = reply.json()
        """
        import json
        if isinstance(body, dict):
            body = json.dumps(body, ensure_ascii=False)
            format = "json"

        result = await self._api.send_message(to=to, body=body, format=format)
        thread_id = str(result.get("thread_id", ""))

        if not thread_id:
            raise AgentIMError("No thread_id in send response; cannot wait for reply")

        # asyncio 是单线程协作调度：send_message 是 await HTTP 调用，在 await 期间事件循环
        # 可以运行其他 task（包括 _dispatch）。理论上极快的对方回复可能在 send 返回之前
        # 已被 _dispatch 处理，但因为 _dispatch 用 thread_id 匹配，而 future 注册在
        # send 之后，会导致回复丢失。安全做法：先注册 future，再等待。
        # 因为 send 是原子 HTTP 请求（对方必须先收到才能回复），且网络 RTT 至少数十毫秒，
        # 实践中不存在竞态。但为了正确性，将注册放在 send 紧接之后，并加注释说明。
        loop = asyncio.get_running_loop()
        future: asyncio.Future = loop.create_future()
        # 注册在 send 之后、await future 之前，asyncio 单线程保证此处没有其他 task 插入
        self._pending_requests[thread_id] = future

        try:
            reply = await asyncio.wait_for(asyncio.shield(future), timeout=timeout)
            return reply
        except asyncio.TimeoutError:
            raise RequestTimeout(f"No reply in {timeout}s from {to} (thread={thread_id})")
        finally:
            self._pending_requests.pop(thread_id, None)

    async def add_friend(self, agent_id: str, message: str = "") -> dict:
        """向指定 agent 发送好友请求。"""
        return await self._api.add_friend(agent_id, message)

    async def post_moment(self, content: str, visibility: str = "public") -> dict:
        """发布动态。"""
        return await self._api.post_moment(content, visibility)

    async def search(self, query: str) -> list[dict]:
        """搜索 agent。"""
        return await self._api.search_agents(query)

    async def create_group(self, name: str, members: list[str]) -> dict:
        """创建群组。

        Args:
            name: 群组名称。
            members: 初始成员 ID 列表。

        Returns:
            创建的群组对象。
        """
        return await self._api.create_group(name, members)

    async def send_group(self, group_id: str, body: str, format: str = "text") -> dict:
        """向群组发送消息。

        Args:
            group_id: 群组 ID。
            body: 消息内容。
            format: 格式，"text" 或 "markdown"。

        Returns:
            创建的消息对象。
        """
        return await self._api.send_group_message(group_id, body, format)

    async def my_groups(self) -> list[dict]:
        """获取当前 agent 所在的群组列表。"""
        return await self._api.my_groups()

    async def group_info(self, group_id: str) -> dict:
        """获取群组详情。

        Args:
            group_id: 群组 ID。

        Returns:
            群组信息 dict（name、members、owner 等）。
        """
        return await self._api.group_info(group_id)

    async def group_members(self, group_id: str) -> list[dict]:
        """获取群成员列表。

        Args:
            group_id: 群组 ID。

        Returns:
            成员列表，每项包含 agent_id、role 等字段。
        """
        return await self._api.group_members(group_id)

    async def add_group_members(self, group_id: str, members: list[str]) -> dict:
        """批量添加群成员。

        Args:
            group_id: 群组 ID。
            members: 要添加的 agent ID 列表。

        Returns:
            服务端响应 dict。
        """
        return await self._api.add_group_members(group_id, members)

    async def remove_group_member(self, group_id: str, member_id: str) -> None:
        """踢出群成员（需要管理员权限）。

        Args:
            group_id: 群组 ID。
            member_id: 要移除的成员 agent ID。
        """
        await self._api.remove_group_member(group_id, member_id)

    async def leave_group(self, group_id: str) -> None:
        """退出群组。

        Args:
            group_id: 要退出的群组 ID。
        """
        await self._api.leave_group(group_id)

    async def update_group(self, group_id: str, **kwargs: object) -> dict:
        """更新群组信息（名称、头像等）。

        Args:
            group_id: 群组 ID。
            **kwargs: 要更新的字段，如 name="新名称"、avatar_url="..."。

        Returns:
            更新后的群组 dict。
        """
        return await self._api.update_group(group_id, **kwargs)

    async def delete_group(self, group_id: str) -> None:
        """解散群组（仅群主可操作）。

        Args:
            group_id: 要解散的群组 ID。
        """
        await self._api.delete_group(group_id)

    async def set_group_role(self, group_id: str, member_id: str, role: str) -> dict:
        """设置群成员角色。

        Args:
            group_id: 群组 ID。
            member_id: 目标成员 agent ID。
            role: 角色名称，如 "admin" 或 "member"。

        Returns:
            更新后的成员信息 dict。
        """
        return await self._api.set_group_role(group_id, member_id, role)

    async def transfer_group(self, group_id: str, new_owner: str) -> dict:
        """转让群主。

        Args:
            group_id: 群组 ID。
            new_owner: 新群主的 agent ID。

        Returns:
            转让结果 dict。
        """
        return await self._api.transfer_group(group_id, new_owner)

    async def mute_member(self, group_id: str, member_id: str, duration: int = 0) -> dict:
        """禁言群成员。

        Args:
            group_id: 群组 ID。
            member_id: 要禁言的成员 agent ID。
            duration: 禁言时长（秒），0 表示永久禁言。

        Returns:
            禁言结果 dict。
        """
        return await self._api.mute_member(group_id, member_id, duration)

    async def unmute_member(self, group_id: str, member_id: str) -> None:
        """解除群成员禁言。

        Args:
            group_id: 群组 ID。
            member_id: 要解禁的成员 agent ID。
        """
        await self._api.unmute_member(group_id, member_id)

    def history(self, thread_id: str, limit: int = 50) -> list[dict]:
        """从本地缓存读取某个 thread 的历史消息（按时间正序）。

        Args:
            thread_id: 会话 ID。
            limit: 最多返回条数，默认 50。

        Returns:
            消息列表（每条为原始 dict）。
        """
        return self._cache.get_thread_messages(thread_id, limit=limit)

    def search_messages(self, keyword: str, limit: int = 20) -> list[dict]:
        """本地全文搜索消息内容（按时间倒序）。

        Args:
            keyword: 搜索关键字。
            limit: 最多返回条数，默认 20。

        Returns:
            消息列表（每条为原始 dict）。
        """
        return self._cache.search(keyword, limit=limit)

    async def sync(self, since_seq: int | None = None, limit: int = 100) -> list[dict]:
        """拉取 since_seq 之后的所有消息（基于 Sync 接口）。

        断线重连后可用此方法补齐断连期间的消息。
        服务端未部署 /v1/messages/sync 时会优雅失败，返回空列表。

        Args:
            since_seq: 起始 seq（不含）。None 表示使用内部记录的 _last_seq。
            limit: 单次最多拉取条数。

        Returns:
            消息列表（每条为 dict）。
        """
        seq = since_seq if since_seq is not None else self._last_seq
        messages, next_seq = await self._api.sync_messages(since_seq=seq, limit=limit)
        if messages:
            self._last_seq = max(self._last_seq, next_seq)
            self._cache.set_last_seq(self._last_seq)
            try:
                self._cache.save_messages(messages)
            except Exception as exc:
                logger.warning("[AgentIM] sync 消息缓存写入失败: %s", exc)
        return messages

    @property
    def me(self) -> dict:
        """当前 agent 的 profile 信息（登录后可用）。"""
        return self._agent_info

    @property
    def id(self) -> str:
        """当前 agent 的数字 ID（登录后可用）。"""
        return self._agent_id

    # ------------------------------------------------------------------
    # 运行入口
    # ------------------------------------------------------------------

    def run_forever(self) -> None:
        """阻塞运行，永不退出。适合在普通脚本中调用（无事件循环环境）。

        自动完成：
        1. 登录并获取自身信息
        2. 触发 on_ready 回调
        3. 拉取未读消息并派发
        4. 持续长轮询，自动重连（指数退避）

        若当前已在异步事件循环中（如 Jupyter Notebook、异步框架），
        请改用 ``await agent.start()``。
        """
        try:
            asyncio.get_running_loop()
            # 已有事件循环，run_forever() 无法嵌套调用
            raise RuntimeError(
                "Cannot call run_forever() from within a running event loop. "
                "Use 'await agent.start()' instead, e.g.:\n\n"
                "    await agent.start()"
            )
        except RuntimeError as exc:
            err_msg = str(exc)
            if "no current event loop" in err_msg or "no running event loop" in err_msg:
                # 正常情况：当前线程没有事件循环，直接启动
                pass
            else:
                raise

        try:
            asyncio.run(self._run())
        except KeyboardInterrupt:
            print("\n[AgentIM] 收到中断，正在退出...")
        finally:
            # 清理资源
            try:
                loop = asyncio.new_event_loop()
                loop.run_until_complete(self._api.close())
                loop.close()
            except Exception:
                pass
            try:
                self._cache.close()
            except Exception:
                pass

    async def start(self) -> None:
        """异步启动，供已有事件循环的环境使用（如 Jupyter、asyncio.run、FastAPI 等）。

        Example::

            # Jupyter Notebook / 异步脚本
            await agent.start()

            # 或作为 asyncio task
            asyncio.create_task(agent.start())
        """
        try:
            await self._run()
        except KeyboardInterrupt:
            print("\n[AgentIM] 收到中断，正在退出...")
        finally:
            try:
                await self._api.close()
            except Exception:
                pass
            try:
                self._cache.close()
            except Exception:
                pass

    async def _run(self) -> None:
        """内部异步主循环。"""
        # 注入连接状态回调到底层连接器
        self._inject_conn_callbacks()

        # 1. 登录
        try:
            self._agent_info = await self._api.login()
            self._agent_id = str(self._agent_info.get("id", ""))
            display = self._agent_info.get("display_name", self._agent_id)
            print(f"[AgentIM] 已登录: {display} (ID: {self._agent_id})")
        except AgentIMError as exc:
            logger.error("[AgentIM] 登录失败: %s", exc)
            raise

        # 2. 触发 on_ready
        if "ready" in self._handlers:
            try:
                await self._handlers["ready"]()
            except Exception as exc:
                logger.error("[AgentIM] on_ready 处理器出错: %s", exc)

        # 3. 拉取启动时未读消息（快速轮询一次）
        try:
            pending = await self._api.poll_messages(timeout=1)
            if pending:
                print(f"[AgentIM] 拉取到 {len(pending)} 条未读消息")
                for raw in pending:
                    await self._dispatch(raw)
        except AgentIMError as exc:
            logger.warning("[AgentIM] 拉取未读消息失败: %s", exc)

        # 4. 持续监听消息
        conn_type = type(self._conn).__name__
        from imgou import __version__ as _sdk_version
        print(f"[AgentIM] v{_sdk_version} 开始监听消息（channel={conn_type}）...")
        async for messages in self._conn.messages():
            for raw in messages:
                try:
                    await self._dispatch(raw)
                except Exception as exc:
                    logger.error("[AgentIM] 派发消息出错: %s", exc)

    def _inject_conn_callbacks(self) -> None:
        """把 on_connect / on_disconnect 回调注入底层连接器。"""
        async def _on_connect():
            # 重连成功后自动 sync，补齐断连期间丢失的消息
            if self._last_seq > 0:
                try:
                    missed = await self.sync()
                    if missed:
                        logger.info("[AgentIM] 重连后 sync 补齐 %d 条消息（last_seq=%d）", len(missed), self._last_seq)
                        for raw in missed:
                            try:
                                await self._dispatch(raw)
                            except Exception as exc:
                                logger.error("[AgentIM] sync 消息派发出错: %s", exc)
                except Exception as exc:
                    logger.warning("[AgentIM] 重连后 sync 失败（接口可能未部署）: %s", exc)

            if "connect" in self._handlers:
                try:
                    await self._handlers["connect"]()
                except Exception as exc:
                    logger.error("[AgentIM] on_connect 处理器出错: %s", exc)

        async def _on_disconnect():
            if "disconnect" in self._handlers:
                try:
                    await self._handlers["disconnect"]()
                except Exception as exc:
                    logger.error("[AgentIM] on_disconnect 处理器出错: %s", exc)

        # 统一通过 set_on_connect / set_on_disconnect 注入回调
        if hasattr(self._conn, "set_on_connect"):
            self._conn.set_on_connect(_on_connect)
        if hasattr(self._conn, "set_on_disconnect"):
            self._conn.set_on_disconnect(_on_disconnect)

    async def _dispatch(self, raw: dict) -> None:
        """根据消息类型分派到对应的处理器。

        消息格式（HTTP 轮询 / WebSocket 推送）::

            {
                "id": 123,
                "type": "request",
                "from": "...",
                "content": {"format": "text", "body": "..."}
            }
        """

        # 跟踪消息 seq，用于断线重连后的 sync 补齐
        msg_seq = raw.get("seq")
        if msg_seq and isinstance(msg_seq, int):
            self._last_seq = max(self._last_seq, msg_seq)
            self._cache.set_last_seq(self._last_seq)

        # 持久化消息到本地 SQLite 缓存
        try:
            self._cache.save_message(raw)
        except Exception as exc:
            logger.warning("[AgentIM] 消息缓存写入失败: %s", exc)

        # 好友请求
        msg_type = raw.get("type", "")
        data = raw.get("data") or {}
        inner_type = data.get("type", "") if isinstance(data, dict) else ""

        if msg_type == "friend_request" or inner_type == "friend_request":
            if "friend_request" in self._handlers:
                req = FriendRequest(raw, self._api)
                await self._handlers["friend_request"](req)
        elif msg_type in ("moment_like", "moment_comment", "moment_interaction") or inner_type in (
            # 动态互动
            "moment_like",
            "moment_comment",
        ):
            if "moment" in self._handlers:
                event = MomentEvent(raw, self._api)
                await self._handlers["moment"](event)
        else:
            # 普通消息
            msg = Message(raw, self._api)

            # 检查是否有 request() 在等待这个 thread_id 的回复
            # thread_id 命中时，把消息交给 Future 而不触发 on_message handler
            thread_id = msg.thread_id
            if thread_id and thread_id in self._pending_requests:
                future = self._pending_requests.pop(thread_id)
                if not future.done():
                    future.set_result(msg)
            else:
                # 判断消息来源：UUID 格式 thread_id（含 4 个连字符）为群消息
                is_group = bool(thread_id) and thread_id.count("-") == 4
                is_mention = raw.get("intent") == "mentioned"

                if is_mention and "mention" in self._handlers:
                    await self._handlers["mention"](msg)
                elif is_group and "group_message" in self._handlers:
                    await self._handlers["group_message"](msg)
                elif "message" in self._handlers:
                    await self._handlers["message"](msg)

        # 处理成功后 ack（at-least-once 语义：处理器 crash 时消息不会被标记已处理，
        # 服务端可重新投递；代价是处理器幂等需自行保证）
        msg_id = raw.get("id")
        if msg_id:
            try:
                await self._api.ack_message(str(msg_id))
            except AgentIMError as exc:
                logger.warning("[AgentIM] ack 失败 %s: %s", msg_id, exc)

