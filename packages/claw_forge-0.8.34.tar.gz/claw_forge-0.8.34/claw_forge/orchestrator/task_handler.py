"""Per-task lifecycle coroutine for the ``claw-forge run`` dispatcher.

``task_handler`` was originally a closure inside ``run()``.  It has been
promoted to a top-level coroutine taking an explicit ``RunContext``
dataclass instead of capturing 15+ locals by reference — the only
refactor permitted inside the cli.py decomposition.  Behaviour is
byte-identical to the original closure.

The ``RunContext`` is constructed once in ``run_cli.py`` after all setup
completes; ``task_handler`` mutates per-task state on the worktree and
the ``active_worktrees`` / ``pending_merge_retries`` registries, but does
not mutate the context fields themselves.

Also owns helper functions that are only called from ``task_handler``:

* :func:`_create_and_sync_worktree` — worktree create + sync wrapper
* :func:`_try_claim_files` — file-claim guard via HTTP
* :func:`_resolve_sdk_credentials` — auth precedence resolution
* :func:`_set_merged_after_merge` — PATCH merge result back to state svc
* Inner-loop HTTP helpers (``_http_retry``, ``_patch_task``, ``_log_agent``)
  — private to this module; only consumed by ``task_handler`` itself.

The first four are re-exported from ``claw_forge.cli`` so existing tests
(``test_cli_merge_gating``, ``test_cli_file_claims``,
``test_resolve_sdk_credentials``, ``tests/git/test_dispatcher_git``)
keep their import paths.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
import sys
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    from claw_forge.git import GitOps
    from claw_forge.pool.manager import ProviderPoolManager
    from claw_forge.state.scheduler import TaskNode


# Maps plugin name → complexity tier for model-tier routing.
# Kept module-local so RunContext doesn't have to thread it.
_PLUGIN_COMPLEXITY: dict[str, str] = {
    "initializer": "high",
    "reviewer": "high",
    "coding": "medium",
    "bugfix": "medium",
    "testing": "low",
}


# Map tool names to the input key that best describes what they do
_TOOL_KEY: dict[str, str] = {
    "Write": "file_path", "Edit": "file_path",
    "Read": "file_path", "Bash": "command",
    "Glob": "pattern", "Grep": "pattern",
}


@dataclass
class RunContext:
    """Per-run context passed to every ``task_handler`` invocation.

    Constructed once in ``run_cli.py`` after all setup completes.  Fields
    correspond to closure-captured locals of the original ``task_handler``
    inside ``run()``.

    The dataclass is **not** ``frozen=True``: three fields hold mutable
    collections shared by reference with ``run_cli``'s signal handlers
    and wave-loop — ``active_worktrees`` (dict), ``pending_merge_retries``
    (set), and ``seen_logs`` (set).  Mutations to those containers
    propagate to all holders of the same reference.  The other fields
    are conceptually immutable for the run's lifetime; ``task_handler``
    does not reassign them.
    """

    # Core state-service handles
    state_base: str
    state_port: int
    session_id: str
    http_timeout: httpx.Timeout

    # Model + dispatch
    model: str
    effective_plan_model: str
    pool: ProviderPoolManager | None
    env_lock: asyncio.Lock

    # Agent run knobs
    edit_mode: str
    loop_detect_threshold: int
    effective_verify_on_exit: bool
    max_subagents: int

    # Filesystem / project
    project_path: Path

    # Agent isolation
    agent_isolation: str
    container_runtime_pref: str
    container_image: str
    container_extra_mounts: list[str]
    container_extra_env: list[str]
    container_pull_if_missing: bool

    # Git knobs
    git_enabled: bool
    git_ops: GitOps | None
    git_merge_strategy: str
    git_branch_prefix: str
    git_commit_on_boundary: bool
    git_auto_checkpoint_secs: int
    git_handle_uncommitted: str
    git_merge_retry_attempts: int
    default_branch: str

    # Mutable per-run registries (shared with run_cli signal handler /
    # wave-loop sidecar — same object reference, not a copy).
    active_worktrees: dict[str, Path] = field(default_factory=dict)
    pending_merge_retries: set[str] = field(default_factory=set)
    seen_logs: dict[str, set[tuple[str, str]]] = field(default_factory=dict)

    # v0.8.33 supply-chain hardening — deny writes to $HOME credential
    # stores / shell rc files / persistence dirs at the OS sandbox level.
    sandbox_home_protection: bool = True
    # v0.8.33 supply-chain hardening — inject ``npm_config_ignore_scripts=
    # true`` (also covers pnpm and yarn-classic via the same env var) into
    # the agent's sdk_env so postinstall hooks of npm packages don't run
    # automatically.  Postinstall scripts are the dominant npm-supply-chain
    # vector: a malicious package runs code as the npm child process the
    # moment it's installed, bypassing every static Bash hook the harness
    # has.  Disable per-config when a project legitimately needs them.
    npm_ignore_scripts: bool = True


# ── Helpers (formerly closures inside ``run`` / ``main``) ───────────────


async def _create_and_sync_worktree(
    git_ops: GitOps,
    *,
    task_id: str,
    slug: str,
    prefix: str,
    target: str,
) -> dict[str, Any] | None:
    """Create (or resume) a worktree, then synchronise its branch with *target*.

    Returns ``None`` when git is disabled or worktree creation failed.
    Otherwise returns ``{"branch": str, "worktree_path": Path, "sync": dict}``
    where ``sync`` is the structured outcome from
    :meth:`GitOps.sync_worktree` — callers MUST inspect ``sync["synced"]``
    before dispatching an agent into the worktree.  When sync fails (real
    conflict or dirty worktree), the caller should mark the task ``failed``
    with the file list and skip the agent dispatch; the existing
    failure-preservation rule keeps the worktree on disk so the operator
    can resolve manually.
    """
    wt_result = await git_ops.create_worktree(
        task_id, slug, prefix=prefix, base_branch=target,
    )
    if not wt_result:
        return None
    branch_name, worktree_path = wt_result
    sync_result = await git_ops.sync_worktree(worktree_path, target=target)
    return {
        "branch": branch_name,
        "worktree_path": worktree_path,
        "sync": sync_result or {"synced": True, "no_op": True, "merged_count": 0},
    }


async def _try_claim_files(
    http: Any, state_base: str, session_id: str, task_id: str,
    file_paths: list[str],
) -> tuple[bool, list[str]]:
    """POST /file-claims for *task_id*; return (ok, conflicts).

    Empty *file_paths* short-circuits to (True, []) — tasks that don't
    declare files participate in no locking.
    """
    if not file_paths:
        return True, []
    import httpx
    try:
        r = await http.post(
            f"{state_base}/sessions/{session_id}/file-claims",
            json={"task_id": task_id, "file_paths": list(file_paths)},
        )
    except httpx.HTTPError:
        # State service unavailable — treat as success (don't block dispatch
        # on transient state-service errors).
        return True, []
    if r.status_code == 200:
        return True, []
    if r.status_code == 409:
        return False, list(r.json().get("conflicts", []))
    # Any other status — log-then-allow; don't block on unexpected codes.
    return True, []


def _resolve_sdk_credentials(
    pool: Any | None,
) -> tuple[dict[str, str], str]:
    """Resolve auth credentials for a Claude Agent SDK invocation.

    Returns ``(sdk_env, provider_name)``.  Caller spreads ``sdk_env`` into
    ``ClaudeAgentOptions.env`` and surfaces ``provider_name`` in the
    activity log.

    Precedence (matches the documented Claude CLI authentication order at
    https://code.claude.com/docs/en/authentication#authentication-precedence):

      1. ``ANTHROPIC_API_KEY`` from process env  → set as is
      2. ``ANTHROPIC_AUTH_TOKEN`` from process env → set as is
      3. ``pool.next_provider_for_dispatch().config.api_key``
         → seeded as ``ANTHROPIC_API_KEY`` (X-Api-Key header)
      4. ``pool.next_provider_for_dispatch().config.oauth_token``
         → seeded as ``ANTHROPIC_AUTH_TOKEN`` (Bearer header)
      5. neither → empty ``sdk_env``; CLI falls back to keychain
         (pre-claw-forge behaviour, single identity)

    ``ANTHROPIC_SETUP_TOKEN`` is **intentionally never set**.  It is the
    import-flow env var consumed by ``claude setup-token`` (which writes
    to keychain) — not a runtime auth credential.  Setting it on a
    running CLI is silently ignored.  Through v0.8.10 claw-forge set
    ``ANTHROPIC_SETUP_TOKEN`` for OAuth providers, which is why
    configured ``oauth_token: ${OAUTH_TOKEN_*}`` entries never actually
    drove agent traffic — every agent fell through to the local
    keychain identity instead.

    ``provider_name`` is ``"env"`` when process env supplied creds (so
    the activity log can distinguish "credential came from shell, not
    from claw-forge.yaml"), the picked provider's ``name`` when pool
    creds were used, or stays ``"env"`` when nothing matched (caller
    detects that via the empty ``sdk_env``).
    """
    sdk_env: dict[str, str] = {}
    provider_name = "env"

    env_api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    env_oauth = os.environ.get("ANTHROPIC_AUTH_TOKEN", "")
    if env_api_key:
        sdk_env["ANTHROPIC_API_KEY"] = env_api_key
        return sdk_env, provider_name
    if env_oauth:
        sdk_env["ANTHROPIC_AUTH_TOKEN"] = env_oauth
        return sdk_env, provider_name

    if pool is None:
        return sdk_env, provider_name

    picked = pool.next_provider_for_dispatch()
    if picked is None:
        return sdk_env, provider_name

    cfg = picked.config
    if cfg.api_key:
        sdk_env["ANTHROPIC_API_KEY"] = cfg.api_key
        provider_name = picked.name
        return sdk_env, provider_name

    tok = getattr(cfg, "oauth_token", "") or ""
    if tok:
        sdk_env["ANTHROPIC_AUTH_TOKEN"] = tok
        provider_name = picked.name

    return sdk_env, provider_name


def _apply_npm_safety_env(sdk_env: dict[str, str], *, enabled: bool) -> None:
    """Inject npm/pnpm/yarn supply-chain safety env vars when *enabled* (v0.8.33).

    ``npm_config_ignore_scripts=true`` is honored by both npm and pnpm
    (pnpm inherits ``npm_config_*`` config keys).  ``YARN_ENABLE_SCRIPTS=
    false`` covers Yarn 2+; Yarn 1 honors the npm-style env var.

    Uses ``setdefault`` so an operator who pre-set these in ``.env`` (or
    process env) wins — useful when a project legitimately needs a
    different setting for a specific run.  Caller decides which value
    of *enabled* to pass based on ``agent.npm_ignore_scripts`` config.
    """
    if not enabled:
        return
    sdk_env.setdefault("npm_config_ignore_scripts", "true")
    sdk_env.setdefault("YARN_ENABLE_SCRIPTS", "false")


async def _set_merged_after_merge(
    http: Any,
    state_base: str,
    task_id: str,
    merge_result: dict[str, Any] | None,
    *,
    current_merge_retry_count: int = 0,
    merge_retry_attempts: int = 0,
) -> dict[str, bool]:
    """PATCH merge result back to the state service.

    Called by the task_handler after apply_on_completion returns.

    On success: sets ``merged_to_target_branch=True`` and ``merge_commit_sha``
    so dependents unblock and the squash is auditable.

    On failure (``merge_result['merged'] is False``):
      - If ``current_merge_retry_count + 1 < merge_retry_attempts``: re-pend
        the task (PATCH ``status='pending'`` + bump ``merge_retry_count``)
        with ``error_message='merge_retry_<N>: <reason>'`` so the next
        dispatch wave picks it up under ``prefer_resumable``.  The agent
        re-runs in the preserved worktree with a merge-conflict resume
        preamble.  Returns ``{"re_pended": True}`` so the caller can
        signal the dispatcher's wave-loop to remove this task ID from
        ``total_completed`` (otherwise the existing filter would skip
        it on the next wave).
      - At the cap: PATCH ``error_message='merge_failed: <reason> (after
        N attempts)'`` and leave ``status='completed'`` + ``merged=False``
        — today's preserve-and-warn behaviour.

    ``merge_retry_attempts=0`` disables the auto-recovery loop entirely
    (legacy behaviour: every failure is terminal).

    Does nothing when ``merge_result is None`` (no merge was attempted —
    git disabled, ``merge_strategy: manual``, or task failed).
    """
    import httpx

    if merge_result is None:
        return {"re_pended": False}
    if not merge_result.get("merged"):
        err = merge_result.get("error", "unknown error")
        next_count = current_merge_retry_count + 1
        if next_count < merge_retry_attempts:
            # Re-pend for autonomous retry.  ``merged_to_target_branch``
            # stays False so dependents stay blocked until the eventual
            # successful merge.  Worktree is already preserved on disk
            # because squash_merge only calls remove_worktree on success.
            with suppress(httpx.HTTPError):
                await http.patch(
                    f"{state_base}/tasks/{task_id}",
                    json={
                        "status": "pending",
                        "merge_retry_count": next_count,
                        "error_message": f"merge_retry_{next_count}: {err}",
                    },
                    timeout=5,
                )
            return {"re_pended": True}
        # At cap (or auto-recovery disabled): preserve-and-warn.  Only
        # annotate the attempt count when retries were actually consumed
        # — preserves byte-exact legacy message for callers that disable
        # auto-recovery (``merge_retry_attempts=0``) or don't pass it.
        if current_merge_retry_count > 0:
            attempts_note = (
                f" (after {current_merge_retry_count + 1} attempts)"
            )
        else:
            attempts_note = ""
        with suppress(httpx.HTTPError):
            await http.patch(
                f"{state_base}/tasks/{task_id}",
                json={"error_message": f"merge_failed: {err}{attempts_note}"},
                timeout=5,
            )
        return {"re_pended": False}
    with suppress(httpx.HTTPError):
        await http.patch(
            f"{state_base}/tasks/{task_id}",
            json={"merged_to_target_branch": True},
        )
    if merge_result.get("commit_hash"):
        try:
            await http.patch(
                f"{state_base}/tasks/{task_id}",
                json={"merge_commit_sha": merge_result["commit_hash"]},
                timeout=5,
            )
        except Exception:
            import logging as _logging
            _logging.getLogger(__name__).warning(
                "failed to PATCH merge_commit_sha for task %s", task_id, exc_info=True
            )
    return {"re_pended": False}


# ── Inner HTTP / logging helpers (formerly inside ``main()``) ──────────


async def _http_retry(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    *,
    max_retries: int = 3,
    **kwargs: Any,
) -> httpx.Response:
    """HTTP call with retry on transient timeout/connection errors."""
    for attempt in range(max_retries):
        try:
            resp: httpx.Response = await getattr(client, method)(url, **kwargs)
            resp.raise_for_status()
            return resp
        except (httpx.TimeoutException, httpx.ConnectError):
            if attempt == max_retries - 1:
                raise
            await asyncio.sleep(1.0 * (attempt + 1))
    raise httpx.TimeoutException("exhausted retries")  # unreachable


async def _patch_task(
    client: httpx.AsyncClient, state_base: str, task_id: str, **fields: Any,
) -> None:
    """PATCH task status via HTTP (triggers WS broadcast)."""
    with suppress(httpx.HTTPError):
        await _http_retry(
            client, "patch",
            f"{state_base}/tasks/{task_id}",
            json=fields,
        )


def _short_name(desc: str) -> str:
    """Extract a short label from a task description.

    Strips common prefixes like "Task X:" or "Feature N:" and
    truncates to 40 chars so the activity log stays scannable.
    """
    # Remove "Task <word>: " or "Feature <word>: " prefix
    cleaned = re.sub(
        r"^(?:task|feature)\s+\S+:\s*",
        "",
        desc,
        flags=re.IGNORECASE,
    )
    if len(cleaned) > 40:
        return cleaned[:37] + "…"
    return cleaned


def _first_line(text: str, max_len: int = 120) -> str:
    """Return the first non-empty line, truncated."""
    line = text.strip().split("\n", 1)[0].strip()
    if len(line) > max_len:
        return line[:max_len - 1] + "…"
    return line


def _fmt_tool(name: str, raw: object) -> str:
    """Format tool input into a short human-readable string."""
    if isinstance(raw, dict):
        key = _TOOL_KEY.get(name)
        if key and key in raw:
            val = str(raw[key])
            if name == "Bash":
                val = val[:80]
            return val
    return str(raw)[:80]


async def _log_agent(
    client: httpx.AsyncClient,
    state_base: str,
    seen_logs: dict[str, set[tuple[str, str]]],
    task_id: str,
    task_name: str,
    role: str,
    content: str,
    level: str = "info",
    model: str = "",
    provider: str = "",
) -> None:
    """POST agent log entry via HTTP (triggers WS broadcast).

    ``provider`` is the configured pool-member name (from
    ``claw-forge.yaml`` ``providers:``) that dispatched this turn —
    ``response.provider_name`` for direct-pool path; the picked
    credential's provider name for SDK path.  Forwarded to the
    Kanban activity log so the user sees which credential / proxy
    handled each call.
    """
    short = _first_line(content)
    # Skip any duplicate (same role + content already seen for this task)
    key = (role, short)
    seen = seen_logs.setdefault(task_id, set())
    if key in seen:
        return
    seen.add(key)
    with suppress(httpx.HTTPError):
        await client.post(
            f"{state_base}/tasks/{task_id}/agent-log",
            json={
                "role": role,
                "content": short,
                "task_name": _short_name(task_name),
                "level": level,
                "model": model or None,
                "provider": provider or None,
            },
        )


# ── Main task handler ─────────────────────────────────────────────────


async def task_handler(task_node: TaskNode, ctx: RunContext) -> dict[str, Any]:
    """Per-task lifecycle: claim files → create worktree → sync → run agent → merge.

    Promoted from inner closure of ``run()``.  Captured locals are now
    accessed via ``ctx``.  Behaviour is byte-identical to the original.
    """
    async with httpx.AsyncClient(timeout=ctx.http_timeout) as http:
        # Fetch task details + mark as running via HTTP
        try:
            task_resp = await _http_retry(
                http, "get",
                f"{ctx.state_base}/tasks/{task_node.id}",
            )
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                logging.getLogger("claw_forge.cli").warning(
                    "Task %s not found in state service — skipping",
                    task_node.id,
                )
                raise RuntimeError(
                    f"Task {task_node.id} not found in state service "
                    "(stale session or service restart)"
                ) from exc
            raise
        task_data = task_resp.json()
        task_name = (
            task_data.get("description") or task_data["plugin_name"]
        )
        prompt = (
            task_data.get("description")
            or f"Execute task: {task_data['plugin_name']}"
        )
        steps = task_data.get("steps") or []
        if steps:
            numbered = "\n".join(
                f"{i + 1}. {s}" for i, s in enumerate(steps)
            )
            prompt = f"{prompt}\n\n## Verification Steps\n{numbered}"

        # File-claim guard: defer this task if any file it declares
        # is already held by another running task.  Tasks without
        # touches_files declared participate in no locking.
        # NOTE: this return is before the try/finally block, so the
        # finally won't PATCH status="failed" — the task stays pending.
        import logging as _logging

        touches = list(getattr(task_node, "touches_files", []) or [])
        _claim_ok, _claim_conflicts = await _try_claim_files(
            http, ctx.state_base, ctx.session_id, task_node.id, touches,
        )
        if not _claim_ok:
            _logging.getLogger(__name__).info(
                "Task %s deferred — files claimed by another task: %s",
                task_node.id, _claim_conflicts,
            )
            return {"success": False, "output": "deferred"}

        # Mark running via HTTP (triggers WS broadcast + sets started_at)
        # ── Flip merged_to_target_branch=False so dependents stay blocked
        #    until our squash-merge succeeds (auto strategy only).
        if ctx.git_enabled and ctx.git_merge_strategy == "auto":
            await _patch_task(
                http, ctx.state_base, task_node.id,
                status="running", merged_to_target_branch=False,
            )
        else:
            await _patch_task(http, ctx.state_base, task_node.id, status="running")

        # Create a feature branch for this task (best-effort — git
        # errors must not crash the dispatcher or leave tasks stuck).
        from claw_forge.git.slug import make_branch_name as _make_branch_name

        _slug = _make_branch_name(
            task_node.description,
            task_node.category,
            task_node.plugin_name,
            prefix=ctx.git_branch_prefix,
        ).removeprefix(f"{ctx.git_branch_prefix}/")
        _worktree_path: Path | None = None
        _resume_conflict: bool = False
        # Set when the autonomous merge-recovery path leaves
        # conflict markers in the worktree for the agent to
        # resolve.  The resume preamble below picks this up and
        # injects an explicit conflict-recovery section.
        _conflict_recovery_files: list[str] | None = None
        if ctx.git_enabled:
            try:
                assert ctx.git_ops is not None
                _wt_bundle = await _create_and_sync_worktree(
                    ctx.git_ops,
                    task_id=task_node.id,
                    slug=_slug,
                    prefix=ctx.git_branch_prefix,
                    target=ctx.default_branch,
                )
                if _wt_bundle:
                    _worktree_path = _wt_bundle["worktree_path"]
                    assert isinstance(_worktree_path, Path)
                    ctx.active_worktrees[task_node.id] = _worktree_path
                    _sync = _wt_bundle["sync"]
                    if not _sync.get("synced"):
                        # Pre-dispatch sync did not complete cleanly.
                        # Three sub-cases, in priority order:
                        #
                        # 1. Real conflicts + budget remains →
                        #    autonomous recovery: re-call sync with
                        #    leave_conflicts=True so markers stay,
                        #    bump merge_retry_count, dispatch agent
                        #    with a conflict-aware preamble.
                        # 2. Dirty worktree (uncommitted edits) →
                        #    today's failure path; agent must NOT
                        #    overwrite operator-managed state.
                        # 3. Conflicts at the cap → today's failure
                        #    path; the loop has tried enough times,
                        #    fall back to manual resolution.
                        _conflict_files = _sync.get("conflicts", [])
                        _dirty = _sync.get("dirty_worktree", False)
                        _current_merge_retries = task_data.get(
                            "merge_retry_count", 0,
                        )
                        _recovery_eligible = (
                            not _dirty
                            and bool(_conflict_files)
                            and (
                                _current_merge_retries + 1
                                < ctx.git_merge_retry_attempts
                            )
                        )
                        if _recovery_eligible:
                            # Re-sync with leave_conflicts=True so
                            # markers persist for the agent.  This
                            # is a second `git merge` invocation;
                            # it produces the same conflicts but
                            # this time we don't abort.
                            _ = await ctx.git_ops.sync_worktree(
                                _worktree_path,
                                target=ctx.default_branch,
                                leave_conflicts=True,
                            )
                            _new_count = _current_merge_retries + 1
                            await _patch_task(
                                http, ctx.state_base, task_node.id,
                                merge_retry_count=_new_count,
                            )
                            _conflict_recovery_files = list(
                                _conflict_files,
                            )
                            _logging.getLogger(__name__).info(
                                "Task %s: dispatching agent for "
                                "autonomous merge-conflict recovery "
                                "(attempt %d of %d) on %d file(s): %s",
                                task_node.id, _new_count,
                                ctx.git_merge_retry_attempts,
                                len(_conflict_files), _conflict_files,
                            )
                            # FALL THROUGH to agent dispatch — the
                            # resume preamble will brief the agent
                            # using ``_conflict_recovery_files``.
                        else:
                            if _dirty:
                                _msg = (
                                    "resume_conflict: worktree has "
                                    "uncommitted changes; resolve in "
                                    f"{_worktree_path} (commit or "
                                    "discard) before retrying."
                                )
                            else:
                                _msg = (
                                    "resume_conflict: catch-up merge "
                                    f"of {ctx.default_branch} into "
                                    "branch failed on "
                                    f"{len(_conflict_files)} file(s)"
                                    f": {', '.join(_conflict_files)}"
                                    ". Resolve manually in "
                                    f"{_worktree_path} (run `git "
                                    f"merge {ctx.default_branch}`, "
                                    "fix conflicts, commit) and "
                                    "requeue the task."
                                )
                            _resume_conflict = True  # set before any await that could raise
                            await _patch_task(
                                http, ctx.state_base, task_node.id,
                                status="failed",
                                error_message=_msg,
                            )
                            _logging.getLogger(__name__).warning(
                                "Task %s: %s", task_node.id, _msg,
                            )
                            with suppress(Exception):
                                await http.delete(
                                    f"{ctx.state_base}/sessions/"
                                    f"{ctx.session_id}/file-claims/"
                                    f"{task_node.id}",
                                    timeout=5,
                                )
                            ctx.active_worktrees.pop(task_node.id, None)
            except Exception as _git_wt_err:
                # Pre-v0.8.12 this was warning-and-continue: the
                # agent then ran with cwd=project_path (main's
                # working tree), and any new files it created
                # landed there as untracked debris that the
                # squash-merge flow never saw.  Fail the task
                # instead — agents must NEVER run against the
                # target branch's working tree when ``git_enabled``.
                _wt_msg = (
                    f"worktree_creation_failed: {_git_wt_err}. "
                    "Agent NOT run — would have leaked output "
                    "files directly into the target branch's "
                    "working tree.  Inspect ``git status`` in "
                    f"{ctx.project_path}, then requeue the task."
                )
                _logging.getLogger(__name__).error(
                    "Task %s: %s", task_node.id, _wt_msg,
                )
                await _patch_task(
                    http, ctx.state_base, task_node.id,
                    status="failed",
                    error_message=_wt_msg,
                )
                with suppress(Exception):
                    await http.delete(
                        f"{ctx.state_base}/sessions/"
                        f"{ctx.session_id}/file-claims/"
                        f"{task_node.id}",
                        timeout=5,
                    )
                return {
                    "success": False,
                    "output": "worktree_creation_failed",
                }

        if _resume_conflict:
            return {"success": False, "output": "resume_conflict"}

        # Defence-in-depth: ``_create_and_sync_worktree`` can
        # return ``None`` (silent failure mode — distinct from the
        # exception path above) when ``git_ops.create_worktree``
        # itself returns nothing.  Catch that case too — a None
        # bundle would still leave ``_worktree_path = None`` and
        # the agent would run in main's working tree per line 1616
        # (``_agent_cwd = _worktree_path or project_path``).
        if ctx.git_enabled and _worktree_path is None:
            _wt_msg = (
                "worktree_unavailable: create_worktree returned "
                "no result (git enabled but no worktree on disk). "
                "Agent NOT run — would have leaked output files "
                "into the target branch's working tree.  Check "
                "``.claw-forge/state.log`` for the underlying "
                "git error, then requeue the task."
            )
            _logging.getLogger(__name__).error(
                "Task %s: %s", task_node.id, _wt_msg,
            )
            await _patch_task(
                http, ctx.state_base, task_node.id,
                status="failed",
                error_message=_wt_msg,
            )
            with suppress(Exception):
                await http.delete(
                    f"{ctx.state_base}/sessions/"
                    f"{ctx.session_id}/file-claims/"
                    f"{task_node.id}",
                    timeout=5,
                )
            return {
                "success": False,
                "output": "worktree_unavailable",
            }

        # ── Periodic auto-checkpoint background task ──────────────
        from claw_forge.orchestrator.checkpointing import periodic_checkpoint_loop

        _checkpoint_task: asyncio.Task[None] | None = None

        if (
            ctx.git_enabled
            and _worktree_path
            and ctx.git_auto_checkpoint_secs > 0
        ):
            assert ctx.git_ops is not None
            _checkpoint_task = asyncio.create_task(
                periodic_checkpoint_loop(
                    ctx.git_ops,
                    _worktree_path,
                    task_node.id,
                    task_node.plugin_name or "unknown",
                    ctx.session_id,
                    ctx.git_auto_checkpoint_secs,
                )
            )

        # ── v0.8.17: pre-agent invariant assertion ────────────────
        # The boot baseline + per-task post-rollback maintains
        # ``project_path`` as HEAD-clean for the run's lifetime.
        # If we see dirt here, either a concurrent task is
        # mid-leak (will rollback when it finishes) OR the
        # invariant has been violated (operator manually edited
        # main during the run, or a rollback failed silently).
        # Log either way — diagnostic only, do not fail dispatch.
        if ctx.git_enabled:
            from claw_forge.git.leak_watch import (
                project_status_porcelain,
            )
            _pre_dirt = await asyncio.to_thread(
                project_status_porcelain, ctx.project_path,
            )
            if _pre_dirt:
                _logging.getLogger(__name__).warning(
                    "Task %s pre-dispatch: main has unexpected "
                    "dirt (%d paths) — concurrent task leak in "
                    "flight or invariant violation: %s",
                    task_node.id, len(_pre_dirt),
                    sorted(_pre_dirt)[:5],
                )

        # ── Resume context: inject prior-attempt info on retry ──
        _error_msg = task_data.get("error_message")
        # Two preamble triggers: (a) error_message set from any
        # prior failure (existing behaviour); (b) the autonomous
        # merge-recovery path left conflict markers in the worktree
        # for the agent to resolve.  Either one demands the
        # preamble; neither one alone does we have a fresh task.
        _is_merge_recovery = (
            _conflict_recovery_files is not None
            or (_error_msg or "").startswith("merge_retry_")
        )
        if (_error_msg or _is_merge_recovery) and ctx.git_enabled:
            from claw_forge.git.commits import branch_commit_subjects

            _resume_branch = f"{ctx.git_branch_prefix}/{_slug}"
            _resume_target = ctx.default_branch
            _prior_subjects = branch_commit_subjects(
                ctx.project_path, _resume_branch, _resume_target
            )
            _handoff_path = (
                (_worktree_path or ctx.project_path) / "HANDOFF.md"
            )
            _handoff_text = ""
            if _handoff_path.exists():
                _handoff_text = _handoff_path.read_text(
                    encoding="utf-8"
                )

            _resume_parts: list[str] = [
                "## Resume Context",
                "This task was previously attempted but did not complete cleanly.\n",
            ]
            if _prior_subjects:
                _resume_parts.append(
                    "### Prior Work (preserved in this worktree)"
                )
                _resume_parts.extend(
                    f"- {s}" for s in _prior_subjects
                )
                _resume_parts.append("")
            if _error_msg:
                _resume_parts.extend([
                    "### Previous Failure",
                    _error_msg[:2000],
                    "",
                ])
            if _handoff_text:
                _resume_parts.extend([
                    "### Handoff from Prior Attempt",
                    _handoff_text[:3000],
                    "",
                ])
            if _is_merge_recovery:
                # The autonomous merge-recovery path is in play —
                # tell the agent explicitly what state the worktree
                # is in and what it needs to do.  Spec:
                # docs/superpowers/specs/2026-05-10-autonomous-merge-recovery.md.
                _attempt_num = task_data.get(
                    "merge_retry_count", 0,
                ) or 1
                _file_lines = (
                    "\n".join(
                        f"- {f}" for f in (
                            _conflict_recovery_files or []
                        )
                    )
                    or "- (file list unavailable; "
                    "run `git status` in this worktree)"
                )
                _resume_parts.extend([
                    "## Merge Conflict Recovery (CRITICAL)",
                    "",
                    f"The catch-up merge of `{ctx.default_branch}` "
                    "into your branch produced conflicts. "
                    "The conflict markers are still in place in "
                    "this worktree (the merge was NOT aborted) "
                    "so you can resolve them directly. The "
                    "conflicted file(s):",
                    "",
                    _file_lines,
                    "",
                    "### Resolution steps",
                    "1. **Migration filename collisions** "
                    "(common alembic case): renumber the "
                    "incoming file under `migrations/versions/` "
                    "to the next free slot and update its "
                    "`down_revision` to the current alembic "
                    "head before resolving.",
                    "2. **Code conflicts**: edit the conflicted "
                    "files, choose the correct merge between "
                    "the `<<<<<<<` / `=======` / `>>>>>>>` "
                    "markers, remove the markers, save.",
                    "3. **Lockfile / generated files**: prefer "
                    "regenerating from authoritative source "
                    "(re-run `uv lock` / `npm install` / "
                    "`cargo update`) rather than hand-merging "
                    "the lockfile text.",
                    "4. Stage and commit the resolution: "
                    "`git add <files> && git commit -m "
                    "\"merge: resolve conflicts with "
                    f"{ctx.default_branch}\"`.",
                    "5. Run the project's test command and "
                    "ensure it still passes before continuing "
                    "the original task.",
                    "",
                    f"This is attempt {_attempt_num} of "
                    f"{ctx.git_merge_retry_attempts}. If the "
                    "post-completion squash-merge fails again, "
                    "the task will be auto-retried up to the "
                    "cap; after the cap it is preserved for "
                    "human resolution.",
                    "",
                ])
            _resume_parts.extend([
                "### Instructions",
                "- Review existing code in this worktree before making changes",
                "- Do NOT redo already-completed work",
                "- Focus on remaining steps and fixing the prior failure",
            ])
            prompt = "\n".join(_resume_parts) + "\n\n" + prompt

        output = ""
        success = False
        _cancelled = False

        try:
            # ── Option 1: claude_agent_sdk + claude CLI (full autonomous agent) ──
            # claude_agent_sdk is a declared dependency so it's always installed.
            # It requires the `claude` CLI in PATH to actually run agents.
            sdk_available = (
                shutil.which("claude") is not None
            )

            if sdk_available:
                from claude_agent_sdk import ClaudeAgentOptions

                from claw_forge.agent.hooks import get_default_hooks as _ghooks
                from claw_forge.agent.permissions import make_can_use_tool
                from claw_forge.agent.session import AgentSession

                # UNDER LOCK: env reads + options construction
                # (matches autonomous-coding _env_client_lock pattern).
                # Serialising this block also serialises pool routing
                # decisions across concurrent task starts, so two
                # tasks dispatched in the same tick can't both grab
                # the same round-robin slot.
                async with ctx.env_lock:
                    # Resolve auth env via ``_resolve_sdk_credentials``
                    # so the precedence is centralised (process env
                    # → pool rotation → keychain fallback) and
                    # unit-testable.  Critically, OAuth tokens go
                    # to ``ANTHROPIC_AUTH_TOKEN`` (Bearer header) —
                    # NOT ``ANTHROPIC_SETUP_TOKEN`` (which is only
                    # the one-shot ``claude setup-token`` import
                    # env var, silently ignored at agent runtime).
                    sdk_env, sdk_provider_name = _resolve_sdk_credentials(ctx.pool)
                    _apply_npm_safety_env(
                        sdk_env, enabled=ctx.npm_ignore_scripts,
                    )

                    agent_hooks = _ghooks(
                        edit_mode=ctx.edit_mode,
                        loop_detect_threshold=ctx.loop_detect_threshold,
                        verify_on_exit=ctx.effective_verify_on_exit,
                        max_subagents=ctx.max_subagents,
                        state_url=f"http://localhost:{ctx.state_port}",
                    )

                    # ── Stderr filter: suppress noisy Claude CLI hook errors ──
                    # Claude Code 2.1.x emits multi-line "Error in hook
                    # callback hook_N" errors with minified JS + ZodError
                    # stack traces.  Non-fatal but noisy.
                    _cli_logger = logging.getLogger("claw_forge.cli")
                    _hook_err_remaining = 0

                    def _stderr_filter(line: str) -> None:
                        nonlocal _hook_err_remaining
                        if "Error in hook callback hook_" in line:
                            _hook_err_remaining = 30
                            _cli_logger.debug(
                                "Suppressed hook error: %s", line[:200],
                            )
                            return
                        if _hook_err_remaining > 0:
                            _hook_err_remaining -= 1
                            return
                        sys.stderr.write(line)
                        sys.stderr.flush()

                    # When ``git_enabled``, ``_worktree_path`` is
                    # guaranteed non-None here — both failure
                    # paths above (worktree_creation_failed and
                    # worktree_unavailable) early-return.  The
                    # ``or project_path`` fallback is therefore
                    # only exercised for ``git.enabled: false``
                    # projects where there is no feature-branch
                    # worktree concept and writing to project_path
                    # is the intended behaviour.
                    _agent_cwd = _worktree_path or ctx.project_path
                    # Route model: initializer (planning) uses plan_model
                    _effective_model = (
                        ctx.effective_plan_model
                        if task_node.plugin_name == "initializer"
                        else ctx.model
                    )
                    # Layer 3 — Information-hiding worktree
                    # boundary directive (v0.8.16, hardened in
                    # v0.8.18).  The original v0.8.16 directive
                    # named the parent project's absolute path
                    # explicitly so the agent could "know what
                    # to avoid" — but in naming it we handed the
                    # agent the ammunition for any escape that
                    # needs an absolute path.  v0.8.18 omits the
                    # parent path entirely: the agent only sees
                    # its own worktree as "the project root" and
                    # has no observable handle to anywhere else.
                    # The OS sandbox (Level 2) and snapshot-
                    # rollback (v0.8.17) cover the long tail
                    # if the agent constructs an escape path
                    # via ``git rev-parse --show-toplevel`` or
                    # similar discovery commands.
                    _wt_directive: str | None = None
                    if ctx.git_enabled and _agent_cwd != ctx.project_path:
                        _wt_directive = (
                            "\n\n## Workspace boundary (CRITICAL)\n"
                            "You are running in an isolated "
                            "workspace.  Treat your current "
                            "working directory as the project "
                            "root; everything you do — file "
                            "edits, git operations, test runs, "
                            "subprocess invocations — must "
                            "happen INSIDE your cwd.\n\n"
                            "Writing files outside your cwd "
                            "is a DESTRUCTIVE ESCAPE that "
                            "breaks your task's delivery flow "
                            "and may fail the task.  Use "
                            "relative paths (``backend/foo.py``) "
                            "or paths under your cwd, never "
                            "absolute paths to other locations.  "
                            "Avoid commands with explicit "
                            "directory flags that target paths "
                            "outside your cwd (``git -C "
                            "<elsewhere>``, ``--git-dir=<elsewhere>``, "
                            "``python <elsewhere>/script.py``).  "
                            "The harness enforces this boundary "
                            "via OS-level sandbox + tool path "
                            "validation; explicit cooperation "
                            "from you avoids tool denials and "
                            "task failures."
                        )
                    # ── Tool usage tips (v0.8.22) ─────────────
                    # Common agent failure modes seen in dispatch
                    # logs that aren't bugs but cost retries:
                    #   * Read on a directory → EISDIR.  The
                    #     Read tool reads files only.  Use Glob
                    #     or ``ls`` for directory contents.
                    #   * Bash assumes ``tree`` is installed →
                    #     exit 127.  Fall back to ``find`` or
                    #     ``ls -R``.
                    #   * Read with mistyped path → ``File does
                    #     not exist``.  Use Glob to discover
                    #     paths before Read.
                    # Brief, declarative — no examples beyond
                    # the alternative tool name so the agent
                    # picks them up without copying patterns
                    # verbatim.  Always emitted (independent of
                    # workspace boundary, which is git-only).
                    _tool_tips = (
                        "\n\n## Tool usage tips\n"
                        "- ``Read`` reads files only; passing a "
                        "directory raises ``EISDIR``.  Use "
                        "``Glob`` (file patterns) or "
                        "``Bash ls`` to enumerate directories "
                        "first, then Read individual files.\n"
                        "- If a Bash command fails with "
                        "``command not found`` (e.g. ``tree``), "
                        "fall back to ``find . -type d`` or "
                        "``ls -R`` rather than installing the "
                        "missing tool.\n"
                        "- If Read returns ``File does not "
                        "exist``, use Glob to discover the "
                        "actual path before retrying — don't "
                        "guess at variations of the same name."
                    )
                    # Compose: tool tips always; workspace
                    # boundary on top when git is enabled.
                    _agent_directive = _tool_tips + (
                        _wt_directive if _wt_directive else ""
                    )
                    # ── Agent isolation: process (Level 2) or container (Level 4) ─
                    # ``agent.isolation: process`` (default,
                    # v0.8.18) wraps ``claude`` in sandbox-exec
                    # (macOS) / bwrap (Linux planned).  Kernel
                    # denies file-write* outside the worktree.
                    #
                    # ``agent.isolation: container`` (opt-in,
                    # v0.8.19) spawns each agent in a Docker/
                    # Podman container with the worktree mounted
                    # at /workspace and the parent project absent
                    # from the container's filesystem namespace.
                    # Strongest isolation — escapes can't even
                    # name the parent project's path because it
                    # doesn't exist in the namespace.  Requires
                    # operator-built image; raises clearly if the
                    # image or runtime is missing.
                    _isolation_cli_path: Path | None = None
                    if ctx.git_enabled and _worktree_path is not None:
                        if ctx.agent_isolation == "container":
                            from claw_forge.agent.container import (
                                make_container_wrapper,
                            )
                            _isolation_cli_path = (
                                make_container_wrapper(
                                    worktree_path=_worktree_path,
                                    output_dir=(
                                        _worktree_path
                                        / ".claw-forge" / "container"
                                    ),
                                    runtime_preference=(
                                        ctx.container_runtime_pref
                                    ),
                                    image=ctx.container_image,
                                    extra_mounts=ctx.container_extra_mounts,
                                    extra_env=ctx.container_extra_env,
                                    pull_if_missing=(
                                        ctx.container_pull_if_missing
                                    ),
                                )
                            )
                        else:
                            from claw_forge.agent.sandbox import (
                                make_sandbox_wrapper,
                            )
                            _isolation_cli_path = make_sandbox_wrapper(
                                project_path=ctx.project_path,
                                worktree_path=_worktree_path,
                                output_dir=(
                                    _worktree_path
                                    / ".claw-forge" / "sandbox"
                                ),
                                home_protection=ctx.sandbox_home_protection,
                            )

                    # ── SDK SandboxSettings ──
                    # The SDK's SandboxSettings spawns
                    # ``sandbox-exec`` (macOS) per Bash
                    # subprocess to sandbox the bash command.
                    # When our v0.8.18 Layer 4 wrapper OR v0.8.19
                    # Layer 5 container is active, the entire
                    # ``claude`` process is already isolated at a
                    # broader scope — and macOS forbids nested
                    # ``sandbox_apply`` calls (kernel returns
                    # ``Operation not permitted``, bash exits
                    # with code 71).  Containers similarly can't
                    # invoke sandbox-exec inside themselves.
                    #
                    # When ``_isolation_cli_path`` is set (Layer
                    # 4 or 5 active), disable the SDK's per-Bash
                    # sandbox to avoid the nested-sandbox
                    # collision.  Our wrapper already covers
                    # filesystem isolation (broader than the
                    # SDK's per-bash mechanism) so nothing is
                    # lost — the SDK's sandbox is redundant in
                    # this configuration.  Otherwise (legacy
                    # unsandboxed dispatch on platforms without
                    # Layer 4 or 5 — Windows, Linux pre-bwrap)
                    # keep the SDK's sandbox on as the only
                    # remaining isolation.
                    from claw_forge.agent.sandbox import (
                        _make_sdk_sandbox_settings,
                    )
                    _sandbox = _make_sdk_sandbox_settings(
                        isolation_active=(
                            _isolation_cli_path is not None
                        ),
                    )
                    options = ClaudeAgentOptions(
                        model=_effective_model,
                        cwd=str(_agent_cwd),
                        env=sdk_env,
                        permission_mode="bypassPermissions",
                        hooks=agent_hooks,  # type: ignore[arg-type]
                        settings=json.dumps({"enabledPlugins": {}}),
                        setting_sources=["project"],
                        stderr=_stderr_filter,
                        cli_path=(
                            str(_isolation_cli_path)
                            if _isolation_cli_path is not None
                            else None
                        ),
                        system_prompt=(
                            {
                                "type": "preset",
                                "preset": "claude_code",
                                "append": _agent_directive,
                            }
                            if _agent_directive
                            else None
                        ),
                        can_use_tool=make_can_use_tool(
                            project_dir=_agent_cwd,
                            # When the agent runs in a worktree
                            # (``git_enabled`` and the dispatcher
                            # is using ``.claw-forge/worktrees/``),
                            # the parent ``project_path`` is the
                            # target branch's working tree.  Passing
                            # it here forbids exempt-command
                            # escapes (``git -C <project_path> add
                            # …``, ``python <project_path>/script.
                            # py``) that would write into the target
                            # branch as untracked debris.  When
                            # ``git.enabled: false`` the agent's
                            # cwd IS project_path, so the helper
                            # short-circuits to a no-op.
                            forbidden_jail_root=(
                                ctx.project_path if ctx.git_enabled else None
                            ),
                        ),
                        sandbox=_sandbox,
                    )

                # OUTSIDE LOCK: connect + run (parallel with other agents).
                #
                # Provider rotation on transient provider errors
                # (v0.8.24): when the agent run raises a rate-limit
                # OR 5xx OR network error AND the pool has other
                # healthy providers, trip the current provider's
                # circuit and retry with the next provider in
                # rotation.  Without this, a single overloaded /
                # rate-limited / unreachable provider failed the
                # entire task even when the user had configured
                # 2+ healthy providers — defeating the multi-
                # provider value prop.
                #
                # Rotation criteria (``is_retryable_provider_error``):
                # rate-limit, 5xx server errors, network failures,
                # generic upstream/provider errors.  Client-side
                # errors (4xx other than 429, malformed input,
                # agent runtime errors, sandbox denials) deliberately
                # don't trigger rotation — same request will fail
                # the same way on a different provider, and trying
                # them all just wastes their quota.
                #
                # Only applies when ``pool`` is the credential
                # source (``sdk_provider_name != "env"``);
                # process-env credentials have no alternative.
                # Bails after ``_max_provider_rotations`` retries
                # (bound the worst case).
                from claw_forge.agent.rate_limit import (
                    is_retryable_provider_error,
                )
                _attempted_providers: set[str] = {sdk_provider_name}
                _max_provider_rotations = 3
                full_output: list[str] = []
                output = ""
                success = False
                for _rotation in range(_max_provider_rotations + 1):
                    full_output = []
                    try:
                        async with AgentSession(options) as agent_session:
                            async for msg in agent_session.run(prompt):  # noqa: E501
                                _cls = type(msg).__name__
                                if _cls == "ResultMessage":
                                    _result = getattr(msg, "result", None)
                                    if _result:
                                        full_output.append(str(_result))
                                        await _log_agent(
                                            http, ctx.state_base, ctx.seen_logs,
                                            task_node.id, task_name,
                                            "result", str(_result)[:500],
                                            model=ctx.model,
                                            provider=sdk_provider_name,
                                        )
                                    continue
                                if _cls != "AssistantMessage":
                                    continue
                                content = getattr(msg, "content", None)
                                if not isinstance(content, list):
                                    continue
                                for block in content:
                                    _bcls = type(block).__name__
                                    if _bcls == "TextBlock":
                                        full_output.append(block.text)
                                        await _log_agent(
                                            http, ctx.state_base, ctx.seen_logs,
                                            task_node.id, task_name,
                                            "assistant", block.text[:500],
                                            model=ctx.model,
                                            provider=sdk_provider_name,
                                        )
                                    elif _bcls == "ToolUseBlock":
                                        _tn = getattr(block, "name", "?")
                                        _raw = getattr(block, "input", {})
                                        _ti = _fmt_tool(_tn, _raw)
                                        await _log_agent(
                                            http, ctx.state_base, ctx.seen_logs,
                                            task_node.id, task_name,
                                            "tool_use", f"{_tn} → {_ti}",
                                            model=ctx.model,
                                            provider=sdk_provider_name,
                                        )
                                    elif _bcls == "ToolResultBlock":
                                        _is_err = getattr(block, "is_error", False)
                                        _tc = str(getattr(block, "content", ""))[:300]
                                        await _log_agent(
                                            http, ctx.state_base, ctx.seen_logs,
                                            task_node.id, task_name,
                                            "tool_result", _tc,
                                            level="error" if _is_err else "info",
                                            model=ctx.model,
                                            provider=sdk_provider_name,
                                        )
                                _err = getattr(msg, "error", None)
                                if _err:
                                    raise RuntimeError(
                                        f"Agent error: {_err} — "
                                        "check `claude login` or verify API key in .env"
                                    )
                        output = "\n".join(full_output)
                        if not output.strip():
                            raise RuntimeError(
                                "Agent produced no output — "
                                "check `claude login` or verify API key in .env"
                            )
                        success = True
                        break
                    except Exception as sdk_exc:
                        _retryable = is_retryable_provider_error(
                            str(sdk_exc),
                        )
                        _can_rotate = (
                            ctx.pool is not None
                            and sdk_provider_name != "env"
                            and _retryable
                            and _rotation < _max_provider_rotations
                        )
                        if not _can_rotate:
                            output = str(sdk_exc)
                            success = False
                            await _log_agent(
                                http, ctx.state_base, ctx.seen_logs,
                                task_node.id, task_name,
                                "error", str(sdk_exc)[:500],
                                level="error",
                                model=ctx.model,
                                provider=sdk_provider_name,
                            )
                            break
                        # Transient provider error + rotation
                        # viable: trip the current provider's
                        # circuit so the pool skips it, re-pick
                        # the next provider, rebuild options
                        # with the new env.  Same circuit-trip
                        # mechanism (``mark_provider_rate_limited``)
                        # for any transient error class — the
                        # name is historic, the effect is "this
                        # provider is unavailable for the
                        # circuit-breaker recovery window".
                        # ``_can_rotate`` already gated
                        # ``pool is not None``; assert here so
                        # mypy can narrow the union type.
                        assert ctx.pool is not None
                        ctx.pool.mark_provider_rate_limited(
                            sdk_provider_name,
                        )
                        await _log_agent(
                            http, ctx.state_base, ctx.seen_logs,
                            task_node.id, task_name,
                            "warning",
                            (
                                f"provider error on "
                                f"{sdk_provider_name} "
                                f"({str(sdk_exc)[:120]}); "
                                "rotating to next available"
                            ),
                            level="warning",
                            model=ctx.model,
                            provider=sdk_provider_name,
                        )
                        async with ctx.env_lock:
                            sdk_env, sdk_provider_name = (
                                _resolve_sdk_credentials(ctx.pool)
                            )
                        if (
                            sdk_provider_name == "env"
                            or sdk_provider_name in _attempted_providers
                        ):
                            # Pool exhausted: same provider
                            # returned (all others tripped) or
                            # fallback to env (no more pool
                            # providers).  Fail with a clear
                            # error explaining what happened.
                            output = (
                                f"All {len(_attempted_providers)} "
                                "configured provider(s) tripped "
                                "by transient errors; no fresh "
                                "providers available for retry.  "
                                "Wait for circuit-breaker "
                                "recovery_timeout or add more "
                                "providers."
                            )
                            success = False
                            await _log_agent(
                                http, ctx.state_base, ctx.seen_logs,
                                task_node.id, task_name,
                                "error", output,
                                level="error",
                                model=ctx.model,
                                provider=sdk_provider_name,
                            )
                            break
                        _attempted_providers.add(sdk_provider_name)
                        # Rebuild options with the rotated env.
                        # All other fields are unchanged from
                        # the initial construction above.
                        options = ClaudeAgentOptions(
                            model=_effective_model,
                            cwd=str(_agent_cwd),
                            env=sdk_env,
                            permission_mode="bypassPermissions",
                            hooks=agent_hooks,  # type: ignore[arg-type]
                            settings=json.dumps({"enabledPlugins": {}}),
                            setting_sources=["project"],
                            stderr=_stderr_filter,
                            cli_path=(
                                str(_isolation_cli_path)
                                if _isolation_cli_path is not None
                                else None
                            ),
                            system_prompt=(
                                {
                                    "type": "preset",
                                    "preset": "claude_code",
                                    "append": _agent_directive,
                                }
                                if _agent_directive
                                else None
                            ),
                            can_use_tool=make_can_use_tool(
                                project_dir=_agent_cwd,
                                forbidden_jail_root=(
                                    ctx.project_path if ctx.git_enabled else None
                                ),
                            ),
                            sandbox=_sandbox,
                        )

            # ── Option 2: direct API call via provider pool ───────────────
            # Used when claude CLI is not installed (API-only mode).
            # BUG-11 fix: parse code blocks from LLM output and write
            # them to the project directory.
            elif ctx.pool is not None:
                system_prompt = (
                    "You are an expert software engineer. "
                    "Implement the requested feature precisely and completely. "
                    "Return code in fenced blocks with the filename as the "
                    "info string, e.g.:\n"
                    "```path/to/file.py\n<code>\n```\n\n"
                    f"Project directory: {ctx.project_path}"
                )
                await _log_agent(
                    http, ctx.state_base, ctx.seen_logs,
                    task_node.id, task_name,
                    "assistant", "Sending request to provider pool…",
                    model=ctx.model,
                    provider="pool",  # actual member set after pool.execute returns
                )
                task_complexity = _PLUGIN_COMPLEXITY.get(
                    task_node.plugin_name or "", "medium"
                )
                # Route model: initializer uses plan_model
                _pool_model = (
                    ctx.effective_plan_model
                    if task_node.plugin_name == "initializer"
                    else ctx.model
                )
                response = await ctx.pool.execute(
                    model=_pool_model,
                    messages=[{"role": "user", "content": prompt}],
                    system=system_prompt,
                    max_tokens=8192,
                    complexity=task_complexity,
                )
                output = response.content or ""
                await _log_agent(
                    http, ctx.state_base, ctx.seen_logs,
                    task_node.id, task_name,
                    "result", output[:500],
                    model=ctx.model,
                    provider=response.provider_name,
                )

                # Write any code blocks to disk (BUG-11)
                from claw_forge.output_parser import write_code_blocks

                written_files = write_code_blocks(
                    output, ctx.project_path
                )
                if written_files:
                    output += (
                        f"\n\n--- Files written ({len(written_files)}) ---\n"
                        + "\n".join(f"  • {f}" for f in written_files)
                    )
                success = True

            # ── No executor available ─────────────────────────────────────
            else:
                output = (
                    "No agent executor available.\n"
                    "  • For full autonomous coding: install the claude CLI "
                    "(https://claude.ai/download) and ensure it is in PATH\n"
                    "  • For API-only mode: add a provider with a valid API key "
                    "to claw-forge.yaml"
                )
                success = False

        except asyncio.CancelledError:
            _cancelled = True
            raise

        except Exception as exc:
            output = str(exc)
            success = False

        finally:
            # Cancel periodic auto-checkpoint before any other cleanup
            if _checkpoint_task is not None:
                _checkpoint_task.cancel()
                with suppress(asyncio.CancelledError):
                    await _checkpoint_task
            ctx.active_worktrees.pop(task_node.id, None)

            # ── v0.8.17 snapshot-rollback ─────────────────────────
            # Enforce the run-lifetime invariant: ``project_path``
            # is HEAD-clean before the squash-merge runs.  Any
            # dirt here is either an agent leak (from this task or
            # a concurrent one) OR a pre-existing baseline leftover
            # that smart-cleanup couldn't archive.  Either way,
            # stash it under a leak marker so it's recoverable,
            # then verify ``project_path`` is clean before
            # ``apply_on_completion`` runs the squash.
            #
            # Holds ``git_ops.exclusive_section`` — the same lock
            # that serialises ``squash_merge`` — so this rollback
            # never races with another task's mid-flight squash
            # (which legitimately stages content into
            # ``project_path``'s index).  Concurrent leaks from
            # other in-flight tasks land in this stash too;
            # marker is best-effort attribution.
            #
            # Skipped in ``handle_uncommitted_at_startup: ignore``
            # mode: that mode means "operator manages main's state
            # themselves; harness keeps hands off".  Boot baseline
            # is also skipped in that mode (above), so per-task
            # rollback would have nothing to restore TO and would
            # destroy operator-edited dirt as collateral.
            if ctx.git_enabled and ctx.git_handle_uncommitted != "ignore":
                from claw_forge.git.leak_watch import (
                    project_status_porcelain,
                    stash_leak_with_marker,
                )
                assert ctx.git_ops is not None
                async with ctx.git_ops.exclusive_section():
                    _post_dirt = await asyncio.to_thread(
                        project_status_porcelain, ctx.project_path,
                    )
                    if _post_dirt:
                        _logging.getLogger(__name__).warning(
                            "Task %s window: main has %d "
                            "dirty/untracked path(s) — stashing "
                            "and rolling back: %s",
                            task_node.id,
                            len(_post_dirt),
                            sorted(_post_dirt)[:5],
                        )
                        await asyncio.to_thread(
                            stash_leak_with_marker,
                            ctx.project_path,
                            task_node.id,
                            _post_dirt,
                        )
                        # Verify the invariant restored.  Stash
                        # failure (rare; rejected pre-commit hook,
                        # disk pressure) leaves dirt in place; log
                        # so the operator sees it explicitly
                        # rather than discovering it via squash
                        # corruption later.
                        _post_dirt2 = await asyncio.to_thread(
                            project_status_porcelain, ctx.project_path,
                        )
                        if _post_dirt2:
                            _logging.getLogger(__name__).error(
                                "Task %s: post-rollback main "
                                "STILL has %d dirty path(s) — "
                                "squash-merge will likely fail "
                                "or absorb this dirt.  Manual "
                                "intervention required: %s",
                                task_node.id,
                                len(_post_dirt2),
                                sorted(_post_dirt2)[:5],
                            )

            if _cancelled:
                # Reset racing tasks to pending via HTTP
                with suppress(Exception):
                    await _patch_task(
                        http, ctx.state_base, task_node.id, status="pending",
                    )
                return {"success": False, "output": "cancelled"}  # noqa: B012

            # Persist final status via HTTP
            await _patch_task(
                http, ctx.state_base, task_node.id,
                status="completed" if success else "failed",
                **({"result": {"output": output}} if success else {}),
                **({"error_message": output} if not success else {}),
            )

            # Git: checkpoint + optional merge on success, cleanup on failure
            if ctx.git_enabled:
                assert ctx.git_ops is not None
                merge_result = await ctx.git_ops.apply_on_completion(
                    task_id=task_node.id,
                    slug=_slug,
                    description=task_node.description or None,
                    plugin_name=task_node.plugin_name,
                    steps=task_node.steps or None,
                    worktree_path=_worktree_path,
                    success=success,
                    commit_on_boundary=ctx.git_commit_on_boundary,
                    merge_strategy=ctx.git_merge_strategy,
                    branch_prefix=ctx.git_branch_prefix,
                    target_branch=ctx.default_branch,
                    session_id=ctx.session_id,
                )
                _merge_result_meta = await _set_merged_after_merge(
                    http, ctx.state_base, task_node.id, merge_result,
                    current_merge_retry_count=task_data.get(
                        "merge_retry_count", 0,
                    ),
                    merge_retry_attempts=ctx.git_merge_retry_attempts,
                )
                if _merge_result_meta.get("re_pended"):
                    # Signal the outer wave-loop that this task is
                    # eligible for re-dispatch despite the agent
                    # returning success — see closure below.
                    ctx.pending_merge_retries.add(task_node.id)

    return {"success": success, "output": output}
