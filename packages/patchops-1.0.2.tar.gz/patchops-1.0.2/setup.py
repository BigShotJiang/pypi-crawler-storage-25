from setuptools import setup, find_packages

setup(
    name="patchops",
    version="1.0.2",
    packages=find_packages(),
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "patchops = patchops.cli:main",
        ],
    },
    install_requires=[
        "click",
        "fastapi",
        "uvicorn",
        "sse-starlette",
        "groq",
        "requests",
        "PyGithub",
        "python-dotenv",
        "httpx",
        "flask",
        "gitpython",
    ],
    python_requires=">=3.9",
)
