import sys
import os
import json
import difflib

# Works both locally (from repo root) and in Lambda
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)
))))
from lambdas.shared.utils import safe_call_llm_json, extract_code_block


def lambda_handler(event, context=None):
    """
    Batch Patch Writer Lambda Handler.
    Now with fuzzy matching and line-by-line fallback to ensure patches apply.
    """
    try:
        source_code = event.get("source_code", "")
        vulnerabilities = event.get("vulnerabilities", [])

        if not source_code:
            return {"error": "Missing source_code", "patched_code": "", "completed_fixes": []}
        if not vulnerabilities:
            return {"patched_code": source_code, "completed_fixes": []}

        vulns_str = json.dumps(vulnerabilities, indent=2)

        prompt = f"""You are an elite Application Security Engineer.
You must fix ALL vulnerabilities in the provide source code.

ORIGINAL CODE:
```python
{source_code}
```

VULNERABILITIES TO FIX:
{vulns_str}

CRITICAL RULES:
1. USE SURGICAL SEARCH & REPLACE.
2. The 'search' block must be a SIGNIFICANT chunk of the original code (e.g., entire function or large block) to ensure uniqueness.
3. The 'search' block must match the original code EXACTLY, line for line.
4. If you fix multiple issues in one file, group them into the 'fixes' array.

JSON SCHEMA:
{{
    "fixes": [
        {{
            "vulnerability_type": "<type>",
            "cwe": "<cwe>",
            "changes_made": ["Fix 1", "Fix 2"],
            "modifications": [
                {{
                    "search": "<EXACT block from original source>",
                    "replace": "<Secure result>"
                }}
            ]
        }}
    ]
}}
"""
        batch_result = safe_call_llm_json(prompt, max_tokens=4000, retries=2)
        current_code = source_code
        completed_fixes = []

        for fix in batch_result.get("fixes", []):
            vuln_type = fix.get("vulnerability_type", "Unknown")
            cwe = fix.get("cwe", "")
            modifications = fix.get("modifications", [])
            
            fix_successful = False
            for mod in modifications:
                search_text = mod.get("search", "").strip()
                replace_text = mod.get("replace", "")

                if not search_text: continue

                # 1. Exact Match
                if search_text in current_code:
                    current_code = current_code.replace(search_text, replace_text, 1)
                    fix_successful = True
                else:
                    # 2. Fuzzy Match / Line-by-line fallback
                    # This is the "Root Cause" fix - being more flexible with hallucinated search strings
                    search_lines = [l.strip() for l in search_text.split('\n') if l.strip()]
                    source_lines = current_code.split('\n')
                    
                    best_match_start = -1
                    best_match_score = 0
                    
                    # Look for the block with highest overlap
                    for i in range(len(source_lines) - len(search_lines) + 1):
                        window = [l.strip() for l in source_lines[i : i+len(search_lines)] if l.strip()]
                        if not window: continue
                        
                        score = difflib.SequenceMatcher(None, '\n'.join(search_lines), '\n'.join(window)).ratio()
                        if score > 0.85 and score > best_match_score:
                            best_match_score = score
                            best_match_start = i
                    
                    if best_match_start != -1:
                        # Replace the block
                        new_lines = source_lines[:best_match_start] + [replace_text] + source_lines[best_match_start + len(search_lines):]
                        current_code = '\n'.join(new_lines)
                        fix_successful = True
                    else:
                        print(f"⚠️  WARNING: Could not apply patch for {vuln_type} - Search string not found (even with 85% fuzzy match).")

            if fix_successful:
                completed_fixes.append({"type": vuln_type, "cwe": cwe, "changes_made": fix.get("changes_made", [])})

        return {
            "patched_code": current_code,
            "completed_fixes": completed_fixes,
            "total_vulnerabilities": len(vulnerabilities),
            "successful_patches": len(completed_fixes)
        }

    except Exception as e:
        return {"error": f"Exception: {str(e)}", "patched_code": "", "completed_fixes": []}
