import click
import os
import sys
import subprocess
import threading
import webbrowser
import uvicorn
import patchops

@click.group()
def cli():
    pass

@cli.command()
def scan():
    """Scan current repo for vulnerabilities, patch, and open a PR"""
    click.echo("╔══════════════════════════════════════════╗")
    click.echo("║  🛡  PatchOps — Autonomous Security CLI  ║")
    click.echo("║  Detect → Exploit → Patch → PR           ║")
    click.echo("╚══════════════════════════════════════════╝")
    click.echo("")

    groq_key = click.prompt("GROQ API Key", hide_input=True)
    os.environ["GROQ_API_KEY"] = groq_key

    github_token = click.prompt("GitHub Token (Enter to skip)", default="", hide_input=True)
    if github_token:
        os.environ["GITHUB_TOKEN"] = github_token

    target = os.getcwd()

    github_repo = "khushidubeyokok/PatchOpsTarget"
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True, text=True, cwd=target
        )
        raw_url = result.stdout.strip()
        if raw_url:
            if "github.com/" in raw_url:
                github_repo = raw_url.split("github.com/")[1].replace(".git", "").strip()
            elif "github.com:" in raw_url:
                github_repo = raw_url.split("github.com:")[1].replace(".git", "").strip()
    except Exception:
        pass

    os.environ["PATCHOPS_TARGET"] = target
    os.environ["GITHUB_REPO"] = github_repo

    package_dir = os.path.dirname(os.path.abspath(patchops.__file__))
    base_dir = os.path.dirname(package_dir)
    os.chdir(base_dir)
    sys.path.insert(0, base_dir)

    click.echo(f"→ Target:    {target}")
    click.echo(f"→ Repo:      {github_repo}")
    click.echo(f"→ Dashboard: http://localhost:8000")
    click.echo("→ Press Ctrl+C to stop")
    click.echo("")

    threading.Timer(2.0, lambda: webbrowser.open("http://localhost:8000")).start()

    try:
        from pipeline_api import app as pipeline_app
        uvicorn.run(pipeline_app, host="0.0.0.0", port=8000, reload=False)
    except KeyboardInterrupt:
        click.echo("\nPatchOps stopped.")

def main():
    cli()