use crate::Result;
use std::collections::VecDeque;
use vt100::Parser;

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Rect {
    pub x: u16,
    pub y: u16,
    pub width: u16,
    pub height: u16,
}

/// Mouse tracking mode as set by the remote application
///
/// Terminal applications enable mouse reporting via escape sequences:
/// - Normal mode (1000): Report button press/release
/// - Button event mode (1002): Report press/release and motion while pressed
/// - Any event mode (1003): Report all motion events
/// - SGR extended mode (1006): Extended coordinates for large terminals
///
/// Without mouse mode enabled, sending X11 mouse sequences to the terminal
/// will result in garbage characters being displayed.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub enum MouseMode {
    /// Mouse tracking disabled (default) - do NOT send mouse events to terminal
    #[default]
    Disabled,
    /// Normal tracking mode (1000) - report button press/release
    Normal,
    /// Button event tracking mode (1002) - report press/release + motion while pressed  
    ButtonEvent,
    /// Any event tracking mode (1003) - report all motion
    AnyEvent,
}

impl MouseMode {
    /// Returns true if mouse mode is enabled (any tracking mode active)
    pub fn is_enabled(&self) -> bool {
        !matches!(self, MouseMode::Disabled)
    }
}

/// A line of terminal content with cell information
#[derive(Debug, Clone)]
pub struct ScrollbackLine {
    pub cells: Vec<vt100::Cell>,
    pub cols: u16,
}

impl ScrollbackLine {
    pub fn new(cols: u16) -> Self {
        Self {
            cells: Vec::with_capacity(cols as usize),
            cols,
        }
    }

    pub fn from_screen_row(screen: &vt100::Screen, row: u16, cols: u16) -> Self {
        let mut cells = Vec::with_capacity(cols as usize);
        for col in 0..cols {
            if let Some(cell) = screen.cell(row, col) {
                cells.push(cell.clone());
            }
        }
        Self { cells, cols }
    }
}

/// Terminal emulator using VT100 parser
///
/// Wraps the vt100 crate and provides dirty tracking for efficient rendering.
/// Maintains a scrollback buffer of lines that have scrolled off the top.
/// Tracks mouse mode state for proper X11 mouse event handling.
/// Tracks Kitty keyboard protocol state for modern keyboard input.
pub struct TerminalEmulator {
    parser: Parser,
    rows: u16,
    cols: u16,
    dirty: bool,
    scrollback: VecDeque<ScrollbackLine>,
    scrollback_max_lines: usize,
    last_screen_state: Vec<String>, // For detecting scrolls
    /// Current mouse tracking mode set by the remote application
    mouse_mode: MouseMode,
    /// Whether SGR extended mouse mode (1006) is active
    sgr_mouse_mode: bool,
    /// Kitty keyboard protocol level (0 = disabled, 1-3 = enabled)
    kitty_keyboard_level: u8,
    /// Kitty keyboard protocol flags (for extended features)
    kitty_keyboard_flags: u32,
    /// Scrollback view offset: number of lines scrolled back from the live screen.
    /// 0 = viewing live content; N > 0 = viewing N lines into scrollback history.
    scroll_offset: usize,
}

impl TerminalEmulator {
    /// Extract text from a specific row of the screen
    fn row_text(screen: &vt100::Screen, row: u16, cols: u16) -> String {
        let mut text = String::with_capacity(cols as usize);
        for col in 0..cols {
            if let Some(cell) = screen.cell(row, col) {
                if let Some(c) = cell.contents().chars().next() {
                    text.push(c);
                } else {
                    text.push(' ');
                }
            } else {
                text.push(' ');
            }
        }
        text
    }

    /// Create a new terminal emulator with default scrollback (150 lines)
    pub fn new(rows: u16, cols: u16) -> Self {
        Self::new_with_scrollback(rows, cols, 150)
    }

    /// Create a new terminal emulator with specified scrollback size
    pub fn new_with_scrollback(rows: u16, cols: u16, scrollback_lines: usize) -> Self {
        let parser = Parser::new(rows, cols, 0);
        let screen = parser.screen();
        let last_screen_state = (0..rows)
            .map(|row| Self::row_text(screen, row, cols))
            .collect();

        Self {
            parser,
            rows,
            cols,
            dirty: false,
            scrollback: VecDeque::with_capacity(scrollback_lines),
            scrollback_max_lines: scrollback_lines,
            last_screen_state,
            mouse_mode: MouseMode::Disabled,
            sgr_mouse_mode: false,
            kitty_keyboard_level: 0,
            kitty_keyboard_flags: 0,
            scroll_offset: 0,
        }
    }

    /// Process terminal output data
    pub fn process(&mut self, data: &[u8]) -> Result<()> {
        // Check for mouse mode escape sequences BEFORE processing
        // This ensures we track mouse mode changes as they happen
        self.detect_mouse_mode_changes(data);

        // Check for Kitty keyboard protocol enable/disable sequences
        self.detect_kitty_keyboard_changes(data);

        let screen = self.parser.screen();

        // Capture current screen state before processing
        let current_screen_state: Vec<String> = (0..self.rows)
            .map(|row| Self::row_text(screen, row, self.cols))
            .collect();

        // Capture the top line before processing (in case it scrolls off)
        let top_line_before = ScrollbackLine::from_screen_row(screen, 0, self.cols);

        // Process the data
        self.parser.process(data);

        // Detect scroll up (new content at bottom, old content pushed up)
        // Compare screen states to detect if top line changed and bottom line is new
        let should_add_scrollback = {
            let new_screen = self.parser.screen();
            if !current_screen_state.is_empty() && current_screen_state.len() == self.rows as usize
            {
                let old_top = &current_screen_state[0];
                let new_top = Self::row_text(new_screen, 0, self.cols);
                let old_bottom = current_screen_state.last().unwrap();
                let new_bottom = Self::row_text(new_screen, self.rows - 1, self.cols);

                // If top line changed but bottom is new (different from old bottom), it's a scroll up
                old_top != &new_top && old_bottom != &new_bottom
            } else {
                false
            }
        };

        // Add to scrollback if needed (outside the borrow)
        if should_add_scrollback {
            self.scrollback.push_back(top_line_before);

            // Limit scrollback size
            while self.scrollback.len() > self.scrollback_max_lines {
                self.scrollback.pop_front();
            }
        }

        // Update last screen state
        let new_screen = self.parser.screen();
        self.last_screen_state = (0..self.rows)
            .map(|row| Self::row_text(new_screen, row, self.cols))
            .collect();

        self.dirty = true;
        Ok(())
    }

    /// Add a line to scrollback buffer (public for testing)
    #[cfg(test)]
    pub(crate) fn add_to_scrollback(&mut self, line: ScrollbackLine) {
        self.scrollback.push_back(line);

        // Limit scrollback size
        while self.scrollback.len() > self.scrollback_max_lines {
            self.scrollback.pop_front();
        }
    }

    /// Check if terminal has changed since last render
    pub fn is_dirty(&self) -> bool {
        self.dirty
    }

    /// Mark terminal as clean (after rendering)
    pub fn clear_dirty(&mut self) {
        self.dirty = false;
    }

    /// Get the terminal screen
    pub fn screen(&self) -> &vt100::Screen {
        self.parser.screen()
    }

    /// Get terminal dimensions
    pub fn size(&self) -> (u16, u16) {
        (self.rows, self.cols)
    }

    /// Resize terminal
    pub fn resize(&mut self, rows: u16, cols: u16) {
        // Use vt100's set_size() to preserve terminal content during resize
        // This is critical - Parser::new() would wipe all content!
        self.parser.set_size(rows, cols);
        self.rows = rows;
        self.cols = cols;

        // Update last screen state for new dimensions
        let screen = self.parser.screen();
        self.last_screen_state = (0..rows)
            .map(|row| Self::row_text(screen, row, cols))
            .collect();

        self.dirty = true;
    }

    /// Get the full screen as a rectangle
    pub fn full_screen_rect(&self) -> Rect {
        Rect {
            x: 0,
            y: 0,
            width: self.cols,
            height: self.rows,
        }
    }

    /// Get scrollback buffer size
    pub fn scrollback_lines(&self) -> usize {
        self.scrollback.len()
    }

    /// Get a line from scrollback buffer (0 = oldest, scrollback_lines()-1 = newest)
    pub fn get_scrollback_line(&self, index: usize) -> Option<&ScrollbackLine> {
        self.scrollback.get(index)
    }

    /// Get all scrollback lines
    pub fn scrollback(&self) -> &VecDeque<ScrollbackLine> {
        &self.scrollback
    }

    /// Clear scrollback buffer
    pub fn clear_scrollback(&mut self) {
        self.scrollback.clear();
        self.scroll_offset = 0;
    }

    /// Scroll back (toward older content), capped at the scrollback buffer length.
    ///
    /// Call this when the user scrolls the mouse wheel up.
    pub fn scroll_up(&mut self, lines: usize) {
        let max_offset = self.scrollback.len();
        self.scroll_offset = (self.scroll_offset + lines).min(max_offset);
        self.dirty = true;
    }

    /// Scroll forward (toward live content).
    ///
    /// Call this when the user scrolls the mouse wheel down.
    pub fn scroll_down(&mut self, lines: usize) {
        self.scroll_offset = self.scroll_offset.saturating_sub(lines);
        self.dirty = true;
    }

    /// Return the current scroll offset (0 = live view).
    pub fn scroll_offset(&self) -> usize {
        self.scroll_offset
    }

    /// Return true when the terminal is showing scrollback history (not live view).
    pub fn is_scrolled_back(&self) -> bool {
        self.scroll_offset > 0
    }

    /// Snap back to the live view (offset = 0).
    pub fn reset_scroll(&mut self) {
        if self.scroll_offset != 0 {
            self.scroll_offset = 0;
            self.dirty = true;
        }
    }

    /// Build the visible rows accounting for the current scroll offset.
    ///
    /// Returns `rows` entries, each being either a reference into the scrollback
    /// buffer or `None` meaning "use the corresponding live-screen row".
    ///
    /// Layout (rows = 5, scrollback has lines [A, B, C, D, E], offset = 3):
    ///
    /// ```text
    /// visible row 0  →  scrollback[len-3] = C
    /// visible row 1  →  scrollback[len-2] = D
    /// visible row 2  →  scrollback[len-1] = E
    /// visible row 3  →  live screen row 0
    /// visible row 4  →  live screen row 1
    /// ```
    ///
    /// The returned `Vec` has exactly `rows as usize` entries.
    /// `Some(sb_idx)` means use `self.scrollback[sb_idx]`.
    /// `None` means use `live_row` = (visible_row - first_live_visible_row).
    pub fn scroll_view_indices(&self) -> Vec<Option<usize>> {
        let rows = self.rows as usize;
        let sb_len = self.scrollback.len();
        let offset = self.scroll_offset.min(sb_len);

        // The scrollback lines shown start at `sb_len - offset` and continue
        // until `sb_len - 1` (newest scrollback line), then live rows follow.
        let sb_start = sb_len.saturating_sub(offset);
        let sb_lines_shown = sb_len - sb_start; // = offset (capped at sb_len)

        (0..rows)
            .map(|visible_row| {
                if visible_row < sb_lines_shown {
                    Some(sb_start + visible_row)
                } else {
                    None // live row
                }
            })
            .collect()
    }

    /// Get current mouse tracking mode
    ///
    /// Returns the mouse mode set by the remote application via escape sequences.
    /// If this returns `MouseMode::Disabled`, X11 mouse sequences should NOT be
    /// sent to the terminal (they will appear as garbage characters).
    pub fn mouse_mode(&self) -> MouseMode {
        self.mouse_mode
    }

    /// Check if mouse tracking is enabled
    ///
    /// Returns true if any mouse tracking mode is active (Normal, ButtonEvent, or AnyEvent).
    /// Only send X11 mouse sequences to the terminal when this returns true.
    pub fn is_mouse_enabled(&self) -> bool {
        self.mouse_mode.is_enabled()
    }

    /// Check if SGR extended mouse mode (1006) is active
    ///
    /// SGR mode uses a different escape sequence format for coordinates.
    pub fn is_sgr_mouse_mode(&self) -> bool {
        self.sgr_mouse_mode
    }

    /// Check if terminal is in application cursor mode (DECCKM)
    ///
    /// When enabled, arrow keys send different escape sequences:
    /// - Normal mode: ESC[A (up), ESC[B (down), ESC[C (right), ESC[D (left)
    /// - Application mode: ESCOA, ESCOB, ESCOC, ESCOD
    ///
    /// This mode is enabled by full-screen applications like vim, less, and tmux.
    pub fn is_application_cursor_mode(&self) -> bool {
        // Check if the vt100 parser has application cursor mode enabled
        // The vt100 crate tracks this via the DECCKM mode (mode 1)
        self.parser.screen().application_cursor()
    }

    /// Get current Kitty keyboard protocol level
    ///
    /// Returns the protocol level (0 = disabled, 1-3 = enabled at various levels).
    /// Applications enable this with `CSI > <level> u` sequences.
    pub fn kitty_keyboard_level(&self) -> u8 {
        self.kitty_keyboard_level
    }

    /// Check if Kitty keyboard protocol is enabled
    ///
    /// Returns true if any level (1-3) is active.
    pub fn is_kitty_keyboard_enabled(&self) -> bool {
        self.kitty_keyboard_level > 0
    }

    /// Get Kitty keyboard protocol flags
    pub fn kitty_keyboard_flags(&self) -> u32 {
        self.kitty_keyboard_flags
    }

    /// Detect mouse mode changes from escape sequences in the data
    ///
    /// Scans for DEC private mode set/reset sequences that control mouse tracking:
    /// - ESC [ ? 1000 h/l - Normal tracking mode (enable/disable)
    /// - ESC [ ? 1002 h/l - Button event tracking mode
    /// - ESC [ ? 1003 h/l - Any event tracking mode
    /// - ESC [ ? 1006 h/l - SGR extended mode
    fn detect_mouse_mode_changes(&mut self, data: &[u8]) {
        // Look for CSI ? <mode> h (set) or CSI ? <mode> l (reset)
        // ESC = 0x1b, [ = 0x5b, ? = 0x3f, h = 0x68, l = 0x6c
        let mut i = 0;
        while i + 5 < data.len() {
            // Look for ESC [
            if data[i] == 0x1b && data[i + 1] == 0x5b {
                // Check for ? (DEC private mode)
                if data[i + 2] == 0x3f {
                    // Find the mode number and terminator
                    let start = i + 3;
                    let mut end = start;

                    // Scan for digits
                    while end < data.len() && data[end].is_ascii_digit() {
                        end += 1;
                    }

                    if end > start && end < data.len() {
                        // Parse mode number
                        if let Ok(mode_str) = std::str::from_utf8(&data[start..end]) {
                            if let Ok(mode_num) = mode_str.parse::<u32>() {
                                let terminator = data[end];
                                let enable = terminator == 0x68; // 'h'
                                let disable = terminator == 0x6c; // 'l'

                                if enable || disable {
                                    self.apply_mouse_mode_change(mode_num, enable);
                                }
                            }
                        }
                    }
                }
            }
            i += 1;
        }
    }

    /// Apply a mouse mode change based on DEC private mode number
    fn apply_mouse_mode_change(&mut self, mode: u32, enable: bool) {
        match mode {
            1000 => {
                // Normal tracking mode
                if enable {
                    self.mouse_mode = MouseMode::Normal;
                } else if self.mouse_mode == MouseMode::Normal {
                    self.mouse_mode = MouseMode::Disabled;
                }
            }
            1002 => {
                // Button event tracking mode
                if enable {
                    self.mouse_mode = MouseMode::ButtonEvent;
                } else if self.mouse_mode == MouseMode::ButtonEvent {
                    self.mouse_mode = MouseMode::Disabled;
                }
            }
            1003 => {
                // Any event tracking mode
                if enable {
                    self.mouse_mode = MouseMode::AnyEvent;
                } else if self.mouse_mode == MouseMode::AnyEvent {
                    self.mouse_mode = MouseMode::Disabled;
                }
            }
            1006 => {
                // SGR extended mode (affects coordinate encoding, not tracking mode)
                self.sgr_mouse_mode = enable;
            }
            _ => {}
        }
    }

    /// Detect Kitty keyboard protocol enable/disable sequences
    ///
    /// Scans for Kitty keyboard protocol control sequences:
    /// - CSI > <level> u - Enable protocol at level 1-3
    /// - CSI < u - Disable protocol (return to legacy mode)
    ///
    /// The Kitty keyboard protocol provides:
    /// - Level 1: Disambiguate escape codes (Ctrl+I vs Tab, Ctrl+M vs Enter)
    /// - Level 2: Report event types (press, repeat, release)
    /// - Level 3: Report alternate keys (base key + shifted key)
    fn detect_kitty_keyboard_changes(&mut self, data: &[u8]) {
        // Look for CSI > <level> u (enable) or CSI < u (disable)
        // ESC = 0x1b, [ = 0x5b, > = 0x3e, < = 0x3c, u = 0x75
        let mut i = 0;
        while i + 3 < data.len() {
            // Look for ESC [
            if data[i] == 0x1b && data[i + 1] == 0x5b {
                match data[i + 2] {
                    0x3e => {
                        // '>' - Enable at level
                        let start = i + 3;
                        let mut end = start;

                        // Scan for digits
                        while end < data.len() && data[end].is_ascii_digit() {
                            end += 1;
                        }

                        if end > start && end < data.len() && data[end] == 0x75 {
                            // 'u' terminator
                            // Parse level number
                            if let Ok(level_str) = std::str::from_utf8(&data[start..end]) {
                                if let Ok(level) = level_str.parse::<u8>() {
                                    if level <= 3 {
                                        self.kitty_keyboard_level = level;
                                        log::debug!(
                                            "Kitty keyboard protocol enabled at level {}",
                                            level
                                        );
                                    }
                                }
                            }
                        }
                    }
                    0x3c => {
                        // '<' - Disable (CSI < u = 4 bytes: ESC [ < u)
                        if i + 3 < data.len() && data[i + 3] == 0x75 {
                            // 'u' terminator
                            self.kitty_keyboard_level = 0;
                            self.kitty_keyboard_flags = 0;
                            log::debug!("Kitty keyboard protocol disabled");
                        }
                    }
                    _ => {}
                }
            }
            i += 1;
        }
    }
}

// Tests moved to src/tests/emulator_tests.rs
