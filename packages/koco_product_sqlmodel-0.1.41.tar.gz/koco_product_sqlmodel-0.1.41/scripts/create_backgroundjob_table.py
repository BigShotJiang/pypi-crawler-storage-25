from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Any

from dotenv import load_dotenv
from sqlalchemy import inspect as sa_inspect
from sqlmodel import SQLModel, Session, select

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

load_dotenv(ROOT / ".env")

from koco_product_sqlmodel.dbmodels.aiingestionjob import CAIIngestionJob  # noqa: E402
from koco_product_sqlmodel.dbmodels.backgroundjob import CBackgroundJob  # noqa: E402
from koco_product_sqlmodel.dbmodels.definition import CUser  # noqa: E402,F401
from koco_product_sqlmodel.mdb_connect.init_db_con import mdb_engine  # noqa: E402

AI_INGESTION_JOB_TYPE = "ai_ingestion"


def main() -> None:
    SQLModel.metadata.create_all(mdb_engine, tables=[CBackgroundJob.__table__])
    print("Ensured table exists:", CBackgroundJob.__tablename__)

    inspector = sa_inspect(mdb_engine)
    if not inspector.has_table(CAIIngestionJob.__tablename__):
        print(
            "Legacy table does not exist, nothing to migrate:",
            CAIIngestionJob.__tablename__,
        )
        return

    drop_only_message: str | None = None
    with Session(mdb_engine) as session:
        legacy_jobs = session.exec(select(CAIIngestionJob)).all()
        legacy_count = len(legacy_jobs)
        if legacy_count == 0:
            drop_only_message = "Dropped empty legacy table:"
        else:
            legacy_ids = {job.id for job in legacy_jobs if job.id is not None}
            migrated_ids = set(
                session.exec(
                    select(CBackgroundJob.id).where(
                        CBackgroundJob.job_type == AI_INGESTION_JOB_TYPE,
                        CBackgroundJob.id.in_(legacy_ids),
                    )
                ).all()
            )
            if migrated_ids:
                if migrated_ids == legacy_ids:
                    drop_only_message = (
                        "Legacy jobs were already migrated; dropped table:"
                    )
                else:
                    raise RuntimeError(
                        "Refusing to migrate: cbackgroundjob contains only a partial "
                        "set of legacy caiingestionjob IDs. Resolve the partial "
                        "migration manually."
                    )

        if drop_only_message is None:
            existing_background_count = len(
                session.exec(
                    select(CBackgroundJob.id).where(
                        CBackgroundJob.job_type == AI_INGESTION_JOB_TYPE
                    )
                ).all()
            )
            if existing_background_count:
                raise RuntimeError(
                    "Refusing to migrate: cbackgroundjob already contains "
                    "ai_ingestion rows with different IDs."
                )

            for legacy_job in legacy_jobs:
                sources = _load_json(legacy_job.sources_json, [])
                background_job = CBackgroundJob(
                    id=legacy_job.id,
                    job_type=AI_INGESTION_JOB_TYPE,
                    entity_id=legacy_job.entity_id,
                    entity_type=legacy_job.entity_type,
                    status=legacy_job.status,
                    phase=legacy_job.phase,
                    payload_json={
                        "legacy_table": CAIIngestionJob.__tablename__,
                        "legacy_ingestion_job_id": legacy_job.id,
                        "sources": sources,
                    },
                    state_json={"sources": sources},
                    result_json=None,
                    events_json=_load_json(legacy_job.events_json, []),
                    warnings_json=_load_json(legacy_job.warnings_json, []),
                    error_text=legacy_job.error_text,
                    applied_at=legacy_job.applied_at,
                    user_id=legacy_job.user_id,
                    insdate=legacy_job.insdate,
                    upddate=legacy_job.upddate,
                )
                session.add(background_job)

            session.commit()

            migrated_count = len(
                session.exec(
                    select(CBackgroundJob.id).where(
                        CBackgroundJob.job_type == AI_INGESTION_JOB_TYPE,
                        CBackgroundJob.id.in_(legacy_ids),
                    )
                ).all()
            )
            if migrated_count != legacy_count:
                raise RuntimeError(
                    f"Migration validation failed: expected {legacy_count} rows, "
                    f"found {migrated_count} migrated rows."
                )

    CAIIngestionJob.__table__.drop(mdb_engine, checkfirst=True)
    if drop_only_message is not None:
        print(drop_only_message, CAIIngestionJob.__tablename__)
        return
    print(
        f"Migrated {legacy_count} rows to {CBackgroundJob.__tablename__} and dropped "
        f"{CAIIngestionJob.__tablename__}."
    )


def _load_json(payload: str | None, fallback: Any) -> Any:
    if not payload:
        return fallback
    return json.loads(payload)


if __name__ == "__main__":
    main()
