from create_backgroundjob_table import main

if __name__ == "__main__":
    print(
        "create_aiingestionjob_table.py is deprecated; running "
        "create_backgroundjob_table.py instead."
    )
    main()
