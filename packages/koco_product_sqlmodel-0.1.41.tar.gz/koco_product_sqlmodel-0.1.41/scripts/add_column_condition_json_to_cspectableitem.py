import sqlmodel as sm
import os
import dotenv

dotenv.load_dotenv()

DATABASE_URL_ENV_VARS = ("MARIADB_CONNECTOR_STRING", "DATABASE_URL")


def get_database_url() -> str:
    for env_var in DATABASE_URL_ENV_VARS:
        value = os.getenv(env_var)
        if value:
            return value
    supported_vars = ", ".join(DATABASE_URL_ENV_VARS)
    raise RuntimeError(
        f"Database connection string is not configured. Set one of: {supported_vars}"
    )

def create_mdb_engine():
    engine = sm.create_engine(url=get_database_url())
    return engine


def main():
    with sm.Session(create_mdb_engine()) as session:
        print("Adding column condition_json to cspectableitem...")
        session.exec(
            sm.text(
            "ALTER TABLE cspectableitem ADD COLUMN IF NOT EXISTS condition_json JSON DEFAULT NULL AFTER name"
            )
        )
        print("Committing changes...")
        session.commit()
        print("Done.")

if __name__ == "__main__":
    main()