from __future__ import annotations

from pathlib import Path
import sys

from dotenv import load_dotenv
from sqlmodel import SQLModel

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

load_dotenv(ROOT / ".env")

from koco_product_sqlmodel.dbmodels.appmeta import CAppMeta  # noqa: E402
from koco_product_sqlmodel.dbmodels.definition import CUser  # noqa: E402,F401
from koco_product_sqlmodel.mdb_connect.init_db_con import mdb_engine  # noqa: E402


def main() -> None:
    SQLModel.metadata.create_all(mdb_engine, tables=[CAppMeta.__table__])
    print("Ensured table exists:", CAppMeta.__tablename__)


if __name__ == "__main__":
    main()
