from datetime import datetime
from typing import Any

import sqlalchemy as sa
from sqlalchemy.types import TIMESTAMP
from sqlmodel import Field, SQLModel, text


class CBackgroundJob(SQLModel, table=True):
    __table_args__ = (
        sa.Index("idx_cbackgroundjob_type_status", "job_type", "status"),
        sa.Index("idx_cbackgroundjob_entity", "entity_type", "entity_id"),
        sa.Index("idx_cbackgroundjob_user_id", "user_id"),
        sa.Index("idx_cbackgroundjob_insdate", "insdate"),
    )

    id: int | None = Field(default=None, primary_key=True)
    job_type: str = Field(max_length=64)
    entity_id: int | None = Field(default=None)
    entity_type: str | None = Field(default=None, max_length=64)
    status: str = Field(default="pending", max_length=64)
    phase: str = Field(default="queued", max_length=128)
    payload_json: dict[str, Any] = Field(
        default_factory=dict,
        sa_column=sa.Column(sa.JSON, nullable=False),
    )
    state_json: dict[str, Any] = Field(
        default_factory=dict,
        sa_column=sa.Column(sa.JSON, nullable=False),
    )
    result_json: dict[str, Any] | list[Any] | None = Field(
        default=None,
        sa_column=sa.Column(sa.JSON, nullable=True),
    )
    events_json: list[dict[str, Any]] = Field(
        default_factory=list,
        sa_column=sa.Column(sa.JSON, nullable=False),
    )
    warnings_json: list[dict[str, Any]] = Field(
        default_factory=list,
        sa_column=sa.Column(sa.JSON, nullable=False),
    )
    error_text: str | None = Field(default=None, sa_column=sa.Column(sa.Text()))
    applied_at: datetime | None = Field(
        default=None, sa_column=sa.Column(TIMESTAMP, nullable=True)
    )
    started_at: datetime | None = Field(
        default=None, sa_column=sa.Column(TIMESTAMP, nullable=True)
    )
    finished_at: datetime | None = Field(
        default=None, sa_column=sa.Column(TIMESTAMP, nullable=True)
    )
    user_id: int = Field(default=1, foreign_key="cuser.id")
    upddate: datetime = Field(
        sa_column=sa.Column(
            TIMESTAMP,
            nullable=False,
            server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
        )
    )
    insdate: datetime = Field(
        sa_column=sa.Column(
            TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP")
        )
    )
