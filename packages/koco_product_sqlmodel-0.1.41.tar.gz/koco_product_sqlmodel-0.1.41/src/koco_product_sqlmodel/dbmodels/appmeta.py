from datetime import datetime
from typing import Any

import sqlalchemy as sa
from sqlalchemy.types import TIMESTAMP
from sqlmodel import Field, SQLModel, text


class CAppMetaPost(SQLModel):
    key: str = Field(max_length=128)
    value_json: dict[str, Any] | list[Any] | None = Field(default_factory=dict)
    user_id: int = Field(default=1, foreign_key="cuser.id")


class CAppMetaGet(CAppMetaPost):
    id: int
    upddate: datetime
    insdate: datetime


class CAppMeta(CAppMetaGet, table=True):
    __table_args__ = (
        sa.UniqueConstraint("key", name="uq_cappmeta_key"),
        sa.Index("idx_cappmeta_key", "key"),
    )

    id: int | None = Field(default=None, primary_key=True)
    key: str = Field(max_length=128)
    value_json: dict[str, Any] | list[Any] | None = Field(
        default_factory=dict,
        sa_column=sa.Column(sa.JSON, nullable=True),
    )
    user_id: int = Field(default=1, foreign_key="cuser.id")
    upddate: datetime = Field(
        sa_column=sa.Column(
            TIMESTAMP,
            nullable=False,
            server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
        )
    )
    insdate: datetime = Field(
        sa_column=sa.Column(
            TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP")
        )
    )
