from datetime import datetime

import sqlalchemy as sa
from sqlalchemy.types import TIMESTAMP
from sqlmodel import Field, SQLModel, text


class CAIIngestionJob(SQLModel, table=True):
    __table_args__ = (
        sa.Index("idx_caiingestionjob_entity", "entity_type", "entity_id"),
        sa.Index("idx_caiingestionjob_status", "status"),
        sa.Index("idx_caiingestionjob_user_id", "user_id"),
    )

    id: int | None = Field(default=None, primary_key=True)
    entity_id: int = Field()
    entity_type: str = Field(default="family", max_length=64)
    status: str = Field(default="pending", max_length=64)
    phase: str = Field(default="queued", max_length=128)
    sources_json: str = Field(
        default="[]",
        sa_column=sa.Column(sa.Text(), nullable=False, server_default=text("'[]'")),
    )
    events_json: str = Field(
        default="[]",
        sa_column=sa.Column(sa.Text(), nullable=False, server_default=text("'[]'")),
    )
    warnings_json: str = Field(
        default="[]",
        sa_column=sa.Column(sa.Text(), nullable=False, server_default=text("'[]'")),
    )
    error_text: str | None = Field(default=None, sa_column=sa.Column(sa.Text()))
    applied_at: datetime | None = Field(default=None, sa_column=sa.Column(TIMESTAMP, nullable=True))
    user_id: int = Field(default=1, foreign_key="cuser.id")
    upddate: datetime = Field(
        sa_column=sa.Column(
            TIMESTAMP,
            nullable=False,
            server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"),
        )
    )
    insdate: datetime = Field(
        sa_column=sa.Column(
            TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP")
        )
    )
