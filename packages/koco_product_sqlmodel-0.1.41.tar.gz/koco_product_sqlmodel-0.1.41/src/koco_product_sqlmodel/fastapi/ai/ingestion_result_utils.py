from __future__ import annotations

from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import koco_product_sqlmodel.dbmodels.models_enums as model_enums
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
	IngestionResult,
	IngestionApplication,
	IngestionArticle,
	IngestionFamilyPatch,
	IngestionFigure,
	IngestionOption,
	IngestionSpectable,
	IngestionEvidence,
	IngestionWarning,
)

SUPPORTED_URL_TYPES = (
	"photo",
	"supplier_site",
	"drawing",
	"datasheet",
	"speed curves",
	"screw_option",
	"step",
	"2D drawing",
	"manual",
	"software",
	"3D models",
	"certifications",
	"3D drawings",
	"catalog",
	"accessories",
	"firmware",
)
SUPPORTED_FIGURE_TYPES = (
	"photo",
	"drawing",
	"2D drawing",
	"3D drawings",
	"speed curves",
)
_SUPPORTED_URL_TYPE_LOOKUP = {
	" ".join(url_type.lower().split()): url_type for url_type in SUPPORTED_URL_TYPES
}
_SUPPORTED_FIGURE_TYPE_LOOKUP = {
	" ".join(figure_type.lower().split()): figure_type
	for figure_type in SUPPORTED_FIGURE_TYPES
}
_STORAGE_URL_TYPE_MAP = {
	"speed curves": model_enums.CUrlTypeEnum.speed_curves.value,
	"2D drawing": model_enums.CUrlTypeEnum.drawings_2D.value,
}
_STORAGE_DOCUMENT_TYPE_MAP = {
	"speed curves": model_enums.CDocumentType.speed_curves.value,
	"2D drawing": model_enums.CDocumentType.drawings_2D.value,
}
DEFAULT_URL_TYPE = model_enums.CUrlTypeEnum.supplier_site.value
DEFAULT_FIGURE_TYPE = "drawing"


def merge_warnings(*warning_sets: list[IngestionWarning]) -> list[IngestionWarning]:
	merged: list[IngestionWarning] = []
	seen: set[tuple[str, str]] = set()
	for warning_list in warning_sets:
		for warning in warning_list:
			key = (warning.code, warning.message)
			if key in seen:
				continue
			seen.add(key)
			merged.append(warning)
	return merged


def canonical_article_name(
	article_name: str | None, article_name_map: dict[str, str]
) -> str | None:
	if not article_name:
		return None
	return article_name_map.get(article_name.strip().lower())


def _canonical_type_key(raw_type: str | None) -> str:
	return " ".join((raw_type or "").strip().lower().split())


def normalize_url_type(raw_type: str | None, url: str | None) -> str:
	canonical = _SUPPORTED_URL_TYPE_LOOKUP.get(_canonical_type_key(raw_type))
	if canonical:
		return canonical

	suffix = Path(urlparse(url or "").path).suffix.lower()
	if suffix == ".pdf":
		return model_enums.CUrlTypeEnum.datasheet.value
	if suffix in {".jpg", ".jpeg", ".png", ".webp"}:
		return "photo"
	if suffix in {".step", ".stp"}:
		return model_enums.CUrlTypeEnum.step.value
	if suffix in {".dwg", ".dxf"}:
		return model_enums.CUrlTypeEnum.drawing.value
	if suffix in {".iges", ".igs", ".stl"}:
		return model_enums.CUrlTypeEnum.models_3D.value
	return DEFAULT_URL_TYPE


def normalize_figure_type(raw_type: str | None) -> str:
	canonical = _SUPPORTED_FIGURE_TYPE_LOOKUP.get(_canonical_type_key(raw_type))
	if canonical:
		return canonical
	return DEFAULT_FIGURE_TYPE


def to_storage_url_type(raw_type: str | None, url: str | None) -> str:
	normalized = normalize_url_type(raw_type, url)
	return _STORAGE_URL_TYPE_MAP.get(normalized, normalized)


def to_storage_document_type(raw_type: str | None) -> str:
	normalized = normalize_figure_type(raw_type)
	return _STORAGE_DOCUMENT_TYPE_MAP.get(normalized, normalized)


def allows_embedded_photo(extracted_figure) -> bool:
	return extracted_figure.extraction_method in {"embedded_image", "downloaded_image"}


def normalize_finding(finding):
	default_evidence_source_ids(
		source_id=finding.source_id,
		family_patch=finding.family_patch,
		articles=finding.articles,
		applications=finding.applications,
		options=finding.options,
		family_spectables=finding.family_spectables,
		article_spectables=finding.article_spectables,
		figures=finding.figures,
		evidence=finding.evidence,
	)
	return finding


def normalize_result(result: IngestionResult) -> IngestionResult:
	articles: list[IngestionArticle] = []
	seen_articles: set[str] = set()
	for article in result.articles:
		key = article.article.strip().lower()
		if not key or key in seen_articles:
			continue
		seen_articles.add(key)
		if article.order_priority <= 0:
			article.order_priority = 100 - len(articles)
		articles.append(article)
	result.articles = articles

	article_name_map = {
		article.article.strip().lower(): article.article for article in result.articles
	}
	result.applications = dedupe_by_key(
		result.applications, key_builder=lambda item: item.application.strip().lower()
	)
	result.options = dedupe_by_key(
		result.options,
		key_builder=lambda item: (
			f"{item.type.strip().lower()}|{(item.category or '').strip().lower()}|"
			f"{item.option.strip().lower()}"
		),
	)
	result.family_spectables = [
		table for table in result.family_spectables if table.name.strip() and table.items
	]
	article_tables: list[IngestionSpectable] = []
	for table in result.article_spectables:
		canonical_name = canonical_article_name(table.article_name, article_name_map)
		if not table.name.strip() or not table.items or not canonical_name:
			continue
		table.article_name = canonical_name
		article_tables.append(table)
	result.article_spectables = article_tables

	normalized_urls: list[Any] = []
	for url in result.urls:
		supplier_url = (url.supplier_url or "").strip() or None
		koco_url = (url.KOCO_url or "").strip() or None
		if not supplier_url and not koco_url:
			continue
		url.supplier_url = supplier_url
		url.KOCO_url = koco_url
		if url.parent == "article":
			canonical_name = canonical_article_name(url.article_name, article_name_map)
			if not canonical_name:
				continue
			url.article_name = canonical_name
		else:
			url.article_name = None
		url.type = normalize_url_type(url.type, supplier_url or koco_url)
		if url.description:
			url.description = url.description.strip()
		normalized_urls.append(url)
	result.urls = dedupe_by_key(
		normalized_urls,
		key_builder=lambda item: (
			f"{item.parent}|{(item.article_name or '').strip().lower()}|"
			f"{(item.type or '').strip().lower()}|{(item.supplier_url or '').strip().lower()}|"
			f"{(item.KOCO_url or '').strip().lower()}"
		),
	)

	normalized_figures: list[IngestionFigure] = []
	for figure in result.figures:
		if not figure.source_id or not figure.source_figure_id:
			continue
		if figure.parent == "article":
			canonical_name = canonical_article_name(figure.article_name, article_name_map)
			if not canonical_name:
				continue
			figure.article_name = canonical_name
		else:
			figure.article_name = None
		figure.type = normalize_figure_type(figure.type)
		if figure.description:
			figure.description = figure.description.strip()
		normalized_figures.append(figure)
	result.figures = dedupe_by_key(
		normalized_figures,
		key_builder=lambda item: (
			f"{item.source_id}|{item.source_figure_id}|{item.parent}|"
			f"{(item.article_name or '').strip().lower()}|{item.type.strip().lower()}"
		),
	)
	return result


def default_evidence_source_ids(
	*,
	source_id: int,
	family_patch: IngestionFamilyPatch,
	articles: list[IngestionArticle],
	applications: list[IngestionApplication],
	options: list[IngestionOption],
	family_spectables: list[IngestionSpectable],
	article_spectables: list[IngestionSpectable],
	figures: list[IngestionFigure],
	evidence: list[IngestionEvidence],
) -> None:
	for entry in family_patch.evidence:
		if entry.source_id is None:
			entry.source_id = source_id
	for collection in (
		articles,
		applications,
		options,
		family_spectables,
		article_spectables,
	):
		for item in collection:
			for entry in item.evidence:
				if entry.source_id is None:
					entry.source_id = source_id
	for figure in figures:
		if figure.source_id is None:
			figure.source_id = source_id
		for entry in figure.evidence:
			if entry.source_id is None:
				entry.source_id = source_id
	for entry in evidence:
		if entry.source_id is None:
			entry.source_id = source_id


def dedupe_by_key(items: list[Any], *, key_builder) -> list[Any]:
	result: list[Any] = []
	seen: set[str] = set()
	for item in items:
		key = key_builder(item)
		if not key or key in seen:
			continue
		seen.add(key)
		result.append(item)
	return result
