from __future__ import annotations

import asyncio
import json
import os
import threading

from fastapi import HTTPException
from sqlmodel import Session, select

import koco_product_sqlmodel.dbmodels.definition as sqlm
import koco_product_sqlmodel.mdb_connect.filedata as mdb_file
import koco_product_sqlmodel.mdb_connect.families as mdb_fam
from koco_product_sqlmodel.fastapi.ai.config import get_ai_settings
from koco_product_sqlmodel.fastapi.ai.ingestion_copy import generate_english_copy
from koco_product_sqlmodel.fastapi.ai.ingestion_extraction_common import (
	MAX_COMBINED_SOURCE_TEXT_CHARS,
	MAX_EXPANDED_TABLES_PER_SOURCE,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_result_utils import (
	allows_embedded_photo,
	merge_warnings,
	normalize_result,
	normalize_finding,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_extractors import (
	IngestionSourceExtractionError,
	expand_related_url_sources,
	extract_file_source,
	extract_url_source,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_generation import (
	RELATED_SOURCE_PLAN_MAX_SELECTIONS,
	generate_source_figure_finding,
	generate_source_finding,
	merge_source_findings,
	plan_related_source_expansion,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_persistence import (
	IngestionPersistenceService,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
	ExtractedFigure,
	ExtractedSourceContent,
	IngestionJobCreateRequest,
	IngestionResult,
	IngestionEvent,
	IngestionJob,
	IngestionSource,
	IngestionSourceFigureFinding,
	IngestionSourceFinding,
	IngestionWarning,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_repository import (
	IngestionJobRepository,
	utcnow,
)
from koco_product_sqlmodel.fastapi.ai.llm import LLMStreamer
from koco_product_sqlmodel.mdb_connect.init_db_con import mdb_engine


TERMINAL_JOB_STATUSES = {"completed", "failed", "applied"}
DEFAULT_EVENT_POLL_INTERVAL = 0.5
MAX_IDLE_POLLS = 2_400
FILEDATA_ENTITY_TYPES_BY_INGESTION_ENTITY = {
	"family": "cfamily",
	"article": "carticle",
	"product_group": "cproductgroup",
	"catalog": "ccatalog",
}


class IngestionService:
	def __init__(
		self,
		*,
		llm_streamer: LLMStreamer | None = None,
		repository: IngestionJobRepository | None = None,
		persistence: IngestionPersistenceService | None = None,
	) -> None:
		self.llm_streamer = llm_streamer
		self.repository = repository or IngestionJobRepository()
		self.persistence = persistence or IngestionPersistenceService()

	def create_job(
		self, *, payload: IngestionJobCreateRequest, user_id: int
	) -> IngestionJob:
		self._ensure_entity_is_empty(
			entity_id=payload.entity_id,
			entity_type=payload.entity_type,
		)
		sources = self._build_sources(
			entity_id=payload.entity_id,
			entity_type=payload.entity_type,
			urls=payload.urls,
			filedata_ids=payload.filedata_ids,
		)
		record = self.repository.create_job(
			entity_id=payload.entity_id,
			entity_type=payload.entity_type,
			user_id=user_id,
			sources=sources,
		)
		self.start_job_thread(record.id)
		return self.repository.get_job(record.id)

	def retry_job(self, *, job_id: int) -> IngestionJob:
		job = self.repository.get_job(job_id)
		if job.status == "running":
			raise HTTPException(status_code=409, detail="Ingestion job is already running")
		if job.applied_at is not None:
			raise HTTPException(
				status_code=409, detail="Applied ingestion jobs cannot be retried"
			)
		self._ensure_entity_is_empty(
			entity_id=job.entity_id,
			entity_type=job.entity_type,
		)
		self.persistence.cleanup_job_figure_previews(job_id)
		reset = self.repository.reset_job(job_id)
		self.start_job_thread(reset.id)
		return reset

	def get_job(self, *, job_id: int) -> IngestionJob:
		return self.repository.get_job(job_id)

	async def get_event_stream(self, *, job_id: int):
		await asyncio.to_thread(self.repository.get_job, job_id)
		last_sequence = 0
		idle_polls = 0
		while True:
			events = await asyncio.to_thread(self.repository.get_events, job_id)
			new_events = [event for event in events if event.sequence > last_sequence]
			if new_events:
				idle_polls = 0
				for event in new_events:
					last_sequence = event.sequence
					yield self._format_sse(event)
			else:
				idle_polls += 1
				yield ": keepalive\n\n"

			job = await asyncio.to_thread(self.repository.get_job, job_id)
			if job.status in TERMINAL_JOB_STATUSES and last_sequence >= len(events):
				break
			if idle_polls >= MAX_IDLE_POLLS:
				break
			await asyncio.sleep(DEFAULT_EVENT_POLL_INTERVAL)

	def _append_job_event(
		self,
		job_id: int,
		*,
		event_type: str,
		message: str,
		source_id: int | None = None,
		meta: dict[str, object] | None = None,
	) -> None:
		self.repository.append_event(
			job_id,
			event_type=event_type,
			message=message,
			source_id=source_id,
			meta=meta,
		)

	def _summarize_finding(self, finding: IngestionSourceFinding) -> dict[str, int]:
		return {
			"article_count": len(finding.articles),
			"application_count": len(finding.applications),
			"option_count": len(finding.options),
			"table_count": len(finding.family_spectables)
			+ len(finding.article_spectables),
			"url_count": len(finding.urls),
			"figure_count": len(finding.figures),
		}

	def _summarize_result(self, result: IngestionResult) -> dict[str, int]:
		return {
			"article_count": len(result.articles),
			"application_count": len(result.applications),
			"option_count": len(result.options),
			"family_table_count": len(result.family_spectables),
			"article_table_count": len(result.article_spectables),
			"table_count": len(result.family_spectables) + len(result.article_spectables),
			"url_count": len(result.urls),
			"figure_count": len(result.figures),
			"warning_count": len(result.warnings),
		}

	def _format_count_summary(
		self,
		counts: dict[str, int],
		*,
		keys: list[str],
		labels: dict[str, str] | None = None,
	) -> str:
		parts: list[str] = []
		for key in keys:
			if key not in counts:
				continue
			label = labels[key] if labels and key in labels else key.removesuffix("_count").replace("_", " ")
			parts.append(f"{counts[key]} {label}")
		return ", ".join(parts)

	def _save_generated_data(
		self, *, job_id: int, user_id: int, result: IngestionResult
	) -> IngestionJob:
		job = self.repository.get_job(job_id)
		if job.applied_at is not None:
			raise HTTPException(
				status_code=409, detail="Ingestion job has already been applied"
			)
		normalized_result = self._normalize_result(result.model_copy(deep=True))
		self._ensure_entity_is_empty(
			entity_id=job.entity_id,
			entity_type=job.entity_type,
		)

		self.repository.update_job_state(job_id, phase="applying")
		result_counts = self._summarize_result(normalized_result)
		self._append_job_event(
			job_id,
			event_type="apply.started",
			message=(
				"Saving extracted catalog data "
				f"({self._format_count_summary(result_counts, keys=['article_count', 'application_count', 'option_count', 'table_count', 'url_count', 'figure_count'])})"
			),
			meta=result_counts,
		)

		try:
			apply_warnings = self.persistence.save_generated_data(
				job_id=job_id,
				entity_id=job.entity_id,
				entity_type=job.entity_type,
				user_id=user_id,
				result=normalized_result,
				progress_callback=lambda event_type, message, meta=None: self._append_job_event(
					job_id,
					event_type=event_type,
					message=message,
					meta=meta,
				),
			)
		except Exception as exc:
			self.repository.update_job_state(
				job_id,
				phase="apply_failed",
				error_text=str(exc),
			)
			self._append_job_event(job_id, event_type="apply.failed", message=str(exc))
			raise

		applied_at = utcnow()
		final_warnings = self._merge_warnings(job.warnings, apply_warnings)
		self.repository.update_job_state(
			job_id,
			status="applied",
			phase="applied",
			applied_at=applied_at,
			warnings=final_warnings,
			error_text=None,
		)
		for warning in apply_warnings:
			self._append_job_event(
				job_id,
				event_type="warning",
				message=warning.message,
				meta={"code": warning.code},
			)
		self._append_job_event(
			job_id,
			event_type="apply.completed",
			message="AI ingestion saved to the selected entity",
			meta={
				**result_counts,
				"warning_count": len(final_warnings),
			},
		)
		self.persistence.cleanup_job_figure_previews(job_id)
		return self.repository.get_job(job_id)

	def start_job_thread(self, job_id: int) -> None:
		worker = threading.Thread(
			target=self.process_job,
			args=(job_id,),
			daemon=True,
			name=f"ai-ingestion-{job_id}",
		)
		worker.start()

	def process_job(self, job_id: int) -> None:
		collected_warnings: list[IngestionWarning] = []
		source_failures: dict[int, str] = {}
		try:
			self._ensure_llm()
			job_record = self.repository.get_record(job_id)
			if job_record is None:
				raise HTTPException(status_code=404, detail="Ingestion job not found")
			job = self.repository.update_job_state(
				job_id, status="running", phase="validating", error_text=None
			)
			self._append_job_event(
				job_id, event_type="run.started", message="Ingestion job started"
			)
			self._ensure_entity_is_empty(
				entity_id=job.entity_id,
				entity_type=job.entity_type,
			)
			self.persistence.cleanup_job_figure_previews(job_id)

			source_findings: list[IngestionSourceFinding] = []
			extracted_figures_by_source: dict[int, dict[int, ExtractedFigure]] = {}

			for source in job.sources:
				self.repository.update_job_state(job_id, phase=f"extracting.{source.id}")
				self.repository.update_source(
					job_id, source.id, status="processing", error_text=None
				)
				self._append_job_event(
					job_id,
					event_type="source.started",
					message=f"Processing source {source.filename or source.url or source.id}",
					source_id=source.id,
				)
				try:

					def emit_source_progress(
						event_type: str,
						message: str,
						meta: dict[str, object] | None = None,
					) -> None:
						self._append_job_event(
							job_id,
							event_type=event_type,
							message=message,
							source_id=source.id,
							meta=meta,
						)

					emit_source_progress(
						"source.extract.started",
						f"Extracting source content for {source.filename or source.url or source.id}",
					)
					extracted = self._extract_source(
						source,
						entity_id=job.entity_id,
						entity_type=job.entity_type,
						progress_callback=emit_source_progress,
					)
					if extracted.figures:
						extracted_figures_by_source[source.id] = {
							figure.figure_id: figure for figure in extracted.figures
						}
					emit_source_progress(
						"source.extract.completed",
						f"Extracted source content for {source.filename or source.url or source.id}",
						{
							"mime_type": extracted.mime_type or "unknown",
							"table_count": len(extracted.tables),
							"figure_count": len(extracted.figures),
							"text_char_count": len(extracted.text),
						},
					)
					self.repository.update_source(
						job_id,
						source.id,
						status="extracted",
						mime_type=extracted.mime_type,
						filename=source.filename or extracted.title,
					)
					for warning in extracted.warnings:
						collected_warnings.append(warning)
						self._append_job_event(
							job_id,
							event_type="warning",
							message=warning.message,
							source_id=source.id,
							meta={"code": warning.code},
						)
					emit_source_progress(
						"source.analysis.started",
						f"Generating structured findings for {source.filename or source.url or source.id}",
					)
					emit_source_progress(
						"source.analysis.progress",
						"Preparing source finding prompt",
						{
							"text_char_count": len(extracted.text),
							"table_count": len(extracted.tables),
							"figure_count": len(extracted.figures),
						},
					)
					finding = self._generate_source_finding(
						entity_id=job.entity_id,
						entity_type=job.entity_type,
						source=source,
						extracted=extracted,
					)
					source_summary = self._summarize_finding(finding)
					emit_source_progress(
						"source.analysis.progress",
						(
							"Structured findings created: "
							+ self._format_count_summary(
								source_summary,
								keys=[
									"article_count",
									"application_count",
									"option_count",
									"table_count",
									"url_count",
								],
							)
						),
						source_summary,
					)
					if extracted.figures:
						emit_source_progress(
							"source.figure_analysis.started",
							f"Classifying {len(extracted.figures)} extracted figures",
							{"figure_count": len(extracted.figures)},
						)
						try:
							figure_finding = self._generate_source_figure_finding(
								entity_id=job.entity_id,
								entity_type=job.entity_type,
								source=source,
								extracted=extracted,
								article_candidates=[
									article.article for article in finding.articles
								],
							)
						except Exception as exc:
							emit_source_progress(
								"source.figure_analysis.failed",
								(
									"Figure analysis failed for "
									f"{source.filename or source.url or source.id}: {exc}"
								),
								{"figure_count": len(extracted.figures)},
							)
							finding.warnings.append(
								IngestionWarning(
									code="figure_analysis_failed",
									message=(
										f"Figure analysis failed for "
										f"{source.filename or source.url or source.id}: {exc}"
									),
								)
							)
						else:
							finding.figures.extend(figure_finding.figures)
							finding.warnings.extend(figure_finding.warnings)
							emit_source_progress(
								"source.figure_analysis.completed",
								(
									f"Kept {len(figure_finding.figures)} figures for "
									f"{source.filename or source.url or source.id}"
								),
								{
									"figure_count": len(figure_finding.figures),
									"warning_count": len(figure_finding.warnings),
								},
							)
					emit_source_progress(
						"source.analysis.completed",
						f"Generated structured findings for {source.filename or source.url or source.id}",
						self._summarize_finding(finding),
					)
					source_findings.append(self._normalize_finding(finding))
					self.repository.update_source(job_id, source.id, status="completed")
					self._append_job_event(
						job_id,
						event_type="source.completed",
						message=f"Completed source {source.filename or source.url or source.id}",
						source_id=source.id,
						meta=self._summarize_finding(finding),
					)
				except Exception as exc:
					message = str(exc)
					source_failures[source.id] = message
					collected_warnings.append(
						IngestionWarning(
							code="source_failed",
							message=f"Source {source.filename or source.url or source.id} failed: {message}",
						)
					)
					self.repository.update_source(
						job_id, source.id, status="failed", error_text=message
					)
					self._append_job_event(
						job_id,
						event_type="source.failed",
						message=message,
						source_id=source.id,
					)

			if not source_findings:
				raise RuntimeError(
					self._format_no_usable_sources_error(
						sources=job.sources,
						source_failures=source_failures,
					)
				)

			self.repository.update_job_state(job_id, phase="merging")
			self._append_job_event(
				job_id,
				event_type="merge.started",
				message=f"Merging findings from {len(source_findings)} extracted sources",
				meta={"source_count": len(source_findings)},
			)
			self._append_job_event(
				job_id,
				event_type="merge.progress",
				message="Combining source findings into one structured result",
				meta={"source_count": len(source_findings)},
			)
			generated_data = self._merge_source_findings(
				entity_id=job.entity_id,
				entity_type=job.entity_type,
				findings=source_findings,
			)
			generated_data = self._normalize_result(generated_data)
			merged_result_summary = self._summarize_result(generated_data)
			self._append_job_event(
				job_id,
				event_type="merge.progress",
				message=(
					"Merged structured result: "
					+ self._format_count_summary(
						merged_result_summary,
						keys=[
							"article_count",
							"application_count",
							"option_count",
							"table_count",
							"url_count",
							"figure_count",
						],
					)
				),
				meta=merged_result_summary,
			)
			generated_data, figure_warnings = self.persistence.materialize_figures(
				job_id=job_id,
				result=generated_data,
				extracted_figures_by_source=extracted_figures_by_source,
				progress_callback=lambda event_type, message, meta=None: self._append_job_event(
					job_id,
					event_type=event_type,
					message=message,
					meta=meta,
				),
			)
			collected_warnings.extend(figure_warnings)
			family = self._get_entity_family(
				entity_id=job.entity_id,
				entity_type=job.entity_type,
			)
			self._append_job_event(
				job_id,
				event_type="merge.copy.started",
				message=(
					"Generating English copy for the selected entity and "
					f"{len(generated_data.articles)} articles"
				),
				meta={"article_count": len(generated_data.articles)},
			)
			generated_data, text_warnings = self._generate_english_copy(
				result=generated_data,
				family_name=family.family if family else "Unknown family",
				progress_callback=lambda event_type, message, meta=None: self._append_job_event(
					job_id,
					event_type=event_type,
					message=message,
					meta=meta,
				),
			)
			self._append_job_event(
				job_id,
				event_type="merge.copy.completed",
				message="Finished generating English copy",
				meta={
					"article_count": len(generated_data.articles),
					"warning_count": len(text_warnings),
				},
			)
			collected_warnings.extend(text_warnings)
			merged_warnings = self._merge_warnings(
				generated_data.warnings, collected_warnings
			)
			generated_data.warnings = merged_warnings
			final_result_summary = self._summarize_result(generated_data)
			self.repository.update_job_state(
				job_id,
				warnings=merged_warnings,
				error_text=None,
			)
			self._append_job_event(
				job_id,
				event_type="merge.completed",
				message=(
					"Merge ready for apply: "
					+ self._format_count_summary(
						final_result_summary,
						keys=[
							"article_count",
							"application_count",
							"option_count",
							"table_count",
							"url_count",
							"figure_count",
							"warning_count",
						],
					)
				),
				meta=final_result_summary,
			)
			self._save_generated_data(
				job_id=job_id,
				user_id=job_record.user_id,
				result=generated_data,
			)
		except Exception as exc:
			self.repository.update_job_state(
				job_id,
				status="failed",
				phase="failed",
				warnings=collected_warnings,
				error_text=str(exc),
			)
			self._append_job_event(job_id, event_type="run.failed", message=str(exc))

	def _build_sources(
		self,
		*,
		entity_id: int,
		entity_type: str,
		urls: list[str],
		filedata_ids: list[int],
	) -> list[IngestionSource]:
		sources: list[IngestionSource] = []
		next_source_id = 1
		storage_entity_type = self._get_filedata_entity_type(entity_type)

		normalized_urls: list[str] = []
		for raw_url in urls:
			candidate = raw_url.strip()
			if candidate and candidate not in normalized_urls:
				normalized_urls.append(candidate)
		for url in normalized_urls:
			sources.append(
				IngestionSource(id=next_source_id, source_type="url", url=url, status="pending")
			)
			next_source_id += 1

		normalized_file_ids: list[int] = []
		for filedata_id in filedata_ids:
			if filedata_id not in normalized_file_ids:
				normalized_file_ids.append(filedata_id)
		for filedata_id in normalized_file_ids:
			filedata = mdb_file.get_file_db_by_id(filedata_id)
			if filedata is None:
				raise HTTPException(
					status_code=400, detail=f"Filedata {filedata_id} does not exist"
				)
			if filedata.entity_type != storage_entity_type or filedata.entity_id != entity_id:
				raise HTTPException(
					status_code=400,
					detail=(
						f"Filedata {filedata_id} is not attached to the selected "
						f"{entity_type}"
					),
				)
			sources.append(
				IngestionSource(
					id=next_source_id,
					source_type="file",
					filedata_id=filedata.id,
					mime_type=filedata.mimetype,
					filename=filedata.oldfilename,
					status="pending",
				)
			)
			next_source_id += 1

		if not sources:
			raise HTTPException(status_code=400, detail="Provide at least one URL or file")
		return sources

	def _require_supported_entity_type(self, *, entity_type: str) -> None:
		if entity_type != "family":
			raise HTTPException(
				status_code=400,
				detail="AI ingestion currently supports entity_type='family' only",
			)

	def _get_filedata_entity_type(self, entity_type: str) -> str:
		storage_entity_type = FILEDATA_ENTITY_TYPES_BY_INGESTION_ENTITY.get(entity_type)
		if storage_entity_type is None:
			raise HTTPException(
				status_code=400,
				detail=f"Unsupported entity_type '{entity_type}'",
			)
		return storage_entity_type

	def _ensure_llm(self) -> None:
		if self.llm_streamer is not None:
			return
		self.llm_streamer = LLMStreamer(get_ai_settings())

	def _extract_source(
		self,
		source: IngestionSource,
		*,
		entity_id: int,
		entity_type: str,
		progress_callback=None,
	) -> ExtractedSourceContent:
		if source.source_type == "url":
			extracted = extract_url_source(source, progress_callback=progress_callback)
			if not extracted.related_candidates:
				return extracted
			assert self.llm_streamer is not None
			family = self._get_entity_family(entity_id=entity_id, entity_type=entity_type)
			family_name = family.family if family else "Unknown family"
			if progress_callback is not None:
				progress_callback(
					"source.related.planning",
					(
						f"Assessing {len(extracted.related_candidates)} related link candidates"
					),
					{"candidate_count": len(extracted.related_candidates)},
				)
			try:
				plan = plan_related_source_expansion(
					llm_streamer=self.llm_streamer,
					family_name=family_name,
					source=source,
					extracted=extracted,
					candidates=extracted.related_candidates,
				)
			except Exception as exc:
				extracted.warnings.append(
					IngestionWarning(
						code="related_source_planning_failed",
						message=(
							f"Related source planning failed for "
							f"{source.filename or source.url or source.id}: {exc}"
						),
					)
				)
				return extracted

			candidate_by_url = {
				candidate.url: candidate for candidate in extracted.related_candidates
			}
			selected_candidates = []
			selected_urls: set[str] = set()
			for url in plan.selected_urls:
				candidate = candidate_by_url.get(url)
				if candidate is None:
					continue
				if candidate.url not in selected_urls:
					selected_candidates.append(candidate)
					selected_urls.add(candidate.url)
				if len(selected_candidates) >= RELATED_SOURCE_PLAN_MAX_SELECTIONS:
					break

			if progress_callback is not None:
				progress_callback(
					"source.related.planned",
					(
						f"Agent selected {len(selected_candidates)} related resources "
						f"from {len(extracted.related_candidates)} candidates"
					),
					{
						"candidate_count": len(extracted.related_candidates),
						"selected_candidate_count": len(selected_candidates),
					},
				)
			if not selected_candidates:
				return extracted

			related_text, related_tables, related_figures, related_candidates, related_warnings = expand_related_url_sources(
				source,
				candidates=selected_candidates,
				progress_callback=progress_callback,
			)
			if related_text:
				extracted.text = "\n\n".join(
					part for part in [extracted.text, related_text] if part.strip()
				)
			if related_tables:
				extracted.tables.extend(related_tables)
			if related_figures:
				next_figure_id = (
					max((figure.figure_id for figure in extracted.figures), default=0) + 1
				)
				for figure in related_figures:
					figure.figure_id = next_figure_id
					next_figure_id += 1
				extracted.figures.extend(related_figures)
			if related_candidates:
				existing_candidate_urls = {
					candidate.url for candidate in extracted.related_candidates
				}
				for candidate in related_candidates:
					if candidate.url in existing_candidate_urls:
						continue
					extracted.related_candidates.append(candidate)
					existing_candidate_urls.add(candidate.url)
			if extracted.text:
				extracted.text = extracted.text[:MAX_COMBINED_SOURCE_TEXT_CHARS]
			if len(extracted.tables) > MAX_EXPANDED_TABLES_PER_SOURCE:
				extracted.tables = extracted.tables[:MAX_EXPANDED_TABLES_PER_SOURCE]
			if related_warnings:
				extracted.warnings.extend(related_warnings)
			return extracted
		if source.filedata_id is None:
			raise IngestionSourceExtractionError("File source is missing filedata_id")
		filedata = mdb_file.get_file_db_by_id(source.filedata_id)
		if filedata is None:
			raise IngestionSourceExtractionError(
				f"Filedata {source.filedata_id} does not exist"
			)
		product_file_folder = os.environ.get("PRODUCT_FILE_FOLDER")
		if not product_file_folder:
			raise IngestionSourceExtractionError("PRODUCT_FILE_FOLDER is not configured")
		file_path = os.path.join(product_file_folder, filedata.blake2shash)
		if not os.path.exists(file_path):
			raise IngestionSourceExtractionError(
				(
					"Stored file blob "
					f"'{filedata.blake2shash}' for filedata {source.filedata_id} "
					"was not found in PRODUCT_FILE_FOLDER"
				)
			)
		return extract_file_source(
			source,
			file_path,
			progress_callback=progress_callback,
		)

	def _format_no_usable_sources_error(
		self,
		*,
		sources: list[IngestionSource],
		source_failures: dict[int, str],
	) -> str:
		if not source_failures:
			return "No usable sources were extracted for this job"

		failed_sources: list[str] = []
		for source in sources:
			message = source_failures.get(source.id)
			if not message:
				continue
			label = source.filename or source.url or f"source {source.id}"
			failed_sources.append(f"{label}: {message}")

		if not failed_sources:
			failed_sources = [message for message in source_failures.values() if message]

		return (
			"No usable sources were extracted for this job. Failed sources: "
			+ " | ".join(failed_sources)
		)

	def _generate_source_finding(
		self,
		*,
		entity_id: int,
		entity_type: str,
		source: IngestionSource,
		extracted: ExtractedSourceContent,
	) -> IngestionSourceFinding:
		assert self.llm_streamer is not None
		family = self._get_entity_family(
			entity_id=entity_id,
			entity_type=entity_type,
		)
		return generate_source_finding(
			llm_streamer=self.llm_streamer,
			family_name=family.family if family else "Unknown family",
			source=source,
			extracted=extracted,
		)

	def _generate_source_figure_finding(
		self,
		*,
		entity_id: int,
		entity_type: str,
		source: IngestionSource,
		extracted: ExtractedSourceContent,
		article_candidates: list[str],
	) -> IngestionSourceFigureFinding:
		assert self.llm_streamer is not None
		family = self._get_entity_family(
			entity_id=entity_id,
			entity_type=entity_type,
		)
		return generate_source_figure_finding(
			llm_streamer=self.llm_streamer,
			family_name=family.family if family else "Unknown family",
			source=source,
			extracted=extracted,
			article_candidates=article_candidates,
		)

	def _merge_source_findings(
		self,
		*,
		entity_id: int,
		entity_type: str,
		findings: list[IngestionSourceFinding],
	) -> IngestionResult:
		assert self.llm_streamer is not None
		family = self._get_entity_family(
			entity_id=entity_id,
			entity_type=entity_type,
		)
		return merge_source_findings(
			llm_streamer=self.llm_streamer,
			family_name=family.family if family else "Unknown family",
			findings=findings,
		)

	def _normalize_finding(self, finding: IngestionSourceFinding) -> IngestionSourceFinding:
		return normalize_finding(finding)

	def _normalize_result(self, result: IngestionResult) -> IngestionResult:
		return normalize_result(result)

	def _merge_warnings(
		self, *warning_sets: list[IngestionWarning]
	) -> list[IngestionWarning]:
		return merge_warnings(*warning_sets)

	def _generate_english_copy(
		self,
		*,
		result: IngestionResult,
		family_name: str,
		progress_callback=None,
	):
		assert self.llm_streamer is not None
		return generate_english_copy(
			llm_streamer=self.llm_streamer,
			result=result,
			family_name=family_name,
			progress_callback=progress_callback,
		)

	def _get_entity_family(self, *, entity_id: int, entity_type: str):
		self._require_supported_entity_type(entity_type=entity_type)
		family = mdb_fam.get_family_db_by_id(id=entity_id, include_siblings=False)
		if family is None:
			raise HTTPException(status_code=404, detail="Family not found")
		return family

	def _ensure_entity_is_empty(self, *, entity_id: int, entity_type: str) -> None:
		self._require_supported_entity_type(entity_type=entity_type)
		with Session(mdb_engine) as session:
			family = session.get(sqlm.CFamily, entity_id)
			if family is None:
				raise HTTPException(status_code=404, detail="Family not found")
			if any(
				value and str(value).strip()
				for value in (
					family.type,
					family.short_description,
					family.description,
				)
			):
				raise HTTPException(
					status_code=409,
					detail="AI ingest only supports newly created or otherwise empty families",
				)
			has_articles = session.exec(
				select(sqlm.CArticle.id).where(sqlm.CArticle.family_id == entity_id)
			).first()
			has_applications = session.exec(
				select(sqlm.CApplication.id).where(sqlm.CApplication.family_id == entity_id)
			).first()
			has_options = session.exec(
				select(sqlm.COption.id).where(sqlm.COption.family_id == entity_id)
			).first()
			has_family_tables = session.exec(
				select(sqlm.CSpecTable.id)
				.where(sqlm.CSpecTable.parent == "family")
				.where(sqlm.CSpecTable.parent_id == entity_id)
			).first()
			if has_articles or has_applications or has_options or has_family_tables:
				raise HTTPException(
					status_code=409,
					detail="AI ingest only supports newly created or otherwise empty families",
				)

	def _format_sse(self, event: IngestionEvent) -> str:
		payload = json.dumps(event.model_dump(mode="json"), ensure_ascii=False)
		return f"data: {payload}\n\n"
