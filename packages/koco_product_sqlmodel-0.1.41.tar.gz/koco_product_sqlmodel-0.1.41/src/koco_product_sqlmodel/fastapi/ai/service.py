from __future__ import annotations

from collections.abc import Generator, Iterable
from typing import Any

from koco_product_sqlmodel.fastapi.ai.context_builder import DescriptionContextBuilder
from koco_product_sqlmodel.fastapi.ai.llm import LLMStreamer


FIELD_LIMITS = {
    "type": 1024,
    "short_description": 1024,
    "description": 4096,
}
DESCRIPTION_TARGET_LIMIT = 3600
DESCRIPTION_STREAM_MAX_TOKENS = 2500

SUPPORTED_ENTITY_TYPES = {"family", "article"}
SUPPORTED_FIELDS = {"type", "short_description", "description"}
DEFAULT_FIELDS = ("type", "short_description", "description")


class DescriptionGenerationService:
    def __init__(
        self,
        *,
        llm_streamer: LLMStreamer,
        context_builder: DescriptionContextBuilder,
    ) -> None:
        self.llm_streamer = llm_streamer
        self.context_builder = context_builder
        self.system_prompt = self._create_system_prompt()

    def stream_run(
        self,
        *,
        entity_type: str,
        entity_id: int,
        fields: Iterable[str] | None = None,
    ) -> Generator[dict[str, Any], None, None]:
        requested_fields = list(fields or DEFAULT_FIELDS)
        invalid_fields = [field for field in requested_fields if field not in SUPPORTED_FIELDS]
        if entity_type not in SUPPORTED_ENTITY_TYPES:
            raise ValueError(f"Unsupported entity_type '{entity_type}'")
        if invalid_fields:
            raise ValueError(f"Unsupported field selection: {', '.join(invalid_fields)}")

        field_selection = {field for field in requested_fields}
        normalized_fields = [field for field in DEFAULT_FIELDS if field in field_selection]

        try:
            context = yield from self._build_context(
                entity_type=entity_type, entity_id=entity_id
            )
            prompt_context = self.context_builder.serialize_prompt_context(context)
            yield self._event(
                "step.started",
                step="prepare.prompt_context",
                label="Prepare AI prompt context",
            )
            yield self._event(
                "step.completed",
                step="prepare.prompt_context",
                label="Prepare AI prompt context",
                meta={"bytes": len(prompt_context.encode("utf-8"))},
            )

            result: dict[str, str] = {}

            if "type" in normalized_fields:
                value = self.llm_streamer.generate_json_field(
                    system_prompt=self.system_prompt,
                    user_prompt=self._create_type_prompt(entity_type, prompt_context),
                    expected_field="type",
                    max_tokens=256,
                )
                value = self._validate_field_limit("type", value)
                result["type"] = value
                yield self._event("field.completed", field="type", value=value)

            if "short_description" in normalized_fields:
                yield self._event(
                    "step.started",
                    step="generate.short_description",
                    label="Generate short description",
                )
                value = self.llm_streamer.generate_json_field(
                    system_prompt=self.system_prompt,
                    user_prompt=self._create_short_description_prompt(
                        entity_type, prompt_context
                    ),
                    expected_field="short_description",
                    max_tokens=600,
                )
                value = self._validate_field_limit("short_description", value)
                result["short_description"] = value
                yield self._event(
                    "field.completed",
                    field="short_description",
                    value=value,
                )
                yield self._event(
                    "step.completed",
                    step="generate.short_description",
                    label="Generate short description",
                )

            if "description" in normalized_fields:
                yield self._event(
                    "step.started",
                    step="generate.description",
                    label="Generate description",
                )
                description_parts: list[str] = []
                stream = self.llm_streamer.stream_text(
                    system_prompt=self.system_prompt,
                    user_prompt=self._create_description_prompt(
                        entity_type, prompt_context
                    ),
                    max_tokens=DESCRIPTION_STREAM_MAX_TOKENS,
                )
                while True:
                    try:
                        delta = next(stream)
                    except StopIteration as stop:
                        full_description = stop.value or "".join(description_parts)
                        break
                    description_parts.append(delta)
                    yield self._event("field.delta", field="description", delta=delta)
                full_description = self._validate_field_limit("description", full_description)
                result["description"] = full_description
                yield self._event(
                    "field.completed",
                    field="description",
                    value=full_description,
                )
                yield self._event(
                    "step.completed",
                    step="generate.description",
                    label="Generate description",
                )

            yield self._event("run.completed", result=result)
        except GeneratorExit:
            raise
        except Exception as exc:
            yield self._event("run.failed", message=str(exc))

    def _build_context(
        self, *, entity_type: str, entity_id: int
    ) -> Generator[dict[str, Any], None, dict[str, Any]]:
        if entity_type == "family":
            yield self._event("step.started", step="fetch.family", label="Fetch family")
            family = self.context_builder.fetch_family(entity_id)
            yield self._event("step.completed", step="fetch.family", label="Fetch family")

            yield self._event(
                "step.started",
                step="fetch.related_articles",
                label="Fetch related articles and article tables",
            )
            articles = self.context_builder.fetch_articles_for_family(entity_id)
            article_spectables = {
                str(article["id"]): self.context_builder.fetch_spectables(
                    parent="article", parent_id=article["id"]
                )
                for article in articles
                if article.get("id")
            }
            yield self._event(
                "step.completed",
                step="fetch.related_articles",
                label="Fetch related articles and article tables",
                meta={"article_count": len(articles)},
            )

            yield self._event(
                "step.started",
                step="fetch.family_metadata",
                label="Fetch family applications, options, and family tables",
            )
            applications = self.context_builder.fetch_applications(entity_id)
            options = self.context_builder.fetch_options(entity_id)
            family_spectables = self.context_builder.fetch_spectables(
                parent="family", parent_id=entity_id
            )
            yield self._event(
                "step.completed",
                step="fetch.family_metadata",
                label="Fetch family applications, options, and family tables",
                meta={
                    "application_count": len(applications),
                    "option_count": len(options),
                    "family_table_count": len(family_spectables),
                },
            )

            return self.context_builder.compose_family_context(
                family=family,
                articles=articles,
                applications=applications,
                options=options,
                family_spectables=family_spectables,
                article_spectables=article_spectables,
            )

        yield self._event("step.started", step="fetch.article", label="Fetch article")
        article = self.context_builder.fetch_article(entity_id)
        yield self._event("step.completed", step="fetch.article", label="Fetch article")

        family_id = article.get("family_id")
        yield self._event("step.started", step="fetch.family", label="Fetch family context")
        family = self.context_builder.fetch_family(family_id) if family_id else {}
        yield self._event(
            "step.completed", step="fetch.family", label="Fetch family context"
        )

        yield self._event(
            "step.started",
            step="fetch.family_metadata",
            label="Fetch family applications, options, and family tables",
        )
        applications = self.context_builder.fetch_applications(family_id) if family_id else []
        options = self.context_builder.fetch_options(family_id) if family_id else []
        family_spectables = (
            self.context_builder.fetch_spectables(parent="family", parent_id=family_id)
            if family_id
            else []
        )
        yield self._event(
            "step.completed",
            step="fetch.family_metadata",
            label="Fetch family applications, options, and family tables",
            meta={
                "application_count": len(applications),
                "option_count": len(options),
                "family_table_count": len(family_spectables),
            },
        )

        yield self._event(
            "step.started", step="fetch.article_tables", label="Fetch article tables"
        )
        article_spectables = self.context_builder.fetch_spectables(
            parent="article", parent_id=entity_id
        )
        yield self._event(
            "step.completed",
            step="fetch.article_tables",
            label="Fetch article tables",
            meta={"article_table_count": len(article_spectables)},
        )

        return self.context_builder.compose_article_context(
            article=article,
            family=family,
            applications=applications,
            options=options,
            family_spectables=family_spectables,
            article_spectables=article_spectables,
        )

    def _create_system_prompt(self) -> str:
        return (
            "Write concise B2B industrial product copy for the KOCO catalog. "
            "Write all output in English only, even when source material is in another language. "
            "Translate source facts into clear technical English without losing meaning. "
            "Use only facts supported by the provided data. "
            "Prefer compact, concrete wording over marketing filler."
        )

    def _create_type_prompt(self, entity_type: str, context: str) -> str:
        return (
            f"Create a concise type label for this {entity_type} and return JSON.\n\n"
            f"Data:\n{context}\n\n"
            "Rules:\n"
            "- max 6 words\n"
            "- industry-standard terminology\n"
            "- English only\n"
            "- non-empty\n\n"
            'Return a JSON object with a single field "type" containing the classification.'
        )

    def _create_short_description_prompt(self, entity_type: str, context: str) -> str:
        return (
            f"Create a short description for this {entity_type} and return JSON.\n\n"
            f"Data:\n{context}\n\n"
            "Rules:\n"
            "- 35 to 55 words\n"
            "- mention the main use or benefit\n"
            "- English only\n"
            "- factual, compact, non-empty\n\n"
            'Return a JSON object with a single field "short_description" containing the description.'
        )

    def _create_description_prompt(self, entity_type: str, context: str) -> str:
        return (
            f"Write a moderately detailed HTML description for this {entity_type}.\n\n"
            f"Data:\n{context}\n\n"
            "Rules:\n"
            f"- hard limit: {DESCRIPTION_TARGET_LIMIT} characters including HTML\n"
            "- valid HTML only, no Markdown, no JSON\n"
            "- exactly 3 short <p> blocks\n"
            "- optional 1 <ul> with at most 5 <li> items\n"
            "- no headings\n"
            "- no concluding CTA line\n"
            "- English only\n"
            "- use only provided facts\n"
            "- cover the main product role, key technical strengths, and typical use cases\n"
            "- prioritize the 5 most important technical benefits"
        )

    def _validate_field_limit(self, field: str, value: str) -> str:
        limit = FIELD_LIMITS[field]
        if len(value) <= limit:
            return value
        raise ValueError(
            f"Generated '{field}' exceeds limit ({len(value)} > {limit})."
        )

    def _event(self, event_type: str, **payload: Any) -> dict[str, Any]:
        return {"type": event_type, **payload}
