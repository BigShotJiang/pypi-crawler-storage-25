from __future__ import annotations

import base64
import hashlib
import os
import re
from pathlib import Path

from fastapi import HTTPException

from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
	ExtractedFigure,
	IngestionFigure,
	IngestionResult,
	IngestionWarning,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_persistence_common import (
	ProgressCallback,
	_emit_progress,
)


class IngestionPersistenceAssetMixin:
	def materialize_figures(
		self,
		*,
		job_id: int,
		result: IngestionResult,
		extracted_figures_by_source: dict[int, dict[int, ExtractedFigure]],
		progress_callback: ProgressCallback | None = None,
	) -> tuple[IngestionResult, list[IngestionWarning]]:
		warnings: list[IngestionWarning] = []
		materialized: list[IngestionFigure] = []
		total_figures = len(result.figures)

		if total_figures:
			_emit_progress(
				progress_callback,
				"merge.figures.started",
				f"Materializing {total_figures} extracted figure previews",
				{"figure_count": total_figures},
			)

		for index, figure in enumerate(result.figures, start=1):
			if not figure.source_id or not figure.source_figure_id:
				continue
			extracted_figure = extracted_figures_by_source.get(figure.source_id, {}).get(
				figure.source_figure_id
			)
			if extracted_figure is None or not extracted_figure.image_data_url:
				warnings.append(
					IngestionWarning(
						code="figure_materialization_failed",
						message=(
							f"Could not materialize figure from source {figure.source_id} "
							f"candidate {figure.source_figure_id}"
						),
					)
				)
				continue
			preview_token, mime_type = self._write_job_figure_preview(
				job_id=job_id,
				figure=figure,
				extracted_figure=extracted_figure,
			)
			if not preview_token:
				warnings.append(
					IngestionWarning(
						code="figure_materialization_failed",
						message=(
							f"Could not persist preview for source {figure.source_id} "
							f"candidate {figure.source_figure_id}"
						),
					)
				)
				continue
			figure.preview_token = preview_token
			figure.filename = figure.filename or self._build_figure_filename(
				figure=figure,
				fallback_index=index,
			)
			figure.mime_type = mime_type
			figure.locator = figure.locator or extracted_figure.locator
			if not figure.context_excerpt:
				figure.context_excerpt = extracted_figure.context_text[:800]
			materialized.append(figure)
			_emit_progress(
				progress_callback,
				"merge.figures.progress",
				f"Materialized figure {index}/{total_figures}",
				{
					"index": index,
					"total": total_figures,
					"figure_count": len(materialized),
				},
			)

		result.figures = materialized
		if total_figures:
			_emit_progress(
				progress_callback,
				"merge.figures.completed",
				f"Finished materializing {len(materialized)} figure previews",
				{
					"figure_count": len(materialized),
					"warning_count": len(warnings),
				},
			)
		return result, warnings

	def cleanup_job_figure_previews(self, job_id: int) -> None:
		preview_dir = self._get_job_figure_preview_dir(job_id)
		if not os.path.isdir(preview_dir):
			return
		for root, _, files in os.walk(preview_dir, topdown=False):
			for filename in files:
				try:
					os.remove(os.path.join(root, filename))
				except OSError:
					pass
			try:
				os.rmdir(root)
			except OSError:
				pass

	def _write_job_figure_preview(
		self,
		*,
		job_id: int,
		figure: IngestionFigure,
		extracted_figure: ExtractedFigure,
	) -> tuple[str | None, str | None]:
		if not extracted_figure.image_data_url or "," not in extracted_figure.image_data_url:
			return None, None
		header, encoded = extracted_figure.image_data_url.split(",", 1)
		mime_type = "image/png"
		header_match = re.match(
			r"data:(.*?);base64$", header.strip(), flags=re.IGNORECASE
		)
		if header_match:
			mime_type = header_match.group(1) or mime_type
		try:
			content = base64.b64decode(encoded)
		except Exception:
			return None, None

		extension = ".png"
		if mime_type == "image/jpeg":
			extension = ".jpg"
		file_hash = hashlib.blake2s(content).hexdigest()[:16]
		preview_token = (
			f"s{figure.source_id}_f{figure.source_figure_id}_{file_hash}{extension}"
		)
		preview_dir = self._get_job_figure_preview_dir(job_id)
		os.makedirs(preview_dir, exist_ok=True)
		preview_path = os.path.join(preview_dir, preview_token)
		if not os.path.exists(preview_path):
			with open(preview_path, "wb") as handle:
				handle.write(content)
		return preview_token, mime_type

	def _build_figure_filename(
		self, *, figure: IngestionFigure, fallback_index: int
	) -> str:
		base_name = figure.description or figure.type or f"figure-{fallback_index}"
		slug = re.sub(r"[^a-z0-9]+", "-", base_name.lower()).strip("-") or "figure"
		return f"{slug}-s{figure.source_id}-f{figure.source_figure_id}.png"

	def _get_product_file_folder(self) -> str:
		product_file_folder = os.environ.get("PRODUCT_FILE_FOLDER")
		if not product_file_folder:
			raise HTTPException(
				status_code=500, detail="PRODUCT_FILE_FOLDER is not configured"
			)
		return product_file_folder

	def _get_job_figure_preview_dir(self, job_id: int) -> str:
		return os.path.join(self._get_product_file_folder(), "_ai_ingestion", str(job_id))

	def _get_job_figure_preview_path(
		self, *, job_id: int, preview_token: str | None
	) -> tuple[str, str]:
		if not preview_token:
			raise HTTPException(status_code=404, detail="Figure preview token is missing")
		if not re.fullmatch(r"[A-Za-z0-9_.-]+", preview_token):
			raise HTTPException(status_code=400, detail="Invalid figure preview token")
		extension = Path(preview_token).suffix.lower()
		mime_type = "image/png"
		if extension in {".jpg", ".jpeg"}:
			mime_type = "image/jpeg"

		preview_path = os.path.join(self._get_job_figure_preview_dir(job_id), preview_token)
		if os.path.exists(preview_path):
			return preview_path, mime_type
		raise HTTPException(status_code=404, detail="Figure preview was not found")


__all__ = ["IngestionPersistenceAssetMixin"]
