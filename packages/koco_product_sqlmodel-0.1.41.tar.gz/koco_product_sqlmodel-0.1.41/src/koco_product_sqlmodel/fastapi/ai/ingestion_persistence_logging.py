from __future__ import annotations

from typing import Any

import koco_product_sqlmodel.dbmodels.support as dbm_support
import koco_product_sqlmodel.mdb_connect.changelog as mdb_change
from koco_product_sqlmodel.fastapi.ai.ingestion_persistence_common import (
	ChangeLogEntry,
)


class IngestionPersistenceLoggingMixin:
	def _queue_change_log(
		self,
		pending_logs: list[ChangeLogEntry],
		obj: Any,
		action: str,
	) -> None:
		entity_type = dbm_support.get_table_from_sqlmodels(obj.__class__)
		entity_id = getattr(obj, "id", None)
		if not entity_type or not entity_id:
			return
		pending_logs.append(
			ChangeLogEntry(
				entity_id=entity_id,
				entity_type=entity_type,
				action=action,
				new_values=str(obj.model_dump_json(exclude={"insdate", "upddate"})),
			)
		)

	def _log_change(self, entry: ChangeLogEntry, *, user_id: int) -> None:
		mdb_change.log_results_to_db(
			entity_id=entry.entity_id,
			entity_type=entry.entity_type,
			action=entry.action,
			user_id=user_id,
			new_values=entry.new_values,
		)


__all__ = ["IngestionPersistenceLoggingMixin"]
