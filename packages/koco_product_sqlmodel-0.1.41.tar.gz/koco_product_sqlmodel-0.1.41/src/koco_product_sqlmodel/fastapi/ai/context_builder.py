from __future__ import annotations

import json
from collections.abc import Callable, Iterable
from enum import Enum
from typing import Any

import koco_product_sqlmodel.dbmodels.definition as sqlm
import koco_product_sqlmodel.mdb_connect.applications as mdb_apps
import koco_product_sqlmodel.mdb_connect.families as mdb_fam
import koco_product_sqlmodel.mdb_connect.generic_object_connect as mdb_gen
import koco_product_sqlmodel.mdb_connect.options as mdb_opt


MAX_PROMPT_TEXT_LENGTH = 1200

FAMILY_TEXT_LIMITS = {
    "family": 512,
    "type": 512,
    "short_description": 800,
    "description": MAX_PROMPT_TEXT_LENGTH,
}
ARTICLE_TEXT_LIMITS = {
    "article": 512,
    "short_description": 800,
    "description": MAX_PROMPT_TEXT_LENGTH,
}
OPTION_TEXT_LIMITS = {"type": 128, "category": 512, "option": 512}
SPECTABLE_TEXT_LIMITS = {"name": 256, "description_json": 1200}
SPECTABLE_ITEM_TEXT_LIMITS = {
    "pos": 64,
    "name": 256,
    "value": 256,
    "min_value": 256,
    "max_value": 256,
    "unit": 64,
}


class DescriptionContextBuilder:
    def __init__(
        self,
        *,
        family_fetcher: Callable[[int], Any] | None = None,
        article_fetcher: Callable[[int], Any] | None = None,
        family_articles_fetcher: Callable[[int], list[Any]] | None = None,
        applications_fetcher: Callable[[int], list[Any]] | None = None,
        options_fetcher: Callable[[int], list[Any]] | None = None,
        spectables_fetcher: Callable[[str, int], list[Any]] | None = None,
    ) -> None:
        self._family_fetcher = family_fetcher or self._fetch_family_from_db
        self._article_fetcher = article_fetcher or self._fetch_article_from_db
        self._family_articles_fetcher = (
            family_articles_fetcher or self._fetch_articles_for_family_from_db
        )
        self._applications_fetcher = (
            applications_fetcher or self._fetch_applications_from_db
        )
        self._options_fetcher = options_fetcher or self._fetch_options_from_db
        self._spectables_fetcher = spectables_fetcher or self._fetch_spectables_from_db

    def fetch_family(self, family_id: int) -> dict[str, Any]:
        return self._require_record(self._family_fetcher(family_id), label="Family", record_id=family_id)

    def fetch_article(self, article_id: int) -> dict[str, Any]:
        return self._require_record(
            self._article_fetcher(article_id), label="Article", record_id=article_id
        )

    def fetch_articles_for_family(self, family_id: int) -> list[dict[str, Any]]:
        return [
            self._normalize_article(self._to_dict(article))
            for article in self._family_articles_fetcher(family_id)
            if article
        ]

    def fetch_applications(self, family_id: int) -> list[str]:
        return [
            self._truncate_text(application.get("application"), 512)
            for application in self._iter_dicts(self._applications_fetcher(family_id))
            if (application.get("application") or "").strip()
        ]

    def fetch_options(self, family_id: int) -> list[dict[str, Any]]:
        return [
            self._project_record(option, text_limits=OPTION_TEXT_LIMITS)
            for option in self._iter_dicts(self._options_fetcher(family_id))
        ]

    def fetch_spectables(self, *, parent: str, parent_id: int) -> list[dict[str, Any]]:
        return [
            self._normalize_spectable(spectable)
            for spectable in self._iter_dicts(self._spectables_fetcher(parent, parent_id))
        ]

    def build_family_context(self, family_id: int) -> dict[str, Any]:
        family = self.fetch_family(family_id)
        articles = self.fetch_articles_for_family(family_id)
        applications = self.fetch_applications(family_id)
        options = self.fetch_options(family_id)
        family_spectables = self.fetch_spectables(parent="family", parent_id=family_id)
        article_spectables = {
            str(article["id"]): self.fetch_spectables(parent="article", parent_id=article["id"])
            for article in articles
            if article.get("id")
        }
        return self.compose_family_context(
            family=family,
            articles=articles,
            applications=applications,
            options=options,
            family_spectables=family_spectables,
            article_spectables=article_spectables,
        )

    def build_article_context(self, article_id: int) -> dict[str, Any]:
        article = self.fetch_article(article_id)
        family_id = article.get("family_id")
        family = self.fetch_family(family_id) if family_id else {}
        applications = self.fetch_applications(family_id) if family_id else []
        options = self.fetch_options(family_id) if family_id else []
        family_spectables = (
            self.fetch_spectables(parent="family", parent_id=family_id) if family_id else []
        )
        article_spectables = self.fetch_spectables(parent="article", parent_id=article_id)
        return self.compose_article_context(
            article=article,
            family=family,
            applications=applications,
            options=options,
            family_spectables=family_spectables,
            article_spectables=article_spectables,
        )

    def compose_family_context(
        self,
        *,
        family: dict[str, Any],
        articles: list[dict[str, Any]],
        applications: list[str],
        options: list[dict[str, Any]],
        family_spectables: list[dict[str, Any]],
        article_spectables: dict[str, list[dict[str, Any]]],
    ) -> dict[str, Any]:
        return self._compact_value(
            {
                "entity_type": "family",
                "family": self._normalize_family(family),
                "articles": articles,
                "applications": applications,
                "options": options,
                "family_spectables": family_spectables,
                "article_spectables": article_spectables,
            }
        )

    def compose_article_context(
        self,
        *,
        article: dict[str, Any],
        family: dict[str, Any],
        applications: list[str],
        options: list[dict[str, Any]],
        family_spectables: list[dict[str, Any]],
        article_spectables: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return self._compact_value(
            {
                "entity_type": "article",
                "article": self._normalize_article(article),
                "family": self._normalize_family(family) if family else {},
                "applications": applications,
                "options": options,
                "family_spectables": family_spectables,
                "article_spectables": article_spectables,
            }
        )

    def serialize_prompt_context(self, context: dict[str, Any]) -> str:
        return json.dumps(context, ensure_ascii=False, indent=2)

    def _fetch_family_from_db(self, family_id: int) -> Any:
        family = mdb_fam.get_family_db_by_id(id=family_id, include_siblings=False)
        return family.model_dump() if family else None

    def _fetch_article_from_db(self, article_id: int) -> Any:
        article = mdb_gen.get_object(db_obj_type=sqlm.CArticle, id=article_id)
        return article.model_dump() if article else None

    def _fetch_articles_for_family_from_db(self, family_id: int) -> list[Any]:
        return [
            article.model_dump()
            for article in mdb_gen.get_family_related_objects(
                db_obj_type=sqlm.CArticle, family_id=family_id
            )
        ]

    def _fetch_applications_from_db(self, family_id: int) -> list[Any]:
        return [
            application.model_dump()
            for application in mdb_apps.get_applications_db(family_id=family_id)
        ]

    def _fetch_options_from_db(self, family_id: int) -> list[Any]:
        return [option.model_dump() for option in mdb_opt.get_options_db(family_id=family_id)]

    def _fetch_spectables_from_db(self, parent: str, parent_id: int) -> list[Any]:
        results: list[dict[str, Any]] = []
        spectables = mdb_gen.get_objects_from_parent(
            db_obj_type=sqlm.CSpecTable, parent_id=parent_id, parent=parent
        )
        for spectable in spectables:
            spectable_dump = spectable.model_dump()
            items = mdb_gen.get_objects_from_spec_table(spec_table_id=spectable.id) or []
            spectable_dump["spectableitems"] = [item.model_dump() for item in items]
            results.append(spectable_dump)
        return results

    def _normalize_family(self, family: dict[str, Any]) -> dict[str, Any]:
        return self._project_record(
            family,
            text_limits=FAMILY_TEXT_LIMITS,
            scalar_fields=("id", "product_group_id", "status"),
        )

    def _normalize_article(self, article: dict[str, Any]) -> dict[str, Any]:
        return self._project_record(
            article,
            text_limits=ARTICLE_TEXT_LIMITS,
            scalar_fields=("id", "family_id", "order_priority", "status"),
        )

    def _normalize_spectable(self, spectable: dict[str, Any]) -> dict[str, Any]:
        normalized = self._project_record(
            spectable,
            text_limits=SPECTABLE_TEXT_LIMITS,
            scalar_fields=("id", "type", "parent", "parent_id", "has_unit"),
        )
        items = [
            self._project_record(item, text_limits=SPECTABLE_ITEM_TEXT_LIMITS)
            for item in self._iter_dicts(spectable.get("spectableitems", []))
        ]
        normalized["items"] = items
        return normalized

    def _project_record(
        self,
        record: dict[str, Any],
        *,
        text_limits: dict[str, int],
        scalar_fields: Iterable[str] = (),
    ) -> dict[str, Any]:
        normalized = {
            field: self._normalize_scalar(record.get(field)) for field in scalar_fields
        }
        normalized.update(
            {
                field: self._truncate_text(record.get(field), max_length)
                for field, max_length in text_limits.items()
            }
        )
        return normalized

    def _compact_value(self, value: Any) -> Any:
        if isinstance(value, str):
            return self._truncate_text(value)
        if isinstance(value, list):
            return [self._compact_value(item) for item in value if item not in (None, "", [], {})]
        if isinstance(value, dict):
            return {
                key: self._compact_value(item)
                for key, item in value.items()
                if item not in (None, "", [], {})
            }
        return self._normalize_scalar(value)

    def _iter_dicts(self, values: Iterable[Any]) -> list[dict[str, Any]]:
        return [self._to_dict(value) for value in values if value is not None]

    def _require_record(self, value: Any, *, label: str, record_id: int) -> dict[str, Any]:
        record = self._to_dict(value)
        if not record:
            raise ValueError(f"{label} '{record_id}' not found")
        return record

    def _normalize_scalar(self, value: Any) -> Any:
        return value.value if isinstance(value, Enum) else value

    def _to_dict(self, value: Any) -> dict[str, Any]:
        if value is None:
            return {}
        if isinstance(value, dict):
            return value
        if hasattr(value, "model_dump"):
            return value.model_dump()
        raise TypeError(f"Unsupported context value type '{type(value)!r}'")

    def _truncate_text(self, text: str | None, max_length: int = MAX_PROMPT_TEXT_LENGTH) -> str:
        if not text:
            return ""
        normalized = str(text).strip()
        if len(normalized) <= max_length:
            return normalized
        shortened = normalized[:max_length].rsplit(" ", 1)[0]
        return f"{shortened}..." if shortened else f"{normalized[:max_length]}..."
