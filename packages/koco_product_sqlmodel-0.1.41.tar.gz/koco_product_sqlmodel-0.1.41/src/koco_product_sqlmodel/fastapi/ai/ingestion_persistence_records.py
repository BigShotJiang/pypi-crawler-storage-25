from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from urllib.parse import urlparse

from fastapi import HTTPException
from sqlmodel import Session

import koco_product_sqlmodel.dbmodels.definition as sqlm
import koco_product_sqlmodel.dbmodels.models_enums as model_enums
from koco_product_sqlmodel.fastapi.ai.ingestion_extractors import download_url_file
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
	IngestionFigure,
	IngestionResult,
	IngestionSpectable,
	IngestionWarning,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_persistence_common import (
	ChangeLogEntry,
	DOWNLOADABLE_URL_TYPES,
	ProgressCallback,
	_emit_progress,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_result_utils import (
	normalize_url_type,
	to_storage_document_type,
	to_storage_url_type,
)
from koco_product_sqlmodel.mdb_connect.init_db_con import mdb_engine


class IngestionPersistenceRecordMixin:
	def save_generated_data(
		self,
		*,
		job_id: int,
		entity_id: int,
		entity_type: str,
		user_id: int,
		result: IngestionResult,
		progress_callback: ProgressCallback | None = None,
	) -> list[IngestionWarning]:
		pending_logs: list[ChangeLogEntry] = []
		persist_warnings: list[IngestionWarning] = []
		if entity_type != "family":
			raise HTTPException(
				status_code=400,
				detail="AI ingestion persistence currently supports entity_type='family' only",
			)

		with Session(mdb_engine) as session:
			family = session.get(sqlm.CFamily, entity_id)
			if family is None:
				raise HTTPException(status_code=404, detail="Family not found")

			_emit_progress(
				progress_callback,
				"apply.progress",
				"Updating selected family",
				None,
			)
			family_payload = result.family_patch.model_dump(
				exclude={"evidence"}, exclude_none=True
			)
			family.sqlmodel_update(
				{
					**family_payload,
					"status": model_enums.StatusEnum.in_work.value,
				}
			)
			session.add(family)
			session.flush()
			self._queue_change_log(pending_logs, family, "PATCH")

			created_articles: dict[str, sqlm.CArticle] = {}
			if result.articles:
				_emit_progress(
					progress_callback,
					"apply.progress",
					f"Creating {len(result.articles)} article records",
					{"article_count": len(result.articles)},
				)
			for index, article_data in enumerate(result.articles):
				article = sqlm.CArticle(
					article=article_data.article,
					description=article_data.description,
					short_description=article_data.short_description,
					family_id=family.id,
					status=model_enums.StatusEnum.in_work.value,
					order_priority=article_data.order_priority or (100 - index),
					user_id=user_id,
				)
				session.add(article)
				session.flush()
				created_articles[article.article] = article
				self._queue_change_log(pending_logs, article, "POST")

			if result.applications:
				_emit_progress(
					progress_callback,
					"apply.progress",
					f"Creating {len(result.applications)} application records",
					{"application_count": len(result.applications)},
				)
			for application_data in result.applications:
				application = sqlm.CApplication(
					application=application_data.application,
					family_id=family.id,
					user_id=user_id,
				)
				session.add(application)
				session.flush()
				self._queue_change_log(pending_logs, application, "POST")

			if result.options:
				_emit_progress(
					progress_callback,
					"apply.progress",
					f"Creating {len(result.options)} option records",
					{"option_count": len(result.options)},
				)
			for option_data in result.options:
				option = sqlm.COption(
					type=option_data.type,
					option=option_data.option,
					category=option_data.category,
					family_id=family.id,
					user_id=user_id,
				)
				session.add(option)
				session.flush()
				self._queue_change_log(pending_logs, option, "POST")

			if result.family_spectables or result.article_spectables:
				_emit_progress(
					progress_callback,
					"apply.progress",
					(
						f"Creating {len(result.family_spectables)} family tables and "
						f"{len(result.article_spectables)} article tables"
					),
					{
						"family_table_count": len(result.family_spectables),
						"article_table_count": len(result.article_spectables),
						"table_count": len(result.family_spectables)
						+ len(result.article_spectables),
					},
				)
			for table_data in result.family_spectables:
				self._create_spectable(
					session=session,
					table_data=table_data,
					parent="family",
					parent_id=family.id,
					user_id=user_id,
					pending_logs=pending_logs,
				)
			for table_data in result.article_spectables:
				article = created_articles.get(table_data.article_name or "")
				if article is None:
					raise HTTPException(
						status_code=400,
						detail=(
							"Article table references unknown article "
							f"'{table_data.article_name}'"
						),
					)
				self._create_spectable(
					session=session,
					table_data=table_data,
					parent="article",
					parent_id=article.id,
					user_id=user_id,
					pending_logs=pending_logs,
				)

			if result.urls:
				_emit_progress(
					progress_callback,
					"apply.progress",
					f"Creating {len(result.urls)} URL resources",
					{"url_count": len(result.urls)},
				)
			for url_data in result.urls:
				self._create_url_resources(
					session=session,
					url_data=url_data,
					family=family,
					created_articles=created_articles,
					user_id=user_id,
					pending_logs=pending_logs,
					warnings=persist_warnings,
				)

			if result.figures:
				_emit_progress(
					progress_callback,
					"apply.progress",
					f"Creating {len(result.figures)} figure resources",
					{"figure_count": len(result.figures)},
				)
			for figure_data in result.figures:
				self._create_figure_resource(
					job_id=job_id,
					session=session,
					figure_data=figure_data,
					family=family,
					created_articles=created_articles,
					user_id=user_id,
					pending_logs=pending_logs,
				)
			session.commit()

		_emit_progress(
			progress_callback,
			"apply.progress",
			f"Writing {len(pending_logs)} change log entries",
			{"change_log_count": len(pending_logs)},
		)
		for entry in pending_logs:
			try:
				self._log_change(entry, user_id=user_id)
			except Exception as exc:
				persist_warnings.append(
					IngestionWarning(
						code="change_log_failed",
						message=(
							f"Failed to write change log for {entry.entity_type} "
							f"{entry.entity_id}: {exc}"
						),
					)
				)

		_emit_progress(
			progress_callback,
			"apply.progress",
			"Finished saving catalog data",
			{
				"change_log_count": len(pending_logs),
				"warning_count": len(persist_warnings),
			},
		)
		return persist_warnings

	def _create_spectable(
		self,
		*,
		session: Session,
		table_data: IngestionSpectable,
		parent: str,
		parent_id: int,
		user_id: int,
		pending_logs: list[ChangeLogEntry],
	) -> None:
		spectable = sqlm.CSpecTable(
			name=table_data.name,
			type=table_data.type,
			has_unit=table_data.has_unit,
			parent=parent,
			parent_id=parent_id,
			description_json=None,
			user_id=user_id,
			order_priority=100,
		)
		session.add(spectable)
		session.flush()
		self._queue_change_log(pending_logs, spectable, "POST")
		for item_data in table_data.items:
			item = sqlm.CSpecTableItem(
				pos=item_data.pos,
				name=item_data.name,
				value=item_data.value,
				min_value=item_data.min_value,
				max_value=item_data.max_value,
				unit=item_data.unit,
				spec_table_id=spectable.id,
				user_id=user_id,
			)
			session.add(item)
			session.flush()
			self._queue_change_log(pending_logs, item, "POST")

	def _create_url_resources(
		self,
		*,
		session: Session,
		url_data,
		family: sqlm.CFamily,
		created_articles: dict[str, sqlm.CArticle],
		user_id: int,
		pending_logs: list[ChangeLogEntry],
		warnings: list[IngestionWarning],
	) -> None:
		parent, parent_id = self._resolve_url_parent(
			url_data=url_data,
			family=family,
			created_articles=created_articles,
		)
		url_record = sqlm.CUrl(
			type=to_storage_url_type(
				url_data.type, url_data.supplier_url or url_data.KOCO_url
			),
			supplier_url=url_data.supplier_url,
			KOCO_url=url_data.KOCO_url,
			description=url_data.description,
			parent=parent,
			parent_id=parent_id,
			user_id=user_id,
		)
		session.add(url_record)
		session.flush()
		self._queue_change_log(pending_logs, url_record, "POST")

		if not self._should_download_url_file(url_data):
			return

		try:
			downloaded = download_url_file(
				url_data.supplier_url,
				filename_hint=url_data.description or url_data.article_name,
			)
			file_record = self._attach_downloaded_supplier_file(
				session=session,
				downloaded=downloaded,
				url_data=url_data,
				parent_id=parent_id,
				parent_type=parent,
				user_id=user_id,
			)
			self._queue_change_log(pending_logs, file_record, "POST")
		except Exception as exc:
			warnings.append(
				IngestionWarning(
					code="linked_file_download_failed",
					message=(
						f"Could not download linked supplier file "
						f"{url_data.supplier_url}: {exc}"
					),
				)
			)

	def _resolve_url_parent(
		self,
		*,
		url_data,
		family: sqlm.CFamily,
		created_articles: dict[str, sqlm.CArticle],
	) -> tuple[str, int]:
		if url_data.parent == "article":
			article = created_articles.get(url_data.article_name or "")
			if article is None:
				raise HTTPException(
					status_code=400,
					detail=f"URL references unknown article '{url_data.article_name}'",
				)
			return "article", article.id
		return "family", family.id

	def _should_download_url_file(self, url_data) -> bool:
		if not url_data.supplier_url:
			return False
		normalized_type = normalize_url_type(
			url_data.type, url_data.supplier_url or url_data.KOCO_url
		)
		if normalized_type in DOWNLOADABLE_URL_TYPES:
			return True
		suffix = Path(urlparse(url_data.supplier_url).path).suffix.lower()
		return suffix in {
				".pdf",
				".docx",
				".xlsx",
				".xlsm",
				".csv",
				".tsv",
				".txt",
				".md",
				".jpg",
				".jpeg",
				".png",
				".webp",
			}

	def _attach_downloaded_supplier_file(
		self,
		*,
		session: Session,
		downloaded,
		url_data,
		parent_id: int,
		parent_type: str,
		user_id: int,
	):
		product_file_folder = self._get_product_file_folder()

		blake2shash = hashlib.blake2s(downloaded.content).hexdigest()
		file_path = os.path.join(product_file_folder, blake2shash)
		if not os.path.exists(file_path):
			with open(file_path, "wb") as handle:
				handle.write(downloaded.content)

		entity_type = "carticle" if parent_type == "article" else "cfamily"
		file_record = sqlm.CFileData(
			documenttype=to_storage_url_type(
				url_data.type, url_data.supplier_url or url_data.KOCO_url
			),
			description_json=json.dumps(
				{
					"description": url_data.description or "",
					"supplier_url": url_data.supplier_url,
					"ai_ingestion_download": True,
				},
				ensure_ascii=False,
			),
			oldfilename=downloaded.filename,
			entity_id=parent_id,
			entity_type=entity_type,
			mimetype=downloaded.mime_type,
			blake2shash=blake2shash,
			visibility=model_enums.CFiledataVisibility.everywhere.value,
			order_priority=100,
			user_id=user_id,
		)
		session.add(file_record)
		session.flush()
		return file_record

	def _create_figure_resource(
		self,
		*,
		job_id: int,
		session: Session,
		figure_data: IngestionFigure,
		family: sqlm.CFamily,
		created_articles: dict[str, sqlm.CArticle],
		user_id: int,
		pending_logs: list[ChangeLogEntry],
	) -> None:
		parent, parent_id = self._resolve_figure_parent(
			figure_data=figure_data,
			family=family,
			created_articles=created_articles,
		)
		preview_path, mime_type = self._get_job_figure_preview_path(
			job_id=job_id,
			preview_token=figure_data.preview_token,
		)
		with open(preview_path, "rb") as handle:
			content = handle.read()

		product_file_folder = self._get_product_file_folder()
		blake2shash = hashlib.blake2s(content).hexdigest()
		file_path = os.path.join(product_file_folder, blake2shash)
		if not os.path.exists(file_path):
			with open(file_path, "wb") as handle:
				handle.write(content)

		entity_type = "carticle" if parent == "article" else "cfamily"
		file_record = sqlm.CFileData(
			documenttype=to_storage_document_type(figure_data.type),
			description_json=json.dumps(
				{
					"description": figure_data.description or "",
					"ai_ingestion_extracted_figure": True,
					"source_id": figure_data.source_id,
					"source_figure_id": figure_data.source_figure_id,
					"locator": figure_data.locator,
					"context_excerpt": figure_data.context_excerpt,
				},
				ensure_ascii=False,
			),
			oldfilename=figure_data.filename
			or (figure_data.preview_token or "ingestion-figure.png"),
			entity_id=parent_id,
			entity_type=entity_type,
			mimetype=mime_type or figure_data.mime_type or "image/png",
			blake2shash=blake2shash,
			visibility=model_enums.CFiledataVisibility.everywhere.value,
			order_priority=100,
			user_id=user_id,
		)
		session.add(file_record)
		session.flush()
		self._queue_change_log(pending_logs, file_record, "POST")

	def _resolve_figure_parent(
		self,
		*,
		figure_data: IngestionFigure,
		family: sqlm.CFamily,
		created_articles: dict[str, sqlm.CArticle],
	) -> tuple[str, int]:
		if figure_data.parent == "article":
			article = created_articles.get(figure_data.article_name or "")
			if article is None:
				raise HTTPException(
					status_code=400,
					detail=(
						f"Figure references unknown article "
						f"'{figure_data.article_name}'"
					),
				)
			return "article", article.id
		return "family", family.id


__all__ = ["IngestionPersistenceRecordMixin"]
