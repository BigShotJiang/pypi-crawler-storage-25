from __future__ import annotations

import base64
import mimetypes
import re
from pathlib import Path

from koco_product_sqlmodel.fastapi.ai.ingestion_extraction_common import (
    FIGURE_CONTEXT_DISTANCE,
    FIGURE_RECT_PADDING,
    FIGURE_RENDER_MAX_EDGE_PX,
    MAX_FIGURES_PER_SOURCE,
    MAX_FIGURE_CONTEXT_CHARS,
    MAX_FIGURE_PAGE_COVERAGE,
    MAX_PDF_PAGES,
    MAX_TABLES_PER_SOURCE,
    MAX_TABLE_ROWS,
    MIN_FIGURE_AREA,
    MIN_FIGURE_SIDE_POINTS,
    ProgressCallback,
    IngestionDependencyError,
    IngestionSourceExtractionError,
    _emit_progress,
    _import_optional,
    _normalize_cell,
    _truncate_text,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
    ExtractedFigure,
    ExtractedSourceContent,
    ExtractedTable,
    IngestionSource,
    IngestionWarning,
)


def _extract_pdf(
    *,
    path: Path,
    source: IngestionSource,
    progress_callback: ProgressCallback | None = None,
) -> ExtractedSourceContent:
    fitz = _import_optional("fitz", package_name="PyMuPDF")
    warnings: list[IngestionWarning] = []
    text_parts: list[str] = []
    figures: list[ExtractedFigure] = []

    try:
        doc = fitz.open(path)
    except Exception as exc:
        raise IngestionSourceExtractionError(f"Failed to open PDF: {exc}") from exc

    try:
        page_count = min(doc.page_count, MAX_PDF_PAGES)
        _emit_progress(
            progress_callback,
            "source.pdf.started",
            f"Processing PDF pages for {source.filename or path.name}",
            {
                "page_count": page_count,
                "total_pages": doc.page_count,
            },
        )
        if doc.page_count > MAX_PDF_PAGES:
            warnings.append(
                IngestionWarning(
                    code="pdf_page_limit",
                    message=f"Only the first {MAX_PDF_PAGES} PDF pages were processed.",
                )
            )
        for index in range(page_count):
            page = doc[index]
            locator = f"page {index + 1}"
            page_text = (page.get_text("text") or "").strip()
            used_ocr = False
            if len(page_text) < 40:
                ocr_text = _extract_pdf_page_ocr(page)
                if ocr_text:
                    page_text = ocr_text
                    used_ocr = True
                else:
                    warnings.append(
                        IngestionWarning(
                            code="ocr_unavailable",
                            message=f"OCR was unavailable or empty for {locator}.",
                        )
                    )
            if page_text:
                text_parts.append(f"[{locator}]\n{page_text}")
            _emit_progress(
                progress_callback,
                "source.pdf.page.completed",
                f"Processed PDF page {index + 1}/{page_count}",
                {
                    "page_number": index + 1,
                    "page_count": page_count,
                    "text_char_count": len(page_text),
                    "used_ocr": used_ocr,
                },
            )
        _emit_progress(
            progress_callback,
            "source.pdf.text.completed",
            f"Extracted text from {page_count} PDF pages",
            {
                "page_count": page_count,
                "text_char_count": sum(len(part) for part in text_parts),
            },
        )
        figures = _extract_pdf_figures(
            doc=doc,
            fitz_module=fitz,
            progress_callback=progress_callback,
        )
    finally:
        doc.close()

    tables = _extract_pdf_tables(path=path, progress_callback=progress_callback)
    extracted = ExtractedSourceContent(
        source_id=source.id,
        title=source.filename or path.name,
        locator=source.filename or path.name,
        mime_type=source.mime_type or "application/pdf",
        text=_truncate_text("\n\n".join(text_parts)),
        tables=tables,
        figures=figures,
        warnings=warnings,
    )
    _emit_progress(
        progress_callback,
        "source.pdf.completed",
        f"Finished PDF extraction for {source.filename or path.name}",
        {
            "page_count": page_count,
            "table_count": len(tables),
            "figure_count": len(figures),
            "warning_count": len(warnings),
        },
    )
    return extracted


def _extract_pdf_page_ocr(page) -> str:
    try:
        text_page = page.get_textpage_ocr(dpi=300, full=True)
        return (page.get_text("text", textpage=text_page) or "").strip()
    except Exception:
        return ""


def _extract_pdf_tables(
    *, path: Path, progress_callback: ProgressCallback | None = None
) -> list[ExtractedTable]:
    try:
        pdfplumber = _import_optional("pdfplumber", package_name="pdfplumber")
    except IngestionDependencyError:
        return []

    tables: list[ExtractedTable] = []
    _emit_progress(
        progress_callback,
        "source.pdf.tables.started",
        f"Scanning PDF tables in {path.name}",
        None,
    )
    try:
        with pdfplumber.open(path) as pdf:
            for page_index, page in enumerate(pdf.pages[:MAX_PDF_PAGES]):
                raw_tables = page.extract_tables() or []
                page_table_count_before = len(tables)
                for table_index, raw_table in enumerate(raw_tables[:MAX_TABLES_PER_SOURCE]):
                    cleaned_rows = [
                        [_normalize_cell(cell) for cell in row]
                        for row in raw_table
                        if row and any(_normalize_cell(cell) for cell in row)
                    ]
                    if not cleaned_rows:
                        continue
                    headers = cleaned_rows[0]
                    rows = cleaned_rows[1 : MAX_TABLE_ROWS + 1]
                    tables.append(
                        ExtractedTable(
                            locator=f"page {page_index + 1}, table {table_index + 1}",
                            name=f"PDF table {table_index + 1}",
                            headers=headers,
                            rows=rows,
                        )
                    )
                    if len(tables) >= MAX_TABLES_PER_SOURCE:
                        _emit_progress(
                            progress_callback,
                            "source.pdf.tables.completed",
                            f"Extracted {len(tables)} PDF tables",
                            {"table_count": len(tables)},
                        )
                        return tables
                _emit_progress(
                    progress_callback,
                    "source.pdf.tables.page.completed",
                    f"Scanned PDF tables on page {page_index + 1}",
                    {
                        "page_number": page_index + 1,
                        "table_count": len(tables),
                        "page_table_count": len(tables) - page_table_count_before,
                    },
                )
    except Exception:
        return []
    _emit_progress(
        progress_callback,
        "source.pdf.tables.completed",
        f"Extracted {len(tables)} PDF tables",
        {"table_count": len(tables)},
    )
    return tables


def _extract_pdf_figures(
    *, doc, fitz_module, progress_callback: ProgressCallback | None = None
) -> list[ExtractedFigure]:
    figures: list[ExtractedFigure] = []
    next_figure_id = 1
    total_pages = min(doc.page_count, MAX_PDF_PAGES)

    _emit_progress(
        progress_callback,
        "source.pdf.figures.started",
        "Extracting images and drawings from PDF",
        {"page_count": total_pages},
    )

    for page_index in range(total_pages):
        page = doc[page_index]
        page_rect = page.rect
        text_dict = page.get_text("dict") or {}
        text_blocks = _extract_pdf_text_blocks(text_dict=text_dict, fitz_module=fitz_module)
        occupied_rects: list[object] = []
        candidates: list[dict[str, object]] = []

        for candidate in _extract_pdf_image_candidates(
            text_dict=text_dict,
            fitz_module=fitz_module,
            page_rect=page_rect,
        ):
            candidates.append(candidate)
            occupied_rects.append(candidate["rect"])

        for rect in _extract_pdf_drawing_rects(
            page=page,
            fitz_module=fitz_module,
            page_rect=page_rect,
            occupied_rects=occupied_rects,
        ):
            candidates.append(
                {
                    "candidate_kind": "vector_drawing",
                    "rect": rect,
                    "extraction_method": "page_crop",
                }
            )
            occupied_rects.append(rect)

        page_figures_before = len(figures)
        for candidate_index, candidate in enumerate(candidates, start=1):
            candidate_kind = str(candidate["candidate_kind"])
            rect = candidate["rect"]
            extraction_method = str(candidate.get("extraction_method") or "page_crop")
            image_data_url = candidate.get("image_data_url")
            mime_type = str(candidate.get("mime_type") or "image/png")
            pixel_width = candidate.get("width")
            pixel_height = candidate.get("height")
            if not image_data_url:
                image_data_url, pixel_width, pixel_height = _render_pdf_figure_data_url(
                    page=page,
                    rect=rect,
                    fitz_module=fitz_module,
                )
                if not image_data_url:
                    continue
                mime_type = "image/png"
            caption, context_text = _build_pdf_figure_context(
                rect=rect,
                text_blocks=text_blocks,
            )
            figures.append(
                ExtractedFigure(
                    figure_id=next_figure_id,
                    locator=f"page {page_index + 1}, figure {candidate_index}",
                    page_number=page_index + 1,
                    mime_type=mime_type,
                    width=pixel_width,
                    height=pixel_height,
                    kind_hint=_guess_pdf_figure_kind_hint(
                        candidate_kind=candidate_kind,
                        extraction_method=extraction_method,
                        caption=caption,
                        context_text=context_text,
                    ),
                    caption=caption,
                    context_text=context_text,
                    image_data_url=image_data_url,
                    extraction_method=extraction_method,
                )
            )
            next_figure_id += 1
            if len(figures) >= MAX_FIGURES_PER_SOURCE:
                _emit_progress(
                    progress_callback,
                    "source.pdf.figures.completed",
                    f"Extracted {len(figures)} PDF figure candidates",
                    {"figure_count": len(figures)},
                )
                return figures

        _emit_progress(
            progress_callback,
            "source.pdf.figures.page.completed",
            f"Scanned figure candidates on PDF page {page_index + 1}",
            {
                "page_number": page_index + 1,
                "candidate_count": len(candidates),
                "page_figure_count": len(figures) - page_figures_before,
                "figure_count": len(figures),
            },
        )

    _emit_progress(
        progress_callback,
        "source.pdf.figures.completed",
        f"Extracted {len(figures)} PDF figure candidates",
        {"figure_count": len(figures)},
    )
    return figures


def _extract_pdf_text_blocks(*, text_dict, fitz_module) -> list[tuple[object, str]]:
    blocks: list[tuple[object, str]] = []
    for block in text_dict.get("blocks", []):
        if block.get("type") != 0:
            continue
        lines: list[str] = []
        for line in block.get("lines", []):
            spans = [
                str(span.get("text", "")).strip()
                for span in line.get("spans", [])
                if str(span.get("text", "")).strip()
            ]
            if spans:
                lines.append(" ".join(spans))
        text = re.sub(r"\s+", " ", " ".join(lines)).strip()
        if not text:
            continue
        bbox = block.get("bbox")
        if not bbox:
            continue
        blocks.append((fitz_module.Rect(bbox), text))
    return blocks


def _extract_pdf_image_candidates(*, text_dict, fitz_module, page_rect) -> list[dict[str, object]]:
    candidates: list[dict[str, object]] = []
    for block in text_dict.get("blocks", []):
        if block.get("type") != 1 or not block.get("bbox"):
            continue
        try:
            rect = fitz_module.Rect(block["bbox"])
        except Exception:
            continue
        if _is_viable_pdf_figure_rect(rect=rect, page_rect=page_rect):
            image_data_url, mime_type, pixel_width, pixel_height = (
                _extract_pdf_embedded_image_data_url(block=block)
            )
            candidates.append(
                {
                    "candidate_kind": "embedded_image",
                    "rect": rect,
                    "image_data_url": image_data_url,
                    "mime_type": mime_type or "image/png",
                    "width": pixel_width,
                    "height": pixel_height,
                    "extraction_method": (
                        "embedded_image" if image_data_url else "page_crop"
                    ),
                }
            )
    return candidates


def _extract_pdf_embedded_image_data_url(
    *, block
) -> tuple[str | None, str | None, int | None, int | None]:
    image_bytes = block.get("image")
    if not isinstance(image_bytes, (bytes, bytearray)) or not image_bytes:
        return None, None, None, None

    extension = str(block.get("ext") or "").strip().lower().lstrip(".")
    if extension == "jpg":
        extension = "jpeg"
    if not extension:
        return None, None, None, None

    mime_type = mimetypes.guess_type(f"figure.{extension}")[0]
    if mime_type not in {"image/png", "image/jpeg", "image/webp", "image/gif"}:
        return None, None, None, None

    data_url = f"data:{mime_type};base64,"
    data_url += base64.b64encode(bytes(image_bytes)).decode("ascii")
    return (
        data_url,
        mime_type,
        _coerce_positive_int(block.get("width")),
        _coerce_positive_int(block.get("height")),
    )


def _extract_pdf_drawing_rects(*, page, fitz_module, page_rect, occupied_rects) -> list[object]:
    if not hasattr(page, "cluster_drawings"):
        return []

    rects: list[object] = []
    try:
        clusters = page.cluster_drawings()
    except Exception:
        return []

    for cluster in clusters or []:
        try:
            rect = _expand_pdf_figure_rect(
                rect=fitz_module.Rect(cluster),
                page_rect=page_rect,
                fitz_module=fitz_module,
            )
        except Exception:
            continue
        if not _is_viable_pdf_figure_rect(rect=rect, page_rect=page_rect):
            continue
        if _pdf_figure_rect_overlaps(rect=rect, others=occupied_rects):
            continue
        rects.append(rect)
    return rects


def _expand_pdf_figure_rect(*, rect, page_rect, fitz_module):
    expanded = fitz_module.Rect(
        max(page_rect.x0, rect.x0 - FIGURE_RECT_PADDING),
        max(page_rect.y0, rect.y0 - FIGURE_RECT_PADDING),
        min(page_rect.x1, rect.x1 + FIGURE_RECT_PADDING),
        min(page_rect.y1, rect.y1 + FIGURE_RECT_PADDING),
    )
    return expanded


def _is_viable_pdf_figure_rect(*, rect, page_rect) -> bool:
    if rect.width < MIN_FIGURE_SIDE_POINTS or rect.height < MIN_FIGURE_SIDE_POINTS:
        return False
    if rect.width * rect.height < MIN_FIGURE_AREA:
        return False
    page_area = max(page_rect.width * page_rect.height, 1)
    if (rect.width * rect.height) / page_area > MAX_FIGURE_PAGE_COVERAGE:
        return False
    return True


def _pdf_figure_rect_overlaps(*, rect, others: list[object]) -> bool:
    rect_area = max(rect.width * rect.height, 1)
    for other in others:
        overlap = rect & other
        if overlap.is_empty:
            continue
        overlap_area = max(overlap.width * overlap.height, 0)
        if overlap_area / rect_area >= 0.45:
            return True
    return False


def _render_pdf_figure_data_url(
    *, page, rect, fitz_module
) -> tuple[str | None, int | None, int | None]:
    max_edge_points = max(rect.width, rect.height, 1)
    zoom = min(max(FIGURE_RENDER_MAX_EDGE_PX / max_edge_points, 1.2), 3.0)
    try:
        pixmap = page.get_pixmap(
            matrix=fitz_module.Matrix(zoom, zoom),
            clip=rect,
            alpha=False,
        )
    except Exception:
        return None, None, None
    try:
        png_bytes = pixmap.tobytes("png")
    except Exception:
        return None, None, None
    data_url = "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii")
    return data_url, getattr(pixmap, "width", None), getattr(pixmap, "height", None)


def _build_pdf_figure_context(
    *, rect, text_blocks: list[tuple[object, str]]
) -> tuple[str | None, str]:
    relevant: list[tuple[float, str, str]] = []
    expanded_top = rect.y0 - FIGURE_CONTEXT_DISTANCE
    expanded_bottom = rect.y1 + FIGURE_CONTEXT_DISTANCE

    for block_rect, text in text_blocks:
        horizontal_overlap = min(rect.x1, block_rect.x1) - max(rect.x0, block_rect.x0)
        close_horizontally = horizontal_overlap > 0 or (
            abs(block_rect.x0 - rect.x1) < FIGURE_CONTEXT_DISTANCE
            or abs(rect.x0 - block_rect.x1) < FIGURE_CONTEXT_DISTANCE
        )
        if not close_horizontally:
            continue

        if block_rect.y1 <= rect.y0:
            distance = rect.y0 - block_rect.y1
            if distance <= FIGURE_CONTEXT_DISTANCE:
                relevant.append((distance, "above", text))
        elif block_rect.y0 >= rect.y1:
            distance = block_rect.y0 - rect.y1
            if distance <= FIGURE_CONTEXT_DISTANCE:
                relevant.append((distance, "below", text))
        elif block_rect.y0 <= expanded_bottom and block_rect.y1 >= expanded_top:
            relevant.append((0, "overlap", text))

    relevant.sort(key=lambda item: (item[0], item[1]))
    seen_texts: set[str] = set()
    context_parts: list[str] = []
    caption: str | None = None
    for _, placement, text in relevant:
        normalized = text.strip()
        if not normalized or normalized in seen_texts:
            continue
        seen_texts.add(normalized)
        if caption is None and placement in {"below", "above"}:
            caption = normalized
        context_parts.append(normalized)
        if len(" ".join(context_parts)) >= MAX_FIGURE_CONTEXT_CHARS:
            break

    context_text = _truncate_text("\n".join(context_parts), limit=MAX_FIGURE_CONTEXT_CHARS)
    return caption, context_text


def _guess_pdf_figure_kind_hint(
    *,
    candidate_kind: str,
    extraction_method: str,
    caption: str | None,
    context_text: str,
) -> str | None:
    haystack = f"{caption or ''} {context_text}".lower()
    if any(token in haystack for token in ("curve", "speed", "torque", "characteristic")):
        return "speed curves"
    if any(
        token in haystack
        for token in ("dimension", "drawing", "outline", "mounting", "mm", "inch")
    ):
        return "drawing"
    if candidate_kind == "embedded_image" and extraction_method == "embedded_image":
        return "photo"
    if candidate_kind == "vector_drawing":
        return "drawing"
    return None


def _coerce_positive_int(value: object) -> int | None:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


__all__ = [
    "_extract_pdf",
    "_extract_pdf_embedded_image_data_url",
]
