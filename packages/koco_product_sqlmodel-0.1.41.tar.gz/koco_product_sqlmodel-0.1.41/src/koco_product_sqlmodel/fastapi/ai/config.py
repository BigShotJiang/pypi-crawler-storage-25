from dataclasses import dataclass
import os

from dotenv import load_dotenv


load_dotenv()


@dataclass(frozen=True)
class AISettings:
    default_model: str
    max_tokens: int
    temperature: float
    openai_api_key: str | None
    azure_openai_api_key: str | None
    azure_openai_api_endpoint: str | None
    azure_openai_api_version: str

    @property
    def use_azure(self) -> bool:
        return bool(self.azure_openai_api_key and self.azure_openai_api_endpoint)

    @property
    def has_llm(self) -> bool:
        return bool(self.openai_api_key or self.use_azure)


def get_ai_settings() -> AISettings:
    return AISettings(
        default_model=os.getenv("DEFAULT_MODEL", "gpt-4.1"),
        max_tokens=int(os.getenv("MAX_TOKENS", "1500")),
        temperature=float(os.getenv("TEMPERATURE", "0.7")),
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        azure_openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        azure_openai_api_endpoint=os.getenv("AZURE_OPENAI_API_ENDPOINT"),
        azure_openai_api_version=os.getenv(
            "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"
        ),
    )
