from __future__ import annotations

import asyncio
import csv
import io
import ipaddress
import os
import re
import socket
import threading
from collections.abc import Callable
from dataclasses import dataclass
import mimetypes
from pathlib import Path
from urllib.parse import unquote, urlparse


MAX_DOWNLOAD_BYTES = 50_000_000
MAX_TEXT_CHARS = 80_000
MAX_PDF_PAGES = 100
MAX_TABLE_ROWS = 100
MAX_TABLES_PER_SOURCE = 40
MAX_EXPANDED_TABLES_PER_SOURCE = 120
MAX_FIGURES_PER_SOURCE = 24
MAX_FIGURE_CONTEXT_CHARS = 1_400
MAX_RELATED_DOCUMENTS = 60
MAX_RELATED_PAGES = 20
MAX_RELATED_MODEL_PAGES = 60
MAX_RELATED_SOURCE_TEXT_CHARS = 12_000
MAX_COMBINED_SOURCE_TEXT_CHARS = 200_000
PLAYWRIGHT_EXTRACTION_THRESHOLD = 300
HTTP_REQUEST_TIMEOUT_SECONDS = 60.0
HTTP_CONNECT_TIMEOUT_SECONDS = 10.0
PLAYWRIGHT_NAVIGATION_TIMEOUT_MS = 15_000
PLAYWRIGHT_COMMIT_TIMEOUT_MS = 8_000
PLAYWRIGHT_WAIT_FOR_BODY_TIMEOUT_MS = 5_000
PLAYWRIGHT_WAIT_FOR_LOAD_TIMEOUT_MS = 3_000
PLAYWRIGHT_POST_LOAD_SETTLE_MS = 1_200
MIN_FIGURE_SIDE_POINTS = 48
MIN_FIGURE_AREA = 8_000
MAX_FIGURE_PAGE_COVERAGE = 0.85
FIGURE_CONTEXT_DISTANCE = 120
FIGURE_RENDER_MAX_EDGE_PX = 1_200
FIGURE_RECT_PADDING = 8

SUPPORTED_TEXT_EXTENSIONS = {".txt", ".md"}
SUPPORTED_CSV_EXTENSIONS = {".csv", ".tsv"}
SUPPORTED_SPREADSHEET_EXTENSIONS = {".xlsx", ".xlsm"}
SUPPORTED_DOCX_EXTENSIONS = {".docx"}
SUPPORTED_PDF_EXTENSIONS = {".pdf"}
SUPPORTED_PDF_MIME_TYPES = {"application/pdf"}
SUPPORTED_DOCX_MIME_TYPES = {
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
}
SUPPORTED_SPREADSHEET_MIME_TYPES = {
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel.sheet.macroenabled.12",
    "application/vnd.ms-excel",
}
SUPPORTED_CSV_MIME_TYPES = {
    "text/csv",
    "text/tab-separated-values",
    "application/csv",
    "application/vnd.ms-excel",
}
PAGE_EXTENSIONS = {"", ".html", ".htm", ".php", ".asp", ".aspx"}
IGNORED_LINK_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".webp",
    ".svg",
    ".css",
    ".js",
    ".ico",
    ".mp4",
    ".webm",
    ".zip",
    ".rar",
    ".7z",
}
RELATED_DOCUMENT_KEYWORDS = (
    "datasheet",
    "data sheet",
    "technical data",
    "manual",
    "drawing",
    "download",
    "catalog",
    "certificate",
    "3d",
    "2d",
    "step",
    "cad",
)
RELATED_PAGE_KEYWORDS = (
    "article",
    "product",
    "variant",
    "model",
    "item",
    "part",
    "sku",
    "detail",
    "details",
    "overview",
)
ACCESSORY_CONTEXT_KEYWORDS = (
    "controller",
    "accessory",
    "accessories",
    "driver",
)
GENERIC_LINK_TOKENS = {
    "http",
    "https",
    "www",
    "com",
    "de",
    "en",
    "pdf",
    "downloads",
    "download",
    "datasheet",
    "guide",
    "product",
    "products",
    "produkt",
    "produkte",
    "page",
    "pages",
    "series",
    "model",
    "models",
    "stepper",
    "motor",
    "motors",
    "drive",
    "drives",
    "servo",
    "integrated",
    "closed",
    "loop",
    "wp",
    "content",
    "uploads",
}

ProgressCallback = Callable[[str, str, dict[str, object] | None], None]


class IngestionDependencyError(RuntimeError):
    pass


class IngestionSourceExtractionError(RuntimeError):
    pass


@dataclass(frozen=True)
class DownloadedSourceFile:
    url: str
    filename: str
    mime_type: str
    content: bytes


def ensure_safe_url(raw_url: str) -> str:
    url = raw_url.strip()
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise IngestionSourceExtractionError("Only http and https URLs are allowed")
    if not parsed.hostname:
        raise IngestionSourceExtractionError("URL hostname is missing")

    hostname = parsed.hostname.lower()
    if hostname in {"localhost"} or hostname.endswith(".local"):
        raise IngestionSourceExtractionError("Local URLs are not allowed")

    try:
        addr_info = socket.getaddrinfo(parsed.hostname, None)
    except socket.gaierror as exc:
        raise IngestionSourceExtractionError(f"Unable to resolve hostname: {exc}") from exc

    for info in addr_info:
        ip = ipaddress.ip_address(info[4][0])
        if (
            ip.is_loopback
            or ip.is_private
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
        ):
            raise IngestionSourceExtractionError("URL resolves to a blocked network address")

    return url


def _emit_progress(
    progress_callback: ProgressCallback | None,
    event_type: str,
    message: str,
    meta: dict[str, object] | None = None,
) -> None:
    if progress_callback is None:
        return
    progress_callback(event_type, message, meta)


def _read_response_content(response) -> tuple[str, bytes]:
    status_code = getattr(response, "status_code", None)
    if isinstance(status_code, int) and status_code >= 400:
        reason_phrase = str(getattr(response, "reason_phrase", "") or "").strip()
        response_url = str(getattr(response, "url", "") or "").strip()
        status_label = f"HTTP {status_code}"
        if reason_phrase:
            status_label = f"{status_label} {reason_phrase}"
        if response_url:
            raise IngestionSourceExtractionError(
                f"Remote resource returned {status_label} for {response_url}"
            )
        raise IngestionSourceExtractionError(
            f"Remote resource returned {status_label}"
        )

    content_type = response.headers.get("content-type", "").split(";", 1)[0].lower()
    content_length = response.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > MAX_DOWNLOAD_BYTES:
                raise IngestionSourceExtractionError("Remote response exceeds the download limit")
        except ValueError:
            pass

    content = response.content
    if len(content) > MAX_DOWNLOAD_BYTES:
        raise IngestionSourceExtractionError("Remote response exceeds the download limit")
    return content_type, content


def _infer_filename_from_response(
    *, response, url: str, filename_hint: str | None
) -> str:
    content_disposition = response.headers.get("content-disposition", "")
    filename_match = re.search(
        r"filename\*?=(?:UTF-8''|\"?)([^\";]+)",
        content_disposition,
        flags=re.IGNORECASE,
    )
    if filename_match:
        return unquote(filename_match.group(1)).strip()
    path_name = Path(unquote(urlparse(url).path)).name
    if filename_hint and filename_hint.strip():
        hinted = filename_hint.strip()
        if Path(hinted).suffix or not path_name:
            return hinted
        path_suffix = Path(path_name).suffix
        if path_suffix:
            return f"{hinted}{path_suffix}"
        return hinted
    return path_name or "source"


def _read_delimited_rows(path: Path) -> list[list[str]]:
    raw = path.read_text(encoding="utf-8", errors="ignore")
    sample = raw[:2048]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.get_dialect("excel")
    reader = csv.reader(io.StringIO(raw), dialect=dialect)
    rows: list[list[str]] = []
    for row in reader:
        normalized = [_normalize_cell(cell) for cell in row]
        if any(normalized):
            rows.append(normalized)
        if len(rows) >= MAX_TABLE_ROWS + 1:
            break
    return rows


def _looks_like_download(*, content_type: str, url: str) -> bool:
    extension = _suffix_from_source(url=url, filename=None)
    return (
        extension in SUPPORTED_PDF_EXTENSIONS
        or extension in SUPPORTED_DOCX_EXTENSIONS
        or extension in SUPPORTED_SPREADSHEET_EXTENSIONS
        or extension in SUPPORTED_CSV_EXTENSIONS
        or extension in SUPPORTED_TEXT_EXTENSIONS
        or extension in {".jpg", ".jpeg", ".png", ".webp"}
        or content_type.startswith("application/pdf")
        or content_type.startswith("image/")
        or "wordprocessingml" in content_type
        or "spreadsheetml" in content_type
        or content_type.startswith("text/plain")
        or content_type.startswith("text/csv")
    )


def _suffix_from_source(*, url: str | None, filename: str | None) -> str:
    candidate = filename or ""
    if not candidate and url:
        candidate = Path(urlparse(url).path).name
    return Path(candidate).suffix.lower()


def _normalize_cell(value) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _truncate_text(value: str, limit: int = MAX_TEXT_CHARS) -> str:
    normalized = re.sub(r"\n{3,}", "\n\n", value).strip()
    if len(normalized) <= limit:
        return normalized
    return normalized[:limit].rsplit(" ", 1)[0].rstrip() + "..."


def _import_optional(module_name: str, *, package_name: str):
    try:
        return __import__(module_name)
    except Exception as exc:
        raise IngestionDependencyError(
            f"{package_name} is not installed in the backend environment"
        ) from exc


def _render_url_with_playwright(url: str) -> tuple[str, str | None]:
    try:
        from playwright.async_api import async_playwright
    except Exception as exc:
        raise IngestionDependencyError(
            "Playwright is not installed in the backend environment"
        ) from exc

    async def _run() -> tuple[str, str | None]:
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(
                headless=True,
                args=["--disable-dev-shm-usage"],
            )
            try:
                context = await browser.new_context(
                    user_agent="KOCO-AI-Ingestion/1.0 (Playwright)",
                )
                page = await context.new_page()
                await page.route(
                    "**/*",
                    lambda route: (
                        route.abort()
                        if route.request.resource_type in {"image", "media", "font"}
                        else route.continue_()
                    ),
                )
                try:
                    await page.goto(
                        url,
                        wait_until="domcontentloaded",
                        timeout=PLAYWRIGHT_NAVIGATION_TIMEOUT_MS,
                    )
                except Exception:
                    await page.goto(
                        url,
                        wait_until="commit",
                        timeout=PLAYWRIGHT_COMMIT_TIMEOUT_MS,
                    )
                try:
                    await page.wait_for_selector(
                        "body",
                        timeout=PLAYWRIGHT_WAIT_FOR_BODY_TIMEOUT_MS,
                    )
                except Exception:
                    pass
                try:
                    await page.wait_for_load_state(
                        "load",
                        timeout=PLAYWRIGHT_WAIT_FOR_LOAD_TIMEOUT_MS,
                    )
                except Exception:
                    pass
                await page.wait_for_timeout(PLAYWRIGHT_POST_LOAD_SETTLE_MS)
                html_content = await page.content()
                title = await page.title()
            finally:
                await browser.close()
        return html_content, title

    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(_run())

    result: tuple[str, str | None] | None = None
    error: BaseException | None = None

    def _run_in_thread() -> None:
        nonlocal result, error
        try:
            result = asyncio.run(_run())
        except BaseException as exc:  # pragma: no cover
            error = exc

    worker = threading.Thread(target=_run_in_thread, daemon=True)
    worker.start()
    worker.join()
    if error is not None:
        raise error
    if result is None:  # pragma: no cover
        raise RuntimeError("Playwright render did not produce a result")
    return result


__all__ = [
    "ACCESSORY_CONTEXT_KEYWORDS",
    "DownloadedSourceFile",
    "FIGURE_CONTEXT_DISTANCE",
    "FIGURE_RECT_PADDING",
    "FIGURE_RENDER_MAX_EDGE_PX",
    "GENERIC_LINK_TOKENS",
    "HTTP_CONNECT_TIMEOUT_SECONDS",
    "HTTP_REQUEST_TIMEOUT_SECONDS",
    "IGNORED_LINK_EXTENSIONS",
    "IngestionDependencyError",
    "IngestionSourceExtractionError",
    "MAX_COMBINED_SOURCE_TEXT_CHARS",
    "MAX_DOWNLOAD_BYTES",
    "MAX_EXPANDED_TABLES_PER_SOURCE",
    "MAX_FIGURES_PER_SOURCE",
    "MAX_FIGURE_CONTEXT_CHARS",
    "MAX_FIGURE_PAGE_COVERAGE",
    "MAX_PDF_PAGES",
    "MAX_RELATED_DOCUMENTS",
    "MAX_RELATED_MODEL_PAGES",
    "MAX_RELATED_PAGES",
    "MAX_RELATED_SOURCE_TEXT_CHARS",
    "MAX_TABLES_PER_SOURCE",
    "MAX_TABLE_ROWS",
    "MAX_TEXT_CHARS",
    "MIN_FIGURE_AREA",
    "MIN_FIGURE_SIDE_POINTS",
    "PAGE_EXTENSIONS",
    "PLAYWRIGHT_COMMIT_TIMEOUT_MS",
    "PLAYWRIGHT_EXTRACTION_THRESHOLD",
    "PLAYWRIGHT_NAVIGATION_TIMEOUT_MS",
    "PLAYWRIGHT_POST_LOAD_SETTLE_MS",
    "PLAYWRIGHT_WAIT_FOR_BODY_TIMEOUT_MS",
    "PLAYWRIGHT_WAIT_FOR_LOAD_TIMEOUT_MS",
    "ProgressCallback",
    "RELATED_DOCUMENT_KEYWORDS",
    "RELATED_PAGE_KEYWORDS",
    "SUPPORTED_CSV_EXTENSIONS",
    "SUPPORTED_CSV_MIME_TYPES",
    "SUPPORTED_DOCX_EXTENSIONS",
    "SUPPORTED_DOCX_MIME_TYPES",
    "SUPPORTED_PDF_EXTENSIONS",
    "SUPPORTED_PDF_MIME_TYPES",
    "SUPPORTED_SPREADSHEET_EXTENSIONS",
    "SUPPORTED_SPREADSHEET_MIME_TYPES",
    "SUPPORTED_TEXT_EXTENSIONS",
    "_emit_progress",
    "_import_optional",
    "_infer_filename_from_response",
    "_looks_like_download",
    "_normalize_cell",
    "_read_delimited_rows",
    "_read_response_content",
    "_render_url_with_playwright",
    "_suffix_from_source",
    "_truncate_text",
    "ensure_safe_url",
]
