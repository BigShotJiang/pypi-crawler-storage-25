from __future__ import annotations

import base64
import json
import mimetypes
import re
import tempfile
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urljoin, urlparse

from koco_product_sqlmodel.fastapi.ai.ingestion_extraction_common import (
    DownloadedSourceFile,
    HTTP_CONNECT_TIMEOUT_SECONDS,
    HTTP_REQUEST_TIMEOUT_SECONDS,
    IGNORED_LINK_EXTENSIONS,
    MAX_EXPANDED_TABLES_PER_SOURCE,
    MAX_RELATED_SOURCE_TEXT_CHARS,
    PAGE_EXTENSIONS,
    PLAYWRIGHT_EXTRACTION_THRESHOLD,
    ProgressCallback,
    RELATED_DOCUMENT_KEYWORDS,
    SUPPORTED_CSV_EXTENSIONS,
    SUPPORTED_DOCX_EXTENSIONS,
    SUPPORTED_PDF_EXTENSIONS,
    SUPPORTED_SPREADSHEET_EXTENSIONS,
    SUPPORTED_TEXT_EXTENSIONS,
    IngestionSourceExtractionError,
    _emit_progress,
    _import_optional,
    _infer_filename_from_response,
    _looks_like_download,
    _read_response_content,
    _render_url_with_playwright,
    _suffix_from_source,
    _truncate_text,
    ensure_safe_url,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_extractors_files import (
    extract_file_source,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
    ExtractedFigure,
    ExtractedSourceContent,
    ExtractedTable,
    IngestionSource,
    IngestionWarning,
    RelatedSourceCandidate,
)

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
MAX_HTML_IMAGE_CANDIDATES = 12


@dataclass(frozen=True)
class _AnchorLinkContext:
    heading: str | None
    ancestor_tags: tuple[str, ...]
    ancestor_hints: tuple[str, ...]
    anchor_hints: tuple[str, ...]


@dataclass(frozen=True)
class _OpenElement:
    tag: str
    hints: tuple[str, ...]


@dataclass(frozen=True)
class _ParsedAnchorLink:
    href: str
    label: str | None
    context: _AnchorLinkContext


@dataclass(frozen=True)
class _ParsedImageCandidate:
    src: str
    label: str | None
    context: _AnchorLinkContext


def extract_url_source(
    source: IngestionSource,
    *,
    progress_callback: ProgressCallback | None = None,
) -> ExtractedSourceContent:
    if not source.url:
        raise IngestionSourceExtractionError("URL source is missing the URL field")

    safe_url = ensure_safe_url(source.url)
    httpx = _import_optional("httpx", package_name="httpx")
    try:
        with httpx.Client(
            follow_redirects=True,
            timeout=httpx.Timeout(
                HTTP_REQUEST_TIMEOUT_SECONDS,
                connect=HTTP_CONNECT_TIMEOUT_SECONDS,
            ),
            headers={"User-Agent": "KOCO-AI-Ingestion/1.0"},
        ) as client:
            _emit_progress(
                progress_callback,
                "source.fetch.started",
                f"Fetching source URL {safe_url}",
                {"url": safe_url},
            )
            return _extract_url_source_with_client(
                client=client,
                source=source,
                safe_url=safe_url,
                collect_related_candidates=True,
                progress_callback=progress_callback,
            )
    except IngestionSourceExtractionError:
        raise
    except Exception as exc:
        raise IngestionSourceExtractionError(f"Failed to fetch URL: {exc}") from exc


def expand_related_url_sources(
    source: IngestionSource,
    *,
    candidates: list[RelatedSourceCandidate],
    progress_callback: ProgressCallback | None = None,
) -> tuple[
    str,
    list[ExtractedTable],
    list[ExtractedFigure],
    list[RelatedSourceCandidate],
    list[IngestionWarning],
]:
    if not source.url:
        raise IngestionSourceExtractionError("URL source is missing the URL field")

    if not candidates:
        return "", [], [], [], []

    safe_url = ensure_safe_url(source.url)
    httpx = _import_optional("httpx", package_name="httpx")
    try:
        with httpx.Client(
            follow_redirects=True,
            timeout=httpx.Timeout(
                HTTP_REQUEST_TIMEOUT_SECONDS,
                connect=HTTP_CONNECT_TIMEOUT_SECONDS,
            ),
            headers={"User-Agent": "KOCO-AI-Ingestion/1.0"},
        ) as client:
            return _expand_related_source_context(
                client=client,
                candidates=candidates,
                source_id=source.id,
                progress_callback=progress_callback,
            )
    except IngestionSourceExtractionError:
        raise
    except Exception as exc:
        raise IngestionSourceExtractionError(
            f"Failed to expand related URL sources: {exc}"
        ) from exc


def download_url_file(
    raw_url: str, *, filename_hint: str | None = None
) -> DownloadedSourceFile:
    safe_url = ensure_safe_url(raw_url)
    httpx = _import_optional("httpx", package_name="httpx")
    try:
        with httpx.Client(
            follow_redirects=True,
            timeout=httpx.Timeout(
                HTTP_REQUEST_TIMEOUT_SECONDS,
                connect=HTTP_CONNECT_TIMEOUT_SECONDS,
            ),
            headers={"User-Agent": "KOCO-AI-Ingestion/1.0"},
        ) as client:
            response = client.get(safe_url)
    except IngestionSourceExtractionError:
        raise
    except Exception as exc:
        raise IngestionSourceExtractionError(f"Failed to fetch URL: {exc}") from exc

    content_type, content = _read_response_content(response)
    if not _looks_like_download(content_type=content_type, url=safe_url):
        raise IngestionSourceExtractionError(
            "URL does not point to a supported downloadable document"
        )

    filename = _infer_filename_from_response(
        response=response,
        url=safe_url,
        filename_hint=filename_hint,
    )
    mime_type = content_type or mimetypes.guess_type(filename)[0] or "application/octet-stream"
    return DownloadedSourceFile(
        url=safe_url,
        filename=filename,
        mime_type=mime_type,
        content=content,
    )


def _extract_url_source_with_client(
    *,
    client,
    source: IngestionSource,
    safe_url: str,
    collect_related_candidates: bool,
    title_hint: str | None = None,
    progress_callback: ProgressCallback | None = None,
) -> ExtractedSourceContent:
    response = client.get(safe_url)
    content_type, content = _read_response_content(response)
    _emit_progress(
        progress_callback,
        "source.fetch.completed",
        f"Fetched source URL {safe_url}",
        {"url": safe_url, "mime_type": content_type or "unknown"},
    )

    if _looks_like_image_asset(content_type=content_type, url=safe_url):
        return _extract_image_asset(
            source=source,
            url=safe_url,
            content_type=content_type,
            content=content,
            title_hint=title_hint,
        )

    if _looks_like_download(content_type=content_type, url=safe_url):
        filename = _infer_filename_from_response(
            response=response,
            url=safe_url,
            filename_hint=source.filename or title_hint,
        )
        suffix = _suffix_from_source(url=safe_url, filename=filename)
        _emit_progress(
            progress_callback,
            "source.document.started",
            f"Extracting linked document {filename}",
            {"url": safe_url, "filename": filename},
        )
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as handle:
            handle.write(content)
            temp_path = Path(handle.name)
        try:
            extracted_file = extract_file_source(
                IngestionSource(
                    **{
                        **source.model_dump(),
                        "mime_type": content_type or source.mime_type,
                        "filename": filename,
                    }
                ),
                temp_path,
                progress_callback=progress_callback,
            )
            _emit_progress(
                progress_callback,
                "source.document.completed",
                f"Extracted linked document {filename}",
                {"url": safe_url, "filename": filename},
            )
            return extracted_file
        finally:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass

    html_content = content.decode(response.encoding or "utf-8", errors="ignore")
    effective_title_hint = title_hint or source.filename
    _emit_progress(
        progress_callback,
        "source.parse.started",
        f"Extracting HTML content from {safe_url}",
        {"url": safe_url},
    )
    extracted = _extract_html_content(
        html_content=html_content,
        url=safe_url,
        source_id=source.id,
        title_hint=effective_title_hint,
    )
    _emit_progress(
        progress_callback,
        "source.parse.completed",
        f"Extracted HTML content from {safe_url}",
        {"url": safe_url, "title": extracted.title or ""},
    )
    chosen_html = html_content
    rendered_html: str | None = None
    rendered_title: str | None = None
    needs_rendered_text = len(extracted.text.strip()) < PLAYWRIGHT_EXTRACTION_THRESHOLD
    if needs_rendered_text or collect_related_candidates:
        _emit_progress(
            progress_callback,
            "source.render.started",
            f"Rendering page for enhanced extraction {safe_url}",
            {
                "url": safe_url,
                "reason": (
                    "text_fallback" if needs_rendered_text else "related_link_discovery"
                ),
            },
        )
        try:
            rendered_html, rendered_title = _render_url_with_playwright(safe_url)
        except Exception as exc:
            _emit_progress(
                progress_callback,
                "source.render.failed",
                f"Playwright rendering failed for {safe_url}: {exc}",
                {"url": safe_url},
            )
            extracted.warnings.append(
                IngestionWarning(
                    code="playwright_fallback_failed",
                    message=f"Playwright fallback failed: {exc}",
                )
            )
        else:
            if needs_rendered_text:
                rendered = _extract_html_content(
                    html_content=rendered_html,
                    url=safe_url,
                    source_id=source.id,
                    title_hint=rendered_title or extracted.title or effective_title_hint,
                )
                if len(rendered.text.strip()) > len(extracted.text.strip()):
                    rendered.warnings.extend(extracted.warnings)
                    extracted = rendered
                    chosen_html = rendered_html
            _emit_progress(
                progress_callback,
                "source.render.completed",
                f"Rendered page for enhanced extraction {safe_url}",
                {"url": safe_url, "title": rendered_title or extracted.title or ""},
            )

    if collect_related_candidates:
        extracted.related_candidates = _collect_related_link_candidates(
            html_contents=[
                variant for variant in [html_content, chosen_html, rendered_html] if variant
            ],
            base_url=safe_url,
            page_title=extracted.title or effective_title_hint,
        )
        _emit_progress(
            progress_callback,
            "source.related.candidates",
            (
                f"Collected {len(extracted.related_candidates)} related link candidates "
                f"from {safe_url}"
            ),
            {"candidate_count": len(extracted.related_candidates)},
        )

    return extracted


def _extract_image_asset(
    *,
    source: IngestionSource,
    url: str,
    content_type: str,
    content: bytes,
    title_hint: str | None,
) -> ExtractedSourceContent:
    mime_type = content_type or mimetypes.guess_type(url)[0] or "image/jpeg"
    image_data_url = f"data:{mime_type};base64,{base64.b64encode(content).decode('ascii')}"
    caption = title_hint or source.filename
    return ExtractedSourceContent(
        source_id=source.id,
        title=caption,
        locator=url,
        mime_type=mime_type,
        figures=[
            ExtractedFigure(
                figure_id=1,
                locator=url,
                mime_type=mime_type,
                caption=caption,
                context_text=caption or "",
                image_data_url=image_data_url,
                extraction_method="downloaded_image",
            )
        ],
    )


def _extract_html_content(
    *,
    html_content: str,
    url: str,
    source_id: int,
    title_hint: str | None,
) -> ExtractedSourceContent:
    trafilatura = _import_optional("trafilatura", package_name="trafilatura")
    text = (
        trafilatura.extract(
            html_content,
            include_tables=True,
            include_links=True,
            output_format="markdown",
            url=url,
        )
        or ""
    )
    title = title_hint
    try:
        metadata = trafilatura.extract_metadata(html_content)
        if metadata and getattr(metadata, "title", None):
            title = metadata.title
    except Exception:
        pass
    if not title:
        match = re.search(r"<title>(.*?)</title>", html_content, flags=re.IGNORECASE | re.DOTALL)
        if match:
            title = re.sub(r"\s+", " ", match.group(1)).strip()
    return ExtractedSourceContent(
        source_id=source_id,
        title=title,
        locator=url,
        mime_type="text/html",
        text=_truncate_text(text),
    )


def _looks_like_image_asset(*, content_type: str, url: str) -> bool:
    if content_type.startswith("image/"):
        return True
    return _suffix_from_source(url=url, filename=None) in IMAGE_EXTENSIONS


def _expand_related_source_context(
    *,
    client,
    candidates: list[RelatedSourceCandidate],
    source_id: int,
    progress_callback: ProgressCallback | None = None,
) -> tuple[
    str,
    list[ExtractedTable],
    list[ExtractedFigure],
    list[RelatedSourceCandidate],
    list[IngestionWarning],
]:
    blocks: list[str] = []
    tables: list[ExtractedTable] = []
    figures: list[ExtractedFigure] = []
    discovered_candidates: dict[str, RelatedSourceCandidate] = {}
    warnings: list[IngestionWarning] = []
    _emit_progress(
        progress_callback,
        "source.related.started",
        f"Processing {len(candidates)} agent-selected related supplier resources",
        {"selected_candidate_count": len(candidates)},
    )

    processed_candidates = 0
    for candidate in candidates:
        processed_candidates += 1
        candidate_label = candidate.label or candidate.url
        _emit_progress(
            progress_callback,
            "source.link.started",
            f"Processing linked {candidate.kind} {processed_candidates}: {candidate_label}",
            {
                "kind": candidate.kind,
                "url": candidate.url,
                "index": processed_candidates,
            },
        )
        try:
            safe_related_url = ensure_safe_url(candidate.url)
            related = _extract_url_source_with_client(
                client=client,
                source=IngestionSource(
                    id=source_id,
                    source_type="url",
                    url=safe_related_url,
                    filename=candidate.label,
                ),
                safe_url=safe_related_url,
                collect_related_candidates=(candidate.kind == "page"),
                title_hint=candidate.label,
                progress_callback=None,
            )
        except Exception as exc:
            _emit_progress(
                progress_callback,
                "source.link.failed",
                f"Linked {candidate.kind} failed: {candidate_label}",
                {"url": candidate.url, "error": str(exc)},
            )
            warnings.append(
                IngestionWarning(
                    code="linked_source_failed",
                    message=f"Linked source {candidate.url} failed: {exc}",
                )
            )
            continue

        block = _render_related_source_block(candidate=candidate, extracted=related)
        if block:
            blocks.append(block)
        tables.extend(_prefix_related_tables(candidate=candidate, tables=related.tables))
        figures.extend(related.figures)
        for related_candidate in related.related_candidates:
            discovered_candidates.setdefault(related_candidate.url, related_candidate)
        _emit_progress(
            progress_callback,
            "source.link.completed",
            f"Processed linked {candidate.kind} {processed_candidates}: {candidate_label}",
            {
                "kind": candidate.kind,
                "url": candidate.url,
                "table_count": len(related.tables),
            },
        )
        if len(tables) >= MAX_EXPANDED_TABLES_PER_SOURCE:
            tables = tables[:MAX_EXPANDED_TABLES_PER_SOURCE]
            break

    _emit_progress(
        progress_callback,
        "source.related.completed",
        "Finished scanning linked supplier resources",
        {"selected_candidate_count": len(candidates)},
    )
    return (
        "\n\n".join(blocks),
        tables[:MAX_EXPANDED_TABLES_PER_SOURCE],
        figures,
        list(discovered_candidates.values()),
        warnings,
    )


def _extract_related_link_candidates(
    *, html_content: str, base_url: str, page_title: str | None = None
) -> list[RelatedSourceCandidate]:
    parser = _AnchorLinkParser()
    parser.feed(html_content)
    best_by_url: dict[str, RelatedSourceCandidate] = {}

    for link in parser.links:
        candidate = _resolve_related_link_candidate(
            raw_href=link.href,
            label=link.label,
            context=link.context.heading,
            base_url=base_url,
        )
        if candidate is None:
            continue
        existing = best_by_url.get(candidate.url)
        if existing is None:
            best_by_url[candidate.url] = candidate

    for image in parser.images:
        candidate = _resolve_related_link_candidate(
            raw_href=image.src,
            label=image.label,
            context=image.context.heading,
            base_url=base_url,
        )
        if candidate is None:
            continue
        existing = best_by_url.get(candidate.url)
        if existing is None:
            best_by_url[candidate.url] = candidate

    return sorted(
        best_by_url.values(),
        key=lambda item: (
            0 if item.kind == "document" else 1 if item.kind == "image" else 2,
            (item.label or "").lower(),
            item.url.lower(),
        ),
    )


def _collect_related_link_candidates(
    *, html_contents: list[str], base_url: str, page_title: str | None = None
) -> list[RelatedSourceCandidate]:
    best_by_url: dict[str, RelatedSourceCandidate] = {}
    for html_content in html_contents:
        if not html_content:
            continue
        for candidate in _extract_related_link_candidates(
            html_content=html_content,
            base_url=base_url,
            page_title=page_title,
        ):
            existing = best_by_url.get(candidate.url)
            if existing is None:
                best_by_url[candidate.url] = candidate

    return sorted(
        best_by_url.values(),
        key=lambda item: (
            0 if item.kind == "document" else 1 if item.kind == "image" else 2,
            (item.label or "").lower(),
            item.url.lower(),
        ),
    )


def _resolve_related_link_candidate(
    *,
    raw_href: str,
    label: str | None,
    context: str | None,
    base_url: str,
) -> RelatedSourceCandidate | None:
    href = (raw_href or "").strip()
    if not href or href.startswith(("#", "mailto:", "tel:", "javascript:")):
        return None

    resolved = urljoin(base_url, href)
    resolved, _, _ = resolved.partition("#")
    parsed = urlparse(resolved)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return None

    normalized_label = _normalize_link_label(label, fallback_url=resolved)
    kind = _classify_related_link_kind(
        url=resolved,
        label=normalized_label,
        context=context,
        base_url=base_url,
    )
    if kind is None:
        return None

    if resolved == base_url:
        return None
    if kind == "page" and not _is_same_or_subdomain(
        parsed.hostname,
        (urlparse(base_url).hostname or "").lower(),
    ):
        return None

    return RelatedSourceCandidate(
        url=resolved,
        label=normalized_label,
        context=context,
        kind=kind,
    )


def _classify_related_link_kind(
    *,
    url: str,
    label: str | None,
    context: str | None,
    base_url: str,
) -> str | None:
    extension = _suffix_from_source(url=url, filename=None)
    if extension in IMAGE_EXTENSIONS:
        return "image"
    if extension in IGNORED_LINK_EXTENSIONS:
        return None

    if extension in (
        SUPPORTED_PDF_EXTENSIONS
        | SUPPORTED_DOCX_EXTENSIONS
        | SUPPORTED_SPREADSHEET_EXTENSIONS
        | SUPPORTED_CSV_EXTENSIONS
        | SUPPORTED_TEXT_EXTENSIONS
    ):
        return "document"

    if extension in PAGE_EXTENSIONS:
        return "page"

    haystack = f"{url} {label or ''} {context or ''}".lower()
    if any(keyword in haystack for keyword in RELATED_DOCUMENT_KEYWORDS):
        parsed = urlparse(url)
        base_host = (urlparse(base_url).hostname or "").lower()
        if parsed.hostname and not _is_same_or_subdomain(parsed.hostname, base_host):
            return "document"
    return None


def _normalize_link_label(label: str | None, *, fallback_url: str) -> str | None:
    normalized = re.sub(r"\s+", " ", (label or "")).strip()
    if normalized:
        return normalized[:240]
    path_name = Path(unquote(urlparse(fallback_url).path)).name
    if path_name:
        return path_name[:240]
    return None


def _is_same_or_subdomain(candidate_hostname: str, base_hostname: str) -> bool:
    candidate = candidate_hostname.lower()
    base = base_hostname.lower()
    return candidate == base or candidate.endswith(f".{base}")


def _render_related_source_block(
    *, candidate: RelatedSourceCandidate, extracted: ExtractedSourceContent
) -> str:
    related_text = _truncate_text(extracted.text, limit=MAX_RELATED_SOURCE_TEXT_CHARS)
    heading = candidate.label or extracted.title or extracted.locator or candidate.url
    parts = [
        f"[Linked {candidate.kind}]",
        f"Label: {heading}",
        f"URL: {candidate.url}",
    ]
    if candidate.context:
        parts.append(f"Context heading: {candidate.context}")
    if extracted.title and extracted.title != heading:
        parts.append(f"Extracted title: {extracted.title}")
    if extracted.mime_type:
        parts.append(f"MIME type: {extracted.mime_type}")
    if extracted.related_candidates:
        parts.append("Discovered related resources:")
        parts.append(
            json.dumps(
                [related_candidate.model_dump(mode="json") for related_candidate in extracted.related_candidates],
                ensure_ascii=False,
            )
        )
    if extracted.figures:
        parts.append(f"Extracted figures: {len(extracted.figures)}")
    if related_text:
        parts.append("Extracted content:")
        parts.append(related_text)
    elif extracted.tables:
        parts.append(f"Extracted tables: {len(extracted.tables)}")
    return "\n".join(parts)


def _prefix_related_tables(
    *, candidate: RelatedSourceCandidate, tables: list[ExtractedTable]
) -> list[ExtractedTable]:
    prefix = candidate.label or candidate.url
    result: list[ExtractedTable] = []
    for table in tables:
        result.append(
            ExtractedTable(
                locator=f"{prefix} • {table.locator or 'linked source'}",
                name=f"{prefix} • {table.name or 'Related table'}",
                headers=table.headers,
                rows=table.rows,
            )
        )
    return result


class _AnchorLinkParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[_ParsedAnchorLink] = []
        self.images: list[_ParsedImageCandidate] = []
        self._stack: list[_OpenElement] = []
        self._current_href: str | None = None
        self._current_title: str | None = None
        self._current_text_parts: list[str] = []
        self._current_link_context: _AnchorLinkContext | None = None
        self._heading_tag: str | None = None
        self._heading_parts: list[str] = []
        self._current_heading: str | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag_lower = tag.lower()
        attributes = dict(attrs)
        if tag_lower in {"h1", "h2", "h3", "h4", "h5", "h6"}:
            self._heading_tag = tag_lower
            self._heading_parts = []
        if tag_lower == "a":
            self._current_href = attributes.get("href")
            self._current_title = attributes.get("title")
            self._current_text_parts = []
            self._current_link_context = _AnchorLinkContext(
                heading=self._current_heading,
                ancestor_tags=tuple(element.tag for element in self._stack),
                ancestor_hints=tuple(
                    hint for element in self._stack for hint in element.hints
                ),
                anchor_hints=_extract_attr_hints(attributes),
            )
        if tag_lower == "img":
            src = attributes.get("src")
            if src:
                self.images.append(
                    _ParsedImageCandidate(
                        src=src,
                        label=attributes.get("alt") or attributes.get("title"),
                        context=_AnchorLinkContext(
                            heading=self._current_heading,
                            ancestor_tags=tuple(element.tag for element in self._stack),
                            ancestor_hints=tuple(
                                hint for element in self._stack for hint in element.hints
                            ),
                            anchor_hints=_extract_attr_hints(attributes),
                        ),
                    )
                )
        self._stack.append(
            _OpenElement(tag=tag_lower, hints=_extract_attr_hints(attributes))
        )

    def handle_data(self, data: str) -> None:
        if self._heading_tag is not None:
            self._heading_parts.append(data)
        if self._current_href is None:
            return
        self._current_text_parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        tag_lower = tag.lower()
        if self._heading_tag == tag_lower:
            heading = re.sub(r"\s+", " ", "".join(self._heading_parts)).strip()
            if heading:
                self._current_heading = heading
            self._heading_tag = None
            self._heading_parts = []
        if tag_lower == "a" and self._current_href is not None:
            label = (
                re.sub(r"\s+", " ", "".join(self._current_text_parts)).strip()
                or self._current_title
            )
            self.links.append(
                _ParsedAnchorLink(
                    href=self._current_href,
                    label=label,
                    context=self._current_link_context
                    or _AnchorLinkContext(
                        heading=self._current_heading,
                        ancestor_tags=(),
                        ancestor_hints=(),
                        anchor_hints=(),
                    ),
                )
            )
            self._current_href = None
            self._current_title = None
            self._current_text_parts = []
            self._current_link_context = None
        for index in range(len(self._stack) - 1, -1, -1):
            if self._stack[index].tag == tag_lower:
                del self._stack[index:]
                break


def _extract_attr_hints(attributes: dict[str, str | None]) -> tuple[str, ...]:
    hint_parts: list[str] = []
    for key in ("class", "id", "role", "data-role"):
        value = attributes.get(key)
        if value:
            hint_parts.extend(re.findall(r"[a-z0-9]+", value.lower()))
    return tuple(hint_parts)


__all__ = [
    "_collect_related_link_candidates",
    "_extract_related_link_candidates",
    "download_url_file",
    "expand_related_url_sources",
    "extract_url_source",
]
