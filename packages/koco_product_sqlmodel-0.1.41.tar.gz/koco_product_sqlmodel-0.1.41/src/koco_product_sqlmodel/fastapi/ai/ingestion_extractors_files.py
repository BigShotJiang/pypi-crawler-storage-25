from __future__ import annotations

from pathlib import Path

from koco_product_sqlmodel.fastapi.ai.ingestion_extraction_common import (
    MAX_TABLES_PER_SOURCE,
    MAX_TABLE_ROWS,
    ProgressCallback,
    SUPPORTED_CSV_EXTENSIONS,
    SUPPORTED_CSV_MIME_TYPES,
    SUPPORTED_DOCX_EXTENSIONS,
    SUPPORTED_DOCX_MIME_TYPES,
    SUPPORTED_PDF_EXTENSIONS,
    SUPPORTED_PDF_MIME_TYPES,
    SUPPORTED_SPREADSHEET_EXTENSIONS,
    SUPPORTED_SPREADSHEET_MIME_TYPES,
    SUPPORTED_TEXT_EXTENSIONS,
    IngestionSourceExtractionError,
    _emit_progress,
    _import_optional,
    _normalize_cell,
    _read_delimited_rows,
    _truncate_text,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_extractors_pdf import _extract_pdf
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
    ExtractedSourceContent,
    ExtractedTable,
    IngestionSource,
)


def extract_file_source(
    source: IngestionSource,
    file_path: str | Path,
    *,
    progress_callback: ProgressCallback | None = None,
) -> ExtractedSourceContent:
    path = Path(file_path)
    extension = path.suffix.lower()
    filename_extension = Path(source.filename or "").suffix.lower()
    mime_type = (source.mime_type or "").lower()
    source_label = source.filename or path.name

    if (
        extension in SUPPORTED_PDF_EXTENSIONS
        or filename_extension in SUPPORTED_PDF_EXTENSIONS
        or mime_type in SUPPORTED_PDF_MIME_TYPES
    ):
        file_type = "PDF"
        extractor = _extract_pdf
    elif (
        extension in SUPPORTED_DOCX_EXTENSIONS
        or filename_extension in SUPPORTED_DOCX_EXTENSIONS
        or mime_type in SUPPORTED_DOCX_MIME_TYPES
    ):
        file_type = "DOCX"
        extractor = _extract_docx
    elif (
        extension in SUPPORTED_SPREADSHEET_EXTENSIONS
        or filename_extension in SUPPORTED_SPREADSHEET_EXTENSIONS
        or mime_type in SUPPORTED_SPREADSHEET_MIME_TYPES
    ):
        file_type = "spreadsheet"
        extractor = _extract_spreadsheet
    elif (
        extension in SUPPORTED_CSV_EXTENSIONS
        or filename_extension in SUPPORTED_CSV_EXTENSIONS
        or mime_type in SUPPORTED_CSV_MIME_TYPES
    ):
        file_type = "CSV/TSV"
        extractor = _extract_csv
    elif (
        extension in SUPPORTED_TEXT_EXTENSIONS
        or filename_extension in SUPPORTED_TEXT_EXTENSIONS
        or mime_type.startswith("text/")
    ):
        file_type = "text"
        extractor = _extract_plain_text
    else:
        raise IngestionSourceExtractionError(
            "Unsupported source file format "
            f"'{filename_extension or path.suffix or mime_type or 'unknown'}'"
        )

    _emit_progress(
        progress_callback,
        "source.file.started",
        f"Opening {file_type} source {source_label}",
        {
            "filename": source_label,
            "mime_type": source.mime_type or "unknown",
        },
    )
    extracted = extractor(path=path, source=source, progress_callback=progress_callback)
    _emit_progress(
        progress_callback,
        "source.file.completed",
        f"Finished {file_type} extraction for {source_label}",
        {
            "filename": source_label,
            "table_count": len(extracted.tables),
            "figure_count": len(extracted.figures),
            "text_char_count": len(extracted.text),
        },
    )
    return extracted


def _extract_docx(
    *,
    path: Path,
    source: IngestionSource,
    progress_callback: ProgressCallback | None = None,
) -> ExtractedSourceContent:
    docx = _import_optional("docx", package_name="python-docx")
    _emit_progress(
        progress_callback,
        "source.docx.started",
        f"Reading DOCX content from {source.filename or path.name}",
        None,
    )
    try:
        document = docx.Document(path)
    except Exception as exc:
        raise IngestionSourceExtractionError(f"Failed to open DOCX: {exc}") from exc

    paragraphs = [
        paragraph.text.strip()
        for paragraph in document.paragraphs
        if paragraph.text.strip()
    ]
    tables: list[ExtractedTable] = []
    for index, table in enumerate(document.tables[:MAX_TABLES_PER_SOURCE]):
        rows = []
        for row in table.rows[: MAX_TABLE_ROWS + 1]:
            values = [cell.text.strip() for cell in row.cells]
            if any(values):
                rows.append(values)
        if not rows:
            continue
        tables.append(
            ExtractedTable(
                locator=f"table {index + 1}",
                name=f"DOCX table {index + 1}",
                headers=rows[0],
                rows=rows[1:],
            )
        )

    extracted = ExtractedSourceContent(
        source_id=source.id,
        title=source.filename or path.name,
        locator=source.filename or path.name,
        mime_type=source.mime_type
        or "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        text=_truncate_text("\n\n".join(paragraphs)),
        tables=tables,
    )
    _emit_progress(
        progress_callback,
        "source.docx.completed",
        f"Extracted DOCX content from {source.filename or path.name}",
        {
            "table_count": len(tables),
            "text_char_count": len(extracted.text),
        },
    )
    return extracted


def _extract_spreadsheet(
    *,
    path: Path,
    source: IngestionSource,
    progress_callback: ProgressCallback | None = None,
) -> ExtractedSourceContent:
    openpyxl = _import_optional("openpyxl", package_name="openpyxl")
    _emit_progress(
        progress_callback,
        "source.spreadsheet.started",
        f"Reading spreadsheet sheets from {source.filename or path.name}",
        None,
    )
    try:
        workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:
        raise IngestionSourceExtractionError(f"Failed to open spreadsheet: {exc}") from exc

    text_parts: list[str] = []
    tables: list[ExtractedTable] = []
    for worksheet in workbook.worksheets:
        rows: list[list[str]] = []
        for raw_row in worksheet.iter_rows(values_only=True):
            values = [_normalize_cell(value) for value in raw_row]
            if any(values):
                rows.append(values)
            if len(rows) >= MAX_TABLE_ROWS + 1:
                break
        if not rows:
            continue
        header = rows[0]
        body = rows[1:]
        tables.append(
            ExtractedTable(
                locator=f"sheet {worksheet.title}",
                name=worksheet.title,
                headers=header,
                rows=body,
            )
        )
        rendered_rows = [", ".join(cell for cell in row if cell) for row in rows]
        text_parts.append(f"[Sheet {worksheet.title}]\n" + "\n".join(rendered_rows))
        _emit_progress(
            progress_callback,
            "source.spreadsheet.sheet.completed",
            f"Parsed spreadsheet sheet {worksheet.title}",
            {
                "sheet_name": worksheet.title,
                "table_count": len(tables),
                "row_count": len(rows),
            },
        )
        if len(tables) >= MAX_TABLES_PER_SOURCE:
            break

    workbook.close()
    extracted = ExtractedSourceContent(
        source_id=source.id,
        title=source.filename or path.name,
        locator=source.filename or path.name,
        mime_type=source.mime_type
        or "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        text=_truncate_text("\n\n".join(text_parts)),
        tables=tables,
    )
    _emit_progress(
        progress_callback,
        "source.spreadsheet.completed",
        f"Extracted spreadsheet content from {source.filename or path.name}",
        {
            "sheet_count": len(tables),
            "table_count": len(tables),
            "text_char_count": len(extracted.text),
        },
    )
    return extracted


def _extract_csv(
    *,
    path: Path,
    source: IngestionSource,
    progress_callback: ProgressCallback | None = None,
) -> ExtractedSourceContent:
    _emit_progress(
        progress_callback,
        "source.csv.started",
        f"Reading delimited data from {source.filename or path.name}",
        None,
    )
    rows = _read_delimited_rows(path)
    if not rows:
        raise IngestionSourceExtractionError("CSV/TSV file is empty")
    extracted = ExtractedSourceContent(
        source_id=source.id,
        title=source.filename or path.name,
        locator=source.filename or path.name,
        mime_type=source.mime_type or "text/csv",
        text=_truncate_text("\n".join(", ".join(cell for cell in row if cell) for row in rows)),
        tables=[
            ExtractedTable(
                locator=source.filename or path.name,
                name=source.filename or path.stem,
                headers=rows[0],
                rows=rows[1 : MAX_TABLE_ROWS + 1],
            )
        ],
    )
    _emit_progress(
        progress_callback,
        "source.csv.completed",
        f"Extracted delimited data from {source.filename or path.name}",
        {
            "row_count": len(rows),
            "table_count": len(extracted.tables),
            "text_char_count": len(extracted.text),
        },
    )
    return extracted


def _extract_plain_text(
    *,
    path: Path,
    source: IngestionSource,
    progress_callback: ProgressCallback | None = None,
) -> ExtractedSourceContent:
    _emit_progress(
        progress_callback,
        "source.text.started",
        f"Reading plain text from {source.filename or path.name}",
        None,
    )
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        text = path.read_text(encoding="latin-1", errors="ignore")
    except OSError as exc:
        raise IngestionSourceExtractionError(f"Failed to read text file: {exc}") from exc

    extracted = ExtractedSourceContent(
        source_id=source.id,
        title=source.filename or path.name,
        locator=source.filename or path.name,
        mime_type=source.mime_type or "text/plain",
        text=_truncate_text(text),
    )
    _emit_progress(
        progress_callback,
        "source.text.completed",
        f"Extracted plain text from {source.filename or path.name}",
        {"text_char_count": len(extracted.text)},
    )
    return extracted


__all__ = [
    "_extract_csv",
    "_extract_docx",
    "_extract_pdf",
    "_extract_plain_text",
    "_extract_spreadsheet",
    "extract_file_source",
]
