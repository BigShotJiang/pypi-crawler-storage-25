from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass


DOWNLOADABLE_URL_TYPES = {
	"photo",
	"datasheet",
	"drawing",
	"manual",
	"catalog",
	"step",
	"2D drawing",
	"3D drawings",
	"3D models",
	"software",
	"firmware",
	"certifications",
	"speed curves",
	"screw_option",
	"accessories",
}


@dataclass(frozen=True)
class ChangeLogEntry:
	entity_id: int
	entity_type: str
	action: str
	new_values: str


ProgressCallback = Callable[[str, str, dict[str, object] | None], None]


def _emit_progress(
	progress_callback: ProgressCallback | None,
	event_type: str,
	message: str,
	meta: dict[str, object] | None = None,
) -> None:
	if progress_callback is None:
		return
	progress_callback(event_type, message, meta)


__all__ = [
	"ChangeLogEntry",
	"DOWNLOADABLE_URL_TYPES",
	"ProgressCallback",
	"_emit_progress",
]
