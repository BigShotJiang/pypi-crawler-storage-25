from __future__ import annotations

import json
from typing import Any

from koco_product_sqlmodel.fastapi.ai.ingestion_result_utils import (
	allows_embedded_photo,
	normalize_figure_type,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
	ExtractedFigure,
	ExtractedSourceContent,
	IngestionGatherPlan,
	IngestionResult,
	IngestionFigure,
	IngestionSource,
	IngestionSourceFigureFinding,
	IngestionSourceFinding,
	IngestionWarning,
	RelatedSourceCandidate,
)


RELATED_SOURCE_PLAN_MAX_TOKENS = 4_000
RELATED_SOURCE_PLAN_MAX_SELECTIONS = 40
RELATED_SOURCE_PLAN_SOURCE_TEXT_CHARS = 6_000
RELATED_SOURCE_PLAN_MAX_CANDIDATES = 60
SOURCE_FINDING_MAX_TOKENS = 24_000
MERGED_RESULT_MAX_TOKENS = 30_000
INGEST_STORAGE_CONVENTIONS = (
	"Storage conventions derived from the existing KOCO database and UI behavior:\n"
	"- 1831 of 2082 articles have exactly one article-level overview table. Match that pattern by default.\n"
	"- Family comparison views are built from article overview tables. Create one article_spectables "
	"overview table per article, not one family table.\n"
	"- Always create one article_spectables overview table per article when the source lists per-article core characteristics.\n"
	"- Use article_spectables type='overview' for the core comparable technical table of an "
	"article. Typical existing names are 'Motor Characteristics'. Use simple row positions "
	"'1', '2', ... with one property per row.\n"
	"- Use article_spectables type='singlecol' for article-specific detail lists such as "
	"'Parameter settings', 'I/O Specifications', 'Open Loop / Absolute Encoder', or "
	"'Software Specifications'. Use simple row positions '1', '2', ...\n"
	"- Use family_spectables type='singlecol' for facts that apply equally to the whole family, "
	"such as 'Family Specification', 'Family Overview', 'Mechanical Specifications', or a "
	"shared lead-screw code list.\n"
	"- Use family_spectables type='multicol' for family-wide matrices where the same row names "
	"repeat across several value columns, such as 'Gearbox Characteristics', "
	"'Encoder Characteristics', or lead-screw / screw-code / pitch tables that apply to all "
	"articles in the family. Encode multicol cells with pos='row;col'. Items in the same row "
	"repeat the same name across columns.\n"
	"- Prefer family multicol over family free when the same row names repeat across value columns.\n"
	"- Use type='free' for irregular grids with explicit header rows that do not fit "
	"overview, singlecol, or multicol. When you must use free, store header cells in row 0 "
	"using positions like '0;1', '0;2', ...\n"
)
INGEST_CLASSIFICATION_RULES = (
	"Classification rules:\n"
	"- Applications are end-use domains only, usually short nouns or noun phrases.\n"
	"- Options are selectable accessories, variants, or order-code choices. Real DB examples "
	"include category='Encoder' option='KPL56', category='Screw End Machining' option='Threaded End', "
	"category='Mechanical Arrangement' option='2 - Keyed shaft', or option='shaft length'.\n"
	"- Features are short product capabilities or sales bullets. They may be sentence fragments, "
	"but they are not spec-table rows.\n"
	"- Do not place measured specifications, motor constants, electrical ratings, dimensions, "
	"communication parameters, protection classes, pitch tables, or code matrices in "
	"options/features/applications. Those belong in spectables.\n"
	"- Non-examples for options/features: 'Voltage 24 V', 'Holding torque 31 Ncm', "
	"'Protection class IP65', 'Lead pitch 6.35 mm', 'Output current: 0-4.5 A'. "
	"These belong in tables.\n"
)
INGEST_OUTPUT_EXAMPLES = (
	"Output examples:\n"
	"1. Per-article core comparison table:\n"
	"article_spectables += {name:'Motor Characteristics', type:'overview', article_name:'ABC-123', "
	"items:[{pos:'1', name:'Voltage', value:'24', unit:'V'}, "
	"{pos:'2', name:'Holding torque', value:'31', unit:'Ncm'}]}\n"
	"2. Family-wide shared matrix:\n"
	"family_spectables += {name:'Gearbox Characteristics', type:'multicol', has_unit:true, items:["
	"{pos:'1;1', name:'Gearbox stages', value:'1', unit:''}, "
	"{pos:'1;2', name:'Gearbox stages', value:'2', unit:''}, "
	"{pos:'2;1', name:'Reduction ratio', value:'3.7~5.2', unit:'--'}, "
	"{pos:'2;2', name:'Reduction ratio', value:'13~27', unit:'--'}]}\n"
	"3. Family-wide shared list:\n"
	"family_spectables += {name:'Family Specification', type:'singlecol', has_unit:true, items:["
	"{pos:'1', name:'Protection Class', value:'IP65'}, "
	"{pos:'2', name:'Ambient temperature', value:'0 to 40', unit:'°C', min_value:'0', max_value:'40'}]}\n"
)


def plan_related_source_expansion(
	*,
	llm_streamer,
	family_name: str,
	source: IngestionSource,
	extracted: ExtractedSourceContent,
	candidates: list[RelatedSourceCandidate],
) -> IngestionGatherPlan:
	if not candidates:
		return IngestionGatherPlan()

	candidate_payload = [
		candidate.model_dump(mode="json")
		for candidate in candidates[:RELATED_SOURCE_PLAN_MAX_CANDIDATES]
	]
	source_text_excerpt = (extracted.text or "").strip()[
		:RELATED_SOURCE_PLAN_SOURCE_TEXT_CHARS
	]
	user_prompt = (
		"Decide which related supplier resources are worth fetching before final structured extraction.\n\n"
		"Goal: improve extraction quality while minimizing unnecessary requests, tokens, and noise.\n\n"
		f"Family name: {family_name}\n"
		f"Source ID: {source.id}\n"
		f"Source title: {extracted.title or source.filename or source.url or 'Unknown'}\n"
		f"Source locator: {extracted.locator or source.url or source.filename or 'Unknown'}\n\n"
		"Rules:\n"
		"- Select only candidates that are likely to add meaningful product-family data, concrete model variants, or primary technical resources.\n"
		"- Select every candidate that looks like a concrete article or model detail page for this family, not just a sample.\n"
		"- Prefer exact model detail pages, family-specific datasheets, manuals, drawings, curves, CAD files, and downloadable graphics or product images.\n"
		"- Skip generic navigation pages, broad category pages, and unrelated product groups unless they clearly contain the actual variant list for this family.\n"
		"- Skip accessory or adjacent products unless they are clearly part of the same family being ingested.\n"
		"- When a relevant article page is available, keep it so later extraction can collect article-specific files and pictures.\n"
		"- If the current source already appears sufficient, return an empty selection.\n"
		"- Return only URLs from the provided candidate list.\n"
		f"- Select at most {RELATED_SOURCE_PLAN_MAX_SELECTIONS} URLs.\n\n"
		f"Current source text excerpt:\n{source_text_excerpt or '[no text extracted]'}\n\n"
		f"Candidate links:\n{json.dumps(candidate_payload, ensure_ascii=False)}"
	)
	return llm_streamer.generate_structured(
		system_prompt=(
			"You decide which related supplier links to fetch for a product-ingestion run. "
			"Be selective and cost-aware. Prefer precision over recall."
		),
		user_prompt=user_prompt,
		response_model=IngestionGatherPlan,
		schema_name="koco_related_source_plan",
		max_tokens=RELATED_SOURCE_PLAN_MAX_TOKENS,
	)


def generate_source_finding(
	*,
	llm_streamer,
	family_name: str,
	source: IngestionSource,
	extracted: ExtractedSourceContent,
) -> IngestionSourceFinding:
	user_prompt = (
		"Extract KOCO catalog data from a single product source.\n\n"
		f"Family name: {family_name}\n"
		f"Source ID: {source.id}\n"
		f"Source type: {source.source_type}\n"
		f"Source title: {extracted.title or source.filename or source.url or 'Unknown'}\n"
		f"Source locator: {extracted.locator or source.url or source.filename or 'Unknown'}\n"
		f"Source MIME type: {extracted.mime_type or source.mime_type or 'unknown'}\n\n"
		"Rules:\n"
		"- Use only facts supported by the source text, linked supplier resources, or table candidates.\n"
		"- Scrape facts from any language, but write all structured text output in English.\n"
		"- Omit uncertain data instead of guessing.\n"
		"- Detect all distinct article variants or model names present in the source set.\n"
		"- Every populated field, article, application, option, and table should include evidence when possible.\n"
			"- Keep evidence compact: one short evidence entry per populated record is usually enough.\n"
			"- Keep evidence excerpts under 180 characters.\n"
			"- Descriptions and short descriptions should be concise English catalog text; they will be normalized later.\n"
			"- Option type must be 'Options' or 'Features'.\n"
			"- Populate urls with linked supplier resources discovered in the source, such as datasheets, manuals, drawings, CAD files, speed curves, image assets, and article pages.\n"
			"- Preserve all distinct useful family-level and article-level resources you can match. Do not keep only one representative document when multiple relevant files are present.\n"
			"- If article pages were crawled, include each relevant article page as an article-level supplier_site URL for the matching article when possible.\n"
			"- Include article-level manuals, datasheets, drawings, curves, and other downloadable files when they are clearly tied to one article.\n"
			"- Include family-level manuals, datasheets, drawings, curves, and other downloadable files when they apply to the whole family.\n"
			"- Do not echo the current source locator itself into urls unless a distinct linked resource points to it.\n"
			"- For article-specific resources, set parent='article' and article_name to the matching article.\n"
			"- For family-wide resources, set parent='family'.\n"
			"- Use URL types like photo, datasheet, manual, drawing, step, 2D drawing, 3D models, speed curves, or supplier_site.\n"
			"- article_spectables must reference article_name values that also exist in articles.\n"
		"- If core motor or product characteristics are given separately per article or variant, create one article overview table per article. "
		"Do not collapse those article comparison rows into a family table.\n"
		"- If a matrix applies to the whole family across shared variants such as gearbox stages, encoder variants, lead screw codes, or pitches, create one family table instead, usually type='multicol'.\n"
		"- Do not put table rows into options or features.\n\n"
		f"{INGEST_STORAGE_CONVENTIONS}\n"
		f"{INGEST_CLASSIFICATION_RULES}\n"
		f"{INGEST_OUTPUT_EXAMPLES}\n"
			f"Source text:\n{extracted.text or '[no text extracted]'}\n\n"
			"Discovered related resources:\n"
			f"{json.dumps([candidate.model_dump(mode='json') for candidate in extracted.related_candidates], ensure_ascii=False)}\n\n"
			"Table candidates:\n"
			f"{json.dumps([table.model_dump(mode='json') for table in extracted.tables], ensure_ascii=False)}"
		)
	return llm_streamer.generate_structured(
		system_prompt=(
			"You are a careful product data extraction assistant for KOCO. "
			"Return only structured facts supported by the source. "
			"Write all output in English."
		),
		user_prompt=user_prompt,
		response_model=IngestionSourceFinding,
		schema_name="koco_source_finding",
		max_tokens=SOURCE_FINDING_MAX_TOKENS,
	)


def generate_source_figure_finding(
	*,
	llm_streamer,
	family_name: str,
	source: IngestionSource,
	extracted: ExtractedSourceContent,
	article_candidates: list[str],
) -> IngestionSourceFigureFinding:
	if not extracted.figures:
		return IngestionSourceFigureFinding()

	figure_metadata = [
		serialize_extracted_figure_for_prompt(figure) for figure in extracted.figures
	]
	prompt_text = (
		"Classify extracted product figure candidates for KOCO ingestion.\n\n"
		f"Family name: {family_name}\n"
		f"Source ID: {source.id}\n"
		f"Source title: {extracted.title or source.filename or source.url or 'Unknown'}\n"
		f"Article candidates from this source: {json.dumps(article_candidates, ensure_ascii=False)}\n\n"
		"Rules:\n"
		"- Inspect the actual figure crop together with its metadata and nearby text context.\n"
		"- Keep only meaningful reusable assets such as product photos, dimensional drawings, wiring/outline drawings, and speed/performance curves.\n"
		"- Ignore logos, decorative icons, repeated headers/footers, seals, and low-value snippets.\n"
		"- Use type='photo' when candidate metadata indicates a true image asset such as extraction_method='embedded_image' or extraction_method='downloaded_image'. Never classify a rendered PDF page crop or screenshot as a product photo.\n"
		"- Candidates with extraction_method='page_crop' may still be kept as drawings or speed/performance curves when they are visually clean and useful.\n"
		"- Return source_figure_id exactly as provided in the candidate metadata.\n"
		"- Use figure types only from: photo, drawing, 2D drawing, 3D drawings, speed curves.\n"
		"- Use parent='article' only when the visible content or nearby text clearly points to one article candidate.\n"
		"- If article ownership is unclear, use parent='family' instead of guessing.\n"
		"- Keep descriptions short and concrete, for example 'Dimensional drawing', 'Speed-torque curve', or 'Product photo'.\n"
		"- Keep evidence excerpts under 180 characters.\n"
		"- Omit uncertain figures instead of guessing.\n\n"
		f"Figure candidate metadata:\n{json.dumps(figure_metadata, ensure_ascii=False)}"
	)
	user_content: list[dict[str, Any]] = [{"type": "text", "text": prompt_text}]
	for figure in extracted.figures:
		user_content.append(
			{
				"type": "text",
				"text": json.dumps(
					serialize_extracted_figure_for_prompt(figure), ensure_ascii=False
				),
			}
		)
		if figure.image_data_url:
			user_content.append(
				{
					"type": "image_url",
					"image_url": {
						"url": figure.image_data_url,
						"detail": "high",
					},
				}
			)

	try:
		result = llm_streamer.generate_structured_multimodal(
			system_prompt=(
				"You classify extracted product figures for KOCO. "
				"Return only structured facts supported by the image and nearby text. "
				"Write all output in English."
			),
			user_content=user_content,
			response_model=IngestionSourceFigureFinding,
			schema_name="koco_source_figure_finding",
			max_tokens=4_000,
		)
	except Exception as exc:
		fallback_prompt = (
			f"{prompt_text}\n\n"
			"Image input was unavailable for this attempt. Rely only on the provided figure "
			"metadata and nearby text."
		)
		result = llm_streamer.generate_structured(
			system_prompt=(
				"You classify extracted product figures for KOCO. "
				"Return only structured facts supported by the provided metadata. "
				"Write all output in English."
			),
			user_prompt=fallback_prompt,
			response_model=IngestionSourceFigureFinding,
			schema_name="koco_source_figure_finding",
			max_tokens=4_000,
		)
		result.warnings.append(
			IngestionWarning(
				code="figure_image_input_unavailable",
				message=(
					f"Figure classification for source {source.id} fell back to "
					f"text-only metadata: {exc}"
				),
			)
		)

	extracted_figures_by_id = {
		figure.figure_id: figure for figure in extracted.figures
	}
	filtered_figures: list[IngestionFigure] = []
	for figure in result.figures:
		if figure.source_id is None:
			figure.source_id = source.id
		if normalize_figure_type(figure.type) == "photo":
			extracted_figure = extracted_figures_by_id.get(figure.source_figure_id or -1)
			if extracted_figure is None or not allows_embedded_photo(extracted_figure):
				result.warnings.append(
					IngestionWarning(
						code="figure_photo_requires_embedded_image",
						message=(
							f"Skipped source {source.id} figure {figure.source_figure_id} "
							"as photo because it was only available as a rendered PDF crop."
						),
					)
				)
				continue
		filtered_figures.append(figure)
	result.figures = filtered_figures
	return result


def merge_source_findings(
	*, llm_streamer, family_name: str, findings: list[IngestionSourceFinding]
) -> IngestionResult:
	findings_payload = json.dumps(
		[finding.model_dump(mode="json") for finding in findings], ensure_ascii=False
	)
	user_prompt = (
		"Merge multiple source findings into one KOCO ingestion result.\n\n"
		f"Family name: {family_name}\n"
		"Rules:\n"
		"- Keep only data that is supported by one or more findings.\n"
		"- Deduplicate articles, applications, options, tables, and figures.\n"
		"- Prefer the most specific article names and the strongest evidence.\n"
		"- Preserve linked supplier resources in urls and attach them to family or article entries.\n"
		"- Preserve relevant figures in figures and keep source_id/source_figure_id so the crop can be materialized later.\n"
		"- Keep only figures that are meaningful reusable assets such as product photos, dimensional drawings, or speed/performance curves.\n"
		"- Write all generated text in English.\n"
		"- Keep evidence compact and do not repeat similar excerpts.\n"
		"- Preserve and merge warnings.\n"
		"- Ensure article_spectables.article_name always points to an article in articles.\n"
		"- Ensure figures.parent/article_name point to a real article when parent='article'; otherwise keep parent='family'.\n"
		"- Use order_priority descending from source order when there is no stronger ranking signal.\n"
		"- Keep one article overview table per article for core comparable specs when the source provides per-article measurements.\n"
		"- Do not merge article overview rows into a family table just because multiple articles share similar property names. The family UI compares article overview tables automatically.\n"
		"- Use family tables only for family-wide shared facts or family-wide matrices.\n"
		"- Prefer family multicol over free for shared matrices such as gearbox, encoder, or lead-screw code/pitch tables.\n"
		"- Keep options/features as short non-tabular labels or bullets. If an entry looks like a measured specification row, keep it in a table instead of options/features.\n\n"
		f"{INGEST_STORAGE_CONVENTIONS}\n"
		f"{INGEST_CLASSIFICATION_RULES}\n"
		f"Findings JSON:\n{findings_payload}"
	)
	return llm_streamer.generate_structured(
		system_prompt=(
			"You merge structured product findings into a final KOCO ingestion result. "
			"Do not invent unsupported data. Write all generated text in English."
		),
		user_prompt=user_prompt,
		response_model=IngestionResult,
		schema_name="koco_ingestion_result",
		max_tokens=MERGED_RESULT_MAX_TOKENS,
	)


def serialize_extracted_figure_for_prompt(figure: ExtractedFigure) -> dict[str, Any]:
	return {
		"source_figure_id": figure.figure_id,
		"locator": figure.locator,
		"page_number": figure.page_number,
		"extraction_method": figure.extraction_method,
		"kind_hint": figure.kind_hint,
		"caption": figure.caption,
		"context_text": figure.context_text,
		"width": figure.width,
		"height": figure.height,
	}
