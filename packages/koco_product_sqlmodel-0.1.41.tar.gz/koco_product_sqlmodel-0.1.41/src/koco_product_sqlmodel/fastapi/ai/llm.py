from __future__ import annotations

from copy import deepcopy
import json
from collections.abc import Callable, Generator
from typing import Any

from openai import AzureOpenAI, OpenAI
from pydantic import BaseModel, ValidationError

try:
    from openai.lib._pydantic import to_strict_json_schema as openai_to_strict_json_schema
except ImportError:  # pragma: no cover - fallback for older OpenAI SDKs
    openai_to_strict_json_schema = None

from koco_product_sqlmodel.fastapi.ai.config import AISettings


STRUCTURED_COMPLETION_TOKEN_CAP = 20_000


class LLMConfigurationError(RuntimeError):
    pass


class LLMStreamer:
    def __init__(self, settings: AISettings) -> None:
        self.settings = settings
        if not settings.has_llm:
            raise LLMConfigurationError(
                "No LLM credentials configured. Set OPENAI_API_KEY or Azure OpenAI credentials."
            )
        self.client = self._create_client(settings=settings)

    def generate_json_field(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        expected_field: str,
        max_attempts: int = 2,
        max_tokens: int | None = None,
    ) -> str:
        last_error: ValueError | None = None
        for attempt in range(max_attempts):
            prompt = user_prompt
            if attempt > 0:
                prompt = (
                    f"{user_prompt}\n\n"
                    f"Important: return a non-empty JSON string in the '{expected_field}' field."
                )
            response = self._create_chat_completion(
                model=self.settings.default_model,
                temperature=self.settings.temperature,
                response_format={"type": "json_object"},
                max_tokens=max_tokens or self.settings.max_tokens,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt},
                ],
            )
            finish_reason = self._extract_finish_reason(response)
            try:
                content = self._extract_response_content(response)
            except ValueError as exc:
                last_error = exc
                if self._should_retry_after_empty_content(
                    error=exc, finish_reason=finish_reason
                ):
                    continue
                raise
            payload = json.loads(self._strip_code_fences(content))
            value = payload.get(expected_field)
            if not isinstance(value, str):
                last_error = ValueError(
                    f"Expected string field '{expected_field}' in LLM response"
                )
                continue
            normalized = value.strip()
            if normalized:
                return normalized
            last_error = ValueError(
                f"LLM returned empty '{expected_field}' value after parsing JSON."
            )
        if last_error is not None:
            raise last_error
        raise ValueError(f"Failed to generate '{expected_field}'")

    def stream_text(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int | None = None,
    ) -> Generator[str, None, str]:
        stream = self._create_chat_completion(
            model=self.settings.default_model,
            temperature=self.settings.temperature,
            stream=True,
            max_tokens=max_tokens or self.settings.max_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        chunks: list[str] = []
        for chunk in stream:
            delta = self._extract_stream_delta(chunk)
            if not delta:
                continue
            chunks.append(delta)
            yield delta
        if not chunks:
            raise ValueError(
                "LLM stream returned no content. Check the configured model or deployment."
            )
        return "".join(chunks)

    def generate_structured(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        response_model: type[BaseModel],
        schema_name: str,
        max_tokens: int | None = None,
        max_attempts: int = 3,
    ) -> BaseModel:
        return self._generate_structured_response(
            system_prompt=system_prompt,
            response_model=response_model,
            schema_name=schema_name,
            max_tokens=max_tokens,
            max_attempts=max_attempts,
            failure_label="structured output",
            build_user_content=lambda attempt: (
                user_prompt
                if attempt == 0
                else (
                    f"{user_prompt}\n\n"
                    "Important: return valid minified JSON only that matches the schema exactly. "
                    "Do not include markdown, prose, or code fences. "
                    "Keep evidence excerpts short and prefer one concise evidence item per record. "
                    "If the full result does not fit, omit lower-priority evidence and secondary records "
                    "instead of truncating the JSON."
                )
            ),
        )

    def generate_structured_multimodal(
        self,
        *,
        system_prompt: str,
        user_content: list[dict[str, Any]],
        response_model: type[BaseModel],
        schema_name: str,
        max_tokens: int | None = None,
        max_attempts: int = 3,
    ) -> BaseModel:
        return self._generate_structured_response(
            system_prompt=system_prompt,
            response_model=response_model,
            schema_name=schema_name,
            max_tokens=max_tokens,
            max_attempts=max_attempts,
            failure_label="structured multimodal output",
            build_user_content=lambda attempt: self._build_multimodal_user_content(
                user_content=user_content,
                attempt=attempt,
            ),
        )

    def _generate_structured_response(
        self,
        *,
        system_prompt: str,
        response_model: type[BaseModel],
        schema_name: str,
        max_tokens: int | None,
        max_attempts: int,
        failure_label: str,
        build_user_content: Callable[[int], str | list[dict[str, Any]]],
    ) -> BaseModel:
        schema = self._build_strict_json_schema(response_model)
        requested_max_tokens = max_tokens or self.settings.max_tokens
        last_error: Exception | None = None
        last_finish_reason: str | None = None

        for attempt in range(max_attempts):
            user_content = build_user_content(attempt)
            response = self._create_chat_completion(
                model=self.settings.default_model,
                temperature=0,
                response_format={
                    "type": "json_schema",
                    "json_schema": {
                        "name": schema_name,
                        "schema": schema,
                        "strict": True,
                    },
                },
                max_tokens=min(
                    requested_max_tokens + (attempt * 750),
                    max(requested_max_tokens, STRUCTURED_COMPLETION_TOKEN_CAP),
                ),
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_content},
                ],
            )
            last_finish_reason = self._extract_finish_reason(response)
            try:
                content = self._extract_response_content(response)
            except ValueError as exc:
                last_error = exc
                if self._should_retry_after_empty_content(
                    error=exc, finish_reason=last_finish_reason
                ):
                    continue
                raise
            try:
                payload = json.loads(self._strip_code_fences(content))
                return response_model.model_validate(payload)
            except (json.JSONDecodeError, ValidationError) as exc:
                last_error = exc
                continue

        finish_reason_suffix = (
            f" (finish_reason={last_finish_reason})" if last_finish_reason else ""
        )
        raise ValueError(
            f"Failed to generate valid {failure_label} for '{schema_name}'"
            f"{finish_reason_suffix}: {last_error}"
        )

    def _build_multimodal_user_content(
        self, *, user_content: list[dict[str, Any]], attempt: int
    ) -> list[dict[str, Any]]:
        prompt_content = deepcopy(user_content)
        if attempt > 0:
            prompt_content.append(
                {
                    "type": "text",
                    "text": (
                        "Important: return valid minified JSON only that matches the schema "
                        "exactly. Do not include markdown, prose, or code fences. If a field is "
                        "uncertain, omit that record instead of guessing."
                    ),
                }
            )
        return prompt_content

    def _build_strict_json_schema(self, response_model: type[BaseModel]) -> dict[str, Any]:
        if openai_to_strict_json_schema is not None:
            return openai_to_strict_json_schema(response_model)
        strict_schema = deepcopy(response_model.model_json_schema())
        self._close_object_schemas(strict_schema)
        return strict_schema

    def _close_object_schemas(self, node: Any) -> None:
        if isinstance(node, dict):
            if node.get("type") == "object":
                if "additionalProperties" not in node:
                    node["additionalProperties"] = False
                if "required" not in node:
                    properties = node.get("properties")
                    if isinstance(properties, dict):
                        node["required"] = list(properties.keys())
                    else:
                        node["required"] = []
            for value in node.values():
                self._close_object_schemas(value)
            return
        if isinstance(node, list):
            for item in node:
                self._close_object_schemas(item)

    def _create_client(self, settings: AISettings) -> OpenAI | AzureOpenAI:
        if settings.use_azure:
            return AzureOpenAI(
                api_key=settings.azure_openai_api_key,
                azure_endpoint=settings.azure_openai_api_endpoint,
                api_version=settings.azure_openai_api_version,
            )
        return OpenAI(api_key=settings.openai_api_key)

    def _create_chat_completion(self, *, max_tokens: int, **kwargs: Any) -> Any:
        request_kwargs = dict(kwargs)
        request_kwargs.update(
            self._build_completion_token_kwargs(
                model=str(request_kwargs.get("model") or self.settings.default_model),
                max_tokens=max_tokens,
            )
        )
        try:
            return self.client.chat.completions.create(**request_kwargs)
        except Exception as exc:
            retry_kwargs = self._build_retry_with_alternate_token_param(
                request_kwargs=request_kwargs,
                error=exc,
            )
            if retry_kwargs is None:
                raise
            return self.client.chat.completions.create(**retry_kwargs)

    def _build_completion_token_kwargs(
        self, *, model: str, max_tokens: int
    ) -> dict[str, int]:
        if self._prefers_max_completion_tokens(model):
            return {"max_completion_tokens": max_tokens}
        return {"max_tokens": max_tokens}

    def _prefers_max_completion_tokens(self, model: str) -> bool:
        normalized = model.strip().lower()
        return normalized.startswith("gpt-5")

    def _build_retry_with_alternate_token_param(
        self, *, request_kwargs: dict[str, Any], error: Exception
    ) -> dict[str, Any] | None:
        unsupported_param = self._extract_unsupported_token_param(error)
        if unsupported_param not in {"max_tokens", "max_completion_tokens"}:
            return None
        if unsupported_param not in request_kwargs:
            return None
        alternate_param = (
            "max_completion_tokens"
            if unsupported_param == "max_tokens"
            else "max_tokens"
        )
        if alternate_param in request_kwargs:
            return None
        retry_kwargs = dict(request_kwargs)
        retry_kwargs[alternate_param] = retry_kwargs.pop(unsupported_param)
        return retry_kwargs

    def _extract_unsupported_token_param(self, error: Exception) -> str | None:
        body = getattr(error, "body", None)
        if isinstance(body, dict):
            details = body.get("error")
            if isinstance(details, dict):
                param = details.get("param")
                code = details.get("code")
                if code == "unsupported_parameter" and param in {
                    "max_tokens",
                    "max_completion_tokens",
                }:
                    return str(param)

        message = str(error)
        for param in ("max_tokens", "max_completion_tokens"):
            if f"Unsupported parameter: '{param}'" in message:
                return param
        return None

    def _should_retry_after_empty_content(
        self, *, error: Exception, finish_reason: str | None
    ) -> bool:
        return finish_reason == "length" and "empty content" in str(error).lower()

    def _strip_code_fences(self, value: str) -> str:
        stripped = value.strip()
        if stripped.startswith("```") and stripped.endswith("```"):
            lines = stripped.splitlines()
            return "\n".join(lines[1:-1]).strip()
        return stripped

    def _extract_response_content(self, response: Any) -> str:
        choices = getattr(response, "choices", None) or []
        if not choices:
            raise ValueError(
                "LLM returned no choices. Check the configured model or Azure deployment."
            )
        message = getattr(choices[0], "message", None)
        content = getattr(message, "content", None)
        if not content:
            finish_reason = getattr(choices[0], "finish_reason", None)
            raise ValueError(
                f"LLM returned empty content (finish_reason={finish_reason})."
            )
        if isinstance(content, list):
            collected: list[str] = []
            for part in content:
                if isinstance(part, dict):
                    text = part.get("text")
                    if text:
                        collected.append(str(text))
                else:
                    text = getattr(part, "text", None)
                    if text:
                        collected.append(str(text))
            if collected:
                return "".join(collected)
            finish_reason = getattr(choices[0], "finish_reason", None)
            raise ValueError(
                f"LLM returned empty content (finish_reason={finish_reason})."
            )
        return str(content)

    def _extract_finish_reason(self, response: Any) -> str | None:
        choices = getattr(response, "choices", None) or []
        if not choices:
            return None
        return getattr(choices[0], "finish_reason", None)

    def _extract_stream_delta(self, chunk: Any) -> str:
        choices = getattr(chunk, "choices", None) or []
        if not choices:
            return ""
        delta = getattr(choices[0], "delta", None)
        content = getattr(delta, "content", None)
        if not content:
            return ""
        return str(content)
