from __future__ import annotations

import datetime as dt
import json
from typing import Any

from fastapi import HTTPException
from sqlalchemy import inspect as sa_inspect, text
from sqlmodel import Session, select

from koco_product_sqlmodel.dbmodels.aiingestionjob import CAIIngestionJob
from koco_product_sqlmodel.dbmodels.backgroundjob import CBackgroundJob
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
    IngestionEvent,
    IngestionJob,
    IngestionSource,
    IngestionWarning,
)
from koco_product_sqlmodel.mdb_connect.init_db_con import mdb_engine

_UNSET = object()
INGESTION_JOB_TYPE = "ai_ingestion"
TERMINAL_JOB_STATUSES = {"completed", "failed", "applied"}
MAX_STORED_EVENTS = 120
MAX_EVENTS_JSON_CHARS = 48_000


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class IngestionJobRepository:
    def create_job(
        self,
        *,
        entity_id: int,
        entity_type: str,
        user_id: int,
        sources: list[IngestionSource],
    ) -> CAIIngestionJob | CBackgroundJob:
        if self._use_legacy_table():
            # TODO(background-job-migration): remove the caiingestionjob write path after
            # production has run scripts/create_backgroundjob_table.py.
            record = CAIIngestionJob(
                entity_id=entity_id,
                entity_type=entity_type,
                status="pending",
                phase="queued",
                sources_json=self._dump_sources_text(sources),
                events_json="[]",
                warnings_json="[]",
                error_text=None,
                user_id=user_id,
            )
        else:
            source_payload = self._dump_sources_payload(sources)
            record = CBackgroundJob(
                job_type=INGESTION_JOB_TYPE,
                entity_id=entity_id,
                entity_type=entity_type,
                status="pending",
                phase="queued",
                payload_json={"sources": source_payload},
                state_json={"sources": source_payload},
                events_json=[],
                warnings_json=[],
                error_text=None,
                user_id=user_id,
            )
        with Session(mdb_engine) as session:
            session.add(record)
            session.commit()
            session.refresh(record)
        return record

    def get_record(self, job_id: int) -> CAIIngestionJob | CBackgroundJob | None:
        model = self._active_model()
        with Session(mdb_engine) as session:
            if model is CAIIngestionJob:
                return session.exec(
                    select(CAIIngestionJob).where(CAIIngestionJob.id == job_id)
                ).one_or_none()
            return session.exec(
                select(CBackgroundJob).where(
                    CBackgroundJob.id == job_id,
                    CBackgroundJob.job_type == INGESTION_JOB_TYPE,
                )
            ).one_or_none()

    def get_job(self, job_id: int) -> IngestionJob:
        record = self.get_record(job_id=job_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Ingestion job not found")
        return self._to_job(record)

    def reset_job(self, job_id: int) -> IngestionJob:
        with Session(mdb_engine) as session:
            record = self._get_record_for_update(session=session, job_id=job_id)
            sources = self._get_record_sources(record)
            for source in sources:
                source.status = "pending"
                source.error_text = None
            record.status = "pending"
            record.phase = "queued"
            record.error_text = None
            record.applied_at = None
            self._set_record_sources(record, sources)
            self._set_record_events(record, [])
            self._set_record_warnings(record, [])
            if isinstance(record, CBackgroundJob):
                record.started_at = None
                record.finished_at = None
            session.add(record)
            session.commit()
            session.refresh(record)
            return self._to_job(record)

    def append_event(
        self,
        job_id: int,
        *,
        event_type: str,
        message: str,
        source_id: int | None = None,
        meta: dict[str, Any] | None = None,
    ) -> IngestionEvent:
        with Session(mdb_engine) as session:
            record = self._get_record_for_update(session=session, job_id=job_id)
            events = self._get_record_events(record)
            event = IngestionEvent(
                job_id=job_id,
                sequence=(events[-1].sequence + 1) if events else 1,
                timestamp=utcnow(),
                type=event_type,
                message=message,
                source_id=source_id,
                meta=meta,
            )
            events.append(event)
            events = self._trim_events(events)
            self._set_record_events(record, events)
            session.add(record)
            session.commit()
            return event

    def get_events(self, job_id: int) -> list[IngestionEvent]:
        record = self.get_record(job_id=job_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Ingestion job not found")
        return self._get_record_events(record)

    def update_source(
        self,
        job_id: int,
        source_id: int,
        *,
        status: str | object = _UNSET,
        error_text: str | None | object = _UNSET,
        mime_type: str | None | object = _UNSET,
        filename: str | None | object = _UNSET,
    ) -> IngestionJob:
        with Session(mdb_engine) as session:
            record = self._get_record_for_update(session=session, job_id=job_id)
            sources = self._get_record_sources(record)
            source = next((item for item in sources if item.id == source_id), None)
            if source is None:
                raise HTTPException(
                    status_code=404, detail="Ingestion source not found"
                )
            if status is not _UNSET:
                source.status = str(status)
            if error_text is not _UNSET:
                source.error_text = error_text
            if mime_type is not _UNSET:
                source.mime_type = mime_type
            if filename is not _UNSET:
                source.filename = filename
            self._set_record_sources(record, sources)
            session.add(record)
            session.commit()
            session.refresh(record)
            return self._to_job(record)

    def update_job_state(
        self,
        job_id: int,
        *,
        status: str | object = _UNSET,
        phase: str | object = _UNSET,
        warnings: list[IngestionWarning] | object = _UNSET,
        error_text: str | None | object = _UNSET,
        applied_at: dt.datetime | None | object = _UNSET,
    ) -> IngestionJob:
        with Session(mdb_engine) as session:
            record = self._get_record_for_update(session=session, job_id=job_id)
            if status is not _UNSET:
                next_status = str(status)
                record.status = next_status
                if isinstance(record, CBackgroundJob):
                    if next_status == "running" and record.started_at is None:
                        record.started_at = utcnow()
                    if (
                        next_status in TERMINAL_JOB_STATUSES
                        and record.finished_at is None
                    ):
                        record.finished_at = utcnow()
            if phase is not _UNSET:
                record.phase = str(phase)
            if warnings is not _UNSET:
                self._set_record_warnings(record, list(warnings))
            if error_text is not _UNSET:
                record.error_text = error_text
            if applied_at is not _UNSET:
                record.applied_at = applied_at
            session.add(record)
            session.commit()
            session.refresh(record)
            return self._to_job(record)

    def _active_model(self) -> type[CAIIngestionJob] | type[CBackgroundJob]:
        return CAIIngestionJob if self._use_legacy_table() else CBackgroundJob

    def _use_legacy_table(self) -> bool:
        inspector = sa_inspect(mdb_engine)
        legacy_exists = inspector.has_table(CAIIngestionJob.__tablename__)
        if not legacy_exists:
            return False
        background_exists = inspector.has_table(CBackgroundJob.__tablename__)
        if not background_exists:
            return True

        # TODO(background-job-migration): remove this compatibility branch after the
        # migration has dropped caiingestionjob in all environments. Until then, keep
        # using legacy storage only while old rows still need to be migrated.
        legacy_count = self._count_rows(CAIIngestionJob.__tablename__)
        return legacy_count > 0

    def _count_rows(self, table_name: str) -> int:
        statement = f"SELECT COUNT(*) FROM {table_name}"
        with mdb_engine.connect() as connection:
            return int(connection.execute(text(statement)).scalar_one())

    def _get_record_for_update(
        self, *, session: Session, job_id: int
    ) -> CAIIngestionJob | CBackgroundJob:
        model = self._active_model()
        if model is CAIIngestionJob:
            record = session.exec(
                select(CAIIngestionJob).where(CAIIngestionJob.id == job_id)
            ).one_or_none()
        else:
            record = session.exec(
                select(CBackgroundJob).where(
                    CBackgroundJob.id == job_id,
                    CBackgroundJob.job_type == INGESTION_JOB_TYPE,
                )
            ).one_or_none()
        if record is None:
            raise HTTPException(status_code=404, detail="Ingestion job not found")
        return record

    def _to_job(self, record: CAIIngestionJob | CBackgroundJob) -> IngestionJob:
        if record.entity_id is None:
            raise HTTPException(
                status_code=500, detail="Ingestion job is missing entity_id"
            )
        warnings = self._get_record_warnings(record)
        return IngestionJob(
            id=record.id,
            entity_id=record.entity_id,
            entity_type=record.entity_type or "family",
            status=record.status,
            phase=record.phase,
            warnings=warnings,
            error_text=record.error_text,
            sources=self._get_record_sources(record),
            applied_at=record.applied_at,
            created_at=record.insdate,
            updated_at=record.upddate,
        )

    def _get_record_sources(
        self, record: CAIIngestionJob | CBackgroundJob
    ) -> list[IngestionSource]:
        if isinstance(record, CAIIngestionJob):
            return self._parse_sources(record.sources_json)
        state = self._coerce_json_object(record.state_json)
        return self._parse_sources(state.get("sources"))

    def _set_record_sources(
        self, record: CAIIngestionJob | CBackgroundJob, sources: list[IngestionSource]
    ) -> None:
        if isinstance(record, CAIIngestionJob):
            record.sources_json = self._dump_sources_text(sources)
            return
        state = self._coerce_json_object(record.state_json)
        record.state_json = {**state, "sources": self._dump_sources_payload(sources)}

    def _get_record_events(
        self, record: CAIIngestionJob | CBackgroundJob
    ) -> list[IngestionEvent]:
        if isinstance(record, CAIIngestionJob):
            return self._parse_events(record.events_json)
        return self._parse_events(record.events_json)

    def _set_record_events(
        self, record: CAIIngestionJob | CBackgroundJob, events: list[IngestionEvent]
    ) -> None:
        if isinstance(record, CAIIngestionJob):
            record.events_json = self._dump_events_text(events)
            return
        record.events_json = self._dump_events_payload(events)

    def _get_record_warnings(
        self, record: CAIIngestionJob | CBackgroundJob
    ) -> list[IngestionWarning]:
        if isinstance(record, CAIIngestionJob):
            return self._parse_warnings(record.warnings_json)
        return self._parse_warnings(record.warnings_json)

    def _set_record_warnings(
        self, record: CAIIngestionJob | CBackgroundJob, warnings: list[IngestionWarning]
    ) -> None:
        if isinstance(record, CAIIngestionJob):
            record.warnings_json = self._dump_warnings_text(warnings)
            return
        record.warnings_json = self._dump_warnings_payload(warnings)

    def _coerce_json_object(self, payload: Any) -> dict[str, Any]:
        if not payload:
            return {}
        if isinstance(payload, str):
            return json.loads(payload)
        if isinstance(payload, dict):
            return payload
        return {}

    def _parse_sources(self, payload: Any) -> list[IngestionSource]:
        if not payload:
            return []
        if isinstance(payload, str):
            payload = json.loads(payload)
        return [IngestionSource.model_validate(item) for item in payload]

    def _parse_events(self, payload: Any) -> list[IngestionEvent]:
        if not payload:
            return []
        if isinstance(payload, str):
            payload = json.loads(payload)
        return [IngestionEvent.model_validate(item) for item in payload]

    def _parse_warnings(self, payload: Any) -> list[IngestionWarning]:
        if not payload:
            return []
        if isinstance(payload, str):
            payload = json.loads(payload)
        return [IngestionWarning.model_validate(item) for item in payload]

    def _dump_sources_payload(
        self, sources: list[IngestionSource]
    ) -> list[dict[str, Any]]:
        return [source.model_dump(mode="json") for source in sources]

    def _dump_events_payload(
        self, events: list[IngestionEvent]
    ) -> list[dict[str, Any]]:
        return [event.model_dump(mode="json") for event in events]

    def _dump_warnings_payload(
        self, warnings: list[IngestionWarning]
    ) -> list[dict[str, Any]]:
        return [warning.model_dump(mode="json") for warning in warnings]

    def _dump_sources_text(self, sources: list[IngestionSource]) -> str:
        return json.dumps(self._dump_sources_payload(sources), ensure_ascii=False)

    def _dump_events_text(self, events: list[IngestionEvent]) -> str:
        return json.dumps(self._dump_events_payload(events), ensure_ascii=False)

    def _dump_warnings_text(self, warnings: list[IngestionWarning]) -> str:
        return json.dumps(self._dump_warnings_payload(warnings), ensure_ascii=False)

    def _trim_events(self, events: list[IngestionEvent]) -> list[IngestionEvent]:
        trimmed = list(events[-MAX_STORED_EVENTS:])
        while (
            len(trimmed) > 1
            and len(self._dump_events_text(trimmed)) > MAX_EVENTS_JSON_CHARS
        ):
            trimmed.pop(0)
        return trimmed
