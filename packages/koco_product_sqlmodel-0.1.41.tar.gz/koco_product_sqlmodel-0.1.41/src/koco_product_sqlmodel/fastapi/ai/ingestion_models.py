from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


class IngestionEvidence(BaseModel):
    source_id: int | None = None
    title: str | None = None
    excerpt: str
    locator: str | None = None


class IngestionWarning(BaseModel):
    code: str
    message: str


class IngestionFamilyPatch(BaseModel):
    family: str | None = None
    type: str | None = None
    description: str | None = None
    short_description: str | None = None
    evidence: list[IngestionEvidence] = Field(default_factory=list)


class IngestionArticle(BaseModel):
    article: str
    description: str | None = None
    short_description: str | None = None
    order_priority: int = 100
    evidence: list[IngestionEvidence] = Field(default_factory=list)


class IngestionApplication(BaseModel):
    application: str
    evidence: list[IngestionEvidence] = Field(default_factory=list)


class IngestionOption(BaseModel):
    type: str
    option: str
    category: str | None = None
    evidence: list[IngestionEvidence] = Field(default_factory=list)


class IngestionSpectableItem(BaseModel):
    pos: str | None = None
    name: str | None = None
    value: str | None = None
    min_value: str | None = None
    max_value: str | None = None
    unit: str | None = None


class IngestionSpectable(BaseModel):
    name: str
    type: Literal["singlecol", "multicol", "overview", "free"]
    has_unit: bool | None = None
    article_name: str | None = None
    items: list[IngestionSpectableItem] = Field(default_factory=list)
    evidence: list[IngestionEvidence] = Field(default_factory=list)


class IngestionUrl(BaseModel):
    type: str
    supplier_url: str | None = None
    KOCO_url: str | None = None
    description: str | None = None
    parent: Literal["family", "article"]
    article_name: str | None = None
    evidence: list[IngestionEvidence] = Field(default_factory=list)


class IngestionFigure(BaseModel):
    source_id: int | None = None
    source_figure_id: int | None = None
    type: str
    description: str | None = None
    parent: Literal["family", "article"]
    article_name: str | None = None
    preview_token: str | None = None
    filename: str | None = None
    mime_type: str | None = None
    locator: str | None = None
    context_excerpt: str | None = None
    evidence: list[IngestionEvidence] = Field(default_factory=list)


class IngestionResult(BaseModel):
    family_patch: IngestionFamilyPatch = Field(
        default_factory=IngestionFamilyPatch
    )
    articles: list[IngestionArticle] = Field(default_factory=list)
    applications: list[IngestionApplication] = Field(default_factory=list)
    options: list[IngestionOption] = Field(default_factory=list)
    family_spectables: list[IngestionSpectable] = Field(default_factory=list)
    article_spectables: list[IngestionSpectable] = Field(default_factory=list)
    urls: list[IngestionUrl] = Field(default_factory=list)
    figures: list[IngestionFigure] = Field(default_factory=list)
    warnings: list[IngestionWarning] = Field(default_factory=list)
    evidence: list[IngestionEvidence] = Field(default_factory=list)


class IngestionSource(BaseModel):
    id: int
    source_type: Literal["url", "file"]
    url: str | None = None
    filedata_id: int | None = None
    mime_type: str | None = None
    filename: str | None = None
    status: str = "pending"
    error_text: str | None = None


class RelatedSourceCandidate(BaseModel):
    url: str
    kind: Literal["document", "page", "image"]
    label: str | None = None
    context: str | None = None


class IngestionGatherPlan(BaseModel):
    selected_urls: list[str] = Field(default_factory=list)


class IngestionJob(BaseModel):
    id: int
    entity_id: int = Field(gt=0)
    entity_type: str = Field(default="family", max_length=64)
    status: str
    phase: str
    warnings: list[IngestionWarning] = Field(default_factory=list)
    error_text: str | None = None
    sources: list[IngestionSource] = Field(default_factory=list)
    applied_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class IngestionEvent(BaseModel):
    job_id: int
    sequence: int
    timestamp: datetime
    type: str
    message: str
    source_id: int | None = None
    meta: dict[str, Any] | None = None


class IngestionJobCreateRequest(BaseModel):
    entity_id: int = Field(gt=0)
    entity_type: str = Field(default="family", max_length=64)
    urls: list[str] = Field(default_factory=list)
    filedata_ids: list[int] = Field(default_factory=list)


class ExtractedTable(BaseModel):
    locator: str | None = None
    name: str | None = None
    headers: list[str] = Field(default_factory=list)
    rows: list[list[str | None]] = Field(default_factory=list)


class ExtractedFigure(BaseModel):
    figure_id: int
    locator: str | None = None
    page_number: int | None = None
    mime_type: str = "image/png"
    width: int | None = None
    height: int | None = None
    kind_hint: str | None = None
    caption: str | None = None
    context_text: str = ""
    image_data_url: str | None = None
    extraction_method: str | None = None


class ExtractedSourceContent(BaseModel):
    source_id: int
    title: str | None = None
    locator: str | None = None
    mime_type: str | None = None
    text: str = ""
    tables: list[ExtractedTable] = Field(default_factory=list)
    figures: list[ExtractedFigure] = Field(default_factory=list)
    related_candidates: list[RelatedSourceCandidate] = Field(default_factory=list)
    warnings: list[IngestionWarning] = Field(default_factory=list)


class IngestionSourceFinding(BaseModel):
    source_id: int
    title: str | None = None
    family_patch: IngestionFamilyPatch = Field(
        default_factory=IngestionFamilyPatch
    )
    articles: list[IngestionArticle] = Field(default_factory=list)
    applications: list[IngestionApplication] = Field(default_factory=list)
    options: list[IngestionOption] = Field(default_factory=list)
    family_spectables: list[IngestionSpectable] = Field(default_factory=list)
    article_spectables: list[IngestionSpectable] = Field(default_factory=list)
    urls: list[IngestionUrl] = Field(default_factory=list)
    figures: list[IngestionFigure] = Field(default_factory=list)
    warnings: list[IngestionWarning] = Field(default_factory=list)
    evidence: list[IngestionEvidence] = Field(default_factory=list)


class IngestionSourceFigureFinding(BaseModel):
    figures: list[IngestionFigure] = Field(default_factory=list)
    warnings: list[IngestionWarning] = Field(default_factory=list)
