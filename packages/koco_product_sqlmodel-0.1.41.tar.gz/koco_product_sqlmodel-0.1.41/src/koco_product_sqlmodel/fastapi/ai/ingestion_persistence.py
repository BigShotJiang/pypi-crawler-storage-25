from __future__ import annotations

from koco_product_sqlmodel.fastapi.ai.ingestion_persistence_assets import (
	IngestionPersistenceAssetMixin,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_persistence_common import (
	ChangeLogEntry,
	DOWNLOADABLE_URL_TYPES,
	ProgressCallback,
	_emit_progress,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_persistence_logging import (
	IngestionPersistenceLoggingMixin,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_persistence_records import (
	IngestionPersistenceRecordMixin,
)


class IngestionPersistenceService(
	IngestionPersistenceRecordMixin,
	IngestionPersistenceAssetMixin,
	IngestionPersistenceLoggingMixin,
):
	pass


__all__ = [
	"ChangeLogEntry",
	"DOWNLOADABLE_URL_TYPES",
	"IngestionPersistenceService",
	"ProgressCallback",
	"_emit_progress",
]
