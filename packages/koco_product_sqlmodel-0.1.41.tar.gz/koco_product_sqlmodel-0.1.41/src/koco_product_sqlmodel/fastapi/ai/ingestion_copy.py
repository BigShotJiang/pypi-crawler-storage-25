from __future__ import annotations

from collections.abc import Callable
from typing import Any

from koco_product_sqlmodel.fastapi.ai.context_builder import DescriptionContextBuilder
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
	IngestionResult,
	IngestionFigure,
	IngestionSpectable,
	IngestionWarning,
)
from koco_product_sqlmodel.fastapi.ai.service import (
	DESCRIPTION_STREAM_MAX_TOKENS,
	DescriptionGenerationService,
)


SHORT_DESCRIPTION_MAX_TOKENS = 600


ProgressCallback = Callable[[str, str, dict[str, object] | None], None]


def _emit_progress(
	progress_callback: ProgressCallback | None,
	event_type: str,
	message: str,
	meta: dict[str, object] | None = None,
) -> None:
	if progress_callback is None:
		return
	progress_callback(event_type, message, meta)


def generate_english_copy(
	*,
	llm_streamer,
	result: IngestionResult,
	family_name: str,
	progress_callback: ProgressCallback | None = None,
):
	description_service = DescriptionGenerationService(
		llm_streamer=llm_streamer,
		context_builder=DescriptionContextBuilder(),
	)
	warnings: list[IngestionWarning] = []
	total_articles = len(result.articles)

	family_context = description_service.context_builder.serialize_prompt_context(
		build_family_copy_context(result=result, family_name=family_name)
	)
	try:
		_emit_progress(
			progress_callback,
			"merge.copy.progress",
			"Generating family short description",
			{"entity_type": "family"},
		)
		result.family_patch.short_description = llm_streamer.generate_json_field(
			system_prompt=description_service.system_prompt,
			user_prompt=description_service._create_short_description_prompt(
				"family", family_context
			),
			expected_field="short_description",
			max_tokens=SHORT_DESCRIPTION_MAX_TOKENS,
		)
		result.family_patch.short_description = description_service._validate_field_limit(
			"short_description",
			result.family_patch.short_description,
		)
	except Exception as exc:
		warnings.append(
			IngestionWarning(
				code="generated_text_failed",
				message=f"Failed to generate family short description: {exc}",
			)
		)

	try:
		_emit_progress(
			progress_callback,
			"merge.copy.progress",
			"Generating family description",
			{"entity_type": "family"},
		)
		result.family_patch.description = generate_description_field(
			llm_streamer=llm_streamer,
			description_service=description_service,
			entity_type="family",
			context=family_context,
		)
	except Exception as exc:
		warnings.append(
			IngestionWarning(
				code="generated_text_failed",
				message=f"Failed to generate family description: {exc}",
			)
		)

	for index, article in enumerate(result.articles, start=1):
		article_context = description_service.context_builder.serialize_prompt_context(
			build_article_copy_context(
				result=result,
				family_name=result.family_patch.family or family_name,
				article_name=article.article,
			)
		)
		try:
			_emit_progress(
				progress_callback,
				"merge.copy.progress",
				f"Generating short description for article {index}/{total_articles}: {article.article}",
				{
					"entity_type": "article",
					"article_name": article.article,
					"index": index,
					"total": total_articles,
				},
			)
			article.short_description = llm_streamer.generate_json_field(
				system_prompt=description_service.system_prompt,
				user_prompt=description_service._create_short_description_prompt(
					"article", article_context
				),
				expected_field="short_description",
				max_tokens=SHORT_DESCRIPTION_MAX_TOKENS,
			)
			article.short_description = description_service._validate_field_limit(
				"short_description",
				article.short_description,
			)
		except Exception as exc:
			warnings.append(
				IngestionWarning(
					code="generated_text_failed",
					message=(
						f"Failed to generate short description for article "
						f"{article.article}: {exc}"
					),
				)
		)

		try:
			_emit_progress(
				progress_callback,
				"merge.copy.progress",
				f"Generating description for article {index}/{total_articles}: {article.article}",
				{
					"entity_type": "article",
					"article_name": article.article,
					"index": index,
					"total": total_articles,
				},
			)
			article.description = generate_description_field(
				llm_streamer=llm_streamer,
				description_service=description_service,
				entity_type="article",
				context=article_context,
			)
		except Exception as exc:
			warnings.append(
				IngestionWarning(
					code="generated_text_failed",
					message=f"Failed to generate description for article {article.article}: {exc}",
				)
			)

	return result, warnings


def generate_description_field(
	*,
	llm_streamer,
	description_service: DescriptionGenerationService,
	entity_type: str,
	context: str,
) -> str:
	parts: list[str] = []
	stream = llm_streamer.stream_text(
		system_prompt=description_service.system_prompt,
		user_prompt=description_service._create_description_prompt(entity_type, context),
		max_tokens=DESCRIPTION_STREAM_MAX_TOKENS,
	)
	while True:
		try:
			delta = next(stream)
		except StopIteration as stop:
			value = stop.value or "".join(parts)
			break
		parts.append(delta)
	return description_service._validate_field_limit("description", value)


def build_family_copy_context(*, result: IngestionResult, family_name: str) -> dict[str, Any]:
	return {
		"entity_type": "family",
		"family": {
			"family": result.family_patch.family or family_name,
			"type": result.family_patch.type,
		},
		"articles": [
			{
				"article": article.article,
				"order_priority": article.order_priority,
			}
			for article in result.articles
		],
		"applications": [application.application for application in result.applications],
		"options": [
			{
				"type": option.type,
				"category": option.category,
				"option": option.option,
			}
			for option in result.options
		],
		"family_spectables": [
			serialize_spectable_for_copy(table) for table in result.family_spectables
		],
		"article_spectables": {
			article.article: [
				serialize_spectable_for_copy(table)
				for table in result.article_spectables
				if table.article_name == article.article
			]
			for article in result.articles
		},
		"figures": [serialize_figure_for_copy(figure) for figure in result.figures],
	}


def build_article_copy_context(
	*, result: IngestionResult, family_name: str, article_name: str
) -> dict[str, Any]:
	article = next(item for item in result.articles if item.article == article_name)
	return {
		"entity_type": "article",
		"article": {
			"article": article.article,
			"order_priority": article.order_priority,
		},
		"family": {
			"family": family_name,
			"type": result.family_patch.type,
		},
		"applications": [application.application for application in result.applications],
		"options": [
			{
				"type": option.type,
				"category": option.category,
				"option": option.option,
			}
			for option in result.options
		],
		"family_spectables": [
			serialize_spectable_for_copy(table) for table in result.family_spectables
		],
		"article_spectables": [
			serialize_spectable_for_copy(table)
			for table in result.article_spectables
			if table.article_name == article_name
		],
		"figures": [
			serialize_figure_for_copy(figure)
			for figure in result.figures
			if figure.parent == "family" or figure.article_name == article_name
		],
	}


def serialize_spectable_for_copy(table: IngestionSpectable) -> dict[str, Any]:
	return {
		"name": table.name,
		"type": table.type,
		"has_unit": table.has_unit,
		"items": [
			{
				"pos": item.pos,
				"name": item.name,
				"value": item.value,
				"min_value": item.min_value,
				"max_value": item.max_value,
				"unit": item.unit,
			}
			for item in table.items
		],
	}


def serialize_figure_for_copy(figure: IngestionFigure) -> dict[str, Any]:
	return {
		"type": figure.type,
		"description": figure.description,
		"parent": figure.parent,
		"article_name": figure.article_name,
	}
