from __future__ import annotations

import datetime as dt
import json
import re
import unicodedata
from collections import defaultdict
from difflib import SequenceMatcher
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field
from sqlalchemy import inspect as sa_inspect
from sqlmodel import Session, SQLModel, select

from koco_product_sqlmodel.dbmodels.appmeta import CAppMeta
from koco_product_sqlmodel.dbmodels.backgroundjob import CBackgroundJob
from koco_product_sqlmodel.dbmodels.spectable import CSpecTable, CSpecTableItem
from koco_product_sqlmodel.fastapi.ai import (
    LLMConfigurationError,
    LLMStreamer,
    get_ai_settings,
)
from koco_product_sqlmodel.mdb_connect.init_db_con import mdb_engine

SPEC_NORMALIZER_JOB_TYPE = "spec_normalizer_scan"
SPEC_NORMALIZER_GROUPS_KEY = "spec_normalizer.groups"
SPEC_NORMALIZER_VARIANT_INDEX_KEY = "spec_normalizer.variant_index"
AI_GROUP_REVIEW_MAX_GROUPS = 8
AI_GROUP_REVIEW_MAX_VARIANTS = 45


class SpecNameContext(BaseModel):
    name: str
    count: int
    units: list[str] = Field(default_factory=list)
    sample_values: list[str] = Field(default_factory=list)
    parent_types: list[str] = Field(default_factory=list)
    table_names: list[str] = Field(default_factory=list)


class SpecNameGroup(BaseModel):
    id: str
    canonical_name: str
    variants: list[str]
    confidence: float = Field(ge=0, le=1)
    reason: str
    needs_review: bool = True


class SpecNormalizerScanRequest(BaseModel):
    use_ai: bool = True


class SpecNormalizerScanResult(BaseModel):
    source: str
    names: list[SpecNameContext]
    groups: list[SpecNameGroup]


class SpecNormalizerProgress(BaseModel):
    label: str = "Queued"
    current: int | None = None
    total: int | None = None
    percent: int | None = None
    message: str | None = None


class SpecNormalizerJob(BaseModel):
    id: int
    status: str
    phase: str
    progress: SpecNormalizerProgress = Field(default_factory=SpecNormalizerProgress)
    result: SpecNormalizerScanResult | None = None
    warnings: list[dict[str, Any]] = Field(default_factory=list)
    error_text: str | None = None
    applied_at: dt.datetime | None = None
    created_at: dt.datetime | None = None
    updated_at: dt.datetime | None = None


class SpecNormalizerApprovedState(BaseModel):
    groups: list[SpecNameGroup] = Field(default_factory=list)
    variant_index: dict[str, dict[str, Any]] = Field(default_factory=dict)


class SpecNormalizerGroupsSaveRequest(BaseModel):
    groups: list[SpecNameGroup]


class SpecNormalizerApplyRequest(BaseModel):
    canonical_name: str = Field(min_length=1, max_length=256)
    variants: list[str] = Field(min_length=1)
    dry_run: bool = True


class SpecNormalizerApplyResult(BaseModel):
    canonical_name: str
    variants: list[str]
    dry_run: bool
    affected_count: int
    examples: list[dict[str, Any]]
    updated_ids: list[int] = Field(default_factory=list)


class _AISpecNormalizerGroups(BaseModel):
    groups: list[SpecNameGroup]


class SpecNormalizerService:
    def __init__(self) -> None:
        self._ensure_tables()

    def create_scan(
        self, payload: SpecNormalizerScanRequest, user_id: int
    ) -> SpecNormalizerJob:
        job = CBackgroundJob(
            job_type=SPEC_NORMALIZER_JOB_TYPE,
            status="pending",
            phase="queued",
            payload_json=payload.model_dump(mode="json"),
            state_json={
                "progress": _progress(
                    label="Queued",
                    message="Waiting for the scan worker to start.",
                )
            },
            events_json=[],
            warnings_json=[],
            user_id=user_id,
        )
        with Session(mdb_engine) as session:
            session.add(job)
            session.commit()
            session.refresh(job)
            return self._to_job(job)

    def run_scan_job(self, job_id: int) -> None:
        job = self._get_scan_record(job_id)
        if job is None:
            return
        payload = SpecNormalizerScanRequest.model_validate(job.payload_json)
        self._update_job(
            job_id=job_id,
            status="running",
            phase="collecting_names",
            progress=_progress(
                label="Collecting names",
                message="Reading specification item names from the database.",
            ),
            started_at=dt.datetime.now(),
        )
        try:
            result, warnings = self._run_scan(payload=payload, job_id=job_id)
            self._update_job(
                job_id=job_id,
                status="completed",
                phase="ready_for_review",
                progress=_progress(
                    label="Ready for review",
                    current=len(result.groups),
                    total=len(result.groups),
                    message=f"Built {len(result.groups)} review groups from {len(result.names)} names.",
                ),
                result=result,
                warnings=warnings,
                error_text=None,
                finished_at=dt.datetime.now(),
            )
        except Exception as exc:
            self._update_job(
                job_id=job_id,
                status="failed",
                phase="failed",
                progress=_progress(
                    label="Failed",
                    message=str(exc),
                ),
                error_text=str(exc),
                finished_at=dt.datetime.now(),
            )

    def get_job(self, job_id: int) -> SpecNormalizerJob | None:
        job = self._get_scan_record(job_id)
        if job is None:
            return None
        return self._to_job(job)

    def _get_scan_record(self, job_id: int) -> CBackgroundJob | None:
        with Session(mdb_engine) as session:
            return session.exec(
                select(CBackgroundJob).where(
                    CBackgroundJob.id == job_id,
                    CBackgroundJob.job_type == SPEC_NORMALIZER_JOB_TYPE,
                )
            ).one_or_none()

    def get_approved_state(self) -> SpecNormalizerApprovedState:
        groups_payload = self._get_meta_value(
            SPEC_NORMALIZER_GROUPS_KEY, {"groups": []}
        )
        index_payload = self._get_meta_value(SPEC_NORMALIZER_VARIANT_INDEX_KEY, {})
        return SpecNormalizerApprovedState(
            groups=[
                SpecNameGroup.model_validate(group)
                for group in groups_payload.get("groups", [])
            ],
            variant_index=index_payload if isinstance(index_payload, dict) else {},
        )

    def save_approved_groups(
        self, groups: list[SpecNameGroup], user_id: int
    ) -> SpecNormalizerApprovedState:
        self._save_groups(groups=groups, user_id=user_id)
        return self.get_approved_state()

    def apply_group(
        self, payload: SpecNormalizerApplyRequest, user_id: int
    ) -> SpecNormalizerApplyResult:
        canonical_name = payload.canonical_name.strip()
        variants = _dedupe_preserve_order(
            [name.strip() for name in payload.variants if name.strip()]
        )
        names_to_replace = [name for name in variants if name != canonical_name]

        with Session(mdb_engine) as session:
            statement = (
                select(CSpecTableItem)
                .join(CSpecTable, CSpecTable.id == CSpecTableItem.spec_table_id)
                .where(CSpecTableItem.name.in_(names_to_replace))
                .where(CSpecTable.type == "overview")
                .limit(50 if payload.dry_run else 100000)
            )
            sample_items = session.exec(statement).all()

            count_statement = (
                select(CSpecTableItem)
                .join(CSpecTable, CSpecTable.id == CSpecTableItem.spec_table_id)
                .where(CSpecTableItem.name.in_(names_to_replace))
                .where(CSpecTable.type == "overview")
            )
            all_items = session.exec(count_statement).all()
            affected_count = len(all_items)

            examples = [
                {
                    "id": item.id,
                    "from_name": item.name,
                    "value": item.value,
                    "unit": item.unit,
                    "spec_table_id": item.spec_table_id,
                }
                for item in sample_items[:20]
            ]

            updated_ids: list[int] = []
            if not payload.dry_run and names_to_replace:
                for item in all_items:
                    item.name = canonical_name
                    item.user_id = user_id
                    session.add(item)
                    if item.id is not None:
                        updated_ids.append(item.id)
                session.commit()
                self._remember_applied_group(
                    canonical_name=canonical_name,
                    variants=variants,
                    user_id=user_id,
                )

        return SpecNormalizerApplyResult(
            canonical_name=canonical_name,
            variants=variants,
            dry_run=payload.dry_run,
            affected_count=affected_count,
            examples=examples,
            updated_ids=updated_ids,
        )

    def check_name(self, name: str) -> dict[str, Any]:
        state = self.get_approved_state()
        return state.variant_index.get(_normalize_name(name), {})

    def _run_scan(
        self, payload: SpecNormalizerScanRequest, job_id: int | None = None
    ) -> tuple[SpecNormalizerScanResult, list[dict[str, Any]]]:
        names = self._collect_spec_names(job_id=job_id)
        warnings: list[dict[str, Any]] = []
        source = "fallback"
        groups: list[SpecNameGroup]

        if payload.use_ai:
            try:
                self._update_job(
                    job_id=job_id,
                    phase="ai_grouping",
                    progress=_progress(
                        label="AI grouping",
                        current=0,
                        total=max(len(names), 1),
                        message=(
                            f"Pre-grouped {len(names)} distinct names; asking AI to review motor-specific groups."
                        ),
                    ),
                )
                groups = self._group_with_ai(names, job_id=job_id)
                source = "ai"
            except (LLMConfigurationError, ValueError) as exc:
                warnings.append(
                    {
                        "code": "ai_grouping_failed",
                        "message": f"AI grouping failed; used local fallback. {exc}",
                    }
                )
                self._update_job(
                    job_id=job_id,
                    phase="fallback_grouping",
                    progress=_progress(
                        label="Fallback grouping",
                        current=0,
                        total=len(names),
                        message="AI grouping failed; using local similarity rules.",
                    ),
                )
                groups = self._group_locally(names)
        else:
            self._update_job(
                job_id=job_id,
                phase="local_grouping",
                progress=_progress(
                    label="Local grouping",
                    current=0,
                    total=len(names),
                    message="Grouping names with local alias and spelling rules.",
                ),
            )
            groups = self._group_locally(names)

        self._update_job(
            job_id=job_id,
            phase="building_result",
            progress=_progress(
                label="Building result",
                current=len(groups),
                total=max(len(groups), 1),
                message=f"Prepared {len(groups)} groups for review.",
            ),
        )

        return (
            SpecNormalizerScanResult(source=source, names=names, groups=groups),
            warnings,
        )

    def _collect_spec_names(self, job_id: int | None = None) -> list[SpecNameContext]:
        grouped: dict[str, dict[str, Any]] = defaultdict(
            lambda: {
                "count": 0,
                "units": set(),
                "sample_values": [],
                "parent_types": set(),
                "table_names": set(),
            }
        )
        statement = (
            select(
                CSpecTableItem.name,
                CSpecTableItem.value,
                CSpecTableItem.min_value,
                CSpecTableItem.max_value,
                CSpecTableItem.unit,
                CSpecTable.parent,
                CSpecTable.name,
            )
            .join(CSpecTable, CSpecTable.id == CSpecTableItem.spec_table_id)
            .where(CSpecTableItem.name.is_not(None))
            .where(CSpecTable.type == "overview")
        )
        with Session(mdb_engine) as session:
            rows = session.exec(statement).all()

        total_rows = len(rows)
        self._update_job(
            job_id=job_id,
            phase="collecting_names",
            progress=_progress(
                label="Collecting names",
                current=0,
                total=total_rows,
                message=f"Scanning {total_rows} spec table item rows.",
            ),
        )

        for index, row in enumerate(rows, start=1):
            raw_name = (row[0] or "").strip()
            if not raw_name:
                continue
            entry = grouped[raw_name]
            entry["count"] += 1
            for set_key, value in (
                ("units", row[4]),
                ("parent_types", row[5]),
                ("table_names", row[6]),
            ):
                clean_value = (value or "").strip()
                if clean_value:
                    entry[set_key].add(clean_value)
            for value in (row[1], row[2], row[3]):
                clean_value = (value or "").strip()
                if clean_value and clean_value not in entry["sample_values"]:
                    entry["sample_values"].append(clean_value)
                if len(entry["sample_values"]) >= 5:
                    break
            if index == total_rows or index % 250 == 0:
                self._update_job(
                    job_id=job_id,
                    phase="collecting_names",
                    progress=_progress(
                        label="Collecting names",
                        current=index,
                        total=total_rows,
                        message=f"Found {len(grouped)} distinct names so far.",
                    ),
                )

        contexts = [
            SpecNameContext(
                name=name,
                count=data["count"],
                units=sorted(data["units"])[:8],
                sample_values=data["sample_values"][:5],
                parent_types=sorted(data["parent_types"])[:5],
                table_names=sorted(data["table_names"])[:8],
            )
            for name, data in grouped.items()
        ]
        contexts.sort(key=lambda item: (-item.count, item.name.lower()))
        self._update_job(
            job_id=job_id,
            phase="preparing_context",
            progress=_progress(
                label="Preparing context",
                current=len(contexts),
                total=max(len(contexts), 1),
                message=f"Prepared context for all {len(contexts)} distinct names.",
            ),
        )
        return contexts

    def _group_with_ai(
        self, names: list[SpecNameContext], job_id: int | None = None
    ) -> list[SpecNameGroup]:
        candidate_groups = self._group_by_motor_semantics(names)
        review_groups, local_groups = _split_ai_review_groups(candidate_groups)
        chunks = _chunk_groups_for_ai(review_groups)
        groups: list[SpecNameGroup] = [
            group.model_copy(
                update={
                    "reason": (
                        f"{group.reason} Kept local because this candidate group has "
                        f"{len(group.variants)} variants, which is too large for a "
                        "single reliable AI structured-output review."
                    )
                }
            )
            for group in local_groups
        ]
        if not chunks:
            self._update_job(
                job_id=job_id,
                phase="ai_grouping",
                progress=_progress(
                    label="AI grouping",
                    current=0,
                    total=0,
                    message=(
                        "No compact candidate groups needed AI review; large "
                        "semantic groups were kept local."
                    ),
                ),
            )
            return groups

        streamer = LLMStreamer(get_ai_settings())
        for index, chunk in enumerate(chunks, start=1):
            self._update_job(
                job_id=job_id,
                phase="ai_grouping",
                progress=_progress(
                    label="AI grouping",
                    current=index,
                    total=len(chunks),
                    message=(
                        f"Reviewing candidate group batch {index} of {len(chunks)}. "
                        f"{len(local_groups)} large groups are kept local."
                    ),
                ),
            )
            response = streamer.generate_structured(
                system_prompt=self._motor_grouping_system_prompt(),
                user_prompt=(
                    "Review these pre-grouped electronic motor specification names. "
                    "Return all variants exactly once. You may split a candidate group, "
                    "but do not merge across different candidate groups in this batch.\n\n"
                    + json.dumps(
                        self._build_ai_candidate_payload(chunk, names),
                        ensure_ascii=False,
                    )
                ),
                response_model=_AISpecNormalizerGroups,
                schema_name="spec_normalizer_groups",
                max_tokens=12000,
            )
            groups.extend(response.groups)
        seen = {variant for group in groups for variant in group.variants}
        missing = [name.name for name in names if name.name not in seen]
        groups.extend(self._singleton_groups(missing))
        return groups

    def _group_locally(self, names: list[SpecNameContext]) -> list[SpecNameGroup]:
        return self._group_by_motor_semantics(names)

    def _group_by_motor_semantics(
        self, names: list[SpecNameContext]
    ) -> list[SpecNameGroup]:
        keyed_contexts: dict[str, list[SpecNameContext]] = defaultdict(list)
        for context in names:
            signature = _motor_spec_signature(context)
            keyed_contexts[signature["key"]].append(context)

        groups: list[SpecNameGroup] = []
        for contexts in keyed_contexts.values():
            signature = _motor_spec_signature(contexts[0])
            variants = sorted([context.name for context in contexts], key=str.lower)
            if signature["quantity"] == "other":
                groups.extend(
                    self._build_group_from_variants(group_variants, signature)
                    for group_variants in self._split_fuzzy_other_variants(variants)
                )
                continue
            groups.append(self._build_group_from_variants(variants, signature))

        groups.sort(
            key=lambda group: (-len(group.variants), group.canonical_name.lower())
        )
        return groups

    def _split_fuzzy_other_variants(self, variants: list[str]) -> list[list[str]]:
        groups: list[list[str]] = []
        for variant in variants:
            normalized = _normalize_name(variant)
            target_group = None
            for group in groups:
                if (
                    SequenceMatcher(None, normalized, _normalize_name(group[0])).ratio()
                    >= 0.9
                ):
                    target_group = group
                    break
            if target_group is None:
                groups.append([variant])
            else:
                target_group.append(variant)
        return groups

    def _build_group_from_variants(
        self, variants: list[str], signature: dict[str, str]
    ) -> SpecNameGroup:
        return SpecNameGroup(
            id=_group_id(),
            canonical_name=_canonical_motor_spec_name(signature, variants),
            variants=variants,
            confidence=0.78 if len(variants) > 1 else 0.42,
            reason=_motor_group_reason(signature),
            needs_review=True,
        )

    def _build_ai_candidate_payload(
        self, groups: list[SpecNameGroup], names: list[SpecNameContext]
    ) -> list[dict[str, Any]]:
        context_by_name = {context.name: context for context in names}
        payload: list[dict[str, Any]] = []
        for group in groups:
            payload.append(
                {
                    "candidate_group_id": group.id,
                    "suggested_canonical_name": group.canonical_name,
                    "variants": group.variants,
                    "parser_reason": group.reason,
                    "context": [
                        _compact_ai_context(context_by_name[variant])
                        for variant in group.variants
                        if variant in context_by_name
                    ],
                }
            )
        return payload

    def _motor_grouping_system_prompt(self) -> str:
        return (
            "You normalize specification names for electronic motors, gear motors, "
            "brushless DC motors, brushed DC motors, stepper motors, motor drivers, "
            "and integrated motor/controller products.\n\n"
            "Core rule: group names only when they refer to the same measurable "
            "property at the same operating point. Preserve distinctions that would "
            "change the value or engineering meaning.\n\n"
            "For motor speed, these are different operating points and MUST NOT be "
            "merged: no-load speed, load speed, rated/nominal speed, maximum speed, "
            "maximum continuous speed, peak speed, input speed, output speed, and "
            "speed/torque gradient. No-load speed means unloaded operation at nominal "
            "or rated voltage. Rated/nominal speed means speed at rated or nominal "
            "load/torque/power. Maximum speed is a mechanical/thermal limit. "
            "Load speed is speed under load and is not no-load speed.\n\n"
            "For torque/current/power, keep stall, starting, rated/nominal, peak, "
            "maximum, continuous, and no-load variants separate unless the words are "
            "only spelling/case/punctuation differences.\n\n"
            "Keep voltage/frequency/temperature conditions separate for performance "
            "specs when they are embedded in the name, such as Maximum speed @24Vdc, "
            "Maximum speed @48Vdc, 230VAC, 400VAC 3phase, or ambient temperature "
            "ranges. For the voltage specification itself, group spelling variants "
            "such as Voltage, Rated voltage, Nominal voltage, and Supply voltage.\n\n"
            "Do not group dimensions or mechanical attributes such as motor length, "
            "shaft length, weight, pole pairs, phases, radial load, or axial load "
            "with speed/torque/electrical performance specs.\n\n"
            "Prefer canonical names used in motor datasheets: No-load speed, "
            "Nominal speed, Rated speed, Maximum speed, Maximum continuous speed, "
            "Stall torque, Nominal torque, No-load current, Rated voltage, "
            "Terminal resistance, Torque constant, Speed constant. Return short "
            "reasons and mark uncertain groups with needs_review=true."
        )

    def _singleton_groups(self, names: list[str]) -> list[SpecNameGroup]:
        return [
            SpecNameGroup(
                id=_group_id(),
                canonical_name=name,
                variants=[name],
                confidence=0,
                reason="AI response omitted this name; added as a review item.",
                needs_review=True,
            )
            for name in names
        ]

    def _remember_applied_group(
        self, canonical_name: str, variants: list[str], user_id: int
    ) -> None:
        state = self.get_approved_state()
        next_groups = [
            group
            for group in state.groups
            if _normalize_name(group.canonical_name) != _normalize_name(canonical_name)
        ]
        next_groups.append(
            SpecNameGroup(
                id=_group_id(),
                canonical_name=canonical_name,
                variants=variants,
                confidence=1,
                reason="Approved and applied by a user.",
                needs_review=False,
            )
        )
        self._save_groups(groups=next_groups, user_id=user_id)

    def _save_groups(self, groups: list[SpecNameGroup], user_id: int) -> None:
        variant_index: dict[str, dict[str, Any]] = {}
        for group in groups:
            for variant in group.variants:
                if variant != group.canonical_name:
                    variant_index[_normalize_name(variant)] = {
                        "canonical_name": group.canonical_name,
                        "variant": variant,
                        "group_id": group.id,
                    }
        self._upsert_meta(
            key=SPEC_NORMALIZER_GROUPS_KEY,
            value={"groups": [group.model_dump(mode="json") for group in groups]},
            user_id=user_id,
        )
        self._upsert_meta(
            key=SPEC_NORMALIZER_VARIANT_INDEX_KEY,
            value=variant_index,
            user_id=user_id,
        )

    def _get_meta_value(self, key: str, fallback: Any) -> Any:
        with Session(mdb_engine) as session:
            meta = session.exec(
                select(CAppMeta).where(CAppMeta.key == key)
            ).one_or_none()
            if meta is None or meta.value_json is None:
                return fallback
            return meta.value_json

    def _upsert_meta(self, key: str, value: Any, user_id: int) -> None:
        with Session(mdb_engine) as session:
            meta = session.exec(
                select(CAppMeta).where(CAppMeta.key == key)
            ).one_or_none()
            if meta is None:
                meta = CAppMeta(key=key, value_json=value, user_id=user_id)
            else:
                meta.value_json = value
                meta.user_id = user_id
            session.add(meta)
            session.commit()

    def _update_job(
        self,
        *,
        job_id: int | None,
        status: str | None = None,
        phase: str | None = None,
        progress: dict[str, Any] | None = None,
        result: SpecNormalizerScanResult | None = None,
        warnings: list[dict[str, Any]] | None = None,
        error_text: str | None = None,
        started_at: dt.datetime | None = None,
        finished_at: dt.datetime | None = None,
    ) -> None:
        if job_id is None:
            return
        with Session(mdb_engine) as session:
            job = session.exec(
                select(CBackgroundJob).where(
                    CBackgroundJob.id == job_id,
                    CBackgroundJob.job_type == SPEC_NORMALIZER_JOB_TYPE,
                )
            ).one_or_none()
            if job is None:
                return
            if status is not None:
                job.status = status
            if phase is not None:
                job.phase = phase
            if progress is not None:
                state = dict(job.state_json or {})
                state["progress"] = progress
                job.state_json = state
            if result is not None:
                job.result_json = result.model_dump(mode="json")
            if warnings is not None:
                job.warnings_json = warnings
            if error_text is not None or status == "completed":
                job.error_text = error_text
            if started_at is not None:
                job.started_at = started_at
            if finished_at is not None:
                job.finished_at = finished_at
            session.add(job)
            session.commit()

    def _to_job(self, job: CBackgroundJob) -> SpecNormalizerJob:
        result = None
        if isinstance(job.result_json, dict):
            result = SpecNormalizerScanResult.model_validate(job.result_json)
        progress_payload = (job.state_json or {}).get("progress", {})
        return SpecNormalizerJob(
            id=job.id,
            status=job.status,
            phase=job.phase,
            progress=SpecNormalizerProgress.model_validate(progress_payload),
            result=result,
            warnings=job.warnings_json or [],
            error_text=job.error_text,
            applied_at=job.applied_at,
            created_at=job.insdate,
            updated_at=job.upddate,
        )

    def _ensure_tables(self) -> None:
        if mdb_engine.dialect.name == "sqlite":
            return
        inspector = sa_inspect(mdb_engine)
        missing_tables = [
            table
            for table in (CBackgroundJob.__table__, CAppMeta.__table__)
            if not inspector.has_table(table.name)
        ]
        if missing_tables:
            SQLModel.metadata.create_all(mdb_engine, tables=missing_tables)


def _normalize_name(name: str) -> str:
    folded = unicodedata.normalize("NFKD", name.strip().lower())
    ascii_name = folded.encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]+", "", ascii_name)


def _contains_any(value: str, tokens: tuple[str, ...]) -> bool:
    return any(token in value for token in tokens)


def _chunk_groups_for_ai(groups: list[SpecNameGroup]) -> list[list[SpecNameGroup]]:
    chunks: list[list[SpecNameGroup]] = []
    current_chunk: list[SpecNameGroup] = []
    current_variant_count = 0
    for group in groups:
        group_variant_count = len(group.variants)
        if current_chunk and (
            len(current_chunk) >= AI_GROUP_REVIEW_MAX_GROUPS
            or current_variant_count + group_variant_count
            > AI_GROUP_REVIEW_MAX_VARIANTS
        ):
            chunks.append(current_chunk)
            current_chunk = []
            current_variant_count = 0
        current_chunk.append(group)
        current_variant_count += group_variant_count
    if current_chunk:
        chunks.append(current_chunk)
    return chunks


def _split_ai_review_groups(
    groups: list[SpecNameGroup],
) -> tuple[list[SpecNameGroup], list[SpecNameGroup]]:
    review_groups: list[SpecNameGroup] = []
    local_groups: list[SpecNameGroup] = []
    for group in groups:
        if len(group.variants) > AI_GROUP_REVIEW_MAX_VARIANTS:
            local_groups.append(group)
        else:
            review_groups.append(group)
    return review_groups, local_groups


def _compact_ai_context(context: SpecNameContext) -> dict[str, Any]:
    return {
        "name": context.name,
        "count": context.count,
        "units": context.units[:4],
        "sample_values": context.sample_values[:2],
        "table_names": context.table_names[:3],
    }


def _motor_spec_signature(context: SpecNameContext) -> dict[str, str]:
    name = context.name.strip()
    lower_name = name.lower()
    normalized = _normalize_name(name)
    unit_text = " ".join(context.units).lower()

    quantity = _motor_spec_quantity(normalized, lower_name, unit_text)
    condition = _condition_signature(lower_name, quantity)
    operating_point = _operating_point_signature(normalized, lower_name, quantity)
    if quantity == "voltage":
        operating_point = "rated_nominal"
    role = _role_signature(normalized, lower_name)

    key_parts = [quantity, operating_point, role, condition]
    if quantity == "other":
        key_parts = [quantity, _normalize_name(name)]

    return {
        "key": "|".join(part for part in key_parts if part),
        "quantity": quantity,
        "operating_point": operating_point,
        "role": role,
        "condition": condition,
        "original": name,
    }


def _motor_spec_quantity(normalized: str, lower_name: str, unit_text: str) -> str:
    compact_unit = re.sub(r"\s+", "", unit_text)
    if _contains_any(
        normalized,
        (
            "length",
            "diameter",
            "width",
            "height",
            "shaftdiameter",
            "shaftlength",
            "motordiameter",
            "motorlength",
            "abmessung",
            "durchmesser",
            "lange",
            "wellenlange",
        ),
    ):
        return "dimension"
    if "weight" in normalized or unit_text in {"g", "kg"}:
        return "weight"
    if "polepair" in normalized or "numberofpole" in normalized:
        return "pole_pairs"
    if "phase" in normalized and not _has_voltage_condition(lower_name):
        return "phases"
    if _contains_any(
        normalized,
        (
            "speedtorquegradient",
            "speedtorqueslope",
            "drehzahlmomentgradient",
            "drehzahldrehmomentgradient",
        ),
    ):
        return "speed_torque_gradient"
    if _contains_any(
        normalized,
        (
            "voltageconstant",
            "generatorconstant",
            "backemf",
            "backemfconstant",
            "spannungskonstante",
            "generatorkonstante",
            "gegenemk",
        ),
    ):
        return "voltage_constant"
    if (
        _contains_any(normalized, ("speedconstant", "drehzahlkonstante"))
        or normalized in {"kn", "kv"}
        or "rpm/v" in compact_unit
        or "rpmperv" in normalized
    ):
        return "speed_constant"
    if "v/rpm" in compact_unit or "vperrpm" in normalized:
        return "voltage_constant"
    if _contains_any(
        normalized, ("torqueconstant", "drehmomentkonstante")
    ) or normalized in {"km", "kt"}:
        return "torque_constant"
    if _contains_any(
        normalized,
        (
            "speed",
            "rpm",
            "drehzahl",
            "rmin",
            "rotationalspeed",
        ),
    ) or compact_unit in {"rpm", "r/min", "min-1"}:
        return "speed"
    if "torque" in normalized or "drehmoment" in normalized or "mnm" in unit_text:
        return "torque"
    if "current" in normalized or "strom" in normalized or unit_text in {"a", "ma"}:
        return "current"
    if (
        "voltage" in normalized
        or "spannung" in normalized
        or _has_voltage_condition(lower_name)
    ):
        return "voltage"
    if "power" in normalized or "leistung" in normalized or unit_text == "w":
        return "power"
    if "efficiency" in normalized or "wirkungsgrad" in normalized:
        return "efficiency"
    if "resistance" in normalized or "terminalresistance" in normalized:
        return "resistance"
    if "inductance" in normalized:
        return "inductance"
    if "temperature" in normalized or "temperatur" in normalized:
        return "temperature"
    if "inertia" in normalized:
        return "inertia"
    if "ratio" in normalized or "reduction" in normalized:
        return "gear_ratio"
    if "radialload" in normalized:
        return "radial_load"
    if "axialload" in normalized:
        return "axial_load"
    return "other"


def _operating_point_signature(normalized: str, lower_name: str, quantity: str) -> str:
    if _contains_any(normalized, ("noload", "no-load", "leerlauf")):
        return "no_load"
    if (
        _contains_any(normalized, ("stall", "blockier", "anlauf"))
        or "starting" in normalized
        or "startcurrent" in normalized
    ):
        return "stall_or_starting"
    if "peak" in normalized:
        return "peak"
    has_max = any(
        token in normalized
        for token in ("maximum", "max", "nmax", "imax", "mmax", "maximal")
    )
    has_continuous = "continuous" in normalized or "continuos" in normalized
    if has_max and has_continuous:
        return "maximum_continuous"
    if has_max:
        return "maximum"
    if _contains_any(normalized, ("rated", "nominal", "nenn", "bemessung")):
        return "rated_nominal"
    if "load" in normalized and quantity == "speed":
        return "load"
    if has_continuous:
        return "continuous"
    if "working" in normalized and quantity in {"speed", "torque", "current", "power"}:
        return "working"
    return "generic"


def _role_signature(normalized: str, lower_name: str) -> str:
    if "input" in normalized:
        return "input"
    if "output" in normalized:
        return "output"
    if "transfer" in normalized:
        return "transfer"
    if "motor" in normalized:
        return "motor"
    if "shaft" in normalized:
        return "shaft"
    return ""


def _condition_signature(lower_name: str, quantity: str) -> str:
    if quantity == "voltage":
        return ""
    conditions: list[str] = []
    for match in re.finditer(
        r"@?\s*(\d+(?:[.,]\d+)?)\s*(v\s*(?:dc|ac)?|vdc|vac)\b",
        lower_name,
    ):
        value = match.group(1).replace(",", ".")
        unit = re.sub(r"\s+", "", match.group(2).upper())
        if unit == "V":
            unit = "V"
        conditions.append(f"{value}{unit}")
    phase_match = re.search(r"\b([13])\s*phase\b", lower_name)
    if phase_match:
        conditions.append(f"{phase_match.group(1)}phase")
    temp_match = re.search(r"ambient temperature[^,)]+(?:\)|$)", lower_name)
    if temp_match:
        conditions.append(re.sub(r"\s+", " ", temp_match.group(0)).strip())
    return "_".join(conditions)


def _has_voltage_condition(lower_name: str) -> bool:
    return bool(
        re.search(r"\d+(?:[.,]\d+)?\s*(?:vdc|vac|v\s*dc|v\s*ac|v)\b", lower_name)
    )


def _canonical_motor_spec_name(signature: dict[str, str], variants: list[str]) -> str:
    quantity = signature["quantity"]
    operating_point = signature["operating_point"]
    role = signature["role"]
    condition = signature["condition"]

    names = {
        "speed": {
            "no_load": "No-load speed",
            "load": "Load speed",
            "rated_nominal": "Nominal speed",
            "maximum": "Maximum speed",
            "maximum_continuous": "Maximum continuous speed",
            "peak": "Peak speed",
            "continuous": "Continuous speed",
            "working": "Working speed",
            "generic": "Speed",
        },
        "torque": {
            "stall_or_starting": "Stall torque",
            "rated_nominal": "Nominal torque",
            "maximum": "Maximum torque",
            "maximum_continuous": "Maximum continuous torque",
            "peak": "Peak torque",
            "continuous": "Continuous torque",
            "generic": "Torque",
        },
        "current": {
            "no_load": "No-load current",
            "stall_or_starting": "Starting current",
            "rated_nominal": "Nominal current",
            "maximum": "Maximum current",
            "maximum_continuous": "Maximum continuous current",
            "peak": "Peak current",
            "continuous": "Continuous current",
            "generic": "Current",
        },
        "power": {
            "rated_nominal": "Nominal power",
            "maximum": "Maximum power",
            "peak": "Peak power",
            "continuous": "Continuous power",
            "generic": "Power",
        },
    }
    base_name = names.get(quantity, {}).get(operating_point)
    if base_name is None:
        base_name = {
            "voltage": (
                "Rated voltage" if operating_point == "rated_nominal" else "Voltage"
            ),
            "speed_torque_gradient": "Speed/torque gradient",
            "speed_constant": "Speed constant",
            "torque_constant": "Torque constant",
            "voltage_constant": "Voltage constant",
            "efficiency": "Efficiency",
            "resistance": "Terminal resistance",
            "inductance": "Terminal inductance",
            "temperature": "Temperature",
            "dimension": _pick_existing_variant(variants),
            "weight": "Weight",
            "pole_pairs": "Number of pole pairs",
            "phases": "Number of phases",
            "inertia": "Rotor inertia",
            "gear_ratio": "Gear ratio",
            "radial_load": "Radial load",
            "axial_load": "Axial load",
            "other": _pick_existing_variant(variants),
        }.get(quantity, _pick_existing_variant(variants))
    if role in {"input", "output"} and quantity == "speed":
        base_name = f"{role.title()} speed"
    if role == "transfer" and quantity == "speed":
        base_name = f"{base_name} transfer"
    if condition:
        return f"{base_name} @ {condition}"
    return base_name


def _pick_existing_variant(variants: list[str]) -> str:
    return max(variants, key=lambda value: (len(value), value))


def _motor_group_reason(signature: dict[str, str]) -> str:
    quantity = signature["quantity"].replace("_", " ")
    operating_point = signature["operating_point"].replace("_", " ")
    if signature["quantity"] == "other":
        return "Locally grouped by close spelling only."
    return (
        "Matched by motor-spec quantity, operating point, role, and embedded "
        f"conditions ({quantity}, {operating_point})."
    )


def _progress(
    *,
    label: str,
    current: int | None = None,
    total: int | None = None,
    message: str | None = None,
) -> dict[str, Any]:
    percent = None
    if current is not None and total:
        percent = max(0, min(100, round((current / total) * 100)))
    return {
        "label": label,
        "current": current,
        "total": total,
        "percent": percent,
        "message": message,
    }


def _group_id() -> str:
    return f"specgrp_{uuid4().hex[:12]}"


def _dedupe_preserve_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result
