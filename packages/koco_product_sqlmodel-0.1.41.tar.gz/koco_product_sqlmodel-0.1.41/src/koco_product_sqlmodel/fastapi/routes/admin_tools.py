from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request

import koco_product_sqlmodel.fastapi.routes.security as sec
from koco_product_sqlmodel.fastapi.spec_normalizer import (
    SpecNormalizerApplyRequest,
    SpecNormalizerApplyResult,
    SpecNormalizerApprovedState,
    SpecNormalizerGroupsSaveRequest,
    SpecNormalizerJob,
    SpecNormalizerScanRequest,
    SpecNormalizerService,
)


router = APIRouter(
    dependencies=[Depends(sec.get_current_active_user)],
    tags=["Endpoints to ADMIN TOOLS"],
)


def get_spec_normalizer_service() -> SpecNormalizerService:
    return SpecNormalizerService()


@router.post(
    "/spec-normalizer/scans",
    response_model=SpecNormalizerJob,
    dependencies=[Depends(sec.has_post_rights)],
)
async def create_spec_normalizer_scan(
    payload: SpecNormalizerScanRequest,
    request: Request,
    background_tasks: BackgroundTasks,
    service: Annotated[
        SpecNormalizerService, Depends(get_spec_normalizer_service)
    ],
) -> SpecNormalizerJob:
    user_id = await sec.get_user_id_from_request(request=request)
    job = service.create_scan(payload=payload, user_id=user_id)
    background_tasks.add_task(service.run_scan_job, job.id)
    return job


@router.get("/spec-normalizer/scans/{job_id}", response_model=SpecNormalizerJob)
def get_spec_normalizer_scan(
    job_id: int,
    service: Annotated[
        SpecNormalizerService, Depends(get_spec_normalizer_service)
    ],
) -> SpecNormalizerJob:
    job = service.get_job(job_id=job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="SpecNormalizer scan not found")
    return job


@router.get(
    "/spec-normalizer/approved-groups",
    response_model=SpecNormalizerApprovedState,
)
def get_spec_normalizer_approved_groups(
    service: Annotated[
        SpecNormalizerService, Depends(get_spec_normalizer_service)
    ],
) -> SpecNormalizerApprovedState:
    return service.get_approved_state()


@router.put(
    "/spec-normalizer/approved-groups",
    response_model=SpecNormalizerApprovedState,
    dependencies=[Depends(sec.has_post_rights)],
)
async def save_spec_normalizer_approved_groups(
    payload: SpecNormalizerGroupsSaveRequest,
    request: Request,
    service: Annotated[
        SpecNormalizerService, Depends(get_spec_normalizer_service)
    ],
) -> SpecNormalizerApprovedState:
    user_id = await sec.get_user_id_from_request(request=request)
    return service.save_approved_groups(groups=payload.groups, user_id=user_id)


@router.post(
    "/spec-normalizer/apply",
    response_model=SpecNormalizerApplyResult,
    dependencies=[Depends(sec.has_post_rights)],
)
async def apply_spec_normalizer_group(
    payload: SpecNormalizerApplyRequest,
    request: Request,
    service: Annotated[
        SpecNormalizerService, Depends(get_spec_normalizer_service)
    ],
) -> SpecNormalizerApplyResult:
    user_id = await sec.get_user_id_from_request(request=request)
    return service.apply_group(payload=payload, user_id=user_id)


@router.get("/spec-normalizer/check-name")
def check_spec_normalizer_name(
    name: str,
    service: Annotated[
        SpecNormalizerService, Depends(get_spec_normalizer_service)
    ],
) -> dict:
    return service.check_name(name=name)
