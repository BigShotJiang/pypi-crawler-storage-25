from __future__ import annotations

import json
from collections.abc import Generator, Iterable
from typing import Literal

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

import koco_product_sqlmodel.fastapi.routes.security as sec
from koco_product_sqlmodel.fastapi.ai import (
    DescriptionContextBuilder,
    DescriptionGenerationService,
    IngestionService,
    LLMConfigurationError,
    LLMStreamer,
    get_ai_settings,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (
    IngestionJobCreateRequest,
    IngestionJob,
)


router = APIRouter(
    dependencies=[Depends(sec.get_current_active_user)],
    tags=["Endpoints to AI description generation"],
)


class AIDescriptionStreamRequest(BaseModel):
    entity_type: Literal["family", "article"]
    entity_id: int = Field(gt=0)
    fields: list[Literal["type", "short_description", "description"]] | None = None


def _create_description_generation_service() -> DescriptionGenerationService:
    return DescriptionGenerationService(
        llm_streamer=LLMStreamer(get_ai_settings()),
        context_builder=DescriptionContextBuilder(),
    )


def get_ingestion_service() -> IngestionService:
    return IngestionService()


@router.post("/descriptions/stream")
async def stream_description_generation(
    payload: AIDescriptionStreamRequest,
) -> StreamingResponse:
    try:
        service = _create_description_generation_service()
        stream = service.stream_run(
            entity_type=payload.entity_type,
            entity_id=payload.entity_id,
            fields=payload.fields,
        )
    except LLMConfigurationError as exc:
        stream = iter(({"type": "run.failed", "message": str(exc)},))

    return StreamingResponse(
        _stream_ndjson(stream),
        media_type="application/x-ndjson",
    )


@router.post(
    "/ingestions",
    response_model=IngestionJob,
    dependencies=[Depends(sec.has_post_rights)],
)
async def create_ingestion_job(
    payload: IngestionJobCreateRequest,
    request: Request,
    service: IngestionService = Depends(get_ingestion_service),
) -> IngestionJob:
    user_id = await sec.get_user_id_from_request(request=request)
    return service.create_job(payload=payload, user_id=user_id)


@router.get("/ingestions/{job_id}", response_model=IngestionJob)
def get_ingestion_job(
    job_id: int,
    service: IngestionService = Depends(get_ingestion_service),
) -> IngestionJob:
    return service.get_job(job_id=job_id)


@router.post(
    "/ingestions/{job_id}/retry",
    response_model=IngestionJob,
    dependencies=[Depends(sec.has_post_rights)],
)
def retry_ingestion_job(
    job_id: int,
    service: IngestionService = Depends(get_ingestion_service),
) -> IngestionJob:
    return service.retry_job(job_id=job_id)


@router.get("/ingestions/{job_id}/events")
def stream_ingestion_events(
    job_id: int,
    service: IngestionService = Depends(get_ingestion_service),
) -> StreamingResponse:
    stream = service.get_event_stream(job_id=job_id)
    return StreamingResponse(
        stream,
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


def _stream_ndjson(
    events: Generator[dict[str, object], None, None] | Iterable[dict[str, object]],
) -> Generator[str, None, None]:
    for event in events:
        yield json.dumps(event, ensure_ascii=False) + "\n"
