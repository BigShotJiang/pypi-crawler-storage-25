import os

from dotenv import load_dotenv
from sqlmodel import create_engine

load_dotenv()

DATABASE_URL_ENV_VARS = ("MARIADB_CONNECTOR_STRING", "DATABASE_URL")


def get_database_url() -> str:
    for env_var in DATABASE_URL_ENV_VARS:
        value = os.getenv(env_var)
        if value:
            return value
    supported_vars = ", ".join(DATABASE_URL_ENV_VARS)
    raise RuntimeError(
        f"Database connection string is not configured. Set one of: {supported_vars}"
    )

def create_mdb_engine():
    engine = create_engine(url=get_database_url())
    return engine


mdb_engine = create_mdb_engine()


def Main():
    print(mdb_engine)


if __name__ == "__main__":
    Main()
