import os
import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
os.environ.setdefault("FASTAPI_SECURITY_SECRET_KEY", "test-secret")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from koco_product_sqlmodel.fastapi.spec_normalizer import (  # noqa: E402
    SpecNameContext,
    SpecNormalizerService,
    _chunk_groups_for_ai,
    _split_ai_review_groups,
)


class SpecNormalizerGroupingTests(unittest.TestCase):
    def test_speed_operating_points_are_not_collapsed(self) -> None:
        service = SpecNormalizerService()

        groups = service._group_locally(
            [
                SpecNameContext(name="No load speed", count=1, units=["rpm"]),
                SpecNameContext(name="No-Load Speed", count=1, units=["rpm"]),
                SpecNameContext(name="Load speed", count=1, units=["rpm"]),
                SpecNameContext(name="Rated speed", count=1, units=["rpm"]),
                SpecNameContext(name="Nominal speed", count=1, units=["rpm"]),
                SpecNameContext(name="Maximum speed", count=1, units=["rpm"]),
                SpecNameContext(name="Motor Length", count=1, units=["mm"]),
            ]
        )

        groups_by_name = {group.canonical_name: group for group in groups}

        self.assertEqual(
            set(groups_by_name["No-load speed"].variants),
            {"No load speed", "No-Load Speed"},
        )
        self.assertEqual(groups_by_name["Load speed"].variants, ["Load speed"])
        self.assertEqual(
            set(groups_by_name["Nominal speed"].variants),
            {"Rated speed", "Nominal speed"},
        )
        self.assertEqual(groups_by_name["Maximum speed"].variants, ["Maximum speed"])
        self.assertEqual(groups_by_name["Motor Length"].variants, ["Motor Length"])

    def test_voltage_names_are_grouped_but_voltage_conditions_are_not(self) -> None:
        service = SpecNormalizerService()

        groups = service._group_locally(
            [
                SpecNameContext(name="Voltage", count=1, units=["V"]),
                SpecNameContext(name="Rated Voltage", count=1, units=["V"]),
                SpecNameContext(name="Supply voltage 24 VDC", count=1, units=["V"]),
                SpecNameContext(name="Maximum speed @24Vdc", count=1, units=["rpm"]),
                SpecNameContext(name="Maximum speed @48Vdc", count=1, units=["rpm"]),
            ]
        )

        groups_by_name = {group.canonical_name: group for group in groups}

        self.assertEqual(
            set(groups_by_name["Rated voltage"].variants),
            {"Voltage", "Rated Voltage", "Supply voltage 24 VDC"},
        )
        self.assertEqual(
            groups_by_name["Maximum speed @ 24VDC"].variants,
            ["Maximum speed @24Vdc"],
        )
        self.assertEqual(
            groups_by_name["Maximum speed @ 48VDC"].variants,
            ["Maximum speed @48Vdc"],
        )

    def test_constants_are_not_grouped_as_speed(self) -> None:
        service = SpecNormalizerService()

        groups = service._group_locally(
            [
                SpecNameContext(name="Voltage constant", count=1, units=["rpm/V"]),
                SpecNameContext(name="Back EMF constant", count=1, units=["V/rpm"]),
                SpecNameContext(name="Speed constant", count=1, units=["rpm/V"]),
                SpecNameContext(name="No load speed", count=1, units=["rpm"]),
            ]
        )

        groups_by_name = {group.canonical_name: group for group in groups}

        self.assertEqual(
            set(groups_by_name["Voltage constant"].variants),
            {"Voltage constant", "Back EMF constant"},
        )
        self.assertEqual(groups_by_name["Speed constant"].variants, ["Speed constant"])
        self.assertEqual(groups_by_name["No-load speed"].variants, ["No load speed"])

    def test_german_motor_aliases_map_to_same_semantics(self) -> None:
        service = SpecNormalizerService()

        groups = service._group_locally(
            [
                SpecNameContext(name="Leerlaufdrehzahl", count=1, units=["rpm"]),
                SpecNameContext(name="No load speed", count=1, units=["rpm"]),
                SpecNameContext(name="Nennspannung", count=1, units=["V"]),
                SpecNameContext(name="Rated Voltage", count=1, units=["V"]),
                SpecNameContext(name="Drehmomentkonstante", count=1, units=["mNm/A"]),
                SpecNameContext(name="Torque constant", count=1, units=["mNm/A"]),
            ]
        )

        groups_by_name = {group.canonical_name: group for group in groups}

        self.assertEqual(
            set(groups_by_name["No-load speed"].variants),
            {"Leerlaufdrehzahl", "No load speed"},
        )
        self.assertEqual(
            set(groups_by_name["Rated voltage"].variants),
            {"Nennspannung", "Rated Voltage"},
        )
        self.assertEqual(
            set(groups_by_name["Torque constant"].variants),
            {"Drehmomentkonstante", "Torque constant"},
        )

    def test_ai_chunks_are_bounded_by_variant_count(self) -> None:
        service = SpecNormalizerService()
        names = [
            SpecNameContext(name=f"Variant {index}", count=1) for index in range(70)
        ]
        groups = service._group_locally(names)

        chunks = _chunk_groups_for_ai(groups)

        self.assertTrue(chunks)
        self.assertTrue(
            all(sum(len(group.variants) for group in chunk) <= 45 for chunk in chunks)
        )

    def test_large_groups_are_kept_out_of_ai_batches(self) -> None:
        service = SpecNormalizerService()
        names = [
            SpecNameContext(name=f"No load speed {index}", count=1, units=["rpm"])
            for index in range(70)
        ]
        groups = service._group_locally(names)

        review_groups, local_groups = _split_ai_review_groups(groups)

        self.assertEqual(review_groups, [])
        self.assertEqual(len(local_groups), 1)
        self.assertEqual(len(local_groups[0].variants), 70)

    def test_collect_spec_names_only_reads_overview_tables(self) -> None:
        session = Mock()
        session.__enter__ = Mock(return_value=session)
        session.__exit__ = Mock(return_value=None)
        session.exec.return_value.all.return_value = []

        with patch(
            "koco_product_sqlmodel.fastapi.spec_normalizer.Session",
            return_value=session,
        ):
            SpecNormalizerService()._collect_spec_names()

        statement = session.exec.call_args.args[0]
        compiled_statement = str(
            statement.compile(compile_kwargs={"literal_binds": True})
        )

        self.assertIn("cspectable.type = 'overview'", compiled_statement)
        self.assertIn("JOIN cspectable", compiled_statement)


if __name__ == "__main__":
    unittest.main()
