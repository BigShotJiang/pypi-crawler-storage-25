import asyncio
import datetime as dt
import json
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
os.environ.setdefault("FASTAPI_SECURITY_SECRET_KEY", "test-secret")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from koco_product_sqlmodel.fastapi.ai.ingestion_models import (  # noqa: E402
    ExtractedFigure,
    ExtractedSourceContent,
    IngestionGatherPlan,
    IngestionJob,
    IngestionResult,
    IngestionApplication,
    IngestionArticle,
    IngestionFigure,
    IngestionOption,
    IngestionSpectable,
    IngestionSpectableItem,
    IngestionUrl,
    IngestionEvent,
    IngestionSource,
    IngestionSourceFigureFinding,
    IngestionSourceFinding,
    IngestionWarning,
    RelatedSourceCandidate,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_persistence import (  # noqa: E402
    ChangeLogEntry,
    IngestionPersistenceService,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_result_utils import (  # noqa: E402
    normalize_figure_type,
    normalize_url_type,
    to_storage_document_type,
    to_storage_url_type,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_service import (  # noqa: E402
    IngestionService,
)


class CapturingLLMStreamer:
    def __init__(self, response, *, multimodal_response=None):
        self.response = response
        self.multimodal_response = (
            response if multimodal_response is None else multimodal_response
        )
        self.calls: list[dict[str, object]] = []

    def generate_structured(self, **kwargs):
        self.calls.append(kwargs)
        return self.response

    def generate_structured_multimodal(self, **kwargs):
        self.calls.append(kwargs)
        return self.multimodal_response


class EventStreamRepository:
    def __init__(self) -> None:
        self.events_calls = 0
        self.job_calls = 0

    def get_job(self, job_id: int):
        self.job_calls += 1
        status = "completed" if self.job_calls >= 3 else "running"
        return SimpleNamespace(id=job_id, status=status)

    def get_events(self, job_id: int):
        self.events_calls += 1
        if self.events_calls == 1:
            return []
        return [
            IngestionEvent(
                job_id=job_id,
                sequence=1,
                timestamp=dt.datetime.now(dt.timezone.utc),
                type="run.completed",
                message="Done",
            )
        ]


class ProcessJobRepository:
    def __init__(self, *, job):
        self.record = SimpleNamespace(
            id=job.id,
            entity_id=job.entity_id,
            entity_type=job.entity_type,
            user_id=7,
        )
        self.job = job
        self.events: list[IngestionEvent] = []

    def get_record(self, job_id: int):
        return self.record if self.record.id == job_id else None

    def update_job_state(self, job_id: int, **kwargs):
        for key, value in kwargs.items():
            setattr(self.job, key, value)
        return self.job

    def update_source(self, job_id: int, source_id: int, **kwargs):
        for source in self.job.sources:
            if source.id != source_id:
                continue
            for key, value in kwargs.items():
                setattr(source, key, value)
            break
        return self.job

    def append_event(
        self,
        job_id: int,
        *,
        event_type: str,
        message: str,
        source_id: int | None = None,
        meta: dict[str, object] | None = None,
    ):
        event = IngestionEvent(
            job_id=job_id,
            sequence=len(self.events) + 1,
            timestamp=dt.datetime.now(dt.timezone.utc),
            type=event_type,
            message=message,
            source_id=source_id,
            meta=meta,
        )
        self.events.append(event)
        return event


class IngestionServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.service = IngestionService(repository=object())
        self.persistence = IngestionPersistenceService()

    def test_normalize_result_dedupes_records_and_filters_invalid_article_tables(self) -> None:
        result = IngestionResult(
            articles=[
                IngestionArticle(article="A-100", order_priority=0),
                IngestionArticle(article="a-100", order_priority=10),
                IngestionArticle(article="B-200", order_priority=-1),
            ],
            applications=[
                IngestionApplication(application="Packaging"),
                IngestionApplication(application="packaging"),
            ],
            options=[
                IngestionOption(type="Features", category="Drive", option="Servo"),
                IngestionOption(type="features", category="drive", option="servo"),
            ],
            family_spectables=[
                IngestionSpectable(
                    name="Overview",
                    type="overview",
                    items=[IngestionSpectableItem(name="Force", value="10")],
                ),
                IngestionSpectable(name=" ", type="overview", items=[]),
            ],
            article_spectables=[
                IngestionSpectable(
                    name="Electrical",
                    type="multicol",
                    article_name="a-100",
                    items=[IngestionSpectableItem(name="Voltage", value="24")],
                ),
                IngestionSpectable(
                    name="Ignore me",
                    type="multicol",
                    article_name="Missing article",
                    items=[IngestionSpectableItem(name="Voltage", value="48")],
                ),
            ],
            warnings=[IngestionWarning(code="kept", message="Still present")],
            urls=[
                IngestionUrl(
                    type="pdf",
                    supplier_url="https://supplier.example/a-100.pdf",
                    parent="article",
                    article_name="a-100",
                ),
                IngestionUrl(
                    type="PDF",
                    supplier_url="https://supplier.example/a-100.pdf",
                    parent="article",
                    article_name="A-100",
                ),
                IngestionUrl(
                    type="product page",
                    supplier_url="https://supplier.example/family",
                    parent="family",
                ),
                IngestionUrl(
                    type="datasheet",
                    supplier_url="https://supplier.example/missing.pdf",
                    parent="article",
                    article_name="Missing article",
                ),
            ],
        )

        normalized = self.service._normalize_result(result)

        self.assertEqual([article.article for article in normalized.articles], ["A-100", "B-200"])
        self.assertEqual(normalized.articles[0].order_priority, 100)
        self.assertEqual(normalized.articles[1].order_priority, 99)
        self.assertEqual(
            [application.application for application in normalized.applications],
            ["Packaging"],
        )
        self.assertEqual(
            [(option.type, option.category, option.option) for option in normalized.options],
            [("Features", "Drive", "Servo")],
        )
        self.assertEqual(len(normalized.family_spectables), 1)
        self.assertEqual(len(normalized.article_spectables), 1)
        self.assertEqual(normalized.article_spectables[0].article_name, "A-100")
        self.assertEqual(len(normalized.urls), 2)
        self.assertEqual(normalized.urls[0].article_name, "A-100")
        self.assertEqual(normalized.urls[0].type, "datasheet")
        self.assertEqual(normalized.urls[1].type, "supplier_site")

    def test_merge_warnings_dedupes_by_code_and_message(self) -> None:
        merged = self.service._merge_warnings(
            [IngestionWarning(code="duplicate", message="same")],
            [
                IngestionWarning(code="duplicate", message="same"),
                IngestionWarning(code="other", message="different"),
            ],
        )

        self.assertEqual(
            [(warning.code, warning.message) for warning in merged],
            [("duplicate", "same"), ("other", "different")],
        )

    def test_normalize_url_type_accepts_only_canonical_names(self) -> None:
        self.assertEqual(normalize_url_type("2D drawing", None), "2D drawing")
        self.assertEqual(normalize_url_type(" Speed Curves ", None), "speed curves")
        self.assertEqual(
            normalize_url_type("2D drawings", "https://supplier.example/resource"),
            "supplier_site",
        )
        self.assertEqual(
            normalize_url_type("speed curve", "https://supplier.example/resource"),
            "supplier_site",
        )
        self.assertEqual(
            normalize_url_type("curve", "https://supplier.example/resource"),
            "supplier_site",
        )

    def test_normalize_figure_type_accepts_only_canonical_names(self) -> None:
        self.assertEqual(normalize_figure_type("2D drawing"), "2D drawing")
        self.assertEqual(normalize_figure_type("speed curves"), "speed curves")
        self.assertEqual(normalize_figure_type("2D drawings"), "drawing")
        self.assertEqual(normalize_figure_type("speed curve"), "drawing")
        self.assertEqual(normalize_figure_type("curve"), "drawing")

    def test_storage_type_mapping_preserves_legacy_db_values(self) -> None:
        self.assertEqual(to_storage_url_type("2D drawing", None), "2D drawings")
        self.assertEqual(to_storage_url_type("speed curves", None), "speed_curves")
        self.assertEqual(to_storage_document_type("2D drawing"), "2D drawings")
        self.assertEqual(to_storage_document_type("speed curves"), "speed_curves")

    def test_format_sse_serializes_event_payload(self) -> None:
        payload = self.service._format_sse(
            IngestionEvent(
                job_id=4,
                sequence=2,
                timestamp="2026-03-20T10:00:00Z",
                type="run.completed",
                message="Done",
                source_id=1,
                meta={"article_count": 3},
            )
        )

        self.assertTrue(payload.startswith("data: "))
        self.assertTrue(payload.endswith("\n\n"))
        raw = payload.removeprefix("data: ").strip()
        parsed = json.loads(raw)
        self.assertEqual(parsed["job_id"], 4)
        self.assertEqual(parsed["sequence"], 2)
        self.assertEqual(parsed["type"], "run.completed")
        self.assertEqual(parsed["meta"]["article_count"], 3)

    def test_get_event_stream_yields_keepalive_until_terminal_event(self) -> None:
        service = IngestionService(repository=EventStreamRepository())

        async def collect() -> list[str]:
            return [chunk async for chunk in service.get_event_stream(job_id=9)]

        with patch(
            "koco_product_sqlmodel.fastapi.ai.ingestion_service.DEFAULT_EVENT_POLL_INTERVAL",
            0,
        ):
            payloads = asyncio.run(collect())

        self.assertEqual(payloads[0], ": keepalive\n\n")
        self.assertTrue(payloads[1].startswith("data: "))
        parsed = json.loads(payloads[1].removeprefix("data: ").strip())
        self.assertEqual(parsed["job_id"], 9)
        self.assertEqual(parsed["sequence"], 1)

    def test_process_job_surfaces_source_failure_details_when_nothing_is_extracted(self) -> None:
        job = IngestionJob(
            id=11,
            entity_id=3,
            entity_type="family",
            status="pending",
            phase="queued",
            sources=[
                IngestionSource(
                    id=1,
                    source_type="url",
                    url="https://supplier.example/files/alpha.pdf",
                    filename="alpha.pdf",
                    status="pending",
                )
            ],
        )
        repository = ProcessJobRepository(job=job)
        persistence = SimpleNamespace(cleanup_job_figure_previews=lambda job_id: None)
        service = IngestionService(
            llm_streamer=object(),
            repository=repository,
            persistence=persistence,
        )

        with (
            patch.object(service, "_ensure_llm"),
            patch.object(service, "_ensure_entity_is_empty"),
            patch.object(
                service,
                "_extract_source",
                side_effect=RuntimeError(
                    "Remote resource returned HTTP 404 Not Found for "
                    "https://supplier.example/files/alpha.pdf"
                ),
            ),
        ):
            service.process_job(job.id)

        self.assertEqual(repository.job.status, "failed")
        self.assertIn("No usable sources were extracted for this job", repository.job.error_text)
        self.assertIn("alpha.pdf", repository.job.error_text)
        self.assertIn("HTTP 404 Not Found", repository.job.error_text)

    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.expand_related_url_sources",
        return_value=("related text", [], [], [], []),
    )
    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.plan_related_source_expansion",
        return_value=IngestionGatherPlan(
            selected_urls=["https://supplier.example/product-detail/a-100.html"]
        ),
    )
    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.extract_url_source",
        return_value=ExtractedSourceContent(
            source_id=1,
            text="base text",
            related_candidates=[
                RelatedSourceCandidate(
                    url="https://supplier.example/product-detail/a-100.html",
                    kind="page",
                    label="A-100",
                ),
                RelatedSourceCandidate(
                    url="https://supplier.example/products/overview.html",
                    kind="page",
                    label="Overview",
                ),
            ],
        ),
    )
    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.mdb_fam.get_family_db_by_id",
        return_value=SimpleNamespace(family="Sample Family"),
    )
    def test_extract_source_uses_agent_selected_related_sources(
        self,
        _get_family,
        extract_url_source,
        plan_related_source_expansion,
        expand_related_url_sources,
    ) -> None:
        service = IngestionService(
            repository=object(),
            llm_streamer=CapturingLLMStreamer(IngestionGatherPlan()),
        )

        extracted = service._extract_source(
            IngestionSource(
                id=1,
                source_type="url",
                url="https://supplier.example/family/a-100",
            ),
            entity_id=7,
            entity_type="family",
        )

        self.assertEqual(extracted.text, "base text\n\nrelated text")
        extract_url_source.assert_called_once()
        plan_related_source_expansion.assert_called_once()
        expand_related_url_sources.assert_called_once()

    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.plan_related_source_expansion",
        side_effect=RuntimeError("planner failed"),
    )
    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.extract_url_source",
        return_value=ExtractedSourceContent(
            source_id=1,
            text="base text",
            related_candidates=[
                RelatedSourceCandidate(
                    url="https://supplier.example/product-detail/a-100.html",
                    kind="page",
                    label="A-100",
                )
            ],
        ),
    )
    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.mdb_fam.get_family_db_by_id",
        return_value=SimpleNamespace(family="Sample Family"),
    )
    def test_extract_source_keeps_base_result_when_related_planning_fails(
        self,
        _get_family,
        extract_url_source,
        _plan_related_source_expansion,
    ) -> None:
        service = IngestionService(
            repository=object(),
            llm_streamer=CapturingLLMStreamer(IngestionGatherPlan()),
        )

        extracted = service._extract_source(
            IngestionSource(
                id=1,
                source_type="url",
                url="https://supplier.example/family/a-100",
            ),
            entity_id=7,
            entity_type="family",
        )

        self.assertEqual(extracted.text, "base text")
        self.assertEqual(
            extracted.warnings[0].code,
            "related_source_planning_failed",
        )
        extract_url_source.assert_called_once()

    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_persistence_logging.dbm_support.get_table_from_sqlmodels",
        return_value="cfamily",
    )
    @patch("koco_product_sqlmodel.fastapi.ai.ingestion_persistence_logging.mdb_change.log_results_to_db")
    def test_queue_change_log_captures_snapshot_before_detach(
        self,
        log_results_to_db,
        _,
    ) -> None:
        class FakeEntity:
            id = 42

            def model_dump_json(self, *, exclude):
                assert exclude == {"insdate", "upddate"}
                return '{"id":42,"family":"Test"}'

        pending_logs: list[ChangeLogEntry] = []

        self.persistence._queue_change_log(
            pending_logs,
            FakeEntity(),
            "PATCH",
        )

        self.assertEqual(
            pending_logs,
            [
                ChangeLogEntry(
                    entity_id=42,
                    entity_type="cfamily",
                    action="PATCH",
                    new_values='{"id":42,"family":"Test"}',
                )
            ],
        )

        self.persistence._log_change(pending_logs[0], user_id=7)

        log_results_to_db.assert_called_once_with(
            entity_id=42,
            entity_type="cfamily",
            action="PATCH",
            user_id=7,
            new_values='{"id":42,"family":"Test"}',
        )

    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.mdb_fam.get_family_db_by_id",
        return_value=SimpleNamespace(family="Sample Family"),
    )
    def test_generate_source_figure_finding_instructs_photo_requires_embedded_image(
        self, _
    ) -> None:
        llm_streamer = CapturingLLMStreamer(
            response=IngestionSourceFinding(source_id=1),
            multimodal_response=IngestionSourceFigureFinding(),
        )
        service = IngestionService(repository=object(), llm_streamer=llm_streamer)
        extracted = ExtractedSourceContent(
            source_id=1,
            title="Sample PDF",
            locator="sample.pdf",
            mime_type="application/pdf",
            figures=[
                ExtractedFigure(
                    figure_id=7,
                    locator="page 1, figure 1",
                    page_number=1,
                    extraction_method="page_crop",
                    image_data_url="data:image/png;base64,AAAA",
                )
            ],
        )

        service._generate_source_figure_finding(
            entity_id=1,
            entity_type="family",
            source=IngestionSource(
                id=1,
                source_type="file",
                filename="sample.pdf",
                mime_type="application/pdf",
            ),
            extracted=extracted,
            article_candidates=["A-100"],
        )

        prompt_text = llm_streamer.calls[0]["user_content"][0]["text"]
        self.assertIn(
            "Use type='photo' when candidate metadata indicates a true image asset",
            prompt_text,
        )
        self.assertIn(
            "Never classify a rendered PDF page crop or screenshot as a product photo.",
            prompt_text,
        )
        self.assertIn('"extraction_method": "page_crop"', prompt_text)

    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.mdb_fam.get_family_db_by_id",
        return_value=SimpleNamespace(family="Sample Family"),
    )
    def test_generate_source_figure_finding_rejects_photo_from_page_crop(self, _) -> None:
        llm_streamer = CapturingLLMStreamer(
            response=IngestionSourceFinding(source_id=1),
            multimodal_response=IngestionSourceFigureFinding(
                figures=[
                    IngestionFigure(
                        source_figure_id=7,
                        type="photo",
                        description="Product photo",
                        parent="family",
                    )
                ]
            ),
        )
        service = IngestionService(repository=object(), llm_streamer=llm_streamer)
        extracted = ExtractedSourceContent(
            source_id=1,
            title="Sample PDF",
            locator="sample.pdf",
            mime_type="application/pdf",
            figures=[
                ExtractedFigure(
                    figure_id=7,
                    locator="page 1, figure 1",
                    page_number=1,
                    extraction_method="page_crop",
                    image_data_url="data:image/png;base64,AAAA",
                )
            ],
        )

        result = service._generate_source_figure_finding(
            entity_id=1,
            entity_type="family",
            source=IngestionSource(
                id=1,
                source_type="file",
                filename="sample.pdf",
                mime_type="application/pdf",
            ),
            extracted=extracted,
            article_candidates=["A-100"],
        )

        self.assertEqual(result.figures, [])
        self.assertEqual(
            [(warning.code, warning.message) for warning in result.warnings],
            [
                (
                    "figure_photo_requires_embedded_image",
                    "Skipped source 1 figure 7 as photo because it was only available as a rendered PDF crop.",
                )
            ],
        )

    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.mdb_fam.get_family_db_by_id",
        return_value=SimpleNamespace(family="Sample Family"),
    )
    def test_generate_source_figure_finding_allows_photo_from_embedded_image(self, _) -> None:
        llm_streamer = CapturingLLMStreamer(
            response=IngestionSourceFinding(source_id=1),
            multimodal_response=IngestionSourceFigureFinding(
                figures=[
                    IngestionFigure(
                        source_figure_id=7,
                        type="photo",
                        description="Product photo",
                        parent="family",
                    )
                ]
            ),
        )
        service = IngestionService(repository=object(), llm_streamer=llm_streamer)
        extracted = ExtractedSourceContent(
            source_id=1,
            title="Sample PDF",
            locator="sample.pdf",
            mime_type="application/pdf",
            figures=[
                ExtractedFigure(
                    figure_id=7,
                    locator="page 1, figure 1",
                    page_number=1,
                    extraction_method="embedded_image",
                    image_data_url="data:image/png;base64,AAAA",
                )
            ],
        )

        result = service._generate_source_figure_finding(
            entity_id=1,
            entity_type="family",
            source=IngestionSource(
                id=1,
                source_type="file",
                filename="sample.pdf",
                mime_type="application/pdf",
            ),
            extracted=extracted,
            article_candidates=["A-100"],
        )

        self.assertEqual(len(result.figures), 1)
        self.assertEqual(result.figures[0].type, "photo")
        self.assertEqual(result.figures[0].source_id, 1)

    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_service.mdb_fam.get_family_db_by_id",
        return_value=SimpleNamespace(family="Sample Family"),
    )
    def test_source_finding_prompt_includes_db_backed_table_and_option_guidance(
        self, _
    ) -> None:
        llm_streamer = CapturingLLMStreamer(
            IngestionSourceFinding(source_id=1)
        )
        service = IngestionService(repository=object(), llm_streamer=llm_streamer)

        service._generate_source_finding(
            entity_id=1,
            entity_type="family",
            source=IngestionSource(
                id=1,
                source_type="file",
                filename="sample.pdf",
                mime_type="application/pdf",
            ),
            extracted=ExtractedSourceContent(
                source_id=1,
                title="Sample PDF",
                locator="sample.pdf",
                mime_type="application/pdf",
                text="Voltage 24 V. Holding torque 31 Ncm. Screw code table.",
                tables=[],
            ),
        )

        prompt = llm_streamer.calls[0]["user_prompt"]
        self.assertIn("1831 of 2082 articles have exactly one article-level overview table", prompt)
        self.assertIn("create one article_spectables overview table per article", prompt)
        self.assertIn("Prefer family multicol over family free", prompt)
        self.assertIn("Do not put table rows into options or features", prompt)
        self.assertIn("category='Encoder' option='KPL56'", prompt)


if __name__ == "__main__":
    unittest.main()
