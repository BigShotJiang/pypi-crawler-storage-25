import os
import sys
import unittest
from pathlib import Path


os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
os.environ.setdefault("FASTAPI_SECURITY_SECRET_KEY", "test-secret")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from koco_product_sqlmodel.fastapi.ai.context_builder import (  # noqa: E402
    DescriptionContextBuilder,
    MAX_PROMPT_TEXT_LENGTH,
)


class DescriptionContextBuilderTests(unittest.TestCase):
    def test_build_family_context_collects_expected_sections(self) -> None:
        builder = DescriptionContextBuilder(
            family_fetcher=lambda family_id: {
                "id": family_id,
                "family": "Linear Actuator",
                "type": "Actuator",
                "short_description": "Existing short",
                "description": "Existing description",
                "product_group_id": 11,
                "status": 2,
            },
            family_articles_fetcher=lambda family_id: [
                {
                    "id": 21,
                    "article": "LA-100",
                    "family_id": family_id,
                    "short_description": "Article short",
                    "description": "Article description",
                    "order_priority": 10,
                    "status": 3,
                }
            ],
            applications_fetcher=lambda family_id: [
                {"application": "Packaging"},
                {"application": "Assembly"},
            ],
            options_fetcher=lambda family_id: [
                {"type": "Features", "category": "Mechanical", "option": "Ball screw"}
            ],
            spectables_fetcher=lambda parent, parent_id: [
                {
                    "id": 31,
                    "name": f"{parent.title()} specs",
                    "type": "overview",
                    "parent": parent,
                    "parent_id": parent_id,
                    "has_unit": True,
                    "description_json": "",
                    "spectableitems": [
                        {
                            "pos": "1",
                            "name": "Stroke",
                            "value": "100",
                            "min_value": "",
                            "max_value": "",
                            "unit": "mm",
                        }
                    ],
                }
            ],
        )

        context = builder.build_family_context(7)

        self.assertEqual(context["entity_type"], "family")
        self.assertEqual(context["family"]["id"], 7)
        self.assertEqual(context["articles"][0]["article"], "LA-100")
        self.assertEqual(context["applications"], ["Packaging", "Assembly"])
        self.assertEqual(context["options"][0]["option"], "Ball screw")
        self.assertEqual(context["family_spectables"][0]["items"][0]["name"], "Stroke")
        self.assertIn("21", context["article_spectables"])

    def test_build_article_context_includes_family_context(self) -> None:
        builder = DescriptionContextBuilder(
            article_fetcher=lambda article_id: {
                "id": article_id,
                "article": "LA-200",
                "family_id": 7,
                "short_description": "Short",
                "description": "Description",
                "order_priority": 100,
                "status": 2,
            },
            family_fetcher=lambda family_id: {
                "id": family_id,
                "family": "Linear Actuator",
                "type": "Actuator",
                "product_group_id": 11,
                "status": 2,
            },
            applications_fetcher=lambda family_id: [{"application": "Machine tools"}],
            options_fetcher=lambda family_id: [
                {"type": "Options", "category": "Control", "option": "Encoder"}
            ],
            spectables_fetcher=lambda parent, parent_id: [
                {
                    "id": 44,
                    "name": f"{parent}-{parent_id}",
                    "type": "overview",
                    "parent": parent,
                    "parent_id": parent_id,
                    "has_unit": False,
                    "description_json": "",
                    "spectableitems": [],
                }
            ],
        )

        context = builder.build_article_context(19)

        self.assertEqual(context["entity_type"], "article")
        self.assertEqual(context["article"]["id"], 19)
        self.assertEqual(context["family"]["family"], "Linear Actuator")
        self.assertEqual(context["applications"], ["Machine tools"])
        self.assertEqual(context["options"][0]["option"], "Encoder")
        self.assertEqual(context["article_spectables"][0]["parent"], "article")

    def test_truncates_oversized_prompt_values(self) -> None:
        oversized = "x" * (MAX_PROMPT_TEXT_LENGTH + 50)
        builder = DescriptionContextBuilder(
            family_fetcher=lambda family_id: {"id": family_id, "family": oversized},
            family_articles_fetcher=lambda family_id: [],
            applications_fetcher=lambda family_id: [],
            options_fetcher=lambda family_id: [],
            spectables_fetcher=lambda parent, parent_id: [],
        )

        context = builder.build_family_context(3)

        self.assertLessEqual(len(context["family"]["family"]), MAX_PROMPT_TEXT_LENGTH + 3)
        self.assertTrue(context["family"]["family"].endswith("..."))


if __name__ == "__main__":
    unittest.main()
