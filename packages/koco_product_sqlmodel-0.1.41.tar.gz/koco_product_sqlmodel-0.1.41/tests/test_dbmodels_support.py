import os
import sys
import unittest
from pathlib import Path

os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from koco_product_sqlmodel.dbmodels.backgroundjob import CBackgroundJob  # noqa: E402
from koco_product_sqlmodel.dbmodels.appmeta import CAppMeta  # noqa: E402
import koco_product_sqlmodel.dbmodels.support as support  # noqa: E402


class SupportNamingTests(unittest.TestCase):
    def test_backgroundjob_uses_compact_canonical_identifier(self) -> None:
        self.assertEqual(CBackgroundJob.__tablename__, "cbackgroundjob")
        self.assertEqual(
            support.get_table_from_sqlmodels(CBackgroundJob),
            "cbackgroundjob",
        )
        self.assertEqual(
            support.get_entity_type_from_sqlmodel_object(
                CBackgroundJob(
                    job_type="ai_ingestion", entity_id=1, entity_type="family"
                )
            ),
            "cbackgroundjob",
        )

    def test_backgroundjob_lookup_accepts_compact_identifier(self) -> None:
        self.assertIs(
            support.get_db_object_type("backgroundjob"),
            CBackgroundJob,
        )
        self.assertIs(
            support.get_db_object_type("cbackgroundjob"),
            CBackgroundJob,
        )

    def test_legacy_aiingestionjob_lookup_points_to_backgroundjob(self) -> None:
        self.assertIs(
            support.get_db_object_type("aiingestionjob"),
            CBackgroundJob,
        )

    def test_appmeta_uses_compact_canonical_identifier(self) -> None:
        self.assertEqual(CAppMeta.__tablename__, "cappmeta")
        self.assertEqual(
            support.get_table_from_sqlmodels(CAppMeta),
            "cappmeta",
        )
        self.assertIs(
            support.get_db_object_type("appmeta"),
            CAppMeta,
        )


if __name__ == "__main__":
    unittest.main()
