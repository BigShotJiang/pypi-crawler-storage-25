import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch


os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import koco_product_sqlmodel.mdb_connect.mdb_connector as mdb_connector  # noqa: E402


class DeleteFamilyTests(unittest.TestCase):
    @patch.object(mdb_connector, "_delete_family_from_category_mapper")
    @patch.object(mdb_connector, "_delete_aiingestionjobs_from_entity")
    @patch.object(mdb_connector, "_delete_articles_from_family")
    @patch.object(mdb_connector, "_delete_spectables_from_family")
    @patch.object(mdb_connector, "_delete_applications_from_family")
    @patch.object(mdb_connector, "_delete_options_from_family")
    @patch.object(mdb_connector, "_delete_filedata_from_family")
    @patch.object(mdb_connector, "_delete_urls_from_family")
    def test_delete_family_cleans_up_aiingestionjobs(
        self,
        delete_urls,
        delete_filedata,
        delete_options,
        delete_applications,
        delete_spectables,
        delete_articles,
        delete_ai_jobs,
        delete_category_mapper,
    ) -> None:
        family = SimpleNamespace(id=699)
        log_func = MagicMock()
        fake_session = MagicMock()
        fake_session.__enter__.return_value = fake_session
        fake_session.__exit__.return_value = False

        with patch.object(mdb_connector, "Session", return_value=fake_session):
            mdb_connector.delete_family(
                log_func=log_func,
                family=family,
                delete_connected_items=True,
                user_id=42,
            )

        delete_ai_jobs.assert_called_once_with(
            log_func=log_func,
            entity_id=family.id,
            entity_type="family",
            user_id=42,
        )
        delete_category_mapper.assert_called_once_with(family=family)
        fake_session.delete.assert_called_once_with(family)
        fake_session.commit.assert_called_once()
        log_func.assert_called_once_with(
            entity_type="cfamily",
            entity_id=699,
            action="DELETE",
            user_id=42,
            new_values=None,
        )


if __name__ == "__main__":
    unittest.main()
