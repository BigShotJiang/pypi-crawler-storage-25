import asyncio
import os
import sys
import types
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
os.environ.setdefault("FASTAPI_SECURITY_SECRET_KEY", "test-secret")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from koco_product_sqlmodel.fastapi.ai.ingestion_extractors import (  # noqa: E402
    _collect_related_link_candidates,
    _extract_pdf_embedded_image_data_url,
    _render_url_with_playwright,
    _extract_related_link_candidates,
    _infer_filename_from_response,
    extract_file_source,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_extraction_common import (  # noqa: E402
    IngestionSourceExtractionError,
    PLAYWRIGHT_COMMIT_TIMEOUT_MS,
    PLAYWRIGHT_NAVIGATION_TIMEOUT_MS,
    PLAYWRIGHT_POST_LOAD_SETTLE_MS,
    PLAYWRIGHT_WAIT_FOR_BODY_TIMEOUT_MS,
    PLAYWRIGHT_WAIT_FOR_LOAD_TIMEOUT_MS,
    _read_response_content,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_models import (  # noqa: E402
    ExtractedSourceContent,
    IngestionSource,
)


class IngestionExtractorTests(unittest.TestCase):
    def test_extract_pdf_embedded_image_data_url_prefers_raw_embedded_bytes(self) -> None:
        data_url, mime_type, width, height = _extract_pdf_embedded_image_data_url(
            block={
                "image": b"raw-image",
                "ext": "png",
                "width": 640,
                "height": 480,
            }
        )

        self.assertEqual(mime_type, "image/png")
        self.assertEqual(width, 640)
        self.assertEqual(height, 480)
        self.assertTrue(data_url.startswith("data:image/png;base64,"))

    def test_extract_related_link_candidates_accepts_relevant_off_domain_datasheets(self) -> None:
        html = """
        <html>
          <body>
            <h3>Downloads</h3>
            <a href="https://cdn.supplier.example/files/a-100-datasheet.pdf">A-100 Datasheet</a>
            <a href="https://supplier.example/products/a-100">A-100 Product Page</a>
          </body>
        </html>
        """

        candidates = _extract_related_link_candidates(
            html_content=html,
            base_url="https://supplier.example/family/kannmotion",
            page_title="A-100 Linear Motor",
        )

        self.assertEqual(len(candidates), 2)
        self.assertEqual(candidates[0].kind, "document")
        self.assertEqual(
            candidates[0].url,
            "https://cdn.supplier.example/files/a-100-datasheet.pdf",
        )
        self.assertEqual(candidates[1].kind, "page")
        self.assertEqual(
            candidates[1].url,
            "https://supplier.example/products/a-100",
        )

    def test_extract_related_link_candidates_ignores_same_page_anchors_and_assets(self) -> None:
        html = """
        <html>
          <body>
            <a href="#top">Back to top</a>
            <a href="/assets/logo.svg">Logo</a>
            <a href="/downloads/a-100-manual.pdf">A-100 Manual</a>
          </body>
        </html>
        """

        candidates = _extract_related_link_candidates(
            html_content=html,
            base_url="https://supplier.example/family/a-100",
            page_title="A-100",
        )

        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0].label, "A-100 Manual")
        self.assertEqual(
            candidates[0].url,
            "https://supplier.example/downloads/a-100-manual.pdf",
        )

    def test_extract_related_link_candidates_includes_inline_product_images(self) -> None:
        html = """
        <html>
          <body>
            <h2>A-100</h2>
            <img src="/media/a-100-front.jpg" alt="A-100 front view" />
          </body>
        </html>
        """

        candidates = _extract_related_link_candidates(
            html_content=html,
            base_url="https://supplier.example/family/a-100",
            page_title="A-100",
        )

        image_candidates = [candidate for candidate in candidates if candidate.kind == "image"]
        self.assertEqual(len(image_candidates), 1)
        self.assertEqual(
            image_candidates[0].url,
            "https://supplier.example/media/a-100-front.jpg",
        )

    def test_extract_related_link_candidates_keeps_navigation_links_for_planner_review(self) -> None:
        html = """
        <html>
          <body>
            <div class="threebox">
              <a href="/products/motors/family-alpha-series.html" class="threenav">Family Alpha Series</a>
              <a href="/products/motors/family-beta-series.html" class="threenav">Family Beta Series</a>
            </div>
            <table>
              <tbody>
                <tr>
                  <td><a href="/product-detail/alpha-100.html">Alpha-100</a></td>
                  <td>24 V</td>
                </tr>
                <tr>
                  <td><a href="/product-detail/alpha-200.html">Alpha-200</a></td>
                  <td>48 V</td>
                </tr>
              </tbody>
            </table>
          </body>
        </html>
        """

        candidates = _extract_related_link_candidates(
            html_content=html,
            base_url="https://supplier.example/products/motors/family-alpha-series.html",
            page_title="Family Alpha Series",
        )

        page_urls = [candidate.url for candidate in candidates if candidate.kind == "page"]
        self.assertIn(
            "https://supplier.example/product-detail/alpha-100.html",
            page_urls,
        )
        self.assertIn(
            "https://supplier.example/product-detail/alpha-200.html",
            page_urls,
        )
        self.assertIn(
            "https://supplier.example/products/motors/family-beta-series.html",
            page_urls,
        )

    def test_collect_related_link_candidates_merges_rendered_model_links_with_static_links(self) -> None:
        static_html = """
        <html>
          <body>
            <div class="threebox">
              <a href="/products/motors/family-beta-series.html" class="threenav">Family Beta Series</a>
            </div>
          </body>
        </html>
        """
        rendered_html = """
        <html>
          <body>
            <div class="threebox">
              <a href="/products/motors/family-beta-series.html" class="threenav">Family Beta Series</a>
            </div>
            <table>
              <tbody>
                <tr><td><a href="/product-detail/alpha-100.html">Alpha-100</a></td></tr>
                <tr><td><a href="/product-detail/alpha-200.html">Alpha-200</a></td></tr>
              </tbody>
            </table>
          </body>
        </html>
        """

        candidates = _collect_related_link_candidates(
            html_contents=[static_html, rendered_html],
            base_url="https://supplier.example/products/motors/family-alpha-series.html",
            page_title="Family Alpha Series",
        )

        page_urls = [candidate.url for candidate in candidates if candidate.kind == "page"]
        self.assertIn(
            "https://supplier.example/product-detail/alpha-100.html",
            page_urls,
        )
        self.assertIn(
            "https://supplier.example/product-detail/alpha-200.html",
            page_urls,
        )
        self.assertIn(
            "https://supplier.example/products/motors/family-beta-series.html",
            page_urls,
        )

    def test_infer_filename_from_response_keeps_url_suffix_for_plain_link_label(self) -> None:
        response = SimpleNamespace(headers={})

        filename = _infer_filename_from_response(
            response=response,
            url="https://supplier.example/files/kannmotion.pdf",
            filename_hint="KannMotion Datasheet",
        )

        self.assertEqual(filename, "KannMotion Datasheet.pdf")

    def test_read_response_content_rejects_http_404_with_explicit_message(self) -> None:
        response = SimpleNamespace(
            status_code=404,
            reason_phrase="Not Found",
            url="https://supplier.example/files/missing.pdf",
            headers={},
            content=b"resource not found",
        )

        with self.assertRaisesRegex(
            IngestionSourceExtractionError,
            r"HTTP 404 Not Found.*missing\.pdf",
        ):
            _read_response_content(response)

    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_extractors_files._extract_pdf",
        return_value=ExtractedSourceContent(source_id=1, text="pdf"),
    )
    def test_extract_file_source_uses_original_filename_suffix_for_hashed_uploads(
        self, extract_pdf
    ) -> None:
        source = IngestionSource(
            id=1,
            source_type="file",
            filedata_id=42,
            mime_type="application/octet-stream",
            filename="linear-actuator_nema11.pdf",
        )

        result = extract_file_source(source, "/tmp/0123456789abcdef")

        self.assertEqual(result.text, "pdf")
        extract_pdf.assert_called_once()

    @patch(
        "koco_product_sqlmodel.fastapi.ai.ingestion_extractors_files._extract_pdf",
        return_value=ExtractedSourceContent(source_id=1, text="pdf"),
    )
    def test_extract_file_source_uses_pdf_mime_type_for_hashed_uploads(self, extract_pdf) -> None:
        source = IngestionSource(
            id=1,
            source_type="file",
            filedata_id=42,
            mime_type="application/pdf",
            filename="linear-actuator_nema11",
        )

        result = extract_file_source(source, "/tmp/0123456789abcdef")

        self.assertEqual(result.text, "pdf")
        extract_pdf.assert_called_once()

    def test_render_url_with_playwright_works_inside_running_event_loop(self) -> None:
        class FakePage:
            def __init__(self) -> None:
                self.routes = []

            async def route(self, pattern, handler) -> None:
                self.routes.append((pattern, handler))

            async def goto(self, url: str, wait_until: str, timeout: int) -> None:
                self.url = url
                self.wait_until = wait_until
                self.timeout = timeout

            async def wait_for_selector(self, selector: str, timeout: int) -> None:
                self.selector = selector
                self.selector_timeout = timeout

            async def wait_for_load_state(self, state: str, timeout: int) -> None:
                self.load_state = state
                self.load_state_timeout = timeout

            async def wait_for_timeout(self, timeout: int) -> None:
                self.settle_timeout = timeout

            async def content(self) -> str:
                return "<html><body>Rendered</body></html>"

            async def title(self) -> str:
                return "Rendered title"

        fake_page = FakePage()

        class FakeContext:
            async def new_page(self) -> FakePage:
                return fake_page

        class FakeBrowser:
            async def new_context(self, user_agent: str) -> FakeContext:
                self.user_agent = user_agent
                return FakeContext()

            async def close(self) -> None:
                return None

        class FakeChromium:
            async def launch(self, headless: bool, args: list[str]) -> FakeBrowser:
                self.headless = headless
                self.args = args
                return FakeBrowser()

        class FakePlaywrightContext:
            async def __aenter__(self):
                return SimpleNamespace(chromium=FakeChromium())

            async def __aexit__(self, exc_type, exc, tb) -> bool:
                return False

        fake_async_api = types.ModuleType("playwright.async_api")
        fake_async_api.async_playwright = lambda: FakePlaywrightContext()
        fake_playwright = types.ModuleType("playwright")
        fake_playwright.async_api = fake_async_api

        async def run_render() -> tuple[str, str | None]:
            return _render_url_with_playwright("https://supplier.example/family")

        with patch.dict(
            sys.modules,
            {
                "playwright": fake_playwright,
                "playwright.async_api": fake_async_api,
            },
        ):
            html_content, title = asyncio.run(run_render())

        self.assertEqual(html_content, "<html><body>Rendered</body></html>")
        self.assertEqual(title, "Rendered title")
        self.assertEqual(fake_page.wait_until, "domcontentloaded")
        self.assertEqual(fake_page.timeout, PLAYWRIGHT_NAVIGATION_TIMEOUT_MS)
        self.assertEqual(fake_page.selector, "body")
        self.assertEqual(fake_page.selector_timeout, PLAYWRIGHT_WAIT_FOR_BODY_TIMEOUT_MS)
        self.assertEqual(fake_page.load_state, "load")
        self.assertEqual(fake_page.load_state_timeout, PLAYWRIGHT_WAIT_FOR_LOAD_TIMEOUT_MS)
        self.assertEqual(fake_page.settle_timeout, PLAYWRIGHT_POST_LOAD_SETTLE_MS)
        self.assertEqual(fake_page.routes[0][0], "**/*")

    def test_render_url_with_playwright_falls_back_to_commit_navigation(self) -> None:
        class FakePage:
            def __init__(self) -> None:
                self.goto_calls = []

            async def route(self, pattern, handler) -> None:
                return None

            async def goto(self, url: str, wait_until: str, timeout: int) -> None:
                self.goto_calls.append((url, wait_until, timeout))
                if wait_until == "domcontentloaded":
                    raise RuntimeError("timeout")

            async def wait_for_selector(self, selector: str, timeout: int) -> None:
                return None

            async def wait_for_load_state(self, state: str, timeout: int) -> None:
                return None

            async def wait_for_timeout(self, timeout: int) -> None:
                return None

            async def content(self) -> str:
                return "<html><body>Rendered</body></html>"

            async def title(self) -> str:
                return "Rendered title"

        fake_page = FakePage()

        class FakeContext:
            async def new_page(self) -> FakePage:
                return fake_page

        class FakeBrowser:
            async def new_context(self, user_agent: str) -> FakeContext:
                return FakeContext()

            async def close(self) -> None:
                return None

        class FakeChromium:
            async def launch(self, headless: bool, args: list[str]) -> FakeBrowser:
                return FakeBrowser()

        class FakePlaywrightContext:
            async def __aenter__(self):
                return SimpleNamespace(chromium=FakeChromium())

            async def __aexit__(self, exc_type, exc, tb) -> bool:
                return False

        fake_async_api = types.ModuleType("playwright.async_api")
        fake_async_api.async_playwright = lambda: FakePlaywrightContext()
        fake_playwright = types.ModuleType("playwright")
        fake_playwright.async_api = fake_async_api

        with patch.dict(
            sys.modules,
            {
                "playwright": fake_playwright,
                "playwright.async_api": fake_async_api,
            },
        ):
            html_content, title = _render_url_with_playwright("https://supplier.example/family")

        self.assertEqual(html_content, "<html><body>Rendered</body></html>")
        self.assertEqual(title, "Rendered title")
        self.assertEqual(
            fake_page.goto_calls,
            [
                (
                    "https://supplier.example/family",
                    "domcontentloaded",
                    PLAYWRIGHT_NAVIGATION_TIMEOUT_MS,
                ),
                (
                    "https://supplier.example/family",
                    "commit",
                    PLAYWRIGHT_COMMIT_TIMEOUT_MS,
                ),
            ],
        )


if __name__ == "__main__":
    unittest.main()
