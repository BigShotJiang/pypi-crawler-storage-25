import datetime as dt
import os
import sys
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
os.environ.setdefault("FASTAPI_SECURITY_SECRET_KEY", "test-secret")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from koco_product_sqlmodel.fastapi.ai.ingestion_models import (  # noqa: E402
    IngestionEvent,
    IngestionSource,
    IngestionWarning,
)
from koco_product_sqlmodel.fastapi.ai.ingestion_repository import (  # noqa: E402
    IngestionJobRepository,
    MAX_EVENTS_JSON_CHARS,
    MAX_STORED_EVENTS,
)
from koco_product_sqlmodel.dbmodels.aiingestionjob import CAIIngestionJob  # noqa: E402
from koco_product_sqlmodel.dbmodels.backgroundjob import CBackgroundJob  # noqa: E402


class IngestionRepositoryTests(unittest.TestCase):
    @contextmanager
    def _patch_existing_job_tables(self, repository, legacy_count: int):
        class Inspector:
            def has_table(self, table_name: str) -> bool:
                return table_name in {
                    CAIIngestionJob.__tablename__,
                    CBackgroundJob.__tablename__,
                }

        with (
            patch(
                "koco_product_sqlmodel.fastapi.ai.ingestion_repository.sa_inspect",
                return_value=Inspector(),
            ),
            patch.object(repository, "_count_rows", return_value=legacy_count),
        ):
            yield

    def test_to_job_reads_background_job_json_payloads(self) -> None:
        repository = IngestionJobRepository()
        timestamp = dt.datetime(2026, 4, 13, tzinfo=dt.timezone.utc)
        source = IngestionSource(id=1, source_type="url", url="https://example.test")
        warning = IngestionWarning(code="sample", message="Sample warning")
        record = CBackgroundJob(
            id=99,
            job_type="ai_ingestion",
            entity_id=123,
            entity_type="family",
            status="running",
            phase="extracting.1",
            state_json={"sources": [source.model_dump(mode="json")]},
            events_json=[],
            warnings_json=[warning.model_dump(mode="json")],
            insdate=timestamp,
            upddate=timestamp,
        )

        job = repository._to_job(record)

        self.assertEqual(job.id, 99)
        self.assertEqual(job.entity_id, 123)
        self.assertEqual(job.sources, [source])
        self.assertEqual(job.warnings, [warning])

    def test_use_legacy_table_prefers_background_when_both_tables_are_empty(
        self,
    ) -> None:
        repository = IngestionJobRepository()

        with self._patch_existing_job_tables(repository, legacy_count=0):
            self.assertFalse(repository._use_legacy_table())

    def test_use_legacy_table_keeps_legacy_when_rows_still_need_migration(
        self,
    ) -> None:
        repository = IngestionJobRepository()

        with self._patch_existing_job_tables(repository, legacy_count=1):
            self.assertTrue(repository._use_legacy_table())

    def test_trim_events_caps_count_and_payload_size(self) -> None:
        repository = IngestionJobRepository()
        base_timestamp = dt.datetime(2026, 4, 13, tzinfo=dt.timezone.utc)
        events = [
            IngestionEvent(
                job_id=1,
                sequence=index,
                timestamp=base_timestamp,
                type="source.progress",
                message=f"event {index}",
                meta={"payload": "x" * 1_000},
            )
            for index in range(1, MAX_STORED_EVENTS + 50)
        ]

        trimmed = repository._trim_events(events)
        payload = repository._dump_events_text(trimmed)

        self.assertLessEqual(len(trimmed), MAX_STORED_EVENTS)
        self.assertLessEqual(len(payload), MAX_EVENTS_JSON_CHARS)
        self.assertEqual(trimmed[-1].sequence, events[-1].sequence)
