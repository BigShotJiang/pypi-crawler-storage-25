import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from fastapi import FastAPI
from fastapi.testclient import TestClient


os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
os.environ.setdefault("FASTAPI_SECURITY_SECRET_KEY", "test-secret")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from koco_product_sqlmodel.fastapi.ai.ingestion_models import IngestionJob  # noqa: E402
from koco_product_sqlmodel.fastapi.routes import ai as ai_routes  # noqa: E402
from koco_product_sqlmodel.fastapi.routes import security as sec  # noqa: E402


class AIRoutesTests(unittest.TestCase):
    def setUp(self) -> None:
        self.app = FastAPI()
        self.app.include_router(ai_routes.router)
        self.app.dependency_overrides[sec.get_current_active_user] = (
            lambda: SimpleNamespace(id=1, role_id=1)
        )
        self.app.dependency_overrides[sec.has_post_rights] = (
            lambda: SimpleNamespace(id=1, role_id=1)
        )
        self.client = TestClient(self.app)

    def tearDown(self) -> None:
        self.app.dependency_overrides.clear()

    def test_create_ingestion_job_rejects_invalid_payload_with_422(self) -> None:
        response = self.client.post("/ingestions", json={"entity_id": 0})

        self.assertEqual(response.status_code, 422)

    @patch(
        "koco_product_sqlmodel.fastapi.routes.ai.sec.get_user_id_from_request",
        new_callable=AsyncMock,
    )
    @patch("koco_product_sqlmodel.fastapi.routes.ai.IngestionService.create_job")
    def test_create_ingestion_job_passes_user_id(
        self,
        create_job,
        get_user_id_from_request,
    ) -> None:
        get_user_id_from_request.return_value = 7
        create_job.return_value = IngestionJob(
            id=12,
            entity_id=3,
            entity_type="family",
            status="pending",
            phase="queued",
        )

        response = self.client.post(
            "/ingestions",
            json={
                "entity_id": 3,
                "entity_type": "family",
                "urls": ["https://supplier.example"],
                "filedata_ids": [9],
            },
        )

        self.assertEqual(response.status_code, 200)
        create_job.assert_called_once()
        _, kwargs = create_job.call_args
        self.assertEqual(kwargs["user_id"], 7)
        self.assertEqual(kwargs["payload"].entity_id, 3)
        self.assertEqual(kwargs["payload"].entity_type, "family")
        self.assertEqual(kwargs["payload"].urls, ["https://supplier.example"])
        self.assertEqual(kwargs["payload"].filedata_ids, [9])
        self.assertEqual(response.json()["entity_id"], 3)
        self.assertEqual(response.json()["entity_type"], "family")


if __name__ == "__main__":
    unittest.main()
