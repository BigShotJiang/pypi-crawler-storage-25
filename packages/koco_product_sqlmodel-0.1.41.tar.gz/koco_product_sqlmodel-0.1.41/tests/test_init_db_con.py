import importlib
import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


class InitDbConTests(unittest.TestCase):
    def test_get_database_url_prefers_legacy_env_var(self) -> None:
        with patch.dict(
            os.environ,
            {
                "MARIADB_CONNECTOR_STRING": "sqlite:///legacy.db",
                "DATABASE_URL": "sqlite://",
            },
            clear=False,
        ):
            import koco_product_sqlmodel.mdb_connect.init_db_con as init_db_con

            init_db_con = importlib.reload(init_db_con)

            self.assertEqual(init_db_con.get_database_url(), "sqlite:///legacy.db")

    def test_get_database_url_falls_back_to_generic_env_var(self) -> None:
        with patch.dict(
            os.environ,
            {
                "MARIADB_CONNECTOR_STRING": "",
                "DATABASE_URL": "sqlite://",
            },
            clear=False,
        ):
            import koco_product_sqlmodel.mdb_connect.init_db_con as init_db_con

            init_db_con = importlib.reload(init_db_con)

            self.assertEqual(init_db_con.get_database_url(), "sqlite://")

    def test_get_database_url_raises_when_not_configured(self) -> None:
        with patch.dict(
            os.environ,
            {
                "MARIADB_CONNECTOR_STRING": "",
                "DATABASE_URL": "",
            },
            clear=False,
        ):

            import koco_product_sqlmodel.mdb_connect.init_db_con as init_db_con

            with self.assertRaisesRegex(
                RuntimeError,
                "MARIADB_CONNECTOR_STRING, DATABASE_URL",
            ):
                init_db_con.get_database_url()


if __name__ == "__main__":
    unittest.main()
