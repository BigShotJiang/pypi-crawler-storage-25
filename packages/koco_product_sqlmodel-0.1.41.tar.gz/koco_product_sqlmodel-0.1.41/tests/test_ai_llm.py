import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

from pydantic import BaseModel


os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
os.environ.setdefault("FASTAPI_SECURITY_SECRET_KEY", "test-secret")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from koco_product_sqlmodel.fastapi.ai.llm import LLMStreamer  # noqa: E402


class StructuredResponse(BaseModel):
    title: str
    score: int


class StructuredChild(BaseModel):
    manufacturer: str


class StructuredNestedResponse(BaseModel):
    title: str
    details: StructuredChild


class LLMStreamerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.streamer = LLMStreamer.__new__(LLMStreamer)

    def test_extract_response_content_rejects_empty_choices(self) -> None:
        response = SimpleNamespace(choices=[])

        with self.assertRaisesRegex(ValueError, "LLM returned no choices"):
            self.streamer._extract_response_content(response)

    def test_extract_response_content_rejects_empty_message(self) -> None:
        response = SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=None), finish_reason="stop")]
        )

        with self.assertRaisesRegex(ValueError, "LLM returned empty content"):
            self.streamer._extract_response_content(response)

    def test_extract_stream_delta_handles_empty_choices(self) -> None:
        chunk = SimpleNamespace(choices=[])

        self.assertEqual(self.streamer._extract_stream_delta(chunk), "")

    def test_extract_response_content_collects_list_parts(self) -> None:
        response = SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(
                        content=[
                            {"type": "output_text", "text": '{"title": '},
                            SimpleNamespace(text='"Motor", "score": 7}'),
                        ]
                    ),
                    finish_reason="stop",
                )
            ]
        )

        self.assertEqual(
            self.streamer._extract_response_content(response),
            '{"title": "Motor", "score": 7}',
        )

    def test_extract_response_content_rejects_list_without_text_parts(self) -> None:
        response = SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content=[{"type": "output_image"}]),
                    finish_reason="stop",
                )
            ]
        )

        with self.assertRaisesRegex(ValueError, "LLM returned empty content"):
            self.streamer._extract_response_content(response)

    def test_generate_json_field_retries_empty_string(self) -> None:
        responses = iter(
            [
                SimpleNamespace(
                    choices=[SimpleNamespace(message=SimpleNamespace(content='{"type": ""}'))]
                ),
                SimpleNamespace(
                    choices=[
                        SimpleNamespace(
                            message=SimpleNamespace(content='{"type": "Integrated drive"}')
                        )
                    ]
                ),
            ]
        )
        self.streamer.settings = SimpleNamespace(
            default_model="gpt-test",
            temperature=0.2,
            max_tokens=200,
        )
        self.streamer.client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=lambda **kwargs: next(responses))
            )
        )

        value = self.streamer.generate_json_field(
            system_prompt="system",
            user_prompt="user",
            expected_field="type",
        )

        self.assertEqual(value, "Integrated drive")

    def test_generate_structured_uses_json_schema_response_format(self) -> None:
        captured_kwargs: dict[str, object] = {}

        def fake_create(**kwargs):
            captured_kwargs.update(kwargs)
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(content='{"title": "Motor", "score": 7}')
                    )
                ]
            )

        self.streamer.settings = SimpleNamespace(
            default_model="gpt-test",
            temperature=0.2,
            max_tokens=200,
        )
        self.streamer.client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=fake_create))
        )

        result = self.streamer.generate_structured(
            system_prompt="system",
            user_prompt="user",
            response_model=StructuredResponse,
            schema_name="structured_response",
        )

        self.assertEqual(result, StructuredResponse(title="Motor", score=7))
        self.assertEqual(captured_kwargs["response_format"]["type"], "json_schema")
        self.assertEqual(
            captured_kwargs["response_format"]["json_schema"]["name"],
            "structured_response",
        )
        self.assertTrue(
            captured_kwargs["response_format"]["json_schema"]["strict"]
        )

    def test_generate_structured_closes_all_object_schemas(self) -> None:
        captured_kwargs: dict[str, object] = {}

        def fake_create(**kwargs):
            captured_kwargs.update(kwargs)
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(
                            content=(
                                '{"title": "Motor", "details": {"manufacturer": "KOCO"}}'
                            )
                        )
                    )
                ]
            )

        self.streamer.settings = SimpleNamespace(
            default_model="gpt-test",
            temperature=0.2,
            max_tokens=200,
        )
        self.streamer.client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=fake_create))
        )

        result = self.streamer.generate_structured(
            system_prompt="system",
            user_prompt="user",
            response_model=StructuredNestedResponse,
            schema_name="structured_nested_response",
        )

        self.assertEqual(
            result,
            StructuredNestedResponse(
                title="Motor", details=StructuredChild(manufacturer="KOCO")
            ),
        )

        schema = captured_kwargs["response_format"]["json_schema"]["schema"]

        def assert_closed_objects(node: object) -> None:
            if isinstance(node, dict):
                if node.get("type") == "object":
                    self.assertIn("additionalProperties", node)
                    self.assertFalse(node["additionalProperties"])
                    self.assertIn("required", node)
                for value in node.values():
                    assert_closed_objects(value)
            elif isinstance(node, list):
                for item in node:
                    assert_closed_objects(item)

        assert_closed_objects(schema)

    def test_generate_structured_retries_invalid_json(self) -> None:
        captured_kwargs: list[dict[str, object]] = []
        responses = iter(
            [
                SimpleNamespace(
                    choices=[
                        SimpleNamespace(
                            message=SimpleNamespace(content='{"title": "Motor"'),
                            finish_reason="length",
                        )
                    ]
                ),
                SimpleNamespace(
                    choices=[
                        SimpleNamespace(
                            message=SimpleNamespace(content='{"title": "Motor", "score": 7}'),
                            finish_reason="stop",
                        )
                    ]
                ),
            ]
        )

        def fake_create(**kwargs):
            captured_kwargs.append(kwargs)
            return next(responses)

        self.streamer.settings = SimpleNamespace(
            default_model="gpt-test",
            temperature=0.7,
            max_tokens=200,
        )
        self.streamer.client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=fake_create))
        )

        result = self.streamer.generate_structured(
            system_prompt="system",
            user_prompt="user",
            response_model=StructuredResponse,
            schema_name="structured_response",
            max_tokens=300,
        )

        self.assertEqual(result, StructuredResponse(title="Motor", score=7))
        self.assertEqual(len(captured_kwargs), 2)
        self.assertEqual(captured_kwargs[0]["temperature"], 0)
        self.assertEqual(captured_kwargs[0]["max_tokens"], 300)
        self.assertEqual(captured_kwargs[1]["max_tokens"], 1050)

    def test_generate_structured_retries_when_length_returns_empty_content(self) -> None:
        captured_kwargs: list[dict[str, object]] = []
        responses = iter(
            [
                SimpleNamespace(
                    choices=[
                        SimpleNamespace(
                            message=SimpleNamespace(content=None),
                            finish_reason="length",
                        )
                    ]
                ),
                SimpleNamespace(
                    choices=[
                        SimpleNamespace(
                            message=SimpleNamespace(content='{"title": "Motor", "score": 7}'),
                            finish_reason="stop",
                        )
                    ]
                ),
            ]
        )

        def fake_create(**kwargs):
            captured_kwargs.append(kwargs)
            return next(responses)

        self.streamer.settings = SimpleNamespace(
            default_model="gpt-5.4",
            temperature=0.2,
            max_tokens=200,
        )
        self.streamer.client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=fake_create))
        )

        result = self.streamer.generate_structured(
            system_prompt="system",
            user_prompt="user",
            response_model=StructuredResponse,
            schema_name="structured_response",
            max_tokens=300,
        )

        self.assertEqual(result, StructuredResponse(title="Motor", score=7))
        self.assertEqual(len(captured_kwargs), 2)
        self.assertEqual(captured_kwargs[0]["max_completion_tokens"], 300)
        self.assertEqual(captured_kwargs[1]["max_completion_tokens"], 1050)

    def test_generate_structured_uses_max_completion_tokens_for_gpt_5_models(self) -> None:
        captured_kwargs: dict[str, object] = {}

        def fake_create(**kwargs):
            captured_kwargs.update(kwargs)
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(content='{"title": "Motor", "score": 7}')
                    )
                ]
            )

        self.streamer.settings = SimpleNamespace(
            default_model="gpt-5.4",
            temperature=0.2,
            max_tokens=200,
        )
        self.streamer.client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=fake_create))
        )

        result = self.streamer.generate_structured(
            system_prompt="system",
            user_prompt="user",
            response_model=StructuredResponse,
            schema_name="structured_response",
            max_tokens=300,
        )

        self.assertEqual(result, StructuredResponse(title="Motor", score=7))
        self.assertEqual(captured_kwargs["max_completion_tokens"], 300)
        self.assertNotIn("max_tokens", captured_kwargs)

    def test_generate_structured_honors_large_initial_token_budget(self) -> None:
        captured_kwargs: dict[str, object] = {}

        def fake_create(**kwargs):
            captured_kwargs.update(kwargs)
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(content='{"title": "Motor", "score": 7}')
                    )
                ]
            )

        self.streamer.settings = SimpleNamespace(
            default_model="gpt-5.4",
            temperature=0.2,
            max_tokens=200,
        )
        self.streamer.client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=fake_create))
        )

        result = self.streamer.generate_structured(
            system_prompt="system",
            user_prompt="user",
            response_model=StructuredResponse,
            schema_name="structured_response",
            max_tokens=12_000,
        )

        self.assertEqual(result, StructuredResponse(title="Motor", score=7))
        self.assertEqual(captured_kwargs["max_completion_tokens"], 12_000)

    def test_generate_structured_retries_with_alternate_token_parameter(self) -> None:
        captured_kwargs: list[dict[str, object]] = []

        class UnsupportedParameterError(Exception):
            def __init__(self) -> None:
                super().__init__(
                    "Error code: 400 - {'error': {'message': \"Unsupported parameter: 'max_tokens' is not supported with this model. Use 'max_completion_tokens' instead.\", 'type': 'invalid_request_error', 'param': 'max_tokens', 'code': 'unsupported_parameter'}}"
                )
                self.body = {
                    "error": {
                        "message": "Unsupported parameter: 'max_tokens' is not supported with this model. Use 'max_completion_tokens' instead.",
                        "type": "invalid_request_error",
                        "param": "max_tokens",
                        "code": "unsupported_parameter",
                    }
                }

        def fake_create(**kwargs):
            captured_kwargs.append(kwargs)
            if len(captured_kwargs) == 1:
                raise UnsupportedParameterError()
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(content='{"title": "Motor", "score": 7}')
                    )
                ]
            )

        self.streamer.settings = SimpleNamespace(
            default_model="custom-azure-deployment",
            temperature=0.2,
            max_tokens=200,
        )
        self.streamer.client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=fake_create))
        )

        result = self.streamer.generate_structured(
            system_prompt="system",
            user_prompt="user",
            response_model=StructuredResponse,
            schema_name="structured_response",
            max_tokens=300,
        )

        self.assertEqual(result, StructuredResponse(title="Motor", score=7))
        self.assertEqual(captured_kwargs[0]["max_tokens"], 300)
        self.assertNotIn("max_completion_tokens", captured_kwargs[0])
        self.assertEqual(captured_kwargs[1]["max_completion_tokens"], 300)
        self.assertNotIn("max_tokens", captured_kwargs[1])


if __name__ == "__main__":
    unittest.main()
