import os
import sys
import unittest
from pathlib import Path


os.environ.setdefault("MARIADB_CONNECTOR_STRING", "sqlite://")
os.environ.setdefault("FASTAPI_SECURITY_SECRET_KEY", "test-secret")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from koco_product_sqlmodel.fastapi.ai.context_builder import DescriptionContextBuilder  # noqa: E402
from koco_product_sqlmodel.fastapi.ai.service import DescriptionGenerationService  # noqa: E402


class FakeLLMStreamer:
    def __init__(self, *, type_value: str, short_value: str, description_chunks: list[str]):
        self.type_value = type_value
        self.short_value = short_value
        self.description_chunks = description_chunks

    def generate_json_field(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        expected_field: str,
        max_tokens: int | None = None,
    ) -> str:
        if expected_field == "type":
            return self.type_value
        if expected_field == "short_description":
            return self.short_value
        raise AssertionError(f"Unexpected field '{expected_field}'")

    def stream_text(
        self, *, system_prompt: str, user_prompt: str, max_tokens: int | None = None
    ):
        collected: list[str] = []
        for chunk in self.description_chunks:
            collected.append(chunk)
            yield chunk
        return "".join(collected)


class BrokenLLMStreamer(FakeLLMStreamer):
    def __init__(self) -> None:
        super().__init__(type_value="", short_value="", description_chunks=[])

    def generate_json_field(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        expected_field: str,
        max_tokens: int | None = None,
    ) -> str:
        raise RuntimeError("LLM unavailable")


def build_context_builder() -> DescriptionContextBuilder:
    return DescriptionContextBuilder(
        family_fetcher=lambda family_id: {
            "id": family_id,
            "family": "Servo Press",
            "type": "Press",
            "short_description": "",
            "description": "",
            "product_group_id": 2,
            "status": 2,
        },
        article_fetcher=lambda article_id: {
            "id": article_id,
            "article": "SP-100",
            "family_id": 4,
            "short_description": "",
            "description": "",
            "order_priority": 100,
            "status": 2,
        },
        family_articles_fetcher=lambda family_id: [
            {
                "id": 8,
                "article": "SP-100",
                "family_id": family_id,
                "short_description": "",
                "description": "",
                "order_priority": 100,
                "status": 2,
            }
        ],
        applications_fetcher=lambda family_id: [{"application": "Joining"}],
        options_fetcher=lambda family_id: [
            {"type": "Features", "category": "Drive", "option": "Servo drive"}
        ],
        spectables_fetcher=lambda parent, parent_id: [
            {
                "id": 12,
                "name": "Overview",
                "type": "overview",
                "parent": parent,
                "parent_id": parent_id,
                "has_unit": True,
                "description_json": "",
                "spectableitems": [
                    {
                        "pos": "1",
                        "name": "Force",
                        "value": "10",
                        "min_value": "",
                        "max_value": "",
                        "unit": "kN",
                    }
                ],
            }
        ],
    )


class DescriptionGenerationServiceTests(unittest.TestCase):
    def test_streams_events_in_expected_order(self) -> None:
        service = DescriptionGenerationService(
            llm_streamer=FakeLLMStreamer(
                type_value="Servo press",
                short_value="Compact servo press for precision joining applications.",
                description_chunks=["<p>Compact", " servo press</p>"],
            ),
            context_builder=build_context_builder(),
        )

        events = list(
            service.stream_run(
                entity_type="family",
                entity_id=4,
                fields=["type", "short_description", "description"],
            )
        )

        self.assertEqual(events[0]["type"], "step.started")
        self.assertEqual(events[0]["step"], "fetch.family")
        self.assertEqual(events[-1]["type"], "run.completed")
        delta_events = [event for event in events if event["type"] == "field.delta"]
        self.assertEqual(len(delta_events), 2)
        self.assertTrue(all(event["field"] == "description" for event in delta_events))
        self.assertEqual(events[-1]["result"]["type"], "Servo press")
        self.assertEqual(
            events[-1]["result"]["description"], "<p>Compact servo press</p>"
        )

    def test_enforces_field_limits_before_completion(self) -> None:
        service = DescriptionGenerationService(
            llm_streamer=FakeLLMStreamer(
                type_value="T" * 1100,
                short_value="S" * 1100,
                description_chunks=["D" * 5000],
            ),
            context_builder=build_context_builder(),
        )

        events = list(
            service.stream_run(
                entity_type="family",
                entity_id=4,
                fields=["type", "short_description", "description"],
            )
        )

        self.assertEqual(events[-1]["type"], "run.failed")
        self.assertIn("exceeds limit", events[-1]["message"])

    def test_emits_run_failed_on_generation_error(self) -> None:
        service = DescriptionGenerationService(
            llm_streamer=BrokenLLMStreamer(),
            context_builder=build_context_builder(),
        )

        events = list(
            service.stream_run(entity_type="family", entity_id=4, fields=["type"])
        )

        self.assertEqual(events[-1]["type"], "run.failed")
        self.assertIn("LLM unavailable", events[-1]["message"])


if __name__ == "__main__":
    unittest.main()
