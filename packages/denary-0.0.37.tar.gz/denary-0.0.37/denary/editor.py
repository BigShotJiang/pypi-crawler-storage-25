#     ,gggggggggggg,
#    dP"""88""""""Y8b,
#    Yb,  88       `8b,
#     `"  88        `8b
#         88         Y8
#         88         d8  ,ggg,    ,ggg,,ggg,     ,gggg,gg   ,gggggg,  gg     gg
#         88        ,8P i8" "8i  ,8" "8P" "8,   dP"  "Y8I   dP""""8I  I8     8I
#         88       ,8P' I8, ,8I  I8   8I   8I  i8'    ,8I  ,8'    8I  I8,   ,8I
#         88______,dP'  `YbadP' ,dP   8I   Yb,,d8,   ,d8b,,dP     Y8,,d8b, ,d8I
#        888888888P"   888P"Y8888P'   8I   `Y8P"Y8888P"`Y88P      `Y8P""Y88P"888
#                                                                          ,d8I'
#                                                                        ,dP'8I
#                                                                       ,8"  8I
#                                                                       I8   8I
#                                                                       `8, ,8I
#                                                                        `Y8P"

"""
A modal terminal editor built on curses with a command-driven,
event-based architecture and chunked text storage.

Includes syntax highlighting, multi-buffer management,
registers and markers, undo/redo history, Git integration,
async LSP support, subprocess execution, and HTTP requests.
"""

from __future__ import annotations

import asyncio
import curses
import itertools
import json
import os
import re
import shutil
import string
import subprocess
import sys
import textwrap
import time
import traceback
from collections import defaultdict, deque
from functools import lru_cache
from io import BytesIO, StringIO
from pathlib import Path
from queue import Queue
from typing import (
    Any,
    Awaitable,
    Callable,
    NamedTuple,
    Optional,
    Sequence,
    cast,
)
from urllib.parse import urlparse

from pygments.lexers import (
    MarkdownLexer,
    TextLexer,
    get_lexer_by_name,
    guess_lexer,
)

from denary import (  # prompts,
    buf_actions,
    commands,
    config,
    diagnostics,
    events,
    file_discovery,
    git_utils,
    gutters,
    http_request,
    key_bindings,
    key_mappings,
    notifications,
    renderer,
    session,
    subprocess_task,
    themes,
    windows,
)
from denary.ai import completions
from denary.buf import (
    Buffer,
    BufferAction,
    BufferActionTypeEnum,
    CursorPosition,
    RichString,
    get_lsp,
    get_uri_from_name,
    load_lsp,
)
from denary.chunked_lines import ChunkedLines
from denary.config import CURRENT_PLATFORM, save_static_config
from denary.displays import PickerWindow
from denary.events import Event, EventType
from denary.file_viewer import LessWindow
from denary.fzf_search import fzf_fuzzy_find
from denary.horizontal_scrolling import get_offsets, line_x, visual_x, wcwidth
from denary.lsp.events import handle_lsp_event
from denary.replacements import expand_replacement
from denary.syntax import hilighing
from denary.syntax.hilighing import (
    get_suffix_from_lexer,
)


class Jump(NamedTuple):
    buffer_name: str
    position: CursorPosition
    timestamp: float


def _run_code(code: str, queue: Queue) -> None:
    import contextlib
    import io

    buf = io.StringIO()

    with contextlib.redirect_stdout(buf):
        try:
            result = eval(code)
        except SyntaxError:
            exec(code)
            result = None

    queue.put((result, buf.getvalue()))


@lru_cache(maxsize=1)
def check_is_wsl() -> bool:
    is_wsl = False
    if sys.platform.startswith("linux"):
        try:
            with open("/proc/version", "r") as f:
                is_wsl = "microsoft" in f.read().lower()
        except Exception:
            pass

    return is_wsl


@lru_cache(maxsize=1)
def check_is_ssh() -> bool:
    return any(k in os.environ for k in ("SSH_CONNECTION", "SSH_CLIENT", "SSH_TTY"))


@lru_cache(maxsize=1)
def get_version() -> str:
    from importlib.metadata import PackageNotFoundError, version

    try:
        _version = f"denary {version('denary')}"
    except PackageNotFoundError:
        _version = "denary (development version)"

    return _version


class SimpleEditor:
    """
    Core editor class handling buffer storage, rendering, and input.
    """

    tg: Optional[asyncio.TaskGroup] = None

    def __init__(
        self,
        stdscr: curses.window,
        file_names: list[str],
        theme: str,
        debug: bool = False,
        temp_dir: str | None = None,
        without_session: bool = False,
        as_text: bool = False,
    ) -> None:
        self.stdscr = stdscr
        self.debug = debug
        self.without_session = without_session
        self.as_text = as_text
        self.temp_dir = temp_dir
        self.disable_record_jump = False

        self.gutter_render: Optional[
            Callable[[curses.window, int, int, Buffer, Optional[int]], int]
        ] = None

        self.buffers: list[Buffer] = []
        self.new_buffer_count = 0
        self.global_markers = {}

        self.fuzzy_search = []
        self.command_history = []
        self.search_history = []
        self.eval_history = []

        self.task_running: list[dict[str, Any]] = []

        self.working_dir = Path(".")
        self.working_dir_mtime = self.get_working_dir_mtime()
        self.color_support = curses.COLORS >= 256

        self.macros: dict[str, list[int | str]] = {}
        self.recording_macro: bool = False
        self.current_macro_recording: Optional[str] = None
        self.current_macro_playing_name: Optional[str] = None
        self.current_macro_playing_index: Optional[int] = None

        self.redraw_event = asyncio.Event()
        self._last_redraw = 0.00

        self.ai_completion_manager = completions.CompletionManager()

        self.window_manager = windows.WindowManager(self.stdscr)

        self.jump_list: list[Jump] = []
        self.last_jump: Optional[Jump] = None
        self.jump_index: int = 0

        self.current_buffer_session = 0
        self.current_session_layout: session.LayoutNodeSession | None = None

        session_path = Path("editor_session.json")
        session_exists = session_path.exists()

        if session_exists and not self.without_session:
            try:
                with open(session_path, "r") as f:
                    session_data = json.load(f)

                self.global_markers = session_data.get("global_markers", {})

                session_mtime = session_data.get("working_dir_mtime", -1)

                if session_mtime >= self.working_dir_mtime:
                    self.fuzzy_search = session_data.get("fuzzy_search", [])

                self.search_history = session_data.get("search_history", [])

                self.command_history = session_data.get("command_history", [])

                self.eval_history = session_data.get("eval_history", [])

                self.current_session_layout = session_data.get("layout", None)

            except Exception:
                session_data = None
                pass

        base_lexer = None

        if self.as_text:
            base_lexer = TextLexer()

        if session_exists and not self.without_session and session_data is not None:
            try:
                error_log = []

                for buf in session_data["buffers"]:
                    try:

                        if not Path(buf["file_name"]).exists():
                            continue

                        new_buffer = Buffer(buf["file_name"], temp_dir=self.temp_dir)

                        new_buffer._cursor_y = buf["cursor_y"]
                        new_buffer._cursor_x = buf["cursor_x"]
                        new_buffer._scroll = buf["scroll"]
                        new_buffer._h_scroll = buf["h_scroll"]

                        new_buffer.markers = buf.get("markers", {})

                        new_buffer.lexer = base_lexer

                        self.buffers.append(new_buffer)

                    except FileNotFoundError:
                        error_log.append(f"Error loading buffer '{buf['file_name']}'")

                current_buffer_index = 0

                for i, buf in enumerate(self.buffers):
                    if buf.file_name == session_data["current_buffer_name"]:
                        current_buffer_index = i
                        break

                self.set_current_buffer(current_buffer_index)

                if error_log:
                    self.send_multiline_notification("\n".join(error_log), 5000)

            except json.JSONDecodeError:
                self.send_notification("Error loading session data. Starting fresh.")

                self.buffers.clear()
                self.buffers.append(Buffer(temp_dir=self.temp_dir))

        if file_names:
            stdin_read = False

            for file in file_names:
                res = file.split(":")

                if len(res) == 4:
                    file_name, _line, _col, message = res
                    file = file_name.strip()
                    line = int(_line.strip())
                    col = int(_col.strip())

                elif len(res) == 3:
                    file_name, _line, _col = res
                    file = file_name.strip()
                    line = int(_line.strip())
                    col = int(_col.strip())
                    message = ""
                elif len(res) == 2:
                    file_name, _line = res
                    file = file_name.strip()
                    line = int(_line.strip())
                    col = 1
                    message = ""
                else:
                    file = res[0].strip()
                    line = 1
                    col = 1
                    message = ""

                is_stdin = file == "-"

                if is_stdin and stdin_read:
                    continue

                if (
                    not is_stdin
                    and (buffer_index := self.get_buffer_by_file_name(file_name=file))
                    != -1
                ):
                    new_buffer = self.buffers[buffer_index]
                    self.set_current_buffer(buffer_index)
                else:
                    if is_stdin:
                        self.new_buffer_count += 1
                        file = f"Untitled-{self.new_buffer_count}"

                    new_buffer = Buffer(
                        file,
                        temp_dir=self.temp_dir,
                        new_buffer_untitled=is_stdin,
                        lexer=base_lexer,
                    )

                    self.buffers.append(new_buffer)
                    self.set_current_buffer(len(self.buffers) - 1)

                if len(res) >= 2:
                    new_buffer._cursor_y = line - 1
                    new_buffer._cursor_x = col - 1
                    new_buffer._last_cursor_x = new_buffer._cursor_x

                if message:
                    new_buffer.diagnostics.append(
                        diagnostics.Diagnostic(
                            line=new_buffer._cursor_y,
                            char=new_buffer._cursor_x,
                            code="E",
                            message=message,
                            severity=1,
                        )
                    )

                if is_stdin:
                    new_buffer.load()
                    new_buffer.first = False

                    stdin = sys.stdin.buffer.read().decode()
                    os.dup2(
                        os.open(
                            (
                                "CONIN$"
                                if CURRENT_PLATFORM.startswith("win")
                                else "/dev/tty"
                            ),
                            os.O_RDONLY,
                        ),
                        sys.stdin.fileno(),
                    )
                    stdin_read = True

                    stdin = stdin.replace("\r\n", "\n").replace("\r", "\n")
                    stdin = stdin.replace("\x00", "�")

                    new_buffer.lines = ChunkedLines(
                        [RichString(line) for line in stdin.splitlines()]
                    )

        if len(self.buffers) == 0:
            self.open_untitled_buffer(
                text='''\
 ,gggggggggggg,
dP"""88""""""Y8b,
Yb,  88       `8b,
 `"  88        `8b
     88         Y8
     88         d8  ,ggg,    ,ggg,,ggg,     ,gggg,gg   ,gggggg,  gg     gg
     88        ,8P i8" "8i  ,8" "8P" "8,   dP"  "Y8I   dP""""8I  I8     8I
     88       ,8P' I8, ,8I  I8   8I   8I  i8'    ,8I  ,8'    8I  I8,   ,8I
     88______,dP'  `YbadP' ,dP   8I   Yb,,d8,   ,d8b,,dP     Y8,,d8b, ,d8I
    888888888P"   888P"Y8888P'   8I   `Y8P"Y8888P"`Y88P      `Y8P""Y88P"888
                                                                      ,d8I'
                                                                    ,dP'8I
                                                                   ,8"  8I
                                                                   I8   8I
                                                                   `8, ,8I
                                                                    `Y8P"
''' + ("\n" * (50 - 16)),
                lexer=TextLexer(),
            )
            # self.buffers.append(Buffer(temp_dir=self.temp_dir))

        self.last_buffer = 0

        self.clipboard: list[str] = []

        self.registers: dict[str, list[str]] = {}
        self.copy_history: deque[list[str]] = deque(maxlen=10)

        self.last_search: str | None = None
        self.last_search_re: re.Pattern | None = None

        self.mouse_button_down = False
        self.mouse_x = -1
        self.mouse_y = -1
        self.last_mouse_click = 0.0

        self.disable_search = True

        self.fuzzy_changed = False  # to know if you need to refresh the fuzzy

        self.current_branch = "--"

        self.mode = "NORMAL"

        config.load_static_config()

        if theme == "current":
            theme = config.STATIC_CONFIG.get("current_theme", "default")

        config.STATIC_CONFIG["current_theme"] = theme

    @property
    def selection_start(self) -> tuple[int, int] | None:
        window = self.window_manager.last_base_focused

        if (window := self.window_manager.last_base_focused) is not None:

            return window.selection_start

        return None

    @selection_start.setter
    def selection_start(self, value: tuple[int, int] | None) -> None:
        window = self.window_manager.last_base_focused

        if (window := self.window_manager.last_base_focused) is not None:
            window.selection_start = value

        return None

    def get_path_from_uri(self, uri: str) -> Path | None:
        parsed = urlparse(uri)

        if parsed.scheme == "file":
            return Path(parsed.path)

        if parsed.scheme == "inmemory":
            return None

        raise ValueError(f"Unsupported URI scheme: {parsed.scheme}")

    def change_modes(self, mode: str) -> None:
        if mode == "NORMAL" and self.mode == "INSERT":
            buffer = self.get_current_buffer()

            if (action := buf_actions.change_modes(buffer)) is not None:
                self.apply_action_to_buffer(action)

        self.mode = mode

    def toggle_selection_start(self) -> None:
        window = self.window_manager.last_base_focused

        if window is None:
            return None

        if self.selection_start:
            sy, sx = self.selection_start
            cy = window.cursor_y
            cx = window.cursor_x

            window.cursor_x = sx
            window.cursor_y = sy
            self.selection_start = (cy, cx)

    def request_redraw(self) -> None:
        self.redraw_event.set()

    async def redraw_watcher(self) -> None:
        min_interval = 1.0 / 30  # fps
        loop = asyncio.get_running_loop()

        try:
            while True:
                await self.redraw_event.wait()
                self.redraw_event.clear()

                now = loop.time()
                elapse = now - self._last_redraw

                if elapse < min_interval and self._last_redraw > 0:
                    await asyncio.sleep(min_interval - elapse)

                self.redraw_event.clear()

                self.adjust_scroll()

                self.window_manager.render()

                self._last_redraw = loop.time()

        except asyncio.CancelledError:
            pass

    async def file_watcher(self, interval: float = 1.0) -> None:
        try:
            while True:
                await asyncio.sleep(interval)

                manager = self.window_manager

                if manager is None:
                    continue

                seen_files: set[str] = set()

                for window in manager.base_windows:
                    if not isinstance(window, windows.BufferWindow):
                        continue

                    if window.win is None:
                        continue

                    try:
                        buffer = self.buffers[window.current_buffer]
                    except (IndexError, KeyError, TypeError):
                        continue

                    if (
                        buffer.first
                        or buffer.is_aux_buffer
                        or buffer.file_time_stamp is None
                        or buffer.file_name is None
                    ):
                        continue

                    file_name = str(buffer.file_name)

                    # Avoid checking the same file multiple times if it is open
                    # in more than one BufferWindow.
                    if file_name in seen_files:
                        continue

                    seen_files.add(file_name)

                    try:
                        current_time_stamp = os.path.getmtime(file_name)
                    except FileNotFoundError:
                        continue

                    if current_time_stamp != buffer.file_time_stamp:
                        await events.EVENT_QUEUE.put(
                            Event(
                                type=EventType.FILE_CHANGED_ON_DISK,
                                data=buffer.file_name,
                            )
                        )

        except asyncio.CancelledError:
            return

    async def handle_external_file_change(self, file_name: str) -> None:
        buffer_index = self.get_buffer_by_file_name(file_name)

        if buffer_index == -1:
            return

        buffer = self.buffers[buffer_index]

        if buffer.is_aux_buffer or buffer.file_time_stamp is None:
            return

        try:
            if buffer.file_name is not None:
                current_time_stamp = os.path.getmtime(str(buffer.file_name))
        except FileNotFoundError:
            return

        if current_time_stamp == buffer.file_time_stamp:
            return

        tmp_buffer = Buffer()
        _, new_sha256 = tmp_buffer.load_file(buffer.file_name)
        del tmp_buffer

        if buffer.file_sha256 == new_sha256:
            buffer.file_time_stamp = current_time_stamp
            return

        if not buffer.modified:
            self._reload_buffer_from_disk(buffer, current_time_stamp)
            self.send_notification(f"File '{buffer.file_name}' reloaded from disk.")
            return

        if await self.send_prompt_confirm(
            f"File '{buffer.file_name}' modified externally. Reload?",
        ):
            self._reload_buffer_from_disk(buffer, current_time_stamp)
            self.send_notification(f"File '{buffer.file_name}' reloaded from disk.")

    def _reload_buffer_from_disk(self, buffer: Buffer, new_timestamp: float) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        old_lines = buffer.get_lines()

        new_lines, new_sha256 = buffer.load_file(buffer.file_name)

        buffer.file_time_stamp = new_timestamp
        buffer.file_sha256 = new_sha256

        cursor_before = window.get_cursor_position()

        action_group = buf_actions.generate_buffer_actions(
            old_lines=old_lines,
            new_lines=new_lines,
        )

        buffer.apply_action(action_group)

        window.set_cursor_position(cursor_before)
        buffer.modified = False

    async def git_branch_watcher(self, path: str = ".", interval: float = 5.0) -> None:
        """
        Periodically checks current git branch.
        Updates cached value only if changed.
        """
        try:
            await asyncio.sleep(0.2)

            while True:
                branch = git_utils.get_current_branch_cached(path)

                if branch != self.current_branch:
                    await events.EVENT_QUEUE.put(
                        Event(type=EventType.GIT_BRANCH_UPDATED, data=branch)
                    )

                await asyncio.sleep(interval)

        except asyncio.CancelledError:
            # Clean shutdown
            raise

    async def syntax_highlight_worker(self) -> None:
        try:
            await asyncio.sleep(0.1)

            while True:
                triggered = False

                for window in self.window_manager.base_windows:
                    buffer = window.buffer

                    if buffer.deverge_state < len(buffer.lines) - 1:
                        view_port = min(
                            window.scroll + window.viewport_height - 2,
                            len(buffer.lines) - 1,
                        )

                        if buffer.deverge_state < view_port:
                            self.request_redraw()

                        hilighing.highlight_with_pygments(buffer, window, True)
                        triggered = True

                if triggered:
                    await asyncio.sleep(0.01)
                else:
                    await asyncio.sleep(0.5)

        except asyncio.CancelledError:
            return

    async def input_watcher(self) -> None:
        try:
            while True:
                try:
                    key = key_mappings.get_key_mapping(
                        self.stdscr, self.stdscr.get_wch()
                    )
                except curses.error:
                    await asyncio.sleep(0.016)
                    continue

                await events.EVENT_QUEUE.put(Event(type=EventType.KEY, data=key))

                if key == "\x1b":  # ESC
                    await asyncio.sleep(0.01)

        except asyncio.CancelledError:
            return

    async def run(self, tg) -> None:
        """
        Main loop: initialize curses modes, render screen, handle keypresses.
        Supports a gutter_render callback for line numbers, git lens, etc.
        """

        # store the task group somewhere
        self.tg = tg

        asyncio.get_running_loop().set_debug(self.debug)

        curses.raw()
        curses.noecho()

        if hasattr(curses, "set_escdelay"):
            curses.set_escdelay(25)
        else:
            os.environ.setdefault("ESCDELAY", "25")

        self.stdscr.keypad(True)
        curses.mousemask(curses.ALL_MOUSE_EVENTS | curses.REPORT_MOUSE_POSITION)
        curses.mouseinterval(40)

        normal = curses.color_pair(1)
        hilighing.init_256_color_pairs()

        self.gutter_render = gutters.render_separator

        if config.STATIC_CONFIG.get("ln", False) and config.STATIC_CONFIG.get("gch"):
            self.gutter_render = gutters.render_line_numbers_and_git
        else:
            if config.STATIC_CONFIG.get("ln", False):
                self.gutter_render = gutters.render_line_numbers

            elif config.STATIC_CONFIG.get("gch", False):
                self.gutter_render = gutters.render_git_gutter

        self.stdscr.bkgd(" ", normal)

        last_current_buffer = self.get_current_buffer_index_window()

        self.height, self.width = self.stdscr.getmaxyx()

        hilighing.MAX_LINE_LIMIT = self.height * 2

        try:
            theme = config.STATIC_CONFIG.get("current_theme", "default")
            themes.default.BUILDIN_THEMES[theme].apply_theme()
            self.syntax_enable = True
        except RuntimeError as e:
            self.send_multiline_notification(
                f"Error applying theme '{theme}': {e}\nReverting to no syntax highlighting.",
                0,
            )
            self.syntax_enable = False

        self.tg.create_task(self.file_watcher())
        self.tg.create_task(self.git_branch_watcher())
        self.tg.create_task(self.input_watcher())
        self.tg.create_task(self.redraw_watcher())
        self.tg.create_task(self.syntax_highlight_worker())
        self.tg.create_task(self.window_manager.dispatcher())

        if self.current_session_layout is not None:
            await session.deserialize_layout(
                self.current_session_layout, self, self.window_manager
            )

            for window in self.window_manager.base_windows:
                if window.current_buffer == self.current_buffer_session:
                    await self.window_manager.set_focus(window)
                    break
        else:
            new_buffer_window = windows.BufferWindow(
                self.window_manager, self, self.current_buffer_session
            )
            await self.window_manager.add_base_window(new_buffer_window)
            self.set_current_buffer(self.current_buffer_session)

        while True:

            current_window = self.window_manager.last_base_focused

            buffer = None

            self.height, self.width = self.stdscr.getmaxyx()

            self.stdscr.nodelay(True)  # Non-blocking

            if isinstance(current_window, windows.BufferWindow):
                buffer = self.get_current_buffer()
                current_buffer_index = self.get_current_buffer_index_window()

                if last_current_buffer != current_buffer_index:
                    self.last_buffer = last_current_buffer
                    last_current_buffer = current_buffer_index

                # self.adjust_scroll()

            self.request_redraw()

            try:
                event = await events.EVENT_QUEUE.get()
            except Exception:
                pass

            key = None
            event_type = event.type

            if event_type == EventType.QUIT:
                break

            elif event_type == EventType.TICK:
                pass

            elif event_type == EventType.KEY:
                key = event.data

                if (
                    buffer is not None
                    and current_window is not None
                    and buffer.file_name is not None
                ):
                    jump = Jump(
                        buffer_name=buffer.file_name,
                        position=current_window.get_cursor_position(),
                        timestamp=time.monotonic(),
                    )

                    if self.should_record_jump(
                        buffer_name=buffer.file_name, pos=jump.position
                    ):

                        self.jump_list.append(jump)

                        while len(self.jump_list) > 500:
                            self.jump_list.pop(0)

                        self.jump_index = len(self.jump_list)

                    self.last_jump = jump

            elif event_type == EventType.FILE_CHANGED_ON_DISK:
                file_name = str(event.data)
                await self.handle_external_file_change(file_name)
                # self.input_timeout = True

            elif event_type == EventType.NOTIFICATION:
                _data = cast(tuple[str, int], event.data)
                message, duration = _data
                self.send_notification_nowait(message, duration)

            elif event_type == EventType.GIT_BRANCH_UPDATED:
                old_branch = self.current_branch
                new_branch = cast(str, event.data)

                if old_branch != "--" and old_branch is not None:
                    self.send_notification(
                        f"Git branch was updated from {old_branch} to {new_branch}."
                    )

                self.current_branch = new_branch

            elif event_type == EventType.LSP_DIAGNOSTICS_UPDATED:
                _data_diag = cast(dict[str, Any], event.data)
                uri_buffer = self.get_buffer_from_uri(cast(str, _data_diag["uri"]))

                if uri_buffer is not None:
                    _diags = cast(list[dict[str, Any]], _data_diag["diagnostics"])
                    diagnostics.process_diagnostics(self, uri_buffer, _diags)

                # self.input_timeout = True

            elif event_type == EventType.LSP_REQUEST_COMPLETED:
                await handle_lsp_event(self, event)

            elif event_type == EventType.LOAD_LSP:
                data = event.data or {}
                suffix = data.get("suffix")
                reload = data.get("reload", False)
                lang = data.get("lang", None)

                if suffix is not None:
                    try:
                        if reload:
                            lang = data.get("lang")
                            if lang:
                                existing = config.LOADED_LSPS.get(lang)
                                if existing is not None:
                                    try:
                                        await existing.shutdown_async()
                                    except Exception:
                                        pass

                                    config.LOADED_LSPS.pop(lang, None)

                        await load_lsp(suffix)

                        lsp_client = get_lsp(suffix)

                        if lsp_client:
                            for b in self.buffers:
                                if not b.first and b.suffix == suffix:
                                    lsp_client.did_open(
                                        get_uri_from_name(b.file_name),
                                        "\n".join(b.get_lines()),
                                    )

                    except Exception as ex:
                        self.send_notification(
                            f"LSP load failed ({suffix}): {ex}", 1000
                        )

                    finally:
                        if lang:
                            config.LOADING_LSPS.discard(lang)

                # self.input_timeout = True

            elif event_type in (
                EventType.SUBPROCESS_STARTED,
                EventType.SUBPROCESS_COMPLETED,
                EventType.SUBPROCESS_CANCELLED,
            ):
                await subprocess_task.handle_subprocess_event(self, event)

            elif event_type in (
                EventType.HTTP_REQUEST_STARTED,
                EventType.HTTP_REQUEST_COMPLETED,
                EventType.HTTP_REQUEST_CANCELLED,
            ):
                try:
                    await http_request.handle_http_request_event(self, event)
                except Exception:
                    self.send_notification(traceback.format_exc())

            elif event_type == EventType.AI_COMPLETION:
                job_id = str(event.data)

                for b in self.buffers:
                    if b.first == False and any(
                        c.code == job_id for c in b.ai_completions
                    ):
                        diagnostics.process_ai_completions(self, b, job_id)
                        break
                else:
                    self.send_notification(f"Could not process {job_id=}", 1000)

            # mark task as done
            events.EVENT_QUEUE.task_done()

            try:
                if key is not None:
                    await self.window_manager.input_queue.put(event)
                    # self.window_manager.dispatch(event)
                    # self.process_key(key)

            except Exception as e:
                self.send_notification(
                    message=f"Error Processing key {key}: {e}.\n{traceback.format_exc()}",
                    duration=0,
                )

                with open("error.log", "a") as f:
                    f.write(f"{e}, {traceback.format_exc()}")

        await self.ai_completion_manager.shutdown()

        for v in config.LOADED_LSPS.values():
            if v._init_started:
                await v.shutdown_async()

        for buffer in self.buffers:
            if buffer.first:
                continue

            try:
                buffer.undo_manager.cleanup()
            except Exception as e:
                with open("error.log" "a") as f:
                    f.write(f"{e}, {traceback.format_exc()}")

        raise asyncio.CancelledError

    async def process_key(self, key: int | str | None) -> None:
        try:
            if self.debug:
                with open("seq.txt", "a", encoding="utf-8") as f:
                    f.write(f"{key}\n")

            if (
                self.current_macro_playing_index is not None
                and self.current_macro_playing_name is not None
            ) == False:

                if (
                    self.recording_macro
                    and self.current_macro_recording is not None
                    and key is not None
                ):
                    self.macros[self.current_macro_recording].append(key)

            if self.debug:
                with open("seq.txt", "a", encoding="utf-8") as f:
                    f.write(f"Processed key: {key}\n")

            action = (
                key_bindings.KEY_MAPPING.get(self.mode, {}).get(key)
                if key is not None
                else None
            )

            if action is not None:
                curses.flushinp()

                await action(self)

                return None

            elif isinstance(key, str) and len(key) == 1:
                # Handle single character input

                if self.mode == "INSERT":
                    if self.selection_start:
                        # If selection is active, replace selection with the character
                        self.backspace()

                    self.end_selection()
                    await self.insert_char(key)

        except Exception as e:
            self.open_untitled_buffer(f"Error: {e},\n\n{traceback.format_exc()}")

        return None  # continue main loop

    def apply_action_on_selection_or_file(
        self,
        action_title: str,
        action_function: Callable[[str], Optional[BufferAction]],
    ) -> None:
        try:
            window = self.window_manager.last_base_focused

            if window is None:
                return None

            if self.selection_start is not None:
                ss, es = self.selection_start
                sc, ec = window.get_cursor_position()

                if (ss, es) < (sc, ec):
                    self.toggle_selection_start()

                selected_text = "\n".join(self.get_selected_text(move_cursor=False))
                action = action_function(selected_text)

                if action is None:
                    return

                self.apply_action_to_buffer(action)
                self.end_selection()

            else:
                window.set_cursor_position(CursorPosition(y=0, x=0))
                full_text = "\n".join(self.get_current_buffer().get_lines())
                action = action_function(full_text)

                if action is None:
                    return

                self.apply_action_to_buffer(action)

        except Exception as e:
            self.send_multiline_notification(
                f"{action_title} failed: {e}\n{traceback.format_exc()}", 0
            )

    def toggle_line_number(self, option: str = "ln") -> None:
        if option == "ln":
            if config.STATIC_CONFIG.get("gch", False):
                if config.STATIC_CONFIG.get("ln", False):
                    self.gutter_render = gutters.render_git_gutter
                else:
                    self.gutter_render = gutters.render_line_numbers_and_git
            else:
                if config.STATIC_CONFIG.get("ln", False):
                    self.gutter_render = gutters.render_separator
                else:
                    self.gutter_render = gutters.render_line_numbers

            config.STATIC_CONFIG["ln"] = not config.STATIC_CONFIG.get("ln", False)

        elif option == "gch":
            if config.STATIC_CONFIG.get("ln", False):
                if config.STATIC_CONFIG.get("gch", False):
                    self.gutter_render = gutters.render_line_numbers
                else:
                    self.gutter_render = gutters.render_line_numbers_and_git
            else:
                if config.STATIC_CONFIG.get("gch", False):
                    self.gutter_render = gutters.render_separator
                else:
                    self.gutter_render = gutters.render_git_gutter

            config.STATIC_CONFIG["gch"] = not config.STATIC_CONFIG.get("gch", False)

        else:
            self.gutter_render = gutters.render_separator
            self.send_notification("Wrong Toggle Param.")

    def toggle_bracket_match(self) -> None:
        config.STATIC_CONFIG["brkm"] = not config.STATIC_CONFIG.get("brkm", False)

    def merge_lines(self) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            buffer = self.get_current_buffer()

            action = buf_actions.merge_lines(buffer)

            if action is not None:
                self.apply_action_to_buffer(action)

                window.set_cursor_position(
                    CursorPosition(
                        y=window.cursor_y, x=len(buffer.lines[window.cursor_y])
                    )
                )

    def get_current_buffer_index_window(self) -> int:
        window = self.window_manager.last_base_focused

        if window is not None:

            if window.current_buffer >= len(self.buffers):
                window.current_buffer = len(self.buffers) - 1

            return window.current_buffer

        else:
            return 0

    def get_current_buffer(self) -> Buffer:
        current_buffer = self.get_current_buffer_index_window()

        self.buffers[current_buffer].load()

        return self.buffers[current_buffer]

    def set_current_buffer(self, buffer_index: int) -> None:
        window = self.window_manager.last_base_focused

        if window is not None:

            if buffer_index >= len(self.buffers):
                buffer_indexr = len(self.buffers) - 1

            window.current_buffer = buffer_index
        else:
            self.current_buffer_session = buffer_index

    def get_buffer_by_file_name(self, file_name: str) -> int:
        buf = -1

        for i, b in enumerate(self.buffers):
            if file_name == b.file_name:
                buf = i
                b.load()
                break

        return buf

    def get_buffer_from_uri(self, uri: str) -> Buffer | None:
        for b in self.buffers:
            if get_uri_from_name(b.file_name) == uri:
                return b

        return None

    def fzf_tui_search(self, options: Optional[list[str]] = None) -> Optional[str]:
        try:
            if shutil.which("fzf"):

                from denary import external_tui

                return_code, output = external_tui.run_external_tui_raw(
                    editor=self,
                    command=["fzf"],
                    input_data="\n".join(options) if options is not None else None,
                )

                if return_code == 0:
                    choice = (
                        [l for l in (l.strip() for l in output.split("\r")) if l][-1]
                        .split("[?1000l")[-1]
                        .split("[?25h")[-1]
                    )

                    return choice

            else:
                self.send_notification("Could not find fzf executable.")

        except Exception as e:
            self.send_notification(f"Error while executing fzf: {e}.")

        return None

    def lsp_hover(self) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No file to show hover for.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                lsp_client.hover(
                    get_uri_from_name(buffer.file_name),
                    window.cursor_y,
                    window.cursor_x,
                )

            except Exception as e:
                self.send_notification(f"Error getting hover info: {e}")

        else:
            self.send_notification("LSP client not found for this file type.")

        return None

    async def lsp_completion(self, trigger: str = "") -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()

        if buf.suffix is None:
            return None

        lsp_client = get_lsp(buf.suffix)

        if lsp_client is not None:
            try:
                lsp_client.completion(
                    get_uri_from_name(buf.file_name),
                    window.cursor_y,
                    window.cursor_x,
                    trigger,
                )
            except Exception as e:
                self.send_notification(f"Error getting hover info: {e}")
        else:
            await self.show_suggestions()

    def lsp_refresh(self) -> None:
        """
        Refresh the LSP client for the current buffer.
        """
        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No file to refresh LSP for.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                uri = get_uri_from_name(buffer.file_name)

                lsp_client.did_close(uri)

                time.sleep(1)

                lsp_client.did_open(
                    uri,
                    "\n".join(buffer.get_lines()),
                )
                self.send_notification("LSP client refreshed successfully.")
            except Exception as e:
                self.send_notification(f"Error refreshing LSP client: {e}")
        else:
            self.send_notification("LSP client not found for this file type.")

    def lsp_definition(self) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No file to show definition for.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                lsp_client.definition(
                    get_uri_from_name(buffer.file_name),
                    window.cursor_y,
                    window.cursor_x,
                )

            except Exception as e:
                self.send_notification(f"Error getting definition: {e}")

        else:
            self.send_notification("LSP client not found for this file type.")

    async def show_all_lsp_diagnostics(self) -> None:
        """
        Collect all LSP diagnostics from the current buffer and display them
        in a floating window, grouped by severity.
        """
        buffer = self.get_current_buffer()
        diags = getattr(buffer, "diagnostics", [])

        if not diags:
            await self.open_file_in_less_mode(
                file_handle=StringIO("No diagnostics available.")
            )
            return

        # Severity mapping: smaller number = higher priority in LSP
        severity_labels = {1: "Error", 2: "Warning", 3: "Info", 4: "Hint"}
        severity_order = [1, 2, 3, 4]  # display order

        grouped = defaultdict(list)
        for d in diags:
            grouped[d.severity].append(d)

        lines = []
        for sev in severity_order:
            if sev in grouped:
                lines.append(
                    f"=== {severity_labels.get(sev, sev)} ({len(grouped[sev])}) ==="
                )
                for diag in grouped[sev]:
                    # Show: line:col  CODE: message
                    lines.append(
                        f"Line {diag.line + 1}, Col {getattr(diag, 'char', 0) + 1} "
                        f"{diag.code or ''}: {diag.message}"
                    )
                lines.append("")

        text = "\n".join(lines).strip()

        await self.open_file_in_less_mode(file_handle=StringIO(text))

    def lsp_references(self) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No references found.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                lsp_client.references(
                    get_uri_from_name(buffer.file_name),
                    window.cursor_y,
                    window.cursor_x,
                )
            except Exception as e:
                self.send_notification(f"Error getting references info: {e}")

        else:
            self.send_notification("LSP client not found for this file type.")

    def lsp_code_action(self) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        if not buffer.file_name and not buffer.is_aux_buffer:
            self.send_notification("No references found.")
            return None

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)
        if lsp_client:
            try:
                lsp_client.code_action(
                    uri=get_uri_from_name(buffer.file_name),
                    line=window.cursor_y,
                    character=window.cursor_x,
                    only=["quickfix"],
                )
                # if code_action_info:
                #     # match code_action_info:
                #     #     case {"result": references, **rest} if isinstance(references, list):
                #     #         self.show_references_picker(references)

                #     #     case { "error": { "message": msg, **error_rest }, **rest }:
                #     #         self.send_notification(f"References not avilable {msg}.")

                #     #     case _:
                #     #         self.open_aux_buffer(json.dumps(hover_info, indent=4))
                #     # self.open_aux
                #     self.open_aux_buffer(json.dumps(code_action_info, indent=4))
                # else:
                #     self.send_notification("References not avilable.")
            except Exception as e:
                self.send_multiline_notification(
                    f"Error getting references info: {e}\n{traceback.format_exc()}", 0
                )

        else:
            self.send_notification("LSP client not found for this file type.")

    def open_aux_buffer(
        self, text: str, title: str = "__auxiliary__", lexer=None
    ) -> None:
        """
        Open an auxiliary buffer with the given lines and title.
        """
        aux_buffer_id = self.get_buffer_by_file_name(title)
        text = (
            text.replace("\r\n", "\n")
            .replace("\r", "\n")
            .expandtabs(4)
            .replace("\x00", "�")
        )

        if aux_buffer_id != -1:
            aux_buffer = self.buffers[aux_buffer_id]
            aux_buffer.set_lines([RichString(s) for s in text.splitlines()])
            aux_buffer.file_name = title
            self.set_current_buffer(aux_buffer_id)

        else:
            aux_buffer = Buffer(aux_buffer=True, temp_dir=self.temp_dir)
            aux_buffer.set_lines([RichString(s) for s in text.splitlines()])
            aux_buffer.file_name = title

            if lexer is not None:
                aux_buffer.lexer = lexer
            else:
                code = "\n".join(aux_buffer.lines[:500])
                try:
                    aux_buffer.lexer = guess_lexer(code)
                except Exception:
                    pass

            self.buffers.append(aux_buffer)
            self.set_current_buffer(len(self.buffers) - 1)

        if (window := self.window_manager.last_base_focused) is not None:
            window.adjust_cursor_position()

        self.send_notification(f"Opened auxiliary buffer: {title}")

    def open_untitled_buffer(self, text: str, lexer=None) -> None:
        """
        Open an auxiliary buffer with the given lines and title.
        """
        text = (
            text.replace("\r\n", "\n")
            .replace("\r", "\n")
            .expandtabs(4)
            .replace("\x00", "�")
        )

        self.new_buffer_count += 1

        aux_buffer = Buffer(
            f"Untitled-{self.new_buffer_count}",
            new_buffer_untitled=True,
            temp_dir=self.temp_dir,
        )
        aux_buffer.load()
        aux_buffer.first = False

        aux_buffer.set_lines([RichString(s) for s in text.splitlines()])

        if lexer is not None:
            aux_buffer.lexer = lexer
        else:
            code = "\n".join(aux_buffer.lines[:500])
            try:
                aux_buffer.lexer = guess_lexer(code)
            except Exception:
                pass

        if aux_buffer.lexer:
            aux_buffer.suffix = self.get_suffix_from_buffer_lexer(aux_buffer.lexer)

        self.buffers.append(aux_buffer)
        self.set_current_buffer(len(self.buffers) - 1)

        if (window := self.window_manager.last_base_focused) is not None:
            window.adjust_cursor_position()

        if len(self.buffers) != 1:
            self.send_notification(f"Opened new buffer: {aux_buffer.file_name}")

    async def set_marker(self) -> None:
        """
        Set a marker at the current cursor position.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()
        all_markers = [
            marker[0]
            for marker in itertools.chain(
                buffer.markers.items(), self.global_markers.items()
            )
        ]

        marker_name = await self.send_prompt("Set marker name: ", history=all_markers)

        if not marker_name:
            return None

        if marker_name.startswith("_"):
            # Store the marker globally
            if not buffer.file_name:
                self.send_notification(
                    "Error, cannot set global markers to unsave files."
                )
                return None

            if marker_name in self.global_markers:
                self.send_notification(
                    f"Global marker '{marker_name}' already exists. Overwriting."
                )

            self.global_markers[marker_name] = (
                window.cursor_y,
                window.cursor_x,
                buffer.file_name,
            )

            self.send_notification(
                f"Global marker '{marker_name}' set at ({window.cursor_y}, {window.cursor_x}, buffer {self.get_current_buffer_index_window()})"
            )
            return None

        else:

            # Store the marker with the current cursor position
            buffer.markers[marker_name] = (window.cursor_y, window.cursor_x)
            self.send_notification(
                f"Marker '{marker_name}' set at ({window.cursor_y}, {window.cursor_x})"
            )

    async def pick_markers(self) -> None:
        """
        Show a list of markers and allow the user to jump to one.
        """
        buffer = self.get_current_buffer()

        if not buffer.markers and not self.global_markers:
            self.send_notification("No markers set.")
            return

        def display(entry: tuple[str, tuple]) -> str:
            if len(entry[1]) == 2:
                y, x = entry[1]
                return f"{entry[0]},{" " * max(0, 10- len(entry[0]))} at [{y},{x}]: {buffer.lines[max(0, min(y, len(buffer.lines) - 1))].strip()[:80]}"
            else:
                y, x, buf_name = entry[1]
                return f"{entry[0]},{" " * max(0, 10- len(entry[0]))} at [{y},{x}]: {buf_name}"

        def compare(entry: tuple[str, tuple], query: str) -> bool:
            return query.lower() in entry[0].lower()

        all_markers = [
            marker
            for marker in itertools.chain(
                buffer.markers.items(), self.global_markers.items()
            )
        ]

        async def callback_func(res) -> None:
            window = self.window_manager.last_base_focused
            if window is None:
                return None

            buffer = self.get_current_buffer()
            try:
                if res is None:
                    res = ""
                else:
                    res = res[0]

            except Exception as e:
                self.send_notification(
                    f"An error has ocour: {e}\n{traceback.format_exc()}"
                )
                return None

            if res.startswith("_"):

                if res in self.global_markers:
                    y, x, file_name = self.global_markers[res]

                    buf = self.get_buffer_by_file_name(file_name=file_name)

                    if buf < 0:
                        path_new_buffer = Path(file_name)

                        if not path_new_buffer.exists():
                            self.send_notification(
                                f"Global marker '{res}' buffer not found."
                            )
                            self.global_markers.pop(res)
                            return

                        new_buffer = Buffer(file_name, temp_dir=self.temp_dir)
                        self.buffers.append(new_buffer)
                        buf = len(self.buffers) - 1

                    buffer = self.buffers[buf]

                    pos = CursorPosition(y=y, x=x)

                    self.set_current_buffer(buf)
                    window.set_cursor_position(pos)

                    self.send_notification(
                        f"Jumped to global marker '{res}' at ({pos.y}, {pos.x}) in buffer {buf}"
                    )
                    return None

            else:
                if res in buffer.markers:
                    pos = CursorPosition(*buffer.markers[res])

                    window.set_cursor_position(pos)

                    self.send_notification(
                        f"Jumped to marker '{res}' at ({pos.y}, {pos.x})"
                    )

                    return None

            if res != "":
                self.send_notification(f"No marker found with name '{res}'")

        await self.show_picker_display(
            entries=all_markers,
            display_func=display,
            compare_func=compare,
            callback_func=callback_func,
        )

    async def interactive_replace_in_buffer(self) -> None:
        """
        Regex interactive replace with:
        - Start searching from cursor
        - Forward search
        - Wrap-around ONCE at EOF
        - Replace-all
        - Zero-length match protection
        - No infinite loops
        - Uses only (before, after) like your engine expects
        """
        window = self.window_manager.last_base_focused

        if window is None:
            return None

        _history = list(self.search_history)
        if self.last_search:
            _history.append(self.last_search)

        pattern = await self.send_prompt("Pattern to replace: ", history=_history)
        if not pattern:
            return None

        replacement = await self.send_prompt("Replace with: ")
        if replacement is None:
            replacement = ""

        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except Exception:
            self.send_notification(f"Invalid regex: {pattern}")
            return None

        buffer = self.get_current_buffer()

        self.last_search = pattern
        self.last_search_re = regex
        self.disable_search = False

        cur_y, cur_x = window.get_cursor_position()
        lines = buffer.get_lines()

        absolute_cursor_index = sum(len(line) + 1 for line in lines[:cur_y]) + cur_x
        text = "\n".join(lines)

        search_pos = max(0, min(len(text), absolute_cursor_index))
        wrapped = False

        replace_all = False
        replacements_made = 0
        MAX_REPLACEMENTS = sum(
            1 for _ in (re.compile(pattern, re.IGNORECASE)).finditer(text)
        )

        while True:
            self.adjust_scroll()
            self.request_redraw()

            if replacements_made + 1 > MAX_REPLACEMENTS:
                self.send_notification(
                    "Stopped: too many replacements (loop protection)."
                )
                break

            text = "\n".join(buffer.get_lines())
            match = regex.search(text, search_pos)

            if not match:
                if wrapped:
                    break  # already wrapped once → fully done
                # wrap-around once only
                search_pos = 0
                wrapped = True
                continue

            start, end = match.span()

            if start == end:
                search_pos = max(end + 1, start + 1)
                continue

            matched_text = text[start:end]

            line_num = text.count("\n", 0, start)
            last_nl = text.rfind("\n", 0, start)
            col_num = start - (last_nl + 1) if last_nl != -1 else start
            col_num = max(0, col_num)

            window.set_cursor_position(CursorPosition(y=line_num, x=col_num))

            self.selection_start = (line_num, col_num + len(matched_text))
            self.adjust_scroll()
            self.request_redraw()

            if not replace_all:
                choice = await self.send_prompt(
                    f"Replace '{matched_text}'? [y]es / [n]o / [a]ll / [q]uit: "
                )
                choice = (choice or "").strip().lower()
            else:
                choice = "y"

            if choice == "q":
                break

            if choice == "a":
                replace_all = True
                choice = "y"

            if choice != "y":
                search_pos = end
                continue

            try:
                # smart replacement
                new_text = expand_replacement(match, replacement)
            except Exception as e:
                self.send_multiline_notification(
                    f"Invalid replacement: {e}\n{traceback.format_exc()}", -1
                )
                break

            action = BufferAction(
                action_type=BufferActionTypeEnum.REPLACE,
                content=(matched_text, new_text),
                cursor_position=CursorPosition(y=line_num, x=col_num),
            )

            self.apply_action_to_buffer(action)
            replacements_made += 1

            search_pos = start + len(replacement)

        self.send_notification(
            f"Interactive replace finished. {replacements_made} replacements made."
        )
        self.last_search = pattern

    def send_notification_nowait(self, message: str, duration: int = 500) -> None:
        if "\n" in message:
            notifications.send_multiline_notification(
                window=self.stdscr,
                message=message,
                duration=duration,
                editor=self,
            )
        else:
            notifications.send_notification(
                window=self.stdscr,
                message=message,
                duration=duration,
                editor=self,
            )

    def send_notification(self, message: str, duration: int = 500) -> None:
        events.EVENT_QUEUE.put_nowait(
            Event(type=EventType.NOTIFICATION, data=(message, duration))
        )

    def send_multiline_notification(self, message: str, duration: int = 500) -> None:

        events.EVENT_QUEUE.put_nowait(
            Event(type=EventType.NOTIFICATION, data=(message, duration))
        )

    async def open_file_in_less_mode(
        self,
        file_handle: StringIO | BytesIO,
        show_paste_menu: bool = True,
        position: Optional[CursorPosition] = None,
    ):
        window = self.window_manager.last_base_focused

        if window is None:
            return None

        viewer = LessWindow(
            manager=self.window_manager,
            parent_window=self.stdscr,
            file_handle=file_handle,
            editor=self,
            show_paste_menu=show_paste_menu,
            cursor_pos=window.get_cursor_position_display(),
        )

        await self.window_manager.push_overlay(viewer)

    # def send_multiline_prompt(self, multiline_message: str, prompt_message: str) -> str:
    #     return prompts.send_multiline_prompt(
    #         window=self.stdscr,
    #         multiline_message=multiline_message,
    #         prompt_message=prompt_message,
    #         editor=self,
    #     )

    async def send_prompt(
        self,
        prompt_message: str,
        history: Optional[list[str]] = None,
        current_value: Optional[str] = None,
        on_change: Optional[Callable[[str], None]] = None,
        debounce_ms: int = 0,
        max_buffer_len: int = -1,
        increment_macro_start: bool = True,
    ) -> str:
        return await self.window_manager.open_prompt(
            # window=self.stdscr,
            prompt_message=prompt_message,
            history=history,
            current_value=current_value,
            on_change=on_change,
            debounce_ms=debounce_ms,
            max_buffer_len=max_buffer_len,
            increment_macro_start=increment_macro_start,
            editor=self,
            # event_queue=self.window_manager.input_queue,
        )

    async def send_prompt_confirm(self, prompt_message: str, color_p: int = -1) -> bool:
        return await self.window_manager.open_confirm(
            # window=self.stdscr,
            prompt_message=prompt_message,
            # event_queue=self.window_manager.input_queue,
            color_p=color_p,
            editor=self,
        )

    # async def send_prompt_confirm_multiline(
    #     self, multiline_message: str, prompt_message: str
    # ) -> bool:
    #     return await prompts.send_prompt_confirm_multiline_async(
    #         window=self.stdscr,
    #         multiline_message=multiline_message,
    #         prompt_message=prompt_message,
    #         editor=self,
    #         event_queue=self.window_manager.input_queue,
    #     )

    async def show_filetype_picker(self) -> None:
        from pygments.lexers import get_all_lexers, get_lexer_by_name

        lexers = list(get_all_lexers())

        if not lexers:
            self.send_notification("Could not load list of lexers")
            return None

        async def callback_func(selected):
            if not selected:
                return None

            lexer_name, aliases, *_ = selected

            # direct resolution (no loops)
            lexer = get_lexer_by_name(aliases[0] if aliases else lexer_name)
            suffix = self.get_suffix_from_buffer_lexer(lexer)

            buffer = self.get_current_buffer()

            if (
                buffer.suffix is not None
                and (lsp_client := get_lsp(buffer.suffix)) is not None
            ):
                lsp_client.did_close(get_uri_from_name(buffer.file_name))

            buffer.lexer = lexer
            buffer.suffix = suffix

            if (
                buffer.suffix is not None
                and (lsp_client := get_lsp(buffer.suffix)) is not None
            ):
                lsp_client.did_open(
                    get_uri_from_name(buffer.file_name), "\n".join(buffer.get_lines())
                )

            buffer.deverge_state = 0

            for line in buffer.lines:
                line.state = None
                line.tokens = None

            self.send_notification(f"Lexer set: {lexer_name}")

        await self.show_picker_display(
            entries=lexers,
            display_func=lambda x: x[0],  # lexer name
            compare_func=lambda x, q: True,
            external_filter=lambda q, c: (
                fzf_fuzzy_find(q, [el["display"] for el in c])
                if q
                else [el["display"] for el in c]
            ),
            debounce_ms=400,
            callback_func=callback_func,
        )

    async def change_lexer(self, arg: Optional[str] = None) -> None:
        buffer = self.buffers[self.get_current_buffer_index_window()]
        first_line = buffer.lines[0]

        if arg is None or not arg:
            await self.show_filetype_picker()
            return None
        else:
            new_filetype = arg

        if not new_filetype:
            self.send_notification("filetype not supplied.")
            return None

        if not new_filetype.startswith("."):
            new_filetype = "." + new_filetype

        lexer = TextLexer()
        suffix = buffer.suffix

        try:
            lexer = hilighing.get_lexer(suffix=new_filetype)
            suffix = new_filetype

        except Exception as e:
            self.send_multiline_notification(
                f"No se pudo cargar el lexer, {e}\n{traceback.format_exc()}.", 0
            )
            try:
                lexer = get_lexer_by_name(new_filetype)

                if lexer:
                    suffix = self.get_suffix_from_buffer_lexer(lexer)

            except Exception:
                pass

        if lexer and not suffix:
            suffix = self.get_suffix_from_buffer_lexer(lexer)

        if (
            buffer.suffix is not None
            and (lsp_client := get_lsp(buffer.suffix)) is not None
        ):
            lsp_client.did_close(get_uri_from_name(buffer.file_name))

        buffer.lexer = lexer
        buffer.suffix = suffix

        if (
            buffer.suffix is not None
            and (lsp_client := get_lsp(buffer.suffix)) is not None
        ):
            lsp_client.did_open(
                get_uri_from_name(buffer.file_name), "\n".join(buffer.get_lines())
            )

        first_line.state = None
        first_line.tokens = None

        buffer.deverge_state = 0

        if isinstance(lexer, TextLexer):
            for line in buffer.lines:
                line.state = None
                line.tokens = None

    def get_suffix_from_buffer_lexer(self, lexer) -> str | None:
        suffixes = get_suffix_from_lexer(lexer)
        suffixes_supported = set(config.EXT_TO_LANG.keys())

        for suffix in suffixes:
            if suffix in suffixes_supported:
                return suffix

        return None

    async def save_file(self) -> None:
        """
        Write self.lines back to disk.  If no filename yet, prompt for 'Save as'.
        """

        buffer = self.get_current_buffer()

        if buffer.is_aux_buffer:
            self.send_notification("Cannot save auxiliary buffers.")
            return

        is_new = False

        if buffer.file_name is None or (
            buffer.file_name.startswith("Untitled") and buffer.file_time_stamp is None
        ):
            prompt = "Save as: "
            name = await self.send_prompt(prompt)

            if not name:
                return None

            lexer_suffix = self.get_suffix_from_buffer_lexer(buffer.lexer)

            if (
                lexer_suffix is not None
                and buffer.file_name is not None
                and (lsp_client_before := get_lsp(lexer_suffix)) is not None
            ):
                lsp_client_before.did_close(uri=get_uri_from_name(buffer.file_name))

            buffer.file_name = name
            buffer.load_lexer()

            is_new = True

        try:
            buffer.save_file()
            self.working_dir_mtime = self.get_working_dir_mtime()

        except Exception as e:
            self.send_notification(f"File could not be saved correctly ({e}).", 1000)
            return None

        if config.STATIC_CONFIG.get("gch", False):
            buffer.git_changes = git_utils.get_file_changes(buffer.file_name)
            buffer.buffer_changes.clear()  # Clear buffer changes after saving

        if buffer.suffix is None:
            return None

        lsp_client = get_lsp(buffer.suffix)

        if lsp_client is not None:

            if is_new:
                try:
                    lsp_client.did_open(
                        get_uri_from_name(buffer.file_name),
                        "\n".join(buffer.get_lines()),
                    )
                except Exception as e:
                    self.send_notification(f"Error opening file in LSP: {e}")
            else:
                try:
                    lsp_client.did_save(
                        get_uri_from_name(buffer.file_name),
                    )
                except Exception as e:
                    self.send_notification(f"Error updating file in LSP: {e}")

        fpath = Path(buffer.file_name)

        self.send_notification(
            f"File '{buffer.file_name}' saved successfully. Writen: {fpath.stat().st_size} Bytes."
        )

        self.buffers[self.get_current_buffer_index_window()] = buffer

    def get_working_dir_mtime(self) -> float:
        return os.stat(str(self.working_dir)).st_mtime

    async def confirm_quit(self) -> None:
        """
        If buffer is modified, ask user to confirm quitting without saving.
        Returns True if safe to quit, False to continue editing.
        """
        try:

            documents_with_changes = sum(1 for b in self.buffers if b.modified)

            if documents_with_changes > 0:
                prompt = f"UNSAVED CHANGES!!!, buffers ({documents_with_changes}). Quit without saving?"
            else:
                prompt = "Are you sure you want to close the editor?"

            if await self.send_prompt_confirm(prompt, color_p=15):
                # return True
                events.EVENT_QUEUE.put_nowait(Event(EventType.QUIT))
            else:
                for i, b in enumerate(self.buffers):
                    if b.modified:
                        self.set_current_buffer(i)
                        break

        finally:
            if self.without_session == False:
                session.save_editor_session(self)

    def start_selection(self) -> None:
        """
        Start a new selection at the current cursor position.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        if self.selection_start is None:
            self.selection_start = (window.cursor_y, window.cursor_x)

    def end_selection(self) -> None:
        self.selection_start = None
        return None

    def toggle_selection(self) -> None:

        if self.selection_start is None:
            self.start_selection()
        else:
            self.end_selection()

    async def manage_registers(self) -> None:
        multiline_message = "\n".join(
            f"{index}) {item[0]}:{" " * max(0, 10 - len(item[0]))} {"".join(item[1]).strip()[:50]} | ({len("".join(item[1]))}) Chars."
            for index, item in enumerate(
                itertools.chain(
                    self.registers.items(),
                    [(str(_i), _v) for _i, _v in enumerate(self.copy_history)],
                ),
                start=1,
            )
        )

        multiline_message = "Registers:\n" + multiline_message + "\n"

        # register_name = self.send_multiline_prompt(
        #     multiline_message=multiline_message, prompt_message="Register name: "
        # )

        register_name = await self.send_prompt(
            prompt_message=multiline_message + "\n" + "Register name: "
        )

        if not register_name:
            return None

        clipboard_before = list(self.clipboard) if len(self.clipboard) else None

        if self.selection_start is not None:
            if register_name.isdigit():
                self.end_selection()
                self.send_notification(
                    f"Numbers cannot be set as register names, but the text was copied and added to the copy history.",
                    1000,
                )
                return None

            self.registers[register_name] = self.get_selected_text()
            self.end_selection()

        else:

            history_len = self.copy_history.maxlen or 0

            if register_name.isdigit():

                register_index = int(register_name)
                try:
                    if (
                        register_index < history_len
                        and len(self.copy_history) > register_index
                    ):
                        self.clipboard = list(self.copy_history[register_index])

                        self.paste()
                        self.clipboard = []

                except Exception as e:
                    self.send_notification(f"Error: {e}.")

            else:
                if register_name not in self.registers:
                    self.send_notification(
                        f"There isn't a register named: {register_name}."
                    )
                    return None

                self.clipboard = list(self.registers[register_name])

                self.paste()
                self.clipboard = []

        if clipboard_before is not None:
            self.clipboard = clipboard_before

    def get_selected_text(self, move_cursor: bool = True) -> list[str]:
        window = self.window_manager.last_base_focused

        if window is None:
            return []

        buffer = self.buffers[self.get_current_buffer_index_window()]

        res: list[str] = []

        if not self.selection_start:
            return res

        start_row, start_col = self.selection_start
        end_row, end_col = window.cursor_y, window.cursor_x

        # Normalize order
        if (start_row, start_col) > (end_row, end_col):
            start_row, start_col, end_row, end_col = (
                end_row,
                end_col,
                start_row,
                start_col,
            )

        max_row = len(buffer.lines) - 1
        if max_row < 0:
            return res

        start_row = max(0, min(start_row, max_row))
        end_row = max(0, min(end_row, max_row))

        start_col = max(0, min(start_col, len(buffer.lines[start_row])))
        end_col = max(0, min(end_col, len(buffer.lines[end_row])))

        if move_cursor:
            window.cursor_y = start_row
            window.cursor_x = start_col
            window.last_cursor_x = window.cursor_x

        for r in range(start_row, end_row + 1):
            line = buffer.lines[r]

            if start_row == end_row:
                res.append(line[start_col:end_col])
            elif r == start_row:
                res.append(line[start_col:])
            elif r == end_row:
                res.append(line[:end_col])
            else:
                res.append(line)

        return res

    def copy(self) -> None:
        """
        Copy selected region or current line if no selection.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        if self.selection_start:
            self.clipboard = self.get_selected_text()
        else:
            self.clipboard = [buffer.lines[window.cursor_y]]

        self.copy_history.append(self.clipboard)

        self._set_clipboard_text("\n".join(self.clipboard))

    def cut(self) -> None:
        """
        VSCode-style cut:
          • With a selection: remove that region (possibly multi-line) and copy it to clipboard.
          • Without a selection: remove the entire current line.
        Implemented as a single DELETE BufferAction.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()
        lines = buf.lines
        clip: list[str] = []

        without_selection = False

        if self.selection_start:
            sr, sc = self.selection_start
            er, ec = window.cursor_y, window.cursor_x
            if (sr, sc) > (er, ec):
                sr, sc, er, ec = er, ec, sr, sc
        else:
            # treat current line as selected
            sr = er = (
                window.cursor_y if window.cursor_y < len(lines) else len(lines) - 1
            )
            sc = 0
            ec = len(lines[sr])
            without_selection = True

        if sr == er:
            # single-line
            text = lines[sr]
            clip_text = text[sc:ec]
            clip = [clip_text]
            old_text = clip_text
        else:
            # multi-line selection
            first, last = lines[sr], lines[er]
            clip = [first[sc:]] + lines[sr + 1 : er] + [last[:ec]]
            old_text = "\n".join(clip)

        self.clipboard = clip

        action = BufferAction(
            action_type=BufferActionTypeEnum.DELETE,
            content=old_text,
            cursor_position=CursorPosition(y=sr, x=sc),
        )

        self.apply_action_to_buffer(action)

        if without_selection:
            if sr == 0:
                self.delete()
            else:
                self.backspace()
                if sr >= len(buf.lines):
                    sr -= 1

        window.cursor_y = sr
        window.cursor_x = sc
        window.last_cursor_x = sc

        self.selection_start = None

        curses.flushinp()
        self.buffers[self.get_current_buffer_index_window()] = buf

    def paste(self) -> None:
        """
        VSCode-style paste:
          • If there's a selection, replaces it (REPLACE action).
          • Otherwise, inserts clipboard content at the cursor (INSERT action).
          • Clipboard is a list[str], each entry one line of text.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()

        if not self.clipboard:
            return None

        if self.selection_start is not None:

            old_text = "\n".join(self.get_selected_text())
            self.selection_start = None

            # build new pasted text
            paste_text = "\n".join(self.clipboard)

            action = BufferAction(
                action_type=BufferActionTypeEnum.REPLACE,
                content=(old_text, paste_text),
                cursor_position=window.get_cursor_position(),
            )

            self.apply_action_to_buffer(action)

            window.last_cursor_x = window.cursor_x
            curses.flushinp()
            return None

        paste_text = "\n".join(self.clipboard)

        # build action
        action = BufferAction(
            action_type=BufferActionTypeEnum.INSERT,
            content=paste_text,
            cursor_position=window.get_cursor_position(),
        )

        self.apply_action_to_buffer(action)

        curses.flushinp()
        self.ensure_cursor_visible()

    def _set_clipboard_text(self, text: str) -> bool:
        """
        Try pyperclip.copy() first; if that fails, fall back to a platform-specific
        clipboard command. Returns True on success.
        """
        is_wsl = check_is_wsl()
        is_ssh = check_is_ssh()

        if is_wsl:
            # Use Windows' clipboard via PowerShell
            cmd = ["/mnt/c/Windows/System32/clip.exe"]
            try:
                p = subprocess.Popen(cmd, stdin=subprocess.PIPE, shell=True)
                p.communicate(text.encode("utf-16le"))

                return p.returncode == 0
            except Exception:
                pass

        if is_ssh:
            try:
                import base64

                b64 = base64.b64encode(text.encode()).decode()
                osc52 = f"\033]52;c;{b64}\a"
                sys.stdout.write(osc52)
                sys.stdout.flush()
                return True
            except Exception:
                pass

        # 2) macOS pbcopy
        if sys.platform.lower() == "darwin":
            try:
                p = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
                p.communicate(text.encode("utf-8"))
                return p.returncode == 0
            except Exception:
                return False

        # 3) Linux xclip / xsel
        if sys.platform.startswith("linux"):
            has_gui = os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")

            if not has_gui:
                return False

            for cmd in (
                ["xclip", "-selection", "clipboard"],
                ["xsel", "--clipboard", "--input"],
            ):
                try:
                    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
                    p.communicate(text.encode("utf-8"))
                    if p.returncode == 0:
                        return True
                except Exception:
                    continue
            return False

        # 4) Windows clip.exe
        if sys.platform.startswith("win"):
            try:
                p = subprocess.Popen(["clip"], stdin=subprocess.PIPE, shell=True)
                p.communicate(text.encode("utf-8"))
                return p.returncode == 0
            except Exception:
                return False

        return False

    def _get_clipboard_text(self) -> str:
        """
        Retrieve text from the system clipboard by trying multiple methods
        until one returns non-empty text.
        """
        # 2) Try a sequence of commands in order
        commands = [
            [
                "powershell.exe",
                "-NoProfile",
                "-Command",
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Clipboard",
            ],
            [
                "/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe",
                "-NoProfile",
                "-Command",
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Clipboard",
            ],
            ["pbpaste"],
            ["xclip", "-selection", "clipboard", "-o"],
            ["xsel", "--clipboard", "--output"],
            [
                "powershell",
                "-NoProfile",
                "-Command",
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Clipboard",
            ],
        ]

        for i, cmd in enumerate(commands):
            if shutil.which(cmd[0]):
                try:
                    result = subprocess.run(
                        cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.DEVNULL,
                        check=True,
                    )

                    text = result.stdout.decode("utf-8", errors="ignore")

                    text = text.replace("\r\n", "\n")
                    text = text.expandtabs(4)
                    text = text.replace("\x00", "�")

                    if text:
                        return text
                except Exception as e:
                    self.send_notification(str(e), 0)
                    continue

        return ""

    def paste_from_system_clipboard(self) -> None:
        """
        Paste text from the system clipboard into the current buffer.
        """
        try:
            text = self._get_clipboard_text()
            if not text:
                self.send_notification("Clipboard is empty", 1000)
                return None

            previous_clipboard = self.clipboard

            lines = text.splitlines()

            self.clipboard = lines if lines else [""]

            self.paste()

            self.clipboard = previous_clipboard

        except Exception as e:
            self.send_notification(
                f"pyperclip module not installed or clipboard unavailable. {e}",
                1000,
            )

    def change_selection_case(self, mode: str = "upper") -> None:
        """
        Change the selected text case using a single REPLACE BufferAction.
        Only the selected span is replaced (not whole lines).
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        if not self.selection_start:
            return None

        # Normalize selection
        start_row, start_col = self.selection_start
        end_row, end_col = window.cursor_y, window.cursor_x
        if (start_row, start_col) > (end_row, end_col):
            start_row, start_col, end_row, end_col = (
                end_row,
                end_col,
                start_row,
                start_col,
            )

        def apply_case(text: str) -> str:
            if mode == "upper":
                return text.upper()
            if mode == "lower":
                return text.lower()
            if mode == "capitalize":
                return text.title()
            return text

        # Build the EXACT selected text (old_text)
        lines = buffer.lines
        if start_row == end_row:
            # single-line selection
            old_text = lines[start_row][start_col:end_col]
        else:
            first_part = lines[start_row][start_col:]
            middle = lines[start_row + 1 : end_row]
            last_part = lines[end_row][:end_col]
            parts = [first_part]
            if middle:
                parts.append("\n".join(middle))
            parts.append(last_part)
            old_text = "\n".join(p for p in parts if p is not None)

        new_text = apply_case(old_text)

        action = BufferAction(
            action_type=BufferActionTypeEnum.REPLACE,
            content=(old_text, new_text),
            cursor_position=CursorPosition(y=start_row, x=start_col),
        )
        self.apply_action_to_buffer(action)

        self.selection_start = None
        window.cursor_y = end_row
        window.cursor_x = end_col
        window.last_cursor_x = window.cursor_x
        curses.flushinp()

    def undo(self) -> None:
        window = self.window_manager.last_base_focused

        if window is None:
            return None

        buffer = self.get_current_buffer()
        buffer.undo_action()

        pos = buffer._get_cursor_position()
        window.set_cursor_position(pos)

        curses.flushinp()

    def redo(self) -> None:
        window = self.window_manager.last_base_focused

        if window is None:
            return None

        buffer = self.get_current_buffer()
        buffer.redo_action()

        pos = buffer._get_cursor_position()
        window.set_cursor_position(pos)

        curses.flushinp()

    def apply_action_to_buffer(
        self, action: BufferAction, buf_index: Optional[int] = None
    ) -> None:
        window = self.window_manager.last_base_focused

        if window is None:
            return None

        if buf_index is None:
            buf_index = self.get_current_buffer_index_window()

        buffer = self.buffers[buf_index]
        buffer.apply_action(action)

        pos = buffer._get_cursor_position()
        window.set_cursor_position(pos)

    def adjust_scroll(self) -> None:
        """
        Apply vertical scrolloff, except near the beginning/end of the file.

        Behavior:
            - Near the first scrolloff lines: keep scroll at 0.
            - Near the last scrolloff lines: keep scroll at max_scroll.
            - Otherwise: keep cursor at least scrolloff rows away from top/bottom.
        """
        window = self.window_manager.last_base_focused
        if window is None or not window.focused:
            return

        buffer = self.get_current_buffer()

        screen_height = window.viewport_height
        screen_width = window.viewport_width

        # Last row is probably status bar / command line
        visible_rows = max(1, screen_height - 1)

        total_lines = len(buffer.lines)
        max_scroll = max(0, total_lines - visible_rows)

        scrolloff = int(config.STATIC_CONFIG.get("scrolloff", 0) or 0)
        scrolloff = max(0, scrolloff)

        # Prevent impossible scrolloff values in small windows.
        # Example: viewport has 10 visible rows, scrolloff=8 is too aggressive.
        effective_scrolloff = min(scrolloff, max(0, visible_rows // 2))

        y = max(0, min(window.cursor_y, max(0, total_lines - 1)))

        # -------------------------
        # Vertical scroll
        # -------------------------

        if total_lines <= visible_rows:
            # Whole file fits on screen.
            window.scroll = 0

        elif y < effective_scrolloff:
            # Near top of file: do not force scrolloff.
            window.scroll = 0

        elif y >= total_lines - effective_scrolloff:
            # Near bottom of file: do not force scrolloff.
            window.scroll = max_scroll

        else:
            top_limit = window.scroll + effective_scrolloff
            bottom_limit = window.scroll + visible_rows - 1 - effective_scrolloff

            if y < top_limit:
                window.scroll = y - effective_scrolloff

            elif y > bottom_limit:
                window.scroll = y + effective_scrolloff - visible_rows + 1

            window.scroll = max(0, min(window.scroll, max_scroll))

        # -------------------------
        # Horizontal scroll
        # -------------------------

        gutter_width = 1

        if self.gutter_render:
            screen_row = y - window.scroll

            if 0 <= screen_row < visible_rows:
                # Ideally this should NOT render.
                # Better: use a pure function like self.get_gutter_width(...)
                try:
                    gutter_width = self.gutter_render(
                        self.stdscr, screen_row, y, buffer, None
                    )
                except Exception:
                    pass

        # Match draw logic:
        # ctx.max_width = width - 1
        # line_width = ctx.max_width - gutter_width - 1
        usable_width = max(1, screen_width - gutter_width - 2)

        if 0 <= y < total_lines:
            line = buffer.lines[y]
        else:
            line = RichString("")

        cursor_visual_x = visual_x(
            line,
            window.cursor_x,
            buffer.tab_size,
        )

        window.h_scroll = line_x(cursor_visual_x, usable_width)

    def move_cursor(self, key) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.move_cursor(key, window.viewport_height, window.viewport_width)

    def move_cursor_end_of_line(self) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.move_cursor_end_of_line()

    def move_cursor_start_of_line(self) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.move_cursor_start_of_line()

    def move_cursor_by_word(self, direction) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.move_cursor_by_word(direction)

    def move_cursor_by_punctuation(self, direction) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.move_cursor_by_punctuation(direction)

    def move_cursor_by_empty_line(self, direction: int) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.move_cursor_by_empty_line(direction, self.height)

    async def find_char(
        self, target_char: Optional[str] = None, forward: bool = True
    ) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            if not target_char:
                target_char = await self.send_prompt("f: " if forward else "F: ")

            window.find_char(target_char, forward)

    def ensure_cursor_visible(self) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.ensure_cursor_visible()

    def should_record_jump(
        self,
        buffer_name: str,
        pos: CursorPosition,
        *,
        line_threshold: int = 20,
        big_jump_threshold: int = 200,
        min_time_delta: float = 0.30,
    ) -> bool:

        if self.disable_record_jump:
            self.disable_record_jump = False
            return False

        if not self.jump_list:
            return True

        if self.last_jump is None:
            return False

        if time.monotonic() - self.last_jump.timestamp < min_time_delta:
            return False

        if buffer_name != self.last_jump.buffer_name:
            return True

        line_distance = abs(pos.y - self.last_jump.position.y)

        if line_distance == 0:
            return False

        if line_distance >= big_jump_threshold:
            return True

        if line_distance >= line_threshold:
            return True

        return False

    def change_indentation(self, direction: int) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()
        y, x = window.get_cursor_position()

        if self.selection_start is not None:
            start_row, start_col = self.selection_start
            end_row, end_col = window.cursor_y, window.cursor_x

            if (start_row, start_col) > (end_row, end_col):
                start_row, start_col, end_row, end_col = (
                    end_row,
                    end_col,
                    start_row,
                    start_col,
                )
        else:
            start_row = end_row = window.cursor_y

        old_lines = buffer.lines[start_row : end_row + 1]
        old_lines_len = len(old_lines)
        old_text = "\n".join(old_lines)

        indent_unit = " " * buffer.tab_size if buffer.insert_spaces else "\t"
        new_lines = []

        for line in old_lines:
            is_blank = line.strip() == ""

            if direction > 0:
                if is_blank and old_lines_len > 1:
                    new_lines.append(line)
                    continue

                new_lines.append(indent_unit + line)

            else:
                if line.startswith("\t"):
                    new_lines.append(line[1:])
                else:
                    remove_count = 0
                    for ch in line[: buffer.tab_size]:
                        if ch == " ":
                            remove_count += 1
                        else:
                            break
                    new_lines.append(line[remove_count:])

        new_text = "\n".join(new_lines)

        if new_text == old_text:
            return None

        action = BufferAction(
            action_type=BufferActionTypeEnum.REPLACE,
            content=(old_text, new_text),
            cursor_position=CursorPosition(y=start_row, x=0),
        )

        self.apply_action_to_buffer(action)

        indent_width = buffer.tab_size if buffer.insert_spaces else 1

        if start_row <= y <= end_row:
            if direction > 0:
                window.cursor_x = min(x + indent_width, len(buffer.lines[y]))
            else:
                window.cursor_x = max(x - indent_width, 0)

        window.cursor_y = y
        window.last_cursor_x = window.cursor_x
        window.adjust_cursor_position()

    def toggle_comment_selection(
        self, prefix: str | tuple[str, str] | None = None
    ) -> None:
        """
        Toggle comment on the selected lines (or current line) like VS Code.
        Works with:
          - single-line token: str (includes trailing space, e.g. "# ")
          - multi-line tokens: (start_with_space, end)
        Empty lines are never commented or uncommented.
        """

        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        tok = (
            prefix
            if prefix is not None
            else (
                hilighing.lookup_prefix(buffer.file_name or "")
                if buffer.suffix is None
                else hilighing.lookup_prefix(f"filename{buffer.suffix}")
            )
        )
        single: str | None = None
        mstart: str | None = None
        mend: str | None = None

        if isinstance(tok, tuple):
            mstart, mend = tok
        else:
            single = tok

        has_single = bool(single)
        has_multi = bool(mstart) and bool(mend)
        if not has_single and not has_multi:
            return None

        if self.selection_start:
            sr, sc = self.selection_start
            er, ec = window.cursor_y, window.cursor_x
            if (sr, sc) > (er, ec):
                sr, sc, er, ec = er, ec, sr, sc
        else:
            sr = er = window.cursor_y

        block = buffer.lines[sr : er + 1]

        indents = [len(ln) - len(ln.lstrip()) for ln in block if ln.strip()]
        min_indent = min(indents) if indents else 0

        def is_single_commented(ln: RichString) -> bool:
            if not single:
                return False
            s = ln.lstrip()
            return s.startswith(single) or s.startswith(single.rstrip())

        def unwrap_single(txt: RichString) -> RichString:
            assert single is not None
            indent = len(txt) - len(txt.lstrip())
            s = txt.lstrip()
            if s.startswith(single):
                core = s[len(single) :]
            elif s.startswith(single.rstrip()):
                core = s[len(single.rstrip()) :]
                if core.startswith(" "):
                    core = core[1:]
            else:
                core = s
            return txt[:indent] + core

        def wrap_single(txt: RichString) -> RichString:
            assert single is not None
            before = txt[:min_indent]
            after = txt[min_indent:]
            return RichString(f"{before}{single}{after}")

        def is_multi_wrapped(ln: RichString) -> bool:
            if not has_multi:
                return False
            s = ln.lstrip()
            if mstart is not None and not s.startswith(mstart):
                return False

            body = s[len(mstart or "") :]

            if mend is not None and body.endswith(mend):
                return True
            pos = body.rfind(mend or "")
            if pos == -1:
                return False
            return body[pos + len(mend or "") :].strip() == ""

        def unwrap_multi(txt: RichString) -> RichString:
            assert has_multi
            indent = len(txt) - len(txt.lstrip())
            rest = txt[indent:]
            if mstart is not None and not rest.startswith(mstart):
                return txt
            body = rest[len(mstart or "") :]
            if mend is not None and body.endswith(mend):
                inner = body[: -len(mend)]
                inner = inner[:-1] if inner.endswith(" ") else inner
            else:
                pos = body.rfind(mend or "")
                if pos == -1:
                    return txt
                inner = body[:pos].rstrip()
            return txt[:indent] + inner

        def wrap_multi(txt: RichString) -> RichString:
            assert has_multi
            before = txt[:min_indent]
            inner = txt[min_indent:]
            sep_before_end = "" if (not inner or inner.endswith(" ")) else " "
            return RichString(f"{before}{mstart}{inner}{sep_before_end}{mend}")

        if has_single:
            uncomment = all(is_single_commented(ln) for ln in block if ln.strip())

            new_lines = []
            for ln in block:
                if not ln.strip():
                    new_lines.append(ln)
                    continue
                new_lines.append(unwrap_single(ln) if uncomment else wrap_single(ln))
        else:
            uncomment = all(is_multi_wrapped(ln) for ln in block if ln.strip())

            new_lines = []
            for ln in block:
                if not ln.strip():
                    new_lines.append(ln)
                    continue
                new_lines.append(unwrap_multi(ln) if uncomment else wrap_multi(ln))

        old_text = "\n".join(block)
        new_text = "\n".join(new_lines)

        action = BufferAction(
            action_type=BufferActionTypeEnum.REPLACE,
            content=(old_text, new_text),
            cursor_position=CursorPosition(y=sr, x=0),
        )
        y, x = window.get_cursor_position()

        self.apply_action_to_buffer(action)

        tok_len = len(tok)
        new_line = buffer.lines[window.cursor_y]
        window.cursor_y = y
        window.cursor_x = max(
            0, min(x + (tok_len if not uncomment else (-1 * tok_len)), len(new_line))
        )
        window.last_cursor_x = window.cursor_x
        window.adjust_cursor_position()

    def go_to_file_start(self) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            # buffer = self.get_current_buffer()
            window.go_to_file_start()

    def go_to_file_end(self) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            # buffer = self.get_current_buffer()
            window.go_to_file_end()

    def go_to_matching_bracket(self) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()
        current_buffer_position = window.get_cursor_position()

        bks = renderer.find_matching_bracket(
            buffer.lines, current_buffer_position.y, current_buffer_position.x
        )

        if bks is not None:
            bk1, bk2 = bks

            if (
                bk1[0] == current_buffer_position.y
                and bk1[1] + 1 == current_buffer_position.x
            ):
                new_pos = CursorPosition(y=bk2[0], x=bk2[1] + 1)
            else:
                new_pos = CursorPosition(y=bk1[0], x=bk1[1] + 1)

            window.set_cursor_position(position=new_pos)

    def delete(self) -> None:
        """
        Delete the character *at* the cursor position (Delete key behavior).
        Uses BufferAction instead of directly modifying the buffer lines.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        if self.selection_start is not None:
            _clipboard = self.clipboard
            self.cut()  # delete selected region
            self.clipboard = _clipboard
            return None

        y, x = window.cursor_y, window.cursor_x
        lines = buffer.lines

        delete_text = ""

        if x < len(lines[y]):
            line = lines[y]
            delete_text = line[x]

            if x + 1 < len(line):
                left = line[x]
                right = line[x + 1]
                if key_mappings.PAIRS.get(left) == right:
                    delete_text = left + right

            cursor_pos = CursorPosition(y=y, x=x)

        elif y < len(lines) - 1:
            delete_text = "\n"
            cursor_pos = CursorPosition(y=y, x=len(lines[y]))

        else:
            curses.beep()
            return None

        action = BufferAction(
            action_type=BufferActionTypeEnum.DELETE,
            content=delete_text,
            cursor_position=cursor_pos,
        )

        self.apply_action_to_buffer(action)

        window.last_cursor_x = window.cursor_x
        window.adjust_cursor_position()

    def backspace(self) -> None:
        """
        Delete the character before the cursor (Backspace behavior).
        Uses BufferAction instead of directly modifying lines.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()

        if self.selection_start is not None:
            _clipboard = self.clipboard
            self.cut()
            self.clipboard = _clipboard
            return None

        y, x = window.cursor_y, window.cursor_x
        lines = buf.lines

        if y == 0 and x == 0:
            curses.beep()
            return None

        if x > 0:
            line = lines[y]

            if buf.insert_spaces:
                offsets = renderer.get_offsets(line, buf.tab_size)
                visual_col = offsets[x]

                prev_tab_stop = visual_col - (visual_col % buf.tab_size or buf.tab_size)
                spaces_to_delete = visual_col - prev_tab_stop

                start = x
                count = 0

                while start > 0 and count < spaces_to_delete and line[start - 1] == " ":
                    start -= 1
                    count += 1

                if count > 0:
                    delete_text = line[start:x]
                    cursor_pos = CursorPosition(y=y, x=start)

                    action = BufferAction(
                        action_type=BufferActionTypeEnum.DELETE,
                        content=delete_text,
                        cursor_position=cursor_pos,
                    )
                    self.apply_action_to_buffer(action)
                    return None

            left = line[x - 1]

            if x < len(line):
                right = line[x]

                if key_mappings.PAIRS.get(left) == right:
                    self.apply_action_to_buffer(
                        BufferAction(
                            action_type=BufferActionTypeEnum.DELETE,
                            content=right,
                            cursor_position=CursorPosition(y=y, x=x),
                        )
                    )

                    self.apply_action_to_buffer(
                        BufferAction(
                            action_type=BufferActionTypeEnum.DELETE,
                            content=left,
                            cursor_position=CursorPosition(y=y, x=x - 1),
                        )
                    )

                    curses.flushinp()
                    self.ensure_cursor_visible()
                    return None

            start = x - 1
            delete_text = line[start:x]
            cursor_pos = CursorPosition(y=y, x=start)

            action = BufferAction(
                action_type=BufferActionTypeEnum.DELETE,
                content=delete_text,
                cursor_position=cursor_pos,
            )
            self.apply_action_to_buffer(action)

        elif y > 0:
            delete_text = "\n"
            cursor_pos = CursorPosition(y=y - 1, x=len(lines[y - 1]))

            action = BufferAction(
                action_type=BufferActionTypeEnum.DELETE,
                content=delete_text,
                cursor_position=cursor_pos,
            )
            self.apply_action_to_buffer(action)

        curses.flushinp()
        self.ensure_cursor_visible()

    def newline(self, disable_auto_indent: bool = False) -> None:
        """
        Split current line at cursor into two lines and move cursor to the new line.
        Implemented as a single REPLACE BufferAction for undo/redo support.
        Prevents duplicated closing symbols (e.g. ')', '}', ']' or 'end').
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()
        y, x = window.cursor_y, window.cursor_x
        line = buffer.lines[y]
        before, after = line[:x], line[x:]

        _m = re.match(r"\s*", before)
        indent = _m.group(0) if _m is not None else ""
        extra = ""
        moved_closers = ""
        remainder_tail = after

        def one_indent() -> str:
            if buffer.insert_spaces:
                return " " * buffer.tab_size
            else:
                return "\t"

        if disable_auto_indent:
            indent = ""
            extra = ""
        else:
            opener = before.strip().lower().endswith(("{", "[", "(", ":", "begin"))
            if opener:
                extra = one_indent()

                m = re.match(
                    r"(\s*)(?:([)\]\}]+)|(end\b))(.*)$",
                    after,
                    flags=re.IGNORECASE,
                )
                if m:
                    leading_ws, closers_run, end_kw, rest = m.groups()

                    if closers_run:
                        moved_closers = closers_run
                        remainder_tail = leading_ws + rest
                    elif end_kw:
                        moved_closers = end_kw
                        remainder_tail = leading_ws + rest

        old_text = after

        if moved_closers:
            new_text = (
                "\n" + indent + extra + "\n" + indent + moved_closers + remainder_tail
            )
        else:
            new_text = "\n" + indent + extra + remainder_tail

        action = BufferAction(
            action_type=BufferActionTypeEnum.REPLACE,
            content=(old_text, new_text),
            cursor_position=CursorPosition(y=y, x=x),
        )

        self.apply_action_to_buffer(action)

        window.cursor_y = y + 1
        window.cursor_x = len(indent + extra)
        window.last_cursor_x = window.cursor_x
        window.adjust_cursor_position()

        curses.flushinp()

    async def insert_char(self, ch: str, disable_autocomplete: bool = False) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        original_ch = ch

        action = buf_actions.insert_char(buffer, ch, disable_autocomplete)

        self.apply_action_to_buffer(action)

        if isinstance(action.content, str):
            ch = action.content

        if len(ch) > 1:
            window.cursor_x -= 1

        window.adjust_cursor_position()

        if not disable_autocomplete:
            if (
                buffer.suffix is not None
                and (lsp_client := get_lsp(buffer.suffix)) is not None
            ):
                if original_ch in lsp_client.triggerCharacters and original_ch not in (
                    " ",
                    "\t",
                    "\n",
                ):
                    await self.lsp_completion(trigger=original_ch)

            elif original_ch == ".":
                await self.show_suggestions()

    async def search_prompt(self) -> None:
        """
        Prompt user for search term.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        current_cur_position = window.get_cursor_position()
        current_scroll = window.scroll

        current_last_search = self.last_search
        current_last_search_re = self.last_search_re

        def on_change(pattern: str) -> None:
            try:
                window.set_cursor_position(current_cur_position)
                if pattern:
                    self.last_search = pattern
                    self.last_search_re = None
                    self.search_re(silent=True)
                    self.adjust_scroll()
                    self.request_redraw()
                else:
                    self.last_search = None
                    self.last_search_re = None
                    self.adjust_scroll()
                    self.request_redraw()

            except Exception:
                pass

        scrolloff_old = config.STATIC_CONFIG.get("scrolloff", 0)
        config.STATIC_CONFIG["scrolloff"] = 8
        try:
            search_term = await self.send_prompt(
                "Search: ",
                history=self.search_history,
                on_change=on_change,
                debounce_ms=100,
            )

        finally:
            config.STATIC_CONFIG["scrolloff"] = scrolloff_old

        window.set_cursor_position(current_cur_position)
        window.scroll = current_scroll

        self.last_search = current_last_search
        self.last_search_re = current_last_search_re

        if search_term:
            if search_term not in self.search_history:
                self.search_history.append(search_term)
            else:
                self.search_history.remove(search_term)
                self.search_history.append(search_term)

            self.last_search = search_term
            self.last_search_re = None
            self.search_re()

    def search_word_under_cursor(self) -> None:
        """
        Grab the word under the cursor (or selected text if single-line),
        set it as last_search, and invoke search().
        """

        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()
        self.last_search_re = None

        if self.selection_start:
            start_row, start_col = self.selection_start
            end_row, end_col = window.cursor_y, window.cursor_x

            if (start_row, start_col) > (end_row, end_col):
                start_row, start_col, end_row, end_col = (
                    end_row,
                    end_col,
                    start_row,
                    start_col,
                )

            if start_row == end_row:
                line = buf.lines[start_row]
                selected_text = line[start_col:end_col]

                if selected_text:
                    if selected_text not in self.search_history:
                        self.search_history.append(selected_text)
                    else:
                        self.search_history.remove(selected_text)
                        self.search_history.append(selected_text)

                    self.last_search = re.escape(selected_text)
                    self.search_re()
                    return None

        line = buf.lines[window.cursor_y]
        x = window.cursor_x

        left = line[:x]
        right = line[x:]

        m1 = re.search(r"\w+$", left)
        m2 = re.match(r"\w+", right)

        word = ""
        if m1:
            word += m1.group(0)
        if m2:
            word += m2.group(0)

        if not word:
            self.send_notification("No word under cursor", 800)
            return None

        if word not in self.search_history:
            self.search_history.append(word)
        else:
            self.search_history.remove(word)
            self.search_history.append(word)

        self.last_search = word
        self.search_re()

    def search(self, silent: bool = False) -> None:
        """
        Search for `self.last_search` in the current buffer, _excluding_
        any match that covers the cursor position on the current line.
        Wraps around once to the top if needed.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()
        term = self.last_search

        if not term:
            if silent == False:
                self.send_notification("No search term provided", 500)
            return None

        term = term.lower()

        y, x = window.cursor_y, window.cursor_x
        n = len(buf.lines)

        self.disable_search = False

        try:
            line = buf.lines[y].lower()
            idx = line.find(term, x + 1)
            if idx != -1:
                window.cursor_y = y
                window.cursor_x = idx
                return None

            for i in range(y + 1, n):
                line = buf.lines[i].lower()
                idx = line.find(term)
                if idx != -1:
                    window.cursor_y = i
                    window.cursor_x = idx
                    return None

            for i in range(0, y):
                line = buf.lines[i].lower()
                idx = line.find(term)
                if idx != -1:
                    window.cursor_y = i
                    window.cursor_x = idx
                    return None
        finally:
            window.last_cursor_x = window.cursor_x

        if silent == False:
            self.send_notification("No match found")

    def search_re(self, backwards: bool = False, silent: bool = False) -> None:
        """
        Search for `self.last_search` in the current buffer using `re` (regex),
        excluding matches that include the cursor position.
        Supports forward (default) and backward search with wrapping.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()
        pattern = self.last_search

        if not pattern:
            if silent == False:
                self.send_notification("No search term provided", 500)
            return None

        y, x = window.cursor_y, window.cursor_x
        n = len(buf.lines)
        self.disable_search = False

        if self.last_search_re is None:
            try:
                regex = re.compile(pattern, re.IGNORECASE)
                self.last_search_re = regex
            except Exception:
                self.last_search_re = None
                self.search(silent=silent)
                return None
        else:
            regex = self.last_search_re

        try:

            if not backwards:
                line_text = buf.lines[y]
                for match in regex.finditer(line_text):
                    if match.start() > x:
                        window.cursor_y = y
                        window.cursor_x = match.start()
                        return None

                for i in range(y + 1, n):
                    line_text = buf.lines[i]
                    match_s = regex.search(line_text)
                    if match_s:
                        window.cursor_y = i
                        window.cursor_x = match_s.start()
                        return None

                for i in range(0, y):
                    line_text = buf.lines[i]
                    match_s = regex.search(line_text)
                    if match_s:
                        window.cursor_y = i
                        window.cursor_x = match_s.start()
                        return None
            else:
                line_text = buf.lines[y]
                prev_match = None
                for match in regex.finditer(line_text):
                    if match.start() < x:
                        prev_match = match
                    else:
                        break
                if prev_match:
                    window.cursor_y = y
                    window.cursor_x = prev_match.start()
                    return None

                for i in range(y - 1, -1, -1):
                    line_text = buf.lines[i]
                    matches = list(regex.finditer(line_text))
                    if matches:
                        window.cursor_y = i
                        window.cursor_x = matches[-1].start()
                        return None

                for i in range(n - 1, y, -1):
                    line_text = buf.lines[i]
                    matches = list(regex.finditer(line_text))
                    if matches:
                        window.cursor_y = i
                        window.cursor_x = matches[-1].start()
                        return None
        finally:
            window.last_cursor_x = window.cursor_x

        if silent == False:
            self.send_notification("No match found")

    async def go_to_line_prompt(self) -> None:
        """
        Prompt user for line number to jump to.
        """
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        _line_number = await self.send_prompt("Goto: ")

        if _line_number.isdigit():

            bufffer_len = len(buffer.lines)
            line_number = int(_line_number) - 1

            if line_number < 0:
                line_number = 0
            elif line_number >= bufffer_len:
                line_number = bufffer_len - 1

            if 0 <= line_number < bufffer_len:
                window.cursor_y = line_number
                window.cursor_x = max(
                    0,
                    min(
                        window.cursor_x,
                        len(buffer.lines[window.cursor_y]) - 1,
                    ),
                )
        else:

            self.send_notification("Invalid line number")

    def open_buffer(self, file_name: str) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        res = file_name.split(":")

        if len(res) == 4:
            file_name, _line, _col, message = res
            file = file_name.strip()
            line = int(_line.strip())
            col = int(_col.strip())

        elif len(res) == 3:
            file_name, _line, _col = res
            file = file_name.strip()
            line = int(_line.strip())
            col = int(_col.strip())
            message = ""
        elif len(res) == 2:
            file_name, _line = res
            file = file_name.strip()
            line = int(_line.strip())
            col = 1
            message = ""
        else:
            file = res[0].strip()
            line = 1
            col = 1
            message = ""

        buf_index = self.get_buffer_by_file_name(str(file))

        if buf_index != -1:
            buffer = self.buffers[buf_index]

        else:
            file_path = Path(file_name)

            if not file_path.exists():
                raise FileNotFoundError(f"File '{file_name}' does not exist.")

            buffer = Buffer(str(file_path), temp_dir=self.temp_dir)
            self.buffers.append(buffer)
            buf_index = len(self.buffers) - 1

        window.cursor_y = line - 1
        window.cursor_x = col - 1

        if message:
            buffer.diagnostics.append(
                diagnostics.Diagnostic(
                    line=window.cursor_y,
                    char=window.cursor_x,
                    code="E",
                    message=message,
                    severity=1,
                )
            )

        self.set_current_buffer(buf_index)

    async def open_buffer_prompt(self) -> None:
        """
        Prompt user for a file to open.
        """
        file_name = await self.send_prompt("Open file: ")

        if file_name:
            try:
                self.open_buffer(file_name)
            except Exception as e:
                self.send_notification(f"Error opening file: {e}", 2000)

    async def select_text_object_prefix(self) -> None:
        scope = await self.send_prompt(
            prompt_message="action (a|i): ",
            max_buffer_len=1,
        )

        if not scope or scope not in ("a", "i"):
            return None

        obj = await self.send_prompt(
            prompt_message="text object (w|\"|'|(|{|[|<|p): ",
            max_buffer_len=1,
            increment_macro_start=False,
        )

        if not obj:
            return None

        self.select_text_object(scope, obj)

    def select_text_object(self, scope: str, obj: str) -> None:
        if obj == "w":
            self._select_word(scope)
            return None

        if obj == "p":
            self._select_paragraph(scope)
            return None

        pairs = {
            "(": ("(", ")"),
            "{": ("{", "}"),
            "[": ("[", "]"),
            '"': ('"', '"'),
            "'": ("'", "'"),
            "<": ("<", ">"),
        }

        if obj in pairs:
            left, right = pairs[obj]
            self._select_delimited(scope, left, right)

    def _get_selection_bounds(self) -> tuple[tuple[int, int], tuple[int, int]] | None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()

        if self.selection_start is None:
            return None

        sy, sx = self.selection_start
        ey, ex = window.cursor_y, window.cursor_x

        if (ey, ex) < (sy, sx):
            sy, sx, ey, ex = ey, ex, sy, sx

        return (sy, sx), (ey, ex)

    def _has_selection(self) -> bool:
        bounds = self._get_selection_bounds()
        if not bounds:
            return False

        (sy, sx), (ey, ex) = bounds
        return (sy, sx) != (ey, ex)

    def _range_contains(
        self,
        outer: tuple[tuple[int, int], tuple[int, int]],
        inner: tuple[tuple[int, int], tuple[int, int]],
    ) -> bool:
        (osy, osx), (oey, oex) = outer
        (isy, isx), (iey, iex) = inner
        return (osy, osx) <= (isy, isx) and (iey, iex) <= (oey, oex)

    def _range_strictly_contains(
        self,
        outer: tuple[tuple[int, int], tuple[int, int]],
        inner: tuple[tuple[int, int], tuple[int, int]],
    ) -> bool:
        return self._range_contains(outer, inner) and outer != inner

    def _range_size_key(self, r) -> tuple[int, int, int, int, int, int]:
        (sy, sx), (ey, ex) = r
        return (ey - sy, ex - sx, sy, sx, ey, ex)

    def _set_selection_absolute(
        self, start: tuple[int, int], end: tuple[int, int]
    ) -> None:
        window = self.window_manager.last_base_focused

        if window is None:
            return None

        self.selection_start = start

        window.cursor_y, window.cursor_x = end
        window.last_cursor_x = window.cursor_x

    def _make_selection_bounds(
        self, scope: str, sy: int, sx: int, ey: int, ex: int
    ) -> tuple[tuple[int, int], tuple[int, int]]:
        if scope == "i":
            sx += 1
        else:
            ex += 1
        return (sy, sx), (ey, ex)

    def _apply_delimited_selection(
        self, scope: str, sy: int, sx: int, ey: int, ex: int
    ) -> None:
        start, end = self._make_selection_bounds(scope, sy, sx, ey, ex)
        self._set_selection_absolute(start, end)

    def _is_escaped(self, line: str, i: int) -> bool:
        backslashes = 0
        j = i - 1
        while j >= 0 and line[j] == "\\":
            backslashes += 1
            j -= 1
        return (backslashes % 2) == 1

    def _is_word_char(self, ch: str) -> bool:
        return ch.isalnum() or ch == "_"

    def _select_word(self, scope: str) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()
        line = buf.lines[window.cursor_y]
        x = window.cursor_x

        for m in re.finditer(r"\w+", line):
            start, end = m.span()

            if start <= x < end:
                if scope == "a":
                    if start > 0 and line[start - 1].isspace():
                        start -= 1
                    if end < len(line) and line[end].isspace():
                        end += 1

                self.selection_start = (window.cursor_y, start)
                window.cursor_x = end
                window.last_cursor_x = window.cursor_x
                return None

    def _select_paragraph(self, scope: str) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()
        y = window.cursor_y
        lines = buf.lines
        n = len(lines)

        start = y
        end = y

        while start > 0 and lines[start].strip():
            start -= 1

        if not lines[start].strip():
            start += 1

        while end < n and lines[end].strip():
            end += 1

        if scope == "a":
            if start > 0:
                start -= 1
            if end < n:
                end += 1

        self.selection_start = (start, 0)
        window.cursor_y = max(start, min(end, n - 1))
        window.cursor_x = 0
        window.last_cursor_x = 0

    def _select_delimited(self, scope: str, left: str, right: str) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()
        lines = buf.lines

        if not lines:
            return None

        selection_bounds = (
            self._get_selection_bounds() if self._has_selection() else None
        )

        if selection_bounds:
            expanded = self._find_expanded_delimited(
                scope, left, right, selection_bounds
            )
            if expanded:
                self._set_selection_absolute(expanded[0], expanded[1])
                return None

        y = window.cursor_y
        x = window.cursor_x

        result = self._find_delimited_same_line(lines[y], x, left, right)
        if result:
            sx, ex = result
            self._apply_delimited_selection(scope, y, sx, y, ex)
            return None

        if left == right:
            return None

        result_m = self._find_delimited_multiline(lines, y, x, left, right)
        if result_m:
            (sy, sx), (ey, ex) = result_m
            self._apply_delimited_selection(scope, sy, sx, ey, ex)

    def _find_expanded_delimited(
        self,
        scope: str,
        left: str,
        right: str,
        current_selection: tuple[tuple[int, int], tuple[int, int]],
    ) -> tuple[tuple[int, int], tuple[int, int]] | None:
        buf = self.get_current_buffer()
        lines = buf.lines
        inner = current_selection
        (csy, csx), (cey, cex) = inner

        candidates = []

        if left == right:
            if csy != cey:
                return None

            line = lines[csy]
            pairs = self._find_all_same_line_pairs(line, left, right)

            for a, b in pairs:
                sel = self._make_selection_bounds(scope, csy, a, csy, b)
                if self._range_strictly_contains(sel, inner):
                    candidates.append(sel)

            if not candidates:
                return None

            return min(candidates, key=self._range_size_key)

        for (sy, sx), (ey, ex) in self._find_all_multiline_pairs(lines, left, right):
            sel = self._make_selection_bounds(scope, sy, sx, ey, ex)
            if self._range_strictly_contains(sel, inner):
                candidates.append(sel)

        if not candidates:
            return None

        return min(candidates, key=self._range_size_key)

    def _find_delimited_same_line(
        self, line: str, x: int, left: str, right: str
    ) -> tuple[int, int] | None:
        """
        Search the whole current line and choose the best candidate:
        1) smallest pair containing cursor
        2) nearest pair to the left
        3) nearest pair to the right
        """
        if not line:
            return None

        x = max(0, min(x, len(line) - 1))

        pairs = self._find_all_same_line_pairs(line, left, right)
        if not pairs:
            return None

        if left == right:
            containing = [(a, b) for a, b in pairs if a < x < b]
        else:
            containing = [(a, b) for a, b in pairs if a <= x <= b]

        if containing:
            return min(containing, key=lambda t: (t[1] - t[0], t[0]))

        exact = [(a, b) for a, b in pairs if a == x or b == x]
        if exact:
            return min(exact, key=lambda t: (t[1] - t[0], t[0]))

        left_side = [(a, b) for a, b in pairs if b < x]
        if left_side:
            return max(left_side, key=lambda t: (t[1], t[0]))

        right_side = [(a, b) for a, b in pairs if a > x]
        if right_side:
            return min(right_side, key=lambda t: (t[0], t[1]))

        return None

    def _find_all_same_line_pairs(
        self, line: str, left: str, right: str
    ) -> list[tuple[int, int]]:
        if not line:
            return []

        if left == right:
            quote_positions = []

            for i, c in enumerate(line):
                if c != left:
                    continue

                if self._is_escaped(line, i):
                    continue

                if left == "'":
                    prev_ch = line[i - 1] if i > 0 else ""
                    next_ch = line[i + 1] if i + 1 < len(line) else ""
                    if self._is_word_char(prev_ch) and self._is_word_char(next_ch):
                        continue

                quote_positions.append(i)

            pairs = []
            i = 0
            while i + 1 < len(quote_positions):
                pairs.append((quote_positions[i], quote_positions[i + 1]))
                i += 2

            return pairs

        stack = []
        pairs = []

        for i, c in enumerate(line):
            if c == left:
                stack.append(i)
            elif c == right and stack:
                start = stack.pop()
                pairs.append((start, i))

        return pairs

    def _find_delimited_multiline(
        self, lines: Sequence[str | RichString], y: int, x: int, left: str, right: str
    ) -> tuple[tuple[int, int], tuple[int, int]] | None:
        start = None
        depth = 0

        for row in range(y, -1, -1):
            line = lines[row]

            if not line:
                continue

            if row == y:
                i = min(x, len(line) - 1)
            else:
                i = len(line) - 1

            while i >= 0:
                c = line[i]

                if c == left:
                    if depth == 0:
                        start = (row, i)
                        break
                    depth -= 1
                elif c == right:
                    depth += 1

                i -= 1

            if start:
                break

        if not start:
            return None

        sy, sx = start
        depth = 0
        end = None

        for row in range(sy, len(lines)):
            line = lines[row]

            if row == sy:
                i = sx + 1
            else:
                i = 0

            while i < len(line):
                c = line[i]

                if c == right:
                    if depth == 0:
                        end = (row, i)
                        break
                    depth -= 1
                elif c == left:
                    depth += 1

                i += 1

            if end:
                break

        if not end:
            return None

        return start, end

    def _find_all_multiline_pairs(
        self, lines: Sequence[str | RichString], left: str, right: str
    ) -> list[tuple[tuple[int, int], tuple[int, int]]]:
        pairs = []
        stack = []

        for row, line in enumerate(lines):
            for col, c in enumerate(line):
                if c == left:
                    stack.append((row, col))
                elif c == right and stack:
                    start = stack.pop()
                    pairs.append((start, (row, col)))

        return pairs

    def page_up(self) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.page_up(window.viewport_height)

    def page_down(self) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.page_down(window.viewport_height)

    def move_scroll(self, direction: int, move_cursor: bool = True) -> None:
        if (window := self.window_manager.last_base_focused) is not None:
            window.move_scroll(direction, window.viewport_height, move_cursor)

    def run_code_with_eval(
        self, code: str, timeout: int = 20
    ) -> tuple[Any, str] | None:
        from concurrent import interpreters

        interp = interpreters.create()
        interp_queue = cast(Queue[Any], interpreters.create_queue())

        try:
            t = interp.call_in_thread(_run_code, code, interp_queue)
            t.join(timeout=timeout)

            result = interp_queue.get(timeout=10)

            return result

        except Exception as e:
            self.send_multiline_notification(f"{e}\n{traceback.format_exc()}", -1)

        finally:
            interp.close()

        return None

    async def show_line_diagnostics(self) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buffer = self.get_current_buffer()

        y, x = window.get_cursor_position()

        diags = []

        for d in getattr(buffer, "diagnostics", []):
            if d.line == y:
                diags.extend(
                    textwrap.wrap(f"{d.code}:{d.message}", int(self.width / 2))
                )

        text = "\n".join(diags)

        await self.open_file_in_less_mode(file_handle=StringIO(text))

    def get_prefix(self) -> str:
        window = self.window_manager.last_base_focused
        if window is None:
            return ""

        buf = self.get_current_buffer()

        prefix = ""

        try:
            left = buf.lines[window.cursor_y][: window.cursor_x]
            m_obj = re.search(r"(\w+)\.$", left)
            if not m_obj:
                m_pref = re.search(r"\b\w+$", left)
                if m_pref:
                    prefix = m_pref.group(0)
        except Exception as e:
            self.send_notification(
                f"Error getting the prefix, \n{traceback.format_exc()}"
            )

        return prefix

    async def show_suggestions(self, lsp_matches: Optional[set[str]] = None) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()

        if lsp_matches is None:
            lsp_matches = set()

            full_text = "\n".join(
                line
                for buffer in self.buffers
                if not buffer.first
                for line in buffer.get_lines()
            )
        else:
            full_text = "\n".join(buf.get_lines())

        line = buf.lines[window.cursor_y]
        left = line[: window.cursor_x]

        prefix = ""

        text_matches = set()
        file_matches = set()

        m_obj = re.search(r"(\w+)\.$", left)
        if m_obj:
            obj_name = m_obj.group(1)
            members = set(re.findall(rf"\b{re.escape(obj_name)}\.(\w+)\b", full_text))
            text_matches = members
        else:
            m_pref = re.search(r"\b\w+$", left)
            if m_pref:
                prefix = m_pref.group(0)

            words = set(re.findall(r"\b\w+\b", full_text))
            text_matches = {w for w in words if w.startswith(prefix) and w != prefix}

        in_string = re.search(r'(["\'])([^"\']*)$', left)

        if in_string:
            file_prefix = in_string.group(2)

            working_dir = str(config.WORKING_DIR)

            base_dir = None

            buffer_dir = None

            if hasattr(buf, "file_path"):
                if getattr(buf, "file_path", None):
                    buffer_dir = str(buf.file_path.parent)

            if file_prefix.startswith("./") and buffer_dir:
                base_dir = buffer_dir

            else:
                dirpart = os.path.dirname(file_prefix)

                if dirpart:
                    if os.path.isabs(dirpart):
                        base_dir = dirpart

                    else:
                        base_dir = os.path.abspath(os.path.join(working_dir, dirpart))
                else:
                    base_dir = working_dir

            if not os.path.isdir(base_dir):
                base_dir = working_dir

            try:
                for name in os.listdir(base_dir):
                    if name.startswith("."):
                        continue

                    path = os.path.join(base_dir, name)

                    if name.startswith(os.path.basename(file_prefix)):
                        if os.path.isdir(path):
                            file_matches.add(name + "/")
                        else:
                            file_matches.add(name)
            except Exception:
                pass

        lsp_matches = {f"{m} - lsp" for m in lsp_matches}
        file_matches = {f"{m} - file" for m in file_matches}
        text_matches = {f"{m} - text" for m in text_matches}

        matches = [*lsp_matches, *file_matches, *text_matches]

        if not matches or len(matches) == 0 or not any(bool(m) for m in matches):
            return

        def filtering_controller(
            query: str, choises: list[dict[str, Any]]
        ) -> list[dict[str, Any]]:
            """
            Custom filtering callback used by the picker.
            Unlike compare_func-based filtering, this preserves fuzzy behavior and caching.
            """
            _choises = [el["display"] for el in choises]

            if not query:
                return _choises

            return fzf_fuzzy_find(query=query, choices=_choises, limit=-1)

        break_chars = None

        if buf.suffix is not None and (lsp_client := get_lsp(buf.suffix)) is not None:
            break_chars = lsp_client.triggerCharacters.copy()

            for ch in string.punctuation:
                if ch == "_":
                    continue

                break_chars.add(ch)

        async def callback_func(selected) -> None:
            if selected is not None:
                choice = selected.split("-")[0].strip()

                if len(prefix) > 0:
                    cur_pos = window.get_cursor_position()

                    rep_pos = CursorPosition(y=cur_pos.y, x=cur_pos.x - len(prefix))

                    action = BufferAction(
                        action_type=BufferActionTypeEnum.REPLACE,
                        content=(prefix, choice),
                        cursor_position=rep_pos,
                    )
                else:
                    action = BufferAction(
                        action_type=BufferActionTypeEnum.INSERT,
                        content=choice,
                        cursor_position=window.get_cursor_position(),
                    )

                self.apply_action_to_buffer(action)

            self.adjust_scroll()

        await self.show_picker_display(
            entries=matches,
            display_func=lambda x: x,
            compare_func=lambda x, q: True,
            position=window.get_cursor_position_display(),
            max_height=15,
            initial_query=prefix if prefix else None,
            return_query=True,
            break_chars=break_chars,
            external_filter=filtering_controller,
            callback_func=callback_func,
        )

    async def show_file_picker(self) -> None:
        root = os.getcwd()

        needs_rescan = (
            self.fuzzy_changed or self.working_dir_mtime != self.get_working_dir_mtime()
        )

        if needs_rescan:
            self.send_notification(
                f"Scanning for {self.working_dir.absolute()} for changes...", 200
            )
            self.working_dir_mtime = self.get_working_dir_mtime()

        all_files = file_discovery.collect_files_with_gitignore(
            root, self.fuzzy_search, needs_rescan
        )

        self.fuzzy_search = all_files
        self.fuzzy_changed = False

        def filtering_controller(
            query: str, choises: list[dict[str, Any]]
        ) -> list[dict[str, Any]]:
            """
            Custom filtering callback used by the picker.
            Unlike compare_func-based filtering, this preserves fuzzy behavior and caching.
            """
            _choises = [el["display"] for el in choises]

            if not query:
                return _choises

            return fzf_fuzzy_find(query=query, choices=_choises)

        async def callback_func(selected):
            if not selected or selected == "<no matches>":
                return None

            full_path = os.path.abspath(os.path.join(root, selected))
            cwd = os.getcwd()

            rel = os.path.relpath(full_path, cwd)

            for buffer_index, buf in enumerate(self.buffers):
                if buf.file_name and buf.file_name == rel:
                    self.set_current_buffer(buffer_index)
                    self.send_notification(f"Switched to buffer: {selected}")
                    return None

            self.open_buffer(rel)
            self.send_notification(f"Opened file: {selected}")

        await self.show_picker_display(
            entries=all_files,
            display_func=lambda x: x,
            compare_func=lambda x, q: True,
            external_filter=filtering_controller,
            debounce_ms=400,
            callback_func=callback_func,
        )

    async def show_theme_picker(self) -> None:
        """
        Use the generic picker to select buffers.
        """

        if not self.syntax_enable or len(themes.default.BUILDIN_THEMES.keys()) <= 0:
            self.send_notification("Can not apply themes.")
            return

        def display(theme_name: Any) -> str:
            return str(theme_name)

        def compare(theme_name: Any, query: str) -> bool:
            if not query:
                return True
            return query.lower() in display(theme_name).lower()

        def selection_change(theme_name: Optional[Any] = None) -> None:
            if (
                theme_name is not None
                and isinstance(theme_name, str)
                and theme_name != "random"
            ):
                themes.default.BUILDIN_THEMES[theme_name].apply_theme()

        prev_theme = config.STATIC_CONFIG.get("current_theme", "default")

        async def callback_func(choice):
            if choice is not None and choice:
                if choice == "random":
                    choice = themes.default.pick_random_theme(name_only=True)

                config.STATIC_CONFIG["current_theme"] = choice
                themes.default.BUILDIN_THEMES[str(choice)].apply_theme()
                save_static_config()

            else:
                themes.default.BUILDIN_THEMES[prev_theme].apply_theme()

        await self.show_picker_display(
            entries=[*sorted(list(themes.default.BUILDIN_THEMES.keys())), "random"],
            display_func=display,
            compare_func=compare,
            selection_change=selection_change,
            callback_func=callback_func,
        )

    async def show_buffer_picker(self) -> None:
        """
        Use the generic picker to select buffers.
        """

        if not self.buffers:
            self.send_notification("No buffers open.", 1000)
            return

        def display(buf):
            return buf.file_name or "[No Name]"

        async def callback_func(choice):
            if choice is not None:
                for i, buf in enumerate(self.buffers):
                    if buf is choice:
                        self.set_current_buffer(i)
                        self.send_notification(f"Switched to: {display(buf)}")
                        break

        await self.show_picker_display(
            entries=self.buffers,
            display_func=display,
            callback_func=callback_func,
        )

    async def show_ai_completion_picker(self) -> None:
        all_ai_completions = list(
            itertools.chain.from_iterable(
                buf.ai_completions for buf in self.buffers if not buf.first
            )
        )

        if not all_ai_completions:
            self.send_notification("There is no ai completions to show", 1000)
            return None

        def display(c):
            return (
                str(self.ai_completion_manager.get_job(c.code))[: self.width]
                or "[No Name]"
            )

        async def callback_func(choice) -> None:
            window = self.window_manager.last_base_focused
            if window is None:
                return None

            if choice is not None:
                self.request_redraw()

                output = self.ai_completion_manager.get_result(choice.code)

                found = False

                for i, b in enumerate(self.buffers):
                    if b.first:
                        continue

                    for bc in b.ai_completions:
                        if bc.code == choice.code:
                            self.set_current_buffer(i)
                            window.set_cursor_position(
                                CursorPosition(y=choice.line, x=choice.char)
                            )
                            found = True
                            break

                    if found:
                        break

                if output:
                    output = output.strip("\n")

                    await self.open_file_in_less_mode(file_handle=StringIO(output))

        await self.show_picker_display(
            entries=all_ai_completions,
            display_func=display,
            callback_func=callback_func,
        )

    async def show_ai_model_picker(self) -> None:
        models = completions.get_available_models()

        if not models:
            self.send_notification("There is no ai models install.", 1000)
            return None

        async def callback_func(choice):
            if choice is not None:
                config.STATIC_CONFIG["model"] = choice

        await self.show_picker_display(entries=models, callback_func=callback_func)

    async def show_command_picker(self) -> None:
        def _display(cmd):
            return f"{cmd["name"]}: {cmd["description"]}"

        cmds = [
            {"name": key, "description": value.description}
            for key, value in commands.COMMANDS.items()
        ]

        async def callback_func(choice):
            if choice is not None:
                await commands.command_mode_mappings(self, command=choice["name"])

        await self.show_picker_display(
            entries=cmds, display_func=_display, callback_func=callback_func
        )

    async def show_jump_picker(self) -> None:
        if not self.jump_list:
            self.send_notification("There is not jumps recorded.")

        def _display(j):
            return f"{j.buffer_name}, y={j.position.y}, x={j.position.x}, timestamp={int(j.timestamp)}"

        async def callback_func(jump):
            window = self.window_manager.last_base_focused
            if window is None:
                return None

            if jump is not None:
                self.disable_record_jump = True

                buffer_index = self.get_buffer_by_file_name(jump.buffer_name)

                if buffer_index == -1:
                    self.send_notification("Buffer not found.")
                    return None

                self.set_current_buffer(buffer_index)

                window.set_cursor_position(position=jump.position)

        await self.show_picker_display(
            entries=list(reversed(self.jump_list)),
            display_func=_display,
            callback_func=callback_func,
        )

    def go_to_jump(self, direction: int) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        if not self.jump_list:
            self.send_notification("There is not jumps recorded.")

        jump = None

        if direction > 0:
            if self.jump_index >= len(self.jump_list) - 1:
                return None

            self.jump_index += 1

            jump = self.jump_list[self.jump_index]

        else:
            if self.jump_index <= 0:
                return None

            if (
                self.jump_index == len(self.jump_list)
                and self.last_jump is not None
                and self.last_jump != self.jump_list[self.jump_index - 1]
            ):
                self.jump_list.append(self.last_jump)
                self.jump_index -= 2
            else:
                self.jump_index -= 1

            jump = self.jump_list[self.jump_index]

        if jump is not None:
            self.disable_record_jump = True

            buffer_index = self.get_buffer_by_file_name(jump.buffer_name)

            if buffer_index == -1:
                self.send_notification("Buffer not found.")
                return None

            self.set_current_buffer(buffer_index)

            window.set_cursor_position(position=jump.position)

    async def show_references_picker(self, references: list[dict]) -> None:
        """
        Use the generic picker to select buffers.
        """
        if not references:
            return None

        if not self.buffers:
            self.send_notification("No buffers open.", 1000)
            return

        def display(buf: dict[str, Any]) -> str:
            display_line = "[No Name]"
            match buf:
                case {
                    "uri": uri,
                    "range": {
                        "start": {
                            "line": start_line,
                            "character": start_char,
                        },
                        "end": _,
                    },
                }:

                    file_path = self.get_path_from_uri(uri)

                    if file_path is None:
                        return display_line

                    file_name = file_path.relative_to(Path.cwd())

                    buf_index = self.get_buffer_by_file_name(str(file_name))

                    if buf_index != -1:
                        buffer = self.buffers[buf_index]
                        display_line = f"{buffer.file_name}[{start_line}] - {buffer.lines[start_line]}"

                case _:
                    pass

            return display_line

        def compare(buf, query):
            if not query:
                return True
            return query.lower() in display(buf).lower()

        async def callback_func(choice) -> None:
            window = self.window_manager.last_base_focused
            if window is None:
                return None

            if choice is not None:
                for i, ref in enumerate(references):
                    if ref is choice:
                        match ref:
                            case {
                                "uri": uri,
                                "range": {
                                    "start": {
                                        "line": start_line,
                                        "character": start_char,
                                    },
                                    "end": _,
                                },
                            }:

                                _file_path = self.get_path_from_uri(uri)

                                if _file_path is None:
                                    self.send_notification(
                                        "Could not find the reference."
                                    )
                                    return None

                                file_name = _file_path.relative_to(Path.cwd())
                                buf_index = self.get_buffer_by_file_name(str(file_name))

                                if buf_index == -1:
                                    new_buffer = Buffer(
                                        file_name=str(file_name),
                                        temp_dir=self.temp_dir,
                                    )
                                    self.buffers.append(new_buffer)
                                    self.set_current_buffer(len(self.buffers) - 1)
                                else:
                                    self.set_current_buffer(buf_index)

                                # buffer = self.get_current_buffer()

                                window.cursor_y = start_line
                                window.cursor_x = start_char
                            case _:
                                self.send_notification(
                                    "Error: Invalid definition result format."
                                )

                        break

        await self.show_picker_display(
            entries=references,
            display_func=display,
            compare_func=compare,
            callback_func=callback_func,
        )

    async def show_picker_display(
        self,
        entries: list[Any],
        display_func: Optional[Callable[[Any], str]] = None,
        compare_func: Optional[Callable[[Any, str], bool]] = None,
        external_filter: Optional[
            Callable[[str, list[dict[str, Any]]], list[dict[str, Any]]]
        ] = None,
        selection_change: Optional[Callable[[Optional[Any]], None]] = None,
        debounce_ms: Optional[int] = None,
        increment_macro_start: bool = True,
        position: Optional[tuple[int, int]] = None,
        max_height: Optional[int] = None,
        return_query: bool = False,
        break_chars: Optional[set[str]] = None,
        initial_query: Optional[str] = None,
        callback_func: Optional[Callable[[Optional[Any]], Awaitable[None]]] = None,
    ) -> None:
        """
        Dynamic picker UI (scrollable, searchable).

        Event-driven version:
        - Non-blocking
        - Result delivered via callback
        """

        if not entries or callback_func is None:
            return None

        picker = PickerWindow(
            manager=self.window_manager,
            stdscr=self.stdscr,
            entries=entries,
            display_func=display_func,
            compare_func=compare_func,
            external_filter=external_filter,
            selection_change=selection_change,
            debounce_ms=debounce_ms,
            increment_macro_start=increment_macro_start,
            position=position,
            max_height=max_height,
            return_query=return_query,
            break_chars=break_chars,
            initial_query=initial_query,
            on_result=callback_func,
            editor=self,
        )

        await self.window_manager.push_overlay(picker)

    def go_next_buffer(self) -> None:
        window = self.window_manager.focused

        if isinstance(window, windows.BufferWindow):

            if len(self.buffers) <= 1:
                self.send_notification("No more buffers")

            if (window.current_buffer + 1) >= len(self.buffers):
                window.current_buffer = 0
            else:
                window.current_buffer += 1

    def go_prev_buffer(self) -> None:
        window = self.window_manager.focused

        if isinstance(window, windows.BufferWindow):
            if len(self.buffers) <= 1:
                self.send_notification("No more buffers")

            if (window.current_buffer - 1) < 0:
                window.current_buffer = len(self.buffers) - 1
            else:
                window.current_buffer -= 1

    def go_to_last_buffer(self) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        self.change_modes(mode="NORMAL")

        if self.last_buffer < 0 or self.last_buffer >= len(self.buffers):
            self.last_buffer = self.get_current_buffer_index_window()

        self.set_current_buffer(self.last_buffer)
        window.adjust_cursor_position()

    async def close_buffer(self) -> None:
        buffer = self.get_current_buffer()

        if not await self.send_prompt_confirm(
            (
                "This buffer have unsave changes, are you sure you want to close it?"
                if buffer.modified
                else "Do you want o close this buffer?"
            ),
            color_p=15,
        ):
            return None

        buffer.undo_manager.cleanup()

        if len(self.buffers) > 1:
            if buffer.suffix is not None:
                lsp_client = get_lsp(buffer.suffix)

                if lsp_client:
                    lsp_client.did_close(get_uri_from_name(buffer.file_name))

            del self.buffers[self.get_current_buffer_index_window()]

            self.set_current_buffer(
                min(self.get_current_buffer_index_window(), len(self.buffers) - 1)
            )
        else:
            self.new_buffer_count += 1

            new_buffer = Buffer(
                f"Untitled-{self.new_buffer_count}",
                new_buffer_untitled=True,
                temp_dir=self.temp_dir,
            )

            self.buffers[self.get_current_buffer_index_window()] = new_buffer

    def select_hole_file(self) -> None:
        window = self.window_manager.last_base_focused
        if window is None:
            return None

        buf = self.get_current_buffer()

        self.selection_start = (0, 0)

        window.cursor_x = len(buf.lines[-1])
        window.cursor_y = len(buf.lines) - 1

    async def record_macro(self) -> None:
        if self.recording_macro and self.current_macro_recording is not None:
            self.recording_macro = False
            self.macros[self.current_macro_recording].pop()
            self.current_macro_recording = None
            return None

        macro_name = await self.send_prompt("record macro: ")

        if not macro_name:
            return None

        if len(macro_name.split()) > 1:
            self.send_notification("Not a valid name")
            return None

        self.macros[macro_name] = []
        self.recording_macro = True
        self.current_macro_recording = macro_name

    async def exec_macro(self) -> None:
        macro_name = await self.send_prompt("exec macro: ")

        if not macro_name:
            return None

        args = macro_name.split()

        if len(args) > 1:
            macro_name = args[0]
            times = int(args[1])
        else:
            macro_name = args[0]
            times = 1

        def check_cancel() -> bool:
            # self.stdscr.timeout(0)
            self.stdscr.nodelay(True)
            ch = self.stdscr.getch()

            if ch == 27:  # ESC
                return True

            return False

        if macro_name in self.macros:
            steps = self.macros.get(macro_name, [])
            self.current_macro_playing_name = macro_name
            step_count = len(steps)

            original_escdelay = curses.get_escdelay()
            curses.set_escdelay(1)

            try:
                if (
                    await self.send_prompt_confirm(
                        "\n".join(
                            f"{i}. {str(s)}" for i, s in enumerate(steps, start=1)
                        )
                        + f"\nMacro {macro_name=}, {step_count=} will be executed {times=}, Press ESC to stop execution after it has started, continue?",
                    )
                    == False
                ):
                    return None

                for _ in range(times):

                    self.current_macro_playing_index = None

                    for index, step in enumerate(steps):

                        if check_cancel():
                            return None

                        if (
                            self.current_macro_playing_index is not None
                            and self.current_macro_playing_name is not None
                            and index < self.current_macro_playing_index
                        ):
                            continue

                        self.current_macro_playing_index = index
                        await self.process_key(step)
                        self.adjust_scroll()
                        self.request_redraw()

            except Exception as e:
                self.send_multiline_notification(
                    f"Error: {e},\n{traceback.format_exc()}", 0
                )

            finally:
                self.current_macro_playing_name = None
                self.current_macro_playing_index = None
                curses.set_escdelay(original_escdelay)
