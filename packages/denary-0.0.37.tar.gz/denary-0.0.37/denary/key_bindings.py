from __future__ import annotations

import curses
import os
import re
import signal
import time
from typing import TYPE_CHECKING, Awaitable, Callable

from denary import commands, events, file_explorer, renderer
from denary.config import CURRENT_PLATFORM
from denary.events import Event, EventType
from denary.horizontal_scrolling import visual_to_logical_x
from denary.windows import BufferWindow

if TYPE_CHECKING:
    from denary.editor import SimpleEditor

type Key = int | str
type Mode = str
type KeyHandler = Callable[[SimpleEditor], Awaitable[None]]

KEY_MAPPING: dict[Mode, dict[Key, KeyHandler]] = {}


def keybind(*keys: Key, modes: tuple[Mode, ...] = ("NORMAL",)):
    def decorator(func: KeyHandler) -> KeyHandler:
        for mode in modes:
            mode_map = KEY_MAPPING.setdefault(mode, {})

            for key in keys:
                if key in mode_map:
                    raise ValueError(
                        f"Duplicate key mapping: mode={mode!r}, key={key!r}"
                    )

                mode_map[key] = func

        return func

    return decorator


@keybind("Right", modes=("NORMAL", "INSERT"))
async def _key_right(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor("Right")


@keybind("Left", modes=("NORMAL", "INSERT"))
async def _key_left(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor("Left")


@keybind("Up", modes=("NORMAL", "INSERT"))
async def _key_up(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor("Up")


@keybind("Down", modes=("NORMAL", "INSERT"))
async def _key_down(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor("Down")


@keybind("l", modes=("NORMAL",))
async def _key_l(editor: SimpleEditor) -> None:
    editor.move_cursor("Right")


@keybind("h", modes=("NORMAL",))
async def _key_h(editor: SimpleEditor) -> None:
    editor.move_cursor("Left")


@keybind("k", modes=("NORMAL",))
async def _key_k(editor: SimpleEditor) -> None:
    editor.move_cursor("Up")


@keybind("j", modes=("NORMAL",))
async def _key_j(editor: SimpleEditor) -> None:
    editor.move_cursor("Down")


@keybind("i", modes=("NORMAL",))
async def _key_i(editor: SimpleEditor) -> None:
    editor.change_modes("INSERT")


@keybind("a", modes=("NORMAL",))
async def _key_a(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor("Right")
    editor.change_modes("INSERT")


@keybind("A", modes=("NORMAL",))
async def _key_A(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor_start_of_line()
    editor.move_cursor_by_punctuation("right")
    editor.change_modes("INSERT")


@keybind("o", modes=("NORMAL",))
async def _key_o(editor: SimpleEditor) -> None:
    if editor.selection_start:
        editor.toggle_selection_start()
    else:
        editor.change_modes(mode="INSERT")
        editor.move_cursor_end_of_line()
        editor.newline()


@keybind("O", modes=("NORMAL",))
async def _key_O(editor: SimpleEditor) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    editor.end_selection()
    editor.move_cursor("Up")
    editor.change_modes(mode="INSERT")

    if window.cursor_y == 0:
        editor.move_cursor_start_of_line()
        editor.newline()
        editor.move_cursor("Up")
    else:
        editor.move_cursor_end_of_line()
        editor.newline()


@keybind("s", modes=("NORMAL",))
async def _key_s(editor: SimpleEditor) -> None:
    await editor.select_text_object_prefix()


@keybind("c", modes=("NORMAL",))
async def _key_c(editor: SimpleEditor) -> None:
    editor.change_modes("INSERT")
    editor.delete()


@keybind("x", modes=("NORMAL",))
async def _key_x(editor: SimpleEditor) -> None:
    editor.change_modes("INSERT")
    editor.cut()


@keybind("d", modes=("NORMAL",))
async def _key_d(editor: SimpleEditor) -> None:
    editor.cut()


@keybind(":", modes=("NORMAL",))
async def _key_colon(editor: SimpleEditor) -> None:
    await commands.command_mode_mappings(editor)


@keybind("v", modes=("NORMAL",))
async def _key_v(editor: SimpleEditor) -> None:
    editor.toggle_selection()


@keybind("V", modes=("NORMAL",))
async def _key_V(editor: SimpleEditor) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    if not editor.selection_start:
        if window.cursor_y != len(editor.get_current_buffer().lines) - 1:
            editor.move_cursor_start_of_line()
            editor.toggle_selection()
            editor.move_cursor("Down")
        else:
            editor.move_cursor_end_of_line()
            editor.toggle_selection()
            editor.move_cursor_start_of_line()
    else:
        if window.cursor_y != len(editor.get_current_buffer().lines) - 1:
            editor.toggle_selection()
            editor.move_cursor_start_of_line()
            editor.move_cursor("Up")
        else:
            editor.toggle_selection()
            editor.move_cursor_start_of_line()


@keybind("y", modes=("NORMAL",))
async def _key_y(editor: SimpleEditor) -> None:
    editor.copy()
    editor.end_selection()


@keybind("u", modes=("NORMAL",))
async def _key_u(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.undo()


@keybind("U", modes=("NORMAL",))
async def _key_U(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.redo()


@keybind(">", modes=("NORMAL",))
async def _key_gt(editor: SimpleEditor) -> None:
    editor.change_indentation(direction=1)


@keybind("<", modes=("NORMAL",))
async def _key_lt(editor: SimpleEditor) -> None:
    editor.change_indentation(direction=-1)


@keybind("Alt+/", modes=("NORMAL", "INSERT"))
async def _key_alt_slash(editor: SimpleEditor) -> None:
    editor.toggle_comment_selection()


@keybind("K", modes=("NORMAL",))
async def _key_K(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.lsp_hover()


@keybind(";", modes=("NORMAL",))
async def _key_semicolon(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.lsp_definition()


@keybind("T", modes=("NORMAL",))
async def _key_T(editor: SimpleEditor) -> None:
    await commands.command_mode_mappings(editor, command=editor.command_history[-1])


@keybind("0", modes=("NORMAL",))
async def _key_0(editor: SimpleEditor) -> None:
    editor.move_cursor_start_of_line()


@keybind("$", modes=("NORMAL",))
async def _key_dollar(editor: SimpleEditor) -> None:
    editor.move_cursor_end_of_line()


@keybind("Ctrl+A", modes=("NORMAL", "INSERT"))
async def _key_ctrl_a(editor: SimpleEditor) -> None:
    editor.select_hole_file()


@keybind("n", modes=("NORMAL",))
async def _key_n(editor: SimpleEditor) -> None:
    editor.search_re()


@keybind("N", modes=("NORMAL",))
async def _key_N(editor: SimpleEditor) -> None:
    editor.search_re(backwards=True)


@keybind("*", modes=("NORMAL",))
async def _key_star(editor: SimpleEditor) -> None:
    editor.search_word_under_cursor()
    editor.end_selection()


@keybind("p", modes=("NORMAL",))
async def _key_p(editor: SimpleEditor) -> None:
    editor.paste()


@keybind("P", modes=("NORMAL",))
async def _key_P(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor_start_of_line()
    editor.move_cursor("Down")
    editor.newline()
    editor.move_cursor("Up")
    editor.paste()


@keybind("Ctrl+P", modes=("NORMAL",))
async def _key_ctrl_p(editor: SimpleEditor) -> None:
    editor.paste_from_system_clipboard()


@keybind("Alt+r", modes=("NORMAL",))
async def _key_alt_r(editor: SimpleEditor) -> None:
    editor.lsp_references()


@keybind("Alt+w", modes=("NORMAL", "INSERT"))
async def _key_alt_w(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.change_modes("NORMAL")
    await editor.show_file_picker()


@keybind("Alt+i", modes=("NORMAL",))
async def _key_alt_i(editor: SimpleEditor) -> None:
    editor.go_to_jump(direction=-1)


@keybind("Alt+o", modes=("NORMAL",))
async def _key_alt_o(editor: SimpleEditor) -> None:
    editor.go_to_jump(direction=1)


@keybind("m", modes=("NORMAL",))
async def _key_m(editor: SimpleEditor) -> None:
    editor.end_selection()
    await editor.set_marker()


@keybind("M", modes=("NORMAL",))
async def _key_M(editor: SimpleEditor) -> None:
    editor.end_selection()
    await editor.pick_markers()


@keybind("'", modes=("NORMAL",))
async def _key_tick(editor: SimpleEditor) -> None:
    await editor.manage_registers()


@keybind("`", modes=("NORMAL",))
async def _key_backtick(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.go_to_last_buffer()


@keybind("PageUp", modes=("NORMAL", "INSERT"))
async def _key_pageup(editor: SimpleEditor) -> None:
    editor.page_up()


@keybind("PageDown", modes=("NORMAL", "INSERT"))
async def _key_pagedown(editor: SimpleEditor) -> None:
    editor.page_down()


@keybind("g", modes=("NORMAL",))
async def _key_g(editor: SimpleEditor) -> None:
    editor.go_to_file_start()


@keybind("G", modes=("NORMAL",))
async def _key_G(editor: SimpleEditor) -> None:
    editor.go_to_file_end()


@keybind("H", modes=("NORMAL",))
async def _key_H(editor: SimpleEditor) -> None:
    editor.page_up()


@keybind("L", modes=("NORMAL",))
async def _key_L(editor: SimpleEditor) -> None:
    editor.page_down()


@keybind("Ctrl+Up", modes=("NORMAL",))
async def _key_ctrl_up(editor: SimpleEditor) -> None:
    editor.page_up()


@keybind("Ctrl+Down", modes=("NORMAL",))
async def _key_ctrl_down(editor: SimpleEditor) -> None:
    editor.page_down()


@keybind("J", modes=("NORMAL",))
async def _key_J(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.merge_lines()


@keybind("Ctrl+X", modes=("NORMAL",))
async def _key_ctrl_x(editor: SimpleEditor) -> None:
    await editor.show_command_picker()


@keybind("Q", modes=("NORMAL",))
async def _key_Q(editor: SimpleEditor) -> None:
    await editor.show_line_diagnostics()


@keybind("q", modes=("NORMAL",))
async def _key_q(editor: SimpleEditor) -> None:
    await editor.record_macro()


@keybind("@", modes=("NORMAL",))
async def _key_at(editor: SimpleEditor) -> None:
    await editor.exec_macro()


@keybind("Alt+k", modes=("NORMAL",))
async def _key_alt_k(editor: SimpleEditor) -> None:
    editor.move_scroll(-1)


@keybind("Alt+j", modes=("NORMAL",))
async def _key_alt_j(editor: SimpleEditor) -> None:
    editor.move_scroll(1)


@keybind("e", modes=("NORMAL",))
async def _key_e(editor: SimpleEditor) -> None:
    editor.move_cursor_by_punctuation("right")


@keybind("w", modes=("NORMAL",))
async def _key_w(editor: SimpleEditor) -> None:
    editor.move_cursor_by_punctuation("right")


@keybind("W", modes=("NORMAL",))
async def _key_W(editor: SimpleEditor) -> None:
    editor.move_cursor_by_word("right")


@keybind("E", modes=("NORMAL",))
async def _key_E(editor: SimpleEditor) -> None:
    editor.move_cursor_by_word("right")


@keybind("b", modes=("NORMAL",))
async def _key_b(editor: SimpleEditor) -> None:
    editor.move_cursor_by_punctuation("left")


@keybind("B", modes=("NORMAL",))
async def _key_B(editor: SimpleEditor) -> None:
    editor.move_cursor_by_word("left")


@keybind("f", modes=("NORMAL",))
async def _key_f(editor: SimpleEditor) -> None:
    await editor.find_char()


@keybind("F", modes=("NORMAL",))
async def _key_F(editor: SimpleEditor) -> None:
    await editor.find_char(forward=False)


@keybind("[", modes=("NORMAL",))
async def _key_open_bracket(editor: SimpleEditor) -> None:
    editor.move_cursor_by_empty_line(-1)


@keybind("]", modes=("NORMAL",))
async def _key_close_bracket(editor: SimpleEditor) -> None:
    editor.move_cursor_by_empty_line(1)


@keybind("Ctrl+Right", modes=("NORMAL", "INSERT"))
async def _key_ctrl_right(editor: SimpleEditor) -> None:
    editor.move_cursor_by_punctuation("right")


@keybind("Ctrl+Left", modes=("NORMAL", "INSERT"))
async def _key_ctrl_left(editor: SimpleEditor) -> None:
    editor.move_cursor_by_punctuation("left")


@keybind("Ctrl+I", modes=("NORMAL",))
async def _key_ctrl_i(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.go_next_buffer()


@keybind(353, modes=("NORMAL",))
async def _key_353(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.go_prev_buffer()


@keybind("Ctrl+D", modes=("NORMAL",))
async def _key_ctrl_d(editor: SimpleEditor) -> None:
    editor.end_selection()
    await editor.close_buffer()


@keybind("Ctrl+O", modes=("NORMAL", "INSERT"))
async def _key_ctrl_o(editor: SimpleEditor) -> None:
    editor.end_selection()
    await editor.open_buffer_prompt()


@keybind("/", modes=("NORMAL",))
async def _key_slash(editor: SimpleEditor) -> None:
    editor.end_selection()
    await editor.search_prompt()


@keybind("%", modes=("NORMAL",))
async def _key_percent(editor: SimpleEditor) -> None:
    editor.go_to_matching_bracket()


@keybind("Alt+;", modes=("INSERT",))
async def _key_alt_semicolon(editor: SimpleEditor) -> None:
    editor.toggle_selection()


@keybind("Alt+Right", "Alt+.", modes=("INSERT",))
async def _key_alt_indent_right(editor: SimpleEditor) -> None:
    editor.change_indentation(direction=1)


@keybind("Alt+Left", "Alt+,", modes=("INSERT",))
async def _key_alt_indent_left(editor: SimpleEditor) -> None:
    editor.change_indentation(direction=-1)


@keybind("Alt+h", modes=("INSERT",))
async def _key_alt_h(editor: SimpleEditor) -> None:
    editor.move_cursor("Left")


@keybind("Alt+j", modes=("INSERT",))
async def _key_alt_j_move(editor: SimpleEditor) -> None:
    editor.move_cursor("Down")


@keybind("Alt+k", modes=("INSERT",))
async def _key_alt_k_move(editor: SimpleEditor) -> None:
    editor.move_cursor("Up")


@keybind("Alt+l", modes=("INSERT",))
async def _key_alt_l(editor: SimpleEditor) -> None:
    editor.move_cursor("Right")


@keybind("Alt+9", modes=("INSERT",))
async def _key_alt_9(editor: SimpleEditor) -> None:
    editor.move_cursor_start_of_line()


@keybind("Alt+0", modes=("INSERT",))
async def _key_alt_0(editor: SimpleEditor) -> None:
    editor.move_cursor_end_of_line()


@keybind("Alt+[", modes=("INSERT",))
async def _key_alt_open_bracket(editor: SimpleEditor) -> None:
    editor.end_selection()
    await editor.set_marker()


@keybind("Alt+'", modes=("INSERT",))
async def _key_alt_quote(editor: SimpleEditor) -> None:
    await editor.manage_registers()


@keybind("Alt+Up", modes=("INSERT",))
async def _key_alt_up_scroll(editor: SimpleEditor) -> None:
    editor.move_scroll(-1)


@keybind("Alt+Down", modes=("INSERT",))
async def _key_alt_down_scroll(editor: SimpleEditor) -> None:
    editor.move_scroll(1)


@keybind("Ctrl+Up", modes=("INSERT",))
async def _key_ctrl_up_empty(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor_by_empty_line(-1)


@keybind("Ctrl+Down", modes=("INSERT",))
async def _key_ctrl_down_empty(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor_by_empty_line(1)


@keybind("Ctrl+Alt+Right", modes=("INSERT",))
async def _key_ctrl_alt_right(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor_by_word("right")


@keybind("Ctrl+Alt+Left", modes=("INSERT",))
async def _key_ctrl_alt_left(editor: SimpleEditor) -> None:
    editor.end_selection()
    editor.move_cursor_by_word("left")


@keybind("Shift+Right", modes=("INSERT",))
async def _key_shift_right(editor: SimpleEditor) -> None:
    editor.start_selection()
    editor.move_cursor("Right")


@keybind("Shift+Left", modes=("INSERT",))
async def _key_shift_left(editor: SimpleEditor) -> None:
    editor.start_selection()
    editor.move_cursor("Left")


@keybind("Shift+Up", modes=("INSERT",))
async def _key_shift_up(editor: SimpleEditor) -> None:
    editor.start_selection()
    editor.move_cursor("Up")


@keybind("Shift+Down", modes=("INSERT",))
async def _key_shift_down(editor: SimpleEditor) -> None:
    editor.start_selection()
    editor.move_cursor("Down")


@keybind("Ctrl+Shift+Right", modes=("INSERT",))
async def _key_ctrl_shift_right(editor: SimpleEditor) -> None:
    editor.start_selection()
    editor.move_cursor_by_punctuation("right")


@keybind("Ctrl+Shift+Left", modes=("INSERT",))
async def _key_ctrl_shift_left(editor: SimpleEditor) -> None:
    editor.start_selection()
    editor.move_cursor_by_punctuation("left")


@keybind("Alt+o", modes=("INSERT",))
async def _key_alt_o_punc(editor: SimpleEditor) -> None:
    editor.move_cursor_by_punctuation("right")


@keybind("Alt+i", modes=("INSERT",))
async def _key_alt_i_punc(editor: SimpleEditor) -> None:
    editor.move_cursor_by_punctuation("left")


# this area the ones that where in the process key function as if statements


@keybind("Ctrl+C", "ESC", 27, modes=("NORMAL", "INSERT"))
async def _key_escape_to_normal(editor: SimpleEditor) -> None:
    editor.change_modes(mode="NORMAL")


@keybind(0, "\x00", modes=("NORMAL", "INSERT"))
async def _key_ctrl_space(editor: SimpleEditor) -> None:
    await editor.lsp_completion()


def _select_word_under_cursor(
    window: BufferWindow,
    buf,
    y: int,
    x: int,
) -> None:
    if not (0 <= y < len(buf.lines)):
        return

    line = buf.lines[y]
    text = str(line)

    x = max(0, min(x, len(text)))

    left = text[:x]
    right = text[x:]

    m1 = re.search(r"\w+$", left)
    m2 = re.match(r"\w+", right)

    if not m1 and not m2:
        return

    sel_start = m1.start() if m1 else x
    sel_end = x + m2.end() if m2 else x

    window.selection_start = (y, sel_start)
    window.cursor_y = y
    window.cursor_x = sel_end
    window.last_cursor_x = sel_end


@keybind(curses.KEY_MOUSE, modes=("NORMAL", "INSERT"))
async def handle_mouse(editor: SimpleEditor) -> None:
    try:
        _, mx, my, _, bstate = curses.getmouse()
    except Exception:
        return None

    manager = editor.window_manager
    window = manager.window_at(mx, my)

    if window is None:
        return None

    # Only BufferWindow supports text editing mouse behavior
    if not isinstance(window, BufferWindow):
        return None

    if window.win is None:
        return None

    await manager.set_focus(window)

    local_x = mx - window.rect.x
    local_y = my - window.rect.y

    if local_x < 0 or local_y < 0:
        return None

    if local_x >= window.rect.width or local_y >= window.rect.height:
        return None

    buf = editor.buffers[window.current_buffer]

    total_lines = len(buf.lines)

    if total_lines <= 0:
        return None

    visible_rows = max(1, window.viewport_height - 1)
    max_scroll = max(0, total_lines - visible_rows)

    # ------------------------------------------------------------
    # Mouse wheel
    # ------------------------------------------------------------

    wheel_amount = 3

    if bstate & curses.BUTTON4_PRESSED:
        # window.scroll = max(0, window.scroll - wheel_amount)
        editor.move_scroll(-wheel_amount)

        if not editor.mouse_button_down:
            window.selection_start = None

        return None

    if bstate & curses.BUTTON5_PRESSED:
        # window.scroll = min(max_scroll, window.scroll + wheel_amount)
        editor.move_scroll(wheel_amount)

        if not editor.mouse_button_down:
            window.selection_start = None

        return None

    # Ignore clicks in status bar / non-text area
    if local_y >= visible_rows:
        return None

    # ------------------------------------------------------------
    # Convert mouse screen position to buffer position
    # ------------------------------------------------------------

    y = window.scroll + local_y
    y = max(0, min(y, total_lines - 1))

    gutter_width = 0

    if hasattr(editor, "get_gutter_width"):
        gutter_width = editor.get_gutter_width(buf)
    elif editor.gutter_render:
        # Fallback only. Prefer a pure get_gutter_width() method.
        gutter_width = len(str(max(1, total_lines))) + 1

    mx_buf = local_x - gutter_width

    if mx_buf < 0:
        mx_buf = 0

    line = buf.lines[y]

    target_visual_x = window.h_scroll + mx_buf

    x = visual_to_logical_x(
        line,
        target_visual_x,
        buf.tab_size,
    )

    x = max(0, min(x, len(line)))

    if x > 0 and not x == len(line):
        x -= 1

    editor.mouse_x = x
    editor.mouse_y = y

    # ------------------------------------------------------------
    # Left button pressed: start or continue selection
    # ------------------------------------------------------------

    if bstate & curses.BUTTON1_PRESSED:
        window.cursor_y = y
        window.cursor_x = x
        window.last_cursor_x = x

        if not editor.mouse_button_down:
            editor.mouse_button_down = True
            window.selection_start = (y, x)

        # Auto-scroll while dragging near pane edges
        if local_y <= 0:
            window.scroll = max(0, window.scroll - 1)

        elif local_y >= visible_rows - 1:
            window.scroll = min(max_scroll, window.scroll + 1)

        return None

    # ------------------------------------------------------------
    # Left button released: finish selection / detect double click
    # ------------------------------------------------------------

    if bstate & curses.BUTTON1_RELEASED:
        editor.mouse_button_down = False

        window.cursor_y = y
        window.cursor_x = x
        window.last_cursor_x = x

        clicked_without_drag = (
            window.selection_start is not None
            and y == window.selection_start[0]
            and x == window.selection_start[1]
        )

        if clicked_without_drag:
            window.selection_start = None

            time_elapsed = time.time() - editor.last_mouse_click

            if time_elapsed < 0.25:
                _select_word_under_cursor(window, buf, y, x)

        editor.last_mouse_click = time.time()

        return None


@keybind("Ctrl+W", modes=("NORMAL", "INSERT"))
async def _key_ctrl_w(editor: SimpleEditor) -> None:
    editor.stdscr.nodelay(True)

    explorer = file_explorer.ExplorerWindow(
        manager=editor.window_manager,
        editor=editor,
    )

    await editor.window_manager.push_overlay(explorer)


@keybind("Ctrl+L", modes=("NORMAL", "INSERT"))
async def _key_ctrl_l(editor: SimpleEditor) -> None:
    await editor.show_buffer_picker()


@keybind("Home", modes=("NORMAL", "INSERT"))
async def _key_home(editor: SimpleEditor) -> None:
    editor.go_to_file_start()


@keybind("End", modes=("NORMAL", "INSERT"))
async def _key_end(editor: SimpleEditor) -> None:
    editor.go_to_file_end()


@keybind("Delete", modes=("INSERT",))
async def _key_delete_insert(editor: SimpleEditor) -> None:
    editor.delete()


@keybind("Delete", modes=("NORMAL",))
async def _key_delete_normal(editor: SimpleEditor) -> None:
    editor.move_cursor("Left")


@keybind("Ctrl+G", modes=("NORMAL",))
async def _key_ctrl_g(editor: SimpleEditor) -> None:
    await editor.go_to_line_prompt()


@keybind(31, "\x1f", modes=("NORMAL", "INSERT"))
async def _key_ctrl_underscore(editor: SimpleEditor) -> None:
    await editor.show_file_picker()


@keybind("Ctrl+Q", modes=("NORMAL", "INSERT"))
async def _key_ctrl_q(editor: SimpleEditor) -> None:
    await editor.confirm_quit()


@keybind("Ctrl+S", modes=("NORMAL", "INSERT"))
async def _key_ctrl_s(editor: SimpleEditor) -> None:
    await editor.save_file()


@keybind("Ctrl+Z", modes=("NORMAL", "INSERT"))
async def _key_ctrl_z(editor: SimpleEditor) -> None:
    if not CURRENT_PLATFORM.startswith("win"):
        curses.cbreak()
        os.kill(os.getpid(), signal.SIGTSTP)
    else:
        editor.send_notification("SIGTSTP not supported on Windows.", 2000)


@keybind("Backspace", 127, 8, "Ctrl+H", modes=("INSERT",))
async def _key_backspace_insert(editor: SimpleEditor) -> None:
    editor.backspace()


@keybind("Enter", 10, 13, "Ctrl+J", "Ctrl+M", modes=("INSERT",))
async def _key_enter_insert(editor: SimpleEditor) -> None:
    if editor.selection_start:
        editor.backspace()
        editor.end_selection()

    editor.newline()


@keybind(9, "\t", "Ctrl+I", modes=("INSERT",))
async def _key_tab_insert(editor: SimpleEditor) -> None:
    window = editor.window_manager.last_base_focused
    if window is None:
        return None

    buffer = editor.get_current_buffer()
    line = buffer.lines[window.cursor_y]

    offsets = renderer.get_offsets(line, buffer.tab_size)

    visual_col = (
        offsets[window.cursor_x] if window.cursor_x < len(offsets) else offsets[-1]
    )

    if buffer.insert_spaces:
        spaces = buffer.tab_size - (visual_col % buffer.tab_size)
        for _ in range(spaces):
            await editor.insert_char(" ")
    else:
        await editor.insert_char("\t")


@keybind("Alt+Left", "Alt+n", modes=("NORMAL",))
async def _key_window_next(editor: SimpleEditor) -> None:
    commands.window_focus_next(editor)
    return None


@keybind("Alt+Right", "Alt+p", modes=("NORMAL",))
async def _key_window_previous(editor: SimpleEditor) -> None:
    commands.window_focus_previous(editor)
    return None


@keybind("Alt+q", modes=("NORMAL",))
async def _key_window_close(editor: SimpleEditor) -> None:
    commands.window_close(editor)
    return None
