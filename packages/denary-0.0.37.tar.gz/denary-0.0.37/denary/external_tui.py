from __future__ import annotations

import curses
import os
import pty
import re
import select
import subprocess
import sys
import tty
from typing import TYPE_CHECKING, Iterable, Optional

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


ANSI_ESCAPE_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


def is_inside_tmux():
    term = os.environ.get("TERM", "")
    return (
        os.environ.get("TMUX")
        or os.environ.get("TMUX_PANE")
        or term.startswith("screen")
        or term.startswith("tmux")
    )


def run_external_tui(
    editor: SimpleEditor,
    command: list[str],
    input_data: Optional[str] = None,
    env: Optional[dict] = None,
) -> None:
    if not command:
        return

    end_result = []
    is_tmux = is_inside_tmux()
    stdscr = editor.stdscr

    curses.curs_set(0)
    stdscr.nodelay(True)
    curses.set_escdelay(25)
    # stdscr.timeout(1)
    stdscr.clear()

    stdin_fd = sys.stdin.fileno()

    height, width = stdscr.getmaxyx()

    win = curses.newwin(height, width, 0, 0)

    master_fd, slave_fd = pty.openpty()

    tty.setraw(slave_fd)

    if env is None:
        env = {**os.environ}

    proc = subprocess.Popen(
        command,
        stdin=slave_fd,
        stdout=slave_fd,
        stderr=slave_fd,
        universal_newlines=False,
        env=env,
    )

    os.close(slave_fd)

    if input_data is not None:
        os.write(master_fd, input_data.encode("utf-8"))

    if is_tmux:
        win.erase()
        win.clear()
        win.refresh()

    try:
        while True:
            r, _, _ = select.select([master_fd, stdin_fd], [], [], 0.05)

            if r:
                try:
                    data = os.read(master_fd, 4096)
                except OSError:
                    break

                if stdin_fd in r:
                    try:
                        chunk = os.read(stdin_fd, 4096)
                        if chunk:
                            for b in chunk:
                                curses.ungetch(b)
                    except Exception:
                        pass

                win.move(0, 0)

                win.erase()

                try:
                    decoded = data.decode("utf-8", errors="ignore")
                    clean = ANSI_ESCAPE_RE.sub("", decoded)
                    win.addstr(clean)
                except Exception:
                    pass

                win.refresh()

            try:
                ch = stdscr.getch()
                if ch == 27:
                    proc.terminate()
                    try:
                        proc.wait(timeout=0.15)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                    break
                elif ch != -1:
                    os.write(master_fd, bytes([ch]))
            except Exception:
                pass

            if proc.poll() is not None:
                break

    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=0.15)
            except subprocess.TimeoutExpired:
                proc.kill()

        curses.endwin()

        try:
            while True:
                data = os.read(master_fd, 4096)

                if not data:
                    break

                end_result.append(data)
        except Exception:
            pass

        os.close(master_fd)

    stdscr = curses.initscr()
    curses.raw()
    curses.noecho()
    stdscr.keypad(True)
    stdscr.nodelay(True)
    curses.set_escdelay(25)
    curses.mousemask(curses.ALL_MOUSE_EVENTS | curses.REPORT_MOUSE_POSITION)
    curses.mouseinterval(40)
    curses.curs_set(1)

    stdscr.erase()
    stdscr.refresh()

    if is_tmux:
        sys.stdout.write("\033[H\033[2J")
        sys.stdout.flush()

    editor.stdscr = stdscr

    editor.request_redraw()

    editor.stdscr = stdscr


def run_external_tui_raw(
    editor: SimpleEditor,
    command: Iterable[str],
    input_data: Optional[str] = None,
    env: Optional[dict] = None,
    timeout: Optional[float] = None,
) -> tuple[int, str]:

    if not command:
        return 0, ""

    is_tmux = is_inside_tmux()
    stdscr = editor.stdscr
    stdscr.nodelay(True)
    curses.set_escdelay(25)
    # stdscr.timeout(1)
    stdscr.clear()

    end_result: list[bytes] = []

    try:
        curses.endwin()
    except Exception:
        pass

    master_fd, slave_fd = pty.openpty()

    if env is None:
        env = os.environ.copy()
    else:
        env = {**os.environ, **env}

    env.setdefault("TERM", os.environ.get("TERM", "xterm-256color"))
    stdin_r, stdin_w = os.pipe()

    if input_data is not None:
        os.write(stdin_w, input_data.encode("utf-8"))

    os.close(stdin_w)

    proc = subprocess.Popen(
        list(command),
        stdin=stdin_r if input_data is not None else slave_fd,
        stdout=slave_fd,
        stderr=slave_fd,
        env=env,
        close_fds=True,
    )

    os.close(stdin_r)
    os.close(slave_fd)

    try:
        while True:
            r, _, _ = select.select([master_fd], [], [], 0.05)

            if r:
                try:
                    data = os.read(master_fd, 4096)
                except OSError:
                    break

                if not data:
                    break

                try:
                    os.write(sys.stdout.fileno(), data)
                except OSError:
                    break

                end_result.append(data)

            if proc.poll() is not None:
                break

    finally:
        if proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=0.1)
            except:
                try:
                    proc.kill()
                except:
                    pass

        try:
            while True:
                data = os.read(master_fd, 4096)
                if not data:
                    break
                end_result.append(data)
        except:
            pass

        try:
            os.close(master_fd)
        except:
            pass

    sys.stdout.write("\033[H\033[2J\033[3J")
    sys.stdout.flush()

    stdscr = curses.initscr()
    curses.raw()
    curses.noecho()
    stdscr.keypad(True)
    stdscr.nodelay(True)
    curses.set_escdelay(25)
    curses.mousemask(curses.ALL_MOUSE_EVENTS | curses.REPORT_MOUSE_POSITION)
    curses.mouseinterval(40)
    curses.curs_set(1)

    stdscr.erase()
    stdscr.refresh()

    if is_tmux:
        sys.stdout.write("\033[H\033[2J")
        sys.stdout.flush()

    editor.stdscr = stdscr
    editor.request_redraw()

    decoded = b"".join(end_result).decode("utf-8", errors="ignore").replace("\x00", "�")
    clean_res = ANSI_ESCAPE_RE.sub("", decoded)

    return int(proc.returncode or 0), clean_res
