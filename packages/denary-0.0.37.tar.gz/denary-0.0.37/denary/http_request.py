from __future__ import annotations

import asyncio
import traceback
from io import StringIO
from typing import TYPE_CHECKING, Any, cast

from denary import events, http_client
from denary.events import Event, EventType

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


async def make_request_with_cancel_async(
    method: http_client.HttpVerbs,
    url: str,
    headers: dict[str, str],
    body: str,
    task_id: str,
) -> None:
    cancelled = False

    await events.EVENT_QUEUE.put(
        Event(
            EventType.HTTP_REQUEST_STARTED,
            {
                "task_id": task_id,
            },
        )
    )

    try:
        response = await http_client.ahttp_client(
            url=url,
            verb=method,
            headers=headers,
            body=body,
        )

    except asyncio.CancelledError:
        cancelled = True

    if cancelled:
        await events.EVENT_QUEUE.put(
            Event(
                EventType.HTTP_REQUEST_CANCELLED,
                {
                    "task_id": task_id,
                },
            )
        )
    else:
        await events.EVENT_QUEUE.put(
            Event(
                EventType.HTTP_REQUEST_COMPLETED,
                {
                    "response": response,
                    "task_id": task_id,
                },
            )
        )


def split_requests(text: str) -> list[str]:
    """
    Split a .http file into multiple request blocks using '###' separator.
    """
    blocks = []
    current: list[str] = []

    for line in text.splitlines():
        if line.strip().startswith("###"):
            if current:
                block = "\n".join(current).strip()
                if block:
                    blocks.append(block)
                current = []
            continue
        current.append(line)

    if current:
        block = "\n".join(current).strip()
        if block:
            blocks.append(block)

    return blocks


def parse_request_block(
    block: str,
) -> tuple[http_client.HttpVerbs, str, dict[str, str], str]:
    lines = block.splitlines()

    while lines and (not lines[0].strip() or lines[0].strip().startswith(("#", "//"))):
        lines.pop(0)

    if not lines:
        raise ValueError("No request line found")

    first_line = lines.pop(0).split("#", 1)[0].strip()
    method_str, url = first_line.split(maxsplit=1)
    method = http_client.HttpVerbs[method_str.upper()]

    headers = {}
    while lines:
        line = lines.pop(0)
        stripped = line.strip()

        if stripped == "":
            break

        if stripped.startswith(("#", "//")):
            continue

        if ":" not in line:
            raise ValueError(f"Invalid header format: {line}")

        k, v = line.split(":", 1)
        headers[k.strip()] = v.strip()

    body = "\n".join(lines).strip()

    return method, url, headers, body


async def handle_http_request_event(editor: SimpleEditor, event: Event) -> None:
    try:
        event_data = cast(dict[str, Any], event.data)

        match event.type:
            case EventType.HTTP_REQUEST_STARTED:
                task_id = event_data["task_id"]

                for t in editor.task_running:
                    if t["task_id"] == task_id:

                        t["status"] = "STARTED"
                        editor.send_notification_nowait(
                            f"HTTP request started: {t["method"]} {t["url"]}"
                        )

                        break

            case EventType.HTTP_REQUEST_COMPLETED:
                task_id = event_data["task_id"]

                for t in editor.task_running:
                    if t["task_id"] == task_id:
                        editor.send_notification_nowait(
                            f"HTTP request Completed: {t["method"]} {t["url"]}"
                        )
                        break

                await _process_http_request(editor, event)

            case EventType.HTTP_REQUEST_CANCELLED:
                task_id = event_data["task_id"]

                for t in editor.task_running:
                    if t["task_id"] == task_id:
                        editor.task_running.remove(t)
                        break

                editor.send_notification_nowait(f"HTTP request Canceled id={task_id}")

    except Exception as e:
        editor.send_notification(f"An eror has ocour {e}]\n{traceback.format_exc()}", 0)


async def _process_http_request(editor: SimpleEditor, event: Event) -> None:
    _data = cast(dict[str, Any], event.data)

    response = _data["response"]
    task_id = _data["task_id"]

    try:
        header_text = "\n".join(f"{k}: {v}" for k, v in response.headers.items())

        output = f"HTTP {response.status}\n"
        output += header_text
        output += "\n\n"
        output += response.text(errors="replace")

        await editor.open_file_in_less_mode(file_handle=StringIO(output))

    finally:
        response.close()

        for t in editor.task_running:
            if t["task_id"] == task_id:
                editor.task_running.remove(t)
                break
