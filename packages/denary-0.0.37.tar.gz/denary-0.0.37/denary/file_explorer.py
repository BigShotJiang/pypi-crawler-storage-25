from __future__ import annotations

import curses
import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from denary.events import Event, EventType
from denary.key_mappings import get_key_mapping
from denary.notifications import send_notification
from denary.windows import Rect, WindowManager

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


class ExplorerWindow:
    """
    Vim-style :Ex file explorer as a WindowManager window.

    Keys:
      Up/k       move up
      Down/j     move down
      Enter      open/descend
      a          new file/dir, dir ends with '/'
      d          delete
      r          rename
      m          move
      c          copy
      /          search, empty query clears search
      n          next match, wraps
      N          previous match, wraps
      g          top
      G          bottom
      q / Esc    close
    """

    def __init__(
        self,
        manager: WindowManager,
        editor: SimpleEditor,
        start_dir: Optional[str] = None,
    ):
        self.manager = manager
        self.editor = editor

        self.rect = Rect(0, 0, 0, 0)
        self.win: curses.window | None = None

        self.focused = False
        self.mounted = False

        buffer = editor.get_current_buffer()

        file_path = (
            buffer.file_path.parent
            if getattr(buffer, "file_name", None) and getattr(buffer, "file_path", None)
            else os.getcwd()
        )

        self.cwd = Path(start_dir or file_path).resolve()
        self.base = Path(start_dir or os.getcwd()).resolve()

        self.cursor = 0
        self.scroll = 0
        self.search_query = ""

        self.entries_full: list[str] = self.list_entries_full()
        self.display_entries: list[str] = self.apply_search(
            self.entries_full,
            self.search_query,
        )

        self.select_current_buffer_file()

    # ==========================================================
    # Overlay sizing
    # ==========================================================

    def preferred_overlay_rect(self, screen_rect: Rect) -> Rect:
        return Rect(
            x=0,
            y=0,
            width=screen_rect.width,
            height=screen_rect.height,
        )

    # ==========================================================
    # Lifecycle
    # ==========================================================

    async def on_mount(self) -> None:
        self.mounted = True

        if (
            self.editor.current_macro_playing_index is not None
            and self.editor.current_macro_playing_name is not None
        ):
            self.editor.current_macro_playing_index += 1

    async def on_unmount(self) -> None:
        self.mounted = False
        self.win = None

    async def on_focus(self) -> None:
        self.focused = True

        if self.win is not None:
            self.win.leaveok(False)

    async def on_blur(self) -> None:
        self.focused = False

        if self.win is not None:
            self.win.leaveok(True)

    # ==========================================================
    # Layout
    # ==========================================================

    def set_rect(self, rect: Rect) -> None:
        rect = rect.clamped()

        if self.rect == rect and self.win is not None:
            return

        self.rect = rect

        if rect.is_empty:
            self.win = None
            return

        try:
            self.win = self.manager.stdscr.derwin(
                rect.height,
                rect.width,
                rect.y,
                rect.x,
            )
            self.win.keypad(True)
            self.win.leaveok(not self.focused)

        except curses.error:
            self.win = None

    # ==========================================================
    # Safe filesystem helpers
    # ==========================================================

    def _is_relative_to(self, p: Path, base: Path) -> bool:
        try:
            p.relative_to(base)
            return True
        except Exception:
            return False

    def _safe_join(self, base: Path, child_name: str) -> Path:
        clean = child_name[:-1] if child_name.endswith("/") else child_name
        target = (base / clean).resolve()

        return target if self._is_relative_to(target, self.base) else base

    def _safe_is_dir(self, p: Path) -> bool:
        try:
            return p.is_dir()
        except (PermissionError, FileNotFoundError, OSError):
            return False

    def _exists_safe(self, p: Path) -> bool:
        try:
            return p.exists()
        except Exception:
            return False

    def _has_access_dir(self, p: Path) -> bool:
        try:
            return os.access(p, os.R_OK | os.X_OK)
        except Exception:
            return False

    def _has_access_file(self, p: Path) -> bool:
        try:
            return os.access(p, os.R_OK)
        except Exception:
            return False

    def ensure_valid_cwd(self) -> None:
        """
        Ensures self.cwd is still a valid directory inside self.base.

        This protects the explorer when the current directory was moved,
        deleted, renamed, or became inaccessible.
        """

        try:
            self.cwd = self.cwd.resolve()

            if (
                self._exists_safe(self.cwd)
                and self._safe_is_dir(self.cwd)
                and self._has_access_dir(self.cwd)
                and self._is_relative_to(self.cwd, self.base)
            ):
                return

        except Exception:
            pass

        p = self.cwd

        while True:
            try:
                p = p.parent.resolve()

                if (
                    self._exists_safe(p)
                    and self._safe_is_dir(p)
                    and self._has_access_dir(p)
                    and self._is_relative_to(p, self.base)
                ):
                    self.cwd = p
                    return

                if p == p.parent:
                    break

            except Exception:
                break

        self.cwd = self.base

    # ==========================================================
    # Entry list / search
    # ==========================================================

    def list_entries_full(self) -> list[str]:
        """
        Return the full, safe entry list for cwd.

        - '../' appears when cwd != base
        - directories get trailing '/'
        - directories sort before files
        """

        items: list[str] = []

        if self.cwd != self.base:
            items.append("../")

        try:
            with os.scandir(self.cwd) as it:
                bucket = []

                for entry in it:
                    try:
                        is_dir = entry.is_dir(follow_symlinks=False)
                    except (PermissionError, FileNotFoundError, OSError):
                        continue

                    name = entry.name + ("/" if is_dir else "")
                    bucket.append((not is_dir, entry.name.lower(), name))

            items.extend(name for _, __, name in sorted(bucket))

        except (PermissionError, FileNotFoundError, NotADirectoryError, OSError):
            return items

        return items

    def apply_search(self, all_items: list[str], q: str) -> list[str]:
        """
        Filter by case-insensitive substring.

        - empty query clears search
        - '../' is always kept
        """

        if not q:
            return list(all_items)

        ql = q.lower()
        out: list[str] = []

        for name in all_items:
            if name == "../":
                out.append(name)
                continue

            if ql in name.lower():
                out.append(name)

        return out

    def reload_entries(self, reset_position: bool = False) -> None:
        """
        Safely reload entries from the current directory.

        This prevents search from using stale entries after moving,
        renaming, deleting, or changing directories.
        """

        self.ensure_valid_cwd()

        self.entries_full = self.list_entries_full()
        self.display_entries = self.apply_search(
            self.entries_full,
            self.search_query,
        )

        if reset_position:
            self.cursor = 0
            self.scroll = 0

        self.clamp_cursor_scroll()

    def jump_to_first_match(self) -> None:
        if not self.search_query:
            return

        ql = self.search_query.lower()

        for i, name in enumerate(self.display_entries):
            if name != "../" and ql in name.lower():
                self.cursor = i

                if self.cursor < self.scroll or self.cursor >= self.scroll + self.win_h:
                    self.scroll = max(
                        0,
                        min(
                            self.cursor,
                            max(0, len(self.display_entries) - self.win_h),
                        ),
                    )

                return

    def next_match(self, backwards: bool = False) -> None:
        if not self.search_query or not self.display_entries:
            return

        ql = self.search_query.lower()
        n = len(self.display_entries)

        if n <= 1:
            return

        step = -1 if backwards else 1
        i = self.cursor

        for _ in range(n - 1):
            i = (i + step) % n
            name = self.display_entries[i]

            if name != "../" and ql in name.lower():
                self.cursor = i

                if self.cursor < self.scroll:
                    self.scroll = self.cursor
                elif self.cursor >= self.scroll + self.win_h:
                    self.scroll = self.cursor - self.win_h + 1

                self.clamp_cursor_scroll()
                return

    def select_current_buffer_file(self) -> None:
        current_buffer_path = None

        try:
            current_buffer_path = self.editor.get_current_buffer().file_path.resolve()
        except Exception:
            pass

        if not current_buffer_path:
            return

        for index, entry in enumerate(self.display_entries):
            if entry == "../":
                continue

            entry_path = self._safe_join(self.cwd, entry).resolve()

            if entry_path == current_buffer_path:
                self.cursor = index

                if self.cursor < self.scroll:
                    self.scroll = self.cursor
                elif self.cursor >= self.scroll + self.win_h:
                    self.scroll = max(0, self.cursor - self.win_h + 1)

                break

    # ==========================================================
    # Size helpers
    # ==========================================================

    @property
    def win_h(self) -> int:
        return max(1, self.rect.height - 3)

    @property
    def win_w(self) -> int:
        return max(1, self.rect.width - 4)

    @property
    def win_y(self) -> int:
        return 1

    @property
    def win_x(self) -> int:
        return 2

    @property
    def max_scroll(self) -> int:
        return max(0, len(self.display_entries) - self.win_h)

    def clamp_cursor_scroll(self) -> None:
        self.scroll = min(self.scroll, self.max_scroll)
        self.scroll = max(0, self.scroll)

        self.cursor = max(
            0,
            min(self.cursor, max(0, len(self.display_entries) - 1)),
        )

    # ==========================================================
    # Key helpers
    # ==========================================================

    def is_enter_key(self, key) -> bool:
        return key in (
            "Enter",
            "\n",
            "\r",
            10,
            13,
            343,
            "Ctrl+J",
            "Ctrl+M",
            curses.KEY_ENTER,
        )

    def is_escape_key(self, key) -> bool:
        return key in (
            27,
            "ESC",
            "Esc",
            "Escape",
        )

    # ==========================================================
    # Rendering
    # ==========================================================

    def render(self) -> None:
        if self.win is None:
            return

        try:
            self.clamp_cursor_scroll()

            self.win.erase()
            self.win.border()

            h = self.rect.height
            w = self.rect.width

            if h <= 2 or w <= 2:
                self.win.noutrefresh()
                return

            title = f" Current Path:  {self.cwd} "
            self.win.addnstr(0, 2, title, max(1, w - 4), curses.A_REVERSE)

            for idx in range(self.scroll, self.scroll + self.win_h):
                if idx >= len(self.display_entries):
                    break

                y = self.win_y + idx - self.scroll
                name = self.display_entries[idx]

                self.draw_row(
                    y=y,
                    name=name,
                    selected=(idx == self.cursor),
                )

            if self.search_query:
                status = (
                    f"[/] Search: {self.search_query}   "
                    "[n] Next  [N] Prev [a] New [d] Delete [r] Rename "
                    "[m] Move  [c] Copy  [q] Quit"
                )
            else:
                status = (
                    "[/] Search  [n] Next  [N] Prev  [a] New  [d] Delete  "
                    "[r] Rename  [m] Move  [c] Copy  [q] Quit"
                )

            self.win.addnstr(
                h - 2,
                2,
                status.ljust(self.win_w),
                self.win_w,
                curses.A_REVERSE,
            )

            self.win.noutrefresh()

        except curses.error:
            pass

    def draw_row(self, y: int, name: str, selected: bool) -> None:
        """
        Safe row drawing.

        Important:
        Searching for values like ".py" or "py" causes many rows to enter
        the highlighted drawing path. This version prevents a single curses
        boundary error from breaking the whole explorer render.
        """

        if self.win is None:
            return

        attr_normal = curses.A_NORMAL
        attr_sel = curses.A_REVERSE
        attr_match = curses.A_BOLD

        attr = attr_sel if selected else attr_normal

        max_x = self.win_x + self.win_w
        x = self.win_x

        def safe_add(text: str, draw_attr: int) -> None:
            nonlocal x
            window = self.win
            if window is None:
                return None

            if not text:
                return

            if x >= max_x:
                return

            remaining = max_x - x

            if remaining <= 0:
                return

            text = text[:remaining]

            try:
                window.addnstr(y, x, text, len(text), draw_attr)
                x += len(text)
            except curses.error:
                x = max_x

        if not self.search_query or name == "../":
            safe_add(name, attr)

            if x < max_x:
                safe_add(" " * (max_x - x), attr)

            return

        low = name.lower()
        ql = self.search_query.lower()
        k = low.find(ql)

        if k < 0:
            safe_add(name, attr)

            if x < max_x:
                safe_add(" " * (max_x - x), attr)

            return

        left = name[:k]
        mid = name[k : k + len(ql)]
        right = name[k + len(ql) :]

        safe_add(left, attr)
        safe_add(mid, attr | attr_match)
        safe_add(right, attr)

        if x < max_x:
            safe_add(" " * (max_x - x), attr)

    # ==========================================================
    # Event handling
    # ==========================================================

    async def handle_event(self, event: Event) -> bool:
        if event.type != EventType.KEY:
            return False

        editor = self.editor

        if (
            editor.current_macro_playing_index is not None
            and editor.current_macro_playing_name is not None
        ):
            macro = editor.macros.get(editor.current_macro_playing_name, [])

            if editor.current_macro_playing_index >= len(macro):
                key = None
            else:
                key = macro[editor.current_macro_playing_index]
                editor.current_macro_playing_index += 1

        else:
            key = event.data

            if (
                editor.recording_macro
                and editor.current_macro_recording is not None
                and key is not None
            ):
                editor.macros[editor.current_macro_recording].append(key)

        try:
            curses.flushinp()
        except curses.error:
            pass

        if key is None:
            return True

        if key in ("Up", "k"):
            self.cursor -= 1

            if self.cursor < self.scroll:
                self.scroll = max(0, self.scroll - 1)

        elif key in ("Down", "j"):
            self.cursor += 1

            if self.cursor >= self.scroll + self.win_h:
                self.scroll = min(self.max_scroll, self.scroll + 1)

        elif key == "g":
            self.cursor = 0
            self.scroll = 0

        elif key == "G":
            self.cursor = len(self.entries_full)
            self.scroll = self.max_scroll

        elif self.is_enter_key(key):
            await self.open_selected()

        elif key == "/":
            await self.search()

        elif key == "n":
            self.next_match(backwards=False)

        elif key == "N":
            self.next_match(backwards=True)

        elif key == "a":
            await self.create_entry()

        elif key == "d":
            await self.delete_entry()

        elif key == "r":
            await self.rename_entry()

        elif key == "c":
            await self.copy_entry()

        elif key == "m":
            await self.move_entry()

        elif key == "q" or key == "Ctrl+C" or self.is_escape_key(key):
            await self.close()

        self.clamp_cursor_scroll()
        return True

    # ==========================================================
    # Actions
    # ==========================================================

    def selected_name(self) -> str | None:
        if not self.display_entries:
            return None

        if self.cursor < 0 or self.cursor >= len(self.display_entries):
            return None

        return self.display_entries[self.cursor]

    async def open_selected(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice:
            return

        if choice == "../":
            parent = self.cwd.parent
            self.cwd = parent if self._is_relative_to(parent, self.base) else self.base
            self.reload_entries(reset_position=True)
            return

        target = self._safe_join(self.cwd, choice)

        if choice.endswith("/") or self._safe_is_dir(target):
            if self._safe_is_dir(target) and self._has_access_dir(target):
                self.cwd = target
                self.reload_entries(reset_position=True)
            else:
                self.notify(
                    message=f"Permission denied: {choice}",
                    duration=2000,
                )

            return

        if not self._has_access_file(target):
            self.notify(
                message=f"Permission denied: {choice}",
                duration=2000,
            )
            return

        try:
            rel = str(target.relative_to(self.base))
        except Exception:
            rel = str(target)

        for b_i, buf in enumerate(self.editor.buffers):
            try:
                if buf.file_name and (
                    buf.file_name == rel or Path(buf.file_name).resolve() == target
                ):
                    self.editor.set_current_buffer(b_i)

                    self.notify(
                        message=f"Switched to buffer: {choice}",
                    )

                    await self.close()
                    return

            except Exception:
                continue

        try:
            self.editor.open_buffer(rel)

            self.notify(
                message=f"Opened file: {choice}",
            )

            await self.close()

        except Exception as e:
            self.notify(
                message=f"Open failed: {e}",
                duration=0,
            )

    async def search(self) -> None:
        prompt = "Search (empty to clear): "

        q_in = await self.editor.send_prompt(prompt_message=prompt)

        self.search_query = q_in or ""

        # Important:
        # Do not filter stale entries. Re-read cwd first.
        self.reload_entries(reset_position=True)

        self.jump_to_first_match()
        self.clamp_cursor_scroll()

        # Important:
        # send_prompt() draws on stdscr. After it closes, force this overlay
        # to redraw so it does not appear to disappear.
        if self.win is not None:
            try:
                self.win.touchwin()
                self.render()
                curses.doupdate()
            except curses.error:
                pass

    async def create_entry(self) -> None:
        prompt = "New name (file or dir/): "

        name = await self.editor.send_prompt(
            prompt_message=prompt,
        )

        if name:
            new_path = self._safe_join(self.cwd, name)

            try:
                if name.endswith("/"):
                    new_path.mkdir(parents=True, exist_ok=True)
                else:
                    new_path.parent.mkdir(parents=True, exist_ok=True)

                    if not self._exists_safe(new_path):
                        new_path.touch(exist_ok=False)
                    else:
                        self.notify(
                            message="File already exists.",
                            duration=1200,
                        )

            except FileExistsError:
                self.notify(
                    message="File already exists.",
                    duration=1200,
                )

            except Exception as e:
                self.notify(
                    message=f"Create failed: {e}",
                    duration=2000,
                )

            self.reload_entries(reset_position=False)

        self.editor.fuzzy_changed = True
        self.clamp_cursor_scroll()

    async def delete_entry(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice or choice in ("../",):
            return

        target = self._safe_join(self.cwd, choice)

        if not self._exists_safe(target):
            self.notify(
                message="Target does not exist.",
                duration=1500,
            )
            return

        prompt = f"Delete '{choice}'?"

        if await self.editor.send_prompt_confirm(
            prompt_message=prompt,
            color_p=15,
        ):
            try:
                if self._safe_is_dir(target):
                    shutil.rmtree(target)
                else:
                    target.unlink()

            except Exception as e:
                self.notify(
                    message=f"Delete failed: {e}",
                    duration=2000,
                )

        self.editor.fuzzy_changed = True
        self.reload_entries(reset_position=False)

    async def rename_entry(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice or choice in ("../",):
            return

        target = self._safe_join(self.cwd, choice)

        if not self._exists_safe(target):
            self.notify(
                message="Target does not exist.",
                duration=1500,
            )
            return

        clean_choice = choice[:-1] if choice.endswith("/") else choice

        new_name = await self.editor.send_prompt(
            prompt_message="Rename: ",
            current_value=clean_choice,
        )

        if new_name:
            dest = self._safe_join(target.parent, new_name)

            if not self._is_relative_to(dest, self.base):
                self.notify(
                    message="Operation blocked outside base dir.",
                    duration=2000,
                )
            else:
                try:
                    target_was_dir = self._safe_is_dir(target)
                    old_abs = target.resolve()
                    new_abs = dest.resolve()

                    target.rename(dest)

                    for buf in self.editor.buffers:
                        try:
                            buf_file_name = buf.file_name
                            if buf_file_name is None:
                                continue

                            buf_path = getattr(buf, "file_path", None)

                            if buf_path:
                                buf_abs = Path(buf_path).resolve()
                            else:
                                buf_abs = Path(buf_file_name).resolve()

                            if target_was_dir:
                                try:
                                    sub = buf_abs.relative_to(old_abs)
                                except ValueError:
                                    continue

                                new_buf_abs = (new_abs / sub).resolve()
                            else:
                                if buf_abs != old_abs:
                                    continue

                                new_buf_abs = new_abs

                            buf.file_path = new_buf_abs

                            try:
                                buf.file_name = str(new_buf_abs.relative_to(self.base))
                            except Exception:
                                buf.file_name = str(new_buf_abs)

                        except Exception:
                            continue

                except Exception as e:
                    self.notify(
                        message=f"Rename failed: {e}",
                        duration=2000,
                    )

            self.reload_entries(reset_position=False)

        self.editor.fuzzy_changed = True
        self.clamp_cursor_scroll()

    async def copy_entry(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice or choice in ("../",):
            return

        source = self._safe_join(self.cwd, choice)

        if not self._exists_safe(source):
            self.notify(
                message="Source does not exist.",
                duration=1500,
            )
            return

        prompt = f"Copy '{choice}' to (path): "

        dest_in = await self.editor.send_prompt(
            prompt_message=prompt,
        )

        if not dest_in:
            return

        dest_path_typed = Path(dest_in)

        dest = (
            self._safe_join(self.cwd, dest_in).resolve()
            if not dest_path_typed.is_absolute()
            else dest_path_typed.resolve()
        )

        source_is_dir = self._safe_is_dir(source)

        if source_is_dir:
            dest = dest / source.name

        if not self._is_relative_to(dest, self.base):
            self.notify(
                message="Operation blocked outside base dir.",
                duration=2000,
            )
            return

        try:
            if dest.exists():
                prompt = f"'{dest.name}' exists. Overwrite?"

                if not await self.editor.send_prompt_confirm(
                    prompt_message=prompt,
                ):
                    self.notify(
                        message="Copy cancelled.",
                        duration=1500,
                    )
                    return

                if dest.is_dir():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()

            if source_is_dir:
                shutil.copytree(source, dest)
            else:
                if dest.exists() and dest.is_dir():
                    dest = dest / source.name

                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, dest)

            self.notify(
                message=f"Copied to {dest}",
                duration=1800,
            )

        except Exception as e:
            self.notify(
                message=f"Copy failed: {e}",
                duration=2500,
            )

        self.editor.fuzzy_changed = True
        self.reload_entries(reset_position=False)

    async def move_entry(self) -> None:
        if not self.display_entries:
            return

        choice = self.selected_name()

        if not choice or choice in ("../",):
            return

        target = self._safe_join(self.cwd, choice)

        if not self._exists_safe(target):
            self.notify(
                message="Target does not exist.",
                duration=1500,
            )
            return

        prompt = f"Move '{choice}' to (path): "

        dest_in = await self.editor.send_prompt(
            prompt_message=prompt,
        )

        if not dest_in:
            return

        def _abs(p: str | Path) -> Path:
            p = Path(p)

            if p.is_absolute():
                return p.resolve()

            return (Path(self.editor.working_dir) / p).resolve()

        def _rel_to_base(p: Path) -> str:
            base = Path(self.editor.working_dir).resolve()

            try:
                return str(p.resolve().relative_to(base))
            except Exception:
                return str(p.resolve())

        def rebase_path(path: Path, old_root: Path, new_root: Path) -> Path:
            path = path.resolve()
            old_root = old_root.resolve()
            new_root = new_root.resolve()

            try:
                sub = path.relative_to(old_root)
            except ValueError:
                return path

            return (new_root / sub).resolve()

        def remap_after_move(path: Path, old: Path, new: Path) -> Path:
            path = path.resolve()
            old = old.resolve()
            new = new.resolve()

            if old.is_dir():
                return rebase_path(path, old, new)

            return new if path == old else path

        dest_path_typed = Path(dest_in)

        dest = (
            self._safe_join(self.cwd, dest_in).resolve()
            if not dest_path_typed.is_absolute()
            else dest_path_typed.resolve()
        )

        target_was_dir = self._safe_is_dir(target)

        if target_was_dir:
            dest = dest / target.name

        if not self._is_relative_to(dest, self.base):
            self.notify(
                message="Operation blocked outside base dir.",
                duration=2000,
            )
        else:
            try:
                if not target_was_dir and dest.exists() and dest.is_dir():
                    dest = dest / target.name

                dest.parent.mkdir(parents=True, exist_ok=True)

                old_abs = target.resolve()
                new_abs = dest.resolve()

                # Move first. Only update buffers after the filesystem operation succeeds.
                shutil.move(str(old_abs), str(new_abs))

                if target_was_dir:
                    for buf in self.editor.buffers:
                        fn = getattr(buf, "file_name", None)

                        if not fn:
                            continue

                        try:
                            buf_abs = _abs(fn)

                            try:
                                buf_abs.relative_to(old_abs)
                            except ValueError:
                                continue

                            new_buf_abs = remap_after_move(buf_abs, old_abs, new_abs)
                            buf.file_path = new_buf_abs
                            buf.file_name = _rel_to_base(new_buf_abs)

                        except Exception:
                            continue

                else:
                    for buf in self.editor.buffers:
                        fn = getattr(buf, "file_name", None)

                        if not fn:
                            continue

                        try:
                            buf_abs = _abs(fn)

                            if buf_abs == old_abs:
                                buf.file_path = new_abs
                                buf.file_name = _rel_to_base(new_abs)
                                break

                        except Exception:
                            continue

                self.notify(
                    message=f"Moved to {new_abs}",
                    duration=1800,
                )

            except Exception as e:
                self.notify(
                    message=f"Move failed: {e}",
                    duration=2000,
                )

        self.editor.fuzzy_changed = True
        self.reload_entries(reset_position=False)

    # ==========================================================
    # Utility
    # ==========================================================

    def notify(self, message: str, duration: int = 1200) -> None:
        send_notification(
            window=self.manager.stdscr,
            message=message,
            duration=duration,
            editor=self.editor,
        )

    async def close(self) -> None:
        await self.manager.remove_window(self)
        self.editor.adjust_scroll()
