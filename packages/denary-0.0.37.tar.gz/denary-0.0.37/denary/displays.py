from __future__ import annotations

import asyncio
import curses
import time
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Optional

from denary import events, notifications
from denary.key_mappings import SHIFT_TAB_KEY, TAB_KEY_FUNC
from denary.windows import Rect, WindowManager

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


class PickerWindow:
    def __init__(
        self,
        manager: WindowManager,
        stdscr: curses.window,
        entries: list[Any],
        *,
        display_func: Optional[Callable[[Any], str]] = None,
        compare_func: Optional[Callable[[Any, str], bool]] = None,
        external_filter: Optional[
            Callable[[str, list[dict[str, Any]]], list[dict[str, Any]]]
        ] = None,
        selection_change: Optional[Callable[[Optional[Any]], None]] = None,
        debounce_ms: Optional[int] = None,
        increment_macro_start: bool = True,
        position: Optional[tuple[int, int]] = None,
        max_height: Optional[int] = None,
        return_query: bool = False,
        break_chars: Optional[set[str]] = None,
        initial_query: Optional[str] = None,
        on_result: Optional[Callable[[Optional[Any]], Awaitable[None]]] = None,
        editor: Optional["SimpleEditor"] = None,
    ):
        self.manager = manager
        self.stdscr = stdscr
        self.entries = entries
        self.rect = Rect(0, 0, 0, 0)

        self.display_func = display_func or (lambda x: str(x) or "[No Name]")

        self.compare_func = compare_func or (
            lambda obj, query: (
                True if not query else query.lower() in self.display_func(obj).lower()
            )
        )

        self.external_filter = external_filter
        self.selection_change = selection_change
        self.debounce_ms = debounce_ms
        self.increment_macro_start = increment_macro_start
        self.position = position
        self.max_height = max_height
        self.return_query = return_query
        self.break_chars = break_chars
        self.on_result = on_result
        self.editor = editor

        self.query = str(initial_query) if initial_query is not None else ""
        self.query_prefix = "> "

        self._wrapped = [{"display": self.display_func(e), "value": e} for e in entries]

        self._matches = self._wrapped[:]
        self._idx = 0
        self._scroll = 0

        self._popup: Optional[curses.window] = None
        self._visible_rows = 1
        self._win_w = 1
        self._max_w = 1

        self._pending_filter = True
        self._last_update_time: Optional[float] = time.time() if self.query else None
        self._debounce_task: Optional[asyncio.Task] = None
        self._closed = False

        curses.curs_set(0)

        if (
            self.editor is not None
            and self.editor.current_macro_playing_index is not None
            and self.editor.current_macro_playing_name is not None
        ):
            if self.increment_macro_start:
                self.editor.current_macro_playing_index += 1

            self.debounce_ms = None

    # ==========================================================
    # Lifecycle
    # ==========================================================

    def set_rect(self, rect: Rect) -> None:
        pass

    async def on_mount(self) -> None:
        if not self.entries:
            notifications.send_notification(
                window=self.stdscr,
                message="There is nothing to display.",
                duration=1000,
            )
            await self._finish(None)
            return

        self._create_window()

        try:
            self._debounce_task = asyncio.create_task(self.tick())
        except RuntimeError:
            self._debounce_task = None

    async def on_unmount(self) -> None:
        self._closed = True

        if self._debounce_task is not None:
            self._debounce_task.cancel()
            self._debounce_task = None

        if self._popup is not None:
            try:
                self._popup.erase()
                self._popup.noutrefresh()
            except curses.error:
                pass

            del self._popup
            self._popup = None

        curses.curs_set(0)
        curses.flushinp()

        if self.editor is not None:
            self.editor.adjust_scroll()
            self.editor.request_redraw()
        else:
            self.stdscr.touchwin()
            self.stdscr.noutrefresh()

    async def on_focus(self) -> None:
        pass

    async def on_blur(self) -> None:
        pass

    async def close(self) -> None:
        await self.manager.remove_window(self)

    # ==========================================================
    # Async debounce tick
    # ==========================================================

    async def tick(self) -> None:
        try:
            await asyncio.sleep(0.05)

            while not self._closed:
                if self._pending_filter:
                    if self.debounce_ms is None:
                        self._filter()
                        self._pending_filter = False

                        await events.EVENT_QUEUE.put(
                            events.Event(events.EventType.TICK)
                        )

                        await asyncio.sleep(0.01)
                        continue

                    if self._last_update_time is not None:
                        elapsed_ms = (time.time() - self._last_update_time) * 1000

                        if elapsed_ms >= self.debounce_ms:
                            self._filter()
                            self._pending_filter = False

                            await events.EVENT_QUEUE.put(
                                events.Event(events.EventType.TICK)
                            )

                            await asyncio.sleep(0.01)
                            continue

                    await asyncio.sleep(0.01)
                else:
                    await asyncio.sleep(0.5)

        except asyncio.CancelledError:
            return

    # ==========================================================
    # Window Creation
    # ==========================================================

    def _create_window(self) -> None:
        height, width = self.stdscr.getmaxyx()

        visible_rows = min(len(self.entries), max(1, height - 4))

        if self.max_height is not None:
            visible_rows = min(visible_rows, self.max_height, len(self.entries))

        max_entry_w = max(
            (len(item["display"]) for item in self._wrapped),
            default=0,
        )

        max_query_w = len(self.query_prefix + self.query)

        max_w = min(max(max_entry_w, max_query_w) + 2, width - 4)

        win_h = visible_rows + 3
        win_w = max_w + 2

        if self.position is not None:
            pos_y, pos_x = self.position

            start_y = pos_y

            if start_y + win_h > height:
                start_y = height - win_h

            start_y = max(0, start_y)

            preferred_x = pos_x + 1

            if preferred_x + win_w <= width:
                start_x = preferred_x
            else:
                start_x = max(pos_x, width - win_w)
        else:
            start_y = max(0, (height - win_h) // 2)
            start_x = max(0, (width - win_w) // 2)

        self._visible_rows = visible_rows
        self._win_w = win_w
        self._max_w = max_w

        # Use derwin instead of curses.newwin.
        # This makes the picker a derived window of stdscr.
        self._popup = self.stdscr.derwin(win_h, win_w, start_y, start_x)
        self._popup.keypad(True)
        self._popup.timeout(0)

    # ==========================================================
    # Filtering
    # ==========================================================

    def _filter(self) -> None:
        if self.external_filter:
            result = self.external_filter(self.query, self._wrapped) or []

            if result and isinstance(result[0], str):
                result_set = set(result)

                self._matches = [e for e in self._wrapped if e["display"] in result_set]
            else:
                obj_set = set(result)

                self._matches = [e for e in self._wrapped if e["value"] in obj_set]
        else:
            if not self.query:
                self._matches = self._wrapped[:]
            else:
                self._matches = [
                    e
                    for e in self._wrapped
                    if self.compare_func(e["value"], self.query)
                ]

        if not self._matches:
            self._matches = [{"display": "<no matches>", "value": None}]

        self._idx = 0
        self._scroll = 0

    def _request_filter(self) -> None:
        self._last_update_time = time.time()
        self._pending_filter = True

    # ==========================================================
    # Event Handling
    # ==========================================================

    async def handle_event(self, event: Any) -> bool:
        if self._popup is None:
            await self._finish(None)
            return False

        if event.type != events.EventType.KEY:
            return False

        key = event.data

        if key in ("Ctrl+C", "ESC", 27):
            if self.return_query and self.query:
                await self._finish(self.query)
            else:
                await self._finish(None)

        elif key == 0 or key == "\x00":
            return True

        elif key == "Ctrl+P":
            if self.editor is not None and self.editor.clipboard is not None:
                clipboard_text = "\n".join(self.editor.clipboard)

                if clipboard_text:
                    self.query += clipboard_text
                    self._request_filter()

        elif key in (10, 13, "Ctrl+J", "Enter", "Ctrl+M"):
            choice = self._matches[self._idx]

            if choice["value"] is not None:
                await self._finish(choice["value"])
            elif self.return_query and self.query:
                await self._finish(self.query)
            else:
                await self._finish(None)

        elif key in ("Backspace", 127, 8, "Ctrl+H"):
            if self.query:
                self.query = self.query[:-1]
                self._request_filter()
            elif self.return_query:
                await self._finish(None)

        elif key in ("Down", 9) or TAB_KEY_FUNC(key):
            self._idx = (self._idx + 1) % len(self._matches)

            if self.selection_change:
                self.selection_change(self._matches[self._idx].get("value"))

        elif key in ("Up", 353) or key == SHIFT_TAB_KEY:
            self._idx = (self._idx - 1) % len(self._matches)

            if self.selection_change:
                self.selection_change(self._matches[self._idx].get("value"))

        elif isinstance(key, str) and len(key) == 1:
            if self.break_chars is not None and key in self.break_chars:
                if self.return_query and self.query:
                    await self._finish(self.query)
                else:
                    await self._finish(None)

                return True

            self.query += key
            self._request_filter()

        return True

    # ==========================================================
    # Rendering
    # ==========================================================

    def render(self) -> None:
        if self._popup is None:
            return

        self._idx = max(0, min(self._idx, len(self._matches) - 1))

        if self._idx < self._scroll:
            self._scroll = self._idx
        elif self._idx >= self._scroll + self._visible_rows:
            self._scroll = self._idx - self._visible_rows + 1

        popup = self._popup

        popup.erase()
        popup.box()

        max_text_width = self._win_w - 4

        shown_query = self.query_prefix + self.query

        try:
            popup.addnstr(1, 1, shown_query[:max_text_width], max_text_width)
        except curses.error:
            pass

        cursor_x = min(len(shown_query), max_text_width)

        try:
            popup.move(1, 1 + cursor_x)
        except curses.error:
            pass

        visible = self._matches[self._scroll : self._scroll + self._visible_rows]

        for i, entry in enumerate(visible):
            y = 2 + i

            attr = (
                curses.A_REVERSE if (self._scroll + i) == self._idx else curses.A_NORMAL
            )

            text = entry["display"].ljust(self._max_w)[:max_text_width]

            try:
                popup.addnstr(
                    y,
                    1,
                    text,
                    max_text_width,
                    attr,
                )
            except curses.error:
                pass

        popup.noutrefresh()

    # ==========================================================
    # Finish
    # ==========================================================

    async def _finish(self, value: Optional[Any]) -> None:
        if self.on_result:
            await self.on_result(value)

        await self.close()
