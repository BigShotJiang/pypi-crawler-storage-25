from __future__ import annotations

import asyncio
import os
import signal
import tempfile
import traceback
from typing import TYPE_CHECKING, Any, cast

from denary import events
from denary.events import Event, EventType

if TYPE_CHECKING:
    from denary.editor import SimpleEditor


async def run_with_cancel_async(command: str, task_id: str, cep: bool = False) -> None:
    cancelled = False

    temp = tempfile.SpooledTemporaryFile()

    proc = await asyncio.create_subprocess_shell(
        command,
        stdout=temp,
        stderr=temp,
        start_new_session=True,  # important for killing process group
    )

    await events.EVENT_QUEUE.put(
        Event(EventType.SUBPROCESS_STARTED, {"command": command, "task_id": task_id})
    )

    try:
        await proc.wait()

    except asyncio.CancelledError:
        cancelled = True
        # kill entire process group
        os.killpg(proc.pid, signal.SIGTERM)

        try:
            await asyncio.wait_for(proc.wait(), timeout=1.5)
        except asyncio.TimeoutError:
            os.killpg(proc.pid, signal.SIGKILL)
            await proc.wait()

    size = temp.seek(0, os.SEEK_END)
    temp.seek(0)

    await events.EVENT_QUEUE.put(
        Event(
            (
                EventType.SUBPROCESS_CANCELLED
                if cancelled
                else EventType.SUBPROCESS_COMPLETED
            ),
            {
                "file": temp,
                "size": size,
                "return_code": proc.returncode,
                "command": command,
                "cep": cep,
                "task_id": task_id,
            },
        )
    )


async def handle_subprocess_event(editor: SimpleEditor, event: Event) -> None:
    try:
        event_data = cast(dict[str, Any], event.data)
        match event.type:
            case EventType.SUBPROCESS_STARTED:
                editor.send_notification(
                    f"Command started: {event_data["command"].split("\n")[0]}"
                )

                task_id = event_data["task_id"]

                for t in editor.task_running:
                    if t["task_id"] == task_id:
                        t["status"] = "STARTED"
                        break

            case EventType.SUBPROCESS_COMPLETED:
                editor.send_notification_nowait(
                    f"Command Completed: {event_data["command"].split("\n")[0]}"
                )

                await _process_subprocess_output(editor, event)

            case EventType.SUBPROCESS_CANCELLED:
                editor.send_notification_nowait(
                    f"Command cancelled or error, exited with code ({event_data["return_code"]}): {event_data["command"].split("\n")[0]}"
                )
                await _process_subprocess_output(editor, event)

    except Exception as e:
        editor.send_notification(f"An eror has ocour {e}]\n{traceback.format_exc()}", 0)


async def _process_subprocess_output(editor: SimpleEditor, event: Event) -> None:
    _data = cast(dict[str, Any], event.data)

    stdout = _data["file"]
    size = _data["size"]
    exit_code = _data["return_code"]
    CEP = _data["cep"]
    task_id = _data["task_id"]

    try:
        output = None

        stdout.seek(0)

        await editor.open_file_in_less_mode(file_handle=stdout)

    except Exception as e:
        editor.send_multiline_notification(
            f"Command failed: {e} \n{traceback.format_exc()}", 0
        )

        with open("errors.pytb", "a") as f:
            f.write(f"\n\n{e}\n{traceback.format_exc()}\n")

    finally:
        for t in editor.task_running:
            if t["task_id"] == task_id:
                editor.task_running.remove(t)
                break
