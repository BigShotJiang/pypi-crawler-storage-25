import argparse
import asyncio
import curses
import logging
import signal
import sys
import tempfile
import warnings
from logging.handlers import RotatingFileHandler
from pathlib import Path

from denary import config, themes
from denary.editor import SimpleEditor, get_version

logger = logging.getLogger(__name__)


def setup_logging(debug: bool) -> None:
    config_dir_path = config.get_config_dir()
    logs_dir_path = config_dir_path / "logs"
    logs_dir_path.mkdir(exist_ok=True)

    level = logging.DEBUG if debug else logging.INFO

    handler = RotatingFileHandler(
        logs_dir_path / "editor.log",
        maxBytes=5_000_000,
        backupCount=5,
        encoding="utf-8",
    )

    handler.setFormatter(
        logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    )

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(level)
    root.addHandler(handler)

    logging.getLogger("asyncio").setLevel(level)
    logging.captureWarnings(True)

    if debug:
        warnings.simplefilter("default", ResourceWarning)


async def configure_asyncio_debug(debug: bool) -> None:
    loop = asyncio.get_running_loop()
    loop.set_debug(debug)

    if debug:
        loop.slow_callback_duration = 0.1

    logger.debug("Asyncio debug enabled: %s", debug)


async def arun_editor(editor: SimpleEditor, debug: bool = False) -> None:
    try:
        await configure_asyncio_debug(debug)

        async with asyncio.TaskGroup() as tg:
            await editor.run(tg)
    except asyncio.CancelledError:
        return None


def run_editor(
    stdscr,
    file_names: list[str],
    theme: str,
    debug=False,
    without_session: bool = False,
    as_text: bool = False,
) -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        editor = SimpleEditor(
            stdscr,
            file_names,
            theme,
            debug=debug,
            temp_dir=temp_dir,
            without_session=without_session,
            as_text=as_text,
        )
        asyncio.run(arun_editor(editor))


def main() -> None:

    config.load_user_lsp_config()

    parser = argparse.ArgumentParser(
        prog="denary",
        description="""
            A modal terminal editor built on curses with a command-driven,
            event-based architecture and chunked text storage.

            Includes syntax highlighting, multi-buffer management,
            registers and markers, undo/redo history, Git integration,
            async LSP support, subprocess execution, and HTTP requests.
            """,
    )

    parser.add_argument("file_names", nargs="*")

    parser.add_argument(
        "-p",
        "--profile",
        action="store_true",
        help="Enable profiling",
    )

    parser.add_argument(
        "-d",
        "--debug",
        action="store_true",
        help="Enable debug mode, it will store the codes of the key pressed in a file",
    )

    parser.add_argument(
        "--without-session",
        action="store_true",
        help="this disable storing a session json",
    )

    VISIBLE_THEMES = list(themes.default.BUILDIN_THEMES.keys())[:10]

    parser.add_argument(
        "-t",
        "--theme",
        default="current",
        metavar="THEME",
        help=f"Select theme (examples: {', '.join(VISIBLE_THEMES)})",
    )

    parser.add_argument(
        "--list-themes",
        action="store_true",
        help="Show all available themes and exit",
    )

    parser.add_argument(
        "--colors",
        action="store_true",
        help="shows the colors default colors in terminal and their number siminar to less",
    )

    parser.add_argument(
        "--as-text", action="store_true", help="disables hilighting for buffers"
    )

    parser.add_argument(
        "--version",
        action="store_true",
        help="Show Denary version and exit",
    )

    args = parser.parse_args()

    setup_logging(args.debug)

    if args.list_themes:
        print("Available themes:")
        for index, name in enumerate(
            sorted(themes.default.BUILDIN_THEMES.keys()), start=1
        ):
            print(f"{index}) ", name)
        raise SystemExit(0)

    if args.colors:
        from denary import display_colors

        display_colors.main()
        exit(0)

    if args.version:
        print(get_version())
        sys.exit(0)

    if args.debug:
        with open("seq.txt", "w", encoding="utf-8") as f:
            f.write("")

    if args.profile:

        import cProfile

        with cProfile.Profile() as pr:
            if not config.CURRENT_PLATFORM.startswith("win"):
                signal.signal(signal.SIGCONT, handle_cont)

            curses.wrapper(
                lambda s: run_editor(
                    s,
                    args.file_names,
                    args.theme,
                    debug=args.debug,
                    without_session=args.without_session,
                    as_text=args.as_text,
                )
            )

            pr.print_stats()
            pr.dump_stats("editor.prof")

    else:
        if not config.CURRENT_PLATFORM.startswith("win"):
            signal.signal(signal.SIGCONT, handle_cont)

        curses.wrapper(
            lambda s: run_editor(
                s,
                args.file_names,
                args.theme,
                debug=args.debug,
                without_session=args.without_session,
                as_text=args.as_text,
            )
        )


def handle_cont(signum, frame) -> None:
    curses.raw()


if __name__ == "__main__":
    main()
