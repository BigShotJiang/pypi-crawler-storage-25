import curses
import locale
from typing import Optional

from denary.buf import Buffer

locale.setlocale(locale.LC_ALL, "")
USE_UNICODE = locale.getpreferredencoding(False).lower() == "utf-8"


def _draw_vline(stdscr: curses.window, y: int, x: int, color: int) -> None:
    """
    Draw vertical separator using Unicode if available,
    otherwise fallback to curses.ACS_VLINE.
    """
    if USE_UNICODE:
        stdscr.addstr(y, x, "│", color)
    else:
        stdscr.addch(y, x, curses.ACS_VLINE, color)


def render_separator(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:

    color = curses.color_pair(2)
    _draw_vline(stdscr, screen_row, 0, color)

    # keep spacing consistent
    stdscr.addstr(screen_row, 1, " ", color)

    return 2


def render_line_numbers(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:

    if num_lines is None:
        num_lines = len(str(len(buffer.lines)))

    ln = line_no + 1
    number_str = f"{ln:{num_lines}} "
    number_color = curses.color_pair(2)

    _draw_vline(stdscr, screen_row, 0, number_color)
    stdscr.addstr(screen_row, 1, number_str, number_color)

    return 1 + len(number_str)


def render_git_gutter(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:

    ln = line_no + 1
    cp = curses.color_pair

    change_type = buffer.buffer_changes.get(ln)
    if change_type is None:
        change_type = buffer.git_changes.get(ln)

    if change_type == "added":
        color = cp(40)
    elif change_type == "deleted":
        color = cp(41)
    elif change_type == "modified":
        color = cp(42)
    else:
        color = cp(2)

    _draw_vline(stdscr, screen_row, 0, color)
    stdscr.addstr(screen_row, 1, " ", color)

    return 2


def render_line_numbers_and_git(
    stdscr: curses.window,
    screen_row: int,
    line_no: int,
    buffer: Buffer,
    num_lines: Optional[int] = None,
) -> int:

    if num_lines is None:
        num_lines = len(str(len(buffer.lines)))

    ln = line_no + 1
    cp = curses.color_pair

    change_type = buffer.buffer_changes.get(ln)
    if change_type is None:
        change_type = buffer.git_changes.get(ln)

    if change_type == "added":
        gutter_color = cp(40)
    elif change_type == "deleted":
        gutter_color = cp(41)
    elif change_type == "modified":
        gutter_color = cp(42)
    else:
        gutter_color = cp(2)

    number_color = cp(2)
    number_str = f"{ln:{num_lines}} "

    _draw_vline(stdscr, screen_row, 0, gutter_color)
    stdscr.addstr(screen_row, 1, number_str, number_color)

    return 1 + len(number_str)
