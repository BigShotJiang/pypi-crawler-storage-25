from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Optional, Any
import json

WARNING_MESSAGE = "The desktop UI services are temporarily unavailable. Please wait a few seconds and continue."
EMPTY_MESSAGE = "No elements found"

if TYPE_CHECKING:
    from macos_use.ax.core import Rect


@dataclass
class TreeState:
    status: bool = True
    root_node: Optional['TreeElementNode'] = None
    dom_node: Optional['ScrollElementNode'] = None
    interactive_nodes: list = field(default_factory=list)
    scrollable_nodes: list = field(default_factory=list)
    dom_informative_nodes: list = field(default_factory=list)

    def interactive_elements_to_string(self) -> str:
        parts = []
        if not self.status:
            parts.append(WARNING_MESSAGE)
            return "\n".join(parts)
        if not self.interactive_nodes and self.status:
            parts.append(EMPTY_MESSAGE)
            return "\n".join(parts)
        header = "# id|window|control_type|name|coords|metadata"
        rows = [header]
        for idx, node in enumerate(self.interactive_nodes):
            row = f"{idx}|{node.window_name}|{node.control_type}|{node.name}|{node.center.to_string()}|{json.dumps(node.metadata)}"
            rows.append(row)
        parts.append("\n".join(rows))
        return "\n".join(parts)

    def scrollable_elements_to_string(self) -> str:
        parts = []
        if not self.status:
            parts.append(WARNING_MESSAGE)
            return "\n".join(parts)
        if not self.scrollable_nodes and self.status:
            parts.append(EMPTY_MESSAGE)
            return "\n".join(parts)
        header = "# id|window|control_type|name|coords|metadata"
        rows = [header]
        base_index = len(self.interactive_nodes)
        for idx, node in enumerate(self.scrollable_nodes):
            row = (f"{base_index + idx}|{node.window_name}|{node.control_type}|{node.name}|"
                   f"{node.center.to_string()}|{json.dumps(node.metadata)}")
            rows.append(row)
        parts.append("\n".join(rows))
        return "\n".join(parts)


@dataclass
class BoundingBox:
    left: int
    top: int
    right: int
    bottom: int
    width: int
    height: int

    @classmethod
    def from_bounding_rectangle(cls, bounding_rectangle: 'Rect') -> 'BoundingBox':
        return cls(
            left=int(bounding_rectangle.left),
            top=int(bounding_rectangle.top),
            right=int(bounding_rectangle.right),
            bottom=int(bounding_rectangle.bottom),
            width=int(bounding_rectangle.width),
            height=int(bounding_rectangle.height),
        )

    def get_center(self) -> 'Center':
        return Center(x=self.left + self.width // 2, y=self.top + self.height // 2)

    def xywh_to_string(self):
        return f'({self.left},{self.top},{self.width},{self.height})'

    def xyxy_to_string(self):
        x1, y1, x2, y2 = self.convert_xywh_to_xyxy()
        return f'({x1},{y1},{x2},{y2})'

    def convert_xywh_to_xyxy(self) -> tuple:
        return self.left, self.top, self.left + self.width, self.top + self.height

    def contains(self, other: 'BoundingBox') -> bool:
        return (
            self.left <= other.left and
            self.right >= other.right and
            self.top <= other.top and
            self.bottom >= other.bottom
        )


@dataclass
class Center:
    x: int
    y: int

    def to_string(self) -> str:
        return f'({self.x},{self.y})'


@dataclass
class TreeElementNode:
    bounding_box: BoundingBox
    center: Center
    name: str = ''
    control_type: str = ''
    window_name: str = ''
    metadata: dict = field(default_factory=dict)


@dataclass
class ScrollElementNode:
    name: str
    control_type: str
    window_name: str
    bounding_box: BoundingBox
    center: Center
    metadata: dict = field(default_factory=dict)


@dataclass
class TextElementNode:
    text: str


ElementNode = TreeElementNode | ScrollElementNode | TextElementNode
