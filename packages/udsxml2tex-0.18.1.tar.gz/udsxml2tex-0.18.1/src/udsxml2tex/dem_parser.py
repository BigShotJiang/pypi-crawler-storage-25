"""ARXML parser for AUTOSAR DEM (Diagnostic Event Manager) module configuration."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from lxml import etree

from udsxml2tex.models import (
    DemCombinedDtcEntry,
    DemDebounceConfig,
    DemEnableCondition,
    DemEventMemoryConfig,
    DemEventParameter,
    DemExtendedDataClass,
    DemFreezeFrameClass,
    DemGeneralConfig,
    DemIndicatorConfig,
    DemOperationCycle,
    DemStorageCondition,
    DemDtcEntry,
    UdsSpecification,
)
from udsxml2tex.parser import _detect_namespace, _xpath, _xpath_text

logger = logging.getLogger(__name__)


def derive_dtc_status_availability_mask(
    *,
    op_cycle_status_storage: bool = False,
    tfslc_handling: str = "",
    has_indicators: bool = False,
) -> int:
    """Derive ISO 14229-1 §11.3.5.2.2 availability mask from DemGeneral flags.

    Used as a fallback when no explicit ``DemDtcStatusAvailabilityMask`` parameter
    is present in the AUTOSAR DEM configuration.

    * Bit 0 (testFailed) and bit 3 (confirmedDTC) are always supported per
      AUTOSAR DEM.
    * Bit 1 (testFailedThisOperationCycle) and bit 2 (pendingDTC) are always
      tracked by AUTOSAR DEM and are therefore reported as available.
    * Bits 4/5 (testNotCompletedSinceLastClear / testFailedSinceLastClear) are
      supported when ``DemStatusBitHandlingTestFailedSinceLastClear`` is set.
    * Bit 6 (testNotCompletedThisOperationCycle) requires
      ``DemOperationCycleStatusStorage``.
    * Bit 7 (warningIndicatorRequested) is supported when at least one
      ``DemIndicator`` is configured.
    """
    mask = 0x01 | 0x02 | 0x04 | 0x08
    if tfslc_handling:
        mask |= 0x10 | 0x20
    if op_cycle_status_storage:
        mask |= 0x40
    if has_indicators:
        mask |= 0x80
    return mask


class DemParser:
    """Parser for AUTOSAR DEM ARXML files.

    Parses a standalone DEM arxml file and merges the extracted data into an
    existing UdsSpecification.  Usage::

        spec = ArxmlParser().parse("dcm.arxml")
        DemParser().parse("dem.arxml", spec)
    """

    def __init__(self) -> None:
        self.ns: dict[str, str] = {}
        self.root: Optional[etree._Element] = None

    def parse(self, arxml_path: str | Path, spec: UdsSpecification) -> UdsSpecification:
        """Parse a DEM ARXML file and merge data into *spec*.

        Args:
            arxml_path: Path to the DEM ARXML file.
            spec: UdsSpecification to merge DEM data into.

        Returns:
            The same *spec* instance with DEM data populated.
        """
        arxml_path = Path(arxml_path)
        if not arxml_path.exists():
            raise FileNotFoundError(f"DEM ARXML file not found: {arxml_path}")

        logger.info("Parsing DEM ARXML: %s", arxml_path)

        parser = etree.XMLParser(remove_blank_text=True, remove_comments=True)
        tree = etree.parse(str(arxml_path), parser)
        self.root = tree.getroot()
        self.ns = _detect_namespace(self.root)

        self._parse_dem_general(spec)
        self._parse_dem_operation_cycles(spec)
        self._parse_dem_dtcs(spec)
        self._parse_dem_event_parameters(spec)
        self._parse_dem_indicators(spec)
        self._parse_dem_enable_conditions(spec)
        self._parse_dem_storage_conditions(spec)
        self._parse_dem_event_memories(spec)
        self._parse_dem_freeze_frame_classes(spec)
        self._parse_dem_extended_data_classes(spec)
        self._parse_dem_combined_dtcs(spec)

        logger.info(
            "Parsed DEM: %d DTCs, %d events, %d indicators, %d memories",
            len(spec.dem_dtcs),
            len(spec.dem_event_parameters),
            len(spec.dem_indicators),
            len(spec.dem_event_memories),
        )
        return spec

    # ---- Section parsers ----

    def _parse_dem_general(self, spec: UdsSpecification) -> None:
        """Parse DemGeneral container."""
        assert self.root is not None
        containers = self._find_containers("DemGeneral")
        if not containers:
            return
        c = containers[0]
        spec.dem_general = DemGeneralConfig(
            status_bit_storage_test_failed=self._get_param_bool(
                c, "DemStatusBitStorageTestFailed", True
            ),
            status_bit_handling_tfslc=self._get_param_text(
                c, "DemStatusBitHandlingTestFailedSinceLastClear"
            ),
            reset_confirmed_bit_on_overflow=self._get_param_bool(
                c, "DemResetConfirmedBitOnOverflow", True
            ),
            operation_cycle_status_storage=self._get_param_bool(
                c, "DemOperationCycleStatusStorage"
            ),
            suppression_support=self._get_param_bool(c, "DemSuppressionSupport"),
            availability_support=self._get_param_bool(c, "DemAvailabilitySupport"),
            trigger_fim_reports=self._get_param_bool(c, "DemTriggerFiMReports"),
            type_of_dtc_supported=self._get_param_text(c, "DemTypeOfDTCSupported"),
            clear_dtc_limitation=self._get_param_text(c, "DemClearDTCLimitation"),
            max_number_event_entry_permanent=self._get_param_int(
                c, "DemMaxNumberEventEntryPermanent"
            ),
            aging_requires_tested_cycle=self._get_param_bool(
                c, "DemAgingRequiresTestedCycle"
            ),
            healing_requires_tested_cycle=self._get_param_bool(
                c, "DemHealingRequiresTestedCycle"
            ),
            ob_cycle_count_threshold=self._get_param_int(
                c, "DemObdCycleCountThreshold"
            ),
        )

        # ---- DTC status availability mask (ISO 14229-1 §11.3.5.2.2) ----
        # Try explicit vendor parameter first.
        mask = self._get_param_int(c, "DemDtcStatusAvailabilityMask", 0)
        if mask == 0:
            mask = self._get_param_int(c, "DemStatusAvailabilityMask", 0)
        if mask == 0:
            # Derive from configured DemGeneral / DemStatusBit* flags.
            mask = self._derive_status_availability_mask(c, spec)
        spec.dem_general.dtc_status_availability_mask = mask
        # Propagate to spec-level mask if DCM did not provide one
        # (default sentinel 0xFF means DCM had nothing).
        if mask and spec.dtc_status_availability_mask == 0xFF:
            spec.dtc_status_availability_mask = mask

        # ---- DTC severity availability mask (ISO 14229-1 §C.3.1) ----
        sev_mask = self._get_param_int(c, "DemDTCSeverityAvailabilityMask", 0)
        spec.dem_general.dtc_severity_availability_mask = sev_mask

        # ---- DTC format identifier (ISO 14229-1 §11.3.6) ----
        spec.dem_general.dtc_format_identifier = self._dtc_format_id(
            spec.dem_general.type_of_dtc_supported
        )

        logger.debug(
            "DEM General: DTCStatusAvailabilityMask=0x%02X, format=0x%02X",
            mask,
            spec.dem_general.dtc_format_identifier,
        )

    @staticmethod
    def _dtc_format_id(type_of_dtc_supported: str) -> int:
        """Map AUTOSAR DemTypeOfDTCSupported to ISO 14229-1 §11.3.6 format id."""
        mapping = {
            "DEM_DTC_TRANSLATION_SAEJ2012DA": 0x00,
            "DEM_DTC_TRANSLATION_ISO14229_1": 0x01,
            "DEM_DTC_TRANSLATION_SAEJ1939_73": 0x02,
            "DEM_DTC_TRANSLATION_ISO11992_4": 0x03,
            "DEM_DTC_TRANSLATION_SAEJ2012DA_FORMAT_04": 0x04,
        }
        return mapping.get(type_of_dtc_supported.strip().upper(), 0x01)

    def _derive_status_availability_mask(
        self, dem_general: etree._Element, spec: UdsSpecification
    ) -> int:
        """Derive ISO 14229-1 §11.3.5.2.2 availability mask from DemGeneral flags."""
        return derive_dtc_status_availability_mask(
            op_cycle_status_storage=self._get_param_bool(
                dem_general, "DemOperationCycleStatusStorage", False
            ),
            tfslc_handling=self._get_param_text(
                dem_general, "DemStatusBitHandlingTestFailedSinceLastClear"
            ),
            has_indicators=bool(
                spec.dem_indicators or self._find_containers("DemIndicator")
            ),
        )

    def _parse_dem_operation_cycles(self, spec: UdsSpecification) -> None:
        """Parse DemOperationCycle containers."""
        assert self.root is not None
        # Cycles may appear as direct containers or as sub-containers of DemGeneral
        seen: set[str] = {oc.short_name for oc in spec.dem_operation_cycles}
        containers = self._find_containers("DemOperationCycle")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DemOperationCycle":
                subs = _xpath(c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns)
                for sub in subs:
                    self._parse_single_operation_cycle(sub, spec, seen)
                continue
            self._parse_single_operation_cycle(c, spec, seen)

    def _parse_single_operation_cycle(
        self, container: etree._Element, spec: UdsSpecification, seen: set[str]
    ) -> None:
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn or sn in seen:
            return
        seen.add(sn)
        cycle = DemOperationCycle(
            short_name=sn,
            cycle_id=self._get_param_int(container, "DemOperationCycleId"),
            cycle_type=self._get_param_text(container, "DemOperationCycleType"),
            autostart=self._get_param_bool(container, "DemOperationCycleAutostart"),
        )
        spec.dem_operation_cycles.append(cycle)
        logger.debug("  DEM OpCycle: %s (id=%d)", sn, cycle.cycle_id)

    def _parse_dem_dtcs(self, spec: UdsSpecification) -> None:
        """Parse DemDTC containers — actual DTC values (ISO 14229-1 §11.3)."""
        assert self.root is not None
        seen: set[str] = {d.short_name for d in spec.dem_dtcs}

        # DemDTC containers live inside DemConfigSet as siblings of DemEventParameter
        patterns = [
            ".//ar:ECUC-CONTAINER-VALUE[starts-with(ar:SHORT-NAME,'DemDTC')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(),'DemDTC')]",
        ]
        candidates: list = []
        for pat in patterns:
            candidates = _xpath(self.root, pat, self.ns)
            if candidates:
                break

        for c in candidates:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn in seen:
                continue
            # Skip containers that are not actual DTC entries
            if sn in ("DemDTC", "DemDTCAttributes"):
                continue
            seen.add(sn)
            self._parse_single_dtc(c, spec)

    def _parse_single_dtc(self, container: etree._Element, spec: UdsSpecification) -> None:
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return

        dtc_value = self._get_param_int(container, "DemDtcValue")

        # DemDTCAttributes may be a sub-container
        severity = ""
        kind = ""
        functional_unit = 0
        aging_cycle_ref = ""
        aging_threshold = 0
        aging_allowed = True
        priority = 0
        memory_entry_ref = ""

        attr_containers = _xpath(
            container,
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(),'DemDTCAttributes')]",
            self.ns,
        )
        if not attr_containers:
            # Attributes may be inline parameters
            attr_containers = [container]

        significance = ""
        for attr in attr_containers:
            severity = severity or self._get_param_text(attr, "DemDTCSeverity")
            kind = kind or self._get_param_text(attr, "DemDTCKind")
            significance = significance or self._get_param_text(attr, "DemDTCSignificance")
            functional_unit = functional_unit or self._get_param_int(attr, "DemDTCFunctionalUnit")
            aging_threshold = aging_threshold or self._get_param_int(
                attr, "DemAgingCycleCounterThreshold"
            )
            aging_val = self._get_param_text(attr, "DemAgingAllowed")
            if aging_val:
                aging_allowed = aging_val.lower() not in ("false", "0")
            priority = priority or self._get_param_int(attr, "DemDTCPriority")

            ref = self._get_param_ref(attr, "DemAgingCycleRef")
            if ref:
                aging_cycle_ref = ref.rsplit("/", 1)[-1]
            ref2 = self._get_param_ref(attr, "DemMemoryEntryRef")
            if ref2:
                memory_entry_ref = ref2.rsplit("/", 1)[-1]

        ob_dtc_value = 0
        wwh_obd_dtc_class = ""
        ff_class_ref = ""
        ext_data_class_ref = ""
        for attr in attr_containers:
            ob_dtc_value = ob_dtc_value or self._get_param_int(attr, "DemOBDDTCValue")
            wwh_obd_dtc_class = wwh_obd_dtc_class or self._get_param_text(
                attr, "DemWWHOBDDTCClass"
            )
            if not ff_class_ref:
                ref_ff = self._get_param_ref(attr, "DemFreezeFrameClassRef")
                if ref_ff:
                    ff_class_ref = ref_ff.rsplit("/", 1)[-1]
            if not ext_data_class_ref:
                ref_ext = self._get_param_ref(attr, "DemExtendedDataClassRef")
                if ref_ext:
                    ext_data_class_ref = ref_ext.rsplit("/", 1)[-1]

        entry = DemDtcEntry(
            short_name=sn,
            dtc_value=dtc_value,
            severity=severity,
            kind=kind,
            dtc_significance=significance,
            functional_unit=functional_unit,
            aging_cycle_ref=aging_cycle_ref,
            aging_cycle_counter_threshold=aging_threshold,
            aging_allowed=aging_allowed,
            priority=priority,
            memory_entry_ref=memory_entry_ref,
            ob_dtc_value=ob_dtc_value,
            wwh_obd_dtc_class=wwh_obd_dtc_class,
            freeze_frame_class_ref=ff_class_ref,
            extended_data_class_ref=ext_data_class_ref,
        )
        spec.dem_dtcs.append(entry)
        logger.debug("  DEM DTC: %s = %s", sn, entry.dtc_value_hex)

    def _parse_dem_event_parameters(self, spec: UdsSpecification) -> None:
        """Parse DemEventParameter containers."""
        assert self.root is not None
        seen: set[str] = {e.short_name for e in spec.dem_event_parameters}
        containers = self._find_containers("DemEventParameter")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DemEventParameter":
                subs = _xpath(c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns)
                for sub in subs:
                    self._parse_single_event_param(sub, spec, seen)
                continue
            self._parse_single_event_param(c, spec, seen)

    def _parse_single_event_param(
        self, container: etree._Element, spec: UdsSpecification, seen: set[str]
    ) -> None:
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn or sn == "DemEventParameter" or sn in seen:
            return
        seen.add(sn)

        debounce = self._parse_debounce(container)

        op_ref = self._get_param_ref(container, "DemOperationCycleRef")
        dtc_ref = self._get_param_ref(container, "DemDTCRef")
        ec_ref = self._get_param_ref(container, "DemEnableConditionGroupRef")
        sc_ref = self._get_param_ref(container, "DemStorageConditionGroupRef")
        indicator_refs = self._get_ref_list(container, "DemIndicatorRef")

        evt = DemEventParameter(
            short_name=sn,
            event_id=self._get_param_int(container, "DemEventId"),
            event_kind=self._get_param_text(container, "DemEventKind"),
            confirmation_threshold=self._get_param_int(
                container, "DemEventConfirmationThreshold", 1
            ),
            operation_cycle_ref=op_ref.rsplit("/", 1)[-1] if op_ref else "",
            enable_condition_group_ref=ec_ref.rsplit("/", 1)[-1] if ec_ref else "",
            storage_condition_group_ref=sc_ref.rsplit("/", 1)[-1] if sc_ref else "",
            dtc_ref=dtc_ref.rsplit("/", 1)[-1] if dtc_ref else "",
            debounce=debounce,
            indicator_refs=indicator_refs,
            recoverable_in_same_cycle=self._get_param_bool(
                container, "DemEventRecoverableInSameOperationCycle", True
            ),
            report_behavior=self._get_param_text(container, "DemReportBehavior"),
            ff_prestorage_supported=self._get_param_bool(
                container, "DemFFPrestorageSupported"
            ),
        )
        spec.dem_event_parameters.append(evt)
        logger.debug("  DEM Event: %s (id=%d)", sn, evt.event_id)

    def _parse_debounce(self, container: etree._Element) -> Optional[DemDebounceConfig]:
        """Parse DemDebounceAlgorithmClass sub-container."""
        debounce_containers = _xpath(
            container,
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DemDebounce')]",
            self.ns,
        )
        if not debounce_containers:
            return None

        dc = debounce_containers[0]
        sn = _xpath_text(dc, "ar:SHORT-NAME", self.ns) or ""

        if "CounterBased" in sn:
            algo = "COUNTER_BASED"
        elif "TimeBase" in sn:
            algo = "TIME_BASED"
        elif "MonitorInternal" in sn:
            algo = "MONITOR_INTERNAL"
        else:
            algo = sn

        return DemDebounceConfig(
            algorithm=algo,
            counter_failed_threshold=self._get_param_int(
                dc, "DemDebounceCounterFailedThreshold", 127
            ),
            counter_passed_threshold=self._get_param_int(
                dc, "DemDebounceCounterPassedThreshold", -128
            ),
            counter_increment_step=self._get_param_int(
                dc, "DemDebounceCounterIncrementStepSize", 1
            ),
            counter_decrement_step=self._get_param_int(
                dc, "DemDebounceCounterDecrementStepSize", 1
            ),
            counter_jump_up=self._get_param_bool(dc, "DemDebounceCounterJumpUp"),
            counter_jump_down=self._get_param_bool(dc, "DemDebounceCounterJumpDown"),
            counter_storage=self._get_param_bool(dc, "DemDebounceCounterStorage"),
            time_failed_threshold=self._get_param_float(
                dc, "DemDebounceTimeFailedThreshold", 0.0
            ),
            time_passed_threshold=self._get_param_float(
                dc, "DemDebounceTimePassedThreshold", 0.0
            ),
        )

    def _parse_dem_indicators(self, spec: UdsSpecification) -> None:
        """Parse DemIndicator containers."""
        assert self.root is not None
        seen: set[str] = {i.short_name for i in spec.dem_indicators}
        containers = self._find_containers("DemIndicator")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DemIndicator":
                subs = _xpath(c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns)
                for sub in subs:
                    self._parse_single_indicator(sub, spec, seen)
                continue
            self._parse_single_indicator(c, spec, seen)

    def _parse_single_indicator(
        self, container: etree._Element, spec: UdsSpecification, seen: set[str]
    ) -> None:
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn or sn in seen:
            return
        seen.add(sn)
        ind = DemIndicatorConfig(
            short_name=sn,
            indicator_id=self._get_param_int(container, "DemIndicatorId"),
            behaviour=self._get_param_text(container, "DemIndicatorBehaviour"),
            failure_cycle_counter_threshold=self._get_param_int(
                container, "DemIndicatorFailureCycleCounterThreshold"
            ),
            healing_cycle_counter_threshold=self._get_param_int(
                container, "DemIndicatorHealingCycleCounterThreshold"
            ),
        )
        spec.dem_indicators.append(ind)
        logger.debug("  DEM Indicator: %s (id=%d)", sn, ind.indicator_id)

    def _parse_dem_enable_conditions(self, spec: UdsSpecification) -> None:
        """Parse DemEnableCondition containers."""
        assert self.root is not None
        seen: set[str] = {e.short_name for e in spec.dem_enable_conditions}
        containers = self._find_containers("DemEnableCondition")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn in ("DemEnableCondition", "DemEnableConditionGroup"):
                subs = _xpath(c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns)
                for sub in subs:
                    sub_sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
                    if sub_sn and "Group" not in sub_sn:
                        self._parse_single_enable_condition(sub, spec, seen)
                continue
            if "Group" in sn:
                continue
            self._parse_single_enable_condition(c, spec, seen)

    def _parse_single_enable_condition(
        self, container: etree._Element, spec: UdsSpecification, seen: set[str]
    ) -> None:
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn or sn in seen:
            return
        seen.add(sn)
        ec = DemEnableCondition(
            short_name=sn,
            condition_id=self._get_param_int(container, "DemEnableConditionId"),
            initial_status=self._get_param_bool(
                container, "DemEnableConditionStatus", True
            ),
        )
        spec.dem_enable_conditions.append(ec)

    def _parse_dem_storage_conditions(self, spec: UdsSpecification) -> None:
        """Parse DemStorageCondition containers."""
        assert self.root is not None
        seen: set[str] = {s.short_name for s in spec.dem_storage_conditions}
        containers = self._find_containers("DemStorageCondition")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn in ("DemStorageCondition", "DemStorageConditionGroup"):
                subs = _xpath(c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns)
                for sub in subs:
                    sub_sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
                    if sub_sn and "Group" not in sub_sn:
                        self._parse_single_storage_condition(sub, spec, seen)
                continue
            if "Group" in sn:
                continue
            self._parse_single_storage_condition(c, spec, seen)

    def _parse_single_storage_condition(
        self, container: etree._Element, spec: UdsSpecification, seen: set[str]
    ) -> None:
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn or sn in seen:
            return
        seen.add(sn)
        ref = self._get_param_ref(container, "DemStorageConditionReplacementEventRef")
        sc = DemStorageCondition(
            short_name=sn,
            condition_id=self._get_param_int(container, "DemStorageConditionId"),
            initial_status=self._get_param_bool(
                container, "DemStorageConditionStatus", True
            ),
            replacement_event_ref=ref.rsplit("/", 1)[-1] if ref else "",
        )
        spec.dem_storage_conditions.append(sc)

    def _parse_dem_event_memories(self, spec: UdsSpecification) -> None:
        """Parse DemPrimaryMemory and DemUserDefinedMemory containers."""
        assert self.root is not None
        seen: set[str] = {m.short_name for m in spec.dem_event_memories}

        for mem_tag, mem_type, max_param in [
            ("DemPrimaryMemory", "PRIMARY", "DemMaxNumberEventEntryPrimary"),
            ("DemUserDefinedMemory", "USER_DEFINED", "DemMaxNumberEventEntryUserDefined"),
            ("DemMirrorMemory", "MIRROR", "DemMaxNumberEventEntryMirror"),
            ("DemPermanentMemory", "PERMANENT", "DemMaxNumberEventEntryPermanent"),
        ]:
            for c in self._find_containers(mem_tag):
                sn = _xpath_text(c, "ar:SHORT-NAME", self.ns) or mem_tag
                if sn in seen:
                    continue
                seen.add(sn)
                mem = DemEventMemoryConfig(
                    short_name=sn,
                    memory_type=mem_type,
                    max_number_event_entries=self._get_param_int(c, max_param),
                    displacement_strategy=self._get_param_text(
                        c, "DemEventDisplacementStrategy"
                    ),
                    occurrence_counter_processing=self._get_param_text(
                        c, "DemOccurrenceCounterProcessing"
                    ),
                    event_memory_entry_storage_trigger=self._get_param_text(
                        c, "DemEventMemoryEntryStorageTrigger"
                    ),
                    freeze_frame_record_trigger=self._get_param_text(
                        c, "DemFreezeFrameRecordTrigger"
                    ),
                    extended_data_record_trigger=self._get_param_text(
                        c, "DemExtendedDataRecordTrigger"
                    ),
                    type_of_freeze_frame_record_numeration=self._get_param_text(
                        c, "DemTypeOfFreezeFrameRecordNumeration"
                    ),
                    max_number_freeze_frame_records=self._get_param_int(
                        c, "DemMaxNumberFreezeFrameRecords"
                    ),
                )
                spec.dem_event_memories.append(mem)
                logger.debug("  DEM Memory: %s (type=%s)", sn, mem_type)

    def _parse_dem_freeze_frame_classes(self, spec: UdsSpecification) -> None:
        """Parse DemFreezeFrameClass containers — ISO 14229-1 §11.3.3."""
        assert self.root is not None
        seen: set[str] = {f.short_name for f in spec.dem_freeze_frame_classes}

        patterns = [
            ".//ar:ECUC-CONTAINER-VALUE[starts-with(ar:SHORT-NAME,'DemFreezeFrameClass')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(),'DemFreezeFrameClass')]",
        ]
        candidates: list = []
        for pat in patterns:
            candidates = _xpath(self.root, pat, self.ns)
            if candidates:
                break

        for c in candidates:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn in seen:
                continue
            seen.add(sn)

            # Collect referenced DID short names
            did_refs = self._get_ref_list(c, "DemFreezeFrameDidRef")
            if not did_refs:
                did_refs = self._get_ref_list(c, "DemDidRef")

            ff_class = DemFreezeFrameClass(short_name=sn, did_refs=did_refs)
            spec.dem_freeze_frame_classes.append(ff_class)
            logger.debug("  DEM FreezeFrameClass: %s (%d DIDs)", sn, len(did_refs))

    def _parse_dem_extended_data_classes(self, spec: UdsSpecification) -> None:
        """Parse DemExtendedDataClass containers — ISO 14229-1 §11.3.4."""
        assert self.root is not None
        seen: set[str] = {e.short_name for e in spec.dem_extended_data_classes}

        patterns = [
            ".//ar:ECUC-CONTAINER-VALUE[starts-with(ar:SHORT-NAME,'DemExtendedDataClass')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(),'DemExtendedDataClass')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(),'DemExtendedDataRecord')]",
        ]
        candidates: list = []
        for pat in patterns:
            found = _xpath(self.root, pat, self.ns)
            if found:
                candidates.extend(found)

        for c in candidates:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn in seen:
                continue
            seen.add(sn)
            rec_num = self._get_param_int(c, "DemExtendedDataRecordNumber")
            data_size = self._get_param_int(c, "DemExtendedDataRecordSize")
            trigger = self._get_param_text(c, "DemExtendedDataRecordTrigger")
            edr = DemExtendedDataClass(
                short_name=sn,
                record_number=rec_num,
                data_size=data_size,
                update_trigger=trigger,
            )
            spec.dem_extended_data_classes.append(edr)
            logger.debug(
                "  DEM ExtDataClass: %s (rec=0x%02X, size=%dB)", sn, rec_num, data_size
            )

    def _parse_dem_combined_dtcs(self, spec: UdsSpecification) -> None:
        """Parse DemCombinedDTC containers — multiple events mapped to one DTC."""
        assert self.root is not None
        seen: set[str] = {d.short_name for d in spec.dem_combined_dtcs}

        patterns = [
            ".//ar:ECUC-CONTAINER-VALUE[starts-with(ar:SHORT-NAME,'DemCombinedDTC')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(),'DemCombinedDTC')]",
        ]
        candidates: list = []
        for pat in patterns:
            found = _xpath(self.root, pat, self.ns)
            if found:
                candidates.extend(found)

        for c in candidates:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn in seen:
                continue
            seen.add(sn)

            dtc_val = self._get_param_int(c, "DemCombinedDTCNumber")
            if dtc_val == 0:
                dtc_val = self._get_param_int(c, "DemDtcValue")

            # Collect sub-class references (DemDTC refs or event refs)
            dtc_class_refs = self._get_ref_list(c, "DemDTCRef")
            if not dtc_class_refs:
                dtc_class_refs = self._get_ref_list(c, "DemCombinedDTCClassRef")

            # Collect event short names from sub-containers
            event_refs: list[str] = []
            for sub in _xpath(c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns):
                sub_sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
                if sub_sn:
                    event_refs.append(sub_sn)
            if not event_refs:
                event_refs = self._get_ref_list(c, "DemEventRef")

            entry = DemCombinedDtcEntry(
                short_name=sn,
                combined_dtc_value=dtc_val,
                dtc_class_refs=dtc_class_refs,
                event_refs=event_refs,
            )
            spec.dem_combined_dtcs.append(entry)
            logger.debug("  DEM CombinedDTC: %s = %s", sn, entry.combined_dtc_value_hex)

    # ---- Helper methods ----

    def _find_containers(self, name: str) -> list:
        assert self.root is not None
        results: list = []
        patterns = [
            f".//ar:ECUC-CONTAINER-VALUE[ar:SHORT-NAME='{name}']",
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
        ]
        for pat in patterns:
            found = _xpath(self.root, pat, self.ns)
            if found:
                results.extend(found)
                break
        return results

    def _get_param_int(
        self, container: etree._Element, param_name: str, default: int = 0
    ) -> int:
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    if text.lower().startswith("0x"):
                        return int(text, 16)
                    return int(float(text))
                except ValueError:
                    pass
        return default

    def _get_param_float(
        self, container: etree._Element, param_name: str, default: float = 0.0
    ) -> float:
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    return float(text)
                except ValueError:
                    pass
        return default

    def _get_param_text(
        self, container: etree._Element, param_name: str, default: str = ""
    ) -> str:
        for path in [
            f".//ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE",
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                return text
        return default

    def _get_param_bool(
        self, container: etree._Element, param_name: str, default: bool = False
    ) -> bool:
        text = self._get_param_text(container, param_name)
        if text.lower() in ("true", "1"):
            return True
        if text.lower() in ("false", "0"):
            return False
        return default

    def _get_param_ref(
        self, container: etree._Element, param_name: str
    ) -> Optional[str]:
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE-REF",
        ]:
            results = _xpath(container, path, self.ns)
            if results:
                elem = results[0]
                return elem.text if isinstance(elem, etree._Element) else str(elem)
        return None

    def _get_ref_list(self, container: etree._Element, param_name: str) -> list[str]:
        refs: list[str] = []
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(),'{param_name}')]/ar:VALUE-REF",
        ]:
            for r in _xpath(container, path, self.ns):
                text = r.text if isinstance(r, etree._Element) else str(r)
                if text:
                    refs.append(text.rsplit("/", 1)[-1])
        return list(dict.fromkeys(refs))
