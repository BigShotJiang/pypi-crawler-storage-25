"""LaTeX generator for UDS specification documents."""

from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from jinja2 import Environment, FileSystemLoader, select_autoescape

from udsxml2tex.models import (
    DTC_SEVERITY_LEVELS,
    DTC_STATUS_BIT_DEFINITIONS,
    ISO14229_SERVICE_ORDER,
    NRC_CHECK_ORDER,
    STANDARD_NRCS,
    UDS_MESSAGE_FORMATS,
    UdsSpecification,
)

logger = logging.getLogger(__name__)

# Characters that need escaping in LaTeX
_LATEX_ESCAPE_MAP = {
    "&": r"\&",
    "%": r"\%",
    "$": r"\$",
    "#": r"\#",
    "_": r"\_",
    "{": r"\{",
    "}": r"\}",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}


def _latex_escape(text: str) -> str:
    """Escape special LaTeX characters in text."""
    if not text:
        return ""
    # Don't escape backslashes that are already LaTeX commands
    result = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "\\" and i + 1 < len(text) and text[i + 1].isalpha():
            # Likely a LaTeX command, don't escape
            result.append(ch)
        elif ch in _LATEX_ESCAPE_MAP:
            result.append(_LATEX_ESCAPE_MAP[ch])
        else:
            result.append(ch)
        i += 1
    return "".join(result)


def _strip_0x(text: str) -> str:
    """Strip '0x' or '0X' prefix from hex string for subscript-16 notation."""
    if isinstance(text, str) and text.lower().startswith("0x"):
        return text[2:]
    return str(text)


class TexGenerator:
    """Generate LaTeX documents from UDS specification data."""

    def __init__(self, template_dir: Optional[str | Path] = None) -> None:
        """Initialize the TeX generator.

        Args:
            template_dir: Directory containing Jinja2 templates.
                         Defaults to the built-in templates directory.
        """
        if template_dir is None:
            template_dir = Path(__file__).parent / "templates"
        else:
            template_dir = Path(template_dir)

        self.template_dir = template_dir
        self.env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            block_start_string=r"\BLOCK{",
            block_end_string="}",
            variable_start_string=r"\VAR{",
            variable_end_string="}",
            comment_start_string=r"\#{",
            comment_end_string="}",
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        # Register custom filters
        self.env.filters["latex_escape"] = _latex_escape
        self.env.filters["strip_0x"] = _strip_0x
        self.env.filters["bitand"] = lambda value, mask: bool(int(value) & int(mask))

    def generate(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        template_name: str = "uds_spec.tex.j2",
    ) -> Path:
        """Generate a LaTeX document from the UDS specification.

        Args:
            spec: The UDS specification data.
            output_path: Path for the output .tex file.
            template_name: Name of the Jinja2 template to use.

        Returns:
            Path to the generated .tex file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        template = self.env.get_template(template_name)
        rendered = template.render(**self._build_context(spec))
        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated LaTeX document: %s", output_path)

        # Copy tikz-uml.sty alongside the output so pdflatex can find it
        tikz_uml_src = self.template_dir / "tikz-uml.sty"
        if tikz_uml_src.exists():
            tikz_uml_dst = output_path.parent / "tikz-uml.sty"
            if not tikz_uml_dst.exists():
                shutil.copy2(tikz_uml_src, tikz_uml_dst)
                logger.info("Copied tikz-uml.sty to %s", tikz_uml_dst)

        # Copy udsspec.cls alongside the output so pdflatex can find it
        cls_src = self.template_dir / "udsspec.cls"
        if cls_src.exists():
            cls_dst = output_path.parent / "udsspec.cls"
            if not cls_dst.exists():
                shutil.copy2(cls_src, cls_dst)
                logger.info("Copied udsspec.cls to %s", cls_dst)

        return output_path

    def generate_string(
        self,
        spec: UdsSpecification,
        template_name: str = "uds_spec.tex.j2",
    ) -> str:
        """Generate LaTeX content as a string.

        Args:
            spec: The UDS specification data.
            template_name: Name of the Jinja2 template to use.

        Returns:
            Rendered LaTeX content.
        """
        template = self.env.get_template(template_name)
        return template.render(**self._build_context(spec))

    def _build_context(self, spec: UdsSpecification) -> dict:
        """Build the shared Jinja2 template context from a UdsSpecification."""
        services = sorted(
            spec.services,
            key=lambda s: ISO14229_SERVICE_ORDER.get(s.service_id, 100),
        )
        dids = sorted(spec.dids, key=lambda d: d.did_id)
        routines = sorted(spec.routines, key=lambda r: r.routine_id)
        sessions = sorted(spec.sessions, key=lambda s: s.session_id)
        security_levels = sorted(spec.security_levels, key=lambda s: s.security_level)

        transport_config = spec.transport_config
        cantp_channels = transport_config.channels if transport_config else []

        session_names = sorted({n for s in services for n in s.supported_sessions})
        security_level_names = sorted(
            {n for s in services for n in s.required_security_levels}
        )

        return {
            "ecu_name": spec.ecu_name,
            "description": spec.description,
            "protocol_name": spec.protocol_name,
            "protocol_type": spec.protocol_type,
            "can_rx_id": spec.can_rx_id,
            "can_tx_id": spec.can_tx_id,
            "can_functional_id": spec.can_functional_id,
            "s3_server": spec.s3_server,
            "dsl_rx_buffer_size": spec.dsl_rx_buffer_size,
            "dsl_tx_buffer_size": spec.dsl_tx_buffer_size,
            "sessions": sessions,
            "security_levels": security_levels,
            "services": services,
            "dids": dids,
            "routines": routines,
            "dtcs": sorted(spec.dtcs, key=lambda d: d.dtc_id),
            "memory_ranges": spec.memory_ranges,
            "io_control_dids": sorted(spec.io_control_dids, key=lambda d: d.did_id),
            "periodic_dids": sorted(spec.periodic_dids, key=lambda d: d.did_id),
            "did_ranges": sorted(spec.did_ranges, key=lambda d: d.lower_did),
            "transport_config": transport_config,
            "cantp_channels": cantp_channels,
            "message_formats": UDS_MESSAGE_FORMATS,
            "nrc_check_order": NRC_CHECK_ORDER,
            "standard_nrcs": STANDARD_NRCS,
            "session_names": session_names,
            "security_level_names": security_level_names,
            "com_control": spec.com_control,
            "response_on_event": spec.response_on_event,
            "dtc_status_availability_mask": spec.dtc_status_availability_mask,
            "max_num_resp_pend": spec.max_num_resp_pend,
            "max_response_length": spec.max_response_length,
            "request_file_transfer": spec.request_file_transfer,
            "clear_dtc_notifications": spec.clear_dtc_notifications,
            "dynamic_dids": sorted(spec.dynamic_dids, key=lambda d: d.did_id),
            "connection_mode": spec.connection_mode,
            "connection_end_of_type": spec.connection_end_of_type,
            "cdtc_status_mask": spec.cdtc_status_mask,
            "clear_dtc_group": spec.clear_dtc_group,
            "module_main_function_period": spec.module_main_function_period,
            "enable_fim_trigger": spec.enable_fim_trigger,
            "protocol_priority": spec.protocol_priority,
            "protocol_trans_type": spec.protocol_trans_type,
            "protocol_preempt_timeout": spec.protocol_preempt_timeout,
            "periodic_slow_rate": spec.periodic_slow_rate,
            "periodic_medium_rate": spec.periodic_medium_rate,
            "periodic_fast_rate": spec.periodic_fast_rate,
            "memory_compression_method": spec.memory_compression_method,
            "memory_encrypting_method": spec.memory_encrypting_method,
            "dev_error_detect": spec.dev_error_detect,
            "version_info_api": spec.version_info_api,
            "task_time": spec.task_time,
            "respond_all_request": spec.respond_all_request,
            "protocol_rows": sorted(spec.protocol_rows, key=lambda r: r.priority),
            "authentication_config": spec.authentication_config,
            "access_timing_rows": spec.access_timing_rows,
            # DEM (Diagnostic Event Manager)
            "dem_general": spec.dem_general,
            "dem_operation_cycles": spec.dem_operation_cycles,
            "dem_event_parameters": sorted(
                spec.dem_event_parameters, key=lambda e: e.event_id
            ),
            "dem_indicators": spec.dem_indicators,
            "dem_enable_conditions": spec.dem_enable_conditions,
            "dem_storage_conditions": spec.dem_storage_conditions,
            "dem_event_memories": spec.dem_event_memories,
            "dem_dtcs": sorted(spec.dem_dtcs, key=lambda d: d.dtc_value),
            "dem_freeze_frame_classes": spec.dem_freeze_frame_classes,
            "dem_extended_data_classes": sorted(
                spec.dem_extended_data_classes, key=lambda e: e.record_number
            ),
            "dem_combined_dtcs": sorted(
                spec.dem_combined_dtcs, key=lambda d: d.combined_dtc_value
            ),
            # ISO 14229-1 constant tables for template rendering
            "dtc_status_bit_definitions": DTC_STATUS_BIT_DEFINITIONS,
            "dtc_severity_levels": DTC_SEVERITY_LEVELS,
            # Upload/Download max block length (ISO 14229-1 §13)
            "max_block_length": spec.max_block_length,
            # LinkControl (0x87) supported baud rates
            "link_control_baudrates": sorted(
                spec.link_control_baudrates, key=lambda b: b.baudrate_value
            ),
            # Named DTC groups (DcmDspGroupOfDTC)
            "dtc_groups": sorted(spec.dtc_groups, key=lambda g: g.group_value),
        }

    # ---- PDF compilation ------------------------------------------------

    def compile_pdf(
        self,
        tex_path: str | Path,
        *,
        clean: bool = True,
    ) -> Path:
        """Compile a .tex file to PDF using latexmk or pdflatex.

        Args:
            tex_path: Path to the .tex file.
            clean: Remove auxiliary files after compilation.

        Returns:
            Path to the generated PDF.

        Raises:
            FileNotFoundError: If no LaTeX compiler is found.
            RuntimeError: If compilation fails.
        """
        tex_path = Path(tex_path).resolve()
        if not tex_path.exists():
            raise FileNotFoundError(f"TeX file not found: {tex_path}")

        work_dir = tex_path.parent

        # Prefer latexmk (handles multiple passes automatically)
        latexmk = shutil.which("latexmk")
        pdflatex = shutil.which("pdflatex")

        if latexmk:
            cmd = [
                latexmk,
                "-pdf",
                "-interaction=nonstopmode",
                "-halt-on-error",
                str(tex_path.name),
            ]
            if clean:
                clean_cmd = [latexmk, "-c", str(tex_path.name)]
        elif pdflatex:
            # Run pdflatex twice for TOC / references
            cmd = [
                pdflatex,
                "-interaction=nonstopmode",
                "-halt-on-error",
                str(tex_path.name),
            ]
            clean_cmd = None
        else:
            raise FileNotFoundError(
                "No LaTeX compiler found. Install TeX Live or MiKTeX "
                "(latexmk or pdflatex must be on PATH)."
            )

        logger.info("Compiling PDF: %s", " ".join(cmd))
        runs = 1 if latexmk else 2
        for i in range(runs):
            result = subprocess.run(
                cmd,
                cwd=str(work_dir),
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode != 0:
                logger.error("LaTeX stdout:\n%s", result.stdout[-2000:])
                logger.error("LaTeX stderr:\n%s", result.stderr[-2000:])
                raise RuntimeError(
                    f"LaTeX compilation failed (exit {result.returncode}). "
                    f"Check log file for details."
                )

        pdf_path = tex_path.with_suffix(".pdf")
        if not pdf_path.exists():
            raise RuntimeError(f"Expected PDF not found: {pdf_path}")

        # Clean auxiliary files
        if clean and latexmk and clean_cmd:
            subprocess.run(clean_cmd, cwd=str(work_dir), capture_output=True)

        logger.info("PDF generated: %s", pdf_path)
        return pdf_path

    # ---- HTML generation ------------------------------------------------

    def generate_html(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        template_name: str = "uds_spec.html.j2",
    ) -> Path:
        """Generate an HTML document from the UDS specification.

        Args:
            spec: The UDS specification data.
            output_path: Path for the output .html file.
            template_name: Name of the HTML Jinja2 template.

        Returns:
            Path to the generated .html file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Create a separate Jinja2 environment with standard delimiters for HTML
        html_env = Environment(
            loader=FileSystemLoader(str(self.template_dir)),
            autoescape=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        html_env.filters["strip_0x"] = _strip_0x

        def _html_hex(value: str) -> str:
            """Render hex value with subscript-16 notation in HTML."""
            v = _strip_0x(str(value))
            return f'<span class="hexval">{v}<sub>16</sub></span>'

        html_env.filters["hexval"] = _html_hex

        template = html_env.get_template(template_name)
        rendered = template.render(**self._build_context(spec))
        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated HTML document: %s", output_path)
        return output_path
