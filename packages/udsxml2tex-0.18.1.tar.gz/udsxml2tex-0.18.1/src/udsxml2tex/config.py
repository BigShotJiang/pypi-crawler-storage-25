"""Configuration file support for udsxml2tex."""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class GenerationConfig:
    """Configuration for specification generation.

    Can be saved/loaded as a JSON file to reproduce generation runs
    without the interactive session.
    """

    # --- Input sources ---
    arxml_type: str = "dcm"  # "dcm", "cantp", "both"
    dcm_arxml_path: str = ""
    cantp_arxml_path: str = ""

    # --- Item selection ---
    include_services: list[int] = field(default_factory=list)  # SIDs to include
    include_dids: list[int] = field(default_factory=list)  # DID IDs to include
    include_routines: list[int] = field(default_factory=list)  # Routine IDs
    include_sessions: list[str] = field(default_factory=list)  # Session short names
    include_security_levels: list[str] = field(default_factory=list)

    # --- Timing parameters ---
    include_timing_params: bool = True  # Include session timing (P2, P2*)
    include_cantp_timing: bool = True  # Include CanTp timing (N_As, N_Bs, etc.)

    # --- NRC 0x22 details ---
    # Maps SID (int) -> detail text or source code file path
    nrc22_details: dict[str, str] = field(default_factory=dict)

    # --- Output settings ---
    ecu_name: str = ""
    output_path: str = ""
    cls_file_path: str = ""  # "" = use default udsspec.cls
    template: str = "uds_spec.tex.j2"
    template_dir: str = ""  # "" = use built-in templates

    def save(self, path: str | Path) -> Path:
        """Save configuration to a JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = asdict(self)
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        logger.info("Configuration saved to: %s", path)
        return path

    @classmethod
    def load(cls, path: str | Path) -> "GenerationConfig":
        """Load configuration from a JSON file."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls(**data)
