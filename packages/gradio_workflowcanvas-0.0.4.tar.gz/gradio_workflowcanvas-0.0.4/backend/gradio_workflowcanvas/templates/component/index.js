import { i as yn, g as ba, o as mi, n as Vt, a as Re, s as _a, r as lr, t as ya, b as rn, c as C, d as o, e as bi, f as wa, h as St, j as _i, T as xa, k as yi, l as ln, p as Zt, q as Er, v as Yt, w as kr, x as Jt, y as Wt, z as Ea, A as ka, B as Dn, E as Tr, C as Ta, D as Rr, F as Lt, G as wi, H as nn, I as Sr, J as xi, K as Ei, L as ur, M as ki, N as Sa, O as Yn, P as Ti, Q as Si, R as Oi, S as Ai, U as Ii, V as z, W as Ci, X as Hi, Y as Li, Z as wn, _ as Or, $ as Ge, a0 as Oa, a1 as Pi, a2 as Ni, a3 as Mi, a4 as Bi, a5 as Ar, a6 as Ri, a7 as Di, a8 as Ui, a9 as ji, aa as X, ab as lt, ac as Fi, ad as mn, ae as Gi, af as zi, ag as Vi, ah as Xi, ai as en, aj as Ir, ak as Wi, al as Aa, am as Ia, an as Ot, ao as qi, ap as Ca, aq as Zi, ar as Yi, as as Ha, at as At, au as Ji, av as Qi, aw as Ki, ax as $i, ay as eo, az as to, aA as no, aB as Dr, aC as Ur, aD as he, aE as ro, aF as nt, aG as rt, aH as Pe, aI as L, aJ as A, aK as ve, aL as re, aM as Te, aN as ao, aO as io, aP as oo } from "./render-DHmaugzp.js";
function so(e) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const lo = [];
function uo(e, t = !1, n = !1) {
  return In(e, /* @__PURE__ */ new Map(), "", lo, null, n);
}
function In(e, t, n, r, a = null, i = !1) {
  if (typeof e == "object" && e !== null) {
    var s = t.get(e);
    if (s !== void 0) return s;
    if (e instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(e)
    );
    if (e instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(e)
    );
    if (yn(e)) {
      var l = (
        /** @type {Snapshot<any>} */
        Array(e.length)
      );
      t.set(e, l), a !== null && t.set(a, l);
      for (var u = 0; u < e.length; u += 1) {
        var c = e[u];
        u in e && (l[u] = In(c, t, n, r, null, i));
      }
      return l;
    }
    if (ba(e) === mi) {
      l = {}, t.set(e, l), a !== null && t.set(a, l);
      for (var h of Object.keys(e))
        l[h] = In(
          // @ts-expect-error
          e[h],
          t,
          n,
          r,
          null,
          i
        );
      return l;
    }
    if (e instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(e)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    e.toJSON == "function" && !i)
      return In(
        /** @type {T & { toJSON(): any } } */
        e.toJSON(),
        t,
        n,
        r,
        // Associate the instance with the toJSON clone
        e
      );
  }
  if (e instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      e
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(e)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      e
    );
  }
}
function Cr(e, t, n) {
  if (e == null)
    return t(void 0), n && n(void 0), Vt;
  const r = Re(
    () => e.subscribe(
      t,
      // @ts-expect-error
      n
    )
  );
  return r.unsubscribe ? () => r.unsubscribe() : r;
}
const $t = [];
function co(e, t) {
  return {
    subscribe: xn(e, t).subscribe
  };
}
function xn(e, t = Vt) {
  let n = null;
  const r = /* @__PURE__ */ new Set();
  function a(l) {
    if (_a(e, l) && (e = l, n)) {
      const u = !$t.length;
      for (const c of r)
        c[1](), $t.push(c, e);
      if (u) {
        for (let c = 0; c < $t.length; c += 2)
          $t[c][0]($t[c + 1]);
        $t.length = 0;
      }
    }
  }
  function i(l) {
    a(l(
      /** @type {T} */
      e
    ));
  }
  function s(l, u = Vt) {
    const c = [l, u];
    return r.add(c), r.size === 1 && (n = t(a, i) || Vt), l(
      /** @type {T} */
      e
    ), () => {
      r.delete(c), r.size === 0 && n && (n(), n = null);
    };
  }
  return { set: a, update: i, subscribe: s };
}
function un(e, t, n) {
  const r = !Array.isArray(e), a = r ? [e] : e;
  if (!a.every(Boolean))
    throw new Error("derived() expects stores as input, got a falsy value");
  const i = t.length < 2;
  return co(n, (s, l) => {
    let u = !1;
    const c = [];
    let h = 0, v = Vt;
    const f = () => {
      if (h)
        return;
      v();
      const b = t(r ? c[0] : c, s, l);
      i ? s(b) : v = typeof b == "function" ? b : Vt;
    }, w = a.map(
      (b, E) => Cr(
        b,
        (p) => {
          c[E] = p, h &= ~(1 << E), u && f();
        },
        () => {
          h |= 1 << E;
        }
      )
    );
    return u = !0, f(), function() {
      lr(w), v(), u = !1;
    };
  });
}
function fo(e) {
  let t;
  return Cr(e, (n) => t = n)(), t;
}
let Tn = !1, cr = /* @__PURE__ */ Symbol();
function La(e, t, n) {
  const r = n[t] ??= {
    store: null,
    source: rn(void 0),
    unsubscribe: Vt
  };
  if (r.store !== e && !(cr in n))
    if (r.unsubscribe(), r.store = e ?? null, e == null)
      r.source.v = void 0, r.unsubscribe = Vt;
    else {
      var a = !0;
      r.unsubscribe = Cr(e, (i) => {
        a ? r.source.v = i : C(r.source, i);
      }), a = !1;
    }
  return e && cr in n ? fo(e) : o(r.source);
}
function Pa() {
  const e = {};
  function t() {
    ya(() => {
      for (var n in e)
        e[n].unsubscribe();
      bi(e, cr, {
        enumerable: !1,
        value: !0
      });
    });
  }
  return [e, t];
}
function ho(e) {
  var t = Tn;
  try {
    return Tn = !1, [e(), Tn];
  } finally {
    Tn = t;
  }
}
const vo = (
  // We gotta write it like this because after downleveling the pure comment may end up in the wrong location
  globalThis?.window?.trustedTypes && /* @__PURE__ */ globalThis.window.trustedTypes.createPolicy("svelte-trusted-html", {
    /** @param {string} html */
    createHTML: (e) => e
  })
);
function po(e) {
  return (
    /** @type {string} */
    vo?.createHTML(e) ?? e
  );
}
function Na(e) {
  var t = wa("template");
  return t.innerHTML = po(e.replaceAll("<!>", "<!---->")), t.content;
}
function Xt(e, t) {
  var n = (
    /** @type {Effect} */
    ln
  );
  n.nodes === null && (n.nodes = { start: e, end: t, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function N(e, t) {
  var n = (t & xa) !== 0, r = (t & yi) !== 0, a, i = !e.startsWith("<!>");
  return () => {
    a === void 0 && (a = Na(i ? e : "<!>" + e), n || (a = /** @type {TemplateNode} */
    St(a)));
    var s = (
      /** @type {TemplateNode} */
      r || _i ? document.importNode(a, !0) : a.cloneNode(!0)
    );
    if (n) {
      var l = (
        /** @type {TemplateNode} */
        St(s)
      ), u = (
        /** @type {TemplateNode} */
        s.lastChild
      );
      Xt(l, u);
    } else
      Xt(s, s);
    return s;
  };
}
// @__NO_SIDE_EFFECTS__
function go(e, t, n = "svg") {
  var r = !e.startsWith("<!>"), a = (t & xa) !== 0, i = `<${n}>${r ? e : "<!>" + e}</${n}>`, s;
  return () => {
    if (!s) {
      var l = (
        /** @type {DocumentFragment} */
        Na(i)
      ), u = (
        /** @type {Element} */
        St(l)
      );
      if (a)
        for (s = document.createDocumentFragment(); St(u); )
          s.appendChild(
            /** @type {TemplateNode} */
            St(u)
          );
      else
        s = /** @type {Element} */
        St(u);
    }
    var c = (
      /** @type {TemplateNode} */
      s.cloneNode(!0)
    );
    if (a) {
      var h = (
        /** @type {TemplateNode} */
        St(c)
      ), v = (
        /** @type {TemplateNode} */
        c.lastChild
      );
      Xt(h, v);
    } else
      Xt(c, c);
    return c;
  };
}
// @__NO_SIDE_EFFECTS__
function bt(e, t) {
  return /* @__PURE__ */ go(e, t, "svg");
}
function Nn(e = "") {
  {
    var t = Zt(e + "");
    return Xt(t, t), t;
  }
}
function $e() {
  var e = document.createDocumentFragment(), t = document.createComment(""), n = Zt();
  return e.append(t, n), Xt(t, n), e;
}
function T(e, t) {
  e !== null && e.before(
    /** @type {Node} */
    t
  );
}
class Hr {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #e = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #n = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #t = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #r = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #a = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(t, n = !0) {
    this.anchor = t, this.#a = n;
  }
  /**
   * @param {Batch} batch
   */
  #i = (t) => {
    if (this.#e.has(t)) {
      var n = (
        /** @type {Key} */
        this.#e.get(t)
      ), r = this.#n.get(n);
      if (r)
        Er(r), this.#r.delete(n);
      else {
        var a = this.#t.get(n);
        a && (this.#n.set(n, a.effect), this.#t.delete(n), a.fragment.lastChild.remove(), this.anchor.before(a.fragment), r = a.effect);
      }
      for (const [i, s] of this.#e) {
        if (this.#e.delete(i), i === t)
          break;
        const l = this.#t.get(s);
        l && (Yt(l.effect), this.#t.delete(s));
      }
      for (const [i, s] of this.#n) {
        if (i === n || this.#r.has(i)) continue;
        const l = () => {
          if (Array.from(this.#e.values()).includes(i)) {
            var c = document.createDocumentFragment();
            Ea(s, c), c.append(Zt()), this.#t.set(i, { effect: s, fragment: c });
          } else
            Yt(s);
          this.#r.delete(i), this.#n.delete(i);
        };
        this.#a || !r ? (this.#r.add(i), kr(s, l, !1)) : l();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #o = (t) => {
    this.#e.delete(t);
    const n = Array.from(this.#e.values());
    for (const [r, a] of this.#t)
      n.includes(r) || (Yt(a.effect), this.#t.delete(r));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(t, n) {
    var r = (
      /** @type {Batch} */
      Wt
    ), a = ka();
    if (n && !this.#n.has(t) && !this.#t.has(t))
      if (a) {
        var i = document.createDocumentFragment(), s = Zt();
        i.append(s), this.#t.set(t, {
          effect: Jt(() => n(s)),
          fragment: i
        });
      } else
        this.#n.set(
          t,
          Jt(() => n(this.anchor))
        );
    if (this.#e.set(r, t), a) {
      for (const [l, u] of this.#n)
        l === t ? r.unskip_effect(u) : r.skip_effect(u);
      for (const [l, u] of this.#t)
        l === t ? r.unskip_effect(u.effect) : r.skip_effect(u.effect);
      r.oncommit(this.#i), r.ondiscard(this.#o);
    } else
      this.#i(r);
  }
}
function W(e, t, n = !1) {
  var r = new Hr(e), a = n ? Tr : 0;
  function i(s, l) {
    r.ensure(s, l);
  }
  Dn(() => {
    var s = !1;
    t((l, u = 0) => {
      s = !0, i(u, l);
    }), s || i(-1, null);
  }, a);
}
function kt(e, t) {
  return t;
}
function mo(e, t, n) {
  for (var r = [], a = t.length, i, s = t.length, l = 0; l < a; l++) {
    let v = t[l];
    kr(
      v,
      () => {
        if (i) {
          if (i.pending.delete(v), i.done.add(v), i.pending.size === 0) {
            var f = (
              /** @type {Set<EachOutroGroup>} */
              e.outrogroups
            );
            dr(e, Sr(i.done)), f.delete(i), f.size === 0 && (e.outrogroups = null);
          }
        } else
          s -= 1;
      },
      !1
    );
  }
  if (s === 0) {
    var u = r.length === 0 && n !== null;
    if (u) {
      var c = (
        /** @type {Element} */
        n
      ), h = (
        /** @type {Element} */
        c.parentNode
      );
      Ai(h), h.append(c), e.items.clear();
    }
    dr(e, t, !u);
  } else
    i = {
      pending: new Set(t),
      done: /* @__PURE__ */ new Set()
    }, (e.outrogroups ??= /* @__PURE__ */ new Set()).add(i);
}
function dr(e, t, n = !0) {
  var r;
  if (e.pending.size > 0) {
    r = /* @__PURE__ */ new Set();
    for (const s of e.pending.values())
      for (const l of s)
        r.add(
          /** @type {EachItem} */
          e.items.get(l).e
        );
  }
  for (var a = 0; a < t.length; a++) {
    var i = t[a];
    if (r?.has(i)) {
      i.f |= Lt;
      const s = document.createDocumentFragment();
      Ea(i, s);
    } else
      Yt(t[a], n);
  }
}
var jr;
function it(e, t, n, r, a, i = null) {
  var s = e, l = /* @__PURE__ */ new Map(), u = (t & Ta) !== 0;
  if (u) {
    var c = (
      /** @type {Element} */
      e
    );
    s = c.appendChild(Zt());
  }
  var h = null, v = nn(() => {
    var m = n();
    return yn(m) ? m : m == null ? [] : Sr(m);
  }), f, w = /* @__PURE__ */ new Map(), b = !0;
  function E(m) {
    (y.effect.f & Sa) === 0 && (y.pending.delete(m), y.fallback = h, bo(y, f, s, t, r), h !== null && (f.length === 0 ? (h.f & Lt) === 0 ? Er(h) : (h.f ^= Lt, bn(h, null, s)) : kr(h, () => {
      h = null;
    })));
  }
  function p(m) {
    y.pending.delete(m);
  }
  var g = Dn(() => {
    f = /** @type {V[]} */
    o(v);
    for (var m = f.length, O = /* @__PURE__ */ new Set(), I = (
      /** @type {Batch} */
      Wt
    ), B = ka(), Z = 0; Z < m; Z += 1) {
      var R = f[Z], F = r(R, Z), q = b ? null : l.get(F);
      q ? (q.v && Rr(q.v, R), q.i && Rr(q.i, Z), B && I.unskip_effect(q.e)) : (q = _o(
        l,
        b ? s : jr ??= Zt(),
        R,
        F,
        Z,
        a,
        t,
        n
      ), b || (q.e.f |= Lt), l.set(F, q)), O.add(F);
    }
    if (m === 0 && i && !h && (b ? h = Jt(() => i(s)) : (h = Jt(() => i(jr ??= Zt())), h.f |= Lt)), m > O.size && wi(), !b)
      if (w.set(I, O), B) {
        for (const [me, Ue] of l)
          O.has(me) || I.skip_effect(Ue.e);
        I.oncommit(E), I.ondiscard(p);
      } else
        E(I);
    o(v);
  }), y = { effect: g, items: l, pending: w, outrogroups: null, fallback: h };
  b = !1;
}
function vn(e) {
  for (; e !== null && (e.f & Si) === 0; )
    e = e.next;
  return e;
}
function bo(e, t, n, r, a) {
  var i = (r & Oi) !== 0, s = t.length, l = e.items, u = vn(e.effect.first), c, h = null, v, f = [], w = [], b, E, p, g;
  if (i)
    for (g = 0; g < s; g += 1)
      b = t[g], E = a(b, g), p = /** @type {EachItem} */
      l.get(E).e, (p.f & Lt) === 0 && (p.nodes?.a?.measure(), (v ??= /* @__PURE__ */ new Set()).add(p));
  for (g = 0; g < s; g += 1) {
    if (b = t[g], E = a(b, g), p = /** @type {EachItem} */
    l.get(E).e, e.outrogroups !== null)
      for (const q of e.outrogroups)
        q.pending.delete(p), q.done.delete(p);
    if ((p.f & Yn) !== 0 && (Er(p), i && (p.nodes?.a?.unfix(), (v ??= /* @__PURE__ */ new Set()).delete(p))), (p.f & Lt) !== 0)
      if (p.f ^= Lt, p === u)
        bn(p, null, n);
      else {
        var y = h ? h.next : u;
        p === e.effect.last && (e.effect.last = p.prev), p.prev && (p.prev.next = p.next), p.next && (p.next.prev = p.prev), Gt(e, h, p), Gt(e, p, y), bn(p, y, n), h = p, f = [], w = [], u = vn(h.next);
        continue;
      }
    if (p !== u) {
      if (c !== void 0 && c.has(p)) {
        if (f.length < w.length) {
          var m = w[0], O;
          h = m.prev;
          var I = f[0], B = f[f.length - 1];
          for (O = 0; O < f.length; O += 1)
            bn(f[O], m, n);
          for (O = 0; O < w.length; O += 1)
            c.delete(w[O]);
          Gt(e, I.prev, B.next), Gt(e, h, I), Gt(e, B, m), u = m, h = B, g -= 1, f = [], w = [];
        } else
          c.delete(p), bn(p, u, n), Gt(e, p.prev, p.next), Gt(e, p, h === null ? e.effect.first : h.next), Gt(e, h, p), h = p;
        continue;
      }
      for (f = [], w = []; u !== null && u !== p; )
        (c ??= /* @__PURE__ */ new Set()).add(u), w.push(u), u = vn(u.next);
      if (u === null)
        continue;
    }
    (p.f & Lt) === 0 && f.push(p), h = p, u = vn(p.next);
  }
  if (e.outrogroups !== null) {
    for (const q of e.outrogroups)
      q.pending.size === 0 && (dr(e, Sr(q.done)), e.outrogroups?.delete(q));
    e.outrogroups.size === 0 && (e.outrogroups = null);
  }
  if (u !== null || c !== void 0) {
    var Z = [];
    if (c !== void 0)
      for (p of c)
        (p.f & Yn) === 0 && Z.push(p);
    for (; u !== null; )
      (u.f & Yn) === 0 && u !== e.fallback && Z.push(u), u = vn(u.next);
    var R = Z.length;
    if (R > 0) {
      var F = (r & Ta) !== 0 && s === 0 ? n : null;
      if (i) {
        for (g = 0; g < R; g += 1)
          Z[g].nodes?.a?.measure();
        for (g = 0; g < R; g += 1)
          Z[g].nodes?.a?.fix();
      }
      mo(e, Z, F);
    }
  }
  i && Ti(() => {
    if (v !== void 0)
      for (p of v)
        p.nodes?.a?.apply();
  });
}
function _o(e, t, n, r, a, i, s, l) {
  var u = (s & xi) !== 0 ? (s & Ei) === 0 ? rn(n, !1, !1) : ur(n) : null, c = (s & ki) !== 0 ? ur(a) : null;
  return {
    v: u,
    i: c,
    e: Jt(() => (i(t, u ?? n, c ?? a, l), () => {
      e.delete(r);
    }))
  };
}
function bn(e, t, n) {
  if (e.nodes)
    for (var r = e.nodes.start, a = e.nodes.end, i = t && (t.f & Lt) === 0 ? (
      /** @type {EffectNodes} */
      t.nodes.start
    ) : n; r !== null; ) {
      var s = (
        /** @type {TemplateNode} */
        Ii(r)
      );
      if (i.before(r), r === a)
        return;
      r = s;
    }
}
function Gt(e, t, n) {
  t === null ? e.effect.first = n : t.next = n, n === null ? e.effect.last = t : n.prev = t;
}
function yo(e, t, n = !1, r = !1, a = !1, i = !1) {
  var s = e, l = "";
  if (n)
    var u = (
      /** @type {Element} */
      e
    );
  z(() => {
    var c = (
      /** @type {Effect} */
      ln
    );
    if (l !== (l = t() ?? "")) {
      if (n) {
        c.nodes = null, u.innerHTML = /** @type {string} */
        l, l !== "" && Xt(
          /** @type {TemplateNode} */
          St(u),
          /** @type {TemplateNode} */
          u.lastChild
        );
        return;
      }
      if (c.nodes !== null && (Ci(
        c.nodes.start,
        /** @type {TemplateNode} */
        c.nodes.end
      ), c.nodes = null), l !== "") {
        var h = r ? Hi : a ? Li : void 0, v = (
          /** @type {HTMLTemplateElement | SVGElement | MathMLElement} */
          wa(r ? "svg" : a ? "math" : "template", h)
        );
        v.innerHTML = /** @type {any} */
        l;
        var f = r || a ? v : (
          /** @type {HTMLTemplateElement} */
          v.content
        );
        if (Xt(
          /** @type {TemplateNode} */
          St(f),
          /** @type {TemplateNode} */
          f.lastChild
        ), r || a)
          for (; St(f); )
            s.before(
              /** @type {TemplateNode} */
              St(f)
            );
        else
          s.before(f);
      }
    }
  });
}
function Lr(e, t, n, r, a) {
  var i = t.$$slots?.[n], s = !1;
  i === !0 && (i = t.children, s = !0), i === void 0 || i(e, s ? () => r : r);
}
function Un(e, t, ...n) {
  var r = new Hr(e);
  Dn(() => {
    const a = t() ?? null;
    r.ensure(a, a && ((i) => a(i, ...n)));
  }, Tr);
}
function Ma(e, t, n) {
  var r = new Hr(e);
  Dn(() => {
    var a = t() ?? null;
    r.ensure(a, a && ((i) => n(i, a)));
  }, Tr);
}
function wo(e, t, n) {
  wn(() => {
    var r = Re(() => t(e, n?.()) || {});
    if (n && r?.update) {
      var a = !1, i = (
        /** @type {any} */
        {}
      );
      Or(() => {
        var s = n();
        Ge(s), a && _a(i, s) && (i = s, r.update(s));
      }), a = !0;
    }
    if (r?.destroy)
      return () => (
        /** @type {Function} */
        r.destroy()
      );
  });
}
function xo(e, t) {
  var n = void 0, r;
  Oa(() => {
    n !== (n = t()) && (r && (Yt(r), r = null), n && (r = Jt(() => {
      wn(() => (
        /** @type {(node: Element) => void} */
        n(e)
      ));
    })));
  });
}
function Ba(e) {
  var t, n, r = "";
  if (typeof e == "string" || typeof e == "number") r += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var a = e.length;
    for (t = 0; t < a; t++) e[t] && (n = Ba(e[t])) && (r && (r += " "), r += n);
  } else for (n in e) e[n] && (r && (r += " "), r += n);
  return r;
}
function Eo() {
  for (var e, t, n = 0, r = "", a = arguments.length; n < a; n++) (e = arguments[n]) && (t = Ba(e)) && (r && (r += " "), r += t);
  return r;
}
function ko(e) {
  return typeof e == "object" ? Eo(e) : e ?? "";
}
const Fr = [...` 	
\r\f \v\uFEFF`];
function To(e, t, n) {
  var r = e == null ? "" : "" + e;
  if (t && (r = r ? r + " " + t : t), n) {
    for (var a of Object.keys(n))
      if (n[a])
        r = r ? r + " " + a : a;
      else if (r.length)
        for (var i = a.length, s = 0; (s = r.indexOf(a, s)) >= 0; ) {
          var l = s + i;
          (s === 0 || Fr.includes(r[s - 1])) && (l === r.length || Fr.includes(r[l])) ? r = (s === 0 ? "" : r.substring(0, s)) + r.substring(l + 1) : s = l;
        }
  }
  return r === "" ? null : r;
}
function Gr(e, t = !1) {
  var n = t ? " !important;" : ";", r = "";
  for (var a of Object.keys(e)) {
    var i = e[a];
    i != null && i !== "" && (r += " " + a + ": " + i + n);
  }
  return r;
}
function Jn(e) {
  return e[0] !== "-" || e[1] !== "-" ? e.toLowerCase() : e;
}
function So(e, t) {
  if (t) {
    var n = "", r, a;
    if (Array.isArray(t) ? (r = t[0], a = t[1]) : r = t, e) {
      e = String(e).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var i = !1, s = 0, l = !1, u = [];
      r && u.push(...Object.keys(r).map(Jn)), a && u.push(...Object.keys(a).map(Jn));
      var c = 0, h = -1;
      const E = e.length;
      for (var v = 0; v < E; v++) {
        var f = e[v];
        if (l ? f === "/" && e[v - 1] === "*" && (l = !1) : i ? i === f && (i = !1) : f === "/" && e[v + 1] === "*" ? l = !0 : f === '"' || f === "'" ? i = f : f === "(" ? s++ : f === ")" && s--, !l && i === !1 && s === 0) {
          if (f === ":" && h === -1)
            h = v;
          else if (f === ";" || v === E - 1) {
            if (h !== -1) {
              var w = Jn(e.substring(c, h).trim());
              if (!u.includes(w)) {
                f !== ";" && v++;
                var b = e.substring(c, v).trim();
                n += " " + b + ";";
              }
            }
            c = v + 1, h = -1;
          }
        }
      }
    }
    return r && (n += Gr(r)), a && (n += Gr(a, !0)), n = n.trim(), n === "" ? null : n;
  }
  return e == null ? null : String(e);
}
function Be(e, t, n, r, a, i) {
  var s = e.__className;
  if (s !== n || s === void 0) {
    var l = To(n, r, i);
    l == null ? e.removeAttribute("class") : t ? e.className = l : e.setAttribute("class", l), e.__className = n;
  } else if (i && a !== i)
    for (var u in i) {
      var c = !!i[u];
      (a == null || c !== !!a[u]) && e.classList.toggle(u, c);
    }
  return i;
}
function Qn(e, t = {}, n, r) {
  for (var a in n) {
    var i = n[a];
    t[a] !== i && (n[a] == null ? e.style.removeProperty(a) : e.style.setProperty(a, i, r));
  }
}
function Ye(e, t, n, r) {
  var a = e.__style;
  if (a !== t) {
    var i = So(t, r);
    i == null ? e.removeAttribute("style") : e.style.cssText = i, e.__style = t;
  } else r && (Array.isArray(r) ? (Qn(e, n?.[0], r[0]), Qn(e, n?.[1], r[1], "important")) : Qn(e, n, r));
  return r;
}
function fr(e, t, n = !1) {
  if (e.multiple) {
    if (t == null)
      return;
    if (!yn(t))
      return Pi();
    for (var r of e.options)
      r.selected = t.includes(zr(r));
    return;
  }
  for (r of e.options) {
    var a = zr(r);
    if (Ni(a, t)) {
      r.selected = !0;
      return;
    }
  }
  (!n || t !== void 0) && (e.selectedIndex = -1);
}
function Oo(e) {
  var t = new MutationObserver(() => {
    fr(e, e.__value);
  });
  t.observe(e, {
    // Listen to option element changes
    childList: !0,
    subtree: !0,
    // because of <optgroup>
    // Listen to option element value attribute changes
    // (doesn't get notified of select value changes,
    // because that property is not reflected as an attribute)
    attributes: !0,
    attributeFilter: ["value"]
  }), ya(() => {
    t.disconnect();
  });
}
function zr(e) {
  return "__value" in e ? e.__value : e.value;
}
const pn = /* @__PURE__ */ Symbol("class"), tn = /* @__PURE__ */ Symbol("style"), Ra = /* @__PURE__ */ Symbol("is custom element"), Da = /* @__PURE__ */ Symbol("is html"), Ao = Ar ? "option" : "OPTION", Io = Ar ? "select" : "SELECT", Co = Ar ? "progress" : "PROGRESS";
function qt(e, t) {
  var n = jn(e);
  n.value === (n.value = // treat null and undefined the same for the initial value
  t ?? void 0) || // @ts-expect-error
  // `progress` elements always need their value set when it's `0`
  e.value === t && (t !== 0 || e.nodeName !== Co) || (e.value = t ?? "");
}
function Vr(e, t) {
  var n = jn(e);
  n.checked !== (n.checked = // treat null and undefined the same for the initial value
  t ?? void 0) && (e.checked = t);
}
function Ho(e, t) {
  t ? e.hasAttribute("selected") || e.setAttribute("selected", "") : e.removeAttribute("selected");
}
function H(e, t, n, r) {
  var a = jn(e);
  a[t] !== (a[t] = n) && (t === "loading" && (e[Mi] = n), n == null ? e.removeAttribute(t) : typeof n != "string" && ja(e).includes(t) ? e[t] = n : e.setAttribute(t, n));
}
function Lo(e, t, n, r, a = !1, i = !1) {
  var s = jn(e), l = s[Ra], u = !s[Da], c = t || {}, h = e.nodeName === Ao;
  for (var v in t)
    v in n || (n[v] = null);
  n.class ? n.class = ko(n.class) : (r || n[pn]) && (n.class = null), n[tn] && (n.style ??= null);
  var f = ja(e);
  for (const m in n) {
    let O = n[m];
    if (h && m === "value" && O == null) {
      e.value = e.__value = "", c[m] = O;
      continue;
    }
    if (m === "class") {
      var w = e.namespaceURI === "http://www.w3.org/1999/xhtml";
      Be(e, w, O, r, t?.[pn], n[pn]), c[m] = O, c[pn] = n[pn];
      continue;
    }
    if (m === "style") {
      Ye(e, O, t?.[tn], n[tn]), c[m] = O, c[tn] = n[tn];
      continue;
    }
    var b = c[m];
    if (!(O === b && !(O === void 0 && e.hasAttribute(m)))) {
      c[m] = O;
      var E = m[0] + m[1];
      if (E !== "$$")
        if (E === "on") {
          const I = {}, B = "$$" + m;
          let Z = m.slice(2);
          var p = Vi(Z);
          if (ji(Z) && (Z = Z.slice(0, -7), I.capture = !0), !p && b) {
            if (O != null) continue;
            e.removeEventListener(Z, c[B], I), c[B] = null;
          }
          if (p)
            X(Z, e, O), lt([Z]);
          else if (O != null) {
            let R = function(F) {
              c[m].call(this, F);
            };
            c[B] = Fi(Z, e, R, I);
          }
        } else if (m === "style")
          H(e, m, O);
        else if (m === "autofocus")
          mn(
            /** @type {HTMLElement} */
            e,
            !!O
          );
        else if (!l && (m === "__value" || m === "value" && O != null))
          e.value = e.__value = O;
        else if (m === "selected" && h)
          Ho(
            /** @type {HTMLOptionElement} */
            e,
            O
          );
        else {
          var g = m;
          u || (g = Gi(g));
          var y = g === "defaultValue" || g === "defaultChecked";
          if (O == null && !l && !y)
            if (s[m] = null, g === "value" || g === "checked") {
              let I = (
                /** @type {HTMLInputElement} */
                e
              );
              const B = t === void 0;
              if (g === "value") {
                let Z = I.defaultValue;
                I.removeAttribute(g), I.defaultValue = Z, I.value = I.__value = B ? Z : null;
              } else {
                let Z = I.defaultChecked;
                I.removeAttribute(g), I.defaultChecked = Z, I.checked = B ? Z : !1;
              }
            } else
              e.removeAttribute(m);
          else y || f.includes(g) && (l || typeof O != "string") ? (e[g] = O, g in s && (s[g] = zi)) : typeof O != "function" && H(e, g, O);
        }
    }
  }
  return c;
}
function Ua(e, t, n = [], r = [], a = [], i, s = !1, l = !1) {
  Di(a, n, r, (u) => {
    var c = void 0, h = {}, v = e.nodeName === Io, f = !1;
    if (Oa(() => {
      var b = t(...u.map(o)), E = Lo(
        e,
        c,
        b,
        i,
        s,
        l
      );
      f && v && "value" in b && fr(
        /** @type {HTMLSelectElement} */
        e,
        b.value
      );
      for (let g of Object.getOwnPropertySymbols(h))
        b[g] || Yt(h[g]);
      for (let g of Object.getOwnPropertySymbols(b)) {
        var p = b[g];
        g.description === Ui && (!c || p !== c[g]) && (h[g] && Yt(h[g]), h[g] = Jt(() => xo(e, () => p))), E[g] = p;
      }
      c = E;
    }), v) {
      var w = (
        /** @type {HTMLSelectElement} */
        e
      );
      wn(() => {
        fr(
          w,
          /** @type {Record<string | symbol, any>} */
          c.value,
          !0
        ), Oo(w);
      });
    }
    f = !0;
  });
}
function jn(e) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    e.__attributes ??= {
      [Ra]: e.nodeName.includes("-"),
      [Da]: e.namespaceURI === Bi
    }
  );
}
var Xr = /* @__PURE__ */ new Map();
function ja(e) {
  var t = e.getAttribute("is") || e.nodeName, n = Xr.get(t);
  if (n) return n;
  Xr.set(t, n = []);
  for (var r, a = e, i = Element.prototype; i !== a; ) {
    r = Ri(a);
    for (var s in r)
      r[s].set && n.push(s);
    a = ba(a);
  }
  return n;
}
function Sn(e, t, n = t) {
  var r = /* @__PURE__ */ new WeakSet();
  Xi(e, "input", async (a) => {
    var i = a ? e.defaultValue : e.value;
    if (i = Kn(e) ? $n(i) : i, n(i), Wt !== null && r.add(Wt), await en(), i !== (i = t())) {
      var s = e.selectionStart, l = e.selectionEnd, u = e.value.length;
      if (e.value = i ?? "", l !== null) {
        var c = e.value.length;
        s === l && l === u && c > u ? (e.selectionStart = c, e.selectionEnd = c) : (e.selectionStart = s, e.selectionEnd = Math.min(l, c));
      }
    }
  }), // If we are hydrating and the value has since changed,
  // then use the updated value from the input instead.
  // If defaultValue is set, then value == defaultValue
  // TODO Svelte 6: remove input.value check and set to empty string?
  Re(t) == null && e.value && (n(Kn(e) ? $n(e.value) : e.value), Wt !== null && r.add(Wt)), Or(() => {
    var a = t();
    if (e === document.activeElement) {
      var i = (
        /** @type {Batch} */
        Wt
      );
      if (r.has(i))
        return;
    }
    Kn(e) && a === $n(e.value) || e.type === "date" && !a && !e.value || a !== e.value && (e.value = a ?? "");
  });
}
function Kn(e) {
  var t = e.type;
  return t === "number" || t === "range";
}
function $n(e) {
  return e === "" ? null : +e;
}
function Wr(e, t) {
  return e === t || e?.[Aa] === t;
}
function Pt(e = {}, t, n, r) {
  var a = (
    /** @type {ComponentContext} */
    Ir.r
  ), i = (
    /** @type {Effect} */
    ln
  );
  return wn(() => {
    var s, l;
    return Or(() => {
      s = l, l = [], Re(() => {
        e !== n(...l) && (t(e, ...l), s && Wr(n(...s), e) && t(null, ...s));
      });
    }), () => {
      let u = i;
      for (; u !== a && u.parent !== null && u.parent.f & Wi; )
        u = u.parent;
      const c = () => {
        l && Wr(n(...l), e) && t(null, ...l);
      }, h = u.teardown;
      u.teardown = () => {
        c(), h?.();
      };
    };
  }), e;
}
function cn(e = !1) {
  const t = (
    /** @type {ComponentContextLegacy} */
    Ir
  ), n = t.l.u;
  if (!n) return;
  let r = () => Ge(t.s);
  if (e) {
    let a = 0, i = (
      /** @type {Record<string, any>} */
      {}
    );
    const s = Ca(() => {
      let l = !1;
      const u = t.s;
      for (const c in u)
        u[c] !== i[c] && (i[c] = u[c], l = !0);
      return l && a++, a;
    });
    r = () => o(s);
  }
  n.b.length && Ia(() => {
    qr(t, r), lr(n.b);
  }), Ot(() => {
    const a = Re(() => n.m.map(qi));
    return () => {
      for (const i of a)
        typeof i == "function" && i();
    };
  }), n.a.length && Ot(() => {
    qr(t, r), lr(n.a);
  });
}
function qr(e, t) {
  if (e.l.s)
    for (const n of e.l.s) o(n);
  t();
}
function Cn(e, t) {
  var n = (
    /** @type {Record<string, Function[] | Function>} */
    e.$$events?.[t.type]
  ), r = yn(n) ? n.slice() : n == null ? [] : [n];
  for (var a of r)
    a.call(this, t);
}
const Po = {
  get(e, t) {
    if (!e.exclude.includes(t))
      return e.props[t];
  },
  set(e, t) {
    return !1;
  },
  getOwnPropertyDescriptor(e, t) {
    if (!e.exclude.includes(t) && t in e.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: e.props[t]
      };
  },
  has(e, t) {
    return e.exclude.includes(t) ? !1 : t in e.props;
  },
  ownKeys(e) {
    return Reflect.ownKeys(e.props).filter((t) => !e.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function No(e, t, n) {
  return new Proxy(
    { props: e, exclude: t },
    Po
  );
}
const Mo = {
  get(e, t) {
    if (!e.exclude.includes(t))
      return o(e.version), t in e.special ? e.special[t]() : e.props[t];
  },
  set(e, t, n) {
    if (!(t in e.special)) {
      var r = ln;
      try {
        Ur(e.parent_effect), e.special[t] = P(
          {
            get [t]() {
              return e.props[t];
            }
          },
          /** @type {string} */
          t,
          Ha
        );
      } finally {
        Ur(r);
      }
    }
    return e.special[t](n), Dr(e.version), !0;
  },
  getOwnPropertyDescriptor(e, t) {
    if (!e.exclude.includes(t) && t in e.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: e.props[t]
      };
  },
  deleteProperty(e, t) {
    return e.exclude.includes(t) || (e.exclude.push(t), Dr(e.version)), !0;
  },
  has(e, t) {
    return e.exclude.includes(t) ? !1 : t in e.props;
  },
  ownKeys(e) {
    return Reflect.ownKeys(e.props).filter((t) => !e.exclude.includes(t));
  }
};
function Zr(e, t) {
  return new Proxy(
    {
      props: e,
      exclude: t,
      special: {},
      version: ur(0),
      // TODO this is only necessary because we need to track component
      // destruction inside `prop`, because of `bind:this`, but it
      // seems likely that we can simplify `bind:this` instead
      parent_effect: (
        /** @type {Effect} */
        ln
      )
    },
    Mo
  );
}
function P(e, t, n, r) {
  var a = !Qi || (n & Ki) !== 0, i = (n & Ji) !== 0, s = (n & eo) !== 0, l = (
    /** @type {V} */
    r
  ), u = !0, c = () => (u && (u = !1, l = s ? Re(
    /** @type {() => V} */
    r
  ) : (
    /** @type {V} */
    r
  )), l);
  let h;
  if (i) {
    var v = Aa in e || no in e;
    h = Zi(e, t)?.set ?? (v && t in e ? (m) => e[t] = m : void 0);
  }
  var f, w = !1;
  i ? [f, w] = ho(() => (
    /** @type {V} */
    e[t]
  )) : f = /** @type {V} */
  e[t], f === void 0 && r !== void 0 && (f = c(), h && (a && Yi(), h(f)));
  var b;
  if (a ? b = () => {
    var m = (
      /** @type {V} */
      e[t]
    );
    return m === void 0 ? c() : (u = !0, m);
  } : b = () => {
    var m = (
      /** @type {V} */
      e[t]
    );
    return m !== void 0 && (l = /** @type {V} */
    void 0), m === void 0 ? l : m;
  }, a && (n & Ha) === 0)
    return b;
  if (h) {
    var E = e.$$legacy;
    return (
      /** @type {() => V} */
      (function(m, O) {
        return arguments.length > 0 ? ((!a || !O || E || w) && h(O ? b() : m), m) : b();
      })
    );
  }
  var p = !1, g = ((n & $i) !== 0 ? Ca : nn)(() => (p = !1, b()));
  i && o(g);
  var y = (
    /** @type {Effect} */
    ln
  );
  return (
    /** @type {() => V} */
    (function(m, O) {
      if (arguments.length > 0) {
        const I = O ? o(g) : a && i ? At(m) : m;
        return C(g, I), p = !0, l !== void 0 && (l = I), m;
      }
      return to && p || (y.f & Sa) !== 0 ? g.v : o(g);
    })
  );
}
function Bo(e, t, { bubbles: n = !1, cancelable: r = !1 } = {}) {
  return new CustomEvent(e, { detail: t, bubbles: n, cancelable: r });
}
function Pr() {
  const e = Ir;
  return e === null && so(), (t, n, r) => {
    const a = (
      /** @type {Record<string, Function | Function[]>} */
      e.s.$$events?.[
        /** @type {string} */
        t
      ]
    );
    if (a) {
      const i = yn(a) ? a.slice() : [a], s = Bo(
        /** @type {string} */
        t,
        n,
        r
      );
      for (const l of i)
        l.call(e.x, s);
      return !s.defaultPrevented;
    }
    return !0;
  };
}
const Ro = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Yr = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Ro.reduce((e, { color: t, primary: n, secondary: r }) => ({
  ...e,
  [t]: {
    primary: Yr[t][n],
    secondary: Yr[t][r]
  }
}), {});
function Do(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var er, Jr;
function Uo() {
  if (Jr) return er;
  Jr = 1;
  var e = function(y) {
    return t(y) && !n(y);
  };
  function t(g) {
    return !!g && typeof g == "object";
  }
  function n(g) {
    var y = Object.prototype.toString.call(g);
    return y === "[object RegExp]" || y === "[object Date]" || i(g);
  }
  var r = typeof Symbol == "function" && Symbol.for, a = r ? /* @__PURE__ */ Symbol.for("react.element") : 60103;
  function i(g) {
    return g.$$typeof === a;
  }
  function s(g) {
    return Array.isArray(g) ? [] : {};
  }
  function l(g, y) {
    return y.clone !== !1 && y.isMergeableObject(g) ? E(s(g), g, y) : g;
  }
  function u(g, y, m) {
    return g.concat(y).map(function(O) {
      return l(O, m);
    });
  }
  function c(g, y) {
    if (!y.customMerge)
      return E;
    var m = y.customMerge(g);
    return typeof m == "function" ? m : E;
  }
  function h(g) {
    return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(g).filter(function(y) {
      return Object.propertyIsEnumerable.call(g, y);
    }) : [];
  }
  function v(g) {
    return Object.keys(g).concat(h(g));
  }
  function f(g, y) {
    try {
      return y in g;
    } catch {
      return !1;
    }
  }
  function w(g, y) {
    return f(g, y) && !(Object.hasOwnProperty.call(g, y) && Object.propertyIsEnumerable.call(g, y));
  }
  function b(g, y, m) {
    var O = {};
    return m.isMergeableObject(g) && v(g).forEach(function(I) {
      O[I] = l(g[I], m);
    }), v(y).forEach(function(I) {
      w(g, I) || (f(g, I) && m.isMergeableObject(y[I]) ? O[I] = c(I, m)(g[I], y[I], m) : O[I] = l(y[I], m));
    }), O;
  }
  function E(g, y, m) {
    m = m || {}, m.arrayMerge = m.arrayMerge || u, m.isMergeableObject = m.isMergeableObject || e, m.cloneUnlessOtherwiseSpecified = l;
    var O = Array.isArray(y), I = Array.isArray(g), B = O === I;
    return B ? O ? m.arrayMerge(g, y, m) : b(g, y, m) : l(y, m);
  }
  E.all = function(y, m) {
    if (!Array.isArray(y))
      throw new Error("first argument should be an array");
    return y.reduce(function(O, I) {
      return E(O, I, m);
    }, {});
  };
  var p = E;
  return er = p, er;
}
var jo = Uo();
const Fo = /* @__PURE__ */ Do(jo);
var hr = function(e, t) {
  return hr = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, r) {
    n.__proto__ = r;
  } || function(n, r) {
    for (var a in r) Object.prototype.hasOwnProperty.call(r, a) && (n[a] = r[a]);
  }, hr(e, t);
};
function Fn(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
  hr(e, t);
  function n() {
    this.constructor = e;
  }
  e.prototype = t === null ? Object.create(t) : (n.prototype = t.prototype, new n());
}
var He = function() {
  return He = Object.assign || function(t) {
    for (var n, r = 1, a = arguments.length; r < a; r++) {
      n = arguments[r];
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
    }
    return t;
  }, He.apply(this, arguments);
};
function Go(e, t) {
  var n = {};
  for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var a = 0, r = Object.getOwnPropertySymbols(e); a < r.length; a++)
      t.indexOf(r[a]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[a]) && (n[r[a]] = e[r[a]]);
  return n;
}
function tr(e, t, n) {
  if (n || arguments.length === 2) for (var r = 0, a = t.length, i; r < a; r++)
    (i || !(r in t)) && (i || (i = Array.prototype.slice.call(t, 0, r)), i[r] = t[r]);
  return e.concat(i || Array.prototype.slice.call(t));
}
function nr(e, t) {
  var n = t && t.cache ? t.cache : Yo, r = t && t.serializer ? t.serializer : qo, a = t && t.strategy ? t.strategy : Xo;
  return a(e, {
    cache: n,
    serializer: r
  });
}
function zo(e) {
  return e == null || typeof e == "number" || typeof e == "boolean";
}
function Vo(e, t, n, r) {
  var a = zo(r) ? r : n(r), i = t.get(a);
  return typeof i > "u" && (i = e.call(this, r), t.set(a, i)), i;
}
function Fa(e, t, n) {
  var r = Array.prototype.slice.call(arguments, 3), a = n(r), i = t.get(a);
  return typeof i > "u" && (i = e.apply(this, r), t.set(a, i)), i;
}
function Ga(e, t, n, r, a) {
  return n.bind(t, e, r, a);
}
function Xo(e, t) {
  var n = e.length === 1 ? Vo : Fa;
  return Ga(e, this, n, t.cache.create(), t.serializer);
}
function Wo(e, t) {
  return Ga(e, this, Fa, t.cache.create(), t.serializer);
}
var qo = function() {
  return JSON.stringify(arguments);
}, Zo = (
  /** @class */
  (function() {
    function e() {
      this.cache = /* @__PURE__ */ Object.create(null);
    }
    return e.prototype.get = function(t) {
      return this.cache[t];
    }, e.prototype.set = function(t, n) {
      this.cache[t] = n;
    }, e;
  })()
), Yo = {
  create: function() {
    return new Zo();
  }
}, rr = {
  variadic: Wo
}, xe;
(function(e) {
  e[e.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", e[e.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", e[e.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", e[e.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", e[e.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", e[e.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", e[e.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", e[e.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", e[e.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", e[e.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", e[e.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", e[e.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", e[e.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", e[e.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", e[e.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", e[e.INVALID_TAG = 23] = "INVALID_TAG", e[e.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", e[e.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", e[e.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(xe || (xe = {}));
var Fe;
(function(e) {
  e[e.literal = 0] = "literal", e[e.argument = 1] = "argument", e[e.number = 2] = "number", e[e.date = 3] = "date", e[e.time = 4] = "time", e[e.select = 5] = "select", e[e.plural = 6] = "plural", e[e.pound = 7] = "pound", e[e.tag = 8] = "tag";
})(Fe || (Fe = {}));
var an;
(function(e) {
  e[e.number = 0] = "number", e[e.dateTime = 1] = "dateTime";
})(an || (an = {}));
function Qr(e) {
  return e.type === Fe.literal;
}
function Jo(e) {
  return e.type === Fe.argument;
}
function za(e) {
  return e.type === Fe.number;
}
function Va(e) {
  return e.type === Fe.date;
}
function Xa(e) {
  return e.type === Fe.time;
}
function Wa(e) {
  return e.type === Fe.select;
}
function qa(e) {
  return e.type === Fe.plural;
}
function Qo(e) {
  return e.type === Fe.pound;
}
function Za(e) {
  return e.type === Fe.tag;
}
function Ya(e) {
  return !!(e && typeof e == "object" && e.type === an.number);
}
function vr(e) {
  return !!(e && typeof e == "object" && e.type === an.dateTime);
}
var Ja = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, Ko = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function $o(e) {
  var t = {};
  return e.replace(Ko, function(n) {
    var r = n.length;
    switch (n[0]) {
      // Era
      case "G":
        t.era = r === 4 ? "long" : r === 5 ? "narrow" : "short";
        break;
      // Year
      case "y":
        t.year = r === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      // Quarter
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      // Month
      case "M":
      case "L":
        t.month = ["numeric", "2-digit", "short", "long", "narrow"][r - 1];
        break;
      // Week
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        t.day = ["numeric", "2-digit"][r - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      // Weekday
      case "E":
        t.weekday = r === 4 ? "long" : r === 5 ? "narrow" : "short";
        break;
      case "e":
        if (r < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][r - 4];
        break;
      case "c":
        if (r < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][r - 4];
        break;
      // Period
      case "a":
        t.hour12 = !0;
        break;
      case "b":
      // am, pm, noon, midnight
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      // Hour
      case "h":
        t.hourCycle = "h12", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "H":
        t.hourCycle = "h23", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "K":
        t.hourCycle = "h11", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "k":
        t.hourCycle = "h24", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      // Minute
      case "m":
        t.minute = ["numeric", "2-digit"][r - 1];
        break;
      // Second
      case "s":
        t.second = ["numeric", "2-digit"][r - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      // Zone
      case "z":
        t.timeZoneName = r < 4 ? "short" : "long";
        break;
      case "Z":
      // 1..3, 4, 5: The ISO8601 varios formats
      case "O":
      // 1, 4: milliseconds in day short, long
      case "v":
      // 1, 4: generic non-location format
      case "V":
      // 1, 2, 3, 4: time zone ID or city
      case "X":
      // 1, 2, 3, 4: The ISO8601 varios formats
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), t;
}
var es = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function ts(e) {
  if (e.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var t = e.split(es).filter(function(f) {
    return f.length > 0;
  }), n = [], r = 0, a = t; r < a.length; r++) {
    var i = a[r], s = i.split("/");
    if (s.length === 0)
      throw new Error("Invalid number skeleton");
    for (var l = s[0], u = s.slice(1), c = 0, h = u; c < h.length; c++) {
      var v = h[c];
      if (v.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: l, options: u });
  }
  return n;
}
function ns(e) {
  return e.replace(/^(.*?)-/, "");
}
var Kr = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, Qa = /^(@+)?(\+|#+)?[rs]?$/g, rs = /(\*)(0+)|(#+)(0+)|(0+)/g, Ka = /^(0+)$/;
function $r(e) {
  var t = {};
  return e[e.length - 1] === "r" ? t.roundingPriority = "morePrecision" : e[e.length - 1] === "s" && (t.roundingPriority = "lessPrecision"), e.replace(Qa, function(n, r, a) {
    return typeof a != "string" ? (t.minimumSignificantDigits = r.length, t.maximumSignificantDigits = r.length) : a === "+" ? t.minimumSignificantDigits = r.length : r[0] === "#" ? t.maximumSignificantDigits = r.length : (t.minimumSignificantDigits = r.length, t.maximumSignificantDigits = r.length + (typeof a == "string" ? a.length : 0)), "";
  }), t;
}
function $a(e) {
  switch (e) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function as(e) {
  var t;
  if (e[0] === "E" && e[1] === "E" ? (t = {
    notation: "engineering"
  }, e = e.slice(2)) : e[0] === "E" && (t = {
    notation: "scientific"
  }, e = e.slice(1)), t) {
    var n = e.slice(0, 2);
    if (n === "+!" ? (t.signDisplay = "always", e = e.slice(2)) : n === "+?" && (t.signDisplay = "exceptZero", e = e.slice(2)), !Ka.test(e))
      throw new Error("Malformed concise eng/scientific notation");
    t.minimumIntegerDigits = e.length;
  }
  return t;
}
function ea(e) {
  var t = {}, n = $a(e);
  return n || t;
}
function is(e) {
  for (var t = {}, n = 0, r = e; n < r.length; n++) {
    var a = r[n];
    switch (a.stem) {
      case "percent":
      case "%":
        t.style = "percent";
        continue;
      case "%x100":
        t.style = "percent", t.scale = 100;
        continue;
      case "currency":
        t.style = "currency", t.currency = a.options[0];
        continue;
      case "group-off":
      case ",_":
        t.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        t.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        t.style = "unit", t.unit = ns(a.options[0]);
        continue;
      case "compact-short":
      case "K":
        t.notation = "compact", t.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        t.notation = "compact", t.compactDisplay = "long";
        continue;
      case "scientific":
        t = He(He(He({}, t), { notation: "scientific" }), a.options.reduce(function(u, c) {
          return He(He({}, u), ea(c));
        }, {}));
        continue;
      case "engineering":
        t = He(He(He({}, t), { notation: "engineering" }), a.options.reduce(function(u, c) {
          return He(He({}, u), ea(c));
        }, {}));
        continue;
      case "notation-simple":
        t.notation = "standard";
        continue;
      // https://github.com/unicode-org/icu/blob/master/icu4c/source/i18n/unicode/unumberformatter.h
      case "unit-width-narrow":
        t.currencyDisplay = "narrowSymbol", t.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        t.currencyDisplay = "code", t.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        t.currencyDisplay = "name", t.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        t.currencyDisplay = "symbol";
        continue;
      case "scale":
        t.scale = parseFloat(a.options[0]);
        continue;
      case "rounding-mode-floor":
        t.roundingMode = "floor";
        continue;
      case "rounding-mode-ceiling":
        t.roundingMode = "ceil";
        continue;
      case "rounding-mode-down":
        t.roundingMode = "trunc";
        continue;
      case "rounding-mode-up":
        t.roundingMode = "expand";
        continue;
      case "rounding-mode-half-even":
        t.roundingMode = "halfEven";
        continue;
      case "rounding-mode-half-down":
        t.roundingMode = "halfTrunc";
        continue;
      case "rounding-mode-half-up":
        t.roundingMode = "halfExpand";
        continue;
      // https://unicode-org.github.io/icu/userguide/format_parse/numbers/skeletons.html#integer-width
      case "integer-width":
        if (a.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        a.options[0].replace(rs, function(u, c, h, v, f, w) {
          if (c)
            t.minimumIntegerDigits = h.length;
          else {
            if (v && f)
              throw new Error("We currently do not support maximum integer digits");
            if (w)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (Ka.test(a.stem)) {
      t.minimumIntegerDigits = a.stem.length;
      continue;
    }
    if (Kr.test(a.stem)) {
      if (a.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      a.stem.replace(Kr, function(u, c, h, v, f, w) {
        return h === "*" ? t.minimumFractionDigits = c.length : v && v[0] === "#" ? t.maximumFractionDigits = v.length : f && w ? (t.minimumFractionDigits = f.length, t.maximumFractionDigits = f.length + w.length) : (t.minimumFractionDigits = c.length, t.maximumFractionDigits = c.length), "";
      });
      var i = a.options[0];
      i === "w" ? t = He(He({}, t), { trailingZeroDisplay: "stripIfInteger" }) : i && (t = He(He({}, t), $r(i)));
      continue;
    }
    if (Qa.test(a.stem)) {
      t = He(He({}, t), $r(a.stem));
      continue;
    }
    var s = $a(a.stem);
    s && (t = He(He({}, t), s));
    var l = as(a.stem);
    l && (t = He(He({}, t), l));
  }
  return t;
}
var On = {
  "001": [
    "H",
    "h"
  ],
  419: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AD: [
    "H",
    "hB"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AS: [
    "h",
    "H"
  ],
  AT: [
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  AX: [
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BI: [
    "H",
    "h"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  BO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  BQ: [
    "H"
  ],
  BR: [
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BT: [
    "h",
    "H"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BY: [
    "H",
    "h"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CD: [
    "hB",
    "H"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  CI: [
    "H",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CL: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CP: [
    "H"
  ],
  CR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CU: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  CV: [
    "H",
    "hB"
  ],
  CW: [
    "H",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CZ: [
    "H"
  ],
  DE: [
    "H",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DJ: [
    "h",
    "H"
  ],
  DK: [
    "H"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EC: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  EE: [
    "H",
    "hB"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  FI: [
    "H"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FO: [
    "H",
    "h"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  GF: [
    "H",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GH: [
    "h",
    "H"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GL: [
    "H",
    "h"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GT: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HN: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  HR: [
    "H",
    "hB"
  ],
  HU: [
    "H",
    "h"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  ID: [
    "H"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IN: [
    "h",
    "H"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  IS: [
    "H"
  ],
  IT: [
    "H",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JP: [
    "H",
    "K",
    "h"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LS: [
    "h",
    "H"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  MF: [
    "H",
    "hB"
  ],
  MG: [
    "H",
    "h"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ML: [
    "H"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MT: [
    "H",
    "h"
  ],
  MU: [
    "H",
    "h"
  ],
  MV: [
    "H",
    "h"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MX: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NC: [
    "H",
    "hB"
  ],
  NE: [
    "H"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NI: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NL: [
    "H",
    "hB"
  ],
  NO: [
    "H",
    "h"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  PG: [
    "h",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  PL: [
    "H",
    "h"
  ],
  PM: [
    "H",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PT: [
    "H",
    "hB"
  ],
  PW: [
    "h",
    "H"
  ],
  PY: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  RU: [
    "H"
  ],
  RW: [
    "H",
    "h"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SE: [
    "H"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  SO: [
    "h",
    "H"
  ],
  SR: [
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  SV: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TH: [
    "H",
    "h"
  ],
  TJ: [
    "H",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TM: [
    "H",
    "h"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  TR: [
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UY: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VN: [
    "H",
    "h"
  ],
  VU: [
    "h",
    "H"
  ],
  WF: [
    "H",
    "hB"
  ],
  WS: [
    "h",
    "H"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YT: [
    "H",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZW: [
    "H",
    "h"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-HK": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-IL": [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "en-MY": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ]
};
function os(e, t) {
  for (var n = "", r = 0; r < e.length; r++) {
    var a = e.charAt(r);
    if (a === "j") {
      for (var i = 0; r + 1 < e.length && e.charAt(r + 1) === a; )
        i++, r++;
      var s = 1 + (i & 1), l = i < 2 ? 1 : 3 + (i >> 1), u = "a", c = ss(t);
      for ((c == "H" || c == "k") && (l = 0); l-- > 0; )
        n += u;
      for (; s-- > 0; )
        n = c + n;
    } else a === "J" ? n += "H" : n += a;
  }
  return n;
}
function ss(e) {
  var t = e.hourCycle;
  if (t === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  e.hourCycles && // @ts-ignore
  e.hourCycles.length && (t = e.hourCycles[0]), t)
    switch (t) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = e.language, r;
  n !== "root" && (r = e.maximize().region);
  var a = On[r || ""] || On[n || ""] || On["".concat(n, "-001")] || On["001"];
  return a[0];
}
var ar, ls = new RegExp("^".concat(Ja.source, "*")), us = new RegExp("".concat(Ja.source, "*$"));
function ke(e, t) {
  return { start: e, end: t };
}
var cs = !!String.prototype.startsWith && "_a".startsWith("a", 1), ds = !!String.fromCodePoint, fs = !!Object.fromEntries, hs = !!String.prototype.codePointAt, vs = !!String.prototype.trimStart, ps = !!String.prototype.trimEnd, gs = !!Number.isSafeInteger, ms = gs ? Number.isSafeInteger : function(e) {
  return typeof e == "number" && isFinite(e) && Math.floor(e) === e && Math.abs(e) <= 9007199254740991;
}, pr = !0;
try {
  var bs = ti("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  pr = ((ar = bs.exec("a")) === null || ar === void 0 ? void 0 : ar[0]) === "a";
} catch {
  pr = !1;
}
var ta = cs ? (
  // Native
  function(t, n, r) {
    return t.startsWith(n, r);
  }
) : (
  // For IE11
  function(t, n, r) {
    return t.slice(r, r + n.length) === n;
  }
), gr = ds ? String.fromCodePoint : (
  // IE11
  function() {
    for (var t = [], n = 0; n < arguments.length; n++)
      t[n] = arguments[n];
    for (var r = "", a = t.length, i = 0, s; a > i; ) {
      if (s = t[i++], s > 1114111)
        throw RangeError(s + " is not a valid code point");
      r += s < 65536 ? String.fromCharCode(s) : String.fromCharCode(((s -= 65536) >> 10) + 55296, s % 1024 + 56320);
    }
    return r;
  }
), na = (
  // native
  fs ? Object.fromEntries : (
    // Ponyfill
    function(t) {
      for (var n = {}, r = 0, a = t; r < a.length; r++) {
        var i = a[r], s = i[0], l = i[1];
        n[s] = l;
      }
      return n;
    }
  )
), ei = hs ? (
  // Native
  function(t, n) {
    return t.codePointAt(n);
  }
) : (
  // IE 11
  function(t, n) {
    var r = t.length;
    if (!(n < 0 || n >= r)) {
      var a = t.charCodeAt(n), i;
      return a < 55296 || a > 56319 || n + 1 === r || (i = t.charCodeAt(n + 1)) < 56320 || i > 57343 ? a : (a - 55296 << 10) + (i - 56320) + 65536;
    }
  }
), _s = vs ? (
  // Native
  function(t) {
    return t.trimStart();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(ls, "");
  }
), ys = ps ? (
  // Native
  function(t) {
    return t.trimEnd();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(us, "");
  }
);
function ti(e, t) {
  return new RegExp(e, t);
}
var mr;
if (pr) {
  var ra = ti("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  mr = function(t, n) {
    var r;
    ra.lastIndex = n;
    var a = ra.exec(t);
    return (r = a[1]) !== null && r !== void 0 ? r : "";
  };
} else
  mr = function(t, n) {
    for (var r = []; ; ) {
      var a = ei(t, n);
      if (a === void 0 || ni(a) || ks(a))
        break;
      r.push(a), n += a >= 65536 ? 2 : 1;
    }
    return gr.apply(void 0, r);
  };
var ws = (
  /** @class */
  (function() {
    function e(t, n) {
      n === void 0 && (n = {}), this.message = t, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return e.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, e.prototype.parseMessage = function(t, n, r) {
      for (var a = []; !this.isEOF(); ) {
        var i = this.char();
        if (i === 123) {
          var s = this.parseArgument(t, r);
          if (s.err)
            return s;
          a.push(s.val);
        } else {
          if (i === 125 && t > 0)
            break;
          if (i === 35 && (n === "plural" || n === "selectordinal")) {
            var l = this.clonePosition();
            this.bump(), a.push({
              type: Fe.pound,
              location: ke(l, this.clonePosition())
            });
          } else if (i === 60 && !this.ignoreTag && this.peek() === 47) {
            if (r)
              break;
            return this.error(xe.UNMATCHED_CLOSING_TAG, ke(this.clonePosition(), this.clonePosition()));
          } else if (i === 60 && !this.ignoreTag && br(this.peek() || 0)) {
            var s = this.parseTag(t, n);
            if (s.err)
              return s;
            a.push(s.val);
          } else {
            var s = this.parseLiteral(t, n);
            if (s.err)
              return s;
            a.push(s.val);
          }
        }
      }
      return { val: a, err: null };
    }, e.prototype.parseTag = function(t, n) {
      var r = this.clonePosition();
      this.bump();
      var a = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: Fe.literal,
            value: "<".concat(a, "/>"),
            location: ke(r, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var i = this.parseMessage(t + 1, n, !0);
        if (i.err)
          return i;
        var s = i.val, l = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !br(this.char()))
            return this.error(xe.INVALID_TAG, ke(l, this.clonePosition()));
          var u = this.clonePosition(), c = this.parseTagName();
          return a !== c ? this.error(xe.UNMATCHED_CLOSING_TAG, ke(u, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: Fe.tag,
              value: a,
              children: s,
              location: ke(r, this.clonePosition())
            },
            err: null
          } : this.error(xe.INVALID_TAG, ke(l, this.clonePosition())));
        } else
          return this.error(xe.UNCLOSED_TAG, ke(r, this.clonePosition()));
      } else
        return this.error(xe.INVALID_TAG, ke(r, this.clonePosition()));
    }, e.prototype.parseTagName = function() {
      var t = this.offset();
      for (this.bump(); !this.isEOF() && Es(this.char()); )
        this.bump();
      return this.message.slice(t, this.offset());
    }, e.prototype.parseLiteral = function(t, n) {
      for (var r = this.clonePosition(), a = ""; ; ) {
        var i = this.tryParseQuote(n);
        if (i) {
          a += i;
          continue;
        }
        var s = this.tryParseUnquoted(t, n);
        if (s) {
          a += s;
          continue;
        }
        var l = this.tryParseLeftAngleBracket();
        if (l) {
          a += l;
          continue;
        }
        break;
      }
      var u = ke(r, this.clonePosition());
      return {
        val: { type: Fe.literal, value: a, location: u },
        err: null
      };
    }, e.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !xs(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, e.prototype.tryParseQuote = function(t) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        // '{', '<', '>', '}'
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (t === "plural" || t === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var r = this.char();
        if (r === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(r);
        this.bump();
      }
      return gr.apply(void 0, n);
    }, e.prototype.tryParseUnquoted = function(t, n) {
      if (this.isEOF())
        return null;
      var r = this.char();
      return r === 60 || r === 123 || r === 35 && (n === "plural" || n === "selectordinal") || r === 125 && t > 0 ? null : (this.bump(), gr(r));
    }, e.prototype.parseArgument = function(t, n) {
      var r = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(xe.EXPECT_ARGUMENT_CLOSING_BRACE, ke(r, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(xe.EMPTY_ARGUMENT, ke(r, this.clonePosition()));
      var a = this.parseIdentifierIfPossible().value;
      if (!a)
        return this.error(xe.MALFORMED_ARGUMENT, ke(r, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(xe.EXPECT_ARGUMENT_CLOSING_BRACE, ke(r, this.clonePosition()));
      switch (this.char()) {
        // Simple argument: `{name}`
        case 125:
          return this.bump(), {
            val: {
              type: Fe.argument,
              // value does not include the opening and closing braces.
              value: a,
              location: ke(r, this.clonePosition())
            },
            err: null
          };
        // Argument with options: `{name, format, ...}`
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(xe.EXPECT_ARGUMENT_CLOSING_BRACE, ke(r, this.clonePosition())) : this.parseArgumentOptions(t, n, a, r);
        default:
          return this.error(xe.MALFORMED_ARGUMENT, ke(r, this.clonePosition()));
      }
    }, e.prototype.parseIdentifierIfPossible = function() {
      var t = this.clonePosition(), n = this.offset(), r = mr(this.message, n), a = n + r.length;
      this.bumpTo(a);
      var i = this.clonePosition(), s = ke(t, i);
      return { value: r, location: s };
    }, e.prototype.parseArgumentOptions = function(t, n, r, a) {
      var i, s = this.clonePosition(), l = this.parseIdentifierIfPossible().value, u = this.clonePosition();
      switch (l) {
        case "":
          return this.error(xe.EXPECT_ARGUMENT_TYPE, ke(s, u));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var c = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var h = this.clonePosition(), v = this.parseSimpleArgStyleIfPossible();
            if (v.err)
              return v;
            var f = ys(v.val);
            if (f.length === 0)
              return this.error(xe.EXPECT_ARGUMENT_STYLE, ke(this.clonePosition(), this.clonePosition()));
            var w = ke(h, this.clonePosition());
            c = { style: f, styleLocation: w };
          }
          var b = this.tryParseArgumentClose(a);
          if (b.err)
            return b;
          var E = ke(a, this.clonePosition());
          if (c && ta(c?.style, "::", 0)) {
            var p = _s(c.style.slice(2));
            if (l === "number") {
              var v = this.parseNumberSkeletonFromString(p, c.styleLocation);
              return v.err ? v : {
                val: { type: Fe.number, value: r, location: E, style: v.val },
                err: null
              };
            } else {
              if (p.length === 0)
                return this.error(xe.EXPECT_DATE_TIME_SKELETON, E);
              var g = p;
              this.locale && (g = os(p, this.locale));
              var f = {
                type: an.dateTime,
                pattern: g,
                location: c.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? $o(g) : {}
              }, y = l === "date" ? Fe.date : Fe.time;
              return {
                val: { type: y, value: r, location: E, style: f },
                err: null
              };
            }
          }
          return {
            val: {
              type: l === "number" ? Fe.number : l === "date" ? Fe.date : Fe.time,
              value: r,
              location: E,
              style: (i = c?.style) !== null && i !== void 0 ? i : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var m = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(xe.EXPECT_SELECT_ARGUMENT_OPTIONS, ke(m, He({}, m)));
          this.bumpSpace();
          var O = this.parseIdentifierIfPossible(), I = 0;
          if (l !== "select" && O.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(xe.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, ke(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var v = this.tryParseDecimalInteger(xe.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, xe.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (v.err)
              return v;
            this.bumpSpace(), O = this.parseIdentifierIfPossible(), I = v.val;
          }
          var B = this.tryParsePluralOrSelectOptions(t, l, n, O);
          if (B.err)
            return B;
          var b = this.tryParseArgumentClose(a);
          if (b.err)
            return b;
          var Z = ke(a, this.clonePosition());
          return l === "select" ? {
            val: {
              type: Fe.select,
              value: r,
              options: na(B.val),
              location: Z
            },
            err: null
          } : {
            val: {
              type: Fe.plural,
              value: r,
              options: na(B.val),
              offset: I,
              pluralType: l === "plural" ? "cardinal" : "ordinal",
              location: Z
            },
            err: null
          };
        }
        default:
          return this.error(xe.INVALID_ARGUMENT_TYPE, ke(s, u));
      }
    }, e.prototype.tryParseArgumentClose = function(t) {
      return this.isEOF() || this.char() !== 125 ? this.error(xe.EXPECT_ARGUMENT_CLOSING_BRACE, ke(t, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, e.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var t = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var r = this.char();
        switch (r) {
          case 39: {
            this.bump();
            var a = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(xe.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, ke(a, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            t += 1, this.bump();
            break;
          }
          case 125: {
            if (t > 0)
              t -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, e.prototype.parseNumberSkeletonFromString = function(t, n) {
      var r = [];
      try {
        r = ts(t);
      } catch {
        return this.error(xe.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: an.number,
          tokens: r,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? is(r) : {}
        },
        err: null
      };
    }, e.prototype.tryParsePluralOrSelectOptions = function(t, n, r, a) {
      for (var i, s = !1, l = [], u = /* @__PURE__ */ new Set(), c = a.value, h = a.location; ; ) {
        if (c.length === 0) {
          var v = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var f = this.tryParseDecimalInteger(xe.EXPECT_PLURAL_ARGUMENT_SELECTOR, xe.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (f.err)
              return f;
            h = ke(v, this.clonePosition()), c = this.message.slice(v.offset, this.offset());
          } else
            break;
        }
        if (u.has(c))
          return this.error(n === "select" ? xe.DUPLICATE_SELECT_ARGUMENT_SELECTOR : xe.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, h);
        c === "other" && (s = !0), this.bumpSpace();
        var w = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? xe.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : xe.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, ke(this.clonePosition(), this.clonePosition()));
        var b = this.parseMessage(t + 1, n, r);
        if (b.err)
          return b;
        var E = this.tryParseArgumentClose(w);
        if (E.err)
          return E;
        l.push([
          c,
          {
            value: b.val,
            location: ke(w, this.clonePosition())
          }
        ]), u.add(c), this.bumpSpace(), i = this.parseIdentifierIfPossible(), c = i.value, h = i.location;
      }
      return l.length === 0 ? this.error(n === "select" ? xe.EXPECT_SELECT_ARGUMENT_SELECTOR : xe.EXPECT_PLURAL_ARGUMENT_SELECTOR, ke(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !s ? this.error(xe.MISSING_OTHER_CLAUSE, ke(this.clonePosition(), this.clonePosition())) : { val: l, err: null };
    }, e.prototype.tryParseDecimalInteger = function(t, n) {
      var r = 1, a = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (r = -1);
      for (var i = !1, s = 0; !this.isEOF(); ) {
        var l = this.char();
        if (l >= 48 && l <= 57)
          i = !0, s = s * 10 + (l - 48), this.bump();
        else
          break;
      }
      var u = ke(a, this.clonePosition());
      return i ? (s *= r, ms(s) ? { val: s, err: null } : this.error(n, u)) : this.error(t, u);
    }, e.prototype.offset = function() {
      return this.position.offset;
    }, e.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, e.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, e.prototype.char = function() {
      var t = this.position.offset;
      if (t >= this.message.length)
        throw Error("out of bound");
      var n = ei(this.message, t);
      if (n === void 0)
        throw Error("Offset ".concat(t, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, e.prototype.error = function(t, n) {
      return {
        val: null,
        err: {
          kind: t,
          message: this.message,
          location: n
        }
      };
    }, e.prototype.bump = function() {
      if (!this.isEOF()) {
        var t = this.char();
        t === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += t < 65536 ? 1 : 2);
      }
    }, e.prototype.bumpIf = function(t) {
      if (ta(this.message, t, this.offset())) {
        for (var n = 0; n < t.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, e.prototype.bumpUntil = function(t) {
      var n = this.offset(), r = this.message.indexOf(t, n);
      return r >= 0 ? (this.bumpTo(r), !0) : (this.bumpTo(this.message.length), !1);
    }, e.prototype.bumpTo = function(t) {
      if (this.offset() > t)
        throw Error("targetOffset ".concat(t, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (t = Math.min(t, this.message.length); ; ) {
        var n = this.offset();
        if (n === t)
          break;
        if (n > t)
          throw Error("targetOffset ".concat(t, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, e.prototype.bumpSpace = function() {
      for (; !this.isEOF() && ni(this.char()); )
        this.bump();
    }, e.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var t = this.char(), n = this.offset(), r = this.message.charCodeAt(n + (t >= 65536 ? 2 : 1));
      return r ?? null;
    }, e;
  })()
);
function br(e) {
  return e >= 97 && e <= 122 || e >= 65 && e <= 90;
}
function xs(e) {
  return br(e) || e === 47;
}
function Es(e) {
  return e === 45 || e === 46 || e >= 48 && e <= 57 || e === 95 || e >= 97 && e <= 122 || e >= 65 && e <= 90 || e == 183 || e >= 192 && e <= 214 || e >= 216 && e <= 246 || e >= 248 && e <= 893 || e >= 895 && e <= 8191 || e >= 8204 && e <= 8205 || e >= 8255 && e <= 8256 || e >= 8304 && e <= 8591 || e >= 11264 && e <= 12271 || e >= 12289 && e <= 55295 || e >= 63744 && e <= 64975 || e >= 65008 && e <= 65533 || e >= 65536 && e <= 983039;
}
function ni(e) {
  return e >= 9 && e <= 13 || e === 32 || e === 133 || e >= 8206 && e <= 8207 || e === 8232 || e === 8233;
}
function ks(e) {
  return e >= 33 && e <= 35 || e === 36 || e >= 37 && e <= 39 || e === 40 || e === 41 || e === 42 || e === 43 || e === 44 || e === 45 || e >= 46 && e <= 47 || e >= 58 && e <= 59 || e >= 60 && e <= 62 || e >= 63 && e <= 64 || e === 91 || e === 92 || e === 93 || e === 94 || e === 96 || e === 123 || e === 124 || e === 125 || e === 126 || e === 161 || e >= 162 && e <= 165 || e === 166 || e === 167 || e === 169 || e === 171 || e === 172 || e === 174 || e === 176 || e === 177 || e === 182 || e === 187 || e === 191 || e === 215 || e === 247 || e >= 8208 && e <= 8213 || e >= 8214 && e <= 8215 || e === 8216 || e === 8217 || e === 8218 || e >= 8219 && e <= 8220 || e === 8221 || e === 8222 || e === 8223 || e >= 8224 && e <= 8231 || e >= 8240 && e <= 8248 || e === 8249 || e === 8250 || e >= 8251 && e <= 8254 || e >= 8257 && e <= 8259 || e === 8260 || e === 8261 || e === 8262 || e >= 8263 && e <= 8273 || e === 8274 || e === 8275 || e >= 8277 && e <= 8286 || e >= 8592 && e <= 8596 || e >= 8597 && e <= 8601 || e >= 8602 && e <= 8603 || e >= 8604 && e <= 8607 || e === 8608 || e >= 8609 && e <= 8610 || e === 8611 || e >= 8612 && e <= 8613 || e === 8614 || e >= 8615 && e <= 8621 || e === 8622 || e >= 8623 && e <= 8653 || e >= 8654 && e <= 8655 || e >= 8656 && e <= 8657 || e === 8658 || e === 8659 || e === 8660 || e >= 8661 && e <= 8691 || e >= 8692 && e <= 8959 || e >= 8960 && e <= 8967 || e === 8968 || e === 8969 || e === 8970 || e === 8971 || e >= 8972 && e <= 8991 || e >= 8992 && e <= 8993 || e >= 8994 && e <= 9e3 || e === 9001 || e === 9002 || e >= 9003 && e <= 9083 || e === 9084 || e >= 9085 && e <= 9114 || e >= 9115 && e <= 9139 || e >= 9140 && e <= 9179 || e >= 9180 && e <= 9185 || e >= 9186 && e <= 9254 || e >= 9255 && e <= 9279 || e >= 9280 && e <= 9290 || e >= 9291 && e <= 9311 || e >= 9472 && e <= 9654 || e === 9655 || e >= 9656 && e <= 9664 || e === 9665 || e >= 9666 && e <= 9719 || e >= 9720 && e <= 9727 || e >= 9728 && e <= 9838 || e === 9839 || e >= 9840 && e <= 10087 || e === 10088 || e === 10089 || e === 10090 || e === 10091 || e === 10092 || e === 10093 || e === 10094 || e === 10095 || e === 10096 || e === 10097 || e === 10098 || e === 10099 || e === 10100 || e === 10101 || e >= 10132 && e <= 10175 || e >= 10176 && e <= 10180 || e === 10181 || e === 10182 || e >= 10183 && e <= 10213 || e === 10214 || e === 10215 || e === 10216 || e === 10217 || e === 10218 || e === 10219 || e === 10220 || e === 10221 || e === 10222 || e === 10223 || e >= 10224 && e <= 10239 || e >= 10240 && e <= 10495 || e >= 10496 && e <= 10626 || e === 10627 || e === 10628 || e === 10629 || e === 10630 || e === 10631 || e === 10632 || e === 10633 || e === 10634 || e === 10635 || e === 10636 || e === 10637 || e === 10638 || e === 10639 || e === 10640 || e === 10641 || e === 10642 || e === 10643 || e === 10644 || e === 10645 || e === 10646 || e === 10647 || e === 10648 || e >= 10649 && e <= 10711 || e === 10712 || e === 10713 || e === 10714 || e === 10715 || e >= 10716 && e <= 10747 || e === 10748 || e === 10749 || e >= 10750 && e <= 11007 || e >= 11008 && e <= 11055 || e >= 11056 && e <= 11076 || e >= 11077 && e <= 11078 || e >= 11079 && e <= 11084 || e >= 11085 && e <= 11123 || e >= 11124 && e <= 11125 || e >= 11126 && e <= 11157 || e === 11158 || e >= 11159 && e <= 11263 || e >= 11776 && e <= 11777 || e === 11778 || e === 11779 || e === 11780 || e === 11781 || e >= 11782 && e <= 11784 || e === 11785 || e === 11786 || e === 11787 || e === 11788 || e === 11789 || e >= 11790 && e <= 11798 || e === 11799 || e >= 11800 && e <= 11801 || e === 11802 || e === 11803 || e === 11804 || e === 11805 || e >= 11806 && e <= 11807 || e === 11808 || e === 11809 || e === 11810 || e === 11811 || e === 11812 || e === 11813 || e === 11814 || e === 11815 || e === 11816 || e === 11817 || e >= 11818 && e <= 11822 || e === 11823 || e >= 11824 && e <= 11833 || e >= 11834 && e <= 11835 || e >= 11836 && e <= 11839 || e === 11840 || e === 11841 || e === 11842 || e >= 11843 && e <= 11855 || e >= 11856 && e <= 11857 || e === 11858 || e >= 11859 && e <= 11903 || e >= 12289 && e <= 12291 || e === 12296 || e === 12297 || e === 12298 || e === 12299 || e === 12300 || e === 12301 || e === 12302 || e === 12303 || e === 12304 || e === 12305 || e >= 12306 && e <= 12307 || e === 12308 || e === 12309 || e === 12310 || e === 12311 || e === 12312 || e === 12313 || e === 12314 || e === 12315 || e === 12316 || e === 12317 || e >= 12318 && e <= 12319 || e === 12320 || e === 12336 || e === 64830 || e === 64831 || e >= 65093 && e <= 65094;
}
function _r(e) {
  e.forEach(function(t) {
    if (delete t.location, Wa(t) || qa(t))
      for (var n in t.options)
        delete t.options[n].location, _r(t.options[n].value);
    else za(t) && Ya(t.style) || (Va(t) || Xa(t)) && vr(t.style) ? delete t.style.location : Za(t) && _r(t.children);
  });
}
function Ts(e, t) {
  t === void 0 && (t = {}), t = He({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, t);
  var n = new ws(e, t).parse();
  if (n.err) {
    var r = SyntaxError(xe[n.err.kind]);
    throw r.location = n.err.location, r.originalMessage = n.err.message, r;
  }
  return t?.captureLocation || _r(n.val), n.val;
}
var on;
(function(e) {
  e.MISSING_VALUE = "MISSING_VALUE", e.INVALID_VALUE = "INVALID_VALUE", e.MISSING_INTL_API = "MISSING_INTL_API";
})(on || (on = {}));
var Gn = (
  /** @class */
  (function(e) {
    Fn(t, e);
    function t(n, r, a) {
      var i = e.call(this, n) || this;
      return i.code = r, i.originalMessage = a, i;
    }
    return t.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, t;
  })(Error)
), aa = (
  /** @class */
  (function(e) {
    Fn(t, e);
    function t(n, r, a, i) {
      return e.call(this, 'Invalid values for "'.concat(n, '": "').concat(r, '". Options are "').concat(Object.keys(a).join('", "'), '"'), on.INVALID_VALUE, i) || this;
    }
    return t;
  })(Gn)
), Ss = (
  /** @class */
  (function(e) {
    Fn(t, e);
    function t(n, r, a) {
      return e.call(this, 'Value for "'.concat(n, '" must be of type ').concat(r), on.INVALID_VALUE, a) || this;
    }
    return t;
  })(Gn)
), Os = (
  /** @class */
  (function(e) {
    Fn(t, e);
    function t(n, r) {
      return e.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(r, '"'), on.MISSING_VALUE, r) || this;
    }
    return t;
  })(Gn)
), st;
(function(e) {
  e[e.literal = 0] = "literal", e[e.object = 1] = "object";
})(st || (st = {}));
function As(e) {
  return e.length < 2 ? e : e.reduce(function(t, n) {
    var r = t[t.length - 1];
    return !r || r.type !== st.literal || n.type !== st.literal ? t.push(n) : r.value += n.value, t;
  }, []);
}
function Is(e) {
  return typeof e == "function";
}
function Hn(e, t, n, r, a, i, s) {
  if (e.length === 1 && Qr(e[0]))
    return [
      {
        type: st.literal,
        value: e[0].value
      }
    ];
  for (var l = [], u = 0, c = e; u < c.length; u++) {
    var h = c[u];
    if (Qr(h)) {
      l.push({
        type: st.literal,
        value: h.value
      });
      continue;
    }
    if (Qo(h)) {
      typeof i == "number" && l.push({
        type: st.literal,
        value: n.getNumberFormat(t).format(i)
      });
      continue;
    }
    var v = h.value;
    if (!(a && v in a))
      throw new Os(v, s);
    var f = a[v];
    if (Jo(h)) {
      (!f || typeof f == "string" || typeof f == "number") && (f = typeof f == "string" || typeof f == "number" ? String(f) : ""), l.push({
        type: typeof f == "string" ? st.literal : st.object,
        value: f
      });
      continue;
    }
    if (Va(h)) {
      var w = typeof h.style == "string" ? r.date[h.style] : vr(h.style) ? h.style.parsedOptions : void 0;
      l.push({
        type: st.literal,
        value: n.getDateTimeFormat(t, w).format(f)
      });
      continue;
    }
    if (Xa(h)) {
      var w = typeof h.style == "string" ? r.time[h.style] : vr(h.style) ? h.style.parsedOptions : r.time.medium;
      l.push({
        type: st.literal,
        value: n.getDateTimeFormat(t, w).format(f)
      });
      continue;
    }
    if (za(h)) {
      var w = typeof h.style == "string" ? r.number[h.style] : Ya(h.style) ? h.style.parsedOptions : void 0;
      w && w.scale && (f = f * (w.scale || 1)), l.push({
        type: st.literal,
        value: n.getNumberFormat(t, w).format(f)
      });
      continue;
    }
    if (Za(h)) {
      var b = h.children, E = h.value, p = a[E];
      if (!Is(p))
        throw new Ss(E, "function", s);
      var g = Hn(b, t, n, r, a, i), y = p(g.map(function(I) {
        return I.value;
      }));
      Array.isArray(y) || (y = [y]), l.push.apply(l, y.map(function(I) {
        return {
          type: typeof I == "string" ? st.literal : st.object,
          value: I
        };
      }));
    }
    if (Wa(h)) {
      var m = h.options[f] || h.options.other;
      if (!m)
        throw new aa(h.value, f, Object.keys(h.options), s);
      l.push.apply(l, Hn(m.value, t, n, r, a));
      continue;
    }
    if (qa(h)) {
      var m = h.options["=".concat(f)];
      if (!m) {
        if (!Intl.PluralRules)
          throw new Gn(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, on.MISSING_INTL_API, s);
        var O = n.getPluralRules(t, { type: h.pluralType }).select(f - (h.offset || 0));
        m = h.options[O] || h.options.other;
      }
      if (!m)
        throw new aa(h.value, f, Object.keys(h.options), s);
      l.push.apply(l, Hn(m.value, t, n, r, a, f - (h.offset || 0)));
      continue;
    }
  }
  return As(l);
}
function Cs(e, t) {
  return t ? He(He(He({}, e || {}), t || {}), Object.keys(e).reduce(function(n, r) {
    return n[r] = He(He({}, e[r]), t[r] || {}), n;
  }, {})) : e;
}
function Hs(e, t) {
  return t ? Object.keys(e).reduce(function(n, r) {
    return n[r] = Cs(e[r], t[r]), n;
  }, He({}, e)) : e;
}
function ir(e) {
  return {
    create: function() {
      return {
        get: function(t) {
          return e[t];
        },
        set: function(t, n) {
          e[t] = n;
        }
      };
    }
  };
}
function Ls(e) {
  return e === void 0 && (e = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: nr(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.NumberFormat).bind.apply(t, tr([void 0], n, !1)))();
    }, {
      cache: ir(e.number),
      strategy: rr.variadic
    }),
    getDateTimeFormat: nr(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.DateTimeFormat).bind.apply(t, tr([void 0], n, !1)))();
    }, {
      cache: ir(e.dateTime),
      strategy: rr.variadic
    }),
    getPluralRules: nr(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.PluralRules).bind.apply(t, tr([void 0], n, !1)))();
    }, {
      cache: ir(e.pluralRules),
      strategy: rr.variadic
    })
  };
}
var Ps = (
  /** @class */
  (function() {
    function e(t, n, r, a) {
      n === void 0 && (n = e.defaultLocale);
      var i = this;
      if (this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(u) {
        var c = i.formatToParts(u);
        if (c.length === 1)
          return c[0].value;
        var h = c.reduce(function(v, f) {
          return !v.length || f.type !== st.literal || typeof v[v.length - 1] != "string" ? v.push(f.value) : v[v.length - 1] += f.value, v;
        }, []);
        return h.length <= 1 ? h[0] || "" : h;
      }, this.formatToParts = function(u) {
        return Hn(i.ast, i.locales, i.formatters, i.formats, u, void 0, i.message);
      }, this.resolvedOptions = function() {
        var u;
        return {
          locale: ((u = i.resolvedLocale) === null || u === void 0 ? void 0 : u.toString()) || Intl.NumberFormat.supportedLocalesOf(i.locales)[0]
        };
      }, this.getAst = function() {
        return i.ast;
      }, this.locales = n, this.resolvedLocale = e.resolveLocale(n), typeof t == "string") {
        if (this.message = t, !e.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        var s = a || {};
        s.formatters;
        var l = Go(s, ["formatters"]);
        this.ast = e.__parse(t, He(He({}, l), { locale: this.resolvedLocale }));
      } else
        this.ast = t;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = Hs(e.formats, r), this.formatters = a && a.formatters || Ls(this.formatterCache);
    }
    return Object.defineProperty(e, "defaultLocale", {
      get: function() {
        return e.memoizedDefaultLocale || (e.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), e.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), e.memoizedDefaultLocale = null, e.resolveLocale = function(t) {
      if (!(typeof Intl.Locale > "u")) {
        var n = Intl.NumberFormat.supportedLocalesOf(t);
        return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof t == "string" ? t : t[0]);
      }
    }, e.__parse = Ts, e.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, e;
  })()
);
function Ns(e, t) {
  if (t == null)
    return;
  if (t in e)
    return e[t];
  const n = t.split(".");
  let r = e;
  for (let a = 0; a < n.length; a++)
    if (typeof r == "object") {
      if (a > 0) {
        const i = n.slice(a, n.length).join(".");
        if (i in r) {
          r = r[i];
          break;
        }
      }
      r = r[n[a]];
    } else
      r = void 0;
  return r;
}
const zt = {}, Ms = (e, t, n) => n && (t in zt || (zt[t] = {}), e in zt[t] || (zt[t][e] = n), n), ri = (e, t) => {
  if (t == null)
    return;
  if (t in zt && e in zt[t])
    return zt[t][e];
  const n = zn(t);
  for (let r = 0; r < n.length; r++) {
    const a = n[r], i = Rs(a, e);
    if (i)
      return Ms(e, t, i);
  }
};
let Nr;
const En = xn({});
function Bs(e) {
  return Nr[e] || null;
}
function ai(e) {
  return e in Nr;
}
function Rs(e, t) {
  if (!ai(e))
    return null;
  const n = Bs(e);
  return Ns(n, t);
}
function Ds(e) {
  if (e == null)
    return;
  const t = zn(e);
  for (let n = 0; n < t.length; n++) {
    const r = t[n];
    if (ai(r))
      return r;
  }
}
function Us(e, ...t) {
  delete zt[e], En.update((n) => (n[e] = Fo.all([n[e] || {}, ...t]), n));
}
un(
  [En],
  ([e]) => Object.keys(e)
);
En.subscribe((e) => Nr = e);
const Ln = {};
function js(e, t) {
  Ln[e].delete(t), Ln[e].size === 0 && delete Ln[e];
}
function ii(e) {
  return Ln[e];
}
function Fs(e) {
  return zn(e).map((t) => {
    const n = ii(t);
    return [t, n ? [...n] : []];
  }).filter(([, t]) => t.length > 0);
}
function yr(e) {
  return e == null ? !1 : zn(e).some(
    (t) => {
      var n;
      return (n = ii(t)) == null ? void 0 : n.size;
    }
  );
}
function Gs(e, t) {
  return Promise.all(
    t.map((r) => (js(e, r), r().then((a) => a.default || a)))
  ).then((r) => Us(e, ...r));
}
const gn = {};
function oi(e) {
  if (!yr(e))
    return e in gn ? gn[e] : Promise.resolve();
  const t = Fs(e);
  return gn[e] = Promise.all(
    t.map(
      ([n, r]) => Gs(n, r)
    )
  ).then(() => {
    if (yr(e))
      return oi(e);
    delete gn[e];
  }), gn[e];
}
const zs = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, Vs = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: zs,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, Xs = Vs;
function sn() {
  return Xs;
}
const or = xn(!1);
var Ws = Object.defineProperty, qs = Object.defineProperties, Zs = Object.getOwnPropertyDescriptors, ia = Object.getOwnPropertySymbols, Ys = Object.prototype.hasOwnProperty, Js = Object.prototype.propertyIsEnumerable, oa = (e, t, n) => t in e ? Ws(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, Qs = (e, t) => {
  for (var n in t || (t = {}))
    Ys.call(t, n) && oa(e, n, t[n]);
  if (ia)
    for (var n of ia(t))
      Js.call(t, n) && oa(e, n, t[n]);
  return e;
}, Ks = (e, t) => qs(e, Zs(t));
let wr;
const Mn = xn(null);
function sa(e) {
  return e.split("-").map((t, n, r) => r.slice(0, n + 1).join("-")).reverse();
}
function zn(e, t = sn().fallbackLocale) {
  const n = sa(e);
  return t ? [.../* @__PURE__ */ new Set([...n, ...sa(t)])] : n;
}
function Qt() {
  return wr ?? void 0;
}
Mn.subscribe((e) => {
  wr = e ?? void 0, typeof window < "u" && e != null && document.documentElement.setAttribute("lang", e);
});
const $s = (e) => {
  if (e && Ds(e) && yr(e)) {
    const { loadingDelay: t } = sn();
    let n;
    return typeof window < "u" && Qt() != null && t ? n = window.setTimeout(
      () => or.set(!0),
      t
    ) : or.set(!0), oi(e).then(() => {
      Mn.set(e);
    }).finally(() => {
      clearTimeout(n), or.set(!1);
    });
  }
  return Mn.set(e);
}, dn = Ks(Qs({}, Mn), {
  set: $s
}), Vn = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (r) => {
    const a = JSON.stringify(r);
    return a in t ? t[a] : t[a] = e(r);
  };
};
var el = Object.defineProperty, Bn = Object.getOwnPropertySymbols, si = Object.prototype.hasOwnProperty, li = Object.prototype.propertyIsEnumerable, la = (e, t, n) => t in e ? el(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, Mr = (e, t) => {
  for (var n in t || (t = {}))
    si.call(t, n) && la(e, n, t[n]);
  if (Bn)
    for (var n of Bn(t))
      li.call(t, n) && la(e, n, t[n]);
  return e;
}, fn = (e, t) => {
  var n = {};
  for (var r in e)
    si.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && Bn)
    for (var r of Bn(e))
      t.indexOf(r) < 0 && li.call(e, r) && (n[r] = e[r]);
  return n;
};
const _n = (e, t) => {
  const { formats: n } = sn();
  if (e in n && t in n[e])
    return n[e][t];
  throw new Error(`[svelte-i18n] Unknown "${t}" ${e} format.`);
}, tl = Vn(
  (e) => {
    var t = e, { locale: n, format: r } = t, a = fn(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return r && (a = _n("number", r)), new Intl.NumberFormat(n, a);
  }
), nl = Vn(
  (e) => {
    var t = e, { locale: n, format: r } = t, a = fn(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return r ? a = _n("date", r) : Object.keys(a).length === 0 && (a = _n("date", "short")), new Intl.DateTimeFormat(n, a);
  }
), rl = Vn(
  (e) => {
    var t = e, { locale: n, format: r } = t, a = fn(t, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return r ? a = _n("time", r) : Object.keys(a).length === 0 && (a = _n("time", "short")), new Intl.DateTimeFormat(n, a);
  }
), al = (e = {}) => {
  var t = e, {
    locale: n = Qt()
  } = t, r = fn(t, [
    "locale"
  ]);
  return tl(Mr({ locale: n }, r));
}, il = (e = {}) => {
  var t = e, {
    locale: n = Qt()
  } = t, r = fn(t, [
    "locale"
  ]);
  return nl(Mr({ locale: n }, r));
}, ol = (e = {}) => {
  var t = e, {
    locale: n = Qt()
  } = t, r = fn(t, [
    "locale"
  ]);
  return rl(Mr({ locale: n }, r));
}, sl = Vn(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (e, t = Qt()) => new Ps(e, t, sn().formats, {
    ignoreTag: sn().ignoreTag
  })
), ll = (e, t = {}) => {
  var n, r, a, i;
  let s = t;
  typeof e == "object" && (s = e, e = s.id);
  const {
    values: l,
    locale: u = Qt(),
    default: c
  } = s;
  if (u == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let h = ri(e, u);
  if (!h)
    h = (i = (a = (r = (n = sn()).handleMissingMessage) == null ? void 0 : r.call(n, { locale: u, id: e, defaultValue: c })) != null ? a : c) != null ? i : e;
  else if (typeof h != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${e}" must be of type "string", found: "${typeof h}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), h;
  if (!l)
    return h;
  let v = h;
  try {
    v = sl(h, u).format(l);
  } catch (f) {
    f instanceof Error && console.warn(
      `[svelte-i18n] Message "${e}" has syntax error:`,
      f.message
    );
  }
  return v;
}, ul = (e, t) => ol(t).format(e), cl = (e, t) => il(t).format(e), dl = (e, t) => al(t).format(e), fl = (e, t = Qt()) => ri(e, t);
un([dn, En], () => ll);
un([dn], () => ul);
un([dn], () => cl);
un([dn], () => dl);
un([dn, En], () => fl);
const hl = "__i18n__", vl = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
];
class Pn extends Error {
  constructor(t) {
    super(t), this.name = "ShareError";
  }
}
async function pl(e, t) {
  if (window.__gradio_space__ == null)
    throw new Pn("Must be on Spaces to share.");
  let n, r, a;
  {
    let u;
    if (typeof e == "object" && e.url)
      u = e.url;
    else if (typeof e == "string")
      u = e;
    else
      throw new Error("Invalid data format for URL type");
    const c = await fetch(u);
    n = await c.blob(), r = c.headers.get("content-type") || "", a = c.headers.get("content-disposition") || "";
  }
  const i = new File([n], a, { type: r }), s = await fetch("https://huggingface.co/uploads", {
    method: "POST",
    body: i,
    headers: {
      "Content-Type": i.type,
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  if (!s.ok) {
    if (s.headers.get("content-type")?.includes("application/json")) {
      const u = await s.json();
      throw new Pn(`Upload failed: ${u.error}`);
    }
    throw new Pn("Upload failed.");
  }
  return await s.text();
}
const gl = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function ml(e) {
  return typeof e == "string" && e.includes(hl);
}
class bl {
  load_component;
  #e = he(At({}));
  get shared() {
    return o(this.#e);
  }
  set shared(t) {
    C(this.#e, t, !0);
  }
  #n = he(At({}));
  get props() {
    return o(this.#n);
  }
  set props(t) {
    C(this.#n, t, !0);
  }
  #t = he((t) => t);
  get i18n() {
    return o(this.#t);
  }
  set i18n(t) {
    C(this.#t, t, !0);
  }
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = gl;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, n) {
    for (const r in t.shared_props)
      this.shared[r] = t.shared_props[r];
    for (const r in t.props)
      this.props[r] = t.props[r];
    if (n)
      for (const r in n)
        this.props[r] === void 0 && (this.props[r] = n[r]);
    this.i18n = this.props.i18n ?? ((r) => r);
    for (const r of vl)
      this.shared[r] = this._translate_and_store(
        "shared",
        r,
        // @ts-ignore
        t.shared_props[r]
      ), this.props[r] = this._translate_and_store(
        "props",
        r,
        // @ts-ignore
        t.props[r]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), Ot(() => {
      for (const r in t.shared_props)
        this._is_i18n_managed(`shared.${r}`, t.shared_props[r]) || (this.shared[r] = t.shared_props[r]);
      for (const r in t.props)
        this._is_i18n_managed(`props.${r}`, t.props[r]) || (this.props[r] = t.props[r]);
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), Re(() => {
        this.shared.id = t.shared_props.id;
      });
    }), Object.keys(this.translatable_props).length > 0 && dn.subscribe(() => {
      for (const [r, a] of Object.entries(this.translatable_props)) {
        const [i, s] = r.split("."), l = this.i18n(a);
        i === "shared" ? this.shared[s] = l : this.props[s] = l;
      }
    });
  }
  // check if props are translatable
  _is_i18n_managed(t, n) {
    const r = this.translatable_props[t];
    return r ? n === r ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, n, r) {
    if (typeof r != "string") return r;
    const a = this.i18n(r);
    return a !== r && (this.translatable_props[`${t}.${n}`] = r), a;
  }
  dispatch(t, n) {
    this.dispatcher(this.shared.id, t, n);
  }
  async get_data() {
    return uo(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const n in t) {
      const r = t[n], a = ml(r) ? this._translate_and_store(this.shared_props.includes(n) ? "shared" : "props", n, r) : r;
      if (this.shared_props.includes(n)) {
        const i = n;
        this.shared[i] = a;
        continue;
      }
      this.props[n] = a;
    }
  }
  watch_for_change() {
    Ot(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
const Xe = {
  image: "#4fd1a5",
  text: "#8b83e8",
  audio: "#f5a623",
  video: "#4d9cf5",
  number: "#e879a8",
  boolean: "#f59e0b",
  file: "#94a3b8",
  json: "#22d3ee",
  gallery: "#34d399",
  model3d: "#a78bfa",
  any: "#6b6e78"
}, _l = {
  image: "rgba(79, 209, 165, 0.15)",
  text: "rgba(139, 131, 232, 0.15)",
  audio: "rgba(245, 166, 35, 0.15)",
  video: "rgba(77, 156, 245, 0.15)",
  number: "rgba(232, 121, 168, 0.15)",
  boolean: "rgba(245, 158, 11, 0.15)",
  file: "rgba(148, 163, 184, 0.15)",
  json: "rgba(34, 211, 238, 0.15)",
  gallery: "rgba(52, 211, 153, 0.15)",
  model3d: "rgba(167, 139, 250, 0.15)",
  any: "rgba(107, 110, 120, 0.10)"
}, yl = {
  input: "IN",
  transform: "FN",
  output: "OUT"
};
function ui() {
  return crypto.randomUUID();
}
const ua = {
  version: "1",
  name: "My workflow",
  nodes: [
    {
      id: "node_default",
      kind: "input",
      label: "Image",
      source: "local",
      inputs: [],
      outputs: [{ id: "out", label: "Image", type: "image" }],
      x: 80,
      y: 120,
      width: 200,
      height: 160,
      data: {}
    }
  ],
  edges: []
};
function wl() {
  if (typeof localStorage > "u") return ua;
  try {
    const e = localStorage.getItem("gradio_workflow");
    if (e) {
      const t = JSON.parse(e);
      return t.nodes = t.nodes.map((n) => (n.kind === "output" && (!n.outputs || n.outputs.length === 0) && n.inputs?.[0] && (n.outputs = [{ id: "out", label: n.inputs[0].label, type: n.inputs[0].type }]), { ...n, data: n.data ?? {} })), t;
    }
  } catch {
  }
  return ua;
}
const tt = xn(wl());
tt.subscribe((e) => {
  if (typeof localStorage < "u") {
    const t = {
      ...e,
      nodes: e.nodes.map((n) => ({
        ...n,
        data: Object.fromEntries(
          Object.entries(n.data ?? {}).map(([r, a]) => [
            r,
            typeof a == "string" || typeof a == "number" || typeof a == "boolean" ? a : null
          ])
        )
      }))
    };
    localStorage.setItem("gradio_workflow", JSON.stringify(t, null, 2));
  }
});
function An(e, t, n) {
  const r = ui();
  return tt.update((a) => ({
    ...a,
    nodes: [...a.nodes, { ...e, id: r, x: t, y: n, data: {} }]
  })), r;
}
function xl(e, t, n) {
  tt.update((r) => ({
    ...r,
    nodes: r.nodes.map((a) => a.id === e ? { ...a, x: t, y: n } : a)
  }));
}
function sr(e) {
  tt.update((t) => ({
    ...t,
    edges: [...t.edges, { ...e, id: ui() }]
  }));
}
function El(e) {
  tt.update((t) => ({
    ...t,
    edges: t.edges.filter((n) => n.id !== e)
  }));
}
function ca(e) {
  tt.update((t) => {
    const n = t.nodes.find((r) => r.id === e);
    return n && Object.values(n.data ?? {}).forEach((r) => {
      r && typeof r == "object" && r.url?.startsWith("blob:") && URL.revokeObjectURL(r.url);
    }), {
      ...t,
      nodes: t.nodes.filter((r) => r.id !== e),
      edges: t.edges.filter(
        (r) => r.from_node_id !== e && r.to_node_id !== e
      )
    };
  });
}
function da(e, t, n) {
  tt.update((r) => ({
    ...r,
    nodes: r.nodes.map(
      (a) => a.id === e ? { ...a, data: { ...a.data, [t]: n } } : a
    )
  }));
}
function kl(e, t, n) {
  tt.update((r) => ({
    ...r,
    nodes: r.nodes.map(
      (a) => a.id === e ? { ...a, width: t, height: n } : a
    )
  }));
}
ro();
const Tl = /`([^`]+)`/g, Sl = /\[([^\]]+)\]\(([^)]+)\)/g, Ol = /\*\*(.+?)\*\*/g, Al = /__(.+?)__/g, Il = /\*(.+?)\*/g, Cl = new RegExp("(?<!\\w)_(.+?)_(?!\\w)", "g"), Hl = /^\w+:/;
function Ll(e) {
  return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function Pl(e, t, n) {
  const r = n.trim();
  return Hl.test(r) ? /^https?:/i.test(r) ? `<a href="${r}" target="_blank" rel="noopener noreferrer">${t}</a>` : t : `<a href="${r}" target="_blank" rel="noopener noreferrer">${t}</a>`;
}
function fa(e) {
  let t = Ll(e);
  return t = t.replace(Tl, "<code>$1</code>"), t = t.replace(Sl, Pl), t = t.replace(Ol, "<strong>$1</strong>"), t = t.replace(Al, "<strong>$1</strong>"), t = t.replace(Il, "<em>$1</em>"), t = t.replace(Cl, "<em>$1</em>"), t = t.replace(/\n/g, "<br>"), t;
}
var Nl = /* @__PURE__ */ N('<div class="info-text svelte-tw5vg1"></div>');
function Ml(e, t) {
  nt(t, !1);
  let n = P(t, "info", 8);
  cn();
  var r = Nl();
  yo(
    r,
    () => (Ge(fa), Ge(n()), Re(() => fa(n()))),
    !0
  ), T(e, r), rt();
}
var Bl = /* @__PURE__ */ N('<span data-testid="block-info"><!></span> <!>', 1);
function Rl(e, t) {
  let n = P(t, "show_label", 8, !0), r = P(t, "info", 8, void 0), a = P(t, "rtl", 8, !1);
  var i = Bl(), s = Pe(i);
  let l;
  var u = A(s);
  Lr(u, t, "default", {});
  var c = L(s, 2);
  {
    var h = (v) => {
      Ml(v, {
        get info() {
          return r();
        }
      });
    };
    W(c, (v) => {
      r() && v(h);
    });
  }
  z(() => {
    H(s, "dir", a() ? "rtl" : "ltr"), l = Be(s, 1, "svelte-4pies8", null, l, {
      hide: !n(),
      "has-info": r() != null,
      "sr-only": !n()
    }), s.dir = s.dir;
  }), T(e, i);
}
var Dl = /* @__PURE__ */ N('<span class="svelte-j6hngg"> </span>'), Ul = /* @__PURE__ */ N("<button><!> <div><!> <!></div></button>");
function jl(e, t) {
  let n = P(t, "label", 3, ""), r = P(t, "show_label", 3, !1), a = P(t, "pending", 3, !1), i = P(t, "size", 3, "small"), s = P(t, "padded", 3, !0), l = P(t, "highlight", 3, !1), u = P(t, "disabled", 3, !1), c = P(t, "hasPopup", 3, !1), h = P(t, "color", 3, "var(--block-label-text-color)"), v = P(t, "transparent", 3, !1), f = P(t, "background", 3, "var(--block-background-fill)"), w = P(t, "border", 3, "transparent"), b = ve(() => l() ? "var(--color-accent)" : h());
  var E = Ul();
  let p, g;
  var y = A(E);
  {
    var m = (F) => {
      var q = Dl(), me = A(q);
      z(() => re(me, n())), T(F, q);
    };
    W(y, (F) => {
      r() && F(m);
    });
  }
  var O = L(y, 2);
  let I;
  var B = A(O);
  Ma(B, () => t.Icon, (F, q) => {
    q(F, {});
  });
  var Z = L(B, 2);
  {
    var R = (F) => {
      var q = $e(), me = Pe(q);
      Un(me, () => t.children), T(F, q);
    };
    W(Z, (F) => {
      t.children && F(R);
    });
  }
  z(() => {
    p = Be(E, 1, "icon-button svelte-j6hngg", null, p, {
      pending: a(),
      padded: s(),
      highlight: l(),
      transparent: v()
    }), E.disabled = u(), H(E, "aria-label", n()), H(E, "aria-haspopup", c()), H(E, "title", n()), g = Ye(E, "", g, {
      "--border-color": w(),
      color: !u() && o(b) ? o(b) : "var(--block-label-text-color)",
      "--bg-color": u() ? "auto" : f()
    }), I = Be(O, 1, "svelte-j6hngg", null, I, {
      "x-small": i() === "x-small",
      small: i() === "small",
      large: i() === "large",
      medium: i() === "medium"
    });
  }), X("click", E, function(...F) {
    t.onclick?.apply(this, F);
  }), T(e, E);
}
lt(["click"]);
var Fl = /* @__PURE__ */ bt('<svg width="100%" height="100%" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M5 13L9 17L19 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
function Gl(e) {
  var t = Fl();
  T(e, t);
}
var zl = /* @__PURE__ */ bt('<svg id="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="100%" height="100%"><path d="M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z" fill="currentColor"></path></svg>');
function Vl(e) {
  var t = zl();
  T(e, t);
}
var Xl = /* @__PURE__ */ bt('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33 33" color="currentColor" aria-hidden="true" width="100%" height="100%"><path fill="currentColor" d="M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"></path><path fill="currentColor" d="M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"></path></svg>');
function Wl(e) {
  var t = Xl();
  T(e, t);
}
var ql = /* @__PURE__ */ bt('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 32 32"><path fill="currentColor" d="M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"></path></svg>');
function Zl(e) {
  var t = ql();
  T(e, t);
}
var Yl = /* @__PURE__ */ bt('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>');
function ha(e) {
  var t = Yl();
  T(e, t);
}
var Jl = /* @__PURE__ */ bt('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-maximize" width="100%" height="100%"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg>');
function Ql(e) {
  var t = Jl();
  T(e, t);
}
var Kl = /* @__PURE__ */ bt('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize" width="100%" height="100%"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"></path></svg>');
function $l(e) {
  var t = Kl();
  T(e, t);
}
var eu = /* @__PURE__ */ bt('<svg viewBox="0 0 22 24" width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M19.1168 12.1484C19.474 12.3581 19.9336 12.2384 20.1432 11.8811C20.3528 11.5238 20.2331 11.0643 19.8758 10.8547L19.1168 12.1484ZM6.94331 4.13656L6.55624 4.77902L6.56378 4.78344L6.94331 4.13656ZM5.92408 4.1598L5.50816 3.5357L5.50816 3.5357L5.92408 4.1598ZM5.51031 5.09156L4.76841 5.20151C4.77575 5.25101 4.78802 5.29965 4.80505 5.34671L5.51031 5.09156ZM7.12405 11.7567C7.26496 12.1462 7.69495 12.3477 8.08446 12.2068C8.47397 12.0659 8.67549 11.6359 8.53458 11.2464L7.12405 11.7567ZM19.8758 12.1484C20.2331 11.9388 20.3528 11.4793 20.1432 11.122C19.9336 10.7648 19.474 10.6451 19.1168 10.8547L19.8758 12.1484ZM6.94331 18.8666L6.56375 18.2196L6.55627 18.2241L6.94331 18.8666ZM5.92408 18.8433L5.50815 19.4674H5.50815L5.92408 18.8433ZM5.51031 17.9116L4.80505 17.6564C4.78802 17.7035 4.77575 17.7521 4.76841 17.8016L5.51031 17.9116ZM8.53458 11.7567C8.67549 11.3672 8.47397 10.9372 8.08446 10.7963C7.69495 10.6554 7.26496 10.8569 7.12405 11.2464L8.53458 11.7567ZM19.4963 12.2516C19.9105 12.2516 20.2463 11.9158 20.2463 11.5016C20.2463 11.0873 19.9105 10.7516 19.4963 10.7516V12.2516ZM7.82931 10.7516C7.4151 10.7516 7.07931 11.0873 7.07931 11.5016C7.07931 11.9158 7.4151 12.2516 7.82931 12.2516V10.7516ZM19.8758 10.8547L7.32284 3.48968L6.56378 4.78344L19.1168 12.1484L19.8758 10.8547ZM7.33035 3.49414C6.76609 3.15419 6.05633 3.17038 5.50816 3.5357L6.34 4.78391C6.40506 4.74055 6.4893 4.73863 6.55627 4.77898L7.33035 3.49414ZM5.50816 3.5357C4.95998 3.90102 4.67184 4.54987 4.76841 5.20151L6.25221 4.98161C6.24075 4.90427 6.27494 4.82727 6.34 4.78391L5.50816 3.5357ZM4.80505 5.34671L7.12405 11.7567L8.53458 11.2464L6.21558 4.83641L4.80505 5.34671ZM19.1168 10.8547L6.56378 18.2197L7.32284 19.5134L19.8758 12.1484L19.1168 10.8547ZM6.55627 18.2241C6.4893 18.2645 6.40506 18.2626 6.34 18.2192L5.50815 19.4674C6.05633 19.8327 6.76609 19.8489 7.33035 19.509L6.55627 18.2241ZM6.34 18.2192C6.27494 18.1759 6.24075 18.0988 6.25221 18.0215L4.76841 17.8016C4.67184 18.4532 4.95998 19.1021 5.50815 19.4674L6.34 18.2192ZM6.21558 18.1667L8.53458 11.7567L7.12405 11.2464L4.80505 17.6564L6.21558 18.1667ZM19.4963 10.7516H7.82931V12.2516H19.4963V10.7516Z" fill="currentColor"></path></g></svg>');
function tu(e) {
  var t = eu();
  T(e, t);
}
var nu = /* @__PURE__ */ bt('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" class="feather feather-square"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>');
function ru(e, t) {
  let n = P(t, "fill", 8, "currentColor"), r = P(t, "stroke_width", 8, 1.5);
  var a = nu();
  z(() => {
    H(a, "fill", n()), H(a, "stroke-width", `${r()}`);
  }), T(e, a);
}
lt(["click"]);
var au = /* @__PURE__ */ N('<span class="custom-button-label svelte-tlifhu"> </span>'), iu = /* @__PURE__ */ N('<button class="custom-button svelte-tlifhu"><!></button>');
function ou(e, t) {
  nt(t, !1);
  let n = P(t, "button", 8), r = P(t, "on_click", 8);
  cn();
  var a = iu(), i = A(a);
  {
    var s = (l) => {
      var u = au(), c = A(u);
      z(() => re(c, (Ge(n()), Re(() => n().value)))), T(l, u);
    };
    W(i, (l) => {
      Ge(n()), Re(() => n().value) && l(s);
    });
  }
  z(() => {
    H(a, "title", (Ge(n()), Re(() => n().value || ""))), H(a, "aria-label", (Ge(n()), Re(() => n().value || "Custom action")));
  }), Te("click", a, () => r()(n().id)), T(e, a), rt();
}
var su = /* @__PURE__ */ N("<div><!> <!></div>");
function lu(e, t) {
  nt(t, !0);
  let n = P(t, "top_panel", 3, !0), r = P(t, "display_top_corner", 3, !1), a = P(t, "show_background", 3, !0), i = P(t, "buttons", 3, null), s = P(t, "on_custom_button_click", 3, null);
  var l = su(), u = A(l);
  {
    var c = (f) => {
      var w = $e(), b = Pe(w);
      Un(b, () => t.children), T(f, w);
    };
    W(u, (f) => {
      t.children && f(c);
    });
  }
  var h = L(u, 2);
  {
    var v = (f) => {
      var w = $e(), b = Pe(w);
      it(b, 17, i, kt, (E, p) => {
        var g = $e(), y = Pe(g);
        {
          var m = (O) => {
            ou(O, {
              get button() {
                return o(p);
              },
              on_click: (I) => {
                s() && s()(I);
              }
            });
          };
          W(y, (O) => {
            typeof o(p) != "string" && O(m);
          });
        }
        T(E, g);
      }), T(f, w);
    };
    W(h, (f) => {
      i() && f(v);
    });
  }
  z(() => Be(l, 1, `icon-button-wrapper ${n() ? "top-panel" : ""} ${r() ? "display-top-corner" : "hide-top-corner"} ${a() ? "" : "no-background"}`, "svelte-6rn70x")), T(e, l), rt();
}
var uu = /* @__PURE__ */ N('<div class="validation-error svelte-1pdydt5"> </div>'), cu = /* @__PURE__ */ N(" <!>", 1), du = /* @__PURE__ */ N('<input data-testid="textbox" type="text"/>'), fu = /* @__PURE__ */ N('<input data-testid="password" type="password" autocomplete=""/>'), hu = /* @__PURE__ */ N('<input data-testid="textbox" type="email" autocomplete="email"/>'), vu = /* @__PURE__ */ N('<textarea data-testid="textbox"></textarea>'), pu = /* @__PURE__ */ N('<button data-testid="submit-button"><!></button>'), gu = /* @__PURE__ */ N('<button data-testid="stop-button"><!></button>'), mu = /* @__PURE__ */ N('<label><!> <!> <div class="input-container svelte-1pdydt5"><!> <!> <!></div></label>');
function bu(e, t) {
  nt(t, !0);
  var n = this && this.__awaiter || function(K, G, _e, ce) {
    function je(S) {
      return S instanceof _e ? S : new _e(function(k) {
        k(S);
      });
    }
    return new (_e || (_e = Promise))(function(S, k) {
      function _(te) {
        try {
          ee(ce.next(te));
        } catch (Se) {
          k(Se);
        }
      }
      function V(te) {
        try {
          ee(ce.throw(te));
        } catch (Se) {
          k(Se);
        }
      }
      function ee(te) {
        te.done ? S(te.value) : je(te.value).then(_, V);
      }
      ee((ce = ce.apply(K, G || [])).next());
    });
  };
  let r = P(t, "value", 15, ""), a = P(t, "value_is_output", 15, !1), i = P(t, "lines", 3, 1), s = P(t, "placeholder", 3, ""), l = P(t, "info", 3, void 0), u = P(t, "disabled", 3, !1), c = P(t, "show_label", 3, !0), h = P(t, "container", 3, !0), v = P(t, "max_lines", 3, void 0), f = P(t, "type", 3, "text"), w = P(t, "buttons", 3, null), b = P(t, "oncustombuttonclick", 3, null), E = P(t, "submit_btn", 3, null), p = P(t, "stop_btn", 3, null), g = P(t, "rtl", 3, !1), y = P(t, "autofocus", 3, !1), m = P(t, "text_align", 3, void 0), O = P(t, "autoscroll", 3, !0), I = P(t, "max_length", 3, void 0), B = P(t, "html_attributes", 3, null), Z = P(t, "validation_error", 3, void 0), R, F = he(!1), q, me = he(!1), Ue = he(0), be = he(!1), Ne = he(1);
  const ut = !E();
  Ot(() => {
    v() === void 0 || v() === null ? f() === "text" ? C(Ne, Math.max(i(), 20), !0) : C(Ne, 1) : C(Ne, Math.max(v(), i()), !0);
  }), Ot(() => {
    r(), Z(), R && i() !== o(Ne) && o(Ne) > 1 && ne({ target: R });
  }), Ot(() => {
    r() === null && r("");
  }), Ia(() => {
    !o(be) && R && R.offsetHeight + R.scrollTop > R.scrollHeight - 100 && C(me, !0);
  });
  const _t = () => {
    o(me) && O() && !o(be) && R.scrollTo(0, R.scrollHeight);
  };
  function yt() {
    return n(this, void 0, void 0, function* () {
      yield en(), t.onchange === null || t.onchange === void 0 || t.onchange(r());
    });
  }
  Ot(() => {
    y() && R && R.focus(), o(me) && O() && _t(), a(!1);
  }), Ot(() => {
    r(), yt();
  });
  function Tt() {
    return n(this, void 0, void 0, function* () {
      if ("clipboard" in navigator) {
        try {
          yield navigator.clipboard.writeText(r()), t.oncopy === null || t.oncopy === void 0 || t.oncopy({ value: r() });
        } catch (K) {
          console.error("COPYING CLIPBOARD FAILED", K);
        }
        It();
      }
    });
  }
  function It() {
    C(F, !0), q && clearTimeout(q), q = setTimeout(
      () => {
        C(F, !1);
      },
      1e3
    );
  }
  function ft(K) {
    const G = K.target, _e = G.value, ce = [G.selectionStart, G.selectionEnd];
    t.onselect === null || t.onselect === void 0 || t.onselect({ value: _e.substring(...ce), index: ce });
  }
  function wt(K) {
    return n(this, void 0, void 0, function* () {
      K.key === "Enter" && K.shiftKey && i() > 1 ? (K.preventDefault(), yield en(), t.onsubmit === null || t.onsubmit === void 0 || t.onsubmit()) : K.key === "Enter" && !K.shiftKey && i() === 1 && o(Ne) >= 1 && (K.preventDefault(), yield en(), t.onsubmit === null || t.onsubmit === void 0 || t.onsubmit()), yield en(), t.oninput === null || t.oninput === void 0 || t.oninput(r());
    });
  }
  function Nt(K) {
    const G = K.target, _e = G.scrollTop;
    _e < o(Ue) && C(be, !0), C(Ue, _e, !0);
    const ce = G.scrollHeight - G.clientHeight;
    _e >= ce && C(be, !1);
  }
  function Y() {
    t.onstop === null || t.onstop === void 0 || t.onstop();
  }
  function J() {
    t.onsubmit === null || t.onsubmit === void 0 || t.onsubmit();
  }
  function ne(K) {
    return n(this, void 0, void 0, function* () {
      if (yield en(), i() === o(Ne)) return;
      const G = K.target, _e = window.getComputedStyle(G), ce = parseFloat(_e.paddingTop), je = parseFloat(_e.paddingBottom), S = parseFloat(_e.lineHeight);
      let k = o(Ne) === void 0 ? !1 : ce + je + S * o(Ne), _ = ce + je + i() * S;
      G.style.height = "1px";
      let V;
      k && G.scrollHeight > k ? V = k : G.scrollHeight < _ ? V = _ : V = G.scrollHeight, G.style.height = `${V}px`, Me(G);
    });
  }
  function Me(K) {
    const G = K.scrollHeight, _e = K.clientHeight, ce = parseFloat(window.getComputedStyle(K).lineHeight);
    G > _e + ce ? K.style.overflowY = "scroll" : K.style.overflowY = "hidden";
  }
  function se(K, G) {
    if (!(i() === o(Ne) || i() === 1 && o(Ne) === 1))
      return K.addEventListener("input", ne), G.trim() && (K.style.overflowY = "scroll", ne({ target: K })), { destroy: () => K.removeEventListener("input", ne) };
  }
  var ze = mu();
  let Ze;
  var ht = A(ze);
  {
    var Ct = (K) => {
      lu(K, {
        get buttons() {
          return w();
        },
        get on_custom_button_click() {
          return b();
        },
        children: (G, _e) => {
          var ce = $e(), je = Pe(ce);
          {
            var S = (_) => {
              {
                let V = ve(() => o(F) ? Gl : Wl), ee = ve(() => o(F) ? "Copied" : "Copy");
                jl(_, {
                  get Icon() {
                    return o(V);
                  },
                  onclick: Tt,
                  get label() {
                    return o(ee);
                  }
                });
              }
            }, k = ve(() => w().some((_) => typeof _ == "string" && _ === "copy"));
            W(je, (_) => {
              o(k) && _(S);
            });
          }
          T(G, ce);
        },
        $$slots: { default: !0 }
      });
    };
    W(ht, (K) => {
      c() && w() && w().length > 0 && K(Ct);
    });
  }
  var vt = L(ht, 2);
  {
    let K = ve(() => Z() ? !0 : c());
    Rl(vt, {
      get show_label() {
        return o(K);
      },
      get info() {
        return l();
      },
      children: (G, _e) => {
        var ce = cu(), je = Pe(ce), S = L(je);
        {
          var k = (_) => {
            var V = uu(), ee = A(V);
            z(() => re(ee, Z())), T(_, V);
          };
          W(S, (_) => {
            Z() && _(k);
          });
        }
        z(() => re(je, `${t.label ?? ""} `)), T(G, ce);
      },
      $$slots: { default: !0 }
    });
  }
  var at = L(vt, 2), xt = A(at);
  {
    var Ut = (K) => {
      var G = $e(), _e = Pe(G);
      {
        var ce = (k) => {
          var _ = du();
          let V;
          mn(_, y()), Pt(_, (ee) => R = ee, () => R), z(() => {
            V = Be(_, 1, "scroll-hide svelte-1pdydt5", null, V, { "validation-error": Z() }), H(_, "dir", g() ? "rtl" : "ltr"), H(_, "placeholder", s()), _.disabled = u(), H(_, "maxlength", I()), Ye(_, m() ? "text-align: " + m() : ""), H(_, "autocapitalize", B()?.autocapitalize), H(_, "autocorrect", B()?.autocorrect), H(_, "spellcheck", B()?.spellcheck), H(_, "autocomplete", B()?.autocomplete), H(_, "tabindex", B()?.tabindex), H(_, "enterkeyhint", B()?.enterkeyhint), H(_, "lang", B()?.lang), _.dir = _.dir;
          }), Te("keypress", _, wt), Te("blur", _, () => t.onblur?.()), Te("select", _, ft), Te("focus", _, () => t.onfocus?.()), Sn(_, r), T(k, _);
        }, je = (k) => {
          var _ = fu();
          let V;
          mn(_, y()), Pt(_, (ee) => R = ee, () => R), z(() => {
            V = Be(_, 1, "scroll-hide svelte-1pdydt5", null, V, { "validation-error": Z() }), H(_, "placeholder", s()), _.disabled = u(), H(_, "maxlength", I()), H(_, "autocapitalize", B()?.autocapitalize), H(_, "autocorrect", B()?.autocorrect), H(_, "spellcheck", B()?.spellcheck), H(_, "tabindex", B()?.tabindex), H(_, "enterkeyhint", B()?.enterkeyhint), H(_, "lang", B()?.lang);
          }), Te("keypress", _, wt), Te("blur", _, () => t.onblur?.()), Te("select", _, ft), Te("focus", _, () => t.onfocus?.()), Sn(_, r), T(k, _);
        }, S = (k) => {
          var _ = hu();
          let V;
          mn(_, y()), Pt(_, (ee) => R = ee, () => R), z(() => {
            V = Be(_, 1, "scroll-hide svelte-1pdydt5", null, V, { "validation-error": Z() }), H(_, "placeholder", s()), _.disabled = u(), H(_, "maxlength", I()), H(_, "autocapitalize", B()?.autocapitalize), H(_, "autocorrect", B()?.autocorrect), H(_, "spellcheck", B()?.spellcheck), H(_, "tabindex", B()?.tabindex), H(_, "enterkeyhint", B()?.enterkeyhint), H(_, "lang", B()?.lang);
          }), Te("keypress", _, wt), Te("blur", _, () => t.onblur?.()), Te("select", _, ft), Te("focus", _, () => t.onfocus?.()), Sn(_, r), T(k, _);
        };
        W(_e, (k) => {
          f() === "text" ? k(ce) : f() === "password" ? k(je, 1) : f() === "email" && k(S, 2);
        });
      }
      T(K, G);
    }, jt = (K) => {
      var G = vu();
      mn(G, y());
      let _e;
      wo(G, (ce, je) => se?.(ce, je), r), wn(() => Sn(G, r)), Pt(G, (ce) => R = ce, () => R), z(() => {
        H(G, "dir", g() ? "rtl" : "ltr"), H(G, "placeholder", s()), H(G, "rows", i()), G.disabled = u(), H(G, "maxlength", I()), Ye(G, m() ? "text-align: " + m() : ""), H(G, "autocapitalize", B()?.autocapitalize), H(G, "autocorrect", B()?.autocorrect), H(G, "spellcheck", B()?.spellcheck), H(G, "autocomplete", B()?.autocomplete), H(G, "tabindex", B()?.tabindex), H(G, "enterkeyhint", B()?.enterkeyhint), H(G, "lang", B()?.lang), _e = Be(G, 1, "svelte-1pdydt5", null, _e, {
          "no-label": !c() && (E() || p()),
          "validation-error": Z()
        }), G.dir = G.dir;
      }), Te("keypress", G, wt), Te("blur", G, () => t.onblur?.()), Te("select", G, ft), Te("focus", G, () => t.onfocus?.()), Te("scroll", G, Nt), T(K, G);
    };
    W(xt, (K) => {
      i() === 1 && o(Ne) === 1 ? K(Ut) : K(jt, -1);
    });
  }
  var Et = L(xt, 2);
  {
    var Mt = (K) => {
      var G = pu();
      let _e;
      var ce = A(G);
      {
        var je = (k) => {
          tu(k);
        }, S = (k) => {
          var _ = Nn();
          z(() => re(_, E())), T(k, _);
        };
        W(ce, (k) => {
          E() === !0 ? k(je) : k(S, -1);
        });
      }
      z(() => _e = Be(G, 1, "submit-button svelte-1pdydt5", null, _e, { "padded-button": E() !== !0 })), X("click", G, J), T(K, G);
    };
    W(Et, (K) => {
      E() && K(Mt);
    });
  }
  var Bt = L(Et, 2);
  {
    var Rt = (K) => {
      var G = gu();
      let _e;
      var ce = A(G);
      {
        var je = (k) => {
          ru(k, { fill: "none", stroke_width: 2.5 });
        }, S = (k) => {
          var _ = Nn();
          z(() => re(_, p())), T(k, _);
        };
        W(ce, (k) => {
          p() === !0 ? k(je) : k(S, -1);
        });
      }
      z(() => _e = Be(G, 1, "stop-button svelte-1pdydt5", null, _e, { "padded-button": p() !== !0 })), X("click", G, Y), T(K, G);
    };
    W(Bt, (K) => {
      p() && K(Rt);
    });
  }
  z(() => Ze = Be(ze, 1, "svelte-1pdydt5", null, Ze, { container: h(), show_textbox_border: ut })), T(e, ze), rt();
}
lt(["click"]);
const _u = (e) => {
  const t = {};
  for (let n = 0, r = e.length; n < r; n++) {
    const a = e[n];
    for (const i in a)
      t[i] ? t[i] = t[i].concat(a[i]) : t[i] = a[i];
  }
  return t;
}, yu = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], wu = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], xu = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
_u([
  Object.fromEntries(yu.map((e) => [e, ["*"]])),
  Object.fromEntries(wu.map((e) => [e, ["svg:*"]])),
  Object.fromEntries(xu.map((e) => [e, ["math:*"]]))
]);
lt(["touchstart", "touchmove", "touchend", "click", "keydown"]);
var Eu = /* @__PURE__ */ N('<label for="" data-testid="block-label"><span class="svelte-6p82yz"><!></span> </label>');
function ku(e, t) {
  let n = P(t, "label", 8, null), r = P(t, "Icon", 8), a = P(t, "show_label", 8, !0), i = P(t, "disable", 8, !1), s = P(t, "float", 8, !0), l = P(t, "rtl", 8, !1);
  var u = Eu();
  let c;
  var h = A(u), v = A(h);
  r()(v, {});
  var f = L(h);
  z(() => {
    H(u, "dir", l() ? "rtl" : "ltr"), c = Be(u, 1, "svelte-6p82yz", null, c, {
      hide: !a(),
      "sr-only": !a(),
      float: s(),
      "hide-label": i()
    }), re(f, ` ${n() ?? ""}`), u.dir = u.dir;
  }), T(e, u);
}
var Tu = /* @__PURE__ */ N("<a><!></a>");
function Su(e, t) {
  const n = Zr(t, ["children", "$$slots", "$$events", "$$legacy"]), r = Zr(n, ["href", "download"]);
  nt(t, !1);
  let a = P(t, "href", 8, void 0), i = P(t, "download", 8);
  const s = Pr();
  cn();
  var l = Tu(), u = ve(() => s.bind(null, "click"));
  Ua(
    l,
    () => ({
      class: "download-link",
      "data-testid": "download-link",
      href: a(),
      target: Re(() => typeof window < "u" && window.__is_colab__ ? "_blank" : null),
      rel: "noopener noreferrer",
      download: i(),
      ...r,
      [tn]: { position: "relative" }
    }),
    void 0,
    void 0,
    void 0,
    "svelte-8043yq"
  );
  var c = A(l);
  Lr(c, t, "default", {}), Te("click", l, function(...h) {
    o(u)?.apply(this, h);
  }), T(e, l), rt();
}
var Ou = /* @__PURE__ */ N('<span class="svelte-1448f1f"> </span>'), Au = /* @__PURE__ */ N("<button><!> <div><!> <!></div></button>");
function Rn(e, t) {
  let n = P(t, "label", 3, ""), r = P(t, "show_label", 3, !1), a = P(t, "pending", 3, !1), i = P(t, "size", 3, "small"), s = P(t, "padded", 3, !0), l = P(t, "highlight", 3, !1), u = P(t, "disabled", 3, !1), c = P(t, "hasPopup", 3, !1), h = P(t, "color", 3, "var(--block-label-text-color)"), v = P(t, "transparent", 3, !1), f = P(t, "background", 3, "var(--block-background-fill)"), w = P(t, "border", 3, "transparent"), b = ve(() => l() ? "var(--color-accent)" : h());
  var E = Au();
  let p, g;
  var y = A(E);
  {
    var m = (F) => {
      var q = Ou(), me = A(q);
      z(() => re(me, n())), T(F, q);
    };
    W(y, (F) => {
      r() && F(m);
    });
  }
  var O = L(y, 2);
  let I;
  var B = A(O);
  Ma(B, () => t.Icon, (F, q) => {
    q(F, {});
  });
  var Z = L(B, 2);
  {
    var R = (F) => {
      var q = $e(), me = Pe(q);
      Un(me, () => t.children), T(F, q);
    };
    W(Z, (F) => {
      t.children && F(R);
    });
  }
  z(() => {
    p = Be(E, 1, "icon-button svelte-1448f1f", null, p, {
      pending: a(),
      padded: s(),
      highlight: l(),
      transparent: v()
    }), E.disabled = u(), H(E, "aria-label", n()), H(E, "aria-haspopup", c()), H(E, "title", n()), g = Ye(E, "", g, {
      "--border-color": w(),
      color: !u() && o(b) ? o(b) : "var(--block-label-text-color)",
      "--bg-color": u() ? "auto" : f()
    }), I = Be(O, 1, "svelte-1448f1f", null, I, {
      "x-small": i() === "x-small",
      small: i() === "small",
      large: i() === "large",
      medium: i() === "medium"
    });
  }), X("click", E, function(...F) {
    t.onclick?.apply(this, F);
  }), T(e, E);
}
lt(["click"]);
var Iu = /* @__PURE__ */ N('<div aria-label="Empty value"><div class="icon svelte-4y56gt"><!></div></div>');
function Cu(e, t) {
  nt(t, !1);
  const n = rn();
  let r = P(t, "size", 8, "small"), a = P(t, "unpadded_box", 8, !1), i = rn();
  function s(v) {
    var f;
    if (!v) return !1;
    const { height: w } = v.getBoundingClientRect(), { height: b } = ((f = v.parentElement) === null || f === void 0 ? void 0 : f.getBoundingClientRect()) || { height: w };
    return w > b + 2;
  }
  ao(() => o(i), () => {
    C(n, s(o(i)));
  }), io();
  var l = Iu();
  let u;
  var c = A(l), h = A(c);
  Lr(h, t, "default", {}), Pt(l, (v) => C(i, v), () => o(i)), z(() => u = Be(l, 1, "empty svelte-4y56gt", null, u, {
    small: r() === "small",
    large: r() === "large",
    unpadded_box: a(),
    small_parent: o(n)
  })), T(e, l), rt();
}
function Hu(e, t) {
  nt(t, !1);
  const n = Pr();
  let r = P(t, "formatter", 8), a = P(t, "value", 8), i = P(t, "i18n", 8), s = rn(!1);
  cn();
  {
    let l = nn(() => (Ge(i()), Re(() => i()("common.share"))));
    Rn(e, {
      get Icon() {
        return Vl;
      },
      get label() {
        return o(l);
      },
      get pending() {
        return o(s);
      },
      onclick: async () => {
        try {
          C(s, !0);
          const u = await r()(a());
          n("share", { description: u });
        } catch (u) {
          console.error(u);
          let c = u instanceof Pn ? u.message : "Share failed.";
          n("error", c);
        } finally {
          C(s, !1);
        }
      }
    });
  }
  rt();
}
lt(["click"]);
var Lu = /* @__PURE__ */ N('<span class="custom-button-label svelte-yex8gp"> </span>'), Pu = /* @__PURE__ */ N('<button class="custom-button svelte-yex8gp"><!></button>');
function Nu(e, t) {
  nt(t, !1);
  let n = P(t, "button", 8), r = P(t, "on_click", 8);
  cn();
  var a = Pu(), i = A(a);
  {
    var s = (l) => {
      var u = Lu(), c = A(u);
      z(() => re(c, (Ge(n()), Re(() => n().value)))), T(l, u);
    };
    W(i, (l) => {
      Ge(n()), Re(() => n().value) && l(s);
    });
  }
  z(() => {
    H(a, "title", (Ge(n()), Re(() => n().value || ""))), H(a, "aria-label", (Ge(n()), Re(() => n().value || "Custom action")));
  }), Te("click", a, () => r()(n().id)), T(e, a), rt();
}
var Mu = /* @__PURE__ */ N("<div><!> <!></div>");
function Bu(e, t) {
  nt(t, !0);
  let n = P(t, "top_panel", 3, !0), r = P(t, "display_top_corner", 3, !1), a = P(t, "show_background", 3, !0), i = P(t, "buttons", 3, null), s = P(t, "on_custom_button_click", 3, null);
  var l = Mu(), u = A(l);
  {
    var c = (f) => {
      var w = $e(), b = Pe(w);
      Un(b, () => t.children), T(f, w);
    };
    W(u, (f) => {
      t.children && f(c);
    });
  }
  var h = L(u, 2);
  {
    var v = (f) => {
      var w = $e(), b = Pe(w);
      it(b, 17, i, kt, (E, p) => {
        var g = $e(), y = Pe(g);
        {
          var m = (O) => {
            Nu(O, {
              get button() {
                return o(p);
              },
              on_click: (I) => {
                s() && s()(I);
              }
            });
          };
          W(y, (O) => {
            typeof o(p) != "string" && O(m);
          });
        }
        T(E, g);
      }), T(f, w);
    };
    W(h, (f) => {
      i() && f(v);
    });
  }
  z(() => Be(l, 1, `icon-button-wrapper ${n() ? "top-panel" : ""} ${r() ? "display-top-corner" : "hide-top-corner"} ${a() ? "" : "no-background"}`, "svelte-dtheq2")), T(e, l), rt();
}
function Ru(e, t) {
  nt(t, !0);
  var n = $e(), r = Pe(n);
  {
    var a = (s) => {
      Rn(s, {
        get Icon() {
          return $l;
        },
        label: "Exit fullscreen mode",
        onclick: () => t.onclick(!1)
      });
    }, i = (s) => {
      Rn(s, {
        get Icon() {
          return Ql;
        },
        label: "Fullscreen",
        onclick: () => t.onclick(!0)
      });
    };
    W(r, (s) => {
      t.fullscreen ? s(a) : s(i, -1);
    });
  }
  T(e, n), rt();
}
const Du = (e) => {
  let t;
  if (e.currentTarget instanceof Element)
    t = e.currentTarget.querySelector("img");
  else
    return [NaN, NaN];
  const n = t.getBoundingClientRect(), r = t.naturalWidth / n.width, a = t.naturalHeight / n.height;
  if (r > a) {
    const l = t.naturalHeight / r, u = (n.height - l) / 2;
    var i = Math.round((e.clientX - n.left) * r), s = Math.round((e.clientY - n.top - u) * r);
  } else {
    const l = t.naturalWidth / a, u = (n.width - l) / 2;
    var i = Math.round((e.clientX - n.left - u) * a), s = Math.round((e.clientY - n.top) * a);
  }
  return i < 0 || i >= t.naturalWidth || s < 0 || s >= t.naturalHeight ? null : [i, s];
};
var Uu = /* @__PURE__ */ N("<img/>");
function ju(e, t) {
  nt(t, !0);
  var n = Uu();
  Ua(
    n,
    (r) => ({
      src: t.src,
      class: r,
      "data-testid": t.data_testid,
      ...t.restProps
    }),
    [() => (t.class_names || []).join(" ")],
    void 0,
    void 0,
    "svelte-5xcf1t"
  ), Te("load", n, function(r) {
    Cn.call(this, t, r);
  }), T(e, n), rt();
}
var Fu = /* @__PURE__ */ N("<!> <!> <!>", 1), Gu = /* @__PURE__ */ N('<div class="image-container svelte-1vq0uw1"><!> <button class="svelte-1vq0uw1"><div><!></div></button></div>'), zu = /* @__PURE__ */ N("<!> <!>", 1);
function Vu(e, t) {
  nt(t, !1);
  let n = P(t, "value", 8), r = P(t, "label", 8, void 0), a = P(t, "show_label", 8), i = P(t, "buttons", 24, () => []), s = P(t, "on_custom_button_click", 8, null), l = P(t, "selectable", 8, !1), u = P(t, "i18n", 8), c = P(t, "display_icon_button_wrapper_top_corner", 8, !1), h = P(t, "fullscreen", 12, !1), v = P(t, "show_button_background", 8, !0);
  const f = Pr(), w = (O) => {
    let I = Du(O);
    I && f("select", { index: I, value: null });
  };
  let b = rn();
  cn();
  var E = zu(), p = Pe(E);
  {
    let O = nn(() => (Ge(a()), Ge(r()), Ge(u()), Re(() => a() ? r() || u()("image.image") : "")));
    ku(p, {
      get show_label() {
        return a();
      },
      get Icon() {
        return ha;
      },
      get label() {
        return o(O);
      }
    });
  }
  var g = L(p, 2);
  {
    var y = (O) => {
      Cu(O, {
        unpadded_box: !0,
        size: "large",
        children: (I, B) => {
          ha(I);
        },
        $$slots: { default: !0 }
      });
    }, m = (O) => {
      var I = Gu(), B = A(I);
      Bu(B, {
        get display_top_corner() {
          return c();
        },
        get show_background() {
          return v();
        },
        get buttons() {
          return i();
        },
        get on_custom_button_click() {
          return s();
        },
        children: (me, Ue) => {
          var be = Fu(), Ne = Pe(be);
          {
            var ut = (Y) => {
              Ru(Y, {
                get fullscreen() {
                  return h();
                },
                onclick: (J) => {
                  h(J), f("fullscreen", J);
                }
              });
            }, _t = ve(() => (Ge(i()), Re(() => i().some((Y) => typeof Y == "string" && Y === "fullscreen"))));
            W(Ne, (Y) => {
              o(_t) && Y(ut);
            });
          }
          var yt = L(Ne, 2);
          {
            var Tt = (Y) => {
              {
                let J = nn(() => (Ge(n()), Re(() => n().orig_name || "image")));
                Su(Y, {
                  get href() {
                    return Ge(n()), Re(() => n().url);
                  },
                  get download() {
                    return o(J);
                  },
                  children: (ne, Me) => {
                    {
                      let se = nn(() => (Ge(u()), Re(() => u()("common.download"))));
                      Rn(ne, {
                        get Icon() {
                          return Zl;
                        },
                        get label() {
                          return o(se);
                        }
                      });
                    }
                  },
                  $$slots: { default: !0 }
                });
              }
            }, It = ve(() => (Ge(i()), Re(() => i().some((Y) => typeof Y == "string" && Y === "download"))));
            W(yt, (Y) => {
              o(It) && Y(Tt);
            });
          }
          var ft = L(yt, 2);
          {
            var wt = (Y) => {
              Hu(Y, {
                get i18n() {
                  return u();
                },
                formatter: async (J) => J ? `<img src="${await pl(J)}" />` : "",
                get value() {
                  return n();
                },
                $$events: {
                  share(J) {
                    Cn.call(this, t, J);
                  },
                  error(J) {
                    Cn.call(this, t, J);
                  }
                }
              });
            }, Nt = ve(() => (Ge(i()), Re(() => i().some((Y) => typeof Y == "string" && Y === "share"))));
            W(ft, (Y) => {
              o(Nt) && Y(wt);
            });
          }
          T(me, be);
        },
        $$slots: { default: !0 }
      });
      var Z = L(B, 2), R = A(Z);
      let F;
      var q = A(R);
      ju(q, {
        get src() {
          return Ge(n()), Re(() => n().url);
        },
        restProps: { loading: "lazy", alt: "" },
        $$events: {
          load(me) {
            Cn.call(this, t, me);
          }
        }
      }), Pt(I, (me) => C(b, me), () => o(b)), z(() => F = Be(R, 1, "image-frame svelte-1vq0uw1", null, F, { selectable: l() })), Te("click", Z, w), T(O, I);
    };
    W(g, (O) => {
      Ge(n()), Re(() => n() == null || !n()?.url) ? O(y) : O(m, -1);
    });
  }
  T(e, E), rt();
}
lt(["touchstart", "touchmove", "touchend", "click", "keydown"]);
typeof process < "u" && process.versions && process.versions.node;
class pd extends TransformStream {
  #e = "";
  /** Constructs a new instance. */
  constructor(t = { allowCR: !1 }) {
    super({
      transform: (n, r) => {
        for (n = this.#e + n; ; ) {
          const a = n.indexOf(`
`), i = t.allowCR ? n.indexOf("\r") : -1;
          if (i !== -1 && i !== n.length - 1 && (a === -1 || a - 1 > i)) {
            r.enqueue(n.slice(0, i)), n = n.slice(i + 1);
            continue;
          }
          if (a === -1)
            break;
          const s = n[a - 1] === "\r" ? a - 1 : a;
          r.enqueue(n.slice(0, s)), n = n.slice(a + 1);
        }
        this.#e = n;
      },
      flush: (n) => {
        if (this.#e === "")
          return;
        const r = t.allowCR && this.#e.endsWith("\r") ? this.#e.slice(0, -1) : this.#e;
        n.enqueue(r);
      }
    });
  }
}
lt(["click"]);
lt(["click"]);
lt(["click"]);
var Xu = /* @__PURE__ */ N('<span class="node-status-spinner svelte-enf4d0"></span>'), Wu = /* @__PURE__ */ N('<input class="node-label-input svelte-enf4d0"/>'), qu = /* @__PURE__ */ N('<span class="node-label svelte-enf4d0"> </span>'), Zu = /* @__PURE__ */ N('<a class="source-badge svelte-enf4d0" target="_blank" rel="noopener"> </a>'), Yu = /* @__PURE__ */ N('<button class="port-auto-btn svelte-enf4d0">+</button>'), Ju = /* @__PURE__ */ N('<input class="inline-input inline-number svelte-enf4d0" type="number" step="any"/>'), Qu = /* @__PURE__ */ N('<label class="inline-checkbox svelte-enf4d0"><input type="checkbox" class="svelte-enf4d0"/> <span class="svelte-enf4d0"> </span></label>'), Ku = /* @__PURE__ */ N('<input class="inline-input svelte-enf4d0" type="text"/>'), $u = /* @__PURE__ */ N('<div class="port-inline-config svelte-enf4d0"><!></div>'), ec = /* @__PURE__ */ N('<div class="port-row input-row svelte-enf4d0"><!> <span role="button" tabindex="-1"></span> <span> </span> <span class="port-type-tag svelte-enf4d0"> </span></div> <!>', 1), tc = /* @__PURE__ */ N('<button class="ports-toggle svelte-enf4d0"><!></button>'), nc = /* @__PURE__ */ N('<div class="ports svelte-enf4d0"><!> <!></div>'), rc = /* @__PURE__ */ N('<div class="widget-gradio-wrap svelte-enf4d0"><!></div>'), ac = /* @__PURE__ */ N('<div class="widget-text-display svelte-enf4d0"> </div>'), ic = /* @__PURE__ */ N('<input class="widget-number svelte-enf4d0" type="number" step="any"/>'), oc = /* @__PURE__ */ N('<label class="widget-checkbox-row svelte-enf4d0"><input class="widget-checkbox svelte-enf4d0" type="checkbox"/> <span class="widget-checkbox-label svelte-enf4d0"> </span></label>'), sc = /* @__PURE__ */ N('<div class="widget-gradio-wrap widget-gradio-image svelte-enf4d0"><!></div>'), lc = /* @__PURE__ */ N('<img class="widget-img svelte-enf4d0"/>'), uc = /* @__PURE__ */ N('<audio class="widget-audio svelte-enf4d0" controls=""></audio>'), cc = /* @__PURE__ */ N('<video class="widget-video svelte-enf4d0" controls=""></video>', 2), dc = /* @__PURE__ */ N('<div class="widget-file-info svelte-enf4d0"><span class="widget-file-name svelte-enf4d0"> </span></div>'), fc = /* @__PURE__ */ N('<button class="widget-clear svelte-enf4d0">&times;</button>'), hc = /* @__PURE__ */ N('<div class="widget-preview svelte-enf4d0"><!> <!></div>'), vc = /* @__PURE__ */ N('<div class="widget-placeholder svelte-enf4d0">Waiting for output...</div>'), pc = /* @__PURE__ */ N('<label class="widget-file-drop svelte-enf4d0"><input type="file" class="svelte-enf4d0"/> <span class="widget-drop-text svelte-enf4d0"> </span></label>'), gc = /* @__PURE__ */ N('<div class="widget-zone svelte-enf4d0"><!></div>'), mc = /* @__PURE__ */ N('<button class="port-auto-btn svelte-enf4d0">+</button>'), bc = /* @__PURE__ */ N('<div class="port-row output-row svelte-enf4d0"><span class="port-type-tag svelte-enf4d0"> </span> <span class="port-label svelte-enf4d0"> </span> <span class="port-dot output-dot svelte-enf4d0" role="button" tabindex="-1"></span> <!></div>'), _c = /* @__PURE__ */ N('<div class="ports svelte-enf4d0"></div>'), yc = /* @__PURE__ */ N('<div class="node-error-banner svelte-enf4d0"> </div>'), wc = /* @__PURE__ */ N('<div><div class="node-top-accent svelte-enf4d0"></div> <div class="node-header svelte-enf4d0" role="button" tabindex="-1"><div class="node-header-top svelte-enf4d0"><!> <span class="kind-tag svelte-enf4d0"> </span> <!> <button class="node-delete svelte-enf4d0" title="Delete node">&times;</button></div> <!></div> <!> <!> <!> <!></div>');
function xc(e, t) {
  nt(t, !0), this && this.__awaiter;
  var n, r, a, i, s, l, u, c, h, v, f, w;
  let b, E = he(!1), p, g = he(!1);
  const y = 3;
  function m(S) {
    const k = S.trim();
    k && k !== t.node.label && tt.update((_) => Object.assign(Object.assign({}, _), {
      nodes: _.nodes.map((V) => V.id === t.node.id ? Object.assign(Object.assign({}, V), { label: k }) : V)
    })), C(E, !1);
  }
  const O = (i = (r = (n = t.node.outputs[0]) === null || n === void 0 ? void 0 : n.type) !== null && r !== void 0 ? r : (a = t.node.inputs[0]) === null || a === void 0 ? void 0 : a.type) !== null && i !== void 0 ? i : "any", I = Xe[O], B = _l[O], Z = t.node.kind === "input" || t.node.kind === "output", R = t.node.kind === "input" ? (l = (s = t.node.outputs[0]) === null || s === void 0 ? void 0 : s.id) !== null && l !== void 0 ? l : null : t.node.kind === "output" && (c = (u = t.node.inputs[0]) === null || u === void 0 ? void 0 : u.id) !== null && c !== void 0 ? c : null, F = t.node.kind === "input" ? (v = (h = t.node.outputs[0]) === null || h === void 0 ? void 0 : h.type) !== null && v !== void 0 ? v : null : t.node.kind === "output" && (w = (f = t.node.inputs[0]) === null || f === void 0 ? void 0 : f.type) !== null && w !== void 0 ? w : null, q = t.node.kind === "output";
  function me() {
    var S;
    if (!R) return "";
    const k = (S = t.node.data) === null || S === void 0 ? void 0 : S[R];
    return typeof k == "string" ? k : "";
  }
  function Ue() {
    var S;
    if (!R) return null;
    const k = (S = t.node.data) === null || S === void 0 ? void 0 : S[R];
    return k && typeof k == "object" ? k : null;
  }
  function be() {
    var S;
    if (!R) return 0;
    const k = (S = t.node.data) === null || S === void 0 ? void 0 : S[R];
    return typeof k == "number" ? k : 0;
  }
  function Ne() {
    var S;
    if (!R) return !1;
    const k = (S = t.node.data) === null || S === void 0 ? void 0 : S[R];
    return typeof k == "boolean" ? k : !1;
  }
  function ut() {
    var S;
    if (!R) return "";
    const k = (S = t.node.data) === null || S === void 0 ? void 0 : S[R];
    return typeof k == "string" ? k : "";
  }
  function _t(S) {
    const k = S.currentTarget;
    R && t.ondatachange(t.node.id, R, parseFloat(k.value) || 0);
  }
  function yt(S) {
    const k = S.currentTarget;
    R && t.ondatachange(t.node.id, R, k.checked);
  }
  function Tt(S) {
    var k, _;
    const ee = (k = S.currentTarget.files) === null || k === void 0 ? void 0 : k[0];
    if (!ee || !R) return;
    const te = Ue();
    !((_ = te?.url) === null || _ === void 0) && _.startsWith("blob:") && URL.revokeObjectURL(te.url), t.ondatachange(t.node.id, R, {
      name: ee.name,
      url: URL.createObjectURL(ee),
      mime: ee.type
    });
  }
  function It(S) {
    var k, _, V;
    S.preventDefault(), S.stopPropagation();
    const ee = (_ = (k = S.dataTransfer) === null || k === void 0 ? void 0 : k.files) === null || _ === void 0 ? void 0 : _[0];
    if (!ee || !R) return;
    const te = Ue();
    !((V = te?.url) === null || V === void 0) && V.startsWith("blob:") && URL.revokeObjectURL(te.url), t.ondatachange(t.node.id, R, {
      name: ee.name,
      url: URL.createObjectURL(ee),
      mime: ee.type
    });
  }
  function ft() {
    var S;
    if (!R) return;
    const k = Ue();
    !((S = k?.url) === null || S === void 0) && S.startsWith("blob:") && URL.revokeObjectURL(k.url), t.ondatachange(t.node.id, R, null);
  }
  const wt = (S) => S;
  function Nt(S) {
    S.preventDefault();
    const k = S.clientX, _ = S.clientY, V = t.node.x, ee = t.node.y;
    function te(pe) {
      const U = (pe.clientX - k) / t.zoom, Oe = (pe.clientY - _) / t.zoom;
      t.onmove(t.node.id, V + U, ee + Oe);
    }
    function Se() {
      window.removeEventListener("mousemove", te), window.removeEventListener("mouseup", Se);
    }
    window.addEventListener("mousemove", te), window.addEventListener("mouseup", Se);
  }
  function Y(S, k) {
    return S === "any" || k === "any" || S === k;
  }
  Ot(() => {
    if (!b) return;
    const S = new ResizeObserver(([k]) => {
      const _ = Math.ceil(k.borderBoxSize[0].blockSize);
      Math.abs(_ - t.node.height) > 1 && kl(t.node.id, t.node.width, _);
    });
    return S.observe(b), () => S.disconnect();
  });
  var J = wc();
  let ne;
  var Me = L(A(J), 2), se = A(Me), ze = A(se);
  {
    var Ze = (S) => {
      var k = Xu();
      T(S, k);
    };
    W(ze, (S) => {
      t.status === "running" && S(Ze);
    });
  }
  var ht = L(ze, 2), Ct = A(ht), vt = L(ht, 2);
  {
    var at = (S) => {
      var k = Wu();
      Pt(k, (_) => p = _, () => p), z(() => qt(k, t.node.label)), Te("blur", k, (_) => m(_.currentTarget.value)), X("keydown", k, (_) => {
        _.key === "Enter" && m(_.currentTarget.value), _.key === "Escape" && C(E, !1), _.stopPropagation();
      }), X("mousedown", k, (_) => _.stopPropagation()), T(S, k);
    }, xt = (S) => {
      var k = qu(), _ = A(k);
      z(() => re(_, t.node.label)), X("dblclick", k, (V) => {
        V.stopPropagation(), C(E, !0), requestAnimationFrame(() => p?.select());
      }), T(S, k);
    };
    W(vt, (S) => {
      o(E) ? S(at) : S(xt, -1);
    });
  }
  var Ut = L(vt, 2), jt = L(se, 2);
  {
    var Et = (S) => {
      var k = Zu(), _ = A(k);
      z(() => {
        H(k, "href", `https://huggingface.co/spaces/${t.node.space_id ?? ""}`), H(k, "title", t.node.space_id), re(_, t.node.space_id);
      }), X("mousedown", k, (V) => V.stopPropagation()), T(S, k);
    };
    W(jt, (S) => {
      t.node.source === "space" && t.node.space_id && S(Et);
    });
  }
  var Mt = L(Me, 2);
  {
    var Bt = (S) => {
      const k = ve(() => t.node.inputs.length > y), _ = ve(() => t.node.inputs.length - y);
      var V = nc(), ee = A(V);
      it(ee, 17, () => t.node.inputs, kt, (pe, U, Oe) => {
        const le = ve(() => t.connectedPorts.has(`${t.node.id}:${o(U).id}:input`)), Ce = ve(() => o(g) || Oe < y || o(le));
        var Ae = $e(), de = Pe(Ae);
        {
          var Ve = (ue) => {
            var ye = ec(), qe = Pe(ye), Ie = A(qe);
            {
              var De = (gt) => {
                var Ke = Yu();
                z(() => {
                  Ye(Ke, `--port-color: ${Xe[o(U).type] ?? ""}`), H(Ke, "title", `Add ${o(U).type ?? ""} input`);
                }), X("mousedown", Ke, (Ft) => Ft.stopPropagation()), X("click", Ke, () => t.onautoconnect(t.node.id, o(U).id, o(U).type, "input")), T(gt, Ke);
              };
              W(Ie, (gt) => {
                !o(le) && !t.pending && gt(De);
              });
            }
            var We = L(Ie, 2);
            let et;
            var Je = L(We, 2);
            let ge;
            var Ee = A(Je), Le = L(Je, 2), Qe = A(Le), pt = L(qe, 2);
            {
              var Ht = (gt) => {
                var Ke = $u(), Ft = A(Ke);
                {
                  var Kt = (ct) => {
                    var ot = Ju();
                    z(
                      (dt) => {
                        H(ot, "placeholder", dt), qt(ot, t.node.data?.[o(U).id] ?? "");
                      },
                      [
                        () => o(U).default_value != null ? String(o(U).default_value) : "0"
                      ]
                    ), X("input", ot, (dt) => t.ondatachange(t.node.id, o(U).id, parseFloat(dt.currentTarget.value) || 0)), T(ct, ot);
                  }, Xn = (ct) => {
                    var ot = Qu(), dt = A(ot), hn = L(dt, 2), Wn = A(hn);
                    z(() => {
                      Vr(dt, !!t.node.data?.[o(U).id]), re(Wn, t.node.data?.[o(U).id] ? "On" : "Off");
                    }), X("change", dt, (qn) => t.ondatachange(t.node.id, o(U).id, qn.currentTarget.checked)), T(ct, ot);
                  }, kn = (ct) => {
                    var ot = Ku();
                    z(
                      (dt) => {
                        H(ot, "placeholder", dt), qt(ot, typeof t.node.data?.[o(U).id] == "string" ? t.node.data[o(U).id] : "");
                      },
                      [
                        () => o(U).default_value != null ? String(o(U).default_value) : o(U).label
                      ]
                    ), X("input", ot, (dt) => t.ondatachange(t.node.id, o(U).id, dt.currentTarget.value)), T(ct, ot);
                  };
                  W(Ft, (ct) => {
                    o(U).type === "number" ? ct(Kt) : o(U).type === "boolean" ? ct(Xn, 1) : ct(kn, -1);
                  });
                }
                X("mousedown", Ke, (ct) => ct.stopPropagation()), T(gt, Ke);
              };
              W(pt, (gt) => {
                !o(le) && t.node.kind === "transform" && (o(U).type === "text" || o(U).type === "number" || o(U).type === "boolean" || o(U).type === "any" || o(U).type === "json") && gt(Ht);
              });
            }
            z(
              (gt) => {
                et = Be(We, 1, "port-dot input-dot svelte-enf4d0", null, et, gt), Ye(We, `--port-color: ${Xe[o(U).type] ?? ""}`), H(We, "data-port-id", `${t.node.id ?? ""}:${o(U).id ?? ""}:input`), ge = Be(Je, 1, "port-label svelte-enf4d0", null, ge, { "port-label-optional": o(U).required === !1 }), re(Ee, o(U).label), Ye(Le, `color: ${Xe[o(U).type] ?? ""}`), re(Qe, o(U).type);
              },
              [
                () => ({
                  "port-optional": o(U).required === !1,
                  "port-filled": o(U).required !== !1,
                  incompatible: t.pending !== null && !Y(t.pending.type, o(U).type),
                  pulse: t.pending !== null && Y(t.pending.type, o(U).type)
                })
              ]
            ), X("mouseup", We, () => t.oncompleteconnection(t.node.id, o(U).id, o(U).type)), T(ue, ye);
          };
          W(de, (ue) => {
            o(Ce) && ue(Ve);
          });
        }
        T(pe, Ae);
      });
      var te = L(ee, 2);
      {
        var Se = (pe) => {
          var U = tc(), Oe = A(U);
          {
            var le = (Ae) => {
              var de = Nn("▴ show less");
              T(Ae, de);
            }, Ce = (Ae) => {
              var de = Nn();
              z(() => re(de, `▾ ${o(_) ?? ""} more params`)), T(Ae, de);
            };
            W(Oe, (Ae) => {
              o(g) ? Ae(le) : Ae(Ce, -1);
            });
          }
          X("mousedown", U, (Ae) => Ae.stopPropagation()), X("click", U, () => C(g, !o(g))), T(pe, U);
        };
        W(te, (pe) => {
          o(k) && pe(Se);
        });
      }
      T(S, V);
    };
    W(Mt, (S) => {
      t.node.inputs.length > 0 && S(Bt);
    });
  }
  var Rt = L(Mt, 2);
  {
    var K = (S) => {
      var k = gc(), _ = A(k);
      {
        var V = (pe) => {
          var U = rc(), Oe = A(U);
          {
            let le = ve(() => me() || ut()), Ce = ve(() => F === "json" ? 4 : 3), Ae = ve(() => q ? "Waiting for output..." : F === "json" ? '{"key": "value"}' : "Enter text...");
            bu(Oe, {
              get value() {
                return o(le);
              },
              label: "text",
              show_label: !1,
              get lines() {
                return o(Ce);
              },
              max_lines: 8,
              get placeholder() {
                return o(Ae);
              },
              get disabled() {
                return q;
              },
              oninput: (de) => {
                R && t.ondatachange(t.node.id, R, de);
              }
            });
          }
          T(pe, U);
        }, ee = (pe) => {
          var U = $e(), Oe = Pe(U);
          {
            var le = (Ae) => {
              var de = ac(), Ve = A(de);
              z((ue) => re(Ve, ue), [() => be()]), T(Ae, de);
            }, Ce = (Ae) => {
              var de = ic();
              z((Ve) => qt(de, Ve), [() => be()]), X("input", de, _t), T(Ae, de);
            };
            W(Oe, (Ae) => {
              q ? Ae(le) : Ae(Ce, -1);
            });
          }
          T(pe, U);
        }, te = (pe) => {
          var U = oc(), Oe = A(U), le = L(Oe, 2), Ce = A(le);
          z(
            (Ae, de) => {
              Vr(Oe, Ae), Oe.disabled = q, re(Ce, de);
            },
            [
              () => Ne(),
              () => Ne() ? "On" : "Off"
            ]
          ), X("change", Oe, yt), T(pe, U);
        }, Se = (pe) => {
          const U = ve(Ue);
          var Oe = $e(), le = Pe(Oe);
          {
            var Ce = (de) => {
              var Ve = hc(), ue = A(Ve);
              {
                var ye = (ge) => {
                  var Ee = sc(), Le = A(Ee);
                  {
                    let Qe = ve(() => ({
                      url: o(U).url,
                      orig_name: o(U).name,
                      path: o(U).url,
                      mime_type: o(U).mime
                    }));
                    Vu(Le, {
                      get value() {
                        return o(Qe);
                      },
                      show_label: !1,
                      i18n: wt,
                      buttons: []
                    });
                  }
                  T(ge, Ee);
                }, qe = (ge) => {
                  var Ee = lc();
                  z(() => {
                    H(Ee, "src", o(U).url), H(Ee, "alt", o(U).name);
                  }), T(ge, Ee);
                }, Ie = (ge) => {
                  var Ee = uc();
                  z(() => H(Ee, "src", o(U).url)), T(ge, Ee);
                }, De = (ge) => {
                  var Ee = cc();
                  z(() => H(Ee, "src", o(U).url)), T(ge, Ee);
                }, We = (ge) => {
                  var Ee = dc(), Le = A(Ee), Qe = A(Le);
                  z(() => re(Qe, o(U).name)), T(ge, Ee);
                };
                W(ue, (ge) => {
                  (F === "image" || F === "gallery") && q ? ge(ye) : F === "image" || F === "gallery" ? ge(qe, 1) : F === "audio" ? ge(Ie, 2) : F === "video" ? ge(De, 3) : ge(We, -1);
                });
              }
              var et = L(ue, 2);
              {
                var Je = (ge) => {
                  var Ee = fc();
                  X("click", Ee, ft), T(ge, Ee);
                };
                W(et, (ge) => {
                  q || ge(Je);
                });
              }
              T(de, Ve);
            }, Ae = (de) => {
              var Ve = $e(), ue = Pe(Ve);
              {
                var ye = (Ie) => {
                  var De = vc();
                  T(Ie, De);
                }, qe = (Ie) => {
                  var De = pc(), We = A(De), et = L(We, 2), Je = A(et);
                  z(() => {
                    H(We, "accept", F === "image" ? "image/*" : F === "audio" ? "audio/*" : F === "video" ? "video/*" : F === "model3d" ? ".glb,.gltf,.obj,.stl" : "*"), re(Je, `Drop ${F ?? ""} or click`);
                  }), Te("dragover", De, (ge) => {
                    ge.preventDefault(), ge.stopPropagation();
                  }), Te("drop", De, It), X("change", We, Tt), T(Ie, De);
                };
                W(ue, (Ie) => {
                  q ? Ie(ye) : Ie(qe, -1);
                });
              }
              T(de, Ve);
            };
            W(le, (de) => {
              o(U) ? de(Ce) : de(Ae, -1);
            });
          }
          T(pe, Oe);
        };
        W(_, (pe) => {
          F === "text" || F === "json" ? pe(V) : F === "number" ? pe(ee, 1) : F === "boolean" ? pe(te, 2) : (F === "image" || F === "audio" || F === "video" || F === "file" || F === "gallery" || F === "model3d") && pe(Se, 3);
        });
      }
      X("mousedown", k, (pe) => pe.stopPropagation()), T(S, k);
    };
    W(Rt, (S) => {
      Z && R && F && S(K);
    });
  }
  var G = L(Rt, 2);
  {
    var _e = (S) => {
      var k = _c();
      it(k, 21, () => t.node.outputs, kt, (_, V) => {
        const ee = ve(() => t.connectedPorts.has(`${t.node.id}:${o(V).id}:output`));
        var te = bc(), Se = A(te), pe = A(Se), U = L(Se, 2), Oe = A(U), le = L(U, 2), Ce = L(le, 2);
        {
          var Ae = (de) => {
            var Ve = mc();
            z(() => {
              Ye(Ve, `--port-color: ${Xe[o(V).type] ?? ""}`), H(Ve, "title", `Add ${o(V).type ?? ""} output`);
            }), X("mousedown", Ve, (ue) => ue.stopPropagation()), X("click", Ve, () => t.onautoconnect(t.node.id, o(V).id, o(V).type, "output")), T(de, Ve);
          };
          W(Ce, (de) => {
            !o(ee) && !t.pending && de(Ae);
          });
        }
        z(() => {
          Ye(Se, `color: ${Xe[o(V).type] ?? ""}`), re(pe, o(V).type), re(Oe, o(V).label), Ye(le, `--port-color: ${Xe[o(V).type] ?? ""}`), H(le, "data-port-id", `${t.node.id ?? ""}:${o(V).id ?? ""}:output`);
        }), X("mousedown", le, (de) => t.onstartconnection(t.node.id, o(V).id, o(V).type, de)), T(_, te);
      }), T(S, k);
    };
    W(G, (S) => {
      t.node.outputs.length > 0 && S(_e);
    });
  }
  var ce = L(G, 2);
  {
    var je = (S) => {
      var k = yc(), _ = A(k);
      z(() => re(_, t.error)), T(S, k);
    };
    W(ce, (S) => {
      t.status === "error" && t.error && S(je);
    });
  }
  Pt(J, (S) => b = S, () => b), z(() => {
    ne = Be(J, 1, "wf-node svelte-enf4d0", null, ne, {
      "node-running": t.status === "running",
      "node-done": t.status === "done",
      "node-error": t.status === "error",
      "node-selected": t.selected
    }), Ye(J, `
		left: ${t.node.x ?? ""}px;
		top: ${t.node.y ?? ""}px;
		width: ${t.node.width ?? ""}px;
		--accent: ${I ?? ""};
		--accent-dim: ${B ?? ""};
	`), re(Ct, yl[t.node.kind] ?? "?");
  }), X("click", J, () => t.onselect(t.node.id)), X("mousedown", Me, Nt), X("mousedown", Ut, (S) => S.stopPropagation()), X("click", Ut, () => t.onremove(t.node.id)), T(e, J), rt();
}
lt([
  "click",
  "mousedown",
  "keydown",
  "dblclick",
  "mouseup",
  "input",
  "change"
]);
var Ec = /* @__PURE__ */ bt('<linearGradient x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-opacity="0.9"></stop><stop offset="100%" stop-opacity="0.4"></stop></linearGradient>'), kc = /* @__PURE__ */ bt('<path fill="none" stroke-opacity="0.08" style="pointer-events: none"></path><path class="wire-hitbox svelte-m0h81u" fill="none" stroke="transparent" role="button" tabindex="-1"></path><path class="wire" fill="none" style="pointer-events: none"></path><path class="wire-flow svelte-m0h81u" fill="none" stroke-opacity="0.5" style="pointer-events: none"></path><rect style="pointer-events: none"></rect>', 1), Tc = /* @__PURE__ */ bt('<path fill="none" stroke-opacity="0.6" style="pointer-events: none"></path><circle fill="none" stroke-opacity="0.5" style="pointer-events: none"></circle>', 1), Sc = /* @__PURE__ */ bt('<svg class="edge-layer svelte-m0h81u"><defs></defs><!><!></svg>');
function Oc(e, t) {
  nt(t, !0);
  const n = () => La(tt, "$workflow", r), [r, a] = Pa();
  function i(f, w, b, E) {
    const p = Math.max(Math.abs(b - f) * 0.5, 60);
    return `M ${f} ${w} C ${f + p} ${w}, ${b - p} ${E}, ${b} ${E}`;
  }
  function s(f, w, b, E) {
    const p = document.querySelector(`[data-port-id="${w}:${b}:${E}"]`), g = document.querySelector(".canvas-transform");
    if (p && g) {
      const R = p.getBoundingClientRect(), F = g.getBoundingClientRect();
      return {
        x: (R.left + R.width / 2 - F.left) / t.zoom,
        y: (R.top + R.height / 2 - F.top) / t.zoom
      };
    }
    const y = f.find((R) => R.id === w);
    if (!y) return { x: 0, y: 0 };
    const m = E === "output" ? y.outputs : y.inputs, O = m.findIndex((R) => R.id === b), I = O >= 0 ? O : 0, B = E === "output" ? y.x + y.width : y.x, Z = y.source === "space" && y.space_id ? 60 : 44;
    if (E === "input")
      return { x: B, y: y.y + Z + I * 26 };
    {
      const R = m.length * 26;
      return {
        x: B,
        y: y.y + y.height - R + I * 26 - 2
      };
    }
  }
  var l = Sc(), u = A(l);
  it(u, 5, () => n().edges, (f) => f.id, (f, w) => {
    var b = Ec(), E = A(b), p = L(E);
    z(() => {
      H(b, "id", `grad-${o(w).id ?? ""}`), H(E, "stop-color", Xe[o(w).type]), H(p, "stop-color", Xe[o(w).type]);
    }), T(f, b);
  });
  var c = L(u);
  it(c, 1, () => n().edges, (f) => f.id, (f, w) => {
    const b = ve(() => s(n().nodes, o(w).from_node_id, o(w).from_port_id, "output")), E = ve(() => s(n().nodes, o(w).to_node_id, o(w).to_port_id, "input")), p = ve(() => 3.5 / t.zoom);
    var g = kc(), y = Pe(g), m = L(y), O = L(m), I = L(O), B = L(I);
    z(
      (Z, R, F, q) => {
        H(y, "d", Z), H(y, "stroke", Xe[o(w).type]), H(y, "stroke-width", 6 / t.zoom), H(m, "d", R), H(m, "stroke-width", 16 / t.zoom), H(O, "d", F), H(O, "stroke", `url(#grad-${o(w).id ?? ""})`), H(O, "stroke-width", 2 / t.zoom), H(I, "d", q), H(I, "stroke", Xe[o(w).type]), H(I, "stroke-width", 2 / t.zoom), H(I, "stroke-dasharray", `${4 / t.zoom} ${12 / t.zoom}`), H(B, "x", o(E).x - o(p)), H(B, "y", o(E).y - o(p)), H(B, "width", o(p) * 2), H(B, "height", o(p) * 2), H(B, "rx", 1 / t.zoom), H(B, "fill", Xe[o(w).type]), H(B, "transform", `rotate(45 ${o(E).x ?? ""} ${o(E).y ?? ""})`);
      },
      [
        () => i(o(b).x, o(b).y, o(E).x, o(E).y),
        () => i(o(b).x, o(b).y, o(E).x, o(E).y),
        () => i(o(b).x, o(b).y, o(E).x, o(E).y),
        () => i(o(b).x, o(b).y, o(E).x, o(E).y)
      ]
    ), X("click", m, () => t.onremove(o(w).id)), T(f, g);
  });
  var h = L(c);
  {
    var v = (f) => {
      const w = ve(() => s(n().nodes, t.pending.from_node_id, t.pending.from_port_id, "output"));
      var b = Tc(), E = Pe(b), p = L(E);
      z(
        (g) => {
          H(E, "d", g), H(E, "stroke", Xe[t.pending.type] ?? "#5c5e6a"), H(E, "stroke-width", 2 / t.zoom), H(E, "stroke-dasharray", `${6 / t.zoom} ${4 / t.zoom}`), H(p, "cx", t.pending.x), H(p, "cy", t.pending.y), H(p, "r", 4 / t.zoom), H(p, "stroke", Xe[t.pending.type] ?? "#5c5e6a"), H(p, "stroke-width", 1.5 / t.zoom);
        },
        [
          () => i(o(w).x, o(w).y, t.pending.x, t.pending.y)
        ]
      ), T(f, b);
    };
    W(h, (f) => {
      t.pending && f(v);
    });
  }
  T(e, l), rt(), a();
}
lt(["click"]);
const Dt = {
  inputs: [
    {
      label: "Image",
      kind: "input",
      source: "local",
      outputs: [{ id: "out", label: "Image", type: "image" }],
      inputs: [],
      width: 220,
      height: 160
    },
    {
      label: "Textbox",
      kind: "input",
      source: "local",
      outputs: [{ id: "out", label: "Text", type: "text" }],
      inputs: [],
      width: 220,
      height: 160
    },
    {
      label: "Audio",
      kind: "input",
      source: "local",
      outputs: [{ id: "out", label: "Audio", type: "audio" }],
      inputs: [],
      width: 220,
      height: 160
    },
    {
      label: "Video",
      kind: "input",
      source: "local",
      outputs: [{ id: "out", label: "Video", type: "video" }],
      inputs: [],
      width: 220,
      height: 160
    },
    {
      label: "Number",
      kind: "input",
      source: "local",
      outputs: [{ id: "out", label: "Number", type: "number" }],
      inputs: [],
      width: 220,
      height: 130
    },
    {
      label: "File",
      kind: "input",
      source: "local",
      outputs: [{ id: "out", label: "File", type: "file" }],
      inputs: [],
      width: 220,
      height: 160
    },
    {
      label: "JSON",
      kind: "input",
      source: "local",
      outputs: [{ id: "out", label: "JSON", type: "json" }],
      inputs: [],
      width: 220,
      height: 160
    },
    {
      label: "Model3D",
      kind: "input",
      source: "local",
      outputs: [{ id: "out", label: "Model", type: "model3d" }],
      inputs: [],
      width: 220,
      height: 160
    }
  ],
  spaces: [
    // Image
    {
      label: "not-lain/background-removal",
      kind: "transform",
      source: "space",
      space_id: "not-lain/background-removal",
      category: "image",
      inputs: [],
      outputs: [],
      width: 280,
      height: 90
    },
    {
      label: "black-forest-labs/FLUX.1-schnell",
      kind: "transform",
      source: "space",
      space_id: "black-forest-labs/FLUX.1-schnell",
      category: "image",
      inputs: [],
      outputs: [],
      width: 280,
      height: 90
    },
    {
      label: "vikhyatk/moondream1",
      kind: "transform",
      source: "space",
      space_id: "vikhyatk/moondream1",
      category: "image",
      inputs: [],
      outputs: [],
      width: 280,
      height: 90
    },
    // Audio
    {
      label: "hf-audio/whisper-large-v3-turbo",
      kind: "transform",
      source: "space",
      space_id: "hf-audio/whisper-large-v3-turbo",
      category: "audio",
      inputs: [],
      outputs: [],
      width: 280,
      height: 90
    },
    {
      label: "mrfakename/E2-F5-TTS",
      kind: "transform",
      source: "space",
      space_id: "mrfakename/E2-F5-TTS",
      category: "audio",
      inputs: [],
      outputs: [],
      width: 280,
      height: 90
    },
    // Text
    {
      label: "UNESCO/nllb",
      kind: "transform",
      source: "space",
      space_id: "UNESCO/nllb",
      category: "text",
      inputs: [],
      outputs: [],
      width: 280,
      height: 90
    },
    {
      label: "huggingface-projects/gemma-2-9b-it",
      kind: "transform",
      source: "space",
      space_id: "huggingface-projects/gemma-2-9b-it",
      category: "text",
      inputs: [],
      outputs: [],
      width: 280,
      height: 90
    }
  ],
  outputs: [
    {
      label: "Image",
      kind: "output",
      source: "local",
      inputs: [{ id: "in", label: "Image", type: "image" }],
      outputs: [{ id: "out", label: "Image", type: "image" }],
      width: 220,
      height: 160
    },
    {
      label: "Textbox",
      kind: "output",
      source: "local",
      inputs: [{ id: "in", label: "Text", type: "text" }],
      outputs: [{ id: "out", label: "Text", type: "text" }],
      width: 220,
      height: 160
    },
    {
      label: "Audio",
      kind: "output",
      source: "local",
      inputs: [{ id: "in", label: "Audio", type: "audio" }],
      outputs: [{ id: "out", label: "Audio", type: "audio" }],
      width: 220,
      height: 160
    },
    {
      label: "Video",
      kind: "output",
      source: "local",
      inputs: [{ id: "in", label: "Video", type: "video" }],
      outputs: [{ id: "out", label: "Video", type: "video" }],
      width: 220,
      height: 160
    },
    {
      label: "Number",
      kind: "output",
      source: "local",
      inputs: [{ id: "in", label: "Number", type: "number" }],
      outputs: [{ id: "out", label: "Number", type: "number" }],
      width: 220,
      height: 110
    },
    {
      label: "File",
      kind: "output",
      source: "local",
      inputs: [{ id: "in", label: "File", type: "file" }],
      outputs: [{ id: "out", label: "File", type: "file" }],
      width: 220,
      height: 160
    },
    {
      label: "JSON",
      kind: "output",
      source: "local",
      inputs: [{ id: "in", label: "JSON", type: "json" }],
      outputs: [{ id: "out", label: "JSON", type: "json" }],
      width: 220,
      height: 160
    },
    {
      label: "Gallery",
      kind: "output",
      source: "local",
      inputs: [{ id: "in", label: "Gallery", type: "gallery" }],
      outputs: [{ id: "out", label: "Gallery", type: "gallery" }],
      width: 220,
      height: 160
    },
    {
      label: "Model3D",
      kind: "output",
      source: "local",
      inputs: [{ id: "in", label: "Model", type: "model3d" }],
      outputs: [{ id: "out", label: "Model", type: "model3d" }],
      width: 220,
      height: 160
    }
  ]
};
function va(e, t) {
  const n = e.toLowerCase();
  if (n === "image" || n === "imageeditor" || n === "imageslider") return "image";
  if (n === "gallery") return "gallery";
  if (n === "audio") return "audio";
  if (n === "video") return "video";
  if (n === "number" || n === "slider") return "number";
  if (n === "checkbox") return "boolean";
  if (n === "file" || n === "uploadbutton" || n === "downloadbutton") return "file";
  if (n === "model3d") return "model3d";
  if (n === "json" || n === "dataframe") return "json";
  if (n === "state") return "__skip__";
  if (n === "textbox" || n === "text" || n === "markdown" || n === "chatbot" || n === "label" || n === "code" || n === "highlightedtext" || n === "dropdown" || n === "radio" || n === "checkboxgroup" || n === "colorpicker" || n === "html") return "text";
  if (t) {
    const r = typeof t == "string" ? t.toLowerCase() : "";
    if (r.includes("image") || r.includes("pil")) return "image";
    if (r.includes("video") || r.includes("mp4")) return "video";
    if (r.includes("audio") || r.includes("wav") || r.includes("mp3")) return "audio";
    if (r.includes("filepath") || r.includes("file")) return "file";
    if (r === "number" || r === "float" || r === "int" || r === "integer") return "number";
    if (r === "bool" || r === "boolean") return "boolean";
    if (r === "str" || r === "string") return "text";
  }
  return "any";
}
const Ac = ["/predict", "/infer", "/generate", "/run", "/process", "/translate"], ci = ["/on_", "/handle_", "/update_", "/prepare_", "/load_", "/clear_", "/reset_"], Ic = /* @__PURE__ */ new Set(["video", "image", "imageeditor", "imageslider", "audio", "file", "uploadbutton", "gallery", "model3d"]);
function pa(e) {
  return (e.returns ?? []).reduce((t, n) => {
    const r = (n.component ?? "").toLowerCase();
    return t + (Ic.has(r) ? 10 : 1);
  }, 0);
}
function Cc(e) {
  const t = Object.keys(e), n = t.filter((a) => !ci.some((i) => a.startsWith(i))), r = n.length > 0 ? n : t;
  for (const a of Ac)
    if (r.includes(a)) return a;
  return r.slice().sort((a, i) => pa(e[i]) - pa(e[a]))[0];
}
const ga = /* @__PURE__ */ new Map();
async function xr(e) {
  const t = ga.get(e);
  if (t) return t;
  const n = e.startsWith("http") ? e : `https://${e.replace("/", "-").replaceAll(".", "-").toLowerCase()}.hf.space`;
  let r = null;
  for (const p of ["/gradio_api/info", "/info", "/api/info"])
    try {
      const g = await Promise.race([
        fetch(`${n}${p}`),
        new Promise(
          (y, m) => setTimeout(() => m(new Error("Timed out")), 1e4)
        )
      ]);
      if (g.ok) {
        r = g;
        break;
      }
    } catch {
    }
  if (!r) throw new Error("Could not connect to Space — it may be sleeping or have no Gradio API");
  const a = await r.json(), i = a.named_endpoints ?? {}, s = a.unnamed_endpoints ?? {};
  if (Object.keys(i).length === 0 && Object.keys(s).length === 0)
    throw new Error("No API endpoints found");
  let l, u;
  const c = Object.keys(i).length > 0 ? Cc(i) : null;
  if (c && !ci.some((p) => c.startsWith(p)))
    l = c, u = i[l];
  else if (s[0])
    l = "0", u = s[0];
  else if (i["/predict"])
    l = "/predict", u = i["/predict"];
  else if (c)
    l = c, u = i[l];
  else
    throw new Error("No suitable endpoint found");
  const h = (u.parameters ?? []).map((p, g) => {
    const y = va(p.component ?? "", typeof p.type == "string" ? p.type : "");
    if (y === "__skip__") return null;
    const m = p.parameter_has_default === !0;
    return {
      id: `in_${g}`,
      label: p.label || p.parameter_name || `Input ${g}`,
      type: y,
      required: !m,
      default_value: m && p.default !== void 0 ? p.default : void 0
    };
  }).filter(Boolean), v = (u.returns ?? []).map((p, g) => {
    const y = va(p.component ?? "", typeof p.type == "string" ? p.type : "");
    return y === "__skip__" ? null : {
      id: `out_${g}`,
      label: p.label || `Output ${g}`,
      type: y
    };
  }).filter(Boolean);
  h.length === 0 && h.push({ id: "in", label: "Input", type: "any" }), v.length === 0 && v.push({ id: "out", label: "Output", type: "any" });
  const f = e.split("/").pop() ?? e, w = Math.max(
    ...h.map((p) => p.label.length),
    ...v.map((p) => p.label.length),
    f.length
  ), b = Math.max(280, Math.min(400, w * 9 + 100)), E = { endpoint: l, inputs: h, outputs: v, width: b };
  return ga.set(e, E), E;
}
var Hc = /* @__PURE__ */ N('<div draggable="true" class="chip svelte-5hsmvk"><span class="chip-dot svelte-5hsmvk"></span> <span class="chip-label svelte-5hsmvk"> </span> <a class="chip-link svelte-5hsmvk" target="_blank" rel="noopener" title="Open on HuggingFace">&#x2197;</a> <button class="chip-remove svelte-5hsmvk" title="Remove">&times;</button></div>'), Lc = /* @__PURE__ */ N('<div class="category-header svelte-5hsmvk"><span class="category-label svelte-5hsmvk"> </span></div> <!>', 1), Pc = /* @__PURE__ */ N('<div draggable="true" class="chip svelte-5hsmvk"><span class="chip-dot svelte-5hsmvk"></span> <span class="chip-label svelte-5hsmvk"> </span></div>'), Nc = /* @__PURE__ */ N('<a class="chip-link svelte-5hsmvk" target="_blank" rel="noopener" title="Open on HuggingFace">&#x2197;</a>'), Mc = /* @__PURE__ */ N('<div draggable="true" class="chip svelte-5hsmvk"><span class="chip-dot svelte-5hsmvk"></span> <span class="chip-label svelte-5hsmvk"> </span> <!> <button class="chip-remove svelte-5hsmvk" title="Remove">&times;</button></div>'), Bc = /* @__PURE__ */ N('<div class="search-result-desc svelte-5hsmvk"> </div>'), Rc = /* @__PURE__ */ N('<button class="search-result svelte-5hsmvk"><div class="search-result-top svelte-5hsmvk"><span></span> <span class="search-result-name svelte-5hsmvk"> </span> <span class="search-result-likes svelte-5hsmvk"> </span> <a class="search-result-link svelte-5hsmvk" target="_blank" rel="noopener" title="Open on HuggingFace">&#x2197;</a></div> <!></button>'), Dc = /* @__PURE__ */ N('<div class="search-dropdown svelte-5hsmvk"></div>'), Uc = /* @__PURE__ */ N('<div class="search-dropdown svelte-5hsmvk"><div class="search-searching svelte-5hsmvk">Searching...</div></div>'), jc = /* @__PURE__ */ N('<div class="space-loading svelte-5hsmvk"><span class="space-loading-spinner svelte-5hsmvk"></span> <span class="space-loading-text svelte-5hsmvk"> </span></div>'), Fc = /* @__PURE__ */ N('<span class="space-error svelte-5hsmvk"> </span>'), Gc = /* @__PURE__ */ N('<!> <div class="add-space-wrapper svelte-5hsmvk"><div class="add-space svelte-5hsmvk"><input class="space-input svelte-5hsmvk" type="text" placeholder="Search Spaces..."/> <button class="space-add-btn svelte-5hsmvk"> </button></div> <!></div> <!> <!>', 1), zc = /* @__PURE__ */ N('<div class="section-items svelte-5hsmvk"><!> <!></div>'), Vc = /* @__PURE__ */ N('<button><span class="section-label svelte-5hsmvk"> </span> <span class="section-count svelte-5hsmvk"> </span> <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg></button> <!>', 1), Xc = /* @__PURE__ */ N('<!> <div class="sidebar-footer svelte-5hsmvk"><span class="hint svelte-5hsmvk">Drag to canvas</span></div>', 1), Wc = /* @__PURE__ */ N('<div class="resize-handle svelte-5hsmvk"></div>'), qc = /* @__PURE__ */ N('<aside><div class="sidebar-header svelte-5hsmvk"><button><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg></button></div> <!> <!></aside>');
function Zc(e, t) {
  nt(t, !0);
  var n = this && this.__awaiter || function(Y, J, ne, Me) {
    function se(ze) {
      return ze instanceof ne ? ze : new ne(function(Ze) {
        Ze(ze);
      });
    }
    return new (ne || (ne = Promise))(function(ze, Ze) {
      function ht(at) {
        try {
          vt(Me.next(at));
        } catch (xt) {
          Ze(xt);
        }
      }
      function Ct(at) {
        try {
          vt(Me.throw(at));
        } catch (xt) {
          Ze(xt);
        }
      }
      function vt(at) {
        at.done ? ze(at.value) : se(at.value).then(ht, Ct);
      }
      vt((Me = Me.apply(Y, J || [])).next());
    });
  }, r, a;
  let i = P(t, "onadd", 3, void 0), s = he("spaces"), l = he(!1), u = he(At(new Set(typeof localStorage < "u" ? JSON.parse((r = localStorage.getItem("gradio_hidden_presets")) !== null && r !== void 0 ? r : "[]") : []))), c = he(220), h = he(!1), v = he(At(typeof localStorage < "u" ? JSON.parse((a = localStorage.getItem("gradio_custom_spaces")) !== null && a !== void 0 ? a : "[]") : []));
  Ot(() => {
    typeof localStorage < "u" && localStorage.setItem("gradio_custom_spaces", JSON.stringify(o(v)));
  });
  function f(Y) {
    Y.preventDefault(), C(h, !0);
    const J = Y.clientX, ne = o(c);
    function Me(ze) {
      C(c, Math.max(160, Math.min(400, ne + (ze.clientX - J))), !0);
    }
    function se() {
      C(h, !1), window.removeEventListener("mousemove", Me), window.removeEventListener("mouseup", se);
    }
    window.addEventListener("mousemove", Me), window.addEventListener("mouseup", se);
  }
  let w = he(""), b = he(!1), E = he(""), p = he("");
  function g(Y) {
    const J = Y.target;
    o(y).length > 0 && !J.closest(".add-space-wrapper") && C(y, [], !0);
  }
  let y = he(At([])), m = he(!1), O = null;
  function I(Y) {
    const J = Y.currentTarget.value;
    if (C(w, J, !0), C(p, ""), O && clearTimeout(O), J.length < 2) {
      C(y, [], !0), C(m, !1);
      return;
    }
    if (J.includes("/") && !J.endsWith("/")) {
      C(y, [], !0);
      return;
    }
    C(m, !0), O = setTimeout(
      () => n(this, void 0, void 0, function* () {
        try {
          const ne = yield fetch(`https://huggingface.co/api/spaces/semantic-search?q=${encodeURIComponent(J)}&limit=8`);
          if (!ne.ok) {
            C(y, [], !0);
            return;
          }
          const Me = yield ne.json();
          C(
            y,
            Me.filter((se) => se.sdk === "gradio").slice(0, 6).map((se) => {
              var ze, Ze;
              return {
                id: se.id,
                likes: (ze = se.likes) !== null && ze !== void 0 ? ze : 0,
                title: se.title || se.id.split("/").pop(),
                description: se.ai_short_description || "",
                running: ((Ze = se.runtime) === null || Ze === void 0 ? void 0 : Ze.stage) === "RUNNING"
              };
            }),
            !0
          );
        } catch {
          C(y, [], !0);
        } finally {
          C(m, !1);
        }
      }),
      300
    );
  }
  function B(Y) {
    C(w, Y, !0), C(y, [], !0), F();
  }
  function Z(Y) {
    var J, ne, Me, se;
    return (se = (ne = (J = Y.outputs[0]) === null || J === void 0 ? void 0 : J.type) !== null && ne !== void 0 ? ne : (Me = Y.inputs[0]) === null || Me === void 0 ? void 0 : Me.type) !== null && se !== void 0 ? se : "any";
  }
  function R(Y) {
    C(s, o(s) === Y ? null : Y, !0);
  }
  function F() {
    return n(this, void 0, void 0, function* () {
      var Y;
      const J = o(w).trim();
      if (!(!J || !J.includes("/"))) {
        if (o(v).some((ne) => ne.space_id === J) || Dt.spaces.some((ne) => ne.space_id === J && !o(u).has(J))) {
          C(w, "");
          return;
        }
        C(b, !0), C(E, J, !0), C(p, ""), C(w, "");
        try {
          const ne = yield xr(J), Me = (Y = J.split("/").pop()) !== null && Y !== void 0 ? Y : J;
          C(
            v,
            [
              ...o(v),
              {
                label: Me,
                kind: "transform",
                source: "space",
                space_id: J,
                endpoint: ne.endpoint,
                inputs: ne.inputs,
                outputs: ne.outputs,
                width: ne.width,
                height: 90
              }
            ],
            !0
          ), C(w, "");
        } catch (ne) {
          C(p, ne instanceof Error ? ne.message : "Failed to connect", !0);
        } finally {
          C(b, !1);
        }
      }
    });
  }
  const q = [
    { key: "image", label: "Image" },
    { key: "audio", label: "Audio" },
    { key: "text", label: "Text" },
    { key: "video", label: "Video" }
  ];
  function me(Y) {
    return Dt.spaces.filter((J) => {
      var ne;
      return J.category === Y && !o(u).has((ne = J.space_id) !== null && ne !== void 0 ? ne : "");
    });
  }
  function Ue(Y) {
    C(u, /* @__PURE__ */ new Set([...o(u), Y]), !0), localStorage.setItem("gradio_hidden_presets", JSON.stringify([...o(u)]));
  }
  const be = [
    {
      key: "spaces",
      label: "Spaces",
      icon: "hub",
      items: Dt.spaces
    },
    {
      key: "components",
      label: "Components",
      icon: "layers",
      items: [...Dt.inputs, ...Dt.outputs]
    }
  ];
  var Ne = qc();
  Te("click", oo, g);
  let ut;
  var _t = A(Ne), yt = A(_t);
  let Tt;
  var It = L(_t, 2);
  {
    var ft = (Y) => {
      var J = Xc(), ne = Pe(J);
      it(ne, 17, () => be, kt, (Me, se) => {
        var ze = Vc(), Ze = Pe(ze);
        let ht;
        var Ct = A(Ze), vt = A(Ct), at = L(Ct, 2), xt = A(at), Ut = L(at, 2);
        let jt;
        var Et = L(Ze, 2);
        {
          var Mt = (Bt) => {
            var Rt = zc(), K = A(Rt);
            {
              var G = (S) => {
                var k = $e(), _ = Pe(k);
                it(_, 17, () => q, kt, (V, ee) => {
                  const te = ve(() => me(o(ee).key));
                  var Se = $e(), pe = Pe(Se);
                  {
                    var U = (Oe) => {
                      var le = Lc(), Ce = Pe(le), Ae = A(Ce), de = A(Ae), Ve = L(Ce, 2);
                      it(Ve, 17, () => o(te), kt, (ue, ye) => {
                        const qe = ve(() => Z(o(ye)));
                        var Ie = Hc(), De = A(Ie), We = L(De, 2), et = A(We), Je = L(We, 2), ge = L(Je, 2);
                        z(() => {
                          Ye(De, `background: ${Xe[o(qe)] ?? ""}; box-shadow: 0 0 6px ${Xe[o(qe)] ?? ""}40`), re(et, o(ye).label), H(Je, "href", `https://huggingface.co/spaces/${o(ye).space_id ?? ""}`);
                        }), X("click", Ie, () => i()?.(o(ye))), Te("dragstart", Ie, (Ee) => {
                          Ee.dataTransfer.setData("node-template", JSON.stringify(o(ye)));
                          const Le = document.createElement("div");
                          Le.textContent = o(ye).label, Le.style.cssText = `background:${Xe[o(qe)]};color:#0c0d10;padding:4px 10px;border-radius:5px;font-family:Manrope,sans-serif;font-size:11px;font-weight:600;position:fixed;top:-100px`, document.body.appendChild(Le), Ee.dataTransfer.setDragImage(Le, 0, 0), setTimeout(() => document.body.removeChild(Le), 0);
                        }), X("click", Je, (Ee) => Ee.stopPropagation()), X("click", ge, (Ee) => {
                          Ee.stopPropagation(), Ue(o(ye).space_id ?? "");
                        }), T(ue, Ie);
                      }), z(() => re(de, o(ee).label)), T(Oe, le);
                    };
                    W(pe, (Oe) => {
                      o(te).length > 0 && Oe(U);
                    });
                  }
                  T(V, Se);
                }), T(S, k);
              }, _e = (S) => {
                var k = $e(), _ = Pe(k);
                it(_, 17, () => o(se).items, kt, (V, ee) => {
                  const te = ve(() => Z(o(ee)));
                  var Se = Pc(), pe = A(Se), U = L(pe, 2), Oe = A(U);
                  z(() => {
                    Ye(pe, `background: ${Xe[o(te)] ?? ""}; box-shadow: 0 0 6px ${Xe[o(te)] ?? ""}40`), re(Oe, o(ee).label);
                  }), X("click", Se, () => i()?.(o(ee))), Te("dragstart", Se, (le) => {
                    le.dataTransfer.setData("node-template", JSON.stringify(o(ee)));
                    const Ce = document.createElement("div");
                    Ce.textContent = o(ee).label, Ce.style.cssText = `background:${Xe[o(te)]};color:#0c0d10;padding:4px 10px;border-radius:5px;font-family:Manrope,sans-serif;font-size:11px;font-weight:600;position:fixed;top:-100px`, document.body.appendChild(Ce), le.dataTransfer.setDragImage(Ce, 0, 0), setTimeout(() => document.body.removeChild(Ce), 0);
                  }), T(V, Se);
                }), T(S, k);
              };
              W(K, (S) => {
                o(se).key === "spaces" ? S(G) : S(_e, -1);
              });
            }
            var ce = L(K, 2);
            {
              var je = (S) => {
                var k = Gc(), _ = Pe(k);
                it(_, 17, () => o(v), kt, (ue, ye, qe) => {
                  const Ie = ve(() => Z(o(ye)));
                  var De = Mc(), We = A(De), et = L(We, 2), Je = A(et), ge = L(et, 2);
                  {
                    var Ee = (Qe) => {
                      var pt = Nc();
                      z(() => H(pt, "href", `https://huggingface.co/spaces/${o(ye).space_id ?? ""}`)), X("click", pt, (Ht) => Ht.stopPropagation()), T(Qe, pt);
                    };
                    W(ge, (Qe) => {
                      o(ye).space_id && Qe(Ee);
                    });
                  }
                  var Le = L(ge, 2);
                  z(() => {
                    Ye(We, `background: ${Xe[o(Ie)] ?? ""}; box-shadow: 0 0 6px ${Xe[o(Ie)] ?? ""}40`), re(Je, o(ye).label);
                  }), X("click", De, () => i()?.(o(ye))), Te("dragstart", De, (Qe) => Qe.dataTransfer.setData("node-template", JSON.stringify(o(ye)))), X("click", Le, (Qe) => {
                    Qe.stopPropagation(), C(v, o(v).filter((pt, Ht) => Ht !== qe), !0);
                  }), T(ue, De);
                });
                var V = L(_, 2), ee = A(V), te = A(ee), Se = L(te, 2), pe = A(Se), U = L(ee, 2);
                {
                  var Oe = (ue) => {
                    var ye = Dc();
                    it(ye, 21, () => o(y), kt, (qe, Ie) => {
                      var De = Rc(), We = A(De), et = A(We);
                      let Je;
                      var ge = L(et, 2), Ee = A(ge), Le = L(ge, 2), Qe = A(Le), pt = L(Le, 2), Ht = L(We, 2);
                      {
                        var gt = (Ke) => {
                          var Ft = Bc(), Kt = A(Ft);
                          z(() => re(Kt, o(Ie).description)), T(Ke, Ft);
                        };
                        W(Ht, (Ke) => {
                          o(Ie).description && Ke(gt);
                        });
                      }
                      z(() => {
                        Je = Be(et, 1, "search-result-status svelte-5hsmvk", null, Je, { "search-result-running": o(Ie).running }), H(et, "title", o(Ie).running ? "Running" : "Not running"), re(Ee, o(Ie).id), re(Qe, `♥ ${o(Ie).likes ?? ""}`), H(pt, "href", `https://huggingface.co/spaces/${o(Ie).id ?? ""}`);
                      }), X("click", De, () => B(o(Ie).id)), X("click", pt, (Ke) => Ke.stopPropagation()), T(qe, De);
                    }), T(ue, ye);
                  }, le = (ue) => {
                    var ye = Uc();
                    T(ue, ye);
                  };
                  W(U, (ue) => {
                    o(y).length > 0 ? ue(Oe) : o(m) && ue(le, 1);
                  });
                }
                var Ce = L(V, 2);
                {
                  var Ae = (ue) => {
                    var ye = jc(), qe = L(A(ye), 2), Ie = A(qe);
                    z(() => re(Ie, `Connecting to ${o(E) ?? ""}...`)), T(ue, ye);
                  };
                  W(Ce, (ue) => {
                    o(b) && ue(Ae);
                  });
                }
                var de = L(Ce, 2);
                {
                  var Ve = (ue) => {
                    var ye = Fc(), qe = A(ye);
                    z(() => re(qe, o(p))), T(ue, ye);
                  };
                  W(de, (ue) => {
                    o(p) && ue(Ve);
                  });
                }
                z(
                  (ue) => {
                    qt(te, o(w)), te.disabled = o(b), Se.disabled = ue, re(pe, o(b) ? "..." : "+");
                  },
                  [
                    () => o(b) || !o(w).trim().includes("/")
                  ]
                ), X("input", te, I), X("keydown", te, (ue) => {
                  ue.key === "Enter" && o(w).includes("/") && (C(y, [], !0), F()), ue.key === "Escape" && C(y, [], !0);
                }), X("click", Se, () => {
                  C(y, [], !0), F();
                }), T(S, k);
              };
              W(ce, (S) => {
                o(se).key === "spaces" && S(je);
              });
            }
            T(Bt, Rt);
          };
          W(Et, (Bt) => {
            o(s) === o(se).key && Bt(Mt);
          });
        }
        z(() => {
          ht = Be(Ze, 1, "section-toggle svelte-5hsmvk", null, ht, { expanded: o(s) === o(se).key }), re(vt, o(se).label), re(xt, o(se).key === "spaces" ? o(se).items.length + o(v).length : o(se).items.length), jt = Be(Ut, 0, "section-chevron svelte-5hsmvk", null, jt, { expanded: o(s) === o(se).key });
        }), X("click", Ze, () => R(o(se).key)), T(Me, ze);
      }), T(Y, J);
    };
    W(It, (Y) => {
      o(l) || Y(ft);
    });
  }
  var wt = L(It, 2);
  {
    var Nt = (Y) => {
      var J = Wc();
      X("mousedown", J, f), T(Y, J);
    };
    W(wt, (Y) => {
      o(l) || Y(Nt);
    });
  }
  z(() => {
    ut = Be(Ne, 1, "sidebar svelte-5hsmvk", null, ut, { "sidebar-collapsed": o(l) }), Ye(Ne, `width: ${(o(l) ? 40 : o(c)) ?? ""}px; min-width: ${(o(l) ? 40 : o(c)) ?? ""}px;`), Tt = Be(yt, 1, "sidebar-collapse-btn svelte-5hsmvk", null, Tt, { collapsed: o(l) });
  }), X("click", yt, () => C(l, !o(l))), T(e, Ne), rt();
}
lt(["click", "input", "keydown", "mousedown"]);
function Yc(e, t) {
  const n = new Map(e.map((i) => [i.id, 0]));
  for (const i of t)
    n.set(i.to_node_id, (n.get(i.to_node_id) ?? 0) + 1);
  const r = e.filter((i) => n.get(i.id) === 0), a = [];
  for (; r.length; ) {
    const i = r.shift();
    a.push(i);
    for (const s of t.filter((l) => l.from_node_id === i.id)) {
      const l = (n.get(s.to_node_id) ?? 1) - 1;
      n.set(s.to_node_id, l), l === 0 && r.push(e.find((u) => u.id === s.to_node_id));
    }
  }
  return a;
}
function ma(e, t, n) {
  const r = {};
  for (const a of e.inputs) {
    const i = t.find(
      (s) => s.to_node_id === e.id && s.to_port_id === a.id
    );
    i ? r[a.id] = n[i.from_node_id]?.[i.from_port_id] ?? null : r[a.id] = e.data?.[a.id] ?? a.default_value ?? null;
  }
  return r;
}
async function Jc(e) {
  if (e === null) return null;
  if (typeof e == "string" || typeof e == "number" || typeof e == "boolean") return e;
  const t = e;
  if (t.url.startsWith("blob:") || t.url.startsWith("data:"))
    try {
      const n = await fetch(t.url);
      if (!n.ok) throw new Error(`Blob fetch failed: ${n.status}`);
      const r = await n.blob(), a = new FormData();
      a.append("files", r, t.name || "file");
      for (const i of ["/gradio_api/upload", "/upload"]) {
        const s = await fetch(i, { method: "POST", body: a });
        if (s.ok) {
          const l = await s.json();
          return { path: l[0], url: l[0] };
        }
      }
      throw new Error("Upload failed");
    } catch (n) {
      throw console.error("[Executor] File upload error:", n), new Error(`Failed to upload file: ${n instanceof Error ? n.message : n}`);
    }
  return { url: t.url };
}
function di(e, t) {
  if (e == null) return null;
  if (Array.isArray(e))
    return e.length === 0 ? null : di(e[e.length - 1], t);
  if (typeof e == "number" || typeof e == "boolean") return e;
  if (typeof e == "string")
    return t !== "text" && (e.startsWith("http://") || e.startsWith("https://") || e.startsWith("blob:") || e.startsWith("data:")) ? { name: "output", url: e, mime: t === "image" ? "image/png" : t === "audio" ? "audio/wav" : "video/mp4" } : e;
  if (typeof e == "object" && "url" in e) {
    const n = e;
    return {
      name: n.orig_name ?? "output",
      url: n.url,
      mime: n.mime_type ?? "application/octet-stream"
    };
  }
  return String(e);
}
async function Qc(e, t, n, r, a) {
  const { nodes: i, edges: s } = e, l = {};
  for (const v of i.filter((f) => f.kind === "input"))
    l[v.id] = { ...v.data ?? {} };
  const u = Yc(i, s), c = [];
  for (const v of u) {
    const w = s.filter((b) => b.to_node_id === v.id).map((b) => c.findIndex((E) => E.some((p) => p.id === b.from_node_id))).reduce((b, E) => Math.max(b, E), -1) + 1;
    for (; c.length <= w; ) c.push([]);
    c[w].push(v);
  }
  async function h(v) {
    if (!r?.aborted) {
      if (v.kind === "input") {
        t(v.id, "done");
        return;
      }
      if (v.kind === "output") {
        const f = ma(v, s, l), w = v.inputs[0];
        if (w) {
          const b = f[w.id];
          l[v.id] = { [w.id]: b }, n(v.id, w.id, b);
          const E = v.outputs[0];
          E && (l[v.id][E.id] = b);
        }
        t(v.id, "done");
        return;
      }
      if (v.kind === "transform" && v.space_id) {
        t(v.id, "running");
        try {
          const f = ma(v, s, l), w = await Promise.all(v.inputs.map((y) => Jc(f[y.id]))), b = v.endpoint ?? "/predict";
          if (console.log(`[Executor] Calling ${v.space_id} endpoint="${b}" inputs:`, JSON.stringify(f), "args:", JSON.stringify(w), "node.data:", JSON.stringify(v.data)), !a)
            throw new Error("Server call function not available");
          const E = await Promise.race([
            a(v.space_id, b, JSON.stringify(w)),
            new Promise(
              (y, m) => setTimeout(() => m(new Error("Request timed out — Space may be overloaded")), 3e5)
            )
          ]), p = JSON.parse(E);
          if (p && typeof p == "object" && "error" in p) {
            const y = p.title, m = p.suggestion, O = p.error_type;
            let I = y ? `${y}: ${p.error}` : p.error;
            m && (I += ` — ${m}`);
            const B = new Error(I);
            throw B.errorType = O, B;
          }
          l[v.id] = {};
          const g = Array.isArray(p) ? p : [p];
          v.outputs.forEach((y, m) => {
            const O = di(g[m] ?? null, y.type);
            l[v.id][y.id] = O, n(v.id, y.id, O);
          }), t(v.id, "done");
        } catch (f) {
          const w = f instanceof Error ? f.message : String(f), b = f?.errorType;
          t(v.id, "error", w, b), l[v.id] = {}, v.outputs.forEach((E) => {
            l[v.id][E.id] = null;
          });
        }
      }
    }
  }
  for (const v of c) {
    if (r?.aborted) break;
    await Promise.all(v.map(h));
  }
}
var Kc = /* @__PURE__ */ N('<input class="name-input svelte-16twpg4"/>'), $c = /* @__PURE__ */ N('<button class="name-btn svelte-16twpg4"><span class="name-text svelte-16twpg4"> </span> <span class="name-edit-icon svelte-16twpg4">&#x270E;</span></button>'), ed = /* @__PURE__ */ N('<button class="toolbar-dropdown-item svelte-16twpg4"><span class="toolbar-dropdown-name svelte-16twpg4"> </span> <span class="toolbar-dropdown-desc svelte-16twpg4"> </span></button>'), td = /* @__PURE__ */ N('<div class="toolbar-dropdown svelte-16twpg4"></div>'), nd = /* @__PURE__ */ N('<button class="run-btn stop svelte-16twpg4"><span class="run-icon svelte-16twpg4">&#x25A0;</span> Stop</button>'), rd = /* @__PURE__ */ N('<button class="run-btn svelte-16twpg4"><span class="run-icon svelte-16twpg4">&#x25B6;</span> Run</button>'), ad = /* @__PURE__ */ N('<div class="run-overlay svelte-16twpg4"></div>'), id = /* @__PURE__ */ N('<button class="template-card svelte-16twpg4"><span class="template-name svelte-16twpg4"> </span> <span class="template-desc svelte-16twpg4"> </span></button>'), od = /* @__PURE__ */ N('<div class="empty-state svelte-16twpg4"><div class="empty-title svelte-16twpg4">Start building</div> <div class="empty-hint svelte-16twpg4">Drag components from the sidebar, or try a template</div> <div class="template-grid svelte-16twpg4"></div></div>'), sd = /* @__PURE__ */ N('<div class="shortcuts-panel svelte-16twpg4"><div class="shortcuts-title svelte-16twpg4">Keyboard shortcuts</div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Cmd+Enter</kbd> <span>Run workflow</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Cmd+S</kbd> <span>Export JSON</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Cmd+D</kbd> <span>Duplicate node</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Cmd+1</kbd> <span>Zoom to fit</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Cmd+0</kbd> <span>Reset zoom</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Delete</kbd> <span>Remove node</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Escape</kbd> <span>Deselect</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Scroll</kbd> <span>Zoom</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Drag canvas</kbd> <span>Pan</span></div> <div class="shortcut-row svelte-16twpg4"><kbd class="svelte-16twpg4">Double-click</kbd> <span>Rename node</span></div></div>'), ld = /* @__PURE__ */ N('<div class="connection-badge svelte-16twpg4"> </div>'), ud = /* @__PURE__ */ N("<div> </div>"), cd = /* @__PURE__ */ N('<div class="wf-toast-stack svelte-16twpg4"></div>'), dd = /* @__PURE__ */ N('<div class="workflow-root svelte-16twpg4"><div class="toolbar svelte-16twpg4"><div class="toolbar-left svelte-16twpg4"><!> <span class="toolbar-stat svelte-16twpg4"> </span></div> <div class="toolbar-right svelte-16twpg4"><form><input class="toolbar-token-input svelte-16twpg4" type="password" placeholder="Paste HF token (hf_...)" title="HuggingFace token for GPU access"/></form> <div class="toolbar-dropdown-wrap svelte-16twpg4"><button class="tool-btn svelte-16twpg4">Templates</button> <!></div> <button class="tool-btn svelte-16twpg4" title="Export workflow.json (Cmd+S)">Export</button> <button class="tool-btn svelte-16twpg4" title="Import workflow.json">Import</button> <div class="toolbar-divider svelte-16twpg4"></div> <button class="tool-btn svelte-16twpg4" title="Auto-arrange nodes">Layout</button> <button class="tool-btn svelte-16twpg4">Clear</button> <div class="toolbar-divider svelte-16twpg4"></div> <!></div></div> <div class="editor svelte-16twpg4"><!> <div role="application" tabindex="0"><div class="canvas-transform svelte-16twpg4"><!> <!></div> <!> <!> <div class="zoom-controls svelte-16twpg4"><button class="zoom-ctrl-btn svelte-16twpg4" title="Keyboard shortcuts">?</button> <button class="zoom-ctrl-btn svelte-16twpg4" title="Fit all (Cmd+1)">&#x2922;</button> <button class="zoom-ctrl-btn svelte-16twpg4">−</button> <button class="zoom-btn svelte-16twpg4"> </button> <button class="zoom-ctrl-btn svelte-16twpg4">+</button></div> <!> <!></div></div> <!></div>');
function fd(e, t) {
  nt(t, !0);
  const n = () => La(tt, "$workflow", r), [r, a] = Pa();
  var i = this && this.__awaiter || function(d, x, j, M) {
    function D(Q) {
      return Q instanceof j ? Q : new j(function($) {
        $(Q);
      });
    }
    return new (j || (j = Promise))(function(Q, $) {
      function oe(ie) {
        try {
          fe(M.next(ie));
        } catch (we) {
          $(we);
        }
      }
      function ae(ie) {
        try {
          fe(M.throw(ie));
        } catch (we) {
          $(we);
        }
      }
      function fe(ie) {
        ie.done ? Q(ie.value) : D(ie.value).then(oe, ae);
      }
      fe((M = M.apply(d, x || [])).next());
    });
  }, s = this && this.__rest || function(d, x) {
    var j = {};
    for (var M in d) Object.prototype.hasOwnProperty.call(d, M) && x.indexOf(M) < 0 && (j[M] = d[M]);
    if (d != null && typeof Object.getOwnPropertySymbols == "function") for (var D = 0, M = Object.getOwnPropertySymbols(d); D < M.length; D++)
      x.indexOf(M[D]) < 0 && Object.prototype.propertyIsEnumerable.call(d, M[D]) && (j[M[D]] = d[M[D]]);
    return j;
  }, l;
  let u = P(t, "server", 19, () => ({})), c = he(At(typeof localStorage < "u" && (l = localStorage.getItem("hf_token")) !== null && l !== void 0 ? l : ""));
  function h(d) {
    C(c, d.trim(), !0), typeof localStorage < "u" && (o(c) ? localStorage.setItem("hf_token", o(c)) : localStorage.removeItem("hf_token"));
  }
  const v = [
    {
      name: "not-lain/background-removal",
      desc: "Image → background removal → clean image",
      build: () => ({
        version: "1",
        name: "not-lain/background-removal",
        nodes: [
          {
            id: "t1",
            kind: "input",
            label: "Image",
            source: "local",
            inputs: [],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 80,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          },
          {
            id: "t2",
            kind: "transform",
            label: "Remove background",
            source: "space",
            space_id: "not-lain/background-removal",
            endpoint: "/image",
            inputs: [{ id: "in", label: "Image", type: "image", required: !0 }],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 420,
            y: 120,
            width: 200,
            height: 90,
            data: {}
          },
          {
            id: "t3",
            kind: "output",
            label: "Image",
            source: "local",
            inputs: [{ id: "in", label: "Image", type: "image" }],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 740,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          }
        ],
        edges: [
          {
            id: "e1",
            from_node_id: "t1",
            from_port_id: "out",
            to_node_id: "t2",
            to_port_id: "in",
            type: "image"
          },
          {
            id: "e2",
            from_node_id: "t2",
            from_port_id: "out",
            to_node_id: "t3",
            to_port_id: "in",
            type: "image"
          }
        ]
      })
    },
    {
      name: "black-forest-labs/FLUX.1-schnell",
      desc: "Prompt → FLUX → generated image",
      build: () => ({
        version: "1",
        name: "black-forest-labs/FLUX.1-schnell",
        nodes: [
          {
            id: "t1",
            kind: "input",
            label: "Textbox",
            source: "local",
            inputs: [],
            outputs: [{ id: "out", label: "Text", type: "text" }],
            x: 80,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          },
          {
            id: "t2",
            kind: "transform",
            label: "Generate image",
            source: "space",
            space_id: "black-forest-labs/FLUX.1-schnell",
            inputs: [{ id: "in", label: "Prompt", type: "text", required: !0 }],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 420,
            y: 120,
            width: 200,
            height: 90,
            data: {}
          },
          {
            id: "t3",
            kind: "output",
            label: "Image",
            source: "local",
            inputs: [{ id: "in", label: "Image", type: "image" }],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 740,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          }
        ],
        edges: [
          {
            id: "e1",
            from_node_id: "t1",
            from_port_id: "out",
            to_node_id: "t2",
            to_port_id: "in",
            type: "text"
          },
          {
            id: "e2",
            from_node_id: "t2",
            from_port_id: "out",
            to_node_id: "t3",
            to_port_id: "in",
            type: "image"
          }
        ]
      })
    },
    {
      name: "hf-audio/whisper-large-v3-turbo",
      desc: "Audio → Whisper → transcript text",
      build: () => ({
        version: "1",
        name: "hf-audio/whisper-large-v3-turbo",
        nodes: [
          {
            id: "t1",
            kind: "input",
            label: "Audio",
            source: "local",
            inputs: [],
            outputs: [{ id: "out", label: "Audio", type: "audio" }],
            x: 80,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          },
          {
            id: "t2",
            kind: "transform",
            label: "Transcribe",
            source: "space",
            space_id: "hf-audio/whisper-large-v3-turbo",
            inputs: [{ id: "in", label: "Audio", type: "audio", required: !0 }],
            outputs: [{ id: "out", label: "Text", type: "text" }],
            x: 420,
            y: 120,
            width: 200,
            height: 90,
            data: {}
          },
          {
            id: "t3",
            kind: "output",
            label: "Textbox",
            source: "local",
            inputs: [{ id: "in", label: "Text", type: "text" }],
            outputs: [{ id: "out", label: "Text", type: "text" }],
            x: 740,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          }
        ],
        edges: [
          {
            id: "e1",
            from_node_id: "t1",
            from_port_id: "out",
            to_node_id: "t2",
            to_port_id: "in",
            type: "audio"
          },
          {
            id: "e2",
            from_node_id: "t2",
            from_port_id: "out",
            to_node_id: "t3",
            to_port_id: "in",
            type: "text"
          }
        ]
      })
    },
    {
      name: "vikhyatk/moondream1",
      desc: "Image → caption → text description",
      build: () => ({
        version: "1",
        name: "vikhyatk/moondream1",
        nodes: [
          {
            id: "t1",
            kind: "input",
            label: "Image",
            source: "local",
            inputs: [],
            outputs: [{ id: "out", label: "Image", type: "image" }],
            x: 80,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          },
          {
            id: "t2",
            kind: "transform",
            label: "Describe image",
            source: "space",
            space_id: "vikhyatk/moondream1",
            inputs: [{ id: "in", label: "Image", type: "image", required: !0 }],
            outputs: [{ id: "out", label: "Caption", type: "text" }],
            x: 420,
            y: 120,
            width: 200,
            height: 90,
            data: {}
          },
          {
            id: "t3",
            kind: "output",
            label: "Textbox",
            source: "local",
            inputs: [{ id: "in", label: "Text", type: "text" }],
            outputs: [{ id: "out", label: "Text", type: "text" }],
            x: 740,
            y: 120,
            width: 220,
            height: 160,
            data: {}
          }
        ],
        edges: [
          {
            id: "e1",
            from_node_id: "t1",
            from_port_id: "out",
            to_node_id: "t2",
            to_port_id: "in",
            type: "image"
          },
          {
            id: "e2",
            from_node_id: "t2",
            from_port_id: "out",
            to_node_id: "t3",
            to_port_id: "in",
            type: "text"
          }
        ]
      })
    }
  ];
  function f(d) {
    return i(this, void 0, void 0, function* () {
      Me(n().nodes);
      const x = d.build();
      tt.set(x), Et(), q(`Loading "${d.name}"...`);
      const j = x.nodes.filter((Q) => Q.source === "space" && Q.space_id), M = yield Promise.allSettled(j.map((Q) => i(this, void 0, void 0, function* () {
        const $ = yield xr(Q.space_id);
        return { nodeId: Q.id, apiInfo: $ };
      })));
      tt.update((Q) => Object.assign(Object.assign({}, Q), {
        nodes: Q.nodes.map(($) => {
          const oe = M.find((ae) => ae.status === "fulfilled" && ae.value.nodeId === $.id);
          if (oe && oe.status === "fulfilled") {
            const { apiInfo: ae } = oe.value;
            return Object.assign(Object.assign({}, $), {
              inputs: ae.inputs,
              outputs: ae.outputs,
              endpoint: ae.endpoint,
              width: ae.width
            });
          }
          return $;
        }),
        // Remap edges to use new port IDs
        edges: Q.edges.map(($) => {
          const oe = M.find((ie) => ie.status === "fulfilled" && ie.value.nodeId === $.from_node_id), ae = M.find((ie) => ie.status === "fulfilled" && ie.value.nodeId === $.to_node_id);
          let fe = Object.assign({}, $);
          if (oe && oe.status === "fulfilled") {
            const ie = oe.value.apiInfo.outputs[0];
            ie && fe.from_port_id === "out" && (fe = Object.assign(Object.assign({}, fe), { from_port_id: ie.id }));
          }
          if (ae && ae.status === "fulfilled") {
            const ie = ae.value.apiInfo.inputs[0];
            ie && fe.to_port_id === "in" && (fe = Object.assign(Object.assign({}, fe), { to_port_id: ie.id }));
          }
          return fe;
        })
      })), M.filter((Q) => Q.status === "rejected").length > 0 ? q("Some Spaces could not be reached", 5e3, "warning") : q(`Loaded "${d.name}"`, 3e3, "success");
    });
  }
  let w, b = he(null), E = he(At({ x: 0, y: 0 })), p = he(!1), g = null, y = he(At({})), m = he(At({})), O = he(!1), I = he(null), B = he(!1), Z = he(!1), R = he(At([])), F = 0;
  function q(d, x = 3e3, j = "info") {
    const M = ++F;
    C(R, [...o(R), { id: M, message: d, type: j }].slice(-3), !0), x > 0 && setTimeout(
      () => {
        C(R, o(R).filter((D) => D.id !== M), !0);
      },
      x
    );
  }
  let me = he(0), Ue = he(0), be = he(1), Ne = he(!1), ut = { x: 0, y: 0, panX: 0, panY: 0 }, _t, yt = ve(() => n().nodes.length), Tt = ve(() => n().nodes.some((d) => d.kind === "transform")), It = ve(() => n().edges.length);
  function ft(d) {
    const x = w.getBoundingClientRect();
    return {
      x: (d.clientX - x.left - o(me)) / o(be),
      y: (d.clientY - x.top - o(Ue)) / o(be)
    };
  }
  function wt(d, x, j, M) {
    C(b, Object.assign({ from_node_id: d, from_port_id: x, type: j }, ft(M)), !0);
  }
  function Nt(d, x, j) {
    if (!o(b)) return;
    if (!Y(o(b).type, j)) {
      C(b, null);
      return;
    }
    sr({
      from_node_id: o(b).from_node_id,
      from_port_id: o(b).from_port_id,
      to_node_id: d,
      to_port_id: x,
      type: o(b).type
    }), C(b, null);
    const M = document.querySelector(`[data-port-id="${d}:${x}:input"]`);
    M && (M.classList.add("port-snap"), setTimeout(() => M.classList.remove("port-snap"), 400));
  }
  function Y(d, x) {
    return d === "any" || x === "any" || d === x;
  }
  function J(d, x, j) {
    return i(this, void 0, void 0, function* () {
      if (d.source === "space" && d.space_id && d.inputs.length === 0) {
        q(`Connecting to ${d.space_id}...`);
        try {
          const M = yield xr(d.space_id);
          d.inputs = M.inputs, d.outputs = M.outputs, d.endpoint = M.endpoint, d.width = M.width;
        } catch (M) {
          q(M instanceof Error ? M.message : "Failed to connect to Space", 5e3, "error");
          return;
        }
      }
      if (x === void 0 || j === void 0) {
        const M = n().nodes;
        x = M.length > 0 ? Math.max(...M.map((D) => D.x + D.width)) + 80 : 200, j = M.length > 0 ? M[M.length - 1].y : 150;
      }
      An(d, x, j);
    });
  }
  function ne(d) {
    return i(this, void 0, void 0, function* () {
      var x;
      d.preventDefault();
      const j = (x = d.dataTransfer) === null || x === void 0 ? void 0 : x.getData("node-template");
      if (!j) return;
      const M = JSON.parse(j), D = w.getBoundingClientRect(), Q = (d.clientX - D.left - o(me)) / o(be) - 100, $ = (d.clientY - D.top - o(Ue)) / o(be) - 45;
      yield J(M, Q, $);
    });
  }
  function Me(d) {
    var x, j;
    for (const M of d)
      for (const D of Object.values((x = M.data) !== null && x !== void 0 ? x : {}))
        D && typeof D == "object" && "url" in D && (!((j = D.url) === null || j === void 0) && j.startsWith("blob:")) && URL.revokeObjectURL(D.url);
  }
  function se() {
    n().nodes.length !== 0 && confirm("Clear all nodes and edges?") && (Me(n().nodes), tt.set({ version: "1", name: n().name, nodes: [], edges: [] }));
  }
  function ze() {
    var d;
    const x = Ze(n().nodes, n().edges), j = n().edges, M = /* @__PURE__ */ new Map();
    for (const fe of x) {
      const ie = j.filter((we) => we.to_node_id === fe.id).map((we) => {
        var mt;
        return (mt = M.get(we.from_node_id)) !== null && mt !== void 0 ? mt : 0;
      }).reduce((we, mt) => Math.max(we, mt + 1), 0);
      M.set(fe.id, ie);
    }
    const D = /* @__PURE__ */ new Map();
    for (const fe of x) {
      const ie = (d = M.get(fe.id)) !== null && d !== void 0 ? d : 0;
      D.has(ie) || D.set(ie, []), D.get(ie).push(fe);
    }
    const Q = 30, $ = 80, oe = [];
    let ae = 80;
    for (const [fe, ie] of [...D.entries()].sort((we, mt) => we[0] - mt[0])) {
      let we = 80, mt = 0;
      for (const Zn of ie)
        oe.push(Object.assign(Object.assign({}, Zn), { x: ae, y: we })), we += Zn.height + Q, mt = Math.max(mt, Zn.width);
      ae += mt + $;
    }
    tt.update((fe) => Object.assign(Object.assign({}, fe), { nodes: oe }));
  }
  function Ze(d, x) {
    var j, M;
    const D = new Map(d.map((oe) => [oe.id, 0]));
    for (const oe of x) D.set(oe.to_node_id, ((j = D.get(oe.to_node_id)) !== null && j !== void 0 ? j : 0) + 1);
    const Q = d.filter((oe) => D.get(oe.id) === 0), $ = [];
    for (; Q.length; ) {
      const oe = Q.shift();
      $.push(oe);
      for (const ae of x.filter((fe) => fe.from_node_id === oe.id)) {
        const fe = ((M = D.get(ae.to_node_id)) !== null && M !== void 0 ? M : 1) - 1;
        D.set(ae.to_node_id, fe), fe === 0 && Q.push(d.find((ie) => ie.id === ae.to_node_id));
      }
    }
    return $;
  }
  function ht() {
    return i(this, void 0, void 0, function* () {
      if (o(p)) return;
      C(p, !0), C(y, {}, !0), C(m, {}, !0), g = new AbortController();
      const d = n().nodes.some((D) => D.source === "space" && D.space_id);
      let x = !1;
      if (d) {
        if (o(c))
          x = !0;
        else if (!(u() === null || u() === void 0) && u().get_token)
          try {
            (yield u().get_token()) && (x = !0);
          } catch {
          }
        x || q("Running as guest — GPU Spaces may hit quota limits. Add token in settings for your own compute.", 5e3, "warning");
      }
      const j = !(u() === null || u() === void 0) && u().call_space ? (D, Q, $) => i(this, void 0, void 0, function* () {
        return u().call_space([D, Q, $, o(c) || ""]);
      }) : void 0;
      yield Qc(
        n(),
        (D, Q, $, oe) => {
          var ae, fe;
          if (C(y, Object.assign(Object.assign({}, o(y)), { [D]: Q }), !0), $) {
            C(m, Object.assign(Object.assign({}, o(m)), { [D]: $ }), !0);
            const ie = n().nodes.find((mt) => mt.id === D), we = (fe = (ae = ie?.label) !== null && ae !== void 0 ? ae : ie?.space_id) !== null && fe !== void 0 ? fe : "Node";
            oe === "quota" || oe === "gpu" ? q(`${we}: ${$}`, 0, "error") : q(`${we}: ${$}`, 5e3, "error");
          }
        },
        (D, Q, $) => {
          da(D, Q, $);
        },
        g.signal,
        j
      ), C(p, !1), g = null, Object.values(o(y)).some((D) => D === "error") ? q("Workflow finished with errors", 5e3, "error") : q("Workflow complete", 3e3, "success"), setTimeout(
        () => {
          C(y, Object.fromEntries(Object.entries(o(y)).filter(([D, Q]) => Q === "error")), !0);
        },
        3e3
      );
    });
  }
  function Ct() {
    g?.abort(), C(p, !1), g = null, C(y, Object.fromEntries(Object.entries(o(y)).map(([d, x]) => [d, x === "running" ? "idle" : x])), !0), q("Stopped", 3e3, "warning");
  }
  function vt(d) {
    const x = d.target;
    o(B) && !x?.closest(".toolbar-dropdown-wrap") && C(B, !1), o(Z) && !x?.closest(".shortcuts-panel") && !x?.closest(".zoom-controls") && C(Z, !1);
  }
  function at(d) {
    d.preventDefault();
    const x = w.getBoundingClientRect(), j = d.clientX - x.left, M = d.clientY - x.top, D = 1 + Math.min(Math.abs(d.deltaY) * 1e-3, 0.05), Q = d.deltaY > 0 ? 1 / D : D, $ = Math.min(Math.max(o(be) * Q, 0.15), 4), oe = $ / o(be);
    C(me, j - (j - o(me)) * oe), C(Ue, M - (M - o(Ue)) * oe), C(be, $, !0);
  }
  function xt(d) {
    (d.button === 1 || d.button === 0 && d.target === w) && (d.preventDefault(), C(I, null), C(Ne, !0), ut = {
      x: d.clientX,
      y: d.clientY,
      panX: o(me),
      panY: o(Ue)
    });
  }
  function Ut(d) {
    if (o(Ne) && (C(me, ut.panX + (d.clientX - ut.x)), C(Ue, ut.panY + (d.clientY - ut.y))), o(b)) {
      C(b, Object.assign(Object.assign({}, o(b)), ft(d)), !0);
      const x = w.getBoundingClientRect();
      C(E, { x: d.clientX - x.left, y: d.clientY - x.top }, !0);
    }
  }
  function jt(d) {
    C(Ne, !1), C(b, null);
  }
  function Et() {
    C(me, 0), C(Ue, 0), C(be, 1);
  }
  function Mt() {
    const d = n().nodes;
    if (d.length === 0) {
      Et();
      return;
    }
    const x = 60, j = Math.min(...d.map((we) => we.x)), M = Math.min(...d.map((we) => we.y)), D = Math.max(...d.map((we) => we.x + we.width)), Q = Math.max(...d.map((we) => we.y + we.height)), $ = D - j + x * 2, oe = Q - M + x * 2;
    if (!w) {
      Et();
      return;
    }
    const ae = w.getBoundingClientRect(), fe = ae.width / $, ie = ae.height / oe;
    C(be, Math.min(Math.max(Math.min(fe, ie), 0.15), 2), !0), C(me, (ae.width - $ * o(be)) / 2 - (j - x) * o(be)), C(Ue, (ae.height - oe * o(be)) / 2 - (M - x) * o(be));
  }
  function Bt(d) {
    C(I, d, !0);
  }
  function Rt(d) {
    const x = n().nodes.find(($) => $.id === d);
    if (!x) return;
    const { id: j, data: M } = x, D = s(x, ["id", "data"]), Q = An(D, x.x + 40, x.y + 40);
    C(I, Q, !0);
  }
  function K(d) {
    var x;
    if (d.key === "s" && (d.metaKey || d.ctrlKey)) {
      d.preventDefault(), ce();
      return;
    }
    if (d.key === "Enter" && (d.metaKey || d.ctrlKey) && !o(p) && o(Tt)) {
      d.preventDefault(), ht();
      return;
    }
    const j = (x = d.target) === null || x === void 0 ? void 0 : x.tagName;
    if (!(j === "INPUT" || j === "TEXTAREA" || j === "SELECT")) {
      if ((d.key === "Delete" || d.key === "Backspace") && o(I)) {
        d.preventDefault();
        const M = o(I);
        C(I, null), requestAnimationFrame(() => ca(M));
      }
      d.key === "d" && (d.metaKey || d.ctrlKey) && o(I) && (d.preventDefault(), Rt(o(I))), d.key === "1" && (d.metaKey || d.ctrlKey) && (d.preventDefault(), Mt()), d.key === "0" && (d.metaKey || d.ctrlKey) && (d.preventDefault(), Et()), d.key === "Escape" && (C(I, null), C(b, null));
    }
  }
  let G = ve(() => () => {
    const d = /* @__PURE__ */ new Set();
    for (const x of n().edges)
      d.add(`${x.from_node_id}:${x.from_port_id}:output`), d.add(`${x.to_node_id}:${x.to_port_id}:input`);
    return d;
  });
  function _e(d, x, j, M) {
    var D, Q;
    const $ = n().nodes.find((ae) => ae.id === d);
    if (!$) return;
    const oe = j === "any" ? "text" : j;
    if (M === "input") {
      const ae = (D = Dt.inputs.find((ie) => {
        var we;
        return ((we = ie.outputs[0]) === null || we === void 0 ? void 0 : we.type) === oe;
      })) !== null && D !== void 0 ? D : Dt.inputs[0], fe = An(ae, $.x - ae.width - 80, $.y);
      sr({
        from_node_id: fe,
        from_port_id: ae.outputs[0].id,
        to_node_id: d,
        to_port_id: x,
        type: oe
      });
    } else {
      const ae = (Q = Dt.outputs.find((ie) => {
        var we;
        return ((we = ie.inputs[0]) === null || we === void 0 ? void 0 : we.type) === oe;
      })) !== null && Q !== void 0 ? Q : Dt.outputs[0], fe = An(ae, $.x + $.width + 80, $.y);
      sr({
        from_node_id: d,
        from_port_id: x,
        to_node_id: fe,
        to_port_id: ae.inputs[0].id,
        type: oe
      });
    }
  }
  function ce() {
    const d = JSON.stringify(n(), null, 2), x = new Blob([d], { type: "application/json" }), j = URL.createObjectURL(x), M = document.createElement("a");
    M.href = j, M.download = `${n().name.replace(/[^a-zA-Z0-9_-]/g, "_")}.workflow.json`, M.click(), URL.revokeObjectURL(j), q("Exported workflow.json");
  }
  function je() {
    const d = document.createElement("input");
    d.type = "file", d.accept = ".json", d.onchange = () => i(this, void 0, void 0, function* () {
      var x;
      const j = (x = d.files) === null || x === void 0 ? void 0 : x[0];
      if (j)
        try {
          const M = yield j.text(), D = JSON.parse(M);
          D.nodes && D.edges && (Me(n().nodes), D.nodes = D.nodes.map((Q) => {
            var $;
            return Object.assign(Object.assign({}, Q), { data: ($ = Q.data) !== null && $ !== void 0 ? $ : {} });
          }), tt.set(D), q("Imported workflow"));
        } catch {
        }
    }), d.click();
  }
  function S(d) {
    tt.update((x) => Object.assign(Object.assign({}, x), { name: d })), C(O, !1);
  }
  var k = dd(), _ = A(k), V = A(_), ee = A(V);
  {
    var te = (d) => {
      var x = Kc();
      Pt(x, (j) => _t = j, () => _t), z(() => qt(x, n().name)), Te("blur", x, (j) => S(j.currentTarget.value)), X("keydown", x, (j) => {
        j.key === "Enter" && S(j.currentTarget.value), j.key === "Escape" && C(O, !1);
      }), T(d, x);
    }, Se = (d) => {
      var x = $c(), j = A(x), M = A(j);
      z(() => re(M, n().name)), X("click", x, () => {
        C(O, !0), requestAnimationFrame(() => _t?.focus());
      }), T(d, x);
    };
    W(ee, (d) => {
      o(O) ? d(te) : d(Se, -1);
    });
  }
  var pe = L(ee, 2), U = A(pe), Oe = L(V, 2), le = A(Oe), Ce = A(le), Ae = L(le, 2), de = A(Ae), Ve = L(de, 2);
  {
    var ue = (d) => {
      var x = td();
      it(x, 21, () => v, kt, (j, M) => {
        var D = ed(), Q = A(D), $ = A(Q), oe = L(Q, 2), ae = A(oe);
        z(() => {
          re($, o(M).name), re(ae, o(M).desc);
        }), X("click", D, () => {
          f(o(M)), C(B, !1);
        }), T(j, D);
      }), T(d, x);
    };
    W(Ve, (d) => {
      o(B) && d(ue);
    });
  }
  var ye = L(Ae, 2), qe = L(ye, 2), Ie = L(qe, 4), De = L(Ie, 2), We = L(De, 4);
  {
    var et = (d) => {
      var x = nd();
      X("click", x, Ct), T(d, x);
    }, Je = (d) => {
      var x = rd();
      z(() => x.disabled = !o(Tt)), X("click", x, ht), T(d, x);
    };
    W(We, (d) => {
      o(p) ? d(et) : d(Je, -1);
    });
  }
  var ge = L(_, 2), Ee = A(ge);
  Zc(Ee, { onadd: (d) => J(d) });
  var Le = L(Ee, 2);
  let Qe;
  var pt = A(Le), Ht = A(pt);
  it(Ht, 1, () => n().nodes, (d) => d.id, (d, x) => {
    {
      let j = ve(() => o(G)()), M = ve(() => o(y)[o(x).id] ?? "idle"), D = ve(() => o(m)[o(x).id] ?? ""), Q = ve(() => o(I) === o(x).id);
      xc(d, {
        get node() {
          return o(x);
        },
        get pending() {
          return o(b);
        },
        onstartconnection: wt,
        oncompleteconnection: Nt,
        get onmove() {
          return xl;
        },
        get ondatachange() {
          return da;
        },
        get onremove() {
          return ca;
        },
        onautoconnect: _e,
        get connectedPorts() {
          return o(j);
        },
        get status() {
          return o(M);
        },
        get error() {
          return o(D);
        },
        get zoom() {
          return o(be);
        },
        get selected() {
          return o(Q);
        },
        onselect: Bt
      });
    }
  });
  var gt = L(Ht, 2);
  Oc(gt, {
    get pending() {
      return o(b);
    },
    get onremove() {
      return El;
    },
    get zoom() {
      return o(be);
    },
    get panX() {
      return o(me);
    },
    get panY() {
      return o(Ue);
    }
  });
  var Ke = L(pt, 2);
  {
    var Ft = (d) => {
      var x = ad();
      T(d, x);
    };
    W(Ke, (d) => {
      o(p) && d(Ft);
    });
  }
  var Kt = L(Ke, 2);
  {
    var Xn = (d) => {
      var x = od(), j = L(A(x), 4);
      it(j, 21, () => v, kt, (M, D) => {
        var Q = id(), $ = A(Q), oe = A($), ae = L($, 2), fe = A(ae);
        z(() => {
          re(oe, o(D).name), re(fe, o(D).desc);
        }), X("click", Q, () => f(o(D))), T(M, Q);
      }), T(d, x);
    };
    W(Kt, (d) => {
      o(yt) === 0 && d(Xn);
    });
  }
  var kn = L(Kt, 2), ct = A(kn), ot = L(ct, 2), dt = L(ot, 2), hn = L(dt, 2), Wn = A(hn), qn = L(hn, 2), Br = L(kn, 2);
  {
    var fi = (d) => {
      var x = sd();
      T(d, x);
    };
    W(Br, (d) => {
      o(Z) && d(fi);
    });
  }
  var hi = L(Br, 2);
  {
    var vi = (d) => {
      var x = ld(), j = A(x);
      z(() => {
        Ye(x, `left: ${o(E).x + 14}px; top: ${o(E).y - 10}px; --badge-color: ${Xe[o(b).type] ?? ""}`), re(j, o(b).type);
      }), T(d, x);
    };
    W(hi, (d) => {
      o(b) && d(vi);
    });
  }
  Pt(Le, (d) => w = d, () => w);
  var pi = L(ge, 2);
  {
    var gi = (d) => {
      var x = cd();
      it(x, 21, () => o(R), (j) => j.id, (j, M) => {
        var D = ud(), Q = A(D);
        z(() => {
          Be(D, 1, `wf-toast wf-toast-${o(M).type ?? ""}`, "svelte-16twpg4"), re(Q, o(M).message);
        }), T(j, D);
      }), T(d, x);
    };
    W(pi, (d) => {
      o(R).length > 0 && d(gi);
    });
  }
  z(
    (d) => {
      re(U, `${o(yt) ?? ""} nodes · ${o(It) ?? ""} edges`), qt(Ce, o(c)), Qe = Be(Le, 1, "canvas svelte-16twpg4", null, Qe, { panning: o(Ne) }), Ye(Le, `--zoom: ${o(be) ?? ""}; --pan-x: ${o(me) ?? ""}px; --pan-y: ${o(Ue) ?? ""}px`), Ye(pt, `transform: translate(${o(me) ?? ""}px, ${o(Ue) ?? ""}px) scale(${o(be) ?? ""})`), re(Wn, `${d ?? ""}%`);
    },
    [() => Math.round(o(be) * 100)]
  ), X("click", k, vt), Te("submit", le, (d) => d.preventDefault()), X("change", Ce, (d) => h(d.currentTarget.value)), X("click", de, () => C(B, !o(B))), X("click", ye, ce), X("click", qe, je), X("click", Ie, ze), X("click", De, se), Te("dragover", Le, (d) => d.preventDefault()), Te("drop", Le, ne), Te("wheel", Le, at), X("mousedown", Le, xt), X("mousemove", Le, Ut), X("mouseup", Le, jt), X("keydown", Le, K), X("click", ct, () => C(Z, !o(Z))), X("click", ot, Mt), X("click", dt, () => {
    C(be, Math.max(0.15, o(be) / 1.2), !0);
  }), X("click", hn, Et), X("click", qn, () => {
    C(be, Math.min(4, o(be) * 1.2), !0);
  }), T(e, k), rt(), a();
}
lt([
  "click",
  "keydown",
  "change",
  "mousedown",
  "mousemove",
  "mouseup"
]);
var hd = /* @__PURE__ */ N('<div class="workflow-fullscreen svelte-r41nsf"><!></div>');
function gd(e, t) {
  nt(t, !0);
  var n, r;
  let a = /* @__PURE__ */ No(t, ["$$slots", "$$events", "$$legacy"]);
  const i = new bl(a);
  let s = ve(() => (r = (n = i.shared) === null || n === void 0 ? void 0 : n.server) !== null && r !== void 0 ? r : {});
  var l = hd(), u = A(l);
  fd(u, {
    get server() {
      return o(s);
    }
  }), T(e, l), rt();
}
export {
  gd as default
};
