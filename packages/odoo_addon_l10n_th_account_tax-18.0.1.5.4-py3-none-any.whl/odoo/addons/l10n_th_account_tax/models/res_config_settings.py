# Copyright 2022 Ecosoft Co., Ltd. (http://ecosoft.co.th)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    customer_tax_invoice_number = fields.Selection(
        related="company_id.customer_tax_invoice_number", readonly=False
    )
    tax_zero_line = fields.Boolean(related="company_id.tax_zero_line", readonly=False)
