"""Neutral shared application core."""
