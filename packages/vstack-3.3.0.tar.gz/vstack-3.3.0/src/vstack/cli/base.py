"""Base command contract for CLI command handlers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from argparse import Namespace
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class CommandContext:
    """Runtime context passed to every CLI command handler."""

    args: Namespace
    install_dir: Path | None
    only: list[str] | None
    excluded_names: dict[str, list[str]] | None = None

    def require_install_dir(self, command_name: str) -> Path:
        """Return install_dir or raise when the command requires one."""
        if self.install_dir is None:
            raise ValueError(f"{command_name} requires install_dir")
        return self.install_dir


class BaseCommand(ABC):
    """Abstract base class for top-level CLI command handlers."""

    @staticmethod
    def _normalize_targeted_names(names: list[str] | None) -> set[str]:
        """Normalize targeted artifact names for force/adopt operations."""
        return {name.strip() for name in names or [] if name.strip()}

    @abstractmethod
    def run(
        self,
        *,
        context: CommandContext,
    ) -> int:
        """Execute the command and return a process-style status code."""
