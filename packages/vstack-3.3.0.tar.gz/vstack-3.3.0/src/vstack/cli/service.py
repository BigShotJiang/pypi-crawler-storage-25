"""Shared coordinator for vstack CLI command handlers.

:class:`CommandService` wires artifact-type generators and manifest access
into the services that individual :class:`~vstack.cli.base.BaseCommand`
subclasses use when executing.  Commands live in their own modules
(``install``, ``verify``, ``uninstall``, ``validate``, ``manifest``,
``status``) and receive a :class:`~vstack.cli.base.CommandContext` at
dispatch time.

The service is type-generic: it iterates over
:data:`~vstack.artifacts.type_config.KNOWN_TYPES` rather than hard-coding
skill-specific or agent-specific logic.  Per-type sub-directories are
derived from
:attr:`~vstack.artifacts.type_config.ArtifactTypeConfig.output_subdir`.
"""

from __future__ import annotations

import sys
from pathlib import Path

from vstack.agents.config import AGENT_TYPE
from vstack.agents.generator import AgentGenerator
from vstack.artifacts.generator import GenericArtifactGenerator
from vstack.cli.constants import KNOWN_TYPES, ArtifactState
from vstack.constants import ARTIFACTS_DOCS_ROOT, VSTACK_DIR_NAME
from vstack.hooks.config import HOOK_TYPE
from vstack.hooks.generator import HookGenerator
from vstack.manifest import CURRENT_MANIFEST_VERSION, ManifestFile, hash_with_algorithm


class CommandService:
    """Coordinate validation, installation, verification, and uninstall flows.

    The class wires artifact-type generators into user-facing CLI operations,
    while keeping per-type behavior in ``ArtifactTypeConfig`` definitions.
    """

    def __init__(
        self,
        templates_root: Path,
        *,
        items_root: str = ARTIFACTS_DOCS_ROOT,
        artifacts_root: str | None = None,
        workflow_stages: list[dict[str, str]] | None = None,
        workflow_mode: str = "agentic",
        hook_default_mode: str = "audit",
        hook_default_log_level: str = "minimal",
        hook_log_retention_days: int = 7,
        hook_log_dir: str = ".vstack/logs",
        hook_mode_overrides: dict[str, str] | None = None,
        hook_log_level_overrides: dict[str, str] | None = None,
        hook_log_name_overrides: dict[str, str] | None = None,
        hook_log_retention_days_overrides: dict[str, int] | None = None,
        disabled_hook_names: list[str] | None = None,
    ) -> None:
        """Create generators for all known artifact families.

        Per-type generator subclasses are used when available so that
        type-specific placeholder injection (e.g. ``{{AGENT_ARTIFACTS_*}}``)
        runs during install without requiring changes to
        :class:`~vstack.artifacts.generator.GenericArtifactGenerator`.

        Args:
            templates_root: Root directory containing the source templates.
            items_root: Root directory for agent work-item paths.  Passed
                through to :class:`~vstack.agents.generator.AgentGenerator`.
                Defaults to :data:`~vstack.constants.ARTIFACTS_DOCS_ROOT`;
                override via ``items.root`` in ``.vstack/config.yaml``.
            artifacts_root: Deprecated alias for ``items_root``.
            workflow_stages: Ordered list of pipeline stage dicts read from
                the ``workflow.stages`` block in ``.vstack/config.yaml``.
                Each dict has ``role`` and ``gate`` string keys, a ``handoffs``
                key containing a list of dicts with ``prompt``, ``agent``, and
                ``label`` string keys, and an optional ``hitl`` string key.
                When ``None`` or empty the generator falls back to v3 behaviour.
            workflow_mode: Workflow execution mode from ``workflow.mode`` in
                ``.vstack/config.yaml``. Supported values: ``manual``,
                ``agentic``, and ``hybrid``.
        """
        self.root = templates_root
        resolved_items_root = artifacts_root or items_root
        self.generators: list[GenericArtifactGenerator] = [
            AgentGenerator(
                templates_root,
                items_root=resolved_items_root,
                workflow_stages=workflow_stages or [],
                workflow_mode=workflow_mode,
            )
            if tc is AGENT_TYPE
            else HookGenerator(
                templates_root,
                default_mode=hook_default_mode,
                default_log_level=hook_default_log_level,
                default_log_retention_days=hook_log_retention_days,
                default_log_dir=hook_log_dir,
                mode_overrides=hook_mode_overrides,
                log_level_overrides=hook_log_level_overrides,
                log_name_overrides=hook_log_name_overrides,
                log_retention_days_overrides=hook_log_retention_days_overrides,
                disabled_names=disabled_hook_names,
            )
            if tc is HOOK_TYPE
            else GenericArtifactGenerator(tc, templates_root)
            for tc in KNOWN_TYPES
        ]

    # ── Shared helpers ───────────────────────────────────────────────────────

    def label(self, path: Path) -> str:
        """Return *path* relative to template root when possible."""
        try:
            return str(path.relative_to(self.root))
        except ValueError:
            return str(path)

    def manifest_for(self, install_dir: Path) -> ManifestFile:
        """Build the manifest accessor for a given install directory.

        For project installs (``install_dir`` named ``.github``), the manifest
        lives in the sibling ``.vstack/`` directory.  For global installs and
        test fixtures that pass arbitrary directories, it falls back to
        ``install_dir`` directly.
        """
        if install_dir.name == ".github":
            return ManifestFile(parent_dir=install_dir.parent / VSTACK_DIR_NAME)
        return ManifestFile(parent_dir=install_dir)

    def gen_for(self, type_name: str) -> GenericArtifactGenerator | None:
        """Return the generator for *type_name*, or ``None`` when unknown."""
        return next((g for g in self.generators if g.config.type_name == type_name), None)

    def artifact_control_state(
        self,
        *,
        out_file: Path,
        existing_entry,
    ) -> tuple[str, str]:
        """Classify ownership and drift state for one installed artifact path."""
        rel_path = self.label(out_file)

        if existing_entry is None:
            if out_file.exists():
                return (
                    ArtifactState.UNTRACKED,
                    f"{rel_path}: file exists but is not tracked by vstack",
                )
            return ArtifactState.ABSENT, f"{rel_path}: file is absent and not tracked by vstack"

        if not out_file.exists():
            return ArtifactState.MISSING, f"{rel_path}: tracked file missing from disk"

        if existing_entry.checksum is None:
            return (
                ArtifactState.MANAGED_LEGACY,
                f"{rel_path}: tracked legacy entry without checksum; treated as managed",
            )

        checksum_algorithm = (existing_entry.checksum_algorithm or "sha256").lower()
        try:
            current_checksum = hash_with_algorithm(
                out_file.read_text(encoding="utf-8"),
                checksum_algorithm,
            )
        except ValueError:
            return (
                ArtifactState.UNKNOWN,
                f"{rel_path}: unsupported checksum algorithm '{checksum_algorithm}' in manifest",
            )
        except OSError as exc:
            return (
                ArtifactState.UNKNOWN,
                f"{rel_path}: could not read file — {exc}",
            )

        if current_checksum == existing_entry.checksum:
            return ArtifactState.MANAGED, f"{rel_path}: checksum matches manifest"

        return ArtifactState.MODIFIED, f"{rel_path}: checksum differs from manifest"

    # ── validate ──────────────────────────────────────────────────────────────

    def validate(self, only: list[str] | None = None) -> int:
        """Render all templates in memory; report unresolved tokens. No files written."""
        from vstack.cli.validate import ValidateCommand

        return ValidateCommand.execute(self, only=only)

    # ── install ───────────────────────────────────────────────────────────────

    def install(
        self,
        install_dir: Path,
        *,
        only: list[str] | None = None,
        force: bool = False,
        force_names: list[str] | None = None,
        adopt_names: list[str] | None = None,
        update: bool = False,
        dry_run: bool = False,
    ) -> int:
        """Generate and install artifacts into install_dir.

        Args:
            install_dir: Workspace ``.github/`` or VS Code user profile install root.
            only:        Optional list of type names to restrict installation.
            force:       Overwrite existing artifacts unconditionally.
            force_names: Overwrite only the named artifacts, even when locally modified.
            adopt_names: Adopt only the named unmanaged artifacts into manifest tracking.
            update:      Install only when a newer version is available.
            dry_run:     Print what would happen without writing any files.
        """
        from vstack.cli.init import InitCommand

        return InitCommand.execute(
            self,
            install_dir,
            only=only,
            force=force,
            force_names=force_names,
            adopt_names=adopt_names,
            update=update,
            dry_run=dry_run,
        )

    # ── verify ────────────────────────────────────────────────────────────────

    def verify(
        self,
        install_dir: Path | None = None,
        *,
        source: bool = True,
        output: bool = True,
        only: list[str] | None = None,
    ) -> int:
        """Check source templates and/or installed output.

        Args:
            install_dir: Workspace ``.github/`` or VS Code user profile install root.
            source:      Verify source templates (metadata, tokens, structure).
            output:      Verify installed output files against the manifest.
            only:        Optional list of type names to restrict verification.
        """
        from vstack.cli.verify import VerifyCommand

        return VerifyCommand.execute(
            self,
            install_dir=install_dir,
            source=source,
            output=output,
            only=only,
        )

    def status(
        self,
        install_dir: Path,
        *,
        only: list[str] | None = None,
        output_format: str = "text",
        verbose: bool = False,
        no_color: bool = False,
    ) -> int:
        """Report which installed artifacts still match the manifest and which do not."""
        from vstack.cli.status import StatusCommand

        return StatusCommand.execute(
            self,
            install_dir=install_dir,
            only=only,
            output_format=output_format,
            verbose=verbose,
            no_color=no_color,
        )

    def manifest_upgrade(self, install_dir: Path, *, backfill: bool = False) -> int:
        """Upgrade a legacy manifest schema to the current schema version."""
        manifest_file = self.manifest_for(install_dir)
        manifest_data = manifest_file.read(allow_legacy=True)

        if manifest_data is None:
            if manifest_file.read_error:
                print(f"ERROR: {manifest_file.read_error}", file=sys.stderr)
                return 1
            print("No manifest found to upgrade.")
            return 1

        needs_upgrade = manifest_data.needs_upgrade()
        if not needs_upgrade and not backfill:
            print(f"Manifest already up to date at schema v{manifest_data.manifest_version}.")
            return 0

        upgraded = manifest_data.upgraded() if needs_upgrade else manifest_data
        backfilled: list[str] = []
        skipped: list[str] = []
        if backfill:
            upgraded, backfilled, skipped = upgraded.with_backfilled_checksums(
                install_dir=install_dir,
            )

        manifest_file.write(upgraded)

        if needs_upgrade:
            print(
                f"Upgraded manifest to schema v{CURRENT_MANIFEST_VERSION}: "
                f"{self.label(manifest_file.path)}"
            )
        else:
            print(f"Manifest schema already current at v{upgraded.manifest_version}.")

        if backfill:
            print(
                f"Backfilled checksums for {len(backfilled)} tracked artifact(s); "
                f"skipped {len(skipped)}."
            )
            for item in skipped:
                print(f"  ! {item}")
        return 0

    # ── uninstall ─────────────────────────────────────────────────────────────

    def uninstall(
        self,
        install_dir: Path,
        *,
        only: list[str] | None = None,
        force: bool = False,
        force_names: list[str] | None = None,
    ) -> int:
        """Remove tracked files whose ownership still matches the manifest."""
        from vstack.cli.uninstall import UninstallCommand

        return UninstallCommand.execute(
            self,
            install_dir,
            only=only,
            force=force,
            force_names=force_names,
        )
