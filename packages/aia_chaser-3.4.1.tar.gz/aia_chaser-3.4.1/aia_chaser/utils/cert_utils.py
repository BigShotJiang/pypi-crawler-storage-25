from __future__ import annotations

import collections
import contextlib
import ssl
import tempfile
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, NamedTuple

from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.serialization import Encoding
from cryptography.utils import CryptographyDeprecationWarning

from aia_chaser.exceptions import AiaChaserWarning


if TYPE_CHECKING:
    from collections.abc import Iterator, Mapping, Sequence

    from cryptography.hazmat.primitives import hashes


def certificates_to_der(certificates: list[x509.Certificate]) -> bytes:
    """DER representation of the given certificates.

    Returns:
        A bytes object with the DER content of `certificates`.
    """
    return b"".join(cert.public_bytes(Encoding.DER) for cert in certificates)


def certificates_to_pem(certificates: list[x509.Certificate]) -> str:
    """PEM representation of the given certificates.

    Returns:
        A string with the PEM content of `certificates`.
    """
    return "\n".join(
        cert.public_bytes(Encoding.PEM).decode("ascii") for cert in certificates
    )


@contextlib.contextmanager
def temp_pem_file(certificates: Sequence[x509.Certificate]) -> Iterator[Path]:
    """Context manager that writes certificates to a temporary PEM file.

    Creates a temporary directory containing a PEM file with the provided
    certificates. The file path is yielded for use with libraries that
    require a file path (e.g., pycurl).

    Note:
        This uses a TemporaryDirectory instead of NamedTemporaryFile because
        on Windows, a file opened by one process cannot be accessed by another
        process. By writing to a file in a temp directory and closing it before
        yielding, we ensure cross-platform compatibility.

    Args:
        certificates: Sequence of certificates to write to the PEM file.

    Yields:
        Path to the temporary PEM file.

    Example:
        ```python
        chaser = AiaChaser()
        ca_chain = chaser.fetch_ca_chain_for_url(url)
        with temp_pem_file(ca_chain) as pem_path:
            response = requests.get(url, verify=str(pem_path))
        ```
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        pem_path = Path(tmpdir) / "ca_chain.pem"
        pem_path.write_text(certificates_to_pem(list(certificates)))
        yield pem_path


def _try_load_der_certificate(der: bytes) -> x509.Certificate | None:
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", CryptographyDeprecationWarning)
            return x509.load_der_x509_certificate(der)
    except Exception as e:  # noqa: BLE001
        warnings.warn(
            f"skipping trust-store certificate that failed to parse: {e}",
            category=AiaChaserWarning,
            stacklevel=3,
        )
        return None


def load_ssl_ca_certificates(
    context: ssl.SSLContext | None = None,
    *,
    force_load: bool = True,
) -> list[x509.Certificate]:
    """Load CA certificates available to Python's `ssl`.

    Args:
        context: The SSL context used to get the default certificates.
            If not provided a default context is created with
            `ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)`.
        force_load: Forcefully load default certificates into the SSL
            context. Certificates in CA path directory are not loaded
            unless they have been used at leas one by the SSL context.

            For more information see
            [`force_load_default_verify_certificates`][aia_chaser.utils.cert_utils.force_load_default_verify_certificates].

    Returns:
        A list with the CA certificates from `context`.
    """
    context = context or ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    if force_load:
        force_load_default_verify_certificates(context)

    # Load trusted certificates
    trusted_der = context.get_ca_certs(True)  # noqa: FBT003
    return [
        cert
        for der in trusted_der
        if (cert := _try_load_der_certificate(der)) is not None
    ]


def force_load_default_verify_certificates(context: ssl.SSLContext) -> None:
    """Forcefully load default verify certificates into the SSL context.

    Certificates in CA path directory are not loaded unless they
    have been used at leas one by the SSL context.

    This function loads all files located in CA path, except those
    that are considered hidden files (start with a '.').

    Args:
        context: The SSL context to load the verify certificates into.
    """
    # Expected way to load default certificates
    context.load_default_certs(purpose=ssl.Purpose.SERVER_AUTH)

    # Forcefully load files in CA path (this solution may not work on Windows
    ssl_defaults = ssl.get_default_verify_paths()

    if ssl_defaults.capath is not None:
        # Note: We found that some ssl installations have files that
        #   are not cert, i.e., homebrew's openssl has a .keepme. For now
        # we ignore files that start with '.' but a try except might
        # be necessary ¯\_(ツ)_/¯
        ca_files = (
            ca_file
            for ca_file in Path(ssl_defaults.capath).iterdir()
            if ca_file.is_file() and not ca_file.name.startswith(".")
        )

        for ca_file in ca_files:
            with contextlib.suppress(ssl.SSLError):
                context.load_verify_locations(ca_file)


def find_leaf_certificates(
    certificates: Sequence[x509.Certificate],
) -> list[x509.Certificate]:
    """Finds leaf certificates.

    A certificate is considered a leaf certificate if its subject
    is not found as the issuer of another certificate from the list.

    Returns:
        List with the certificates that are not issuers of any of the
            other provided certificates.
    """
    graph = collections.defaultdict(list)
    for cert in certificates:
        graph[cert.issuer].append(cert.subject)

    return [
        cert
        for cert in certificates
        if cert.subject not in graph or not graph[cert.subject]
    ]


def build_certificate_chain(
    leaf_cert: x509.Certificate,
    certs_map: Mapping[x509.Name, x509.Certificate],
) -> list[x509.Certificate]:
    """Builds a certificate chain from the `leaf_cert` to the root CA.

    Args:
        leaf_cert: Leaf certificate of the chain.
        certs_map: Mapping from `x509.Certificate.subject` to `x509.Certificate`.

    Returns:
        A certificate chain starting at `leaf_cert` and ending in root CA.

    Raises:
        KeyError: An issuer is not found in `certs_map`.
    """
    chain = [leaf_cert]

    while chain[-1].subject != chain[-1].issuer:
        chain.append(certs_map[chain[-1].issuer])

    return chain


def build_certificate_chains(
    certificates: Sequence[x509.Certificate],
) -> list[list[x509.Certificate]]:
    """Builds all certificate chains found in `certificates`.

    First it looks for all leaf certificates using
    [`find_leaf_certificates`][aia_chaser.utils.cert_utils.find_leaf_certificates]
    and then builds the chains starting at each leaf using
    [`build_certificate_chain`][aia_chaser.utils.cert_utils.build_certificate_chain].

    Returns:
        All certificate chains found in `certificates` each starting at
            its corresponding leaf certificate.
    """
    leaves = find_leaf_certificates(certificates)
    certs_map = {cert.subject: cert for cert in certificates}

    return [
        build_certificate_chain(
            leaf_cert=leaf,
            certs_map=certs_map,
        )
        for leaf in leaves
    ]


class AiaInformation(NamedTuple):
    """Authority Information Access (AIA) values."""

    ca_issuers: list[str]
    ocsp_urls: list[str]


def extract_aia_information(
    certificate: x509.Certificate,
) -> AiaInformation:
    """Extract authority information access (AIA) from a certificate.

    Args:
        certificate: Certificate from which extract AIA information.

    Returns:
        The extracted CA issues and OCSP servers.

    Note:
        If the certificate does not have the AIA extension this function
        does not fail, it fallbacks to returning empty sequences of data.
    """
    try:
        aia_extension = certificate.extensions.get_extension_for_class(
            x509.AuthorityInformationAccess,
        )
    except x509.ExtensionNotFound:
        return AiaInformation([], [])

    ca_issuers = [
        aia_entry.access_location.value
        for aia_entry in aia_extension.value
        if aia_entry.access_method == x509.OID_CA_ISSUERS
    ]
    ocsp_urls = [
        aia_entry.access_location.value
        for aia_entry in aia_extension.value
        if aia_entry.access_method == x509.OID_OCSP
    ]

    return AiaInformation(ca_issuers=ca_issuers, ocsp_urls=ocsp_urls)


def extract_crl_urls(certificate: x509.Certificate) -> list[str]:
    """Extract CRL distribution points from a certificate."""
    try:
        crl_extension = certificate.extensions.get_extension_for_class(
            x509.CRLDistributionPoints,
        )
        return [
            name.value
            for distribution_point in crl_extension.value
            for name in distribution_point.full_name
            if isinstance(name, x509.UniformResourceIdentifier)
        ]

    except x509.ExtensionNotFound:
        return []


_PADDING_PKCS1V15_OIDS = (
    x509.SignatureAlgorithmOID.RSA_WITH_MD5,
    x509.SignatureAlgorithmOID.RSA_WITH_SHA1,
    x509.SignatureAlgorithmOID.RSA_WITH_SHA224,
    x509.SignatureAlgorithmOID.RSA_WITH_SHA256,
    x509.SignatureAlgorithmOID.RSA_WITH_SHA384,
    x509.SignatureAlgorithmOID.RSA_WITH_SHA3_224,
    x509.SignatureAlgorithmOID.RSA_WITH_SHA3_256,
    x509.SignatureAlgorithmOID.RSA_WITH_SHA3_384,
    x509.SignatureAlgorithmOID.RSA_WITH_SHA3_512,
)


def select_rsa_padding_for_signature_algorithm_oid(
    signature_alg_oid: x509.ObjectIdentifier,
    signature_hash_alg: hashes.HashAlgorithm | None,
) -> padding.AsymmetricPadding:
    """Select padding for a given signature algorithm OID."""
    if signature_alg_oid == x509.SignatureAlgorithmOID.RSASSA_PSS:
        if signature_hash_alg is None:
            msg = "RSASSA-PSS signature requires a hash algorithm"
            raise ValueError(msg)

        return padding.PSS(
            mgf=padding.MGF1(signature_hash_alg),
            salt_length=padding.PSS.MAX_LENGTH,
        )
    if signature_alg_oid in _PADDING_PKCS1V15_OIDS:
        return padding.PKCS1v15()

    msg = f"unknown padding for signature algorithm oid {signature_alg_oid}"
    raise ValueError(msg)
