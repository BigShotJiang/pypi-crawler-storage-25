# JayDev - Web Exam Framework v7.0

[English](#english) | [Русский](#русский)

---

## English

**JayDev** is a powerful automation tool designed for students and developers (specifically for specialty 09.02.07) to quickly bootstrap Flask and PHP web projects with built-in modules, custom designs, and system environment checks.

### Features
*   **Project Constructor:** Generate full Flask projects with Auth, Admin Panel, Catalog, Cart, and more.
*   **Dynamic Design:** Choose between randomized "cool" styles or detailed custom CSS configurations.
*   **System Scanner:** Automatically check for installed Python, Flask, MySQL, XAMPP, OpenServer, and IDEs.
*   **Offline Installer:** Install required Python libraries from a local `libs` folder without internet.
*   **Tool Manager:** Launch external installers (.exe, .msi) directly from the framework.
*   **Built-in Guides:** Detailed instructions for setting up databases and servers.

### Installation
pip install JayDev

### Launch
python -m jaydev.main

### Русский

**JayDev** это мощный инструмент автоматизации, разработанный для студентов и разработчиков (специально для специальности 09.02.07). Он позволяет мгновенно создавать веб-проекты на Flask и PHP с готовыми модулями, кастомным дизайном и проверкой системного окружения.

### Возможности
*   **Конструктор проектов:** Генерация полноценных Flask-приложений (Авторизация, Админка, Каталог, Корзина и др.).
*   **Динамический дизайн:** Выбор между случайным "крутым" стилем или детальной настройкой CSS.
*   **Сканер системы:** Автоматическая проверка наличия Python, Flask, MySQL, XAMPP, OpenServer и редакторов кода.
*   **Офлайн установщик:** Установка необходимых библиотек из локальной папки libs без интернета.
*   **Менеджер инструментов:** Запуск внешних установщиков (.exe, .msi) прямо из интерфейса программы.
*   **Инструкции:** Встроенные гайды по настройке баз данных и серверов.

### Установка
pip install JayDev

### Запуск
python -m jaydev.main
