import os
import sys
import subprocess
import random
import re

BASE_PACKAGE_PATH = os.path.dirname(os.path.abspath(__file__))

# --- КОНФИГУРАЦИЯ ЦВЕТОВ ---
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def header():
    C = Colors
    print(f"")
    print(f"{C.BLUE}          __               ____{C.RESET}")
    print(f"{C.BLUE}         |  |             |  _ \\{C.RESET}")
    print(f"{C.BLUE}         |  | __ _ _   _  | | | | _____   __{C.RESET}")
    print(f"{C.BLUE}      _  |  |/ _` | | | | | | | |/ _ \\ \\ / /{C.RESET}")
    print(f"{C.BLUE}     | |__| | (_| | |_| | | |_| |  __/\\ V /{C.RESET}")
    print(f"{C.BLUE}      \\____/ \\__,_|\\__, | |____/ \\___| \\_/{C.RESET}")
    print(f"{C.CYAN}            ^   {C.BLUE}    __/ |{C.RESET}")
    print(f"{C.CYAN}           / \\ {C.BLUE}    |___/{C.RESET}")
    print(f"{C.CYAN}          / o \\{C.BLUE} {C.RESET}")
    print(f"{C.WHITE}         <    |{C.BLUE}           {C.BOLD}v7.2.0 - Web Exam Framework{C.RESET}")
    print(f"{C.WHITE}          \\   |{C.BLUE}/\\         ========================={C.RESET}")
    print(f"{C.WHITE}           \\  |{C.BLUE}///\\      [{C.GREEN}+{C.RESET}] Modules: Survey, Events, Services + 10 more")
    print(f"{C.BLUE}          / \\ |{C.BLUE}/////     [{C.GREEN}+{C.RESET}] Feature: Dynamic Auth & Admin Panel")
    print(f"{C.BLUE}         //  \\|{C.BLUE}/////     [{C.GREEN}+{C.RESET}] Status: Chat System & Mobile Ready")
    print(f"{C.BLUE}        ///   |{C.BLUE}//// {C.RESET}")
    print(f"{C.BLUE}       ////   |{C.BLUE}/// \\ {C.RESET}")
    print(f"{C.BLUE}      /////   |{C.BLUE}// \\ \\ {C.RESET}")
    print(f"{C.BLUE}              |{C.BLUE}/    \\\\ {C.RESET}")
    print(f"{C.BLUE}              {C.BLUE}        \\ {C.RESET}")
    print(f"\n{C.CYAN}  Рабочая директория: {os.getcwd()}{C.RESET}\n")

# --- 1. СКАНЕР СИСТЕМЫ ---
def check_env():
    software = {
        "Flask Lib": [[sys.executable, "-c", "import flask"]],
        "flask-wtf Lib": [[sys.executable, "-c", "import flask_wtf"]],
        "pillow Lib": [[sys.executable, "-c", "import PIL"]],
        "requests Lib": [[sys.executable, "-c", "import requests"]],
        "SQLite Browser": [
            r"C:\Program Files\DB Browser for SQLite\DB Browser for SQLite.exe",
            r"C:\Program Files (x86)\DB Browser for SQLite\DB Browser for SQLite.exe"
        ]
    }

    print(f"{Colors.BOLD}Отчет о состоянии системы:{Colors.RESET}")
    status = {}
    for name, paths in software.items():
        found = False
        for path in paths:
            if isinstance(path, str):
                if os.path.exists(path):
                    found = True
                    break
            else:
                try:
                    subprocess.check_call(path, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    found = True
                    break
                except:
                    continue

        if found:
            print(f"  {Colors.GREEN}[OK]{Colors.RESET} {name}")
            status[name] = True
        else:
            print(f"  {Colors.YELLOW}[!!]{Colors.RESET} {name} (ОТСУТСТВУЕТ)")
            status[name] = False
    return status

# --- 2. УСТАНОВКА БИБЛИОТЕК ---
def install_libs():
    libs = ["flask", "flask-wtf", "wtforms", "pillow", "requests"]
    print(f"{Colors.CYAN}\nНачинаю онлайн установку библиотек...{Colors.RESET}")

    for lib in libs:
        print(f"Установка {lib}...")
        cmd = [sys.executable, "-m", "pip", "install", lib]
        try:
            subprocess.check_call(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"  {Colors.GREEN}[+]{Colors.RESET} {lib} установлен.")
        except Exception:
            print(f"  {Colors.RED}[-]{Colors.RESET} Не удалось установить {lib}.")

# --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---
def write_file(path, filename, content):
    with open(os.path.join(path, filename), "w", encoding="utf-8") as f:
        f.write(content.strip() + "\n")

def ask_yes_no(question):
    while True:
        ans = input(question).strip().lower()
        if ans in ['y', 'n']:
            return ans == 'y'
        print(f"{Colors.RED}Ошибка: введите 'y' (да) или 'n' (нет).{Colors.RESET}")

def sanitize(name, default):
    name = name.strip().replace(" ", "_")
    return name if name else default

# --- 3. ГЕНЕРАЦИЯ ПРОЕКТА ---
def init_project(env_status):
    clear()
    header()
    print(f"{Colors.BOLD}=== КОНСТРУКТОР ПРОЕКТА (FLASK EDITION) v7.2 ==={Colors.RESET}")

    site_name = input(f"\n{Colors.CYAN}Название сайта [Project]: {Colors.RESET}").strip() or "Project"

    print(f"\n{Colors.YELLOW}Выберите дополнительные модули:{Colors.RESET}")
    mods = {
        "auth":     True,
        "admin":    True,
        "survey":   ask_yes_no("  - Модуль 'Анкетирование / Опрос сотрудников'? (y/n): "),
        "services": ask_yes_no("  - Каталог 'Услуги' (добавление через админку)? (y/n): "),
        "events":   ask_yes_no("  - Модуль 'Афиша / Мероприятия'? (y/n): "),
        "news":     ask_yes_no("  - Модуль 'Новости'? (y/n): "),
        "portfolio":ask_yes_no("  - Модуль 'Галерея / Портфолио'? (y/n): "),
        "reviews":  ask_yes_no("  - Форма 'Отзывы клиентов' (публичная)? (y/n): "),
        "booking":  ask_yes_no("  - Форма 'Заявка на услугу / Бронь'? (y/n): "),
        "careers":  ask_yes_no("  - Форма 'Вакансии / Отклик на работу'? (y/n): "),
        "team":     ask_yes_no("  - Модуль 'Наша команда'? (y/n): "),
        "profile":  ask_yes_no("  - Личный кабинет (Профиль)? (y/n): "),
        "catalog":  ask_yes_no("  - Каталог товаров + БД? (y/n): "),
        "cart":     ask_yes_no("  - Корзина товаров? (y/n): "),
        "about":    ask_yes_no("  - Страница 'О нас' (Инфо)? (y/n): "),
        "faq":      ask_yes_no("  - Блок FAQ (Частые вопросы + Задать вопрос/Чат)? (y/n): "),
        "feedback": ask_yes_no("  - Форма обратной связи (Контакты/Чат)? (y/n): ")
    }

    if mods["cart"] and not mods["catalog"]:
        mods["catalog"] = True
        print(f"{Colors.GREEN}[!] Каталог включен автоматически, так как выбрана корзина.{Colors.RESET}")

    print(f"\n{Colors.CYAN}Настройка Базы Данных SQLite:{Colors.RESET}")
    db_name = input("Имя файла базы данных [database.db]: ").strip() or "database.db"
    if not db_name.endswith('.db'): db_name += '.db'

    tables = {}
    tables["users"] = sanitize(input("  Таблица пользователей [users]: "), "users")
    if mods["survey"]:
        tables["survey_questions"] = sanitize(input("  Таблица вопросов анкеты [survey_questions]: "), "survey_questions")
        tables["survey_answers"] = sanitize(input("  Таблица ответов анкеты [survey_answers]: "), "survey_answers")
    if mods["catalog"]: tables["products"] = sanitize(input("  Таблица товаров [products]: "), "products")
    if mods["services"]: tables["services"] = sanitize(input("  Таблица услуг [services]: "), "services")
    if mods["events"]: tables["events"] = sanitize(input("  Таблица мероприятий [events]: "), "events")
    if mods["news"]: tables["news"] = sanitize(input("  Таблица новостей [news]: "), "news")
    if mods["portfolio"]: tables["portfolio"] = sanitize(input("  Таблица портфолио [portfolio]: "), "portfolio")
    if mods["reviews"]: tables["reviews"] = sanitize(input("  Таблица отзывов [reviews]: "), "reviews")
    if mods["booking"]: tables["bookings"] = sanitize(input("  Таблица заявок/брони [bookings]: "), "bookings")
    if mods["careers"]: tables["careers"] = sanitize(input("  Таблица откликов на работу [careers]: "), "careers")
    if mods["team"]: tables["team"] = sanitize(input("  Таблица сотрудников [team]: "), "team")
    if mods["faq"]: tables["faq"] = sanitize(input("  Таблица FAQ [faq]: "), "faq")

    print(f"\n{Colors.CYAN}Настройка полей Регистрации / Авторизации:{Colors.RESET}")
    login_field = input("Главное поле для входа (например: login, email, phone) [login]: ").strip().lower() or "login"
    login_field = re.sub(r'[^a-z0-9_]', '', login_field)

    raw_extra = input("Доп. поля регистрации (на англ. через запятую: email, age, city) [нет]: ").strip()
    extra_fields = []
    if raw_extra:
        for f in raw_extra.split(','):
            clean_f = re.sub(r'[^a-z0-9_]', '', f.strip().lower())
            if clean_f and clean_f not in ['id', 'password', login_field]:
                extra_fields.append(clean_f)

    print(f"\n{Colors.CYAN}Настройка Администратора:{Colors.RESET}")
    admin_user = input(f"Значение для поля '{login_field}' админа [admin]: ").strip() or "admin"
    admin_pass = input("Пароль администратора [admin123]: ").strip() or "admin123"

    print(f"\n{Colors.CYAN}Хотите детально настроить дизайн? (y/n) [n - случайный дизайн]: {Colors.RESET}", end="")
    custom_design = ask_yes_no("")

    fonts_dict = {'1': ("Современный", "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"), '2': ("Классика", "'Georgia', serif"), '3': ("Ретро", "'Courier New', Courier, monospace"), '4': ("Минимализм", "'Helvetica Neue', Helvetica, Arial, sans-serif"), '5': ("Игривый", "'Comic Sans MS', cursive, sans-serif")}
    shadows_dict = {'1': ("Мягкая тень", "0 4px 15px rgba(0,0,0,0.08)"), '2': ("Брутализм", "5px 5px 0px rgba(0,0,0,1)"), '3': ("Плоский", "none"), '4': ("Неоновое свечение", "0 0 15px rgba(0, 255, 255, 0.4)"), '5': ("Глубокая тень", "0 10px 30px rgba(0,0,0,0.2)")}
    borders_dict = {'1': ("Без рамок", "none"), '2': ("Тонкая линия", "1px solid #ddd"), '3': ("Толстая", "3px solid #333"), '4': ("Пунктир", "2px dashed var(--accent)"), '5': ("Двойная", "4px double var(--accent)")}
    # Усиленный эффект поворота под номером 4
    hovers_dict = {'1': ("Увеличение", "transform: scale(1.03);"), '2': ("Поднятие", "transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1);"), '3': ("Свечение", "box-shadow: 0 0 15px var(--accent); border-color: var(--accent);"), '4': ("Поворот", "transform: rotate(3deg) scale(1.05); box-shadow: 0 10px 20px rgba(0,0,0,0.15);"), '5': ("Инверсия", "background-color: var(--accent); color: var(--primary-bg);")}
    nav_opts = ['top', 'left', 'right']

    if custom_design:
        accent = input("Акцентный цвет (HEX, #ff5733): ").strip() or f"#{random.randint(0, 0xFFFFFF):06x}"
        primary_bg = input("Цвет карточек/меню [#ffffff]: ").strip() or "#ffffff"
        secondary_bg = input("Цвет фона сайта [#f4f7f6]: ").strip() or "#f4f7f6"
        rad_input = input("Радиус скругления (px) [10]: ").strip()
        radius = f"{rad_input}px" if rad_input.isdigit() else "10px"
        nav_pos = input("Расположение меню (top/left/right) [top]: ").strip().lower()
        if nav_pos not in nav_opts: nav_pos = 'top'

        font_family = fonts_dict.get(input("Шрифт (1.Современный | 2.Классика | 3.Ретро | 4.Минимализм | 5.Игривый) [1]: ").strip() or '1', fonts_dict['1'])[1]
        box_shadow = shadows_dict.get(input("Тени (1.Мягкие | 2.Брутализм | 3.Без теней | 4.Неон | 5.Глубокие) [1]: ").strip() or '1', shadows_dict['1'])[1]
        border_style = borders_dict.get(input("Рамки (1.Нет | 2.Тонкие | 3.Толстые | 4.Пунктир | 5.Двойная) [1]: ").strip() or '1', borders_dict['1'])[1]
        hover_effect = hovers_dict.get(input("Наведение (1.Увеличение | 2.Поднятие | 3.Свечение | 4.Поворот | 5.Инверсия) [1]: ").strip() or '1', hovers_dict['1'])[1]
        padding_base = input("Внутренние отступы (px) [20]: ").strip()
        padding_base = f"{padding_base}px" if padding_base.isdigit() else "20px"
    else:
        accent = f"#{random.randint(0, 0xFFFFFF):06x}"
        primary_bg, secondary_bg = "#ffffff", "#f4f7f6"
        if random.choice([True, False]): primary_bg, secondary_bg = "#2c3e50", "#1a252f"
        radius = f"{random.randint(0, 25)}px"
        nav_pos = random.choice(nav_opts)
        font_family = random.choice(list(fonts_dict.values()))[1]
        box_shadow = random.choice(list(shadows_dict.values()))[1]
        border_style = random.choice(list(borders_dict.values()))[1]
        hover_effect = random.choice(list(hovers_dict.values()))[1]
        padding_base = f"{random.randint(15, 30)}px"

    print("\nГде создать проект?")
    print("1. Рабочий стол | 2. Текущая папка | 3. Свой путь")
    loc = input("> ")
    if loc == '1': base_path = os.path.join(os.path.expanduser("~"), "Desktop")
    elif loc == '3': base_path = input("Введите полный путь: ")
    else: base_path = os.getcwd()

    proj_name = input("\nИмя папки проекта [flask_exam]: ") or "flask_exam"
    full_path = os.path.join(base_path, proj_name)

    try:
        generate_flask_pro(full_path, site_name, mods, db_name, tables, login_field, extra_fields, admin_user, admin_pass, accent, primary_bg, secondary_bg, radius, nav_pos, font_family, box_shadow, border_style, hover_effect, padding_base)
        print(f"\n{Colors.GREEN}[УСПЕХ] Проект '{proj_name}' успешно создан!{Colors.RESET}")
        print(f"Путь: {full_path}")
        print(f"Инструкция:\n  1. cd {proj_name}\n  2. python init_db.py\n  3. python app.py")
        print(f"\n{Colors.YELLOW}ДАННЫЕ АДМИНА:{Colors.RESET} {login_field.capitalize()}: {admin_user} | Пароль: {admin_pass}")
    except Exception as e:
        print(f"{Colors.RED}Ошибка при создании: {e}{Colors.RESET}")

    input("\nНажмите Enter для продолжения...")

# ==========================================
#        ГЕНЕРАТОР FLASK (ПОЛНАЯ ВЕРСИЯ)
# ==========================================
def generate_flask_pro(path, site_name, mods, db_name, tables, login_field, extra_fields, admin_user, admin_pass, accent, primary_bg, secondary_bg, radius, nav_pos, font_family, box_shadow, border_style, hover_effect, padding_base):
    os.makedirs(os.path.join(path, "static/css"), exist_ok=True)
    os.makedirs(os.path.join(path, "templates"), exist_ok=True)

    tu = tables.get('users', 'users')
    tsq = tables.get('survey_questions', 'survey_questions')
    tsa = tables.get('survey_answers', 'survey_answers')
    tp = tables.get('products', 'products')
    tserv = tables.get('services', 'services')
    tev = tables.get('events', 'events')
    tn = tables.get('news', 'news')
    tport = tables.get('portfolio', 'portfolio')
    tr = tables.get('reviews', 'reviews')
    tb = tables.get('bookings', 'bookings')
    tc = tables.get('careers', 'careers')
    tt = tables.get('team', 'team')
    tfaq = tables.get('faq', 'faq')

    all_reg_fields = [login_field, 'password'] + extra_fields
    reg_form_gets = "\n        ".join([f"{f} = request.form.get('{f}', '').strip()" for f in all_reg_fields])
    db_insert_cols = ", ".join(all_reg_fields)
    db_insert_qmarks = ", ".join(["?"] * len(all_reg_fields))
    db_insert_vals = ", ".join(all_reg_fields)

    # --- 1. Генерация app.py ---
    app_code = f"""from flask import Flask, render_template, request, redirect, session, url_for
import sqlite3
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__, template_folder=os.path.join(BASE_DIR, 'templates'), static_folder=os.path.join(BASE_DIR, 'static'))
app.secret_key = 'super_secret_exam_key'
ADMIN_USER = '{admin_user}'

def get_db():
    conn = sqlite3.connect(os.path.join(BASE_DIR, '{db_name}'))
    conn.row_factory = sqlite3.Row
    return conn

@app.context_processor
def inject_globals():
    return dict(is_admin=(session.get('user') == ADMIN_USER), site_name="{site_name}")

@app.route('/')
def index():
    return render_template('index.html')
"""
    if mods["survey"]:
        app_code += f"""
@app.route('/survey', methods=['GET', 'POST'])
def survey():
    db = get_db()
    error, success = None, None
    questions = db.execute('SELECT * FROM {tsq}').fetchall()
    if request.method == 'POST':
        if not questions:
            error = "Анкета пуста."
        else:
            for q in questions:
                ans = request.form.get(f'q_{{q["id"]}}')
                if ans:
                    db.execute('INSERT INTO {tsa} (question_id, answer) VALUES (?, ?)', (q["id"], ans))
            db.commit()
            success = "Спасибо за участие! Ваши ответы сохранены анонимно."
    return render_template('survey.html', questions=questions, error=error, success=success)
"""
    if mods["about"]: app_code += "\n@app.route('/about')\ndef about():\n    return render_template('about.html')\n"
    if mods["services"]: app_code += f"\n@app.route('/services')\ndef services():\n    return render_template('services.html', srvs=get_db().execute('SELECT * FROM {tserv}').fetchall())\n"
    if mods["events"]: app_code += f"\n@app.route('/events')\ndef events():\n    return render_template('events.html', evs=get_db().execute('SELECT * FROM {tev} ORDER BY id DESC').fetchall())\n"
    if mods["team"]: app_code += f"\n@app.route('/team')\ndef team():\n    return render_template('team.html', members=get_db().execute('SELECT * FROM {tt}').fetchall())\n"
    if mods["portfolio"]: app_code += f"\n@app.route('/portfolio')\ndef portfolio():\n    return render_template('portfolio.html', projects=get_db().execute('SELECT * FROM {tport} ORDER BY id DESC').fetchall())\n"
    if mods["news"]: app_code += f"\n@app.route('/news')\ndef news():\n    return render_template('news.html', news_list=get_db().execute('SELECT * FROM {tn} ORDER BY id DESC').fetchall())\n"

    if mods["faq"]:
        app_code += f"""
@app.route('/faq', methods=['GET', 'POST'])
def faq():
    db = get_db()
    error, success = None, None
    if request.method == 'POST':
        if 'user_id' not in session:
            error = "Необходимо авторизоваться!"
        else:
            new_q = request.form.get('new_question', '').strip()
            if len(new_q) >= 5:
                db.execute('INSERT INTO threads (user_id, title) VALUES (?, ?)', (session['user_id'], 'Вопрос FAQ: ' + new_q[:30] + '...'))
                thread_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
                db.execute('INSERT INTO replies (thread_id, sender, text) VALUES (?, ?, ?)', (thread_id, session['user'], new_q))
                db.commit()
                success = "Ваш вопрос успешно отправлен! Отслеживайте ответ в Личном кабинете."
            else:
                error = "Вопрос слишком короткий. Пожалуйста, опишите подробнее."
    faqs = db.execute('SELECT * FROM {tfaq}').fetchall()
    return render_template('faq.html', faqs=faqs, error=error, success=success)
"""

    if mods["booking"]:
        app_code += f"""
@app.route('/booking', methods=['GET', 'POST'])
def booking():
    error, success = None, None
    if request.method == 'POST':
        if 'user_id' not in session: return redirect('/login')
        name = request.form.get('name', '').strip()
        phone = request.form.get('phone', '').strip()
        date = request.form.get('date', '').strip()
        service = request.form.get('service', '').strip()
        user_id = session.get('user_id')
        if len(name) < 2 or len(phone) < 5 or not date:
            error = "Пожалуйста, заполните все обязательные поля."
        else:
            db = get_db()
            db.execute('INSERT INTO {tb} (user_id, name, phone, date, service) VALUES (?, ?, ?, ?, ?)', (user_id, name, phone, date, service))
            db.commit()
            success = "Ваша заявка успешно отправлена! Отслеживайте статус в Личном кабинете."
    return render_template('booking.html', error=error, success=success)
"""

    if mods["careers"]:
        app_code += f"""
@app.route('/careers', methods=['GET', 'POST'])
def careers():
    db = get_db()
    error, success = None, None
    vacancies = db.execute('SELECT * FROM vacancies').fetchall()
    if request.method == 'POST':
        if 'user_id' not in session: return redirect('/login')
        name = request.form.get('name', '').strip()
        phone = request.form.get('phone', '').strip()
        vacancy_id = request.form.get('vacancy_id', '').strip()
        experience = request.form.get('experience', '').strip()
        user_id = session.get('user_id')
        if len(name) < 2 or len(phone) < 5 or not vacancy_id:
            error = "Пожалуйста, заполните все обязательные поля."
        else:
            db.execute('INSERT INTO {tc} (user_id, vacancy_id, name, phone, experience) VALUES (?, ?, ?, ?, ?)', (user_id, vacancy_id, name, phone, experience))
            db.commit()
            success = "Ваш отклик успешно отправлен! Статус можно проверить в Профиле."
    return render_template('careers.html', vacancies=vacancies, error=error, success=success)
"""

    if mods["reviews"]:
        app_code += f"""
@app.route('/reviews', methods=['GET', 'POST'])
def reviews():
    db = get_db()
    error, success = None, None
    if request.method == 'POST':
        if 'user_id' not in session: return redirect('/login')
        author = request.form.get('author', '').strip()
        text = request.form.get('text', '').strip()
        rating = request.form.get('rating', '5')
        if len(author) < 2 or len(text) < 5:
            error = "Имя и текст отзыва не могут быть такими короткими."
        else:
            db.execute('INSERT INTO {tr} (author, text, rating) VALUES (?, ?, ?)', (author, text, int(rating)))
            db.commit()
            success = "Спасибо за ваш отзыв!"
    rev_list = db.execute('SELECT * FROM {tr} ORDER BY id DESC').fetchall()
    return render_template('reviews.html', rev_list=rev_list, error=error, success=success)
"""

    if mods["feedback"]:
        app_code += f"""
@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    error, success = None, None
    if request.method == 'POST':
        if 'user_id' not in session: return redirect('/login')
        subj = request.form.get('subject', 'Без темы').strip()
        msg = request.form.get('message', '').strip()
        user_id = session.get('user_id')
        if len(msg) < 5:
            error = "Сообщение слишком короткое."
        else:
            db = get_db()
            db.execute('INSERT INTO threads (user_id, title) VALUES (?, ?)', (user_id, subj))
            thread_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
            db.execute('INSERT INTO replies (thread_id, sender, text) VALUES (?, ?, ?)', (thread_id, session['user'], msg))
            db.commit()
            success = "Ваше сообщение успешно отправлено! Ответ будет в личном кабинете."
    return render_template('feedback.html', error=error, success=success)
"""

    if mods["feedback"] or mods["faq"]:
        app_code += f"""
@app.route('/profile/thread/<int:th_id>', methods=['GET', 'POST'])
def profile_thread(th_id):
    if 'user_id' not in session: return redirect('/login')
    db = get_db()
    thread = db.execute('SELECT * FROM threads WHERE id=? AND user_id=?', (th_id, session['user_id'])).fetchone()
    if not thread: return "Диалог не найден", 404
    if request.method == 'POST':
        msg = request.form.get('message', '').strip()
        if msg:
            db.execute('INSERT INTO replies (thread_id, sender, text) VALUES (?, ?, ?)', (th_id, session['user'], msg))
            db.execute('UPDATE threads SET status="Новое сообщение" WHERE id=?', (th_id,))
            db.commit()
            return redirect(url_for('profile_thread', th_id=th_id))
    replies = db.execute('SELECT * FROM replies WHERE thread_id=? ORDER BY id ASC', (th_id,)).fetchall()
    return render_template('thread.html', thread=thread, replies=replies)
"""

    app_code += f"""
@app.route('/register', methods=['GET', 'POST'])
def register():
    error = None
    if request.method == 'POST':
        {reg_form_gets}
        if len({login_field}) < 3: error = "Логин слишком короткий."
        elif len(password) < 6: error = "Пароль слишком короткий."
        else:
            db = get_db()
            if db.execute('SELECT id FROM {tu} WHERE {login_field}=?', ({login_field},)).fetchone():
                error = "Пользователь уже существует."
            else:
                db.execute('INSERT INTO {tu} ({db_insert_cols}) VALUES ({db_insert_qmarks})', ({db_insert_vals}))
                db.commit()
                return render_template('login.html', success="Регистрация успешна! Теперь вы можете войти.")
    return render_template('register.html', error=error)

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        {login_field} = request.form.get('{login_field}', '').strip()
        password = request.form.get('password', '').strip()
        db = get_db()
        user = db.execute('SELECT * FROM {tu} WHERE {login_field}=? AND password=?', ({login_field}, password)).fetchone()
        if user:
            session['user'] = user['{login_field}']
            session['user_id'] = user['id']
            return redirect(url_for('index'))
        error = "Неверные данные."
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))
"""
    if mods["profile"]:
        app_code += f"""
@app.route('/profile')
def profile():
    if 'user' not in session: return redirect(url_for('login'))
    db = get_db()
    user_id = session['user_id']
    user = db.execute('SELECT * FROM {tu} WHERE id=?', (user_id,)).fetchone()

    my_bookings = db.execute('SELECT * FROM {tb} WHERE user_id=? ORDER BY id DESC', (user_id,)).fetchall() if {mods['booking']} else []
    my_careers = db.execute('SELECT c.*, v.title FROM {tc} c JOIN vacancies v ON c.vacancy_id = v.id WHERE c.user_id=? ORDER BY c.id DESC', (user_id,)).fetchall() if {mods['careers']} else []
    my_threads = db.execute('SELECT * FROM threads WHERE user_id=? ORDER BY id DESC', (user_id,)).fetchall() if {(mods['feedback'] or mods['faq'])} else []

    return render_template('profile.html', user=user, my_bookings=my_bookings, my_careers=my_careers, my_threads=my_threads)
"""
    if mods["catalog"]:
        app_code += f"""
@app.route('/catalog')
def catalog():
    items = get_db().execute('SELECT * FROM {tp}').fetchall()
    return render_template('catalog.html', items=items)
"""
    if mods["cart"]:
        app_code += f"""
@app.route('/cart')
def cart():
    if 'cart' not in session: session['cart'] = []
    db = get_db()
    items, total = [], 0
    for item_id in session['cart']:
        prod = db.execute('SELECT * FROM {tp} WHERE id=?', (item_id,)).fetchone()
        if prod:
            items.append(prod)
            total += prod['price']
    return render_template('cart.html', items=items, total=total)

@app.route('/cart/add/<int:item_id>')
def add_to_cart(item_id):
    if 'user_id' not in session: return redirect('/login')
    cart = session.get('cart', [])
    cart.append(item_id)
    session['cart'] = cart
    return redirect(url_for('catalog'))

@app.route('/cart/clear')
def clear_cart():
    session.pop('cart', None)
    return redirect(url_for('cart'))
"""

    # --- АДМИН-ПАНЕЛЬ ---
    app_code += f"""
@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if session.get('user') != ADMIN_USER: return "Доступ запрещен", 403
    db = get_db()
    error, success = None, None

    if request.method == 'POST':
        form_type = request.form.get('form_type')
        if form_type == 'product':
            name, price, desc = request.form.get('name', '').strip(), request.form.get('price', 0), request.form.get('description', '').strip()
            try:
                price = float(price)
                if price > 0 and len(name) >= 2:
                    db.execute('INSERT INTO {tp} (name, price, description) VALUES (?, ?, ?)', (name, price, desc))
                    db.commit()
                    success = "Товар добавлен."
                else: error = "Ошибка валидации."
            except ValueError: error = "Некорректная цена."

        elif form_type == 'survey_question':
            q_text, q_type = request.form.get('question_text', '').strip(), request.form.get('question_type', 'text').strip()
            if len(q_text) >= 5:
                db.execute('INSERT INTO {tsq} (question_text, question_type) VALUES (?, ?)', (q_text, q_type))
                db.commit()
                success = "Вопрос добавлен."
            else: error = "Вопрос слишком короткий."

        elif form_type == 'vacancy':
            title, desc = request.form.get('title', '').strip(), request.form.get('description', '').strip()
            if len(title) >= 2:
                db.execute('INSERT INTO vacancies (title, description) VALUES (?, ?)', (title, desc))
                db.commit()
                success = "Вакансия добавлена."
            else: error = "Название слишком короткое."

        elif form_type == 'service':
            name, price, desc = request.form.get('name', '').strip(), request.form.get('price', '').strip(), request.form.get('description', '').strip()
            if len(name) >= 2:
                db.execute('INSERT INTO {tserv} (name, price, description) VALUES (?, ?, ?)', (name, price, desc))
                db.commit()
                success = "Услуга добавлена."
            else: error = "Название слишком короткое."

        elif form_type == 'event':
            title, date, loc = request.form.get('title', '').strip(), request.form.get('date', '').strip(), request.form.get('location', '').strip()
            if len(title) >= 2 and date:
                db.execute('INSERT INTO {tev} (title, date, location) VALUES (?, ?, ?)', (title, date, loc))
                db.commit()
                success = "Мероприятие добавлено."
            else: error = "Заполните название и дату."

        elif form_type == 'faq':
            q, a = request.form.get('question', '').strip(), request.form.get('answer', '').strip()
            if len(q) >= 5 and len(a) >= 5:
                db.execute('INSERT INTO {tfaq} (question, answer) VALUES (?, ?)', (q, a))
                db.commit()
                success = "Вопрос добавлен."
            else: error = "Вопрос и ответ слишком короткие."

        elif form_type == 'news':
            title, content = request.form.get('title', '').strip(), request.form.get('content', '').strip()
            if len(title) >= 3 and len(content) >= 10:
                db.execute('INSERT INTO {tn} (title, content) VALUES (?, ?)', (title, content))
                db.commit()
                success = "Новость опубликована."
            else: error = "Заголовок или текст слишком короткие."

        elif form_type == 'team':
            name, pos, bio = request.form.get('name', '').strip(), request.form.get('position', '').strip(), request.form.get('bio', '').strip()
            if len(name) >= 2 and len(pos) >= 2:
                db.execute('INSERT INTO {tt} (name, position, bio) VALUES (?, ?, ?)', (name, pos, bio))
                db.commit()
                success = "Сотрудник добавлен."
            else: error = "Заполните имя и должность."

        elif form_type == 'portfolio':
            title, img_url, desc = request.form.get('title', '').strip(), request.form.get('image_url', '').strip() or 'https://via.placeholder.com/400x300', request.form.get('description', '').strip()
            if len(title) >= 2:
                db.execute('INSERT INTO {tport} (title, image_url, description) VALUES (?, ?, ?)', (title, img_url, desc))
                db.commit()
                success = "Проект добавлен."
            else: error = "Название проекта обязательно."

    stats = {{}}
    if {mods['booking']}:
        stats['book_total'] = db.execute('SELECT COUNT(*) FROM {tb}').fetchone()[0]
        stats['book_new'] = db.execute('SELECT COUNT(*) FROM {tb} WHERE status="В обработке"').fetchone()[0]
    if {mods['careers']}:
        stats['car_total'] = db.execute('SELECT COUNT(*) FROM {tc}').fetchone()[0]
        stats['car_new'] = db.execute('SELECT COUNT(*) FROM {tc} WHERE status="На рассмотрении"').fetchone()[0]
    if {mods['survey']}:
        stats['surv_ans'] = db.execute('SELECT COUNT(*) FROM {tsa}').fetchone()[0]
    if {mods['reviews']}:
        stats['rev_total'] = db.execute('SELECT COUNT(*) FROM {tr}').fetchone()[0]
    if {mods['faq']} or {mods['feedback']}:
        stats['threads_total'] = db.execute('SELECT COUNT(*) FROM threads').fetchone()[0]
        stats['threads_new'] = db.execute('SELECT COUNT(*) FROM threads WHERE status="Новое сообщение" OR status="Открыт"').fetchone()[0]

    return render_template('admin.html', stats=stats, error=error, success=success)
"""

    if mods["feedback"] or mods["faq"]:
        app_code += f"""
@app.route('/admin/messages', methods=['GET'])
def admin_messages():
    if session.get('user') != ADMIN_USER: return redirect('/')
    threads = get_db().execute('SELECT t.*, u.{login_field} as username FROM threads t JOIN {tu} u ON t.user_id = u.id ORDER BY t.id DESC').fetchall()
    return render_template('admin_messages.html', threads=threads)

@app.route('/admin/thread/<int:th_id>', methods=['GET', 'POST'])
def admin_thread(th_id):
    if session.get('user') != ADMIN_USER: return redirect('/')
    db = get_db()
    thread = db.execute('SELECT t.*, u.{login_field} as username FROM threads t JOIN {tu} u ON t.user_id = u.id WHERE t.id=?', (th_id,)).fetchone()
    if not thread: return "Не найдено", 404

    if request.method == 'POST':
        action = request.form.get('action')
        reply_text = request.form.get('reply', '').strip()
        if reply_text:
            db.execute('INSERT INTO replies (thread_id, sender, text) VALUES (?, ?, ?)', (th_id, 'Администратор', reply_text))
            db.execute('UPDATE threads SET status="Ожидает ответа пользователя" WHERE id=?', (th_id,))
            if action == 'publish_faq' and {mods['faq']}:
                first_msg = db.execute('SELECT text FROM replies WHERE thread_id=? ORDER BY id ASC LIMIT 1', (th_id,)).fetchone()
                if first_msg:
                    db.execute('INSERT INTO {tfaq} (question, answer) VALUES (?, ?)', (first_msg['text'], reply_text))
            db.commit()
            return redirect(url_for('admin_thread', th_id=th_id))

    replies = db.execute('SELECT * FROM replies WHERE thread_id=? ORDER BY id ASC', (th_id,)).fetchall()
    return render_template('admin_thread.html', thread=thread, replies=replies, faq_enabled={mods['faq']})
"""

    if mods["booking"]:
        app_code += f"""
@app.route('/admin/bookings', methods=['GET', 'POST'])
def admin_bookings():
    if session.get('user') != ADMIN_USER: return redirect('/')
    db = get_db()
    if request.method == 'POST':
        b_id, status, comment = request.form.get('b_id'), request.form.get('status'), request.form.get('comment')
        db.execute('UPDATE {tb} SET status=?, admin_comment=? WHERE id=?', (status, comment, b_id))
        db.commit()
    bookings = db.execute('SELECT * FROM {tb} ORDER BY id DESC').fetchall()
    return render_template('admin_bookings.html', bookings=bookings)
"""
    if mods["careers"]:
        app_code += f"""
@app.route('/admin/careers', methods=['GET', 'POST'])
def admin_careers():
    if session.get('user') != ADMIN_USER: return redirect('/')
    db = get_db()
    if request.method == 'POST':
        c_id, status = request.form.get('c_id'), request.form.get('status')
        db.execute('UPDATE {tc} SET status=? WHERE id=?', (status, c_id))
        db.commit()
    apps = db.execute('SELECT c.*, v.title FROM {tc} c JOIN vacancies v ON c.vacancy_id = v.id ORDER BY c.id DESC').fetchall()
    return render_template('admin_careers.html', apps=apps)
"""
    if mods["reviews"]:
        app_code += f"""
@app.route('/admin/reviews')
def admin_reviews():
    if session.get('user') != ADMIN_USER: return redirect('/')
    db = get_db()
    sort = request.args.get('sort', 'desc')
    order = "ASC" if sort == 'asc' else "DESC"
    reviews = db.execute(f'SELECT * FROM {tr} ORDER BY rating {{order}}, id DESC').fetchall()
    avg_rating = db.execute('SELECT AVG(rating) FROM {tr}').fetchone()[0]
    avg_rating = round(avg_rating, 1) if avg_rating else 0
    return render_template('admin_reviews.html', reviews=reviews, avg_rating=avg_rating, current_sort=sort)
"""
    if mods["survey"]:
        app_code += f"""
@app.route('/admin/survey')
def admin_survey():
    if session.get('user') != ADMIN_USER: return redirect('/')
    db = get_db()
    questions = db.execute('SELECT * FROM {tsq}').fetchall()
    stats, text_answers = [], []
    for q in questions:
        if q['question_type'] == 'rating':
            avg = db.execute('SELECT AVG(CAST(answer AS REAL)) FROM {tsa} WHERE question_id=?', (q['id'],)).fetchone()[0]
            stats.append({{'text': q['question_text'], 'type': 'rating', 'value': round(avg, 1) if avg else 0}})
        elif q['question_type'] == 'yesno':
            yes_c = db.execute('SELECT COUNT(*) FROM {tsa} WHERE question_id=? AND answer="Да"', (q['id'],)).fetchone()[0]
            no_c = db.execute('SELECT COUNT(*) FROM {tsa} WHERE question_id=? AND answer="Нет"', (q['id'],)).fetchone()[0]
            stats.append({{'text': q['question_text'], 'type': 'yesno', 'yes': yes_c, 'no': no_c}})
        else:
            ans = db.execute('SELECT answer, created_at FROM {tsa} WHERE question_id=? ORDER BY id DESC', (q['id'],)).fetchall()
            text_answers.append({{'text': q['question_text'], 'answers': ans}})
    return render_template('admin_survey.html', stats=stats, text_answers=text_answers)
"""

    app_code += "\nif __name__ == '__main__':\n    app.run(debug=True, port=5000, host='0.0.0.0')\n"
    write_file(path, "app.py", app_code)

    # --- 2. Генерация init_db.py ---
    tu_columns = f"id INTEGER PRIMARY KEY AUTOINCREMENT, {login_field} TEXT NOT NULL, password TEXT NOT NULL"
    for f in extra_fields:
        tu_columns += f", {f} TEXT"

    admin_qmarks = "?, ?" + ("" if not extra_fields else ", " + ", ".join(["?"] * len(extra_fields)))
    admin_vals = f"'{admin_user}', '{admin_pass}'" + ("" if not extra_fields else ", " + ", ".join(["''"] * len(extra_fields)))

    db_init = f"""import sqlite3
import os
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
conn = sqlite3.connect(os.path.join(BASE_DIR, '{db_name}'))
cursor = conn.cursor()

cursor.execute('CREATE TABLE IF NOT EXISTS {tu} ({tu_columns})')
if not cursor.execute('SELECT id FROM {tu} WHERE {login_field}=?', ('{admin_user}',)).fetchone():
    cursor.execute('INSERT INTO {tu} ({db_insert_cols}) VALUES ({admin_qmarks})', ({admin_vals}))
"""
    if mods["survey"]:
        db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tsq} (id INTEGER PRIMARY KEY AUTOINCREMENT, question_text TEXT NOT NULL, question_type TEXT DEFAULT \"text\")')\n"
        db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tsa} (id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER, answer TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(question_id) REFERENCES {tsq}(id))')\n"
    if mods["catalog"]: db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tp} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price REAL NOT NULL, description TEXT)')\n"
    if mods["services"]: db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tserv} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price TEXT NOT NULL, description TEXT)')\n"
    if mods["events"]: db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tev} (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, date TEXT NOT NULL, location TEXT)')\n"
    if mods["faq"]: db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tfaq} (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, answer TEXT NOT NULL)')\n"
    if mods["feedback"] or mods["faq"]:
        db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS threads (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, title TEXT, status TEXT DEFAULT \"Открыт\")')\n"
        db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS replies (id INTEGER PRIMARY KEY AUTOINCREMENT, thread_id INTEGER, sender TEXT, text TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)')\n"
    if mods["news"]: db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tn} (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, content TEXT NOT NULL, date_posted TIMESTAMP DEFAULT CURRENT_TIMESTAMP)')\n"
    if mods["team"]: db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tt} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, position TEXT NOT NULL, bio TEXT)')\n"
    if mods["portfolio"]: db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tport} (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, image_url TEXT NOT NULL, description TEXT)')\n"
    if mods["reviews"]: db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tr} (id INTEGER PRIMARY KEY AUTOINCREMENT, author TEXT NOT NULL, text TEXT NOT NULL, rating INTEGER)')\n"
    if mods["booking"]: db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tb} (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, name TEXT NOT NULL, phone TEXT NOT NULL, date TEXT NOT NULL, service TEXT, status TEXT DEFAULT \"В обработке\", admin_comment TEXT)')\n"
    if mods["careers"]:
        db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS vacancies (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT)')\n"
        db_init += f"cursor.execute('CREATE TABLE IF NOT EXISTS {tc} (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, vacancy_id INTEGER, name TEXT NOT NULL, phone TEXT NOT NULL, experience TEXT, status TEXT DEFAULT \"На рассмотрении\")')\n"

    db_init += f"conn.commit()\nconn.close()\nprint('БД {db_name} успешно создана!')"
    write_file(path, "init_db.py", db_init)

    # --- 3. HTML Шаблоны ---
    nav_links = ""
    if mods["survey"]: nav_links += '<li><a href="/survey">Опрос</a></li>\n'
    if mods["services"]: nav_links += '<li><a href="/services">Услуги</a></li>\n'
    if mods["catalog"]: nav_links += '<li><a href="/catalog">Каталог</a></li>\n'
    if mods["events"]: nav_links += '<li><a href="/events">Афиша</a></li>\n'
    if mods["news"]: nav_links += '<li><a href="/news">Новости</a></li>\n'
    if mods["portfolio"]: nav_links += '<li><a href="/portfolio">Галерея</a></li>\n'
    if mods["booking"]: nav_links += '<li><a href="/booking">Заявка</a></li>\n'
    if mods["careers"]: nav_links += '<li><a href="/careers">Вакансии</a></li>\n'
    if mods["team"]: nav_links += '<li><a href="/team">Команда</a></li>\n'
    if mods["reviews"]: nav_links += '<li><a href="/reviews">Отзывы</a></li>\n'
    if mods["faq"]: nav_links += '<li><a href="/faq">FAQ</a></li>\n'
    if mods["cart"]: nav_links += '<li><a href="/cart">Корзина</a></li>\n'
    if mods["about"]: nav_links += '<li><a href="/about">О нас</a></li>\n'
    if mods["feedback"]: nav_links += '<li><a href="/feedback">Контакты</a></li>\n'

    auth_links = "{% if session.user %}\n"
    auth_links += '<li><a href="/profile" class="btn-nav btn-outline">{{ session.user }}</a></li>\n'
    auth_links += """{% if is_admin %}<li><a href="/admin" class="btn-nav btn-dark">Админка</a></li>{% endif %}
    <li><a href="/logout" class="btn-nav btn-danger">Выход</a></li>
    {% else %}
    <li><a href="/login" class="btn-nav btn-outline">Вход</a></li>
    <li><a href="/register" class="btn-nav btn-primary">Регистрация</a></li>
    {% endif %}"""

    layout_html = """<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ site_name }}</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
</head>
<body>
    <header class="main-header">
        <div class="header-top">
            <div class="logo"><a href="/">{{ site_name }}</a></div>
            <button class="menu-toggle" onclick="document.querySelector('.navbar').classList.toggle('active')">☰</button>
        </div>
        <nav class="navbar">
            <ul class="nav-links"><li><a href="/">Главная</a></li>\n""" + nav_links + """</ul>
            <ul class="nav-links auth-links">\n""" + auth_links + """</ul>
        </nav>
    </header>
    <main class="container">{% block content %}{% endblock %}</main>
</body>
</html>"""
    write_file(os.path.join(path, "templates"), "layout.html", layout_html)
    write_file(os.path.join(path, "templates"), "index.html", "{% extends 'layout.html' %}\n{% block content %}\n<div class='hero-section'><h1>Добро пожаловать на {{ site_name }}</h1><p>Используйте навигацию для перехода по разделам.</p></div>\n{% endblock %}")

    login_html = f"""{{% extends 'layout.html' %}}\n{{% block content %}}\n<div class="form-container"><h2>Авторизация</h2>{{% if error %}}<div class="alert alert-error">{{{{ error }}}}</div>{{% endif %}}{{% if success %}}<div class="alert alert-success">{{{{ success }}}}</div>{{% endif %}}<form action="/login" method="POST"><div class="form-group"><label>{login_field.capitalize()}</label><input type="text" name="{login_field}" required minlength="3"></div><div class="form-group"><label>Password</label><input type="password" name="password" required minlength="6"></div><button type="submit" class="btn-submit">Войти</button></form></div>\n{{% endblock %}}"""
    write_file(os.path.join(path, "templates"), "login.html", login_html)

    reg_inputs = f'<div class="form-group"><label>{login_field.capitalize()}</label><input type="text" name="{login_field}" required minlength="3"></div>\n<div class="form-group"><label>Password</label><input type="password" name="password" required minlength="6"></div>\n'
    for f in extra_fields: reg_inputs += f'<div class="form-group"><label>{f.capitalize()}</label><input type="text" name="{f}" required></div>\n'
    register_html = f"""{{% extends 'layout.html' %}}\n{{% block content %}}\n<div class="form-container"><h2>Регистрация</h2>{{% if error %}}<div class="alert alert-error">{{{{ error }}}}</div>{{% endif %}}<form action="/register" method="POST">{reg_inputs}<button type="submit" class="btn-submit">Зарегистрироваться</button></form></div>\n{{% endblock %}}"""
    write_file(os.path.join(path, "templates"), "register.html", register_html)

    if mods["profile"]:
        profile_content = f"""{{% extends 'layout.html' %}}\n{{% block content %}}\n<h2>Личный кабинет</h2>\n<div class='card' style="margin-bottom:30px;"><p><b>{login_field.capitalize()}:</b> {{{{ user.{login_field} }}}}</p><p><b>ID аккаунта:</b> #{{{{ user.id }}}}</p>\n"""
        for f in extra_fields: profile_content += f"<p><b>{f.capitalize()}:</b> {{{{ user.{f} }}}}</p>\n"
        profile_content += "</div>\n<div style='display:flex; flex-direction:column; gap:30px;'>\n"
        if mods["feedback"] or mods["faq"]: profile_content += """<div><h3 style='border-bottom: 2px solid var(--accent); padding-bottom:10px;'>💬 Мои сообщения и тикеты</h3><div class="grid-container">{% for t in my_threads %}<a href="/profile/thread/{{ t.id }}" class="card card-link"><h4>{{ t.title }}</h4><p>Статус: <b style="color:var(--accent);">{{ t.status }}</b></p></a>{% else %}<p>У вас пока нет активных диалогов.</p>{% endfor %}</div></div>"""
        if mods["booking"]: profile_content += """<div><h3 style='border-bottom: 2px solid var(--accent); padding-bottom:10px;'>📅 Мои заявки на бронь</h3><div class="grid-container">{% for b in my_bookings %}<div class="card"><p><b>Услуга:</b> {{ b.service }}</p><p><b>Дата:</b> {{ b.date }}</p><p><b>Статус:</b> <span style="color:var(--accent); font-weight:bold;">{{ b.status }}</span></p>{% if b.admin_comment %}<hr><p><small><b>Ответ админа:</b> {{ b.admin_comment }}</small></p>{% endif %}</div>{% else %}<p>Заявок нет.</p>{% endfor %}</div></div>"""
        if mods["careers"]: profile_content += """<div><h3 style='border-bottom: 2px solid var(--accent); padding-bottom:10px;'>💼 Мои отклики на вакансии</h3><div class="grid-container">{% for c in my_careers %}<div class="card"><p><b>Вакансия:</b> {{ c.title }}</p><p><b>Статус:</b> <span style="color:var(--accent); font-weight:bold;">{{ c.status }}</span></p></div>{% else %}<p>Откликов нет.</p>{% endfor %}</div></div>"""
        profile_content += "</div>{% endblock %}"
        write_file(os.path.join(path, "templates"), "profile.html", profile_content)

    if mods["feedback"] or mods["faq"]:
        write_file(os.path.join(path, "templates"), "thread.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2><a href="/profile" style="text-decoration:none;">←</a> Диалог: {{ thread.title }}</h2><div class="chat-container">{% for r in replies %}<div class="msg-bubble {% if r.sender == session.user %}msg-user{% else %}msg-admin{% endif %}"><b>{{ r.sender }}</b><br>{{ r.text }}<br><small style="font-size:0.75rem; opacity:0.8;">{{ r.created_at }}</small></div>{% endfor %}</div><form action="/profile/thread/{{ thread.id }}" method="POST" style="margin-top:20px;"><textarea name="message" rows="2" style="width:100%; padding:10px; border-radius:var(--radius);" placeholder="Написать сообщение..." required></textarea><button type="submit" class="btn-submit" style="margin-top:10px;">Отправить</button></form>\n{% endblock %}""")

    if mods["survey"]: write_file(os.path.join(path, "templates"), "survey.html", """{% extends 'layout.html' %}\n{% block content %}\n<div class="form-container"><h2>Анонимное анкетирование</h2>{% if error %}<div class="alert alert-error">{{ error }}</div>{% endif %}{% if success %}<div class="alert alert-success">{{ success }}</div>{% endif %}{% if not success %}<form action="/survey" method="POST">{% for q in questions %}<div class="form-group"><label>{{ q.question_text }}</label>{% if q.question_type == 'rating' %}<input type="number" name="q_{{ q.id }}" min="1" max="10" placeholder="Оценка (1-10)" required>{% elif q.question_type == 'yesno' %}<select name="q_{{ q.id }}" required><option value="" disabled selected>Выберите ответ...</option><option value="Да">Да</option><option value="Нет">Нет</option></select>{% else %}<textarea name="q_{{ q.id }}" rows="2" placeholder="Ваш ответ..." required></textarea>{% endif %}</div>{% else %}<p>Опросов нет.</p>{% endfor %}{% if questions %}<button type="submit" class="btn-submit">Отправить</button>{% endif %}</form>{% endif %}</div>\n{% endblock %}""")
    if mods["services"]: write_file(os.path.join(path, "templates"), "services.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2>Услуги</h2><div class="grid-container">{% for s in srvs %}<div class="card"><h3>{{ s.name }}</h3><p class="price">{{ s.price }}</p><p>{{ s.description }}</p></div>{% else %}<p>Пусто.</p>{% endfor %}</div>\n{% endblock %}""")
    if mods["events"]: write_file(os.path.join(path, "templates"), "events.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2>Афиша</h2><div class="grid-container">{% for e in evs %}<div class="card" style="border-left: 5px solid var(--accent);"><h3>{{ e.title }}</h3><p style="color:#888; font-weight:bold;">📅 {{ e.date }}</p><p>📍 Место: {{ e.location }}</p></div>{% else %}<p>Пусто.</p>{% endfor %}</div>\n{% endblock %}""")
    if mods["news"]: write_file(os.path.join(path, "templates"), "news.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2>Новости</h2><div class="grid-container">{% for n in news_list %}<div class="card"><small class="date">{{ n.date_posted }}</small><h3>{{ n.title }}</h3><p>{{ n.content }}</p></div>{% else %}<p>Пусто.</p>{% endfor %}</div>\n{% endblock %}""")
    if mods["portfolio"]: write_file(os.path.join(path, "templates"), "portfolio.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2>Портфолио</h2><div class="grid-container">{% for p in projects %}<div class="card" style="padding:0; overflow:hidden;"><img src="{{ p.image_url }}" style="width:100%; height:200px; object-fit:cover;"><div style="padding:20px;"><h3>{{ p.title }}</h3><p>{{ p.description }}</p></div></div>{% else %}<p>Пусто.</p>{% endfor %}</div>\n{% endblock %}""")
    if mods["team"]: write_file(os.path.join(path, "templates"), "team.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2>Команда</h2><div class="grid-container">{% for m in members %}<div class="card" style="text-align:center;"><h3 style="color:var(--accent);">{{ m.name }}</h3><h4>{{ m.position }}</h4><p>{{ m.bio }}</p></div>{% else %}<p>Пусто.</p>{% endfor %}</div>\n{% endblock %}""")
    if mods["reviews"]: write_file(os.path.join(path, "templates"), "reviews.html", """{% extends 'layout.html' %}\n{% block content %}\n<div class="form-container"><h2>Оставить отзыв</h2>{% if session.user %}{% if error %}<div class="alert alert-error">{{ error }}</div>{% endif %}{% if success %}<div class="alert alert-success">{{ success }}</div>{% endif %}<form action="/reviews" method="POST"><div class="form-group"><label>Ваше имя</label><input type="text" name="author" required minlength="2"></div><div class="form-group"><label>Оценка (1-5)</label><input type="number" name="rating" min="1" max="5" value="5" required></div><div class="form-group"><label>Текст отзыва</label><textarea name="text" rows="3" required minlength="5"></textarea></div><button type="submit" class="btn-submit">Отправить отзыв</button></form>{% else %}<div class="alert alert-error">Пожалуйста, <a href="/login" style="color:inherit;text-decoration:underline;">войдите</a>, чтобы оставить отзыв.</div>{% endif %}</div><h2>Отзывы клиентов</h2><div class="grid-container">{% for r in rev_list %}<div class="card"><h3>{{ r.author }} <span style="color: gold;">★{{ r.rating }}</span></h3><p><i>"{{ r.text }}"</i></p></div>{% else %}<p>Отзывов пока нет.</p>{% endfor %}</div>\n{% endblock %}""")
    if mods["booking"]: write_file(os.path.join(path, "templates"), "booking.html", """{% extends 'layout.html' %}\n{% block content %}\n<div class="form-container"><h2>Забронировать</h2>{% if session.user %}{% if error %}<div class="alert alert-error">{{ error }}</div>{% endif %}{% if success %}<div class="alert alert-success">{{ success }}</div>{% endif %}<form action="/booking" method="POST"><div class="form-group"><label>Ваше имя</label><input type="text" name="name" required minlength="2"></div><div class="form-group"><label>Телефон</label><input type="text" name="phone" required minlength="5"></div><div class="form-group"><label>Желаемая дата</label><input type="date" name="date" required></div><div class="form-group"><label>Услуга</label><input type="text" name="service"></div><button type="submit" class="btn-submit">Отправить заявку</button></form>{% else %}<div class="alert alert-error">Пожалуйста, <a href="/login" style="color:inherit;text-decoration:underline;">войдите</a>, чтобы оставить заявку.</div>{% endif %}</div>\n{% endblock %}""")
    if mods["careers"]: write_file(os.path.join(path, "templates"), "careers.html", """{% extends 'layout.html' %}\n{% block content %}\n<div class="form-container"><h2>Откликнуться на вакансию</h2>{% if session.user %}{% if error %}<div class="alert alert-error">{{ error }}</div>{% endif %}{% if success %}<div class="alert alert-success">{{ success }}</div>{% endif %}<form action="/careers" method="POST"><div class="form-group"><label>ФИО</label><input type="text" name="name" required minlength="2"></div><div class="form-group"><label>Телефон</label><input type="text" name="phone" required minlength="5"></div><div class="form-group"><label>Вакансия</label><select name="vacancy_id" required><option value="" disabled selected>Выберите вакансию...</option>{% for v in vacancies %}<option value="{{ v.id }}">{{ v.title }}</option>{% endfor %}</select></div><div class="form-group"><label>Опыт работы (кратко)</label><textarea name="experience" rows="4"></textarea></div><button type="submit" class="btn-submit">Отправить резюме</button></form>{% else %}<div class="alert alert-error">Пожалуйста, <a href="/login" style="color:inherit;text-decoration:underline;">войдите</a>, чтобы откликнуться на вакансию.</div>{% endif %}</div>\n{% endblock %}""")
    if mods["feedback"]: write_file(os.path.join(path, "templates"), "feedback.html", """{% extends 'layout.html' %}\n{% block content %}\n<div class="form-container"><h2>Свяжитесь с нами</h2>{% if session.user %}{% if error %}<div class="alert alert-error">{{ error }}</div>{% endif %}{% if success %}<div class="alert alert-success">{{ success }}</div>{% endif %}<form action="/feedback" method="POST"><div class="form-group"><label>Тема обращения</label><input type="text" name="subject" required minlength="2"></div><div class="form-group"><label>Сообщение</label><textarea name="message" rows="4" required minlength="5"></textarea></div><button type="submit" class="btn-submit">Начать чат с поддержкой</button></form>{% else %}<div class="alert alert-error">Пожалуйста, <a href="/login" style="color:inherit;text-decoration:underline;">войдите</a>, чтобы написать нам.</div>{% endif %}</div>\n{% endblock %}""")
    if mods["about"]: write_file(os.path.join(path, "templates"), "about.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2>О нас</h2><div class="card"><p>Мы лучшая компания.</p></div>\n{% endblock %}""")
    if mods["faq"]: write_file(os.path.join(path, "templates"), "faq.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2>FAQ (Частые вопросы)</h2>\n<div class="faq-container" style="margin-bottom: 40px;">{% for f in faqs %}<div class="card" style="margin-bottom: 15px;"><h3 style="color: var(--accent);">{{ f.question }}</h3><p>{{ f.answer }}</p></div>{% else %}<p>Пока нет добавленных вопросов.</p>{% endfor %}</div>\n<div class="form-container" style="max-width: 100%;"><h3>Не нашли ответ? Задайте свой вопрос!</h3>{% if session.user %}{% if error %}<div class="alert alert-error">{{ error }}</div>{% endif %}{% if success %}<div class="alert alert-success">{{ success }}</div>{% endif %}<form action="/faq" method="POST"><div class="form-group"><label>Ваш вопрос</label><textarea name="new_question" rows="3" required minlength="5" placeholder="Напишите ваш вопрос здесь..."></textarea></div><button type="submit" class="btn-submit">Отправить вопрос</button></form>{% else %}<div class="alert alert-error">Пожалуйста, <a href="/login" style="color:inherit;text-decoration:underline;">войдите</a>, чтобы задать вопрос.</div>{% endif %}</div>\n{% endblock %}""")

    if mods["catalog"]:
        catalog_html = """{% extends 'layout.html' %}\n{% block content %}\n<h2>Каталог</h2>\n<div class="grid-container">{% for item in items %}\n<div class="card"><h3>{{ item.name }}</h3><p class="price">{{ item.price }} ₽</p><p>{{ item.description }}</p>\n"""
        if mods["cart"]: catalog_html += '<br>{% if session.user %}<a href="/cart/add/{{ item.id }}" class="btn-primary" style="text-align:center;">В корзину</a>{% else %}<a href="/login" class="btn-outline" style="text-align:center;">Войти для покупки</a>{% endif %}'
        catalog_html += "</div>{% else %}<p>Пусто.</p>{% endfor %}</div>{% endblock %}"
        write_file(os.path.join(path, "templates"), "catalog.html", catalog_html)

    if mods["cart"]: write_file(os.path.join(path, "templates"), "cart.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2>Корзина</h2>{% if items %}<div class="grid-container">{% for i in items %}<div class="card"><h3>{{ i.name }}</h3><p>{{ i.price }}₽</p></div>{% endfor %}</div><div class="card" style="margin-top: 20px;"><h3>Итого: {{ total }}₽</h3><br><a href="/cart/clear" class="btn-logout">Очистить</a></div>{% else %}<p>Пусто</p>{% endif %}\n{% endblock %}""")

    # --- АДМИНКА ---
    admin_html = """{% extends 'layout.html' %}\n{% block content %}\n<h2>Панель администратора</h2>\n{% if error %}<div class="alert alert-error">{{ error }}</div>{% endif %}\n{% if success %}<div class="alert alert-success">{{ success }}</div>{% endif %}\n"""
    if mods["survey"]: admin_html += """<div class="admin-panel"><h3>Добавить вопрос в Анкету</h3><form action="/admin" method="POST" class="inline-form"><input type="hidden" name="form_type" value="survey_question"><input type="text" name="question_text" placeholder="Текст вопроса" required minlength="5"><select name="question_type" style="padding: 12px; border-radius: var(--radius); border: none; background: var(--secondary-bg); color: var(--text); font-family: var(--font);"><option value="text">Текстовый ответ</option><option value="rating">Оценка (1-10)</option><option value="yesno">Да / Нет</option></select><button type="submit" class="btn-submit">Добавить</button></form></div>"""
    if mods["careers"]: admin_html += """<div class="admin-panel"><h3>Добавить Вакансию</h3><form action="/admin" method="POST" class="inline-form"><input type="hidden" name="form_type" value="vacancy"><input type="text" name="title" placeholder="Название вакансии" required minlength="2"><input type="text" name="description" placeholder="Описание"><button type="submit" class="btn-submit">Добавить</button></form></div>"""
    if mods["services"]: admin_html += """<div class="admin-panel"><h3>Добавить Услугу</h3><form action="/admin" method="POST" class="inline-form"><input type="hidden" name="form_type" value="service"><input type="text" name="name" placeholder="Название услуги" required minlength="2"><input type="text" name="price" placeholder="Цена" required><input type="text" name="description" placeholder="Описание"><button type="submit" class="btn-submit">Добавить</button></form></div>"""
    if mods["events"]: admin_html += """<div class="admin-panel"><h3>Добавить Мероприятие (Афиша)</h3><form action="/admin" method="POST" class="inline-form"><input type="hidden" name="form_type" value="event"><input type="text" name="title" placeholder="Название" required minlength="2"><input type="date" name="date" required><input type="text" name="location" placeholder="Место проведения"><button type="submit" class="btn-submit">Добавить</button></form></div>"""
    if mods["news"]: admin_html += """<div class="admin-panel"><h3>Добавить Новость</h3><form action="/admin" method="POST" class="inline-form"><input type="hidden" name="form_type" value="news"><input type="text" name="title" placeholder="Заголовок новости" required minlength="3"><input type="text" name="content" placeholder="Текст новости" required minlength="10"><button type="submit" class="btn-submit">Опубликовать</button></form></div>"""
    if mods["portfolio"]: admin_html += """<div class="admin-panel"><h3>Добавить в Портфолио</h3><form action="/admin" method="POST" class="inline-form"><input type="hidden" name="form_type" value="portfolio"><input type="text" name="title" placeholder="Название проекта" required minlength="2"><input type="text" name="image_url" placeholder="Ссылка на картинку (URL)"><input type="text" name="description" placeholder="Краткое описание"><button type="submit" class="btn-submit">Добавить</button></form></div>"""
    if mods["catalog"]: admin_html += """<div class="admin-panel"><h3>Добавить товар</h3><form action="/admin" method="POST" class="inline-form"><input type="hidden" name="form_type" value="product"><input type="text" name="name" placeholder="Название" required minlength="2"><input type="number" name="price" placeholder="Цена" step="0.01" min="0.1" required><input type="text" name="description" placeholder="Описание"><button type="submit" class="btn-submit">Добавить</button></form></div>"""
    if mods["team"]: admin_html += """<div class="admin-panel"><h3>Добавить Сотрудника</h3><form action="/admin" method="POST" class="inline-form"><input type="hidden" name="form_type" value="team"><input type="text" name="name" placeholder="Имя сотрудника" required minlength="2"><input type="text" name="position" placeholder="Должность" required minlength="2"><input type="text" name="bio" placeholder="Краткое описание"><button type="submit" class="btn-submit">Добавить</button></form></div>"""
    if mods["faq"]: admin_html += """<div class="admin-panel"><h3>Добавить FAQ (вручную)</h3><form action="/admin" method="POST" class="inline-form"><input type="hidden" name="form_type" value="faq"><input type="text" name="question" placeholder="Вопрос" required minlength="5"><input type="text" name="answer" placeholder="Ответ" required minlength="5"><button type="submit" class="btn-submit">Добавить</button></form></div>"""

    admin_html += "<h3>Управление данными</h3><div class='grid-container'>"
    if mods["survey"]: admin_html += """<a href="/admin/survey" class="card card-link"><h4>📊 Ответы на Анкеты</h4>{% if stats.surv_ans > 0 %}<p>Всего получено ответов: <b>{{ stats.surv_ans }}</b></p>{% else %}<p>Ответов пока нет.</p>{% endif %}</a>"""
    if mods["booking"]: admin_html += """<a href="/admin/bookings" class="card card-link"><h4>📅 Заявки на Бронь</h4>{% if stats.book_total > 0 %}<p>Новых (В обработке): <b style="color:var(--accent);">{{ stats.book_new }}</b></p><p>Всего заявок: {{ stats.book_total }}</p>{% else %}<p>Нет заявок.</p>{% endif %}</a>"""
    if mods["careers"]: admin_html += """<a href="/admin/careers" class="card card-link"><h4>💼 Отклики на Вакансии</h4>{% if stats.car_total > 0 %}<p>Нерассмотренных: <b style="color:var(--accent);">{{ stats.car_new }}</b></p><p>Всего откликов: {{ stats.car_total }}</p>{% else %}<p>Нет откликов.</p>{% endif %}</a>"""
    if mods["reviews"]: admin_html += """<a href="/admin/reviews" class="card card-link"><h4>⭐ Отзывы клиентов</h4>{% if stats.rev_total > 0 %}<p>Всего отзывов: <b>{{ stats.rev_total }}</b></p>{% else %}<p>Нет отзывов.</p>{% endif %}</a>"""
    if mods["faq"] or mods["feedback"]: admin_html += """<a href="/admin/messages" class="card card-link"><h4>💬 Обращения и FAQ</h4>{% if stats.threads_total > 0 %}<p>Ожидают ответа: <b style="color:red;">{{ stats.threads_new }}</b></p><p>Всего диалогов: {{ stats.threads_total }}</p>{% else %}<p>Нет обращений.</p>{% endif %}</a>"""
    admin_html += "</div>{% endblock %}"
    write_file(os.path.join(path, "templates"), "admin.html", admin_html)

    if mods["feedback"] or mods["faq"]:
        write_file(os.path.join(path, "templates"), "admin_messages.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2><a href="/admin" style="text-decoration:none;">←</a> Управление Обращениями и FAQ</h2><div class="grid-container">{% for t in threads %}<a href="/admin/thread/{{ t.id }}" class="card card-link"><p><b>От:</b> {{ t.username }}</p><h4>{{ t.title }}</h4><p>Статус: <span style="color: {% if t.status == 'Ожидает ответа пользователя' %}green{% else %}red{% endif %}; font-weight:bold;">{{ t.status }}</span></p></a>{% else %}<p>Обращений нет.</p>{% endfor %}</div>\n{% endblock %}""")
        write_file(os.path.join(path, "templates"), "admin_thread.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2><a href="/admin/messages" style="text-decoration:none;">←</a> Диалог: {{ thread.title }}</h2><p>Пользователь: <b>{{ thread.username }}</b></p><div class="chat-container">{% for r in replies %}<div class="msg-bubble {% if r.sender == 'Администратор' %}msg-user{% else %}msg-admin{% endif %}"><b>{{ r.sender }}</b><br>{{ r.text }}<br><small style="font-size:0.75rem; opacity:0.8;">{{ r.created_at }}</small></div>{% endfor %}</div><form action="/admin/thread/{{ thread.id }}" method="POST" style="margin-top:20px;"><textarea name="reply" rows="3" style="width:100%; padding:10px; border-radius:var(--radius);" placeholder="Написать ответ..." required></textarea><div style="display:flex; gap:10px; margin-top:10px; flex-wrap:wrap;"><button type="submit" name="action" value="reply" class="btn-submit">Просто ответить</button>{% if faq_enabled %}<button type="submit" name="action" value="publish_faq" class="btn-primary">Ответить и добавить в FAQ</button>{% endif %}</div></form>\n{% endblock %}""")

    if mods["booking"]: write_file(os.path.join(path, "templates"), "admin_bookings.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2><a href="/admin" style="text-decoration:none;">←</a> Управление заявками</h2><div class="grid-container">{% for b in bookings %}<div class="card"><p><b>Клиент:</b> {{ b.name }} ({{ b.phone }})</p><p><b>Услуга:</b> {{ b.service }} (Дата: {{ b.date }})</p><p><b>Текущий статус:</b> {{ b.status }}</p><hr><form action="/admin/bookings" method="POST"><input type="hidden" name="b_id" value="{{ b.id }}"><select name="status" style="width:100%; margin-bottom:10px; padding:5px;"><option value="В обработке" {% if b.status == 'В обработке' %}selected{% endif %}>В обработке</option><option value="В работе" {% if b.status == 'В работе' %}selected{% endif %}>В работе</option><option value="Выполнено" {% if b.status == 'Выполнено' %}selected{% endif %}>Выполнено</option></select><textarea name="comment" rows="2" style="width:100%; margin-bottom:10px;" placeholder="Комментарий для клиента">{{ b.admin_comment or '' }}</textarea><button type="submit" class="btn-submit">Сохранить</button></form></div>{% else %}<p>Заявок нет.</p>{% endfor %}</div>\n{% endblock %}""")
    if mods["careers"]: write_file(os.path.join(path, "templates"), "admin_careers.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2><a href="/admin" style="text-decoration:none;">←</a> Управление откликами</h2><div class="grid-container">{% for c in apps %}<div class="card"><p><b>Кандидат:</b> {{ c.name }} ({{ c.phone }})</p><p><b>Вакансия:</b> {{ c.title }}</p><p><b>Опыт:</b> {{ c.experience }}</p><p><b>Текущий статус:</b> {{ c.status }}</p><hr><form action="/admin/careers" method="POST"><input type="hidden" name="c_id" value="{{ c.id }}"><select name="status" style="width:100%; margin-bottom:10px; padding:5px;"><option value="На рассмотрении" {% if c.status == 'На рассмотрении' %}selected{% endif %}>На рассмотрении</option><option value="Приглашаем на собеседование" {% if c.status == 'Приглашаем на собеседование' %}selected{% endif %}>Приглашаем на собеседование</option><option value="Отказ" {% if c.status == 'Отказ' %}selected{% endif %}>Отказ</option></select><button type="submit" class="btn-submit">Сохранить статус</button></form></div>{% else %}<p>Откликов нет.</p>{% endfor %}</div>\n{% endblock %}""")
    if mods["reviews"]: write_file(os.path.join(path, "templates"), "admin_reviews.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2><a href="/admin" style="text-decoration:none;">←</a> Отзывы клиентов</h2><div class="hero-section" style="margin-bottom:20px; padding:20px;"><h3>Средняя оценка: <span style="color:gold;">★ {{ avg_rating }}</span></h3></div><div style="margin-bottom:20px;"><a href="/admin/reviews?sort=desc" class="btn-nav {% if current_sort == 'desc' %}btn-dark{% else %}btn-outline{% endif %}">Сначала хорошие</a> <a href="/admin/reviews?sort=asc" class="btn-nav {% if current_sort == 'asc' %}btn-dark{% else %}btn-outline{% endif %}">Сначала плохие</a></div><div class="grid-container">{% for r in reviews %}<div class="card"><h3>{{ r.author }} <span style="color:gold;">★{{ r.rating }}</span></h3><p><i>"{{ r.text }}"</i></p></div>{% else %}<p>Отзывов нет.</p>{% endfor %}</div>\n{% endblock %}""")
    if mods["survey"]: write_file(os.path.join(path, "templates"), "admin_survey.html", """{% extends 'layout.html' %}\n{% block content %}\n<h2><a href="/admin" style="text-decoration:none;">←</a> Статистика Анкетирования</h2><div class="grid-container">{% for s in stats %}<div class="card"><h4>{{ s.text }}</h4><hr>{% if s.type == 'rating' %}<h2 style="color:var(--accent); text-align:center; font-size:3rem;">{{ s.value }} <small style="font-size:1rem; color:#888;">/ 10</small></h2>{% elif s.type == 'yesno' %}<p>Да: <b style="color:green;">{{ s.yes }}</b> | Нет: <b style="color:red;">{{ s.no }}</b></p><div style="width:100%; background:#eee; height:20px; border-radius:10px; overflow:hidden; display:flex;"><div style="width:{% if (s.yes+s.no)>0 %}{{ (s.yes/(s.yes+s.no))*100 }}{% else %}0{% endif %}%; background:green;"></div><div style="width:{% if (s.yes+s.no)>0 %}{{ (s.no/(s.yes+s.no))*100 }}{% else %}0{% endif %}%; background:red;"></div></div>{% endif %}</div>{% endfor %}</div><h3 style="margin-top:40px;">Текстовые ответы:</h3><div class="grid-container">{% for t in text_answers %}<div class="card"><h4>{{ t.text }}</h4><hr><div style="max-height:300px; overflow-y:auto;">{% for a in t.answers %}<p style="background:var(--secondary-bg); padding:10px; border-radius:5px; margin-bottom:5px;">{{ a.answer }}<br><small style="color:#888;">{{ a.created_at }}</small></p>{% else %}<p>Нет ответов.</p>{% endfor %}</div></div>{% endfor %}</div>\n{% endblock %}""")

    # --- 4. CSS ---
    write_file(os.path.join(path, "static/css"), "style.css", get_flask_css(accent, primary_bg, secondary_bg, radius, nav_pos, font_family, box_shadow, border_style, hover_effect, padding_base))

def get_flask_css(accent, primary, secondary, radius, nav_pos, font_family, box_shadow, border_style, hover_effect, padding_base):
    body_flex, header_css, nav_flex, nav_align = "column", "width: 100%;", "row", "align-items: center;"
    if nav_pos in ['left', 'right']:
        body_flex = "row" if nav_pos == 'left' else "row-reverse"
        header_css = "width: 250px; min-height: 100vh; flex-shrink: 0;"
        nav_flex, nav_align = "column", "align-items: flex-start;"
    text_color = "#333" if primary.lower() in ["#ffffff", "#fff"] else "#f4f4f4"
    bubble_admin_bg = primary if primary.lower() not in ["#ffffff", "#fff"] else "#fff"
    bubble_admin_border = border_style if border_style != "none" else "1px solid #ccc"

    mobile_media_query = f"""
@media (max-width: 768px) {{
    body {{ flex-direction: column; }}
    .main-header {{ width: 100%; min-height: auto; border-right: none; border-bottom: var(--border); padding: 15px; position: sticky; top: 0; z-index: 100; }}
    .header-top {{ display: flex; justify-content: space-between; align-items: center; width: 100%; }}
    .logo a {{ margin-bottom: 0; }}
    .menu-toggle {{ display: block; background: none; border: none; font-size: 2rem; color: var(--accent); cursor: pointer; }}
    .navbar {{ display: none; width: 100%; flex-direction: column; align-items: stretch; gap: 15px; margin-top: 15px; }}
    .navbar.active {{ display: flex; }}
    .nav-links {{ flex-direction: column; align-items: stretch; width: 100%; gap: 10px; }}
    .nav-links li {{ width: 100%; text-align: center; }}
    .nav-links a {{ display: block; width: 100%; padding: 12px 0; }}
    .btn-nav {{ justify-content: center; }}
    .container {{ padding: 15px; }}
    .grid-container {{ grid-template-columns: 1fr; gap: 15px; }}
    .inline-form {{ flex-direction: column; }}
    .inline-form input, .inline-form select, .inline-form button {{ width: 100%; }}
}}
"""

    return f""":root {{ --accent: {accent}; --primary-bg: {primary}; --secondary-bg: {secondary}; --radius: {radius}; --shadow: {box_shadow}; --border: {border_style}; --padding: {padding_base}; --text: {text_color}; --font: {font_family}; }}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ font-family: var(--font); background: var(--secondary-bg); color: var(--text); display: flex; flex-direction: {body_flex}; min-height: 100vh; }}
.main-header {{ background: var(--primary-bg); box-shadow: var(--shadow); border-right: var(--border); border-bottom: var(--border); {header_css} padding: var(--padding); z-index: 10; }}
.header-top {{ display: flex; flex-direction: column; }}
.logo a {{ font-size: 1.8rem; font-weight: bold; color: var(--accent); text-decoration: none; display:block; margin-bottom: 20px; }}
.menu-toggle {{ display: none; }}
.navbar {{ display: flex; flex-direction: {nav_flex}; gap: 30px; justify-content: space-between; {nav_align} }}
.nav-links {{ list-style: none; display: flex; flex-direction: {nav_flex}; gap: 15px; flex-wrap: wrap; align-items: center; }}
.nav-links a:not(.btn-nav) {{ text-decoration: none; color: var(--text); font-weight: 600; font-size: 1.1rem; transition: 0.2s; padding: 8px 0; }}
.nav-links a:not(.btn-nav):hover {{ color: var(--accent); }}
.btn-nav {{ padding: 8px 18px; border-radius: var(--radius); text-decoration: none; font-weight: bold; transition: 0.3s; border: 2px solid transparent; display: inline-flex; align-items: center; height: 42px; }}
.btn-nav-primary {{ background: var(--accent); color: white !important; }}
.btn-outline {{ border-color: var(--accent); color: var(--text) !important; background: transparent; }}
.btn-outline:hover {{ background: var(--accent); color: white !important; }}
.btn-dark {{ background: #2c3e50; color: white !important; }}
.btn-danger {{ background: #e74c3c; color: white !important; }}
.container {{ flex: 1; padding: 40px; width: 100%; max-width: 1200px; margin: 0 auto; }}
.hero-section {{ background: var(--primary-bg); padding: 40px; border-radius: var(--radius); border: var(--border); box-shadow: var(--shadow); text-align: center; }}
.btn-primary, .btn-submit {{ background: var(--accent); color: white !important; padding: 12px 20px; border: none; border-radius: var(--radius); cursor: pointer; text-decoration: none; display: inline-block; font-weight: bold; transition: 0.3s; }}
.btn-primary:hover, .btn-submit:hover {{ opacity: 0.8; transform: scale(1.02); }}
.btn-logout {{ color: #e74c3c !important; font-weight: bold; text-decoration: none; }}
.form-container, .admin-panel {{ background: var(--primary-bg); padding: var(--padding); border-radius: var(--radius); box-shadow: var(--shadow); border: var(--border); max-width: 600px; margin-bottom: 30px; width: 100%; }}
.form-group {{ margin-bottom: 20px; }}
.form-group label {{ display: block; margin-bottom: 8px; font-weight: bold; }}
.form-group input, .form-group textarea, .form-group select {{ width: 100%; padding: 12px; border: 2px solid var(--secondary-bg); border-radius: var(--radius); font-family: var(--font); background: var(--secondary-bg); color: var(--text); transition: 0.3s; }}
.form-group input:focus, .form-group textarea:focus {{ border-color: var(--accent); outline: none; }}
.grid-container {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 25px; margin-top: 20px; margin-bottom: 40px; }}
.card {{ background: var(--primary-bg); padding: var(--padding); border-radius: var(--radius); box-shadow: var(--shadow); border: var(--border); transition: 0.3s; display: flex; flex-direction: column; }}
.card:hover {{ {hover_effect} }}
.card .price {{ font-size: 1.4rem; color: var(--accent); font-weight: bold; margin: 15px 0; }}
.card-link {{ text-decoration: none; color: inherit; display: block; cursor: pointer; }}
.card-link:hover h4 {{ color: var(--accent); transition: 0.2s; }}
.alert {{ padding: 15px; margin-bottom: 20px; border-radius: var(--radius); font-weight: bold; border: var(--border); }}
.alert-error {{ background-color: #ffebee; color: #c62828; border-color: #ef9a9a; }}
.alert-success {{ background-color: #e8f5e9; color: #2e7d32; border-color: #a5d6a7; }}
.inline-form {{ display: flex; gap: 15px; flex-wrap: wrap; }}
.inline-form input, .inline-form select {{ flex: 1; min-width: 180px; padding: 12px; border: none; background: var(--secondary-bg); color: var(--text); border-radius: var(--radius); font-family: var(--font); }}
.chat-container {{ display: flex; flex-direction: column; gap: 15px; max-height: 500px; overflow-y: auto; padding: 20px; background: var(--secondary-bg); border-radius: var(--radius); border: var(--border); }}
.msg-bubble {{ max-width: 80%; padding: 12px 18px; border-radius: 18px; line-height: 1.4; }}
.msg-user {{ align-self: flex-end; background: var(--accent); color: white; border-bottom-right-radius: 4px; }}
.msg-admin {{ align-self: flex-start; background: {bubble_admin_bg}; color: var(--text); border: {bubble_admin_border}; box-shadow: var(--shadow); border-bottom-left-radius: 4px; }}
{mobile_media_query}"""

# --- 4. СПРАВОЧНИК ---
def quick_help():
    clear()
    header()
    print(f"{Colors.BOLD}ПОДРОБНЫЕ ИНСТРУКЦИИ:{Colors.RESET}")
    print(f"\n{Colors.CYAN}--- РАБОТА С PYTHON + FLASK + SQLITE ---{Colors.RESET}")
    print(f"{Colors.GREEN}Шаг 1: Инициализация БД{Colors.RESET}")
    print("Откройте терминал в папке проекта и введите:")
    print("  > python init_db.py")
    print(f"{Colors.GREEN}Шаг 2: Просмотр базы данных{Colors.RESET}")
    print("Используйте программу 'DB Browser for SQLite' для просмотра файла .db.")
    print(f"{Colors.GREEN}Шаг 3: Запуск сервера{Colors.RESET}")
    print("В терминале введите:")
    print("  > python app.py")
    print("Откройте браузер и перейдите по адресу: http://127.0.0.1:5000")
    print(f"{Colors.GREEN}Шаг 4: Дизайн{Colors.RESET}")
    print("Все HTML файлы лежат в папке /templates. Стили в /static/css/style.css.")
    input("\nНажмите Enter для выхода в меню...")

# --- ГЛАВНЫЙ ЦИКЛ ---
def main():
    while True:
        clear()
        header()
        env_status = check_env()

        print(f"\n{Colors.BOLD}ГЛАВНОЕ МЕНЮ:{Colors.RESET}")
        print(f"1. {Colors.GREEN}[Install Libs]{Colors.RESET} Установка Python библиотек")
        print(f"2. {Colors.GREEN}[Project Init]{Colors.RESET} Создать структуру сайта (Flask / SQLite)")
        print(f"3. {Colors.GREEN}[Quick Help]  {Colors.RESET} Инструкции по запуску проектов")
        print(f"\n{Colors.YELLOW}c. Очистить экран | q. Выход{Colors.RESET}")

        cmd = input(f"\nВведите команду > ").lower()
        if cmd == '1':
            install_libs()
            input("\nНажмите Enter...")
        elif cmd == '2':
            init_project(env_status)
        elif cmd == '3':
            quick_help()
        elif cmd == 'c':
            clear()
        elif cmd == 'q':
            break

def start():
    try:
        main()
    except KeyboardInterrupt:
        sys.exit()

if __name__ == "__main__":
    start()
