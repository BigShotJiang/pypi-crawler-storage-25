"""SDK initialization and lifecycle."""

from __future__ import annotations

import atexit
import importlib.metadata
import logging
import os
from typing import Any, Literal

from pontem import _emit, _metrics
from pontem.log import PontemFormatter

_initialized = False
_logger = logging.getLogger("pontem.sdk")

# Environment variables the Pontem agent sets on managed devices.
_AGENT_ENV_MAP = {
    "device.id": "PONTEM_DEVICE_ID",
    "pontem.tenant.id": "PONTEM_TENANT_ID",
    "pontem.config.version": "PONTEM_CONFIG_VERSION",
}


def _infer_service_version(service_name: str) -> str | None:
    """Read version from installed package metadata.

    Tries the name as-is, then underscore ↔ hyphen normalization.
    """
    candidates = {service_name}
    candidates.add(service_name.replace("_", "-"))
    candidates.add(service_name.replace("-", "_"))

    for name in candidates:
        try:
            return importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            continue
    return None


def init(
    *,
    service_name: str,
    service_version: str | None = None,
    emit_dir: str | None = None,
    emit_target: Literal["file", "stdout"] | None = None,
    stdlib_logging: bool = False,
) -> None:
    """Initialize the Pontem SDK.

    Call once at startup.

    Telemetry is written as JSONL. By default the SDK writes per-channel
    files under ``emit_dir`` (or ``$PONTEM_EMIT_DIR``) for the on-host
    Pontem agent to ship. Pass ``emit_target="stdout"`` (or set
    ``PONTEM_EMIT_TARGET=stdout``) for compose deployments where a
    sidecar collector tails the container's stdout.

    Args:
        service_name: Identifies this service in all emitted telemetry.
        service_version: Override auto-detected version.
        emit_dir: Override ``PONTEM_EMIT_DIR`` env var and the default
            ``/var/lib/pontem/services/<service_name>/logs``. Ignored when
            ``emit_target="stdout"``.
        emit_target: ``"file"`` (default) or ``"stdout"``. Falls back to
            ``$PONTEM_EMIT_TARGET`` then to ``"file"``.
        stdlib_logging: If True, install :class:`PontemFormatter` on
            every handler currently attached to the root logger, so
            existing ``logging.getLogger(...).info(...)`` calls produce
            Pontem JSONL on the wire. Existing destinations, rotation
            policies, and filters are untouched.

            Configure your logging (``basicConfig``, ``dictConfig``,
            etc.) BEFORE calling :func:`init`; the formatter install
            step requires root handlers to be attached.
    """
    global _initialized
    if _initialized:
        _logger.warning("pontem.init() already called, ignoring")
        return

    if stdlib_logging and not logging.getLogger().handlers:
        # Validate up front — duplicates the check inside
        # PontemFormatter.install() but lets us fail before any state
        # mutation (e.g. before _emit.configure starts the writer
        # thread), so the user's program is untouched on misorder.
        raise RuntimeError(
            "pontem.init(stdlib_logging=True) requires the root logger to "
            "have handlers attached. Run logging.basicConfig() (or your "
            "own logging setup) before pontem.init()."
        )

    service_version = service_version or _infer_service_version(service_name)

    # Resource attributes — attached to every emitted record.
    resource: dict[str, Any] = {"service.name": service_name}
    if service_version:
        resource["service.version"] = service_version
    for attr_key, env_var in _AGENT_ENV_MAP.items():
        val = os.environ.get(env_var)
        if val:
            resource[attr_key] = val

    # Resolve emit_target: kwarg > env var > default "file".
    target = emit_target or os.environ.get("PONTEM_EMIT_TARGET") or "file"

    # In file mode, default emit dir is /var/lib/pontem/services/<service_name>/logs.
    # In stdout mode, emit_dir is irrelevant.
    if target == "file" and not emit_dir and not os.environ.get("PONTEM_EMIT_DIR"):
        emit_dir = f"/var/lib/pontem/services/{service_name}/logs"

    path = _emit.configure(emit_dir, resource, emit_target=target)

    # Register metrics aggregation flush with the emit thread.
    _emit.register_periodic(_metrics._collect)

    if stdlib_logging:
        # Install the formatter on the user's existing handler chain.
        # Pass the freshly built resource dict explicitly —
        # `_sdk._initialized` is still False here, so the formatter's
        # auto-fallback wouldn't pick it up otherwise. Done before the
        # startup debug log below so even that comes out as Pontem JSON
        # via the user's chain rather than a one-off plaintext line.
        PontemFormatter.install(resource=resource)

    if path:
        _logger.debug("pontem emit dir: %s", path)
    elif target == "stdout":
        _logger.debug("pontem emit: stdout")
    else:
        _logger.debug("emit dir could not be configured")

    atexit.register(shutdown)
    _initialized = True


def shutdown() -> None:
    """Flush aggregated metrics, drain logs, and close emit files."""
    global _initialized
    if not _initialized:
        return
    _emit.close()
    _initialized = False
