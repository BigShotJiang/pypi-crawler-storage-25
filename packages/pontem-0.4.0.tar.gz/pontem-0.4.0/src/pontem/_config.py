"""Configuration reader for Pontem agent-managed config."""

from __future__ import annotations

import json
import logging
import os
from typing import Any, TypeVar, overload

_logger = logging.getLogger("pontem.config")

T = TypeVar("T")

_DEFAULT_CONFIG_DIR = "/var/lib/pontem/config"


class Config:
    """Callable config reader with reload support.

    Example::

        import pontem

        threshold = pontem.config("scoring", "confidence_threshold", default=0.85)
        pontem.config.reload()  # re-read from disk
    """

    def __init__(self) -> None:
        self._cache: dict[str, dict[str, Any]] = {}

    def _load(self, namespace: str) -> dict[str, Any]:
        """Load a namespace's config from its agent-managed JSON file."""
        if namespace in self._cache:
            return self._cache[namespace]

        config_dir = os.environ.get("PONTEM_CONFIG_DIR", _DEFAULT_CONFIG_DIR)
        config_file = os.path.join(config_dir, f"{namespace}.json")

        try:
            with open(config_file) as f:
                data = json.load(f)
        except FileNotFoundError:
            _logger.debug("No agent config at %s, using defaults", config_file)
            data = {}
        except json.JSONDecodeError:
            _logger.warning("Invalid JSON in %s, using defaults", config_file)
            data = {}

        self._cache[namespace] = data
        return data

    @overload
    def __call__(self, namespace: str, key: str) -> str | None: ...

    @overload
    def __call__(self, namespace: str, key: str, *, default: T) -> T: ...

    def __call__(self, namespace: str, key: str, *, default: Any = None) -> Any:
        """Read a config value managed by the Pontem agent.

        Each namespace lives in its own JSON file at
        ``<PONTEM_CONFIG_DIR>/<namespace>.json``, written by the agent as a
        flat ``{key: value}`` map.

        Example::

            pontem.config("scoring", "confidence_threshold")
            pontem.config("scoring", "confidence_threshold", default=0.85)

        Args:
            namespace: Namespace name (matches the JSON filename, without
                the ``.json`` extension).
            key: Config key within the namespace.
            default: Fallback value if the file or key is missing.
        """
        data = self._load(namespace)
        if key in data:
            return data[key]
        return default

    def reload(self) -> None:
        """Force re-read of config from disk on next access.

        Call after the agent signals a config update (e.g. via inotify or
        a SIGHUP handler).
        """
        self._cache = {}


config = Config()
