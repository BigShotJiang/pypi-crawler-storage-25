"""Metrics instrumentation with client-side aggregation.

Metrics are accumulated in memory and flushed periodically by the
background emitter thread — the same pattern used by OTel's
``PeriodicExportingMetricReader``, Prometheus client, and Micrometer.

The caller's hot path is a lock + dict update (~100ns).  No JSON
serialization, no queue, no disk I/O.
"""

from __future__ import annotations

import functools
import threading
import time
from typing import Any

# -- Aggregation state ---------------------------------------------------------

_lock = threading.Lock()

# Key: (name, unit, frozenset of attribute items)
_Key = tuple[str, str, frozenset[tuple[str, Any]]]

_EMPTY_ATTRS: frozenset[tuple[str, Any]] = frozenset()

_counters: dict[_Key, float] = {}
_gauges: dict[_Key, float] = {}
_histograms: dict[_Key, _HistogramAcc] = {}


class _HistogramAcc:
    """Running min/max/sum/count accumulator for histogram values."""

    __slots__ = ("count", "total", "mn", "mx")

    def __init__(self) -> None:
        self.count = 0
        self.total = 0.0
        self.mn = float("inf")
        self.mx = float("-inf")

    def add(self, value: float) -> None:
        self.count += 1
        self.total += value
        if value < self.mn:
            self.mn = value
        if value > self.mx:
            self.mx = value


# -- Timer (private) -----------------------------------------------------------


class _Timer:
    """Time a block of code.  Context manager and decorator.

    As context manager::

        with pontem.metrics.timer("model.inference"):
            result = model.predict(frame)

    As decorator::

        @pontem.metrics.timer("model.inference")
        def predict(frame):
            ...

    Records elapsed seconds to a histogram.
    """

    def __init__(self, name: str, *, unit: str = "s", **attrs: Any) -> None:
        self._name = name
        self._unit = unit
        self._attrs = attrs
        self._start: float = 0

    def __enter__(self) -> _Timer:
        self._start = time.perf_counter()
        return self

    def __exit__(self, *exc: Any) -> bool:
        elapsed = time.perf_counter() - self._start
        key = (
            self._name,
            self._unit,
            frozenset(self._attrs.items()) if self._attrs else _EMPTY_ATTRS,
        )
        with _lock:
            acc = _histograms.get(key)
            if acc is None:
                acc = _HistogramAcc()
                _histograms[key] = acc
            acc.add(elapsed)
        return False

    def __call__(self, fn: Any) -> Any:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with _Timer(self._name, unit=self._unit, **self._attrs):
                return fn(*args, **kwargs)

        return wrapper


# -- Public API ----------------------------------------------------------------


class Metrics:
    """Namespace for metric instrumentation functions."""

    def count(self, name: str, amount: float = 1, **attrs: Any) -> None:
        """Increment a counter.

        Example::

            pontem.metrics.count("detections", class_name="apple")
            pontem.metrics.count("bytes_sent", len(payload))
        """
        key = (name, "", frozenset(attrs.items()) if attrs else _EMPTY_ATTRS)
        with _lock:
            _counters[key] = _counters.get(key, 0) + amount

    def record(self, name: str, value: float, *, unit: str = "", **attrs: Any) -> None:
        """Record a value to a histogram.

        Accumulates count/sum/min/max and flushes as a summary each
        interval — the standard approach used by OTel and Prometheus.

        Example::

            pontem.metrics.record("payload_size", len(data), unit="bytes")
        """
        key = (name, unit, frozenset(attrs.items()) if attrs else _EMPTY_ATTRS)
        with _lock:
            acc = _histograms.get(key)
            if acc is None:
                acc = _HistogramAcc()
                _histograms[key] = acc
            acc.add(value)

    def set_gauge(
        self, name: str, value: float, *, unit: str = "", **attrs: Any
    ) -> None:
        """Set a gauge to a point-in-time value.

        Only the latest value per interval is emitted.

        Example::

            pontem.metrics.set_gauge("gpu_temperature", 72.0, unit="celsius", gpu="0")
        """
        key = (name, unit, frozenset(attrs.items()) if attrs else _EMPTY_ATTRS)
        with _lock:
            _gauges[key] = value

    def timer(self, name: str, *, unit: str = "s", **attrs: Any) -> _Timer:
        """Time a block of code.  Returns a context manager / decorator.

        Example::

            with pontem.metrics.timer("model.inference"):
                result = model.predict(frame)
        """
        return _Timer(name, unit=unit, **attrs)


metrics = Metrics()


# -- Collection (called by the emit background thread) -------------------------


def _collect() -> list[tuple[str, dict[str, Any]]]:
    """Swap out accumulated metrics and return serializable records.

    Returns a list of ``(channel, record_dict)`` tuples.  The emit
    thread adds ``timestamp`` and ``resource`` before writing.

    The lock is held only during the swap (O(1) reference swap) —
    building output records happens outside the lock.
    """
    global _counters, _gauges, _histograms
    with _lock:
        counters = _counters
        _counters = {}
        gauges = _gauges
        _gauges = {}
        histograms = _histograms
        _histograms = {}

    results: list[tuple[str, dict[str, Any]]] = []

    for (name, unit, attrs_frozen), total in counters.items():
        rec: dict[str, Any] = {
            "name": name,
            "type": "counter",
            "value": total,
            "attributes": dict(attrs_frozen),
        }
        if unit:
            rec["unit"] = unit
        results.append(("metrics.jsonl", rec))

    for (name, unit, attrs_frozen), value in gauges.items():
        rec = {
            "name": name,
            "type": "gauge",
            "value": value,
            "attributes": dict(attrs_frozen),
        }
        if unit:
            rec["unit"] = unit
        results.append(("metrics.jsonl", rec))

    for (name, unit, attrs_frozen), acc in histograms.items():
        rec = {
            "name": name,
            "type": "histogram",
            "value": {
                "count": acc.count,
                "sum": acc.total,
                "min": acc.mn,
                "max": acc.mx,
            },
            "attributes": dict(attrs_frozen),
        }
        if unit:
            rec["unit"] = unit
        results.append(("metrics.jsonl", rec))

    return results


def _reset() -> None:
    """Clear all aggregation state.  Used by tests."""
    global _counters, _gauges, _histograms
    with _lock:
        _counters = {}
        _gauges = {}
        _histograms = {}
