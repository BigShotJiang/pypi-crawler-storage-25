"""Structured logging.

Direct API::

    from pontem.log import Level
    Level.DEBUG  # 5

    pontem.logger.info("model loaded", model="scoring_v3")

Stdlib :mod:`logging` integration via :class:`PontemFormatter`::

    from pontem.log import PontemFormatter

    handler.setFormatter(PontemFormatter(service_name="my-service"))
    # or
    PontemFormatter.install()
"""

from __future__ import annotations

import enum
import json
import logging
from typing import Any

from pontem import _emit, _sdk


class Level(enum.IntEnum):
    """Log severity levels.

    Values map to OpenTelemetry SeverityNumber (1-24 scale).
    https://opentelemetry.io/docs/specs/otel/logs/data-model/#severity-fields
    """

    TRACE = 1
    DEBUG = 5
    INFO = 9
    WARN = 13
    ERROR = 17
    FATAL = 21


class Logger:
    """Structured logger with level helpers.

    Example::

        import pontem

        pontem.logger.info("model loaded", model="scoring_v3")
        pontem.logger.warn("high latency", latency_ms=120)

    Severity levels are available as attributes::

        pontem.logger.TRACE  # 1
        pontem.logger.INFO   # 9
    """

    TRACE = Level.TRACE
    DEBUG = Level.DEBUG
    INFO = Level.INFO
    WARN = Level.WARN
    ERROR = Level.ERROR
    FATAL = Level.FATAL

    def _log(self, level: int, msg: str, **attrs: Any) -> None:
        try:
            severity_text = Level(level).name
        except ValueError:
            severity_text = "INFO"

        _emit.emit(
            "logs.jsonl",
            {
                "severityNumber": level,
                "severityText": severity_text,
                "body": msg,
                "attributes": attrs or {},
            },
        )

    def trace(self, msg: str, **attrs: Any) -> None:
        self._log(Level.TRACE, msg, **attrs)

    def debug(self, msg: str, **attrs: Any) -> None:
        self._log(Level.DEBUG, msg, **attrs)

    def info(self, msg: str, **attrs: Any) -> None:
        self._log(Level.INFO, msg, **attrs)

    def warn(self, msg: str, **attrs: Any) -> None:
        self._log(Level.WARN, msg, **attrs)

    def error(self, msg: str, **attrs: Any) -> None:
        self._log(Level.ERROR, msg, **attrs)

    def fatal(self, msg: str, **attrs: Any) -> None:
        self._log(Level.FATAL, msg, **attrs)


logger = Logger()


# -- stdlib logging integration ----------------------------------------------

# Built-in attributes set by :class:`logging.LogRecord`. Anything else
# on the record's ``__dict__`` was supplied via ``extra=`` and should
# be lifted onto the emitted record's ``attributes``.
_RESERVED_LOGRECORD_ATTRS = frozenset(
    {
        "args",
        "asctime",
        "created",
        "exc_info",
        "exc_text",
        "filename",
        "funcName",
        "levelname",
        "levelno",
        "lineno",
        "message",
        "module",
        "msecs",
        "msg",
        "name",
        "pathname",
        "process",
        "processName",
        "relativeCreated",
        "stack_info",
        "thread",
        "threadName",
        "taskName",
    }
)


def _stdlib_to_otel(levelno: int) -> Level:
    """Map a stdlib logging level number to an OTel SeverityNumber."""
    if levelno >= logging.CRITICAL:
        return Level.FATAL
    if levelno >= logging.ERROR:
        return Level.ERROR
    if levelno >= logging.WARNING:
        return Level.WARN
    if levelno >= logging.INFO:
        return Level.INFO
    if levelno >= logging.DEBUG:
        return Level.DEBUG
    return Level.TRACE


def _record_to_pontem_dict(
    record: logging.LogRecord,
    formatter: logging.Formatter,
) -> dict[str, Any]:
    severity = _stdlib_to_otel(record.levelno)
    attrs: dict[str, Any] = {
        k: v
        for k, v in record.__dict__.items()
        if k not in _RESERVED_LOGRECORD_ATTRS and not k.startswith("_")
    }
    attrs.setdefault("logger.name", record.name)
    if record.exc_info:
        attrs["exception"] = formatter.formatException(record.exc_info)
    if record.stack_info:
        attrs["stack_info"] = record.stack_info
    return {
        "severityNumber": int(severity),
        "severityText": severity.name,
        "body": record.getMessage(),
        "attributes": attrs,
    }


class PontemFormatter(logging.Formatter):
    """:class:`logging.Formatter` that emits Pontem-shaped JSONL.

    Compose with any stdlib handler — ``handler.setFormatter(PontemFormatter())``
    — to make that handler's output match the Pontem schema without
    routing through the SDK's emit pipeline.

    Resource attributes resolution order, highest priority first:

    1. ``resource={...}`` constructor kwarg (replaces all),
    2. ``service_name=`` / ``service_version=`` constructor kwargs
       (override individual keys),
    3. whatever :func:`pontem.init` configured (read from the SDK's
       internal resource dict at construction time).

    At least one source must populate ``service.name``; otherwise
    :class:`RuntimeError` is raised at construction.
    """

    def __init__(
        self,
        *,
        service_name: str | None = None,
        service_version: str | None = None,
        resource: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        if resource is not None:
            base = dict(resource)
        elif _sdk._initialized:
            base = dict(_emit._resource)
        else:
            base = {}
        if service_name is not None:
            base["service.name"] = service_name
        if service_version is not None:
            base["service.version"] = service_version
        if "service.name" not in base:
            raise RuntimeError(
                "PontemFormatter requires service_name=, resource= containing "
                "'service.name', or pontem.init() to have been called first"
            )
        self._resource = base

    def format(self, record: logging.LogRecord) -> str:
        out = _record_to_pontem_dict(record, self)
        out["timestamp"] = record.created
        out["resource"] = self._resource
        return json.dumps(out, separators=(",", ":"), default=str)

    @classmethod
    def install(
        cls,
        *,
        service_name: str | None = None,
        service_version: str | None = None,
        resource: dict[str, Any] | None = None,
    ) -> PontemFormatter:
        """Apply a :class:`PontemFormatter` to every handler currently on root.

        Intended for the ``basicConfig()``-style setup: the user already
        has a handler chain in place, and just wants its on-the-wire
        format to be Pontem-shaped. Existing destinations, rotation
        policies, and filters are untouched — only ``handler.formatter``
        changes.

        **Call order matters.** This method swaps the formatter on
        handlers that are already attached to the root logger; run
        ``logging.basicConfig()`` (or your own logging setup) BEFORE
        :meth:`install`. Raises :class:`RuntimeError` if the root
        logger has no handlers attached.

        Handlers attached AFTER this call are not affected; rerun
        :meth:`install` if you add handlers later.
        """
        handlers = logging.getLogger().handlers
        if not handlers:
            raise RuntimeError(
                "PontemFormatter.install() requires the root logger to "
                "already have handlers. Run logging.basicConfig() (or your "
                "own logging setup) before PontemFormatter.install()."
            )
        formatter = cls(
            service_name=service_name,
            service_version=service_version,
            resource=resource,
        )
        for handler in handlers:
            handler.setFormatter(formatter)
        return formatter
