"""Pontem edge SDK.

Zero dependencies.  One-line install, one-line instrumentation::

    import pontem

    pontem.init(service_name="my-service")
    pontem.logger.info("model loaded", model="scoring_v3")

    with pontem.metrics.timer("model.inference"):
        result = model.predict(frame)

    pontem.metrics.count("detections", class_name="apple")
"""

from pontem._config import config
from pontem._metrics import metrics
from pontem._sdk import init, shutdown
from pontem.log import logger

__all__ = [
    "init",
    "shutdown",
    "logger",
    "metrics",
    "config",
]
