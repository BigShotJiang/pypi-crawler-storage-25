"""Telemetry emission: queue, background writer thread, sink dispatch.

Architecture::

    Caller thread                    Background thread (pontem-emit)
    ─────────────                    ──────────────────────────────
    pontem.logger.info(...)            wakes every _flush_interval
      → queue.put_nowait()            drains log queue → batch write
      → returns (~2µs)               collects aggregated metrics
                                      writes metric summaries
    pontem.metrics.count(...)          single flush() across the sink
      → lock, dict += 1, unlock      sleeps
      → returns (~100ns)

* **Non-blocking** — log emit enqueues to a bounded buffer; metric
  calls just update in-memory aggregation state.
* **Bounded** — log queue is bounded; sinks bound their own outputs
  (file rotation, etc.).
* **Thread-safe** — multiple threads can call emit/count concurrently.

The actual destination (files vs stdout) is encapsulated in a sink
object selected at :func:`configure` time. See ``_sinks.py``.
"""

from __future__ import annotations

import json
import logging
import os
import queue
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from pontem._sinks import _FileSink, _Sink, _StdoutSink

_logger = logging.getLogger("pontem.emit")

# -- Public state --------------------------------------------------------------

_emit_dir: Path | None = None
_emit_target: str = "file"
_resource: dict[str, Any] = {}

# -- Defaults ------------------------------------------------------------------

DEFAULT_MAX_FILE_BYTES = 10 * 1024 * 1024  # 10 MB per channel file
DEFAULT_MAX_ROTATED = 5  # keep last N rotated files per channel
DEFAULT_FLUSH_INTERVAL = 1.0  # seconds between background flushes
DEFAULT_QUEUE_SIZE = 10_000  # max buffered records before dropping
DEFAULT_EMIT_TARGET = "file"

# -- Internal state ------------------------------------------------------------

_max_file_bytes = DEFAULT_MAX_FILE_BYTES
_max_rotated = DEFAULT_MAX_ROTATED
_flush_interval = DEFAULT_FLUSH_INTERVAL

_queue: queue.Queue[tuple[str, str] | None] = queue.Queue(
    maxsize=DEFAULT_QUEUE_SIZE,
)
_thread: threading.Thread | None = None
_stop = threading.Event()

# Periodic callbacks — called each cycle to collect aggregated data.
# Each returns a list of (channel, record_dict) tuples.
_periodic: list[Callable[[], list[tuple[str, dict[str, Any]]]]] = []

# The active sink. Accessed only from the writer thread after configure().
_sink: _Sink | None = None


def configure(
    emit_dir: str | None = None,
    resource: dict[str, Any] | None = None,
    *,
    emit_target: str = DEFAULT_EMIT_TARGET,
    max_file_bytes: int = DEFAULT_MAX_FILE_BYTES,
    max_rotated_files: int = DEFAULT_MAX_ROTATED,
    flush_interval: float = DEFAULT_FLUSH_INTERVAL,
) -> Path | None:
    """Set up the emit sink and start the background writer.

    ``emit_target`` selects the sink:

    * ``"file"`` (default) — write JSONL files under ``emit_dir``.
      Returns the resolved emit dir path. If ``emit_dir`` is unset and
      ``PONTEM_EMIT_DIR`` is unset, returns ``None`` and emits become
      no-ops (backward-compatible behavior).
    * ``"stdout"`` — write JSONL lines to ``sys.stdout``. ``emit_dir``
      is ignored. Returns ``None`` (no path).

    Unknown ``emit_target`` values are logged and treated as ``"file"``.
    """
    global _emit_dir, _emit_target, _resource, _thread, _sink
    global _max_file_bytes, _max_rotated, _flush_interval

    _resource = resource or {}
    _max_file_bytes = max_file_bytes
    _max_rotated = max_rotated_files
    _flush_interval = flush_interval

    target = (emit_target or DEFAULT_EMIT_TARGET).lower()
    if target not in ("file", "stdout"):
        _logger.warning(
            "pontem-emit: unknown emit_target=%r, falling back to 'file'",
            emit_target,
        )
        target = "file"
    _emit_target = target

    if target == "stdout":
        _emit_dir = None
        _sink = _StdoutSink()
    else:
        path = emit_dir or os.environ.get("PONTEM_EMIT_DIR")
        if not path:
            _emit_dir = None
            _sink = None
            return None
        _emit_dir = Path(path)
        _emit_dir.mkdir(parents=True, exist_ok=True)
        _sink = _FileSink(
            _emit_dir,
            max_file_bytes=_max_file_bytes,
            max_rotated_files=_max_rotated,
        )

    # Start background writer if not already running.
    if _thread is None or not _thread.is_alive():
        _stop.clear()
        _thread = threading.Thread(
            target=_writer_loop,
            daemon=True,
            name="pontem-emit",
        )
        _thread.start()

    return _emit_dir


def register_periodic(
    fn: Callable[[], list[tuple[str, dict[str, Any]]]],
) -> None:
    """Register a callback invoked each flush cycle.

    The callback should return ``(channel, record_dict)`` tuples.
    Used by ``_metrics._collect()`` to flush aggregated metrics.
    """
    _periodic.append(fn)


def emit(channel: str, record: dict[str, Any]) -> None:
    """Enqueue a telemetry record. Non-blocking; drops if buffer full.

    Used for logs (each record is unique). Metrics use aggregation
    instead — see ``_metrics.py``.

    No-op when no sink is configured (e.g. ``file`` mode without an
    ``emit_dir``).
    """
    if _sink is None:
        return
    record["timestamp"] = time.time()
    record["resource"] = _resource
    line = json.dumps(record, separators=(",", ":"), default=str)
    try:
        _queue.put_nowait((channel, line))
    except queue.Full:
        # Back-pressure: drop rather than block the caller.
        _logger.debug("emit queue full, dropping record on %s", channel)


def close() -> None:
    """Drain remaining records, flush sink, and stop the writer thread."""
    global _thread, _emit_dir, _sink
    _stop.set()
    if _thread is not None:
        _thread.join(timeout=5.0)
        if _thread.is_alive():
            _logger.warning(
                "pontem-emit: writer thread did not exit in 5s, "
                "buffered data may be lost"
            )
        _thread = None

    # Thread has exited — safe to close sink from this thread.
    if _sink is not None:
        try:
            _sink.close()
        except Exception:
            _logger.exception("pontem-emit: error closing sink")
    _sink = None
    _emit_dir = None
    _stop.clear()
    _periodic.clear()

    # Discard any stragglers left after thread timeout.
    while not _queue.empty():
        try:
            _queue.get_nowait()
        except queue.Empty:
            break


# -- Background writer ---------------------------------------------------------


def _writer_loop() -> None:
    """Drain queue, collect aggregated metrics, write, flush. Daemon thread."""
    while not _stop.is_set():
        try:
            _drain()
            _collect_periodic()
            _flush_all()
        except Exception:
            _logger.exception("pontem-emit: error in writer loop")
        _stop.wait(_flush_interval)
    # Final cycle before exit.
    try:
        _drain()
        _collect_periodic()
        _flush_all()
    except Exception:
        _logger.exception("pontem-emit: error in final flush")


def _drain() -> None:
    """Pull all available records from the queue and write in batches."""
    batches: dict[str, list[str]] = {}
    while True:
        try:
            item = _queue.get_nowait()
        except queue.Empty:
            break
        if item is None:
            continue
        channel, line = item
        batches.setdefault(channel, []).append(line)

    for channel, lines in batches.items():
        _write_lines(channel, lines)


def _collect_periodic() -> None:
    """Run registered periodic callbacks and write their output."""
    for cb in _periodic:
        batches: dict[str, list[str]] = {}
        for channel, record in cb():
            record["timestamp"] = time.time()
            record["resource"] = _resource
            line = json.dumps(record, separators=(",", ":"), default=str)
            batches.setdefault(channel, []).append(line)
        for channel, lines in batches.items():
            _write_lines(channel, lines)


def _flush_all() -> None:
    """Single flush across the sink. Called once per cycle."""
    if _sink is not None:
        _sink.flush()


def _write_lines(channel: str, lines: list[str]) -> None:
    """Dispatch a batch of serialized JSON lines to the active sink."""
    if _sink is None:
        return
    _sink.write_lines(channel, lines)
