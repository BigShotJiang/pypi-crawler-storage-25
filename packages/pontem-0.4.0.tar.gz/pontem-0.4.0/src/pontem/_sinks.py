"""Telemetry sinks.

A sink turns ``(channel, lines)`` into bytes on a destination. The
background writer thread in ``_emit.py`` calls a sink's methods; the
sink owns its own buffers and rotation policy.

Two implementations:

* :class:`_FileSink` — writes JSONL files under ``$PONTEM_EMIT_DIR``,
  rotates at a size threshold, gzips rotated files, prunes old files.
  This is the default and matches the on-host edge-agent contract.
* :class:`_StdoutSink` — writes JSONL lines to ``sys.stdout``. No
  rotation, no compression — the docker daemon's ``json-file`` driver
  handles container log rotation. Used in compose deployments where a
  collector tails ``/var/lib/docker/containers/*/*-json.log``.

All sink methods run on the ``pontem-emit`` background thread only.
The caller's thread never reaches a sink.
"""

from __future__ import annotations

import gzip
import logging
import os
import shutil
import sys
import time
from pathlib import Path
from typing import Protocol, TextIO

_logger = logging.getLogger("pontem.emit")


class _Sink(Protocol):
    """A destination for serialized JSONL lines, batched per channel."""

    def write_lines(self, channel: str, lines: list[str]) -> None:
        """Write a batch of already-serialized JSON lines for a channel.

        Does NOT flush. The emit thread calls :meth:`flush` once per
        cycle after all channels have been written.
        """

    def flush(self) -> None:
        """Flush any buffered output to the underlying destination."""

    def close(self) -> None:
        """Release resources (close files, etc.). Called once at SDK shutdown."""


class _FileSink:
    """Write per-channel JSONL files under ``emit_dir``, rotate + gzip on size."""

    def __init__(
        self,
        emit_dir: Path,
        *,
        max_file_bytes: int,
        max_rotated_files: int,
    ) -> None:
        self._emit_dir = emit_dir
        self._max_file_bytes = max_file_bytes
        self._max_rotated = max_rotated_files
        self._files: dict[str, TextIO] = {}
        self._sizes: dict[str, int] = {}

    def write_lines(self, channel: str, lines: list[str]) -> None:
        f = self._files.get(channel)
        if f is None:
            filepath = self._emit_dir / channel
            f = open(filepath, "a")  # noqa: SIM115
            self._files[channel] = f
            self._sizes[channel] = os.fstat(f.fileno()).st_size

        payload = "\n".join(lines) + "\n"
        f.write(payload)
        self._sizes[channel] = self._sizes.get(channel, 0) + len(payload)

        if self._sizes[channel] >= self._max_file_bytes:
            self._rotate(channel)

    def flush(self) -> None:
        for f in self._files.values():
            f.flush()

    def close(self) -> None:
        for f in self._files.values():
            try:
                f.flush()
                f.close()
            except OSError:
                pass
        self._files.clear()
        self._sizes.clear()

    # -- rotation ---------------------------------------------------------

    def _rotate(self, channel: str) -> None:
        f = self._files.pop(channel, None)
        if f:
            f.flush()
            f.close()
        self._sizes.pop(channel, None)

        src = self._emit_dir / channel
        if src.exists():
            dst = self._emit_dir / f"{channel}.{time.time_ns()}"
            src.rename(dst)
            _compress_gz(dst)

        rotated = sorted(
            self._emit_dir.glob(f"{channel}.*"),
            key=lambda p: p.stat().st_mtime,
        )
        while len(rotated) > self._max_rotated:
            rotated.pop(0).unlink()


class _StdoutSink:
    """Write JSONL lines to ``sys.stdout``. No rotation; docker handles it.

    Resolves ``sys.stdout`` per call rather than caching at construction
    so pytest's ``capsys`` and similar redirection still work.
    """

    def write_lines(self, channel: str, lines: list[str]) -> None:
        # Channel hint is intentionally NOT prefixed; the JSON record is
        # self-describing (see SCHEMA.md). Collectors branch on field
        # presence.
        payload = "\n".join(lines) + "\n"
        sys.stdout.write(payload)

    def flush(self) -> None:
        try:
            sys.stdout.flush()
        except (OSError, ValueError):
            # ValueError: I/O on closed file (test-shutdown race).
            pass

    def close(self) -> None:
        # We do not own sys.stdout. Just flush.
        self.flush()


def _compress_gz(path: Path) -> None:
    """Gzip-compress a file in place. Replaces original with .gz."""
    gz_path = Path(str(path) + ".gz")
    with open(path, "rb") as f_in, gzip.open(gz_path, "wb") as f_out:
        shutil.copyfileobj(f_in, f_out)
    path.unlink()
