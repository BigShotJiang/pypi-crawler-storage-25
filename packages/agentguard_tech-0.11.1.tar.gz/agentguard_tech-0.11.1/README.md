# agentguard-tech

**Runtime governance for production AI agents.** Built for APRA CPS 230, EU AI Act and ISO/IEC 42001 — with native OpenClaw, LangChain, CrewAI, OpenAI Assistants, AutoGen and MCP integrations.

[![PyPI](https://img.shields.io/pypi/v/agentguard-tech?color=38bdb0)](https://pypi.org/project/agentguard-tech/)
[![Python](https://img.shields.io/pypi/pyversions/agentguard-tech?color=38bdb0)](https://pypi.org/project/agentguard-tech/)
[![license](https://img.shields.io/badge/license-BSL%201.1-orange)](https://github.com/thebotclub/agentguard-core/blob/main/LICENSE)
[![homepage](https://img.shields.io/badge/site-agentguard.tech-38bdb0)](https://agentguard.tech)

AgentGuard sits between your production AI agent and the systems it touches. Every database write, every customer email, every fund transfer — evaluated against your written policy, logged with a tamper-evident hash chain, and rolled up into the evidence pack your auditor and your board accept.

This package is the Python SDK. For the TypeScript SDK install [`@the-bot-club/agentguard`](https://www.npmjs.com/package/@the-bot-club/agentguard). For the compliance evidence pack generator see [agentguard.tech/compliance](https://agentguard.tech/compliance).

## Install

```bash
pip install agentguard-tech
```

## Quick start

```python
from agentguard import AgentGuard

guard = AgentGuard(api_key="ag_live_...")
decision = guard.evaluate(tool="shell_exec", params={"cmd": "rm -rf /"})
# → blocked
```

## OpenClaw fleet governance

Drop-in plugin for any [OpenClaw](https://openclaw.ai) agent. The plugin registers a `before_tool_call` hook and blocks any call that violates the agent's attached policy.

```python
from agentguard.integrations.openclaw import openclaw_guard

guard = openclaw_guard(
    api_key=os.environ["AGENTGUARD_API_KEY"],
    agent_id="ops-dispatch-1",
    policy="./policies/cps230.yaml",
    strict=True,
)
```

Other framework integrations: LangChain (`agentguard.integrations.langchain`), CrewAI, OpenAI, AutoGen, LangGraph, MCP, Vercel AI.

## Documentation

- Website — [agentguard.tech](https://agentguard.tech)
- Docs — [docs.agentguard.tech](https://docs.agentguard.tech)
- OpenClaw integration — [agentguard.tech/openclaw](https://agentguard.tech/openclaw)
- Compliance evidence pack — [agentguard.tech/compliance](https://agentguard.tech/compliance)
- Source — [github.com/thebotclub/agentguard-core](https://github.com/thebotclub/agentguard-core)

## Licence

Business Source License 1.1. Source available, commercial use under licence.
© 2026 The Bot Club Pty Ltd (ABN 99 695 980 226).
