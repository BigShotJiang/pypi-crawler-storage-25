"""AgentGuard — Runtime security for AI agents."""
from .client import AgentGuard
from .integrations.errors import AgentGuardBlockError

__version__ = "0.11.1"
__all__ = ["AgentGuard", "AgentGuardBlockError"]
