# Fragment API Python

Async Python library for Fragment.com automation — purchases, marketplace, bids, and management.

[![PyPI version](https://img.shields.io/pypi/v/fragment-api-py.svg)](https://pypi.org/project/fragment-api-py/)
[![Python versions](https://img.shields.io/pypi/pyversions/fragment-api-py.svg)](https://pypi.org/project/fragment-api-py/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

---

## Installation

```bash
pip install fragment-api-py
```

## Quick Start

```python
import asyncio
from FragmentAPI import FragmentClient

async def main():
    client = FragmentClient(
        seed="your 24 word mnemonic...",
        cookies={"stel_ssid": "...", "stel_token": "...", "stel_dt": "...", "stel_ton_token": "..."}
    )

    # Get wallet info
    wallet = await client.get_wallet()
    print(f"Balance: {wallet.balance_ton} TON")

    # Purchase Telegram Stars
    result = await client.purchase_stars("@username", amount=100)
    print(f"Transaction: {result.transaction_id}")

    # Purchase Telegram Premium
    await client.purchase_premium("@username", months=6)

    # Place bid on username
    await client.place_bid(item_type=1, slug="username", bid=150)

    # Search marketplace
    items = await client.search_usernames("gold", filter="sale")

asyncio.run(main())
```

## Auto-Authentication

```python
cookies = await FragmentClient.authenticate(
    seed="24 words...",
    telegram_phone="+71234567890"  # or telegram_auth_data
)
client = FragmentClient(seed="...", cookies=cookies)
```

## Features

| Feature | Description |
|---------|-------------|
| **Purchases** | Stars (50–10M), Premium (3/6/12 mo), TON Ads |
| **Giveaways** | Stars & Premium for channels |
| **Bids** | Usernames (type=1), Numbers (type=3), Gifts (type=5) |
| **Marketplace** | Search with filters & pagination |
| **Wallet** | V4R2 & V5R1 (W5) support |
| **Anonymous Numbers** | Login codes, session termination |
| **NFT** | Withdraw/transfer gifts to wallet |
| **Stars Revenue** | Withdraw earned Stars |

## Requirements

- Python 3.10+
- Fragment cookies: `stel_ssid`, `stel_dt`, `stel_token`, `stel_ton_token`
- TON wallet seed phrase

## Documentation

📚 [Full Documentation](https://fragment.s1qwy.ru)

## Support

💬 [Telegram Chat](https://t.me/fragment_api_py) | 🐛 [GitHub Issues](https://github.com/S1qwy/fragment-api-py/issues)

## License

MIT