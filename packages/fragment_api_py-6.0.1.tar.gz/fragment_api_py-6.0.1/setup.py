#!/usr/bin/env python3
'''
Setup script for Fragment API Python Library.
'''

from setuptools import setup, find_packages
import os

readme_path = os.path.join(os.path.dirname(__file__), "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "Async Python library for Fragment.com API"

setup(
    name="fragment-api-py",
    version="6.0.1",
    author="S1qwy",
    author_email="S1qwy@internet.ru",
    description=(
        "Async Python library for Fragment.com API "
        "with seqno/balance confirmation and confirmReq"
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/S1qwy/fragment-api-py",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Framework :: AsyncIO",
    ],
    python_requires=">=3.9",
    install_requires=[
        "httpx>=0.27.0",
        "tonutils>=0.4.0",
        "pynacl>=1.5.0",
        "ton-core>=0.1.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "isort>=5.12.0",
            "mypy>=1.0.0",
        ],
    },
    project_urls={
        "Bug Reports": (
            "https://github.com/S1qwy/fragment-api-py/issues"
        ),
        "Source": "https://github.com/S1qwy/fragment-api-py",
    },
    keywords=(
        "fragment telegram ton premium stars api async"
    ),
)