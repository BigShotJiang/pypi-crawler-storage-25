from __future__ import annotations

from dataclasses import dataclass

from kevent import Event, EventHandler, Listener, Middleware, listener
from kevent.cli import main, run_demo


class UserSignedUp(Event):
    def __init__(self, username: str) -> None:
        self.username = username


@dataclass(slots=True)
class TraceMiddleware(Middleware):
    trace: list[str]

    def process(self, event: Event) -> Event | None:
        self.trace.append(f"middleware:{type(event).__name__}")
        return event


class Subscribers:
    def __init__(self, trace: list[str]) -> None:
        self.trace = trace

        def on_user_signed_up(event: UserSignedUp) -> None:
            self.trace.append(f"typed:{event.username}")

        def on_any_event(event: Event) -> None:
            self.trace.append(f"fallback:{type(event).__name__}")

        self.on_user_signed_up = listener(UserSignedUp)(on_user_signed_up)
        self.on_any_event = listener(Event)(on_any_event)


def test_listener_decorator_creates_listener() -> None:
    def callback(event: Event) -> None:
        del event

    registered = listener(UserSignedUp)(callback)

    assert isinstance(registered, Listener)
    assert registered.event is UserSignedUp
    assert registered.callback is callback


def test_subscribe_deduplicates_listeners() -> None:
    handler = EventHandler()

    def callback(event: Event) -> None:
        del event

    registered = listener(UserSignedUp)(callback)

    handler.subscribe(registered)
    handler.subscribe(registered)

    assert list(handler.listeners_for(UserSignedUp)) == [registered]


def test_publish_runs_middleware_then_typed_then_fallback() -> None:
    trace: list[str] = []
    handler = EventHandler()
    handler.add_middleware(TraceMiddleware(trace))
    handler.lookup(Subscribers(trace))

    handler.publish(UserSignedUp("aria"))

    assert trace == [
        "middleware:UserSignedUp",
        "typed:aria",
        "fallback:UserSignedUp",
    ]


def test_lookup_discovers_listener_attributes() -> None:
    trace: list[str] = []
    handler = EventHandler(Subscribers(trace))

    handler.publish(UserSignedUp("milo"))

    assert trace == ["typed:milo", "fallback:UserSignedUp"]


def test_cli_demo_returns_trace() -> None:
    trace = run_demo("kevent")

    assert trace == ["middleware:DemoEvent", "listener:kevent", "fallback:DemoEvent"]


def test_cli_main_prints_demo_output(capsys) -> None:
    exit_code = main(["demo", "hello"])

    captured = capsys.readouterr()

    assert exit_code == 0
    assert captured.out.splitlines() == [
        "middleware:DemoEvent",
        "listener:hello",
        "fallback:DemoEvent",
    ]


def test_listener_is_callable() -> None:
    events: list[str] = []

    def on_event(event: UserSignedUp) -> None:
        events.append(event.username)

    registered = listener(UserSignedUp)(on_event)
    event = UserSignedUp("bob")

    registered(event)

    assert events == ["bob"]


def test_mro_dispatch_inherited_events() -> None:
    class BaseEvent(Event):
        pass

    class DerivedEvent(BaseEvent):
        pass

    trace: list[str] = []

    def on_base(event: BaseEvent) -> None:
        trace.append("base")

    def on_derived(event: DerivedEvent) -> None:
        trace.append("derived")

    handler = EventHandler()
    handler.subscribe(listener(BaseEvent)(on_base))
    handler.subscribe(listener(DerivedEvent)(on_derived))

    handler.publish(DerivedEvent())

    assert trace == ["derived", "base"]


def test_middleware_can_cancel_event() -> None:
    trace: list[str] = []

    @dataclass(slots=True)
    class CancelMiddleware(Middleware):
        def process(self, event: Event) -> Event | None:
            return None

    def on_event(event: Event) -> None:
        trace.append("received")

    handler = EventHandler()
    handler.add_middleware(CancelMiddleware())
    handler.subscribe(listener(Event)(on_event))

    handler.publish(UserSignedUp("alice"))

    assert trace == []


def test_error_handler_catches_exceptions() -> None:
    errors: list[tuple[Exception, str]] = []

    def on_error(exc: Exception, event: Event, listener_obj) -> None:
        errors.append((exc, type(event).__name__))

    def failing_callback(event: Event) -> None:
        raise ValueError("test error")

    handler = EventHandler(on_error=on_error)
    handler.subscribe(listener(Event)(failing_callback))

    handler.publish(UserSignedUp("bob"))

    assert len(errors) == 1
    assert isinstance(errors[0][0], ValueError)
    assert errors[0][1] == "UserSignedUp"


def test_handlers_count_property() -> None:
    handler = EventHandler()

    assert handler.handlers_count == 0

    handler.subscribe(listener(UserSignedUp)(lambda e: None))
    assert handler.handlers_count == 1

    handler.subscribe(listener(Event)(lambda e: None))
    assert handler.handlers_count == 2

    handler.subscribe(listener(UserSignedUp)(lambda e: None))
    assert handler.handlers_count == 3
