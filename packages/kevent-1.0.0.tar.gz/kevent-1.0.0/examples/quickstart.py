"""Runnable quickstart for kevent."""

from __future__ import annotations

from kevent import Event, EventHandler, Middleware, listener


class TaskCreated(Event):
    def __init__(self, task_id: int, title: str) -> None:
        self.task_id = task_id
        self.title = title


class AuditMiddleware(Middleware):
    def __init__(self) -> None:
        self.trace: list[str] = []

    def process(self, event: Event) -> None:
        self.trace.append(f"audit:{type(event).__name__}")


class TaskSubscribers:
    def __init__(self) -> None:
        self.events: list[str] = []

        def on_task_created(event: TaskCreated) -> None:
            self.events.append(f"task:{event.task_id}:{event.title}")

        def on_any_event(event: Event) -> None:
            self.events.append(f"any:{type(event).__name__}")

        self.on_task_created = listener(TaskCreated)(on_task_created)
        self.on_any_event = listener(Event)(on_any_event)


def main() -> None:
    handler = EventHandler()
    middleware = AuditMiddleware()
    subscribers = TaskSubscribers()

    handler.add_middleware(middleware)
    handler.lookup(subscribers)
    handler.publish(TaskCreated(7, "ship docs"))

    print(middleware.trace)
    print(subscribers.events)


if __name__ == "__main__":
    main()
