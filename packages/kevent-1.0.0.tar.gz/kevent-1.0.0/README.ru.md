# kevent

[Русский](README.ru.md) | English

`kevent` — небольшой типизированный event system для Python-приложений. Он предоставляет базовый тип `Event`, декларативные listeners, middleware и легкий handler, который доставляет события по точному типу и через generic fallback.

## Что делает проект

- `Event` — базовый класс для событий приложения
- `Listener` связывает один класс события с одним callback
- `listener()` — декоратор для декларативной регистрации listener'ов
- `Middleware` выполняется до передачи события listeners
- `EventHandler` хранит listeners, запускает middleware и публикует события

## Быстрый старт

```python
from kevent import Event, EventHandler, Middleware, listener


class UserLoggedIn(Event):
    def __init__(self, username: str) -> None:
        self.username = username


class TraceMiddleware(Middleware):
    def __init__(self) -> None:
        self.trace: list[str] = []

    def process(self, event: Event) -> Event | None:
        self.trace.append(type(event).__name__)
        return event  # Продолжить распространение


def on_login(event: UserLoggedIn) -> None:
    print(f"welcome:{event.username}")


def on_any(event: Event) -> None:
    print(f"received:{type(event).__name__}")


handler = EventHandler()
handler.add_middleware(TraceMiddleware())
handler.subscribe(listener(UserLoggedIn)(on_login))
handler.subscribe(listener(Event)(on_any))

handler.publish(UserLoggedIn("aria"))
```

## CLI

Запустить встроенную демонстрацию middleware и listener'ов:

```bash
kevent demo "hello"
```

Ожидаемый вывод:

```text
middleware:DemoEvent
listener:hello
fallback:DemoEvent
```

## Установка

```bash
uv sync --dev
```

## Разработка

Запуск тестов:

```bash
just test
```

Проверка линтинга и type checking:

```bash
just check
```

Форматирование кода:

```bash
just fmt
```

Сборка релизных артефактов:

```bash
just build
```

## Структура проекта

```text
kevent/
  __init__.py
  cli.py
  event.py
  handler.py
  listener.py
  middleware.py
examples/
  quickstart.py
tests/
  test_event_system.py
```

## Примечания

- У пакета нет runtime-зависимостей
- Публичный API экспортируется из [kevent/__init__.py](kevent/__init__.py)
- Точка входа CLI: `kevent = "kevent.cli:main"`

## Иерархия событий и диспетчер

`EventHandler.publish()` использует порядок разрешения методов (MRO) для отправки событий. Если вы зарегистрируете listener для базового класса события, он будет получать все экземпляры подклассов:

```python
class UserEvent(Event):
    pass

class UserLoggedIn(UserEvent):
    pass

def on_user_event(event: UserEvent) -> None:
    print(f"user event: {type(event).__name__}")

handler = EventHandler()
handler.subscribe(listener(UserEvent)(on_user_event))
handler.publish(UserLoggedIn("alice"))  # Matches UserEvent через MRO
```

## Middleware и контроль потока

Middleware может наблюдать события и опционально отменять распространение, вернув `None`:

```python
class ValidationMiddleware(Middleware):
    def process(self, event: Event) -> Event | None:
        if not is_valid(event):
            return None  # Запретить listeners получить это событие
        return event

handler = EventHandler()
handler.add_middleware(ValidationMiddleware())
handler.publish(event)  # Listeners не запустятся если валидация провалена
```

## Обработка ошибок

Перехватывайте исключения в listeners без потери других событий:

```python
def on_error(exc: Exception, event: Event, listener_obj) -> None:
    print(f"Ошибка в {listener_obj}: {exc}")

handler = EventHandler(on_error=on_error)
handler.subscribe(listener(Event)(on_event))  # Если вызовет ошибку, on_error будет вызван
handler.publish(event)  # Другие listeners всё ещё выполнятся
```

## Мониторинг слушателей

Проверьте сколько listeners зарегистрировано:

```python
handler = EventHandler()
print(handler.handlers_count)  # 0

handler.subscribe(listener(Event)(lambda e: None))
print(handler.handlers_count)  # 1
```

## Вызов слушателей напрямую

Объекты `Listener` вызываемы: вы можете вызвать их напрямую или использовать как функции. Это полезно для тестирования, цепочек или ручного запуска слушателя вне нормального потока `publish()`:

```python
from kevent import listener, Event

class UserLoggedIn(Event):
    def __init__(self, username: str) -> None:
        self.username = username

def on_login(event: UserLoggedIn) -> None:
    print(f"User {event.username} logged in")

registered = listener(UserLoggedIn)(on_login)

event = UserLoggedIn("alice")
registered(event)  # Вызов напрямую
```
