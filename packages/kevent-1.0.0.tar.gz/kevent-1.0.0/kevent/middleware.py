"""Middleware abstractions for event processing."""

from __future__ import annotations

from abc import ABC, abstractmethod

from kevent.event import Event


class Middleware(ABC):
    """Base class for middleware objects executed before listeners.

    Middleware can observe events and optionally cancel propagation.
    """

    @abstractmethod
    def process(self, event: Event) -> Event | None:
        """Process an event before listener dispatch.

        Args:
            event: The event to process.

        Returns:
            The event (possibly modified) to continue dispatch, or None to cancel.
        """
