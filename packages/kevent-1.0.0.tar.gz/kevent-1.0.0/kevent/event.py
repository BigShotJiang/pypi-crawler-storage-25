"""Base event types for kevent."""

from __future__ import annotations


class Event:
    """Base class for all events.

    Applications should subclass this type to define strongly typed events.
    """

