"""Listener declarations and decorators."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from kevent.event import Event

EventType = type[Event]
type Callback[E] = Callable[[E], None]


@dataclass(frozen=True, slots=True)
class Listener[E]:
    """A typed listener binding between an event class and a callback."""

    event: type[E]
    callback: Callback[E]

    def __call__(self, event: E) -> None:
        """Invoke the listener callback directly."""
        self.callback(event)


def listener[E](event: type[E]) -> Callable[[Callback], Listener[E]]:
    """Decorate a callback so it can be discovered by :class:`EventHandler`."""

    def decorator(callback: Callback) -> Listener[E]:
        return Listener(event=event, callback=callback)

    return decorator
