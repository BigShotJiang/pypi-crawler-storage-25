"""Command-line interface for kevent."""

from __future__ import annotations

import argparse
from collections.abc import Sequence
from dataclasses import dataclass

from kevent import Event, EventHandler, Middleware, listener


@dataclass(slots=True)
class DemoEvent(Event):
    """Small event type used by the demo command."""

    message: str


@dataclass(slots=True)
class DemoMiddleware(Middleware):
    """Collect a trace so the demo can show execution order."""

    trace: list[str]

    def process(self, event: Event) -> Event | None:
        """Record middleware execution in the demo trace."""
        self.trace.append(f"middleware:{type(event).__name__}")
        return event


class DemoSubscriber:
    """Container with declarative listeners for the demo command."""

    def __init__(self, trace: list[str]) -> None:
        """Attach demo listeners that write into the shared trace list."""
        self.trace = trace

        def on_demo(event: DemoEvent) -> None:
            self.trace.append(f"listener:{event.message}")

        def on_any(event: Event) -> None:
            self.trace.append(f"fallback:{type(event).__name__}")

        self.on_demo = listener(DemoEvent)(on_demo)
        self.on_any = listener(Event)(on_any)


def build_parser() -> argparse.ArgumentParser:
    """Create the top-level CLI parser."""
    parser = argparse.ArgumentParser(prog="kevent", description="Event system utilities")
    subparsers = parser.add_subparsers(dest="command")

    demo_parser = subparsers.add_parser("demo", help="Run a dispatch demonstration")
    demo_parser.add_argument("message", nargs="?", default="hello from kevent")

    return parser


def run_demo(message: str) -> list[str]:
    """Execute a small in-memory event dispatch demonstration."""
    trace: list[str] = []
    handler = EventHandler()
    middleware = DemoMiddleware(trace)
    handler.add_middleware(middleware)
    handler.lookup(DemoSubscriber(trace))
    handler.publish(DemoEvent(message))
    return trace


def main(argv: Sequence[str] | None = None) -> int:
    """Run the kevent command-line interface."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "demo":
        trace = run_demo(args.message)
        for item in trace:
            print(item)
        return 0

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
