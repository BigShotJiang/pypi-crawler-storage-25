"""Event handler and dispatch logic."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Iterable
from typing import Any, cast

from kevent.event import Event
from kevent.listener import EventType, Listener
from kevent.middleware import Middleware

ErrorHandler = Callable[[Exception, Event, Listener[Any]], None]


class EventHandler:
    """Dispatch events to typed listeners and generic fallbacks."""

    def __init__(
        self,
        *lookup: object,
        on_error: ErrorHandler | None = None,
    ) -> None:
        """Create a handler and eagerly inspect any lookup objects.

        Args:
            *lookup: Objects to scan for listener declarations.
            on_error: Optional callback for handling listener exceptions.
        """
        self.middlewares: list[Middleware] = []
        self.listeners: dict[EventType, list[Listener[Any]]] = defaultdict(list)
        self.on_error = on_error
        for obj in lookup:
            self.lookup(obj)

    def add_middleware(self, middleware: Middleware) -> None:
        """Register middleware that runs before listener dispatch."""
        self.middlewares.append(middleware)

    def subscribe(self, listener: Listener[Any]) -> None:
        """Register a listener once for its declared event type."""
        listeners = self.listeners[listener.event]
        if listener not in listeners:
            listeners.append(listener)

    def lookup(self, obj: object) -> None:
        """Discover listener declarations on an object and subscribe them."""
        own_attributes = vars(obj) if hasattr(obj, "__dict__") else {}
        for attribute_name in dir(obj):
            attribute = getattr(obj, attribute_name)
            if isinstance(attribute, Listener):
                if attribute_name in own_attributes:
                    self.subscribe(attribute)
                else:
                    self.subscribe(self._bind_listener(attribute, obj))

    def _bind_listener(self, listener: Listener[Any], owner: object) -> Listener[Any]:
        """Bind listener callbacks to an instance owner when needed."""
        if isinstance(owner, type):
            return listener

        callback_getter = getattr(listener.callback, "__get__", None)
        if callback_getter is None:
            return listener

        bound_callback = callback_getter(owner, type(owner))
        return Listener(event=listener.event, callback=bound_callback)

    def publish(self, event: Event) -> None:
        """Run middleware and dispatch the event to matching listeners.

        Middleware execute first and can cancel event propagation by returning None.
        Listeners are matched by exact type and by traversing the event class hierarchy.
        """
        current_event: Event | None = event
        for middleware in self.middlewares:
            current_event = middleware.process(current_event)
            if current_event is None:
                return

        for cls in type(current_event).__mro__:
            cls_key = cast(EventType, cls)
            if cls_key not in self.listeners:
                continue

            for listener in self.listeners[cls_key]:
                try:
                    listener.callback(current_event)
                except Exception as exc:
                    if self.on_error:
                        self.on_error(exc, current_event, listener)
                    else:
                        raise

            if cls is Event:
                break

    def listeners_for(self, event_type: EventType) -> Iterable[Listener[Any]]:
        """Return registered listeners for a specific event type."""
        return tuple(self.listeners[event_type])

    @property
    def handlers_count(self) -> int:
        """Return the total number of registered listeners."""
        return sum(len(listeners) for listeners in self.listeners.values())

    def __repr__(self) -> str:
        """Return a compact debugging representation."""
        return f"<EventHandler listeners={self.handlers_count}>"
