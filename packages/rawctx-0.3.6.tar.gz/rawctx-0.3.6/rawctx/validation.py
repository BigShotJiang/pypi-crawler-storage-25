from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from rawctx.formats.osi import OsiSummary, validate_osi
from rawctx.packaging.manifest import Manifest, ValidationError, load_manifest, validate_manifest


@dataclass(frozen=True)
class ValidateResult:
    target: Path
    validated_files: list[Path] = field(default_factory=list)
    manifest: Manifest | None = None
    osi_summaries: dict[Path, OsiSummary] = field(default_factory=dict)


def resolve_manifest_path(path: Path) -> Path:
    candidate = path / "rawctx.yaml"
    if candidate.is_file():
        return candidate
    raise ValidationError("rawctx.yaml not found", path)


def is_manifest_file(path: Path) -> bool:
    return path.name == "rawctx.yaml"


def is_osi_file(path: Path) -> bool:
    name = path.name.lower()
    return name.endswith(".osi.yaml") or name.endswith(".osi.yml")


def validate_manifest_file(manifest_path: Path) -> tuple[Manifest, list[Path]]:
    manifest = load_manifest(manifest_path)
    validate_manifest(manifest, manifest_path.parent, manifest_path=manifest_path)
    return manifest, [manifest_path]


def validate_osi_file(osi_path: Path) -> tuple[OsiSummary, list[Path]]:
    summary = validate_osi(osi_path)
    return summary, [osi_path]


def validate_directory(target: Path, format_hint: str) -> ValidateResult:
    manifest_path = resolve_manifest_path(target)
    manifest = load_manifest(manifest_path)
    validate_manifest(manifest, target, manifest_path=manifest_path)

    validated_files = [manifest_path]
    osi_summaries: dict[Path, OsiSummary] = {}
    if format_hint in {"auto", "osi"}:
        for model in manifest.models:
            model_path = target / model
            summary = validate_osi(model_path)
            osi_summaries[model_path] = summary
            validated_files.append(model_path)

    return ValidateResult(
        target=target,
        manifest=manifest,
        validated_files=validated_files,
        osi_summaries=osi_summaries,
    )


def validate_file(target: Path, format_hint: str) -> ValidateResult:
    if format_hint == "manifest":
        manifest, files = validate_manifest_file(target)
        return ValidateResult(target=target, manifest=manifest, validated_files=files)
    if format_hint == "osi":
        summary, files = validate_osi_file(target)
        return ValidateResult(target=target, validated_files=files, osi_summaries={target: summary})

    if is_manifest_file(target):
        manifest, files = validate_manifest_file(target)
        return ValidateResult(target=target, manifest=manifest, validated_files=files)
    if is_osi_file(target):
        summary, files = validate_osi_file(target)
        return ValidateResult(target=target, validated_files=files, osi_summaries={target: summary})

    raise ValueError("auto format requires rawctx.yaml or *.osi.yaml/*.osi.yml file")


def validate_target(target: Path, format_hint: str = "auto") -> ValidateResult:
    if format_hint not in {"auto", "manifest", "osi"}:
        raise ValueError("format must be one of: auto, manifest, osi")

    resolved_target = target.expanduser().resolve()
    if not resolved_target.exists():
        raise ValidationError("target does not exist", resolved_target)

    if resolved_target.is_dir():
        return validate_directory(resolved_target, format_hint)
    if not resolved_target.is_file():
        raise ValidationError("target must be a file or directory", resolved_target)
    return validate_file(resolved_target, format_hint)
