from __future__ import annotations

import re

_INSTALL_COMMAND_RE = re.compile(r"\brawctx install\b")
_DEST_FLAG_RE = re.compile(r"(?<!\S)--dest(?=(?:=|\s|`|$))")


def rewrite_legacy_install_commands(markdown: str) -> str:
    rendered = markdown.replace("\r\n", "\n")
    rendered = _INSTALL_COMMAND_RE.sub("rawctx snapshot-download", rendered)
    rendered = _DEST_FLAG_RE.sub("--local-dir", rendered)
    return rendered
