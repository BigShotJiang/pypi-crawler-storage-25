from __future__ import annotations

from dataclasses import dataclass
from math import ceil
from pathlib import Path
from typing import Any, Iterable

from rawctx.errors import UsageError
from rawctx.formats.osi import read_osi
from rawctx.semantic import LoadedPackage, Relationship


@dataclass
class _PromptDatasetBlock:
    name: str
    primary_label: str
    compact_label: str
    measures: list[str]
    dimensions: list[str]
    measure_visible_count: int
    dimension_visible_count: int
    use_compact_label: bool = False

    @property
    def label(self) -> str:
        if self.use_compact_label:
            return self.compact_label
        return self.primary_label

    @property
    def compact_savings(self) -> int:
        if self.use_compact_label:
            return 0
        return max(0, len(self.primary_label) - len(self.compact_label))


@dataclass(frozen=True)
class _PromptRelationship:
    text: str
    priority: int


@dataclass(frozen=True)
class _DatasetMetadata:
    description: str | None
    source: str | None


def _clean_str(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return cleaned or None


def _estimate_tokens(text: str) -> int:
    return max(1, ceil(len(text) / 4))


def _dataset_metadata(snapshot_dir: Path, model_paths: list[str]) -> dict[str, _DatasetMetadata]:
    metadata: dict[str, _DatasetMetadata] = {}
    for model_path in model_paths:
        document = read_osi(snapshot_dir / model_path)
        semantic_models = document.get("semantic_model")
        if not isinstance(semantic_models, list):
            continue
        for semantic_model in semantic_models:
            if not isinstance(semantic_model, dict):
                continue
            raw_datasets = semantic_model.get("datasets")
            if not isinstance(raw_datasets, list):
                continue
            for raw_dataset in raw_datasets:
                if not isinstance(raw_dataset, dict):
                    continue
                name = _clean_str(raw_dataset.get("name"))
                if name is None or name in metadata:
                    continue
                metadata[name] = _DatasetMetadata(
                    description=_clean_str(raw_dataset.get("description")),
                    source=_clean_str(raw_dataset.get("source")),
                )
    return metadata


def _normalize_requested_datasets(available: list[str], datasets: Iterable[str] | None) -> list[str]:
    if datasets is None:
        return list(available)

    raw_items = [datasets] if isinstance(datasets, str) else list(datasets)
    selected: list[str] = []
    seen: set[str] = set()
    missing: list[str] = []
    available_set = set(available)

    for item in raw_items:
        if not isinstance(item, str) or not item.strip():
            raise UsageError("datasets must contain non-empty strings")
        normalized = item.strip()
        if normalized in seen:
            continue
        seen.add(normalized)
        if normalized not in available_set:
            missing.append(normalized)
            continue
        selected.append(normalized)

    if missing:
        raise UsageError(f"Unknown dataset(s): {', '.join(missing)}")
    return selected


def _group_names_by_dataset(loaded: LoadedPackage, dataset_names: list[str]) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    measures = {dataset_name: [] for dataset_name in dataset_names}
    dimensions = {dataset_name: [] for dataset_name in dataset_names}

    for measure in loaded.measures:
        if measure.dataset in measures:
            measures[measure.dataset].append(measure.name)

    for dimension in loaded.dimensions:
        if dimension.dataset in dimensions:
            dimensions[dimension.dataset].append(dimension.name)

    return measures, dimensions


def _primary_label(name: str, metadata: _DatasetMetadata | None) -> str:
    if metadata is None:
        return name
    return metadata.description or metadata.source or name


def _compact_label(name: str, metadata: _DatasetMetadata | None) -> str:
    if metadata is None:
        return name
    if metadata.description:
        return metadata.source or name
    if metadata.source:
        return name
    return name


def _build_dataset_blocks(loaded: LoadedPackage, dataset_names: list[str]) -> list[_PromptDatasetBlock]:
    metadata = _dataset_metadata(loaded.snapshot_dir, loaded.model_paths)
    measures_by_dataset, dimensions_by_dataset = _group_names_by_dataset(loaded, dataset_names)

    blocks: list[_PromptDatasetBlock] = []
    for dataset_name in dataset_names:
        dataset_metadata = metadata.get(dataset_name)
        measures = measures_by_dataset.get(dataset_name, [])
        dimensions = dimensions_by_dataset.get(dataset_name, [])
        blocks.append(
            _PromptDatasetBlock(
                name=dataset_name,
                primary_label=_primary_label(dataset_name, dataset_metadata),
                compact_label=_compact_label(dataset_name, dataset_metadata),
                measures=measures,
                dimensions=dimensions,
                measure_visible_count=len(measures),
                dimension_visible_count=len(dimensions),
            )
        )
    return blocks


def _format_endpoint(dataset: str, columns: list[str]) -> str:
    if not columns:
        return dataset
    if len(columns) == 1:
        return f"{dataset}.{columns[0]}"
    return f"{dataset}({', '.join(columns)})"


def _format_relationship(relationship: Relationship) -> str:
    return (
        f"{_format_endpoint(relationship.from_dataset, relationship.from_columns)}"
        f" -> "
        f"{_format_endpoint(relationship.to_dataset, relationship.to_columns)}"
    )


def _build_relationships(loaded: LoadedPackage, selected_datasets: list[str]) -> list[_PromptRelationship]:
    selected_set = set(selected_datasets)
    selected_selected: list[_PromptRelationship] = []
    selected_external: list[_PromptRelationship] = []

    for relationship in loaded.relationships:
        from_selected = relationship.from_dataset in selected_set
        to_selected = relationship.to_dataset in selected_set
        if not (from_selected or to_selected):
            continue

        item = _PromptRelationship(
            text=_format_relationship(relationship),
            priority=0 if from_selected and to_selected else 1,
        )
        if item.priority == 0:
            selected_selected.append(item)
        else:
            selected_external.append(item)

    return selected_selected + selected_external


def _render_name_list(names: list[str], visible_count: int) -> str:
    if not names:
        return "-"
    if visible_count >= len(names):
        return ", ".join(names)
    shown = max(1, visible_count)
    hidden = len(names) - shown
    return f"{', '.join(names[:shown])}, ..., +{hidden} more"


def _render_prompt(
    *,
    header: str,
    blocks: list[_PromptDatasetBlock],
    relationships: list[_PromptRelationship],
    minimal: bool,
) -> str:
    lines = [header, "", "Datasets:"]
    if not blocks:
        lines.append("-")
    elif minimal:
        for block in blocks:
            lines.append(f"- {block.name}")
    else:
        for index, block in enumerate(blocks):
            lines.append(f"- {block.name}: {block.label}")
            lines.append(f"  measures: {_render_name_list(block.measures, block.measure_visible_count)}")
            lines.append(f"  dimensions: {_render_name_list(block.dimensions, block.dimension_visible_count)}")
            if index != len(blocks) - 1:
                lines.append("")

    lines.extend(("", "Relationships:"))
    if relationships:
        lines.extend(f"- {relationship.text}" for relationship in relationships)
    else:
        lines.append("-")
    return "\n".join(lines)


def _select_list_to_shrink(blocks: list[_PromptDatasetBlock]) -> tuple[int, str] | None:
    candidates: list[tuple[int, int, int, str]] = []
    for index, block in enumerate(blocks):
        if block.measure_visible_count > 1:
            candidates.append((block.measure_visible_count, 0, index, "measure"))
        if block.dimension_visible_count > 1:
            candidates.append((block.dimension_visible_count, 1, index, "dimension"))

    if not candidates:
        return None

    _, _, block_index, kind = max(candidates, key=lambda item: (item[0], item[1], item[2]))
    return block_index, kind


def _shrink_lists(
    *,
    header: str,
    blocks: list[_PromptDatasetBlock],
    relationships: list[_PromptRelationship],
    max_tokens: int,
) -> str:
    prompt = _render_prompt(header=header, blocks=blocks, relationships=relationships, minimal=False)
    while _estimate_tokens(prompt) > max_tokens:
        candidate = _select_list_to_shrink(blocks)
        if candidate is None:
            break
        block_index, kind = candidate
        if kind == "measure":
            blocks[block_index].measure_visible_count -= 1
        else:
            blocks[block_index].dimension_visible_count -= 1
        prompt = _render_prompt(header=header, blocks=blocks, relationships=relationships, minimal=False)
    return prompt


def _compact_labels(
    *,
    header: str,
    blocks: list[_PromptDatasetBlock],
    relationships: list[_PromptRelationship],
    max_tokens: int,
) -> str:
    prompt = _render_prompt(header=header, blocks=blocks, relationships=relationships, minimal=False)
    while _estimate_tokens(prompt) > max_tokens:
        candidates = [
            (block.compact_savings, index)
            for index, block in enumerate(blocks)
            if block.compact_savings > 0
        ]
        if not candidates:
            break
        _, block_index = max(candidates, key=lambda item: (item[0], item[1]))
        blocks[block_index].use_compact_label = True
        prompt = _render_prompt(header=header, blocks=blocks, relationships=relationships, minimal=False)
    return prompt


def build_prompt(
    *,
    package_ref: str,
    loaded: LoadedPackage,
    info_payload: dict[str, Any],
    datasets: Iterable[str] | None = None,
    max_tokens: int = 2000,
) -> str:
    del package_ref
    if max_tokens < 1:
        raise UsageError("max_tokens must be >= 1")

    selected_datasets = _normalize_requested_datasets(loaded.datasets, datasets)
    blocks = _build_dataset_blocks(loaded, selected_datasets)
    relationships = _build_relationships(loaded, selected_datasets)

    package_info = info_payload.get("package") if isinstance(info_payload.get("package"), dict) else {}
    domain = _clean_str(package_info.get("domain")) or "unknown"
    package_name = loaded.package.rsplit("/", 1)[-1]
    header = f"Domain: {domain} ({package_name})"

    prompt = _render_prompt(header=header, blocks=blocks, relationships=relationships, minimal=False)
    if _estimate_tokens(prompt) <= max_tokens:
        return prompt

    prompt = _shrink_lists(header=header, blocks=blocks, relationships=relationships, max_tokens=max_tokens)
    if _estimate_tokens(prompt) <= max_tokens:
        return prompt

    trimmed_relationships = list(relationships)
    prompt = _render_prompt(header=header, blocks=blocks, relationships=trimmed_relationships, minimal=False)
    while _estimate_tokens(prompt) > max_tokens and trimmed_relationships:
        trimmed_relationships.pop()
        prompt = _render_prompt(header=header, blocks=blocks, relationships=trimmed_relationships, minimal=False)
    if _estimate_tokens(prompt) <= max_tokens:
        return prompt

    prompt = _compact_labels(header=header, blocks=blocks, relationships=trimmed_relationships, max_tokens=max_tokens)
    if _estimate_tokens(prompt) <= max_tokens:
        return prompt

    minimal_relationships = list(trimmed_relationships)
    prompt = _render_prompt(header=header, blocks=blocks, relationships=minimal_relationships, minimal=True)
    while _estimate_tokens(prompt) > max_tokens and minimal_relationships:
        minimal_relationships.pop()
        prompt = _render_prompt(header=header, blocks=blocks, relationships=minimal_relationships, minimal=True)
    return prompt

