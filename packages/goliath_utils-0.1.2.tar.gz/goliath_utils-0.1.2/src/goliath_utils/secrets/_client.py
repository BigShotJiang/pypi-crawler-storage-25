"""Secrets client for the Goliath secrets API."""

from __future__ import annotations

import os

import httpx
from dotenv import load_dotenv

from ._errors import SecretNotFoundError, SecretsAuthError, SecretsRequestError


class SecretsClient:
    """Client for the Goliath secrets API.

    Reads configuration from constructor args or environment variables:
    GOLIATH_API_URL, GOLIATH_API_KEY.
    """

    def __init__(
        self,
        *,
        api_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ):
        load_dotenv()

        self.api_url = (api_url or os.environ.get("GOLIATH_API_URL", "")).rstrip("/")
        self.api_key = api_key or os.environ.get("GOLIATH_API_KEY", "")

        if not self.api_url or not self.api_key:
            raise SecretsAuthError(
                "API credentials required. Set GOLIATH_API_URL and "
                "GOLIATH_API_KEY environment variables, or pass them directly."
            )

        self._base = self.api_url.rstrip("/")
        self._http = httpx.Client(
            headers={"X-API-Key": self.api_key},
            timeout=timeout,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # -- internal helpers --------------------------------------------------

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Send request and handle errors at both HTTP and API level."""
        resp = self._http.request(method, f"{self._base}/secrets{path}", **kwargs)

        if resp.status_code == 404:
            detail = resp.text
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                pass
            raise SecretNotFoundError(detail)

        if resp.status_code >= 400:
            raise SecretsRequestError(resp.status_code, resp.text)

        data = resp.json()
        if data.get("error") == 1:
            raise SecretsRequestError(resp.status_code, data.get("msg", "Unknown error"))

        return data

    # -- CRUD --------------------------------------------------------------

    def setup(self) -> dict:
        """Initialize the secrets table. Idempotent."""
        return self._request("POST", "/setup")

    def create(self, section: str, key: str, value: str) -> dict:
        """Create a secret. Returns the secret record dict."""
        data = self._request(
            "POST", "/", json={"section": section, "key": key, "value": value}
        )
        return data["secret"]

    def list(self, *, section: str | None = None, limit: int = 100) -> list[dict]:
        """List secrets, optionally filtered by section."""
        params: dict[str, str | int] = {"limit": limit}
        if section is not None:
            params["section"] = section
        data = self._request("GET", "/", params=params)
        return data["secrets"]

    def get(self, secret_id: int) -> dict:
        """Get a single secret by its numeric ID."""
        data = self._request("GET", f"/{secret_id}")
        return data["secret"]

    def update(
        self,
        secret_id: int,
        *,
        section: str | None = None,
        key: str | None = None,
        value: str | None = None,
    ) -> dict:
        """Update a secret. Only provided fields are changed."""
        body = {k: v for k, v in {"section": section, "key": key, "value": value}.items() if v is not None}
        data = self._request("PUT", f"/{secret_id}", json=body)
        return data["secret"]

    def delete(self, secret_id: int) -> None:
        """Delete a secret by ID."""
        self._request("DELETE", f"/{secret_id}")

    # -- convenience -------------------------------------------------------

    def get_section(self, section: str) -> dict[str, str]:
        """Get all secrets in a section as a flat {key: value} dict.

        Example::

            db = client.get_section("db_credentials")
            connect(host=db["host"], password=db["password"])
        """
        secrets = self.list(section=section)
        return {s["key"]: s["value"] for s in secrets}

    def get_value(self, section: str, key: str) -> str:
        """Get a single secret value by section and key.

        Raises SecretNotFoundError if the combination doesn't exist.
        """
        secrets = self.list(section=section)
        for s in secrets:
            if s["key"] == key:
                return s["value"]
        raise SecretNotFoundError(f"No secret found for section={section!r}, key={key!r}")

    def set_value(self, section: str, key: str, value: str) -> dict:
        """Create or update a secret (upsert by section + key)."""
        try:
            return self.create(section, key, value)
        except SecretsRequestError:
            secrets = self.list(section=section)
            for s in secrets:
                if s["key"] == key:
                    return self.update(s["id"], value=value)
            raise
