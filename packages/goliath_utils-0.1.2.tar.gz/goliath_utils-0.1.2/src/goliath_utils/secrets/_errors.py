class SecretsError(Exception):
    """Base exception for secrets operations."""


class SecretsAuthError(SecretsError):
    """Raised when API URL or API key is missing or invalid."""


class SecretsRequestError(SecretsError):
    """Raised when the secrets API returns an error response."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"Secrets API error {status_code}: {message}")


class SecretNotFoundError(SecretsRequestError):
    """Raised when a secret is not found."""

    def __init__(self, message: str = "Secret not found"):
        super().__init__(404, message)
