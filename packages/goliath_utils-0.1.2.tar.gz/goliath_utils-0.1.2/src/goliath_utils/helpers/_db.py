"""Database insertion helpers for Atrax DataSet."""

from __future__ import annotations

import logging
import os

from dotenv import load_dotenv

from goliath_utils.atrax import DataSet

logger = logging.getLogger("goliath.helpers.db")


def insert_dataset(
    ds: DataSet,
    table_name: str,
    db_url: str | None = None,
    connection=None,
    chunk_size: int = 1000,
) -> int:
    """Insert a DataSet into a database table in chunks.

    Pass a db_url (reads GOLIATH_DATABASE_URL env var if not provided)
    or a pre-existing connection object.

    Auto-reduces chunk size on MemoryError or connection failures.
    Returns the number of rows inserted.

    Requires psycopg2 when using db_url.
    """
    records = ds.to_dict(orient="records")
    if not records:
        return 0

    own_conn = False
    conn = connection

    if conn is None:
        try:
            import psycopg2
        except ImportError:
            raise ImportError(
                "psycopg2 is required for insert_dataset. "
                "Install it with: pip install psycopg2-binary"
            )

        load_dotenv()
        url = db_url or os.environ.get("GOLIATH_DATABASE_URL", "")
        if not url:
            raise ValueError(
                "Database URL required. Set GOLIATH_DATABASE_URL or pass db_url."
            )
        conn = psycopg2.connect(url)
        own_conn = True

    # Detect placeholder style: sqlite uses ?, psycopg2 uses %s
    module_name = type(conn).__module__
    placeholder = "?" if "sqlite" in module_name else "%s"

    columns = ds.columns
    placeholders = ", ".join([placeholder] * len(columns))
    col_names = ", ".join(columns)
    sql = f"INSERT INTO {table_name} ({col_names}) VALUES ({placeholders})"

    inserted = 0

    try:
        with conn:
            cur = conn.cursor()
            while inserted < len(records):
                end = min(inserted + chunk_size, len(records))
                chunk = records[inserted:end]
                values = [tuple(row[c] for c in columns) for row in chunk]
                try:
                    cur.executemany(sql, values)
                    inserted = end
                    logger.info("Inserted rows %d to %d (chunk size: %d)", inserted - len(chunk), end, chunk_size)
                except MemoryError:
                    chunk_size = max(100, chunk_size // 2)
                    logger.warning("MemoryError — reducing chunk size to %d", chunk_size)
                    conn.rollback()
                except Exception as e:
                    msg = str(e).lower()
                    if "connection closed" in msg or "terminated" in msg:
                        chunk_size = max(100, chunk_size // 2)
                        logger.warning("Connection issue — reducing chunk size to %d", chunk_size)
                        conn.rollback()
                    else:
                        raise
    finally:
        if own_conn:
            conn.close()

    logger.info("Inserted %d total rows into %s", inserted, table_name)
    return inserted
