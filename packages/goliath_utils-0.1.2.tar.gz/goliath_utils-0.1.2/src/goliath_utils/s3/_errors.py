class S3Error(Exception):
    """Base exception for S3 operations."""


class S3AuthError(S3Error):
    """Raised when AWS credentials are missing or invalid."""


class S3RequestError(S3Error):
    """Raised when the S3 API returns a non-2xx response."""

    def __init__(self, status_code: int, code: str, message: str):
        self.status_code = status_code
        self.code = code
        self.message = message
        super().__init__(f"S3 error {status_code} ({code}): {message}")
