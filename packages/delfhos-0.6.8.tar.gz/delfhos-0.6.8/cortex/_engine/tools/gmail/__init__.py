"""Internal gmail tool implementation."""
