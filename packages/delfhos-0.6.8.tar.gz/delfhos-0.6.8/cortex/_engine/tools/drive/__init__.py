"""Internal drive tool implementation."""
