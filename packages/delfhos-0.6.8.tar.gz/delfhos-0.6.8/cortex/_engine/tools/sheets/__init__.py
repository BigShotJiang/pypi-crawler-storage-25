"""Internal sheets tool implementation."""
