"""Compute the renderer's pixel-space canvas from the layout grid + theme.

The renderer needs concrete pixel dimensions for the SVG it emits:
canvas `width` / `height` and the effective spacings / margins the
coordinate transform multiplies into grid indices. `compute_canvas`
takes the grid extent (from `Layout.grid`, i.e. `LayoutGrid`) plus
the resolved theme, and walks an axis-relative auto-fit pass: four
helpers compute the pixel allowance along each axis edge
(branch-axis lower/upper, commit-axis lower/upper), then a single
visual-side mapping table converts those to (margin_left,
margin_right, margin_top, margin_bottom) per orientation.

This module lives in `render/` because it's purely pixel work. The
layout engine never reads it.
"""

from dataclasses import dataclass
from typing import Literal

from gitsvg.layout import Layout
from gitsvg.render._label_widths import commit_label_width, pill_width
from gitsvg.theme import OrientationLiteral, Theme

# Auto-fit safety margin between content (pill / outward label) and the canvas
# edge — keeps the rendered geometry from butting right up against the SVG
# bounding box. Deliberately not a `Theme` field: when a user wants more
# breathing room, the relevant `margin_*` theme field is the right knob to
# turn — this internal perceptual pad just prevents zero-margin clipping in
# the auto-fit path, and never needs per-diagram tuning.
_AUTO_FIT_EDGE_PAD_PX = 4.0  # axis-symmetric (perceptual)

_AxisEdge = Literal["lower", "upper"]

# Maps each orientation to the visual side each axis edge corresponds
# to. Mirrors the `label_side` axis-index → pixel-side mapping pattern
# from invariant #7 (`docs/architecture.md`): axis-relative reasoning
# everywhere; orientation enters once at the boundary.
_AXIS_TO_VISUAL: dict[OrientationLiteral, dict[str, str]] = {
    "bt": {"branch_lower": "left", "branch_upper": "right", "commit_lower": "bottom", "commit_upper": "top"},
    "tb": {"branch_lower": "left", "branch_upper": "right", "commit_lower": "top", "commit_upper": "bottom"},
    "lr": {"branch_lower": "top", "branch_upper": "bottom", "commit_lower": "left", "commit_upper": "right"},
    "rl": {"branch_lower": "top", "branch_upper": "bottom", "commit_lower": "right", "commit_upper": "left"},
}


@dataclass(slots=True)
class RenderCanvas:
    """Computed pixel-space canvas the renderer's coordinate transform reads from.

    Spacings, margins, and orientation flow from the resolved theme;
    slot counts flow from `Layout.grid` (the `LayoutGrid`, populated
    from `state.grid` if pinned, otherwise auto-fit).

    Margin attributes name visual sides of the canvas, not axis-index
    sides — they always refer to the same screen edge regardless of
    orientation. The geometry module reads `orientation` to map grid
    indices to pixel coordinates per the four-orientation rule.

    Attributes:
        width: SVG canvas width in pixels.
        height: SVG canvas height in pixels.
        n_commits: Effective commit-axis slot count (pinned via `grid.n_commits`
            or auto-fit from content).
        n_branches: Effective branch-axis slot count.
        branch_spacing: Effective pixel distance between adjacent branch-axis slots.
        commit_spacing: Effective pixel distance between adjacent commit-axis slots.
        margin_left: Effective pixel margin at the visually-left canvas edge.
        margin_right: Effective pixel margin at the visually-right canvas edge.
        margin_bottom: Effective pixel margin at the visually-bottom canvas edge.
        margin_top: Effective pixel margin at the visually-top canvas edge.
        orientation: Active orientation (`bt`, `tb`, `lr`, `rl`). Drives
            the geometry module's grid → pixel mapping.
    """

    width: float  # axis-symmetric (visual)
    height: float  # axis-symmetric (visual)
    n_commits: int  # axis-bound: commit-axis (slot count)
    n_branches: int  # axis-bound: branch-axis (slot count)
    branch_spacing: float  # axis-bound: branch-axis
    commit_spacing: float  # axis-bound: commit-axis
    margin_left: float  # axis-symmetric (visual-side, px)
    margin_right: float  # axis-symmetric (visual-side, px)
    margin_bottom: float  # axis-symmetric (visual-side, px)
    margin_top: float  # axis-symmetric (visual-side, px)
    orientation: OrientationLiteral  # axis-symmetric (selector)


def compute_canvas(layout: Layout, theme: Theme) -> RenderCanvas:
    """Compute the effective `RenderCanvas` for `layout` under `theme`.

    Margins auto-fit to the longest visible labels and pills via four
    axis-relative helpers + a per-orientation visual-side mapping;
    spacings and default margins come from the resolved theme (the
    `theme:` op is the only source for those, per invariant #6).

    Args:
        layout: The completed layout, supplying the integer-grid extent
            (`n_commits`, `n_branches`) and the entities (branches,
            commits, PRs) that drive the auto-fit margin computation.
        theme: The resolved theme, supplying spacings and default
            margins plus the font sizes used in label-width estimation.

    Returns:
        A `RenderCanvas` carrying the pixel-space width / height and the
        effective spacing / margin values the coordinate transform reads.
    """
    grid = layout.grid
    orientation = theme.orientation

    branch_spacing = theme.branch_spacing
    commit_spacing = theme.commit_spacing

    n_commits = grid.n_commits
    n_branches = grid.n_branches

    # Axis-relative auto-fit needs (pure: no notion of visual sides).
    axis_needs: dict[str, float] = {
        "branch_lower": _auto_fit_branch_axis_edge(layout, theme, edge="lower"),
        "branch_upper": _auto_fit_branch_axis_edge(layout, theme, edge="upper"),
        "commit_lower": _auto_fit_commit_axis_edge(layout, theme, edge="lower"),
        "commit_upper": _auto_fit_commit_axis_edge(layout, theme, edge="upper"),
    }

    # Map axis-relative needs to visual sides per orientation; take the
    # wider of the theme default and the computed need on each side.
    # Force-cast to float so the coordinate transform's `y = margin_top
    # + ...` formula propagates float type into y attributes drawsvg
    # emits, keeping the SVG output stable across orientations.
    margins: dict[str, float] = {
        "left": float(theme.margin_left),
        "right": float(theme.margin_right),
        "top": float(theme.margin_top),
        "bottom": float(theme.margin_bottom),
    }
    for axis_edge, visual_side in _AXIS_TO_VISUAL[orientation].items():
        margins[visual_side] = max(margins[visual_side], axis_needs[axis_edge])

    is_vertical = orientation in ("bt", "tb")
    if is_vertical:
        width = margins["left"] + (n_branches - 1) * branch_spacing + margins["right"]
        height = margins["top"] + (n_commits - 1) * commit_spacing + margins["bottom"]
    else:
        width = margins["left"] + (n_commits - 1) * commit_spacing + margins["right"]
        height = margins["top"] + (n_branches - 1) * branch_spacing + margins["bottom"]
    return RenderCanvas(
        width=width,
        height=height,
        n_commits=n_commits,
        n_branches=n_branches,
        branch_spacing=branch_spacing,
        commit_spacing=commit_spacing,
        margin_left=margins["left"],
        margin_right=margins["right"],
        margin_bottom=margins["bottom"],
        margin_top=margins["top"],
        orientation=orientation,
    )


# ==================================================================================================
#  Branch-axis auto-fit
# ==================================================================================================
def _auto_fit_branch_axis_edge(layout: Layout, theme: Theme, *, edge: _AxisEdge) -> float:
    """Pixel allowance for content protruding past a branch-axis edge.

    The branch-axis edges are perpendicular to the lane direction —
    `edge="lower"` is lane 0, `edge="upper"` is the maximum-index
    lane. Considers two sources:

    - Outward-pointing commit labels on the edge lane. Text extends
      along the branch axis from the label anchor, in the same
      direction the edge faces.
    - Edge-lane branch-name pills. The pill rect's extent along the
      branch axis depends on orientation: in vertical orientations
      the rect is centred horizontally over the lane line so the
      half-pill-width protrudes; in horizontal orientations the rect
      is anchored along the commit axis (rect width runs along the
      commit axis, height along the branch axis), so the half-pill-
      height protrudes along the branch axis.

    Args:
        layout: Supplies branches and commits to walk.
        theme: Supplies font sizes, label offset, and the orientation
            that drives the pill-extent branch.
        edge: Which branch-axis edge to compute.

    Returns:
        Pixel allowance needed past the edge; returns 0 if nothing
        on the edge protrudes.
    """
    branches = layout.branches
    commit_layouts = layout.commits
    max_branch_pos = max((b.branch_pos for b in branches), default=0)
    target_lane = 0 if edge == "lower" else max_branch_pos
    matching_label_side = "before" if edge == "lower" else "after"

    is_vertical = theme.orientation in ("bt", "tb")
    pill_height = theme.branch_label_font_size + theme.pill_padding_y

    needed: float = 0.0
    for branch in branches:
        if branch.branch_pos == target_lane:
            extent = (pill_width(branch.name, theme) / 2) if is_vertical else (pill_height / 2)
            needed = max(needed, extent + _AUTO_FIT_EDGE_PAD_PX)
    for commit in commit_layouts.values():
        if commit.branch_pos == target_lane and commit.label_side == matching_label_side:
            extent = theme.label_offset + commit_label_width(commit, theme)
            needed = max(needed, extent + _AUTO_FIT_EDGE_PAD_PX)
    return needed


# ==================================================================================================
#  Commit-axis auto-fit
# ==================================================================================================
def _auto_fit_commit_axis_edge(layout: Layout, theme: Theme, *, edge: _AxisEdge) -> float:
    """Pixel allowance for content protruding past a commit-axis edge.

    The commit-axis edges run along the commit-axis direction —
    `edge="lower"` is commit row 0, `edge="upper"` is the maximum
    commit row. Considers two sources:

    - Branch-name pills at branch starts. Default offset is negative
      along the commit axis in every orientation, so branches with
      `start == 0` protrude past the lower edge; an override making
      the offset positive would shift the case to a branch with
      `start == max_commit_pos`.
    - PR-title pills at projected merge rows. Default offset is
      negative along the commit axis in vertical orientations and
      zero in horizontal orientations; positive overrides shift the
      case to the upper edge.

    The pill's extent past its anchor depends on orientation: in
    vertical orientations the rect is centred on the anchor so the
    half-pill-height extends along the commit axis; in horizontal
    orientations the rect's near-edge is anchored at the offset
    point so the full pill_width extends in the offset direction
    along the commit axis.

    Args:
        layout: Supplies branches and PRs to walk.
        theme: Supplies offset fields, font sizes, and the
            orientation that drives the pill-extent branch.
        edge: Which commit-axis edge to compute.

    Returns:
        Pixel allowance needed past the edge; returns 0 if nothing
        on the edge protrudes.
    """
    is_vertical = theme.orientation in ("bt", "tb")
    pill_height = theme.branch_label_font_size + theme.pill_padding_y
    max_commit_pos = layout.grid.n_commits - 1

    needed: float = 0.0

    # Branch-name pills.
    branch_offset_rows = theme.branch_name_pill_offset_commit_axis_in_rows
    if branch_offset_rows != 0:
        protrudes_at = "lower" if branch_offset_rows < 0 else "upper"
        if edge == protrudes_at:
            target_start = 0 if edge == "lower" else max_commit_pos
            offset_px = abs(branch_offset_rows) * theme.commit_spacing
            for branch in layout.branches:
                if branch.start == target_start:
                    extent = offset_px + (pill_height / 2 if is_vertical else pill_width(branch.name, theme))
                    needed = max(needed, extent + _AUTO_FIT_EDGE_PAD_PX)

    # PR-title pills (only branches with a non-None title render a pill).
    pr_offset_rows = theme.pull_request_pill_offset_commit_axis_in_rows
    if pr_offset_rows != 0:
        protrudes_at = "lower" if pr_offset_rows < 0 else "upper"
        if edge == protrudes_at:
            target_pos = 0 if edge == "lower" else max_commit_pos
            offset_px = abs(pr_offset_rows) * theme.commit_spacing
            for pr in layout.pull_requests:
                if pr.title is None or pr.to_commit_pos != target_pos:
                    continue
                extent = offset_px + (pill_height / 2 if is_vertical else pill_width(pr.title, theme))
                needed = max(needed, extent + _AUTO_FIT_EDGE_PAD_PX)

    return needed
