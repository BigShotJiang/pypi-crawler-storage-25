# -*- coding: utf-8 -*-
"""Functions used by the Stoner.Data class."""

import numpy as np
from scipy.interpolate import interp1d
from scipy.optimize import curve_fit, fsolve, newton
from scipy.signal import get_window
from scipy.stats import sem

from ..tools import format_error, make_Class, make_Data
from .fitting.models.generic import linear

__all__ = ["outlier", "threshold", "_twoD_fit", "ApplyAffineTransform", "GetAffineTransform", "poly_outlier"]


def outlier(row, window, metric, ycol=None, shape="bopxcar"):
    """Outlier detector function.

    Calculates if the current row is an outlier from the surrounding data by looking
    at the number of standard deviations away from the average of the window it is.

    Args:
        row (array):
            Single row of the dataset.
        window (array):
            Section of data surrounding the row being examined.
        metric (float):
            distance the current row is from the local mean.

    Keyword Arguments:
        ycol (column index or None):
            If set, specifies the column containing the data to check.

    Returns:
        (bool):
            If True, then the current row is an outlier from the local data.
    """
    windowing = get_window(shape, len(window))
    windowing /= windowing.sum() / windowing.size
    av = np.average(window[:, ycol] * windowing)
    std = np.std(window[:, ycol])  # standard deviation
    return abs(row[ycol] - av) > metric * std


def poly_outlier(row, window, metric=3.0, ycol=None, xcol=None, order=1, yerr=None):
    """Alternative outlier detection function that fits a polynomial locally over the window.

    Args:
        row (1D array):
            Current row of data
        column int):
            Column index of y values to examine
        window (2D array):
            Local window of data

    Keyyword Arguments:
        metric (float):
            Some measure of how sensitive the dection should be
        xcol (column index):
            Column of data to use for X values. Defaults to current setas value
        order (int):
            Order of polynomial to fit. Must be < length of window-1

    Returns:
        (bool):
            True if current row is an outlier
    """
    if order > window.shape[0] - 2:
        raise ValueError(f"order should be smaller than the window length. {order} vs {window.shape[0] - 2}")

    x = window[:, xcol] - row[xcol]
    y = window[:, ycol]
    if yerr:
        w = 1.0 / window[:, yerr]
    else:
        w = None

    popt, pcov = np.polyfit(x, y, w=w, deg=order, cov=True)
    pval = np.polyval(popt, 0.0)
    perr = np.sqrt(np.diag(pcov))[-1]
    return (pval - row[ycol]) ** 2 > metric * perr


def threshold(threshold, data, rising=True, falling=False):
    """Implement the threshold method - also used in peak-finder.

    Args:
        threshold (float):
            Threshold valuye in data to look for
        rising (bool):
            Find points where data is rising up past threshold
        falling (bool):
            Find points where data is falling below the threshold

    Returns:
        (array):
            Fractional indices where the data has crossed the threshold assuming a
            straight line interpolation between two points.
    """
    # First we find all points where we cross zero in the correct direction
    current = data
    previous = np.roll(current, 1)
    current = np.atleast_1d(current)
    index = np.arange(len(current))
    sdat = np.column_stack((index, current, previous))
    if rising and not falling:

        def _expr(x):
            return (x[1] >= threshold) & (x[2] < threshold)

    elif rising and falling:

        def _expr(x):
            return ((x[1] >= threshold) & (x[2] < threshold)) | ((x[1] <= threshold) & (x[2] > threshold))

    elif falling and not rising:

        def _expr(x):
            return (x[1] <= threshold) & (x[2] > threshold)

    else:

        def _expr(_):
            return False

    # Now we refine the estimate of zero crossing with a cubic interpolation
    # and use Newton's root finding method to locate the zero in the interpolated data

    intr = interp1d(index, data.ravel() - threshold, kind="cubic")
    roots = []
    for ix, x in enumerate(sdat):
        if ix > 0 and _expr(x):  # There's a root somewhere here !
            try:
                roots.append(newton(intr, ix))
            except (ValueError, RuntimeError):  # fell off the end here
                pass
    return np.array(roots)


def _twoD_fit(xy1, xy2, xmode="linear", ymode="linear", m0=None):
    r"""Calculae an optimal transformation of points :math:`(x_1,y_1)\rightarrow(x_2,y_2)`.

    Arguments:
        xy1 ( n by 2 array of float):
            Set of points to be mapped from.
        xy2 ( n by 2 array of floats):
            Set of points to be mapped to.

    Keyword Arguments:
        xmode ('affine', 'linear', 'scale' 'offset' or 'fixed'):
            How to manipulate the x-data
        ymode ('linear', 'scale' 'offset' or 'fixed'):
            How to manipulate the y-data
        m0 (3x2 array):
            Initial and fixed values of the transformation. Defaults to using an identity transformation.

    Returns:
        (tuple of opt_trans,trans_err,mapping func)

    The most general case is an affine transform which includes rotation, scale, translation and skew. This is
    represented as a 2 x 3 matrix  of coordinates. The *xmode* and *ymode* parameters control the possible operations
    to align the data in x and y directions, in addition to which the *xmode* parameter can take the value 'affine'
    which allows a full affine transformation. The returned values are the affine transformation matrix, the
    uncertainties in this and a function to map coordinates with the optimal affine transformation.

    Note:
        *m0* combines both giving an initial value and fixed values for the transformation. If *m0* is set, then it
        is used to provide initial balues of the free parameters. Which elelemnts of *m0* that are free parameters
        and which are fixed is determined by the *xmode* and *ymode* parameters. IF *xmode* and *ymode* are both
        fixed, however, no scaling is done at all.
    """
    if xy1.shape != xy2.shape or xy1.shape[1] != 2:
        raise RuntimeError(f"coordinate arrays must be equal length with two columns, not {xy1.shape} and {xy2.shape}")
    xvarp = {
        "affine": [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2]],
        "linear": [[0, 0], [0, 2]],
        "scale": [[0, 0]],
        "offset": [[0, 2]],
        "fixed": [[]],
    }
    yvarp = {"linear": [[1, 1], [1, 2]], "scale": [[1, 1]], "offset": [[1, 2]], "fixed": [[]]}

    if xmode not in xvarp or ymode not in yvarp:
        raise RuntimeError(f"xmode and ymode must be one of 'linear','scale','offset','fixed' not {xmode} and {ymode}")

    if xmode == "affine":
        ymode = "fixed"

    xunknowns = len(xvarp[xmode])
    yunknowns = len(yvarp[ymode])
    if xunknowns + yunknowns == 0:  # shortcircuit for the trivial case
        return np.array([[1, 0], [1, 0]]), np.zeros((2, 2)), lambda x: x

    mapping = xvarp[xmode] + yvarp[ymode]
    mapping = [m for m in mapping if m]  # remove empty mappings
    data = np.column_stack((xy1, xy2)).T

    if isinstance(m0, list):
        m0 = np.array(m0)

    if m0 is None:
        p0s = {"affine": [1, 0, 0, 0, 1, 0], "linear": [1, 0], "scale": [1], "offset": [0], "fixed": []}
        p0 = p0s[xmode] + p0s[ymode]
        default = np.array([[1.00, 0.0, 0.0], [0.0, 1.0, 0.0]])
    elif isinstance(m0, np.ndarray) and m0.shape == (2, 3):
        p0 = [0] * len(mapping)
        for i, [u, v] in enumerate(mapping):
            p0[i] = m0[u, v]
            default = m0
    else:
        raise RuntimeError(f"m0 starting matrix should be a numpy array of size (2,3) not {m0}")

    result = np.zeros(len(xy1))

    def transform(xy, *p):  # Construct the fitting function
        """Fitting function to find the transfoprm."""
        xy1 = np.column_stack((xy[:2, :].T, np.ones(xy.shape[1]))).T
        xy2 = xy[2:, :]
        for pi, (u, v) in zip(p, mapping):
            default[u, v] = pi
        xyt = np.dot(default, xy1)
        ret = np.sqrt(np.sum((xy2 - xyt) ** 2, axis=0))
        return ret

    popt, pcov = curve_fit(transform, data, result, p0=p0)  # pylint: disable=unbalanced-tuple-unpacking
    perr = np.sqrt(np.diag(pcov))

    # Initialise the return values
    default = np.array([[1.00, 0.0, 0.0], [0.0, 1.0, 0.0]])
    for pi, (u, v) in zip(popt, mapping):
        default[u, v] = pi
    default_err = np.zeros((2, 3))
    for pi, (u, v) in zip(perr, mapping):
        default_err[u, v] = pi

    def _transform(xy):
        return ApplyAffineTransform(xy, default)

    return (default, default_err, _transform)


def ApplyAffineTransform(xy, transform):  # pylint: disable=invalid-name
    """Apply a given afffine transform to a set of xy data points.

    Args:
        xy (n by 2 array):
            Set of x,y coordinates to be transformed
        transform (2 by 3 array):
            Affine transform matrix.

    Returns:
        (n x 2 array).
        Transformed coordinates.
    """
    xyt = np.vstack((xy.T, np.ones(len(xy))))
    xyt = np.dot(transform, xyt)
    return xyt.T


def GetAffineTransform(p, pd):  # pylint: disable=invalid-name
    """Calculate an affine transform from 2 sets of three points.

    Args:
        p (3x2 array):
            Coordinates of points to transform from.
        pd (3x2 array):
            Coordinates of points to transform to.

    Returns:
        (2x3 array):
            matrix representing the affine transform.
    """
    if np.shape(p) != (3, 2) and np.shape(pd) != (3, 2):
        raise RuntimeError("Must supply three points")

    p = np.append(p, np.atleast_2d(np.ones(3)).T, axis=1)
    transform = np.linalg.solve(p, pd)
    return transform.T


def _step(x, m, c, h):
    """Provide a sloping step function for fitting to the extrema of a hysteresis loop.

    Args:
        x (array-like):
            Field (x) data of loop.
        m (float):
            susceptibility(slopee) of loop.
        c (float):
            vertical offset of loop.
        h (float):
            Saturatted moement (height) of loop.

    Returns:
        y (Tarray-like):
            Calculated moment of loop.
    """
    mid = (x.max() + x.min()) / 2.0

    X = x - mid
    y = m * x + c + np.sign(X) * h
    return y


def _h_sat_linear(d, i, Ms_vals, Hsat_vals, h_sat_fraction):
    """Determine the saturation field from linear fits to the hysteresis loop.

    This method uses the intercept of the saturated state with zero field portions of the loop.
    """
    from Stoner.analysis.fitting.models.generic import (
        Linear,  # pylint: disable=import-outside-toplevel
    )

    Ms, Ms_err, _ = Ms_vals
    Hsat, Hsat_err = Hsat_vals

    # Fit a straight line to the central fraction of the data
    if i == 1:

        def _bounds(_, r):
            return np.abs(r.y) < np.abs(Ms) * h_sat_fraction

    else:

        def _bounds(_, r):
            return np.abs(r.y) < np.abs(Ms) * h_sat_fraction

    popt, pcov = d.lmfit(Linear, bounds=_bounds)
    perr = np.sqrt(np.diag(pcov))
    popt = popt[:2]
    pferr = perr / popt
    # Pick the positive or negative Ms depending on the up or down loop
    Ms_i = Ms if i == 0 else -Ms
    # Find the intercept
    Hsat[1 - i] = fsolve(lambda x: Linear().func(x, *popt) - Ms_i, 0)[0]
    # Uncertainty is the sum of error in slope * found intercept and error in Ms times slope
    Hsat_err[1 - i] = np.sqrt((Hsat[1 - i] * pferr[1]) ** 2 + (popt[1] * Ms_err) ** 2)

    return (Hsat, Hsat_err)


def _h_sat_susceptibility(d, i, Ms_vals, Hsat_vals, h_sat_fraction):  # pylint: disable=unused-argument
    """Determine the saturation field from the change in local sysceptibility in the loop."""
    Hsat, Hsat_err = Hsat_vals
    xi = d.SG_Filter(order=1)[0, :]
    m, h = d.SG_Filter()
    tmp = np.column_stack((h, m, xi))[4:-4]
    tmp = make_Data(tmp, setas="x.y")
    threshold = tmp.mean(bounds=lambda r: not 7 < r.i < len(tmp) - 7) * h_sat_fraction
    hs = tmp.threshold(threshold, all_vals=True, rising=i != 0, falling=i == 0)  # Get the H_sat value
    Hsat[1 - i] = np.mean(hs)  # Get the H_sat value
    if hs.size > 1:
        Hsat_err[1 - i] = sem(hs)
    else:
        Hsat_err[1 - i] = np.nan
    return (Hsat, Hsat_err)


def _h_sat_delta_M(d, i, Ms_vals, Hsat_vals, h_sat_fraction):  # pylint: disable=unused-argument
    """Determine the saturation field from the change in magnetisation from Ms."""
    m_sat = Ms_vals[2]
    Hsat, Hsat_err = Hsat_vals
    m, h = d.SG_Filter()
    tmp = np.column_stack((h, m))[4:-4]
    tmp = make_Data(tmp, setas="xy")
    threshold = m_sat[i]
    hs = tmp.threshold(threshold, all_vals=True, rising=True, falling=True).view(np.ndarray)  # Get the H_sat value
    if hs.size > 1:
        hs = hs[np.argmin(np.abs(hs))]
    Hsat[1 - i] = hs  # Get the H_sat value
    Hsat_err[1 - i] = np.nan
    return (Hsat, Hsat_err)


def _up_down(data):
    """Split data d into rising and falling sections and then add and sort the two sets.

    This routine searches for the local maxima and minima in the x-axis data by identifying points
    where the x-data is more than 95% of the total span from the mid-point. It thenuses this to identify
    ranges of rows where the x value passes from one extreme to the other and splits the data file up on
    that basis. This assumes that the x-data is reasonably well behaved in the the increments between
    successive x-values are larger than the noise in x. This will work best if the x value is derived from a set value
    rather than the read-back value.

    Args:
        data (Data):
            DataFile like object with x and y columns set

    Returns:
        (Data, Data):
            Tuple of two DataFile like instances for the rising and falling data.
    """
    # Calculate x span and mid-point for working out limits to search for maxima.
    lx, hx = data.span(data.setas.xcol)
    mid = (lx + hx) / 2.0
    span = hx - lx
    high = data.x > mid + 0.45 * span
    low = data.x < mid - 0.45 * span

    # Locate points where we cross a threshold
    t = np.zeros((2, len(data) + 2), dtype=bool)
    t[0, 1:-1] = high
    t[1, 1:-1] = low
    t = np.diff(t)

    # Find  the indiices of the highest and lowest extrema
    high_i = np.arange(len(data) + 1, dtype=int)[t[0, :]]
    low_i = np.arange(len(data) + 1, dtype=int)[t[1, :]]
    if low_i.size > 2:
        low_i = np.reshape(low_i, (2, -1)).mean(axis=1)
    else:
        low_i = np.array(low_i.mean())
    if high_i.size > 2:
        high_i = np.reshape(high_i, (2, -1)).mean(axis=1)
    else:
        high_i = np.array(high_i.mean())
    # Build a sorted list of extrema positions + the start and end of the data
    indices = np.unique(np.append(low_i, np.append(high_i, np.array([0, len(data) - 1]))))
    indices = np.ceil(indices).astype(int)
    indices.sort()
    if indices[-1] >= len(data):  # Remove possible over-range element
        indices = indices[0:-1]

    # Build a boolean array to index the data for rows that where x is increasing
    rising = np.zeros(len(data), dtype=bool)
    for ix, iy in zip(indices[:-1], indices[1:]):
        if data.x[iy] > data.x[ix]:
            rising[ix:iy] = True

    # Clone the data and select rows that are either rising or falling in the two clones.
    up = data.clone
    up.data = up.data[rising]
    down = data.clone
    down.data = down.data[~rising]
    # Done.
    return up, down


def split_up_down(data, col=None, folder=None):
    """Split the DataFile data into several files where the column *col* is either rising or falling.

    Args:
        data (:py:class:`Stoner.Core.DataFile`):
            object containign the data to be sorted
        col (index):
            is something that :py:meth:`Stoner.Core.DataFile.find_col` can use
        folder (:py:class:`Stoner.Folders.DataFolder` or None):
            if this is an instance of :py:class:`Stoner.Folders.DataFolder` then add
            rising and falling files to groups of this DataFolder, otherwise create a new one

    Returns:
        (:py:class:`Sonter.Folder.DataFolder`):
            with two groups, rising and falling
    """
    a = make_Data(data)
    if col is None:
        _ = a._col_args()
        col = _.xcol
    width = int(len(a) / 10)
    if width % 2 == 0:  # Ensure the window for Satvisky Golay filter is odd
        width += 1
    setas = a.setas.clone
    a.setas = ""
    peaks = list(a.peaks(ycol=col, width=width, full_data=False))
    troughs = list(a.peaks(ycol=col, width=width, peaks=False, troughs=True, full_data=False))
    a.setas = setas
    if peaks and troughs:  # Ok more than up down here
        order = peaks[0] < troughs[0]
    elif peaks:  # Rise then fall
        order = True
    elif troughs:  # Fall then rise
        order = False
    else:  # No peaks or troughs so just return a single rising
        ret = make_Class("DataFolder", readlist=False)
        ret += data
        return ret
    splits = [0, len(a)]
    splits.extend(peaks)
    splits.extend(troughs)
    splits.sort()
    splits = [int(s) for s in splits]
    if not isinstance(folder, make_Class("DataFolder", None)):  # Create a new DataFolder object
        output = make_Class("DataFolder", readlist=False)
    else:
        output = folder
    output.add_group("rising")
    output.add_group("falling")

    if order:
        risefall = ["rising", "falling"]
    else:
        risefall = ["falling", "rising"]
    for i in range(len(splits) - 1):
        working = data.clone
        working.data = data.data[splits[i] : splits[i + 1], :]
        output.groups[risefall[i % 2]].append(working)
    return output


Hickeyify = format_error


def hysteresis_correct(data, **kwargs):
    """Perform corrections to a hysteresis loop.

    Args:
        data (Data):
            The data containing the hysteresis loop. The :py:attr:`DataFile.setas` attribute
            should be set to give the H and M axes as x and y.

    Keyword Arguments:
        correct_background (bool):
            Correct for a diamagnetic or paramagnetic background to the hystersis loop
            also recentres the loop about zero moment (default True).
        correct_H (bool):
            Finds the co-ercive fields and sets them to be equal and opposite. If the loop is sysmmetric
            this will remove any offset in filed due to trapped flux (default True)
        saturated_fraction (float):
            The fraction of the horizontal (field) range where the moment can be assumed to be
            fully saturated. If an integer is given it will use that many data points at the end of the loop.
        h_sat_method (str):
            The method used to determine thwe saturation field. Options are -
            -   "linear_intercept" (default): Fit a straight line to the central region of each branch of the loop
                and look at the
                intercept with the relevant saturation moment.
            -   "delta_M": Look for a field where the moment has changed by *h_sat_fraction* times the error in M_s.
            -   "susceptibility" - Calculate H_sat from where the susceptibility changes by 1% of the average
                susceptibility
        h_sat_fraction (float):
            The central fraction of the saturation moment that is used for calculating the saturation field. Defaults
            to 0.5
        xcol (column index):
            Column with the x data in it
        ycol (column_index):
            Column with the y data in it
        setas (string or iterable):
            Column assignments.

    Returns:
        (:py:class:`Stoner.Data`):
            The original loop with the x and y columns replaced with corrected data and extra metadata added to give
            the background suceptibility, offset in moment, co-ercive fields and saturation magnetisation.
    """
    cls = make_Data(None)
    if isinstance(data, cls):
        cls = type(data)

    data = cls(data)

    # Get other keyword arguments
    correct_bg = kwargs.pop("correct_background", True)
    correct_H = kwargs.pop("correct_H", True)
    saturation_f = kwargs.pop("saturated_fraction", 0.2)

    h_sat_method = kwargs.pop("h_sat_method", "linear_intercept")
    h_sat_fraction = kwargs.pop("h_sat_fraction", 0.5 if h_sat_method == "linear_intercept" else 2.0)
    hsat_methods = {
        "linear_intercept": _h_sat_linear,
        "susceptibility": _h_sat_susceptibility,
        "delta_M": _h_sat_delta_M,
    }
    if callable(h_sat_method) or h_sat_method in hsat_methods:
        h_sat_method = hsat_methods.get(h_sat_method, h_sat_method)
    else:
        raise ValueError("Saturation field method not recognized!")

    for k, val in kwargs.items():
        try:
            setattr(data, k, val)
        except AttributeError:
            if data.debug:
                print("Error setting attribute from keyword {k}={val}")
    if "setas" in kwargs:  # Allow us to override the setas variable
        data.setas = kwargs.pop("setas")

    xcol = kwargs.pop("xcol", data.setas.xcol)
    ycol = kwargs.pop("ycol", data.setas.ycol)
    # Get xcol and ycols from kwargs if specified
    _ = data._col_args(xcol=xcol, ycol=ycol)
    data.setas(x=_.xcol, y=_.ycol, reset=False)
    # Split into two sets of data:

    up, down = _up_down(data)

    mid = (data.x.max() + data.x.min()) / 2.0
    span = data.x.max() - data.x.min()
    low = mid - span * (1 - saturation_f) / 2
    high = mid + span * (1 - saturation_f) / 2

    popt, pcov = data.curve_fit(_step, bounds=lambda x, r: not low < x < high)

    perr = np.sqrt(np.diag(pcov))

    Ms = popt[2]
    Ms_err = perr[2]

    data["Ms"] = Ms  # mean(Ms)
    data["Ms Error"] = Ms_err
    data["Offset Moment"] = popt[1]
    data["Offset Moment Error"] = perr[1]
    data["Background susceptibility"] = popt[0]
    data["Background Susceptibility Error"] = perr[0]

    if correct_bg:
        fixes = [data, up, down]
    else:
        fixes = [up, down]
    m = popt[0]
    c = popt[1] - m * mid

    for d in fixes:
        d.y = d.y - linear(d.x, c, m)

    Hc = [None, None]
    Hc_err = [None, None]
    Hsat = [None, None]
    Hsat_err = [None, None]
    Mr = [None, None]
    Mr_err = [None, None]

    m_sat = [Ms - h_sat_fraction * Ms_err, -Ms + h_sat_fraction * Ms_err]
    single_side = False

    for i, d in enumerate([up, down]):
        if len(d) < 2:
            single_side = True
            continue
        hc = d.threshold(0.0, all_vals=True, rising=i == 0, falling=i != 0)  # Get the Hc value
        Hc[i] = np.mean(hc)
        if hc.size > 1:
            Hc_err[i] = sem(hc)

        Hsat, Hsat_err = h_sat_method(d, i, (Ms, Ms_err, m_sat), (Hsat, Hsat_err), h_sat_fraction)

        mr = d.threshold(0.0, col=_.xcol, xcol=_.ycol, all_vals=True, rising=True, falling=True)
        Mr[i] = np.mean(mr)
        if mr.size > 1:
            Mr_err[i] = sem(mr)

    if correct_H and not single_side:
        Hc_mean = np.mean(Hc)
        for d in [data, up, down]:
            d.x = d.x - Hc_mean
        data["Exchange Bias offset"] = Hc_mean
    else:
        Hc_mean = 0.0

    if not single_side:
        data["Hc"] = (Hc[1] - Hc_mean, Hc[0] - Hc_mean)
        data["Hc_mean"] = np.abs(np.array(Hc)).mean()
        data["Hsat"] = (Hsat[1] - Hc_mean, Hsat[0] - Hc_mean)
        data["Hsat Error"] = (Hsat_err[1], Hsat_err[0])
        data["Hsat_mean"] = np.abs(np.array(Hsat)).mean()
        data["Hsat_mean Error"] = np.sqrt(np.array(Hsat_err) ** 2)[0] / 2.0
    else:
        data["Hc"] = [x for x in Hc if x is not None]
        data["Hc_mean"] = abs(data["Hc"][0])
        data["Hsat"] = [x for x in Hsat if x is not None]
        data["Hsat Error"] = [x for x in Hsat_err if x is not None]
        data["Hsat_mean"] = abs(data["Hsat"][0])
        data["Hsat_mean Error"] = abs(data["Hsat Error"][0])
    data["Remenance"] = Mr

    bh = (-data.x) * data.y
    i = np.argmax(bh)
    data["BH_Max"] = max(bh)
    data["BH_Max_H"] = data.x[i]

    data["Area"] = data.integrate(output="result")
    return cls(data)
