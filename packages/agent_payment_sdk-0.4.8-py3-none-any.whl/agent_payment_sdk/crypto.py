"""Optional crypto signing module — requires web3"""
try:
    from web3 import Web3
    from eth_account import Account
    WEB3_AVAILABLE = True
except ImportError:
    WEB3_AVAILABLE = False


def sign_eth_transfer(
    private_key: str,
    to_address: str,
    amount_wei: int,
    nonce: int,
    gas_price: int,
    chain_id: int = 8453  # Base Mainnet
) -> str:
    """Sign an ETH transfer transaction, return raw signed tx hex"""
    if not WEB3_AVAILABLE:
        raise ImportError("web3 is required for crypto payments. Install with: pip install agent-payment-sdk[crypto]")

    account = Account.from_key(private_key)
    tx = {
        "to": Web3.to_checksum_address(to_address),
        "value": amount_wei,
        "gas": 21000,
        "gasPrice": gas_price,
        "nonce": nonce,
        "chainId": chain_id
    }
    signed = account.sign_transaction(tx)
    return signed.raw_transaction.hex()



ROUTER_CONTRACT_ADDRESS = "0xB4732569092a4DFfd18A2D1A37bD8d3A4B0C291e"
ROUTER_ABI = [{
    "inputs": [
        {"internalType": "address", "name": "receiver", "type": "address"},
        {"internalType": "uint256", "name": "feeBps", "type": "uint256"}
    ],
    "name": "routePayment",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
}]

def sign_router_payment(
    private_key: str,
    receiver_address: str,
    amount_wei: int,
    fee_bps: int,
    nonce: int,
    gas_price: int,
    chain_id: int = 8453
) -> str:
    """Sign a routePayment contract call — atomic fee split, non-custodial."""
    if not WEB3_AVAILABLE:
        raise ImportError("web3 is required for crypto payments. Install with: pip install agent-payment-sdk[crypto]")
    account = Account.from_key(private_key)
    w3 = Web3()
    contract = w3.eth.contract(
        address=Web3.to_checksum_address(ROUTER_CONTRACT_ADDRESS),
        abi=ROUTER_ABI
    )
    tx = contract.functions.routePayment(
        Web3.to_checksum_address(receiver_address),
        fee_bps
    ).build_transaction({
        "from": account.address,
        "value": amount_wei,
        "gas": 80000,
        "gasPrice": gas_price,
        "nonce": nonce,
        "chainId": chain_id
    })
    signed = account.sign_transaction(tx)
    return signed.raw_transaction.hex()

def get_address_from_key(private_key: str) -> str:
    """Derive wallet address from private key"""
    if not WEB3_AVAILABLE:
        raise ImportError("web3 is required. Install with: pip install agent-payment-sdk[crypto]")
    account = Account.from_key(private_key)
    return account.address
