"""Governor configuration getter owner."""

from __future__ import annotations

import logging
import os
from typing import Any

from obra.config.typed_schema import ParallelConfig

from .. import _core

logger = logging.getLogger(__name__)

__all__ = [
    "get_governor_config",
]


def _resolve_global_env_overrides(defaults: Any) -> dict[str, Any]:
    """Resolve the global env-var override layer."""
    overrides = {
        "enabled": defaults.enabled,
        "max_concurrent_calls": defaults.max_concurrent_calls,
        "cooldown_s": defaults.cooldown_s,
        "acquire_timeout_s": defaults.acquire_timeout_s,
        "env_enabled": os.environ.get("OBRA_GOVERNOR_ENABLED"),
        "env_max": os.environ.get("OBRA_GOVERNOR_MAX_CONCURRENT"),
        "env_cooldown": os.environ.get("OBRA_GOVERNOR_COOLDOWN_S"),
        "env_timeout": os.environ.get("OBRA_GOVERNOR_ACQUIRE_TIMEOUT_S"),
    }

    env_enabled = overrides["env_enabled"]
    if env_enabled is not None:
        overrides["enabled"] = str(env_enabled).lower() not in ("0", "false", "no")

    env_max = overrides["env_max"]
    if env_max is not None:
        try:
            value = int(env_max)
            if value > 0:
                overrides["max_concurrent_calls"] = value
            else:
                logger.warning("OBRA_GOVERNOR_MAX_CONCURRENT must be > 0 (got %s)", env_max)
        except (TypeError, ValueError):
            logger.warning("OBRA_GOVERNOR_MAX_CONCURRENT must be an integer (got %s)", env_max)

    env_cooldown = overrides["env_cooldown"]
    if env_cooldown is not None:
        try:
            value = float(env_cooldown)
            if value >= 0:
                overrides["cooldown_s"] = value
            else:
                logger.warning("OBRA_GOVERNOR_COOLDOWN_S must be >= 0 (got %s)", env_cooldown)
        except (TypeError, ValueError):
            logger.warning("OBRA_GOVERNOR_COOLDOWN_S must be a number (got %s)", env_cooldown)

    env_timeout = overrides["env_timeout"]
    if env_timeout is not None:
        try:
            value = float(env_timeout)
            if value > 0:
                overrides["acquire_timeout_s"] = value
            else:
                logger.warning("OBRA_GOVERNOR_ACQUIRE_TIMEOUT_S must be > 0 (got %s)", env_timeout)
        except (TypeError, ValueError):
            logger.warning("OBRA_GOVERNOR_ACQUIRE_TIMEOUT_S must be a number (got %s)", env_timeout)

    return overrides


def _parse_provider_overrides(raw_providers: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Normalize provider overrides from orchestration.governor.providers."""
    overrides: dict[str, dict[str, Any]] = {}
    for provider_name, provider_data in raw_providers.items():
        if not isinstance(provider_data, dict):
            continue
        provider_override = {
            "max_concurrent_calls": None,
            "cooldown_s": None,
            "models": {},
            "codex_refresh_lock": None,
        }
        raw_max = provider_data.get("max_concurrent_calls")
        if raw_max is not None:
            try:
                value = int(raw_max)
                if value > 0:
                    provider_override["max_concurrent_calls"] = value
            except (TypeError, ValueError):
                pass
        raw_cooldown = provider_data.get("cooldown_s")
        if raw_cooldown is not None:
            try:
                value = float(raw_cooldown)
                if value >= 0:
                    provider_override["cooldown_s"] = value
            except (TypeError, ValueError):
                pass
        raw_models = provider_data.get("models", {})
        if isinstance(raw_models, dict):
            model_overrides: dict[str, dict[str, Any]] = {}
            for model_name, model_data in raw_models.items():
                if not isinstance(model_data, dict):
                    continue
                model_override: dict[str, Any] = {
                    "max_concurrent_calls": None,
                    "cooldown_s": None,
                }
                raw_model_max = model_data.get("max_concurrent_calls")
                if raw_model_max is not None:
                    try:
                        value = int(raw_model_max)
                        if value > 0:
                            model_override["max_concurrent_calls"] = value
                    except (TypeError, ValueError):
                        pass
                raw_model_cooldown = model_data.get("cooldown_s")
                if raw_model_cooldown is not None:
                    try:
                        value = float(raw_model_cooldown)
                        if value >= 0:
                            model_override["cooldown_s"] = value
                    except (TypeError, ValueError):
                        pass
                model_overrides[str(model_name)] = model_override
            provider_override["models"] = model_overrides
        raw_lock = provider_data.get("codex_refresh_lock")
        if isinstance(raw_lock, dict):
            lock_override: dict[str, Any] = {}
            if raw_lock.get("enabled") is not None:
                lock_override["enabled"] = bool(raw_lock["enabled"])
            if raw_lock.get("lock_window_s") is not None:
                try:
                    value = float(raw_lock["lock_window_s"])
                    if value >= 0:
                        lock_override["lock_window_s"] = value
                except (TypeError, ValueError):
                    pass
            if raw_lock.get("assumed_validity_s") is not None:
                try:
                    value = float(raw_lock["assumed_validity_s"])
                    if value > 0:
                        lock_override["assumed_validity_s"] = value
                except (TypeError, ValueError):
                    pass
            provider_override["codex_refresh_lock"] = lock_override
        overrides[provider_name] = provider_override
    return overrides


def _process_governor_section(
    governor_section: dict[str, Any],
    env_overrides: dict[str, Any],
    defaults: Any,
) -> dict[str, Any]:
    """Resolve the orchestration.governor section."""
    from obra.llm.governor import (
        CodexRefreshLockConfig,
        ModelGovernorConfig,
        ProviderGovernorConfig,
    )

    resolved = {
        "enabled": env_overrides["enabled"],
        "max_concurrent_calls": env_overrides["max_concurrent_calls"],
        "cooldown_s": env_overrides["cooldown_s"],
        "cooldown_jitter": defaults.cooldown_jitter,
        "pacing_s": defaults.pacing_s,
        "pacing_jitter": defaults.pacing_jitter,
        "acquire_timeout_s": env_overrides["acquire_timeout_s"],
        "providers": dict(defaults.providers),
        "log_wait_times": defaults.telemetry.log_wait_times,
        "warn_threshold_s": defaults.telemetry.warn_threshold_s,
    }

    # --- Pacing / jitter fields from config file ---
    for field_name in ("cooldown_jitter", "pacing_s", "pacing_jitter"):
        raw = governor_section.get(field_name)
        if raw is not None:
            try:
                value = float(raw)
                if value >= 0:
                    resolved[field_name] = value
            except (TypeError, ValueError):
                pass

    if env_overrides["env_enabled"] is None and governor_section.get("enabled") is not None:
        resolved["enabled"] = bool(governor_section.get("enabled"))
    if env_overrides["env_max"] is None and governor_section.get("max_concurrent_calls") is not None:
        try:
            value = int(governor_section.get("max_concurrent_calls"))
            if value > 0:
                resolved["max_concurrent_calls"] = value
        except (TypeError, ValueError):
            pass
    if env_overrides["env_cooldown"] is None and governor_section.get("cooldown_s") is not None:
        try:
            value = float(governor_section.get("cooldown_s"))
            if value >= 0:
                resolved["cooldown_s"] = value
        except (TypeError, ValueError):
            pass
    if (
        env_overrides["env_timeout"] is None
        and governor_section.get("acquire_timeout_s") is not None
    ):
        try:
            value = float(governor_section.get("acquire_timeout_s"))
            if value > 0:
                resolved["acquire_timeout_s"] = value
        except (TypeError, ValueError):
            pass

    raw_providers = governor_section.get("providers", {})
    if isinstance(raw_providers, dict):
        for provider_name, provider_override in _parse_provider_overrides(raw_providers).items():
            models = {
                model_name: ModelGovernorConfig(
                    max_concurrent_calls=model_override["max_concurrent_calls"],
                    cooldown_s=model_override["cooldown_s"],
                )
                for model_name, model_override in provider_override["models"].items()
            }
            raw_lock = provider_override["codex_refresh_lock"]
            codex_refresh_lock = None
            if isinstance(raw_lock, dict):
                codex_refresh_lock = CodexRefreshLockConfig(**raw_lock)
            resolved["providers"][provider_name] = ProviderGovernorConfig(
                max_concurrent_calls=provider_override["max_concurrent_calls"],
                cooldown_s=provider_override["cooldown_s"],
                models=models,
                codex_refresh_lock=codex_refresh_lock,
            )

    raw_telemetry = governor_section.get("telemetry", {})
    if isinstance(raw_telemetry, dict):
        if raw_telemetry.get("log_wait_times") is not None:
            resolved["log_wait_times"] = bool(raw_telemetry.get("log_wait_times"))
        if raw_telemetry.get("warn_threshold_s") is not None:
            try:
                value = float(raw_telemetry.get("warn_threshold_s"))
                if value > 0:
                    resolved["warn_threshold_s"] = value
            except (TypeError, ValueError):
                pass

    return resolved


def _process_parallel_fallback(
    parallel_config: dict[str, Any],
    env_overrides: dict[str, Any],
    defaults: Any,
) -> dict[str, Any]:
    """Resolve the backward-compatible orchestration.parallel fallback."""
    from obra.llm.governor import ProviderGovernorConfig

    resolved = {
        "enabled": env_overrides["enabled"],
        "max_concurrent_calls": env_overrides["max_concurrent_calls"],
        "cooldown_s": env_overrides["cooldown_s"],
        "cooldown_jitter": defaults.cooldown_jitter,
        "pacing_s": defaults.pacing_s,
        "pacing_jitter": defaults.pacing_jitter,
        "acquire_timeout_s": env_overrides["acquire_timeout_s"],
        "providers": dict(defaults.providers),
        "log_wait_times": defaults.telemetry.log_wait_times,
        "warn_threshold_s": defaults.telemetry.warn_threshold_s,
    }

    if not parallel_config:
        return resolved

    raw_delay = parallel_config.get("worker_delay_s")
    if raw_delay is not None and env_overrides["env_cooldown"] is None:
        try:
            value = float(raw_delay)
            if value >= 0:
                resolved["cooldown_s"] = value
        except (TypeError, ValueError):
            pass

    raw_overrides = parallel_config.get("provider_overrides", {})
    if isinstance(raw_overrides, dict):
        for provider_name, provider_delay in raw_overrides.items():
            try:
                value = float(provider_delay)
                if value >= 0:
                    existing = resolved["providers"].get(provider_name, ProviderGovernorConfig())
                    resolved["providers"][provider_name] = ProviderGovernorConfig(
                        max_concurrent_calls=existing.max_concurrent_calls,
                        cooldown_s=value,
                        models=dict(existing.models),
                        codex_refresh_lock=existing.codex_refresh_lock,
                    )
            except (TypeError, ValueError):
                pass

    return resolved


def _apply_parallel_compat_overrides(
    resolved: dict[str, Any],
    parallel_config: dict[str, Any],
    env_overrides: dict[str, Any],
) -> dict[str, Any]:
    """Overlay legacy orchestration.parallel cooldowns onto resolved governor config."""
    from obra.llm.governor import ProviderGovernorConfig

    if not parallel_config:
        return resolved
    raw_delay = parallel_config.get("worker_delay_s")
    if raw_delay is not None and env_overrides["env_cooldown"] is None:
        try:
            value = float(raw_delay)
            if value >= 0:
                resolved["cooldown_s"] = value
        except (TypeError, ValueError):
            pass

    raw_overrides = parallel_config.get("provider_overrides", {})
    if isinstance(raw_overrides, dict):
        for provider_name, provider_delay in raw_overrides.items():
            try:
                value = float(provider_delay)
                if value >= 0:
                    existing = resolved["providers"].get(provider_name, ProviderGovernorConfig())
                    resolved["providers"][provider_name] = ProviderGovernorConfig(
                        max_concurrent_calls=existing.max_concurrent_calls,
                        cooldown_s=value,
                        models=dict(existing.models),
                        codex_refresh_lock=existing.codex_refresh_lock,
                    )
            except (TypeError, ValueError):
                pass
    return resolved


def _apply_per_provider_env_overrides(providers: dict[str, Any]) -> dict[str, Any]:
    """Apply OBRA_GOVERNOR_COOLDOWN_S_<PROVIDER> env-var overrides."""
    from obra.llm.governor import ProviderGovernorConfig

    resolved_providers = dict(providers)
    for provider_name in list(resolved_providers.keys()):
        env_key = f"OBRA_GOVERNOR_COOLDOWN_S_{provider_name.upper()}"
        env_val = os.environ.get(env_key)
        if env_val is None:
            continue
        try:
            value = float(env_val)
            if value >= 0:
                existing = resolved_providers[provider_name]
                resolved_providers[provider_name] = ProviderGovernorConfig(
                    max_concurrent_calls=existing.max_concurrent_calls,
                    cooldown_s=value,
                    models=dict(existing.models),
                    codex_refresh_lock=existing.codex_refresh_lock,
                )
            else:
                logger.warning("%s must be >= 0 (got %s)", env_key, env_val)
        except (TypeError, ValueError):
            logger.warning("%s must be a number (got %s)", env_key, env_val)
    return resolved_providers


def get_governor_config():  # -> GovernorConfig (imported lazily to avoid circular deps)
    """Get the LLM concurrency governor configuration.

    Resolution order:
    1. OBRA_GOVERNOR_ENABLED, OBRA_GOVERNOR_MAX_CONCURRENT, OBRA_GOVERNOR_COOLDOWN_S
       env vars for global settings
    2. orchestration.governor.* from config file
    3. Backward compat: when orchestration.governor absent, construct from
       orchestration.parallel.worker_delay_s / provider_overrides
    4. Hardcoded defaults from GovernorConfig()

    Per-provider env overrides use OBRA_GOVERNOR_COOLDOWN_S_<PROVIDER> (uppercase).

    Returns:
        GovernorConfig populated from the resolution order above.
    """
    from obra.llm.governor import (  # local import avoids circular dependency
        GovernorConfig,
        GovernorTelemetryConfig,
    )

    defaults = GovernorConfig()
    env_overrides = _resolve_global_env_overrides(defaults)

    config, origins, _ = _core.load_layered_config(include_defaults=True)
    orch_config = config.get("orchestration", {}) if isinstance(config, dict) else {}
    governor_section = orch_config.get("governor", {}) if isinstance(orch_config, dict) else {}
    governor_has_non_default = any(
        path.startswith("orchestration.governor.") and origin != "default"
        for path, origin in origins.items()
    )

    if isinstance(governor_section, dict) and governor_section:
        resolved = _process_governor_section(governor_section, env_overrides, defaults)
        if not governor_has_non_default:
            try:
                parallel_config = ParallelConfig.model_validate(
                    orch_config.get("parallel", {}) if isinstance(orch_config, dict) else {}
                ).model_dump()
            except Exception:
                parallel_config = (
                    orch_config.get("parallel", {}) if isinstance(orch_config, dict) else {}
                )
            resolved = _apply_parallel_compat_overrides(
                resolved,
                parallel_config if isinstance(parallel_config, dict) else {},
                env_overrides,
            )
    else:
        parallel_config: dict[str, Any] = {}
        try:
            parallel_config = ParallelConfig.model_validate(
                orch_config.get("parallel", {}) if isinstance(orch_config, dict) else {}
            ).model_dump()
        except Exception:
            parallel_config = (
                orch_config.get("parallel", {}) if isinstance(orch_config, dict) else {}
            )
        resolved = _process_parallel_fallback(
            parallel_config if isinstance(parallel_config, dict) else {},
            env_overrides,
            defaults,
        )
    providers = _apply_per_provider_env_overrides(resolved["providers"])

    return GovernorConfig(
        enabled=resolved["enabled"],
        max_concurrent_calls=resolved["max_concurrent_calls"],
        cooldown_s=resolved["cooldown_s"],
        cooldown_jitter=resolved["cooldown_jitter"],
        pacing_s=resolved["pacing_s"],
        pacing_jitter=resolved["pacing_jitter"],
        acquire_timeout_s=resolved["acquire_timeout_s"],
        providers=providers,
        telemetry=GovernorTelemetryConfig(
            log_wait_times=resolved["log_wait_times"],
            warn_threshold_s=resolved["warn_threshold_s"],
        ),
    )
