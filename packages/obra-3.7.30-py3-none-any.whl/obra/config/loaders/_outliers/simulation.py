"""Simulation-specific config getter owners."""

from __future__ import annotations

import sys
from typing import Any

from obra.config.loaders import _core
from obra.exceptions import ConfigurationError

__all__ = [
    "get_nightly_simulation_config",
    "get_campaign_simulation_config",
    "get_local_emulator_config",
    "get_persona_harness_config",
    "get_simulation_runtime_config",
]


def get_nightly_simulation_config() -> dict[str, Any]:
    """Return the nightly simulation runner config as one validated dict."""
    parent_module = sys.modules.get("obra.config.loaders")
    if parent_module is None:
        raise RuntimeError("obra.config.loaders must be imported before simulation getters")

    return {
        "wait_poll_interval_s": parent_module.get_nightly_wait_poll_interval_s(),
        "max_total_loops": parent_module.get_nightly_max_total_loops(),
        "max_target_retries": parent_module.get_nightly_max_target_retries(),
        "max_fix_loops": parent_module.get_nightly_max_fix_loops(),
        "max_repair_attempts": parent_module.get_nightly_max_repair_attempts(),
        "repair_cooldown_s": parent_module.get_nightly_repair_cooldown_s(),
        "worker_timeout_s": parent_module.get_nightly_worker_timeout_s(),
        "analysis_tier": parent_module.get_nightly_analysis_tier(),
        "fix_tier": parent_module.get_nightly_fix_tier(),
        "enable_llm_fixes": parent_module.get_nightly_enable_llm_fixes(),
        "enable_session_repair": parent_module.get_nightly_enable_session_repair(),
        "allow_force_complete": parent_module.get_nightly_allow_force_complete(),
    }


def get_campaign_simulation_config() -> dict[str, Any]:
    """Return the campaign runner config as one validated dict."""
    parent_module = sys.modules.get("obra.config.loaders")
    if parent_module is None:
        raise RuntimeError("obra.config.loaders must be imported before simulation getters")

    return {
        "child_poll_interval_s": parent_module.get_campaign_child_poll_interval_s(),
        "bootstrap_ready_timeout_s": parent_module.get_campaign_bootstrap_ready_timeout_s(),
        "max_fix_loops": parent_module.get_campaign_max_fix_loops(),
        "confirmation_reruns": parent_module.get_campaign_confirmation_reruns(),
        "worker_timeout_s": parent_module.get_campaign_worker_timeout_s(),
        "analysis_tier": parent_module.get_campaign_analysis_tier(),
        "fix_tier": parent_module.get_campaign_fix_tier(),
        "enable_llm_fixes": parent_module.get_campaign_enable_llm_fixes(),
    }


def get_persona_harness_config() -> dict[str, Any]:
    """Return validated persona-driven Studio harness settings."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        gateway = config["gateway"]
    except KeyError as exc:
        raise ConfigurationError("gateway section is required") from exc
    if not isinstance(gateway, dict):
        raise ConfigurationError("gateway section must be a mapping")
    try:
        assistant = gateway["assistant"]
    except KeyError as exc:
        raise ConfigurationError("gateway.assistant section is required") from exc
    if not isinstance(assistant, dict):
        raise ConfigurationError("gateway.assistant section must be a mapping")
    try:
        driver_model = assistant["persona_driver_model"]
    except KeyError as exc:
        raise ConfigurationError("gateway.assistant.persona_driver_model is required") from exc
    try:
        judge_model = assistant["persona_judge_model"]
    except KeyError as exc:
        raise ConfigurationError("gateway.assistant.persona_judge_model is required") from exc
    try:
        runs_per_night = assistant["persona_runs_per_night"]
    except KeyError as exc:
        raise ConfigurationError("gateway.assistant.persona_runs_per_night is required") from exc
    try:
        normalized_runs = int(runs_per_night)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError("gateway.assistant.persona_runs_per_night must be an integer") from exc
    if normalized_runs < 1:
        raise ConfigurationError("gateway.assistant.persona_runs_per_night must be >= 1")
    return {
        "persona_driver_model": str(driver_model),
        "persona_judge_model": str(judge_model),
        "persona_runs_per_night": normalized_runs,
    }


def get_simulation_runtime_config() -> dict[str, int | float]:
    """Return validated local simulation runtime limits."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    simulation = config.get("simulation")
    if not isinstance(simulation, dict):
        raise ConfigurationError("simulation section is required")
    try:
        log_tail_lines = int(simulation["log_tail_lines"])
        tcp_probe_timeout_s = float(simulation["tcp_probe_timeout_s"])
    except KeyError as exc:
        raise ConfigurationError(f"simulation.{exc.args[0]} is required") from exc
    except (TypeError, ValueError) as exc:
        raise ConfigurationError("simulation runtime values must be numeric") from exc
    if log_tail_lines <= 0:
        raise ConfigurationError("simulation.log_tail_lines must be > 0")
    if tcp_probe_timeout_s <= 0:
        raise ConfigurationError("simulation.tcp_probe_timeout_s must be > 0")
    return {
        "log_tail_lines": log_tail_lines,
        "tcp_probe_timeout_s": tcp_probe_timeout_s,
    }


def get_local_emulator_config() -> dict[str, int]:
    """Return validated local Firebase emulator ports."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    local = config.get("local")
    if not isinstance(local, dict):
        raise ConfigurationError("local section is required")
    emulator = local.get("emulator")
    if not isinstance(emulator, dict):
        raise ConfigurationError("local.emulator section is required")
    try:
        firestore_port = int(emulator["firestore_port"])
        functions_port = int(emulator["functions_port"])
    except KeyError as exc:
        raise ConfigurationError(f"local.emulator.{exc.args[0]} is required") from exc
    except (TypeError, ValueError) as exc:
        raise ConfigurationError("local emulator ports must be integers") from exc
    for name, value in {
        "firestore_port": firestore_port,
        "functions_port": functions_port,
    }.items():
        if not 0 < value < 65536:
            raise ConfigurationError(f"local.emulator.{name} must be a valid TCP port")
    return {
        "firestore_port": firestore_port,
        "functions_port": functions_port,
    }
