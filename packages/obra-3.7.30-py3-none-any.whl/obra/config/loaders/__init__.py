"""Configuration file I/O and path management for Obra.

Handles loading and saving client configuration from
~/.obra/config-layers/01-user.yaml, plus environment variable resolution for
API URLs and timeouts.

Example:
    from obra.config.loaders import load_config, save_config, get_api_base_url

    config = load_config()
    api_url = get_api_base_url()
"""

import sys

# ── Submodule imports ──────────────────────────────────────────────────────
from . import _core

# ── Infrastructure functions from _core ───────────────────────────────────
from ._core import (
    clear_config_cache,
    enable_local_mode,
    expand_automation_mode,
    get_config_path,
    get_isolated_mode,
    get_workspace_layer_path,
    get_session_layer_override,
    get_session_layer_path,
    load_auth_state,
    load_config,
    load_config_with_warnings,
    load_layered_config,
    load_llm_section,
    load_workspace_layer,
    save_workspace_layer,
    resolve_config_alias,
    resolve_semantic_alias,
    save_auth_state,
    save_config,
    set_isolated_mode,
    validate_default_schema,
    validate_pipeline_config,
)

# ── Constants & data tables from _defaults ────────────────────────────────
from ._defaults import (
    AGENT_LLM_DEFAULTS,
    AUTH_STATE_PATH,
    CONFIG_LAYER_DIR,
    CONFIG_PATH,
    CONFIG_PATH_ALIASES,
    DEFAULT_AGENT_EXECUTION_TIMEOUT,
    DEFAULT_API_BASE_URL,
    DEFAULT_AUTO_UPDATE,
    DEFAULT_CHECK_FOR_UPDATES,
    DEFAULT_DECOMPOSITION_DURATION_THRESHOLD_S,
    DEFAULT_DECOMPOSITION_ENABLED,
    DEFAULT_DECOMPOSITION_EXECUTE_STREAM_IDLE_S,
    DEFAULT_DECOMPOSITION_FAILURE_THRESHOLD,
    DEFAULT_DECOMPOSITION_MAX_ATTEMPTS,
    DEFAULT_DECOMPOSITION_SUMMARY_MAX_CHARS,
    DEFAULT_DECOMPOSITION_WARNING_THRESHOLD_RATIO,
    DEFAULT_DECOMPOSITION_WARNING_THRESHOLD_S,
    DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG,
    DEFAULT_DERIVATION_BUDGET_CONFIG,
    DEFAULT_DERIVATION_EXPLORATION_LOOKBACK_MINUTES,
    DEFAULT_DERIVATION_TASK_CONFIG,
    DEFAULT_EXECUTE_ZERO_OUTPUT_RETRY_MAX,
    DEFAULT_GATEWAY_CORS_ORIGINS,
    DEFAULT_GATEWAY_ENABLE_CORS,
    DEFAULT_GATEWAY_ESCALATION_TIMEOUT_S,
    DEFAULT_GATEWAY_HOST,
    DEFAULT_GATEWAY_MAX_SESSIONS,
    DEFAULT_GATEWAY_PORT,
    DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD,
    DEFAULT_HANG_CONFIDENCE,
    DEFAULT_HYBRID_POLLING_CONFIG,
    DEFAULT_INPUT_BUDGET_ON_EXCEED,
    DEFAULT_INTENT_CHUNKING_CONFIG,
    DEFAULT_INTENT_RATE_LIMIT_CONFIG,
    DEFAULT_INTERACTIVE_GUARD_ENABLED,
    DEFAULT_INTERACTIVE_GUARD_PATTERNS,
    DEFAULT_INTERACTIVE_GUARD_RETRY_MAX,
    DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES,
    DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED,
    DEFAULT_LLM_API_TIMEOUT,
    DEFAULT_LLM_CALL_TIMEOUT,
    DEFAULT_LLM_STREAM_IDLE_TIMEOUT,
    DEFAULT_LLM_TIMEOUT,
    DEFAULT_MAX_ITERATIONS,
    DEFAULT_NETWORK_TIMEOUT,
    DEFAULT_PRIORITY_ORDER,
    DEFAULT_PROMPT_MAX_FILES,
    DEFAULT_QUALITY_POLICY_MODE,
    DEFAULT_QUALITY_THRESHOLD,
    DEFAULT_REFINEMENT_REGRESSION_MIN_DELTA,
    DEFAULT_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER,
    DEFAULT_REFINEMENT_STRAGGLER_ALERT_THRESHOLD,
    DEFAULT_RETRY_AUTH_MAX_ATTEMPTS,
    DEFAULT_RETRY_BACKOFF_MULTIPLIER,
    DEFAULT_RETRY_BASE_DELAY,
    DEFAULT_RETRY_JITTER,
    DEFAULT_RETRY_MAX_ATTEMPTS,
    DEFAULT_RETRY_MAX_DELAY,
    DEFAULT_RETRY_PATTERNS,
    DEFAULT_RETRY_RATE_LIMIT_MAX_ATTEMPTS,
    DEFAULT_REVIEW_AGENT_TIMEOUT,
    DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT,
    DEFAULT_REVIEW_COMPLEXITY_MEDIUM,
    DEFAULT_REVIEW_COMPLEXITY_SIMPLE,
    DEFAULT_REVIEW_DEFAULT_INITIAL_QUALITY_SCORE,
    DEFAULT_REVIEW_FAIL_ADJUSTMENT,
    DEFAULT_REVIEW_FLAG_PENALTY_CAP,
    DEFAULT_REVIEW_FLAG_WEIGHTS,
    DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED,
    DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES,
    DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL,
    DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS,
    DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET,
    DEFAULT_REVIEW_PASS_ADJUSTMENT,
    DEFAULT_REVIEW_PASS_RATING_THRESHOLD,
    DEFAULT_REVIEW_RATING_ADJUSTMENTS,
    DEFAULT_REVIEW_REDERIVATION_THRESHOLD,
    DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD,
    DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD,
    DEFAULT_SLOW_LLM_CALL_THRESHOLD_FALLBACK_MS,
    DEFAULT_SLOW_LLM_CALL_THRESHOLD_MS,
    DEFAULT_STORY0_CAPABILITY_CHECKS,
    DEFAULT_STORY0_PORT_MAPPINGS,
    DEFAULT_STORY0_SERVICE_IMAGES,
    DEFAULT_TEMPLATE_RETAIN_ON_ERROR,
    DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS,
    DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES,
    DEFAULT_VERIFICATION_DISCOVERY_ENABLED,
    DEFAULT_WATCHDOG_ENABLED,
    DEFAULT_WATCHDOG_STALL_TIMEOUT_S,
    DEPRECATED_FIELDS,
    LEGACY_CONFIG_PATH,
    LOCAL_EMULATOR_API_URL,
    PROJECT_LAYER_PREFIX,
    SEMANTIC_CONFIG_ALIASES,
    SESSION_CONFIG_ENV_VAR,
    SESSION_LAYER_PREFIX,
    VALID_QUALITY_POLICY_MODES,
    VALID_TRIGGERS,
)

# ── Handwritten getter functions from _outliers ───────────────────────────
from ._outliers import (
    get_connector_credentials_key_path,
    get_connector_credentials_refresh_margin_s,
    get_connector_credentials_store_path,
    get_google_drive_credential_name,
    get_google_drive_oauth_lifecycle_config,
    get_google_drive_oauth_config,
    get_agent_ignore_patterns,
    get_api_base_url,
    get_api_connection_pool_config,
    get_api_limits,
    get_api_retry_delays,
    get_api_timeouts,
    get_benchmark_dockerhub_username,
    get_benchmark_eval_harness_dir,
    get_benchmark_remediation_config,
    get_benchmark_repo_root,
    get_benchmark_timeout_s,
    get_benchmark_workspace_directory,
    get_cli_cleanup_runtime_log_config,
    get_cli_force_exit_threshold,
    get_cli_interrupt_threshold,
    get_cli_update_check_config,
    get_code_verify_config,
    get_code_verify_preflight_config,
    get_code_verify_timeout_s,
    get_format_before_lint,
    get_decomposition_context_max_chars,
    get_convergence_fresh_fix_enabled,
    get_convergence_identity_overlap_threshold,
    get_convergence_max_template_failure_cycles,
    get_convergence_stale_cycles_for_escalate,
    get_convergence_stale_cycles_for_fresh_fix,
    get_decomposition_failure_threshold,
    get_derivation_auto_decompose_config,
    get_derivation_budget_config,
    get_derivation_exploration_lookback_minutes,
    get_derivation_serialize_max_concurrent,
    get_derivation_serialize_worker_delay_s,
    get_derivation_stall_threshold,
    get_derivation_step1_tier,
    get_derivation_step2_tier,
    get_derivation_step3_tier,
    get_derivation_step_tier,
    get_derivation_step_timeout,
    get_derivation_task_config,
    get_derive_llm_timeout,
    get_display_limit,
    get_enrichment_review_max_concurrent,
    get_enrichment_stage_timeout_s,
    get_escalation_continue_iteration_reset,
    get_escalation_fixer_allowed_routes,
    get_escalation_fixer_config,
    get_escalation_fixer_eligible_reason_codes,
    get_escalation_fixer_enabled,
    get_escalation_fixer_max_attempts_per_episode,
    get_escalation_fixer_timeout_s,
    get_execute_zero_output_retry_max,
    get_fallback_config,
    get_fix_llm_suggestion_timeout,
    get_fix_llm_test_gap_timeout,
    get_gateway_assistant_config,
    get_gateway_config,
    get_gateway_desktop_config,
    get_gateway_onboarding_config,
    get_gateway_session_timeout,
    get_gateway_studio_runtime_config,
    get_gateway_transcription_config,
    get_phase_detection_draft_instruction_threshold,
    get_phase_detection_entry_point_defaults,
    get_phase_detection_enabled,
    get_phase_detection_min_stages_for_full_model,
    get_phase_detection_stable_run_threshold,
    get_phase_detection_validate_min_run_count,
    get_generated_plan_quality_threshold,
    get_governor_config,
    get_hang_confidence,
    get_heartbeat_initial_delay,
    get_heartbeat_interval,
    get_hierarchy_limit,
    get_hybrid_polling_config,
    get_input_budget_on_exceed,
    get_intent_alignment_max_concurrent,
    get_intent_alignment_timeout_s,
    get_intent_chunking_config,
    get_intent_gap_check_timeout_s,
    get_intent_rate_limit_config,
    get_interactive_guard_enabled,
    get_interactive_guard_patterns,
    get_interactive_guard_retry_max,
    get_interactive_guard_rollback_codes,
    get_interactive_guard_rollback_enabled,
    get_limit,
    get_llm_api_timeout,
    get_llm_call_timeout,
    get_llm_timeout,
    get_mcp_servers_config,
    get_execution_limits,
    get_filesystem_preflight_config,
    get_campaign_simulation_config,
    get_llm_timeouts,
    get_local_emulator_config,
    get_nightly_simulation_config,
    get_persona_harness_config,
    get_bulk_template_gen_config,
    get_ollama_endpoint,
    get_ollama_timeouts,
    get_provider_validation_config,
    get_parallel_worker_delay_s,
    get_pipeline_custom_stages,
    get_pipeline_max_iterations,
    get_pipeline_registered_runners,
    get_pipeline_runner_kind_timeout_floors,
    get_pipeline_stage_defaults,
    get_pipeline_stage_timeout,
    get_prompt_enricher_limits,
    get_stage_runner_limits,
    get_priority_order,
    get_provider_tier_defaults,
    get_projects_default_directory,
    get_runtime_platform_config,
    get_simulation_runtime_config,
    get_spike_first_config,
    get_workspace_context_config,
    get_quality_config,
    get_quality_policy_mode,
    get_quality_threshold,
    get_readiness_next_action_priorities,
    get_readiness_first_use_intro_enabled,
    get_readiness_prompt_section_max_tokens,
    get_readiness_prompt_section_priority,
    get_readiness_recap_enabled,
    get_readiness_seed_alignment_min_keyword_matches,
    get_refinement_parallel_max_workers,
    get_refinement_regression_min_delta,
    get_refinement_regression_threshold_multiplier,
    get_refinement_straggler_alert_threshold,
    get_retry_config,
    get_review_blocking_low_priority_strict,
    get_review_complexity_medium,
    get_review_complexity_simple,
    get_review_feedback_config,
    get_review_flag_weights,
    get_review_loop_exit_policy_enabled,
    get_review_loop_exit_policy_max_non_critical_review_cycles,
    get_review_loop_exit_policy_score_plateau_max_delta,
    get_review_loop_exit_policy_score_plateau_min_review_cycles,
    get_review_loop_exit_policy_require_no_new_critical,
    get_review_loop_exit_policy_require_required_checks_pass,
    get_review_loop_exit_policy_require_threshold_met,
    get_review_loop_exit_policy_unverifiable_accept_after_cycles,
    get_review_rating_adjustments,
    get_review_stabilization_cycle_threshold,
    get_revision_plan_shrinkage_block_threshold,
    get_revision_plan_shrinkage_warning_threshold,
    get_role_tier_defaults,
    get_session_token_budget,
    get_slow_llm_call_threshold_ms,
    get_spinner_config,
    get_story0_capability_checks,
    get_story0_llm_schema_timeout,
    get_story0_port_mapping,
    get_story0_service_image,
    get_subprocess_runner_timeouts,
    get_template_retention_settings,
    get_thinking_config,
    get_tier_fallbacks,
    get_timeout,
    get_timeout_config,
    get_user_story_generation_timeout_s,
    get_verification_chain_order,
    get_verification_discovery_settings,
    get_verification_early_exit,
    get_verification_tool_installs,
    get_verification_tools_config,
    get_workflow_derivation_config,
    get_workflow_derivation_llm_config,
    get_prompt_sanitizer_strict_mode,
    is_decomposition_enabled,
    is_local_mode,
)

# ── Registry injection ────────────────────────────────────────────────────
# Injects registry-generated getters (get_derive_*, get_agent_*, etc.) into
# this module's namespace. Uses a module-level reference to load_layered_config
# so that test patches targeting obra.config.loaders._core.load_layered_config
# are honoured at call time.
from ._registry import (
    CONSTRAINT_ENTRIES,
    DOMAIN_ENTRIES,
    HANDLER_ENTRIES,
    INFRA_ENTRIES,
    SECTION_ENTRIES,
    register_getters,
)

_target = sys.modules[__name__]


def _loader():
    return _core.load_layered_config()


register_getters(HANDLER_ENTRIES, _target, _loader)
register_getters(INFRA_ENTRIES, _target, _loader)
register_getters(DOMAIN_ENTRIES, _target, _loader)
register_getters(SECTION_ENTRIES, _target, _loader)
register_getters(CONSTRAINT_ENTRIES, _target, _loader)

_generated_get_derivation_preview_config = get_derivation_preview_config

from ._outliers.derivation import (  # noqa: E402
    get_decomposition_warning_threshold_ratio as _manual_get_decomposition_warning_threshold_ratio,
)
from ._outliers.derivation import (
    get_decomposition_warning_threshold_s as _manual_get_decomposition_warning_threshold_s,
)
from ._outliers.derivation import (
    get_execute_decomposition_stream_idle_timeout_s as _manual_get_execute_decomposition_stream_idle_timeout_s,
)

get_decomposition_warning_threshold_ratio = _manual_get_decomposition_warning_threshold_ratio
get_decomposition_warning_threshold_s = _manual_get_decomposition_warning_threshold_s
get_execute_decomposition_stream_idle_timeout_s = (
    _manual_get_execute_decomposition_stream_idle_timeout_s
)


def get_derivation_preview_config():
    """Return derivation preview limits with the explicit env override applied."""
    import os

    config = dict(_generated_get_derivation_preview_config())
    raw_override = os.environ.get("OBRA_DERIVATION_PREVIEW_LIMIT")
    if raw_override:
        try:
            override = int(raw_override)
        except (TypeError, ValueError) as exc:
            from obra.exceptions import ConfigurationError

            raise ConfigurationError(
                "OBRA_DERIVATION_PREVIEW_LIMIT must be an integer"
            ) from exc
        if override <= 0:
            from obra.exceptions import ConfigurationError

            raise ConfigurationError("OBRA_DERIVATION_PREVIEW_LIMIT must be > 0")
        config["readme_limit"] = override
        config["raw_response_limit"] = override
    return config

del _target, _loader

# ── __all__ ───────────────────────────────────────────────────────────────
__all__ = [name for name in dir() if not name.startswith("_")]
