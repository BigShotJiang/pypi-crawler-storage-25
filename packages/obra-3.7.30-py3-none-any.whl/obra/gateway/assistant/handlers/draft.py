"""Draft workflow handler — create a new workflow from a conversation scaffold."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.adapter_runtime import (
    create_workflow_via_adapter,
    run_derive_quality_gate_via_adapter,
)
from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.workflow_studio.assistant_response_planner import _default_workflow_top_level
from obra.gateway.workflow_studio.starter_catalog import (
    _registered_domain_names,
    normalize_starter_domain_id,
)

_CANONICAL_DOMAIN_ALIASES = frozenset({"business", "obra_business", "software", "obra_software"})


def _log_domain_coercion(
    ctx: HandlerContext | None,
    *,
    raw_domain_id: str,
    coerced_domain_id: str,
    source: str,
) -> None:
    if ctx is None or ctx.log_event is None:
        return
    normalized_raw = raw_domain_id.strip().lower()
    if not normalized_raw or normalized_raw in _CANONICAL_DOMAIN_ALIASES:
        return
    if coerced_domain_id != "business":
        return
    ctx.log_event(
        "asst.domain_id_coerced",
        turn_id=ctx.turn_id,
        raw_domain_id=raw_domain_id,
        coerced_domain_id=coerced_domain_id,
        source=source,
    )


def _resolve_domain_id(
    inputs: dict[str, Any],
    scaffold: dict[str, Any],
    *,
    ctx: HandlerContext | None = None,
    source: str = "draft_workflow",
) -> str:
    """Resolve domain_id, failing loudly for unregistered explicit values."""
    raw = str(inputs.get("domain_id") or scaffold.get("domain_id") or "business").strip()
    normalized_raw = raw.lower()
    supported = sorted(_registered_domain_names() | {"business", "software"})
    if (
        normalized_raw
        and normalized_raw not in _CANONICAL_DOMAIN_ALIASES
        and normalized_raw not in supported
    ):
        raise ValueError(f"unknown domain_id {raw!r}; supported: {supported}")
    domain_id = normalize_starter_domain_id(raw) or "business"
    _log_domain_coercion(ctx, raw_domain_id=raw, coerced_domain_id=domain_id, source=source)
    return domain_id


def propose_draft(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose creating a new workflow from an LLM-generated scaffold definition.

    Top-level workflow fields required by the workflow-derivation validator
    (compile_ready, quality_dimensions, lifecycle_capabilities) are backfilled
    via `_default_workflow_top_level()` before the scaffold reaches the proposal
    record.
    """
    scaffold_definition: dict[str, Any] = inputs.get("scaffold_definition", {})

    stages = scaffold_definition.get("stages", [])
    if not stages:
        return {"outcome": "invalid", "detail": "scaffold_definition must have at least one stage"}

    title = scaffold_definition.get("title", "")
    if not title:
        return {"outcome": "invalid", "detail": "scaffold_definition must have a title"}

    resolved_domain_id = _resolve_domain_id(
        inputs,
        scaffold_definition,
        ctx=ctx,
        source="draft_workflow_proposal",
    )
    top_level = _default_workflow_top_level(
        title=title,
        domain_id=resolved_domain_id,
        description=str(scaffold_definition.get("description", "") or ""),
    )
    resolved_scaffold = {
        **scaffold_definition,
        "domain_id": resolved_domain_id,
        "compile_ready": top_level["compile_ready"],
        "quality_dimensions": top_level["quality_dimensions"],
        "lifecycle_capabilities": top_level["lifecycle_capabilities"],
    }

    connections = sum(len(s.get("depends_on", [])) for s in stages)
    action_inputs = {
        "scaffold_definition": resolved_scaffold,
        "domain_id": resolved_domain_id,
    }

    return build_proposal_record(
        action_id="execute_draft_workflow_from_thread",
        action_type="draft_workflow_from_thread",
        action_inputs=action_inputs,
        preview_type="scaffold",
        outcome="proposal",
        scaffold_definition=resolved_scaffold,
        stage_count=len(stages),
        connection_count=connections,
    )


def create_result_to_action_response(
    result: dict[str, Any],
    *,
    invalid_detail: str,
) -> dict[str, Any]:
    """Convert a canonical create result into an assistant action response."""
    result_outcome = str(result.get("outcome") or "").strip().lower()
    if result_outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "detail": invalid_detail,
        }

    workflow_data = result.get("workflow", {})
    if not isinstance(workflow_data, dict):
        workflow_data = {}
    revision_ref = result.get("resulting_revision_ref", {})
    if not isinstance(revision_ref, dict):
        revision_ref = {}
    return {
        "outcome": "applied",
        "workflow_id": workflow_data.get("workflow_id", ""),
        "resulting_revision_ref": revision_ref,
    }


def execute_draft(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Execute: create a new workflow from the accepted scaffold definition.

    Reads scaffold_definition from inputs; expects backfill applied by
    propose_draft. Re-backfill not required.
    """
    scaffold_definition: dict[str, Any] = inputs.get("scaffold_definition", {})
    domain_id: str = _resolve_domain_id(
        inputs,
        scaffold_definition,
        ctx=ctx,
        source="draft_workflow_execute",
    )

    payload: dict[str, Any] = {
        "title": scaffold_definition.get("title", ""),
        "domain_id": domain_id,
        "workflow_definition": scaffold_definition,
    }
    run_derive_quality_gate_via_adapter(
        ctx,
        action_name="execute_draft_workflow_from_thread",
        inputs=inputs,
        objective=str(
            inputs.get("objective")
            or scaffold_definition.get("description")
            or scaffold_definition.get("title")
            or ""
        ),
    )

    result = create_workflow_via_adapter(
        ctx,
        workflow_id=str(payload.get("workflow_id") or ""),
        candidate=payload,
        action_name="assistant_draft_workflow_create",
        prompt="Validate this accepted Studio draft workflow candidate.",
    )

    return create_result_to_action_response(
        result,
        invalid_detail="draft workflow candidate failed validation",
    )
