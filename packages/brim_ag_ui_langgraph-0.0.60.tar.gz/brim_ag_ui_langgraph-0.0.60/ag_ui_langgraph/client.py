"""AG-UI LangGraph Client — streams LangGraph events as AG-UI protocol events.

Supports: text streaming, tool calls, tool results, custom events, step tracking,
state snapshots, resume/HITL interrupts, thinking/reasoning, subgraph streaming,
and all forwardedProps from the frontend (stream_mode, on_completion, checkpoint_id,
multitask_strategy, stream_subgraphs).

Streaming resilience (added in 0.0.57):

* A periodic keepalive ``CustomEvent`` (name ``agui.keepalive``) fires when the
  LangGraph stream goes quiet.  Consumers (proxies, load balancers, frontend
  idle watchdogs) rely on a regular signal to distinguish "backend is working"
  from "connection is dead".  The keepalive interval is configurable via the
  ``AGUI_LANGGRAPH_HEARTBEAT_SEC`` env var; default 15 seconds.
* A server-side idle timeout fires ``RUN_ERROR`` when no LangGraph chunk
  arrives for a prolonged period, preventing the generator from hanging on a
  wedged upstream connection forever.  Configurable via
  ``AGUI_LANGGRAPH_STREAM_IDLE_TIMEOUT_SEC``; default 180 seconds.

These changes make the Python client the single source of truth for run
liveness — frontends no longer need to infer "still alive" from the absence
of errors.
"""

import asyncio
import json
import logging
import os
import uuid
from typing import AsyncGenerator, Optional, Dict, Any, List

from ag_ui.core import (
    EventType,
    RunAgentInput,
    RunStartedEvent,
    RunFinishedEvent,
    RunErrorEvent,
    RawEvent,
    CustomEvent,
    TextMessageStartEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    ToolCallStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    ToolCallResultEvent,
    StateSnapshotEvent,
    MessagesSnapshotEvent,
    StepStartedEvent,
    StepFinishedEvent,
)

# Thinking events — imported conditionally since older ag-ui-protocol versions
# may not have them.
try:
    from ag_ui.core import (
        ThinkingStartEvent,
        ThinkingTextMessageStartEvent,
        ThinkingTextMessageContentEvent,
        ThinkingTextMessageEndEvent,
        ThinkingEndEvent,
    )
    _HAS_THINKING_EVENTS = True
except ImportError:
    _HAS_THINKING_EVENTS = False

from .utils import langchain_messages_to_agui, resolve_reasoning_content

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _unpack_stream_chunk(chunk) -> tuple[str | None, Any]:
    """Unpack a LangGraph SDK stream chunk into (stream_mode, data)."""
    if isinstance(chunk, (list, tuple)) and len(chunk) >= 2:
        return str(chunk[0]), chunk[1]
    if isinstance(chunk, dict):
        return chunk.get("event"), chunk.get("data")
    return getattr(chunk, "event", None), getattr(chunk, "data", None)


def _extract_text_from_content(content) -> str:
    """Extract plain text from an AIMessageChunk content field."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
        return "".join(parts)
    return ""


class InvalidResumeCommandError(ValueError):
    """Raised when forwardedProps.command.resume has an unexpected shape.

    The shape contract is:
      - resume must be non-None
      - if resume is a dict, it must contain either "value" or
        "interruption_id"
      - any other type (str, list, primitive) is forwarded as-is to the
        langgraph-sdk Command

    Anything else would cause a downstream crash in the SDK, so we reject
    it here with a safe message + code so the caller can emit RUN_ERROR
    instead of propagating a 500.
    """

    code = "INVALID_RESUME_COMMAND"

    def __init__(self, safe_message: str, *, trace_id: str | None = None) -> None:
        super().__init__(safe_message)
        self.safe_message = safe_message
        self.trace_id = trace_id


def _extract_resume_command(input: RunAgentInput) -> dict | None:
    """Extract resume value from forwardedProps.command.resume if present.

    Raises InvalidResumeCommandError if the shape is malformed so callers
    can surface a structured RUN_ERROR instead of crashing the SDK.
    """
    fp = getattr(input, "forwardedProps", None) or getattr(input, "forwarded_props", None)
    if not fp or not isinstance(fp, dict):
        return None
    command = fp.get("command")
    if command is None:
        return None
    if not isinstance(command, dict):
        raise InvalidResumeCommandError(
            "forwardedProps.command must be a dict; refusing to forward malformed resume payload.",
        )
    # Key absent → no resume; key present but None → also no resume.
    if "resume" not in command:
        return None
    resume = command.get("resume")
    if resume is None:
        raise InvalidResumeCommandError(
            "forwardedProps.command.resume is null; a resume value is required.",
        )
    if isinstance(resume, dict):
        if "value" in resume:
            return resume["value"]
        if "interruption_id" in resume:
            return resume
        raise InvalidResumeCommandError(
            "forwardedProps.command.resume must contain 'value' or 'interruption_id'.",
        )
    # Accept scalar/list/string payloads — SDK Command.resume accepts these.
    if isinstance(resume, (str, int, float, bool, list)):
        return resume
    raise InvalidResumeCommandError(
        f"forwardedProps.command.resume has unsupported type {type(resume).__name__}.",
    )


def _extract_forwarded_props(input: RunAgentInput) -> dict:
    """Extract forwardedProps dict from input."""
    fp = getattr(input, "forwardedProps", None) or getattr(input, "forwarded_props", None)
    return fp if isinstance(fp, dict) else {}


def _discard_last_matching_step(open_steps: list[str], step_name: str) -> None:
    """Remove the most recent matching step name, falling back to stack order."""
    for idx in range(len(open_steps) - 1, -1, -1):
        if open_steps[idx] == step_name:
            del open_steps[idx]
            return
    if open_steps:
        open_steps.pop()


def _snapshots_equal(a: Any, b: Any) -> bool:
    """Fast comparison of two state snapshots to skip duplicate emissions."""
    if a is b:
        return True
    if type(a) != type(b):
        return False
    try:
        return json.dumps(a, sort_keys=True, default=str) == json.dumps(b, sort_keys=True, default=str)
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# Streaming resilience — keepalive + idle timeout (added in 0.0.57)
#
# The LangGraph SDK's async stream does not itself emit any signal when the
# run is "still alive but quiet" (e.g. LLM taking a long time, tool call in
# flight, HITL checkpoint awaiting resume).  Without a regular signal, two
# failure modes hit downstream consumers:
#
# 1. Proxies / load balancers idle-kill the HTTP connection after 30-120s.
# 2. Frontend idle watchdogs interpret silence as a hung run and abort.
#
# The helpers below wrap the SDK iterator with a periodic heartbeat tick and
# a hard idle timeout.  Behaviour is purely additive — every LangGraph chunk
# flows through unchanged; heartbeats are interleaved as lightweight
# sentinels that the caller converts into ``agui.keepalive`` CustomEvents.
# ---------------------------------------------------------------------------


def _heartbeat_sec() -> float:
    raw = os.environ.get("AGUI_LANGGRAPH_HEARTBEAT_SEC")
    if raw:
        try:
            val = float(raw)
            if val > 0:
                return val
        except ValueError:
            pass
    return 15.0


def _idle_timeout_sec() -> float:
    raw = os.environ.get("AGUI_LANGGRAPH_STREAM_IDLE_TIMEOUT_SEC")
    if raw:
        try:
            val = float(raw)
            if val > 0:
                return val
        except ValueError:
            pass
    return 180.0


_STREAM_HEARTBEAT = "__heartbeat__"
_STREAM_IDLE_TIMEOUT = "__idle_timeout__"
_STREAM_END = "__end__"


def _extract_interrupts_from_state(state) -> list:
    """Return the pending-interrupt list from a LangGraph thread state.

    LangGraph's ``interrupt()`` pauses a graph and stores pending prompts on
    ``state.tasks[*].interrupts`` (each a ``langgraph.types.Interrupt`` with
    ``.value`` and ``.id``).  The state may be returned either as a TypedDict
    (``client.threads.get_state``) or as a ``StateSnapshot`` (``graph.aget_state``)
    — we support both shapes.
    """
    try:
        tasks = state.get("tasks") if isinstance(state, dict) else getattr(state, "tasks", None)
    except Exception:  # noqa: BLE001
        return []
    if not tasks:
        return []
    interrupts: list = []
    for task in tasks:
        try:
            task_ints = task.get("interrupts") if isinstance(task, dict) else getattr(task, "interrupts", None)
        except Exception:  # noqa: BLE001
            task_ints = None
        if task_ints:
            interrupts.extend(task_ints)
    return interrupts


def _interrupt_to_custom_event_value(interrupt) -> Any:
    """Normalize a LangGraph Interrupt into the JSON-safe shape the frontend expects.

    The frontend's ``detectInterruptFromState`` accepts either a list of
    interrupt objects or the direct ``.value`` payload.  We mirror the
    ``agent.py`` pattern: pass through ``interrupt.value`` as-is when it is
    already a plain dict/list, stringify otherwise.
    """
    value = None
    try:
        value = interrupt["value"] if isinstance(interrupt, dict) else getattr(interrupt, "value", None)
    except Exception:  # noqa: BLE001
        value = None
    if value is None:
        return interrupt if isinstance(interrupt, (dict, list, str, int, float, bool)) else str(interrupt)
    if isinstance(value, (dict, list, str, int, float, bool)):
        return value
    try:
        return json.loads(json.dumps(value, default=str))
    except Exception:  # noqa: BLE001
        return str(value)


async def _iter_with_keepalive(
    stream,
    heartbeat_sec: float,
    idle_timeout_sec: float,
    cancel_flag_getter,
):
    """Iterate a LangGraph stream with heartbeat and idle-timeout markers.

    Yields tuples of ``(marker, payload)``:

    - ``(_STREAM_END, None)`` — iterator exhausted normally.
    - ``(_STREAM_HEARTBEAT, elapsed_since_last_chunk_float)`` — heartbeat tick.
    - ``(_STREAM_IDLE_TIMEOUT, elapsed_since_last_chunk_float)`` — idle limit hit.
    - ``("chunk", chunk)`` — a real LangGraph chunk.

    The underlying iterator is owned by a background task so that timeout
    ticks never cancel in-flight ``__anext__`` calls (which would abort the
    HTTP read and corrupt buffered state in the SDK).  The task is cancelled
    cleanly on generator close.
    """
    loop = asyncio.get_event_loop()
    queue: asyncio.Queue = asyncio.Queue()

    async def _pump():
        try:
            async for chunk in stream:
                await queue.put(("chunk", chunk))
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 — caller converts to RUN_ERROR
            await queue.put(("__error__", exc))
        finally:
            await queue.put((_STREAM_END, None))

    pump_task = asyncio.create_task(_pump(), name="agui-langgraph-stream-pump")

    last_chunk_at = loop.time()

    try:
        while True:
            if cancel_flag_getter():
                # Caller requested cancel — return immediately.  The pump task
                # is cleaned up in the outer finally.
                return

            try:
                item = await asyncio.wait_for(queue.get(), timeout=heartbeat_sec)
            except asyncio.TimeoutError:
                elapsed = loop.time() - last_chunk_at
                if elapsed >= idle_timeout_sec:
                    yield (_STREAM_IDLE_TIMEOUT, elapsed)
                    return
                yield (_STREAM_HEARTBEAT, elapsed)
                continue

            if item[0] == _STREAM_END:
                return
            if item[0] == "__error__":
                raise item[1]

            last_chunk_at = loop.time()
            yield item
    finally:
        if not pump_task.done():
            pump_task.cancel()
            try:
                await pump_task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class AGUILangGraphClient:
    """AG-UI Agent that connects to a LangGraph server via langgraph-sdk.

    Converts LangGraph SDK stream chunks into AG-UI protocol events for
    browser consumption. Supports the full BrimAI streaming feature set.
    """

    def __init__(
        self,
        langgraph_client,
        assistant_id: str,
        name: str = "LangGraphServerAgent",
        description: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        discovery_client=None,
    ):
        self.client = langgraph_client
        # discovery_client is used for runs.list / threads.get_state lookups.
        # Callers should pass the in-process langgraph client here when
        # langgraph_client is an HTTP client pointed at LANGGRAPH_API_URL —
        # HTTP discovery can miss runs when auth headers, URL, or ownership
        # filters differ between the writer (e.g. assignment execute.py using
        # the in-process client) and the reader (AWP using HTTP).  Falls back
        # to langgraph_client if not provided.
        self.discovery_client = discovery_client or langgraph_client
        self.assistant_id = assistant_id
        self.name = name
        self.description = description
        self.config = config or {}
        # Cancel tracking — set by cancel_run(), checked in stream loop
        self._cancel_requested = False
        self._active_thread_id: str | None = None
        self._active_run_id: str | None = None

    def clone(self):
        return AGUILangGraphClient(
            langgraph_client=self.client,
            assistant_id=self.assistant_id,
            name=self.name,
            description=self.description,
            config=self.config,
            discovery_client=self.discovery_client,
        )

    async def cancel_run(self) -> None:
        """Cancel the currently active run.

        Signals the stream loop to stop iteration and calls the LangGraph
        SDK's runs.cancel() to terminate the server-side execution.
        Safe to call from any coroutine — the stream loop checks the flag
        on each chunk.
        """
        self._cancel_requested = True
        if self._active_thread_id and self._active_run_id:
            try:
                await self.client.runs.cancel(self._active_thread_id, self._active_run_id)
                logger.info("Cancelled run %s on thread %s", self._active_run_id, self._active_thread_id)
            except Exception:
                logger.debug("runs.cancel() failed (run may have already completed)", exc_info=True)

    def _dispatch_event(self, event):
        return event

    async def run(self, input: RunAgentInput) -> AsyncGenerator[str, None]:
        thread_id = input.thread_id
        run_id = input.run_id or str(uuid.uuid4())
        fp = _extract_forwarded_props(input)

        # Reset cancel state for this run
        self._cancel_requested = False
        self._active_thread_id = thread_id
        self._active_run_id = run_id

        if not thread_id:
            logger.warning("AGUILangGraphClient requires a thread_id. Starting a fresh thread.")
            thread = await self.client.threads.create()
            thread_id = thread["thread_id"]
            self._active_thread_id = thread_id

        # --- Check for active run to rejoin ---
        # Do NOT filter by status here. The langgraph-sdk's status filter has
        # historically missed runs in transitional states (created but not yet
        # "running", or the SDK's enum does not match the server's). List all
        # runs on the thread and pick the latest non-terminal one — this is
        # the root fix for "assignment Run Now produces a run but runs.list
        # with status='running' returns empty" seen in 0.0.49.
        # "pending" added: join_stream on a pending run returns empty immediately
        # because the run hasn't started executing yet. Excluding it forces the
        # poll loop (below) to wait until the run transitions to "running".
        #
        # "interrupted" is NOT in this set: a LangGraph run paused at
        # ``interrupt()`` reports status="interrupted" but is absolutely not
        # terminal — it is awaiting user input.  Treating it as terminal would
        # prevent rejoining (page refresh loses the HITL card).  The join-only
        # branch below handles paused runs by fetching state and emitting
        # ``on_interrupt`` for any pending HITL prompts.
        _TERMINAL_STATUSES = {"success", "error", "timeout", "pending"}

        def _pick_active(runs_list: list) -> Optional[dict]:
            non_terminal = [
                r for r in (runs_list or [])
                if (r.get("status") if isinstance(r, dict) else None) not in _TERMINAL_STATUSES
            ]
            if not non_terminal:
                return None
            # Prefer the most recently created run
            non_terminal.sort(
                key=lambda r: r.get("created_at") or "",
                reverse=True,
            )
            return non_terminal[0]

        all_runs = await self.discovery_client.runs.list(thread_id=thread_id)
        active_run = _pick_active(all_runs)
        if active_run:
            logger.info(
                "Found active run %s (status=%s) for thread %s",
                active_run.get("run_id"),
                active_run.get("status"),
                thread_id,
            )

        # Race-condition guard: /run-now may have just been triggered and
        # LangGraph may not have registered the run yet. If messages is empty
        # and no run found, poll briefly (up to 3 s) before giving up.
        if not active_run and not input.messages:
            for _attempt in range(6):
                await asyncio.sleep(0.5)
                polled = await self.discovery_client.runs.list(thread_id=thread_id)
                active_run = _pick_active(polled)
                if active_run:
                    logger.info(
                        "Active run %s (status=%s) found after %d poll(s) for thread %s",
                        active_run.get("run_id"),
                        active_run.get("status"),
                        _attempt + 1,
                        thread_id,
                    )
                    break

        yield self._dispatch_event(
            RunStartedEvent(type=EventType.RUN_STARTED, thread_id=thread_id, run_id=run_id)
        )

        # --- Tracking state ---
        active_text_messages: dict[str, str] = {}
        open_text_message_ids: list[str] = []
        open_tool_calls: dict[str, dict] = {}
        open_steps: list[str] = []
        active_step_names: set[str] = set()
        skipped_step_run_ids: set[str] = set()
        _MAX_SKIPPED_RUN_IDS = 256  # cap to prevent unbounded growth
        errored = False
        last_snapshot: Any = None  # for dedup
        thinking_active = False  # native thinking event state

        # --- Extract forwarded stream options ---
        fp_config = fp.get("config") or {}
        fp_configurable = fp_config.get("configurable") or {}
        stream_subgraphs = fp.get("streamSubgraphs", False)
        stream_mode = fp.get("streamMode") or ["messages", "values", "events"]
        on_completion = fp.get("onCompletion") or fp.get("on_completion")
        on_disconnect = fp.get("onDisconnect") or fp.get("on_disconnect") or "continue"
        multitask_strategy = fp.get("multitaskStrategy") or fp.get("multitask_strategy")
        checkpoint_id = fp_configurable.get("checkpoint_id")

        # Merge per-request config with constructor config
        merged_config = {**self.config}
        if fp_configurable:
            merged_configurable = {**merged_config.get("configurable", {}), **fp_configurable}
            merged_config["configurable"] = merged_configurable

        # Build common stream kwargs
        common_stream_kwargs: dict[str, Any] = {
            "config": merged_config,
            "stream_mode": stream_mode,
            "stream_subgraphs": stream_subgraphs,
            "on_disconnect": on_disconnect,
        }
        if on_completion:
            common_stream_kwargs["on_completion"] = on_completion
        if multitask_strategy:
            common_stream_kwargs["multitask_strategy"] = multitask_strategy
        if checkpoint_id:
            common_stream_kwargs["checkpoint_id"] = checkpoint_id

        try:
            if active_run:
                logger.info("Joining active stream for run %s", active_run["run_id"])

                # Dispatch initial state + messages snapshots for late-joining client.
                # Only emit when there is actual content to send — an empty
                # snapshot can clobber runtime state (e.g. workflow_context)
                # that the frontend needs for assignment-specific rendering.
                state = await self.discovery_client.threads.get_state(thread_id)
                if state:
                    values = state.get("values", {}) or {}
                    if values:
                        yield self._dispatch_event(
                            StateSnapshotEvent(type=EventType.STATE_SNAPSHOT, snapshot=values)
                        )
                    messages = values.get("messages", []) or []
                    if messages:
                        yield self._dispatch_event(
                            MessagesSnapshotEvent(
                                type=EventType.MESSAGES_SNAPSHOT,
                                messages=langchain_messages_to_agui(messages),
                            )
                        )

                # INTERRUPT-EMIT (active-run-join): if the run is paused
                # at ``interrupt()`` (status="interrupted" or any state that
                # has tasks[].interrupts populated), surface the HITL prompt
                # BEFORE calling join_stream.  A paused run has no further
                # chunks to yield, so join_stream would block until the
                # idle-timeout fires — meanwhile the FE would sit with no
                # interrupt card shown.  By short-circuiting here, the FE
                # gets the on_interrupt + RUN_FINISHED immediately and can
                # render the card.  The next user action (submitting
                # resume_input) hits the resume branch below.
                pending_interrupts = _extract_interrupts_from_state(state) if state else []
                if pending_interrupts:
                    interrupt_values = [
                        _interrupt_to_custom_event_value(it) for it in pending_interrupts
                    ]
                    logger.info(
                        "active-run-join: run %s is paused at interrupt, emitting on_interrupt (%d pending)",
                        active_run["run_id"],
                        len(interrupt_values),
                    )
                    yield self._dispatch_event(
                        CustomEvent(
                            type=EventType.CUSTOM,
                            name="on_interrupt",
                            value=interrupt_values,
                        )
                    )
                    yield self._dispatch_event(
                        RunFinishedEvent(
                            type=EventType.RUN_FINISHED,
                            thread_id=thread_id,
                            run_id=run_id,
                        )
                    )
                    return

                stream = self.client.runs.join_stream(
                    thread_id=thread_id,
                    run_id=active_run["run_id"],
                    stream_mode=stream_mode,
                )
            else:
                logger.info("Starting new stream for run %s", run_id)

                # Check for resume command (HITL interrupt response).
                # Malformed payloads used to crash langgraph-sdk with a 500;
                # _extract_resume_command now raises InvalidResumeCommandError
                # which we catch in the outer except to emit a structured
                # RUN_ERROR (code=INVALID_RESUME_COMMAND).
                resume_value = _extract_resume_command(input)

                if resume_value is not None:
                    from langgraph_sdk.schema import Command  # noqa: PLC0415

                    logger.info("Resuming thread %s with value: %s", thread_id, resume_value)
                    stream = self.client.runs.stream(
                        thread_id=thread_id,
                        assistant_id=self.assistant_id,
                        input=None,
                        command=Command(resume=resume_value),
                        **common_stream_kwargs,
                    )
                else:
                    # Normal path: send messages as input
                    messages = []
                    if input.messages:
                        for msg in input.messages:
                            msg_dict: dict[str, Any] = {"role": msg.role, "content": msg.content}
                            if hasattr(msg, "id") and msg.id:
                                msg_dict["id"] = msg.id
                            if msg.role == "assistant" and getattr(msg, "tool_calls", None):
                                msg_dict["tool_calls"] = []
                                for tc in msg.tool_calls:
                                    # AG-UI spec: tc.function.arguments is a JSON string.
                                    # LangGraph expects args as a dict.
                                    raw_args = tc.function.arguments
                                    if isinstance(raw_args, str):
                                        try:
                                            parsed_args = json.loads(raw_args)
                                        except (json.JSONDecodeError, TypeError):
                                            parsed_args = {}
                                    elif isinstance(raw_args, dict):
                                        parsed_args = raw_args
                                    else:
                                        parsed_args = {}
                                    msg_dict["tool_calls"].append({
                                        "name": tc.function.name,
                                        "args": parsed_args,
                                        "id": tc.id,
                                    })
                            elif msg.role == "tool":
                                msg_dict["tool_call_id"] = getattr(msg, "tool_call_id", "")
                            messages.append(msg_dict)

                    if not messages:
                        # Empty messages + no active run = join-only intent with
                        # nothing to join yet.  Emit the current thread state
                        # (StateSnapshot + MessagesSnapshot) so the chat panel
                        # can at least render whatever history exists, then
                        # RunFinished to close the stream cleanly.  Returning
                        # immediately with only RunFinished (as the prior code
                        # did) leaves the chat blank when the caller is a late
                        # join that missed the actual run — e.g. assignment
                        # Run Now where the run executes asynchronously on a
                        # separate worker and completes before the browser's
                        # AWP connection arrives.
                        logger.info(
                            "No messages and no active run on thread %s — "
                            "emitting state snapshot + RunFinished (join-only)",
                            thread_id,
                        )
                        try:
                            state = await self.discovery_client.threads.get_state(thread_id)
                            if state:
                                values = state.get("values", {}) or {}
                                thread_messages = values.get("messages", []) or []
                                # Only emit snapshots when we actually have
                                # content.  Emitting an empty StateSnapshot or
                                # MessagesSnapshot replaces the chat runtime's
                                # existing state with nothing — causing already-
                                # rendered messages (synthesis virtual AI, in-
                                # flight stream buffers, hydrated history) to
                                # disappear.  For assignment_executor threads
                                # in particular the graph writes to
                                # state.synthesis (not state.messages) during
                                # the run, so an empty messages[] snapshot
                                # here would wipe the UI mid-run.
                                if values and thread_messages:
                                    yield self._dispatch_event(
                                        StateSnapshotEvent(
                                            type=EventType.STATE_SNAPSHOT,
                                            snapshot=values,
                                        )
                                    )
                                    yield self._dispatch_event(
                                        MessagesSnapshotEvent(
                                            type=EventType.MESSAGES_SNAPSHOT,
                                            messages=langchain_messages_to_agui(thread_messages),
                                        )
                                    )
                                elif values:
                                    # State exists but has no messages yet —
                                    # still deliver the non-message state (e.g.
                                    # synthesis, plan, artefacts) so the
                                    # workspace can render it.  Skip the
                                    # messages snapshot to preserve the UI.
                                    yield self._dispatch_event(
                                        StateSnapshotEvent(
                                            type=EventType.STATE_SNAPSHOT,
                                            snapshot=values,
                                        )
                                    )
                            # INTERRUPT-EMIT (join-only): if the thread is
                            # paused at an ``interrupt()``, replay the
                            # pending interrupt so the frontend can render
                            # the HITL card.  Without this, late-join
                            # sessions (e.g. page refresh while the graph
                            # is awaiting user input) saw nothing — the
                            # interrupt was buried inside state.tasks and
                            # never surfaced as an event.
                            pending_interrupts = _extract_interrupts_from_state(state)
                            if pending_interrupts:
                                interrupt_values = [
                                    _interrupt_to_custom_event_value(it)
                                    for it in pending_interrupts
                                ]
                                logger.info(
                                    "join-only: emitting on_interrupt (%d pending) on thread %s",
                                    len(interrupt_values),
                                    thread_id,
                                )
                                yield self._dispatch_event(
                                    CustomEvent(
                                        type=EventType.CUSTOM,
                                        name="on_interrupt",
                                        value=interrupt_values,
                                    )
                                )
                        except Exception:
                            logger.debug(
                                "join-only state fetch failed for thread %s",
                                thread_id,
                                exc_info=True,
                            )
                        yield self._dispatch_event(
                            RunFinishedEvent(
                                type=EventType.RUN_FINISHED,
                                thread_id=thread_id,
                                run_id=run_id,
                            )
                        )
                        return

                    payload = {"messages": messages}
                    stream = self.client.runs.stream(
                        thread_id=thread_id,
                        assistant_id=self.assistant_id,
                        input=payload,
                        **common_stream_kwargs,
                    )

            # --- Process stream ---
            #
            # Wrap the LangGraph SDK iterator so we get periodic heartbeats
            # and a hard idle-timeout.  Heartbeats fire as ``agui.keepalive``
            # CustomEvents (configurable via AGUI_LANGGRAPH_HEARTBEAT_SEC);
            # idle timeouts fire as RUN_ERROR (configurable via
            # AGUI_LANGGRAPH_STREAM_IDLE_TIMEOUT_SEC).  All real chunks flow
            # through unchanged.  See module docstring for rationale.
            _heartbeat_every = _heartbeat_sec()
            _idle_limit = _idle_timeout_sec()
            async for _marker, _payload in _iter_with_keepalive(
                stream,
                heartbeat_sec=_heartbeat_every,
                idle_timeout_sec=_idle_limit,
                cancel_flag_getter=lambda: self._cancel_requested,
            ):
                if self._cancel_requested:
                    logger.info("Cancel requested — breaking stream loop")
                    break

                if _marker == _STREAM_HEARTBEAT:
                    # The LangGraph stream is quiet but the run is still
                    # alive.  Emit a keepalive CustomEvent so proxies/LBs
                    # don't idle-kill the HTTP connection and frontend idle
                    # watchdogs keep their timer reset.
                    yield self._dispatch_event(
                        CustomEvent(
                            type=EventType.CUSTOM,
                            name="agui.keepalive",
                            value={
                                "interval_sec": _heartbeat_every,
                                "quiet_for_sec": round(float(_payload or 0), 2),
                                "thread_id": thread_id,
                                "run_id": run_id,
                            },
                        )
                    )
                    continue

                if _marker == _STREAM_IDLE_TIMEOUT:
                    # No LangGraph chunks for `_idle_limit` seconds — the
                    # upstream stream is almost certainly wedged (Redis
                    # pub/sub stall, half-closed TCP, stalled checkpointer).
                    # Surface this as a terminal error so the frontend can
                    # unblock instead of hanging indefinitely.
                    logger.warning(
                        "Stream idle for %.1fs (limit=%.0fs) on thread=%s run=%s — aborting",
                        float(_payload or 0),
                        _idle_limit,
                        thread_id,
                        run_id,
                    )
                    errored = True
                    yield self._dispatch_event(
                        RunErrorEvent(
                            type=EventType.RUN_ERROR,
                            message=(
                                f"LangGraph stream idle for {float(_payload or 0):.0f}s "
                                f"(limit {_idle_limit:.0f}s). Upstream may have stalled."
                            ),
                            code="STREAM_IDLE_TIMEOUT",
                        )
                    )
                    break

                # Real chunk — original processing logic unchanged.
                chunk = _payload
                stream_mode_key, data = _unpack_stream_chunk(chunk)

                yield self._dispatch_event(RawEvent(type=EventType.RAW, event=chunk))

                # Update active run_id from server metadata if available
                if isinstance(data, dict):
                    server_run_id = (data.get("metadata") or {}).get("run_id")
                    if server_run_id:
                        self._active_run_id = server_run_id

                # --- Error ---
                if stream_mode_key == "error":
                    msg = data.get("message", "Unknown Error") if isinstance(data, dict) else "Unknown Error"
                    errored = True
                    yield self._dispatch_event(RunErrorEvent(type=EventType.RUN_ERROR, message=str(msg)))
                    break

                # --- Messages mode (skip — we use on_chat_model_stream) ---
                elif stream_mode_key in ("messages", "messages/partial"):
                    pass

                # --- Events mode ---
                elif stream_mode_key == "events" or (
                    isinstance(stream_mode_key, str) and stream_mode_key.startswith("events")
                ):
                    if not isinstance(data, dict):
                        continue

                    event_name = data.get("event", "")
                    node_name = data.get("name", "")
                    tags = data.get("tags") or []
                    event_data = data.get("data", {})

                    # 1. Custom events
                    if event_name == "on_custom_event":
                        yield self._dispatch_event(
                            CustomEvent(type=EventType.CUSTOM, name=node_name, value=event_data)
                        )
                        continue

                    # 2. LLM token streaming
                    if event_name == "on_chat_model_stream":
                        chunk_data = event_data.get("chunk") or {}
                        msg_id = (
                            chunk_data.get("id") if isinstance(chunk_data, dict)
                            else getattr(chunk_data, "id", None)
                        )
                        if not msg_id:
                            msg_id = str(uuid.uuid4())

                        msg_type = (
                            chunk_data.get("type", "") if isinstance(chunk_data, dict)
                            else getattr(chunk_data, "type", "")
                        )
                        if msg_type not in ("AIMessageChunk", "ai"):
                            continue

                        # --- Thinking/reasoning detection ---
                        if _HAS_THINKING_EVENTS:
                            # resolve_reasoning_content expects an object with .content attr;
                            # wrap dict as SimpleNamespace if needed.
                            try:
                                from types import SimpleNamespace  # noqa: PLC0415
                                _rc_input = chunk_data if hasattr(chunk_data, "content") else SimpleNamespace(**chunk_data) if isinstance(chunk_data, dict) else chunk_data
                                reasoning = resolve_reasoning_content(_rc_input)
                            except Exception:
                                reasoning = None
                            if reasoning and reasoning.get("text"):
                                if not thinking_active:
                                    thinking_active = True
                                    yield self._dispatch_event(
                                        ThinkingStartEvent(type=EventType.THINKING_START)
                                    )
                                    yield self._dispatch_event(
                                        ThinkingTextMessageStartEvent(type=EventType.THINKING_TEXT_MESSAGE_START)
                                    )
                                yield self._dispatch_event(
                                    ThinkingTextMessageContentEvent(
                                        type=EventType.THINKING_TEXT_MESSAGE_CONTENT,
                                        delta=reasoning["text"],
                                    )
                                )
                                continue  # thinking content — don't emit as regular text

                        # Close thinking if we get non-thinking content
                        if thinking_active and _HAS_THINKING_EVENTS:
                            thinking_active = False
                            yield self._dispatch_event(
                                ThinkingTextMessageEndEvent(type=EventType.THINKING_TEXT_MESSAGE_END)
                            )
                            yield self._dispatch_event(
                                ThinkingEndEvent(type=EventType.THINKING_END)
                            )

                        # --- Regular text content ---
                        content = (
                            chunk_data.get("content", []) if isinstance(chunk_data, dict)
                            else getattr(chunk_data, "content", [])
                        )
                        text = _extract_text_from_content(content)
                        if text:
                            if msg_id not in active_text_messages:
                                active_text_messages[msg_id] = "active"
                                open_text_message_ids.append(msg_id)
                                yield self._dispatch_event(
                                    TextMessageStartEvent(
                                        type=EventType.TEXT_MESSAGE_START,
                                        message_id=msg_id,
                                        role="assistant",
                                        raw_event=chunk_data,
                                    )
                                )
                            yield self._dispatch_event(
                                TextMessageContentEvent(
                                    type=EventType.TEXT_MESSAGE_CONTENT,
                                    message_id=msg_id,
                                    delta=text,
                                    raw_event=chunk_data,
                                )
                            )

                        # --- Tool call streaming ---
                        # Tool call chunks arrive incrementally. The first chunk
                        # may have only args (no id/name). We buffer args until
                        # we have an id+name to emit START, then flush buffered args.
                        tc_chunks = (
                            chunk_data.get("tool_call_chunks") or []
                            if isinstance(chunk_data, dict)
                            else getattr(chunk_data, "tool_call_chunks", None) or []
                        )
                        for tc_chunk in tc_chunks:
                            call_id = tc_chunk.get("id", "") if isinstance(tc_chunk, dict) else getattr(tc_chunk, "id", "") or ""
                            tc_name = tc_chunk.get("name", "") if isinstance(tc_chunk, dict) else getattr(tc_chunk, "name", "") or ""
                            args_delta = tc_chunk.get("args", "") if isinstance(tc_chunk, dict) else getattr(tc_chunk, "args", "") or ""
                            index = tc_chunk.get("index", 0) if isinstance(tc_chunk, dict) else getattr(tc_chunk, "index", 0)

                            tc_key = f"tc_{msg_id}_{index}"
                            if tc_key not in open_tool_calls:
                                real_id = call_id if call_id else tc_key
                                open_tool_calls[tc_key] = {
                                    "msg_id": msg_id, "name": tc_name, "call_id": real_id,
                                    "started": bool(tc_name),  # START needs a name
                                    "buffered_args": "",
                                }
                                if tc_name:
                                    yield self._dispatch_event(
                                        ToolCallStartEvent(
                                            type=EventType.TOOL_CALL_START,
                                            toolCallId=real_id,
                                            toolCallName=tc_name,
                                            parentMessageId=msg_id,
                                        )
                                    )
                                if args_delta:
                                    if tc_name:
                                        # START already emitted, send ARGS immediately
                                        yield self._dispatch_event(
                                            ToolCallArgsEvent(
                                                type=EventType.TOOL_CALL_ARGS,
                                                toolCallId=real_id,
                                                delta=args_delta,
                                            )
                                        )
                                    else:
                                        # Buffer args until we have a name for START
                                        open_tool_calls[tc_key]["buffered_args"] += args_delta
                            else:
                                tc_info = open_tool_calls[tc_key]
                                # Late-arriving name: emit START now + flush buffered args
                                if tc_name and not tc_info.get("started"):
                                    tc_info["name"] = tc_name
                                    tc_info["started"] = True
                                    if call_id:
                                        tc_info["call_id"] = call_id
                                    yield self._dispatch_event(
                                        ToolCallStartEvent(
                                            type=EventType.TOOL_CALL_START,
                                            toolCallId=tc_info["call_id"],
                                            toolCallName=tc_name,
                                            parentMessageId=tc_info["msg_id"],
                                        )
                                    )
                                    # Flush any buffered args
                                    if tc_info.get("buffered_args"):
                                        yield self._dispatch_event(
                                            ToolCallArgsEvent(
                                                type=EventType.TOOL_CALL_ARGS,
                                                toolCallId=tc_info["call_id"],
                                                delta=tc_info["buffered_args"],
                                            )
                                        )
                                        tc_info["buffered_args"] = ""
                                # Update call_id if it arrives late
                                if call_id and tc_info["call_id"] != call_id:
                                    tc_info["call_id"] = call_id

                            # Emit ARGS for already-started tool calls
                            if args_delta and tc_key in open_tool_calls and open_tool_calls[tc_key].get("started"):
                                yield self._dispatch_event(
                                    ToolCallArgsEvent(
                                        type=EventType.TOOL_CALL_ARGS,
                                        toolCallId=open_tool_calls[tc_key]["call_id"],
                                        delta=args_delta,
                                    )
                                )
                        continue

                    # 3. on_tool_start: close open tool calls
                    if event_name == "on_tool_start":
                        for tc_info in list(open_tool_calls.values()):
                            yield self._dispatch_event(
                                ToolCallEndEvent(type=EventType.TOOL_CALL_END, toolCallId=tc_info["call_id"])
                            )
                        open_tool_calls.clear()
                        continue

                    # 3b. on_tool_end: emit TOOL_CALL_RESULT
                    if event_name == "on_tool_end":
                        output = event_data.get("output")
                        if output is not None:
                            if isinstance(output, dict):
                                tc_id = output.get("tool_call_id", "")
                                raw_content = output.get("content", "")
                                update_msgs = (output.get("update") or {}).get("messages") or []
                                if update_msgs and isinstance(update_msgs, list):
                                    for tool_msg in update_msgs:
                                        if isinstance(tool_msg, dict) and tool_msg.get("type") == "tool":
                                            tc_id = tc_id or tool_msg.get("tool_call_id", "")
                                            raw_content = tool_msg.get("content", "")
                                            break
                            else:
                                tc_id = getattr(output, "tool_call_id", "")
                                raw_content = getattr(output, "content", "")

                            content_str = raw_content if isinstance(raw_content, str) else str(raw_content)
                            if tc_id:
                                yield self._dispatch_event(
                                    ToolCallResultEvent(
                                        type=EventType.TOOL_CALL_RESULT,
                                        toolCallId=tc_id,
                                        content=content_str,
                                        messageId=str(uuid.uuid4()),
                                        role="tool",
                                    )
                                )
                        continue

                    # 4. Step events (graph:step:N tagged)
                    is_graph_step = any(isinstance(t, str) and t.startswith("graph:step:") for t in tags)
                    if not is_graph_step:
                        continue

                    event_run_id = data.get("run_id", "")
                    if event_name == "on_chain_start":
                        step_name = node_name or "step"
                        if step_name in active_step_names:
                            if event_run_id:
                                skipped_step_run_ids.add(event_run_id)
                                # Cap to prevent unbounded growth
                                if len(skipped_step_run_ids) > _MAX_SKIPPED_RUN_IDS:
                                    skipped_step_run_ids.clear()
                        else:
                            active_step_names.add(step_name)
                            open_steps.append(step_name)
                            yield self._dispatch_event(
                                StepStartedEvent(type=EventType.STEP_STARTED, step_name=step_name)
                            )
                    elif event_name == "on_chain_end":
                        if event_run_id and event_run_id in skipped_step_run_ids:
                            skipped_step_run_ids.discard(event_run_id)
                        else:
                            # Late-join guard: if we never observed the matching
                            # on_chain_start for this step (e.g. the client
                            # joined mid-run and the start event lived before
                            # the replay window), suppress STEP_FINISHED. The
                            # AG-UI spec requires STEP_FINISHED to pair with a
                            # prior STEP_STARTED, so emitting here would trip
                            # the client-side validator with
                            # "Cannot send 'STEP_FINISHED' for step <name> that
                            # was not started" and abort the run.
                            candidate_name = node_name or "step"
                            if not open_steps and candidate_name not in active_step_names:
                                logger.debug(
                                    "Suppressing STEP_FINISHED for unstarted step %r "
                                    "(likely late-join replay gap)",
                                    candidate_name,
                                )
                            else:
                                step_name = open_steps.pop() if open_steps else candidate_name
                                active_step_names.discard(step_name)
                                yield self._dispatch_event(
                                    StepFinishedEvent(type=EventType.STEP_FINISHED, step_name=step_name)
                                )

                # --- Values mode → STATE_SNAPSHOT (with dedup) ---
                elif stream_mode_key == "values" or (
                    isinstance(stream_mode_key, str) and stream_mode_key.startswith("values")
                ):
                    # Only emit when the payload is a non-empty dict.
                    # LangGraph occasionally yields empty {} or non-record
                    # chunks in values-mode (init/checkpoint markers) which,
                    # forwarded verbatim, are noise for the frontend adapter
                    # and can trigger downstream state-snapshot logic that
                    # assumes a meaningful payload shape.
                    if (
                        isinstance(data, dict)
                        and data
                        and not _snapshots_equal(data, last_snapshot)
                    ):
                        last_snapshot = data
                        yield self._dispatch_event(
                            StateSnapshotEvent(type=EventType.STATE_SNAPSHOT, snapshot=data)
                        )

                # --- Custom mode → CustomEvent ---
                # LangGraph StreamWriter (`writer(payload)` under stream_mode="custom")
                # produces ("custom", payload) chunks. The substrate emits its
                # tool_invocation_started / tool_invocation envelopes via this
                # path so they survive contexts where `config` is unavailable
                # (recovery, idempotency replays, projector crash-handling) —
                # which adispatch_custom_event cannot.
                #
                # Subgraph-namespaced chunks: when `streamSubgraphs=True` is
                # set (as in Brim's chat path), LangGraph SDK exposes custom
                # events from inside subgraphs as `"custom|<ns>"` (e.g.
                # `"custom|worker:abc"`). Match the bare `"custom"` AND any
                # `"custom|…"` prefix so substrate emissions from subgraph
                # workers also reach AG-UI consumers. The `|` delimiter avoids
                # accidentally classifying a future `custom_v2`-style mode as
                # substrate payload.
                #
                # Routing convention: payload["type"] becomes the AG-UI
                # CustomEvent.name; the FE adapter routes by name.  Non-dict
                # payloads, or dicts missing a string `type`, are dropped at
                # debug log level (caller bug — substrate emitters always
                # include `type`; we don't synthesise one because that would
                # silently hide miswiring).
                elif stream_mode_key == "custom" or (
                    isinstance(stream_mode_key, str)
                    and stream_mode_key.startswith("custom|")
                ):
                    if isinstance(data, dict):
                        custom_event_name = data.get("type")
                        if isinstance(custom_event_name, str) and custom_event_name:
                            yield self._dispatch_event(
                                CustomEvent(
                                    type=EventType.CUSTOM,
                                    name=custom_event_name,
                                    value=data,
                                )
                            )
                        else:
                            logger.debug(
                                "[AGUILangGraphClient] custom-mode payload missing 'type'; dropping. keys=%s",
                                list(data.keys())[:8],
                            )
                    else:
                        logger.debug(
                            "[AGUILangGraphClient] custom-mode payload not a dict; dropping. type=%s",
                            type(data).__name__,
                        )

        except InvalidResumeCommandError as resume_err:
            logger.warning(
                "Rejecting malformed resume command: %s (trace=%s)",
                resume_err.safe_message,
                resume_err.trace_id,
            )
            errored = True
            yield self._dispatch_event(
                RunErrorEvent(
                    type=EventType.RUN_ERROR,
                    message=resume_err.safe_message,
                    code=InvalidResumeCommandError.code,
                )
            )
        except Exception as e:
            logger.error("Stream error: %s", e, exc_info=True)
            errored = True
            yield self._dispatch_event(
                RunErrorEvent(type=EventType.RUN_ERROR, message=f"Agent exception: {str(e)}")
            )

        # --- Cleanup ---

        # Close thinking if still active
        if thinking_active and _HAS_THINKING_EVENTS:
            yield self._dispatch_event(ThinkingTextMessageEndEvent(type=EventType.THINKING_TEXT_MESSAGE_END))
            yield self._dispatch_event(ThinkingEndEvent(type=EventType.THINKING_END))

        # Close open tool calls. Entries with started=True had a
        # TOOL_CALL_START emitted and need a matching TOOL_CALL_END.
        # Entries with started=False (tool_call_chunks arrived with args
        # but the name never came through) must NOT emit END (that would
        # violate the protocol by closing a call that never opened).
        # We log a warning with the abandoned count and drop them so
        # buffered args don't leak across runs.
        abandoned_tool_calls = 0
        for tc_info in list(open_tool_calls.values()):
            if tc_info.get("started"):
                yield self._dispatch_event(
                    ToolCallEndEvent(type=EventType.TOOL_CALL_END, toolCallId=tc_info["call_id"])
                )
            else:
                abandoned_tool_calls += 1
        if abandoned_tool_calls > 0:
            logger.warning(
                "[AGUILangGraphClient] Abandoned %d tool_call_chunks without name at run end",
                abandoned_tool_calls,
            )
        # Always clear to prevent buffered args from leaking across runs,
        # whether this run ends with RUN_FINISHED or RUN_ERROR.
        open_tool_calls.clear()

        # Close open text messages
        for message_id in open_text_message_ids:
            yield self._dispatch_event(
                TextMessageEndEvent(type=EventType.TEXT_MESSAGE_END, message_id=message_id)
            )

        # Close dangling steps
        if open_steps:
            logger.warning("Closing %d dangling step(s) before RUN_FINISHED: %s", len(open_steps), open_steps)
            while open_steps:
                yield self._dispatch_event(
                    StepFinishedEvent(type=EventType.STEP_FINISHED, step_name=open_steps.pop())
                )

        # Only emit RUN_FINISHED if no error occurred
        if not errored:
            try:
                state = await self.discovery_client.threads.get_state(thread_id)
                if state:
                    yield self._dispatch_event(
                        StateSnapshotEvent(type=EventType.STATE_SNAPSHOT, snapshot=state.get("values", {}))
                    )
                    msgs = state.get("values", {}).get("messages", [])
                    if msgs:
                        yield self._dispatch_event(
                            MessagesSnapshotEvent(
                                type=EventType.MESSAGES_SNAPSHOT,
                                messages=langchain_messages_to_agui(msgs),
                            )
                        )

                    # INTERRUPT-EMIT: if the graph paused at an interrupt(),
                    # surface it to the frontend as an on_interrupt CustomEvent.
                    # Previously ``client.py`` never emitted this event even
                    # though ``agent.py`` does (agent.py:350-358) — leaving
                    # the frontend with no structured signal that a HITL
                    # prompt is live.  detectInterruptFromState on the FE
                    # accepts this shape (list of interrupt objects) via the
                    # handleCustomEvent 'on_interrupt' branch.
                    pending_interrupts = _extract_interrupts_from_state(state)
                    if pending_interrupts:
                        interrupt_values = [
                            _interrupt_to_custom_event_value(it) for it in pending_interrupts
                        ]
                        logger.info(
                            "Emitting on_interrupt: %d pending interrupt(s) on thread=%s run=%s",
                            len(interrupt_values),
                            thread_id,
                            run_id,
                        )
                        yield self._dispatch_event(
                            CustomEvent(
                                type=EventType.CUSTOM,
                                name="on_interrupt",
                                value=interrupt_values,
                            )
                        )
            except Exception:
                logger.debug("Post-run state fetch failed (non-blocking)")

            yield self._dispatch_event(
                RunFinishedEvent(type=EventType.RUN_FINISHED, thread_id=thread_id, run_id=run_id)
            )
