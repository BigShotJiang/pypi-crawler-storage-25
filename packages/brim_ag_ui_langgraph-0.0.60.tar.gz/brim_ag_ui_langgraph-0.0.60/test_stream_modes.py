import asyncio
from langgraph_sdk import get_client

async def main():
    try:
        client = get_client()
        async for chunk in client.runs.stream(
            thread_id=None,
            assistant_id="engine",
            input={"messages": [{"role": "user", "content": "Tell me a short 3 sentence story."}]},
            stream_mode=["events"]
        ):
            if getattr(chunk, "event", None) == "events":
                data = getattr(chunk, "data", {})
                if data.get("event") == "on_chat_model_stream":
                    print("ON_CHAT_MODEL_STREAM", data["data"]["chunk"])
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    asyncio.run(main())
