"""Tests for the streaming resilience helpers added in 0.0.57.

Covers:
- ``_heartbeat_sec`` / ``_idle_timeout_sec`` env var parsing.
- ``_iter_with_keepalive`` emits heartbeat sentinels when the underlying
  iterator stalls and terminates with an idle-timeout sentinel after the
  configured limit.
- Pump task is cleaned up on caller cancel.
"""

import asyncio
import os
import unittest

from ag_ui_langgraph.client import (
    _STREAM_END,
    _STREAM_HEARTBEAT,
    _STREAM_IDLE_TIMEOUT,
    _heartbeat_sec,
    _idle_timeout_sec,
    _iter_with_keepalive,
)


class TestEnvConfig(unittest.TestCase):
    def setUp(self):
        self._saved_hb = os.environ.pop("AGUI_LANGGRAPH_HEARTBEAT_SEC", None)
        self._saved_idle = os.environ.pop("AGUI_LANGGRAPH_STREAM_IDLE_TIMEOUT_SEC", None)

    def tearDown(self):
        for key, val in [
            ("AGUI_LANGGRAPH_HEARTBEAT_SEC", self._saved_hb),
            ("AGUI_LANGGRAPH_STREAM_IDLE_TIMEOUT_SEC", self._saved_idle),
        ]:
            if val is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = val

    def test_heartbeat_default(self):
        self.assertEqual(_heartbeat_sec(), 15.0)

    def test_heartbeat_env_override(self):
        os.environ["AGUI_LANGGRAPH_HEARTBEAT_SEC"] = "3.5"
        self.assertEqual(_heartbeat_sec(), 3.5)

    def test_heartbeat_rejects_invalid(self):
        os.environ["AGUI_LANGGRAPH_HEARTBEAT_SEC"] = "not-a-number"
        self.assertEqual(_heartbeat_sec(), 15.0)

    def test_heartbeat_rejects_non_positive(self):
        os.environ["AGUI_LANGGRAPH_HEARTBEAT_SEC"] = "0"
        self.assertEqual(_heartbeat_sec(), 15.0)
        os.environ["AGUI_LANGGRAPH_HEARTBEAT_SEC"] = "-5"
        self.assertEqual(_heartbeat_sec(), 15.0)

    def test_idle_timeout_default(self):
        self.assertEqual(_idle_timeout_sec(), 180.0)

    def test_idle_timeout_env_override(self):
        os.environ["AGUI_LANGGRAPH_STREAM_IDLE_TIMEOUT_SEC"] = "60"
        self.assertEqual(_idle_timeout_sec(), 60.0)


# ---------------------------------------------------------------------------
# Iterator behavior
# ---------------------------------------------------------------------------


class _FakeAsyncIter:
    """Async iterator that yields items after configurable delays."""

    def __init__(self, schedule):
        # schedule: list of (delay_sec, item) — item=None means "never yield"
        self._schedule = list(schedule)
        self._idx = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._idx >= len(self._schedule):
            raise StopAsyncIteration
        delay, item = self._schedule[self._idx]
        self._idx += 1
        if item is None:
            # Simulate a permanent stall
            await asyncio.sleep(3600)
            raise StopAsyncIteration
        await asyncio.sleep(delay)
        return item


class TestIterWithKeepalive(unittest.IsolatedAsyncioTestCase):
    async def test_passes_chunks_through(self):
        stream = _FakeAsyncIter([(0.0, "a"), (0.0, "b"), (0.0, "c")])
        results = []
        async for marker, payload in _iter_with_keepalive(
            stream,
            heartbeat_sec=1.0,
            idle_timeout_sec=10.0,
            cancel_flag_getter=lambda: False,
        ):
            results.append((marker, payload))
        self.assertEqual(
            [r for r in results if r[0] == "chunk"],
            [("chunk", "a"), ("chunk", "b"), ("chunk", "c")],
        )
        # Iterator should have ended via the StopAsyncIteration path, which
        # the helper surfaces as natural generator completion (no final sentinel).

    async def test_emits_heartbeat_on_stall(self):
        # One chunk, then stall. heartbeat=0.05s, idle=1.0s.
        # We should receive at least one heartbeat sentinel before giving up.
        stream = _FakeAsyncIter([(0.0, "first"), (0.0, None)])
        heartbeats = 0
        chunks = 0
        idle_timeouts = 0
        async for marker, _ in _iter_with_keepalive(
            stream,
            heartbeat_sec=0.05,
            idle_timeout_sec=0.3,
            cancel_flag_getter=lambda: False,
        ):
            if marker == "chunk":
                chunks += 1
            elif marker == _STREAM_HEARTBEAT:
                heartbeats += 1
            elif marker == _STREAM_IDLE_TIMEOUT:
                idle_timeouts += 1
        self.assertEqual(chunks, 1, "Should deliver the one real chunk")
        self.assertGreaterEqual(heartbeats, 1, "Should emit at least one heartbeat during stall")
        self.assertEqual(idle_timeouts, 1, "Should hit idle timeout exactly once")

    async def test_respects_cancel_flag(self):
        # Stream would stall forever; cancel flag flips mid-wait.
        stream = _FakeAsyncIter([(0.0, None)])
        cancel_flag = {"v": False}
        results = []

        async def _flip_flag():
            await asyncio.sleep(0.2)
            cancel_flag["v"] = True

        flipper = asyncio.create_task(_flip_flag())
        async for marker, _ in _iter_with_keepalive(
            stream,
            heartbeat_sec=0.05,
            idle_timeout_sec=10.0,
            cancel_flag_getter=lambda: cancel_flag["v"],
        ):
            results.append(marker)
        await flipper
        # Should exit cleanly via cancel path — no idle-timeout sentinel.
        self.assertNotIn(_STREAM_IDLE_TIMEOUT, results)


if __name__ == "__main__":
    unittest.main()
