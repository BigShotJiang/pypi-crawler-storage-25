"""Tests for interrupt emission added in 0.0.58.

The client previously never emitted ``on_interrupt`` CustomEvents, leaving
frontends with no structured signal that a LangGraph ``interrupt()`` was
pending.  These tests exercise the new helpers:

- ``_extract_interrupts_from_state`` — robust extraction across TypedDict
  and ``StateSnapshot`` shapes.
- ``_interrupt_to_custom_event_value`` — safe normalization for JSON wire.
"""

import unittest
from dataclasses import dataclass
from typing import Any

from ag_ui_langgraph.client import (
    _extract_interrupts_from_state,
    _interrupt_to_custom_event_value,
)


@dataclass
class _FakeInterrupt:
    value: Any
    id: str = "int-1"


@dataclass
class _FakeTask:
    interrupts: list


class TestExtractInterrupts(unittest.TestCase):
    def test_typeddict_state_with_tasks(self):
        state = {
            "values": {},
            "tasks": [
                {"interrupts": [{"value": {"question": "approve?"}, "id": "int-1"}]},
                {"interrupts": []},
            ],
        }
        found = _extract_interrupts_from_state(state)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["id"], "int-1")

    def test_statesnapshot_like_object(self):
        state = type(
            "StateSnapshot",
            (),
            {
                "tasks": [
                    _FakeTask(interrupts=[_FakeInterrupt(value={"q": "yes?"})]),
                    _FakeTask(interrupts=[_FakeInterrupt(value={"q": "no?"}, id="int-2")]),
                ],
            },
        )()
        found = _extract_interrupts_from_state(state)
        self.assertEqual(len(found), 2)

    def test_empty_state(self):
        self.assertEqual(_extract_interrupts_from_state({}), [])
        self.assertEqual(_extract_interrupts_from_state({"tasks": []}), [])
        self.assertEqual(
            _extract_interrupts_from_state({"tasks": [{"interrupts": []}]}), []
        )

    def test_none_and_garbage(self):
        self.assertEqual(_extract_interrupts_from_state(None), [])
        self.assertEqual(_extract_interrupts_from_state("not a state"), [])

    def test_task_without_interrupts_key(self):
        state = {"tasks": [{"name": "node_a"}]}
        self.assertEqual(_extract_interrupts_from_state(state), [])


class TestInterruptValueNormalization(unittest.TestCase):
    def test_dict_interrupt_value_passes_through(self):
        ev = {"value": {"question": "approve?", "options": ["yes", "no"]}}
        out = _interrupt_to_custom_event_value(ev)
        self.assertEqual(out, {"question": "approve?", "options": ["yes", "no"]})

    def test_list_interrupt_value(self):
        ev = _FakeInterrupt(value=[{"a": 1}, {"b": 2}])
        out = _interrupt_to_custom_event_value(ev)
        self.assertEqual(out, [{"a": 1}, {"b": 2}])

    def test_string_value(self):
        ev = _FakeInterrupt(value="hello")
        self.assertEqual(_interrupt_to_custom_event_value(ev), "hello")

    def test_non_json_safe_value_falls_back_to_str(self):
        class _Unserializable:
            def __repr__(self):
                return "<unserializable>"

        ev = _FakeInterrupt(value=_Unserializable())
        out = _interrupt_to_custom_event_value(ev)
        # Either a str repr or a JSON-compatible coercion — both are fine,
        # the contract is "never raise".
        self.assertIsInstance(out, (str, dict, list))

    def test_no_value_field(self):
        # Raw scalar interrupt (unusual but shouldn't crash)
        out = _interrupt_to_custom_event_value({"id": "x"})
        # falls back to the dict itself
        self.assertEqual(out, {"id": "x"})


if __name__ == "__main__":
    unittest.main()
