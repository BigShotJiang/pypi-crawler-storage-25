"""Tests for the ``custom`` stream-mode branch of AGUILangGraphClient.run().

LangGraph ``StreamWriter`` (``writer(payload)`` under ``stream_mode="custom"``)
produces ``("custom", payload)`` chunks. The dispatcher converts dict
payloads into AG-UI ``CustomEvent`` messages, using ``payload["type"]`` as
the routing key (the FE adapter routes by ``CustomEvent.name``).

Behaviours under test:
- dict payload with string ``type`` → CustomEvent emitted with name=type, value=payload
- non-dict payload → silently dropped (no CustomEvent)
- dict payload missing ``type`` → silently dropped (no CustomEvent)
- dict payload with non-string ``type`` → silently dropped (no CustomEvent)
- payload's other fields (workspace_id, schema_version, …) survive verbatim
"""

import unittest
import uuid
from unittest.mock import AsyncMock, MagicMock

from ag_ui.core import EventType, RunAgentInput, UserMessage
from ag_ui_langgraph.client import AGUILangGraphClient
from langgraph_sdk.schema import StreamPart


# ---------------------------------------------------------------------------
# Fixtures (mirror test_agui_langgraph_client.py helpers)
# ---------------------------------------------------------------------------


def _make_client(stream_chunks=None):
    mock_sdk = MagicMock()
    mock_sdk.runs.list = AsyncMock(side_effect=[[], []])

    async def _mock_stream(*args, **kwargs):
        for chunk in stream_chunks or []:
            yield chunk

    mock_sdk.runs.stream = _mock_stream
    mock_sdk.runs.join_stream = MagicMock()

    return AGUILangGraphClient(langgraph_client=mock_sdk, assistant_id="engine")


def _make_input():
    return RunAgentInput(
        thread_id="thread-123",
        run_id=str(uuid.uuid4()),
        state={},
        messages=[UserMessage(id="m1", role="user", content="Hi")],
        tools=[],
        context=[],
        forwarded_props={},
    )


async def _collect_events(client, input_data):
    events = []
    async for event in client.run(input_data):
        events.append(event)
    return events


def _custom_events(events):
    """Return only events whose type is CUSTOM."""
    return [e for e in events if getattr(e, "type", None) == EventType.CUSTOM]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestCustomStreamMode(unittest.IsolatedAsyncioTestCase):
    async def test_dict_with_string_type_emits_custom_event(self):
        payload = {
            "type": "tool_invocation_started",
            "schema_version": "1",
            "event_type": "tool_invocation_started",
            "invocation_id": "wk-step-1-search-0",
            "workspace_id": "ws-test",
            "tool_name": "search_knowledge",
            "started_at_ms": 1730000000000,
        }
        client = _make_client(stream_chunks=[["custom", payload, None]])
        events = await _collect_events(client, _make_input())
        customs = _custom_events(events)

        self.assertEqual(len(customs), 1, f"expected one CUSTOM event, got types={[e.type for e in events]}")
        self.assertEqual(customs[0].name, "tool_invocation_started")
        # Value is the full payload, including unknown fields the substrate may add.
        self.assertEqual(customs[0].value, payload)

    async def test_terminal_envelope_routes_under_tool_invocation_name(self):
        payload = {
            "type": "tool_invocation",
            "schema_version": "1",
            "event_type": "tool_invocation",
            "invocation": {
                "invocation_id": "wk-step-1-search-0",
                "status": "success",
                "tool_name": "search_knowledge",
            },
            "projected_steprail_row": {"id": "wk-step-1-search-0", "status": "success"},
        }
        client = _make_client(stream_chunks=[["custom", payload, None]])
        events = await _collect_events(client, _make_input())
        customs = _custom_events(events)

        self.assertEqual(len(customs), 1)
        self.assertEqual(customs[0].name, "tool_invocation")
        self.assertEqual(customs[0].value["invocation"]["status"], "success")

    async def test_non_dict_payload_dropped(self):
        client = _make_client(
            stream_chunks=[
                ["custom", "not a dict", None],
                ["custom", 42, None],
                ["custom", ["a", "list"], None],
                ["custom", None, None],
            ]
        )
        events = await _collect_events(client, _make_input())
        self.assertEqual(_custom_events(events), [])

    async def test_dict_missing_type_dropped(self):
        client = _make_client(
            stream_chunks=[
                ["custom", {"schema_version": "1", "invocation_id": "x"}, None],
            ]
        )
        events = await _collect_events(client, _make_input())
        self.assertEqual(_custom_events(events), [])

    async def test_dict_non_string_type_dropped(self):
        client = _make_client(
            stream_chunks=[
                ["custom", {"type": 42, "schema_version": "1"}, None],
                ["custom", {"type": None, "schema_version": "1"}, None],
                ["custom", {"type": "", "schema_version": "1"}, None],  # empty string
            ]
        )
        events = await _collect_events(client, _make_input())
        self.assertEqual(_custom_events(events), [])

    async def test_unknown_top_level_fields_survive_verbatim(self):
        # The substrate (eng-spec STREAM-SUB-V1 §9.8) carries workspace_id and
        # other multi-tenancy / tracing fields at the top level. The dispatcher
        # must pass them through untouched so the FE can enforce the workspace
        # guard. Verifies the package does not filter to a known field set.
        payload = {
            "type": "tool_invocation_started",
            "schema_version": "1",
            "event_type": "tool_invocation_started",
            "invocation_id": "inv-1",
            "workspace_id": "ws-A",
            "trace_id": "0af7651916cd43dd8448eb211c80319c",
            "run_id": "run-1",
            "thread_id": "thread-1",
            "step_id": "step-1",
            "item_id": None,
            "origin": "worker",
            "tool_name": "search_knowledge",
            "requested_tool_name": "search_knowledge",
            "tool_input": {"query": "q1"},
            "input_description": "Search for q1",
            "started_at_ms": 1000,
            "future_field_brim_did_not_invent_yet": "preserved",
        }
        client = _make_client(stream_chunks=[["custom", payload, None]])
        events = await _collect_events(client, _make_input())
        customs = _custom_events(events)

        self.assertEqual(len(customs), 1)
        self.assertEqual(customs[0].value, payload)
        self.assertEqual(
            customs[0].value["future_field_brim_did_not_invent_yet"],
            "preserved",
            "Dispatcher must not filter unknown top-level fields",
        )

    async def test_subgraph_namespaced_custom_event_emitted(self):
        # LangGraph SDK surfaces subgraph custom events as "custom|<ns>"
        # (e.g. "custom|worker:abc") when streamSubgraphs=True is set —
        # which is the default for BrimAI's chat path. Substrate emitters
        # in worker / runtime nodes run inside subgraphs, so this case
        # is the dominant one in practice.
        #
        # Pin via StreamPart explicitly per Ian's review feedback (PR #17).
        payload = {
            "type": "tool_invocation_started",
            "schema_version": "1",
            "event_type": "tool_invocation_started",
            "invocation_id": "inv-1",
            "workspace_id": "ws-test",
            "tool_name": "search_knowledge",
        }
        client = _make_client(
            stream_chunks=[StreamPart(event="custom|worker:abc", data=payload)]
        )
        events = await _collect_events(client, _make_input())
        customs = _custom_events(events)

        self.assertEqual(len(customs), 1, f"expected one CUSTOM event, got types={[e.type for e in events]}")
        self.assertEqual(customs[0].name, "tool_invocation_started")
        self.assertEqual(customs[0].value, payload)

    async def test_namespaced_dispatch_does_not_match_lookalikes(self):
        # The delimiter (`custom|`) prevents accidentally classifying
        # future modes (e.g. `custom_v2`, `customs`) as substrate payload.
        client = _make_client(
            stream_chunks=[
                StreamPart(event="custom_v2", data={"type": "tool_invocation_started"}),
                StreamPart(event="customs", data={"type": "tool_invocation_started"}),
            ]
        )
        events = await _collect_events(client, _make_input())
        self.assertEqual(_custom_events(events), [])

    async def test_multiple_custom_chunks_emit_in_order(self):
        # Substrate emits a started + terminal pair per invocation; verify
        # ordering is preserved across the dispatcher.
        started = {
            "type": "tool_invocation_started",
            "schema_version": "1",
            "event_type": "tool_invocation_started",
            "invocation_id": "inv-1",
        }
        terminal = {
            "type": "tool_invocation",
            "schema_version": "1",
            "event_type": "tool_invocation",
            "invocation": {"invocation_id": "inv-1", "status": "success"},
        }
        client = _make_client(
            stream_chunks=[
                ["custom", started, None],
                ["custom", terminal, None],
            ]
        )
        events = await _collect_events(client, _make_input())
        customs = _custom_events(events)

        self.assertEqual([c.name for c in customs], ["tool_invocation_started", "tool_invocation"])


if __name__ == "__main__":
    unittest.main()
