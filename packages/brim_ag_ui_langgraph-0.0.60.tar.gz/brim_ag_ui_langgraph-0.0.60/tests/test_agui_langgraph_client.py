"""Tests for AGUILangGraphClient.

Validates that stream chunks from the LangGraph SDK (which arrive as
[stream_mode, data, ...] tuples) are correctly converted to AG-UI protocol
events (TEXT_MESSAGE_START/CONTENT/END, STEP_STARTED/FINISHED, STATE_SNAPSHOT).
"""

import unittest
from unittest.mock import AsyncMock, MagicMock

import uuid
from ag_ui.core import RunAgentInput, UserMessage, EventType
from langchain_core.messages import HumanMessage
from ag_ui_langgraph.client import (
    AGUILangGraphClient,
    _extract_text_from_content,
    _unpack_stream_chunk,
)


# ---------------------------------------------------------------------------
# Helper: realistic AIMessageChunk as returned by LangGraph SDK messages mode
# ---------------------------------------------------------------------------

def _ai_chunk(text: str, msg_id: str = "lc_run--msg-001", tool_call_chunks=None):
    """Build a minimal AIMessageChunk dict."""
    content = [{"type": "text", "text": text, "index": 0}] if text else []
    return {
        "type": "AIMessageChunk",
        "id": msg_id,
        "content": content,
        "additional_kwargs": {},
        "response_metadata": {"model_provider": "bedrock_converse"},
        "tool_calls": [],
        "invalid_tool_calls": [],
        "usage_metadata": None,
        "tool_call_chunks": tool_call_chunks or [],
        "chunk_position": None,
    }


def _metadata_dict():
    return {"run_id": "run-001", "thread_id": "thread-123"}


# ---------------------------------------------------------------------------
# Unit tests: helpers
# ---------------------------------------------------------------------------

class TestUnpackStreamChunk(unittest.TestCase):

    def test_list_tuple_format(self):
        chunk = ["messages", [_ai_chunk("Hi"), _metadata_dict()], None]
        mode, data = _unpack_stream_chunk(chunk)
        self.assertEqual(mode, "messages")
        self.assertIsInstance(data, list)

    def test_tuple_format(self):
        chunk = ("values", {"messages": []}, None)
        mode, data = _unpack_stream_chunk(chunk)
        self.assertEqual(mode, "values")
        self.assertEqual(data, {"messages": []})

    def test_dict_format_legacy(self):
        chunk = {"event": "messages/partial", "data": []}
        mode, data = _unpack_stream_chunk(chunk)
        self.assertEqual(mode, "messages/partial")
        self.assertEqual(data, [])

    def test_object_format_legacy(self):
        chunk = MagicMock()
        chunk.event = "values"
        chunk.data = {"foo": "bar"}
        mode, data = _unpack_stream_chunk(chunk)
        self.assertEqual(mode, "values")
        self.assertEqual(data, {"foo": "bar"})

    def test_metadata_mode(self):
        chunk = ["metadata", {"run_id": "run-001"}, None]
        mode, data = _unpack_stream_chunk(chunk)
        self.assertEqual(mode, "metadata")
        self.assertEqual(data, {"run_id": "run-001"})


class TestExtractTextFromContent(unittest.TestCase):

    def test_string_content(self):
        self.assertEqual(_extract_text_from_content("hello"), "hello")

    def test_block_list(self):
        content = [{"type": "text", "text": "I'm"}, {"type": "other", "text": "ignored"}]
        self.assertEqual(_extract_text_from_content(content), "I'm")

    def test_multiple_text_blocks(self):
        content = [{"type": "text", "text": "foo"}, {"type": "text", "text": "bar"}]
        self.assertEqual(_extract_text_from_content(content), "foobar")

    def test_empty_list(self):
        self.assertEqual(_extract_text_from_content([]), "")

    def test_none(self):
        self.assertEqual(_extract_text_from_content(None), "")

    def test_empty_string(self):
        self.assertEqual(_extract_text_from_content(""), "")


# ---------------------------------------------------------------------------
# Integration tests: AGUILangGraphClient.run() event emission
# ---------------------------------------------------------------------------

def _make_client(active_runs=None, pending_runs=None, stream_chunks=None):
    """Build a client with mocked LangGraph SDK."""
    mock_sdk = MagicMock()
    mock_sdk.runs.list = AsyncMock(side_effect=[
        active_runs or [],
        pending_runs or [],
    ])

    async def _mock_stream(*args, **kwargs):
        for chunk in (stream_chunks or []):
            yield chunk

    mock_sdk.runs.stream = _mock_stream
    mock_sdk.runs.join_stream = MagicMock()

    return AGUILangGraphClient(langgraph_client=mock_sdk, assistant_id="engine")


def _make_input(thread_id="thread-123", run_id="run-456", messages=None):
    return RunAgentInput(
        thread_id=thread_id,
        run_id=run_id,
        state={},
        messages=messages or [UserMessage(id="m1", role="user", content="Hi")],
        tools=[],
        context=[],
        forwarded_props={},
    )


async def _collect_events(client, input_data):
    events = []
    async for event in client.run(input_data):
        events.append(event)
    return events


def _ai_chunk(text: str, msg_id: str = None):
    msg_id = msg_id or str(uuid.uuid4())
    return [
        "events",
        {
            "event": "on_chat_model_stream",
            "data": {
                "chunk": {
                    "id": msg_id,
                    "type": "AIMessageChunk",
                    "content": text
                }
            }
        }
    ]


class TestTextStreaming(unittest.IsolatedAsyncioTestCase):

    async def test_text_chunks_emit_start_content_end(self):
        """events chunks → TEXT_MESSAGE_START + CONTENT tokens + END."""
        msg_id = "lc_run--msg-001"
        stream_chunks = [
            _ai_chunk("I'm", msg_id),
            _ai_chunk("I'm here", msg_id),
            _ai_chunk("I'm here to help.", msg_id),
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())
        types = [e.type for e in events]

        self.assertIn("RUN_STARTED", types)
        self.assertIn("TEXT_MESSAGE_START", types)
        self.assertIn("TEXT_MESSAGE_CONTENT", types)
        self.assertIn("TEXT_MESSAGE_END", types)
        self.assertIn("RUN_FINISHED", types)

        # START before CONTENT before END
        start_i = types.index("TEXT_MESSAGE_START")
        end_i = types.index("TEXT_MESSAGE_END")
        content_indices = [i for i, t in enumerate(types) if t == "TEXT_MESSAGE_CONTENT"]
        self.assertTrue(all(start_i < i < end_i for i in content_indices))

    async def test_text_content_delta_values(self):
        """TEXT_MESSAGE_CONTENT events carry the correct delta text. 
        SDK streams send true deltas in events mode."""
        msg_id = "lc_run--msg-001"
        stream_chunks = [
            _ai_chunk("Hello", msg_id),
            _ai_chunk(" world", msg_id),
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        content_events = [e for e in events if e.type == EventType.TEXT_MESSAGE_CONTENT]
        self.assertEqual(len(content_events), 2)
        self.assertEqual(content_events[0].delta, "Hello")
        self.assertEqual(content_events[1].delta, " world")

    async def test_start_emitted_only_once_per_message(self):
        """TEXT_MESSAGE_START fires exactly once even for many chunks from same message."""
        msg_id = "lc_run--msg-001"
        stream_chunks = [
            _ai_chunk(f"token{i}", msg_id)
            for i in range(5)
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        starts = [e for e in events if e.type == EventType.TEXT_MESSAGE_START]
        self.assertEqual(len(starts), 1)
        self.assertEqual(starts[0].message_id, msg_id)

    async def test_empty_chunks_skipped(self):
        """AIMessageChunk with empty content (e.g. first/last empty chunk) is skipped."""
        msg_id = "lc_run--msg-001"
        stream_chunks = [
            _ai_chunk("", msg_id),  # empty
            _ai_chunk("Hi", msg_id),
            _ai_chunk("", msg_id),  # empty
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        content_events = [e for e in events if e.type == EventType.TEXT_MESSAGE_CONTENT]
        self.assertEqual(len(content_events), 1)
        self.assertEqual(content_events[0].delta, "Hi")

    async def test_non_ai_chunk_types_skipped(self):
        """Non-AIMessageChunk messages are ignored."""
        chunk = _ai_chunk("Hello", "msg-001")
        chunk[1]["data"]["chunk"]["type"] = "HumanMessage"
        stream_chunks = [
            chunk,
            _ai_chunk("OK", "msg-002"),
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        content_events = [e for e in events if e.type == EventType.TEXT_MESSAGE_CONTENT]
        self.assertEqual(len(content_events), 1)
        self.assertEqual(content_events[0].delta, "OK")


class TestStepEvents(unittest.IsolatedAsyncioTestCase):

    def _chain_start(self, name, step_n):
        return ["events", {
            "event": "on_chain_start",
            "name": name,
            "tags": [f"graph:step:{step_n}"],
            "run_id": "run-001",
            "data": {},
        }, None]

    def _chain_end(self, name, step_n):
        return ["events", {
            "event": "on_chain_end",
            "name": name,
            "tags": [f"graph:step:{step_n}"],
            "run_id": "run-001",
            "data": {},
        }, None]

    async def test_graph_steps_emit_started_finished(self):
        stream_chunks = [
            self._chain_start("intake", 1),
            self._chain_end("intake", 1),
            self._chain_start("execute", 2),
            self._chain_end("execute", 2),
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        types = [e.type for e in events]
        self.assertEqual(types.count("STEP_STARTED"), 2)
        self.assertEqual(types.count("STEP_FINISHED"), 2)

    async def test_step_names_match_node_names(self):
        stream_chunks = [
            self._chain_start("intake", 1),
            self._chain_end("intake", 1),
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        started = [e for e in events if e.type == "STEP_STARTED"]
        finished = [e for e in events if e.type == "STEP_FINISHED"]
        self.assertEqual(started[0].step_name, "intake")
        self.assertEqual(finished[0].step_name, "intake")

    async def test_non_graph_step_events_ignored(self):
        """on_chain_start without graph:step:N tag should not emit step events."""
        stream_chunks = [
            ["events", {
                "event": "on_chain_start",
                "name": "engine",
                "tags": [],  # no graph:step tag
                "run_id": "run-001",
                "data": {},
            }, None],
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        types = [e.type for e in events]
        self.assertNotIn("STEP_STARTED", types)
        self.assertNotIn("STEP_FINISHED", types)


class TestStateSnapshot(unittest.IsolatedAsyncioTestCase):

    async def test_values_mode_emits_state_snapshot(self):
        snapshot = {"messages": [], "handoff_history": []}
        stream_chunks = [
            ["values", snapshot, None],
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        snapshots = [e for e in events if e.type == "STATE_SNAPSHOT"]
        self.assertEqual(len(snapshots), 1)
        self.assertEqual(snapshots[0].snapshot, snapshot)


class TestRawEventForwarding(unittest.IsolatedAsyncioTestCase):

    async def test_all_chunks_forwarded_as_raw(self):
        """Every chunk from the stream must produce a RAW event."""
        stream_chunks = [
            ["metadata", {"run_id": "run-001"}, None],
            ["values", {"messages": []}, None],
            ["messages", [_ai_chunk("Hi"), _metadata_dict()], None],
            ["events", {"event": "on_chain_start", "name": "intake",
                        "tags": ["graph:step:1"], "data": {}}, None],
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        raw_count = sum(1 for e in events if e.type == "RAW")
        self.assertEqual(raw_count, len(stream_chunks))


class TestJoinActiveRun(unittest.IsolatedAsyncioTestCase):

    async def test_joins_existing_run_instead_of_starting(self):
        mock_sdk = MagicMock()
        mock_sdk.runs.list = AsyncMock(side_effect=[
            [{"run_id": "active-run-789", "status": "running"}],
            [],
        ])
        mock_sdk.threads.get_state = AsyncMock(return_value={
            "values": {
                "messages": [HumanMessage(content="hello", id="m1")],
                "some_state": "value"
            }
        })

        join_called_with = {}

        async def _mock_join_stream(thread_id, run_id, **kwargs):
            join_called_with["thread_id"] = thread_id
            join_called_with["run_id"] = run_id
            yield ["values", {"messages": []}, None]

        mock_sdk.runs.join_stream = _mock_join_stream
        mock_sdk.runs.stream = MagicMock()

        client = AGUILangGraphClient(langgraph_client=mock_sdk, assistant_id="engine")
        events = await _collect_events(client, _make_input())

        # stream() must NOT be called when there's an active run
        mock_sdk.runs.stream.assert_not_called()
        self.assertEqual(join_called_with["run_id"], "active-run-789")

        types = [e.type for e in events]
        self.assertIn("STATE_SNAPSHOT", types)
        self.assertIn("MESSAGES_SNAPSHOT", types)


class TestRunLifecycle(unittest.IsolatedAsyncioTestCase):

    async def test_always_starts_and_finishes(self):
        client = _make_client(stream_chunks=[])
        events = await _collect_events(client, _make_input())
        types = [e.type for e in events]
        self.assertEqual(types[0], "RUN_STARTED")
        self.assertEqual(types[-1], "RUN_FINISHED")

    async def test_text_message_end_emitted_even_with_partial_stream(self):
        """If stream ends mid-message, TEXT_MESSAGE_END is still emitted."""
        msg_id = "lc_run--msg-001"
        stream_chunks = [
            _ai_chunk("partial...", msg_id),
            # stream ends here without a closing signal
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        types = [e.type for e in events]
        self.assertIn("TEXT_MESSAGE_END", types)
        # END must come after CONTENT
        end_i = types.index("TEXT_MESSAGE_END")
        content_i = types.index("TEXT_MESSAGE_CONTENT")
        self.assertGreater(end_i, content_i)


class TestCustomEventForwarding(unittest.IsolatedAsyncioTestCase):

    async def test_on_custom_event_forwarded(self):
        """on_custom_event → CUSTOM event with correct name and value."""
        stream_chunks = [
            ["events", {
                "event": "on_custom_event",
                "name": "narrative_update",
                "data": {"headline": "Processing request", "detail": "Analyzing..."},
                "tags": [],
            }, None],
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        custom = [e for e in events if e.type == "CUSTOM"]
        self.assertEqual(len(custom), 1)
        self.assertEqual(custom[0].name, "narrative_update")
        self.assertEqual(custom[0].value["headline"], "Processing request")

    async def test_multiple_custom_events(self):
        """Multiple custom events are all forwarded."""
        stream_chunks = [
            ["events", {"event": "on_custom_event", "name": "narrative_update",
                        "data": {"headline": "Step 1"}, "tags": []}, None],
            ["events", {"event": "on_custom_event", "name": "cot.update",
                        "data": {"thinking": "..."}, "tags": []}, None],
            ["events", {"event": "on_custom_event", "name": "on_interrupt",
                        "data": [{"id": "int-1", "value": {}}], "tags": []}, None],
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        custom = [e for e in events if e.type == "CUSTOM"]
        self.assertEqual(len(custom), 3)
        names = [e.name for e in custom]
        self.assertEqual(names, ["narrative_update", "cot.update", "on_interrupt"])


class TestToolCallResult(unittest.IsolatedAsyncioTestCase):

    async def test_on_tool_end_emits_result(self):
        """on_tool_end with output → TOOL_CALL_RESULT."""
        stream_chunks = [
            ["events", {
                "event": "on_tool_end",
                "name": "GMAIL_FETCH_EMAILS",
                "data": {
                    "output": {
                        "tool_call_id": "tc-001",
                        "content": "Found 3 emails",
                        "type": "tool",
                    },
                },
                "tags": [],
            }, None],
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        results = [e for e in events if e.type == "TOOL_CALL_RESULT"]
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].tool_call_id, "tc-001")
        self.assertEqual(results[0].content, "Found 3 emails")
        self.assertEqual(results[0].role, "tool")

    async def test_on_tool_end_nested_messages(self):
        """on_tool_end with update.messages format → TOOL_CALL_RESULT."""
        stream_chunks = [
            ["events", {
                "event": "on_tool_end",
                "name": "search",
                "data": {
                    "output": {
                        "update": {
                            "messages": [
                                {"type": "tool", "tool_call_id": "tc-002", "content": "Search results"}
                            ]
                        }
                    },
                },
                "tags": [],
            }, None],
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        results = [e for e in events if e.type == "TOOL_CALL_RESULT"]
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].tool_call_id, "tc-002")


class TestErrorSafety(unittest.IsolatedAsyncioTestCase):

    async def test_error_chunk_emits_run_error(self):
        """error stream mode → RUN_ERROR + no RUN_FINISHED."""
        stream_chunks = [
            ["error", {"message": "Server crashed"}, None],
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        types = [e.type for e in events]
        self.assertIn("RUN_ERROR", types)
        self.assertNotIn("RUN_FINISHED", types)

    async def test_exception_emits_run_error(self):
        """Exception during streaming → RUN_ERROR + no RUN_FINISHED."""
        mock_sdk = MagicMock()
        mock_sdk.runs.list = AsyncMock(side_effect=[[], []])

        async def _exploding_stream(*args, **kwargs):
            yield ["values", {"messages": []}, None]
            raise RuntimeError("Connection lost")

        mock_sdk.runs.stream = _exploding_stream

        client = AGUILangGraphClient(langgraph_client=mock_sdk, assistant_id="engine")
        events = await _collect_events(client, _make_input())

        types = [e.type for e in events]
        self.assertIn("RUN_ERROR", types)
        self.assertNotIn("RUN_FINISHED", types)

        error_event = [e for e in events if e.type == "RUN_ERROR"][0]
        self.assertIn("Connection lost", error_event.message)


class TestDanglingStepCleanup(unittest.IsolatedAsyncioTestCase):

    def _chain_start(self, name, step_n):
        return ["events", {
            "event": "on_chain_start",
            "name": name,
            "tags": [f"graph:step:{step_n}"],
            "run_id": f"run-{step_n}",
            "data": {},
        }, None]

    async def test_dangling_steps_closed_before_run_finished(self):
        """Steps still open at end-of-stream get STEP_FINISHED before RUN_FINISHED."""
        stream_chunks = [
            self._chain_start("human", 1),
            # stream ends without on_chain_end for human
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        types = [e.type for e in events]
        self.assertIn("STEP_STARTED", types)
        self.assertIn("STEP_FINISHED", types)
        # STEP_FINISHED must come before RUN_FINISHED
        sf_i = types.index("STEP_FINISHED")
        rf_i = types.index("RUN_FINISHED")
        self.assertLess(sf_i, rf_i)


class TestResumeCommand(unittest.IsolatedAsyncioTestCase):

    async def test_resume_uses_command_not_input(self):
        """When forwardedProps.command.resume is present, Command(resume=value) is used."""
        mock_sdk = MagicMock()
        mock_sdk.runs.list = AsyncMock(side_effect=[[], []])
        mock_sdk.threads.get_state = AsyncMock(return_value={
            "values": {"messages": [HumanMessage(content="hi", id="m1")]}
        })

        stream_call_kwargs = {}

        async def _capture_stream(*args, **kwargs):
            stream_call_kwargs.update(kwargs)
            yield ["values", {"messages": []}, None]

        mock_sdk.runs.stream = _capture_stream

        client = AGUILangGraphClient(langgraph_client=mock_sdk, assistant_id="engine")
        input_data = RunAgentInput(
            thread_id="thread-123",
            run_id="run-456",
            state={},
            messages=[UserMessage(id="m1", role="user", content="approve")],
            tools=[],
            context=[],
            forwardedProps={
                "command": {
                    "resume": {
                        "interrupt": "int-001",
                        "value": {"decisions": [{"type": "approve"}]},
                    }
                }
            },
        )

        events = await _collect_events(client, input_data)

        # Verify Command(resume=...) was passed, not input
        self.assertIsNone(stream_call_kwargs.get("input"))
        command = stream_call_kwargs.get("command")
        self.assertIsNotNone(command)
        self.assertEqual(command["resume"], {"decisions": [{"type": "approve"}]})

    async def test_no_resume_uses_input(self):
        """Without forwardedProps.command.resume, normal input is used."""
        stream_call_kwargs = {}

        mock_sdk = MagicMock()
        mock_sdk.runs.list = AsyncMock(side_effect=[[], []])

        async def _capture_stream(*args, **kwargs):
            stream_call_kwargs.update(kwargs)
            yield ["values", {"messages": []}, None]

        mock_sdk.runs.stream = _capture_stream

        client = AGUILangGraphClient(langgraph_client=mock_sdk, assistant_id="engine")
        events = await _collect_events(client, _make_input())

        # input should be set, command should not
        self.assertIsNotNone(stream_call_kwargs.get("input"))
        self.assertIsNone(stream_call_kwargs.get("command"))


class TestResumeCommandValidation(unittest.IsolatedAsyncioTestCase):
    """Malformed forwardedProps.command.resume must produce a structured
    RUN_ERROR (code=INVALID_RESUME_COMMAND) instead of crashing the SDK.
    """

    def _input_with_command(self, command):
        return RunAgentInput(
            thread_id="thread-123",
            run_id="run-456",
            state={},
            messages=[UserMessage(id="m1", role="user", content="approve")],
            tools=[],
            context=[],
            forwardedProps={"command": command},
        )

    async def test_null_resume_rejected(self):
        """command.resume=None must be rejected with INVALID_RESUME_COMMAND."""
        client = _make_client(stream_chunks=[])
        events = await _collect_events(client, self._input_with_command({"resume": None}))

        run_errors = [e for e in events if e.type == "RUN_ERROR"]
        self.assertEqual(len(run_errors), 1)
        self.assertEqual(run_errors[0].code, "INVALID_RESUME_COMMAND")
        self.assertIn("null", run_errors[0].message.lower())
        # RUN_FINISHED must NOT be emitted after RUN_ERROR
        types = [e.type for e in events]
        self.assertNotIn("RUN_FINISHED", types)

    async def test_resume_dict_missing_value_and_interruption_id(self):
        """Dict resume without 'value' or 'interruption_id' is rejected."""
        client = _make_client(stream_chunks=[])
        events = await _collect_events(
            client,
            self._input_with_command({"resume": {"unexpected": "shape"}}),
        )

        run_errors = [e for e in events if e.type == "RUN_ERROR"]
        self.assertEqual(len(run_errors), 1)
        self.assertEqual(run_errors[0].code, "INVALID_RESUME_COMMAND")
        self.assertIn("value", run_errors[0].message)

    async def test_command_not_a_dict_rejected(self):
        """command that's not a dict is rejected."""
        client = _make_client(stream_chunks=[])
        events = await _collect_events(
            client,
            self._input_with_command("not-a-dict"),
        )

        run_errors = [e for e in events if e.type == "RUN_ERROR"]
        self.assertEqual(len(run_errors), 1)
        self.assertEqual(run_errors[0].code, "INVALID_RESUME_COMMAND")

    async def test_valid_resume_with_interruption_id_passes_through(self):
        """Dict resume with 'interruption_id' is forwarded as-is."""
        stream_call_kwargs = {}

        mock_sdk = MagicMock()
        mock_sdk.runs.list = AsyncMock(side_effect=[[], []])

        async def _capture_stream(*args, **kwargs):
            stream_call_kwargs.update(kwargs)
            yield ["values", {"messages": []}, None]

        mock_sdk.runs.stream = _capture_stream

        client = AGUILangGraphClient(langgraph_client=mock_sdk, assistant_id="engine")
        events = await _collect_events(
            client,
            self._input_with_command({"resume": {"interruption_id": "int-001"}}),
        )

        # No RUN_ERROR
        types = [e.type for e in events]
        self.assertNotIn("RUN_ERROR", types)
        self.assertIn("RUN_FINISHED", types)
        # The dict (with interruption_id) was forwarded to Command(resume=...)
        command = stream_call_kwargs.get("command")
        self.assertIsNotNone(command)
        self.assertEqual(command["resume"], {"interruption_id": "int-001"})


class TestToolCallBufferCleanup(unittest.IsolatedAsyncioTestCase):
    """open_tool_calls must be cleared at run end, and abandoned
    tool_call_chunks (args received but no name ever arrived) must log a
    warning instead of emitting invalid TOOL_CALL_END events.
    """

    async def test_abandoned_tool_call_chunks_warn_and_do_not_emit_end(self):
        msg_id = "lc_run--msg-001"
        # Stream emits only a tool_call_chunk with args but no name.
        stream_chunks = [
            ["events", {
                "event": "on_chat_model_stream",
                "data": {"chunk": {
                    "id": msg_id,
                    "type": "AIMessageChunk",
                    "content": [],
                    "tool_call_chunks": [{"id": "", "name": "", "args": '{"q":"hi"}', "index": 0}],
                }},
                "tags": [],
            }, None],
            # Stream ends without a name or on_tool_start.
        ]
        client = _make_client(stream_chunks=stream_chunks)

        with self.assertLogs("ag_ui_langgraph.client", level="WARNING") as log_ctx:
            events = await _collect_events(client, _make_input())

        # No invalid TOOL_CALL_START/END for the buffered chunk
        types = [e.type for e in events]
        self.assertNotIn("TOOL_CALL_START", types)
        self.assertNotIn("TOOL_CALL_END", types)
        # RUN_FINISHED still emitted
        self.assertIn("RUN_FINISHED", types)
        # Warning mentions abandoned count
        self.assertTrue(
            any("Abandoned 1 tool_call_chunks without name" in line for line in log_ctx.output),
            f"Expected abandoned-tool-calls warning in {log_ctx.output}",
        )


class TestToolCallStreaming(unittest.IsolatedAsyncioTestCase):

    async def test_tool_call_chunks_emit_start_args_end(self):
        """Tool call chunks from on_chat_model_stream → START + ARGS + END (via on_tool_start)."""
        msg_id = "lc_run--msg-001"
        stream_chunks = [
            ["events", {
                "event": "on_chat_model_stream",
                "data": {"chunk": {
                    "id": msg_id,
                    "type": "AIMessageChunk",
                    "content": [],
                    "tool_call_chunks": [{"id": "tc-1", "name": "search", "args": "", "index": 0}],
                }},
                "tags": [],
            }, None],
            ["events", {
                "event": "on_chat_model_stream",
                "data": {"chunk": {
                    "id": msg_id,
                    "type": "AIMessageChunk",
                    "content": [],
                    "tool_call_chunks": [{"id": "", "name": "", "args": '{"query":', "index": 0}],
                }},
                "tags": [],
            }, None],
            ["events", {
                "event": "on_tool_start",
                "name": "search",
                "data": {},
                "tags": [],
            }, None],
        ]
        client = _make_client(stream_chunks=stream_chunks)
        events = await _collect_events(client, _make_input())

        types = [e.type for e in events]
        self.assertIn("TOOL_CALL_START", types)
        self.assertIn("TOOL_CALL_ARGS", types)
        self.assertIn("TOOL_CALL_END", types)

        tc_start = [e for e in events if e.type == "TOOL_CALL_START"][0]
        self.assertEqual(tc_start.tool_call_name, "search")
        self.assertEqual(tc_start.tool_call_id, "tc-1")


if __name__ == "__main__":
    unittest.main()
