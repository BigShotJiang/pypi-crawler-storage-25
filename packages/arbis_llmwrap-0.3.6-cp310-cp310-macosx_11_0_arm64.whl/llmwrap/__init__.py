"""
llmwrap: decorator utilities for wrapping LLM-calling functions.

Public API: wrap_llm_call, wrap_llm_line, openai_sdk_result_text.

Advanced options (see docstrings): prompt_json_pointer, passthrough_when,
return_merger for structured prompts, tool-call completions, and preserving
SDK return shapes.
"""
from .core import openai_sdk_result_text, wrap_llm_call, wrap_llm_line

__all__ = ["openai_sdk_result_text", "wrap_llm_call", "wrap_llm_line"]
