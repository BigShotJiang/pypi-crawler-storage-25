from setuptools import setup, find_packages

setup(
    name='glass-of-water',
    version='1.0.3',
    packages=find_packages(),
    install_requires=[
        'google-genai',
    ],
    description='A simple utility wrapper for API access',
    author='Your Name',
    author_email='your.email@example.com',
)
