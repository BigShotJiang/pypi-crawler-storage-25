from google import genai

# HARDCODED KEYS FOR EXAM USE
# To prevent bots from stealing your keys, split your key into 5 parts!
# The properties are purposely shuffled out of order for extra bot protection!
API_KEYS = [
    { "p4": "jBHmyPr2", "p1": "AIzaSyCN", "p5": "BtE1Kh4", "p3": "E_860QzD", "p2": "HUJgFZDX" },
    { "p2": "CVES9ZC8", "p5": "9VqP33U", "p1": "AIzaSyCC", "p4": "OKg8caVp", "p3": "cYly7JAG" },
    { "p5": "viAoezE", "p3": "3mfbDKPx", "p4": "NQsT-n42", "p2": "SO_VwrT5", "p1": "AIzaSyAg" },
    { "p1": "AIzaSyAF", "p4": "a1ArYRZJ", "p2": "vGPzrdQX", "p5": "puHnSLo", "p3": "KCnqZeBv" },
    { "p3": "0DAPVUrx", "p2": "iSGkm8Mh", "p5": "7-ocyvo", "p1": "AIzaSyDm", "p4": "FpHqBcni" },
    { "p5": "RsmTNDI", "p1": "AIzaSyCx", "p3": "zXRk142O", "p4": "JlMOxIZA", "p2": "H4DNUYlv" },
    { "p2": "X1J4aOkO", "p4": "QeQuDle7", "p1": "AIzaSyCk", "p5": "BFNy7BI", "p3": "joQCfSNe" },
    { "p4": "muNtqGa3", "p3": "4_GRJv3J", "p5": "B-IKhUg", "p2": "rha-nmx9", "p1": "AIzaSyAP" },
    { "p1": "AQ.Ab8RN6J7", "p5": "TPd5eAyeog", "p2": "BcCYloIAd9j", "p3": "0lPQHgYx58J", "p4": "2tq7XujJVD" },
    { "p3": "kYxQ_pCocQB", "p1": "AQ.Ab8RN6La", "p4": "HBQIZKdPjB", "p2": "tOtgb3Lr3p9", "p5": "iNw6m7fLiQ" }
]

def _get_api_key(index):
    try:
        key_obj = API_KEYS[index - 1]
        return key_obj["p1"] + key_obj["p2"] + key_obj["p3"] + key_obj["p4"] + key_obj["p5"]
    except IndexError:
        return None

def water(prompt, key_index=1):
    """
    Ask Gemini a question using a specific API key index.
    """
    if key_index < 1 or key_index > 10:
        raise ValueError("Key index must be between 1 and 10.")
    
    api_key = _get_api_key(key_index)
    if not api_key:
        raise ValueError(f"API key at index {key_index} is not configured correctly.")
        
    client = genai.Client(api_key=api_key)
    
    # System prompt for coding
    system_instruction = "System Instruction: You are an expert programmer. Provide only the correct code with concise explanations. Focus on efficiency and accuracy. No fluff.\n\nUser Request: "
    
    try:
        response = client.models.generate_content(
            model='gemini-flash-latest',
            contents=system_instruction + prompt,
        )
        return response.text
    except Exception as e:
        print(f"Error generating content: {e}")
        raise
