"""Argument parser setup for the Quodeq CLI."""
from __future__ import annotations

import argparse

from quodeq.shared.utils import get_evaluations_dir

_DEFAULT_N_SUBAGENTS = 5
_MODE_NUMERICAL = "numerical"
_MODE_GRADES = "grades"


def _add_output_args(parser: argparse.ArgumentParser) -> None:
    """Register output and scoring mode arguments."""
    parser.add_argument(
        "-o", "--output", default=get_evaluations_dir(), help="Reports output directory"
    )
    parser.add_argument(
        "-m", "--mode", default=_MODE_NUMERICAL,
        choices=[_MODE_NUMERICAL, _MODE_GRADES], help="Scoring mode",
    )
    parser.add_argument(
        "--evidence-only", action="store_true",
        help="Produce evidence JSON only (skip scoring)",
    )


def _add_evaluate_args(parser: argparse.ArgumentParser) -> None:
    """Register arguments for the evaluate subcommand."""
    parser.add_argument("repo", help="Path or URL to the repository")
    parser.add_argument(
        "-l", "--language", default=None, help="Language (overrides auto-detection)"
    )
    _add_output_args(parser)
    parser.add_argument(
        "--no-prescan", action="store_true", help="Skip source-file counting"
    )
    parser.add_argument(
        "-d", "--dimensions", default=None,
        help="Comma-separated dimensions to evaluate (default: all)",
    )
    parser.add_argument(
        "--max-turns", type=int, default=None,
        help="Max AI conversation turns per dimension (default: 200)",
    )
    parser.add_argument(
        "--max-duration", type=int, default=None,
        help="Max seconds per dimension before terminating (default: 1800)",
    )
    parser.add_argument(
        "--n-subagents", "--max-subagents", type=int, default=_DEFAULT_N_SUBAGENTS,
        dest="n_subagents",
        help="Max parallel subagents per dimension (default: %(default)s)",
    )
    parser.add_argument(
        "--no-verify", action="store_true",
        help="Skip post-analysis verification pass",
    )
    parser.add_argument(
        "--time-limit", "--pool-budget",
        dest="pool_budget", type=int, default=None,
        help="Total evaluation time limit in seconds (0 = unlimited; default: 600). "
             "--pool-budget is a deprecated alias.",
    )
    parser.add_argument(
        "--no-consolidated", action="store_true",
        help="Disable multi-dimension consolidation (evaluate dimensions separately)",
    )
    parser.add_argument(
        "--clean-scan", action="store_true", dest="clean_scan",
        help="Force a full re-analysis, ignoring any cached findings from prior runs. "
             "By default Quodeq carries forward findings for unchanged files.",
    )
    parser.add_argument(
        "--incremental", action="store_true", dest="legacy_incremental",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--branch", default=None,
        help="Git branch to analyze (creates a temporary worktree)",
    )
    parser.add_argument(
        "--scope", default=None,
        help="Subdirectory to analyze (relative to repo root)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Skip AI calls and generate placeholder findings (for CI pipeline testing)",
    )
    parser.add_argument(
        "--diff-from",
        default=None,
        metavar="REF",
        help=(
            "PR mode: analyze only files changed since <ref> (e.g., "
            "origin/develop). Mutually exclusive with --incremental. "
            "Produces evidence only — no scored evaluation reports."
        ),
    )


def build_parser() -> argparse.ArgumentParser:
    """Build the top-level argument parser with all subcommands."""
    parser = argparse.ArgumentParser(prog="quodeq")
    subparsers = parser.add_subparsers(dest="command")

    dashboard_parser = subparsers.add_parser("dashboard", help="Run the dashboard")
    dashboard_parser.set_defaults(handler_command="dashboard")

    evaluate_parser = subparsers.add_parser(
        "evaluate", help="Run evaluation (auto-detects language)"
    )
    _add_evaluate_args(evaluate_parser)
    evaluate_parser.set_defaults(handler_command="evaluate")

    ci_parser = subparsers.add_parser("ci", help="CI integration commands")
    ci_sub = ci_parser.add_subparsers(dest="ci_action")
    report_parser = ci_sub.add_parser("report", help="Post evaluation results as PR review")
    report_parser.add_argument("--evaluation-dir", required=True, help="Path to evaluation output directory")
    report_parser.add_argument("--owner", required=True, help="GitHub repository owner")
    report_parser.add_argument("--repo", required=True, help="GitHub repository name")
    report_parser.add_argument("--pr", type=int, required=True, help="Pull request number")
    report_parser.add_argument("--token", help="GitHub token (default: GITHUB_TOKEN env var)")
    report_parser.add_argument("--duration", type=int, help="Evaluation duration in seconds")
    report_parser.add_argument(
        "--baseline-dir",
        help="Path to baseline evaluation directory for new vs. existing classification (optional)",
    )
    report_parser.add_argument(
        "--artifact-url",
        help="URL to the workflow run page where the evaluation artifact can be downloaded (optional)",
    )
    report_parser.add_argument(
        "--from-evidence",
        action="store_true",
        dest="from_evidence",
        help=(
            "Read violations from <evaluation-dir>/evidence/<dim>_evidence.jsonl "
            "instead of scored evaluation/<dim>.json reports. Use for PR diff "
            "mode runs that skip the scoring phase."
        ),
    )

    review_parser = subparsers.add_parser(
        "review",
        help="Run Quodeq locally and post findings as a PR review (uses gh CLI)",
    )
    review_parser.add_argument(
        "--pr",
        type=int,
        help="PR number to post to (default: auto-detect from current branch)",
    )
    review_parser.add_argument(
        "--dimensions",
        help=(
            "Dimensions to evaluate (comma-separated). Accepts full names or aliases: "
            "sec, rel, mnt, perf, flex, ux. Default: all dimensions."
        ),
    )
    review_parser.add_argument(
        "--time-limit", "--pool-budget",
        dest="pool_budget", type=int,
        help="Total time budget in seconds for the evaluation (default: 300). "
             "--pool-budget is a deprecated alias.",
    )
    review_parser.add_argument(
        "--output",
        help="Evaluation output directory (default: ~/.quodeq/evaluations)",
    )
    review_parser.add_argument(
        "--dry-run",
        action="store_true",
        dest="dry_run",
        help="Build the review but do not post it",
    )

    return parser
