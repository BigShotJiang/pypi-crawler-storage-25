"""Numerical-mode scoring helpers: deduction computation and grade drops."""
from __future__ import annotations

from dataclasses import dataclass

from quodeq.core.types import Deductions

# Progressive drop tables: (min_type_count_inclusive, levels_to_drop).
# Checked top-to-bottom; first matching row wins.
_CRITICAL_DROP_TABLE: list[tuple[int, int]] = [(12, 3), (4, 2), (1, 1)]
_MAJOR_DROP_TABLE: list[tuple[int, int]] = [(36, 3), (12, 2), (4, 1)]

# Per-type deduction constants for numerical mode.
# Override via configure_penalties(); defaults are used when no config is set.

_DEFAULT_CRITICAL_PENALTY = 2.0
_DEFAULT_MAJOR_PENALTY = 1.0
_DEFAULT_MINOR_PENALTY = 0.25


@dataclass(frozen=True)
class _PenaltyConfig:
    critical: float
    major: float
    minor: float


_penalty_config: _PenaltyConfig = _PenaltyConfig(
    critical=_DEFAULT_CRITICAL_PENALTY,
    major=_DEFAULT_MAJOR_PENALTY,
    minor=_DEFAULT_MINOR_PENALTY,
)


def configure_penalties(
    critical: float | None = None,
    major: float | None = None,
    minor: float | None = None,
) -> None:
    """Set penalty values. Called by outer layers (e.g. config) at startup."""
    global _penalty_config
    _penalty_config = _PenaltyConfig(
        critical=critical if critical is not None else _penalty_config.critical,
        major=major if major is not None else _penalty_config.major,
        minor=minor if minor is not None else _penalty_config.minor,
    )


def reset_penalty_caches() -> None:
    """Reset all penalty values to defaults. Useful for test isolation."""
    global _penalty_config
    _penalty_config = _PenaltyConfig(
        critical=_DEFAULT_CRITICAL_PENALTY,
        major=_DEFAULT_MAJOR_PENALTY,
        minor=_DEFAULT_MINOR_PENALTY,
    )


_CRITICAL_SCORE_CAP = 3
_MAJOR_SCORE_CAP = 5
_MAX_SCORE = 10


def _compute_severity_deduction(
    count: int, type_cap: int, penalty: float, score_cap: int,
) -> tuple[float, int]:
    """Compute deduction and score cap for a single severity level.

    Returns (deduction_points, effective_score_cap).
    """
    effective = min(count, type_cap)
    deduction = effective * penalty
    cap = score_cap if count >= type_cap else _MAX_SCORE
    return deduction, cap


def build_deductions(
    violation_type_counts: dict[str, int],
    scale_multiplier: int = 1,
    *,
    critical_penalty: float | None = None,
    major_penalty: float | None = None,
    minor_penalty: float | None = None,
    config: _PenaltyConfig | None = None,
) -> Deductions:
    """Compute point deductions for numerical mode.

    Rules:
    - Each distinct critical violation type removes 2.0 points; types are capped
      at 3*scale before computing the deduction.
    - Each distinct major violation type removes 1.0 point; capped at 5*scale.
    - Minor violation types are NOT capped — every distinct type deducts 0.25.
    - If the raw critical count reaches 3*scale, the score is hard-capped at 3.
    - If the raw major count reaches 5*scale, the score is hard-capped at 5.
    - Both caps may apply simultaneously (take min).
    """
    cfg = config if config is not None else _penalty_config
    crit_pen = critical_penalty if critical_penalty is not None else cfg.critical
    maj_pen = major_penalty if major_penalty is not None else cfg.major
    min_pen = minor_penalty if minor_penalty is not None else cfg.minor

    n_critical = violation_type_counts.get("critical", 0)
    n_major = violation_type_counts.get("major", 0)
    n_minor = violation_type_counts.get("minor", 0)

    critical_deduction, cap_from_critical = _compute_severity_deduction(
        n_critical, _CRITICAL_SCORE_CAP * scale_multiplier, crit_pen, _CRITICAL_SCORE_CAP,
    )
    major_deduction, cap_from_major = _compute_severity_deduction(
        n_major, _MAJOR_SCORE_CAP * scale_multiplier, maj_pen, _MAJOR_SCORE_CAP,
    )
    minor_deduction = n_minor * min_pen

    return Deductions(
        critical_type_count=n_critical,
        major_type_count=n_major,
        minor_type_count=n_minor,
        critical_deduction=critical_deduction,
        major_deduction=major_deduction,
        minor_deduction=minor_deduction,
        total_deduction=critical_deduction + major_deduction + minor_deduction,
        critical_cap=cap_from_critical,
        major_cap=cap_from_major,
    )


def count_grade_drops(violation_type_counts: dict[str, int], scale_multiplier: int = 1) -> int:
    """Return the number of grade levels to drop in non-numerical mode.

    Drop table thresholds are multiplied by scale_multiplier so that large
    projects require proportionally more violation types before incurring drops.
    """
    n_critical = violation_type_counts.get("critical", 0)
    n_major = violation_type_counts.get("major", 0)

    critical_drops = 0
    for min_count, levels in _CRITICAL_DROP_TABLE:
        if n_critical >= min_count * scale_multiplier:
            critical_drops = levels
            break

    major_drops = 0
    for min_count, levels in _MAJOR_DROP_TABLE:
        if n_major >= min_count * scale_multiplier:
            major_drops = levels
            break

    return max(critical_drops, major_drops)
