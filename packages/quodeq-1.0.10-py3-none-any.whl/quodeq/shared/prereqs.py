"""Prerequisite checks for external tool dependencies."""
from __future__ import annotations

import os
import subprocess
import urllib.error
import urllib.request

from quodeq.analysis._provider_cache import get_provider_configs
from quodeq.shared.utils import IS_WIN32 as _IS_WIN32, get_ai_cmd

_INSTALL_HINT_NODE = (
    "Install Node.js + npm from https://nodejs.org/ or via your package manager:\n"
    "  brew install node                    # macOS (installs both)\n"
    "  sudo apt install -y nodejs npm       # Ubuntu/Debian (two packages)\n"
    "  sudo dnf install -y nodejs npm       # Fedora/RHEL\n"
    "  pacman -S nodejs npm                 # Arch"
)

_CLI_INSTALL_HINTS: dict[str, str] = {
    "claude": (
        "Install Claude Code:\n"
        "  npm install -g @anthropic-ai/claude-code\n"
        "  https://docs.anthropic.com/en/docs/claude-code/overview"
    ),
    "codex": (
        "Install Codex CLI:\n"
        "  npm install -g @openai/codex\n"
        "  https://developers.openai.com/codex/quickstart"
    ),
    "gemini": (
        "Install Gemini CLI:\n"
        "  npm install -g @anthropic-ai/gemini-cli\n"
        "  https://geminicli.com/docs/get-started/installation/"
    ),
}

_SETTINGS_HINT = (
    "Open the dashboard and go to Settings to select your AI provider:\n"
    "  quodeq"
)

_VERSION_CMD_TIMEOUT_S = 30
_API_CHECK_TIMEOUT_S = 5


def _run_version_cmd(cmd: list[str]) -> str:
    """Run a command and return its stdout, or raise FileNotFoundError.

    ``shell=True`` is required on Windows so that ``where`` and other
    shell built-ins resolve correctly and executables installed via npm
    (which are .cmd shims) can be found on PATH.  The *cmd* parameter
    is always a ``list[str]`` hard-coded by callers in this module
    (never user-influenced), so the shell injection risk does not apply.

    SECURITY: Do not pass user-controlled strings into *cmd*.
    All callers in this module construct *cmd* from string literals
    (e.g. ``["node", "--version"]``).  If this function is ever
    exposed to external input, ``shell=True`` MUST be removed.
    """
    if not isinstance(cmd, list):
        raise TypeError("cmd must be a list of strings, not a raw string")
    result = subprocess.run(
        cmd, capture_output=True, text=True, check=True, shell=_IS_WIN32,
        timeout=_VERSION_CMD_TIMEOUT_S,
    )
    return result.stdout.strip()


def _parse_major(version_str: str) -> int:
    """Extract the major version number from a version string like 'v20.11.0' or '10.2.0'."""
    cleaned = version_str.lstrip("v")
    return int(cleaned.split(".")[0])


def _check_tool_version(cmd: list[str], tool_name: str, min_major: int, install_hint: str) -> None:
    """Raise RuntimeError if *tool_name* is missing or below *min_major*."""
    try:
        version_str = _run_version_cmd(cmd)
    except (FileNotFoundError, subprocess.CalledProcessError) as exc:
        raise RuntimeError(
            f"{tool_name} {min_major}+ is required but not found.\n{install_hint}"
        ) from exc
    try:
        major = _parse_major(version_str)
    except (ValueError, IndexError):
        return
    if major < min_major:
        raise RuntimeError(
            f"{tool_name} {version_str} is below the minimum required version {min_major}.x.\n"
            f"{install_hint}"
        )


def check_node(min_major: int = 18) -> None:
    """Raise RuntimeError if Node.js is missing or below minimum version."""
    _check_tool_version(["node", "--version"], "Node.js", min_major, _INSTALL_HINT_NODE)


def check_npm(min_major: int = 9) -> None:
    """Raise RuntimeError if npm is missing or below minimum version."""
    _check_tool_version(["npm", "--version"], "npm", min_major, _INSTALL_HINT_NODE)


def _is_provider_explicitly_configured() -> bool:
    """Return True if the user has explicitly set a provider via env or config."""
    return "AI_PROVIDER" in os.environ or "AI_CMD" in os.environ


def _check_cli_provider(provider: str) -> None:
    """Check that a CLI provider binary is available on PATH."""
    try:
        _run_version_cmd([provider, "--version"])
    except (FileNotFoundError, subprocess.CalledProcessError) as exc:
        hint = _CLI_INSTALL_HINTS.get(provider, f"Install {provider} and make sure it is on your PATH.")
        raise RuntimeError(
            f"'{provider}' is configured as your AI provider but was not found.\n\n"
            f"{hint}\n\n"
            f"Or choose a different provider in the dashboard Settings:\n"
            f"  quodeq"
        ) from exc


def _check_api_provider(provider: str, *, env: dict[str, str] | None = None) -> None:
    """Check that an API provider has basic connectivity (Ollama: server running)."""
    _env = env or os.environ
    if provider == "ollama":
        try:
            _ollama_base = _env.get("OLLAMA_BASE_URL", "http://localhost:11434")
            urllib.request.urlopen(f"{_ollama_base}/api/tags", timeout=_API_CHECK_TIMEOUT_S)
        except (urllib.error.URLError, OSError) as exc:
            raise RuntimeError(
                "Ollama is configured as your AI provider but the server is not running.\n\n"
                "Start it with:\n"
                "  ollama serve\n\n"
                "Or install Ollama from https://ollama.com/download"
            ) from exc


def _collect_tool_issue(cmd: list[str], tool_name: str, min_major: int) -> str | None:
    """Return a one-line description of a tool problem, or None if OK.

    Used by aggregators that want to report every missing/outdated tool in
    a single error instead of failing fast on the first one.
    """
    try:
        version_str = _run_version_cmd(cmd)
    except (FileNotFoundError, subprocess.CalledProcessError):
        return f"{tool_name} {min_major}+ not found on PATH"
    try:
        major = _parse_major(version_str)
    except (ValueError, IndexError):
        return None
    if major < min_major:
        return f"{tool_name} {version_str} is below the minimum required version {min_major}.x"
    return None


def check_dashboard_prereqs() -> None:
    """Check all prerequisites for the dashboard command in one pass.

    Runs every tool check, collects any issues, and raises a single
    RuntimeError that lists them all — so a user missing both Node.js and
    npm (common on fresh Debian/Ubuntu systems where they're separate
    packages) gets the full story in one message, with one install command.
    """
    issues: list[str] = []
    node_issue = _collect_tool_issue(["node", "--version"], "Node.js", 18)
    if node_issue is not None:
        issues.append(node_issue)
    npm_issue = _collect_tool_issue(["npm", "--version"], "npm", 9)
    if npm_issue is not None:
        issues.append(npm_issue)
    if not issues:
        return
    bullets = "\n".join(f"  - {issue}" for issue in issues)
    raise RuntimeError(
        f"Missing or outdated prerequisites:\n{bullets}\n\n{_INSTALL_HINT_NODE}"
    )


def check_evaluate_prereqs() -> None:
    """Check all prerequisites for the evaluate command.

    Checks the configured AI provider instead of always assuming Claude.
    If no provider is configured, tells the user to select one.
    """
    if not _is_provider_explicitly_configured():
        raise RuntimeError(
            "No AI provider configured.\n\n"
            "Quodeq needs an AI provider to evaluate your code. You can use:\n\n"
            "  Local (free, private):  Ollama with Gemma 4\n"
            "  Cloud (faster):         Claude Code, Codex CLI, or Gemini CLI\n\n"
            f"{_SETTINGS_HINT}"
        )

    provider = get_ai_cmd()
    configs = get_provider_configs()
    provider_cfg = configs.get(provider, {})
    provider_type = provider_cfg.get("type", "cli")

    if provider_type == "cli":
        _check_cli_provider(provider)
    elif provider_type == "api":
        _check_api_provider(provider)
