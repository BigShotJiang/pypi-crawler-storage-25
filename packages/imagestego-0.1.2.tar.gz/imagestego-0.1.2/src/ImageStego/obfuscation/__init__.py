"""Lazy exports for obfuscation helpers."""

from importlib import import_module

_EXPORTS = {
    "pixel_obfuscate": (".pixel_scramble", "obfuscate"),
    "pixel_deobfuscate": (".pixel_scramble", "deobfuscate"),
    "block_obfuscate": (".block_scramble", "obfuscate"),
    "block_deobfuscate": (".block_scramble", "deobfuscate"),
    "arnold_cat_obfuscate": (".arnold_cat_map", "obfuscate"),
    "arnold_cat_deobfuscate": (".arnold_cat_map", "deobfuscate"),
    "bakers_obfuscate": (".bakers_map", "obfuscate"),
    "bakers_deobfuscate": (".bakers_map", "deobfuscate"),
    "henon_obfuscate": (".henon_map", "obfuscate"),
    "henon_deobfuscate": (".henon_map", "deobfuscate"),
    "obfuscate_gif": (".gif_scramble", "obfuscate"),
    "deobfuscate_gif": (".gif_scramble", "deobfuscate"),
    "obfuscate_mp4": (".mp4_scramble", "obfuscate"),
    "deobfuscate_mp4": (".mp4_scramble", "deobfuscate"),
}

__all__ = list(_EXPORTS.keys())


def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module_name, attribute = _EXPORTS[name]
    module = import_module(module_name, __name__)
    value = getattr(module, attribute)
    globals()[name] = value
    return value
