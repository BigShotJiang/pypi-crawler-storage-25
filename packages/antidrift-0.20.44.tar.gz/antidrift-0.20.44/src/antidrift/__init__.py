"""Company brain for Claude."""
