"""Tests for Wauldo SDK."""
