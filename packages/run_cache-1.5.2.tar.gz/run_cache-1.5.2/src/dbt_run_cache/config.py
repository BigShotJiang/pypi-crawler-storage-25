from __future__ import annotations

import os
import typing as t
import dataclasses
from dataclasses import dataclass, field, Field
from enum import Enum
from pathlib import Path

import pytimeparse2

try:
    from dbt.artifacts.resources.v1.config import TestConfig
except ImportError:
    from dbt.contracts.graph.model_config import TestConfig

from dbt.config.profile import read_profile
from dbt.config.runtime import RuntimeConfig

from dbt_run_cache.utils import str_to_bool

if t.TYPE_CHECKING:
    from dbt.artifacts.resources.v1.model import ModelConfig
    from dbt.artifacts.resources.v1.seed import SeedConfig
    from dbt.artifacts.resources.v1.snapshot import SnapshotConfig


ENV_VAR_PREFIXES = ("RUN_CACHE_", "DBT_RUN_CACHE_")
CONFIG_KEY_PREFIX = "run_cache_"


def get_env(name: str, default: str = "") -> str:
    """Get an environment variable checking both RUN_CACHE_ and DBT_RUN_CACHE_ prefixes.

    RUN_CACHE_ takes precedence over DBT_RUN_CACHE_.
    """
    for prefix in ENV_VAR_PREFIXES:
        value = os.environ.get(f"{prefix}{name.upper()}")
        if value is not None:
            return value
    return default


def _resolve_home_path() -> Path:
    env_override = get_env("HOME")
    if env_override:
        return Path(env_override)
    new_path = Path.home() / ".run-cache"
    legacy_path = Path.home() / ".drc"
    if not new_path.exists() and legacy_path.exists():
        return legacy_path
    return new_path


DBT_RUN_CACHE_PATH = _resolve_home_path()


DEFER_TO_DEFAULT = "prod"
DEFER_LOG_LEVEL_DEFAULT = "off"
FRESHNESS_TOLERANCE_DEFAULT = 2700  # 45 minutes
METADATA_CACHE_TTL_DEFAULT = 0  # infinite (cache never expires)
API_CLIENT_TIMEOUT_DEFAULT = 60  # seconds
CLIENT_ID_DEFAULT = "2fd87cd5-69a6-4c5f-9097-747a58f0edf6"


class CloneIncrementalInDev(str, Enum):
    NEVER = "NEVER"
    IF_TABLE_MISSING = "IF_TABLE_MISSING"
    ALWAYS = "ALWAYS"


FieldAndType = tuple[Field, type]


def _parse_time(value: str) -> int:
    result = pytimeparse2.parse(value)
    if isinstance(result, float):
        return int(result)
    if not isinstance(result, int):
        raise ValueError(f"Cannot parse time value '{value}'")
    return result


def _parse_clone_incremental_in_dev(value: str) -> CloneIncrementalInDev:
    normalized = value.upper()
    try:
        return CloneIncrementalInDev(normalized)
    except ValueError:
        options = [e.value for e in CloneIncrementalInDev]
        raise ValueError(
            f"Invalid clone_incremental_in_dev value: '{value}'. Must be one of {options}"
        )


@dataclass
class RunCacheConfig:
    defer_to: str = DEFER_TO_DEFAULT
    # Mostly used for demo purposes to output defer to console
    defer_log_level: str = DEFER_LOG_LEVEL_DEFAULT
    # Decision logger configuration
    enable_response_logging: bool = True
    enable_data_tests: bool = True
    log_file_limit: int = 20
    log_dir_override: t.Optional[str] = None
    log_prefix: str = "responses_"
    freshness_tolerance: int = field(
        default=FRESHNESS_TOLERANCE_DEFAULT, metadata={"parser": _parse_time}
    )
    tolerate_nondeterminism: bool = True
    clone_incremental_in_dev: CloneIncrementalInDev = field(
        default=CloneIncrementalInDev.IF_TABLE_MISSING,
        metadata={"parser": _parse_clone_incremental_in_dev},
    )
    clone_time_travel_limit: t.Optional[int] = field(default=None, metadata={"parser": _parse_time})
    metadata_cache_ttl: int = field(
        default=METADATA_CACHE_TTL_DEFAULT, metadata={"parser": _parse_time}
    )
    api_client_timeout: int = field(
        default=API_CLIENT_TIMEOUT_DEFAULT, metadata={"parser": _parse_time}
    )
    oauth_client_id: str = field(default=CLIENT_ID_DEFAULT, metadata={"sensitive": True})
    oauth_client_secret: t.Optional[str] = field(default=None, metadata={"sensitive": True})
    org_id: t.Optional[str] = None
    run_hooks_on_no_op: bool = False
    snowflake_get_view_ddl_override: t.Optional[str] = None
    snowflake_metadata_warehouse: t.Optional[str] = None

    @classmethod
    def from_runtime_config(cls, config: RuntimeConfig) -> RunCacheConfig:
        """
        Load configuration from multiple sources with precedence (highest to lowest):
        1. Environment variables (prefixed with DBT_RUN_CACHE_)
        2. Current target configuration in profiles.yml (prefixed with run_cache_)
        3. dbt_project.yml flags section (prefixed with run_cache_)
        4. Default values from the dataclass
        """
        config_fields = cls._fields_and_types()
        project_config = cls._load_from_project_flags(config, config_fields)
        profile_config = cls._load_from_profile(config, config_fields)
        env_config = cls._load_from_env(config_fields)
        merged_config = {**project_config, **profile_config, **env_config}
        return cls(**merged_config)

    @classmethod
    def _load_from_env(cls, config_fields: t.Dict[str, FieldAndType]) -> t.Dict[str, t.Any]:
        """Load configuration from environment variables."""
        config = {}
        for field_name, field_and_type in config_fields.items():
            env_var_value = get_env(field_name)
            if env_var_value:
                config[field_name] = cls._convert_value(env_var_value, field_and_type)
        return config

    @classmethod
    def _load_from_profile(
        cls, runtime_config: RuntimeConfig, config_fields: t.Dict[str, FieldAndType]
    ) -> t.Dict[str, t.Any]:
        """Load configuration from the current target configuration as defined in profiles.yml."""
        config = {}
        raw_profiles = read_profile(runtime_config.args.profiles_dir)
        profile_name = runtime_config.profile_name
        target_name = runtime_config.target_name

        if profile_name in raw_profiles:
            profile = raw_profiles[profile_name]
            outputs = profile.get("outputs", {})
            if target_name in outputs:
                target_config = outputs[target_name]
                for field_name, field_and_type in config_fields.items():
                    config_key = f"{CONFIG_KEY_PREFIX}{field_name}"
                    if config_key in target_config:
                        config[field_name] = cls._convert_value(
                            target_config[config_key], field_and_type
                        )
        return config

    @classmethod
    def _load_from_project_flags(
        cls, runtime_config: RuntimeConfig, config_fields: t.Dict[str, FieldAndType]
    ) -> t.Dict[str, t.Any]:
        """Load configuration from flags section of dbt_project.yml."""
        config = {}
        if hasattr(runtime_config, "flags"):
            flags = runtime_config.flags
        else:
            from ruamel import yaml
            from dbt.config.renderer import DbtProjectYamlRenderer

            raw_project_config = yaml.YAML().load(
                Path(runtime_config.project_root) / "dbt_project.yml"
            )
            flags = raw_project_config.get("flags", {})
            renderer = DbtProjectYamlRenderer(
                profile=runtime_config, cli_vars=runtime_config.cli_vars
            )
            flags = renderer.render_data(flags)

        for field_name, field_and_type in config_fields.items():
            config_key = f"{CONFIG_KEY_PREFIX}{field_name}"
            if config_key in flags:
                config[field_name] = cls._convert_value(flags[config_key], field_and_type)
        return config

    @classmethod
    def _convert_value(cls, value: t.Any, field_and_type: FieldAndType) -> t.Any:
        """If the value is string, coerce it to the target type."""
        if not isinstance(value, str):
            return value

        target_field, target_type = field_and_type

        if target_type == str:
            return value

        # Handle Optional types by checking whether the given type is a generic Union type with
        # one of its arguments being NoneType
        if t.get_origin(target_type) is t.Union:
            non_none_types = [t for t in t.get_args(target_type) if t != type(None)]
            if non_none_types:
                return cls._convert_value(value, (target_field, non_none_types[0]))

        try:
            custom_parser = target_field.metadata.get("parser")
            if callable(custom_parser):
                return custom_parser(value)
            if target_type == int:
                return int(value)
            if target_type == float:
                return float(value)
            if target_type == bool:
                return str_to_bool(value)
        except Exception as e:
            raise ValueError(f"Cannot convert value '{value}' to type {target_type}") from e

        return value

    @classmethod
    def _fields_and_types(cls) -> t.Dict[str, FieldAndType]:
        fields = {f.name: f for f in dataclasses.fields(cls)}
        type_hints = t.get_type_hints(cls)
        return {n: (fields[n], type_hints[n]) for n in fields}

    def to_json(self, exclude_sensitive: bool = True) -> dict:
        result = {}
        for field in dataclasses.fields(self):
            if exclude_sensitive and field.metadata.get("sensitive", False):
                continue
            value = getattr(self, field.name)
            result[field.name] = value.value if isinstance(value, Enum) else value
        return result

    def resolve_tolerate_nondeterminism(
        self, node_config: t.Union[ModelConfig, SnapshotConfig, TestConfig]
    ) -> bool:
        value = node_config.get(f"{CONFIG_KEY_PREFIX}tolerate_nondeterminism")
        if value is None:
            return self.tolerate_nondeterminism
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return str_to_bool(value)
        if isinstance(value, int):
            return bool(value)
        raise ValueError(
            f"Invalid run_cache_tolerate_nondeterminism model config value of type {type(value).__name__}: {value!r}. "
            "Expected bool, int, or string (e.g., 'true', 'false', 'yes', 'no')."
        )

    def resolve_run_hooks_on_no_op(
        self, node_config: t.Union[ModelConfig, SnapshotConfig, SeedConfig, TestConfig]
    ) -> bool:
        value = node_config.get(f"{CONFIG_KEY_PREFIX}run_hooks_on_no_op")
        if value is None:
            return self.run_hooks_on_no_op
        if not isinstance(value, str):
            value = str(value)
        return str_to_bool(value)

    def resolve_freshness_tolerance(
        self, node_config: t.Union[ModelConfig, SnapshotConfig, TestConfig]
    ) -> int:
        if isinstance(node_config, TestConfig):
            # Since tests can run in a separate command invocation from models / snapshots, we cannot accurately
            # determine which upstream changes the test needs to react to vs. which ones it can tolerate. Therefore,
            # we take a conservative approach and disable tolerance to always react to upstream data changes
            return 0
        value = node_config.get(f"{CONFIG_KEY_PREFIX}freshness_tolerance")
        if value is None:
            return self.freshness_tolerance
        if isinstance(value, bool):
            raise ValueError(
                f"Invalid run_cache_freshness_tolerance model config value: {value!r}. "
                "Expected int (seconds) or time string (e.g., '30s', '5m')."
            )
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            return _parse_time(value)
        raise ValueError(
            f"Invalid run_cache_freshness_tolerance model config value of type {type(value).__name__}: {value!r}. "
            "Expected int (seconds) or time string (e.g., '30s', '5m')."
        )

    @property
    def defer_logging_enabled(self) -> bool:
        return self.defer_log_level.lower() != "off"
