"""Decorators for defining Athena blocks."""

import functools
import inspect
from collections.abc import Callable
from typing import Any, TypeVar

from pydantic import BaseModel

from athena.types import BlockInput, BlockOutput, BlockSpec

F = TypeVar("F", bound=Callable[..., Any])

CONFIG_PATH_EXTENSIONS = (".yaml", ".yml")


def _validate_config_path(config_path: str | None) -> str | None:
    if config_path is None:
        return None
    normalized = config_path.strip()
    if not normalized:
        raise ValueError("config_path must be a non-empty YAML path relative to the workspace root")
    if not normalized.lower().endswith(CONFIG_PATH_EXTENSIONS):
        raise ValueError(
            f"config_path must point to a YAML file ending in .yaml or .yml; got {config_path!r}"
        )
    return normalized


def block(
    name: str | None = None,
    description: str | None = None,
    inputs: list[str] | None = None,
    outputs: list[str] | None = None,
    config: type[BaseModel] | None = None,
    config_path: str | None = None,
    secrets: list[str] | None = None,
) -> Callable[[F], F]:
    """Decorator to define an Athena block.

    Usage:
        @block(
            name="TrainVAE",
            inputs=["data"],
            outputs=["checkpoint", "samples"],
            config=TrainVAEConfig,
            config_path="athenalabs/configs/blocks/train_vae.yaml",
            secrets=["OPENAI_API_KEY"],
        )
        async def train_vae(ctx: BlockContext, config: TrainVAEConfig) -> dict:
            ...

    Args:
        name: Block name (defaults to function name)
        description: Block description (defaults to function docstring)
        inputs: List of input names
        outputs: List of output names
        config: Pydantic model class for config schema validation
        config_path: Path to a YAML config file, relative to workspace root
        secrets: List of required secret names resolved at runtime (e.g., ['OPENAI_API_KEY'])
    """
    validated_config_path = _validate_config_path(config_path)

    def decorator(func: F) -> F:
        # Store block metadata on the function
        block_name = name or func.__name__
        block_description = description or func.__doc__

        input_specs = [BlockInput(name=n, type="Any", required=True) for n in (inputs or [])]
        output_specs = [BlockOutput(name=n, type="ArtifactRef") for n in (outputs or [])]

        # Build config schema
        config_schema = None
        if config:
            config_schema = config.model_json_schema()

        # Create block spec
        spec = BlockSpec(
            name=block_name,
            description=block_description,
            inputs=input_specs,
            outputs=output_specs,
            config_schema=config_schema,
            config_path=validated_config_path,
            secrets=secrets or [],
        )

        # Attach spec to function
        func.__athena_block__ = spec  # type: ignore[attr-defined]
        func.__athena_config_class__ = config  # type: ignore[attr-defined]

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                return await func(*args, **kwargs)
        else:

            @functools.wraps(func)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                return func(*args, **kwargs)

        # Copy attributes to wrapper
        wrapper.__athena_block__ = spec  # type: ignore[attr-defined]
        wrapper.__athena_config_class__ = config  # type: ignore[attr-defined]

        return wrapper  # type: ignore[return-value]

    return decorator


def get_block_spec(func: Callable[..., Any]) -> BlockSpec | None:
    """Get the block spec from a decorated function."""
    return getattr(func, "__athena_block__", None)


def get_config_class(func: Callable[..., Any]) -> type[BaseModel] | None:
    """Get the config class from a decorated function."""
    return getattr(func, "__athena_config_class__", None)
