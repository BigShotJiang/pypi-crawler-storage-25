"""Tests for SDK decorators."""

import importlib

import pytest
from pydantic import BaseModel

from athena import (
    BlockContext,
    block,
    get_block_spec,
    get_config_class,
)

_REMOVED_INSPECTOR_EXPORTS = (
    "inspector" + "_backend",
    "Inspector" + "BackendProtocol",
    "Inspector" + "Context",
    "get_" + "inspector" + "_backend_marker",
    "is_" + "inspector" + "_backend",
)
_REMOVED_INSPECTOR_MODULE = "athena." + "inspector" + "_backend"


class TrainConfig(BaseModel):
    """Test config class."""

    epochs: int = 100
    batch_size: int = 32


@block(
    name="TestBlock",
    description="A test block",
    inputs=["data"],
    outputs=["output"],
    config=TrainConfig,
)
async def sample_block_func(
    ctx: BlockContext,  # noqa: ARG001
    config: TrainConfig,  # noqa: ARG001
) -> dict:
    """A test block function."""
    return {"output": None}


class TestBlockDecorator:
    """Tests for the @block decorator."""

    def test_block_decorator_attaches_spec(self) -> None:
        """Test that @block attaches a spec to the function."""
        spec = get_block_spec(sample_block_func)

        assert spec is not None
        assert spec.name == "TestBlock"
        assert spec.description == "A test block"

    def test_block_decorator_captures_inputs(self) -> None:
        """Test that @block captures input definitions."""
        spec = get_block_spec(sample_block_func)

        assert spec is not None
        assert len(spec.inputs) == 1
        assert spec.inputs[0].name == "data"
        assert spec.inputs[0].type == "Any"

    def test_block_decorator_captures_outputs(self) -> None:
        """Test that @block captures output definitions."""
        spec = get_block_spec(sample_block_func)

        assert spec is not None
        assert len(spec.outputs) == 1
        assert spec.outputs[0].name == "output"

    def test_block_decorator_captures_config_class(self) -> None:
        """Test that @block captures config class."""
        config_class = get_config_class(sample_block_func)

        assert config_class is not None
        assert config_class == TrainConfig

    def test_block_decorator_captures_config_schema(self) -> None:
        """Test that @block captures config schema."""
        spec = get_block_spec(sample_block_func)

        assert spec is not None
        assert spec.config_schema is not None
        assert "epochs" in spec.config_schema.get("properties", {})

    @pytest.mark.asyncio
    async def test_decorated_function_is_callable(self) -> None:
        """Test that decorated function remains callable."""
        # Create a mock context
        from unittest.mock import MagicMock

        ctx = MagicMock(spec=BlockContext)
        config = TrainConfig()

        result = await sample_block_func(ctx, config)

        assert result == {"output": None}

    def test_block_decorator_with_defaults(self) -> None:
        """Test @block with default values."""

        @block(name="MinimalBlock")
        async def minimal_block(_ctx: BlockContext) -> None:
            pass

        spec = get_block_spec(minimal_block)

        assert spec is not None
        assert spec.name == "MinimalBlock"
        assert len(spec.inputs) == 0
        assert len(spec.outputs) == 0
        assert spec.config_schema is None
        assert spec.secrets == []

    def test_block_decorator_accepts_yaml_config_path(self) -> None:
        """Test @block accepts YAML config paths."""

        @block(name="ConfiguredBlock", config_path="configs/blocks/train.yml")
        async def configured_block(_ctx: BlockContext) -> None:
            pass

        spec = get_block_spec(configured_block)

        assert spec is not None
        assert spec.config_path == "configs/blocks/train.yml"

    def test_block_decorator_rejects_non_yaml_config_path(self) -> None:
        """Test @block rejects non-YAML config paths."""

        with pytest.raises(ValueError, match="must point to a YAML file"):

            @block(name="JsonConfiguredBlock", config_path="configs/blocks/train.json")
            async def json_configured_block(_ctx: BlockContext) -> None:
                pass

    def test_block_decorator_rejects_empty_config_path(self) -> None:
        """Test @block rejects empty config paths."""

        with pytest.raises(ValueError, match="non-empty YAML path"):

            @block(name="EmptyConfiguredBlock", config_path=" ")
            async def empty_configured_block(_ctx: BlockContext) -> None:
                pass

    def test_block_decorator_with_secrets(self) -> None:
        """Test @block with secrets declaration."""

        @block(
            name="SecretBlock",
            secrets=["OPENAI_API_KEY", "AWS_ACCESS_KEY_ID"],
        )
        async def secret_block(_ctx: BlockContext) -> None:
            """Block that requires secrets."""
            pass

        spec = get_block_spec(secret_block)

        assert spec is not None
        assert spec.secrets == ["OPENAI_API_KEY", "AWS_ACCESS_KEY_ID"]

    def test_block_decorator_secrets_defaults_to_empty(self) -> None:
        """Test that secrets defaults to empty list when not specified."""

        @block(name="NoSecrets")
        async def no_secrets_block(_ctx: BlockContext) -> None:
            pass

        spec = get_block_spec(no_secrets_block)

        assert spec is not None
        assert spec.secrets == []
        assert spec.secrets == []

    def test_block_decorator_without_name(self) -> None:
        """Test @block without explicit name uses function name."""

        @block()
        async def auto_named_block(_ctx: BlockContext) -> None:
            """Auto-named block."""
            pass

        spec = get_block_spec(auto_named_block)

        assert spec is not None
        assert spec.name == "auto_named_block"
        assert spec.description == "Auto-named block."

    @pytest.mark.asyncio
    async def test_sync_block_is_callable(self) -> None:
        """Test that a sync function decorated with @block can be called via await."""
        from unittest.mock import MagicMock

        @block(name="SyncBlock")
        def sync_block(
            ctx: BlockContext,  # noqa: ARG001
        ) -> dict:
            """A sync block function."""
            return {"result": 42}

        spec = get_block_spec(sync_block)
        assert spec is not None
        assert spec.name == "SyncBlock"

        ctx = MagicMock(spec=BlockContext)
        # The @block decorator wraps sync functions in an async wrapper
        result = await sync_block(ctx)  # type: ignore[misc]
        assert result == {"result": 42}

    @pytest.mark.asyncio
    async def test_async_block_still_works(self) -> None:
        """Test that an async function decorated with @block still works."""
        from unittest.mock import MagicMock

        @block(name="AsyncBlock")
        async def async_block(
            ctx: BlockContext,  # noqa: ARG001
        ) -> dict:
            """An async block function."""
            return {"result": 99}

        ctx = MagicMock(spec=BlockContext)
        result = await async_block(ctx)
        assert result == {"result": 99}


class TestHandlerRemoval:
    """Tests for the removed @handler surface."""

    def test_top_level_sdk_no_longer_exports_handler(self) -> None:
        """Top-level athena should not expose handler symbols."""
        import athena

        assert "handler" not in athena.__all__
        assert "HandlerSpec" not in athena.__all__
        assert "get_handler_spec" not in athena.__all__
        assert not hasattr(athena, "handler")

    def test_types_module_no_longer_exports_handler(self) -> None:
        """athena.types should not expose handler symbols."""
        import athena.types

        assert "handler" not in athena.types.__all__
        assert "HandlerSpec" not in athena.types.__all__
        assert "get_handler_spec" not in athena.types.__all__
        assert not hasattr(athena.types, "handler")

    def test_handler_module_is_removed(self) -> None:
        """Importing athena.handler should fail after the cutover."""
        with pytest.raises(ModuleNotFoundError):
            importlib.import_module("athena.handler")


class TestRemovedInspectorSurface:
    """Tests for the removed interactive inspector SDK surface."""

    def test_top_level_sdk_no_longer_exports_removed_inspector_surface(self) -> None:
        """Top-level athena should not expose the removed inspector surface."""
        import athena

        for name in _REMOVED_INSPECTOR_EXPORTS:
            assert name not in athena.__all__
        assert not hasattr(athena, _REMOVED_INSPECTOR_EXPORTS[0])

    def test_types_module_no_longer_exports_removed_inspector_surface(self) -> None:
        """athena.types should not expose the removed inspector surface."""
        import athena.types

        for name in _REMOVED_INSPECTOR_EXPORTS:
            assert name not in athena.types.__all__
        assert not hasattr(athena.types, _REMOVED_INSPECTOR_EXPORTS[0])

    def test_removed_inspector_module_fails_to_import(self) -> None:
        """Importing the removed inspector module should fail after the cutover."""
        with pytest.raises(ModuleNotFoundError):
            importlib.import_module(_REMOVED_INSPECTOR_MODULE)
