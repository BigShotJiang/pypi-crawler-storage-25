#ifndef __CRACKLE_OPERATIONS_HPP__
#define __CRACKLE_OPERATIONS_HPP__

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <memory>
#include <string>
#include <vector>
#include <span>
#include <type_traits>
#include <unordered_map>
#include <mutex>

#include "robin_hood.hpp"

#include "cc3d.hpp"
#include "crc.hpp"
#include "header.hpp"
#include "crackcodes.hpp"
#include "lib.hpp"
#include "labels.hpp"
#include "pins.hpp"
#include "markov.hpp"
#include "dual_graph.hpp"
#include "threadpool.hpp"

namespace crackle {
namespace operations {

crackle::CrackleHeader get_header(
	const unsigned char* buffer, 
	const size_t num_bytes
) {
	if (num_bytes < CrackleHeader::header_size) {
		std::string err = "crackle: Input too small to be a valid stream. Bytes: ";
		err += std::to_string(num_bytes);
		throw std::runtime_error(err);
	}

	const CrackleHeader header(buffer);

	if (header.format_version > CrackleHeader::current_version) {
		std::string err = "crackle: Invalid format version.";
		err += std::to_string(header.format_version);
		throw std::runtime_error(err);
	}

	return header;
}

int64_t get_szr(
	const crackle::CrackleHeader& header,
	int64_t z_start, 
	int64_t z_end
) {
	z_start = std::max(std::min(z_start, static_cast<int64_t>(header.sz - 1)), static_cast<int64_t>(0));
	z_end = z_end < 0 ? static_cast<int64_t>(header.sz) : z_end;
	z_end = std::max(std::min(z_end, static_cast<int64_t>(header.sz)), static_cast<int64_t>(0));

	if (z_start >= z_end) {
		std::string err = "crackle: Invalid range: ";
		err += std::to_string(z_start);
		err += std::string(" - ");
		err += std::to_string(z_end);
		throw std::runtime_error(err);
	}

	return z_end - z_start;
}


uint64_t get_voxels(
	const crackle::CrackleHeader& header,
	int64_t z_start, 
	int64_t z_end
) {
	const int64_t szr = get_szr(header, z_start, z_end);

	return (
		static_cast<uint64_t>(header.sx) 
		* static_cast<uint64_t>(header.sy) 
		* static_cast<uint64_t>(szr)
	);
}

template <typename LABEL>
void for_each_z_parallel(
	const unsigned char* buffer, 
	const size_t num_bytes,
	int64_t z_start,
	int64_t z_end,
	size_t parallel,
	const std::function<void(
		std::vector<uint8_t>&, 
		std::vector<uint32_t>&,
		uint64_t,
		std::vector<LABEL>&,
		int64_t
	)>& fn
) {
	const CrackleHeader header = get_header(buffer, num_bytes);

	z_start = std::max(std::min(z_start, static_cast<int64_t>(header.sz - 1)), static_cast<int64_t>(0));
	z_end = z_end < 0 ? static_cast<int64_t>(header.sz) : z_end;
	z_end = std::max(std::min(z_end, static_cast<int64_t>(header.sz)), static_cast<int64_t>(0));

	if (z_start >= z_end) {
		std::string err = "crackle: Invalid range: ";
		err += std::to_string(z_start);
		err += std::string(" - ");
		err += std::to_string(z_end);
		throw std::runtime_error(err);
	}

	const int64_t szr = z_end - z_start;

	const uint64_t voxels = (
		static_cast<uint64_t>(header.sx) 
		* static_cast<uint64_t>(header.sy) 
		* static_cast<uint64_t>(szr)
	);

	if (voxels == 0) {
		return;
	}

	std::span<const unsigned char> binary(buffer, num_bytes);

	// only used for markov compressed streams
	std::vector<std::vector<uint8_t>> markov_model = decode_markov_model(header, binary);
	
	auto crack_codes = get_crack_codes(header, binary, z_start, z_end);

	if (parallel == 0) {
		parallel = std::thread::hardware_concurrency();
	}
	parallel = std::min(parallel, static_cast<size_t>(szr));

	ThreadPool pool(parallel);

	std::vector<std::vector<uint8_t>> vcgs(parallel);
	std::vector<std::vector<uint32_t>> ccls(parallel);

	for (size_t t = 0; t < parallel; t++) {
		vcgs[t].resize(header.sx * header.sy);
		ccls[t].resize(header.sx * header.sy);
	}

	for (size_t z = z_start, i = 0; i < crack_codes.size(); z++, i++) {
		pool.enqueue([&,z,i](size_t t){
			std::vector<uint8_t>& vcg = vcgs[t];
			std::vector<uint32_t>& ccl = ccls[t];
			auto& crack_code = crack_codes[i];

			crack_code_to_vcg(
				/*code=*/crack_code,
				/*sx=*/header.sx, /*sy=*/header.sy,
				/*permissible=*/(header.crack_format == CrackFormat::PERMISSIBLE),
				/*markov_model=*/markov_model,
				/*slice_edges=*/vcg.data()
			);

			uint64_t N = 0;
			crackle::cc3d::color_connectivity_graph<uint32_t>(
				vcg, header.sx, header.sy, 1, ccl.data(), N
			);

			std::vector<LABEL> label_map = decode_label_map<LABEL>(
				header, binary, ccl.data(), N, z, z+1
			);

			fn(vcg, ccl, N, label_map, z);
		});
	}

	pool.join();

	return;
}


template <typename LABEL>
std::unordered_map<uint64_t, std::vector<uint16_t>>
point_cloud(
	const unsigned char* buffer, 
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	const std::optional<std::vector<uint64_t>> labels = std::nullopt,
	size_t parallel = 1
) {
	const CrackleHeader header = get_header(buffer, num_bytes);
	const uint64_t voxels = get_voxels(header, z_start, z_end);
	const int64_t szr = get_szr(header, z_start, z_end);

	if (voxels == 0) {
		return std::unordered_map<uint64_t, std::vector<uint16_t>>();
	}

	const bool selective = labels.has_value();
	robin_hood::unordered_flat_set<uint64_t> labels_set;
	if (selective) {
		labels_set.insert(labels->begin(), labels->end());
	}

	std::span<const unsigned char> binary(buffer, num_bytes);
	uint64_t num_labels = crackle::labels::num_labels(binary);
	std::unordered_map<uint64_t, std::vector<uint16_t>> ptc;
	ptc.reserve(num_labels / (header.sz / szr));

	std::mutex mtx;

	for_each_z_parallel<LABEL>(
		buffer, num_bytes,
		z_start, z_end, parallel,
		[&](
			std::vector<uint8_t>& vcg, 
			std::vector<uint32_t>& ccl, 
			uint64_t N,
			std::vector<LABEL>& label_map,
			int64_t z
		){
			uint64_t label_i = 0;

			auto ptc_ccls = crackle::dual_graph::extract_contours(vcg, ccl, N, header.sx, header.sy);

			std::unique_lock<std::mutex> lock(mtx);

			for (auto ptc_ccl : ptc_ccls) {
				uint64_t current_label = label_map[label_i];
				
				if (selective && !labels_set.contains(current_label)) {
					label_i++;
					continue;
				}

				std::vector<uint16_t>& label_points = ptc[current_label];

				for (uint32_t loc : ptc_ccl) {
					uint16_t y = loc / header.sx;
					uint16_t x = loc - (header.sx * y);

					label_points.push_back(x);
					label_points.push_back(y);
					label_points.push_back(static_cast<uint16_t>(z));
				}

				label_i++;
			}
		}
	);

	return ptc;
}

auto point_cloud(
	const unsigned char* buffer, 
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	const std::optional<std::vector<uint64_t>> labels = std::nullopt,
	size_t parallel = 1
) {
	CrackleHeader header(buffer);

	if (header.data_width == 1) {
		return point_cloud<uint8_t>(
			buffer, num_bytes,
			z_start, z_end, labels, parallel
		);
	}
	else if (header.data_width == 2) {
		return point_cloud<uint16_t>(
			buffer, num_bytes,
			z_start, z_end, labels, parallel
		);
	}
	else if (header.data_width == 4) {
		return point_cloud<uint32_t>(
			buffer, num_bytes,
			z_start, z_end, labels, parallel
		);
	}
	else {
		return point_cloud<uint64_t>(
			buffer, num_bytes,
			z_start, z_end, labels, parallel
		);
	}
}

auto point_cloud(
	const std::span<const unsigned char>& buffer,
	const int64_t z_start = -1, 
	const int64_t z_end = -1,
	const std::optional<std::vector<uint64_t>> labels = std::nullopt,
	size_t parallel = 1
) {
	return point_cloud(
		buffer.data(),
		buffer.size(),
		z_start, z_end, labels, parallel
	);
}

template <typename LABEL>
std::unordered_map<uint64_t, uint64_t>
voxel_counts(
	const unsigned char* buffer, 
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	size_t parallel = 1
) {
	const CrackleHeader header = get_header(buffer, num_bytes);
	const uint64_t voxels = get_voxels(header, z_start, z_end);
	const int64_t szr = get_szr(header, z_start, z_end);

	if (voxels == 0) {
		return std::unordered_map<uint64_t, uint64_t>();
	}

	std::span<const unsigned char> binary(buffer, num_bytes);
	uint64_t num_labels = crackle::labels::num_labels(binary);
	std::unordered_map<uint64_t, uint64_t> cts;
	cts.reserve(num_labels / (header.sz / szr));

	const uint64_t sxy = header.sx * header.sy;

	std::mutex mtx;

	for_each_z_parallel<LABEL>(
		buffer, num_bytes,
		z_start, z_end, parallel,
		[&](
			std::vector<uint8_t>& vcg, 
			std::vector<uint32_t>& ccl, 
			uint64_t N,
			std::vector<LABEL>& label_map,
			int64_t z
		){
			std::vector<uint64_t> subcounts(N);

			for (uint64_t i = 0; i < sxy; i++) {
				subcounts[ccl[i]]++;
			}

			std::unique_lock<std::mutex> lock(mtx);
			for (uint64_t i = 0; i < N; i++) {
				cts[label_map[i]] += subcounts[i];
			}
		}
	);

	return cts;
}

auto voxel_counts(
	const unsigned char* buffer, 
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	size_t parallel = 1
) {
	CrackleHeader header(buffer);

	if (header.data_width == 1) {
		return voxel_counts<uint8_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
	else if (header.data_width == 2) {
		return voxel_counts<uint16_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
	else if (header.data_width == 4) {
		return voxel_counts<uint32_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
	else {
		return voxel_counts<uint64_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
}

auto voxel_counts(
	const std::span<const unsigned char>& buffer,
	const int64_t z_start = -1, 
	const int64_t z_end = -1,
	size_t parallel = 1
) {
	return voxel_counts(
		buffer.data(),
		buffer.size(),
		z_start, z_end, parallel
	);
}

template <typename LABEL>
std::unordered_map<uint64_t, std::array<double, 3>>
centroids(
	const unsigned char* buffer, 
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	size_t parallel = 1
) {
	const CrackleHeader header = get_header(buffer, num_bytes);
	const uint64_t voxels = get_voxels(header, z_start, z_end);
	const int64_t szr = get_szr(header, z_start, z_end);

	if (voxels == 0) {
		return std::unordered_map<uint64_t, std::array<double,3>>();
	}

	std::span<const unsigned char> binary(buffer, num_bytes);
	uint64_t num_labels = crackle::labels::num_labels(binary);
	std::unordered_map<uint64_t, std::array<uint64_t, 4>> cts; // label: x,y,z,N
	cts.reserve(num_labels / (header.sz / szr));

	std::mutex mtx;

	for_each_z_parallel<LABEL>(
		buffer, num_bytes,
		z_start, z_end, parallel,
		[&](
			std::vector<uint8_t>& vcg, 
			std::vector<uint32_t>& ccl, 
			uint64_t N,
			std::vector<LABEL>& label_map,
			int64_t z
		){
			std::vector<std::array<uint64_t, 4>> subcounts(N);

			for (uint64_t y = 0; y < header.sy; y++) {
				for (uint64_t x = 0; x < header.sx; x++) {
					uint32_t ccl_label = ccl[x + header.sx * y];

					subcounts[ccl_label][0] += x;
					subcounts[ccl_label][1] += y;
					subcounts[ccl_label][2] += z;
					subcounts[ccl_label][3]++;
				}
			}

			std::unique_lock<std::mutex> lock(mtx);
			for (uint64_t i = 0; i < N; i++) {
				auto& arr = cts[label_map[i]];
				arr[0] += subcounts[i][0];
				arr[1] += subcounts[i][1];
				arr[2] += subcounts[i][2];
				arr[3] += subcounts[i][3];
			}
		}
	);

	std::unordered_map<uint64_t, std::array<double, 3>> ctsf;
	ctsf.reserve(cts.size());

	for (auto& [label, ctarr] : cts) {
		ctsf[label] = {
			static_cast<double>(ctarr[0]) / static_cast<double>(ctarr[3]),
			static_cast<double>(ctarr[1]) / static_cast<double>(ctarr[3]),
			static_cast<double>(ctarr[2]) / static_cast<double>(ctarr[3]),
		};
	}

	return ctsf;
}

auto centroids(
	const unsigned char* buffer, 
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	size_t parallel = 1
) {
	CrackleHeader header(buffer);

	if (header.data_width == 1) {
		return centroids<uint8_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
	else if (header.data_width == 2) {
		return centroids<uint16_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
	else if (header.data_width == 4) {
		return centroids<uint32_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
	else {
		return centroids<uint64_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
}

auto centroids(
	const std::span<const unsigned char>& buffer,
	const int64_t z_start = -1, 
	const int64_t z_end = -1,
	size_t parallel = 1
) {
	return centroids(
		buffer.data(),
		buffer.size(),
		z_start, z_end, parallel
	);
}

template <typename LABEL>
std::unordered_map<uint64_t, std::array<uint32_t, 6>>
bounding_boxes(
	const unsigned char* buffer, 
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	size_t parallel = 1
) {

	const CrackleHeader header = get_header(buffer, num_bytes);
	const uint64_t voxels = get_voxels(header, z_start, z_end);

	if (voxels == 0) {
		return std::unordered_map<uint64_t, std::array<uint32_t,6>>();
	}

	std::span<const unsigned char> binary(buffer, num_bytes);
	uint64_t num_labels = crackle::labels::num_labels(binary);
	std::unordered_map<uint64_t, std::array<uint32_t, 6>> bbxes; // label: xmin,ymin,zmin,xmax,ymax,zmax
	bbxes.reserve(num_labels);

	std::vector<uint64_t> uniq = crackle::labels::unique(binary);
	for (auto lbl : uniq) {
		auto& bbx = bbxes[lbl];
		bbx[0] = std::numeric_limits<uint32_t>::max();
		bbx[1] = std::numeric_limits<uint32_t>::max();
		bbx[2] = std::numeric_limits<uint32_t>::max();
	}

	std::mutex mtx;

	for_each_z_parallel<LABEL>(
		buffer, num_bytes,
		z_start, z_end, parallel,
		[&](
			std::vector<uint8_t>& vcg, 
			std::vector<uint32_t>& ccl, 
			uint64_t N,
			std::vector<LABEL>& label_map,
			int64_t z
		){
			std::vector<std::array<uint32_t, 4>> slice_bbxs(N);

			for (uint64_t i = 0; i < N; i++) {
				slice_bbxs[i][0] = std::numeric_limits<uint32_t>::max(); // xmin
				slice_bbxs[i][1] = std::numeric_limits<uint32_t>::max(); // ymin
			}

			for (uint64_t y = 0; y < header.sy; y++) {
				for (uint64_t x = 0; x < header.sx; x++) {
					uint32_t ccl_label = ccl[x + header.sx * y];

					auto& bbx = slice_bbxs[ccl_label];

					bbx[0] = std::min(bbx[0], static_cast<uint32_t>(x));
					bbx[1] = std::min(bbx[1], static_cast<uint32_t>(y));
					bbx[2] = std::max(bbx[2], static_cast<uint32_t>(x));
					bbx[3] = std::max(bbx[3], static_cast<uint32_t>(y));
				}
			}

			std::unique_lock<std::mutex> lock(mtx);
			for (uint64_t i = 0; i < N; i++) {
				auto& bbx = bbxes[label_map[i]];
				bbx[0] = std::min(bbx[0], slice_bbxs[i][0]);
				bbx[1] = std::min(bbx[1], slice_bbxs[i][1]);
				bbx[2] = std::min(bbx[2], static_cast<uint32_t>(z));
				bbx[3] = std::max(bbx[3], slice_bbxs[i][2]);
				bbx[4] = std::max(bbx[4], slice_bbxs[i][3]);
				bbx[5] = std::max(bbx[5], static_cast<uint32_t>(z));
			}
		}
	);

	return bbxes;
}

auto bounding_boxes(
	const unsigned char* buffer, 
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	size_t parallel = 1
) {
	CrackleHeader header(buffer);

	if (header.data_width == 1) {
		return bounding_boxes<uint8_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
	else if (header.data_width == 2) {
		return bounding_boxes<uint16_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
	else if (header.data_width == 4) {
		return bounding_boxes<uint32_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
	else {
		return bounding_boxes<uint64_t>(
			buffer, num_bytes,
			z_start, z_end, parallel
		);
	}
}

auto bounding_boxes(
	const std::span<const unsigned char>& buffer,
	const int64_t z_start = -1, 
	const int64_t z_end = -1,
	size_t parallel = 1
) {
	return bounding_boxes(
		buffer.data(),
		buffer.size(),
		z_start, z_end, parallel
	);
}

uint8_t* voxel_connectivity_graph(
	const unsigned char* buffer,
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	size_t parallel = 1,
	const int connectivity = 4
) {
	if (connectivity != 4 && connectivity != 6) {
		std::string err = "crackle: voxel_connectivity_graph: only connectivity 4 and 6 are currently supported.";
		err += std::to_string(num_bytes);
		throw std::runtime_error(err);
	}

	if (num_bytes < CrackleHeader::header_size) {
		std::string err = "crackle: Input too small to be a valid stream. Bytes: ";
		err += std::to_string(num_bytes);
		throw std::runtime_error(err);
	}

	const CrackleHeader header(buffer);

	const uint64_t sx = header.sx;
	const uint64_t sy = header.sy;
	const uint64_t sz = header.sz;
	const uint64_t sxy = header.sx * header.sy;

	if (header.format_version > CrackleHeader::current_version) {
		std::string err = "crackle: Invalid format version.";
		err += std::to_string(header.format_version);
		throw std::runtime_error(err);
	}

	z_start = std::max(std::min(z_start, static_cast<int64_t>(sz - 1)), static_cast<int64_t>(0));
	z_end = z_end < 0 ? static_cast<int64_t>(sz) : z_end;
	z_end = std::max(std::min(z_end, static_cast<int64_t>(sz)), static_cast<int64_t>(0));

	if (z_start >= z_end) {
		std::string err = "crackle: Invalid range: ";
		err += std::to_string(z_start);
		err += std::string(" - ");
		err += std::to_string(z_end);
		throw std::runtime_error(err);
	}

	const int64_t szr = z_end - z_start;

	const uint64_t voxels = (
		static_cast<uint64_t>(sx) 
		* static_cast<uint64_t>(sy) 
		* static_cast<uint64_t>(szr)
	);

	uint8_t* vcg = new uint8_t[voxels];

	if (voxels == 0) {
		return vcg;
	}

	std::span<const unsigned char> binary(buffer, num_bytes);

	// only used for markov compressed streams
	std::vector<std::vector<uint8_t>> markov_model = decode_markov_model(header, binary);
	
	auto crack_codes = get_crack_codes(header, binary, z_start, z_end);

	if (parallel == 0) {
		parallel = std::thread::hardware_concurrency();
	}
	parallel = std::min(parallel, static_cast<size_t>(szr));

	ThreadPool pool(parallel);

	for (uint64_t i = 0; i < crack_codes.size(); i++) {
		pool.enqueue([&,i](size_t t){
			auto& crack_code = crack_codes[i];

			crack_code_to_vcg(
				/*code=*/crack_code,
				/*sx=*/sx, /*sy=*/sy,
				/*permissible=*/(header.crack_format == CrackFormat::PERMISSIBLE),
				/*markov_model=*/markov_model,
				/*slice_edges=*/(vcg + i * sxy)
			);
		});
	}

	pool.join();

	if (sz == 1 || connectivity == 4) {
		return vcg;
	}

	std::vector<std::vector<uint32_t>> ccls(2);
	std::vector<std::vector<uint64_t>> label_maps(2);
	for (size_t t = 0; t < ccls.size(); t++) {
		ccls[t].resize(sxy);
	}

	std::span<const uint8_t> init_sub_vcg(vcg, vcg + sxy);

	uint64_t N = 0;
	crackle::cc3d::color_connectivity_graph<uint32_t>(
		init_sub_vcg, sx, sy, 1, ccls[0].data(), N
	);

	label_maps[0] = decode_label_map<uint64_t>(
		header, binary, ccls[0].data(), N, z_start, z_start+1
	);

	for (size_t z = z_start + 1, i = 1; i < crack_codes.size(); z++, i++) {
		size_t bottom_j = i & 0b1;
		size_t top_j = (i-1) & 0b1;

		std::vector<uint32_t>& top_ccl = ccls[top_j];
		std::vector<uint32_t>& bottom_ccl = ccls[bottom_j];

		const std::span<uint8_t> sub_vcg(
			vcg + i * sxy, 
			vcg + (i+1) * sxy
		);

		uint64_t N = 0;
		crackle::cc3d::color_connectivity_graph<uint32_t>(
			sub_vcg, sx, sy, 1, bottom_ccl.data(), N
		);

		label_maps[bottom_j] = decode_label_map<uint64_t>(
			header, binary, bottom_ccl.data(), N, z, z+1
		);

		const std::vector<uint64_t>& top_labels = label_maps[top_j];
		const std::vector<uint64_t>& bottom_labels = label_maps[bottom_j];

		for (size_t y = 0; y < sy; y++) {
			for (size_t x = 0; x < sx; x++) {
				const int64_t loc = x + sx * y;
				const uint64_t bottom_label = bottom_labels[bottom_ccl[loc]];
				const uint64_t top_label = top_labels[top_ccl[loc]];

				if (bottom_label == top_label) {
					vcg[loc + (z-1) * sxy] |= 0b010000;
					vcg[loc + z * sxy] |= 0b100000;
				}
			}
		}
	}

	// set boundary to passable for compatibility with
	// certain operations like autapse elimination
	for (size_t y = 0; y < sy; y++) {
		for (size_t x = 0; x < sx; x++) {
			const int64_t loc = x + sx * y;
			vcg[loc] |= 0b100000;
			vcg[loc + (sz-1) * sxy] |= 0b010000;
		}
	}

	return vcg;
}

auto voxel_connectivity_graph(
	const std::span<const unsigned char>& buffer,
	const int64_t z_start = -1, 
	const int64_t z_end = -1,
	size_t parallel = 1,
	const int connectivity = 4
) {
	return voxel_connectivity_graph(
		buffer.data(),
		buffer.size(),
		z_start, z_end, parallel,
		connectivity
	);
}

struct pair_hash {
	inline std::size_t operator()(const std::pair<uint64_t,uint64_t> & v) const {
		return v.first * 31 + v.second; // arbitrary hash fn
	}
};

const std::unordered_map<std::pair<uint64_t,uint64_t>, float, pair_hash> 
contacts(
	const unsigned char* buffer,
	const size_t num_bytes,
	int64_t z_start = -1,
	int64_t z_end = -1,
	const float wx = 1,
	const float wy = 1,
	const float wz = 1
) {
	if (num_bytes < CrackleHeader::header_size) {
		std::string err = "crackle: Input too small to be a valid stream. Bytes: ";
		err += std::to_string(num_bytes);
		throw std::runtime_error(err);
	}

	const CrackleHeader header(buffer);

	const uint64_t sx = header.sx;
	const uint64_t sy = header.sy;
	const uint64_t sz = header.sz;
	const uint64_t sxy = header.sx * header.sy;

	if (header.format_version > CrackleHeader::current_version) {
		std::string err = "crackle: Invalid format version.";
		err += std::to_string(header.format_version);
		throw std::runtime_error(err);
	}

	z_start = std::max(std::min(z_start, static_cast<int64_t>(sz - 1)), static_cast<int64_t>(0));
	z_end = z_end < 0 ? static_cast<int64_t>(sz) : z_end;
	z_end = std::max(std::min(z_end, static_cast<int64_t>(sz)), static_cast<int64_t>(0));

	if (z_start >= z_end) {
		std::string err = "crackle: Invalid range: ";
		err += std::to_string(z_start);
		err += std::string(" - ");
		err += std::to_string(z_end);
		throw std::runtime_error(err);
	}

	const int64_t szr = z_end - z_start;

	const uint64_t voxels = (
		static_cast<uint64_t>(sx) 
		* static_cast<uint64_t>(sy) 
		* static_cast<uint64_t>(szr)
	);

	std::unordered_map<std::pair<uint64_t, uint64_t>, float, pair_hash> edges;

	if (voxels == 0) {
		return edges;
	}

	std::span<const unsigned char> binary(buffer, num_bytes);

	// only used for markov compressed streams
	std::vector<std::vector<uint8_t>> markov_model = decode_markov_model(header, binary);
	
	auto crack_codes = get_crack_codes(header, binary, z_start, z_end);

	std::vector<uint8_t> vcg(sxy);
	std::vector<std::vector<uint32_t>> ccls(2);
	std::vector<std::vector<uint64_t>> label_maps(2);
	for (size_t t = 0; t < ccls.size(); t++) {
		ccls[t].resize(sxy);
	}

	crack_code_to_vcg(
		/*code=*/crack_codes[0],
		/*sx=*/sx, /*sy=*/sy,
		/*permissible=*/(header.crack_format == CrackFormat::PERMISSIBLE),
		/*markov_model=*/markov_model,
		/*slice_edges=*/vcg.data()
	);

	uint64_t N = 0;
	crackle::cc3d::color_connectivity_graph<uint32_t>(
		vcg, sx, sy, 1, ccls[0].data(), N
	);

	label_maps[0] = decode_label_map<uint64_t>(
		header, binary, ccls[0].data(), N, z_start, z_start+1
	);

	const float area_x = wy * wz;
	const float area_y = wx * wz;
	const float area_z = wx * wy;


	auto add_edge = [&edges](uint64_t a, uint64_t b, float area) {
		if (a != 0 && b != 0) {
			const std::pair<uint64_t,uint64_t> p = (a <= b) 
				? std::pair<uint64_t,uint64_t>(a,b)
				: std::pair<uint64_t,uint64_t>(b,a);
				
			edges[p] += area;
		}
	};

	for (size_t y = 0; y < sy; y++) {
		for (size_t x = 0; x < sx; x++) {
			const int64_t loc = x + sx * y;

			if (x < sx - 1 && ccls[0][loc] != ccls[0][loc+1]) {
				add_edge(label_maps[0][ccls[0][loc]], label_maps[0][ccls[0][loc+1]], area_x);
			}
			if (y < sy - 1 && ccls[0][loc] != ccls[0][loc+sx]) {
				add_edge(label_maps[0][ccls[0][loc]], label_maps[0][ccls[0][loc+sx]], area_y);
			}
		}
	}

	for (size_t z = z_start + 1, i = 1; i < crack_codes.size(); z++, i++) {
		size_t bottom_j = i & 0b1;
		size_t top_j = (i-1) & 0b1;


		crack_code_to_vcg(
			/*code=*/crack_codes[i],
			/*sx=*/sx, /*sy=*/sy,
			/*permissible=*/(header.crack_format == CrackFormat::PERMISSIBLE),
			/*markov_model=*/markov_model,
			/*slice_edges=*/vcg.data()
		);

		std::vector<uint32_t>& top_ccl = ccls[top_j];
		std::vector<uint32_t>& bottom_ccl = ccls[bottom_j];

		uint64_t N = 0;
		crackle::cc3d::color_connectivity_graph<uint32_t>(
			vcg, sx, sy, 1, bottom_ccl.data(), N
		);

		label_maps[bottom_j] = decode_label_map<uint64_t>(
			header, binary, bottom_ccl.data(), N, z, z+1
		);

		const std::vector<uint64_t>& top_labels = label_maps[top_j];
		const std::vector<uint64_t>& bottom_labels = label_maps[bottom_j];

		for (size_t y = 0; y < sy; y++) {
			for (size_t x = 0; x < sx; x++) {
				const int64_t loc = x + sx * y;

				if (x < sx - 1 && bottom_ccl[loc] != bottom_ccl[loc+1]) {
					add_edge(
						bottom_labels[bottom_ccl[loc]], 
						bottom_labels[bottom_ccl[loc+1]],
						area_x
					);
				}
				if (y < sy - 1 && bottom_ccl[loc] != bottom_ccl[loc+sx]) {
					add_edge(
						bottom_labels[bottom_ccl[loc]],
						bottom_labels[bottom_ccl[loc+sx]],
						area_y
					);
				}
				if (bottom_labels[bottom_ccl[loc]] != top_labels[top_ccl[loc]]) {
					add_edge(
						bottom_labels[bottom_ccl[loc]],
						top_labels[top_ccl[loc]],
						area_z
					);
				}
			}
		}
	}

	return edges;
}

auto contacts(
	const std::span<const unsigned char>& buffer,
	const int64_t z_start = -1, 
	const int64_t z_end = -1,
	const float wx = 1,
	const float wy = 1,
	const float wz = 1
) {
	return contacts(
		buffer.data(),
		buffer.size(),
		z_start, z_end,
		wx, wy, wz
	);
}

bool array_equal(
	const unsigned char* buffer1,
	const size_t num_bytes1,
	const unsigned char* buffer2,
	const size_t num_bytes2,
	size_t parallel = 1
) {
	const CrackleHeader header1 = get_header(buffer1, num_bytes1);
	const CrackleHeader header2 = get_header(buffer2, num_bytes2);

	const uint64_t voxels1 = get_voxels(header1, 0, -1);
	const uint64_t voxels2 = get_voxels(header2, 0, -1);

	if (voxels1 == 0 || voxels2 == 0) {
		return voxels1 == voxels2;
	}

	if (
		header1.sx != header2.sx 
		|| header1.sy != header2.sy 
		|| header1.sz != header2.sz
	) {
		return false;
	}

	const size_t sx = header1.sx;
	const size_t sy = header1.sy;
	const size_t sz = header1.sz;

	std::span<const unsigned char> binary1(buffer1, num_bytes1);
	std::span<const unsigned char> binary2(buffer2, num_bytes2);

	// only used for markov compressed streams
	std::vector<std::vector<uint8_t>> markov_model1 = decode_markov_model(header1, binary1);
	std::vector<std::vector<uint8_t>> markov_model2 = decode_markov_model(header2, binary2);
	
	auto crack_codes1 = get_crack_codes(header1, binary1, 0, sz);
	auto crack_codes2 = get_crack_codes(header2, binary2, 0, sz);

	if (parallel == 0) {
		parallel = std::thread::hardware_concurrency();
	}
	parallel = std::min(parallel, sz);

	ThreadPool pool(parallel);

	std::vector<std::vector<uint8_t>> vcgs(parallel * 2);
	std::vector<std::vector<uint32_t>> ccls(parallel * 2);

	for (size_t t = 0; t < parallel * 2; t++) {
		vcgs[t].resize(header1.sx * header1.sy);
		ccls[t].resize(header1.sx * header1.sy);
	}
	
	std::atomic<bool> is_equal{true};

	for (size_t z = 0; z < sz; z++) {
		pool.enqueue([&,z](size_t t){
			if (!is_equal) {
				return;
			}

			t *= 2;

			std::vector<uint8_t>& vcg1 = vcgs[t];
			std::vector<uint8_t>& vcg2 = vcgs[t+1];
			
			std::vector<uint32_t>& ccl1 = ccls[t];
			std::vector<uint32_t>& ccl2 = ccls[t+1];

			auto& crack_code1 = crack_codes1[z];
			auto& crack_code2 = crack_codes2[z];

			crack_code_to_vcg(
				/*code=*/crack_code1,
				/*sx=*/sx, /*sy=*/sy,
				/*permissible=*/(header1.crack_format == CrackFormat::PERMISSIBLE),
				/*markov_model=*/markov_model1,
				/*slice_edges=*/vcg1.data()
			);

			if (!is_equal) {
				return;
			}

			crack_code_to_vcg(
				/*code=*/crack_code2,
				/*sx=*/sx, /*sy=*/sy,
				/*permissible=*/(header2.crack_format == CrackFormat::PERMISSIBLE),
				/*markov_model=*/markov_model2,
				/*slice_edges=*/vcg2.data()
			);

			if (!is_equal) {
				return;
			}

			uint64_t N1 = 0;
			crackle::cc3d::color_connectivity_graph<uint32_t>(
				vcg1, sx, sy, 1, ccl1.data(), N1
			);

			if (!is_equal) {
				return;
			}

			uint64_t N2 = 0;
			crackle::cc3d::color_connectivity_graph<uint32_t>(
				vcg2, sx, sy, 1, ccl2.data(), N2
			);

			if (!is_equal) {
				return;
			}

			if (N1 != N2) {
    			is_equal.store(false, std::memory_order_relaxed);
				return;
			}

			std::vector<uint64_t> label_map1 = decode_label_map<uint64_t>(
				header1, binary1, ccl1.data(), N1, z, z+1
			);
			std::vector<uint64_t> label_map2 = decode_label_map<uint64_t>(
				header2, binary2, ccl2.data(), N2, z, z+1
			);

			for (size_t y = 0; y < sy; y++) {
				for (size_t x = 0; x < sx; x++) {
					const int64_t loc = x + sx * y;
					const uint64_t a = label_map1[ccl1[loc]];
					const uint64_t b = label_map1[ccl2[loc]];

					if (a != b) {
						is_equal.store(false, std::memory_order_relaxed);
						return;
					}
				}
			}
		});
	}

	pool.join();

	return is_equal;
}

bool array_equal(
	const std::span<const unsigned char>& buffer1,
	const std::span<const unsigned char>& buffer2,
	const int parallel = 1
) {
	return array_equal(
		buffer1.data(),
		buffer1.size(),
		buffer2.data(),
		buffer2.size(),
		parallel
	);
}

};
};

#endif