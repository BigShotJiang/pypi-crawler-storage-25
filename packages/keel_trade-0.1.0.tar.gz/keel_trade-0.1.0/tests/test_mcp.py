"""Tests for the MCP server, registry, and dispatch."""

from __future__ import annotations

import asyncio
import json

import pytest

from keel.mcp.registry import get_registry, get_tool_detail, search_tool_registry
from keel.mcp.server import create_server


# ── Registry ──────────────────────────────────────────────────────────────


class TestRegistry:
    def test_registry_has_local_tools(self):
        registry = get_registry()
        assert "strategy_validate" in registry
        assert "strategy_components_search" in registry
        assert registry["strategy_validate"].execution == "local"

    def test_registry_has_remote_tools(self):
        registry = get_registry()
        assert "backtest_run" in registry
        assert "live_deploy" in registry
        assert registry["backtest_run"].execution == "remote"

    def test_registry_domain_grouping(self):
        registry = get_registry()
        assert registry["strategy_validate"].domain == "strategy"
        assert registry["backtest_run"].domain == "backtest"
        assert registry["live_deploy"].domain == "live"
        assert registry["strategy_components_search"].domain == "components"

    def test_registry_has_all_domains(self):
        registry = get_registry()
        domains = {t.domain for t in registry.values()}
        assert "components" in domains
        assert "strategy" in domains
        assert "backtest" in domains
        assert "live" in domains
        assert "universe" in domains

    def test_registry_has_sharing_and_audit(self):
        registry = get_registry()
        assert "sharing_create_link" in registry
        assert "sharing_fork" in registry
        assert "audit_list" in registry

    def test_search_by_name(self):
        results = search_tool_registry("validate")
        names = [r["name"] for r in results]
        assert "strategy_validate" in names

    def test_search_by_domain(self):
        results = search_tool_registry("backtest")
        names = [r["name"] for r in results]
        assert any("backtest" in n for n in names)

    def test_search_by_description(self):
        results = search_tool_registry("component")
        assert len(results) > 0

    def test_search_returns_scores(self):
        results = search_tool_registry("strategy")
        assert all("score" in r for r in results)
        # Results should be sorted by score descending
        scores = [r["score"] for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_search_empty_query(self):
        results = search_tool_registry("zzz_nonexistent_xyz")
        assert len(results) == 0

    def test_tool_detail_local(self):
        detail = get_tool_detail("strategy_validate")
        assert detail is not None
        assert detail["name"] == "strategy_validate"
        assert detail["execution"] == "local"
        assert "input_schema" in detail

    def test_tool_detail_remote(self):
        detail = get_tool_detail("backtest_run")
        assert detail is not None
        assert detail["execution"] == "remote"
        assert "method" in detail
        assert "path" in detail

    def test_tool_detail_nonexistent(self):
        detail = get_tool_detail("nonexistent_tool")
        assert detail is None

    def test_compile_is_remote(self):
        """strategy_compile moved from local to remote in SDK."""
        registry = get_registry()
        assert "strategy_compile" in registry
        assert registry["strategy_compile"].execution == "remote"


# ── Server ────────────────────────────────────────────────────────────────


def _run(coro):
    """Run async coroutine synchronously."""
    return asyncio.get_event_loop().run_until_complete(coro)


@pytest.fixture
def server():
    return create_server()


class TestServer:
    def test_server_creates(self, server):
        assert server.name == "keel"

    def test_search_tools(self, server):
        result = _run(server.call_tool("search_tools", {"query": "component"}))
        text = result.content[0].text
        data = json.loads(text)
        assert isinstance(data, list)
        assert len(data) > 0
        assert "name" in data[0]

    def test_describe_tool(self, server):
        result = _run(server.call_tool("describe_tool", {"name": "strategy_validate"}))
        text = result.content[0].text
        data = json.loads(text)
        assert data["name"] == "strategy_validate"
        assert "input_schema" in data

    def test_describe_tool_not_found(self, server):
        result = _run(server.call_tool("describe_tool", {"name": "nonexistent"}))
        text = result.content[0].text
        data = json.loads(text)
        assert "error" in data

    def test_keel_status(self, server):
        result = _run(server.call_tool("keel_status", {}))
        text = result.content[0].text
        data = json.loads(text)
        assert "authenticated" in data
        assert "api_url" in data

    def test_execute_local_tool(self, server):
        result = _run(server.call_tool("execute", {
            "tool_name": "strategy_components_search",
            "arguments": '{"keyword": "ROC"}',
        }))
        text = result.content[0].text
        data = json.loads(text)
        assert isinstance(data, list)
        assert len(data) > 0

    def test_execute_unknown_tool(self, server):
        result = _run(server.call_tool("execute", {
            "tool_name": "nonexistent_tool",
            "arguments": "{}",
        }))
        text = result.content[0].text
        data = json.loads(text)
        assert "error" in data

    def test_execute_invalid_json(self, server):
        result = _run(server.call_tool("execute", {
            "tool_name": "strategy_components_search",
            "arguments": "not valid json",
        }))
        text = result.content[0].text
        data = json.loads(text)
        assert "error" in data


# ── Dispatch ──────────────────────────────────────────────────────────────


class TestDispatch:
    def test_execute_local(self):
        from keel.mcp.dispatch import execute_local

        result = execute_local("strategy_components_search", {"keyword": "ROC"})
        assert isinstance(result, list)
        assert len(result) > 0

    def test_execute_local_unknown(self):
        from keel.mcp.dispatch import execute_local

        with pytest.raises(ValueError, match="Unknown local tool"):
            execute_local("nonexistent", {})

    def test_execute_remote_unknown(self):
        from keel.mcp.dispatch import execute_remote

        with pytest.raises(ValueError, match="Unknown remote tool"):
            execute_remote("nonexistent", {})
