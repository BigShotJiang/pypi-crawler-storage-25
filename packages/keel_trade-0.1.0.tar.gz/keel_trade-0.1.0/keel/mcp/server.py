"""MCP server — exposes Keel tools via the Model Context Protocol.

Uses the progressive discovery pattern: 4 meta-tools (search, describe, status,
execute) that provide access to all 50+ underlying tools. Keeps tools/list under
3K tokens while enabling full platform access.

Best practices applied:
- Tool descriptions specify WHEN to use, not just WHAT
- Annotations (readOnlyHint, destructiveHint) for client safety
- Structured errors with suggestion and retryable fields
- Flat primitive arguments, no nested dicts
"""

from __future__ import annotations

import json
from typing import Any

from fastmcp import FastMCP

from keel.mcp.dispatch import execute_tool
from keel.mcp.registry import get_tool_detail, search_tool_registry


def create_server() -> FastMCP:
    """Create and configure the MCP server."""
    mcp = FastMCP(
        name="keel",
        instructions=(
            "Keel is a quantitative crypto trading platform. "
            "Start with keel_status to check auth, then search_tools to discover "
            "capabilities, describe_tool for schemas, and execute to run. "
            "Local tools (components, validation, universe) need no API key. "
            "Remote tools (backtest, live, workspace sync) need KEEL_API_KEY."
        ),
    )

    # ── Meta-tools ────────────────────────────────────────────────────────

    @mcp.tool(
        annotations={"readOnlyHint": True, "idempotentHint": True},
    )
    def search_tools(query: str) -> str:
        """Find available Keel tools by keyword. Call this FIRST to discover what's possible.

        Use when: You need to find a tool but don't know its exact name.
        Returns: Array of {name, domain, description, execution, score} sorted by relevance.

        Example queries: "momentum", "backtest", "validate", "live trading",
        "components", "universe", "checkout"
        """
        results = search_tool_registry(query)
        return json.dumps(results, indent=2)

    @mcp.tool(
        annotations={"readOnlyHint": True, "idempotentHint": True},
    )
    def describe_tool(name: str) -> str:
        """Get the full parameter schema for a specific tool. Call this BEFORE execute().

        Use when: You found a tool via search_tools and need its argument schema.
        Returns: {name, domain, description, execution, input_schema} for local tools,
        plus {method, path} for remote tools.
        """
        detail = get_tool_detail(name)
        if detail is None:
            return json.dumps({
                "error": "tool_not_found",
                "message": f"Tool '{name}' not found",
                "suggestion": "Use search_tools to find available tools",
                "retryable": False,
            })
        return json.dumps(detail, indent=2)

    @mcp.tool(
        annotations={"readOnlyHint": True, "idempotentHint": True},
    )
    def keel_status() -> str:
        """Check authentication state and available capabilities. Call this FIRST in any session.

        Use when: Starting a new conversation, or when a remote tool fails with auth errors.
        Returns: {authenticated, api_url, local_tools, remote_tools, suggestion}.
        """
        from keel.config import load_config

        config = load_config()
        status: dict[str, Any] = {
            "authenticated": config.api_key is not None,
            "api_url": config.api_url,
            "local_tools": "Available (no auth needed): components, strategy validation, universe editing",
        }
        if config.api_key:
            try:
                from keel.auth import get_status

                remote = get_status()
                status.update(remote)
            except Exception as e:
                status["auth_error"] = str(e)
                status["remote_tools"] = "Auth configured but validation failed"
        else:
            status["remote_tools"] = "Requires KEEL_API_KEY: backtest, live, workspace sync, market-data"
            status["suggestion"] = "Set KEEL_API_KEY env var or run 'keel auth login'"
        return json.dumps(status, indent=2)

    @mcp.tool(
        annotations={"readOnlyHint": False},
    )
    def execute(tool_name: str, arguments: str = "{}") -> str:
        """Run any Keel tool by name with JSON arguments.

        Use when: You have a tool name from search_tools and its schema from describe_tool.
        Always call describe_tool first to get the parameter schema.

        Args:
            tool_name: The tool to execute (e.g., "strategy_components_search")
            arguments: JSON string of tool arguments (e.g., '{"keyword": "momentum"}')

        Returns: Tool result as JSON. On error: {error, message, suggestion, retryable}.
        """
        try:
            args = json.loads(arguments) if arguments else {}
        except json.JSONDecodeError as e:
            return json.dumps({
                "error": "invalid_json",
                "message": f"Invalid JSON arguments: {e}",
                "retryable": False,
                "suggestion": "Check JSON syntax. Arguments must be a valid JSON object.",
            })
        try:
            result = execute_tool(tool_name, args)
            return json.dumps(result, indent=2, default=str)
        except Exception as e:
            from keel.errors import KeelError

            if isinstance(e, KeelError):
                return json.dumps(e.to_dict())
            return json.dumps({
                "error": "execution_failed",
                "message": str(e),
                "retryable": False,
            })

    # ── Resources ─────────────────────────────────────────────────────────

    @mcp.resource("keel://components/catalog")
    def components_catalog() -> str:
        """Full component catalog — all 160+ components with parameters.
        Use when you need to browse the entire registry at once."""
        from keel.tools.local import strategy_components_dump

        return json.dumps(strategy_components_dump(), indent=2, default=str)

    @mcp.resource("keel://dsl/reference/{topic}")
    def dsl_reference_resource(topic: str) -> str:
        """DSL reference docs by topic (phases, types, slots, composition, normalization, best_practices)."""
        from keel.tools.local import dsl_reference

        return json.dumps(dsl_reference(topic=topic), indent=2)

    return mcp
