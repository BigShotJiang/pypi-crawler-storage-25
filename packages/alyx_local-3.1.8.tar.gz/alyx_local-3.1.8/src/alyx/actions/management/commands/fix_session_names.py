from django.core.management import BaseCommand
from alyx.actions.models import Session


class Command(BaseCommand):
    help = "Fix or update session names to make sure they follow the standard"

    def add_arguments(self, parser):
        parser.add_argument("--check", action="store_true", help="Check session names (flag)")
        parser.add_argument("--session-alias", type=str, help="Session alias string")

    def loop_update(self):
        updated = 0
        for session in Session.objects.all():
            new_name = session.alias
            if session.name != new_name:
                session.name = new_name
                session.save(update_fields=["name"])
                updated += 1
        self.stdout.write(self.style.SUCCESS(f"Updated {updated} session names."))

    def bulk_update(self):
        self.stdout.write("Updating all session names...")
        to_update = []
        for session_number, session in enumerate(Session.objects.all(), start=1):
            new_name = session.alias
            if session.name != new_name:
                session.name = new_name
                to_update.append(session)
        if to_update:
            Session.objects.bulk_update(to_update, ["name"])
        self.stdout.write(self.style.SUCCESS(f"Updated {len(to_update)} over {session_number} session names."))

    def check_session_name(self, session_alias: str):
        self.stdout.write("Checking session_name...")
        session = Session.objects.filter(alias=session_alias).first()
        if session is None:
            self.stdout.write(self.style.ERROR(f"Session with alias {session_alias} doesn't exist !"))
            return
        self.stdout.write(self.style.SUCCESS(f"Session with alias {session_alias} has session name {session.name}."))

    def handle(self, *args, **options):
        if not options.get("check", False):
            self.bulk_update()
        else:
            session_alias_to_check = options.get("session-alias", None)
            if not session_alias_to_check:
                self.stdout.write(self.style.ERROR("You must supply a --session-alias"))
                return
            self.check_session_name(session_alias_to_check)
