from django.shortcuts import render, redirect
from django.http import FileResponse, Http404
from django.utils.safestring import mark_safe
from django.views.generic.detail import DetailView
from django.views import View
from django.urls import reverse
from alyx.actions.models import Session
from natsort import natsorted
from itertools import groupby
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class ServeImagesView(DetailView):
    model = Session

    def render_page(self, request, images: list[list] | None = None):
        images = [[]] if images is None else images
        context = {"image_groups": images, **self.get_context_data()}
        return render(request, "results-manager/images_gallery.html", context)

    def get(self, request, *args, **kwargs):
        self.object: Session = self.get_object()  # type: ignore

        folder_path = Path(self.object.mount_path) / "figures"
        if not folder_path.is_dir():
            return self.render_page(request)
        try:
            image_files = [file for file in folder_path.iterdir() if file.suffix in (".png", ".jpg")]
        except FileNotFoundError:
            return self.render_page(request)
        image_files.sort()
        image_groups = [natsorted(group) for _, group in groupby(image_files, lambda x: str(x.stem).split(".")[1])]
        images = [
            [
                {
                    "filename": file.name,
                    "path": reverse("results-manager-send-figure", kwargs={"path": str(file)}),
                }
                for file in group
            ]
            for group in image_groups
        ]
        return self.render_page(request, images)

    def get_context_data(self, **kwargs):
        uuid = self.object.pk
        alias = self.object.alias
        backlink = reverse("admin:actions_session_change", args=[uuid])
        context = super().get_context_data(**kwargs)
        context["site_header"] = "Alyx"
        context["back_url"] = backlink
        context["title"] = mark_safe(
            f'Figures of session <a href="{backlink}">{alias}</a> obtained from location {self.object.path}'
        )
        context["session_alias"] = alias
        context["session_uuid"] = uuid
        return context


class SendImageView(View):
    def get(self, request, path):
        path = Path(path).resolve()
        if not path.is_file():
            raise Http404("File does not exist")
        return FileResponse(open(path, "rb"), as_attachment=False, filename=path.name)
