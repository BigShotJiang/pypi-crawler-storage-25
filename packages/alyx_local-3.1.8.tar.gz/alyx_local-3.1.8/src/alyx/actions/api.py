import itertools
from datetime import timedelta
from operator import itemgetter
from typing import cast

import structlog
from django.http import Http404
from django.shortcuts import get_object_or_404
from drf_spectacular.utils import extend_schema
from rest_framework.generics import (
    ListAPIView,
    ListCreateAPIView,
    RetrieveDestroyAPIView,
    RetrieveUpdateAPIView,
    RetrieveUpdateDestroyAPIView,
)
from rest_framework.response import Response
from rest_framework.views import APIView

from ..base.permissions import (
    rest_permission_classes,
)
from ..subjects.models import Subject
from .filters import (
    SessionFilter,
    WaterAdministrationFilter,
    WaterRestrictionFilter,
    WeighingFilter,
)

# from ..experiments.filters import _filter_qs_with_brain_regions
from .models import (
    LabLocation,
    ProcedureType,
    Session,
    Surgery,
    WaterAdministration,
    WaterRestriction,
    WaterType,
    Weighing,
)
from .serializers import (
    LabLocationSerializer,
    ProcedureTypeSerializer,
    SessionDetailSerializer,
    SessionListSerializer,
    SurgerySerializer,
    WaterAdministrationDetailSerializer,
    WaterRequirementSerializer,
    WaterRestrictionListSerializer,
    WaterTypeDetailSerializer,
    WeighingDetailSerializer,
)

logger = structlog.get_logger("actions.api")


def date_range(start_date, end_date):
    for n in range(int((end_date - start_date).days) + 1):
        yield (start_date + timedelta(n))


class ProcedureTypeList(ListCreateAPIView):
    queryset = ProcedureType.objects.all()
    permission_classes = rest_permission_classes()
    serializer_class = ProcedureTypeSerializer
    lookup_field = "name"


class SessionAPIList(ListCreateAPIView):
    """
        get: **FILTERS**

    -   **subject**: subject nickname `/sessions?subject=Algernon`
    -   **dataset_types**: dataset type
    -   **number**: session number
    -   **users**: experimenters (exact)
    -   **date_range**: date `/sessions?date_range=2020-01-12,2020-01-16`
    -   **lab**: lab name (exact)
    -   **task_protocol** (icontains)
    -   **location**: location name (icontains)
    -   **project**: project name (icontains)
    -   **json**: queries on json fields, for example here `tutu`
        -   exact/equal lookup: `/sessions?extended_qc=tutu,True`,
        -   gte lookup: `/sessions/?extended_qc=tutu__gte,0.5`,
    -   **extended_qc** queries on json fields, for example here `qc_bool` and `qc_pct`,
        values and fields come by pairs, using semi-colon as a separator
        -   exact/equal lookup: `/sessions?extended_qc=qc_bool;True`,
        -   gte lookup: `/sessions/?extended_qc=qc_pct__gte;0.5`,
        -   chained lookups: `/sessions/?extended_qc=qc_pct__gte;0.5;qc_bool;True`,
    -   **performance_gte**, **performance_lte**: percentage of successful trials gte/lte
    -   **brain_region**: returns a session if any channel name icontains the value:
        `/sessions?brain_region=visual cortex`
    -   **atlas_acronym**: returns a session if any of its channels name exactly matches the value
        `/sessions?atlas_acronym=SSp-m4`, cf Allen CCFv2017
    -   **atlas_id**: returns a session if any of its channels id matches the provided value:
        `/sessions?atlas_id=950`, cf Allen CCFv2017
    -   **qc**: returns sessions for which the qc statuses matches provided string. Should be
    one of CRITICAL, ERROR, WARNING, NOT_SET, PASS
        `/sessions?qc=CRITICAL`
    -   **histology**: returns sessions for which the subject has an histology session:
        `/sessions?histology=True`
    -   **django**: generic filter allowing lookups (same syntax as json filter)
        `/sessions?django=project__name__icontains,matlab
        filters sessions that have matlab in the project name
        `/sessions?django=~project__name__icontains,matlab
        does the exclusive set: filters sessions that do not have matlab in the project name

    [===> session model reference](/admin/doc/models/actions.session)
    """

    queryset = Session.objects.all()
    queryset = SessionListSerializer.setup_eager_loading(queryset)
    permission_classes = rest_permission_classes()

    filterset_class = SessionFilter

    def get_serializer_class(self):
        if not self.request or self.request.method == "GET":
            return SessionListSerializer
        if self.request.method == "POST":
            return SessionDetailSerializer


class SessionAPIDetail(RetrieveUpdateDestroyAPIView):
    """
    Detail of one session
    """

    queryset = Session.objects.all().order_by("-start_time")
    queryset = SessionDetailSerializer.setup_eager_loading(queryset)
    serializer_class = SessionDetailSerializer
    permission_classes = rest_permission_classes()

    def get_object(self):
        # Check which parameter was matched (pk or name)
        if "pk" in self.kwargs:
            return get_object_or_404(self.get_queryset(), id=self.kwargs["pk"])
        elif "name" in self.kwargs:
            return get_object_or_404(self.get_queryset(), name=self.kwargs["name"])
        raise Http404("No matching session found")

    @extend_schema(operation_id="session_retrieve")
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    @extend_schema(operation_id="session_update")
    def put(self, request, *args, **kwargs):
        return super().put(request, *args, **kwargs)

    @extend_schema(operation_id="session_partial_update")
    def patch(self, request, *args, **kwargs):
        return super().patch(request, *args, **kwargs)

    @extend_schema(operation_id="session_delete")
    def delete(self, request, *args, **kwargs):
        return super().delete(request, *args, **kwargs)


class SessionAPIDetailByName(SessionAPIDetail):
    @extend_schema(operation_id="session_retrieve_by_name")
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    @extend_schema(operation_id="session_update_by_name")
    def put(self, request, *args, **kwargs):
        return super().put(request, *args, **kwargs)

    @extend_schema(operation_id="session_partial_update_by_name")
    def patch(self, request, *args, **kwargs):
        return super().patch(request, *args, **kwargs)

    @extend_schema(operation_id="session_delete_by_name")
    def delete(self, request, *args, **kwargs):
        return super().delete(request, *args, **kwargs)


class WeighingAPIListCreate(ListCreateAPIView):
    """
    Lists or creates a new weighing.
    """

    permission_classes = rest_permission_classes()
    serializer_class = WeighingDetailSerializer
    queryset = Weighing.objects.all()
    queryset = WeighingDetailSerializer.setup_eager_loading(queryset)
    filterset_class = WeighingFilter


class WeighingAPIDetail(RetrieveDestroyAPIView):
    """
    Allows viewing of full detail and deleting a weighing.
    """

    permission_classes = rest_permission_classes()
    serializer_class = WeighingDetailSerializer
    queryset = Weighing.objects.all()


class WaterTypeList(ListCreateAPIView):
    queryset = WaterType.objects.all()
    serializer_class = WaterTypeDetailSerializer
    permission_classes = rest_permission_classes()
    lookup_field = "name"


class WaterAdministrationAPIListCreate(ListCreateAPIView):
    """
    Lists or creates a new water administration.
    """

    permission_classes = rest_permission_classes()
    serializer_class = WaterAdministrationDetailSerializer
    queryset = WaterAdministration.objects.all()
    queryset = WaterAdministrationDetailSerializer.setup_eager_loading(queryset)
    filterset_class = WaterAdministrationFilter


class WaterAdministrationAPIDetail(RetrieveUpdateDestroyAPIView):
    """
    Allows viewing of full detail and deleting a water administration.
    """

    permission_classes = rest_permission_classes()
    serializer_class = WaterAdministrationDetailSerializer
    queryset = WaterAdministration.objects.all()


def _merge_lists_dicts(la, lb, key):
    lst = sorted(itertools.chain(la, lb), key=itemgetter(key))
    out = []
    for k, v in itertools.groupby(lst, key=itemgetter(key)):
        d = {}
        for dct in v:
            d.update(dct)
        out.append(d)
    return out


class WaterRequirement(APIView):
    permission_classes = rest_permission_classes()
    serializer_class = WaterRequirementSerializer

    def get(self, request, format=None, nickname=None):
        assert nickname
        start_date = request.query_params.get("start_date", None)
        end_date = request.query_params.get("end_date", None)
        subject = cast(Subject, Subject.objects.get(nickname=nickname))
        records = subject.water_control.to_jsonable(
            start_date=start_date, end_date=end_date
        )
        data = {
            "subject": nickname,
            "implant_weight": subject.implant_weight,
            "records": records,
        }
        serializer = self.serializer_class(data)
        return Response(serializer.data)


class WaterRestrictionList(ListAPIView):
    """
    Lists water restriction.
    """

    queryset = WaterRestriction.objects.all().order_by("-end_time", "-start_time")
    serializer_class = WaterRestrictionListSerializer
    permission_classes = rest_permission_classes()
    filterset_class = WaterRestrictionFilter


class LabLocationList(ListAPIView):
    """
    Lists Lab Location
    """

    queryset = LabLocation.objects.all()
    serializer_class = LabLocationSerializer
    permission_classes = rest_permission_classes()


class LabLocationAPIDetails(RetrieveUpdateAPIView):
    """
    Allows viewing of full detail and deleting a water administration.
    """

    permission_classes = rest_permission_classes()
    serializer_class = LabLocationSerializer
    queryset = LabLocation.objects.all()
    lookup_field = "name"


class SurgeriesList(ListAPIView):
    """
    Lists Surgeries
    """

    queryset = Surgery.objects.all()
    serializer_class = SurgerySerializer
    permission_classes = rest_permission_classes()
