from django.views.generic.list import ListView
from django.db.models.deletion import Collector
from django.utils.safestring import mark_safe
from django.urls import reverse

from datetime import timedelta, date
from operator import itemgetter
import structlog

from ...subjects.models import Subject
from ..models import (
    BaseAction,
    Session,
    WaterRestriction,
)
from .water_control import water_control, to_date

logger = structlog.get_logger("actions.history_views")

def last_monday(reqdate=None):
    reqdate = reqdate or date.today()
    monday = reqdate - timedelta(days=reqdate.weekday())
    assert monday.weekday() == 0
    return monday


def training_days(reqdate=None):
    monday = last_monday(reqdate=reqdate)
    wr = WaterRestriction.objects.filter(
        start_time__isnull=False,
        end_time__isnull=True,
    ).order_by("subject__responsible_user__username", "subject__nickname")
    next_monday = monday + timedelta(days=7)
    for w in wr:
        sessions = Session.objects.filter(subject=w.subject, start_time__gte=monday, start_time__lt=next_monday)
        dates = sorted(set([_[0] for _ in sessions.order_by("start_time").values_list("start_time")]))
        wds = set(date.weekday() for date in dates)
        yield {
            "nickname": w.subject.nickname,
            "username": w.subject.responsible_user.username,
            "training_history_url": reverse("training-history", args=[w.subject.pk]),
            "url": reverse("admin:subjects_subject_change", args=[w.subject.pk]),
            "n_training_days": len(wds),
            "training_ok": len(wds) >= 5,
            "training_days": [wd in wds for wd in range(7)],
        }



class SubjectHistoryListView(ListView):
    template_name = "custom_views/subject_history.html"

    CLASS_FIELDS = {
        "Session": ("number", "n_correct_trials", "n_trials"),
        "Weighing": ("weight",),
        "WaterRestriction": (),
    }

    CLASS_TYPE_FIELD = {
        "Session": "type",
        "WaterRestriction": "water_type",
    }

    def get_context_data(self, **kwargs):
        context = super(SubjectHistoryListView, self).get_context_data(**kwargs)
        subject = Subject.objects.get(pk=self.kwargs["subject_id"])
        context["title"] = mark_safe(
            'Subject history of <a href="%s">%s</a>'
            % (
                reverse("admin:subjects_subject_change", args=[subject.id]),
                subject.nickname,
            )
        )
        context["site_header"] = "Alyx"
        return context

    def get_queryset(self):
        logger.warning(f"Getting queryset of {self.kwargs['subject_id']}")

        subject = Subject.objects.get(pk=self.kwargs["subject_id"])
        logger.warning(f"Subject got {subject}")
        collector = Collector(using="default")
        logger.warning(f"Collector defined queryset of {collector}")
        collector.collect([subject])
        logger.warning("Collector ran")
        out = []

        for model, instance in collector.instances_with_model():
            logger.warning(f"trating instance {instance} of model {model}")
            if model._meta.app_label == "data":
                continue
            if not isinstance(instance, BaseAction):
                continue
            url = reverse(
                "admin:%s_%s_change" % (instance._meta.app_label, instance._meta.model_name),
                args=[instance.id],
            )
            item = {}
            clsname = instance.__class__.__name__
            item["url"] = url
            item["name"] = model.__name__
            item["type"] = getattr(instance, self.CLASS_TYPE_FIELD.get(clsname, ""), None)
            item["date_time"] = instance.start_time
            i = 0
            for n in self.CLASS_FIELDS.get(clsname, ()):
                v = getattr(instance, n, None)
                if v is None:
                    continue
                item["arg%d" % i] = "%s: %s" % (n, v)
                i += 1
            out.append(item)
        out = sorted(out, key=itemgetter("date_time"), reverse=True)
        return out

class WaterHistoryListView(ListView):
    template_name = "custom_views/water_history.html"

    def get_context_data(self, **kwargs):
        context = super(WaterHistoryListView, self).get_context_data(**kwargs)
        subject = Subject.objects.get(pk=self.kwargs["subject_id"])
        context["title"] = mark_safe(
            'Water history of <a href="%s">%s</a>'
            % (
                reverse("admin:subjects_subject_change", args=[subject.id]),
                subject.nickname,
            )
        )
        context["site_header"] = "Alyx"
        url = reverse("weighing-plot", kwargs={"subject_id": subject.id})
        context["plot_url"] = url
        return context

    def get_queryset(self):
        subject = Subject.objects.get(pk=self.kwargs["subject_id"])
        return water_control(subject).to_jsonable()[::-1]

class TrainingHistoryListView(ListView):
    template_name = "custom_views/training_history.html"

    def get_context_data(self, **kwargs):
        context = super(TrainingHistoryListView, self).get_context_data(**kwargs)
        subject = Subject.objects.get(pk=self.kwargs["subject_id"])
        context["title"] = mark_safe(
            'Training history of <a href="%s">%s</a>'
            % (
                reverse("admin:subjects_subject_change", args=[subject.id]),
                subject.nickname,
            )
        )
        context["site_header"] = "Alyx"
        url = reverse("training-perf-plot", kwargs={"subject_id": subject.id})
        context["plot_url"] = url
        return context

    def get_queryset(self):
        subject = Subject.objects.get(pk=self.kwargs["subject_id"])
        return training_control(subject).to_jsonable()[::-1]


class TrainingListView(ListView):
    template_name = "custom_views/training.html"

    def get_context_data(self, **kwargs):
        context = super(TrainingListView, self).get_context_data(**kwargs)
        reqdate = self.kwargs.get("date", None) or date.today().strftime("%Y-%m-%d")
        reqdate = to_date(reqdate)
        monday = last_monday(reqdate=reqdate)
        self.monday = monday
        previous_week = (monday - timedelta(days=7)).strftime("%Y-%m-%d")
        today = (date.today()).strftime("%Y-%m-%d")
        next_week = (monday + timedelta(days=7)).strftime("%Y-%m-%d")
        context["title"] = "Training view for %s" % monday.strftime("%Y-%m-%d")
        context["site_header"] = "Alyx"
        context["prev_url"] = reverse("training", args=[previous_week])
        context["today_url"] = reverse("training", args=[today])
        context["next_url"] = reverse("training", args=[next_week])
        context["wds"] = [(monday + timedelta(days=n)).strftime(r"%a %d/%m/%Y") for n in range(7)]
        context["today"] = date.today().strftime(r"%a %d/%m/%Y")
        return context

    def get_queryset(self):
        yield from training_days(reqdate=self.monday)

