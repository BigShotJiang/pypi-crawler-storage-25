from django.conf.urls import include
from django.urls import path

from . import api as api_views

# register_file = api_views.RegisterFileViewSet.as_view({"post": "create"})

# sync_file_status = api_views.SyncViewSet.as_view({"post": "sync", "get": "sync_status"})

# new_download = api_views.DownloadViewSet.as_view({"post": "create"})

api_urls = [
    path("data-formats", api_views.DataFormatList.as_view(), name="dataformat-list"),
    path(
        "data-formats/<str:name>",
        api_views.DataFormatDetail.as_view(),
        name="dataformat-detail",
    ),
    path(
        "data-repository-type",
        api_views.DataRepositoryTypeList.as_view(),
        name="datarepositorytype-list",
    ),
    path(
        "data-repository-type/<str:name>",
        api_views.DataRepositoryTypeDetail.as_view(),
        name="datarepositorytype-detail",
    ),
    path(
        "data-repository",
        api_views.DataRepositoryList.as_view(),
        name="datarepository-list",
    ),
    path(
        "data-repository/<str:name>",
        api_views.DataRepositoryDetail.as_view(),
        name="datarepository-detail",
    ),
    path("revisions", api_views.RevisionList.as_view(), name="revision-list"),
    path(
        "revisions/<str:name>",
        api_views.RevisionDetail.as_view(),
        name="revision-detail",
    ),
    path("tags", api_views.TagList.as_view(), name="tag-list"),
    path("tags/<uuid:pk>", api_views.TagDetail.as_view(), name="tag-detail"),
    path("datasets", api_views.DatasetList.as_view(), name="dataset-list"),
    path(
        "datasets/<uuid:pk>", api_views.DatasetDetail.as_view(), name="dataset-detail"
    ),
    path("dataset-types", api_views.DatasetTypeList.as_view(), name="datasettype-list"),
    path(
        "dataset-types/<str:name>",
        api_views.DatasetTypeDetail.as_view(),
        name="datasettype-detail",
    ),
    path("downloads", api_views.DownloadList.as_view(), name="download-list"),
    path(
        "downloads/<uuid:pk>",
        api_views.DownloadDetail.as_view(),
        name="download-detail",
    ),
    path("files", api_views.FileRecordList.as_view(), name="filerecord-list"),
    path(
        "files/<uuid:pk>",
        api_views.FileRecordDetail.as_view(),
        name="filerecord-detail",
    ),
    # path("new-download", new_download, name="new-download"),
    # path("register-file", register_file, name="register-file"),
    # path("sync-file-status", sync_file_status, name="sync-file-status"),
]

urlpatterns = [path("api/", include(api_urls))]
