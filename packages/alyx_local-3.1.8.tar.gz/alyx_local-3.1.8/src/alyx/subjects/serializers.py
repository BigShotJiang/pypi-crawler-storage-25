from datetime import datetime

from django.contrib.auth import get_user_model
from drf_spectacular.utils import extend_schema_field
from rest_framework.serializers import (
    CharField,
    ChoiceField,
    CurrentUserDefault,
    HyperlinkedModelSerializer,
    ListField,
    ModelSerializer,
    SerializerMethodField,
    SlugRelatedField,
)

from ..actions.serializers import (
    WaterAdministrationDetailSerializer,
    WeighingDetailSerializer,
)
from ..misc.models import Lab
from .models import (
    Allele,
    Line,
    Litter,
    Project,
    Source,
    Species,
    Strain,
    Subject,
    Zygosity,
)

SUBJECT_LIST_SERIALIZER_FIELDS = (
    "nickname",
    "name",
    "url",
    "id",
    "responsible_user",
    "birth_date",
    "age_weeks",
    "death_date",
    "species",
    "sex",
    "litter",
    "strain",
    "source",
    "line",
    "projects",
    "session_projects",
    "lab",
    "genotype",
    "description",
    "alive",
    "reference_weight",
    "last_water_restriction",
    "expected_water",
    "remaining_water",
)


class _WaterRestrictionBaseSerializer(HyperlinkedModelSerializer):
    def get_expected_water(self, obj: "Subject") -> float:
        return obj.water_control.expected_water()

    def get_remaining_water(self, obj: "Subject") -> float:
        return obj.water_control.remaining_water()

    def get_reference_weight(self, obj: "Subject") -> float:
        return obj.water_control.reference_weight()

    def get_last_water_restriction(self, obj: "Subject") -> datetime | None:
        return obj.water_control.water_restriction_at()

    expected_water = SerializerMethodField()
    remaining_water = SerializerMethodField()
    reference_weight = SerializerMethodField()
    last_water_restriction = SerializerMethodField()


class WaterRestrictedSubjectListSerializer(_WaterRestrictionBaseSerializer):
    class Meta:
        model = Subject
        fields = (
            "name",
            "url",
            "expected_water",
            "remaining_water",
            "reference_weight",
            "last_water_restriction",
        )

        lookup_field = "name"
        extra_kwargs = {"url": {"view_name": "subject-detail", "lookup_field": "name"}}


class ZygosityListSerializer(ModelSerializer):
    ZYGOSITY_TYPES = (
        (0, "Absent"),
        (1, "Heterozygous"),
        (2, "Homozygous"),
        (3, "Present"),
    )

    zygosity = ChoiceField(choices=ZYGOSITY_TYPES)
    allele = SlugRelatedField(
        read_only=False,
        slug_field="name",
        queryset=Allele.objects.all(),
        required=False,
    )

    class Meta:
        model = Zygosity
        fields = ("allele", "zygosity")


class SubjectListSerializer(_WaterRestrictionBaseSerializer):
    genotype = ListField(source="zygosity_strings", required=False)

    responsible_user = SlugRelatedField(
        read_only=False,
        slug_field="username",
        queryset=get_user_model().objects.all(),
        required=False,
        default=CurrentUserDefault(),
    )

    species = SlugRelatedField(
        read_only=False,
        slug_field="name",
        queryset=Species.objects.all(),
        allow_null=True,
        required=False,
    )

    strain = SlugRelatedField(
        read_only=False,
        slug_field="name",
        queryset=Strain.objects.all(),
        allow_null=True,
        required=False,
    )

    line = SlugRelatedField(
        read_only=False,
        slug_field="name",
        queryset=Line.objects.all(),
        allow_null=True,
        required=False,
    )

    litter = SlugRelatedField(
        read_only=False,
        slug_field="name",
        queryset=Litter.objects.all(),
        allow_null=True,
        required=False,
    )

    projects = SlugRelatedField(
        read_only=False,
        slug_field="name",
        queryset=Project.objects.all(),
        many=True,
        required=False,
    )

    # session_projects = SlugRelatedField(
    #     read_only=True,
    #     slug_field="name",
    #     many=True,
    #     required=False,
    # )
    session_projects = SerializerMethodField(read_only=True, required=False)

    source = SlugRelatedField(
        read_only=False,
        slug_field="name",
        queryset=Source.objects.all(),
        allow_null=True,
        required=False,
    )

    lab = SlugRelatedField(
        read_only=False,
        slug_field="name",
        queryset=Lab.objects.all(),
        many=False,
        required=True,
    )

    # @extend_schema_field(ListField(child=CharField()))
    def get_session_projects(self, obj: "Subject") -> list[str]:
        return list(obj.session_projects.values_list("name", flat=True))

    @staticmethod
    def setup_eager_loading(queryset):
        """Perform necessary eager loading of data to avoid horrible performance."""
        queryset = queryset.select_related(
            "responsible_user", "species", "strain", "line", "litter"
        )
        queryset = queryset.prefetch_related("zygosity_set", "zygosity_set__allele")
        return queryset

    class Meta:
        model = Subject
        fields = SUBJECT_LIST_SERIALIZER_FIELDS
        lookup_field = "name"
        extra_kwargs = {"url": {"view_name": "subject-detail", "lookup_field": "name"}}


class SubjectDetailSerializer(SubjectListSerializer, _WaterRestrictionBaseSerializer):
    weighings = WeighingDetailSerializer(many=True, read_only=True)
    water_administrations = WaterAdministrationDetailSerializer(
        many=True, read_only=True
    )
    genotype = ZygosityListSerializer(source="zygosity_set", many=True, read_only=True)

    class Meta:
        model = Subject
        fields = list(SUBJECT_LIST_SERIALIZER_FIELDS)
        fields.extend(["weighings", "water_administrations"])
        lookup_field = "name"
        extra_kwargs = {"url": {"view_name": "subject-detail", "lookup_field": "name"}}


class ProjectSerializer(HyperlinkedModelSerializer):
    users = SlugRelatedField(
        read_only=False,
        slug_field="username",
        queryset=get_user_model().objects.all(),
        many=True,
        required=False,
        default=CurrentUserDefault(),
    )

    class Meta:
        model = Project
        fields = ("name", "description", "users", "json")
        lookup_field = "name"
        extra_kwargs = {"url": {"view_name": "project-detail", "lookup_field": "name"}}
