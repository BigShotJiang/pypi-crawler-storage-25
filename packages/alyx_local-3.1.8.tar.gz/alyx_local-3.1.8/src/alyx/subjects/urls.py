from django.urls import path
from django.conf.urls import include

from .api import (
    SubjectList,
    SubjectDetail,
    ProjectList,
    ProjectDetail,
    WaterRestrictedSubjectList,
)

api_urls = [
    path("projects", ProjectList.as_view(), name="project-list"),
    path("projects/<str:name>", ProjectDetail.as_view(), name="project-detail"),
    path(
        "water-restricted-subjects",
        WaterRestrictedSubjectList.as_view(),
        name="water-restricted-subject-list",
    ),
    path("subjects", SubjectList.as_view(), name="subject-list"),
    path("subjects/<str:name>", SubjectDetail.as_view(), name="subject-detail"),
]

views_urls = [
]

urlpatterns = [
    path("api/", include(api_urls)),
    path("", include(views_urls))
]

