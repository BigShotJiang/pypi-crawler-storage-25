from pathlib import Path

bind = "0.0.0.0:8000"
workers = 3
reload = True
reload_engine = "inotify"
reload_extra_file = [str(dir / file) for dir, folders, files in Path("/app/src").walk() for file in files]
