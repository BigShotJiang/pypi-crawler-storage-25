#!/bin/bash
echo -n "Django version: " && echo -n $(uv run python -m django --version) && echo " is installed"

# pdm install --prod --frozen-lockfile
# uv sync --all-groups

# Collect static files
echo "Collecting static files..."
uv run --frozen alyx manage collectstatic --noinput --clear --verbosity 0

uv run --frozen alyx manage auto_restore --use_settings --migrate_new_db

# Restore mounts
echo "Restoring all mounts if any"
uv run --frozen alyx manage mounts

# Start Gunicorn
echo "Starting Gunicorn to serve django alyx..."
uv run --frozen gunicorn 'alyx.base.wsgi' --config '/app/gunicorn.conf.py'