// selectionStart not changing means Firefox is not performing the default caret-move action
// even though defaultPrevented=false. That almost always means SOME listener is calling
// stopImmediatePropagation + doing something odd, OR the textarea is effectively non-editable
// (readonly/disabled/contenteditable overlay), OR an IME/composition state is interfering.
//
// Next: find any keydown listeners on the textarea/document that run for ArrowUp/Down.
// Use a debugger breakpoint on keydown and capture the call stack of every handler.
//
// This snippet installs a "trap" that logs ALL keydown handlers that run (capture+bubble)
// and also detects readonly/disabled and composition state.

(function diagnoseArrowUpDown() {
  const ta = document.querySelector(".markdownx-editor");
  if (!ta) throw new Error("No .markdownx-editor found");

  console.log("readonly=", ta.readOnly, "disabled=", ta.disabled, "contentEditable=", ta.isContentEditable);

  let composing = false;
  ta.addEventListener("compositionstart", () => (composing = true), true);
  ta.addEventListener("compositionend", () => (composing = false), true);

  const keys = new Set(["ArrowUp", "ArrowDown"]);

  function logEvent(where, phase) {
    return function (e) {
      if (!keys.has(e.key)) return;
      console.log(
        `[${where} ${phase}] key=${e.key} defaultPrevented=${e.defaultPrevented} cancelBubble=${e.cancelBubble} composing=${e.isComposing || composing}`
      );
    };
  }

  // Log at multiple points
  window.addEventListener("keydown", logEvent("WIN", "CAPTURE"), true);
  document.addEventListener("keydown", logEvent("DOC", "CAPTURE"), true);
  ta.addEventListener("keydown", logEvent("TA", "CAPTURE"), true);

  ta.addEventListener("keydown", (e) => {
    if (!keys.has(e.key)) return;

    const before = ta.selectionStart;

    // After all handlers + default action
    setTimeout(() => {
      const after = ta.selectionStart;
      console.log(`[AFTER] key=${e.key} selectionStart ${before} -> ${after}`);
      if (after === before) {
        console.log(
          "No caret move. Next step: enable DevTools Event Listener Breakpoints -> Keyboard -> keydown,\n" +
          "press ArrowUp/Down, and inspect the call stack of each handler. Look for code that calls:\n" +
          " - e.preventDefault()\n" +
          " - e.stopImmediatePropagation()\n" +
          " - textarea.setSelectionRange(...)\n" +
          " - textarea.blur()/focus()"
        );
      }
    }, 0);
  }, false);

  // Monkey-patch stopImmediatePropagation to catch who calls it during ArrowUp/Down
  const origSIP = Event.prototype.stopImmediatePropagation;
  Event.prototype.stopImmediatePropagation = function () {
    if (this && this.type === "keydown" && keys.has(this.key)) {
      console.log("[stopImmediatePropagation CALLED] key=", this.key);
      console.log(new Error("stack").stack);
    }
    return origSIP.apply(this, arguments);
  };

  // Monkey-patch preventDefault too (in case some handler calls it but you didn't see it)
  const origPD = Event.prototype.preventDefault;
  Event.prototype.preventDefault = function () {
    if (this && this.type === "keydown" && keys.has(this.key)) {
      console.log("[preventDefault CALLED] key=", this.key);
      console.log(new Error("stack").stack);
    }
    return origPD.apply(this, arguments);
  };

  // Monkey-patch setSelectionRange to see if someone forces selection back
  const origSSR = HTMLTextAreaElement.prototype.setSelectionRange;
  HTMLTextAreaElement.prototype.setSelectionRange = function (s, e, dir) {
    if (this === ta) {
      console.log("[setSelectionRange on TA]", s, e, dir);
      console.log(new Error("stack").stack);
    }
    return origSSR.call(this, s, e, dir);
  };

  console.log("Diagnostics installed. Press ArrowUp/Down. If any code blocks/mangles it, you'll get a stack trace.");
})();

// If this produces NO preventDefault/stopImmediatePropagation/setSelectionRange logs,
// then it's likely a Firefox/browser-level feature (Caret Browsing F7, extension, OS keybinding).
// Test in a clean Firefox profile / safe mode, and toggle F7.
