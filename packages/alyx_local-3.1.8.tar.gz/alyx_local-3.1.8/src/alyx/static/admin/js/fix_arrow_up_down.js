// Problem: a jQuery keydown handler on your admin change page IS calling preventDefault()
// for ArrowUp/ArrowDown (see stack: .../change/:5566:7 and .../change/:5550:13).
// That blocks the textarea's default vertical caret movement.
//
// Fix: remove/limit that handler so it doesn't run when focus is inside a textarea/input,
// or at least don't preventDefault for ArrowUp/Down in editable fields.
//
// Paste this in the console to (a) confirm which handler, and (b) hot-fix by stopping it
// only when the target is an editable control.

(function patchArrowKeyPreventDefaultInInputs() {
  const keys = new Set(["ArrowUp", "ArrowDown"]);

  // Capture-phase guard: if some bubble-phase handler calls preventDefault(),
  // we can't "undo" it, but we CAN stop that handler from running by stopping propagation
  // early when the event originates from an editable element.
  document.addEventListener(
    "keydown",
    function (e) {
      if (!keys.has(e.key)) return;

      const t = e.target;
      const isEditable =
        t &&
        (t.tagName === "TEXTAREA" ||
          (t.tagName === "INPUT" && !/^(button|submit|checkbox|radio|file|range|color|hidden)$/i.test(t.type)) ||
          t.isContentEditable);

      if (!isEditable) return;

      // Let the browser handle caret movement; prevent global hotkeys from interfering.
      e.stopImmediatePropagation();
      // DO NOT call preventDefault here.
      // This ensures the offending jQuery handler (on document/body) won't run.
      console.log("[patched] allowed", e.key, "for", t.tagName, t.id || t.name || "");
    },
    true // capture
  );

  console.log("Patch installed. ArrowUp/ArrowDown should work inside textarea now.");
})();

// Permanent fix: open view-source / your bundled JS and locate the code at /change/:5550 and :5566.
// It will look like $(document).on('keydown', ...) or similar.
// Wrap it with a guard:
//
// if ($(e.target).is('textarea, input, [contenteditable=true]')) return;
//
// or only preventDefault when NOT in an editable field.
