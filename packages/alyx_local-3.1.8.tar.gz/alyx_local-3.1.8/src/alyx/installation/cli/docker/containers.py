from rich_click import Choice, Context, argument, group, option, pass_context, secho

from ...implementation.configuration import DockerConfigInstaller
from ...implementation.docker.containers import (
    EXISTING_CONTAINER_NAMES,
    container_action,
    container_interactive_shell,
)

###### Individual container related commands ######
# they require a container to be selected


@group("container")
def container_command_group():
    """Start, stop, interact with containers"""


@container_command_group.command("start")
@argument(
    "container_name",
    required=True,
    default=None,
    type=Choice(EXISTING_CONTAINER_NAMES),
)
def start_container_command(container_name: str):
    """Start an alyx docker container that have already been built.
    (starts if stopped, does nothing if it is currentely running)"""
    container_action(container_name, action="start")


@container_command_group.command("restart")
@argument(
    "container_name",
    required=True,
    default=None,
    type=Choice(EXISTING_CONTAINER_NAMES),
)
def restart_container_command(container_name: str):
    """Restarts alyx docker containers that have already been built.
    (starts if stopped, or restart if they are currentely running)"""
    container_action(container_name, action="restart")


@container_command_group.command("stop")
@argument(
    "container_name",
    required=True,
    default=None,
    type=Choice(EXISTING_CONTAINER_NAMES),
)
def stop_container_command(container_name: str):
    """Start an alyx docker container that have already been built.
    (starts if stopped, does nothing if it is currentely running)"""
    container_action(container_name, action="stop")


@container_command_group.command(
    "build", context_settings=dict(ignore_unknown_options=True, allow_extra_args=True)
)
@argument(
    "container_name",
    required=True,
    default=None,
    type=Choice(EXISTING_CONTAINER_NAMES),
)
@option(
    "--no-config-update",
    is_flag=True,
    help="Don't make sure the config is up-to-date and do not update it if not the case, before building.",
)
@pass_context
def build_container_command(
    context: Context, container_name: str, no_config_update: bool = False
):
    """Build a specific container"""
    if not no_config_update:
        DockerConfigInstaller.default_installer().run()

    container_action(container_name, action="build", fresh=False)


@container_command_group.command(
    "rebuild", context_settings=dict(ignore_unknown_options=True, allow_extra_args=True)
)
@argument(
    "container_name",
    required=True,
    default=None,
    type=Choice(EXISTING_CONTAINER_NAMES),
)
@option(
    "--no-config-update",
    is_flag=True,
    help="Don't make sure the config is up-to-date and do not update it if not the case, before building.",
)
@pass_context
def rebuild_container_command(
    context: Context, container_name: str, no_config_update: bool = False
):
    """Builds a specific container, deleting it first if it exists."""
    if not no_config_update:
        DockerConfigInstaller.default_installer().run()

    container_action(container_name, action="delete", fresh=False)
    container_action(container_name, action="build", fresh=True)


@container_command_group.command("shell")
@argument(
    "container_name",
    required=False,
    default="django_server",
    type=Choice(EXISTING_CONTAINER_NAMES),
)
def interactive_shell_command(container_name: str = "django_server"):
    """Interact with a specified Docker container by opening a bash shell.

    This function executes a command to start an interactive bash shell in the
    given Docker container. It uses the `docker exec` command to attach to the
    container's terminal.

    The default argument given after the interact command, if left blank, is resolved to "django_server".

    You can interact with other containers of the alyx app using one of "django_server", "nginx_server",
     "celery_server", "postgres_db", "pgadmin" or "rabbitmq" as argument.
    """
    container_interactive_shell(container_name)


@container_command_group.command("list")
def list_containers_command():
    """List containers names associated with alyx."""
    # TODO make a table where for each container, docker checks if it actually exists
    secho(EXISTING_CONTAINER_NAMES)
