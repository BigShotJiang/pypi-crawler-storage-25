import shlex
import subprocess
from typing import Optional

from rich_click import Choice, Context, argument, group, option, pass_context, secho

from ...implementation.configuration import DockerConfigInstaller
from ...implementation.docker.containers import (
    EXISTING_CONTAINER_NAMES,
    container_action,
)
from ...implementation.docker.project import build_project, delete_project
from ...implementation.utils import PROJECT_NAME

###### Containers related commands ######
# they work at project level, and don't require a container to be selected


@group("containers")
def containers_command_group():
    """Start, stop, interact with containers"""


@containers_command_group.command(
    "stop", context_settings=dict(ignore_unknown_options=True, allow_extra_args=True)
)
def stop_all_containers_command():
    container_action(None, action="stop")


@containers_command_group.command(
    "start", context_settings=dict(ignore_unknown_options=True, allow_extra_args=True)
)
def start_all_containers_command():
    container_action(None, action="start")


@containers_command_group.command(
    "build", context_settings=dict(ignore_unknown_options=True, allow_extra_args=True)
)
@option(
    "--fast",
    is_flag=True,
    help="Fasten up the --fresh flag, by not removing the old built-images. "
    "If --fast flag is added without the --fresh flag, --fast is ignored.",
)
@option(
    "--fresh",
    "--refresh",
    is_flag=True,
    help="Remove old built-images, containers, and volumes, then rebuild the containers",
)
@option(
    "--update-config",
    is_flag=True,
    help="Make sure the config is up-to-date and update it if not the case, before building.",
)
@argument(
    "container_name",
    required=False,
    default=None,
    type=Choice(EXISTING_CONTAINER_NAMES),
)
@pass_context
def build_all_containers_command(
    context: Context,
    container_name: Optional[str] = None,
    fast: bool = False,
    fresh: bool = False,
    update_config: bool = False,
):
    """Build new images and then starts the containers for the alyx-local docker project"""

    # shlex.quote(arg)
    build_project(*context.args, fresh=fresh, update_config=update_config)


@containers_command_group.command("delete")
@option("--containers", is_flag=True, help="Deletes docker containers.")
@option(
    "--volumes",
    is_flag=True,
    help="Deletes docker volumes (requires deleting containers).",
)
@option(
    "--images",
    is_flag=True,
    help="Deletes docker images (requires deleting the containers).",
)
@option(
    "--cache", is_flag=True, help="Deletes docker build-cache too after the operation."
)
@option("--all", is_flag=True, help="Deletes all of the above.")
@pass_context
def delete_all_containers_command(
    context: Context,
    volumes: bool = False,
    images: bool = False,
    cache: bool = False,
    orphans: bool = False,
    all: bool = False,
):
    """Stop and remove elements for this project : containers (always), built-images, build-cache, volumes, and networks,
    depending on the arguments provided"""
    if not any([volumes, images, cache, all]):
        # No flag has been set to true, we don't delete anything, but send a user warning
        # to inform that the command requires flag to be used
        secho(
            "The delete command requires at least one flag to be set, to know what to delete.",
            fg="red",
        )
        secho(context.command.get_help(context))
        return

    if all:
        volumes, images, orphans, cache = True, True, True, True

    delete_project(delete_volumes=volumes, delete_images=images, clean_orphans=orphans)

    if cache:
        delete_build_cache()
