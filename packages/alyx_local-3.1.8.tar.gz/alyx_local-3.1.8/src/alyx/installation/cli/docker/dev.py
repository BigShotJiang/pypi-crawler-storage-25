from rich_click import Choice, Context, argument, group, option, pass_context, secho

from ...implementation.docker.dev import build_docker_django_base_image


@group("dev")
def dev_command_group():
    """Perform advanced actions (for developpers only)"""


@dev_command_group.command("build-django-base-image")
def build_django_base_image_command():
    build_docker_django_base_image()
