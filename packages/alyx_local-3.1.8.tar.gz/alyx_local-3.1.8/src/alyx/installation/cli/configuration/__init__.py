from rich_click import group
from .installation import installation_command_group
from .keywords import keywords_command_group
from .folders import folders_command_group

@group("configuration")
def configuration_command_group():
    """ Create and edit the configuration necessary for docker builds.

    Create, and edit the configuration keywords, injects and writes template files, 
    and verifies the already existing templated files, for the docker build of the 
    alyx services, to work as you inted it.
    To configure your user installation of alyx, 
    use the `alyx configuration installation create` subcommand."""

configuration_command_group.add_command(installation_command_group)
configuration_command_group.add_command(keywords_command_group)
configuration_command_group.add_command(folders_command_group)