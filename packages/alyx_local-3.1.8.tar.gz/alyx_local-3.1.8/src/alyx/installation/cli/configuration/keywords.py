from rich_click import group, option, argument, get_current_context, Context

from ...implementation.configuration import DockerConfigInstaller
from .utils import rich_valid_table

from typing import cast

@group("keywords")
def keywords_command_group():
    """Create, and edit necessary files and variables for a sucessfull build of the docker containers"""


@keywords_command_group.command("set")
@argument(
    "values",
    nargs=-1,
    help="Force resetting of one or multiple values provided after this argument.",
)
@option(
    "-i",
    "--install",
    is_flag=True,
    help="Perform template injection after setting the new values",
)
@option("-v", "--verbose", is_flag=True, help="Increase output verbosity")
def set_keywords_commands(values: list[str] = [], verbose : bool = False, install : bool = False):
    """Sets one or multiple values, specifying wich ones should be re-prompted for."""
    
    reset_values = {}
    for text in values :
        key, value = text.split('=')
        reset_values[key.strip().upper()] = value.strip()
    
    params = cast(Context, get_current_context(False)).params
    params["reset_values"] = reset_values

    installer = DockerConfigInstaller.from_cli_arguments(params)
    installer.keywords_store.validate_keywords_list().populate_set_values()

    if install :
        installer.run()

@keywords_command_group.command("create")
def create_keywords_command():
    DockerConfigInstaller().populate_keywords_store()

    
@keywords_command_group.command("list")
def list_keywords_command():
    
    installation = DockerConfigInstaller() 
    keywords = installation.keywords_store.validate_keywords_list().keywords_list
    installation.renderer.show_panel(*sorted(keywords), title="Keywords" )

@keywords_command_group.command("check")
def check_keywords_command():
    """Verifies wich keywords are yet unset"""

    installation = DockerConfigInstaller()
    key_validity = installation.get_keywords_config_status()
    missing_count = list(key_validity.values()).count(False)

    table = rich_valid_table(key_validity, title="Keywords defined in config")
    installation.renderer.print(table)

    if missing_count :
        installation.renderer.print(f"❌ Your config misses {missing_count} keys", style = "yellow")
    else :
        installation.renderer.print("✅ Your config is fully defined", style = "green")
