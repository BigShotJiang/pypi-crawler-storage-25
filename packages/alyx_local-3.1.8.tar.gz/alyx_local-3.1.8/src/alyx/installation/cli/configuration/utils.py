from typing import Any

from rich import box
from rich.table import Table


def rich_valid_table(
    valid_dict: dict[str, bool], title: str = "", column_titles=["Keyword", "Defined"]
):

    table = Table(title=title, title_style="bold blue", box=box.ROUNDED, style="blue")
    table.add_column(
        column_titles[0], justify="left", no_wrap=True, header_style="blue"
    )
    table.add_column(column_titles[1], justify="center", header_style="blue")

    for keyword, exists in valid_dict.items():
        table.add_row(
            keyword,
            "✅" if exists else "❌",
            style="black on dark_sea_green2" if exists else "black on light_coral",
        )

    return table


def rich_value_table(
    rows_dict: list[dict[str, Any]],
    title: str = "",
    column_titles=["Keyword", "Defined", "Values"],
):

    table = Table(title=title, title_style="bold blue", box=box.ROUNDED, style="blue")
    table.add_column(
        column_titles[0], justify="left", no_wrap=True, header_style="blue"
    )
    table.add_column(
        column_titles[1], justify="center", no_wrap=True, header_style="blue"
    )
    table.add_column(
        column_titles[2], justify="center", no_wrap=True, header_style="blue"
    )

    for row in rows_dict:
        table.add_row(
            row["key"],
            row["valid"],
            row["value"],
            style="black on dark_sea_green2"
            if row["valid"]
            else "black on light_coral",
        )

    return table
