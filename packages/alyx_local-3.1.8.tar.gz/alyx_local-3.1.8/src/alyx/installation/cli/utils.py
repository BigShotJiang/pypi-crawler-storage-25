from typing import cast

from rich_click import Context, command, get_current_context, group, option, secho

from ..implementation.configuration import DockerConfigInstaller
from ..implementation.docker.containers import container_action
from ..implementation.docker.utils import (
    EXISTING_CONTAINER_NAMES,
    EXISTING_VOLUME_NAMES,
    clean_docker_build_cache,
)
from ..implementation.docker.volumes import volume_action
from ..implementation.utils import copy_last_outdated_save


@command("launch")
@option(
    "--noinput",
    is_flag=True,
    help="Runs the configuration in no input mode, meaning that all operations that normally ask the user for "
    "an input will auto-complete, using default values for usernames and generated ones for passwords.",
)
def launch_command(noinput: bool = False):
    """Combination of other subcommands, allowing you to launch alyx in one go.

    Under the hood it does for configure your alyx install :
     - create user config (if not existing)
     - verify configuration (if already existing)
     - applies configuration (if changes are needed)

    Then starts the docker containers :
     - build docker images, volumes and containers, aggregating the logs of multiple services
        in the current terminal for easy debugging
     - start containers
    """

    params = cast(Context, get_current_context(False)).params

    container_action(None, action="stop")
    (
        DockerConfigInstaller.from_cli_arguments(
            params, copy_ressources=True, create_folders=True
        ).run()
    )
    container_action(None, action="build", verbose=True)


@command("uninstall")
@option(
    "--remove-data/--keep-data",
    default=False,
    help="Add this flag if data "
    "folder containing database backups, uploads and logs, should also be deleted.",
)
@option(
    "--remove-config/--keep-config",
    default=False,
    help="Add this flag to chose wether "
    "to also remove the config.json file, or to keep it.",
)
@option(
    "-y",
    "--yes",
    is_flag=True,
    help="Confirms deleting without asking through a prompt",
)
def uninstall_command(
    remove_data: bool = False, remove_config: bool = False, yes: bool = False
):
    """Uninstalls all (or almost all, depending on your flags) the
    items that got installed for alyx to be built.

    By default, it removes the docker-build folder (where the template injected files,
    obtained after running `alyx configuration installation create`)
    """

    installer = DockerConfigInstaller()

    # ask for confirmation(s) if needed
    if not yes:
        yes = installer.renderer.confirm(
            "Are you sure you want to uninstall the "
            "entire alyx configuration keywords file, the injectd templated files ? "
            f"(The `source_package_path` folder located at {installer.source_package_path} "
            "from wich this code is running wil *NOT* be deleted)",
            manager=installer,
        )
        if yes and remove_data:
            yes = installer.renderer.confirm(
                "Are you sure you also want to delete the data folder "
                f" at {installer.data_path}, containing your database backups, "
                "uploaded files and django logs ?",
                manager=installer,
            )
        if yes and remove_config:
            yes = installer.renderer.confirm(
                "Are you sure you also want to delete the config file "
                f" at {installer.config_file_path}, containing your user defined "
                "keywords and values ?",
                manager=installer,
            )

    if not yes:
        secho("Aborting")
        return

    # Remove the docker build folder
    installer.delete_folder("docker_build_path", confirm=True)

    # Remove the config file
    if remove_config:
        if installer.config_file_path.is_file():
            installer.config_file_path.unlink()
            installer.renderer.print(
                f"Removed user config file at {installer.config_file_path}", style="red"
            )
        else:
            installer.renderer.print(
                f"User config file at {installer.config_file_path} "
                "already doesn't exist",
                style="yellow",
            )

    # Remove the data folder
    if remove_data:
        installer.delete_folder("data_path", confirm=True)

    # Stop and remove docker containers
    for container in EXISTING_CONTAINER_NAMES:
        container_action(container, "stop")
        container_action(container, "delete")

    # Stop and remove docker volumnes
    for volume in EXISTING_VOLUME_NAMES:
        volume_action(volume, "delete")

    # Stop and remove docker build cache
    clean_docker_build_cache(confirm=True)


@group("utils")
def utils_command_group():
    """Utility functions for various operations.

    This module contains a collection of utility functions that can be
    used across different parts of the application.
    """


@utils_command_group.command("copy-last-outdated-dump")
def copy_last_outdated_save_command():
    copy_last_outdated_save()
