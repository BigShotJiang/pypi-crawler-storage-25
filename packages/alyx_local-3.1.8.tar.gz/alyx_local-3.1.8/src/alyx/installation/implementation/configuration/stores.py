import json
from rich.text import Text

from .files import TemplatedFile
from ..utils import rich_to_ansi

from typing import Callable, Set, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .installers import Installer


class KeywordsStore(dict):
    filename = "input_fields.json"
    populated = False
    loaded = False

    def __init__(self, *args, manager: "Installer", **kwargs):
        """Initialize the class with a manager.

        Args:
            *args: Variable length argument list for the superclass initialization.
            manager (Installation): An instance of the Installation class that manages this instance.
            **kwargs: Variable length keyword argument list for the superclass initialization.
        """
        super().__init__(*args, **kwargs)
        self.manager = manager

    @property
    def path(self):
        """Returns the full path to the configuration file.

        This method constructs the full path by combining the configuration
        directory path managed by the manager with the filename of the
        configuration file.

        Returns:
            Path: The full path to the configuration file.
        """
        return self.manager.appdata_path / self.filename

    def __setitem__(self, key, value):
        """Sets the value for a given key in the object and saves the state.

        Args:
            key: The key for which the value is to be set.
            value: The value to be associated with the key.

        This method overrides the default behavior of setting an item by calling
        the superclass's __setitem__ method and then saving the current state
        of the object.
        """
        super().__setitem__(key, value)
        self.save()

    def __getitem__(self, key) -> str:
        return self.get_or_define_value(key)


    def get_or_define_value(self, key : str) -> str :
        """Retrieve an item from the KeywordsStore.

        This method overrides the __getitem__ method to fetch a keyword from the
        KeywordsStore. If the manager is in reconfiguration mode or the key is not
        present, it loads the necessary data and retrieves the value using a getter
        function.

        Args:
            key (str): The key for the item to retrieve from the KeywordsStore.

        Returns:
            The value associated with the specified key.

        Raises:
            KeyError: If the key is not found in the KeywordsStore after attempting
            to retrieve it.

        Notes:
            This method logs a comment indicating the retrieval of the keyword and
            the current state of the KeywordsStore.
        """

        # loads keywords from the json file if neve done on that instance.
        # then populate the current key if it is missing
        if not self.loaded:
            self.load()

        self.update_value_if_needed(key)
        return super().__getitem__(key)
    
    def directly_set_value(self, key : str, value : Any):

        requirements = getattr(self.get_keyword_getter(key), "requirements", [])

        if len(requirements):
            raise ValueError(f"The key {key} is defined as depending on some requirements, "
            "thus, it's value directely depends on these keys and you cannot set it.")
        # key is in the "reset_values" dictionnary, we set it's value
        # from this dictionnary. (set by user when calling the manager)
        self.__setitem__(key, self.manager.reset_values[key])
        self.manager.renderer.print(f"Keyword {key} 's value has been set")

    def update_value_if_needed(self, key : str):
        """Checks if a value is present in the current dict instance, for the given key.
        If not, it will try to assign it from the associated getter function, 
        defined in the installation manager.
        It will also decide wether to "overrride" a value that could be currentely present 
        in the dictionnary or the value that would be provided by the getter value,
        if the user set a mapping of key:values with the argument "reset_values" in the 
        installation manager. Lastly, if a key depends on other keys for it's value, this function
        will recursively (if dependancies have dependancies themselves) update the values of the 
        dependancies, then get its's value for the current key, to make sure it's value
        is up to date with the dependanciy mechanism. Be carefull for dependancies loops while writing
        with getter depends on wich one, in your installation manager, as they are not verified in the
        current implementation of the code.
        """
        
        if not self.should_update_key(key):
            return

        getter = self.get_keyword_getter(key)
        requirements = getattr(getter, "requirements", [])
         
        # populate the getter's requirements before acessing
        # the getter's value, if any requirement is present
        for requirement in requirements :
            # somewhat recursive, using get_or_define_value again on another key
            self.get_or_define_value(requirement) 

        value = getter()
        self.__setitem__(key, value)

    def should_update_key(self, key) -> bool:

        if self.manager.config_frozen :
            return False

        requirements = getattr(self.get_keyword_getter(key), "requirements", [])

        key_exists = key in self.keys()
        key_has_requirements = bool(requirements)

        should_update = ( # we update if :
            not key_exists or ( # key not in the dictionnary yet
                not self.populated and ( # if we didn't finished running self.populate() yet
                    self.manager.reconfigure or # we force reconfiguration of all keys
                    key_has_requirements) # the key depends on requirements
                )
            )
        
        return should_update

    def load(self, key=None) -> "KeywordsStore":
        """Load data from a JSON file into the object.

        This method reads a JSON file from the specified path and loads its contents into the object.
        If a specific key is provided, only the value associated with that key will be loaded.
        If the key is not found or if no key is specified, all key-value pairs from the JSON file will be loaded.

        Args:
            key (str, optional): The specific key to load from the JSON file.
                                 If None, all key-value pairs will be loaded.

        Returns:
            None: This method does not return a value.

        Raises:
            FileNotFoundError: If the specified path does not point to a valid file.
        """
        if not self.path.is_file():
            return self
        with open(self.path, "r") as f:
            fields: dict[str, str] = json.load(f)
        for loaded_key, value in fields.items():
            if key is None or loaded_key == key:
                super().__setitem__(loaded_key, value)
        
        return self

    def save(self) -> "KeywordsStore":
        """Saves the current object state to a JSON file.

        This method creates the necessary parent directories for the file if they do not exist,
        and then writes the object's dictionary representation to the specified path in JSON format
        with an indentation of 4 spaces.

        Attributes:
            path (Path): The file path where the object state will be saved.

        Raises:
            IOError: If there is an error writing to the file.
        """
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "w") as f:
            json.dump(dict(self), f, indent=4, sort_keys=True)

        return self

    def get_keyword_getter(self, keyword) -> Callable[..., str]:
        """Retrieves a getter method for a specified keyword from the manager.

        This function looks for a method in the manager associated with the given keyword.
        If the method is not found, it raises a ValueError.

        Args:
            keyword (str): The name of the keyword for which to retrieve the getter method.

        Returns:
            Callable[..., str]: The getter method associated with the specified keyword.

        Raises:
            ValueError: If no getter method is configured for the specified keyword.
        """
        getter = getattr(self.manager, keyword, None)
        if getter is None:
            raise ValueError(
                f"You didn't configured a getter method for the variable {keyword}"
            )
        return getter

    @property
    def keywords_list(self) -> Set[str]:
        
        keywords = [
            keyword
            for container in self.manager.containers
            for file in container.files
            if isinstance(file, TemplatedFile)
            for keyword in file.keywords
        ]
        keywords.extend(
            [
                keyword
                for file in self.manager.files
                if isinstance(file, TemplatedFile)
                for keyword in file.keywords
            ]
        )
        return set(keywords)

    def validate_keywords_list(self) -> "KeywordsStore":
        """Only verifies that the kewords declared in the m-> "KeywordsStore":anager's containers, 
        manager files and container files, have configured getter methods, and that 
        the keywords specified in the reset values dictionnary, have a corresponding
        keyword getter defined in the manager.
        """
        for keyword in self.keywords_list:
            if not hasattr(self.manager, keyword):
                raise ValueError(
                    f"You didn't configured a getter method for the variable {keyword}"
                )
        for keyword in self.manager.reset_values.keys():
            if not hasattr(self.manager, keyword):
                raise ValueError(
                    rich_to_ansi(Text("The variable ",style="red")
                    .append(keyword, style="yellow")
                    .append(" doesn't exist and cannot be reset.") 
                    ))

        return self

    def populate(self) -> "KeywordsStore":
        """Populates the keyword store, by trying to access (getitem) the value of each of the 
        keywords found in the files, and containers templates.
        """

        # First pass for setting values if any 
        self.populate_set_values()

        if self.manager.config_frozen :
            return self

        for keyword in sorted(self.keywords_list):
            self.get_or_define_value(keyword)

        # We finished populating, now we set reset_values to an empty dict, 
        # and populated Flag to True to make sure we don't forcefully update 
        # values over and over each time they are used somewhere in the installation
        # process
        self.populated = True

        return self

    def populate_set_values(self) -> "KeywordsStore":
        """Sets arguments to config (saved them in config file) from instalaltion manager's
        reset_values attribute, if any.
        """

        # setting values from reset_values argument, if any 
        for keyword, value in self.manager.reset_values.items():
            self.directly_set_value(keyword, value)

        # We finished populating, now we set reset_values to an empty dict, 
        self.manager.reset_values = {}

        return self