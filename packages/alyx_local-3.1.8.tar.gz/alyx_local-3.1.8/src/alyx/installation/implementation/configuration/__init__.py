import shutil
from pathlib import Path
from socket import gethostname

from tzlocal import get_localzone

from .containers import Container
from .files import TemplatedFile
from .installers import Installer, ressource_copy_function


class DjangoServer(Container):
    container_name = "django_server"

    class DjangoSettingsFile(TemplatedFile):
        filename = "custom_settings.py"
        keywords = [
            "DJANGO_SECRET_KEY",
            "DB_BACKUP_HOSTNAME",
            "TIMEZONE",
            "MACHINE_ALLOWED_HOSTS",
            "MACHINE_CSRF_TRUSTED_ORIGINS",
            "DJANGO_DEBUG_MODE",
            "AUTORESTORE_DJANGO_ON_STARTUP",
        ]

    class DjangoEntrypoint(TemplatedFile):
        filename = "entrypoint.sh"

    class DjangoDockerFile(TemplatedFile):
        filename = "Dockerfile"
        keywords = [
            "PERMISSIONED_USERNAME",
            "PERMISSIONED_GROUPNAME",
            "PERMISSIONED_UID",
            "PERMISSIONED_GID",
        ]

    class GunicornConfig(TemplatedFile):
        filename = "gunicorn.conf.py"

    files_classes = [
        DjangoSettingsFile,
        DjangoEntrypoint,
        GunicornConfig,
        DjangoDockerFile,
    ]


class NginxServer(Container):
    container_name = "nginx_server"

    class NginxConfFile(TemplatedFile):
        filename = "nginx.conf"
        keywords = ["NGINX_OUT_PORT"]

    class NginxError502(TemplatedFile):
        filename = "502.html"

    files_classes = [NginxConfFile, NginxError502]


class RabbitMQ(Container):
    container_name = "rabbitmq"

    class RabbitmqConfFile(TemplatedFile):
        filename = "rabbitmq.conf"
        keywords = ["RABBITMQ_USER", "RABBITMQ_PASSWORD"]

    files_classes = [RabbitmqConfFile]


class PostgresDB(Container):
    container_name = "postgres_db"

    class DbPasswordFile(TemplatedFile):
        filename = "db-secure-password"
        keywords = ["POSTGRES_DB_PASSWORD"]

    files_classes = [DbPasswordFile]


class PgAdmin(Container):
    container_name = "pgadmin"

    class ServersJsonFile(TemplatedFile):
        filename = "servers.json"
        keywords = ["POSTGRES_DB_USERNAME"]

    class PgadminEnvFile(TemplatedFile):
        filename = "pgadmin.env"
        keywords = ["PGADMIN_DEFAULT_EMAIL", "PGADMIN_DEFAULT_PASSWORD"]

    files_classes = [PgadminEnvFile, ServersJsonFile]


class CeleryServer(Container):
    container_name = "celery_server"

    class CeleryEnvFile(TemplatedFile):
        filename = "celery.env"
        keywords = ["RABBITMQ_USER", "RABBITMQ_PASSWORD"]

    files_classes = [CeleryEnvFile]


class ComposeYamlFile(TemplatedFile):
    source_file = "./ressources/docker/compose.yaml"
    path = "./compose.yaml"
    keywords = [
        "RABBITMQ_OUT_PORT",
        "NGINX_OUT_PORT",
        "DJANGO_DATA_PATH",
        "ALYX_SRC_PATH",
        "USE_RABBITMQ_SERVICE",
        "USE_CELERY_SERVICE",
        "USE_PGADMIN_SERVICE",
        "DEV_COMPLETE_DJANGO_BUILD",
        "PERMISSIONED_USERNAME",
        "PERMISSIONED_GROUPNAME",
        "PERMISSIONED_UID",
        "PERMISSIONED_GID",
    ]


class PyprojectToml(TemplatedFile):
    source_file = "./ressources/pyproject.toml"
    path = "./pyproject.toml"
    silent_checks = True


class UVLock(TemplatedFile):
    source_file = "./ressources/uv.lock"
    path = "./uv.lock"
    silent_checks = True


class DockerConfigInstaller(Installer):
    # registers these containers for the installation
    containers_classes = [
        DjangoServer,
        NginxServer,
        PostgresDB,
        PgAdmin,
        RabbitMQ,
        CeleryServer,
    ]
    # registers these files (not linked to a specific container) for the installation
    files_classes = [ComposeYamlFile, PyprojectToml, UVLock]

    def DEV_COMPLETE_DJANGO_BUILD(self):
        """Wether to use the pre-built django image or to build the complete image.
        This is indended for dev only, and can only be activated to True with
        `uv run alyx configuration keywords set DEV_COMPLETE_DJANGO_BUILD=True`
        or by editing the input_fields.json file.
        """
        return False

    def USE_RABBITMQ_SERVICE(self):
        return self.renderer.confirm(
            "Do you want to use the rabbitmq service "
            "(message queue for taks automation, advanced users/installations)",
            self,
            default=False,
        )

    def USE_CELERY_SERVICE(self):
        return self.renderer.confirm(
            "Do you want to use the celery service "
            "(webinterface to manage task queues requests, "
            "from the celery package (using rabbitmq), advanced "
            "users/installations only)",
            self,
            default=False,
        )

    def USE_PGADMIN_SERVICE(self):
        return self.renderer.confirm(
            "Do you want to use the pgadmin service "
            "(webinterface to manage the postgres server. "
            "Advances users/installation only)",
            self,
            default=False,
        )

    def DOCKER_BUILD_PATH(self):
        return str(self.appdata_path / "docker_build")

    def DJANGO_DATA_PATH(self):
        return str(self.appdata_path / "data")

    def ALYX_SRC_PATH(self):
        return str(self.source_package_path)

    def POSTGRES_DB_USERNAME(self):
        return "postgres"

    def POSTGRES_DB_PASSWORD(self):
        return self.renderer.ask(
            "Please enter a password for securing the postgresql database",
            self,
            default=self.generate_password(
                20, alphanum=True
            ),  # no special chars as they cause issues with the connection with pg_dumb through dbbackup
            password_mode=True,
        )

    def RABBITMQ_USER(self):
        username = self.renderer.ask(
            "Please enter an Username for securing the rabbitmq database",
            self,
            default="username",
        )
        return username

    def RABBITMQ_PASSWORD(self):
        password = self.renderer.ask(
            "Please enter a Password for securing the rabbitmq database",
            self,
            default=self.generate_password(20, alphanum=True),
            password_mode=True,
        )
        return password

    def PGADMIN_DEFAULT_EMAIL(self):
        return "admin@admin.com"

    def PGADMIN_DEFAULT_PASSWORD(self):
        return self.renderer.ask(
            "Please enter a password for securing the pgadmin web interface",
            self,
            default=self.generate_password(20, alphanum=True),
            password_mode=True,
        )

    def DJANGO_SECRET_KEY(self):
        return self.generate_password()

    def DB_BACKUP_HOSTNAME(self):
        return gethostname()

    def TIMEZONE(self):
        return get_localzone().key

    def MACHINE_ALLOWED_HOSTS(self):
        input_value = self.renderer.ask(
            "Please specify a set of addresses (example localhost, 127.0.0.1) that will be used to access "
            "the service from outside (usually you want to put the IP adress and / or network hostname of "
            "your machine in there) Must be comma separated.",
            self,
            default="localhost, 127.0.0.1",
            password_mode=False,
        )
        # input_value = "localhost, 127.0.0.1"  # make this the result of an ask request if necessary
        # validates that is has single quotes around each allowed hostname, and no space
        hosts = [f'"{host.strip(" ")}"' for host in input_value.split(",")]
        return ", ".join(hosts)

    def MACHINE_CSRF_TRUSTED_ORIGINS(self):
        trusted_origins = []
        for host in self.keywords_store["MACHINE_ALLOWED_HOSTS"].split(","):
            host = host.replace('"', "").strip(" ")
            trusted_origins.append(
                f'"http://{host}:{self.keywords_store["NGINX_OUT_PORT"]}"'
            )
        return ", ".join(trusted_origins)

    MACHINE_CSRF_TRUSTED_ORIGINS.requirements: list[str] = [
        "MACHINE_ALLOWED_HOSTS",
        "NGINX_OUT_PORT",
    ]

    def NGINX_OUT_PORT(self):
        return self.renderer.ask(
            "Please specify a port (only integers, like 80 , or 9876) that you will use to connect to the server.",
            self,
            default="80",
            password_mode=False,
        )

    def RABBITMQ_OUT_PORT(self):
        return self.renderer.ask(
            "Please specify a port (only integers, like 5672) that you will use to connect to rabbitmq. "
            "(the message broker server for pipelined jobs API)",
            self,
            default="5672",
            password_mode=False,
        )

    def PERMISSIONED_USERNAME(self):
        return self.renderer.ask(
            "Please enter the username that was set for your host machine, "
            "to use bind mounts permissions (for backups, logs, and table files)",
            self,
            default="appuser",
        )

    def PERMISSIONED_GROUPNAME(self):
        return self.renderer.ask(
            "Please enter the user group name that was set for your host machine, "
            "to use bind mounts permissions (for backups, logs, and table files)",
            self,
            default="users",
        )

    def PERMISSIONED_UID(self):
        return self.renderer.ask(
            "Please enter the UID (user id) that was set for your host machine, "
            "to use bind mounts permissions (for backups, logs, and table files)",
            self,
            default="1000",
        )

    def PERMISSIONED_GID(self):
        return self.renderer.ask(
            "Please enter the GID (group id) that was set for your host machine, "
            "to use bind mounts permissions (for backups, logs, and table files)",
            self,
            default="100",
        )

    def AUTORESTORE_DJANGO_ON_STARTUP(self):
        return self.renderer.confirm(
            "Do you want django to attempt to auto-restore the database "
            "from a backup file upon each build or start ? "
            "(Dangerous, potential dataloss, do not set yes without knowing the implications beforehand)",
            self,
            default=False,
        )

    def DJANGO_DEBUG_MODE(self):
        return self.renderer.confirm(
            "Do you want to set the DJANGO server in debug mode, "
            "showing more logging info to the brower and log files ? "
            "(but potentially reducing security against malicious attackers)"
            "(Set to 'no' for production environment, and 'yes' for developpement environment)",
            self,
            default=False,
        )

    @ressource_copy_function
    def copy_source_code_if_available(self):
        source_code_folder = self.source_package_path
        if not source_code_folder.is_dir():
            self.renderer.print(
                "Could not copy the source code to the folder `source_code_copy`",
                style="yellow",
            )
            return None, None

        filter_out_paths = ["ressources", "__pycache__", "tests"]
        destination_root = self.docker_build_path / "django_server" / "source_code_copy"
        filter_out = [Path(x) for x in filter_out_paths]

        # TODO : maybe move the deletion to another part of the code ?
        shutil.rmtree(destination_root, ignore_errors=True)
        destination_root.mkdir(parents=True, exist_ok=True)

        sources: list[Path] = []
        destinations: list[Path] = []
        for p in source_code_folder.rglob("*"):
            if not p.is_file():
                continue

            relative_path = p.relative_to(source_code_folder)

            # Filter out anything under a top-level "ressources" directory
            if any(
                (relative_path == filter) or (str(filter) in str(relative_path.parent))
                for filter in filter_out
            ):
                continue

            sources.append(p)
            destinations.append(destination_root / relative_path)

        return sources, destinations

    @ressource_copy_function
    def copy_pyproject_toml_from_source_to_ressources_if_available(self):
        import tomllib

        pyproject_source_path = (
            self.source_package_path.parent.parent / "pyproject.toml"
        )
        if not pyproject_source_path.is_file():
            self.renderer.print(
                "Could not copy pyproject toml from source to ressources, package is installed through pip or wheels. "
                "This is normal and expected.",
                style="yellow",
            )
            return None, None

        with open(pyproject_source_path, "rb") as file:
            content = tomllib.load(file)
        if content.get("project", {}).get("name", None) == self.PROJECT_NAME():
            return (
                pyproject_source_path,
                self.source_package_path / "ressources" / "pyproject.toml",
            )

        self.renderer.print(
            f"Could not copy pyproject toml ({pyproject_source_path}) "
            "because if was not having the name={PROJECT_NAME} flag.",
            style="red",
        )
        return None, None

    @ressource_copy_function
    def copy_uv_lock_from_source_to_ressources_if_available(self):

        uv_source_path = self.source_package_path.parent.parent / "uv.lock"

        if uv_source_path.is_file():
            return uv_source_path, self.source_package_path / "ressources" / "uv.lock"

        self.renderer.print(
            "Could not copy uv.lock file "
            f"because it was not found in the host computer at that location : ({uv_source_path})",
            style="red",
        )
        return None, None
