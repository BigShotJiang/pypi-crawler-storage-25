from pathlib import Path

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .installers import Installer
    from .containers import Container


class SourceMixin:
    """This is a mixin to be used with File class to make a
    class that requires a source file (template) to generate a desination file

    Raises:
        ValueError: _description_

    Returns:
        _type_: _description_
    """

    source_file: Path | str
    manager: "Installer"
    container: "Optional[Container]"

    @property
    def source_path(self):
        """Determines the source path of the file associated with the current instance.
        (either of a File or Validator class and child classes). Use it as a mixin to provide access to a source
        file that relates to the destination file, for file-templated File and Validator classes.

        This method checks the type of the current instance and its associated file to
        return the appropriate source path. It handles various scenarios including
        validation of file types and the presence of absolute or relative paths.

        Returns:
            Path: The source path of the file.

        Raises:
            ValueError: If the validator is used with a file that does not inherit from
            SourceFile, or if an absolute path is provided without a corresponding
            absolute source_file.

        Notes:
            - The method requires that both Validator and File inherit from SourceFile
              when using the source_path attribute.
            - If the instance has a container, the source path is determined based on
              the container's source path.
        """
        from .verifications import Validator

        if isinstance(self, Validator):

            # In case we use the mixin with a validator class,
            # we just return the validator associatd file's source_path property
            if isinstance(self.file, SourceMixin):
                return self.file.source_path
            else:
                raise ValueError(
                    f"The validator {self.__class__.__name__} is used for a "
                    f"file {self.file.__class__.__name__} that doesn't seem to inherit from SourceFile. "
                    "Please make sure both Validator and File inherits "
                    "from SourceFIle is you use the source_path attribute."
                )

        # in case it is a file, we proceed down here with one of the cases
        if hasattr(self, "source_file"):
            source_file = Path(self.source_file)
            if source_file.is_absolute():
                return source_file
        elif hasattr(self, "path"):
            source_file = Path(getattr(self, "path"))
            if source_file.is_absolute():
                raise ValueError(
                    "If you use an absolute value for path to specify where the file sits, "
                    "you must supply an absolute value for source_file too."
                )
        elif hasattr(self, "filename"):
            source_file = Path(getattr(self, "filename")) # a file name is relative, by essence
        else:
            raise ValueError(
                "source_file is unbound because none " "of 'path', 'source_file' or 'filename' were set on that class"
            )

        # If we arrive there, source_file is a relative path, so we determine
        # it's root depending of wether or not there is a container attached to this file.
        if self.container is None:
            # if file not in a container, the root is obtained from the package source
            return self.manager.source_package_path / source_file
        return self.container.source_path / source_file
