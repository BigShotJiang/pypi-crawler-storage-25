import io
import os
import re
import sys
import traceback
from datetime import datetime
from functools import wraps
from pathlib import Path
from shutil import copy2
from typing import Callable, ParamSpec, TypeVar

from rich.console import Console
from rich.text import Text
from rich_click import secho

PROJECT_NAME = "alyx-local"

TIMESTAMP_PATTERN = re.compile(r"(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})\.sql")

PS = ParamSpec("PS")
T = TypeVar("T")


def get_timestamp(filepath: Path) -> float:

    result = TIMESTAMP_PATTERN.findall(filepath.name)
    if not result:
        return 0.0
    timestamp = datetime.strptime(result[0], "%Y-%m-%d_%H-%M-%S").timestamp()
    return timestamp


def is_inside_docker_container() -> bool:
    # Check for the /.dockerenv file (common in Docker containers)
    if os.path.exists("/.dockerenv"):
        return True
    # Check for 'docker' in /proc/1/cgroup (works for most Linux containers)
    try:
        with open("/proc/1/cgroup", "rt") as f:
            if "docker" in f.read() or "containerd" in f.read():
                return True
    except Exception:
        pass
    return False


def verify_outside_container(func: Callable[PS, T]) -> "Callable[PS, T]":
    """Decorator that will check that the function is executed outside a docker container, or raise and OSError"""

    @wraps(func)
    def wrapper(*args, **kwargs):
        if is_inside_docker_container():
            raise OSError(
                f"Cannot use function {func.__name__} from inside a docker container."  # ty:ignore[unresolved-attribute]
            )
        return func(*args, **kwargs)

    return wrapper


def copy_last_outdated_save():
    """Copy the most recent outdated SQL backup file to the django data/outdated_saves folder.

    This function searches for SQL files in a predefined directory that are considered outdated based on their
    timestamps. It copies the most recent outdated file to a designated folder within the Django data path.

    Raises:
        ValueError: If no outdated SQL files are found in the specified directory.

    Returns:
        None
    """
    from .configuration import DockerConfigInstaller

    installer = DockerConfigInstaller()

    outdated_folder = Path(r"//Mountcastle/ActiveBackupforBusiness/alyx_db_backups")

    sql_files = [file for file in outdated_folder.iterdir() if get_timestamp(file) != 0]
    if len(sql_files) == 0:
        secho("Cannot find any file meeting the requirements", fg="red")
        return ValueError("Cannot find any file meeting the requirements")
    sql_files.sort(key=get_timestamp, reverse=True)
    sql_file = sql_files[0]

    destination_path = (
        Path(installer.keywords_store["DJANGO_DATA_PATH"]) / "outdated_saves"
    )
    destination_path.mkdir(exist_ok=True, parents=True)
    destination_file = destination_path / sql_file.name

    copy2(sql_file, destination_file)
    secho(f"Successfully copied file {sql_file.name}", fg="green")


def rich_to_ansi(text: Text) -> str:
    # Render Rich Text to a string containing ANSI escape codes
    c = Console(
        file=io.StringIO(),
        force_terminal=True,
        color_system="truecolor",
        width=10_000,
        record=True,
    )
    c.print(text, end="")
    return c.export_text(clear=False)


def install_ansi_excepthook():
    def hook(exc_type, exc, tb):
        # Print traceback frames (no exception message)
        traceback.print_tb(tb, file=sys.stderr)
        # Print exception type + raw message (ANSI preserved)
        sys.stderr.write(f"{exc_type.__name__}: {exc}\n")

    sys.excepthook = hook
