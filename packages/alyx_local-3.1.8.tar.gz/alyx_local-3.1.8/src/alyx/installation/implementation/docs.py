import subprocess
import sys
import os
from rich_click import secho

from .utils import verify_outside_container

from typing import Literal

@verify_outside_container
def mkdocs(action:Literal["serve"], args: list[str] = []):

    try:
        import mkdocs  # noqa: F401
    except ModuleNotFoundError:
        subprocess.run(
            ["uv", "pip", "install", "mkdocs-material>=9.6.11"], 
            # TODO : get the version here from parsing the .toml file
            env=os.environ.copy(),
            check=True,
        )

    if "--config-file" not in args:
        args.extend(["--config-file", "./docs/mkdocs.yml"])
    if action == "serve":
        args.extend(["--open","--livereload"])
    shell_cmd = [sys.executable, "-m", "mkdocs", action, *args]
    secho(f"Using command : {shell_cmd}", fg="bright_black")
    subprocess.run(shell_cmd, shell=False, env=os.environ.copy())