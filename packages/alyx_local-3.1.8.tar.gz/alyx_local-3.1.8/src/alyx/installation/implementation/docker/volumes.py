import subprocess
from typing import Literal, Optional

from rich_click import secho

from .utils import (
    EXISTING_VOLUME_NAMES,
    validates_volume_name,
    verify_docker_daemon_is_running,
)


@validates_volume_name
@verify_docker_daemon_is_running
def volume_action(volume_name: Optional[str], action: Literal["delete"]):

    name_to_implementation = {
        "delete": "rm",
    }
    action_name = action.capitalize()

    action_impl = name_to_implementation[action]

    if volume_name is None:
        volume_names = EXISTING_VOLUME_NAMES
    else:
        volume_names = [volume_name]

    secho(f"{action_name}ing volume(s): {', '.join(volume_names)}", fg="yellow")

    shell_cmd = f"docker volume {action_impl} {' '.join(volume_names)}"
    secho(f"Using command : {shell_cmd}", fg="bright_black")
    subprocess.run(shell_cmd, shell=True)
