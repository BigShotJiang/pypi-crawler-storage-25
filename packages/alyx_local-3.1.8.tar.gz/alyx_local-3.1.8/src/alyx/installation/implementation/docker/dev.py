import subprocess

from ..configuration import DockerConfigInstaller


def build_docker_django_base_image():
    from alyx import __version__

    installer = DockerConfigInstaller.default_installer().run()

    registry_image = "ghcr.io/josttim/alyx-local-django-base"

    tags = [
        f"{registry_image}:{__version__}",  # immutable release tag
        f"{registry_image}:latest",  # moving pointer (optional)
    ]

    shell_cmd = [
        "docker",
        "buildx",
        "build",
        "-f",
        "django_server/Dockerfile",
        "--target",
        "base",
        *sum([["-t", t] for t in tags], []),
        "--push",
        ".",  # build context
    ]
    print(shell_cmd)
    subprocess.run(shell_cmd, cwd=installer.docker_build_path, check=True)
