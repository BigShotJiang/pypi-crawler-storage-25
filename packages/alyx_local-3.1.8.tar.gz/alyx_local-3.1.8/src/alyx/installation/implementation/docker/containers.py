import subprocess
from typing import Literal, Optional

from rich_click import secho

from ..configuration import DockerConfigInstaller
from ..utils import PROJECT_NAME
from .utils import (
    EXISTING_CONTAINER_NAMES,
    validates_container_name,
    verify_outside_container,
)


@verify_outside_container
@validates_container_name
def container_action(
    container_name: Optional[str],
    action: Literal["start", "stop", "restart", "delete", "build"],
    args: list[str] = [],
    fresh: bool = False,
    verbose: bool = False,
    follow_logs: bool = True,
) -> None:
    """Start or restart alyx docker containers, depending on the action provided"""

    name_to_implementation = {
        "start": "up" if follow_logs else "start",
        "stop": "stop",
        "restart": "restart",
        "delete": "rm",
        "build": "up --build",
    }
    action_name = action.capitalize()
    action_impl = name_to_implementation[action]

    installer = DockerConfigInstaller()

    if container_name:
        secho(f"{action_name}ing container {container_name}", fg="yellow")
    else:
        secho(f"{action_name}ing all containers", fg="yellow")

    if not container_name or action_name == "build":
        shell_cmd = (
            f"docker compose -p {PROJECT_NAME} "
            f'--project-directory "{installer.docker_build_path}" '
            f"{action_impl}"
        )
    else:
        shell_cmd = f"docker container {action_impl}"
        if verbose and action_name == "build":
            shell_cmd += "--progress=plain"

    if fresh:
        container_action(container_name, "delete")

    shell_cmd = f"{shell_cmd} {container_name or ''} {' '.join(args)}".strip()
    secho(f"Using command : {shell_cmd}", fg="bright_black")
    subprocess.run(shell_cmd, shell=True)


@verify_outside_container
@validates_container_name
def container_interactive_shell(container_name: Optional[str]):
    if container_name not in EXISTING_CONTAINER_NAMES:
        raise ValueError(f"container_name must be one of : {EXISTING_CONTAINER_NAMES}")
    secho(
        f"Opening interactive bash terminal to the container {container_name}",
        fg="yellow",
    )
    shell_cmd = f"docker exec -it {container_name} bash"
    subprocess.run(shell_cmd, shell=True)
