import os
import shlex
import subprocess

from rich_click import secho

from .utils import is_inside_docker_container


def manage(args: list[str] = [], internal=False):
    """

    The behaviour of the internal argument when true is to force running the
    manage ocmmand in an internal way, without trying to detect wether being
    called from outside or inside a docker container.
    """
    if internal or is_inside_docker_container():
        return manage_internal(args)
    return manage_external(args)


def manage_internal(args: list[str] = []):
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "alyx.base.settings")
    from django.core.management import execute_from_command_line

    args = ["manage"] + args
    secho(
        f"Running manage from inside a docker container: execute_from_command_line({args})",
        fg="yellow",
    )
    execute_from_command_line(args)


def manage_external(args: list[str] = []):
    args_str = " ".join(shlex.quote(arg) for arg in args)

    shell_cmd = f"docker exec -w /app/ -it django_server uv run --frozen alyx manage --internal {args_str}"
    secho(
        f"Running manage from outside a docker containerwith command: {shell_cmd}",
        fg="yellow",
    )
    subprocess.run(shell_cmd, shell=True)
