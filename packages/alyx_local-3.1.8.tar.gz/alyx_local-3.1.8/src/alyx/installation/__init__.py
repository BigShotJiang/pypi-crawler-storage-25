from .implementation.utils import install_ansi_excepthook

install_ansi_excepthook()