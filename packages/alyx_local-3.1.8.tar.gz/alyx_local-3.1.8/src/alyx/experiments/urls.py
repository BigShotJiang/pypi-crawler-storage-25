from django.conf.urls import include
from django.urls import path

from .api import (
    BrainRegionDetail,
    BrainRegionList,
    ChannelDetail,
    ChannelList,
    ProbeInsertionDetail,
    ProbeInsertionList,
    TrajectoryEstimateDetail,
    TrajectoryEstimateList,
)

api_urls = [
    path("insertions", ProbeInsertionList.as_view(), name="probeinsertion-list"),
    path(
        "insertions/<uuid:pk>",
        ProbeInsertionDetail.as_view(),
        name="probeinsertion-detail",
    ),
    path(
        "trajectories", TrajectoryEstimateList.as_view(), name="trajectoryestimate-list"
    ),
    path(
        "trajectories/<uuid:pk>",
        TrajectoryEstimateDetail.as_view(),
        name="trajectoryestimate-detail",
    ),
    path("channels", ChannelList.as_view(), name="channel-list"),
    path("channels/<uuid:pk>", ChannelDetail.as_view(), name="channel-detail"),
    path("brain-regions", BrainRegionList.as_view(), name="brainregion-list"),
    path(
        "brain-regions/<int:pk>", BrainRegionDetail.as_view(), name="brainregion-detail"
    ),
]

views_urls = []

urlpatterns = [path("api/", include(api_urls)), path("", include(views_urls))]
