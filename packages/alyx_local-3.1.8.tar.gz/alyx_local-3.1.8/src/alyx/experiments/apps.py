from django.apps import AppConfig
import structlog

logger = structlog.get_logger("alyx.expe_app")


class ExperimentsConfig(AppConfig):
    name = "alyx.experiments"
    label = "experiments"

    def ready(self):
        logger.debug("EXPERIMENTS APP IS READY")
