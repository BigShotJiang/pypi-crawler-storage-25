from typing import cast

from django.db.models import QuerySet
from drf_spectacular.utils import extend_schema
from rest_framework import serializers
from rest_framework.serializers import ChoiceField

from ..actions.models import EphysSession, Session

# from ..actions.serializers import SessionListSerializer
from ..base.serializers import LazySerializerField
from ..data.models import DataRepository, Dataset, DatasetType, FileRecord
from ..experiments.models import (
    BrainRegion,
    Channel,
    CoordinateSystem,
    ProbeInsertion,
    ProbeModel,
    TrajectoryEstimate,
)

# class SessionListSerializer(serializers.ModelSerializer):
#     @staticmethod
#     def setup_eager_loading(queryset):
#         """Perform necessary eager loading of data to avoid horrible performance."""
#         queryset = queryset.select_related("subject", "lab")
#         return queryset.order_by("-start_time")

#     subject = serializers.SlugRelatedField(read_only=True, slug_field="name")
#     lab = serializers.SlugRelatedField(read_only=True, slug_field="name")

#     class Meta:
#         model = Session
#         fields = ("subject", "start_time", "number", "lab", "id", "task_protocol")


class TrajectoryEstimateSerializer(serializers.ModelSerializer):
    probe_insertion = serializers.SlugRelatedField(
        read_only=False,
        required=False,
        slug_field="id",
        many=False,
        queryset=ProbeInsertion.objects.all(),
    )
    x = serializers.FloatField(required=True, allow_null=True)
    y = serializers.FloatField(required=True, allow_null=True)
    z = serializers.FloatField(required=False, allow_null=True)
    depth = serializers.FloatField(required=True, allow_null=True)
    theta = serializers.FloatField(required=True, allow_null=True)
    phi = serializers.FloatField(required=True, allow_null=True)
    roll = serializers.FloatField(required=False, allow_null=True)
    provenance = ChoiceField(
        required=True, choices=TrajectoryEstimate.INSERTION_DATA_SOURCES
    )
    session = LazySerializerField(
        "actions.serializers.SessionListSerializer",
        read_only=True,
    )
    # session = SessionListSerializer(read_only=True)
    probe_name = serializers.CharField(read_only=True)
    coordinate_system = serializers.SlugRelatedField(
        read_only=False,
        required=False,
        slug_field="name",
        many=False,
        queryset=CoordinateSystem.objects.all(),
    )

    class Meta:
        model = TrajectoryEstimate
        fields = "__all__"


class ChannelSerializer(serializers.ModelSerializer):
    trajectory_estimate = serializers.SlugRelatedField(
        read_only=False,
        required=False,
        slug_field="id",
        many=False,
        queryset=TrajectoryEstimate.objects.all(),
    )
    brain_region = serializers.SlugRelatedField(
        read_only=False,
        required=False,
        slug_field="id",
        many=False,
        queryset=BrainRegion.objects.all(),
    )

    class Meta:
        model = Channel
        fields = "__all__"


class FilterDatasetSerializer(serializers.ListSerializer):
    def to_representation(self, data: "QuerySet[Dataset]"):
        if DataRepository.objects.count() > 0:
            frs = FileRecord.objects.filter(
                pk__in=data.values_list("file_records", flat=True)
            )
            pkd = frs.filter(exists=True).values_list("dataset", flat=True)
            dsets = data.filter(pk__in=pkd)
        return super(FilterDatasetSerializer, self).to_representation(dsets)


class ProbeInsertionDatasetsSerializer(serializers.ModelSerializer):
    dataset_type = serializers.SlugRelatedField(
        read_only=False,
        slug_field="name",
        queryset=DatasetType.objects.all(),
    )

    class Meta:
        list_serializer_class = FilterDatasetSerializer
        model = Dataset
        fields = (
            "id",
            "name",
            "dataset_type",
            "data_url",
            "url",
            "file_size",
            "hash",
            "version",
            "collection",
        )


class ProbeInsertionListSerializer(serializers.ModelSerializer):
    @staticmethod
    def setup_eager_loading(queryset):
        """Perform necessary eager loading of data to avoid horrible performance."""
        queryset = queryset.select_related("model", "session")
        queryset = queryset.prefetch_related(
            "session__subject", "session__lab", "datasets"
        )
        return queryset.order_by("-session__start_time")

    session = serializers.SlugRelatedField(
        read_only=False,
        required=False,
        slug_field="id",
        queryset=EphysSession.objects.filter(task_protocol__icontains="ephys"),
    )
    model = serializers.SlugRelatedField(
        read_only=False,
        required=False,
        slug_field="probe_model",
        queryset=ProbeModel.objects.all(),
    )
    session_info = LazySerializerField(
        "actions.serializers.SessionListSerializer",
        read_only=True,
    )

    # session_info = SessionListSerializer(read_only=True, source="session")

    class Meta:
        model = ProbeInsertion
        fields = "__all__"


class ProbeInsertionDetailSerializer(serializers.ModelSerializer):
    session = serializers.SlugRelatedField(
        read_only=False,
        required=False,
        slug_field="id",
        queryset=EphysSession.objects.filter(task_protocol__icontains="ephys"),
    )
    model = serializers.SlugRelatedField(
        read_only=False,
        required=False,
        slug_field="probe_model",
        queryset=ProbeModel.objects.all(),
    )
    session_info = LazySerializerField(
        "actions.serializers.SessionListSerializer",
        read_only=True,
    )
    # session_info = SessionListSerializer(read_only=True, source="session")

    datasets = serializers.SerializerMethodField()

    def get_datasets(self, obj) -> list[dict]:
        qs = obj.session.data_dataset_session_related.all().filter(
            collection__icontains=obj.name
        )

        request = self.context.get("request", None)
        dsets = ProbeInsertionDatasetsSerializer(
            qs, many=True, context={"request": request}
        )
        return cast(list[dict], dsets.data)

    class Meta:
        model = ProbeInsertion
        fields = "__all__"


class BrainRegionSerializer(serializers.ModelSerializer):
    # we do not want anybody to update the ontology from rest ! Only the description
    id = serializers.IntegerField(read_only=True)
    acronym = serializers.CharField(read_only=True)
    name = serializers.CharField(read_only=True)
    parent = serializers.SlugRelatedField(read_only=True, slug_field="id")

    class Meta:
        model = BrainRegion
        fields = (
            "id",
            "acronym",
            "name",
            "description",
            "parent",
            "related_descriptions",
        )
