from django.core.management.base import BaseCommand
from django.core.management import call_command
from django.conf import settings
from django.db import connections
from django.db.utils import ProgrammingError
import structlog

logger = structlog.get_logger("actions.admin")


class Command(BaseCommand):
    help = (
        "Automatically restore the database and perform migrations, "
        "if the database is not existing already. (for example after a fresh build)"
    )

    def add_arguments(self, parser):
        super(Command, self).add_arguments(parser)
        parser.add_argument(
            "--use_settings",
            action="store_true",
            help="Choose to decide wether to auto restore based on settings or bypass settings. "
            "If not set, settigns will be bypassed (the default and expected behaviour, if you call it yourself).",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Force auto restoration even if migrations are present",
        )
        parser.add_argument(
            "--migrate_new_db",
            action="store_true",
            help="In case that the database is new (no migration found), perform a first migration.",
        )

    def handle(self, *args, **options):
        use_settings = options.get("use_settings", False)
        migrate_new_db = options.get("migrate_new_db", False)
        force_db_restoration = options.get("force", False)

        migration_count = self.get_migration_count()

        actions_to_perform = set()

        if migration_count and force_db_restoration:
            actions_to_perform.update(["pre-migrate", "restore", "post-migrate"])
            logger.warning(
                "Some migrations were found on the database, forcing auto restoration !"
            )
        elif migration_count and not force_db_restoration:
            logger.warning(
                "Some migrations were found on the database, not auto-restoring."
            )
        elif not migration_count and use_settings and settings.AUTO_RESTORE_ON_STARTUP:
            logger.info(
                "Performing auto-restoration of the database from config settings."
            )
            actions_to_perform.update(["pre-migrate", "restore", "post-migrate"])

        elif not migration_count and migrate_new_db:
            logger.info(
                "No migration are present on the database, attempting initial migration."
            )
            actions_to_perform.update(["pre-migrate"])
        elif (
            not migration_count
            and use_settings
            and not settings.AUTO_RESTORE_ON_STARTUP
        ):
            logger.warning(
                "No auto-resoration of the database was done as the settings are forbidding it."
            )
            # if we run command using the settigns to know what to do,
            # and we see that AUTO_RESTORE_ON_STARTUP is False,
            # we skip the command after this if condition. In any other case, we execute it.

        self.perform_actions(actions_to_perform)

    def get_migration_count(self):
        connection = connections["default"]
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) FROM django_migrations;")
                return cursor.fetchone()[0]
        except ProgrammingError:
            return 0  # django_migrations table does not exist yet

    def perform_actions(self, actions: set):
        if "pre-migrate" in actions:
            # migrate to be sure the database is created correctly
            call_command("migrate")

        if "restore" in actions:
            logger.info("Performing auto-restoration of the database.")
            # restore from latest database file in /data/backups folder
            call_command("dbrestore", "--noinput")

        if "post-migrate":
            # migrate after restore in case we restore from a previous database version
            call_command("migrate")
