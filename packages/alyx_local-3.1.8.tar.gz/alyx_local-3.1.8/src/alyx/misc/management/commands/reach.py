"""
Connectivity checks that work in Docker even when ICMP ping is blocked.

Usage:
  python reach.py https://pypi.org
  python reach.py 8.8.8.8
  python reach.py 192.168.1.10:445
  python reach.py smb://192.168.1.10/share
  python reach.py nfs://192.168.1.20/export
  python reach.py postgres://postgres_db:5432
  python reach.py rabbitmq://rabbitmq:5672

Exit codes:
  0 = reachable (at least one relevant check succeeded)
  2 = unreachable / failed
"""

from __future__ import annotations

import argparse
import socket
import ssl
import sys
from dataclasses import dataclass
from urllib.parse import urlparse


DEFAULT_TIMEOUT = 3.0


@dataclass
class Result:
    ok: bool
    message: str


def tcp_connect(host: str, port: int, timeout: float = DEFAULT_TIMEOUT) -> Result:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return Result(True, f"OK TCP connect {host}:{port}")
    except Exception as e:
        return Result(False, f"FAIL TCP connect {host}:{port} -> {e}")


def tls_handshake(host: str, port: int = 443, timeout: float = DEFAULT_TIMEOUT, server_name: str | None = None) -> Result:
    try:
        raw = socket.create_connection((host, port), timeout=timeout)
        try:
            ctx = ssl.create_default_context()
            with ctx.wrap_socket(raw, server_hostname=server_name or host) as s:
                s.do_handshake()
            return Result(True, f"OK TLS handshake {host}:{port}")
        finally:
            raw.close()
    except Exception as e:
        return Result(False, f"FAIL TLS handshake {host}:{port} -> {e}")


def http_head(url: str, timeout: float = DEFAULT_TIMEOUT) -> Result:
    # Minimal HTTP HEAD without external deps; supports http/https.
    p = urlparse(url)
    scheme = p.scheme.lower()
    host = p.hostname
    if not host:
        return Result(False, f"FAIL parse URL: {url}")
    port = p.port or (443 if scheme == "https" else 80)
    path = p.path or "/"
    if p.query:
        path += "?" + p.query

    try:
        raw = socket.create_connection((host, port), timeout=timeout)
        try:
            s = raw
            if scheme == "https":
                ctx = ssl.create_default_context()
                s = ctx.wrap_socket(raw, server_hostname=host)

            req = (
                f"HEAD {path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                f"User-Agent: reach/1.0\r\n"
                f"Connection: close\r\n\r\n"
            ).encode("ascii", "strict")
            s.sendall(req)
            data = s.recv(4096)
            line = data.split(b"\r\n", 1)[0].decode("latin1", "replace")
            if line.startswith("HTTP/"):
                return Result(True, f"OK {url} -> {line}")
            return Result(False, f"FAIL {url} -> unexpected response: {line!r}")
        finally:
            raw.close()
    except Exception as e:
        return Result(False, f"FAIL {url} -> {e}")


def resolve_host(host: str) -> Result:
    try:
        infos = socket.getaddrinfo(host, None)
        addrs = sorted({i[4][0] for i in infos})
        return Result(True, f"OK DNS resolve {host} -> {', '.join(addrs)}")
    except Exception as e:
        return Result(False, f"FAIL DNS resolve {host} -> {e}")


def parse_target(s: str):
    # Accept:
    # - URL (scheme://...)
    # - host
    # - host:port
    if "://" in s:
        return ("url", s)
    if s.count(":") == 1 and not s.startswith("["):
        host, port = s.rsplit(":", 1)
        if port.isdigit():
            return ("hostport", (host, int(port)))
    return ("host", s)


def check_url(url: str) -> list[Result]:
    p = urlparse(url)
    scheme = p.scheme.lower()
    host = p.hostname or ""
    port = p.port

    results: list[Result] = []
    results.append(resolve_host(host))

    if scheme in ("http", "https"):
        results.append(http_head(url))
        # Also do a pure TCP/TLS check to distinguish HTTP issues from network issues
        results.append(tcp_connect(host, port or (443 if scheme == "https" else 80)))
        if scheme == "https":
            results.append(tls_handshake(host, port or 443, server_name=host))
        return results

    # Protocol-specific "reachability" = TCP connect to the well-known port (or provided port)
    # This does NOT prove auth/share/export exists; it proves network path + port open.
    default_ports = {
        "smb": 445,
        "cifs": 445,
        "nfs": 2049,
        "ssh": 22,
        "postgres": 5432,
        "postgresql": 5432,
        "amqp": 5672,
        "rabbitmq": 5672,
        "redis": 6379,
        "ldap": 389,
        "ldaps": 636,
    }
    dport = default_ports.get(scheme)
    if dport is None and port is None:
        results.append(Result(False, f"Unknown scheme {scheme!r}; provide host:port"))
        return results

    results.append(tcp_connect(host, port or dport))
    return results


def check_host(host: str) -> list[Result]:
    # For a bare IPv4/hostname, "reachability" is ambiguous without a protocol.
    # We do DNS resolve + optional common TCP ports (443, 80) as a generic outside check.
    results: list[Result] = []
    results.append(resolve_host(host))
    results.append(tcp_connect(host, 443))
    results.append(tcp_connect(host, 80))
    return results


def check_hostport(host: str, port: int) -> list[Result]:
    return [resolve_host(host), tcp_connect(host, port)]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("target", help="URL, host, or host:port")
    ap.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    args = ap.parse_args()

    global DEFAULT_TIMEOUT
    DEFAULT_TIMEOUT = args.timeout

    kind, val = parse_target(args.target)
    if kind == "url":
        results = check_url(val)
    elif kind == "hostport":
        host, port = val
        results = check_hostport(host, port)
    else:
        results = check_host(val)

    ok = any(r.ok for r in results)
    for r in results:
        print(r.message)

    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
