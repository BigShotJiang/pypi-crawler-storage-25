import subprocess, logging, re, os
from datetime import datetime
from subprocess import CalledProcessError, PIPE
from pathlib import Path
from django.core.management.base import BaseCommand
from django.conf import settings
from django.core.management import call_command

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = "Restore the database from an earlier backup in a .sql format (before using the dbbackup package)"
    timestamp_pattern = re.compile(r"(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})\.sql")

    @property
    def db_name(self):
        return settings.DATABASES["default"]["NAME"]

    @property
    def db_user(self):
        return settings.DATABASES["default"]["USER"]

    @property
    def db_pass(self):
        return settings.DATABASES["default"]["PASSWORD"]

    @property
    def db_host(self):
        return settings.DATABASES["default"]["HOST"]

    def add_arguments(self, parser):
        super(Command, self).add_arguments(parser)
        parser.add_argument("--input-file", "-f", nargs=1, type=str, required=False)
        parser.add_argument("--data-only", action="store_true", default=False, required=False)

        parser.add_argument("--no-drop-db", dest="drop_db", action="store_false")
        parser.add_argument("--drop-db", dest="drop_db", action="store_true")
        parser.add_argument("--do-not-migrate", dest="migrate", action="store_false")
        parser.add_argument("--migrate", dest="migrate", action="store_true")
        parser.set_defaults(drop_db=True)
        parser.set_defaults(migrate=True)

    def get_timestamp(self, filepath: Path) -> float:

        result = self.timestamp_pattern.findall(filepath.name)
        if not result:
            return 0.0
        timestamp = datetime.strptime(result[0], "%Y-%m-%d_%H-%M-%S").timestamp()
        return timestamp

    def handle(self, *args, **options):

        sql_dir_root = Path("/app/data/outdated_saves")
        sql_dir_root.mkdir(parents=True, exist_ok=True)

        if options["input_file"]:
            sql_file = sql_dir_root / options["input_file"]
        else:

            sql_files = [file for file in sql_dir_root.iterdir() if self.get_timestamp(file) != 0]
            if len(sql_files) == 0:
                raise ValueError("Cannot find any file meeting the requirements")
            sql_files.sort(key=self.get_timestamp, reverse=True)
            sql_file = sql_files[0]

        if options["drop_db"]:
            self.psql_drop_and_recreate_db()

        self.restore_psql_readaccess()
        if options["data_only"]:
            logger.warning("Restoring in data only mode.")
            self.psql_command("SET session_replication_role = replica;")
            # self.psql_restore_from_file(sql_file)
            self.pgrestore_from_file(sql_file)
            self.psql_command("SET session_replication_role = origin;")
        else:
            logger.warning("Restoring in normal mode.")
            # self.psql_restore_from_file(sql_file)
            self.pgrestore_from_file(sql_file, clean=True, if_exists=True)
        logger.warning("Restoration finished succesfully")

        if options["migrate"]:
            call_command("migrate")
            logger.warning("Migration done successfully")

    def restore_psql_readaccess(self):

        command = rf"""
        DO $$
            BEGIN
                IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'readaccess') THEN
                    CREATE ROLE readaccess LOGIN;
                    GRANT CONNECT ON DATABASE {self.db_name} TO readaccess;
                    GRANT USAGE ON SCHEMA public TO readaccess;
                    GRANT SELECT ON ALL TABLES IN SCHEMA public TO readaccess;
                END IF;
            END
        $$;"""
        logger.warning("Creating database role readaccess if missing...")
        self.psql_command(command)

    def psql_drop_and_recreate_db(self):
        logger.warning("Dropping and recreating the database...")
        self.psql_command(f"DROP DATABASE IF EXISTS {self.db_name};", db_name="postgres")
        self.psql_command(f"CREATE DATABASE {self.db_name} OWNER {self.db_user};", db_name="postgres")

    def psql_command(self, command: str, db_name=None):
        self.send_psql_request({"-c": command}, db_name=db_name)

    def psql_restore_from_file(self, filepath: Path):
        self.send_psql_request({"-f": str(filepath)})

    def send_psql_request(self, arguments: dict, db_name=None):

        db_name = self.db_name if db_name is None else db_name

        arguments_list = []
        [arguments_list.extend([key, value]) for key, value in arguments.items()]
        arguments_list = ["psql", "-h", self.db_host, "-U", self.db_user, "-d", db_name] + arguments_list

        os.environ["PGPASSWORD"] = self.db_pass

        try:
            result = subprocess.run(arguments_list, stdout=PIPE, stderr=PIPE, check=True)
        except CalledProcessError as e:
            error_message = e.stderr.decode("utf-8")
            output_message = e.stdout.decode("utf-8")
            logger.error(
                f"SQL request with args : {' '.join(arguments_list)}, failed with exit status {e.returncode}, "
                f"{error_message}.\n{output_message}"
            )
            return

    def pgrestore_from_file(self, filepath: Path, clean=False, if_exists=False):

        os.environ["PGPASSWORD"] = self.db_pass

        if_exists = ["--if-exists"] if if_exists == True else []
        clean = ["--clean"] if clean == True else []
        arguments = ["pg_restore"] + clean + if_exists + ["-h", self.db_host, "-U", self.db_user, "-d", self.db_name]
        try:
            with open(filepath, "r") as file:
                result = subprocess.run(arguments, stdin=file, stdout=PIPE, stderr=PIPE, check=True)
        except CalledProcessError as e:
            error_message = e.stderr.decode("utf-8")
            output_message = e.stdout.decode("utf-8")
            logger.error(
                f"Command pg_restore, failed with exit status {e.returncode}, {error_message}.\n{output_message}"
            )
            return
