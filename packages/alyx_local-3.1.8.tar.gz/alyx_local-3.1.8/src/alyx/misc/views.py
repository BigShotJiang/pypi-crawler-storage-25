import re
import socket
import subprocess
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.views.generic import TemplateView, View
from django.http import HttpResponseBadRequest, StreamingHttpResponse


class ManagementHubView(TemplateView, LoginRequiredMixin, PermissionRequiredMixin):
    template_name = "management/hub.html"
    permission_required = "system_admin"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["subpages"] = [
            {"name": "Database Management", "url": "database-management"},
            {"name": "Media Management", "url": "media-management"},
            {"name": "Backups", "url": "backups-management"},
            {"name": "Restore", "url": "restore-management"},
            {"name": "Test Netork Connectivity", "url": "test-network-connectivity-management"},
        ]
        context["site_header"] = "Alyx"
        context["title"] = "Management Hub"
        return context


class DatabaseManagementUIView(TemplateView, LoginRequiredMixin, PermissionRequiredMixin):
    template_name = "management/database.html"
    permission_required = "system_admin"


class ServicesHubView(TemplateView, LoginRequiredMixin, PermissionRequiredMixin):
    template_name = "management/services.html"
    permission_required = "system_admin"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["subpages"] = [
            {"name": "Celery", "url": "/services/celery"},
            {"name": "PgAdmin", "url": "/services/pgadmin"},
            {"name": "Rabbitmq", "url": "/services/rabbitmq"},
        ]
        context["site_header"] = "Alyx"
        context["title"] = "Services Hub"
        return context


HOST_MAC_ALIAS = "docker.for.mac.localhost"
PING_INTERVAL_SECONDS = 1
PING_COUNT = 0  # 0 => continuous (linux ping). Set >0 to stop after N replies.


def _normalize_target(raw: str) -> str:
    raw = (raw or "").strip()
    if not raw:
        raise ValueError("Empty target")

    # If URL, extract hostname
    if "://" in raw:
        from urllib.parse import urlparse

        u = urlparse(raw)
        if not u.hostname:
            raise ValueError("Invalid URL")
        raw = u.hostname

    raw = raw.strip("[]")  # allow [::1]

    # Safety: allow only hostname/ip chars (prevents shell injection; we also never use shell=True)
    if not re.fullmatch(r"[A-Za-z0-9\.\-:]+", raw):
        raise ValueError("Invalid characters in target")

    # Ensure it resolves (optional but useful)
    socket.getaddrinfo(raw, None)
    return raw


class TestNetworkConnectivityView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    template_name = "management/test_network_connectivity.html"
    permission_required = "system_admin"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["site_header"] = "Alyx"
        ctx["title"] = "Test Network Connectivity"
        ctx["docker_host_target"] = HOST_MAC_ALIAS
        return ctx


class PingStreamView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = "system_admin"

    def get(self, request, *args, **kwargs):
        target = request.GET.get("target", "")
        quick = request.GET.get("quick", "")

        if quick == "host":
            target = HOST_MAC_ALIAS

        try:
            target = _normalize_target(target)
        except Exception as e:
            return HttpResponseBadRequest(str(e))

        def sse():
            yield "retry: 1000\n\n"

            cmd = ["ping", "-n", "-O", "-i", str(PING_INTERVAL_SECONDS), target]
            if PING_COUNT and PING_COUNT > 0:
                cmd = ["ping", "-n", "-O", "-i", str(PING_INTERVAL_SECONDS), "-c", str(PING_COUNT), target]

            try:
                p = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )
            except FileNotFoundError:
                yield "event: line\ndata: ping binary not found in container (install iputils-ping)\n\n"
                return

            try:
                for line in iter(p.stdout.readline, ""):
                    line = line.rstrip("\n").replace("\r", "")
                    if line:
                        yield f"event: line\ndata: {line}\n\n"
                rc = p.wait(timeout=2)
                yield f"event: done\ndata: ping exited with code {rc}\n\n"
            except GeneratorExit:
                try:
                    p.terminate()
                except Exception:
                    pass
            except Exception as e:
                try:
                    p.terminate()
                except Exception:
                    pass
                yield f"event: error\ndata: {str(e)}\n\n"

        resp = StreamingHttpResponse(sse(), content_type="text/event-stream")
        resp["Cache-Control"] = "no-cache"
        resp["X-Accel-Buffering"] = "no"
        return resp