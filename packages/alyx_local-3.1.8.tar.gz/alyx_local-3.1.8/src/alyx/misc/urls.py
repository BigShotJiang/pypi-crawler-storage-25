from django.conf.urls import include
from django.urls import path, re_path

from .api import (
    CacheDownloadView,
    CacheVersionView,
    LabDetail,
    LabList,
    MediaView,
    NoteDetail,
    NoteList,
    ServerInfoView,
    UserViewSet,
)
from .views import (
    DatabaseManagementUIView,
    ManagementHubView,
    PingStreamView,
    ServicesHubView,
    TestNetworkConnectivityView,
)

user_list = UserViewSet.as_view({"get": "list"})
user_detail = UserViewSet.as_view({"get": "retrieve"})

management_urls = [
    path("", ManagementHubView.as_view(), name="management-hub"),
    path("media", DatabaseManagementUIView.as_view(), name="media-management"),
    path("restore", DatabaseManagementUIView.as_view(), name="restore-management"),
    path("backups", DatabaseManagementUIView.as_view(), name="backups-management"),
    path("database", DatabaseManagementUIView.as_view(), name="database-management"),
    path(
        "test-network-connectivity/",
        TestNetworkConnectivityView.as_view(),
        name="test-network-connectivity-management",
    ),
    path(
        "test-network-connectivity/stream/",
        PingStreamView.as_view(),
        name="test-network-connectivity-stream",
    ),
]

api_urls = [
    path("labs", LabList.as_view(), name="lab-list"),
    path("labs/<str:name>", LabDetail.as_view(), name="lab-detail"),
    path("notes", NoteList.as_view(), name="note-list"),
    path("notes/<uuid:pk>", NoteDetail.as_view(), name="note-detail"),
    path("users/<str:username>", user_detail, name="user-detail"),
    path("users", user_list, name="user-list"),
    re_path("^media/(?P<img_url>.*)", MediaView.as_view(), name="media"),
    path("cache.zip", CacheDownloadView.as_view(), name="cache-download"),
    re_path(
        r"^cache/info(?:/(?P<tag>\w+))?/$",
        CacheVersionView.as_view(),
        name="cache-info",
    ),
    path("server-info", ServerInfoView.as_view(), name="server-info"),
]

views_urls = []

urlpatterns = [
    path("services", ServicesHubView.as_view(), name="services-hub"),
    path("api/", include(api_urls)),
    path("management/", include(management_urls)),
    path("", include(views_urls)),
]
