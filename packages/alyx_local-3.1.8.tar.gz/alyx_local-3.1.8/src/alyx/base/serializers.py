from pathlib import Path

from django.db.models.options import Options
from django.utils.module_loading import import_string
from rest_framework.serializers import (
    # ChoiceField,
    Field,
    IntegerField,
    SlugRelatedField,
    ValidationError,
)


class PathField(Field):
    def to_representation(self, value: str | Path) -> str:
        return str(value)

    def to_internal_value(self, data: str) -> Path:
        return Path(data)


class BaseSerializerContentTypeField(SlugRelatedField):
    """
    Field serializer for ContentType - the internal representation is an int
    The string representation is the concatenation of app + model, such as 'actions.session'
    """

    def to_representation(self, obj: Options):
        return str(obj.app_label) + "." + str(obj.model)

    def to_internal_value(self, data: str):
        """
        If there is no dot, attempt a straight model lookup that may have conflicts
        Otherwise look for 'app.model' syntax as is returned in the representation
        A good practice is to constrain the queryset when initializing the serializer to given apps
        to avoid conflicts on the model name as much as possible
        """
        if self.queryset is None:
            raise ValueError(
                "Queryset in None in BaseSerializerContentTypeField.to_internal_value"
            )
        if "." in data:
            app, model = data.split(".")
            return self.queryset.get(model=model, app_label=app)
        return self.queryset.get(model=data)


class LazySerializerField(Field):
    """
    Lazily instantiates a DRF serializer class from a dotted path to avoid
    circular imports at module import time.
    """

    def __init__(self, serializer_path: str, *, many=False, **kwargs):
        self.serializer_path = serializer_path
        self.many = many
        super().__init__(**kwargs)

    def _get_serializer(self, *args, **kwargs):
        cls = import_string(self.serializer_path)
        return cls(*args, many=self.many, context=self.context, **kwargs)

    def to_representation(self, value):
        return self._get_serializer(instance=value).data

    def to_internal_value(self, data):
        ser = self._get_serializer(data=data)
        ser.is_valid(raise_exception=True)
        return ser.validated_data


# class BaseSerializerEnumField(Field):
#     """
#     Field serializer for an int model field with enumerated choices.
#     This provides the string representation of the model for the rest requests and filters
#     """

#     @property
#     def choices(self):
#         if self.parent is None:
#             raise ValueError("parent of {self} is None, canot access to choices")
#         model = self.parent.Meta.model
#         return model._meta.get_field(self.field_name).choices

#     def to_representation(self, int_rep):
#         status = [ch for ch in self.choices if ch[0] == int_rep]
#         return status[0][1]

#     def to_internal_value(self, str_rep):
#         status = [ch for ch in self.choices if ch[1] == str_rep]
#         if len(status) == 0:
#             raise ValidationError(
#                 f"Invalid {self.field_name}, choices are: "
#                 + ", ".join([ch[1] for ch in self.choices])
#             )
#         return status[0][0]
