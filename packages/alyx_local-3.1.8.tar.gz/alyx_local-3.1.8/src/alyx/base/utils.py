import logging
from datetime import datetime
from zoneinfo import ZoneInfo

from dateutil.parser import parse
from dateutil.relativedelta import relativedelta
from django.conf import settings

logger = logging.getLogger("django.security")


def show_host_middleware(get_response):
    """Show host middleware that logs the raw Host header and allowed hosts.

    This middleware retrieves the Host header from the incoming request and logs it,
    along with the allowed hosts defined in the settings. It is intended to help with
    debugging and monitoring of incoming requests.

    Args:
        get_response (callable): The next middleware or view in the processing chain.

    Returns:
        callable: The middleware function that processes the request.
    """

    def middleware(request):
        host = request.META.get("HTTP_HOST", "<no host header>")
        logger.warning(f"Raw Host header received: {host}")
        logger.warning(f"allowed hosts are : {settings.ALLOWED_HOSTS}")
        return get_response(request)

    return middleware


class Bunch(dict):
    def __init__(self, *args, **kwargs):
        super(Bunch, self).__init__(*args, **kwargs)
        self.__dict__ = self


def flatten(list_like):
    return [item for sublist in list_like for item in sublist]


def _show_change(date_time, old, new):
    date_time = parse(date_time)
    return "%s: %s ⇨ %s" % (date_time.strftime("%d/%m/%Y at %H:%M"), str(old), str(new))


def iter_history_changes(obj, field):
    changes = obj.json.get("history", {}).get(field, [])
    for d1, d2 in zip(changes, changes[1:]):
        yield _show_change(d1["date_time"], d1["value"], d2["value"])
    # Last change to current value.
    if changes:
        d = changes[-1]
        current = getattr(obj, field, None)
        yield _show_change(d["date_time"], d["value"], current)


def uptime(seconds=False) -> str:

    from django.conf import settings

    now = datetime.now(ZoneInfo(settings.TIME_ZONE))
    if seconds:
        uptime = now - settings.SERVER_START_TIME
        return uptime.total_seconds()

    delta = relativedelta(now, settings.SERVER_START_TIME)
    parts = []
    if delta.years:
        parts.append(f"{delta.years}years")
    if delta.months or parts:
        parts.append(f"{delta.months}months")
    if delta.days or parts:
        parts.append(f"{delta.days}days")
    parts.append(f"{delta.hours:02}h:{delta.minutes:02}m:{delta.seconds:02}s")
    return "-".join(parts)
