"""Olive Log Mint"""
__version__ = "1.0.0"
