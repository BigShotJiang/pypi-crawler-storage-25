# Questra Email

Python Email Client for the Questra API.

## Installation

```bash
pip install seven2one-questra-email
```

## Requirements

- Python >= 3.10

## Quickstart

```python
from seven2one.questra.authentication import QuestraAuthentication
from seven2one.questra.email import QuestraEmail

auth = QuestraAuthentication(
    url="https://authentik.example.com", username="svc", password="secret"
)
client = QuestraEmail(
    url="https://questra.example.com/emailservice/", auth_client=auth
)

client.send(
    to=["user@example.com"],
    subject="Hello",
    text_body="World",
)
```
