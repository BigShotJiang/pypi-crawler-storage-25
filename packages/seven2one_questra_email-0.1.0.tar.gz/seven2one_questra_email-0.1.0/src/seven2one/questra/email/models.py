"""Domain models for the Questra Email service."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ServiceVersion:
    """Version information returned by the email service.

    Attributes:
        version: The semantic version string (e.g. ``"3.2.0"``).
        informational_version: The full informational version including branch
            and commit hash (e.g. ``"3.2.0-feat-version.build-c3234510+..."``).

    Example:
        ```python
        v = client.get_version()
        print(v.version)  # "3.2.0"
        print(v.informational_version)  # "3.2.0-feat-version.build-..."
        ```
    """

    version: str
    informational_version: str

    @classmethod
    def _from_dict(cls, data: dict[str, str]) -> ServiceVersion:
        return cls(
            version=data["Version"],
            informational_version=data["InformationalVersion"],
        )
