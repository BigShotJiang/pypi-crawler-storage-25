"""REST transport layer for Questra Email."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

import requests

from .exceptions import EmailConnectionError, EmailHTTPError

logger = logging.getLogger(__name__)


class RESTTransport:
    """Manages REST transport with Bearer token authentication.

    Args:
        base_url: Base URL of the email service.
        get_access_token_func: Callable that returns a valid access token.
    """

    def __init__(self, base_url: str, get_access_token_func: Callable[[], str]) -> None:
        self._base_url = base_url.rstrip("/")
        self._get_access_token = get_access_token_func
        logger.debug(f"RESTTransport initialized. base_url={self._base_url}")

    def _get_headers(self) -> dict[str, str]:
        access_token = self._get_access_token()
        masked = (
            f"{access_token[:4]}...{access_token[-4:]}"
            if len(access_token) > 8
            else "***"
        )
        logger.debug(f"Access token retrieved. token_preview={masked}")
        return {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }

    def _handle_response(self, response: requests.Response) -> Any:
        if 200 <= response.status_code < 300:
            if response.content:
                content_type = response.headers.get("Content-Type", "")
                if "application/json" in content_type:
                    return response.json()
                return response.text
            return None

        logger.error(
            f"REST request failed. status_code={response.status_code}, "
            f"url={response.url}, response_text={response.text[:500]}"
        )
        try:
            error_data = response.json()
            error_msg = error_data.get("message", response.text)
        except ValueError:
            error_msg = response.text
        raise EmailHTTPError(
            status_code=response.status_code,
            message=error_msg,
            response_text=response.text[:500],
        )

    def get(self, path: str, timeout: int = 30) -> Any:
        """Execute a GET request.

        Args:
            path: Path relative to base URL.
            timeout: Request timeout in seconds.

        Returns:
            Parsed JSON, plain text, or ``None`` for empty responses.
        """
        url = f"{self._base_url}{path}"
        headers = self._get_headers()
        logger.info(f"Executing REST GET request. url={url}")
        try:
            response = requests.get(url, headers=headers, timeout=timeout, verify=True)
            result = self._handle_response(response)
            logger.info("REST GET request completed successfully")
            return result
        except requests.RequestException as e:
            logger.error(f"REST GET request failed. error={str(e)}, url={url}")
            raise EmailConnectionError(str(e)) from e

    def post(self, path: str, json_data: Any | None = None, timeout: int = 30) -> Any:
        """Execute a POST request.

        Args:
            path: Path relative to base URL.
            json_data: JSON-serialisable body.
            timeout: Request timeout in seconds.

        Returns:
            Parsed JSON, plain text, or ``None`` for empty responses.
        """
        url = f"{self._base_url}{path}"
        headers = self._get_headers()
        logger.info(
            f"Executing REST POST request. url={url}, has_body={json_data is not None}"
        )
        try:
            response = requests.post(
                url, headers=headers, json=json_data, timeout=timeout, verify=True
            )
            result = self._handle_response(response)
            logger.info("REST POST request completed successfully")
            return result
        except requests.RequestException as e:
            logger.error(f"REST POST request failed. error={str(e)}, url={url}")
            raise EmailConnectionError(str(e)) from e
