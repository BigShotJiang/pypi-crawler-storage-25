"""
Questra Email - Email Client for Questra API

Example:
    ```python
    from seven2one.questra.authentication import QuestraAuthentication
    from seven2one.questra.email import QuestraEmail

    auth = QuestraAuthentication(
        url="https://authentik.example.com", username="svc", password="secret"
    )
    client = QuestraEmail(
        url="https://questra.example.com/emailservice/", auth_client=auth
    )

    client.send(
        to=["user@example.com"],
        subject="Hello",
        text_body="World",
    )
    ```
"""

import logging
import os
import sys

LOG_LEVEL = os.getenv("questra_email_LOG_LEVEL", "WARNING")
LOG_FORMAT = (
    "%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s"
)

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper(), logging.WARNING),
    format=LOG_FORMAT,
    datefmt="%Y-%m-%d %H:%M:%S",
    stream=sys.stdout,
)

LOG_FILE = os.getenv("questra_email_LOG_FILE")
if LOG_FILE:
    _file_handler = logging.FileHandler(LOG_FILE)
    _file_handler.setLevel(logging.DEBUG)
    _file_handler.setFormatter(
        logging.Formatter(LOG_FORMAT, datefmt="%Y-%m-%d %H:%M:%S")
    )
    logging.getLogger().addHandler(_file_handler)

logger = logging.getLogger(__name__)
logger.debug("Questra Email logger initialized")

from .attachment import Attachment
from .client import QuestraEmail
from .exceptions import EmailConnectionError, EmailError, EmailHTTPError
from .generated.models import SendEmailCommand
from .models import ServiceVersion

__all__ = [
    "QuestraEmail",
    "EmailError",
    "EmailHTTPError",
    "EmailConnectionError",
    "Attachment",
    "SendEmailCommand",
    "ServiceVersion",
]
