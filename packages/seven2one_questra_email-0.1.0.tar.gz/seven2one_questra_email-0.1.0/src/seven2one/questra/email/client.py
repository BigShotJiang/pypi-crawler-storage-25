"""
Questra Email client.
"""

from __future__ import annotations

import base64
import logging

from seven2one.questra.authentication import QuestraAuthentication

from .attachment import Attachment
from .generated.models import Attachment as _GeneratedAttachment
from .generated.models import SendEmailCommand
from .models import ServiceVersion
from .raw_client import _QuestraEmailCore

logger = logging.getLogger(__name__)


class QuestraEmail:
    """Email client for the Questra Email Service.

    Provides a simplified interface for sending emails. For direct access
    to the generated REST operations, use the
    [`raw`][seven2one.questra.email.QuestraEmail.raw] property.

    Args:
        url: Base URL of the email service.
        auth_client: Authenticated :class:`~seven2one.questra.authentication.QuestraAuthentication` instance.

    Environment Variables:
        QUESTRA_EMAIL_URL: Fallback for ``url`` if not passed explicitly.

    Example:
        ```python
        from seven2one.questra.authentication import QuestraAuthentication
        from seven2one.questra.email import QuestraEmail

        auth = QuestraAuthentication(url="...", username="svc", password="secret")

        client = QuestraEmail(
            url="https://questra.example.com/emailservice/",
            auth_client=auth,
        )

        client.send(
            to=["user@example.com"],
            subject="Hello",
            text_body="World",
        )
        ```
    """

    def __init__(
        self,
        url: str | None = None,
        *,
        auth_client: QuestraAuthentication,
    ) -> None:
        logger.info(f"Initializing QuestraEmail. url={url}")
        self._client = _QuestraEmailCore(url=url, auth_client=auth_client)
        logger.info("QuestraEmail initialized successfully")

    def send(
        self,
        *,
        to: str | list[str],
        subject: str,
        text_body: str | None = None,
        html_body: str | None = None,
        cc: str | list[str] | None = None,
        bcc: str | list[str] | None = None,
        attachments: Attachment | list[Attachment] | None = None,
    ) -> None:
        """Send an email.

        Args:
            to: Recipient email address(es). A single string or a list of strings.
            subject: Email subject line.
            text_body: Plain text body.
            html_body: HTML body. At least one of ``text_body`` or ``html_body``
                should be provided.
            cc: CC recipient(s). A single string or a list of strings.
            bcc: BCC recipient(s). A single string or a list of strings.
            attachments: File attachment(s). A single :class:`~seven2one.questra.email.Attachment`
                or a list of them.

        Raises:
            ValueError: If ``to`` is empty, ``subject`` is empty, or neither
                ``text_body`` nor ``html_body`` is provided.
            EmailHTTPError: If the service returns a non-2xx HTTP response.
            EmailConnectionError: If a network error occurs.

        Example:
            ```python
            from seven2one.questra.email import Attachment

            # Single recipient, no attachment
            client.send(
                to="alice@example.com",
                subject="Hello",
                text_body="World",
            )

            # Multiple recipients with attachment
            client.send(
                to=["alice@example.com", "bob@example.com"],
                subject="Report",
                html_body="<p>See attached.</p>",
                attachments=[Attachment("/path/to/report.pdf")],
            )
            ```
        """
        to_list = [to] if isinstance(to, str) else list(to)
        if not to_list:
            raise ValueError("'to' must contain at least one recipient.")
        if not subject:
            raise ValueError("'subject' must not be empty.")
        if text_body is None and html_body is None:
            raise ValueError(
                "At least one of 'text_body' or 'html_body' must be provided."
            )
        cc_list = [cc] if isinstance(cc, str) else cc
        bcc_list = [bcc] if isinstance(bcc, str) else bcc
        attachments_list: list[Attachment] | None = (
            [attachments] if isinstance(attachments, Attachment) else attachments
        )
        built_attachments: list[_GeneratedAttachment] | None = (
            [
                _GeneratedAttachment(
                    file_name=a.resolve_filename(),
                    content=base64.b64encode(a.read_content()).decode(),
                )
                for a in attachments_list
            ]
            if attachments_list is not None
            else None
        )
        command = SendEmailCommand(
            to=to_list,
            subject=subject,
            text_body=text_body,
            html_body=html_body,
            cc=cc_list,
            bcc=bcc_list,
            attachments=built_attachments,
        )
        self._client.email.send(command)

    def get_version(self) -> ServiceVersion:
        """Return version information from the email service.

        Returns:
            ServiceVersion: Service version details.

        Raises:
            EmailHTTPError: If the service returns a non-2xx HTTP response.
            EmailConnectionError: If a network error occurs.

        Example:
            ```python
            v = client.get_version()
            print(v.version)  # "3.2.0"
            print(v.informational_version)  # "3.2.0-feat-..."
            ```
        """
        return self._client.email.get_version()

    @property
    def raw(self) -> _QuestraEmailCore:
        """Direct access to the underlying REST operations.

        Example:
            ```python
            version = client.raw.email.get_version()
            ```
        """
        return self._client
