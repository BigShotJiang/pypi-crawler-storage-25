"""Operations for Questra Email."""

from .email import EmailOperations

__all__ = ["EmailOperations"]
