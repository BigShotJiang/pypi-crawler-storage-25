"""REST operations for Email endpoints."""

from __future__ import annotations

import logging
from collections.abc import Callable

from ..generated.models import SendEmailCommand
from ..models import ServiceVersion

logger = logging.getLogger(__name__)


class EmailOperations:
    """REST operations for the Email service.

    Args:
        rest_get_func: GET request function from the transport layer.
        rest_post_func: POST request function from the transport layer.
    """

    def __init__(self, rest_get_func: Callable, rest_post_func: Callable) -> None:
        self._get = rest_get_func
        self._post = rest_post_func
        logger.debug("EmailOperations initialized")

    def send(self, command: SendEmailCommand) -> None:
        """Send an email.

        Args:
            command: Fully populated ``SendEmailCommand`` describing the email
                to send.

        Raises:
            Exception: On HTTP errors returned by the service.

        Example:
            ```python
            from seven2one.questra.email.generated.models import SendEmailCommand

            client.raw.email.send(
                SendEmailCommand(
                    to=["user@example.com"],
                    subject="Hello",
                    text_body="World",
                )
            )
            ```
        """
        logger.info(f"Sending email. subject={command.subject!r}, to={command.to}")
        payload = command.model_dump(mode="json", by_alias=True, exclude_none=True)
        self._post("/Email", json_data=payload)
        logger.info("Email sent successfully")

    def get_version(self) -> ServiceVersion:
        """Get the service version.

        Returns:
            Version information returned by the service.
        """
        logger.info("Requesting email service version")
        return ServiceVersion._from_dict(self._get("/version"))
