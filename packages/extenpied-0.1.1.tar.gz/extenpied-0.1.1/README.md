#EXTENPIED MODULE V0.1 BUILD 1 (WIP)
#Module to extend python
Features: reverse(), info(), randomization functions, nextwo(), randsort(), It was created loool

#HOW 2 USE

import module first. For example:

import extendpied

If you want to make name shorter, do:

import extendpied as expied

**reverse()** - reverses a string. Example:

print(expied.reverse("Hi!!"))

**info()** - information about variable. Example:

a = 5··
expied.info(a)

**piedfeat()** - information about extenpied. Version, features, etc.

**randlatin()** - randomizes symbol from latin alphabet. Example:

print(expied.randlatin())

prints random latin letter

**randld()** - does the same as randlatin(), but digits are included

print(expied.randld())

**randall()** - get random latin letter, digit or special symbol (like ~ or % etc)

print(expied.randall())

**nextwo** - get exponent of two

print(nextwo(8)) -> 256 (2^8 is 256)

**randsort** - returns a string with randomized letters.

print(randsort("Hello")) -> something like "ohleh" or "lholo"

#LICENSE

Do anything, just mention author (Idose114)

#INSTALLATION

install using pip

Goodbye and be a good boy XD

