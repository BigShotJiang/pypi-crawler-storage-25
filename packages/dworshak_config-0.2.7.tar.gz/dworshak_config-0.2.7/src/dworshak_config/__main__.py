# src/dworshak_config/__main__.py
try:
    from .cli import app
    #from .cli_typer import app
    def run():
        app()
except ImportError:
    #from .cli_stdlib import main as run
    from .cli_argparse import main as run

if __name__ == "__main__":
    run()
