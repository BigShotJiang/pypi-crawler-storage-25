"""NATS event publisher with production-grade error handling.

This module provides a generic NATS event publisher with circuit breaker
integration, optional tracing, and reliable message delivery.
"""

import hashlib
import json
import re
from typing import Any

from robin_commons.log import logger
from robin_commons.resilience.breaker import CircuitBreaker

from .client import NATSClient, NATSConnectionError


class EventPublishError(Exception):
    """Event publishing related errors."""

    pass


class NATSEventPublisher:
    """NATS event publisher with feature flag protection and error handling.

    Single responsibility: Publish events to NATS JetStream with reliability.
    Follows dependency inversion principle with injected NATS client.

    Example:
        publisher = NATSEventPublisher(nats_client)
        await publisher.publish(
            subject="event.user.created",
            stream_name="app-events",
            payload={"user_id": "123"}
        )
    """

    def __init__(
        self,
        nats_client: NATSClient,
        circuit_breaker: CircuitBreaker | None = None,
        traced_patterns: list[str] | None = None,
        ignored_patterns: list[str] | None = None,
    ) -> None:
        """Initialize NATS event publisher.

        Args:
            nats_client: NATS client for connection management
            circuit_breaker: Optional circuit breaker for publishing resilience
            traced_patterns: Optional regex patterns for events to trace
            ignored_patterns: Optional regex patterns for events to ignore in tracing
        """
        self._nats_client = nats_client
        self._circuit_breaker = circuit_breaker
        self._traced_patterns = traced_patterns or []
        self._ignored_patterns = ignored_patterns or []

    def _should_trace_event(self, subject: str) -> bool:
        """Determine if an event should be traced based on patterns.

        Args:
            subject: NATS subject (e.g., "cmd.task.create")

        Returns:
            True if event should be traced, False otherwise
        """
        # Check if explicitly ignored
        for pattern in self._ignored_patterns:
            if re.match(pattern, subject):
                return False

        # Check if matches traced patterns
        for pattern in self._traced_patterns:
            if re.match(pattern, subject):
                return True

        return False

    async def publish(
        self,
        subject: str,
        stream_name: str,
        payload: dict[str, Any],
        enable_deduplication: bool = True,
        enable_tracing: bool = True,
    ) -> None:
        """Publish event to NATS JetStream stream.

        Generic publish method that accepts any subject and stream name.
        Applications define their own event types and stream configurations.

        Args:
            subject: NATS subject (e.g., "event.user.created")
            stream_name: JetStream stream name to publish to
            payload: Event data dictionary
            enable_deduplication: Whether to enable message deduplication
            enable_tracing: Whether to wrap the publish operation in a tracing span
                and propogate trace context when tracing is configured

        Raises:
            EventPublishError: If event publishing fails
        """
        if not self._nats_client.is_connected():
            logger.debug(f"NATS disabled - skipping publish to {stream_name}/{subject}")
            return

        await self._publish_to_stream(
            subject=subject,
            stream_name=stream_name,
            payload=payload,
            event_type="event",
            enable_deduplication=enable_deduplication,
            enable_tracing=enable_tracing,
        )

    async def _publish_to_stream(
        self,
        subject: str,
        stream_name: str,
        payload: dict[str, Any],
        event_type: str,
        enable_deduplication: bool = True,
        enable_tracing: bool = True,
    ) -> None:
        """Internal method to publish event to stream with error handling.

        Args:
            subject: NATS subject
            stream_name: JetStream stream name
            payload: Event payload
            event_type: Event type for logging
            enable_deduplication: Whether to enable message deduplication
            enable_tracing: Whether to add tracing span events

        Raises:
            EventPublishError: If publishing fails after retry logic
        """
        # Import instrumentation helpers
        try:
            from robin_commons.telemetry.nats_instrumentation import (
                add_circuit_breaker_attributes,
                add_publish_attributes,
                nats_operation_span,
                propagate_context_to_headers,
            )

            instrumentation_available = True
        except ImportError:  # pragma: no cover
            instrumentation_available = False

        if self._circuit_breaker and not self._circuit_breaker.can_execute():
            error_msg = f"Circuit breaker is {self._circuit_breaker.get_state()}"
            logger.warning(f"{event_type} publish blocked: {error_msg}")
            raise EventPublishError(error_msg)

        # Create span for publish operation
        span_attributes = {
            "messaging.destination": subject,
            "messaging.nats.stream": stream_name,
            "event.type": event_type,
        }

        async def do_publish() -> tuple[Any, str | None]:
            js = await self._nats_client.get_jetstream()

            # Serialize payload
            serialized = json.dumps(payload).encode()

            # Generate message ID for deduplication
            headers = {}
            msg_id = None
            if enable_deduplication:
                msg_id = hashlib.sha256(serialized).hexdigest()
                headers["Nats-Msg-Id"] = msg_id

            # Propagate trace context to message headers
            if instrumentation_available and enable_tracing:
                headers = propagate_context_to_headers(headers)

            # Publish with ACK
            ack = await js.publish(subject, serialized, headers=headers or None)

            logger.debug(
                f"Published {event_type} to {stream_name}/{subject} (seq={ack.seq})"
            )

            return ack, msg_id

        try:
            if (
                instrumentation_available
                and enable_tracing
                and self._should_trace_event(subject)
            ):
                # Use proper span instead of span event
                async with nats_operation_span(
                    "publish", attributes=span_attributes
                ) as span:
                    # Add circuit breaker state
                    if self._circuit_breaker:
                        add_circuit_breaker_attributes(  # pragma: no cover
                            span,
                            self._circuit_breaker.get_state().value,
                            True,
                        )

                    ack, msg_id = await do_publish()

                    # Add publish-specific attributes
                    add_publish_attributes(
                        span,
                        subject,
                        stream_name,
                        msg_id,
                        ack.seq,
                    )
            else:
                # No instrumentation or tracing disabled
                await do_publish()

            if self._circuit_breaker:
                self._circuit_breaker.record_success()

        except NATSConnectionError as e:
            error_msg = f"NATS not connected for {event_type}: {e}"
            logger.error(error_msg)
            if self._circuit_breaker:  # pragma: no cover
                self._circuit_breaker.record_failure()
            raise EventPublishError(error_msg) from e

        except Exception as e:
            error_msg = (
                f"Failed to publish {event_type} to {stream_name}/{subject}: {e}"
            )
            logger.error(error_msg, exc_info=True)
            if self._circuit_breaker:
                self._circuit_breaker.record_failure()
            raise EventPublishError(error_msg) from e

    async def health_check(self) -> bool:
        """Check if publisher can publish events.

        Returns:
            True if NATS is connected and publisher is healthy
        """
        if not self._nats_client.is_connected():
            return False

        if self._circuit_breaker:
            return self._circuit_breaker.can_execute()

        return True
