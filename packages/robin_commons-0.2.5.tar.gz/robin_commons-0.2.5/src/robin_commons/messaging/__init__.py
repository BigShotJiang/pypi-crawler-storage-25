"""NATS messaging module for robin-commons.

Provides generic NATS messaging infrastructure with JetStream support.
"""

from .client import NATSClient, NATSConnectionError
from .config import ConfigProvider, NATSConfig, StreamConfig
from .consumer import (
    ConsumerConfig,
    ConsumerError,
    MessageHandler,
    NATSConsumer,
    RetryInfo,
)
from .publisher import EventPublishError, NATSEventPublisher

__all__ = [
    # Client
    "NATSClient",
    "NATSConnectionError",
    # Configuration
    "ConfigProvider",
    "NATSConfig",
    "StreamConfig",
    # Consumer
    "ConsumerConfig",
    "ConsumerError",
    "MessageHandler",
    "NATSConsumer",
    "RetryInfo",
    # Publisher
    "EventPublishError",
    "NATSEventPublisher",
]
