"""NATS client connection management with resilience and monitoring.

This module provides NATS connection lifecycle management with circuit breaker
integration, automatic retry logic, and JetStream setup capabilities.
"""

import asyncio
from typing import Any

import nats
from nats.aio.client import Client as NATSConnection
from nats.js import JetStreamContext

from robin_commons.log import logger
from robin_commons.resilience.breaker import CircuitBreaker

from .config import NATSConfig


class NATSConnectionError(Exception):
    """NATS connection related errors."""

    pass


class NATSClient:
    """NATS client with feature flag protection and connection management.

    Single responsibility: Manage NATS connection lifecycle.
    Follows dependency inversion principle with injected configuration.

    Example:
        config = NATSConfig(config_provider, feature_flags, stream_configs)
        client = NATSClient(config)
        await client.connect()
        js = await client.get_jetstream()
    """

    def __init__(
        self, config: NATSConfig, circuit_breaker: CircuitBreaker | None = None
    ) -> None:
        """Initialize NATS client.

        Args:
            config: NATS configuration management
            circuit_breaker: Optional circuit breaker for connection resilience
        """
        self._config = config
        self._circuit_breaker = circuit_breaker
        self._connection: NATSConnection | None = None
        self._jetstream: JetStreamContext | None = None
        self._is_connected = False

    async def connect(self, max_retries: int = 10, base_delay: float = 1.0) -> None:
        """Establish NATS connection with retry logic.

        Blocks until connection succeeds or max retries exceeded.
        Uses exponential backoff: 1s, 2s, 4s, 8s, 16s, 32s (capped at 30s).

        Args:
            max_retries: Maximum connection attempts (default: 10)
            base_delay: Initial retry delay in seconds (default: 1.0)

        Raises:
            NATSConnectionError: After all retries exhausted
        """
        if not self._config.is_enabled():
            logger.info("NATS integration disabled via feature flag")
            return

        # Import instrumentation helper
        try:
            from robin_commons.telemetry.nats_instrumentation import (
                add_connection_attributes,
                nats_operation_span,
            )

            add_connection_attributes_fn = add_connection_attributes
            nats_operation_span_fn = nats_operation_span
        except ImportError:  # pragma: no cover
            # Instrumentation not available, continue without tracing
            add_connection_attributes_fn = None
            nats_operation_span_fn = None

        max_delay = 30.0
        current_delay = base_delay

        # Create span for the entire connection operation
        if nats_operation_span_fn:
            async with nats_operation_span_fn(
                "connect",
                attributes={"net.peer.name": self._config.get_server_url()},
            ) as span:
                success = await self._attempt_connection(
                    max_retries,
                    current_delay,
                    max_delay,
                    span,
                    add_connection_attributes_fn,
                )
                if not success:  # pragma: no cover
                    error_msg = (
                        f"Failed to connect to NATS after {max_retries} attempts"
                    )
                    raise NATSConnectionError(error_msg)
            return

        # No instrumentation, just attempt connection
        await self._attempt_connection_without_tracing(  # pragma: no cover
            max_retries, current_delay, max_delay
        )

    async def _attempt_connection(
        self,
        max_retries: int,
        current_delay: float,
        max_delay: float,
        span: Any,
        add_connection_attributes: Any,
    ) -> bool:
        """Attempt NATS connection with tracing."""
        last_error: Exception | None = None

        for attempt in range(1, max_retries + 1):
            try:
                if self._circuit_breaker and not self._circuit_breaker.can_execute():
                    error_msg = (
                        f"Circuit breaker is {self._circuit_breaker.get_state()}"
                    )
                    if add_connection_attributes:  # pragma: no cover
                        from robin_commons.telemetry.nats_instrumentation import (
                            add_circuit_breaker_attributes,
                        )

                        add_circuit_breaker_attributes(
                            span,
                            self._circuit_breaker.get_state().value,
                            False,
                        )
                    raise NATSConnectionError(error_msg)

                if add_connection_attributes:  # pragma: no cover
                    add_connection_attributes(
                        span,
                        self._config.get_server_url(),
                        attempt,
                        max_retries,
                    )

                logger.info(
                    f"NATS connection attempt {attempt}/{max_retries} "
                    f"to {self._config.get_server_url()}"
                )

                self._connection = await nats.connect(
                    servers=[self._config.get_server_url()],
                    connect_timeout=self._config.get_connection_timeout(),
                    max_reconnect_attempts=self._config.get_max_reconnect_attempts(),
                    reconnect_time_wait=self._config.get_reconnect_delay(),
                    reconnected_cb=self._on_reconnected,
                    disconnected_cb=self._on_disconnected,
                    error_cb=self._on_error,
                    closed_cb=self._on_closed,
                )

                self._is_connected = True
                logger.info(f"NATS connected successfully after {attempt} attempt(s)")

                if self._circuit_breaker:
                    self._circuit_breaker.record_success()

                span.set_attribute("messaging.nats.connected", True)
                return True

            except Exception as e:
                last_error = e
                if self._circuit_breaker:
                    self._circuit_breaker.record_failure()

                if attempt < max_retries:
                    logger.warning(
                        f"NATS connection attempt {attempt} failed: {e}. "
                        f"Retrying in {current_delay:.1f}s..."
                    )
                    await asyncio.sleep(current_delay)
                    current_delay = min(current_delay * 2, max_delay)
                else:
                    logger.error(
                        f"NATS connection failed after {max_retries} attempts: {e}",
                        exc_info=True,
                    )

        span.set_attribute("messaging.nats.connected", False)
        error_msg = (
            f"Failed to connect to NATS after {max_retries} attempts: {last_error}"
        )
        raise NATSConnectionError(error_msg) from last_error

    async def _attempt_connection_without_tracing(  # pragma: no cover
        self, max_retries: int, current_delay: float, max_delay: float
    ) -> None:
        """Attempt NATS connection without tracing (fallback)."""
        last_error: Exception | None = None

        for attempt in range(1, max_retries + 1):
            try:
                if self._circuit_breaker and not self._circuit_breaker.can_execute():
                    raise NATSConnectionError(
                        f"Circuit breaker is {self._circuit_breaker.get_state()}"
                    )

                logger.info(
                    f"NATS connection attempt {attempt}/{max_retries} "
                    f"to {self._config.get_server_url()}"
                )

                self._connection = await nats.connect(
                    servers=[self._config.get_server_url()],
                    connect_timeout=self._config.get_connection_timeout(),
                    max_reconnect_attempts=self._config.get_max_reconnect_attempts(),
                    reconnect_time_wait=self._config.get_reconnect_delay(),
                    reconnected_cb=self._on_reconnected,
                    disconnected_cb=self._on_disconnected,
                    error_cb=self._on_error,
                    closed_cb=self._on_closed,
                )

                self._is_connected = True
                logger.info(f"NATS connected successfully after {attempt} attempt(s)")

                if self._circuit_breaker:
                    self._circuit_breaker.record_success()
                return

            except Exception as e:
                last_error = e
                if self._circuit_breaker:
                    self._circuit_breaker.record_failure()

                if attempt < max_retries:
                    logger.warning(
                        f"NATS connection attempt {attempt} failed: {e}. "
                        f"Retrying in {current_delay:.1f}s..."
                    )
                    await asyncio.sleep(current_delay)
                    current_delay = min(current_delay * 2, max_delay)
                else:
                    logger.error(
                        f"NATS connection failed after {max_retries} attempts: {e}",
                        exc_info=True,
                    )

        error_msg = (
            f"Failed to connect to NATS after {max_retries} attempts: {last_error}"
        )
        raise NATSConnectionError(error_msg) from last_error

    async def disconnect(self) -> None:
        """Gracefully disconnect from NATS server."""
        if not (self._connection and self._is_connected):
            return

        try:
            from robin_commons.telemetry.nats_instrumentation import nats_operation_span

            nats_operation_span_fn = nats_operation_span
        except ImportError:  # pragma: no cover
            nats_operation_span_fn = None

        try:
            if nats_operation_span_fn:
                async with nats_operation_span_fn("disconnect"):
                    await self._connection.close()
                    logger.info("NATS connection closed gracefully")
                return

            await self._connection.close()
            logger.info("NATS connection closed gracefully")
        except Exception as e:
            logger.warning(f"Error during NATS disconnect: {e}")
        finally:
            self._is_connected = False
            self._connection = None
            self._jetstream = None

    async def get_jetstream(self) -> JetStreamContext:
        """Get JetStream context for stream operations.

        Automatically configures domain if configured via JETSTREAM_DOMAIN.
        Domain is required when NATS server uses JetStream domains.

        Returns:
            JetStream context for publishing and subscribing

        Raises:
            NATSConnectionError: If not connected to NATS
        """
        if not self._is_connected or not self._connection:
            raise NATSConnectionError("Not connected to NATS server")

        if not self._jetstream:
            # Get domain from config for multi-domain NATS clusters
            domain = self._config.get_jetstream_domain()

            if domain:
                self._jetstream = self._connection.jetstream(domain=domain)
                logger.info(f"JetStream context initialized with domain: {domain}")
            else:
                self._jetstream = self._connection.jetstream()
                logger.debug("JetStream context initialized (no domain)")

        return self._jetstream

    async def setup_jetstream(self) -> None:
        """Setup JetStream streams based on configuration.

        Creates streams defined in NATSConfig.stream_configs.
        Idempotent - safe to call multiple times.

        Raises:
            NATSConnectionError: If JetStream setup fails
        """
        if not self._config.is_enabled():
            return

        try:
            js = await self.get_jetstream()
            stream_configs = self._config.get_stream_configs()

            for stream_name, stream_config in stream_configs.items():
                try:
                    # Check if stream already exists
                    await js.stream_info(stream_name)
                    logger.debug(f"JetStream stream '{stream_name}' already exists")
                except Exception:
                    # Stream doesn't exist, create it
                    await js.add_stream(
                        name=stream_config.name,
                        subjects=stream_config.subjects,
                        max_msgs=stream_config.max_msgs,
                        max_bytes=stream_config.max_bytes,
                        max_age=stream_config.max_age,  # Library expects seconds
                        storage=stream_config.storage,
                        num_replicas=stream_config.replicas,
                        duplicate_window=stream_config.duplicate_window,  # seconds
                    )
                    logger.info(f"Created JetStream stream: {stream_name}")

            logger.info("JetStream streams setup completed")

        except Exception as e:
            error_msg = f"Failed to setup JetStream: {e}"
            logger.error(error_msg, exc_info=True)
            raise NATSConnectionError(error_msg) from e

    def is_connected(self) -> bool:
        """Check if currently connected to NATS.

        Returns:
            True if connected, False otherwise
        """
        return self._is_connected and self._connection is not None

    async def _on_reconnected(self) -> None:
        """Handle NATS reconnection events."""
        self._is_connected = True
        logger.info("NATS reconnected successfully")

    async def _on_disconnected(self) -> None:
        """Handle NATS disconnection events."""
        self._is_connected = False
        logger.warning("NATS connection lost")

    async def _on_error(self, error: Exception) -> None:
        """Handle NATS connection errors.

        Args:
            error: The error that occurred
        """
        logger.error(f"NATS connection error: {error}")

    async def _on_closed(self) -> None:
        """Handle NATS connection closed events."""
        self._is_connected = False
        logger.info("NATS connection closed")
