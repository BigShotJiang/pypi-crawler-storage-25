"""NATS consumer implementation with lifecycle management and retry logic.

Provides a generic JetStream consumer with:
- Consumer lifecycle (start, stop, health check)
- Message fetching/subscription
- Acknowledgment handling (ack/nak)
- Retry logic with exponential backoff
- Circuit breaker integration
- Optional Dead Letter Queue
"""

import asyncio
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Protocol

from nats.js.api import AckPolicy, DeliverPolicy
from nats.js.api import ConsumerConfig as JetStreamConsumerConfig

from robin_commons.log import logger
from robin_commons.resilience.breaker import CircuitBreaker

from .client import NATSClient, NATSConnectionError


class MessageHandler(Protocol):
    """Protocol for processing NATS messages.

    Implementations should handle message processing logic and raise
    exceptions for failures that should trigger retries.
    """

    async def handle_message(
        self,
        subject: str,
        data: bytes,
        headers: dict[str, str] | None = None,
        metadata: Any | None = None,
    ) -> None:
        """Process a message from NATS.

        Args:
            subject: Message subject
            data: Raw message data
            headers: Optional message headers
            metadata: Optional NATS metadata (sequence, timestamp, etc.)

        Raises:
            Exception: If message processing fails (will trigger retry)
        """
        ...


@dataclass
class ConsumerConfig:
    """Configuration for NATS JetStream consumer.

    Args:
        stream_name: Name of the JetStream stream to consume from
        subject: Subject filter for messages (supports wildcards)
        durable_name: Optional durable consumer name for persistence
        queue_group: Optional queue group for load balancing
        deliver_policy: Message delivery policy ("new", "all", "last", "by_start_sequence", "by_start_time")
        ack_policy: Acknowledgment policy ("explicit", "none", "all")
        max_deliver: Maximum delivery attempts before message is discarded
        ack_wait_seconds: Time to wait for acknowledgment before redelivery
    """

    stream_name: str
    subject: str
    durable_name: str | None = None
    queue_group: str | None = None
    deliver_policy: str = "new"
    ack_policy: str = "explicit"
    max_deliver: int = 5
    ack_wait_seconds: int = 30

    def to_jetstream_config(self) -> JetStreamConsumerConfig:
        """Convert to NATS JetStream ConsumerConfig."""
        # Map string policy names to NATS enums
        deliver_policy_map = {
            "new": DeliverPolicy.NEW,
            "all": DeliverPolicy.ALL,
            "last": DeliverPolicy.LAST,
            "by_start_sequence": DeliverPolicy.BY_START_SEQUENCE,
            "by_start_time": DeliverPolicy.BY_START_TIME,
        }

        ack_policy_map = {
            "explicit": AckPolicy.EXPLICIT,
            "none": AckPolicy.NONE,
            "all": AckPolicy.ALL,
        }

        return JetStreamConsumerConfig(
            durable_name=self.durable_name,
            deliver_policy=deliver_policy_map.get(
                self.deliver_policy, DeliverPolicy.NEW
            ),
            ack_policy=ack_policy_map.get(self.ack_policy, AckPolicy.EXPLICIT),
            max_deliver=self.max_deliver,
            ack_wait=self.ack_wait_seconds,
        )


@dataclass
class RetryInfo:
    """Track retry attempts for messages."""

    message_id: str
    subject: str
    attempt_count: int
    first_attempt: datetime
    last_attempt: datetime
    error_message: str


class ConsumerError(Exception):
    """NATS consumer related errors."""

    pass


class NATSConsumer:
    """Generic NATS JetStream consumer with lifecycle management.

    Provides:
    - Consumer lifecycle (start, stop, health check)
    - Message fetching/subscription
    - Acknowledgment handling
    - Retry logic with exponential backoff
    - Circuit breaker integration
    - Optional Dead Letter Queue

    Example:
        ```python
        # Define message handler
        class MyHandler:
            async def handle_message(self, subject: str, data: bytes, headers=None, metadata=None):
                payload = json.loads(data.decode())
                print(f"Received: {payload}")

        # Setup consumer
        config = ConsumerConfig(
            stream_name="my-stream",
            subject="events.*",
            durable_name="my-consumer"
        )
        consumer = NATSConsumer(nats_client, config, MyHandler())

        # Start consuming
        await consumer.start()

        # Health check
        health = await consumer.health_check()

        # Stop when done
        await consumer.stop()
        ```
    """

    def __init__(
        self,
        nats_client: NATSClient,
        config: ConsumerConfig,
        handler: MessageHandler,
        circuit_breaker: CircuitBreaker | None = None,
        max_retries: int = 3,
        retry_backoff_seconds: int = 2,
        enable_dlq: bool = False,
        dlq_subject: str | None = None,
    ) -> None:
        """Initialize NATS consumer.

        Args:
            nats_client: NATS client for connection
            config: Consumer configuration
            handler: Message handler for processing
            circuit_breaker: Optional circuit breaker for resilience
            max_retries: Maximum retry attempts before DLQ/discard (default: 3)
            retry_backoff_seconds: Base backoff seconds for exponential backoff (default: 2)
            enable_dlq: Enable dead letter queue for failed messages (default: False)
            dlq_subject: Subject for DLQ messages (default: "dlq.{stream_name}")
        """
        self._nats_client = nats_client
        self._config = config
        self._handler = handler
        self._circuit_breaker = circuit_breaker
        self._max_retries = max_retries
        self._retry_backoff_seconds = retry_backoff_seconds
        self._enable_dlq = enable_dlq
        self._dlq_subject = dlq_subject or f"dlq.{config.stream_name}"

        # Consumer state
        self._is_running = False
        self._consumer_task: asyncio.Task[None] | None = None
        self._subscription: Any = None
        self._retry_tracker: dict[str, RetryInfo] = {}
        self._dlq_count = 0
        self._processed_count = 0
        self._error_count = 0
        self._last_error: Exception | None = None

        logger.debug(
            "NATS consumer initialized",
            extra={
                "stream": config.stream_name,
                "subject": config.subject,
                "durable": config.durable_name,
                "queue_group": config.queue_group,
            },
        )

    async def start(self) -> None:
        """Start consuming messages from JetStream.

        The consume loop handles its own subscribe lifecycle with stale consumer
        cleanup and retry logic for resilience across pod restarts.

        Raises:
            ConsumerError: If consumer cannot be started
            NATSConnectionError: If NATS client is not connected
        """
        if self._is_running:
            logger.debug("Consumer already running")
            return

        if not self._nats_client.is_connected():
            raise NATSConnectionError("NATS client not connected")

        try:
            self._is_running = True
            self._consumer_task = asyncio.create_task(self._consume_loop())

            logger.info(
                "NATS consumer started",
                extra={
                    "stream": self._config.stream_name,
                    "subject": self._config.subject,
                    "durable": self._config.durable_name,
                },
            )

        except Exception as e:
            self._is_running = False
            error_msg = f"Failed to start consumer: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise ConsumerError(error_msg) from e

    async def stop(self) -> None:
        """Stop consuming messages and cleanup resources."""
        if not self._is_running:
            logger.debug("Consumer not running")
            return

        self._is_running = False

        # Cancel consumer task
        if self._consumer_task:
            self._consumer_task.cancel()
            try:
                await self._consumer_task
            except asyncio.CancelledError:
                pass
            self._consumer_task = None

        # Unsubscribe
        if self._subscription:
            try:
                await self._subscription.unsubscribe()
            except Exception as e:
                logger.warning(f"Error unsubscribing: {e}")
            self._subscription = None

        # Clear retry tracker
        self._retry_tracker.clear()

        logger.info(
            "NATS consumer stopped",
            extra={
                "processed": self._processed_count,
                "errors": self._error_count,
                "dlq": self._dlq_count,
            },
        )

    async def health_check(self) -> dict[str, Any]:
        """Check consumer health status.

        Returns:
            Dictionary with health information including:
            - running: Whether consumer is active
            - connected: Whether NATS client is connected
            - circuit_state: Circuit breaker state (if enabled)
            - processed_count: Number of messages processed
            - error_count: Number of errors encountered
            - dlq_count: Number of messages moved to DLQ
            - last_error: Last error message (if any)
        """
        health = {
            "running": self._is_running,
            "connected": self._nats_client.is_connected(),
            "processed_count": self._processed_count,
            "error_count": self._error_count,
            "dlq_count": self._dlq_count,
            "last_error": str(self._last_error) if self._last_error else None,
        }

        if self._circuit_breaker:
            health["circuit_state"] = str(self._circuit_breaker.get_state())

        return health

    def is_running(self) -> bool:
        """Check if consumer is currently running.

        Returns:
            True if consumer is active, False otherwise
        """
        return self._is_running

    async def _cleanup_stale_consumer(self) -> None:
        """Delete durable consumer if it has no active subscribers.

        Multi-pod safe: only deletes when push_bound is False (no active subscriber).
        Skips cleanup when no durable_name is configured.
        """
        if not self._config.durable_name:
            return

        try:
            jetstream = await self._nats_client.get_jetstream()
            info = await jetstream.consumer_info(
                self._config.stream_name, self._config.durable_name
            )
            if not info.push_bound:
                await jetstream.delete_consumer(
                    self._config.stream_name, self._config.durable_name
                )
                logger.info(
                    "Deleted stale consumer",
                    extra={
                        "stream": self._config.stream_name,
                        "durable": self._config.durable_name,
                        "push_bound": False,
                        "action": "delete",
                    },
                )
            else:
                logger.debug(
                    f"Consumer '{self._config.durable_name}' has active subscribers, "
                    f"skipping cleanup"
                )
        except Exception as e:
            logger.debug(
                f"Stale consumer cleanup for '{self._config.durable_name}': {e}"
            )

    async def _subscribe_with_retry(
        self,
        max_attempts: int = 3,
        base_delay: float = 2.0,
    ) -> Any:
        """Subscribe to JetStream with retry for consumer creation race conditions.

        Args:
            max_attempts: Maximum subscription attempts
            base_delay: Initial backoff delay in seconds

        Returns:
            NATS push subscription

        Raises:
            Exception: If all retry attempts fail
        """
        jetstream = await self._nats_client.get_jetstream()
        js_config = self._config.to_jetstream_config()
        delay = base_delay

        for attempt in range(1, max_attempts + 1):
            try:
                return await jetstream.subscribe(
                    subject=self._config.subject,
                    stream=self._config.stream_name,
                    queue=self._config.queue_group,
                    config=js_config,
                )
            except Exception as e:
                if attempt < max_attempts:
                    logger.warning(
                        f"Subscribe attempt {attempt}/{max_attempts} failed: {e}. "
                        f"Retrying in {delay}s..."
                    )
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 30.0)
                else:
                    raise

    async def _consume_loop(self) -> None:
        """Self-healing message consumption loop.

        Handles stale consumer cleanup, subscribe-with-retry, and automatic
        reconnection on subscription failures. Exits via CancelledError when
        stop() cancels the task.
        """
        while self._is_running:
            try:
                await self._cleanup_stale_consumer()
                self._subscription = await self._subscribe_with_retry()

                try:
                    async for message in self._subscription.messages:
                        await self._process_message(message)
                finally:
                    # Best-effort cleanup of the current JetStream subscription
                    if self._subscription is not None:
                        try:
                            await self._subscription.unsubscribe()
                        except Exception as unsubscribe_error:
                            logger.warning(
                                "Failed to unsubscribe JetStream subscription during cleanup: "
                                f"{unsubscribe_error}",
                                exc_info=True,
                            )
                        finally:
                            self._subscription = None

            except Exception as e:
                self._last_error = e
                logger.warning(
                    f"Consumer loop error, restarting in 5s: {e}",
                    exc_info=True,
                )
                await asyncio.sleep(5)

    async def _process_message(self, message: Any) -> None:
        """Process a single message with retry logic.

        Args:
            message: NATS message object
        """
        message_id = self._get_message_id(message)

        try:
            # Check circuit breaker
            if self._circuit_breaker and not self._circuit_breaker.can_execute():
                logger.warning(
                    "Circuit breaker open, skipping message",
                    extra={"message_id": message_id, "subject": message.subject},
                )
                await message.nak()
                return

            # Extract message data
            subject = message.subject
            data = message.data
            headers = getattr(message, "headers", None)
            metadata = getattr(message, "metadata", None)

            # Process message
            await self._handler.handle_message(subject, data, headers, metadata)

            # Success: acknowledge message
            await message.ack()
            self._processed_count += 1

            # Clear retry tracker for this message
            if message_id in self._retry_tracker:
                del self._retry_tracker[message_id]

            # Record success in circuit breaker
            if self._circuit_breaker:
                self._circuit_breaker.record_success()

            logger.debug(
                "Message processed successfully",
                extra={"message_id": message_id, "subject": subject},
            )

        except Exception as e:
            self._error_count += 1
            self._last_error = e

            # Record failure in circuit breaker
            if self._circuit_breaker:
                self._circuit_breaker.record_failure()

            # Handle retry logic
            await self._handle_message_error(message, message_id, e)

    def _get_message_id(self, message: Any) -> str:
        """Get unique message identifier for retry tracking."""
        try:
            return str(message.metadata.sequence.stream)
        except Exception:
            # Fallback to timestamp-based ID
            return f"{message.subject}_{datetime.now(UTC).timestamp()}"

    async def _handle_message_error(
        self, message: Any, message_id: str, error: Exception
    ) -> None:
        """Handle message processing error with retry tracking.

        Args:
            message: NATS message that failed
            message_id: Unique message identifier
            error: Exception that occurred
        """
        # Get or create retry info
        if message_id not in self._retry_tracker:
            self._retry_tracker[message_id] = RetryInfo(
                message_id=message_id,
                subject=message.subject,
                attempt_count=1,
                first_attempt=datetime.now(UTC),
                last_attempt=datetime.now(UTC),
                error_message=str(error),
            )
        else:
            retry_info = self._retry_tracker[message_id]
            retry_info.attempt_count += 1
            retry_info.last_attempt = datetime.now(UTC)
            retry_info.error_message = str(error)

        retry_info = self._retry_tracker[message_id]

        # Check if max retries exceeded
        if retry_info.attempt_count >= self._max_retries:
            logger.error(
                "Message exceeded max retries",
                extra={
                    "message_id": message_id,
                    "subject": message.subject,
                    "attempts": retry_info.attempt_count,
                    "error": str(error),
                },
            )

            # Move to DLQ or acknowledge to remove from stream
            if self._enable_dlq:
                await self._move_to_dlq(message, retry_info)

            await message.ack()  # Remove from stream
            del self._retry_tracker[message_id]
            return

        # Calculate exponential backoff
        backoff_seconds = self._retry_backoff_seconds * (
            2 ** (retry_info.attempt_count - 1)
        )

        logger.warning(
            "Message processing failed, will retry",
            extra={
                "message_id": message_id,
                "subject": message.subject,
                "attempt": retry_info.attempt_count,
                "max_retries": self._max_retries,
                "backoff_seconds": backoff_seconds,
                "error": str(error),
            },
        )

        # NAK message for redelivery, using server-side delay when supported
        try:
            await message.nak_with_delay(delay=backoff_seconds)
        except (TypeError, AttributeError):
            # Fallback for clients that do not support the delay argument
            await message.nak()
            # Apply backoff
            await asyncio.sleep(backoff_seconds)

    async def _move_to_dlq(self, message: Any, retry_info: RetryInfo) -> None:
        """Move failed message to dead letter queue.

        Args:
            message: NATS message that failed
            retry_info: Retry tracking information
        """
        try:
            import json

            dlq_payload = {
                "original_subject": message.subject,
                "original_data": message.data.decode(),
                "message_id": retry_info.message_id,
                "retry_info": {
                    "attempts": retry_info.attempt_count,
                    "first_attempt": retry_info.first_attempt.isoformat(),
                    "last_attempt": retry_info.last_attempt.isoformat(),
                    "error_message": retry_info.error_message,
                },
                "timestamp": datetime.now(UTC).isoformat(),
            }

            # Publish to DLQ subject
            jetstream = await self._nats_client.get_jetstream()
            await jetstream.publish(
                subject=self._dlq_subject,
                payload=json.dumps(dlq_payload).encode(),
            )

            self._dlq_count += 1

            logger.error(
                "Message moved to DLQ",
                extra={
                    "message_id": retry_info.message_id,
                    "subject": message.subject,
                    "dlq_subject": self._dlq_subject,
                    "attempts": retry_info.attempt_count,
                },
            )

        except Exception as dlq_error:
            logger.critical(
                "Failed to move message to DLQ",
                extra={
                    "message_id": retry_info.message_id,
                    "subject": message.subject,
                    "dlq_error": str(dlq_error),
                },
                exc_info=True,
            )
