"""NATS configuration management with protocol-based dependency injection.

This module provides configuration classes for NATS JetStream with support
for dependency injection via Protocol classes. Applications implement the
ConfigProvider and FeatureFlagProvider protocols to integrate with their
own configuration systems.
"""

from dataclasses import dataclass
from typing import Protocol

from robin_commons.features import FeatureFlagProvider


@dataclass(frozen=True)
class StreamConfig:
    """Configuration for a NATS JetStream stream.

    Defines stream behavior including retention, storage, and delivery settings.
    Applications define their own stream configurations based on their needs.

    Args:
        name: Stream name (must be unique)
        subjects: List of NATS subjects this stream captures (supports wildcards)
        max_msgs: Maximum number of messages to retain
        max_bytes: Maximum total size of messages in bytes
        max_age: Maximum age of messages in seconds
        storage: Storage type ("file" or "memory")
        replicas: Number of stream replicas for high availability
        max_deliver: Maximum delivery attempts before moving to DLQ
        duplicate_window: Deduplication window in seconds for network retry protection

    Example:
        config = StreamConfig(
            name="app-events",
            subjects=["event.>"],
            max_msgs=100000,
            max_bytes=268435456,  # 256MB
            max_age=86400,  # 1 day
        )
    """

    name: str
    subjects: list[str]
    max_msgs: int = 1000000
    max_bytes: int = 1073741824  # 1GB
    max_age: int = 2592000  # 30 days in seconds
    storage: str = "file"
    replicas: int = 1
    max_deliver: int = 5
    duplicate_window: int = 120  # seconds


class ConfigProvider(Protocol):
    """Protocol for NATS configuration providers.

    Applications implement this protocol to provide NATS connection settings
    from their preferred configuration source (env vars, config files, database, etc.).

    Example:
        class MyConfigProvider:
            def get_nats_url(self) -> str:
                return os.getenv("NATS_URL", "nats://localhost:4222")

            def get_nats_connection_timeout(self) -> int:
                return int(os.getenv("NATS_TIMEOUT", "5"))

            # ... implement other methods
    """

    def get_nats_url(self) -> str:
        """Get NATS server URL.

        Returns:
            NATS server URL (e.g., "nats://localhost:4222")
        """
        ...

    def get_nats_connection_timeout(self) -> int:
        """Get NATS connection timeout in seconds.

        Returns:
            Connection timeout in seconds
        """
        ...

    def get_nats_max_reconnect_attempts(self) -> int:
        """Get maximum NATS reconnection attempts.

        Returns:
            Maximum reconnection attempts
        """
        ...

    def get_nats_reconnect_delay(self) -> int:
        """Get NATS reconnection delay in seconds.

        Returns:
            Reconnection delay in seconds
        """
        ...

    def get_jetstream_domain(self) -> str | None:
        """Get JetStream domain configuration.

        JetStream domains provide namespace isolation for multi-environment deployments.
        When NATS server is configured with a domain, clients must specify it.

        Returns:
            Domain name or None for default domain
        """
        ...


class NATSConfig:
    """NATS configuration with injected dependencies.

    Stream configurations are passed at initialization, allowing
    each application to define its own event streams and subjects.

    Example:
        from robin_commons.features import EnvironmentFeatureFlags

        class MyConfig:
            def get_nats_url(self): return "nats://localhost:4222"
            # ... implement other methods

        streams = {
            "app-events": StreamConfig(
                name="app-events",
                subjects=["event.>"],
            )
        }

        config = NATSConfig(
            config=MyConfig(),
            feature_flags=EnvironmentFeatureFlags(),
            stream_configs=streams,
        )
    """

    def __init__(
        self,
        config: ConfigProvider,
        feature_flags: FeatureFlagProvider,
        stream_configs: dict[str, StreamConfig] | None = None,
    ) -> None:
        """Initialize NATS configuration.

        Args:
            config: Configuration provider for NATS settings
            feature_flags: Feature flags provider for NATS enablement
            stream_configs: Optional dictionary mapping stream names to configurations
        """
        self._config = config
        self._feature_flags = feature_flags
        self._stream_configs = stream_configs or {}

    def is_enabled(self) -> bool:
        """Check if NATS integration is enabled via feature flag.

        Checks the "nats_enabled" feature flag.

        Returns:
            True if NATS integration is enabled, False otherwise
        """
        return self._feature_flags.is_enabled("nats_enabled")

    def get_server_url(self) -> str:
        """Get NATS server URL.

        Returns:
            NATS server URL from configuration
        """
        return self._config.get_nats_url()

    def get_connection_timeout(self) -> int:
        """Get NATS connection timeout in seconds.

        Returns:
            Connection timeout in seconds
        """
        return self._config.get_nats_connection_timeout()

    def get_max_reconnect_attempts(self) -> int:
        """Get maximum NATS reconnection attempts.

        Returns:
            Maximum reconnection attempts
        """
        return self._config.get_nats_max_reconnect_attempts()

    def get_reconnect_delay(self) -> int:
        """Get NATS reconnection delay in seconds.

        Returns:
            Reconnection delay in seconds
        """
        return self._config.get_nats_reconnect_delay()

    def get_jetstream_domain(self) -> str | None:
        """Get JetStream domain configuration.

        Returns:
            Domain name from configuration or None for default domain
        """
        return self._config.get_jetstream_domain()

    def get_stream_configs(self) -> dict[str, StreamConfig]:
        """Get JetStream stream configurations.

        Returns:
            Dictionary mapping stream names to their configurations
        """
        return self._stream_configs
