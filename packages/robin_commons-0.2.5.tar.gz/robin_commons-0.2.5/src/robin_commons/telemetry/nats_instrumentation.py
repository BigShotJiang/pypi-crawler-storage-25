"""OpenTelemetry instrumentation helpers for NATS messaging.

Provides utilities for tracing NATS operations following OpenTelemetry
semantic conventions for messaging systems.
"""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from opentelemetry import trace
from opentelemetry.trace import Span, Status, StatusCode, Tracer

from robin_commons.telemetry.config import get_observability_config

# Get tracer for NATS operations
_tracer: Tracer | None = None


def get_nats_tracer() -> Tracer:
    """Get or create the NATS tracer instance."""
    global _tracer
    if _tracer is None:
        _tracer = trace.get_tracer("robin_commons.messaging.nats")
    return _tracer


def is_nats_instrumentation_enabled() -> bool:
    """Check if NATS instrumentation is enabled."""
    config = get_observability_config()
    return config.is_nats_instrumentation_enabled()


@asynccontextmanager
async def nats_operation_span(
    operation: str,
    attributes: dict[str, Any] | None = None,
    record_exception: bool = True,
) -> AsyncIterator[Span]:
    """Context manager for NATS operation spans.

    Args:
        operation: Operation name (e.g., "connect", "publish", "receive")
        attributes: Additional span attributes
        record_exception: Whether to record exceptions in span

    Yields:
        OpenTelemetry Span
    """
    if not is_nats_instrumentation_enabled():
        # Create a no-op span when instrumentation is disabled
        with trace.get_tracer(__name__).start_as_current_span(
            f"nats.{operation}", record_exception=False
        ) as span:
            yield span
        return

    tracer = get_nats_tracer()
    span_name = f"nats.{operation}"

    # Base attributes following OpenTelemetry semantic conventions
    span_attributes = {
        "messaging.system": "nats",
        "messaging.operation": operation,
    }

    if attributes:
        span_attributes.update(attributes)

    with tracer.start_as_current_span(span_name, attributes=span_attributes) as span:
        try:
            yield span
        except Exception as e:
            if record_exception:
                span.record_exception(e)
                span.set_status(Status(StatusCode.ERROR, str(e)))
            raise


def add_connection_attributes(
    span: Span,
    server_url: str,
    retry_attempt: int | None = None,
    max_retries: int | None = None,
) -> None:
    """Add connection-specific attributes to span.

    Args:
        span: OpenTelemetry span
        server_url: NATS server URL
        retry_attempt: Current retry attempt number
        max_retries: Maximum retry attempts
    """
    if not is_nats_instrumentation_enabled():
        return

    span.set_attribute("net.peer.name", server_url)

    if retry_attempt is not None:
        span.set_attribute("messaging.nats.retry_attempt", retry_attempt)

    if max_retries is not None:
        span.set_attribute("messaging.nats.max_retries", max_retries)


def add_publish_attributes(
    span: Span,
    subject: str,
    stream_name: str,
    message_id: str | None = None,
    sequence: int | None = None,
) -> None:
    """Add publish-specific attributes to span.

    Args:
        span: OpenTelemetry span
        subject: NATS subject
        stream_name: JetStream stream name
        message_id: Message deduplication ID
        sequence: JetStream sequence number
    """
    if not is_nats_instrumentation_enabled():
        return

    span.set_attribute("messaging.destination", subject)
    span.set_attribute("messaging.nats.stream", stream_name)

    if message_id:
        span.set_attribute("messaging.message.id", message_id)

    if sequence is not None:
        span.set_attribute("messaging.nats.sequence", sequence)


def add_consume_attributes(
    span: Span,
    subject: str,
    stream_name: str,
    durable_name: str | None = None,
    retry_count: int | None = None,
    dlq_enabled: bool = False,
) -> None:
    """Add consume-specific attributes to span.

    Args:
        span: OpenTelemetry span
        subject: NATS subject
        stream_name: JetStream stream name
        durable_name: Consumer durable name
        retry_count: Number of retries
        dlq_enabled: Whether DLQ is enabled
    """
    if not is_nats_instrumentation_enabled():
        return

    span.set_attribute("messaging.source", subject)
    span.set_attribute("messaging.nats.stream", stream_name)

    if durable_name:
        span.set_attribute("messaging.nats.consumer.durable_name", durable_name)

    if retry_count is not None:
        span.set_attribute("messaging.nats.retry_count", retry_count)

    if dlq_enabled:
        span.set_attribute("messaging.nats.dlq_enabled", True)


def add_jetstream_attributes(
    span: Span,
    stream_name: str,
    subjects: list[str] | None = None,
) -> None:
    """Add JetStream-specific attributes to span.

    Args:
        span: OpenTelemetry span
        stream_name: JetStream stream name
        subjects: Stream subjects
    """
    if not is_nats_instrumentation_enabled():
        return

    span.set_attribute("messaging.nats.stream", stream_name)

    if subjects:
        span.set_attribute("messaging.nats.stream.subjects", ",".join(subjects))


def add_circuit_breaker_attributes(
    span: Span,
    circuit_state: str,
    can_execute: bool,
) -> None:
    """Add circuit breaker attributes to span.

    Args:
        span: OpenTelemetry span
        circuit_state: Circuit breaker state
        can_execute: Whether circuit allows execution
    """
    if not is_nats_instrumentation_enabled():
        return

    span.set_attribute("messaging.nats.circuit_breaker.state", circuit_state)
    span.set_attribute("messaging.nats.circuit_breaker.can_execute", can_execute)


def propagate_context_to_headers(
    headers: dict[str, str] | None = None,
) -> dict[str, str]:
    """Inject trace context into NATS message headers for distributed tracing.

    Args:
        headers: Existing message headers

    Returns:
        Headers with injected trace context
    """
    if not is_nats_instrumentation_enabled():
        return headers.copy() if headers else {}

    from opentelemetry.propagate import inject

    result_headers = headers.copy() if headers else {}
    inject(result_headers)
    return result_headers


def extract_context_from_headers(headers: dict[str, str] | None) -> Any | None:
    """Extract trace context from NATS message headers.

    Sets the extracted context as the current context for downstream spans.

    Returns:
        A token from ``opentelemetry.context.attach`` that can be passed to
        ``opentelemetry.context.detach`` to restore the previous context, or
        ``None`` if instrumentation is disabled or no headers are provided.

    Args:
        headers: Message headers
    """
    if not is_nats_instrumentation_enabled() or not headers:
        return None

    from opentelemetry.context import attach
    from opentelemetry.propagate import extract

    context = extract(headers)
    token = attach(context)
    return token
