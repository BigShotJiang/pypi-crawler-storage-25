"""Feature flag provider protocols for dependency injection.

This module defines the generic interface for feature flag providers,
allowing applications to implement feature flags with any backend
(environment variables, database, LaunchDarkly, etc.).
"""

from typing import Any, Protocol


class FeatureFlagProvider(Protocol):
    """Generic interface for feature flag providers.

    Applications can implement this protocol with any backend:
    environment variables, database, LaunchDarkly, etc.

    Example:
        class MyFeatureFlags:
            def is_enabled(self, flag_name: str) -> bool:
                # Custom implementation
                return check_flag(flag_name)

            def get_value(self, flag_name: str, default: Any = None) -> Any:
                # Custom implementation
                return get_flag_value(flag_name, default)
    """

    def is_enabled(self, flag_name: str) -> bool:
        """Check if a feature flag is enabled.

        Args:
            flag_name: Name of the feature flag

        Returns:
            True if feature is enabled, False otherwise
        """
        ...

    def get_value(self, flag_name: str, default: Any = None) -> Any:
        """Get feature flag value with optional default.

        Args:
            flag_name: Name of the feature flag
            default: Default value if flag not found

        Returns:
            Flag value or default
        """
        ...
