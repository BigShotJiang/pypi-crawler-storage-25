"""Feature flags module for robin-commons.

Provides generic feature flag abstractions for dependency injection.
"""

from .env_flags import EnvironmentFeatureFlags
from .protocols import FeatureFlagProvider

__all__ = [
    "FeatureFlagProvider",
    "EnvironmentFeatureFlags",
]
