"""Environment variable-based feature flags implementation.

Simple feature flag provider that reads from environment variables.
Useful for development, testing, and simple production deployments.
"""

import os
from typing import Any


class EnvironmentFeatureFlags:
    """Environment variable-based feature flags.

    Reads feature flags from environment variables with configurable prefix.

    Example:
        # Set environment variable: FEATURE_NATS_ENABLED=true
        flags = EnvironmentFeatureFlags()
        if flags.is_enabled("nats_enabled"):
            print("NATS is enabled")

        # Custom prefix
        flags = EnvironmentFeatureFlags(prefix="APP_FLAG_")
        # Reads from: APP_FLAG_MY_FEATURE=true
    """

    def __init__(self, prefix: str = "FEATURE_") -> None:
        """Initialize environment-based feature flags.

        Args:
            prefix: Environment variable prefix for feature flags
        """
        self.prefix = prefix

    def is_enabled(self, flag_name: str) -> bool:
        """Check if a feature flag is enabled via environment variable.

        Converts flag name to uppercase and prepends prefix.
        Treats "true", "1", "yes" (case-insensitive) as enabled.

        Args:
            flag_name: Name of the feature flag

        Returns:
            True if feature is enabled, False otherwise

        Example:
            # FEATURE_NATS_ENABLED=true
            flags.is_enabled("nats_enabled")  # Returns True
        """
        var_name = f"{self.prefix}{flag_name.upper()}"
        return os.getenv(var_name, "false").lower() in ("true", "1", "yes")

    def get_value(self, flag_name: str, default: Any = None) -> Any:
        """Get feature flag value from environment variable.

        Args:
            flag_name: Name of the feature flag
            default: Default value if flag not found

        Returns:
            Flag value from environment or default

        Example:
            # FEATURE_MAX_CONNECTIONS=100
            max_conn = flags.get_value("max_connections", default="10")
            # Returns "100"
        """
        var_name = f"{self.prefix}{flag_name.upper()}"
        return os.getenv(var_name, default)
