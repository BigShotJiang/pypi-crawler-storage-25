"""Redis client with automatic cluster detection and connection management.

This module provides a production-ready Redis client that automatically detects
whether to use cluster or single-node mode, with connection pooling and resilience.

Adapted from robin-ai's cache module for use in robin-commons.
"""

from __future__ import annotations

import builtins
from collections.abc import AsyncIterator, Callable
from typing import Any
from urllib.parse import quote

import redis.asyncio as redis
from redis.asyncio.cluster import RedisCluster
from redis.exceptions import RedisClusterException

from robin_commons.cache.config import RedisCacheConfig
from robin_commons.log import logger
from robin_commons.resilience.breaker import CircuitBreaker


class RedisClient:
    """Unified Redis client supporting both cluster and single-node modes.

    This wrapper provides a consistent interface regardless of whether Redis
    is running in cluster mode or single-node mode. All methods delegate to
    the underlying redis-py client with minimal overhead (~50ns per call).

    The wrapper exposes the most commonly used Redis operations while hiding
    the complexity of cluster vs single-node differences.
    """

    def __init__(
        self,
        client: redis.Redis | RedisCluster,
        is_cluster: bool,
        circuit_breaker: CircuitBreaker | None = None,
    ):
        """Initialize Redis client wrapper.

        Args:
            client: Underlying redis.Redis or RedisCluster instance
            is_cluster: True if using cluster mode, False for single-node
            circuit_breaker: Optional circuit breaker for operation protection
        """
        self._client = client
        self._is_cluster = is_cluster
        self._circuit_breaker = circuit_breaker

    async def _execute_with_breaker(
        self, operation: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> Any:
        """Execute operation with optional circuit breaker protection.

        Args:
            operation: Async operation to execute
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Result of the operation

        Raises:
            CircuitBreakerError: If circuit breaker is open
        """
        if self._circuit_breaker is None:
            # No circuit breaker, execute directly
            return await operation(*args, **kwargs)

        # Execute with circuit breaker protection
        async with self._circuit_breaker:
            return await operation(*args, **kwargs)

    # ============================================
    # Core String Operations
    # ============================================

    async def get(self, key: str) -> str | None:
        """Get value for a key.

        Args:
            key: Redis key

        Returns:
            Value as string or None if key doesn't exist
        """
        return await self._execute_with_breaker(self._client.get, key)

    async def set(
        self, key: str, value: str, ex: int | None = None, px: int | None = None
    ) -> bool:
        """Set key to value with optional expiration.

        Args:
            key: Redis key
            value: Value to store
            ex: Expiration in seconds
            px: Expiration in milliseconds

        Returns:
            True if successful
        """
        return await self._execute_with_breaker(
            self._client.set, key, value, ex=ex, px=px
        )

    async def setex(self, key: str, seconds: int, value: str) -> bool:
        """Set key with expiration time in seconds.

        Args:
            key: Redis key
            seconds: TTL in seconds
            value: Value to store

        Returns:
            True if successful
        """
        return await self._execute_with_breaker(self._client.setex, key, seconds, value)

    async def delete(self, *keys: str) -> int:
        """Delete one or more keys.

        Args:
            *keys: One or more Redis keys to delete

        Returns:
            Number of keys deleted
        """
        return await self._execute_with_breaker(self._client.delete, *keys)

    async def exists(self, *keys: str) -> int:
        """Check if keys exist.

        Args:
            *keys: One or more Redis keys to check

        Returns:
            Number of keys that exist
        """
        return await self._execute_with_breaker(self._client.exists, *keys)

    # ============================================
    # Hash Operations
    # ============================================

    async def hget(self, name: str, key: str) -> str | None:
        """Get value of hash field.

        Args:
            name: Hash key
            key: Field name

        Returns:
            Field value or None if not found
        """
        return await self._execute_with_breaker(self._client.hget, name, key)

    async def hset(
        self,
        name: str,
        key: str | None = None,
        value: str | None = None,
        mapping: dict[str, str] | None = None,
    ) -> int:
        """Set hash field or multiple fields.

        Args:
            name: Hash key
            key: Field name (if setting single field)
            value: Field value (if setting single field)
            mapping: Dict of field:value pairs (if setting multiple fields)

        Returns:
            Number of fields added
        """
        return await self._execute_with_breaker(
            self._client.hset, name, key, value, mapping=mapping
        )

    async def hgetall(self, name: str) -> dict[str, str]:
        """Get all fields and values from hash.

        Args:
            name: Hash key

        Returns:
            Dict of field:value pairs
        """
        return await self._execute_with_breaker(self._client.hgetall, name)

    async def hdel(self, name: str, *keys: str) -> int:
        """Delete hash fields.

        Args:
            name: Hash key
            *keys: Field names to delete

        Returns:
            Number of fields deleted
        """
        return await self._execute_with_breaker(self._client.hdel, name, *keys)

    # ============================================
    # List Operations
    # ============================================

    async def lpush(self, name: str, *values: str) -> int:
        """Push values to the head of a list.

        Args:
            name: List key
            *values: Values to push

        Returns:
            Length of list after push
        """
        return await self._execute_with_breaker(self._client.lpush, name, *values)

    async def rpush(self, name: str, *values: str) -> int:
        """Push values to the tail of a list.

        Args:
            name: List key
            *values: Values to push

        Returns:
            Length of list after push
        """
        return await self._execute_with_breaker(self._client.rpush, name, *values)

    async def lpop(self, name: str, count: int | None = None) -> str | list[str] | None:
        """Remove and return values from head of list.

        Args:
            name: List key
            count: Number of elements to pop (None for 1)

        Returns:
            Single value if count is None, list of values if count > 1,
            or None if list is empty
        """
        return await self._execute_with_breaker(self._client.lpop, name, count)

    async def rpop(self, name: str, count: int | None = None) -> str | list[str] | None:
        """Remove and return values from tail of list.

        Args:
            name: List key
            count: Number of elements to pop (None for 1)

        Returns:
            Single value if count is None, list of values if count > 1,
            or None if list is empty
        """
        return await self._execute_with_breaker(self._client.rpop, name, count)

    async def lrange(self, name: str, start: int, end: int) -> list[str]:
        """Get range of values from list.

        Args:
            name: List key
            start: Start index (0-based, supports negative indexing)
            end: End index (inclusive, supports negative indexing)

        Returns:
            List of values in range
        """
        return await self._execute_with_breaker(self._client.lrange, name, start, end)

    async def llen(self, name: str) -> int:
        """Get length of list.

        Args:
            name: List key

        Returns:
            Length of list
        """
        return await self._execute_with_breaker(self._client.llen, name)

    # ============================================
    # Set Operations
    # ============================================

    async def sadd(self, name: str, *members: str) -> int:
        """Add members to a set.

        Args:
            name: Set key
            *members: Members to add

        Returns:
            Number of members added (not already existing)
        """
        return await self._execute_with_breaker(self._client.sadd, name, *members)

    async def srem(self, name: str, *members: str) -> int:
        """Remove members from a set.

        Args:
            name: Set key
            *members: Members to remove

        Returns:
            Number of members removed
        """
        return await self._execute_with_breaker(self._client.srem, name, *members)

    async def smembers(self, name: str) -> builtins.set[str]:
        """Get all members of a set.

        Args:
            name: Set key

        Returns:
            Set of all members
        """
        return await self._execute_with_breaker(self._client.smembers, name)

    async def scard(self, name: str) -> int:
        """Get cardinality (size) of a set.

        Args:
            name: Set key

        Returns:
            Number of members in set
        """
        return await self._execute_with_breaker(self._client.scard, name)

    async def sismember(self, name: str, member: str) -> bool:
        """Check if member exists in set.

        Args:
            name: Set key
            member: Member to check

        Returns:
            True if member exists, False otherwise
        """
        return await self._execute_with_breaker(self._client.sismember, name, member)

    # ============================================
    # Sorted Set Operations
    # ============================================

    async def zadd(
        self,
        name: str,
        mapping: dict[str, float],
    ) -> int:
        """Add members to sorted set with scores.

        Args:
            name: Sorted set key
            mapping: Dict of member:score pairs

        Returns:
            Number of members added

        Example:
            >>> await client.zadd("leaderboard", {"alice": 1000, "bob": 1500})
            2
        """
        return await self._execute_with_breaker(self._client.zadd, name, mapping)

    async def zrem(self, name: str, *members: str) -> int:
        """Remove members from sorted set.

        Args:
            name: Sorted set key
            *members: Members to remove

        Returns:
            Number of members removed
        """
        return await self._execute_with_breaker(self._client.zrem, name, *members)

    async def zrange(
        self, name: str, start: int, end: int, withscores: bool = False
    ) -> list[str] | list[tuple[str, float]]:
        """Get range of members from sorted set.

        Args:
            name: Sorted set key
            start: Start index (0-based)
            end: End index (inclusive)
            withscores: Include scores in result

        Returns:
            List of members or list of (member, score) tuples
        """
        return await self._execute_with_breaker(
            self._client.zrange, name, start, end, withscores=withscores
        )

    async def zscore(self, name: str, member: str) -> float | None:
        """Get score of member in sorted set.

        Args:
            name: Sorted set key
            member: Member name

        Returns:
            Score as float or None if member doesn't exist
        """
        return await self._execute_with_breaker(self._client.zscore, name, member)

    async def zcard(self, name: str) -> int:
        """Get cardinality (size) of sorted set.

        Args:
            name: Sorted set key

        Returns:
            Number of members in sorted set
        """
        return await self._execute_with_breaker(self._client.zcard, name)

    # ============================================
    # Key Discovery Operations
    # ============================================

    async def keys(self, pattern: str = "*") -> list[str]:
        """Find all keys matching pattern.

        WARNING: This command can be very slow on large Redis instances
        as it blocks the server. Use scan() for iterative scanning instead,
        especially in production environments with large keyspaces.

        Args:
            pattern: Key pattern to match (supports * and ? wildcards)

        Returns:
            List of matching keys
        """
        return await self._execute_with_breaker(self._client.keys, pattern)

    async def scan(
        self, cursor: int = 0, match: str | None = None, count: int | None = None
    ) -> tuple[int, list[str]]:
        """Incrementally scan keys from the keyspace.

        This is a non-blocking alternative to keys() that returns results
        in batches. Iterate using the returned cursor until it returns 0.

        Args:
            cursor: Scan position (start with 0)
            match: Optional pattern to match
            count: Approximate number of keys per iteration

        Returns:
            Tuple of (next_cursor, list_of_keys)

        Example:
            >>> cursor = 0
            >>> all_keys = []
            >>> while True:
            ...     cursor, keys = await client.scan(cursor, match="user:*")
            ...     all_keys.extend(keys)
            ...     if cursor == 0:
            ...         break
        """
        return await self._execute_with_breaker(
            self._client.scan, cursor, match=match, count=count
        )

    async def _scan_iter_protected(
        self, match: str | None = None, count: int | None = None
    ) -> AsyncIterator[str]:
        """Internal async generator that wraps scan_iter with breaker protection.

        Args:
            match: Optional pattern to match
            count: Approximate number of keys per iteration

        Yields:
            Keys from the keyspace

        Raises:
            CircuitBreakerError: If circuit breaker is open
        """
        if self._circuit_breaker is None:
            # No circuit breaker, iterate directly
            async for key in self._client.scan_iter(match=match, count=count):
                yield key
        else:
            # Check breaker before starting iteration
            async with self._circuit_breaker:
                async for key in self._client.scan_iter(match=match, count=count):
                    yield key

    def scan_iter(
        self, match: str | None = None, count: int | None = None
    ) -> AsyncIterator[str]:
        """Iterate over keys in the keyspace using SCAN.

        This returns an async iterator that automatically handles cursor
        management for scanning large keyspaces without blocking. The iterator
        is protected by the circuit breaker using the same pattern as other
        operations.

        Args:
            match: Optional pattern to match
            count: Approximate number of keys per iteration

        Returns:
            Async iterator yielding keys

        Raises:
            CircuitBreakerError: If circuit breaker is open

        Example:
            >>> async for key in client.scan_iter(match="user:*"):
            ...     await client.delete(key)
        """
        return self._scan_iter_protected(match=match, count=count)

    # ============================================
    # Key Management Operations
    # ============================================

    async def expire(self, key: str, seconds: int) -> bool:
        """Set expiration time for a key in seconds.

        Args:
            key: Redis key
            seconds: TTL in seconds

        Returns:
            True if timeout was set, False if key doesn't exist
        """
        return await self._execute_with_breaker(self._client.expire, key, seconds)

    async def expireat(self, key: str, timestamp: int) -> bool:
        """Set expiration time for a key using Unix timestamp.

        Args:
            key: Redis key
            timestamp: Unix timestamp (seconds since epoch)

        Returns:
            True if timeout was set, False if key doesn't exist
        """
        return await self._execute_with_breaker(self._client.expireat, key, timestamp)

    async def pexpire(self, key: str, milliseconds: int) -> bool:
        """Set expiration time for a key in milliseconds.

        Args:
            key: Redis key
            milliseconds: TTL in milliseconds

        Returns:
            True if timeout was set, False if key doesn't exist
        """
        return await self._execute_with_breaker(self._client.pexpire, key, milliseconds)

    async def ttl(self, key: str) -> int:
        """Get remaining time to live for a key in seconds.

        Args:
            key: Redis key

        Returns:
            TTL in seconds (-2 if key doesn't exist, -1 if no expiration)
        """
        return await self._execute_with_breaker(self._client.ttl, key)

    async def pttl(self, key: str) -> int:
        """Get remaining time to live for a key in milliseconds.

        Args:
            key: Redis key

        Returns:
            TTL in milliseconds (-2 if key doesn't exist, -1 if no expiration)
        """
        return await self._execute_with_breaker(self._client.pttl, key)

    async def type(self, key: str) -> str:
        """Get the type of a key.

        Args:
            key: Redis key

        Returns:
            Key type (string, list, set, zset, hash, stream, etc.)
        """
        return await self._execute_with_breaker(self._client.type, key)

    async def rename(self, key: str, newkey: str) -> bool:
        """Rename a key.

        Args:
            key: Current key name
            newkey: New key name

        Returns:
            True if successful

        Raises:
            redis.ResponseError: If key doesn't exist
        """
        return await self._execute_with_breaker(self._client.rename, key, newkey)

    async def renamenx(self, key: str, newkey: str) -> bool:
        """Rename a key only if new key doesn't exist.

        Args:
            key: Current key name
            newkey: New key name

        Returns:
            True if successful, False if newkey already exists
        """
        return await self._execute_with_breaker(self._client.renamenx, key, newkey)

    # ============================================
    # Server Operations
    # ============================================

    async def dbsize(self) -> int:
        """Get the number of keys in current database.

        Returns:
            Number of keys in database
        """
        return await self._execute_with_breaker(self._client.dbsize)

    async def info(self, section: str | None = None) -> dict[str, Any]:
        """Get server information.

        Args:
            section: Specific section to retrieve (e.g., 'server', 'clients',
                'memory'). If None, returns all sections.

        Returns:
            Dictionary containing server information
        """
        return await self._execute_with_breaker(self._client.info, section)

    # ============================================
    # Utility Methods
    # ============================================

    async def ping(self) -> bool:
        """Ping Redis to check connection.

        Returns:
            True if ping successful
        """
        response = await self._execute_with_breaker(self._client.ping)
        return response is True

    async def close(self) -> None:
        """Close the Redis connection."""
        await self._client.close()

    # ============================================
    # Properties
    # ============================================

    @property
    def is_cluster_mode(self) -> bool:
        """Check if using cluster mode.

        Returns:
            True if cluster mode, False for single-node
        """
        return self._is_cluster


# Module state (initialized during lifespan)
_redis_client: RedisClient | None = None

_is_cluster_mode: bool = False
_redis_host: str = "redis"
_redis_port: int = 6379
_redis_password: str | None = None


def _build_redis_url(host: str, port: int, password: str | None, ssl: bool) -> str:
    """Build Redis URL with authentication.

    Args:
        host: Redis host
        port: Redis port
        password: Redis password (optional)
        ssl: Whether to use SSL (rediss:// vs redis://)

    Returns:
        Redis URL string with credentials

    Example:
        >>> _build_redis_url("localhost", 6379, None, False)
        'redis://localhost:6379/0'
        >>> _build_redis_url("redis.example.com", 6379, "secret", True)
        'rediss://:secret@redis.example.com:6379/0'
    """
    scheme = "rediss" if ssl else "redis"
    if password:
        encoded_password = quote(password, safe="")
        return f"{scheme}://:{encoded_password}@{host}:{port}/0"
    return f"{scheme}://{host}:{port}/0"


async def detect_and_create_client(
    config: RedisCacheConfig | None = None,
    circuit_breaker: CircuitBreaker | None = None,
) -> RedisClient:
    """Auto-detect Redis mode and create appropriate client.

    Attempts to connect to Redis cluster mode first. If that fails (cluster mode
    not available or connection refused), falls back to single-node mode.

    Args:
        config: Redis configuration. If None, creates default config from environment.
        circuit_breaker: Optional circuit breaker for operation protection.
            If None, no circuit breaker will be used.

    Returns:
        RedisClient instance with optional circuit breaker protection

    Raises:
        redis.ConnectionError: If unable to connect to Redis
        redis.RedisError: If Redis is unreachable or misconfigured

    Example:
        >>> from robin_commons.cache import detect_and_create_client, RedisCacheConfig
        >>> config = RedisCacheConfig()
        >>> client = await detect_and_create_client(config)
        >>> await client.ping()
        True
        >>> await client.close()
    """
    global _redis_client, _is_cluster_mode, _redis_host, _redis_port, _redis_password

    # Use provided config or create from environment
    if config is None:
        config = RedisCacheConfig()

    # Store config for later access
    _redis_host = config.get_host()
    _redis_port = config.get_port()
    _redis_password = config.get_password()

    # Build URL with authentication
    redis_url = _build_redis_url(
        config.get_host(),
        config.get_port(),
        config.get_password(),
        config.is_ssl_enabled(),
    )
    logger.debug(
        f"Redis URL built for host={config.get_host()}, port={config.get_port()}, ssl={config.is_ssl_enabled()}"
    )

    # Try cluster mode first
    cluster_client: RedisCluster | None = None
    cluster_promoted = False
    try:
        cluster_client = RedisCluster.from_url(
            redis_url,
            decode_responses=True,
            ssl=config.is_ssl_enabled(),
        )
        await cluster_client.ping()
        _is_cluster_mode = True

        # Wrap in RedisClient
        wrapped_client = RedisClient(
            cluster_client, is_cluster=True, circuit_breaker=circuit_breaker
        )
        _redis_client = wrapped_client
        cluster_promoted = True
        logger.info(f"Redis cluster mode initialized (SSL={config.is_ssl_enabled()})")
        return wrapped_client
    except (RedisClusterException, TypeError) as e:
        # TypeError: older redis-py versions don't support some kwargs
        logger.debug(f"Cluster mode not available: {e}")
    except Exception as e:
        logger.debug(f"Cluster mode connection failed: {e}")
    finally:
        # Close cluster client if it was created but not promoted
        if cluster_client is not None and not cluster_promoted:
            try:
                await cluster_client.close()
            except Exception as e:
                logger.debug(f"Failed to close cluster client during fallback: {e}")

    # Fallback to single-node
    pool: redis.ConnectionPool = redis.ConnectionPool.from_url(
        redis_url,
        decode_responses=True,
        max_connections=config.get_max_connections(),
        retry_on_timeout=True,
    )
    single_client: redis.Redis = redis.Redis(connection_pool=pool)
    await single_client.ping()
    _is_cluster_mode = False

    # Wrap in RedisClient
    wrapped_client = RedisClient(
        single_client, is_cluster=False, circuit_breaker=circuit_breaker
    )
    _redis_client = wrapped_client
    logger.info(f"Redis single-node mode initialized (SSL={config.is_ssl_enabled()})")
    return wrapped_client


def is_cluster_mode() -> bool:
    """Check if Redis is running in cluster mode.

    Returns:
        True if connected to Redis cluster, False for single-node

    Example:
        >>> from robin_commons.cache import detect_and_create_client, is_cluster_mode
        >>> await detect_and_create_client()
        >>> if is_cluster_mode():
        ...     print("Using Redis cluster")
        ... else:
        ...     print("Using single-node Redis")
    """
    return _is_cluster_mode


def get_redis_config() -> tuple[str, int, str | None]:
    """Get Redis connection config (host, port, password).

    Used by cache services when connection_pool access fails or when
    creating custom clients.

    Returns:
        Tuple of (host, port, password)

    Example:
        >>> from robin_commons.cache import detect_and_create_client, get_redis_config
        >>> await detect_and_create_client()
        >>> host, port, password = get_redis_config()
        >>> print(f"Connected to {host}:{port}")
    """
    return _redis_host, _redis_port, _redis_password


def get_cached_client() -> RedisClient | None:
    """Get the cached Redis client (initialized during lifespan).

    Returns:
        Redis client if initialized, None otherwise

    Example:
        >>> from robin_commons.cache import detect_and_create_client, get_cached_client
        >>> await detect_and_create_client()
        >>> client = get_cached_client()
        >>> if client:
        ...     await client.set("key", "value")
    """
    return _redis_client


async def close_redis_connection() -> None:
    """Close Redis connection. Usually called during shutdown.

    Example:
        >>> from robin_commons.cache import detect_and_create_client, close_redis_connection
        >>> client = await detect_and_create_client()
        >>> # ... use client ...
        >>> await close_redis_connection()
    """
    global _redis_client
    if _redis_client is not None:
        await _redis_client.close()
        _redis_client = None
        logger.info("Redis connection closed")
