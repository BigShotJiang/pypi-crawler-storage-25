"""FastAPI dependency injection helpers for Redis client.

This module provides dependency functions for injecting Redis clients into
FastAPI route handlers.
"""

from collections.abc import AsyncGenerator

from robin_commons.cache.client import RedisClient, get_cached_client


async def get_redis_client() -> AsyncGenerator[RedisClient]:
    """FastAPI dependency for async Redis client.

    Provides an async Redis client with automatic connection management.
    Use this as a dependency in FastAPI route handlers.

    Yields:
        RedisClient: Async Redis client for cache operations

    Raises:
        RuntimeError: If Redis client not initialized (lifespan not run)

    Example:
        >>> from fastapi import FastAPI, Depends
        >>> from robin_commons.cache import get_redis_client, detect_and_create_client
        >>>
        >>> app = FastAPI()
        >>>
        >>> @app.on_event("startup")
        >>> async def startup():
        ...     await detect_and_create_client()
        >>>
        >>> @app.get("/items/{item_id}")
        >>> async def get_item(item_id: str, redis=Depends(get_redis_client)):
        ...     cached = await redis.get(f"item:{item_id}")
        ...     return {"item": cached}
    """
    client = get_cached_client()
    if client is None:
        raise RuntimeError("Redis client not initialized. Ensure lifespan has run.")
    yield client


async def get_redis_connection() -> RedisClient:
    """Get a Redis client instance.

    Direct access to Redis client without dependency injection.
    Useful for non-route contexts like background tasks.

    Returns:
        RedisClient: Async Redis client instance

    Raises:
        RuntimeError: If Redis client not initialized (lifespan not run)

    Example:
        >>> from robin_commons.cache import get_redis_connection
        >>>
        >>> async def background_task():
        ...     redis = await get_redis_connection()
        ...     await redis.set("background:task", "completed")
    """
    client = get_cached_client()
    if client is None:
        raise RuntimeError("Redis client not initialized. Ensure lifespan has run.")
    return client
