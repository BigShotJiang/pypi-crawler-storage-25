"""Redis cache configuration using environment variables.

This module provides environment-based configuration for Redis connections,
supporting both single-node and cluster deployments.

Follows the robin-commons configuration pattern using plain classes with
os.getenv() instead of Pydantic settings.
"""

import os


class RedisCacheConfig:
    """Redis cache configuration from environment variables.

    All settings are loaded from environment variables with REDIS_ prefix.

    Environment Variables:
        REDIS_HOST: Redis server host (default: "redis")
        REDIS_PORT: Redis server port (default: 6379)
        REDIS_PASSWORD: Redis password for authentication (optional)
        REDIS_SSL_ENABLED: Enable SSL/TLS connections (default: false)
        REDIS_MAX_CONNECTIONS: Maximum connection pool size (default: 20)

    Example:
        >>> from robin_commons.cache import RedisCacheConfig
        >>> config = RedisCacheConfig()
        >>> config.get_host()
        'redis'

        Using environment variables:
        >>> import os
        >>> os.environ["REDIS_HOST"] = "redis.example.com"
        >>> os.environ["REDIS_SSL_ENABLED"] = "true"
        >>> config = RedisCacheConfig()
        >>> config.get_host()
        'redis.example.com'
        >>> config.is_ssl_enabled()
        True
    """

    def get_host(self) -> str:
        """Get Redis server hostname or IP address.

        Returns:
            Redis host from REDIS_HOST environment variable
        """
        return os.getenv("REDIS_HOST", "redis")

    def get_port(self) -> int:
        """Get Redis server port number.

        Returns:
            Redis port from REDIS_PORT environment variable
        """
        return int(os.getenv("REDIS_PORT", "6379"))

    def get_password(self) -> str | None:
        """Get Redis password for authentication.

        Returns:
            Redis password from REDIS_PASSWORD environment variable, or None
        """
        return os.getenv("REDIS_PASSWORD")

    def is_ssl_enabled(self) -> bool:
        """Check if SSL/TLS is enabled for Redis connections.

        Returns:
            True if SSL enabled, False otherwise
        """
        return os.getenv("REDIS_SSL_ENABLED", "false").lower() == "true"

    def get_max_connections(self) -> int:
        """Get maximum number of connections in the pool.

        Returns:
            Maximum connections from REDIS_MAX_CONNECTIONS environment variable
        """
        return int(os.getenv("REDIS_MAX_CONNECTIONS", "20"))
