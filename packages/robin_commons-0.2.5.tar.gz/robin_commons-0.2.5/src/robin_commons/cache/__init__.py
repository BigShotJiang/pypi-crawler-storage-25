"""Redis cache module with cluster auto-detection and circuit breaker protection.

This module provides production-grade Redis client infrastructure with:
- Automatic cluster mode detection (AWS ElastiCache compatible)
- Connection pooling with configurable limits
- SSL/TLS support
- Circuit breaker protection for resilience
- FastAPI dependency injection
- OpenTelemetry instrumentation

Example:
    Basic usage:
        >>> from robin_commons.cache import detect_and_create_client, RedisCacheConfig
        >>> config = RedisCacheConfig() # reads host/port and other settings from environment variables
        >>> redis_client = await detect_and_create_client(config)
        >>> await redis_client.set("key", "value")
        >>> value = await redis_client.get("key")

    FastAPI integration:
        >>> from fastapi import FastAPI, Depends
        >>> from robin_commons.cache import get_redis_client
        >>>
        >>> app = FastAPI()
        >>>
        >>> @app.get("/items/{item_id}")
        >>> async def get_item(item_id: str, redis=Depends(get_redis_client)):
        ...     return {"item": await redis.get(f"item:{item_id}")}
"""

from robin_commons.cache.client import (
    RedisClient,
    close_redis_connection,
    detect_and_create_client,
    get_cached_client,
    get_redis_config,
    is_cluster_mode,
)
from robin_commons.cache.config import RedisCacheConfig
from robin_commons.cache.dependencies import (
    get_redis_client,
    get_redis_connection,
)

__all__ = [
    # Client
    "RedisClient",
    "detect_and_create_client",
    "is_cluster_mode",
    "get_redis_config",
    "get_cached_client",
    "close_redis_connection",
    # Dependencies
    "get_redis_client",
    "get_redis_connection",
    # Config
    "RedisCacheConfig",
]
