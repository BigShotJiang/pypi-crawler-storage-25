from __future__ import annotations

import os
from typing import Any, Mapping

from .config import (
    UnifiedObservabilityConfig,
    UnifiedServiceConfig,
    parse_bool,
    parse_float,
    parse_int,
)

_CORRELATION_LABEL_NAMES = frozenset({"traceid", "spanid", "requestid"})

_OTEL_INSTRUMENTATION_ENV_MAP = {
    "asgi": "OTEL_INSTR_ASGI",
    "starlette": "OTEL_INSTR_STARLETTE",
    "graphql": "OTEL_INSTR_GRAPHQL",
    "fastapi": "OTEL_INSTR_FASTAPI",
    "flask": "OTEL_INSTR_FLASK",
    "django": "OTEL_INSTR_DJANGO",
    "wsgi": "OTEL_INSTR_WSGI",
    "grpc": "OTEL_INSTR_GRPC",
    "requests": "OTEL_INSTR_REQUESTS",
    "httpx": "OTEL_INSTR_HTTPX",
    "urllib3": "OTEL_INSTR_URLLIB3",
    "aiohttp_client": "OTEL_INSTR_AIOHTTP_CLIENT",
    "sqlalchemy": "OTEL_INSTR_SQLALCHEMY",
    "psycopg": "OTEL_INSTR_PSYCOPG",
    "psycopg2": "OTEL_INSTR_PSYCOPG2",
    "pymysql": "OTEL_INSTR_PYMYSQL",
    "mysqlclient": "OTEL_INSTR_MYSQLCLIENT",
    "pymongo": "OTEL_INSTR_PYMONGO",
    "redis": "OTEL_INSTR_REDIS",
    "celery": "OTEL_INSTR_CELERY",
    "kafka": "OTEL_INSTR_KAFKA",
    "pika": "OTEL_INSTR_PIKA",
    "boto3sqs": "OTEL_INSTR_BOTO3SQS",
    "threading": "OTEL_INSTR_THREADING",
    "asyncio": "OTEL_INSTR_ASYNCIO",
    "logging": "OTEL_INSTR_LOGGING",
}


def load_config_from_env(env: Mapping[str, str] | None = None) -> UnifiedObservabilityConfig:
    source = dict(os.environ if env is None else env)
    filter_exclude_prefixes = _merge_string_lists(
        _split_csv(_logs_env(source, "FILTER_EXCLUDE_LOGGER_PREFIXES")),
        _split_csv(source.get("UO_LOGGING_EXCLUDE_PREFIXES")),
    )

    service = UnifiedServiceConfig(
        service_name=(
            source.get("OTEL_SERVICE_NAME") or _logs_env(source, "APP_NAME") or "unknown-service"
        ),
        service_version=(
            source.get("OTEL_SERVICE_VERSION") or _logs_env(source, "APP_VERSION") or "1.0.0"
        ),
        environment=(
            source.get("OTEL_DEPLOYMENT_ENVIRONMENT")
            or _logs_env(source, "ENVIRONMENT")
            or source.get("ENVIRONMENT")
            or source.get("APP_ENV")
            or "development"
        ),
        service_namespace=source.get("OTEL_SERVICE_NAMESPACE"),
        attributes=_parse_resource_attributes(source.get("OTEL_RESOURCE_ATTRIBUTES")),
    )

    master_enabled = parse_bool(source.get("UO_ENABLED"))
    enable_logging = _resolve_wrapper_flag(
        master_enabled, source, "UO_ENABLE_LOGGING", "ENABLE_LOGGING"
    )
    enable_metrics = _resolve_wrapper_flag(
        master_enabled, source, "UO_ENABLE_METRICS", "ENABLE_METRICS"
    )
    enable_tracing = _resolve_wrapper_flag(
        master_enabled, source, "UO_ENABLE_TRACING", "ENABLE_TRACING"
    )

    logging = _compact(
        {
            "transport": _compact(
                {
                    "url": _logs_env(source, "URL"),
                    "tenant_id": _logs_env(source, "TENANT"),
                    "auth_token": _logs_env(source, "TOKEN"),
                    "compression": _logs_env(source, "COMPRESSION"),
                    "compression_level": parse_int(_logs_env(source, "COMPRESSION_LEVEL")),
                    "compression_threshold": parse_int(_logs_env(source, "COMPRESSION_THRESHOLD")),
                    "use_workers": parse_bool(_logs_env(source, "USE_WORKERS")),
                    "max_workers": parse_int(_logs_env(source, "MAX_WORKERS")),
                    "worker_timeout": parse_int(_logs_env(source, "WORKER_TIMEOUT")),
                    "enable_connection_pooling": parse_bool(
                        _logs_env(source, "CONNECTION_POOLING")
                    ),
                    "max_sockets": parse_int(_logs_env(source, "MAX_SOCKETS")),
                    "timeout": parse_int(_logs_env(source, "TIMEOUT")),
                    "max_retries": parse_int(_logs_env(source, "MAX_RETRIES")),
                    "retry_delay": parse_int(_logs_env(source, "RETRY_DELAY")),
                }
            ),
            "labels": _parse_log_labels(source),
            "buffer": _compact(
                {
                    "max_size": parse_int(_logs_env(source, "BUFFER_MAX_SIZE")),
                    "flush_interval": parse_int(_logs_env(source, "BUFFER_FLUSH_INTERVAL")),
                    "max_memory_mb": parse_int(_logs_env(source, "BUFFER_MAX_MEMORY_MB")),
                    "max_age": parse_int(_logs_env(source, "BUFFER_MAX_AGE")),
                    "auto_flush": parse_bool(_logs_env(source, "BUFFER_AUTO_FLUSH")),
                }
            ),
            "filter": _compact(
                {
                    "levels": _split_csv(_logs_env(source, "FILTER_LEVELS")),
                    "sampling_rate": parse_float(_logs_env(source, "FILTER_SAMPLING_RATE")),
                    "sanitize": parse_bool(_logs_env(source, "FILTER_SANITIZE")),
                    "max_message_length": parse_int(_logs_env(source, "FILTER_MAX_MESSAGE_LENGTH")),
                    "exclude_logger_prefixes": filter_exclude_prefixes,
                }
            ),
            "circuit_breaker": _compact(
                {
                    "enabled": parse_bool(_logs_env(source, "CIRCUIT_BREAKER_ENABLED")),
                    "failure_threshold": parse_int(
                        _logs_env(source, "CIRCUIT_BREAKER_FAILURE_THRESHOLD")
                    ),
                    "reset_timeout": parse_int(_logs_env(source, "CIRCUIT_BREAKER_RESET_TIMEOUT")),
                    "half_open_requests": parse_int(
                        _logs_env(source, "CIRCUIT_BREAKER_HALF_OPEN_REQUESTS")
                    ),
                }
            ),
            "dead_letter_queue": _compact(
                {
                    "enabled": parse_bool(_logs_env(source, "DLQ_ENABLED")),
                    "type": _logs_env(source, "DLQ_TYPE"),
                    "max_size": parse_int(_logs_env(source, "DLQ_MAX_SIZE")),
                    "max_retries": parse_int(_logs_env(source, "DLQ_MAX_RETRIES")),
                    "base_path": _logs_env(source, "DLQ_BASE_PATH"),
                }
            ),
            "performance": _compact(
                {
                    "use_workers": parse_bool(_logs_env(source, "USE_WORKERS")),
                    "max_concurrent_flushes": parse_int(
                        _logs_env(source, "MAX_CONCURRENT_FLUSHES")
                    ),
                    "compression_level": parse_int(_logs_env(source, "COMPRESSION_LEVEL")),
                }
            ),
            "intercept_console": parse_bool(_logs_env(source, "INTERCEPT_CONSOLE")),
            "preserve_original_console": parse_bool(_logs_env(source, "PRESERVE_ORIGINAL_CONSOLE")),
            "enable_metrics": parse_bool(_logs_env(source, "ENABLE_METRICS")),
            "enable_health_check": parse_bool(_logs_env(source, "ENABLE_HEALTH_CHECK")),
            "debug": parse_bool(_logs_env(source, "DEBUG")),
            "silent_errors": parse_bool(_logs_env(source, "SILENT_ERRORS")),
        }
    )

    telemetry = _compact(
        {
            "exporters": _compact(
                {
                    "protocol": source.get("OTEL_EXPORTER_OTLP_PROTOCOL"),
                    "headers": _parse_kv_csv(source.get("OTEL_EXPORTER_OTLP_HEADERS")),
                    "compression": source.get("OTEL_EXPORTER_OTLP_COMPRESSION"),
                    "insecure": parse_bool(source.get("OTEL_EXPORTER_OTLP_INSECURE")),
                    "timeout_millis": parse_int(source.get("OTEL_EXPORTER_OTLP_TIMEOUT")),
                }
            ),
            "tracing": _compact({"enabled": parse_bool(source.get("OTEL_TRACING_ENABLED"))}),
            "metrics": _compact(
                {
                    "enabled": parse_bool(source.get("OTEL_METRICS_ENABLED")),
                    "export_interval_millis": parse_int(source.get("OTEL_METRIC_EXPORT_INTERVAL")),
                    "export_timeout_millis": parse_int(source.get("OTEL_METRIC_EXPORT_TIMEOUT")),
                }
            ),
            "privacy": _compact(
                {
                    "redact_db_statement": parse_bool(
                        source.get("OTEL_PRIVACY_REDACT_DB_STATEMENT")
                        or source.get("OTEL_INSTRUMENTATION_DB_STATEMENT_REDACTION")
                    ),
                    "hash_user_id": parse_bool(source.get("OTEL_PRIVACY_HASH_USER_ID")),
                    "allow_raw_attributes": _split_csv(
                        source.get("OTEL_PRIVACY_ALLOW_RAW_ATTRIBUTES")
                    ),
                }
            ),
            "instrumentations": _parse_instrumentations(source),
        }
    )

    return UnifiedObservabilityConfig(
        service=service,
        logging=logging or None,
        logging_integrations=_parse_logging_integrations(source),
        telemetry=telemetry or None,
        enable_logging=enable_logging,
        enable_metrics=enable_metrics,
        enable_tracing=enable_tracing,
        strict=bool(parse_bool(source.get("UO_STRICT")) or False),
    )


def _resolve_wrapper_flag(
    master_enabled: bool | None,
    env: Mapping[str, str],
    primary_key: str,
    legacy_key: str,
) -> bool | None:
    explicit = parse_bool(env.get(primary_key))
    if explicit is not None:
        return explicit
    legacy = parse_bool(env.get(legacy_key))
    if legacy is not None:
        return legacy
    if master_enabled is not None:
        return master_enabled
    return None


def _parse_instrumentations(env: Mapping[str, str]) -> dict[str, dict[str, bool]] | None:
    values: dict[str, dict[str, bool]] = {}
    for name, env_key in _OTEL_INSTRUMENTATION_ENV_MAP.items():
        parsed = parse_bool(env.get(env_key))
        if parsed is not None:
            values[name] = {"enabled": parsed}
    return values or None


def _parse_logging_integrations(env: Mapping[str, str]) -> dict[str, Any] | None:
    requested = _split_csv(env.get("UO_LOGGING_INTEGRATIONS"))
    loguru = _compact(
        {
            "enabled": parse_bool(env.get("UO_ENABLE_LOGURU_BRIDGE")),
            "level": env.get("UO_LOGURU_LEVEL"),
            "enqueue": parse_bool(env.get("UO_LOGURU_ENQUEUE")),
            "backtrace": parse_bool(env.get("UO_LOGURU_BACKTRACE")),
            "diagnose": parse_bool(env.get("UO_LOGURU_DIAGNOSE")),
            "exclude_prefixes": _split_csv(env.get("UO_LOGURU_EXCLUDE_PREFIXES")),
        }
    )
    structlog = _compact(
        {
            "enabled": parse_bool(env.get("UO_ENABLE_STRUCTLOG_BRIDGE")),
            "exclude_prefixes": _split_csv(env.get("UO_STRUCTLOG_EXCLUDE_PREFIXES")),
        }
    )

    return _compact(
        {
            "auto_install": requested,
            "exclude_prefixes": _split_csv(env.get("UO_LOGGING_EXCLUDE_PREFIXES")),
            "loguru": loguru,
            "structlog": structlog,
        }
    ) or None


def _parse_resource_attributes(raw: str | None) -> dict[str, str]:
    values = _parse_kv_csv(raw)
    if not values:
        return {}
    reserved = {
        "service.name",
        "service.version",
        "service.namespace",
        "deployment.environment",
    }
    return {key: value for key, value in values.items() if key not in reserved}


def _parse_log_labels(env: Mapping[str, str]) -> dict[str, str] | None:
    labels: dict[str, str] = {}
    for prefix in ("LOKI_LABEL_", "LOGS_LABEL_"):
        for key, value in env.items():
            if key.startswith(prefix) and value:
                label_key = key[len(prefix) :].lower()
                if _normalize_label_name(label_key) in _CORRELATION_LABEL_NAMES:
                    continue
                labels[label_key] = value
    return labels or None


def _normalize_label_name(key: str) -> str:
    return key.replace("_", "").replace("-", "").replace(".", "").lower()


def _logs_env(env: Mapping[str, str], suffix: str) -> str | None:
    return env.get(f"LOGS_{suffix}") or env.get(f"LOKI_{suffix}")


def _compact(data: dict[str, Any]) -> dict[str, Any]:
    compacted: dict[str, Any] = {}
    for key, value in data.items():
        if value is None:
            continue
        if isinstance(value, dict):
            nested = _compact(value)
            if nested:
                compacted[key] = nested
            continue
        if isinstance(value, list):
            if value:
                compacted[key] = value
            continue
        compacted[key] = value
    return compacted


def _split_csv(raw: str | None) -> list[str] | None:
    if not raw:
        return None
    values = [item.strip() for item in raw.split(",") if item.strip()]
    return values or None


def _merge_string_lists(*groups: list[str] | None) -> list[str] | None:
    values: list[str] = []
    seen: set[str] = set()
    for group in groups:
        if not group:
            continue
        for item in group:
            normalized = item.strip()
            lowered = normalized.lower()
            if not normalized or lowered in seen:
                continue
            seen.add(lowered)
            values.append(normalized)
    return values or None


def _parse_kv_csv(raw: str | None) -> dict[str, str] | None:
    if not raw:
        return None
    values: dict[str, str] = {}
    for item in raw.split(","):
        key, separator, value = item.partition("=")
        if separator and key.strip():
            values[key.strip()] = value.strip()
    return values or None
