from __future__ import annotations

import importlib
import os
import sys
import threading
from dataclasses import dataclass, field
from typing import Any, Mapping

from .config import (
    UnifiedObservabilityConfig,
    build_logging_init_input,
    coerce_unified_config,
    has_minimum_logging_config,
    merge_configs,
    normalize_data,
    parse_bool,
)
from .env import load_config_from_env
from .logging_bridges import (
    flush_logging_integrations,
    install_logging_integrations,
    uninstall_logging_integrations,
)
from .proxies import NoOpLogger, NoOpMetrics, NoOpTracer, logger, metrics, tracer

_LOCK = threading.RLock()


@dataclass
class UnifiedObservabilityHandle:
    logger: Any
    tracer: Any
    metrics: Any
    _state: "RuntimeState"

    def shutdown(self) -> None:
        shutdown()

    def force_flush(self) -> None:
        force_flush()

    def is_started(self) -> bool:
        return self._state.lifecycle == "started"


@dataclass
class RuntimeState:
    lifecycle: str = "idle"
    config: UnifiedObservabilityConfig | None = None
    handle: UnifiedObservabilityHandle | None = None
    logger_instance: Any = None
    telemetry_handle: Any = None
    logging_integration_uninstallers: list[Any] = field(default_factory=list)
    logs_started: bool = False
    telemetry_started: bool = False


_STATE = RuntimeState()


def init(
    config: UnifiedObservabilityConfig | Mapping[str, Any] | None = None,
) -> UnifiedObservabilityHandle:
    with _LOCK:
        if _STATE.lifecycle == "started" and _STATE.handle is not None:
            return _STATE.handle

        merged_config = _resolve_config(config)
        strict = bool(merged_config.strict)
        logger_instance: Any = NoOpLogger()
        tracer_instance: Any = NoOpTracer()
        metrics_instance: Any = NoOpMetrics()
        logs_started = False
        telemetry_started = False
        telemetry_handle: Any = None
        logging_integration_uninstallers: list[Any] = []
        log_error: Exception | None = None
        telemetry_error: Exception | None = None

        _STATE.lifecycle = "starting"

        logging_requested = _resolve_logging_requested(merged_config)
        telemetry_requested = _resolve_telemetry_requested(merged_config)

        if logging_requested:
            logging_config = build_logging_init_input(merged_config)
            if has_minimum_logging_config(logging_config):
                try:
                    logs_module = _load_logs_module()
                    logger_instance = logs_module.init(logging_config)
                    logs_started = True
                    logging_integration_uninstallers = install_logging_integrations(
                        merged_config,
                        logger_instance,
                        warn=_warn,
                    )
                except Exception as exc:  # pragma: no cover - exercised in tests via monkeypatch
                    log_error = exc
                    _warn(f"Logging initialization failed: {exc}")
            else:
                _warn("Logging requested but skipped because LOGS_URL or LOGS_TENANT is missing.")

        if telemetry_requested:
            try:
                otel_module = _load_otel_module()
                telemetry_handle = otel_module.init_observability(
                    _build_telemetry_config(merged_config)
                )
                tracer_instance = telemetry_handle.tracer
                metrics_instance = telemetry_handle.metrics
                telemetry_started = True
            except Exception as exc:  # pragma: no cover - exercised in tests via monkeypatch
                telemetry_error = exc
                _warn(f"Telemetry initialization failed: {exc}")

        if strict and (log_error or telemetry_error):
            if logs_started:
                uninstall_logging_integrations(logging_integration_uninstallers)
                _safe_destroy_logs()
                logs_started = False
                logger_instance = NoOpLogger()
            if telemetry_started and telemetry_handle is not None:
                _safe_shutdown_telemetry(telemetry_handle)
                telemetry_started = False
                tracer_instance = NoOpTracer()
                metrics_instance = NoOpMetrics()
            _STATE.lifecycle = "idle"
            raise RuntimeError("Unified observability strict initialization failed.") from (
                telemetry_error or log_error
            )

        logger.set_target(logger_instance)
        tracer.set_target(tracer_instance)
        metrics.set_target(metrics_instance)

        handle = UnifiedObservabilityHandle(
            logger=logger_instance,
            tracer=tracer_instance,
            metrics=metrics_instance,
            _state=_STATE,
        )

        _STATE.config = merged_config
        _STATE.handle = handle
        _STATE.logger_instance = logger_instance
        _STATE.telemetry_handle = telemetry_handle
        _STATE.logging_integration_uninstallers = logging_integration_uninstallers
        _STATE.logs_started = logs_started
        _STATE.telemetry_started = telemetry_started
        _STATE.lifecycle = "started"

        return handle


def init_from_env(strict: bool | None = None) -> UnifiedObservabilityHandle:
    config = load_config_from_env()
    if strict is not None:
        config.strict = strict
    return init(config)


def get_handle() -> UnifiedObservabilityHandle:
    if _STATE.handle is None:
        raise RuntimeError("Unified observability is not initialized. Call init() first.")
    return _STATE.handle


def is_initialized() -> bool:
    return _STATE.handle is not None and _STATE.lifecycle == "started"


def force_flush() -> None:
    with _LOCK:
        if _STATE.lifecycle not in {"started", "stopping"}:
            return

        if _STATE.logs_started and _STATE.logger_instance is not None:
            try:
                flush_logging_integrations(_STATE.logging_integration_uninstallers)
            except Exception:
                pass
            try:
                _STATE.logger_instance.flush()
            except Exception:
                pass

        if _STATE.telemetry_started and _STATE.telemetry_handle is not None:
            try:
                _STATE.telemetry_handle.force_flush()
            except Exception:
                pass


def shutdown() -> None:
    with _LOCK:
        if _STATE.lifecycle not in {"starting", "started"}:
            return

        _STATE.lifecycle = "stopping"
        force_flush()

        if _STATE.logs_started:
            uninstall_logging_integrations(_STATE.logging_integration_uninstallers)
            _safe_destroy_logs()

        if _STATE.telemetry_started and _STATE.telemetry_handle is not None:
            _safe_shutdown_telemetry(_STATE.telemetry_handle)

        logger.set_target(None)
        tracer.set_target(None)
        metrics.set_target(None)

        _STATE.config = None
        _STATE.handle = None
        _STATE.logger_instance = None
        _STATE.telemetry_handle = None
        _STATE.logging_integration_uninstallers = []
        _STATE.logs_started = False
        _STATE.telemetry_started = False
        _STATE.lifecycle = "idle"


def _resolve_config(
    config: UnifiedObservabilityConfig | Mapping[str, Any] | None,
) -> UnifiedObservabilityConfig:
    env_config = load_config_from_env()
    if config is None:
        return env_config
    explicit = coerce_unified_config(config)
    return merge_configs(explicit, env_config)


def _resolve_logging_requested(config: UnifiedObservabilityConfig) -> bool:
    if config.enable_logging is not None:
        return config.enable_logging
    component_flag = parse_bool(_env_value("LOGS_ENABLED") or _env_value("LOKI_ENABLED"))
    return True if component_flag is None else component_flag


def _resolve_telemetry_requested(config: UnifiedObservabilityConfig) -> bool:
    traces_enabled = _resolve_telemetry_signal_requested(
        config.enable_tracing,
        env_key="OTEL_TRACING_ENABLED",
        exporter_env_key="OTEL_TRACES_EXPORTER",
    )
    metrics_enabled = _resolve_telemetry_signal_requested(
        config.enable_metrics,
        env_key="OTEL_METRICS_ENABLED",
        exporter_env_key="OTEL_METRICS_EXPORTER",
    )
    return traces_enabled or metrics_enabled


def _resolve_telemetry_signal_requested(
    explicit: bool | None,
    *,
    env_key: str,
    exporter_env_key: str,
) -> bool:
    if explicit is not None:
        return explicit
    parsed = parse_bool(_env_value(env_key))
    if parsed is not None:
        return parsed
    exporter = _env_value(exporter_env_key)
    if exporter:
        return exporter != "none"
    return True


def _build_telemetry_config(config: UnifiedObservabilityConfig) -> Any:
    types_module = importlib.import_module("elven_opentelemetry_instrumentation.types")
    service_name = config.service.service_name or "unknown-service"
    service_version = config.service.service_version or "1.0.0"
    environment = config.service.environment or "development"

    telemetry = normalize_data(config.telemetry or {})
    telemetry_service = (
        telemetry.get("service") if isinstance(telemetry.get("service"), dict) else {}
    )
    service_attributes = dict(config.service.attributes)
    service_attributes.update(_dict_or_empty(telemetry_service.get("attributes")))

    service = types_module.ServiceConfig(
        service_name=service_name,
        service_version=service_version,
        service_namespace=(
            telemetry_service.get("service_namespace") or config.service.service_namespace
        ),
        deployment_environment=environment,
        attributes=service_attributes,
    )

    exporters_raw = _dict_or_empty(telemetry.get("exporters"))
    exporters = types_module.ExporterConfig(
        protocol=exporters_raw.get("protocol"),
        url=exporters_raw.get("url"),
        headers=_dict_or_empty(exporters_raw.get("headers")),
        compression=exporters_raw.get("compression"),
        insecure=exporters_raw.get("insecure"),
        timeout_millis=exporters_raw.get("timeout_millis"),
    )

    tracing_raw = _dict_or_empty(telemetry.get("tracing"))
    rules = _coerce_sampling_rules(types_module, tracing_raw.get("rules"))
    tracing_config = types_module.TracingConfig(
        enabled=(
            config.enable_tracing
            if config.enable_tracing is not None
            else tracing_raw.get("enabled")
        ),
        ratio=tracing_raw.get("ratio", 1.0),
        rules=rules,
    )

    metrics_raw = _dict_or_empty(telemetry.get("metrics"))
    metrics_config = types_module.MetricsConfig(
        enabled=(
            config.enable_metrics
            if config.enable_metrics is not None
            else metrics_raw.get("enabled")
        ),
        export_interval_millis=metrics_raw.get("export_interval_millis"),
        export_timeout_millis=metrics_raw.get("export_timeout_millis"),
    )

    privacy_raw = _dict_or_empty(telemetry.get("privacy"))
    privacy = types_module.PrivacyConfig(
        redact_db_statement=privacy_raw.get("redact_db_statement"),
        hash_user_id=privacy_raw.get("hash_user_id"),
        allow_raw_attributes=list(privacy_raw.get("allow_raw_attributes", [])),
    )

    instrumentations = types_module.InstrumentationsConfig()
    instrumentations_raw = _dict_or_empty(telemetry.get("instrumentations"))
    for name, value in instrumentations_raw.items():
        if not hasattr(instrumentations, name):
            continue
        enabled_value: bool | None
        if isinstance(value, dict):
            enabled_value = parse_bool(value.get("enabled"))
        else:
            enabled_value = parse_bool(value)
        setattr(
            instrumentations,
            name,
            types_module.InstrumentationToggleConfig(enabled=enabled_value),
        )

    return types_module.ObservabilityConfig(
        service=service,
        exporters=exporters,
        runtime=telemetry.get("runtime", "python"),
        tracing=tracing_config,
        metrics=metrics_config,
        instrumentations=instrumentations,
        privacy=privacy,
    )


def _coerce_sampling_rules(types_module: Any, rules_value: Any) -> list[Any]:
    if not isinstance(rules_value, list):
        return []
    decision_enum = importlib.import_module("opentelemetry.sdk.trace.sampling").Decision
    rules: list[Any] = []
    for item in rules_value:
        if isinstance(item, types_module.SamplingRule):
            rules.append(item)
            continue
        if not isinstance(item, dict):
            continue
        decision = item.get("decision")
        if isinstance(decision, str):
            decision = getattr(
                decision_enum, decision, getattr(decision_enum, decision.upper(), None)
            )
        if decision is None:
            continue
        attribute_key = item.get("attribute_key")
        attribute_value = item.get("attribute_value")
        if not attribute_key or attribute_value is None:
            continue
        rules.append(
            types_module.SamplingRule(
                attribute_key=attribute_key,
                attribute_value=attribute_value,
                decision=decision,
            )
        )
    return rules


def _dict_or_empty(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _load_logs_module() -> Any:
    return importlib.import_module("logs_interceptor")


def _load_otel_module() -> Any:
    return importlib.import_module("elven_opentelemetry_instrumentation")


def _safe_destroy_logs() -> None:
    try:
        _load_logs_module().destroy()
    except Exception:
        pass


def _safe_shutdown_telemetry(telemetry_handle: Any) -> None:
    try:
        telemetry_handle.shutdown()
    except Exception:
        pass


def _env_value(key: str) -> str | None:
    return os.environ.get(key)


def _warn(message: str) -> None:
    sys.stderr.write(f"[elven-unified-observability] {message}\n")
    sys.stderr.flush()
