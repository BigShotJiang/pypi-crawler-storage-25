from __future__ import annotations

import atexit
import os
import signal
import sys
from pathlib import Path
from typing import Any

from .config import parse_bool
from .runtime import init_from_env, shutdown

_PRELOADED = False
_HANDLERS_REGISTERED = False


def preload() -> None:
    global _PRELOADED
    if _PRELOADED:
        return

    _PRELOADED = True
    os.environ["ELVEN_UNIFIED_OBSERVABILITY_PRELOADED"] = "true"
    os.environ.setdefault("LOGS_AUTO_INIT", "false")
    os.environ.setdefault("OTEL_ZERO_CODE", "false")

    _load_dotenv_if_enabled()
    init_from_env()
    _register_handlers_once()


def _load_dotenv_if_enabled() -> None:
    if parse_bool(os.getenv("UO_LOAD_DOTENV")) is False:
        return

    from dotenv import load_dotenv

    dotenv_path = os.getenv("UO_DOTENV_PATH")
    if dotenv_path:
        load_dotenv(dotenv_path=dotenv_path, override=False)
        return

    candidate = Path.cwd() / ".env"
    if candidate.exists():
        load_dotenv(dotenv_path=candidate, override=False)
        return

    load_dotenv(override=False)


def _register_handlers_once() -> None:
    global _HANDLERS_REGISTERED
    if _HANDLERS_REGISTERED:
        return

    atexit.register(_safe_shutdown)

    if signal.getsignal(signal.SIGTERM) is not None:
        signal.signal(signal.SIGTERM, _signal_handler)
    if signal.getsignal(signal.SIGINT) is not None:
        signal.signal(signal.SIGINT, _signal_handler)

    _HANDLERS_REGISTERED = True


def _signal_handler(signum: int, frame: Any) -> None:
    del frame
    _safe_shutdown()
    raise SystemExit(128 + signum)


def _safe_shutdown() -> None:
    try:
        shutdown()
    except Exception as exc:  # pragma: no cover - best effort only
        sys.stderr.write(f"[elven-unified-observability] preload shutdown failed: {exc}\n")
        sys.stderr.flush()


preload()
