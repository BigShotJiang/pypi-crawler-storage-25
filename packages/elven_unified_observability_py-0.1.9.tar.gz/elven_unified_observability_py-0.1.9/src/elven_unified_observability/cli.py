from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if args and args[0] == "--":
        args = args[1:]

    if not args:
        sys.stderr.write("usage: elven-unified-observability -- <command> [args...]\n")
        sys.stderr.flush()
        return 2

    with tempfile.TemporaryDirectory(prefix="uo-sitecustomize-") as tmpdir:
        sitecustomize_path = Path(tmpdir) / "sitecustomize.py"
        sitecustomize_path.write_text(
            "import elven_unified_observability.preload\n",
            encoding="utf-8",
        )

        env = os.environ.copy()
        existing_pythonpath = env.get("PYTHONPATH")
        env["PYTHONPATH"] = (
            f"{tmpdir}{os.pathsep}{existing_pythonpath}" if existing_pythonpath else tmpdir
        )
        try:
            process = subprocess.run(args, env=env, check=False)
        except KeyboardInterrupt:
            return 130
        return process.returncode
