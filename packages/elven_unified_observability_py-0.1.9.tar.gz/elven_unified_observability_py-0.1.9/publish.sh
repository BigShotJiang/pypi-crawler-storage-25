#!/bin/bash
set -euo pipefail

REPOSITORY="pypi"
DRY_RUN="false"
SKIP_CHECKS="false"
SKIP_BUILD="false"
TOKEN_ENV=""
SKIP_EXISTING="true"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --repository)
      REPOSITORY="$2"
      shift 2
      ;;
    --dry-run)
      DRY_RUN="true"
      shift
      ;;
    --skip-checks)
      SKIP_CHECKS="true"
      shift
      ;;
    --skip-build)
      SKIP_BUILD="true"
      shift
      ;;
    --token-env)
      TOKEN_ENV="$2"
      shift 2
      ;;
    --no-skip-existing)
      SKIP_EXISTING="false"
      shift
      ;;
    *)
      echo "Unknown argument: $1"
      exit 2
      ;;
  esac
done

if [[ "$REPOSITORY" != "pypi" && "$REPOSITORY" != "testpypi" ]]; then
  echo "Repository must be either 'pypi' or 'testpypi'."
  exit 2
fi

if [[ -z "$TOKEN_ENV" ]]; then
  if [[ "$REPOSITORY" == "testpypi" ]]; then
    TOKEN_ENV="TEST_PYPI_API_TOKEN"
  else
    TOKEN_ENV="PYPI_API_TOKEN"
  fi
fi

if [[ "$SKIP_CHECKS" != "true" ]]; then
  python -m ruff check .
  python -m pyright
  python -m pytest
fi

if [[ "$SKIP_BUILD" != "true" ]]; then
  rm -rf dist build *.egg-info
  python -m build
  python -m twine check dist/*
fi

if [[ "$DRY_RUN" == "true" ]]; then
  echo "Dry run complete for repository '$REPOSITORY'."
  exit 0
fi

TOKEN_VALUE="${!TOKEN_ENV:-}"
if [[ -z "$TOKEN_VALUE" ]]; then
  echo "Missing token in environment variable: $TOKEN_ENV"
  exit 1
fi

TWINE_ARGS=(python -m twine upload)
if [[ "$REPOSITORY" == "testpypi" ]]; then
  TWINE_ARGS+=(--repository-url https://test.pypi.org/legacy/)
fi
if [[ "$SKIP_EXISTING" == "true" ]]; then
  TWINE_ARGS+=(--skip-existing)
fi
TWINE_ARGS+=(--username __token__ --password "$TOKEN_VALUE" dist/*)

"${TWINE_ARGS[@]}"
