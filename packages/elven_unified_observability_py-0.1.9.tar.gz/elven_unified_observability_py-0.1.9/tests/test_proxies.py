from __future__ import annotations

from typing import Iterator

import pytest

from elven_unified_observability import logger, shutdown


@pytest.fixture(autouse=True)
def reset_runtime() -> Iterator[None]:
    shutdown()
    yield
    shutdown()


def test_logger_proxy_is_safe_before_init_for_logging_style_calls() -> None:
    logger.info(
        "payload %s",
        {"ok": True},
        extra={"request_id": "req-1"},
    )
    logger.warning("careful %s", "now")
    logger.exception("failed %s", "payload", exc_info=True)
    logger.critical("fatal %s", "now")
