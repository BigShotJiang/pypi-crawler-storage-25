from django_ecommerce.models import Setting
from django_ecommerce.utils import get_cart_snapshot


def ecommerce_settings(request):
    return {
        'ecommerce_settings': Setting.get_solo()
    }


def ecommerce_cart(request):
    snapshot = get_cart_snapshot(
        request,
        include_images=False,
        include_discount_context=True,
        include_availability=False,
    )
    return {
        "ecommerce_cart": {
            "items": [
                {"variant": item.variant, "quantity": item.quantity, "total": item.line_total}
                for item in snapshot.items
            ],
            "total": snapshot.total,
            "quantity": snapshot.quantity,
            "shipping": snapshot.shipping,
        }
    }
