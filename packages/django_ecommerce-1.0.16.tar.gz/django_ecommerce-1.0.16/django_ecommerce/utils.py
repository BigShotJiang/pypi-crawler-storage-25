from dataclasses import dataclass
from contextlib import nullcontext
from typing import Callable
import random

from django.conf import settings
from django.db import transaction
from django.db.models import Prefetch, Sum, Value, Case, When, BooleanField, Exists, OuterRef, Subquery, IntegerField, \
    F
from django.db.models.functions import Coalesce
from djmoney.money import Money
from django.utils import timezone

from django_ecommerce.models import ProductVariant, Setting, Order, OrderItem, City, Product, Category, Country, \
    DiscountProduct, DiscountCategory, Discount


@dataclass
class CartSnapshotItem:
    variant_id: int
    quantity: int
    variant: ProductVariant
    product: Product
    line_total: Money
    unit_price: Money
    availability: int | None = None


@dataclass
class CartSnapshot:
    items: list[CartSnapshotItem]
    quantity: int
    subtotal: Money
    shipping_amount: Money
    total: Money
    shipping: dict
    variant_map: dict[int, ProductVariant]
    product_map: dict[int, Product]


def chunks(queryset, chunk_size):
    chunk_size = int(chunk_size)

    return [queryset[i:i + chunk_size] for i in range(0, len(queryset), chunk_size)]


def similar_products(product, limit=4):
    category = product.category
    similar_items = Product.objects.filter(category=category).exclude(id=product.id)
    candidate_ids = list(similar_items.values_list("id", flat=True))
    sampled_ids = random.sample(candidate_ids, min(limit, len(candidate_ids)))

    return Product.objects.filter(id__in=sampled_ids)


def annotate_product_card_fields(
    qs,
    *,
    now=None,
    include_stock=True,
    include_discount=True,
):
    now = now or timezone.now()
    product_discount_subquery = (
        DiscountProduct.objects.filter(
            product=OuterRef("pk"),
            discount__active=True,
            discount__start_date__lte=now,
            discount__end_date__gte=now,
        )
        .values("percentage")[:1]
    )
    category_discount_subquery = (
        DiscountCategory.objects.filter(
            category=OuterRef("category_id"),
            discount__active=True,
            discount__start_date__lte=now,
            discount__end_date__gte=now,
        )
        .values("percentage")[:1]
    )

    if include_discount:
        qs = qs.annotate(
            effective_discount_percent=Coalesce(
                Subquery(product_discount_subquery, output_field=IntegerField()),
                Subquery(category_discount_subquery, output_field=IntegerField()),
                Value(0),
            ),
        ).annotate(
            has_active_discount=Case(
                When(effective_discount_percent__gt=0, then=Value(True)),
                default=Value(False),
                output_field=BooleanField(),
            ),
        )
        qs = qs.annotate(
            effective_price=(F("price") * (100 - Coalesce("effective_discount_percent", Value(0))) / 100)
        )
    else:
        qs = qs.annotate(
            effective_discount_percent=Value(0, output_field=IntegerField()),
            has_active_discount=Value(False, output_field=BooleanField()),
            effective_price=F("price"),
        )

    if include_stock:
        in_stock_subquery = ProductVariant.objects.filter(
            product=OuterRef("pk"),
            available_quantity__gt=0,
        )
        qs = qs.annotate(
            in_stock=Exists(in_stock_subquery),
        )
    else:
        qs = qs.annotate(in_stock=Value(False, output_field=BooleanField()))

    return qs


def with_product_card_graph(
    qs,
    *,
    include_category=True,
    include_images=True,
    include_variants=False,
    include_discount_relations=True,
):
    if include_category:
        qs = qs.select_related("category")
    if include_images:
        qs = qs.prefetch_related("images")
    if include_variants:
        qs = qs.prefetch_related("variants")
    if include_discount_relations:
        qs = qs.prefetch_related(
            Prefetch(
                "discount_products",
                queryset=DiscountProduct.objects.select_related("discount"),
            ),
            Prefetch(
                "category__discount_categories",
                queryset=DiscountCategory.objects.select_related("discount"),
            ),
        )
    return qs


def get_product_availability_map(
    product_ids: list[int],
    *,
    include_reserved=True,
) -> dict[int, int]:
    if not product_ids:
        return {}

    variants_qs = ProductVariant.objects.filter(product_id__in=product_ids)
    quantity_field = "available_quantity" if include_reserved else "stock_quantity"
    rows = variants_qs.values("product_id").annotate(total=Coalesce(Sum(quantity_field), 0))
    totals = {row["product_id"]: row["total"] for row in rows}
    for product_id in product_ids:
        totals.setdefault(product_id, 0)
    return totals


def get_similar_products_bundle(
    product_id: int,
    *,
    limit: int = 8,
    annotate_cards: bool = True,
    include_images: bool = True,
) -> list[Product]:
    try:
        base_product = Product.objects.only("id", "category_id").get(pk=product_id)
    except Product.DoesNotExist:
        return []

    if not base_product.category_id or limit <= 0:
        return []

    candidate_ids = list(
        Product.objects.filter(category_id=base_product.category_id)
        .exclude(pk=base_product.pk)
        .values_list("id", flat=True)
    )
    sampled_ids = random.sample(candidate_ids, min(limit, len(candidate_ids)))
    if not sampled_ids:
        return []

    qs = Product.objects.filter(pk__in=sampled_ids)
    qs = with_product_card_graph(
        qs,
        include_category=True,
        include_images=include_images,
        include_variants=False,
        include_discount_relations=True,
    )
    if annotate_cards:
        qs = annotate_product_card_fields(qs)

    products = list(qs)
    products_map = {product.pk: product for product in products}
    return [products_map[pk] for pk in sampled_ids if pk in products_map]


def get_category_products_bundle(
    slug: str,
    *,
    only_in_stock: bool = False,
    annotate_cards: bool = True,
):
    try:
        category = Category.objects.get(slug=slug)
    except Category.DoesNotExist:
        return {"category": None, "products": Product.objects.none()}

    products = Product.objects.filter(category=category)
    products = with_product_card_graph(
        products,
        include_category=False,
        include_images=True,
        include_variants=False,
        include_discount_relations=True,
    )
    if annotate_cards:
        products = annotate_product_card_fields(products, include_stock=True, include_discount=True)
    if only_in_stock:
        if annotate_cards:
            products = products.filter(in_stock=True)
        else:
            products = products.filter(variants__available_quantity__gt=0).distinct()

    return {"category": category, "products": products}


def get_discount_impacted_product_and_section_ids(
    discount_ids: list[int] | None = None,
    *,
    at_time=None,
) -> dict[str, set[int]]:
    at_time = at_time or timezone.now()
    discounts = Discount.objects.filter(
        active=True,
        start_date__lte=at_time,
        end_date__gte=at_time,
    )
    if discount_ids is not None:
        discounts = discounts.filter(id__in=discount_ids)

    resolved_discount_ids = list(discounts.values_list("id", flat=True))
    if not resolved_discount_ids:
        return {"product_ids": set(), "section_ids": set()}

    direct_product_ids = set(
        DiscountProduct.objects.filter(discount_id__in=resolved_discount_ids).values_list("product_id", flat=True)
    )
    section_ids = set(
        DiscountCategory.objects.filter(discount_id__in=resolved_discount_ids).values_list("category_id", flat=True)
    )
    category_product_ids = set(Product.objects.filter(category_id__in=section_ids).values_list("id", flat=True))
    return {
        "product_ids": direct_product_ids | category_product_ids,
        "section_ids": section_ids,
    }


def variant_availability(variant: ProductVariant, request) -> int:
    cart_quantity = 0

    if str(variant.pk) in request.session.get('cart', {}):
        cart_quantity = request.session['cart'][str(variant.pk)]

    return variant.available_quantity - cart_quantity


def _invalidate_cart_snapshot_cache(request) -> None:
    if hasattr(request, "_ecommerce_cart_snapshot_cache"):
        delattr(request, "_ecommerce_cart_snapshot_cache")


def _get_session_cart_data(request) -> dict[str, int]:
    cart_data = request.session.get("cart", {})
    return {
        str(variant_id): quantity
        for variant_id, quantity in cart_data.items()
        if str(variant_id).isdigit()
    }


def fetch_variants_with_products(
    variant_ids: list[int],
    *,
    for_pricing: bool = True,
    for_images: bool = False,
) -> dict[int, ProductVariant]:
    if not variant_ids:
        return {}

    queryset = ProductVariant.objects.filter(pk__in=variant_ids).select_related(
        "product",
        "product__category",
    )

    if for_pricing:
        queryset = queryset.prefetch_related(
            Prefetch(
                "product__discount_products",
                queryset=DiscountProduct.objects.select_related("discount"),
            ),
            Prefetch(
                "product__category__discount_categories",
                queryset=DiscountCategory.objects.select_related("discount"),
            ),
        )

    if for_images:
        queryset = queryset.prefetch_related("product__images")

    return {variant.pk: variant for variant in queryset}


def get_variant_availability_map(
    request,
    variant_ids: list[int],
    *,
    cart_data: dict[str, int] | None = None,
    include_reserved: bool = True,
) -> dict[int, int]:
    if not variant_ids:
        return {}

    if cart_data is None:
        cart_data = _get_session_cart_data(request)

    variants = ProductVariant.objects.filter(pk__in=variant_ids).values("id", "available_quantity")
    availability_map = {row["id"]: row["available_quantity"] for row in variants}

    if not include_reserved:
        return {key: max(0, value) for key, value in availability_map.items()}

    for variant_id, quantity in cart_data.items():
        int_id = int(variant_id)
        if int_id in availability_map:
            availability_map[int_id] = max(0, availability_map[int_id] - quantity)

    return availability_map


def money(amount: float, currency: str = None) -> Money:
    if currency:
        return Money(amount, currency)

    if hasattr(settings, 'ECOMMERCE_DEFAULT_CURRENCY'):
        return Money(amount, getattr(settings, 'ECOMMERCE_DEFAULT_CURRENCY'))

    return Money(amount, 'EUR')


def get_shipping_data(amount: Money) -> dict:
    site_settings = Setting.get_solo()

    shipping = {
        'shipping_enabled': site_settings.shipping_enabled,
        'free_shipping_enabled': site_settings.free_shipping_enabled,
        'shipping_amount': site_settings.shipping_amount
    }

    if site_settings.shipping_enabled:
        if site_settings.free_shipping_enabled:
            shipping['free_shipping_remaining'] = site_settings.free_shipping_min_amount - amount
            shipping['is_free_shipping'] = (shipping['free_shipping_remaining']
                                            <= Money(0, site_settings.free_shipping_min_amount_currency))

            if shipping['is_free_shipping']:
                shipping['shipping_amount'] = money(0)

    return shipping


def get_cart_snapshot(
    request,
    *,
    include_images: bool = True,
    include_discount_context: bool = True,
    include_availability: bool = True,
) -> CartSnapshot:
    cache_key = (include_images, include_discount_context, include_availability)
    cache = getattr(request, "_ecommerce_cart_snapshot_cache", None)
    if cache and cache_key in cache:
        return cache[cache_key]

    raw_cart_data = request.session.get("cart", {})
    cart_data = _get_session_cart_data(request)
    invalid_session_keys = [str(variant_id) for variant_id in raw_cart_data.keys() if not str(variant_id).isdigit()]
    variant_ids = [int(variant_id) for variant_id in cart_data.keys()]
    variant_map = fetch_variants_with_products(
        variant_ids,
        for_pricing=include_discount_context,
        for_images=include_images,
    )
    availability_map = (
        get_variant_availability_map(
            request,
            variant_ids,
            cart_data=cart_data,
            include_reserved=True,
        )
        if include_availability
        else {}
    )

    subtotal = money(0)
    cart_quantity = 0
    items: list[CartSnapshotItem] = []
    remove: list[str] = []

    for variant_id, quantity in cart_data.items():
        if quantity <= 0:
            remove.append(variant_id)
            continue

        variant = variant_map.get(int(variant_id))
        if not variant:
            remove.append(variant_id)
            continue

        if variant.available_quantity <= 0:
            remove.append(variant_id)
            continue

        adjusted_quantity = min(quantity, variant.available_quantity)
        unit_price = variant.product.actual_price
        line_total = unit_price * adjusted_quantity
        subtotal += line_total
        cart_quantity += adjusted_quantity

        items.append(
            CartSnapshotItem(
                variant_id=variant.pk,
                quantity=adjusted_quantity,
                variant=variant,
                product=variant.product,
                unit_price=unit_price,
                line_total=line_total,
                availability=availability_map.get(variant.pk) if include_availability else None,
            )
        )

    if remove or invalid_session_keys:
        for variant_id in invalid_session_keys:
            if variant_id in request.session.get("cart", {}):
                del request.session["cart"][variant_id]
        for variant_id in remove:
            if variant_id in request.session.get("cart", {}):
                del request.session["cart"][variant_id]
        request.session.modified = True

    shipping = get_shipping_data(subtotal)
    total = subtotal
    if shipping["shipping_enabled"] and shipping["shipping_amount"]:
        total += shipping["shipping_amount"]

    snapshot = CartSnapshot(
        items=items,
        quantity=cart_quantity,
        subtotal=subtotal,
        shipping_amount=shipping["shipping_amount"],
        total=total,
        shipping=shipping,
        variant_map=variant_map,
        product_map={item.product.pk: item.product for item in items},
    )

    if not cache:
        cache = {}
    cache[cache_key] = snapshot
    request._ecommerce_cart_snapshot_cache = cache
    return snapshot


def get_cart(request):
    # Preserve legacy behavior: each get_cart call reflects latest DB state.
    _invalidate_cart_snapshot_cache(request)
    snapshot = get_cart_snapshot(request, include_images=False, include_discount_context=True, include_availability=False)
    items = [
        {
            "variant": item.variant,
            "quantity": item.quantity,
            "total": item.line_total,
        }
        for item in snapshot.items
    ]
    return {
        "items": items,
        "total": snapshot.total,
        "quantity": snapshot.quantity,
        "shipping": snapshot.shipping,
    }


def remove_from_cart(request, variant_id: int) -> dict:
    if 'cart' in request.session and str(variant_id) in request.session['cart']:
        del request.session['cart'][str(variant_id)]
        request.session.modified = True
        _invalidate_cart_snapshot_cache(request)

    return {}


def add_to_cart_and_snapshot(
    request,
    variant_id: int,
    quantity_delta: int,
    *,
    include_availability: bool = False,
) -> dict:
    try:
        variant_id = int(variant_id or 0)
        quantity_delta = int(quantity_delta or 0)
    except (TypeError, ValueError):
        return {"ok": False, "error": "InvalidQuantity", "remaining": None, "snapshot": None}

    if not variant_id:
        return {"ok": False, "error": "InvalidVariant", "remaining": None, "snapshot": None}
    if not quantity_delta:
        return {"ok": False, "error": "InvalidQuantity", "remaining": None, "snapshot": None}

    try:
        variant = ProductVariant.objects.get(pk=variant_id)
    except ProductVariant.DoesNotExist:
        return {"ok": False, "error": "InvalidVariant", "remaining": None, "snapshot": None}

    if "cart" not in request.session:
        request.session["cart"] = {}

    session_key = str(variant_id)
    current_quantity = request.session["cart"].get(session_key, 0)
    total_quantity = current_quantity + quantity_delta

    if total_quantity > variant.available_quantity:
        return {"ok": False, "error": "OutOfStock", "remaining": None, "snapshot": None}

    if total_quantity <= 0:
        if session_key in request.session["cart"]:
            del request.session["cart"][session_key]
            request.session.modified = True
    else:
        request.session["cart"][session_key] = total_quantity
        request.session.modified = True

    _invalidate_cart_snapshot_cache(request)
    snapshot = get_cart_snapshot(
        request,
        include_images=True,
        include_discount_context=True,
        include_availability=include_availability,
    )
    remaining = (variant.available_quantity - max(total_quantity, 0)) > 0
    return {"ok": True, "error": None, "remaining": remaining, "snapshot": snapshot}


def add_to_cart(request, variant_id: int, quantity: int = 1) -> dict:
    if not variant_id or not quantity:
        return {"error": "InvalidRequestOrParameters"}

    result = add_to_cart_and_snapshot(
        request,
        variant_id=variant_id,
        quantity_delta=quantity,
        include_availability=False,
    )
    if not result["ok"]:
        if result["error"] == "InvalidVariant":
            return {"error": "ProductVariantDoesNotExist"}
        if result["error"] == "OutOfStock":
            return {"error": "StockError"}
        return {"error": "InvalidRequestOrParameters"}

    return {"remaining": result["remaining"]}


def create_order_from_snapshot(
    request,
    *,
    customer: dict,
    snapshot: CartSnapshot | None = None,
    func: Callable | None = None,
    use_transaction: bool = True,
) -> dict:
    snapshot = snapshot or get_cart_snapshot(
        request,
        include_images=False,
        include_discount_context=True,
        include_availability=False,
    )

    if not snapshot.items:
        return {"error": "EmptyCart"}

    tx_ctx = transaction.atomic() if use_transaction else nullcontext()
    with tx_ctx:
        order = Order.objects.create(
            email=customer.get("email"),
            full_name=customer.get("full_name"),
            address=customer.get("address"),
            phone=customer.get("phone"),
            city=customer.get("city"),
            country=customer.get("country"),
            zip_code=customer.get("zip_code"),
            remark=customer.get("remark"),
            shipping_amount=snapshot.shipping_amount,
        )

        OrderItem.objects.bulk_create(
            [
                OrderItem(
                    order=order,
                    product_variant=item.variant,
                    price=item.variant.product.price,
                    discount_percentage=item.variant.product.discount,
                    quantity=item.quantity,
                )
                for item in snapshot.items
            ]
        )

        if func:
            func(request, order)

    if "cart" in request.session:
        del request.session["cart"]
        request.session.modified = True
    _invalidate_cart_snapshot_cache(request)
    return {"order": order, "snapshot": snapshot}


def create_order(request, email: str = None, full_name: str = None, address: str = None, phone: str = None,
                 city: str = None, country: str = None, zip_code: str = None, remark: str = None,
                 func: Callable = None):
    result = create_order_from_snapshot(
        request,
        customer={
            "email": email,
            "full_name": full_name,
            "address": address,
            "phone": phone,
            "city": city,
            "country": country,
            "zip_code": zip_code,
            "remark": remark,
        },
        func=func,
        use_transaction=False,
    )
    if "error" in result:
        return {"error": result["error"]}
    return {"order": result["order"]}


def get_cities() -> set:
    return set(City.objects.values_list("name", flat=True))


def get_countries() -> set:
    return set(Country.objects.values_list("name", flat=True))


def find_product_by_slug(slug: str) -> Product | None:
    try:
        return Product.objects.get(slug=slug)
    except Product.DoesNotExist:
        return None


def find_category_by_slug(slug: str) -> Category | None:
    try:
        return Category.objects.get(slug=slug)
    except Category.DoesNotExist:
        return None


def find_order_by_code(code: str) -> Order | None:
    try:
        return Order.objects.get(code=code)
    except Order.DoesNotExist:
        return None


def get_order_bundle(code: str, *, with_discounts: bool = True) -> Order | None:
    prefetches = [
        "items__warehouse",
        "items__product_variant__product__images",
        "items__product_variant__product__variants",
    ]
    if with_discounts:
        prefetches += [
            Prefetch(
                "items__product_variant__product__discount_products",
                queryset=DiscountProduct.objects.select_related("discount"),
            ),
            Prefetch(
                "items__product_variant__product__category__discount_categories",
                queryset=DiscountCategory.objects.select_related("discount"),
            ),
        ]

    try:
        return Order.objects.prefetch_related(*prefetches).get(code=code)
    except Order.DoesNotExist:
        return None
