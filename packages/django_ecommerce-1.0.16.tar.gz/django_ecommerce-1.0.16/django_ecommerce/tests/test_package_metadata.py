import re

from django.test import SimpleTestCase

from django_ecommerce import __version__


class PackageMetadataTests(SimpleTestCase):
    def test_version_is_semver_like(self):
        self.assertRegex(__version__, re.compile(r"^\d+\.\d+\.\d+$"))
