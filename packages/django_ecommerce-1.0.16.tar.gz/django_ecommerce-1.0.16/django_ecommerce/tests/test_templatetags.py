from django.template import Context, Template
from django.test import TestCase

from django_ecommerce.models import Category, Color, Gender, Product, ProductVariant, Stock, StockImport, Warehouse
from django_ecommerce.templatetags import ecommerce_filters
from django_ecommerce.utils import money


class TemplateTagTests(TestCase):
    def setUp(self):
        category = Category.objects.create(name="Category")
        color = Color.objects.create(name="Blue")
        gender = Gender.objects.create(name="Unisex")
        warehouse = Warehouse.objects.create(name="Main")
        product = Product.objects.create(
            name="Product", category=category, color=color, gender=gender, price=money(10)
        )
        self.variant = ProductVariant.objects.create(
            product=product, name="Small", sku="tag-small"
        )
        stock_import = StockImport.objects.create()
        Stock.objects.create(
            product_variant=self.variant,
            warehouse=warehouse,
            quantity=5,
            content_object=stock_import,
        )
        self.request = self.client.get("/").wsgi_request

    def test_filters_are_registered(self):
        self.assertIn("chunks", ecommerce_filters.register.filters)
        self.assertIn("similar_products", ecommerce_filters.register.filters)
        self.assertIn("variant_availability", ecommerce_filters.register.filters)

    def test_chunks_filter_renders(self):
        template = Template("{% load ecommerce_filters %}{{ values|chunks:2|length }}")
        rendered = template.render(Context({"values": [1, 2, 3, 4]}))
        self.assertEqual(rendered, "2")

    def test_variant_availability_filter_renders(self):
        variant = ProductVariant.objects.get(pk=self.variant.pk)
        template = Template(
            "{% load ecommerce_filters %}{{ variant|variant_availability:request }}"
        )
        rendered = template.render(
            Context({"variant": variant, "request": self.request})
        )
        self.assertEqual(rendered, "5")
