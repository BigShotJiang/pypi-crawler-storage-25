from django.test import TestCase

from django_ecommerce.models import (
    Category,
    Color,
    Gender,
    Order,
    Product,
    ProductVariant,
    Stock,
    StockImport,
    Warehouse,
)
from django_ecommerce.utils import (
    add_to_cart_and_snapshot,
    find_category_by_slug,
    find_order_by_code,
    find_product_by_slug,
    get_cart_snapshot,
    get_order_bundle,
    get_variant_availability_map,
    money,
)


class UtilsEdgeCaseTests(TestCase):
    def setUp(self):
        category = Category.objects.create(name="Category")
        color = Color.objects.create(name="Blue")
        gender = Gender.objects.create(name="Unisex")
        self.warehouse = Warehouse.objects.create(name="Main")
        self.product = Product.objects.create(
            name="Product", category=category, color=color, gender=gender, price=money(10)
        )
        self.variant = ProductVariant.objects.create(
            product=self.product, name="Small", sku="sku-small"
        )
        self.request = self.client.get("/").wsgi_request

    def _add_stock(self, quantity):
        stock_import = StockImport.objects.create()
        Stock.objects.create(
            product_variant=self.variant,
            warehouse=self.warehouse,
            quantity=quantity,
            content_object=stock_import,
        )

    def test_add_to_cart_and_snapshot_invalid_contract(self):
        invalid_variant = add_to_cart_and_snapshot(self.request, 0, 1)
        self.assertEqual(
            invalid_variant,
            {"ok": False, "error": "InvalidVariant", "remaining": None, "snapshot": None},
        )

        invalid_quantity = add_to_cart_and_snapshot(self.request, self.variant.pk, 0)
        self.assertEqual(
            invalid_quantity,
            {"ok": False, "error": "InvalidQuantity", "remaining": None, "snapshot": None},
        )

        coercion_error = add_to_cart_and_snapshot(self.request, self.variant.pk, "abc")
        self.assertEqual(
            coercion_error,
            {"ok": False, "error": "InvalidQuantity", "remaining": None, "snapshot": None},
        )

    def test_add_to_cart_and_snapshot_out_of_stock_contract(self):
        self._add_stock(1)
        response = add_to_cart_and_snapshot(self.request, self.variant.pk, 2)
        self.assertEqual(
            response,
            {"ok": False, "error": "OutOfStock", "remaining": None, "snapshot": None},
        )

    def test_get_cart_snapshot_cleans_invalid_and_missing_items(self):
        self._add_stock(3)
        ghost_variant = ProductVariant.objects.create(
            product=self.product, name="Ghost", sku="ghost"
        )
        self.request.session["cart"] = {
            "not-a-number": 2,
            str(self.variant.pk): 2,
            str(ghost_variant.pk): 1,
            "999999": 1,
        }
        self.request.session.modified = True

        ghost_variant.delete()
        snapshot = get_cart_snapshot(self.request)

        self.assertEqual(snapshot.quantity, 2)
        self.assertEqual(len(snapshot.items), 1)
        self.assertNotIn("not-a-number", self.request.session["cart"])
        self.assertNotIn("999999", self.request.session["cart"])
        self.assertNotIn(str(ghost_variant.pk), self.request.session["cart"])

    def test_get_cart_snapshot_removes_non_positive_quantities(self):
        self._add_stock(3)
        self.request.session["cart"] = {str(self.variant.pk): 0}
        self.request.session.modified = True

        snapshot = get_cart_snapshot(self.request)
        self.assertEqual(snapshot.quantity, 0)
        self.assertNotIn(str(self.variant.pk), self.request.session["cart"])

    def test_get_variant_availability_map_without_reserved_and_empty(self):
        self._add_stock(5)
        self.request.session["cart"] = {str(self.variant.pk): 4}
        self.request.session.modified = True

        with_reserved = get_variant_availability_map(
            self.request, [self.variant.pk], include_reserved=True
        )
        without_reserved = get_variant_availability_map(
            self.request, [self.variant.pk], include_reserved=False
        )
        self.assertEqual(with_reserved[self.variant.pk], 1)
        self.assertEqual(without_reserved[self.variant.pk], 5)
        self.assertEqual(get_variant_availability_map(self.request, [], include_reserved=False), {})

    def test_finders_and_order_bundle_return_none_when_not_found(self):
        self.assertIsNone(find_product_by_slug("missing-product"))
        self.assertIsNone(find_category_by_slug("missing-category"))
        self.assertIsNone(find_order_by_code("MISSING"))
        self.assertIsNone(get_order_bundle("MISSING"))

    def test_get_order_bundle_returns_order_when_found(self):
        order = Order.objects.create()
        self.assertEqual(get_order_bundle(order.code).pk, order.pk)
