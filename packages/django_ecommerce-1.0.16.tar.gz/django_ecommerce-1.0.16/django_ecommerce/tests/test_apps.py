from django.test import SimpleTestCase

from django_ecommerce.apps import DjangoEcommerceConfig


class AppsSmokeTests(SimpleTestCase):
    def test_app_config_values(self):
        self.assertEqual(DjangoEcommerceConfig.name, "django_ecommerce")
        self.assertEqual(DjangoEcommerceConfig.label, "ecommerce")
