from django.template import Context, Template
from django.test import TestCase

from django_ecommerce.context_processors import ecommerce_cart, ecommerce_settings
from django_ecommerce.models import Category, Color, Gender, Product, ProductVariant, Stock, StockImport, Warehouse
from django_ecommerce.utils import money


class ContextProcessorTests(TestCase):
    def setUp(self):
        category = Category.objects.create(name="Category")
        color = Color.objects.create(name="Blue")
        gender = Gender.objects.create(name="Unisex")
        warehouse = Warehouse.objects.create(name="Main")
        product = Product.objects.create(
            name="Product", category=category, color=color, gender=gender, price=money(10)
        )
        self.variant = ProductVariant.objects.create(
            product=product, name="Small", sku="context-small"
        )
        stock_import = StockImport.objects.create()
        Stock.objects.create(
            product_variant=self.variant,
            warehouse=warehouse,
            quantity=3,
            content_object=stock_import,
        )
        self.request = self.client.get("/").wsgi_request

    def test_ecommerce_settings_context_contains_singleton(self):
        data = ecommerce_settings(self.request)
        self.assertIn("ecommerce_settings", data)
        self.assertFalse(data["ecommerce_settings"].shipping_enabled)

    def test_ecommerce_cart_context_shape_and_values(self):
        self.request.session["cart"] = {str(self.variant.pk): 2}
        self.request.session.modified = True

        data = ecommerce_cart(self.request)
        cart = data["ecommerce_cart"]

        self.assertEqual(cart["quantity"], 2)
        self.assertEqual(len(cart["items"]), 1)
        self.assertEqual(cart["items"][0]["variant"].pk, self.variant.pk)
        self.assertEqual(cart["items"][0]["quantity"], 2)
        self.assertEqual(cart["items"][0]["total"], money(20))

    def test_ecommerce_cart_works_in_template_context(self):
        self.request.session["cart"] = {str(self.variant.pk): 1}
        self.request.session.modified = True
        template = Template("{{ ecommerce_cart.quantity }}")
        rendered = template.render(Context(ecommerce_cart(self.request)))
        self.assertEqual(rendered, "1")
