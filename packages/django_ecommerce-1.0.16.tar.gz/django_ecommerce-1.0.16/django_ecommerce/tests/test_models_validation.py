from unittest.mock import patch

from django.core.exceptions import ValidationError
from django.test import TestCase

from django_ecommerce.models import (
    Category,
    Color,
    Gender,
    Order,
    OrderItem,
    Product,
    ProductVariant,
    Stock,
    StockImport,
    Warehouse,
    generate_order_code,
)
from django_ecommerce.utils import money


class ModelValidationTests(TestCase):
    def setUp(self):
        category = Category.objects.create(name="Category")
        color = Color.objects.create(name="Blue")
        gender = Gender.objects.create(name="Unisex")
        self.warehouse = Warehouse.objects.create(name="Main")
        self.product = Product.objects.create(
            name="Product",
            category=category,
            color=color,
            gender=gender,
            price=money(10),
        )
        self.variant = ProductVariant.objects.create(
            product=self.product,
            name="Small",
            sku="sku-lower",
        )

    def _add_stock(self, quantity):
        stock_import = StockImport.objects.create()
        Stock.objects.create(
            product_variant=self.variant,
            warehouse=self.warehouse,
            quantity=quantity,
            content_object=stock_import,
        )

    def test_order_full_clean_rejects_invalid_status_transition(self):
        order = Order.objects.create(status="pending")
        order.status = "returned"

        with self.assertRaises(ValidationError):
            order.full_clean()

    def test_order_full_clean_rejects_terminal_status_change(self):
        order = Order.objects.create(status="canceled")
        order.status = "pending"

        with self.assertRaises(ValidationError):
            order.full_clean()

    def test_order_item_full_clean_rejects_unreserved_when_required(self):
        self._add_stock(3)
        order = Order.objects.create(status=Order.REQUIRE_RESERVED_ITEMS_STATUSES[0])
        item = OrderItem(
            order=order,
            product_variant=self.variant,
            quantity=1,
            price=self.product.price,
            reserved=False,
            warehouse=self.warehouse,
        )

        with self.assertRaises(ValidationError):
            item.full_clean()

    def test_order_item_full_clean_rejects_quantity_over_stock(self):
        self._add_stock(1)
        order = Order.objects.create(status="pending")
        item = OrderItem(
            order=order,
            product_variant=self.variant,
            quantity=3,
            price=self.product.price,
            reserved=True,
            warehouse=self.warehouse,
        )

        with self.assertRaises(ValidationError):
            item.full_clean()

    def test_generate_order_code_retries_on_collision(self):
        Order.objects.create(code="ABC123")
        with patch("django_ecommerce.models.get_random_string", side_effect=["abc123", "xyz789"]):
            code = generate_order_code()

        self.assertEqual(code, "XYZ789")

    def test_product_variant_save_uppercases_sku(self):
        variant = ProductVariant.objects.create(
            product=self.product,
            name="Medium",
            sku="mixedCase-1",
        )
        self.assertEqual(variant.sku, "MIXEDCASE-1")
