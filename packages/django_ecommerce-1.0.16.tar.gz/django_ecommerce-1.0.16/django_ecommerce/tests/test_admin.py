from datetime import timedelta
from unittest.mock import MagicMock, patch

from django.contrib import admin
from django.contrib.admin.sites import AdminSite
from django.test import RequestFactory, TestCase, override_settings
from django.utils import timezone

from django_ecommerce.admin import DiscountAdmin, OrderItemInline, get_shipping_fields
from django_ecommerce.models import (
    Category,
    Color,
    Discount,
    DiscountCategory,
    Gender,
    Order,
    Product,
)
from django_ecommerce.utils import money


class AdminBehaviorTests(TestCase):
    def setUp(self):
        self.site = AdminSite()
        self.factory = RequestFactory()
        self.request = self.factory.get("/admin/")

    def test_get_shipping_fields_default(self):
        fields = get_shipping_fields()
        self.assertEqual(
            fields,
            [
                "full_name",
                "address",
                "city",
                "zip_code",
                "country",
                "phone",
                "remark",
                "shipping_amount",
            ],
        )

    @override_settings(
        ECOMMERCE_SHIPPING_ADMIN_FIELDS=["full_name", "city", "shipping_amount"]
    )
    def test_get_shipping_fields_uses_override(self):
        self.assertEqual(
            get_shipping_fields(), ["full_name", "city", "shipping_amount"]
        )

    def test_order_item_inline_permissions_for_editable_order(self):
        inline = OrderItemInline(Order, self.site)
        order = Order(status="pending")

        self.assertTrue(inline.has_change_permission(self.request, order))
        self.assertTrue(inline.has_delete_permission(self.request, order))
        self.assertTrue(inline.has_add_permission(self.request, order))

    def test_order_item_inline_permissions_for_immutable_order(self):
        inline = OrderItemInline(Order, self.site)
        order = Order.objects.create(status=Order.RETURN_TO_STOCK_STATUS)

        self.assertFalse(inline.has_change_permission(self.request, order))
        self.assertFalse(inline.has_delete_permission(self.request, order))
        self.assertFalse(inline.has_add_permission(self.request, order))

    def test_discount_admin_save_model_resets_run_fields_when_tracked_fields_change(self):
        discount = Discount.objects.create(
            name="Spring Sale",
            start_date=timezone.now(),
            end_date=timezone.now() + timedelta(days=7),
            active=True,
            last_activation_run=timezone.now(),
            last_deactivation_run=timezone.now(),
        )
        discount_admin = DiscountAdmin(Discount, self.site)
        form = MagicMock()

        discount.name = "Spring Sale Updated"
        discount_admin.save_model(self.request, discount, form, change=True)
        discount.refresh_from_db()

        self.assertIsNone(discount.last_activation_run)
        self.assertIsNone(discount.last_deactivation_run)

    def test_discount_admin_save_related_resets_run_fields_when_inlines_change(self):
        category = Category.objects.create(name="Category")
        color = Color.objects.create(name="Blue")
        gender = Gender.objects.create(name="Unisex")
        Product.objects.create(
            name="Product",
            category=category,
            color=color,
            gender=gender,
            price=money(10),
        )
        discount = Discount.objects.create(
            name="Inline Change",
            start_date=timezone.now(),
            end_date=timezone.now() + timedelta(days=7),
            active=True,
            last_activation_run=timezone.now(),
            last_deactivation_run=timezone.now(),
        )
        DiscountCategory.objects.create(discount=discount, category=category, percentage=10)
        discount_admin = DiscountAdmin(Discount, self.site)

        form = MagicMock()
        form.instance = discount

        changed_formset = MagicMock()
        changed_formset.model = DiscountCategory
        changed_formset.has_changed.return_value = True

        with patch.object(admin.ModelAdmin, "save_related", autospec=True):
            discount_admin.save_related(
                self.request,
                form=form,
                formsets=[changed_formset],
                change=True,
            )

        discount.refresh_from_db()
        self.assertIsNone(discount.last_activation_run)
        self.assertIsNone(discount.last_deactivation_run)
