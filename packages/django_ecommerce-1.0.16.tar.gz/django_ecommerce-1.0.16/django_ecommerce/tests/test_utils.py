from unittest.mock import MagicMock

from django.test import TestCase
from django.test.utils import override_settings
from djmoney.money import Money

from django_ecommerce.models import Category, Product, Color, Gender, ProductVariant, StockImport, Warehouse, Stock, \
    Country, City, Order, Setting, OrderItem
from django_ecommerce.utils import chunks, money, similar_products, variant_availability, add_to_cart, create_order, \
    find_order_by_code, find_category_by_slug, find_product_by_slug, get_countries, get_cities, remove_from_cart, \
    get_cart, get_shipping_data, fetch_variants_with_products, get_variant_availability_map, get_cart_snapshot, \
    add_to_cart_and_snapshot, create_order_from_snapshot, get_order_bundle, annotate_product_card_fields, \
    with_product_card_graph, get_product_availability_map, get_similar_products_bundle, get_category_products_bundle, \
    get_discount_impacted_product_and_section_ids


class UtilsTestCase(TestCase):
    def setUp(self):
        category = Category.objects.create(name='Test')
        color = Color.objects.create(name='Blue')
        gender = Gender.objects.create(name='Unisex')
        Warehouse.objects.create(name='Warehouse1')

        p = Product.objects.create(name='Product1', category=category, color=color, gender=gender, price=money(10))
        ProductVariant.objects.create(product=p, name='Small', sku='PRODUCT1-SMALL')
        ProductVariant.objects.create(product=p, name='Medium', sku='PRODUCT1-MEDIUM')

        Product.objects.create(name='Product2', category=category, color=color, gender=gender, price=money(15))
        Product.objects.create(name='Product3', category=category, color=color, gender=gender, price=money(20))

    def test_chunks(self):
        queryset = [1, 2, 3, 4, 5, 6, 7, 8]
        chunk_size = 3
        result = chunks(queryset, chunk_size)

        self.assertEqual(result, [[1, 2, 3], [4, 5, 6], [7, 8]])

    def test_similar_products(self):
        similar = similar_products(Product.objects.first())
        self.assertTrue(similar)

    def test_variant_availability(self):
        product = Product.objects.first()
        request = self.client.get('/').wsgi_request

        # No stock
        self.assertEqual(variant_availability(product.variants.first(), request), 0)

        # Add to stock
        si = StockImport.objects.create()
        Stock.objects.create(product_variant=product.variants.first(), warehouse=Warehouse.objects.first(), quantity=5,
                             content_object=si)
        self.assertEqual(variant_availability(product.variants.first(), request), 5)

        # Add item to cart
        add_to_cart(request, product.variants.first().pk, 1)
        self.assertEqual(variant_availability(product.variants.first(), request), 4)

        # Create order and reserve items
        order = create_order(request)['order']
        for item in order.items.all():
            item.reserved = True
            item.save()

        self.assertEqual(variant_availability(product.variants.first(), request), 4)

    def test_money(self):
        # Currency argument is provided
        self.assertEqual(money(10, 'USD'), Money(10, 'USD'))

        # Currency argument is not provided, and we have default currency in settings
        with override_settings(ECOMMERCE_DEFAULT_CURRENCY='EUR'):
            self.assertEqual(money(10), Money(10, 'EUR'))

        # Default value for currency
        self.assertEqual(money(10), Money(10, 'EUR'))

    def test_get_shipping_data(self):
        product = Product.objects.first()

        # Shipping is not enabled
        shipping = get_shipping_data(product.price)
        self.assertFalse(shipping['shipping_enabled'])
        self.assertEqual(shipping['shipping_amount'], money(0))

        # Enable shipping
        ecommerce_settings = Setting.get_solo()
        ecommerce_settings.shipping_enabled = True
        ecommerce_settings.shipping_amount = money(3)
        ecommerce_settings.save()

        shipping = get_shipping_data(product.price)
        self.assertTrue(shipping['shipping_enabled'])
        self.assertEqual(shipping['shipping_amount'], money(3))

        # Enable free shipping
        ecommerce_settings.free_shipping_enabled = True
        ecommerce_settings.free_shipping_min_amount = 3 * product.price
        ecommerce_settings.save()

        shipping = get_shipping_data(2 * product.price)
        self.assertTrue(shipping['shipping_enabled'])
        self.assertTrue(shipping['free_shipping_enabled'])
        self.assertEqual(shipping['shipping_amount'], money(3))

        shipping = get_shipping_data(3 * product.price)
        self.assertTrue(shipping['shipping_enabled'])
        self.assertEqual(shipping['shipping_amount'], money(0))

    def test_get_cart(self):
        product = Product.objects.first()
        request = self.client.get('/').wsgi_request

        # Empty Cart
        cart = get_cart(request)
        self.assertEqual(cart['total'], money(0))
        self.assertEqual(cart['quantity'], 0)

        # Add item to cart and check again
        si = StockImport.objects.create()
        stock = Stock.objects.create(product_variant=product.variants.first(), warehouse=Warehouse.objects.first(),
                                     quantity=5,
                                     content_object=si)

        self.assertEqual(add_to_cart(request, product.variants.first().pk, 2), {'remaining': True})

        cart = get_cart(request)
        self.assertEqual(cart['total'], 2 * product.price)
        self.assertEqual(cart['quantity'], 2)

        # Check if quantity is updated when stock is updated
        stock.quantity = 1
        stock.save()
        cart = get_cart(request)
        self.assertEqual(cart['total'], product.price)
        self.assertEqual(cart['quantity'], 1)

        # Check if item is removed from cart
        stock.delete()
        cart = get_cart(request)
        self.assertEqual(cart['total'], money(0))
        self.assertEqual(cart['quantity'], 0)

    def test_remove_from_cart(self):
        product = Product.objects.first()
        request = self.client.get('/').wsgi_request

        si = StockImport.objects.create()
        Stock.objects.create(product_variant=product.variants.first(), warehouse=Warehouse.objects.first(), quantity=5,
                             content_object=si)

        self.assertEqual(add_to_cart(request, product.variants.first().pk, 3), {'remaining': True})
        remove_from_cart(request, product.variants.first().pk)
        self.assertNotIn(str(product.variants.first()), request.session.get('cart'))

    def test_add_to_cart(self):
        product = Product.objects.first()
        request = self.client.get('/').wsgi_request

        # Check invalid variant id
        self.assertEqual(add_to_cart(request, 12345), {'error': f'ProductVariantDoesNotExist'})

        # Check for stock data
        self.assertEqual(add_to_cart(request, product.variants.first().pk), {'error': f'StockError'})

        # Add stock and then add to cart
        si = StockImport.objects.create()
        Stock.objects.create(product_variant=product.variants.first(), warehouse=Warehouse.objects.first(), quantity=5,
                             content_object=si)

        self.assertEqual(add_to_cart(request, product.variants.first().pk, 4), {'remaining': True})
        self.assertEqual(add_to_cart(request, product.variants.first().pk, 1), {'remaining': False})
        self.assertEqual(add_to_cart(request, product.variants.first().pk, -1), {'remaining': True})

        # Check if it was removed from cart correctly
        add_to_cart(request, product.variants.first().pk, -4)
        self.assertNotIn(str(product.variants.first()), request.session.get('cart'))

    def test_create_order(self):
        product = Product.objects.first()
        request = self.client.get('/').wsgi_request

        # Create a mock function
        mock_func = MagicMock()

        # Order params
        params = {
            'email': 'test@example.com',
            'full_name': 'Hello World',
            'address': 'Test address',
            'phone': '1234567890',
            'city': 'Test',
            'country': 'Test',
            'zip_code': '123456',
            'remark': 'Test',
        }

        # Check when cart is empty
        self.assertEqual(create_order(request), {'error': 'EmptyCart'})

        # Add item to cart and create order
        si = StockImport.objects.create()
        Stock.objects.create(product_variant=product.variants.first(), warehouse=Warehouse.objects.first(), quantity=5,
                             content_object=si)

        add_to_cart(request, product.variants.first().pk, 2)
        result = create_order(request, func=mock_func, **params)

        # Assert that the order was created
        self.assertTrue('order' in result)
        order = result['order']
        self.assertIsInstance(order, Order)

        # Assert that the session cart is empty after order creation
        self.assertNotIn('cart', request)

        # Check if params were saved correctly
        for k, v in params.items():
            self.assertEqual(v, getattr(order, k))

        # Assert that the mock function was called with the expected arguments
        mock_func.assert_called_once_with(request, order)

        # Check if order item was saved correctly
        item = order.items.first()
        self.assertEqual(item.product_variant, product.variants.first())
        self.assertEqual(item.price, product.price)
        self.assertEqual(item.quantity, 2)

    def test_get_cart_query_count_for_multiple_items(self):
        request = self.client.get('/').wsgi_request
        category = Category.objects.first()
        color = Color.objects.first()
        gender = Gender.objects.first()
        warehouse = Warehouse.objects.first()

        variants = []
        for index in range(4):
            product = Product.objects.create(
                name=f"PerfProduct{index}",
                category=category,
                color=color,
                gender=gender,
                price=money(10 + index),
            )
            variant = ProductVariant.objects.create(
                product=product,
                name=f"Size{index}",
                sku=f"PERF-{index}",
            )
            si = StockImport.objects.create()
            Stock.objects.create(
                product_variant=variant,
                warehouse=warehouse,
                quantity=10,
                content_object=si,
            )
            variants.append(variant)

        request.session["cart"] = {str(variant.pk): 1 for variant in variants}
        request.session.modified = True

        with self.assertNumQueries(7):
            cart = get_cart(request)

        self.assertEqual(cart["quantity"], len(variants))

    def test_create_order_query_count_for_multiple_items(self):
        request = self.client.get('/').wsgi_request
        category = Category.objects.first()
        color = Color.objects.first()
        gender = Gender.objects.first()
        warehouse = Warehouse.objects.first()

        variants = []
        for index in range(3):
            product = Product.objects.create(
                name=f"OrderPerfProduct{index}",
                category=category,
                color=color,
                gender=gender,
                price=money(20 + index),
            )
            variant = ProductVariant.objects.create(
                product=product,
                name=f"OrderSize{index}",
                sku=f"ORDER-PERF-{index}",
            )
            si = StockImport.objects.create()
            Stock.objects.create(
                product_variant=variant,
                warehouse=warehouse,
                quantity=5,
                content_object=si,
            )
            variants.append(variant)

        request.session["cart"] = {str(variant.pk): 1 for variant in variants}
        request.session.modified = True

        with self.assertNumQueries(10):
            result = create_order(request)

        self.assertIn("order", result)

    def test_fetch_variants_with_products(self):
        variants = list(ProductVariant.objects.all()[:2])
        result = fetch_variants_with_products([variant.pk for variant in variants])

        self.assertEqual(set(result.keys()), {variant.pk for variant in variants})
        self.assertTrue(all(variant.product for variant in result.values()))

    def test_get_variant_availability_map(self):
        product = Product.objects.first()
        variant = product.variants.first()
        request = self.client.get("/").wsgi_request
        request.session["cart"] = {}

        si = StockImport.objects.create()
        Stock.objects.create(
            product_variant=variant,
            warehouse=Warehouse.objects.first(),
            quantity=5,
            content_object=si,
        )

        request.session["cart"][str(variant.pk)] = 2
        request.session.modified = True

        availability = get_variant_availability_map(request, [variant.pk], include_reserved=True)
        self.assertEqual(availability[variant.pk], 3)

    def test_get_cart_snapshot_memoized(self):
        request = self.client.get("/").wsgi_request
        product = Product.objects.first()
        variant = product.variants.first()
        si = StockImport.objects.create()
        Stock.objects.create(
            product_variant=variant,
            warehouse=Warehouse.objects.first(),
            quantity=5,
            content_object=si,
        )
        request.session["cart"] = {str(variant.pk): 2}
        request.session.modified = True

        with self.assertNumQueries(9):
            first = get_cart_snapshot(request, include_images=True)
        with self.assertNumQueries(0):
            second = get_cart_snapshot(request, include_images=True)

        self.assertEqual(first.quantity, second.quantity)
        self.assertEqual(first.total, 2 * product.price)

    def test_add_to_cart_and_snapshot(self):
        request = self.client.get("/").wsgi_request
        product = Product.objects.first()
        variant = product.variants.first()
        si = StockImport.objects.create()
        Stock.objects.create(
            product_variant=variant,
            warehouse=Warehouse.objects.first(),
            quantity=5,
            content_object=si,
        )

        result = add_to_cart_and_snapshot(request, variant.pk, 2)
        self.assertTrue(result["ok"])
        self.assertEqual(result["snapshot"].quantity, 2)
        self.assertTrue(result["remaining"])

    def test_create_order_from_snapshot(self):
        request = self.client.get("/").wsgi_request
        product = Product.objects.first()
        variant = product.variants.first()
        si = StockImport.objects.create()
        Stock.objects.create(
            product_variant=variant,
            warehouse=Warehouse.objects.first(),
            quantity=4,
            content_object=si,
        )
        request.session["cart"] = {str(variant.pk): 2}
        request.session.modified = True

        snapshot = get_cart_snapshot(request)
        result = create_order_from_snapshot(
            request,
            customer={"email": "snapshot@example.com", "full_name": "Snapshot User"},
            snapshot=snapshot,
        )

        self.assertIn("order", result)
        self.assertEqual(result["order"].items.count(), 1)
        self.assertNotIn("cart", request.session)

    def test_get_order_bundle(self):
        product = Product.objects.first()
        variant = product.variants.first()
        order = Order.objects.create()
        OrderItem.objects.create(
            order=order,
            product_variant=variant,
            price=product.price,
            quantity=1,
        )

        with self.assertNumQueries(9):
            fetched_order = get_order_bundle(order.code)

        self.assertEqual(fetched_order.pk, order.pk)

    def test_annotate_product_card_fields(self):
        product = Product.objects.first()
        qs = annotate_product_card_fields(Product.objects.filter(pk=product.pk))
        annotated = qs.get()
        self.assertTrue(hasattr(annotated, "in_stock"))
        self.assertTrue(hasattr(annotated, "effective_discount_percent"))
        self.assertTrue(hasattr(annotated, "has_active_discount"))
        self.assertTrue(hasattr(annotated, "effective_price"))

    def test_with_product_card_graph(self):
        qs = with_product_card_graph(Product.objects.all(), include_variants=True)
        with self.assertNumQueries(5):
            list(qs)

    def test_get_product_availability_map(self):
        product = Product.objects.first()
        variant = product.variants.first()
        si = StockImport.objects.create()
        Stock.objects.create(
            product_variant=variant,
            warehouse=Warehouse.objects.first(),
            quantity=3,
            content_object=si,
        )

        result = get_product_availability_map([product.pk])
        self.assertEqual(result[product.pk], 3)

    def test_get_similar_products_bundle(self):
        product = Product.objects.first()
        result = get_similar_products_bundle(product.pk, limit=2)
        self.assertLessEqual(len(result), 2)
        for item in result:
            self.assertNotEqual(item.pk, product.pk)
            self.assertEqual(item.category_id, product.category_id)

    def test_get_category_products_bundle(self):
        category = Category.objects.first()
        product = Product.objects.first()
        variant = product.variants.first()
        si = StockImport.objects.create()
        Stock.objects.create(
            product_variant=variant,
            warehouse=Warehouse.objects.first(),
            quantity=4,
            content_object=si,
        )

        result = get_category_products_bundle(category.slug, only_in_stock=True)
        self.assertEqual(result["category"].pk, category.pk)
        self.assertTrue(result["products"].exists())

    def test_get_discount_impacted_product_and_section_ids(self):
        category = Category.objects.first()
        product = Product.objects.first()
        result = get_discount_impacted_product_and_section_ids()
        self.assertIn("product_ids", result)
        self.assertIn("section_ids", result)
        self.assertIsInstance(result["product_ids"], set)
        self.assertIsInstance(result["section_ids"], set)
        # Baseline: with no active discounts this is empty.
        self.assertFalse(result["product_ids"])
        self.assertFalse(result["section_ids"])

        self.assertEqual(product.category_id, category.pk)

    def test_get_cities(self):
        c1 = City.objects.create(name='City1')
        c2 = City.objects.create(name='City1')

        self.assertEqual(get_cities(), {c1.name, c2.name})

    def test_get_countries(self):
        c1 = Country.objects.create(name='Country1')
        c2 = Country.objects.create(name='Country2')

        self.assertEqual(get_countries(), {c1.name, c2.name})

    def test_find_product_by_slug(self):
        p = Product.objects.first()

        self.assertEqual(find_product_by_slug(p.slug), p)

    def test_find_category_by_slug(self):
        c = Category.objects.create(name='MyCategory', slug='my-category')

        self.assertEqual(find_category_by_slug(c.slug), c)

    def test_find_order_by_code(self):
        product = Product.objects.first()

        request = self.client.get('/').wsgi_request

        si = StockImport.objects.create()
        Stock.objects.create(product_variant=product.variants.first(), warehouse=Warehouse.objects.first(), quantity=5,
                             content_object=si)

        add_to_cart(request, product.variants.first().pk)

        order = create_order(request)['order']

        self.assertEqual(find_order_by_code(order.code), order)
