import hashlib
from pathlib import Path

from loguru import logger
from single_source import get_version

from .tools.tools_plugins import installed_plugins

__version__ = get_version(__name__, Path(__file__).parent.parent)
__package_name__ = __name__

_HASH_EXTENSIONS = [".py"]
_IGNORED_FILES = [
    # Prevent to change hash, if contributors
    # a new supported device
    "usb_devices.py",
    # routes_website contains only routes for testing purpose
    # for the web interface. only 'routes_odoo' should be hashed.
    "routes_website.py",
]


def md5_update_from_dir(directory, hash_value):
    assert Path(directory).is_dir()
    for path in sorted(Path(directory).iterdir(), key=lambda p: str(p).lower()):
        hash_value.update(path.name.encode())
        if path.is_file():
            if path.suffix not in _HASH_EXTENSIONS:
                continue
            if path.name in _IGNORED_FILES:
                continue
            logger.debug(f"Hashing file {path.absolute()}...")
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_value.update(chunk)
        elif path.is_dir():
            hash_value = md5_update_from_dir(path, hash_value)
    return hash_value


logger.info("Computing hash for 'odoo_driver'...")
code_hash = md5_update_from_dir(__path__[0], hashlib.md5()).hexdigest()
logger.info(f"Hash of odoo_driver is '{code_hash}'")

for module_name, plugin in installed_plugins.items():
    logger.info(f"Computing hash for plugin '{module_name}'...")
    code_hash = md5_update_from_dir(plugin.__path__[0], hashlib.md5()).hexdigest()
    logger.info(f"Hash of {module_name} is '{code_hash}'")
    setattr(plugin, "code_hash", code_hash)
