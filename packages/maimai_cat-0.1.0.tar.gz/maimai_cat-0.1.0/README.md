# maimai_cat

`maimai_cat` 是脉脉（maimai）平台的 Python API 封装工具库，提供候选人搜索、详情查询、分组管理、星标、点评、联系记录、项目关联、备注、统计数据、标签、动态及求职意向等完整功能，帮助招聘团队高效管理人才资源。

---

## 功能特性

- **候选人搜索**：按关键词搜索候选人，支持分页，结果可打印或保存到本地
- **候选人详情**：获取基本简历信息（姓名、公司、职位、教育经历等）
- **点评列表**：查看其他人对候选人的点评内容
- **联系记录**：获取团队成员与候选人的历史联系记录
- **项目关联**：查询候选人所在的招聘项目列表
- **同事备注**：获取团队成员对候选人的备注信息
- **统计数据**：查看候选人的查看次数、沟通次数等综合指标
- **个人标签**：获取候选人的平台标签信息
- **动态记录**：获取候选人的查看记录与消息动态
- **求职意向**：查询候选人的看机会状态与期望岗位
- **分组管理**：创建、查询、删除分组，将候选人添加到指定分组
- **星标管理**：对候选人进行星标或取消星标

---

## 安装和环境配置

### 安装

```shell
pip install maimai_cat
```

### 前置条件：导出脉脉 Cookie

`maimai_cat` 通过 Cookie 完成身份认证，使用前需导出你的脉脉登录 Cookie：

1. 在 Chrome 浏览器中登录 [maimai.cn](https://maimai.cn)
2. 安装 Chrome 扩展 [EditThisCookie](https://chrome.google.com/webstore/detail/editthiscookie/fngmhnnpilhplaeedifhccceomclgfbg)
3. 打开脉脉任意页面，点击 EditThisCookie 图标，选择 **导出** → 导出为 JSON 格式
4. 将导出的内容保存为 `cookies.json` 文件，放置在你的脚本同级目录

> **注意**：Cookie 具有时效性，若请求返回未登录错误，请重新导出 Cookie。

---

## 使用示例

### 初始化

```python
from maimai.api import MaimaiAPI

# 默认读取同目录下的 cookies.json
api = MaimaiAPI().connect()
```

如果 `cookies.json` 不在脚本同级目录，可在 `LoginManager` 中指定路径（或子类传入）：

```python
# 目前通过直接修改 cookies_file 路径实现
from maimai.api import MaimaiAPI, Group, User, Search

group = Group(cookies_file="/path/to/cookies.json")
```

---

### 候选人搜索

```python
# 关键词搜索，page 从 0 开始，最大 30 页
result = api.search.keyword("LLM", page=0)
api.pretty_print(result)

# 搜索并在控制台格式化打印每位候选人信息
api.search.extract_search_result(api.search.keyword("Google", page=0))

# 搜索并将每位候选人数据保存为 JSON 文件到 ./profile_data 目录
api.search.save_search_result(api.search.keyword("Microsoft", page=0), folder="./profile_data")

# 使用 search_api 接口搜索（另一种搜索方式，返回联系人列表）
contacts = api.search.search_api(keyword="张三", page=1)
print(contacts)

# 搜索并保存到本地文件夹
api.search.search_api_save_file(keyword="张三", page=1, folder="./search_api")

# 查询某关键词搜索结果总数
total = api.search.search_api_total_page(keyword="LLM")
print(f"搜索总条数: {total}")
```

---

### 候选人详情

```python
uid = 41962985

# 获取候选人基本简历（姓名、公司、职位、教育经历等）
api.pretty_print(api.user.read(uid))

# 获取其他人对该候选人的点评列表
api.pretty_print(api.user.get_comments(uid))

# 获取团队成员与该候选人的联系记录
api.pretty_print(api.user.get_contact_status(uid))

# 获取候选人所在的招聘项目列表
api.pretty_print(api.user.get_projects(uid))

# 获取团队成员对该候选人的备注（page 从 0 开始，size 每页条数）
api.pretty_print(api.user.get_remarks(uid, page=0, size=5))

# 获取候选人综合统计数据（查看次数、沟通次数等）
api.pretty_print(api.user.get_stats(uid))

# 获取候选人的个人标签列表
api.pretty_print(api.user.get_tags(uid))

# 获取候选人的查看记录与消息动态
api.pretty_print(api.user.get_dynamic(uid))

# 获取候选人的求职意向（看机会状态、期望岗位等）
api.pretty_print(api.user.get_job_preference(uid, page=0, size=20))
```

---

### 分组管理

```python
# 创建新分组
api.pretty_print(api.group.create("LLM方向"))

# 查询所有分组列表（默认返回最多 100 个）
api.pretty_print(api.group.read())

# 将候选人添加到指定分组（user_group_ids 为分组 ID 列表）
api.pretty_print(api.group.add_user_to_group(uid=41962985, user_group_ids=[1323029]))

# 删除指定分组
api.pretty_print(api.group.delete(group_id=1323029))
```

---

### 星标管理

```python
# 星标候选人
api.pretty_print(api.group.star(79460397))

# 取消星标
api.pretty_print(api.group.unstar(41962985))
```

---

## API 接口说明

### `api.user` — 候选人相关

| 方法 | 参数 | 说明 |
|------|------|------|
| `read(to_uid)` | `to_uid: int` | 获取候选人基本简历信息 |
| `get_comments(user_id)` | `user_id: int` | 获取其他人对候选人的点评列表 |
| `get_contact_status(to_uid)` | `to_uid: int` | 获取团队成员与候选人的联系记录 |
| `get_projects(to_uid)` | `to_uid: int` | 获取候选人关联的招聘项目列表 |
| `get_remarks(to_uid, page, size)` | `to_uid: int`, `page: int=0`, `size: int=5` | 获取团队成员对候选人的备注列表 |
| `get_stats(to_uids)` | `to_uids: int` | 获取候选人综合统计数据 |
| `get_tags(tagu)` | `tagu: int` | 获取候选人的个人标签信息 |
| `get_dynamic(to_uids)` | `to_uids: int` | 获取候选人的查看记录与消息动态 |
| `get_job_preference(to_uid, page, size)` | `to_uid: int`, `page: int=0`, `size: int=20` | 获取候选人的求职意向 |

### `api.group` — 分组管理

| 方法 | 参数 | 说明 |
|------|------|------|
| `create(name)` | `name: str` | 创建新分组 |
| `read(page, size)` | `page: int=0`, `size: int=100` | 查询分组列表 |
| `delete(group_id)` | `group_id: int` | 删除指定分组 |
| `add_user_to_group(uid, user_group_ids)` | `uid: int`, `user_group_ids: list` | 将候选人添加到分组 |
| `star(uid)` | `uid: int` | 星标候选人 |
| `unstar(uid)` | `uid: int` | 取消星标候选人 |

### `api.search` — 搜索相关

| 方法 | 参数 | 说明 |
|------|------|------|
| `keyword(keyword, page, **kwargs)` | `keyword: str`, `page: int=0` | 企业版关键词搜索 |
| `search_api(keyword, page, user)` | `keyword: str`, `page: int=1` | 公开搜索接口 |
| `search_api_save_file(keyword, page, user, folder)` | `keyword: str`, `folder: str` | 搜索并保存结果到本地 |
| `search_api_total_page(keyword, page, user)` | `keyword: str` | 查询搜索结果总条数 |
| `extract_search_result(json_data)` | `json_data: dict` | 在控制台格式化打印搜索结果 |
| `save_search_result(json_data, folder)` | `json_data: dict`, `folder: str` | 将搜索结果保存为本地 JSON 文件 |

---

## 依赖项

| 依赖 | 版本要求 | 说明 |
|------|---------|------|
| Python | >= 3.7 | 语言运行环境 |
| requests | 最新稳定版 | HTTP 请求库 |
| colorama | 最新稳定版 | 终端彩色输出 |

安装所有依赖：

```shell
pip install requests colorama
```

---

## 贡献指南与许可证

### 贡献指南

欢迎提交 Issue 或 Pull Request。贡献代码时请确保：

1. 代码符合 Python PEP 8 规范
2. 新增方法须包含完整的中文 docstring（参数类型、返回值说明）
3. 提交前在本地完成基本功能测试

### 许可证

本项目基于 [MIT License](LICENSE) 开源，允许自由使用、修改和分发。
