from __future__ import annotations

import os
from pathlib import Path, PurePosixPath
import tempfile
from typing import Any
from urllib.parse import unquote, urlparse
from urllib.request import Request, urlopen


DEFAULT_PROJECT_PATH = "/workspace/projects"
DEFAULT_ATTACHMENT_DIR = "assets"
MAX_ATTACHMENT_BYTES = 20 * 1024 * 1024


def project_path() -> Path:
    return Path(os.environ.get("LICOS_PROJECT_PATH") or DEFAULT_PROJECT_PATH).resolve()


def attachment_dir(project_root: Path | None = None) -> Path:
    root = project_root or project_path()
    configured = os.environ.get("LICOS_AGENT_ATTACHMENT_DIR") or DEFAULT_ATTACHMENT_DIR
    relative = PurePosixPath(str(configured).replace("\\", "/"))
    if relative.is_absolute() or any(part == ".." for part in relative.parts):
        relative = PurePosixPath(DEFAULT_ATTACHMENT_DIR)
    return root.joinpath(*relative.parts)


def extract_upload_file(item: Any) -> dict[str, Any] | None:
    if not isinstance(item, dict):
        return None

    upload_file: Any = None
    if item.get("type") == "upload_file":
        content = item.get("content")
        if isinstance(content, dict):
            upload_file = content.get("upload_file") or content.get("file")
        elif isinstance(content, str):
            upload_file = {"url": content}
    elif "upload_file" in item:
        upload_file = item.get("upload_file")

    if not isinstance(upload_file, dict):
        return None
    return dict(upload_file)


def materialize_upload_file(upload_file: dict[str, Any], index: int = 0) -> dict[str, Any]:
    root = project_path()
    assets = attachment_dir(root)
    file_name = _safe_file_name(
        upload_file.get("file_name")
        or upload_file.get("name")
        or _file_name_from_url(upload_file.get("url"))
        or f"attachment-{index + 1}"
    )
    dest = (assets / file_name).resolve()
    record = _attachment_record(upload_file, root, dest, file_name)

    try:
        _ensure_inside(root, dest)
        assets.mkdir(parents=True, exist_ok=True)

        url = upload_file.get("url")
        if isinstance(url, str) and url.strip():
            content_type = _download_to_file(url.strip(), dest)
            record.update(_saved_record(root, dest))
            if content_type:
                record["mime_type"] = content_type
            record["file_type"] = infer_file_type(record)
            return record

        record["status"] = "failed"
        record["error"] = "missing upload_file.url"
        record["file_type"] = infer_file_type(record)
        return record
    except Exception as exc:
        record["status"] = "failed"
        record["error"] = str(exc) or exc.__class__.__name__
        record["file_type"] = infer_file_type(record)
        return record


def materialize_upload_files(upload_files: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [materialize_upload_file(upload_file, index) for index, upload_file in enumerate(upload_files)]


def format_attachment_manifest(attachments: list[dict[str, Any]]) -> str:
    if not attachments:
        return ""
    lines = ["Attachments:"]
    for attachment in attachments:
        file_name = attachment.get("file_name") or ""
        file_path = attachment.get("file_path") or ""
        status = attachment.get("status") or ""
        line = f"- file_name: {file_name}"
        if file_path:
            line += f", file_path: {file_path}"
        if status and status != "saved":
            line += f", status: {status}"
        if attachment.get("error"):
            line += f", error: {attachment['error']}"
        lines.append(line)
    return "\n".join(lines)


def content_parts_for_attachment(attachment: dict[str, Any]) -> list[dict[str, Any]]:
    url = str(attachment.get("url") or attachment.get("source_url") or "")
    file_name = str(attachment.get("file_name") or "")
    file_path = str(attachment.get("file_path") or "")
    file_type = str(attachment.get("file_type") or infer_file_type(attachment))
    mime_type = str(attachment.get("mime_type") or "")

    if file_type == "image" and url:
        return [
            {"type": "text", "text": url},
            {"type": "image_url", "image_url": {"url": url}},
        ]
    if file_type == "video" and url:
        video_url: dict[str, Any] = {"url": url}
        if mime_type:
            video_url["media_type"] = mime_type
        return [
            {"type": "text", "text": url},
            {"type": "video_url", "video_url": video_url},
        ]
    if file_type == "audio" and url:
        return [{"type": "text", "text": f"audio url: {url}"}]

    text = f"file name:{file_name}, url: {url}"
    if file_path:
        text += f"\nlocal file path: {file_path}"
    extracted = extract_text_preview(attachment)
    if extracted:
        text += f"\n\nFile Content:\n{extracted}"
    return [{"type": "text", "text": text}]


def infer_file_type(attachment: dict[str, Any]) -> str:
    mime_type = str(attachment.get("mime_type") or "").split(";")[0].strip().lower()
    if mime_type:
        top = mime_type.split("/", 1)[0]
        if top in {"image", "video", "audio"}:
            return top
        if top == "text" or mime_type in {
            "application/json",
            "application/xml",
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-powerpoint",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        }:
            return "document"

    for value in (attachment.get("file_name"), attachment.get("url"), attachment.get("source_url")):
        ext = _extension(value)
        if not ext:
            continue
        if ext in IMAGE_EXTENSIONS:
            return "image"
        if ext in VIDEO_EXTENSIONS:
            return "video"
        if ext in AUDIO_EXTENSIONS:
            return "audio"
        if ext in DOCUMENT_EXTENSIONS:
            return "document"
    return "default"


def extract_text_preview(attachment: dict[str, Any]) -> str:
    path = attachment.get("local_path")
    if not isinstance(path, str) or not path:
        return ""
    suffix = _extension(path)
    if suffix not in TEXT_PREVIEW_EXTENSIONS:
        return ""
    try:
        data = Path(path).read_bytes()
    except OSError:
        return ""
    if len(data) > TEXT_PREVIEW_MAX_BYTES:
        data = data[:TEXT_PREVIEW_MAX_BYTES]
    return data.decode("utf-8", errors="replace")


def _attachment_record(upload_file: dict[str, Any], root: Path, dest: Path, file_name: str) -> dict[str, Any]:
    source_file_name = upload_file.get("file_name") or upload_file.get("name")
    record: dict[str, Any] = {
        "type": "upload_file",
        "file_name": file_name,
        "file_path": _relative_posix(root, dest),
        "local_path": str(dest),
        "status": "pending",
    }
    if source_file_name and str(source_file_name) != file_name:
        record["original_file_name"] = str(source_file_name)
    for source_key, target_key in (
        ("url", "url"),
        ("mime_type", "mime_type"),
        ("content_type", "mime_type"),
        ("size", "size"),
    ):
        value = upload_file.get(source_key)
        if value not in (None, "") and target_key not in record:
            record[target_key] = value
    record["file_type"] = infer_file_type(record)
    return record


def _saved_record(root: Path, dest: Path) -> dict[str, Any]:
    stat = dest.stat()
    return {
        "file_path": _relative_posix(root, dest),
        "local_path": str(dest),
        "size": stat.st_size,
        "status": "saved",
    }


def _download_to_file(url: str, dest: Path) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError(f"unsupported upload_file.url scheme: {parsed.scheme or '<empty>'}")

    timeout = _float_env("LICOS_AGENT_ATTACHMENT_TIMEOUT_SECONDS", 30.0)
    configured_max_bytes = int(_float_env("LICOS_AGENT_ATTACHMENT_MAX_BYTES", MAX_ATTACHMENT_BYTES))
    max_bytes = min(configured_max_bytes, MAX_ATTACHMENT_BYTES)
    request = Request(url, headers={"User-Agent": "licos-agent-runtime"})

    tmp_path: Path | None = None
    try:
        content_type = ""
        with urlopen(request, timeout=timeout) as response:
            content_type = str(response.headers.get("Content-Type") or "").split(";", 1)[0].strip()
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > max_bytes:
                raise ValueError(f"attachment exceeds max size: {content_length} > {max_bytes}")

            with tempfile.NamedTemporaryFile(delete=False, dir=str(dest.parent), prefix=f".{dest.name}.") as tmp:
                tmp_path = Path(tmp.name)
                total = 0
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > max_bytes:
                        raise ValueError(f"attachment exceeds max size: {total} > {max_bytes}")
                    tmp.write(chunk)

        if tmp_path is None:
            raise ValueError("failed to create temporary attachment file")
        os.replace(tmp_path, dest)
        return content_type
    except Exception:
        if tmp_path is not None and tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass
        raise


def _ensure_inside(root: Path, path: Path) -> None:
    root_resolved = root.resolve()
    path_resolved = path.resolve()
    if path_resolved == root_resolved:
        return
    if root_resolved not in path_resolved.parents:
        raise ValueError(f"path is outside project root: {path}")


def _safe_file_name(value: Any) -> str:
    raw = str(value or "").replace("\\", "/")
    name = PurePosixPath(raw).name.strip()
    if not name:
        name = "attachment"
    sanitized = "".join("_" if char in {'/', '\\', ':', '*', '?', '"', '<', '>', '|'} or ord(char) < 32 else char for char in name)
    sanitized = sanitized.strip(" .")
    return sanitized or "attachment"


def _file_name_from_url(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    parsed = urlparse(value)
    name = PurePosixPath(unquote(parsed.path)).name
    return name or None


def _extension(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        return ""
    parsed = urlparse(value)
    path = unquote(parsed.path or value)
    suffix = PurePosixPath(path).suffix.lower().lstrip(".")
    return suffix


def _relative_posix(root: Path, path: Path) -> str:
    try:
        relative = path.resolve().relative_to(root.resolve())
    except ValueError:
        return path.name
    return relative.as_posix()


def _float_env(name: str, default: float) -> float:
    value = os.environ.get(name)
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


IMAGE_EXTENSIONS = {
    "apng",
    "avif",
    "bmp",
    "gif",
    "heic",
    "ico",
    "jpg",
    "jpeg",
    "png",
    "svg",
    "tiff",
    "webp",
}
VIDEO_EXTENSIONS = {"mp4", "avi", "mov", "mkv", "flv", "wmv", "webm", "m4v", "3gp"}
AUDIO_EXTENSIONS = {"mp3", "wav", "flac", "aac", "ogg", "wma", "m4a"}
DOCUMENT_EXTENSIONS = {
    "pdf",
    "doc",
    "docx",
    "xls",
    "xlsx",
    "ppt",
    "pptx",
    "txt",
    "md",
    "csv",
    "json",
    "xml",
    "html",
    "htm",
}
TEXT_PREVIEW_EXTENSIONS = {"txt", "md", "csv", "json", "xml", "html", "htm", "log"}
TEXT_PREVIEW_MAX_BYTES = 200_000
