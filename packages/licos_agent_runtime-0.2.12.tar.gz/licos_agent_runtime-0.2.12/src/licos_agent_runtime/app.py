from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles

from . import telemetry
from .context import new_context, request_context
from .errors import extract_core_stack
from .graph_loader import is_agent_project
from .openai import OpenAIChatHandler
from .service import GraphService
from .stream_runner import RunOpt, agent_stream_handler, workflow_stream_handler
from .trace_records import clear_run_records, get_run_record, list_run_records

logger = logging.getLogger(__name__)

HEADER_X_RUN_ID = "x-run-id"
HEADER_X_WORKFLOW_STREAM_MODE = "x-workflow-stream-mode"


def _project_assets_dir() -> Path:
    project_dir = Path(os.environ.get("LICOS_PROJECT_PATH") or os.getcwd()).resolve()
    return (project_dir / "assets").resolve()


def create_app(service: GraphService | None = None) -> FastAPI:
    runtime_service = service or GraphService()
    openai_handler = OpenAIChatHandler(runtime_service)
    app = FastAPI()
    app.mount("/assets", StaticFiles(directory=str(_project_assets_dir()), check_dir=False), name="assets")

    def register_task(run_id: str, task: asyncio.Task) -> None:
        runtime_service.running_tasks[run_id] = task

    @app.post("/run")
    async def http_run(request: Request) -> dict[str, Any]:
        raw_body = await request.body()
        try:
            body_text = raw_body.decode("utf-8")
        except UnicodeDecodeError:
            body_text = str(raw_body)

        ctx = new_context(method="run", headers=request.headers)
        request_context.set(ctx)
        logger.info(
            "Received /run: run_id=%s query=%s body=%s",
            ctx.run_id,
            dict(request.query_params),
            body_text,
        )

        try:
            payload = json.loads(body_text) if body_text else {}
            return await runtime_service.run_with_timeout(payload, ctx)
        except json.JSONDecodeError as exc:
            logger.error("JSON decode error in /run: %s", exc)
            raise HTTPException(status_code=400, detail=f"Invalid JSON format: {extract_core_stack()}") from exc
        except asyncio.CancelledError:
            return {"status": "cancelled", "run_id": ctx.run_id, "message": "Execution was cancelled"}
        except Exception as exc:
            error_response = runtime_service.error_classifier.get_error_response(
                exc,
                {"node_name": "http_run", "run_id": ctx.run_id},
            )
            logger.error("Unexpected error in /run: %s", error_response, exc_info=True)
            raise HTTPException(
                status_code=500,
                detail={
                    "error_code": error_response["error_code"],
                    "error_message": error_response["error_message"],
                    "stack_trace": extract_core_stack(),
                },
            ) from exc
        finally:
            telemetry.flush()

    @app.post("/stream_run")
    async def http_stream_run(request: Request) -> StreamingResponse:
        ctx = new_context(method="stream_run", headers=request.headers)
        request_context.set(ctx)
        workflow_stream_mode = request.headers.get(HEADER_X_WORKFLOW_STREAM_MODE, "").lower()
        workflow_debug = workflow_stream_mode == "debug"
        stream_mode = "debug" if workflow_debug else "updates"
        run_opt = RunOpt(workflow_debug=workflow_debug, stream_mode=stream_mode, platform_stream_protocol=True)
        raw_body = await request.body()
        try:
            body_text = raw_body.decode("utf-8")
        except UnicodeDecodeError:
            body_text = str(raw_body)
        logger.info(
            "Received /stream_run: run_id=%s is_agent_project=%s query=%s body=%s",
            ctx.run_id,
            is_agent_project(),
            dict(request.query_params),
            body_text,
        )

        try:
            payload = json.loads(body_text) if body_text else {}
        except json.JSONDecodeError as exc:
            logger.error("JSON decode error in /stream_run: %s", exc)
            raise HTTPException(status_code=400, detail=f"Invalid JSON format: {extract_core_stack()}") from exc

        if is_agent_project():
            stream_generator = agent_stream_handler(
                payload=payload,
                ctx=ctx,
                run_id=ctx.run_id,
                stream_sse_func=runtime_service.stream_sse,
                sse_event_func=runtime_service._sse_event,
                error_classifier=runtime_service.error_classifier,
                register_task_func=register_task,
                run_opt=run_opt,
            )
        else:
            stream_generator = workflow_stream_handler(
                payload=payload,
                ctx=ctx,
                run_id=ctx.run_id,
                stream_sse_func=runtime_service.stream_sse,
                sse_event_func=runtime_service._sse_event,
                error_classifier=runtime_service.error_classifier,
                register_task_func=register_task,
                run_opt=run_opt,
            )

        return StreamingResponse(stream_generator, media_type="text/event-stream")

    @app.post("/cancel/{run_id}")
    async def http_cancel(run_id: str, request: Request) -> dict[str, Any]:
        ctx = new_context(method="cancel", headers=request.headers)
        request_context.set(ctx)
        return runtime_service.cancel_run(run_id, ctx)

    @app.post("/node_run/{node_id}")
    async def http_node_run(node_id: str, request: Request) -> Any:
        raw_body = await request.body()
        try:
            body_text = raw_body.decode("utf-8")
        except UnicodeDecodeError:
            body_text = str(raw_body)
        ctx = new_context(method="node_run", headers=request.headers)
        request_context.set(ctx)
        try:
            payload = json.loads(body_text) if body_text else {}
            return await runtime_service.run_node(node_id, payload, ctx)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail=f"Invalid JSON format: {extract_core_stack()}") from exc
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:
            error_response = runtime_service.error_classifier.get_error_response(exc, {"node_name": node_id})
            logger.error("Unexpected error in /node_run/%s: %s", node_id, error_response, exc_info=True)
            raise HTTPException(
                status_code=500,
                detail={
                    "error_code": error_response["error_code"],
                    "error_message": error_response["error_message"],
                    "stack_trace": extract_core_stack(),
                },
            ) from exc
        finally:
            telemetry.flush()

    @app.post("/v1/chat/completions")
    async def openai_chat_completions(request: Request) -> Any:
        ctx = new_context(method="openai_chat", headers=request.headers)
        request_context.set(ctx)
        try:
            payload = await request.json()
            return await openai_handler.handle(payload, ctx)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="Invalid JSON format") from exc
        finally:
            telemetry.flush()

    @app.get("/health")
    async def health_check() -> dict[str, str]:
        return {"status": "ok", "message": "Service is running"}

    @app.get("/graph_parameter")
    async def http_graph_inout_parameter(request: Request) -> dict[str, Any]:
        del request
        return runtime_service.graph_inout_schema()

    @app.get("/agent/config")
    async def http_agent_config(request: Request) -> dict[str, Any]:
        del request
        return runtime_service.agent_config_info()

    @app.get("/run_records")
    async def http_run_records(
        request: Request,
        date: str | None = None,
        status: str = "all",
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        del request
        return list_run_records(date=date, status=status, limit=limit, offset=offset)

    @app.get("/run-records")
    async def http_run_records_alias(
        request: Request,
        date: str | None = None,
        status: str = "all",
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        return await http_run_records(request, date=date, status=status, limit=limit, offset=offset)

    @app.get("/run_records/{trace_id}")
    async def http_run_record_detail(trace_id: str, request: Request) -> dict[str, Any]:
        del request
        record = get_run_record(trace_id)
        if record is None:
            raise HTTPException(status_code=404, detail="run record not found")
        return record

    @app.get("/run-records/{trace_id}")
    async def http_run_record_detail_alias(trace_id: str, request: Request) -> dict[str, Any]:
        return await http_run_record_detail(trace_id, request)

    @app.delete("/run_records")
    async def http_run_records_clear(request: Request, date: str | None = None) -> dict[str, Any]:
        del request
        return clear_run_records(date=date)

    @app.delete("/run-records")
    async def http_run_records_clear_alias(request: Request, date: str | None = None) -> dict[str, Any]:
        return await http_run_records_clear(request, date=date)

    @app.get("/agent/canvas")
    async def http_agent_canvas_get(request: Request) -> dict[str, Any]:
        del request
        return runtime_service.agent_canvas()

    @app.post("/agent/canvas")
    async def http_agent_canvas_post(request: Request) -> dict[str, Any]:
        del request
        return runtime_service.agent_canvas()

    @app.post("/v1/api/project/{project_id}/agent/canvas")
    async def http_agent_canvas_coze(project_id: str, request: Request) -> dict[str, Any]:
        del project_id, request
        return runtime_service.agent_canvas()

    @app.post("/agent/canvas_submit")
    async def http_agent_canvas_submit(request: Request) -> dict[str, Any]:
        try:
            payload = await request.json()
            if not isinstance(payload, dict):
                raise ValueError("request body must be an object")
            return runtime_service.agent_canvas_submit(payload)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail="Invalid JSON format") from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/v1/api/project/{project_id}/agent/canvas_submit")
    async def http_agent_canvas_submit_coze(project_id: str, request: Request) -> dict[str, Any]:
        del project_id
        return await http_agent_canvas_submit(request)

    return app


app = create_app()
