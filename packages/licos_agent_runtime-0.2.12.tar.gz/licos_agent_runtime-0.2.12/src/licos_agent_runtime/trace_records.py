from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time
from typing import Any

from .context import Context

try:
    from langchain_core.callbacks import BaseCallbackHandler
except Exception:  # pragma: no cover - langchain_core is a runtime dependency
    BaseCallbackHandler = object  # type: ignore[misc,assignment]


TRACE_DIR_NAME = "run-records"
MAX_SERIALIZED_STRING = 16_384
MAX_SERIALIZED_ITEMS = 80
MAX_SERIALIZED_DEPTH = 8


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso_now() -> str:
    return _utc_now().isoformat().replace("+00:00", "Z")


def _epoch_ms() -> int:
    return int(time.time() * 1000)


def _local_date() -> str:
    return time.strftime("%Y-%m-%d", time.localtime())


def _workspace_root() -> Path:
    value = os.environ.get("LICOS_WORKSPACE_PATH")
    if value:
        return Path(value).resolve()
    project_path = os.environ.get("LICOS_PROJECT_PATH")
    if project_path:
        project = Path(project_path).resolve()
        return project.parent if project.name == "projects" else project
    return Path.cwd().resolve()


def trace_store_dir() -> Path:
    return _workspace_root() / ".licos" / TRACE_DIR_NAME


def _safe_id(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in value)[:128] or "trace"


def _serialize(value: Any, *, depth: int = 0) -> Any:
    if depth > MAX_SERIALIZED_DEPTH:
        return _short_repr(value)
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value if len(value) <= MAX_SERIALIZED_STRING else value[:MAX_SERIALIZED_STRING] + "...<truncated>"
    if isinstance(value, bytes):
        text = value.decode("utf-8", errors="replace")
        return text if len(text) <= MAX_SERIALIZED_STRING else text[:MAX_SERIALIZED_STRING] + "...<truncated>"

    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            return _serialize(model_dump(), depth=depth + 1)
        except Exception:
            pass

    to_json = getattr(value, "to_json", None)
    if callable(to_json):
        try:
            return _serialize(to_json(), depth=depth + 1)
        except Exception:
            pass

    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for index, (key, item) in enumerate(value.items()):
            if index >= MAX_SERIALIZED_ITEMS:
                result["..."] = f"{len(value) - MAX_SERIALIZED_ITEMS} more items"
                break
            result[str(key)] = _serialize(item, depth=depth + 1)
        return result

    if isinstance(value, (list, tuple, set)):
        items = list(value)
        result = [_serialize(item, depth=depth + 1) for item in items[:MAX_SERIALIZED_ITEMS]]
        if len(items) > MAX_SERIALIZED_ITEMS:
            result.append(f"... {len(items) - MAX_SERIALIZED_ITEMS} more items")
        return result

    return _short_repr(value)


def _short_repr(value: Any) -> str:
    text = repr(value)
    return text if len(text) <= MAX_SERIALIZED_STRING else text[:MAX_SERIALIZED_STRING] + "...<truncated>"


def _extract_token_usage(value: Any) -> dict[str, int] | None:
    candidates: list[Any] = [value]
    if hasattr(value, "llm_output"):
        candidates.append(getattr(value, "llm_output", None))
    if hasattr(value, "generations"):
        candidates.append(getattr(value, "generations", None))

    for candidate in candidates:
        usage = _find_usage(candidate)
        if usage:
            return usage
    return None


def _find_usage(value: Any) -> dict[str, int] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        raw = (
            value.get("token_usage")
            or value.get("usage")
            or value.get("usage_metadata")
            or value.get("token_cost")
        )
        if isinstance(raw, dict):
            return _normalize_usage(raw)
        for item in value.values():
            usage = _find_usage(item)
            if usage:
                return usage
        return None
    if isinstance(value, (list, tuple)):
        for item in value:
            usage = _find_usage(item)
            if usage:
                return usage
        return None
    raw = getattr(value, "usage_metadata", None) or getattr(value, "token_usage", None)
    if isinstance(raw, dict):
        return _normalize_usage(raw)
    for attr in ("message", "generation_info", "llm_output"):
        nested = getattr(value, attr, None)
        if nested is None:
            continue
        usage = _find_usage(nested)
        if usage:
            return usage
    return None


def _normalize_usage(raw: dict[str, Any]) -> dict[str, int]:
    input_tokens = _int_value(raw, "input_tokens", "prompt_tokens")
    output_tokens = _int_value(raw, "output_tokens", "completion_tokens")
    total_tokens = _int_value(raw, "total_tokens", "total")
    if total_tokens == 0:
        total_tokens = input_tokens + output_tokens
    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": total_tokens,
    }


def _int_value(raw: dict[str, Any], *keys: str) -> int:
    for key in keys:
        value = raw.get(key)
        if isinstance(value, bool):
            continue
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            return int(value)
        if isinstance(value, str) and value.isdigit():
            return int(value)
    return 0


def _node_name(serialized: Any, explicit_name: str | None, metadata: Any) -> str:
    if explicit_name:
        return str(explicit_name)
    if isinstance(metadata, dict):
        node = metadata.get("langgraph_node") or metadata.get("name") or metadata.get("title")
        if node:
            return str(node)
    if isinstance(serialized, dict):
        name = serialized.get("name")
        if name:
            return str(name)
        identifier = serialized.get("id")
        if isinstance(identifier, list) and identifier:
            return str(identifier[-1])
        if identifier:
            return str(identifier)
    return "run"


def _status_filter_matches(status: str, selected: str) -> bool:
    selected = selected.lower()
    if selected in {"", "all"}:
        return True
    if selected in {"success", "succeeded", "ok"}:
        return status == "success"
    if selected in {"error", "failed", "failure", "exception"}:
        return status == "error"
    return status == selected


@dataclass
class TraceNode:
    id: str
    name: str
    type: str
    parent_id: str | None = None
    status: str = "running"
    input: Any = None
    output: Any = None
    error: str | None = None
    started_at: str = field(default_factory=_iso_now)
    finished_at: str | None = None
    duration_ms: int = 0
    token_usage: dict[str, int] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    children: list[str] = field(default_factory=list)
    _started_perf: float = field(default_factory=time.perf_counter, repr=False)

    def finish(self, *, status: str, output: Any = None, error: str | None = None, token_usage: dict[str, int] | None = None) -> None:
        self.status = status
        self.output = _serialize(output)
        self.error = error
        self.finished_at = _iso_now()
        self.duration_ms = max(0, int((time.perf_counter() - self._started_perf) * 1000))
        if token_usage:
            self.token_usage = token_usage

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "parent_id": self.parent_id,
            "status": self.status,
            "input": self.input,
            "output": self.output,
            "error": self.error,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration_ms": self.duration_ms,
            "token_usage": self.token_usage,
            "metadata": self.metadata,
            "children": self.children,
        }


class RunTraceRecorder:
    def __init__(self, ctx: Context, *, project_kind: str) -> None:
        self.trace_id = ctx.run_id
        self.project_kind = project_kind
        self.started_at = _iso_now()
        self.date = _local_date()
        self.started_ms = _epoch_ms()
        self.status = "running"
        self.error: str | None = None
        self.nodes: dict[str, TraceNode] = {}
        self.node_order: list[str] = []
        self.root_node_id: str | None = None
        self._root_input: Any = None
        self._root_output: Any = None

    def callback_handler(self) -> BaseCallbackHandler:
        return _TraceCallbackHandler(self)

    def set_root_input(self, payload: Any) -> None:
        self._root_input = _serialize(payload)

    def set_root_output(self, output: Any) -> None:
        self._root_output = _serialize(output)

    def start_node(
        self,
        *,
        run_id: Any,
        parent_run_id: Any,
        name: str,
        node_type: str,
        input_value: Any,
        metadata: Any = None,
    ) -> None:
        node_id = str(run_id)
        parent_id = str(parent_run_id) if parent_run_id else None
        if node_id in self.nodes:
            return
        node = TraceNode(
            id=node_id,
            name=name,
            type=node_type,
            parent_id=parent_id,
            input=_serialize(input_value),
            metadata=_serialize(metadata) if isinstance(metadata, dict) else {},
        )
        self.nodes[node_id] = node
        self.node_order.append(node_id)
        if parent_id and parent_id in self.nodes:
            self.nodes[parent_id].children.append(node_id)
        elif self.root_node_id is None:
            self.root_node_id = node_id

    def end_node(self, *, run_id: Any, output: Any, token_usage: dict[str, int] | None = None) -> None:
        node = self.nodes.get(str(run_id))
        if node is None:
            return
        node.finish(status="success", output=output, token_usage=token_usage)

    def error_node(self, *, run_id: Any, error: BaseException | str) -> None:
        node = self.nodes.get(str(run_id))
        if node is None:
            return
        node.finish(status="error", error=str(error), output=None)
        self.status = "error"
        self.error = str(error)

    def finish(self, *, status: str = "success", output: Any = None, error: BaseException | str | None = None) -> dict[str, Any]:
        self.status = "error" if error is not None or status == "error" else status
        self.error = str(error) if error is not None else self.error
        if output is not None:
            self.set_root_output(output)
        self._ensure_root()
        for node in self.nodes.values():
            if node.status == "running":
                node.finish(status="success", output=node.output)
        return self.to_record()

    def _ensure_root(self) -> None:
        if self.root_node_id and self.root_node_id in self.nodes:
            root = self.nodes[self.root_node_id]
            if root.input is None:
                root.input = self._root_input
            if root.output is None and self._root_output is not None:
                root.output = self._root_output
            if self.error and root.status != "error":
                root.finish(status="error", output=root.output, error=self.error)
            return

        root_id = f"{self.trace_id}:root"
        node = TraceNode(
            id=root_id,
            name="LangGraph" if self.project_kind == "agent" else "Workflow",
            type="graph",
            input=self._root_input,
        )
        node.finish(
            status="error" if self.error else "success",
            output=self._root_output,
            error=self.error,
        )
        self.nodes[root_id] = node
        self.node_order.insert(0, root_id)
        self.root_node_id = root_id

    def to_record(self) -> dict[str, Any]:
        finished_at = _iso_now()
        total_tokens = self._total_tokens()
        nodes = [self.nodes[node_id].to_dict() for node_id in self.node_order if node_id in self.nodes]
        return {
            "trace_id": self.trace_id,
            "project_kind": self.project_kind,
            "status": self.status,
            "date": self.date,
            "started_at": self.started_at,
            "finished_at": finished_at,
            "duration_ms": max(0, _epoch_ms() - self.started_ms),
            "total_tokens": total_tokens,
            "root_node_id": self.root_node_id,
            "nodes": nodes,
            "tree": build_tree(nodes),
            "error": self.error,
        }

    def save(self) -> dict[str, Any]:
        record = self.to_record()
        day = str(record.get("date") or record["started_at"])[:10]
        directory = trace_store_dir() / day
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / f"{_safe_id(self.trace_id)}.json"
        target.write_text(json.dumps(record, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        return record

    def _total_tokens(self) -> int:
        total = 0
        for node in self.nodes.values():
            usage = node.token_usage
            if usage:
                total += int(usage.get("total_tokens") or 0)
        return total


class _TraceCallbackHandler(BaseCallbackHandler):  # type: ignore[misc]
    ignore_retry = True

    def __init__(self, recorder: RunTraceRecorder) -> None:
        self.recorder = recorder

    def on_chain_start(self, serialized: Any, inputs: Any, *, run_id: Any, parent_run_id: Any = None, tags: Any = None, metadata: Any = None, name: str | None = None, **kwargs: Any) -> None:
        del tags, kwargs
        self.recorder.start_node(
            run_id=run_id,
            parent_run_id=parent_run_id,
            name=_node_name(serialized, name, metadata),
            node_type="graph" if parent_run_id is None else "chain",
            input_value=inputs,
            metadata=metadata,
        )

    def on_chain_end(self, outputs: Any, *, run_id: Any, **kwargs: Any) -> None:
        del kwargs
        self.recorder.end_node(run_id=run_id, output=outputs)

    def on_chain_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> None:
        del kwargs
        self.recorder.error_node(run_id=run_id, error=error)

    def on_chat_model_start(self, serialized: Any, messages: Any, *, run_id: Any, parent_run_id: Any = None, tags: Any = None, metadata: Any = None, name: str | None = None, **kwargs: Any) -> None:
        del tags, kwargs
        self.recorder.start_node(
            run_id=run_id,
            parent_run_id=parent_run_id,
            name=_node_name(serialized, name, metadata) or "ChatModel",
            node_type="llm",
            input_value={"messages": messages},
            metadata=metadata,
        )

    def on_llm_start(self, serialized: Any, prompts: Any, *, run_id: Any, parent_run_id: Any = None, tags: Any = None, metadata: Any = None, name: str | None = None, **kwargs: Any) -> None:
        del tags, kwargs
        self.recorder.start_node(
            run_id=run_id,
            parent_run_id=parent_run_id,
            name=_node_name(serialized, name, metadata) or "LLM",
            node_type="llm",
            input_value={"prompts": prompts},
            metadata=metadata,
        )

    def on_llm_end(self, response: Any, *, run_id: Any, **kwargs: Any) -> None:
        del kwargs
        self.recorder.end_node(run_id=run_id, output=response, token_usage=_extract_token_usage(response))

    def on_llm_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> None:
        del kwargs
        self.recorder.error_node(run_id=run_id, error=error)

    def on_tool_start(self, serialized: Any, input_str: str, *, run_id: Any, parent_run_id: Any = None, tags: Any = None, metadata: Any = None, name: str | None = None, **kwargs: Any) -> None:
        del tags, kwargs
        self.recorder.start_node(
            run_id=run_id,
            parent_run_id=parent_run_id,
            name=_node_name(serialized, name, metadata),
            node_type="tool",
            input_value=input_str,
            metadata=metadata,
        )

    def on_tool_end(self, output: Any, *, run_id: Any, **kwargs: Any) -> None:
        del kwargs
        self.recorder.end_node(run_id=run_id, output=output)

    def on_tool_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> None:
        del kwargs
        self.recorder.error_node(run_id=run_id, error=error)


def append_trace_callback(run_config: dict[str, Any], recorder: RunTraceRecorder) -> dict[str, Any]:
    updated = dict(run_config)
    callbacks = list(updated.get("callbacks") or [])
    callbacks.append(recorder.callback_handler())
    updated["callbacks"] = callbacks
    return updated


def save_record(recorder: RunTraceRecorder, *, status: str = "success", output: Any = None, error: BaseException | str | None = None) -> dict[str, Any]:
    recorder.finish(status=status, output=output, error=error)
    return recorder.save()


def list_run_records(
    *,
    date: str | None = None,
    status: str = "all",
    limit: int = 50,
    offset: int = 0,
) -> dict[str, Any]:
    base = trace_store_dir()
    if not base.exists():
        return {"records": [], "total": 0, "limit": limit, "offset": offset}

    days = [date] if date else sorted((item.name for item in base.iterdir() if item.is_dir()), reverse=True)
    records: list[dict[str, Any]] = []
    for day in days:
        if not day:
            continue
        directory = base / day
        if not directory.exists():
            continue
        for path in directory.glob("*.json"):
            summary = _read_summary(path)
            if not summary:
                continue
            if not _status_filter_matches(str(summary.get("status") or ""), status):
                continue
            records.append(summary)

    records.sort(key=lambda item: str(item.get("started_at") or ""), reverse=True)
    total = len(records)
    safe_offset = max(0, offset)
    safe_limit = max(1, min(limit, 200))
    return {
        "records": records[safe_offset : safe_offset + safe_limit],
        "total": total,
        "limit": safe_limit,
        "offset": safe_offset,
    }


def get_run_record(trace_id: str) -> dict[str, Any] | None:
    safe = _safe_id(trace_id)
    base = trace_store_dir()
    if not base.exists():
        return None
    for path in base.glob(f"*/{safe}.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        return data if isinstance(data, dict) else None
    return None


def clear_run_records(*, date: str | None = None) -> dict[str, Any]:
    base = trace_store_dir()
    if not base.exists():
        return {"deleted": 0}
    targets = [base / date] if date else [item for item in base.iterdir() if item.is_dir()]
    deleted = 0
    for directory in targets:
        if not directory.exists():
            continue
        for path in directory.glob("*.json"):
            try:
                path.unlink()
                deleted += 1
            except OSError:
                pass
    return {"deleted": deleted}


def build_tree(nodes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_id = {str(node.get("id")): dict(node, children=[]) for node in nodes}
    roots: list[dict[str, Any]] = []
    for node in by_id.values():
        parent_id = node.get("parent_id")
        if parent_id and str(parent_id) in by_id:
            by_id[str(parent_id)]["children"].append(node)
        else:
            roots.append(node)
    return roots


def _read_summary(path: Path) -> dict[str, Any] | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    nodes = data.get("nodes")
    node_count = len(nodes) if isinstance(nodes, list) else 0
    return {
        "trace_id": data.get("trace_id"),
        "project_kind": data.get("project_kind"),
        "status": data.get("status"),
        "date": data.get("date") or str(data.get("started_at") or "")[:10],
        "started_at": data.get("started_at"),
        "finished_at": data.get("finished_at"),
        "duration_ms": data.get("duration_ms"),
        "total_tokens": data.get("total_tokens") or 0,
        "root_node_id": data.get("root_node_id"),
        "tree": _compact_tree(data.get("tree") or []),
        "node_count": node_count,
        "error": data.get("error"),
    }


def _compact_tree(nodes: Any) -> list[dict[str, Any]]:
    if not isinstance(nodes, list):
        return []
    result: list[dict[str, Any]] = []
    for node in nodes:
        if not isinstance(node, dict):
            continue
        result.append(
            {
                "id": node.get("id"),
                "name": node.get("name"),
                "type": node.get("type"),
                "status": node.get("status"),
                "duration_ms": node.get("duration_ms"),
                "token_usage": node.get("token_usage"),
                "error": node.get("error"),
                "children": _compact_tree(node.get("children") or []),
            }
        )
    return result
