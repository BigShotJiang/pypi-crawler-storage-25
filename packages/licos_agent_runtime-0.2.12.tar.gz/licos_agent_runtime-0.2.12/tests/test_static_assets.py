import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

from licos_agent_runtime.app import create_app
from licos_agent_runtime.service import GraphService


class StaticAssetsTests(unittest.TestCase):
    def test_serves_project_assets_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            assets_dir = root / "assets"
            assets_dir.mkdir()
            (assets_dir / "sample.txt").write_text("hello assets", encoding="utf-8")

            with patch.dict(os.environ, {"LICOS_PROJECT_PATH": str(root)}):
                client = TestClient(create_app(GraphService()))

            response = client.get("/assets/sample.txt")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.text, "hello assets")

