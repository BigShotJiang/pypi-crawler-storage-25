import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from licos_agent_runtime.context import new_context
from licos_agent_runtime.trace_records import (
    RunTraceRecorder,
    clear_run_records,
    get_run_record,
    list_run_records,
    save_record,
)


class TraceRecordTests(unittest.TestCase):
    def test_records_langgraph_tree_and_token_usage(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.dict("os.environ", {"LICOS_WORKSPACE_PATH": tmp}, clear=True):
                ctx = new_context("stream_run", {"X-Run-Id": "trace-1"})
                recorder = RunTraceRecorder(ctx, project_kind="agent")
                recorder.set_root_input({"messages": [{"role": "user", "content": "hello"}]})
                handler = recorder.callback_handler()

                handler.on_chain_start({}, {"messages": []}, run_id="root", name="LangGraph")
                handler.on_chat_model_start({}, [["hello"]], run_id="llm", parent_run_id="root", name="ChatOpenAI")

                class Response:
                    llm_output = {
                        "token_usage": {
                            "prompt_tokens": 10,
                            "completion_tokens": 5,
                            "total_tokens": 15,
                        }
                    }

                handler.on_llm_end(Response(), run_id="llm")
                handler.on_chain_end({"messages": [{"role": "assistant", "content": "hi"}]}, run_id="root")
                save_record(recorder, output={"answer": "hi"})

                listed = list_run_records(status="success")
                self.assertEqual(listed["total"], 1)
                summary = listed["records"][0]
                self.assertEqual(summary["trace_id"], "trace-1")
                self.assertEqual(summary["total_tokens"], 15)
                self.assertEqual(summary["tree"][0]["name"], "LangGraph")
                self.assertEqual(summary["tree"][0]["children"][0]["name"], "ChatOpenAI")

                detail = get_run_record("trace-1")
                assert detail is not None
                self.assertEqual(len(detail["nodes"]), 2)
                self.assertEqual(detail["nodes"][1]["token_usage"]["total_tokens"], 15)

                self.assertEqual(clear_run_records()["deleted"], 1)
                self.assertEqual(list((Path(tmp) / ".licos" / "run-records").glob("*/*.json")), [])


if __name__ == "__main__":
    unittest.main()
