# Copyright (C) 2015 Forest and Biomass Romania
# Copyright (C) 2020 NextERP Romania
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

{
    "name": "Partner Data VIES Populator",
    "summary": "Populate Partner name and address using the VIES webservice",
    "version": "17.0.1.0.0",
    "category": "Customer Relationship Management",
    "author": "NextERP Romania,"
    "Forest and Biomass Romania,"
    "Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/partner-contact",
    "license": "AGPL-3",
    "depends": ["base_vat"],
    "external_dependencies": {"python": ["python-stdnum"]},
    "installable": True,
}
