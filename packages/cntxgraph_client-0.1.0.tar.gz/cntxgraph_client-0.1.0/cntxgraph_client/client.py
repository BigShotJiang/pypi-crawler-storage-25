from cntxgraph_client._transport import SyncTransport, AsyncTransport
from cntxgraph_client.resources.think import ThinkResource, AsyncThinkResource
from cntxgraph_client.resources.queue import QueueResource, AsyncQueueResource
from cntxgraph_client.resources.plans import PlansResource, AsyncPlansResource
from cntxgraph_client.resources.nodes import NodesResource, AsyncNodesResource
from cntxgraph_client.resources.stack_traces import StackTracesResource, AsyncStackTracesResource


class CntxgraphClient:
    def __init__(self, url: str, timeout: float = 30.0) -> None:
        self._transport = SyncTransport(url, timeout)
        self.think = ThinkResource(self._transport)
        self.queue = QueueResource(self._transport)
        self.plans = PlansResource(self._transport)
        self.nodes = NodesResource(self._transport)
        self.stack_traces = StackTracesResource(self._transport)

    def __enter__(self) -> "CntxgraphClient":
        self._transport.__enter__()
        return self

    def __exit__(self, *args: object) -> None:
        self._transport.__exit__(*args)


class AsyncCntxgraphClient:
    def __init__(self, url: str, timeout: float = 30.0) -> None:
        self._transport = AsyncTransport(url, timeout)
        self.think = AsyncThinkResource(self._transport)
        self.queue = AsyncQueueResource(self._transport)
        self.plans = AsyncPlansResource(self._transport)
        self.nodes = AsyncNodesResource(self._transport)
        self.stack_traces = AsyncStackTracesResource(self._transport)

    async def __aenter__(self) -> "AsyncCntxgraphClient":
        await self._transport.__aenter__()
        return self

    async def __aexit__(self, *args: object) -> None:
        await self._transport.__aexit__(*args)
