class CntxgraphError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status_code: int | None,
        request_method: str,
        request_url: str,
        raw_body: str,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.request_method = request_method
        self.request_url = request_url
        self.raw_body = raw_body


class CntxgraphNotFoundError(CntxgraphError): ...
class CntxgraphValidationError(CntxgraphError): ...
class CntxgraphServerError(CntxgraphError): ...
class CntxgraphConnectionError(CntxgraphError): ...
