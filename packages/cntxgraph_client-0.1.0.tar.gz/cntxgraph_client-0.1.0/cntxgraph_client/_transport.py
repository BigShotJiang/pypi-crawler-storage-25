from typing import Any, Never
import httpx
from cntxgraph_client._errors import (
    CntxgraphNotFoundError,
    CntxgraphValidationError,
    CntxgraphServerError,
    CntxgraphConnectionError,
)


def _map_error(resp: httpx.Response) -> Never:
    kwargs = dict(
        status_code=resp.status_code,
        request_method=resp.request.method,
        request_url=str(resp.request.url),
        raw_body=resp.text,
    )
    if resp.status_code == 404:
        raise CntxgraphNotFoundError(f"Not found: {resp.request.url}", **kwargs)
    if resp.status_code == 422:
        raise CntxgraphValidationError(f"Validation error: {resp.text}", **kwargs)
    raise CntxgraphServerError(f"Server error {resp.status_code}: {resp.text}", **kwargs)


class SyncTransport:
    def __init__(self, base_url: str, timeout: float = 30.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client: httpx.Client | None = None

    def __enter__(self) -> "SyncTransport":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def request(self, method: str, path: str, **kwargs: Any) -> Any:
        if self._client is None:
            self._client = httpx.Client(timeout=self._timeout)
        url = f"{self._base_url}{path}"
        try:
            resp = self._client.request(method, url, **kwargs)
        except httpx.ConnectError as exc:
            raise CntxgraphConnectionError(
                str(exc),
                status_code=None,
                request_method=method.upper(),
                request_url=url,
                raw_body="",
            ) from exc
        if not resp.is_success:
            _map_error(resp)
        return resp.json()


class AsyncTransport:
    def __init__(self, base_url: str, timeout: float = 30.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "AsyncTransport":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def request(self, method: str, path: str, **kwargs: Any) -> Any:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self._timeout)
        url = f"{self._base_url}{path}"
        try:
            resp = await self._client.request(method, url, **kwargs)
        except httpx.ConnectError as exc:
            raise CntxgraphConnectionError(
                str(exc),
                status_code=None,
                request_method=method.upper(),
                request_url=url,
                raw_body="",
            ) from exc
        if not resp.is_success:
            _map_error(resp)
        return resp.json()
