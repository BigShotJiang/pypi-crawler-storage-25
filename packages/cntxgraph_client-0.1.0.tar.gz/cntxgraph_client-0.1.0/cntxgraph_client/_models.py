from datetime import datetime
from typing import Any, TypedDict
from pydantic import BaseModel, Field, ConfigDict


class Process(TypedDict):
    name: str
    description: str


class Skill(BaseModel):
    skill_id: str
    name: str
    content: str


class StackTraceEntry(BaseModel):
    depth: int
    node: str
    decision: str
    rationale: str
    skills: list[str] = []


class ThinkResult(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    stack_trace_id: str
    node_path: list[str]
    skills_activated: list[Skill]
    entries: list[StackTraceEntry] = Field(alias="stack_trace")


class StackTrace(BaseModel):
    stack_trace_id: str
    entries: list[StackTraceEntry]
    node_path: list[str]
    skills_activated: list[Skill]


class Submission(BaseModel):
    submission_id: str
    status: str


class QueueStatus(BaseModel):
    pending_count: int
    oldest_pending_age_hours: float | None = None


class PlanOperation(BaseModel):
    model_config = ConfigDict(extra="allow")
    op: str


class Plan(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str = Field(alias="_key")
    status: str
    batch_submission_ids: list[str]
    operations: list[PlanOperation]
    created_at: datetime
    updated_at: datetime


class Node(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str = Field(alias="_key")
    name: str
    type: str
    description: str | None = None
    payload: dict[str, Any] = {}
    children: list["Node"] = []
