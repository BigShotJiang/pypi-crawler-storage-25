from typing import Any
from cntxgraph_client._models import Plan


class PlansResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    def list(self, status: str | None = None) -> list[Plan]:
        kwargs: dict = {}
        if status is not None:
            kwargs["params"] = {"status": status}
        data = self._t.request("GET", "/plans", **kwargs)
        return [Plan(**p) for p in data]

    def get(self, plan_id: str) -> Plan:
        data = self._t.request("GET", f"/plans/{plan_id}")
        return Plan(**data)

    def pending(self) -> Plan:
        data = self._t.request("GET", "/plans/pending")
        return Plan(**data)

    def approve(self, plan_id: str) -> Plan:
        data = self._t.request("POST", f"/plans/{plan_id}/approve")
        return Plan(**data)

    def defer(self, plan_id: str) -> None:
        self._t.request("POST", f"/plans/{plan_id}/defer")

    def defer_submission(self, plan_id: str, submission_id: str) -> Plan:
        data = self._t.request("POST", f"/plans/{plan_id}/submissions/{submission_id}/defer")
        return Plan(**data)

    def rollback(self, plan_id: str) -> Plan:
        data = self._t.request("POST", f"/plans/{plan_id}/rollback")
        return Plan(**data)

    def delete(self, plan_id: str) -> None:
        self._t.request("DELETE", f"/plans/{plan_id}")


class AsyncPlansResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    async def list(self, status: str | None = None) -> list[Plan]:
        kwargs: dict = {}
        if status is not None:
            kwargs["params"] = {"status": status}
        data = await self._t.request("GET", "/plans", **kwargs)
        return [Plan(**p) for p in data]

    async def get(self, plan_id: str) -> Plan:
        data = await self._t.request("GET", f"/plans/{plan_id}")
        return Plan(**data)

    async def pending(self) -> Plan:
        data = await self._t.request("GET", "/plans/pending")
        return Plan(**data)

    async def approve(self, plan_id: str) -> Plan:
        data = await self._t.request("POST", f"/plans/{plan_id}/approve")
        return Plan(**data)

    async def defer(self, plan_id: str) -> None:
        await self._t.request("POST", f"/plans/{plan_id}/defer")

    async def defer_submission(self, plan_id: str, submission_id: str) -> Plan:
        data = await self._t.request("POST", f"/plans/{plan_id}/submissions/{submission_id}/defer")
        return Plan(**data)

    async def rollback(self, plan_id: str) -> Plan:
        data = await self._t.request("POST", f"/plans/{plan_id}/rollback")
        return Plan(**data)

    async def delete(self, plan_id: str) -> None:
        await self._t.request("DELETE", f"/plans/{plan_id}")
