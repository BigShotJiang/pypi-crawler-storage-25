from typing import Any
from cntxgraph_client._models import StackTrace, StackTraceEntry


class StackTracesResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    def get(self, stack_trace_id: str) -> StackTrace:
        data = self._t.request("GET", f"/stack-traces/{stack_trace_id}")
        return StackTrace(**data)

    def append_entry(self, stack_trace_id: str, entry: StackTraceEntry) -> StackTrace:
        data = self._t.request("PATCH", f"/stack-traces/{stack_trace_id}", json=entry.model_dump())
        return StackTrace(**data)


class AsyncStackTracesResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    async def get(self, stack_trace_id: str) -> StackTrace:
        data = await self._t.request("GET", f"/stack-traces/{stack_trace_id}")
        return StackTrace(**data)

    async def append_entry(self, stack_trace_id: str, entry: StackTraceEntry) -> StackTrace:
        data = await self._t.request("PATCH", f"/stack-traces/{stack_trace_id}", json=entry.model_dump())
        return StackTrace(**data)
