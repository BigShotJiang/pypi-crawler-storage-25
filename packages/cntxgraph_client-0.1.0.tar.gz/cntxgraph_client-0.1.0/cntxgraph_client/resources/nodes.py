from typing import Any
from cntxgraph_client._models import Node


class NodesResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    def get(self, node_id: str, include: list[str] | None = None) -> Node:
        kwargs: dict = {}
        if include:
            kwargs["params"] = {"include": ",".join(include)}
        data = self._t.request("GET", f"/nodes/{node_id}", **kwargs)
        return Node(**data)

    def subtree(self, node_id: str = "root", depth: int | None = None) -> Node:
        kwargs: dict = {}
        if depth is not None:
            kwargs["params"] = {"depth": depth}
        data = self._t.request("GET", f"/nodes/{node_id}/subtree", **kwargs)
        return Node(**data)

    def children(self, node_id: str) -> list[Node]:
        data = self._t.request("GET", f"/nodes/{node_id}/children")
        return [Node(**n) for n in data]


class AsyncNodesResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    async def get(self, node_id: str, include: list[str] | None = None) -> Node:
        kwargs: dict = {}
        if include:
            kwargs["params"] = {"include": ",".join(include)}
        data = await self._t.request("GET", f"/nodes/{node_id}", **kwargs)
        return Node(**data)

    async def subtree(self, node_id: str = "root", depth: int | None = None) -> Node:
        kwargs: dict = {}
        if depth is not None:
            kwargs["params"] = {"depth": depth}
        data = await self._t.request("GET", f"/nodes/{node_id}/subtree", **kwargs)
        return Node(**data)

    async def children(self, node_id: str) -> list[Node]:
        data = await self._t.request("GET", f"/nodes/{node_id}/children")
        return [Node(**n) for n in data]
