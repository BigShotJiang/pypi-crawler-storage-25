from typing import Any
from cntxgraph_client._models import ThinkResult


class ThinkResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    def query(self, prompt: str) -> ThinkResult:
        data = self._t.request("POST", "/think", json={"prompt": prompt})
        return ThinkResult(**data)


class AsyncThinkResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    async def query(self, prompt: str) -> ThinkResult:
        data = await self._t.request("POST", "/think", json={"prompt": prompt})
        return ThinkResult(**data)
