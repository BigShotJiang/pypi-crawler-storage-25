from typing import Any
from cntxgraph_client._models import Submission, QueueStatus, Process


class QueueResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    def submit(
        self,
        summary: str,
        processes: list[Process],
        raw_transcript: str | None = None,
        stack_trace_id: str | None = None,
        agent_id: str | None = None,
    ) -> Submission:
        body: dict = {"summary": summary, "processes": processes}
        if raw_transcript is not None:
            body["raw_transcript"] = raw_transcript
        if stack_trace_id is not None:
            body["stack_trace_id"] = stack_trace_id
        if agent_id is not None:
            body["agent_id"] = agent_id
        data = self._t.request("POST", "/queue/submissions", json=body)
        return Submission(**data)

    def status(self) -> QueueStatus:
        data = self._t.request("GET", "/queue/status")
        return QueueStatus(**data)

    def flush(self) -> None:
        self._t.request("POST", "/queue/flush")


class AsyncQueueResource:
    def __init__(self, transport: Any) -> None:
        self._t = transport

    async def submit(
        self,
        summary: str,
        processes: list[Process],
        raw_transcript: str | None = None,
        stack_trace_id: str | None = None,
        agent_id: str | None = None,
    ) -> Submission:
        body: dict = {"summary": summary, "processes": processes}
        if raw_transcript is not None:
            body["raw_transcript"] = raw_transcript
        if stack_trace_id is not None:
            body["stack_trace_id"] = stack_trace_id
        if agent_id is not None:
            body["agent_id"] = agent_id
        data = await self._t.request("POST", "/queue/submissions", json=body)
        return Submission(**data)

    async def status(self) -> QueueStatus:
        data = await self._t.request("GET", "/queue/status")
        return QueueStatus(**data)

    async def flush(self) -> None:
        await self._t.request("POST", "/queue/flush")
