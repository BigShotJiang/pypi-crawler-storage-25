from datetime import datetime
from cntxgraph_client._models import (
    Skill, StackTraceEntry, ThinkResult, StackTrace,
    QueueStatus, PlanOperation, Plan, Node,
)
from tests.conftest import MockTransport


def test_plan_uses_key_alias():
    plan = Plan(**{
        "_key": "plan-abc",
        "status": "pending_review",
        "batch_submission_ids": ["sub-1"],
        "operations": [{"op": "create_node"}],
        "created_at": "2026-04-04T10:00:00Z",
        "updated_at": "2026-04-04T10:00:00Z",
    })
    assert plan.id == "plan-abc"
    assert plan.status == "pending_review"
    assert isinstance(plan.created_at, datetime)


def test_node_uses_key_alias():
    node = Node(**{"_key": "sales", "name": "Sales", "type": "domain"})
    assert node.id == "sales"


def test_node_defaults():
    node = Node(**{"_key": "x", "name": "X", "type": "domain"})
    assert node.description is None
    assert node.payload == {}
    assert node.children == []


def test_node_with_children():
    data = {
        "_key": "root",
        "name": "root",
        "type": "domain",
        "children": [{"_key": "sales", "name": "Sales", "type": "domain"}],
    }
    node = Node(**data)
    assert len(node.children) == 1
    assert node.children[0].id == "sales"


def test_queue_status_null_age():
    qs = QueueStatus(pending_count=0, oldest_pending_age_hours=None)
    assert qs.oldest_pending_age_hours is None


def test_think_result_parses_nested():
    result = ThinkResult(**{
        "stack_trace_id": "trace-1",
        "node_path": ["Sales"],
        "skills_activated": [{"skill_id": "s1", "name": "Script", "content": "Steps..."}],
        "stack_trace": [{"depth": 0, "node": "root", "decision": "descend", "rationale": "match"}],
    })
    assert result.stack_trace_id == "trace-1"
    assert isinstance(result.skills_activated[0], Skill)
    assert isinstance(result.entries[0], StackTraceEntry)


def test_stack_trace_entry_default_skills():
    entry = StackTraceEntry(depth=0, node="root", decision="descend", rationale="match")
    assert entry.skills == []


def test_plan_operation_allows_extra_fields():
    op = PlanOperation(**{"op": "create_node", "parent_path": ["Sales"], "name": "SMB"})
    assert op.op == "create_node"


def test_stack_trace_parses_correctly():
    trace = StackTrace(**{
        "stack_trace_id": "trace-1",
        "entries": [{"depth": 0, "node": "root", "decision": "descend", "rationale": "match"}],
        "node_path": ["Sales"],
        "skills_activated": [],
    })
    assert trace.stack_trace_id == "trace-1"
    assert len(trace.entries) == 1
    assert isinstance(trace.entries[0], StackTraceEntry)
    assert trace.node_path == ["Sales"]


def test_mock_transport_records_calls():
    t = MockTransport()
    t.add("POST", "/think", {"stack_trace_id": "t1"})
    result = t.request("POST", "/think", json={"prompt": "hello"})
    assert result == {"stack_trace_id": "t1"}
    assert t.calls == [("POST", "/think", {"json": {"prompt": "hello"}})]
