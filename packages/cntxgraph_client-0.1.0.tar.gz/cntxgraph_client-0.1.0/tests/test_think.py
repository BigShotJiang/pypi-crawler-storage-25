from cntxgraph_client.resources.think import ThinkResource, AsyncThinkResource
from cntxgraph_client._models import ThinkResult, Skill, StackTraceEntry

THINK_RESPONSE = {
    "stack_trace_id": "trace-123",
    "node_path": ["Sales", "Enterprise"],
    "skills_activated": [
        {"skill_id": "skill-abc", "name": "Renewal Script", "content": "Use these steps..."}
    ],
    "stack_trace": [
        {"depth": 0, "node": "root", "decision": "descend", "rationale": "Best match: Sales", "skills": []},
        {"depth": 1, "node": "Sales", "decision": "descend", "rationale": "Best match: Enterprise", "skills": []},
        {"depth": 2, "node": "Enterprise", "decision": "activate", "rationale": "Leaf node", "skills": ["skill-abc"]},
    ],
}


def test_query_returns_think_result(mock_transport):
    mock_transport.add("POST", "/think", THINK_RESPONSE)
    resource = ThinkResource(mock_transport)
    result = resource.query("how do we handle NDA renewals?")
    assert isinstance(result, ThinkResult)
    assert result.stack_trace_id == "trace-123"
    assert result.node_path == ["Sales", "Enterprise"]
    assert len(result.skills_activated) == 1
    assert isinstance(result.skills_activated[0], Skill)
    assert result.skills_activated[0].name == "Renewal Script"
    assert len(result.entries) == 3
    assert isinstance(result.entries[0], StackTraceEntry)


def test_query_sends_correct_request(mock_transport):
    mock_transport.add("POST", "/think", THINK_RESPONSE)
    resource = ThinkResource(mock_transport)
    resource.query("how do we handle NDA renewals?")
    method, path, kwargs = mock_transport.calls[0]
    assert method == "POST"
    assert path == "/think"
    assert kwargs["json"] == {"prompt": "how do we handle NDA renewals?"}


def test_query_empty_results(mock_transport):
    mock_transport.add("POST", "/think", {
        "stack_trace_id": "trace-empty",
        "node_path": [],
        "skills_activated": [],
        "stack_trace": [{"depth": 0, "node": "root", "decision": "activate", "rationale": "No children"}],
    })
    resource = ThinkResource(mock_transport)
    result = resource.query("anything")
    assert result.node_path == []
    assert result.skills_activated == []


async def test_async_query_returns_think_result(async_mock_transport):
    async_mock_transport.add("POST", "/think", THINK_RESPONSE)
    resource = AsyncThinkResource(async_mock_transport)
    result = await resource.query("how do we handle NDA renewals?")
    assert isinstance(result, ThinkResult)
    assert result.stack_trace_id == "trace-123"


async def test_async_query_sends_correct_request(async_mock_transport):
    async_mock_transport.add("POST", "/think", THINK_RESPONSE)
    resource = AsyncThinkResource(async_mock_transport)
    await resource.query("test prompt")
    method, path, kwargs = async_mock_transport.calls[0]
    assert method == "POST"
    assert path == "/think"
    assert kwargs["json"] == {"prompt": "test prompt"}
