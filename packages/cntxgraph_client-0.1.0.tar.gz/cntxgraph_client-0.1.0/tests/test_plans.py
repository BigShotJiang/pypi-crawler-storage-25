from cntxgraph_client.resources.plans import PlansResource, AsyncPlansResource
from cntxgraph_client._models import Plan

_PLAN = {
    "_key": "plan-123",
    "status": "pending_review",
    "batch_submission_ids": ["sub-1", "sub-2"],
    "operations": [{"op": "create_node", "parent_path": ["Sales"], "name": "SMB"}],
    "created_at": "2026-04-04T10:00:00Z",
    "updated_at": "2026-04-04T10:00:00Z",
}


def test_list_returns_plans(mock_transport):
    mock_transport.add("GET", "/plans", [_PLAN])
    resource = PlansResource(mock_transport)
    result = resource.list()
    assert len(result) == 1
    assert isinstance(result[0], Plan)
    assert result[0].id == "plan-123"


def test_list_passes_status_filter(mock_transport):
    mock_transport.add("GET", "/plans", [_PLAN])
    resource = PlansResource(mock_transport)
    resource.list(status="pending_review")
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs["params"]["status"] == "pending_review"


def test_list_no_params_when_no_status(mock_transport):
    mock_transport.add("GET", "/plans", [_PLAN])
    resource = PlansResource(mock_transport)
    resource.list()
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs.get("params", {}) == {}


def test_get_plan(mock_transport):
    mock_transport.add("GET", "/plans/plan-123", _PLAN)
    resource = PlansResource(mock_transport)
    result = resource.get("plan-123")
    assert result.id == "plan-123"
    assert result.status == "pending_review"


def test_pending_plan(mock_transport):
    mock_transport.add("GET", "/plans/pending", _PLAN)
    resource = PlansResource(mock_transport)
    result = resource.pending()
    assert result.id == "plan-123"


def test_approve_plan(mock_transport):
    applied = {**_PLAN, "status": "applied"}
    mock_transport.add("POST", "/plans/plan-123/approve", applied)
    resource = PlansResource(mock_transport)
    result = resource.approve("plan-123")
    assert isinstance(result, Plan)
    assert result.status == "applied"


def test_defer_plan(mock_transport):
    mock_transport.add("POST", "/plans/plan-123/defer", {})
    resource = PlansResource(mock_transport)
    result = resource.defer("plan-123")
    assert result is None
    method, path, _ = mock_transport.calls[0]
    assert method == "POST"
    assert path == "/plans/plan-123/defer"


def test_defer_submission(mock_transport):
    updated = {**_PLAN, "batch_submission_ids": ["sub-2"]}
    mock_transport.add("POST", "/plans/plan-123/submissions/sub-1/defer", updated)
    resource = PlansResource(mock_transport)
    result = resource.defer_submission("plan-123", "sub-1")
    assert isinstance(result, Plan)
    assert result.batch_submission_ids == ["sub-2"]


def test_rollback_plan(mock_transport):
    rolled = {**_PLAN, "status": "rolled_back"}
    mock_transport.add("POST", "/plans/plan-123/rollback", rolled)
    resource = PlansResource(mock_transport)
    result = resource.rollback("plan-123")
    assert result.status == "rolled_back"


def test_delete_plan(mock_transport):
    mock_transport.add("DELETE", "/plans/plan-123", {})
    resource = PlansResource(mock_transport)
    result = resource.delete("plan-123")
    assert result is None
    method, path, _ = mock_transport.calls[0]
    assert method == "DELETE"
    assert path == "/plans/plan-123"


async def test_async_approve(async_mock_transport):
    applied = {**_PLAN, "status": "applied"}
    async_mock_transport.add("POST", "/plans/plan-123/approve", applied)
    resource = AsyncPlansResource(async_mock_transport)
    result = await resource.approve("plan-123")
    assert result.status == "applied"


async def test_async_defer(async_mock_transport):
    async_mock_transport.add("POST", "/plans/plan-123/defer", {})
    resource = AsyncPlansResource(async_mock_transport)
    result = await resource.defer("plan-123")
    assert result is None


async def test_async_list(async_mock_transport):
    async_mock_transport.add("GET", "/plans", [_PLAN])
    resource = AsyncPlansResource(async_mock_transport)
    result = await resource.list()
    assert len(result) == 1
    assert result[0].id == "plan-123"
