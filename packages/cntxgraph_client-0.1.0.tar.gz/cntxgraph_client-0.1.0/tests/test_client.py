from cntxgraph_client.client import CntxgraphClient, AsyncCntxgraphClient
from cntxgraph_client.resources.think import ThinkResource, AsyncThinkResource
from cntxgraph_client.resources.queue import QueueResource, AsyncQueueResource
from cntxgraph_client.resources.plans import PlansResource, AsyncPlansResource
from cntxgraph_client.resources.nodes import NodesResource, AsyncNodesResource
from cntxgraph_client.resources.stack_traces import StackTracesResource, AsyncStackTracesResource


def test_sync_client_has_all_resources():
    # Does not open transport — just checks attribute presence
    client = CntxgraphClient(url="http://localhost:8000")
    assert isinstance(client.think, ThinkResource)
    assert isinstance(client.queue, QueueResource)
    assert isinstance(client.plans, PlansResource)
    assert isinstance(client.nodes, NodesResource)
    assert isinstance(client.stack_traces, StackTracesResource)


def test_async_client_has_all_resources():
    client = AsyncCntxgraphClient(url="http://localhost:8000")
    assert isinstance(client.think, AsyncThinkResource)
    assert isinstance(client.queue, AsyncQueueResource)
    assert isinstance(client.plans, AsyncPlansResource)
    assert isinstance(client.nodes, AsyncNodesResource)
    assert isinstance(client.stack_traces, AsyncStackTracesResource)


def test_sync_client_context_manager():
    with CntxgraphClient(url="http://localhost:8000") as client:
        assert isinstance(client.think, ThinkResource)


async def test_async_client_context_manager():
    async with AsyncCntxgraphClient(url="http://localhost:8000") as client:
        assert isinstance(client.think, AsyncThinkResource)


def test_sync_client_usable_without_context_manager():
    client = CntxgraphClient(url="http://localhost:8000")
    # Resource attributes should exist before any context manager is entered
    assert isinstance(client.think, ThinkResource)
    assert isinstance(client.queue, QueueResource)


def test_top_level_imports():
    from cntxgraph_client import (
        CntxgraphClient,
        AsyncCntxgraphClient,
        CntxgraphError,
        CntxgraphNotFoundError,
        Process,
        Skill,
        ThinkResult,
        Plan,
        Node,
    )
    assert CntxgraphClient is not None
    assert AsyncCntxgraphClient is not None
    assert CntxgraphError is not None
    assert CntxgraphNotFoundError is not None
    assert Process is not None
    assert Skill is not None
    assert ThinkResult is not None
    assert Plan is not None
    assert Node is not None
