import pytest
import httpx

from cntxgraph_client._errors import (
    CntxgraphError,
    CntxgraphNotFoundError,
    CntxgraphValidationError,
    CntxgraphServerError,
    CntxgraphConnectionError,
)
from cntxgraph_client._transport import _map_error


def test_error_attributes():
    err = CntxgraphError(
        "something failed",
        status_code=400,
        request_method="POST",
        request_url="http://localhost:8000/plans",
        raw_body='{"detail": "bad request"}',
    )
    assert str(err) == "something failed"
    assert err.status_code == 400
    assert err.request_method == "POST"
    assert err.request_url == "http://localhost:8000/plans"
    assert err.raw_body == '{"detail": "bad request"}'


def test_connection_error_has_none_status():
    err = CntxgraphConnectionError(
        "connection refused",
        status_code=None,
        request_method="GET",
        request_url="http://localhost:8000/health",
        raw_body="",
    )
    assert err.status_code is None
    assert err.raw_body == ""


def test_not_found_is_cntxgraph_error():
    err = CntxgraphNotFoundError("not found", status_code=404, request_method="GET", request_url="http://x/y", raw_body="")
    assert isinstance(err, CntxgraphError)


def test_server_error_is_cntxgraph_error():
    err = CntxgraphServerError("boom", status_code=500, request_method="GET", request_url="http://x/y", raw_body="boom")
    assert isinstance(err, CntxgraphError)


def test_validation_error_is_cntxgraph_error():
    err = CntxgraphValidationError("invalid input", status_code=422, request_method="POST", request_url="http://x/think", raw_body='{"detail": "missing prompt"}')
    assert isinstance(err, CntxgraphError)
    assert err.status_code == 422


def _resp(status: int, body: str) -> httpx.Response:
    req = httpx.Request("GET", "http://localhost:8000/plans/bad-id")
    return httpx.Response(status, text=body, request=req)


def test_map_404():
    with pytest.raises(CntxgraphNotFoundError) as exc_info:
        _map_error(_resp(404, "not found"))
    err = exc_info.value
    assert err.status_code == 404
    assert err.raw_body == "not found"
    assert err.request_method == "GET"
    assert "bad-id" in err.request_url


def test_map_422():
    with pytest.raises(CntxgraphValidationError) as exc_info:
        _map_error(_resp(422, '{"detail": "missing prompt"}'))
    err = exc_info.value
    assert err.status_code == 422
    assert err.raw_body == '{"detail": "missing prompt"}'
    assert err.request_method == "GET"
    assert "bad-id" in err.request_url


def test_map_500():
    with pytest.raises(CntxgraphServerError) as exc_info:
        _map_error(_resp(500, "internal server error"))
    err = exc_info.value
    assert err.status_code == 500
    assert err.raw_body == "internal server error"


def test_map_503():
    with pytest.raises(CntxgraphServerError) as exc_info:
        _map_error(_resp(503, "service unavailable"))
    err = exc_info.value
    assert err.status_code == 503
    assert err.raw_body == "service unavailable"
