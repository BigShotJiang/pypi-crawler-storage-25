from cntxgraph_client.resources.nodes import NodesResource, AsyncNodesResource
from cntxgraph_client._models import Node

_NODE = {"_key": "sales-node", "name": "Sales", "type": "domain", "description": "Sales domain", "payload": {}, "children": []}
_SUBTREE = {
    "_key": "root", "name": "root", "type": "domain", "description": None, "payload": {},
    "children": [_NODE],
}


def test_get_node(mock_transport):
    mock_transport.add("GET", "/nodes/sales-node", _NODE)
    resource = NodesResource(mock_transport)
    result = resource.get("sales-node")
    assert isinstance(result, Node)
    assert result.id == "sales-node"
    assert result.name == "Sales"


def test_get_node_no_include_by_default(mock_transport):
    mock_transport.add("GET", "/nodes/sales-node", _NODE)
    resource = NodesResource(mock_transport)
    resource.get("sales-node")
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs.get("params", {}) == {}


def test_get_node_with_include(mock_transport):
    mock_transport.add("GET", "/nodes/sales-node", _NODE)
    resource = NodesResource(mock_transport)
    resource.get("sales-node", include=["skill_refs", "provenance_links"])
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs["params"]["include"] == "skill_refs,provenance_links"


def test_subtree_defaults_to_root(mock_transport):
    mock_transport.add("GET", "/nodes/root/subtree", _SUBTREE)
    resource = NodesResource(mock_transport)
    result = resource.subtree()
    assert result.id == "root"
    assert len(result.children) == 1
    _, path, _ = mock_transport.calls[0]
    assert path == "/nodes/root/subtree"


def test_subtree_custom_node(mock_transport):
    mock_transport.add("GET", "/nodes/sales-node/subtree", {**_NODE, "children": []})
    resource = NodesResource(mock_transport)
    resource.subtree(node_id="sales-node")
    _, path, _ = mock_transport.calls[0]
    assert path == "/nodes/sales-node/subtree"


def test_subtree_with_depth(mock_transport):
    mock_transport.add("GET", "/nodes/root/subtree", _SUBTREE)
    resource = NodesResource(mock_transport)
    resource.subtree(depth=2)
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs["params"]["depth"] == 2


def test_subtree_no_depth_param_by_default(mock_transport):
    mock_transport.add("GET", "/nodes/root/subtree", _SUBTREE)
    resource = NodesResource(mock_transport)
    resource.subtree()
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs.get("params", {}) == {}


def test_children_returns_list(mock_transport):
    mock_transport.add("GET", "/nodes/root/children", [_NODE])
    resource = NodesResource(mock_transport)
    result = resource.children("root")
    assert len(result) == 1
    assert isinstance(result[0], Node)
    assert result[0].name == "Sales"


async def test_async_get_node(async_mock_transport):
    async_mock_transport.add("GET", "/nodes/sales-node", _NODE)
    resource = AsyncNodesResource(async_mock_transport)
    result = await resource.get("sales-node")
    assert result.id == "sales-node"


async def test_async_subtree(async_mock_transport):
    async_mock_transport.add("GET", "/nodes/root/subtree", _SUBTREE)
    resource = AsyncNodesResource(async_mock_transport)
    result = await resource.subtree()
    assert result.id == "root"
    assert len(result.children) == 1


async def test_async_children(async_mock_transport):
    async_mock_transport.add("GET", "/nodes/root/children", [_NODE])
    resource = AsyncNodesResource(async_mock_transport)
    result = await resource.children("root")
    assert len(result) == 1
