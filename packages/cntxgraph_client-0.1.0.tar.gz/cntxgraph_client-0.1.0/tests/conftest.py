from typing import Any
import pytest


class _MockTransportBase:
    def __init__(self) -> None:
        self._responses: list[tuple[str, str, Any]] = []
        self.calls: list[tuple[str, str, dict]] = []

    def add(self, method: str, path: str, response: Any) -> None:
        self._responses.append((method.upper(), path, response))

    def _match(self, method: str, path: str, kwargs: dict) -> Any:
        self.calls.append((method.upper(), path, kwargs))
        for m, p, r in self._responses:
            if m == method.upper() and p == path:
                return r
        raise AssertionError(f"No mock registered for {method.upper()} {path}")


class MockTransport(_MockTransportBase):
    def request(self, method: str, path: str, **kwargs: Any) -> Any:
        return self._match(method, path, kwargs)

    def __enter__(self) -> "MockTransport":
        return self

    def __exit__(self, *args: object) -> None:
        pass


class AsyncMockTransport(_MockTransportBase):
    async def request(self, method: str, path: str, **kwargs: Any) -> Any:
        return self._match(method, path, kwargs)

    async def __aenter__(self) -> "AsyncMockTransport":
        return self

    async def __aexit__(self, *args: object) -> None:
        pass


@pytest.fixture
def mock_transport() -> MockTransport:
    return MockTransport()


@pytest.fixture
def async_mock_transport() -> AsyncMockTransport:
    return AsyncMockTransport()
