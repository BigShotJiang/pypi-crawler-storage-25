from cntxgraph_client.resources.queue import QueueResource, AsyncQueueResource
from cntxgraph_client._models import Submission, QueueStatus


def test_submit_returns_submission(mock_transport):
    mock_transport.add("POST", "/queue/submissions", {"submission_id": "sub-abc", "status": "pending"})
    resource = QueueResource(mock_transport)
    result = resource.submit(
        summary="Learned that NDAs over $500k require legal sign-off",
        processes=[{"name": "NDA Review", "description": "Process for reviewing high-value NDAs"}],
    )
    assert isinstance(result, Submission)
    assert result.submission_id == "sub-abc"
    assert result.status == "pending"


def test_submit_sends_correct_body(mock_transport):
    mock_transport.add("POST", "/queue/submissions", {"submission_id": "sub-abc", "status": "pending"})
    resource = QueueResource(mock_transport)
    resource.submit(
        summary="Learned something",
        processes=[{"name": "P", "description": "D"}],
    )
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs["json"]["summary"] == "Learned something"
    assert kwargs["json"]["processes"] == [{"name": "P", "description": "D"}]
    assert "raw_transcript" not in kwargs["json"]
    assert "stack_trace_id" not in kwargs["json"]
    assert "agent_id" not in kwargs["json"]


def test_submit_includes_stack_trace_id_when_provided(mock_transport):
    mock_transport.add("POST", "/queue/submissions", {"submission_id": "sub-abc", "status": "pending"})
    resource = QueueResource(mock_transport)
    resource.submit(
        summary="Learned something",
        processes=[{"name": "P", "description": "D"}],
        stack_trace_id="trace-xyz",
    )
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs["json"]["stack_trace_id"] == "trace-xyz"


def test_submit_includes_agent_id_when_provided(mock_transport):
    mock_transport.add("POST", "/queue/submissions", {"submission_id": "sub-abc", "status": "pending"})
    resource = QueueResource(mock_transport)
    resource.submit(
        summary="Learned something",
        processes=[{"name": "P", "description": "D"}],
        agent_id="my-agent-v1",
    )
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs["json"]["agent_id"] == "my-agent-v1"


def test_submit_includes_transcript_when_provided(mock_transport):
    mock_transport.add("POST", "/queue/submissions", {"submission_id": "sub-xyz", "status": "pending"})
    resource = QueueResource(mock_transport)
    resource.submit(
        summary="Learned something",
        processes=[{"name": "P", "description": "D"}],
        raw_transcript="Full conversation text here",
    )
    _, _, kwargs = mock_transport.calls[0]
    assert kwargs["json"]["raw_transcript"] == "Full conversation text here"


def test_status_returns_queue_status(mock_transport):
    mock_transport.add("GET", "/queue/status", {"pending_count": 3, "oldest_pending_age_hours": 1.5})
    resource = QueueResource(mock_transport)
    result = resource.status()
    assert isinstance(result, QueueStatus)
    assert result.pending_count == 3
    assert result.oldest_pending_age_hours == 1.5


def test_status_null_age_when_empty(mock_transport):
    mock_transport.add("GET", "/queue/status", {"pending_count": 0, "oldest_pending_age_hours": None})
    resource = QueueResource(mock_transport)
    result = resource.status()
    assert result.pending_count == 0
    assert result.oldest_pending_age_hours is None


def test_flush_calls_correct_endpoint(mock_transport):
    mock_transport.add("POST", "/queue/flush", {"detail": "flush signal accepted"})
    resource = QueueResource(mock_transport)
    resource.flush()
    method, path, _ = mock_transport.calls[0]
    assert method == "POST"
    assert path == "/queue/flush"


def test_flush_returns_none(mock_transport):
    mock_transport.add("POST", "/queue/flush", {"detail": "flush signal accepted"})
    resource = QueueResource(mock_transport)
    result = resource.flush()
    assert result is None


async def test_async_submit(async_mock_transport):
    async_mock_transport.add("POST", "/queue/submissions", {"submission_id": "sub-abc", "status": "pending"})
    resource = AsyncQueueResource(async_mock_transport)
    result = await resource.submit("Learned something", [{"name": "P", "description": "D"}])
    assert result.submission_id == "sub-abc"


async def test_async_status(async_mock_transport):
    async_mock_transport.add("GET", "/queue/status", {"pending_count": 1, "oldest_pending_age_hours": 0.5})
    resource = AsyncQueueResource(async_mock_transport)
    result = await resource.status()
    assert result.pending_count == 1


async def test_async_flush(async_mock_transport):
    async_mock_transport.add("POST", "/queue/flush", {"detail": "flush signal accepted"})
    resource = AsyncQueueResource(async_mock_transport)
    result = await resource.flush()
    assert result is None
