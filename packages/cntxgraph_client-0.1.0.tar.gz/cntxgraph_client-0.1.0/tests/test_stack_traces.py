from cntxgraph_client.resources.stack_traces import StackTracesResource, AsyncStackTracesResource
from cntxgraph_client._models import StackTrace, StackTraceEntry

_TRACE = {
    "stack_trace_id": "trace-abc",
    "entries": [
        {"depth": 0, "node": "root", "decision": "descend", "rationale": "Best match: Sales", "skills": []},
    ],
    "node_path": ["Sales"],
    "skills_activated": [],
}


def test_get_returns_stack_trace(mock_transport):
    mock_transport.add("GET", "/stack-traces/trace-abc", _TRACE)
    resource = StackTracesResource(mock_transport)
    result = resource.get("trace-abc")
    assert isinstance(result, StackTrace)
    assert result.stack_trace_id == "trace-abc"
    assert result.node_path == ["Sales"]
    assert len(result.entries) == 1
    assert isinstance(result.entries[0], StackTraceEntry)


def test_get_sends_correct_request(mock_transport):
    mock_transport.add("GET", "/stack-traces/trace-abc", _TRACE)
    resource = StackTracesResource(mock_transport)
    resource.get("trace-abc")
    method, path, _ = mock_transport.calls[0]
    assert method == "GET"
    assert path == "/stack-traces/trace-abc"


def test_append_entry_returns_updated_trace(mock_transport):
    updated = {
        **_TRACE,
        "entries": [
            *_TRACE["entries"],
            {"depth": -1, "node": "Renewal Script", "decision": "activate", "rationale": "Resolved reference", "skills": ["skill-abc"]},
        ],
    }
    mock_transport.add("PATCH", "/stack-traces/trace-abc", updated)
    resource = StackTracesResource(mock_transport)
    entry = StackTraceEntry(depth=-1, node="Renewal Script", decision="activate", rationale="Resolved reference", skills=["skill-abc"])
    result = resource.append_entry("trace-abc", entry)
    assert isinstance(result, StackTrace)
    assert len(result.entries) == 2
    assert result.entries[1].node == "Renewal Script"
    assert result.entries[1].depth == -1


def test_append_entry_sends_correct_request(mock_transport):
    updated = {**_TRACE, "entries": [*_TRACE["entries"], {"depth": -1, "node": "X", "decision": "activate", "rationale": "R", "skills": []}]}
    mock_transport.add("PATCH", "/stack-traces/trace-abc", updated)
    resource = StackTracesResource(mock_transport)
    entry = StackTraceEntry(depth=-1, node="X", decision="activate", rationale="R")
    resource.append_entry("trace-abc", entry)
    method, path, kwargs = mock_transport.calls[0]
    assert method == "PATCH"
    assert path == "/stack-traces/trace-abc"
    assert kwargs["json"]["depth"] == -1
    assert kwargs["json"]["node"] == "X"
    assert kwargs["json"]["decision"] == "activate"


async def test_async_get(async_mock_transport):
    async_mock_transport.add("GET", "/stack-traces/trace-abc", _TRACE)
    resource = AsyncStackTracesResource(async_mock_transport)
    result = await resource.get("trace-abc")
    assert result.stack_trace_id == "trace-abc"


async def test_async_append_entry(async_mock_transport):
    updated = {
        **_TRACE,
        "entries": [*_TRACE["entries"], {"depth": -1, "node": "X", "decision": "activate", "rationale": "R", "skills": []}],
    }
    async_mock_transport.add("PATCH", "/stack-traces/trace-abc", updated)
    resource = AsyncStackTracesResource(async_mock_transport)
    entry = StackTraceEntry(depth=-1, node="X", decision="activate", rationale="R")
    result = await resource.append_entry("trace-abc", entry)
    assert len(result.entries) == 2
