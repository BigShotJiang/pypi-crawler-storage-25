"""One-shot script: mark the dev user as email-verified."""
import sqlite3
import pathlib

db = pathlib.Path("mycontext.db")
if not db.exists():
    print("ERROR: mycontext.db not found. Make sure the backend has started at least once.")
    raise SystemExit(1)

con = sqlite3.connect(str(db))
cur = con.cursor()

email = "dev@mycontext.dev"
cur.execute(
    "UPDATE users SET email_verified=1, email_verify_token=NULL WHERE email=?",
    (email,),
)
con.commit()

cur.execute(
    "SELECT id, email, email_verified, is_active FROM users WHERE email=?",
    (email,),
)
row = cur.fetchone()
if row:
    print(f"OK — user verified: id={row[0]}  email={row[1]}  verified={bool(row[2])}  active={bool(row[3])}")
else:
    print("User not found — did signup succeed?")

con.close()
