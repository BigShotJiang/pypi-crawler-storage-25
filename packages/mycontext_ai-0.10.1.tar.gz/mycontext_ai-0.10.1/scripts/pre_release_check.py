#!/usr/bin/env python3
"""Pre-release checks: same spirit as .github/workflows/backend.yml (lint + unit tests).

Run from repo root:
  uv run python scripts/pre_release_check.py
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    cmds = [
        [sys.executable, "-m", "ruff", "check", "."],
        [sys.executable, "-m", "pytest", "tests/unit/", "-q", "--tb=short"],
    ]
    for cmd in cmds:
        print(">>", " ".join(cmd), flush=True)
        r = subprocess.run(cmd, cwd=ROOT, check=False)
        if r.returncode != 0:
            print(f"FAILED ({r.returncode}): {' '.join(cmd)}", file=sys.stderr)
            return r.returncode
    print("pre_release_check: OK", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
