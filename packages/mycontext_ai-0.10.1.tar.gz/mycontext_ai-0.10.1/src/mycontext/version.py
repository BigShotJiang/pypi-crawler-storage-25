"""Version information"""

__version__ = "0.10.1"
__version_info__ = tuple(int(i) for i in __version__.split(".") if i.isdigit())
