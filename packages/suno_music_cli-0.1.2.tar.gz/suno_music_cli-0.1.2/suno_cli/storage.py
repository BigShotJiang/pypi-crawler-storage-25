from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from .config import CONFIG_DIR

JOBS_FILE = CONFIG_DIR / "jobs.json"


def _read() -> list[dict]:
    if not JOBS_FILE.exists():
        return []
    try:
        return json.loads(JOBS_FILE.read_text())
    except json.JSONDecodeError:
        return []


def _write(jobs: list[dict]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    JOBS_FILE.write_text(json.dumps(jobs, indent=2))


def record(task_id: str, title: str | None, model: str) -> None:
    jobs = _read()
    jobs.append(
        {
            "task_id": task_id,
            "title": title,
            "model": model,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
    )
    _write(jobs)


def list_jobs(limit: int = 20) -> list[dict]:
    jobs = _read()
    return list(reversed(jobs))[:limit]


def last_task_id() -> str | None:
    jobs = _read()
    return jobs[-1]["task_id"] if jobs else None
