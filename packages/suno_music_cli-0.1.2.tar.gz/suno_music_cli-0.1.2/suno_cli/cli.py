from __future__ import annotations

import json as jsonlib
import re
import sys
import time
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TextColumn,
    TimeElapsedColumn,
    TransferSpeedColumn,
)
from rich.table import Table

from . import config as config_mod
from . import storage
from .client import SunoAPIError, SunoClient
from .models import ExtendRequest, GenerateRequest, LyricsRequest

app = typer.Typer(add_completion=False, help="Generate music via sunoapi.org.")
config_app = typer.Typer(help="Manage CLI configuration.")
app.add_typer(config_app, name="config")

console = Console()
err = Console(stderr=True)


def _client() -> SunoClient:
    try:
        return SunoClient(config_mod.load())
    except RuntimeError as e:
        err.print(f"[red]{e}[/red]")
        raise typer.Exit(2)


def _resolve_task_id(task_id: Optional[str], use_last: bool) -> str:
    if task_id and use_last:
        err.print("[red]Pass either a task ID or --last, not both.[/red]")
        raise typer.Exit(2)
    if use_last:
        last = storage.last_task_id()
        if not last:
            err.print("[red]No cached jobs. Run `suno generate` first.[/red]")
            raise typer.Exit(2)
        return last
    if not task_id:
        err.print("[red]Provide a task ID or pass --last.[/red]")
        raise typer.Exit(2)
    return task_id


@app.command()
def generate(
    prompt: Optional[str] = typer.Option(None, "--prompt", "-p", help="Lyrics or description (or '-' for stdin)."),
    lyrics_file: Optional[Path] = typer.Option(None, "--lyrics-file", "-f", help="Read lyrics/prompt from a file."),
    style: Optional[str] = typer.Option(None, "--style", "-s", help="Genre/style descriptor."),
    style_file: Optional[Path] = typer.Option(None, "--style-file", help="Read style descriptor from file."),
    title: Optional[str] = typer.Option(None, "--title", "-t"),
    model: str = typer.Option("V5", "--model", "-m", help="V4|V4_5|V4_5PLUS|V4_5ALL|V5|V5_5"),
    custom: bool = typer.Option(False, "--custom", help="Custom mode (requires --style and --title)."),
    instrumental: bool = typer.Option(False, "--instrumental"),
    negative_tags: Optional[str] = typer.Option(None, "--negative-tags", help="Comma-separated styles to exclude."),
    vocal_gender: Optional[str] = typer.Option(None, "--vocal-gender", help="m or f"),
    persona_id: Optional[str] = typer.Option(None, "--persona-id"),
    persona_model: Optional[str] = typer.Option(None, "--persona-model", help="style_persona or voice_persona"),
    style_weight: Optional[float] = typer.Option(None, "--style-weight", min=0.0, max=1.0, help="0.00–1.00."),
    weirdness: Optional[float] = typer.Option(None, "--weirdness", min=0.0, max=1.0, help="0.00–1.00 creative deviation."),
    audio_weight: Optional[float] = typer.Option(None, "--audio-weight", min=0.0, max=1.0, help="0.00–1.00."),
    callback_url: Optional[str] = typer.Option(None, "--callback-url"),
    wait: bool = typer.Option(False, "--wait", help="Poll until done and print audio URLs."),
    interval: float = typer.Option(10.0, "--interval", help="Polling interval (s) when --wait is set."),
    json_out: bool = typer.Option(False, "--json"),
):
    """Submit a music generation job. Prints the task ID on success."""
    prompt = _read_text_arg(prompt, lyrics_file, "lyrics")
    if style_file:
        style = style_file.read_text().strip()

    if custom and not (style and title):
        err.print("[red]--custom mode requires --style and --title.[/red]")
        raise typer.Exit(2)
    if not custom and not prompt:
        err.print("[red]Non-custom mode requires --prompt or --lyrics-file.[/red]")
        raise typer.Exit(2)
    if custom and not instrumental and not prompt:
        err.print("[red]Custom mode with vocals requires --prompt or --lyrics-file.[/red]")
        raise typer.Exit(2)

    cfg = config_mod.load()
    req = GenerateRequest(
        customMode=custom,
        instrumental=instrumental,
        callBackUrl=callback_url or cfg.callback_url,
        model=model,  # type: ignore[arg-type]
        prompt=prompt,
        style=style,
        title=title,
        negativeTags=negative_tags,
        vocalGender=vocal_gender,  # type: ignore[arg-type]
        personaId=persona_id,
        personaModel=persona_model,  # type: ignore[arg-type]
        styleWeight=style_weight,
        weirdnessConstraint=weirdness,
        audioWeight=audio_weight,
    )

    with SunoClient(cfg) as c:
        try:
            task_id = c.generate(req)
        except SunoAPIError as e:
            err.print(f"[red]API error: {e}[/red]")
            raise typer.Exit(1)

        storage.record(task_id, title=title, model=model)

        if json_out and not wait:
            console.print_json(jsonlib.dumps({"taskId": task_id}))
        else:
            console.print(f"[green]submitted[/green] task_id=[bold]{task_id}[/bold]")

        if wait:
            rec = _poll_until_terminal(c, task_id, interval)
            if json_out:
                console.print_json(rec.model_dump_json())
            else:
                _print_status(rec)
            if not rec.is_success():
                raise typer.Exit(1)
        else:
            console.print(f"check status: [dim]suno status {task_id} --watch[/dim]")


@app.command()
def status(
    task_id: Optional[str] = typer.Argument(None),
    last: bool = typer.Option(False, "--last", help="Use the most recent cached job."),
    watch: bool = typer.Option(False, "--watch", help="Poll until the task finishes."),
    interval: float = typer.Option(10.0, "--interval", help="Polling interval (s)."),
    json_out: bool = typer.Option(False, "--json"),
):
    """Get the status of a generation job."""
    tid = _resolve_task_id(task_id, last)

    with SunoClient(config_mod.load()) as c:
        while True:
            try:
                rec = c.get_record(tid)
            except SunoAPIError as e:
                err.print(f"[red]API error: {e}[/red]")
                raise typer.Exit(1)

            if json_out:
                console.print_json(rec.model_dump_json())
            else:
                _print_status(rec)

            if not watch or rec.is_terminal():
                if rec.is_terminal() and not rec.is_success():
                    raise typer.Exit(1)
                return
            time.sleep(interval)


@app.command()
def download(
    task_id: Optional[str] = typer.Argument(None),
    last: bool = typer.Option(False, "--last"),
    output: Path = typer.Option(Path.cwd(), "--output", "-o", help="Directory or file path."),
    url_only: bool = typer.Option(False, "--url-only", help="Print audio URLs without downloading."),
    track: Optional[int] = typer.Option(None, "--track", help="1-based track index (default: all)."),
):
    """Download generated audio (or print URLs)."""
    tid = _resolve_task_id(task_id, last)

    with SunoClient(config_mod.load()) as c:
        try:
            rec = c.get_record(tid)
        except SunoAPIError as e:
            err.print(f"[red]API error: {e}[/red]")
            raise typer.Exit(1)

        if not rec.is_success():
            err.print(f"[yellow]Not ready yet (status={rec.status}). Try `suno status {tid} --watch`.[/yellow]")
            raise typer.Exit(1)

        tracks = rec.tracks()
        if track is not None:
            if track < 1 or track > len(tracks):
                err.print(f"[red]--track must be 1..{len(tracks)}[/red]")
                raise typer.Exit(2)
            tracks = [tracks[track - 1]]

        if url_only:
            for t in tracks:
                console.print(t.audioUrl or "")
            return

        multi = len(tracks) > 1
        for t in tracks:
            if not t.audioUrl:
                err.print(f"[yellow]Track {t.id} has no audioUrl yet.[/yellow]")
                continue
            base = t.title or t.id
            if multi:
                base = f"{base}-{t.id[:8]}"
            dest = _resolve_dest(output, base, t.audioUrl)
            _stream_to_disk(c, t.audioUrl, dest)
            console.print(f"[green]saved[/green] {dest}")


@app.command()
def extend(
    task_id: str = typer.Argument(..., help="Source task ID whose track will be extended."),
    track: int = typer.Option(1, "--track", help="1-based index of track within the source task."),
    continue_at: Optional[float] = typer.Option(None, "--continue-at", help="Seconds into the source track to continue from."),
    prompt: Optional[str] = typer.Option(None, "--prompt", "-p"),
    lyrics_file: Optional[Path] = typer.Option(None, "--lyrics-file", "-f"),
    style: Optional[str] = typer.Option(None, "--style", "-s"),
    style_file: Optional[Path] = typer.Option(None, "--style-file"),
    title: Optional[str] = typer.Option(None, "--title", "-t"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Must match the source model. Defaults to source."),
    use_defaults: bool = typer.Option(False, "--use-defaults", help="Reuse the source track's params (no prompt/style/title needed)."),
    negative_tags: Optional[str] = typer.Option(None, "--negative-tags"),
    vocal_gender: Optional[str] = typer.Option(None, "--vocal-gender"),
    persona_id: Optional[str] = typer.Option(None, "--persona-id"),
    persona_model: Optional[str] = typer.Option(None, "--persona-model"),
    style_weight: Optional[float] = typer.Option(None, "--style-weight", min=0.0, max=1.0),
    weirdness: Optional[float] = typer.Option(None, "--weirdness", min=0.0, max=1.0),
    audio_weight: Optional[float] = typer.Option(None, "--audio-weight", min=0.0, max=1.0),
    callback_url: Optional[str] = typer.Option(None, "--callback-url"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Continue an existing track from a timestamp (POST /api/v1/generate/extend)."""
    prompt = _read_text_arg(prompt, lyrics_file, "lyrics", required=False)
    if style_file:
        style = style_file.read_text().strip()

    cfg = config_mod.load()
    with SunoClient(cfg) as c:
        try:
            source = c.get_record(task_id)
        except SunoAPIError as e:
            err.print(f"[red]API error reading source task: {e}[/red]")
            raise typer.Exit(1)

        tracks = source.tracks()
        if not tracks:
            err.print(f"[red]Source task has no tracks (status={source.status}).[/red]")
            raise typer.Exit(1)
        if track < 1 or track > len(tracks):
            err.print(f"[red]--track must be 1..{len(tracks)}[/red]")
            raise typer.Exit(2)
        chosen = tracks[track - 1]
        chosen_model = model or chosen.modelName or "V5"

        if not use_defaults and continue_at is None:
            err.print("[red]Provide --continue-at, or pass --use-defaults to inherit source params.[/red]")
            raise typer.Exit(2)
        if not use_defaults and not (prompt and style and title):
            err.print("[red]Custom-param mode requires --prompt, --style, and --title (or --use-defaults).[/red]")
            raise typer.Exit(2)

        req = ExtendRequest(
            defaultParamFlag=not use_defaults,
            audioId=chosen.id,
            model=chosen_model,  # type: ignore[arg-type]
            callBackUrl=callback_url or cfg.callback_url,
            prompt=prompt,
            style=style,
            title=title,
            continueAt=continue_at,
            negativeTags=negative_tags,
            vocalGender=vocal_gender,  # type: ignore[arg-type]
            personaId=persona_id,
            personaModel=persona_model,  # type: ignore[arg-type]
            styleWeight=style_weight,
            weirdnessConstraint=weirdness,
            audioWeight=audio_weight,
        )

        try:
            new_task_id = c.extend(req)
        except SunoAPIError as e:
            err.print(f"[red]API error: {e}[/red]")
            raise typer.Exit(1)

    storage.record(new_task_id, title=title or f"extend@{continue_at}", model=chosen_model)
    if json_out:
        console.print_json(jsonlib.dumps({"taskId": new_task_id, "audioId": chosen.id}))
    else:
        console.print(f"[green]submitted[/green] extend task_id=[bold]{new_task_id}[/bold] from audio_id={chosen.id}")


@app.command()
def lyrics(
    prompt: Optional[str] = typer.Option(None, "--prompt", "-p", help="Lyrics description (max 200 chars)."),
    prompt_file: Optional[Path] = typer.Option(None, "--prompt-file", "-f"),
    callback_url: Optional[str] = typer.Option(None, "--callback-url"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Submit a lyrics-only generation (POST /api/v1/lyrics). Result arrives via callback."""
    prompt = _read_text_arg(prompt, prompt_file, "prompt")
    if len(prompt) > 200:
        err.print("[red]Lyrics prompt must be 200 chars or less.[/red]")
        raise typer.Exit(2)

    cfg = config_mod.load()
    req = LyricsRequest(prompt=prompt, callBackUrl=callback_url or cfg.callback_url)
    with SunoClient(cfg) as c:
        try:
            task_id = c.generate_lyrics(req)
        except SunoAPIError as e:
            err.print(f"[red]API error: {e}[/red]")
            raise typer.Exit(1)

    if json_out:
        console.print_json(jsonlib.dumps({"taskId": task_id}))
    else:
        console.print(f"[green]submitted[/green] lyrics task_id=[bold]{task_id}[/bold]")
        console.print("[dim]results are delivered via the callback URL.[/dim]")


@app.command()
def credits():
    """Show remaining credits (GET /api/v1/generate/credit)."""
    with SunoClient(config_mod.load()) as c:
        try:
            balance = c.get_credits()
        except SunoAPIError as e:
            err.print(f"[red]API error: {e}[/red]")
            raise typer.Exit(1)
    console.print(f"credits: [bold]{balance}[/bold]")


@app.command(name="list")
def list_cmd(limit: int = typer.Option(20, "--limit")):
    """Show recently submitted jobs from local cache."""
    jobs = storage.list_jobs(limit=limit)
    if not jobs:
        console.print("[dim]no cached jobs[/dim]")
        return
    table = Table("created", "task_id", "title", "model")
    for j in jobs:
        table.add_row(j["created_at"], j["task_id"], j.get("title") or "-", j.get("model") or "-")
    console.print(table)


@config_app.command("set-key")
def set_key(api_key: str = typer.Argument(...)):
    """Save the API key to ~/.suno/config.toml."""
    path = config_mod.write_key(api_key)
    console.print(f"[green]saved[/green] {path}")


@config_app.command("show")
def show_config():
    try:
        cfg = config_mod.load()
    except RuntimeError as e:
        err.print(f"[red]{e}[/red]")
        raise typer.Exit(2)
    console.print(f"base_url    = {cfg.base_url}")
    console.print(f"callback    = {cfg.callback_url}")
    console.print(f"api_key     = {'*' * 4}{cfg.api_key[-4:]}")


def _read_text_arg(value: Optional[str], file: Optional[Path], label: str, required: bool = True) -> Optional[str]:
    if value == "-":
        value = sys.stdin.read()
    if file:
        if value:
            err.print(f"[red]Pass either inline {label} or a file, not both.[/red]")
            raise typer.Exit(2)
        value = file.read_text()
    if value is not None:
        value = value.strip()
    if required and not value:
        return None  # caller validates required-ness in context
    return value or None


def _poll_until_terminal(client: SunoClient, task_id: str, interval: float):
    while True:
        rec = client.get_record(task_id)
        if rec.is_terminal():
            return rec
        time.sleep(interval)


def _print_status(rec) -> None:
    color = "green" if rec.is_success() else "red" if rec.is_terminal() else "yellow"
    console.print(f"task=[bold]{rec.taskId}[/bold] status=[{color}]{rec.status}[/{color}]")
    if rec.errorMessage:
        err.print(f"[red]error:[/red] {rec.errorMessage}")
    for i, t in enumerate(rec.tracks(), 1):
        bits = [f"track {i}", f"id={t.id}"]
        if t.duration:
            bits.append(f"{t.duration:.0f}s")
        if t.audioUrl:
            bits.append(f"audio={t.audioUrl}")
        elif t.streamAudioUrl:
            bits.append(f"stream={t.streamAudioUrl}")
        console.print("  " + " ".join(bits))


def _safe_filename(name: str) -> str:
    cleaned = re.sub(r"[^\w\-. ]+", "_", name).strip().strip(".")
    return cleaned or "track"


def _resolve_dest(output: Path, name: str, url: str) -> Path:
    suffix = Path(url.split("?", 1)[0]).suffix or ".mp3"
    if output.exists() and output.is_dir():
        return output / f"{_safe_filename(name)}{suffix}"
    if output.suffix:
        return output
    return output / f"{_safe_filename(name)}{suffix}"


def _stream_to_disk(client: SunoClient, url: str, dest: Path) -> None:
    columns = (
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeElapsedColumn(),
    )
    with Progress(*columns, console=console) as progress:
        stream = client.stream_download(url, dest)
        total = next(stream)
        task = progress.add_task(dest.name, total=total or None)
        for n in stream:
            progress.update(task, advance=n)


def main() -> None:
    try:
        app()
    except KeyboardInterrupt:
        err.print("[yellow]interrupted[/yellow]")
        sys.exit(130)


if __name__ == "__main__":
    main()
