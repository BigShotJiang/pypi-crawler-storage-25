from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

CONFIG_DIR = Path.home() / ".suno"
CONFIG_FILE = CONFIG_DIR / "config.toml"
DEFAULT_BASE_URL = "https://api.sunoapi.org"
DEFAULT_CALLBACK_URL = "https://example.com/callback"


@dataclass
class Config:
    api_key: str
    base_url: str = DEFAULT_BASE_URL
    callback_url: str = DEFAULT_CALLBACK_URL


def load() -> Config:
    file_data: dict = {}
    if CONFIG_FILE.exists():
        with CONFIG_FILE.open("rb") as f:
            file_data = tomllib.load(f)

    api_key = os.environ.get("SUNO_API_KEY") or file_data.get("api_key")
    if not api_key:
        raise RuntimeError(
            "No API key found. Set SUNO_API_KEY or run `suno config set-key <key>`."
        )

    return Config(
        api_key=api_key,
        base_url=os.environ.get("SUNO_BASE_URL") or file_data.get("base_url", DEFAULT_BASE_URL),
        callback_url=os.environ.get("SUNO_CALLBACK_URL")
        or file_data.get("callback_url", DEFAULT_CALLBACK_URL),
    )


def write_key(api_key: str) -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    existing: dict = {}
    if CONFIG_FILE.exists():
        with CONFIG_FILE.open("rb") as f:
            existing = tomllib.load(f)
    existing["api_key"] = api_key
    lines = [f'{k} = "{v}"' for k, v in existing.items()]
    CONFIG_FILE.write_text("\n".join(lines) + "\n")
    CONFIG_FILE.chmod(0o600)
    return CONFIG_FILE
