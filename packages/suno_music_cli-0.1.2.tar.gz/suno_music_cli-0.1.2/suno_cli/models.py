from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

Model = Literal["V4", "V4_5", "V4_5PLUS", "V4_5ALL", "V5", "V5_5"]
TerminalStatus = {
    "SUCCESS",
    "CREATE_TASK_FAILED",
    "GENERATE_AUDIO_FAILED",
    "CALLBACK_EXCEPTION",
    "SENSITIVE_WORD_ERROR",
}


PersonaModel = Literal["style_persona", "voice_persona"]


class GenerateRequest(BaseModel):
    customMode: bool
    instrumental: bool
    callBackUrl: str
    model: Model
    prompt: str | None = None
    style: str | None = None
    title: str | None = None
    negativeTags: str | None = None
    vocalGender: Literal["m", "f"] | None = None
    personaId: str | None = None
    personaModel: PersonaModel | None = None
    styleWeight: float | None = Field(default=None, ge=0, le=1)
    weirdnessConstraint: float | None = Field(default=None, ge=0, le=1)
    audioWeight: float | None = Field(default=None, ge=0, le=1)


class ExtendRequest(BaseModel):
    defaultParamFlag: bool
    audioId: str
    model: Model
    callBackUrl: str
    prompt: str | None = None
    style: str | None = None
    title: str | None = None
    continueAt: float | None = None
    personaId: str | None = None
    personaModel: PersonaModel | None = None
    negativeTags: str | None = None
    vocalGender: Literal["m", "f"] | None = None
    styleWeight: float | None = Field(default=None, ge=0, le=1)
    weirdnessConstraint: float | None = Field(default=None, ge=0, le=1)
    audioWeight: float | None = Field(default=None, ge=0, le=1)


class LyricsRequest(BaseModel):
    prompt: str
    callBackUrl: str


class TrackInfo(BaseModel):
    id: str
    audioUrl: str | None = None
    streamAudioUrl: str | None = None
    imageUrl: str | None = None
    title: str | None = None
    tags: str | None = None
    duration: float | None = None
    modelName: str | None = None


class RecordInfoData(BaseModel):
    taskId: str
    status: str
    errorCode: int | None = None
    errorMessage: str | None = None
    response: dict | None = None

    def tracks(self) -> list[TrackInfo]:
        if not self.response:
            return []
        return [TrackInfo(**t) for t in self.response.get("sunoData") or []]

    def is_terminal(self) -> bool:
        return self.status in TerminalStatus

    def is_success(self) -> bool:
        return self.status == "SUCCESS"
