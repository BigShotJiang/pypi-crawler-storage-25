from __future__ import annotations

from pathlib import Path
from typing import Iterator

import httpx

from .config import Config
from .models import ExtendRequest, GenerateRequest, LyricsRequest, RecordInfoData


class SunoAPIError(RuntimeError):
    def __init__(self, code: int, message: str):
        super().__init__(f"[{code}] {message}")
        self.code = code
        self.message = message


class SunoClient:
    def __init__(self, config: Config, timeout: float = 30.0):
        self._config = config
        self._http = httpx.Client(
            base_url=config.base_url,
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=timeout,
        )

    def __enter__(self) -> "SunoClient":
        return self

    def __exit__(self, *_exc) -> None:
        self._http.close()

    def generate(self, req: GenerateRequest) -> str:
        r = self._http.post("/api/v1/generate", json=req.model_dump(exclude_none=True))
        return self._unwrap(r)["taskId"]

    def extend(self, req: ExtendRequest) -> str:
        r = self._http.post("/api/v1/generate/extend", json=req.model_dump(exclude_none=True))
        return self._unwrap(r)["taskId"]

    def generate_lyrics(self, req: LyricsRequest) -> str:
        r = self._http.post("/api/v1/lyrics", json=req.model_dump(exclude_none=True))
        return self._unwrap(r)["taskId"]

    def get_credits(self) -> int:
        r = self._http.get("/api/v1/generate/credit")
        return int(self._unwrap(r))

    def get_record(self, task_id: str) -> RecordInfoData:
        r = self._http.get("/api/v1/generate/record-info", params={"taskId": task_id})
        body = self._unwrap(r)
        return RecordInfoData(**body)

    def stream_download(self, url: str, dest: Path, chunk: int = 65536) -> Iterator[int]:
        dest.parent.mkdir(parents=True, exist_ok=True)
        with httpx.stream("GET", url, timeout=None, follow_redirects=True) as r:
            r.raise_for_status()
            total = int(r.headers.get("content-length") or 0)
            yield total
            with dest.open("wb") as f:
                for block in r.iter_bytes(chunk):
                    f.write(block)
                    yield len(block)

    @staticmethod
    def _unwrap(r: httpx.Response):
        try:
            body = r.json()
        except ValueError:
            r.raise_for_status()
            raise SunoAPIError(r.status_code, f"non-JSON response: {r.text[:200]}")
        code = body.get("code", r.status_code)
        if code != 200:
            raise SunoAPIError(code, body.get("msg") or "request failed")
        return body.get("data")
