from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from qbu_crawler import config


@dataclass(frozen=True)
class EmailDecision:
    send_email: bool
    reason: str
    cadence: str
    report_window_type: str
    window_days: int
    # F012 M3：周一/bootstrap 路径必须发邮件，绕过下游频率门（如 should_send_quiet_email）。
    # 与 send_email 的区别：send_email 是"是否要发"，force_send 是"哪怕下游想跳过也必须发"。
    # daily cadence 下 force_send=False，让 quiet 子函数继续按"前 N 天连发，第 7/14 天" 算法节流。
    force_send: bool = False


def _logical_date(value: str) -> date:
    return date.fromisoformat(str(value)[:10])


def _is_bootstrap(snapshot: dict) -> bool:
    if snapshot.get("report_semantics") == "bootstrap":
        return True
    if snapshot.get("is_bootstrap") is True:
        return True
    return False


def decide_business_email(*, run: dict, snapshot: dict, mode: str) -> EmailDecision:
    window_days = int(getattr(config, "REPORT_WEEKLY_WINDOW_DAYS", 7))
    if _is_bootstrap(snapshot):
        if bool(getattr(config, "REPORT_EMAIL_FORCE_DISABLED", False)):
            return EmailDecision(False, "email_disabled", "bootstrap", "bootstrap", window_days, False)
        if bool(getattr(config, "REPORT_EMAIL_SEND_BOOTSTRAP", True)):
            return EmailDecision(True, "bootstrap", "bootstrap", "bootstrap", window_days, True)
        return EmailDecision(False, "bootstrap_email_disabled", "bootstrap", "daily", window_days, False)

    cadence = getattr(config, "REPORT_EMAIL_CADENCE", "weekly")
    if bool(getattr(config, "REPORT_EMAIL_FORCE_DISABLED", False)):
        return EmailDecision(False, "email_disabled", cadence, "daily", window_days, False)
    if cadence == "daily":
        return EmailDecision(True, "daily_cadence", "daily", "daily", window_days, False)

    logical_date = _logical_date(run.get("logical_date") or snapshot.get("logical_date"))
    if logical_date.isoweekday() == int(getattr(config, "REPORT_WEEKLY_EMAIL_WEEKDAY", 1)):
        return EmailDecision(True, "weekly_report_day", "weekly", "weekly", window_days, True)
    return EmailDecision(False, "weekly_cadence_skip", "weekly", "daily", window_days, False)
