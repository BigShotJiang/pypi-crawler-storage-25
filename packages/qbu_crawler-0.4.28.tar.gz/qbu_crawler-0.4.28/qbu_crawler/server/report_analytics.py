import json
import re
from datetime import date, timedelta

from qbu_crawler import config, models


def _date_sort_key(date_str):
    """Parse date string for chronological sorting. Unparseable → epoch."""
    from qbu_crawler.server.report_common import _parse_date_flexible
    parsed = _parse_date_flexible(date_str)
    return parsed or date(1970, 1, 1)


NEGATIVE_LABELS = (
    "quality_stability",
    "structure_design",
    "assembly_installation",
    "material_finish",
    "cleaning_maintenance",
    "noise_power",
    "packaging_shipping",
    "service_fulfillment",
)

POSITIVE_LABELS = (
    "easy_to_use",
    "solid_build",
    "good_value",
    "easy_to_clean",
    "strong_performance",
    "good_packaging",
)

TAXONOMY_VERSION = "v1"

_POLARITY_WHITELIST = {
    "quality_stability": {"negative"},
    "structure_design": {"negative"},
    "assembly_installation": {"negative"},
    "material_finish": {"negative"},
    "cleaning_maintenance": {"negative"},
    "noise_power": {"negative"},
    "packaging_shipping": {"negative"},
    "service_fulfillment": {"negative", "positive"},  # bidirectional
    "easy_to_use": {"positive"},
    "solid_build": {"positive"},
    "good_value": {"positive"},
    "easy_to_clean": {"positive"},
    "strong_performance": {"positive"},
    "good_packaging": {"positive"},
}

_MAX_LABELS_PER_REVIEW = 3

_NEGATIVE_RULES = {
    "quality_stability": {
        "severity": "high",
        "confidence": 0.95,
        "keywords": (
            "broke",
            "broken",
            "breaks",
            "failed",
            "failure",
            "stopped working",
            "defect",
            "defective",
            "flimsy",
            "not durable",
            "坏了",
            "故障",
            "失灵",
            "不耐用",
            "损坏",
        ),
    },
    "structure_design": {
        "severity": "medium",
        "confidence": 0.9,
        "keywords": (
            "poor design",
            "design flaw",
            "awkward",
            "unstable",
            "wobbly",
            "too small",
            "too big",
            "设计问题",
            "结构问题",
            "不稳",
        ),
    },
    "assembly_installation": {
        "severity": "medium",
        "confidence": 0.9,
        "keywords": (
            "hard to assemble",
            "difficult to assemble",
            "difficult to install",
            "instructions unclear",
            "assembly was difficult",
            "安装困难",
            "组装困难",
            "说明书不清楚",
        ),
    },
    "material_finish": {
        "severity": "medium",
        "confidence": 0.88,
        "keywords": (
            "cheap plastic",
            "rust",
            "rusted",
            "rusting",
            "poor finish",
            "bad finish",
            "finish peeling",
            "finish chipping",
            "scratched",
            "scratch",
            "材料差",
            "做工差",
            "生锈",
            "毛刺",
        ),
    },
    "cleaning_maintenance": {
        "severity": "medium",
        "confidence": 0.88,
        "keywords": (
            "hard to clean",
            "difficult to clean",
            "messy to clean",
            "难清洗",
            "不好清洁",
        ),
    },
    "noise_power": {
        "severity": "high",
        "confidence": 0.92,
        "keywords": (
            "noisy",
            "too loud",
            "weak motor",
            "not powerful",
            "动力不足",
            "噪音",
            "太吵",
        ),
    },
    "packaging_shipping": {
        "severity": "medium",
        "confidence": 0.86,
        "keywords": (
            "damaged on arrival",
            "arrived damaged",
            "shipping damage",
            "packaging was damaged",
            "包装破损",
            "运输损坏",
            "箱子破了",
        ),
    },
    "service_fulfillment": {
        "severity": "low",
        "confidence": 0.82,
        "keywords": (
            "customer service",
            "missing parts",
            "wrong item",
            "late delivery",
            "客服",
            "漏件",
            "少件",
            "发错",
            "送错",
        ),
    },
}

_POSITIVE_RULES = {
    "easy_to_use": {
        "severity": "low",
        "confidence": 0.92,
        "keywords": (
            "easy to use",
            "simple to use",
            "easy setup",
            "easy setup",
            "user friendly",
            "easy assembly",
            "好上手",
            "简单易用",
            "安装简单",
            "使用方便",
        ),
    },
    "solid_build": {
        "severity": "medium",
        "confidence": 0.9,
        "keywords": (
            "solid build",
            "well made",
            "sturdy",
            "durable",
            "做工扎实",
            "结实",
            "质量好",
        ),
    },
    "good_value": {
        "severity": "low",
        "confidence": 0.86,
        "keywords": (
            "good value",
            "worth the money",
            "great value",
            "great price",
            "性价比高",
            "值得",
            "物有所值",
        ),
    },
    "easy_to_clean": {
        "severity": "low",
        "confidence": 0.9,
        "keywords": (
            "easy to clean",
            "cleans easily",
            "easy cleanup",
            "容易清洗",
            "清洗方便",
        ),
    },
    "strong_performance": {
        "severity": "medium",
        "confidence": 0.9,
        "keywords": (
            "works great",
            "great performance",
            "powerful motor",
            "powerful enough",
            "very powerful",
            "performs well",
            "动力强",
            "性能好",
        ),
    },
    "good_packaging": {
        "severity": "low",
        "confidence": 0.84,
        "keywords": (
            "well packaged",
            "packaged well",
            "arrived intact",
            "包装好",
            "包装严实",
        ),
    },
}

_SEVERITY_SCORE = {"critical": 4, "high": 3, "medium": 2, "low": 1}

_SAFETY_KEYWORDS = frozenset({
    "metal shaving", "metal debris", "metal flake", "metal particle",
    "broke", "broken", "snapped", "shattered", "exploded",
    "dangerous", "hazard", "injury", "hurt", "unsafe",
    "rust", "rusted", "corrosion",
    "金属屑", "金属碎", "断裂", "爆裂", "危险", "安全", "锈",
})


def compute_cluster_severity(cluster, reviews_in_cluster, logical_date):
    """Compute severity at cluster level from volume, breadth, recency, safety.

    Args:
        cluster: dict with review_count, affected_product_count, review_dates
        reviews_in_cluster: list of review dicts (for safety keyword scan)
        logical_date: date object for recency calculation

    Returns one of: "critical", "high", "medium", "low".
    """
    from datetime import datetime, timedelta

    review_count = cluster.get("review_count", 0)
    affected_products = cluster.get("affected_product_count", 0)

    # Recency: count reviews from last 90 days
    recent_cutoff = logical_date - timedelta(days=90)
    recent_count = 0
    for d in cluster.get("review_dates", []):
        try:
            if datetime.strptime(d, "%Y-%m-%d").date() >= recent_cutoff:
                recent_count += 1
        except (ValueError, TypeError):
            pass
    recency_rate = recent_count / max(review_count, 1)

    # Safety signal
    has_safety = False
    for r in reviews_in_cluster:
        text = f"{r.get('headline', '')} {r.get('body', '')}".lower()
        if any(kw in text for kw in _SAFETY_KEYWORDS):
            has_safety = True
            break

    score = 0
    if review_count >= 20:
        score += 3
    elif review_count >= 10:
        score += 2
    elif review_count >= 5:
        score += 1

    if affected_products >= 3:
        score += 2
    elif affected_products >= 2:
        score += 1

    if recency_rate >= 0.30:
        score += 2
    elif recency_rate >= 0.10:
        score += 1

    if has_safety:
        score += 3

    if score >= 7:
        return "critical"
    if score >= 5:
        return "high"
    if score >= 3:
        return "medium"
    return "low"


_RECOMMENDATION_MAP = {
    "quality_stability": {
        "possible_cause_boundary": "可能与核心部件耐久性、负载冗余或质检拦截不足有关",
        "improvement_direction": "优先复核高频失效部件寿命、材料和出厂老化测试",
    },
    "structure_design": {
        "possible_cause_boundary": "可能与结构支撑、尺寸匹配或人机设计不顺有关",
        "improvement_direction": "复核关键尺寸、公差和使用姿态，缩短用户完成主任务的步骤",
    },
    "assembly_installation": {
        "possible_cause_boundary": "可能与安装路径复杂、说明表达不足或配件定位不直观有关",
        "improvement_direction": "优先减少装配步骤并补强说明书、装配视频和定位结构",
    },
    "material_finish": {
        "possible_cause_boundary": "可能与外观件材料选择、表面处理或供应稳定性有关",
        "improvement_direction": "加强表面处理一致性和来料外观检验，降低廉价感",
    },
    "cleaning_maintenance": {
        "possible_cause_boundary": "可能与死角过多、拆洗路径不顺或污渍残留有关",
        "improvement_direction": "优化拆洗动线和易藏污部位，减少用户清洁阻力",
    },
    "noise_power": {
        "possible_cause_boundary": "可能与电机功率匹配、振动控制或隔音设计不足有关",
        "improvement_direction": "优先验证动力余量和噪声源，评估减振和隔音方案",
    },
    "packaging_shipping": {
        "possible_cause_boundary": "可能与包装缓冲、防护结构或物流跌落场景覆盖不足有关",
        "improvement_direction": "补强高风险边角防护和跌落测试，减少到货损伤",
    },
    "service_fulfillment": {
        "possible_cause_boundary": "可能与配件齐套、发货校验或售后 SOP 不一致有关",
        "improvement_direction": "复核配件清单和出库校验，压缩售后闭环时间",
    },
}


_NEGATION_WORDS = {"not", "no", "never", "don't", "doesn't", "didn't", "isn't", "wasn't",
                   "won't", "can't", "couldn't", "shouldn't", "wouldn't", "hardly",
                   "没有", "不", "不会", "没", "未", "无"}
_NEGATION_WINDOW = 4

_KEYWORD_PATTERN_CACHE: dict[str, re.Pattern] = {}


def _build_keyword_pattern(keyword: str) -> re.Pattern:
    cjk_chars = sum(1 for c in keyword if '\u4e00' <= c <= '\u9fff')
    if cjk_chars > len(keyword) / 2:
        return re.compile(re.escape(keyword))
    return re.compile(r'\b' + re.escape(keyword) + r'\b', re.IGNORECASE)


def _get_keyword_pattern(keyword: str) -> re.Pattern:
    if keyword not in _KEYWORD_PATTERN_CACHE:
        _KEYWORD_PATTERN_CACHE[keyword] = _build_keyword_pattern(keyword)
    return _KEYWORD_PATTERN_CACHE[keyword]


def _is_negated(text: str, match_start: int, keyword: str) -> bool:
    cjk_chars = sum(1 for c in keyword if '\u4e00' <= c <= '\u9fff')
    if cjk_chars > len(keyword) / 2:
        prefix = text[max(0, match_start - 4):match_start]
        return any(neg in prefix for neg in ("不", "没", "未", "无", "没有", "不会"))
    before_text = text[:match_start]
    words = before_text.split()
    preceding = words[-_NEGATION_WINDOW:] if words else []
    return any(w.lower().rstrip(".,;:!?") in _NEGATION_WORDS for w in preceding)


def _safe_date(value):
    return date.fromisoformat(value)


def _review_text(review):
    parts = [
        review.get("headline") or "",
        review.get("body") or "",
        review.get("headline_cn") or "",
        review.get("body_cn") or "",
    ]
    return " ".join(parts).lower()


def _review_images(review):
    images = review.get("images") or []
    if isinstance(images, str):
        try:
            images = json.loads(images)
        except Exception:
            images = []
    return images


def _product_key(product_name, product_sku):
    if product_sku:
        return product_sku
    return product_name or ""


def _group_products(products):
    grouped = {}
    for product in products:
        grouped[_product_key(product.get("name"), product.get("sku"))] = product
    return grouped


def _review_id(review):
    return review.get("id") or review.get("review_id")


def _match_rule(text: str, rule: dict) -> bool:
    for keyword in rule["keywords"]:
        pattern = _get_keyword_pattern(keyword)
        for m in pattern.finditer(text):
            if not _is_negated(text, m.start(), keyword):
                return True
    return False


def _label_item(label_code, label_polarity, rule):
    return {
        "label_code": label_code,
        "label_polarity": label_polarity,
        "severity": rule["severity"],
        "confidence": rule["confidence"],
        "source": "rule",
        "taxonomy_version": TAXONOMY_VERSION,
    }


def classify_review_labels(review):
    text = _review_text(review)
    negative = []
    positive = []
    for label_code, rule in _NEGATIVE_RULES.items():
        if _match_rule(text, rule):
            negative.append(_label_item(label_code, "negative", rule))
    for label_code, rule in _POSITIVE_RULES.items():
        if _match_rule(text, rule):
            positive.append(_label_item(label_code, "positive", rule))

    ownership = review.get("ownership") or ""
    labels = positive + negative if ownership == "competitor" else negative + positive
    labels.sort(
        key=lambda item: (
            0 if ownership == "competitor" and item["label_polarity"] == "positive" else 1
            if ownership == "competitor"
            else 0 if item["label_polarity"] == "negative" else 1,
            -_SEVERITY_SCORE[item["severity"]],
            -item["confidence"],
            item["label_code"],
        )
    )
    return labels


def detect_report_mode(run_id, logical_date):
    current_date = _safe_date(logical_date)
    since_date = (current_date - timedelta(days=30)).isoformat()
    conn = models.get_conn()
    try:
        rows = conn.execute(
            """
            SELECT id, logical_date
            FROM workflow_runs
            WHERE workflow_type = 'daily'
              AND status = 'completed'
              AND logical_date >= ?
              AND logical_date < ?
              AND id != ?
            ORDER BY logical_date ASC, id ASC
            """,
            (since_date, logical_date, run_id),
        ).fetchall()
    finally:
        conn.close()

    baseline_run_ids = [row["id"] for row in rows]
    baseline_sample_days = len(rows)
    baseline_day_index = baseline_sample_days + 1
    return {
        "mode": "incremental" if baseline_sample_days >= 3 else "baseline",
        "baseline_run_ids": baseline_run_ids,
        "baseline_sample_days": baseline_sample_days,
        "baseline_day_index": baseline_day_index,
        "baseline_display_state": "initial" if baseline_day_index == 1 else "building",
    }


def _maybe_normalize_labels_with_llm(review_labels):
    return {}


def _sanitize_hybrid_labels(candidate_labels, llm_labels):
    if not llm_labels:
        return []

    allowed_codes = {item["label_code"] for item in candidate_labels}
    sanitized = []
    for item in llm_labels:
        if item.get("label_code") not in allowed_codes:
            continue
        if item.get("label_polarity") not in {"negative", "positive"}:
            continue
        if item.get("severity") not in _SEVERITY_SCORE:
            continue
        sanitized.append(
            {
                "label_code": item["label_code"],
                "label_polarity": item["label_polarity"],
                "severity": item["severity"],
                "confidence": item.get("confidence", 0.9),
                "source": item.get("source", "llm"),
                "taxonomy_version": TAXONOMY_VERSION,
            }
        )
    return sanitized


def _extract_validated_llm_labels(review):
    """Extract and validate LLM labels from review's analysis_labels field.

    Maps LLM field names (code/polarity) to downstream names (label_code/label_polarity).
    Filters by polarity whitelist and caps at _MAX_LABELS_PER_REVIEW by confidence.
    """
    raw = review.get("analysis_labels") or "[]"
    if isinstance(raw, str):
        try:
            items = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return []
    else:
        items = raw

    if not isinstance(items, list):
        return []

    validated = []
    for item in items:
        if not isinstance(item, dict):
            continue
        code = item.get("code", "")
        polarity = item.get("polarity", "")
        allowed = _POLARITY_WHITELIST.get(code)
        if not allowed or polarity not in allowed:
            continue
        validated.append({
            "label_code": code,
            "label_polarity": polarity,
            "severity": item.get("severity", "low"),
            "confidence": item.get("confidence", 0.5),
            "source": "llm",
            "taxonomy_version": TAXONOMY_VERSION,
        })

    validated.sort(key=lambda l: -l["confidence"])
    return validated[:_MAX_LABELS_PER_REVIEW]


def sync_review_labels(snapshot):
    all_labels = {}
    for review in snapshot.get("reviews") or []:
        review_id = _review_id(review)
        if not review_id:
            continue

        # Primary: validated LLM labels
        labels = _extract_validated_llm_labels(review)

        if not labels:
            # Fallback: rule-based classification
            labels = classify_review_labels(review)

        models.replace_review_issue_labels(review_id, labels)
        all_labels[review_id] = labels

    # Keep hybrid branch for future use (currently no-op)
    if config.REPORT_LABEL_MODE == "hybrid" and all_labels:
        sample_review_ids = [rid for rid, labels in all_labels.items() if labels][:20]
        normalized_labels = _maybe_normalize_labels_with_llm(
            {rid: all_labels[rid] for rid in sample_review_ids}
        )
        for rid in sample_review_ids:
            llm_labels = _sanitize_hybrid_labels(all_labels[rid], normalized_labels.get(rid))
            if llm_labels:
                models.replace_review_issue_labels(rid, llm_labels)

    persisted = models.list_review_issue_labels(list(all_labels))
    for review_id, labels in all_labels.items():
        if not persisted.get(review_id):
            persisted[review_id] = labels
    return persisted


def _build_labeled_reviews(snapshot, synced_labels=None):
    products = _group_products(snapshot.get("products") or [])
    labeled_reviews = []
    for review in snapshot.get("reviews") or []:
        product_key = _product_key(review.get("product_name"), review.get("product_sku"))
        product = products.get(product_key, {})
        # Use synced labels if available, otherwise classify
        review_id = _review_id(review)
        if synced_labels and review_id and review_id in synced_labels:
            labels = synced_labels[review_id]
        else:
            labels = classify_review_labels(review)
        labeled_reviews.append(
            {
                "review": review,
                "labels": labels,
                "product": product,
                "images": _review_images(review),
            }
        )
    return labeled_reviews


def _cluster_summary_items(labeled_reviews, *, ownership, polarity):
    grouped = {}
    for item in labeled_reviews:
        review = item["review"]
        if review.get("ownership") != ownership:
            continue
        for label in item["labels"]:
            if label["label_polarity"] != polarity:
                continue
            cluster = grouped.setdefault(
                label["label_code"],
                {
                    "label_code": label["label_code"],
                    "label_polarity": label["label_polarity"],
                    "review_count": 0,
                    "image_review_count": 0,
                    "severity": label["severity"],
                    "severity_score": _SEVERITY_SCORE[label["severity"]],
                    "example_reviews": [],
                    "affected_products": set(),
                    "dates": [],
                },
            )
            cluster["review_count"] += 1
            cluster["affected_products"].add(review.get("product_sku") or review.get("product_name"))
            pub_date = review.get("date_published_parsed") or review.get("date_published")
            if pub_date:
                cluster["dates"].append(pub_date)
            if item["images"]:
                cluster["image_review_count"] += 1
            cluster["severity_score"] = max(cluster["severity_score"], _SEVERITY_SCORE[label["severity"]])
            if _SEVERITY_SCORE[label["severity"]] > _SEVERITY_SCORE[cluster["severity"]]:
                cluster["severity"] = label["severity"]
            if len(cluster["example_reviews"]) < 3:
                cluster["example_reviews"].append(
                    {
                        "product_name": review.get("product_name"),
                        "product_sku": review.get("product_sku"),
                        "author": review.get("author"),
                        "rating": review.get("rating"),
                        "headline": review.get("headline"),
                        "body": review.get("body"),
                        "headline_cn": review.get("headline_cn"),
                        "body_cn": review.get("body_cn"),
                        "headline_en": review.get("headline", ""),
                        "body_en": review.get("body", ""),
                        "date_published": review.get("date_published", ""),
                        "images": item["images"],
                    }
                )

    items = list(grouped.values())
    items.sort(
        key=lambda item: (
            -item["review_count"],
            -item["severity_score"],
            -item["image_review_count"],
            item["label_code"],
        )
    )
    from qbu_crawler.server.report_common import _LABEL_DISPLAY

    for item in items:
        item.pop("severity_score")
        from qbu_crawler.server.report_common import _SEVERITY_DISPLAY
        item["label_display"] = _LABEL_DISPLAY.get(item["label_code"], item["label_code"])
        item["severity_display"] = _SEVERITY_DISPLAY.get(item["severity"], item["severity"])
        item["affected_product_count"] = len(item.pop("affected_products"))
        dates = item.pop("dates")
        sorted_dates = sorted(dates, key=_date_sort_key)
        item["first_seen"] = sorted_dates[0] if sorted_dates else None
        item["last_seen"] = sorted_dates[-1] if sorted_dates else None
        item["review_dates"] = sorted_dates  # needed by compute_cluster_severity recency factor
    return items


# F011 H6/H10 — unified denominator threshold
LOW_COVERAGE_THRESHOLD = 0.5  # ingested/site < 50% → surface warning

# F011 H11/H18 — 5-factor risk score constants
HIGH_RISK_THRESHOLD = 35.0
NEAR_HIGH_RISK_FACTOR = 0.85
RISK_WEIGHTS = {
    "neg_rate": 0.35,
    "severity": 0.25,
    "evidence": 0.15,
    "recency": 0.15,
    "volume": 0.10,
}


def is_near_high_risk(score: float | None, *, threshold: float = HIGH_RISK_THRESHOLD) -> bool:
    """F011 H18 — score in band [NEAR_HIGH_RISK_FACTOR * threshold, threshold) → True."""
    if score is None:
        return False
    return NEAR_HIGH_RISK_FACTOR * threshold <= score < threshold


def compute_risk_score(product: dict, *, threshold: float = HIGH_RISK_THRESHOLD) -> dict:
    """Compute risk score with 5-factor breakdown (F011 H6/H10/H11/H18).

    Args:
        product: dict with ingested_count, review_count, negative_review_count,
                 and optionally high_severity_count, image_evidence_count,
                 recent_negative_count, total_volume (default 0).

    Returns dict with:
      Task 2.1 keys:
        neg_rate, coverage, low_coverage_warning
      Task 2.2 keys:
        risk_score (pct, 1 dp), risk_factors (5-key breakdown or None),
        near_high_risk (bool).
    """
    ingested = int(product.get("ingested_count", 0) or 0)
    site = int(product.get("review_count", 0) or 0)
    ratings_only = int(product.get("ratings_only_count", 0) or 0)
    text_total = max(0, site - ratings_only)  # scraper 物理上能抓到的文字评论数
    neg = int(product.get("negative_review_count", 0) or 0)

    if ingested == 0:
        return {
            "neg_rate": None,
            "coverage": None,
            # 业务口径：分析样本占总反馈的比例（含 ratings-only），代表分析覆盖度
            "text_sample_share": None,
            # 运维口径：scraper 抓到的文字 / 物理上能抓的文字，代表爬虫健康
            "scrape_completeness": None,
            "low_coverage_warning": site > 0,
            "risk_score": None,
            "risk_factors": None,
            "near_high_risk": False,
        }

    neg_rate = neg / ingested
    # ⚠ 命名规则（与用户 2026-04 拍板）：
    # - text_sample_share (= ingested / review_count)：业务侧，反映"文字样本占总反馈比"
    #   ratings-only 是真实消费者反馈，他们的态度可能与文字写手不同，低占比 = 分析有盲区
    # - scrape_completeness (= ingested / text_total)：运维侧，反映"爬虫抓全率"
    #   稳定状态应 ≈ 100%；任何明显小于 1 都是 scraper 异常信号
    # 风险评分用 text_sample_share 触发 low_coverage_warning，因为分析代表性低 = 风险
    text_sample_share = (ingested / site) if site > 0 else 1.0
    scrape_completeness = (ingested / text_total) if text_total > 0 else 1.0
    low_coverage_warning = (site > 0) and (text_sample_share < LOW_COVERAGE_THRESHOLD)

    high_sev = int(product.get("high_severity_count", 0) or 0)
    image_ev = int(product.get("image_evidence_count", 0) or 0)
    recent = int(product.get("recent_negative_count", 0) or 0)
    total_vol = int(product.get("total_volume", 0) or 0)

    neg_max = max(neg, 1)  # avoid /0 for denominators of factor 2/3/4
    factors_raw = {
        "neg_rate": neg_rate,
        "severity": high_sev / neg_max,
        "evidence": image_ev / neg_max,
        "recency":  recent / neg_max,
        "volume":   min(total_vol / 100.0, 1.0),
    }

    factors = {}
    score_raw = 0.0
    for key, weight in RISK_WEIGHTS.items():
        raw = factors_raw[key]
        weighted = raw * weight
        factors[key] = {
            "raw": round(raw, 4),
            "weight": weight,
            "weighted": round(weighted, 4),
        }
        score_raw += weighted

    score_pct = round(score_raw * 100, 1)

    return {
        "neg_rate": neg_rate,
        # `coverage` 保留为兼容别名 = text_sample_share（业务口径），
        # 老调用方读到 0.7 时含义和以前一样（ingested / review_count）
        "coverage": text_sample_share,
        "text_sample_share": text_sample_share,
        "scrape_completeness": scrape_completeness,
        "low_coverage_warning": low_coverage_warning,
        "risk_score": score_pct,
        "risk_factors": factors,
        "near_high_risk": is_near_high_risk(score_pct, threshold=threshold),
    }


def build_product_overview_rows(products: list) -> list:
    """Build dual-column rows for the Excel '产品概览' sheet (F011 H10).

    Each row exposes BOTH rates so the reader sees site vs ingested explicitly:
    `negative_rate_ingested` (primary) + `negative_rate_site` (sanity-check) +
    `coverage` (ingested / site).

    Returns: list of dicts with keys
      name, site_count, ingested_count, coverage,
      negative_count, negative_rate_ingested, negative_rate_site
    """
    rows = []
    for p in products:
        ingested = int(p.get("ingested_count", 0) or 0)
        site = int(p.get("review_count", 0) or 0)
        ratings_only = int(p.get("ratings_only_count", 0) or 0)
        text_total = max(0, site - ratings_only)
        neg = int(p.get("negative_review_count", 0) or 0)
        rows.append({
            "name": p.get("name"),
            "site_count": site,
            "ratings_only_count": ratings_only,
            "text_review_count": text_total,
            "ingested_count": ingested,
            # 业务口径：分析样本占总反馈比例（含 ratings-only）
            "text_sample_share": (ingested / site) if site > 0 else None,
            # 运维口径：scraper 抓全文字评论的健康度，正常应 ≈ 1.0
            "scrape_completeness": (ingested / text_total) if text_total > 0 else None,
            # 兼容别名：coverage 保留 = text_sample_share（旧业务口径）
            "coverage": (ingested / site) if site > 0 else None,
            "negative_count": neg,
            "negative_rate_ingested": (neg / ingested) if ingested > 0 else None,
            "negative_rate_site": (neg / site) if site > 0 else None,
        })
    return rows


def _risk_products(labeled_reviews, snapshot_products=None, logical_date=None):
    """Compute per-product risk scores using a 5-factor weighted algorithm.

    Factors (weights):
      neg_rate    (35%): negative reviews / total reviews (site-reported)
      severity    (25%): average severity of negative reviews, normalised 0–1
      evidence    (15%): image-bearing negatives / total negatives
      recency     (15%): proportion of negatives from last 90 days
      volume_sig  (10%): min(neg_count / 10, 1.0) — statistical significance

    A review is "negative" when rating <= config.NEGATIVE_THRESHOLD (default 2).
    Reviews without labels still count toward neg_rate.
    """
    from qbu_crawler.server.report_common import _join_label_counts, _parse_date_flexible

    # Reference date for recency calculation
    if logical_date:
        try:
            ref_date = date.fromisoformat(logical_date) if isinstance(logical_date, str) else logical_date
        except (ValueError, TypeError):
            ref_date = date.today()
    else:
        ref_date = date.today()
    recency_window = timedelta(days=90)

    # Severity weights for the severity factor (normalised against max = "critical")
    max_severity_score = float(_SEVERITY_SCORE.get("critical", max(_SEVERITY_SCORE.values())))

    sku_to_review_count = {}
    sku_to_rating = {}
    sku_to_ratings_only = {}  # 用于 coverage 分母扣减
    for p in (snapshot_products or []):
        sku = p.get("sku") or ""
        sku_to_review_count[sku] = p.get("review_count") or 0
        sku_to_rating[sku] = p.get("rating")
        sku_to_ratings_only[sku] = p.get("ratings_only_count") or 0

    # First pass: group ALL own reviews by SKU
    by_sku = {}
    for item in labeled_reviews:
        review = item["review"]
        if review.get("ownership") != "own":
            continue
        sku = review.get("product_sku", "")
        if not sku:
            continue
        entry = by_sku.setdefault(sku, {
            "product_name": review.get("product_name"),
            "product_sku": sku,
            "all_items": [],
            "negative_items": [],
            "image_negative_count": 0,
            "top_labels": {},
        })
        entry["all_items"].append(item)
        rating = float(review.get("rating") or 0)
        if rating <= config.NEGATIVE_THRESHOLD:
            entry["negative_items"].append(item)
            if item.get("images"):
                entry["image_negative_count"] += 1
            for label in item.get("labels", []):
                if label.get("label_polarity") == "negative":
                    lc = label["label_code"]
                    entry["top_labels"][lc] = entry["top_labels"].get(lc, 0) + 1

    # Second pass: compute 5-factor score per SKU
    items = []
    for sku, entry in by_sku.items():
        all_count = len(entry["all_items"])
        neg_items = entry["negative_items"]
        neg_count = len(neg_items)
        total_reviews = sku_to_review_count.get(sku, 0)

        # ── factor 1: neg_rate (35%) ──────────────────────────────
        # F011 H6: denominator unified to ingested-only.
        # Zero-scrape SKUs are skipped here; scrape_quality alerting covers them.
        if all_count == 0:
            continue
        factors = compute_risk_score({
            "ingested_count": all_count,
            "review_count": total_reviews,
            "ratings_only_count": sku_to_ratings_only.get(sku, 0),
            "negative_review_count": neg_count,
        })
        neg_rate = factors["neg_rate"]
        coverage = factors["coverage"]
        low_coverage_warning = factors["low_coverage_warning"]

        if neg_count == 0:
            risk_score_raw = 0.0
        else:
            # ── factor 2: severity_avg (25%) ─────────────────────
            # Per-review-max: take max severity per review, normalise, then average
            severity_scores = []
            for neg_item in neg_items:
                neg_labels = [l for l in neg_item.get("labels", []) if l.get("label_polarity") == "negative"]
                if neg_labels:
                    max_sev = max(_SEVERITY_SCORE.get(l.get("severity", "low"), 1) for l in neg_labels)
                else:
                    max_sev = 2 if float(neg_item["review"].get("rating", 0)) <= 1 else 1
                severity_scores.append(max_sev / max_severity_score)
            severity_avg = sum(severity_scores) / len(severity_scores) if severity_scores else 0.0

            # ── factor 3: evidence_rate (15%) ────────────────────
            evidence_rate = entry["image_negative_count"] / neg_count

            # ── factor 4: recency (15%) ──────────────────────────
            recent_neg = 0
            for neg_item in neg_items:
                review = neg_item["review"]
                raw_parsed = review.get("date_published_parsed")
                pub_date = _parse_date_flexible(raw_parsed) if raw_parsed else None
                if pub_date is None:
                    pub_date = _parse_date_flexible(review.get("date_published"))
                if pub_date and (ref_date - pub_date) <= recency_window:
                    recent_neg += 1
            recency = recent_neg / neg_count

            # ── factor 5: volume_sig (10%) ───────────────────────
            volume_sig = min(neg_count / 10.0, 1.0)

            # ── weighted combination ──────────────────────────────
            risk_score_raw = (
                0.35 * neg_rate
                + 0.25 * severity_avg
                + 0.15 * evidence_rate
                + 0.15 * recency
                + 0.10 * volume_sig
            )

        risk_score = round(min(risk_score_raw, 1.0) * 100, 1)

        label_counts = entry["top_labels"]
        top_labels = [
            {"label_code": code, "count": count}
            for code, count in sorted(label_counts.items(), key=lambda pair: (-pair[1], pair[0]))
        ]

        ingested = all_count
        negative_review_rows = neg_count
        image_review_rows = entry["image_negative_count"]

        items.append({
            "product_name": entry["product_name"],
            "product_sku": sku,
            "negative_review_rows": negative_review_rows,
            "image_review_rows": image_review_rows,
            "risk_score_raw": risk_score_raw,
            "risk_score": risk_score,
            "total_reviews": total_reviews,
            "ingested_reviews": ingested,
            "rating_avg": sku_to_rating.get(sku),
            "negative_rate": neg_count / all_count,                              # backward-compat alias (now ingested-based, F011 H6)
            "negative_rate_ingested": neg_count / all_count,                     # F011 H6 explicit
            # negative_rate_site / coverage_rate 仍用 site_total（业务/分析口径）：
            # ratings-only 也是消费者反馈，业务侧不应把它从分母里去掉
            "negative_rate_site": (neg_count / total_reviews) if total_reviews > 0 else None,
            "coverage_rate": ingested / total_reviews if total_reviews else None,
            # 新增运维口径：scraper 抓全文字评论的健康度，正常应 ≈ 1.0
            "scrape_completeness": (
                ingested / max(0, total_reviews - sku_to_ratings_only.get(sku, 0))
                if max(0, total_reviews - sku_to_ratings_only.get(sku, 0)) > 0 else None
            ),
            "ratings_only_count": sku_to_ratings_only.get(sku, 0),
            "low_coverage_warning": low_coverage_warning,
            "top_labels": top_labels,
            "top_features_display": _join_label_counts(top_labels),
        })

    items.sort(
        key=lambda item: (
            -item["risk_score"],
            -item["negative_review_rows"],
            -item["image_review_rows"],
            item["product_sku"] or "",
        )
    )
    # Exclude zero-risk products (no negative reviews) from output
    items = [item for item in items if item["risk_score"] > 0]
    return items


# F011 §4.2.3 — Product status lamps
# ─────────────────────────────────────────────────────────────────────────
# Returns ALL own products (including healthy/no-data ones) classified by
# four lamp states. The HTML attachment renders this as 灯 + 一句原因.
# Detailed risk_score / risk_factors live in the hover tooltip only.
_STATUS_LABEL_MAP = {
    "green": "健康",
    "yellow": "需关注",
    "red": "高风险",
    "gray": "无数据",
}


def _product_status(labeled_reviews, snapshot_products=None, logical_date=None):
    """Build per-product status-lamp records for ALL own products.

    F011 §4.2.3 lamp rules:
      🔴 red:    risk_score >= HIGH_RISK_THRESHOLD (35)
      🟡 yellow: 0.85 * threshold <= risk_score < threshold
                 OR has any negative review (negative_review_count >= 1)
      🟢 green:  no negative AND risk_score < 0.85 * threshold
      ⚪ gray:   ingested_reviews == 0 (no data)

    primary_concern:
      - red/yellow → top-1 (or top-2 joined with " + ") negative label_display
      - green/gray → ""
    """
    from qbu_crawler.server.report_common import _LABEL_DISPLAY, _parse_date_flexible

    if logical_date:
        try:
            ref_date = date.fromisoformat(logical_date) if isinstance(logical_date, str) else logical_date
        except (ValueError, TypeError):
            ref_date = date.today()
    else:
        ref_date = date.today()
    recency_window = timedelta(days=90)
    max_severity_score = float(_SEVERITY_SCORE.get("critical", max(_SEVERITY_SCORE.values())))

    # Pre-build per-SKU site-stats from snapshot_products
    site_review_count = {}
    site_rating = {}
    own_skus_from_products = []
    sku_to_name = {}
    for p in (snapshot_products or []):
        sku = p.get("sku") or ""
        if not sku:
            continue
        site_review_count[sku] = p.get("review_count") or 0
        site_rating[sku] = p.get("rating")
        sku_to_name[sku] = p.get("name") or p.get("product_name")
        # Treat as own when explicit ownership=='own' OR no ownership column
        # (legacy products without ownership default to own scope; gating below
        # filters out competitor products since they won't appear in own-review aggregation).
        if (p.get("ownership") or "own") == "own":
            own_skus_from_products.append(sku)

    # Aggregate reviews per own SKU
    by_sku = {}
    for item in labeled_reviews:
        review = item["review"]
        if review.get("ownership") != "own":
            continue
        sku = review.get("product_sku") or ""
        if not sku:
            continue
        entry = by_sku.setdefault(sku, {
            "product_name": review.get("product_name"),
            "product_sku": sku,
            "all_items": [],
            "negative_items": [],
            "image_negative_count": 0,
            "neg_label_counts": {},
        })
        entry["all_items"].append(item)
        rating = float(review.get("rating") or 0)
        if rating <= config.NEGATIVE_THRESHOLD:
            entry["negative_items"].append(item)
            if item.get("images"):
                entry["image_negative_count"] += 1
            for label in item.get("labels", []):
                if label.get("label_polarity") == "negative":
                    lc = label["label_code"]
                    entry["neg_label_counts"][lc] = entry["neg_label_counts"].get(lc, 0) + 1

    # Union of SKUs: those with reviews + those declared own in snapshot_products
    all_skus = set(by_sku.keys()) | set(own_skus_from_products)

    records = []
    near_high_threshold = 0.85 * HIGH_RISK_THRESHOLD  # 29.75

    for sku in all_skus:
        entry = by_sku.get(sku)
        ingested = len(entry["all_items"]) if entry else 0
        product_name = (entry["product_name"] if entry else None) or sku_to_name.get(sku)

        # Gray: zero ingested
        if ingested == 0:
            records.append({
                "product_name": product_name,
                "product_sku": sku,
                "status_lamp": "gray",
                "status_label": _STATUS_LABEL_MAP["gray"],
                "primary_concern": "",
                "risk_score": 0.0,
                "risk_factors": None,
                "near_high_risk": False,
            })
            continue

        neg_items = entry["negative_items"]
        neg_count = len(neg_items)
        total_reviews = site_review_count.get(sku, 0)

        factors = compute_risk_score({
            "ingested_count": ingested,
            "review_count": total_reviews,
            "negative_review_count": neg_count,
        })
        neg_rate = factors["neg_rate"]

        if neg_count == 0:
            risk_score = 0.0
            risk_factors = None
        else:
            severity_scores = []
            for neg_item in neg_items:
                neg_labels = [l for l in neg_item.get("labels", []) if l.get("label_polarity") == "negative"]
                if neg_labels:
                    max_sev = max(_SEVERITY_SCORE.get(l.get("severity", "low"), 1) for l in neg_labels)
                else:
                    max_sev = 2 if float(neg_item["review"].get("rating", 0)) <= 1 else 1
                severity_scores.append(max_sev / max_severity_score)
            severity_avg = sum(severity_scores) / len(severity_scores) if severity_scores else 0.0
            evidence_rate = entry["image_negative_count"] / neg_count

            recent_neg = 0
            for neg_item in neg_items:
                review = neg_item["review"]
                raw_parsed = review.get("date_published_parsed")
                pub_date = _parse_date_flexible(raw_parsed) if raw_parsed else None
                if pub_date is None:
                    pub_date = _parse_date_flexible(review.get("date_published"))
                if pub_date and (ref_date - pub_date) <= recency_window:
                    recent_neg += 1
            recency = recent_neg / neg_count
            volume_sig = min(neg_count / 10.0, 1.0)

            risk_score_raw = (
                0.35 * neg_rate
                + 0.25 * severity_avg
                + 0.15 * evidence_rate
                + 0.15 * recency
                + 0.10 * volume_sig
            )
            risk_score = round(min(risk_score_raw, 1.0) * 100, 1)
            risk_factors = {
                "neg_rate": round(neg_rate, 4),
                "severity": round(severity_avg, 4),
                "evidence": round(evidence_rate, 4),
                "recency": round(recency, 4),
                "volume_sig": round(volume_sig, 4),
            }

        # Lamp classification
        if risk_score >= HIGH_RISK_THRESHOLD:
            lamp = "red"
        elif risk_score >= near_high_threshold or neg_count >= 1:
            lamp = "yellow"
        else:
            lamp = "green"

        # primary_concern: top-1 (or top-2 joined) negative label_display
        if lamp in ("yellow", "red"):
            top_codes = sorted(
                entry["neg_label_counts"].items(),
                key=lambda pair: (-pair[1], pair[0]),
            )[:2]
            display_parts = [_LABEL_DISPLAY.get(code, code) for code, _ in top_codes]
            primary_concern = " + ".join(display_parts) if display_parts else ""
        else:
            primary_concern = ""

        records.append({
            "product_name": product_name,
            "product_sku": sku,
            "status_lamp": lamp,
            "status_label": _STATUS_LABEL_MAP[lamp],
            "primary_concern": primary_concern,
            "risk_score": risk_score,
            "risk_factors": risk_factors,
            "near_high_risk": is_near_high_risk(risk_score),
        })

    # Sort: red > yellow > green > gray, then by risk_score desc, sku
    lamp_order = {"red": 0, "yellow": 1, "green": 2, "gray": 3}
    records.sort(key=lambda r: (
        lamp_order.get(r["status_lamp"], 4),
        -(r.get("risk_score") or 0.0),
        r.get("product_sku") or "",
    ))
    return records


def _build_label_options(labeled_reviews):
    """F011 §4.2.6 — label codes actually present in labeled_reviews,
    sorted by frequency desc, for panorama label filter dropdown.
    """
    from qbu_crawler.server.report_common import _LABEL_DISPLAY

    counts = {}
    for item in labeled_reviews:
        for label in item.get("labels", []) or []:
            code = label.get("label_code")
            if not code:
                continue
            counts[code] = counts.get(code, 0) + 1
    sorted_codes = sorted(counts.items(), key=lambda pair: (-pair[1], pair[0]))
    return [
        {"code": code, "display": _LABEL_DISPLAY.get(code, code)}
        for code, _ in sorted_codes
    ]


def _recommendations(top_negative_clusters):
    items = []
    for cluster in top_negative_clusters[:5]:
        content = _RECOMMENDATION_MAP.get(cluster["label_code"])
        if not content:
            continue

        # Extract concrete evidence from example reviews
        examples = cluster.get("example_reviews") or []
        top_complaint = ""
        affected_products = []
        seen_products = set()
        for ex in examples:
            if not top_complaint:
                top_complaint = (
                    (ex.get("headline_cn") or ex.get("headline") or "")
                    + "："
                    + (ex.get("body_cn") or ex.get("body") or "")
                ).strip().rstrip("：")[:120]
            pname = ex.get("product_name") or ""
            if pname and pname not in seen_products:
                seen_products.add(pname)
                affected_products.append(pname)

        # Use top sub_features for product-specific actionable detail
        sub_features = cluster.get("sub_features") or []
        top_symptoms = "、".join(
            sf["feature"] for sf in sub_features[:5] if sf.get("feature")
        )

        items.append(
            {
                "label_code": cluster["label_code"],
                "priority": "high" if cluster["severity"] == "high" else "medium",
                "possible_cause_boundary": content["possible_cause_boundary"],
                "improvement_direction": content["improvement_direction"],
                "top_symptoms": top_symptoms,
                "evidence_count": cluster["review_count"],
                "top_complaint": top_complaint,
                "affected_products": affected_products[:3],
            }
        )
    return items


def _benchmark_examples(labeled_reviews):
    grouped = {
        "product_design": [],
        "marketing_message": [],
        "service_model": [],
    }

    def _category(codes):
        if any(code in {"service_fulfillment", "easy_to_clean"} for code in codes):
            return "service_model"
        if any(code in {"good_value", "good_packaging"} for code in codes):
            return "marketing_message"
        return "product_design"

    for item in labeled_reviews:
        review = item["review"]
        if review.get("ownership") != "competitor":
            continue
        positive_labels = [label["label_code"] for label in item["labels"] if label["label_polarity"] == "positive"]
        if not positive_labels:
            continue
        category = _category(positive_labels)
        grouped[category].append(
            {
                "review_id": review.get("id"),
                "product_name": review.get("product_name"),
                "product_sku": review.get("product_sku"),
                "author": review.get("author"),
                "rating": review.get("rating"),
                "headline": review.get("headline"),
                "body": review.get("body"),
                "headline_cn": review.get("headline_cn"),
                "body_cn": review.get("body_cn"),
                "label_codes": positive_labels,
            }
        )
    for key, items in grouped.items():
        items.sort(key=lambda item: (-(item["rating"] or 0), len(item["label_codes"]) * -1, item["product_sku"] or ""))
        grouped[key] = items[:3]
    return grouped


# ── F011 §4.2.7 v1.2 — weakness opportunities (scoped) ──────────────────
WEAKNESS_OPP_MIN_COMPETITOR_COMPLAINTS = 3
WEAKNESS_OPP_MIN_OUR_POSITIVE = 10


def _generate_advantage_direction(label_code: str) -> str:
    """Rule-based advantage direction copy.

    LLM enhancement deferred to F011 v1.3 follow-up; this stub keeps the
    schema stable so downstream consumers can render copy today.
    """
    from qbu_crawler.server.report_common import _LABEL_DISPLAY
    label_zh = _LABEL_DISPLAY.get(label_code, label_code)
    return f"我方 {label_zh} 差异化"


def _build_weakness_opportunities(labeled_reviews) -> list[dict]:
    """F011 §4.2.7 v1.2 — Top 3 competitor negative labels mapped to our positive advantages.

    Conditions (both must hold for a label to qualify):
      - competitor.negative_count[label] >= ``WEAKNESS_OPP_MIN_COMPETITOR_COMPLAINTS``
      - own.positive_count[label] >= ``WEAKNESS_OPP_MIN_OUR_POSITIVE``
    """
    from qbu_crawler.server.report_common import _LABEL_DISPLAY

    own_label_stats: dict[str, dict] = {}
    comp_label_stats: dict[str, dict] = {}
    for item in labeled_reviews:
        review = item.get("review") or {}
        ownership = review.get("ownership") or "competitor"
        target = own_label_stats if ownership == "own" else comp_label_stats
        product_name = review.get("product_name") or ""
        for label in item.get("labels") or []:
            code = label.get("label_code")
            if not code:
                continue
            stats = target.setdefault(code, {
                "positive_count": 0,
                "negative_count": 0,
                "total": 0,
                "products": set(),
            })
            polarity = label.get("label_polarity")
            if polarity == "positive":
                stats["positive_count"] += 1
            elif polarity == "negative":
                stats["negative_count"] += 1
            stats["total"] += 1
            if product_name:
                stats["products"].add(product_name)

    eligible_comp = [
        (code, stats) for code, stats in comp_label_stats.items()
        if stats["negative_count"] >= WEAKNESS_OPP_MIN_COMPETITOR_COMPLAINTS
    ]
    eligible_comp.sort(key=lambda kv: kv[1]["negative_count"], reverse=True)

    opportunities = []
    for code, comp_stats in eligible_comp:
        if len(opportunities) >= 3:
            break
        our_stats = own_label_stats.get(code, {})
        our_positive = our_stats.get("positive_count", 0)
        if our_positive < WEAKNESS_OPP_MIN_OUR_POSITIVE:
            continue
        opportunities.append({
            "competitor_complaint_theme": code,
            "competitor_complaint_display": _LABEL_DISPLAY.get(code, code),
            "competitor_evidence_count": comp_stats["negative_count"],
            "competitor_products_affected": sorted(comp_stats["products"]),
            "our_advantage_label": code,
            "our_positive_count": our_positive,
            "our_advantage_direction": _generate_advantage_direction(code),
        })
    return opportunities


def _negative_opportunities(labeled_reviews):
    items = []
    for item in labeled_reviews:
        review = item["review"]
        if review.get("ownership") != "competitor":
            continue
        negative_labels = [label["label_code"] for label in item["labels"] if label["label_polarity"] == "negative"]
        if not negative_labels:
            continue
        items.append(
            {
                "product_name": review.get("product_name"),
                "product_sku": review.get("product_sku"),
                "rating": review.get("rating"),
                "headline": review.get("headline"),
                "headline_cn": review.get("headline_cn"),
                "body": review.get("body"),
                "body_cn": review.get("body_cn"),
                "label_codes": negative_labels,
            }
        )
    items.sort(key=lambda item: ((item["rating"] or 5), item["product_sku"] or ""))
    return items[:5]


def _select_diverse_examples(reviews, max_count=3):
    """Select diverse example reviews: lowest-rated + with-image + mid-range."""
    if len(reviews) <= max_count:
        return sorted(reviews, key=lambda r: r.get("rating", 5))

    selected = []
    remaining = list(reviews)

    # 1. Lowest rated
    remaining.sort(key=lambda r: r.get("rating", 5))
    selected.append(remaining.pop(0))

    # 2. Prefer one with images (if not already selected)
    img_candidates = [r for r in remaining if r.get("images")]
    if img_candidates:
        pick = min(img_candidates, key=lambda r: r.get("rating", 5))
        selected.append(pick)
        remaining.remove(pick)
    elif remaining:
        selected.append(remaining.pop(0))

    # 3. Highest-rated among remaining (for diversity)
    if remaining and len(selected) < max_count:
        pick = max(remaining, key=lambda r: r.get("rating", 5))
        selected.append(pick)

    return selected[:max_count]


def _build_feature_clusters(reviews_with_analysis, ownership="own", polarity="negative"):
    """Aggregate reviews into clusters grouped by ``label_code``.

    Instead of clustering by free-text feature strings (which creates 100+
    fragmented clusters), this groups reviews by their primary
    ``analysis_labels[].code`` — a fixed 14-code taxonomy.  Original feature
    strings are preserved in ``sub_features``.

    Reviews whose labels have no ``code`` matching the target *polarity* fall
    into the ``_uncategorized`` bucket.
    """
    from collections import defaultdict
    from qbu_crawler.server.report_common import _LABEL_DISPLAY, _SEVERITY_DISPLAY

    clusters = defaultdict(lambda: {
        "reviews": [],
        "products": set(),
        "product_names": set(),
        "severities": [],
        "sub_features": defaultdict(int),
    })

    for r in reviews_with_analysis:
        if r.get("ownership") != ownership:
            continue
        sentiment = r.get("sentiment") or ""
        if polarity == "negative" and sentiment not in ("negative", "mixed"):
            continue
        if polarity == "positive" and sentiment not in ("positive", "mixed"):
            continue

        raw_features = r.get("analysis_features") or r.get("features") or "[]"
        raw_labels = r.get("analysis_labels") or r.get("labels") or "[]"
        features = json.loads(raw_features) if isinstance(raw_features, str) else raw_features
        labels = json.loads(raw_labels) if isinstance(raw_labels, str) else raw_labels

        if not features:
            continue

        # Find primary label_code: highest-confidence label matching target polarity
        # Also validates against _POLARITY_WHITELIST to reject LLM mis-assignments
        # (e.g., strong_performance/negative — strong_performance is positive-only)
        primary_code = None
        primary_severity = "low"
        best_confidence = -1.0
        for label in labels:
            if not isinstance(label, dict):
                continue
            code = label.get("code") or label.get("label_code")
            lab_polarity = label.get("polarity") or label.get("label_polarity")
            if not code:
                continue
            if lab_polarity and lab_polarity != polarity:
                continue
            # Reject codes that don't belong to the target polarity per taxonomy
            allowed = _POLARITY_WHITELIST.get(code)
            if allowed and polarity not in allowed:
                continue
            confidence = label.get("confidence", 0.0)
            if confidence > best_confidence:
                best_confidence = confidence
                primary_code = code
                primary_severity = label.get("severity", "low")

        # Fallback: if no polarity-matching label found, use _uncategorized
        if not primary_code:
            primary_code = "_uncategorized"
            # Still extract max severity from all labels
            for label in labels:
                if isinstance(label, dict):
                    sev = label.get("severity", "low")
                    if _SEVERITY_SCORE.get(sev, 0) > _SEVERITY_SCORE.get(primary_severity, 0):
                        primary_severity = sev

        bucket = clusters[primary_code]
        bucket["reviews"].append(r)
        bucket["products"].add(r.get("product_sku") or r.get("product_name", ""))
        bucket["product_names"].add(r.get("product_name") or "")
        bucket["severities"].append(primary_severity)

        for feat in features:
            feat = feat.strip() if isinstance(feat, str) else str(feat)
            if feat:
                bucket["sub_features"][feat] += 1

    from collections import Counter

    result = []
    for code, data in clusters.items():
        reviews = data["reviews"]
        dates = [r.get("date_published_parsed") or r.get("date_published") for r in reviews if r.get("date_published_parsed") or r.get("date_published")]
        max_sev = max(data["severities"], key=lambda s: _SEVERITY_SCORE.get(s, 0), default="low")
        display = _LABEL_DISPLAY.get(code, code)

        sub_features = [
            {"feature": feat, "count": cnt}
            for feat, cnt in sorted(data["sub_features"].items(), key=lambda x: -x[1])
        ]

        rating_counts = Counter(r.get("rating", 0) for r in reviews)

        translated = sum(1 for r in reviews if r.get("body_cn") or r.get("headline_cn"))

        result.append({
            "label_code": code,
            "feature_display": display,
            "label_display": display,
            "label_polarity": polarity,
            "review_count": len(reviews),
            "affected_product_count": len(data["products"]),
            "severity": max_sev,
            "severity_display": _SEVERITY_DISPLAY.get(max_sev, max_sev),
            "first_seen": sorted(dates, key=_date_sort_key)[0] if dates else None,
            "last_seen": sorted(dates, key=_date_sort_key)[-1] if dates else None,
            "example_reviews": _select_diverse_examples(reviews, max_count=3),
            "rating_breakdown": {f"{star}星": rating_counts.get(star, 0) for star in range(1, 6) if rating_counts.get(star, 0) > 0},
            "image_review_count": sum(1 for r in reviews if r.get("images")),
            "translated_rate": translated / max(len(reviews), 1),
            "sub_features": sub_features,
            "affected_products": sorted(data["product_names"] - {""})[:5],
            "review_dates": sorted(dates),
        })

    result.sort(key=lambda c: (
        -c["review_count"],
        -_SEVERITY_SCORE.get(c["severity"], 0),
        -c["image_review_count"],
    ))
    return result


def _has_review_analysis_data(reviews):
    """Check if any review in the snapshot has analysis_features populated."""
    for r in reviews:
        features = r.get("analysis_features") or r.get("features")
        if features and features != "[]":
            return True
    return False


def _compute_chart_data(labeled_reviews, snapshot):
    """Compute chart-specific analytics data for Plotly visualizations."""
    from qbu_crawler.server.report_common import _LABEL_DISPLAY

    # All label codes that appear in labeled reviews
    DIMENSIONS = list(set(
        label["label_code"]
        for item in labeled_reviews
        for label in item["labels"]
    ))
    if not DIMENSIONS:
        return {}

    result = {}

    # ── Radar data: own vs competitor using unified dimensions ─────
    from qbu_crawler.server.report_common import CODE_TO_DIMENSION

    # Phase 1: For each review, determine per-dimension polarity (negative wins)
    dim_pos = {"own": {}, "competitor": {}}
    dim_total = {"own": {}, "competitor": {}}

    for item in labeled_reviews:
        ownership = item["review"].get("ownership") or "competitor"
        if ownership not in ("own", "competitor"):
            ownership = "competitor"

        # Determine per-dimension polarity for this review
        dim_polarity = {}  # dim -> "positive" | "negative"
        for label in item["labels"]:
            dim = CODE_TO_DIMENSION.get(label["label_code"])
            if not dim:
                continue
            if dim not in dim_polarity:
                dim_polarity[dim] = label["label_polarity"]
            elif label["label_polarity"] == "negative":
                dim_polarity[dim] = "negative"  # negative wins

        # Phase 2: Count once per dimension
        for dim, polarity in dim_polarity.items():
            dim_total[ownership][dim] = dim_total[ownership].get(dim, 0) + 1
            if polarity == "positive":
                dim_pos[ownership][dim] = dim_pos[ownership].get(dim, 0) + 1

    # F011 §4.2.7.3 v1.2 — Top 6-8 aggregation: only dims with data from BOTH sides,
    # sorted by combined mention volume desc, capped at RADAR_MAX_CATEGORIES.
    RADAR_MAX_CATEGORIES = 8
    shared_dims = set(dim_total["own"]) & set(dim_total["competitor"])
    dims_with_total = [
        (d, dim_total["own"].get(d, 0) + dim_total["competitor"].get(d, 0))
        for d in shared_dims
    ]
    # Sort by total volume desc, tie-break alphabetically for determinism.
    dims_with_total.sort(key=lambda dt: (-dt[1], dt[0]))
    top_dims = [d for d, _ in dims_with_total[:RADAR_MAX_CATEGORIES]]

    if len(top_dims) >= 3:
        result["_radar_data"] = {
            "categories": top_dims,
            "own_values": [
                round(dim_pos["own"].get(d, 0) / max(dim_total["own"].get(d, 1), 1), 2)
                for d in top_dims
            ],
            "competitor_values": [
                round(dim_pos["competitor"].get(d, 0) / max(dim_total["competitor"].get(d, 1), 1), 2)
                for d in top_dims
            ],
        }

    # ── Sentiment distribution: split by ownership ─────────────────
    products = snapshot.get("products") or []
    for ownership_tag in ("own", "competitor"):
        product_names = []
        pos_counts = []
        neu_counts = []
        neg_counts = []
        for p in products:
            if p.get("ownership", "competitor") != ownership_tag:
                continue
            pname = p.get("name") or p.get("sku") or "?"
            psku = p.get("sku") or ""
            pos = neu = neg = 0
            for item in labeled_reviews:
                r = item["review"]
                if (r.get("product_sku") or "") == psku or (r.get("product_name") or "") == pname:
                    rating = float(r.get("rating") or 0)
                    if rating >= 4:
                        pos += 1
                    elif rating <= 2:
                        neg += 1
                    else:
                        neu += 1
            if pos + neu + neg > 0:
                product_names.append(pname[:20])
                pos_counts.append(pos)
                neu_counts.append(neu)
                neg_counts.append(neg)

        if len(product_names) >= 2:
            key = f"_sentiment_distribution_{ownership_tag}"
            result[key] = {
                "categories": product_names,
                "positive": pos_counts,
                "neutral": neu_counts,
                "negative": neg_counts,
            }

    # Display hints for templates consuming chart data
    result["_sentiment_chart_title"] = "评分分布"
    result["_sentiment_chart_legend"] = {
        "positive": "好评(≥4星)",
        "neutral": "中评(3星)",
        "negative": "差评(≤2星)",
    }

    # ── Heatmap (F011 §4.2.6.2 v1.2) ──────────────────
    # New data contract: x-axis aggregated to Top HEATMAP_MAX_LABELS-1 + "其他";
    # cells are dicts ({score, sample_size, color_class, top_review_id,
    # top_review_excerpt}) instead of bare floats. Charts that consumed the
    # old float `z` extract `cell["score"]` (None → treated as 0.0).
    heatmap_data = _build_heatmap_data_v12(labeled_reviews, products)
    if heatmap_data is not None:
        result["_heatmap_data"] = heatmap_data

    return result


# ── F011 §4.2.6.2 v1.2 — heatmap constants ──────────────────
HEATMAP_MAX_LABELS = 8
HEATMAP_MIN_SAMPLE = 3
HEATMAP_TOP_REVIEW_EXCERPT_LEN = 80


def _build_heatmap_data_v12(labeled_reviews, products):
    """F011 §4.2.6.2 v1.2 — Top-N label aggregation + per-cell top review.

    Returns dict with:
      x_labels         — display names, length <= HEATMAP_MAX_LABELS
      x_label_codes    — parallel list of canonical codes ("" for "其他")
      y_labels         — own product display names (smart-truncated)
      z                — list[list[dict]] (cell schema below)
      aggregated_labels — codes folded into "其他" bucket (empty if no overflow)

    Cell schema:
      {"score": float|None, "sample_size": int, "color_class": str,
       "top_review_id": int|None, "top_review_excerpt": str}

    Returns None if guard conditions fail (>= 2 own products + >= 2 dimensions).
    """
    from qbu_crawler.server.report_common import _LABEL_DISPLAY

    own_products = [p for p in products if p.get("ownership") == "own"]

    # Count label mentions across own reviews (each label_code per review counted once)
    label_mention_counts: dict[str, int] = {}
    for item in labeled_reviews:
        if item["review"].get("ownership") != "own":
            continue
        seen_codes_in_review: set[str] = set()
        for label in item["labels"]:
            code = label.get("label_code")
            if not code or code in seen_codes_in_review:
                continue
            seen_codes_in_review.add(code)
            label_mention_counts[code] = label_mention_counts.get(code, 0) + 1

    if len(own_products) < 2 or len(label_mention_counts) < 2:
        return None

    # Sort by mention count desc; deterministic tie-break by code
    sorted_codes = sorted(
        label_mention_counts.items(),
        key=lambda kv: (-kv[1], kv[0]),
    )
    top_codes = [code for code, _ in sorted_codes[:HEATMAP_MAX_LABELS - 1]]
    other_codes = [code for code, _ in sorted_codes[HEATMAP_MAX_LABELS - 1:]]

    x_label_codes = list(top_codes)
    x_labels = [_LABEL_DISPLAY.get(c, c) for c in top_codes]
    if other_codes:
        x_labels.append("其他")
        x_label_codes.append("")  # "其他" bucket maps to no single code

    # Group reviews by SKU for fast cell lookup
    reviews_by_sku: dict[str, list[dict]] = {}
    for item in labeled_reviews:
        r = item["review"]
        if r.get("ownership") != "own":
            continue
        psku = r.get("product_sku") or ""
        reviews_by_sku.setdefault(psku, []).append(item)

    bucket_codes: list[list[str]] = [[c] for c in top_codes]
    if other_codes:
        bucket_codes.append(other_codes)

    y_labels: list[str] = []
    y_items: list[dict] = []
    z: list[list[dict]] = []

    for p in own_products:
        psku = p.get("sku") or ""
        pname = p.get("name") or "?"
        product_items = reviews_by_sku.get(psku, [])
        if not product_items:
            continue

        row: list[dict] = []
        for codes in bucket_codes:
            code_set = set(codes)
            cell_reviews = [
                item["review"] for item in product_items
                if any(lab.get("label_code") in code_set for lab in item["labels"])
            ]
            row.append(_build_heatmap_cell(cell_reviews))

        # Skip products that yielded zero data across all buckets
        if all(c.get("sample_size", 0) == 0 for c in row):
            continue

        # Smart truncation: remove known brand prefix, truncate at word boundary
        short_name = pname
        for prefix in ("Cabela's ", "Cabela’s "):
            if short_name.startswith(prefix):
                short_name = short_name[len(prefix):]
                break
        if len(short_name) > 25:
            short_name = short_name[:25].rsplit(" ", 1)[0]

        y_labels.append(short_name)
        y_items.append({"product_name": pname, "display_label": short_name})
        z.append(row)

    if len(y_labels) < 2:
        return None

    return {
        "x_labels": x_labels,
        "x_label_codes": x_label_codes,
        "y_labels": y_labels,
        "y_items": y_items,
        "z": z,
        "aggregated_labels": other_codes,
    }


def _classify_review_positive(review: dict) -> bool:
    """Decide whether a single review counts as "positive" for heatmap scoring.

    Two paths, mutually exclusive:

    1. **Explicit sentiment path** — when `review["sentiment"]` is a non-empty
       string (the translation worker writes one of ``positive`` / ``negative``
       / ``mixed`` / ``neutral`` per LLM analysis, persisted on `reviews.sentiment`).
       Treat ``positive`` and ``mixed`` as positive; any other non-empty value
       (``negative`` / ``neutral`` / etc.) is treated as non-positive WITHOUT
       falling back to rating — the LLM verdict overrides star count.

    2. **Rating fallback path** — when sentiment is missing/empty (older rows
       written before the translator populated the column, or rows the worker
       has not yet processed). Treats ``rating >= 4`` as positive.
    """
    sentiment = (review.get("sentiment") or "").lower()
    if sentiment in {"positive", "mixed"}:
        return True
    if sentiment:
        # Explicit non-positive sentiment present — LLM overrides rating.
        return False
    try:
        rating = float(review.get("rating") or 0)
    except (TypeError, ValueError):
        rating = 0.0
    return rating >= 4


def _build_heatmap_cell(cell_reviews: list[dict]) -> dict:
    """F011 §4.2.6.2 v1.2 — derive cell dict from reviews matched to a cell."""
    sample_size = len(cell_reviews)

    def _sentiment_bucket(review: dict) -> str:
        sentiment = (review.get("sentiment") or "").lower()
        if sentiment in {"positive", "mixed", "negative", "neutral"}:
            return sentiment
        try:
            rating = float(review.get("rating") or 0)
        except (TypeError, ValueError):
            rating = 0.0
        if rating >= 4:
            return "positive"
        if rating <= 2 and rating > 0:
            return "negative"
        return "neutral"

    if sample_size < HEATMAP_MIN_SAMPLE:
        return {
            "score": None,
            "sample_size": sample_size,
            "positive_count": 0,
            "mixed_count": 0,
            "negative_count": 0,
            "neutral_count": sample_size,
            "color_class": "gray",
            "top_review_id": None,
            "top_review_excerpt": ("样本不足" if sample_size > 0 else "无样本"),
            "tooltip": ("样本不足" if sample_size > 0 else "无样本"),
        }

    buckets = [_sentiment_bucket(r) for r in cell_reviews]
    positive_count = sum(1 for b in buckets if b == "positive")
    mixed_count = sum(1 for b in buckets if b == "mixed")
    negative_count = sum(1 for b in buckets if b == "negative")
    neutral_count = sum(1 for b in buckets if b == "neutral")

    score = (positive_count + 0.5 * mixed_count) / sample_size

    if score > 0.7:
        color = "green"
    elif score >= 0.4:
        color = "yellow"
    else:
        color = "red"

    def _body_len(r: dict) -> int:
        return len(r.get("body_translated") or r.get("body_cn") or r.get("body") or "")

    def _rating(r: dict) -> float:
        try:
            return float(r.get("rating") or 0)
        except (TypeError, ValueError):
            return 0.0

    def _pick_review(preferred_bucket: str) -> dict | None:
        candidates = [
            review for review, bucket in zip(cell_reviews, buckets)
            if bucket == preferred_bucket
        ]
        if not candidates:
            return None
        if preferred_bucket == "negative":
            return min(candidates, key=lambda r: (_rating(r), -_body_len(r)))
        return max(candidates, key=lambda r: (_rating(r), _body_len(r)))

    if color == "red":
        top_r = _pick_review("negative")
    elif color == "yellow":
        top_r = _pick_review("mixed") or _pick_review("negative") or _pick_review("positive")
    else:
        top_r = _pick_review("positive") or _pick_review("mixed")
    if top_r is None:
        top_r = max(cell_reviews, key=lambda r: (_rating(r), _body_len(r)))

    body = (top_r.get("body_translated") or top_r.get("body_cn")
            or top_r.get("body") or "")
    excerpt = body[:HEATMAP_TOP_REVIEW_EXCERPT_LEN]
    tooltip = (
        f"体验健康度 {score * 100:.0f}%："
        f"正向 {positive_count}，混合 {mixed_count}，"
        f"负向 {negative_count}，中性 {neutral_count}，样本 {sample_size}；"
        "混合=正负并存，按 0.5 权重计入健康度"
    )

    return {
        "score": round(score, 3),
        "sample_size": sample_size,
        "positive_count": positive_count,
        "mixed_count": mixed_count,
        "negative_count": negative_count,
        "neutral_count": neutral_count,
        "color_class": color,
        "top_review_id": top_r.get("id"),
        "top_review_excerpt": excerpt,
        "tooltip": tooltip,
    }


def _build_trend_data(products, days=30):
    """Build per-product time series from product_snapshots.

    Returns a list of per-product series dicts. Each consumer is responsible
    for flattening to its own format (e.g., Excel rows, chart points).
    Stored under ``_trend_series`` key — NOT ``_trend_data`` which is
    reserved for ``report_charts.py``'s line chart format.
    """
    result = []
    for product in products:
        sku = product.get("sku", "")
        name = product.get("name", "")
        snapshots = models.get_product_snapshots(sku, days=days) if sku else []
        result.append({
            "product_name": name,
            "product_sku": sku,
            "series": [
                {
                    "date": s.get("scraped_at", ""),
                    "price": s.get("price"),
                    "rating": s.get("rating"),
                    "review_count": s.get("review_count"),
                    "stock_status": s.get("stock_status"),
                }
                for s in snapshots
            ],
        })
    return result


def build_historical_product_trend_series(products, until, days=365):
    result = []
    for product in products or []:
        sku = product.get("sku")
        product_url = product.get("url") or product.get("product_url")
        snapshots = models.get_product_snapshots_until(
            product_url=product_url,
            sku=sku,
            site=product.get("site"),
            until=until,
            days=days,
        ) if (product_url or sku) else []
        result.append({
            "product_name": product.get("name", ""),
            "product_sku": sku or "",
            "product_url": product_url or "",
            "site": product.get("site", ""),
            "ownership": product.get("ownership", ""),
            "series": [
                {
                    "date": s.get("scraped_at", ""),
                    "price": s.get("price"),
                    "rating": s.get("rating"),
                    "review_count": s.get("review_count"),
                    "ratings_only_count": s.get("ratings_only_count"),
                    "stock_status": s.get("stock_status"),
                }
                for s in snapshots
            ],
        })
    return result


_TREND_VIEWS = {
    "week": {"days": 7, "grain": "day"},
    "month": {"days": 30, "grain": "day"},
    "year": {"days": 365, "grain": "month"},
}

_TREND_DIMENSIONS = ("sentiment", "issues", "products", "competition")


def _shift_month(year_value, month_value, delta):
    total = year_value * 12 + (month_value - 1) + delta
    shifted_year = total // 12
    shifted_month = total % 12 + 1
    return shifted_year, shifted_month


def _trend_bucket_labels(logical_day, view):
    config_view = _TREND_VIEWS[view]
    if config_view["grain"] == "day":
        start = logical_day - timedelta(days=config_view["days"] - 1)
        labels = [(start + timedelta(days=index)).isoformat() for index in range(config_view["days"])]

        def _bucket_for(day_value):
            if not day_value or day_value < start or day_value > logical_day:
                return None
            return day_value.isoformat()

        return labels, _bucket_for

    labels = []
    for offset in range(11, -1, -1):
        year_value, month_value = _shift_month(logical_day.year, logical_day.month, -offset)
        labels.append(f"{year_value:04d}-{month_value:02d}")

    label_set = set(labels)

    def _bucket_for(day_value):
        if not day_value:
            return None
        label = f"{day_value.year:04d}-{day_value.month:02d}"
        return label if label in label_set else None

    return labels, _bucket_for


def _review_publish_date(review, logical_day):
    from qbu_crawler.server.report_common import _parse_date_flexible

    raw = review.get("date_published_parsed") or review.get("date_published")
    return _parse_date_flexible(raw, anchor_date=logical_day) if raw else None


def _scraped_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def _empty_comparison():
    """Phase 2 T9: comparison 永远是稳定 3 段 shape，
    数据不足时 current/previous/start/end 为 None，change_pct 同步 None。"""
    return {
        "period_over_period": {
            "label": "",
            "current": None,
            "previous": None,
            "change_pct": None,
        },
        "year_over_year": {
            "label": "",
            "current": None,
            "previous": None,
            "change_pct": None,
        },
        "start_vs_end": {
            "label": "",
            "start": None,
            "end": None,
            "change_pct": None,
        },
    }


def _trend_dimension_payload(
    *,
    status,
    message,
    kpis,
    primary_chart,
    table,
    secondary_charts=None,
    comparison=None,
):
    return {
        "status": status,
        "status_message": message,
        "kpis": kpis,
        "primary_chart": primary_chart,
        # Phase 2 T9: schema 永远齐全；ready 状态由各 _build_*_trend 主函数填充
        "secondary_charts": list(secondary_charts) if secondary_charts else [],
        "comparison": comparison if comparison is not None else _empty_comparison(),
        "table": table,
    }


def _empty_trend_dimension(status, message, chart_title, table_columns,
                            kpi_placeholder_labels=None):
    """Phase 2 T9: accumulating / degraded 状态也必须给出 4 个 KPI 占位项（label 固定，
    value 显示 "—"），不再返回空 items 列表。"""
    placeholder_labels = list(kpi_placeholder_labels or ["—", "—", "—", "—"])
    # 兜底：长度不足 4 时用 "—" 补齐
    while len(placeholder_labels) < 4:
        placeholder_labels.append("—")
    placeholder_items = [
        {"label": label, "value": "—"} for label in placeholder_labels[:4]
    ]
    return _trend_dimension_payload(
        status=status,
        message=message,
        kpis={"status": status, "items": placeholder_items},
        primary_chart={
            "status": status,
            "chart_type": "line",
            "title": chart_title,
            "labels": [],
            "series": [],
        },
        table={
            "status": status,
            "columns": table_columns,
            "rows": [],
        },
        secondary_charts=[],
        comparison=_empty_comparison(),
    )


def _build_sentiment_trend(view, logical_day, labeled_reviews):
    from qbu_crawler.server.report_common import _bayesian_bucket_health

    labels, bucket_for = _trend_bucket_labels(logical_day, view)
    review_count_by_bucket = {label: 0 for label in labels}
    own_total_by_bucket = {label: 0 for label in labels}
    own_negative_by_bucket = {label: 0 for label in labels}
    own_positive_by_bucket = {label: 0 for label in labels}

    for item in labeled_reviews:
        review = item["review"]
        bucket = bucket_for(_review_publish_date(review, logical_day))
        if not bucket:
            continue
        review_count_by_bucket[bucket] += 1
        if review.get("ownership") != "own":
            continue
        own_total_by_bucket[bucket] += 1
        rating = float(review.get("rating") or 0)
        if rating <= config.NEGATIVE_THRESHOLD:
            own_negative_by_bucket[bucket] += 1
        elif rating >= 4:
            own_positive_by_bucket[bucket] += 1

    review_counts = [review_count_by_bucket[label] for label in labels]
    own_negative_counts = [own_negative_by_bucket[label] for label in labels]
    own_negative_rates = [
        round((own_negative_by_bucket[label] / own_total_by_bucket[label]) * 100, 1)
        if own_total_by_bucket[label]
        else None
        for label in labels
    ]
    health_scores = [
        _bayesian_bucket_health(
            own_total=own_total_by_bucket[label],
            own_neg=own_negative_by_bucket[label],
            own_pos=own_positive_by_bucket[label],
        )
        for label in labels
    ]

    non_zero_points = sum(1 for value in review_counts if value > 0)
    ready = sum(review_counts) > 0 and (view != "year" or non_zero_points >= 2)
    if not ready:
        return _empty_trend_dimension(
            "accumulating",
            "评论发布时间样本仍在积累，当前不足以形成稳定趋势。",
            "评论声量与情绪",
            ["日期", "评论量", "自有差评", "自有差评率", "健康分"],
            kpi_placeholder_labels=["窗口评论量", "自有差评数", "自有差评率", "有效时间点"],
        )

    rows = []
    for label in labels:
        if review_count_by_bucket[label] <= 0:
            continue
        rows.append(
            {
                "bucket": label,
                "review_count": review_count_by_bucket[label],
                "own_negative_count": own_negative_by_bucket[label],
                "own_negative_rate": own_negative_rates[labels.index(label)],
                "health_index": health_scores[labels.index(label)],
            }
        )

    total_own_reviews = sum(own_total_by_bucket.values())
    total_own_negative = sum(own_negative_by_bucket.values())
    total_own_negative_rate = round((total_own_negative / total_own_reviews) * 100, 1) if total_own_reviews else 0

    return _trend_dimension_payload(
        status="ready",
        message="",
        kpis={
            "status": "ready",
            "items": [
                {"label": "窗口评论量", "value": sum(review_counts)},
                {"label": "自有差评数", "value": total_own_negative},
                {"label": "自有差评率", "value": f"{total_own_negative_rate:.1f}%"},
                {"label": "有效时间点", "value": non_zero_points},
            ],
        },
        primary_chart={
            "status": "ready",
            "chart_type": "line",
            "title": "评论声量与情绪",
            "labels": labels,
            "series": [
                {"name": "评论量", "data": review_counts},
                {"name": "自有差评数", "data": own_negative_counts},
                {"name": "健康分", "data": health_scores},
            ],
        },
        secondary_charts=_build_sentiment_secondary_charts(
            labels, own_negative_rates, health_scores,
        ),
        comparison=_build_sentiment_comparison(labels, own_negative_rates),
        table={
            "status": "ready",
            "columns": ["日期", "评论量", "自有差评", "自有差评率", "健康分"],
            "rows": rows,
        },
    )


def _build_sentiment_secondary_charts(labels, own_negative_rates, health_scores):
    """Phase 2 T9: sentiment dim 辅图 — 差评率与健康分独立走势。
    各自带 status：当 series 全部为 None（或为空）时降级到 accumulating；
    全 0 视为有效信号，不降级。"""
    own_neg_status = "ready" if any(v is not None for v in own_negative_rates) else "accumulating"
    health_status = "ready" if any(v is not None for v in health_scores) else "accumulating"

    return [
        {
            "status": own_neg_status,
            "chart_type": "line",
            "title": "自有差评率趋势",
            "labels": labels if own_neg_status == "ready" else [],
            "series": [
                {"name": "自有差评率(%)", "data": own_negative_rates},
            ] if own_neg_status == "ready" else [],
        },
        {
            "status": health_status,
            "chart_type": "line",
            "title": "健康分趋势",
            "labels": labels if health_status == "ready" else [],
            "series": [
                {"name": "健康分", "data": health_scores},
            ] if health_status == "ready" else [],
        },
    ]


def _build_sentiment_comparison(labels, own_negative_rates):
    """Phase 2 T9: sentiment dim comparison — 度量统一为「自有差评率」。
    start_vs_end: 第一个 / 最后一个非 null bucket（≥2 个非 null bucket 才出，单点不强行返"持平"）
    period_over_period / year_over_year: 当前实现填 null（待 Phase 2 后续历史扩展）

    change_pct 语义：相对百分比变化 (end - start) / start * 100，
    例如 start=50%、end=0% 时 change_pct = -100.0 表示「下降 100%」（相对于初值）。
    Phase 2 全维度 change_pct 统一用此口径，避免各维度不一致；
    未来若需要"百分点变化"语义，再加 change_pp 字段。"""
    _ = labels  # reserved for future PoP/YoY bucket alignment
    comparison = _empty_comparison()
    non_null = [v for v in own_negative_rates if v is not None]
    if len(non_null) < 2:
        return comparison
    start_value = non_null[0]
    end_value = non_null[-1]
    change_pct = None
    if (
        start_value is not None
        and end_value is not None
        and start_value != 0
    ):
        change_pct = round((end_value - start_value) / start_value * 100, 1)

    comparison["start_vs_end"]["label"] = "首尾差评率对比"
    comparison["start_vs_end"]["start"] = start_value
    comparison["start_vs_end"]["end"] = end_value
    comparison["start_vs_end"]["change_pct"] = change_pct
    return comparison


def _build_issue_trend(view, logical_day, labeled_reviews):
    from qbu_crawler.server.report_common import _label_display

    labels, bucket_for = _trend_bucket_labels(logical_day, view)
    counts_by_label: dict[str, dict[str, int]] = {}
    affected_products: dict[str, set[str]] = {}

    for item in labeled_reviews:
        review = item["review"]
        if review.get("ownership") != "own":
            continue
        bucket = bucket_for(_review_publish_date(review, logical_day))
        if not bucket:
            continue
        product_marker = review.get("product_sku") or review.get("product_name") or ""
        for label in item.get("labels") or []:
            if label.get("label_polarity") != "negative":
                continue
            code = label.get("label_code") or "_uncategorized"
            counts_by_label.setdefault(code, {name: 0 for name in labels})
            counts_by_label[code][bucket] += 1
            affected_products.setdefault(code, set()).add(product_marker)

    if not counts_by_label:
        return _empty_trend_dimension(
            "accumulating",
            "问题标签样本仍在积累，当前不足以形成稳定趋势。",
            "问题结构",
            ["问题", "评论数", "影响产品数"],
            kpi_placeholder_labels=["问题信号数", "活跃问题数", "头号问题", "涉及产品数"],
        )

    ranked_codes = sorted(
        counts_by_label,
        key=lambda code: (-sum(counts_by_label[code].values()), code),
    )[:3]
    non_zero_points = sum(
        1
        for label in labels
        if sum(counts_by_label[code].get(label, 0) for code in ranked_codes) > 0
    )
    ready = non_zero_points > 0 and (view != "year" or non_zero_points >= 2)
    if not ready:
        return _empty_trend_dimension(
            "accumulating",
            "问题标签时间分布仍在积累，当前不足以形成年度趋势。",
            "问题结构",
            ["问题", "评论数", "影响产品数"],
            kpi_placeholder_labels=["问题信号数", "活跃问题数", "头号问题", "涉及产品数"],
        )

    rows = []
    for code in ranked_codes:
        rows.append(
            {
                "label_code": code,
                "label_display": _label_display(code),
                "review_count": sum(counts_by_label[code].values()),
                "affected_product_count": len([name for name in affected_products.get(code, set()) if name]),
            }
        )

    top_code = ranked_codes[0]
    return _trend_dimension_payload(
        status="ready",
        message="",
        kpis={
            "status": "ready",
            "items": [
                {"label": "问题信号数", "value": sum(sum(counts_by_label[code].values()) for code in ranked_codes)},
                {"label": "活跃问题数", "value": len(ranked_codes)},
                {"label": "头号问题", "value": _label_display(top_code)},
                {"label": "涉及产品数", "value": rows[0]["affected_product_count"]},
            ],
        },
        primary_chart={
            "status": "ready",
            "chart_type": "line",
            "title": "问题结构",
            "labels": labels,
            "series": [
                {
                    "name": _label_display(code),
                    "data": [counts_by_label[code].get(label, 0) for label in labels],
                }
                for code in ranked_codes
            ],
        },
        secondary_charts=_build_issue_secondary_charts(
            labels, ranked_codes, counts_by_label, affected_products,
        ),
        comparison=_build_issue_comparison(labels, ranked_codes, counts_by_label),
        table={
            "status": "ready",
            "columns": ["问题", "评论数", "影响产品数"],
            "rows": rows,
        },
    )


def _build_issue_secondary_charts(labels, ranked_codes, counts_by_label, affected_products):
    """Phase 2 T9: issues dim 辅图 —
    1) Top3 问题在 buckets 上的分时段堆叠 (stacked_bar)
    2) Top3 问题受影响 SKU 数 (bar，x=问题，y=affected_product_count)

    status：ranked_codes 为空时返回 []（即 0 条辅图，由调用方决定 fallback）；
    否则两张图均 ready。"""
    from qbu_crawler.server.report_common import _label_display

    if not ranked_codes:
        return []

    stacked = {
        "status": "ready",
        "chart_type": "stacked_bar",
        "title": "Top3 问题分时段堆叠",
        "labels": labels,
        # series 故意复用 primary_chart 的数据；视觉形态 (stacked vs line) 是两张图的差异点
        "series": [
            {
                "name": _label_display(code),
                "data": [counts_by_label[code].get(label, 0) for label in labels],
            }
            for code in ranked_codes
        ],
    }

    affected = {
        "status": "ready",
        "chart_type": "bar",
        "title": "Top3 问题影响 SKU 数",
        "labels": [_label_display(code) for code in ranked_codes],
        "series": [
            {
                "name": "影响 SKU 数",
                "data": [
                    len([name for name in affected_products.get(code, set()) if name])
                    for code in ranked_codes
                ],
            },
        ],
    }
    return [stacked, affected]


def _build_issue_comparison(labels, ranked_codes, counts_by_label):
    """Phase 2 T9: issues dim comparison — 度量「头号问题在 bucket 上的评论数」。
    start_vs_end: 第一个非 0 bucket vs 最后一个非 0 bucket
    change_pct 语义：相对百分比变化（与 sentiment dim 同口径），start=0 时返回 None。
    period_over_period / year_over_year 当前留 null（待 Phase 2 后续历史扩展）。"""
    comparison = _empty_comparison()
    if not ranked_codes:
        return comparison

    top_code = ranked_codes[0]
    bucket_counts = [counts_by_label[top_code].get(label, 0) for label in labels]
    non_zero = [count for count in bucket_counts if count > 0]
    start_value = non_zero[0] if non_zero else None
    end_value = non_zero[-1] if non_zero else None
    change_pct = None
    if start_value is not None and end_value is not None and start_value != 0:
        change_pct = round((end_value - start_value) / start_value * 100, 1)

    comparison["start_vs_end"]["label"] = "头号问题首尾热度对比"
    comparison["start_vs_end"]["start"] = start_value
    comparison["start_vs_end"]["end"] = end_value
    comparison["start_vs_end"]["change_pct"] = change_pct
    return comparison


def _count_trend_value_changes(points, key):
    values = [point.get(key) for point in points if point.get(key) not in (None, "")]
    if len(values) < 2:
        return 0
    changes = 0
    previous = values[0]
    for value in values[1:]:
        if value != previous:
            changes += 1
        previous = value
    return changes


def _latest_stock_change(points):
    previous = None
    latest = ""
    for point in points:
        current = point.get("stock_status")
        if current in (None, ""):
            continue
        if previous is not None and current != previous:
            latest = f"{point.get('date') or point.get('bucket') or ''}: {previous} -> {current}"
        previous = current
    return latest


def _score_product_trend_series(points):
    if not points:
        return 0
    stock_changes = _count_trend_value_changes(points, "stock_status")
    price_changes = _count_trend_value_changes(points, "price")
    rating_changes = _count_trend_value_changes(points, "rating")
    return (
        (5 if stock_changes else 0)
        + (4 if price_changes else 0)
        + (3 if rating_changes else 0)
        + len(points)
    )


def _build_product_trend(view, logical_day, trend_series, snapshot_products):
    labels, bucket_for = _trend_bucket_labels(logical_day, view)
    own_products = [product for product in snapshot_products if product.get("ownership") == "own"]
    rows = []
    ready_series = None

    for product in own_products:
        sku = product.get("sku") or ""
        matching = next((item for item in trend_series if item.get("product_sku") == sku), None) or {}
        filtered = []
        for point in matching.get("series") or []:
            point_day = _scraped_date(point.get("date"))
            bucket = bucket_for(point_day)
            if not bucket:
                continue
            filtered.append({**point, "bucket": bucket})
        filtered = sorted(filtered, key=lambda item: item.get("date") or item.get("bucket") or "")
        price_change_count = _count_trend_value_changes(filtered, "price")
        stock_change_count = _count_trend_value_changes(filtered, "stock_status")
        rating_change_count = _count_trend_value_changes(filtered, "rating")
        rows.append(
            {
                "sku": sku,
                "name": product.get("name") or sku,
                "current_price": product.get("price"),
                "current_stock": product.get("stock_status") or "unknown",
                "current_rating": product.get("rating"),
                "current_review_count": product.get("review_count"),
                "snapshot_points": len(filtered),
                "price_change_count": price_change_count,
                "stock_change_count": stock_change_count,
                "latest_stock_change": _latest_stock_change(filtered),
                "scraped_at": product.get("scraped_at"),
            }
        )
        if len(filtered) >= 2:
            candidate = {
                "product_name": product.get("name") or sku,
                "points": filtered,
                "score": _score_product_trend_series(filtered),
            }
            if ready_series is None or candidate["score"] > ready_series["score"]:
                ready_series = candidate

    state_change_sku_count = sum(
        1 for row in rows
        if row["price_change_count"] or row["stock_change_count"]
    )
    total_snapshot_points = sum(row["snapshot_points"] for row in rows)
    product_table_columns = [
        "SKU", "产品", "当前价格", "当前库存", "当前评分", "当前评论总数",
        "快照点数", "价格变化次数", "库存变化次数", "最近库存变化", "最新抓取时间",
    ]

    if ready_series is None:
        return _trend_dimension_payload(
            status="accumulating",
            message="产品快照样本不足，连续状态趋势仍在积累。",
            kpis={
                "status": "ready" if rows else "accumulating",
                "items": [
                    {"label": "跟踪产品数", "value": len(own_products)},
                    {"label": "有快照产品数", "value": sum(1 for row in rows if row["snapshot_points"] > 0)},
                    {"label": "状态变化SKU数", "value": state_change_sku_count},
                    {"label": "快照点数", "value": total_snapshot_points},
                ],
            },
            primary_chart={
                "status": "accumulating",
                "chart_type": "line",
                "title": "产品状态",
                "labels": [],
                "series": [],
            },
            table={
                "status": "ready" if rows else "accumulating",
                "columns": product_table_columns,
                "rows": rows,
            },
        )

    bucket_to_rating = {label: None for label in labels}
    bucket_to_review_count = {label: None for label in labels}
    for point in ready_series["points"]:
        bucket_to_rating[point["bucket"]] = point.get("rating")
        bucket_to_review_count[point["bucket"]] = point.get("review_count")

    return _trend_dimension_payload(
        status="ready",
        message="",
        kpis={
            "status": "ready",
            "items": [
                {"label": "跟踪产品数", "value": len(own_products)},
                {"label": "有快照产品数", "value": sum(1 for row in rows if row["snapshot_points"] > 0)},
                {"label": "状态变化SKU数", "value": state_change_sku_count},
                {"label": "快照点数", "value": len(ready_series["points"])},
            ],
        },
        primary_chart={
            "status": "ready",
            "chart_type": "line",
            "title": f"产品状态 - {ready_series['product_name']}",
            "labels": labels,
            "series": [
                {"name": "评分", "data": [bucket_to_rating[label] for label in labels]},
                {"name": "评论总数", "data": [bucket_to_review_count[label] for label in labels]},
            ],
        },
        secondary_charts=_build_product_secondary_charts(
            labels, ready_series, bucket_to_review_count,
        ),
        comparison=_build_product_comparison(ready_series),
        table={
            "status": "ready",
            "columns": product_table_columns,
            "rows": rows,
        },
    )


def _build_product_secondary_charts(labels, ready_series, bucket_to_review_count):
    """Phase 2 T9: products dim 辅图 —
    1) 重点 SKU 评论总数走势 (line)
    2) 重点 SKU 价格走势 (line) — series 用 trend_series 中的 price

    status：评论总数总是 ready（数据来自既有 bucket_to_review_count）；
    价格在 price 全 None 时降级到 accumulating。"""
    if ready_series is None:
        return []

    bucket_to_price = {label: None for label in labels}
    for point in ready_series.get("points") or []:
        bucket = point.get("bucket")
        if bucket and bucket in bucket_to_price:
            bucket_to_price[bucket] = point.get("price")

    review_chart = {
        "status": "ready",
        "chart_type": "line",
        "title": f"重点 SKU 评论总数 - {ready_series['product_name']}",
        "labels": labels,
        "series": [
            {"name": "评论总数", "data": [bucket_to_review_count[label] for label in labels]},
        ],
    }

    has_price = any(v is not None for v in bucket_to_price.values())
    price_status = "ready" if has_price else "accumulating"
    price_chart = {
        "status": price_status,
        "chart_type": "line",
        "title": f"重点 SKU 价格 - {ready_series['product_name']}",
        "labels": labels if has_price else [],
        "series": [
            {"name": "价格", "data": [bucket_to_price[label] for label in labels]},
        ] if has_price else [],
    }
    return [review_chart, price_chart]


def _build_product_comparison(ready_series):
    """Phase 2 T9: products dim comparison — 度量「重点 SKU 评分」。
    start_vs_end: trend_series 第一个 / 最后一个有 rating 的 point。
    helper 内部按 bucket 排序作防御 — 生产路径 _build_trend_data 已 ORDER BY scraped_at ASC，
    但单测/未来调用方传入乱序 points 时这层排序保证语义不被静默颠倒。
    change_pct 语义：相对百分比变化（与 sentiment / issues dim 同口径）。
    period_over_period / year_over_year 当前留 null（待 Phase 2 后续历史扩展）。"""
    comparison = _empty_comparison()
    if ready_series is None:
        return comparison

    points = ready_series.get("points") or []
    rating_points = sorted(
        [p for p in points if p.get("rating") is not None],
        key=lambda p: p.get("bucket") or "",
    )
    if len(rating_points) < 2:
        return comparison

    start_value = rating_points[0]["rating"]
    end_value = rating_points[-1]["rating"]
    change_pct = None
    if start_value not in (None, 0):
        change_pct = round((end_value - start_value) / start_value * 100, 1)

    comparison["start_vs_end"]["label"] = "重点 SKU 评分首尾对比"
    comparison["start_vs_end"]["start"] = start_value
    comparison["start_vs_end"]["end"] = end_value
    comparison["start_vs_end"]["change_pct"] = change_pct
    return comparison


def _build_competition_trend(view, logical_day, labeled_reviews):
    labels, bucket_for = _trend_bucket_labels(logical_day, view)
    own_ratings = {label: [] for label in labels}
    competitor_ratings = {label: [] for label in labels}
    own_total = {label: 0 for label in labels}
    own_negative = {label: 0 for label in labels}
    competitor_total = {label: 0 for label in labels}
    competitor_positive = {label: 0 for label in labels}

    for item in labeled_reviews:
        review = item["review"]
        bucket = bucket_for(_review_publish_date(review, logical_day))
        if not bucket:
            continue
        rating = float(review.get("rating") or 0)
        if review.get("ownership") == "own":
            own_ratings[bucket].append(rating)
            own_total[bucket] += 1
            if rating <= config.NEGATIVE_THRESHOLD:
                own_negative[bucket] += 1
        elif review.get("ownership") == "competitor":
            competitor_ratings[bucket].append(rating)
            competitor_total[bucket] += 1
            if rating >= 4:
                competitor_positive[bucket] += 1

    shared_points = sum(1 for label in labels if own_total[label] > 0 and competitor_total[label] > 0)
    chart_ready = shared_points > 0 and (view != "year" or shared_points >= 2)
    own_points = sum(1 for label in labels if own_total[label] > 0)
    competitor_points = sum(1 for label in labels if competitor_total[label] > 0)
    any_side_has_data = own_points > 0 or competitor_points > 0

    if not any_side_has_data:
        # Neither side has data → integral accumulating is correct.
        return _empty_trend_dimension(
            "accumulating",
            "自有与竞品的可比样本仍在积累，当前不足以形成稳定趋势。",
            "竞品对标",
            ["日期", "自有均分", "竞品均分", "自有差评率", "竞品好评率"],
            kpi_placeholder_labels=["可比时间点", "最新评分差", "最新自有差评率", "最新竞品好评率"],
        )

    own_avg_rating = [
        round(sum(own_ratings[label]) / len(own_ratings[label]), 2) if own_ratings[label] else None
        for label in labels
    ]
    competitor_avg_rating = [
        round(sum(competitor_ratings[label]) / len(competitor_ratings[label]), 2) if competitor_ratings[label] else None
        for label in labels
    ]
    own_negative_rate = [
        round((own_negative[label] / own_total[label]) * 100, 1) if own_total[label] else None
        for label in labels
    ]
    competitor_positive_rate = [
        round((competitor_positive[label] / competitor_total[label]) * 100, 1) if competitor_total[label] else None
        for label in labels
    ]

    rows = []
    for label in labels:
        if own_total[label] <= 0 and competitor_total[label] <= 0:
            continue
        rows.append(
            {
                "bucket": label,
                "own_avg_rating": own_avg_rating[labels.index(label)],
                "competitor_avg_rating": competitor_avg_rating[labels.index(label)],
                "own_negative_rate": own_negative_rate[labels.index(label)],
                "competitor_positive_rate": competitor_positive_rate[labels.index(label)],
            }
        )

    latest_row = rows[-1] if rows else {}
    rating_gap = None
    if latest_row.get("own_avg_rating") is not None and latest_row.get("competitor_avg_rating") is not None:
        rating_gap = round(latest_row["competitor_avg_rating"] - latest_row["own_avg_rating"], 2)

    kpis_ready = shared_points > 0
    kpi_status = "ready" if kpis_ready else "accumulating"
    top_status = "ready" if chart_ready else "accumulating"
    top_message = "" if chart_ready else "可比样本仍在积累，图表暂未稳定但已有数据点可查。"

    _own_neg = latest_row.get("own_negative_rate") if latest_row else None
    _comp_pos = latest_row.get("competitor_positive_rate") if latest_row else None

    return _trend_dimension_payload(
        status=top_status,
        message=top_message,
        kpis={
            "status": kpi_status,
            "items": [
                {"label": "可比时间点", "value": shared_points},
                {"label": "最新评分差", "value": rating_gap if rating_gap is not None else "—"},
                {"label": "最新自有差评率", "value": f"{_own_neg:.1f}%" if _own_neg is not None else "—"},
                {"label": "最新竞品好评率", "value": f"{_comp_pos:.1f}%" if _comp_pos is not None else "—"},
            ],
        },
        primary_chart={
            "status": "ready" if chart_ready else "accumulating",
            "chart_type": "line",
            "title": "竞品对标",
            "labels": labels if chart_ready else [],
            "series": [
                {"name": "自有均分", "data": own_avg_rating},
                {"name": "竞品均分", "data": competitor_avg_rating},
            ] if chart_ready else [],
        },
        secondary_charts=_build_competition_secondary_charts(
            labels, own_avg_rating, competitor_avg_rating,
            own_negative_rate, competitor_positive_rate,
        ),
        comparison=_build_competition_comparison(
            labels, own_avg_rating, competitor_avg_rating,
        ),
        table={
            "status": "ready" if any_side_has_data else "accumulating",
            "columns": ["日期", "自有均分", "竞品均分", "自有差评率", "竞品好评率"],
            "rows": rows,
        },
    )


def _build_competition_secondary_charts(labels, own_avg_rating, competitor_avg_rating,
                                         own_negative_rate, competitor_positive_rate):
    """Phase 2 T9: competition dim 辅图 —
    1) 评分差趋势 (line, 单 series = competitor − own，None 透传给前端做 gap)
    2) 差/好评率对比 (line, series=own_neg_rate + competitor_pos_rate)

    各自带独立 status（mixed-state，兼容 spec §8.5）：gap 与 rate 的 ready/accumulating
    决策完全解耦；top_status 由 primary chart 决定，secondary 不参与 top 决策。
    当 series 全部为 None 时降级到 accumulating（labels/series 清空）；
    全 0 视为有效信号，不降级。"""
    gap_data = []
    for own_v, comp_v in zip(own_avg_rating, competitor_avg_rating):
        if own_v is None or comp_v is None:
            gap_data.append(None)
        else:
            gap_data.append(round(comp_v - own_v, 2))
    gap_status = "ready" if any(v is not None for v in gap_data) else "accumulating"

    rate_status = "ready" if (
        any(v is not None for v in own_negative_rate)
        or any(v is not None for v in competitor_positive_rate)
    ) else "accumulating"

    return [
        {
            "status": gap_status,
            "chart_type": "line",
            "title": "评分差趋势 (竞品 − 自有)",
            "labels": labels if gap_status == "ready" else [],
            "series": [
                {"name": "评分差", "data": gap_data},
            ] if gap_status == "ready" else [],
        },
        {
            "status": rate_status,
            "chart_type": "line",
            "title": "差/好评率对比",
            "labels": labels if rate_status == "ready" else [],
            "series": [
                {"name": "自有差评率(%)", "data": own_negative_rate},
                {"name": "竞品好评率(%)", "data": competitor_positive_rate},
            ] if rate_status == "ready" else [],
        },
    ]


def _build_competition_comparison(labels, own_avg_rating, competitor_avg_rating):
    """Phase 2 T9: competition dim comparison — 度量「评分差 (competitor - own)」。
    start_vs_end: 第一个 / 最后一个 own & comp 都非 None 的 bucket。
    change_pct 语义：相对百分比变化（与 sentiment / issues / products dim 同口径）。
    使用 abs(start) 作分母避免负 gap 时符号翻转 — 但 start=0 时仍返回 None。
    period_over_period / year_over_year 当前留 null（待 Phase 2 后续历史扩展）。"""
    _ = labels  # reserved for future PoP/YoY bucket alignment
    comparison = _empty_comparison()
    gaps = []
    for own_v, comp_v in zip(own_avg_rating, competitor_avg_rating):
        if own_v is not None and comp_v is not None:
            gaps.append(round(comp_v - own_v, 2))
    if len(gaps) < 2:
        return comparison

    start_value = gaps[0]
    end_value = gaps[-1]
    change_pct = None
    if start_value not in (None, 0):
        change_pct = round((end_value - start_value) / abs(start_value) * 100, 1)

    comparison["start_vs_end"]["label"] = "评分差首尾对比"
    comparison["start_vs_end"]["start"] = start_value
    comparison["start_vs_end"]["end"] = end_value
    comparison["start_vs_end"]["change_pct"] = change_pct
    return comparison


def _build_trend_dimension(builder, *args):
    try:
        return builder(*args)
    except Exception as exc:
        return _empty_trend_dimension(
            "degraded",
            f"趋势数据生成失败：{exc}",
            "趋势",
            [],
        )


# ---------------------------------------------------------------------------
# F011 H16 — public trend digest helpers
# ---------------------------------------------------------------------------

TREND_MIN_HIGH = (30, 7)
TREND_MIN_MEDIUM = (15, 5)
TREND_DEFAULT_WINDOWS = ("7d", "30d", "12m")
TREND_DEFAULT_ANCHORS = ("scraped_at", "date_published")


def _classify_trend_confidence(sample_size: int, time_points: int) -> str:
    """F011 H16 — promote to 'high' when both thresholds cleared, otherwise medium/low/no_data."""
    if sample_size <= 0:
        return "no_data"
    if sample_size >= TREND_MIN_HIGH[0] and time_points >= TREND_MIN_HIGH[1]:
        return "high"
    if sample_size >= TREND_MIN_MEDIUM[0] and time_points >= TREND_MIN_MEDIUM[1]:
        return "medium"
    return "low"


def _aggregate_health_series(reviews: list, *, ownership: str, anchor: str = "scraped_at",
                              window: str = "30d") -> list:
    """Aggregate health-index series points by date using `anchor` field on each review.

    Returns list of {"date": "YYYY-MM-DD", "value": float, "sample_count": int} sorted ascending.
    A point's "value" is the average rating for that day among reviews matching `ownership`.
    `window` clips to the last N days where N = 7 / 30 / 365 (12m). Reviews missing the anchor
    field are skipped silently.
    """
    from datetime import date as _date, timedelta as _td

    days = {"7d": 7, "30d": 30, "12m": 365}.get(window, 30)
    by_date: dict = {}
    for r in reviews:
        if (r.get("ownership") or "") != ownership:
            continue
        raw = r.get(anchor) or r.get("date") or r.get("date_published_parsed")
        if not raw:
            continue
        try:
            iso_day = str(raw)[:10]
            _date.fromisoformat(iso_day)
        except (ValueError, TypeError):
            continue
        rating = r.get("rating")
        if rating is None:
            continue
        try:
            by_date.setdefault(iso_day, []).append(float(rating))
        except (TypeError, ValueError):
            continue

    if not by_date:
        return []

    # Clip to window relative to most recent day
    sorted_days = sorted(by_date.keys())
    latest_day = _date.fromisoformat(sorted_days[-1])
    cutoff = latest_day - _td(days=days)
    points = []
    for d in sorted_days:
        if _date.fromisoformat(d) < cutoff:
            continue
        ratings = by_date[d]
        avg = sum(ratings) / len(ratings)
        # Linear-map 1..5 → 0..100 health index
        health = round(((avg - 1) / 4) * 100, 1)
        points.append({"date": d, "value": health, "sample_count": len(ratings)})
    return points


def _build_trend_comparison(series_own: list, prev_window_data) -> dict | None:
    """Build current-vs-prior comparison block. Returns None if either side missing."""
    if not series_own or not prev_window_data:
        return None
    current = series_own[-1]["value"]
    prior = prev_window_data.get("own_avg_health")
    if prior is None:
        return None
    delta = current - prior
    delta_pct = (delta / prior * 100) if prior else 0
    return {
        "own_vs_prior_window": {
            "current": round(current, 2),
            "prior": round(prior, 2),
            "delta": round(delta, 2),
            "delta_pct": round(delta_pct, 2),
        }
    }


def _parse_analysis_labels(review: dict) -> list:
    """Parse a review's ``analysis_labels`` (canonical JSON-string field) into a list.

    F011 §4.2.5 I-5 fix — drill-down builders previously read a phantom
    ``analysis_labels_parsed`` key that no upstream code ever writes, silently
    returning empty drill-down items in production. The DB column / `report.py`
    query alias is `analysis_labels` (a JSON string of ``[{code, polarity, ...}]``);
    parse it inline here so each call site stays self-contained.

    Per review-discipline in the task brief: do NOT swallow malformed JSON —
    fail loudly so we notice corruption upstream instead of silently emptying.
    """
    raw = review.get("analysis_labels") or "[]"
    if isinstance(raw, list):
        return raw
    parsed = json.loads(raw)
    return parsed if isinstance(parsed, list) else []


def _build_top_issues_drilldown(reviews: list, window: str) -> dict:
    """Lightweight Top Issues drill-down (placeholder shape; richer in Task 3.x)."""
    from collections import Counter as _C
    own_neg = [r for r in reviews if (r.get("ownership") or "") == "own"
               and (r.get("rating") or 5) <= 2]
    label_counter: _C = _C()
    for r in own_neg:
        for lab in _parse_analysis_labels(r):
            if not isinstance(lab, dict):
                continue
            if (lab.get("polarity") or "") == "negative" and lab.get("code"):
                label_counter[lab["code"]] += 1
    return {
        "kind": "top_issues",
        "window": window,
        "items": [{"label_code": c, "review_count": n} for c, n in label_counter.most_common(5)],
    }


def _build_product_ratings_drilldown(reviews: list) -> dict:
    """Product-ratings drill-down: per-SKU mean rating among own reviews."""
    by_sku: dict = {}
    name_lookup: dict = {}
    for r in reviews:
        if (r.get("ownership") or "") != "own":
            continue
        sku = r.get("product_sku") or ""
        rating = r.get("rating")
        if not sku or rating is None:
            continue
        try:
            by_sku.setdefault(sku, []).append(float(rating))
        except (TypeError, ValueError):
            continue
        if sku not in name_lookup and r.get("product_name"):
            name_lookup[sku] = r["product_name"]
    items = sorted(
        ({"sku": sku, "product_name": name_lookup.get(sku, sku),
          "rating_avg": round(sum(rs) / len(rs), 2),
          "review_count": len(rs)}
         for sku, rs in by_sku.items()),
        key=lambda x: x["rating_avg"],
    )
    return {"kind": "product_ratings", "items": items[:8]}


def _build_competitor_radar_drilldown(reviews: list) -> dict:
    """Competitor radar drill-down: positive feature counts (top 6)."""
    from collections import Counter as _C
    counter: _C = _C()
    for r in reviews:
        if (r.get("ownership") or "") != "competitor":
            continue
        for lab in _parse_analysis_labels(r):
            if not isinstance(lab, dict):
                continue
            if (lab.get("polarity") or "") == "positive" and lab.get("code"):
                counter[lab["code"]] += 1
    return {
        "kind": "competitor_radar",
        "items": [{"label_code": c, "review_count": n} for c, n in counter.most_common(6)],
    }


# F011 §4.2.5 — drill-down spec contract: each drill_down must be wrapped with
# stable `id` (for client-side wiring), user-visible `title`, and `data` payload.
_DRILLDOWN_TITLES = {
    "top_issues": "Top 3 问题随时间",
    "product_ratings": "产品评分变化",
    "competitor_radar": "竞品对标雷达",
}


def _wrap_drilldown(inner: dict) -> dict:
    """Wrap an inner drill-down builder result into the F011 §4.2.5 spec shape:

        {"id": <kind>, "title": <Chinese>, "data": <inner full payload>}

    Inner builders stay pure (return `kind`/`items`/...); this wrapper alone
    enforces the contract that the attachment HTML template consumes (see
    daily_report_v3.html.j2: `d.title`, `d.id`, `d.data`).
    """
    kind = inner.get("kind", "") if isinstance(inner, dict) else ""
    return {
        "id": kind,
        "title": _DRILLDOWN_TITLES.get(kind, kind),
        "data": inner if isinstance(inner, dict) else {},
    }


def build_trend_digest(
    reviews: list,
    *,
    prev_window_data=None,
    default_window: str = "30d",
    default_anchor: str = "scraped_at",
) -> dict:
    """F011 H16 — single-primary-chart trend digest with drill-downs.

    Output shape:
        {
          "primary_chart": {
            "kind": "health_trend",
            "default_window": "30d", "default_anchor": "scraped_at",
            "windows_available": [...], "anchors_available": [...],
            "series_own": [...], "series_competitor": [...],
            "comparison": {...} | None,
            "confidence": "high" | "medium" | "low" | "no_data",
            "min_sample_warning": str | None,
          },
          "drill_downs": [
            {"id": "top_issues",       "title": "Top 3 问题随时间", "data": {...}},
            {"id": "product_ratings",  "title": "产品评分变化",    "data": {...}},
            {"id": "competitor_radar", "title": "竞品对标雷达",    "data": {...}},
          ]
        }
    """
    series_own = _aggregate_health_series(reviews, ownership="own",
                                          anchor=default_anchor, window=default_window)
    series_competitor = _aggregate_health_series(reviews, ownership="competitor",
                                                  anchor=default_anchor, window=default_window)

    sample_size = sum(1 for r in reviews if (r.get("ownership") or "") == "own")
    time_points = len(series_own)
    confidence = _classify_trend_confidence(sample_size, time_points)
    min_warning = (
        f"样本 {sample_size} 条 / 时间点 {time_points}，需 ≥{TREND_MIN_HIGH[0]} + ≥{TREND_MIN_HIGH[1]} 才能判趋势"
        if confidence in ("low", "medium") else None
    )

    primary_chart = {
        "kind": "health_trend",
        "default_window": default_window,
        "default_anchor": default_anchor,
        "windows_available": list(TREND_DEFAULT_WINDOWS),
        "anchors_available": list(TREND_DEFAULT_ANCHORS),
        "series_own": series_own,
        "series_competitor": series_competitor,
        "comparison": _build_trend_comparison(series_own, prev_window_data),
        "confidence": confidence,
        "min_sample_warning": min_warning,
    }

    drill_downs = [
        _wrap_drilldown(_build_top_issues_drilldown(reviews, default_window)),
        _wrap_drilldown(_build_product_ratings_drilldown(reviews)),
        _wrap_drilldown(_build_competitor_radar_drilldown(reviews)),
    ]

    return {"primary_chart": primary_chart, "drill_downs": drill_downs}


# ---------------------------------------------------------------------------
# (private) legacy multi-view trend digest — keep for backward compat
# ---------------------------------------------------------------------------

def _build_trend_digest(snapshot, labeled_reviews, trend_series):
    logical_day = date.fromisoformat(snapshot["logical_date"])
    data = {}
    snapshot_products = snapshot.get("products") or []

    for view in _TREND_VIEWS:
        data[view] = {
            "sentiment": _build_trend_dimension(_build_sentiment_trend, view, logical_day, labeled_reviews),
            "issues": _build_trend_dimension(_build_issue_trend, view, logical_day, labeled_reviews),
            "products": _build_trend_dimension(_build_product_trend, view, logical_day, trend_series, snapshot_products),
            "competition": _build_trend_dimension(_build_competition_trend, view, logical_day, labeled_reviews),
        }

    return {
        "views": list(_TREND_VIEWS.keys()),
        "dimensions": list(_TREND_DIMENSIONS),
        "default_view": "month",
        "default_dimension": "sentiment",
        "data": data,
        "dimension_notes": {
            "sentiment": "基于评论发布时间 date_published 聚合，反映用户反馈发生时间。",
            "issues": "基于评论发布时间 date_published 和问题标签聚合，反映问题声量结构。",
            "products": "基于产品快照 scraped_at 聚合，反映每日采集到的价格、库存、评分、评论总数状态。",
            "competition": "基于评论发布时间 date_published 和可比样本聚合；可比样本不足时仅展示截面差异，不做强趋势判断。",
        },
        # 修 9: 年视图基于 date_published_parsed（评论发布时间），跨越历史数年；
        # 用户容易误以为是"监控系统已运行 N 年"，所以给出语义提示。
        "view_notes": {
            "week": None,
            "month": None,
            "year": (
                "年度视角基于评论发布时间聚合。历史数据源于站点用户的历史发布时间跨度，"
                "不代表本监控系统的实际运行年限。"
            ),
        },
    }


_WORKSPACE_VIEWS = {
    "week": {"label": "近7天", "days": 7, "previous_label": "较前7天"},
    "month": {"label": "近30天", "days": 30, "previous_label": "较前30天"},
    "year": {"label": "近12个月", "days": 365, "previous_label": "较前12个月"},
}

_WORKSPACE_DIMENSIONS = ("reputation", "issues", "products", "competition")


def _trend_until_date(snapshot, trend_history):
    until = (trend_history or {}).get("until") or snapshot.get("data_until") or f"{snapshot['logical_date']}T23:59:59+08:00"
    return date.fromisoformat(str(until)[:10])


def _trend_review_date(review):
    from qbu_crawler.server.report_common import _parse_date_flexible

    raw = review.get("date_published_parsed") or review.get("date_published")
    return _parse_date_flexible(raw) if raw else None


def _window_bounds(until_day, days):
    current_end = until_day - timedelta(days=1)
    current_start = current_end - timedelta(days=days - 1)
    previous_end = current_start - timedelta(days=1)
    previous_start = previous_end - timedelta(days=days - 1)
    return current_start, current_end, previous_start, previous_end


def _reviews_between(reviews, start, end):
    selected = []
    for review in reviews or []:
        day = _trend_review_date(review)
        if day and start <= day <= end:
            selected.append(review)
    return selected


def _avg_rating(reviews):
    ratings = []
    for review in reviews or []:
        try:
            ratings.append(float(review.get("rating")))
        except (TypeError, ValueError):
            pass
    return round(sum(ratings) / len(ratings), 2) if ratings else None


def _bad_rate(reviews):
    if not reviews:
        return None
    bad = sum(1 for review in reviews if float(review.get("rating") or 0) <= config.NEGATIVE_THRESHOLD)
    return round(bad / len(reviews), 4)


def _rate_display(value):
    return "—" if value is None else f"{value * 100:.1f}%"


def _delta_display(current, previous, suffix=""):
    if current is None or previous is None:
        return "暂无足够历史对比"
    delta = round(current - previous, 2)
    sign = "+" if delta > 0 else ""
    return f"{sign}{delta}{suffix}"


def _rating_gap_display(gap):
    if gap is None:
        return "—"
    value = abs(gap)
    if value == 0:
        return "自有与竞品持平"
    if gap > 0:
        return f"自有低于竞品 {value} 分"
    return f"自有高于竞品 {value} 分"


def _bad_rate_gap_display(gap):
    if gap is None:
        return "—"
    value = round(abs(gap) * 100, 1)
    if value == 0:
        return "自有与竞品持平"
    if gap > 0:
        return f"自有差评率比竞品高 {value} 个百分点"
    return f"自有差评率比竞品低 {value} 个百分点"


def _workspace_labels(until_day, view):
    days = _WORKSPACE_VIEWS[view]["days"]
    if view == "year":
        labels = []
        month_anchor = until_day - timedelta(days=1)
        year = month_anchor.year
        month = month_anchor.month
        for offset in range(11, -1, -1):
            shifted_year, shifted_month = _shift_month(year, month, -offset)
            labels.append(f"{shifted_year:04d}-{shifted_month:02d}")
        return labels
    start = until_day - timedelta(days=days)
    return [(start + timedelta(days=index)).isoformat() for index in range(days)]


def _bucket_review_counts(reviews, labels, view, ownership=None, metric="avg_rating"):
    buckets = {label: [] for label in labels}
    for review in reviews or []:
        if ownership and review.get("ownership") != ownership:
            continue
        day = _trend_review_date(review)
        if not day:
            continue
        label = f"{day.year:04d}-{day.month:02d}" if view == "year" else day.isoformat()
        if label in buckets:
            buckets[label].append(review)
    values = []
    for label in labels:
        bucket_reviews = buckets[label]
        if metric == "bad_rate":
            value = _bad_rate(bucket_reviews)
        else:
            value = _avg_rating(bucket_reviews)
        values.append(value)
    return values


def _workspace_empty(title, message, columns):
    return {
        "status": "accumulating",
        "title": title,
        "status_message": message,
        "comparison": {"status": "insufficient_history", "label": "暂无足够历史对比"},
        "kpis": {"items": []},
        "primary_chart": {"status": "accumulating", "chart_type": "line", "title": title, "labels": [], "series": []},
        "table": {"columns": columns, "rows": []},
    }


def _workspace_analysis_labels(review):
    labels = _extract_validated_llm_labels(review)
    if labels:
        return labels
    return classify_review_labels(review)


def _workspace_label_display(code):
    from qbu_crawler.server.report_common import _LABEL_DISPLAY

    return _LABEL_DISPLAY.get(code, code)


def _workspace_dimension(code):
    from qbu_crawler.server.report_common import CODE_TO_DIMENSION

    return CODE_TO_DIMENSION.get(code, code)


def _build_workspace_reputation(view, reviews, until_day):
    view_conf = _WORKSPACE_VIEWS[view]
    labels = _workspace_labels(until_day, view)
    own_series = _bucket_review_counts(reviews, labels, view, ownership="own")
    competitor_series = _bucket_review_counts(reviews, labels, view, ownership="competitor")
    current_start, current_end, previous_start, previous_end = _window_bounds(until_day, view_conf["days"])
    current = _reviews_between(reviews, current_start, current_end)
    previous = _reviews_between(reviews, previous_start, previous_end)
    own_current = [r for r in current if r.get("ownership") == "own"]
    comp_current = [r for r in current if r.get("ownership") == "competitor"]
    own_previous = [r for r in previous if r.get("ownership") == "own"]
    own_avg = _avg_rating(own_current)
    comp_avg = _avg_rating(comp_current)
    own_bad_rate = _bad_rate(own_current)
    gap = round((comp_avg or 0) - (own_avg or 0), 2) if own_avg is not None and comp_avg is not None else None
    rows = []
    for label in labels:
        bucket_reviews = []
        for review in reviews:
            day = _trend_review_date(review)
            if not day:
                continue
            bucket = f"{day.year:04d}-{day.month:02d}" if view == "year" else day.isoformat()
            if bucket == label:
                bucket_reviews.append(review)
        bucket_own = [r for r in bucket_reviews if r.get("ownership") == "own"]
        bucket_comp = [r for r in bucket_reviews if r.get("ownership") == "competitor"]
        rows.append({
            "日期 / 月份": label,
            "评论量": len(bucket_reviews),
            "自有均分": _avg_rating(bucket_own) or "—",
            "自有差评率": _rate_display(_bad_rate(bucket_own)),
            "竞品均分": _avg_rating(bucket_comp) or "—",
        })
    return {
        "status": "ready" if current else "accumulating",
        "title": f"{view_conf['label']} / 口碑趋势",
        "status_message": "",
        "comparison": {
            "status": "ready" if previous else "insufficient_history",
            "label": view_conf["previous_label"],
        },
        "kpis": {"items": [
            {"label": "自有平均评分", "value": own_avg if own_avg is not None else "—", "change": _delta_display(own_avg, _avg_rating(own_previous))},
            {"label": "自有差评率", "value": _rate_display(own_bad_rate)},
            {"label": "与竞品评分差", "value": gap if gap is not None else "—"},
        ]},
        "primary_chart": {
            "status": "ready",
            "chart_type": "line",
            "title": "自有平均评分 vs 竞品平均评分",
            "labels": labels,
            "series": [
                {"name": "自有平均评分", "data": own_series},
                {"name": "竞品平均评分", "data": competitor_series},
            ],
        },
        "table": {"columns": ["日期 / 月份", "评论量", "自有均分", "自有差评率", "竞品均分"], "rows": rows},
        "note": "空白表示当天没有对应自有或竞品评论。",
    }


def _label_counts(reviews, polarity, *, ownership=None):
    counts = {}
    skus = {}
    for review in reviews or []:
        if ownership and review.get("ownership") != ownership:
            continue
        for label in _workspace_analysis_labels(review):
            if label.get("label_polarity") != polarity:
                continue
            code = label.get("label_code")
            counts[code] = counts.get(code, 0) + 1
            skus.setdefault(code, set()).add(review.get("product_sku") or review.get("product_name") or "")
    return counts, skus


def _build_workspace_issues(view, reviews, until_day):
    view_conf = _WORKSPACE_VIEWS[view]
    labels = _workspace_labels(until_day, view)
    current_start, current_end, previous_start, previous_end = _window_bounds(until_day, view_conf["days"])
    current = _reviews_between(reviews, current_start, current_end)
    previous = _reviews_between(reviews, previous_start, previous_end)
    own_current = [r for r in current if r.get("ownership") == "own"]
    own_previous = [r for r in previous if r.get("ownership") == "own"]
    counts, skus = _label_counts(own_current, "negative", ownership="own")
    prev_counts, _ = _label_counts(own_previous, "negative", ownership="own")
    sorted_codes = [code for code, _ in sorted(counts.items(), key=lambda item: (-item[1], item[0]))]
    chart_codes = sorted_codes[:3]
    rows = []
    for code in sorted_codes:
        count = counts.get(code, 0)
        rows.append({
            "问题": _workspace_label_display(code),
            "当前评论数": count,
            "占比": _rate_display(count / len(own_current) if own_current else None),
            "对比变化": _delta_display(count, prev_counts.get(code)),
            "影响 SKU": "、".join(sorted(item for item in skus.get(code, set()) if item)),
        })
    series = []
    for code in chart_codes:
        data = []
        for label in labels:
            bucket_reviews = []
            for review in own_current:
                day = _trend_review_date(review)
                bucket = f"{day.year:04d}-{day.month:02d}" if (day and view == "year") else day.isoformat() if day else ""
                if bucket == label:
                    bucket_reviews.append(review)
            bucket_count = sum(
                1 for review in bucket_reviews
                if any(l.get("label_code") == code and l.get("label_polarity") == "negative" for l in _workspace_analysis_labels(review))
            )
            data.append(round(bucket_count / len(bucket_reviews), 4) if bucket_reviews else None)
        series.append({"name": _workspace_label_display(code), "data": data})
    top_code = sorted_codes[0] if sorted_codes else None
    return {
        "status": "ready" if own_current else "accumulating",
        "title": f"{view_conf['label']} / 问题趋势",
        "status_message": "",
        "comparison": {"status": "ready" if previous else "insufficient_history", "label": view_conf["previous_label"]},
        "kpis": {"items": [
            {"label": "问题评论占比", "value": _rate_display(sum(counts.values()) / len(own_current) if own_current else None)},
            {"label": "Top 1 问题", "value": _workspace_label_display(top_code) if top_code else "—"},
            {"label": "影响产品数", "value": len(skus.get(top_code, set())) if top_code else 0},
        ]},
        "primary_chart": {
            "status": "ready",
            "chart_type": "line",
            "title": "Top 3 问题评论占比趋势",
            "labels": labels,
            "series": series,
        },
        "table": {"columns": ["问题", "当前评论数", "占比", "对比变化", "影响 SKU"], "rows": rows},
        "note": "图表显示 Top 3 问题，表格列出当前窗口全部问题。",
    }


def _series_window_points(series, start, end):
    points = []
    for point in series or []:
        day = _scraped_date(point.get("date"))
        if day and start <= day <= end:
            points.append(point)
    return points


def _sku_bad_rate(reviews):
    result = {}
    for review in reviews or []:
        sku = review.get("product_sku")
        if not sku:
            continue
        bucket = result.setdefault(sku, {"total": 0, "bad": 0})
        bucket["total"] += 1
        if float(review.get("rating") or 0) <= config.NEGATIVE_THRESHOLD:
            bucket["bad"] += 1
    return {sku: (data["bad"] / data["total"] if data["total"] else None) for sku, data in result.items()}


def _build_workspace_products(view, reviews, product_series, until_day):
    view_conf = _WORKSPACE_VIEWS[view]
    current_start, current_end, previous_start, previous_end = _window_bounds(until_day, view_conf["days"])
    current_reviews = _reviews_between([r for r in reviews if r.get("ownership") == "own"], current_start, current_end)
    previous_reviews = _reviews_between([r for r in reviews if r.get("ownership") == "own"], previous_start, previous_end)
    current_bad = _sku_bad_rate(current_reviews)
    previous_bad = _sku_bad_rate(previous_reviews)
    labels = _workspace_labels(until_day, view)
    rows = []
    chart_series = []
    rating_down = bad_rate_up = growth_rating_down = 0
    for product in product_series or []:
        points = _series_window_points(product.get("series"), current_start, current_end)
        if len(points) < 2:
            continue
        first = points[0]
        last = points[-1]
        rating_delta = None
        if first.get("rating") is not None and last.get("rating") is not None:
            rating_delta = round(float(last["rating"]) - float(first["rating"]), 2)
        review_growth = (last.get("review_count") or 0) - (first.get("review_count") or 0)
        sku = product.get("product_sku")
        current_rate = current_bad.get(sku)
        previous_rate = previous_bad.get(sku)
        bad_delta = current_rate - previous_rate if current_rate is not None and previous_rate is not None else None
        if rating_delta is not None and rating_delta < 0:
            rating_down += 1
        if bad_delta is not None and bad_delta > 0:
            bad_rate_up += 1
        if review_growth > 0 and rating_delta is not None and rating_delta < 0:
            growth_rating_down += 1
        rows.append({
            "产品": product.get("product_name") or sku or "—",
            "当前评分": last.get("rating") if last.get("rating") is not None else "—",
            "评分变化": rating_delta if rating_delta is not None else "—",
            "当前差评率": _rate_display(current_rate),
            "差评率变化": _delta_display(current_rate, previous_rate),
            "评论增长数": review_growth,
        })
        chart_series.append({
            "name": product.get("product_name") or sku or "—",
            "data": [point.get("rating") for point in points],
        })
    return {
        "status": "ready" if rows else "accumulating",
        "title": f"{view_conf['label']} / 产品趋势",
        "status_message": "",
        "comparison": {"status": "ready" if previous_reviews else "insufficient_history", "label": view_conf["previous_label"]},
        "kpis": {"items": [
            {"label": "评分下降产品数", "value": rating_down},
            {"label": "差评率上升产品数", "value": bad_rate_up},
            {"label": "评论增长但评分下降产品数", "value": growth_rating_down},
        ]},
        "primary_chart": {
            "status": "ready" if chart_series else "accumulating",
            "chart_type": "line",
            "title": "重点风险产品评分趋势",
            "labels": labels,
            "series": chart_series[:3],
        },
        "table": {"columns": ["产品", "当前评分", "评分变化", "当前差评率", "差评率变化", "评论增长数"], "rows": rows},
    }


def _build_workspace_competition(view, reviews, until_day):
    view_conf = _WORKSPACE_VIEWS[view]
    labels = _workspace_labels(until_day, view)
    current_start, current_end, previous_start, previous_end = _window_bounds(until_day, view_conf["days"])
    current = _reviews_between(reviews, current_start, current_end)
    previous = _reviews_between(reviews, previous_start, previous_end)
    own = [r for r in current if r.get("ownership") == "own"]
    comp = [r for r in current if r.get("ownership") == "competitor"]
    own_avg = _avg_rating(own)
    comp_avg = _avg_rating(comp)
    own_bad = _bad_rate(own)
    comp_bad = _bad_rate(comp)
    pos_counts, _ = _label_counts(comp, "positive", ownership="competitor")
    neg_counts, _ = _label_counts(own, "negative", ownership="own")
    top_codes = sorted(pos_counts, key=lambda code: (-pos_counts[code], code))
    top_code = top_codes[0] if top_codes else None
    rows = []
    for advantage_code in top_codes:
        related = "暂无匹配"
        dimension = _workspace_dimension(advantage_code)
        matched = [
            issue_code for issue_code in neg_counts
            if issue_code == advantage_code or _workspace_dimension(issue_code) == dimension
        ]
        if matched:
            related = "、".join(_workspace_label_display(issue_code) for issue_code in matched[:3])
        rows.append({
            "竞品优势主题": "做工与质量" if advantage_code == "solid_build" else _workspace_label_display(advantage_code),
            "竞品好评数": pos_counts.get(advantage_code, 0),
            "自有相关问题": related,
            "建议动作": "暂无匹配" if related == "暂无匹配" else "优先对照该主题下的自有负面反馈复核体验短板",
        })
    gap_series = []
    own_series = _bucket_review_counts(reviews, labels, view, ownership="own")
    comp_series = _bucket_review_counts(reviews, labels, view, ownership="competitor")
    for own_value, comp_value in zip(own_series, comp_series):
        gap_series.append(round(own_value - comp_value, 2) if own_value is not None and comp_value is not None else None)
    gap = round(comp_avg - own_avg, 2) if own_avg is not None and comp_avg is not None else None
    bad_gap = own_bad - comp_bad if own_bad is not None and comp_bad is not None else None
    return {
        "status": "ready" if current else "accumulating",
        "title": f"{view_conf['label']} / 竞品对比",
        "status_message": "",
        "comparison": {"status": "ready" if previous else "insufficient_history", "label": view_conf["previous_label"]},
        "kpis": {"items": [
            {"label": "评分结论", "value": _rating_gap_display(gap)},
            {"label": "差评率结论", "value": _bad_rate_gap_display(bad_gap)},
            {"label": "竞品优势主题 Top 1", "value": "做工与质量" if top_code == "solid_build" else _workspace_label_display(top_code) if top_code else "—"},
        ]},
        "primary_chart": {
            "status": "ready",
            "chart_type": "line",
            "title": "自有与竞品评分差距",
            "labels": labels,
            "series": [{"name": "自有领先分数", "data": gap_series}],
        },
        "table": {"columns": ["竞品优势主题", "竞品好评数", "自有相关问题", "建议动作"], "rows": rows},
        "note": "表格列出当前窗口全部竞品优势主题；结论已按方向翻译。",
    }


def build_trend_workspace_digest(snapshot, trend_history, trend_product_series=None):
    trend_history = trend_history or {}
    reviews = trend_history.get("reviews") or []
    product_series = trend_product_series if trend_product_series is not None else trend_history.get("product_series") or []
    until_day = _trend_until_date(snapshot, trend_history)
    data = {}
    for view in _WORKSPACE_VIEWS:
        data[view] = {
            "reputation": _build_workspace_reputation(view, reviews, until_day),
            "issues": _build_workspace_issues(view, reviews, until_day),
            "products": _build_workspace_products(view, reviews, product_series, until_day),
            "competition": _build_workspace_competition(view, reviews, until_day),
        }
    return {
        "views": list(_WORKSPACE_VIEWS.keys()),
        "dimensions": list(_WORKSPACE_DIMENSIONS),
        "default_view": "month",
        "default_dimension": "reputation",
        "data": data,
    }


def build_report_analytics(snapshot, synced_labels=None, skip_delta=False, conn=None, trend_history=None):
    mode_info = detect_report_mode(snapshot.get("run_id", 0), snapshot["logical_date"])
    labeled_reviews = _build_labeled_reviews(snapshot, synced_labels=synced_labels)

    # Determine if review_analysis data is available for feature-based clustering
    snapshot_reviews = snapshot.get("reviews") or []
    use_feature_clusters = _has_review_analysis_data(snapshot_reviews)

    if use_feature_clusters:
        top_negative_clusters = _build_feature_clusters(snapshot_reviews, ownership="own", polarity="negative")
        top_positive_themes = _build_feature_clusters(snapshot_reviews, ownership="competitor", polarity="positive")
        # Own positive clusters (for gap analysis catch_up_gap)
        own_positive_clusters = _build_feature_clusters(snapshot_reviews, ownership="own", polarity="positive")
    else:
        top_negative_clusters = _cluster_summary_items(labeled_reviews, ownership="own", polarity="negative")
        top_positive_themes = _cluster_summary_items(labeled_reviews, ownership="competitor", polarity="positive")
        # Own positive clusters (for gap analysis catch_up_gap)
        own_positive_clusters = _cluster_summary_items(labeled_reviews, ownership="own", polarity="positive")

    # Override cluster severity with computed V3 severity (4-factor: volume/breadth/recency/safety)
    from datetime import datetime as _dt
    _logical_date = _dt.strptime(snapshot.get("logical_date", "2026-01-01"), "%Y-%m-%d").date()
    for cluster in top_negative_clusters:
        # Collect reviews matching this cluster for safety scan
        _cluster_reviews = [
            item["review"] for item in labeled_reviews
            if any(
                l["label_code"] == cluster["label_code"] and l["label_polarity"] == "negative"
                for l in item["labels"]
            )
            and item["review"].get("ownership") == "own"
        ]
        cluster["severity"] = compute_cluster_severity(cluster, _cluster_reviews, _logical_date)
        from qbu_crawler.server.report_common import _SEVERITY_DISPLAY
        cluster["severity_display"] = _SEVERITY_DISPLAY.get(cluster["severity"], cluster["severity"])

    image_reviews = []
    for item in labeled_reviews:
        if item["images"]:
            review = item["review"]
            image_reviews.append(
                {
                    "product_name": review.get("product_name"),
                    "product_sku": review.get("product_sku"),
                    "ownership": review.get("ownership"),
                    "rating": review.get("rating"),
                    "headline": review.get("headline"),
                    "body": review.get("body"),
                    "images": item["images"],
                }
            )

    own_products = [product for product in snapshot.get("products") or [] if product.get("ownership") == "own"]
    competitor_products = [
        product for product in snapshot.get("products") or [] if product.get("ownership") == "competitor"
    ]
    own_reviews = [item for item in labeled_reviews if item["review"].get("ownership") == "own"]
    competitor_reviews = [item for item in labeled_reviews if item["review"].get("ownership") == "competitor"]

    all_review_ratings = [
        float(review.get("rating") or 0) for review in snapshot_reviews
        if review.get("rating")
    ]
    own_review_ratings = [
        float(r["review"].get("rating") or 0) for r in own_reviews
        if r["review"].get("rating")
    ]
    competitor_review_ratings = [
        float(r["review"].get("rating") or 0) for r in competitor_reviews
        if r["review"].get("rating")
    ]
    sample_avg_rating = round(sum(all_review_ratings) / len(all_review_ratings), 2) if all_review_ratings else 0
    own_avg_rating = round(sum(own_review_ratings) / len(own_review_ratings), 2) if own_review_ratings else 0
    competitor_avg_rating = (
        round(sum(competitor_review_ratings) / len(competitor_review_ratings), 2)
        if competitor_review_ratings else 0
    )

    # Use config.NEGATIVE_THRESHOLD for negative review counting
    negative_threshold = config.NEGATIVE_THRESHOLD

    # _products_for_charts: used by price-rating quadrant chart
    products_for_charts = [
        {
            "name": p.get("name", ""),
            "sku": p.get("sku", ""),
            "price": float(p.get("price") or 0),
            "rating": float(p.get("rating") or 0),
            "ownership": p.get("ownership", "competitor"),
        }
        for p in (snapshot.get("products") or [])
        if p.get("price") and p.get("rating")
    ]

    # Chart-specific analytics data (radar, heatmap, sentiment distribution)
    chart_data = _compute_chart_data(labeled_reviews, snapshot)

    # Trend data from product_snapshots (stored as _trend_series, NOT _trend_data)
    _trend_series = _build_trend_data(snapshot.get("products") or [], days=30)

    # Compute recently_published_count: reviews published within 30 days of logical_date
    from qbu_crawler.server.report_common import _parse_date_flexible
    from datetime import date as _date, timedelta as _timedelta
    logical = _date.fromisoformat(snapshot["logical_date"])
    recent_cutoff = logical - _timedelta(days=30)
    recently_published_count = 0
    for review in snapshot_reviews:
        raw_parsed = review.get("date_published_parsed")
        pub_date = (_parse_date_flexible(raw_parsed) if raw_parsed else None) or _parse_date_flexible(review.get("date_published"))
        if pub_date and pub_date >= recent_cutoff:
            recently_published_count += 1

    # ── F011 §3.3.1: determine report semantics via state machine ────────────
    if conn and snapshot.get("run_id"):
        _report_semantics = determine_report_semantics(conn, snapshot["run_id"])
    else:
        _report_semantics = "bootstrap" if mode_info["mode"] == "baseline" else "incremental"

    analytics = {
        "run_id": snapshot.get("run_id"),
        "logical_date": snapshot["logical_date"],
        "snapshot_hash": snapshot["snapshot_hash"],
        "mode": mode_info["mode"],
        "report_semantics": _report_semantics,
        "is_bootstrap": _report_semantics == "bootstrap",
        "baseline_run_ids": mode_info["baseline_run_ids"],
        "baseline_sample_days": mode_info["baseline_sample_days"],
        "baseline_day_index": mode_info["baseline_day_index"],
        "baseline_display_state": mode_info["baseline_display_state"],
        "taxonomy_version": TAXONOMY_VERSION,
        "label_mode": config.REPORT_LABEL_MODE,
        "generated_at": config.now_shanghai().isoformat(),
        "change_digest": {},
        # F011 §4.2.5 — wire public build_trend_digest (primary_chart + drill_downs).
        # Legacy _build_trend_digest still exists for daily_report_v3_legacy.html.j2;
        # Task 4.6 will retire it.
        "trend_digest": build_trend_digest(
            reviews=[item["review"] for item in labeled_reviews],
        ),
        "_products_for_charts": products_for_charts,
        "metric_semantics": {
            "ingested_review_rows": "reviews 实际入库行数（按 scraped_at 窗口，含历史补采）",
            "recently_published_count": "其中 date_published 在近 30 天内的评论数",
            "site_reported_review_total_current": "products.review_count 当前站点展示总评论数（含 ratings-only）",
            "text_review_total_current": "可被 scraper 抓取的文字评论总数 = review_count - ratings_only_count，用于覆盖率分母",
            "ratings_only_total_current": "BV widget 中仅评分（无文字）的评论数，scraper 无法抓取",
        },
        "kpis": {
            "product_count": len(snapshot.get("products") or []),
            "ingested_review_rows": len(snapshot.get("reviews") or []),
            "site_reported_review_total_current": sum((product.get("review_count") or 0) for product in snapshot.get("products") or []),
            "text_review_total_current": sum(max(0, (product.get("review_count") or 0) - (product.get("ratings_only_count") or 0)) for product in snapshot.get("products") or []),
            "ratings_only_total_current": sum((product.get("ratings_only_count") or 0) for product in snapshot.get("products") or []),
            "translated_count": snapshot.get("translated_count", 0),
            "untranslated_count": snapshot.get("untranslated_count", 0),
            "own_product_count": len(own_products),
            "competitor_product_count": len(competitor_products),
            "own_review_rows": len(own_reviews),
            "competitor_review_rows": len(competitor_reviews),
            "image_review_rows": len(image_reviews),
            "own_avg_rating": own_avg_rating,
            "competitor_avg_rating": competitor_avg_rating,
            "sample_avg_rating": sample_avg_rating,
            "negative_review_rows": sum(
                1 for review in snapshot_reviews if (review.get("rating") or 0) <= negative_threshold
            ),
            "own_positive_review_rows": sum(
                1 for r in own_reviews if (r.get("review", {}).get("rating") or 0) >= 4
            ),
            "own_negative_review_rows": sum(
                1 for r in own_reviews if (r.get("review", {}).get("rating") or 0) <= negative_threshold
            ),
            "own_negative_review_rate": (
                sum(1 for r in own_reviews if (r.get("review", {}).get("rating") or 0) <= negative_threshold)
                / max(len(own_reviews), 1)
            ),
            "low_rating_review_rows": sum(
                1 for review in snapshot_reviews if (review.get("rating") or 0) <= config.LOW_RATING_THRESHOLD
            ),
            "recently_published_count": recently_published_count,
        },
        "self": {
            "risk_products": _risk_products(labeled_reviews, snapshot_products=snapshot.get("products", []),
                                            logical_date=snapshot.get("logical_date")),
            # F011 §4.2.3 — full-coverage status lamps for ALL own products (incl. healthy/no-data)
            "product_status": _product_status(
                labeled_reviews,
                snapshot_products=snapshot.get("products", []),
                logical_date=snapshot.get("logical_date"),
            ),
            "top_negative_clusters": top_negative_clusters,
            "top_positive_clusters": own_positive_clusters,
            "recommendations": _recommendations(top_negative_clusters),
        },
        "competitor": {
            "top_positive_themes": top_positive_themes,
            "benchmark_examples": _benchmark_examples(labeled_reviews),
            "negative_opportunities": _negative_opportunities(labeled_reviews),
            # F011 §4.2.7 v1.2 — competitor weakness ↔ our advantage opportunities
            "weakness_opportunities": _build_weakness_opportunities(labeled_reviews),
        },
        "appendix": {
            "image_reviews": sorted(
                image_reviews,
                key=lambda r: (
                    0 if r.get("ownership") == "own" else 1,
                    r.get("rating") or 5,
                ),
            )[:20],
            "coverage": {
                "own_products": len(own_products),
                "competitor_products": len(competitor_products),
                "own_reviews": len(own_reviews),
                "competitor_reviews": len(competitor_reviews),
            },
        },
        # F011 §4.2.6 — labels actually present in this run, for panorama label filter dropdown
        "label_options": _build_label_options(labeled_reviews),
        **chart_data,
        "_trend_series": _trend_series,
    }

    if trend_history is not None:
        analytics["trend_digest"]["workspace"] = build_trend_workspace_digest(
            snapshot,
            trend_history,
            trend_history.get("product_series") if isinstance(trend_history, dict) else None,
        )

    _ensure_delta_ready_kpis(analytics)

    # ── KPI delta computation (Fix-4) ────────────────────────────────────
    if not skip_delta and mode_info["mode"] != "baseline":
        from .report_snapshot import load_previous_report_context  # lazy import
        from .report_common import _compute_kpi_deltas

        _run_id = snapshot.get("run_id", 0)
        prev_analytics, _ = load_previous_report_context(_run_id)
        if prev_analytics:
            deltas = _compute_kpi_deltas(analytics["kpis"], prev_analytics)
            analytics["kpis"].update(deltas)

    return analytics


def _ensure_delta_ready_kpis(analytics):
    from qbu_crawler.server.report_common import compute_health_index

    health, confidence = compute_health_index(analytics)
    analytics.setdefault("kpis", {})["health_index"] = health
    analytics["kpis"]["health_confidence"] = confidence


def build_dual_report_analytics(snapshot, synced_labels=None, trend_history=None):
    """Dual-perspective analytics: cumulative (main) + window (delta).

    If snapshot has no 'cumulative' field (old format), degrades to single
    perspective by calling build_report_analytics() directly.
    """
    if not snapshot.get("cumulative"):
        return build_report_analytics(snapshot, synced_labels=synced_labels, trend_history=trend_history)

    cum = snapshot["cumulative"]
    cumulative_snapshot = {
        "run_id": snapshot["run_id"],
        "logical_date": snapshot["logical_date"],
        "snapshot_hash": snapshot.get("snapshot_hash", ""),
        "products": cum["products"],
        "reviews": cum["reviews"],
        "products_count": cum["products_count"],
        "reviews_count": cum["reviews_count"],
        "translated_count": cum.get("translated_count", 0),
        "untranslated_count": cum.get("untranslated_count", 0),
    }

    # Cumulative analytics (main body) — skip_delta=True: outer block handles delta correctly
    cum_analytics = build_report_analytics(
        cumulative_snapshot,
        synced_labels=synced_labels,
        skip_delta=True,
        trend_history=trend_history,
    )

    # Window analytics — skip delta (F3: avoids meaningless window-vs-cumulative comparison)
    window_analytics = None
    if snapshot.get("reviews"):
        window_analytics = build_report_analytics(
            snapshot, synced_labels=synced_labels, skip_delta=True)

    # Window summary
    window_reviews = snapshot.get("reviews", [])
    own_window = [r for r in window_reviews if r.get("ownership") == "own"]
    neg_threshold = config.NEGATIVE_THRESHOLD

    merged = {
        **cum_analytics,
        "perspective": "dual",
        "cumulative_kpis": cum_analytics["kpis"],
        "window": {
            "reviews_count": len(window_reviews),
            "own_reviews_count": len(own_window),
            "competitor_reviews_count": len(window_reviews) - len(own_window),
            "new_negative_count": sum(
                1 for r in own_window
                if (r.get("rating") or 5) <= neg_threshold),
            "new_reviews": window_reviews,
            "analytics": window_analytics,
        },
    }

    # KPI delta: cumulative vs previous cumulative
    if cum_analytics.get("mode") != "baseline":
        from .report_snapshot import load_previous_report_context
        from .report_common import _compute_kpi_deltas

        _ensure_delta_ready_kpis(merged)
        _run_id = snapshot.get("run_id", 0)
        prev_analytics, _ = load_previous_report_context(_run_id)
        if prev_analytics:
            prev_kpis_source = prev_analytics
            if prev_analytics.get("cumulative_kpis"):
                prev_kpis_source = {"kpis": prev_analytics["cumulative_kpis"]}
            deltas = _compute_kpi_deltas(merged["cumulative_kpis"], prev_kpis_source)
            merged["cumulative_kpis"].update(deltas)
            merged["kpis"].update(deltas)

    return merged


def build_fallback_priorities(
    risk_products: list[dict],
    issue_clusters: list[dict] | None = None,
    *,
    max_items: int = 5,
) -> list[dict]:
    """F011 H20 — produce rule-based improvement_priorities when LLM output is empty.

    Strategy:
    1. Walk top-3 risk products; for each, take its top label and build a row.
    2. If still under `max_items`, append rows from `issue_clusters` (top labels).
    3. Prefer concrete review evidence from issue clusters. Rows without review
       IDs are explicitly marked evidence_insufficient instead of pretending to
       be fully AI-supported recommendations.

    Each row is shaped to match LLM_INSIGHTS_SCHEMA_V3.improvement_priorities[].
    """
    issue_clusters = issue_clusters or []
    priorities: list[dict] = []
    seen_codes: set[str] = set()

    from qbu_crawler.server.report_common import _LABEL_DISPLAY

    action_templates = {
        "structure_design": (
            "针对{display}反馈，先围绕{products}复核尺寸、适配件、进出料路径和调节结构；"
            "结合典型原话“{complaint}”，安排样品复测并列出可验证的结构改良项。"
            "若问题集中在单一 SKU，优先做小批量结构验证；若跨 SKU 出现，则纳入下一轮设计评审。"
        ),
        "quality_stability": (
            "针对{display}反馈，优先对{products}做故障复现、批次追踪和耐久测试；"
            "结合典型原话“{complaint}”，检查开关、电机、齿轮和关键连接件的失效路径。"
            "短期先建立客服回访清单，中期把高频失效模式转成出厂抽检项。"
        ),
        "service_fulfillment": (
            "针对{display}反馈，先复盘{products}在发货、换货、客服响应和承诺兑现上的断点；"
            "结合典型原话“{complaint}”，把订单状态、补发时效和客服话术拆成可追踪指标。"
            "短期优先处理未闭环投诉，中期建立异常订单升级机制。"
        ),
        "material_finish": (
            "针对{display}反馈，优先检查{products}的材料厚度、表面处理、毛刺、清洁残留和包装保护；"
            "结合典型原话“{complaint}”，把用户可感知的做工问题转成来料、装配和终检清单。"
            "若图片证据集中出现，应追加批次抽样和供应商复核。"
        ),
        "assembly_installation": (
            "针对{display}反馈，先验证{products}的安装步骤、转接件兼容性、说明书和首次使用引导；"
            "结合典型原话“{complaint}”，找出用户卡住的位置并补充图示或预装方案。"
            "短期更新客服排障脚本，中期把高频装配问题纳入包装内说明。"
        ),
    }
    default_template = (
        "针对{display}反馈，先围绕{products}抽取典型评论和图片证据，确认用户抱怨是否集中在同一使用场景；"
        "结合典型原话“{complaint}”，安排产品、客服和质检共同复盘。"
        "短期先验证最高频症状，中期把复盘结论转成可追踪的改良项。"
    )
    insufficient_template = (
        "证据不足：当前仅能确认{display}在{products}上存在聚合信号，但缺少可直接追溯的典型评论 ID。"
        "请先回到评论原文补齐证据，再决定是否进入正式改良排期；在证据补齐前，只建议做样品复核、客服回访和数据补采。"
    )

    def _display_for(code: str, value: str | None = None) -> str:
        return value or _LABEL_DISPLAY.get(code) or code

    def _review_id(review: dict):
        return review.get("id") or review.get("review_id")

    def _review_text(review: dict) -> str:
        headline = review.get("headline_cn") or review.get("headline") or ""
        body = review.get("body_cn") or review.get("body_translated") or review.get("body") or ""
        if headline and body:
            return f"{headline}：{body}"
        return headline or body

    def _build_action(code: str, display: str, products: list[str], complaint: str, source: str) -> str:
        product_text = "、".join(products[:3]) if products else "相关产品"
        complaint_text = complaint or "暂无可展示的典型原话"
        if source == "evidence_insufficient":
            return insufficient_template.format(
                display=display,
                products=product_text,
                complaint=complaint_text,
            )
        template = action_templates.get(code, default_template)
        return template.format(
            display=display,
            products=product_text,
            complaint=complaint_text,
        )

    def _make_priority(
        *,
        code: str,
        display: str,
        evidence_count: int,
        affected_products: list[str],
        example_reviews: list[dict] | None = None,
    ) -> dict:
        examples = example_reviews or []
        evidence_review_ids = []
        for review in examples:
            rid = _review_id(review)
            if rid is not None and rid not in evidence_review_ids:
                evidence_review_ids.append(rid)
        top_complaint = ""
        for review in examples:
            text = _review_text(review)
            if text:
                top_complaint = text[:200]
                break
        source = "rule_fallback" if evidence_review_ids else "evidence_insufficient"
        short_title = display if len(display) <= 20 else display[:20]
        return {
            "label_code": code,
            "label_display": display,
            "short_title": short_title,
            "full_action": _build_action(code, display, affected_products, top_complaint, source),
            "top_complaint": top_complaint,
            "source": source,
            "evidence_count": int(evidence_count or len(evidence_review_ids) or 0),
            "evidence_review_ids": evidence_review_ids,
            "affected_products": list(affected_products[:3]),
            "affected_products_count": len(affected_products),
        }

    for p in (risk_products or [])[:3]:
        labels = p.get("top_labels") or []
        if not labels:
            continue
        label = labels[0]
        code = label.get("code") or label.get("label_code")
        if not code or code in seen_codes:
            continue
        seen_codes.add(code)

        display = _display_for(code, label.get("display") or label.get("label_display"))
        product_name = p.get("product_name") or p.get("name") or "(未知产品)"
        priorities.append(_make_priority(
            code=code,
            display=display,
            evidence_count=int(label.get("count") or 0),
            affected_products=[product_name],
            example_reviews=label.get("example_reviews") or p.get("example_reviews") or [],
        ))

    for cluster in issue_clusters:
        if len(priorities) >= max_items:
            break
        code = cluster.get("label_code")
        if not code or code in seen_codes:
            continue
        seen_codes.add(code)

        display = _display_for(code, cluster.get("label_display"))
        sample_products = cluster.get("affected_products") or cluster.get("products") or []
        priorities.append(_make_priority(
            code=code,
            display=display,
            evidence_count=int(cluster.get("review_count") or 0),
            affected_products=list(sample_products),
            example_reviews=cluster.get("example_reviews") or [],
        ))

    return priorities[:max_items]


def determine_report_semantics(conn, current_run_id: int) -> str:
    """报告状态机：返回 'bootstrap' / 'incremental'。

    F011 §3.3.1：
    - 当前 run 之前无同 workflow_type 的 status='completed' run → bootstrap
    - 之前有 ≥1 个 status='completed' 的同 workflow_type run → incremental
    """
    cur = conn.cursor()
    row = cur.execute(
        "SELECT workflow_type FROM workflow_runs WHERE id=?",
        (current_run_id,),
    ).fetchone()
    if not row:
        return "bootstrap"  # 异常情况，保守返回 bootstrap

    (workflow_type,) = row
    prior_completed = cur.execute(
        """SELECT COUNT(*) FROM workflow_runs
           WHERE workflow_type=? AND status='completed' AND id < ?""",
        (workflow_type, current_run_id),
    ).fetchone()[0]

    return "incremental" if prior_completed > 0 else "bootstrap"
