from cryptography.fernet import Fernet
import base64


class Encryption:
    def __init__(self, key=None):
        if key is None:
            self.cipher = None
        else:
            if isinstance(key, str):
                key = key.encode("utf-8")
            try:
                self.cipher = Fernet(key)
            except Exception as e:
                raise ValueError(f"Invalid key: {e}") from e

    def encrypt(self, data):
        if self.cipher is None:
            return data
        if isinstance(data, str):
            data = data.encode("utf-8")
        return self.cipher.encrypt(data)

    def decrypt(self, data):
        if self.cipher is None:
            return data
        return self.cipher.decrypt(data)

    @staticmethod
    def generate_key():
        return Fernet.generate_key().decode("utf-8")
