import sqlite3
import importlib
import importlib.abc
import marshal
import types
import os
import sys
import tempfile
import shutil
import json
from pathlib import Path
from .encryption import Encryption


class SQLiteModuleLoader(importlib.abc.Loader):
    """SQLite模块加载器"""

    def __init__(
        self,
        db_connection: sqlite3.Connection,
        module_name: str,
        db_path: str | None = None,
        key: str | None = None,
    ):
        self.db_connection = db_connection
        self.module_name = module_name
        self.db_path = db_path
        self.db_connection.row_factory = sqlite3.Row
        self.encryption = Encryption(key)
        self._runtime_temp_dir = None

    def create_module(self, spec):
        """创建模块对象"""
        # 获取模块信息
        cursor = self.db_connection.execute(
            "SELECT is_package FROM python_modules WHERE module_name = ?",
            (self.module_name,),
        )
        row = cursor.fetchone()

        if row and row["is_package"]:
            # 创建包模块
            module = types.ModuleType(self.module_name)
            module.__path__ = []  # 包需要有__path__属性
            module.__package__ = self.module_name
            return module
        else:
            # 创建普通模块
            return None  # 使用默认创建方式

    def exec_module(self, module):  # type: ignore
        """执行模块代码"""
        cursor = self.db_connection.execute(
            "SELECT bytecode, is_package, encrypted, pyarmor_protected, source_code, metadata FROM python_modules WHERE module_name = ?",
            (self.module_name,),
        )
        row = cursor.fetchone()

        if not row:
            raise ImportError(f"No module named '{self.module_name}' in database")

        pyarmor_protected = row["pyarmor_protected"]

        # 如果是 PyArmor 保护的模块，需要先部署运行时再执行
        if pyarmor_protected:
            return self._exec_pyarmor_module(module, row)

        # 从字节码加载
        bytecode_blob = row["bytecode"]
        encrypted = row["encrypted"]

        # 如果字节码是加密的，需要解密
        if encrypted:
            if self.encryption.cipher is None:
                raise ImportError(
                    f"Module '{self.module_name}' has encrypted bytecode but no decryption key provided. "
                    "Please set the key when installing the importer."
                )
            bytecode_blob = self.encryption.decrypt(bytecode_blob)

        # 从字节码加载
        bytecode = marshal.loads(bytecode_blob)

        # 在模块的命名空间中执行字节码
        exec(bytecode, module.__dict__)

        # 如果是包，设置__path__属性
        if row["is_package"]:
            module.__path__ = []
            module.__package__ = self.module_name

        # 设置模块的__file__属性为数据库路径
        module.__file__ = f"sqlite://{self.db_path}/{self.module_name}"

        return module

    def _deploy_runtime(self, runtime_name: str) -> str | None:
        """
        部署 PyArmor 运行时到临时目录

        Args:
            runtime_name: 运行时模块名，如 'pyarmor_runtime_000000'

        Returns:
            临时目录路径，如果部署失败则返回 None
        """
        if self.db_path is None:
            return None

        try:
            from .sqlite_module_importer import SQLiteModuleImporter

            importer = SQLiteModuleImporter(self.db_path)
            runtime_dict = importer.get_runtime(runtime_name)
        except Exception:
            return None

        if not runtime_dict:
            return None

        # 创建临时目录来存放运行时包
        temp_dir = tempfile.mkdtemp(prefix="pyarmor_runtime_")
        runtime_pkg_dir = os.path.join(temp_dir, runtime_name)
        os.makedirs(runtime_pkg_dir, exist_ok=True)

        # 确定运行时二进制文件名（.pyd for Windows, .so for Linux/Mac）
        pyd_data = runtime_dict.get("pyd_data")
        if pyd_data:
            if sys.platform == "win32":
                so_filename = "pyarmor_runtime.pyd"
            elif sys.platform == "darwin":
                so_filename = "pyarmor_runtime.dylib"
            else:
                so_filename = "pyarmor_runtime.so"

            so_path = os.path.join(runtime_pkg_dir, so_filename)
            with open(so_path, "wb") as f:
                f.write(pyd_data)

        # 写入 __init__.py
        init_data = runtime_dict.get("init_data")
        if init_data:
            init_path = os.path.join(runtime_pkg_dir, "__init__.py")
            with open(init_path, "w", encoding="utf-8") as f:
                f.write(init_data)

        # 将临时目录添加到 sys.path，使运行时包可被导入
        if temp_dir not in sys.path:
            sys.path.insert(0, temp_dir)

        return temp_dir

    def _extract_runtime_name_from_source(self, source_code: str) -> str | None:
        """从混淆代码中提取运行时模块名"""
        import re

        match = re.search(
            r"from\s+(pyarmor_runtime_\w+)\s+import\s+__pyarmor__",
            source_code,
        )
        return match.group(1) if match else None

    def _extract_runtime_name_from_metadata(
        self, metadata_str: str | None
    ) -> str | None:
        """从 metadata JSON 中提取运行时模块名"""
        if not metadata_str:
            return None
        try:
            metadata = json.loads(metadata_str)
            return metadata.get("pyarmor_runtime")
        except (json.JSONDecodeError, TypeError):
            return None

    def _exec_pyarmor_module(self, module, row):
        """
        执行 PyArmor 保护的模块

        PyArmor 混淆后的代码需要在运行时导入 pyarmor_runtime_xxx 包。
        该包包含 __init__.py 和原生 .pyd/.so 文件。

        支持两种模式：
        1. 有源代码：从源代码编译执行（标准模式）
        2. 无源代码：从已编译的字节码执行（delete_source 后的模式）
        """
        source_code = row["source_code"]
        bytecode_blob = row["bytecode"]
        encrypted = row["encrypted"]
        metadata_str = row["metadata"]

        # 确定运行时名：优先从源代码提取，其次从 metadata
        runtime_name = None
        if source_code:
            runtime_name = self._extract_runtime_name_from_source(source_code)
        if not runtime_name:
            runtime_name = self._extract_runtime_name_from_metadata(metadata_str)

        # 部署运行时
        if runtime_name:
            self._runtime_temp_dir = self._deploy_runtime(runtime_name)
            if self._runtime_temp_dir:
                print(f"  已部署 PyArmor 运行时: {runtime_name}")

        # 设置 __file__ 属性（PyArmor 的 __pyarmor__() 需要它）
        module_file = f"sqlite://{self.db_path}/{self.module_name}"
        module.__file__ = module_file

        # 如果是包，设置__path__和__package__属性
        if row["is_package"]:
            module.__path__ = []
            module.__package__ = self.module_name

        # 执行代码
        if source_code:
            # 模式1：有源代码 - 编译后执行
            bytecode = compile(
                source_code, f"<sqlite_module:{self.module_name}>", "exec"
            )
            exec(bytecode, module.__dict__)
        else:
            # 模式2：无源代码 - 从已存储的字节码执行
            if not bytecode_blob:
                raise ImportError(
                    f"PyArmor protected module '{self.module_name}' has no source code or bytecode available"
                )

            # 如果字节码是加密的，需要解密
            if encrypted:
                if self.encryption.cipher is None:
                    raise ImportError(
                        f"Module '{self.module_name}' has encrypted bytecode but no decryption key provided."
                    )
                bytecode_blob = self.encryption.decrypt(bytecode_blob)

            bytecode = marshal.loads(bytecode_blob)
            exec(bytecode, module.__dict__)

        return module

    def cleanup_runtime(self):
        """清理 PyArmor 运行时临时文件"""
        if self._runtime_temp_dir and os.path.exists(self._runtime_temp_dir):
            try:
                if self._runtime_temp_dir in sys.path:
                    sys.path.remove(self._runtime_temp_dir)
                shutil.rmtree(self._runtime_temp_dir, ignore_errors=True)
            except Exception:
                pass
            self._runtime_temp_dir = None
