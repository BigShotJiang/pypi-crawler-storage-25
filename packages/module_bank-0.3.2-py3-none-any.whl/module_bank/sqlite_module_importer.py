import sqlite3
import marshal
import base64
import os
import json
from pathlib import Path
from typing import Dict, Optional, Tuple
from .encryption import Encryption


class SQLiteModuleImporter:
    """从SQLite数据库导入Python模块的导入器"""

    def __init__(
        self,
        db_path: str,
        key: Optional[str] = None,
        pyarmor_obfuscate: bool = False,
        pyarmor_obf_code: int = 1,
        pyarmor_obf_mod: int = 1,
    ):
        self.db_path = db_path
        self.connection = sqlite3.connect(db_path)
        self.connection.row_factory = sqlite3.Row
        self.encryption = Encryption(key)
        self.pyarmor_obfuscate = pyarmor_obfuscate
        self.pyarmor_obf_code = pyarmor_obf_code
        self.pyarmor_obf_mod = pyarmor_obf_mod
        self._pyarmor_enc = None
        self._create_tables()

    def _create_tables(self):
        """创建存储模块的数据库表"""
        self.connection.execute("""
            CREATE TABLE IF NOT EXISTS python_modules (
                module_name TEXT PRIMARY KEY,
                source_code TEXT,
                bytecode BLOB,
                is_package BOOLEAN,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        try:
            self.connection.execute(
                "ALTER TABLE python_modules ADD COLUMN encrypted INTEGER DEFAULT 0"
            )
        except sqlite3.OperationalError:
            pass

        # 添加 pyarmor_protected 列（用于标记 PyArmor 混淆过的模块）
        try:
            self.connection.execute(
                "ALTER TABLE python_modules ADD COLUMN pyarmor_protected INTEGER DEFAULT 0"
            )
        except sqlite3.OperationalError:
            pass

        # 创建 PyArmor 运行时存储表（支持二进制文件和文本文件的存储）
        self.connection.execute("""
            CREATE TABLE IF NOT EXISTS pyarmor_runtime (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                runtime_name TEXT UNIQUE NOT NULL,
                pyd_data BLOB,
                init_data TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self.connection.commit()

    def _get_pyarmor_enc(self):
        """惰性获取 PyArmor 加密器"""
        if self._pyarmor_enc is None:
            from .pyarmor_encryption import PyArmorEncryption

            self._pyarmor_enc = PyArmorEncryption(
                key=None,
                obf_code=self.pyarmor_obf_code,
                obf_mod=self.pyarmor_obf_mod,
            )
        return self._pyarmor_enc

    def add_module(
        self,
        module_name: str,
        source_code: str,
        is_package: bool = False,
        metadata: Dict | None = None,
    ):
        """添加模块到数据库"""
        pyarmor_protected = 0

        # 如果启用了 PyArmor 混淆，则先混淆源代码
        if self.pyarmor_obfuscate:
            pyarmor_enc = self._get_pyarmor_enc()
            if pyarmor_enc.check_pyarmor_available():
                obfuscated_code, runtime_dict = pyarmor_enc.obfuscate_source(
                    source_code, module_name
                )
                source_code = obfuscated_code
                pyarmor_protected = 1

                # 存储运行时文件
                runtime_name = None
                if runtime_dict is not None:
                    runtime_name = runtime_dict.get("runtime_name")
                    self._store_runtime(runtime_dict)

                # 将运行时名存入 metadata，以便在删除源代码后仍能定位运行时
                if runtime_name and metadata is None:
                    metadata = {"pyarmor_runtime": runtime_name}
                elif runtime_name and isinstance(metadata, dict):
                    metadata["pyarmor_runtime"] = runtime_name
            else:
                print(f"警告: PyArmor 未安装，跳过模块 '{module_name}' 的 PyArmor 混淆")

        # 编译为字节码
        bytecode = compile(source_code, f"<sqlite_module:{module_name}>", "exec")
        bytecode_blob = marshal.dumps(bytecode)

        # metadata_str = str(metadata) if metadata else "{}"
        metadata_str = json.dumps(metadata)
        encrypted_flag = 0

        # 如果加密器已设置，则加密字节码
        if self.encryption.cipher is not None:
            bytecode_blob = self.encryption.encrypt(bytecode_blob)
            encrypted_flag = 1

        self.connection.execute(
            """
            INSERT OR REPLACE INTO python_modules 
            (module_name, source_code, bytecode, is_package, metadata, encrypted, pyarmor_protected)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
            (
                module_name,
                source_code,
                bytecode_blob,
                is_package,
                metadata_str,
                encrypted_flag,
                pyarmor_protected,
            ),
        )
        self.connection.commit()

    def _store_runtime(self, runtime_dict: dict):
        """存储 PyArmor 运行时文件到数据库"""
        self.connection.execute(
            """
            INSERT OR REPLACE INTO pyarmor_runtime 
            (runtime_name, pyd_data, init_data)
            VALUES (?, ?, ?)
        """,
            (
                runtime_dict.get("runtime_name"),
                runtime_dict.get("pyd_data"),
                runtime_dict.get("init_data"),
            ),
        )
        self.connection.commit()

    def get_runtime(self, runtime_name: str) -> Optional[dict]:
        """从数据库获取 PyArmor 运行时文件数据"""
        cursor = self.connection.execute(
            "SELECT runtime_name, pyd_data, init_data FROM pyarmor_runtime WHERE runtime_name = ?",
            (runtime_name,),
        )
        row = cursor.fetchone()
        if row:
            return {
                "runtime_name": row["runtime_name"],
                "pyd_data": row["pyd_data"],
                "init_data": row["init_data"],
            }
        return None

    def list_runtimes(self):
        """列出数据库中的所有 PyArmor 运行时"""
        cursor = self.connection.execute(
            "SELECT runtime_name, created_at FROM pyarmor_runtime ORDER BY id"
        )
        return [dict(row) for row in cursor.fetchall()]

    def add_module_from_file(self, file_path_str: str, module_name: str | None = None):
        """从文件添加模块"""
        file_path = Path(file_path_str)

        if module_name is None:
            # 从文件名推导模块名
            module_name = file_path.stem

        with open(file_path, "r", encoding="utf-8") as f:
            source_code = f.read()

        self.add_module(module_name, source_code)

    def add_package(self, package_path_str: str, package_name: str | None = None):
        """添加整个包到数据库"""
        package_path = Path(package_path_str)

        if package_name is None:
            package_name = package_path.name

        # 添加包目录下的所有.py文件
        for py_file in package_path.rglob("*.py"):
            # 计算模块名
            rel_path = py_file.relative_to(package_path)
            module_parts = list(rel_path.parts)
            module_parts[-1] = module_parts[-1][:-3]  # 去掉.py

            if module_parts[-1] == "__init__":
                # 包本身
                module_name = package_name
                if len(module_parts) > 1:
                    # 子包
                    module_name = f"{package_name}.{'.'.join(module_parts[:-1])}"
                self.add_module(
                    module_name,
                    py_file.read_text(encoding="utf-8"),
                    is_package=True,
                )
            else:
                # 包内的模块
                if len(module_parts) == 1:
                    # 直接子模块
                    module_name = f"{package_name}.{module_parts[0]}"
                else:
                    # 子包内的模块
                    module_name = f"{package_name}.{'.'.join(module_parts)}"

                self.add_module(
                    module_name,
                    py_file.read_text(encoding="utf-8"),
                    is_package=False,
                )
