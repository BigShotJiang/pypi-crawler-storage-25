"""
PyArmor 加密支持模块

为 module_bank 提供 PyArmor 代码混淆/加密能力。
使用 PyArmor CLI 对 Python 源代码进行混淆保护，
并将混淆后的源代码和运行时文件存储到 SQLite 数据库中。
"""

import os
import sys
import tempfile
import shutil
import subprocess
import re
from pathlib import Path
from typing import Optional, Tuple


class PyArmorEncryption:
    """PyArmor 加密处理器，用于混淆/保护 Python 源代码"""

    def __init__(self, key: Optional[str] = None, obf_code: int = 1, obf_mod: int = 1):
        """
        初始化 PyArmor 加密处理器

        Args:
            key: 加密密钥（可选，PyArmor 不使用此参数，保留接口兼容性）
            obf_code: 代码混淆级别 (0/1)
            obf_mod: 模块混淆级别 (0/1)
        """
        self.key = key
        self.obf_code = obf_code
        self.obf_mod = obf_mod

    def obfuscate_source(
        self, source_code: str, module_name: str
    ) -> Tuple[str, Optional[dict]]:
        """
        使用 PyArmor 混淆源代码

        Args:
            source_code: 原始 Python 源代码
            module_name: 模块名

        Returns:
            (混淆后的源代码, PyArmor 运行时数据字典)
            运行时数据字典包含: {
                "runtime_name": "pyarmor_runtime_000000",
                "pyd_data": bytes,
                "init_data": str,
            }
            为 None 表示没有运行时文件
        """
        if not self.check_pyarmor_available():
            raise ImportError(
                "PyArmor 未安装。请使用 'uv add pyarmor' 或 'pip install pyarmor' 安装。"
            )

        temp_dir = tempfile.mkdtemp(prefix=f"pyarmor_pack_")
        try:
            # 创建临时源文件
            src_filename = f"{module_name.replace('.', '_')}.py"
            src_file = os.path.join(temp_dir, src_filename)
            with open(src_file, "w", encoding="utf-8") as f:
                f.write(source_code)

            # 输出目录
            output_dir = os.path.join(temp_dir, "dist")
            os.makedirs(output_dir, exist_ok=True)

            # 调用 pyarmor gen 命令进行混淆
            cmd = [
                sys.executable,
                "-m",
                "pyarmor.cli",
                "gen",
                "-O",
                output_dir,
                "-i",
                src_file,
            ]

            # 添加混淆级别参数
            if self.obf_code == 0:
                cmd.extend(["--obf-code", "0"])
            if self.obf_mod == 0:
                cmd.extend(["--obf-mod", "0"])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=temp_dir,
            )

            if result.returncode != 0:
                raise RuntimeError(f"PyArmor 混淆失败:\n{result.stderr}")

            # 读取混淆后的代码
            obfuscated_file = os.path.join(output_dir, src_filename)
            if not os.path.exists(obfuscated_file):
                raise RuntimeError(f"PyArmor 未生成输出文件: {obfuscated_file}")

            with open(obfuscated_file, "r", encoding="utf-8") as f:
                obfuscated_code = f.read()

            # 查找并读取运行时文件
            runtime_data = self._find_and_read_runtime(output_dir)

            return obfuscated_code, runtime_data

        except Exception as e:
            if isinstance(e, RuntimeError):
                raise
            raise RuntimeError(f"PyArmor 混淆失败 ({module_name}): {e}") from e
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

    def _find_and_read_runtime(self, output_dir: str) -> Optional[dict]:
        """
        查找并读取 PyArmor 运行时文件

        Args:
            output_dir: PyArmor 输出目录

        Returns:
            包含运行时文件的字典: {
                "runtime_name": "pyarmor_runtime_000000",
                "pyd_data": bytes,  # 原生二进制文件
                "init_data": str,   # __init__.py 内容
            }
            如果没有找到则返回 None
        """
        output_path = Path(output_dir)
        # 查找 pyarmor_runtime_* 目录
        runtime_dirs = list(output_path.glob("pyarmor_runtime_*"))
        if not runtime_dirs:
            return None

        runtime_dir = runtime_dirs[0]
        runtime_name = runtime_dir.name

        result = {"runtime_name": runtime_name, "pyd_data": None, "init_data": None}

        # 查找 .pyd 或 .so 文件
        runtime_files = list(runtime_dir.glob("pyarmor_runtime.*"))
        if runtime_files:
            with open(runtime_files[0], "rb") as f:
                result["pyd_data"] = f.read()

        # 读取 __init__.py
        init_file = runtime_dir / "__init__.py"
        if init_file.exists():
            with open(init_file, "r", encoding="utf-8") as f:
                result["init_data"] = f.read()

        return result

    @staticmethod
    def extract_runtime_info(obfuscated_code: str) -> Optional[str]:
        """
        从混淆后的代码中提取运行时模块名

        Args:
            obfuscated_code: 混淆后的源代码

        Returns:
            运行时模块名，如 'pyarmor_runtime_000000'
        """
        match = re.search(
            r"from\s+(pyarmor_runtime_\w+)\s+import\s+__pyarmor__",
            obfuscated_code,
        )
        return match.group(1) if match else None

    @staticmethod
    def is_pyarmor_protected(source_code: str) -> bool:
        """
        检测源代码是否已被 PyArmor 保护

        Args:
            source_code: 要检测的源代码

        Returns:
            是否为 PyArmor 保护的代码
        """
        markers = [
            "pyarmor_runtime",
            "__pyarmor__",
            "from pyarmor_runtime",
        ]
        return any(marker in source_code for marker in markers)

    @staticmethod
    def check_pyarmor_available() -> bool:
        """检查 PyArmor 是否可用"""
        try:
            import pyarmor  # noqa: F401

            return True
        except ImportError:
            return False
