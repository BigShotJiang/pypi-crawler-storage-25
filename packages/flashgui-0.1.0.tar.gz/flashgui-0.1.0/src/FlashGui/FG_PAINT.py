# FlashGUI - Copyright (c) 2026 Robert Opris - Standard License
import wx
import os


class PAINT:
    def __init__(self, title="Paint", size=(2, 2), color=(240, 240, 240), icon=None, maximized=False, min_size=(2, 4), max_size=(1, 1)):
        self.app = wx.App(False)

        self.screen_width, self.screen_height = wx.GetDisplaySize()
        w = int(self.screen_width / float(size[0]))
        h = int(self.screen_height / float(size[1]))

        self.frame = wx.Frame(None, title=title, size=(w, h))
        self.frame.SetBackgroundColour(wx.Colour(*color))
        self.frame.SetMinSize((int(self.screen_width // min_size[0]), int(self.screen_height // min_size[1])))
        self.frame.SetMaxSize((int(self.screen_width // max_size[0]), int(self.screen_height // max_size[1])))

        if maximized:
            self.frame.Maximize(True)

        if icon:
            ext = icon.split('.')[-1].lower()
            icon_type = wx.BITMAP_TYPE_PNG if ext == "png" else wx.BITMAP_TYPE_ICO
            self.frame.SetIcon(wx.Icon(icon, icon_type))

        self.drawing = False
        self.current_tool = "brush"
        self.start_pos = wx.Point(0, 0)
        self.cur_pos = wx.Point(0, 0)
        self.last_pos = wx.Point(0, 0)
        self.canvas_bg = (255, 255, 255)
        self.width_text = "Width"
        self.text_file_png = "PNG files"
        self.text_file_jpg = "JPG files"
        self.title_save_image = "Save Image"
        self.brush_button_id = "brush"
        self.eraser_button_id = "eraser"
        self.line_button_id = "line"
        self.circle_button_id = "circle"
        self.rect_button_id = "rect"
        self.bucket_button_id = "bucket"
        self.brush_button_command = None
        self.eraser_button_command = None
        self.line_button_command = None
        self.circle_button_command = None
        self.rect_button_command = None
        self.bucket_button_command = None
        self.clear_button_command = None
        self.save_button_command = None
        self.color_picker_start_color = (0,0,0)
        self.slider_start_value = 5
        self.slider_from_value = 0
        self.slider_to_value = 100

        self.panel = wx.Panel(self.frame)
        self.main_sizer = wx.BoxSizer(wx.VERTICAL)

        self.toolbar_panel = wx.Panel(self.panel)
        self.toolbar_panel.SetBackgroundColour(wx.Colour(240, 240, 245))
        self.toolbar_sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.canvas_panel = wx.Panel(self.panel)
        self.canvas_panel.SetBackgroundColour(wx.Colour(*self.canvas_bg))
        self.canvas_panel.SetDoubleBuffered(True)
        self.canvas_panel.SetBackgroundStyle(wx.BG_STYLE_PAINT)
        self.canvas_panel.Bind(wx.EVT_ERASE_BACKGROUND, lambda e: None)

        self.buffer = None

        self.setup_toolbar()

        self.main_sizer.Add(self.toolbar_panel, 0, wx.EXPAND)
        self.main_sizer.Add(self.canvas_panel, 1, wx.EXPAND | wx.ALL, 10)

        self.panel.SetSizer(self.main_sizer)

        self.canvas_panel.Bind(wx.EVT_LEFT_DOWN, self.on_mousedown)
        self.canvas_panel.Bind(wx.EVT_LEFT_UP, self.on_mouseup)
        self.canvas_panel.Bind(wx.EVT_MOTION, self.on_mouse_move)
        self.canvas_panel.Bind(wx.EVT_PAINT, self.on_paint)
        self.canvas_panel.Bind(wx.EVT_SIZE, self.on_canvas_resize)

        self._pending_size = None
        self._resize_timer = wx.Timer(self.canvas_panel)
        self.canvas_panel.Bind(wx.EVT_TIMER, self._on_resize_timer, self._resize_timer)

        self._font_resize_timer = wx.Timer(self.frame)
        self.frame.Bind(wx.EVT_TIMER, self._on_font_resize_timer, self._font_resize_timer)
        self.frame.Bind(wx.EVT_SIZE, self._on_frame_resize)
        self.toolbar_panel.Bind(wx.EVT_SIZE, self._on_toolbar_resize)

        wx.CallAfter(self.init_buffer)
        wx.CallAfter(self.update_button_fonts)

        self.frame.Centre()
        self.frame.Show()

    def Edit(
        self,
        brush_button_bg=None, brush_button_fg=None,
        eraser_button_bg=None, eraser_button_fg=None,
        bucket_button_bg=None, bucket_button_fg=None,
        line_button_bg=None, line_button_fg=None,
        circle_button_bg=None, circle_button_fg=None,
        rect_button_bg=None, rect_button_fg=None,
        clear_button_bg=None, clear_button_fg=None,
        save_button_bg=None, save_button_fg=None, toolbar_panel_bg=None,
        canvas_bg=None, brush_button_text=None, eraser_button_text=None,
        bucket_button_text=None, line_button_text=None,
        circle_button_text=None, rect_button_text=None,
        clear_button_text=None, save_button_text=None,
        width_text=None, title_save_image = None, text_file_png = None, text_file_jpg = None
    ):
        text_list = [
            brush_button_text,
            eraser_button_text,
            bucket_button_text,
            line_button_text,
            circle_button_text,
            rect_button_text
        ]

        if brush_button_text is not None:
            self.brush_btn.SetLabel(brush_button_text)
            self.brush_button_id = brush_button_text

        if eraser_button_text is not None:
            self.eraser_btn.SetLabel(eraser_button_text)
            self.eraser_button_id = eraser_button_text

        if bucket_button_text is not None:
            self.bucket_btn.SetLabel(bucket_button_text)
            self.bucket_button_id = bucket_button_text

        if line_button_text is not None:
            self.line_btn.SetLabel(line_button_text)
            self.line_button_id = line_button_text

        if circle_button_text is not None:
            self.circle_btn.SetLabel(circle_button_text)
            self.circle_button_id = circle_button_text

        if rect_button_text is not None:
            self.rect_btn.SetLabel(rect_button_text)
            self.rect_button_id = rect_button_text

        if clear_button_text is not None:
            self.clear_btn.SetLabel(clear_button_text)

        if save_button_text is not None:
            self.save_btn.SetLabel(save_button_text)

        if brush_button_bg is not None:
            self.brush_btn.SetBackgroundColour(wx.Colour(*brush_button_bg))
            self.brush_btn.Refresh()
        if brush_button_fg is not None:
            self.brush_btn.SetForegroundColour(wx.Colour(*brush_button_fg))
            self.brush_btn.Refresh()

        if eraser_button_bg is not None:
            self.eraser_btn.SetBackgroundColour(wx.Colour(*eraser_button_bg))
            self.eraser_btn.Refresh()
        if eraser_button_fg is not None:
            self.eraser_btn.SetForegroundColour(wx.Colour(*eraser_button_fg))
            self.eraser_btn.Refresh()

        if bucket_button_bg is not None:
            self.bucket_btn.SetBackgroundColour(wx.Colour(*bucket_button_bg))
            self.bucket_btn.Refresh()
        if bucket_button_fg is not None:
            self.bucket_btn.SetForegroundColour(wx.Colour(*bucket_button_fg))
            self.bucket_btn.Refresh()

        if line_button_bg is not None:
            self.line_btn.SetBackgroundColour(wx.Colour(*line_button_bg))
            self.line_btn.Refresh()
        if line_button_fg is not None:
            self.line_btn.SetForegroundColour(wx.Colour(*line_button_fg))
            self.line_btn.Refresh()

        if circle_button_bg is not None:
            self.circle_btn.SetBackgroundColour(wx.Colour(*circle_button_bg))
            self.circle_btn.Refresh()
        if circle_button_fg is not None:
            self.circle_btn.SetForegroundColour(wx.Colour(*circle_button_fg))
            self.circle_btn.Refresh()

        if rect_button_bg is not None:
            self.rect_btn.SetBackgroundColour(wx.Colour(*rect_button_bg))
            self.rect_btn.Refresh()
        if rect_button_fg is not None:
            self.rect_btn.SetForegroundColour(wx.Colour(*rect_button_fg))
            self.rect_btn.Refresh()

        if clear_button_bg is not None:
            self.clear_btn.SetBackgroundColour(wx.Colour(*clear_button_bg))
            self.clear_btn.Refresh()
        if clear_button_fg is not None:
            self.clear_btn.SetForegroundColour(wx.Colour(*clear_button_fg))
            self.clear_btn.Refresh()

        if save_button_bg is not None:
            self.save_btn.SetBackgroundColour(wx.Colour(*save_button_bg))
            self.save_btn.Refresh()
        if save_button_fg is not None:
            self.save_btn.SetForegroundColour(wx.Colour(*save_button_fg))
            self.save_btn.Refresh()

        if toolbar_panel_bg is not None:
            self.toolbar_panel.SetBackgroundColour(wx.Colour(*toolbar_panel_bg))
            self.toolbar_panel.Refresh()

        if canvas_bg is not None:
            self.canvas_bg = canvas_bg
            self.canvas_panel.SetBackgroundColour(wx.Colour(*canvas_bg))
            self.buffer = None
            self.init_buffer()
            self.canvas_panel.Refresh()

        if width_text is not None:
            self.width_text = width_text
            self.width_label.SetLabel(f"{self.width_text}: {self.width_slider.GetValue()}")
            self.toolbar_panel.Layout()
            self.panel.Layout()

        if title_save_image is not None:
            self.title_save_image = title_save_image
        if text_file_png is not None:
            self.text_file_png = text_file_png
        if text_file_jpg is not None:
            self.text_file_jpg = text_file_jpg

        self.toolbar_panel.Layout()
        self.panel.Layout()
        wx.CallAfter(self.update_button_fonts)

    def Logic(
        self,
        current_tool="brush",
        color_picker_start_color=(0,0,0),
        slider_start_value=5,
        slider_from_value=0,
        slider_to_value=100,
        brush_button_command=None,
        eraser_button_command=None,
        line_button_command=None,
        circle_button_command=None,
        rect_button_command=None,
        bucket_button_command=None,
        clear_button_command=None,
        save_button_command=None
    ):
        self.current_tool = current_tool
        self.color_picker_start_color = color_picker_start_color
        self.color_picker.SetColour(self.color_picker_start_color)
        self.color_picker.Refresh()

        self.width_slider.SetValue(slider_start_value)
        self.width_slider.SetMin(slider_from_value)
        self.width_slider.SetMax(slider_to_value)
        self.on_width_change(event=None)


        if brush_button_command:
            self.brush_button_command = brush_button_command
            self.brush_btn.Bind(wx.EVT_BUTTON, self.brush_button_command)

        if eraser_button_command:
            self.eraser_button_command = eraser_button_command
            self.eraser_btn.Bind(wx.EVT_BUTTON, self.eraser_button_command)

        if line_button_command:
            self.line_button_command = line_button_command
            self.line_btn.Bind(wx.EVT_BUTTON, self.line_button_command)

        if circle_button_command:
            self.circle_button_command = circle_button_command
            self.circle_btn.Bind(wx.EVT_BUTTON, self.circle_button_command)

        if rect_button_command:
            self.rect_button_command = rect_button_command
            self.rect_btn.Bind(wx.EVT_BUTTON, self.rect_button_command)

        if bucket_button_command:
            self.bucket_button_command = bucket_button_command
            self.bucket_btn.Bind(wx.EVT_BUTTON, self.bucket_button_command)

        if clear_button_command:
            self.clear_button_command = clear_button_command
            self.clear_btn.Bind(wx.EVT_BUTTON, self.clear_button_command)

        if save_button_command:
            self.save_button_command = save_button_command
            self.save_btn.Bind(wx.EVT_BUTTON, self.save_button_command)



    def init_buffer(self):
        size = self.canvas_panel.GetClientSize()
        self.resize_buffer(max(1, size.width), max(1, size.height))

    def resize_buffer(self, w, h):
        if w <= 0 or h <= 0:
            return

        if self.buffer and self.buffer.GetWidth() == w and self.buffer.GetHeight() == h:
            return

        new_bmp = wx.Bitmap(w, h)

        ndc = wx.MemoryDC(new_bmp)
        ndc.SetBackground(wx.Brush(wx.Colour(*self.canvas_bg)))
        ndc.Clear()

        if self.buffer:
            mdc = wx.MemoryDC(self.buffer)
            bw, bh = self.buffer.GetWidth(), self.buffer.GetHeight()

            copy_w = min(bw, w)
            copy_h = min(bh, h)

            ndc.Blit(0, 0, copy_w, copy_h, mdc, 0, 0)
            del mdc

        del ndc
        self.buffer = new_bmp

    # ---------------- TOOLBAR ----------------

    def setup_toolbar(self):
        self.buttons = []

        self.brush_btn = wx.Button(self.toolbar_panel, label="🖌️ Brush")
        self.brush_btn.Bind(wx.EVT_BUTTON, lambda e: self.set_tool(self.brush_button_id))
        self.toolbar_sizer.Add(self.brush_btn, 1, wx.EXPAND | wx.ALL, 5)

        self.eraser_btn = wx.Button(self.toolbar_panel, label="🧽 Eraser")
        self.eraser_btn.Bind(wx.EVT_BUTTON, lambda e: self.set_tool(self.eraser_button_id))
        self.toolbar_sizer.Add(self.eraser_btn, 1, wx.EXPAND | wx.ALL, 5)

        self.bucket_btn = wx.Button(self.toolbar_panel, label="🪣 Bucket")
        self.bucket_btn.Bind(wx.EVT_BUTTON, lambda e: self.set_tool(self.bucket_button_id))
        self.toolbar_sizer.Add(self.bucket_btn, 1, wx.EXPAND | wx.ALL, 5)

        self.line_btn = wx.Button(self.toolbar_panel, label="📏 Line")
        self.line_btn.Bind(wx.EVT_BUTTON, lambda e: self.set_tool(self.line_button_id))
        self.toolbar_sizer.Add(self.line_btn, 1, wx.EXPAND | wx.ALL, 5)

        self.circle_btn = wx.Button(self.toolbar_panel, label="⭕ Circle")
        self.circle_btn.Bind(wx.EVT_BUTTON, lambda e: self.set_tool(self.circle_button_id))
        self.toolbar_sizer.Add(self.circle_btn, 1, wx.EXPAND | wx.ALL, 5)

        self.rect_btn = wx.Button(self.toolbar_panel, label="⬜ Rectangle")
        self.rect_btn.Bind(wx.EVT_BUTTON, lambda e: self.set_tool(self.rect_button_id))
        self.toolbar_sizer.Add(self.rect_btn, 1, wx.EXPAND | wx.ALL, 5)

        # colore base
        for btn in [
            self.brush_btn,
            self.eraser_btn,
            self.bucket_btn,
            self.line_btn,
            self.circle_btn,
            self.rect_btn
        ]:
            btn.SetBackgroundColour(wx.Colour(255, 255, 255))

        self.color_picker = wx.ColourPickerCtrl(self.toolbar_panel, colour=wx.Colour(self.color_picker_start_color))
        self.toolbar_sizer.Add(self.color_picker, 0, wx.CENTER | wx.ALL, 5)

        self.width_label = wx.StaticText(self.toolbar_panel, label=f"{self.width_text}: 5")
        self.toolbar_sizer.Add(self.width_label, 0, wx.CENTER | wx.ALL, 5)

        self.width_slider = wx.Slider(self.toolbar_panel, value=5, minValue=1, maxValue=100)
        self.width_slider.Bind(wx.EVT_SLIDER, self.on_width_change)
        self.toolbar_sizer.Add(self.width_slider, 1, wx.CENTER | wx.ALL, 5)

        self.clear_btn = wx.Button(self.toolbar_panel, label="🧹 Clear")
        self.clear_btn.Bind(wx.EVT_BUTTON, lambda e: self.clear_canvas())
        self.toolbar_sizer.Add(self.clear_btn, 0, wx.CENTER | wx.ALL, 5)

        self.save_btn = wx.Button(self.toolbar_panel, label="💾 Save")
        self.save_btn.Bind(wx.EVT_BUTTON, lambda e: self.save_image_dialog())
        self.toolbar_sizer.Add(self.save_btn, 0, wx.CENTER | wx.ALL, 5)

        self.toolbar_panel.SetSizer(self.toolbar_sizer)
        self.toolbar_panel.Layout()

    def on_width_change(self, event):
        self.width_label.SetLabel(f"{self.width_text}: {self.width_slider.GetValue()}")
        self.toolbar_panel.Layout()
        self.panel.Layout()

    def set_tool(self, name):
        self.current_tool = name

    # ---------------- AUTO FONT RESIZE ----------------

    def _on_frame_resize(self, event):
        self._schedule_font_resize()
        event.Skip()

    def _on_toolbar_resize(self, event):
        self._schedule_font_resize()
        event.Skip()

    def _schedule_font_resize(self):
        if hasattr(self, "_font_resize_timer") and self._font_resize_timer.IsRunning():
            self._font_resize_timer.Stop()
        self._font_resize_timer.Start(80, oneShot=True)

    def _on_font_resize_timer(self, event):
        self.update_button_fonts()

    def update_button_fonts(self):
        controls = []
        if hasattr(self, "buttons"):
            controls.extend(self.buttons)
        if hasattr(self, "clear_btn"):
            controls.append(self.clear_btn)
        if hasattr(self, "save_btn"):
            controls.append(self.save_btn)

        for ctrl in controls:
            self._fit_font_to_control(ctrl)

        self.toolbar_panel.Layout()
        self.panel.Layout()

    def _fit_font_to_control(self, ctrl, min_pt=7, max_pt=28, padding_x=14, padding_y=10):
        if ctrl is None:
            return

        label = ctrl.GetLabel()
        if not label:
            return

        w, h = ctrl.GetClientSize()
        if w <= 0 or h <= 0:
            return

        dc = wx.ClientDC(ctrl)
        base_font = ctrl.GetFont()

        max_pt = min(max_pt, max(8, h - padding_y))
        best_pt = min_pt

        for pt in range(max_pt, min_pt - 1, -1):
            font = wx.Font(base_font)
            font.SetPointSize(pt)
            dc.SetFont(font)
            tw, th = dc.GetTextExtent(label)

            if tw <= (w - padding_x) and th <= (h - padding_y):
                best_pt = pt
                break

        final_font = wx.Font(base_font)
        final_font.SetPointSize(best_pt)
        ctrl.SetFont(final_font)
        ctrl.Refresh(False)

    # ---------------- MOUSE ----------------

    def on_mousedown(self, event):
        pos = event.GetPosition()

        if self.current_tool == str(self.bucket_button_id):
            self.flood_fill(pos.x, pos.y)
            return

        self.drawing = True
        self.start_pos = pos
        self.last_pos = pos
        self.cur_pos = pos

    def on_mouseup(self, event):
        if not self.drawing:
            return

        self.drawing = False

        if self.current_tool in [str(self.line_button_id), str(self.circle_button_id), str(self.rect_button_id)]:
            mdc = wx.MemoryDC(self.buffer)
            gc = wx.GraphicsContext.Create(mdc)

            if gc:
                self.draw_modern_shape(gc, event.GetPosition(), False)

            del mdc
            self.canvas_panel.Refresh()

    def on_mouse_move(self, event):
        if event.Dragging() and event.LeftIsDown() and self.drawing:
            self.cur_pos = event.GetPosition()

            if self.current_tool in [str(self.brush_button_id), str(self.eraser_button_id)]:
                mdc = wx.MemoryDC(self.buffer)
                gc = wx.GraphicsContext.Create(mdc)

                color = self.canvas_bg if self.current_tool == str(self.eraser_button_id) else self.color_picker.GetColour()
                width = self.width_slider.GetValue()

                pen = gc.CreatePen(wx.Pen(color, width))
                gc.SetPen(pen)

                gc.StrokeLine(self.last_pos.x, self.last_pos.y, self.cur_pos.x, self.cur_pos.y)

                self.last_pos = self.cur_pos
                del mdc

            self.canvas_panel.Refresh()

    # ---------------- SHAPES ----------------

    def draw_modern_shape(self, gc, end_pos, is_preview):
        color = self.color_picker.GetColour()
        width = self.width_slider.GetValue()

        if is_preview:
            gc.SetPen(gc.CreatePen(wx.Pen(color, 2, wx.PENSTYLE_SHORT_DASH)))
        else:
            gc.SetPen(gc.CreatePen(wx.Pen(color, width)))

        rect = wx.Rect(
            min(self.start_pos.x, end_pos.x),
            min(self.start_pos.y, end_pos.y),
            abs(self.start_pos.x - end_pos.x),
            abs(self.start_pos.y - end_pos.y)
        )

        if self.current_tool == str(self.line_button_id):
            gc.StrokeLine(self.start_pos.x, self.start_pos.y, end_pos.x, end_pos.y)

        elif self.current_tool == str(self.rect_button_id):
            gc.DrawRectangle(rect.x, rect.y, rect.width, rect.height)

        elif self.current_tool == str(self.circle_button_id):
            gc.DrawEllipse(rect.x, rect.y, rect.width, rect.height)

    # ---------------- PAINT ----------------

    def on_paint(self, event):
        dc = wx.AutoBufferedPaintDC(self.canvas_panel)
        dc.SetBackground(wx.Brush(wx.Colour(*self.canvas_bg)))
        dc.Clear()

        if self.buffer:
            dc.DrawBitmap(self.buffer, 0, 0)

        if self.drawing and self.current_tool in [str(self.line_button_id), str(self.circle_button_id), str(self.rect_button_id)]:
            gc = wx.GraphicsContext.Create(dc)
            if gc:
                self.draw_modern_shape(gc, self.cur_pos, True)

    def flood_fill(self, x, y):
        if self.buffer is None:
            return

        img = self.buffer.ConvertToImage()
        w, h = img.GetSize()

        if x < 0 or y < 0 or x >= w or y >= h:
            return

        target = (img.GetRed(x, y), img.GetGreen(x, y), img.GetBlue(x, y))

        color = self.color_picker.GetColour()
        fill = (color.Red(), color.Green(), color.Blue())

        if target == fill:
            return

        stack = [(x, y)]

        while stack:
            px, py = stack.pop()

            if px < 0 or py < 0 or px >= w or py >= h:
                continue

            r, g, b = img.GetRed(px, py), img.GetGreen(px, py), img.GetBlue(px, py)

            if (r, g, b) != target:
                continue

            img.SetRGB(px, py, *fill)

            stack.append((px + 1, py))
            stack.append((px - 1, py))
            stack.append((px, py + 1))
            stack.append((px, py - 1))

        self.buffer = img.ConvertToBitmap()
        self.canvas_panel.Refresh()

    # ---------------- RESIZE ----------------

    def on_canvas_resize(self, event):
        size = event.GetSize()

        if size.width <= 1 or size.height <= 1:
            event.Skip()
            return

        self._pending_size = (size.width, size.height)
        self._resize_timer.Start(60, oneShot=True)

        event.Skip()

    def _on_resize_timer(self, event):
        if not self._pending_size:
            return

        w, h = self._pending_size
        self.resize_buffer(w, h)
        self.canvas_panel.Refresh()

    # ---------------- UTILS ----------------

    def clear_canvas(self):
        if self.buffer is None:
            return

        dc = wx.MemoryDC(self.buffer)
        dc.SetBackground(wx.Brush(wx.Colour(*self.canvas_bg)))
        dc.Clear()
        del dc

        self.canvas_panel.Refresh()

    def save_image_dialog(self):
        wildcard = f"{self.text_file_png} (*.png)|*.png|{self.text_file_jpg} (*.jpg)|*.jpg"

        dlg = wx.FileDialog(
            self.frame,
            str(self.title_save_image),
            wildcard=wildcard,
            style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT
        )

        if dlg.ShowModal() == wx.ID_CANCEL:
            dlg.Destroy()
            return

        path = dlg.GetPath()
        ext = os.path.splitext(path)[1].lower()

        t = wx.BITMAP_TYPE_PNG if ext == ".png" else wx.BITMAP_TYPE_JPEG

        if self.buffer:
            self.buffer.SaveFile(path, t)

        dlg.Destroy()

    def run(self):
        self.app.MainLoop()