# FlashGUI - Copyright (c) 2026 Robert Opris - Standard License
import wx
import wx.adv
import os
from datetime import datetime

class WINDOW:
    def __init__(self, title="Window", size=(2, 2), color=(240, 240, 240),
                 icon=None, maximized=False, min_size=(5, 4), max_size=(1, 1)):

        self.app = wx.App(False)
        self.title = title
        self.base_color = self._to_colour(color)
        self.widgets = []
        self._named_widgets = {}
        self._pending_resize = None
        self._resize_timer = wx.Timer()
        self._resize_timer.Bind(wx.EVT_TIMER, self._on_resize_timer)

        screen_w, screen_h = wx.GetDisplaySize()
        w = self._calc_size(size[0], screen_w)
        h = self._calc_size(size[1], screen_h)

        self.frame = wx.Frame(None, title=title, size=(w, h))
        self.frame.SetBackgroundColour(self.base_color)

        min_w = self._calc_size(min_size[0], screen_w, as_divisor=True)
        min_h = self._calc_size(min_size[1], screen_h, as_divisor=True)
        max_w = self._calc_size(max_size[0], screen_w, as_divisor=True)
        max_h = self._calc_size(max_size[1], screen_h, as_divisor=True)
        self.frame.SetMinSize((min_w, min_h))
        self.frame.SetMaxSize((max_w, max_h))

        if maximized:
            self.frame.Maximize(True)

        if icon and os.path.exists(icon):
            ext = os.path.splitext(icon)[1].lower()
            icon_type = wx.BITMAP_TYPE_PNG if ext == '.png' else wx.BITMAP_TYPE_ICO
            self.frame.SetIcon(wx.Icon(icon, icon_type))

        self.panel = wx.Panel(self.frame)
        self.panel.SetBackgroundColour(self.base_color)
        self.panel.SetDoubleBuffered(True)

        self.frame.Bind(wx.EVT_SIZE, self._on_frame_size)
        self.frame.Bind(wx.EVT_CLOSE, self._on_close)
        self.frame.Centre()
        self.frame.Show()

    def _calc_size(self, value, screen_dim, as_divisor=False):
        """Converte un valore (divisore o pixel) in pixel."""
        try:
            v = float(value)
        except (TypeError, ValueError):
            v = 1.0
        if v <= 0:
            v = 1.0
        if as_divisor or v <= 20:
            return int(screen_dim / v)
        else:
            return int(v)

    def _to_colour(self, val):
        if isinstance(val, wx.Colour):
            return val
        if isinstance(val, (tuple, list)) and len(val) >= 3:
            return wx.Colour(*val[:3])
        if isinstance(val, str):
            try:
                return wx.Colour(val)
            except:
                pass
        return wx.Colour(240, 240, 240)

    def _on_frame_size(self, event):
        if self._resize_timer.IsRunning():
            self._resize_timer.Stop()
        self._resize_timer.Start(50, oneShot=True)
        event.Skip()

    def _on_resize_timer(self, event):
        if not self.widgets:
            return
        self._apply_proportional_layout()

    def _apply_proportional_layout(self):
        w, h = self.panel.GetClientSize()
        if w <= 0 or h <= 0:
            return

        base_font_size = max(8, int(w * 0.02))

        for item in self.widgets:
            widget = item['widget']
            relx = item.get('relx', 0.0)
            rely = item.get('rely', 0.0)
            relw = item.get('relwidth', 0.1)
            relh = item.get('relheight', 0.1)

            x = int(relx * w)
            y = int(rely * h)
            width = int(relw * w)
            height = int(relh * h)

            width = max(width, 10)
            height = max(height, 10)

            widget.SetSize(x, y, width, height)

            if hasattr(widget, 'SetFont'):
                font = widget.GetFont()
                factor = item.get('font_scale', 1.0)
                new_size = int(base_font_size * factor)
                font.SetPointSize(max(6, new_size))
                widget.SetFont(font)

        self.panel.Refresh()
        self.panel.Layout()

    def _add_widget(self, widget, relx, rely, relwidth, relheight, font_scale=1.0, name=None):
        widget.Reparent(self.panel)
        item = {
            'widget': widget,
            'relx': relx,
            'rely': rely,
            'relwidth': relwidth,
            'relheight': relheight,
            'font_scale': font_scale
        }
        self.widgets.append(item)
        if name:
            self._named_widgets[name] = widget
        self._apply_proportional_layout()
        return widget


    def AddLabel(self, text="Label", relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                 font_scale=1.0, bold=False, color=None, bg=None, name=None):
        lbl = wx.StaticText(self.panel, label=str(text))
        if bold:
            font = lbl.GetFont()
            font.SetWeight(wx.FONTWEIGHT_BOLD)
            lbl.SetFont(font)
        if color:
            lbl.SetForegroundColour(self._to_colour(color))
        if bg:
            lbl.SetBackgroundColour(self._to_colour(bg))
        return self._add_widget(lbl, relx, rely, relwidth, relheight, font_scale, name)

    def AddButton(self, text="Button", relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                  command=None, font_scale=1.0, bold=False, color=None, bg=None, name=None):
        btn = wx.Button(self.panel, label=str(text))
        if bold:
            font = btn.GetFont()
            font.SetWeight(wx.FONTWEIGHT_BOLD)
            btn.SetFont(font)
        if color:
            btn.SetForegroundColour(self._to_colour(color))
        if bg:
            btn.SetBackgroundColour(self._to_colour(bg))
        if command:
            btn.Bind(wx.EVT_BUTTON, lambda e: command())
        return self._add_widget(btn, relx, rely, relwidth, relheight, font_scale, name)

    def AddInput(self, relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                 text="", hint="", password=False, font_scale=1.0, color=None, bg=None, name=None):
        style = wx.TE_PROCESS_ENTER
        if password:
            style |= wx.TE_PASSWORD
        inp = wx.TextCtrl(self.panel, value=str(text), style=style)
        if hint:
            inp.SetHint(hint)
        if color:
            inp.SetForegroundColour(self._to_colour(color))
        if bg:
            inp.SetBackgroundColour(self._to_colour(bg))
        return self._add_widget(inp, relx, rely, relwidth, relheight, font_scale, name)

    def AddTextArea(self, relx=0.0, rely=0.0, relwidth=0.3, relheight=0.2,
                    text="", font_scale=1.0, color=None, bg=None, name=None):
        area = wx.TextCtrl(self.panel, value=str(text),
                           style=wx.TE_MULTILINE | wx.TE_RICH2 | wx.HSCROLL)
        if color:
            area.SetForegroundColour(self._to_colour(color))
        if bg:
            area.SetBackgroundColour(self._to_colour(bg))
        return self._add_widget(area, relx, rely, relwidth, relheight, font_scale, name)

    def AddCounter(self, relx=0.0, rely=0.0, relwidth=0.15, relheight=0.1,
                   min_val=0, max_val=100, start=0, font_scale=1.0, name=None):
        sc = wx.SpinCtrl(self.panel, min=min_val, max=max_val, initial=start)
        return self._add_widget(sc, relx, rely, relwidth, relheight, font_scale, name)

    def AddCalendar(self, relx=0.0, rely=0.0, relwidth=0.4, relheight=0.3, command=None, name=None):
        cal = wx.adv.CalendarCtrl(self.panel)
        if command:
            cal.Bind(wx.adv.EVT_CALENDAR_SEL_CHANGED, lambda e: command(cal.GetDate()))
        return self._add_widget(cal, relx, rely, relwidth, relheight, font_scale=1.0, name=name)

    def AddSlider(self, relx=0.0, rely=0.0, relwidth=0.3, relheight=0.1,
                  min_val=1, max_val=50, start=2, command=None, name=None):
        sld = wx.Slider(self.panel, minValue=min_val, maxValue=max_val, value=start,
                        style=wx.SL_HORIZONTAL | wx.SL_LABELS)
        if command:
            sld.Bind(wx.EVT_SLIDER, lambda e: command(sld.GetValue()))
        return self._add_widget(sld, relx, rely, relwidth, relheight, font_scale=1.0, name=name)

    def AddColorPicker(self, relx=0.0, rely=0.0, relwidth=0.1, relheight=0.1,
                       color="#000000", command=None, name=None):
        cp = wx.ColourPickerCtrl(self.panel, colour=self._to_colour(color))
        if command:
            cp.Bind(wx.EVT_COLOURPICKER_CHANGED,
                    lambda e: command(cp.GetColour().GetAsString(wx.C2S_HTML_SYNTAX)))
        return self._add_widget(cp, relx, rely, relwidth, relheight, font_scale=1.0, name=name)

    def AddCheckBox(self, label="Option", relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                    checked=False, command=None, font_scale=1.0, name=None):
        cb = wx.CheckBox(self.panel, label=str(label))
        cb.SetValue(checked)
        if command:
            cb.Bind(wx.EVT_CHECKBOX, lambda e: command(cb.GetValue()))
        return self._add_widget(cb, relx, rely, relwidth, relheight, font_scale, name)

    def AddRadioButton(self, label="Choice", relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                       group=None, checked=False, command=None, font_scale=1.0, name=None):
        style = 0
        if group:
            pass
        rb = wx.RadioButton(self.panel, label=str(label))
        rb.SetValue(checked)
        if command:
            rb.Bind(wx.EVT_RADIOBUTTON, lambda e: command(rb.GetValue()))
        return self._add_widget(rb, relx, rely, relwidth, relheight, font_scale, name)

    def AddComboBox(self, choices=[], relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                    value="", command=None, font_scale=1.0, name=None):
        cb = wx.ComboBox(self.panel, choices=choices, value=str(value), style=wx.CB_DROPDOWN)
        if command:
            cb.Bind(wx.EVT_COMBOBOX, lambda e: command(cb.GetValue()))
        return self._add_widget(cb, relx, rely, relwidth, relheight, font_scale, name)

    def AddListBox(self, choices=[], relx=0.0, rely=0.0, relwidth=0.2, relheight=0.2,
                   command=None, font_scale=1.0, name=None):
        lb = wx.ListBox(self.panel, choices=choices, style=wx.LB_SINGLE)
        if command:
            lb.Bind(wx.EVT_LISTBOX, lambda e: command(lb.GetStringSelection()))
        return self._add_widget(lb, relx, rely, relwidth, relheight, font_scale, name)

    def AddCanvas(self, relx=0.0, rely=0.0, relwidth=0.5, relheight=0.5, bg="white", name=None):
        canvas = _CanvasPanel(self.panel, bg=self._to_colour(bg))
        return self._add_widget(canvas, relx, rely, relwidth, relheight, font_scale=1.0, name=name)

    def AddTabs(self, relx=0.0, rely=0.0, relwidth=0.5, relheight=0.5, name=None):
        nb = wx.Notebook(self.panel)
        return self._add_widget(nb, relx, rely, relwidth, relheight, font_scale=1.0, name=name)

    def AddPage(self, notebook, title="Page"):
        page = wx.Panel(notebook)
        notebook.AddPage(page, title)
        return page
    def GetWidget(self, name):
        return self._named_widgets.get(name)

    def GetText(self, name):
        w = self.GetWidget(name)
        if w:
            if hasattr(w, 'GetValue'):
                return w.GetValue()
            elif hasattr(w, 'GetLabel'):
                return w.GetLabel()
        return ""

    def SetText(self, name, text):
        w = self.GetWidget(name)
        if w:
            if hasattr(w, 'SetValue'):
                w.SetValue(str(text))
            elif hasattr(w, 'SetLabel'):
                w.SetLabel(str(text))

    def GetValue(self, name):
        w = self.GetWidget(name)
        if w:
            if hasattr(w, 'GetValue'):
                return w.GetValue()
            elif hasattr(w, 'GetLabel'):
                return w.GetLabel()
        return None

    def SetValue(self, name, value):
        w = self.GetWidget(name)
        if w and hasattr(w, 'SetValue'):
            w.SetValue(value)

    def GetSelectedItem(self, name):
        w = self.GetWidget(name)
        if w:
            if isinstance(w, wx.ListBox):
                return w.GetStringSelection()
            elif isinstance(w, wx.ComboBox):
                return w.GetValue()
        return ""

    # -------------------- METODI PER CANVAS --------------------
    def CanvasSetPen(self, name, color=None, width=None):
        canvas = self.GetWidget(name)
        if isinstance(canvas, _CanvasPanel):
            canvas.SetPen(color, width)

    def CanvasClear(self, name, color=None):
        canvas = self.GetWidget(name)
        if isinstance(canvas, _CanvasPanel):
            canvas.Clear(color)

    def AddMenuBar(self):
        self.menu_bar = wx.MenuBar()
        self.frame.SetMenuBar(self.menu_bar)

    def AddMenu(self, title="File"):
        if not hasattr(self, 'menu_bar') or self.menu_bar is None:
            self.AddMenuBar()
        menu = wx.Menu()
        self.menu_bar.Append(menu, title)
        return menu

    def AddMenuItem(self, menu, label="Item", command=None, shortcut=""):
        item_id = wx.NewIdRef()
        item = menu.Append(item_id, label + (f"\t{shortcut}" if shortcut else ""))
        if command:
            self.frame.Bind(wx.EVT_MENU, lambda e: command(), id=item_id)
        if shortcut:
            entry = self._make_accelerator(shortcut, item_id)
            if entry:
                tbl = wx.AcceleratorTable([entry])
                self.frame.SetAcceleratorTable(tbl)
        return item

    def _make_accelerator(self, shortcut, item_id):
        parts = shortcut.upper().split('+')
        flags = 0
        key = None
        for p in parts:
            if p == 'CTRL':
                flags |= wx.ACCEL_CTRL
            elif p == 'ALT':
                flags |= wx.ACCEL_ALT
            elif p == 'SHIFT':
                flags |= wx.ACCEL_SHIFT
            else:
                if len(p) == 1:
                    key = ord(p)
        if key:
            return wx.AcceleratorEntry(flags, key, item_id)
        return None

    def AddStatusBar(self, text="Ready"):
        self.status_bar = self.frame.CreateStatusBar()
        self.status_bar.SetStatusText(text)

    def SetStatusText(self, text, field=0):
        if hasattr(self, 'status_bar') and self.status_bar:
            self.status_bar.SetStatusText(text, field)

    def AddTimer(self, ms=1000, command=None):
        t = wx.Timer(self.frame)
        if command:
            self.frame.Bind(wx.EVT_TIMER, lambda e: command(), t)
        t.Start(ms)
        return t

    def Message(self, text, title="Notice"):
        wx.MessageBox(str(text), str(title), wx.OK | wx.ICON_INFORMATION)

    def AskSave(self, wildcard="All files (*.*)|*.*", default_dir=""):
        with wx.FileDialog(self.frame, "Save as...", default_dir,
                           wildcard=wildcard, style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as dlg:
            if dlg.ShowModal() == wx.ID_OK:
                return dlg.GetPath()
        return None

    def AskOpen(self, wildcard="All files (*.*)|*.*", default_dir=""):
        with wx.FileDialog(self.frame, "Open file", default_dir,
                           wildcard=wildcard, style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as dlg:
            if dlg.ShowModal() == wx.ID_OK:
                return dlg.GetPath()
        return None

    def EnableWidget(self, widget_or_name, enable=True):
        if isinstance(widget_or_name, str):
            w = self.GetWidget(widget_or_name)
        else:
            w = widget_or_name
        if w:
            w.Enable(enable)

    def ShowWidget(self, widget_or_name, show=True):
        if isinstance(widget_or_name, str):
            w = self.GetWidget(widget_or_name)
        else:
            w = widget_or_name
        if w:
            w.Show(show)
            self._apply_proportional_layout()

    def run(self):
        self.app.MainLoop()

    def exit(self):
        self.frame.Close()

    def _on_close(self, event):
        self.frame.Destroy()
        event.Skip()


class _CanvasPanel(wx.Panel):
    def __init__(self, parent, bg=wx.WHITE):
        super().__init__(parent, style=wx.BORDER_NONE)
        self.SetBackgroundColour(bg)
        self.bg = bg
        self.buffer = None
        self.pen_color = wx.BLACK
        self.pen_width = 2
        self.drawing = False
        self.last_pos = None

        self.Bind(wx.EVT_SIZE, self._on_size)
        self.Bind(wx.EVT_LEFT_DOWN, self._on_left_down)
        self.Bind(wx.EVT_LEFT_UP, self._on_left_up)
        self.Bind(wx.EVT_MOTION, self._on_motion)
        self.Bind(wx.EVT_PAINT, self._on_paint)

    def _on_size(self, event):
        size = self.GetClientSize()
        if size.width > 0 and size.height > 0:
            new_bmp = wx.Bitmap(size.width, size.height)
            mdc = wx.MemoryDC(new_bmp)
            mdc.SetBackground(wx.Brush(self.bg))
            mdc.Clear()
            if self.buffer:
                old_dc = wx.MemoryDC(self.buffer)
                mdc.Blit(0, 0, min(size.width, self.buffer.GetWidth()),
                         min(size.height, self.buffer.GetHeight()), old_dc, 0, 0)
            self.buffer = new_bmp
        event.Skip()

    def _on_left_down(self, event):
        self.drawing = True
        self.last_pos = event.GetPosition()
        event.Skip()

    def _on_left_up(self, event):
        self.drawing = False
        self.last_pos = None
        event.Skip()

    def _on_motion(self, event):
        if event.Dragging() and event.LeftIsDown() and self.drawing and self.last_pos and self.buffer:
            pos = event.GetPosition()
            dc = wx.MemoryDC(self.buffer)
            dc.SetPen(wx.Pen(self.pen_color, self.pen_width))
            dc.DrawLine(self.last_pos.x, self.last_pos.y, pos.x, pos.y)
            del dc
            self.last_pos = pos
            self.Refresh()
        event.Skip()

    def _on_paint(self, event):
        if self.buffer:
            wx.BufferedPaintDC(self, self.buffer)

    # Metodi pubblici per il canvas
    def SetPen(self, color=None, width=None):
        if color is not None:
            if isinstance(color, (tuple, list)):
                self.pen_color = wx.Colour(*color[:3])
            else:
                self.pen_color = color
        if width is not None:
            self.pen_width = int(width)

    def Clear(self, color=None):
        if color is not None:
            if isinstance(color, (tuple, list)):
                self.bg = wx.Colour(*color[:3])
            else:
                self.bg = color
        if self.buffer:
            dc = wx.MemoryDC(self.buffer)
            dc.SetBackground(wx.Brush(self.bg))
            dc.Clear()
            del dc
            self.Refresh()