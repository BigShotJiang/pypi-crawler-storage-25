# FlashGUI - Copyright (c) 2026 Robert Opris - Standard License
import wx

class CALCULATOR:
    def __init__(self, title="Calculator", size=(3,2), color=(240,240,240), icon = None, maximized=False, min_size = (5, 4), max_size = (1, 1)):
        self.app = wx.App(False)
        self.title = title
        self.size = size
        self.color = color
        self.message_error = "Error"
        self._eq_button_id = "="
        self._C_button_id = "C"
        self._DEL_button_id = "DEL"
        self._button_0_id = "0"
        self._button_1_id = "1"
        self._button_2_id = "2"
        self._button_3_id = "3"
        self._button_4_id = "4"
        self._button_5_id = "5"
        self._button_6_id = "6"
        self._button_7_id= "7"
        self._button_8_id = "8"
        self._button_9_id = "9"
        self._button_dot_id = "."
        self._button_plus_id = "+"
        self._button_minus_id = "-"
        self._button_mul_id = "*"
        self._button_div_id = "/"

        self._button_0_command = None
        self._button_1_command = None
        self._button_2_command = None
        self._button_3_command = None
        self._button_4_command = None
        self._button_5_command = None
        self._button_6_command = None
        self._button_7_command = None
        self._button_8_command = None
        self._button_9_command = None
        self._button_dot_command = None
        self._button_plus_command = None
        self._button_minus_command = None
        self._button_mul_command = None
        self._button_div_command = None
        self._button_eq_command = None
        self._button_C_command = None
        self._button_DEL_command = None

        self.screen_width, self.screen_height = wx.GetDisplaySize()
        w = int(self.screen_width / float(size[0]))
        h = int(self.screen_height / float(size[1]))

        self.frame = wx.Frame(None, title=self.title, size=(w,h))
        self.frame.SetBackgroundColour(wx.Colour(*self.color))
        self.frame.SetMinSize((int(self.screen_width//min_size[0]), int(self.screen_height//min_size[1])))
        self.frame.SetMaxSize((int(self.screen_width//max_size[0]), int(self.screen_height//max_size[1])))

        if maximized:
            self.frame.Maximize(True)

        if icon:
            ext = icon.split('.')[-1].lower()
            if ext == "png":
                icon_type = wx.BITMAP_TYPE_PNG
            elif ext in ("ico", "ico"):
                icon_type = wx.BITMAP_TYPE_ICO
            else:
                icon_type = wx.BITMAP_TYPE_ANY
            self.frame.SetIcon(wx.Icon(icon, icon_type))

        panel = wx.Panel(self.frame)
        self.panel = panel
        self.expression = ""

        self.display = wx.TextCtrl(panel, style=wx.TE_RIGHT | wx.TE_READONLY | wx.BORDER_NONE)
        self.display.SetMinSize((-1,50))

        main_sizer = wx.BoxSizer(wx.VERTICAL)
        main_sizer.Add(self.display, 0, wx.EXPAND | wx.ALL, 10)

        grid = wx.GridBagSizer(5,5)
        self.buttons = []

        buttons = [
            ("7",0,0,1), ("8",0,1,1), ("9",0,2,1), ("/",0,3,1),
            ("4",1,0,1), ("5",1,1,1), ("6",1,2,1), ("*",1,3,1),
            ("1",2,0,1), ("2",2,1,1), ("3",2,2,1), ("-",2,3,1),
            ("0",3,1,1), (".",3,0,1), ("C",3,2,1), ("+",3,3,1),
            ("=",4,0,3), ("DEL",4,3,1)
        ]

        self.default_button_color = (240,240,240)
        self.equals_button_color = (0,120,215)

        for label,row,col,span_col in buttons:
            btn = wx.Button(panel, label=label)
            btn.Bind(wx.EVT_BUTTON, self.on_button)
            self.buttons.append(btn)
            if label == "=":
                btn.SetBackgroundColour(wx.Colour(*self.equals_button_color))
                btn.SetForegroundColour(wx.WHITE)
            else:
                btn.SetBackgroundColour(wx.Colour(*self.default_button_color))
            grid.Add(btn, pos=(row,col), span=(1,span_col), flag=wx.EXPAND)

        for i in range(5):
            grid.AddGrowableRow(i)
        for i in range(4):
            grid.AddGrowableCol(i)

        main_sizer.Add(grid,1,wx.EXPAND|wx.ALL,10)
        panel.SetSizer(main_sizer)

        self.frame.Bind(wx.EVT_SIZE, self.on_resize)
        self.frame.Centre()
        self.frame.Show()

    def run(self):
        self.app.MainLoop()

    def Logic(self, button_0_command = None, button_1_command = None, button_2_command = None , button_3_command = None, button_4_command = None,
              button_5_command = None, button_6_command = None, button_7_command = None, button_8_command = None , button_9_command = None , button_dot_command = None ,button_minus_command = None,
              button_plus_command = None, button_mul_command = None,button_div_command = None, button_eq_command = None,button_C_command = None,button_DEL_command = None):
        self._button_0_command = button_0_command
        self._button_1_command = button_1_command
        self._button_2_command = button_2_command
        self._button_3_command = button_3_command
        self._button_4_command = button_4_command
        self._button_5_command = button_5_command
        self._button_6_command = button_6_command
        self._button_7_command = button_7_command
        self._button_8_command = button_8_command
        self._button_9_command = button_9_command
        self._button_dot_command = button_dot_command
        self._button_minus_command = button_minus_command
        self._button_plus_command = button_plus_command
        self._button_mul_command = button_mul_command
        self._button_div_command = button_div_command
        self._button_eq_command = button_eq_command
        self._button_C_command = button_C_command
        self._button_DEL_command = button_DEL_command
        

    def GetText(self):
        text = self.display.GetValue()
        return text
    def SetText(self,text = ""):
        self.display.SetValue(str(text))
        self.expression += text
    def AppendText(self, text = ""):
        self.display.AppendText(str(text))
        self.expression += text
    def Clear(self):
        self.display.Clear()
        self.expression = ""
        

    def Edit(
        self,

        button_0_bg=(240,240,240), button_0_fg=(0,0,0), button_0_text="0",
        button_1_bg=(240,240,240), button_1_fg=(0,0,0), button_1_text="1",
        button_2_bg=(240,240,240), button_2_fg=(0,0,0), button_2_text="2",
        button_3_bg=(240,240,240), button_3_fg=(0,0,0), button_3_text="3",
        button_4_bg=(240,240,240), button_4_fg=(0,0,0), button_4_text="4",
        button_5_bg=(240,240,240), button_5_fg=(0,0,0), button_5_text="5",
        button_6_bg=(240,240,240), button_6_fg=(0,0,0), button_6_text="6",
        button_7_bg=(240,240,240), button_7_fg=(0,0,0), button_7_text="7",
        button_8_bg=(240,240,240), button_8_fg=(0,0,0), button_8_text="8",
        button_9_bg=(240,240,240), button_9_fg=(0,0,0), button_9_text="9",

        button_dot_bg=(240,240,240), button_dot_fg=(0,0,0), button_dot_text=".",
        button_plus_bg=(240,240,240), button_plus_fg=(0,0,0), button_plus_text="+",
        button_minus_bg=(240,240,240), button_minus_fg=(0,0,0), button_minus_text="-",
        button_mul_bg=(240,240,240), button_mul_fg=(0,0,0), button_mul_text="*",
        button_div_bg=(240,240,240), button_div_fg=(0,0,0), button_div_text="/",

        button_C_bg=(240,240,240), button_C_fg=(0,0,0), button_C_text="C",
        button_DEL_bg=(240,240,240), button_DEL_fg=(0,0,0), button_DEL_text="DEL",
        button_eq_bg=(0,120,215), button_eq_fg=(255,255,255), button_eq_text="=",

        entry_bg_color=(240,240,240),
        entry_text_color=(0,0,0),

        message_error="Error"
    ):

        self.message_error = message_error
        self._eq_button_id = button_eq_text
        self._C_button_id = button_C_text
        self._DEL_button_id = button_DEL_text

        buttons_info = [
            (button_7_bg, button_7_fg, button_7_text),
            (button_8_bg, button_8_fg, button_8_text),
            (button_9_bg, button_9_fg, button_9_text),
            (button_div_bg, button_div_fg, button_div_text),

            (button_4_bg, button_4_fg, button_4_text),
            (button_5_bg, button_5_fg, button_5_text),
            (button_6_bg, button_6_fg, button_6_text),
            (button_mul_bg, button_mul_fg, button_mul_text),

            (button_1_bg, button_1_fg, button_1_text),
            (button_2_bg, button_2_fg, button_2_text),
            (button_3_bg, button_3_fg, button_3_text),
            (button_minus_bg, button_minus_fg, button_minus_text),

            (button_dot_bg, button_dot_fg, button_dot_text),
            (button_0_bg, button_0_fg, button_0_text),
            (button_C_bg, button_C_fg, button_C_text),
            (button_plus_bg, button_plus_fg, button_plus_text),

            (button_eq_bg, button_eq_fg, button_eq_text),
            (button_DEL_bg, button_DEL_fg, button_DEL_text),
        ]

        for btn, (bg, fg, text) in zip(self.buttons, buttons_info):

            btn.SetBackgroundColour(wx.Colour(*bg))
            btn.SetForegroundColour(wx.Colour(*fg))
            btn.SetLabel(text)

        self.display.SetBackgroundColour(wx.Colour(*entry_bg_color))
        self.display.SetForegroundColour(wx.Colour(*entry_text_color))

        self.frame.Refresh()

    def on_resize(self, event):
        w,h = self.frame.GetClientSize()
        display_font_size = max(20, int(h*0.07))
        button_font_size = max(12, int(h*0.035))
        self.display.SetFont(wx.Font(display_font_size,
                                     wx.FONTFAMILY_DEFAULT,
                                     wx.FONTSTYLE_NORMAL,
                                     wx.FONTWEIGHT_BOLD))
        self.display.SetMinSize((-1, display_font_size*2))
        for btn in self.buttons:
            btn.SetFont(wx.Font(button_font_size,
                                wx.FONTFAMILY_DEFAULT,
                                wx.FONTSTYLE_NORMAL,
                                wx.FONTWEIGHT_BOLD))
        self.frame.Layout()
        event.Skip()

    def on_button(self,event):
        label = event.GetEventObject().GetLabel()
        if label == str(self._eq_button_id):
            if hasattr(self, "_button_eq_command") and self._button_eq_command:
                self._button_eq_command()
            else:
                try:
                    result = str(eval(self.expression))
                    self.display.SetValue(result)
                    self.expression = result
                except:
                    self.display.SetValue(self.message_error)
                    self.expression = ""
        elif label == str(self._C_button_id):
            if hasattr(self, "_button_C_command") and self._button_C_command:
                self._button_C_command()
            else:
                self.expression = ""
                self.display.SetValue("")
        elif label == str(self._DEL_button_id):
            if hasattr(self, "_button_DEL_command") and self._button_DEL_command:
                self._button_DEL_command()
            else:
                self.expression = self.expression[:-1]
                self.display.SetValue(self.expression)
        elif label == str(self._button_0_id) and self._button_0_command != None:
            if hasattr(self, "_button_0_command") and self._button_0_command:
                self._button_0_command()
        elif label == str(self._button_1_id) and self._button_1_command != None:
            if hasattr(self, "_button_1_command") and self._button_1_command:
                self._button_1_command()
        elif label == str(self._button_2_id) and self._button_2_command != None:
            if hasattr(self, "_button_2_command") and self._button_2_command:
                self._button_2_command()
        elif label == str(self._button_3_id) and self._button_3_command != None:
            if hasattr(self, "_button_3_command") and self._button_3_command:
                self._button_3_command()
        elif label == str(self._button_4_id) and self._button_4_command != None:
            if hasattr(self, "_button_4_command") and self._button_4_command:
                self._button_4_command()
        elif label == str(self._button_5_id) and self._button_5_command != None:
            if hasattr(self, "_button_5_command") and self._button_5_command:
                self._button_5_command()
        elif label == str(self._button_6_id) and self._button_6_command != None:
            if hasattr(self, "_button_6_command") and self._button_6_command:
                self._button_6_command()
        elif label == str(self._button_7_id) and self._button_7_command != None:
            if hasattr(self, "_button_7_command") and self._button_7_command:
                self._button_7_command()
        elif label == str(self._button_8_id) and self._button_8_command != None:
            if hasattr(self, "_button_8_command") and self._button_8_command:
                self._button_8_command()
        elif label == str(self._button_9_id) and self._button_9_command != None:
            if hasattr(self, "_button_9_command") and self._button_9_command:
                self._button_9_command()
        elif label == str(self._button_dot_id) and self._button_dot_command != None:
            if hasattr(self, "_button_dot_command") and self._button_dot_command:
                self._button_dot_command()
        elif label == str(self._button_minus_id) and self._button_minus_command != None:
            if hasattr(self, "_button_minus_command") and self._button_minus_command:
                self._button_minus_command()
        elif label == str(self._button_plus_id) and self._button_plus_command != None:
            if hasattr(self, "_button_plus_command") and self._button_plus_command:
                self._button_plus_command()
        elif label == str(self._button_mul_id) and self._button_mul_command != None:
            if hasattr(self, "_button_mul_command") and self._button_mul_command:
                self._button_mul_command()
        elif label == str(self._button_div_id) and self._button_div_command != None:
            if hasattr(self, "_button_div_command") and self._button_div_command:
                self._button_div_command()
        else:
            self.expression += label
            self.display.SetValue(self.expression)