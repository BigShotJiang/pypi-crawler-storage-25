import serial
import serial.tools.list_ports

from modulitiz_nano.ModuloColorText import ModuloColorText
from modulitiz_nano.ModuloDate import ModuloDate
from modulitiz_nano.sistema.EncodingEnum import EncodingEnum


class SerialModule(object):
	"""
	Utility di gestione della connessione seriale / RS232
	"""
	
	def __init__(self):
		self.conn=None
	
	def populate(self,port: str,baudrate: int):
		self.conn=serial.Serial(port,baudrate,timeout=1)
	
	@staticmethod
	def findFirstPortConnected()->str|None:
		ports:list|tuple=serial.tools.list_ports.comports()
		if not ports:
			return None
		return min(ports)[0]
	
	def isOpen(self)->bool:
		"""
		Controlla se la connessione alla porta è aperta.
		"""
		return self.conn is not None and self.conn.isOpen()
	
	def read(self, exitCallback):
		"""
		Reads serial strings and prints it to standard output.
		"""
		try:
			while not exitCallback():
				character=self.conn.read(1).decode(EncodingEnum.UTF8,"replace")
				if character!="\n":
					msg=character
				else:
					msg="\n%s%s >>> %s"%(ModuloDate.dateToString(None,ModuloDate.FORMATO_ORA),ModuloColorText.BLU,ModuloColorText.DEFAULT)
				print(msg,end="",flush=True)
		finally:
			self.close()
	
	def close(self):
		"""
		Chiude la connessione alla porta.
		"""
		if not self.isOpen():
			return
		self.conn.close()
		self.conn=None
