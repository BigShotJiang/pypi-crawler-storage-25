"""FastAPI app-level smoke tests via TestClient."""

import pytest
from fastapi.testclient import TestClient

from surveyshield.serve.app import app


@pytest.fixture
def client() -> TestClient:
    return TestClient(app)


def test_root_health(client: TestClient) -> None:
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "healthy"
    assert body["service"] == "Survey Shield"


def test_survey_health(client: TestClient) -> None:
    r = client.get("/api/v1/survey/health")
    assert r.status_code == 200
    assert r.json()["status"] == "healthy"


def test_config_reflects_env(client: TestClient, monkeypatch: pytest.MonkeyPatch) -> None:
    """`/api/v1/survey/config` returns live_take_enabled=False when neither
    OPENAI_API_KEY nor GOOGLE_API_KEY is set, True when one is."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    r = client.get("/api/v1/survey/config")
    assert r.status_code == 200
    assert r.json() == {"live_take_enabled": False}

    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    r = client.get("/api/v1/survey/config")
    assert r.json() == {"live_take_enabled": True}


def test_unknown_api_path_404s_instead_of_falling_through_to_spa(
    client: TestClient,
) -> None:
    r = client.get("/api/v1/typo")
    assert r.status_code == 404


def test_openapi_docs_reachable(client: TestClient) -> None:
    r = client.get("/openapi.json")
    assert r.status_code == 200
    spec = r.json()
    assert spec["info"]["title"] == "Survey Shield"


def test_rate_limit_fires_on_review_endpoint(client: TestClient) -> None:
    """Empty-file POSTs are rejected 400 *and still count against the cap*,
    so a malicious client can't bypass the limit by sending malformed
    bodies. The 6th and 7th get 429."""
    fake_file = ("file", ("empty.qsf", b"", "application/octet-stream"))

    statuses = [
        client.post("/api/v1/instrument/review", files=[fake_file]).status_code
        for _ in range(7)
    ]
    assert statuses[:5] == [400] * 5
    assert statuses[5] == 429
    assert statuses[6] == 429
