"""Quote-verification + drop_unverified_quotes behavior."""

import logging

import pytest

from surveyshield.models.instrument_review import (
    DimensionReview,
    EditKind,
    Finding,
    Severity,
)
from surveyshield.review.parser import parse_qsf
from surveyshield.review.reviewer import (
    _build_question_haystacks,
    _verify_quote,
    drop_unverified_quotes,
)


def _finding(*, excerpt: str, qid: str | None = None) -> Finding:
    return Finding(
        question_id=qid,
        excerpt=excerpt,
        severity=Severity.MED,
        confidence=0.9,
        rationale="t",
        recommended_edit_kind=EditKind.NONE,
    )


def test_verify_quote_per_question_match(tiny_qsf_bytes: bytes) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    per_q, survey_level = _build_question_haystacks(parsed)

    assert _verify_quote(_finding(qid="QID1", excerpt="how satisfied"), per_q, survey_level)
    # choice labels are part of the haystack
    assert _verify_quote(_finding(qid="QID1", excerpt="Very satisfied"), per_q, survey_level)
    # whitespace + case-folded
    assert _verify_quote(
        _finding(qid="QID1", excerpt="  HOW   SATISFIED  "), per_q, survey_level
    )


def test_verify_quote_rejects_fabricated(tiny_qsf_bytes: bytes) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    per_q, survey_level = _build_question_haystacks(parsed)
    assert not _verify_quote(
        _finding(qid="QID1", excerpt="this phrase never appears"),
        per_q,
        survey_level,
    )


def test_verify_quote_rejects_unknown_qid(tiny_qsf_bytes: bytes) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    per_q, survey_level = _build_question_haystacks(parsed)
    assert not _verify_quote(
        _finding(qid="QID99", excerpt="how satisfied"), per_q, survey_level
    )


def test_verify_quote_survey_level(tiny_qsf_bytes: bytes) -> None:
    """qid=None checks against the union haystack, which includes the survey
    name, description, and every question/choice text."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    per_q, survey_level = _build_question_haystacks(parsed)
    # appears in the description
    assert _verify_quote(_finding(excerpt="two-question instrument"), per_q, survey_level)
    # appears as a choice on QID1
    assert _verify_quote(_finding(excerpt="Somewhat satisfied"), per_q, survey_level)


def test_drop_unverified_quotes(tiny_qsf_bytes: bytes, caplog: pytest.LogCaptureFixture) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    good = _finding(qid="QID1", excerpt="Very satisfied")
    fabricated = _finding(qid="QID1", excerpt="MADE UP PHRASE")
    unknown_qid = _finding(qid="QID42", excerpt="how satisfied")

    review = DimensionReview(
        dimension="attention_checks",
        score=50.0,
        findings=[good, fabricated, unknown_qid],
        summary="",
        model="test",
        duration_seconds=0.1,
    )
    errored = DimensionReview(
        dimension="identity_questions",
        score=0.0,
        findings=[],
        summary="(failed)",
        model="test",
        duration_seconds=0.0,
        error="boom",
    )

    with caplog.at_level(logging.WARNING, logger="surveyshield.review.reviewer"):
        out = drop_unverified_quotes([review, errored], parsed)

    assert out[0].findings == [good]
    # errored review is left alone
    assert out[1].error == "boom"
    # one warning per drop
    assert sum("dropping unverified" in r.message for r in caplog.records) == 2
