"""CLI smoke tests — review pipeline mocked so no LLM is hit."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from surveyshield.cli import app
from surveyshield.models.instrument_review import (
    DimensionReview,
    InstrumentReview,
    OverallFeedback,
)
from surveyshield.review.parser import parse_qsf, summarize

runner = CliRunner()


def test_version() -> None:
    from surveyshield import __version__

    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "surveyshield" in result.stdout
    assert __version__ in result.stdout


def _stub_review(parsed) -> InstrumentReview:
    return InstrumentReview(
        review_id="stub",
        filename="tiny.qsf",
        timestamp=datetime(2026, 1, 1),
        overall_score=42.0,
        completion_likelihood=58.0,
        parsed_summary=summarize(parsed),
        dimensions=[
            DimensionReview(dimension="attention_checks", score=42.0,
                            findings=[], summary="", model="stub",
                            duration_seconds=0.0)
        ],
        recommendations=[],
        overall_feedback=OverallFeedback(headline="Stub headline", paragraphs=[]),
        narrative_summary="stub narrative",
        methods_statement="stub methods",
        parameters={"model": "stub", "dimension_set_version": "test"},
    )


def test_review_writes_html_and_json(
    tmp_path: Path, tiny_qsf_path: Path, tiny_qsf_bytes: bytes
) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    stub = _stub_review(parsed)

    async def fake_review_qsf(*args, **kwargs):
        return stub, parsed

    out_html = tmp_path / "report.html"
    out_json = tmp_path / "review.json"

    with patch("surveyshield.review.reviewer.review_qsf", side_effect=fake_review_qsf):
        result = runner.invoke(
            app,
            [
                "review", str(tiny_qsf_path),
                "--output", str(out_html),
                "--json", str(out_json),
                "--model", "stub-model",
            ],
        )

    assert result.exit_code == 0, result.stdout
    assert out_html.exists()
    assert "<html" in out_html.read_text()
    assert out_json.exists()
    assert '"overall_score": 42' in out_json.read_text()
    assert "Stub headline" in result.stdout


def test_review_default_output_path(tmp_path: Path, tiny_qsf_bytes: bytes) -> None:
    """When --output is omitted the report lands next to the input as
    <stem>.report.html."""
    qsf_copy = tmp_path / "small.qsf"
    qsf_copy.write_bytes(tiny_qsf_bytes)
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    stub = _stub_review(parsed)

    async def fake_review_qsf(*args, **kwargs):
        return stub, parsed

    with patch("surveyshield.review.reviewer.review_qsf", side_effect=fake_review_qsf):
        result = runner.invoke(app, ["review", str(qsf_copy)])

    assert result.exit_code == 0, result.stdout
    expected = qsf_copy.with_suffix("").with_suffix(".report.html")
    assert expected.exists()
