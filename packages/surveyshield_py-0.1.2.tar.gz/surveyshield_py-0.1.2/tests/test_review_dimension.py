"""review_dimension + consolidate_and_summarize with the LLM mocked out."""

from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import patch

import pytest

from surveyshield.models.instrument_review import (
    EditKind,
    Finding,
    OverallFeedback,
    Severity,
)
from surveyshield.review.dimensions import DIMENSIONS, DimensionOutput
from surveyshield.review.parser import parse_qsf
from surveyshield.review.reviewer import (
    ConsolidationResult,
    consolidate_and_summarize,
    review_dimension,
)


class _StubStructured:
    """Stands in for `_make_llm(...).with_structured_output(...)`."""

    def __init__(self, return_value: Any) -> None:
        self._rv = return_value

    async def ainvoke(self, prompt: str) -> Any:  # noqa: ARG002
        return self._rv


class _StubLLM:
    def __init__(self, return_value: Any) -> None:
        self._rv = return_value

    def with_structured_output(self, schema: type) -> _StubStructured:  # noqa: ARG002
        return _StubStructured(self._rv)


def _good_finding() -> Finding:
    return Finding(
        question_id="QID1",
        excerpt="how satisfied",
        severity=Severity.HIGH,
        confidence=0.9,
        rationale="r",
        recommended_edit_kind=EditKind.ADD_ATTENTION_CHECK,
    )


def test_review_dimension_clamps_score_and_records_duration() -> None:
    """Reviewer over-shoots score=200 → clamped to 100, duration_seconds set."""
    out = DimensionOutput(score=200.0, findings=[_good_finding()], summary="ok")

    with patch(
        "surveyshield.review.reviewer._make_llm", return_value=_StubLLM(out)
    ):
        result = asyncio.run(
            review_dimension("survey_blob", DIMENSIONS[0], model="gpt-4o-mini")
        )

    assert result.score == 100.0
    assert result.findings == [out.findings[0]]
    assert result.summary == "ok"
    assert result.duration_seconds >= 0.0
    assert result.error is None


def test_review_dimension_captures_exceptions() -> None:
    """A raised exception inside the LLM call is captured into `.error`,
    never re-raised — one stuck dimension shouldn't poison the review."""

    class _Boom:
        def with_structured_output(self, schema: type) -> Any:  # noqa: ARG002
            class _BoomSO:
                async def ainvoke(self, prompt: str) -> Any:  # noqa: ARG002
                    raise RuntimeError("provider down")
            return _BoomSO()

    with patch("surveyshield.review.reviewer._make_llm", return_value=_Boom()):
        result = asyncio.run(
            review_dimension("blob", DIMENSIONS[0], model="gpt-4o-mini")
        )

    assert result.error is not None and "RuntimeError" in result.error
    assert result.score == 0.0
    assert result.findings == []


def test_review_dimension_timeout() -> None:
    """asyncio.TimeoutError → graceful 0-score DimensionReview with .error set."""

    class _Slow:
        def with_structured_output(self, schema: type) -> Any:  # noqa: ARG002
            class _SlowSO:
                async def ainvoke(self, prompt: str) -> Any:  # noqa: ARG002
                    await asyncio.sleep(10)
                    return None
            return _SlowSO()

    with patch("surveyshield.review.reviewer._make_llm", return_value=_Slow()):
        result = asyncio.run(
            review_dimension("blob", DIMENSIONS[0], model="gpt-4o-mini", timeout=0.05)
        )

    assert result.error is not None and "timeout" in result.error.lower()


def test_consolidate_short_circuits_when_no_findings(tiny_qsf_bytes: bytes) -> None:
    """If every successful reviewer reported zero findings, consolidation
    returns a stub OverallFeedback without calling the LLM."""
    from surveyshield.models.instrument_review import DimensionReview

    parsed, _ = parse_qsf(tiny_qsf_bytes)  # noqa: F841
    reviews = [
        DimensionReview(dimension=d.name, score=80.0, findings=[], summary="",
                        model="m", duration_seconds=0.0)
        for d in DIMENSIONS[:2]
    ]
    result = asyncio.run(
        consolidate_and_summarize("blob", reviews, model="gpt-4o-mini")
    )
    assert isinstance(result, ConsolidationResult)
    assert result.consolidated_findings == []
    assert "No dimension surfaced" in result.overall_feedback.headline


def test_consolidate_returns_none_on_llm_error() -> None:
    """LLM error → consolidation returns None so aggregate falls back."""
    from surveyshield.models.instrument_review import DimensionReview

    reviews = [
        DimensionReview(
            dimension=DIMENSIONS[0].name, score=40.0,
            findings=[_good_finding()],
            summary="", model="m", duration_seconds=0.0,
        )
    ]

    class _Boom:
        def with_structured_output(self, schema: type) -> Any:  # noqa: ARG002
            class _BoomSO:
                async def ainvoke(self, prompt: str) -> Any:  # noqa: ARG002
                    raise RuntimeError("nope")
            return _BoomSO()

    with patch("surveyshield.review.reviewer._make_llm", return_value=_Boom()):
        result = asyncio.run(
            consolidate_and_summarize("blob", reviews, model="gpt-4o-mini")
        )

    assert result is None


def test_consolidate_returns_llm_output_on_success() -> None:
    from surveyshield.models.instrument_review import DimensionReview

    reviews = [
        DimensionReview(
            dimension=DIMENSIONS[0].name, score=40.0,
            findings=[_good_finding()],
            summary="", model="m", duration_seconds=0.0,
        )
    ]
    expected = ConsolidationResult(
        consolidated_findings=[_good_finding()],
        overall_feedback=OverallFeedback(headline="H", paragraphs=["P"]),
    )

    with patch(
        "surveyshield.review.reviewer._make_llm", return_value=_StubLLM(expected)
    ):
        result = asyncio.run(
            consolidate_and_summarize("blob", reviews, model="gpt-4o-mini")
        )

    assert result == expected
