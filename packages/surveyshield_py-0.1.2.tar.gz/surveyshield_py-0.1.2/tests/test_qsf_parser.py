"""Parser shape + tolerance tests."""

import json

import pytest

from surveyshield.review.parser import QSFParseError, parse_qsf, summarize


def test_parses_tiny_fixture(tiny_qsf_bytes: bytes) -> None:
    parsed, raw_dict = parse_qsf(tiny_qsf_bytes)
    assert parsed.name == "Tiny Test Survey"
    assert len(parsed.questions) == 2
    assert len(parsed.blocks) == 1

    qids = [q.qid for q in parsed.questions]
    assert qids == ["QID1", "QID2"]

    q1 = parsed.questions[0]
    assert q1.text == "How satisfied are you with the product?"
    assert q1.choices == ["Very satisfied", "Somewhat satisfied", "Not satisfied"]
    assert q1.force_response is False
    assert q1.type == "MC"

    q2 = parsed.questions[1]
    assert q2.force_response is True

    block = parsed.blocks[0]
    assert block.question_ids == ["QID1", "QID2"]

    # raw_dict must round-trip the SurveyEntry — Phase 2's QSF writer needs it.
    assert raw_dict["SurveyEntry"]["SurveyID"] == "SV_test_tiny"


def test_summarize_metrics(tiny_qsf_bytes: bytes) -> None:
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    s = summarize(parsed)
    assert s["n_questions"] == 2
    assert s["n_blocks"] == 1
    assert s["force_response_pct"] == 50.0
    assert s["type_histogram"] == {"MC": 1, "TE": 1}


def test_rejects_non_json() -> None:
    with pytest.raises(QSFParseError, match="not valid JSON"):
        parse_qsf(b"<html>nope</html>")


def test_rejects_non_qsf_json() -> None:
    with pytest.raises(QSFParseError, match="not a Qualtrics QSF"):
        parse_qsf(b'{"hello": "world"}')


def test_tolerates_dict_block_payload(tiny_qsf_bytes: bytes) -> None:
    """BL.Payload sometimes appears as a dict keyed by stringified ints
    instead of a list. Mutate the fixture to that shape and verify it still
    parses without losing the block."""
    raw = json.loads(tiny_qsf_bytes)
    for el in raw["SurveyElements"]:
        if el["Element"] == "BL":
            el["Payload"] = {"0": el["Payload"][0]}
            break
    parsed, _ = parse_qsf(json.dumps(raw).encode())
    assert len(parsed.blocks) == 1
    assert parsed.blocks[0].block_id == "BL_test"


@pytest.mark.parametrize("validation", [None, "", {"Settings": {}}])
def test_tolerates_validation_variants(tiny_qsf_bytes: bytes, validation) -> None:
    """`Validation` has been observed as None, dict, or a bare string in the
    wild. None of those should crash the parser."""
    raw = json.loads(tiny_qsf_bytes)
    for el in raw["SurveyElements"]:
        if el["Element"] == "SQ":
            el["Payload"]["Validation"] = validation
    parsed, _ = parse_qsf(json.dumps(raw).encode())
    assert len(parsed.questions) == 2
