"""Deterministic aggregate() tests — no LLM, just shape + math."""

from surveyshield.models.instrument_review import (
    DimensionReview,
    EditKind,
    Finding,
    OverallFeedback,
    Severity,
)
from surveyshield.review.parser import parse_qsf
from surveyshield.review.reviewer import ConsolidationResult, aggregate


def _review(name: str, score: float, *findings: Finding, error: str | None = None) -> DimensionReview:
    return DimensionReview(
        dimension=name,
        score=score,
        findings=list(findings),
        summary="",
        model="test",
        duration_seconds=0.0,
        error=error,
    )


def _finding(qid: str | None, kind: EditKind, severity: Severity = Severity.HIGH) -> Finding:
    return Finding(
        question_id=qid,
        excerpt="some excerpt",
        severity=severity,
        confidence=0.9,
        rationale="r",
        suggested_fix="f",
        recommended_edit_kind=kind,
    )


def test_no_findings_path(tiny_qsf_bytes: bytes) -> None:
    """When every reviewer succeeded with no findings, overall_score is the
    weighted mean of the dimension scores and recommendations are empty."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [
        _review("attention_checks", 80.0),
        _review("identity_questions", 60.0),
    ]
    result = aggregate(
        parsed,
        reviews,
        review_id="abc",
        filename="t.qsf",
        parsed_summary={"name": "t"},
        model="m",
    )
    # equal weights → simple mean
    assert abs(result.overall_score - 70.0) < 0.1
    assert result.recommendations == []
    assert result.review_id == "abc"
    assert result.parameters["model"] == "m"


def test_completion_likelihood_is_inverse_of_defense(tiny_qsf_bytes: bytes) -> None:
    """Low defense score → high completion likelihood for an automated agent."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    weak = [_review("attention_checks", 10.0), _review("identity_questions", 20.0)]
    strong = [_review("attention_checks", 90.0), _review("identity_questions", 95.0)]

    weak_out = aggregate(
        parsed, weak, review_id="w", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    strong_out = aggregate(
        parsed, strong, review_id="s", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    assert weak_out.completion_likelihood > strong_out.completion_likelihood
    assert weak_out.completion_likelihood > 50
    assert strong_out.completion_likelihood < 50


def test_all_reviews_errored_returns_empty_picture(tiny_qsf_bytes: bytes) -> None:
    """If every reviewer errored, overall_score collapses to 0 and the
    methods statement still composes — never raises."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [
        _review("attention_checks", 0.0, error="timeout"),
        _review("identity_questions", 0.0, error="boom"),
    ]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    assert result.overall_score == 0.0
    assert "Review ID: x" in result.methods_statement


def test_fallback_dedup_by_kind_and_qid(tiny_qsf_bytes: bytes) -> None:
    """When consolidation is None, recommendations dedup by (edit_kind, qid)
    and credit each contributing dimension."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    same_fix_dim_a = _finding("QID1", EditKind.ADD_ATTENTION_CHECK)
    same_fix_dim_b = _finding("QID1", EditKind.ADD_ATTENTION_CHECK)
    different_qid = _finding("QID2", EditKind.ADD_ATTENTION_CHECK)
    reviews = [
        _review("attention_checks", 40.0, same_fix_dim_a),
        _review("identity_questions", 50.0, same_fix_dim_b, different_qid),
    ]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    # one merged rec for QID1, one fresh for QID2 — two total
    assert len(result.recommendations) == 2
    qid1_rec = next(r for r in result.recommendations if "QID1" in r.title)
    assert set(qid1_rec.related_dimensions) == {"attention_checks", "identity_questions"}


def test_consolidation_path_uses_overall_feedback(tiny_qsf_bytes: bytes) -> None:
    """When the second-stage LLM produced a ConsolidationResult, its
    overall_feedback is stored verbatim and its findings drive the recs."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [_review("attention_checks", 40.0, _finding("QID1", EditKind.ADD_ATTENTION_CHECK))]
    consolidation = ConsolidationResult(
        consolidated_findings=[
            Finding(
                question_id="QID1",
                excerpt="some excerpt",
                severity=Severity.HIGH,
                confidence=0.9,
                rationale="merged",
                suggested_fix="add an IMC",
                recommended_edit_kind=EditKind.ADD_ATTENTION_CHECK,
                contributing_dimensions=["attention_checks", "identity_questions"],
            )
        ],
        overall_feedback=OverallFeedback(
            headline="A short verdict",
            paragraphs=["A short paragraph."],
        ),
    )
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
        consolidation=consolidation,
    )
    assert result.overall_feedback.headline == "A short verdict"
    assert len(result.recommendations) == 1
    assert set(result.recommendations[0].related_dimensions) == {
        "attention_checks", "identity_questions"
    }


def test_unknown_dimension_weight_is_one(tiny_qsf_bytes: bytes) -> None:
    """A reviewer that reports a dimension name not in the registry should
    not crash aggregate (defaults to weight=1.0, completion_weight=0.0)."""
    parsed, _ = parse_qsf(tiny_qsf_bytes)
    reviews = [_review("not_a_real_dimension", 50.0)]
    result = aggregate(
        parsed, reviews, review_id="x", filename="t.qsf",
        parsed_summary={}, model="m",
    )
    assert result.overall_score == 50.0
