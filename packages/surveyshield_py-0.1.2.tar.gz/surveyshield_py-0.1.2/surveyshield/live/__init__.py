"""Live runtime — drives a real browser through a Qualtrics survey.

Requires the optional dependency: ``pip install surveyshield-py[live]``.
If browser-use isn't installed, importing this subpackage raises
``ImportError`` which the top-level ``surveyshield/__init__.py`` catches,
binding ``surveyshield.take_survey = None``.
"""

import os
from typing import Optional

from surveyshield._providers import provider_env_var
from surveyshield.live.analyzer import SurveyAnalyzer
from surveyshield.models.survey_result import SurveyAnalysisResult


async def take_survey(
    url: str,
    *,
    model: str = "gemini-3-flash-preview",
    api_key: Optional[str] = None,
    max_steps: int = 150,
    use_vision: bool = True,
    verbose: bool = False,
) -> SurveyAnalysisResult:
    """Drive a live browser through a survey URL.

    The reviewer-style instrument review runs entirely server-side and
    requires no browser. Use this only when you need to exercise a real
    survey end-to-end against a live URL.

    ``api_key`` is written into the right env var for ``model`` (Gemini
    models use ``GOOGLE_API_KEY``; everything else uses ``OPENAI_API_KEY``).
    Pass ``None`` to rely on the env / a ``.env`` loaded by python-dotenv.
    """
    if api_key:
        os.environ[provider_env_var(model)] = api_key

    analyzer = SurveyAnalyzer(
        model_name=model,
        max_steps=max_steps,
        use_vision=use_vision,
        verbose=verbose,
    )
    return await analyzer.analyze_survey(survey_url=url)


__all__ = ["take_survey", "SurveyAnalyzer"]
