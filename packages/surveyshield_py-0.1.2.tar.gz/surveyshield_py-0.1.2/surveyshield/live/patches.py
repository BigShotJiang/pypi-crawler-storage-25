"""Runtime monkey-patches applied to browser-use internals.

Two patches, applied at the start of `SurveyAnalyzer.analyze_survey()`:

- `apply_cdp_timeout_patch()` extends Chromium's CDP-readiness wait to 120s
  (browser-use's default 30s is too short for Heroku dyno cold starts).
- `apply_human_typing_patch(browser)` slows browser-use's near-instant typing
  (~1ms/char, superhuman) to a configurable 80-150ms/char with random pauses.

The typing patch's closure captures the live `browser` instance, so each
analysis re-installs a fresh closure. To avoid building a fallback chain of
dead-browser closures across analyses, the *true* original implementations are
captured once at first patch application and re-used as the stable fallback.
"""

import asyncio
import logging
import os
import random
from typing import Optional

import aiohttp

logger = logging.getLogger(__name__)

# Captured on first patch application; reused as the stable fallback so
# successive `apply_*_patch()` calls don't chain through prior closures.
_real_input_text = None


def apply_cdp_timeout_patch(timeout_seconds: float = 120.0) -> None:
    """Patch LocalBrowserWatchdog._wait_for_cdp_url to use an extended timeout."""
    from browser_use.browser.watchdogs.local_browser_watchdog import LocalBrowserWatchdog

    @staticmethod
    async def _wait_for_cdp_url_patched(port: int, timeout: float = timeout_seconds) -> str:
        start_time = asyncio.get_event_loop().time()
        attempt_count = 0
        last_error = None

        logger.info(f"[CDP] Waiting for CDP endpoint on port {port} (timeout: {timeout}s)")

        while asyncio.get_event_loop().time() - start_time < timeout:
            attempt_count += 1
            elapsed = asyncio.get_event_loop().time() - start_time

            if attempt_count % 100 == 0:
                logger.info(
                    f"[CDP] Still waiting... {elapsed:.1f}s elapsed, "
                    f"attempt #{attempt_count}, last_error: {last_error}"
                )

            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=2)) as session:
                    async with session.get(f"http://localhost:{port}/json/version") as resp:
                        if resp.status == 200:
                            logger.info(
                                f"[CDP] Success! CDP endpoint responded after "
                                f"{elapsed:.1f}s and {attempt_count} attempts"
                            )
                            return f"http://localhost:{port}/"
                        last_error = f"HTTP {resp.status}"
                        await asyncio.sleep(0.1)
            except Exception as e:
                last_error = type(e).__name__
                await asyncio.sleep(0.1)

        logger.error(
            f"[CDP] Timeout after {timeout}s and {attempt_count} attempts. "
            f"Last error: {last_error}"
        )
        raise TimeoutError(
            f"Browser did not start within {timeout} seconds (last error: {last_error})"
        )

    LocalBrowserWatchdog._wait_for_cdp_url = _wait_for_cdp_url_patched


def apply_human_typing_patch(
    browser,
    min_delay: Optional[float] = None,
    max_delay: Optional[float] = None,
    verbose: bool = False,
) -> None:
    """Patch DefaultActionWatchdog._input_text_element_node_impl to type at human speed.

    Reads TYPING_DELAY_MIN / TYPING_DELAY_MAX from env when explicit args are None
    (defaults: 80-150ms per character).
    """
    global _real_input_text
    from browser_use.browser.watchdogs.default_action_watchdog import DefaultActionWatchdog

    # Capture the real implementation only on first application — successive
    # calls would otherwise rebind to the previously-patched closure (stale
    # browser ref, growing fallback chain, leaked Browser graphs).
    if _real_input_text is None:
        _real_input_text = DefaultActionWatchdog._input_text_element_node_impl

    if min_delay is None:
        min_delay = float(os.getenv("TYPING_DELAY_MIN", "0.08"))
    if max_delay is None:
        max_delay = float(os.getenv("TYPING_DELAY_MAX", "0.15"))

    async def human_like_input_text(
        self, element_node, text: str, clear: bool = True, is_sensitive: bool = False
    ):
        try:
            page = await browser.get_current_page()
            if not page:
                logger.warning("human-typing patch: no current page, falling back to default impl")
                return await _real_input_text(self, element_node, text, clear, is_sensitive)

            element_index = element_node.get("index") or element_node.get("nodeId")

            try:
                element = await browser.get_element_by_index(element_index)

                if element and hasattr(element, "selector"):
                    if clear:
                        await page.fill(element.selector, "")
                        await asyncio.sleep(0.05)

                    for i, char in enumerate(text):
                        await page.type(element.selector, char, delay=0)
                        delay = random.uniform(min_delay, max_delay)
                        # Longer pause after punctuation, or every 15-25 chars.
                        if char in ".,!?;:" or (i > 0 and i % random.randint(15, 25) == 0):
                            delay += random.uniform(0.1, 0.3)
                        await asyncio.sleep(delay)
                    return
                logger.warning(
                    "human-typing patch: element has no selector attr, "
                    "falling back to default impl"
                )
                return await _real_input_text(self, element_node, text, clear, is_sensitive)

            except Exception as e:
                logger.warning(
                    f"human-typing patch: playwright path failed ({type(e).__name__}: {e}), "
                    f"falling back to default impl"
                )
                return await _real_input_text(self, element_node, text, clear, is_sensitive)

        except Exception as e:
            logger.warning(
                f"human-typing patch: outer failure ({type(e).__name__}: {e}), "
                f"falling back to default impl"
            )
            return await _real_input_text(self, element_node, text, clear, is_sensitive)

    DefaultActionWatchdog._input_text_element_node_impl = human_like_input_text

    if verbose:
        print(
            f"⌨️  Human-like typing enabled: "
            f"{min_delay*1000:.0f}-{max_delay*1000:.0f}ms per character"
        )
