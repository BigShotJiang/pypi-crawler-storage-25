"""Effective survey analyzer using specific prompting techniques."""

import asyncio
import os
import time
import tempfile
import requests
from typing import Optional, List
from datetime import datetime
from urllib.parse import urlparse
from pathlib import Path

from browser_use import Agent, Browser, BrowserProfile, ChatOpenAI, ChatGoogle, Tools, ActionResult
from dotenv import load_dotenv
from openai import OpenAI

from surveyshield.models.survey_result import (
    SurveyAnalysisResult,
    BotDetectionMechanism,
    BotDetectionType
)
from surveyshield.review.mechanism_context import MECHANISM_CONTEXT
from .patches import apply_cdp_timeout_patch, apply_human_typing_patch
from .prompts import build_task_prompt

# Best-effort .env loading: walks up from cwd to find a `.env` file (so
# `cd backend && uvicorn ...` and `cd repo-root && surveyshield serve`
# both pick up local keys). Heroku-style deploys inject env directly.
load_dotenv()

class SurveyAnalyzer:
    """Effective AI agent that analyzes surveys using browser automation with specific prompting."""

    # Mechanism severity weights (1-10 scale, where 10 is most difficult).
    MECHANISM_SEVERITY = {
        BotDetectionType.CAPTCHA: 10,
        BotDetectionType.REVERSE_SHIBBOLETH: 9,
        BotDetectionType.MOUSE_TRACKING: 8,
        BotDetectionType.IDENTITY_QUESTION: 7,
        BotDetectionType.HOVER_TRAP: 7,
        BotDetectionType.TIMING_TRAP: 6,
        BotDetectionType.AUDIO_VIDEO_QUESTION: 6,
        BotDetectionType.LOGIC_PUZZLE: 5,
        BotDetectionType.INVISIBLE_TEXT: 5,
        BotDetectionType.READING_COMPREHENSION: 4,
        BotDetectionType.ATTENTION_CHECK: 4,
        BotDetectionType.INSTRUCTION_FOLLOWING: 3,
        BotDetectionType.IMPOSSIBLE_EVENT: 2,
        BotDetectionType.HONEYPOT_FIELD: 2,
        BotDetectionType.OTHER: 5,
    }

    # Default response_method strings — how the agent typically handles each
    # mechanism. HOVER_TRAP and AUDIO_VIDEO_QUESTION are handled inline because
    # their methods depend on evidence in the agent's history.
    RESPONSE_METHODS = {
        BotDetectionType.IDENTITY_QUESTION: "Responded with human identity claim",
        BotDetectionType.REVERSE_SHIBBOLETH: "Responded with strategic refusal or uncertainty",
        BotDetectionType.IMPOSSIBLE_EVENT: "Responded with rejection of impossible claims",
        BotDetectionType.LOGIC_PUZZLE: "Attempted logical reasoning",
        BotDetectionType.READING_COMPREHENSION: "Attempted text comprehension and analysis",
        BotDetectionType.INSTRUCTION_FOLLOWING: "Attempted to follow embedded instructions",
        BotDetectionType.ATTENTION_CHECK: "Attempted pattern recognition and answer selection",
        BotDetectionType.TIMING_TRAP: "Applied timing delays during navigation",
    }


    def __init__(
        self,
        model_name: str = "gemini-3-flash-preview",
        max_steps: int = 350,
        use_vision: bool = True,
        verbose: bool = True,
    ):
        """Initialize the Survey analyzer.

        Args:
            model_name: LLM model to use (default: gemini-3-flash-preview)
            max_steps: Maximum agent steps (default: 350)
            use_vision: Enable vision analysis (default: True)
            verbose: Enable verbose logging (default: True)
        """
        self.model_name = model_name
        self.max_steps = max_steps
        self.use_vision = use_vision
        self.verbose = verbose

    def _find_chromium_executable(self) -> Optional[str]:
        """Find the Chromium executable installed by Playwright.

        Returns:
            Path to Chromium executable if found on Heroku, None for local development.
        """
        is_heroku = os.getenv('DYNO') is not None

        if not is_heroku:
            return None  # Let browser-use handle local development

        # On Heroku, check multiple possible browser locations
        # Try custom installation location first (set via PLAYWRIGHT_BROWSERS_PATH)
        browser_locations = [
            Path('/app/.playwright-browsers'),  # Custom non-cache location (included in slug)
            Path('/app/.playwright'),  # Alternative custom location
            Path.home() / '.cache' / 'ms-playwright',  # Standard location (excluded from slug)
        ]

        for browser_base in browser_locations:
            if not browser_base.exists():
                continue

            # Look for chromium headless shell (used on Heroku to reduce slug size)
            # The executable is named 'headless_shell' (NOT 'chrome-headless-shell')
            headless_patterns = [
                'chromium_headless_shell-*/chrome-linux/headless_shell',  # Standard path
                'chromium_headless_shell-*/headless_shell',  # Fallback
            ]

            for pattern in headless_patterns:
                headless_shell_paths = list(browser_base.glob(pattern))
                if headless_shell_paths:
                    browser_path = str(headless_shell_paths[0])
                    if self.verbose:
                        print(f"Found Playwright Chromium Headless Shell at: {browser_path}")
                    return browser_path

            # Fallback: Look for full chromium executable (local development)
            chromium_paths = list(browser_base.glob('chromium-*/chrome-linux/chrome'))
            if chromium_paths:
                browser_path = str(chromium_paths[0])
                if self.verbose:
                    print(f"Found Playwright Chromium at: {browser_path}")
                return browser_path

        if self.verbose:
            print(f"Warning: Chromium executable not found in any expected location")
            print(f"  Checked: {[str(loc) for loc in browser_locations]}")
        return None


    async def analyze_survey(
        self,
        survey_url: str
    ) -> SurveyAnalysisResult:
        """Analyze survey with effective prompting and browser configuration."""
        if self.verbose:
            print(f"Starting survey analysis: {survey_url}")
            print(f"Model: {self.model_name}")

        # Validate URL format
        if not survey_url.startswith(('http://', 'https://')):
            raise ValueError(f"Invalid URL format: {survey_url}")

        # Check for required API key based on model
        is_google_model = self.model_name.startswith("gemini")
        if is_google_model:
            if not os.getenv("GOOGLE_API_KEY"):
                raise ValueError("Google API key not found. Please set GOOGLE_API_KEY environment variable.")
        else:
            if not os.getenv("OPENAI_API_KEY"):
                raise ValueError("OpenAI API key not found. Please set OPENAI_API_KEY environment variable.")

        # Auto-detect if running on Heroku
        is_heroku = os.getenv('DYNO') is not None
        headless = os.getenv('HEADLESS_MODE', 'true' if is_heroku else 'false').lower() == 'true'

        # Find browser executable on Heroku
        executable_path = self._find_chromium_executable()

        # Add Heroku-specific launch arguments for containerized environments
        extra_args = []
        if is_heroku:
            extra_args = [
                # CRITICAL: Sandbox disabling (Heroku requirement)
                '--no-sandbox',
                '--disable-setuid-sandbox',

                # CRITICAL: Memory management (Heroku requirement)
                '--disable-dev-shm-usage',

                # CRITICAL: Prevent startup hangs
                '--disable-background-networking',
                '--disable-default-apps',
                '--disable-extensions',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--disable-hang-monitor',
                '--disable-prompt-on-repost',
                '--disable-sync',

                # Performance optimization
                '--disable-gpu',
                '--disable-software-rasterizer',
                '--disable-features=VizDisplayCompositor',
                '--metrics-recording-only',
                '--mute-audio',
                '--no-first-run',
                '--safebrowsing-disable-auto-update',

                # Anti-detection (helps with survey completion)
                '--disable-blink-features=AutomationControlled',
            ]

        # Configure browser with environment-aware settings
        browser_profile = BrowserProfile(
            headless=headless,
            executable_path=executable_path,  # Explicitly set the browser path
            viewport={'width': 1280, 'height': 720},
            extra_chromium_args=extra_args,
            enable_default_extensions=False  # Disable extensions to prevent 30s download timeout on Heroku
        )

        apply_cdp_timeout_patch()

        browser = Browser(browser_profile=browser_profile)

        apply_human_typing_patch(browser, verbose=self.verbose)

        tools = Tools()

        # Add audio/video transcription tool (always available)
        @tools.registry.action(description='Listen to audio or watch video content and get a transcription. Use this when you encounter <audio> or <video> elements with questions about their content. Provide the full HTTP URL from the src attribute.')
        async def listen_to_media(url: str) -> ActionResult:
            """Transcribe audio or video content using OpenAI Whisper API.

            Args:
                url: The full URL to the audio/video file (e.g., https://example.com/audio.mp3)

            Returns:
                ActionResult with the transcribed text or error message
            """
            try:
                if self.verbose:
                    print(f"🎵 Attempting to transcribe media from: {url}")

                # Validate URL
                if not url or len(url.strip()) == 0:
                    return ActionResult(
                        extracted_content='Error: Empty URL provided. Please extract the media URL from the page first using JavaScript like: document.querySelector("video, audio").src or document.querySelector("video, audio").currentSrc',
                        include_in_memory=True
                    )

                if not url.startswith('http'):
                    return ActionResult(
                        extracted_content=f'Error: Invalid URL "{url}". Must start with http:// or https://',
                        include_in_memory=True
                    )

                if url.startswith('blob:'):
                    return ActionResult(
                        extracted_content='Error: blob: URLs (in-memory media) are not supported. Please provide an actual HTTP URL.',
                        include_in_memory=True
                    )

                # Download the media file
                if self.verbose:
                    print(f"📥 Downloading media file...")

                # Try downloading without cookies first (many survey media files are public)
                # If we get 401/403, we'll get an exception and can handle it
                try:
                    response = requests.get(url, timeout=30)
                    response.raise_for_status()
                except requests.exceptions.HTTPError as e:
                    if e.response.status_code in (401, 403):
                        # Authentication required - try getting cookies
                        if self.verbose:
                            print(f"🔐 Authentication required, attempting to get cookies...")

                        cookie_dict = {}
                        try:
                            # Get cookies from browser's current page
                            page = await browser.get_current_page()
                            if page:
                                # Access context via Playwright's async API
                                cookies_list = await page.context.cookies()
                                cookie_dict = {cookie['name']: cookie['value'] for cookie in cookies_list}

                            if cookie_dict:
                                # Retry with cookies
                                response = requests.get(url, cookies=cookie_dict, timeout=30)
                                response.raise_for_status()
                            else:
                                raise Exception("Could not retrieve authentication cookies")
                        except Exception as cookie_error:
                            return ActionResult(
                                extracted_content=f'Error: Media file requires authentication but could not retrieve cookies: {str(cookie_error)}',
                                include_in_memory=True
                            )
                    else:
                        raise  # Re-raise if it's a different HTTP error

                # Determine actual file extension using multiple detection methods
                # Priority: Magic bytes (most reliable) > Content-Type > Content-Disposition > URL
                ext = None

                # Log response details for debugging
                if self.verbose:
                    print(f"📋 Response headers:")
                    print(f"   Content-Type: {response.headers.get('content-type', 'N/A')}")
                    print(f"   Content-Length: {response.headers.get('content-length', 'N/A')} bytes")
                    print(f"   Content-Disposition: {response.headers.get('content-disposition', 'N/A')}")

                # Method 1: Detect from magic bytes (file signature) - MOST RELIABLE
                if len(response.content) > 12:
                    magic_bytes = response.content[:12]

                    # Common audio/video file signatures
                    if magic_bytes.startswith(b'RIFF') and b'WAVE' in magic_bytes:
                        ext = '.wav'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (WAV)")
                    elif magic_bytes.startswith(b'ID3') or magic_bytes.startswith(b'\xff\xfb') or magic_bytes.startswith(b'\xff\xf3') or magic_bytes.startswith(b'\xff\xf2'):
                        ext = '.mp3'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (MP3)")
                    elif magic_bytes[4:8] == b'ftyp':
                        # MP4/M4A container format
                        ext = '.m4a'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (M4A/MP4)")
                    elif magic_bytes.startswith(b'OggS'):
                        ext = '.ogg'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (OGG)")
                    elif magic_bytes.startswith(b'fLaC'):
                        ext = '.flac'
                        if self.verbose:
                            print(f"✓ Extension from magic bytes: {ext} (FLAC)")

                # Method 2: Check content-type header
                if not ext:
                    content_type = response.headers.get('content-type', '').lower()
                    if 'wav' in content_type or 'wave' in content_type:
                        ext = '.wav'
                    elif 'mp3' in content_type or 'mpeg' in content_type:
                        ext = '.mp3'
                    elif 'm4a' in content_type or 'mp4' in content_type:
                        ext = '.m4a'
                    elif 'ogg' in content_type:
                        ext = '.ogg'
                    elif 'flac' in content_type:
                        ext = '.flac'
                    elif 'webm' in content_type:
                        ext = '.webm'

                    if ext and self.verbose:
                        print(f"✓ Extension from Content-Type: {ext}")

                # Method 3: Check Content-Disposition header for filename (can be misleading)
                if not ext:
                    content_disposition = response.headers.get('content-disposition', '')
                    if 'filename=' in content_disposition:
                        import re
                        # Parse filename from header (handles both quoted and unquoted)
                        match = re.search(r'filename[^;=\n]*=(([\'"]).*?\2|[^;\n]*)', content_disposition)
                        if match:
                            filename = match.group(1).strip('\'"')
                            if '.' in filename:
                                ext = '.' + filename.rsplit('.', 1)[1].lower()
                                if self.verbose:
                                    print(f"✓ Extension from Content-Disposition filename: {ext}")

                # Method 4: Check URL extension
                if not ext:
                    for audio_ext in ['.mp3', '.wav', '.m4a', '.ogg', '.flac', '.webm', '.mp4', '.mpeg', '.mpga', '.oga']:
                        if url.lower().endswith(audio_ext):
                            ext = audio_ext
                            if self.verbose:
                                print(f"✓ Extension from URL: {ext}")
                            break

                # Fallback: default to .mp3
                if not ext:
                    ext = '.mp3'
                    if self.verbose:
                        print(f"⚠️  Using default extension: {ext}")

                # Save to temporary file
                with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp_file:
                    tmp_file.write(response.content)
                    tmp_path = tmp_file.name

                if self.verbose:
                    print(f"💾 Saved to temporary file: {tmp_path}")

                # Transcribe using OpenAI Whisper
                if self.verbose:
                    print(f"🎤 Transcribing with Whisper...")

                client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

                with open(tmp_path, 'rb') as audio_file:
                    transcript = client.audio.transcriptions.create(
                        model="whisper-1",
                        file=audio_file
                    )

                # Clean up temp file
                os.unlink(tmp_path)

                transcribed_text = transcript.text

                if self.verbose:
                    print(f"✅ Transcription successful: {transcribed_text[:100]}...")

                return ActionResult(
                    extracted_content=f'Transcribed audio/video content: {transcribed_text}',
                    include_in_memory=True
                )

            except Exception as e:
                # Clean up temp file on error
                try:
                    if 'tmp_path' in locals():
                        os.unlink(tmp_path)
                except:
                    pass

                # Provide detailed error information
                error_details = []
                error_details.append(f'Error transcribing media from {url}')
                error_details.append(f'Error: {str(e)}')

                # Include format detection info if available
                if 'ext' in locals() and ext:
                    error_details.append(f'Detected format: {ext}')
                if 'content_type' in locals():
                    error_details.append(f'Content-Type: {content_type}')
                if 'response' in locals():
                    error_details.append(f'File size: {len(response.content)} bytes')

                error_msg = ' | '.join(error_details)

                if self.verbose:
                    print(f"❌ {error_msg}")

                return ActionResult(
                    extracted_content=error_msg,
                    include_in_memory=True
                )

        if self.verbose:
            print(f"🎵 Audio/video transcription tool registered: listen_to_media(url)")

        # Use appropriate LLM based on model name
        if is_google_model:
            llm = ChatGoogle(model=self.model_name)
        else:
            llm = ChatOpenAI(model=self.model_name)
        task = build_task_prompt(survey_url)

        # Create agent with browser, tools, and vision settings
        # Always pass tools (audio transcription is always available, CAPTCHA is conditional)
        tools_to_pass = tools
        if self.verbose:
            try:
                num_tools = len(tools.registry._registry) if hasattr(tools.registry, '_registry') else 'unknown'
                print(f"🔧 Passing {num_tools} custom tool(s) to agent")
            except Exception as e:
                print(f"🔧 Passing custom tools to agent (count unavailable: {e})")

        agent = Agent(
            task=task,
            llm=llm,
            browser=browser,
            tools=tools_to_pass,  # listen_to_media for audio/video transcription
            use_vision=self.use_vision,
            vision_detail_level="high"  # Critical for detecting hover elements
        )

        if self.verbose:
            print("Running agent with specific instructions...")

        # Track timing
        start_time = time.time()
        history = await agent.run(max_steps=self.max_steps)
        elapsed_time = time.time() - start_time

        return self._build_result(history, survey_url, elapsed_time)

    @staticmethod
    def _collect_history_text(history) -> str:
        """Concatenate every extracted_content chunk into one lowercased blob."""
        if not hasattr(history, 'extracted_content'):
            return ""
        return "".join(
            str(content).lower() for content in history.extracted_content() if content
        )

    def _build_result(self, history, survey_url: str, time_seconds: float = 0.0) -> SurveyAnalysisResult:
        """Build SurveyAnalysisResult from agent history."""

        history_text = self._collect_history_text(history)
        mechanism_types = self._extract_mechanisms(history_text)

        parsed_url = urlparse(survey_url)
        survey_domain = parsed_url.netloc

        bot_mechanisms = []
        for mechanism_type in mechanism_types:
            severity = self.MECHANISM_SEVERITY.get(mechanism_type, 5)
            description = mechanism_type.value.replace('_', ' ').title()

            response_method = self.RESPONSE_METHODS.get(mechanism_type)

            # The two evidence-conditional cases.
            if mechanism_type == BotDetectionType.HOVER_TRAP and 'hover' in history_text:
                response_method = "Attempted JavaScript hover event simulation"
            elif mechanism_type == BotDetectionType.AUDIO_VIDEO_QUESTION:
                if 'transcribed audio/video content' in history_text:
                    response_method = "Audio/video transcription via OpenAI Whisper API"
                else:
                    response_method = "Attempted to handle audio/video content"

            # bypassed=True means: survey completed AND we have an attributable
            # response method. It's a weak signal (correlation, not proof).
            bypassed = True if (history.is_done() and response_method) else None

            bot_mechanisms.append(
                BotDetectionMechanism(
                    type=mechanism_type,
                    description=description,
                    bypassed=bypassed,
                    severity=severity,
                    bypass_method=response_method  # How we responded to this mechanism
                )
            )

        # Calculate success probability and difficulty score based on mechanisms
        success_probability = self._calculate_success_probability(history, bot_mechanisms)
        difficulty_score = self._calculate_difficulty_score(bot_mechanisms)

        # Generate narrative summary
        narrative_summary = self._generate_narrative_summary(
            history=history,
            bot_mechanisms=bot_mechanisms,
            completed=history.is_done(),
            success_probability=success_probability,
            difficulty_score=difficulty_score,
            steps_taken=len(history.history),
            time_seconds=time_seconds
        )

        # Create result
        result = SurveyAnalysisResult(
            survey_url=survey_url,
            survey_domain=survey_domain,
            completed=history.is_done(),
            success_probability=success_probability,
            difficulty_score=difficulty_score,
            detected_mechanisms=len(bot_mechanisms),
            steps_taken=len(history.history),
            time_seconds=time_seconds,
            bot_mechanisms=bot_mechanisms,
            final_result=history.final_result() or "Analysis completed",
            narrative_summary=narrative_summary,
            timestamp=datetime.now(),
            analysis_parameters={
                "model": self.model_name,
                "max_steps": self.max_steps
            }
        )

        if self.verbose:
            self._print_results(result)

        return result

    # Keyword scan for bot-detection mechanisms in agent history.
    # Single source of truth for type ↔ keyword mapping.
    DETECTION_KEYWORDS = {
        BotDetectionType.HOVER_TRAP: ['hover', 'mouseover', 'arrow', '←', '→', '↑', '↓'],
        BotDetectionType.CAPTCHA: ['captcha', 'not a robot', 'recaptcha'],
        BotDetectionType.ATTENTION_CHECK: ['attention check', 'select option', 'carefully read', 'if you are reading'],
        BotDetectionType.INVISIBLE_TEXT: ['hidden', 'invisible', 'white text', 'opacity'],
        BotDetectionType.TIMING_TRAP: ['too fast', 'too slow', 'timing', 'wait'],
        BotDetectionType.HONEYPOT_FIELD: ['honeypot', 'trap field', 'hidden field'],
        BotDetectionType.MOUSE_TRACKING: ['mouse', 'cursor', 'movement'],
        BotDetectionType.IDENTITY_QUESTION: [
            'are you human', 'are you a bot', 'are you ai', 'type 17 if human',
            'type pi if', 'large language model', 'are you using ai',
        ],
        BotDetectionType.REVERSE_SHIBBOLETH: [
            'write code in fortran', 'recite the constitution', 'translate to mandarin',
            'what was the weather', 'solve this integral', 'programming', 'assembly code',
        ],
        BotDetectionType.IMPOSSIBLE_EVENT: [
            'visited the moon', 'elected president', 'convicted of murder',
            'without sleep', 'every museum', 'fictitious', 'roscoville',
        ],
        BotDetectionType.LOGIC_PUZZLE: ['logic puzzle', 'if all', 'therefore', 'syllogism', 'must be true'],
        BotDetectionType.READING_COMPREHENSION: [
            'according to the passage', 'based on the text above',
            'the excerpt states', 'vignette', 'scenario',
        ],
        BotDetectionType.INSTRUCTION_FOLLOWING: [
            'please select', 'choose exactly', 'do not select',
            'skip this question', 'answer in this format',
        ],
        BotDetectionType.AUDIO_VIDEO_QUESTION: [
            'listen to', 'audio clip', 'listen to the', 'watch the video',
            'play the audio', '<audio', '<video', 'sound clip', 'audio file',
        ],
    }

    def _extract_mechanisms(self, history_text: str) -> List[BotDetectionType]:
        """Scan history text for keywords indicating each detection mechanism."""
        return [
            mech_type
            for mech_type, keywords in self.DETECTION_KEYWORDS.items()
            if any(kw in history_text for kw in keywords)
        ]

    def _calculate_success_probability(
        self,
        history,
        bot_mechanisms: List[BotDetectionMechanism]
    ) -> float:
        """Calculate completion likelihood based on survey status and detected mechanisms.

        This is NOT a measure of bypassing individual mechanisms, but rather an
        assessment of overall completion likelihood given the detected security measures.

        Args:
            history: Agent history object
            bot_mechanisms: List of detected bot detection mechanisms with severity

        Returns:
            Completion likelihood from 0-100
        """
        # Start with base score based on completion status
        if history.is_done():
            base_score = 95.0  # High confidence if survey completed
        else:
            base_score = 30.0  # Low confidence if survey incomplete

        # Adjust based on total difficulty of detected mechanisms
        # More difficult mechanisms suggest a more challenging survey
        total_severity = sum(m.severity for m in bot_mechanisms)

        # Normalize severity impact (each mechanism reduces confidence slightly)
        # Max realistic: 4 very hard mechanisms (40 points) = 20% reduction
        severity_penalty = min((total_severity / 40) * 20, 30)

        base_score -= severity_penalty

        # Ensure score stays in valid range
        return max(min(round(base_score, 1), 100.0), 0.0)

    def _calculate_difficulty_score(self, bot_mechanisms: List[BotDetectionMechanism]) -> float:
        """Calculate weighted difficulty score based on mechanism severities.

        Args:
            bot_mechanisms: List of detected bot detection mechanisms

        Returns:
            Difficulty score from 0-100
        """
        if not bot_mechanisms:
            return 0.0

        # Sum up severity scores (each mechanism is weighted 1-10)
        total_severity = sum(m.severity for m in bot_mechanisms)

        # Normalize to 0-100 scale
        # Assume max realistic scenario is 4 very difficult mechanisms (4 × 10 = 40)
        max_expected_severity = 40
        difficulty = min((total_severity / max_expected_severity) * 100, 100)

        return round(difficulty, 1)

    def _generate_narrative_summary(
        self,
        history,
        bot_mechanisms: List[BotDetectionMechanism],
        completed: bool,
        success_probability: float,
        difficulty_score: float,
        steps_taken: int,
        time_seconds: float
    ) -> str:
        """Generate a narrative summary of the survey analysis.

        Args:
            history: Agent history object
            bot_mechanisms: List of detected bot detection mechanisms
            completed: Whether the survey was completed
            success_probability: Success probability percentage
            difficulty_score: Difficulty score percentage
            steps_taken: Number of agent steps taken
            time_seconds: Time taken in seconds

        Returns:
            Formatted narrative summary string
        """
        lines = []

        # Header
        lines.append("SURVEY ANALYSIS SUMMARY")
        lines.append("=" * 80)
        lines.append("")

        # Overview
        lines.append("OVERVIEW:")
        if completed:
            if len(bot_mechanisms) == 0:
                lines.append("The survey completed successfully. No bot detection mechanisms were ")
                lines.append("explicitly identified in the interaction history.")
            elif len(bot_mechanisms) == 1:
                lines.append("The survey completed successfully. During the process, we detected 1 ")
                lines.append("security measure in the interaction history.")
            else:
                lines.append(f"The survey completed successfully. During the process, we detected {len(bot_mechanisms)} ")
                lines.append("security measures in the interaction history.")
        else:
            if len(bot_mechanisms) == 0:
                lines.append("The survey did not complete. No bot detection mechanisms were explicitly ")
                lines.append("identified, suggesting the issue may be unrelated to security measures.")
            else:
                lines.append(f"The survey did not complete. We detected {len(bot_mechanisms)} security ")
                lines.append("measure(s) during the attempt. The specific cause of incompletion is unclear.")

        lines.append("")

        # Security Measures Encountered
        if bot_mechanisms:
            lines.append("SECURITY MEASURES DETECTED:")
            lines.append("")

            for i, mechanism in enumerate(bot_mechanisms, 1):
                lines.append(f"{i}. {mechanism.description} (Severity: {mechanism.severity}/10)")

                context = MECHANISM_CONTEXT.get(mechanism.type, {})

                lines.append(f"   What is this? {context.get('what_it_is', 'Unknown detection mechanism')}")
                lines.append(f"   Why it matters: {context.get('why_it_matters', 'This helps ensure response authenticity')}")

                if mechanism.bypass_method:
                    lines.append(f"   How we responded: {mechanism.bypass_method}")
                else:
                    lines.append(f"   How we responded: Mechanism detected but specific response method unclear")

                lines.append("")

        # Final Outcome
        lines.append("FINAL OUTCOME:")
        lines.append(f"Survey Status: {'Completed' if completed else 'Incomplete'}")
        lines.append(f"Mechanisms Detected: {len(bot_mechanisms)}")

        # Interpret difficulty score
        if difficulty_score >= 80:
            difficulty_label = "Very High Challenge"
        elif difficulty_score >= 60:
            difficulty_label = "High Challenge"
        elif difficulty_score >= 40:
            difficulty_label = "Moderate Challenge"
        elif difficulty_score >= 20:
            difficulty_label = "Low Challenge"
        else:
            difficulty_label = "Minimal Challenge"

        lines.append(f"Difficulty Assessment: {difficulty_score}/100 ({difficulty_label} - based on detected mechanisms)")

        # Interpret completion likelihood
        if success_probability >= 85:
            confidence_label = "High"
        elif success_probability >= 70:
            confidence_label = "Moderate-High"
        elif success_probability >= 50:
            confidence_label = "Moderate"
        else:
            confidence_label = "Low"

        lines.append(f"Completion Likelihood: {success_probability}% ({confidence_label} confidence)")
        lines.append(f"Analysis Time: {int(time_seconds)} seconds ({steps_taken} agent steps)")
        lines.append("")
        lines.append("IMPORTANT NOTE:")
        lines.append("This analysis is based on mechanisms explicitly detected in the agent's interaction")
        lines.append("history. Additional security measures may be present but were not identified during")
        lines.append("this analysis. The completion status reflects whether the survey reached its final")
        lines.append("page, not necessarily whether all responses were valid or accepted.")

        return "\n".join(lines)

    def _print_results(self, result: SurveyAnalysisResult):
        """Print formatted results."""
        print("\n" + "="*60)
        print("SURVEY ANALYSIS RESULTS")
        print("="*60)
        print(f"Survey URL: {result.survey_url}")
        print(f"Survey Domain: {result.survey_domain}")
        print(f"Completed: {result.completed}")
        print(f"Steps taken: {result.steps_taken}")
        print(f"Success probability: {result.success_probability}%")
        print(f"Difficulty score: {result.difficulty_score}/100")
        print(f"Bot detection mechanisms found: {len(result.bot_mechanisms)}")

        for mechanism in result.bot_mechanisms:
            print(f"  - {mechanism.type.value}: {mechanism.description}")

        if result.final_result:
            print(f"\nFinal agent message: {result.final_result}")

