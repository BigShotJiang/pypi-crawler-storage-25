"""Pydantic models for the static-instrument-review feature.

Kept separate from `survey_result.py` (runtime/live-agent analysis) to keep
the two product surfaces from blurring into one another.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class Severity(int, Enum):
    LOW = 1
    MED = 2
    HIGH = 3


class EditKind(str, Enum):
    """Coarse hint at what kind of QSF modification would resolve a finding.

    v1 only populates this enum on findings; v2 will use it as the
    discriminator for a structured `Edit` taxonomy applied by `qsf_writer`.
    Keeping it as a top-level enum lets v1 reviewers produce edit hints
    without committing to the full edit schema yet.
    """

    NONE = "none"
    ADD_ATTENTION_CHECK = "add_attention_check"
    ADD_IDENTITY_QUESTION = "add_identity_question"
    ADD_IMPOSSIBLE_EVENT = "add_impossible_event"
    ENABLE_FORCE_RESPONSE = "enable_force_response"
    ADD_DISPLAY_LOGIC = "add_display_logic"
    REMOVE_QUESTION = "remove_question"
    EDIT_QUESTION_TEXT = "edit_question_text"
    REORDER_OR_RANDOMIZE = "reorder_or_randomize"
    OTHER = "other"


class Finding(BaseModel):
    """A single issue surfaced by a reviewer.

    Every finding must cite a verbatim ``excerpt`` from the source survey.
    The reviewer pipeline drops findings whose excerpt can't be located in
    the parsed survey before they reach the report — so by the time a Finding
    reaches the API it is grounded in real survey content.
    """

    question_id: Optional[str] = None
    excerpt: str
    severity: Severity
    confidence: float
    rationale: str
    suggested_fix: Optional[str] = None
    recommended_edit_kind: EditKind = EditKind.NONE
    # Set on consolidated findings (the second-stage LLM merges per-dimension
    # findings that flag the same underlying problem). Empty for raw findings.
    contributing_dimensions: List[str] = []


class DimensionReview(BaseModel):
    """A single reviewer agent's verdict for one dimension."""

    dimension: str
    score: float
    findings: List[Finding] = []
    summary: str
    model: str
    duration_seconds: float
    error: Optional[str] = None


class Recommendation(BaseModel):
    title: str
    detail: str
    priority: int
    related_dimensions: List[str] = []


class OverallFeedback(BaseModel):
    """LLM-written holistic peer-review-style assessment.

    Produced by the second-stage `consolidate_and_summarize` call. If that
    call errors, falls back to a synthesized headline pointing readers at
    `narrative_summary` (which is composed in pure Python and never errors).
    """

    headline: str
    paragraphs: List[str] = []


class InstrumentReview(BaseModel):
    """Top-level review result returned by the API."""

    review_id: str
    filename: str
    timestamp: datetime
    overall_score: float
    completion_likelihood: float
    parsed_summary: Dict[str, Any]
    dimensions: List[DimensionReview]
    recommendations: List[Recommendation]
    overall_feedback: OverallFeedback
    narrative_summary: str
    methods_statement: str
    parameters: Dict[str, Any]


class InstrumentReviewRequest(BaseModel):
    """Body for `POST /api/v1/instrument/review`. The QSF file itself is a
    multipart upload; this captures the optional form fields."""

    model_name: str = "gpt-4o-mini"
    dimensions: Optional[List[str]] = None


class ParsedQuestion(BaseModel):
    """Subset of a QSF SurveyElement (Element=SQ) that reviewers consume."""

    qid: str
    type: str
    subtype: Optional[str] = None
    text: str
    description: Optional[str] = None
    choices: List[str] = []
    display_logic: Optional[Dict[str, Any]] = None
    validation: Optional[Dict[str, Any]] = None
    force_response: bool = False
    hidden: bool = False
    embedded_html: Optional[str] = None


class ParsedBlock(BaseModel):
    block_id: str
    description: str
    question_ids: List[str] = []


class ParsedSurvey(BaseModel):
    """Typed view over a QSF file. The reviewer agents see only this — never
    the raw dict — so the prompt surface is deterministic. Phase 2 needs the
    raw dict to apply edits without losing fields we didn't model; that's
    held alongside in the service layer, not in this model.
    """

    name: str
    description: Optional[str] = None
    blocks: List[ParsedBlock] = []
    questions: List[ParsedQuestion] = []
    flow: List[Dict[str, Any]] = []
