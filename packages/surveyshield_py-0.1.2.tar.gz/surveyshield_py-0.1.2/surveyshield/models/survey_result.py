"""Data models for Survey Shield."""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, HttpUrl


class BotDetectionType(str, Enum):
    """Types of bot detection mechanisms.

    The first group is classic web-bot defenses; the second group is the
    LLM-specific categories from Westwood (2025), PNAS.
    """

    HOVER_TRAP = "hover_trap"
    INVISIBLE_TEXT = "invisible_text"
    TIMING_TRAP = "timing_trap"
    CAPTCHA = "captcha"
    HONEYPOT_FIELD = "honeypot_field"
    ATTENTION_CHECK = "attention_check"
    MOUSE_TRACKING = "mouse_tracking"

    IDENTITY_QUESTION = "identity_question"
    REVERSE_SHIBBOLETH = "reverse_shibboleth"
    IMPOSSIBLE_EVENT = "impossible_event"
    LOGIC_PUZZLE = "logic_puzzle"
    READING_COMPREHENSION = "reading_comprehension"
    INSTRUCTION_FOLLOWING = "instruction_following"
    AUDIO_VIDEO_QUESTION = "audio_video_question"
    OTHER = "other"


class BotDetectionMechanism(BaseModel):
    """A detected bot-prevention mechanism."""

    type: BotDetectionType
    description: str
    severity: int  # 1-10 scale
    bypassed: Optional[bool] = None  # None = unknown, True = evidence of successful handling
    bypass_method: Optional[str] = None


class SurveyAnalysisResult(BaseModel):
    """Complete analysis result for a survey."""

    survey_url: HttpUrl
    survey_domain: str
    timestamp: datetime

    analysis_parameters: Optional[Dict[str, Any]] = None

    completed: bool
    success_probability: float  # 0-100
    steps_taken: int
    time_seconds: float

    bot_mechanisms: List[BotDetectionMechanism] = []
    detected_mechanisms: int = 0
    difficulty_score: float = 0.0

    final_result: str = ""
    narrative_summary: str = ""
    detection_note: str = (
        "Note: This analysis reports mechanisms detected in the agent's "
        "interaction history. Additional mechanisms may be present but undetected."
    )


class SurveyAnalysisRequest(BaseModel):
    """Request body for `POST /api/v1/survey/analyze`."""

    survey_url: HttpUrl
    model_name: str = "gemini-3-flash-preview"
    max_steps: int = 150
    use_vision: bool = True
