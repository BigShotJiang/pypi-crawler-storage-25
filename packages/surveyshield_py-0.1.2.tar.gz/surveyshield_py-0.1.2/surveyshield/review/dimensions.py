"""Plug-in registry of evaluation dimensions.

Adding a new dimension is one entry below — no router, aggregator, or
template changes required. Each dimension owns:

- ``name`` — stable identifier; surfaces in the API, the HTML report, and
  the methods statement copy-paste paragraph.
- ``weight`` / ``completion_weight`` — feeds the aggregator's overall_score
  and completion_likelihood blends.
- ``description`` — one-line surfaced near the top of each dimension card.
- ``prompt_template`` — the dimension-specific *instructions only*. The
  reviewer prepends a shared, pre-rendered survey blob so OpenAI's automatic
  prompt-prefix cache can hit across dimensions.
- ``output_schema`` — Pydantic class the reviewer populates via structured
  outputs.
"""

from __future__ import annotations

from typing import List

from pydantic import BaseModel

from surveyshield.models.instrument_review import EditKind, Finding
from surveyshield.models.survey_result import BotDetectionType


DIMENSION_SET_VERSION = "v1-arch-2026-05"

# Rendered into the shared rubric so the prompt's enumeration of edit kinds
# stays in lock-step with the Pydantic enum — single source of truth.
_EDIT_KIND_LIST = ", ".join(k.value for k in EditKind)


class DimensionOutput(BaseModel):
    """Structured-output schema reviewers populate for every dimension."""

    score: float
    findings: List[Finding] = []
    summary: str


class Dimension(BaseModel):
    name: str
    weight: float
    completion_weight: float = 0.0
    description: str
    prompt_template: str
    output_schema: type = DimensionOutput
    related_bot_types: List[BotDetectionType] = []

    model_config = {"arbitrary_types_allowed": True}


_SHARED_RUBRIC = """
SCOPE: You are evaluating ONLY the instrument's resistance to AI/bot
respondents. You are NOT a peer reviewer of the survey's substantive
research, methodology, or wording quality.

STRICTLY OUT OF SCOPE — do NOT flag any of the following, even if you
notice issues:
- The substantive topic, theoretical framing, hypotheses, or research
  design.
- Question wording, clarity, grammar, or readability — UNLESS the wording
  itself is the defense (or the lack of one) against AI respondents.
- Demographic question design, response-option phrasing, scale points,
  or balance.
- Survey length, ordering, pacing, fatigue, or engagement.
- Accessibility, ethics, IRB-style concerns.
- Statistical, sampling, or validity threats unrelated to bot detection.

ONLY flag findings that bear on whether an AI/automated agent can complete
this survey undetected. Examples of in-scope findings: missing attention
checks, no identity-probe items, no reverse-shibboleth probes, no
impossible-event probes, missing visual-perceptual traps, force-response
disabled on bot-trap questions, hidden honeypot fields, instructions that
are easy for an LLM to follow blindly. If a question is poorly worded but
the poor wording does not affect bot resistance, do NOT flag it.

Score the dimension 0–100 (higher = better defended). For every in-scope
issue, return one entry in `findings` with:
- `question_id`: the QID this concerns, or null for a survey-level issue
- `excerpt`: REQUIRED. The exact verbatim text from the survey above that
  prompted this finding — quote a question's text, a choice label, a
  description, or a phrase from the survey metadata. The excerpt must be a
  literal substring of what appears in the survey blob. Findings whose
  excerpt cannot be located verbatim are dropped during validation, so be
  conservative: if you are not certain of the exact wording, do not flag
  the issue.
- `severity`: 1 (low), 2 (medium), 3 (high)
- `confidence`: how sure you are this finding is real, 0..1
- `rationale`: 1–2 short sentences naming the concrete bot-resistance
  reason. Do not pivot into general critique.
- `suggested_fix`: a short, concrete bot-resistance change the survey
  author could make.
- `recommended_edit_kind`: one of {EDIT_KINDS}

Do not invent QIDs that aren't in the survey. Cite the actual QID
strings (e.g., "QID42") when applicable.
""".strip().replace("{EDIT_KINDS}", _EDIT_KIND_LIST)


DIMENSIONS: List[Dimension] = [
    Dimension(
        name="attention_checks",
        weight=1.0,
        completion_weight=0.5,
        description=(
            "Presence and quality of attention / instructional manipulation "
            "checks (IMCs). A defended instrument has at least one explicit "
            "IMC distributed across the survey."
        ),
        prompt_template=(
            "You are reviewing a Qualtrics survey for attention-check coverage.\n\n"
            "Identify: (a) explicit IMCs (e.g., \"Select 'Strongly Agree' to show you "
            "are reading carefully\"), (b) candidate items that could be IMCs but "
            "aren't enforced, (c) coverage gaps (e.g., long surveys with zero IMCs).\n\n"
            "Score 100 for strong, well-distributed IMCs across multiple blocks; "
            "50 for one IMC; 0 for none.\n\n"
            f"{_SHARED_RUBRIC}"
        ),
        related_bot_types=[
            BotDetectionType.ATTENTION_CHECK,
            BotDetectionType.INSTRUCTION_FOLLOWING,
        ],
    ),
    Dimension(
        name="identity_questions",
        weight=1.0,
        completion_weight=0.5,
        description=(
            "Direct LLM-resistance items: questions that ask whether the "
            "respondent is human, AI, or a bot, or that depend on knowing "
            "human-only context. Westwood (2025) showed these expose AI "
            "agents that follow training to identify themselves."
        ),
        prompt_template=(
            "You are reviewing a Qualtrics survey for LLM-resistance items.\n\n"
            "Look for: identity questions (\"Are you human?\", \"Type 17 if human, "
            "type the first 5 digits of pi if AI\"), reverse-shibboleth probes "
            "(asking for verbatim recitation, advanced math, code in obscure "
            "languages), and impossible-event probes (\"Have you visited the moon?\").\n\n"
            "Score 100 if all three sub-categories are represented across the "
            "instrument; 0 if none. Penalize if every identity probe is at the very "
            "end of the survey (easy to skip).\n\n"
            f"{_SHARED_RUBRIC}"
        ),
        related_bot_types=[
            BotDetectionType.IDENTITY_QUESTION,
            BotDetectionType.REVERSE_SHIBBOLETH,
            BotDetectionType.IMPOSSIBLE_EVENT,
        ],
    ),
    Dimension(
        name="visual_perceptual_traps",
        weight=1.0,
        completion_weight=0.0,
        description=(
            "Visual-perceptual cognitive traps: image- or layout-based items "
            "that exploit architectural constraints in vision-language "
            "models. Affonso (2026) frames these as tasks humans pass "
            "trivially while AI agents fail systematically."
        ),
        prompt_template=(
            "You are reviewing a Qualtrics survey for visual-perceptual cognitive "
            "traps in the spirit of Affonso (2026, JCR).\n\n"
            "ONLY flag findings about visual / perceptual content: questions that "
            "depend on seeing an image and counting / locating elements, perspective "
            "or composition tasks, items that hide instructions inside images, "
            "items that test color discrimination or spatial reasoning, layout "
            "tricks (off-screen text, hover-only content, color-coded answer keys). "
            "Do NOT flag textual questions for being \"easy for bots\" — that is "
            "covered by other dimensions and is out of scope here.\n\n"
            "Most surveys will have NO visual-perceptual traps at all. That is the "
            "common case and produces a survey-level finding (\"no visual-perceptual "
            "defenses present\"), not a per-question finding for every text question. "
            "Score 0 when absent, 100 when at least one well-constructed visual-"
            "perceptual trap is present and non-trivial. QSFs are text-only; infer "
            "from references like \"see image above\", `<img>` tags in embedded_html, "
            "or instructions that mention spatial layout.\n\n"
            f"{_SHARED_RUBRIC}"
        ),
        related_bot_types=[
            BotDetectionType.HOVER_TRAP,
            BotDetectionType.MOUSE_TRACKING,
        ],
    ),
]


DIMENSIONS_BY_NAME = {d.name: d for d in DIMENSIONS}
