"""Static descriptive metadata for each BotDetectionType.

Used by `SurveyAnalyzer._generate_narrative_summary` to compose the
human-readable section of the analysis report. Each entry has two fields:

- ``what_it_is``     — one-sentence explanation of the mechanism
- ``why_it_matters`` — what bot population it filters out and how
"""

from typing import Dict

from surveyshield.models.survey_result import BotDetectionType


MECHANISM_CONTEXT: Dict[BotDetectionType, Dict[str, str]] = {
    BotDetectionType.CAPTCHA: {
        "what_it_is": "A CAPTCHA challenge (Completely Automated Public Turing test) that presents puzzles or image recognition tasks that are designed to be easy for humans but difficult for bots",
        "why_it_matters": "CAPTCHAs are one of the most effective bot detection methods because they require visual processing and complex reasoning that traditional bots struggle with"
    },
    BotDetectionType.IDENTITY_QUESTION: {
        "what_it_is": "A direct question asking whether the respondent is human, an AI, or a bot, often phrased as 'Are you a bot?' or 'Type X if human, type Y if AI'",
        "why_it_matters": "These questions directly challenge AI systems to misrepresent their identity, testing whether they will follow instructions to deceive or default to their training to identify themselves accurately"
    },
    BotDetectionType.REVERSE_SHIBBOLETH: {
        "what_it_is": "Questions that test for superhuman abilities like writing complex code, reciting long texts verbatim, solving advanced mathematics, or having encyclopedic knowledge that no typical human would possess",
        "why_it_matters": "These questions catch AI systems that might demonstrate capabilities beyond what a reasonable human respondent would have, revealing their non-human nature through overperformance"
    },
    BotDetectionType.IMPOSSIBLE_EVENT: {
        "what_it_is": "Questions asking about physically impossible or extremely implausible biographical events like 'Have you visited the moon?' or locations that don't exist",
        "why_it_matters": "These questions test whether a respondent applies common sense and real-world knowledge constraints, catching bots that might respond randomly or lack contextual awareness"
    },
    BotDetectionType.HOVER_TRAP: {
        "what_it_is": "Interactive elements that require hovering the mouse cursor over specific areas (often marked with arrows or special instructions) to trigger state changes before proceeding",
        "why_it_matters": "Hover interactions test for real mouse movements and user engagement, which simple automation scripts cannot easily replicate without specific programming"
    },
    BotDetectionType.ATTENTION_CHECK: {
        "what_it_is": "Questions with embedded instructions like 'Select option 3 if you are reading carefully' or 'Choose Strongly Disagree for this question'",
        "why_it_matters": "These checks catch inattentive respondents and simple bots that don't carefully read question text before responding"
    },
    BotDetectionType.LOGIC_PUZZLE: {
        "what_it_is": "Logical reasoning questions or syllogisms that test the ability to apply deductive reasoning, such as 'If all X are Y, and some Y are Z, can we conclude that all X are Z?'",
        "why_it_matters": "These questions test for genuine reasoning ability and catch bots that might respond randomly without understanding logical relationships"
    },
    BotDetectionType.READING_COMPREHENSION: {
        "what_it_is": "Questions that reference previous text, passages, or vignettes, requiring the respondent to recall and understand information presented earlier",
        "why_it_matters": "Comprehension checks test whether a respondent is actually reading and processing the survey content rather than clicking through randomly"
    },
    BotDetectionType.INSTRUCTION_FOLLOWING: {
        "what_it_is": "Explicit instructions directing the respondent to perform a specific action, such as 'Please select the second option' or 'Skip this question'",
        "why_it_matters": "These direct instructions test basic compliance and reading ability, filtering out the simplest forms of automated responses"
    },
    BotDetectionType.TIMING_TRAP: {
        "what_it_is": "Monitoring of response times to detect unnaturally fast completions or patterns that suggest automated form filling",
        "why_it_matters": "Human respondents need time to read and think; bots often complete surveys in impossible timeframes that reveal their automated nature"
    },
    BotDetectionType.INVISIBLE_TEXT: {
        "what_it_is": "Hidden instructions or text elements that are visible to screen readers and careful inspection but not immediately apparent, often using small fonts, white text on white backgrounds, or CSS opacity",
        "why_it_matters": "These hidden elements test whether a system is processing all page content (as a bot might) or only what's visually prominent (as a human would)"
    },
    BotDetectionType.HONEYPOT_FIELD: {
        "what_it_is": "Form fields that are hidden from human users but visible to bots, designed to trap automated form-filling scripts that complete every field",
        "why_it_matters": "Legitimate users should never fill these fields, so any response indicates automated form completion"
    },
    BotDetectionType.MOUSE_TRACKING: {
        "what_it_is": "Background monitoring of mouse movement patterns, cursor trajectories, click patterns, and interaction timing to detect non-human behavior",
        "why_it_matters": "Human mouse movements have characteristic patterns, hesitations, and imperfections that are difficult for bots to replicate authentically"
    },
    BotDetectionType.AUDIO_VIDEO_QUESTION: {
        "what_it_is": "Questions requiring the respondent to listen to audio clips or watch videos and answer questions about their content",
        "why_it_matters": "Audio and video questions test whether the respondent can process multimedia content, which traditional bots cannot do without specialized transcription capabilities"
    },
    BotDetectionType.OTHER: {
        "what_it_is": "An unclassified or custom bot detection mechanism",
        "why_it_matters": "Survey creators may employ novel detection methods beyond standard categories"
    },
}
