"""Parse Qualtrics QSF (Survey Format) files into a typed `ParsedSurvey`.

The QSF format is not officially documented; this parser was developed
against the fixtures in `example_qsf/` and the schema implied by Qualtrics'
v3 survey-definitions API. It is tolerant of two shapes that appear for the
`BL` (block) element's Payload: a list of blocks, and a dict of blocks
keyed by stringified integers.

Only the subset of fields the reviewer agents actually consume is extracted.
Phase 2 (modified-QSF download) will need the raw dict; the service layer
keeps that alongside, so the parser doesn't need to round-trip.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Tuple

from surveyshield.models.instrument_review import ParsedBlock, ParsedQuestion, ParsedSurvey


class QSFParseError(ValueError):
    """Raised when the input is not a parsable QSF file."""


def parse_qsf(raw: bytes | str) -> Tuple[ParsedSurvey, Dict[str, Any]]:
    """Parse a QSF file (JSON bytes or string) into a typed survey + the raw dict.

    Returns:
        (parsed, raw_dict). The raw dict is preserved for Phase 2's modified-QSF
        feature, which needs to apply edits without losing fields the parser
        didn't model. v1 callers can ignore the second element.
    """
    try:
        raw_dict: Dict[str, Any] = json.loads(raw)
    except (json.JSONDecodeError, TypeError) as e:
        raise QSFParseError(f"input is not valid JSON: {e}") from e

    if not isinstance(raw_dict, dict) or "SurveyEntry" not in raw_dict or "SurveyElements" not in raw_dict:
        raise QSFParseError(
            "input is not a Qualtrics QSF file "
            "(missing top-level SurveyEntry / SurveyElements)"
        )

    entry = raw_dict["SurveyEntry"]
    elements = raw_dict["SurveyElements"]
    if not isinstance(elements, list):
        raise QSFParseError("SurveyElements must be a list")

    questions = [
        _parse_question(e)
        for e in elements
        if e.get("Element") == "SQ"
    ]
    blocks = _parse_blocks(elements)
    flow = _parse_flow(elements)

    parsed = ParsedSurvey(
        name=entry.get("SurveyName") or "(untitled survey)",
        description=entry.get("SurveyDescription") or None,
        blocks=blocks,
        questions=questions,
        flow=flow,
    )
    return parsed, raw_dict


def _parse_question(element: Dict[str, Any]) -> ParsedQuestion:
    payload = element.get("Payload") or {}
    qid = element.get("PrimaryAttribute") or payload.get("QuestionID") or "(unknown)"

    # Validation can appear as None, a dict {"Settings": {...}}, or rarely a
    # bare string like "None" — only the dict form carries fields we read.
    validation_raw = payload.get("Validation")
    validation_settings: Dict[str, Any] = {}
    if isinstance(validation_raw, dict):
        settings = validation_raw.get("Settings")
        if isinstance(settings, dict):
            validation_settings = settings
    force_response = str(validation_settings.get("ForceResponse", "OFF")).upper() == "ON"

    # Choices come as a dict keyed by stringified int; ChoiceOrder gives the
    # canonical sequence. Fall back to insertion order if ChoiceOrder is absent.
    choices_raw = payload.get("Choices") or {}
    choice_order = payload.get("ChoiceOrder") or list(choices_raw.keys())
    choices: List[str] = []
    for idx in choice_order:
        entry = choices_raw.get(str(idx)) or choices_raw.get(idx) or {}
        display = entry.get("Display") if isinstance(entry, dict) else None
        if display:
            choices.append(str(display))

    embedded_html = _extract_embedded_html(payload)

    return ParsedQuestion(
        qid=str(qid),
        type=str(payload.get("QuestionType") or ""),
        subtype=payload.get("Selector"),
        text=str(payload.get("QuestionText") or ""),
        description=payload.get("QuestionDescription") or None,
        choices=choices,
        display_logic=payload.get("DisplayLogic") or None,
        validation=validation_settings or None,
        force_response=force_response,
        hidden=_question_is_hidden(payload),
        embedded_html=embedded_html,
    )


def _question_is_hidden(payload: Dict[str, Any]) -> bool:
    """Heuristic: a question is "hidden" if Configuration.Hidden is set, or
    if HiddenLogic is present and resolved to always-true. We don't evaluate
    the logic; presence alone is suspicious enough to flag for the reviewer.
    """
    if (payload.get("Configuration") or {}).get("Hidden"):
        return True
    if payload.get("HiddenLogic"):
        return True
    return False


def _extract_embedded_html(payload: Dict[str, Any]) -> Optional[str]:
    """If the question carries raw JS or HTML-shaped text, surface it for
    the reviewer to inspect. Bot-trap content often lives here.
    """
    js = payload.get("QuestionJS")
    text = payload.get("QuestionText") or ""
    has_html = "<" in text and ">" in text
    if not js and not has_html:
        return None
    parts: List[str] = []
    if has_html:
        parts.append(f"QuestionText: {text}")
    if js:
        parts.append(f"QuestionJS: {js}")
    return "\n\n".join(parts)


def _parse_blocks(elements: List[Dict[str, Any]]) -> List[ParsedBlock]:
    """The BL element's Payload is sometimes a dict (keyed by stringified
    indices) and sometimes a list. Normalize to a list of blocks.
    """
    bl = next((e for e in elements if e.get("Element") == "BL"), None)
    if bl is None:
        return []
    payload = bl.get("Payload")
    if isinstance(payload, dict):
        block_iter = payload.values()
    elif isinstance(payload, list):
        block_iter = payload
    else:
        return []

    blocks: List[ParsedBlock] = []
    for block in block_iter:
        if not isinstance(block, dict):
            continue
        question_ids = [
            be.get("QuestionID")
            for be in (block.get("BlockElements") or [])
            if be.get("Type") == "Question" and be.get("QuestionID")
        ]
        blocks.append(
            ParsedBlock(
                block_id=str(block.get("ID") or ""),
                description=str(block.get("Description") or block.get("Type") or ""),
                question_ids=question_ids,
            )
        )
    return blocks


def _parse_flow(elements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Keep the flow as raw dicts. Reviewers that care about branching can
    opt in; most won't read it."""
    fl = next((e for e in elements if e.get("Element") == "FL"), None)
    if fl is None:
        return []
    payload = fl.get("Payload") or {}
    flow = payload.get("Flow")
    return flow if isinstance(flow, list) else []


def summarize(parsed: ParsedSurvey) -> Dict[str, Any]:
    """Produce the small `parsed_summary` dict that goes into the report."""
    type_counts: Dict[str, int] = {}
    force_response_count = 0
    hidden_count = 0
    embedded_count = 0

    for q in parsed.questions:
        type_counts[q.type] = type_counts.get(q.type, 0) + 1
        if q.force_response:
            force_response_count += 1
        if q.hidden:
            hidden_count += 1
        if q.embedded_html:
            embedded_count += 1

    n = len(parsed.questions)
    return {
        "name": parsed.name,
        "n_questions": n,
        "n_blocks": len(parsed.blocks),
        "type_histogram": type_counts,
        "force_response_pct": round(100.0 * force_response_count / n, 1) if n else 0.0,
        "hidden_count": hidden_count,
        "embedded_html_count": embedded_count,
    }
