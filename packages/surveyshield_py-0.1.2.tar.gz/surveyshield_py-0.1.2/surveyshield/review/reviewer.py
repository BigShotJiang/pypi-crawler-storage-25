"""Static-instrument reviewer.

Pure functions composed by the router's BackgroundTasks worker:

- ``review_dimension``: one LLM call with structured output, wrapped in a
  per-call timeout. Failures are captured in ``DimensionReview.error``
  rather than raised, so one stuck dimension never poisons the whole review.
- ``run_review``: fan out reviewers via ``asyncio.gather`` under a
  semaphore. Renders the shared survey blob ONCE and prepends it to every
  prompt — identical prefix means OpenAI's automatic prompt cache hits
  across reviewers, halving the input token cost from the second one on.
- ``aggregate``: pure compute — overall_score, completion_likelihood,
  recommendations, narrative summary. No LLM call.
- ``build_methods_statement``: pure compute — copy-paste-ready paragraph
  for researchers' Methods sections.
- ``render_html``: Jinja2 render of the report template.

State management (FIFO storage, status transitions) lives in the router.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from collections import Counter, defaultdict
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from jinja2 import Environment, FileSystemLoader, Template, select_autoescape
from pydantic import BaseModel

from surveyshield._providers import provider_env_var
from surveyshield.models.instrument_review import (
    DimensionReview,
    Finding,
    InstrumentReview,
    OverallFeedback,
    ParsedSurvey,
    Recommendation,
    Severity,
)
from .dimensions import (
    DIMENSION_SET_VERSION,
    DIMENSIONS_BY_NAME,
    Dimension,
    DimensionOutput,
)

logger = logging.getLogger(__name__)


# Survey Shield citation. Single source of truth — update once when the
# paper is finalized and every report picks it up.
SURVEY_SHIELD_CITATION = {
    "short": "Fernandez et al., 2026",
    "apa": (
        "Fernandez, K., Low, A., Bogard, J., & Fox, C. R. (2026). Survey "
        "Shield: Static review of online survey instruments for resistance "
        "to non-human responses. [Manuscript in preparation]."
    ),
    "bibtex": (
        "@misc{fernandez2026surveyshield,\n"
        "  author = {Fernandez, K. and Low, A. and Bogard, J. and Fox, C. R.},\n"
        "  title = {Survey Shield: Static review of online survey instruments "
        "for resistance to non-human responses},\n"
        "  year = {2026},\n"
        "  note = {Manuscript in preparation},\n"
        "}"
    ),
}


# ---------------------------------------------------------------------------
# Shared survey blob
# ---------------------------------------------------------------------------

# Rendered once per `run_review` and prepended to every reviewer's prompt.
# Identical prefix across reviewers = automatic prompt-cache hits on OpenAI.
_SURVEY_BLOB_TEMPLATE = Template(
    "Survey: {{ survey.name }}\n"
    "Description: {{ survey.description or '(none)' }}\n"
    "Total questions: {{ survey.questions|length }}\n"
    "Total blocks: {{ survey.blocks|length }}\n"
    "\n"
    "Questions:\n"
    "{% for q in survey.questions %}"
    "[{{ q.qid }} | type={{ q.type }}{% if q.subtype %}/{{ q.subtype }}{% endif %} | force_response={{ q.force_response }}{% if q.hidden %} | hidden{% endif %}]\n"
    "{{ q.text }}\n"
    "{% if q.choices %}choices: {{ q.choices|join(' | ') }}\n{% endif %}"
    "{% if q.embedded_html %}embedded: {{ q.embedded_html[:400] }}\n{% endif %}"
    "{% endfor %}"
)


def _render_survey_blob(survey: ParsedSurvey) -> str:
    return _SURVEY_BLOB_TEMPLATE.render(survey=survey)


# ---------------------------------------------------------------------------
# Per-dimension LLM call
# ---------------------------------------------------------------------------


@lru_cache(maxsize=8)
def _make_llm(model_name: str):
    """Pick the right LangChain client for a model name. Cached because
    client construction does non-trivial work (httpx setup, validators)."""
    env_var = provider_env_var(model_name)
    if not os.getenv(env_var):
        raise RuntimeError(f"{env_var} not set; required for model {model_name!r}.")

    if env_var == "GOOGLE_API_KEY":
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
        except ImportError as e:
            raise RuntimeError(
                "Gemini reviewer requested but langchain-google-genai isn't installed."
            ) from e
        return ChatGoogleGenerativeAI(model=model_name)

    from langchain_openai import ChatOpenAI

    return ChatOpenAI(model=model_name)


async def review_dimension(
    survey_blob: str,
    dim: Dimension,
    *,
    model: str,
    timeout: float = 60.0,
) -> DimensionReview:
    """Run one reviewer agent. Always returns a DimensionReview; failures
    are captured in `.error` rather than raised."""
    start = time.monotonic()
    # Survey blob first so the identical prefix triggers OpenAI's prompt
    # cache for second-and-beyond reviewers in the fan-out.
    prompt = f"{survey_blob}\n\n{dim.prompt_template}"

    try:
        llm = _make_llm(model).with_structured_output(dim.output_schema)
        result: DimensionOutput = await asyncio.wait_for(
            llm.ainvoke(prompt), timeout=timeout
        )
        score = max(0.0, min(100.0, float(result.score)))
        return DimensionReview(
            dimension=dim.name,
            score=score,
            findings=list(result.findings or []),
            summary=result.summary or "",
            model=model,
            duration_seconds=time.monotonic() - start,
        )
    except asyncio.TimeoutError:
        logger.warning("reviewer timeout: dimension=%s timeout=%ss", dim.name, timeout)
        return DimensionReview(
            dimension=dim.name,
            score=0.0,
            findings=[],
            summary="(reviewer timed out)",
            model=model,
            duration_seconds=time.monotonic() - start,
            error=f"timeout after {timeout}s",
        )
    except Exception as e:  # noqa: BLE001 — failure capture is the point
        logger.exception("reviewer failed: dimension=%s", dim.name)
        return DimensionReview(
            dimension=dim.name,
            score=0.0,
            findings=[],
            summary="(reviewer failed)",
            model=model,
            duration_seconds=time.monotonic() - start,
            error=f"{type(e).__name__}: {e}",
        )


# ---------------------------------------------------------------------------
# Fan-out
# ---------------------------------------------------------------------------


async def run_review(
    survey: ParsedSurvey,
    dims: List[Dimension],
    *,
    model: str,
    max_concurrency: int = 6,
) -> Tuple[List[DimensionReview], str]:
    """Run all reviewers in parallel, semaphore-bounded.

    Returns ``(reviews, survey_blob)``. The blob is rendered once here and
    handed back so the orchestrator can also feed it to
    ``consolidate_and_summarize`` without a second render.
    """
    survey_blob = _render_survey_blob(survey)
    sem = asyncio.Semaphore(max_concurrency)

    async def _one(d: Dimension) -> DimensionReview:
        async with sem:
            return await review_dimension(survey_blob, d, model=model)

    reviews = await asyncio.gather(*(_one(d) for d in dims))
    return reviews, survey_blob


# ---------------------------------------------------------------------------
# Quote verification (post-fan-out, pre-aggregation)
# ---------------------------------------------------------------------------


_WS_RE = re.compile(r"\s+")


def _normalize(text: str) -> str:
    return _WS_RE.sub(" ", text).strip().lower()


def _build_question_haystacks(parsed: ParsedSurvey) -> Tuple[Dict[str, str], str]:
    """Pre-build the normalized haystacks once per review.

    Returns (per_question, survey_level) where:
    - ``per_question[qid]`` is the normalized concat of one question's text +
      description + choices.
    - ``survey_level`` is the normalized concat of survey name/description +
      every question's text + every choice — used for survey-level findings
      that can quote a representative phrase from anywhere.
    """
    per_question: Dict[str, str] = {}
    parts: List[str] = [parsed.name, parsed.description or ""]
    for q in parsed.questions:
        q_parts = [q.text, q.description or "", *q.choices]
        per_question[q.qid] = _normalize(" \n ".join(p for p in q_parts if p))
        parts.append(q.text)
        parts.extend(q.choices)
    survey_level = _normalize(" \n ".join(p for p in parts if p))
    return per_question, survey_level


def _verify_quote(
    finding: Finding,
    per_question: Dict[str, str],
    survey_level: str,
) -> bool:
    """Case-insensitive, whitespace-collapsed substring match against the
    pre-built haystacks. Per-question findings match against their cited
    question's haystack; survey-level findings match against the union."""
    excerpt = _normalize(finding.excerpt)
    if not excerpt:
        return False
    if finding.question_id:
        haystack = per_question.get(finding.question_id)
        # Returning False for an unknown QID is a hallucination signal — the
        # caller logs it the same as a fabricated quote.
        return haystack is not None and excerpt in haystack
    return excerpt in survey_level


def drop_unverified_quotes(
    reviews: List[DimensionReview], parsed: ParsedSurvey
) -> List[DimensionReview]:
    """Drop findings whose excerpt can't be located in the source survey.

    Mutates each review's findings list in place. Logs each drop with
    enough context to debug a noisy reviewer.
    """
    per_question, survey_level = _build_question_haystacks(parsed)
    for r in reviews:
        if r.error is not None:
            continue
        kept: List[Finding] = []
        for f in r.findings:
            if _verify_quote(f, per_question, survey_level):
                kept.append(f)
            else:
                logger.warning(
                    "dropping unverified finding: dim=%s qid=%s excerpt=%r",
                    r.dimension,
                    f.question_id,
                    f.excerpt[:80],
                )
        r.findings = kept
    return reviews


# ---------------------------------------------------------------------------
# Second-stage LLM call: consolidation + holistic feedback (one round trip)
# ---------------------------------------------------------------------------


class ConsolidationResult(BaseModel):
    """Output of the second-stage LLM call. Service-layer-only — not exposed
    on the public API; `aggregate` unpacks it into the InstrumentReview."""

    consolidated_findings: List[Finding] = []
    overall_feedback: OverallFeedback


_CONSOLIDATION_PROMPT_HEADER = (
    "You are consolidating per-dimension findings about a Qualtrics survey "
    "instrument's resistance to AI/bot respondents. SCOPE IS STRICTLY "
    "BOT-RESISTANCE: you are NOT a peer reviewer of the survey's substantive "
    "research, question wording, or methodology. Do not introduce findings "
    "or commentary about topic, theoretical framing, demographics, length, "
    "ordering, accessibility, or general writing quality.\n\n"
    "Two tasks, returned together:\n\n"
    "1) CONSOLIDATE FINDINGS. Merge findings from different dimensions that "
    "flag the same underlying bot-resistance problem. When you merge, "
    "preserve the most specific question_id, the strongest rationale, and "
    "the most concrete suggested_fix. List the source dimensions in "
    "`contributing_dimensions`. Do NOT invent new findings, do NOT change "
    "quoted excerpts, do NOT add general-survey-design critique, and do NOT "
    "drop a finding just because no other reviewer flagged it. Set "
    "`quote_verified=true` on every emitted finding (already verified "
    "upstream).\n\n"
    "2) OVERALL FEEDBACK. Write a focused bot-resistance assessment:\n"
    "  - `headline`: one sentence verdict about how well this instrument "
    "resists AI respondents (e.g., \"This instrument has limited defenses "
    "against AI respondents and would benefit from a small set of targeted "
    "additions.\").\n"
    "  - `paragraphs`: one or two short paragraphs synthesizing the "
    "strongest bot-resistance themes across dimensions, naming the most "
    "pressing concrete fixes, and acknowledging which defenses the "
    "instrument already has. Reference dimensions by name. Do NOT comment "
    "on the survey's substantive design, wording quality, or methodology — "
    "those are out of scope.\n\n"
    "Be concise, direct, and grounded in what the reviewers actually found."
)


def _build_consolidation_prompt(
    survey_blob: str, reviews: List[DimensionReview]
) -> str:
    chunks: List[str] = [_CONSOLIDATION_PROMPT_HEADER, "", "SURVEY:", survey_blob, ""]
    for r in reviews:
        if r.error is not None:
            continue
        chunks.append(f"--- DIMENSION: {r.dimension} (score {r.score:.0f}/100) ---")
        chunks.append(f"Summary: {r.summary}")
        if not r.findings:
            chunks.append("No findings.")
        else:
            for i, f in enumerate(r.findings, 1):
                qid = f.question_id or "(survey-level)"
                chunks.append(
                    f"{i}. [{qid}] severity={f.severity.name} "
                    f"confidence={f.confidence:.2f} "
                    f"edit_kind={f.recommended_edit_kind.value}"
                )
                chunks.append(f"   excerpt: {f.excerpt}")
                chunks.append(f"   rationale: {f.rationale}")
                if f.suggested_fix:
                    chunks.append(f"   fix: {f.suggested_fix}")
        chunks.append("")
    return "\n".join(chunks)


async def consolidate_and_summarize(
    survey_blob: str,
    reviews: List[DimensionReview],
    *,
    model: str,
    timeout: float = 90.0,
) -> Optional[ConsolidationResult]:
    """Second-stage LLM call. Returns None on timeout/error so the pipeline
    can fall back to the pure-Python aggregation path.

    Takes the pre-rendered survey blob (rendered once by the orchestrator
    and reused across reviewer + consolidation calls). Timeout is 90s vs
    the per-reviewer 60s because consolidation has more context to chew on.
    """
    if not any(r.findings for r in reviews if r.error is None):
        return ConsolidationResult(
            consolidated_findings=[],
            overall_feedback=OverallFeedback(
                headline="No dimension surfaced specific findings.",
                paragraphs=[
                    "Reviewers completed without flagging any concrete issues. "
                    "See the per-dimension scores and narrative summary for the "
                    "high-level verdict."
                ],
            ),
        )

    prompt = _build_consolidation_prompt(survey_blob, reviews)

    try:
        llm = _make_llm(model).with_structured_output(ConsolidationResult)
        return await asyncio.wait_for(llm.ainvoke(prompt), timeout=timeout)
    except Exception as e:  # noqa: BLE001
        logger.exception("consolidate_and_summarize failed: %s", e)
        return None


# ---------------------------------------------------------------------------
# Aggregation (pure compute)
# ---------------------------------------------------------------------------


def aggregate(
    survey: ParsedSurvey,
    reviews: List[DimensionReview],
    *,
    review_id: str,
    filename: str,
    parsed_summary: Dict[str, Any],
    model: str,
    consolidation: Optional[ConsolidationResult] = None,
) -> InstrumentReview:
    """Combine per-dimension reviews into the final InstrumentReview.

    `consolidation` is the second-stage LLM output: when present, its
    `consolidated_findings` drive the recommendations list and its
    `overall_feedback` is stored verbatim. When absent (LLM error or
    no findings to consolidate), we fall back to the per-dimension findings
    with the legacy (kind, qid) dedup, plus a synthesized headline that
    points readers at the deterministic narrative_summary.
    """
    timestamp = datetime.now()
    successful = [r for r in reviews if r.error is None]

    overall_score = _weighted_mean(
        [(r.score, _dim_weight(r.dimension)) for r in successful]
    )

    # `completion_likelihood` measures how easy this survey is for an
    # automated agent to complete — runs OPPOSITE to defense score.
    completion_pairs = [
        (100.0 - r.score, _dim_completion_weight(r.dimension))
        for r in successful
        if _dim_completion_weight(r.dimension) > 0
    ]
    if completion_pairs:
        completion_likelihood = _weighted_mean(completion_pairs)
    else:
        # No completion-weight-bearing dimensions succeeded (either none
        # declared one, or they all errored). Fall back to the inverse of
        # overall_score so the metric is consistent with intuition: low
        # defense → high bot completion likelihood.
        completion_likelihood = 100.0 - overall_score

    if consolidation is not None:
        recommendations = _build_recommendations_from_findings(
            consolidation.consolidated_findings
        )
        overall_feedback = consolidation.overall_feedback
    else:
        recommendations = _build_recommendations_from_reviews(reviews)
        overall_feedback = OverallFeedback(
            headline="(holistic feedback unavailable; see narrative summary)",
            paragraphs=[],
        )

    narrative = _build_narrative(survey, reviews, overall_score, completion_likelihood)
    parameters = {"model": model, "dimension_set_version": DIMENSION_SET_VERSION}

    methods = _compose_methods_statement(
        review_id=review_id,
        timestamp=timestamp,
        successful_dims=[r.dimension for r in successful],
        overall_score=overall_score,
        completion_likelihood=completion_likelihood,
    )

    return InstrumentReview(
        review_id=review_id,
        filename=filename,
        timestamp=timestamp,
        overall_score=round(overall_score, 1),
        completion_likelihood=round(completion_likelihood, 1),
        parsed_summary=parsed_summary,
        dimensions=reviews,
        recommendations=recommendations,
        overall_feedback=overall_feedback,
        narrative_summary=narrative,
        methods_statement=methods,
        parameters=parameters,
    )


def _dim_weight(name: str) -> float:
    d = DIMENSIONS_BY_NAME.get(name)
    return d.weight if d else 1.0


def _dim_completion_weight(name: str) -> float:
    d = DIMENSIONS_BY_NAME.get(name)
    return d.completion_weight if d else 0.0


def _weighted_mean(pairs: List[Tuple[float, float]]) -> float:
    total_weight = sum(w for _, w in pairs)
    if total_weight <= 0:
        return 0.0
    return sum(v * w for v, w in pairs) / total_weight


_REC_CAP = 8


def _finalize_recommendations(
    items: List[Tuple[Finding, List[str]]],
) -> List[Recommendation]:
    """Rank ``(finding, related_dimensions)`` pairs by severity*confidence,
    cap at ``_REC_CAP``, build Recommendations, sort by priority. Shared
    tail used by both the consolidated and the fallback paths."""
    items.sort(
        key=lambda pair: -(float(pair[0].severity) * float(pair[0].confidence))
    )
    out: List[Recommendation] = []
    for finding, related in items[:_REC_CAP]:
        title_dim = related[0] if related else "consolidated"
        out.append(
            Recommendation(
                title=_recommendation_title(finding, title_dim),
                detail=finding.suggested_fix or finding.rationale,
                priority=_priority_for(finding.severity),
                related_dimensions=related,
            )
        )
    out.sort(key=lambda r: r.priority)
    return out


def _build_recommendations_from_reviews(
    reviews: List[DimensionReview],
) -> List[Recommendation]:
    """Fallback path used when consolidation failed: pure-Python dedup by
    ``(recommended_edit_kind, question_id)``. Two questions needing the same
    fix both show up; only literal duplicates merge into a single rec."""
    seen: Dict[Tuple[str, Optional[str]], List[str]] = {}
    items: List[Tuple[Finding, List[str]]] = []
    for r in reviews:
        if r.error is not None:
            continue
        for f in r.findings:
            kind = f.recommended_edit_kind.value
            key = (kind, f.question_id)
            if kind != "none" and key in seen:
                related = seen[key]
                if r.dimension not in related:
                    related.append(r.dimension)
                continue
            related = [r.dimension]
            if kind != "none":
                seen[key] = related
            items.append((f, related))
    return _finalize_recommendations(items)


def _build_recommendations_from_findings(
    findings: List[Finding],
) -> List[Recommendation]:
    """Happy path: consolidation already merged duplicates semantically.
    Just hand each finding through with its declared contributing_dimensions."""
    return _finalize_recommendations(
        [(f, list(f.contributing_dimensions)) for f in findings]
    )


def _priority_for(severity: Severity) -> int:
    return {Severity.HIGH: 1, Severity.MED: 2, Severity.LOW: 3}.get(severity, 3)


def _recommendation_title(finding: Finding, dim_name: str) -> str:
    if finding.question_id:
        return f"[{dim_name}] {finding.question_id}: {finding.rationale[:80]}"
    return f"[{dim_name}] {finding.rationale[:80]}"


def _build_narrative(
    survey: ParsedSurvey,
    reviews: List[DimensionReview],
    overall_score: float,
    completion_likelihood: float,
) -> str:
    """Compose a prose paragraph from structured findings, no LLM call."""
    n = len(survey.questions)
    lines: List[str] = []
    lines.append(
        f"This instrument has {n} question{'s' if n != 1 else ''} across "
        f"{len(survey.blocks)} block{'s' if len(survey.blocks) != 1 else ''}. "
        f"Reviewed across {len(reviews)} dimension{'s' if len(reviews) != 1 else ''}, "
        f"the overall defense score is {overall_score:.0f}/100 and the "
        f"estimated completion-likelihood for an automated agent is "
        f"{completion_likelihood:.0f}/100."
    )

    failed = [r for r in reviews if r.error is not None]
    if failed:
        names = ", ".join(r.dimension for r in failed)
        lines.append(
            f"\nNote: the following dimensions did not complete and were "
            f"weighted at zero in the overall score: {names}."
        )

    successful = [r for r in reviews if r.error is None]
    if successful:
        ranked = sorted(successful, key=lambda r: r.score)
        weakest = ranked[0]
        strongest = ranked[-1]
        if weakest.dimension != strongest.dimension:
            lines.append(
                f"\nThe weakest dimension is **{weakest.dimension}** "
                f"({weakest.score:.0f}/100). The strongest is "
                f"**{strongest.dimension}** ({strongest.score:.0f}/100)."
            )

    finding_counts = Counter(
        f.severity.name for r in successful for f in r.findings
    )
    if finding_counts:
        parts = [f"{finding_counts[s]} {s.lower()}" for s in ("HIGH", "MED", "LOW") if finding_counts[s]]
        lines.append("\nFindings: " + ", ".join(parts) + ".")

    return " ".join(lines).strip()


def _compose_methods_statement(
    *,
    review_id: str,
    timestamp: datetime,
    successful_dims: List[str],
    overall_score: float,
    completion_likelihood: float,
) -> str:
    dim_list = ", ".join(successful_dims) or "none"
    return (
        f"We evaluated this instrument for resistance to non-human responses "
        f"using Survey Shield ({SURVEY_SHIELD_CITATION['short']}), "
        f"reviewing it across {len(successful_dims)} dimension"
        f"{'s' if len(successful_dims) != 1 else ''}: {dim_list}. The instrument "
        f"received an overall defense score of {overall_score:.0f}/100 "
        f"and an estimated completion-likelihood for automated agents of "
        f"{completion_likelihood:.0f}/100. Review ID: {review_id} "
        f"({timestamp.strftime('%Y-%m-%d')})."
    )


def build_methods_statement(review: InstrumentReview) -> str:
    """Re-derive the methods statement from a stored review (used by tests
    and by callers that want the string without re-running aggregation)."""
    successful = [d.dimension for d in review.dimensions if d.error is None]
    return _compose_methods_statement(
        review_id=review.review_id,
        timestamp=review.timestamp,
        successful_dims=successful,
        overall_score=review.overall_score,
        completion_likelihood=review.completion_likelihood,
    )


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------


# Templates live at surveyshield/review/templates/. The `__file__`-relative
# path works for both editable and built-wheel installs because pyproject.toml
# lists `review/templates/*.html` as package_data.
_TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"
_jinja_env: Optional[Environment] = None


def _env() -> Environment:
    global _jinja_env
    if _jinja_env is None:
        _jinja_env = Environment(
            loader=FileSystemLoader(str(_TEMPLATE_DIR)),
            autoescape=select_autoescape(["html"]),
        )
    return _jinja_env


def render_html(review: InstrumentReview, survey: ParsedSurvey) -> str:
    template = _env().get_template("instrument_report.html")
    findings_by_qid: Dict[str, List[Tuple[str, Finding]]] = defaultdict(list)
    for d in review.dimensions:
        if d.error is not None:
            continue
        for f in d.findings:
            if f.question_id:
                findings_by_qid[f.question_id].append((d.dimension, f))
    return template.render(
        review=review,
        survey=survey,
        findings_by_qid=findings_by_qid,
        citation=SURVEY_SHIELD_CITATION,
    )


# ---------------------------------------------------------------------------
# High-level facade for library users
# ---------------------------------------------------------------------------


def _resolve_qsf_input(
    qsf: "str | bytes | os.PathLike[str]",
    filename: Optional[str],
) -> Tuple[bytes, str]:
    """Accept a path, bytes, or JSON string; return ``(raw, filename)``."""
    if isinstance(qsf, bytes):
        return qsf, filename or "upload.qsf"
    if isinstance(qsf, str):
        try:
            path = Path(qsf)
            return path.read_bytes(), filename or path.name
        except (OSError, ValueError):
            return qsf.encode(), filename or "upload.qsf"
    path = Path(os.fspath(qsf))
    return path.read_bytes(), filename or path.name


async def review_qsf(
    qsf: "str | bytes | os.PathLike[str]",
    *,
    model: str = "gpt-4o-mini",
    api_key: Optional[str] = None,
    dimensions: Optional[List[str]] = None,
    filename: Optional[str] = None,
    review_id: Optional[str] = None,
) -> Tuple[InstrumentReview, ParsedSurvey]:
    """One-call entry point for the static review pipeline.

    Accepts a path-like, raw bytes, or a JSON string; runs parse →
    fan-out → quote-verification → consolidation → aggregate, and returns
    the ``(InstrumentReview, ParsedSurvey)`` pair so callers can render
    HTML or JSON without re-parsing.

    ``api_key`` is written into the right env var for ``model``. ``review_id``
    lets callers (e.g., the FastAPI router) preserve a queued ID.
    """
    import uuid

    from .parser import parse_qsf, summarize
    from .dimensions import DIMENSIONS, DIMENSIONS_BY_NAME

    if api_key:
        os.environ[provider_env_var(model)] = api_key

    raw, resolved_filename = _resolve_qsf_input(qsf, filename)
    parsed, _raw_dict = parse_qsf(raw)

    if dimensions:
        dims = [DIMENSIONS_BY_NAME[n] for n in dimensions if n in DIMENSIONS_BY_NAME]
        if not dims:
            raise ValueError(
                f"no valid dimensions selected. Known: {list(DIMENSIONS_BY_NAME)}"
            )
    else:
        dims = DIMENSIONS

    reviews, survey_blob = await run_review(parsed, dims, model=model)
    reviews = drop_unverified_quotes(reviews, parsed)
    consolidation = await consolidate_and_summarize(survey_blob, reviews, model=model)
    review = aggregate(
        parsed,
        reviews,
        review_id=review_id or str(uuid.uuid4()),
        filename=resolved_filename,
        parsed_summary=summarize(parsed),
        model=model,
        consolidation=consolidation,
    )
    return review, parsed
