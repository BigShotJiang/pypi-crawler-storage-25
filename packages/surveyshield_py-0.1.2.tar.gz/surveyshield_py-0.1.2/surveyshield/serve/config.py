"""Application configuration constants.

Most environment variables (OPENAI_API_KEY, GOOGLE_API_KEY, HEADLESS_MODE,
TYPING_DELAY_MIN/MAX, DYNO) are read directly via `os.getenv` at the call
site where they're used, not centralized here.
"""

import os

API_V1_STR = "/api/v1"

BACKEND_CORS_ORIGINS = os.getenv(
    "BACKEND_CORS_ORIGINS",
    "http://localhost:3000,http://localhost:3001,http://localhost:3002,"
    "http://127.0.0.1:3000,http://127.0.0.1:3001,http://127.0.0.1:3002,"
    "http://localhost:8000,http://127.0.0.1:8000",
).split(",")
