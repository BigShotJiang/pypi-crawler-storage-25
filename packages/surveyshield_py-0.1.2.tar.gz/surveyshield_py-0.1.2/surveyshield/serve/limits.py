"""Per-IP rate limiting for the hosted demo.

Protects ``OPENAI_API_KEY`` / ``GOOGLE_API_KEY`` from being burned by a
loop hitting the LLM-fanout endpoints.

Trust-proxy note: ``get_remote_address`` reads ``request.client.host``,
which Starlette's ``ProxyHeadersMiddleware`` rewrites from the leftmost
``X-Forwarded-For`` entry — but only when the upstream is in the trusted
list. Run uvicorn/gunicorn with ``--forwarded-allow-ips="*"`` (the
Procfile and ``bin/start.sh`` already do) so Heroku's router is trusted
and direct clients can't spoof their IP via a forged header.
"""

from slowapi import Limiter
from slowapi.util import get_remote_address


# Per-IP caps. Live runtime costs ~10x more LLM credit per call so its
# cap is tighter. Adjust here, not at the call site.
INSTRUMENT_LIMIT = "5/hour;20/day"
SURVEY_LIMIT = "3/hour;10/day"


limiter = Limiter(key_func=get_remote_address)
