"""Survey analysis API endpoints."""

import os
import uuid
from collections import Counter, OrderedDict
from typing import Any

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request

from surveyshield.models.survey_result import SurveyAnalysisRequest, SurveyAnalysisResult
from surveyshield.serve.limits import SURVEY_LIMIT, limiter

router = APIRouter()


def _require_live() -> None:
    """Raise 503 if the ``[live]`` extra isn't installed. Hosted/review-only
    deployments don't ship browser-use; only ``/analyze`` needs it."""
    try:
        import surveyshield.live.analyzer  # noqa: F401
    except ImportError as e:
        raise HTTPException(
            status_code=503,
            detail=(
                "Live runtime is not available on this deployment. "
                "Self-hosters: install with `pip install surveyshield-py[live]` "
                "and set OPENAI_API_KEY / GOOGLE_API_KEY."
            ),
        ) from e

# Process-local state. Capped FIFO so a long-running worker doesn't grow
# unbounded — see Procfile (gunicorn -w 1) for why we keep this in-process
# rather than backing with Redis. Replace with a real store before scaling out.
_MAX_RETAINED_ANALYSES = 100
analysis_results: "OrderedDict[str, Any]" = OrderedDict()
analysis_status: "OrderedDict[str, str]" = OrderedDict()


def _record_status(analysis_id: str, status: str) -> None:
    analysis_status[analysis_id] = status
    while len(analysis_status) > _MAX_RETAINED_ANALYSES:
        evicted_id, _ = analysis_status.popitem(last=False)
        analysis_results.pop(evicted_id, None)


def _record_result(analysis_id: str, payload: Any) -> None:
    analysis_results[analysis_id] = payload
    while len(analysis_results) > _MAX_RETAINED_ANALYSES:
        evicted_id, _ = analysis_results.popitem(last=False)
        analysis_status.pop(evicted_id, None)


async def run_analysis_task(analysis_id: str, request: SurveyAnalysisRequest):
    """Background task to run survey analysis."""
    try:
        _record_status(analysis_id, "running")

        from surveyshield.live.analyzer import SurveyAnalyzer

        analyzer = SurveyAnalyzer(
            model_name=request.model_name,
            max_steps=request.max_steps,
            use_vision=request.use_vision,
            verbose=True,
        )

        result = await analyzer.analyze_survey(survey_url=str(request.survey_url))

        _record_result(analysis_id, result.model_dump())
        _record_status(analysis_id, "completed")

    except Exception as e:
        _record_status(analysis_id, "failed")
        _record_result(
            analysis_id,
            {
                "error": str(e),
                "error_type": type(e).__name__,
                "completed": False,
            },
        )


@router.post("/analyze", response_model=dict)
@limiter.limit(SURVEY_LIMIT)
async def submit_survey_analysis(
    request: Request,
    analysis_request: SurveyAnalysisRequest,
    background_tasks: BackgroundTasks,
):
    """Submit a survey for analysis.

    Any model name browser-use's ChatOpenAI / ChatGoogle accept is allowed.
    Routing in the analyzer is by prefix: names starting with "gemini" go to
    Google (requires GOOGLE_API_KEY), everything else goes to OpenAI
    (requires OPENAI_API_KEY). Invalid model IDs surface as upstream API
    errors when the analysis runs.
    """
    _require_live()
    try:
        analysis_id = str(uuid.uuid4())
        _record_status(analysis_id, "queued")
        background_tasks.add_task(run_analysis_task, analysis_id, analysis_request)

        return {
            "analysis_id": analysis_id,
            "status": "queued",
            "message": "Survey analysis started. Use the analysis_id to check progress.",
            "estimated_time": "5-10 minutes",
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status/{analysis_id}")
async def get_analysis_status(analysis_id: str):
    """Get the status of a survey analysis."""
    if analysis_id not in analysis_status:
        raise HTTPException(status_code=404, detail="Analysis not found")

    status = analysis_status[analysis_id]
    response = {"analysis_id": analysis_id, "status": status}

    if status == "completed":
        response["ready"] = True
        response["message"] = "Analysis completed. Retrieve results using /results endpoint."
    elif status == "running":
        response["message"] = "Analysis in progress..."
    elif status == "failed":
        response["message"] = "Analysis failed. Check error details in results."
    else:
        response["message"] = "Analysis queued for processing..."

    return response


@router.get("/results/{analysis_id}", response_model=SurveyAnalysisResult)
async def get_analysis_results(analysis_id: str):
    """Get the results of a completed survey analysis."""
    if analysis_id not in analysis_results:
        raise HTTPException(status_code=404, detail="Analysis results not found")

    if analysis_status.get(analysis_id) not in ["completed", "failed"]:
        raise HTTPException(status_code=400, detail="Analysis not yet completed")

    result_data = analysis_results[analysis_id]

    if "error" in result_data:
        raise HTTPException(
            status_code=500,
            detail={
                "error": result_data["error"],
                "error_type": result_data.get("error_type", "Unknown"),
                "analysis_failed": True,
            },
        )

    return SurveyAnalysisResult(**result_data)


@router.get("/results/{analysis_id}/summary")
async def get_analysis_summary(analysis_id: str):
    """Get a summary of analysis results."""
    if analysis_id not in analysis_results:
        raise HTTPException(status_code=404, detail="Analysis results not found")

    if analysis_status.get(analysis_id) != "completed":
        raise HTTPException(status_code=400, detail="Analysis not yet completed")

    result_data = analysis_results[analysis_id]

    if "error" in result_data:
        return {"error": result_data["error"]}

    result = SurveyAnalysisResult(**result_data)
    type_counts = Counter(m.type.value for m in result.bot_mechanisms)

    return {
        "analysis_id": analysis_id,
        "survey_domain": result.survey_domain,
        "completed": result.completed,
        "success_probability": result.success_probability,
        "difficulty_score": result.difficulty_score,
        "detected_mechanisms": result.detected_mechanisms,
        "steps_taken": result.steps_taken,
        "time_seconds": result.time_seconds,
        "mechanisms_by_type": {t: {"count": n} for t, n in type_counts.items()},
    }


@router.delete("/results/{analysis_id}")
async def delete_analysis_results(analysis_id: str):
    """Delete analysis results and status."""
    if analysis_id not in analysis_status:
        raise HTTPException(status_code=404, detail="Analysis not found")

    analysis_status.pop(analysis_id, None)
    analysis_results.pop(analysis_id, None)

    return {"message": "Analysis results deleted successfully"}


@router.get("/config")
async def get_config():
    """Surface deploy-time capability flags to the frontend.

    `live_take_enabled` is true when the backend has an LLM API key
    available — i.e., a self-hoster has set OPENAI_API_KEY or
    GOOGLE_API_KEY in their .env. The hosted demo doesn't set these,
    so the Take Survey tab renders a self-host explainer instead of
    the live-runtime form.
    """
    return {
        "live_take_enabled": bool(
            os.getenv("OPENAI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        ),
    }


@router.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "Survey Shield API",
        "version": "1.0.0",
    }
