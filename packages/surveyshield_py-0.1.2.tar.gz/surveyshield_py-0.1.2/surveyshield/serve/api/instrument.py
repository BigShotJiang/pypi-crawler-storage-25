"""Instrument-review API endpoints.

Mirror of `survey.py`'s shape: process-local FIFO storage capped at 100,
status polling, and a BackgroundTasks worker that runs the static review
without blocking the request that submitted it.

The runtime constraint (single gunicorn worker so module-level state is
addressable) is identical to `survey.py` — see Procfile.
"""

import logging
import uuid
from collections import OrderedDict
from typing import Any, Dict, Optional

from fastapi import APIRouter, BackgroundTasks, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse

from surveyshield.models.instrument_review import InstrumentReview, ParsedSurvey
from surveyshield.review.dimensions import DIMENSIONS
from surveyshield.review.reviewer import render_html, review_qsf
from surveyshield.review.parser import QSFParseError
from surveyshield.serve.limits import INSTRUMENT_LIMIT, limiter

router = APIRouter()
logger = logging.getLogger(__name__)

_MAX_RETAINED_REVIEWS = 100

# Three dicts kept in lock-step, all FIFO-evicted together. Phase 2 (modified-
# QSF download) will need the original raw bytes; that storage gets added when
# Phase 2 lands rather than carrying ~1 MB per review around for nothing now.
review_results: "OrderedDict[str, Any]" = OrderedDict()
review_status: "OrderedDict[str, str]" = OrderedDict()
review_parsed: "OrderedDict[str, ParsedSurvey]" = OrderedDict()


def _evict() -> None:
    while len(review_status) > _MAX_RETAINED_REVIEWS:
        evicted, _ = review_status.popitem(last=False)
        review_results.pop(evicted, None)
        review_parsed.pop(evicted, None)


def _record_status(review_id: str, status: str) -> None:
    review_status[review_id] = status
    _evict()


def _record_result(review_id: str, payload: Any) -> None:
    review_results[review_id] = payload
    _evict()


async def _run_review_task(
    review_id: str,
    raw: bytes,
    filename: str,
    model_name: str,
    dimension_names: Optional[list[str]],
) -> None:
    try:
        _record_status(review_id, "running")
        result, parsed = await review_qsf(
            raw,
            model=model_name,
            dimensions=dimension_names,
            filename=filename,
            review_id=review_id,
        )
        review_parsed[review_id] = parsed
        _record_result(review_id, result.model_dump(mode="json"))
        _record_status(review_id, "completed")

    except QSFParseError as e:
        logger.warning("QSF parse failed: review=%s err=%s", review_id, e)
        _record_status(review_id, "failed")
        _record_result(
            review_id,
            {"error": str(e), "error_type": "QSFParseError", "completed": False},
        )
    except Exception as e:  # noqa: BLE001
        logger.exception("review failed: review=%s", review_id)
        _record_status(review_id, "failed")
        _record_result(
            review_id,
            {"error": str(e), "error_type": type(e).__name__, "completed": False},
        )


@router.post("/review")
@limiter.limit(INSTRUMENT_LIMIT)
async def submit_instrument_review(
    request: Request,
    background_tasks: BackgroundTasks,
    file: UploadFile = File(..., description="Qualtrics QSF export"),
    model_name: str = Form("gpt-4o-mini"),
    dimensions: Optional[str] = Form(
        None, description="Comma-separated dimension names; omit for all."
    ),
):
    """Upload a QSF and start a static review."""
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="empty upload")

    review_id = str(uuid.uuid4())
    _record_status(review_id, "queued")

    dim_names = (
        [n.strip() for n in dimensions.split(",") if n.strip()]
        if dimensions
        else None
    )

    background_tasks.add_task(
        _run_review_task,
        review_id,
        raw,
        file.filename or "upload.qsf",
        model_name,
        dim_names,
    )

    return {
        "review_id": review_id,
        "status": "queued",
        "message": "Review started. Poll /status/{id} until completed.",
        "estimated_time": "30-90 seconds",
    }


@router.get("/status/{review_id}")
async def get_status(review_id: str):
    if review_id not in review_status:
        raise HTTPException(status_code=404, detail="review not found")

    status = review_status[review_id]
    response = {"review_id": review_id, "status": status}

    if status == "completed":
        response["ready"] = True
        response["message"] = "Review complete. Fetch /results/{id} or /report/{id}."
    elif status == "running":
        response["message"] = "Review in progress..."
    elif status == "failed":
        response["message"] = "Review failed. Error details in /results/{id}."
    else:
        response["message"] = "Review queued for processing..."

    return response


@router.get("/results/{review_id}", response_model=InstrumentReview)
async def get_results(review_id: str):
    if review_id not in review_results:
        raise HTTPException(status_code=404, detail="review results not found")

    if review_status.get(review_id) not in ("completed", "failed"):
        raise HTTPException(status_code=400, detail="review not yet completed")

    payload = review_results[review_id]
    if "error" in payload:
        raise HTTPException(
            status_code=500,
            detail={
                "error": payload["error"],
                "error_type": payload.get("error_type", "Unknown"),
                "review_failed": True,
            },
        )
    return InstrumentReview(**payload)


@router.get("/report/{review_id}", response_class=HTMLResponse)
async def get_report(review_id: str, download: int = 0):
    """Server-rendered HTML report. Self-contained, no external assets.

    Pass `?download=1` to force a download with a `Content-Disposition`
    header instead of inline rendering — used by the "Download Report"
    button in the UI so researchers can share/archive a standalone file.
    """
    if review_id not in review_results:
        raise HTTPException(status_code=404, detail="review results not found")
    if review_status.get(review_id) != "completed":
        raise HTTPException(status_code=400, detail="review not yet completed")

    payload = review_results[review_id]
    if "error" in payload:
        raise HTTPException(
            status_code=500,
            detail={"error": payload["error"], "review_failed": True},
        )

    parsed = review_parsed.get(review_id)
    if parsed is None:
        raise HTTPException(
            status_code=500,
            detail="parsed-survey state missing; re-run the review",
        )

    review = InstrumentReview(**payload)
    headers: Dict[str, str] = {}
    if download:
        # Strip the .qsf suffix (case-insensitive) so the download is
        # `<filename>_review.html` rather than `<filename>.qsf_review.html`.
        stem = review.filename
        if stem.lower().endswith(".qsf"):
            stem = stem[:-4]
        download_name = f"{stem or 'survey'}_review.html"
        # Quote the filename minimally so spaces/parentheses survive.
        headers["Content-Disposition"] = f'attachment; filename="{download_name}"'
    return HTMLResponse(content=render_html(review, parsed), headers=headers)


@router.delete("/{review_id}")
async def delete_review(review_id: str):
    if review_id not in review_status:
        raise HTTPException(status_code=404, detail="review not found")
    review_status.pop(review_id, None)
    review_results.pop(review_id, None)
    review_parsed.pop(review_id, None)
    return {"message": "review deleted"}


@router.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "Survey Shield Instrument Review",
        "version": "1.0.0",
        "dimensions": [d.name for d in DIMENSIONS],
    }
