"""Survey Shield command-line interface.

Three commands:

- ``surveyshield review FILE.qsf`` — runs the static review pipeline and
  writes JSON, HTML, or both. The default writes a self-contained HTML
  report next to the input file.
- ``surveyshield take URL`` — drives a real browser through a Qualtrics
  URL. Requires the ``[live]`` extra.
- ``surveyshield serve`` — boots the FastAPI app + bundled React SPA on
  ``http://127.0.0.1:8000``.

The CLI doesn't try to be a config layer: API keys come from the
environment (or ``.env`` loaded by python-dotenv), exactly the way the
library does it.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import typer
from dotenv import load_dotenv

from surveyshield._version import __version__

app = typer.Typer(
    name="surveyshield",
    help="Static review of online survey instruments for resistance to AI/bot respondents.",
    no_args_is_help=True,
    add_completion=False,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"surveyshield {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show the Survey Shield version and exit.",
    ),
) -> None:
    pass


@app.command()
def review(
    qsf_path: Path = typer.Argument(
        ..., exists=True, dir_okay=False, readable=True,
        help="Path to a Qualtrics QSF export.",
    ),
    model: str = typer.Option(
        "gpt-4o-mini", "--model", "-m",
        help="Reviewer model (gpt-* → OpenAI, gemini-* → Google).",
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o",
        help="HTML report output path. Default: <qsf_basename>.report.html.",
    ),
    json_output: Optional[Path] = typer.Option(
        None, "--json",
        help="Also write the InstrumentReview as JSON to this path.",
    ),
    api_key: Optional[str] = typer.Option(
        None, "--api-key",
        help="Override OPENAI_API_KEY / GOOGLE_API_KEY for this run.",
    ),
    dimensions: Optional[str] = typer.Option(
        None, "--dimensions",
        help="Comma-separated dimension names; omit to run all.",
    ),
) -> None:
    """Run a static review against a QSF file and write a report."""
    load_dotenv()
    from surveyshield.review.reviewer import render_html, review_qsf

    dim_list = (
        [n.strip() for n in dimensions.split(",") if n.strip()]
        if dimensions
        else None
    )

    typer.echo(f"Reviewing {qsf_path.name} with {model}…")
    instrument_review, parsed = asyncio.run(
        review_qsf(
            qsf_path,
            model=model,
            api_key=api_key,
            dimensions=dim_list,
        )
    )

    html_path = output or qsf_path.with_suffix("").with_suffix(".report.html")
    html_path.write_text(render_html(instrument_review, parsed), encoding="utf-8")
    typer.echo(f"  HTML → {html_path}")

    if json_output is not None:
        json_output.write_text(
            instrument_review.model_dump_json(indent=2), encoding="utf-8"
        )
        typer.echo(f"  JSON → {json_output}")

    typer.echo(
        f"  overall defense: {instrument_review.overall_score:.0f}/100   "
        f"completion likelihood (bot): {instrument_review.completion_likelihood:.0f}/100"
    )
    headline = instrument_review.overall_feedback.headline
    if headline:
        typer.echo(f"  → {headline}")


@app.command()
def take(
    url: str = typer.Argument(..., help="Qualtrics survey URL."),
    model: str = typer.Option(
        "gemini-3-flash-preview", "--model", "-m",
        help="Browser-driving model (gemini-* or gpt-*).",
    ),
    max_steps: int = typer.Option(
        150, "--max-steps", help="Cap the agent step budget."
    ),
    no_vision: bool = typer.Option(
        False, "--no-vision", help="Disable screenshot tool."
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
    api_key: Optional[str] = typer.Option(
        None, "--api-key",
        help="Override OPENAI_API_KEY / GOOGLE_API_KEY for this run.",
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o",
        help="Write the SurveyAnalysisResult JSON to this path.",
    ),
) -> None:
    """Drive a live Chromium through a survey URL (requires the live extra)."""
    load_dotenv()
    try:
        from surveyshield.live import take_survey as _take_survey
    except ImportError as e:
        typer.secho(
            "The live runtime requires the [live] extra. Install with:\n"
            "    pip install 'surveyshield-py[live]'\n"
            "    playwright install chromium",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(code=2) from e

    result = asyncio.run(
        _take_survey(
            url,
            model=model,
            api_key=api_key,
            max_steps=max_steps,
            use_vision=not no_vision,
            verbose=verbose,
        )
    )

    if output is not None:
        output.write_text(result.model_dump_json(indent=2), encoding="utf-8")
        typer.echo(f"JSON → {output}")
    else:
        typer.echo(result.model_dump_json(indent=2))


@app.command()
def serve(
    host: str = typer.Option("127.0.0.1", "--host"),
    port: int = typer.Option(8000, "--port"),
    reload: bool = typer.Option(False, "--reload", help="Enable auto-reload (dev)."),
) -> None:
    """Boot the FastAPI app + bundled React SPA."""
    load_dotenv()
    try:
        import uvicorn
    except ImportError as e:
        typer.secho(
            "uvicorn is required to run `surveyshield serve`.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(code=2) from e

    typer.echo(f"Survey Shield → http://{host}:{port}")
    uvicorn.run(
        "surveyshield.serve.app:app", host=host, port=port, reload=reload
    )


if __name__ == "__main__":  # pragma: no cover
    app()
