"""Tests for udsxml2tex."""

from pathlib import Path

import pytest

from udsxml2tex import ArxmlParser, CanTpParser, TexGenerator

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLE_CANTP = FIXTURES_DIR / "sample_cantp.arxml"


class TestArxmlParser:
    """Tests for the ARXML parser."""

    def test_parse_file_not_found(self):
        parser = ArxmlParser()
        with pytest.raises(FileNotFoundError):
            parser.parse("/nonexistent/file.arxml")

    def test_parse_sample(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec is not None
        assert len(spec.sessions) > 0
        assert len(spec.security_levels) > 0
        assert len(spec.services) > 0
        assert len(spec.dids) > 0
        assert len(spec.routines) > 0

    def test_sessions_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        session_names = [s.short_name for s in spec.sessions]
        assert "DefaultSession" in session_names
        assert "ProgrammingSession" in session_names
        assert "ExtendedSession" in session_names

        default = next(s for s in spec.sessions if s.short_name == "DefaultSession")
        assert default.session_id == 1
        assert default.session_id_hex == "0x01"

    def test_s3_server_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.s3_server == 5.0

    def test_security_levels_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.security_levels) == 2
        level_names = [s.short_name for s in spec.security_levels]
        assert "SecurityLevel_1" in level_names
        assert "SecurityLevel_2" in level_names

        sec1 = next(
            s for s in spec.security_levels if s.short_name == "SecurityLevel_1"
        )
        assert sec1.security_level == 1
        assert sec1.num_max_attempts == 3

    def test_services_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        service_ids = [s.service_id for s in spec.services]
        assert 0x10 in service_ids  # DiagnosticSessionControl
        assert 0x11 in service_ids  # ECUReset
        assert 0x14 in service_ids  # ClearDiagnosticInformation
        assert 0x19 in service_ids  # ReadDTCInformation
        assert 0x22 in service_ids  # ReadDataByIdentifier
        assert 0x27 in service_ids  # SecurityAccess
        assert 0x28 in service_ids  # CommunicationControl
        assert 0x29 in service_ids  # Authentication
        assert 0x2E in service_ids  # WriteDataByIdentifier
        assert 0x31 in service_ids  # RoutineControl
        assert 0x34 in service_ids  # RequestDownload
        assert 0x36 in service_ids  # TransferData
        assert 0x37 in service_ids  # RequestTransferExit
        assert 0x3E in service_ids  # TesterPresent
        assert 0x85 in service_ids  # ControlDTCSetting

    def test_service_names_mapped(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        session_ctrl = next(s for s in spec.services if s.service_id == 0x10)
        assert session_ctrl.short_name == "DiagnosticSessionControl"
        assert session_ctrl.positive_response_id == 0x50
        assert session_ctrl.positive_response_id_hex == "0x50"

    def test_service_sessions(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        tester_present = next(s for s in spec.services if s.service_id == 0x3E)
        assert "DefaultSession" in tester_present.supported_sessions
        assert "ExtendedSession" in tester_present.supported_sessions

    def test_dids_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.dids) == 3

        vin_did = next(d for d in spec.dids if d.did_id == 0xF190)
        assert vin_did.short_name == "DID_F190_VIN"
        assert vin_did.did_id_hex == "0xF190"
        assert vin_did.read_access is True
        assert "DefaultSession" in vin_did.supported_sessions

        # Check data elements
        assert len(vin_did.data_elements) > 0

    def test_did_write_access(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        app_ver = next(d for d in spec.dids if d.did_id == 0xF101)
        assert app_ver.read_access is True
        assert app_ver.write_access is True

    def test_routines_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.routines) == 4
        # Verify the first routine (EraseMemory)
        routine = next(r for r in spec.routines if r.routine_id == 0x0203)
        assert routine.routine_id_hex == "0x0203"
        assert routine.start_supported is True
        assert routine.result_supported is True
        assert "ExtendedSession" in routine.supported_sessions
        assert "SecurityLevel_1" in routine.required_security_levels

        # Verify no duplicate sessions/security from overlapping XPath
        assert routine.supported_sessions == ["ExtendedSession"]
        assert routine.required_security_levels == ["SecurityLevel_1"]

        # Verify other routines exist
        rids = sorted(r.routine_id for r in spec.routines)
        assert rids == [0x0203, 0x0302, 0xF000, 0xFF00]

        # SelfTest has start+stop+result
        self_test = next(r for r in spec.routines if r.routine_id == 0xF000)
        assert self_test.start_supported is True
        assert self_test.stop_supported is True
        assert self_test.result_supported is True

        # CheckProgrammingPreconditions has no security
        precond = next(r for r in spec.routines if r.routine_id == 0x0302)
        assert precond.required_security_levels == []

    def test_nrc_list(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        security_svc = next(s for s in spec.services if s.service_id == 0x27)
        nrc_codes = [n.nrc_code for n in security_svc.nrc_list]
        # SecurityAccess should have specific NRCs
        assert 0x33 in nrc_codes  # securityAccessDenied
        assert 0x35 in nrc_codes  # invalidKey
        assert 0x36 in nrc_codes  # exceededNumberOfAttempts

    def test_sub_functions_parsed_from_arxml(self):
        """Sub-functions defined as DcmDsdSubService in ARXML are parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        # DiagnosticSessionControl has 3 explicit sub-functions in fixture
        dsc = next(s for s in spec.services if s.service_id == 0x10)
        assert len(dsc.sub_functions) == 3
        sf_ids = [sf.sub_function_id for sf in dsc.sub_functions]
        assert sf_ids == [0x01, 0x02, 0x03]
        assert dsc.sub_functions[0].short_name == "defaultSession"
        # Check session refs parsed for sub-function
        assert "DefaultSession" in dsc.sub_functions[0].supported_sessions

    def test_sub_functions_parsed_from_arxml_ecureset(self):
        """ECUReset has 2 explicit sub-functions (hardReset, softReset)."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        ecureset = next(s for s in spec.services if s.service_id == 0x11)
        assert len(ecureset.sub_functions) == 2
        sf_names = [sf.short_name for sf in ecureset.sub_functions]
        assert "hardReset" in sf_names
        assert "softReset" in sf_names

    def test_sub_functions_standard_fallback(self):
        """Services with SubfuncAvail=true but no ARXML sub-services
        get ISO 14229-1 standard sub-functions."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        # TesterPresent has SubfuncAvail=true but no DcmDsdSubService
        tp = next(s for s in spec.services if s.service_id == 0x3E)
        assert len(tp.sub_functions) >= 1
        assert tp.sub_functions[0].short_name == "zeroSubFunction"
        assert tp.sub_functions[0].sub_function_id == 0x00

    def test_sub_functions_none_when_not_available(self):
        """Services with SubfuncAvail=false have no sub-functions."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        # RequestDownload has SubfuncAvail=false
        rd = next(s for s in spec.services if s.service_id == 0x34)
        assert len(rd.sub_functions) == 0

    def test_communication_control_parsed(self):
        """SID 0x28 CommunicationControl is parsed with sub-functions."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        cc = next(s for s in spec.services if s.service_id == 0x28)
        assert cc.short_name == "CommunicationControl"
        assert cc.positive_response_id == 0x68
        assert cc.positive_response_id_hex == "0x68"
        assert "ExtendedSession" in cc.supported_sessions
        # 4 sub-functions defined in ARXML
        assert len(cc.sub_functions) == 4
        sf_ids = [sf.sub_function_id for sf in cc.sub_functions]
        assert sf_ids == [0x00, 0x01, 0x02, 0x03]
        assert cc.sub_functions[0].short_name == "enableRxAndTx"
        assert cc.sub_functions[3].short_name == "disableRxAndTx"

    def test_control_dtc_setting_parsed(self):
        """SID 0x85 ControlDTCSetting is parsed with sub-functions."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dtc = next(s for s in spec.services if s.service_id == 0x85)
        assert dtc.short_name == "ControlDTCSetting"
        assert dtc.positive_response_id == 0xC5
        assert dtc.positive_response_id_hex == "0xC5"
        assert "ExtendedSession" in dtc.supported_sessions
        # 2 sub-functions defined in ARXML
        assert len(dtc.sub_functions) == 2
        sf_ids = [sf.sub_function_id for sf in dtc.sub_functions]
        assert sf_ids == [0x01, 0x02]
        assert dtc.sub_functions[0].short_name == "on"
        assert dtc.sub_functions[1].short_name == "off"

    def test_communication_control_nrcs(self):
        """SID 0x28 should have requestOutOfRange NRC."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        cc = next(s for s in spec.services if s.service_id == 0x28)
        nrc_codes = [n.nrc_code for n in cc.nrc_list]
        assert 0x12 in nrc_codes  # subFunctionNotSupported
        assert 0x31 in nrc_codes  # requestOutOfRange
        assert 0x22 in nrc_codes  # conditionsNotCorrect

    def test_control_dtc_setting_nrcs(self):
        """SID 0x85 should have requestOutOfRange NRC."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dtc = next(s for s in spec.services if s.service_id == 0x85)
        nrc_codes = [n.nrc_code for n in dtc.nrc_list]
        assert 0x12 in nrc_codes  # subFunctionNotSupported
        assert 0x31 in nrc_codes  # requestOutOfRange
        assert 0x22 in nrc_codes  # conditionsNotCorrect

    def test_did_description_parsed(self):
        """DID descriptions should be extracted from DESC/L-2."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        vin = next(d for d in spec.dids if d.did_id == 0xF190)
        assert vin.description == "Vehicle Identification Number"

    def test_did_data_element_data_type(self):
        """DataElement data_type should be parsed from DcmDspDidDataType."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        vin = next(d for d in spec.dids if d.did_id == 0xF190)
        assert len(vin.data_elements) > 0
        assert vin.data_elements[0].data_type == "uint8_n"

    def test_security_extended_fields(self):
        """Security levels should parse delay, key_size, seed_size."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        sec1 = next(s for s in spec.security_levels if s.security_level == 1)
        assert sec1.attempt_delay == 10.0
        assert sec1.key_size == 4
        assert sec1.seed_size == 4

    def test_protocol_type_parsed(self):
        """DcmDslProtocolType should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.protocol_type == "UDS_ON_CAN"

    def test_dsl_buffer_sizes(self):
        """DSL buffer sizes should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.dsl_rx_buffer_size == 4095
        assert spec.dsl_tx_buffer_size == 4095

    def test_routine_description_parsed(self):
        """Routine descriptions should be extracted from DESC/L-2."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        erase = next(r for r in spec.routines if r.routine_id == 0x0203)
        assert erase.description == "Erases a memory block"

    def test_routine_parameters_parsed(self):
        """Routine in/out parameters from DcmDspRoutineInSignal/OutSignal."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        erase = next(r for r in spec.routines if r.routine_id == 0x0203)
        assert len(erase.in_parameters) == 2
        assert erase.in_parameters[0].short_name == "DcmDspRoutineInSignal_Address"
        assert erase.in_parameters[0].bit_size == 32
        assert erase.in_parameters[0].data_type == "uint32"
        assert erase.in_parameters[1].byte_position == 4

        assert len(erase.out_parameters) == 1
        assert erase.out_parameters[0].short_name == "DcmDspRoutineOutSignal_Status"
        assert erase.out_parameters[0].bit_size == 8

    def test_dtcs_parsed(self):
        """DTC definitions should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.dtcs) == 2
        bus_off = next(d for d in spec.dtcs if d.short_name == "DTC_BusOff")
        assert bus_off.dtc_id == 0xC07300
        assert bus_off.severity == "HIGH"
        assert bus_off.functional_unit == "Communication"
        assert bus_off.description == "CAN bus off detected"

    def test_memory_ranges_parsed(self):
        """Memory ranges should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.memory_ranges) == 1
        mr = spec.memory_ranges[0]
        assert mr.short_name == "ReadRange_Calibration"
        assert mr.start_address == 0x80000000
        assert mr.end_address == 0x8000FFFF
        assert mr.read_access is True
        assert "ExtendedSession" in mr.supported_sessions

    def test_periodic_dids_parsed(self):
        """Periodic DIDs should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.periodic_dids) == 1
        pdid = spec.periodic_dids[0]
        assert pdid.short_name == "PeriodicDID_F200"
        assert pdid.did_id == 0xF200
        assert pdid.transmission_mode == "slowRate"
        assert "ExtendedSession" in pdid.supported_sessions

    def test_io_control_dids_parsed(self):
        """IO control DIDs should be parsed from DcmDspDidControl."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.io_control_dids) == 1
        io = spec.io_control_dids[0]
        assert io.short_name == "DID_D001_OutputControl"
        assert io.did_id == 0xD001
        assert io.control_mask_size == 8
        assert io.return_control_to_ecu is True
        assert io.short_term_adjustment is True

    def test_dtc_extended_data_records(self):
        """DTC extended data records should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        busoff = [d for d in spec.dtcs if d.short_name == "DTC_BusOff"][0]
        assert len(busoff.extended_data_records) == 1
        edr = busoff.extended_data_records[0]
        assert edr.record_number == 1
        assert edr.data_size == 4
        assert edr.short_name == "ExtendedDataRecord_01"

    def test_dtc_snapshot_records(self):
        """DTC snapshot records should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        busoff = [d for d in spec.dtcs if d.short_name == "DTC_BusOff"][0]
        assert len(busoff.snapshot_records) == 1
        snap = busoff.snapshot_records[0]
        assert snap.record_number == 1
        assert snap.short_name == "SnapshotRecord_01"
        assert 0xF190 in snap.dids

    def test_did_ranges_parsed(self):
        """DID ranges should be parsed from DcmDspDidRange."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.did_ranges) == 1
        dr = spec.did_ranges[0]
        assert dr.short_name == "DidRange_Supplier"
        assert dr.lower_did == 0xFD00
        assert dr.upper_did == 0xFDFF
        assert dr.read_access is True
        assert "ExtendedSession" in dr.supported_sessions

    def test_service_nrcs_from_arxml(self):
        """Service NRCs should be read from ARXML when defined."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        svc_22 = [s for s in spec.services if s.service_id == 0x22][0]
        nrc_codes = [n.nrc_code for n in svc_22.nrc_list]
        assert 0x13 in nrc_codes
        assert 0x31 in nrc_codes
        assert 0x33 in nrc_codes
        # Should only contain the 3 NRCs from ARXML, not defaults
        assert len(svc_22.nrc_list) == 3


class TestTexGenerator:
    """Tests for the LaTeX generator."""

    def test_generate_string(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert r"\documentclass" in tex
        assert r"\begin{document}" in tex
        assert r"\end{document}" in tex
        assert "UDS Specification" in tex

    def test_generate_contains_sessions(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "DefaultSession" in tex
        assert "ProgrammingSession" in tex
        assert "ExtendedSession" in tex

    def test_generate_contains_services(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "{10}" in tex
        assert "DiagnosticSessionControl" in tex
        assert "{22}" in tex
        assert "ReadDataByIdentifier" in tex

    def test_generate_contains_dids(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "{F190}" in tex
        assert "DID\\_F190\\_VIN" in tex  # LaTeX escaped underscores

    def test_generate_file(self, tmp_path):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        output = tmp_path / "test_output.tex"
        result = gen.generate(spec, output)

        assert result == output
        assert output.exists()
        content = output.read_text()
        assert r"\documentclass" in content

    def test_ecu_name_override(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        spec.ecu_name = "TestECU"

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "TestECU" in tex

    def test_latex_escape(self):
        from udsxml2tex.generator import _latex_escape

        assert _latex_escape("a&b") == r"a\&b"
        assert _latex_escape("100%") == r"100\%"
        assert _latex_escape("a_b") == r"a\_b"
        assert _latex_escape("a#b") == r"a\#b"
        assert _latex_escape("") == ""

    def test_generate_contains_sub_functions(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        # Sub-function IDs should appear in the Service Overview table
        assert "Sub-Function" in tex  # column header
        assert r"\hexval{01}" in tex  # sub-function 0x01
        assert r"\hexval{03}" in tex  # sub-function 0x03
        # Services without sub-functions should show ---
        assert "---" in tex

    def test_generate_contains_message_formats(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        # Request / positive response format sections should be present
        assert "Request Message Format" in tex
        assert "Positive Response Message Format" in tex
        # SID bytes should appear in format tables (e.g. SID 0x10 -> \hexval{10})
        assert r"\hexval{10}" in tex  # DiagnosticSessionControl request SID
        assert r"\hexval{50}" in tex  # DiagnosticSessionControl response SID
        assert r"\hexval{22}" in tex  # ReadDataByIdentifier request SID
        assert r"\hexval{62}" in tex  # ReadDataByIdentifier response SID

    def test_generate_contains_communication_control(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "CommunicationControl" in tex
        assert r"\hexval{28}" in tex or "{28}" in tex
        assert "Request Message Format" in tex  # message format table for 0x28

    def test_generate_contains_control_dtc_setting(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "ControlDTCSetting" in tex
        assert r"\hexval{85}" in tex or "{85}" in tex
        assert r"\hexval{C5}" in tex  # positive response SID

    def test_generate_contains_supported_nrc_heading(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Supported Negative Response Codes" in tex

    def test_tex_contains_dsl_config(self):
        """Template should render DSL configuration section."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "UDS\\_ON\\_CAN" in tex or "UDS_ON_CAN" in tex
        assert "4095" in tex

    def test_tex_contains_dtc_section(self):
        """Template should render DTC table."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Diagnostic Trouble Codes" in tex
        assert "DTC\\_BusOff" in tex or "DTC_BusOff" in tex

    def test_tex_contains_memory_ranges(self):
        """Template should render memory ranges table."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Memory Access Ranges" in tex

    def test_tex_contains_periodic_dids(self):
        """Template should render periodic DIDs table."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Periodic DIDs" in tex
        assert "slowRate" in tex

    def test_tex_contains_io_control_dids(self):
        """Template should render IO control DIDs table."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "IO Control DIDs" in tex

    def test_tex_contains_security_extended_fields(self):
        """Template should render extended security fields."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Seed Size" in tex
        assert "Key Size" in tex
        assert "Delay" in tex

    def test_tex_contains_routine_description(self):
        """Template should render routine description."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Erases a memory block" in tex

    def test_tex_contains_did_description(self):
        """Template should render DID description."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Vehicle Identification Number" in tex

    def test_tex_contains_dtc_extended_data(self):
        """Template should render DTC extended data records."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Extended Data Records" in tex
        assert "ExtendedDataRecord" in tex

    def test_tex_contains_dtc_snapshot(self):
        """Template should render DTC snapshot records."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Snapshot Records" in tex
        assert "SnapshotRecord" in tex

    def test_tex_contains_did_ranges(self):
        """Template should render DID Ranges section."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "DID Ranges" in tex
        assert "DidRange" in tex


class TestCli:
    """Tests for the CLI interface."""

    def test_cli_help(self):
        from udsxml2tex.cli import _build_parser

        parser = _build_parser()
        assert parser.prog == "udsxml2tex"

    def test_cli_main_success(self, tmp_path):
        from udsxml2tex.cli import main

        output = tmp_path / "output.tex"
        rc = main([str(SAMPLE_ARXML), "-o", str(output)])
        assert rc == 0
        assert output.exists()

    def test_cli_main_file_not_found(self):
        from udsxml2tex.cli import main

        rc = main(["/nonexistent/file.arxml"])
        assert rc == 1

    def test_cli_ecu_name(self, tmp_path):
        from udsxml2tex.cli import main

        output = tmp_path / "output.tex"
        rc = main([str(SAMPLE_ARXML), "-o", str(output), "--ecu-name", "MyECU"])
        assert rc == 0

        content = output.read_text()
        assert "MyECU" in content


class TestCanTpParser:
    """Tests for the CanTp ARXML parser."""

    def test_parse_file_not_found(self):
        parser = CanTpParser()
        with pytest.raises(FileNotFoundError):
            parser.parse("/nonexistent/file.arxml")

    def test_parse_sample(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        assert config is not None
        assert len(config.channels) > 0

    def test_main_function_period(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        assert config.main_function_period == 0.01

    def test_channel_count(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        # Physical channel (1 Rx+Tx pair) + Functional channel (1 Rx only)
        assert len(config.channels) == 2

    def test_physical_channel(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        # Find the physical channel (has CanTpRxNSdu_Phys in name)
        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.bs == 8
        assert phys.stmin == 10.0
        assert phys.n_ar == 1.0
        assert phys.n_br == 0.9
        assert phys.n_cr == 1.0
        assert phys.padding_byte == 0xAA
        assert phys.padding_activation is True
        assert phys.rx_addressing_format == "STANDARD"
        assert phys.max_data_length == 8
        assert phys.channel_mode == "FULL_DUPLEX"

    def test_physical_channel_tx(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.n_as == 1.0
        assert phys.n_bs == 1.0
        assert phys.n_cs == 0.5
        assert phys.tx_addressing_format == "STANDARD"
        assert phys.tx_pdu_id == "DiagPhysTxPdu"

    def test_functional_channel(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        func = next(
            (ch for ch in config.channels if "Func" in ch.short_name), None
        )
        assert func is not None
        assert func.bs == 0
        assert func.stmin == 0.0
        assert func.rx_addressing_format == "EXTENDED"
        assert func.max_data_length == 64
        assert func.channel_mode == "HALF_DUPLEX"
        assert func.padding_byte == 0xFF

    def test_rx_pdu_ref(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.rx_pdu_id == "DiagPhysRxPdu"

    def test_padding_byte_hex(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.padding_byte_hex == "0xAA"

    def test_rx_ta_type(self):
        """TA type should be parsed from CanTpRxTaType."""
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.rx_ta_type == "PHYSICAL"

    def test_tx_ta_type(self):
        """Tx TA type should be parsed from CanTpTxTaType."""
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.tx_ta_type == "PHYSICAL"

    def test_functional_ta_type(self):
        """Functional channel TA type."""
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        func = next(
            (ch for ch in config.channels if "Func" in ch.short_name), None
        )
        assert func is not None
        assert func.rx_ta_type == "FUNCTIONAL"


class TestCanTpIntegration:
    """Integration tests for CanTp with ArxmlParser and TexGenerator."""

    def test_arxml_parser_detects_cantp(self):
        """ArxmlParser should detect CanTp in a CanTp-only file."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_CANTP)

        assert spec.transport_config is not None
        assert len(spec.transport_config.channels) == 2

    def test_parse_multi_dcm_and_cantp(self):
        """parse_multi should merge DCM and CanTp from separate files."""
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])

        # DCM data present
        assert len(spec.sessions) > 0
        assert len(spec.services) > 0
        assert len(spec.dids) > 0

        # CanTp data merged
        assert spec.transport_config is not None
        assert len(spec.transport_config.channels) == 2

    def test_tex_with_cantp(self):
        """Generator should include transport layer section."""
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Transport Layer" in tex
        assert "FULL\\_DUPLEX" in tex or "FULL_DUPLEX" in tex
        assert "{AA}" in tex

    def test_tex_without_cantp(self):
        """Generator without CanTp should show 'No CAN Transport' message."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        # DCM-only file should have no transport config
        assert spec.transport_config is None

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "No CAN Transport Protocol configuration found" in tex

    def test_generate_file_with_cantp(self, tmp_path):
        """Full pipeline: DCM + CanTp -> .tex file."""
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        spec.ecu_name = "TestECU"

        gen = TexGenerator()
        output = tmp_path / "cantp_test.tex"
        result = gen.generate(spec, output)

        assert result == output
        assert output.exists()
        content = output.read_text()
        assert "Transport Layer" in content
        assert "TestECU" in content

    def test_cli_multi_file(self, tmp_path):
        """CLI should handle DCM + CanTp files."""
        from udsxml2tex.cli import main

        output = tmp_path / "multi.tex"
        rc = main([str(SAMPLE_ARXML), str(SAMPLE_CANTP), "-o", str(output)])
        assert rc == 0
        assert output.exists()
        content = output.read_text()
        assert "Transport Layer" in content
