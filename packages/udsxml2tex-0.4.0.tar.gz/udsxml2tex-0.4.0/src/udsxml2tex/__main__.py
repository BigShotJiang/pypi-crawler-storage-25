"""Allow running udsxml2tex as ``python -m udsxml2tex``."""

import sys

from udsxml2tex.cli import main

sys.exit(main())
