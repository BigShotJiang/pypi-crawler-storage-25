"""Basic tests for us-water-quality-data package."""

import us_water_quality_data as water


def test_lookup_existing_zip():
    """lookup() returns a dict for a known ZIP code."""
    record = water.lookup("10001")
    assert record is not None
    assert record["zip"] == "10001"
    assert record["state"] == "NY"
    assert "city" in record
    assert "home_safety_score" in record


def test_lookup_zero_padded():
    """lookup() zero-pads short ZIP codes."""
    # ZIP 06001 is in Connecticut if it exists; test padding logic
    result_padded = water.lookup("06001")
    result_int = water.lookup("6001")
    assert result_padded == result_int


def test_lookup_missing_zip():
    """lookup() returns None for a non-existent ZIP."""
    assert water.lookup("00000") is None


def test_get_state():
    """get_state() returns records for a valid state."""
    ny_records = water.get_state("NY")
    assert isinstance(ny_records, list)
    assert len(ny_records) > 0
    assert all(r["state"] == "NY" for r in ny_records)


def test_get_state_case_insensitive():
    """get_state() handles lowercase input."""
    result = water.get_state("ny")
    assert isinstance(result, list)
    assert all(r["state"] == "NY" for r in result)


def test_get_state_empty():
    """get_state() returns empty list for invalid state."""
    assert water.get_state("ZZ") == []


def test_get_worst():
    """get_worst() returns records sorted by score ascending."""
    worst = water.get_worst(5)
    assert len(worst) <= 5
    assert len(worst) > 0
    scores = [r["home_safety_score"] for r in worst]
    assert scores == sorted(scores)


def test_get_best():
    """get_best() returns records sorted by score descending."""
    best = water.get_best(5)
    assert len(best) <= 5
    assert len(best) > 0
    scores = [r["home_safety_score"] for r in best]
    assert scores == sorted(scores, reverse=True)


def test_states():
    """states() returns a sorted list of state abbreviations."""
    state_list = water.states()
    assert isinstance(state_list, list)
    assert len(state_list) > 0
    assert state_list == sorted(state_list)
    assert all(len(s) == 2 for s in state_list)


def test_count():
    """count() returns a positive integer."""
    c = water.count()
    assert isinstance(c, int)
    assert c > 0


def test_zips():
    """zips() returns a list of ZIP code strings."""
    z = water.zips()
    assert isinstance(z, list)
    assert len(z) == water.count()
    assert all(isinstance(code, str) for code in z)


def test_search_city():
    """search_city() finds records by partial city name."""
    results = water.search_city("new york")
    assert isinstance(results, list)
    assert len(results) > 0
    assert all("new york" in r["city"].lower() for r in results)


def test_search_city_empty():
    """search_city() returns empty list for nonsense input."""
    assert water.search_city("xyznonexistent") == []


def test_meta():
    """meta exposes dataset metadata."""
    assert water.meta["name"] is not None
    assert water.meta["license"] == "CC-BY-4.0"
    assert "total_zips" in water.meta.keys()
    assert "fields" in water.meta.keys()


def test_record_fields():
    """Records contain all expected fields."""
    record = water.lookup("10001")
    assert record is not None
    expected_fields = {
        "zip", "city", "state", "system_name", "pwsid", "population",
        "water_source", "total_violations", "health_violations",
        "unresolved_violations", "lead_level_mg_l", "copper_level_mg_l",
        "radon_zone", "home_safety_score", "home_safety_grade",
        "latitude", "longitude", "contaminant_count", "health_contaminant_names",
    }
    assert expected_fields.issubset(record.keys())
