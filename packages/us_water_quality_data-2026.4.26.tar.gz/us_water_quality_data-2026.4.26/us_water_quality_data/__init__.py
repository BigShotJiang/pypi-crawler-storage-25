"""
us-water-quality-data — U.S. water quality data by ZIP code.

Includes violation history, lead/copper levels, radon zone classification,
and Home Safety Scores for thousands of ZIP codes, sourced from the
EPA Safe Drinking Water Information System (SDWIS).

Usage:
    >>> import us_water_quality_data as water
    >>> record = water.lookup("10001")
    >>> record["city"]
    'New York'
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

__all__ = [
    "lookup",
    "get_state",
    "get_worst",
    "get_best",
    "states",
    "count",
    "zips",
    "search_city",
    "meta",
]

_DATA_DIR = Path(__file__).parent / "data"

# Lazy-loaded module-level cache
_data: dict[str, dict[str, Any]] | None = None
_meta: dict[str, Any] | None = None


def _load_data() -> dict[str, dict[str, Any]]:
    """Load and cache the water quality dataset."""
    global _data
    if _data is None:
        data_path = _DATA_DIR / "water-quality.json"
        if not data_path.exists():
            raise FileNotFoundError(
                f"Dataset not found at {data_path}. "
                "Run `python -m scripts.build_pypi_package` to copy data files."
            )
        with open(data_path, encoding="utf-8") as f:
            _data = json.load(f)
    return _data


def _load_meta() -> dict[str, Any]:
    """Load and cache dataset metadata."""
    global _meta
    if _meta is None:
        meta_path = _DATA_DIR / "metadata.json"
        if not meta_path.exists():
            raise FileNotFoundError(
                f"Metadata not found at {meta_path}. "
                "Run `python -m scripts.build_pypi_package` to copy data files."
            )
        with open(meta_path, encoding="utf-8") as f:
            _meta = json.load(f)
    return _meta


def lookup(zip_code: str) -> dict[str, Any] | None:
    """
    Lookup water quality data for a specific ZIP code.

    Args:
        zip_code: 5-digit ZIP code (will be zero-padded if needed).

    Returns:
        Water quality record as a dict, or None if not found.
    """
    key = str(zip_code).zfill(5)
    return _load_data().get(key)


def get_state(state: str) -> list[dict[str, Any]]:
    """
    Get all ZIP records for a given state.

    Args:
        state: 2-letter state abbreviation (e.g. "CA", "NY").

    Returns:
        List of water quality records for that state.
    """
    abbr = str(state).upper()
    return [r for r in _load_data().values() if r.get("state") == abbr]


def get_worst(n: int = 10) -> list[dict[str, Any]]:
    """
    Get the ZIP codes with the worst (lowest) Home Safety Scores.

    Args:
        n: Number of results to return (default: 10).

    Returns:
        List sorted by score ascending (worst first).
    """
    scored = [r for r in _load_data().values() if r.get("home_safety_score") is not None]
    scored.sort(key=lambda r: r["home_safety_score"])
    return scored[:n]


def get_best(n: int = 10) -> list[dict[str, Any]]:
    """
    Get the ZIP codes with the best (highest) Home Safety Scores.

    Args:
        n: Number of results to return (default: 10).

    Returns:
        List sorted by score descending (best first).
    """
    scored = [r for r in _load_data().values() if r.get("home_safety_score") is not None]
    scored.sort(key=lambda r: r["home_safety_score"], reverse=True)
    return scored[:n]


def states() -> list[str]:
    """
    Get all unique states in the dataset.

    Returns:
        Sorted list of 2-letter state abbreviations.
    """
    state_set: set[str] = set()
    for rec in _load_data().values():
        st = rec.get("state")
        if st:
            state_set.add(st)
    return sorted(state_set)


def count() -> int:
    """
    Get the total number of ZIP codes in the dataset.

    Returns:
        Number of ZIP code entries.
    """
    return len(_load_data())


def zips() -> list[str]:
    """
    Get all ZIP codes in the dataset.

    Returns:
        List of 5-digit ZIP code strings.
    """
    return list(_load_data().keys())


def search_city(city: str) -> list[dict[str, Any]]:
    """
    Search ZIP codes by city name (case-insensitive partial match).

    Args:
        city: City name or partial name to search for.

    Returns:
        List of matching water quality records.
    """
    needle = str(city).lower()
    return [
        r for r in _load_data().values()
        if r.get("city") and needle in r["city"].lower()
    ]


@property
def _meta_property() -> dict[str, Any]:
    return _load_meta()


# Expose metadata as a module-level variable (lazy-loaded on first access)
class _MetaAccessor:
    """Lazy accessor for dataset metadata."""

    def __getattr__(self, name: str) -> Any:
        return getattr(_load_meta(), name) if hasattr(dict, name) else _load_meta()[name]

    def __getitem__(self, key: str) -> Any:
        return _load_meta()[key]

    def __repr__(self) -> str:
        return repr(_load_meta())

    def __str__(self) -> str:
        return str(_load_meta())

    def keys(self):  # noqa: ANN201
        return _load_meta().keys()

    def values(self):  # noqa: ANN201
        return _load_meta().values()

    def items(self):  # noqa: ANN201
        return _load_meta().items()

    def get(self, key: str, default: Any = None) -> Any:
        return _load_meta().get(key, default)


meta = _MetaAccessor()
