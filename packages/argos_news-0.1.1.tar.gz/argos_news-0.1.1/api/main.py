"""
ARGOS — FastAPI Application Entry Point
==========================================
Main application module for the ARGOS REST API.

Responsibilities:
  - Creates the FastAPI app instance with metadata
  - Registers all route modules (/v1/health, /v1/sources, /v1/articles)
  - Mounts static files (favicon, logo)
  - Configures CORS for cross-origin access
  - Sets up the lifespan handler for DB initialization
  - Adds global exception handlers for consistent error responses
  - Serves a custom branded landing page

Run with:
  uvicorn api.main:app --host 0.0.0.0 --port 8000

Or via the launch.py script.

Requirement refs: FR-17, FR-20
"""

import logging
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from api.config import get_settings
from api.database import init_db
from api.routes import articles, health, sources
from api.routes import db_viewer, client_docs

# Configure logging for the API layer.
settings = get_settings()
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL, logging.INFO),
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)

logger = logging.getLogger(__name__)


# ============================================================================
# Lifespan — Startup and Shutdown Events
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan handler.

    Startup:
      - Initializes the database (creates table + indexes if missing)
      - Logs configuration summary

    Shutdown:
      - Logs graceful shutdown message
    """
    # --- Startup ---
    logger.info("ARGOS API starting up...")
    logger.info("Database: %s", settings.DATABASE_PATH)
    logger.info("Public URL: %s", settings.API_BASE_URL)

    # Ensure the database table exists.
    # This is a safety net — the Scrapy storage pipeline also creates it.
    await init_db()

    logger.info("ARGOS API ready — Argus Panoptes is watching.")

    yield  # Application runs here

    # --- Shutdown ---
    logger.info("ARGOS API shutting down gracefully.")


# ============================================================================
# FastAPI Application Instance
# ============================================================================

app = FastAPI(
    title="ARGOS API",
    description=(
        "Automated Realtime Global Observer System — "
        "A news aggregation API providing structured access to articles "
        "from 4 Middle East news networks, enriched with editorial metadata.\n\n"
        "Named after Argus Panoptes — the all-seeing guardian of Greek mythology."
    ),
    version="0.1.1",
    docs_url="/docs",         # Swagger UI at /docs
    redoc_url="/redoc",       # ReDoc at /redoc
    openapi_url="/openapi.json",
    lifespan=lifespan,
)


# ============================================================================
# Static Files — Serve logo.png and favicon.ico
# ============================================================================
# Mount the static/ directory so the custom UI pages can reference
# /static/logo.png and /static/favicon.ico.

STATIC_DIR = Path(__file__).parent.parent / "static"
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
    logger.info("Static files mounted from: %s", STATIC_DIR)


# ============================================================================
# CORS Middleware
# ============================================================================
# Allow all origins for v0.1.0 — the API is designed to be open.
# Tighten this in production if authentication is added.

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],              # Allow all origins
    allow_credentials=True,           # Allow cookies (for future auth)
    allow_methods=["*"],              # Allow all HTTP methods
    allow_headers=["*"],              # Allow all headers
)


# ============================================================================
# Route Registration
# ============================================================================
# All routes are versioned under /v1 for API stability.
# Future breaking changes go under /v2.

app.include_router(
    health.router,
    prefix="/v1",
    tags=["System"],
)

app.include_router(
    sources.router,
    prefix="/v1",
    tags=["Sources"],
)

app.include_router(
    articles.router,
    prefix="/v1",
    tags=["Articles"],
)

# Database viewer — operator tool for inspecting DB contents.
app.include_router(
    db_viewer.router,
    prefix="/v1",
    tags=["Database"],
)

# Client documentation page — detailed Python client usage guide.
app.include_router(
    client_docs.router,
    tags=["Documentation"],
)


# ============================================================================
# Global Exception Handlers
# ============================================================================
# Catch unhandled exceptions and return consistent ErrorResponse format.
# Never let a raw 500 stack trace reach the client.

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """
    Catches any unhandled exception and returns a structured error response.

    This is the safety net — specific exceptions should be caught in routes
    using HTTPException. This handler catches everything else.

    The error is logged at ERROR level with full traceback for debugging.
    The client only sees a safe, generic message — never internal details.
    """
    logger.error(
        "Unhandled exception on %s %s: %s",
        request.method, request.url.path, exc,
        exc_info=True
    )

    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": {
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred. Please try again.",
                "field": None,
            }
        }
    )


@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    """Returns a structured 404 error instead of FastAPI's default."""
    return JSONResponse(
        status_code=404,
        content={
            "success": False,
            "error": {
                "code": "NOT_FOUND",
                "message": f"Resource not found: {request.url.path}",
                "field": None,
            }
        }
    )


@app.exception_handler(422)
async def validation_error_handler(request: Request, exc):
    """
    Returns a structured 422 error for request validation failures.

    FastAPI raises 422 when query parameters or path params fail
    Pydantic validation (e.g., page=-1 when ge=1 is required).
    """
    return JSONResponse(
        status_code=422,
        content={
            "success": False,
            "error": {
                "code": "VALIDATION_ERROR",
                "message": str(exc.detail) if hasattr(exc, "detail") else "Invalid request parameters",
                "field": None,
            }
        }
    )


# ============================================================================
# Root Endpoint — Custom Branded Landing Page
# ============================================================================

@app.get("/", response_class=HTMLResponse, tags=["System"], include_in_schema=False)
async def root():
    """
    Root endpoint — serves the ARGOS landing page.

    A branded HTML page with quick links to all API features.
    """
    return _LANDING_PAGE_HTML


# Landing page HTML — self-contained with embedded CSS
_LANDING_PAGE_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARGOS — Automated Realtime Global Observer System</title>
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0a0a0f;
            --surface: #12121a;
            --surface-alt: #1a1a2e;
            --border: #2a2a3e;
            --text: #e0e0f0;
            --text-muted: #8888aa;
            --accent: #6366f1;
            --accent-2: #818cf8;
            --accent-glow: rgba(99, 102, 241, 0.3);
            --success: #22c55e;
            --radius: 16px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .hero {
            min-height: 70vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 60px 24px;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at 50% 50%, rgba(99, 102, 241, 0.08) 0%, transparent 50%);
            animation: pulse 8s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.1); opacity: 1; }
        }

        .hero-content { position: relative; z-index: 1; }

        .logo-wrap {
            width: 120px;
            height: 120px;
            border-radius: 24px;
            overflow: hidden;
            margin: 0 auto 32px;
            box-shadow: 0 0 60px var(--accent-glow), 0 0 120px rgba(99, 102, 241, 0.1);
            border: 2px solid rgba(99, 102, 241, 0.3);
        }

        .logo-wrap img { width: 100%; height: 100%; object-fit: cover; }

        h1 {
            font-size: 56px;
            font-weight: 800;
            letter-spacing: -1px;
            background: linear-gradient(135deg, var(--accent) 0%, var(--accent-2) 50%, #c4b5fd 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 12px;
        }

        .subtitle {
            font-size: 18px;
            color: var(--text-muted);
            max-width: 600px;
            margin: 0 auto 40px;
            line-height: 1.6;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(34, 197, 94, 0.15);
            border: 1px solid rgba(34, 197, 94, 0.3);
            padding: 8px 20px;
            border-radius: 100px;
            font-size: 13px;
            font-weight: 500;
            color: var(--success);
            margin-bottom: 40px;
        }

        .status-badge .dot {
            width: 8px; height: 8px;
            border-radius: 50%;
            background: var(--success);
            animation: blink 2s ease infinite;
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 16px;
            max-width: 1100px;
            margin: 0 auto;
            padding: 0 24px;
        }

        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 28px;
            text-decoration: none;
            color: var(--text);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .card:hover {
            border-color: var(--accent);
            box-shadow: 0 0 30px var(--accent-glow);
            transform: translateY(-4px);
        }

        .card .icon {
            font-size: 28px;
            width: 48px; height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            background: var(--surface-alt);
        }

        .card h3 { font-size: 16px; font-weight: 600; }
        .card p { font-size: 13px; color: var(--text-muted); line-height: 1.5; }

        .card .badge {
            display: inline-block;
            background: var(--surface-alt);
            padding: 3px 10px;
            border-radius: 4px;
            font-size: 11px;
            color: var(--accent);
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .stats-row {
            display: flex;
            justify-content: center;
            gap: 48px;
            margin: 48px 0;
            flex-wrap: wrap;
        }

        .stat {
            text-align: center;
        }

        .stat .val {
            font-size: 36px;
            font-weight: 700;
            color: var(--accent);
        }

        .stat .lbl {
            font-size: 12px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 4px;
        }

        footer {
            text-align: center;
            padding: 40px;
            color: var(--text-muted);
            font-size: 13px;
            border-top: 1px solid var(--border);
            margin-top: 60px;
        }

        @media (max-width: 600px) {
            h1 { font-size: 36px; }
            .subtitle { font-size: 15px; }
        }
    </style>
</head>
<body>
    <section class="hero">
        <div class="hero-content">
            <div class="logo-wrap">
                <img src="/static/logo.png" alt="ARGOS">
            </div>
            <h1>ARGOS</h1>
            <p class="subtitle">
                Automated Realtime Global Observer System<br>
                News aggregation from 4 Middle East networks with editorial metadata.
                Named after Argus Panoptes — the all-seeing guardian.
            </p>
            <div class="status-badge" id="status-badge">
                <span class="dot"></span>
                <span id="status-text">Checking system...</span>
            </div>

            <div class="stats-row" id="stats-row">
                <div class="stat"><div class="val" id="stat-articles">—</div><div class="lbl">Total Articles</div></div>
                <div class="stat"><div class="val">4</div><div class="lbl">News Sources</div></div>
                <div class="stat"><div class="val" id="stat-uptime">—</div><div class="lbl">Uptime</div></div>
                <div class="stat"><div class="val">v0.1.0</div><div class="lbl">API Version</div></div>
            </div>
        </div>
    </section>

    <section class="cards">
        <a class="card" href="/docs">
            <div class="icon">📖</div>
            <h3>API Documentation</h3>
            <p>Interactive Swagger UI — explore all endpoints, try queries live, see response schemas.</p>
            <span class="badge">OPENAPI 3.1</span>
        </a>

        <a class="card" href="/v1/db">
            <div class="icon">🗄️</div>
            <h3>Database Viewer</h3>
            <p>Browse articles, view statistics, search by filters — all in a visual interface.</p>
            <span class="badge">INTERACTIVE</span>
        </a>

        <a class="card" href="/client-docs">
            <div class="icon">🐍</div>
            <h3>Python Client Guide</h3>
            <p>Learn how to use ArgosClient — installation, examples, all methods documented.</p>
            <span class="badge">ZERO-CONFIG</span>
        </a>

        <a class="card" href="/v1/articles/latest?count=10">
            <div class="icon">📰</div>
            <h3>Latest Articles</h3>
            <p>Quick endpoint — get the most recent articles across all sources.</p>
            <span class="badge">JSON</span>
        </a>

        <a class="card" href="/v1/sources">
            <div class="icon">🌐</div>
            <h3>Source Registry</h3>
            <p>All 4 tracked networks with orientation, trust scores, and influence flags.</p>
            <span class="badge">4 SOURCES</span>
        </a>

        <a class="card" href="/v1/health">
            <div class="icon">❤️</div>
            <h3>Health Check</h3>
            <p>System status — DB connectivity, uptime, article count, version info.</p>
            <span class="badge">MONITORING</span>
        </a>

        <a class="card" href="/redoc">
            <div class="icon">📝</div>
            <h3>ReDoc</h3>
            <p>Alternative API documentation with a clean, readable layout.</p>
            <span class="badge">OPENAPI</span>
        </a>

        <a class="card" href="/v1/articles?category=war&sort_by=published_at&order=desc&page_size=5">
            <div class="icon">⚔️</div>
            <h3>War Coverage</h3>
            <p>Quick link — recent war articles from all sources, sorted newest first.</p>
            <span class="badge">FILTER DEMO</span>
        </a>
    </section>

    <footer>
        ARGOS v0.1.0 — Automated Realtime Global Observer System<br>
        Built by Zayani Mouhamed Mouheb / EGen Labs<br>
        <em>Argus Panoptes sees everything.</em>
    </footer>

    <script>
        async function loadStatus() {
            try {
                const resp = await fetch('/v1/health');
                const data = await resp.json();

                document.getElementById('status-text').textContent =
                    data.db_connected ? 'System Online — All Systems Operational' : 'Database Offline';

                document.getElementById('stat-articles').textContent =
                    data.article_count.toLocaleString();

                const hours = Math.floor(data.uptime_seconds / 3600);
                const mins = Math.floor((data.uptime_seconds % 3600) / 60);
                document.getElementById('stat-uptime').textContent =
                    hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;

            } catch (e) {
                document.getElementById('status-text').textContent = 'Unable to reach API';
                document.querySelector('.status-badge').style.borderColor = 'rgba(239, 68, 68, 0.3)';
                document.querySelector('.status-badge').style.background = 'rgba(239, 68, 68, 0.15)';
                document.querySelector('.status-badge').style.color = '#ef4444';
            }
        }
        loadStatus();
    </script>
</body>
</html>"""
