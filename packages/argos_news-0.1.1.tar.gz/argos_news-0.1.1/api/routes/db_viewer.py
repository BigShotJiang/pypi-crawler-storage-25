"""
ARGOS — Database Viewer Route
================================
GET /v1/db — Interactive database viewer page (HTML)
GET /v1/db/stats — Database statistics (JSON)
GET /v1/db/browse — Browse articles with a web UI

Provides a browser-based interface for inspecting the contents
of the ARGOS SQLite database without needing external tools.

Features:
  - Total article counts by source, category, orientation
  - Recent articles table view
  - Search/filter interface
  - Storage statistics (DB size, index info)

This is a convenience tool for operators — not part of the
public API consumed by ArgosClient.

Requirement refs: FR-16
"""

import json
import os

from fastapi import APIRouter, Query
from fastapi.responses import HTMLResponse

from api.config import get_settings
from api.database import get_article_count, get_db

router = APIRouter()


@router.get(
    "/db/stats",
    summary="Database statistics",
    description="Returns aggregate statistics about the database contents.",
)
async def db_stats():
    """
    Returns database statistics:
      - Total article count
      - Count by source
      - Count by category
      - Count by country
      - Database file size
      - Date range of data

    This is useful for monitoring pipeline health:
    Is data flowing? Are all 4 sources producing articles?
    """
    settings = get_settings()

    async with get_db() as db:
        # Total count
        cursor = await db.execute("SELECT COUNT(*) as cnt FROM articles")
        row = await cursor.fetchone()
        total = row["cnt"]

        # By source
        cursor = await db.execute(
            "SELECT source_name, COUNT(*) as cnt FROM articles GROUP BY source_name ORDER BY cnt DESC"
        )
        by_source = [{"source_name": r["source_name"], "count": r["cnt"]} for r in await cursor.fetchall()]

        # By category
        cursor = await db.execute(
            "SELECT category, COUNT(*) as cnt FROM articles GROUP BY category ORDER BY cnt DESC"
        )
        by_category = [{"category": r["category"], "count": r["cnt"]} for r in await cursor.fetchall()]

        # By country
        cursor = await db.execute(
            "SELECT country, COUNT(*) as cnt FROM articles GROUP BY country ORDER BY cnt DESC"
        )
        by_country = [{"country": r["country"], "count": r["cnt"]} for r in await cursor.fetchall()]

        # Date range
        cursor = await db.execute(
            "SELECT MIN(published_at) as oldest, MAX(published_at) as newest FROM articles"
        )
        date_row = await cursor.fetchone()

        # By orientation
        cursor = await db.execute(
            "SELECT orientation, COUNT(*) as cnt FROM articles GROUP BY orientation ORDER BY cnt DESC"
        )
        by_orientation = [{"orientation": r["orientation"], "count": r["cnt"]} for r in await cursor.fetchall()]

    # Database file size
    db_size_bytes = 0
    try:
        db_size_bytes = os.path.getsize(settings.DATABASE_PATH)
    except OSError:
        pass

    return {
        "total_articles": total,
        "db_size_bytes": db_size_bytes,
        "db_size_mb": round(db_size_bytes / (1024 * 1024), 2),
        "date_range": {
            "oldest": date_row["oldest"] if date_row else None,
            "newest": date_row["newest"] if date_row else None,
        },
        "by_source": by_source,
        "by_category": by_category,
        "by_country": by_country,
        "by_orientation": by_orientation,
    }


@router.get(
    "/db",
    response_class=HTMLResponse,
    summary="Database viewer UI",
    description="Interactive web UI for browsing the ARGOS database.",
)
async def db_viewer():
    """
    Serves the interactive database viewer HTML page.

    This is a self-contained HTML page with embedded CSS and JS
    that calls the API endpoints to display database contents.
    No external dependencies required.
    """
    return _DB_VIEWER_HTML


# ============================================================================
# Database Viewer HTML — Self-Contained Single Page Application
# ============================================================================
# This is embedded directly in the Python file to avoid external file
# dependencies. The page calls /v1/db/stats and /v1/articles via fetch()
# to populate its content dynamically.

_DB_VIEWER_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARGOS — Database Viewer</title>
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0a0a0f;
            --surface: #12121a;
            --surface-alt: #1a1a2e;
            --border: #2a2a3e;
            --text: #e0e0f0;
            --text-muted: #8888aa;
            --accent: #6366f1;
            --accent-glow: rgba(99, 102, 241, 0.3);
            --success: #22c55e;
            --warning: #f59e0b;
            --danger: #ef4444;
            --radius: 12px;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
        }

        .header {
            background: linear-gradient(135deg, #12121a 0%, #1e1e3a 50%, #12121a 100%);
            border-bottom: 1px solid var(--border);
            padding: 24px 32px;
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header img { width: 48px; height: 48px; border-radius: 8px; }
        .header h1 { font-size: 24px; font-weight: 700; color: var(--accent); }
        .header .subtitle { color: var(--text-muted); font-size: 14px; }

        .container { max-width: 1400px; margin: 0 auto; padding: 24px 32px; }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            border-color: var(--accent);
            box-shadow: 0 0 20px var(--accent-glow);
            transform: translateY(-2px);
        }

        .stat-card .value {
            font-size: 32px;
            font-weight: 700;
            color: var(--accent);
            margin-bottom: 4px;
        }

        .stat-card .label {
            font-size: 13px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .section { margin-bottom: 32px; }
        .section h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 16px;
            color: var(--text);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section h2::before {
            content: '';
            width: 4px;
            height: 20px;
            background: var(--accent);
            border-radius: 2px;
        }

        .breakdown-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 16px;
        }

        .breakdown-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 20px;
        }

        .breakdown-card h3 {
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
            margin-bottom: 12px;
        }

        .bar-row {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 8px;
        }

        .bar-label { width: 130px; font-size: 13px; flex-shrink: 0; }
        .bar-bg {
            flex: 1;
            height: 24px;
            background: var(--surface-alt);
            border-radius: 4px;
            overflow: hidden;
        }
        .bar-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--accent), #818cf8);
            border-radius: 4px;
            transition: width 0.6s ease;
            display: flex;
            align-items: center;
            padding-left: 8px;
            font-size: 11px;
            font-weight: 600;
            color: white;
            min-width: 30px;
        }

        .articles-table-wrap {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            overflow: hidden;
        }

        .search-bar {
            padding: 16px 20px;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            border-bottom: 1px solid var(--border);
            align-items: center;
        }

        .search-bar input, .search-bar select {
            background: var(--surface-alt);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            padding: 8px 14px;
            font-size: 13px;
            font-family: inherit;
            outline: none;
            transition: border-color 0.2s;
        }

        .search-bar input:focus, .search-bar select:focus {
            border-color: var(--accent);
        }

        .search-bar input { flex: 1; min-width: 200px; }

        .search-bar button {
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 8px;
            padding: 8px 20px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.2s;
        }

        .search-bar button:hover { opacity: 0.8; }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        th {
            background: var(--surface-alt);
            padding: 12px 16px;
            text-align: left;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.5px;
            border-bottom: 1px solid var(--border);
        }

        td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        tr:hover td { background: var(--surface-alt); }

        .badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }

        .badge-politics { background: #312e81; color: #a5b4fc; }
        .badge-economy { background: #064e3b; color: #6ee7b7; }
        .badge-war { background: #7f1d1d; color: #fca5a5; }
        .badge-tech { background: #1e3a5f; color: #93c5fd; }
        .badge-health { background: #365314; color: #a3e635; }
        .badge-sports { background: #713f12; color: #fcd34d; }
        .badge-culture { background: #4a1d96; color: #c4b5fd; }
        .badge-other { background: #292524; color: #a8a29e; }
        .badge-science { background: #134e4a; color: #5eead4; }
        .badge-environment { background: #14532d; color: #86efac; }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            padding: 16px;
        }

        .pagination button {
            background: var(--surface-alt);
            color: var(--text);
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 6px 14px;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .pagination button:hover { border-color: var(--accent); }
        .pagination button:disabled { opacity: 0.3; cursor: not-allowed; }
        .pagination .current { background: var(--accent); border-color: var(--accent); font-weight: 600; }

        .loading { text-align: center; padding: 40px; color: var(--text-muted); }
        .loading .spinner {
            width: 32px; height: 32px;
            border: 3px solid var(--border);
            border-top: 3px solid var(--accent);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto 12px;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        a { color: var(--accent); text-decoration: none; }
        a:hover { text-decoration: underline; }

        .nav-links {
            display: flex;
            gap: 16px;
            margin-left: auto;
        }

        .nav-links a {
            color: var(--text-muted);
            font-size: 13px;
            padding: 6px 12px;
            border-radius: 6px;
            transition: all 0.2s;
        }

        .nav-links a:hover { background: var(--surface-alt); color: var(--text); text-decoration: none; }
    </style>
</head>
<body>
    <div class="header">
        <img src="/static/logo.png" alt="ARGOS">
        <div>
            <h1>ARGOS Database Viewer</h1>
            <div class="subtitle">Automated Realtime Global Observer System</div>
        </div>
        <div class="nav-links">
            <a href="/docs">API Docs</a>
            <a href="/v1/health">Health</a>
            <a href="/v1/sources">Sources</a>
            <a href="/client-docs">Client Docs</a>
        </div>
    </div>

    <div class="container">
        <!-- Stats Cards -->
        <div class="stats-grid" id="stats-grid">
            <div class="loading"><div class="spinner"></div>Loading statistics...</div>
        </div>

        <!-- Breakdowns -->
        <div class="section">
            <h2>Data Breakdown</h2>
            <div class="breakdown-grid" id="breakdowns"></div>
        </div>

        <!-- Articles Table -->
        <div class="section">
            <h2>Browse Articles</h2>
            <div class="articles-table-wrap">
                <div class="search-bar">
                    <input type="text" id="search-title" placeholder="Search by title...">
                    <select id="filter-source">
                        <option value="">All Sources</option>
                        <option value="Al Jazeera">Al Jazeera</option>
                        <option value="Al Arabiya">Al Arabiya</option>
                        <option value="Sky News Arabia">Sky News Arabia</option>
                        <option value="Middle East Eye">Middle East Eye</option>
                    </select>
                    <select id="filter-category">
                        <option value="">All Categories</option>
                        <option value="politics">Politics</option>
                        <option value="economy">Economy</option>
                        <option value="war">War</option>
                        <option value="tech">Tech</option>
                        <option value="health">Health</option>
                        <option value="sports">Sports</option>
                        <option value="culture">Culture</option>
                        <option value="science">Science</option>
                        <option value="environment">Environment</option>
                        <option value="other">Other</option>
                    </select>
                    <button onclick="searchArticles()">Search</button>
                </div>
                <div id="articles-table">
                    <div class="loading"><div class="spinner"></div>Loading articles...</div>
                </div>
                <div class="pagination" id="pagination"></div>
            </div>
        </div>
    </div>

    <script>
        let currentPage = 1;
        const PAGE_SIZE = 20;

        async function loadStats() {
            try {
                const resp = await fetch('/v1/db/stats');
                const data = await resp.json();

                document.getElementById('stats-grid').innerHTML = `
                    <div class="stat-card"><div class="value">${data.total_articles.toLocaleString()}</div><div class="label">Total Articles</div></div>
                    <div class="stat-card"><div class="value">${data.by_source.length}</div><div class="label">Sources Active</div></div>
                    <div class="stat-card"><div class="value">${data.db_size_mb} MB</div><div class="label">Database Size</div></div>
                    <div class="stat-card"><div class="value">${data.by_category.length}</div><div class="label">Categories</div></div>
                    <div class="stat-card"><div class="value">${data.date_range.oldest ? data.date_range.oldest.split('T')[0] : 'N/A'}</div><div class="label">Oldest Article</div></div>
                    <div class="stat-card"><div class="value">${data.date_range.newest ? data.date_range.newest.split('T')[0] : 'N/A'}</div><div class="label">Newest Article</div></div>
                `;

                const total = data.total_articles || 1;
                let breakdownHTML = '';

                // By Source
                if (data.by_source.length) {
                    breakdownHTML += '<div class="breakdown-card"><h3>By Source</h3>';
                    data.by_source.forEach(s => {
                        const pct = Math.round(s.count / total * 100);
                        breakdownHTML += `<div class="bar-row"><span class="bar-label">${s.source_name}</span><div class="bar-bg"><div class="bar-fill" style="width:${Math.max(pct, 3)}%">${s.count.toLocaleString()}</div></div></div>`;
                    });
                    breakdownHTML += '</div>';
                }

                // By Category
                if (data.by_category.length) {
                    breakdownHTML += '<div class="breakdown-card"><h3>By Category</h3>';
                    data.by_category.forEach(c => {
                        const pct = Math.round(c.count / total * 100);
                        breakdownHTML += `<div class="bar-row"><span class="bar-label">${c.category}</span><div class="bar-bg"><div class="bar-fill" style="width:${Math.max(pct, 3)}%">${c.count.toLocaleString()}</div></div></div>`;
                    });
                    breakdownHTML += '</div>';
                }

                // By Country
                if (data.by_country.length) {
                    breakdownHTML += '<div class="breakdown-card"><h3>By Country</h3>';
                    data.by_country.forEach(c => {
                        const pct = Math.round(c.count / total * 100);
                        breakdownHTML += `<div class="bar-row"><span class="bar-label">${c.country}</span><div class="bar-bg"><div class="bar-fill" style="width:${Math.max(pct, 3)}%">${c.count.toLocaleString()}</div></div></div>`;
                    });
                    breakdownHTML += '</div>';
                }

                // By Orientation
                if (data.by_orientation.length) {
                    breakdownHTML += '<div class="breakdown-card"><h3>By Orientation</h3>';
                    data.by_orientation.forEach(o => {
                        const pct = Math.round(o.count / total * 100);
                        breakdownHTML += `<div class="bar-row"><span class="bar-label">${o.orientation}</span><div class="bar-bg"><div class="bar-fill" style="width:${Math.max(pct, 3)}%">${o.count.toLocaleString()}</div></div></div>`;
                    });
                    breakdownHTML += '</div>';
                }

                document.getElementById('breakdowns').innerHTML = breakdownHTML;
            } catch (e) {
                document.getElementById('stats-grid').innerHTML = '<div class="loading">Failed to load statistics</div>';
            }
        }

        async function loadArticles(page = 1) {
            currentPage = page;
            const title = document.getElementById('search-title').value;
            const source = document.getElementById('filter-source').value;
            const category = document.getElementById('filter-category').value;

            let url = `/v1/articles?page=${page}&page_size=${PAGE_SIZE}&sort_by=published_at&order=desc`;
            if (title) url += `&title=${encodeURIComponent(title)}`;
            if (source) url += `&source_name=${encodeURIComponent(source)}`;
            if (category) url += `&category=${encodeURIComponent(category)}`;

            try {
                const resp = await fetch(url);
                const data = await resp.json();

                if (!data.data.length) {
                    document.getElementById('articles-table').innerHTML = '<div class="loading">No articles found</div>';
                    document.getElementById('pagination').innerHTML = '';
                    return;
                }

                let html = '<table><thead><tr><th>ID</th><th>Title</th><th>Source</th><th>Category</th><th>Published</th><th>Trust</th></tr></thead><tbody>';
                data.data.forEach(a => {
                    const cat = a.category || 'other';
                    html += `<tr>
                        <td>${a.id}</td>
                        <td><a href="${a.source_url}" target="_blank">${a.title}</a></td>
                        <td>${a.source_name}</td>
                        <td><span class="badge badge-${cat}">${cat}</span></td>
                        <td>${a.published_at ? a.published_at.split('T')[0] : 'N/A'}</td>
                        <td>${a.trust_score}</td>
                    </tr>`;
                });
                html += '</tbody></table>';
                document.getElementById('articles-table').innerHTML = html;

                // Pagination
                const p = data.pagination;
                let pagHTML = '';
                pagHTML += `<button ${p.has_prev ? `onclick="loadArticles(${p.page-1})"` : 'disabled'}>← Prev</button>`;
                pagHTML += `<button class="current">Page ${p.page} / ${p.total_pages}</button>`;
                pagHTML += `<button ${p.has_next ? `onclick="loadArticles(${p.page+1})"` : 'disabled'}>Next →</button>`;
                document.getElementById('pagination').innerHTML = pagHTML;
            } catch (e) {
                document.getElementById('articles-table').innerHTML = '<div class="loading">Failed to load articles</div>';
            }
        }

        function searchArticles() { loadArticles(1); }

        document.getElementById('search-title').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') searchArticles();
        });

        // Load on page load
        loadStats();
        loadArticles(1);
    </script>
</body>
</html>"""
