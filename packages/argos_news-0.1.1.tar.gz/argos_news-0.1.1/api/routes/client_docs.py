"""
ARGOS — Client Documentation Page
=====================================
GET /client-docs — Detailed Python client usage documentation (HTML)

Serves a beautiful, self-contained HTML page that teaches users
how to install and use the ArgosClient Python library.

This page covers:
  - Installation
  - Quick start
  - All client methods with examples
  - Filter parameters reference
  - Error handling
  - Advanced usage

This is the "zero-to-hero" guide for anyone using the ARGOS client.
"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

router = APIRouter()


@router.get(
    "/client-docs",
    response_class=HTMLResponse,
    summary="Client documentation",
    description="Interactive documentation for the ARGOS Python client library.",
    include_in_schema=False,
)
async def client_docs():
    """Serves the client documentation HTML page."""
    return _CLIENT_DOCS_HTML


_CLIENT_DOCS_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARGOS — Python Client Documentation</title>
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0a0a0f;
            --surface: #12121a;
            --surface-alt: #1a1a2e;
            --border: #2a2a3e;
            --text: #e0e0f0;
            --text-muted: #8888aa;
            --accent: #6366f1;
            --accent-glow: rgba(99, 102, 241, 0.2);
            --success: #22c55e;
            --warning: #f59e0b;
            --code-bg: #0d1117;
            --radius: 12px;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.7;
        }

        .header {
            background: linear-gradient(135deg, #12121a 0%, #1e1e3a 50%, #12121a 100%);
            border-bottom: 1px solid var(--border);
            padding: 24px 32px;
            display: flex;
            align-items: center;
            gap: 16px;
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(20px);
        }

        .header img { width: 40px; height: 40px; border-radius: 8px; }
        .header h1 { font-size: 20px; font-weight: 700; color: var(--accent); }

        .nav-links {
            display: flex;
            gap: 16px;
            margin-left: auto;
        }

        .nav-links a {
            color: var(--text-muted);
            font-size: 13px;
            padding: 6px 12px;
            border-radius: 6px;
            transition: all 0.2s;
            text-decoration: none;
        }

        .nav-links a:hover { background: var(--surface-alt); color: var(--text); }

        .layout {
            display: flex;
            max-width: 1400px;
            margin: 0 auto;
        }

        .sidebar {
            width: 240px;
            position: sticky;
            top: 80px;
            height: calc(100vh - 80px);
            overflow-y: auto;
            padding: 24px 16px;
            border-right: 1px solid var(--border);
            flex-shrink: 0;
        }

        .sidebar a {
            display: block;
            color: var(--text-muted);
            text-decoration: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            margin-bottom: 2px;
            transition: all 0.2s;
        }

        .sidebar a:hover { background: var(--surface-alt); color: var(--text); }
        .sidebar .section-title {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--text-muted);
            padding: 16px 12px 6px;
            font-weight: 600;
        }

        .content {
            flex: 1;
            padding: 32px 48px;
            max-width: 900px;
        }

        h2 {
            font-size: 24px;
            font-weight: 700;
            margin: 48px 0 16px;
            padding-top: 24px;
            border-top: 1px solid var(--border);
            color: var(--text);
        }

        h2:first-of-type { border-top: none; margin-top: 0; }

        h3 {
            font-size: 18px;
            font-weight: 600;
            margin: 32px 0 12px;
            color: var(--accent);
        }

        p { margin-bottom: 16px; color: var(--text); }

        pre {
            background: var(--code-bg);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 20px;
            overflow-x: auto;
            margin: 16px 0;
            font-family: 'JetBrains Mono', monospace;
            font-size: 13px;
            line-height: 1.6;
        }

        code {
            font-family: 'JetBrains Mono', monospace;
            font-size: 13px;
        }

        p code, li code {
            background: var(--surface-alt);
            padding: 2px 6px;
            border-radius: 4px;
            color: #c4b5fd;
        }

        .keyword { color: #c792ea; }
        .string { color: #c3e88d; }
        .comment { color: #546e7a; }
        .function { color: #82aaff; }
        .variable { color: #f78c6c; }
        .builtin { color: #ffcb6b; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 16px 0;
            font-size: 13px;
        }

        th {
            background: var(--surface-alt);
            padding: 10px 14px;
            text-align: left;
            font-weight: 600;
            border-bottom: 1px solid var(--border);
            color: var(--text-muted);
        }

        td {
            padding: 10px 14px;
            border-bottom: 1px solid var(--border);
        }

        .tip {
            background: rgba(99, 102, 241, 0.1);
            border-left: 3px solid var(--accent);
            padding: 16px 20px;
            border-radius: 0 8px 8px 0;
            margin: 16px 0;
        }

        .tip strong { color: var(--accent); }

        .warning {
            background: rgba(245, 158, 11, 0.1);
            border-left: 3px solid var(--warning);
            padding: 16px 20px;
            border-radius: 0 8px 8px 0;
            margin: 16px 0;
        }

        .warning strong { color: var(--warning); }

        ul, ol { margin: 12px 0 16px 24px; }
        li { margin-bottom: 6px; }

        .hero {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.15), rgba(139, 92, 246, 0.1));
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 32px;
            margin-bottom: 32px;
        }

        .hero h2 { border-top: none; margin-top: 0; font-size: 28px; }
        .hero p { font-size: 15px; }

        @media (max-width: 768px) {
            .sidebar { display: none; }
            .content { padding: 24px 16px; }
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="/static/logo.png" alt="ARGOS">
        <h1>Client Documentation</h1>
        <div class="nav-links">
            <a href="/">Home</a>
            <a href="/docs">API Docs</a>
            <a href="/v1/db">DB Viewer</a>
            <a href="/v1/health">Health</a>
        </div>
    </div>

    <div class="layout">
        <nav class="sidebar">
            <div class="section-title">Getting Started</div>
            <a href="#installation">Installation</a>
            <a href="#quickstart">Quick Start</a>
            <a href="#connection">Connection Setup</a>

            <div class="section-title">Methods</div>
            <a href="#get-latest">get_latest()</a>
            <a href="#get-articles">get_articles()</a>
            <a href="#get-article">get_article()</a>
            <a href="#get-sources">get_sources()</a>
            <a href="#health-check">health_check()</a>

            <div class="section-title">Reference</div>
            <a href="#filters">Filter Parameters</a>
            <a href="#pagination">Pagination</a>
            <a href="#errors">Error Handling</a>
            <a href="#advanced">Advanced Usage</a>
            <a href="#examples">Real-World Examples</a>
        </nav>

        <main class="content">
            <div class="hero">
                <h2>ARGOS Python Client</h2>
                <p>A zero-config Python library for accessing news articles from 4 Middle East networks. Query by source, topic, date, orientation — all with named parameters, no raw HTTP.</p>
            </div>

            <h2 id="installation">Installation</h2>
            <p>Install from PyPI:</p>
<pre><span class="comment"># Install from PyPI</span>
pip install argos-news</pre>

            <p>Or install from source:</p>
<pre><span class="comment"># Clone and install</span>
git clone https://github.com/egenlabs/argos.git
cd argos
pip install -e .</pre>

            <h2 id="quickstart">Quick Start</h2>
            <p>Get up and running in 3 lines:</p>
<pre><span class="keyword">from</span> client <span class="keyword">import</span> ArgosClient

<span class="comment"># Connects to argos.news.ydns.eu automatically — zero config!</span>
client = ArgosClient()

<span class="comment"># Get the 10 most recent articles</span>
articles = client.<span class="function">get_latest</span>(count=<span class="variable">10</span>)

<span class="keyword">for</span> article <span class="keyword">in</span> articles:
    <span class="builtin">print</span>(f<span class="string">"[{article['source_name']}] {article['title']}"</span>)</pre>

            <p>Output:</p>
<pre><span class="comment">[Al Jazeera] Peace talks resume in Cairo amid cautious optimism
[Middle East Eye] New tech hub opens in Riyadh
[Al Arabiya] Oil prices surge on OPEC+ decision
...</span></pre>

            <h2 id="connection">Connection Setup</h2>
            <p>By default, the client connects to <code>argos.news.ydns.eu:8000</code>. No configuration needed.</p>

            <h3>Local Development</h3>
            <p>If you're running the API server locally:</p>
<pre>client = ArgosClient(base_url=<span class="string">"http://localhost:8000"</span>)</pre>

            <h3>Context Manager</h3>
            <p>Use <code>with</code> for automatic resource cleanup:</p>
<pre><span class="keyword">with</span> ArgosClient() <span class="keyword">as</span> client:
    articles = client.<span class="function">get_latest</span>()
    <span class="comment"># Connection is automatically closed when done</span></pre>

            <h3>Custom Timeout</h3>
            <p>Default timeout is 30 seconds. Increase for slow connections:</p>
<pre>client = ArgosClient(timeout=<span class="variable">60</span>)  <span class="comment"># 60-second timeout</span></pre>

            <h2 id="get-latest">get_latest(count=20)</h2>
            <p>Returns the N most recently published articles. No filters — just the latest news.</p>
<pre>latest = client.<span class="function">get_latest</span>(count=<span class="variable">5</span>)

<span class="comment"># Returns: list of article dicts</span>
<span class="keyword">for</span> a <span class="keyword">in</span> latest:
    <span class="builtin">print</span>(f<span class="string">"{a['published_at'][:10]}: {a['title']}"</span>)
    <span class="builtin">print</span>(f<span class="string">"  Source: {a['source_name']} | Category: {a['category']}"</span>)
    <span class="builtin">print</span>(f<span class="string">"  Trust: {a['trust_score']} | Tags: {', '.join(a['tags'])}"</span>)
    <span class="builtin">print</span>()</pre>

            <table>
                <tr><th>Parameter</th><th>Type</th><th>Default</th><th>Description</th></tr>
                <tr><td><code>count</code></td><td>int</td><td>20</td><td>Number of articles (max 100)</td></tr>
            </table>

            <h2 id="get-articles">get_articles(**filters)</h2>
            <p>The main query method. Search with any combination of filters — all are optional and keyword-only.</p>
<pre>results = client.<span class="function">get_articles</span>(
    source_name=<span class="string">"Al Jazeera"</span>,
    category=<span class="string">"war"</span>,
    date_from=<span class="string">"2024-01-01"</span>,
    date_to=<span class="string">"2024-12-31"</span>,
    page_size=<span class="variable">50</span>,
)

<span class="comment"># results has two keys: "articles" and "pagination"</span>
<span class="builtin">print</span>(f<span class="string">"Found {results['pagination']['total_results']} articles"</span>)

<span class="keyword">for</span> a <span class="keyword">in</span> results[<span class="string">"articles"</span>]:
    <span class="builtin">print</span>(f<span class="string">"  {a['title']}"</span>)</pre>

            <div class="tip">
                <strong>💡 Tip:</strong> All parameters are keyword-only — you must name them explicitly. This prevents positional argument mistakes.
            </div>

            <h3>Multi-filter Example</h3>
<pre><span class="comment"># Find war articles from Israeli-influenced sources in 2024</span>
results = client.<span class="function">get_articles</span>(
    category=<span class="string">"war"</span>,
    is_israeli_influenced=<span class="builtin">True</span>,
    date_from=<span class="string">"2024-01-01"</span>,
    sort_by=<span class="string">"published_at"</span>,
    order=<span class="string">"desc"</span>,
)

<span class="builtin">print</span>(f<span class="string">"Total: {results['pagination']['total_results']}"</span>)
<span class="builtin">print</span>(f<span class="string">"Pages: {results['pagination']['total_pages']}"</span>)</pre>

            <h3>Title Search</h3>
<pre><span class="comment"># Search for articles mentioning "ceasefire"</span>
results = client.<span class="function">get_articles</span>(title=<span class="string">"ceasefire"</span>)
<span class="builtin">print</span>(f<span class="string">"Found {results['pagination']['total_results']} ceasefire articles"</span>)</pre>

            <h3>Tag Filtering</h3>
<pre><span class="comment"># Find articles tagged with BOTH "Egypt" and "diplomacy"</span>
results = client.<span class="function">get_articles</span>(tags=[<span class="string">"Egypt"</span>, <span class="string">"diplomacy"</span>])
<span class="comment"># Tags use AND logic — article must have ALL specified tags</span></pre>

            <h2 id="get-article">get_article(article_id)</h2>
            <p>Get a single article by its database ID:</p>
<pre>article = client.<span class="function">get_article</span>(article_id=<span class="variable">42</span>)

<span class="builtin">print</span>(article[<span class="string">"title"</span>])
<span class="builtin">print</span>(article[<span class="string">"content"</span>])
<span class="builtin">print</span>(article[<span class="string">"source_url"</span>])  <span class="comment"># Link to original article</span></pre>

            <div class="warning">
                <strong>⚠️ Raises ArgosAPIError</strong> with code <code>ARTICLE_NOT_FOUND</code> if the ID doesn't exist.
            </div>

            <h2 id="get-sources">get_sources()</h2>
            <p>Returns all 4 registered news networks with their metadata:</p>
<pre>sources = client.<span class="function">get_sources</span>()

<span class="keyword">for</span> s <span class="keyword">in</span> sources:
    <span class="builtin">print</span>(f<span class="string">"{s['source_name']}"</span>)
    <span class="builtin">print</span>(f<span class="string">"  Country: {s['country']}"</span>)
    <span class="builtin">print</span>(f<span class="string">"  Orientation: {s['orientation']}"</span>)
    <span class="builtin">print</span>(f<span class="string">"  Trust Score: {s['trust_score']}"</span>)
    <span class="builtin">print</span>(f<span class="string">"  Israeli-Influenced: {s['is_israeli_influenced']}"</span>)
    <span class="builtin">print</span>()</pre>

            <h2 id="health-check">health_check()</h2>
            <p>Check if the API is running and the database is connected:</p>
<pre>health = client.<span class="function">health_check</span>()

<span class="builtin">print</span>(f<span class="string">"Status: {health['status']}"</span>)          <span class="comment"># "ok"</span>
<span class="builtin">print</span>(f<span class="string">"DB: {health['db_connected']}"</span>)         <span class="comment"># True/False</span>
<span class="builtin">print</span>(f<span class="string">"Articles: {health['article_count']}"</span>)  <span class="comment"># Total count</span>
<span class="builtin">print</span>(f<span class="string">"Uptime: {health['uptime_seconds']}s"</span>)  <span class="comment"># Seconds</span></pre>

            <h2 id="filters">Filter Parameters Reference</h2>
            <p>All parameters for <code>get_articles()</code>:</p>
            <table>
                <tr><th>Parameter</th><th>Type</th><th>Default</th><th>Description</th></tr>
                <tr><td><code>source_name</code></td><td>str</td><td>None</td><td>News network: "Al Jazeera", "Al Arabiya", "Sky News Arabia", "Middle East Eye"</td></tr>
                <tr><td><code>country</code></td><td>str</td><td>None</td><td>Source country: "Qatar", "Saudi Arabia", "UAE", "UK (ME Focus)"</td></tr>
                <tr><td><code>category</code></td><td>str</td><td>None</td><td>Topic: politics, economy, tech, war, health, science, culture, sports, environment, other</td></tr>
                <tr><td><code>orientation</code></td><td>str</td><td>None</td><td>Editorial: left, center-left, center, center-right, right, far-right, state, zionist, unknown</td></tr>
                <tr><td><code>is_israeli_influenced</code></td><td>bool</td><td>None</td><td>Israeli ownership/editorial influence flag</td></tr>
                <tr><td><code>date_from</code></td><td>str</td><td>None</td><td>Min date (ISO 8601): "2024-01-01" or "2024-01-01T00:00:00Z"</td></tr>
                <tr><td><code>date_to</code></td><td>str</td><td>None</td><td>Max date (ISO 8601)</td></tr>
                <tr><td><code>title</code></td><td>str</td><td>None</td><td>Search title text (partial match, case-insensitive)</td></tr>
                <tr><td><code>tags</code></td><td>list[str]</td><td>None</td><td>Tags to filter by (AND logic)</td></tr>
                <tr><td><code>page</code></td><td>int</td><td>1</td><td>Page number (1-indexed)</td></tr>
                <tr><td><code>page_size</code></td><td>int</td><td>20</td><td>Items per page (max 100)</td></tr>
                <tr><td><code>sort_by</code></td><td>str</td><td>"published_at"</td><td>Sort column</td></tr>
                <tr><td><code>order</code></td><td>str</td><td>"desc"</td><td>"asc" or "desc"</td></tr>
            </table>

            <h2 id="pagination">Pagination</h2>
            <p>The <code>get_articles()</code> response includes pagination metadata:</p>
<pre>results = client.<span class="function">get_articles</span>(page=<span class="variable">1</span>, page_size=<span class="variable">20</span>)
p = results[<span class="string">"pagination"</span>]

<span class="builtin">print</span>(f<span class="string">"Page {p['page']} of {p['total_pages']}"</span>)
<span class="builtin">print</span>(f<span class="string">"Total: {p['total_results']} articles"</span>)
<span class="builtin">print</span>(f<span class="string">"Has next: {p['has_next']}"</span>)
<span class="builtin">print</span>(f<span class="string">"Has prev: {p['has_prev']}"</span>)</pre>

            <h3>Iterating All Pages</h3>
<pre><span class="comment"># Collect ALL articles matching a filter (all pages)</span>
all_articles = []
page = <span class="variable">1</span>

<span class="keyword">while</span> <span class="builtin">True</span>:
    results = client.<span class="function">get_articles</span>(
        category=<span class="string">"war"</span>,
        page=page,
        page_size=<span class="variable">100</span>,
    )
    all_articles.extend(results[<span class="string">"articles"</span>])

    <span class="keyword">if not</span> results[<span class="string">"pagination"</span>][<span class="string">"has_next"</span>]:
        <span class="keyword">break</span>
    page += <span class="variable">1</span>

<span class="builtin">print</span>(f<span class="string">"Collected {len(all_articles)} war articles"</span>)</pre>

            <h2 id="errors">Error Handling</h2>
            <p>All errors raise <code>ArgosAPIError</code> with structured fields:</p>
<pre><span class="keyword">from</span> client <span class="keyword">import</span> ArgosClient, ArgosAPIError

client = ArgosClient()

<span class="keyword">try</span>:
    article = client.<span class="function">get_article</span>(article_id=<span class="variable">99999</span>)
<span class="keyword">except</span> ArgosAPIError <span class="keyword">as</span> e:
    <span class="builtin">print</span>(f<span class="string">"Error code: {e.code}"</span>)        <span class="comment"># "ARTICLE_NOT_FOUND"</span>
    <span class="builtin">print</span>(f<span class="string">"Message: {e.message}"</span>)          <span class="comment"># "No article found with ID 99999"</span>
    <span class="builtin">print</span>(f<span class="string">"HTTP status: {e.status_code}"</span>)  <span class="comment"># 404</span>
    <span class="builtin">print</span>(f<span class="string">"Field: {e.field}"</span>)              <span class="comment"># "article_id"</span></pre>

            <h3>Error Codes</h3>
            <table>
                <tr><th>Code</th><th>HTTP</th><th>Meaning</th></tr>
                <tr><td><code>ARTICLE_NOT_FOUND</code></td><td>404</td><td>No article with that ID</td></tr>
                <tr><td><code>VALIDATION_ERROR</code></td><td>422</td><td>Invalid request parameters</td></tr>
                <tr><td><code>INTERNAL_ERROR</code></td><td>500</td><td>Server-side error</td></tr>
                <tr><td><code>CONNECTION_ERROR</code></td><td>—</td><td>Cannot reach the API</td></tr>
                <tr><td><code>TIMEOUT_ERROR</code></td><td>—</td><td>Request timed out</td></tr>
            </table>

            <h2 id="advanced">Advanced Usage</h2>

            <h3>Comparing Source Coverage</h3>
<pre><span class="comment"># Compare how different sources cover the same topic</span>
sources = [<span class="string">"Al Jazeera"</span>, <span class="string">"Al Arabiya"</span>, <span class="string">"Sky News Arabia"</span>, <span class="string">"Middle East Eye"</span>]

<span class="keyword">for</span> source <span class="keyword">in</span> sources:
    result = client.<span class="function">get_articles</span>(
        source_name=source,
        category=<span class="string">"war"</span>,
        date_from=<span class="string">"2024-01-01"</span>,
    )
    <span class="builtin">print</span>(f<span class="string">"{source}: {result['pagination']['total_results']} war articles"</span>)</pre>

            <h3>Trust Score Analysis</h3>
<pre><span class="comment"># Get articles only from high-trust sources</span>
all_articles = client.<span class="function">get_latest</span>(count=<span class="variable">100</span>)
high_trust = [a <span class="keyword">for</span> a <span class="keyword">in</span> all_articles <span class="keyword">if</span> a[<span class="string">"trust_score"</span>] >= <span class="variable">0.5</span>]
<span class="builtin">print</span>(f<span class="string">"High-trust articles: {len(high_trust)} / {len(all_articles)}"</span>)</pre>

            <h3>Israeli Influence Filter</h3>
<pre><span class="comment"># Get articles ONLY from independent (non-Israeli-influenced) sources</span>
results = client.<span class="function">get_articles</span>(
    is_israeli_influenced=<span class="builtin">False</span>,
    category=<span class="string">"politics"</span>,
)
<span class="builtin">print</span>(f<span class="string">"Independent politics articles: {results['pagination']['total_results']}"</span>)</pre>

            <h2 id="examples">Real-World Examples</h2>

            <h3>Daily News Digest Script</h3>
<pre><span class="keyword">from</span> client <span class="keyword">import</span> ArgosClient
<span class="keyword">from</span> datetime <span class="keyword">import</span> datetime, timedelta

client = ArgosClient()
today = datetime.now().strftime(<span class="string">"%Y-%m-%d"</span>)
yesterday = (datetime.now() - timedelta(days=<span class="variable">1</span>)).strftime(<span class="string">"%Y-%m-%d"</span>)

<span class="comment"># Get today's articles</span>
results = client.<span class="function">get_articles</span>(
    date_from=yesterday,
    date_to=today,
    page_size=<span class="variable">100</span>,
    sort_by=<span class="string">"published_at"</span>,
    order=<span class="string">"desc"</span>,
)

<span class="builtin">print</span>(f<span class="string">"=== Daily Digest ({today}) ==="</span>)
<span class="builtin">print</span>(f<span class="string">"Total articles: {results['pagination']['total_results']}"</span>)
<span class="builtin">print</span>()

<span class="keyword">for</span> a <span class="keyword">in</span> results[<span class="string">"articles"</span>][:<span class="variable">10</span>]:
    <span class="builtin">print</span>(f<span class="string">"[{a['source_name']}] {a['title']}"</span>)
    <span class="builtin">print</span>(f<span class="string">"  {a['summary'][:100]}..."</span>)
    <span class="builtin">print</span>()</pre>

            <h3>Data Export to CSV</h3>
<pre><span class="keyword">import</span> csv
<span class="keyword">from</span> client <span class="keyword">import</span> ArgosClient

client = ArgosClient()

<span class="keyword">with</span> <span class="builtin">open</span>(<span class="string">"war_articles.csv"</span>, <span class="string">"w"</span>, newline=<span class="string">""</span>) <span class="keyword">as</span> f:
    writer = csv.DictWriter(f, fieldnames=[
        <span class="string">"title"</span>, <span class="string">"source_name"</span>, <span class="string">"published_at"</span>,
        <span class="string">"country"</span>, <span class="string">"orientation"</span>, <span class="string">"trust_score"</span>
    ])
    writer.writeheader()

    page = <span class="variable">1</span>
    <span class="keyword">while</span> <span class="builtin">True</span>:
        results = client.<span class="function">get_articles</span>(
            category=<span class="string">"war"</span>, page=page, page_size=<span class="variable">100</span>
        )
        <span class="keyword">for</span> a <span class="keyword">in</span> results[<span class="string">"articles"</span>]:
            writer.writerow({k: a[k] <span class="keyword">for</span> k <span class="keyword">in</span> writer.fieldnames})

        <span class="keyword">if not</span> results[<span class="string">"pagination"</span>][<span class="string">"has_next"</span>]:
            <span class="keyword">break</span>
        page += <span class="variable">1</span>

<span class="builtin">print</span>(<span class="string">"Export complete!"</span>)</pre>

            <div class="tip">
                <strong>📖 Article Data Model:</strong> Every article has exactly 13 fields: title, content, summary, category, tags, source_name, source_url, published_at, scraped_at, country, orientation, trust_score, is_israeli_influenced. Plus <code>id</code> from the database.
            </div>

            <br><br>
            <p style="text-align: center; color: var(--text-muted); font-size: 13px;">
                ARGOS v0.1.0 — Named after Argus Panoptes, the all-seeing guardian<br>
                Built by Zayani Mouhamed Mouheb / EGen Labs
            </p>
        </main>
    </div>
</body>
</html>"""
