# Published at https://pypi.org/project/acryl-datahub-airflow-plugin-hcc-clean/.
__package_name__ = "acryl-datahub-airflow-plugin-hcc-clean"
__version__ = "1.4.0.3.post2"
