"""
khy OS 的 Python 入口（新手版说明）

你在终端输入 `khy` 时，先执行的是这个文件。
它的职责是把控制权安全地交给 Node.js 后端。

执行流程：
1. 检查 Node.js 版本（必须 >= 18）
2. 找到 backend 目录（pip 安装模式或源码模式）
3. 首次运行时自动完成初始化（npm/.env/数据库）
4. 启动 Node CLI（bin/khyquant.js）
"""
import os
import subprocess
import sys
from pathlib import Path

try:
    # Python 3.8+ 自带 importlib.metadata
    from importlib import metadata as importlib_metadata
except ImportError:  # Python < 3.8 的兼容兜底
    import importlib_metadata  # type: ignore


def get_bundle_dir() -> Path:
    """返回 backend 目录路径（这是 Node 端核心代码所在位置）。

    查找顺序：
    1. 独立后端包（khy-quant-backend）
    2. pip 安装后的 bundled/backend
    3. 源码开发目录 ../backend

    backend 中包含：
    - bin/khyquant.js（Node CLI 入口）
    - server.js（后端服务）
    - src/（业务代码）
    - package.json（依赖定义）
    """
    # 方案1：尝试独立后端包
    try:
        from khy_quant_backend.cli import get_bundle_dir as _backend_get
        return _backend_get()
    except ImportError:
        pass

    # 方案2：源码开发模式优先（避免仓库内 bundled 与 backend 内容漂移）
    project_root = Path(__file__).parent.parent
    dev = project_root / "backend"
    if (project_root / ".git").exists() and dev.exists():
        return dev

    # 方案3：pip 安装模式（backend 在 wheel 内）
    bundled = Path(__file__).parent / "bundled" / "backend"
    if bundled.exists():
        return bundled

    # 方案4：源码模式兜底（pip install -e .）
    if dev.exists():
        return dev

    # 都找不到时，给出可操作提示
    print("Error: Cannot locate khy OS backend directory.", file=sys.stderr)
    print("  If you installed via pip, the package may be corrupted.", file=sys.stderr)
    print("  Try: pip install --force-reinstall khy-os", file=sys.stderr)
    print("  Fallback: pip install --force-reinstall khy-quant", file=sys.stderr)
    sys.exit(1)


def _subprocess_kwargs():
    """返回 subprocess 的平台参数（主要用于 Windows 隐藏黑窗）。

    在 Windows 上，子进程默认会弹出控制台窗口。
    这里把窗口隐藏，避免初始化过程频繁闪烁。
    """
    kwargs = {}
    if os.name == "nt":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0  # SW_HIDE：不显示窗口
        kwargs["startupinfo"] = si
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    return kwargs


def check_node() -> str:
    """检查 Node.js 是否存在且版本>=18，返回可执行命令名。

    这里尝试 node / node.exe 两种命令，兼容不同 PATH 配置。
    """
    for cmd in ("node", "node.exe"):
        try:
            result = subprocess.run(
                [cmd, "--version"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=10,
                **_subprocess_kwargs(),
            )
            if result.returncode == 0:
                # 版本示例：v22.12.0 -> 22
                version = result.stdout.strip().lstrip("v")
                major = int(version.split(".")[0])
                if major >= 18:
                    return cmd
                print(
                    f"Error: Node.js v{version} found but >= 18 required.",
                    file=sys.stderr,
                )
                _print_node_install_hint()
                sys.exit(1)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue

    print("Error: Node.js not found.", file=sys.stderr)
    print("  khy OS requires Node.js >= 18.", file=sys.stderr)
    _print_node_install_hint()
    sys.exit(1)


def get_installed_version() -> str:
    """Read installed package version (empty string on failure)."""
    for package_name in ("khy-os", "khy-quant"):
        try:
            return importlib_metadata.version(package_name)
        except Exception:
            continue
    return ""


def _print_node_install_hint():
    """输出 Node.js 安装提示（按系统给出不同建议）。"""
    # 检测中文环境，优先给国内镜像地址
    lang = os.environ.get("LANG", "") + os.environ.get("LC_ALL", "")
    tz = os.environ.get("TZ", "")
    is_china = lang.startswith("zh") or "Shanghai" in tz or "Chongqing" in tz

    if is_china:
        print("  Install from: https://npmmirror.com/mirrors/node/", file=sys.stderr)
    else:
        print("  Install from: https://nodejs.org/", file=sys.stderr)

    # 不同平台的安装建议
    plat = sys.platform
    if plat == "darwin":
        print("  Or: brew install node", file=sys.stderr)
    elif plat.startswith("linux"):
        print("  Or: curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash -", file=sys.stderr)
    elif plat == "win32":
        print("  Or: winget install OpenJS.NodeJS.LTS", file=sys.stderr)


def _print_fallback_help():
    """当后端依赖缺失时，输出最小可用帮助信息。"""
    print("khy OS CLI")
    print("")
    print("Usage:")
    print("  khy [command] [args]")
    print("  khy-os [command] [args]")
    print("  khyquant [command] [args]")
    print("")
    print("Common:")
    print('  khy -p "your question"        # one-shot AI output')
    print("  khy-os --no-server help       # command help")
    print("  khy-os --version              # version")
    print("  khy bundle verify --manifest <manifest.json>")
    print("  khy bundle repair --manifest <manifest.json>")
    print("  khy iso build --output dist/khy-os.iso")
    print("")
    print("Note:")
    print("  Bundled backend dependencies are missing in this environment.")
    print("  Run a normal startup once (without --help/--version) to initialize.")


def _normalize_bundle_command(raw_args):
    """Map bundle-related aliases to bundle subcommand argv.

    Supported forms:
      - khy bundle verify ...
      - khy bundle repair ...
      - khy os verify-bundle ...
      - khy os repair-bundle ...
      - khy verify-bundle ...
      - khy repair-bundle ...
    """
    if not raw_args:
        return None

    argv = [str(a).strip() for a in raw_args if str(a).strip()]
    if not argv:
        return None

    head = argv[0].lower()
    if head == "bundle":
        return argv[1:]

    if head == "os" and len(argv) >= 2:
        cmd = argv[1].lower()
        if cmd == "verify-bundle":
            return ["verify"] + argv[2:]
        if cmd == "repair-bundle":
            return ["repair"] + argv[2:]
        return None

    if head == "verify-bundle":
        return ["verify"] + argv[1:]
    if head == "repair-bundle":
        return ["repair"] + argv[1:]
    return None


def _normalize_iso_build_command(raw_args):
    """Map ISO build aliases to script argv.

    Supported forms:
      - khy iso build [--output ...] [--no-cache]
      - khy os iso build [--output ...] [--no-cache]
      - khy build-iso [--output ...] [--no-cache]
    """
    if not raw_args:
        return None

    argv = [str(a).strip() for a in raw_args if str(a).strip()]
    if not argv:
        return None

    lower = [a.lower() for a in argv]
    if len(lower) >= 2 and lower[0] == "iso" and lower[1] == "build":
        return argv[2:]
    if len(lower) >= 3 and lower[0] == "os" and lower[1] == "iso" and lower[2] == "build":
        return argv[3:]
    if lower[0] == "build-iso":
        return argv[1:]
    return None


def _find_iso_script(is_windows: bool) -> Path | None:
    """Locate ISO build helper script in source mode or pip bundled mode."""
    project_root = Path(__file__).parent.parent
    bundled_root = Path(__file__).parent / "bundled"
    if is_windows:
        candidates = [
            project_root / "scripts" / "alpine" / "build-iso-windows.ps1",
            bundled_root / "scripts" / "alpine" / "build-iso-windows.ps1",
        ]
    else:
        candidates = [
            project_root / "scripts" / "alpine" / "build-iso-docker.sh",
            bundled_root / "scripts" / "alpine" / "build-iso-docker.sh",
        ]
    for p in candidates:
        if p.exists():
            return p
    return None


def _run_iso_build_cli(script_args):
    """Run cross-platform ISO build helper script."""
    is_windows = os.name == "nt"
    script = _find_iso_script(is_windows)
    if not script:
        print("Error: ISO build script not found in this installation.", file=sys.stderr)
        print("  Please reinstall khy-os or use source tree with scripts/alpine.", file=sys.stderr)
        return 1

    if is_windows:
        cmd = [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script),
            *script_args,
        ]
    else:
        cmd = ["bash", str(script), *script_args]

    result = subprocess.run(cmd)
    return int(result.returncode or 0)


def main():
    """控制台入口函数（pyproject.toml 的 console_scripts 指向这里）。

    三个命令名都会进到这里：
    - khy
    - khy-os
    - khy-quant
    - khyquant
    """
    raw_args = sys.argv[1:]
    bundle_argv = _normalize_bundle_command(raw_args)
    if bundle_argv is not None:
        from khy_quant.bundle_tools import run_bundle_cli
        sys.exit(run_bundle_cli(bundle_argv))

    iso_argv = _normalize_iso_build_command(raw_args)
    if iso_argv is not None:
        sys.exit(_run_iso_build_cli(iso_argv))

    node = check_node()
    backend_dir = get_bundle_dir()

    # 定位 Node CLI 入口脚本
    cli_script = backend_dir / "bin" / "khyquant.js"
    if not cli_script.exists():
        print(f"Error: CLI script not found at {cli_script}", file=sys.stderr)
        sys.exit(1)

    # 判断用户是用 khy/khy-os 还是 khyquant 调用（用于后续模式差异）
    invoked = Path(sys.argv[0]).stem.lower().replace("-", "")
    is_khy_mode = invoked in {"khy", "khyos"}

    control_flags = {"--no-server", "--cli"}
    effective_args = [a for a in raw_args if a not in control_flags]
    first_effective = (effective_args[0] if effective_args else "").lower()
    is_help = ("--help" in raw_args) or ("-h" in raw_args) or (first_effective == "help")
    is_version = (
        ("--version" in raw_args)
        or ("-v" in raw_args)
        or ("-V" in raw_args)
        or (first_effective == "version")
    )

    # 快速路径：help/version 不触发首次初始化
    if not (is_help or is_version):
        from khy_quant._bootstrap import ensure_bootstrapped
        ensure_bootstrapped(backend_dir, node)

    # 拼接最终要执行的 Node 命令
    args = [node, str(cli_script)] + raw_args

    # 传递环境变量给 Node 进程
    env = os.environ.copy()
    env["KHYQUANT_ROOT"] = str(backend_dir)  # 告诉后端自己的目录
    # Ensure wrapper behavior matches direct Node CLI:
    # prefer the selected adapter and avoid relay bind fallback loops by default.
    env.setdefault("GATEWAY_PREFERRED_STRICT", "true")
    env.setdefault("GATEWAY_RELAY_ENABLED", "false")

    # Fix module resolution for @khy/shared (file: dependency).
    # When npm links a file: dep, Node resolves require() relative to the
    # *real* path (packages/shared/) which has no node_modules.
    # Setting NODE_PATH lets those requires fall back to backend/node_modules.
    node_modules_dir = str(backend_dir / "node_modules")
    existing_node_path = env.get("NODE_PATH", "")
    env["NODE_PATH"] = (
        f"{node_modules_dir}{os.pathsep}{existing_node_path}"
        if existing_node_path
        else node_modules_dir
    )
    pkg_version = get_installed_version()
    if pkg_version:
        env["KHYQUANT_PKG_VERSION"] = pkg_version  # 用于版本显示
    # 告诉 Node 当前入口别名（khy / khyquant）
    env["KHYQUANT_INVOKED_AS"] = "khy" if is_khy_mode else "khyquant"

    # help/version 走子进程，便于优雅处理“依赖缺失”场景
    if is_help or is_version:
        result = subprocess.run(
            args,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            **_subprocess_kwargs(),
        )
        # bundled 里没 node_modules 时，仍返回可读帮助
        if is_help and "Cannot find module" in (result.stderr or ""):
            _print_fallback_help()
            sys.exit(0)
        if result.stdout:
            print(result.stdout, end="")
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr)
        if result.returncode == 0:
            sys.exit(0)
        sys.exit(result.returncode)

    if os.name == "nt":
        # Windows 无 os.execvpe，改用 subprocess
        # 注意：保持用户当前目录，不强制切到 backend_dir
        result = subprocess.run(args, env=env)
        sys.exit(result.returncode)
    else:
        # Unix 直接替换当前进程为 Node，REPL 交互更自然
        os.execvpe(node, args, env)
