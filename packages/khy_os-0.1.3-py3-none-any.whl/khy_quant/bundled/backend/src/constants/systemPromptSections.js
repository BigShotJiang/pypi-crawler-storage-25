'use strict';

/**
 * System prompt section management with memoization.
 * Ported from Claude Code's systemPromptSections.ts architecture.
 *
 * Two types of sections:
 * - systemPromptSection(): Cached once per session, memoized until /clear or /compact
 * - DANGEROUS_uncachedSystemPromptSection(): Recomputes every turn
 */

const _sectionCache = new Map();

/**
 * Create a cached system prompt section.
 * The compute function is called once and memoized until cache is cleared.
 *
 * @param {string} id - Unique section identifier
 * @param {Function} compute - Async or sync function that returns string|null
 * @returns {{ id: string, compute: Function, cached: boolean }}
 */
function systemPromptSection(id, compute) {
  return { id, compute, cached: true };
}

/**
 * Create an uncached system prompt section that recomputes every turn.
 * Use sparingly - breaks prompt caching.
 *
 * @param {string} id - Unique section identifier
 * @param {Function} compute - Async or sync function that returns string|null
 * @param {string} _reason - Why this section cannot be cached (for documentation)
 * @returns {{ id: string, compute: Function, cached: boolean }}
 */
function DANGEROUS_uncachedSystemPromptSection(id, compute, _reason) {
  return { id, compute, cached: false };
}

/**
 * Resolve all system prompt sections, using cache where possible.
 *
 * @param {Array<{ id: string, compute: Function, cached: boolean }>} sections
 * @returns {Promise<string[]>} Resolved non-null section strings
 */
async function resolveSystemPromptSections(sections) {
  const results = [];

  for (const section of sections) {
    let value;

    if (section.cached && _sectionCache.has(section.id)) {
      value = _sectionCache.get(section.id);
    } else {
      value = await section.compute();
      if (section.cached) {
        _sectionCache.set(section.id, value);
      }
    }

    if (value != null) {
      results.push(value);
    }
  }

  return results;
}

/**
 * Clear all cached sections (called on /clear or /compact).
 */
function clearSectionCache() {
  _sectionCache.clear();
}

module.exports = {
  systemPromptSection,
  DANGEROUS_uncachedSystemPromptSection,
  resolveSystemPromptSections,
  clearSectionCache,
};
