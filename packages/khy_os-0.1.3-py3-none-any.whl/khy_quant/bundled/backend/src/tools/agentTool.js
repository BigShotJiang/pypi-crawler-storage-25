/**
 * Agent Tool — spawn independent sub-agents for parallel work.
 *
 * Inspired by Claude Code's AgentTool: sub-agents run with full tool access
 * in independent async contexts. Each agent gets its own tool-use loop.
 *
 * Two modes:
 *   1. Coordinator mode (advanced): full worker management via coordinator
 *   2. Standalone mode (default): lightweight agent using direct AI chat + tool loop
 */
const { defineTool } = require('./_baseTool');
const path = require('path');

module.exports = defineTool({
  name: 'agent',
  description:
    'Launch a sub-agent to handle a task autonomously. The agent has access to ' +
    'all tools (read, write, execute, search, explore). Use for: parallel research, ' +
    'independent code tasks, file exploration across multiple directories. ' +
    'Provide a detailed, self-contained prompt — agents cannot see conversation history.',
  category: 'coordinator',
  risk: 'medium',
  isReadOnly: false,
  isConcurrencySafe: true,
  alwaysLoad: true,

  aliases: ['spawn_worker', 'delegate', 'sub_agent', 'subagent'],
  searchHint: 'spawn worker agent delegate task parallel explore research',

  inputSchema: {
    prompt: {
      type: 'string',
      required: true,
      description: 'Self-contained task description (must include all context the agent needs)',
    },
    role: {
      type: 'string',
      required: false,
      description: 'Agent role: explore, coder, reviewer, general (default: general)',
    },
    timeout: {
      type: 'number',
      required: false,
      description: 'Timeout in seconds (default: 120)',
    },
  },

  // Always enabled — standalone mode works without coordinator
  isEnabled() { return true; },

  getActivityDescription(input) {
    const role = input.role || 'general';
    const preview = (input.prompt || '').slice(0, 40);
    return `Agent (${role}): ${preview}`;
  },

  getToolUseSummary(input) {
    return `agent: ${(input.prompt || '').slice(0, 60)}`;
  },

  async execute(params) {
    const timeoutMs = (params.timeout || 120) * 1000;
    const role = params.role || 'general';

    // Try coordinator mode first
    try {
      const { isCoordinatorMode } = require('../coordinator/coordinatorMode');
      if (isCoordinatorMode()) {
        const { spawnWorker } = require('../coordinator/workerAgent');
        const worker = await spawnWorker(params.prompt, {
          role,
          timeout: timeoutMs,
        });
        return {
          success: true,
          workerId: worker.id,
          role: worker.role,
          status: worker.status,
          output: worker.output || worker.message,
          message: `Worker ${worker.id} completed as ${worker.role}.`,
        };
      }
    } catch { /* coordinator not available, use standalone mode */ }

    // Standalone mode: run a mini tool-use loop with direct AI chat
    return _runStandaloneAgent(params.prompt, role, timeoutMs);
  },
});

/**
 * Standalone agent execution — uses a fresh AI chat + tool-use loop.
 * No coordinator dependency, works with any available AI provider.
 */
async function _runStandaloneAgent(prompt, role, timeoutMs) {
  const startTime = Date.now();

  // Build a role-specific system prompt prefix
  const roleHints = {
    explore: 'You are a codebase exploration agent. Search files, read code, and summarize findings. Do NOT modify files.',
    coder: 'You are a coding agent. Read, write, and edit files to complete the task. Test your changes.',
    reviewer: 'You are a code review agent. Read code, find issues, and provide actionable feedback. Do NOT modify files.',
    general: 'You are a general-purpose agent. Use available tools to complete the task efficiently.',
  };
  const rolePrompt = roleHints[role] || roleHints.general;

  try {
    // Use tool-use loop for agentic execution
    const toolUseLoop = require('../services/toolUseLoop');

    if (toolUseLoop.isEnabled()) {
      const ai = require('../cli/ai');
      const agentPrompt = `[Agent Task — Role: ${role}]\n${rolePrompt}\n\nTask:\n${prompt}`;
      const toolLog = [];

      const result = await Promise.race([
        toolUseLoop.runToolUseLoop(agentPrompt, {
          chat: (message, opts = {}) => ai.chat(message, {
            ...opts,
            disableNaturalToolLoop: true,
          }),
          maxIterations: 8,
          onToolCall: (name, params, iteration) => {
            toolLog.push({ tool: name, iteration, status: 'started' });
          },
          onToolResult: (name, params, result, iteration, elapsed) => {
            const last = toolLog.find(t => t.tool === name && t.status === 'started');
            if (last) {
              last.status = result?.success ? 'success' : 'error';
              last.elapsed = elapsed;
            }
          },
        }),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Agent timed out')), timeoutMs)
        ),
      ]);

      const elapsed = Date.now() - startTime;
      return {
        success: true,
        role,
        output: result.finalResponse || '',
        iterations: result.iterations,
        toolCalls: toolLog.length,
        elapsed: `${(elapsed / 1000).toFixed(1)}s`,
        message: `Agent (${role}) completed in ${(elapsed / 1000).toFixed(1)}s with ${toolLog.length} tool uses.`,
      };
    }

    // Fallback: simple single-shot AI chat (no tool loop)
    const ai = require('../cli/ai');
    const result = await ai.chat(`[Agent Task — ${role}] ${prompt}`, {
      disableNaturalToolLoop: false,
    });
    const elapsed = Date.now() - startTime;
    return {
      success: true,
      role,
      output: result.reply || '',
      iterations: 1,
      toolCalls: 0,
      elapsed: `${(elapsed / 1000).toFixed(1)}s`,
      message: `Agent (${role}) completed in ${(elapsed / 1000).toFixed(1)}s.`,
    };
  } catch (err) {
    const elapsed = Date.now() - startTime;
    return {
      success: false,
      role,
      error: err.message,
      elapsed: `${(elapsed / 1000).toFixed(1)}s`,
      message: `Agent (${role}) failed after ${(elapsed / 1000).toFixed(1)}s: ${err.message}`,
    };
  }
}
