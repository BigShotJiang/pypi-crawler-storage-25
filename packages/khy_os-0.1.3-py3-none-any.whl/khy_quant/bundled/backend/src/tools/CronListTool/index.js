/**
 * CronListTool — list all scheduled cron jobs.
 * Aligned with Claude Code's CronList tool.
 */
const { BaseTool } = require('../_baseTool');

class CronListTool extends BaseTool {
  static toolName = 'CronList';
  static category = 'system';
  static risk = 'safe';
  static aliases = ['cron_list', 'list_cron'];
  static searchHint = 'list cron jobs schedule view';

  isReadOnly() { return true; }

  prompt() {
    return `List all cron jobs scheduled via CronCreate/ScheduleCron, both durable (.khy/scheduled_tasks.json) and session-only.`;
  }

  inputSchema() {
    return { type: 'object', properties: {} };
  }

  async execute() {
    try {
      const cronScheduler = require('../../jobs/cronScheduler');
      const jobs = cronScheduler.listJobs();
      return { jobs, count: jobs.length };
    } catch (err) {
      return { error: err.message };
    }
  }
}

module.exports = CronListTool;
