/**
 * Tool: build_project — detect project type and run build with structured output.
 */
'use strict';

const { defineTool } = require('./_baseTool');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// ─── Project Type Detection ────────────────────────────────────────────────

const BUILD_CONFIGS = [
  { file: 'package.json', type: 'nodejs', detect: _detectNodeBuild },
  { file: 'Cargo.toml',   type: 'rust',   cmd: 'cargo build --release' },
  { file: 'go.mod',       type: 'go',     cmd: 'go build ./...' },
  { file: 'Makefile',     type: 'make',   cmd: 'make' },
  { file: 'makefile',     type: 'make',   cmd: 'make' },
  { file: 'CMakeLists.txt', type: 'cmake', cmd: 'mkdir -p build && cd build && cmake .. && make' },
  { file: 'build.gradle', type: 'gradle', cmd: './gradlew build' },
  { file: 'pom.xml',      type: 'maven',  cmd: 'mvn package -q' },
];

function _detectNodeBuild(cwd) {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf-8'));
    if (pkg.scripts && pkg.scripts.build) return `npm run build`;
  } catch { /* ignore */ }
  return null;
}

function _detectProject(cwd) {
  for (const config of BUILD_CONFIGS) {
    if (fs.existsSync(path.join(cwd, config.file))) {
      const cmd = config.detect ? config.detect(cwd) : config.cmd;
      return { type: config.type, command: cmd };
    }
  }
  return null;
}

// ─── Output Parsers ────────────────────────────────────────────────────────

function _parseErrors(output, type) {
  const errors = [];
  const warnings = [];
  const lines = output.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (type === 'nodejs' || type === 'cmake') {
      // Webpack/TypeScript/ESBuild: ERROR in ./path:line:col
      const errMatch = line.match(/ERROR\s+in\s+(.+?)(?::(\d+):(\d+))?/);
      if (errMatch) { errors.push({ file: errMatch[1], line: _int(errMatch[2]), col: _int(errMatch[3]), message: lines[i + 1]?.trim() || '' }); continue; }
      const warnMatch = line.match(/WARNING\s+in\s+(.+?)(?::(\d+):(\d+))?/);
      if (warnMatch) { warnings.push({ file: warnMatch[1], line: _int(warnMatch[2]), col: _int(warnMatch[3]), message: lines[i + 1]?.trim() || '' }); continue; }
    }

    if (type === 'rust') {
      const errMatch = line.match(/^error(?:\[E\d+\])?: (.+)/);
      if (errMatch) { errors.push({ file: '', line: null, col: null, message: errMatch[1] }); continue; }
      const warnMatch = line.match(/^warning(?:\[.+?\])?: (.+)/);
      if (warnMatch) { warnings.push({ file: '', line: null, col: null, message: warnMatch[1] }); continue; }
    }

    if (type === 'go') {
      const goMatch = line.match(/^\.?\/?(.+?):(\d+):(\d+):\s*(.+)/);
      if (goMatch) {
        const entry = { file: goMatch[1], line: _int(goMatch[2]), col: _int(goMatch[3]), message: goMatch[4] };
        if (goMatch[4].includes('error')) errors.push(entry);
        else warnings.push(entry);
        continue;
      }
    }

    // GCC/Make generic: path:line:col: error/warning: message
    const gccMatch = line.match(/^(.+?):(\d+):(\d+):\s*(error|warning):\s*(.+)/);
    if (gccMatch) {
      const entry = { file: gccMatch[1], line: _int(gccMatch[2]), col: _int(gccMatch[3]), message: gccMatch[5] };
      if (gccMatch[4] === 'error') errors.push(entry);
      else warnings.push(entry);
    }
  }

  return { errors, warnings };
}

function _int(s) { return s ? parseInt(s, 10) : null; }

// ─── Tool Definition ───────────────────────────────────────────────────────

module.exports = defineTool({
  name: 'build_project',
  description: 'Detect project type and run build command, returning structured errors/warnings. Supports Node.js, Rust, Go, Make, CMake, Gradle, Maven.',
  category: 'execution',
  risk: 'medium',
  isReadOnly: false,
  isConcurrencySafe: false,

  inputSchema: {
    cwd: { type: 'string', required: false, description: 'Project directory (defaults to process.cwd)' },
    command: { type: 'string', required: false, description: 'Override build command' },
    timeout: { type: 'number', required: false, description: 'Timeout in ms (default 120000)' },
  },

  getActivityDescription(input) {
    return `Building project${input?.cwd ? ' in ' + input.cwd : ''}`;
  },

  async execute(params) {
    const cwd = params.cwd || process.cwd();
    const timeout = params.timeout || 120000;
    const startMs = Date.now();

    // Detect or use override
    const detected = _detectProject(cwd);
    const command = params.command || (detected ? detected.command : null);
    const projectType = detected ? detected.type : 'unknown';

    if (!command) {
      return {
        success: false,
        error: `No build configuration found in ${cwd}. Provide a command or ensure a build file exists.`,
      };
    }

    let stdout = '', stderr = '', exitCode = 0;
    try {
      const output = execSync(command, {
        cwd, timeout, encoding: 'utf-8',
        stdio: ['pipe', 'pipe', 'pipe'],
        env: { ...process.env, FORCE_COLOR: '0', NO_COLOR: '1' },
        maxBuffer: 10 * 1024 * 1024,
      });
      stdout = output || '';
    } catch (err) {
      exitCode = err.status || 1;
      stdout = err.stdout || '';
      stderr = err.stderr || '';
    }

    const combined = stdout + '\n' + stderr;
    const { errors, warnings } = _parseErrors(combined, projectType);
    const outputLines = combined.split('\n');
    const tail = outputLines.slice(-50).join('\n');

    return {
      success: exitCode === 0,
      data: {
        projectType,
        command,
        exitCode,
        errors,
        warnings,
        errorCount: errors.length,
        warningCount: warnings.length,
        durationMs: Date.now() - startMs,
        outputTail: tail.slice(0, 5000),
      },
    };
  },
});
