/**
 * FileWriteTool — file creation/overwrite tool, aligned with Claude Code's Write tool.
 *
 * Completely replaces the contents of a file or creates a new one.
 * Prefer the Edit tool for modifying existing files.
 */
const { BaseTool } = require('../_baseTool');
const fs = require('fs');
const path = require('path');

class FileWriteTool extends BaseTool {
  static toolName = 'Write';
  static category = 'filesystem';
  static risk = 'high';
  static aliases = ['writeFile', 'write_file', 'create_file'];
  static searchHint = 'write create file overwrite';
  static alwaysLoad = true;
  static maxResultSizeChars = 1000;

  isReadOnly() { return false; }

  isDestructive(input) {
    if (!input?.file_path) return false;
    try {
      const resolved = path.resolve(
        process.env.KHYQUANT_CWD || process.cwd(), input.file_path
      );
      return fs.existsSync(resolved);
    } catch { return false; }
  }

  isConcurrencySafe() { return false; }

  prompt() {
    return `Writes a file to the local filesystem.

Usage:
- This tool will overwrite the existing file if there is one at the provided path.
- If this is an existing file, you MUST use the Read tool first to read the file's contents. This tool will fail if you did not read the file first.
- Prefer the Edit tool for modifying existing files — it only sends the diff. Only use this tool to create new files or for complete rewrites.
- NEVER create documentation files (*.md) or README files unless explicitly requested by the User.`;
  }

  get inputSchema() {
    return {
      type: 'object',
      properties: {
        file_path: {
          type: 'string',
          description: 'The absolute path to the file to write (must be absolute, not relative)',
        },
        content: {
          type: 'string',
          description: 'The content to write to the file',
        },
      },
      required: ['file_path', 'content'],
    };
  }

  async validateInput(params) {
    try {
      const { validateNotUNCPath, validateNoPathTraversal, composeValidations } = require('../inputValidators');
      return composeValidations(
        validateNotUNCPath(params.file_path),
        validateNoPathTraversal(params.file_path),
      );
    } catch {
      return { valid: true };
    }
  }

  getActivityDescription(input) {
    return `Writing to ${input.file_path || 'file'}`;
  }

  getToolUseSummary(input) {
    if (!input.file_path) return null;
    return `write ${path.basename(input.file_path)}`;
  }

  async execute(params, _context) {
    try {
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      let rawPath = params.file_path;

      if (process.platform === 'win32') {
        rawPath = rawPath.replace(/%([^%]+)%/g, (_, key) => process.env[key] || `%${key}%`);
      } else {
        rawPath = rawPath.replace(/\$\{?(\w+)\}?/g, (_, key) => process.env[key] || '');
      }
      if (rawPath.startsWith('~')) {
        rawPath = path.join(require('os').homedir(), rawPath.slice(1));
      }

      const filePath = path.resolve(cwd, rawPath);
      const dir = path.dirname(filePath);

      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      fs.writeFileSync(filePath, params.content, 'utf-8');
      const bytes = Buffer.byteLength(params.content, 'utf-8');

      return { success: true, path: filePath, bytes };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }
}

module.exports = new FileWriteTool();
module.exports.FileWriteTool = FileWriteTool;
