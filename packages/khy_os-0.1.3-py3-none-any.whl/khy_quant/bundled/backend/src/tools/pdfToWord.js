const { defineTool } = require('./_baseTool');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const DOC_HELPER = path.join(__dirname, '../services/docHelper.py');
const MAX_PDF_SIZE = 50 * 1024 * 1024; // 50 MB

function resolvePath(rawPath, cwd) {
  let p = String(rawPath || '');
  if (process.platform === 'win32') {
    p = p.replace(/%([^%]+)%/g, (_, key) => process.env[key] || `%${key}%`);
  } else {
    p = p.replace(/\$\{?(\w+)\}?/g, (_, key) => process.env[key] || '');
  }
  if (p.startsWith('~')) {
    p = path.join(os.homedir(), p.slice(1));
  }
  return path.resolve(cwd, p);
}

function runPython(pythonPath, args) {
  return new Promise((resolve, reject) => {
    const env = { ...process.env, PYTHONIOENCODING: 'utf-8' };
    const child = spawn(pythonPath, args, { env });

    let stdout = '';
    let stderr = '';

    const timer = setTimeout(() => {
      child.kill('SIGTERM');
      reject(new Error('Python process timed out (120s)'));
    }, 120000);

    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', d => { stdout += d; });
    child.stderr.on('data', d => { stderr += d; });

    child.on('error', err => {
      clearTimeout(timer);
      reject(new Error(`Python process error: ${err.message}`));
    });

    child.on('close', code => {
      clearTimeout(timer);
      if (code !== 0) {
        reject(new Error(`Python exit code ${code}: ${stderr}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout.trim()));
      } catch (e) {
        reject(new Error(`Failed to parse Python output: ${e.message}`));
      }
    });
  });
}

module.exports = defineTool({
  name: 'pdfToWord',
  description: 'Convert a PDF file to Word (.docx) format',
  category: 'filesystem',
  risk: 'medium',
  isReadOnly: false,
  isConcurrencySafe: true,

  aliases: ['pdf_to_word', 'pdf2word', 'pdf2docx'],
  searchHint: 'convert pdf to word docx document',

  inputSchema: {
    inputPath: { type: 'string', required: true, description: 'Path to the source PDF file' },
    outputPath: { type: 'string', required: false, description: 'Path for the output .docx file (default: same name with .docx extension)' },
  },

  async validateInput(input) {
    const { validateNotDevicePath, validateNotUNCPath, composeValidations } = require('./inputValidators');
    return composeValidations(
      validateNotDevicePath(input.inputPath),
      validateNotUNCPath(input.inputPath),
      input.outputPath ? validateNotUNCPath(input.outputPath) : { valid: true },
    );
  },

  getActivityDescription(input) {
    const name = input?.inputPath ? path.basename(input.inputPath) : 'file';
    return `Converting PDF to Word: ${name}`;
  },

  getToolUseSummary(input) {
    if (!input?.inputPath) return null;
    return `pdf2word: ${input.inputPath}`;
  },

  async execute(params) {
    const cwd = process.env.KHYQUANT_CWD || process.cwd();
    const inputPath = resolvePath(params.inputPath, cwd);
    const outputPath = params.outputPath
      ? resolvePath(params.outputPath, cwd)
      : inputPath.replace(/\.pdf$/i, '.docx');

    if (!fs.existsSync(inputPath)) {
      return { success: false, error: `File not found: ${inputPath}` };
    }

    const stat = fs.statSync(inputPath);
    if (stat.size > MAX_PDF_SIZE) {
      return { success: false, error: `PDF too large: ${(stat.size / 1024 / 1024).toFixed(1)}MB (max 50MB)` };
    }

    const { findPython } = require('../utils/pythonPath');
    const pythonPath = findPython();

    try {
      const result = await runPython(pythonPath, [DOC_HELPER, 'pdf2word', inputPath, outputPath]);
      return result;
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
