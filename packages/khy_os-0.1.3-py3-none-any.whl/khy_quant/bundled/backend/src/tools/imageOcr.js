const { defineTool } = require('./_baseTool');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const DOC_HELPER = path.join(__dirname, '../services/docHelper.py');
const MAX_IMAGE_SIZE = 20 * 1024 * 1024; // 20 MB
const SUPPORTED_FORMATS = new Set([
  '.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif', '.webp', '.gif',
]);

const MIME_MAP = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.bmp': 'image/bmp',
  '.tiff': 'image/tiff',
  '.tif': 'image/tiff',
};

function resolvePath(rawPath, cwd) {
  let p = String(rawPath || '');
  if (process.platform === 'win32') {
    p = p.replace(/%([^%]+)%/g, (_, key) => process.env[key] || `%${key}%`);
  } else {
    p = p.replace(/\$\{?(\w+)\}?/g, (_, key) => process.env[key] || '');
  }
  if (p.startsWith('~')) {
    p = path.join(os.homedir(), p.slice(1));
  }
  return path.resolve(cwd, p);
}

function runPython(pythonPath, args) {
  return new Promise((resolve, reject) => {
    const env = { ...process.env, PYTHONIOENCODING: 'utf-8' };
    const child = spawn(pythonPath, args, { env });

    let stdout = '';
    let stderr = '';

    const timer = setTimeout(() => {
      child.kill('SIGTERM');
      reject(new Error('Python process timed out (120s)'));
    }, 120000);

    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', d => { stdout += d; });
    child.stderr.on('data', d => { stderr += d; });

    child.on('error', err => {
      clearTimeout(timer);
      reject(new Error(`Python process error: ${err.message}`));
    });

    child.on('close', code => {
      clearTimeout(timer);
      if (code !== 0) {
        reject(new Error(`Python exit code ${code}: ${stderr}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout.trim()));
      } catch (e) {
        reject(new Error(`Failed to parse Python output: ${e.message}`));
      }
    });
  });
}

async function aiVisionOcr(imagePath) {
  try {
    const gateway = require('../services/gateway/aiGateway');
    const imageData = fs.readFileSync(imagePath);
    const base64 = imageData.toString('base64');
    const ext = path.extname(imagePath).toLowerCase();
    const mimeType = MIME_MAP[ext] || 'image/jpeg';

    const result = await gateway.generate(
      'Extract all text from this image. Preserve the original layout and formatting. '
      + 'If there are tables, output them in Markdown table format. '
      + 'Output only the recognized text, no explanations.',
      {
        images: [{ base64, mimeType }],
        maxTokens: 4096,
        temperature: 0.1,
      }
    );

    if (result.success) {
      return {
        success: true,
        text: result.content,
        method: 'ai_vision',
        model: result.model || result.provider,
      };
    }

    return {
      success: false,
      error: `AI vision OCR failed: ${result.content || 'unknown error'}. Install local OCR: pip install khy-os[doc]`,
    };
  } catch (err) {
    return {
      success: false,
      error: `AI vision OCR error: ${err.message}`,
    };
  }
}

module.exports = defineTool({
  name: 'imageOcr',
  description: 'Extract text from an image using OCR (local Tesseract or AI vision fallback)',
  category: 'filesystem',
  risk: 'low',
  isReadOnly: (input) => !input?.outputPath,
  isConcurrencySafe: true,

  aliases: ['ocr', 'image_to_text', 'recognize_text'],
  searchHint: 'OCR extract text from image recognize characters',

  inputSchema: {
    imagePath: { type: 'string', required: true, description: 'Path to the image file' },
    outputPath: { type: 'string', required: false, description: 'Save recognized text as an editable Word (.docx) file at this path' },
    lang: { type: 'string', required: false, description: 'OCR language (default: chi_sim+eng). Examples: eng, chi_sim, chi_tra+eng' },
    forceAi: { type: 'boolean', required: false, description: 'Force AI vision instead of local OCR' },
  },

  async validateInput(input) {
    const { validateNotDevicePath, validateNotUNCPath, composeValidations } = require('./inputValidators');
    return composeValidations(
      validateNotDevicePath(input.imagePath),
      validateNotUNCPath(input.imagePath),
    );
  },

  getActivityDescription(input) {
    const name = input?.imagePath ? path.basename(input.imagePath) : 'image';
    return `Recognizing text in ${name}`;
  },

  getToolUseSummary(input) {
    if (!input?.imagePath) return null;
    return `ocr: ${input.imagePath}`;
  },

  async execute(params) {
    const cwd = process.env.KHYQUANT_CWD || process.cwd();
    const imagePath = resolvePath(params.imagePath, cwd);

    if (!fs.existsSync(imagePath)) {
      return { success: false, error: `Image not found: ${imagePath}` };
    }

    const ext = path.extname(imagePath).toLowerCase();
    if (!SUPPORTED_FORMATS.has(ext)) {
      return {
        success: false,
        error: `Unsupported image format: ${ext}. Supported: ${[...SUPPORTED_FORMATS].join(', ')}`,
      };
    }

    const stat = fs.statSync(imagePath);
    if (stat.size > MAX_IMAGE_SIZE) {
      return {
        success: false,
        error: `Image too large: ${(stat.size / 1024 / 1024).toFixed(1)}MB (max 20MB)`,
      };
    }

    const lang = params.lang || 'chi_sim+eng';

    const { findPython } = require('../utils/pythonPath');
    const pythonPath = findPython();
    const outputDocx = params.outputPath ? resolvePath(params.outputPath, cwd) : null;

    // Force AI vision if requested
    if (params.forceAi) {
      const result = await aiVisionOcr(imagePath);
      if (result.success && outputDocx) {
        return saveTextAsDocx(pythonPath, result.text, outputDocx, result);
      }
      return result;
    }

    // Step 1: Try local Tesseract OCR via Python
    let localResult;
    try {
      localResult = await runPython(pythonPath, [DOC_HELPER, 'ocr', imagePath, lang]);
    } catch {
      localResult = { success: false, needsAiFallback: true };
    }

    // Step 2: Local OCR succeeded with adequate confidence
    if (localResult.success && !localResult.needsAiFallback) {
      const result = {
        success: true,
        text: localResult.text,
        confidence: localResult.confidence,
        method: 'tesseract',
        lang: localResult.lang,
      };
      if (outputDocx) {
        return saveTextAsDocx(pythonPath, result.text, outputDocx, result);
      }
      return result;
    }

    // Step 3: Fallback to AI vision
    const aiResult = await aiVisionOcr(imagePath);

    // Attach local result for comparison if available
    if (localResult.success && localResult.text) {
      aiResult.localText = localResult.text;
      aiResult.localConfidence = localResult.confidence;
    }

    if (aiResult.success && outputDocx) {
      return saveTextAsDocx(pythonPath, aiResult.text, outputDocx, aiResult);
    }

    return aiResult;
  },
});

async function saveTextAsDocx(pythonPath, text, outputPath, ocrResult) {
  try {
    const docResult = await runPython(pythonPath, [DOC_HELPER, 'text2docx', text, outputPath]);
    if (docResult.success) {
      return {
        ...ocrResult,
        output: docResult.output,
        outputSize: docResult.outputSize,
        message: docResult.message,
      };
    }
    // Word save failed, but OCR succeeded — return text with a warning
    return { ...ocrResult, warning: `OCR succeeded but Word save failed: ${docResult.error}` };
  } catch (err) {
    return { ...ocrResult, warning: `OCR succeeded but Word save failed: ${err.message}` };
  }
}
