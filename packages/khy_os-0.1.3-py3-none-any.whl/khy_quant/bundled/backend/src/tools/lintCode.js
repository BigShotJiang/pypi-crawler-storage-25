/**
 * Tool: lint_code — run linter and return structured file:line:message results.
 */
'use strict';

const { defineTool } = require('./_baseTool');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// ─── Linter Detection ──────────────────────────────────────────────────────

function _detectLinter(cwd) {
  // ESLint
  const eslintConfigs = ['.eslintrc', '.eslintrc.js', '.eslintrc.json', '.eslintrc.yml',
    '.eslintrc.yaml', 'eslint.config.js', 'eslint.config.mjs', 'eslint.config.ts'];
  for (const cfg of eslintConfigs) {
    if (fs.existsSync(path.join(cwd, cfg))) {
      return { linter: 'eslint', cmd: 'npx eslint --format json .' };
    }
  }
  // Check package.json for eslint
  const pkgPath = path.join(cwd, 'package.json');
  if (fs.existsSync(pkgPath)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
      if (pkg.eslintConfig) return { linter: 'eslint', cmd: 'npx eslint --format json .' };
      const deps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };
      if (deps.eslint) return { linter: 'eslint', cmd: 'npx eslint --format json .' };
    } catch { /* ignore */ }
  }

  // Cargo clippy
  if (fs.existsSync(path.join(cwd, 'Cargo.toml'))) {
    return { linter: 'clippy', cmd: 'cargo clippy --message-format=json 2>&1' };
  }

  // Go vet + golangci-lint
  if (fs.existsSync(path.join(cwd, 'go.mod'))) {
    return { linter: 'go-vet', cmd: 'go vet ./... 2>&1' };
  }

  // Python: pylint or flake8
  for (const cfg of ['.pylintrc', 'pylintrc', '.flake8', 'setup.cfg']) {
    if (fs.existsSync(path.join(cwd, cfg))) {
      const isFlake8 = cfg === '.flake8';
      return isFlake8
        ? { linter: 'flake8', cmd: 'python3 -m flake8 --format=json .' }
        : { linter: 'pylint', cmd: 'python3 -m pylint --output-format=json . 2>&1' };
    }
  }

  return null;
}

// ─── Parsers ───────────────────────────────────────────────────────────────

function _parseEslintJson(output) {
  try {
    const jsonStart = output.indexOf('[');
    if (jsonStart === -1) return null;
    const results = JSON.parse(output.slice(jsonStart));
    const issues = [];
    let errorCount = 0, warningCount = 0;

    for (const file of results) {
      for (const msg of (file.messages || [])) {
        issues.push({
          file: file.filePath ? path.relative(process.cwd(), file.filePath) : '',
          line: msg.line || null,
          col: msg.column || null,
          severity: msg.severity === 2 ? 'error' : 'warning',
          rule: msg.ruleId || '',
          message: msg.message || '',
        });
        if (msg.severity === 2) errorCount++;
        else warningCount++;
      }
    }

    return { issues, errorCount, warningCount, fileCount: results.length };
  } catch { return null; }
}

function _parseGenericLint(output) {
  const issues = [];
  let errorCount = 0, warningCount = 0;

  for (const line of output.split('\n')) {
    // Generic: file:line:col: severity: message (rule)
    const match = line.match(/^(.+?):(\d+):(\d+):\s*(error|warning|note|E\d+|W\d+|C\d+)[\s:]+(.+)/);
    if (match) {
      const severity = match[4].startsWith('E') || match[4] === 'error' ? 'error' : 'warning';
      issues.push({
        file: match[1], line: parseInt(match[2], 10), col: parseInt(match[3], 10),
        severity, rule: match[4], message: match[5].trim(),
      });
      if (severity === 'error') errorCount++; else warningCount++;
    }
  }

  return { issues, errorCount, warningCount, fileCount: 0 };
}

// ─── Tool Definition ───────────────────────────────────────────────────────

module.exports = defineTool({
  name: 'lint_code',
  description: 'Detect linter for project and run it, returning structured file:line:message issues. Supports ESLint, Clippy, go vet, Pylint, Flake8.',
  category: 'execution',
  risk: 'low',
  isReadOnly: true,
  isConcurrencySafe: true,

  inputSchema: {
    cwd: { type: 'string', required: false, description: 'Project directory' },
    files: { type: 'string', required: false, description: 'Specific files/globs to lint' },
    fix: { type: 'boolean', required: false, description: 'Auto-fix issues (default false)' },
  },

  getActivityDescription(input) {
    return `Linting code${input?.cwd ? ' in ' + input.cwd : ''}`;
  },

  async execute(params) {
    const cwd = params.cwd || process.cwd();
    const detected = _detectLinter(cwd);

    if (!detected) {
      return { success: true, data: { linter: 'none', errorCount: 0, warningCount: 0, issues: [], fileCount: 0 } };
    }

    let command = detected.cmd;
    if (params.files) command += ` ${params.files}`;
    if (params.fix && detected.linter === 'eslint') command += ' --fix';
    if (params.fix && detected.linter === 'clippy') command = command.replace('clippy', 'clippy --fix');

    let output = '', exitCode = 0;
    try {
      output = execSync(command, {
        cwd, timeout: 60000, encoding: 'utf-8',
        stdio: ['pipe', 'pipe', 'pipe'],
        maxBuffer: 10 * 1024 * 1024,
        env: { ...process.env, FORCE_COLOR: '0', NO_COLOR: '1' },
      });
    } catch (err) {
      exitCode = err.status || 1;
      output = (err.stdout || '') + '\n' + (err.stderr || '');
    }

    let parsed = null;
    if (detected.linter === 'eslint') parsed = _parseEslintJson(output);
    if (!parsed) parsed = _parseGenericLint(output);

    return {
      success: parsed.errorCount === 0,
      data: {
        linter: detected.linter,
        errorCount: parsed.errorCount,
        warningCount: parsed.warningCount,
        fixedCount: params.fix ? 0 : undefined,
        issues: parsed.issues.slice(0, 100),
        fileCount: parsed.fileCount,
      },
    };
  },
});
