const { defineTool } = require('./_baseTool');
const { execSync } = require('child_process');
const { isSearchOrReadCommand, getBaseCommand } = require('./shellClassifier');
const { isGuiApp, spawnGuiApp } = require('./platformUtils');

const MAX_OUTPUT = 50 * 1024; // 50 KB

module.exports = defineTool({
  name: 'shellCommand',
  description: 'Execute a shell command and return its output',
  category: 'execution',
  risk: 'critical',

  // Dynamic: read-only if the command is a search/read/list pipeline
  isReadOnly: (input) => {
    if (!input?.command) return false;
    const { isSearch, isRead, isList } = isSearchOrReadCommand(input.command);
    return isSearch || isRead || isList;
  },

  isDestructive: (input) => {
    // Detect dangerous shell patterns
    if (!input?.command) return false;
    return /\b(rm\s+-rf|rm\s+-r|mkfs|dd\s+if=|format\s|fdisk|wipefs|shred)\b/i.test(input.command);
  },
  isConcurrencySafe: false,

  // Chapter 5 additions
  maxResultSizeChars: 50000,

  inputSchema: {
    command: { type: 'string', required: true, description: 'Shell command to execute' },
    cwd: { type: 'string', required: false, description: 'Working directory' },
    timeout: { type: 'number', required: false, max: 60000, description: 'Timeout in ms (max 60000)' },
  },

  async validateInput(input) {
    const { validateNotDevicePath, validateNotUNCPath, composeValidations } = require('./inputValidators');

    // Check for device paths in the command arguments
    if (input.command) {
      const tokens = input.command.split(/\s+/);
      for (const token of tokens) {
        if (token.startsWith('/dev/')) {
          const devCheck = validateNotDevicePath(token);
          if (!devCheck.valid) return devCheck;
        }
      }
    }

    // Check working directory
    if (input.cwd) {
      return composeValidations(
        validateNotUNCPath(input.cwd),
      );
    }

    return { valid: true };
  },

  getActivityDescription(input) {
    if (!input?.command) return 'Executing shell command';
    const base = getBaseCommand(input.command);
    const short = input.command.length > 60
      ? input.command.slice(0, 57) + '...'
      : input.command;
    return `Running: ${short}`;
  },

  getToolUseSummary(input) {
    if (!input?.command) return null;
    return `shell: ${input.command.slice(0, 80)}`;
  },

  async execute(params, context) {
    try {
      const cwd = params.cwd || process.env.KHYQUANT_CWD || process.cwd();
      const timeout = Math.min(params.timeout || 30000, 60000);
      const baseCmd = getBaseCommand(params.command);

      // GUI apps: launch in background (detached), cross-platform
      if (isGuiApp(baseCmd)) {
        const parts = params.command.split(/\s+/);
        const child = spawnGuiApp(parts[0], parts.slice(1), { cwd });
        return { success: true, output: `已启动 ${baseCmd} (PID: ${child.pid})` };
      }

      // Windows shell built-ins (start, dir, type, etc.) require shell: true.
      // Also, commands with env vars (%USERNAME%) or pipes/redirects need shell.
      const isWin = process.platform === 'win32';
      const WIN_BUILTINS = new Set(['start', 'dir', 'type', 'copy', 'move', 'del', 'ren', 'mkdir', 'rmdir', 'chcp', 'set', 'cls', 'assoc', 'ftype']);
      const needsShell = isWin && (
        WIN_BUILTINS.has(baseCmd.toLowerCase())
        || /%\w+%/.test(params.command)
        || /[|><&]/.test(params.command)
      );

      let output = execSync(params.command, {
        cwd,
        timeout,
        encoding: 'utf-8',
        maxBuffer: MAX_OUTPUT,
        ...(needsShell ? { shell: true } : {}),
      });

      if (output && output.length > MAX_OUTPUT) {
        output = output.slice(0, MAX_OUTPUT) + '\n... [truncated]';
      }

      return { success: true, output: output || '' };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
