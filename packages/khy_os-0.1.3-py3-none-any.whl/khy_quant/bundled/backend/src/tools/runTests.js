/**
 * Tool: run_tests — detect test framework and run tests with structured results.
 */
'use strict';

const { defineTool } = require('./_baseTool');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// ─── Framework Detection ───────────────────────────────────────────────────

function _detectTestFramework(cwd) {
  const pkgPath = path.join(cwd, 'package.json');
  if (fs.existsSync(pkgPath)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
      const allDeps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };

      if (allDeps.jest || allDeps['@jest/core']) return { framework: 'jest', cmd: 'npx jest --json --no-coverage' };
      if (allDeps.vitest) return { framework: 'vitest', cmd: 'npx vitest run --reporter=json' };
      if (allDeps.mocha) return { framework: 'mocha', cmd: 'npx mocha --reporter json' };
      if (pkg.scripts && pkg.scripts.test && pkg.scripts.test !== 'echo "Error: no test specified" && exit 1') {
        return { framework: 'npm-script', cmd: 'npm test' };
      }
    } catch { /* ignore */ }
  }

  if (fs.existsSync(path.join(cwd, 'Cargo.toml'))) return { framework: 'cargo', cmd: 'cargo test 2>&1' };
  if (fs.existsSync(path.join(cwd, 'go.mod'))) return { framework: 'go', cmd: 'go test -v ./... 2>&1' };

  // Python test detection
  for (const f of ['pytest.ini', 'setup.cfg', 'pyproject.toml', 'tox.ini']) {
    if (fs.existsSync(path.join(cwd, f))) {
      return { framework: 'pytest', cmd: 'python3 -m pytest -q --tb=short 2>&1' };
    }
  }
  if (fs.existsSync(path.join(cwd, 'tests')) || fs.existsSync(path.join(cwd, 'test'))) {
    return { framework: 'pytest', cmd: 'python3 -m pytest -q --tb=short 2>&1' };
  }

  return null;
}

// ─── Result Parsers ────────────────────────────────────────────────────────

function _parseJestJson(output) {
  try {
    // Jest --json outputs a single JSON line (may have preceding text)
    const jsonStart = output.indexOf('{');
    if (jsonStart === -1) return null;
    const json = JSON.parse(output.slice(jsonStart));
    const failures = [];
    for (const suite of (json.testResults || [])) {
      for (const test of suite.assertionResults.filter(t => t.status === 'failed')) {
        failures.push({
          testName: test.fullName || test.title,
          file: path.relative(process.cwd(), suite.name),
          message: (test.failureMessages || []).join('\n').slice(0, 500),
        });
      }
    }
    return {
      passed: json.numPassedTests || 0,
      failed: json.numFailedTests || 0,
      skipped: json.numPendingTests || 0,
      total: json.numTotalTests || 0,
      failures,
    };
  } catch { return null; }
}

function _parseGenericOutput(output) {
  const lines = output.split('\n');
  let passed = 0, failed = 0, skipped = 0;
  const failures = [];

  for (const line of lines) {
    // pytest summary: "X passed, Y failed, Z skipped"
    const pytestMatch = line.match(/(\d+)\s+passed/);
    if (pytestMatch) passed = parseInt(pytestMatch[1], 10);
    const pytestFailed = line.match(/(\d+)\s+failed/);
    if (pytestFailed) failed = parseInt(pytestFailed[1], 10);
    const pytestSkipped = line.match(/(\d+)\s+skipped/);
    if (pytestSkipped) skipped = parseInt(pytestSkipped[1], 10);

    // cargo test: "test result: ok. X passed; Y failed; Z ignored"
    const cargoMatch = line.match(/test result:.*?(\d+)\s+passed.*?(\d+)\s+failed.*?(\d+)\s+ignored/);
    if (cargoMatch) { passed = parseInt(cargoMatch[1], 10); failed = parseInt(cargoMatch[2], 10); skipped = parseInt(cargoMatch[3], 10); }

    // go test: "ok"/"FAIL" per package, "--- FAIL: TestName"
    const goFail = line.match(/--- FAIL:\s+(\S+)/);
    if (goFail) { failures.push({ testName: goFail[1], file: '', message: '' }); }
    if (line.startsWith('ok ')) passed++;
    if (line.startsWith('FAIL\t')) failed++;

    // Generic FAIL/PASS patterns
    if (line.includes('FAILED') && line.includes('::')) {
      failures.push({ testName: line.trim(), file: '', message: '' });
    }
  }

  return { passed, failed, skipped, total: passed + failed + skipped, failures };
}

// ─── Tool Definition ───────────────────────────────────────────────────────

module.exports = defineTool({
  name: 'run_tests',
  description: 'Detect test framework and run tests, returning structured pass/fail/skip counts and failure details. Supports Jest, Vitest, Mocha, pytest, cargo test, go test.',
  category: 'execution',
  risk: 'medium',
  isReadOnly: false,
  isConcurrencySafe: false,

  inputSchema: {
    cwd: { type: 'string', required: false, description: 'Project directory' },
    command: { type: 'string', required: false, description: 'Override test command' },
    filter: { type: 'string', required: false, description: 'Test name/pattern filter' },
    timeout: { type: 'number', required: false, description: 'Timeout in ms (default 120000)' },
  },

  getActivityDescription(input) {
    return `Running tests${input?.cwd ? ' in ' + input.cwd : ''}`;
  },

  async execute(params) {
    const cwd = params.cwd || process.cwd();
    const timeout = params.timeout || 120000;
    const startMs = Date.now();

    const detected = _detectTestFramework(cwd);
    let command = params.command || (detected ? detected.cmd : null);
    const framework = detected ? detected.framework : 'unknown';

    if (!command) {
      return { success: false, error: `No test framework detected in ${cwd}. Provide a command.` };
    }

    // Append filter if provided
    if (params.filter && !params.command) {
      if (framework === 'jest' || framework === 'vitest') command += ` -t "${params.filter}"`;
      else if (framework === 'pytest') command += ` -k "${params.filter}"`;
      else if (framework === 'cargo') command += ` ${params.filter}`;
      else if (framework === 'go') command += ` -run "${params.filter}"`;
    }

    let output = '', exitCode = 0;
    try {
      output = execSync(command, {
        cwd, timeout, encoding: 'utf-8',
        stdio: ['pipe', 'pipe', 'pipe'],
        maxBuffer: 10 * 1024 * 1024,
        env: { ...process.env, FORCE_COLOR: '0', NO_COLOR: '1', CI: '1' },
      });
    } catch (err) {
      exitCode = err.status || 1;
      output = (err.stdout || '') + '\n' + (err.stderr || '');
    }

    // Parse results
    let parsed = null;
    if (framework === 'jest' || framework === 'vitest') {
      parsed = _parseJestJson(output);
    }
    if (!parsed) {
      parsed = _parseGenericOutput(output);
    }

    return {
      success: exitCode === 0 && parsed.failed === 0,
      data: {
        framework,
        command,
        exitCode,
        passed: parsed.passed,
        failed: parsed.failed,
        skipped: parsed.skipped,
        total: parsed.total,
        failures: parsed.failures.slice(0, 20),
        durationMs: Date.now() - startMs,
        outputTail: output.split('\n').slice(-30).join('\n').slice(0, 3000),
      },
    };
  },
});
