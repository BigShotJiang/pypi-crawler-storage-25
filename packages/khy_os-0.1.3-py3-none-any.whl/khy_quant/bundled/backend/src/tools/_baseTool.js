/**
 * Base Tool — standardized tool definition interface with parameter validation.
 *
 * Each tool file in backend/src/tools/ exports a frozen tool definition created
 * via defineTool(). The registry (index.js) auto-discovers and registers them.
 *
 * Tool interface:
 *   { name, description, category, risk, inputSchema, execute }
 *
 * InputSchema is a plain object describing parameters with validation rules:
 *   { symbol: { type: 'string', required: true, maxLength: 20 } }
 *
 * Additionally, tools can be defined as ES-class subclasses of BaseTool:
 *
 *   class MyTool extends BaseTool {
 *     static toolName = 'MyTool';
 *     prompt() { return 'description'; }
 *     get inputSchema() { return { type: 'object', properties: { ... } }; }
 *     async execute(params, context) { ... }
 *   }
 *
 * No external validation library (Zod, Joi) — pure JS implementation.
 */

// ── Constants ───────────────────────────────────────────────────────

const RISK_LEVELS = ['safe', 'low', 'medium', 'high', 'critical'];

const CATEGORIES = {
  data: 'Data retrieval & market information',
  analysis: 'Quantitative analysis & backtesting',
  execution: 'Code execution & shell commands',
  filesystem: 'File read/write operations',
  git: 'Git version control operations',
  system: 'System administration & configuration',
  optimization: 'Configuration optimization & code proposals',
  coordinator: 'Multi-agent coordination & orchestration',
  mcp: 'MCP protocol tools',
  custom: 'User-defined custom tools',
};

// ── Behavioral Defaults (fail-closed) ──────────────────────────────

const BEHAVIOR_DEFAULTS = {
  isReadOnly: false,           // assume writes unless declared otherwise
  isDestructive: false,        // assume non-destructive
  isConcurrencySafe: false,    // assume NOT safe for parallel execution
  isEnabled: () => true,       // always available by default
  interruptBehavior: 'cancel', // 'cancel' or 'block'
};

// ── Extended Field Defaults ────────────────────────────────────────

const EXTENDED_DEFAULTS = {
  aliases: [],                      // alternative names for tool discovery
  searchHint: undefined,            // keyword for deferred tool search
  shouldDefer: false,               // tool can be deferred (not loaded into initial prompt)
  alwaysLoad: false,                // tool is never deferred (overrides shouldDefer)
  maxResultSizeChars: undefined,    // per-tool result size limit (undefined = system default)
};

const VALID_INTERRUPT_BEHAVIORS = ['cancel', 'block'];

// ── isGitRepo helper (10s TTL cache) ───────────────────────────────

let _gitRepoCache = { value: null, expiry: 0 };

/**
 * Check whether the current working directory is inside a git repository.
 * Result is cached for 10 seconds to avoid repeated execSync calls.
 *
 * @returns {boolean}
 */
function isGitRepo() {
  const now = Date.now();
  if (_gitRepoCache.expiry > now) return _gitRepoCache.value;
  try {
    require('child_process').execSync('git rev-parse --is-inside-work-tree', {
      stdio: 'ignore',
      timeout: 3000,
    });
    _gitRepoCache = { value: true, expiry: now + 10000 };
    return true;
  } catch {
    _gitRepoCache = { value: false, expiry: now + 10000 };
    return false;
  }
}

// ── Parameter Validation ────────────────────────────────────────────

/**
 * Validate parameters against a schema definition.
 *
 * @param {object} schema - Input schema definition
 * @param {object} params - Actual parameters to validate
 * @returns {{ valid: boolean, errors: string[] }}
 *
 * Supported types: string, number, boolean, array, object
 * Supported constraints: required, minLength, maxLength, min, max, enum, pattern, description
 */
function validateParams(schema, params) {
  if (!schema || typeof schema !== 'object') return { valid: true, errors: [] };
  if (!params || typeof params !== 'object') params = {};

  const errors = [];

  for (const [key, rule] of Object.entries(schema)) {
    if (!rule || typeof rule !== 'object') continue;

    const value = params[key];
    const hasValue = value !== undefined && value !== null && value !== '';

    // Required check
    if (rule.required && !hasValue) {
      errors.push(`${key} is required`);
      continue;
    }

    // Skip further checks if no value and not required
    if (!hasValue) continue;

    // Type check
    if (rule.type) {
      const actualType = Array.isArray(value) ? 'array' : typeof value;
      if (actualType !== rule.type) {
        errors.push(`${key} must be of type ${rule.type}, got ${actualType}`);
        continue;
      }
    }

    // String constraints
    if (rule.type === 'string' && typeof value === 'string') {
      if (rule.minLength !== undefined && value.length < rule.minLength) {
        errors.push(`${key} must be at least ${rule.minLength} characters`);
      }
      if (rule.maxLength !== undefined && value.length > rule.maxLength) {
        errors.push(`${key} must be at most ${rule.maxLength} characters`);
      }
      if (rule.pattern) {
        const re = typeof rule.pattern === 'string' ? new RegExp(rule.pattern) : rule.pattern;
        if (!re.test(value)) {
          errors.push(`${key} does not match required pattern`);
        }
      }
    }

    // Number constraints
    if (rule.type === 'number' && typeof value === 'number') {
      if (rule.min !== undefined && value < rule.min) {
        errors.push(`${key} must be >= ${rule.min}`);
      }
      if (rule.max !== undefined && value > rule.max) {
        errors.push(`${key} must be <= ${rule.max}`);
      }
    }

    // Enum check
    if (rule.enum && Array.isArray(rule.enum)) {
      if (!rule.enum.includes(value)) {
        errors.push(`${key} must be one of: ${rule.enum.join(', ')}`);
      }
    }

    // Array constraints
    if (rule.type === 'array' && Array.isArray(value)) {
      if (rule.minLength !== undefined && value.length < rule.minLength) {
        errors.push(`${key} must have at least ${rule.minLength} items`);
      }
      if (rule.maxLength !== undefined && value.length > rule.maxLength) {
        errors.push(`${key} must have at most ${rule.maxLength} items`);
      }
    }
  }

  return { valid: errors.length === 0, errors };
}

// ── Tool Definition Factory ─────────────────────────────────────────

/**
 * Define a tool with standardized interface. Returns a frozen object.
 *
 * @param {object} config
 * @param {string} config.name - Unique tool name (alphanumeric + underscores)
 * @param {string} config.description - Human-readable description
 * @param {string} [config.category='custom'] - Tool category
 * @param {string} [config.risk='medium'] - Risk level
 * @param {object} [config.inputSchema={}] - Parameter schema
 * @param {function} config.execute - async (params, context) => result
 * @returns {object} Frozen tool definition
 */
function defineTool(config) {
  if (!config || typeof config !== 'object') {
    throw new Error('defineTool requires a config object');
  }
  if (!config.name || typeof config.name !== 'string') {
    throw new Error('Tool name is required and must be a string');
  }
  if (!config.execute || typeof config.execute !== 'function') {
    throw new Error(`Tool "${config.name}": execute function is required`);
  }

  const category = config.category || 'custom';
  if (!(category in CATEGORIES)) {
    throw new Error(`Tool "${config.name}": invalid category "${category}". Valid: ${Object.keys(CATEGORIES).join(', ')}`);
  }

  const risk = config.risk || 'medium';
  if (!RISK_LEVELS.includes(risk)) {
    throw new Error(`Tool "${config.name}": invalid risk "${risk}". Valid: ${RISK_LEVELS.join(', ')}`);
  }

  // ── Resolve behavioral declarations ──────────────────────────────
  const interruptBehavior = config.interruptBehavior || BEHAVIOR_DEFAULTS.interruptBehavior;
  if (!VALID_INTERRUPT_BEHAVIORS.includes(interruptBehavior)) {
    throw new Error(`Tool "${config.name}": invalid interruptBehavior "${interruptBehavior}". Valid: ${VALID_INTERRUPT_BEHAVIORS.join(', ')}`);
  }

  // Normalize boolean-or-function fields into callable methods
  const _wrapBehavior = (val, fallback) => {
    if (typeof val === 'function') return val;
    if (typeof val === 'boolean') return () => val;
    return fallback;
  };

  const _isReadOnly = _wrapBehavior(config.isReadOnly, () => BEHAVIOR_DEFAULTS.isReadOnly);
  const _isDestructive = _wrapBehavior(config.isDestructive, () => BEHAVIOR_DEFAULTS.isDestructive);
  const _isConcurrencySafe = _wrapBehavior(config.isConcurrencySafe, () => BEHAVIOR_DEFAULTS.isConcurrencySafe);
  const _isEnabled = typeof config.isEnabled === 'function' ? config.isEnabled : BEHAVIOR_DEFAULTS.isEnabled;

  // ── Resolve extended fields ────────────────────────────────────
  const aliases = Array.isArray(config.aliases) ? config.aliases : EXTENDED_DEFAULTS.aliases;
  const searchHint = config.searchHint || EXTENDED_DEFAULTS.searchHint;
  const shouldDefer = config.shouldDefer || EXTENDED_DEFAULTS.shouldDefer;
  const alwaysLoad = config.alwaysLoad || EXTENDED_DEFAULTS.alwaysLoad;
  const maxResultSizeChars = config.maxResultSizeChars !== undefined
    ? config.maxResultSizeChars
    : EXTENDED_DEFAULTS.maxResultSizeChars;

  // Optional extended methods (undefined = not provided)
  const _prompt = typeof config.prompt === 'function' ? config.prompt : null;
  const _validateInput = typeof config.validateInput === 'function' ? config.validateInput : null;
  const _getActivityDescription = typeof config.getActivityDescription === 'function' ? config.getActivityDescription : null;
  const _getToolUseSummary = typeof config.getToolUseSummary === 'function' ? config.getToolUseSummary : null;

  const tool = {
    name: config.name,
    description: config.description || '',
    category,
    risk,
    inputSchema: config.inputSchema || {},
    execute: config.execute,

    // ── Extended metadata ─────────────────────────────────────────
    aliases,
    searchHint,
    shouldDefer,
    alwaysLoad,
    maxResultSizeChars,

    // ── Behavioral declarations ──────────────────────────────────
    /** @param {object} [input] - Tool params (for dynamic checks) */
    isReadOnly(input) { return _isReadOnly(input); },
    /** @param {object} [input] - Tool params (for dynamic checks) */
    isDestructive(input) { return _isDestructive(input); },
    /** @param {object} [input] - Tool params (for dynamic checks) */
    isConcurrencySafe(input) { return _isConcurrencySafe(input); },
    /** @returns {boolean} Whether the tool is available in the current environment */
    isEnabled() { return _isEnabled(); },
    interruptBehavior,

    // ── Extended methods (optional) ──────────────────────────────
    /**
     * Rich tool description with usage notes/warnings.
     * @returns {Promise<string>}
     */
    async prompt() {
      if (_prompt) return _prompt();
      return this.description;
    },

    /**
     * Pre-execution semantic validation beyond schema checks.
     * @param {object} input - Tool parameters
     * @param {object} [context] - Execution context
     * @returns {Promise<{ valid: boolean, message?: string }>}
     */
    async validateInput(input, context) {
      if (_validateInput) return _validateInput(input, context);
      return { valid: true };
    },

    /**
     * Human-readable description of what this tool call will do.
     * @param {object} input
     * @returns {string|null}
     */
    getActivityDescription(input) {
      if (_getActivityDescription) return _getActivityDescription(input);
      return null;
    },

    /**
     * Brief summary for logs/audit.
     * @param {object} input
     * @returns {string|null}
     */
    getToolUseSummary(input) {
      if (_getToolUseSummary) return _getToolUseSummary(input);
      return null;
    },

    // Convenience: validate params against this tool's schema
    validate(params) {
      return validateParams(this.inputSchema, params);
    },

    // Convert to Claude/OpenAI function-calling format
    toFunctionDef() {
      const properties = {};
      const required = [];

      for (const [key, rule] of Object.entries(this.inputSchema)) {
        const prop = { type: rule.type || 'string' };
        if (rule.description) prop.description = rule.description;
        if (rule.enum) prop.enum = rule.enum;
        properties[key] = prop;
        if (rule.required) required.push(key);
      }

      const def = {
        name: this.name,
        description: this.description,
        parameters: {
          type: 'object',
          properties,
          required: required.length > 0 ? required : undefined,
        },
      };

      if (this.aliases.length > 0) {
        def.aliases = this.aliases;
      }

      return def;
    },
  };

  // Store pending commands if provided (for commandRegistry integration)
  if (Array.isArray(config.commands) && config.commands.length > 0) {
    Object.defineProperty(tool, '_pendingCommands', {
      value: Object.freeze(config.commands),
      enumerable: false,
    });
  }

  return Object.freeze(tool);
}

// ── ToolResult Wrapper ──────────────────────────────────────────────

/**
 * Wrap a tool execution result into the enhanced ToolResult format.
 *
 * Existing tools return flat { success, data/error } objects. This wrapper
 * adds optional newMessages and contextModifier fields for tools that need
 * to inject messages into the conversation or modify execution context.
 *
 * @param {object} output - The tool's raw output (e.g. { success: true, data: ... })
 * @param {object} [extras]
 * @param {Array} [extras.newMessages] - Messages to inject into conversation
 * @param {function} [extras.contextModifier] - Context modification callback
 * @returns {{ data: object, newMessages?: Array, contextModifier?: function }}
 */
function wrapResult(output, extras = {}) {
  const result = { data: output };
  if (extras.newMessages && extras.newMessages.length > 0) {
    result.newMessages = extras.newMessages;
  }
  if (typeof extras.contextModifier === 'function') {
    result.contextModifier = extras.contextModifier;
  }
  return result;
}

// ── BaseTool Class ─────────────────────────────────────────────────
//
// An alternative to the functional defineTool() factory.  Tools can
// subclass BaseTool and provide prompt(), inputSchema, execute(), etc.
// The registry converts them via toToolDef() into the same frozen
// shape used by defineTool().

/**
 * Base class for Claude Code-aligned tool definitions.
 *
 * Subclasses must provide:
 *   - static toolName  — the canonical tool name (e.g. 'Read', 'Edit')
 *   - prompt()         — returns the system prompt description string
 *   - inputSchema      — JSON Schema object (getter or property)
 *   - execute(params, context) — async, runs the tool
 *
 * Optional overrides:
 *   - static category / risk / aliases / searchHint / etc.
 *   - validateInput(params) — semantic pre-exec validation
 *   - getActivityDescription(input) — short progress label
 *   - getToolUseSummary(input) — brief audit label
 */
class BaseTool {
  /* ── Identity (override in subclass) ─────────────────────────────── */

  /** Canonical tool name, e.g. 'Read'. */
  static toolName = 'BaseTool';

  /** Tool category — must be a key in CATEGORIES. */
  static category = 'custom';

  /** Risk level — one of RISK_LEVELS. */
  static risk = 'medium';

  /** Alternative names for tool search / discovery. */
  static aliases = [];

  /** Keyword for deferred tool search. */
  static searchHint = undefined;

  /** Whether this tool should be deferred from initial prompt. */
  static shouldDefer = false;

  /** Whether this tool must always be loaded. */
  static alwaysLoad = false;

  /** Per-tool max result size. undefined = system default. */
  static maxResultSizeChars = undefined;

  /* ── Behavioral declarations ─────────────────────────────────────── */

  /** @returns {boolean} */
  isReadOnly() { return false; }

  /** @param {object} [input] @returns {boolean} */
  isDestructive(_input) { return false; }

  /** @returns {boolean} */
  isConcurrencySafe() { return false; }

  /** @returns {boolean} */
  isEnabled() { return true; }

  /** 'cancel' or 'block' */
  get interruptBehavior() { return 'cancel'; }

  /* ── Core interface ──────────────────────────────────────────────── */

  /**
   * System prompt description for the AI.
   * Override in subclass.
   * @returns {string}
   */
  prompt() {
    return '';
  }

  /**
   * JSON Schema describing the tool's input parameters.
   * Override in subclass (getter or property).
   * @returns {object}
   */
  get inputSchema() {
    return { type: 'object', properties: {}, required: [] };
  }

  /**
   * Validate input beyond schema checks (semantic validation).
   * @param {object} params
   * @returns {Promise<{valid: boolean, message?: string}>}
   */
  async validateInput(_params) {
    return { valid: true };
  }

  /**
   * Execute the tool.
   * @param {object} params - Validated parameters
   * @param {object} context - Execution context
   * @returns {Promise<object>}
   */
  async execute(_params, _context) {
    throw new Error(`${this.constructor.toolName}.execute() not implemented`);
  }

  /* ── Metadata helpers ────────────────────────────────────────────── */

  /**
   * Human-readable description of what this tool call will do.
   * @param {object} input
   * @returns {string|null}
   */
  getActivityDescription(_input) { return null; }

  /**
   * Brief summary for logs/audit.
   * @param {object} input
   * @returns {string|null}
   */
  getToolUseSummary(_input) { return null; }

  /* ── Serialization ───────────────────────────────────────────────── */

  /**
   * Return the Claude/Anthropic API tool schema.
   * @returns {{ name: string, description: string, input_schema: object }}
   */
  toAPISchema() {
    return {
      name: this.constructor.toolName,
      description: this.prompt(),
      input_schema: this.inputSchema,
    };
  }

  /**
   * Convert this class-based tool into a frozen defineTool()-compatible
   * object that the existing registry can consume.
   * @returns {object}
   */
  toToolDef() {
    const Ctor = this.constructor;
    const instance = this;

    // Convert JSON Schema inputSchema to the legacy flat schema format
    // so that validateParams() works.
    const jsonSchema = instance.inputSchema;
    const legacySchema = {};
    if (jsonSchema && jsonSchema.properties) {
      const requiredSet = new Set(jsonSchema.required || []);
      for (const [key, prop] of Object.entries(jsonSchema.properties)) {
        legacySchema[key] = {
          type: prop.type || 'string',
          required: requiredSet.has(key),
          description: prop.description || '',
        };
        if (prop.enum) legacySchema[key].enum = prop.enum;
        if (prop.minLength !== undefined) legacySchema[key].minLength = prop.minLength;
        if (prop.maxLength !== undefined) legacySchema[key].maxLength = prop.maxLength;
        if (prop.minimum !== undefined) legacySchema[key].min = prop.minimum;
        if (prop.maximum !== undefined) legacySchema[key].max = prop.maximum;
        if (prop.default !== undefined) legacySchema[key].default = prop.default;
      }
    }

    return defineTool({
      name: Ctor.toolName,
      description: instance.prompt(),
      category: Ctor.category || 'custom',
      risk: Ctor.risk || 'medium',
      inputSchema: legacySchema,
      execute: (params, ctx) => instance.execute(params, ctx),
      isReadOnly: (input) => instance.isReadOnly(input),
      isDestructive: (input) => instance.isDestructive(input),
      isConcurrencySafe: (input) => instance.isConcurrencySafe(input),
      isEnabled: () => instance.isEnabled(),
      interruptBehavior: instance.interruptBehavior,
      aliases: Ctor.aliases || [],
      searchHint: Ctor.searchHint,
      shouldDefer: Ctor.shouldDefer || false,
      alwaysLoad: Ctor.alwaysLoad || false,
      maxResultSizeChars: Ctor.maxResultSizeChars,
      prompt: () => instance.prompt(),
      validateInput: (input, ctx) => instance.validateInput(input, ctx),
      getActivityDescription: (input) => instance.getActivityDescription(input),
      getToolUseSummary: (input) => instance.getToolUseSummary(input),
    });
  }
}

// ── Exports ─────────────────────────────────────────────────────────

module.exports = {
  defineTool,
  validateParams,
  wrapResult,
  isGitRepo,
  BaseTool,
  RISK_LEVELS,
  CATEGORIES,
  BEHAVIOR_DEFAULTS,
  EXTENDED_DEFAULTS,
};
