/**
 * FileReadTool — structured file reading, aligned with Claude Code's Read tool.
 *
 * Delegates to the existing readFile tool's logic for actual file I/O,
 * but exposes the Claude Code-compatible name, prompt, and input schema.
 */
const { BaseTool } = require('../_baseTool');
const fs = require('fs');
const path = require('path');

const MAX_LINES_TO_READ = 2000;
const MAX_FILE_SIZE = 500 * 1024; // 500 KB

class FileReadTool extends BaseTool {
  static toolName = 'Read';
  static category = 'filesystem';
  static risk = 'low';
  static aliases = ['readFile', 'read_file', 'cat'];
  static searchHint = 'read file contents from filesystem';
  static alwaysLoad = true;
  static maxResultSizeChars = Infinity; // never truncate reads

  isReadOnly() { return true; }
  isConcurrencySafe() { return true; }

  prompt() {
    return `Reads a file from the local filesystem. You can access any file directly by using this tool.
Assume this tool is able to read all files on the machine. If the User provides a path to a file assume that path is valid. It is okay to read a file that does not exist; an error will be returned.

Usage:
- The file_path parameter must be an absolute path, not a relative path
- By default, it reads up to ${MAX_LINES_TO_READ} lines starting from the beginning of the file
- You can optionally specify a line offset and limit (especially handy for long files), but it's recommended to read the whole file by not providing these parameters
- Results are returned using cat -n format, with line numbers starting at 1
- This tool can read Jupyter notebooks (.ipynb files) and returns all cells with their outputs, combining code, text, and visualizations.
- This tool can only read files, not directories. To read a directory, use an ls command via the Bash tool.
- You will regularly be asked to read screenshots. If the user provides a path to a screenshot, ALWAYS use this tool to view the file at the path.
- If you read a file that exists but has empty contents you will receive a system reminder warning in place of file contents.`;
  }

  get inputSchema() {
    return {
      type: 'object',
      properties: {
        file_path: {
          type: 'string',
          description: 'The absolute path to the file to read',
        },
        offset: {
          type: 'number',
          description: 'The line number to start reading from (1-based). Only provide if the file is too large to read at once.',
        },
        limit: {
          type: 'number',
          description: 'The number of lines to read. Only provide if the file is too large to read at once.',
        },
      },
      required: ['file_path'],
    };
  }

  async validateInput(params) {
    try {
      const { validateNotDevicePath, validateNotUNCPath, composeValidations } = require('../inputValidators');
      return composeValidations(
        validateNotDevicePath(params.file_path),
        validateNotUNCPath(params.file_path),
      );
    } catch {
      return { valid: true };
    }
  }

  getActivityDescription(input) {
    return `Reading ${input.file_path || 'file'}`;
  }

  getToolUseSummary(input) {
    if (!input.file_path) return null;
    return `read ${path.basename(input.file_path)}`;
  }

  async execute(params, _context) {
    try {
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      let rawPath = params.file_path;

      // Expand environment variables and tilde
      if (process.platform === 'win32') {
        rawPath = rawPath.replace(/%([^%]+)%/g, (_, key) => process.env[key] || `%${key}%`);
      } else {
        rawPath = rawPath.replace(/\$\{?(\w+)\}?/g, (_, key) => process.env[key] || '');
      }
      if (rawPath.startsWith('~')) {
        rawPath = path.join(require('os').homedir(), rawPath.slice(1));
      }

      const filePath = path.resolve(cwd, rawPath);

      if (!fs.existsSync(filePath)) {
        return { success: false, error: `File not found: ${filePath}` };
      }

      const stat = fs.statSync(filePath);

      if (stat.isDirectory()) {
        return { success: false, error: `Cannot read a directory. Use ls command instead: ${filePath}` };
      }

      if (stat.size > MAX_FILE_SIZE) {
        return {
          success: false,
          error: `File too large: ${stat.size} bytes (max ${MAX_FILE_SIZE}). Use offset/limit parameters or a shell command to read portions.`,
        };
      }

      if (stat.size === 0) {
        return {
          success: true,
          content: '[File exists but is empty]',
          size: 0,
          lines: 0,
        };
      }

      const raw = fs.readFileSync(filePath, 'utf-8');
      const allLines = raw.split('\n');

      // Apply offset/limit
      const offset = params.offset || 1;
      const limit = params.limit || MAX_LINES_TO_READ;
      const start = Math.max(0, offset - 1);
      const end = Math.min(allLines.length, start + limit);
      const sliced = allLines.slice(start, end);

      // Format with line numbers (cat -n style)
      const numbered = sliced.map((line, i) => `${start + i + 1}\t${line}`).join('\n');

      return {
        success: true,
        content: numbered,
        size: stat.size,
        lines: sliced.length,
        totalLines: allLines.length,
      };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }
}

module.exports = new FileReadTool();
module.exports.FileReadTool = FileReadTool;
