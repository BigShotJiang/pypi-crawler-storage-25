/**
 * Grep — content search tool using regular expressions.
 *
 * Searches file contents for a regex pattern, similar to ripgrep.
 * Supports output modes: files_with_matches, content, count.
 *
 * Execution strategy (cross-platform):
 *   1. ripgrep (rg) — fastest, works on Linux/macOS/Windows
 *   2. grep -rnE   — Unix fallback
 *   3. Pure-JS walk — universal fallback (no native binary needed)
 */
const { defineTool } = require('./_baseTool');
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const {
  isRgAvailable,
  isGrepAvailable,
  shellEscape,
  pureJsGrep,
} = require('./platformUtils');

const MAX_OUTPUT = 100 * 1024; // 100 KB
const EXCLUDE_DIRS = ['node_modules', '.git', 'dist', 'build', '.cache', 'coverage', '__pycache__'];

module.exports = defineTool({
  name: 'grep',
  description:
    'Search file contents for a regex pattern.  Returns matching lines or file paths.  ' +
    'Supports regex syntax (e.g. "function\\s+\\w+").  ' +
    'Use output_mode "files_with_matches" to get file paths only, "content" for matching lines with line numbers, "count" for match counts.',
  category: 'filesystem',
  risk: 'safe',
  isReadOnly: true,
  isConcurrencySafe: true,

  aliases: ['search_content', 'rg'],
  searchHint: 'search grep regex content files',

  inputSchema: {
    pattern: {
      type: 'string',
      required: true,
      description: 'Regular expression pattern to search for',
    },
    path: {
      type: 'string',
      required: false,
      description: 'File or directory to search in (default: CWD)',
    },
    glob: {
      type: 'string',
      required: false,
      description: 'File glob filter (e.g. "*.js", "*.{ts,tsx}")',
    },
    output_mode: {
      type: 'string',
      required: false,
      description: 'Output mode: "files_with_matches" (default), "content", or "count"',
    },
    max_results: {
      type: 'number',
      required: false,
      description: 'Maximum number of results (default: 50)',
    },
    case_insensitive: {
      type: 'boolean',
      required: false,
      description: 'Case insensitive search (default: false)',
    },
  },

  getActivityDescription(input) {
    return `Searching for "${(input.pattern || '').slice(0, 40)}"`;
  },

  async execute(params) {
    const cwd = process.env.KHYQUANT_CWD || process.cwd();
    const searchPath = params.path ? path.resolve(cwd, params.path) : cwd;
    const mode = params.output_mode || 'files_with_matches';
    const maxResults = params.max_results || 50;

    if (!fs.existsSync(searchPath)) {
      return { success: false, error: `Path not found: ${searchPath}` };
    }

    // Strategy 1: ripgrep (best, cross-platform)
    if (isRgAvailable()) {
      return _execRg(params, searchPath, cwd, mode, maxResults);
    }

    // Strategy 2: Unix grep
    if (isGrepAvailable()) {
      return _execGrep(params, searchPath, cwd, mode, maxResults);
    }

    // Strategy 3: Pure-JS fallback (Windows without rg, or bare environments)
    return _execPureJs(params, searchPath, cwd, mode, maxResults);
  },
});

// ── ripgrep execution ───────────────────────────────────────────────

function _execRg(params, searchPath, cwd, mode, maxResults) {
  const args = ['--no-heading', '--line-number', '--color=never'];
  if (params.case_insensitive) args.push('-i');

  if (mode === 'files_with_matches') {
    args.push('-l');
  } else if (mode === 'count') {
    args.push('-c');
  }

  if (params.glob) {
    args.push('-g', params.glob);
  }

  for (const skip of EXCLUDE_DIRS) {
    args.push('-g', `!${skip}`);
  }

  args.push('--max-count', String(maxResults * 10)); // over-fetch for safety
  const escaped = shellEscape(params.pattern);
  const cmd = `rg ${args.join(' ')} ${escaped} ${shellEscape(searchPath)}`;

  return _runAndParse(cmd, cwd, mode, maxResults, searchPath);
}

// ── Unix grep execution ─────────────────────────────────────────────

function _execGrep(params, searchPath, cwd, mode, maxResults) {
  const args = ['-rn'];
  if (params.case_insensitive) args.push('-i');

  if (mode === 'files_with_matches') {
    args.push('-l');
  } else if (mode === 'count') {
    args.push('-c');
  }

  args.push('-E');

  if (params.glob) {
    args.push(`--include=${params.glob}`);
  }

  for (const skip of EXCLUDE_DIRS) {
    args.push(`--exclude-dir=${skip}`);
  }

  const escaped = shellEscape(params.pattern);
  const cmd = `grep ${args.join(' ')} ${escaped} ${searchPath}`;

  return _runAndParse(cmd, cwd, mode, maxResults, searchPath);
}

// ── Common output parser ────────────────────────────────────────────

function _runAndParse(cmd, cwd, mode, maxResults, searchPath) {
  try {
    let output = execSync(cmd, {
      cwd,
      encoding: 'utf-8',
      maxBuffer: MAX_OUTPUT,
      timeout: 15000,
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    if (!output || !output.trim()) {
      return { success: true, matches: [], count: 0, message: 'No matches found' };
    }

    const lines = output.trim().split('\n');

    if (mode === 'files_with_matches') {
      const files = lines.slice(0, maxResults).map(f => path.relative(cwd, f.trim()));
      return { success: true, files, count: files.length, truncated: lines.length > maxResults };
    }

    if (mode === 'count') {
      const counts = [];
      for (const line of lines.slice(0, maxResults)) {
        const sep = line.lastIndexOf(':');
        if (sep > 0) {
          const file = path.relative(cwd, line.slice(0, sep));
          const count = parseInt(line.slice(sep + 1), 10);
          if (count > 0) counts.push({ file, count });
        }
      }
      return { success: true, counts, total: counts.reduce((s, c) => s + c.count, 0) };
    }

    // mode === 'content'
    const matches = lines.slice(0, maxResults).map(line => {
      const firstColon = line.indexOf(':');
      const secondColon = line.indexOf(':', firstColon + 1);
      if (firstColon > 0 && secondColon > 0) {
        return {
          file: path.relative(cwd, line.slice(0, firstColon)),
          line: parseInt(line.slice(firstColon + 1, secondColon), 10),
          content: line.slice(secondColon + 1),
        };
      }
      return { raw: line };
    });

    return { success: true, matches, count: matches.length, truncated: lines.length > maxResults };
  } catch (err) {
    // grep/rg exit code 1 = no matches
    if (err.status === 1) {
      return { success: true, matches: [], count: 0, message: 'No matches found' };
    }
    return { success: false, error: err.message };
  }
}

// ── Pure-JS fallback ────────────────────────────────────────────────

function _execPureJs(params, searchPath, cwd, mode, maxResults) {
  try {
    const flags = params.case_insensitive ? 'i' : '';
    const regex = new RegExp(params.pattern, flags);

    const result = pureJsGrep(searchPath, regex, {
      mode,
      glob: params.glob,
      maxResults,
      excludeDirs: EXCLUDE_DIRS,
    });

    if (mode === 'files_with_matches') {
      const files = result.files.map(f => path.relative(cwd, f));
      return { success: true, files, count: files.length, truncated: result.truncated };
    }

    if (mode === 'count') {
      const counts = (result.counts || []).map(c => ({
        file: path.relative(cwd, c.file),
        count: c.count,
      }));
      return { success: true, counts, total: result.total || 0 };
    }

    // mode === 'content'
    const matches = (result.matches || []).map(m => ({
      file: path.relative(cwd, m.file),
      line: m.line,
      content: m.content,
    }));
    return { success: true, matches, count: matches.length, truncated: result.truncated };
  } catch (err) {
    return { success: false, error: `Pure-JS grep error: ${err.message}` };
  }
}
