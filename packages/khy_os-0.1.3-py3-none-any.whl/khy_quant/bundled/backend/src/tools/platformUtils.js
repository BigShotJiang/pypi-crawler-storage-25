/**
 * platformUtils — cross-platform helpers for tool execution.
 *
 * Consolidates platform-specific logic (DISPLAY detection, executable lookup,
 * shell escaping, grep availability) so individual tools stay platform-agnostic.
 */
const { execFileSync, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

// ── Executable lookup ────────────────────────────────────────────────

let _rgAvailable = null;
let _grepAvailable = null;

/**
 * Cross-platform `which` / `where`.
 * Returns the resolved path on success, null on failure.
 */
function searchExecutable(name) {
  const isWin = process.platform === 'win32';
  try {
    const cmd = isWin ? 'where' : 'which';
    return execFileSync(cmd, [name], {
      encoding: 'utf-8',
      timeout: 3000,
      stdio: ['pipe', 'pipe', 'ignore'],
    }).split(/\r?\n/)[0].trim() || null;
  } catch {
    return null;
  }
}

function isRgAvailable() {
  if (_rgAvailable === null) _rgAvailable = !!searchExecutable('rg');
  return _rgAvailable;
}

function isGrepAvailable() {
  if (_grepAvailable === null) _grepAvailable = !!searchExecutable('grep');
  return _grepAvailable;
}

// ── DISPLAY detection (Linux / X11) ─────────────────────────────────

/**
 * Auto-detect DISPLAY for X11 sessions on Linux.
 * Returns the DISPLAY string (e.g. ':0') or null.
 */
function getDisplay() {
  if (process.env.DISPLAY) return process.env.DISPLAY;
  if (process.platform !== 'linux') return null;
  // Check for X11 unix socket
  try {
    if (fs.existsSync('/tmp/.X11-unix/X0')) return ':0';
  } catch { /* ignore */ }
  // Check for Wayland
  if (process.env.WAYLAND_DISPLAY) return null; // Wayland doesn't use DISPLAY
  return null;
}

/**
 * Build environment suitable for spawning GUI applications.
 * Ensures DISPLAY is set on Linux if an X session is available.
 */
function buildGuiEnv(baseEnv) {
  const env = { ...(baseEnv || process.env) };
  if (process.platform === 'linux' && !env.DISPLAY) {
    const display = getDisplay();
    if (display) env.DISPLAY = display;
  }
  return env;
}

// ── Shell escaping ──────────────────────────────────────────────────

/**
 * Platform-aware shell argument escaping.
 * - Unix: single-quote wrapping
 * - Windows: double-quote wrapping
 */
function shellEscape(arg) {
  if (!arg) return "''";
  // Safe chars that need no quoting on any platform
  if (/^[a-zA-Z0-9._\-/\\:=@]+$/.test(arg)) return arg;
  if (process.platform === 'win32') {
    // cmd.exe double-quote escaping
    return '"' + arg.replace(/"/g, '\\"') + '"';
  }
  // POSIX single-quote escaping
  return "'" + arg.replace(/'/g, "'\\''") + "'";
}

// ── GUI app detection ───────────────────────────────────────────────

const LINUX_GUI_APPS = new Set([
  'firefox', 'chromium', 'chrome', 'google-chrome', 'google-chrome-stable',
  'code', 'vscode', 'cursor', 'gedit', 'nautilus', 'thunar', 'dolphin',
  'evince', 'eog', 'vlc', 'mpv', 'gimp', 'inkscape', 'libreoffice',
  'xdg-open', 'wps', 'typora', 'okular', 'kate', 'mousepad',
  'obs', 'blender', 'kdenlive', 'krita', 'shotcut',
]);

const WINDOWS_GUI_APPS = new Set([
  'notepad', 'calc', 'mspaint', 'explorer', 'msedge', 'chrome',
  'firefox', 'code', 'cursor', 'winword', 'excel', 'powerpnt',
  'outlook', 'teams', 'slack', 'discord', 'spotify', 'vlc',
  'mstsc', 'control', 'taskmgr', 'regedit', 'devenv',
]);

/**
 * Check if a command base name is a known GUI application.
 */
function isGuiApp(baseName) {
  const name = String(baseName).toLowerCase().replace(/\.exe$/, '');
  if (process.platform === 'win32') return WINDOWS_GUI_APPS.has(name);
  return LINUX_GUI_APPS.has(name);
}

/**
 * Spawn a GUI application in detached mode, cross-platform.
 * Returns the spawned ChildProcess (already unref'd).
 */
function spawnGuiApp(command, args = [], options = {}) {
  const { spawn } = require('child_process');
  const isWin = process.platform === 'win32';
  const env = buildGuiEnv(options.env);

  let child;
  if (isWin) {
    // Windows: use 'start' via cmd.exe for proper detach
    child = spawn('cmd', ['/c', 'start', '', command, ...args], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
      env,
      ...(options.cwd ? { cwd: options.cwd } : {}),
    });
  } else {
    child = spawn(command, args, {
      detached: true,
      stdio: 'ignore',
      env,
      ...(options.cwd ? { cwd: options.cwd } : {}),
    });
  }
  child.unref();
  return child;
}

// ── Pure-JS grep fallback ───────────────────────────────────────────

/**
 * Pure-JS grep implementation for platforms without grep/rg.
 * Walks directories recursively and matches file contents against a RegExp.
 *
 * @param {string} searchPath - Directory or file to search
 * @param {RegExp} regex - Pattern to match
 * @param {object} opts
 * @param {string} opts.mode - 'files_with_matches' | 'content' | 'count'
 * @param {string} [opts.glob] - Glob filter (e.g. '*.js')
 * @param {number} [opts.maxResults=50]
 * @param {string[]} [opts.excludeDirs] - Directories to skip
 * @returns {{ files?: string[], matches?: object[], counts?: object[], count?: number, total?: number }}
 */
function pureJsGrep(searchPath, regex, opts = {}) {
  const {
    mode = 'files_with_matches',
    glob: globPattern,
    maxResults = 50,
    excludeDirs = ['node_modules', '.git', 'dist', 'build', '.cache', 'coverage', '__pycache__'],
  } = opts;

  const excludeSet = new Set(excludeDirs);
  const results = { files: [], matches: [], counts: [] };
  let totalCount = 0;
  let resultCount = 0;

  // Simple glob-to-regex conversion for --include filter
  let includeRe = null;
  if (globPattern) {
    const escaped = globPattern
      .replace(/[.+^${}()|[\]\\]/g, '\\$&')
      .replace(/\*/g, '.*')
      .replace(/\?/g, '.');
    includeRe = new RegExp('^' + escaped + '$', 'i');
  }

  function shouldInclude(filePath) {
    if (!includeRe) return true;
    return includeRe.test(path.basename(filePath));
  }

  function walkDir(dir) {
    if (resultCount >= maxResults) return;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }

    for (const entry of entries) {
      if (resultCount >= maxResults) break;
      const fullPath = path.join(dir, entry.name);

      if (entry.isDirectory()) {
        if (!excludeSet.has(entry.name)) walkDir(fullPath);
        continue;
      }

      if (!entry.isFile() || !shouldInclude(fullPath)) continue;

      // Read file and match
      let content;
      try { content = fs.readFileSync(fullPath, 'utf-8'); } catch { continue; }

      // Skip binary-looking files
      if (content.includes('\0')) continue;

      const lines = content.split('\n');
      let fileMatchCount = 0;
      const fileMatches = [];

      for (let i = 0; i < lines.length; i++) {
        if (regex.test(lines[i])) {
          fileMatchCount++;
          if (mode === 'content' && resultCount + fileMatches.length < maxResults) {
            fileMatches.push({ file: fullPath, line: i + 1, content: lines[i] });
          }
        }
      }

      if (fileMatchCount > 0) {
        if (mode === 'files_with_matches') {
          results.files.push(fullPath);
          resultCount++;
        } else if (mode === 'content') {
          results.matches.push(...fileMatches);
          resultCount += fileMatches.length;
        } else if (mode === 'count') {
          results.counts.push({ file: fullPath, count: fileMatchCount });
          totalCount += fileMatchCount;
          resultCount++;
        }
      }
    }
  }

  const stat = fs.statSync(searchPath);
  if (stat.isFile()) {
    // Single file search
    let content;
    try { content = fs.readFileSync(searchPath, 'utf-8'); } catch { return results; }
    const lines = content.split('\n');
    let fileMatchCount = 0;
    for (let i = 0; i < lines.length; i++) {
      if (regex.test(lines[i])) {
        fileMatchCount++;
        if (mode === 'content' && results.matches.length < maxResults) {
          results.matches.push({ file: searchPath, line: i + 1, content: lines[i] });
        }
      }
    }
    if (fileMatchCount > 0) {
      results.files.push(searchPath);
      results.counts.push({ file: searchPath, count: fileMatchCount });
      totalCount = fileMatchCount;
    }
  } else {
    walkDir(searchPath);
  }

  results.count = mode === 'files_with_matches' ? results.files.length : resultCount;
  results.total = totalCount;
  results.truncated = resultCount >= maxResults;
  return results;
}

// ── Temp directory ──────────────────────────────────────────────────

function getTmpDir() {
  return process.env.TEMP || process.env.TMP || os.tmpdir();
}

// ── Platform constants ─────────────────────────────────────────────

const isWin = process.platform === 'win32';
const NULL_DEVICE = isWin ? 'NUL' : '/dev/null';
const HOME_DIR = os.homedir();

// ── Platform shell ─────────────────────────────────────────────────

/**
 * Return { cmd, args } for running a shell command string.
 * Unix: sh -c "command"
 * Windows: cmd /c "command"
 */
function platformShell(command) {
  if (isWin) return { cmd: 'cmd', args: ['/c', command] };
  return { cmd: 'sh', args: ['-c', command] };
}

/**
 * Return the default interactive shell path.
 */
function defaultShell() {
  if (isWin) return process.env.COMSPEC || 'cmd.exe';
  return process.env.SHELL || '/bin/sh';
}

// ── Process management ─────────────────────────────────────────────

/**
 * Kill a child process tree, cross-platform.
 * On Unix: kill the process group if possible, else just the child.
 * On Windows: use taskkill /T /F /PID.
 */
function safeKill(childOrPid, signal = 'SIGTERM') {
  const pid = typeof childOrPid === 'number' ? childOrPid : childOrPid?.pid;
  if (!pid) return;

  if (isWin) {
    // taskkill /T terminates the process tree
    try {
      require('child_process').execSync(`taskkill /T /F /PID ${pid}`, {
        stdio: 'ignore', timeout: 5000, windowsHide: true,
      });
    } catch {
      // Process may have already exited
      try {
        if (typeof childOrPid === 'object' && typeof childOrPid.kill === 'function') {
          childOrPid.kill();
        } else {
          process.kill(pid);
        }
      } catch { /* already dead */ }
    }
    return;
  }

  // Unix: try process group kill first
  try {
    process.kill(-pid, signal);
  } catch {
    try {
      if (typeof childOrPid === 'object' && typeof childOrPid.kill === 'function') {
        childOrPid.kill(signal);
      } else {
        process.kill(pid, signal);
      }
    } catch { /* already dead */ }
  }
}

/**
 * Send a signal to a child process, cross-platform.
 * On Windows SIGTERM/SIGKILL just terminate the process (Node built-in).
 * This is for single process, not tree kill.
 */
function safeSignal(childOrPid, signal = 'SIGTERM') {
  const pid = typeof childOrPid === 'number' ? childOrPid : childOrPid?.pid;
  if (!pid) return;
  try {
    if (typeof childOrPid === 'object' && typeof childOrPid.kill === 'function') {
      childOrPid.kill(signal);
    } else {
      process.kill(pid, signal);
    }
  } catch { /* already dead */ }
}

// ── Symlink / junction ─────────────────────────────────────────────

/**
 * Create a symlink; on Windows fall back to junction (no admin needed)
 * for directories, or hard link for files if symlink fails.
 */
function safeMklink(target, linkPath) {
  const resolved = path.resolve(target);
  try {
    // Try native symlink first
    const isDir = fs.statSync(resolved).isDirectory();
    fs.symlinkSync(resolved, linkPath, isDir ? 'junction' : 'file');
  } catch (e1) {
    if (!isWin) throw e1;
    // Windows fallback: junction for dirs, copy for files
    try {
      if (fs.statSync(resolved).isDirectory()) {
        fs.symlinkSync(resolved, linkPath, 'junction');
      } else {
        fs.copyFileSync(resolved, linkPath);
      }
    } catch (e2) {
      throw new Error(`Failed to create link ${linkPath} → ${target}: ${e2.message}`);
    }
  }
}

// ── chmod wrapper ──────────────────────────────────────────────────

/**
 * Set file permissions; silently ignored on Windows where chmod is
 * ineffective on NTFS.
 */
function safeChmod(filePath, mode) {
  if (isWin) return;
  try {
    fs.chmodSync(filePath, mode);
  } catch { /* non-fatal */ }
}

// ── Open URL / file in default application ─────────────────────────

/**
 * Open a URL or file with the platform default handler.
 * Returns the spawned ChildProcess (detached+unref'd).
 */
function openDefault(target) {
  const { spawn } = require('child_process');
  let child;
  if (isWin) {
    child = spawn('cmd', ['/c', 'start', '', target], {
      detached: true, stdio: 'ignore', windowsHide: true,
    });
  } else if (process.platform === 'darwin') {
    child = spawn('open', [target], { detached: true, stdio: 'ignore' });
  } else {
    // Linux: xdg-open → sensible-browser → fallback
    const opener = searchExecutable('xdg-open') ? 'xdg-open'
      : searchExecutable('sensible-browser') ? 'sensible-browser'
      : 'xdg-open';
    child = spawn(opener, [target], {
      detached: true, stdio: 'ignore', env: buildGuiEnv(),
    });
  }
  child.unref();
  return child;
}

// ── Docker / container detection ───────────────────────────────────

/**
 * Detect if running inside a Docker/container environment.
 */
function isContainer() {
  if (isWin) return false;
  try {
    if (fs.existsSync('/.dockerenv')) return true;
    const cgroup = fs.readFileSync('/proc/1/cgroup', 'utf8');
    return cgroup.includes('docker') || cgroup.includes('kubepods') || cgroup.includes('containerd');
  } catch {
    return false;
  }
}

// ── Exports ─────────────────────────────────────────────────────────

module.exports = {
  // Platform constants
  isWin,
  NULL_DEVICE,
  HOME_DIR,
  // Executable lookup
  searchExecutable,
  isRgAvailable,
  isGrepAvailable,
  // GUI / display
  getDisplay,
  buildGuiEnv,
  isGuiApp,
  spawnGuiApp,
  openDefault,
  // Shell
  shellEscape,
  platformShell,
  defaultShell,
  // Process management
  safeKill,
  safeSignal,
  // Filesystem
  safeMklink,
  safeChmod,
  getTmpDir,
  // Search
  pureJsGrep,
  // Environment
  isContainer,
  // Sets
  LINUX_GUI_APPS,
  WINDOWS_GUI_APPS,
};
