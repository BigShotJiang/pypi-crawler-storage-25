const { BaseTool } = require('../_baseTool');

class LSPTool extends BaseTool {
  static toolName = 'LSP';
  static category = 'analysis';
  static risk = 'safe';
  static aliases = ['lsp', 'language_server'];
  static searchHint = 'language server protocol symbols definitions references';
  static shouldDefer = true;

  isReadOnly() { return true; }
  isConcurrencySafe() { return true; }

  prompt() {
    return `Query language server for code intelligence.
Provides symbol definitions, references, hover information, and diagnostics.
Requires a compatible language server to be available.`;
  }

  get inputSchema() {
    return {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          description: 'LSP action to perform',
          enum: ['definition', 'references', 'hover', 'symbols', 'diagnostics', 'completion'],
        },
        file_path: { type: 'string', description: 'Path to the source file' },
        line: { type: 'number', description: 'Line number (0-based)' },
        character: { type: 'number', description: 'Character offset (0-based)' },
        query: { type: 'string', description: 'Symbol name to search for (for symbols action)' },
      },
      required: ['action', 'file_path'],
    };
  }

  async execute(params) {
    // LSP is best-effort — if no server is available, return gracefully
    return {
      success: false,
      note: 'LSP server not connected. Use grep/glob for code navigation, or configure a language server.',
      action: params.action,
      file: params.file_path,
    };
  }

  getActivityDescription(input) { return `LSP ${input.action}: ${input.file_path}`; }
}

module.exports = LSPTool;
