/**
 * Shared in-memory task store for TaskCreate, TaskUpdate, and TaskList tools.
 *
 * Tasks are session-scoped — they live only as long as the process.
 * Provides a simple Map-based store with add/get/update/list operations.
 */

const _tasks = new Map(); // id -> task

/**
 * Add a task to the store.
 * @param {object} task - Must have an `id` property.
 */
function add(task) {
  if (!task || !task.id) throw new Error('Task must have an id');
  _tasks.set(task.id, { ...task });
}

/**
 * Get a task by ID.
 * @param {string} id
 * @returns {object|undefined}
 */
function get(id) {
  return _tasks.get(id);
}

/**
 * Update a task by ID (shallow merge).
 * @param {string} id
 * @param {object} updates
 * @returns {object|null} Updated task or null if not found.
 */
function update(id, updates) {
  const task = _tasks.get(id);
  if (!task) return null;
  const updated = { ...task, ...updates, updatedAt: new Date().toISOString() };
  _tasks.set(id, updated);
  return updated;
}

/**
 * List all tasks, optionally filtered by status.
 * @param {string} [statusFilter] - Optional status to filter by.
 * @returns {object[]}
 */
function list(statusFilter) {
  const all = [..._tasks.values()];
  if (statusFilter) {
    return all.filter(t => t.status === statusFilter);
  }
  return all;
}

/**
 * Remove a task by ID.
 * @param {string} id
 * @returns {boolean}
 */
function remove(id) {
  return _tasks.delete(id);
}

/**
 * Clear all tasks.
 */
function clear() {
  _tasks.clear();
}

/**
 * Get task count.
 * @returns {number}
 */
function count() {
  return _tasks.size;
}

module.exports = { add, get, update, list, remove, clear, count };
