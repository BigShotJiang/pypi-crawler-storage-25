/**
 * GlobTool — fast file pattern matching, aligned with Claude Code's Glob tool.
 *
 * Finds files matching a glob pattern. Results sorted by modification time.
 * Uses pure-JS recursive directory walking with glob-to-regex conversion.
 */
const { BaseTool } = require('../_baseTool');
const fs = require('fs');
const path = require('path');

const MAX_RESULTS = 200;
const MAX_DEPTH = 15;

// Skip directories that are never useful to search
const SKIP_DIRS = new Set([
  'node_modules', '.git', '.hg', '.svn', 'dist', 'build', '.cache',
  '__pycache__', '.tox', '.mypy_cache', '.pytest_cache', 'coverage',
  '.next', '.nuxt', '.output', 'vendor',
]);

/**
 * Simple glob-to-regex converter (covers *, **, ?, {a,b}, [abc]).
 */
function globToRegex(pattern) {
  let re = '';
  let i = 0;
  while (i < pattern.length) {
    const c = pattern[i];
    if (c === '*') {
      if (pattern[i + 1] === '*') {
        re += '.*';
        i += 2;
        if (pattern[i] === '/') i++;
        continue;
      }
      re += '[^/]*';
    } else if (c === '?') {
      re += '[^/]';
    } else if (c === '{') {
      const end = pattern.indexOf('}', i);
      if (end !== -1) {
        const alts = pattern.slice(i + 1, end).split(',').map(a => a.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
        re += '(?:' + alts.join('|') + ')';
        i = end;
      } else {
        re += '\\{';
      }
    } else if (c === '[') {
      const end = pattern.indexOf(']', i);
      if (end !== -1) {
        re += pattern.slice(i, end + 1);
        i = end;
      } else {
        re += '\\[';
      }
    } else if ('.+^$|()\\'.includes(c)) {
      re += '\\' + c;
    } else {
      re += c;
    }
    i++;
  }
  return new RegExp('^' + re + '$');
}

function walkDir(dir, baseDir, regex, results, depth) {
  if (depth > MAX_DEPTH || results.length >= MAX_RESULTS) return;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }

  for (const entry of entries) {
    if (results.length >= MAX_RESULTS) break;
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(baseDir, fullPath);

    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name) || entry.name.startsWith('.')) continue;
      walkDir(fullPath, baseDir, regex, results, depth + 1);
    } else if (entry.isFile()) {
      if (regex.test(relPath)) {
        let mtime = 0;
        try { mtime = fs.statSync(fullPath).mtimeMs; } catch { /* skip */ }
        results.push({ path: relPath, mtime });
      }
    }
  }
}

class GlobTool extends BaseTool {
  static toolName = 'Glob';
  static category = 'filesystem';
  static risk = 'safe';
  static aliases = ['glob', 'find_files', 'find'];
  static searchHint = 'find files by name pattern glob';
  static alwaysLoad = true;

  isReadOnly() { return true; }
  isConcurrencySafe() { return true; }

  prompt() {
    return `- Fast file pattern matching tool that works with any codebase size
- Supports glob patterns like "**/*.js" or "src/**/*.ts"
- Returns matching file paths sorted by modification time
- Use this tool when you need to find files by name patterns
- When you are doing an open ended search that may require multiple rounds of globbing and grepping, use the Agent tool instead`;
  }

  get inputSchema() {
    return {
      type: 'object',
      properties: {
        pattern: {
          type: 'string',
          description: 'The glob pattern to match files against',
        },
        path: {
          type: 'string',
          description: 'The directory to search in. If not specified, the current working directory will be used.',
        },
      },
      required: ['pattern'],
    };
  }

  getActivityDescription(input) {
    return `Searching for ${input.pattern || 'files'}`;
  }

  async execute(params, _context) {
    try {
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const searchDir = params.path ? path.resolve(cwd, params.path) : cwd;

      if (!fs.existsSync(searchDir)) {
        return { success: false, error: `Directory not found: ${searchDir}` };
      }

      const regex = globToRegex(params.pattern);
      const results = [];
      walkDir(searchDir, searchDir, regex, results, 0);

      // Sort by mtime descending (newest first)
      results.sort((a, b) => b.mtime - a.mtime);

      return {
        success: true,
        files: results.map(r => r.path),
        count: results.length,
        truncated: results.length >= MAX_RESULTS,
      };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }
}

module.exports = new GlobTool();
module.exports.GlobTool = GlobTool;
