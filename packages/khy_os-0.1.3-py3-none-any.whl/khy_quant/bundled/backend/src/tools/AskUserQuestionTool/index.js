/**
 * AskUserQuestionTool — structured user interaction, aligned with Claude Code's AskUserQuestion tool.
 *
 * Allows the AI to ask the user multiple-choice or free-form questions
 * during execution. Supports multi-select and recommended options.
 */
const { BaseTool } = require('../_baseTool');

class AskUserQuestionTool extends BaseTool {
  static toolName = 'AskUserQuestion';
  static category = 'system';
  static risk = 'safe';
  static aliases = ['ask_user', 'ask_question', 'prompt_user'];
  static searchHint = 'ask user question clarify confirm choice';
  static alwaysLoad = true;

  isReadOnly() { return true; }
  isConcurrencySafe() { return false; }

  prompt() {
    return `Use this tool when you need to ask the user questions during execution. This allows you to:
1. Gather user preferences or requirements
2. Clarify ambiguous instructions
3. Get decisions on implementation choices as you work
4. Offer choices to the user about what direction to take.

Usage notes:
- Users will always be able to select "Other" to provide custom text input
- Use multiSelect: true to allow multiple answers to be selected for a question
- If you recommend a specific option, make that the first option in the list and add "(Recommended)" at the end of the label

Plan mode note: In plan mode, use this tool to clarify requirements or choose between approaches BEFORE finalizing your plan. Do NOT use this tool to ask "Is my plan ready?" or "Should I proceed?" - use ExitPlanMode for plan approval. IMPORTANT: Do not reference "the plan" in your questions because the user cannot see the plan in the UI until you call ExitPlanMode. If you need plan approval, use ExitPlanMode instead.`;
  }

  get inputSchema() {
    return {
      type: 'object',
      properties: {
        question: {
          type: 'string',
          description: 'The question to ask the user',
        },
        options: {
          type: 'array',
          description: 'Array of options for the user to choose from. Each option has label (required), value (optional), description (optional), and preview (optional).',
        },
        multiSelect: {
          type: 'boolean',
          description: 'Allow multiple answers to be selected (default: false)',
        },
      },
      required: ['question'],
    };
  }

  getActivityDescription(input) {
    const preview = (input.question || '').slice(0, 40);
    return `Asking user: ${preview}`;
  }

  async execute(params, context) {
    const { question, options, multiSelect } = params;

    // If running in CLI mode (interactive), use readline
    try {
      const readline = require('readline');
      let _chalk;
      const c = () => (_chalk ??= (require('chalk').default || require('chalk')));

      // Display the question
      console.log('');
      console.log(c().cyan.bold('  ? ') + c().white.bold(question));

      if (options && options.length > 0) {
        console.log('');
        options.forEach((opt, i) => {
          const label = typeof opt === 'string' ? opt : (opt.label || opt.value || String(opt));
          const desc = (typeof opt === 'object' && opt.description) ? c().dim(` — ${opt.description}`) : '';
          console.log(c().cyan(`  ${i + 1}. `) + label + desc);
        });
        console.log(c().dim(`  ${options.length + 1}. Other (custom input)`));
      }

      console.log('');

      // Non-interactive mode: return the question for external handling
      if (!process.stdin.isTTY) {
        return {
          success: true,
          type: 'question',
          question,
          options: options || [],
          multiSelect: multiSelect || false,
          message: 'Question queued for user (non-interactive mode)',
        };
      }

      // Interactive mode: wait for user input
      const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
      });

      const answer = await new Promise((resolve) => {
        const prompt = multiSelect
          ? c().dim('  Enter choice numbers (comma-separated) > ')
          : c().dim('  Enter choice number or type answer > ');

        rl.question(prompt, (input) => {
          rl.close();
          resolve(input.trim());
        });
      });

      // Parse the answer
      if (options && options.length > 0) {
        if (multiSelect) {
          const nums = answer.split(/[,;\s]+/).map(n => parseInt(n, 10)).filter(n => !isNaN(n));
          const selected = nums
            .map(n => {
              if (n > 0 && n <= options.length) {
                const opt = options[n - 1];
                return typeof opt === 'string' ? opt : (opt.value || opt.label);
              }
              return null;
            })
            .filter(Boolean);

          if (selected.length === 0) {
            // Treat as free-text
            return { success: true, answer, type: 'custom' };
          }
          return { success: true, selected, type: 'multi_choice' };
        }

        const num = parseInt(answer, 10);
        if (num > 0 && num <= options.length) {
          const opt = options[num - 1];
          const value = typeof opt === 'string' ? opt : (opt.value || opt.label);
          return { success: true, answer: value, type: 'choice', index: num - 1 };
        }

        if (num === options.length + 1) {
          // "Other" selected
          return { success: true, answer, type: 'custom' };
        }
      }

      return { success: true, answer, type: 'text' };
    } catch (err) {
      // Fallback: return the question as-is for external handling
      return {
        success: true,
        type: 'question',
        question,
        options: options || [],
        multiSelect: multiSelect || false,
        message: 'Question returned for external handling',
      };
    }
  }
}

module.exports = new AskUserQuestionTool();
module.exports.AskUserQuestionTool = AskUserQuestionTool;
