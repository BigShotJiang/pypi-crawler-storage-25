/**
 * AgentTool — sub-agent spawning tool, aligned with Claude Code's Agent tool.
 *
 * Spawns independent sub-agents for parallel work. Supports multiple
 * subagent types: Explore (read-only codebase exploration), Plan
 * (structured planning), and general-purpose (full tool access).
 *
 * Delegates to the coordinator (when available) or runs a standalone
 * tool-use loop with direct AI chat.
 */
const { BaseTool } = require('../_baseTool');
const path = require('path');

class AgentTool extends BaseTool {
  static toolName = 'Agent';
  static category = 'coordinator';
  static risk = 'medium';
  static aliases = ['agent', 'spawn_worker', 'delegate', 'sub_agent', 'Task'];
  static searchHint = 'spawn worker agent delegate task parallel explore research plan';
  static alwaysLoad = true;

  isReadOnly() { return false; }
  isConcurrencySafe() { return true; }

  prompt() {
    return `Launch a sub-agent that has access to all tools to handle a task autonomously.

The sub-agent runs independently with its own tool-use loop and cannot see the parent conversation. You MUST provide a detailed, self-contained prompt with all necessary context.

Use this tool for:
- Parallel research across multiple files or directories
- Independent coding tasks that don't require parent context
- Complex file exploration and analysis
- Tasks that benefit from focused, autonomous execution

Subagent types:
- "Explore" — read-only codebase exploration. Searches files, reads code, and summarizes findings. Does NOT modify files.
- "Plan" — structured planning. Analyzes requirements and produces an execution plan.
- "general-purpose" — full tool access. Can read, write, edit, execute, and search.

Tips:
- Provide specific file paths, function names, or patterns when possible
- Include ALL relevant context in the prompt — agents cannot see conversation history
- For Explore agents, ask specific questions rather than broad ones
- Agents are best for tasks that can be completed independently`;
  }

  get inputSchema() {
    return {
      type: 'object',
      properties: {
        prompt: {
          type: 'string',
          description: 'Self-contained task description with all context the agent needs',
        },
        subagent_type: {
          type: 'string',
          enum: ['Explore', 'Plan', 'general-purpose'],
          description: 'Agent type: "Explore" for read-only search, "Plan" for structured planning, "general-purpose" for full tool access (default)',
        },
        timeout: {
          type: 'number',
          description: 'Timeout in seconds (default: 120)',
        },
      },
      required: ['prompt'],
    };
  }

  getActivityDescription(input) {
    const type = input.subagent_type || 'general-purpose';
    const preview = (input.prompt || '').slice(0, 40);
    return `Agent (${type}): ${preview}`;
  }

  getToolUseSummary(input) {
    return `agent: ${(input.prompt || '').slice(0, 60)}`;
  }

  async execute(params, _context) {
    const timeoutMs = (params.timeout || 120) * 1000;
    const subagentType = params.subagent_type || 'general-purpose';

    // Map subagent_type to the internal role system
    const roleMap = {
      'Explore': 'explore',
      'Plan': 'reviewer', // Plan agents analyze but don't modify
      'general-purpose': 'general',
    };
    const role = roleMap[subagentType] || 'general';

    // Try coordinator mode first
    try {
      const { isCoordinatorMode } = require('../../coordinator/coordinatorMode');
      if (isCoordinatorMode()) {
        const { spawnWorker } = require('../../coordinator/workerAgent');
        const worker = await spawnWorker(params.prompt, {
          role,
          timeout: timeoutMs,
        });
        return {
          success: true,
          workerId: worker.id,
          subagent_type: subagentType,
          role: worker.role,
          status: worker.status,
          output: worker.output || worker.message,
          message: `Worker ${worker.id} completed as ${subagentType}.`,
        };
      }
    } catch { /* coordinator not available, use standalone mode */ }

    // Standalone mode: run a mini tool-use loop with direct AI chat
    return this._runStandaloneAgent(params.prompt, role, subagentType, timeoutMs);
  }

  async _runStandaloneAgent(prompt, role, subagentType, timeoutMs) {
    const startTime = Date.now();

    const roleHints = {
      explore: 'You are a codebase exploration agent. Search files, read code, and summarize findings. Do NOT modify files.',
      reviewer: 'You are a planning agent. Analyze requirements, explore the codebase, and produce a structured execution plan. Do NOT modify files.',
      general: 'You are a general-purpose agent. Use available tools to complete the task efficiently.',
    };
    const rolePrompt = roleHints[role] || roleHints.general;

    try {
      const toolUseLoop = require('../../services/toolUseLoop');

      if (toolUseLoop.isEnabled()) {
        const ai = require('../../cli/ai');
        const agentPrompt = `[Agent Task — Type: ${subagentType}]\n${rolePrompt}\n\nTask:\n${prompt}`;
        const toolLog = [];

        const result = await Promise.race([
          toolUseLoop.runToolUseLoop(agentPrompt, {
            chat: (message, opts = {}) => ai.chat(message, {
              ...opts,
              disableNaturalToolLoop: true,
            }),
            maxIterations: 8,
            onToolCall: (name, _params, iteration) => {
              toolLog.push({ tool: name, iteration, status: 'started' });
            },
            onToolResult: (name, _params, result, _iteration, elapsed) => {
              const last = toolLog.find(t => t.tool === name && t.status === 'started');
              if (last) {
                last.status = result?.success ? 'success' : 'error';
                last.elapsed = elapsed;
              }
            },
          }),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Agent timed out')), timeoutMs)
          ),
        ]);

        const elapsed = Date.now() - startTime;
        return {
          success: true,
          subagent_type: subagentType,
          role,
          output: result.finalResponse || '',
          iterations: result.iterations,
          toolCalls: toolLog.length,
          elapsed: `${(elapsed / 1000).toFixed(1)}s`,
          message: `Agent (${subagentType}) completed in ${(elapsed / 1000).toFixed(1)}s with ${toolLog.length} tool uses.`,
        };
      }

      // Fallback: simple single-shot AI chat (no tool loop)
      const ai = require('../../cli/ai');
      const result = await ai.chat(`[Agent Task — ${subagentType}] ${prompt}`, {
        disableNaturalToolLoop: false,
      });
      const elapsed = Date.now() - startTime;
      return {
        success: true,
        subagent_type: subagentType,
        role,
        output: result.reply || '',
        iterations: 1,
        toolCalls: 0,
        elapsed: `${(elapsed / 1000).toFixed(1)}s`,
        message: `Agent (${subagentType}) completed in ${(elapsed / 1000).toFixed(1)}s.`,
      };
    } catch (err) {
      const elapsed = Date.now() - startTime;
      return {
        success: false,
        subagent_type: subagentType,
        role,
        error: err.message,
        elapsed: `${(elapsed / 1000).toFixed(1)}s`,
        message: `Agent (${subagentType}) failed after ${(elapsed / 1000).toFixed(1)}s: ${err.message}`,
      };
    }
  }
}

module.exports = new AgentTool();
module.exports.AgentTool = AgentTool;
