const { defineTool } = require('./_baseTool');
const fs = require('fs');
const path = require('path');

const MAX_SIZE = 500 * 1024; // 500 KB (upgraded from 100KB)

module.exports = defineTool({
  name: 'readFile',
  description: 'Read a file from the filesystem (capped at 500KB)',
  category: 'filesystem',
  risk: 'low',
  isReadOnly: true,
  isConcurrencySafe: true,

  // Chapter 5 additions
  aliases: ['read_file', 'cat'],
  searchHint: 'read file contents from filesystem',
  maxResultSizeChars: Infinity, // never persist to disk (prevents circular reads)

  inputSchema: {
    path: { type: 'string', required: true, description: 'File path (relative to CWD or absolute)' },
    encoding: { type: 'string', required: false, description: 'File encoding (default: utf-8)' },
    offset: { type: 'number', required: false, description: 'Line number to start reading from (1-based)' },
    limit: { type: 'number', required: false, description: 'Number of lines to read' },
  },

  async validateInput(input) {
    const { validateNotDevicePath, validateNotUNCPath, composeValidations } = require('./inputValidators');
    return composeValidations(
      validateNotDevicePath(input.path),
      validateNotUNCPath(input.path),
    );
  },

  getActivityDescription(input) {
    return `Reading ${input.path || 'file'}`;
  },

  async execute(params, context) {
    try {
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      // Expand environment variables in path (%USERNAME%, $HOME, ~)
      let rawPath = params.path;
      if (process.platform === 'win32') {
        rawPath = rawPath.replace(/%([^%]+)%/g, (_, key) => process.env[key] || `%${key}%`);
      } else {
        rawPath = rawPath.replace(/\$\{?(\w+)\}?/g, (_, key) => process.env[key] || '');
      }
      if (rawPath.startsWith('~')) {
        rawPath = path.join(require('os').homedir(), rawPath.slice(1));
      }
      const filePath = path.resolve(cwd, rawPath);
      const encoding = params.encoding || 'utf-8';

      const stat = fs.statSync(filePath);
      if (stat.size > MAX_SIZE) {
        return { success: false, error: `File too large: ${stat.size} bytes (max ${MAX_SIZE}). Use a shell command to read portions.` };
      }

      const raw = fs.readFileSync(filePath, encoding);

      // Apply offset/limit for line-range reading
      if (params.offset || params.limit) {
        const lines = raw.split('\n');
        const start = Math.max(0, (params.offset || 1) - 1);
        const end = params.limit ? start + params.limit : lines.length;
        const sliced = lines.slice(start, end);

        // Add line numbers
        const numbered = sliced.map((line, i) => `${start + i + 1}\t${line}`).join('\n');
        return { success: true, content: numbered, size: stat.size, lines: sliced.length };
      }

      return { success: true, content: raw, size: stat.size };
    } catch (err) {
      return { success: false, error: err.message };
    }
  },
});
