'use strict';

/**
 * Cron job scheduler for khy OS.
 * Aligned with Claude Code's ScheduleCron architecture.
 *
 * Supports:
 * - Standard 5-field cron expressions (minute hour dom month dow)
 * - One-shot jobs (recurring: false, auto-delete after firing)
 * - Recurring jobs (auto-expire after 7 days)
 * - Durable jobs (persisted to .khy/scheduled_tasks.json)
 * - Session-only jobs (in-memory, die with the process)
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { randomBytes } = require('crypto');

const DURABLE_FILE = path.join(os.homedir(), '.khy', 'scheduled_tasks.json');
const MAX_RECURRING_LIFETIME_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

/**
 * @typedef {Object} CronJob
 * @property {string} id
 * @property {string} cron - Standard 5-field cron expression
 * @property {string} prompt - The prompt to enqueue
 * @property {boolean} recurring - true = fire on every match; false = one-shot
 * @property {boolean} durable - true = persisted to disk
 * @property {number} createdAt - Unix timestamp (ms)
 * @property {number} [lastFired] - Unix timestamp (ms) of last fire
 * @property {number} [expiresAt] - Unix timestamp (ms) when auto-expires
 */

/** @type {Map<string, CronJob>} */
const _sessionJobs = new Map();

/** @type {Map<string, CronJob>} */
const _durableJobs = new Map();

/** @type {NodeJS.Timeout|null} */
let _tickInterval = null;

/** @type {function(string): void|null} */
let _enqueueCallback = null;

/**
 * Generate a short unique job ID.
 * @returns {string}
 */
function generateJobId() {
  return 'cron_' + randomBytes(6).toString('hex');
}

/**
 * Parse a 5-field cron expression and check if it matches the given date.
 *
 * @param {string} expr - "M H DoM Mon DoW"
 * @param {Date} date
 * @returns {boolean}
 */
function cronMatches(expr, date) {
  const parts = expr.trim().split(/\s+/);
  if (parts.length !== 5) return false;

  const minute = date.getMinutes();
  const hour = date.getHours();
  const dom = date.getDate();
  const month = date.getMonth() + 1;
  const dow = date.getDay(); // 0=Sun

  return (
    fieldMatches(parts[0], minute, 0, 59) &&
    fieldMatches(parts[1], hour, 0, 23) &&
    fieldMatches(parts[2], dom, 1, 31) &&
    fieldMatches(parts[3], month, 1, 12) &&
    fieldMatches(parts[4], dow, 0, 7)
  );
}

/**
 * Check if a cron field matches a value.
 * Supports: *, N, N-M, *​/N, N-M/N, comma-separated lists.
 *
 * @param {string} field
 * @param {number} value
 * @param {number} min
 * @param {number} max
 * @returns {boolean}
 */
function fieldMatches(field, value, min, max) {
  // Handle comma-separated values
  if (field.includes(',')) {
    return field.split(',').some(part => fieldMatches(part.trim(), value, min, max));
  }

  // Handle step values
  if (field.includes('/')) {
    const [rangeStr, stepStr] = field.split('/');
    const step = parseInt(stepStr, 10);
    if (isNaN(step) || step <= 0) return false;

    let rangeMin = min;
    let rangeMax = max;

    if (rangeStr !== '*') {
      if (rangeStr.includes('-')) {
        const [lo, hi] = rangeStr.split('-').map(Number);
        rangeMin = lo;
        rangeMax = hi;
      } else {
        rangeMin = parseInt(rangeStr, 10);
      }
    }

    if (value < rangeMin || value > rangeMax) return false;
    return (value - rangeMin) % step === 0;
  }

  // Handle ranges
  if (field.includes('-')) {
    const [lo, hi] = field.split('-').map(Number);
    return value >= lo && value <= hi;
  }

  // Wildcard
  if (field === '*') return true;

  // Exact match
  const num = parseInt(field, 10);
  // Day-of-week: 7 = 0 (both mean Sunday)
  if (max === 7 && num === 7 && value === 0) return true;
  return value === num;
}

/**
 * Load durable jobs from disk.
 */
function loadDurableJobs() {
  try {
    if (!fs.existsSync(DURABLE_FILE)) return;
    const raw = fs.readFileSync(DURABLE_FILE, 'utf-8');
    const jobs = JSON.parse(raw);
    _durableJobs.clear();
    for (const job of jobs) {
      _durableJobs.set(job.id, job);
    }
  } catch {
    // Corrupted or missing file, start fresh
  }
}

/**
 * Save durable jobs to disk.
 */
function saveDurableJobs() {
  try {
    const dir = path.dirname(DURABLE_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const jobs = Array.from(_durableJobs.values());
    fs.writeFileSync(DURABLE_FILE, JSON.stringify(jobs, null, 2), 'utf-8');
  } catch {
    // Best-effort persistence
  }
}

/**
 * Create a new cron job.
 *
 * @param {object} opts
 * @param {string} opts.cron - 5-field cron expression
 * @param {string} opts.prompt - Prompt to enqueue
 * @param {boolean} [opts.recurring=true] - Recurring or one-shot
 * @param {boolean} [opts.durable=false] - Persist to disk
 * @returns {CronJob}
 */
function createJob({ cron, prompt, recurring = true, durable = false }) {
  const now = Date.now();
  const job = {
    id: generateJobId(),
    cron,
    prompt,
    recurring,
    durable,
    createdAt: now,
    expiresAt: recurring ? now + MAX_RECURRING_LIFETIME_MS : undefined,
  };

  if (durable) {
    _durableJobs.set(job.id, job);
    saveDurableJobs();
  } else {
    _sessionJobs.set(job.id, job);
  }

  return job;
}

/**
 * Delete a cron job by ID.
 *
 * @param {string} id
 * @returns {boolean} - True if the job was found and deleted
 */
function deleteJob(id) {
  if (_sessionJobs.has(id)) {
    _sessionJobs.delete(id);
    return true;
  }
  if (_durableJobs.has(id)) {
    _durableJobs.delete(id);
    saveDurableJobs();
    return true;
  }
  return false;
}

/**
 * List all jobs (session + durable).
 *
 * @returns {CronJob[]}
 */
function listJobs() {
  return [
    ...Array.from(_sessionJobs.values()),
    ...Array.from(_durableJobs.values()),
  ];
}

/**
 * Tick: check all jobs against the current time, fire matching ones.
 * Called once per minute.
 */
function tick() {
  const now = new Date();
  const allJobs = [
    ...Array.from(_sessionJobs.entries()),
    ...Array.from(_durableJobs.entries()),
  ];

  for (const [id, job] of allJobs) {
    // Check expiry
    if (job.expiresAt && Date.now() > job.expiresAt) {
      _sessionJobs.delete(id);
      _durableJobs.delete(id);
      continue;
    }

    // Check if cron matches
    if (!cronMatches(job.cron, now)) continue;

    // Fire the job
    job.lastFired = Date.now();

    if (_enqueueCallback) {
      try {
        _enqueueCallback(job.prompt);
      } catch {
        // Don't crash the scheduler
      }
    }

    // One-shot: remove after firing
    if (!job.recurring) {
      _sessionJobs.delete(id);
      _durableJobs.delete(id);
    }
  }

  // Persist changes to durable jobs
  if (_durableJobs.size > 0) {
    saveDurableJobs();
  }
}

/**
 * Start the cron scheduler.
 *
 * @param {function(string): void} enqueueCallback - Called with prompt when a job fires
 */
function startScheduler(enqueueCallback) {
  _enqueueCallback = enqueueCallback;
  loadDurableJobs();

  if (!_tickInterval) {
    _tickInterval = setInterval(tick, 60 * 1000);
    // Don't prevent process exit
    if (_tickInterval.unref) _tickInterval.unref();
  }
}

/**
 * Stop the cron scheduler.
 */
function stopScheduler() {
  if (_tickInterval) {
    clearInterval(_tickInterval);
    _tickInterval = null;
  }
  _enqueueCallback = null;
}

module.exports = {
  createJob,
  deleteJob,
  listJobs,
  startScheduler,
  stopScheduler,
  cronMatches,
  fieldMatches,
};
