/**
 * Task Board — file-based shared task list for coordinator & workers.
 *
 * Tasks stored as individual JSON files in ~/.khyquant/tasks/.
 * Supports atomic claiming via rename-based locking.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function _tasksDir() {
  const { getDataDir } = require('../utils/dataHome');
  return getDataDir('tasks');
}

function _taskPath(id) {
  return path.join(_tasksDir(), `${id}.json`);
}

function _newId() {
  return 't-' + Date.now().toString(36) + '-' + crypto.randomBytes(2).toString('hex');
}

// ── CRUD Operations ────────────────────────────────────────────────

/**
 * Create a new task.
 * @param {object} task
 * @param {string} task.description
 * @param {string} [task.assignee]
 * @param {string[]} [task.dependencies] - IDs of tasks that must complete first
 * @param {string} [task.priority] - low/medium/high
 * @returns {object} Created task with id
 */
function createTask(task) {
  const id = _newId();
  const record = {
    id,
    description: task.description,
    status: 'pending',
    assignee: task.assignee || null,
    dependencies: task.dependencies || [],
    priority: task.priority || 'medium',
    result: null,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    completedAt: null,
  };
  fs.writeFileSync(_taskPath(id), JSON.stringify(record, null, 2), 'utf-8');
  return record;
}

/**
 * Get a task by ID.
 * @param {string} id
 * @returns {object|null}
 */
function getTask(id) {
  try {
    return JSON.parse(fs.readFileSync(_taskPath(id), 'utf-8'));
  } catch {
    return null;
  }
}

/**
 * Update a task (atomic read-modify-write).
 * @param {string} id
 * @param {object} updates
 * @returns {object|null} Updated task
 */
function updateTask(id, updates) {
  const task = getTask(id);
  if (!task) return null;

  Object.assign(task, updates, { updatedAt: Date.now() });
  fs.writeFileSync(_taskPath(id), JSON.stringify(task, null, 2), 'utf-8');
  return task;
}

/**
 * List all tasks with optional status filter.
 * @param {object} [filter]
 * @param {string} [filter.status] - pending/claimed/completed/failed
 * @param {string} [filter.assignee]
 * @returns {object[]}
 */
function listTasks(filter = {}) {
  const dir = _tasksDir();
  let files;
  try { files = fs.readdirSync(dir).filter(f => f.endsWith('.json')); } catch { return []; }

  const tasks = [];
  for (const file of files) {
    try {
      const task = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf-8'));
      if (filter.status && task.status !== filter.status) continue;
      if (filter.assignee && task.assignee !== filter.assignee) continue;
      tasks.push(task);
    } catch { /* skip corrupt files */ }
  }

  // Sort by priority then creation time
  const priorityOrder = { high: 0, medium: 1, low: 2 };
  tasks.sort((a, b) => {
    const pa = priorityOrder[a.priority] ?? 1;
    const pb = priorityOrder[b.priority] ?? 1;
    return pa - pb || a.createdAt - b.createdAt;
  });

  return tasks;
}

/**
 * Atomically claim a task for a worker.
 * Uses rename-based locking: renames the file to include the claimer.
 * @param {string} id
 * @param {string} workerId
 * @returns {boolean} true if claim succeeded
 */
function claimTask(id, workerId) {
  const task = getTask(id);
  if (!task || task.status !== 'pending') return false;

  // Check dependencies are complete
  if (task.dependencies && task.dependencies.length > 0) {
    for (const depId of task.dependencies) {
      const dep = getTask(depId);
      if (!dep || dep.status !== 'completed') return false;
    }
  }

  task.status = 'claimed';
  task.assignee = workerId;
  task.updatedAt = Date.now();
  fs.writeFileSync(_taskPath(id), JSON.stringify(task, null, 2), 'utf-8');
  return true;
}

/**
 * Mark a task as completed with result.
 * @param {string} id
 * @param {string} result
 * @returns {object|null}
 */
function completeTask(id, result) {
  return updateTask(id, {
    status: 'completed',
    result,
    completedAt: Date.now(),
  });
}

/**
 * Mark a task as failed.
 * @param {string} id
 * @param {string} error
 * @returns {object|null}
 */
function failTask(id, error) {
  return updateTask(id, {
    status: 'failed',
    result: error,
    completedAt: Date.now(),
  });
}

/**
 * Clean up old completed/failed tasks.
 * @param {number} [olderThanMs=3600000] - Default 1 hour
 * @returns {number} Count of removed tasks
 */
function cleanup(olderThanMs = 3600000) {
  const cutoff = Date.now() - olderThanMs;
  let removed = 0;

  const tasks = listTasks();
  for (const task of tasks) {
    if ((task.status === 'completed' || task.status === 'failed') && task.completedAt < cutoff) {
      try {
        fs.unlinkSync(_taskPath(task.id));
        removed++;
      } catch { /* ignore */ }
    }
  }
  return removed;
}

module.exports = {
  createTask, getTask, updateTask, listTasks,
  claimTask, completeTask, failTask, cleanup,
};
