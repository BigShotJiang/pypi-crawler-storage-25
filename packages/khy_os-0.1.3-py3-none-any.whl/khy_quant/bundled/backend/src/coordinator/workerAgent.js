/**
 * Worker Agent — manages worker lifecycle for coordinator mode.
 *
 * Workers are in-process async tasks that run with full tool sets.
 * They reuse the existing AI chat + tool execution pipeline.
 */
'use strict';

const crypto = require('crypto');

// ── Worker Registry ────────────────────────────────────────────────

const _workers = new Map(); // id → WorkerState

/**
 * @typedef {object} WorkerState
 * @property {string} id
 * @property {string} task
 * @property {'pending'|'running'|'completed'|'error'|'stopped'} status
 * @property {string} result
 * @property {number} startedAt
 * @property {number} [completedAt]
 * @property {string} [error]
 * @property {AbortController} [abortController]
 * @property {string[]} pendingMessages - Queue for follow-up messages
 */

function _newId() {
  return 'w-' + crypto.randomBytes(3).toString('hex');
}

// ── Public API ─────────────────────────────────────────────────────

/**
 * Spawn a new worker to execute a task.
 * @param {string} taskDescription - Self-contained task prompt
 * @param {object} [opts]
 * @param {string} [opts.role] - Agent role (explore/planner/coder/reviewer/general)
 * @param {number} [opts.timeout] - Timeout in ms (default: 120000)
 * @returns {Promise<WorkerState>}
 */
async function spawnWorker(taskDescription, opts = {}) {
  const id = _newId();
  const abortController = new AbortController();

  const worker = {
    id,
    task: taskDescription,
    role: opts.role || 'coder',
    status: 'pending',
    result: '',
    startedAt: Date.now(),
    completedAt: null,
    error: null,
    abortController,
    pendingMessages: [],
    toolCalls: 0,
    tokens: 0,
  };
  _workers.set(id, worker);

  // Execute asynchronously
  _executeWorker(worker, opts).catch(err => {
    worker.status = 'error';
    worker.error = err.message;
    worker.completedAt = Date.now();
  });

  return worker;
}

/**
 * Send a follow-up message to an active worker.
 * @param {string} workerId
 * @param {string} message
 * @returns {boolean}
 */
function sendMessage(workerId, message) {
  const worker = _workers.get(workerId);
  if (!worker) return false;
  if (worker.status !== 'running') return false;

  worker.pendingMessages.push(message);
  return true;
}

/**
 * Stop a running worker gracefully.
 * @param {string} workerId
 * @returns {boolean}
 */
function shutdownWorker(workerId) {
  const worker = _workers.get(workerId);
  if (!worker) return false;

  if (worker.abortController) {
    worker.abortController.abort();
  }
  worker.status = 'stopped';
  worker.completedAt = Date.now();
  return true;
}

/**
 * Get worker status.
 * @param {string} workerId
 * @returns {WorkerState|null}
 */
function getWorkerStatus(workerId) {
  return _workers.get(workerId) || null;
}

/**
 * List all workers with optional status filter.
 * @param {string} [statusFilter]
 * @returns {WorkerState[]}
 */
function listWorkers(statusFilter) {
  const all = [..._workers.values()];
  if (statusFilter) return all.filter(w => w.status === statusFilter);
  return all;
}

/**
 * Clean up completed workers older than threshold.
 * @param {number} [olderThanMs=300000] - Default 5 minutes
 */
function cleanup(olderThanMs = 300000) {
  const cutoff = Date.now() - olderThanMs;
  for (const [id, worker] of _workers) {
    if (worker.completedAt && worker.completedAt < cutoff) {
      _workers.delete(id);
    }
  }
}

// ── Internal Execution ─────────────────────────────────────────────

async function _executeWorker(worker, opts = {}) {
  worker.status = 'running';
  const timeout = opts.timeout || 120000;

  try {
    // Load the AI agent runner
    const agentRunner = require('../services/cliAgentRunner');
    const { AGENT_ROLES } = agentRunner;

    // Get the role configuration
    const role = AGENT_ROLES[worker.role] || AGENT_ROLES.general;

    // Build the worker prompt
    const prompt = `${role.systemPrompt}\n\nTask:\n${worker.task}\n\nProvide a concise, actionable result.`;

    // Use a simple AI chat call with the role's tool profile
    let aiModule;
    try {
      aiModule = require('../cli/ai');
    } catch {
      // Fallback: use gateway directly
      const gateway = require('../services/gateway/aiGateway');
      const result = await Promise.race([
        gateway.generate(prompt),
        new Promise((_, rej) => setTimeout(() => rej(new Error('Worker timeout')), timeout)),
      ]);
      worker.result = typeof result === 'string' ? result : (result.text || result.reply || JSON.stringify(result));
      worker.status = 'completed';
      worker.completedAt = Date.now();
      return;
    }

    // Use ai.chat with tool profile
    const chatOpts = {
      _isFollowUp: true,
      effort: 'medium',
    };

    // Apply tool profile from role
    if (role.toolProfile) {
      try {
        const toolRegistry = require('../tools');
        chatOpts.toolDefinitions = toolRegistry.getDefinitions(role.toolProfile);
      } catch { /* fallback: no filtering */ }
    }

    const result = await Promise.race([
      aiModule.chat(prompt, chatOpts),
      new Promise((_, rej) => setTimeout(() => rej(new Error('Worker timeout')), timeout)),
    ]);

    worker.result = result.reply || result.text || '';
    worker.tokens = result.tokenUsage?.totalTokens || 0;
    worker.toolCalls = (result.commands || []).length;
    worker.status = 'completed';
    worker.completedAt = Date.now();

    // Process pending follow-up messages
    while (worker.pendingMessages.length > 0 && worker.status === 'completed') {
      const msg = worker.pendingMessages.shift();
      worker.status = 'running';
      const followUp = await aiModule.chat(msg, { _isFollowUp: true });
      worker.result += '\n---\n' + (followUp.reply || '');
      worker.status = 'completed';
    }

  } catch (err) {
    if (err.name === 'AbortError' || worker.status === 'stopped') {
      worker.status = 'stopped';
    } else {
      worker.status = 'error';
      worker.error = err.message;
    }
    worker.completedAt = Date.now();
  }
}

module.exports = {
  spawnWorker,
  sendMessage,
  shutdownWorker,
  getWorkerStatus,
  listWorkers,
  cleanup,
};
