/**
 * KAIROS Assistant Mode — persistent cross-session assistant.
 *
 * Features:
 * - Cross-session persistence via config
 * - Daily append-only markdown logs
 * - Auto-dream memory consolidation (4 phases)
 * - Proactive idle tick system
 *
 * Activation: KHYQUANT_ASSISTANT_MODE=true or config assistant: true
 *
 * Ported from Claude Code's assistant/index.ts.
 */
'use strict';

const { appendLog, readTodayLog, getRecentLogs, getLogFileCount } = require('./dailyLog');
const { shouldDream, runDream } = require('./autoDream');
const { activate: activateProactive, deactivate: deactivateProactive, isProactiveActive } = require('./proactive');
const { readLastConsolidatedAt } = require('./consolidationLock');

// ── Mode Detection ─────────────────────────────────────────────────

/**
 * Check if assistant mode is active.
 * @returns {boolean}
 */
function isAssistantMode() {
  // Environment variable
  const env = process.env.KHYQUANT_ASSISTANT_MODE;
  if (env === 'true' || env === '1') return true;
  if (env === 'false' || env === '0') return false;

  // Config file
  try {
    const fs = require('fs');
    const path = require('path');
    const { getDataHome } = require('../utils/dataHome');
    const configPath = path.join(getDataHome(), 'config.json');
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      return !!config.assistant;
    }
  } catch { /* no config */ }

  return false;
}

// ── Activation ─────────────────────────────────────────────────────

let _activated = false;

/**
 * Activate assistant mode — starts daily logging and proactive ticks.
 */
function activate() {
  if (_activated) return;
  _activated = true;

  process.env.KHYQUANT_ASSISTANT_MODE = 'true';

  // Log activation
  appendLog('Assistant mode activated.');

  // Start proactive idle ticks
  activateProactive(undefined, async (tickInfo) => {
    if (tickInfo.dreamNeeded) {
      // Auto-dream in background
      try {
        const ai = require('../cli/ai');
        runDream(ai).catch(() => {}); // Fire and forget
      } catch { /* AI not available */ }
    }
  });
}

/**
 * Deactivate assistant mode.
 */
function deactivate() {
  if (!_activated) return;
  _activated = false;

  process.env.KHYQUANT_ASSISTANT_MODE = 'false';
  deactivateProactive();
  appendLog('Assistant mode deactivated.');
}

// ── Status ─────────────────────────────────────────────────────────

/**
 * Get assistant mode status summary.
 * @returns {object}
 */
function getStatus() {
  const lastDream = readLastConsolidatedAt();
  const dreamCheck = shouldDream();
  const logCount = getLogFileCount();

  return {
    active: isAssistantMode(),
    proactive: isProactiveActive(),
    logCount,
    lastDream: lastDream > 0 ? new Date(lastDream).toISOString() : 'never',
    dreamNeeded: dreamCheck.needed,
    dreamReason: dreamCheck.reason,
  };
}

// ── Log Session Activity ───────────────────────────────────────────

/**
 * Log a user interaction to the daily log.
 * @param {string} userInput - What the user asked
 * @param {string} [summary] - Brief summary of the response
 */
function logInteraction(userInput, summary) {
  if (!isAssistantMode()) return;

  const entry = summary
    ? `**User:** ${userInput.slice(0, 100)}\n**Summary:** ${summary.slice(0, 200)}`
    : `**User:** ${userInput.slice(0, 100)}`;

  appendLog(entry);
}

module.exports = {
  isAssistantMode,
  activate,
  deactivate,
  getStatus,
  logInteraction,
  // Re-exports for convenience
  appendLog,
  readTodayLog,
  getRecentLogs,
  shouldDream,
  runDream,
};
