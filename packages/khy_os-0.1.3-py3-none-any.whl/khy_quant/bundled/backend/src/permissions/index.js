/**
 * Permission System — mode-based permission management.
 *
 * Three permission modes (matching Claude Code's architecture):
 *
 *   default  — Safe tools auto-approved; dangerous tools require confirmation.
 *              This is the standard interactive mode.
 *
 *   auto     — All tools auto-approved except blocked patterns.
 *              Equivalent to "accept all" / dangerousMode.
 *
 *   bypass   — Strict mode. ALL tools require explicit confirmation,
 *              including normally-safe read operations.
 *
 * The mode can be cycled via Shift+Tab (or programmatically) for quick
 * toggling during an interactive session.
 *
 * This module is the entry point — it re-exports bashSecurity and rules
 * for convenience, and provides the mode management layer.
 */
'use strict';

const bashSecurity = require('./bashSecurity');
const rules = require('./rules');

// ── Permission modes ───────────────────────────────────────────────────

const PERMISSION_MODES = ['default', 'auto', 'bypass'];

let _mode = 'default';

/**
 * Get the current permission mode.
 * @returns {'default'|'auto'|'bypass'}
 */
function getPermissionMode() {
  return _mode;
}

/**
 * Set the permission mode.
 * @param {'default'|'auto'|'bypass'} mode
 */
function setPermissionMode(mode) {
  if (!PERMISSION_MODES.includes(mode)) {
    throw new Error(`Invalid permission mode: ${mode}. Valid: ${PERMISSION_MODES.join(', ')}`);
  }
  _mode = mode;
}

/**
 * Cycle through permission modes (for Shift+Tab binding).
 * Order: default -> auto -> bypass -> default
 *
 * @returns {'default'|'auto'|'bypass'} The new mode
 */
function cyclePermissionMode() {
  const idx = PERMISSION_MODES.indexOf(_mode);
  _mode = PERMISSION_MODES[(idx + 1) % PERMISSION_MODES.length];
  return _mode;
}

/**
 * Check whether a tool call should be allowed, denied, or needs user confirmation.
 *
 * Decision flow:
 *   1. Mode = 'auto' and tool is not in deny list -> allow
 *   2. Mode = 'bypass' -> ask (everything needs confirmation)
 *   3. Check rules (always-allow / always-deny patterns)
 *   4. bashSecurity classification for bash/shell commands
 *   5. Mode = 'default' + safe tool -> allow
 *   6. Default -> ask
 *
 * @param {string} toolName  - The tool being invoked
 * @param {object} [params]  - Tool parameters (e.g., { command } for bash)
 * @param {object} [options] - Extra context: { risk, isReadOnly, isDestructive }
 * @returns {'allow'|'deny'|'ask'}
 */
function checkPermission(toolName, params = {}, options = {}) {
  // Auto mode: allow everything unless explicitly denied
  if (_mode === 'auto') {
    const ruleResult = rules.checkPermission(toolName, params);
    if (ruleResult === 'deny') return 'deny';
    return 'allow';
  }

  // Bypass mode: require confirmation for everything
  if (_mode === 'bypass') {
    const ruleResult = rules.checkPermission(toolName, params);
    if (ruleResult === 'deny') return 'deny';
    if (ruleResult === 'allow') return 'allow'; // Explicit allow overrides bypass
    return 'ask';
  }

  // Default mode
  // Check explicit rules first
  const ruleResult = rules.checkPermission(toolName, params);
  if (ruleResult === 'allow') return 'allow';
  if (ruleResult === 'deny') return 'deny';

  // For bash/shell tools, use security classification
  if (toolName === 'bash' || toolName === 'shell' || toolName === 'Bash') {
    const command = params.command || params.cmd || '';
    if (command) {
      const classification = bashSecurity.classifyBashCommand(command);
      if (classification.category === 'blocked') return 'deny';
      if (classification.category === 'dangerous') return 'ask';
      if (classification.category === 'needs_confirmation') return 'ask';
      if (classification.category === 'safe') return 'allow';
    }
  }

  // Safe tools in default mode
  if (options.risk === 'safe' || options.isReadOnly === true) {
    return 'allow';
  }

  // Destructive tools always need confirmation in default mode
  if (options.isDestructive === true) {
    return 'ask';
  }

  return 'ask';
}

/**
 * Get a human-readable description of the current mode.
 * @returns {string}
 */
function getModeDescription() {
  switch (_mode) {
    case 'default':
      return 'Default: safe tools auto-approved, dangerous tools need confirmation';
    case 'auto':
      return 'Auto: all tools auto-approved (dangerous mode)';
    case 'bypass':
      return 'Bypass: all tools require explicit confirmation';
    default:
      return `Unknown mode: ${_mode}`;
  }
}

module.exports = {
  PERMISSION_MODES,
  getPermissionMode,
  setPermissionMode,
  cyclePermissionMode,
  checkPermission,
  getModeDescription,
  // Re-exports for convenience
  bashSecurity,
  rules,
};
