/**
 * Task Store — in-memory task state management with event emission.
 *
 * Central registry for all active and recently-completed tasks.
 * Provides CRUD operations, dependency tracking (blocks/blockedBy),
 * and an EventEmitter interface for reactive UI updates.
 *
 * Design:
 *   - Tasks are stored in a Map keyed by task ID.
 *   - State mutations go through updateTask() which validates transitions
 *     and emits change events.
 *   - Terminal tasks are kept for a configurable TTL before eviction
 *     (default: 5 minutes) so late-arriving UI polls can still read them.
 */
'use strict';

const { EventEmitter } = require('events');
const {
  generateTaskId,
  createTaskState,
  isTerminalStatus,
  isValidTaskStatus,
  isValidTaskType,
  TASK_STATUSES,
} = require('./index');
const { initTaskOutput, cleanupTaskOutput } = require('./diskOutput');

// ── Constants ──────────────────────────────────────────────────────────

/** How long to keep terminal tasks before auto-eviction (ms). */
const TERMINAL_TASK_TTL = 5 * 60 * 1000; // 5 minutes

/** Maximum number of tasks before oldest terminals are force-evicted. */
const MAX_TASKS = 500;

// ── Store ──────────────────────────────────────────────────────────────

const _tasks = new Map();
const _emitter = new EventEmitter();
_emitter.setMaxListeners(50);

let _evictionTimer = null;

// ── CRUD ───────────────────────────────────────────────────────────────

/**
 * Create a new task and register it in the store.
 *
 * @param {string} description - What the task does
 * @param {string} type        - Task type (local_bash, local_agent, etc.)
 * @param {object} [options]   - Extra fields: subject, activeForm, toolUseId
 * @returns {object} The created task state
 */
function createTask(description, type, options = {}) {
  if (!isValidTaskType(type)) {
    throw new Error(`Invalid task type: ${type}`);
  }

  // Enforce max tasks — evict oldest terminals first
  if (_tasks.size >= MAX_TASKS) {
    _evictOldestTerminal();
  }

  const id = generateTaskId(type);
  const task = createTaskState(id, type, description, options);

  // Initialize disk output file
  try {
    initTaskOutput(id);
  } catch {
    // Non-fatal — output file will be created on first write
  }

  _tasks.set(id, task);
  _emitter.emit('created', { taskId: id, task });
  _emitter.emit('change', { type: 'created', taskId: id, task });

  _scheduleEviction();
  return task;
}

/**
 * Get a task by ID.
 * @param {string} id
 * @returns {object|null}
 */
function getTask(id) {
  return _tasks.get(id) || null;
}

/**
 * List all tasks, optionally filtered.
 *
 * @param {object} [filter]
 * @param {string} [filter.status]  - Filter by status
 * @param {string} [filter.type]    - Filter by type
 * @param {string} [filter.owner]   - Filter by owner
 * @returns {object[]} Array of task states
 */
function listTasks(filter = {}) {
  let tasks = Array.from(_tasks.values());

  if (filter.status) {
    tasks = tasks.filter(t => t.status === filter.status);
  }
  if (filter.type) {
    tasks = tasks.filter(t => t.type === filter.type);
  }
  if (filter.owner) {
    tasks = tasks.filter(t => t.owner === filter.owner);
  }

  return tasks;
}

/**
 * Get a summary of all tasks for display.
 * @returns {object} { total, pending, running, completed, failed, killed, tasks: [...] }
 */
function getTaskSummary() {
  const tasks = Array.from(_tasks.values());
  const summary = {
    total: tasks.length,
    pending: 0,
    running: 0,
    completed: 0,
    failed: 0,
    killed: 0,
    tasks: [],
  };

  for (const task of tasks) {
    summary[task.status] = (summary[task.status] || 0) + 1;
    summary.tasks.push({
      id: task.id,
      type: task.type,
      status: task.status,
      subject: task.subject,
      description: task.description,
      startTime: task.startTime,
      endTime: task.endTime,
      owner: task.owner,
      blocks: task.blocks,
      blockedBy: task.blockedBy,
    });
  }

  return summary;
}

/**
 * Update a task's fields.
 *
 * Supports the following update keys:
 *   - status: Transition to a new status (validates the transition)
 *   - subject: Update the short title
 *   - description: Update the description
 *   - activeForm: Update the spinner text
 *   - owner: Assign/reassign owner
 *   - error: Set error message (typically with status='failed')
 *   - addBlocks: Add task IDs that this task blocks
 *   - addBlockedBy: Add task IDs that block this task
 *   - removeBlocks: Remove from blocks list
 *   - removeBlockedBy: Remove from blockedBy list
 *   - notified: Mark as notified
 *
 * @param {string} id      - Task ID
 * @param {object} updates - Fields to update
 * @returns {object|null} Updated task or null if not found
 */
function updateTask(id, updates) {
  const task = _tasks.get(id);
  if (!task) return null;

  // Guard: no updates to terminal tasks (except notified flag)
  if (isTerminalStatus(task.status) && updates.status === undefined && !('notified' in updates)) {
    return task;
  }

  const prev = { ...task };

  // Status transition
  if (updates.status !== undefined) {
    if (!isValidTaskStatus(updates.status)) {
      throw new Error(`Invalid status: ${updates.status}. Valid: ${TASK_STATUSES.join(', ')}`);
    }
    // Don't allow transitions FROM terminal states
    if (isTerminalStatus(task.status)) {
      throw new Error(`Cannot transition from terminal status '${task.status}'`);
    }
    task.status = updates.status;

    // Set endTime when entering a terminal state
    if (isTerminalStatus(updates.status)) {
      task.endTime = Date.now();
    }
  }

  // Simple field updates
  if (updates.subject !== undefined) task.subject = updates.subject;
  if (updates.description !== undefined) task.description = updates.description;
  if (updates.activeForm !== undefined) task.activeForm = updates.activeForm;
  if (updates.owner !== undefined) task.owner = updates.owner;
  if (updates.error !== undefined) task.error = updates.error;
  if (updates.notified !== undefined) task.notified = updates.notified;
  if (updates.outputOffset !== undefined) task.outputOffset = updates.outputOffset;

  // Dependency graph mutations
  if (updates.addBlocks) {
    const ids = Array.isArray(updates.addBlocks) ? updates.addBlocks : [updates.addBlocks];
    for (const blockId of ids) {
      if (!task.blocks.includes(blockId)) {
        task.blocks.push(blockId);
      }
      // Mirror: add this task to the other task's blockedBy
      const blocked = _tasks.get(blockId);
      if (blocked && !blocked.blockedBy.includes(id)) {
        blocked.blockedBy.push(id);
      }
    }
  }

  if (updates.addBlockedBy) {
    const ids = Array.isArray(updates.addBlockedBy) ? updates.addBlockedBy : [updates.addBlockedBy];
    for (const blockerId of ids) {
      if (!task.blockedBy.includes(blockerId)) {
        task.blockedBy.push(blockerId);
      }
      // Mirror: add this task to the blocker's blocks list
      const blocker = _tasks.get(blockerId);
      if (blocker && !blocker.blocks.includes(id)) {
        blocker.blocks.push(id);
      }
    }
  }

  if (updates.removeBlocks) {
    const ids = Array.isArray(updates.removeBlocks) ? updates.removeBlocks : [updates.removeBlocks];
    task.blocks = task.blocks.filter(b => !ids.includes(b));
    for (const blockId of ids) {
      const blocked = _tasks.get(blockId);
      if (blocked) {
        blocked.blockedBy = blocked.blockedBy.filter(b => b !== id);
      }
    }
  }

  if (updates.removeBlockedBy) {
    const ids = Array.isArray(updates.removeBlockedBy) ? updates.removeBlockedBy : [updates.removeBlockedBy];
    task.blockedBy = task.blockedBy.filter(b => !ids.includes(b));
    for (const blockerId of ids) {
      const blocker = _tasks.get(blockerId);
      if (blocker) {
        blocker.blocks = blocker.blocks.filter(b => b !== id);
      }
    }
  }

  _emitter.emit('updated', { taskId: id, task, prev });
  _emitter.emit('change', { type: 'updated', taskId: id, task, prev });

  return task;
}

/**
 * Delete a task from the store.
 *
 * Cleans up disk output and removes dependency references from other tasks.
 *
 * @param {string} id
 * @returns {boolean} true if the task existed and was removed
 */
function deleteTask(id) {
  const task = _tasks.get(id);
  if (!task) return false;

  // Remove dependency references from other tasks
  for (const blockId of task.blocks) {
    const blocked = _tasks.get(blockId);
    if (blocked) {
      blocked.blockedBy = blocked.blockedBy.filter(b => b !== id);
    }
  }
  for (const blockerId of task.blockedBy) {
    const blocker = _tasks.get(blockerId);
    if (blocker) {
      blocker.blocks = blocker.blocks.filter(b => b !== id);
    }
  }

  _tasks.delete(id);

  // Clean up disk output (best-effort)
  try {
    cleanupTaskOutput(id);
  } catch { /* non-fatal */ }

  _emitter.emit('deleted', { taskId: id, task });
  _emitter.emit('change', { type: 'deleted', taskId: id, task });

  return true;
}

// ── Bulk operations ────────────────────────────────────────────────────

/**
 * Kill all running tasks.
 * @returns {string[]} IDs of killed tasks
 */
function killAllRunning() {
  const killed = [];
  for (const [id, task] of _tasks) {
    if (task.status === 'running') {
      updateTask(id, { status: 'killed' });
      killed.push(id);
    }
  }
  return killed;
}

/**
 * Clear all terminal tasks from the store.
 * @returns {number} Number of tasks removed
 */
function clearTerminal() {
  let count = 0;
  for (const [id, task] of _tasks) {
    if (isTerminalStatus(task.status)) {
      deleteTask(id);
      count++;
    }
  }
  return count;
}

/**
 * Reset the entire store (for testing or session clear).
 */
function reset() {
  for (const id of Array.from(_tasks.keys())) {
    deleteTask(id);
  }
  _tasks.clear();
  if (_evictionTimer) {
    clearInterval(_evictionTimer);
    _evictionTimer = null;
  }
}

// ── Eviction ───────────────────────────────────────────────────────────

function _evictOldestTerminal() {
  let oldest = null;
  let oldestTime = Infinity;

  for (const [id, task] of _tasks) {
    if (isTerminalStatus(task.status) && task.endTime && task.endTime < oldestTime) {
      oldest = id;
      oldestTime = task.endTime;
    }
  }

  if (oldest) {
    deleteTask(oldest);
  }
}

function _scheduleEviction() {
  if (_evictionTimer) return;

  _evictionTimer = setInterval(() => {
    const now = Date.now();
    const toEvict = [];

    for (const [id, task] of _tasks) {
      if (isTerminalStatus(task.status) && task.endTime && (now - task.endTime) > TERMINAL_TASK_TTL) {
        toEvict.push(id);
      }
    }

    for (const id of toEvict) {
      deleteTask(id);
    }

    // Stop the timer if no more tasks need eviction
    const hasTerminal = Array.from(_tasks.values()).some(t => isTerminalStatus(t.status));
    if (!hasTerminal && _evictionTimer) {
      clearInterval(_evictionTimer);
      _evictionTimer = null;
    }
  }, 60_000); // Check every minute

  if (_evictionTimer.unref) _evictionTimer.unref();
}

// ── Event interface ────────────────────────────────────────────────────

/**
 * Subscribe to task state changes.
 *
 * Events:
 *   'created'  — { taskId, task }
 *   'updated'  — { taskId, task, prev }
 *   'deleted'  — { taskId, task }
 *   'change'   — { type, taskId, task, prev? } (catch-all)
 *
 * @param {string} event
 * @param {Function} listener
 * @returns {Function} Unsubscribe function
 */
function on(event, listener) {
  _emitter.on(event, listener);
  return () => _emitter.off(event, listener);
}

/**
 * Subscribe to a single event occurrence.
 * @param {string} event
 * @param {Function} listener
 */
function once(event, listener) {
  _emitter.once(event, listener);
}

module.exports = {
  createTask,
  getTask,
  listTasks,
  getTaskSummary,
  updateTask,
  deleteTask,
  killAllRunning,
  clearTerminal,
  reset,
  on,
  once,
  TERMINAL_TASK_TTL,
  MAX_TASKS,
};
