'use strict';

/**
 * retryWithBackoff.js — Exponential backoff retry with jitter.
 *
 * Ported from OpenClaw's retry.ts:
 *   - Configurable attempts, delay bounds, jitter
 *   - shouldRetry predicate for error classification
 *   - retryAfterMs parser for server backpressure (Retry-After header)
 *   - onRetry callback for telemetry
 *
 * Constants:
 *   DEFAULT_ATTEMPTS = 3
 *   DEFAULT_MIN_DELAY = 300ms
 *   DEFAULT_MAX_DELAY = 30000ms
 *   DEFAULT_JITTER = 1.0 (±100%)
 */

const DEFAULT_ATTEMPTS = 3;
const DEFAULT_MIN_DELAY = 300;
const DEFAULT_MAX_DELAY = 30000;
const DEFAULT_JITTER = 1.0;

/**
 * Execute a function with exponential backoff retry.
 *
 * @param {function} fn - Async function to execute
 * @param {object} [opts]
 * @param {number} [opts.attempts=3] - Max attempts (1 = no retry)
 * @param {number} [opts.minDelayMs=300] - Minimum delay between retries
 * @param {number} [opts.maxDelayMs=30000] - Maximum delay between retries
 * @param {number} [opts.jitter=1.0] - Jitter fraction [0,1]. 1.0 = ±100%
 * @param {string} [opts.label] - Diagnostic label for logging
 * @param {function} [opts.shouldRetry] - (err, attempt) => boolean. Default: always retry
 * @param {function} [opts.retryAfterMs] - (err) => number|undefined. Extract Retry-After from error
 * @param {function} [opts.onRetry] - (info: RetryInfo) => void. Called before each retry sleep
 * @param {AbortSignal} [opts.signal] - AbortSignal for cancellation
 * @returns {Promise<T>} Result of fn()
 */
async function retryWithBackoff(fn, opts = {}) {
  const {
    attempts = DEFAULT_ATTEMPTS,
    minDelayMs = DEFAULT_MIN_DELAY,
    maxDelayMs = DEFAULT_MAX_DELAY,
    jitter = DEFAULT_JITTER,
    label,
    shouldRetry,
    retryAfterMs,
    onRetry,
    signal,
  } = opts;

  const maxAttempts = Math.max(1, Math.floor(attempts));

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    // Check abort before each attempt
    if (signal?.aborted) {
      throw new Error(`Retry aborted${label ? ` (${label})` : ''}`);
    }

    try {
      return await fn(attempt);
    } catch (err) {
      // Last attempt — throw without retry
      if (attempt >= maxAttempts) throw err;

      // Check if error is retryable
      if (shouldRetry && !shouldRetry(err, attempt)) throw err;

      // Calculate delay
      let baseDelay;

      // Check for server-specified retry-after
      const serverDelay = retryAfterMs ? retryAfterMs(err) : undefined;
      if (serverDelay != null && serverDelay > 0) {
        baseDelay = Math.max(serverDelay, minDelayMs);
      } else {
        // Exponential backoff: minDelay * 2^(attempt-1)
        baseDelay = minDelayMs * Math.pow(2, attempt - 1);
      }

      // Apply jitter: ±(jitter * baseDelay)
      if (jitter > 0) {
        const jitterRange = jitter * baseDelay;
        baseDelay += (Math.random() * 2 - 1) * jitterRange;
      }

      // Clamp to [minDelayMs, maxDelayMs]
      const delayMs = Math.min(maxDelayMs, Math.max(minDelayMs, Math.round(baseDelay)));

      // Emit retry callback
      if (onRetry) {
        onRetry({
          attempt,
          maxAttempts,
          delayMs,
          err,
          label,
        });
      }

      // Sleep with abort support
      await _sleep(delayMs, signal);
    }
  }
}

/**
 * Parse Retry-After from HTTP-style errors.
 * Handles both seconds (integer) and date (HTTP-date) formats.
 *
 * @param {Error|object} err
 * @returns {number|undefined} milliseconds to wait
 */
function parseRetryAfter(err) {
  const header = err?.response?.headers?.['retry-after']
    || err?.headers?.['retry-after']
    || err?.retryAfter;

  if (header == null) return undefined;

  // Integer seconds
  const seconds = Number(header);
  if (!isNaN(seconds) && seconds > 0) {
    return Math.ceil(seconds * 1000);
  }

  // HTTP-date format
  try {
    const date = new Date(header);
    const ms = date.getTime() - Date.now();
    return ms > 0 ? ms : undefined;
  } catch {
    return undefined;
  }
}

/**
 * Common shouldRetry predicate for HTTP errors.
 * Retries on 429 (rate limit), 5xx (server error), network errors.
 *
 * @param {Error|object} err
 * @returns {boolean}
 */
function isRetryableError(err) {
  if (!err) return false;

  // Network errors
  if (err.code === 'ECONNRESET' || err.code === 'ETIMEDOUT' || err.code === 'ENOTFOUND') {
    return true;
  }

  // HTTP status codes
  const status = err.status || err.statusCode || err.response?.status;
  if (status === 429) return true; // Rate limited
  if (status >= 500 && status < 600) return true; // Server error

  // Anthropic/OpenAI overloaded
  if (err.type === 'overloaded_error') return true;
  if (/overloaded|rate.?limit|too.?many.?requests|capacity/i.test(err.message || '')) {
    return true;
  }

  return false;
}

function _sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    if (signal) {
      const onAbort = () => {
        clearTimeout(timer);
        reject(new Error('Retry sleep aborted'));
      };
      signal.addEventListener('abort', onAbort, { once: true });
      // Clean up listener after sleep completes
      const origResolve = resolve;
      resolve = () => {
        signal.removeEventListener('abort', onAbort);
        origResolve();
      };
    }
  });
}

module.exports = {
  retryWithBackoff,
  parseRetryAfter,
  isRetryableError,
  DEFAULT_ATTEMPTS,
  DEFAULT_MIN_DELAY,
  DEFAULT_MAX_DELAY,
  DEFAULT_JITTER,
};
