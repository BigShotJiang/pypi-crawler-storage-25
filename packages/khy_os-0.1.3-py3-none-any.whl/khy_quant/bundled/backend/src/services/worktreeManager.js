/**
 * Worktree Manager — Git worktree isolation for agents and CLI.
 *
 * Creates isolated git worktrees in .khy/worktrees/ so agents can work
 * on separate branches without affecting the main working tree.
 * Aligned with Claude Code's EnterWorktree/ExitWorktree architecture.
 */
const { execSync, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const WORKTREE_DIR_NAME = '.khy/worktrees';

/**
 * Generate a random worktree name.
 */
function generateWorktreeName() {
  const adjectives = ['swift', 'quiet', 'bright', 'bold', 'calm', 'cool', 'keen', 'warm'];
  const nouns = ['oak', 'river', 'hawk', 'stone', 'pine', 'wolf', 'star', 'flame'];
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun = nouns[Math.floor(Math.random() * nouns.length)];
  const suffix = crypto.randomBytes(3).toString('hex');
  return `${adj}-${noun}-${suffix}`;
}

/**
 * Validate a worktree name.
 */
function validateName(name) {
  if (!name || typeof name !== 'string') return false;
  if (name.length > 64) return false;
  return /^[a-zA-Z0-9._/-]+$/.test(name);
}

/**
 * Get the git root directory.
 */
function getGitRoot(cwd) {
  try {
    return execSync('git rev-parse --show-toplevel', {
      cwd: cwd || process.cwd(),
      encoding: 'utf-8',
    }).trim();
  } catch {
    return null;
  }
}

/**
 * Check if current directory is already inside a worktree.
 */
function isInsideWorktree(cwd) {
  try {
    const gitDir = execSync('git rev-parse --git-dir', {
      cwd: cwd || process.cwd(),
      encoding: 'utf-8',
    }).trim();
    return gitDir.includes('worktrees');
  } catch {
    return false;
  }
}

/**
 * Create a new worktree.
 *
 * @param {object} options
 * @param {string} [options.name] - Worktree name (auto-generated if not provided)
 * @param {string} [options.cwd] - Working directory (defaults to process.cwd())
 * @returns {{ path: string, branch: string, name: string }}
 */
function createWorktree(options = {}) {
  const cwd = options.cwd || process.cwd();
  const gitRoot = getGitRoot(cwd);
  if (!gitRoot) {
    throw new Error('Not inside a git repository');
  }

  if (isInsideWorktree(cwd)) {
    throw new Error('Already inside a git worktree');
  }

  const name = options.name || generateWorktreeName();
  if (!validateName(name)) {
    throw new Error(`Invalid worktree name: "${name}". Use letters, digits, dots, underscores, dashes; max 64 chars.`);
  }

  const worktreeBase = path.join(gitRoot, WORKTREE_DIR_NAME);
  const worktreePath = path.join(worktreeBase, name);
  const branchName = `khy-worktree/${name}`;

  if (fs.existsSync(worktreePath)) {
    throw new Error(`Worktree "${name}" already exists at ${worktreePath}`);
  }

  // Ensure base directory exists
  fs.mkdirSync(worktreeBase, { recursive: true });

  // Create worktree with a new branch based on HEAD
  const result = spawnSync('git', ['worktree', 'add', '-b', branchName, worktreePath], {
    cwd: gitRoot,
    encoding: 'utf-8',
    timeout: 30000,
  });

  if (result.status !== 0) {
    throw new Error(`Failed to create worktree: ${result.stderr || result.error}`);
  }

  return {
    path: worktreePath,
    branch: branchName,
    name,
    gitRoot,
  };
}

/**
 * Remove a worktree.
 *
 * @param {string} worktreePath - Absolute path to the worktree
 * @param {object} [options]
 * @param {boolean} [options.force=false] - Force removal even with changes
 * @returns {{ removed: boolean, uncommittedChanges: string[]|null }}
 */
function removeWorktree(worktreePath, options = {}) {
  if (!fs.existsSync(worktreePath)) {
    return { removed: true, uncommittedChanges: null };
  }

  // Check for uncommitted changes
  if (!options.force) {
    const statusResult = spawnSync('git', ['status', '--porcelain'], {
      cwd: worktreePath,
      encoding: 'utf-8',
      timeout: 10000,
    });

    if (statusResult.status === 0 && statusResult.stdout.trim()) {
      const changes = statusResult.stdout.trim().split('\n');
      return { removed: false, uncommittedChanges: changes };
    }
  }

  // Get the branch name before removing
  let branchName = null;
  try {
    branchName = execSync('git branch --show-current', {
      cwd: worktreePath,
      encoding: 'utf-8',
    }).trim();
  } catch { /* ignore */ }

  // Find git root from worktree
  let gitRoot = null;
  try {
    // Navigate to the main working tree
    const commonDir = execSync('git rev-parse --git-common-dir', {
      cwd: worktreePath,
      encoding: 'utf-8',
    }).trim();
    gitRoot = path.resolve(worktreePath, commonDir, '..');
  } catch { /* ignore */ }

  // Remove the worktree
  const forceFlag = options.force ? '--force' : '';
  const removeResult = spawnSync('git', ['worktree', 'remove', worktreePath, forceFlag].filter(Boolean), {
    cwd: gitRoot || path.dirname(worktreePath),
    encoding: 'utf-8',
    timeout: 30000,
  });

  if (removeResult.status !== 0) {
    // Try force if normal removal fails
    if (!options.force) {
      const forceRemove = spawnSync('git', ['worktree', 'remove', '--force', worktreePath], {
        cwd: gitRoot || path.dirname(worktreePath),
        encoding: 'utf-8',
        timeout: 30000,
      });
      if (forceRemove.status !== 0) {
        throw new Error(`Failed to remove worktree: ${forceRemove.stderr}`);
      }
    } else {
      throw new Error(`Failed to remove worktree: ${removeResult.stderr}`);
    }
  }

  // Delete the branch
  if (branchName && gitRoot) {
    try {
      spawnSync('git', ['branch', '-D', branchName], {
        cwd: gitRoot,
        encoding: 'utf-8',
        timeout: 10000,
      });
    } catch { /* branch cleanup is best-effort */ }
  }

  return { removed: true, uncommittedChanges: null };
}

/**
 * List all active worktrees.
 *
 * @param {string} [cwd] - Working directory
 * @returns {{ path: string, branch: string, head: string }[]}
 */
function listWorktrees(cwd) {
  const gitRoot = getGitRoot(cwd);
  if (!gitRoot) return [];

  try {
    const result = execSync('git worktree list --porcelain', {
      cwd: gitRoot,
      encoding: 'utf-8',
    });

    const worktrees = [];
    let current = {};

    for (const line of result.split('\n')) {
      if (line.startsWith('worktree ')) {
        if (current.path) worktrees.push(current);
        current = { path: line.slice(9) };
      } else if (line.startsWith('HEAD ')) {
        current.head = line.slice(5);
      } else if (line.startsWith('branch ')) {
        current.branch = line.slice(7);
      } else if (line === '') {
        if (current.path) worktrees.push(current);
        current = {};
      }
    }
    if (current.path) worktrees.push(current);

    // Filter to only .khy/worktrees/ entries
    return worktrees.filter(w => w.path.includes(WORKTREE_DIR_NAME));
  } catch {
    return [];
  }
}

module.exports = {
  createWorktree,
  removeWorktree,
  listWorktrees,
  isInsideWorktree,
  getGitRoot,
  generateWorktreeName,
  validateName,
};
