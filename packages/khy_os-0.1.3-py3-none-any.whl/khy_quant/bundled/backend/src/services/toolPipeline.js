'use strict';

/**
 * toolPipeline.js — 12-layer tool execution decorator pipeline.
 *
 * Ported from OpenClaw's pi-tool-definition-adapter.ts.
 * Wraps tool execution with a layered pipeline:
 *   1. ID normalization
 *   2. Name validation
 *   3. Before-hook (pre-execution plugins)
 *   4. Parameter coercion (type conversion)
 *   5. Parameter validation
 *   6. Rate limiting (per-tool)
 *   7. Execution (actual tool call)
 *   8. Result normalization
 *   9. Error handling (structured error wrapping)
 *  10. Output sanitization (credential/secret scrubbing)
 *  11. Result truncation (context guard)
 *  12. Diagnostic emission
 *
 * Usage:
 *   const pipeline = new ToolPipeline({ tools, diagnostics, usageTracker });
 *   const result = await pipeline.execute(toolName, params, context);
 */

const { diagnostics } = require('./diagnosticEvents');

// Patterns for credential scrubbing
const SECRET_PATTERNS = [
  /(?:api[_-]?key|token|secret|password|credential|auth)[=:]\s*["']?([^\s"',;}{]+)/gi,
  /(?:sk|pk|rk)-[a-zA-Z0-9]{20,}/g,      // API keys (Stripe, OpenAI style)
  /ghp_[a-zA-Z0-9]{36}/g,                  // GitHub PAT
  /glpat-[a-zA-Z0-9\-_]{20,}/g,            // GitLab PAT
  /(?:Bearer|Basic)\s+[a-zA-Z0-9+/=._\-]{20,}/gi,
  /-----BEGIN (?:RSA |EC )?PRIVATE KEY-----[\s\S]*?-----END/g,
];

// Reserved/dangerous tool names
const BLOCKED_TOOL_NAMES = new Set([
  '__proto__', 'constructor', 'prototype',
  'hasOwnProperty', 'toString', 'valueOf',
]);

class ToolPipeline {
  /**
   * @param {object} opts
   * @param {object} opts.tools - Tool definitions { name → { execute, schema? } }
   * @param {Array<function>} [opts.beforeHooks] - Pre-execution hooks: (toolName, params, ctx) => params|null
   * @param {Array<function>} [opts.afterHooks] - Post-execution hooks: (toolName, result, ctx) => result
   * @param {number} [opts.maxResultChars=50000] - Max result size before truncation
   * @param {boolean} [opts.enableDiagnostics=true] - Emit diagnostic events
   * @param {boolean} [opts.enableSanitization=true] - Scrub secrets from output
   */
  constructor(opts = {}) {
    this._tools = opts.tools || {};
    this._beforeHooks = opts.beforeHooks || [];
    this._afterHooks = opts.afterHooks || [];
    this._maxResultChars = opts.maxResultChars || 50_000;
    this._enableDiagnostics = opts.enableDiagnostics !== false;
    this._enableSanitization = opts.enableSanitization !== false;
    this._toolRateLimiters = new Map(); // toolName → { count, windowStart }
    this._toolRateLimitConfig = opts.rateLimits || {}; // toolName → { max, windowMs }
  }

  /**
   * Execute a tool through the full pipeline.
   *
   * @param {string} toolName - Tool name
   * @param {object} params - Tool parameters
   * @param {object} [context] - Execution context (traceId, sessionId, etc.)
   * @returns {Promise<ToolResult>}
   */
  async execute(toolName, params, context = {}) {
    const startTime = Date.now();
    let spanId = null;

    try {
      // Layer 1: ID normalization
      toolName = this._normalizeId(toolName);

      // Layer 2: Name validation
      this._validateName(toolName);

      // Layer 3: Before hooks
      params = await this._runBeforeHooks(toolName, params, context);
      if (params === null) {
        return this._buildResult(toolName, null, 'blocked_by_hook', startTime);
      }

      // Layer 4: Parameter coercion
      params = this._coerceParams(toolName, params);

      // Layer 5: Parameter validation
      this._validateParams(toolName, params);

      // Layer 6: Rate limiting
      const rateCheck = this._checkToolRateLimit(toolName);
      if (!rateCheck.allowed) {
        return this._buildResult(toolName, null,
          `Rate limited: retry after ${rateCheck.retryAfterMs}ms`, startTime);
      }

      // Layer 7: Diagnostic start
      if (this._enableDiagnostics) {
        spanId = diagnostics.emitToolCall(toolName, params, {
          traceId: context.traceId,
        });
      }

      // Layer 8: Execution
      const tool = this._tools[toolName];
      if (!tool || !tool.execute) {
        throw new ToolPipelineError(`Unknown tool: ${toolName}`, 'unknown_tool');
      }

      let result = await tool.execute(params, context);

      // Layer 9: Result normalization
      result = this._normalizeResult(result);

      // Layer 10: Error handling (result may contain error info)
      if (result.error) {
        result = this._handleError(toolName, result);
      }

      // Layer 11: Output sanitization
      if (this._enableSanitization) {
        result = this._sanitizeOutput(result);
      }

      // Layer 12: Result truncation
      result = this._truncateResult(result);

      // After hooks
      result = await this._runAfterHooks(toolName, result, context);

      // Diagnostic end
      if (this._enableDiagnostics && spanId) {
        diagnostics.emitToolResult(spanId, result, null, {
          traceId: context.traceId,
        });
      }

      return this._buildResult(toolName, result, null, startTime);

    } catch (err) {
      // Diagnostic error
      if (this._enableDiagnostics && spanId) {
        diagnostics.emitToolResult(spanId, null, err, {
          traceId: context.traceId,
        });
      }

      return this._buildResult(toolName, null, err, startTime);
    }
  }

  /**
   * Register a tool.
   */
  registerTool(name, tool) {
    this._tools[name] = tool;
  }

  /**
   * Add a before-hook.
   */
  addBeforeHook(hook) {
    this._beforeHooks.push(hook);
  }

  /**
   * Add an after-hook.
   */
  addAfterHook(hook) {
    this._afterHooks.push(hook);
  }

  // ── Pipeline layers ──

  /** Layer 1: Normalize tool ID (lowercase, strip prefix) */
  _normalizeId(name) {
    if (!name || typeof name !== 'string') return '';
    return name.trim().toLowerCase().replace(/^tool[_.-]/, '');
  }

  /** Layer 2: Validate tool name (no prototype pollution, etc.) */
  _validateName(name) {
    if (!name) throw new ToolPipelineError('Empty tool name', 'invalid_name');
    if (BLOCKED_TOOL_NAMES.has(name)) {
      throw new ToolPipelineError(`Blocked tool name: ${name}`, 'blocked_name');
    }
    if (!/^[a-z0-9_][a-z0-9_.\-]{0,63}$/.test(name)) {
      throw new ToolPipelineError(`Invalid tool name format: ${name}`, 'invalid_name');
    }
  }

  /** Layer 3: Run before-hooks */
  async _runBeforeHooks(toolName, params, context) {
    let current = params;
    for (const hook of this._beforeHooks) {
      const result = await hook(toolName, current, context);
      if (result === null || result === false) return null; // blocked
      if (result && typeof result === 'object') current = result;
    }
    return current;
  }

  /** Layer 4: Coerce parameter types based on tool schema */
  _coerceParams(toolName, params) {
    const tool = this._tools[toolName];
    if (!tool?.schema?.properties) return params;

    const coerced = { ...params };
    for (const [key, schema] of Object.entries(tool.schema.properties)) {
      if (coerced[key] === undefined) continue;

      if (schema.type === 'number' && typeof coerced[key] === 'string') {
        const num = Number(coerced[key]);
        if (!isNaN(num)) coerced[key] = num;
      } else if (schema.type === 'boolean' && typeof coerced[key] === 'string') {
        coerced[key] = coerced[key] === 'true' || coerced[key] === '1';
      } else if (schema.type === 'array' && typeof coerced[key] === 'string') {
        try { coerced[key] = JSON.parse(coerced[key]); } catch { /* keep as string */ }
      }
    }
    return coerced;
  }

  /** Layer 5: Validate required parameters */
  _validateParams(toolName, params) {
    const tool = this._tools[toolName];
    if (!tool?.schema?.required) return;

    for (const key of tool.schema.required) {
      if (params[key] === undefined || params[key] === null) {
        throw new ToolPipelineError(
          `Missing required parameter: ${key} for tool ${toolName}`,
          'missing_param'
        );
      }
    }
  }

  /** Layer 6: Per-tool rate limiting */
  _checkToolRateLimit(toolName) {
    const config = this._toolRateLimitConfig[toolName];
    if (!config) return { allowed: true };

    const now = Date.now();
    let state = this._toolRateLimiters.get(toolName);
    if (!state || now - state.windowStart >= config.windowMs) {
      state = { count: 0, windowStart: now };
      this._toolRateLimiters.set(toolName, state);
    }

    if (state.count >= config.max) {
      const retryAfterMs = config.windowMs - (now - state.windowStart);
      return { allowed: false, retryAfterMs };
    }

    state.count++;
    return { allowed: true };
  }

  /** Layer 9: Normalize result to standard shape */
  _normalizeResult(result) {
    if (result === null || result === undefined) {
      return { content: '', error: null };
    }
    if (typeof result === 'string') {
      return { content: result, error: null };
    }
    if (typeof result === 'object' && !result.content && !result.error) {
      return { content: JSON.stringify(result), error: null };
    }
    return result;
  }

  /** Layer 10: Structured error wrapping */
  _handleError(toolName, result) {
    return {
      ...result,
      content: result.content || `[Tool Error: ${toolName}] ${result.error}`,
      error: result.error,
      _errorWrapped: true,
    };
  }

  /** Layer 11: Scrub secrets from output */
  _sanitizeOutput(result) {
    if (!result.content || typeof result.content !== 'string') return result;

    let sanitized = result.content;
    for (const pattern of SECRET_PATTERNS) {
      // Reset lastIndex for global regexes
      pattern.lastIndex = 0;
      sanitized = sanitized.replace(pattern, '[REDACTED]');
    }

    if (sanitized !== result.content) {
      return { ...result, content: sanitized, _sanitized: true };
    }
    return result;
  }

  /** Layer 12: Truncate oversized results */
  _truncateResult(result) {
    if (!result.content || result.content.length <= this._maxResultChars) return result;

    const lastNewline = result.content.lastIndexOf('\n', this._maxResultChars);
    const cutPoint = lastNewline > this._maxResultChars * 0.7
      ? lastNewline
      : this._maxResultChars;

    const omitted = result.content.length - cutPoint;
    return {
      ...result,
      content: result.content.slice(0, cutPoint) + `\n[... ${omitted} chars truncated]`,
      _truncated: true,
      _omittedChars: omitted,
    };
  }

  /** After-hooks */
  async _runAfterHooks(toolName, result, context) {
    let current = result;
    for (const hook of this._afterHooks) {
      const modified = await hook(toolName, current, context);
      if (modified && typeof modified === 'object') current = modified;
    }
    return current;
  }

  /** Build standardized result */
  _buildResult(toolName, result, error, startTime) {
    const durationMs = Date.now() - startTime;
    return {
      toolName,
      success: !error,
      content: result?.content || '',
      error: error
        ? (error instanceof Error ? error.message : String(error))
        : null,
      errorCode: error instanceof ToolPipelineError ? error.code : null,
      durationMs,
      metadata: {
        truncated: result?._truncated || false,
        sanitized: result?._sanitized || false,
        omittedChars: result?._omittedChars || 0,
      },
    };
  }
}

class ToolPipelineError extends Error {
  constructor(message, code) {
    super(message);
    this.name = 'ToolPipelineError';
    this.code = code;
  }
}

// ── Global Hook Registry ──────────────────────────────────────────────
// Allows plugins to register hooks without needing a pipeline instance.
// Hooks registered here are automatically injected into every new ToolPipeline.

const _globalBeforeHooks = [];
const _globalAfterHooks = [];

/**
 * Register a global before-hook for all pipelines.
 * Hook signature: async (toolName, params, context) => params | null
 * Return null/false to block the tool call.
 * @param {function} fn
 */
function registerBeforeHook(fn) {
  if (typeof fn === 'function') _globalBeforeHooks.push(fn);
}

/**
 * Register a global after-hook for all pipelines.
 * Hook signature: async (toolName, result, context) => result
 * @param {function} fn
 */
function registerAfterHook(fn) {
  if (typeof fn === 'function') _globalAfterHooks.push(fn);
}

/**
 * Get all registered global hooks (for injection into pipeline constructor).
 * @returns {{ before: function[], after: function[] }}
 */
function getGlobalHooks() {
  return { before: [..._globalBeforeHooks], after: [..._globalAfterHooks] };
}

/**
 * Clear all global hooks (for testing).
 */
function clearGlobalHooks() {
  _globalBeforeHooks.length = 0;
  _globalAfterHooks.length = 0;
}

// Patch constructor to auto-inject global hooks
const _origConstructor = ToolPipeline.prototype.constructor;
const _origInit = ToolPipeline.prototype.constructor;
ToolPipeline.prototype._injectGlobalHooks = function () {
  for (const h of _globalBeforeHooks) {
    if (!this._beforeHooks.includes(h)) this._beforeHooks.push(h);
  }
  for (const h of _globalAfterHooks) {
    if (!this._afterHooks.includes(h)) this._afterHooks.push(h);
  }
};

// Override execute to ensure global hooks are always included
const _origExecute = ToolPipeline.prototype.execute;
ToolPipeline.prototype.execute = async function (toolName, params, context) {
  this._injectGlobalHooks();
  return _origExecute.call(this, toolName, params, context);
};

module.exports = {
  ToolPipeline,
  ToolPipelineError,
  SECRET_PATTERNS,
  BLOCKED_TOOL_NAMES,
  // Plugin hook registration API
  registerBeforeHook,
  registerAfterHook,
  getGlobalHooks,
  clearGlobalHooks,
};
