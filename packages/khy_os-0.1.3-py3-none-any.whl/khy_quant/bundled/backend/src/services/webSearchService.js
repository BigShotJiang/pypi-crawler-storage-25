/**
 * Web Search Service — search the web using Kiro's InvokeMCP API.
 *
 * Reuses kiroAdapter's auth token and SDK client infrastructure.
 * Calls Amazon Q Developer's InvokeMCP endpoint with the web_search tool.
 *
 * Reference: https://github.com/Colin3191/kiro-web-search
 */
const crypto = require('crypto');

const SEARCH_TIMEOUT_MS = 30_000;

// Lazy refs
let _kiroAdapter = null;

function getKiroAdapter() {
  if (!_kiroAdapter) {
    _kiroAdapter = require('./gateway/adapters/kiroAdapter');
  }
  return _kiroAdapter;
}

/**
 * Check if web search is available (Kiro token exists).
 * @returns {boolean}
 */
function isAvailable() {
  try {
    return getKiroAdapter().detect();
  } catch {
    return false;
  }
}

/**
 * Search the web using Kiro's remote MCP web_search tool.
 *
 * @param {string} query - Search query (max 200 characters)
 * @returns {Promise<{success: boolean, results?: object[], formatted?: string, error?: string}>}
 */
async function search(query) {
  if (!query || typeof query !== 'string') {
    return { success: false, error: 'Search query is required' };
  }

  // Enforce max length per API spec
  const trimmedQuery = query.trim().slice(0, 200);
  if (!trimmedQuery) {
    return { success: false, error: 'Search query is empty' };
  }

  try {
    const kiro = getKiroAdapter();
    const tokenData = await kiro.getAccessToken();
    const client = await kiro.createSDKClient(tokenData);
    const { InvokeMCPCommand, MCPMethod } = await kiro.getCWModule();

    const command = new InvokeMCPCommand({
      jsonrpc: '2.0',
      id: crypto.randomUUID(),
      method: MCPMethod.TOOLS_CALL,
      profileArn: tokenData.profileArn,
      params: {
        name: 'web_search',
        arguments: { query: trimmedQuery },
      },
    });

    // Race against timeout
    const response = await Promise.race([
      client.send(command),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Web search timed out (30s)')), SEARCH_TIMEOUT_MS)
      ),
    ]);

    if (response.error) {
      return {
        success: false,
        error: `Web search failed (code ${response.error.code}): ${response.error.message}`,
      };
    }

    // Parse and format results
    const { results, formatted } = formatResults(response.result);
    return { success: true, results, formatted };
  } catch (err) {
    // Clear cached client on auth errors
    if (err.message?.includes('401') || err.message?.includes('403') || err.message?.includes('expired')) {
      try { getKiroAdapter().destroy(); } catch { /* ignore */ }
    }
    return { success: false, error: err.message || 'Web search failed' };
  }
}

/**
 * Parse MCP response into structured results + formatted markdown.
 */
function formatResults(result) {
  const empty = { results: [], formatted: 'No results found.' };
  if (!result?.content) return empty;

  const textContent = result.content.find(c => c.type === 'text');
  if (!textContent?.text) return empty;

  try {
    const parsed = JSON.parse(textContent.text);
    if (!Array.isArray(parsed.results) || parsed.results.length === 0) {
      return { results: [], formatted: textContent.text };
    }

    const results = parsed.results.map(r => ({
      title: r.title || 'Untitled',
      url: r.url || '',
      snippet: r.snippet || '',
      publishedDate: r.publishedDate || '',
    }));

    const formatted = results.map((r, i) => {
      const parts = [`### ${i + 1}. ${r.title}`];
      if (r.url) parts.push(`   ${r.url}`);
      if (r.snippet) parts.push(`   ${r.snippet}`);
      if (r.publishedDate) parts.push(`   Published: ${r.publishedDate}`);
      return parts.join('\n');
    }).join('\n\n');

    return { results, formatted };
  } catch {
    return { results: [], formatted: textContent.text };
  }
}

/**
 * Fallback search via DuckDuckGo HTML (no API key needed).
 * Used when Kiro token is unavailable.
 */
async function searchFallback(query) {
  const https = require('https');
  const trimmedQuery = String(query || '').trim().slice(0, 200);
  if (!trimmedQuery) return { success: false, error: 'Search query is empty' };

  return new Promise((resolve) => {
    const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(trimmedQuery)}`;
    const req = https.get(url, {
      headers: { 'User-Agent': 'KHY-OS/1.0 (search fallback)' },
      timeout: 15000,
    }, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          // Extract result snippets from DuckDuckGo HTML
          const results = [];
          const re = /<a[^>]*class="result__a"[^>]*href="([^"]*)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/a>/gi;
          let m;
          while ((m = re.exec(data)) !== null && results.length < 5) {
            const rawUrl = decodeURIComponent(String(m[1] || '').replace(/.*uddg=/, '').replace(/&.*/, ''));
            const title = String(m[2] || '').replace(/<[^>]*>/g, '').trim();
            const snippet = String(m[3] || '').replace(/<[^>]*>/g, '').trim();
            if (title && rawUrl) results.push({ title, url: rawUrl, snippet, publishedDate: '' });
          }
          if (results.length === 0) {
            resolve({ success: true, results: [], formatted: 'No results found.' });
            return;
          }
          const formatted = results.map((r, i) => {
            const parts = [`### ${i + 1}. ${r.title}`];
            if (r.url) parts.push(`   ${r.url}`);
            if (r.snippet) parts.push(`   ${r.snippet}`);
            return parts.join('\n');
          }).join('\n\n');
          resolve({ success: true, results, formatted });
        } catch (err) {
          resolve({ success: false, error: `Search parse error: ${err.message}` });
        }
      });
    });
    req.on('error', (err) => resolve({ success: false, error: `Search failed: ${err.message}` }));
    req.on('timeout', () => { req.destroy(); resolve({ success: false, error: 'Search timed out' }); });
  });
}

/**
 * Unified search: try Kiro MCP first, fall back to DuckDuckGo HTML.
 */
async function searchUnified(query) {
  // Try Kiro-based search first
  if (isAvailable()) {
    const result = await search(query);
    if (result.success) return result;
  }
  // Fallback to DuckDuckGo
  return searchFallback(query);
}

module.exports = { search: searchUnified, searchDirect: search, searchFallback, isAvailable, formatResults };
