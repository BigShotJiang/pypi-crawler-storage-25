/**
 * Tool Sandbox — enhanced sandboxed execution with per-tool resource limits.
 *
 * Wraps Node.js vm module and child_process with:
 * - Configurable timeout per risk level
 * - Output size caps
 * - Command whitelist/blacklist for shell execution
 * - Memory measurement
 *
 * Extends (does not replace) resourceGuard.js's safeExec.
 */
const vm = require('vm');
const { execSync } = require('child_process');
const path = require('path');

// ── Default limits per risk level ───────────────────────────────────

const DEFAULT_LIMITS = {
  safe:     { timeoutMs: 10000,  maxOutputBytes: 1048576,  maxMemoryMB: 100 },
  low:      { timeoutMs: 30000,  maxOutputBytes: 5242880,  maxMemoryMB: 200 },
  medium:   { timeoutMs: 60000,  maxOutputBytes: 10485760, maxMemoryMB: 300 },
  high:     { timeoutMs: 120000, maxOutputBytes: 10485760, maxMemoryMB: 500 },
  critical: { timeoutMs: 120000, maxOutputBytes: 10485760, maxMemoryMB: 500 },
};

// Commands that are always blocked (destructive / dangerous)
const BLOCKED_COMMANDS = [
  'rm -rf /',
  'rm -rf ~',
  'rm -rf /*',
  'mkfs',
  'dd if=',
  ':(){:|:&};:',   // fork bomb
  'chmod -R 777 /',
  'wget|sh',
  'curl|sh',
  'curl|bash',
  'wget|bash',
];

// Paths that should never be written to
const BLOCKED_PATHS = [
  '/etc/',
  '/usr/',
  '/bin/',
  '/sbin/',
  '/boot/',
  '/proc/',
  '/sys/',
];

// ── Sandboxed Code Execution ────────────────────────────────────────

/**
 * Execute JavaScript code in a sandboxed VM context.
 *
 * @param {string} code - JavaScript code to execute
 * @param {object} [limits]
 * @param {number} [limits.timeoutMs=5000] - Execution timeout
 * @param {number} [limits.maxOutputBytes=1048576] - Max output size
 * @returns {{ success: boolean, result?: any, output?: string, error?: string, elapsed: number }}
 */
function sandboxedExec(code, limits = {}) {
  const timeout = Math.min(limits.timeoutMs || 5000, 120000);
  const maxOutput = limits.maxOutputBytes || 1048576; // 1MB default

  const start = Date.now();
  const output = [];
  let totalOutputBytes = 0;

  // Create sandbox with limited globals
  const sandbox = {
    console: {
      log: (...args) => {
        const line = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
        totalOutputBytes += Buffer.byteLength(line, 'utf-8');
        if (totalOutputBytes <= maxOutput) {
          output.push(line);
        }
      },
      error: (...args) => {
        const line = args.map(a => String(a)).join(' ');
        totalOutputBytes += Buffer.byteLength(line, 'utf-8');
        if (totalOutputBytes <= maxOutput) {
          output.push(`[ERROR] ${line}`);
        }
      },
      warn: (...args) => {
        const line = args.map(a => String(a)).join(' ');
        totalOutputBytes += Buffer.byteLength(line, 'utf-8');
        if (totalOutputBytes <= maxOutput) {
          output.push(`[WARN] ${line}`);
        }
      },
    },
    Math,
    Date,
    JSON,
    parseInt,
    parseFloat,
    isNaN,
    isFinite,
    Array,
    Object,
    String,
    Number,
    Boolean,
    Map,
    Set,
    RegExp,
    Error,
    Promise,
    setTimeout: undefined,  // Blocked
    setInterval: undefined, // Blocked
    require: undefined,     // Blocked
    process: undefined,     // Blocked
    global: undefined,      // Blocked
  };

  try {
    const context = vm.createContext(sandbox);
    const script = new vm.Script(code, { filename: 'sandbox.js' });
    const result = script.runInContext(context, { timeout });

    const elapsed = Date.now() - start;
    const outputText = output.join('\n');
    const truncated = totalOutputBytes > maxOutput;

    return {
      success: true,
      result: _serializeResult(result),
      output: truncated ? outputText + `\n... (output truncated at ${maxOutput} bytes)` : outputText,
      elapsed,
      truncated,
    };
  } catch (err) {
    return {
      success: false,
      error: err.message,
      output: output.join('\n'),
      elapsed: Date.now() - start,
    };
  }
}

// ── Sandboxed Shell Execution ───────────────────────────────────────

/**
 * Execute a shell command with safety checks and output limits.
 *
 * @param {string} command - Shell command
 * @param {object} [limits]
 * @param {number} [limits.timeoutMs=30000] - Execution timeout
 * @param {number} [limits.maxOutputBytes=5242880] - Max output size (5MB)
 * @param {string[]} [limits.allowedCommands] - If set, only these command prefixes are allowed
 * @param {string} [limits.cwd] - Working directory
 * @returns {{ success: boolean, output?: string, error?: string, elapsed: number }}
 */
function sandboxedShell(command, limits = {}) {
  const timeout = Math.min(limits.timeoutMs || 30000, 120000);
  const maxOutput = limits.maxOutputBytes || 5242880;
  const cwd = limits.cwd || process.env.KHYQUANT_CWD || process.cwd();

  // Security: check blocked patterns
  const cmdLower = command.toLowerCase().trim();
  for (const blocked of BLOCKED_COMMANDS) {
    if (cmdLower.includes(blocked.toLowerCase())) {
      return {
        success: false,
        error: `Blocked: command contains dangerous pattern "${blocked}"`,
        elapsed: 0,
      };
    }
  }

  // Security: check blocked paths in write commands
  const writePatterns = /\b(rm|rmdir|mv|cp|chmod|chown|ln)\b/i;
  if (writePatterns.test(command)) {
    for (const blockedPath of BLOCKED_PATHS) {
      if (command.includes(blockedPath)) {
        return {
          success: false,
          error: `Blocked: cannot modify system path "${blockedPath}"`,
          elapsed: 0,
        };
      }
    }
  }

  // Allowed commands whitelist (if configured)
  if (limits.allowedCommands && Array.isArray(limits.allowedCommands)) {
    const cmdPrefix = command.split(/\s+/)[0];
    if (!limits.allowedCommands.includes(cmdPrefix)) {
      return {
        success: false,
        error: `Blocked: "${cmdPrefix}" is not in allowed commands list`,
        elapsed: 0,
      };
    }
  }

  const start = Date.now();

  try {
    const output = execSync(command, {
      cwd,
      timeout,
      encoding: 'utf-8',
      maxBuffer: maxOutput,
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    const elapsed = Date.now() - start;
    const truncated = Buffer.byteLength(output, 'utf-8') >= maxOutput;

    return {
      success: true,
      output: truncated ? output.slice(0, maxOutput) + '\n... (output truncated)' : output,
      elapsed,
      truncated,
    };
  } catch (err) {
    return {
      success: false,
      error: err.message,
      output: err.stdout ? String(err.stdout).slice(0, maxOutput) : '',
      stderr: err.stderr ? String(err.stderr).slice(0, 2000) : '',
      elapsed: Date.now() - start,
    };
  }
}

// ── Limit Configuration ─────────────────────────────────────────────

/**
 * Get default resource limits for a tool based on its risk level.
 *
 * @param {string} toolName - Tool name (for potential overrides)
 * @param {string} risk - Risk level
 * @returns {object} Resource limits
 */
function getToolLimits(toolName, risk) {
  const base = DEFAULT_LIMITS[risk] || DEFAULT_LIMITS.medium;
  return { ...base };
}

// ── Internal helpers ────────────────────────────────────────────────

function _serializeResult(result) {
  if (result === undefined) return undefined;
  if (result === null) return null;
  if (typeof result === 'string' || typeof result === 'number' || typeof result === 'boolean') {
    return result;
  }
  try {
    const json = JSON.stringify(result);
    if (json.length > 10000) {
      return json.slice(0, 10000) + '... (truncated)';
    }
    return JSON.parse(json); // Round-trip to strip non-serializable values
  } catch {
    return String(result);
  }
}

// ── ANOLISA-aligned Command Classification ────────────────────────
// Classifies any shell command into a risk tier for sandbox policy decision.

const COMMAND_CLASSIFICATIONS = {
  // Safe: read-only, no side effects
  safe: [
    'ls', 'cat', 'head', 'tail', 'wc', 'echo', 'pwd', 'whoami', 'id', 'date',
    'uname', 'hostname', 'which', 'file', 'stat', 'du', 'df', 'env', 'printenv',
    'grep', 'rg', 'find', 'locate', 'tree', 'less', 'more', 'sort', 'uniq',
    'diff', 'md5sum', 'sha256sum', 'base64', 'xxd', 'hexdump', 'strings',
    'git status', 'git log', 'git diff', 'git branch', 'git show', 'git remote',
    'node --version', 'npm --version', 'python --version', 'moon version',
    // Windows equivalents
    'dir', 'type', 'where', 'ver', 'systeminfo',
  ],
  // Moderate: may modify user files, non-destructive
  moderate: [
    'cp', 'mv', 'touch', 'mkdir', 'ln', 'tar', 'zip', 'unzip', 'gzip', 'gunzip',
    'git add', 'git commit', 'git checkout', 'git merge', 'git stash',
    'npm install', 'npm run', 'pip install', 'moon build', 'moon test',
    'make', 'cargo build', 'go build',
    'sed', 'awk', 'tee', 'xargs',
    // Windows
    'copy', 'move', 'md', 'xcopy',
  ],
  // Dangerous: may cause data loss or affect system
  dangerous: [
    'rm', 'rmdir', 'chmod', 'chown', 'kill', 'pkill', 'killall',
    'apt', 'yum', 'dnf', 'pacman', 'brew',
    'npm uninstall', 'pip uninstall',
    'git push', 'git reset', 'git rebase', 'git clean',
    'docker', 'podman', 'systemctl', 'service',
    'crontab', 'at',
    // Windows
    'del', 'rd', 'icacls', 'taskkill', 'sc', 'net',
  ],
  // Critical: always blocked unless explicitly approved
  critical: [
    'dd', 'mkfs', 'fdisk', 'parted', 'mount', 'umount',
    'sudo', 'su', 'passwd',
    'iptables', 'firewall-cmd', 'ufw',
    'reboot', 'shutdown', 'init', 'halt', 'poweroff',
    'nc -e', 'ncat -e', 'socat',
    'curl|sh', 'wget|sh', 'curl|bash', 'wget|bash',
    // Windows
    'format', 'diskpart', 'shutdown', 'bcdedit',
  ],
};

/**
 * Classify a command into a risk tier.
 * Aligned with ANOLISA Agent Sec Core sandbox policy:
 *   safe       → read-only sandbox
 *   moderate   → workspace-write sandbox
 *   dangerous  → user confirmation required
 *   critical   → blocked unless approved
 *   unknown    → treated as moderate
 *
 * @param {string} command - Shell command to classify
 * @returns {{ tier: string, command: string, matchedRule: string|null }}
 */
function classifyCommand(command) {
  if (!command || typeof command !== 'string') {
    return { tier: 'unknown', command: '', matchedRule: null };
  }

  const trimmed = command.trim();
  const lower = trimmed.toLowerCase();

  // Check from most dangerous to least
  for (const tier of ['critical', 'dangerous', 'moderate', 'safe']) {
    for (const pattern of COMMAND_CLASSIFICATIONS[tier]) {
      if (lower.startsWith(pattern.toLowerCase()) || lower.includes(pattern.toLowerCase())) {
        return { tier, command: trimmed, matchedRule: pattern };
      }
    }
  }

  return { tier: 'unknown', command: trimmed, matchedRule: null };
}

/**
 * Get sandbox policy based on command classification.
 * @param {string} tier - Classification tier
 * @returns {{ allowed: boolean, requiresApproval: boolean, sandboxMode: string, limits: object }}
 */
function getSandboxPolicy(tier) {
  switch (tier) {
    case 'safe':
      return {
        allowed: true,
        requiresApproval: false,
        sandboxMode: 'read-only',
        limits: DEFAULT_LIMITS.safe,
      };
    case 'moderate':
      return {
        allowed: true,
        requiresApproval: false,
        sandboxMode: 'workspace-write',
        limits: DEFAULT_LIMITS.low,
      };
    case 'dangerous':
      return {
        allowed: true,
        requiresApproval: true,
        sandboxMode: 'workspace-write',
        limits: DEFAULT_LIMITS.medium,
      };
    case 'critical':
      return {
        allowed: false,
        requiresApproval: true,
        sandboxMode: 'full-access',
        limits: DEFAULT_LIMITS.critical,
      };
    default:
      return {
        allowed: true,
        requiresApproval: false,
        sandboxMode: 'workspace-write',
        limits: DEFAULT_LIMITS.low,
      };
  }
}

module.exports = {
  sandboxedExec,
  sandboxedShell,
  getToolLimits,
  DEFAULT_LIMITS,
  BLOCKED_COMMANDS,
  // ANOLISA-aligned command classification
  classifyCommand,
  getSandboxPolicy,
  COMMAND_CLASSIFICATIONS,
};
