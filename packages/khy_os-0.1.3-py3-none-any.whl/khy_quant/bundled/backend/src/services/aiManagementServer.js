/**
 * AI Management Backend Server
 *
 * Standalone HTTP + WebSocket server on a separate port (default 9090).
 * Acts as a "web branch" of the CLI — same AI gateway, adapters, tools,
 * security, and token tracking, but accessible over REST and WS.
 *
 * Pattern: raw http.createServer (like proxyServer.js), no Express dependency.
 * Exports: { start, stop, isRunning, getPort }
 */
const http = require('http');
const crypto = require('crypto');
const { URL } = require('url');
const path = require('path');
const fs = require('fs');
const { getDataHome } = require('../utils/dataHome');

// ── Module state ──────────────────────────────────────────────
let _server = null;
let _wss = null;
const _sessions = new Map();
let _startTime = 0;
let _port = 0;
let _heartbeatTimer = null;
let _autoImportLastAt = 0;
let _autoImportSummary = null;
let _lastGatewayAssetsSnapshot = null;

const SESSION_IDLE_MS = 30 * 60 * 1000; // 30 min idle timeout
const AUTH_TIMEOUT_MS = 30 * 1000;       // 30s to authenticate
const GC_INTERVAL_MS = 30 * 1000;        // 30s heartbeat / GC sweep
const MAX_BODY_BYTES = 1 * 1024 * 1024;  // 1 MB body limit
const KHY_DIR = getDataHome();
const CONVO_DIR = path.join(KHY_DIR, 'conversations');
const ACCOUNT_CB_FILE = path.join(KHY_DIR, 'account_pool_circuit_breaker.json');
const AUTO_IMPORT_INTERVAL_MS = Math.max(
  15000,
  parseInt(process.env.AI_GATEWAY_AUTO_IMPORT_INTERVAL_MS || '60000', 10) || 60000
);
const AUTO_IMPORT_ACCOUNT_PROVIDERS = ['kiro', 'cursor', 'trae', 'windsurf', 'warp', 'nirvana'];
const DEFAULT_ACCOUNT_CIRCUIT_BREAKER = Object.freeze({
  enabled: false,
  backoffSteps: [60, 300, 1800, 7200],
});
const DEFAULT_PLUGIN_TEMPLATE = `/**
 * Gateway Plugin Template
 * Hooks: onBeforeRequest, onAfterResponse, onError, onStream
 */
module.exports = {
  name: 'my-plugin',
  priority: 100,
  enabled: true,
  hooks: {
    async onBeforeRequest(ctx, next) {
      return next(ctx);
    },
    async onAfterResponse(ctx, next) {
      return next(ctx);
    },
    async onError(ctx, next) {
      return next(ctx);
    },
    onStream(chunk) {
      return chunk;
    },
  },
};
`;

// In-memory rate limiter
const _rateLimits = new Map(); // ip -> { count, windowStart }

// ── Lazy module loaders ───────────────────────────────────────
let _gateway, _ai, _toolCalling, _security, _tokenUsage;
let _apiKeyPool, _accountPool, _aiMonitor, _oauthManager;
let _pluginChain, _tlsSidecar, _protocolConverter, _concurrencySlots;
let _proxyServer, _customerRegistry, _modelRouter;

function getGateway() { return (_gateway ??= require('./gateway/aiGateway')); }
function getAi() { return (_ai ??= require('../cli/ai')); }
function getToolCalling() { return (_toolCalling ??= require('./toolCalling')); }
function getSecurity() { return (_security ??= require('./securityGuardService')); }
function getTokenUsage() { return (_tokenUsage ??= require('./tokenUsageService')); }
function getApiKeyPool() { return (_apiKeyPool ??= require('./apiKeyPool')); }
function getAccountPool() { return (_accountPool ??= require('./accountPool')); }
function getAiMonitor() { return (_aiMonitor ??= require('./aiMonitor')); }
function getOauthManager() { return (_oauthManager ??= require('./gateway/oauthManager')); }
function getPluginChain() { return (_pluginChain ??= require('./gateway/pluginChain')); }
function getTlsSidecar() { return (_tlsSidecar ??= require('./gateway/tlsSidecar')); }
function getProtocolConverter() { return (_protocolConverter ??= require('./gateway/protocolConverter')); }
function getConcurrencySlots() { return (_concurrencySlots ??= require('./concurrencySlots')); }
function getProxyServer() { return (_proxyServer ??= require('./gateway/proxyServer')); }
function getCustomerRegistry() { return (_customerRegistry ??= require('./gateway/customerRegistry')); }
function getModelRouter() { return (_modelRouter ??= require('./gateway/modelRouter')); }

// ── Utility functions ─────────────────────────────────────────

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    let bytes = 0;
    req.on('data', chunk => {
      bytes += chunk.length;
      if (bytes > MAX_BODY_BYTES) {
        req.destroy();
        reject(new Error('Body too large'));
        return;
      }
      data += chunk;
    });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function corsHeaders() {
  const origins = process.env.AI_MGMT_CORS_ORIGINS || '*';
  return {
    'Access-Control-Allow-Origin': origins,
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-API-Key',
    'Access-Control-Max-Age': '86400',
  };
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    ...corsHeaders(),
  });
  res.end(body);
}

function sendError(res, status, message) {
  sendJson(res, status, { success: false, error: message });
}

function getClientIp(req) {
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim()
    || req.socket?.remoteAddress
    || '127.0.0.1';
}

function isLocalIp(ip) {
  return ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1'
    || ip.startsWith('192.168.') || ip.startsWith('10.')
    || /^172\.(1[6-9]|2\d|3[01])\./.test(ip);
}

function safeJsonParse(raw, fallback = {}) {
  try {
    const parsed = JSON.parse(raw);
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}

function normalizeCircuitBreakerConfig(input = {}) {
  const src = (input && typeof input === 'object') ? input : {};
  const enabled = src.enabled === true;
  const backoffSteps = Array.isArray(src.backoffSteps)
    ? src.backoffSteps.map(n => parseInt(n, 10)).filter(n => Number.isFinite(n) && n > 0)
    : [];
  return {
    enabled,
    backoffSteps: backoffSteps.length > 0
      ? [...new Set(backoffSteps)]
      : [...DEFAULT_ACCOUNT_CIRCUIT_BREAKER.backoffSteps],
  };
}

function readAccountCircuitBreakerConfig() {
  try {
    if (!fs.existsSync(ACCOUNT_CB_FILE)) {
      return { ...DEFAULT_ACCOUNT_CIRCUIT_BREAKER };
    }
    const parsed = safeJsonParse(fs.readFileSync(ACCOUNT_CB_FILE, 'utf-8'), DEFAULT_ACCOUNT_CIRCUIT_BREAKER);
    return normalizeCircuitBreakerConfig(parsed);
  } catch {
    return { ...DEFAULT_ACCOUNT_CIRCUIT_BREAKER };
  }
}

function saveAccountCircuitBreakerConfig(next = {}) {
  const normalized = normalizeCircuitBreakerConfig(next);
  fs.mkdirSync(path.dirname(ACCOUNT_CB_FILE), { recursive: true });
  const tmpPath = `${ACCOUNT_CB_FILE}.tmp.${Date.now()}`;
  fs.writeFileSync(tmpPath, JSON.stringify(normalized, null, 2), 'utf-8');
  fs.renameSync(tmpPath, ACCOUNT_CB_FILE);
  return normalized;
}

function sanitizePluginName(raw) {
  return String(raw || '').trim().replace(/\.js$/i, '');
}

function getPluginFilePath(pluginName) {
  const normalized = sanitizePluginName(pluginName);
  if (!/^[a-zA-Z0-9_-]+$/.test(normalized)) {
    throw new Error('invalid plugin name');
  }
  const chain = getPluginChain();
  return path.join(chain.getPluginsDir(), `${normalized}.js`);
}

// ── Authentication ────────────────────────────────────────────

/**
 * Authenticate an HTTP request or WebSocket token.
 * Dual-mode: Full (JWT + API Key via DB) or Lightweight (env token).
 * @param {string|null} bearerToken - Bearer token from Authorization header
 * @param {string|null} apiKey - X-API-Key header value
 * @returns {Promise<{ ok: boolean, user?: object, method?: string, error?: string }>}
 */
async function authenticate(bearerToken, apiKey) {
  // Dev bypass
  if (process.env.AI_MGMT_SKIP_AUTH === 'true' && process.env.NODE_ENV !== 'production') {
    return { ok: true, user: { id: 0, role: 'admin' }, method: 'skip' };
  }

  // Lightweight mode: simple token comparison
  const envToken = process.env.AI_MGMT_AUTH_TOKEN;
  if (envToken) {
    if (bearerToken === envToken) return { ok: true, user: { id: 0, role: 'user' }, method: 'token' };
    if (apiKey === envToken) return { ok: true, user: { id: 0, role: 'user' }, method: 'token' };
    // If env token is set, only accept that token (don't fall through to DB)
    return { ok: false, error: 'Invalid token' };
  }

  // Full mode: JWT + API Key via Sequelize models
  if (process.env.JWT_SECRET) {
    try {
      const jwt = require('jsonwebtoken');
      const { User, ApiKey: ApiKeyModel } = require('../models');

      // Path A: JWT Bearer
      if (bearerToken) {
        try {
          const decoded = jwt.verify(bearerToken, process.env.JWT_SECRET);
          const user = await User.findByPk(decoded.userId);
          if (!user) return { ok: false, error: 'User not found' };
          if (user.status !== 'active') return { ok: false, error: 'Account disabled' };
          return { ok: true, user, method: 'jwt' };
        } catch { /* JWT invalid — fall through */ }
      }

      // Path B: X-API-Key
      if (apiKey) {
        const record = await ApiKeyModel.findOne({
          where: { key: apiKey, isActive: true },
          include: [{ model: User, as: 'user' }],
        });
        if (!record?.user) return { ok: false, error: 'Invalid API key' };
        if (record.user.status !== 'active') return { ok: false, error: 'Account disabled' };
        record.update({ lastUsedAt: new Date() }).catch(() => {});
        return { ok: true, user: record.user, method: 'apiKey' };
      }
    } catch {
      // Models not available (CLI-only mode) — no auth possible
    }
  }

  // No auth mechanism configured + no token provided
  // In development without explicit config, allow localhost access
  return { ok: false, error: 'Authentication required (set AI_MGMT_AUTH_TOKEN or JWT_SECRET)' };
}

/**
 * Authenticate an HTTP request. Extracts credentials from headers.
 */
async function authenticateRequest(req) {
  const bearerToken = req.headers.authorization?.split(' ')[1] || null;
  const apiKey = req.headers['x-api-key'] || null;
  return authenticate(bearerToken, apiKey);
}

function sanitizeAuthUser(user) {
  if (!user) return null;
  if (typeof user.toJSON === 'function') {
    const data = user.toJSON();
    if (data && typeof data === 'object') {
      delete data.password;
      delete data.securityAnswer;
      delete data.sendKey;
    }
    return data;
  }
  return {
    id: user.id ?? 0,
    username: user.username || 'user',
    email: user.email || '',
    role: user.role || 'user',
    status: user.status || 'active',
  };
}

async function verifyAuthPassword(user, password) {
  if (!user || typeof user.comparePassword !== 'function') return false;
  let isValid = await user.comparePassword(password);

  // Compatibility bridge: allow historical default admin password without trailing dot.
  if (!isValid && String(user.username || '').toLowerCase() === 'admin' && password === 'admin123') {
    const legacyMatched = await user.comparePassword('admin123.');
    if (legacyMatched) {
      isValid = true;
      try {
        await user.update({ password: 'admin123' });
      } catch {
        // best effort password migration
      }
    }
  }
  return isValid;
}

function issueAuthJwt(userId) {
  const jwt = require('jsonwebtoken');
  return jwt.sign(
    { userId },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

async function handleAuthLogin(req, res) {
  const body = await parseBody(req);
  const username = String(body.username || '').trim();
  const password = String(body.password || '');

  if (!username || !password) {
    return sendJson(res, 400, { success: false, message: 'Username and password are required' });
  }

  const envToken = String(process.env.AI_MGMT_AUTH_TOKEN || '').trim();
  if (envToken) {
    if (password === envToken || username === envToken) {
      return sendJson(res, 200, {
        success: true,
        message: 'Login successful',
        data: {
          token: envToken,
          user: { id: 0, username: 'token-user', role: 'user', status: 'active' },
        },
      });
    }
    return sendJson(res, 401, { success: false, message: 'Invalid username or password' });
  }

  if (process.env.AI_MGMT_SKIP_AUTH === 'true' && process.env.NODE_ENV !== 'production') {
    const fakeToken = process.env.AI_MGMT_DEV_TOKEN || 'ai-mgmt-skip-auth';
    return sendJson(res, 200, {
      success: true,
      message: 'Login successful',
      data: {
        token: fakeToken,
        user: { id: 0, username: username || 'dev-admin', role: 'admin', status: 'active' },
      },
    });
  }

  if (!process.env.JWT_SECRET) {
    return sendJson(res, 500, {
      success: false,
      message: 'JWT_SECRET is not configured for username/password login',
    });
  }

  try {
    const { Op } = require('sequelize');
    const { User } = require('../models');
    const user = await User.findOne({
      where: {
        [Op.or]: [
          { username },
          { email: username },
        ],
      },
    });

    if (!user) {
      return sendJson(res, 401, { success: false, message: 'Invalid username or password' });
    }
    if (user.status !== 'active') {
      return sendJson(res, 403, { success: false, message: 'Account is not active' });
    }

    const isPasswordValid = await verifyAuthPassword(user, password);
    if (!isPasswordValid) {
      return sendJson(res, 401, { success: false, message: 'Invalid username or password' });
    }

    try {
      await user.update({ lastLoginAt: new Date() });
    } catch {
      // non-blocking
    }

    const token = issueAuthJwt(user.id);
    return sendJson(res, 200, {
      success: true,
      message: 'Login successful',
      data: {
        user: sanitizeAuthUser(user),
        token,
      },
    });
  } catch (err) {
    return sendJson(res, 500, {
      success: false,
      message: err?.message || 'Login failed',
    });
  }
}

async function handleAuthMe(req, res) {
  const auth = req.authContext || await authenticateRequest(req);
  if (!auth.ok) return sendJson(res, 401, { success: false, message: auth.error || 'Authentication required' });
  return sendJson(res, 200, {
    success: true,
    data: {
      user: sanitizeAuthUser(auth.user),
      method: auth.method || 'unknown',
    },
  });
}

// ── Rate Limiting ─────────────────────────────────────────────

const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const RATE_LIMIT_MAX = parseInt(process.env.AI_MGMT_RATE_LIMIT || '120', 10);

function checkRateLimit(ip) {
  if (isLocalIp(ip)) return { allowed: true, remaining: RATE_LIMIT_MAX };

  const now = Date.now();
  let entry = _rateLimits.get(ip);

  if (!entry || (now - entry.windowStart) > RATE_LIMIT_WINDOW_MS) {
    entry = { count: 0, windowStart: now };
    _rateLimits.set(ip, entry);
  }

  entry.count++;

  if (entry.count > RATE_LIMIT_MAX) {
    const retryAfter = Math.ceil((RATE_LIMIT_WINDOW_MS - (now - entry.windowStart)) / 1000);
    return { allowed: false, remaining: 0, retryAfter };
  }

  return { allowed: true, remaining: RATE_LIMIT_MAX - entry.count };
}

// ── REST Route Handlers ───────────────────────────────────────

async function handleHealth(req, res) {
  const pkg = require('../../package.json');
  sendJson(res, 200, {
    success: true,
    data: {
      status: 'ok',
      uptime: process.uptime(),
      serverUptime: Date.now() - _startTime,
      port: _port,
      sessions: _sessions.size,
      version: pkg.version || '1.0.0',
    },
  });
}

async function handleStatus(req, res) {
  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  const adapters = gw.getStatus();
  const active = gw.getActiveAdapter();
  const effort = getAi().getEffort();
  const presets = getAi().getEffortPresets();

  sendJson(res, 200, {
    success: true,
    data: {
      adapters,
      active: active || null,
      activeProvider: getAi().getActiveProvider(),
      effort: { current: effort, presets },
    },
  });
}

async function handleListModels(req, res, adapterKey) {
  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  if (adapterKey) {
    // Single adapter
    try {
      const models = await gw.listModels(adapterKey);
      const test = await gw.testAdapter(adapterKey);
      sendJson(res, 200, {
        success: true,
        data: {
          adapter: adapterKey,
          health: test.connectivity,
          models: models || [],
        },
      });
    } catch (err) {
      sendError(res, 404, `Adapter not found: ${adapterKey}`);
    }
    return;
  }

  // All adapters with health indicators
  const statuses = gw.getStatus();
  const results = [];

  // Run tests in parallel for all enabled adapters
  const testPromises = {};
  for (const s of statuses) {
    if (s.enabled && s.available) {
      testPromises[s.type] = gw.testAdapter(s.type).catch(() => null);
    }
  }

  for (const s of statuses) {
    if (!s.enabled) continue;

    const test = testPromises[s.type] ? await testPromises[s.type] : null;
    const health = test?.connectivity?.success ? 'green' : (s.available ? 'yellow' : 'red');
    const latencyMs = test?.connectivity?.latencyMs || null;

    let models = [];
    try {
      if (s.available) models = await gw.listModels(s.type) || [];
    } catch { /* skip */ }

    results.push({
      adapter: s.type,
      name: s.name,
      priority: s.priority,
      available: s.available,
      health,
      latencyMs,
      modelsHealth: test?.models || null,
      models: models.map(m => ({
        id: m.id,
        name: m.name || m.id,
        isDefault: m.isDefault || false,
      })),
    });
  }

  sendJson(res, 200, { success: true, data: results });
}

async function handleTestAdapter(req, res, adapterKey) {
  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  const result = await gw.testAdapter(adapterKey);
  sendJson(res, 200, { success: true, data: result });
}

function parseBooleanLike(value, fallback = false) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  const normalized = String(value).trim().toLowerCase();
  if (['1', 'true', 'yes', 'on'].includes(normalized)) return true;
  if (['0', 'false', 'no', 'off'].includes(normalized)) return false;
  return fallback;
}

function parseEnvJsonObject(value, fallback = {}) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'object' && !Array.isArray(value)) return value;
  if (typeof value !== 'string') return fallback;
  try {
    const parsed = JSON.parse(value);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
  } catch {
    return fallback;
  }
  return fallback;
}

function parseInputJsonObject(fieldName, value) {
  if (value === undefined) return undefined;
  if (value === null || value === '') return {};
  if (typeof value === 'object' && !Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
      throw new Error(`${fieldName} must be a JSON object`);
    } catch {
      throw new Error(`${fieldName} must be a valid JSON object`);
    }
  }
  throw new Error(`${fieldName} must be a JSON object`);
}

async function handleGetConfig(req, res) {
  sendJson(res, 200, { success: true, data: getGatewayConfigSnapshot() });
}

function getGatewayConfigSnapshot() {
  const ai = getAi();
  return {
    preferredAdapter: process.env.GATEWAY_PREFERRED_ADAPTER || '',
    preferredModel: process.env.GATEWAY_PREFERRED_MODEL || '',
    effort: ai.getEffort(),
    effortPresets: ai.getEffortPresets(),
    cliEnabled: process.env.GATEWAY_CLI_ENABLED !== 'false',
    ollamaHost: process.env.OLLAMA_HOST || 'http://localhost:11434',
    ollamaModel: process.env.OLLAMA_MODEL || 'qwen2.5:7b',
    relayPort: process.env.GATEWAY_RELAY_PORT || '9099',
    modelRouteMap: parseEnvJsonObject(process.env.GATEWAY_MODEL_ROUTE_MAP, {}),
    modelRouteStrict: parseBooleanLike(process.env.GATEWAY_MODEL_ROUTE_STRICT, false),
    keySelectionStrategy: process.env.GATEWAY_KEY_SELECTION_STRATEGY || 'round-robin',
    keySelectionStrategyMap: parseEnvJsonObject(process.env.GATEWAY_KEY_SELECTION_STRATEGY_MAP, {}),
    apiPoolProvider: process.env.GATEWAY_API_POOL_PROVIDER || '',
    apiPoolProviderAliasMap: parseEnvJsonObject(process.env.GATEWAY_API_POOL_PROVIDER_ALIAS_MAP, {}),
    apiPoolServiceMap: parseEnvJsonObject(process.env.GATEWAY_API_POOL_SERVICE_MAP, {}),
    apiPoolDefaultModelMap: parseEnvJsonObject(process.env.GATEWAY_API_POOL_DEFAULT_MODEL_MAP, {}),
  };
}

function applyGatewayConfigPatch(body = {}) {
  const ALLOWED_KEYS = {
    GATEWAY_PREFERRED_ADAPTER: 'preferredAdapter',
    GATEWAY_PREFERRED_MODEL: 'preferredModel',
    OLLAMA_HOST: 'ollamaHost',
    OLLAMA_MODEL: 'ollamaModel',
    GATEWAY_CLI_ENABLED: 'cliEnabled',
    GATEWAY_RELAY_PORT: 'relayPort',
    GATEWAY_MODEL_ROUTE_STRICT: 'modelRouteStrict',
    GATEWAY_KEY_SELECTION_STRATEGY: 'keySelectionStrategy',
    GATEWAY_API_POOL_PROVIDER: 'apiPoolProvider',
    GATEWAY_MODEL_ROUTE_MAP: 'modelRouteMap',
    GATEWAY_KEY_SELECTION_STRATEGY_MAP: 'keySelectionStrategyMap',
    GATEWAY_API_POOL_PROVIDER_ALIAS_MAP: 'apiPoolProviderAliasMap',
    GATEWAY_API_POOL_SERVICE_MAP: 'apiPoolServiceMap',
    GATEWAY_API_POOL_DEFAULT_MODEL_MAP: 'apiPoolDefaultModelMap',
  };
  const envPath = path.resolve(__dirname, '../../.env');
  let envContent = '';
  try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }

  const updated = [];
  const JSON_BODY_KEYS = new Set([
    'modelRouteMap',
    'keySelectionStrategyMap',
    'apiPoolProviderAliasMap',
    'apiPoolServiceMap',
    'apiPoolDefaultModelMap',
  ]);
  const BOOLEAN_BODY_KEYS = new Set(['cliEnabled', 'modelRouteStrict']);

  for (const [envKey, bodyKey] of Object.entries(ALLOWED_KEYS)) {
    if (body[bodyKey] !== undefined) {
      let normalizedValue = body[bodyKey];
      if (JSON_BODY_KEYS.has(bodyKey)) {
        normalizedValue = parseInputJsonObject(bodyKey, body[bodyKey]);
      } else if (BOOLEAN_BODY_KEYS.has(bodyKey)) {
        normalizedValue = parseBooleanLike(body[bodyKey], false);
      }

      let value = '';
      if (JSON_BODY_KEYS.has(bodyKey)) {
        value = JSON.stringify(normalizedValue);
      } else if (BOOLEAN_BODY_KEYS.has(bodyKey)) {
        value = normalizedValue ? 'true' : 'false';
      } else {
        value = String(normalizedValue);
      }
      const regex = new RegExp(`^${envKey}=.*$`, 'm');
      const shouldUnset = (bodyKey === 'preferredAdapter' || bodyKey === 'preferredModel' || bodyKey === 'apiPoolProvider')
        && String(normalizedValue).trim() === '';
      if (shouldUnset) {
        envContent = envContent.replace(new RegExp(`^${envKey}=.*(?:\\r?\\n)?`, 'm'), '');
        delete process.env[envKey];
      } else {
        const line = `${envKey}=${value}`;
        if (regex.test(envContent)) {
          envContent = envContent.replace(regex, line);
        } else {
          envContent = envContent.trimEnd() + '\n' + line + '\n';
        }
        process.env[envKey] = value;
      }
      updated.push(bodyKey);
    }
  }

  // Handle effort separately (not an env var)
  if (body.effort) {
    if (getAi().setEffort(body.effort)) {
      updated.push('effort');
    }
  }

  // Atomic write: temp + rename
  if (updated.length > 0 && updated.some(k => k !== 'effort')) {
    const tmpPath = envPath + '.tmp.' + Date.now();
    fs.writeFileSync(tmpPath, envContent, 'utf-8');
    fs.renameSync(tmpPath, envPath);
  }
  return { updated, config: getGatewayConfigSnapshot() };
}

async function handleUpdateConfig(req, res) {
  const body = await parseBody(req);
  const result = applyGatewayConfigPatch(body);
  sendJson(res, 200, { success: true, data: { updated: result.updated } });
}

async function handleListConversations(req, res) {
  const conversations = getAi().listConversations();
  sendJson(res, 200, { success: true, data: conversations });
}

async function handleGetConversation(req, res, file) {
  // Strict filename validation to prevent path traversal
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}\.json$/.test(file)) {
    return sendError(res, 400, 'Invalid conversation filename');
  }

  const filePath = path.join(CONVO_DIR, file);
  try {
    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    sendJson(res, 200, { success: true, data });
  } catch {
    sendError(res, 404, 'Conversation not found');
  }
}

async function handleDeleteConversation(req, res, file) {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}\.json$/.test(file)) {
    return sendError(res, 400, 'Invalid conversation filename');
  }

  const filePath = path.join(CONVO_DIR, file);
  try {
    fs.unlinkSync(filePath);
    sendJson(res, 200, { success: true, data: { deleted: file } });
  } catch {
    sendError(res, 404, 'Conversation not found');
  }
}

async function handleGetUsage(req, res) {
  const tu = getTokenUsage();
  sendJson(res, 200, {
    success: true,
    data: {
      session: tu.getSessionUsage(),
      today: tu.getTodayUsage(),
      month: tu.getMonthUsage(),
      quota: tu.getRemainingQuota(),
      cost: tu.getSessionCost(),
    },
  });
}

async function handleGetUsageHistory(req, res, searchParams) {
  const days = parseInt(searchParams.get('days')) || 30;
  const history = getTokenUsage().getUsageHistory(days);
  sendJson(res, 200, { success: true, data: history });
}

async function handleListTools(req, res) {
  const tc = getToolCalling();
  sendJson(res, 200, {
    success: true,
    data: {
      tools: tc.listTools(),
      definitions: tc.getToolDefinitions(),
    },
  });
}

async function handleExecuteTool(req, res, toolName) {
  const body = await parseBody(req);
  const params = body.params || body;

  // Find the tool
  const tc = getToolCalling();
  const tool = tc.BUILTIN_TOOLS.find(t => t.name === toolName);
  if (!tool) return sendError(res, 404, `Tool not found: ${toolName}`);

  // Security check on params
  try {
    const check = getSecurity().analyzeInput(JSON.stringify(params));
    if (!check.safe) return sendError(res, 403, check.refusal);
  } catch { /* security failure should not block */ }

  // High-risk tools require explicit approval via web (return approval request)
  if (tool.risk !== 'safe' && !tc.isDangerousMode() && !tc.isApproved(toolName)) {
    return sendJson(res, 200, {
      success: false,
      requiresApproval: true,
      tool: { name: tool.name, risk: tool.risk, description: tool.description },
      message: `Tool "${toolName}" requires approval (risk: ${tool.risk})`,
    });
  }

  try {
    const result = await tool.handler(params);
    sendJson(res, 200, { success: true, data: result });
  } catch (err) {
    sendError(res, 500, `Tool execution failed: ${err.message}`);
  }
}

async function handleSecurityStats(req, res) {
  const stats = getSecurity().getSecurityStats();
  sendJson(res, 200, { success: true, data: stats });
}

function validatePluginCode(code) {
  try {
    const vm = require('vm');
    new vm.Script(String(code || ''), { filename: 'plugin.js' });
    return { valid: true };
  } catch (err) {
    return { valid: false, error: err.message };
  }
}

function toGatewayModelId(adapterKey, rawModelId) {
  const prefixMap = getModelRouter().DEFAULT_ADAPTER_TO_PREFIX || {};
  const prefix = prefixMap[adapterKey] || adapterKey;
  const modelId = String(rawModelId || '').trim();
  if (!modelId) return '';
  if (modelId.startsWith(`${prefix}/`)) return modelId;
  return `${prefix}/${modelId}`;
}

function parseProviderFromModelId(modelId) {
  const m = String(modelId || '').trim().toLowerCase().match(/^([a-z0-9_-]+)[/:](.+)$/);
  return m ? m[1] : '';
}

async function runAutoImportIfNeeded() {
  if (String(process.env.AI_GATEWAY_AUTO_IMPORT || 'true').toLowerCase() === 'false') {
    return _autoImportSummary;
  }

  const now = Date.now();
  if (_autoImportSummary && (now - _autoImportLastAt) < AUTO_IMPORT_INTERVAL_MS) {
    return _autoImportSummary;
  }

  const summary = {
    at: new Date(now).toISOString(),
    providers: [],
  };

  try {
    const accountPool = getAccountPool();
    await accountPool.init();
    for (const provider of AUTO_IMPORT_ACCOUNT_PROVIDERS) {
      try {
        const imported = await accountPool.importProviderTokens(provider, { activateIfNone: true });
        summary.providers.push({
          provider,
          found: imported?.found || 0,
          inserted: imported?.inserted || 0,
          updated: imported?.updated || 0,
          activated: imported?.activated || null,
        });
      } catch (err) {
        summary.providers.push({
          provider,
          error: err?.message || String(err),
        });
      }
    }
  } catch (err) {
    summary.error = err?.message || String(err);
  }

  _autoImportLastAt = now;
  _autoImportSummary = summary;
  return summary;
}

function ensureAutoSharedCustomerFromSnapshot(gatewayAssets, apiPoolStatus = {}) {
  try {
    const customerRegistry = getCustomerRegistry();
    const discoveredProviders = new Set();

    for (const item of gatewayAssets?.list || []) {
      const provider = parseProviderFromModelId(item?.id || '');
      if (provider) discoveredProviders.add(provider);
    }
    for (const provider of Object.keys(apiPoolStatus || {})) {
      if (provider) discoveredProviders.add(String(provider).toLowerCase());
    }
    for (const row of gatewayAssets?.adapters || []) {
      if (row?.enabled && row?.available && row?.key) {
        discoveredProviders.add(String(row.key).toLowerCase());
      }
    }

    customerRegistry.ensureAutoSharedCustomer({
      modelIds: (gatewayAssets?.list || []).map(item => item.id).filter(Boolean),
      providers: [...discoveredProviders],
    });
  } catch {
    // best-effort auto customer sync
  }
}

async function collectGatewayModelsSnapshot() {
  const gw = getGateway();
  if (!gw._initialized) await gw.init();
  const statuses = gw.getStatus().filter(row => row.enabled !== false);

  const adapters = [];
  const list = [];
  const seen = new Set();

  for (const row of statuses) {
    let models = [];
    let modelError = '';
    if (row.available) {
      try {
        models = await gw.listModels(row.type) || [];
      } catch (err) {
        modelError = err.message || String(err);
      }
    }

    let modelCount = 0;
    for (const model of models) {
      const rawId = String(model?.id || model?.name || '').trim();
      if (!rawId) continue;
      modelCount += 1;

      const canonicalId = toGatewayModelId(row.type, rawId);
      if (!seen.has(canonicalId)) {
        seen.add(canonicalId);
        list.push({
          id: canonicalId,
          name: model?.name || rawId,
          adapter: row.type,
          isDefault: model?.isDefault === true,
        });
      }

      if (row.type === 'trae') {
        const antiId = `antigravity/${rawId}`;
        const nirvanaId = `nirvana/${rawId}`;
        if (!seen.has(antiId)) {
          seen.add(antiId);
          list.push({ id: antiId, name: model?.name || rawId, adapter: row.type, isDefault: false });
        }
        if (!seen.has(nirvanaId)) {
          seen.add(nirvanaId);
          list.push({ id: nirvanaId, name: model?.name || rawId, adapter: row.type, isDefault: false });
        }
      }
    }

    adapters.push({
      key: row.type,
      name: row.name,
      enabled: row.enabled !== false,
      available: row.available !== false,
      modelCount,
      modelError,
    });
  }

  try {
    const discovery = require('./gateway/modelDiscovery').discoverModels();
    for (const id of discovery.models || []) {
      const normalized = String(id || '').trim();
      if (!normalized) continue;
      let guessed = normalized;
      if (!normalized.includes('/')) {
        const looksLocalOllama = normalized.includes(':')
          && /(qwen|llama|mistral|gemma|phi|yi|baichuan|deepseek|qwq|qvq)/i.test(normalized);
        guessed = looksLocalOllama ? `ollama/${normalized}` : `api/${normalized}`;
      }
      if (seen.has(guessed)) continue;
      seen.add(guessed);
      list.push({
        id: guessed,
        name: normalized,
        adapter: 'discovered',
        isDefault: false,
      });
    }
  } catch {
    // Best-effort model discovery
  }

  list.sort((a, b) => String(a.id || '').localeCompare(String(b.id || '')));

  return {
    enabledAdapters: adapters.length,
    totalModels: list.length,
    adapters,
    list,
  };
}

async function handleAiGatewayStatus(req, res) {
  const gw = getGateway();
  if (!gw._initialized) await gw.init();
  const adapters = gw.getStatus();
  const active = gw.getActiveAdapter();
  sendJson(res, 200, {
    adapters,
    active: active ? { name: active.name, type: active.type } : null,
  });
}

async function handleAiGatewayPool(req, res) {
  const pool = getApiKeyPool();
  pool.init();
  sendJson(res, 200, pool.getAllStatus());
}

async function handleAiGatewayPoolAddKey(req, res, provider) {
  const body = await parseBody(req);
  const pool = getApiKeyPool();
  pool.init();
  if (!body.key) return sendError(res, 400, 'key is required');
  pool.addKey(provider, {
    key: body.key,
    endpoint: body.endpoint || '',
    priority: Number.isFinite(Number(body.priority)) ? Number(body.priority) : 10,
    label: body.label || '',
  });
  sendJson(res, 200, { success: true });
}

async function handleAiGatewayPoolRemoveKey(req, res, provider, keyId) {
  const pool = getApiKeyPool();
  pool.init();
  pool.removeKey(provider, keyId);
  sendJson(res, 200, { success: true });
}

async function handleAiGatewayMonitorTraces(req, res, searchParams) {
  const monitor = getAiMonitor();
  const filter = {};
  const limit = parseInt(searchParams.get('limit') || '', 10);
  const offset = parseInt(searchParams.get('offset') || '', 10);
  const provider = String(searchParams.get('provider') || '').trim();
  const success = searchParams.get('success');
  const since = String(searchParams.get('since') || '').trim();
  if (Number.isFinite(limit) && limit > 0) filter.limit = limit;
  if (Number.isFinite(offset) && offset >= 0) filter.offset = offset;
  if (provider) filter.provider = provider;
  if (success !== null) filter.success = success === 'true';
  if (since) filter.since = since;
  sendJson(res, 200, monitor.getTraces(filter));
}

async function handleAiGatewayMonitorStats(req, res) {
  sendJson(res, 200, getAiMonitor().getStats());
}

function handleAiGatewayMonitorStream(req, res) {
  const monitor = getAiMonitor();
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
    ...corsHeaders(),
  });

  const events = monitor.createEventStream();
  const onTrace = (trace) => {
    res.write(`data: ${JSON.stringify(trace)}\n\n`);
  };

  events.on('trace:start', onTrace);
  events.on('trace:end', onTrace);
  events.on('trace:cascade', onTrace);

  req.on('close', () => {
    events.removeListener('trace:start', onTrace);
    events.removeListener('trace:end', onTrace);
    events.removeListener('trace:cascade', onTrace);
  });
}

async function handleAiGatewayOAuthStatus(req, res) {
  const oauth = getOauthManager();
  oauth.init();
  sendJson(res, 200, oauth.getAllStatus());
}

async function handleAiGatewayOAuthRefresh(req, res, provider) {
  const oauth = getOauthManager();
  oauth.init();
  const token = await oauth.refreshToken(provider);
  sendJson(res, 200, { success: !!token, token: token ? '***' : null });
}

async function handleAiGatewayPlugins(req, res) {
  sendJson(res, 200, getPluginChain().list());
}

async function handleAiGatewayTogglePlugin(req, res, name) {
  const body = await parseBody(req);
  const success = getPluginChain().toggle(name, body.enabled !== false);
  sendJson(res, 200, { success });
}

async function handleAiGatewayPluginCode(req, res, name) {
  let pluginPath;
  try {
    pluginPath = getPluginFilePath(name);
  } catch (err) {
    return sendError(res, 400, err.message);
  }
  if (!fs.existsSync(pluginPath)) return sendError(res, 404, 'plugin not found');
  const code = fs.readFileSync(pluginPath, 'utf-8');
  sendJson(res, 200, { code });
}

async function handleAiGatewayCreatePlugin(req, res) {
  const body = await parseBody(req);
  let pluginPath;
  try {
    pluginPath = getPluginFilePath(body.name);
  } catch (err) {
    return sendError(res, 400, err.message);
  }
  if (fs.existsSync(pluginPath)) return sendError(res, 409, 'plugin already exists');
  const code = String(body.code || '').trim();
  if (!code) return sendError(res, 400, 'code is required');
  const valid = validatePluginCode(code);
  if (!valid.valid) return sendError(res, 400, valid.error || 'invalid plugin code');
  fs.mkdirSync(path.dirname(pluginPath), { recursive: true });
  fs.writeFileSync(pluginPath, code, 'utf-8');
  getPluginChain().reload();
  sendJson(res, 200, { success: true, name: sanitizePluginName(body.name) });
}

async function handleAiGatewayUpdatePlugin(req, res, name) {
  const body = await parseBody(req);
  let pluginPath;
  try {
    pluginPath = getPluginFilePath(name);
  } catch (err) {
    return sendError(res, 400, err.message);
  }
  const code = String(body.code || '').trim();
  if (!code) return sendError(res, 400, 'code is required');
  const valid = validatePluginCode(code);
  if (!valid.valid) return sendError(res, 400, valid.error || 'invalid plugin code');
  fs.mkdirSync(path.dirname(pluginPath), { recursive: true });
  fs.writeFileSync(pluginPath, code, 'utf-8');
  getPluginChain().reload();
  sendJson(res, 200, { success: true, name: sanitizePluginName(name) });
}

async function handleAiGatewayDeletePlugin(req, res, name) {
  let pluginPath;
  try {
    pluginPath = getPluginFilePath(name);
  } catch (err) {
    return sendError(res, 400, err.message);
  }
  if (!fs.existsSync(pluginPath)) return sendError(res, 404, 'plugin not found');
  fs.unlinkSync(pluginPath);
  getPluginChain().reload();
  sendJson(res, 200, { success: true });
}

async function handleAiGatewayValidatePlugin(req, res) {
  const body = await parseBody(req);
  sendJson(res, 200, validatePluginCode(String(body.code || '')));
}

async function handleAiGatewayPluginTemplate(req, res) {
  sendJson(res, 200, { code: DEFAULT_PLUGIN_TEMPLATE });
}

async function handleAiGatewayReloadPlugins(req, res) {
  const loaded = getPluginChain().reload();
  sendJson(res, 200, { success: true, loaded });
}

async function handleAiGatewayTlsStatus(req, res) {
  sendJson(res, 200, getTlsSidecar().getStatus());
}

async function handleAiGatewayTlsStart(req, res) {
  const body = await parseBody(req);
  const result = await getTlsSidecar().start(body || {});
  sendJson(res, 200, { success: true, ...result });
}

async function handleAiGatewayTlsStop(req, res) {
  await getTlsSidecar().stop();
  sendJson(res, 200, { success: true });
}

async function handleAiGatewayProtocols(req, res) {
  sendJson(res, 200, { protocols: getProtocolConverter().getSupportedProtocols() });
}

async function handleAiGatewaySlots(req, res) {
  sendJson(res, 200, getConcurrencySlots().getAllStatus());
}

async function handleAiGatewayConfigGet(req, res) {
  sendJson(res, 200, getGatewayConfigSnapshot());
}

async function handleAiGatewayConfigPut(req, res) {
  const body = await parseBody(req);
  const result = applyGatewayConfigPatch(body || {});
  sendJson(res, 200, { updated: result.updated, config: result.config });
}

async function handleAiGatewayAssetsOverview(req, res) {
  const autoImport = await runAutoImportIfNeeded();
  const gatewayAssets = await collectGatewayModelsSnapshot();
  _lastGatewayAssetsSnapshot = gatewayAssets;

  const apiPool = getApiKeyPool();
  apiPool.init();
  const apiPoolStatus = apiPool.getAllStatus();
  let totalKeys = 0;
  for (const rows of Object.values(apiPoolStatus)) {
    totalKeys += Array.isArray(rows) ? rows.length : 0;
  }

  const accountPool = getAccountPool();
  let accountStatus = { totalAccounts: 0 };
  try {
    await accountPool.init();
    accountStatus = await accountPool.getStatus();
  } catch {
    accountStatus = { totalAccounts: 0 };
  }

  const customerRegistry = getCustomerRegistry();
  ensureAutoSharedCustomerFromSnapshot(gatewayAssets, apiPoolStatus);
  const customers = customerRegistry.listCustomers({ includeSecrets: false });
  const customerSummary = customerRegistry.getCustomerSummary(customers);

  const proxy = getProxyServer();
  const proxyRuntime = proxy.getRuntimeStatus();
  const proxyAuth = proxy.getAuthStatus();

  sendJson(res, 200, {
    assets: {
      gateway: gatewayAssets,
      apiKeyPool: {
        totalKeys,
        providers: Object.keys(apiPoolStatus),
      },
      accountPool: {
        totalAccounts: accountStatus.totalAccounts || 0,
        byProvider: accountStatus.byProvider || {},
      },
      customers: customerSummary,
      autoImport: autoImport || null,
      proxy: {
        runtime: proxyRuntime,
        auth: {
          tokenCount: proxyAuth.tokenCount,
          managedTokenCount: proxyAuth.managedTokenCount,
          managedTokenEnabledCount: proxyAuth.managedTokenEnabledCount,
          managedTokens: proxyAuth.managedTokens,
        },
      },
    },
  });
}

async function handleAiGatewayListCustomers(req, res, searchParams) {
  const includeSecrets = parseBooleanLike(searchParams.get('includeSecrets'), false);
  const model = String(searchParams.get('model') || '').trim();
  const apiPool = getApiKeyPool();
  apiPool.init();
  const apiPoolStatus = apiPool.getAllStatus();

  if (!_lastGatewayAssetsSnapshot) {
    try {
      _lastGatewayAssetsSnapshot = await collectGatewayModelsSnapshot();
    } catch {
      _lastGatewayAssetsSnapshot = { adapters: [], list: [] };
    }
  }
  ensureAutoSharedCustomerFromSnapshot(_lastGatewayAssetsSnapshot, apiPoolStatus);

  const rows = getCustomerRegistry().listCustomers({ includeSecrets, model });
  sendJson(res, 200, rows);
}

async function handleAiGatewayCreateCustomer(req, res) {
  const body = await parseBody(req);
  const created = getCustomerRegistry().createCustomer(body || {});
  sendJson(res, 200, created);
}

async function handleAiGatewayUpdateCustomer(req, res, customerId) {
  const body = await parseBody(req);
  const updated = getCustomerRegistry().updateCustomer(customerId, body || {});
  sendJson(res, 200, updated);
}

async function handleAiGatewaySetCustomerEnabled(req, res, customerId, enabled) {
  const updated = getCustomerRegistry().setCustomerEnabled(customerId, enabled);
  sendJson(res, 200, updated);
}

async function handleAiGatewayIssueToken(req, res, customerId) {
  const body = await parseBody(req);
  const created = getCustomerRegistry().issueToken(customerId, body || {});
  sendJson(res, 200, created);
}

async function handleAiGatewayRotateToken(req, res, customerId, tokenId) {
  const body = await parseBody(req);
  const rotated = getCustomerRegistry().rotateToken(customerId, tokenId, body.token || '');
  sendJson(res, 200, rotated);
}

async function handleAiGatewaySetTokenEnabled(req, res, customerId, tokenId, enabled) {
  const updated = getCustomerRegistry().setTokenEnabled(customerId, tokenId, enabled);
  sendJson(res, 200, updated);
}

async function handleAiGatewayDeleteToken(req, res, customerId, tokenId) {
  const removed = getCustomerRegistry().deleteToken(customerId, tokenId);
  sendJson(res, 200, removed);
}

async function handleAiGatewayListAccounts(req, res) {
  const pool = getAccountPool();
  await pool.init();
  const rows = await pool.getAllAccounts();
  sendJson(res, 200, rows);
}

async function handleAiGatewayAddAccount(req, res) {
  const body = await parseBody(req);
  const pool = getAccountPool();
  await pool.init();
  const created = await pool.addAccount(body || {});
  sendJson(res, 200, created || {});
}

async function handleAiGatewayUpdateAccount(req, res, accountId) {
  const body = await parseBody(req);
  const pool = getAccountPool();
  await pool.init();
  if (!pool.updateAccount) return sendError(res, 501, 'updateAccount is not implemented');
  const updated = await pool.updateAccount(accountId, body || {});
  sendJson(res, 200, updated || {});
}

async function handleAiGatewayDeleteAccount(req, res, accountId) {
  const pool = getAccountPool();
  await pool.init();
  await pool.removeAccount(accountId);
  sendJson(res, 200, { success: true });
}

async function handleAiGatewaySetAccountEnabled(req, res, accountId, enabled) {
  const pool = getAccountPool();
  await pool.init();
  if (enabled) await pool.enableAccount(accountId);
  else await pool.disableAccount(accountId);
  sendJson(res, 200, { success: true });
}

async function handleAiGatewayGetScheduling(req, res) {
  const pool = getAccountPool();
  await pool.init();
  const cfg = await pool.getSchedulingConfig();
  sendJson(res, 200, cfg);
}

async function handleAiGatewayUpdateScheduling(req, res) {
  const body = await parseBody(req);
  const pool = getAccountPool();
  await pool.init();
  const next = await pool.setSchedulingConfig(body || {});
  sendJson(res, 200, next);
}

async function handleAiGatewayGetCircuitBreaker(req, res) {
  sendJson(res, 200, readAccountCircuitBreakerConfig());
}

async function handleAiGatewayUpdateCircuitBreaker(req, res) {
  const body = await parseBody(req);
  const next = saveAccountCircuitBreakerConfig(body || {});
  sendJson(res, 200, next);
}

async function handleAiGatewayNamespace(req, res, pathname, searchParams) {
  const method = req.method;
  let apiPath = String(pathname || '');
  if (apiPath.startsWith('/api/gateway')) {
    apiPath = `/api/ai-gateway${apiPath.slice('/api/gateway'.length)}`;
  }
  if (!apiPath.startsWith('/api/ai-gateway')) return false;

  // Monitor SSE stream must short-circuit with persistent connection.
  if (method === 'GET' && apiPath === '/api/ai-gateway/monitor/stream') {
    handleAiGatewayMonitorStream(req, res);
    return true;
  }

  if (method === 'GET' && apiPath === '/api/ai-gateway/status') return handleAiGatewayStatus(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/pool') return handleAiGatewayPool(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/config') return handleAiGatewayConfigGet(req, res);
  if (method === 'PUT' && apiPath === '/api/ai-gateway/config') return handleAiGatewayConfigPut(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/slots') return handleAiGatewaySlots(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/protocols') return handleAiGatewayProtocols(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/plugins') return handleAiGatewayPlugins(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/oauth/status') return handleAiGatewayOAuthStatus(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/tls/status') return handleAiGatewayTlsStatus(req, res);
  if (method === 'POST' && apiPath === '/api/ai-gateway/tls/start') return handleAiGatewayTlsStart(req, res);
  if (method === 'POST' && apiPath === '/api/ai-gateway/tls/stop') return handleAiGatewayTlsStop(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/monitor/stats') return handleAiGatewayMonitorStats(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/monitor/traces') return handleAiGatewayMonitorTraces(req, res, searchParams);
  if (method === 'GET' && apiPath === '/api/ai-gateway/assets/overview') return handleAiGatewayAssetsOverview(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/customers') return handleAiGatewayListCustomers(req, res, searchParams);
  if (method === 'POST' && apiPath === '/api/ai-gateway/customers') return handleAiGatewayCreateCustomer(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/accounts') return handleAiGatewayListAccounts(req, res);
  if (method === 'POST' && apiPath === '/api/ai-gateway/accounts') return handleAiGatewayAddAccount(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/accounts/scheduling') return handleAiGatewayGetScheduling(req, res);
  if (method === 'PUT' && apiPath === '/api/ai-gateway/accounts/scheduling') return handleAiGatewayUpdateScheduling(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/accounts/circuit-breaker') return handleAiGatewayGetCircuitBreaker(req, res);
  if (method === 'PUT' && apiPath === '/api/ai-gateway/accounts/circuit-breaker') return handleAiGatewayUpdateCircuitBreaker(req, res);
  if (method === 'POST' && apiPath === '/api/ai-gateway/plugins') return handleAiGatewayCreatePlugin(req, res);
  if (method === 'POST' && apiPath === '/api/ai-gateway/plugins/validate') return handleAiGatewayValidatePlugin(req, res);
  if (method === 'GET' && apiPath === '/api/ai-gateway/plugins/template') return handleAiGatewayPluginTemplate(req, res);
  if (method === 'POST' && apiPath === '/api/ai-gateway/plugins/reload') return handleAiGatewayReloadPlugins(req, res);

  let match = apiPath.match(/^\/api\/ai-gateway\/pool\/([a-z0-9_-]+)\/keys$/i);
  if (match && method === 'POST') return handleAiGatewayPoolAddKey(req, res, match[1]);

  match = apiPath.match(/^\/api\/ai-gateway\/pool\/([a-z0-9_-]+)\/keys\/([a-z0-9_-]+)$/i);
  if (match && method === 'DELETE') return handleAiGatewayPoolRemoveKey(req, res, match[1], match[2]);

  match = apiPath.match(/^\/api\/ai-gateway\/oauth\/([a-z0-9_-]+)\/refresh$/i);
  if (match && method === 'POST') return handleAiGatewayOAuthRefresh(req, res, match[1]);

  match = apiPath.match(/^\/api\/ai-gateway\/plugins\/([a-z0-9_-]+)\/toggle$/i);
  if (match && method === 'POST') return handleAiGatewayTogglePlugin(req, res, match[1]);

  match = apiPath.match(/^\/api\/ai-gateway\/plugins\/([a-z0-9_-]+)\/code$/i);
  if (match && method === 'GET') return handleAiGatewayPluginCode(req, res, match[1]);

  match = apiPath.match(/^\/api\/ai-gateway\/plugins\/([a-z0-9_-]+)$/i);
  if (match && method === 'PUT') return handleAiGatewayUpdatePlugin(req, res, match[1]);
  if (match && method === 'DELETE') return handleAiGatewayDeletePlugin(req, res, match[1]);

  match = apiPath.match(/^\/api\/ai-gateway\/customers\/([a-z0-9_-]+)$/i);
  if (match && method === 'PUT') return handleAiGatewayUpdateCustomer(req, res, match[1]);

  match = apiPath.match(/^\/api\/ai-gateway\/customers\/([a-z0-9_-]+)\/(enable|disable)$/i);
  if (match && method === 'POST') return handleAiGatewaySetCustomerEnabled(req, res, match[1], match[2] === 'enable');

  match = apiPath.match(/^\/api\/ai-gateway\/customers\/([a-z0-9_-]+)\/tokens$/i);
  if (match && method === 'POST') return handleAiGatewayIssueToken(req, res, match[1]);

  match = apiPath.match(/^\/api\/ai-gateway\/customers\/([a-z0-9_-]+)\/tokens\/([a-z0-9_-]+)\/rotate$/i);
  if (match && method === 'POST') return handleAiGatewayRotateToken(req, res, match[1], match[2]);

  match = apiPath.match(/^\/api\/ai-gateway\/customers\/([a-z0-9_-]+)\/tokens\/([a-z0-9_-]+)\/(enable|disable)$/i);
  if (match && method === 'POST') {
    return handleAiGatewaySetTokenEnabled(req, res, match[1], match[2], match[3] === 'enable');
  }

  match = apiPath.match(/^\/api\/ai-gateway\/customers\/([a-z0-9_-]+)\/tokens\/([a-z0-9_-]+)$/i);
  if (match && method === 'DELETE') return handleAiGatewayDeleteToken(req, res, match[1], match[2]);

  match = apiPath.match(/^\/api\/ai-gateway\/accounts\/([0-9]+)$/i);
  if (match && method === 'PUT') return handleAiGatewayUpdateAccount(req, res, match[1]);
  if (match && method === 'DELETE') return handleAiGatewayDeleteAccount(req, res, match[1]);

  match = apiPath.match(/^\/api\/ai-gateway\/accounts\/([0-9]+)\/(enable|disable)$/i);
  if (match && method === 'POST') return handleAiGatewaySetAccountEnabled(req, res, match[1], match[2] === 'enable');

  sendError(res, 404, 'Not found');
  return true;
}

// ── Route Dispatcher ──────────────────────────────────────────

async function routeRequest(req, res, pathname, searchParams) {
  const method = req.method;

  if (method === 'POST' && pathname === '/api/auth/login') return handleAuthLogin(req, res);
  if (method === 'GET' && pathname === '/api/auth/me') return handleAuthMe(req, res);

  if (pathname.startsWith('/api/ai-gateway') || pathname.startsWith('/api/gateway')) {
    await handleAiGatewayNamespace(req, res, pathname, searchParams);
    return;
  }

  // Static routes
  if (method === 'GET' && pathname === '/api/health') return handleHealth(req, res);
  if (method === 'GET' && pathname === '/api/status') return handleStatus(req, res);
  if (method === 'GET' && pathname === '/api/models') return handleListModels(req, res, null);
  if (method === 'GET' && pathname === '/api/config') return handleGetConfig(req, res);
  if (method === 'PUT' && pathname === '/api/config') return handleUpdateConfig(req, res);
  if (method === 'GET' && pathname === '/api/conversations') return handleListConversations(req, res);
  if (method === 'GET' && pathname === '/api/usage') return handleGetUsage(req, res);
  if (method === 'GET' && pathname === '/api/usage/history') return handleGetUsageHistory(req, res, searchParams);
  if (method === 'GET' && pathname === '/api/tools') return handleListTools(req, res);
  if (method === 'GET' && pathname === '/api/security/stats') return handleSecurityStats(req, res);

  // Parameterized routes
  let match;

  match = pathname.match(/^\/api\/models\/([a-z_]+)$/);
  if (match && method === 'GET') return handleListModels(req, res, match[1]);

  match = pathname.match(/^\/api\/test\/([a-z_]+)$/);
  if (match && method === 'POST') return handleTestAdapter(req, res, match[1]);

  match = pathname.match(/^\/api\/conversations\/(.+)$/);
  if (match) {
    if (method === 'GET') return handleGetConversation(req, res, match[1]);
    if (method === 'DELETE') return handleDeleteConversation(req, res, match[1]);
  }

  match = pathname.match(/^\/api\/tools\/([a-z_]+)$/);
  if (match && method === 'POST') return handleExecuteTool(req, res, match[1]);

  sendError(res, 404, 'Not found');
}

// ── WebSocket Handler ─────────────────────────────────────────

function wsSend(session, data) {
  try {
    const WebSocket = require('ws');
    if (session.ws.readyState === WebSocket.OPEN) {
      session.ws.send(JSON.stringify(data));
    }
  } catch { /* ignore send errors */ }
}

function handleWsConnection(ws) {
  const sessionId = crypto.randomUUID();
  const session = {
    id: sessionId,
    ws,
    authenticated: false,
    user: null,
    effort: 'high',
    isGenerating: false,
    lastActivity: Date.now(),
    createdAt: Date.now(),
  };

  _sessions.set(sessionId, session);
  wsSend(session, { type: 'connected', sessionId });

  // Auth timeout
  const authTimer = setTimeout(() => {
    if (!session.authenticated) {
      wsSend(session, { type: 'auth_error', message: 'Auth timeout (30s)' });
      ws.close(4001, 'Auth timeout');
    }
  }, AUTH_TIMEOUT_MS);

  ws.on('message', async (raw) => {
    session.lastActivity = Date.now();

    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return wsSend(session, { type: 'error', message: 'Invalid JSON' });
    }

    if (!session.authenticated && msg.type !== 'auth' && msg.type !== 'ping') {
      return wsSend(session, { type: 'error', message: 'Not authenticated' });
    }

    try {
      switch (msg.type) {
        case 'auth':
          clearTimeout(authTimer);
          await handleWsAuth(session, msg);
          break;
        case 'chat':
          await handleWsChat(session, msg);
          break;
        case 'stop':
          handleWsStop(session);
          break;
        case 'ping':
          wsSend(session, { type: 'pong' });
          break;
        case 'set_effort':
          handleWsSetEffort(session, msg);
          break;
        default:
          wsSend(session, { type: 'error', message: `Unknown message type: ${msg.type}` });
      }
    } catch (err) {
      wsSend(session, { type: 'error', message: err.message });
    }
  });

  ws.on('close', () => cleanupSession(sessionId));
  ws.on('error', () => cleanupSession(sessionId));
}

async function handleWsAuth(session, msg) {
  const token = msg.token || '';
  const result = await authenticate(token, token);

  if (result.ok) {
    session.authenticated = true;
    session.user = result.user;
    wsSend(session, { type: 'auth_ok', sessionId: session.id });
  } else {
    wsSend(session, { type: 'auth_error', message: result.error });
    session.ws.close(4001, 'Auth failed');
  }
}

async function handleWsChat(session, msg) {
  if (!session.authenticated) {
    return wsSend(session, { type: 'error', message: 'Not authenticated' });
  }
  if (session.isGenerating) {
    return wsSend(session, { type: 'error', message: 'Already generating — send stop first' });
  }

  const message = msg.message || '';
  if (!message.trim()) {
    return wsSend(session, { type: 'error', message: 'Empty message' });
  }

  // Security check
  try {
    const check = getSecurity().analyzeInput(message);
    if (!check.safe) {
      return wsSend(session, { type: 'error', message: check.refusal, blocked: true });
    }
  } catch { /* security failure should not block */ }

  session.isGenerating = true;
  wsSend(session, { type: 'chat_start', sessionId: session.id });

  const effort = msg.effort || session.effort;

  try {
    const result = await getAi().chat(message, {
      effort,
      images: msg.images || undefined,
      onChunk: (chunk) => {
        if (!session.isGenerating) return; // stopped
        if (chunk.type === 'thinking') {
          wsSend(session, { type: 'thinking', text: chunk.text });
        } else if (chunk.type === 'text') {
          wsSend(session, { type: 'text', text: chunk.text });
        } else if (chunk.type === 'cost') {
          wsSend(session, { type: 'cost', data: chunk });
        }
      },
      onFallback: (info) => {
        wsSend(session, {
          type: 'fallback',
          from: info.failedAdapter,
          to: info.nextAdapter,
          error: info.failedError,
          errorType: info.failedErrorType,
        });
      },
    });

    // Send tool calls if any
    if (result.commands?.length > 0) {
      for (const cmd of result.commands) {
        wsSend(session, { type: 'tool_call', command: cmd });
      }
    }

    wsSend(session, {
      type: 'chat_complete',
      reply: result.reply,
      elapsed: result.elapsed,
      provider: result.provider,
      adapter: result.adapter,
      tokenUsage: result.tokenUsage,
      effort: result.effort,
    });
  } catch (err) {
    wsSend(session, { type: 'error', message: `Chat failed: ${err.message}` });
  } finally {
    session.isGenerating = false;
  }
}

function handleWsStop(session) {
  session.isGenerating = false;
  wsSend(session, {
    type: 'chat_complete',
    reply: '',
    elapsed: 0,
    provider: 'cancelled',
    adapter: 'none',
  });
}

function handleWsSetEffort(session, msg) {
  const presets = getAi().getEffortPresets();
  if (!presets[msg.effort]) {
    return wsSend(session, { type: 'error', message: `Invalid effort: ${msg.effort}` });
  }
  session.effort = msg.effort;
  wsSend(session, { type: 'effort_set', effort: msg.effort, label: presets[msg.effort].label });
}

function cleanupSession(sessionId) {
  const session = _sessions.get(sessionId);
  if (session) {
    session.isGenerating = false;
    _sessions.delete(sessionId);
  }
}

// ── Heartbeat / GC ────────────────────────────────────────────

function gcSweep() {
  const now = Date.now();

  // Close idle sessions
  for (const [id, session] of _sessions) {
    if (now - session.lastActivity > SESSION_IDLE_MS) {
      wsSend(session, { type: 'error', message: 'Session closed: idle timeout' });
      session.ws.close(4002, 'Idle timeout');
      _sessions.delete(id);
    }
  }

  // Clean stale rate limit entries
  for (const [ip, entry] of _rateLimits) {
    if (now - entry.windowStart > RATE_LIMIT_WINDOW_MS * 2) {
      _rateLimits.delete(ip);
    }
  }
}

// ── Server Lifecycle ──────────────────────────────────────────

/**
 * Start the AI management server.
 * @param {number} [port] - Port to listen on (default: AI_MGMT_PORT or 9090)
 * @returns {Promise<number>} The actual port the server is listening on
 */
function start(port) {
  return new Promise(async (resolve, reject) => {
    if (_server) return reject(new Error('AI management server already running'));

    const listenPort = port || parseInt(process.env.AI_MGMT_PORT, 10) || 9090;

    // Init gateway in background
    try {
      const gw = getGateway();
      if (!gw._initialized) gw.init().catch(() => {});
    } catch { /* best effort */ }

    // Create WebSocket server (noServer mode — attached to HTTP upgrade)
    const WebSocket = require('ws');
    _wss = new WebSocket.Server({ noServer: true });
    _wss.on('connection', handleWsConnection);

    // Create HTTP server
    _server = http.createServer(async (req, res) => {
      // CORS preflight
      if (req.method === 'OPTIONS') {
        res.writeHead(204, corsHeaders());
        return res.end();
      }

      const url = new URL(req.url, `http://localhost:${listenPort}`);
      const pathname = url.pathname;

      // Rate limiting
      const ip = getClientIp(req);
      const rateCheck = checkRateLimit(ip);
      if (!rateCheck.allowed) {
        res.writeHead(429, {
          'Content-Type': 'application/json',
          'Retry-After': String(rateCheck.retryAfter || 60),
          ...corsHeaders(),
        });
        res.end(JSON.stringify({ success: false, error: 'Rate limit exceeded', retryAfter: rateCheck.retryAfter }));
        return;
      }

      // Health endpoint — no auth required
      if (pathname === '/api/health') {
        try { return await handleHealth(req, res); }
        catch (err) { return sendError(res, 500, err.message); }
      }

      // Login endpoint — public route
      if (req.method === 'POST' && pathname === '/api/auth/login') {
        try { return await handleAuthLogin(req, res); }
        catch (err) { return sendJson(res, 500, { success: false, message: err.message || 'Login failed' }); }
      }

      // Auth check for all other routes
      const auth = await authenticateRequest(req);
      if (!auth.ok) {
        return sendError(res, 401, auth.error);
      }
      req.authContext = auth;

      // Route dispatch
      try {
        await routeRequest(req, res, pathname, url.searchParams);
      } catch (err) {
        sendError(res, 500, `Internal error: ${err.message}`);
      }
    });

    // WebSocket upgrade
    _server.on('upgrade', async (req, socket, head) => {
      const url = new URL(req.url, `http://localhost:${listenPort}`);
      if (url.pathname !== '/ws') {
        socket.destroy();
        return;
      }
      _wss.handleUpgrade(req, socket, head, (ws) => {
        _wss.emit('connection', ws, req);
      });
    });

    // Port auto-retry (up to +10)
    let attempt = 0;
    const maxAttempts = 10;

    function tryListen(tryPort) {
      const onListening = () => {
        _server.off('error', onError);
        _port = tryPort;
        _startTime = Date.now();
        _heartbeatTimer = setInterval(gcSweep, GC_INTERVAL_MS);
        _heartbeatTimer.unref();
        resolve(tryPort);
      };

      const onError = (err) => {
        _server.off('listening', onListening);
        if (err.code === 'EADDRINUSE' && attempt < maxAttempts) {
          attempt += 1;
          tryListen(tryPort + 1);
          return;
        }
        _server = null;
        _wss = null;
        reject(err);
      };

      _server.once('listening', onListening);
      _server.once('error', onError);
      _server.listen(tryPort);
    }

    tryListen(listenPort);
  });
}

/**
 * Stop the AI management server.
 */
function stop() {
  return new Promise((resolve) => {
    if (!_server) { resolve(); return; }

    // Notify all sessions
    for (const [id, session] of _sessions) {
      wsSend(session, { type: 'error', message: 'Server shutting down' });
      try { session.ws.close(1001, 'Server shutting down'); } catch { /* ignore */ }
    }
    _sessions.clear();

    if (_heartbeatTimer) {
      clearInterval(_heartbeatTimer);
      _heartbeatTimer = null;
    }

    // Close WebSocket server
    if (_wss) {
      _wss.close(() => {});
      _wss = null;
    }

    // Close HTTP server with 5s force-close
    const forceTimer = setTimeout(() => {
      _server = null;
      _port = 0;
      resolve();
    }, 5000);
    forceTimer.unref();

    _server.close(() => {
      clearTimeout(forceTimer);
      _server = null;
      _port = 0;
      resolve();
    });
  });
}

function isRunning() { return !!_server; }

function getPort() { return _port || parseInt(process.env.AI_MGMT_PORT, 10) || 9090; }

module.exports = { start, stop, isRunning, getPort };
