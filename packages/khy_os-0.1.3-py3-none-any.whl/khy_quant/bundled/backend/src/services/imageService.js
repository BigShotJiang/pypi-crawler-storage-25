/**
 * Image Service — handle image input for AI vision analysis.
 *
 * Supports:
 *   - File path input: read PNG/JPEG/GIF/WebP from disk
 *   - Clipboard paste: platform-specific clipboard image capture
 *   - Terminal preview: iTerm2/Kitty inline protocol, fallback to text
 *   - Base64 encoding for AI provider APIs
 *
 * No npm dependencies — uses child_process + Buffer only.
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const os = require('os');

// Magic bytes for image format detection
const MAGIC_BYTES = {
  png:  Buffer.from([0x89, 0x50, 0x4E, 0x47]),
  jpeg: Buffer.from([0xFF, 0xD8, 0xFF]),
  gif:  Buffer.from([0x47, 0x49, 0x46]),
  webp: Buffer.from([0x52, 0x49, 0x46, 0x46]), // RIFF header
};

const MIME_MAP = {
  png:  'image/png',
  jpeg: 'image/jpeg',
  gif:  'image/gif',
  webp: 'image/webp',
};

// Max image size (5MB — larger images should be resized)
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

/**
 * Detect image format from buffer magic bytes.
 * @param {Buffer} buf
 * @returns {'png'|'jpeg'|'gif'|'webp'|null}
 */
function detectFormat(buf) {
  if (!buf || buf.length < 4) return null;
  if (buf.subarray(0, 4).equals(MAGIC_BYTES.png)) return 'png';
  if (buf.subarray(0, 3).equals(MAGIC_BYTES.jpeg)) return 'jpeg';
  if (buf.subarray(0, 3).equals(MAGIC_BYTES.gif)) return 'gif';
  if (buf.subarray(0, 4).equals(MAGIC_BYTES.webp)) return 'webp';
  return null;
}

/**
 * Read an image from a file path.
 * @param {string} filePath - absolute or relative path to image file
 * @returns {{ base64: string, mimeType: string, sizeBytes: number, format: string }}
 * @throws {Error} if file doesn't exist, isn't an image, or is too large
 */
function readImageFromFile(filePath) {
  let normalized = String(filePath || '').trim();
  if (!normalized) {
    throw new Error('Image path is empty');
  }

  // Accept file:// URIs from terminal paste/drag-and-drop.
  // Examples:
  //   file:///home/user/a.png
  //   file://localhost/home/user/a.png
  if (/^file:\/\//i.test(normalized)) {
    try {
      const u = new URL(normalized);
      normalized = decodeURIComponent(u.pathname || '');
      if (process.platform === 'win32' && /^\/[A-Za-z]:\//.test(normalized)) {
        normalized = normalized.slice(1);
      }
    } catch {
      normalized = normalized.replace(/^file:\/\/(?:localhost)?/i, '');
      try { normalized = decodeURIComponent(normalized); } catch { /* ignore */ }
    }
  }

  const resolved = path.resolve(normalized);
  if (!fs.existsSync(resolved)) {
    throw new Error(`File not found: ${resolved}`);
  }

  const stat = fs.statSync(resolved);
  if (stat.size > MAX_IMAGE_BYTES) {
    throw new Error(`Image too large (${(stat.size / 1024 / 1024).toFixed(1)}MB). Max: ${MAX_IMAGE_BYTES / 1024 / 1024}MB`);
  }

  const buf = fs.readFileSync(resolved);
  const format = detectFormat(buf);
  if (!format) {
    throw new Error(`Not a recognized image format. Supported: PNG, JPEG, GIF, WebP`);
  }

  return {
    base64: buf.toString('base64'),
    mimeType: MIME_MAP[format],
    sizeBytes: stat.size,
    format,
  };
}

/**
 * Read an image from the system clipboard.
 * Platform-specific implementation.
 * @returns {{ base64: string, mimeType: string, sizeBytes: number, format: string }}
 * @throws {Error} if clipboard doesn't contain an image or tools aren't available
 */
function readImageFromClipboard() {
  const platform = os.platform();

  if (platform === 'linux') {
    return _readClipboardLinux();
  } else if (platform === 'darwin') {
    return _readClipboardMac();
  } else if (platform === 'win32') {
    return _readClipboardWindows();
  } else {
    throw new Error(`Clipboard image not supported on ${platform}`);
  }
}

function _readClipboardLinux() {
  // Try xclip first, then xsel
  try {
    const buf = execSync('xclip -selection clipboard -t image/png -o', {
      maxBuffer: MAX_IMAGE_BYTES,
      timeout: 5000,
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    if (buf.length > 0) {
      const format = detectFormat(buf) || 'png';
      return {
        base64: buf.toString('base64'),
        mimeType: MIME_MAP[format] || 'image/png',
        sizeBytes: buf.length,
        format,
      };
    }
  } catch { /* xclip failed */ }

  // Fallback: try wl-paste (Wayland)
  try {
    const buf = execSync('wl-paste --type image/png', {
      maxBuffer: MAX_IMAGE_BYTES,
      timeout: 5000,
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    if (buf.length > 0) {
      return {
        base64: buf.toString('base64'),
        mimeType: 'image/png',
        sizeBytes: buf.length,
        format: 'png',
      };
    }
  } catch { /* wl-paste failed */ }

  throw new Error('Clipboard is empty or does not contain an image. Install xclip (X11) or wl-paste (Wayland).');
}

function _readClipboardMac() {
  // Use pngpaste if available, otherwise osascript
  const tmpFile = path.join(os.tmpdir(), `khy_clipboard_${Date.now()}.png`);

  try {
    execSync(`pngpaste "${tmpFile}"`, { timeout: 5000, stdio: 'pipe' });
    if (fs.existsSync(tmpFile)) {
      const result = readImageFromFile(tmpFile);
      fs.unlinkSync(tmpFile);
      return result;
    }
  } catch { /* pngpaste not available */ }

  // Fallback: osascript
  try {
    execSync(`osascript -e 'set theFile to (POSIX file "${tmpFile}") as text' -e 'tell application "System Events" to set imageData to the clipboard as «class PNGf»' -e 'set fileRef to open for access file theFile with write permission' -e 'write imageData to fileRef' -e 'close access fileRef'`, {
      timeout: 5000,
      stdio: 'pipe',
    });
    if (fs.existsSync(tmpFile)) {
      const result = readImageFromFile(tmpFile);
      fs.unlinkSync(tmpFile);
      return result;
    }
  } catch { /* osascript failed */ }

  throw new Error('Clipboard is empty or does not contain an image. Install pngpaste: brew install pngpaste');
}

function _readClipboardWindows() {
  const tmpFile = path.join(os.tmpdir(), `khy_clipboard_${Date.now()}.png`);
  try {
    execSync(
      `powershell -command "Add-Type -AssemblyName System.Windows.Forms; $img = [System.Windows.Forms.Clipboard]::GetImage(); if ($img -ne $null) { $img.Save('${tmpFile.replace(/\\/g, '\\\\')}', [System.Drawing.Imaging.ImageFormat]::Png) }"`,
      { timeout: 10000, stdio: 'pipe' }
    );
    if (fs.existsSync(tmpFile)) {
      const result = readImageFromFile(tmpFile);
      fs.unlinkSync(tmpFile);
      return result;
    }
  } catch { /* PowerShell failed */ }

  throw new Error('Clipboard is empty or does not contain an image.');
}

/**
 * Check if clipboard likely contains an image (quick, no full read).
 * @returns {boolean}
 */
function isClipboardImageAvailable() {
  const platform = os.platform();
  try {
    if (platform === 'linux') {
      const targets = execSync('xclip -selection clipboard -t TARGETS -o', {
        encoding: 'utf-8',
        timeout: 2000,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      return targets.includes('image/png') || targets.includes('image/jpeg');
    } else if (platform === 'darwin') {
      const result = execSync("osascript -e 'clipboard info'", {
        encoding: 'utf-8',
        timeout: 2000,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      return result.includes('«class PNGf»') || result.includes('«class TIFF»');
    } else if (platform === 'win32') {
      const result = execSync(
        'powershell -command "[System.Windows.Forms.Clipboard]::ContainsImage()"',
        { encoding: 'utf-8', timeout: 3000, stdio: ['pipe', 'pipe', 'pipe'] }
      );
      return result.trim().toLowerCase() === 'true';
    }
  } catch { /* ignore */ }
  return false;
}

/**
 * Print an image preview in the terminal.
 * Uses iTerm2 inline image protocol if supported, otherwise text summary.
 *
 * @param {{ base64: string, mimeType: string, sizeBytes: number, format: string }} image
 */
function printImagePreview(image) {
  const sizeStr = image.sizeBytes >= 1024 * 1024
    ? `${(image.sizeBytes / 1024 / 1024).toFixed(1)}MB`
    : `${(image.sizeBytes / 1024).toFixed(0)}KB`;

  // Check for iTerm2 or compatible terminal
  const term = process.env.TERM_PROGRAM || '';
  const isITerm = term === 'iTerm.app' || term === 'WezTerm' || process.env.KITTY_WINDOW_ID;

  if (isITerm && process.stdout.isTTY) {
    // iTerm2 inline image protocol
    const params = `inline=1;size=${image.sizeBytes};width=40;preserveAspectRatio=1`;
    process.stdout.write(`\x1b]1337;File=${params}:${image.base64}\x07\n`);
  } else {
    // Fallback: text-only summary
    let _chalk;
    const c = () => (_chalk ??= (require('chalk').default || require('chalk')));
    console.log(`  ${c().cyan('📷')} ${c().white(`[Image: ${image.format.toUpperCase()}, ${sizeStr}]`)}`);
  }
}

/**
 * Format image data for a specific AI provider.
 * Returns the provider-specific payload structure.
 *
 * @param {'google'|'openai'|'anthropic'} provider
 * @param {{ base64: string, mimeType: string }} image
 * @returns {object} provider-specific image payload
 */
function formatImageForProvider(provider, image) {
  switch (provider) {
    case 'google':
      return { inlineData: { mimeType: image.mimeType, data: image.base64 } };
    case 'openai':
      return {
        type: 'image_url',
        image_url: { url: `data:${image.mimeType};base64,${image.base64}`, detail: 'auto' },
      };
    case 'anthropic':
      return {
        type: 'image',
        source: { type: 'base64', media_type: image.mimeType, data: image.base64 },
      };
    default:
      return null;
  }
}

module.exports = {
  readImageFromFile,
  readImageFromClipboard,
  isClipboardImageAvailable,
  printImagePreview,
  formatImageForProvider,
  detectFormat,
  MAX_IMAGE_BYTES,
};
