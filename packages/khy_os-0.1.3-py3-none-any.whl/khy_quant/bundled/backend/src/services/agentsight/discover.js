/**
 * Agent Discovery — AI agent process auto-discovery.
 *
 * Aligned with ANOLISA AgentSight discover module:
 * - Scans running processes for known AI agent patterns
 * - Identifies agent type, PID, and connection info
 * - Supports Linux (/proc), macOS (ps), and Windows (tasklist)
 *
 * Known agent patterns are extensible via addAgentPattern().
 */

'use strict';

const { execSync } = require('child_process');
const os = require('os');

// ─── Known Agent Patterns ───────────────────────────────────────────────────

const AGENT_PATTERNS = [
  {
    name: 'Claude Code',
    processPatterns: ['claude', 'claude-code', 'anthropic'],
    category: 'coding-agent',
    ports: [3000, 8080],
  },
  {
    name: 'OpenAI Codex CLI',
    processPatterns: ['codex', 'openai'],
    category: 'coding-agent',
    ports: [],
  },
  {
    name: 'Cursor',
    processPatterns: ['cursor', 'Cursor'],
    category: 'ide-agent',
    ports: [],
  },
  {
    name: 'Windsurf',
    processPatterns: ['windsurf', 'codeium'],
    category: 'ide-agent',
    ports: [],
  },
  {
    name: 'Copilot',
    processPatterns: ['copilot', 'github-copilot'],
    category: 'ide-agent',
    ports: [],
  },
  {
    name: 'Ollama',
    processPatterns: ['ollama'],
    category: 'local-llm',
    ports: [11434],
  },
  {
    name: 'LM Studio',
    processPatterns: ['lm-studio', 'lmstudio', 'LM Studio'],
    category: 'local-llm',
    ports: [1234],
  },
  {
    name: 'KHY Quant',
    processPatterns: ['khyquant', 'khy-quant', 'khy_quant'],
    category: 'khy-os',
    ports: [3000, 5000],
  },
  {
    name: 'Aider',
    processPatterns: ['aider'],
    category: 'coding-agent',
    ports: [],
  },
  {
    name: 'Open Interpreter',
    processPatterns: ['interpreter', 'open-interpreter'],
    category: 'coding-agent',
    ports: [],
  },
];

// Custom patterns added at runtime
const _customPatterns = [];

// ─── Discovery Functions ────────────────────────────────────────────────────

/**
 * Discover running AI agent processes.
 * Cross-platform: uses /proc on Linux, ps on macOS, tasklist on Windows.
 *
 * @returns {Array<{ name: string, category: string, pid: number, cmdline: string, ports: number[] }>}
 */
function discoverAgents() {
  const platform = os.platform();
  const allPatterns = [...AGENT_PATTERNS, ..._customPatterns];

  try {
    const processes = _getProcessList(platform);
    const found = [];

    for (const proc of processes) {
      for (const agent of allPatterns) {
        for (const pattern of agent.processPatterns) {
          if (proc.cmdline.toLowerCase().includes(pattern.toLowerCase())) {
            // Avoid duplicate matches for same PID
            if (!found.some(f => f.pid === proc.pid)) {
              found.push({
                name: agent.name,
                category: agent.category,
                pid: proc.pid,
                cmdline: proc.cmdline.slice(0, 200),
                ports: agent.ports,
              });
            }
            break;
          }
        }
      }
    }

    return found;
  } catch {
    return [];
  }
}

/**
 * Check if a specific agent is running.
 * @param {string} agentName - Name from AGENT_PATTERNS
 * @returns {{ running: boolean, pids: number[] }}
 */
function isAgentRunning(agentName) {
  const agents = discoverAgents();
  const matches = agents.filter(a => a.name.toLowerCase() === agentName.toLowerCase());
  return {
    running: matches.length > 0,
    pids: matches.map(a => a.pid),
  };
}

/**
 * Add a custom agent pattern for discovery.
 * @param {{ name: string, processPatterns: string[], category: string, ports: number[] }} pattern
 */
function addAgentPattern(pattern) {
  if (pattern && pattern.name && Array.isArray(pattern.processPatterns)) {
    _customPatterns.push(pattern);
  }
}

/**
 * Get summary of all discovered agents.
 * @returns {{ total: number, byCategory: object, agents: Array }}
 */
function getDiscoverySummary() {
  const agents = discoverAgents();
  const byCategory = {};

  for (const agent of agents) {
    byCategory[agent.category] = (byCategory[agent.category] || 0) + 1;
  }

  return {
    total: agents.length,
    byCategory,
    agents,
    timestamp: new Date().toISOString(),
  };
}

// ─── Internal: Process List ─────────────────────────────────────────────────

function _getProcessList(platform) {
  const processes = [];

  if (platform === 'linux') {
    // Use /proc for efficiency
    try {
      const pids = execSync('ls /proc | grep -E "^[0-9]+$" | head -500', {
        encoding: 'utf-8', timeout: 5000, stdio: 'pipe',
      }).trim().split('\n');

      for (const pidStr of pids) {
        try {
          const cmdline = execSync(`cat /proc/${pidStr}/cmdline 2>/dev/null | tr '\\0' ' '`, {
            encoding: 'utf-8', timeout: 1000, stdio: 'pipe',
          }).trim();
          if (cmdline) {
            processes.push({ pid: parseInt(pidStr, 10), cmdline });
          }
        } catch { /* process may have exited */ }
      }
    } catch {
      // Fallback to ps
      return _psProcessList();
    }
  } else if (platform === 'win32') {
    try {
      const output = execSync('tasklist /V /FO CSV 2>nul', {
        encoding: 'utf-8', timeout: 5000, stdio: 'pipe',
      });
      const lines = output.split('\n').slice(1);
      for (const line of lines) {
        const parts = line.split('","');
        if (parts.length >= 2) {
          const name = parts[0].replace(/"/g, '');
          const pid = parseInt(parts[1], 10);
          if (name && pid) {
            processes.push({ pid, cmdline: name });
          }
        }
      }
    } catch { /* ignore */ }
  } else {
    // macOS and other Unix
    return _psProcessList();
  }

  return processes;
}

function _psProcessList() {
  const processes = [];
  try {
    const output = execSync('ps aux 2>/dev/null | head -500', {
      encoding: 'utf-8', timeout: 5000, stdio: 'pipe',
    });
    const lines = output.split('\n').slice(1);
    for (const line of lines) {
      const parts = line.trim().split(/\s+/);
      if (parts.length >= 11) {
        const pid = parseInt(parts[1], 10);
        const cmdline = parts.slice(10).join(' ');
        if (pid && cmdline) {
          processes.push({ pid, cmdline });
        }
      }
    }
  } catch { /* ignore */ }
  return processes;
}

module.exports = {
  discoverAgents,
  isAgentRunning,
  addAgentPattern,
  getDiscoverySummary,
  AGENT_PATTERNS,
};
