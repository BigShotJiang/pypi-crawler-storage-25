/**
 * Local LLM Service — direct GGUF model inference
 *
 * Loads Qwen 3.5 4B (or other GGUF models) directly.
 * Strategy:
 *   1. Try ollama-runner (standalone, no Ollama service needed)
 *   2. Try node-llama-cpp (ESM, dynamic import)
 *   3. Fallback to Python inference_server.py (HTTP API at localhost:8765)
 *   4. Fallback to Ollama HTTP API (requires Ollama service)
 *
 * ollama-runner is the preferred backend because it uses Ollama's patched
 * llama.cpp which supports Qwen 3.5 hybrid SSM+Attention out of the box.
 */
const path = require('path');
const fs = require('fs');
const http = require('http');
const net = require('net');
const os = require('os');
const { spawn, spawnSync, execFileSync } = require('child_process');
const { safeKill } = require('../tools/platformUtils');

const DEFAULT_MODEL_PATH = process.env.LOCAL_MODEL_PATH
  || path.join(__dirname, '../../models/qwen3.5-4b.gguf');
// Also check the Ollama-format model (symlink to blob, works with ollama-runner)
const OLLAMA_MODEL_PATH = path.join(__dirname, '../../models/qwen3.5-4b-ollama.gguf');
// Also check the export model
const EXPORT_MODEL_PATH = path.join(__dirname, '../../models/qwen3.5-4b-export.gguf');
const INFERENCE_SERVER_PORT = parseInt(process.env.INFERENCE_SERVER_PORT || '8765', 10);
const INFERENCE_SERVER_URL = `http://127.0.0.1:${INFERENCE_SERVER_PORT}`;
const OLLAMA_RUNNER_PORT = parseInt(process.env.OLLAMA_RUNNER_PORT || '8767', 10);
const OLLAMA_HOST = process.env.OLLAMA_HOST || 'http://localhost:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'qwen3.5:4b';
let _autoLocalAiEnv = null;
function _getAutoLocalAiEnv() {
  if (_autoLocalAiEnv) return _autoLocalAiEnv;
  try {
    const hw = require('./hardwareProfileService');
    const tuning = hw && typeof hw.recommendLocalAiTuning === 'function'
      ? hw.recommendLocalAiTuning('auto')
      : null;
    _autoLocalAiEnv = (tuning && tuning.env) ? tuning.env : {};
  } catch {
    _autoLocalAiEnv = {};
  }
  return _autoLocalAiEnv;
}
function _envIntWithAuto(key, hardDefault) {
  const raw = process.env[key];
  if (raw !== undefined && String(raw).trim() !== '') {
    const parsed = parseInt(String(raw).trim(), 10);
    if (Number.isFinite(parsed)) return parsed;
  }
  const auto = parseInt(String(_getAutoLocalAiEnv()[key] || ''), 10);
  if (Number.isFinite(auto)) return auto;
  return hardDefault;
}
const RUNNER_HEALTH_TIMEOUT_MS = Math.max(
  300,
  _envIntWithAuto('KHY_LOCAL_RUNNER_HEALTH_TIMEOUT_MS', 1200)
);
const RUNNER_START_TIMEOUT_MS = Math.max(
  3000,
  _envIntWithAuto('KHY_LOCAL_RUNNER_START_TIMEOUT_MS', 15000)
);
const RUNNER_LOAD_TIMEOUT_MS = Math.max(
  10000,
  _envIntWithAuto('KHY_LOCAL_RUNNER_LOAD_TIMEOUT_MS', 120000)
);
const RUNNER_HOT_ATTACH_TIMEOUT_MS = Math.max(
  200,
  _envIntWithAuto('KHY_LOCAL_HOT_ATTACH_TIMEOUT_MS', 900)
);

function resolveOllamaBinary() {
  const envBin = String(process.env.OLLAMA_BIN || '').trim();
  if (envBin) return envBin;

  // Bundled runner inside the project (no system ollama install needed)
  const bundledBase = path.join(__dirname, '../../bin/ollama-runner/bin');
  const bundledCandidates = process.platform === 'win32'
    ? [path.join(bundledBase, 'ollama.exe'), path.join(bundledBase, 'ollama')]
    : [path.join(bundledBase, 'ollama')];
  for (const candidate of bundledCandidates) {
    if (fs.existsSync(candidate)) return candidate;
  }

  // System-installed fallback
  if (process.platform === 'win32') {
    const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    const programFiles = process.env.ProgramFiles || 'C:\\Program Files';
    const candidates = [
      path.join(localAppData, 'Programs', 'Ollama', 'ollama.exe'),
      path.join(programFiles, 'Ollama', 'ollama.exe'),
      'ollama.exe',
      'ollama',
    ];
    for (const p of candidates) {
      if (p.includes('\\') || p.includes('/')) {
        if (fs.existsSync(p)) return p;
      } else {
        return p; // PATH command candidate
      }
    }
  } else {
    const candidates = [
      '/usr/local/bin/ollama',
      '/usr/bin/ollama',
      '/opt/homebrew/bin/ollama',
      'ollama',
    ];
    for (const p of candidates) {
      if (p.startsWith('/')) {
        if (fs.existsSync(p)) return p;
      } else {
        return p; // PATH command candidate
      }
    }
  }

  return process.platform === 'win32' ? 'ollama.exe' : 'ollama';
}

function resolvePythonLauncher() {
  const envCmd = String(process.env.KHY_PYTHON_BIN || '').trim();
  const candidates = [];
  if (envCmd) candidates.push({ cmd: envCmd, preArgs: [] });
  if (process.platform === 'win32') {
    candidates.push({ cmd: 'python', preArgs: [] });
    candidates.push({ cmd: 'py', preArgs: ['-3'] });
  } else {
    candidates.push({ cmd: 'python3', preArgs: [] });
    candidates.push({ cmd: 'python', preArgs: [] });
  }

  for (const candidate of candidates) {
    try {
      const probe = spawnSync(candidate.cmd, [...candidate.preArgs, '--version'], {
        stdio: 'ignore',
        timeout: 3000,
        windowsHide: true,
      });
      if (!probe.error && probe.status === 0) return candidate;
    } catch { /* keep probing */ }
  }

  // Return the first candidate even if not verified, so downstream error is explicit.
  return candidates[0];
}

function terminateChildTree(child) {
  safeKill(child);
}

const OLLAMA_BIN = resolveOllamaBinary();
const PYTHON_LAUNCHER = resolvePythonLauncher();

let _modelPath = DEFAULT_MODEL_PATH;
let _backend = null; // 'ollama-runner' | 'node-llama-cpp' | 'python-server' | 'ollama' | null
let _llama = null;
let _model = null;
let _context = null;
let _loadingPromise = null;
let _lastError = null;
let _pythonProcess = null;
let _runnerProcess = null;
let _runnerReady = false;
let _pythonLlamaCppAvailable = null;
let _pythonLlamaCppError = '';
let _loopbackListenProbe = { ok: null, at: 0, error: '' };
const LOCAL_LLM_VERBOSE = ['1', 'true', 'yes', 'on'].includes(
  String(process.env.KHY_LOCAL_LLM_VERBOSE || '').toLowerCase()
);

function localLLMLog(message) {
  if (!LOCAL_LLM_VERBOSE) return;
  console.log(message);
}

async function canListenLoopback(forceRefresh = false) {
  const ttlMs = Math.max(
    1000,
    parseInt(process.env.KHY_LOCAL_LOOPBACK_PROBE_TTL_MS || '30000', 10) || 30000
  );
  const timeoutMs = Math.max(
    300,
    parseInt(process.env.KHY_LOCAL_LOOPBACK_PROBE_TIMEOUT_MS || '1200', 10) || 1200
  );

  if (!forceRefresh && _loopbackListenProbe.ok !== null && (Date.now() - _loopbackListenProbe.at) < ttlMs) {
    return _loopbackListenProbe.ok;
  }

  const result = await new Promise((resolve) => {
    const server = net.createServer();
    let settled = false;

    const finish = (ok, errMsg = '') => {
      if (settled) return;
      settled = true;
      try { server.close(); } catch { /* ignore */ }
      resolve({ ok, error: errMsg });
    };

    server.once('error', (err) => {
      finish(false, err && err.message ? err.message : String(err || 'loopback listen failed'));
    });
    server.listen(0, '127.0.0.1', () => finish(true, ''));

    const timer = setTimeout(() => finish(false, 'loopback listen probe timed out'), timeoutMs);
    timer.unref?.();
  });

  _loopbackListenProbe = { ok: !!result.ok, at: Date.now(), error: String(result.error || '') };
  return _loopbackListenProbe.ok;
}

/**
 * Check if model file exists (checks default, Ollama-format, and export paths).
 */
function isModelAvailable() {
  try {
    if (fs.existsSync(_modelPath)) return true;
    // Prefer the Ollama-format model (works with ollama-runner out of the box)
    if (fs.existsSync(OLLAMA_MODEL_PATH)) {
      _modelPath = OLLAMA_MODEL_PATH;
      return true;
    }
    if (fs.existsSync(EXPORT_MODEL_PATH)) {
      _modelPath = EXPORT_MODEL_PATH;
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

/**
 * Find the best model path for ollama-runner.
 * Prefers Ollama-format GGUF (blob symlink) as it works without patches.
 */
function findRunnerModelPath() {
  // Ollama blob format works directly with ollama-runner (no tensor renaming needed)
  if (fs.existsSync(OLLAMA_MODEL_PATH)) return OLLAMA_MODEL_PATH;

  // Also check if there's a direct blob in ~/.ollama
  const ollamaBlobs = path.join(os.homedir(), '.ollama', 'models', 'blobs');
  if (fs.existsSync(ollamaBlobs)) {
    try {
      const files = fs.readdirSync(ollamaBlobs);
      // Find the largest blob (likely the model weights)
      let bestFile = null;
      let bestSize = 0;
      for (const f of files) {
        const fp = path.join(ollamaBlobs, f);
        const stat = fs.statSync(fp);
        if (stat.size > bestSize) {
          bestSize = stat.size;
          bestFile = fp;
        }
      }
      // Model files are typically > 1GB
      if (bestFile && bestSize > 1e9) return bestFile;
    } catch {}
  }

  // Fallback to export model (may need patches for upstream llama.cpp, but works with ollama-runner)
  if (fs.existsSync(EXPORT_MODEL_PATH)) return EXPORT_MODEL_PATH;
  if (fs.existsSync(DEFAULT_MODEL_PATH)) return DEFAULT_MODEL_PATH;
  return _modelPath;
}

/**
 * Check if ollama binary supports the `runner` subcommand.
 */
function isOllamaRunnerAvailable() {
  try {
    // runner --help prints to stderr, so we need to capture both
    const result = spawnSync(OLLAMA_BIN, ['runner', '--help'], {
      timeout: 3000,
      encoding: 'utf-8',
      windowsHide: true,
    });
    const output = (result.stdout || '') + (result.stderr || '');
    return output.includes('-model') || output.includes('Runner');
  } catch {
    return false;
  }
}

/**
 * Fast preflight: verify Python has llama-cpp-python importable.
 * Avoid waiting up to 60s on a detached server process that exits immediately.
 */
function isPythonLlamaCppAvailable(forceRefresh = false) {
  if (!forceRefresh && _pythonLlamaCppAvailable !== null) return _pythonLlamaCppAvailable;
  try {
    execFileSync(PYTHON_LAUNCHER.cmd, [...PYTHON_LAUNCHER.preArgs, '-c', 'import llama_cpp'], {
      stdio: 'ignore',
      timeout: 4000,
      env: process.env,
    });
    _pythonLlamaCppAvailable = true;
    _pythonLlamaCppError = '';
    return true;
  } catch (err) {
    _pythonLlamaCppAvailable = false;
    _pythonLlamaCppError = err.message || String(err || 'llama_cpp import failed');
    return false;
  }
}

/**
 * HTTP helper for ollama-runner (raw HTTP, streams NDJSON).
 * @param {number} port
 * @param {string} urlPath
 * @param {object} body
 * @param {object} [streamOpts] - { onChunk, timeoutMs }
 */
function runnerPost(port, urlPath, body, streamOpts = {}) {
  const timeoutMs = streamOpts.timeoutMs || 60_000;
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    let lastActivity = Date.now();

    const req = http.request({
      hostname: '127.0.0.1',
      port,
      path: urlPath,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data),
      },
      timeout: timeoutMs,
    }, (res) => {
      const parsed = [];
      let partialLine = '';

      // Idle timer: abort if no data received for 30s during inference
      const idleLimit = 30_000;
      const idleCheck = setInterval(() => {
        if (Date.now() - lastActivity > idleLimit) {
          clearInterval(idleCheck);
          req.destroy(new Error('Runner inference stalled (no output for 30s)'));
        }
      }, 5000);
      if (idleCheck.unref) idleCheck.unref();

      res.on('data', chunk => {
        lastActivity = Date.now();
        partialLine += chunk.toString('utf-8');

        // Parse complete NDJSON lines as they arrive
        const lines = partialLine.split('\n');
        partialLine = lines.pop(); // keep incomplete last line

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          try {
            const obj = JSON.parse(trimmed);
            parsed.push(obj);
            // Stream text chunks to caller immediately
            if (streamOpts.onChunk && obj.content) {
              streamOpts.onChunk({ type: 'text', text: obj.content });
            }
          } catch { /* skip malformed */ }
        }
      });

      res.on('end', () => {
        clearInterval(idleCheck);
        // Parse any remaining partial line
        if (partialLine.trim()) {
          try {
            const obj = JSON.parse(partialLine.trim());
            parsed.push(obj);
            if (streamOpts.onChunk && obj.content) {
              streamOpts.onChunk({ type: 'text', text: obj.content });
            }
          } catch { /* skip */ }
        }
        const raw = parsed.map(p => JSON.stringify(p)).join('\n');
        resolve({ status: res.statusCode, data: parsed, raw });
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Runner request timeout')); });
    req.write(data);
    req.end();
  });
}

function runnerGet(port, urlPath, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const req = http.request({
      hostname: '127.0.0.1',
      port,
      path: urlPath,
      method: 'GET',
      timeout: Math.max(200, Number(timeoutMs) || 5000),
    }, (res) => {
      const chunks = [];
      res.on('data', chunk => { chunks.push(chunk); });
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf-8');
        try { resolve({ status: res.statusCode, data: JSON.parse(raw) }); }
        catch { resolve({ status: res.statusCode, data: raw }); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.end();
  });
}

function _isRunnerHealthReady(data) {
  if (!data || typeof data !== 'object') return false;
  const status = data.status;
  const progress = Number(data.progress);
  const readyByStatus = status === 0
    || status === '0'
    || String(status || '').toLowerCase() === 'ready'
    || String(status || '').toLowerCase() === 'ok';
  if (!readyByStatus) return false;
  // Some runner builds may omit progress; treat missing progress as ready.
  if (!Number.isFinite(progress)) return true;
  return progress >= 1;
}

async function tryAdoptHotRunner(options = {}) {
  if (_backend && _backend !== 'ollama-runner') {
    return { adopted: false, ready: false, listening: false, reason: `backend already loaded: ${_backend}` };
  }
  const timeoutMs = Math.max(
    200,
    parseInt(options.timeoutMs || process.env.KHY_LOCAL_HOT_ATTACH_TIMEOUT_MS || String(RUNNER_HOT_ATTACH_TIMEOUT_MS), 10)
      || RUNNER_HOT_ATTACH_TIMEOUT_MS
  );
  try {
    const res = await runnerGet(OLLAMA_RUNNER_PORT, '/health', timeoutMs);
    if (res.status !== 200) {
      return { adopted: false, ready: false, listening: false, reason: `health ${res.status}` };
    }
    const health = (res && typeof res.data === 'object' && res.data) ? res.data : {};
    const ready = _isRunnerHealthReady(health);
    if (!ready) {
      _runnerReady = false;
      return { adopted: false, ready: false, listening: true, health };
    }
    _runnerReady = true;
    _backend = 'ollama-runner';
    _lastError = null;
    return { adopted: true, ready: true, listening: true, health };
  } catch (err) {
    return { adopted: false, ready: false, listening: false, reason: String(err && err.message ? err.message : err || 'unknown') };
  }
}

/**
 * Check if ollama-runner is healthy and model is loaded.
 * Runner health returns: status 0 = ready, 2 = launched, 3 = loading
 */
async function isRunnerReady() {
  try {
    const res = await runnerGet(
      OLLAMA_RUNNER_PORT,
      '/health',
      parseInt(process.env.KHY_LOCAL_RUNNER_HEALTH_TIMEOUT_MS || String(RUNNER_HEALTH_TIMEOUT_MS), 10) || RUNNER_HEALTH_TIMEOUT_MS
    );
    if (res.status !== 200) return false;
    const data = typeof res.data === 'object' ? res.data : {};
    return _isRunnerHealthReady(data);
  } catch {
    return false;
  }
}

/**
 * Check if ollama-runner is at least listening (not necessarily model loaded).
 */
async function isRunnerListening() {
  try {
    const res = await runnerGet(
      OLLAMA_RUNNER_PORT,
      '/health',
      parseInt(process.env.KHY_LOCAL_RUNNER_HEALTH_TIMEOUT_MS || String(RUNNER_HEALTH_TIMEOUT_MS), 10) || RUNNER_HEALTH_TIMEOUT_MS
    );
    return res.status === 200;
  } catch {
    return false;
  }
}

async function _loadRunnerModel(options = {}) {
  const requireChildAlive = options.requireChildAlive !== false;
  const loadTimeoutMs = Math.max(
    10000,
    parseInt(process.env.KHY_LOCAL_RUNNER_LOAD_TIMEOUT_MS || String(RUNNER_LOAD_TIMEOUT_MS), 10) || RUNNER_LOAD_TIMEOUT_MS
  );

    const numCPU = os.cpus().length;
  const loadRes = await runnerPost(OLLAMA_RUNNER_PORT, '/load', {
    Operation: 2, // LoadOperationCommit
    KvSize: 8192,
    BatchSize: 512,
    Parallel: 1,
    NumThreads: Math.max(1, Math.floor(numCPU * 0.75)),
    MultiUserCache: false,
  });

  if (loadRes.status !== 200) {
    localLLMLog(`[LocalLLM] Runner load failed: ${loadRes.raw?.slice(0, 300)}`);
    return false;
  }

  // Wait for model to be fully loaded
  // Runner health: status 0 = ready, 2 = launched, 3 = loading
  const loadDeadline = Date.now() + loadTimeoutMs;
  while (Date.now() < loadDeadline) {
    await new Promise(r => setTimeout(r, 1000));
    if (await isRunnerReady()) {
      _runnerReady = true;
      localLLMLog('[LocalLLM] Ollama runner model loaded successfully!');
      return true;
    }
    if (requireChildAlive && !_runnerProcess) {
      localLLMLog('[LocalLLM] Runner process died during model loading');
      return false;
    }
  }

  localLLMLog('[LocalLLM] Runner model loading timed out');
  return false;
}

/**
 * Start ollama runner as standalone subprocess and load the model.
 * Uses --ollama-engine flag to enable the Go-native engine (supports Qwen 3.5).
 */
async function startOllamaRunner(options = {}) {
  const allowSpawn = options.allowSpawn !== false;

  const adopted = await tryAdoptHotRunner({
    timeoutMs: parseInt(
      process.env.KHY_LOCAL_HOT_ATTACH_TIMEOUT_MS || String(RUNNER_HOT_ATTACH_TIMEOUT_MS),
      10
    ) || RUNNER_HOT_ATTACH_TIMEOUT_MS,
  });
  if (adopted.adopted) {
    localLLMLog('[LocalLLM] Reusing hot ollama-runner backend');
    return true;
  }

  const runnerListening = adopted.listening || await isRunnerListening();
  if (runnerListening) {
    localLLMLog('[LocalLLM] Existing ollama-runner detected; issuing model load...');
    try {
      if (await _loadRunnerModel({ requireChildAlive: false })) {
        _backend = 'ollama-runner';
        _lastError = null;
        return true;
      }
    } catch (err) {
      localLLMLog(`[LocalLLM] Existing runner load request failed: ${err.message}`);
    }
  }

  if (!allowSpawn) {
    localLLMLog('[LocalLLM] Loopback listen unavailable; skip spawning new ollama-runner process');
    return false;
  }

  if (!isOllamaRunnerAvailable()) {
    localLLMLog('[LocalLLM] ollama binary does not support runner subcommand');
    return false;
  }

  const runnerModelPath = findRunnerModelPath();
  if (!fs.existsSync(runnerModelPath)) {
    localLLMLog('[LocalLLM] No suitable model file found for ollama-runner');
    return false;
  }

  try {
    localLLMLog(`[LocalLLM] Starting ollama runner on port ${OLLAMA_RUNNER_PORT}...`);
    localLLMLog(`[LocalLLM] Model: ${runnerModelPath}`);

    _runnerProcess = spawn(OLLAMA_BIN, [
      'runner',
      '--ollama-engine',  // Use Go-native engine (supports qwen35/qwen3next)
      '--model', runnerModelPath,
      '--port', String(OLLAMA_RUNNER_PORT),
    ], {
      detached: true,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, OLLAMA_LOG_LEVEL: 'warn' },
      windowsHide: true,
    });

    // Collect stderr for debugging — log all output in first 30s for diagnostics
    let stderrBuf = '';
    const runnerStartTime = Date.now();
    _runnerProcess.stderr.on('data', (data) => {
      const line = data.toString();
      stderrBuf += line;
      if (stderrBuf.length > 4096) stderrBuf = stderrBuf.slice(-2048);
      // Always log during startup phase (first 30s) or on important keywords
      const isStartup = Date.now() - runnerStartTime < 30000;
      if (isStartup || line.includes('error') || line.includes('listening') || line.includes('loaded') || line.includes('ASSERT') || line.includes('fail')) {
        localLLMLog(`[OllamaRunner] ${line.trim()}`);
      }
    });

    _runnerProcess.stdout.on('data', (data) => {
      const line = data.toString().trim();
      if (line) localLLMLog(`[OllamaRunner:stdout] ${line}`);
    });

    _runnerProcess.on('exit', (code) => {
      localLLMLog(`[OllamaRunner] Process exited with code ${code}`);
      if (code !== 0 && stderrBuf) localLLMLog(`[OllamaRunner] Last stderr: ${stderrBuf.slice(-500)}`);
      _runnerProcess = null;
      _runnerReady = false;
    });

    _runnerProcess.unref();

    // Wait for server to come online (just listening, not model loaded yet)
    const startTimeoutMs = Math.max(
      3000,
      parseInt(process.env.KHY_LOCAL_RUNNER_START_TIMEOUT_MS || String(RUNNER_START_TIMEOUT_MS), 10) || RUNNER_START_TIMEOUT_MS
    );
    const deadline = Date.now() + startTimeoutMs;
    while (Date.now() < deadline) {
      await new Promise(r => setTimeout(r, 400));
      if (await isRunnerListening()) {
        localLLMLog('[LocalLLM] Ollama runner is online, loading model...');
        break;
      }
    }

    if (!(await isRunnerListening())) {
      localLLMLog('[LocalLLM] Ollama runner failed to start');
      if (_runnerProcess) terminateChildTree(_runnerProcess);
      _runnerProcess = null;
      return false;
    }

    if (!(await _loadRunnerModel({ requireChildAlive: true }))) {
      if (_runnerProcess) {
        terminateChildTree(_runnerProcess);
        _runnerProcess = null;
      }
      return false;
    }
    _backend = 'ollama-runner';
    _lastError = null;
    return true;
  } catch (err) {
    localLLMLog(`[LocalLLM] Failed to start ollama runner: ${err.message}`);
    _lastError = err;
    return false;
  }
}

/**
 * Generate via ollama-runner (standalone process).
 * Runner uses the same completion API as Ollama's internal runner protocol.
 *
 * Qwen 3.5 thinking mode is always active (runner doesn't support /no_think).
 * The <think>...</think> block is parsed out and returned separately.
 * Local model — no token billing, generous budget allocated.
 */
async function generateRunner(prompt, options) {
  // Build ChatML prompt from messages
  let fullPrompt = prompt;
  if (options.messages && Array.isArray(options.messages) && options.messages.length > 0) {
    const parts = [];
    if (options.system) {
      parts.push(`<|im_start|>system\n${options.system}<|im_end|>`);
    }
    for (const msg of options.messages) {
      if (msg.role === 'user') {
        parts.push(`<|im_start|>user\n${msg.content}<|im_end|>`);
      } else if (msg.role === 'assistant') {
        parts.push(`<|im_start|>assistant\n${msg.content}<|im_end|>`);
      } else if (msg.role === 'tool') {
        parts.push(`<|im_start|>user\n[Tool Results]: ${msg.content}<|im_end|>`);
      }
    }
    parts.push(`<|im_start|>assistant\n`);
    fullPrompt = parts.join('\n');
  } else if (options.system) {
    fullPrompt = `<|im_start|>system\n${options.system}<|im_end|>\n<|im_start|>user\n${prompt}<|im_end|>\n<|im_start|>assistant\n`;
  } else if (prompt) {
    fullPrompt = `<|im_start|>user\n${prompt}<|im_end|>\n<|im_start|>assistant\n`;
  }

  // Local model: reasonable token budget (avoid excessive thinking on simple queries)
  const numPredict = options.maxTokens ?? 1024;
  const inferenceTimeout = options.timeoutMs ?? 60_000;

  const res = await runnerPost(OLLAMA_RUNNER_PORT, '/completion', {
    Prompt: fullPrompt,
    Options: {
      temperature: options.temperature ?? 0.6,
      top_p: options.top_p ?? 0.85,
      num_predict: numPredict,
      stop: ['<|im_end|>', '<|endoftext|>'],
    },
  }, {
    onChunk: options.onChunk,
    timeoutMs: inferenceTimeout,
  });

  if (res.status !== 200) {
    throw new Error(`Runner completion failed: ${res.raw?.slice(0, 300)}`);
  }

  // Collect content from streamed NDJSON responses and token stats
  let rawContent = '';
  let promptEvalCount = 0;
  let evalCount = 0;
  for (const chunk of res.data) {
    if (chunk.content) rawContent += chunk.content;
    if (chunk.prompt_eval_count) promptEvalCount = chunk.prompt_eval_count;
    if (chunk.eval_count) evalCount = chunk.eval_count;
  }

  // Parse thinking block from output
  let thinking = '';
  let content = rawContent;

  const thinkMatch = rawContent.match(/<think>([\s\S]*?)<\/think>/);
  if (thinkMatch) {
    thinking = thinkMatch[1].trim();
    content = rawContent.replace(/<think>[\s\S]*?<\/think>\s*/, '').trim();
  } else {
    // Handle unclosed <think> block
    const unclosedMatch = rawContent.match(/<think>([\s\S]*)/);
    if (unclosedMatch) {
      // Try to find where thinking ends and content begins
      // Look for common patterns: double newline, or end of thinking markers
      const thinkingContent = unclosedMatch[1];
      const splitMatch = thinkingContent.match(/([\s\S]*?)(\n\n[\s\S]+)/);

      if (splitMatch) {
        // Found a natural break - first part is thinking, rest is content
        thinking = splitMatch[1].trim();
        content = splitMatch[2].trim();
      } else {
        // No clear break - treat everything as thinking, but keep it as content too
        thinking = thinkingContent.trim();
        content = thinkingContent.trim();
      }
    }
  }

  // Always return structured result with thinking + token stats
  return {
    content,
    thinking,
    tokenUsage: {
      promptTokens: promptEvalCount,
      completionTokens: evalCount,
      thinkingTokens: thinking ? Math.ceil(thinking.length / 3) : 0, // estimate
    },
  };
}

/**
 * HTTP request helper for Python inference server.
 */
function httpPost(urlPath, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const url = new URL(urlPath, INFERENCE_SERVER_URL);

    const req = http.request({
      hostname: '127.0.0.1',
      port: INFERENCE_SERVER_PORT,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data),
      },
      timeout: 120_000,
    }, (res) => {
      const chunks = [];
      res.on('data', chunk => { chunks.push(chunk); });
      res.on('end', () => {
        const responseData = Buffer.concat(chunks).toString('utf-8');
        try {
          resolve({ status: res.statusCode, data: JSON.parse(responseData) });
        } catch {
          resolve({ status: res.statusCode, data: responseData });
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Inference server timeout')); });
    req.write(data);
    req.end();
  });
}

function httpGet(urlPath) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlPath, INFERENCE_SERVER_URL);
    const req = http.request({
      hostname: '127.0.0.1',
      port: INFERENCE_SERVER_PORT,
      path: url.pathname,
      method: 'GET',
      timeout: 3000,
    }, (res) => {
      const chunks = [];
      res.on('data', chunk => { chunks.push(chunk); });
      res.on('end', () => {
        const data = Buffer.concat(chunks).toString('utf-8');
        try { resolve({ status: res.statusCode, data: JSON.parse(data) }); }
        catch { resolve({ status: res.statusCode, data }); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.end();
  });
}

/**
 * Check if Python inference server is running.
 */
async function isPythonServerRunning() {
  try {
    const res = await httpGet('/health');
    return res.status === 200 && res.data?.status === 'ok';
  } catch {
    return false;
  }
}

/**
 * Check if Ollama is running and has the target model.
 */
async function isOllamaAvailable() {
  try {
    const url = new URL('/api/tags', OLLAMA_HOST);
    const res = await new Promise((resolve, reject) => {
      const req = http.request({
        hostname: url.hostname === 'localhost' ? '127.0.0.1' : url.hostname,
        port: url.port,
        path: url.pathname,
        method: 'GET',
        timeout: 3000,
      }, (r) => {
        let data = '';
        r.on('data', c => { data += c; });
        r.on('end', () => {
          try { resolve({ status: r.statusCode, data: JSON.parse(data) }); }
          catch { resolve({ status: r.statusCode, data }); }
        });
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
      req.end();
    });

    if (res.status === 200 && res.data?.models) {
      const models = res.data.models.map(m => m.name || m.model);
      return models.some(m => m.startsWith(OLLAMA_MODEL.split(':')[0]));
    }
    return false;
  } catch {
    return false;
  }
}

/**
 * Generate via Ollama HTTP API.
 */
async function generateOllama(prompt, options) {
  const messages = options.messages || [{ role: 'user', content: prompt }];
  const allMessages = [];
  if (options.system) {
    allMessages.push({ role: 'system', content: options.system });
  }
  allMessages.push(...messages);

  const url = new URL('/api/chat', OLLAMA_HOST);
  const enableThinking = options.think !== false;
  const body = JSON.stringify({
    model: OLLAMA_MODEL,
    messages: allMessages,
    stream: false,
    think: enableThinking,
    options: {
      temperature: options.temperature ?? (enableThinking ? 0.6 : 0.1),
      top_p: options.top_p ?? 0.85,
      num_predict: enableThinking ? Math.max(options.maxTokens ?? 2048, 4096) : (options.maxTokens ?? 2048),
    },
  });

  const res = await new Promise((resolve, reject) => {
    const req = http.request({
      hostname: url.hostname === 'localhost' ? '127.0.0.1' : url.hostname,
      port: url.port,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
      timeout: 300_000,
    }, (r) => {
      let data = '';
      r.on('data', c => { data += c; });
      r.on('end', () => {
        try { resolve({ status: r.statusCode, data: JSON.parse(data) }); }
        catch { resolve({ status: r.statusCode, data }); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Ollama request timeout')); });
    req.write(body);
    req.end();
  });

  if (res.status === 200 && res.data?.message) {
    const content = res.data.message.content || '';
    const thinking = res.data.message.thinking || '';
    if (options.returnThinking) {
      return { content, thinking };
    }
    return content;
  }

  throw new Error(res.data?.error || `Ollama returned ${res.status}`);
}

/**
 * Start Python inference server if not running.
 */
async function startPythonServer() {
  if (await isPythonServerRunning()) return true;

  const serverScript = path.join(__dirname, '../../inference_server.py');
  if (!fs.existsSync(serverScript)) return false;
  if (!isPythonLlamaCppAvailable()) {
    localLLMLog(`[LocalLLM] llama-cpp-python unavailable, skipping Python server (${_pythonLlamaCppError || 'import failed'})`);
    return false;
  }

  try {
    const startupTimeoutMs = Math.max(
      5000,
      parseInt(process.env.KHY_LOCAL_PY_SERVER_START_TIMEOUT_MS || '60000', 10) || 60000
    );
    const startupPollMs = Math.max(
      250,
      parseInt(process.env.KHY_LOCAL_PY_SERVER_START_POLL_MS || '500', 10) || 500
    );
    let exited = false;
    let exitCode = null;
    let stderrTail = '';

    _pythonProcess = spawn(PYTHON_LAUNCHER.cmd, [
      ...PYTHON_LAUNCHER.preArgs,
      serverScript,
      '--model', _modelPath,
      '--port', String(INFERENCE_SERVER_PORT),
      '--preload',
    ], {
      detached: false,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, LOCAL_MODEL_PATH: _modelPath },
      windowsHide: true,
    });
    _pythonProcess.stdout?.on('data', () => { /* drain pipe */ });
    _pythonProcess.stderr?.on('data', (buf) => {
      const text = String(buf || '');
      if (!text) return;
      stderrTail += text;
      if (stderrTail.length > 4096) stderrTail = stderrTail.slice(-2048);
    });
    _pythonProcess.on('exit', (code) => {
      exited = true;
      exitCode = code;
    });
    _pythonProcess.on('error', (err) => {
      exited = true;
      if (stderrTail.length < 512) {
        stderrTail += `\nspawn error: ${err && err.message ? err.message : String(err)}`;
      }
    });
    _pythonProcess.unref?.();

    // Wait for server to come online. If process exits early, fail fast.
    const deadline = Date.now() + startupTimeoutMs;
    while (Date.now() < deadline) {
      if (exited) {
        const msg = String(stderrTail || '').replace(/\s+/g, ' ').trim();
        _lastError = new Error(
          msg
            ? `Python inference server exited early (code=${exitCode}): ${msg.slice(0, 260)}`
            : `Python inference server exited early (code=${exitCode})`
        );
        _pythonProcess = null;
        return false;
      }
      if (await isPythonServerRunning()) return true;
      await new Promise(r => setTimeout(r, startupPollMs));
    }

    const timeoutMsg = String(stderrTail || '').replace(/\s+/g, ' ').trim();
    _lastError = new Error(
      timeoutMsg
        ? `Python inference server startup timed out after ${Math.round(startupTimeoutMs / 1000)}s: ${timeoutMsg.slice(0, 260)}`
        : `Python inference server startup timed out after ${Math.round(startupTimeoutMs / 1000)}s`
    );
    return false;
  } catch (err) {
    _lastError = err;
    return false;
  }
}

/**
 * Try to load via node-llama-cpp (ESM dynamic import).
 */
async function tryNodeLlamaCpp() {
  try {
    const { getLlama } = await import('node-llama-cpp');
    _llama = await getLlama();
    _model = await _llama.loadModel({
      modelPath: _modelPath,
      gpuLayers: 0,
    });
    _context = await _model.createContext({ contextSize: 4096 });
    _backend = 'node-llama-cpp';
    return true;
  } catch (err) {
    // node-llama-cpp not available or model format unsupported
    localLLMLog(`[LocalLLM] node-llama-cpp unavailable: ${err.message}`);
    return false;
  }
}

/**
 * Ensure inference backend is ready.
 */
async function ensureLoaded() {
  if (_backend) return _backend;
  if (_loadingPromise) return _loadingPromise;

  _loadingPromise = (async () => {
    try {
      const modelFileExists = isModelAvailable();
      const loopbackAvailable = await canListenLoopback();
      if (!loopbackAvailable) {
        localLLMLog(`[LocalLLM] Loopback sockets unavailable (${_loopbackListenProbe.error || 'listen failed'}), spawn-based local backends may be restricted`);
      }

      // Strategy 1: ollama-runner (standalone subprocess, best Qwen 3.5 support)
      // Even when loopback listen is blocked, still try to attach to an already-running runner.
      {
        localLLMLog('[LocalLLM] Trying ollama-runner (standalone)...');
        if (await startOllamaRunner({ allowSpawn: loopbackAvailable && modelFileExists })) {
          _backend = 'ollama-runner';
          _lastError = null;
          localLLMLog(`[LocalLLM] Using ollama-runner backend (no Ollama service needed)`);
          return _backend;
        }
      }

      // Strategy 2: try node-llama-cpp (requires model file)
      if (modelFileExists && await tryNodeLlamaCpp()) {
        _lastError = null;
        return _backend;
      }

      // Strategy 3: Python inference server (requires model file)
      if (!modelFileExists) {
        localLLMLog('[LocalLLM] No model file, skipping Python server...');
      }
      localLLMLog('[LocalLLM] Falling back to Python inference server...');
      const started = modelFileExists && loopbackAvailable && await startPythonServer();
      if (started) {
        _backend = 'python-server';
        _lastError = null;
        return _backend;
      }

      // Strategy 4: Ollama HTTP API (uses Ollama's own llama.cpp which supports newer models)
      localLLMLog('[LocalLLM] Falling back to Ollama HTTP API...');
      if (await isOllamaAvailable()) {
        _backend = 'ollama';
        _lastError = null;
        localLLMLog(`[LocalLLM] Using Ollama backend with model: ${OLLAMA_MODEL}`);
        return _backend;
      }

      if (!loopbackAvailable) {
        throw new Error(
          `No inference backend available in current runtime: loopback listen is not permitted (${_loopbackListenProbe.error || 'listen failed'}), and no hot local runner/Ollama HTTP backend was reachable.`
        );
      }
      throw new Error('No inference backend available. Install ollama (for ollama-runner), node-llama-cpp, llama-cpp-python, or run Ollama service.');
    } catch (err) {
      _lastError = err;
      _loadingPromise = null;
      throw err;
    }
  })();

  return _loadingPromise;
}

/**
 * Generate via node-llama-cpp.
 */
async function generateNodeLlama(prompt, options) {
  const { LlamaChatSession } = await import('node-llama-cpp');
  const sequence = _context.getSequence();
  const session = new LlamaChatSession({ contextSequence: sequence });
  return session.prompt(prompt, {
    temperature: options.temperature ?? 0.1,
    topP: options.top_p ?? 0.85,
    maxTokens: options.maxTokens ?? 2048,
  });
}

/**
 * Generate via Python HTTP server.
 */
async function generatePython(prompt, options) {
  const messages = options.messages || [{ role: 'user', content: prompt }];

  // Prepend system message if provided
  const allMessages = [];
  if (options.system) {
    allMessages.push({ role: 'system', content: options.system });
  }
  allMessages.push(...messages);

  const res = await httpPost('/v1/chat/completions', {
    messages: allMessages,
    temperature: options.temperature ?? 0.1,
    top_p: options.top_p ?? 0.85,
    max_tokens: options.maxTokens ?? 2048,
  });

  if (res.status === 200 && res.data?.choices?.[0]) {
    return res.data.choices[0].message?.content || '';
  }

  throw new Error(res.data?.error || `Inference server returned ${res.status}`);
}

/**
 * Reset backend state so the next call to ensureLoaded() re-detects.
 * Called automatically when a connection error indicates the backend crashed.
 */
function _resetBackend(reason) {
  localLLMLog(`[LocalLLM] Backend reset: ${reason}`);
  _backend = null;
  _loadingPromise = null;
  _runnerReady = false;
}

/**
 * Check if an error indicates the backend process died or is unreachable.
 */
function _isBackendCrashError(err) {
  if (!err) return false;
  const msg = String(err.message || err).toLowerCase();
  return /econnrefused|econnreset|epipe|socket hang up|channel closed|stalled|spawn|exited/i.test(msg)
    || err.code === 'ECONNREFUSED'
    || err.code === 'ECONNRESET'
    || err.code === 'EPIPE';
}

/**
 * Generate a response using the local model.
 * Auto-recovers from backend crashes by resetting and retrying once.
 */
async function generate(prompt, options = {}) {
  await ensureLoaded();

  const dispatch = async () => {
    if (_backend === 'ollama-runner') {
      return generateRunner(prompt, options);
    }
    if (_backend === 'node-llama-cpp') {
      return generateNodeLlama(prompt, options);
    }
    if (_backend === 'python-server') {
      return generatePython(prompt, options);
    }
    if (_backend === 'ollama') {
      return generateOllama(prompt, options);
    }
    throw new Error('No inference backend loaded');
  };

  try {
    return await dispatch();
  } catch (err) {
    // If the backend crashed (ECONNREFUSED, etc.), reset and retry once
    if (_isBackendCrashError(err)) {
      _resetBackend(`backend crash detected: ${err.message}`);
      try {
        await ensureLoaded();
        return await dispatch();
      } catch (retryErr) {
        // Second failure is final — don't loop
        throw retryErr;
      }
    }
    throw err;
  }
}

/**
 * Dispose resources (for graceful shutdown).
 */
async function dispose() {
  try {
    if (_context) { await _context.dispose(); _context = null; }
    if (_model) { await _model.dispose(); _model = null; }
    if (_llama) { await _llama.dispose(); _llama = null; }
    if (_pythonProcess) {
      terminateChildTree(_pythonProcess);
      _pythonProcess = null;
    }
    if (_runnerProcess) {
      terminateChildTree(_runnerProcess);
      _runnerProcess = null;
      _runnerReady = false;
    }
    _loadingPromise = null;
    _backend = null;
    _pythonLlamaCppAvailable = null;
    _pythonLlamaCppError = '';
    _loopbackListenProbe = { ok: null, at: 0, error: '' };
  } catch (err) {
    console.error('Error disposing local LLM:', err);
  }
}

/**
 * Get current status.
 */
function getStatus() {
  return {
    modelPath: _modelPath,
    available: isModelAvailable(),
    loaded: _backend !== null,
    backend: _backend,
    inferenceServerPort: INFERENCE_SERVER_PORT,
    runnerPort: OLLAMA_RUNNER_PORT,
    runnerReady: _runnerReady,
    lastError: _lastError ? _lastError.message : null,
    loopbackListenAvailable: _loopbackListenProbe.ok,
    loopbackListenError: _loopbackListenProbe.error || null,
  };
}

module.exports = {
  isModelAvailable,
  canListenLoopback,
  tryAdoptHotRunner,
  ensureLoaded,
  generate,
  dispose,
  getStatus,
  isPythonServerRunning,
};
