/**
 * Auth Guard — lightweight shared gate for login-required features.
 */
function getCliAuth() {
  try {
    // Lazy require to avoid boot-time side effects
    // eslint-disable-next-line global-require
    return require('./cliAuthService');
  } catch {
    return null;
  }
}

function hasValidSession() {
  try {
    const cliAuth = getCliAuth();
    if (!cliAuth || typeof cliAuth.checkSession !== 'function') return false;
    const session = cliAuth.checkSession();
    return !!(session && session.loggedIn);
  } catch {
    return false;
  }
}

function requireLogin(featureName = 'this feature') {
  if (hasValidSession()) return { ok: true };
  return {
    ok: false,
    error: `Login required for ${featureName}. Please run login first.`,
    errorType: 'auth',
  };
}

module.exports = {
  hasValidSession,
  requireLogin,
};

