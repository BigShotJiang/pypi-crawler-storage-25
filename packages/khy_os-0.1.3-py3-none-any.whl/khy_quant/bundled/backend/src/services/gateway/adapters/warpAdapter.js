/**
 * Warp Adapter — bridge Warp usage through authenticated clipboard relay.
 *
 * Warp currently does not expose a stable local chat API for this gateway.
 * This adapter routes prompts to the generic clipboard relay using Warp URL.
 */
const clipboardRelayAdapter = require('./clipboardRelayAdapter');

let _available = null;

function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;
  // Clipboard relay availability is the practical requirement.
  _available = clipboardRelayAdapter.detect();
  return _available;
}

async function listModels() {
  return [
    { id: 'warp-web', name: 'Warp Web Relay', isDefault: true, provider: 'warp', description: '' },
  ];
}

async function generate(prompt, options = {}) {
  const result = await clipboardRelayAdapter.generate(prompt, {
    ...options,
    service: 'warp',
  });

  if (!result || !result.success) {
    return {
      success: false,
      content: result?.content || 'Warp relay failed',
      provider: 'Warp',
      adapter: 'warp',
      error: result?.error || result?.content || 'warp relay failed',
      errorType: result?.errorType || 'unknown',
      attempts: result?.attempts || [{ provider: 'Warp', success: false, error: result?.error || 'relay_failed' }],
    };
  }

  return {
    success: true,
    content: result.content,
    provider: 'Warp (relay)',
    adapter: 'warp',
    model: 'warp-web',
    attempts: [{ provider: 'Warp', success: true }],
  };
}

function getStatus() {
  const available = detect();
  return {
    name: 'Warp',
    type: 'warp',
    available,
    detail: available
      ? '可用（通过登录态剪贴板中继）'
      : '不可用 — 需要剪贴板工具 (xclip/pbcopy)',
  };
}

function destroy() {
  _available = null;
}

module.exports = { detect, listModels, generate, getStatus, destroy };

