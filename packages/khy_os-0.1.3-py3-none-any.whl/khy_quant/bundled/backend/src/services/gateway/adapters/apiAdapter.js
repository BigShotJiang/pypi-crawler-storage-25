/**
 * API Adapter — thin wrapper around the existing MultiFreeService
 * to expose a unified interface for the gateway.
 */
const { fetchWithTimeout } = require('../../fetchTimeout');

const DEFAULT_API_TIMEOUT_MS = 120_000; // 2 minutes default
let _service = null;
const SERVICE_PROVIDER_KEYS = new Set([
  'google',
  'groq',
  'openrouter',
  'openai',
  'anthropic',
  'trae',
  'zhipu',
  'xunfei',
  'baidu',
  'alibaba',
  'huggingface',
]);
const DEFAULT_POOL_PROVIDER_ALIASES = Object.freeze({
  openai: 'openai',
  gpt: 'openai',
  anthropic: 'anthropic',
  claude: 'anthropic',
  trae: 'trae',
  deepseek: 'deepseek',
  qwen: 'qwen',
  alibaba: 'qwen',
  dashscope: 'qwen',
  glm: 'glm',
  zhipu: 'glm',
  doubao: 'doubao',
  wenxin: 'wenxin',
  baidu: 'wenxin',
  relay: 'relay',
});
const DEFAULT_POOL_TO_SERVICE_PROVIDER = Object.freeze({
  openai: 'openai',
  anthropic: 'anthropic',
  trae: 'trae',
  deepseek: 'openai',
  qwen: 'alibaba',
  glm: 'zhipu',
  doubao: 'openai',
  wenxin: 'baidu',
  relay: 'openai',
});
const DEFAULT_POOL_DEFAULT_MODEL_MAP = Object.freeze({
  deepseek: 'deepseek-chat',
  doubao: 'doubao-pro-32k',
  qwen: 'qwen-plus',
  glm: 'glm-4-plus',
  wenxin: 'ERNIE-Bot',
  anthropic: 'claude-sonnet-4-6',
  openai: 'gpt-4o-mini',
  trae: 'gpt-4o',
  relay: 'gpt-4o-mini',
});

function parseJsonMap(raw) {
  const text = String(raw || '').trim();
  if (!text) return {};
  try {
    const parsed = JSON.parse(text);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed;
    }
  } catch {
    return {};
  }
  return {};
}

function getPoolAliasMap() {
  const extra = parseJsonMap(process.env.GATEWAY_API_POOL_PROVIDER_ALIAS_MAP || '');
  const merged = { ...DEFAULT_POOL_PROVIDER_ALIASES };
  for (const [k, v] of Object.entries(extra)) {
    const key = String(k || '').trim().toLowerCase();
    const value = String(v || '').trim().toLowerCase();
    if (!key || !value) continue;
    merged[key] = value;
  }
  return merged;
}

function getPoolServiceMap() {
  const extra = parseJsonMap(process.env.GATEWAY_API_POOL_SERVICE_MAP || '');
  const merged = { ...DEFAULT_POOL_TO_SERVICE_PROVIDER };
  for (const [k, v] of Object.entries(extra)) {
    const key = String(k || '').trim().toLowerCase();
    const value = String(v || '').trim().toLowerCase();
    if (!key || !value) continue;
    merged[key] = value;
  }
  return merged;
}

function getPoolDefaultModelMap() {
  const extra = parseJsonMap(process.env.GATEWAY_API_POOL_DEFAULT_MODEL_MAP || '');
  const merged = { ...DEFAULT_POOL_DEFAULT_MODEL_MAP };
  for (const [k, v] of Object.entries(extra)) {
    const key = String(k || '').trim().toLowerCase();
    const value = String(v || '').trim();
    if (!key || !value) continue;
    merged[key] = value;
  }
  return merged;
}

function getService() {
  if (!_service) {
    const MultiFreeService = require('../../multiFreeService');
    _service = new MultiFreeService();
  }
  return _service;
}

/**
 * Check if any API provider is configured and available.
 */
function detect() {
  const svc = getService();
  const providers = svc.getAvailableProviders();
  return providers.length > 0;
}

function parseProviderModel(rawModel) {
  const input = String(rawModel || '').trim();
  if (!input) return { provider: null, model: null };
  const m = input.match(/^([a-z0-9_-]+)[:/](.+)$/i);
  if (m) {
    return {
      provider: m[1].toLowerCase(),
      model: m[2].trim(),
    };
  }
  return { provider: null, model: input };
}

function normalizePoolProvider(raw) {
  const normalized = String(raw || '').trim().toLowerCase();
  if (!normalized) return null;
  const aliasMap = getPoolAliasMap();
  return aliasMap[normalized] || normalized;
}

function normalizeServiceProvider(raw) {
  const normalized = String(raw || '').trim().toLowerCase();
  if (!normalized) return null;
  if (SERVICE_PROVIDER_KEYS.has(normalized)) return normalized;
  const poolProvider = normalizePoolProvider(normalized);
  if (!poolProvider) return null;
  return getPoolServiceMap()[poolProvider] || null;
}

function defaultModelForPoolProvider(poolProvider) {
  const normalized = String(poolProvider || '').toLowerCase();
  const defaults = getPoolDefaultModelMap();
  if (normalized === 'deepseek') return process.env.DEEPSEEK_MODEL || defaults.deepseek;
  if (normalized === 'doubao') return process.env.DOUBAO_MODEL || defaults.doubao;
  if (normalized === 'qwen') return process.env.QWEN_MODEL || defaults.qwen;
  if (normalized === 'glm') return process.env.GLM_MODEL || process.env.ZHIPU_MODEL || defaults.glm;
  if (normalized === 'wenxin') return process.env.WENXIN_MODEL || defaults.wenxin;
  if (normalized === 'anthropic') return process.env.ANTHROPIC_MODEL || defaults.anthropic;
  if (normalized === 'openai') return process.env.OPENAI_MODEL || defaults.openai;
  if (normalized === 'trae') return process.env.TRAE_MODEL || defaults.trae;
  if (normalized === 'relay') return process.env.RELAY_API_MODEL || process.env.OPENAI_MODEL || defaults.relay;
  const mapped = getPoolDefaultModelMap()[normalized];
  if (mapped) return mapped;
  return null;
}

function resolveProviderScope(parsed, options = {}) {
  const hintedPoolProvider = normalizePoolProvider(options.apiPoolProvider);
  const scopedProvider = normalizeServiceProvider(parsed.provider || '');
  const explicitProvider = normalizeServiceProvider(options.provider || '');
  const serviceMap = getPoolServiceMap();
  const fromPoolHint = hintedPoolProvider ? (serviceMap[hintedPoolProvider] || null) : null;

  const serviceProvider = scopedProvider || explicitProvider || fromPoolHint || null;
  const poolProvider = hintedPoolProvider
    || normalizePoolProvider(parsed.provider || '')
    || normalizePoolProvider(options.provider || '')
    || null;

  return {
    serviceProvider,
    poolProvider,
  };
}

function withBaseUrl(rawEndpoint = '') {
  const endpoint = String(rawEndpoint || '').trim();
  if (!endpoint) return '';
  return endpoint.replace(/\/+$/, '');
}

function buildOverriddenService(providerKey, options = {}) {
  if (!providerKey) return null;
  const MultiFreeService = require('../../multiFreeService');
  const svc = new MultiFreeService();
  const current = svc.providers?.[providerKey];
  if (!current) return null;

  const next = {
    ...current,
    enabled: true,
  };
  if (String(options.apiKey || '').trim()) {
    next.apiKey = String(options.apiKey).trim();
  }
  if (String(options.apiEndpoint || '').trim()) {
    next.baseUrl = withBaseUrl(options.apiEndpoint);
  }

  svc.providers[providerKey] = next;
  for (const key of Object.keys(svc.providers || {})) {
    if (key === providerKey) continue;
    svc.providers[key] = {
      ...svc.providers[key],
      enabled: false,
    };
  }
  return svc;
}

/**
 * Generate a response through cloud API providers.
 */
async function generate(prompt, options = {}) {
  const parsed = parseProviderModel(options.model);
  const scope = resolveProviderScope(parsed, options);
  const timeoutMs = options.timeoutMs || DEFAULT_API_TIMEOUT_MS;
  const upstreamSignal = options.abortSignal || options.signal || null;
  const useRequestOverride = !!(
    scope.serviceProvider && (String(options.apiKey || '').trim() || String(options.apiEndpoint || '').trim())
  );
  const svc = useRequestOverride
    ? (buildOverriddenService(scope.serviceProvider, options) || getService())
    : getService();
  const resolvedModel = parsed.model
    || defaultModelForPoolProvider(scope.poolProvider)
    || null;
  const resolvedProvider = scope.serviceProvider || null;

  const result = await fetchWithTimeout(
    (signal) => svc.generateResponse(prompt, {
      ...options,
      provider: resolvedProvider,
      model: resolvedModel,
      signal,
    }),
    {
      timeoutMs,
      signal: upstreamSignal,
      operation: 'apiAdapter.generate',
    }
  );

  return {
    success: result.success,
    content: result.content || '',
    provider: result.provider || '',
    adapter: 'api',
    model: result.model || resolvedModel || null,
    attempts: result.attempts || [],
    tokenUsage: result.tokenUsage || null,
    thinking: result.thinking || null,
  };
}

/**
 * List available API models in provider-scoped form:
 *   openai:gpt-4o-mini
 *   anthropic:claude-sonnet-4-6
 */
async function listModels() {
  const svc = getService();
  const providers = svc.getAvailableProviders();
  const seen = new Set();
  const rows = [];

  for (const p of providers) {
    const models = Array.isArray(p.availableModels) && p.availableModels.length > 0
      ? p.availableModels.map(m => m.id).filter(Boolean)
      : (p.model ? [p.model] : []);

    for (const mid of models) {
      const id = `${p.key}:${mid}`;
      if (seen.has(id)) continue;
      seen.add(id);
      rows.push({
        id,
        name: `${p.name} / ${mid}`,
        provider: 'api',
        description: `Cloud provider: ${p.name}`,
        isDefault: mid === p.model,
      });
    }
  }

  return rows;
}

/**
 * Get adapter status for display.
 */
function getStatus() {
  const svc = getService();
  const status = svc.getStatus();
  return {
    name: 'API 云端服务',
    type: 'api',
    available: status.available,
    detail: status.available
      ? `${status.configuredProviders.length} 个提供商 (${status.provider})`
      : '未配置 API 密钥',
  };
}

/**
 * Reset the cached service instance (call after API keys change).
 */
function resetService() {
  _service = null;
}

function destroy() {
  _service = null;
}

module.exports = { detect, generate, listModels, getStatus, resetService, destroy, parseProviderModel };
