/**
 * Unified image normalization helpers for gateway adapters.
 *
 * Input accepted:
 * - string URL / data URL / raw base64
 * - { base64, mimeType }
 * - { url }
 * - { data } where data can be data URL or base64
 * - OpenAI-like { image_url: { url } }
 * - Anthropic-like { source: { data, media_type } }
 */

const DATA_URL_RE = /^data:([^;,]+)?;base64,([a-z0-9+/=\r\n]+)$/i;
const HTTP_OR_FILE_URL_RE = /^(https?:\/\/|file:\/\/)/i;
const BASE64_RE = /^(?:[a-z0-9+/]{4})*(?:[a-z0-9+/]{2}==|[a-z0-9+/]{3}=)?$/i;

function _cleanBase64(value = '') {
  return String(value || '').replace(/\s+/g, '').trim();
}

function _parseDataUrl(raw = '') {
  const text = String(raw || '').trim();
  const matched = text.match(DATA_URL_RE);
  if (!matched) return null;
  const mimeType = String(matched[1] || 'image/png').trim() || 'image/png';
  const base64 = _cleanBase64(matched[2] || '');
  if (!base64) return null;
  return { mimeType, base64, dataUrl: `data:${mimeType};base64,${base64}` };
}

function _looksLikeBase64(raw = '', minLen = 64) {
  const text = _cleanBase64(raw);
  if (!text || text.length < minLen) return false;
  return BASE64_RE.test(text);
}

function normalizeImageItem(item) {
  if (!item) return null;

  if (typeof item === 'string') {
    const text = item.trim();
    if (!text) return null;

    const dataUrlParsed = _parseDataUrl(text);
    if (dataUrlParsed) return { ...dataUrlParsed };

    if (HTTP_OR_FILE_URL_RE.test(text)) return { url: text };

    if (_looksLikeBase64(text, 64)) {
      const base64 = _cleanBase64(text);
      const mimeType = 'image/png';
      return { base64, mimeType, dataUrl: `data:${mimeType};base64,${base64}` };
    }

    return null;
  }

  if (typeof item !== 'object') return null;

  const imageUrlObj = item.image_url;
  const objectUrl = (
    item.url
    || item.imageUrl
    || item.dataUrl
    || (typeof imageUrlObj === 'string' ? imageUrlObj : '')
    || (imageUrlObj && typeof imageUrlObj.url === 'string' ? imageUrlObj.url : '')
  );
  if (objectUrl) {
    const dataUrlParsed = _parseDataUrl(objectUrl);
    if (dataUrlParsed) return { ...dataUrlParsed };
    if (HTTP_OR_FILE_URL_RE.test(String(objectUrl).trim())) return { url: String(objectUrl).trim() };
  }

  const sourceObj = item.source && typeof item.source === 'object' ? item.source : null;
  let mimeType = (
    item.mimeType
    || item.mediaType
    || item.media_type
    || (sourceObj ? (sourceObj.media_type || sourceObj.mediaType) : '')
    || 'image/png'
  );
  mimeType = String(mimeType || 'image/png').trim() || 'image/png';

  const base64Candidate = (
    item.base64
    || item.data
    || (sourceObj ? sourceObj.data : '')
    || ''
  );
  if (base64Candidate) {
    const parsedFromDataField = _parseDataUrl(base64Candidate);
    if (parsedFromDataField) return { ...parsedFromDataField };
    const base64 = _cleanBase64(base64Candidate);
    if (_looksLikeBase64(base64, 1)) {
      return { base64, mimeType, dataUrl: `data:${mimeType};base64,${base64}` };
    }
  }

  return null;
}

function normalizeImages(images = []) {
  if (!Array.isArray(images) || images.length === 0) return [];
  const out = [];
  for (const item of images) {
    const normalized = normalizeImageItem(item);
    if (normalized) out.push(normalized);
  }
  return out;
}

function toCodexInputImages(images = []) {
  const normalized = normalizeImages(images);
  return normalized
    .map((img) => {
      const imageUrl = img.url || img.dataUrl || '';
      if (!imageUrl) return null;
      return { type: 'input_image', image_url: imageUrl };
    })
    .filter(Boolean);
}

function toAnthropicImageBlocks(images = []) {
  const normalized = normalizeImages(images);
  return normalized
    .map((img) => {
      if (!img.base64) return null;
      const mimeType = img.mimeType || 'image/png';
      return {
        type: 'image',
        source: { type: 'base64', media_type: mimeType, data: img.base64 },
      };
    })
    .filter(Boolean);
}

function toOllamaBase64Images(images = []) {
  const normalized = normalizeImages(images);
  return normalized
    .map(img => img.base64 || '')
    .filter(Boolean);
}

/**
 * Convert normalized images to OpenAI vision content blocks.
 * Works for OpenAI, 智谱 (glm-4v), and any OpenAI-compatible provider.
 * @param {object[]} images - Raw or already normalized
 * @returns {{ type: 'image_url', image_url: { url: string, detail: string } }[]}
 */
function toOpenAIVisionBlocks(images = []) {
  const normalized = normalizeImages(images);
  return normalized
    .map((img) => {
      const url = img.dataUrl || img.url || '';
      if (!url) return null;
      return { type: 'image_url', image_url: { url, detail: 'auto' } };
    })
    .filter(Boolean);
}

/**
 * Convert normalized images to Google Gemini inline data format.
 * @param {object[]} images - Raw or already normalized
 * @returns {{ inlineData: { mimeType: string, data: string } }[]}
 */
function toGoogleInlineData(images = []) {
  const normalized = normalizeImages(images);
  return normalized
    .map((img) => {
      if (!img.base64) return null;
      return { inlineData: { mimeType: img.mimeType || 'image/png', data: img.base64 } };
    })
    .filter(Boolean);
}

function attachImagesToOpenAIMessages(messages = [], images = []) {
  const imageBlocks = toOpenAIVisionBlocks(images);
  if (imageBlocks.length === 0) return messages;
  const next = Array.isArray(messages)
    ? messages.map((msg) => (msg && typeof msg === 'object' ? { ...msg } : msg))
    : [];

  let userIndex = -1;
  for (let i = next.length - 1; i >= 0; i--) {
    if (String(next[i]?.role || '').toLowerCase() === 'user') {
      userIndex = i;
      break;
    }
  }

  if (userIndex < 0) {
    next.push({
      role: 'user',
      content: [{ type: 'text', text: 'Please analyze the attached image(s).' }, ...imageBlocks],
    });
    return next;
  }

  const target = next[userIndex] || { role: 'user', content: '' };
  if (typeof target.content === 'string') {
    target.content = [{ type: 'text', text: target.content || '' }, ...imageBlocks];
  } else if (Array.isArray(target.content)) {
    target.content = [...target.content, ...imageBlocks];
  } else {
    target.content = [{ type: 'text', text: String(target.content || '') }, ...imageBlocks];
  }
  next[userIndex] = target;
  return next;
}

module.exports = {
  normalizeImageItem,
  normalizeImages,
  toCodexInputImages,
  toAnthropicImageBlocks,
  toOllamaBase64Images,
  toOpenAIVisionBlocks,
  toGoogleInlineData,
  attachImagesToOpenAIMessages,
};
