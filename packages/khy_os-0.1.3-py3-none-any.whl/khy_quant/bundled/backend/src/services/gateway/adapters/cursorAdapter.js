/**
 * Cursor Adapter — connect to Cursor IDE's AI models.
 *
 * Reads Cursor's auth token from local storage files and provides
 * access to Cursor's model catalog. Supports both local token detection
 * and account pool fallback.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');
const { sanitizeOutgoingHeaders } = require('./ipAnonymizer');

// Cursor stores auth tokens in different locations per platform
const CURSOR_STORAGE_PATHS = [
  path.join(os.homedir(), '.config', 'Cursor', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'Library', 'Application Support', 'Cursor', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'Cursor', 'User', 'globalStorage', 'storage.json'),
];

const CURSOR_DB_PATHS = [
  path.join(os.homedir(), '.config', 'Cursor', 'User', 'globalStorage', 'state.vscdb'),
  path.join(os.homedir(), 'Library', 'Application Support', 'Cursor', 'User', 'globalStorage', 'state.vscdb'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'Cursor', 'User', 'globalStorage', 'state.vscdb'),
];

const KNOWN_MODELS = [
  { id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', isDefault: false },
  { id: 'gpt-4o', name: 'GPT-4o', isDefault: true },
  { id: 'gpt-4o-mini', name: 'GPT-4o Mini', isDefault: false },
  { id: 'claude-3-opus', name: 'Claude 3 Opus', isDefault: false },
  { id: 'cursor-small', name: 'Cursor Small', isDefault: false },
];

const TIMEOUT_MS = 60_000;
const ACCOUNT_POOL_TYPE = 'cursor';
let _available = null;
let _token = null;

/**
 * Try to read Cursor auth token from local storage.
 */
function readCursorToken() {
  // Try SQLite database first (primary storage since Cursor 0.40+)
  for (const dbPath of CURSOR_DB_PATHS) {
    try {
      if (fs.existsSync(dbPath)) {
        const token = readTokenFromVscdb(dbPath);
        if (token) return { accessToken: token, source: 'state.vscdb' };
      }
    } catch { /* skip */ }
  }

  // Fallback: try storage.json (older versions)
  for (const p of CURSOR_STORAGE_PATHS) {
    try {
      if (fs.existsSync(p)) {
        const data = JSON.parse(fs.readFileSync(p, 'utf8'));
        // Cursor stores token under various keys
        const token = data.cursorAuth?.accessToken
          || data['cursorAuth/accessToken']
          || data.accessToken;
        if (token) return { accessToken: token, source: 'storage.json' };
      }
    } catch { /* skip */ }
  }
  return null;
}

/**
 * Read token from Cursor's SQLite database (state.vscdb).
 * Uses better-sqlite3 if available, falls back to manual parsing.
 */
function readTokenFromVscdb(dbPath) {
  try {
    // Try using better-sqlite3 if available
    const Database = require('better-sqlite3');
    const db = new Database(dbPath, { readonly: true, fileMustExist: true });

    // Query for token keys
    const tokenKeys = [
      'cursorAuth/accessToken',
      'cursorAuth.accessToken',
      'accessToken',
      'cursor.accessToken',
    ];

    for (const key of tokenKeys) {
      try {
        const row = db.prepare('SELECT value FROM ItemTable WHERE key = ?').get(key);
        if (row && row.value) {
          const token = typeof row.value === 'string' ? row.value : row.value.toString('utf8');
          db.close();
          return token;
        }
      } catch { /* try next key */ }
    }

    db.close();
  } catch (sqliteErr) {
    // better-sqlite3 not available or failed, try manual binary parsing
    try {
      const buffer = fs.readFileSync(dbPath);
      const content = buffer.toString('utf8', 0, Math.min(buffer.length, 1024 * 1024)); // First 1MB

      // Look for token patterns in the database
      const tokenPatterns = [
        /cursorAuth[\/\.]accessToken[^\w]+([\w\-\.]+)/,
        /"accessToken":\s*"([\w\-\.]+)"/,
        /accessToken[^\w]+(eyJ[\w\-\.]+)/,  // JWT pattern
      ];

      for (const pattern of tokenPatterns) {
        const match = content.match(pattern);
        if (match && match[1] && match[1].length > 20) {
          return match[1];
        }
      }
    } catch { /* skip */ }
  }

  return null;
}

function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;

  const localToken = readCursorToken();
  if (localToken) {
    _token = localToken;
    persistObservedToken(localToken);
  } else if (!(_token && _token.accessToken && String(_token.source || '').startsWith('pool:'))) {
    _token = null;
  }
  _available = !!_token;
  return _available;
}

function toPoolTokenShape(poolToken = null) {
  if (!poolToken || !poolToken.accessToken) return null;
  return {
    accessToken: String(poolToken.accessToken || '').trim(),
    refreshToken: poolToken.refreshToken ? String(poolToken.refreshToken).trim() : null,
    source: `pool:${poolToken.label || ACCOUNT_POOL_TYPE}`,
    path: poolToken.sourcePath || '',
    expiresAt: poolToken.expiresAt || null,
  };
}

async function getPoolActiveToken() {
  try {
    const pool = require('../../accountPool');
    await pool.init();
    const token = await pool.getActiveToken(ACCOUNT_POOL_TYPE);
    return toPoolTokenShape(token);
  } catch {
    return null;
  }
}

function persistObservedToken(token = null) {
  if (!token || !token.accessToken) return;
  Promise.resolve().then(async () => {
    try {
      const pool = require('../../accountPool');
      await pool.init();
      await pool.saveObservedToken(ACCOUNT_POOL_TYPE, {
        accessToken: token.accessToken,
        refreshToken: token.refreshToken || null,
        sourcePath: token.path || '',
        label: token.source ? `${ACCOUNT_POOL_TYPE}:${token.source}` : ACCOUNT_POOL_TYPE,
        authData: {
          source: token.source || ACCOUNT_POOL_TYPE,
          path: token.path || '',
          expiresAt: token.expiresAt || null,
        },
      }, { activateIfNone: true });
    } catch { /* ignore */ }
  });
}

async function listModels() {
  detect(true);
  const poolToken = await getPoolActiveToken();
  if (poolToken && poolToken.accessToken) {
    _token = poolToken;
    _available = true;
  }
  if (_token && _token.accessToken) {
    persistObservedToken(_token);
  }
  return KNOWN_MODELS.map(m => ({
    ...m,
    provider: 'cursor',
    description: '',
  }));
}

/**
 * Generate a response using Cursor's API.
 * Falls back to OpenAI-compatible endpoint if direct API unavailable.
 */
async function generate(prompt, options = {}) {
  const poolToken = await getPoolActiveToken();
  if (poolToken && poolToken.accessToken) {
    _token = poolToken;
    _available = true;
  }

  if (!detect()) {
    return { success: false, content: '', provider: 'Cursor', adapter: 'cursor', attempts: [] };
  }

  persistObservedToken(_token);

  const model = options.model || 'gpt-4o';
  const onChunk = options.onChunk || (() => {});

  try {
    // Use OpenAI-compatible endpoint
    const content = await cursorChat(prompt, model, onChunk);
    return {
      success: true,
      content,
      provider: `Cursor (${model})`,
      adapter: 'cursor',
      attempts: [{ provider: 'Cursor', success: true }],
    };
  } catch (err) {
    return {
      success: false,
      content: '',
      provider: 'Cursor',
      adapter: 'cursor',
      attempts: [{ provider: 'Cursor', success: false, error: err.message }],
    };
  }
}

/**
 * Call Cursor's API endpoint.
 */
function cursorChat(prompt, model, onChunk) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify({
      model,
      messages: [{ role: 'user', content: prompt }],
      stream: false,
    });

    const options = {
      hostname: 'api2.cursor.sh',
      path: '/v1/chat/completions',
      method: 'POST',
      headers: sanitizeOutgoingHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${_token.accessToken}`,
        'Content-Length': Buffer.byteLength(payload),
      }),
      timeout: TIMEOUT_MS,
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          if (result.choices?.[0]?.message?.content) {
            const text = result.choices[0].message.content;
            onChunk({ type: 'text', text });
            resolve(text);
          } else if (result.error) {
            reject(new Error(result.error.message || 'Cursor API error'));
          } else {
            reject(new Error(`Unexpected response (HTTP ${res.statusCode})`));
          }
        } catch {
          reject(new Error(`Invalid response from Cursor API (HTTP ${res.statusCode})`));
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Cursor API timeout')); });
    req.write(payload);
    req.end();
  });
}

function getStatus() {
  detect();
  return {
    name: 'Cursor IDE',
    type: 'cursor',
    available: _available,
    detail: _available
      ? `Token 有效 (${KNOWN_MODELS.length} 个模型)`
      : '未检测到 Cursor token — 请先登录 Cursor IDE',
  };
}

function destroy() {
  _available = null;
  _token = null;
}

module.exports = { detect, listModels, generate, getStatus, destroy };
