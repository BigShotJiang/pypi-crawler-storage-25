'use strict';

/**
 * toolLoopDetector.js — 5-detector tool loop detection system.
 *
 * Ported from OpenClaw's tool-loop-detection.ts concept with KHY-specific tuning.
 *
 * Detectors:
 *   1. genericRepeat     — Same tool+params hash appears repeatedly
 *   2. unknownToolRepeat — Model repeatedly calls non-existent tools
 *   3. noProgressStreak  — Same tool+params+result hash (output unchanged)
 *   4. pingPong          — Two tools alternate without progress
 *   5. circuitBreaker    — Global call count hard limit
 *
 * Severity levels: 'ok' → 'warning' → 'critical' → 'circuit_breaker'
 */

const { fnv1aHash } = require('./contextWasm');

// ── Defaults ────────────────────────────────────────────────────────

const DEFAULT_CONFIG = {
  historySize: 30,
  warningThreshold: 5,
  criticalThreshold: 8,
  circuitBreakerThreshold: 12,
  unknownToolThreshold: 3,
  noProgressWarning: 3,
  noProgressCritical: 5,
  pingPongThreshold: 4,
};

// ── Stable hash helper ──────────────────────────────────────────────

function stableStringify(obj) {
  if (obj === null || obj === undefined) return '';
  if (typeof obj !== 'object') return String(obj);
  if (Array.isArray(obj)) return '[' + obj.map(stableStringify).join(',') + ']';
  const keys = Object.keys(obj).sort();
  return '{' + keys.map(k => `${k}:${stableStringify(obj[k])}`).join(',') + '}';
}

function hashCall(toolName, params) {
  return fnv1aHash(`${toolName}|${stableStringify(params)}`);
}

function hashResult(result) {
  if (!result) return '0';
  const key = result.success
    ? (result.output || result.content || result.result || 'ok')
    : (result.error || 'fail');
  return fnv1aHash(typeof key === 'string' ? key : stableStringify(key));
}

// ── Detector class ──────────────────────────────────────────────────

class ToolLoopDetector {
  constructor(config = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.history = [];       // ToolCallRecord[]
    this.totalCalls = 0;
    this.unknownToolCount = 0;

    // Track registered tool names for unknown-tool detection
    this._knownTools = new Set();
  }

  /**
   * Register known tool names so we can detect unknown tool calls.
   * @param {Iterable<string>} names
   */
  registerTools(names) {
    for (const n of names) this._knownTools.add(n);
  }

  /**
   * Record a tool call (before execution).
   * @param {string} toolName
   * @param {object} params
   */
  recordCall(toolName, params) {
    const callHash = hashCall(toolName, params);
    const isUnknown = this._knownTools.size > 0 && !this._knownTools.has(toolName);

    this.history.push({
      toolName,
      callHash,
      resultHash: null,
      isUnknown,
      timestamp: Date.now(),
    });

    this.totalCalls++;
    if (isUnknown) this.unknownToolCount++;

    // Keep history bounded
    while (this.history.length > this.config.historySize) {
      const removed = this.history.shift();
      if (removed.isUnknown) this.unknownToolCount--;
    }
  }

  /**
   * Record tool execution outcome (after execution).
   * @param {string} toolName
   * @param {object} params
   * @param {object} result
   */
  recordOutcome(toolName, params, result) {
    const callHash = hashCall(toolName, params);
    const rHash = hashResult(result);

    // Find the most recent matching call record and attach the result hash
    for (let i = this.history.length - 1; i >= 0; i--) {
      if (this.history[i].callHash === callHash && this.history[i].resultHash === null) {
        this.history[i].resultHash = rHash;
        break;
      }
    }
  }

  /**
   * Check all 5 detectors before executing a tool call.
   * @param {string} toolName
   * @param {object} params
   * @returns {{ stuck: boolean, level: string, detector: string, message: string }}
   */
  check(toolName, params) {
    const results = [
      this._checkCircuitBreaker(),
      this._checkGenericRepeat(toolName, params),
      this._checkUnknownTool(toolName),
      this._checkNoProgress(toolName, params),
      this._checkPingPong(toolName),
    ];

    // Return the most severe detection
    const SEVERITY = { ok: 0, warning: 1, critical: 2, circuit_breaker: 3 };
    let worst = { stuck: false, level: 'ok', detector: 'none', message: '' };

    for (const r of results) {
      if (SEVERITY[r.level] > SEVERITY[worst.level]) {
        worst = r;
      }
    }

    return worst;
  }

  /**
   * Reset all state.
   */
  reset() {
    this.history = [];
    this.totalCalls = 0;
    this.unknownToolCount = 0;
  }

  // ── Individual detectors ──────────────────────────────────────────

  _checkCircuitBreaker() {
    if (this.totalCalls >= this.config.circuitBreakerThreshold) {
      return {
        stuck: true,
        level: 'circuit_breaker',
        detector: 'circuitBreaker',
        message: `Circuit breaker tripped: ${this.totalCalls} total tool calls (limit: ${this.config.circuitBreakerThreshold}).`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'circuitBreaker', message: '' };
  }

  _checkGenericRepeat(toolName, params) {
    const callHash = hashCall(toolName, params);
    let count = 0;
    for (const rec of this.history) {
      if (rec.callHash === callHash) count++;
    }

    if (count >= this.config.criticalThreshold) {
      return {
        stuck: true,
        level: 'critical',
        detector: 'genericRepeat',
        message: `Tool "${toolName}" called ${count} times with identical params (critical threshold: ${this.config.criticalThreshold}).`,
      };
    }
    if (count >= this.config.warningThreshold) {
      return {
        stuck: false,
        level: 'warning',
        detector: 'genericRepeat',
        message: `Tool "${toolName}" called ${count} times with identical params. Consider a different approach.`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'genericRepeat', message: '' };
  }

  _checkUnknownTool(toolName) {
    if (this._knownTools.size === 0) {
      return { stuck: false, level: 'ok', detector: 'unknownTool', message: '' };
    }
    if (this._knownTools.has(toolName)) {
      return { stuck: false, level: 'ok', detector: 'unknownTool', message: '' };
    }
    if (this.unknownToolCount >= this.config.unknownToolThreshold) {
      return {
        stuck: true,
        level: 'critical',
        detector: 'unknownTool',
        message: `Model has called ${this.unknownToolCount} unknown tools. Latest: "${toolName}".`,
      };
    }
    return {
      stuck: false,
      level: 'warning',
      detector: 'unknownTool',
      message: `Unknown tool "${toolName}". ${this.unknownToolCount} unknown calls so far.`,
    };
  }

  _checkNoProgress(toolName, params) {
    const callHash = hashCall(toolName, params);

    // Count consecutive entries with same call+result hash at the tail
    let streak = 0;
    let lastResultHash = null;
    for (let i = this.history.length - 1; i >= 0; i--) {
      const rec = this.history[i];
      if (rec.callHash !== callHash) break;
      if (rec.resultHash === null) continue; // not yet resolved

      if (lastResultHash === null) {
        lastResultHash = rec.resultHash;
        streak = 1;
      } else if (rec.resultHash === lastResultHash) {
        streak++;
      } else {
        break;
      }
    }

    if (streak >= this.config.noProgressCritical) {
      return {
        stuck: true,
        level: 'critical',
        detector: 'noProgress',
        message: `No progress: "${toolName}" returned identical results ${streak} times.`,
      };
    }
    if (streak >= this.config.noProgressWarning) {
      return {
        stuck: false,
        level: 'warning',
        detector: 'noProgress',
        message: `"${toolName}" returned the same result ${streak} times. Try a different approach.`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'noProgress', message: '' };
  }

  _checkPingPong(toolName) {
    if (this.history.length < 4) {
      return { stuck: false, level: 'ok', detector: 'pingPong', message: '' };
    }

    // Look for A→B→A→B pattern at the tail
    const tail = this.history.slice(-this.config.pingPongThreshold * 2);
    if (tail.length < 4) {
      return { stuck: false, level: 'ok', detector: 'pingPong', message: '' };
    }

    const toolA = tail[tail.length - 2]?.toolName;
    const toolB = tail[tail.length - 1]?.toolName;

    if (!toolA || !toolB || toolA === toolB) {
      return { stuck: false, level: 'ok', detector: 'pingPong', message: '' };
    }

    let pingPongCount = 0;
    for (let i = tail.length - 1; i >= 1; i -= 2) {
      if (tail[i].toolName === toolB && tail[i - 1].toolName === toolA) {
        pingPongCount++;
      } else {
        break;
      }
    }

    if (pingPongCount >= this.config.pingPongThreshold) {
      return {
        stuck: true,
        level: 'warning',
        detector: 'pingPong',
        message: `Ping-pong detected: "${toolA}" ↔ "${toolB}" alternating ${pingPongCount} times.`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'pingPong', message: '' };
  }
}

module.exports = { ToolLoopDetector, DEFAULT_CONFIG };
