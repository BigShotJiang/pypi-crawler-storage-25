/**
 * QueryEngine — unified dialogue orchestrator (async generator).
 *
 * Centralizes the AI conversation lifecycle that was previously split across
 * ai.js (message management), toolUseLoop.js (tool iteration), and repl.js
 * (command execution). Yields lifecycle events so callers can render them
 * however they choose (CLI, web, SDK).
 *
 * Feature flag: KHY_QUERY_ENGINE=true to enable (default: disabled).
 * V2 enhanced path: KHY_QUERY_ENGINE_V2 !== 'false' when query modules present.
 *
 * Event types yielded by submitMessage():
 *   { type: 'thinking',    data: string }  — AI thinking/status update
 *   { type: 'text',        data: string }  — Streamed text chunk
 *   { type: 'tool_call',   data: { name, params } }
 *   { type: 'tool_result', data: { name, result, elapsed } }
 *   { type: 'cost',        data: { inputTokens, outputTokens, totalTokens } }
 *   { type: 'done',        data: { reply, commands, provider, ... } }
 */

const MAX_HISTORY = 30;
const MAX_TURNS = 10;

// ── Lazy module loaders for V2 (fail gracefully) ─────────────────

let _queryModules = null;

function _loadQueryModules() {
  if (_queryModules !== null) return _queryModules;
  try {
    _queryModules = {
      queryState: require('./query/queryState'),
      queryConfig: require('./query/queryConfig'),
      queryDeps: require('./query/queryDeps'),
      tokenBudget: require('./query/tokenBudget'),
      compactPipeline: require('./query/compactPipeline'),
      stopHooks: require('./query/stopHooks'),
      StreamingToolExecutor: require('./query/streamingToolExecutor').StreamingToolExecutor,
    };
  } catch {
    _queryModules = false; // Mark as unavailable
  }
  return _queryModules;
}

// ── QueryEngine class ─────────────────────────────────────────────

class QueryEngine {
  /**
   * @param {object} [options]
   * @param {number} [options.maxHistory=30] - Max messages to keep in history
   * @param {number} [options.maxTurns=10] - Max tool-use turns per submitMessage
   * @param {object} [options.deps] - Dependency injection (for testing)
   */
  constructor(options = {}) {
    this._messages = [];
    this._maxHistory = options.maxHistory || MAX_HISTORY;
    this._maxTurns = options.maxTurns || MAX_TURNS;
    this._totalTokens = 0;
    this._aborted = false;
    this._depsOverride = options.deps || null;
  }

  /**
   * Submit a user message and yield lifecycle events as an async generator.
   * Dispatches to V2 (state machine) or Legacy based on module availability.
   *
   * @param {string} userMessage
   * @param {object} [options]
   * @param {string} [options.effort] - AI effort level (low/medium/high/max)
   * @param {Array}  [options.images] - Image attachments
   * @yields {{ type: string, data: any }}
   */
  async * submitMessage(userMessage, options = {}) {
    this._aborted = false;

    // Decide: V2 or Legacy
    const modules = _loadQueryModules();
    const v2Disabled = process.env.KHY_QUERY_ENGINE_V2 === 'false';

    if (modules && !v2Disabled) {
      try {
        yield* this._submitMessageV2(userMessage, options, modules);
        return;
      } catch (err) {
        // V2 failed — fall back to Legacy
        yield { type: 'thinking', data: `V2 engine error: ${err.message}. Falling back to legacy.` };
      }
    }

    // Legacy path
    yield* this._submitMessageLegacy(userMessage, options);
  }

  // ── V2: State-machine-driven query loop ─────────────────────────

  /**
   * Enhanced query loop with state machine, token budget, compact pipeline,
   * streaming tool execution, and stop hooks.
   *
   * @param {string} userMessage
   * @param {object} options
   * @param {object} modules - Loaded query modules
   * @yields {{ type: string, data: any }}
   * @private
   */
  async * _submitMessageV2(userMessage, options, modules) {
    const { queryState, queryConfig, queryDeps, tokenBudget, compactPipeline, stopHooks, StreamingToolExecutor } = modules;
    const { TRANSITIONS, createInitialState, nextState, shouldContinue: stateShouldContinue } = queryState;

    // ── 1. Frozen config snapshot ──────────────────────────────────
    const config = queryConfig.createConfig({
      effort: options.effort,
      maxTurns: this._maxTurns,
      images: options.images,
      isSubAgent: options._isSubAgent || false,
    });

    // ── 2. Dependency injection ────────────────────────────────────
    const deps = this._depsOverride
      ? queryDeps.createDeps(this._depsOverride)
      : queryDeps.productionDeps();

    // ── 3. Token budget ────────────────────────────────────────────
    const budget = tokenBudget.createBudget(config);

    // ── 4. Stop hooks ──────────────────────────────────────────────
    const hooks = stopHooks.loadHooks();

    // ── 5. Input preprocessing ─────────────────────────────────────
    let processedMessage = userMessage;
    try {
      const { preprocess } = require('./inputPreprocessor');
      const result = preprocess(userMessage);
      processedMessage = result.processed;
    } catch { /* best effort */ }

    yield { type: 'thinking', data: 'Preprocessing input...' };

    // ── 6. Security check ──────────────────────────────────────────
    try {
      const { analyzeInput } = require('./securityGuardService');
      const check = analyzeInput(processedMessage);
      if (!check.safe) {
        yield { type: 'done', data: { reply: check.refusal, commands: [], provider: 'security', blocked: true } };
        return;
      }
    } catch { /* security failure should not block */ }

    // ── 7. Initialize state ────────────────────────────────────────
    let state = createInitialState(config);

    // Add user message to state and engine history
    state.messages = [...this._messages, { role: 'user', content: processedMessage }];
    this._messages.push({ role: 'user', content: processedMessage });
    if (this._messages.length > this._maxHistory) {
      this._messages = this._messages.slice(-this._maxHistory);
    }

    let finalResult = null;

    // ── 8. State machine loop ──────────────────────────────────────
    while (stateShouldContinue(state)) {
      // (a) Check abort
      if (this._aborted) {
        state = nextState(state, TRANSITIONS.USER_ABORT);
        yield { type: 'done', data: { reply: '(Aborted by user)', commands: [], aborted: true } };
        return;
      }

      // (b) Check max turns
      if (state.turnCount >= config.maxTurns) {
        state = nextState(state, TRANSITIONS.MAX_TURNS_REACHED);
        continue;
      }

      // (c) Run compact pipeline if needed
      if (state.turnCount > 0) {
        try {
          const compactResult = await compactPipeline.runCompactPipeline(
            state.messages, deps, config,
            { forceAutocompact: state.transition === TRANSITIONS.COMPACT_RETRY }
          );
          state = nextState(state, state.transition, { messages: compactResult.messages });
          if (compactResult.stagesRun.length > 0) {
            yield { type: 'thinking', data: `Compacted: ${compactResult.stagesRun.join(', ')} (freed ~${compactResult.totalFreedChars} chars)` };
          }
        } catch { /* compact failure is non-fatal */ }
      }

      // (d) Call model
      yield { type: 'thinking', data: state.turnCount === 0 ? 'Requesting AI...' : `Tool turn ${state.turnCount + 1}...` };

      let chatResult;
      const chunks = [];
      try {
        chatResult = await deps.callModel(processedMessage, {
          effort: config.effort,
          images: state.turnCount === 0 ? config.images : undefined,
          _isFollowUp: state.turnCount > 0,
          onChunk: (chunk) => { chunks.push(chunk); },
        });
      } catch (err) {
        const errMsg = err.message || String(err);

        // Token overflow (413) → try compact retry
        if ((err.status === 413 || errMsg.includes('413') || errMsg.includes('too many tokens'))
            && !state.hasAttemptedCompact) {
          state = nextState(state, TRANSITIONS.COMPACT_RETRY, {
            hasAttemptedCompact: true,
          });
          yield { type: 'thinking', data: 'Token overflow — attempting compact retry...' };
          continue;
        }

        // Unrecoverable model error
        yield { type: 'done', data: { reply: `AI error: ${errMsg}`, commands: [], error: true } };
        return;
      }

      // Yield collected chunks
      for (const chunk of chunks) {
        if (chunk.type === 'thinking') {
          yield { type: 'thinking', data: chunk.text || chunk.content };
        } else if (chunk.type === 'text') {
          yield { type: 'text', data: chunk.text || chunk.content };
        }
      }

      // (e) Record token usage
      if (chatResult.tokenUsage) {
        tokenBudget.recordTurn(budget, chatResult.tokenUsage);
        this._totalTokens += chatResult.tokenUsage.totalTokens || 0;
        yield { type: 'cost', data: { ...chatResult.tokenUsage, budget: tokenBudget.getSummary(budget) } };
      }

      // (f) Parse tool calls
      let toolCalls = [];
      try {
        toolCalls = deps.parseToolCalls(chatResult.reply);
      } catch { /* no tool calls */ }

      // No tool calls → check for output truncation
      if (toolCalls.length === 0) {
        // Max output recovery: detect truncated responses
        if (chatResult.stopReason === 'max_tokens' &&
            state.maxOutputRecoveryCount < 3) {
          state = nextState(state, TRANSITIONS.MAX_OUTPUT_RECOVERY, {
            turnCount: state.turnCount + 1,
            maxOutputRecoveryCount: state.maxOutputRecoveryCount + 1,
            lastOutputTokens: chatResult.tokenUsage?.outputTokens || 0,
          });
          // Inject continuation prompt
          processedMessage = '[System: Your previous response was truncated. Please continue from where you left off.]';
          state.messages.push(
            { role: 'assistant', content: chatResult.reply },
            { role: 'user', content: processedMessage }
          );
          yield { type: 'thinking', data: `Output truncated — continuation ${state.maxOutputRecoveryCount}/3...` };
          continue;
        }

        finalResult = chatResult;
        state = nextState(state, TRANSITIONS.DONE);
        continue;
      }

      // (g) Execute tools via streaming executor
      const executor = new StreamingToolExecutor({
        executeTools: deps.executeTools,
        isConcurrencySafe: deps.isConcurrencySafe,
        uuid: deps.uuid,
      });

      for (const call of toolCalls) {
        yield { type: 'tool_call', data: { name: call.name, params: call.params } };
        executor.addTool(call);
      }

      // Await all results
      const toolResults = await executor.awaitAll();
      let denied = false;

      for (const tr of toolResults) {
        yield {
          type: 'tool_result',
          data: {
            name: tr.name,
            params: tr.params || {},
            result: tr.output,
            elapsed: tr.elapsed,
            status: tr.status,
          },
        };
        if (tr.status === 'denied') { denied = true; }
      }

      if (denied) {
        finalResult = { ...chatResult, reply: chatResult.reply + '\n\n(Tool execution denied by user)' };
        state = nextState(state, TRANSITIONS.DONE);
        continue;
      }

      // Build follow-up message
      const parts = ['[Tool execution results]\n'];
      for (const tr of toolResults) {
        parts.push(`Tool: ${tr.name}`);
        if (tr.status === 'success') {
          const output = tr.output;
          if (output != null) {
            const text = typeof output === 'string' ? output :
              (typeof output === 'object' && output.output) ? String(output.output) :
              JSON.stringify(output);
            parts.push(`Result: ${text.length > 3000 ? text.slice(0, 3000) + '...' : text}`);
          } else {
            parts.push('Result: Success');
          }
        } else {
          parts.push(`Error: ${tr.output || 'Unknown error'}`);
        }
        parts.push('');
      }
      processedMessage = parts.join('\n');

      // Add to state messages
      state.messages.push(
        { role: 'assistant', content: chatResult.reply },
        { role: 'user', content: processedMessage }
      );

      // (h) Evaluate stop hooks
      if (hooks.length > 0) {
        const hookResult = stopHooks.evaluateHooks(hooks, {
          turnCount: state.turnCount,
          trigger: 'after_turn',
          transition: state.transition,
        });

        if (hookResult.preventContinuation) {
          finalResult = chatResult;
          state = nextState(state, TRANSITIONS.DONE);
          continue;
        }

        // Inject blocking error messages
        if (hookResult.blockingErrors.length > 0) {
          for (const errMsg of hookResult.blockingErrors) {
            state.messages.push(errMsg);
          }
          state = nextState(state, TRANSITIONS.STOP_HOOK_BLOCKING, {
            turnCount: state.turnCount + 1,
          });
          processedMessage = hookResult.blockingErrors.map((m) => m.content).join('\n');
          continue;
        }
      }

      // (i) Token budget continuation decision
      const budgetDecision = tokenBudget.shouldContinue(budget, config);
      if (budgetDecision.action === 'stop') {
        finalResult = chatResult;
        state = nextState(state, TRANSITIONS.DONE);
        continue;
      }

      // (j) Next turn
      state = nextState(state, TRANSITIONS.NEXT_TURN, {
        turnCount: state.turnCount + 1,
      });
    }

    // ── 9. Finalize ────────────────────────────────────────────────
    if (!finalResult) {
      finalResult = { reply: '(Max tool-use turns reached)', commands: [], maxTurnsReached: true };
    }

    // Add assistant reply to history
    if (finalResult.reply) {
      this._messages.push({ role: 'assistant', content: finalResult.reply });
      if (this._messages.length > this._maxHistory) {
        this._messages = this._messages.slice(-this._maxHistory);
      }
    }

    // Post-processing hooks (non-critical)
    this._postProcess(userMessage, finalResult.reply);

    yield { type: 'done', data: { ...finalResult, budget: tokenBudget.getSummary(budget) } };
  }

  // ── Legacy: Original query loop (zero changes) ──────────────────

  /**
   * Original submitMessage implementation — preserved as fallback.
   *
   * @param {string} userMessage
   * @param {object} [options]
   * @yields {{ type: string, data: any }}
   * @private
   */
  async * _submitMessageLegacy(userMessage, options = {}) {
    // ── 1. Input preprocessing ────────────────────────────────────
    let processedMessage = userMessage;
    try {
      const { preprocess } = require('./inputPreprocessor');
      const result = preprocess(userMessage);
      processedMessage = result.processed;
    } catch { /* best effort */ }

    yield { type: 'thinking', data: 'Preprocessing input...' };

    // ── 2. Security check ─────────────────────────────────────────
    try {
      const { analyzeInput } = require('./securityGuardService');
      const check = analyzeInput(processedMessage);
      if (!check.safe) {
        yield { type: 'done', data: { reply: check.refusal, commands: [], provider: 'security', blocked: true } };
        return;
      }
    } catch { /* security failure should not block */ }

    // ── 3. Build system prompt ────────────────────────────────────
    const systemPrompt = this._buildSystemPrompt(processedMessage);

    // ── 4. Add to history ─────────────────────────────────────────
    this._messages.push({ role: 'user', content: processedMessage });
    if (this._messages.length > this._maxHistory) {
      this._messages = this._messages.slice(-this._maxHistory);
    }

    // ── 5. Tool-use loop ──────────────────────────────────────────
    let currentInput = processedMessage;
    let finalResult = null;

    for (let turn = 0; turn < this._maxTurns; turn++) {
      if (this._aborted) {
        yield { type: 'done', data: { reply: '(Aborted by user)', commands: [], aborted: true } };
        return;
      }

      yield { type: 'thinking', data: turn === 0 ? 'Requesting AI...' : `Tool turn ${turn + 1}...` };

      // Call AI via ai.js chat()
      const chunks = [];
      const ai = require('../cli/ai');
      const chatResult = await ai.chat(currentInput, {
        effort: options.effort || ai.getEffort(),
        images: turn === 0 ? options.images : undefined,
        _isFollowUp: turn > 0,
        onChunk: (chunk) => {
          chunks.push(chunk);
        },
      });

      // Yield collected chunks
      for (const chunk of chunks) {
        if (chunk.type === 'thinking') {
          yield { type: 'thinking', data: chunk.text || chunk.content };
        } else if (chunk.type === 'text') {
          yield { type: 'text', data: chunk.text || chunk.content };
        }
      }

      // Yield cost info if available
      if (chatResult.tokenUsage) {
        this._totalTokens += chatResult.tokenUsage.totalTokens || 0;
        yield { type: 'cost', data: chatResult.tokenUsage };
      }

      // Parse tool calls from reply
      let toolCalls = [];
      try {
        const toolUseLoop = require('./toolUseLoop');
        toolCalls = toolUseLoop._parseToolCalls(chatResult.reply);
      } catch { /* no tool calls */ }

      // No tool calls → done
      if (toolCalls.length === 0) {
        finalResult = chatResult;
        break;
      }

      // Execute tool calls (using registry for parallel awareness)
      const toolResults = [];
      let denied = false;

      // Classify by concurrency safety
      const parallelCalls = [];
      const sequentialCalls = [];
      let toolRegistry;
      try { toolRegistry = require('../tools'); } catch { toolRegistry = null; }

      for (const call of toolCalls) {
        let isSafe = false;
        if (toolRegistry) {
          const regTool = toolRegistry.get(call.name);
          if (regTool && typeof regTool.isConcurrencySafe === 'function') {
            isSafe = regTool.isConcurrencySafe(call.params);
          }
        }
        (isSafe ? parallelCalls : sequentialCalls).push(call);
      }

      // Execute parallel calls
      if (parallelCalls.length >= 2 && toolRegistry) {
        for (const call of parallelCalls) {
          yield { type: 'tool_call', data: { name: call.name, params: call.params } };
        }
        const results = await Promise.allSettled(
          parallelCalls.map(async (call) => {
            const start = Date.now();
            const result = await toolRegistry.execute(call.name, call.params);
            return { name: call.name, result, elapsed: Date.now() - start };
          })
        );
        for (const s of results) {
          const r = s.status === 'fulfilled'
            ? s.value
            : { name: 'unknown', result: { success: false, error: s.reason?.message }, elapsed: 0 };
          toolResults.push(r);
          yield { type: 'tool_result', data: r };
          if (r.result?.denied) { denied = true; break; }
        }
      } else {
        sequentialCalls.unshift(...parallelCalls);
      }

      if (denied) break;

      // Execute sequential calls
      for (const call of sequentialCalls) {
        if (this._aborted) break;
        yield { type: 'tool_call', data: { name: call.name, params: call.params } };
        const start = Date.now();
        let result;
        try {
          const executor = toolRegistry || { execute: async (n, p) => ({ success: false, error: 'No tool registry' }) };
          result = await executor.execute(call.name, call.params);
        } catch (err) {
          result = { success: false, error: err.message };
        }
        const elapsed = Date.now() - start;
        toolResults.push({ name: call.name, result, elapsed });
        yield { type: 'tool_result', data: { name: call.name, result, elapsed } };
        if (result?.denied) { denied = true; break; }
      }

      if (denied) {
        finalResult = { ...chatResult, reply: chatResult.reply + '\n\n(Tool execution denied by user)' };
        break;
      }

      // Build follow-up message with tool results
      const parts = ['[Tool execution results]\n'];
      for (const tr of toolResults) {
        parts.push(`Tool: ${tr.name}`);
        if (tr.result?.success) {
          const output = tr.result.output || tr.result.content || tr.result.result;
          if (output) {
            const text = typeof output === 'string' ? output : JSON.stringify(output);
            parts.push(`Result: ${text.length > 3000 ? text.slice(0, 3000) + '...' : text}`);
          } else {
            parts.push('Result: Success');
          }
        } else {
          parts.push(`Error: ${tr.result?.error || 'Unknown error'}`);
        }
        parts.push('');
      }
      currentInput = parts.join('\n');
    }

    // ── 6. Post-processing ────────────────────────────────────────
    if (!finalResult) {
      finalResult = { reply: '(Max tool-use turns reached)', commands: [], maxTurnsReached: true };
    }

    // Add assistant reply to history
    if (finalResult.reply) {
      this._messages.push({ role: 'assistant', content: finalResult.reply });
      if (this._messages.length > this._maxHistory) {
        this._messages = this._messages.slice(-this._maxHistory);
      }
    }

    // Post-processing hooks (non-critical)
    this._postProcess(userMessage, finalResult.reply);

    yield { type: 'done', data: finalResult };
  }

  // ── Shared helpers ──────────────────────────────────────────────

  /**
   * Run non-critical post-processing hooks.
   * @param {string} userMessage
   * @param {string} reply
   * @private
   */
  _postProcess(userMessage, reply) {
    try {
      const { extractKnowledge } = require('./knowledgeTeachingService');
      extractKnowledge(userMessage, reply);
    } catch {}

    try {
      const { recordInteraction: recordHabit } = require('./usageHabitService');
      recordHabit(userMessage);
    } catch {}
  }

  /**
   * Build the full system prompt with all enrichment layers.
   * @param {string} userMessage
   * @returns {string}
   * @private
   */
  _buildSystemPrompt(userMessage) {
    // The system prompt is already constructed inside ai.chat().
    // QueryEngine delegates to ai.chat() which handles prompt construction.
    // This method exists as a hook for future decoupling.
    return '';
  }

  /**
   * Save conversation to disk.
   * @returns {string|null} File path or null
   */
  saveConversation() {
    try {
      const ai = require('../cli/ai');
      return ai.saveConversation();
    } catch { return null; }
  }

  /**
   * Load a conversation from file.
   * @param {string} file
   */
  loadConversation(file) {
    try {
      const ai = require('../cli/ai');
      ai.loadLastConversation();
    } catch {}
  }

  /**
   * Clear conversation history (both engine and ai.js).
   */
  clearHistory() {
    this._messages = [];
    this._totalTokens = 0;
    try {
      const ai = require('../cli/ai');
      ai.clearHistory();
    } catch {}
  }

  /**
   * Abort the current submitMessage loop.
   */
  abort() {
    this._aborted = true;
  }

  /**
   * Get accumulated token usage for this engine instance.
   * @returns {{ totalTokens: number }}
   */
  getTokenUsage() {
    return { totalTokens: this._totalTokens };
  }
}

// ── Feature flag ──────────────────────────────────────────────────

/**
 * Check if QueryEngine is enabled via KHY_QUERY_ENGINE env var.
 * @returns {boolean}
 */
function isEnabled() {
  return process.env.KHY_QUERY_ENGINE === 'true';
}

/**
 * Check if V2 enhanced path is available and enabled.
 * @returns {boolean}
 */
function isV2Available() {
  if (process.env.KHY_QUERY_ENGINE_V2 === 'false') return false;
  const modules = _loadQueryModules();
  return !!modules;
}

// ── Exports ───────────────────────────────────────────────────────

module.exports = { QueryEngine, isEnabled, isV2Available };
