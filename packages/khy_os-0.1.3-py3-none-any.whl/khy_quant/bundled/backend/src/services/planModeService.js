/**
 * Plan Mode Service — structured plan → approve → execute workflow.
 *
 * When a complex task is detected, AI generates a numbered execution plan.
 * The user can approve, modify, or reject before step-by-step execution.
 *
 * State machine: idle → generating → reviewing → executing → complete
 */
const readline = require('readline');
const fs = require('fs');
const path = require('path');

// ── State ─────────────────────────────────────────────────────────────
let _state = 'idle'; // idle | generating | reviewing | executing | complete
let _currentPlan = null;

function isStepExecutionFailure(result) {
  if (!result || typeof result !== 'object') return true;
  if (result.errorType || result.blocked) return true;

  const reply = String(result.reply || '').trim();
  if (!reply) return true;

  if (/^\s*(AI 请求失败|AI 未返回有效回复|error:|错误:)/i.test(reply)) return true;
  if (/(permission denied|operation not permitted|access denied|forbidden|not allowed)/i.test(reply)) return true;
  if (/(权限被拒绝|未授权|任务被权限阻止|无法完成|无法运行|未创建)/.test(reply)) return true;

  return false;
}

function runWithTimeout(promise, timeoutMs, errorMessage) {
  const ms = Math.max(1000, Number(timeoutMs) || 0);
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      const t = setTimeout(() => reject(new Error(errorMessage || `Timeout after ${ms}ms`)), ms);
      if (t.unref) t.unref();
    }),
  ]);
}

function extractAbsolutePaths(text) {
  if (!text) return [];
  const paths = new Set();
  const pattern = /(?:^|[\s`'"])(\/[^\s`'"]+)/g;
  let m;
  while ((m = pattern.exec(String(text)))) {
    const cleaned = m[1].replace(/[),.;:]+$/g, '').trim();
    if (cleaned) paths.add(cleaned);
  }
  return Array.from(paths);
}

function inferPlanBaseDirs(plan) {
  const combined = [
    ...(plan?.dataNeeds || []),
    ...(plan?.expectedOutputs || []),
    ...(plan?.risks || []),
    ...(plan?.steps || []).map(s => s.description || ''),
  ].join('\n');
  const absPaths = extractAbsolutePaths(combined);
  const dirs = [];
  for (const p of absPaths) {
    const last = path.basename(p);
    if (/\.[a-z0-9]{1,8}$/i.test(last)) {
      dirs.push(path.dirname(p));
    } else {
      dirs.push(p);
    }
  }
  const cwd = process.env.KHYQUANT_CWD || process.cwd();
  if (cwd) dirs.push(path.resolve(cwd));
  return Array.from(new Set(dirs.filter(Boolean)));
}

function inferStepFileTargets(stepDescription, plan) {
  const desc = String(stepDescription || '');
  const namePattern = /(?:^|[\s`'"])([A-Za-z0-9_.\/-]+\.[A-Za-z0-9]{1,8})(?=$|[\s`'".,;:])/g;
  const names = new Set();
  let m;
  while ((m = namePattern.exec(desc))) {
    names.add(m[1]);
  }
  const baseDirs = inferPlanBaseDirs(plan);
  const targets = new Set();
  for (const n of names) {
    if (n.startsWith('/')) {
      targets.add(path.resolve(n));
      continue;
    }
    for (const dir of baseDirs) {
      targets.add(path.resolve(dir, n));
    }
  }

  // If assistant reply already contains absolute artifact paths, include them.
  for (const p of extractAbsolutePaths(desc)) {
    const base = path.basename(p);
    if (/\.[a-z0-9]{1,8}$/i.test(base)) targets.add(path.resolve(p));
  }

  return Array.from(targets);
}

function hasExecutionIntent(stepDescription) {
  return /(创建|新建|写入|编写|生成|修改|编辑|运行|执行|测试|校验|验证|create|write|add|update|edit|run|execute|test|verify)/i
    .test(String(stepDescription || ''));
}

function hasWriteIntent(stepDescription) {
  return /(创建|新建|写入|编写|生成|修改|编辑|create|write|add|update|edit|文件|目录)/i
    .test(String(stepDescription || ''));
}

function hasRunIntent(stepDescription) {
  return /(运行|执行|测试|校验|验证|run|execute|test|verify|命令|command)/i
    .test(String(stepDescription || ''));
}

function hasRuntimeEvidence(reply) {
  const text = String(reply || '');
  if (!text.trim()) return false;
  if (/\b(pass|passed|fail|failed|exit code|stdout|stderr)\b/i.test(text)) return true;
  if (/(测试结果|通过|失败|退出码|命令输出|执行结果)/.test(text)) return true;
  if (/`(?:bash|node|npm|pnpm|yarn)\s+/i.test(text)) return true;
  return false;
}

function shortenReason(reason, maxLen = 220) {
  const text = String(reason || '').replace(/\s+/g, ' ').trim();
  if (!text) return 'unknown reason';
  return text.length > maxLen ? `${text.slice(0, maxLen)}...` : text;
}

function validateStepResult(step, plan, result, stepStartedAtMs) {
  if (isStepExecutionFailure(result)) {
    return { ok: false, reason: 'AI response indicates failure or no valid output' };
  }

  const desc = String(step?.description || '');
  if (!hasExecutionIntent(desc)) {
    return { ok: true, reason: '' };
  }

  const reply = String(result?.reply || '');
  const toolCalls = Number(result?.toolSummary?.totalCalls || 0);
  const fileTargets = inferStepFileTargets(desc, plan);
  const missingFiles = [];
  const staleFiles = [];

  for (const filePath of fileTargets) {
    if (!fs.existsSync(filePath)) {
      missingFiles.push(filePath);
      continue;
    }
    if (hasWriteIntent(desc)) {
      try {
        const st = fs.statSync(filePath);
        if (st.mtimeMs + 1500 < stepStartedAtMs) {
          staleFiles.push(filePath);
        }
      } catch {
        staleFiles.push(filePath);
      }
    }
  }

  if (missingFiles.length > 0) {
    return { ok: false, reason: `missing expected files: ${missingFiles.join(', ')}` };
  }

  if (hasWriteIntent(desc) && fileTargets.length > 0 && staleFiles.length === fileTargets.length && toolCalls <= 0) {
    return { ok: false, reason: 'no observable file updates for a write/create step' };
  }

  if (hasRunIntent(desc) && toolCalls <= 0 && !hasRuntimeEvidence(reply)) {
    return { ok: false, reason: 'run/test step has no executable evidence in output' };
  }

  // For mutation steps, require at least one concrete signal.
  if (hasWriteIntent(desc) && fileTargets.length === 0 && toolCalls <= 0 && !hasRuntimeEvidence(reply)) {
    return { ok: false, reason: 'write step has no tool evidence and no detectable artifacts' };
  }

  return { ok: true, reason: '' };
}

// ── Plan Prompt Template ──────────────────────────────────────────────
const PLAN_PROMPT = `[大型任务 — 请先制定详细执行计划]

用户请求: {REQUEST}

请输出一个结构化的执行计划，格式如下:

## 执行计划
1. [步骤描述]
2. [步骤描述]
...

## 需要的数据
- [数据项]

## 预计输出
- [输出描述]

## 风险与注意事项
- [风险项]

注意: 每个步骤应独立可执行，步骤之间有明确的输入/输出关系。`;

/**
 * Enter plan mode: generate a plan from AI.
 * @param {string} userRequest - the user's original request
 * @param {object} aiModule - the ai module (lazy-loaded)
 * @param {object} [opts] - { onChunk, effort }
 * @returns {{ plan: object, rawResponse: string }}
 */
async function enterPlanMode(userRequest, aiModule, opts = {}) {
  _state = 'generating';

  const prompt = PLAN_PROMPT.replace('{REQUEST}', userRequest);
  let result;
  try {
    const defaultPlanTimeout = (process.env.GATEWAY_PREFERRED_ADAPTER === 'localllm'
      || process.env.GATEWAY_PREFERRED_ADAPTER === 'ollama'
      || !process.env.GATEWAY_PREFERRED_ADAPTER) ? '120000' : '45000';
    const timeoutMs = Math.max(10000, parseInt(process.env.KHY_PLAN_MODE_TIMEOUT_MS || defaultPlanTimeout, 10));
    result = await runWithTimeout(
      aiModule.chat(prompt, {
        ...opts,
        _isFollowUp: false,
      }),
      timeoutMs,
      `Plan generation timeout after ${Math.round(timeoutMs / 1000)}s`
    );
  } catch (err) {
    _state = 'idle';
    return {
      plan: null,
      rawResponse: `计划模式生成失败: ${err && err.message ? err.message : 'unknown error'}`,
      provider: null,
      elapsed: 0,
      errorType: 'timeout',
    };
  }

  if (!result.reply) {
    _state = 'idle';
    return { plan: null, rawResponse: '' };
  }

  if (result.errorType) {
    _state = 'idle';
    return {
      plan: null,
      rawResponse: result.reply,
      provider: result.provider || null,
      elapsed: result.elapsed || 0,
      errorType: result.errorType,
    };
  }

  const plan = parsePlanFromResponse(result.reply);
  _currentPlan = plan;
  _state = 'reviewing';

  return { plan, rawResponse: result.reply, provider: result.provider, elapsed: result.elapsed };
}

/**
 * Parse a numbered plan from AI response text.
 * Extracts steps from patterns like "1. xxx\n2. xxx\n..."
 *
 * @param {string} text - AI response containing a plan
 * @returns {{ steps: Array<{id: number, description: string, status: string}>, dataNeeds: string[], expectedOutputs: string[], risks: string[] }}
 */
function parsePlanFromResponse(text) {
  const plan = {
    steps: [],
    dataNeeds: [],
    expectedOutputs: [],
    risks: [],
  };

  // Extract numbered steps
  const stepPattern = /(?:^|\n)\s*(\d+)[.、）)]\s*(.+)/g;
  const matches = [...text.matchAll(stepPattern)];
  for (const m of matches) {
    plan.steps.push({
      id: parseInt(m[1], 10),
      description: m[2].trim().slice(0, 100),
      status: 'pending', // pending | in_progress | completed | skipped | error
    });
  }

  // Extract data needs section
  const dataSection = text.match(/需要的数据[\s\S]*?(?=##|$)/);
  if (dataSection) {
    const dataItems = [...dataSection[0].matchAll(/[-•]\s*(.+)/g)];
    plan.dataNeeds = dataItems.map(m => m[1].trim());
  }

  // Extract expected outputs section
  const outputSection = text.match(/预计输出[\s\S]*?(?=##|$)/);
  if (outputSection) {
    const outputItems = [...outputSection[0].matchAll(/[-•]\s*(.+)/g)];
    plan.expectedOutputs = outputItems.map(m => m[1].trim());
  }

  // Extract risks section
  const riskSection = text.match(/风险[\s\S]*?(?=##|$)/);
  if (riskSection) {
    const riskItems = [...riskSection[0].matchAll(/[-•]\s*(.+)/g)];
    plan.risks = riskItems.map(m => m[1].trim());
  }

  return plan;
}

/**
 * Present plan for user approval via interactive prompt.
 * @param {object} plan - parsed plan object
 * @param {object} renderer - aiRenderer module
 * @param {readline.Interface} rl - existing readline interface
 * @returns {Promise<{approved: boolean, modifications: string[]}>}
 */
async function presentForApproval(plan, renderer, rl) {
  // Render plan as task checklist
  const planTracker = new renderer.TaskPlanTracker();
  for (const step of plan.steps) {
    planTracker.addTask(step.description);
  }
  planTracker.render();

  // Show data needs and risks if present
  let _chalk;
  const c = () => (_chalk ??= (require('chalk').default || require('chalk')));

  if (plan.dataNeeds.length > 0) {
    console.log('');
    console.log(c().dim('  需要的数据:'));
    plan.dataNeeds.forEach(d => console.log(c().dim(`    • ${d}`)));
  }

  if (plan.risks.length > 0) {
    console.log('');
    console.log(c().yellow('  风险提示:'));
    plan.risks.forEach(r => console.log(c().yellow(`    ⚠ ${r}`)));
  }

  console.log('');
  console.log(c().cyan('  操作: ') +
    c().white('Enter') + c().dim(' 确认执行 · ') +
    c().white('skip N') + c().dim(' 跳过步骤 · ') +
    c().white('edit N 描述') + c().dim(' 修改步骤 · ') +
    c().white('add after N 描述') + c().dim(' 新增步骤 · ') +
    c().white('n') + c().dim(' 取消')
  );
  console.log(c().dim('  输入 ? 查看示例；支持英文/中文命令，例如：跳过 2, 修改 1 更新描述'));

  return new Promise((resolve) => {
    const autoApproveMs = Math.max(0, parseInt(process.env.KHY_PLAN_AUTO_APPROVE_MS || '20000', 10));
    let resolved = false;
    let autoTimer = null;

    const done = (payload) => {
      if (resolved) return;
      resolved = true;
      if (autoTimer) clearTimeout(autoTimer);
      resolve(payload);
    };

    if (autoApproveMs > 0) {
      const autoApproveSec = autoApproveMs >= 1000
        ? `${Math.round(autoApproveMs / 1000)}`
        : `${(autoApproveMs / 1000).toFixed(1)}`;
      console.log(c().dim(`  ${autoApproveSec} 秒无输入将自动确认执行`));
      autoTimer = setTimeout(() => {
        console.log(c().dim('  ⏱ 已自动确认，开始执行计划'));
        done({ approved: true, modifications: [] });
      }, autoApproveMs);
      if (autoTimer.unref) autoTimer.unref();
    }

    const askApproval = () => {
      rl.question(c().dim('  计划确认 > '), (answer) => {
        if (autoTimer) {
          clearTimeout(autoTimer);
          autoTimer = null;
        }
        const raw = String(answer || '').trim();
        const trimmed = raw.toLowerCase();

        if (!trimmed || ['y', 'yes', 'ok', '确认', '执行', '继续'].includes(trimmed)) {
          done({ approved: true, modifications: [] });
          return;
        }

        if (['n', 'no', '取消', 'abort', 'stop'].includes(trimmed)) {
          _state = 'idle';
          _currentPlan = null;
          done({ approved: false, modifications: [] });
          return;
        }

        if (trimmed === '?' || trimmed === 'help' || trimmed === 'h') {
          console.log(c().dim('  示例:'));
          console.log(c().dim('    skip 2'));
          console.log(c().dim('    edit 1 补充输入数据下载与校验'));
          console.log(c().dim('    add after 2 运行自测并记录关键输出'));
          askApproval();
          return;
        }

        const modifications = [];
        const invalidCommands = [];
        const commands = raw.split(/[;,]/).map(s => s.trim()).filter(Boolean);

        for (const cmd of commands) {
          const skipMatch = cmd.match(/^(?:skip|跳过)\s+(\d+)$/i);
          const editMatch = cmd.match(/^(?:edit|修改)\s+(\d+)\s+(.+)$/i);
          const addMatch = cmd.match(/^(?:add|添加)\s+(?:after\s+)?(\d+)\s+(.+)$/i) || cmd.match(/^在\s*(\d+)\s*后(?:添加)?\s+(.+)$/i);

          if (skipMatch) {
            const idx = parseInt(skipMatch[1], 10) - 1;
            if (idx >= 0 && idx < plan.steps.length) {
              plan.steps[idx].status = 'skipped';
              modifications.push(`Skipped step ${skipMatch[1]}`);
            } else {
              invalidCommands.push(`${cmd} (step out of range)`);
            }
            continue;
          }

          if (editMatch) {
            const idx = parseInt(editMatch[1], 10) - 1;
            if (idx >= 0 && idx < plan.steps.length) {
              plan.steps[idx].description = editMatch[2].trim();
              modifications.push(`Edited step ${editMatch[1]}`);
            } else {
              invalidCommands.push(`${cmd} (step out of range)`);
            }
            continue;
          }

          if (addMatch) {
            const afterIdx = parseInt(addMatch[1], 10);
            if (Number.isNaN(afterIdx) || afterIdx < 0 || afterIdx > plan.steps.length) {
              invalidCommands.push(`${cmd} (step out of range)`);
              continue;
            }
            plan.steps.splice(afterIdx, 0, {
              id: afterIdx + 1,
              description: addMatch[2].trim(),
              status: 'pending',
            });
            plan.steps.forEach((s, i) => { s.id = i + 1; });
            modifications.push(`Added step after ${addMatch[1]}`);
            continue;
          }

          invalidCommands.push(cmd);
        }

        if (invalidCommands.length > 0) {
          console.log(c().yellow(`  未识别输入: ${invalidCommands.join(' ; ')}`));
          console.log(c().dim('  可用格式: Enter / skip N / edit N 描述 / add after N 描述 / n'));
          if (modifications.length === 0) {
            askApproval();
            return;
          }
        }

        done({ approved: true, modifications });
      });
    };

    askApproval();
  });
}

/**
 * Execute plan steps one by one with live progress tracking.
 * @param {object} plan - the plan with steps
 * @param {object} opts - { ai, renderer, rl, route, parseInput }
 * @returns {Array<{step: object, result: object}>}
 */
async function executePlanSteps(plan, opts) {
  const { ai: aiModule, renderer, rl } = opts;
  _state = 'executing';
  const stepTimeoutMs = parseInt(process.env.KHY_PLAN_STEP_TIMEOUT_MS || '180000', 10);
  const maxStepRetry = Math.max(0, parseInt(process.env.KHY_PLAN_STEP_RETRY || '1', 10));

  const results = [];
  const planTracker = new renderer.TaskPlanTracker();

  // Add all non-skipped steps
  const activeSteps = plan.steps.filter(s => s.status !== 'skipped');
  for (const step of activeSteps) {
    planTracker.addTask(step.description);
  }
  planTracker.render();

  for (let i = 0; i < activeSteps.length; i++) {
    const step = activeSteps[i];
    planTracker.start(i);
    const stepStartedAt = Date.now();

    try {
      // Execute step via AI with follow-up flag (prevents recursive plan mode)
      const basePrompt = `[执行计划步骤 ${step.id}/${plan.steps.length}]\n\n任务: ${step.description}\n\n要求:\n1) 必须实际执行，不要只描述计划。\n2) 如果涉及文件创建/修改，请直接完成并在回复中给出具体文件路径。\n3) 如果涉及命令执行，请给出命令与关键输出。\n4) 若执行失败，明确说明失败原因。`;

      let attempt = 0;
      let acceptedResult = null;
      let lastResult = null;
      let lastValidation = { ok: false, reason: 'unknown' };
      const maxAttempts = maxStepRetry + 1;

      while (attempt <= maxStepRetry) {
        const attemptNumber = attempt + 1;
        const prompt = attempt === 0
          ? basePrompt
          : `${basePrompt}\n\n上次执行未通过校验：${lastValidation.reason}\n请重新执行该步骤，并提供可验证证据。`;

        if (maxAttempts > 1) {
          renderer.printStepDetail(`步骤 ${step.id} 执行尝试 ${attemptNumber}/${maxAttempts}`, false);
        }

        const result = await runWithTimeout(
          aiModule.chat(prompt, { _isFollowUp: true }),
          stepTimeoutMs,
          `Plan step timeout after ${stepTimeoutMs}ms`
        );
        lastResult = result;
        lastValidation = validateStepResult(step, plan, result, stepStartedAt);
        if (lastValidation.ok) {
          acceptedResult = result;
          break;
        }

        renderer.printStepDetail(`步骤 ${step.id} 校验未通过: ${shortenReason(lastValidation.reason)}`, false);
        attempt += 1;
      }

      if (acceptedResult) {
        planTracker.complete(i);
        step.status = 'completed';
        results.push({ step, result: { ...acceptedResult, _planAttempts: attempt + 1 } });
      } else {
        planTracker.fail(i);
        step.status = 'error';
        const errorMsg = lastValidation.reason || (lastResult && lastResult.reply ? lastResult.reply : 'No response');
        renderer.printStepDetail(`步骤 ${step.id} 失败: ${shortenReason(errorMsg)}`, false);
        results.push({ step, result: { ...lastResult, error: errorMsg, _planAttempts: maxAttempts } });
      }
    } catch (err) {
      planTracker.fail(i);
      step.status = 'error';
      results.push({ step, result: { error: err.message } });
    }
  }

  _state = 'complete';
  _currentPlan = null;

  return results;
}

/**
 * Get current plan mode state.
 */
function getState() {
  return _state;
}

/**
 * Reset plan mode to idle.
 */
function reset() {
  _state = 'idle';
  _currentPlan = null;
}

module.exports = {
  enterPlanMode,
  parsePlanFromResponse,
  presentForApproval,
  executePlanSteps,
  getState,
  reset,
  PLAN_PROMPT,
};
