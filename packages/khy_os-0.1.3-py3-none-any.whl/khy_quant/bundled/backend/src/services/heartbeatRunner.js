'use strict';

/**
 * heartbeatRunner.js — Phase-aligned heartbeat scheduling with flood detection.
 *
 * Ported from OpenClaw's heartbeat-runner (2352 lines).
 * Provides a deterministic, phase-aligned scheduling system for periodic
 * AI heartbeats with ring-buffer flood detection, active hours gating,
 * configurable cooldown evaluation, and isolated session per heartbeat.
 *
 * Key features:
 * - Phase-aligned scheduling: SHA256(agentId) % interval for stagger
 * - Ring-buffer flood detection: sliding window burst protection
 * - Active hours gating: only run during configured time windows
 * - Cooldown evaluation: configurable per-intent cooldowns
 * - Isolated sessions: each heartbeat runs in its own context
 * - Intent matrix: manual/immediate/scheduled/event classification
 */

const crypto = require('crypto');

// ── Intent types ──

const INTENT = {
  MANUAL:    'manual',     // User-triggered
  IMMEDIATE: 'immediate', // System needs immediate response
  SCHEDULED: 'scheduled', // Regular timer-based
  EVENT:     'event',     // Triggered by external event
};

// ── Default configuration ──

const DEFAULTS = {
  intervalMs: 60_000,            // Base interval: 1 minute
  minCooldownMs: 30_000,         // Minimum 30 seconds between heartbeats
  activeHoursStart: 6,           // 6 AM
  activeHoursEnd: 23,            // 11 PM
  floodWindowMs: 60_000,         // 1 minute flood window
  floodMaxBursts: 5,             // Max 5 heartbeats per window
  maxHistorySize: 100,           // Ring buffer size
  sessionTimeoutMs: 120_000,     // 2 minute session timeout
  respectActiveHours: true,      // Enforce active hours
};

// ── Ring buffer for flood detection ──

class RingBuffer {
  /**
   * @param {number} capacity
   */
  constructor(capacity) {
    this._buffer = new Array(capacity).fill(0);
    this._head = 0;
    this._count = 0;
    this._capacity = capacity;
  }

  push(timestamp) {
    this._buffer[this._head] = timestamp;
    this._head = (this._head + 1) % this._capacity;
    if (this._count < this._capacity) this._count++;
  }

  /**
   * Count entries within a time window.
   */
  countWithin(windowMs) {
    const cutoff = Date.now() - windowMs;
    let count = 0;
    for (let i = 0; i < this._count; i++) {
      const idx = (this._head - 1 - i + this._capacity) % this._capacity;
      if (this._buffer[idx] >= cutoff) count++;
      else break; // entries are ordered, can stop early
    }
    return count;
  }

  /**
   * Get the most recent entry timestamp.
   */
  latest() {
    if (this._count === 0) return 0;
    return this._buffer[(this._head - 1 + this._capacity) % this._capacity];
  }

  get size() {
    return this._count;
  }
}

/**
 * Calculate the phase-aligned offset for an agent.
 * Uses SHA256 hash to deterministically stagger heartbeats.
 *
 * @param {string} agentId
 * @param {number} intervalMs
 * @returns {number} offset in milliseconds [0, intervalMs)
 */
function calculatePhaseOffset(agentId, intervalMs) {
  const hash = crypto.createHash('sha256').update(agentId).digest();
  // Use first 4 bytes as uint32
  const value = hash.readUInt32BE(0);
  return value % intervalMs;
}

/**
 * Check if current time is within active hours.
 *
 * @param {number} startHour
 * @param {number} endHour
 * @returns {boolean}
 */
function isWithinActiveHours(startHour, endHour) {
  const hour = new Date().getHours();
  if (startHour <= endHour) {
    return hour >= startHour && hour < endHour;
  }
  // Wrapping (e.g., 22 to 6)
  return hour >= startHour || hour < endHour;
}

/**
 * @typedef {object} HeartbeatResult
 * @property {boolean} executed
 * @property {string} [intent]
 * @property {number} [durationMs]
 * @property {object} [result]
 * @property {string} [error]
 * @property {string} [skippedReason]
 */

class HeartbeatRunner {
  /**
   * @param {object} opts
   * @param {string} opts.agentId - Unique agent identifier for phase alignment
   * @param {function} opts.heartbeatFn - (session) => Promise<result>
   * @param {object} [opts.config]
   * @param {function} [opts.onHeartbeat] - (result: HeartbeatResult) => void
   */
  constructor(opts = {}) {
    if (!opts.agentId) throw new Error('agentId is required');
    if (!opts.heartbeatFn) throw new Error('heartbeatFn is required');

    this._agentId = opts.agentId;
    this._heartbeatFn = opts.heartbeatFn;
    this._onHeartbeat = opts.onHeartbeat || null;
    this._config = { ...DEFAULTS, ...opts.config };

    // Phase offset for staggered scheduling
    this._phaseOffset = calculatePhaseOffset(this._agentId, this._config.intervalMs);

    // Flood detection
    this._floodBuffer = new RingBuffer(this._config.floodMaxBursts * 2);

    // Cooldown tracking per intent
    this._lastExecution = new Map(); // intent → timestamp

    // History
    this._history = []; // HeartbeatResult[]

    // Scheduling
    this._timer = null;
    this._running = false;
    this._sessionCounter = 0;
  }

  /**
   * Start the heartbeat scheduler.
   */
  start() {
    if (this._timer) return;

    // Calculate initial delay to align with phase
    const now = Date.now();
    const interval = this._config.intervalMs;
    const nextAligned = now - (now % interval) + this._phaseOffset;
    let initialDelay = nextAligned - now;
    if (initialDelay <= 0) initialDelay += interval;

    this._timer = setTimeout(() => {
      this._tick();
      // Switch to regular interval
      this._timer = setInterval(() => this._tick(), interval);
      if (this._timer.unref) this._timer.unref();
    }, initialDelay);

    if (this._timer.unref) this._timer.unref();
  }

  /**
   * Stop the heartbeat scheduler.
   */
  stop() {
    if (this._timer) {
      clearInterval(this._timer);
      clearTimeout(this._timer);
      this._timer = null;
    }
  }

  /**
   * Trigger an immediate heartbeat (bypass scheduler).
   *
   * @param {string} [intent='manual']
   * @returns {Promise<HeartbeatResult>}
   */
  async trigger(intent = INTENT.MANUAL) {
    return this._executeHeartbeat(intent);
  }

  /**
   * Check if a heartbeat should be allowed right now.
   *
   * @param {string} intent
   * @returns {{ allowed: boolean, reason?: string }}
   */
  checkCooldown(intent) {
    // Manual always allowed
    if (intent === INTENT.MANUAL) return { allowed: true };

    // Active hours check
    if (this._config.respectActiveHours && !isWithinActiveHours(
      this._config.activeHoursStart, this._config.activeHoursEnd
    )) {
      return { allowed: false, reason: 'Outside active hours' };
    }

    // Flood detection
    const recentCount = this._floodBuffer.countWithin(this._config.floodWindowMs);
    if (recentCount >= this._config.floodMaxBursts) {
      return { allowed: false, reason: `Flood limit: ${recentCount}/${this._config.floodMaxBursts} in window` };
    }

    // Cooldown check
    const lastExec = this._lastExecution.get(intent) || 0;
    const elapsed = Date.now() - lastExec;
    if (elapsed < this._config.minCooldownMs) {
      return {
        allowed: false,
        reason: `Cooldown: ${Math.ceil((this._config.minCooldownMs - elapsed) / 1000)}s remaining`,
      };
    }

    return { allowed: true };
  }

  /**
   * Get heartbeat history.
   */
  getHistory(limit) {
    return this._history.slice(-(limit || this._history.length));
  }

  /**
   * Get runner status.
   */
  getStatus() {
    return {
      agentId: this._agentId,
      running: !!this._timer,
      phaseOffset: this._phaseOffset,
      sessionCount: this._sessionCounter,
      lastHeartbeat: this._floodBuffer.latest(),
      floodCount: this._floodBuffer.countWithin(this._config.floodWindowMs),
      activeHours: this._config.respectActiveHours
        ? isWithinActiveHours(this._config.activeHoursStart, this._config.activeHoursEnd)
        : true,
      config: { ...this._config },
    };
  }

  // ── Internal ──

  _tick() {
    const cooldown = this.checkCooldown(INTENT.SCHEDULED);
    if (!cooldown.allowed) {
      this._recordResult({
        executed: false,
        intent: INTENT.SCHEDULED,
        skippedReason: cooldown.reason,
      });
      return;
    }

    this._executeHeartbeat(INTENT.SCHEDULED).catch(() => {});
  }

  async _executeHeartbeat(intent) {
    if (this._running) {
      const result = { executed: false, intent, skippedReason: 'Already running' };
      this._recordResult(result);
      return result;
    }

    const cooldown = this.checkCooldown(intent);
    if (!cooldown.allowed) {
      const result = { executed: false, intent, skippedReason: cooldown.reason };
      this._recordResult(result);
      return result;
    }

    this._running = true;
    this._sessionCounter++;
    this._floodBuffer.push(Date.now());
    this._lastExecution.set(intent, Date.now());

    const startTime = Date.now();
    const session = {
      id: `hb-${this._agentId}-${this._sessionCounter}`,
      agentId: this._agentId,
      intent,
      timestamp: startTime,
      counter: this._sessionCounter,
    };

    try {
      const fnResult = await Promise.race([
        this._heartbeatFn(session),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Heartbeat session timeout')),
            this._config.sessionTimeoutMs)
        ),
      ]);

      const result = {
        executed: true,
        intent,
        durationMs: Date.now() - startTime,
        result: fnResult,
      };

      this._recordResult(result);
      return result;

    } catch (err) {
      const result = {
        executed: true,
        intent,
        durationMs: Date.now() - startTime,
        error: err.message,
      };

      this._recordResult(result);
      return result;

    } finally {
      this._running = false;
    }
  }

  _recordResult(result) {
    this._history.push({ ...result, timestamp: Date.now() });
    if (this._history.length > this._config.maxHistorySize) {
      this._history = this._history.slice(-this._config.maxHistorySize);
    }

    if (this._onHeartbeat) {
      try { this._onHeartbeat(result); } catch { /* swallow */ }
    }
  }
}

module.exports = {
  INTENT,
  DEFAULTS,
  RingBuffer,
  calculatePhaseOffset,
  isWithinActiveHours,
  HeartbeatRunner,
};
