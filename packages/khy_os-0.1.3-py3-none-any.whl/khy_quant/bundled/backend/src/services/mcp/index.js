/**
 * MCP Service Module — Model Context Protocol client for Khy OS.
 *
 * Architecture aligned with Claude Code's MCP subsystem:
 *   - MCPServerConnection states: connected / connecting / failed / pending / disabled
 *   - MCPClient with connect(), listTools(), callTool(), disconnect()
 *   - Server instruction extraction and tool schema normalization
 *   - Config loaded from ~/.khy/mcp.json (user) and ./.khy/mcp.json (project)
 *
 * Config format (matches Claude Code's mcpServers schema):
 *
 *   {
 *     "mcpServers": {
 *       "filesystem": {
 *         "command": "npx",
 *         "args": ["-y", "@anthropic/mcp-server-filesystem", "/path"],
 *         "env": {}
 *       },
 *       "postgres": {
 *         "type": "sse",
 *         "url": "http://localhost:3100/sse"
 *       }
 *     }
 *   }
 */
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const readline = require('readline');
const EventEmitter = require('events');
const {
  Transport,
  ConnectionState,
  ConfigScope,
  validateServerConfig,
  serializeTool,
  buildCliState,
} = require('./types');

const PROTOCOL_VERSION = '2024-11-05';
const DEFAULT_CONNECT_TIMEOUT_MS = 30_000;
const DEFAULT_REQUEST_TIMEOUT_MS = 60_000;
const MAX_RECONNECT_ATTEMPTS = 3;
const RECONNECT_DELAY_MS = 2_000;

// Config file locations (priority: project > user > legacy)
const CONFIG_PATHS = {
  user: path.join(os.homedir(), '.khy', 'mcp.json'),
  legacy: path.join(os.homedir(), '.khyquant', 'mcp.json'),
};

// ── MCPClient ───────────────────────────────────────────────────────────────

class MCPClient extends EventEmitter {
  /**
   * @param {string} name - Server display name
   * @param {object} config - Server config (stdio / sse / http / ws)
   * @param {object} [options]
   * @param {number} [options.connectTimeout]
   * @param {number} [options.requestTimeout]
   */
  constructor(name, config, options = {}) {
    super();
    this.name = name;
    this.config = config;
    this.transportType = config.type || Transport.STDIO;
    this.connectTimeout = options.connectTimeout || DEFAULT_CONNECT_TIMEOUT_MS;
    this.requestTimeout = options.requestTimeout || DEFAULT_REQUEST_TIMEOUT_MS;

    /** @type {'connected'|'connecting'|'failed'|'pending'|'disabled'} */
    this.state = ConnectionState.PENDING;
    this.capabilities = {};
    this.serverInfo = null;
    this.instructions = null;

    this._process = null;
    this._tools = [];
    this._resources = [];
    this._prompts = [];
    this._requestId = 0;
    this._pendingRequests = new Map();
    this._reconnectAttempt = 0;
    this._lastError = null;
  }

  // ── Connection Lifecycle ────────────────────────────────────────────────

  /**
   * Connect to the MCP server. Supports stdio transport (spawn process).
   * SSE/HTTP/WS transports are stub-ready for future extension.
   * @returns {Promise<void>}
   */
  async connect() {
    if (this.state === ConnectionState.CONNECTED) return;
    if (this.state === ConnectionState.DISABLED) {
      throw new Error(`MCP server "${this.name}" is disabled`);
    }

    // Validate config before attempting connection
    const validation = validateServerConfig(this.config);
    if (!validation.valid) {
      this.state = ConnectionState.FAILED;
      this._lastError = `Invalid config: ${validation.errors.join('; ')}`;
      this.emit('stateChange', this.state, this._lastError);
      throw new Error(this._lastError);
    }

    this.state = ConnectionState.CONNECTING;
    this.emit('stateChange', this.state);

    try {
      if (this.transportType === Transport.STDIO) {
        await this._connectStdio();
      } else {
        // Future: SSE, HTTP, WS transports
        throw new Error(`Transport "${this.transportType}" is not yet supported`);
      }

      this.state = ConnectionState.CONNECTED;
      this._reconnectAttempt = 0;
      this.emit('stateChange', this.state);
    } catch (err) {
      this.state = ConnectionState.FAILED;
      this._lastError = err.message;
      this.emit('stateChange', this.state, err.message);
      throw err;
    }
  }

  /**
   * Disconnect from the MCP server and clean up resources.
   * @returns {Promise<void>}
   */
  async disconnect() {
    // Cancel all pending requests
    for (const [id, { reject }] of this._pendingRequests) {
      reject(new Error('Client disconnecting'));
      this._pendingRequests.delete(id);
    }

    if (this._process) {
      const { safeSignal } = require('../../tools/platformUtils');
      safeSignal(this._process, 'SIGTERM');
      this._process = null;
    }

    if (this._readline) {
      this._readline.close();
      this._readline = null;
    }

    this.state = ConnectionState.PENDING;
    this._tools = [];
    this._resources = [];
    this._prompts = [];
    this.emit('stateChange', this.state);
  }

  /**
   * Attempt reconnection with exponential backoff.
   * @returns {Promise<boolean>} true if reconnection succeeded
   */
  async reconnect() {
    if (this._reconnectAttempt >= MAX_RECONNECT_ATTEMPTS) {
      this._lastError = `Max reconnect attempts (${MAX_RECONNECT_ATTEMPTS}) exceeded`;
      this.state = ConnectionState.FAILED;
      this.emit('stateChange', this.state, this._lastError);
      return false;
    }

    this._reconnectAttempt++;
    const delay = RECONNECT_DELAY_MS * Math.pow(2, this._reconnectAttempt - 1);

    await new Promise(r => setTimeout(r, delay));

    try {
      await this.disconnect();
      await this.connect();
      return true;
    } catch {
      return false;
    }
  }

  // ── Tool Operations ─────────────────────────────────────────────────────

  /**
   * List all tools exposed by this MCP server.
   * @returns {object[]} Array of tool definitions
   */
  listTools() {
    return this._tools.map(t => serializeTool(this.name, t));
  }

  /**
   * Call a tool on the MCP server.
   * @param {string} toolName - The tool name (original, not prefixed)
   * @param {object} [args={}] - Tool arguments
   * @returns {Promise<object>} Tool call result
   */
  async callTool(toolName, args = {}) {
    this._ensureConnected();

    const result = await this._sendRequest('tools/call', {
      name: toolName,
      arguments: args,
    });

    return result;
  }

  /**
   * List resources exposed by this MCP server.
   * @returns {object[]}
   */
  listResources() {
    return this._resources;
  }

  /**
   * Get the server's instruction string (if provided during initialization).
   * @returns {string|null}
   */
  getInstructions() {
    return this.instructions;
  }

  /**
   * Get raw tool definitions (not serialized).
   * @returns {object[]}
   */
  get tools() {
    return this._tools;
  }

  /**
   * Get prompts exposed by this MCP server.
   * @returns {object[]}
   */
  get prompts() {
    return this._prompts;
  }

  /**
   * Build a connection snapshot for serialization.
   * @returns {object}
   */
  toConnectionObject() {
    return {
      name: this.name,
      type: this.state,
      config: this.config,
      capabilities: this.capabilities,
      serverInfo: this.serverInfo,
      instructions: this.instructions,
      tools: this._tools,
      resources: this._resources,
      error: this._lastError,
      reconnectAttempt: this._reconnectAttempt,
      maxReconnectAttempts: MAX_RECONNECT_ATTEMPTS,
    };
  }

  // ── Internal: Stdio Transport ───────────────────────────────────────────

  /** @private */
  async _connectStdio() {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new Error(`MCP server "${this.name}" connection timed out after ${this.connectTimeout}ms`));
      }, this.connectTimeout);

      try {
        const env = { ...process.env, ...(this.config.env || {}) };
        this._process = spawn(this.config.command, this.config.args || [], {
          stdio: ['pipe', 'pipe', 'pipe'],
          env,
        });

        // JSON-RPC line-delimited protocol on stdout
        this._readline = readline.createInterface({ input: this._process.stdout });
        this._readline.on('line', (line) => {
          try {
            const msg = JSON.parse(line);
            this._handleMessage(msg);
          } catch { /* ignore non-JSON lines */ }
        });

        this._process.stderr.on('data', (data) => {
          const text = data.toString().trim();
          if (text) this._lastError = text;
        });

        this._process.on('error', (err) => {
          clearTimeout(timer);
          reject(err);
        });

        this._process.on('exit', (code) => {
          if (this.state === ConnectionState.CONNECTING) {
            clearTimeout(timer);
            reject(new Error(`MCP server "${this.name}" exited with code ${code} during startup`));
          } else if (this.state === ConnectionState.CONNECTED) {
            this.state = ConnectionState.FAILED;
            this._lastError = `Process exited with code ${code}`;
            this.emit('stateChange', this.state, this._lastError);
            this.emit('unexpectedExit', code);
          }
        });

        // MCP initialize handshake
        this._sendRequest('initialize', {
          protocolVersion: PROTOCOL_VERSION,
          capabilities: {
            tools: {},
            resources: {},
            prompts: {},
          },
          clientInfo: {
            name: 'khy-os',
            version: _getVersion(),
          },
        }).then(async (result) => {
          clearTimeout(timer);

          // Extract server metadata
          this.capabilities = result.capabilities || {};
          this.serverInfo = result.serverInfo || null;
          this.instructions = result.instructions || null;

          // Send initialized notification
          this._sendNotification('notifications/initialized', {});

          // Fetch tools, resources, prompts in parallel
          const [toolsResult, resourcesResult, promptsResult] = await Promise.allSettled([
            this._sendRequest('tools/list', {}),
            this._sendRequest('resources/list', {}),
            this._sendRequest('prompts/list', {}),
          ]);

          this._tools = toolsResult.status === 'fulfilled' ? (toolsResult.value.tools || []) : [];
          this._resources = resourcesResult.status === 'fulfilled' ? (resourcesResult.value.resources || []) : [];
          this._prompts = promptsResult.status === 'fulfilled' ? (promptsResult.value.prompts || []) : [];

          resolve();
        }).catch((err) => {
          clearTimeout(timer);
          reject(err);
        });
      } catch (err) {
        clearTimeout(timer);
        reject(err);
      }
    });
  }

  // ── Internal: JSON-RPC ──────────────────────────────────────────────────

  /** @private */
  _sendRequest(method, params) {
    return new Promise((resolve, reject) => {
      const id = ++this._requestId;
      const msg = JSON.stringify({ jsonrpc: '2.0', id, method, params });

      this._pendingRequests.set(id, { resolve, reject, method });

      if (!this._process?.stdin?.writable) {
        this._pendingRequests.delete(id);
        reject(new Error(`Cannot send request: process stdin not writable`));
        return;
      }

      this._process.stdin.write(msg + '\n');

      // Per-request timeout
      const timer = setTimeout(() => {
        if (this._pendingRequests.has(id)) {
          this._pendingRequests.delete(id);
          reject(new Error(`MCP request "${method}" timed out after ${this.requestTimeout}ms`));
        }
      }, this.requestTimeout);

      // Store timer reference for cleanup
      const entry = this._pendingRequests.get(id);
      if (entry) entry._timer = timer;
    });
  }

  /** @private */
  _sendNotification(method, params) {
    const msg = JSON.stringify({ jsonrpc: '2.0', method, params });
    if (this._process?.stdin?.writable) {
      this._process.stdin.write(msg + '\n');
    }
  }

  /** @private */
  _handleMessage(msg) {
    // Response to a pending request
    if (msg.id != null && this._pendingRequests.has(msg.id)) {
      const entry = this._pendingRequests.get(msg.id);
      this._pendingRequests.delete(msg.id);
      if (entry._timer) clearTimeout(entry._timer);

      if (msg.error) {
        entry.reject(new Error(msg.error.message || `MCP error: code ${msg.error.code}`));
      } else {
        entry.resolve(msg.result);
      }
      return;
    }

    // Server-initiated notifications
    if (msg.method === 'notifications/tools/list_changed') {
      this._refreshTools();
    } else if (msg.method === 'notifications/resources/list_changed') {
      this._refreshResources();
    }
  }

  /** @private */
  async _refreshTools() {
    try {
      const result = await this._sendRequest('tools/list', {});
      this._tools = result.tools || [];
      this.emit('toolsChanged', this._tools);
    } catch { /* best effort */ }
  }

  /** @private */
  async _refreshResources() {
    try {
      const result = await this._sendRequest('resources/list', {});
      this._resources = result.resources || [];
      this.emit('resourcesChanged', this._resources);
    } catch { /* best effort */ }
  }

  /** @private */
  _ensureConnected() {
    if (this.state !== ConnectionState.CONNECTED) {
      throw new Error(`MCP server "${this.name}" is not connected (state: ${this.state})`);
    }
  }
}

// ── Connection Manager ──────────────────────────────────────────────────────

/** @type {Map<string, MCPClient>} */
const _connections = new Map();

/**
 * Load MCP config from disk. Checks project-local, user-level, and legacy paths.
 * @param {string} [projectDir] - Optional project directory for local config
 * @returns {object} Merged config with mcpServers map
 */
function loadConfig(projectDir) {
  const merged = { mcpServers: {} };

  // Load order: user < project (project overrides user)
  const paths = [
    { path: CONFIG_PATHS.user, scope: ConfigScope.USER },
    { path: CONFIG_PATHS.legacy, scope: ConfigScope.USER },
  ];

  if (projectDir) {
    paths.push({
      path: path.join(projectDir, '.khy', 'mcp.json'),
      scope: ConfigScope.LOCAL,
    });
    // Legacy project config
    paths.push({
      path: path.join(projectDir, '.khyquant', 'mcp.json'),
      scope: ConfigScope.LOCAL,
    });
  }

  for (const { path: configPath, scope } of paths) {
    try {
      if (!fs.existsSync(configPath)) continue;
      const raw = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

      // Support both new format { mcpServers: {...} } and legacy { servers: [...] }
      if (raw.mcpServers && typeof raw.mcpServers === 'object') {
        for (const [name, config] of Object.entries(raw.mcpServers)) {
          merged.mcpServers[name] = { ...config, _scope: scope, _configPath: configPath };
        }
      } else if (Array.isArray(raw.servers)) {
        // Legacy format: convert array to named map
        for (const serverConfig of raw.servers) {
          if (!serverConfig.name) continue;
          const { name, enabled, ...rest } = serverConfig;
          if (enabled === false) {
            merged.mcpServers[name] = { ...rest, _scope: scope, _disabled: true };
          } else {
            merged.mcpServers[name] = { ...rest, _scope: scope };
          }
        }
      }
    } catch { /* skip malformed config files */ }
  }

  return merged;
}

/**
 * Save MCP server config to the user-level config file.
 * @param {object} config - Full config object with mcpServers
 */
function saveConfig(config) {
  const dir = path.dirname(CONFIG_PATHS.user);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  // Strip internal fields before saving
  const clean = { mcpServers: {} };
  for (const [name, serverConfig] of Object.entries(config.mcpServers || {})) {
    const { _scope, _configPath, _disabled, ...rest } = serverConfig;
    clean.mcpServers[name] = rest;
  }

  fs.writeFileSync(CONFIG_PATHS.user, JSON.stringify(clean, null, 2), 'utf-8');
}

/**
 * Connect to a single MCP server by name and config.
 * @param {string} name - Server name
 * @param {object} config - Server config
 * @param {object} [options] - Connection options
 * @returns {Promise<MCPClient>}
 */
async function connectMCPServer(name, config, options = {}) {
  // Disconnect existing connection for this name
  if (_connections.has(name)) {
    await disconnectMCPServer(name);
  }

  const client = new MCPClient(name, config, options);

  // Handle unexpected exits with auto-reconnect
  client.on('unexpectedExit', async () => {
    const reconnected = await client.reconnect();
    if (!reconnected) {
      _connections.delete(name);
    }
  });

  _connections.set(name, client);

  await client.connect();
  return client;
}

/**
 * Disconnect a single MCP server by name.
 * @param {string} name
 * @returns {Promise<void>}
 */
async function disconnectMCPServer(name) {
  const client = _connections.get(name);
  if (!client) return;

  await client.disconnect();
  _connections.delete(name);
}

/**
 * Connect to all configured MCP servers.
 * @param {string} [projectDir] - Optional project directory
 * @returns {Promise<{ connected: string[], failed: { name: string, error: string }[] }>}
 */
async function connectAll(projectDir) {
  const config = loadConfig(projectDir);
  const connected = [];
  const failed = [];

  const entries = Object.entries(config.mcpServers);
  if (entries.length === 0) return { connected, failed };

  // Connect in parallel
  const results = await Promise.allSettled(
    entries.map(async ([name, serverConfig]) => {
      if (serverConfig._disabled) {
        return { name, status: 'disabled' };
      }
      await connectMCPServer(name, serverConfig);
      return { name, status: 'connected' };
    })
  );

  for (const result of results) {
    if (result.status === 'fulfilled') {
      if (result.value.status === 'connected') {
        connected.push(result.value.name);
      }
    } else {
      const name = entries[results.indexOf(result)]?.[0] || 'unknown';
      failed.push({ name, error: result.reason?.message || 'Unknown error' });
    }
  }

  return { connected, failed };
}

/**
 * Disconnect all MCP servers.
 * @returns {Promise<void>}
 */
async function disconnectAll() {
  const promises = [];
  for (const name of _connections.keys()) {
    promises.push(disconnectMCPServer(name));
  }
  await Promise.allSettled(promises);
}

/**
 * List all tools from all connected MCP servers.
 * @returns {object[]} Array of serialized tool definitions
 */
function listMCPTools() {
  const tools = [];
  for (const client of _connections.values()) {
    if (client.state === ConnectionState.CONNECTED) {
      tools.push(...client.listTools());
    }
  }
  return tools;
}

/**
 * Call a tool by its fully qualified name (mcp__serverName__toolName).
 * @param {string} qualifiedName - e.g., "mcp__filesystem__read_file"
 * @param {object} [args={}]
 * @returns {Promise<object>}
 */
async function callMCPTool(qualifiedName, args = {}) {
  const parts = qualifiedName.split('__');
  if (parts.length < 3 || parts[0] !== 'mcp') {
    throw new Error(`Invalid MCP tool name: ${qualifiedName}. Expected format: mcp__serverName__toolName`);
  }

  const serverName = parts[1];
  const toolName = parts.slice(2).join('__'); // Tool name may contain __

  const client = _connections.get(serverName);
  if (!client) {
    throw new Error(`MCP server "${serverName}" not found`);
  }

  return client.callTool(toolName, args);
}

/**
 * Get all server instructions (for system prompt injection).
 * @returns {string[]} Array of instruction strings from connected servers
 */
function getMCPInstructions() {
  const instructions = [];
  for (const client of _connections.values()) {
    if (client.state === ConnectionState.CONNECTED && client.instructions) {
      instructions.push(`[MCP Server: ${client.name}]\n${client.instructions}`);
    }
  }
  return instructions;
}

/**
 * Get the current state of all connections.
 * @returns {object} MCPCliState
 */
function getState() {
  return buildCliState(_connections);
}

/**
 * Get a specific client by name.
 * @param {string} name
 * @returns {MCPClient|undefined}
 */
function getClient(name) {
  return _connections.get(name);
}

/**
 * Get all connected client names.
 * @returns {string[]}
 */
function getConnectedServers() {
  const names = [];
  for (const [name, client] of _connections) {
    if (client.state === ConnectionState.CONNECTED) {
      names.push(name);
    }
  }
  return names;
}

// ── Internal Helpers ────────────────────────────────────────────────────────

function _getVersion() {
  try {
    return require('../../../package.json').version;
  } catch {
    return '0.0.0';
  }
}

module.exports = {
  // Core class
  MCPClient,

  // Connection management
  connectMCPServer,
  disconnectMCPServer,
  connectAll,
  disconnectAll,

  // Tool operations
  listMCPTools,
  callMCPTool,

  // State & instructions
  getMCPInstructions,
  getState,
  getClient,
  getConnectedServers,

  // Config
  loadConfig,
  saveConfig,

  // Re-export types
  Transport,
  ConnectionState,
  ConfigScope,
};
