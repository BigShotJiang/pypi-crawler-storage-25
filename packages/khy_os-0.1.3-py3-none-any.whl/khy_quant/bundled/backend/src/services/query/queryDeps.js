/**
 * Query Dependencies — dependency injection container.
 *
 * Wraps external modules into a deps object so the query loop
 * can be tested without real services. Production deps are
 * resolved lazily to avoid circular requires.
 *
 * Usage:
 *   const deps = productionDeps();        // real services
 *   const deps = createDeps({ callModel: mockFn }); // test override
 */

/**
 * Build the production dependency bag.
 * All requires are lazy — evaluated on first call, not on import.
 *
 * @returns {object} deps
 */
function productionDeps() {
  // Lazy references (resolved once on first use)
  let _ai, _toolUseLoop, _toolCalling, _toolRegistry, _tokenUsage;

  return {
    /**
     * Send a message to the AI model.
     * Wraps ai.chat() preserving its full signature.
     *
     * @param {string} message
     * @param {object} [opts]
     * @returns {Promise<{ reply: string, provider?: string, inputTokens?: number, outputTokens?: number }>}
     */
    callModel(message, opts = {}) {
      if (!_ai) _ai = require('../../cli/ai');
      return _ai.chat(message, opts);
    },

    /**
     * Parse tool calls from AI response text.
     * @param {string} text
     * @returns {Array<{ name: string, params: object }>}
     */
    parseToolCalls(text) {
      if (!_toolUseLoop) _toolUseLoop = require('../toolUseLoop');
      return _toolUseLoop._parseToolCalls(text);
    },

    /**
     * Execute a single tool by name.
     * @param {string} toolName
     * @param {object} params
     * @returns {Promise<*>}
     */
    async executeTools(toolName, params) {
      if (!_toolCalling) _toolCalling = require('../toolCalling');
      if (!_toolRegistry) _toolRegistry = require('../../tools');

      // Capture writeFile diff context so streaming UI can render red/green changes.
      let writeCtx = null;
      try {
        if (toolName === 'writeFile') {
          const relPath = params?.path;
          const afterContent = params?.content;
          if (relPath && typeof afterContent === 'string') {
            const cwd = process.env.KHYQUANT_CWD || process.cwd();
            const filePath = require('path').isAbsolute(relPath)
              ? relPath
              : require('path').resolve(cwd, relPath);
            const beforeContent = require('fs').existsSync(filePath)
              ? require('fs').readFileSync(filePath, 'utf-8')
              : '';
            writeCtx = { filePath, beforeContent, afterContent };
          }
        }
      } catch { /* non-critical */ }

      const result = await _toolCalling.executeTool(toolName, params);

      // Attach runtime metadata for renderer (not persisted to user-facing text)
      if (writeCtx && result && typeof result === 'object') {
        result._khyWriteDiff = writeCtx;
      }
      return result;
    },

    /**
     * Check if a tool is safe for concurrent execution.
     * @param {string} toolName
     * @returns {boolean}
     */
    isConcurrencySafe(toolName) {
      try {
        if (!_toolRegistry) _toolRegistry = require('../../tools');
        if (_toolRegistry.isConcurrencySafe) {
          const safeMap = _toolRegistry.isConcurrencySafe();
          return safeMap.has(toolName);
        }
      } catch { /* registry not available */ }
      return false;
    },

    /**
     * Estimate token count for text.
     * @param {string} text
     * @returns {number}
     */
    estimateTokens(text) {
      try {
        if (!_tokenUsage) _tokenUsage = require('../tokenUsageService');
        if (_tokenUsage.estimateTokens) {
          return _tokenUsage.estimateTokens(text);
        }
      } catch { /* fallback below */ }
      // Fallback: ~3 chars per token
      return Math.ceil((text || '').length / 3);
    },

    /**
     * Generate a unique ID.
     * @returns {string}
     */
    uuid() {
      return `qe_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    },
  };
}

/**
 * Create a deps object with optional overrides.
 * Useful for testing — override only the functions you need.
 *
 * @param {object} [overrides] - Partial deps to merge
 * @returns {object} Merged deps
 */
function createDeps(overrides = {}) {
  return {
    ...productionDeps(),
    ...overrides,
  };
}

module.exports = { productionDeps, createDeps };
