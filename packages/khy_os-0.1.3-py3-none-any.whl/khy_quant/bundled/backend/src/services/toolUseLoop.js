/**
 * Tool-Use Loop — iterative AI ↔ tool execution cycle.
 *
 * Inspired by Claude Code's agentic loop:
 *   1. Send user message + tool definitions → AI
 *   2. Parse AI response for tool calls
 *   3. Execute tools (with permission checks)
 *   4. Append results to conversation, loop back to step 1
 *   5. When AI responds without tool calls → return final answer
 *
 * Safety: hard max-iterations limit, per-tool timeout, audit logging.
 * Feature flag: KHY_TOOL_LOOP=false disables this, falling back to legacy.
 */
const chalk = require('chalk').default || require('chalk');
const fs = require('fs');
const path = require('path');
const { diagnostics, generateTraceId: genDiagTraceId } = require('./diagnosticEvents');
const { runWithConcurrency } = require('./concurrencyLimiter');
const { analyzeCommand } = require('./shellSafetyValidator');
const { normalizeToolCall } = require('./claudeCompat');

// Exec approval (multi-level permission, complements shellSafetyValidator)
let _execApproval;
try {
  const { execApproval } = require('./execApproval');
  _execApproval = execApproval;
} catch { _execApproval = null; }

// ── Constants ──────────────────────────────────────────────────────

const MAX_ITERATIONS = 10;
const MAX_ELAPSED_MS_DEFAULT = 120000;
const TOOL_CALL_REGEX = /<tool_call>\s*(\w+)\s*\(([^)]*)\)\s*<\/tool_call>/g;
const JSON_TOOL_CALL_REGEX = /<tool_call>\s*(\{[\s\S]*?\})\s*<\/tool_call>/g;
const NATURAL_ACTION_TO_TOOL = {
  // Search
  '搜索': 'web_search',
  'search': 'web_search',
  'websearch': 'web_search',
  'web_search': 'web_search',
  '查找': 'search',

  // Market quote
  '行情': 'quote',
  'quote': 'quote',
  '报价': 'quote',
  '价格': 'quote',

  // Backtest
  '回测': 'backtest',
  'backtest': 'backtest',

  // Build / Test / Lint / Verify
  '构建': 'build_project',
  'build': 'build_project',
  '编译': 'build_project',
  '测试': 'run_tests',
  'test': 'run_tests',
  'lint': 'lint_code',
  '检查': 'lint_code',
  '代码检查': 'lint_code',
  '验证': 'verify_artifact',
  'verify': 'verify_artifact',
  '交付验证': 'verify_artifact',

  // K-line / data fetch
  'k线': 'data_fetch',
  'K线': 'data_fetch',
  'kline': 'data_fetch',
  'k线查询': 'data_fetch',

  // Strategy list
  '策略列表': 'strategy_list',
  'strategylist': 'strategy_list',
  'strategy_list': 'strategy_list',

  // File operations
  '读取文件': 'read_file',
  '读文件': 'read_file',
  'readfile': 'read_file',
  'read_file': 'read_file',
  '写入文件': 'write_file',
  'writefile': 'write_file',
  'write_file': 'write_file',

  // Shell
  '命令': 'shell_command',
  'shell': 'shell_command',
  'bash': 'shell_command',
  'shellcommand': 'shell_command',
  'shell_command': 'shell_command',

  // App launch
  '打开应用': 'open_app',
  '启动应用': 'open_app',
  '打开程序': 'open_app',
  'openapp': 'open_app',
  'open_app': 'open_app',
  '应用': 'open_app',
  '浏览器': 'open_app',

  // Git
  'git状态': 'git_status',
  'gitstatus': 'git_status',
  'git_status': 'git_status',
  'git差异': 'git_diff',
  'gitdiff': 'git_diff',
  'git_diff': 'git_diff',

  // Glob file search
  '文件搜索': 'glob',
  'glob': 'glob',
  'find': 'glob',
  'find_files': 'glob',

  // Grep content search
  '内容搜索': 'grep',
  'grep': 'grep',
  'rg': 'grep',
  'search_content': 'grep',

  // Edit file (precise replacement)
  '编辑': 'editFile',
  'edit': 'editFile',
  '修改文件': 'editFile',
  'edit_file': 'editFile',
  'replace': 'editFile',
};

function _parsePositiveInt(value, fallback, min = 1, max = Number.MAX_SAFE_INTEGER) {
  const n = Number.parseInt(String(value || '').trim(), 10);
  if (!Number.isFinite(n) || n < min) return fallback;
  return Math.min(max, n);
}

function _resolveMaxIterations(requestedMaxIterations) {
  if (requestedMaxIterations !== undefined && requestedMaxIterations !== null) {
    return _parsePositiveInt(requestedMaxIterations, MAX_ITERATIONS, 1, 100);
  }
  return _parsePositiveInt(process.env.KHY_TOOL_LOOP_MAX_ITERATIONS, MAX_ITERATIONS, 1, 100);
}

function _resolveMaxElapsedMs() {
  return _parsePositiveInt(
    process.env.KHY_TOOL_LOOP_MAX_MS,
    MAX_ELAPSED_MS_DEFAULT,
    5000,
    15 * 60 * 1000,
  );
}

function _resolveTaskScale(userMessage = '', options = {}) {
  const explicit = String(options.taskScale || '').trim().toLowerCase();
  if (explicit === 'small' || explicit === 'normal' || explicit === 'large') return explicit;
  const text = String(userMessage || '');
  const largeHint = /大型任务|大任务|完整实现|全量|全流程|端到端|深度|深入|deep|exhaustive|end-to-end|full implementation/i.test(text);
  if (largeHint || text.length >= 700 || (text.length >= 450 && /\n/.test(text))) return 'large';
  if (text.length <= 120 && !/\n/.test(text)) return 'small';
  return 'normal';
}

function _isTransientLoopErrorType(errorType = '') {
  const t = String(errorType || '').trim().toLowerCase();
  return t === 'timeout'
    || t === 'cancelled'
    || t === 'network'
    || t === 'process'
    || t === 'unknown';
}

function _resolveTransientRecoveryMax(userMessage = '', options = {}) {
  const explicit = parseInt(String(options.maxTransientRecoveries ?? ''), 10);
  if (Number.isFinite(explicit)) return Math.max(0, Math.min(6, explicit));
  const scale = _resolveTaskScale(userMessage, options);
  if (scale === 'small') {
    const n = parseInt(String(process.env.KHY_TOOL_LOOP_TRANSIENT_RECOVERIES_SMALL || '0'), 10);
    return Number.isFinite(n) ? Math.max(0, Math.min(3, n)) : 0;
  }
  if (scale === 'large') {
    const n = parseInt(String(process.env.KHY_TOOL_LOOP_TRANSIENT_RECOVERIES_LARGE || '3'), 10);
    return Number.isFinite(n) ? Math.max(0, Math.min(6, n)) : 3;
  }
  const n = parseInt(String(process.env.KHY_TOOL_LOOP_TRANSIENT_RECOVERIES || '1'), 10);
  return Number.isFinite(n) ? Math.max(0, Math.min(4, n)) : 1;
}

function _recoveryDelayMs(attemptIndex = 0) {
  const base = Math.max(300, parseInt(String(process.env.KHY_TOOL_LOOP_RECOVERY_DELAY_MS || '1200'), 10) || 1200);
  const exp = Math.min(4, Math.max(0, attemptIndex));
  const jitter = Math.random() * 300;
  return Math.round(base * Math.pow(1.65, exp) + jitter);
}

function _formatDurationMs(ms) {
  const totalSec = Math.max(1, Math.ceil(Number(ms || 0) / 1000));
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  if (m > 0 && s > 0) return `${m}m ${s}s`;
  if (m > 0) return `${m}m`;
  return `${s}s`;
}

// ── Main Loop ──────────────────────────────────────────────────────

/**
 * Run an iterative tool-use loop: AI generates tool calls, system executes
 * them, feeds results back, and AI continues until it has a final answer.
 *
 * @param {string} userMessage - The user's original message
 * @param {object} options
 * @param {function} options.chat - AI chat function (message, opts) => { reply, ... }
 * @param {object} [options.chatOpts] - Options passed through to chat()
 * @param {number} [options.maxIterations] - Safety limit on loop iterations (fallback: KHY_TOOL_LOOP_MAX_ITERATIONS or 10)
 * @param {function} [options.onToolCall] - Callback before tool execution: (toolName, params, iteration)
 * @param {function} [options.onToolResult] - Callback after tool execution: (toolName, params, result, iteration, elapsedMs)
 * @param {function} [options.onIteration] - Callback at each iteration start: (iteration, totalCalls)
 * @param {function} [options.onPlanReady] - Callback when execution plan is parsed: (plan)
 * @param {function} [options.onPlanProgress] - Callback as plan steps progress: (stepIndex, status)
 * @param {function} [options.onParallelBatch] - Callback before a parallel batch runs: (calls, iteration)
 * @param {function} [options.onNoToolCall] - Callback when an iteration returns no tool calls: (iteration, reply, info)
 * @returns {Promise<{ finalResponse: string, toolCallLog: Array, iterations: number, provider?: string }>}
 */
async function runToolUseLoop(userMessage, options = {}) {
  const {
    chat,
    chatOpts = {},
    maxIterations: requestedMaxIterations,
    sessionId: requestedSessionId,
    onToolCall,
    onToolResult,
    onIteration,
    onPlanReady,
    onPlanProgress,
    onParallelBatch,
    onNoToolCall,
  } = options;

  if (!chat || typeof chat !== 'function') {
    throw new Error('toolUseLoop: chat function is required');
  }

  let traceAudit = null;
  try {
    traceAudit = require('./traceAuditService');
    traceAudit.ensureDiagnosticsBridge();
  } catch { /* optional */ }
  const diagTraceId = options?._diagTraceId || genDiagTraceId();
  const traceSessionId = requestedSessionId || traceAudit?.getContext?.()?.sessionId || null;
  if (options && typeof options === 'object') {
    options._diagTraceId = diagTraceId;
  }
  if (traceAudit && traceSessionId) {
    try {
      traceAudit.attachTrace(diagTraceId, traceSessionId);
      traceAudit.logEvent('agent.loop.start', {
        maxIterations: _resolveMaxIterations(requestedMaxIterations),
        messagePreview: String(userMessage || '').slice(0, 600),
      }, {
        sessionId: traceSessionId,
        traceId: diagTraceId,
        source: 'tool-loop',
        visibility: 'summary',
      });
    } catch { /* non-critical */ }
  }

  const toolCallLog = [];
  let currentMessage = userMessage;
  let lastResult = null;
  let totalToolCalls = 0;
  let preflightApproved = null; // Set<string> of batch-approved tool names
  let executionPlan = null;     // Parsed execution plan { steps: [...] }
  let currentPlanStep = 0;
  let noToolNudgeUsed = false;
  const resolvedMaxIterations = _resolveMaxIterations(requestedMaxIterations);
  const transientRecoveryMax = _resolveTransientRecoveryMax(userMessage, options);
  const effectiveMaxIterations = Math.min(160, resolvedMaxIterations + transientRecoveryMax);
  const maxElapsedMs = _resolveMaxElapsedMs();
  let transientRecoveryUsed = 0;

  // Dedup: track ALL tool calls (both success and failure) to avoid re-executing
  // identical calls. Previously only tracked failures, which allowed the AI to
  // call the same successful command (e.g. `tree /f .`) 10 times in a loop.
  const executedCallKeys = new Map(); // key -> { result, count }

  // Phase 2: 5-detector loop detection (replaces simple dedup for advanced checks)
  let loopDetector;
  try {
    const { ToolLoopDetector } = require('./toolLoopDetector');
    loopDetector = new ToolLoopDetector();
    // Register known tools for unknown-tool detection
    try {
      const toolRegistry = require('../tools');
      const allTools = toolRegistry.getEnabled ? toolRegistry.getEnabled() : toolRegistry.getAll();
      if (allTools) {
        const names = allTools instanceof Map ? allTools.keys() : Object.keys(allTools);
        loopDetector.registerTools(names);
      }
    } catch { /* registry not available, skip unknown-tool detection */ }
  } catch { loopDetector = null; /* toolLoopDetector not available */ }

  // Guardrails: time limit, read-only cap, and consecutive failure cap
  const loopStartTime = Date.now();
  const MAX_READ_ONLY_ITERATIONS = 5; // If AI only reads without acting, force summary after 5
  const MAX_CONSECUTIVE_FAILURES = 3; // If all tool calls fail N iterations in a row, bail out
  let consecutiveReadOnlyIterations = 0;
  let consecutiveFailureIterations = 0;

  // Inject planning prompt for complex tasks
  const isComplex = _isComplexTask(userMessage);
  if (isComplex && process.env.KHY_TASK_PLAN !== 'false') {
    currentMessage = _injectPlanningPrompt(userMessage);
  }

  try {

  for (let iteration = 1; iteration <= effectiveMaxIterations; iteration++) {
    if (onIteration) onIteration(iteration, totalToolCalls);

    // Time guardrail: force return if loop has been running too long
    const elapsed = Date.now() - loopStartTime;
    if (elapsed > maxElapsedMs) {
      const limitText = _formatDurationMs(maxElapsedMs);
      const timeWarning = `\n\n${chalk.yellow(`⚠ 工具循环超时 (>${limitText})。返回已收集的信息。`)}`;
      return {
        finalResponse: _stripToolCalls(_stripExecutionPlan(lastResult?.reply || '')) + timeWarning,
        toolCallLog,
        iterations: iteration - 1,
        provider: lastResult?.provider,
        timeLimitReached: true,
        maxElapsedMs,
      };
    }

    // Read-only guardrail: if AI keeps reading without producing output, inject summarize nudge
    if (consecutiveReadOnlyIterations >= MAX_READ_ONLY_ITERATIONS) {
      currentMessage += '\n\n[SYSTEM: You have spent several iterations only reading files. Please synthesize what you have learned and produce your final answer NOW. Do not call more tools.]';
      consecutiveReadOnlyIterations = 0; // reset so it doesn't fire again next iteration
    }

    // 1. Send to AI
    const aiResult = await chat(currentMessage, {
      ...chatOpts,
      _isFollowUp: iteration > 1,
    });

    if (aiResult && aiResult.errorType) {
      const transient = _isTransientLoopErrorType(aiResult.errorType);
      if (transient && transientRecoveryUsed < transientRecoveryMax) {
        const attemptIdx = transientRecoveryUsed;
        transientRecoveryUsed++;
        const delayMs = _recoveryDelayMs(attemptIdx);
        try {
          if (traceAudit) {
            traceAudit.logEvent('agent.loop.resume', {
              reason: aiResult.errorType,
              attempt: transientRecoveryUsed,
              maxAttempts: transientRecoveryMax,
              delayMs,
              iteration,
            }, {
              sessionId: traceSessionId,
              traceId: diagTraceId,
              source: 'tool-loop',
              visibility: 'summary',
            });
          }
        } catch { /* non-critical */ }
        currentMessage += '\n\n[SYSTEM: Previous round failed due transient channel interruption. Resume from completed progress. Do NOT repeat successful tool calls. Continue execution.]';
        await new Promise((r) => setTimeout(r, delayMs));
        continue;
      }
      return {
        finalResponse: String(aiResult.reply || `AI request failed (${aiResult.errorType})`),
        toolCallLog,
        iterations: iteration,
        provider: aiResult.provider,
        tokenUsage: aiResult.tokenUsage,
        effort: aiResult.effort,
        errorType: aiResult.errorType,
        stopped: true,
      };
    }

    if (!aiResult || !aiResult.reply) {
      return {
        finalResponse: aiResult?.reply || 'AI returned no response',
        toolCallLog,
        iterations: iteration,
        provider: aiResult?.provider,
        tokenUsage: aiResult?.tokenUsage,
      };
    }

    lastResult = aiResult;

    // 2. Parse tool calls from AI response
    const toolCalls = _parseToolCalls(aiResult.reply);

    // 2a. Parse execution plan from first response (task decomposition)
    if (iteration === 1 && isComplex && !executionPlan) {
      executionPlan = _parseExecutionPlan(aiResult.reply);
      if (executionPlan && onPlanReady) {
        onPlanReady(executionPlan);
      }
    }

    // Also include legacy [CMD:...] commands as pseudo-tool-calls
    if (aiResult.commands && aiResult.commands.length > 0) {
      for (const cmd of aiResult.commands) {
        toolCalls.push({ name: '_legacy_cmd', params: { command: cmd }, legacy: true });
      }
    }

    // 3. No tool calls → final response
    if (toolCalls.length === 0) {
      const strippedReply = _stripToolCalls(_stripExecutionPlan(aiResult.reply));
      const placeholder = _looksLikeProgressOnlyReply(strippedReply);
      const actionTask = _looksLikeActionRequest(userMessage);

      // If the first reply is only a progress preface ("我来检查...") with no tool
      // calls, nudge once so the loop doesn't appear to "stop after OK".
      if (iteration === 1 && !noToolNudgeUsed && placeholder && actionTask) {
        noToolNudgeUsed = true;
        if (onNoToolCall) {
          onNoToolCall(iteration, strippedReply, { placeholder, actionTask, autoContinued: true });
        }
        currentMessage = _buildNoToolCallNudge(userMessage, strippedReply);
        continue;
      }
      if (onNoToolCall) {
        onNoToolCall(iteration, strippedReply, { placeholder, actionTask, autoContinued: false });
      }
      // Mark remaining plan steps as completed
      if (executionPlan && onPlanProgress) {
        for (let i = currentPlanStep; i < executionPlan.steps.length; i++) {
          if (executionPlan.steps[i].status !== 'completed') {
            onPlanProgress(i, 'completed');
          }
        }
      }
      return {
        finalResponse: strippedReply,
        toolCallLog,
        iterations: iteration,
        provider: aiResult.provider,
        tokenUsage: aiResult.tokenUsage,
        effort: aiResult.effort,
      };
    }

    // 3a. Preflight permission batch check (first iteration, 2+ tools)
    if (iteration === 1 && toolCalls.length >= 2 && process.env.KHY_PREFLIGHT !== 'false' && !preflightApproved) {
      try {
        const { runPreflight } = require('./preflightPermission');
        const pfResult = await runPreflight(toolCalls);
        preflightApproved = pfResult.approved;

        // Set preflight context in toolCalling so individual requestPermission() checks it
        try {
          const toolCalling = require('./toolCalling');
          toolCalling.setPreflightContext(preflightApproved);
        } catch { /* non-critical */ }

        // If all tools denied, stop early
        if (pfResult.denied.size > 0 && pfResult.approved.size === 0) {
          return {
            finalResponse: _stripToolCalls(aiResult.reply) + `\n\n${chalk.yellow('⚠ All tools denied in preflight check, stopping.')}`,
            toolCallLog,
            iterations: iteration,
            provider: aiResult.provider,
            stopped: true,
          };
        }
      } catch { /* preflight not available — continue with individual approval */ }
    }

    // 4. Execute tool calls — parallel for concurrency-safe, sequential for rest
    const toolResults = [];
    const parallelCalls = [];
    const sequentialCalls = [];

    // Classify calls by concurrency safety
    // Static set of known-safe tools as fallback when registry isn't available
    const KNOWN_CONCURRENCY_SAFE = new Set([
      'quote', 'data_fetch', 'search', 'strategy_list', 'web_search',
      'read_file', 'git_status', 'git_diff', 'git_log', 'tool_search',
      // camelCase aliases
      'readFile', 'gitStatus', 'gitDiff', 'gitLog', 'webSearch',
      'dataFetch', 'strategyList', 'toolSearch', 'glob', 'grep', 'ls', 'notebookRead',
    ]);

    let toolRegistry;
    try { toolRegistry = require('../tools'); } catch { toolRegistry = null; }

    for (const call of toolCalls) {
      if (call.legacy) {
        sequentialCalls.push(call);
        continue;
      }
      let isSafe = false;
      // Try dynamic check from registry first
      if (toolRegistry) {
        const regTool = toolRegistry.get(call.name);
        if (regTool && typeof regTool.isConcurrencySafe === 'function') {
          isSafe = regTool.isConcurrencySafe(call.params);
        } else {
          // Fallback to static set
          isSafe = KNOWN_CONCURRENCY_SAFE.has(call.name);
        }
      } else {
        // No registry — use static set
        isSafe = KNOWN_CONCURRENCY_SAFE.has(call.name);
      }
      if (isSafe) {
        parallelCalls.push(call);
      } else {
        sequentialCalls.push(call);
      }
    }

    // Execute parallel calls via toolCalling.executeTool (includes permission system)
    if (parallelCalls.length >= 2) {
      if (onParallelBatch) onParallelBatch(parallelCalls, iteration);
      const toolCalling = require('./toolCalling');
      const parallelPromises = parallelCalls.map(async (call) => {
        totalToolCalls++;
        if (onToolCall) onToolCall(call.name, call.params, iteration);

        // Loop detection: check before executing
        if (loopDetector) {
          const detection = loopDetector.check(call.name, call.params);
          if (detection.stuck && (detection.level === 'circuit_breaker' || detection.level === 'critical')) {
            const result = { success: false, error: `[LoopDetector:${detection.detector}] ${detection.message}`, _loopDetected: true };
            if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
            return { tool: call.name, params: call.params, result, elapsed: 0 };
          }
          if (detection.level === 'warning' && detection.message) {
            // Attach warning to result so it appears in tool result message
            call._loopWarning = detection.message;
          }
        }

        // Dedup: skip tool calls already executed with identical params (success or failure)
        const dedupKey = JSON.stringify({ t: call.name, p: call.params });
        const prevExec = executedCallKeys.get(dedupKey);
        if (prevExec) {
          prevExec.count++;
          const result = { ...prevExec.result, _deduped: true,
            _dedupNote: `This exact call was already executed (attempt #${prevExec.count}). Use the previous result.` };
          if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
          return { tool: call.name, params: call.params, result, elapsed: 0 };
        }

        if (loopDetector) loopDetector.recordCall(call.name, call.params);

        // Shell command safety check (parallel path)
        if ((call.name === 'shell_command' || call.name === 'shellCommand' || call.name === 'bash') && call.params?.command) {
          const safety = analyzeCommand(call.params.command);
          if (!safety.safe) {
            const result = { success: false, error: `[ShellSafety] Command blocked (${safety.maxSeverity}): ${safety.risks.filter(r => r.severity === 'critical').map(r => r.detail).join('; ')}` };
            if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
            return { tool: call.name, params: call.params, result, elapsed: 0 };
          }
          // Exec approval check (multi-level permission)
          if (_execApproval) {
            const approval = _execApproval.checkCommand(call.params.command);
            if (!approval.allowed && !approval.requestId) {
              const result = { success: false, error: `[ExecApproval] ${approval.reason} (risk: ${approval.risk})` };
              if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
              return { tool: call.name, params: call.params, result, elapsed: 0 };
            }
          }
        }

        const start = Date.now();
        const diagSpanId = diagnostics.emitToolCall(call.name, call.params, { traceId: diagTraceId });
        if (traceAudit) {
          try {
            traceAudit.logEvent('agent.tool.call', {
              toolName: call.name,
              params: call.params,
              iteration,
              parallel: true,
            }, {
              sessionId: traceSessionId,
              traceId: diagTraceId,
              source: 'tool-loop',
              visibility: 'summary',
            });
          } catch { /* non-critical */ }
        }
        const writeCtx = _captureWriteFileDiffContext(call);
        let result;
        try {
          result = await toolCalling.executeTool(call.name, call.params, {
            sessionId: traceSessionId,
            traceId: diagTraceId,
          });
        } catch (err) {
          result = { success: false, error: err.message };
        }
        diagnostics.emitToolResult(diagSpanId, result, result?.error ? result.error : null, { traceId: diagTraceId });
        if (traceAudit) {
          try {
            traceAudit.logEvent('agent.tool.result', {
              toolName: call.name,
              success: !!result?.success,
              denied: !!result?.denied,
              error: result?.error || null,
              iteration,
              parallel: true,
            }, {
              sessionId: traceSessionId,
              traceId: diagTraceId,
              source: 'tool-loop',
              visibility: 'summary',
            });
          } catch { /* non-critical */ }
        }
        // Track ALL executed calls for dedup (not just failures)
        executedCallKeys.set(dedupKey, { result, count: 1 });

        if (loopDetector) loopDetector.recordOutcome(call.name, call.params, result);

        if (writeCtx && result && typeof result === 'object') {
          result._khyWriteDiff = writeCtx;
        }
        const elapsed = Date.now() - start;
        if (onToolResult) onToolResult(call.name, call.params, result, iteration, elapsed);
        return { tool: call.name, params: call.params, result, elapsed, _loopWarning: call._loopWarning };
      });

      const settled = await Promise.allSettled(parallelPromises);
      for (const s of settled) {
        if (s.status === 'fulfilled') {
          toolResults.push(s.value);
          toolCallLog.push({ iteration, ...s.value });
          // Plan progress for parallel calls
          if (executionPlan && onPlanProgress) {
            const stepIdx = _matchToolCallToStep(s.value.tool, s.value.params, executionPlan, currentPlanStep);
            if (stepIdx >= 0) {
              const status = (s.value.result && s.value.result.success) ? 'completed' : 'error';
              onPlanProgress(stepIdx, status);
              executionPlan.steps[stepIdx].status = status;
              if (status === 'completed' && stepIdx >= currentPlanStep) currentPlanStep = stepIdx + 1;
            }
          }
          if (s.value.result && s.value.result.denied) {
            return {
              finalResponse: _stripToolCalls(aiResult.reply) + `\n\n${chalk.yellow('⚠ Tool execution denied by user, stopping.')}`,
              toolCallLog, iterations: iteration, provider: aiResult.provider, stopped: true,
            };
          }
        } else {
          const entry = { tool: 'unknown', params: {}, result: { success: false, error: s.reason?.message || 'Promise rejected' }, elapsed: 0 };
          toolResults.push(entry);
          toolCallLog.push({ iteration, ...entry });
        }
      }
    } else {
      // Move single parallel call back to sequential
      sequentialCalls.unshift(...parallelCalls);
    }

    // Execute sequential calls
    for (const call of sequentialCalls) {
      totalToolCalls++;

      // Skip legacy commands — they are handled by the existing REPL pipeline
      if (call.legacy) {
        toolResults.push({
          tool: '_legacy_cmd',
          params: call.params,
          result: { success: true, note: 'Executed via legacy command pipeline' },
        });
        toolCallLog.push({
          iteration,
          tool: '_legacy_cmd',
          params: call.params,
          result: { success: true },
          elapsed: 0,
        });
        continue;
      }

      if (onToolCall) onToolCall(call.name, call.params, iteration);

      // Loop detection: check before executing
      if (loopDetector) {
        const detection = loopDetector.check(call.name, call.params);
        if (detection.stuck && (detection.level === 'circuit_breaker' || detection.level === 'critical')) {
          const result = { success: false, error: `[LoopDetector:${detection.detector}] ${detection.message}`, _loopDetected: true };
          if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
          toolResults.push({ tool: call.name, params: call.params, result, elapsed: 0 });
          toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed: 0 });
          if (detection.level === 'circuit_breaker') break; // stop all sequential calls
          continue;
        }
        // Warning: inject hint and tag the call for result message
        if (detection.level === 'warning' && detection.message) {
          currentMessage += `\n[LoopDetector warning: ${detection.message}]`;
          call._loopWarning = detection.message;
        }
      }

      // Dedup: skip tool calls already executed with identical params (success or failure)
      const dedupKey = JSON.stringify({ t: call.name, p: call.params });
      const prevExec = executedCallKeys.get(dedupKey);
      if (prevExec) {
        prevExec.count++;
        const result = { ...prevExec.result, _deduped: true,
          _dedupNote: `This exact call was already executed (attempt #${prevExec.count}). Use the previous result.` };
        const elapsed = 0;
        if (onToolResult) onToolResult(call.name, call.params, result, iteration, elapsed);
        toolResults.push({ tool: call.name, params: call.params, result, elapsed });
        toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed });
        continue;
      }

      if (loopDetector) loopDetector.recordCall(call.name, call.params);

      // Shell command safety check (sequential path)
      if ((call.name === 'shell_command' || call.name === 'shellCommand' || call.name === 'bash') && call.params?.command) {
        const safety = analyzeCommand(call.params.command);
        if (!safety.safe) {
          const result = { success: false, error: `[ShellSafety] Command blocked (${safety.maxSeverity}): ${safety.risks.filter(r => r.severity === 'critical').map(r => r.detail).join('; ')}` };
          if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
          toolResults.push({ tool: call.name, params: call.params, result, elapsed: 0 });
          toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed: 0 });
          continue;
        }
        // Exec approval check (multi-level permission)
        if (_execApproval) {
          const approval = _execApproval.checkCommand(call.params.command);
          if (!approval.allowed && !approval.requestId) {
            const result = { success: false, error: `[ExecApproval] ${approval.reason} (risk: ${approval.risk})` };
            if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
            toolResults.push({ tool: call.name, params: call.params, result, elapsed: 0 });
            toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed: 0 });
            continue;
          }
        }
      }

      const start = Date.now();
      const seqDiagSpanId = diagnostics.emitToolCall(call.name, call.params, { traceId: diagTraceId });
      if (traceAudit) {
        try {
          traceAudit.logEvent('agent.tool.call', {
            toolName: call.name,
            params: call.params,
            iteration,
            parallel: false,
          }, {
            sessionId: traceSessionId,
            traceId: diagTraceId,
            source: 'tool-loop',
            visibility: 'summary',
          });
        } catch { /* non-critical */ }
      }
      const writeCtx = _captureWriteFileDiffContext(call);
      let result;

      try {
        // Use toolCalling.executeTool which includes permission system
        const toolCalling = require('./toolCalling');
        result = await toolCalling.executeTool(call.name, call.params, {
          sessionId: traceSessionId,
          traceId: diagTraceId,
        });
      } catch (err) {
        // Fallback: try tool registry directly
        try {
          const toolRegistry = require('../tools');
          result = await toolRegistry.execute(call.name, call.params);
        } catch (err2) {
          result = { success: false, error: err2.message || err.message };
        }
      }
      diagnostics.emitToolResult(seqDiagSpanId, result, result?.error ? result.error : null, { traceId: diagTraceId });
      if (traceAudit) {
        try {
          traceAudit.logEvent('agent.tool.result', {
            toolName: call.name,
            success: !!result?.success,
            denied: !!result?.denied,
            error: result?.error || null,
            iteration,
            parallel: false,
          }, {
            sessionId: traceSessionId,
            traceId: diagTraceId,
            source: 'tool-loop',
            visibility: 'summary',
          });
        } catch { /* non-critical */ }
      }

      // Track ALL executed calls for dedup (not just failures)
      executedCallKeys.set(dedupKey, { result, count: 1 });

      if (loopDetector) loopDetector.recordOutcome(call.name, call.params, result);

      const elapsed = Date.now() - start;
      if (writeCtx && result && typeof result === 'object') {
        result._khyWriteDiff = writeCtx;
      }

      // Audit logging (non-critical)
      try {
        const { logToolExecution } = require('./auditLog');
        logToolExecution({
          tool: call.name,
          params: call.params,
          result,
          elapsed,
        });
      } catch { /* audit failure is non-critical */ }

      if (onToolResult) onToolResult(call.name, call.params, result, iteration, elapsed);

      // Update plan progress if we have an execution plan
      if (executionPlan && onPlanProgress) {
        const stepIdx = _matchToolCallToStep(call.name, call.params, executionPlan, currentPlanStep);
        if (stepIdx >= 0) {
          const status = (result && result.success) ? 'completed' : 'error';
          onPlanProgress(stepIdx, status);
          executionPlan.steps[stepIdx].status = status;
          if (status === 'completed' && stepIdx >= currentPlanStep) {
            currentPlanStep = stepIdx + 1;
            // Mark next step as in_progress
            if (currentPlanStep < executionPlan.steps.length) {
              onPlanProgress(currentPlanStep, 'in_progress');
            }
          }
        }
      }

      toolResults.push({ tool: call.name, params: call.params, result, _loopWarning: call._loopWarning });
      toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed });

      // Auto-verify: if write_file failed, automatically read the file to check state
      if (result && !result.success && (call.name === 'write_file' || call.name === 'writeFile') && call.params?.path) {
        try {
          const toolCalling = require('./toolCalling');
          const verifyResult = await toolCalling.executeTool('read_file', { path: call.params.path });
          if (verifyResult && verifyResult.success) {
            toolResults.push({ tool: 'read_file', params: { path: call.params.path }, result: verifyResult, elapsed: 0, _autoVerify: true });
            toolCallLog.push({ iteration, tool: 'read_file', params: { path: call.params.path }, result: verifyResult, elapsed: 0, _autoVerify: true });
          }
        } catch { /* verification is best-effort */ }
      }

      // If user denied the tool, stop the loop
      if (result && result.denied) {
        return {
          finalResponse: _stripToolCalls(aiResult.reply) + `\n\n${chalk.yellow('⚠ Tool execution denied by user, stopping.')}`,
          toolCallLog,
          iterations: iteration,
          provider: aiResult.provider,
          stopped: true,
        };
      }
    }

    // 5. Build follow-up message with tool results
    currentMessage = _buildToolResultMessage(toolResults);

    // 6. Track read-only iterations (AI only reading without acting)
    const READ_ONLY_TOOLS = new Set([
      'read_file', 'readFile',
      'search', 'toolSearch',
      'git_status', 'gitStatus',
      'git_diff', 'gitDiff',
      'git_log',
      'strategy_list', 'strategyList',
      'quote', 'grep', 'glob', 'ls', 'webSearch', 'web_search', 'webFetch', 'notebookRead',
    ]);
    const allReadOnly = toolResults.length > 0 && toolResults.every(tr => {
      // For shell commands, check if the command is read-only (ls, cat, grep, find, etc.)
      if (tr.tool === 'shell_command' || tr.tool === 'shellCommand') {
        const cmd = (tr.params?.command || '').trim().split(/\s+/)[0];
        const readOnlyCmds = new Set(['ls', 'cat', 'head', 'tail', 'grep', 'rg', 'find', 'wc', 'file', 'stat', 'pwd', 'which', 'echo', 'tree', 'du', 'df']);
        return readOnlyCmds.has(cmd);
      }
      return READ_ONLY_TOOLS.has(tr.tool);
    });
    if (allReadOnly) {
      consecutiveReadOnlyIterations++;
    } else {
      consecutiveReadOnlyIterations = 0;
    }

    // Consecutive failure guardrail: if all tool calls in this iteration failed,
    // track consecutive failures and bail out after MAX_CONSECUTIVE_FAILURES.
    // Prevents the AI from endlessly retrying variations of failing commands
    // (e.g. trying to open an app that doesn't exist on this system).
    const allFailed = toolResults.length > 0 && toolResults.every(tr =>
      tr.result && !tr.result.success
    );
    if (allFailed) {
      consecutiveFailureIterations++;
      if (consecutiveFailureIterations >= MAX_CONSECUTIVE_FAILURES) {
        currentMessage = _buildToolResultMessage(toolResults)
          + '\n\n[SYSTEM: All tool calls have failed for ' + consecutiveFailureIterations
          + ' consecutive iterations. STOP retrying. Summarize what went wrong and suggest'
          + ' the user take manual action. Do NOT call any more tools.]';
        // One final AI call to summarize the failure
        const summaryResult = await chat(currentMessage, { ...chatOpts, _isFollowUp: true });
        const summaryText = summaryResult?.reply || 'All tool calls failed repeatedly.';
        return {
          finalResponse: _stripToolCalls(_stripExecutionPlan(summaryText)),
          toolCallLog,
          iterations: iteration,
          provider: summaryResult?.provider || lastResult?.provider,
          tokenUsage: summaryResult?.tokenUsage,
          consecutiveFailureBailout: true,
        };
      }
    } else {
      consecutiveFailureIterations = 0;
    }
  }

  // Exceeded max iterations
  const warning = `\n\n${chalk.yellow(`⚠ Reached maximum tool-use iterations (${effectiveMaxIterations}). Returning last response.`)}`;
  return {
    finalResponse: _stripToolCalls(_stripExecutionPlan(lastResult?.reply || '')) + warning,
    toolCallLog,
    iterations: effectiveMaxIterations,
    provider: lastResult?.provider,
    maxIterationsReached: true,
    maxIterations: effectiveMaxIterations,
    transientRecoveries: transientRecoveryUsed,
  };

  } finally {
    // Always cleanup preflight context, even on error
    try {
      const toolCalling = require('./toolCalling');
      toolCalling.clearPreflightContext();
    } catch { /* non-critical */ }
  }
}

// ── Parsing ────────────────────────────────────────────────────────

/**
 * Parse tool calls from AI response text.
 * Supports two formats:
 *   1. <tool_call>tool_name(param1, param2)</tool_call>
 *   2. <tool_call>{"name": "tool", "params": {...}}</tool_call>
 *
 * @param {string} text - AI response text
 * @returns {Array<{name: string, params: object}>}
 */
function _parseToolCalls(text) {
  if (!text) return [];

  const calls = [];

  // Format 1: JSON-style tool calls
  const jsonMatches = [...text.matchAll(/<tool_call>\s*(\{[\s\S]*?\})\s*<\/tool_call>/g)];
  for (const match of jsonMatches) {
    try {
      const parsed = JSON.parse(match[1]);
      if (parsed.name) {
        const normalized = normalizeToolCall(parsed.name, parsed.params || parsed.arguments || {});
        calls.push({ name: normalized.name, params: normalized.params });
      }
    } catch { /* skip malformed JSON */ }
  }

  // Format 2: function-call-style tool calls
  // e.g. <tool_call>git_status()</tool_call> or <tool_call>shellCommand(command: "dir")</tool_call>
  const funcMatches = [...text.matchAll(/<tool_call>\s*([\w_]+)\s*\(([\s\S]*?)\)\s*<\/tool_call>/g)];
  for (const match of funcMatches) {
    const rawName = match[1];
    const argsStr = match[2].trim();

    const params = _parseFunctionArgs(rawName, argsStr);
    const normalized = normalizeToolCall(rawName, params);
    // Avoid only true duplicates (same tool + same params)
    const sameCallExists = calls.some((c) => (
      c.name === normalized.name
      && JSON.stringify(c.params || {}) === JSON.stringify(normalized.params || {})
    ));
    if (sameCallExists) continue;
    calls.push({ name: normalized.name, params: normalized.params });
  }

  // Format 3: natural-language tool calls from local models
  // e.g. 【调用策略列表：all】 / 【调用回测：symbol=000300 strategy=ma_cross】
  if (calls.length === 0) {
    const naturalSource = _stripExecutionPlan(String(text || ''));
    const naturalCalls = _parseNaturalToolCalls(naturalSource);
    if (naturalCalls.length > 0) {
      return naturalCalls.map((call) => {
        const normalized = normalizeToolCall(call.name, call.params || {});
        return { ...call, name: normalized.name, params: normalized.params };
      });
    }
  }

  return calls;
}

function _parseNaturalToolCalls(text) {
  if (!text) return [];
  const out = [];
  const src = String(text);

  const matches = [...src.matchAll(/【\s*调用\s*([^：:\]】\n]{1,32})\s*(?:[：:]\s*([^】]*?))?\s*】/g)];
  for (const m of matches) {
    // Lenient line-prefix check: allow 【调用】 anywhere in the line.
    // Only skip if the prefix looks like a plan description header
    // (e.g. inside a markdown code block or deeply nested structure).
    const linePrefix = src.slice(0, m.index || 0).split('\n').pop() || '';
    const inCodeBlock = /```/.test(src.slice(Math.max(0, (m.index || 0) - 500), m.index));
    if (inCodeBlock) continue;

    const rawAction = String(m[1] || '').trim();
    const rawArg = String(m[2] || '').trim();
    const toolName = _mapNaturalActionToTool(rawAction);
    if (!toolName) continue;

    // Relaxed tail check: allow most trailing text.
    // Only skip if it looks like a plan-description line with significant
    // natural-language explanation after the tag AND the tool is not an action tool.
    const endIdx = (m.index || 0) + m[0].length;
    const tail = src.slice(endIdx).split('\n')[0].trim();
    const allowTailForActionTool = (toolName === 'open_app' || toolName === 'shell_command'
      || toolName === 'write_file' || toolName === 'read_file' || toolName === 'editFile');
    // Only skip if tail is a long CJK explanation (>15 chars), suggesting a plan description
    if (!allowTailForActionTool && tail.length > 15 && !/^[，,。.!！?？:：;；\s]*$/.test(tail)) continue;

    const params = _buildNaturalToolParams(toolName, rawArg);
    out.push({ name: toolName, params, natural: true, rawAction, rawArg });
  }

  return out;
}

function _mapNaturalActionToTool(action) {
  const raw = String(action || '').trim();
  if (!raw) return null;
  const key = raw.toLowerCase().replace(/\s+/g, '');
  if (NATURAL_ACTION_TO_TOOL[key]) return NATURAL_ACTION_TO_TOOL[key];
  if (NATURAL_ACTION_TO_TOOL[raw]) return NATURAL_ACTION_TO_TOOL[raw];

  // Fuzzy fallback for slight phrasing differences
  if (/(回测|backtest)/i.test(raw)) return 'backtest';
  if (/(k线|kline|日线|周线|月线|分钟线)/i.test(raw)) return 'data_fetch';
  if (/(策略|strategy)/i.test(raw)) return 'strategy_list';
  if (/(行情|报价|价格|quote|price)/i.test(raw)) return 'quote';
  if (/(搜索|search|web)/i.test(raw)) return 'web_search';
  if (/(读取|read)/i.test(raw)) return 'read_file';
  if (/(写入|write)/i.test(raw)) return 'write_file';
  if (/(命令|shell|bash|terminal|cmd)/i.test(raw)) return 'shell_command';
  if (/(打开|启动|运行|应用|程序|浏览器|open|launch|run)/i.test(raw)) return 'open_app';
  if (/(git状态|gitstatus)/i.test(raw)) return 'git_status';
  if (/(git差异|gitdiff)/i.test(raw)) return 'git_diff';
  return null;
}

function _parseLooseKv(argText = '') {
  const out = {};
  const s = String(argText || '').trim();
  if (!s) return out;
  const parts = s.split(/[\s,，]+/).filter(Boolean);
  for (const p of parts) {
    const m = p.match(/^([a-zA-Z_]+)=(.+)$/);
    if (m) out[m[1]] = m[2];
  }
  return out;
}

function _cleanParams(obj = {}) {
  return Object.fromEntries(
    Object.entries(obj).filter(([, v]) => v !== undefined && v !== null && v !== '')
  );
}

function _buildNaturalToolParams(toolName, argText) {
  const raw = String(argText || '').trim();
  const kv = _parseLooseKv(raw);

  if (toolName === 'strategy_list' || toolName === 'git_status') return {};

  if (toolName === 'quote') {
    return _cleanParams({ symbol: kv.symbol || kv.code || raw });
  }

  if (toolName === 'backtest') {
    const firstToken = raw.split(/\s+/).filter(Boolean)[0];
    return _cleanParams({
      symbol: kv.symbol || kv.code || firstToken || '000300',
      strategy: kv.strategy,
      start: kv.start,
      end: kv.end,
      capital: kv.capital !== undefined ? _coerceValue(String(kv.capital)) : undefined,
    });
  }

  if (toolName === 'data_fetch') {
    const parts = raw.split(/\s+/).filter(Boolean);
    return _cleanParams({
      symbol: kv.symbol || kv.code || parts[0] || '000001',
      period: kv.period || parts[1],
    });
  }

  if (toolName === 'search') {
    return _cleanParams({ keyword: kv.keyword || raw });
  }

  if (toolName === 'web_search') {
    return _cleanParams({ query: kv.query || kv.keyword || raw || '最新市场信息' });
  }

  if (toolName === 'read_file') {
    return _cleanParams({ path: raw.replace(/^\/+/, '') });
  }

  if (toolName === 'write_file') {
    const [filePath, ...rest] = raw.split('|');
    return _cleanParams({
      path: (filePath || '').trim(),
      content: rest.join('|').trim(),
    });
  }

  if (toolName === 'shell_command') {
    return _cleanParams({ command: raw });
  }

  if (toolName === 'open_app') {
    return _cleanParams({ name: raw || kv.name || kv.app || kv.application });
  }

  if (toolName === 'git_diff') {
    return raw ? _cleanParams({ file: raw }) : {};
  }

  return {};
}

/**
 * Parse function-call-style arguments into an object.
 * Maps positional args to parameter names based on tool schema.
 *
 * @param {string} toolName
 * @param {string} argsStr - Raw argument string
 * @returns {object}
 */
function _parseFunctionArgs(toolName, argsStr) {
  if (!argsStr) return {};

  // Try JSON parse first (e.g. {"symbol": "sh600519"} or {"command": "dir"})
  try {
    if (argsStr.startsWith('{')) {
      return JSON.parse(argsStr);
    }
  } catch { /* fall through */ }

  // Try key: "value" pairs (AI often uses this format, e.g. command: "dir /b", cwd: "D:\\")
  const kvColonRe = /(\w+)\s*:\s*(?:"([^"]*?)"|'([^']*?)'|([^,)]+))/g;
  let kvMatch;
  const colonParams = {};
  let hasColonPairs = false;
  while ((kvMatch = kvColonRe.exec(argsStr)) !== null) {
    hasColonPairs = true;
    // Quoted values (groups 2/3) stay as strings; unquoted (group 4) get type coercion
    if (kvMatch[2] !== undefined) {
      colonParams[kvMatch[1]] = kvMatch[2];
    } else if (kvMatch[3] !== undefined) {
      colonParams[kvMatch[1]] = kvMatch[3];
    } else {
      colonParams[kvMatch[1]] = _coerceValue((kvMatch[4] ?? '').trim());
    }
  }
  if (hasColonPairs) return colonParams;

  // Try key=value pairs (e.g. symbol=sh600519, staged=true)
  if (argsStr.includes('=')) {
    const params = {};
    const pairs = argsStr.split(',').map(s => s.trim());
    for (const pair of pairs) {
      const [key, ...rest] = pair.split('=');
      const value = rest.join('=').trim().replace(/^["']|["']$/g, '');
      params[key.trim()] = _coerceValue(value);
    }
    return params;
  }

  // Positional argument: map to the first required parameter
  try {
    const toolRegistry = require('../tools');
    const normalized = normalizeToolCall(toolName, {}).name || toolName;
    const tool = toolRegistry.get(normalized);
    if (tool && tool.inputSchema) {
      const firstRequired = Object.entries(tool.inputSchema)
        .find(([, rule]) => rule.required);
      if (firstRequired) {
        return { [firstRequired[0]]: argsStr.replace(/^["']|["']$/g, '') };
      }
    }
  } catch { /* registry not available */ }

  // Fallback: use 'command' as the default param (most common tool)
  return { command: argsStr.replace(/^["']|["']$/g, '') };
}

/**
 * Coerce string values to appropriate JS types.
 */
function _coerceValue(str) {
  if (str === 'true') return true;
  if (str === 'false') return false;
  if (str === 'null') return null;
  const num = Number(str);
  if (!isNaN(num) && str !== '') return num;
  return str;
}

// ── Formatting ─────────────────────────────────────────────────────

/**
 * Build a follow-up message containing tool execution results.
 * Formatted so the AI can understand what happened and continue.
 */
function _buildToolResultMessage(toolResults) {
  const parts = ['[Tool execution results]\n'];

  for (const tr of toolResults) {
    if (tr.tool === '_legacy_cmd') continue;

    // Mark auto-verification reads clearly
    if (tr._autoVerify) {
      parts.push(`Tool: ${tr.tool} (auto-verify after write failure)`);
    } else if (tr.result._deduped) {
      const verb = tr.result.success ? 'succeeded' : 'failed';
      parts.push(`Tool: ${tr.tool} (SKIPPED — identical call already ${verb}. Do NOT call it again with the same parameters. Use the previous result or try a DIFFERENT approach.)`);
    } else if (tr.result._loopDetected) {
      parts.push(`Tool: ${tr.tool} (BLOCKED — loop detected. Change your approach entirely.)`);
    } else {
      parts.push(`Tool: ${tr.tool}`);
    }

    // Append loop detection warning if present
    if (tr._loopWarning) {
      parts.push(`[LoopWarning: ${tr._loopWarning} — try a different tool or approach]`);
    }
    if (tr.result.success) {
      // Include relevant output fields
      const output = tr.result.output || tr.result.content || tr.result.result;
      if (output) {
        const text = typeof output === 'string' ? output : JSON.stringify(output);
        // Context-aware truncation (OpenClaw: SINGLE_TOOL_RESULT_CONTEXT_SHARE=0.5)
        // Cap each tool result at 50% of context budget (char-level approximation)
        const contextBudget = Number(process.env.KHY_CONTEXT_TOKEN_LIMIT) || 65536;
        const singleResultMaxChars = Math.floor(contextBudget * 0.5 * 4); // tokens * 4 chars/token
        // Also apply adaptive floor for local models
        const adapterFloor = (process.env.OLLAMA_MODEL || !process.env.OPENAI_API_KEY) ? 6000 : 15000;
        const maxLen = Math.min(singleResultMaxChars, Math.max(adapterFloor, singleResultMaxChars));
        if (text.length > maxLen) {
          // Newline-aware truncation for cleaner output
          let cutPos = maxLen;
          const lastNewline = text.lastIndexOf('\n', maxLen);
          if (lastNewline > maxLen * 0.5) cutPos = lastNewline;
          const omitted = text.length - cutPos;
          parts.push(`Result: ${text.slice(0, cutPos)}\n... [truncated ${omitted} chars, ${Math.ceil(omitted / 4)} est. tokens]`);
        } else {
          parts.push(`Result: ${text}`);
        }
      } else {
        parts.push('Result: Success');
      }
    } else {
      // Structured error (ToolError) vs legacy string error
      const err = tr.result.error;
      if (err && typeof err === 'object' && err.code) {
        parts.push(`[ERROR:${err.code}] ${err.message}`);
        if (err.hint) parts.push(`Hint: ${err.hint}`);
        parts.push(`Retryable: ${err.retryable ? 'yes' : 'no'}`);
      } else {
        // Safely stringify error objects to avoid "[object Object]" display
        const errStr = (err && typeof err === 'object')
          ? (err.message || JSON.stringify(err))
          : (err || 'Unknown error');
        parts.push(`Error: ${errStr}`);
      }
    }
    parts.push('');
  }

  return parts.join('\n');
}

/**
 * Remove <tool_call> tags from text for display purposes.
 */
function _stripToolCalls(text) {
  if (!text) return '';
  return text
    .replace(/<tool_call>[\s\S]*?<\/tool_call>/g, '')
    .replace(/【\s*调用\s*([^：:\]】\n]{1,32})\s*(?:[：:]\s*([^】]*?))?\s*】/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Remove <execution_plan> tags from text for display purposes.
 */
function _stripExecutionPlan(text) {
  if (!text) return text;
  return text.replace(/<execution_plan>[\s\S]*?<\/execution_plan>/g, '').trim();
}

/**
 * Heuristic: does this look like a "work preface" instead of a real answer?
 */
function _looksLikeProgressOnlyReply(text) {
  if (!text) return false;
  const t = text.replace(/\s+/g, ' ').trim();
  if (!t) return false;
  if (t.length > 220) return false;
  if (/<tool_call>/i.test(t)) return false;
  if (/```/.test(t)) return false;
  if (/\n\s*\d+\.\s+/.test(t)) return false;
  const cn = /^(我来|我先|让我|正在|继续|先去|下面我来|我会先)/;
  const en = /^(let me|i(?:'| a)m (?:going to|now)|continuing to|i will)/i;
  const hasTaskVerb = /(检查|排查|查看|分析|探索|处理|修复|定位|梳理|总结|review|inspect|check|analy[sz]e|investigate)/i.test(t);
  return (cn.test(t) || en.test(t)) && hasTaskVerb;
}

/**
 * Heuristic: does the user request likely require concrete actions/tools?
 */
function _looksLikeActionRequest(text) {
  if (!text) return false;
  return /(继续|检查|排查|修复|实现|修改|review|审查|自我检查|排错|定位|运行|执行|测试|验证|debug|调试|看下|看看)/i.test(text);
}

/**
 * Build a one-shot continuation nudge when AI returns no tool calls.
 */
function _buildNoToolCallNudge(userMessage, previousReply) {
  return [
    '[System follow-up: continue execution]',
    'The previous response looks like a progress note without tool execution.',
    'Continue immediately.',
    'Choose one path only:',
    '1) If actions are needed, output one or more <tool_call>...</tool_call> now.',
    '   You may also use natural format like: 【调用工具名：参数】.',
    '2) If no tool is needed, output the final complete answer now.',
    'Do not output another progress preface.',
    '',
    `[Original user request]\n${userMessage}`,
    '',
    `[Previous response]\n${previousReply}`,
  ].join('\n');
}

/**
 * Capture before/after context for writeFile so UI can render real diffs.
 * @param {{name: string, params: object}} call
 * @returns {{filePath: string, beforeContent: string, afterContent: string}|null}
 */
function _captureWriteFileDiffContext(call) {
  try {
    if (!call || !call.name) return null;
    const toolName = String(call.name).toLowerCase().replace(/[\s_-]/g, '');
    const cwd = process.env.KHYQUANT_CWD || process.cwd();

    // writeFile / write_file / write
    if (toolName === 'writefile' || toolName === 'write') {
      const relPath = call.params?.path || call.params?.file_path || call.params?.filePath;
      const afterContent = call.params?.content;
      if (!relPath || typeof afterContent !== 'string') return null;
      const filePath = path.isAbsolute(relPath) ? relPath : path.resolve(cwd, relPath);
      const beforeContent = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf-8') : '';
      return { filePath, beforeContent, afterContent };
    }

    // editFile / edit_file / edit / multiedit
    if (toolName === 'editfile' || toolName === 'edit' || toolName === 'multiedit') {
      const relPath = call.params?.file_path || call.params?.filePath || call.params?.path;
      if (!relPath) return null;
      const filePath = path.isAbsolute(relPath) ? relPath : path.resolve(cwd, relPath);
      if (!fs.existsSync(filePath)) return null;
      const beforeContent = fs.readFileSync(filePath, 'utf-8');
      const oldStr = call.params?.old_string || call.params?.oldString || '';
      const newStr = call.params?.new_string || call.params?.newString || '';
      if (!oldStr) return null;
      let afterContent;
      if (call.params?.replace_all || call.params?.replaceAll) {
        afterContent = beforeContent.split(oldStr).join(newStr);
      } else {
        const pos = beforeContent.indexOf(oldStr);
        afterContent = pos >= 0
          ? beforeContent.slice(0, pos) + newStr + beforeContent.slice(pos + oldStr.length)
          : beforeContent;
      }
      if (beforeContent === afterContent) return null;
      return { filePath, beforeContent, afterContent };
    }

    return null;
  } catch {
    return null;
  }
}

// ── Task Decomposition ────────────────────────────────────────────

const COMPLEXITY_KEYWORDS = [
  // Chinese
  '然后', '接着', '步骤', '首先', '最后', '之后', '同时', '分别',
  // English
  'then', 'step', 'first', 'next', 'finally', 'after that', 'followed by',
  'and then', 'additionally', 'also need to',
];

/**
 * Determine if a user message represents a complex multi-step task.
 * @param {string} message
 * @returns {boolean}
 */
function _isComplexTask(message) {
  if (!message) return false;
  // Length heuristic
  if (message.length > 200) return true;
  // Keyword heuristic
  const lower = message.toLowerCase();
  return COMPLEXITY_KEYWORDS.some(kw => lower.includes(kw));
}

/**
 * Inject planning instruction into the user message so AI outputs
 * an execution plan alongside tool calls in the same response.
 * @param {string} message
 * @returns {string}
 */
function _injectPlanningPrompt(message) {
  const planInst = [
    '[System: This is a complex task. Before executing, output a numbered execution plan',
    'wrapped in <execution_plan> tags. Format each step as:',
    'N. [tool_hint] Description of what this step does',
    'Then proceed with the first tool call(s).]',
  ].join(' ');
  return `${planInst}\n\n${message}`;
}

/**
 * Parse an execution plan from AI response text.
 * @param {string} text - AI response
 * @returns {{steps: Array<{id: number, description: string, toolHint: string, status: string}>} | null}
 */
function _parseExecutionPlan(text) {
  if (!text) return null;
  const match = text.match(/<execution_plan>([\s\S]*?)<\/execution_plan>/);
  if (!match) return null;

  const planText = match[1].trim();
  const lines = planText.split('\n').filter(l => l.trim());
  const steps = [];

  for (const line of lines) {
    // Match patterns like: "1. [shell_command] Run git status" or "1. Check the file"
    const stepMatch = line.match(/^\s*(\d+)\.\s*(?:\[([^\]]*)\]\s*)?(.+)/);
    if (stepMatch) {
      steps.push({
        id: parseInt(stepMatch[1], 10),
        toolHint: stepMatch[2] || '',
        description: stepMatch[3].trim(),
        status: 'pending',
      });
    }
  }

  return steps.length > 0 ? { steps } : null;
}

/**
 * Match a tool call to the most likely plan step.
 * Uses tool name matching and sequential advancement.
 * @param {string} toolName
 * @param {object} params
 * @param {object} plan - { steps: [...] }
 * @param {number} currentStep - Current plan step index
 * @returns {number} Matched step index, or -1 if no match
 */
function _matchToolCallToStep(toolName, params, plan, currentStep) {
  if (!plan || !plan.steps || plan.steps.length === 0) return -1;

  // Try matching current step first (sequential advancement)
  if (currentStep < plan.steps.length) {
    const step = plan.steps[currentStep];
    if (step.status !== 'completed') {
      // Match by tool hint
      if (step.toolHint && toolName.includes(step.toolHint.replace(/_/g, ''))) {
        return currentStep;
      }
      // Match by description containing tool-related keywords
      const desc = step.description.toLowerCase();
      const normalizedTool = toolName.replace(/_/g, ' ').toLowerCase();
      if (desc.includes(normalizedTool) || desc.includes(toolName)) {
        return currentStep;
      }
      // Default: advance sequentially
      return currentStep;
    }
  }

  // Look ahead for a matching step
  for (let i = currentStep + 1; i < plan.steps.length; i++) {
    const step = plan.steps[i];
    if (step.status === 'completed') continue;
    if (step.toolHint && toolName.includes(step.toolHint.replace(/_/g, ''))) {
      return i;
    }
  }

  return -1;
}

/**
 * Check if the tool-use loop is enabled via feature flag.
 * @returns {boolean}
 */
function isEnabled() {
  return process.env.KHY_TOOL_LOOP !== 'false';
}

// ── Exports ────────────────────────────────────────────────────────

module.exports = {
  runToolUseLoop,
  isEnabled,
  MAX_ITERATIONS,
  MAX_ELAPSED_MS_DEFAULT,
  // Exposed for testing
  _parseToolCalls,
  _stripToolCalls,
  _buildToolResultMessage,
  _isComplexTask,
  _parseExecutionPlan,
  _matchToolCallToStep,
  _resolveMaxIterations,
  _resolveMaxElapsedMs,
  _formatDurationMs,
};
