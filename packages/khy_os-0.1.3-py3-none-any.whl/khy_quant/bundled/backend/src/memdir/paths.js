/**
 * Memory Paths — canonical path resolution for the memory directory.
 *
 * Resolution order:
 *   1. KHY_MEMORY_DIR env var (explicit override)
 *   2. ~/.khy/memory/ (default)
 *
 * For compatibility, also checks ~/.claude/ if ~/.khy/ does not exist
 * (allows users migrating from Claude Code to keep their memories).
 *
 * Path security:
 *   - Rejects relative paths, root paths, and null-byte paths
 *   - All returned paths are normalized with a trailing separator
 */
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');

// ── Constants ──────────────────────────────────────────────────────────

const MEMORY_DIR_NAME = 'memory';
const MEMORY_INDEX_NAME = 'MEMORY.md';
const MAX_ENTRYPOINT_LINES = 200;
const MAX_ENTRYPOINT_BYTES = 25_000;

// ── Path resolution ────────────────────────────────────────────────────

let _cachedMemoryDir = null;

/**
 * Get the memory directory path.
 *
 * @returns {string} Absolute path to the memory directory (with trailing separator)
 */
function getMemoryDir() {
  if (_cachedMemoryDir) return _cachedMemoryDir;

  // 1. Environment override
  if (process.env.KHY_MEMORY_DIR) {
    const validated = _validatePath(process.env.KHY_MEMORY_DIR);
    if (validated) {
      _cachedMemoryDir = validated;
      return _cachedMemoryDir;
    }
  }

  // 2. Default: ~/.khy/memory/
  const khyDir = path.join(os.homedir(), '.khy', MEMORY_DIR_NAME);
  if (fs.existsSync(khyDir) || !_hasClaudeMemory()) {
    _cachedMemoryDir = path.normalize(khyDir) + path.sep;
    return _cachedMemoryDir;
  }

  // 3. Fallback: ~/.claude/ for migration
  const claudeDir = path.join(os.homedir(), '.claude', MEMORY_DIR_NAME);
  if (fs.existsSync(claudeDir)) {
    _cachedMemoryDir = path.normalize(claudeDir) + path.sep;
    return _cachedMemoryDir;
  }

  // Default to ~/.khy/memory/ even if it doesn't exist yet
  _cachedMemoryDir = path.normalize(khyDir) + path.sep;
  return _cachedMemoryDir;
}

/**
 * Get the project-specific memory directory.
 *
 * @param {string} [projectRoot] - Project root path. Defaults to cwd.
 * @returns {string} Project memory directory path
 */
function getProjectMemoryDir(projectRoot) {
  const root = projectRoot || process.cwd();
  const crypto = require('crypto');
  const hash = crypto.createHash('sha256').update(root).digest('hex').slice(0, 16);
  const baseDir = path.join(os.homedir(), '.khy', 'projects', hash, MEMORY_DIR_NAME);
  return path.normalize(baseDir) + path.sep;
}

/**
 * Get the MEMORY.md index file path.
 * @returns {string}
 */
function getMemoryIndexPath() {
  return path.join(getMemoryDir(), MEMORY_INDEX_NAME);
}

/**
 * Get the full path for a memory file.
 * @param {string} filename - File name (e.g., 'user_role.md')
 * @returns {string}
 */
function getMemoryFilePath(filename) {
  // Security: prevent directory traversal
  const sanitized = path.basename(filename);
  return path.join(getMemoryDir(), sanitized);
}

/**
 * Ensure the memory directory exists. Idempotent.
 */
function ensureMemoryDirExists() {
  const dir = getMemoryDir();
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

/**
 * Check if an absolute path is within the memory directory.
 * @param {string} absolutePath
 * @returns {boolean}
 */
function isMemoryPath(absolutePath) {
  const normalized = path.normalize(absolutePath);
  return normalized.startsWith(getMemoryDir());
}

// ── Validation ─────────────────────────────────────────────────────────

/**
 * Validate and normalize a memory path.
 *
 * Rejects:
 *   - Relative paths
 *   - Root or near-root paths (length < 3)
 *   - UNC paths
 *   - Paths containing null bytes
 *
 * @param {string} raw
 * @returns {string|null} Normalized path with trailing separator, or null
 */
function _validatePath(raw) {
  if (!raw || typeof raw !== 'string') return null;

  let candidate = raw;

  // Expand ~/
  if (candidate.startsWith('~/') || candidate.startsWith('~\\')) {
    candidate = path.join(os.homedir(), candidate.slice(2));
  }

  const normalized = path.normalize(candidate).replace(/[/\\]+$/, '');

  if (!path.isAbsolute(normalized)) return null;
  if (normalized.length < 3) return null;
  if (normalized.startsWith('\\\\') || normalized.startsWith('//')) return null;
  if (normalized.includes('\0')) return null;

  return normalized + path.sep;
}

/**
 * Check if ~/.claude/ memory directory exists (for migration compatibility).
 * @returns {boolean}
 */
function _hasClaudeMemory() {
  try {
    const claudeDir = path.join(os.homedir(), '.claude', MEMORY_DIR_NAME);
    return fs.existsSync(claudeDir);
  } catch {
    return false;
  }
}

/**
 * Reset cached paths (for testing).
 */
function _resetCache() {
  _cachedMemoryDir = null;
}

module.exports = {
  MEMORY_DIR_NAME,
  MEMORY_INDEX_NAME,
  MAX_ENTRYPOINT_LINES,
  MAX_ENTRYPOINT_BYTES,
  getMemoryDir,
  getProjectMemoryDir,
  getMemoryIndexPath,
  getMemoryFilePath,
  ensureMemoryDirExists,
  isMemoryPath,
  _resetCache,
};
