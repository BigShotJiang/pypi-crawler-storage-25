/**
 * Memory Directory Operations — load, save, search, and index memories.
 *
 * Core operations:
 *   loadMemoryPrompt()    — Load MEMORY.md and build the system prompt section
 *   saveMemory()          — Write a memory file with proper frontmatter
 *   updateMemoryIndex()   — Update MEMORY.md index entries
 *   searchMemories()      — Simple text search across all memory files
 *   readMemory()          — Read a specific memory file
 *   deleteMemory()        — Delete a memory file and remove its index entry
 *   listMemories()        — List all memory files with their frontmatter
 */
'use strict';

const fs = require('fs');
const path = require('path');
const {
  getMemoryDir,
  getMemoryIndexPath,
  getMemoryFilePath,
  ensureMemoryDirExists,
  MAX_ENTRYPOINT_LINES,
  MAX_ENTRYPOINT_BYTES,
  MEMORY_INDEX_NAME,
} = require('./paths');

// ── Frontmatter parsing ────────────────────────────────────────────────

/**
 * Parse YAML frontmatter from a markdown file.
 *
 * @param {string} content - File content
 * @returns {{ frontmatter: object, body: string }}
 */
function parseFrontmatter(content) {
  const match = content.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
  if (!match) {
    return { frontmatter: {}, body: content };
  }

  const yamlBlock = match[1];
  const body = match[2] || '';
  const frontmatter = {};

  // Simple YAML parser (key: value pairs, one per line)
  for (const line of yamlBlock.split('\n')) {
    const colonIdx = line.indexOf(':');
    if (colonIdx === -1) continue;
    const key = line.slice(0, colonIdx).trim();
    const value = line.slice(colonIdx + 1).trim();
    if (key) frontmatter[key] = value;
  }

  return { frontmatter, body: body.trim() };
}

/**
 * Serialize frontmatter + body into a markdown file.
 *
 * @param {object} frontmatter - { name, description, type }
 * @param {string} body        - Memory content
 * @returns {string}
 */
function serializeFrontmatter(frontmatter, body) {
  const lines = ['---'];
  for (const [key, value] of Object.entries(frontmatter)) {
    if (value !== undefined && value !== null) {
      lines.push(`${key}: ${value}`);
    }
  }
  lines.push('---', '');
  if (body) {
    lines.push(body);
  }
  return lines.join('\n');
}

// ── Entrypoint truncation ──────────────────────────────────────────────

/**
 * Truncate MEMORY.md content to line and byte caps.
 *
 * Appends a warning if truncation occurred, naming which cap fired.
 * Line-truncates first (natural boundary), then byte-truncates at
 * the last newline before the cap.
 *
 * @param {string} raw
 * @returns {{ content: string, lineCount: number, byteCount: number, wasTruncated: boolean }}
 */
function truncateEntrypoint(raw) {
  const trimmed = raw.trim();
  const lines = trimmed.split('\n');
  const lineCount = lines.length;
  const byteCount = trimmed.length;

  const wasLineTruncated = lineCount > MAX_ENTRYPOINT_LINES;
  const wasByteTruncated = byteCount > MAX_ENTRYPOINT_BYTES;

  if (!wasLineTruncated && !wasByteTruncated) {
    return { content: trimmed, lineCount, byteCount, wasTruncated: false };
  }

  let truncated = wasLineTruncated
    ? lines.slice(0, MAX_ENTRYPOINT_LINES).join('\n')
    : trimmed;

  if (truncated.length > MAX_ENTRYPOINT_BYTES) {
    const cutAt = truncated.lastIndexOf('\n', MAX_ENTRYPOINT_BYTES);
    truncated = truncated.slice(0, cutAt > 0 ? cutAt : MAX_ENTRYPOINT_BYTES);
  }

  const reasons = [];
  if (wasLineTruncated) reasons.push(`${lineCount} lines (limit: ${MAX_ENTRYPOINT_LINES})`);
  if (wasByteTruncated) reasons.push(`${_formatBytes(byteCount)} (limit: ${_formatBytes(MAX_ENTRYPOINT_BYTES)})`);

  return {
    content: truncated + `\n\n> WARNING: ${MEMORY_INDEX_NAME} is ${reasons.join(' and ')}. Only part was loaded. Keep index entries to one line under ~150 chars; move detail into topic files.`,
    lineCount,
    byteCount,
    wasTruncated: true,
  };
}

function _formatBytes(bytes) {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
}

// ── Core operations ────────────────────────────────────────────────────

/**
 * Load the memory prompt for inclusion in the system prompt.
 *
 * Reads MEMORY.md, truncates if needed, and builds a prompt section
 * that includes type descriptions, save instructions, and the current index.
 *
 * @returns {string|null} Memory prompt text, or null if memory is disabled
 */
function loadMemoryPrompt() {
  if (process.env.KHY_DISABLE_MEMORY === '1' || process.env.KHY_DISABLE_MEMORY === 'true') {
    return null;
  }

  const memoryDir = getMemoryDir();
  ensureMemoryDirExists();

  const indexPath = getMemoryIndexPath();
  let indexContent = '';

  try {
    if (fs.existsSync(indexPath)) {
      indexContent = fs.readFileSync(indexPath, 'utf-8');
    }
  } catch {
    // No memory file yet
  }

  const lines = _buildMemoryLines(memoryDir);

  if (indexContent.trim()) {
    const truncated = truncateEntrypoint(indexContent);
    lines.push(`## ${MEMORY_INDEX_NAME}`, '', truncated.content);
  } else {
    lines.push(
      `## ${MEMORY_INDEX_NAME}`,
      '',
      `Your ${MEMORY_INDEX_NAME} is currently empty. When you save new memories, they will appear here.`,
    );
  }

  return lines.join('\n');
}

/**
 * Save a memory to a file with proper frontmatter.
 *
 * @param {string} type     - Memory type (user, feedback, project, reference)
 * @param {string} name     - Memory title
 * @param {string} content  - Memory body content
 * @param {object} [options]
 * @param {string} [options.description] - One-line description for relevance
 * @param {string} [options.filename]    - Custom filename (auto-generated if omitted)
 * @returns {{ filename: string, filepath: string }}
 */
function saveMemory(type, name, content, options = {}) {
  const VALID_TYPES = ['user', 'feedback', 'project', 'reference'];
  if (!VALID_TYPES.includes(type)) {
    throw new Error(`Invalid memory type: ${type}. Valid: ${VALID_TYPES.join(', ')}`);
  }

  ensureMemoryDirExists();

  const description = options.description || name;
  const filename = options.filename || _generateFilename(type, name);
  const filepath = getMemoryFilePath(filename);

  const fileContent = serializeFrontmatter(
    { name, description, type },
    content,
  );

  fs.writeFileSync(filepath, fileContent, 'utf-8');

  return { filename, filepath };
}

/**
 * Read a memory file and parse its frontmatter.
 *
 * @param {string} filename - Memory file name
 * @returns {{ frontmatter: object, body: string, exists: boolean }}
 */
function readMemory(filename) {
  const filepath = getMemoryFilePath(filename);

  try {
    if (!fs.existsSync(filepath)) {
      return { frontmatter: {}, body: '', exists: false };
    }
    const content = fs.readFileSync(filepath, 'utf-8');
    const parsed = parseFrontmatter(content);
    return { ...parsed, exists: true };
  } catch {
    return { frontmatter: {}, body: '', exists: false };
  }
}

/**
 * Delete a memory file and optionally remove its index entry.
 *
 * @param {string} filename
 * @param {object} [options]
 * @param {boolean} [options.updateIndex=true] - Remove entry from MEMORY.md
 * @returns {boolean} true if the file existed and was deleted
 */
function deleteMemory(filename, options = {}) {
  const filepath = getMemoryFilePath(filename);
  const updateIndex = options.updateIndex !== false;

  try {
    if (!fs.existsSync(filepath)) return false;
    fs.unlinkSync(filepath);

    if (updateIndex) {
      _removeFromIndex(filename);
    }

    return true;
  } catch {
    return false;
  }
}

/**
 * Update the MEMORY.md index file.
 *
 * @param {Array<{title: string, filename: string, description: string}>} entries
 *   New entries to add/update. Existing entries with the same filename are replaced.
 */
function updateMemoryIndex(entries) {
  ensureMemoryDirExists();

  const indexPath = getMemoryIndexPath();
  let existingContent = '';

  try {
    if (fs.existsSync(indexPath)) {
      existingContent = fs.readFileSync(indexPath, 'utf-8');
    }
  } catch {
    existingContent = '';
  }

  // Parse existing entries
  const existingLines = existingContent.split('\n').filter(l => l.trim());
  const existingMap = new Map();

  for (const line of existingLines) {
    const match = line.match(/^\s*-\s*\[([^\]]+)\]\(([^)]+)\)/);
    if (match) {
      existingMap.set(match[2], line);
    } else if (line.trim()) {
      // Preserve non-link lines (headers, etc.)
      existingMap.set(`__raw_${existingMap.size}`, line);
    }
  }

  // Add/update entries
  for (const entry of entries) {
    const line = `- [${entry.title}](${entry.filename}) — ${entry.description}`;
    existingMap.set(entry.filename, line);
  }

  // Write back
  const newContent = Array.from(existingMap.values()).join('\n') + '\n';
  fs.writeFileSync(indexPath, newContent, 'utf-8');
}

/**
 * Search across all memory files for a query string.
 *
 * Performs a case-insensitive text search through both frontmatter
 * and body content of all .md files in the memory directory.
 *
 * @param {string} query - Search string
 * @returns {Array<{filename: string, frontmatter: object, matches: string[]}>}
 */
function searchMemories(query) {
  if (!query || typeof query !== 'string') return [];

  const memoryDir = getMemoryDir();
  const results = [];
  const lowerQuery = query.toLowerCase();

  try {
    if (!fs.existsSync(memoryDir)) return [];

    const files = fs.readdirSync(memoryDir)
      .filter(f => f.endsWith('.md') && f !== MEMORY_INDEX_NAME);

    for (const filename of files) {
      try {
        const filepath = path.join(memoryDir, filename);
        const content = fs.readFileSync(filepath, 'utf-8');
        const lowerContent = content.toLowerCase();

        if (!lowerContent.includes(lowerQuery)) continue;

        const parsed = parseFrontmatter(content);
        const lines = content.split('\n');
        const matches = [];

        for (const line of lines) {
          if (line.toLowerCase().includes(lowerQuery)) {
            matches.push(line.trim());
          }
        }

        results.push({
          filename,
          frontmatter: parsed.frontmatter,
          matches,
        });
      } catch {
        // Skip unreadable files
      }
    }
  } catch {
    // Directory unreadable
  }

  return results;
}

/**
 * List all memory files with their frontmatter metadata.
 *
 * @returns {Array<{filename: string, frontmatter: object, size: number, modifiedAt: Date}>}
 */
function listMemories() {
  const memoryDir = getMemoryDir();
  const results = [];

  try {
    if (!fs.existsSync(memoryDir)) return [];

    const files = fs.readdirSync(memoryDir)
      .filter(f => f.endsWith('.md') && f !== MEMORY_INDEX_NAME);

    for (const filename of files) {
      try {
        const filepath = path.join(memoryDir, filename);
        const stat = fs.statSync(filepath);
        const content = fs.readFileSync(filepath, 'utf-8');
        const parsed = parseFrontmatter(content);

        results.push({
          filename,
          frontmatter: parsed.frontmatter,
          size: stat.size,
          modifiedAt: stat.mtime,
        });
      } catch {
        // Skip unreadable files
      }
    }
  } catch {
    // Directory unreadable
  }

  return results.sort((a, b) => b.modifiedAt - a.modifiedAt);
}

// ── Internal helpers ───────────────────────────────────────────────────

/**
 * Build the memory prompt lines (without MEMORY.md content).
 * @param {string} memoryDir
 * @returns {string[]}
 */
function _buildMemoryLines(memoryDir) {
  return [
    '# Memory System',
    '',
    `You have a persistent, file-based memory system at \`${memoryDir}\`.`,
    'This directory already exists — write to it directly (do not run mkdir or check for its existence).',
    '',
    'Build up this memory over time so that future conversations have a complete picture of who the user is,',
    'how they want to collaborate, what behaviors to avoid or repeat, and the context behind the work.',
    '',
    'If the user explicitly asks you to remember something, save it immediately.',
    'If they ask you to forget something, find and remove the relevant entry.',
    '',
    '## Types of memory',
    '',
    '<types>',
    '<type>',
    '    <name>user</name>',
    '    <description>Information about the user\'s role, goals, responsibilities, and knowledge. Tailor future behavior to their preferences and perspective.</description>',
    '    <when_to_save>When you learn details about the user\'s role, preferences, responsibilities, or knowledge.</when_to_save>',
    '</type>',
    '<type>',
    '    <name>feedback</name>',
    '    <description>Guidance about how to approach work — corrections AND confirmations. Record from failure AND success to remain coherent.</description>',
    '    <when_to_save>When the user corrects your approach OR confirms a non-obvious approach worked.</when_to_save>',
    '</type>',
    '<type>',
    '    <name>project</name>',
    '    <description>Non-derivable context about ongoing work, goals, deadlines, and decisions. Not code patterns — those are in the codebase.</description>',
    '    <when_to_save>When you learn who is doing what, why, or by when. Convert relative dates to absolute dates.</when_to_save>',
    '</type>',
    '<type>',
    '    <name>reference</name>',
    '    <description>Pointers to external systems (dashboards, ticket trackers, Slack channels, documentation).</description>',
    '    <when_to_save>When you learn about resources in external systems and their purpose.</when_to_save>',
    '</type>',
    '</types>',
    '',
    '## What NOT to save in memory',
    '',
    '- Code patterns, architecture, file paths — derivable from the codebase.',
    '- Git history — git log / git blame are authoritative.',
    '- Debugging solutions — the fix is in the code.',
    '- Anything in project instruction files (CLAUDE.md / khy.md).',
    '- Ephemeral task details or temporary state.',
    '',
    '## How to save memories',
    '',
    'Saving a memory is a two-step process:',
    '',
    '**Step 1** — Write the memory to its own file with frontmatter:',
    '',
    '```markdown',
    '---',
    'name: {{memory name}}',
    'description: {{one-line description}}',
    'type: {{user, feedback, project, reference}}',
    '---',
    '',
    '{{memory content}}',
    '```',
    '',
    `**Step 2** — Add a pointer in \`${MEMORY_INDEX_NAME}\`. Each entry should be one line, under ~150 chars:`,
    '`- [Title](file.md) — one-line hook`',
    '',
    `\`${MEMORY_INDEX_NAME}\` is always loaded into context — lines after ${MAX_ENTRYPOINT_LINES} will be truncated.`,
    '',
    '## When to access memories',
    '',
    '- When memories seem relevant, or the user references prior-conversation work.',
    '- You MUST access memory when the user explicitly asks.',
    '- Memory records can become stale — verify against current state before acting on them.',
    '',
    '## Before recommending from memory',
    '',
    'A memory that names a specific file, function, or flag is a claim about what existed *when the memory was written*.',
    'Before recommending it: check the file exists, grep for the function, verify the flag.',
    '',
  ];
}

/**
 * Generate a filename from type and name.
 * @param {string} type
 * @param {string} name
 * @returns {string}
 */
function _generateFilename(type, name) {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9_\-\s]/g, '')
    .replace(/\s+/g, '_')
    .slice(0, 50);
  return `${type}_${slug}.md`;
}

/**
 * Remove a filename's entry from MEMORY.md.
 * @param {string} filename
 */
function _removeFromIndex(filename) {
  const indexPath = getMemoryIndexPath();
  try {
    if (!fs.existsSync(indexPath)) return;
    const content = fs.readFileSync(indexPath, 'utf-8');
    const lines = content.split('\n');
    const filtered = lines.filter(line => !line.includes(`(${filename})`));
    if (filtered.length !== lines.length) {
      fs.writeFileSync(indexPath, filtered.join('\n'), 'utf-8');
    }
  } catch {
    // Best effort
  }
}

module.exports = {
  loadMemoryPrompt,
  saveMemory,
  readMemory,
  deleteMemory,
  updateMemoryIndex,
  searchMemories,
  listMemories,
  parseFrontmatter,
  serializeFrontmatter,
  truncateEntrypoint,
};
