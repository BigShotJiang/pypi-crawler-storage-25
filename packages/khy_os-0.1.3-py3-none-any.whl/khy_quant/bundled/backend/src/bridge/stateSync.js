/**
 * State Sync — synchronize state between local CLI and remote bridge clients.
 *
 * Captures snapshots of current session state and computes minimal diffs
 * for efficient network transmission.
 */
'use strict';

// ── State Capture ──────────────────────────────────────────────────

/**
 * Capture current session state for bridge sync.
 * @returns {BridgeState}
 */
function captureState() {
  const state = {
    timestamp: Date.now(),
    cwd: process.cwd(),
    platform: process.platform,
    nodeVersion: process.version,
    conversation: [],
    pendingPermissions: [],
    activeToolCalls: [],
  };

  // Try to capture AI conversation state
  try {
    const ai = require('../cli/ai');
    if (ai.getHistory) {
      const history = ai.getHistory();
      state.conversation = (history || []).slice(-20).map(m => ({
        role: m.role,
        content: typeof m.content === 'string' ? m.content.slice(0, 500) : '[complex]',
        timestamp: m.timestamp || 0,
      }));
    }
  } catch { /* AI not available */ }

  return state;
}

/**
 * Apply a state update from remote.
 * @param {Partial<BridgeState>} update
 */
function applyStateUpdate(update) {
  // Currently only supports CWD changes from remote
  if (update.cwd && update.cwd !== process.cwd()) {
    try {
      process.chdir(update.cwd);
    } catch { /* invalid directory */ }
  }
}

/**
 * Compute minimal diff between two states.
 * @param {BridgeState} prev
 * @param {BridgeState} curr
 * @returns {object} Only changed fields
 */
function createStateDiff(prev, curr) {
  const diff = {};

  if (prev.cwd !== curr.cwd) diff.cwd = curr.cwd;

  // New conversation messages
  if (curr.conversation.length !== prev.conversation.length) {
    diff.newMessages = curr.conversation.slice(prev.conversation.length);
  }

  // Permission changes
  if (JSON.stringify(prev.pendingPermissions) !== JSON.stringify(curr.pendingPermissions)) {
    diff.pendingPermissions = curr.pendingPermissions;
  }

  // Tool call changes
  if (JSON.stringify(prev.activeToolCalls) !== JSON.stringify(curr.activeToolCalls)) {
    diff.activeToolCalls = curr.activeToolCalls;
  }

  diff.timestamp = curr.timestamp;
  return diff;
}

module.exports = { captureState, applyStateUpdate, createStateDiff };
