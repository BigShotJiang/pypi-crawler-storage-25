/**
 * Bridge Server — WebSocket server for remote CLI control.
 *
 * Allows remote clients (web browser, mobile, another CLI) to:
 * - Send commands/messages to the local REPL
 * - Approve/deny permission requests
 * - View real-time output
 *
 * Ported concept from Claude Code's bridge/ system.
 */
'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DEFAULT_PORT = 9222;
const TOKEN_EXPIRY_MS = 30 * 60 * 1000; // 30 minutes

let _wss = null;
let _clients = new Map(); // id → { ws, remoteAddress, connectedAt, authenticated }
let _token = null;
let _tokenCreatedAt = 0;

let _chalk;
function chalk() {
  if (_chalk) return _chalk;
  const m = require('chalk');
  _chalk = m.default || m;
  return _chalk;
}

// ── Server Lifecycle ───────────────────────────────────────────────

/**
 * Start the WebSocket bridge server.
 * @param {number} [port]
 * @returns {Promise<{port: number}>}
 */
async function startBridgeServer(port) {
  // Feature gate
  try {
    const { isEnabled } = require('../services/featureFlags');
    if (!isEnabled('bridge')) {
      console.log(chalk().gray('Bridge feature is disabled. Set KHY_FEATURE_BRIDGE=true to enable.'));
      return { port: 0 };
    }
  } catch { /* no feature flags */ }

  if (_wss) {
    console.log(chalk().yellow('Bridge server is already running.'));
    return { port: _wss.options.port };
  }

  // Ensure ws is available
  let WebSocketServer;
  try {
    const ws = require('ws');
    WebSocketServer = ws.WebSocketServer || ws.Server;
  } catch {
    console.log(chalk().red('WebSocket dependency (ws) not installed. Run: npm install ws'));
    return { port: 0 };
  }

  const serverPort = port || parseInt(process.env.BRIDGE_PORT) || DEFAULT_PORT;

  return new Promise((resolve, reject) => {
    _wss = new WebSocketServer({ port: serverPort });

    _wss.on('listening', () => {
      const actualPort = _wss.address().port;
      _token = generateToken();
      console.log(chalk().green(`\n  Bridge server started on port ${actualPort}`));
      console.log(chalk().cyan(`  Connection token: ${_token}`));
      console.log(chalk().gray('  Token expires in 30 minutes.\n'));
      resolve({ port: actualPort });
    });

    _wss.on('connection', (ws, req) => {
      const clientId = 'c-' + crypto.randomBytes(3).toString('hex');
      const remoteAddr = req.socket.remoteAddress || 'unknown';

      _clients.set(clientId, {
        ws,
        remoteAddress: remoteAddr,
        connectedAt: Date.now(),
        authenticated: false,
      });

      ws.on('message', (data) => {
        _handleMessage(clientId, data);
      });

      ws.on('close', () => {
        _clients.delete(clientId);
      });

      ws.on('error', () => {
        _clients.delete(clientId);
      });

      // Send auth challenge
      _send(ws, { type: 'auth_required', clientId });
    });

    _wss.on('error', (err) => {
      console.log(chalk().red(`Bridge server error: ${err.message}`));
      reject(err);
    });
  });
}

/**
 * Stop the bridge server.
 */
async function stopBridgeServer() {
  if (!_wss) {
    console.log(chalk().gray('No bridge server running.'));
    return;
  }

  // Close all client connections
  for (const [id, client] of _clients) {
    try { client.ws.close(1000, 'Server shutting down'); } catch { /* ignore */ }
  }
  _clients.clear();

  return new Promise((resolve) => {
    _wss.close(() => {
      _wss = null;
      _token = null;
      console.log(chalk().yellow('Bridge server stopped.'));
      resolve();
    });
  });
}

// ── Message Handling ───────────────────────────────────────────────

function _handleMessage(clientId, rawData) {
  const client = _clients.get(clientId);
  if (!client) return;

  let msg;
  try { msg = JSON.parse(rawData.toString()); } catch { return; }

  switch (msg.type) {
    case 'auth': {
      if (_validateToken(msg.token)) {
        client.authenticated = true;
        _send(client.ws, { type: 'auth_ok', clientId });
      } else {
        _send(client.ws, { type: 'auth_failed', reason: 'Invalid or expired token' });
        client.ws.close(4001, 'Authentication failed');
        _clients.delete(clientId);
      }
      break;
    }

    case 'input': {
      if (!client.authenticated) return;
      // Forward input to REPL (emit event for REPL to pick up)
      _emitBridgeEvent('input', { text: msg.text, clientId });
      break;
    }

    case 'approve': {
      if (!client.authenticated) return;
      _emitBridgeEvent('approve', { requestId: msg.requestId, clientId });
      break;
    }

    case 'deny': {
      if (!client.authenticated) return;
      _emitBridgeEvent('deny', { requestId: msg.requestId, clientId });
      break;
    }

    case 'ping': {
      _send(client.ws, { type: 'pong', timestamp: Date.now() });
      break;
    }
  }
}

// ── Broadcasting ───────────────────────────────────────────────────

/**
 * Broadcast output to all authenticated clients.
 * @param {object} data - { type: 'stdout'|'ai_response'|'tool_call'|'error', content: string }
 */
function broadcastOutput(data) {
  if (!_wss) return;

  const msg = JSON.stringify({ ...data, timestamp: Date.now() });
  for (const [, client] of _clients) {
    if (client.authenticated && client.ws.readyState === 1) { // OPEN
      try { client.ws.send(msg); } catch { /* ignore */ }
    }
  }
}

// ── Token Management ───────────────────────────────────────────────

/**
 * Generate a new connection token.
 * @returns {string}
 */
function generateToken() {
  _token = crypto.randomBytes(16).toString('hex');
  _tokenCreatedAt = Date.now();
  return _token;
}

function _validateToken(token) {
  if (!_token || !token) return false;
  if (Date.now() - _tokenCreatedAt > TOKEN_EXPIRY_MS) return false;
  return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(_token));
}

// ── Event Emitter ──────────────────────────────────────────────────

const _eventListeners = [];

function _emitBridgeEvent(event, data) {
  for (const listener of _eventListeners) {
    try { listener(event, data); } catch { /* ignore */ }
  }
}

/**
 * Register a bridge event listener.
 * @param {function} listener - (event, data) => void
 * @returns {function} Unsubscribe function
 */
function onBridgeEvent(listener) {
  _eventListeners.push(listener);
  return () => {
    const idx = _eventListeners.indexOf(listener);
    if (idx >= 0) _eventListeners.splice(idx, 1);
  };
}

// ── Status Display ─────────────────────────────────────────────────

function printStatus() {
  const c = chalk();
  if (!_wss) {
    console.log(c.gray('\n  Bridge server is not running.\n'));
    return;
  }

  const port = _wss.address()?.port || '?';
  const clientCount = [..._clients.values()].filter(cl => cl.authenticated).length;

  console.log(c.bold('\n  Bridge Status'));
  console.log(c.gray('  ' + '\u2500'.repeat(35)));
  console.log(`  Server:  ${c.green(`ws://localhost:${port}`)}`);
  console.log(`  Clients: ${c.cyan(clientCount)} connected`);
  console.log(`  Token:   ${_token ? c.cyan(_token.slice(0, 8) + '...') : c.gray('none')}`);
  console.log('');
}

function printToken() {
  const c = chalk();
  if (!_wss || !_token) {
    console.log(c.gray('\n  No active bridge server. Run: bridge start\n'));
    return;
  }
  const remaining = Math.max(0, TOKEN_EXPIRY_MS - (Date.now() - _tokenCreatedAt));
  console.log(c.bold('\n  Bridge Token'));
  console.log(c.cyan(`  ${_token}`));
  console.log(c.gray(`  Expires in ${Math.round(remaining / 60000)} minutes\n`));
}

// ── Helpers ────────────────────────────────────────────────────────

function _send(ws, data) {
  try { ws.send(JSON.stringify(data)); } catch { /* ignore */ }
}

function getConnectedClients() {
  return [..._clients.entries()]
    .filter(([, c]) => c.authenticated)
    .map(([id, c]) => ({
      id,
      remoteAddress: c.remoteAddress,
      connectedAt: c.connectedAt,
    }));
}

module.exports = {
  startBridgeServer,
  stopBridgeServer,
  broadcastOutput,
  onBridgeEvent,
  generateToken,
  getConnectedClients,
  printStatus,
  printToken,
};
