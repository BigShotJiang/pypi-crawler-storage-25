/**
 * Command Alias Registry
 *
 * Maps pinyin, English abbreviations, and Chinese to canonical commands.
 * Users type whatever feels natural; the router normalizes via this table.
 *
 *   huice sh600519         → backtest sh600519
 *   hq 茅台                → quote 茅台
 *   xz sh000001            → data fetch sh000001
 *   cl                     → strategy list
 */

// { alias → { command, [subCommand], [defaultArgs], [defaultPositionals] } }
const ALIAS_MAP = {
  // ── 行情 ──
  hq:        { command: 'quote' },
  hangqing:  { command: 'quote' },
  '行情':    { command: 'quote' },
  price:     { command: 'quote' },
  p:         { command: 'quote' },

  // ── 回测 ──
  bt:        { command: 'backtest' },
  huice:     { command: 'backtest' },
  '回测':    { command: 'backtest' },

  // ── 策略 ──
  cl:        { command: 'strategy', subCommand: 'list' },
  celue:     { command: 'strategy', subCommand: 'list' },
  '策略':    { command: 'strategy', subCommand: 'list' },

  // ── 数据下载 ──
  xz:        { command: 'data', subCommand: 'fetch' },
  xiazai:    { command: 'data', subCommand: 'fetch' },
  download:  { command: 'data', subCommand: 'fetch' },
  dl:        { command: 'data', subCommand: 'fetch' },
  '下载':    { command: 'data', subCommand: 'fetch' },

  // ── 数据列表 ──
  sj:        { command: 'data', subCommand: 'list' },
  shuju:     { command: 'data', subCommand: 'list' },
  '数据':    { command: 'data', subCommand: 'list' },

  // ── 持仓 ──
  cc:        { command: 'position' },
  chicang:   { command: 'position' },
  '持仓':    { command: 'position' },
  pos:       { command: 'position' },

  // ── 下单 ──
  xd:        { command: 'order' },
  xiadan:    { command: 'order' },
  '下单':    { command: 'order' },
  buy:       { command: 'order', defaultArgs: { side: 'buy' } },
  sell:      { command: 'order', defaultArgs: { side: 'sell' } },
  '买入':    { command: 'order', defaultArgs: { side: 'buy' } },
  '卖出':    { command: 'order', defaultArgs: { side: 'sell' } },
  mai:       { command: 'order', defaultArgs: { side: 'buy' } },
  mairu:     { command: 'order', defaultArgs: { side: 'buy' } },
  maichu:    { command: 'order', defaultArgs: { side: 'sell' } },

  // ── 账户 ──
  zh:        { command: 'account' },
  zhanghu:   { command: 'account' },
  '账户':    { command: 'account' },
  acc:       { command: 'account' },

  // ── 分析 (AI) ──
  fx:        { command: 'analyze' },
  fenxi:     { command: 'analyze' },
  '分析':    { command: 'analyze' },
  analyze:   { command: 'analyze' },

  // ── 服务 ──
  fw:        { command: 'server' },
  fuwu:      { command: 'server' },
  '服务':    { command: 'server' },
  '启动':    { command: 'server', subCommand: 'start' },

  // ── Linux 能力 ──
  linux:     { command: 'linux' },
  shell:     { command: 'linux' },
  lx:        { command: 'linux' },
  '终端':    { command: 'linux' },
  '网络':    { command: 'linux', subCommand: 'net' },
  '联网':    { command: 'linux', subCommand: 'net' },
  '系统状态': { command: 'linux', subCommand: 'status' },

  // ── 数据库 ──
  sjk:       { command: 'db' },
  shujuku:   { command: 'db' },
  '数据库':  { command: 'db' },

  // ── 本地模型 (Ollama) ──
  '模型':     { command: 'models', subCommand: 'list' },
  '本地模型': { command: 'models', subCommand: 'list' },
  moxing:    { command: 'models', subCommand: 'list' },
  '导入模型': { command: 'models', subCommand: 'import' },
  importmodel: { command: 'models', subCommand: 'import' },

  // ── 缓存 ──
  hc:        { command: 'cache', subCommand: 'clear' },
  huancun:   { command: 'cache', subCommand: 'clear' },
  '清缓存':  { command: 'cache', subCommand: 'clear' },

  // ── 菜单 ──
  cd:        { command: 'menu' },
  caidan:    { command: 'menu' },
  '菜单':    { command: 'menu' },

  // ── 帮助 ──
  bz:        { command: 'help' },
  bangzhu:   { command: 'help' },
  '帮助':    { command: 'help' },
  h:         { command: 'help' },

  // ── 退出 ──
  q:         { command: 'exit' },
  tuichu:    { command: 'exit' },
  '退出':    { command: 'exit' },

  // ── 清屏 ──
  cls:       { command: 'clear' },
  qp:        { command: 'clear' },
  qingping:  { command: 'clear' },
  '清屏':    { command: 'clear' },

  // ── 监控 ──
  jk:        { command: 'watch' },
  jiankong:  { command: 'watch' },
  '监控':    { command: 'watch' },
  watch:     { command: 'watch' },

  // ── 排行 ──
  ph:        { command: 'rank' },
  paihang:   { command: 'rank' },
  '排行':    { command: 'rank' },
  rank:      { command: 'rank' },
  top:       { command: 'rank' },

  // ── 搜索 ──
  ss:        { command: 'search' },
  sousuo:    { command: 'search' },
  '搜索':    { command: 'search' },
  find:      { command: 'search' },
  websearch: { command: 'search', subCommand: 'web' },
  '联网搜索': { command: 'search', subCommand: 'web' },

  // ── 网关 ──
  wg:        { command: 'gateway' },
  wangguan:  { command: 'gateway' },
  '网关':    { command: 'gateway' },
  guanli:    { command: 'gateway', subCommand: 'manage' },
  aiguanli:  { command: 'gateway', subCommand: 'manage' },
  'ai管理':  { command: 'gateway', subCommand: 'manage' },
  '管理页':  { command: 'gateway', subCommand: 'manage' },
  relay:     { command: 'gateway', subCommand: 'relay' },
  '中转':    { command: 'gateway', subCommand: 'relay' },
  zhongzhuan: { command: 'gateway', subCommand: 'relay' },
  '模型发现': { command: 'gateway', subCommand: 'discover-models' },
  modelscan: { command: 'gateway', subCommand: 'discover-models' },
  discovermodels: { command: 'gateway', subCommand: 'discover-models' },

  // ── Cursor2API 集成 ──
  c2a:         { command: 'proxy', subCommand: 'cursor2api' },
  cursor2api:  { command: 'proxy', subCommand: 'cursor2api' },
  traeswitch:  { command: 'proxy', subCommand: 'trae-switch' },
  traeproxy:   { command: 'proxy', subCommand: 'trae-switch' },
  'trae切换':  { command: 'proxy', subCommand: 'trae-switch' },
  'trae代理':  { command: 'proxy', subCommand: 'trae-switch' },
  nir:         { command: 'pool', subCommand: 'import', defaultPositionals: ['nirvana'] },
  nrv:         { command: 'pool', subCommand: 'import', defaultPositionals: ['nirvana'] },
  antigravity: { command: 'trae' },
  nirvana:     { command: 'trae' },
  fanzhongli:  { command: 'trae' },
  'api提取':   { command: 'proxy', subCommand: 'cursor2api' },
  '提取api':   { command: 'proxy', subCommand: 'cursor2api' },
  '代理帮助':   { command: 'proxy', subCommand: 'help' },
  '代理一键':   { command: 'proxy', subCommand: 'quickstart' },
  '一键代理':   { command: 'proxy', subCommand: 'quickstart' },
  '客户token': { command: 'proxy', subCommand: 'client' },
  '客户令牌':  { command: 'proxy', subCommand: 'client' },

  // ── 初始化 ──
  '初始化':  { command: 'init' },
  chushihua: { command: 'init' },
  setup:     { command: 'init' },
  anzhuang:  { command: 'init' },
  '安装':    { command: 'init' },

  // ── 诊断 ──
  '诊断':    { command: 'doctor' },
  zhenduan:  { command: 'doctor' },
  check:     { command: 'doctor' },
  jiankang:  { command: 'doctor' },
  '健康':    { command: 'doctor' },

  // ── 发布 ──
  fabu:      { command: 'publish' },
  '发布':    { command: 'publish' },
  '发布检查': { command: 'publish', subCommand: 'check' },
  '构建发布': { command: 'publish', subCommand: 'build' },
  testpypi:  { command: 'publish', subCommand: 'testpypi' },

  // ── 稳定性工作流测试 ──
  '稳定测试': { command: 'verify', subCommand: 'workflow' },
  '工作流测试': { command: 'verify', subCommand: 'workflow' },
  liantongceshi: { command: 'verify', subCommand: 'workflow' },
  workflowtest: { command: 'verify', subCommand: 'workflow' },

  // ── 恢复上下文 ──
  huifu:     { command: 'history', subCommand: 'resume' },
  '恢复':    { command: 'history', subCommand: 'resume' },
  resume:    { command: 'history', subCommand: 'resume' },
  '上下文':  { command: 'history', subCommand: 'resume' },

  // ── 费用 ──
  feiyong:   { command: 'cost' },
  '费用':    { command: 'cost' },

  // ── 训练 ──
  xunlian:   { command: 'train' },
  '训练':    { command: 'train' },

  // ── 历史 ──
  lishi:     { command: 'history' },
  '历史':    { command: 'history', subCommand: 'list' },

  // ── 更新 ──
  gengxin:   { command: 'update' },
  '更新':    { command: 'update' },
  upgrade:   { command: 'update' },

  // ── 成长 ──
  cz:        { command: 'growth' },
  chengzhang: { command: 'growth' },
  '成长':    { command: 'growth' },
  '成长导出': { command: 'growth', subCommand: 'export' },
  '成长导入': { command: 'growth', subCommand: 'import' },

  // ── 智能体 ──
  znt:       { command: 'agent' },
  zhinengti: { command: 'agent' },
  '智能体':  { command: 'agent' },
  '智能体状态': { command: 'agent', subCommand: 'status' },

  // ── 提示词 ──
  tsc:       { command: 'prompt' },
  tishici:   { command: 'prompt' },
  '提示词':  { command: 'prompt' },
  '保存提示词': { command: 'prompt', subCommand: 'save' },

  // ── 语音 ──
  yuyin:     { command: 'voice' },
  '语音':    { command: 'voice' },

  // ── 技能 ──
  jineng:    { command: 'skill' },
  '技能':    { command: 'skill', subCommand: 'list' },
  '学习':    { command: 'skill', subCommand: 'learn' },
  xuexi:     { command: 'skill', subCommand: 'learn' },
  '已学习':  { command: 'skill', subCommand: 'learned' },

  // ── 习惯 ──
  xiguan:    { command: 'habit' },
  '习惯':    { command: 'habit' },
  '预测':    { command: 'habit', subCommand: 'predict' },

  // ── 知识库 ──
  zhishi:    { command: 'knowledge' },
  '知识':    { command: 'knowledge' },
  '知识库':  { command: 'knowledge' },
  '知识搜索': { command: 'knowledge', subCommand: 'search' },
  '知识同步': { command: 'knowledge', subCommand: 'sync' },
  kb:        { command: 'knowledge' },

  // ── 安全 ──
  anquan:    { command: 'security' },
  '安全':    { command: 'security' },
  '安全扫描': { command: 'security', subCommand: 'scan' },
  '安全监控': { command: 'security', subCommand: 'monitor' },

  // ── 认证 ──
  denglu:    { command: 'login' },
  '登录':    { command: 'login' },
  zhuce:     { command: 'register' },
  '注册':    { command: 'register' },
  '退出登录': { command: 'logout' },
  tuichudenglu: { command: 'logout' },
  '我是谁':  { command: 'whoami' },
  woshishui: { command: 'whoami' },
  '改密码':  { command: 'passwd' },
  gaimima:   { command: 'passwd' },
  '忘记密码': { command: 'forgot' },
  wangjimima: { command: 'forgot' },
  '找回密码': { command: 'forgot' },
  zhaohuimima: { command: 'forgot' },
};

/**
 * Resolve an alias to its canonical command.
 * @param {string} input - The raw command token
 * @returns {{ command: string, subCommand?: string, defaultArgs?: object, defaultPositionals?: string[] } | null}
 */
function resolveAlias(input) {
  if (!input) return null;
  const key = input.toLowerCase();
  return ALIAS_MAP[key] || ALIAS_MAP[input] || null;
}

/**
 * Get all aliases for a canonical command (for help display).
 */
function getAliasesForCommand(canonicalCmd) {
  return Object.entries(ALIAS_MAP)
    .filter(([, v]) => v.command === canonicalCmd)
    .map(([k]) => k);
}

/**
 * Get all alias keys for auto-complete.
 */
function getAllAliasKeys() {
  return Object.keys(ALIAS_MAP);
}

module.exports = { resolveAlias, getAliasesForCommand, getAllAliasKeys, ALIAS_MAP };
