/**
 * Interactive REPL — the heart of the CLI.
 * Combines command mode, menu mode, and AI conversation mode.
 *
 * All heavy modules are lazy-loaded for fast cold start.
 */
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const { renderSideBySideDiff } = require('./ui/diffViewer');

// ── Lazy module loaders (Claude-style: zero top-level heavy requires) ──
let _chalk, _inquirer, _formatters, _router, _ai, _menu, _userProfile;
const chalk = () => {
  if (_chalk) return _chalk;
  const chalkModule = require('chalk');
  _chalk = chalkModule.default || chalkModule;
  return _chalk;
};
const inquirer = () => (_inquirer ??= require('inquirer'));
const fmt = () => (_formatters ??= require('./formatters'));
const router = () => (_router ??= require('./router'));
const ai = () => (_ai ??= require('./ai'));
const menu = () => (_menu ??= require('./menu'));
const userProfile = () => (_userProfile ??= require('../services/userProfile'));

const os = require('os');
let _vimInput, _vimSettings;
const vimInput = () => (_vimInput ??= require('../vim/vimInput'));
const vimSettings = () => (_vimSettings ??= require('../vim/settings'));
const HISTORY_FILE = path.join(os.homedir(), '.khyquant_history');
const MAX_HISTORY = 500;

// Ensure history file has secure permissions (0600)
const { safeChmod } = require('../tools/platformUtils');
try {
  if (!fs.existsSync(HISTORY_FILE)) {
    fs.writeFileSync(HISTORY_FILE, '');
  }
  safeChmod(HISTORY_FILE, 0o600);
} catch { /* best effort */ }
const VERSION = process.env.KHYQUANT_PKG_VERSION || require('../../package.json').version;

// ── Terminal title (ANSI escape) ────────────────────────────────────────

function setTerminalTitle(title) {
  if (process.stdout.isTTY) {
    process.stdout.write(`\x1b]0;${title}\x07`);
  }
}

// Track the current conversation topic for dynamic title updates
let _currentTopic = '';

function updateTitleFromConversation(userMessage) {
  const topic = (userMessage || '').replace(/\n/g, ' ').slice(0, 30).trim();
  _currentTopic = topic || _currentTopic;
  setTerminalTitle(_currentTopic ? `· ${_currentTopic}` : 'khy OS');
}

/**
 * Update terminal title to reflect current work phase.
 * Claude Code style:
 *   Working: "· topic" (dot prefix indicates activity)
 *   Idle:    "· topic"
 * @param {'thinking'|'tool'|'generating'|'idle'} phase
 * @param {string} [detail] - tool name or phase detail
 */
function updateTitlePhase(phase, detail = '') {
  const topic = _currentTopic || 'khy OS';
  switch (phase) {
    case 'thinking':
      setTerminalTitle(`· ${topic}`);
      break;
    case 'tool':
      setTerminalTitle(`· ${topic}`);
      break;
    case 'generating':
      setTerminalTitle(`· ${topic}`);
      break;
    case 'idle':
    default:
      setTerminalTitle(`· ${topic}`);
      break;
  }
}

function hasToolCallTag(text = '') {
  const s = text || '';
  return /<tool_call>\s*[\s\S]*?<\/tool_call>/i.test(s)
    || /【\s*调用\s*[^】\n]{1,48}(?:[：:][^】]*)?】/.test(s);
}

function stripToolCallTags(text = '') {
  return (text || '')
    .replace(/<tool_call>[\s\S]*?<\/tool_call>/gi, '')
    .replace(/【\s*调用\s*[^】\n]{1,48}(?:[：:][^】]*)?】/g, '')
    .replace(/<execution_plan>[\s\S]*?<\/execution_plan>/gi, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function shouldBypassPlanMode(input = '') {
  const raw = String(input || '');
  const lower = raw.toLowerCase();
  if (!lower) return false;
  if (/\bnoplan\b|\/noplan\b/.test(lower)) return true;

  const zhPattern = /不要(?:进入)?计划|无需(?:进入)?计划|不需要(?:进入)?计划|跳过计划|直接执行|直接开始执行/;
  const enPattern = /\b(no\s*plan|skip\s*plan|direct\s*execute|execute\s*directly)\b/i;
  return zhPattern.test(raw) || enPattern.test(raw);
}

function looksLikeUiEchoInput(input = '') {
  const s = String(input || '').trim();
  if (!s) return false;
  return /^>\s*状态:\s*/.test(s)
    || /^状态:\s*(就绪|处理中)/.test(s)
    || /^>\s*(向\s*AI\s*发送请求|进入计划模式|执行计划|计划模式)/.test(s)
    || /^[-─]{10,}$/.test(s);
}

function isArrowEscapeLine(input = '') {
  const raw = String(input || '');
  const trimmed = raw.trim();
  if (!trimmed) return false;
  return trimmed === '\u001b[A'
    || trimmed === '\u001b[B'
    || trimmed === '\u001b[C'
    || trimmed === '\u001b[D'
    || /^\^\[\[[ABCD]$/.test(trimmed);
}

function mapToolToPhaseLabel(toolName = '') {
  // Claude Code style: use English tool display names
  try {
    const renderer = require('./aiRenderer');
    return renderer.getToolDisplayName(toolName);
  } catch {
    const n = String(toolName || '').toLowerCase();
    if (n.includes('read')) return 'Read';
    if (n.includes('write') || n.includes('edit')) return 'Write';
    if (n.includes('search') || n.includes('grep') || n.includes('glob')) return 'Search';
    if (n.includes('bash') || n.includes('shell') || n.includes('command')) return 'Bash';
    return toolName || 'Tool';
  }
}

function getDisplayWidthChar(ch) {
  const code = ch.codePointAt(0);
  if (!code) return 1;
  if ((code >= 0x1100 && code <= 0x115F) ||
      (code >= 0x2E80 && code <= 0xA4CF) ||
      (code >= 0xAC00 && code <= 0xD7AF) ||
      (code >= 0xF900 && code <= 0xFAFF) ||
      (code >= 0xFE10 && code <= 0xFE6F) ||
      (code >= 0xFF01 && code <= 0xFF60) ||
      (code >= 0xFFE0 && code <= 0xFFE6) ||
      (code >= 0x20000 && code <= 0x2FA1F)) {
    return 2;
  }
  return 1;
}

function streamThinkingChunk(text, streamState, c) {
  const showThinkingText = String(process.env.KHY_SHOW_THINKING_TEXT || 'false').toLowerCase() === 'true';
  if (!showThinkingText) return;
  const content = String(text || '').replace(/\r/g, '');
  if (!content) return;

  const maxCols = Math.max(24, (process.stdout.columns || 80) - 6);
  const prefix = '  ';

  if (!streamState.thinkingLineOpen) {
    process.stdout.write(prefix);
    streamState.thinkingLineOpen = true;
    streamState.thinkingCol = 0;
  }

  for (const ch of content) {
    if (ch === '\n') {
      process.stdout.write('\n');
      process.stdout.write(prefix);
      streamState.thinkingCol = 0;
      continue;
    }

    const charWidth = getDisplayWidthChar(ch);
    if (streamState.thinkingCol + charWidth > maxCols) {
      process.stdout.write('\n');
      process.stdout.write(prefix);
      streamState.thinkingCol = 0;
    }

    process.stdout.write(c.yellow(ch));
    streamState.thinkingCol += charWidth;
  }
}

function closeThinkingStream(streamState) {
  if (!streamState.thinkingLineOpen) return;
  process.stdout.write('\n');
  streamState.thinkingLineOpen = false;
  streamState.thinkingCol = 0;
}

function normalizePathLike(inputPath = '') {
  const p = String(inputPath || '').trim();
  if (!p) return '';
  const cwd = process.env.KHYQUANT_CWD || process.cwd();
  return path.isAbsolute(p) ? p : path.resolve(cwd, p);
}

function maybeRenderWriteDiff(toolName, params, result, c) {
  try {
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    if (name !== 'writefile' && name !== 'write' && name !== 'editfile' && name !== 'edit' && name !== 'multiedit') return;
    if (!result || !result.success) return;
    const diffCtx = result._khyWriteDiff || null;
    const absPath = normalizePathLike(diffCtx?.filePath || result.path || result.file || params?.path || params?.file_path || params?.filePath || '');
    if (!absPath) return;
    const nextContent = diffCtx && typeof diffCtx.afterContent === 'string'
      ? diffCtx.afterContent
      : String(params?.content ?? '');
    const prevContent = diffCtx && typeof diffCtx.beforeContent === 'string'
      ? diffCtx.beforeContent
      : '';
    if (prevContent === nextContent) return;

    const renderer = require('./aiRenderer');
    const relPath = path.relative(process.cwd(), absPath) || absPath;

    if (!prevContent && nextContent) {
      // New file — Claude Code style: green content preview (max 10 lines)
      const lines = nextContent.split('\n');
      const maxPreview = 10;
      const shown = lines.slice(0, maxPreview);
      for (let i = 0; i < shown.length; i++) {
        const num = String(i + 1).padStart(4);
        console.log(c.bgHex('#225C2B').hex('#FFFFFF')(`    ${num} + ${shown[i]}`));
      }
      if (lines.length > maxPreview) {
        console.log(c.dim(`    ... +${lines.length - maxPreview} lines (ctrl+o to expand)`));
      }
    } else {
      // Existing file — red/green structured diff
      const rendered = renderer.renderStructuredDiff(prevContent, nextContent, relPath);
      rendered.split('\n').forEach(line => console.log(`    ${line}`));
    }
  } catch {
    // non-critical
  }
}

function maybeRenderInlineDiffFromToolOutput(toolName, result, c) {
  try {
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    if (name !== 'shellcommand' && name !== 'shell' && name !== 'bash' && name !== 'command') return;
    if (!result || !result.success) return;
    const out = String(result.output || result.content || '');
    const diffPattern = /(^|\n)(\+\+\+|---|@@|\+[^+].*|-[^-].*)/m;
    if (!diffPattern.test(out)) return;
    const rendered = require('./aiRenderer').renderDiff(out);
    rendered.split('\n').slice(0, 120).forEach(line => console.log(`    ${line}`));
  } catch {
    // non-critical
  }
}

function extractInlineImageIntent(input = '', sceneHint = '') {
  const text = String(input || '').trim();
  if (!text) return null;

  const pathPattern = /(file:\/\/[^\s"'`<>]+?\.(?:png|jpg|jpeg|gif|webp)|(?:\/|\.\/|\.\.\/)[^\s"'`<>]+?\.(?:png|jpg|jpeg|gif|webp))/i;
  const m = text.match(pathPattern);
  if (!m || !m[0]) return null;

  const pathText = m[0];
  const idx = m.index || 0;
  const promptText = `${text.slice(0, idx)} ${text.slice(idx + pathText.length)}`
    .replace(/\s+/g, ' ')
    .trim();

  return {
    filePath: pathText,
    prompt: buildContextualImagePrompt(promptText, `${text} ${sceneHint}`),
  };
}

function buildImageSceneHint(sceneHint = '', history = []) {
  const base = String(sceneHint || '').trim();
  if (!Array.isArray(history) || history.length === 0) return base;

  const recentHints = history
    .slice(-10)
    .map(line => String(line || '').trim())
    .filter(Boolean)
    .filter(line => !/^\/(?:status|help|trace|usage|new|clear|exit|model|think|plan|menu)\b/i.test(line))
    .filter(line => !/^(?:paste|粘贴|clipboard|剪贴板|image|图片|img)\b/i.test(line))
    .slice(-4);

  return [base, ...recentHints].filter(Boolean).join(' ');
}

function buildContextualImagePrompt(rawPrompt = '', sceneHint = '') {
  const prompt = String(rawPrompt || '').trim();
  const normalizedPrompt = prompt
    .toLowerCase()
    .replace(/[，。！？,.!?]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  const context = `${prompt} ${String(sceneHint || '')}`.toLowerCase();
  const genericPatterns = [
    /^请?(?:分析|看看|看下|看一下)(?:这张|这个)?(?:图片|图|截图)?$/,
    /^(?:描述|说说)(?:这张|这个)?(?:图片|图|截图)(?:的内容)?$/,
    /^(?:这|这个|这张)(?:是什么|是啥|啥)$/,
    /^analy[sz]e(?: this)? (?:image|picture|photo|screenshot)$/,
    /^describe(?: this)? (?:image|picture|photo|screenshot)$/,
    /^what(?:'s| is) this(?: image| picture| photo| screenshot)?$/,
    /^(?:look at|check)(?: this)? (?:image|picture|photo|screenshot)$/,
  ];
  const isGeneric = !prompt
    || /^(?:image|picture|photo|screenshot|图片|截图|这张图|这个图)$/.test(normalizedPrompt)
    || genericPatterns.some(pattern => pattern.test(normalizedPrompt));

  if (!isGeneric) return prompt;

  if (/(报错|错误|异常|堆栈|traceback|stack|error|exception|failed)/i.test(context)) {
    return '请先提取图片中的报错/堆栈信息，再定位可能原因，并给出可执行的修复步骤。';
  }
  if (/(界面|ui|布局|对齐|样式|css|前端|按钮|截图|页面)/i.test(context)) {
    return '请检查这张界面截图中的布局与对齐问题，指出不对称点，并给出可落地的修改建议。';
  }
  if (/(代码|终端|日志|log|command|console|diff|patch)/i.test(context)) {
    return '请识别图片里的代码/终端/日志关键信息，结合上下文判断问题，并给出下一步执行命令或改动建议。';
  }
  if (/(k线|走势|行情|图表|trading|chart|candlestick)/i.test(context)) {
    return '请分析图表中的关键趋势与风险信号，并给出清晰的操作建议。';
  }
  if (/(ocr|识别|提取文字|翻译|translate|text)/i.test(context)) {
    return '请先OCR提取图片文字，再按上下文整理要点并给出结论。';
  }

  return '请先描述图片中的关键信息，再结合当前任务上下文推断我想完成的目标，并给出下一步可执行操作。';
}

/**
 * Load command history from file.
 */
function loadHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      return fs.readFileSync(HISTORY_FILE, 'utf-8').split('\n').filter(Boolean);
    }
  } catch { /* ignore */ }
  return [];
}

/**
 * Save command history to file.
 */
function saveHistory(history) {
  try {
    const lines = history.slice(-MAX_HISTORY);
    fs.writeFileSync(HISTORY_FILE, lines.join('\n') + '\n');
  } catch { /* ignore */ }
}

/**
 * Offer interactive model selection at startup.
 * Shows a dropdown if multiple adapters/models are available.
 */
async function offerModelSelection() {
  const c = chalk();
  try {
    const aiGateway = require('../services/gateway/aiGateway');

    // Quick sync detection of available adapters
    const allStatus = aiGateway.getStatus();
    const availableAdapters = allStatus.filter(s => s.enabled && s.available);

    if (availableAdapters.length === 0) return;

    // Gather models from all available adapters via gateway.listModels
    const modelChoices = [];
    for (const adapter of availableAdapters) {
      try {
        const models = await aiGateway.listModels(adapter.type);
        if (models && models.length > 0) {
          for (const model of models) {
            modelChoices.push({
              name: `${adapter.name} → ${model.name || model.id}${model.isDefault ? ' (默认)' : ''}`,
              value: { adapter: adapter.type, model: model.id },
            });
          }
        } else {
          // Adapter without model list — add as single entry
          modelChoices.push({
            name: `${adapter.name}`,
            value: { adapter: adapter.type, model: null },
          });
        }
      } catch {
        // listModels not supported — add as single entry
        modelChoices.push({
          name: `${adapter.name}`,
          value: { adapter: adapter.type, model: null },
        });
      }
    }

    if (modelChoices.length <= 1) return; // No choice needed

    // Check if user has a saved preference — skip selection if so
    const currentAdapter = process.env.GATEWAY_PREFERRED_ADAPTER;
    const currentModel = process.env.GATEWAY_PREFERRED_MODEL;
    if (currentAdapter && currentModel) {
      // Already configured, show current and offer quick switch
      // Claude Code style: model info is shown in banner, not a separate line
      return;
    }

    // Show interactive selection
    const inq = inquirer();
    console.log('');
    const { selected } = await inq.prompt([{
      type: 'list',
      name: 'selected',
      message: '选择 AI 模型 (上下箭头选择，回车确认，Esc跳过):',
      choices: [
        ...modelChoices,
        { name: c.dim('────────────'), value: '__skip_sep__', disabled: true },
        { name: '跳过 (稍后用 khy gateway model 设置)', value: null },
      ],
      pageSize: 10,
    }]);

    if (selected) {
      process.env.GATEWAY_PREFERRED_ADAPTER = selected.adapter;
      process.env.GATEWAY_PREFERRED_STRICT = 'true';
      if (selected.model) process.env.GATEWAY_PREFERRED_MODEL = selected.model;
      try { await aiGateway.refreshAdapters(); } catch { /* best effort */ }
      fmt().printSuccess(`已选择: ${selected.adapter}${selected.model ? '/' + selected.model : ''}`);
    }

    // Ensure stdin is resumed after inquirer closes its readline
    // inquirer may pause stdin which prevents our readline from working
    try { process.stdin.resume(); } catch { /* ignore */ }
    try {
      if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
        process.stdin.setRawMode(true);
      }
    } catch { /* ignore */ }
  } catch {
    // Non-critical — silently skip if anything fails
    try { process.stdin.resume(); } catch { /* ignore */ }
    try {
      if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
        process.stdin.setRawMode(true);
      }
    } catch { /* ignore */ }
  }
}

/**
 * Execute a menu result by mapping it back to command handlers.
 */
async function executeMenuResult(result) {
  if (!result) return;

  switch (result.action) {
    case 'quote': {
      const { handleQuote } = require('./handlers/data');
      await handleQuote(result.symbol);
      break;
    }
    case 'backtest-run': {
      const { handleBacktestRun } = require('./handlers/backtest');
      await handleBacktestRun(result.symbol, {
        strategy: result.strategy,
        start: result.start,
        end: result.end,
        capital: result.capital,
      });
      break;
    }
    case 'data-fetch': {
      const { handleDataFetch } = require('./handlers/data');
      await handleDataFetch(result.symbol);
      break;
    }
    case 'data-list': {
      const { handleDataList } = require('./handlers/data');
      await handleDataList();
      break;
    }
    case 'cache-clear': {
      const { handleCacheClear } = require('./handlers/data');
      await handleCacheClear();
      break;
    }
    case 'server-start': {
      const { handleServerStart } = require('./handlers/service');
      await handleServerStart();
      break;
    }
    case 'server-status': {
      const { handleServerStatus } = require('./handlers/service');
      await handleServerStatus();
      break;
    }
    case 'db-init': {
      const { handleDbInit } = require('./handlers/service');
      await handleDbInit();
      break;
    }
    case 'db-seed': {
      const { handleDbSeed } = require('./handlers/service');
      await handleDbSeed();
      break;
    }
    case 'db-status': {
      const { handleDbStatus } = require('./handlers/service');
      await handleDbStatus();
      break;
    }
    case 'app-list': {
      const { handleApp } = require('./handlers/app');
      await handleApp('list', [], {});
      break;
    }
    case 'app-status': {
      const { handleApp } = require('./handlers/app');
      await handleApp('status', [], {});
      break;
    }
    case 'app-start': {
      const { handleApp } = require('./handlers/app');
      await handleApp('start', [result.appName], {});
      break;
    }
    case 'app-stop': {
      const { handleApp } = require('./handlers/app');
      await handleApp('stop', [result.appName], {});
      break;
    }
    case 'ai-status':
      await ai().handleAiStatus();
      break;
    case 'ai-config':
      await ai().handleAiConfig();
      break;
    case 'doctor': {
      const { handleDoctor } = require('./handlers/init');
      await handleDoctor();
      break;
    }
    case 'gateway-status': {
      const { handleGatewayStatus } = require('./handlers/gateway');
      await handleGatewayStatus();
      break;
    }
    case 'gateway-config': {
      const { handleGatewayConfig } = require('./handlers/gateway');
      await handleGatewayConfig();
      break;
    }
    case 'gateway-relay': {
      const { handleGatewayRelay } = require('./handlers/gateway');
      await handleGatewayRelay();
      break;
    }
    case 'gateway-select-model': {
      const { handleGatewaySelectModel } = require('./handlers/gateway');
      await handleGatewaySelectModel();
      break;
    }
    case 'docs-quickstart': {
      const { handleDocsQuickstart } = require('./handlers/docs');
      await handleDocsQuickstart();
      break;
    }
    case 'docs-claude': {
      const { handleDocsClaude } = require('./handlers/docs');
      await handleDocsClaude();
      break;
    }
    case 'docs-gateway': {
      const { handleDocsGateway } = require('./handlers/docs');
      await handleDocsGateway();
      break;
    }
    case 'docs-strategy': {
      const { handleDocsStrategy } = require('./handlers/docs');
      await handleDocsStrategy();
      break;
    }
    case 'docs-faq': {
      const { handleDocsFaq } = require('./handlers/docs');
      await handleDocsFaq();
      break;
    }
  }
}

/**
 * Start the interactive REPL loop.
 */
async function startRepl(options = {}) {
  // Mark interactive REPL context so router can avoid low-level clear conflicts.
  process.env.KHY_REPL_ACTIVE = '1';
  const runtimeMode = String(options.mode || process.env.KHY_RUNTIME_MODE || 'khyquant').toLowerCase();
  const enablePluginAutoload = (
    options.enablePluginAutoload !== undefined
      ? !!options.enablePluginAutoload
      : String(process.env.KHY_PLUGIN_AUTOLOAD || 'true').toLowerCase() !== 'false'
  );
  const claudeUiEnabled = (
    options.claudeUi !== undefined
      ? !!options.claudeUi
      : String(process.env.KHY_CLAUDE_UI || 'true').toLowerCase() !== 'false'
  );
  const showGettingStarted = (
    options.showGettingStarted !== undefined
      ? !!options.showGettingStarted
      : String(
        process.env.KHY_SHOW_GETTING_STARTED
        || (claudeUiEnabled ? 'false' : 'true')
      ).toLowerCase() !== 'false'
  );
  const startupModelPickerEnabled = (
    options.startupModelPicker !== undefined
      ? !!options.startupModelPicker
      : String(process.env.KHY_STARTUP_MODEL_PICKER || 'false').toLowerCase() === 'true'
  );

  // Load formatters + chalk now (needed for REPL UI)
  const { printBanner, printError, printSuccess, printInfo, printWarn, ICON_PROMPT, ICON_BOT, MASCOT_MINI, getRandomFarewell } = fmt();
  const c = chalk();
  const { parseInput, route, getCompletions } = router();

  // Load renderer constants for inline use
  const { DOT_PENDING, DOT_INDICATOR, DOT_SUCCESS, DOT_ERROR } = require('./aiRenderer');
  const TREE_LAST = '└';

  // Set terminal window title
  setTerminalTitle('khy OS');

  function formatShortCwd() {
    const cwd = process.cwd();
    const home = os.homedir();
    if (cwd === home) return '~';
    if (cwd.startsWith(home + path.sep)) return '~' + cwd.slice(home.length);
    return cwd;
  }

  let _startupHeaderRendered = false;
  function renderStartupHeader(force = false) {
    if (_startupHeaderRendered && !force) return;
    _startupHeaderRendered = true;
    const aiProvider = ai().getActiveProvider();
    if (!claudeUiEnabled) {
      printBanner(VERSION, aiProvider);
      if (showGettingStarted) {
        try {
          const gettingStarted = require('../services/gettingStartedService');
          gettingStarted.displayGettingStarted();
        } catch { /* non-critical */ }
      }
      return;
    }

    let modelName = '';
    let effortLabel = 'high effort';
    let billingType = 'API Usage Billing';
    let adapterName = '';
    try {
      const gateway = require('../services/gateway/aiGateway');
      const active = gateway.getActiveAdapter();
      modelName = active?.activeModel || '';
      adapterName = active?.name || active?.type || '';
    } catch { /* best effort */ }

    if (!modelName) modelName = process.env.GATEWAY_PREFERRED_MODEL || 'auto';
    if (!adapterName) adapterName = process.env.GATEWAY_PREFERRED_ADAPTER || aiProvider || 'auto';

    // Determine billing type
    if (/ollama|local|llama/i.test(adapterName)) billingType = 'Local Model';
    else if (/relay|web|clipboard/i.test(adapterName)) billingType = 'Relay';

    // Effort level
    try {
      const effort = ai().getEffort ? ai().getEffort() : 'high';
      const labels = { max: 'max effort', high: 'high effort', medium: 'medium effort', low: 'low effort' };
      effortLabel = labels[effort] || 'high effort';
    } catch { /* best effort */ }

    const cols = process.stdout.columns || 80;

    // ── Claude Code style bordered box ──
    // Layout:
    // ╭─── khy OS vX.Y.Z ───────────────────────────╮
    // │                                               │
    // │   Welcome back!        Tips for getting started│
    // │                        Run /init to create...  │
    // │   [mascot sprite]                              │
    // │                        Recent activity         │
    // │                        No recent activity      │
    // │                                               │
    // │   Model with effort · Billing                 │
    // │       /working/directory                      │
    // ╰───────────────────────────────────────────────╯

    const boxWidth = Math.min(cols - 4, 76);
    const innerWidth = boxWidth - 4; // 2 for "│ " and " │"
    const dim = c.dim;
    const orange = c.hex('#D77757');

    // Title line
    const titleText = ` khy OS v${VERSION} `;
    const topDashes = boxWidth - 2 - titleText.length; // -2 for ╭╮
    const topLeft = Math.floor(topDashes / 2);
    const topRight = topDashes - topLeft;
    console.log('');
    console.log(dim(`  ╭${'─'.repeat(Math.max(1, topLeft))}`) + dim(titleText) + dim(`${'─'.repeat(Math.max(1, topRight))}╮`));

    // Pet sprite + right-side info
    const petColor = c.hex('#D77757');
    const petLines = [
      petColor(' ▐▛███▜▌'),
      petColor('▝▜█████▛▘'),
      petColor('  ▘▘ ▝▝'),
    ];

    const padLine = (content, width) => {
      const stripped = content.replace(/\x1b\[[0-9;]*m/g, '');
      const pad = Math.max(0, width - stripped.length);
      return content + ' '.repeat(pad);
    };

    // Left column width (pet + "Welcome back!")
    const leftColW = Math.floor(innerWidth * 0.45);
    const rightColW = innerWidth - leftColW;

    // Tips / activity section
    const tipsHeader = c.hex('#4EBA65')('Tips for getting started');
    const tipsBody = dim('Run /init to create a CLAUDE.md file');
    const actHeader = c.hex('#4EBA65')('Recent activity');
    const actBody = dim('No recent activity');

    // Row 1: empty
    console.log(dim('  │') + ' '.repeat(innerWidth) + dim('│'));

    // Row 2: "Welcome back!" + tips header
    const welcomeText = c.bold('Welcome back!');
    console.log(dim('  │ ') + padLine(`  ${welcomeText}`, leftColW) + padLine(tipsHeader, rightColW - 1) + dim('│'));

    // Row 3: pet line 0 + tips body
    console.log(dim('  │ ') + padLine(`  ${petLines[0]}`, leftColW) + padLine(tipsBody, rightColW - 1) + dim('│'));

    // Row 4: pet line 1 + activity header
    console.log(dim('  │ ') + padLine(`  ${petLines[1]}`, leftColW) + padLine(actHeader, rightColW - 1) + dim('│'));

    // Row 5: pet line 2 + activity body
    console.log(dim('  │ ') + padLine(`  ${petLines[2]}`, leftColW) + padLine(actBody, rightColW - 1) + dim('│'));

    // Row 6: empty
    console.log(dim('  │') + ' '.repeat(innerWidth) + dim('│'));

    // Row 7: model info
    const modelInfo = `${modelName} with ${effortLabel} · ${billingType}`;
    console.log(dim('  │ ') + padLine(`  ${dim(modelInfo)}`, innerWidth - 1) + dim('│'));

    // Row 8: working directory
    console.log(dim('  │ ') + padLine(`  ${dim(formatShortCwd())}`, innerWidth - 1) + dim('│'));

    // Bottom border
    console.log(dim(`  ╰${'─'.repeat(boxWidth - 2)}╯`));
    console.log('');
  }

  renderStartupHeader(true);

  // Initialize proxy configuration from saved settings
  try {
    const proxyConfig = require('../services/proxyConfigService');
    proxyConfig.initFromConfig();
  } catch { /* proxy init is non-critical */ }

  // Initialize SDK plugin system (discovers and activates khy-* plugins)
  if (enablePluginAutoload) {
    try {
      const pluginLoader = require('../plugin-loader');
      const { createContextFactory } = require('../plugin-loader/contextFactory');
      const cmdRegistry = require('./commandRegistry');
      let aiGw = null;
      try { aiGw = require('../services/gateway/aiGateway'); } catch {}

      const contextFactory = createContextFactory({
        commandRegistry: cmdRegistry,
        toolRegistry: null,
        aiGateway: aiGw,
        logger: console,
        hostVersion: VERSION,
      });

      pluginLoader.init({
        hostVersion: VERSION,
        contextFactory,
        logger: { info: () => {}, warn: console.warn, error: console.error, debug: () => {} },
      }).catch(() => {}); // Non-blocking — don't hold up REPL
    } catch { /* plugin system is non-critical */ }
  }

  // Start periodic base self-check loop (can be disabled by KHY_SELF_CHECK_ENABLED=false)
  try {
    const selfCheck = require('../services/baseSelfCheckService');
    selfCheck.autoStartFromEnv();
  } catch { /* self-check is non-critical */ }

  // Start each session with a clean slate.
  // Previous conversations are saved on exit and can be restored explicitly
  // via /resume, which compacts and extracts key context before restoring.
  let _autoResumed = false;
  try {
    ai().clearHistory();
  } catch { /* non-critical */ }

  // ── State variables (must be before setTimeout calls and renderStatusBar) ──
  let _busy = false;
  let _planMode = false;
  let _fastMode = false;
  let _effortLevel = 'medium'; // low/medium/high/max
  const _sessionStart = Date.now();
  let _ctrlCCount = 0;
  let _ctrlCTimer = null;
  let _lastTipShown = 0;
  let _recentCommands = [];
  const PATTERN_WINDOW = 5;
  let _startupTimers = [];

  // ── Deferred prefetch: all non-blocking startup tasks in one place ─────
  // Replaces 8+ individual setTimeout calls with a single managed module.
  // Falls back to empty array if the bootstrap module is not available.
  try {
    const { deferredPrefetch } = require('../bootstrap/prefetch');
    _startupTimers = deferredPrefetch({
      mode: runtimeMode === 'khy' ? 'khy' : 'khyquant',
      isBusy: () => _busy,
      onOutput: (msg) => {
        if (!_busy) {
          console.log(msg);
          try { rl.prompt(); } catch { /* ignore */ }
        }
      },
    });
  } catch {
    // Fallback: if bootstrap module unavailable, no deferred tasks.
    // This should never happen in normal operation but ensures safety.
  }

  // Startup model picker is opt-in (avoid unexpected operation prompts).
  if (startupModelPickerEnabled && process.stdin.isTTY && process.stdout.isTTY) {
    await offerModelSelection();
  }

  // Setup readline
  const history = loadHistory();

  // Build prompt with abbreviated working directory (like Claude Code)
  function buildCwdPrompt() {
    const cwd = process.cwd();
    const home = os.homedir();
    let display = cwd;
    if (cwd === home) {
      display = '~';
    } else if (cwd.startsWith(home + path.sep)) {
      display = '~' + cwd.slice(home.length);
    }
    // Shorten intermediate directories to first char if path is too long
    const parts = display.split(path.sep);
    if (parts.length > 3) {
      const last = parts.pop();
      const first = parts.shift();
      display = first + path.sep + parts.map(p => p[0] || p).join(path.sep) + path.sep + last;
    }
    return `${c.dim(display)} ${c.bold.cyan('>')} `;
  }

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: buildCwdPrompt(),
    historySize: MAX_HISTORY,
    completer: (line) => {
      const completions = getCompletions(line);
      return [completions.length > 0 ? completions : [], line];
    },
  });

  // Prepopulate history
  history.forEach(line => rl.history.push(line));

  // ── Vim mode handler ──
  let _vimHandler = null;
  try {
    if (vimSettings().isVimEnabled()) {
      _vimHandler = vimInput().createVimInputHandler(rl, {
        enabled: true,
        prompt: buildCwdPrompt(),
        onModeChange: (mode) => {
          // Status bar will pick up mode from _vimHandler.getMode()
        },
      });
    }
  } catch { /* vim not available — ignore */ }

  function bindInteractiveInputGuard(renderer) {
    if (!renderer || typeof renderer.setInteractiveGuard !== 'function') return;
    renderer.setInteractiveGuard(() => (
      _busy
      && (
        (typeof rl.line === 'string' && rl.line.length > 0)
        || Date.now() < _busyTypingUntil
      )
    ));
  }

  // ── Exit handling ──
  // IMPORTANT: Do NOT add any keypress listener on rl.input / process.stdin.
  // readline internally calls emitKeypressEvents on its input stream.
  // Adding another 'keypress' listener causes every character to echo twice
  // because the keypress event fires for both readline's internal handler
  // and our external handler, each triggering a write to stdout.
  // The SIGINT handler (Ctrl+C double-press to exit) is registered later
  // in this function, after all state variables are initialized.

  // ── Prompt Frame (Claude Code style: upper line + branch badge + lower line) ──
  let _statusBarEnabled = process.stdout.isTTY && (process.stdout.columns || 0) > 28;
  let _currentOp = '';        // Active operation name (shown during AI work)
  let _requestStart = 0;      // Timestamp when current operation started
  let _sessionTokens = 0;     // Running token count for display
  let _queryEngine = null;    // QueryEngine singleton (KHY_QUERY_ENGINE mode)
  let _intentionalExit = false; // Guard: only exit on real user request, not inquirer side-effects
  let _inquirerActive = false;  // Track inquirer stdin usage for Ctrl+D guard
  let _busyTypingUntil = 0;     // Freeze spinner updates briefly while typing/deleting
  const _slashAutoMenuEnabled = String(process.env.KHY_SLASH_AUTOMENU || 'true').toLowerCase() !== 'false';
  let _slashAutoMenuOpening = false;
  let _slashAutoMenuCooldownUntil = 0;

  try {
    process.stdin.on('data', (chunk) => {
      if (_busy) _busyTypingUntil = Date.now() + 900;
      if (!_slashAutoMenuEnabled) return;
      if (_busy || _inquirerActive || _slashAutoMenuOpening) return;
      if ((process.stdin && process.stdin.isTTY) !== true || (process.stdout && process.stdout.isTTY) !== true) return;
      if (typeof rl?.paused === 'boolean' && rl.paused) return;
      if (Date.now() < _slashAutoMenuCooldownUntil) return;

      const raw = Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk || '');
      if (!raw.includes('/')) return;

      if (String(rl.line || '') !== '/') return;
      _slashAutoMenuOpening = true;
      _slashAutoMenuCooldownUntil = Date.now() + 700;
      setTimeout(() => {
        try {
          if (_busy || _inquirerActive) return;
          if (String(rl.line || '') !== '/') return;
          try { rl.write(null, { ctrl: true, name: 'u' }); } catch { rl.line = ''; }
          rl.emit('line', '__KHY_INTERNAL_LINE__ /');
        } finally {
          _slashAutoMenuOpening = false;
        }
      }, 0);
    });
  } catch { /* best effort */ }

  // Wrapper for inquirer.prompt that sets _inquirerActive flag
  async function inqPrompt(questions) {
    _inquirerActive = true;
    try {
      return await inquirer().prompt(questions);
    } finally {
      _inquirerActive = false;
    }
  }

  // ANSI cursor helpers
  // ANSI cursor constants removed — using simple console.log for cross-platform compat

  // Rotating tips
  const TIPS = [
    '/btw 在 AI 工作时插入不打断的提示',
    '/review 自动多轮代码审查',
    '/cost 查看 AI 费用统计',
    '/model 快速切换 AI 模型',
    '/plan 生成执行计划再动手',
    '/hud 展开完整仪表盘',
    'pool list 管理 AI 账号池',
    'image <路径> 图片分析',
  ];
  let _tipIdx = 0;
  const _tipTimer = setInterval(() => { _tipIdx = (_tipIdx + 1) % TIPS.length; }, 30000);

  function fitFrameText(text, width) {
    const chars = Array.from(String(text || ''));
    if (chars.length <= width) return chars.join('') + ' '.repeat(width - chars.length);
    if (width <= 1) return chars.slice(0, width).join('');
    return chars.slice(0, width - 1).join('') + '…';
  }

  function getPromptFrameWidth() {
    const cols = process.stdout.columns || 80;
    return Math.max(26, Math.min(cols - 6, 86));
  }

  function formatToolSummary(summary) {
    if (!summary || typeof summary !== 'object') return '';
    const totalCalls = Number(summary.totalCalls || 0);
    const totalDurationMs = Number(summary.totalDurationMs || 0);
    if (!Number.isFinite(totalCalls) || !Number.isFinite(totalDurationMs)) return '';
    return `${Math.max(0, totalCalls)} tool uses \u00B7 ${Math.max(0, totalDurationMs / 1000).toFixed(1)}s`;
  }

  /**
   * Format tool result for ⎿ display line, per tool type.
   * Claude Code shows tool-specific summaries:
   *   Read → "Read N lines"
   *   Bash → command output summary or "Running in the background"
   *   Search/Grep → "Found N files" / "Found N matches"
   *   Write → "Wrote N lines to path"
   *   Edit → "Updated file (N lines changed)"
   */
  function _formatToolResult(toolName, result) {
    if (!result) return 'done';
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    const out = result.output || result.content || '';
    const outStr = typeof out === 'string' ? out : JSON.stringify(out);

    if (name === 'read' || name === 'readfile' || name === 'notebookread') {
      if (typeof result.lines === 'number') return `Read ${result.lines} lines`;
      const lineCount = outStr.split('\n').length;
      return `Read ${lineCount} lines`;
    }
    if (name === 'websearch' || name === 'webfetch') {
      if (Array.isArray(result.results)) return `Found ${result.results.length} web results`;
      if (result.data && Array.isArray(result.data.results)) return `Found ${result.data.results.length} web results`;
      if (typeof result.status === 'number') return `Fetched URL (HTTP ${result.status})`;
      return 'Web search completed';
    }
    if (name === 'ls') {
      if (typeof result.count === 'number') return `Listed ${result.count} entries`;
      if (Array.isArray(result.entries)) return `Listed ${result.entries.length} entries`;
      return 'Listed directory';
    }
    if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
      if (result._background) return 'Running in the background (\u2193 to manage)';
      const lines = outStr.trim().split('\n');
      if (lines.length <= 2) return lines.join(' ').slice(0, 80);
      return `${lines.length} lines of output`;
    }
    if (name === 'grep' || name === 'search' || name === 'searchcontent') {
      if (typeof result.count === 'number') return `Found ${result.count} matches`;
      if (Array.isArray(result.matches)) return `Found ${result.matches.length} matches`;
      const matches = outStr.split('\n').filter(Boolean).length;
      return `Found ${matches} results`;
    }
    if (name === 'glob' || name === 'find' || name === 'findfiles') {
      if (typeof result.count === 'number') return `Found ${result.count} files`;
      if (Array.isArray(result.files)) return `Found ${result.files.length} files`;
      const files = outStr.split('\n').filter(Boolean).length;
      return `Found ${files} files`;
    }
    if (name === 'write' || name === 'writefile') {
      if (typeof result.bytes === 'number') return `Wrote ${result.bytes} bytes`;
      const lineCount = outStr ? outStr.split('\n').length : 0;
      return `Wrote ${lineCount} lines`;
    }
    if (name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
      if (typeof result.editsApplied === 'number') return `Applied ${result.editsApplied} edits`;
      if (typeof result.replacements === 'number') return `Replaced ${result.replacements} occurrences`;
      return 'File updated';
    }
    if (name === 'todowrite') {
      if (typeof result.count === 'number') return `Updated ${result.count} todos`;
      return 'Todo list updated';
    }
    if (name === 'agent' || name === 'task') {
      if (result.message) return String(result.message).slice(0, 90);
      return 'Agent task completed';
    }

    // Generic
    const brief = outStr.replace(/\n/g, ' ').slice(0, 60);
    return brief || 'done';
  }

  function _toolProgressStart(toolName, params = {}) {
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    if (name === 'websearch') return { label: 'Searching the web', target: params.query || params.q || '' };
    if (name === 'webfetch') return { label: 'Fetching URL', target: params.url || '' };
    if (name === 'grep' || name === 'glob' || name === 'find' || name === 'search' || name === 'ls') {
      return { label: 'Exploring workspace', target: params.path || params.pattern || '' };
    }
    if (name === 'read' || name === 'readfile' || name === 'notebookread') {
      return { label: 'Reading file', target: params.path || params.file_path || '' };
    }
    if (name === 'write' || name === 'writefile' || name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
      return { label: 'Updating file', target: params.path || params.file_path || '' };
    }
    if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
      return { label: 'Running command', target: (params.command || '').slice(0, 80) };
    }
    if (name === 'agent' || name === 'task') {
      return { label: 'Delegating to agent', target: params.role || params.subagent_type || 'general' };
    }
    return null;
  }

  function _toolProgressReason(toolName, params = {}) {
    const name = String(toolName || '').toLowerCase().replace(/[\s_-]/g, '');
    const pathHint = String(params.path || params.file_path || params.filePath || '').trim();
    const patternHint = String(params.pattern || params.query || params.q || '').trim();
    const commandHint = String(params.command || '').trim();

    if (name === 'grep' || name === 'glob' || name === 'find' || name === 'search' || name === 'ls') {
      const scope = pathHint || patternHint || '.';
      return `原因：先在 ${scope} 定位相关文件/上下文，再执行修改或回答。`;
    }
    if (name === 'read' || name === 'readfile' || name === 'notebookread') {
      const target = pathHint || 'target file';
      return `原因：先读取 ${target}，避免盲改导致错误。`;
    }
    if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
      if (commandHint) return `原因：先执行 \`${commandHint.slice(0, 80)}\` 校验当前运行状态。`;
      return '原因：先校验环境状态，再进行下一步操作。';
    }
    if (name === 'websearch' || name === 'webfetch') {
      return '原因：先补齐外部事实信息，再给出结论。';
    }
    return '';
  }

  function _toolProgressDone(toolName, success, detail = '') {
    const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
    const status = success ? 'success' : 'error';
    if (name === 'websearch') return { status, label: success ? 'Searched' : 'Web search failed', detail };
    if (name === 'webfetch') return { status, label: success ? 'Fetched URL' : 'URL fetch failed', detail };
    if (name === 'grep' || name === 'glob' || name === 'find' || name === 'search' || name === 'ls') {
      return { status, label: success ? 'Explored' : 'Explore failed', detail };
    }
    if (name === 'read' || name === 'readfile' || name === 'notebookread') {
      return { status, label: success ? 'Read' : 'Read failed', detail };
    }
    if (name === 'write' || name === 'writefile' || name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
      return { status, label: success ? 'Updated' : 'Update failed', detail };
    }
    if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
      return { status, label: success ? 'Ran command' : 'Command failed', detail };
    }
    if (name === 'agent' || name === 'task') {
      return { status, label: success ? 'Agent completed' : 'Agent failed', detail };
    }
    return { status, label: success ? 'Completed' : 'Failed', detail };
  }

  /**
   * Render a simple static context line above the prompt.
   * No ANSI cursor movement — just prints lines that stay in the scrollback.
   * This avoids overlap/corruption issues on Windows and non-standard terminals.
   */
  function renderPromptContext() {
    // Claude Code style: no context line above prompt — clean minimal
  }

  // Wrap rl.prompt to print context before prompt (simple, no ANSI tricks)
  const _origPrompt = rl.prompt.bind(rl);

  // Claude Code style prompt: just "> " with a pipe cursor
  // IMPORTANT: Use plain ASCII for readline prompt to avoid CJK cursor drift.
  // ANSI color codes in prompt cause readline to miscalculate display width,
  // leading to ghost characters when editing CJK text.
  function _getPromptRaw() {
    return '> ';
  }
  function _getPlainPrompt() { return '> '; }
  const _framedPromptFn = _getPlainPrompt;
  // Claude Code style: input frame enabled by default on TTY.
  // Explicit opt-out: KHY_INPUT_FRAME=false|0|off
  const _inputFrameOpt = String(process.env.KHY_INPUT_FRAME || '').toLowerCase();
  const _inputFrameEnabled = process.stdout.isTTY
    && process.platform !== 'win32'
    && !['false', '0', 'off'].includes(_inputFrameOpt);

  // ── Claude Code style bottom status bar ──────────────────────────────
  // Shows: [permission mode] [X% until auto-compact]
  //        [git branch right-aligned above prompt]

  function _renderBottomStatusBar() {
    if (!process.stdout.isTTY) return;
    const cols = process.stdout.columns || 80;

    // Right side: git branch
    try {
      const hud = require('./hudRenderer');
      hud.refreshGit();
      const state = hud.getState();
      if (state.git && state.git.branch) {
        const branchText = ` ${state.git.branch} `;
        const branchLen = branchText.length;
        const pad = Math.max(0, cols - branchLen);
        // Right-aligned neutral status text
        process.stdout.write(' '.repeat(pad) + c.hex('#FFFFFF').dim(branchText) + '\n');
      }
    } catch { /* best-effort */ }
  }

  function _getPermissionModeState() {
    try {
      const toolCalling = require('../services/toolCalling');
      if (toolCalling && typeof toolCalling.isDangerousMode === 'function' && toolCalling.isDangerousMode()) {
        return { label: '⏵⏵ bypass permissions on', color: '#FF6B80' };
      }
    } catch { /* best effort */ }

    try {
      const permStore = require('../services/permissionStore');
      const profile = typeof permStore.getProfile === 'function'
        ? permStore.getProfile()
        : 'normal';
      if (profile === 'yolo') return { label: '⏵⏵ bypass permissions on', color: '#FF6B80' };
      if (profile === 'strict') return { label: 'ask before all tools on', color: '#FFFFFF' };
      return null;
    } catch {
      return null;
    }
  }

  function _renderPermissionBar() {
    if (!process.stdout.isTTY) return;
    const cols = process.stdout.columns || 80;

    // Left: mode text when non-default; fallback to shortcuts hint (Claude-style).
    const modeState = _getPermissionModeState();
    const permLeft = modeState
      ? c.hex(modeState.color || '#FFFFFF')(modeState.label)
      : c.hex('#FFFFFF').dim('? for shortcuts');

    // Right: auto-compact progress — based on session accumulated tokens vs context limit
    let compactRight = '';
    try {
      const hud = require('./hudRenderer');
      const state = hud.getState();
      const limit = state.contextWindow.limit || 200000;
      // Use session total tokens as approximate context usage
      const sessionTokens = state.sessionTokens.total || 0;
      if (sessionTokens > 0 && limit > 0) {
        const usedPct = Math.round((sessionTokens / limit) * 100);
        const remaining = Math.max(0, 100 - usedPct);
        compactRight = c.dim(`${remaining}% until auto-compact`);
      }
      // Don't show percentage when no tokens used yet (just started)
    } catch {
      // Don't show on error
    }

    const stripAnsi = (s) => s.replace(/\x1b\[[0-9;]*m/g, '');
    const truncatePlain = (s, n) => {
      const t = String(s || '');
      if (n <= 0) return '';
      if (t.length <= n) return t;
      return n <= 1 ? t.slice(0, n) : (t.slice(0, n - 1) + '…');
    };
    const plainLeft = stripAnsi(permLeft);
    const rightLen = stripAnsi(compactRight).length;
    const leftBudget = Math.max(1, cols - rightLen - 2);
    const safeLeft = plainLeft.length > leftBudget
      ? c.dim(truncatePlain(plainLeft, leftBudget))
      : permLeft;
    const leftLen = stripAnsi(safeLeft).length;
    const pad = Math.max(1, cols - leftLen - rightLen - 1);

    console.log(safeLeft + ' '.repeat(pad) + compactRight);
  }

  let _frameRendered = false; // track whether decoration has been rendered

  function renderInputPromptFrame(args) {
    const currentPrompt = _getPlainPrompt();
    if (!_inputFrameEnabled || (process.stdout.columns || 0) < 36) {
      rl.setPrompt(currentPrompt);
      _origPrompt(...args);
      return;
    }

    // Only render decoration lines when transitioning from busy→idle or at startup.
    // Avoids duplicate output on repeated rl.prompt() calls.
    if (!_frameRendered) {
      _frameRendered = true;

      const width = process.stdout.columns || 80;
      // Claude orange border — matches Claude Code theme: rgb(215,119,87)
      const rule = c.hex('#D77757')('─'.repeat(width));

      // Source-aligned layout:
      //   [optional git]
      //   ─────────────────────── (top rule)
      //   > [cursor]
      //   ─────────────────────── (bottom rule)
      //   ? for shortcuts / mode line
      _renderBottomStatusBar();
      console.log(rule);
      rl.setPrompt(currentPrompt);
      _origPrompt(...args);
      process.stdout.write('\n');
      process.stdout.write(rule);
      process.stdout.write('\n');
      _renderPermissionBar();
      try {
        readline.moveCursor(process.stdout, 0, -3);
        readline.cursorTo(process.stdout, currentPrompt.length);
      } catch {
        try { process.stdout.write('\x1b[3A\r'); } catch {}
      }
      return;
    }

    // Prompt line refresh (frame already in place)
    rl.setPrompt(currentPrompt);
    _origPrompt(...args);
  }

  function leaveInputPromptFrame() {
    // Remove lower frame remnants (bottom rule + footer) from current cursor down.
    try {
      if (process.stdout.isTTY) {
        readline.clearScreenDown(process.stdout);
      }
    } catch { /* ignore */ }
    _frameRendered = false;
  }

  rl.prompt = (...args) => {
    if (_statusBarEnabled) {
      renderPromptContext();
    }
    renderInputPromptFrame(args);
  };

  function showBusyInterjectPrompt() {
    if (!_busy) return;
    try {
      if (process.stdout.isTTY) {
        readline.clearLine(process.stdout, 0);
        readline.cursorTo(process.stdout, 0);
      }
      rl.setPrompt(_getPlainPrompt());
      _origPrompt();
    } catch { /* ignore */ }
  }

  function showBusySlashMenu() {
    let commands = [];
    try {
      const cmdReg = require('./commandRegistry');
      const byCat = cmdReg.getByCategory();
      for (const items of Object.values(byCat)) {
        for (const sc of items || []) {
          if (sc && sc.cmd && sc.desc) commands.push({ cmd: sc.cmd, desc: sc.desc });
        }
      }
    } catch {
      try {
        const { SLASH_COMMANDS } = router();
        commands = (SLASH_COMMANDS || [])
          .filter(sc => sc && sc.cmd && sc.desc)
          .map(sc => ({ cmd: sc.cmd, desc: sc.desc }));
      } catch { /* ignore */ }
    }
    const preferred = ['/i', '/interrupt', '/model', '/gateway', '/status', '/help'];
    const picked = [];
    for (const key of preferred) {
      const hit = commands.find(c0 => c0.cmd === key);
      if (hit) picked.push(hit);
    }
    if (picked.length === 0) {
      commands.slice(0, 6).forEach(c0 => picked.push(c0));
    }

    console.log(c.dim('  ↳ 忙碌菜单（可继续输入，命令会排队）:'));
    for (const item of picked.slice(0, 6)) {
      console.log(c.dim(`    ${item.cmd.padEnd(12)} ${item.desc}`));
    }
    console.log(c.dim('    /i <内容> 可优先插队并尝试中断当前请求'));
  }

  function recoverReadlineInput() {
    // If vim is active, resume vim handler instead of readline
    if (_vimHandler && _vimHandler.getMode()) {
      _vimHandler.resume();
      return;
    }
    try { process.stdin.resume(); } catch { /* ignore */ }
    try { rl.resume(); } catch { /* ignore */ }
    try {
      if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
        process.stdin.setRawMode(true);
      }
    } catch { /* ignore */ }
  }

  // Handle terminal resize
  if (process.stdout.on) {
    process.stdout.on('resize', () => {
      _statusBarEnabled = process.stdout.isTTY && (process.stdout.columns || 0) > 28;
    });
  }

  rl.prompt();

  // Track session start
  userProfile().trackSessionStart();

  // Non-blocking startup tasks (cloudSync, adminService, skillLearning,
  // securityGuard) are now handled by deferredPrefetch() above.

  // /btw hint queue — non-interrupting hints queued while AI is working
  let _btwQueue = [];
  // Queued user inputs submitted while AI is busy.
  let _queuedInputs = [];
  let _lastBusyEnterHintAt = 0;
  const INTERNAL_LINE_PREFIX = '__KHY_INTERNAL_LINE__ ';
  const INPUT_BATCH_WINDOW_MS = Math.max(20, parseInt(process.env.KHY_PASTE_MERGE_MS || '90', 10));
  const INPUT_BATCH_MODE = String(process.env.KHY_INPUT_BATCH_MODE || 'auto').toLowerCase(); // off | auto | always
  let _inputBatchTimer = null;
  let _inputBatchLines = [];
  let _pendingPaste = null;   // Buffered paste text waiting for user supplement
  let _lastBusyMergeAt = 0;   // Timestamp for busy-state rapid merge

  // ── Bracketed paste detection (ported from liteRepl) ──
  const BRACKETED_PASTE_START = ['\u001b[200~', '[200~', '00~'];
  const BRACKETED_PASTE_END = ['\u001b[201~', '[201~', '01~'];
  const _pasteCapture = { active: false, lines: [] };

  function _findFirstMarker(text, markers) {
    let best = null;
    for (const marker of markers) {
      const idx = text.indexOf(marker);
      if (idx === -1) continue;
      if (!best || idx < best.idx) best = { idx, marker };
    }
    return best;
  }

  function _stripBracketArtifacts(text) {
    return String(text || '')
      .replace(/\u001b\[\?2004[hl]/g, '')
      .replace(/\u001b\[(200|201)~/g, '')
      .replace(/\[(200|201)~/g, '')
      .replace(/^00~/, '')
      .replace(/01~$/, '');
  }

  function _consumeBracketedPaste(rawLine) {
    const line = _stripBracketArtifacts(String(rawLine || ''));
    if (!_pasteCapture.active) {
      const start = _findFirstMarker(line, BRACKETED_PASTE_START);
      if (!start || start.idx > 2) {
        return { state: 'normal', text: line };
      }
      const withoutStart = line.slice(0, start.idx) + line.slice(start.idx + start.marker.length);
      const inlineEnd = _findFirstMarker(withoutStart, BRACKETED_PASTE_END);
      if (inlineEnd) {
        const completed = (withoutStart.slice(0, inlineEnd.idx) + withoutStart.slice(inlineEnd.idx + inlineEnd.marker.length)).trim();
        return { state: 'completed', text: completed };
      }
      _pasteCapture.active = true;
      _pasteCapture.lines = [];
      if (withoutStart) _pasteCapture.lines.push(withoutStart);
      return { state: 'capturing', text: '' };
    }

    const end = _findFirstMarker(line, BRACKETED_PASTE_END);
    if (end) {
      const chunk = line.slice(0, end.idx) + line.slice(end.idx + end.marker.length);
      if (chunk) _pasteCapture.lines.push(chunk);
      const completed = _pasteCapture.lines.join('\n').trim();
      _pasteCapture.active = false;
      _pasteCapture.lines = [];
      return { state: 'completed', text: completed };
    }

    _pasteCapture.lines.push(line);
    return { state: 'capturing', text: '' };
  }

  let _pasteCounter = 0; // Running paste ID for display

  function _injectPasteIntoLine(text, rlRef) {
    _pasteCounter++;
    const lineCount = text.split('\n').length;
    // Claude Code style: [Pasted text #N +M lines] inline in the prompt
    const tag = lineCount > 1
      ? `[Pasted text #${_pasteCounter} +${lineCount} lines]`
      : `[Pasted text #${_pasteCounter}]`;
    // Write the tag into readline's line buffer so user can keep typing after it
    try { rlRef.write(tag); } catch { /* ignore */ }
  }

  function _shouldBatchInputLine(lineText = '') {
    if (INPUT_BATCH_MODE === 'always') return true;
    if (INPUT_BATCH_MODE === 'off') return false;
    // auto: always enter batch path — timer detects if more lines follow
    // If a batch is already accumulating, keep adding
    if (_inputBatchLines.length > 0 || _inputBatchTimer) return true;
    return true;
  }

  function _scheduleInputBatch(lineText, rlRef) {
    _inputBatchLines.push(String(lineText || ''));
    if (_inputBatchTimer) clearTimeout(_inputBatchTimer);
    _inputBatchTimer = setTimeout(() => {
      const merged = _inputBatchLines.join('\n').trim();
      const batchCount = _inputBatchLines.length;
      _inputBatchLines = [];
      _inputBatchTimer = null;
      if (!merged) {
        try { rlRef.prompt(); } catch { /* ignore */ }
        return;
      }
      // Single short line — not a paste, pass through directly
      if (batchCount === 1 && merged.length < 180) {
        const savedOutput = rlRef.output;
        try {
          rlRef.output = null;
          rlRef.emit('line', `${INTERNAL_LINE_PREFIX}${merged}`);
        } finally {
          rlRef.output = savedOutput;
        }
        return;
      }
      // Multi-line or long content — paste detected (Claude Code style)
      _pendingPaste = merged;
      _injectPasteIntoLine(merged, rlRef);
    }, INPUT_BATCH_WINDOW_MS);
  }

  function _requestRelayCancel(reason = 'Interrupted by user input') {
    try {
      const gateway = require('../services/gateway/aiGateway');
      const relay = gateway.getRelayAdapter();
      if (relay && typeof relay.cancelPending === 'function') {
        return relay.cancelPending(reason);
      }
    } catch { /* non-critical */ }
    return false;
  }

  rl.on('line', async (line) => {
    // When input frame is active the cursor sits inside a 3-line decoration
    // (top rule → prompt → bottom rule + footer).  readline's built-in echo
    // prints the entered text at the prompt line and then moves the cursor
    // down into the decoration area.  If we only clearLine at the current
    // position, the original echo remains visible above → duplicate input.
    //
    // Fix: when the frame was rendered, move cursor to the prompt line first,
    // wipe everything from there downward (kills both the echo ghost AND the
    // decoration remnants), then reprint a clean "> {input}" line.
    if (process.stdout.isTTY && _frameRendered) {
      try {
        // Move up to the prompt line inside the frame (cursor is ~2 lines
        // below after readline processes Enter).
        readline.moveCursor(process.stdout, 0, -2);
        readline.cursorTo(process.stdout, 0);
        readline.clearScreenDown(process.stdout);
        // Reprint the accepted input so the scrollback shows it cleanly
        const echoLine = `${_getPlainPrompt()}${line}`;
        process.stdout.write(echoLine + '\n');
      } catch { /* ignore */ }
      _frameRendered = false;
    } else if (process.stdout.isTTY) {
      try {
        readline.clearLine(process.stdout, 0);
        readline.cursorTo(process.stdout, 0);
      } catch { /* ignore */ }
    }
    const isInternalLine = typeof line === 'string' && line.startsWith(INTERNAL_LINE_PREFIX);
    line = isInternalLine ? line.slice(INTERNAL_LINE_PREFIX.length) : line;

    // ── Bracketed paste detection ──
    if (!isInternalLine) {
      const pasteState = _consumeBracketedPaste(line);
      if (pasteState.state === 'capturing') return;
      if (pasteState.state === 'completed') {
        if (!pasteState.text) { rl.prompt(); return; }
        // Claude Code style: store pending + inject tag into readline
        _pendingPaste = pasteState.text;
        _injectPasteIntoLine(pasteState.text, rl);
        return;
      }
      line = pasteState.text; // cleaned text for normal processing
    }

    const trimmed = line.trim();

    // ── Flush pending paste: merge with any supplement the user typed ──
    if (_pendingPaste !== null && !isInternalLine) {
      const paste = _pendingPaste;
      _pendingPaste = null;
      // Strip the [Pasted text ...] tag from readline's line to get only the supplement
      const supplement = trimmed.replace(/\[Pasted text #\d+(?:\s\+\d+ lines)?\]\s*/g, '').trim();
      const finalText = supplement ? paste + '\n' + supplement : paste;
      rl.emit('line', `${INTERNAL_LINE_PREFIX}${finalText}`);
      return;
    }

    if (!isInternalLine && isArrowEscapeLine(line)) {
      rl.prompt();
      return;
    }

    // Merge rapid multi-line paste into a single request before execution.
    if (!isInternalLine && !_busy && !trimmed.startsWith('/') && _shouldBatchInputLine(line)) {
      _scheduleInputBatch(line, rl);
      return;
    }

    if (!trimmed) {
      if (_busy) {
        const now = Date.now();
        if (now - _lastBusyEnterHintAt > 1200) {
          console.log(c.dim('  ↳ 正在处理中：输入内容后回车可排队，/i <内容> 可优先处理'));
          _lastBusyEnterHintAt = now;
        }
        showBusyInterjectPrompt();
        return;
      }
      // Empty line: just re-prompt without re-rendering decorations
      rl.setPrompt(_getPlainPrompt());
      _origPrompt();
      return;
    }

    // Non-empty input: clear frame so decorations re-render after processing
    if (!_busy) leaveInputPromptFrame();

    // Busy-safe slash menu: show commands without interactive dropdown, keep stream stable.
    if (_busy && trimmed === '/') {
      const now = Date.now();
      if (now - _lastBusyEnterHintAt > 1200) {
        showBusySlashMenu();
        _lastBusyEnterHintAt = now;
      }
      showBusyInterjectPrompt();
      return;
    }

    // Slash command menu — when user types exactly "/"
    if (trimmed === '/') {
      try {
        console.log('');

        // Try category-grouped menu via commandRegistry
        let choices;
        try {
          const cmdReg = require('./commandRegistry');
          const byCat = cmdReg.getByCategory();
          const catNames = cmdReg.CATEGORIES || {};
          choices = [];
          for (const [cat, cmds] of Object.entries(byCat)) {
            if (cmds.length === 0) continue;
            choices.push({ name: c.bold.white(`── ${catNames[cat] || cat} ──`), value: `__cat_${cat}`, disabled: true });
            for (const sc of cmds) {
              choices.push({
                name: `${c.cyan(sc.cmd.padEnd(14))} ${sc.label.padEnd(10)} ${c.dim(sc.desc)}`,
                value: sc,
              });
            }
          }
        } catch {
          // Fallback to flat list from router
          const { SLASH_COMMANDS } = router();
          choices = SLASH_COMMANDS.map(sc => ({
            name: `${c.cyan(sc.cmd.padEnd(14))} ${sc.label.padEnd(10)} ${c.dim(sc.desc)}`,
            value: sc,
          }));
        }

        const { selected } = await inqPrompt([{
          type: 'list',
          name: 'selected',
          message: '选择命令:',
          choices,
          pageSize: 18,
          loop: false,
        }]);

        if (selected) {
          if (selected.flag) {
            // Handle special flags
            if (selected.flag.startsWith('effort-')) {
              const level = selected.flag.replace('effort-', '');
              if (ai().setEffort(level)) {
                const presets = ai().getEffortPresets();
                const p = presets[level];
                printSuccess(`模型精度已切换: ${level} (${p.label}) — temp=${p.temperature}, maxTokens=${p.maxTokens}`);
              }
            } else if (selected.flag === 'plan') {
              // Enter plan mode — next AI call will generate a structured plan
              _planMode = true;
              printInfo('Plan mode enabled — AI will plan before executing');
            } else if (selected.flag === 'vim') {
              // Toggle vim mode
              if (_vimHandler && _vimHandler.isActive()) {
                _vimHandler.disable();
                _vimHandler = null;
                vimSettings().setEditorMode('normal');
                printSuccess('Vim mode disabled');
              } else {
                if (!_vimHandler) {
                  _vimHandler = vimInput().createVimInputHandler(rl, {
                    enabled: true,
                    prompt: buildCwdPrompt(),
                  });
                } else {
                  _vimHandler.enable();
                }
                vimSettings().setEditorMode('vim');
                printSuccess('Vim mode enabled — Esc for NORMAL, i for INSERT');
              }
            } else if (selected.flag === 'voice') {
              try {
                const voiceService = require('../services/voiceService');
                const settings = voiceService.getVoiceSettings();
                if (settings.enabled) {
                  voiceService.setVoiceEnabled(false);
                  voiceService.stopSpeaking();
                  printSuccess('Voice mode disabled');
                } else {
                  const caps = voiceService.getCapabilities();
                  voiceService.setVoiceEnabled(true);
                  printSuccess(`Voice mode enabled — TTS: ${caps.tts || 'none'} | STT: ${caps.stt || 'none'}`);
                }
              } catch (err) {
                printError(`Voice service error: ${err.message}`);
              }
            } else if (selected.flag === 'image') {
              // Prompt for image file path
              printInfo('用法: image <文件路径> <分析提示>  或  paste <分析提示>');
            } else if (selected.flag === 'paste') {
              // Read clipboard image and send to AI for analysis
              try {
                const imageService = require('../services/imageService');
                const renderer = require('./aiRenderer');
                const { prompt: userPrompt } = await inqPrompt([{
                  type: 'input', name: 'prompt', message: '图片分析提示:',
                  default: '请分析这张图片',
                }]);
                const readStart = Date.now();
                const image = imageService.readImageFromClipboard();
                renderer.printToolCallResult('Clipboard', 'clipboard', 'success',
                  `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
                  Date.now() - readStart
                );
                imageService.printImagePreview(image);
                _busy = true;
                const prompt = buildContextualImagePrompt(
                  userPrompt,
                  buildImageSceneHint('clipboard paste image', history),
                );
                const aiResult = await ai().chat(prompt, {
                  images: [{ base64: image.base64, mimeType: image.mimeType }],
                });
                if (aiResult.reply) {
                  renderer.printStepLine('success', 'AI response', aiResult.provider || 'vision');
                  const rendered = renderer.renderAiResponse(aiResult.reply);
                  rendered.split('\n').forEach(l => console.log(`  ${l}`));
                } else {
                  printInfo('AI returned no result — current provider may not support vision');
                }
                _busy = false;
              } catch (e) {
                _busy = false;
                printError(`Clipboard read failed: ${e.message}`);
                printInfo('Ensure clipboard contains image data');
              }
            } else if (selected.flag === 'clipboard') {
              // Clipboard relay status and instructions
              try {
                const clipAdapter = require('../services/gateway/adapters/clipboardRelayAdapter');
                const status = clipAdapter.getStatus();
                if (status.available) {
                  printSuccess(status.detail);
                } else {
                  printError(status.detail);
                }
                printInfo('用法: clipboard relay <提示>  或  webai <提示>');
                printInfo('管理: clipboard relay list / set <服务> / open');
              } catch (e) {
                printError(`剪贴板中继不可用: ${e.message}`);
              }
            } else if (selected.flag === 'websearch') {
              // Web search via Kiro InvokeMCP
              try {
                const webSearch = require('../services/webSearchService');
                if (!webSearch.isAvailable()) {
                  printError('联网搜索不可用 — 需要 Kiro IDE 认证 (请先登录 Kiro)');
                } else {
                  const { query } = await inqPrompt([{
                    type: 'input', name: 'query', message: '搜索关键词:',
                    validate: v => v.trim() ? true : '请输入搜索关键词',
                  }]);
                  printInfo(`正在搜索: ${query}`);
                  const result = await webSearch.search(query);
                  if (result.success) {
                    console.log('');
                    console.log(c.bold.cyan('  Search results'));
                    console.log(c.dim('  ─'.repeat(30)));
                    for (const r of (result.results || []).slice(0, 10)) {
                      console.log('');
                      console.log(c.bold.white(`  ${r.title}`));
                      if (r.url) console.log(c.blue(`  ${r.url}`));
                      if (r.snippet) console.log(c.gray(`  ${r.snippet}`));
                      if (r.publishedDate) console.log(c.dim(`  ${r.publishedDate}`));
                    }
                    console.log('');
                  } else {
                    printError(result.error || '搜索失败');
                  }
                }
              } catch (e) {
                printError(`搜索失败: ${e.message}`);
              }
            } else if (selected.flag === 'proxy') {
              // Proxy configuration (Clash / HTTP / SOCKS5)
              try {
                const proxyConfig = require('../services/proxyConfigService');
                const status = proxyConfig.getStatus();
                if (status.active) {
                  printSuccess(`代理已启用: ${status.url}`);
                  const { action } = await inqPrompt([{
                    type: 'list', name: 'action', message: '代理操作:',
                    choices: [
                      { name: '关闭代理', value: 'off' },
                      { name: '重新检测 Clash', value: 'detect' },
                      { name: '取消', value: 'cancel' },
                    ],
                  }]);
                  if (action === 'off') { proxyConfig.disableProxy(); printSuccess('代理已关闭'); }
                  else if (action === 'detect') {
                    const r = await proxyConfig.autoDetectAndEnable();
                    r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
                  }
                } else {
                  const { action } = await inqPrompt([{
                    type: 'list', name: 'action', message: '代理设置:',
                    choices: [
                      { name: '自动检测 Clash', value: 'detect' },
                      { name: '手动配置 HTTP 代理', value: 'http' },
                      { name: '手动配置 SOCKS5 代理', value: 'socks5' },
                      { name: '取消', value: 'cancel' },
                    ],
                  }]);
                  if (action === 'detect') {
                    printInfo('正在检测 Clash...');
                    const r = await proxyConfig.autoDetectAndEnable();
                    r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
                  } else if (action === 'http' || action === 'socks5') {
                    const { port } = await inqPrompt([{
                      type: 'input', name: 'port', message: `端口 (默认 ${action === 'http' ? '7890' : '1080'}):`,
                      default: action === 'http' ? '7890' : '1080',
                    }]);
                    const r = await proxyConfig.enableProxy({ type: action, host: '127.0.0.1', port });
                    r.success ? printSuccess(`代理已启用: ${r.proxy.url}`) : printError(r.error);
                  }
                }
              } catch (e) { printError(`代理配置失败: ${e.message}`); }
            } else if (selected.flag === 'models') {
              // Ollama / NVIDIA model management
              try {
                const ollamaMgr = require('../services/ollamaModelManager');
                const running = await ollamaMgr.isOllamaRunning();
                const hw = ollamaMgr.detectHardware();

                console.log('');
                printInfo(`硬件: ${hw.totalRamGB} GB RAM · ${hw.cpuCount} CPUs` + (hw.gpu ? ` · GPU: ${hw.gpu.name} (${(hw.gpu.vramMB / 1024).toFixed(1)} GB)` : ''));
                printInfo(`硬件等级: ${hw.tier.toUpperCase()} — Ollama ${running ? c.green('运行中') : c.yellow('未运行')}`);
                console.log('');

                if (running) {
                  const models = await ollamaMgr.listModels();
                  if (models.length > 0) {
                    printSuccess(`已安装 ${models.length} 个模型:`);
                    for (const m of models) {
                      console.log(c.dim(`    ${m.name}  (${m.size}, ${m.paramSize})`));
                    }
                  } else {
                    printInfo('暂无已安装模型');
                  }
                }

                const { recommended } = ollamaMgr.getRecommendations();
                const mainChoices = [
                  { name: '下载推荐模型', value: 'pull' },
                  { name: '导入本地模型文件/目录 (GGUF / Safetensors)', value: 'import' },
                  { name: '设置默认模型', value: 'set' },
                  { name: '删除已安装模型', value: 'delete' },
                  { name: '取消', value: 'cancel' },
                ];
                const { action } = await inqPrompt([{
                  type: 'list', name: 'action', message: '模型管理操作:',
                  choices: mainChoices,
                }]);

                if (action === 'pull') {
                  console.log('');
                  printInfo(`推荐模型 (${hw.tier} 级别):`);
                  const choices = recommended.map(m => ({
                    name: `${m.name} (${m.size}) — ${m.reason}`,
                    value: m.id,
                  }));
                  choices.push({ name: '取消', value: 'cancel' });
                  const { modelId } = await inqPrompt([{
                    type: 'list', name: 'modelId', message: '选择要下载的模型:',
                    choices,
                  }]);
                  if (modelId !== 'cancel' && running) {
                    printInfo(`正在下载 ${modelId}...`);
                    await ollamaMgr.pullModel(modelId, (progress) => {
                      if (progress.total > 0 && process.stdout.isTTY) {
                        process.stdout.write(`\r  ⟳ ${progress.status} ${progress.percent}%`);
                      }
                    });
                    console.log('');
                    printSuccess(`模型 ${modelId} 下载完成!`);
                  }
                } else if (action === 'import') {
                  if (!running) {
                    printError('Ollama 未运行。请先安装并启动: https://ollama.ai');
                  } else {
                    const ans = await inqPrompt([
                      { type: 'input', name: 'source', message: '本地路径 (.gguf/.safetensors/目录):' },
                      { type: 'input', name: 'name', message: '目标模型名 (可空自动生成):', default: '' },
                      { type: 'input', name: 'base', message: '若是 adapter，填写 base 模型 (如 qwen2.5:7b，可空):', default: '' },
                    ]);
                    const imported = await ollamaMgr.importModel(ans.source, ans.name, { base: ans.base || undefined });
                    if (!imported.success) {
                      printError(`导入失败: ${imported.error}`);
                    } else {
                      printSuccess(`导入成功: ${imported.model} (${imported.sourceKind})`);
                      printInfo(`运行: models set ${imported.model}`);
                    }
                  }
                } else if (action === 'set') {
                  if (!running) {
                    printError('Ollama 未运行。请先安装并启动: https://ollama.ai');
                  } else {
                    const models = await ollamaMgr.listModels();
                    if (!models.length) {
                      printInfo('暂无已安装模型');
                    } else {
                      const fs = require('fs');
                      const envPath = path.resolve(__dirname, '../../.env');
                      let envContent = '';
                      try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }
                      const setEnvVar = (k, v) => {
                        const regex = new RegExp(`^${k}=.*$`, 'm');
                        const line = `${k}=${v}`;
                        if (regex.test(envContent)) envContent = envContent.replace(regex, line);
                        else envContent = envContent.trimEnd() + '\n' + line + '\n';
                        fs.writeFileSync(envPath, envContent);
                        process.env[k] = String(v);
                      };
                      const { picked } = await inqPrompt([{
                        type: 'list',
                        name: 'picked',
                        message: '选择默认 Ollama 模型:',
                        choices: models.map(m => ({ name: `${m.name} (${m.size})`, value: m.name })),
                      }]);
                      setEnvVar('GATEWAY_PREFERRED_ADAPTER', 'ollama');
                      setEnvVar('GATEWAY_PREFERRED_STRICT', 'true');
                      setEnvVar('OLLAMA_MODEL', picked);
                      try {
                        const gateway = require('../services/gateway/aiGateway');
                        await gateway.refreshAdapters();
                      } catch { /* best effort */ }
                      printSuccess(`已设置默认模型: ollama/${picked}`);
                    }
                  }
                } else if (action === 'delete') {
                  if (!running) {
                    printError('Ollama 未运行。请先安装并启动: https://ollama.ai');
                  } else {
                    const models = await ollamaMgr.listModels();
                    if (!models.length) {
                      printInfo('暂无已安装模型');
                    } else {
                      const { picked } = await inqPrompt([{
                        type: 'list',
                        name: 'picked',
                        message: '选择要删除的模型:',
                        choices: [...models.map(m => ({ name: `${m.name} (${m.size})`, value: m.name })), { name: '取消', value: 'cancel' }],
                      }]);
                      if (picked !== 'cancel') {
                        const ok = await ollamaMgr.deleteModel(picked);
                        if (ok) printSuccess(`已删除模型: ${picked}`);
                        else printError(`删除失败: ${picked}`);
                      }
                    }
                  }
                }
              } catch (e) { printError(`模型管理失败: ${e.message}`); }
            } else if (selected.flag === 'scan') {
              // Antivirus scan
              try {
                const av = require('../services/antivirusService');
                const tools = av.detectTools();
                if (!tools.hasClamAV) {
                  printError('ClamAV 未安装');
                  const inst = av.getInstallInstructions();
                  printInfo(`安装命令: ${inst.install}`);
                } else {
                  printInfo('正在扫描项目文件...');
                  const result = av.scanProject();
                  if (result.clean) {
                    printSuccess(`扫描完成: 未发现威胁 (${(result.elapsed / 1000).toFixed(1)}s)`);
                  } else {
                    printError(`发现 ${result.infected} 个威胁!`);
                    for (const t of result.threats) {
                      console.log(c.red(`    ${t.virus} → ${t.file}`));
                    }
                    printInfo('已隔离到 ~/.khyquant/quarantine/');
                  }
                }
              } catch (e) { printError(`扫描失败: ${e.message}`); }
            } else if (selected.flag === 'security-full') {
              // Full security status
              try {
                const secGuard = require('../services/securityGuardService');
                const integrity = require('../services/fileIntegrityService');
                const resGuard = require('../services/resourceGuard');

                // 1. File integrity
                console.log('');
                printInfo('文件完整性校验...');
                const intResult = integrity.verify();
                if (intResult.verified) {
                  printSuccess(`完整性: ${intResult.unchanged} 文件无改动`);
                } else {
                  printError(`完整性异常: ${intResult.modified.length} 修改, ${intResult.removed.length} 删除`);
                  for (const f of intResult.modified.slice(0, 5)) console.log(c.yellow(`    修改: ${f}`));
                  for (const f of intResult.removed.slice(0, 5)) console.log(c.red(`    删除: ${f}`));
                }
                if (intResult.added.length > 0) {
                  printInfo(`新增文件: ${intResult.added.length} (正常更新)`);
                }

                // 2. Threat scan
                printInfo('威胁扫描...');
                const threats = secGuard.scanForThreats();
                if (threats.clean) {
                  printSuccess('威胁扫描: 未发现异常');
                } else {
                  printError(`发现 ${threats.threats.length} 个威胁:`);
                  for (const t of threats.threats) {
                    console.log(c.red(`    [${t.severity}] ${t.type}: ${t.detail}`));
                  }
                }

                // 3. System health
                const health = resGuard.systemHealthCheck();
                if (health.healthy) {
                  printSuccess('系统资源: 正常');
                } else {
                  for (const w of health.warnings) printWarn(w);
                }

                // 4. Security stats
                const stats = secGuard.getSecurityStats();
                if (stats.totalEvents > 0) {
                  printInfo(`安全事件: ${stats.totalEvents} 总计, ${stats.last24h} 近24小时`);
                }
                console.log('');
              } catch (e) { printError(`安全检查失败: ${e.message}`); }
            } else if (selected.flag === 'hardware') {
              // Hardware info and local model recommendations
              try {
                const hw = require('../services/hardwareProfileService');
                const { lines, profile } = hw.getHardwareSummary();

                console.log('');
                printInfo('硬件配置:');
                for (const line of lines) console.log(c.dim(`    ${line}`));
                console.log('');

                if (profile.localModels.length > 0) {
                  printInfo('推荐本地模型:');
                  for (const m of profile.localModels) {
                    const rec = m.recommended ? c.green(' ★ 推荐') : '';
                    if (m.recommendation === 'api-only') {
                      console.log(c.yellow(`    ${m.reason}`));
                    } else {
                      console.log(c.dim(`    ${m.name} (${m.sizeGB}GB)`) + rec);
                      console.log(c.dim(`      ${m.reason}`));
                    }
                  }
                }

                console.log('');
                printInfo('资源限制:');
                const lim = profile.limits;
                console.log(c.dim(`    Node.js 堆: ${lim.nodeHeapMB}MB`));
                console.log(c.dim(`    并发数: ${lim.maxConcurrency}`));
                console.log(c.dim(`    多智能体: ${lim.enableMultiAgent ? '启用' : '禁用'}`));
                console.log(c.dim(`    本地模型: ${lim.enableLocalModel ? '启用' : '禁用'}`));
                console.log('');
              } catch (e) { printError(`硬件检测失败: ${e.message}`); }
            } else if (selected.flag === 'review') {
              // Multi-round AI code review
              try {
                const { handleReview } = require('./handlers/review');
                _busy = true;
                await handleReview();
                _busy = false;
              } catch (e) { printError(`代码审查失败: ${e.message}`); _busy = false; }
            } else if (selected.flag === 'subscribe') {
              // Show AI subscription guide
              try {
                const { handleDocsSubscription } = require('./handlers/docs');
                await handleDocsSubscription();
              } catch (e) { printError(`显示订阅指引失败: ${e.message}`); }

            // ── Claude Code aligned flag handlers ──────────────────────
            } else if (selected.flag === 'compact') {
              printInfo('Compacting conversation history...');
              try {
                ai().compactConversation && ai().compactConversation();
                printSuccess('对话已压缩');
              } catch (e) { printError(`Compact failed: ${e.message}`); }

            } else if (selected.flag === 'config') {
              const settings = (() => {
                try { return JSON.parse(fs.readFileSync(path.join(os.homedir(), '.khy', 'settings.json'), 'utf-8')); } catch { return {}; }
              })();
              console.log(c.bold('\n  Configuration:'));
              for (const [k, v] of Object.entries(settings)) {
                console.log(`    ${c.cyan(k)}: ${JSON.stringify(v)}`);
              }
              if (Object.keys(settings).length === 0) console.log(c.dim('    No custom settings'));
              console.log('');

            } else if (selected.flag === 'context') {
              try {
                const hud = require('./hudRenderer');
                const state = hud.getState();
                const pct = state.contextWindow.limit > 0
                  ? Math.round((state.contextWindow.used / state.contextWindow.limit) * 100) : 0;
                console.log(c.bold('\n  Context Window:'));
                console.log(`    Used: ${(state.contextWindow.used / 1000).toFixed(1)}k / ${(state.contextWindow.limit / 1000).toFixed(0)}k tokens (${pct}%)`);
                console.log(`    Session tokens: ↑${(state.sessionTokens.input / 1000).toFixed(1)}k ↓${(state.sessionTokens.output / 1000).toFixed(1)}k`);
                console.log(`    Requests: ${state.requestCount}`);
                console.log('');
              } catch (e) { printError(`Context info failed: ${e.message}`); }

            } else if (selected.flag === 'diff') {
              try {
                const { execSync } = require('child_process');
                const diff = execSync('git diff', { encoding: 'utf-8', timeout: 5000 }).trim();
                if (diff) {
                  renderSideBySideDiff(diff);
                } else {
                  printInfo('No uncommitted changes');
                }
              } catch (e) { printError(`Diff failed: ${e.message}`); }

            } else if (selected.flag === 'effort') {
              printInfo('Use /max, /high, /medium, or /low to set effort level');

            } else if (selected.flag === 'env') {
              console.log(c.bold('\n  Environment:'));
              console.log(`    Platform: ${process.platform} ${process.arch}`);
              console.log(`    Node: ${process.version}`);
              console.log(`    CWD: ${process.cwd()}`);
              console.log(`    Shell: ${process.env.SHELL || 'N/A'}`);
              console.log(`    Term: ${process.env.TERM || 'N/A'}`);
              try {
                const { execSync } = require('child_process');
                const branch = execSync('git rev-parse --abbrev-ref HEAD', { encoding: 'utf-8', timeout: 2000 }).trim();
                console.log(`    Git branch: ${branch}`);
              } catch { /* not a git repo */ }
              console.log('');

            } else if (selected.flag === 'export') {
              try {
                const exportPath = path.join(process.cwd(), `khy-session-${Date.now()}.json`);
                const convo = ai().getConversation ? ai().getConversation() : [];
                fs.writeFileSync(exportPath, JSON.stringify(convo, null, 2), 'utf-8');
                printSuccess(`Conversation exported to ${exportPath}`);
              } catch (e) { printError(`Export failed: ${e.message}`); }

            } else if (selected.flag === 'fast') {
              _fastMode = !_fastMode;
              printSuccess(`Fast mode ${_fastMode ? 'enabled' : 'disabled'}`);

            } else if (selected.flag === 'files') {
              try {
                const { execSync } = require('child_process');
                const files = execSync('git ls-files', { encoding: 'utf-8', timeout: 5000 }).trim().split('\n');
                console.log(c.bold(`\n  Files in repo (${files.length}):`));
                files.slice(0, 30).forEach(f => console.log(`    ${f}`));
                if (files.length > 30) console.log(c.dim(`    ... and ${files.length - 30} more`));
                console.log('');
              } catch (e) { printError(`Files listing failed: ${e.message}`); }

            } else if (selected.flag === 'hooks') {
              try {
                const hookSystem = require('./hooks/hookSystem');
                const count = hookSystem.registry.count;
                console.log(c.bold(`\n  Hooks: ${count} registered`));
                for (const ev of hookSystem.registry.events) {
                  const hooks = hookSystem.registry.getHooks(ev);
                  if (hooks.length > 0) console.log(`    ${ev}: ${hooks.length} hook(s)`);
                }
                console.log('');
              } catch (e) { printError(`Hooks info failed: ${e.message}`); }

            } else if (selected.flag === 'mcp') {
              printInfo('MCP server management. Use /mcp add <name> <command> to add a server.');

            } else if (selected.flag === 'session') {
              const elapsed = ((Date.now() - _sessionStart) / 1000 / 60).toFixed(1);
              console.log(c.bold('\n  Session Info:'));
              console.log(`    Duration: ${elapsed} min`);
              console.log(`    Version: ${VERSION}`);
              console.log('');

            } else if (selected.flag === 'share') {
              printInfo('Share is not yet supported in CLI mode.');

            } else if (selected.flag === 'stats') {
              try {
                const hud = require('./hudRenderer');
                const s = hud.getState();
                console.log(c.bold('\n  Session Stats:'));
                console.log(`    Requests: ${s.requestCount}`);
                console.log(`    Tokens: ↑${(s.sessionTokens.input/1000).toFixed(1)}k ↓${(s.sessionTokens.output/1000).toFixed(1)}k total=${(s.sessionTokens.total/1000).toFixed(1)}k`);
                console.log(`    Tools used: ${s.toolHistory.length}`);
                console.log(`    Active agents: ${s.activeAgents.length}`);
                console.log('');
              } catch (e) { printError(`Stats failed: ${e.message}`); }

            } else if (selected.flag === 'status') {
              try {
                const hud = require('./hudRenderer');
                hud.refreshGit();
                const s = hud.getState();
                console.log(c.bold('\n  Status:'));
                if (s.git.branch) console.log(`    Branch: ${s.git.branch}${s.git.dirty ? ` (${s.git.dirtyCount} changed)` : ''}`);
                if (s.activeTool) console.log(`    Active: ${s.activeTool.name}`);
                if (s.activeAgents.length > 0) console.log(`    Agents: ${s.activeAgents.map(a => a.name).join(', ')}`);
                console.log(`    Context: ${Math.round(s.contextWindow.used/1000)}k/${Math.round(s.contextWindow.limit/1000)}k`);
                console.log('');
              } catch (e) { printError(`Status failed: ${e.message}`); }

            } else if (selected.flag === 'summary') {
              printInfo('Generating conversation summary...');
              // Delegate to AI for summarization
              try {
                const convo = ai().getConversation ? ai().getConversation() : [];
                printInfo(`Conversation has ${convo.length} messages. Use AI to summarize.`);
              } catch (e) { printError(`Summary failed: ${e.message}`); }

            } else if (selected.flag === 'tasks') {
              try {
                const taskStore = require('../tools/_taskStore');
                const tasks = taskStore.listTasks ? taskStore.listTasks() : [];
                if (tasks.length === 0) {
                  printInfo('No background tasks');
                } else {
                  console.log(c.bold(`\n  Tasks (${tasks.length}):`));
                  tasks.forEach(t => console.log(`    [${t.status}] ${t.id}: ${t.description || 'N/A'}`));
                  console.log('');
                }
              } catch { printInfo('No background tasks'); }

            } else if (selected.flag === 'theme') {
              printInfo('Themes: dark (default). Use /config to set custom theme.');

            } else if (selected.flag === 'branch') {
              try {
                const { execSync } = require('child_process');
                const branches = execSync('git branch -a', { encoding: 'utf-8', timeout: 5000 }).trim();
                console.log(c.bold('\n  Git Branches:'));
                console.log(branches.split('\n').map(b => `    ${b.trim()}`).join('\n'));
                console.log('');
              } catch (e) { printError(`Branch info failed: ${e.message}`); }

            } else if (selected.flag === 'debug') {
              printInfo('Debug mode. Use /debug <tool_name> to debug the last tool call.');

            } else if (selected.flag === 'stickers') {
              const stickers = ['(╯°□°)╯︵ ┻━┻', '┬─┬ノ( º _ ºノ)', '( •_•)>⌐■-■', '(⌐■_■)', '\\(^_^)/', '(>_<)', '(◕‿◕)', '(ノಠ益ಠ)ノ彡┻━┻'];
              console.log('\n  ' + stickers[Math.floor(Math.random() * stickers.length)] + '\n');

            } else if (selected.flag === 'effort-max') {
              _effortLevel = 'max';
              printSuccess('Effort level: MAX — AI will use maximum precision');

            }
          } else if (selected.route) {
            // Parse and execute the route command
            const cmdParsed = parseInput(selected.route);
            if (cmdParsed) {
              const result = await route(cmdParsed);
              recoverReadlineInput();
              if (result === 'exit') {
                ai().saveConversation();
                saveHistory(history);
                setTerminalTitle('');
                console.log('');
                console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
                console.log(c.dim('  对话摘要已保存'));
                console.log('');
                _intentionalExit = true; process.exit(0);
              }
            }
          }
        }
      } catch { /* menu cancelled or error */ }
      recoverReadlineInput();
      rl.prompt();
      return;
    }

    // /btw — queue hint without interrupting current AI work
    if (trimmed === '/btw' || trimmed.startsWith('/btw ')) {
      const hint = trimmed.slice(4).trim();
      if (hint) {
        _btwQueue.push(hint);
        console.log(c.dim(`  Queued hint (${_btwQueue.length} in queue)`));
      } else {
        console.log(c.dim('  Usage: /btw <hint text>'));
        console.log(c.dim('  Queue a hint while AI is working without interrupting'));
        console.log(c.dim(`  Current queue: ${_btwQueue.length} hint(s)`));
      }
      rl.prompt();
      return;
    }

    // /vim — toggle vim mode
    if (trimmed === '/vim') {
      const c = chalk();
      if (_vimHandler && _vimHandler.isActive()) {
        _vimHandler.disable();
        _vimHandler = null;
        vimSettings().setEditorMode('normal');
        console.log(c.green('  Vim mode disabled'));
      } else {
        if (!_vimHandler) {
          _vimHandler = vimInput().createVimInputHandler(rl, {
            enabled: true,
            prompt: buildCwdPrompt(),
          });
        } else {
          _vimHandler.enable();
        }
        vimSettings().setEditorMode('vim');
        console.log(c.green('  Vim mode enabled — Esc for NORMAL, i for INSERT'));
      }
      if (!_vimHandler || !_vimHandler.isActive()) {
        rl.prompt();
      }
      return;
    }

    // /voice — toggle voice mode
    if (trimmed === '/voice') {
      const c = chalk();
      try {
        const voiceService = require('../services/voiceService');
        const settings = voiceService.getVoiceSettings();
        if (settings.enabled) {
          voiceService.setVoiceEnabled(false);
          voiceService.stopSpeaking();
          console.log(c.green('  Voice mode disabled'));
        } else {
          const caps = voiceService.getCapabilities();
          voiceService.setVoiceEnabled(true);
          console.log(c.green('  Voice mode enabled'));
          console.log(c.dim(`    TTS: ${caps.tts || 'none'} | STT: ${caps.stt || 'none'}`));
          if (!caps.tts) console.log(c.yellow('    No TTS provider found. Install espeak or edge-tts.'));
          if (!caps.stt) console.log(c.yellow('    No STT provider found. Install sox or whisper.'));
        }
      } catch (err) {
        console.log(c.red(`  Voice service error: ${err.message}`));
      }
      rl.prompt();
      return;
    }

    // /fast — toggle fast mode
    if (trimmed === '/fast') {
      _fastMode = !_fastMode;
      printSuccess(`Fast mode ${_fastMode ? 'enabled' : 'disabled'}`);
      rl.prompt();
      return;
    }

    // /compact — compact conversation
    if (trimmed === '/compact') {
      printInfo('Compacting conversation...');
      try {
        ai().compactConversation && ai().compactConversation();
        printSuccess('对话已压缩');
      } catch (e) { printError(`Compact failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /context — show context window usage
    if (trimmed === '/context') {
      try {
        const hud = require('./hudRenderer');
        const s = hud.getState();
        const pct = s.contextWindow.limit > 0 ? Math.round((s.contextWindow.used / s.contextWindow.limit) * 100) : 0;
        const c = chalk();
        console.log(c.bold('\n  Context Window:'));
        console.log(`    Used: ${(s.contextWindow.used/1000).toFixed(1)}k / ${(s.contextWindow.limit/1000).toFixed(0)}k tokens (${pct}%)`);
        console.log(`    Session: ↑${(s.sessionTokens.input/1000).toFixed(1)}k ↓${(s.sessionTokens.output/1000).toFixed(1)}k`);
        console.log('');
      } catch (e) { printError(`Context failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /diff — show git diff
    if (trimmed === '/diff') {
      try {
        const { execSync } = require('child_process');
        const diff = execSync('git diff', { encoding: 'utf-8', timeout: 5000 }).trim();
        if (diff) {
          renderSideBySideDiff(diff);
        } else {
          printInfo('No uncommitted changes');
        }
      } catch (e) { printError(`Diff failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /status — show current status
    if (trimmed === '/status') {
      try {
        const hud = require('./hudRenderer');
        hud.refreshGit();
        const s = hud.getState();
        const c = chalk();
        console.log(c.bold('\n  Status:'));
        if (s.git.branch) console.log(`    Branch: ${s.git.branch}${s.git.dirty ? ` (${s.git.dirtyCount} changed)` : ''}`);
        console.log(`    Context: ${Math.round(s.contextWindow.used/1000)}k/${Math.round(s.contextWindow.limit/1000)}k`);
        console.log(`    Requests: ${s.requestCount}`);
        console.log('');
      } catch (e) { printError(`Status failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /stats — show session statistics
    if (trimmed === '/stats') {
      try {
        const hud = require('./hudRenderer');
        const s = hud.getState();
        const c = chalk();
        const elapsed = ((Date.now() - _sessionStart) / 1000 / 60).toFixed(1);
        console.log(c.bold('\n  Session Stats:'));
        console.log(`    Duration: ${elapsed} min`);
        console.log(`    Requests: ${s.requestCount}`);
        console.log(`    Tokens: ↑${(s.sessionTokens.input/1000).toFixed(1)}k ↓${(s.sessionTokens.output/1000).toFixed(1)}k`);
        console.log(`    Tools: ${s.toolHistory.length} calls`);
        console.log('');
      } catch (e) { printError(`Stats failed: ${e.message}`); }
      rl.prompt();
      return;
    }

    // /env — environment info
    if (trimmed === '/env') {
      const c = chalk();
      console.log(c.bold('\n  Environment:'));
      console.log(`    Platform: ${process.platform} ${process.arch}`);
      console.log(`    Node: ${process.version}`);
      console.log(`    CWD: ${process.cwd()}`);
      console.log(`    Shell: ${process.env.SHELL || 'N/A'}`);
      console.log(`    Version: ${VERSION}`);
      console.log('');
      rl.prompt();
      return;
    }

    // /tasks — list background tasks
    if (trimmed === '/tasks') {
      try {
        const taskStore = require('../tools/_taskStore');
        const tasks = taskStore.listTasks ? taskStore.listTasks() : [];
        if (tasks.length === 0) {
          printInfo('No background tasks');
        } else {
          const c = chalk();
          console.log(c.bold(`\n  Tasks (${tasks.length}):`));
          tasks.forEach(t => console.log(`    [${t.status}] ${t.id}: ${t.description || ''}`));
          console.log('');
        }
      } catch { printInfo('No background tasks'); }
      rl.prompt();
      return;
    }

    // /max, /high, /medium, /low — effort level switching
    const effortMatch = trimmed.match(/^\/(max|high|medium|low)$/);
    if (effortMatch) {
      const level = effortMatch[1];
      if (ai().setEffort(level)) {
        const presets = ai().getEffortPresets();
        const p = presets[level];
        printSuccess(`模型精度已切换: ${level} (${p.label}) — temp=${p.temperature}, maxTokens=${p.maxTokens}`);
      } else {
        printError('无效的精度级别');
      }
      rl.prompt();
      return;
    }

    // ── Clipboard relay commands ──────────────────────────────────
    const clipRelayMatch = /^(?:clipboard\s+relay|剪贴板中继|webai)(?:\s+(.+))?$/i.exec(trimmed);
    if (clipRelayMatch) {
      const subCmd = (clipRelayMatch[1] || '').trim().toLowerCase();

      try {
        const clipAdapter = require('../services/gateway/adapters/clipboardRelayAdapter');

        // Sub-commands: service list, service set, open, or direct prompt
        if (subCmd === 'list' || subCmd === '列表') {
          const services = clipAdapter.getServices();
          const current = clipAdapter.getPreferredService();
          printInfo('可用的 Web AI 服务:');
          for (const [key, svc] of Object.entries(services)) {
            const marker = key === current ? c.green(' ← 当前') : '';
            console.log(`  ${c.cyan(key.padEnd(10))} ${svc.name.padEnd(20)} ${c.dim(svc.url)}${marker}`);
          }
        } else if (subCmd.startsWith('set ') || subCmd.startsWith('切换 ')) {
          const serviceKey = subCmd.replace(/^(set|切换)\s+/i, '').trim();
          if (clipAdapter.setService(serviceKey)) {
            const services = clipAdapter.getServices();
            printSuccess(`已切换到 ${services[serviceKey].name}`);
          } else {
            printError(`未知服务: ${serviceKey} — 运行 clipboard relay list 查看可用服务`);
          }
        } else if (subCmd === 'open' || subCmd === '打开') {
          const services = clipAdapter.getServices();
          const current = clipAdapter.getPreferredService();
          const svc = services[current];
          clipAdapter.openBrowser(svc.url);
          printInfo(`已打开 ${svc.name}: ${svc.url}`);
        } else if (subCmd === 'status' || subCmd === '状态' || !subCmd) {
          const status = clipAdapter.getStatus();
          if (status.available) {
            printSuccess(status.detail);
          } else {
            printError(status.detail);
          }
        } else {
          // Treat as a prompt to relay via clipboard
          _busy = true;
          try {
            const result = await clipAdapter.generate(subCmd);
            if (result.success) {
              const renderer = require('./aiRenderer');
              renderer.printStepLine('success', 'AI response', result.provider);
              const rendered = renderer.renderAiResponse(result.content);
              rendered.split('\n').forEach(l => console.log(`  ${l}`));
            } else {
              printError(result.content);
            }
          } finally {
            _busy = false;
          }
        }
      } catch (err) {
        printError(`剪贴板中继失败: ${err.message}`);
      }
      rl.prompt();
      return;
    }

    // Image analysis — file path or clipboard paste
    const imageMatch = trimmed.match(/^(?:image|图片|img)\s+(.+?\.(png|jpg|jpeg|gif|webp))\s*(.*)/i);
    const pasteMatch = /^(?:paste|粘贴|clipboard|剪贴板)(?:\s+(.*))?$/i.exec(trimmed);
    const sceneHint = buildImageSceneHint(trimmed, history);
    const inlineImage = (!imageMatch && !pasteMatch) ? extractInlineImageIntent(trimmed, sceneHint) : null;

    if (imageMatch || pasteMatch || inlineImage) {
      try {
        const imageService = require('../services/imageService');
        const renderer = require('./aiRenderer');
        let image, prompt;

        if (imageMatch || inlineImage) {
          // File path mode
          const filePath = imageMatch ? imageMatch[1] : inlineImage.filePath;
          prompt = imageMatch
            ? buildContextualImagePrompt(imageMatch[3] || '', sceneHint)
            : inlineImage.prompt;
          const readStart = Date.now();
          image = imageService.readImageFromFile(filePath);
          renderer.printToolCallResult('Read', { path: filePath }, 'success',
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
            Date.now() - readStart
          );
        } else {
          // Clipboard paste mode
          prompt = buildContextualImagePrompt(
            pasteMatch[1] || '',
            buildImageSceneHint('clipboard paste image', history),
          );
          const readStart = Date.now();
          image = imageService.readImageFromClipboard();
          renderer.printToolCallResult('Clipboard', 'clipboard', 'success',
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
            Date.now() - readStart
          );
        }

        // Show preview
        imageService.printImagePreview(image);

        // Send to AI with vision
        _busy = true;
        const aiResult = await ai().chat(prompt, {
          images: [{ base64: image.base64, mimeType: image.mimeType }],
        });

        if (aiResult.reply) {
          if (aiResult.errorType) {
            printError(aiResult.reply);
            printInfo('提示: 可用 /model 切换到支持视觉的模型后重试');
          } else {
            renderer.printStepLine('success', 'AI 图片分析', aiResult.provider || 'vision');
            const rendered = renderer.renderAiResponse(aiResult.reply);
            rendered.split('\n').forEach(l => console.log(`  ${l}`));
          }
        } else {
          printInfo('AI 未返回分析结果 — 当前 AI 服务可能不支持图片分析');
        }
        console.log('');
      } catch (imgErr) {
        printError(`图片处理失败: ${imgErr.message}`);
      } finally {
        _busy = false;
      }
      rl.prompt();
      return;
    }

    // Prevent concurrent command execution
    if (_busy) {
      // /interrupt (or /i) while busy: request cancellation and prioritize next input
      const interruptMatch = /^\/(?:interrupt|i)\s+([\s\S]+)$/i.exec(trimmed);
      if (interruptMatch) {
        const nextInput = interruptMatch[1].trim();
        if (!nextInput) {
          printInfo('用法: /interrupt <新输入> 或 /i <新输入>');
          return;
        }
        _queuedInputs.unshift(nextInput);
        const cancelled = _requestRelayCancel('Interrupted by /interrupt');
        if (cancelled) {
          console.log(c.dim('  ⚡ 已中断当前 Web 中转请求，完成后优先处理新输入'));
        } else {
          console.log(c.dim('  ⚡ 已记录中断请求，将在当前步骤结束后优先处理新输入'));
        }
        showBusyInterjectPrompt();
        return;
      }

      // Queue input without interrupting current work (like Claude Code's /btw)
      // Merge rapid consecutive lines (paste while busy) into one queued block
      const now = Date.now();
      if (_queuedInputs.length > 0 && (now - _lastBusyMergeAt) <= 250) {
        _queuedInputs[_queuedInputs.length - 1] += '\n' + trimmed;
      } else {
        _queuedInputs.push(trimmed);
      }
      _lastBusyMergeAt = now;
      const queuePreview = _queuedInputs[_queuedInputs.length - 1].replace(/\n/g, ' ').slice(0, 40);
      console.log(c.dim(`  ${DOT_PENDING} 已排队: "${queuePreview}${queuePreview.length >= 40 ? '...' : ''}" (队列: ${_queuedInputs.length})`));
      console.log(c.dim(`    ${TREE_LAST} AI 完成当前工作后自动处理，/i <内容> 可优先处理，Ctrl+C 可中断`));
      showBusyInterjectPrompt();
      return;
    }
    _busy = true;

    // Suspend vim handler during command execution (raw mode conflicts)
    if (_vimHandler) try { _vimHandler.suspend(); } catch { /* ignore */ }

    // Save to history
    history.push(trimmed);

    // Parse and route the command
    const parsed = parseInput(trimmed);
    if (!parsed) {
      _busy = false;
      rl.prompt();
      return;
    }

    try {
      const result = await route(parsed);

      // Restore stdin/readline after route handlers that may use inquirer internally.
      // Inquirer creates its own readline and may pause stdin, leaving our rl deaf.
      recoverReadlineInput();

      // Claude Code style: /clear clears screen + conversation history
      if (parsed.command === 'clear') {
        try { ai().clearHistory(); } catch {}
        if (_queryEngine) {
          try { _queryEngine.clearHistory(); } catch {}
        }
        // Reprint startup header after a hard screen reset.
        // Avoid router-level + frame-level double clear artifacts.
        try { leaveInputPromptFrame(); } catch {}
        try {
          if (process.stdout.isTTY) {
            readline.cursorTo(process.stdout, 0, 0);
            readline.clearScreenDown(process.stdout);
          } else {
            console.clear();
          }
        } catch { console.clear(); }
        _startupHeaderRendered = false;
        try { renderStartupHeader(true); } catch {}
      }

      if (result === 'exit') {
        ai().saveConversation();
        saveHistory(history);
        setTerminalTitle(''); // restore terminal title
        console.log('');
        console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
        console.log(c.dim('  对话摘要已保存，下次输入 /resume 恢复上下文'));
        console.log('');
        _intentionalExit = true; process.exit(0);
      }

      if (result === 'menu') {
        let menuResult;
        do {
          menuResult = await menu().runMenuLoop();
          await executeMenuResult(menuResult);
        } while (menuResult !== null);
        rl.prompt();
        return;
      }

      if (result === 'ai-status') {
        await ai().handleAiStatus();
        rl.prompt();
        return;
      }

      if (result === 'ai-config') {
        await ai().handleAiConfig();
        rl.prompt();
        return;
      }

      if (result === 'ai-on' || result === 'ai-off') {
        // AI is always on — no manual toggle needed
        printInfo('AI 对话已默认开启，无需手动切换');
        rl.prompt();
        return;
      }

      if (result === true) {
        // Command was handled — track it
        if (parsed && parsed.command) userProfile().trackCommand(parsed.command);

        // Record command sequence for pattern learning
        if (parsed && parsed.command) {
          _recentCommands.push(trimmed);
          if (_recentCommands.length > PATTERN_WINDOW) _recentCommands.shift();

          // Record workflow step for habit optimization
          try {
            const { recordWorkflowStep, recordInteraction: recordHabit } = require('../services/usageHabitService');
            recordHabit(trimmed);
            if (_recentCommands.length >= 2) {
              recordWorkflowStep(_recentCommands.slice(-2));
            }
          } catch { /* best effort */ }

          // Check for patterns when we have enough commands
          if (_recentCommands.length >= 2) {
            try {
              const { recordCommandSequence } = require('../services/skillLearningService');
              const suggestion = recordCommandSequence(_recentCommands.slice(-3));
              if (suggestion && suggestion.suggest) {
                console.log('');
                console.log(c.hex('#FFC107')(`  Detected repeated operation pattern (${suggestion.count} times):`));
                console.log(c.dim(`     ${suggestion.sequence.join(' → ')}`));
                console.log(c.dim(`     输入 skill learn workflow "${suggestion.sequence.join(' → ')}" 自动化`));
                console.log('');
              }
            } catch { /* pattern learning is best-effort */ }
          }
        }

        rl.prompt();
        return;
      }

      // result.aiForward → a command generated a prompt for AI
      const aiInput = (result && result.aiForward) ? result.aiForward : trimmed;

      // Unrecognized command → auto-route to AI (always on)

      // result === false or aiForward → send to AI
      let streamState = { phase: 'idle', thinkingStarted: false, textStarted: false, thinkingLineOpen: false, thinkingCol: 0 };

      // Update terminal title with user's topic immediately
      updateTitleFromConversation(aiInput);

      // Merge any queued /btw hints into the input
      let finalAiInput = aiInput;
      if (_btwQueue.length > 0) {
        const hints = _btwQueue.splice(0).join('\n');
        finalAiInput = `${aiInput}\n\n[附加提示]\n${hints}`;
      }

      // Detect inline image paths (file:///...png, /path/to/img.jpg, etc.)
      // If found, extract image and send via vision API instead of text-only chat.
      let _inlineImageOpts = null;
      try {
        const _imgIntent = extractInlineImageIntent(finalAiInput, buildImageSceneHint(finalAiInput, history));
        if (_imgIntent) {
          const imageService = require('../services/imageService');
          const image = imageService.readImageFromFile(_imgIntent.filePath);
          _inlineImageOpts = {
            images: [{ base64: image.base64, mimeType: image.mimeType }],
          };
          finalAiInput = _imgIntent.prompt || '请分析这张图片的内容';
          const renderer = require('./aiRenderer');
          renderer.printStepLine('success', 'Read', _imgIntent.filePath,
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`);
          imageService.printImagePreview(image);
        }
      } catch (imgErr) {
        printInfo(`图片读取失败: ${imgErr.message}，将作为文本发送`);
      }

      // Detect file paths in input (drag-and-drop support)
      // Strips quotes, resolves relative to user's launch directory
      try {
        const fileExts = /\.(txt|js|ts|py|json|csv|md|log|yaml|yml|toml|html|css|vue|sql|sh|bat|xml|ini|cfg|conf|java|go|rs|c|cpp|h|rb|php)$/i;
        const pathCandidate = finalAiInput.replace(/^['"`]+|['"`]+$/g, '').replace(/\\ /g, ' ').split(/\s+/)[0];
        if (fileExts.test(pathCandidate)) {
          const userCwd = process.env.KHYQUANT_CWD || process.cwd();
          const resolvedPath = path.isAbsolute(pathCandidate) ? pathCandidate : path.resolve(userCwd, pathCandidate);
          // Security: restrict file reads to project root or user CWD
          const projectRoot = path.resolve(__dirname, '..', '..');
          const normalizedPath = path.resolve(resolvedPath);
          const isWithinCwd = normalizedPath.startsWith(path.resolve(userCwd) + path.sep) || normalizedPath === path.resolve(userCwd);
          const isWithinProject = normalizedPath.startsWith(projectRoot + path.sep);
          const BLOCKED_NAMES = ['.env', '.pem', '.key', '.crt', '.pfx', '.p12', 'id_rsa', 'id_ed25519', 'id_ecdsa', 'id_dsa', 'credentials', 'secret', 'token', '.admin_initial_password', '.htpasswd', 'shadow', '.netrc', '.pgpass'];
          const BLOCKED_EXTS = ['.pem', '.key', '.crt', '.pfx', '.p12', '.jks', '.keystore'];
          const basename = path.basename(normalizedPath).toLowerCase();
          const ext = path.extname(normalizedPath).toLowerCase();
          const isBlocked = BLOCKED_NAMES.some(b => basename === b || basename.startsWith(b + '.') || basename.endsWith(b)) || BLOCKED_EXTS.includes(ext);
          if (isBlocked) {
            printInfo(`Security: blocked reading sensitive file: ${basename}`);
          } else if (!isWithinCwd && !isWithinProject) {
            printInfo(`Security: file is outside project/working directory, skipped: ${path.basename(resolvedPath)}`);
          } else if (fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isFile()) {
            const stat = fs.statSync(resolvedPath);
            const maxSize = 100 * 1024;
            const content = fs.readFileSync(resolvedPath, 'utf-8').slice(0, maxSize);
            const sizeInfo = stat.size > maxSize ? `截取前 100KB / 总 ${(stat.size / 1024).toFixed(0)}KB` : `${(stat.size / 1024).toFixed(1)} KB`;
            printInfo(`已读取文件: ${path.basename(resolvedPath)} (${sizeInfo})`);
            const followUp = finalAiInput.slice(pathCandidate.length).trim();
            const prompt = followUp || '请分析这个文件的内容';
            finalAiInput = `[文件内容: ${path.basename(resolvedPath)}]\n\`\`\`\n${content}\n\`\`\`\n\n${prompt}`;
          }
        }
      } catch { /* file detection is best-effort, ignore errors */ }

      // Check for multi-agent trigger
      const agentRunner = require('../services/cliAgentRunner');
      if (agentRunner.shouldUseMultiAgent(finalAiInput)) {
        _currentOp = '多智能体协作';
        _requestStart = Date.now();
        const agentDisplay = require('./agentRenderer');
        const renderer = require('./aiRenderer');

        // Decompose task into sub-tasks
        const subtasks = agentRunner.decomposeTask(finalAiInput);
        let renderedLines = 0;

        // Show initial agent display
        renderedLines = agentDisplay.renderAgentDisplay(subtasks.map(st => ({
          name: st.name, status: 'pending', toolCalls: 0, tokens: 0, elapsed: 0, detail: '',
        })));

        // Run agents with progress updates
        const agentResults = await agentRunner.runAgents(subtasks, {
          ai: ai(),
          onProgress: (states) => {
            renderedLines = agentDisplay.rerenderAgentDisplay(states, renderedLines);
          },
        });

        // Show final state
        agentDisplay.rerenderAgentDisplay(agentResults, renderedLines, true);
        agentDisplay.renderAgentSummary(agentResults);

        // Synthesize results
        renderer.printToolCallStart('Synthesize', '综合分析');
        const synthStart = Date.now();
        const synthesized = await agentRunner.synthesizeResults(agentResults, finalAiInput, ai());
        renderer.printToolCallResult('Synthesize', '综合分析', 'success', '合成完成', Date.now() - synthStart);

        // Display synthesized result
        agentDisplay.renderSynthesisResult(synthesized, agentResults);
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // Check for plan mode trigger
      const planService = require('../services/planModeService');
      if (looksLikeUiEchoInput(aiInput)) {
        printInfo('检测到界面状态文本，已忽略该输入');
        return;
      }
      let needsPlan = false;
      const bypassPlan = shouldBypassPlanMode(aiInput);
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        needsPlan = bypassPlan ? false : (pp.needsPlan || _planMode);
      } catch { /* best effort */ }

      if (bypassPlan && _planMode) _planMode = false;
      if (bypassPlan) {
        printInfo('Skipping plan mode, executing directly');
      }

      if (needsPlan || _planMode) {
        const renderer = require('./aiRenderer');
        _planMode = false; // Reset after use
        _currentOp = 'Planning';
        _requestStart = Date.now();

        // Step 1: Generate plan
        renderer.printStepLine('active', 'Plan mode', 'generating plan...');
        const { plan, rawResponse, provider, elapsed, errorType } = await planService.enterPlanMode(finalAiInput, ai());

        if (plan && plan.steps.length > 0) {
          if (process.stdout.isTTY) {
            process.stdout.write('\x1b[1A\r\x1b[K');
          }
          renderer.printStepLine('success', 'Plan mode', `generated ${plan.steps.length}-step plan`);

          // Step 2: Present for approval
          const approval = await planService.presentForApproval(plan, renderer, rl);

          if (approval.approved) {
            // Step 3: Execute step by step
            console.log('');
            renderer.printStepLine('active', '执行计划', `${plan.steps.filter(s => s.status !== 'skipped').length} 步骤`);

            const results = await planService.executePlanSteps(plan, {
              ai: ai(),
              renderer,
              rl,
              route,
              parseInput,
            });

            if (process.stdout.isTTY) {
              process.stdout.write('\x1b[1A\r\x1b[K');
            }
            renderer.printStepLine('success', '计划执行完成', `${results.filter(r => r.step.status === 'completed').length}/${results.length} 成功`);

            // Show final results
            for (const { step, result } of results) {
              const attempts = Number(result?._planAttempts || 0);
              if (step.status === 'error') {
                const reason = String(result?.error || '未知错误');
                console.log(c.red(`  ✗ 步骤 ${step.id} 失败${attempts > 0 ? `（尝试 ${attempts} 次）` : ''}: ${reason}`));
              } else if (attempts > 1) {
                console.log(c.dim(`  ✓ 步骤 ${step.id} 在第 ${attempts} 次尝试通过校验`));
              }
              if (result.reply) {
                console.log(c.dim(`  步骤 ${step.id}: ${step.description}`));
                const rendered = renderer.renderAiResponse(result.reply);
                rendered.split('\n').forEach(l => console.log(`  ${l}`));
              }
            }
            renderer.renderAgentDone({
              toolCalls: results.length,
              elapsedMs: elapsed,
            });
          } else {
            printInfo('Plan cancelled');
          }
        } else {
          // Plan generation failed — fall through to normal AI
          if (process.stdout.isTTY) {
            process.stdout.write('\x1b[1A\r\x1b[K');
          }
          renderer.printStepLine('error', 'Plan mode', errorType || '', 'plan generation failed');
          if (rawResponse) {
            const renderer2 = require('./aiRenderer');
            const rendered = renderer2.renderAiResponse(rawResponse);
            rendered.split('\n').forEach(l => console.log(`  ${l}`));
          } else {
            printError('计划模式生成失败，且未返回具体错误信息');
          }
        }
        planService.reset();
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // Load AI renderer for rich output
      const renderer = require('./aiRenderer');
      bindInteractiveInputGuard(renderer);
      const spinner = new renderer.DynamicSpinner();
      const tracker = new renderer.ProcessTracker();
      if (_inputFrameEnabled && typeof spinner.setPromptMode === 'function') {
        spinner.setPromptMode('framed', {
          ruleColor: '#D77757',
          footer: c.hex('#FFFFFF').dim('? for shortcuts'),
        });
      }

      // Claude Code style: no intent analysis step — go straight to AI

      // Step 1: Preprocessing — detect complexity for display
      let complexTask = false;
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        complexTask = pp.needsPlan;
      } catch { /* best effort */ }

      if (complexTask) {
        tracker.start('Analyzing', aiInput.slice(0, 40), 'complex task detected');
        tracker.complete('AI will plan first');
      }

      // Step 2: AI request — Claude Code style: rich spinner with effort/tokens
      _currentOp = 'Requesting AI';
      _requestStart = Date.now();

      // Get current effort level for spinner display
      try {
        const aiModule = require('./ai');
        const effort = typeof aiModule.getEffort === 'function' ? aiModule.getEffort() : 'high';
        spinner.setEffort(effort);
      } catch { /* best effort */ }

      let _streamTokenCount = 0;
      const streamedToolNames = new Map(); // tool_use_id -> tool name
      const streamedTaskStatus = new Map(); // task_id -> latest status
      let _lastRuntimeStatusSig = '';

      const emitRuntimeStatus = (text = '') => {
        const msg = String(text || '').trim();
        if (!msg) return;
        const sig = `status:${msg}`;
        if (sig === _lastRuntimeStatusSig) return;
        _lastRuntimeStatusSig = sig;

        // Classify status messages for rich display
        const lower = msg.toLowerCase();
        if (lower.includes('重试') || lower.includes('retry')) {
          // Retry — prominent warning
          spinner.stop();
          renderer.printStepLine('error', 'Retry', '', msg);
          spinner.start('request');
        } else if (lower.includes('responded') || lower.includes('成功')) {
          // Success — green checkmark
          spinner.stop();
          renderer.printStepLine('success', 'Connected', '', msg);
        } else if (lower.includes('failed') || lower.includes('error') || lower.includes('异常') || lower.includes('失败')) {
          // Failure — red dot
          spinner.stop();
          renderer.printStepLine('error', 'Error', '', msg);
          spinner.start('request');
        } else if (lower.includes('尝试通道') || lower.includes('switching') || lower.includes('首选通道') || lower.includes('preferred')) {
          // Adapter selection — active indicator
          spinner.stop();
          renderer.printStepLine('active', 'Adapter', '', msg);
          spinner.start('request');
        } else if (lower.includes('探测') || lower.includes('probe') || lower.includes('检测')) {
          // Probing — detail line
          spinner.setPhase('request', msg);
        } else if (lower.includes('任务模式') || lower.includes('task mode')) {
          // Task mode — just update spinner detail
          spinner.setPhase('request', msg);
        } else {
          // General status — update spinner detail text
          spinner.setPhase(spinner._phase || 'request', msg);
        }
      };

      const handleControlRequest = async ({ request, requestId }) => {
        const subtype = String(request?.subtype || '').trim().toLowerCase();
        if (subtype !== 'can_use_tool') {
          return { subtype: 'success', response: {} };
        }

        const toolName = String(request?.tool_name || request?.tool || 'tool');
        const normalizedTool = toolName.toLowerCase().replace(/[\s_-]/g, '');
        const input = (request && typeof request.input === 'object' && request.input) ? request.input : {};

        spinner.stop();
        try {
          if (normalizedTool === 'askuserquestion') {
            const questions = Array.isArray(input.questions) ? input.questions : [];
            const answers = {};

            for (const q of questions.slice(0, 4)) {
              const questionText = String(q?.question || '').trim() || 'Please choose an option';
              const qOptions = Array.isArray(q?.options) ? q.options : [];
              const renderedOptions = qOptions
                .map(opt => ({
                  label: String(opt?.label || '').trim(),
                  description: String(opt?.description || '').trim(),
                }))
                .filter(opt => opt.label);

              if (renderedOptions.length === 0) continue;

              const selection = await renderer.askInlineQuestion(questionText, renderedOptions, {
                multiSelect: !!q?.multiSelect,
                rl,
              });

              if (selection === null || selection === undefined) {
                return {
                  subtype: 'success',
                  response: {
                    behavior: 'deny',
                    message: 'User declined to answer questions',
                  },
                };
              }

              answers[questionText] = Array.isArray(selection)
                ? selection.join(', ')
                : String(selection);
            }

            return {
              subtype: 'success',
              response: {
                behavior: 'allow',
                updatedInput: { ...input, answers },
              },
            };
          }

          const permissionChoice = await renderer.askInlineQuestion(
            `Allow ${toolName}?`,
            [
              { label: 'Allow', description: 'Approve this tool call once' },
              { label: 'Deny', description: 'Reject this tool call' },
            ],
            { rl },
          );

          if (permissionChoice === 'Allow') {
            return { subtype: 'success', response: { behavior: 'allow' } };
          }
          return {
            subtype: 'success',
            response: {
              behavior: 'deny',
              message: 'Permission denied',
            },
          };
        } finally {
          spinner.start('request');
        }
      };

      let _timerResetDone = false;
      const onChunk = (chunk) => {
          // Reset spinner timer on the first received SSE event
          if (!_timerResetDone) {
            _timerResetDone = true;
            if (spinner && typeof spinner.resetTimer === 'function') spinner.resetTimer();
          }
          if (chunk.type === 'thinking') {
            spinner.stop();
            _currentOp = 'Thinking';
            updateTitlePhase('thinking');
          if (!streamState.thinkingStarted) {
            streamState.thinkingStarted = true;
            streamState.phase = 'thinking';
              console.log('');
              console.log(c.dim(`  Thinking...`));
            }
            streamThinkingChunk(chunk.text, streamState, c);
          } else if (chunk.type === 'tool_use') {
            if (streamState.phase === 'thinking') {
              closeThinkingStream(streamState);
              console.log('');
              streamState.phase = 'tool';
            }
            spinner.stop();
            _currentOp = 'Tool use';
            updateTitlePhase('tool', chunk.tool || 'Tool');
            if (chunk.id) streamedToolNames.set(String(chunk.id), chunk.tool || 'tool');
            // Always show tool_use events from adapter streaming (Codex CLI, Claude, etc.)
            {
              const toolLabel = chunk.tool || 'tool';
              const inputHint = typeof chunk.input === 'string' ? chunk.input.slice(0, 80) : '';
              renderer.printToolCallStart(toolLabel, inputHint);
            }
          } else if (chunk.type === 'tool_result') {
            // Always show tool_result events from adapter streaming
            if (chunk.content) {
              const brief = String(chunk.content).replace(/\n/g, ' ').slice(0, 80);
              const toolLabel = streamedToolNames.get(String(chunk.id || '')) || 'tool';
              const ok = !String(chunk.content).toLowerCase().includes('error');
              renderer.printStepLine(ok ? 'success' : 'error', toolLabel, '', brief);
            }
            if (chunk.id) streamedToolNames.delete(String(chunk.id));
          } else if (chunk.type === 'tool_progress') {
            spinner.stop();
            const toolName = chunk.tool || streamedToolNames.get(String(chunk.id || '')) || 'tool';
            const status = String(chunk.status || '').toLowerCase();
            const detail = String(chunk.detail || '').trim();
            if (status.includes('fail') || status.includes('error')) {
              renderer.printStepLine('error', toolName, '', detail || 'failed');
            } else if (status.includes('complete') || status.includes('success') || status === 'done') {
              renderer.printStepLine('success', toolName, '', detail || 'completed');
              if (chunk.id) streamedToolNames.delete(String(chunk.id));
            } else {
              renderer.printStepLine('active', toolName, '', detail || 'running');
            }
          } else if (chunk.type === 'task_started') {
            spinner.stop();
            const taskId = String(chunk.taskId || chunk.toolUseId || 'task');
            streamedTaskStatus.set(taskId, 'running');
            renderer.printStepLine('active', 'Task started', taskId, String(chunk.summary || '').trim());
          } else if (chunk.type === 'task_progress') {
            spinner.stop();
            const taskId = String(chunk.taskId || chunk.toolUseId || 'task');
            renderer.printStepLine('active', 'Task progress', taskId, String(chunk.summary || chunk.status || 'in progress').trim());
          } else if (chunk.type === 'task_notification') {
            spinner.stop();
            const taskId = String(chunk.taskId || chunk.toolUseId || 'task');
            const status = String(chunk.status || '').toLowerCase();
            const ok = status === 'completed' || status === 'success';
            renderer.printStepLine(ok ? 'success' : 'error', 'Task finished', taskId, String(chunk.summary || status || 'done').trim());
            streamedTaskStatus.delete(taskId);
          } else if (chunk.type === 'auth_status') {
            spinner.stop();
            if (chunk.error) {
              renderer.printStepLine('error', 'Auth', '', String(chunk.error));
            } else if (chunk.isAuthenticating) {
              renderer.printStepLine('active', 'Auth', '', String(chunk.output || 'authenticating...'));
            } else if (chunk.output) {
              emitRuntimeStatus(`Auth: ${String(chunk.output)}`);
            }
          } else if (chunk.type === 'status') {
          emitRuntimeStatus(chunk.text || 'status update');
          } else if (chunk.type === 'control_request') {
            spinner.stop();
            const req = chunk.request || {};
            const reqSubtype = String(req.subtype || '').trim() || 'control';
            const reqTool = String(req.tool_name || req.tool || '').trim();
            if (reqSubtype === 'can_use_tool') {
              renderer.printStepLine('active', 'Permission', reqTool || 'tool', `request ${chunk.requestId || ''}`.trim());
            } else {
              renderer.printStepLine('active', 'Control request', reqSubtype, `request ${chunk.requestId || ''}`.trim());
            }
          } else if (chunk.type === 'text') {
          if (streamState.phase === 'thinking') {
            closeThinkingStream(streamState);
            console.log('');
            streamState.phase = 'text';
            spinner.setPhase('generating');
          }
          // Track output tokens approximately
          if (chunk.text) {
            _streamTokenCount += Math.ceil(chunk.text.length / 4);
            spinner.setTokens(_streamTokenCount, 'output');
          }
          if (!streamState.textStarted) {
            streamState.textStarted = true;
            _currentOp = 'Generating';
            updateTitlePhase('generating');
            spinner.stop();
          }
        } else if (chunk.type === 'cost') {
          streamState.cost = chunk.cost;
          if (chunk.cost?.totalTokens) _sessionTokens = chunk.cost.totalTokens;
          // Update spinner with real token counts
          if (chunk.cost?.inputTokens) spinner.setTokens(chunk.cost.inputTokens, 'input');
          if (chunk.cost?.outputTokens) spinner.setTokens(chunk.cost.outputTokens, 'output');
        }
      };

      // Start dynamic spinner
      spinner.start('request');

      let aiResult;
      let responseAlreadyRendered = false;

      // ── QueryEngine path (KHY_QUERY_ENGINE=true) ────────────────
      let _useQueryEngine = false;
      try { _useQueryEngine = require('../services/queryEngine').isEnabled(); } catch {}

      if (_useQueryEngine) {
        try {
          const { QueryEngine } = require('../services/queryEngine');
          if (!_queryEngine) _queryEngine = new QueryEngine();
          for await (const event of _queryEngine.submitMessage(finalAiInput, {
            effort: ai().getEffort(),
          })) {
            switch (event.type) {
              case 'thinking':
                onChunk({ type: 'thinking', text: event.data });
                break;
              case 'text':
                onChunk({ type: 'text', text: event.data });
                break;
              case 'tool_call':
                spinner.stop();
                {
                  const toolName = event.data.name;
                  const activity = _toolProgressStart(toolName, event.data.params || {});
                  if (activity) {
                    renderer.printStepLine('active', activity.label, activity.target || '');
                  }
                  // Claude Code style: ⏺ ToolName(params)
                  renderer.printToolCallStart(toolName, event.data.params || {});
                }
                spinner.start('tool');
                break;
              case 'tool_result': {
                spinner.stop();
                const ok = event.data.status ? event.data.status === 'success' : !!event.data.result?.success;
                const toolName = event.data.name;
                let progressDetail = '';
                if (ok) {
                  const detail = _formatToolResult(toolName, event.data.result || {});
                  progressDetail = detail;
                  renderer.printToolCallResult(toolName, event.data.params || {}, 'success', detail, event.data.elapsed || 0);
                } else {
                  const rawErr = event.data.result?.error || event.data.result || 'failed';
                  const errStr = (rawErr && typeof rawErr === 'object')
                    ? (rawErr.message || JSON.stringify(rawErr))
                    : String(rawErr);
                  progressDetail = String(errStr).slice(0, 120);
                  renderer.printToolCallResult(toolName, event.data.params || {}, 'error', progressDetail, event.data.elapsed || 0);
                }
                const progressDone = _toolProgressDone(toolName, ok, progressDetail);
                if (progressDone) {
                  renderer.printStepLine(progressDone.status, progressDone.label, '', progressDone.detail || '');
                }
                maybeRenderWriteDiff(event.data.name, event.data.params || {}, event.data.result, c);
                maybeRenderInlineDiffFromToolOutput(event.data.name, event.data.result, c);
                break;
              }
              case 'cost':
                if (event.data?.totalTokens) _sessionTokens += event.data.totalTokens;
                break;
              case 'done':
                aiResult = event.data;
                break;
            }
          }
          spinner.stop();
        } catch (qeErr) {
          spinner.stop();
          // Fall through to legacy path on QueryEngine error
          _useQueryEngine = false;
          console.log(c.hex('#FFC107')(`  QueryEngine error: ${qeErr.message} — falling back to legacy`));
        }
      }

      if (!_useQueryEngine) {
        // ── Tool-use loop path (execution-first) ─────────────────────
        const toolUseLoop = require('../services/toolUseLoop');
        const loopManaged = toolUseLoop.isEnabled();
        // Claude Code: no busy-mode hint text
        showBusyInterjectPrompt();

        const chatFn = async (message, opts = {}) => {
          // Reset streaming state for each iteration
          streamState = { phase: 'idle', thinkingStarted: false, textStarted: false, thinkingLineOpen: false, thinkingCol: 0, _inToolLoop: true };
          let _lastStatusLine = '';
          let _lastStatusLineAt = 0;
          let _lastStatusText = '';
          let _lastStatusTextAt = 0;
          let _liveStatusOpen = false;
          let _liveStatusKey = '';
          const _statusDedupMs = (() => {
            const raw = process.env.KHY_AI_STATUS_DEDUP_MS || process.env.GATEWAY_STATUS_DEDUP_MS || '1500';
            const parsed = Number.parseInt(String(raw).trim(), 10);
            if (!Number.isFinite(parsed) || parsed < 200) return 1500;
            return parsed;
          })();
          const _normalizeProgressKey = (phase, text) => {
            const normalized = String(text || '')
              .replace(/（\d+s）/g, '(Xs)')
              .replace(/\b\d+s\b/g, 'Xs')
              .replace(/\.{3}\s*\d+s/gi, '... Xs')
              .trim();
            return `${phase}:${normalized}`;
          };
          const _isDynamicProgressStatus = (phase, text) => (
            phase === 'request'
            && /处理中（\d+s）|等待模型响应中\.\.\.\s*\d+s/i.test(String(text || ''))
          );
          const _flushLiveStatusLine = () => {
            if (!_liveStatusOpen) return;
            try { process.stdout.write('\n'); } catch { /* ignore */ }
            _liveStatusOpen = false;
            _liveStatusKey = '';
          };

          // Claude Code: just spinner, no "Requesting AI" text line
          spinner.start('request');

          let result;
          try {
            const { startWatchdog, WATCHDOG_TIMEOUT_MS, withTimeout } = require('../services/resourceGuard');
            const isLargeTask = (() => {
              const text = String(message || '');
              return text.length >= 700
                || /大型任务|大任务|完整实现|全量|全流程|端到端|deep|exhaustive|full implementation|end-to-end/i.test(text);
            })();
            const largeTaskMinTimeoutMs = parseInt(String(process.env.KHY_AI_REQUEST_TIMEOUT_LARGE_MS || '900000'), 10) || 900000;
            const timeoutMs = Math.max(
              isLargeTask ? Math.max(300000, largeTaskMinTimeoutMs) : 300000, // large tasks get wider budget
              Number(process.env.KHY_AI_REQUEST_TIMEOUT_MS || WATCHDOG_TIMEOUT_MS),
            );
            const wd = startWatchdog('ai-chat', WATCHDOG_TIMEOUT_MS, () => {
              spinner.stop();
              console.log(c.hex('#FF6B80')('\n  AI 请求超时'));
            });
            try {
              result = await withTimeout(ai().chat(message, {
                ...opts,
                disableNaturalToolLoop: loopManaged,
                onChunk,
                onControlRequest: opts.onControlRequest || handleControlRequest,
                onStatus: (status) => {
                  if (status.phase === 'compacted') {
                    _flushLiveStatusLine();
                    spinner.stop();
                    console.log(`\n${c.hex('#D77757')('✻')} ${c.bold('对话已压缩')} ${c.dim('(ctrl+o 查看历史)')}`);
                    spinner.start('request');
                    return;
                  }
                  const phase = String(status && status.phase ? status.phase : '').trim();
                  const text = String(status && status.message ? status.message : '').replace(/\s+/g, ' ').trim();
                  if (!text || phase === 'done') return;
                  const now = Date.now();
                  const sig = `${phase}:${text}`;
                  if (sig === _lastStatusLine && (now - _lastStatusLineAt) < _statusDedupMs) return;
                  if (text === _lastStatusText && (now - _lastStatusTextAt) < _statusDedupMs) return;
                  _lastStatusLine = sig;
                  _lastStatusLineAt = now;
                  _lastStatusText = text;
                  _lastStatusTextAt = now;
                  if (_isDynamicProgressStatus(phase, text)) {
                    spinner.stop();
                    const liveKey = _normalizeProgressKey(phase, text);
                    if (!_liveStatusOpen || _liveStatusKey !== liveKey) {
                      if (_liveStatusOpen) _flushLiveStatusLine();
                      try { process.stdout.write(c.dim(`  · ${text}`)); } catch { console.log(c.dim(`  · ${text}`)); }
                      _liveStatusOpen = true;
                      _liveStatusKey = liveKey;
                    } else {
                      try { process.stdout.write(`\r\x1b[K${c.dim(`  · ${text}`)}`); } catch { /* ignore */ }
                    }
                    spinner.start('request');
                    return;
                  }
                  _flushLiveStatusLine();
                  spinner.stop();

                  // Tool progress from ai.chat() natural tool loop — show with step indicators
                  if (phase === 'tool_progress') {
                    const toolName = status.toolName || '';
                    const success = status.success;
                    if (success === true) {
                      renderer.printStepLine('success', toolName || 'Tool', '', text);
                    } else if (success === false) {
                      renderer.printStepLine('error', toolName || 'Tool', '', text);
                    } else {
                      renderer.printStepLine('active', toolName || 'Tool', '', text);
                    }
                    spinner.start('request');
                    return;
                  }

                  if (phase === 'plan') {
                    renderer.printStepLine('active', 'Plan', '', text);
                    spinner.start('request');
                    return;
                  }

                  if (phase === 'summary') {
                    renderer.printStepLine('done', 'Summary', '', text);
                    spinner.start('request');
                    return;
                  }

                  // Classify onStatus messages for rich display
                  const _lower = text.toLowerCase();
                  if (_lower.includes('重试') || _lower.includes('retry')) {
                    renderer.printStepLine('error', 'Retry', '', text);
                  } else if (_lower.includes('responded') || _lower.includes('已连接')) {
                    renderer.printStepLine('success', 'Connected', '', text);
                  } else if (_lower.includes('failed') || _lower.includes('error') || _lower.includes('异常') || _lower.includes('失败')) {
                    renderer.printStepLine('error', 'Error', '', text);
                  } else if (_lower.includes('尝试通道') || _lower.includes('switching') || _lower.includes('首选通道')) {
                    renderer.printStepLine('active', 'Adapter', '', text);
                  } else {
                    console.log(c.dim(`  · ${text}`));
                  }
                  spinner.start('request');
                },
                onWait: (adapterKey, waitMs) => {
                  try {
                    _flushLiveStatusLine();
                    spinner.stop();
                    const sec = Math.max(0, Number(waitMs || 0) / 1000);
                    renderer.printStepLine('active', 'Rate limit', adapterKey || 'adapter', `等待 ${sec.toFixed(1)}s`);
                    spinner.start('request');
                  } catch { /* best effort */ }
                },
                onFallback: (info) => {
                  _flushLiveStatusLine();
                  spinner.stop();
                  const statusCode = info.failedStatusCode ? ` (${info.failedStatusCode})` : '';
                  renderer.printStepLine('error', 'Fallback', info.failedAdapter || '', `${info.failedError || 'failed'}${statusCode}`);
                  if (info.nextAdapter) {
                    renderer.printStepLine('active', 'Switching', info.nextAdapter, '');
                  }
                  spinner.start('request');
                },
              }), timeoutMs, 'AI request');
            } finally {
              wd.done();
            }
          } catch (wdErr) {
            spinner.stop();
            if (tracker.isActive) tracker.complete();
            throw wdErr;
          }

          spinner.stop();
          _flushLiveStatusLine();

          if (streamState.phase === 'thinking') {
            closeThinkingStream(streamState);
            console.log('');
          }

          // Update context usage for auto-compact display
          if (result && result.tokenUsage) {
            try {
              const hud = require('./hudRenderer');
              const totalUsed = (result.tokenUsage.totalTokens || 0) + (hud.getState().contextWindow.used || 0);
              hud.setContextUsage(totalUsed);
              hud.updateTokens(result.tokenUsage);
            } catch { /* best-effort */ }
          }

          // Print completion summary with stats (provider, elapsed, tokens)
          if (result && result.content) {
            const elapsed = result.elapsed || result.elapsedMs || (Date.now() - (result._startTime || Date.now()));
            const elapsedSec = typeof elapsed === 'number' && elapsed > 0 ? (elapsed / 1000).toFixed(1) : null;
            const provider = result.provider || result.adapter || result.actualAdapter || '';
            const model = result.model || '';
            const tokens = result.tokenUsage;
            const parts = [];
            if (provider) parts.push(provider);
            if (model && model !== provider) parts.push(model);
            if (elapsedSec) parts.push(`${elapsedSec}s`);
            if (tokens) {
              const inT = tokens.inputTokens || tokens.promptTokens || 0;
              const outT = tokens.outputTokens || tokens.completionTokens || 0;
              if (inT || outT) {
                const fmt = (n) => n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n);
                parts.push(`↑${fmt(inT)} ↓${fmt(outT)}`);
              }
            }
            if (parts.length > 0) {
              console.log(c.dim(`  ${parts.join(' · ')}`));
            }
          }
          return result;
        };

        let loopResult;
        let loopIterations = 0;
        let _loopToolCount = 0;
        const _loopStartTime = Date.now();

        if (toolUseLoop.isEnabled()) {
          // Claude Code-style read/search collapse tracking
          const READ_SEARCH_TOOLS = new Set([
            'read_file', 'readFile', 'grep', 'glob', 'search',
            'find_files', 'findFiles', 'search_content', 'searchContent',
            'git_status', 'gitStatus', 'git_diff', 'gitDiff', 'git_log',
            'explore', 'search_codebase', 'find_code', 'codebase_search',
          ]);
          let _collapseGroup = { count: 0, searches: 0, reads: 0, files: new Set(), patterns: [] };
          const _flushCollapseGroup = () => {
            if (_collapseGroup.count <= 1) return; // Don't collapse single operations
            const parts = [];
            if (_collapseGroup.searches > 0) parts.push(`搜索 ${_collapseGroup.searches} 次`);
            if (_collapseGroup.reads > 0) parts.push(`读取 ${_collapseGroup.reads} 个文件`);
            if (parts.length > 0) {
              const summary = parts.join('，');
              renderer.printStepLine('success', 'Explored', '', `${summary} (ctrl+o 展开)`);
              const patternPreview = _collapseGroup.patterns
                .map(p => String(p || '').trim())
                .filter(Boolean)
                .slice(0, 3);
              if (patternPreview.length > 0) {
                renderer.printStepDetail(`Patterns: ${patternPreview.join(' | ')}`);
              }
              const filePreview = [..._collapseGroup.files]
                .map(f => String(f || '').trim())
                .filter(Boolean)
                .slice(0, 4);
              if (filePreview.length > 0) {
                renderer.printStepDetail(`Read: ${filePreview.join(', ')}`);
              }
            }
            _collapseGroup = { count: 0, searches: 0, reads: 0, files: new Set(), patterns: [] };
          };

          loopResult = await toolUseLoop.runToolUseLoop(finalAiInput, {
            chat: chatFn,
            chatOpts: _inlineImageOpts || {},
            maxIterations: (() => {
              const base = parseInt(String(process.env.KHY_TOOL_LOOP_MAX_ITERATIONS || '12'), 10) || 12;
              const boost = String(finalAiInput || '').length >= 700 ? 6 : 0;
              return Math.max(8, Math.min(40, base + boost));
            })(),
            onIteration: (iteration) => {
              loopIterations = iteration;
              // Flush collapse group between iterations (AI is about to make new decisions)
              if (iteration > 1) _flushCollapseGroup();
            },
            onToolCall: (toolName, params) => {
              _currentOp = 'Tool use';
              _loopToolCount++;
              spinner.stop();
              updateTitlePhase('tool', mapToolToPhaseLabel(toolName));

              const activity = _toolProgressStart(toolName, params || {});
              if (activity) {
                renderer.printStepLine('active', activity.label, activity.target || '');
                const reason = _toolProgressReason(toolName, params || {});
                if (reason) renderer.printStepDetail(reason);
              }

              const normalizedName = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
              const isReadSearch = READ_SEARCH_TOOLS.has(toolName) || READ_SEARCH_TOOLS.has(normalizedName);

              if (isReadSearch) {
                // Track in collapse group — show individual lines but track for summary
                _collapseGroup.count++;
                if (/grep|search|glob|find|explore/i.test(toolName)) {
                  _collapseGroup.searches++;
                  if (params?.pattern) _collapseGroup.patterns.push(params.pattern);
                } else {
                  _collapseGroup.reads++;
                  const filePath = params?.path || params?.file_path || params?.filePath || '';
                  if (filePath) _collapseGroup.files.add(filePath);
                }
              } else {
                // Non-read-search tool: flush any pending collapse group
                _flushCollapseGroup();
              }

              // Claude Code: ⏺ ToolName(params) — one clean line per tool
              renderer.printToolCallStart(toolName, params);

              // Agent tools get special treatment: show running header
              const normName = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
              if (normName === 'agent' || normName === 'spawnworker' || normName === 'subagent') {
                const role = params?.role || 'general';
                const prompt = (params?.prompt || '').slice(0, 50);
                renderer.renderAgentHeader(1, `${role}: ${prompt}...`);
              }
            },
            onParallelBatch: (calls) => {
              // Show parallel agent count if multiple agents spawned
              const agentCalls = calls.filter(c =>
                /^(agent|spawn_worker|sub_agent)$/i.test(String(c.name).replace(/[\s_-]/g, ''))
              );
              if (agentCalls.length >= 2) {
                renderer.renderAgentHeader(agentCalls.length, '(ctrl+o to expand)');
                const agentInfos = agentCalls.map(c => ({
                  name: `${c.params?.role || 'general'} agent`,
                  status: 'running',
                  detail: (c.params?.prompt || '').slice(0, 60),
                }));
                renderer.renderAgentProgress(agentInfos);
              }
            },
            onToolResult: (toolName, params, result, _iteration, elapsedMs) => {
              // Claude Code: overwrite tool start line with success/error dot + ⎿ result
              const status = (result && result.success) ? 'success' : 'error';
              let detail = '';
              if (result && result.denied) {
                detail = 'Permission denied';
              } else if (result && result.success) {
                detail = _formatToolResult(toolName, result);
              } else {
                const err = result && result.error;
                detail = (err && typeof err === 'object')
                  ? (err.message || JSON.stringify(err))
                  : (err || 'failed');
                detail = String(detail).slice(0, 120);
              }
              renderer.printToolCallResult(toolName, params, status, detail, elapsedMs || 0);
              const activityDone = _toolProgressDone(toolName, status === 'success', detail);
              if (activityDone) {
                renderer.printStepLine(activityDone.status, activityDone.label, '', activityDone.detail || '');
              }
              maybeRenderWriteDiff(toolName, params, result, c);
              maybeRenderInlineDiffFromToolOutput(toolName, result, c);
            },
          });
          // Flush any remaining collapse group
          _flushCollapseGroup();
        } else {
          const r = await chatFn(finalAiInput, _inlineImageOpts || {});
          loopResult = {
            finalResponse: r.reply,
            provider: r.provider,
            tokenUsage: r.tokenUsage,
            errorType: r.errorType || null,
            iterations: 1,
            toolCallLog: [],
          };
        }

        aiResult = {
          reply: loopResult.finalResponse || '',
          provider: loopResult.provider,
          tokenUsage: loopResult.tokenUsage,
          errorType: loopResult.errorType || null,
          elapsed: 0,
        };

        if (loopIterations > 0) {
          const log = (loopResult.toolCallLog || []).filter(t => t.tool !== '_legacy_cmd');
          const toolCount = log.length;
          if (toolCount > 0) {
            // Claude Code style summary: "Searched for N patterns, read M files (ctrl+o to expand)"
            const searches = log.filter(t => /grep|glob|search|find/i.test(t.tool)).length;
            const reads = log.filter(t => /read/i.test(t.tool)).length;
            const writes = log.filter(t => /write|edit/i.test(t.tool)).length;
            const bashes = log.filter(t => /bash|shell|command/i.test(t.tool)).length;
            const parts = [];
            if (searches > 0) parts.push(`搜索 ${searches} 次`);
            if (reads > 0) parts.push(`读取 ${reads} 个文件`);
            if (writes > 0) parts.push(`写入 ${writes} 个文件`);
            if (bashes > 0) parts.push(`执行 ${bashes} 条命令`);
            const summary = parts.length > 0 ? parts.join('，') : `${toolCount} 次工具调用`;
            console.log('');
            console.log(c.dim(`  ${summary} (ctrl+o 展开详情)`));
            console.log('');
          }
        }

        if (loopResult.consecutiveFailureBailout) {
          console.log(c.hex('#FFC107')('  连续工具调用失败，已停止重试'));
        } else if (loopResult.timeLimitReached) {
          const limitMs = Number(loopResult.maxElapsedMs || 0);
          const totalSec = Math.max(1, Math.ceil(limitMs / 1000));
          const m = Math.floor(totalSec / 60);
          const s = totalSec % 60;
          const limitText = (m > 0 && s > 0) ? `${m}m ${s}s` : (m > 0 ? `${m}m` : `${s}s`);
          console.log(c.hex('#FFC107')(`  工具循环超时 (>${limitText})，返回已收集结果`));
        } else if (loopResult.maxIterationsReached) {
          console.log(c.hex('#FFC107')(`  达到最大迭代次数 (${loopResult.iterations})，返回最后结果`));
        }
      } // end if (!_useQueryEngine)

      // Close thinking block if it was still open
      if (streamState.phase === 'thinking') {
        closeThinkingStream(streamState);
        console.log('');
      }

      if (aiResult.reply && !responseAlreadyRendered) {
        if (aiResult.errorType) {
          printError(aiResult.reply);
          console.log('');
        } else {
          // Update terminal title with conversation topic
          updateTitleFromConversation(aiInput);

          // Update session tokens for prompt frame display
          if (aiResult.tokenUsage?.totalTokens) {
            _sessionTokens += aiResult.tokenUsage.totalTokens;
          }

          // Build meta info line (Claude Code style)
          const elapsedSec = aiResult.elapsed ? `${(aiResult.elapsed / 1000).toFixed(1)}s` : '';
	          const tokenCount = aiResult.tokenUsage
	            ? `↑ ${aiResult.tokenUsage.totalTokens?.toLocaleString() || '?'} tokens` : '';
	          const thinkTime = streamState.thinkingStarted ? 'thought' : '';
          const toolSummaryText = formatToolSummary(aiResult.toolSummary);
	          const metaParts = [elapsedSec, tokenCount, thinkTime].filter(Boolean);
	          const metaTag = metaParts.length > 0 ? c.dim(` (${metaParts.join(' · ')})`) : '';

          // Claude Code style: no "AI response" header — just render the response text directly

          // Render with diff highlighting and markdown-lite
          const rendered = renderer.renderAiResponse(aiResult.reply);
          const lines = rendered.split('\n');
          lines.forEach(l => console.log(`  ${l}`));

          // Compacting notice — only when context is actually getting large (>80% of limit)
          try {
            const hud = require('./hudRenderer');
            const state = hud.getState();
            const usedPct = state.contextWindow.limit > 0
              ? (state.sessionTokens.total / state.contextWindow.limit) * 100
              : 0;
            if (usedPct > 80) {
              renderer.printCompactingNotice({
                tokens: state.sessionTokens.total?.toLocaleString() || '?',
              });
            }
          } catch { /* best effort */ }

          // Extract and display task plan if AI response contains numbered steps
          try {
            const planPattern = /执行计划|分析步骤|操作步骤|回测计划|分步|plan|steps|implementation/i;
            if (planPattern.test(aiResult.reply) || needsPlan) {
              const planTracker = new renderer.TaskPlanTracker();
              if (planTracker.extractFromResponse(aiResult.reply)) {
                planTracker.render();
              }
            }
          } catch { /* best effort */ }

          // Claude Code style: show random Tip after AI response (throttled)
          try {
            if (!_lastTipShown || (Date.now() - _lastTipShown > 120000)) {
              const tips = [
                '输入 /clear 切换话题时清空上下文',
                '按 Ctrl+C 中断当前 AI 请求',
                '↑/↓ 方向键浏览历史命令',
                '拖拽文件到终端可附带文件内容',
                '输入 /plan 让 AI 先规划再执行复杂任务',
                '输入 /btw 在 AI 工作时补充提示',
                '输入 /resume 恢复上次对话',
              ];
              const tip = tips[Math.floor(Math.random() * tips.length)];
              console.log('');
              console.log(c.dim(`    Tip: ${tip}`));
              _lastTipShown = Date.now();
            }
          } catch { /* tips are best-effort */ }

          // Detect inline options in AI response (numbered lists ending with ?)
          // Pattern: AI asks a question with numbered options like "1. xxx\n2. xxx\n请选择"
          try {
            const optionPattern = /(?:^|\n)\s*(\d)\.\s+(.+)/g;
            const questionPattern = /请选择|你想|哪个|选哪|怎么做|如何选/;
            const hasQuestion = questionPattern.test(aiResult.reply);

            if (hasQuestion) {
              const matches = [...aiResult.reply.matchAll(optionPattern)];
              if (matches.length >= 2 && matches.length <= 6) {
                const options = matches.map(m => ({ label: m[2].trim() }));
                const selection = await renderer.askInlineQuestion(
                  'AI needs your choice:',
                  options,
                  { rl }
                );
                if (selection) {
                  _btwQueue.push(`Selected: ${Array.isArray(selection) ? selection.join(', ') : selection}`);
                  console.log(c.hex('#4EBA65')(`  Selected: ${Array.isArray(selection) ? selection.join(', ') : selection}`));
                }
              }
            }
          } catch { /* interactive selection is best-effort */ }
        }

        console.log('');
      } else if (!aiResult.reply && !responseAlreadyRendered) {
        // Truly empty reply — inform user
        printInfo('AI 未返回有效回复 — 请重试或检查连接');
        console.log('');
      }

      // Execute any embedded commands with Claude Code-style tool call display
      // Also handle <tool_call> tags via the new tool-use loop
      if (aiResult.commands && aiResult.commands.length > 0) {
        console.log('');
        const toolCallStats = { toolCalls: 0, startTime: Date.now() };
        for (const cmd of aiResult.commands) {
          const cmdParts = cmd.split(/\s+/);
          const cmdLabel = cmdParts[0] || cmd;
          const cmdTarget = cmdParts.slice(1).join(' ') || '';
          toolCallStats.toolCalls++;

          // Show Claude Code-style tool call start
          renderer.printToolCallStart(cmdLabel, cmdTarget || cmd);
          const cmdStart = Date.now();

          try {
            const cmdParsed = parseInput(cmd);
            if (cmdParsed) {
              // Capture output by temporarily redirecting console.log
              const origLog = console.log;
              const output = [];
              console.log = (...args) => {
                const line = args.map(a => typeof a === 'string' ? a : String(a)).join(' ');
                output.push(line);
              };
              try {
                await route(cmdParsed);
              } finally {
                console.log = origLog;
              }

              const cmdElapsed = Date.now() - cmdStart;

              // Show condensed result via tool call result display
              const condensed = output.filter(l => l.trim()).slice(0, 5);
              const cleanLines = condensed.map(l => l.replace(/\x1b\[[0-9;]*m/g, '').trim().slice(0, 80));
              const detail = cleanLines.length > 0 ? cleanLines[0] : `${cmdLabel} completed`;
              const moreLines = output.filter(l => l.trim()).length;

              renderer.printToolCallResult(
                cmdLabel,
                cmdTarget || cmd,
                'success',
                moreLines > 1 ? `${detail} (+${moreLines - 1} more lines)` : detail,
                cmdElapsed
              );
            } else {
              renderer.printToolCallResult(cmdLabel, cmd, 'error', 'Cannot parse command', 0);
            }
          } catch (cmdErr) {
            renderer.printToolCallResult(
              cmdLabel, cmd, 'error',
              cmdErr.message || 'Execution failed',
              Date.now() - cmdStart
            );
          }
        }
        // Show completion summary
        renderer.renderAgentDone({
          toolCalls: toolCallStats.toolCalls,
          elapsedMs: Date.now() - toolCallStats.startTime,
        });
      }

    } catch (err) {
      try { printError(err?.message || String(err) || '执行出错'); } catch { /* ignore */ }
    } finally {
      _busy = false;
      _currentOp = '';
      updateTitlePhase('idle');
      try {
        const renderer = require('./aiRenderer');
        if (typeof renderer.setInteractiveGuard === 'function') renderer.setInteractiveGuard(null);
      } catch { /* non-critical */ }
      // Ensure terminal is in a clean state after AI streaming
      if (process.stdout.isTTY) {
        process.stdout.write('\x1b[?25h'); // show cursor (in case hidden during streaming)
      }
      // Resume vim handler after command execution
      if (_vimHandler) try { _vimHandler.resume(); } catch { /* ignore */ }
      // Re-enable frame rendering so decoration lines appear on next prompt
      leaveInputPromptFrame();
      const nextQueued = _queuedInputs.shift();
      if (nextQueued) {
        try {
          const queuedPreview = nextQueued.replace(/\n/g, ' ').slice(0, 48);
          console.log(c.dim(`  ↳ 继续处理排队输入: "${queuedPreview}${queuedPreview.length >= 48 ? '...' : ''}"`));
          setImmediate(() => rl.emit('line', `${INTERNAL_LINE_PREFIX}${nextQueued}`));
          return;
        } catch { /* fallthrough to prompt */ }
      }
      try { rl.prompt(); } catch { /* readline may be destroyed */ }
    }
  });

  // Handle Ctrl+C — require double-press within 2s to exit (prevent accidental exit)
  rl.on('SIGINT', () => {
    if (_busy) {
      // Keep loop state coherent; avoid force-clearing busy while async flow
      // is still running, which can cause "stopped unexpectedly" behavior.
      try {
        const gateway = require('../services/gateway/aiGateway');
        const relay = gateway.getRelayAdapter();
        if (relay && typeof relay.cancelPending === 'function' && relay.cancelPending('Interrupted by Ctrl+C')) {
          console.log(c.hex('#FFC107')('\n  Interrupted web relay request, returning'));
          return;
        }
      } catch { /* non-critical */ }
      console.log(c.hex('#FFC107')('\n  Interrupt requested, will return after current step'));
      rl.prompt();
      return;
    }

    _ctrlCCount++;
    if (_ctrlCCount >= 2) {
      // Double Ctrl+C confirmed — exit
      ai().saveConversation();
      saveHistory(history);
      setTerminalTitle(''); // restore terminal title
      console.log('');
      console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
      console.log(c.dim('  对话摘要已保存'));
      console.log('');
      _intentionalExit = true; process.exit(0);
    } else {
      console.log(c.hex('#FFC107')('\n  Press Ctrl+C again to exit, or type resume to continue'));
      if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
      _ctrlCTimer = setTimeout(() => { _ctrlCCount = 0; }, 2000);
      rl.prompt();
    }
  });

  // Handle Ctrl+D (EOF) — save and exit gracefully
  // Guard: inquirer may close stdin which triggers 'close' on our readline.
  // _intentionalExit is set by /exit and double-Ctrl+C. For Ctrl+D (real EOF),
  // we check if inquirer is active — if not, it's a genuine exit request.
  rl.on('close', () => {
    if (_intentionalExit) {
      // Already handled (e.g., /exit command triggered process.exit above)
      return;
    }
    if (_inquirerActive) {
      // Triggered by inquirer closing stdin — reopen readline
      try {
        process.stdin.resume();
        if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
          process.stdin.setRawMode(true);
        }
        rl.resume();
        rl.prompt();
      } catch { /* ignore */ }
      return;
    }
    // Real EOF (Ctrl+D) — save and exit
    for (const t of _startupTimers) clearTimeout(t);
    clearInterval(_tipTimer);
    if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
    try { require('../services/resourceGuard').cancelAll(); } catch { /* ignore */ }
    ai().saveConversation();
    saveHistory(history);
    setTerminalTitle('');
    console.log('');
    console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
    console.log(c.dim('  对话摘要已保存，下次输入 /resume 恢复'));
    console.log('');
    process.exit(0);
  });
}

module.exports = { startRepl };
