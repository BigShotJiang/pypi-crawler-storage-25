/**
 * Non-Interactive Mode — headless JSON protocol for CI/CD and IDE integration.
 *
 * Protocol:
 *   Input  (stdin, one JSON per line):  { "type": "prompt", "content": "...", "options": {} }
 *   Output (stdout, one JSON per line): { "type": "response"|"tool_call"|"error"|"done", ... }
 *
 * Usage:
 *   echo '{"type":"prompt","content":"list strategies"}' | khy --non-interactive
 *   khy --non-interactive < commands.jsonl
 */
const readline = require('readline');

/**
 * Start non-interactive session.
 * @param {Object} deps - Injected dependencies
 * @param {Function} deps.processMessage - async (message, options) => AsyncGenerator<chunk>
 * @param {Object} deps.options - Session options
 */
async function startNonInteractive(deps) {
  const { processMessage, options = {} } = deps;

  const rl = readline.createInterface({
    input: process.stdin,
    output: null, // don't echo
    terminal: false,
  });

  _emit({ type: 'ready', version: '1.0.0', capabilities: ['prompt', 'tool_call'] });

  rl.on('line', async (line) => {
    const trimmed = line.trim();
    if (!trimmed) return;

    let msg;
    try {
      msg = JSON.parse(trimmed);
    } catch {
      _emit({ type: 'error', error: 'Invalid JSON input' });
      return;
    }

    if (msg.type === 'prompt') {
      await _handlePrompt(msg, processMessage, options);
    } else if (msg.type === 'ping') {
      _emit({ type: 'pong', ts: Date.now() });
    } else if (msg.type === 'exit') {
      _emit({ type: 'done', reason: 'client_exit' });
      process.exit(0);
    } else {
      _emit({ type: 'error', error: `Unknown message type: ${msg.type}` });
    }
  });

  rl.on('close', () => {
    process.exit(0);
  });
}

async function _handlePrompt(msg, processMessage, options) {
  const { content, requestId } = msg;
  if (!content) {
    _emit({ type: 'error', error: 'Missing "content" field', requestId });
    return;
  }

  try {
    const generator = processMessage(content, { ...options, ...msg.options });

    if (generator && typeof generator[Symbol.asyncIterator] === 'function') {
      for await (const chunk of generator) {
        _emit({ type: 'chunk', content: chunk, requestId });
      }
    } else if (generator && typeof generator.then === 'function') {
      const result = await generator;
      _emit({ type: 'response', content: result, requestId });
    } else {
      _emit({ type: 'response', content: String(generator), requestId });
    }

    _emit({ type: 'done', requestId });
  } catch (err) {
    _emit({ type: 'error', error: err.message, requestId });
  }
}

function _emit(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

/**
 * Check if we should run in non-interactive mode.
 */
function shouldRunNonInteractive() {
  return process.argv.includes('--non-interactive')
    || process.argv.includes('--headless')
    || process.argv.includes('-H')
    || !process.stdin.isTTY;
}

module.exports = { startNonInteractive, shouldRunNonInteractive };
