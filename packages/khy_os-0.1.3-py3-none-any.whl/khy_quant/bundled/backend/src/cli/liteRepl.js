/**
 * Lightweight AI REPL — zero-start mode.
 *
 * Launched via `khy ai` — skips auth, server, and all heavy startup services.
 * Reuses ai.js chat engine, aiGateway adapters, router commands, and all
 * rendering components (aiRenderer, agentRenderer, planModeService).
 *
 * Target: <200ms to first prompt.
 */
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { renderSideBySideDiff } = require('./ui/diffViewer');

// ── Lazy module loaders ──
let _chalk, _fmt, _router, _ai, _inquirer;
let _inquirerActive = false; // Track whether inquirer is using stdin (for Ctrl+D guard)
const c = () => {
  if (_chalk) return _chalk;
  const chalkModule = require('chalk');
  _chalk = chalkModule.default || chalkModule;
  return _chalk;
};
const fmt = () => (_fmt ??= require('./formatters'));
const router = () => (_router ??= require('./router'));
const ai = () => (_ai ??= require('./ai'));
const inquirer = () => (_inquirer ??= require('inquirer'));

/**
 * Wrapper for inquirer.prompt that sets _inquirerActive flag.
 * This prevents real Ctrl+D from being swallowed by the close handler.
 */
async function inqPrompt(questions) {
  _inquirerActive = true;
  try {
    return await inquirer().prompt(questions);
  } finally {
    _inquirerActive = false;
  }
}

function _splitShellLikeArgs(raw = '') {
  return String(raw || '').match(/"[^"]*"|'[^']*'|\S+/g) || [];
}

function _unquoteArg(token = '') {
  return String(token || '').replace(/^["']|["']$/g, '');
}

function _parseStudyCommand(trimmed = '') {
  const matched = /^\/study(?:\s+([\s\S]+))?$/i.exec(String(trimmed || ''));
  if (!matched) return null;

  const tokens = _splitShellLikeArgs(matched[1] || '');
  const out = { action: 'status', secret: '', invalid: [] };

  for (let i = 0; i < tokens.length; i++) {
    const token = String(tokens[i] || '');
    const lower = token.toLowerCase();

    if (lower === 'on' || lower === 'off' || lower === 'status') {
      out.action = lower;
      continue;
    }

    if (lower === '--secret' || lower === '-s') {
      if (i + 1 < tokens.length) {
        out.secret = _unquoteArg(tokens[i + 1]);
        i++;
      } else {
        out.invalid.push(token);
      }
      continue;
    }

    if (lower.startsWith('--secret=')) {
      out.secret = _unquoteArg(token.slice(token.indexOf('=') + 1));
      continue;
    }

    out.invalid.push(token);
  }

  return out;
}

async function _verifyStudyOwnerSecret(providedSecret = '') {
  const owner = require('../services/ownerControlService');
  if (!owner.isOwnerControlConfigured()) {
    return {
      ok: false,
      error: 'Owner 控制未初始化。请先由管理员执行: ai owner init',
    };
  }

  let secret = String(providedSecret || '').trim();
  if (!secret && process.stdin.isTTY && process.stdout.isTTY) {
    try {
      const answer = await inqPrompt([{
        type: 'password',
        name: 'secret',
        message: 'Owner secret:',
        mask: '*',
        validate: v => String(v || '').trim().length > 0 || 'Secret 不能为空',
      }]);
      secret = String(answer.secret || '').trim();
    } catch {
      return { ok: false, error: '已取消 Owner Secret 输入' };
    }
  }

  if (!secret) {
    return {
      ok: false,
      error: '缺少 Owner Secret。用法: /study on --secret <value>',
    };
  }

  const verify = owner.verifyOwnerSecret(secret);
  if (!verify.ok) {
    return { ok: false, error: verify.error || 'Owner Secret 校验失败。' };
  }

  return { ok: true };
}

function _parseToggleAction(trimmed = '', cmd = '') {
  const raw = String(trimmed || '').trim();
  const prefix = `/${String(cmd || '').trim()}`;
  if (!prefix || prefix === '/') return null;
  if (!raw.toLowerCase().startsWith(prefix.toLowerCase())) return null;

  const rest = raw.slice(prefix.length).trim();
  if (!rest) return 'status';

  const action = rest.split(/\s+/)[0].toLowerCase();
  if (action === 'on' || action === 'off' || action === 'status') return action;
  return 'invalid';
}

function _parseCompactArgs(trimmed = '') {
  const matched = /^\/compact(?:\s+([\s\S]+))?$/i.exec(String(trimmed || ''));
  if (!matched) return null;

  const tokens = _splitShellLikeArgs(matched[1] || '');
  const out = { keepRecent: 12, mode: 'balanced', instructions: '', invalid: [] };
  const freeTokens = [];

  const isMode = (v) => ['light', 'balanced', 'aggressive', 'auto'].includes(v);

  for (let i = 0; i < tokens.length; i++) {
    const token = String(tokens[i] || '');
    const lower = token.toLowerCase();

    if (isMode(lower)) {
      out.mode = lower;
      continue;
    }

    if (lower === '--keep') {
      const next = String(tokens[i + 1] || '');
      const n = parseInt(next, 10);
      if (Number.isFinite(n)) {
        out.keepRecent = Math.max(4, Math.min(40, n));
        i++;
      } else {
        out.invalid.push(token);
      }
      continue;
    }

    if (lower.startsWith('--keep=')) {
      const n = parseInt(lower.slice('--keep='.length), 10);
      if (Number.isFinite(n)) {
        out.keepRecent = Math.max(4, Math.min(40, n));
      } else {
        out.invalid.push(token);
      }
      continue;
    }

    if (lower === '--mode') {
      const next = String(tokens[i + 1] || '').toLowerCase();
      if (isMode(next)) {
        out.mode = next;
        i++;
      } else {
        out.invalid.push(token);
      }
      continue;
    }

    if (lower.startsWith('--mode=')) {
      const v = lower.slice('--mode='.length);
      if (isMode(v)) out.mode = v;
      else out.invalid.push(token);
      continue;
    }

    freeTokens.push(_unquoteArg(token));
  }

  out.instructions = freeTokens.join(' ').trim();
  return out;
}

function _formatOnOff(v) { return v ? 'ON' : 'OFF'; }

function _normalizeMentionTrigger(name = '') {
  const cleaned = String(name || '').trim().replace(/^@+/, '').replace(/\s+/g, '');
  return cleaned || 'khy';
}

function _parseActivationCommand(trimmed = '') {
  const matched = /^\/activation(?:\s+([\s\S]+))?$/i.exec(String(trimmed || ''));
  if (!matched) return null;

  const tokens = _splitShellLikeArgs(matched[1] || '');
  const out = { action: 'status', name: '', invalid: [] };

  for (let i = 0; i < tokens.length; i++) {
    const token = String(tokens[i] || '');
    const lower = token.toLowerCase();

    if (lower === 'always' || lower === 'mention' || lower === 'status') {
      out.action = lower;
      continue;
    }

    if (lower === '--name' || lower === '-n' || lower === '--trigger') {
      if (i + 1 < tokens.length) {
        out.name = _normalizeMentionTrigger(_unquoteArg(tokens[i + 1]));
        i++;
      } else {
        out.invalid.push(token);
      }
      continue;
    }

    if (lower.startsWith('--name=') || lower.startsWith('--trigger=')) {
      out.name = _normalizeMentionTrigger(_unquoteArg(token.slice(token.indexOf('=') + 1)));
      continue;
    }

    out.invalid.push(token);
  }

  return out;
}

function _applyActivationPolicy(input = '', mode = 'always', mentionName = 'khy') {
  const raw = String(input || '').trim();
  if (!raw) return { accepted: true, prompt: '' };
  if (mode !== 'mention') return { accepted: true, prompt: raw };

  const trigger = _normalizeMentionTrigger(mentionName);
  const escaped = trigger.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const patterns = [
    new RegExp(`^@${escaped}[\\s:：,，-]*(.*)$`, 'i'),
    new RegExp(`^${escaped}[\\s:：,，-]+(.*)$`, 'i'),
    /^\/(?:ask|ai)\s+([\s\S]+)$/i,
  ];

  for (const ptn of patterns) {
    const m = ptn.exec(raw);
    if (!m) continue;
    const prompt = String(m[1] || '').trim();
    if (!prompt) {
      return { accepted: false, reason: `mention 模式下请输入内容，例如: @${trigger} 帮我分析这段代码` };
    }
    return { accepted: true, prompt };
  }

  return { accepted: false, reason: `mention 模式已开启，请以 @${trigger} 开头，或 /activation always 关闭限制` };
}


const HISTORY_FILE = path.join(os.homedir(), '.khyquant_history');
const MAX_HISTORY = 500;
const VERSION = process.env.KHYQUANT_PKG_VERSION || require('../../package.json').version;

// Commands that require full mode (server, DB, auth)
const BLOCKED_COMMANDS = new Set([
  'db', 'account', 'position', 'order',
  'login', 'register', 'logout', 'whoami', 'passwd', 'forgot',
  'cloud', 'admin', 'train', 'compute', 'update', 'doctor', 'plugin',
]);

// ── History helpers ──
function loadHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      return fs.readFileSync(HISTORY_FILE, 'utf-8').split('\n').filter(Boolean);
    }
  } catch { /* ignore */ }
  return [];
}

function saveHistory(history) {
  try {
    fs.writeFileSync(HISTORY_FILE, history.slice(-MAX_HISTORY).join('\n') + '\n');
  } catch { /* ignore */ }
}

function setTerminalTitle(title) {
  if (process.stdout.isTTY) process.stdout.write(`\x1b]0;${title}\x07`);
}

function hasToolCallTag(text = '') {
  const s = text || '';
  return /<tool_call>\s*[\s\S]*?<\/tool_call>/i.test(s)
    || /【\s*调用\s*[^】\n]{1,48}(?:[：:][^】]*)?】/.test(s);
}

function stripToolCallTags(text = '') {
  return (text || '')
    .replace(/<tool_call>[\s\S]*?<\/tool_call>/gi, '')
    .replace(/【\s*调用\s*[^】\n]{1,48}(?:[：:][^】]*)?】/g, '')
    .replace(/<execution_plan>[\s\S]*?<\/execution_plan>/gi, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function shouldBypassPlanMode(input = '') {
  const raw = String(input || '');
  const lower = raw.toLowerCase();
  if (!lower) return false;
  if (/\bnoplan\b|\/noplan\b/.test(lower)) return true;

  const zhPattern = /不要(?:进入)?计划|无需(?:进入)?计划|不需要(?:进入)?计划|跳过计划|直接执行|直接开始执行/;
  const enPattern = /\b(no\s*plan|skip\s*plan|direct\s*execute|execute\s*directly)\b/i;
  return zhPattern.test(raw) || enPattern.test(raw);
}

function looksLikeUiEchoInput(input = '') {
  const s = String(input || '').trim();
  if (!s) return false;
  return /^>\s*状态:\s*/.test(s)
    || /^状态:\s*(就绪|处理中)/.test(s)
    || /^>\s*(向\s*AI\s*发送请求|进入计划模式|执行计划|计划模式)/.test(s)
    || /^[-─]{10,}$/.test(s);
}

function isArrowEscapeLine(input = '') {
  const raw = String(input || '');
  const trimmed = raw.trim();
  if (!trimmed) return false;
  return trimmed === '\u001b[A'
    || trimmed === '\u001b[B'
    || trimmed === '\u001b[C'
    || trimmed === '\u001b[D'
    || /^\^\[\[[ABCD]$/.test(trimmed);
}

function mapToolToPhaseLabel(toolName = '') {
  const n = String(toolName || '').toLowerCase();
  if (n.includes('read')) return '读取';
  if (n.includes('write') || n.includes('edit')) return '写入';
  if (n.includes('search') || n.includes('grep') || n.includes('glob') || n.includes('fetch') || n.includes('ls') || n.includes('bash') || n.includes('shell') || n.includes('git')) return '探索';
  return '执行';
}

function _toolProgressStart(toolName, params = {}) {
  const name = String(toolName || '').toLowerCase().replace(/[\s_-]/g, '');
  if (name === 'websearch') return { label: 'Searching the web', target: params.query || params.q || '' };
  if (name === 'webfetch') return { label: 'Fetching URL', target: params.url || '' };
  if (name === 'grep' || name === 'glob' || name === 'find' || name === 'search' || name === 'ls') {
    return { label: 'Exploring workspace', target: params.path || params.pattern || '' };
  }
  if (name === 'read' || name === 'readfile' || name === 'notebookread') {
    return { label: 'Reading file', target: params.path || params.file_path || '' };
  }
  if (name === 'write' || name === 'writefile' || name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
    return { label: 'Updating file', target: params.path || params.file_path || '' };
  }
  if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
    return { label: 'Running command', target: (params.command || '').slice(0, 80) };
  }
  if (name === 'agent' || name === 'task') {
    return { label: 'Delegating to agent', target: params.role || params.subagent_type || 'general' };
  }
  return null;
}

function _toolProgressReason(toolName, params = {}) {
  const name = String(toolName || '').toLowerCase().replace(/[\s_-]/g, '');
  const pathHint = String(params.path || params.file_path || params.filePath || '').trim();
  const patternHint = String(params.pattern || params.query || params.q || '').trim();
  const commandHint = String(params.command || '').trim();

  if (name === 'grep' || name === 'glob' || name === 'find' || name === 'search' || name === 'ls') {
    const scope = pathHint || patternHint || '.';
    return `原因：先在 ${scope} 定位相关文件/上下文，再执行修改或回答。`;
  }
  if (name === 'read' || name === 'readfile' || name === 'notebookread') {
    const target = pathHint || 'target file';
    return `原因：先读取 ${target}，避免盲改导致错误。`;
  }
  if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
    if (commandHint) return `原因：先执行 \`${commandHint.slice(0, 80)}\` 校验当前运行状态。`;
    return '原因：先校验环境状态，再进行下一步操作。';
  }
  if (name === 'websearch' || name === 'webfetch') {
    return '原因：先补齐外部事实信息，再给出结论。';
  }
  return '';
}

function _toolProgressDone(toolName, success, detail = '') {
  const name = String(toolName || '').toLowerCase().replace(/[\s_-]/g, '');
  const status = success ? 'success' : 'error';
  if (name === 'websearch') return { status, label: success ? 'Searched' : 'Web search failed', detail };
  if (name === 'webfetch') return { status, label: success ? 'Fetched URL' : 'URL fetch failed', detail };
  if (name === 'grep' || name === 'glob' || name === 'find' || name === 'search' || name === 'ls') {
    return { status, label: success ? 'Explored' : 'Explore failed', detail };
  }
  if (name === 'read' || name === 'readfile' || name === 'notebookread') {
    return { status, label: success ? 'Read' : 'Read failed', detail };
  }
  if (name === 'write' || name === 'writefile' || name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
    return { status, label: success ? 'Updated' : 'Update failed', detail };
  }
  if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
    return { status, label: success ? 'Ran command' : 'Command failed', detail };
  }
  if (name === 'agent' || name === 'task') {
    return { status, label: success ? 'Agent completed' : 'Agent failed', detail };
  }
  return { status, label: success ? 'Completed' : 'Failed', detail };
}

function _formatToolResult(toolName, result) {
  if (!result) return 'done';
  const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
  const out = result.output || result.content || result.message || '';
  const outStr = typeof out === 'string' ? out : JSON.stringify(out);

  if (name === 'read' || name === 'readfile' || name === 'notebookread') {
    if (typeof result.lines === 'number') return `Read ${result.lines} lines`;
    return `Read ${String(outStr).split('\n').length} lines`;
  }
  if (name === 'websearch') {
    if (result.data && Array.isArray(result.data.results)) return `Found ${result.data.results.length} web results`;
    if (Array.isArray(result.results)) return `Found ${result.results.length} web results`;
    return 'Web search completed';
  }
  if (name === 'webfetch') {
    if (typeof result.status === 'number') return `Fetched URL (HTTP ${result.status})`;
    return 'Fetched URL';
  }
  if (name === 'grep' || name === 'search' || name === 'searchcontent') {
    if (typeof result.count === 'number') return `Found ${result.count} matches`;
    if (Array.isArray(result.matches)) return `Found ${result.matches.length} matches`;
    return 'Search completed';
  }
  if (name === 'glob' || name === 'find' || name === 'findfiles' || name === 'ls') {
    if (typeof result.count === 'number') return `Found ${result.count} files`;
    if (Array.isArray(result.files)) return `Found ${result.files.length} files`;
    if (Array.isArray(result.entries)) return `Listed ${result.entries.length} entries`;
    return 'Exploration completed';
  }
  if (name === 'write' || name === 'writefile') {
    if (typeof result.bytes === 'number') return `Wrote ${result.bytes} bytes`;
    return 'File written';
  }
  if (name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
    if (typeof result.editsApplied === 'number') return `Applied ${result.editsApplied} edits`;
    if (typeof result.replacements === 'number') return `Replaced ${result.replacements} occurrences`;
    return 'File updated';
  }
  if (name === 'todowrite') {
    if (typeof result.count === 'number') return `Updated ${result.count} todos`;
    return 'Todo list updated';
  }
  if (name === 'agent' || name === 'task') {
    return result.message ? String(result.message).slice(0, 90) : 'Agent task completed';
  }
  if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
    const lines = String(outStr || '').trim().split('\n').filter(Boolean);
    if (lines.length <= 2) return lines.join(' ').slice(0, 90) || 'Command completed';
    return `${lines.length} lines of output`;
  }

  return String(outStr || 'done').replace(/\n/g, ' ').slice(0, 90) || 'done';
}

function getDisplayWidthChar(ch) {
  const code = ch.codePointAt(0);
  if (!code) return 1;
  if ((code >= 0x1100 && code <= 0x115F) ||
      (code >= 0x2E80 && code <= 0xA4CF) ||
      (code >= 0xAC00 && code <= 0xD7AF) ||
      (code >= 0xF900 && code <= 0xFAFF) ||
      (code >= 0xFE10 && code <= 0xFE6F) ||
      (code >= 0xFF01 && code <= 0xFF60) ||
      (code >= 0xFFE0 && code <= 0xFFE6) ||
      (code >= 0x20000 && code <= 0x2FA1F)) {
    return 2;
  }
  return 1;
}

function streamThinkingChunk(text, streamState, chalk) {
  const showThinkingText = String(process.env.KHY_SHOW_THINKING_TEXT || 'false').toLowerCase() === 'true';
  if (!showThinkingText) return;
  const content = String(text || '').replace(/\r/g, '');
  if (!content) return;

  const maxCols = Math.max(24, (process.stdout.columns || 80) - 6);
  const prefix = '  ';

  if (!streamState.thinkingLineOpen) {
    process.stdout.write(prefix);
    streamState.thinkingLineOpen = true;
    streamState.thinkingCol = 0;
  }

  for (const ch of content) {
    if (ch === '\n') {
      process.stdout.write('\n');
      process.stdout.write(prefix);
      streamState.thinkingCol = 0;
      continue;
    }

    const charWidth = getDisplayWidthChar(ch);
    if (streamState.thinkingCol + charWidth > maxCols) {
      process.stdout.write('\n');
      process.stdout.write(prefix);
      streamState.thinkingCol = 0;
    }

    process.stdout.write(chalk.yellow(ch));
    streamState.thinkingCol += charWidth;
  }
}

function closeThinkingStream(streamState) {
  if (!streamState.thinkingLineOpen) return;
  process.stdout.write('\n');
  streamState.thinkingLineOpen = false;
  streamState.thinkingCol = 0;
}

function normalizePathLike(inputPath = '') {
  const p = String(inputPath || '').trim();
  if (!p) return '';
  const cwd = process.env.KHYQUANT_CWD || process.cwd();
  return path.isAbsolute(p) ? p : path.resolve(cwd, p);
}

function maybeRenderWriteDiff(toolName, params, result, chalk) {
  try {
    if (String(toolName) !== 'writeFile') return;
    if (!result || !result.success) return;
    const diffCtx = result._khyWriteDiff || null;
    const absPath = normalizePathLike(diffCtx?.filePath || result.path || params?.path || '');
    if (!absPath) return;
    const nextContent = diffCtx && typeof diffCtx.afterContent === 'string'
      ? diffCtx.afterContent
      : String(params?.content ?? '');
    const prevContent = diffCtx && typeof diffCtx.beforeContent === 'string'
      ? diffCtx.beforeContent
      : (fs.existsSync(absPath) ? fs.readFileSync(absPath, 'utf-8') : '');
    if (prevContent === nextContent) {
      console.log(chalk.dim(`    → 无文本差异: ${path.relative(process.cwd(), absPath) || absPath}`));
      return;
    }
    const outputFilePath = result.path ? String(result.path) : (path.relative(process.cwd(), absPath) || absPath);
    console.log(chalk.dim(`    → 文本变更: ${outputFilePath}`));
    const rendered = renderSideBySideDiff(prevContent, nextContent, outputFilePath);
    rendered.split('\n').forEach(line => console.log(`    ${line}`));
  } catch {
    // non-critical
  }
}

function maybeRenderInlineDiffFromToolOutput(toolName, result, chalk) {
  try {
    if (String(toolName) !== 'shellCommand' && String(toolName) !== 'shell_command') return;
    if (!result || !result.success) return;
    const out = String(result.output || result.content || '');
    const diffPattern = /(^|\n)(\+\+\+|---|@@|\+[^+].*|-[^-].*)/m;
    if (!diffPattern.test(out)) return;
    console.log(chalk.dim('    → 命令输出包含 diff:'));
    const rendered = require('./aiRenderer').renderDiff(out);
    rendered.split('\n').slice(0, 120).forEach(line => console.log(`    ${line}`));
  } catch {
    // non-critical
  }
}

function extractInlineImageIntent(input = '', sceneHint = '') {
  const text = String(input || '').trim();
  if (!text) return null;

  const pathPattern = /(file:\/\/[^\s"'`<>]+?\.(?:png|jpg|jpeg|gif|webp)|(?:\/|\.\/|\.\.\/)[^\s"'`<>]+?\.(?:png|jpg|jpeg|gif|webp))/i;
  const m = text.match(pathPattern);
  if (!m || !m[0]) return null;

  const pathText = m[0];
  const idx = m.index || 0;
  const promptText = `${text.slice(0, idx)} ${text.slice(idx + pathText.length)}`
    .replace(/\s+/g, ' ')
    .trim();

  return {
    filePath: pathText,
    prompt: buildContextualImagePrompt(promptText, `${text} ${sceneHint}`),
  };
}

function buildImageSceneHint(sceneHint = '', history = []) {
  const base = String(sceneHint || '').trim();
  if (!Array.isArray(history) || history.length === 0) return base;

  const recentHints = history
    .slice(-10)
    .map(line => String(line || '').trim())
    .filter(Boolean)
    .filter(line => !/^\/(?:status|help|trace|usage|new|clear|exit|model|think|plan|menu)\b/i.test(line))
    .filter(line => !/^(?:paste|粘贴|clipboard|剪贴板|image|图片|img)\b/i.test(line))
    .slice(-4);

  return [base, ...recentHints].filter(Boolean).join(' ');
}

function buildContextualImagePrompt(rawPrompt = '', sceneHint = '') {
  const prompt = String(rawPrompt || '').trim();
  const normalizedPrompt = prompt
    .toLowerCase()
    .replace(/[，。！？,.!?]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  const context = `${prompt} ${String(sceneHint || '')}`.toLowerCase();
  const genericPatterns = [
    /^请?(?:分析|看看|看下|看一下)(?:这张|这个)?(?:图片|图|截图)?$/,
    /^(?:描述|说说)(?:这张|这个)?(?:图片|图|截图)(?:的内容)?$/,
    /^(?:这|这个|这张)(?:是什么|是啥|啥)$/,
    /^analy[sz]e(?: this)? (?:image|picture|photo|screenshot)$/,
    /^describe(?: this)? (?:image|picture|photo|screenshot)$/,
    /^what(?:'s| is) this(?: image| picture| photo| screenshot)?$/,
    /^(?:look at|check)(?: this)? (?:image|picture|photo|screenshot)$/,
  ];
  const isGeneric = !prompt
    || /^(?:image|picture|photo|screenshot|图片|截图|这张图|这个图)$/.test(normalizedPrompt)
    || genericPatterns.some(pattern => pattern.test(normalizedPrompt));

  if (!isGeneric) return prompt;

  if (/(报错|错误|异常|堆栈|traceback|stack|error|exception|failed)/i.test(context)) {
    return '请先提取图片中的报错/堆栈信息，再定位可能原因，并给出可执行的修复步骤。';
  }
  if (/(界面|ui|布局|对齐|样式|css|前端|按钮|截图|页面)/i.test(context)) {
    return '请检查这张界面截图中的布局与对齐问题，指出不对称点，并给出可落地的修改建议。';
  }
  if (/(代码|终端|日志|log|command|console|diff|patch)/i.test(context)) {
    return '请识别图片里的代码/终端/日志关键信息，结合上下文判断问题，并给出下一步执行命令或改动建议。';
  }
  if (/(k线|走势|行情|图表|trading|chart|candlestick)/i.test(context)) {
    return '请分析图表中的关键趋势与风险信号，并给出清晰的操作建议。';
  }
  if (/(ocr|识别|提取文字|翻译|translate|text)/i.test(context)) {
    return '请先OCR提取图片文字，再按上下文整理要点并给出结论。';
  }

  return '请先描述图片中的关键信息，再结合当前任务上下文推断我想完成的目标，并给出下一步可执行操作。';
}

/**
 * Start the lightweight AI REPL.
 * @param {object} [options]
 * @param {boolean} [options.oneShot] - run single query and return
 * @param {boolean} [options.printMode] - raw text output for piping
 * @param {string}  [options.prompt] - prompt for oneShot/printMode
 */
async function startLiteRepl(options = {}) {
  const { printLiteBanner, printError, printInfo, printSuccess, ICON_PROMPT, ICON_BOT, MASCOT_MINI, getRandomFarewell } = fmt();
  const chalk = c();
  const { parseInput, route, getCompletions, SLASH_COMMANDS } = router();

  // ── Print mode: raw output, no formatting ──
  if (options.printMode && options.prompt) {
    const result = await ai().chat(options.prompt);
    if (result && result.reply) process.stdout.write(result.reply + '\n');
    return;
  }

  // ── One-shot mode: formatted single query ──
  if (options.oneShot && options.prompt) {
    const renderer = require('./aiRenderer');
    const aiProvider = ai().getActiveProvider() || 'AI';
    console.log('');
    renderer.printStepLine('active', '请求 AI', aiProvider);

    let thinkingStarted = false;
    const oneShotThinkingState = { thinkingLineOpen: false, thinkingCol: 0 };
    const result = await ai().chat(options.prompt, {
      onChunk: (chunk) => {
        if (chunk.type === 'thinking' && !thinkingStarted) {
          thinkingStarted = true;
          if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
          renderer.printStepLine('success', '请求 AI', aiProvider);
          console.log('');
          console.log(chalk.yellow(`  ${ICON_BOT} 思考过程:`));
        }
        if (chunk.type === 'thinking') {
          streamThinkingChunk(chunk.text, oneShotThinkingState, chalk);
        }
      },
    });

    if (thinkingStarted) {
      closeThinkingStream(oneShotThinkingState);
      console.log('');
    } else {
      if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
    }

    if (result.reply) {
      const meta = [
        result.elapsed ? `${(result.elapsed / 1000).toFixed(1)}s` : '',
        result.tokenUsage ? `${result.tokenUsage.totalTokens} tokens` : '',
      ].filter(Boolean).join(' · ');
      renderer.printStepLine('success', 'AI 回复', result.provider || 'local', meta);
      renderer.renderAiResponse(result.reply).split('\n').forEach(l => console.log(`  ${l}`));
    } else {
      printError('AI 未返回有效回复');
    }
    console.log('');
    return;
  }

  // ── Interactive REPL mode ──
  setTerminalTitle('khy OS AI');
  const aiProvider = ai().getActiveProvider();
  const claudeUiEnabled = String(process.env.KHY_CLAUDE_UI || 'true').toLowerCase() !== 'false';
  printLiteBanner(VERSION, aiProvider);

  // Session starts fresh — history is only loaded on explicit /resume command
  // to minimize token usage per request.
  try {
    ai().clearHistory();
  } catch { /* non-critical */ }

  // State variables
  let _busy = false;
  let _planMode = false;
  let _ctrlCCount = 0;
  let _ctrlCTimer = null;
  let _btwQueue = [];
  const _sessionStartAt = Date.now();
  let _queuedInputs = [];
  let _lastBusyMergeAt = 0;
  let _lastBusyEnterHintAt = 0;
  let _busyTypingUntil = 0;
  const _slashAutoMenuEnabled = String(process.env.KHY_SLASH_AUTOMENU || 'true').toLowerCase() !== 'false';
  let _slashAutoMenuOpening = false;
  let _slashAutoMenuCooldownUntil = 0;
  let _traceMode = false;
  let _usageMode = 'tokens'; // off | tokens | full
  let _activationMode = 'always'; // always | mention
  let _activationMentionName = 'khy';
  const INTERNAL_LINE_PREFIX = '__KHY_INTERNAL_LINE__ ';
  const INPUT_BATCH_WINDOW_MS = Math.max(20, parseInt(process.env.KHY_PASTE_MERGE_MS || '90', 10));
  const INPUT_BATCH_MODE = String(process.env.KHY_INPUT_BATCH_MODE || 'off').toLowerCase(); // off | auto | always
  let _inputBatchTimer = null;
  let _inputBatchLines = [];

  function _shouldBatchInputLine(lineText = '') {
    if (INPUT_BATCH_MODE === 'always') return true;
    if (INPUT_BATCH_MODE === 'off') return false;
    const raw = String(lineText || '');
    return raw.includes('\n') || raw.includes('\r') || raw.length >= 180;
  }

  const BRACKETED_PASTE_START = ['\u001b[200~', '[200~', '00~'];
  const BRACKETED_PASTE_END = ['\u001b[201~', '[201~', '01~'];
  const _pasteCapture = { active: false, lines: [] };

  function _findFirstMarker(text, markers) {
    let best = null;
    for (const marker of markers) {
      const idx = text.indexOf(marker);
      if (idx === -1) continue;
      if (!best || idx < best.idx) best = { idx, marker };
    }
    return best;
  }

  function _stripBracketArtifacts(text) {
    return String(text || '')
      .replace(/\u001b\[\?2004[hl]/g, '')
      .replace(/\u001b\[(200|201)~/g, '')
      .replace(/\[(200|201)~/g, '')
      .replace(/^00~/, '')
      .replace(/01~$/, '');
  }

  function _consumeBracketedPaste(rawLine) {
    const line = _stripBracketArtifacts(String(rawLine || ''));
    if (!_pasteCapture.active) {
      const start = _findFirstMarker(line, BRACKETED_PASTE_START);
      if (!start || start.idx > 2) {
        return { state: 'normal', text: line };
      }
      const withoutStart = line.slice(0, start.idx) + line.slice(start.idx + start.marker.length);
      const inlineEnd = _findFirstMarker(withoutStart, BRACKETED_PASTE_END);
      if (inlineEnd) {
        const completed = (withoutStart.slice(0, inlineEnd.idx) + withoutStart.slice(inlineEnd.idx + inlineEnd.marker.length)).trim();
        return { state: 'completed', text: completed };
      }
      _pasteCapture.active = true;
      _pasteCapture.lines = [];
      if (withoutStart) _pasteCapture.lines.push(withoutStart);
      return { state: 'capturing', text: '' };
    }

    const end = _findFirstMarker(line, BRACKETED_PASTE_END);
    if (end) {
      const chunk = line.slice(0, end.idx) + line.slice(end.idx + end.marker.length);
      if (chunk) _pasteCapture.lines.push(chunk);
      const completed = _pasteCapture.lines.join('\n').trim();
      _pasteCapture.active = false;
      _pasteCapture.lines = [];
      return { state: 'completed', text: completed };
    }

    _pasteCapture.lines.push(line);
    return { state: 'capturing', text: '' };
  }

  function _requestRelayCancel(reason = 'Interrupted by user input') {
    try {
      const gateway = require('../services/gateway/aiGateway');
      const relay = gateway.getRelayAdapter();
      if (relay && typeof relay.cancelPending === 'function') {
        return relay.cancelPending(reason);
      }
    } catch { /* non-critical */ }
    return false;
  }

  function _scheduleInputBatch(lineText, rl) {
    _inputBatchLines.push(String(lineText || ''));
    if (_inputBatchTimer) clearTimeout(_inputBatchTimer);
    _inputBatchTimer = setTimeout(() => {
      const merged = _inputBatchLines.join('\n').trim();
      _inputBatchLines = [];
      _inputBatchTimer = null;
      if (!merged) {
        try { rl.prompt(); } catch { /* ignore */ }
        return;
      }
      rl.emit('line', `${INTERNAL_LINE_PREFIX}${merged}`);
    }, INPUT_BATCH_WINDOW_MS);
  }

  // ── Complete Roles export/import ──
  const ROLES_DIR = path.join(os.homedir(), '.khyquant');

  function _exportCompleteRoles() {
    const roles = {
      version: VERSION,
      exportDate: new Date().toISOString(),
      // System prompt (user override)
      systemPrompt: null,
      // Agent roles (custom overrides)
      agentRoles: null,
      // Tool permissions
      toolPermissions: null,
      // Provider config (keys masked)
      providerConfig: {},
      // Prompt library (if exists)
      promptLibrary: null,
      // Skill registry (if exists)
      skillRegistry: null,
      // Project memory (if exists)
      projectMemory: null,
    };

    // System prompt
    const spFile = path.join(ROLES_DIR, 'system_prompt.txt');
    try { if (fs.existsSync(spFile)) roles.systemPrompt = fs.readFileSync(spFile, 'utf-8'); } catch {}

    // Agent roles
    const arFile = path.join(ROLES_DIR, 'agent_roles.json');
    try { if (fs.existsSync(arFile)) roles.agentRoles = JSON.parse(fs.readFileSync(arFile, 'utf-8')); } catch {}

    // Tool permissions
    const tpFile = path.join(ROLES_DIR, 'tool_permissions.json');
    try { if (fs.existsSync(tpFile)) roles.toolPermissions = JSON.parse(fs.readFileSync(tpFile, 'utf-8')); } catch {}

    // Provider configs (mask sensitive keys)
    const envKeys = ['DEEPSEEK_API_KEY', 'QWEN_API_KEY', 'GLM_API_KEY', 'DOUBAO_API_KEY',
      'WENXIN_API_KEY', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'RELAY_API_KEY',
      'DEEPSEEK_API_ENDPOINT', 'QWEN_API_ENDPOINT', 'GLM_API_ENDPOINT', 'DOUBAO_API_ENDPOINT',
      'WENXIN_API_ENDPOINT', 'OPENAI_API_ENDPOINT', 'ANTHROPIC_API_ENDPOINT',
      'RELAY_API_ENDPOINT', 'RELAY_API_MODEL', 'OLLAMA_HOST', 'OLLAMA_MODEL'];
    for (const k of envKeys) {
      if (process.env[k]) {
        // Mask API keys (show first 6 + last 4 chars)
        if (k.endsWith('_KEY') && process.env[k].length > 12) {
          const v = process.env[k];
          roles.providerConfig[k] = v.slice(0, 6) + '***' + v.slice(-4);
        } else {
          roles.providerConfig[k] = process.env[k];
        }
      }
    }

    // Prompt library
    const plFile = path.join(ROLES_DIR, 'prompt_library.json');
    try { if (fs.existsSync(plFile)) roles.promptLibrary = JSON.parse(fs.readFileSync(plFile, 'utf-8')); } catch {}

    // Skill registry
    const srFile = path.join(ROLES_DIR, 'skill_registry.json');
    try { if (fs.existsSync(srFile)) roles.skillRegistry = JSON.parse(fs.readFileSync(srFile, 'utf-8')); } catch {}

    // Project memory
    const pmFile = path.join(ROLES_DIR, 'project_memory.json');
    try { if (fs.existsSync(pmFile)) roles.projectMemory = JSON.parse(fs.readFileSync(pmFile, 'utf-8')); } catch {}

    const outPath = path.join(os.homedir(), 'khy_complete_roles.json');
    fs.writeFileSync(outPath, JSON.stringify(roles, null, 2), 'utf-8');
    return outPath;
  }

  function _importCompleteRoles(filePath) {
    if (!fs.existsSync(filePath)) throw new Error(`文件不存在: ${filePath}`);
    const roles = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    let count = 0;

    if (!fs.existsSync(ROLES_DIR)) fs.mkdirSync(ROLES_DIR, { recursive: true });

    if (roles.systemPrompt) {
      fs.writeFileSync(path.join(ROLES_DIR, 'system_prompt.txt'), roles.systemPrompt, 'utf-8');
      count++;
    }
    if (roles.agentRoles) {
      fs.writeFileSync(path.join(ROLES_DIR, 'agent_roles.json'), JSON.stringify(roles.agentRoles, null, 2), 'utf-8');
      count++;
    }
    if (roles.toolPermissions) {
      fs.writeFileSync(path.join(ROLES_DIR, 'tool_permissions.json'), JSON.stringify(roles.toolPermissions, null, 2), 'utf-8');
      count++;
    }
    if (roles.promptLibrary) {
      fs.writeFileSync(path.join(ROLES_DIR, 'prompt_library.json'), JSON.stringify(roles.promptLibrary, null, 2), 'utf-8');
      count++;
    }
    if (roles.skillRegistry) {
      fs.writeFileSync(path.join(ROLES_DIR, 'skill_registry.json'), JSON.stringify(roles.skillRegistry, null, 2), 'utf-8');
      count++;
    }
    if (roles.projectMemory) {
      fs.writeFileSync(path.join(ROLES_DIR, 'project_memory.json'), JSON.stringify(roles.projectMemory, null, 2), 'utf-8');
      count++;
    }
    // Provider config: write to .env (note: keys are masked in export, so only endpoints/models are useful)
    if (roles.providerConfig) {
      const envPath = path.resolve(__dirname, '../../.env');
      let envContent = '';
      try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch {}
      for (const [k, v] of Object.entries(roles.providerConfig)) {
        if (k.endsWith('_KEY') && v.includes('***')) continue; // Skip masked keys
        const regex = new RegExp(`^${k}=.*$`, 'm');
        const line = `${k}=${v}`;
        if (regex.test(envContent)) {
          envContent = envContent.replace(regex, line);
        } else {
          envContent = envContent.trimEnd() + '\n' + line + '\n';
        }
        count++;
      }
      fs.writeFileSync(envPath, envContent, 'utf-8');
    }

    return count;
  }

  // Setup readline
  const history = loadHistory();
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: chalk.bold.cyan('> '),
    historySize: MAX_HISTORY,
    completer: (line) => {
      const completions = getCompletions(line);
      return [completions.length > 0 ? completions : [], line];
    },
  });
  history.forEach(line => rl.history.push(line));

  function bindInteractiveInputGuard(renderer) {
    if (!renderer || typeof renderer.setInteractiveGuard !== 'function') return;
    renderer.setInteractiveGuard(() => (
      _busy
      && (
        (typeof rl.line === 'string' && rl.line.length > 0)
        || Date.now() < _busyTypingUntil
      )
    ));
  }

  try {
    process.stdin.on('data', (chunk) => {
      if (_busy) _busyTypingUntil = Date.now() + 900;
      if (!_slashAutoMenuEnabled) return;
      if (_busy || _inquirerActive || _slashAutoMenuOpening) return;
      if ((process.stdin && process.stdin.isTTY) !== true || (process.stdout && process.stdout.isTTY) !== true) return;
      if (typeof rl?.paused === 'boolean' && rl.paused) return;
      if (Date.now() < _slashAutoMenuCooldownUntil) return;

      const raw = Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk || '');
      if (!raw.includes('/')) return;
      if (String(rl.line || '') !== '/') return;

      _slashAutoMenuOpening = true;
      _slashAutoMenuCooldownUntil = Date.now() + 700;
      setTimeout(() => {
        try {
          if (_busy || _inquirerActive) return;
          if (String(rl.line || '') !== '/') return;
          try { rl.write(null, { ctrl: true, name: 'u' }); } catch { rl.line = ''; }
          rl.emit('line', `${INTERNAL_LINE_PREFIX}/`);
        } finally {
          _slashAutoMenuOpening = false;
        }
      }, 0);
    });
  } catch { /* best effort */ }

  // Register readline with toolCalling so permission prompts use our rl (avoid stdin conflict)
  try {
    const toolCalling = require('../services/toolCalling');
    toolCalling.setReadlineProvider(() => rl);
  } catch { /* toolCalling not available */ }

  // ── Prompt context line (simple, no ANSI cursor tricks) ──
  let _statusBarEnabled = process.stdout.isTTY && (process.stdout.columns || 0) > 28;

  // Rotating tips
  const TIPS = [
    '/btw 在 AI 工作时插入不打断的提示',
    '/review 多轮代码审查',
    '/model 快速切换 AI 模型',
    '/plan 生成执行计划再动手',
    '/server 启动 Web UI',
    '/cost 查看 AI 费用统计',
    '/status 查看当前会话状态',
    '/compact 压缩历史上下文',
    '/activation mention 进入点名触发模式',
  ];
  let _tipIdx = 0;
  const _tipTimer = setInterval(() => { _tipIdx = (_tipIdx + 1) % TIPS.length; }, 30000);

  function formatDuration(ms) {
    const sec = Math.max(0, Math.floor(ms / 1000));
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) return `${h}h ${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
    return `${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
  }

  function getPromptFrameWidth() {
    const cols = process.stdout.columns || 80;
    return Math.max(26, Math.min(cols - 6, 86));
  }

  function formatToolSummary(summary) {
    if (!summary || typeof summary !== 'object') return '';
    const totalCalls = Number(summary.totalCalls || 0);
    const totalDurationMs = Number(summary.totalDurationMs || 0);
    if (!Number.isFinite(totalCalls) || !Number.isFinite(totalDurationMs)) return '';
    return `工具摘要: ${Math.max(0, totalCalls)} 次调用 · ${Math.max(0, totalDurationMs / 1000).toFixed(1)}s`;
  }

  /**
   * Print a static context line above the prompt.
   * No ANSI cursor movement — just prints lines that stay in the scrollback.
   * This avoids all the overlap/corruption issues on Windows.
   */
  function renderPromptContext() {
    if (claudeUiEnabled || !_statusBarEnabled) return;
    const provider = ai().getActiveProvider() || 'AI';
    const status = _busy ? '处理中' : '就绪';
    const tip = TIPS[_tipIdx];
    const elapsed = formatDuration(Date.now() - _sessionStartAt);
    console.log(chalk.dim(`状态: ${status} · 模型: ${provider} · 总时长: ${elapsed} · 提示: ${tip}`));
  }

  // Wrap prompt to print context before prompt
  const _origPrompt = rl.prompt.bind(rl);
  const _promptRaw = '> ';
  const _plainPrompt = _promptRaw;
  const _legacyPrompt = chalk.bold.cyan(_promptRaw);
  const _defaultPrompt = claudeUiEnabled ? _plainPrompt : _legacyPrompt;
  const _inputFrameEnabled = process.stdout.isTTY
    && process.platform !== 'win32'
    && (claudeUiEnabled || process.env.KHY_INPUT_FRAME === '1');

  function _renderBottomStatusBar() {
    if (!process.stdout.isTTY) return;
    const cols = process.stdout.columns || 80;
    try {
      const hud = require('./hudRenderer');
      hud.refreshGit();
      const state = hud.getState();
      if (state.git && state.git.branch) {
        const branchText = ` ${state.git.branch} `;
        const branchLen = branchText.length;
        const pad = Math.max(0, cols - branchLen);
        process.stdout.write(' '.repeat(pad) + chalk.bgHex('#1A4D6E').hex('#87CEEB')(branchText) + '\n');
      }
    } catch { /* best-effort */ }
  }

  function _getPermissionModeState() {
    try {
      const toolCalling = require('../services/toolCalling');
      if (toolCalling && typeof toolCalling.isDangerousMode === 'function' && toolCalling.isDangerousMode()) {
        return { label: '⏵⏵ bypass permissions on', color: '#FF6B80' };
      }
    } catch { /* best effort */ }

    try {
      const permStore = require('../services/permissionStore');
      const profile = typeof permStore.getProfile === 'function'
        ? permStore.getProfile()
        : 'normal';
      if (profile === 'yolo') return { label: '⏵⏵ bypass permissions on', color: '#FF6B80' };
      if (profile === 'strict') return { label: 'ask before all tools on', color: '#FFFFFF' };
      return null;
    } catch {
      return null;
    }
  }

  function _renderPermissionBar() {
    if (!process.stdout.isTTY) return;
    const cols = process.stdout.columns || 80;
    const modeState = _getPermissionModeState();
    const permLeft = modeState
      ? chalk.hex(modeState.color || '#B388FF')(modeState.label)
      : chalk.dim('? for shortcuts');

    let compactRight = '';
    try {
      const hud = require('./hudRenderer');
      const state = hud.getState();
      const limit = state.contextWindow.limit || 200000;
      const sessionTokens = state.sessionTokens.total || 0;
      if (sessionTokens > 0 && limit > 0) {
        const usedPct = Math.round((sessionTokens / limit) * 100);
        const remaining = Math.max(0, 100 - usedPct);
        compactRight = chalk.dim(`${remaining}% until auto-compact`);
      }
    } catch {
      // Don't show on error
    }

    const stripAnsi = (s) => s.replace(/\x1b\[[0-9;]*m/g, '');
    const truncatePlain = (s, n) => {
      const t = String(s || '');
      if (n <= 0) return '';
      if (t.length <= n) return t;
      return n <= 1 ? t.slice(0, n) : (t.slice(0, n - 1) + '…');
    };
    const plainLeft = stripAnsi(permLeft);
    const rightLen = stripAnsi(compactRight).length;
    const leftBudget = Math.max(1, cols - rightLen - 2);
    const safeLeft = plainLeft.length > leftBudget
      ? chalk.dim(truncatePlain(plainLeft, leftBudget))
      : permLeft;
    const leftLen = stripAnsi(safeLeft).length;
    const pad = Math.max(1, cols - leftLen - rightLen - 1);

    console.log(safeLeft + ' '.repeat(pad) + compactRight);
  }

  let _frameRendered = false;

  function renderInputPromptFrame(args) {
    if (!_inputFrameEnabled || (process.stdout.columns || 0) < 36) {
      rl.setPrompt(_defaultPrompt);
      _origPrompt(...args);
      return;
    }

    if (claudeUiEnabled) {
      if (!_frameRendered) {
        _frameRendered = true;
        const width = process.stdout.columns || 80;
        const rule = chalk.hex('#D77757')('─'.repeat(width));
        _renderBottomStatusBar();
        console.log(rule);
        rl.setPrompt(_plainPrompt);
        _origPrompt(...args);
        process.stdout.write('\n');
        process.stdout.write(rule);
        process.stdout.write('\n');
        _renderPermissionBar();
        try {
          readline.moveCursor(process.stdout, 0, -3);
          readline.cursorTo(process.stdout, _promptRaw.length);
        } catch {
          try { process.stdout.write('\x1b[3A\r'); } catch {}
        }
        return;
      }
      rl.setPrompt(_plainPrompt);
      _origPrompt(...args);
      return;
    }

    const width = getPromptFrameWidth();
    const rule = chalk.hex('#D77757')('─'.repeat(width));
    console.log(rule);
    rl.setPrompt(_legacyPrompt);
    _origPrompt(...args);
    process.stdout.write('\n');
    process.stdout.write(rule);
    process.stdout.write('\n');
    try {
      readline.moveCursor(process.stdout, 0, -2);
      readline.cursorTo(process.stdout, _promptRaw.length);
      readline.clearLine(process.stdout, 1);
    } catch {
      try { process.stdout.write('\x1b[2A\r'); } catch {}
    }
  }

  function leaveInputPromptFrame() {
    if (claudeUiEnabled) {
      try {
        if (process.stdout.isTTY) {
          readline.clearScreenDown(process.stdout);
        }
      } catch { /* ignore */ }
      _frameRendered = false;
      return;
    }
    if (!_inputFrameEnabled || (process.stdout.columns || 0) < 36) return;
    const width = getPromptFrameWidth();
    const rule = chalk.hex('#D77757')('─'.repeat(width));
    try {
      // Redraw the lower rule on Enter, then move to next line for logs.
      readline.clearLine(process.stdout, 0);
      readline.cursorTo(process.stdout, 0);
      process.stdout.write(rule);
      process.stdout.write('\n');
    } catch {
      try { process.stdout.write('\n'); } catch {}
    }
  }

  rl.prompt = (...args) => {
    if (_statusBarEnabled) {
      renderPromptContext();
    }
    renderInputPromptFrame(args);
  };

  function showBusyInterjectPrompt() {
    if (!_busy) return;
    if (_inputFrameEnabled) return;
    try {
      if (process.stdout.isTTY) {
        readline.clearLine(process.stdout, 0);
        readline.cursorTo(process.stdout, 0);
      }
      rl.setPrompt(_defaultPrompt);
      _origPrompt();
    } catch { /* ignore */ }
  }

  function showBusySlashMenu() {
    const preferred = ['/i', '/interrupt', '/model', '/gateway', '/status', '/help'];
    const picked = [];
    for (const key of preferred) {
      const hit = (LITE_SLASH || []).find(sc => sc && sc.cmd === key);
      if (hit) picked.push(hit);
    }
    if (picked.length === 0) {
      (LITE_SLASH || []).slice(0, 6).forEach((item) => {
        if (item && item.cmd) picked.push(item);
      });
    }
    console.log(chalk.dim('  ↳ 忙碌菜单（可继续输入，命令会排队）:'));
    for (const item of picked.slice(0, 6)) {
      console.log(chalk.dim(`    ${String(item.cmd || '').padEnd(12)} ${String(item.desc || '')}`));
    }
    console.log(chalk.dim('    /i <内容> 可优先插队并尝试中断当前请求'));
  }

  function recoverReadlineInput() {
    try { process.stdin.resume(); } catch { /* ignore */ }
    try { rl.resume(); } catch { /* ignore */ }
    try {
      if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
        process.stdin.setRawMode(true);
      }
    } catch { /* ignore */ }
  }

  if (process.stdout.on) {
    process.stdout.on('resize', () => {
      _statusBarEnabled = process.stdout.isTTY && (process.stdout.columns || 0) > 28;
    });
  }

  rl.prompt();

  // Initialize HUD git info (non-blocking)
  try { require('./hudRenderer').refreshGit(); } catch {}

  // Lightweight deferred prefetch for khy mode (hardware limits only)
  try {
    const { deferredPrefetch } = require('../bootstrap/prefetch');
    deferredPrefetch({ mode: 'khy' });
  } catch { /* bootstrap not available, fine */ }

  // ── Lite slash commands (filtered subset) ──
  const LITE_SLASH = SLASH_COMMANDS.filter(sc =>
    !['/security', '/scan', '/hardware', '/doctor'].includes(sc.cmd)
  );

  // Add extra commands only if not already present in SLASH_COMMANDS
  const _existingCmds = new Set(LITE_SLASH.map(sc => sc.cmd));
  const _extraCommands = [
    { cmd: '/hud', desc: '显示 HUD 仪表盘', label: 'HUD 面板' },
    { cmd: '/status', desc: '显示会话状态与运行开关', label: '会话状态' },
    { cmd: '/new', desc: '新建会话（清空当前上下文）', label: '新会话' },
    { cmd: '/reset', desc: '重置会话（同 /new）', label: '重置会话' },
    { cmd: '/compact', desc: '压缩历史上下文，减少 token 占用', label: '压缩上下文' },
    { cmd: '/think', desc: '设置思考强度 low|medium|high|max', label: '思考强度' },
    { cmd: '/trace', desc: '调试追踪开关 on|off|status', label: '追踪开关' },
    { cmd: '/usage', desc: 'usage 显示模式 off|tokens|full', label: 'Usage 显示' },
    { cmd: '/activation', desc: 'AI 触发策略 always|mention', label: '触发策略' },
    { cmd: '/export-roles', desc: '导出 Complete Roles 配置文件', label: '导出角色' },
    { cmd: '/import-roles', desc: '导入 Complete Roles 配置文件', label: '导入角色' },
    { cmd: '/learn', desc: '导入 Claude 轨迹文件进行自我学习', label: '学习轨迹' },
    { cmd: '/study', desc: '学习模式开关（需 Owner Secret）', label: '学习模式' },
    { cmd: '/optimize', desc: 'AI 自我优化（分析经验并改进）', label: '自优化' },
    { cmd: '/optimize-log', desc: '查看优化历史记录', label: '优化日志' },
    { cmd: '/push', desc: '推送项目到 GitHub/Gitee 私人仓库备份', label: '推送备份' },
    { cmd: '/pool', desc: '查看 API Key 池状态（多账号轮询）', label: 'Key 池' },
    { cmd: '/model', desc: '切换 AI 模型 / 适配器', label: '切换模型', route: 'gateway model' },
    { cmd: '/config', desc: '配置 API Key / 中转站 / Ollama', label: 'AI 配置', route: 'gateway config' },
    { cmd: '/gateway', desc: '查看 AI 网关状态', label: '网关状态', route: 'gateway status' },
    { cmd: '/server', desc: '启动 Web 服务器', label: '启动服务', route: 'server start' },
    { cmd: '/init', desc: '创建 khy.md 项目指令文件', label: '初始化', route: 'init' },
    { cmd: '/review', desc: '多轮代码审查', label: '代码审查', route: 'review' },
    { cmd: '/app', desc: '管理 khy 平台应用', label: '应用管理', route: 'app list' },
  ];
  for (const extra of _extraCommands) {
    if (!_existingCmds.has(extra.cmd)) {
      LITE_SLASH.push(extra);
      _existingCmds.add(extra.cmd);
    }
  }

  // ── Main line handler ──
  rl.on('line', async (line) => {
    if (!_busy) leaveInputPromptFrame();
    if (process.stdout.isTTY) {
      try {
        readline.clearLine(process.stdout, 0);
        readline.cursorTo(process.stdout, 0);
      } catch { /* ignore */ }
    }
    const isInternalLine = typeof line === 'string' && line.startsWith(INTERNAL_LINE_PREFIX);
    const lineBody = isInternalLine ? line.slice(INTERNAL_LINE_PREFIX.length) : line;

    if (!isInternalLine) {
      const pasteState = _consumeBracketedPaste(lineBody);
      if (pasteState.state === 'capturing') return;
      if (pasteState.state === 'completed') {
        if (!pasteState.text) { rl.prompt(); return; }
        rl.emit('line', `${INTERNAL_LINE_PREFIX}${pasteState.text}`);
        return;
      }
      line = pasteState.text;
    } else {
      line = lineBody;
    }

    const trimmed = line.trim();
    if (!isInternalLine && isArrowEscapeLine(line)) {
      rl.prompt();
      return;
    }
    // Merge rapid multi-line paste into a single request before execution.
    // Slash-prefixed commands bypass batching for immediate response.
    // NOTE: this block is intentionally before the empty-line guard so pasted
    // blank lines are preserved as part of a single paste payload.
    if (!isInternalLine && !_busy && !trimmed.startsWith('/') && _shouldBatchInputLine(line)) {
      _scheduleInputBatch(line, rl);
      return;
    }

    if (!trimmed) {
      if (_busy) {
        const now = Date.now();
        if (now - _lastBusyEnterHintAt > 1200) {
          console.log(chalk.dim('  ↳ 正在处理中：输入内容后回车可排队，/i <内容> 可优先处理'));
          _lastBusyEnterHintAt = now;
        }
        showBusyInterjectPrompt();
        return;
      }
      rl.prompt();
      return;
    }

    if (!isInternalLine && _busy && trimmed === '/') {
      const now = Date.now();
      if (now - _lastBusyEnterHintAt > 1200) {
        showBusySlashMenu();
        _lastBusyEnterHintAt = now;
      }
      showBusyInterjectPrompt();
      return;
    }

    // Slash menu — inline display (Claude Code style)
    if (!isInternalLine && !_busy && (trimmed === '/' || (trimmed.startsWith('/') && trimmed.length <= 12 && !/^\/\w+\s/.test(trimmed)))) {
      const filter = trimmed.length > 1 ? trimmed.toLowerCase() : '';
      const matches = filter
        ? LITE_SLASH.filter(sc => sc.cmd.startsWith(filter) || sc.label.includes(filter.slice(1)))
        : LITE_SLASH;

      if (matches.length === 0) {
        printInfo(`无匹配的命令: ${trimmed}`);
        rl.prompt();
        return;
      }

      // If user typed an exact command name, execute it directly (even if other commands share prefix)
      const exactHit = filter ? matches.find(sc => sc.cmd === trimmed) : null;
      if (exactHit) {
        const selected = exactHit;
        if (selected.flag === 'plan') {
          _planMode = true;
          printInfo('计划模式已开启 — 下次 AI 回复将先制定执行计划');
        } else if (selected.flag && selected.flag.startsWith('effort-')) {
          const level = selected.flag.replace('effort-', '');
          if (ai().setEffort(level)) {
            const p = ai().getEffortPresets()[level];
            printSuccess(`精度已切换: ${level} (${p.label})`);
          }
        } else if (selected.flag === 'subscribe') {
          const { handleDocsSubscription } = require('./handlers/docs');
          await handleDocsSubscription();
        } else if (selected.flag === 'proxy') {
          try {
            const proxyConfig = require('../services/proxyConfigService');
            const status = proxyConfig.getStatus();
            if (status.active) {
              printSuccess(`代理已启用: ${status.url}`);
              const { action } = await inqPrompt([{
                type: 'list', name: 'action', message: '代理操作:',
                choices: [
                  { name: '关闭代理', value: 'off' },
                  { name: '重新检测 Clash', value: 'detect' },
                  { name: '取消', value: 'cancel' },
                ],
              }]);
              if (action === 'off') { proxyConfig.disableProxy(); printSuccess('代理已关闭'); }
              else if (action === 'detect') {
                const r = await proxyConfig.autoDetectAndEnable();
                r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
              }
            } else {
              const { action } = await inqPrompt([{
                type: 'list', name: 'action', message: '代理设置:',
                choices: [
                  { name: '自动检测 Clash', value: 'detect' },
                  { name: '手动配置 HTTP 代理', value: 'http' },
                  { name: '手动配置 SOCKS5 代理', value: 'socks5' },
                  { name: '取消', value: 'cancel' },
                ],
              }]);
              if (action === 'detect') {
                printInfo('正在检测 Clash...');
                const r = await proxyConfig.autoDetectAndEnable();
                r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
              } else if (action === 'http' || action === 'socks5') {
                const { port } = await inqPrompt([{
                  type: 'input', name: 'port', message: `端口 (默认 ${action === 'http' ? '7890' : '1080'}):`,
                  default: action === 'http' ? '7890' : '1080',
                }]);
                const r = await proxyConfig.enableProxy({ type: action, host: '127.0.0.1', port });
                r.success ? printSuccess(`代理已启用: ${r.proxy.url}`) : printError(r.error);
              }
            }
          } catch (e) { printError(`代理配置失败: ${e.message}`); }
        } else if (selected.flag === 'models') {
          try {
            const ollamaMgr = require('../services/ollamaModelManager');
            const running = await ollamaMgr.isOllamaRunning();
            const hw = ollamaMgr.detectHardware();
            console.log('');
            printInfo(`硬件: ${hw.totalRamGB} GB RAM · ${hw.cpuCount} CPUs` + (hw.gpu ? ` · GPU: ${hw.gpu.name}` : ''));
            printInfo(`Ollama ${running ? chalk.green('运行中') : chalk.yellow('未运行')}`);
            if (running) {
              const models = await ollamaMgr.listModels();
              if (models.length > 0) {
                printSuccess(`已安装 ${models.length} 个模型:`);
                for (const m of models) {
                  console.log(chalk.dim(`    ${m.name}  (${m.size}, ${m.paramSize})`));
                }
              } else {
                printInfo('暂无已安装模型');
              }
              const { recommended } = ollamaMgr.getRecommendations();
              const { action } = await inqPrompt([{
                type: 'list',
                name: 'action',
                message: '模型管理操作:',
                choices: [
                  { name: '下载推荐模型', value: 'pull' },
                  { name: '导入本地模型文件/目录 (GGUF / Safetensors)', value: 'import' },
                  { name: '设置默认模型', value: 'set' },
                  { name: '删除已安装模型', value: 'delete' },
                  { name: '取消', value: 'cancel' },
                ],
              }]);

              if (action === 'pull') {
                console.log('');
                printInfo(`推荐模型 (${hw.tier}):`);
                const choices = recommended.map(m => ({
                  name: `${m.name} (${m.size}) — ${m.reason}`,
                  value: m.id,
                }));
                choices.push({ name: '取消', value: 'cancel' });
                const { modelId } = await inqPrompt([{
                  type: 'list', name: 'modelId', message: '选择要下载的模型:', choices,
                }]);
                if (modelId !== 'cancel') {
                  printInfo(`正在下载 ${modelId}...`);
                  await ollamaMgr.pullModel(modelId, (progress) => {
                    if (progress.total > 0 && process.stdout.isTTY) {
                      process.stdout.write(`\r  ${progress.status} ${progress.percent}%`);
                    }
                  });
                  console.log('');
                  printSuccess(`模型 ${modelId} 下载完成!`);
                }
              } else if (action === 'import') {
                const ans = await inqPrompt([
                  { type: 'input', name: 'source', message: '本地路径 (.gguf/.safetensors/目录):' },
                  { type: 'input', name: 'name', message: '目标模型名 (可空自动生成):', default: '' },
                  { type: 'input', name: 'base', message: '若是 adapter，填写 base 模型 (如 qwen2.5:7b，可空):', default: '' },
                ]);
                const imported = await ollamaMgr.importModel(ans.source, ans.name, { base: ans.base || undefined });
                if (!imported.success) {
                  printError(`导入失败: ${imported.error}`);
                } else {
                  printSuccess(`导入成功: ${imported.model} (${imported.sourceKind})`);
                  printInfo(`运行: models set ${imported.model}`);
                }
              } else if (action === 'set') {
                const models = await ollamaMgr.listModels();
                if (!models.length) {
                  printInfo('暂无已安装模型');
                } else {
                  const fs = require('fs');
                  const envPath = path.resolve(__dirname, '../../.env');
                  let envContent = '';
                  try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }
                  const setEnvVar = (k, v) => {
                    const regex = new RegExp(`^${k}=.*$`, 'm');
                    const line = `${k}=${v}`;
                    if (regex.test(envContent)) envContent = envContent.replace(regex, line);
                    else envContent = envContent.trimEnd() + '\n' + line + '\n';
                    fs.writeFileSync(envPath, envContent);
                    process.env[k] = String(v);
                  };
                  const { picked } = await inqPrompt([{
                    type: 'list',
                    name: 'picked',
                    message: '选择默认 Ollama 模型:',
                    choices: models.map(m => ({ name: `${m.name} (${m.size})`, value: m.name })),
                  }]);
                  setEnvVar('GATEWAY_PREFERRED_ADAPTER', 'ollama');
                  setEnvVar('GATEWAY_PREFERRED_STRICT', 'true');
                  setEnvVar('OLLAMA_MODEL', picked);
                  try {
                    const gateway = require('../services/gateway/aiGateway');
                    await gateway.refreshAdapters();
                  } catch { /* best effort */ }
                  printSuccess(`已设置默认模型: ollama/${picked}`);
                }
              } else if (action === 'delete') {
                const models = await ollamaMgr.listModels();
                if (!models.length) {
                  printInfo('暂无已安装模型');
                } else {
                  const { picked } = await inqPrompt([{
                    type: 'list',
                    name: 'picked',
                    message: '选择要删除的模型:',
                    choices: [...models.map(m => ({ name: `${m.name} (${m.size})`, value: m.name })), { name: '取消', value: 'cancel' }],
                  }]);
                  if (picked !== 'cancel') {
                    const ok = await ollamaMgr.deleteModel(picked);
                    if (ok) printSuccess(`已删除模型: ${picked}`);
                    else printError(`删除失败: ${picked}`);
                  }
                }
              }
            } else {
              printError('Ollama 未运行。请先安装并启动: https://ollama.ai');
            }
          } catch (e) { printError(`模型管理失败: ${e.message}`); }
        } else if (selected.flag === 'image') {
          printInfo('用法: image <文件路径> <分析提示>  或  /paste <分析提示>');
          printInfo('示例: image ./screenshot.png 这是什么');
        } else if (selected.flag === 'paste') {
          const { prompt: userPrompt } = await inqPrompt([{
            type: 'input', name: 'prompt', message: '图片分析提示:',
            default: '请分析这张图片',
          }]);
          try {
            const imageService = require('../services/imageService');
            printInfo('正在读取剪贴板图片...');
            const image = imageService.readImageFromClipboard();
            imageService.printImagePreview(image);
            printInfo(`图片: ${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB — 正在分析...`);
            const prompt = buildContextualImagePrompt(
              userPrompt,
              buildImageSceneHint('clipboard paste image', history),
            );
            const aiResult = await ai().chat(prompt, {
              images: [{ base64: image.base64, mimeType: image.mimeType }],
            });
            if (aiResult.reply) {
              console.log('');
              console.log(aiResult.reply);
              console.log('');
            } else {
              printInfo('AI 未返回分析结果 — 当前模型可能不支持图片分析');
            }
          } catch (e) {
            printError(`剪贴板图片读取失败: ${e.message}`);
            printInfo('确保剪贴板中有图片数据 (截图或复制图片后使用)');
          }
        } else if (selected.flag === 'clipboard') {
          try {
            const clipAdapter = require('../services/gateway/adapters/clipboardRelayAdapter');
            const status = clipAdapter.getStatus();
            if (status.available) {
              printSuccess(status.detail);
            } else {
              printError(status.detail);
            }
            printInfo('用法: clipboard relay <提示>  或  webai <提示>');
          } catch (e) { printError(`剪贴板中继不可用: ${e.message}`); }
        } else if (selected.flag === 'websearch') {
          try {
            const webSearch = require('../services/webSearchService');
            if (!webSearch.isAvailable()) {
              printError('联网搜索不可用 — 需要 Kiro IDE 认证');
            } else {
              const { query } = await inqPrompt([{
                type: 'input', name: 'query', message: '搜索关键词:',
                validate: v => v.trim() ? true : '请输入搜索关键词',
              }]);
              printInfo(`正在搜索: ${query}`);
              const result = await webSearch.search(query);
              if (result.success) {
                console.log('');
                for (const r of (result.results || []).slice(0, 8)) {
                  console.log(chalk.bold(`  ${r.title}`));
                  if (r.url) console.log(chalk.blue(`  ${r.url}`));
                  if (r.snippet) console.log(chalk.dim(`  ${r.snippet}`));
                  console.log('');
                }
              } else {
                printError(result.error || '搜索失败');
              }
            }
          } catch (e) { printError(`搜索失败: ${e.message}`); }
        } else if (selected.flag === 'review') {
          // /review — AI code review of current git changes
          try {
            const { handleReview } = require('./handlers/review');
            await handleReview();
          } catch (e) { printError(`代码审查失败: ${e.message}`); }
        } else if (selected.route) {
          const parsed = parseInput(selected.route);
          if (parsed) {
            const result = await route(parsed);
            recoverReadlineInput();
            if (result === 'exit') {
              ai().saveConversation();
              saveHistory(history);
              setTerminalTitle('');
              console.log('');
              console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
              console.log('');
              _intentionalClose = true; process.exit(0);
            }
          }
        } else if (selected.cmd) {
          // Fallback: execute slash command through normal command pipeline.
          // Route through internal line to avoid re-entering slash-menu recursion.
          rl.emit('line', `${INTERNAL_LINE_PREFIX}${selected.cmd}`);
          return;
        }
        recoverReadlineInput();
        rl.prompt();
        return;
      }

      // Numbered command menu — uses readline input (no inquirer conflict)
      console.log('');
      const cmdWidth = Math.max(...matches.map(sc => sc.cmd.length)) + 2;
      for (let idx = 0; idx < matches.length; idx++) {
        const sc = matches[idx];
        console.log(`  ${chalk.white(`${idx + 1}.`)} ${chalk.cyan(sc.cmd.padEnd(cmdWidth))} ${chalk.dim(sc.desc)}`);
      }
      console.log(`  ${chalk.dim('0. 取消')}`);
      console.log('');

      // Wait for user to type a number
      _busy = true;
      const answer = await new Promise(resolve => {
        rl.question(chalk.dim('  输入编号: '), resolve);
      });
      _busy = false;

      const num = parseInt(answer, 10);
      if (num >= 1 && num <= matches.length) {
        const selected = matches[num - 1];
        // Process the selected command inline (avoid re-emit infinite loop)
        if (selected.route) {
          const parsed = parseInput(selected.route);
          if (parsed) {
            const result = await route(parsed);
            recoverReadlineInput();
            if (result === 'exit') {
              ai().saveConversation();
              saveHistory(history);
              setTerminalTitle('');
              console.log('');
              console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
              console.log('');
              _intentionalClose = true; process.exit(0);
            }
          }
        } else if (selected.flag) {
          // Re-emit as exact command so the exactMatch branch handles it
          rl.emit('line', `${INTERNAL_LINE_PREFIX}${selected.cmd}`);
          return;
        } else if (selected.cmd) {
          // Fallback for commands defined without explicit route/flag (e.g. /pool).
          rl.emit('line', `${INTERNAL_LINE_PREFIX}${selected.cmd}`);
          return;
        }
      }

      rl.prompt();
      return;
    }

    // Quick slash shortcuts (without menu)
    if (/^\/plan$/i.test(trimmed)) {
      _planMode = true;
      printInfo('计划模式已开启');
      rl.prompt();
      return;
    }
    if (/^\/cost$/i.test(trimmed)) {
      try {
        const tokenSvc = require('../services/tokenUsageService');
        const s = tokenSvc.getSessionUsage();
        console.log(chalk.cyan(`  本次会话: ${s.totalTokens.toLocaleString()} tokens, ${s.requests} 次请求`));
      } catch { printInfo('token 统计暂不可用'); }
      rl.prompt();
      return;
    }

    if (/^\/status$/i.test(trimmed)) {
      try {
        const aiMod = ai();
        const stats = aiMod.getConversationStats ? aiMod.getConversationStats() : null;
        const effort = aiMod.getEffort ? aiMod.getEffort() : 'high';
        const effortLabel = aiMod.getEffortPresets && aiMod.getEffortPresets()[effort]
          ? aiMod.getEffortPresets()[effort].label
          : effort;
        let toolLoop = 'unknown';
        try { toolLoop = require('../services/toolUseLoop').isEnabled() ? 'ON' : 'OFF'; } catch {}

        console.log('');
        console.log(chalk.cyan.bold('  会话状态'));
        console.log(chalk.dim(`  模型: ${aiMod.getActiveProvider() || 'AI'}`));
        console.log(chalk.dim(`  思考强度: ${effort} (${effortLabel})`));
        if (stats) {
          console.log(chalk.dim(`  上下文消息: ${stats.totalMessages} (U:${stats.userMessages} A:${stats.assistantMessages} T:${stats.toolMessages})`));
          console.log(chalk.dim(`  学习模式: ${_formatOnOff(!!stats.studyMode)}`));
        }
        console.log(chalk.dim(`  计划模式: ${_formatOnOff(_planMode)}`));
        console.log(chalk.dim(`  追踪模式: ${_formatOnOff(_traceMode)}`));
        console.log(chalk.dim(`  Usage 显示: ${_usageMode}`));
        console.log(chalk.dim(`  触发策略: ${_activationMode}${_activationMode === 'mention' ? ` (@${_activationMentionName})` : ''}`));
        console.log(chalk.dim(`  工具循环: ${toolLoop}`));
        console.log('');
      } catch (e) {
        printError(`状态读取失败: ${e.message}`);
      }
      rl.prompt();
      return;
    }

    if (/^\/(?:new|reset)$/i.test(trimmed)) {
      const aiMod = ai();
      const before = aiMod.getConversationStats ? aiMod.getConversationStats().totalMessages : null;
      aiMod.clearHistory();
      if (before && before > 0) printSuccess(`已重置会话上下文（清理 ${before} 条消息）`);
      else printInfo('会话上下文已清空');
      rl.prompt();
      return;
    }

    const compactArgs = _parseCompactArgs(trimmed);
    if (compactArgs) {
      if (compactArgs.invalid && compactArgs.invalid.length > 0) {
        printError('用法: /compact [light|balanced|aggressive|auto] [--keep N] [说明文本]');
        rl.prompt();
        return;
      }

      const aiMod = ai();
      if (typeof aiMod.compactHistory !== 'function') {
        printError('当前版本不支持 /compact');
        rl.prompt();
        return;
      }
      const compacted = aiMod.compactHistory({
        keepRecent: compactArgs.keepRecent,
        mode: compactArgs.mode,
        instructions: compactArgs.instructions,
      });
      if (!compacted.changed) {
        printInfo(`无需压缩：当前上下文较短（${compacted.previousCount} 条）`);
      } else {
        printSuccess(`上下文已压缩：${compacted.previousCount} -> ${compacted.nextCount}（压缩 ${compacted.compactedCount} 条）`);
        printInfo(`压缩策略: ${compacted.mode || compactArgs.mode}`);
        if (compactArgs.instructions) {
          printInfo(`压缩焦点: ${compactArgs.instructions}`);
        }
      }
      rl.prompt();
      return;
    }

    const thinkMatch = /^\/think(?:\s+(\S+))?$/i.exec(trimmed);
    if (thinkMatch) {
      const raw = String(thinkMatch[1] || 'status').toLowerCase();
      const mapped = {
        status: 'status',
        low: 'low',
        fast: 'low',
        quick: 'low',
        medium: 'medium',
        med: 'medium',
        high: 'high',
        max: 'max',
      };
      const level = mapped[raw] || null;
      if (!level) {
        printError('用法: /think <low|medium|high|max>');
        rl.prompt();
        return;
      }
      if (level === 'status') {
        const current = ai().getEffort();
        const label = ai().getEffortPresets()?.[current]?.label || current;
        printInfo(`当前思考强度: ${current} (${label})`);
        rl.prompt();
        return;
      }
      if (ai().setEffort(level)) {
        const p = ai().getEffortPresets()[level];
        printSuccess(`思考强度已设置为 ${level} (${p.label})`);
      } else {
        printError('思考强度设置失败');
      }
      rl.prompt();
      return;
    }

    const traceAction = _parseToggleAction(trimmed, 'trace');
    if (traceAction) {
      if (traceAction === 'invalid') {
        printError('用法: /trace <on|off|status>');
      } else if (traceAction === 'status') {
        printInfo(`追踪模式: ${_traceMode ? chalk.green('ON') : chalk.dim('OFF')}`);
      } else {
        _traceMode = traceAction === 'on';
        printSuccess(`追踪模式已${_traceMode ? '开启' : '关闭'}`);
      }
      rl.prompt();
      return;
    }

    const usageMatch = /^\/usage(?:\s+(\S+))?$/i.exec(trimmed);
    if (usageMatch) {
      const mode = String(usageMatch[1] || 'status').toLowerCase();
      if (mode === 'status') {
        printInfo(`Usage 显示模式: ${_usageMode}`);
      } else if (['off', 'tokens', 'full'].includes(mode)) {
        _usageMode = mode;
        printSuccess(`Usage 显示模式已切换为 ${mode}`);
      } else {
        printError('用法: /usage <off|tokens|full|status>');
      }
      rl.prompt();
      return;
    }

    const activationCmd = _parseActivationCommand(trimmed);
    if (activationCmd) {
      if (activationCmd.invalid.length > 0) {
        printError('用法: /activation [always|mention|status] [--name <触发词>]');
        rl.prompt();
        return;
      }

      if (activationCmd.action === 'status') {
        const extra = _activationMode === 'mention' ? ` (@${_activationMentionName})` : '';
        printInfo(`触发策略: ${_activationMode}${extra}`);
        rl.prompt();
        return;
      }

      if (activationCmd.name) {
        _activationMentionName = _normalizeMentionTrigger(activationCmd.name);
      }
      _activationMode = activationCmd.action;
      if (_activationMode === 'mention') {
        printSuccess(`触发策略已切换为 mention (@${_activationMentionName})`);
      } else {
        printSuccess('触发策略已切换为 always');
      }
      rl.prompt();
      return;
    }

    if (/^\/hud$/i.test(trimmed)) {
      const hud = require('./hudRenderer');
      hud.refreshGit();
      console.log(hud.renderHudPanel(process.stdout.columns || 80));
      rl.prompt();
      return;
    }
    if (/^\/export-roles$/i.test(trimmed)) {
      try {
        const rolesFile = _exportCompleteRoles();
        printSuccess(`Complete Roles 已导出: ${rolesFile}`);
        printInfo('将此文件发送给他人或保存，在新机器上使用 /import-roles 恢复');
      } catch (e) { printError(`导出失败: ${e.message}`); }
      rl.prompt();
      return;
    }
    if (/^\/import-roles$/i.test(trimmed)) {
      const { filePath } = await inqPrompt([{
        type: 'input',
        name: 'filePath',
        message: 'Complete Roles 文件路径:',
        default: path.join(os.homedir(), 'khy_complete_roles.json'),
      }]);
      recoverReadlineInput();
      try {
        const count = _importCompleteRoles(filePath);
        printSuccess(`Complete Roles 已导入! 恢复了 ${count} 项配置`);
        printInfo('重启终端后完全生效');
      } catch (e) { printError(`导入失败: ${e.message}`); }
      rl.prompt();
      return;
    }

    // ── /study — gated study mode toggle (Owner Secret required) ──
    const studyCmd = _parseStudyCommand(trimmed);
    if (studyCmd) {
      if (studyCmd.invalid.length > 0) {
        printError('用法: /study [on|off|status] [--secret <value>]');
        rl.prompt();
        return;
      }

      const aiMod = ai();
      if (studyCmd.action === 'status') {
        printInfo(`学习模式当前状态: ${aiMod.isStudyMode() ? chalk.green('ON') : chalk.dim('OFF')}`);
        if (!aiMod.isStudyMode()) {
          printInfo('开启命令: /study on');
        }
        rl.prompt();
        return;
      }

      const verify = await _verifyStudyOwnerSecret(studyCmd.secret);
      if (!verify.ok) {
        printError(verify.error);
        rl.prompt();
        return;
      }

      if (studyCmd.action === 'on') {
        if (aiMod.isStudyMode()) {
          printInfo('学习模式已处于激活状态');
          rl.prompt();
          return;
        }

        aiMod.enableStudyMode();
        console.log('');
        printSuccess('🎓 学习模式已解锁！');
        console.log(chalk.dim('  现在你可以向 AI 提问关于本项目的一切:'));
        console.log(chalk.dim('    • 项目架构与模块关系'));
        console.log(chalk.dim('    • 任意源码文件的实现逻辑'));
        console.log(chalk.dim('    • 设计模式与技术决策'));
        console.log(chalk.dim('    • 前后端交互与数据流'));
        console.log(chalk.dim('    • AI 网关适配器系统'));
        console.log(chalk.dim('    • 策略引擎与回测引擎'));
        console.log('');
      } else if (studyCmd.action === 'off') {
        if (!aiMod.isStudyMode()) {
          printInfo('学习模式已处于关闭状态');
          rl.prompt();
          return;
        }
        aiMod.disableStudyMode();
        printSuccess('学习模式已关闭');
      }

      rl.prompt();
      return;
    }

    // /btw — queue hint without interrupting current AI work
    // Keep behavior aligned with full REPL: always enqueue the hint payload itself.
    if (/^\/btw\s+/i.test(trimmed)) {
      const hint = trimmed.replace(/^\/btw\s+/i, '').trim();
      if (hint) {
        _btwQueue.push(hint);
        console.log(chalk.dim(`  📌 提示已排队 (当前队列: ${_btwQueue.length})`));
      } else {
        printInfo('用法: /btw <提示内容>');
      }
      rl.prompt();
      return;
    }

    // ── /learn — import Claude transcript for self-learning ──
    if (/^\/learn$/i.test(trimmed)) {
      const inq = inquirer();
      const { filePath: transcriptPath } = await inq.prompt([{
        type: 'input',
        name: 'filePath',
        message: 'Claude 轨迹文件路径 (.jsonl):',
        validate: v => v.endsWith('.jsonl') || v.endsWith('.json') ? true : '请输入 .jsonl 或 .json 文件路径',
      }]);
      try {
        const optimizer = require('../services/selfOptimizer');
        const result = optimizer.learnFromTranscript(transcriptPath);
        if (result.success) {
          console.log('');
          printSuccess(`轨迹学习完成!`);
          console.log(chalk.dim(`  总消息: ${result.stats.totalMessages}`));
          console.log(chalk.dim(`  用户消息: ${result.stats.userMessages} · AI 消息: ${result.stats.assistantMessages}`));
          console.log(chalk.dim(`  工具调用: ${result.stats.toolCalls} · 错误: ${result.stats.errors}`));
          console.log(chalk.dim(`  用户纠正: ${result.stats.corrections} · 用户确认: ${result.stats.confirmations}`));
          console.log(chalk.cyan(`  新增模式: ${result.patternsAdded} 条`));
          console.log('');
          printInfo('学到的经验将在后续对话中自动应用');
        } else {
          printError(`学习失败: ${result.error}`);
        }
      } catch (e) { printError(`轨迹解析失败: ${e.message}`); }
      rl.prompt();
      return;
    }

    // ── /optimize — AI self-optimization ──
    if (/^\/optimize$/i.test(trimmed)) {
      const optimizer = require('../services/selfOptimizer');
      const summary = optimizer.getLearningSummary();

      console.log('');
      console.log(chalk.cyan.bold('  AI 自我优化面板'));
      console.log('');
      console.log(chalk.white('  学习状态:'));
      console.log(chalk.dim(`    已学习模式: ${summary.patterns} 条`));
      console.log(chalk.dim(`    纠正经验: ${summary.corrections} · 确认经验: ${summary.confirmations}`));
      console.log(chalk.dim(`    工作流模式: ${summary.workflows} · 错误恢复: ${summary.errors}`));
      console.log(chalk.dim(`    自定义提示词: ${summary.hasCustomPrompt ? chalk.green('●') : chalk.dim('○')}`));
      console.log(chalk.dim(`    自定义角色: ${summary.hasCustomRoles ? chalk.green('●') : chalk.dim('○')}`));
      console.log(chalk.dim(`    提示词库: ${summary.hasPromptLibrary ? chalk.green('●') : chalk.dim('○')}`));
      if (summary.lastOptimized) {
        console.log(chalk.dim(`    上次优化: ${new Date(summary.lastOptimized).toLocaleString('zh-CN')}`));
      }
      console.log('');

      if (summary.patterns > 0) {
        const inq = inquirer();
        const { action } = await inq.prompt([{
          type: 'list',
          name: 'action',
          message: '优化操作:',
          choices: [
            { name: '让 AI 基于学到的经验自动优化提示词', value: 'auto' },
            { name: '查看已学习的模式', value: 'view' },
            { name: '清除学习数据', value: 'clear' },
            { name: '↩️  返回', value: 'back' },
          ],
        }]);

        if (action === 'auto') {
          printInfo('正在基于学习数据生成优化建议...');
          const learned = optimizer.getLearnedContext();
          if (learned) {
            const optimizePrompt = `你是一个 AI 系统优化器。以下是从历史对话中提取的学习经验：

${learned}

当前系统提示词：
${optimizer.readConfig('system_prompt.txt') || '(默认)'}

请基于这些经验，生成一段优化后的补充指令（不超过 500 字），将其追加到系统提示词中以改进未来的对话质量。
只输出优化的补充内容，不要重复原有内容。格式为纯文本。`;

            try {
              const result = await ai().chat(optimizePrompt, { _isFollowUp: true, effort: 'high' });
              if (result.reply) {
                console.log('');
                console.log(chalk.cyan('  AI 生成的优化建议:'));
                result.reply.split('\n').forEach(l => console.log(`  ${l}`));
                console.log('');

                const { apply } = await inq.prompt([{
                  type: 'confirm',
                  name: 'apply',
                  message: '是否应用此优化?',
                  default: true,
                }]);

                if (apply) {
                  // Append to prompt library as learned instruction
                  let lib = {};
                  try { const raw = optimizer.readConfig('prompt_library.json'); if (raw) lib = JSON.parse(raw); } catch {}
                  if (!lib.instructions) lib.instructions = [];
                  lib.instructions.push(result.reply.trim());
                  const writeResult = optimizer.applyOptimization('prompt_library', lib, 'AI self-optimization based on learned patterns');
                  if (writeResult.success) {
                    printSuccess('优化已应用! 配置文件已安全更新');
                    printInfo('无需重启 — 下次对话即生效');
                  } else {
                    printError(`应用失败: ${writeResult.error}`);
                  }
                }
              }
            } catch (e) { printError(`优化请求失败: ${e.message}`); }
          } else {
            printInfo('暂无学习数据，请先使用 /learn 导入轨迹文件');
          }
        }

        if (action === 'view') {
          const patterns = optimizer.readConfig('learned_patterns.json');
          if (patterns) {
            const parsed = JSON.parse(patterns);
            console.log('');
            for (const p of parsed.slice(-10)) {
              const icon = p.type === 'correction' ? chalk.red('✗')
                : p.type === 'confirmation' ? chalk.green('✓')
                : p.type === 'tool_sequence' ? chalk.cyan('→')
                : chalk.yellow('!');
              console.log(`  ${icon} ${chalk.dim(`[${p.type}]`)} ${p.lesson}`);
            }
            console.log('');
          } else {
            printInfo('暂无学习数据');
          }
        }

        if (action === 'clear') {
          const { confirm } = await inq.prompt([{
            type: 'confirm', name: 'confirm', message: '确认清除所有学习数据?', default: false,
          }]);
          if (confirm) {
            optimizer.safeWriteConfig('learned_patterns.json', []);
            printSuccess('学习数据已清除');
          }
        }
      } else {
        printInfo('暂无学习数据。使用 /learn 导入 Claude 轨迹文件开始学习');
      }
      console.log('');
      rl.prompt();
      return;
    }

    // ── /optimize-log ──
    if (/^\/optimize-log$/i.test(trimmed)) {
      const optimizer = require('../services/selfOptimizer');
      const history = optimizer.getOptimizationHistory(15);
      if (history.length === 0) {
        printInfo('暂无优化记录');
      } else {
        console.log('');
        console.log(chalk.cyan.bold('  优化历史'));
        console.log('');
        for (const h of history) {
          const time = new Date(h.timestamp).toLocaleString('zh-CN');
          const icon = h.action === 'ai_optimize' ? chalk.green('●')
            : h.action === 'transcript_learn' ? chalk.cyan('●')
            : h.action === 'config_rollback' ? chalk.yellow('●')
            : chalk.dim('●');
          console.log(`  ${icon} ${chalk.dim(time)} ${chalk.white(h.action)} → ${h.target}`);
        }
        console.log('');
      }
      rl.prompt();
      return;
    }

    // ── /pool — API Key pool status ──
    if (/^\/pool$/i.test(trimmed)) {
      try {
        const pool = require('../services/apiKeyPool');
        pool.init();
        const allStatus = pool.getAllStatus();
        const providers = Object.keys(allStatus);

        console.log('');
        console.log(chalk.cyan.bold('  API Key 池状态'));
        console.log('');

        if (providers.length === 0) {
          console.log(chalk.dim('  暂无已配置的 Key'));
          console.log(chalk.dim('  运行 khy gateway → provider-keys 添加 API Key'));
        } else {
          for (const provider of providers) {
            const keys = allStatus[provider];
            const activeCount = keys.filter(k => k.status === 'active').length;
            console.log(chalk.white(`  ${provider.charAt(0).toUpperCase() + provider.slice(1)}`) +
              chalk.dim(` (${keys.length} key${keys.length > 1 ? 's' : ''}, ${activeCount} active)`));

            for (const k of keys) {
              const icon = k.status === 'active' ? chalk.green('●')
                : k.status === 'cooldown' ? chalk.yellow('○')
                : chalk.red('○');
              const label = k.label ? chalk.dim(` ${k.label}`) : '';
              const priority = chalk.dim(` P:${k.priority}`);
              let statusInfo = '';
              if (k.status === 'cooldown') {
                statusInfo = chalk.yellow(` ⏳ ${k.cooldownRemaining}s`);
              }
              const stats = chalk.dim(` ${k.totalRequests} req · ${k.totalFailures} fail`);
              const errInfo = k.lastError ? chalk.dim(chalk.red(` · ${k.lastError.slice(0, 30)}`)) : '';
              console.log(`    ${icon} ${chalk.dim(k.keyPreview)}${label}${priority}${statusInfo}${stats}${errInfo}`);
            }
            console.log('');
          }
        }
      } catch (e) {
        printError(`Key 池加载失败: ${e.message}`);
      }
      console.log('');
      rl.prompt();
      return;
    }

    // ── /push — push project to GitHub/Gitee private repo ──
    if (/^\/push$/i.test(trimmed)) {
      const { execSync } = require('child_process');
      const projectCwd = process.env.KHYQUANT_CWD || process.cwd();

      console.log('');
      console.log(chalk.cyan.bold('  项目推送到私人仓库'));
      console.log('');

      // Check git status
      try {
        const branch = execSync('git rev-parse --abbrev-ref HEAD', { cwd: projectCwd, encoding: 'utf-8', stdio: 'pipe' }).trim();
        const status = execSync('git status --porcelain', { cwd: projectCwd, encoding: 'utf-8', stdio: 'pipe' }).trim();
        const remotes = execSync('git remote -v', { cwd: projectCwd, encoding: 'utf-8', stdio: 'pipe' }).trim();

        console.log(chalk.dim(`  分支: ${branch}`));
        console.log(chalk.dim(`  工作区: ${status ? `${status.split('\n').length} 个文件改动` : '干净'}`));
        console.log('');

        // Parse existing remotes
        const remoteMap = {};
        for (const line of remotes.split('\n').filter(Boolean)) {
          const match = line.match(/^(\S+)\s+(\S+)\s+\(push\)/);
          if (match) remoteMap[match[1]] = match[2];
        }

        if (Object.keys(remoteMap).length > 0) {
          console.log(chalk.dim('  已配置的远程仓库:'));
          for (const [name, url] of Object.entries(remoteMap)) {
            // Mask tokens in URL
            const safeUrl = url.replace(/(:\/\/)([^@]+)@/, '$1***@');
            console.log(chalk.dim(`    ${name}: ${safeUrl}`));
          }
          console.log('');
        }

        const inq = inquirer();
        const { action } = await inq.prompt([{
          type: 'list',
          name: 'action',
          message: '操作:',
          choices: [
            ...(Object.keys(remoteMap).length > 0
              ? Object.keys(remoteMap).map(name => ({
                  name: `推送到 ${name} (${remoteMap[name].includes('gitee') ? 'Gitee' : remoteMap[name].includes('github') ? 'GitHub' : 'remote'})`,
                  value: `push-${name}`,
                }))
              : []),
            { name: '添加 GitHub 私人仓库', value: 'add-github' },
            { name: '添加 Gitee 私人仓库', value: 'add-gitee' },
            { name: '↩️  返回', value: 'back' },
          ],
        }]);

        if (action === 'back') {
          rl.prompt();
          return;
        }

        if (action.startsWith('push-')) {
          const remoteName = action.replace('push-', '');
          // Commit first if dirty
          if (status) {
            const { doCommit } = await inq.prompt([{
              type: 'confirm',
              name: 'doCommit',
              message: `工作区有改动，是否先提交?`,
              default: true,
            }]);
            if (doCommit) {
              const { commitMsg } = await inq.prompt([{
                type: 'input',
                name: 'commitMsg',
                message: '提交信息:',
                default: `Update ${new Date().toISOString().slice(0, 10)}`,
              }]);
              try {
                execSync('git add -A', { cwd: projectCwd, stdio: 'pipe' });
                execSync(`git commit -m "${commitMsg.replace(/"/g, '\\"')}"`, { cwd: projectCwd, stdio: 'pipe' });
                printSuccess('已提交');
              } catch { printInfo('无新改动需要提交'); }
            }
          }

          // Push
          const renderer = require('./aiRenderer');
          const pushTracker = new renderer.ToolUseTracker('Push', `${remoteName}`);
          pushTracker.printHeader();
          pushTracker.toolStart('git push', `${remoteName} ${branch}`);
          try {
            execSync(`git push ${remoteName} ${branch}`, { cwd: projectCwd, encoding: 'utf-8', stdio: 'pipe', timeout: 120000 });
            pushTracker.toolEnd('git push', 'success', '', 0);
            pushTracker.finish();
            printSuccess(`已推送到 ${remoteName} (${branch})`);
          } catch (e) {
            pushTracker.toolEnd('git push', 'error', e.message, 0);
            pushTracker.finish();
            printError(`推送失败: ${e.message}`);
          }
        }

        if (action === 'add-github' || action === 'add-gitee') {
          const platform = action === 'add-github' ? 'github' : 'gitee';
          const domain = platform === 'github' ? 'github.com' : 'gitee.com';

          const { remoteName } = await inq.prompt([{
            type: 'input',
            name: 'remoteName',
            message: '远程名称:',
            default: platform,
            validate: v => v.trim().length > 0 || '不能为空',
          }]);

          const { repoUrl } = await inq.prompt([{
            type: 'input',
            name: 'repoUrl',
            message: `仓库地址 (SSH 或 HTTPS):`,
            default: `git@${domain}:username/khy-os.git`,
            validate: v => v.includes(domain) || v.includes('@') ? true : `请输入 ${platform} 仓库地址`,
          }]);

          try {
            try {
              execSync(`git remote remove ${remoteName}`, { cwd: projectCwd, stdio: 'pipe' });
            } catch { /* no existing remote */ }
            execSync(`git remote add ${remoteName} ${repoUrl}`, { cwd: projectCwd, stdio: 'pipe' });
            printSuccess(`已添加远程仓库: ${remoteName} → ${repoUrl}`);
            printInfo(`使用 /push 再次执行即可推送`);
          } catch (e) {
            printError(`添加失败: ${e.message}`);
          }
        }
      } catch (e) {
        printError(`非 git 仓库或 git 不可用: ${e.message}`);
      }
      console.log('');
      rl.prompt();
      return;
    }

    // ── Support dropping .jsonl files directly ──
    if (trimmed.endsWith('.jsonl') || trimmed.endsWith('.json')) {
      const candidatePath = trimmed.replace(/^['"`]+|['"`]+$/g, '').replace(/\\ /g, ' ');
      const resolvedPath = path.isAbsolute(candidatePath) ? candidatePath : path.resolve(process.env.KHYQUANT_CWD || process.cwd(), candidatePath);
      if (fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isFile()) {
        // Check if it looks like a Claude transcript
        try {
          const firstLine = fs.readFileSync(resolvedPath, 'utf-8').split('\n')[0];
          const parsed = JSON.parse(firstLine);
          if (parsed.role || parsed.type || parsed.content) {
            printInfo(`检测到 Claude 轨迹文件，正在学习...`);
            const optimizer = require('../services/selfOptimizer');
            const result = optimizer.learnFromTranscript(resolvedPath);
            if (result.success) {
              printSuccess(`学习完成! 新增 ${result.patternsAdded} 条模式 (共 ${result.stats.totalMessages} 条消息)`);
            } else {
              printError(`学习失败: ${result.error || '未知错误'}`);
            }
            rl.prompt();
            return;
          }
        } catch { /* not a transcript, fall through to normal processing */ }
      }
    }

    // ── App Registry: dynamic app command interception ──
    // If user types an app name (e.g., "khyquant"), start it via appRegistry.
    try {
      const appRegistry = require('../services/appRegistry');
      const matchedApp = appRegistry.findByCommand(trimmed);
      if (matchedApp) {
        const result = await appRegistry.start(matchedApp.name);
        if (result.success) {
          if (result.alreadyRunning) {
            printSuccess(`${matchedApp.name} 已在运行 (端口 ${result.port})`);
          } else {
            printSuccess(`${matchedApp.name} 已启动 → http://localhost:${result.port}`);
          }

          // Show frontend URL if configured
          const frontendPort = matchedApp.frontendPort;
          if (frontendPort) {
            const net = require('net');
            const frontendUp = await new Promise((resolve) => {
              const srv = net.createServer();
              srv.once('error', (err) => resolve(err.code === 'EADDRINUSE'));
              srv.once('listening', () => { srv.close(); resolve(false); });
              srv.listen(frontendPort);
            });
            if (frontendUp) {
              printSuccess(`前端可访问 → http://localhost:${frontendPort}`);
            } else {
              printInfo(`前端: http://localhost:${result.port} (后端一体化服务)`);
            }
          }

          // Auto-open browser
          try {
            const url = `http://localhost:${frontendPort || result.port}`;
            const { exec } = require('child_process');
            const cmd = process.platform === 'win32' ? `start "" "${url}"`
                      : process.platform === 'darwin' ? `open "${url}"`
                      : `xdg-open "${url}"`;
            exec(cmd, { timeout: 5000 });
            printInfo(`已打开浏览器: ${url}`);
          } catch { /* non-critical */ }
        } else {
          printError(result.error);
        }
        console.log('');
        rl.prompt();
        return;
      }
    } catch { /* appRegistry not available, continue */ }

    // Concurrency guard — only queue genuine user input, not echoed output
    if (_busy) {
      // /interrupt (or /i) while busy: request cancellation and prioritize next input
      const interruptMatch = /^\/(?:interrupt|i)\s+([\s\S]+)$/i.exec(trimmed);
      if (interruptMatch) {
        const nextInput = interruptMatch[1].trim();
        if (!nextInput) {
          printInfo('用法: /interrupt <新输入> 或 /i <新输入>');
          return;
        }
        _queuedInputs.unshift(nextInput);
        const cancelled = _requestRelayCancel('Interrupted by /interrupt');
        if (cancelled) {
          console.log(chalk.dim('  ⚡ 已中断当前 Web 中转请求，完成后优先处理新输入'));
        } else {
          console.log(chalk.dim('  ⚡ 已记录中断请求，将在当前步骤结束后优先处理新输入'));
        }
        return;
      }

      // Filter out lines that look like system output (not real user input)
      const looksLikeOutput = /^[·└●✳⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏✓⚠ℹ┌│┘─╭╮╰╯]/.test(trimmed)
        || /^\s*(就绪|处理中|请求 AI|生成|AI 回复|Startup Profile)/.test(trimmed)
        || /^>\s*状态:\s*/.test(trimmed)
        || /^>\s*(向\s*AI\s*发送请求|进入计划模式|执行计划|计划模式)/.test(trimmed)
        || /^\/\w+\s+帮助/.test(trimmed);
      if (looksLikeOutput) return; // silently ignore echoed output

      // Merge rapid consecutive lines as one queued block (fixes multi-line paste split)
      const now = Date.now();
      if (_queuedInputs.length > 0 && (now - _lastBusyMergeAt) <= 250) {
        _queuedInputs[_queuedInputs.length - 1] = `${_queuedInputs[_queuedInputs.length - 1]}\n${trimmed}`;
      } else {
        _queuedInputs.push(trimmed);
      }
      _lastBusyMergeAt = now;
      const queueLen = _queuedInputs.length;
      const preview = _queuedInputs[queueLen - 1].replace(/\n/g, ' ').slice(0, 40);
      console.log(chalk.dim(`  ○ 已排队: "${preview}${preview.length >= 40 ? '...' : ''}" (队列: ${queueLen})`));
      console.log(chalk.dim('    └ 输入 /i <新内容> 可请求打断并优先处理'));
      showBusyInterjectPrompt();
      return;
    }
    _busy = true;
    history.push(trimmed);

    try {
      // Parse input
      const parsed = parseInput(trimmed);

      // Check for blocked commands
      if (parsed && BLOCKED_COMMANDS.has(parsed.command)) {
        printInfo(`"${parsed.command}" 需要完整模式。请运行 khy 启动。`);
        _busy = false;
        rl.prompt();
        return;
      }

      // Route recognized commands
      if (parsed) {
        const result = await route(parsed);

        // Restore stdin/readline after route handlers that may use inquirer internally.
        // Inquirer creates its own readline and may pause stdin, leaving our rl deaf.
        recoverReadlineInput();

        if (result === 'exit') {
          ai().saveConversation();
          saveHistory(history);
          setTerminalTitle('');
          console.log('');
          console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
          console.log('');
          _intentionalClose = true; process.exit(0);
        }

        if (result === true) {
          _busy = false;
          rl.prompt();
          return;
        }

        // 'menu' and special returns
        if (result === 'menu') {
          const { runMenuLoop } = require('./menu');
          await runMenuLoop();
          _busy = false;
          rl.prompt();
          return;
        }
      }

      // ── AI path (unrecognized command or AI forward) ──
      let aiInput = (parsed && parsed.aiForward) ? parsed.aiForward : trimmed;

      const activationGate = _applyActivationPolicy(aiInput, _activationMode, _activationMentionName);
      if (!activationGate.accepted) {
        printInfo(activationGate.reason);
        _busy = false;
        rl.prompt();
        return;
      }
      aiInput = activationGate.prompt;

      // Inline image path detection: allows direct paste like:
      // "这个图什么意思 file:///home/.../a.png"
      const inlineImage = extractInlineImageIntent(aiInput, buildImageSceneHint(aiInput, history));
      if (inlineImage) {
        try {
          const imageService = require('../services/imageService');
          const renderer = require('./aiRenderer');
          const readStart = Date.now();
          const image = imageService.readImageFromFile(inlineImage.filePath);
          renderer.printToolCallResult('Read', { path: inlineImage.filePath }, 'success',
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
            Date.now() - readStart
          );

          imageService.printImagePreview(image);
          printInfo('检测到图片路径，已自动进入图片分析模式');

          const aiResult = await ai().chat(inlineImage.prompt, {
            images: [{ base64: image.base64, mimeType: image.mimeType }],
          });

          if (aiResult.reply) {
            if (aiResult.errorType) {
              printError(aiResult.reply);
              printInfo('提示: 可用 /model 切换到支持视觉的模型后重试');
            } else {
              renderer.printStepLine('success', 'AI 图片分析', aiResult.provider || 'vision');
              const rendered = renderer.renderAiResponse(aiResult.reply);
              rendered.split('\n').forEach(l => console.log(`  ${l}`));
            }
          } else {
            printInfo('AI 未返回分析结果 — 当前模型可能不支持图片分析');
          }
          console.log('');
          _busy = false;
          rl.prompt();
          return;
        } catch (imgErr) {
          printError(`图片处理失败: ${imgErr.message}`);
          _busy = false;
          rl.prompt();
          return;
        }
      }

      // Merge queued hints
      let finalAiInput = aiInput;
      if (_btwQueue.length > 0) {
        const hints = _btwQueue.splice(0).join('\n');
        finalAiInput = `${aiInput}\n\n[附加提示]\n${hints}`;
      }

      // Model file drag-and-drop detection (before text file detection)
      try {
        const modelImport = require('../services/modelImportService');
        const dragCandidate = finalAiInput.replace(/^['"`]+|['"`]+$/g, '').replace(/\\ /g, ' ').split(/\s+/)[0];
        if (modelImport.looksLikeModelPath(dragCandidate)) {
          const userCwd = process.env.KHYQUANT_CWD || process.cwd();
          const resolvedModel = path.isAbsolute(dragCandidate) ? dragCandidate : path.resolve(userCwd, dragCandidate);
          if (fs.existsSync(resolvedModel)) {
            const stat = fs.statSync(resolvedModel);
            const sizeInfo = stat.isFile() ? `${(stat.size / (1024 * 1024)).toFixed(1)} MB` : 'directory';
            printInfo(`检测到模型文件: ${path.basename(resolvedModel)} (${sizeInfo})`);
            const followUp = finalAiInput.slice(dragCandidate.length).trim();
            finalAiInput = `[模型文件检测: ${resolvedModel}]\n${followUp || '请帮我导入这个模型'}`;
          }
        } else if (modelImport.looksLikeModelUrl(finalAiInput)) {
          const urlMatch = finalAiInput.match(/https?:\/\/[^\s]+/i);
          if (urlMatch) {
            printInfo(`检测到模型下载链接: ${urlMatch[0].slice(0, 80)}...`);
            const rest = finalAiInput.replace(urlMatch[0], '').trim();
            finalAiInput = `[模型下载链接: ${urlMatch[0]}]\n${rest || '请帮我下载并导入这个模型'}`;
          }
        }
      } catch { /* best-effort */ }

      // File drag-and-drop detection
      try {
        const fileExts = /\.(txt|js|ts|py|json|csv|md|log|yaml|yml|toml|html|css|vue|sql|sh|bat|xml|ini|cfg|conf|java|go|rs|c|cpp|h|rb|php)$/i;
        const pathCandidate = finalAiInput.replace(/^['"`]+|['"`]+$/g, '').replace(/\\ /g, ' ').split(/\s+/)[0];
        if (fileExts.test(pathCandidate)) {
          const userCwd = process.env.KHYQUANT_CWD || process.cwd();
          const resolvedPath = path.isAbsolute(pathCandidate) ? pathCandidate : path.resolve(userCwd, pathCandidate);
          if (fs.existsSync(resolvedPath) && fs.statSync(resolvedPath).isFile()) {
            const stat = fs.statSync(resolvedPath);
            const maxSize = 100 * 1024;
            const content = fs.readFileSync(resolvedPath, 'utf-8').slice(0, maxSize);
            const sizeInfo = stat.size > maxSize ? `截取前 100KB` : `${(stat.size / 1024).toFixed(1)} KB`;
            printInfo(`已读取文件: ${path.basename(resolvedPath)} (${sizeInfo})`);
            const followUp = finalAiInput.slice(pathCandidate.length).trim();
            finalAiInput = `[文件内容: ${path.basename(resolvedPath)}]\n\`\`\`\n${content}\n\`\`\`\n\n${followUp || '请分析这个文件的内容'}`;
          }
        }
      } catch { /* best-effort */ }

      // ── Multi-agent trigger ──
      const agentRunner = require('../services/cliAgentRunner');
      if (agentRunner.shouldUseMultiAgent(finalAiInput)) {
        const agentDisplay = require('./agentRenderer');
        const renderer = require('./aiRenderer');

        // Claude Code-style tool use tracker for multi-agent
        const toolTracker = new renderer.ToolUseTracker('Agents', finalAiInput.slice(0, 50).replace(/\n/g, ' '));
        toolTracker.printHeader();

        renderer.printActionHint(`分解任务并启动多智能体并行分析...`);
        const subtasks = agentRunner.decomposeTask(finalAiInput);

        // Track each agent as a tool use
        for (const st of subtasks) {
          toolTracker.toolStart(st.name, st.task ? st.task.slice(0, 60) : '');
        }

        const agentResults = await agentRunner.runAgents(subtasks, {
          ai: ai(),
          onProgress: (states) => {
            // Update tool tracker with agent status changes
            for (const state of states) {
              if (state.status === 'completed' || state.status === 'error') {
                toolTracker.toolEnd(state.name, state.status === 'completed' ? 'success' : 'error',
                  '', state.elapsed || 0);
                if (state.tokens) toolTracker.addTokens(state.tokens);
              }
            }
            try { require('./hudRenderer').agentUpdate(states); } catch {}
          },
        });

        // Collapse to "Done" summary
        const totalTokens = agentResults.reduce((sum, a) => sum + (a.tokens || 0), 0);
        toolTracker.addTokens(totalTokens);
        toolTracker.finish();

        renderer.printToolCallStart('Synthesize', '综合分析');
        const synthStart = Date.now();
        const synthesized = await agentRunner.synthesizeResults(agentResults, finalAiInput, ai());
        renderer.printToolCallResult('Synthesize', '综合分析', 'success', '合成完成', Date.now() - synthStart);

        agentDisplay.renderSynthesisResult(synthesized, agentResults);
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // ── Plan mode ──
      const planService = require('../services/planModeService');
      if (looksLikeUiEchoInput(aiInput)) {
        printInfo('检测到界面状态文本，已忽略该输入');
        return;
      }
      let needsPlan = false;
      const bypassPlan = shouldBypassPlanMode(aiInput);
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        needsPlan = bypassPlan ? false : (pp.needsPlan || _planMode);
      } catch { /* best effort */ }

      if (bypassPlan && _planMode) _planMode = false;
      if (bypassPlan) {
        printInfo('已按请求跳过计划模式，直接执行任务');
      }

      if (needsPlan || _planMode) {
        const renderer = require('./aiRenderer');
        _planMode = false;

        renderer.printActionHint(`进入计划模式，分析任务并生成执行计划...`);
        renderer.printStepLine('active', '计划模式', '生成执行计划...');
        const { plan, rawResponse, provider, elapsed, errorType } = await planService.enterPlanMode(finalAiInput, ai());

        if (plan && plan.steps.length > 0) {
          if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
          renderer.printStepLine('success', '计划模式', `生成 ${plan.steps.length} 步执行计划`);

          const approval = await planService.presentForApproval(plan, renderer, rl);

          if (approval.approved) {
            console.log('');
            renderer.printStepLine('active', '执行计划', `${plan.steps.filter(s => s.status !== 'skipped').length} 步骤`);

            const results = await planService.executePlanSteps(plan, {
              ai: ai(), renderer, rl, route, parseInput,
            });

            if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
            renderer.printStepLine('success', '计划执行完成', `${results.filter(r => r.step.status === 'completed').length}/${results.length} 成功`);

            for (const { step, result } of results) {
              const attempts = Number(result?._planAttempts || 0);
              if (step.status === 'error') {
                const reason = String(result?.error || '未知错误');
                console.log(chalk.red(`  ✗ 步骤 ${step.id} 失败${attempts > 0 ? `（尝试 ${attempts} 次）` : ''}: ${reason}`));
              } else if (attempts > 1) {
                console.log(chalk.dim(`  ✓ 步骤 ${step.id} 在第 ${attempts} 次尝试通过校验`));
              }
              if (result.reply) {
                console.log(chalk.dim(`  步骤 ${step.id}: ${step.description}`));
                renderer.renderAiResponse(result.reply).split('\n').forEach(l => console.log(`  ${l}`));
              }
            }
            renderer.renderAgentDone({ toolCalls: results.length, elapsedMs: elapsed });
          } else {
            printInfo('计划已取消');
          }
        } else {
          if (process.stdout.isTTY) process.stdout.write('\x1b[1A\r\x1b[K');
          renderer.printStepLine('error', '计划模式', errorType || '', '生成执行计划失败');
          if (rawResponse) {
            const renderer2 = require('./aiRenderer');
            renderer2.renderAiResponse(rawResponse).split('\n').forEach(l => console.log(`  ${l}`));
          } else {
            printError('计划模式生成失败，且未返回具体错误信息');
          }
        }
        planService.reset();
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // ── Tool-Use Loop (Claude Code style) ──
      // AI calls tools → system executes with permission → feeds results back → AI continues
      const renderer = require('./aiRenderer');
      bindInteractiveInputGuard(renderer);
      const toolUseLoop = require('../services/toolUseLoop');
      const loopManaged = toolUseLoop.isEnabled();

      const truncatedInput = aiInput.replace(/\n/g, ' ').slice(0, 50);
      console.log(chalk.dim('  ↳ 模型工作中可直接输入并回车插话（会排队），/i <内容> 可优先处理'));
      showBusyInterjectPrompt();
      renderer.printActionHint(`向 AI 发送请求: "${truncatedInput}${aiInput.length > 50 ? '...' : ''}"`);

      const spinner = new renderer.DynamicSpinner();
      if (_inputFrameEnabled && typeof spinner.setPromptMode === 'function') {
        spinner.setPromptMode('framed', {
          ruleColor: '#D77757',
          footer: chalk.dim('? for shortcuts'),
        });
      }
      const tracker = new renderer.ProcessTracker();
      let toolTracker = null; // ToolUseTracker for tool calls (created on first tool call)
      let planTracker = null; // TaskPlanTracker for execution plans
      let iterationCount = 0;

      // Streaming state for rendering thinking/text phases
      let streamState = { phase: 'idle', thinkingStarted: false, textStarted: false, thinkingLineOpen: false, thinkingCol: 0 };
      const streamedToolNames = new Map(); // tool_use_id -> tool name
      const streamedTaskStatus = new Map(); // task_id -> latest status
      let _lastRuntimeStatusSig = '';

      const emitRuntimeStatus = (text = '') => {
        const msg = String(text || '').trim();
        if (!msg) return;
        const sig = `status:${msg}`;
        if (sig === _lastRuntimeStatusSig) return;
        _lastRuntimeStatusSig = sig;
        if (tracker.isActive) tracker.complete();
        console.log(chalk.dim(`  · ${msg}`));
      };

      const handleControlRequest = async ({ request }) => {
        const subtype = String(request?.subtype || '').trim().toLowerCase();
        if (subtype !== 'can_use_tool') {
          return { subtype: 'success', response: {} };
        }

        const toolName = String(request?.tool_name || request?.tool || 'tool');
        const normalizedTool = toolName.toLowerCase().replace(/[\s_-]/g, '');
        const input = (request && typeof request.input === 'object' && request.input) ? request.input : {};

        spinner.stop();
        try {
          if (normalizedTool === 'askuserquestion') {
            const questions = Array.isArray(input.questions) ? input.questions : [];
            const answers = {};

            for (const q of questions.slice(0, 4)) {
              const questionText = String(q?.question || '').trim() || '请选择';
              const qOptions = Array.isArray(q?.options) ? q.options : [];
              const renderedOptions = qOptions
                .map(opt => ({
                  label: String(opt?.label || '').trim(),
                  description: String(opt?.description || '').trim(),
                }))
                .filter(opt => opt.label);

              if (renderedOptions.length === 0) continue;

              const selection = await renderer.askInlineQuestion(questionText, renderedOptions, {
                multiSelect: !!q?.multiSelect,
                rl,
              });

              if (selection === null || selection === undefined) {
                return {
                  subtype: 'success',
                  response: {
                    behavior: 'deny',
                    message: 'User declined to answer questions',
                  },
                };
              }

              answers[questionText] = Array.isArray(selection)
                ? selection.join(', ')
                : String(selection);
            }

            return {
              subtype: 'success',
              response: {
                behavior: 'allow',
                updatedInput: { ...input, answers },
              },
            };
          }

          const permissionChoice = await renderer.askInlineQuestion(
            `Allow ${toolName}?`,
            [
              { label: 'Allow', description: 'Approve this tool call once' },
              { label: 'Deny', description: 'Reject this tool call' },
            ],
            { rl },
          );

          if (permissionChoice === 'Allow') {
            return { subtype: 'success', response: { behavior: 'allow' } };
          }
          return {
            subtype: 'success',
            response: {
              behavior: 'deny',
              message: 'Permission denied',
            },
          };
        } finally {
          spinner.start('request');
        }
      };

      const onChunk = (chunk) => {
        if (_traceMode && chunk && chunk.type && chunk.type !== 'text' && chunk.type !== 'thinking') {
          const traceMsg = chunk.text ? `${chunk.type}: ${String(chunk.text).slice(0, 120)}` : chunk.type;
          console.log(chalk.dim(`  [trace] ${traceMsg}`));
        }

        if (chunk.type === 'thinking') {
          if (tracker.isActive) tracker.complete();
          spinner.stop();
          if (!streamState.thinkingStarted) {
            streamState.thinkingStarted = true;
            streamState.phase = 'thinking';
            tracker.start('思考', '', '深度分析中...');
            console.log('');
            console.log(chalk.yellow(`  ${ICON_BOT} 思考过程:`));
          }
          streamThinkingChunk(chunk.text, streamState, chalk);
        } else if (chunk.type === 'tool_use') {
          // Claude CLI is executing a tool internally — show status
          if (streamState.phase === 'thinking') {
            closeThinkingStream(streamState);
            streamState.phase = 'tool';
          }
          spinner.stop();
          if (tracker.isActive) tracker.complete();
          const toolLabel = chunk.tool || 'tool';
          if (chunk.id) streamedToolNames.set(String(chunk.id), toolLabel);
          const inputHint = chunk.input ? chalk.dim(` (${chunk.input.slice(0, 50)})`) : '';
          console.log(chalk.cyan(`  🔧 ${toolLabel}`) + inputHint);
          tracker.start('执行', toolLabel, chunk.input ? chunk.input.slice(0, 30) : '');
        } else if (chunk.type === 'tool_result') {
          // Tool finished — show brief result
          if (tracker.isActive) tracker.complete();
          if (chunk.id) streamedToolNames.delete(String(chunk.id));
          if (chunk.content) {
            const brief = chunk.content.replace(/\n/g, ' ').slice(0, 60);
            console.log(chalk.dim(`    → ${brief}${chunk.content.length > 60 ? '...' : ''}`));
          }
        } else if (chunk.type === 'tool_progress') {
          spinner.stop();
          const toolName = chunk.tool || streamedToolNames.get(String(chunk.id || '')) || 'tool';
          const status = String(chunk.status || '').toLowerCase();
          const detail = String(chunk.detail || '').trim();
          if (status.includes('fail') || status.includes('error')) {
            renderer.printStepLine('error', `${toolName}`, '', detail || 'failed');
            if (chunk.id) streamedToolNames.delete(String(chunk.id));
          } else if (status.includes('complete') || status.includes('success') || status === 'done') {
            renderer.printStepLine('success', `${toolName}`, '', detail || 'completed');
            if (chunk.id) streamedToolNames.delete(String(chunk.id));
          } else {
            renderer.printStepLine('active', `${toolName}`, '', detail || 'running');
          }
        } else if (chunk.type === 'task_started') {
          spinner.stop();
          const taskId = String(chunk.taskId || chunk.toolUseId || 'task');
          streamedTaskStatus.set(taskId, 'running');
          const detail = String(chunk.summary || '').trim();
          renderer.printStepLine('active', 'Task started', taskId, detail);
        } else if (chunk.type === 'task_progress') {
          spinner.stop();
          const taskId = String(chunk.taskId || chunk.toolUseId || 'task');
          const detail = String(chunk.summary || chunk.status || '').trim() || 'in progress';
          renderer.printStepLine('active', 'Task progress', taskId, detail);
        } else if (chunk.type === 'task_notification') {
          spinner.stop();
          const taskId = String(chunk.taskId || chunk.toolUseId || 'task');
          const status = String(chunk.status || '').toLowerCase();
          const detail = String(chunk.summary || '').trim();
          const ok = status === 'completed' || status === 'success';
          renderer.printStepLine(ok ? 'success' : 'error', 'Task finished', taskId, detail || status || 'done');
          streamedTaskStatus.delete(taskId);
        } else if (chunk.type === 'auth_status') {
          spinner.stop();
          if (chunk.error) {
            renderer.printStepLine('error', 'Auth', '', String(chunk.error));
          } else if (chunk.isAuthenticating) {
            renderer.printStepLine('active', 'Auth', '', String(chunk.output || 'authenticating...'));
          } else if (chunk.output) {
            emitRuntimeStatus(`Auth: ${String(chunk.output)}`);
          }
        } else if (chunk.type === 'status') {
          emitRuntimeStatus(chunk.text || 'status update');
          tracker.start('等待', '', chunk.text || '上游服务响应中...');
        } else if (chunk.type === 'control_request') {
          spinner.stop();
          const req = chunk.request || {};
          const reqSubtype = String(req.subtype || '').trim() || 'control';
          const reqTool = String(req.tool_name || req.tool || '').trim();
          if (reqSubtype === 'can_use_tool') {
            renderer.printStepLine('active', 'Permission', reqTool || 'tool', `request ${chunk.requestId || ''}`.trim());
          } else {
            renderer.printStepLine('active', 'Control request', reqSubtype, `request ${chunk.requestId || ''}`.trim());
          }
        } else if (chunk.type === 'text') {
          if (streamState.phase === 'thinking') {
            closeThinkingStream(streamState);
            console.log('');
            if (tracker.isActive) tracker.complete('思考完成');
            streamState.phase = 'text';
            spinner.setPhase('generating', '生成回复');
          }
          if (streamState.phase === 'tool') {
            console.log('');
            streamState.phase = 'text';
          }
          if (!streamState.textStarted) {
            streamState.textStarted = true;
            if (tracker.isActive) tracker.complete();
            spinner.stop();
            tracker.start('生成', '', '输出回复...');
          }
        }
      };

      // Chat wrapper for toolUseLoop — calls ai().chat() with streaming
      const chatFn = async (message, opts = {}) => {
        // Reset streaming state for each iteration
        streamState = { phase: 'idle', thinkingStarted: false, textStarted: false, thinkingLineOpen: false, thinkingCol: 0 };
        let _lastStatusLine = '';
        let _lastStatusLineAt = 0;
        let _lastStatusText = '';
        let _lastStatusTextAt = 0;
        let _liveStatusOpen = false;
        let _liveStatusKey = '';
        const _statusDedupMs = (() => {
          const raw = process.env.KHY_AI_STATUS_DEDUP_MS || process.env.GATEWAY_STATUS_DEDUP_MS || '1500';
          const parsed = Number.parseInt(String(raw).trim(), 10);
          if (!Number.isFinite(parsed) || parsed < 200) return 1500;
          return parsed;
        })();
        const _normalizeProgressKey = (phase, text) => {
          const normalized = String(text || '')
            .replace(/（\d+s）/g, '(Xs)')
            .replace(/\b\d+s\b/g, 'Xs')
            .replace(/\.{3}\s*\d+s/gi, '... Xs')
            .trim();
          return `${phase}:${normalized}`;
        };
        const _isDynamicProgressStatus = (phase, text) => (
          phase === 'request'
          && /处理中（\d+s）|等待模型响应中\.\.\.\s*\d+s/i.test(String(text || ''))
        );
        const _flushLiveStatusLine = () => {
          if (!_liveStatusOpen) return;
          try { process.stdout.write('\n'); } catch { /* ignore */ }
          _liveStatusOpen = false;
          _liveStatusKey = '';
        };

        if (!opts._isFollowUp) {
          tracker.start('请求 AI', ai().getActiveProvider() || 'AI 服务');
          spinner.start('request');
        } else {
          tracker.start('AI 继续', ai().getActiveProvider() || 'AI 服务', '基于工具结果...');
          spinner.start('request');
        }

        let result;
        try {
          const { WATCHDOG_TIMEOUT_MS, withTimeout } = require('../services/resourceGuard');
          const preferredAdapter = String(
            opts.preferredAdapter !== undefined
              ? opts.preferredAdapter
              : (process.env.GATEWAY_PREFERRED_ADAPTER || '')
          ).trim().toLowerCase();
          const longRunningAdapters = new Set(['claude', 'codex', 'cli', 'windsurf', 'kiro', 'trae', 'warp']);
          const minTimeoutMs = longRunningAdapters.has(preferredAdapter) ? 300000 : 120000;
          const isLargeTask = (() => {
            const text = String(message || '');
            return text.length >= 700
              || /大型任务|大任务|完整实现|全量|全流程|端到端|deep|exhaustive|full implementation|end-to-end/i.test(text);
          })();
          const largeTaskMinTimeoutMs = Math.max(
            minTimeoutMs,
            parseInt(String(process.env.KHY_AI_REQUEST_TIMEOUT_LARGE_MS || '900000'), 10) || 900000
          );
          const timeoutMs = Math.max(
            isLargeTask ? largeTaskMinTimeoutMs : minTimeoutMs,
            Number(process.env.KHY_AI_REQUEST_TIMEOUT_MS || WATCHDOG_TIMEOUT_MS),
          );
          result = await withTimeout(ai().chat(message, {
            ...opts,
            disableNaturalToolLoop: loopManaged,
            onChunk,
            onControlRequest: opts.onControlRequest || handleControlRequest,
            onStatus: (st) => {
              try {
                const phase = String(st && st.phase ? st.phase : '').trim();
                const text = String(st && st.message ? st.message : '').replace(/\s+/g, ' ').trim();
                if (!text) return;
                if (phase === 'done') {
                  _flushLiveStatusLine();
                  return;
                }
                const now = Date.now();
                const sig = `${phase}:${text}`;
                if (sig === _lastStatusLine && (now - _lastStatusLineAt) < _statusDedupMs) return;
                if (text === _lastStatusText && (now - _lastStatusTextAt) < _statusDedupMs) return;
                _lastStatusLine = sig;
                _lastStatusLineAt = now;
                _lastStatusText = text;
                _lastStatusTextAt = now;
                if (_isDynamicProgressStatus(phase, text)) {
                  const liveKey = _normalizeProgressKey(phase, text);
                  const line = chalk.dim(`  · ${text}`);
                  if (!_liveStatusOpen || _liveStatusKey !== liveKey) {
                    if (_liveStatusOpen) _flushLiveStatusLine();
                    try { process.stdout.write(line); } catch { console.log(line); }
                    _liveStatusOpen = true;
                    _liveStatusKey = liveKey;
                  } else {
                    try { process.stdout.write(`\r\x1b[K${line}`); } catch { /* ignore */ }
                  }
                  return;
                }
                _flushLiveStatusLine();
                // Distinct formatting for work lifecycle phases
                if (phase === 'plan') {
                  console.log(chalk.cyan(`  📋 ${text}`));
                } else if (phase === 'tool_progress') {
                  console.log(chalk.dim(`  ⚙ ${text}`));
                } else if (phase === 'summary') {
                  console.log(chalk.green(`  ✓ ${text}`));
                } else {
                  console.log(chalk.dim(`  · ${text}`));
                }
              } catch { /* non-critical */ }
            },
            onWait: (adapterKey, waitMs) => {
              try {
                _flushLiveStatusLine();
                const sec = Math.max(0, Number(waitMs || 0) / 1000);
                console.log(chalk.dim(`  · ${adapterKey || 'adapter'} 限流等待 ${(sec).toFixed(1)}s`));
              } catch { /* non-critical */ }
            },
            onFallback: (info) => {
              _flushLiveStatusLine();
              spinner.stop();
              console.log(chalk.yellow(`\n  ⚠ ${info.failedAdapter} 失败: ${info.failedError}`));
              if (info.nextAdapter) console.log(chalk.yellow(`  → 切换到 ${info.nextAdapter}`));
              console.log('');
              spinner.start('request');
            },
          }), timeoutMs, 'AI request');
        } catch (err) {
          spinner.stop();
          if (tracker.isActive) tracker.complete();
          throw err;
        }

        spinner.stop();
        _flushLiveStatusLine();
        if (tracker.isActive) tracker.complete();

        if (streamState.phase === 'thinking') {
          closeThinkingStream(streamState);
          console.log('');
        }

        // Display thinking process if available
        if (result && result.thinking) {
          console.log(chalk.yellow.bold('思考过程:'));
          console.log(chalk.dim(result.thinking));
          console.log('');
        }

        // Display the AI response for this iteration.
        // Execution-first behavior: if reply contains tool calls, suppress body
        // and let tool loop execute first.
        if (result && result.reply) {
          if (result.errorType) {
            renderer.printStepLine('error', 'AI 请求失败', result.provider || 'gateway', String(result.errorType));
            renderer.renderAiResponse(result.reply).split('\n').forEach(l => console.log(`  ${l}`));
            console.log('');
            // Update HUD even on failures so users can still see latest token/context movement.
            try {
              const hud = require('./hudRenderer');
              if (result.tokenUsage) hud.updateTokens(result.tokenUsage);
              hud.toolEnd('AI Response', 'error', result.elapsed || 0);
            } catch { /* non-critical */ }
            return result;
          }

          const showUsage = _usageMode !== 'off';
          const showTokens = _usageMode === 'tokens' || _usageMode === 'full';
          const metaParts = [
            showUsage && result.elapsed ? `${(result.elapsed / 1000).toFixed(1)}s` : '',
            showTokens && result.tokenUsage ? `↑ ${result.tokenUsage.totalTokens?.toLocaleString() || '?'} tokens` : '',
          ].filter(Boolean);
          const toolSummaryText = formatToolSummary(result.toolSummary);

          const containsToolCall = hasToolCallTag(result.reply);
          const displayText = stripToolCallTags(result.reply);

          if (containsToolCall) {
            const planMeta = metaParts.join(' · ');
            renderer.printStepLine('success', 'AI 规划', result.provider || 'local', `${planMeta ? `${planMeta} · ` : ''}开始执行工具`);
            if (toolSummaryText) console.log(chalk.dim(`  ℹ ${toolSummaryText}`));
            console.log(chalk.dim('  └ 已生成工具调用，先执行命令后汇总结论'));
            console.log('');
          } else if (displayText) {
            renderer.printStepLine('success', 'AI 回复', result.provider || 'local', metaParts.join(' · '));
            if (_usageMode === 'full' && result.tokenUsage) {
              const inTok = Number(result.tokenUsage.inputTokens || 0).toLocaleString();
              const outTok = Number(result.tokenUsage.outputTokens || 0).toLocaleString();
              console.log(chalk.dim(`  ℹ Usage: input ${inTok} · output ${outTok}`));
            }
            if (toolSummaryText) console.log(chalk.dim(`  ℹ ${toolSummaryText}`));
            renderer.renderAiResponse(displayText).split('\n').forEach(l => console.log(`  ${l}`));
            console.log('');
          }
        }

        // Update HUD
        try {
          const hud = require('./hudRenderer');
          if (result.tokenUsage) hud.updateTokens(result.tokenUsage);
          hud.toolEnd('AI Response', 'success', result.elapsed || 0);
        } catch { /* non-critical */ }

        return result;
      };

      // Run the tool-use loop
      let loopResult;
      try {
        if (toolUseLoop.isEnabled()) {
          const loopMaxIterations = (() => {
            const base = parseInt(String(process.env.KHY_TOOL_LOOP_MAX_ITERATIONS || '12'), 10) || 12;
            const boost = String(finalAiInput || '').length >= 700 ? 6 : 0;
            return Math.max(8, Math.min(40, base + boost));
          })();
          loopResult = await toolUseLoop.runToolUseLoop(finalAiInput, {
            chat: chatFn,
            maxIterations: loopMaxIterations,

            onIteration: (iteration) => {
              iterationCount = iteration;
              if (iteration > 1) {
                console.log(chalk.dim(`  ─── Iteration ${iteration} ───`));
              }
            },

            onToolCall: (toolName, params, iteration) => {
              // Create tracker on first tool call
              if (!toolTracker) {
                toolTracker = new renderer.ToolUseTracker('Tools', '工具调用');
                toolTracker.printHeader();
              }
              const paramStr = Object.entries(params || {})
                .map(([k, v]) => `${k}=${typeof v === 'string' ? v.slice(0, 30) : v}`)
                .join(', ')
                .slice(0, 60);
              toolTracker.toolStart(toolName, paramStr || '');
              tracker.start(mapToolToPhaseLabel(toolName), toolName, paramStr || '');
              const progress = _toolProgressStart(toolName, params || {});
              if (progress) {
                renderer.printStepLine('active', progress.label, progress.target || '');
                const reason = _toolProgressReason(toolName, params || {});
                if (reason) renderer.printStepDetail(reason);
              }
              try { require('./hudRenderer').toolStart(toolName, paramStr); } catch {}
              if (_traceMode) {
                let paramsText = '';
                try { paramsText = JSON.stringify(params || {}); } catch { paramsText = '[unserializable params]'; }
                if (paramsText.length > 300) paramsText = `${paramsText.slice(0, 300)}…`;
                console.log(chalk.dim(`    [trace] params: ${paramsText}`));
              }
            },

            onParallelBatch: (calls, iteration) => {
              try {
                console.log(chalk.dim(`  ⚡ 并行 ${calls.length} 个工具`));
              } catch { /* non-critical */ }
            },

            onToolResult: (toolName, params, result, iteration, elapsedMs) => {
              let success = false;
              let resultDetail = '';
              if (result && result.denied) {
                success = false;
                resultDetail = 'Permission denied';
              } else if (result && result.success) {
                success = true;
                resultDetail = _formatToolResult(toolName, result);
              } else {
                success = false;
                resultDetail = result && result.error
                  ? (typeof result.error === 'string' ? result.error : JSON.stringify(result.error))
                  : 'failed';
                resultDetail = resultDetail.slice(0, 120);
              }

              if (toolTracker) {
                toolTracker.toolEnd(toolName, success ? 'success' : 'error', resultDetail.slice(0, 80), elapsedMs || 0);
                // Surface token usage in tool tracker when available.
                // Some tools may return tokenUsage with provider-specific accounting.
                try {
                  const t = Number(result?.tokenUsage?.totalTokens || 0);
                  if (t > 0) toolTracker.addTokens(t);
                } catch { /* best effort */ }
              }
              const progressDone = _toolProgressDone(toolName, success, resultDetail);
              if (progressDone) {
                renderer.printStepLine(progressDone.status, progressDone.label, '', progressDone.detail || '');
              }
              if (tracker.isActive) tracker.complete();
              maybeRenderWriteDiff(toolName, params, result, chalk);
              maybeRenderInlineDiffFromToolOutput(toolName, result, chalk);
              if (_traceMode) {
                const trace = {
                  success: !!result?.success,
                  denied: !!result?.denied,
                  elapsedMs: elapsedMs || 0,
                };
                let traceText = '';
                try { traceText = JSON.stringify(trace); } catch { traceText = '{"success":false}'; }
                console.log(chalk.dim(`    [trace] result: ${traceText}`));
              }
              try { require('./hudRenderer').toolEnd(toolName, 'done', 0); } catch {}
            },

            onPlanReady: (plan) => {
              try {
                planTracker = new renderer.TaskPlanTracker();
                for (const step of plan.steps) {
                  planTracker.addTask(step.description);
                }
                planTracker.render();
                // Mark first step as in-progress
                if (plan.steps.length > 0) {
                  planTracker.start(0);
                }
              } catch { /* renderer not available */ }
            },

            onPlanProgress: (stepIndex, status) => {
              if (planTracker) {
                try {
                  if (status === 'completed') planTracker.complete(stepIndex);
                  else if (status === 'in_progress') planTracker.start(stepIndex);
                  else if (status === 'error') planTracker.fail(stepIndex);
                } catch { /* non-critical */ }
              }
            },

            onNoToolCall: (iteration, reply, info = {}) => {
              if (iteration === 1 && info.autoContinued) {
                console.log(chalk.dim('  ℹ 首轮仅收到过程性回复，已自动续跑并要求直接执行'));
              } else if (iteration === 1 && info.placeholder && info.actionTask) {
                console.log(chalk.dim('  ℹ 检测到过程性回复且无工具调用，建议重试或使用 /review 强化执行'));
              }
            },
          });
        } else {
          // Feature flag disabled — single-shot chat (legacy)
          const result = await chatFn(finalAiInput);
          loopResult = {
            finalResponse: result.reply,
            toolCallLog: [],
            iterations: 1,
            provider: result.provider,
            errorType: result.errorType || null,
          };
        }
      } catch (err) {
        spinner.stop();
        if (tracker.isActive) tracker.complete();
        throw err;
      }

      // Finish tool tracker if it was created
      if (toolTracker) {
        toolTracker.finish();
        toolTracker = null;
      }

      // Finish plan tracker if it was created
      if (planTracker) {
        planTracker = null;
      }

      // Execute embedded [CMD:...] commands (legacy system)
      if (loopResult.toolCallLog) {
        const legacyCmds = loopResult.toolCallLog
          .filter(t => t.tool === '_legacy_cmd')
          .map(t => t.params?.command)
          .filter(Boolean);

        if (legacyCmds.length > 0) {
          const cmdTracker = new renderer.ToolUseTracker('Execute', `${legacyCmds.length} commands`);
          cmdTracker.printHeader();

          for (const cmd of legacyCmds) {
            const cmdParts = cmd.split(/\s+/);
            const cmdLabel = cmdParts[0] || cmd;
            const cmdTarget = cmdParts.slice(1).join(' ') || '';
            cmdTracker.toolStart(cmdLabel, cmdTarget || cmd);
            const cmdStart = Date.now();

            try {
              const cmdParsed = parseInput(cmd);
              if (cmdParsed && !BLOCKED_COMMANDS.has(cmdParsed.command)) {
                const origLog = console.log;
                const output = [];
                console.log = (...args) => output.push(args.map(String).join(' '));
                try { await route(cmdParsed); } finally { console.log = origLog; }
                cmdTracker.toolEnd(cmdLabel, 'success', '', Date.now() - cmdStart);
              } else {
                cmdTracker.toolEnd(cmdLabel, 'error', 'not available', 0);
              }
            } catch (e) {
              cmdTracker.toolEnd(cmdLabel, 'error', e.message || 'failed', Date.now() - cmdStart);
            }
          }
          cmdTracker.finish();
        }
      }

      // Summary for multi-iteration loops
      if (iterationCount > 1) {
        const toolCount = (loopResult.toolCallLog || []).filter(t => t.tool !== '_legacy_cmd').length;
        console.log(chalk.dim(`  ✓ 完成 — ${iterationCount} 轮迭代, ${toolCount} 次工具调用`));
        console.log('');
      }

      // Render final response from tool-use loop if it wasn't already shown
      // by chatFn (e.g. the last iteration produced a summary after tool execution)
      if (iterationCount > 1 && loopResult.finalResponse) {
        const finalText = loopResult.finalResponse.trim();
        if (finalText) {
          renderer.printStepLine('success', 'AI 总结', loopResult.provider || 'local', '');
          renderer.renderAiResponse(finalText).split('\n').forEach(l => console.log(`  ${l}`));
          console.log('');
        }
      }

      if (loopResult.timeLimitReached) {
        const limitMs = Number(loopResult.maxElapsedMs || 0);
        const totalSec = Math.max(1, Math.ceil(limitMs / 1000));
        const m = Math.floor(totalSec / 60);
        const s = totalSec % 60;
        const limitText = (m > 0 && s > 0) ? `${m}m ${s}s` : (m > 0 ? `${m}m` : `${s}s`);
        console.log(chalk.yellow(`  ⚠ 工具循环超时 (>${limitText})，已返回已收集结果`));
      } else if (loopResult.maxIterationsReached) {
        console.log(chalk.yellow(`  ⚠ 达到最大迭代次数 (${loopResult.iterations})，已返回最后结果`));
      }

      if (!loopResult.finalResponse && iterationCount <= 1) {
        printInfo('AI 未返回有效回复 — 请重试或检查连接');
        console.log('');
      }

    } catch (err) {
      try { printError(err?.message || String(err) || '执行出错'); } catch { /* ignore */ }
      if (process.env.KHY_DEBUG === '1' && err && err.stack) {
        try { console.error(chalk.dim(err.stack)); } catch { /* ignore */ }
      }
    } finally {
      _busy = false;
      try {
        const renderer = require('./aiRenderer');
        if (typeof renderer.setInteractiveGuard === 'function') renderer.setInteractiveGuard(null);
      } catch { /* non-critical */ }
      if (process.stdout.isTTY) process.stdout.write('\x1b[?25h');
      // Restore stdin state — raw mode must be off for readline to work,
      // and stdin must be resumed. Permission dialogs use raw mode + pause rl;
      // if cleanup is incomplete, readline is left dead.
      recoverReadlineInput();
      const nextQueued = _queuedInputs.shift();
      if (nextQueued) {
        try {
          const queuedPreview = nextQueued.replace(/\n/g, ' ').slice(0, 48);
          console.log(chalk.dim(`  ↳ 继续处理排队输入: "${queuedPreview}${queuedPreview.length >= 48 ? '...' : ''}"`));
          rl.emit('line', `${INTERNAL_LINE_PREFIX}${nextQueued}`);
          return;
        } catch { /* fallthrough to prompt */ }
      }
      try { rl.prompt(); } catch { /* ignore */ }
    }
  });

  // ── Ctrl+C exit ──
  rl.on('SIGINT', () => {
    if (_busy) {
      // Don't force-clear busy state here: Ctrl+C notifies user, but we keep
      // the current loop lifecycle consistent and let active async flow settle.
      try {
        const gateway = require('../services/gateway/aiGateway');
        const relay = gateway.getRelayAdapter();
        if (relay && typeof relay.cancelPending === 'function' && relay.cancelPending('Interrupted by Ctrl+C')) {
          console.log(chalk.yellow('\n  ⚠ 已中断当前 Web 中转请求，正在返回'));
          return;
        }
      } catch { /* non-critical */ }
      console.log(chalk.yellow('\n  ⚠ 已请求中断，将在当前步骤结束后返回'));
      rl.prompt();
      return;
    }
    _ctrlCCount++;
    if (_ctrlCCount >= 2) {
      clearInterval(_tipTimer);
      ai().saveConversation();
      saveHistory(history);
      setTerminalTitle('');
      console.log('');
      console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
      console.log(chalk.dim('  对话已保存'));
      console.log('');
      _intentionalClose = true; process.exit(0);
    }
    console.log(chalk.yellow('\n  ⚠ 再按一次 Ctrl+C 退出 (对话自动保存)'));
    if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
    _ctrlCTimer = setTimeout(() => { _ctrlCCount = 0; }, 2000);
    rl.prompt();
  });

  // ── Ctrl+D exit ──
  // Guard: inquirer may close stdin triggering 'close' on our readline.
  // We track inquirer activity via module-level _inquirerActive (set by inqPrompt wrapper).
  let _intentionalClose = false;
  rl.on('close', () => {
    if (_intentionalClose) {
      // Already handled (e.g., /exit command)
      return;
    }
    if (_inquirerActive) {
      // Triggered by inquirer closing readline — recover
      try {
        process.stdin.resume();
        if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function' && !process.stdin.isRaw) {
          process.stdin.setRawMode(true);
        }
        rl.resume();
        rl.prompt();
      } catch {}
      return;
    }
    // Real EOF (Ctrl+D) — save and exit
    clearInterval(_tipTimer);
    ai().saveConversation();
    saveHistory(history);
    setTerminalTitle('');
    console.log('');
    console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
    console.log(chalk.dim('  对话已保存'));
    process.exit(0);
  });
}

module.exports = { startLiteRepl };
