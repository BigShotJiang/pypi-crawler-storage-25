/**
 * CLI output formatting utilities.
 * All user-facing prose is in Chinese.
 */
const chalkModule = require('chalk');
const chalk = chalkModule.default || chalkModule;
const Table = require('cli-table3');
const os = require('os');
const path = require('path');

// ── Mascot & themed icons ────────────────────────────────────────────────────

// Legacy mascot (kept for backward compatibility)
const MASCOT_LEGACY = [
  '  ╭─────╮    ',
  '  │ ◉ ◉ │    ',
  '╭─┤ ▽▽▽ ├─╮  ',
  '│ ╰─┬─┬─╯ │  ',
  '╰───┤ ├───╯  ',
  '  ╭─┴─┴─╮    ',
  '  │ KHY │    ',
  '  ╰─────╯    ',
];

// Legendary flash card pet — Claude Code style pixel art (3 lines tall)
const MASCOT = [
  '  ╭━━━━━╮  ',
  '  ┃✦ ◈ ✦┃  ',
  '  ╰┳━━┳╯  ',
];

// Claude Code style: minimal icons, no emoji
const MASCOT_MINI = '·';       // for status lines (Claude Code: dot)
const ICON_PROMPT = '>';       // prompt arrow
const ICON_AI = '*';           // AI indicator
const ICON_BULL = '>';         // market up
const ICON_BEAR = '<';         // market down
const ICON_BOT = '*';          // AI assistant
const ICON_CHART = '#';        // chart / backtest
const ICON_GEAR = '*';         // system
const ICON_PLUG = '+';         // plugin
const ICON_HEART = '+';        // health / doctor
const ICON_ROCKET = '>';       // launch / start
const ICON_KEY = '*';          // API key
const ICON_DB = '#';           // database
const ICON_SEARCH = '*';       // search
const ICON_GATEWAY = '*';      // gateway / relay

// Random farewell messages
const TIPS = [
  'Run /init to create a CLAUDE.md file with instructions for Claude',
  'Use /clear to start fresh when switching topics',
  'Press Ctrl+C to interrupt, type resume to continue',
  'Use /btw to ask a quick side question without interrupting',
  'Drag and drop files into the terminal to include them',
  'Use arrow keys to navigate through command history',
  'Run khy gateway status to check model provider status',
];

/**
 * Print startup banner — Claude Code aligned layout.
 *
 * Layout (source-level 1:1 match with Claude Code):
 *
 *   [buddy sprite]  khy OS vX.Y.Z
 *                   Model with effort · Billing Type
 *                   /working/directory
 *
 * Clean single-column. No tips, no activity panel.
 * Buddy sprite renders to the left if terminal is wide enough.
 */
function printBanner(version, aiProvider) {
  const d = chalk.dim;
  const orange = chalk.hex('#D77757');

  // Get active model info
  let modelName = '';
  let adapterName = '';
  let effortLabel = 'high effort';
  let billingType = 'API Usage Billing';
  try {
    const gateway = require('../services/gateway/aiGateway');
    const active = gateway.getActiveAdapter();
    if (active) {
      adapterName = active.name || active.type || '';
      modelName = active.activeModel || process.env.GATEWAY_PREFERRED_MODEL || '';
    }
  } catch { /* best effort */ }

  if (!modelName) {
    modelName = process.env.GATEWAY_PREFERRED_MODEL || process.env.OLLAMA_MODEL || 'auto';
  }
  if (!adapterName) {
    adapterName = process.env.GATEWAY_PREFERRED_ADAPTER || aiProvider || 'auto';
  }

  // Determine billing type from adapter
  if (/ollama|local|llama/i.test(adapterName)) {
    billingType = 'Local Model';
  } else if (/relay|web|clipboard/i.test(adapterName)) {
    billingType = 'Relay';
  }

  // Effort level
  try {
    const ai = require('./ai');
    const effort = ai.getEffort ? ai.getEffort() : 'high';
    const labels = { max: 'max effort', high: 'high effort', medium: 'medium effort', low: 'low effort' };
    effortLabel = labels[effort] || 'high effort';
  } catch { /* best effort */ }

  const cwd = process.cwd();
  const home = os.homedir();
  const cwdShort = cwd.startsWith(home) ? '~' + cwd.slice(home.length) : cwd;
  const ver = version || require('../../package.json').version;
  const cols = process.stdout.columns || 80;

  // ── Buddy sprite (Claude Code style: companion renders left of text) ──
  let buddyLines = [];
  try {
    const buddyModule = require('../buddy');
    const companion = buddyModule.getActiveCompanion ? buddyModule.getActiveCompanion() : null;
    if (companion && companion.sprite) {
      buddyLines = companion.sprite;
    }
  } catch { /* no buddy */ }

  // Fallback pet sprite (Claude Code's Clawd-style pixel art)
  if (!buddyLines || buddyLines.length === 0) {
    buddyLines = [
      orange('  ╭━━━━╮'),
      orange('  ┃') + chalk.hex('#FFD700')('✦') + orange(' ◈ ') + chalk.hex('#FFD700')('✦') + orange('┃'),
      orange('  ╰┳━┳╯'),
    ];
  }

  // ── Render: sprite left, info right ──
  // Always keep the CLI pet visible; on narrow terminals, switch to stacked mode.
  const hasSprite = Array.isArray(buddyLines) && buddyLines.length >= 3;
  const sideBySide = hasSprite && cols > 50;
  const spriteWidth = sideBySide ? 12 : 0;

  console.log('');

  if (sideBySide) {
    // Line 1: sprite + "khy OS vX.Y.Z"
    console.log(`${padToWidth(buddyLines[0] || '', spriteWidth)}  ${chalk.bold('khy OS')} ${d(`v${ver}`)}`);
    // Line 2: sprite + "Model with effort · Billing"
    console.log(`${padToWidth(buddyLines[1] || '', spriteWidth)}  ${d(`${modelName} with ${effortLabel} · ${billingType}`)}`);
    // Line 3: sprite + working directory
    console.log(`${padToWidth(buddyLines[2] || '', spriteWidth)}  ${d(cwdShort)}`);
    // Extra sprite lines (if buddy has more)
    for (let i = 3; i < buddyLines.length; i++) {
      console.log(buddyLines[i]);
    }
  } else if (hasSprite) {
    // Narrow terminal: show pet first, then metadata lines.
    console.log(buddyLines[0] || '');
    console.log(buddyLines[1] || '');
    console.log(buddyLines[2] || '');
    console.log(`  ${chalk.bold('khy OS')} ${d(`v${ver}`)}`);
    console.log(`  ${d(`${modelName} with ${effortLabel} · ${billingType}`)}`);
    console.log(`  ${d(cwdShort)}`);
  } else {
    // Ultimate fallback: text-only mode
    console.log(`    ${chalk.bold('khy OS')} ${d(`v${ver}`)}`);
    console.log(`    ${d(`${modelName} with ${effortLabel} · ${billingType}`)}`);
    console.log(`    ${d(cwdShort)}`);
  }

  console.log('');
}

function stripAnsi(str) {
  // eslint-disable-next-line no-control-regex
  return str.replace(/\u001b\[[0-9;]*m/g, '');
}

/**
 * Calculate the visual display width of a string, accounting for:
 * - CJK characters (2 columns each)
 * - Emoji (2 columns each)
 * - ANSI escape codes (0 columns)
 * - Combining characters (0 columns)
 */
function displayWidth(str) {
  const stripped = stripAnsi(str);
  let width = 0;
  for (const ch of stripped) {
    const cp = ch.codePointAt(0);
    // CJK Unified Ideographs, CJK Symbols, Fullwidth Forms, Hangul
    if (
      (cp >= 0x1100 && cp <= 0x115F) ||   // Hangul Jamo
      (cp >= 0x2E80 && cp <= 0x303E) ||   // CJK Radicals Supplement, Kangxi Radicals
      (cp >= 0x3040 && cp <= 0x33BF) ||   // Hiragana, Katakana, CJK Compatibility
      (cp >= 0x3400 && cp <= 0x4DBF) ||   // CJK Unified Extension A
      (cp >= 0x4E00 && cp <= 0x9FFF) ||   // CJK Unified Ideographs
      (cp >= 0xA000 && cp <= 0xA4CF) ||   // Yi Syllables
      (cp >= 0xAC00 && cp <= 0xD7AF) ||   // Hangul Syllables
      (cp >= 0xF900 && cp <= 0xFAFF) ||   // CJK Compatibility Ideographs
      (cp >= 0xFE30 && cp <= 0xFE6F) ||   // CJK Compatibility Forms
      (cp >= 0xFF01 && cp <= 0xFF60) ||   // Fullwidth Forms
      (cp >= 0xFFE0 && cp <= 0xFFE6) ||   // Fullwidth Signs
      (cp >= 0x20000 && cp <= 0x2FA1F) || // CJK Ext B-F, Supplement
      (cp >= 0x1F300 && cp <= 0x1F9FF)    // Miscellaneous Symbols/Emoji
    ) {
      width += 2;
    } else if (cp >= 0x0300 && cp <= 0x036F) {
      // Combining diacritical marks — zero width
      width += 0;
    } else {
      width += 1;
    }
  }
  return width;
}

/**
 * Pad a string to a target display width, accounting for CJK characters.
 * @param {string} str - raw or ANSI-colored string
 * @param {number} targetWidth
 * @param {string} [fill=' ']
 * @returns {string}
 */
function padToWidth(str, targetWidth, fill = ' ') {
  const currentWidth = displayWidth(str);
  const needed = Math.max(0, targetWidth - currentWidth);
  return str + fill.repeat(needed);
}

/**
 * Truncate a string to a maximum display width, adding '...' if truncated.
 * @param {string} str
 * @param {number} maxWidth
 * @returns {string}
 */
function truncateToWidth(str, maxWidth) {
  if (displayWidth(str) <= maxWidth) return str;
  let result = '';
  let w = 0;
  for (const ch of str) {
    const cp = ch.codePointAt(0);
    const charWidth = (
      (cp >= 0x1100 && cp <= 0x115F) ||
      (cp >= 0x2E80 && cp <= 0x9FFF) ||
      (cp >= 0x3040 && cp <= 0x33BF) ||
      (cp >= 0x3400 && cp <= 0x4DBF) ||
      (cp >= 0x4E00 && cp <= 0x9FFF) ||
      (cp >= 0xAC00 && cp <= 0xD7AF) ||
      (cp >= 0xF900 && cp <= 0xFAFF) ||
      (cp >= 0xFE30 && cp <= 0xFE6F) ||
      (cp >= 0xFF01 && cp <= 0xFF60) ||
      (cp >= 0xFFE0 && cp <= 0xFFE6) ||
      (cp >= 0x20000 && cp <= 0x2FA1F) ||
      (cp >= 0x1F300 && cp <= 0x1F9FF)
    ) ? 2 : 1;
    if (w + charWidth + 3 > maxWidth) { // reserve 3 for '...'
      result += '...';
      break;
    }
    result += ch;
    w += charWidth;
  }
  return result;
}

/**
 * Safe string for terminal output — replace any characters that might
 * cause rendering issues in terminals that don't support full Unicode.
 */
function safeTerminalString(str) {
  if (!str || typeof str !== 'string') return '';
  // Replace null bytes and other control characters (except newline/tab)
  // eslint-disable-next-line no-control-regex
  return str.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
}

function printSuccess(msg) {
  console.log(chalk.green('  ✓ ') + msg);
}

function printError(msg) {
  console.log(chalk.red('  ✗ ') + msg);
}

function printWarn(msg) {
  console.log(chalk.yellow('  ⚠ ') + msg);
}

function printInfo(msg) {
  console.log(chalk.blue('  ℹ ') + msg);
}

function printTable(headers, rows) {
  try {
    const table = new Table({
      head: headers.map(h => chalk.cyan(h)),
      style: { 'padding-left': 1, 'padding-right': 1 },
    });
    rows.forEach(row => table.push(row));
    console.log(table.toString());
    return;
  } catch {
    // Fallback when cli-table3/string-width has ESM/CJS compatibility issues.
  }

  const colCount = headers.length;
  const normalizedRows = rows.map(row => {
    const arr = Array.isArray(row) ? row : [row];
    const out = new Array(colCount).fill('');
    for (let i = 0; i < colCount; i++) out[i] = String(arr[i] ?? '');
    return out;
  });

  const colWidths = headers.map((h, i) => {
    const headerW = displayWidth(String(h));
    const rowW = normalizedRows.reduce((max, row) => Math.max(max, displayWidth(String(row[i] ?? ''))), 0);
    return Math.max(headerW, rowW);
  });

  const top = `  ┌${colWidths.map(w => '─'.repeat(w + 2)).join('┬')}┐`;
  const mid = `  ├${colWidths.map(w => '─'.repeat(w + 2)).join('┼')}┤`;
  const bot = `  └${colWidths.map(w => '─'.repeat(w + 2)).join('┴')}┘`;

  console.log(chalk.dim(top));
  const headerLine = headers
    .map((h, i) => ` ${padToWidth(chalk.cyan(String(h)), colWidths[i])} `)
    .join(chalk.dim('│'));
  console.log(chalk.dim('  │') + headerLine + chalk.dim('│'));
  console.log(chalk.dim(mid));

  for (const row of normalizedRows) {
    const rowLine = row
      .map((cell, i) => ` ${padToWidth(String(cell), colWidths[i])} `)
      .join(chalk.dim('│'));
    console.log(chalk.dim('  │') + rowLine + chalk.dim('│'));
  }
  console.log(chalk.dim(bot));
}

function printQuote(quote) {
  const change = quote.current - quote.preClose;
  const changePct = quote.preClose > 0 ? (change / quote.preClose) * 100 : 0;
  const color = change >= 0 ? chalk.red : chalk.green; // Chinese market: red = up
  const icon = change >= 0 ? ICON_BULL : ICON_BEAR;
  const arrow = change >= 0 ? '▲' : '▼';

  console.log('');
  console.log(`  ${icon} ${chalk.bold(quote.name)} ${chalk.dim('(' + quote.symbol + ')')}`);
  console.log(chalk.dim('  ┌──────────────────────────────────────'));
  console.log(`  │ 现价  ${color(chalk.bold('¥' + quote.current.toFixed(2)))}  ${color(arrow + ' ' + (change >= 0 ? '+' : '') + changePct.toFixed(2) + '%')}`);
  console.log(`  │ 开盘  ¥${quote.open.toFixed(2)}  最高  ${chalk.red('¥' + quote.high.toFixed(2))}  最低  ${chalk.green('¥' + quote.low.toFixed(2))}`);
  console.log(`  │ 昨收  ¥${quote.preClose.toFixed(2)}  成交量  ${chalk.bold(formatVolume(quote.volume))}`);
  if (quote.date) console.log(`  │ 时间  ${chalk.dim(quote.date + ' ' + (quote.time || ''))}`);
  console.log(chalk.dim('  └──────────────────────────────────────'));
  console.log('');
}

function printBacktestResult(result) {
  const returnColor = result.totalReturn >= 0 ? chalk.red : chalk.green;
  const icon = result.totalReturn >= 0 ? ICON_BULL : ICON_BEAR;

  console.log('');
  console.log(`  ${ICON_CHART} ${chalk.bold('回测结果')} ${icon}`);
  console.log(chalk.dim('  ┌──────────────────────────────────────'));

  const rows = [
    ['品种', result.symbol],
    ['区间', `${result.startDate} → ${result.endDate}`],
    ['', ''],
    ['初始资金', formatCurrency(result.initialCapital)],
    ['最终资金', chalk.bold(formatCurrency(result.finalCapital))],
    ['总收益率', returnColor(chalk.bold(safePercent(result.totalReturn)))],
    ['年化收益', returnColor(safePercent(result.annualizedReturn))],
    ['', ''],
    ['最大回撤', chalk.yellow(safePercent(result.maxDrawdown, false))],
    ['夏普比率', safeNum(result.sharpeRatio, 4)],
    ['胜率', safePercent(result.winRate, false)],
    ['', ''],
    ['交易次数', String(result.totalTrades || 0)],
    ['盈利次数', chalk.red(String(result.winningTrades || 0))],
    ['亏损次数', chalk.green(String(result.losingTrades || 0))],
    ['交易天数', String(result.tradingDays || 0)],
  ];

  rows.forEach(([label, value]) => {
    if (!label && !value) {
      console.log(chalk.dim('  ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌'));
      return;
    }
    console.log(`  │ ${chalk.dim(label.padEnd(10))} ${value}`);
  });

  console.log(chalk.dim('  └──────────────────────────────────────'));
  console.log('');
}

function safePercent(value, showSign = true) {
  if (value === undefined || value === null || isNaN(value)) return '-';
  const prefix = showSign && value >= 0 ? '+' : '';
  return prefix + Number(value).toFixed(2) + '%';
}

function safeNum(value, decimals = 2) {
  if (value === undefined || value === null || isNaN(value)) return '-';
  return Number(value).toFixed(decimals);
}

function formatCurrency(value) {
  return '¥' + Number(value).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatVolume(vol) {
  if (!vol) return '0';
  if (vol >= 1e8) return (vol / 1e8).toFixed(2) + '亿';
  if (vol >= 1e4) return (vol / 1e4).toFixed(2) + '万';
  return String(vol);
}

function printHelp() {
  const pkg = require('../../package.json');
  const displayVersion = process.env.KHYQUANT_PKG_VERSION || pkg.version;
  console.log('');
  console.log(`  ${MASCOT_MINI} ${chalk.bold('khy OS')} ${chalk.cyan('v' + displayVersion)} ${chalk.dim('命令速查')}`);
  console.log(chalk.dim('  用法: khy <命令> [参数] [--选项]'));
  console.log(chalk.dim('  AI:  直接输入自然语言即可对话'));
  console.log(chalk.dim('  应用: khyquant 仅作为量化应用入口'));
  console.log('');

  const groups = [
    {
      name: '核心',
      cmds: [
        ['app list|install|start|stop|status', '应用管理'],
        ['server start [--port N] | server status', '服务管理'],
        ['db init|seed|status', '数据库'],
        ['menu | clear | exit', '交互辅助'],
      ],
    },
    {
      name: 'AI 与网关',
      cmds: [
        ['gateway status|model|prefer-remote|config|relay', '通道状态与切换'],
        ['models list|pull|import|set|delete', '本地模型管理'],
        ['ai status|config|owner', 'AI 配置与权限'],
        ['kiro|cursor|claude|codex|trae --list', '查看 IDE 模型'],
      ],
    },
    {
      name: '诊断与运维',
      cmds: [
        ['doctor', '环境诊断'],
        ['init [--force]', '初始化/重置'],
        ['publish check|build|pypi|testpypi', 'PyPI 构建与发布'],
        ['verify workflow [--adapter ...] [--timeout N] [--autofix]', 'T1-T5 工作流稳定性测试'],
        ['monitor selfcheck status|run', '底座自检'],
        ['proxy quickstart | proxy client add|list', '代理与令牌'],
        ['linux status|net|run', '网络与系统排查'],
      ],
    },
    {
      name: '量化应用 (khyquant)',
      cmds: [
        ['quote|hq <代码|名称>', '实时行情'],
        ['backtest|bt <代码> [--strategy ...]', '策略回测'],
        ['data fetch <代码> | data list', '数据下载/列表'],
        ['search <关键词> | analyze <代码>', '搜索与分析'],
      ],
    },
  ];

  groups.forEach((group) => {
    console.log(`  ${chalk.cyan.bold(group.name)}`);
    group.cmds.forEach(([cmd, desc]) => {
      console.log(`    ${chalk.white(cmd.padEnd(40))} ${chalk.dim(desc)}`);
    });
    console.log('');
  });

  console.log(chalk.dim('  示例:'));
  console.log(chalk.dim('    khy gateway status'));
  console.log(chalk.dim('    khy gateway model'));
  console.log(chalk.dim('    khy ai run qwen3.5:4b'));
  console.log(chalk.dim('    khy doctor'));
  console.log(chalk.dim('    khy hq 茅台'));
  console.log(chalk.dim('    khy bt sh600519 --strategy 1'));
  console.log('');
  console.log(chalk.dim('  更多文档: khy docs'));
  console.log('');
}

function _normalizeHelpTopic(input = '') {
  const key = String(input || '').trim().toLowerCase();
  if (!key) return null;
  if (['gateway', 'gw', 'model', 'models', '网关', '模型'].includes(key)) return 'gateway';
  if (['quant', 'khyquant', 'trade', 'trading', '量化', '交易'].includes(key)) return 'quant';
  if (['ops', 'doctor', 'devops', '运维', '诊断', '排障'].includes(key)) return 'ops';
  return null;
}

function printHelpTopic(topicInput = '') {
  const topic = _normalizeHelpTopic(topicInput);
  if (!topic) {
    printWarn(`未知帮助主题: ${topicInput}`);
    printInfo('可用主题: gateway | quant | ops');
    printInfo('示例: khy help gateway');
    return false;
  }

  console.log('');
  console.log(`  ${MASCOT_MINI} ${chalk.bold('khy help')} ${chalk.cyan(topic)}`);
  console.log('');

  if (topic === 'gateway') {
    const rows = [
      ['gateway status', '查看通道可用性与实测告警'],
      ['gateway model', '选择默认通道与模型'],
      ['gateway prefer-remote', '一键切换到可用 API/桥接通道'],
      ['gateway tune-local [auto|fast|balanced|quality] [apply]', '本地模型参数智能匹配并写入 .env'],
      ['gateway config', '配置网关参数（endpoint/key/timeout）'],
      ['gateway relay', '启动 Web 中转'],
      ['models list|pull|import|set|delete', '管理本地模型（Ollama）'],
      ['ai config', '配置 API 密钥'],
      ['proxy quickstart', '一键启动代理并输出接入参数'],
    ];
    rows.forEach(([cmd, desc]) => {
      console.log(`    ${chalk.white(cmd.padEnd(34))} ${chalk.dim(desc)}`);
    });
    console.log('');
    console.log(chalk.dim('  示例:'));
    console.log(chalk.dim('    khy gateway status'));
    console.log(chalk.dim('    khy gateway prefer-remote'));
    console.log(chalk.dim('    khy gateway model'));
    console.log(chalk.dim('    khy ai run qwen3.5:4b'));
    console.log('');
    return true;
  }

  if (topic === 'quant') {
    const rows = [
      ['hq|quote <代码|名称>', '查看实时行情'],
      ['search <关键词>', '搜索标的'],
      ['data fetch <代码> | data list', '下载/列出数据'],
      ['bt|backtest <代码> [--strategy ...]', '执行策略回测'],
      ['strategy list | backtest list', '查看策略/历史回测'],
      ['analyze <代码>', 'AI 辅助分析'],
      ['cache clear', '清理缓存'],
    ];
    rows.forEach(([cmd, desc]) => {
      console.log(`    ${chalk.white(cmd.padEnd(34))} ${chalk.dim(desc)}`);
    });
    console.log('');
    console.log(chalk.dim('  示例:'));
    console.log(chalk.dim('    khy hq 茅台'));
    console.log(chalk.dim('    khy bt sh600519 --strategy 1'));
    console.log(chalk.dim('    khy analyze sz000001'));
    console.log('');
    return true;
  }

  // ops
  const rows = [
    ['doctor', '环境诊断（依赖/网络/服务）'],
    ['init [--force]', '初始化或强制重置'],
    ['publish check|build|pypi|testpypi', 'PyPI 构建、检查、发布'],
    ['verify workflow [--adapter ...] [--timeout N] [--autofix]', 'T1-T5 稳定性工作流测试'],
    ['monitor selfcheck status|run', '底座自检状态/立即执行'],
    ['linux status|net|run', '系统网络排障'],
    ['proxy status|quickstart', '代理状态与快速启动'],
    ['server status', '后端服务状态'],
    ['db status', '数据库状态'],
  ];
  rows.forEach(([cmd, desc]) => {
    console.log(`    ${chalk.white(cmd.padEnd(34))} ${chalk.dim(desc)}`);
  });
  console.log('');
  console.log(chalk.dim('  示例:'));
  console.log(chalk.dim('    khy doctor'));
  console.log(chalk.dim('    khy monitor selfcheck run'));
  console.log(chalk.dim('    khy linux net'));
  console.log('');
  return true;
}

async function withSpinner(text, fn, { muteOutput = false } = {}) {
  // On Windows, ora's ANSI cursor control conflicts with readline in REPL mode,
  // causing all output to be swallowed. Use a simple text fallback instead.
  const useSimpleSpinner = process.platform === 'win32' && process.stdin.isTTY;

  let spinner;
  if (useSimpleSpinner) {
    // Simple fallback: just print the text, no animated spinner
    process.stdout.write(chalk.cyan(`  ◌ ${text}...`));
    spinner = {
      succeed: (msg) => { process.stdout.write('\r' + chalk.green(`  ✓ ${msg || text}`) + '\n'); },
      fail: (msg) => { process.stdout.write('\r' + chalk.red(`  ✗ ${msg || text}`) + '\n'); },
    };
  } else {
    try {
      const ora = (await import('ora')).default;
      // discardStdin: false prevents ora from pausing/closing stdin,
      // which would destroy any active readline interface and crash the REPL.
      spinner = ora({ text, indent: 2, discardStdin: false }).start();
    } catch {
      // ora dynamic import may fail — fall back to simple text spinner
      process.stdout.write(chalk.cyan(`  ◌ ${text}`));
      spinner = {
        succeed: (msg) => { process.stdout.write('\r' + chalk.green(`  ✓ ${msg || text}`) + '\n'); },
        fail: (msg) => { process.stdout.write('\r' + chalk.red(`  ✗ ${msg || text}`) + '\n'); },
      };
    }
  }

  // Suppress noisy service logs (console + winston) while spinner runs
  let origLog, origWarn, origError, origLogLevel;
  if (muteOutput) {
    origLog = console.log;
    origWarn = console.warn;
    origError = console.error;
    console.log = () => {};
    console.warn = () => {};
    console.error = () => {};
    // Also silence winston console transport
    try {
      const logger = require('../utils/logger');
      origLogLevel = logger.level;
      logger.level = 'silent';
    } catch { /* logger not available */ }
  }

  const restore = () => {
    if (!muteOutput) return;
    console.log = origLog;
    console.warn = origWarn;
    console.error = origError;
    try {
      const logger = require('../utils/logger');
      logger.level = origLogLevel || 'info';
    } catch { /* ignore */ }
  };

  try {
    const result = await fn();
    restore();
    spinner.succeed();
    return result;
  } catch (err) {
    restore();
    spinner.fail(err.message);
    throw err;
  }
}

function printDivider(label) {
  if (label) {
    const line = '─'.repeat(Math.max(0, 22 - stripAnsi(label).length));
    console.log(chalk.dim(`  ── ${label} ${line}`));
  } else {
    console.log(chalk.dim('  ' + '─'.repeat(40)));
  }
}

// Farewell messages (randomly chosen on exit)
const FAREWELLS = [
  '任务完成，随时回来继续。再见！',
  '平台已待命，下次见！',
  '保持节奏，持续迭代。再见！',
  '祝你开发顺利，下次见！',
  '理性决策，稳步推进。再见！',
];

function getRandomFarewell() {
  return FAREWELLS[Math.floor(Math.random() * FAREWELLS.length)];
}

/**
 * Print startup banner for AI-only / lite mode.
 * Aligned with Claude Code's compact banner:
 *   [sprite]  khy OS vX.Y.Z
 *             model · provider
 *             ~/cwd
 */
function printLiteBanner(version, aiProvider) {
  const d = chalk.dim;
  const orange = chalk.hex('#D77757');

  const cwd = process.cwd();
  const home = os.homedir();
  const cwdShort = cwd === home
    ? '~'
    : (cwd.startsWith(home + path.sep) ? '~' + cwd.slice(home.length) : cwd);
  const ver = version || require('../../package.json').version;

  let modelName = '';
  try {
    const gateway = require('../services/gateway/aiGateway');
    const active = gateway.getActiveAdapter();
    modelName = active?.activeModel || '';
  } catch { /* best effort */ }

  const providerText = String(aiProvider || 'AI');
  const modelText = String(modelName || '');
  const providerPart = (
    modelText && !providerText.toLowerCase().includes(modelText.toLowerCase())
  )
    ? `${modelText} · ${providerText}`
    : providerText;

  // Compact sprite (Claude Code style)
  const petLines = [
    orange(' ▐▛███▜▌'),
    orange('▝▜█████▛▘'),
    orange('  ▘▘ ▝▝'),
  ];

  console.log('');
  console.log(`${petLines[0]}  ${chalk.bold('khy OS')} ${d(`v${ver}`)}`);
  console.log(`${petLines[1]}    ${d(providerPart)}`);
  console.log(`${petLines[2]}    ${d(cwdShort)}`);
  console.log('');
}

module.exports = {
  // Output functions
  printBanner,
  printLiteBanner,
  printSuccess,
  printError,
  printWarn,
  printInfo,
  printTable,
  printQuote,
  printBacktestResult,
  printHelp,
  printHelpTopic,
  printDivider,
  // Formatting helpers
  formatCurrency,
  formatVolume,
  stripAnsi,
  displayWidth,
  padToWidth,
  truncateToWidth,
  safeTerminalString,
  // Spinner
  withSpinner,
  // Theme icons (for use in other modules)
  MASCOT_MINI,
  ICON_PROMPT,
  ICON_AI,
  ICON_BOT,
  ICON_CHART,
  ICON_GEAR,
  ICON_ROCKET,
  ICON_KEY,
  ICON_DB,
  ICON_SEARCH,
  ICON_HEART,
  ICON_PLUG,
  ICON_BULL,
  ICON_BEAR,
  ICON_GATEWAY,
  // Farewell
  getRandomFarewell,
};
