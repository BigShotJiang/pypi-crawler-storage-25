/**
 * Hook System — unified facade for the hooks subsystem.
 *
 * Usage:
 *   const hookSystem = require('./hooks/hookSystem');
 *   hookSystem.init(projectDir);
 *
 *   // Before tool execution:
 *   const { blocked, context } = await hookSystem.trigger('PreToolUse', { toolName, args });
 *   if (blocked) return; // hook vetoed this action
 *
 *   // After tool execution:
 *   await hookSystem.trigger('PostToolUse', { toolName, result });
 */
const registry = require('./hookRegistry');
const { runHooks } = require('./hookRunner');

let _initialized = false;

function init(projectDir) {
  registry.load(projectDir);
  _initialized = true;
  if (registry.count > 0) {
    console.log(`[Hooks] Loaded ${registry.count} hook(s)`);
  }
}

/**
 * Trigger hooks for an event.
 * @param {string} event - One of: PreToolUse, PostToolUse, PrePrompt, PostResponse, Stop, SubAgentStart, SubAgentEnd
 * @param {Object} context - Event-specific data
 * @returns {Promise<{blocked: boolean, reason?: string, context: Object}>}
 */
async function trigger(event, context = {}) {
  if (!_initialized) return { blocked: false, context };

  const hooks = registry.getHooks(event, context);
  if (hooks.length === 0) return { blocked: false, context };

  return runHooks(hooks, context);
}

function reload(projectDir) {
  init(projectDir);
}

module.exports = { init, trigger, reload, registry };
