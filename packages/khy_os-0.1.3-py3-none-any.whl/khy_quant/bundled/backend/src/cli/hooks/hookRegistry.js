/**
 * Hook Registry — stores and matches lifecycle hooks.
 *
 * Hooks intercept CLI events at well-defined points:
 *   PreToolUse    — before a tool executes (can block/modify)
 *   PostToolUse   — after a tool returns (can transform result)
 *   PrePrompt     — before sending prompt to LLM
 *   PostResponse  — after receiving LLM response
 *   Stop          — when a task or session is stopped/interrupted
 *   SubAgentStart — when a sub-agent is spawned
 *   SubAgentEnd   — when a sub-agent completes
 *
 * Config: ~/.khyquant/hooks.json or project .khyquant/hooks.json
 */
const fs = require('fs');
const path = require('path');
const os = require('os');

const HOOK_EVENTS = [
  'PreToolUse',
  'PostToolUse',
  'PrePrompt',
  'PostResponse',
  'Stop',
  'SubAgentStart',
  'SubAgentEnd',
];

const GLOBAL_HOOKS_PATH = path.join(os.homedir(), '.khyquant', 'hooks.json');

class HookRegistry {
  constructor() {
    this._hooks = new Map(); // event → Hook[]
    for (const ev of HOOK_EVENTS) this._hooks.set(ev, []);
  }

  /**
   * Load hooks from config files (project-level overrides global).
   */
  load(projectDir) {
    this._clearAll();

    const configs = [];
    if (fs.existsSync(GLOBAL_HOOKS_PATH)) {
      configs.push({ source: 'global', path: GLOBAL_HOOKS_PATH });
    }
    if (projectDir) {
      const projectHooks = path.join(projectDir, '.khyquant', 'hooks.json');
      if (fs.existsSync(projectHooks)) {
        configs.push({ source: 'project', path: projectHooks });
      }
    }

    for (const cfg of configs) {
      try {
        const raw = JSON.parse(fs.readFileSync(cfg.path, 'utf-8'));
        const hooks = Array.isArray(raw) ? raw : (raw.hooks || []);
        for (const h of hooks) {
          this._register(h, cfg.source);
        }
      } catch (err) {
        console.error(`[HookRegistry] Failed to load ${cfg.path}: ${err.message}`);
      }
    }
  }

  _register(hookDef, source) {
    const { event, command, pattern, timeout = 10000, enabled = true } = hookDef;
    if (!enabled) return;
    if (!HOOK_EVENTS.includes(event)) {
      console.warn(`[HookRegistry] Unknown event "${event}", skipping`);
      return;
    }
    if (!command) {
      console.warn(`[HookRegistry] Hook missing "command", skipping`);
      return;
    }

    this._hooks.get(event).push({
      event,
      command,
      pattern: pattern ? new RegExp(pattern) : null,
      timeout,
      source,
    });
  }

  /**
   * Get all hooks for a given event, optionally filtered by context.
   */
  getHooks(event, context = {}) {
    const hooks = this._hooks.get(event) || [];
    return hooks.filter(h => {
      if (!h.pattern) return true;
      const target = context.toolName || context.prompt || '';
      return h.pattern.test(target);
    });
  }

  _clearAll() {
    for (const ev of HOOK_EVENTS) this._hooks.set(ev, []);
  }

  get events() { return [...HOOK_EVENTS]; }
  get count() {
    let n = 0;
    for (const hooks of this._hooks.values()) n += hooks.length;
    return n;
  }
}

module.exports = new HookRegistry();
