/**
 * CLI Handlers for built-in documentation / tutorials.
 * Renders markdown docs directly in the terminal.
 */
const chalk = require('chalk').default || require('chalk');
const fs = require('fs');
const path = require('path');
const { printInfo, printSuccess } = require('../formatters');

const DOCS_DIR = path.resolve(__dirname, '../../../docs');
const BUNDLED_DOCS_DIR = path.resolve(__dirname, '../../bundled/docs');

function getDocsDir() {
  if (fs.existsSync(DOCS_DIR)) return DOCS_DIR;
  if (fs.existsSync(BUNDLED_DOCS_DIR)) return BUNDLED_DOCS_DIR;
  return null;
}

/**
 * Render a markdown file as terminal-friendly output.
 */
function renderMarkdown(content) {
  const lines = content.split('\n');
  const output = [];

  for (const line of lines) {
    if (line.startsWith('# ')) {
      output.push('');
      output.push(chalk.cyan.bold('  ' + line.slice(2)));
      output.push(chalk.dim('  ' + '─'.repeat(50)));
    } else if (line.startsWith('## ')) {
      output.push('');
      output.push(chalk.yellow.bold('  ' + line.slice(3)));
    } else if (line.startsWith('### ')) {
      output.push(chalk.green('  ' + line.slice(4)));
    } else if (line.startsWith('```')) {
      output.push(chalk.dim('  ┄┄┄'));
    } else if (line.startsWith('- ')) {
      output.push('  ' + chalk.dim('•') + ' ' + line.slice(2));
    } else if (line.startsWith('> ')) {
      output.push(chalk.dim('  │ ') + chalk.italic(line.slice(2)));
    } else if (line.trim() === '') {
      output.push('');
    } else {
      output.push('  ' + line);
    }
  }

  return output.join('\n');
}

async function handleDocsQuickstart() {
  console.log('');
  console.log(chalk.cyan.bold('  🚀 khy OS 快速开始'));
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log('  ' + chalk.bold('5 分钟上手：'));
  console.log('');
  console.log('  ' + chalk.green('Step 1') + ' — 查询行情:');
  console.log(chalk.dim('    $ khy hq 茅台'));
  console.log(chalk.dim('    $ khy hq sh000300'));
  console.log('');
  console.log('  ' + chalk.green('Step 2') + ' — 与 AI 对话:');
  console.log(chalk.dim('    $ khy'));
  console.log(chalk.dim('    ◉ khy ❯ 分析一下沪深300最近的走势'));
  console.log('');
  console.log('  ' + chalk.green('Step 3') + ' — 策略回测:');
  console.log(chalk.dim('    $ khy bt sh000300 --strategy 1'));
  console.log('');
  console.log('  ' + chalk.green('Step 4') + ' — 网关配置 (选择 AI 通道):');
  console.log(chalk.dim('    $ khy gateway model'));
  console.log('');
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log('  ' + chalk.bold('常用命令:'));
  console.log('');
  console.log('  ' + chalk.cyan('hq <代码|名称>') + '  查询实时行情');
  console.log('  ' + chalk.cyan('bt <代码>') + '       快速回测');
  console.log('  ' + chalk.cyan('menu') + '            打开交互式菜单');
  console.log('  ' + chalk.cyan('gateway model') + '   选择 AI 模型');
  console.log('  ' + chalk.cyan('doctor') + '          环境诊断');
  console.log('  ' + chalk.cyan('help') + '            查看全部命令');
  console.log('');
  console.log(chalk.dim('  💡 提示: 直接输入中文问题，AI 会理解并执行'));
  console.log('');
}

async function handleDocsClaude() {
  const docsDir = getDocsDir();
  if (!docsDir) {
    printInfo('教程文件未安装。请使用完整版: pip install "khy-os[all]"');
    return;
  }

  const claudeDir = path.join(docsDir, 'claude-code');
  if (!fs.existsSync(claudeDir)) {
    printInfo('Claude Code 教程文件未找到');
    return;
  }

  const files = fs.readdirSync(claudeDir)
    .filter(f => f.endsWith('.md'))
    .sort();

  const inquirer = require('inquirer');
  const { doc } = await inquirer.prompt([{
    type: 'list',
    name: 'doc',
    message: '选择教程:',
    choices: [
      ...files.map(f => ({
        name: f.replace('.md', '').replace(/^\d+-/, ''),
        value: f,
      })),
      { name: '↩️  返回', value: 'back' },
    ],
    pageSize: 15,
  }]);

  if (doc === 'back') return;

  const content = fs.readFileSync(path.join(claudeDir, doc), 'utf-8');
  // Show first 80 lines as preview
  const preview = content.split('\n').slice(0, 80).join('\n');
  console.log(renderMarkdown(preview));
  console.log('');
  printInfo(`完整文档: ${path.join(claudeDir, doc)}`);
  console.log('');
}

async function handleDocsGateway() {
  console.log('');
  console.log(chalk.cyan.bold('  🌐 AI 网关使用指南'));
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log('  khy OS 支持多种 AI 通道，按优先级自动选择:');
  console.log('');
  console.log('  ' + chalk.bold('通道优先级 (从高到低):'));
  console.log('  ' + chalk.green('1.') + ' CLI 工具桥接 — 复用已登录的 Claude/Codex');
  console.log('  ' + chalk.green('2.') + ' Kiro IDE — Amazon Q Developer (免费)');
  console.log('  ' + chalk.green('3.') + ' Cursor IDE — 复用 Cursor 订阅');
  console.log('  ' + chalk.green('4.') + ' Claude Code — 复用 Claude 订阅');
  console.log('  ' + chalk.green('5.') + ' Ollama 本地 — 完全离线，无需API密钥');
  console.log('  ' + chalk.green('6.') + ' API 云端 — 需配置密钥');
  console.log('  ' + chalk.green('7.') + ' Web 中转 — 手动复制粘贴到网页AI');
  console.log('');
  console.log('  ' + chalk.bold('通用扩展:'));
  console.log(chalk.dim('    CLIPBOARD_RELAY_EXTRA_SERVICES="myrelay|My Relay|https://example.com/chat,foo=https://foo.ai"'));
  console.log(chalk.dim('    RELAY_API_MODELS="gpt-4.1,claude-sonnet-4-6,deepseek-chat"'));
  console.log(chalk.dim('    GATEWAY_EXTRA_IDES="myide" + MYIDE_INSTALL_PATH/MYIDE_DATA_PATH'));
  console.log('');
  console.log('  ' + chalk.bold('配置方法:'));
  console.log(chalk.dim('    khy gateway status    查看所有通道状态'));
  console.log(chalk.dim('    khy gateway model     选择使用哪个模型'));
  console.log(chalk.dim('    khy gateway prefer-remote 一键切换到可用 API/桥接通道'));
  console.log(chalk.dim('    khy gateway config    配置参数'));
  console.log(chalk.dim('    khy gateway relay     启动 Web 中转'));
  console.log(chalk.dim('    khy gateway discover-models 自动发现本机模型并更新 RELAY_API_MODELS'));
  console.log('');
  console.log('  ' + chalk.bold('高级策略配置 (支持国内外多供应商/多渠道):'));
  console.log(chalk.dim('    gateway config → 高级: 模型路由规则'));
  console.log(chalk.dim('      GATEWAY_MODEL_ROUTE_MAP={\"gpt-4o-mini\":\"api/openai:gpt-4o-mini\",\"claude-*\":{\"target\":\"kiro/claude-sonnet-4\",\"strict\":true}}'));
  console.log(chalk.dim('      GATEWAY_MODEL_ROUTE_STRICT=false'));
  console.log(chalk.dim('    gateway config → 高级: Key 选择策略'));
  console.log(chalk.dim('      GATEWAY_KEY_SELECTION_STRATEGY=hybrid'));
  console.log(chalk.dim('      GATEWAY_KEY_SELECTION_STRATEGY_MAP={\"relay\":\"least-used\",\"openai\":\"least-fail\"}'));
  console.log(chalk.dim('    gateway config → 高级: API 池默认 provider'));
  console.log(chalk.dim('      GATEWAY_API_POOL_PROVIDER=deepseek'));
  console.log(chalk.dim('    gateway config → 高级: 供应商映射'));
  console.log(chalk.dim('      GATEWAY_API_POOL_PROVIDER_ALIAS_MAP={\"openai-sb\":\"openai\",\"myqwen\":\"qwen\"}'));
  console.log(chalk.dim('      GATEWAY_API_POOL_SERVICE_MAP={\"deepseek\":\"openai\",\"qwen\":\"alibaba\",\"glm\":\"zhipu\",\"relay\":\"openai\"}'));
  console.log(chalk.dim('      GATEWAY_API_POOL_DEFAULT_MODEL_MAP={\"deepseek\":\"deepseek-chat\",\"qwen\":\"qwen-plus\"}'));
  console.log('');
  console.log('  ' + chalk.bold('Ollama 本地部署 (推荐):'));
  console.log(chalk.dim('    1. 安装 Ollama: https://ollama.com'));
  console.log(chalk.dim('    2. 拉取模型: ollama pull qwen2.5:7b'));
  console.log(chalk.dim('    3. 导入本地模型: models import <path> [name] [--base qwen2.5:7b]'));
  console.log(chalk.dim('    3. 重启 khy，自动检测'));
  console.log('');
}

async function handleDocsStrategy() {
  console.log('');
  console.log(chalk.cyan.bold('  📊 量化策略入门'));
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log('  ' + chalk.bold('内置策略:'));
  console.log('');
  console.log('  ' + chalk.green('1.') + ' 双均线交叉 — MA5/MA20 金叉死叉');
  console.log('  ' + chalk.green('2.') + ' RSI 超买超卖 — RSI > 70 卖 / RSI < 30 买');
  console.log('  ' + chalk.green('3.') + ' MACD 信号 — MACD 金叉做多');
  console.log('  ' + chalk.green('4.') + ' 布林带突破 — 突破上/下轨交易');
  console.log('  ' + chalk.green('5.') + ' ML 机器学习 — 基于 XGBoost 预测');
  console.log('');
  console.log('  ' + chalk.bold('回测示例:'));
  console.log(chalk.dim('    khy bt sh000300 --strategy 1 --start 2024-01-01'));
  console.log(chalk.dim('    khy bt sh600519 --strategy 3 --capital 200000'));
  console.log('');
  console.log('  ' + chalk.bold('指标说明:'));
  console.log('  • ' + chalk.yellow('年化收益率') + ' — 策略的年化投资回报');
  console.log('  • ' + chalk.yellow('夏普比率') + ' — 每承受1单位风险获得的超额收益');
  console.log('  • ' + chalk.yellow('最大回撤') + ' — 净值从最高点的最大跌幅');
  console.log('  • ' + chalk.yellow('胜率') + ' — 盈利交易占总交易数的比例');
  console.log('');
}

async function handleDocsFaq() {
  console.log('');
  console.log(chalk.cyan.bold('  🔧 常见问题 FAQ'));
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log(chalk.bold('  Q: 安装时报 "WinError 5 拒绝访问"?'));
  console.log(chalk.dim('  A: Windows 文件被占用。解决方法:'));
  console.log(chalk.dim('     1. 关闭所有 Python 进程: taskkill /F /IM python.exe'));
  console.log(chalk.dim('     2. 关闭 VSCode / Jupyter'));
  console.log(chalk.dim('     3. 以管理员身份运行 PowerShell'));
  console.log(chalk.dim('     4. 或使用: pip install --user khy-os'));
  console.log('');
  console.log(chalk.bold('  Q: 行情显示乱码?'));
  console.log(chalk.dim('  A: Windows 终端编码问题。运行:'));
  console.log(chalk.dim('     chcp 65001'));
  console.log(chalk.dim('     或使用 Windows Terminal (推荐)'));
  console.log('');
  console.log(chalk.bold('  Q: AI 不回复?'));
  console.log(chalk.dim('  A: 检查网关状态: khy gateway status'));
  console.log(chalk.dim('     优先使用 Ollama 本地模型 (无需网络)'));
  console.log(chalk.dim('     或启动 Web 中转: khy gateway relay'));
  console.log('');
  console.log(chalk.bold('  Q: 如何升级?'));
  console.log(chalk.dim('  A: pip install --upgrade khy-os --no-cache-dir'));
  console.log(chalk.dim('     兼容旧包名: pip install --upgrade khy-quant --no-cache-dir'));
  console.log(chalk.dim('     如遇权限问题加 --user'));
  console.log('');
  console.log(chalk.bold('  Q: 如何配置 API 密钥?'));
  console.log(chalk.dim('  A: 运行 ai config，按提示输入密钥'));
  console.log(chalk.dim('     或直接设置环境变量: OPENAI_API_KEY=sk-xxx'));
  console.log('');
}

async function handleDocsSubscription() {
  console.log('');
  console.log(chalk.cyan.bold('  💳 AI 模型订阅与获取指南'));
  console.log(chalk.dim('  ' + '─'.repeat(55)));
  console.log('');
  console.log(chalk.bold.green('  🆓 免费方案 (国内直接可用):'));
  console.log('');
  console.log('  ' + chalk.green('1.') + chalk.bold(' Kiro IDE') + ' — 免费 Claude 4 Sonnet 额度');
  console.log(chalk.dim('     下载: https://kiro.dev'));
  console.log(chalk.dim('     安装后登录 Amazon 账号即可使用'));
  console.log(chalk.dim('     运行: khy gateway model → 选择 Kiro'));
  console.log('');
  console.log('  ' + chalk.green('2.') + chalk.bold(' Trae IDE') + ' — 免费 Claude/GPT 额度 (字节跳动)');
  console.log(chalk.dim('     下载: https://trae.ai'));
  console.log(chalk.dim('     国内直连，支持 doubao-1.5-pro / Claude / GPT'));
  console.log('');
  console.log('  ' + chalk.green('3.') + chalk.bold(' Ollama 本地模型') + ' — 完全离线，无需 API');
  console.log(chalk.dim('     安装: https://ollama.com'));
  console.log(chalk.dim('     推荐模型: ollama pull qwen2.5:7b'));
  console.log(chalk.dim('     高配推荐: ollama pull qwen2.5:32b'));
  console.log('');
  console.log(chalk.bold.yellow('  💰 付费订阅 (需代理/VPN):'));
  console.log('');
  console.log('  ' + chalk.yellow('4.') + chalk.bold(' Claude (Anthropic)'));
  console.log(chalk.dim('     订阅: https://claude.ai/pricing'));
  console.log(chalk.dim('     Pro $20/月, 安装 Claude Code CLI 后复用额度'));
  console.log(chalk.dim('     运行: npm i -g @anthropic-ai/claude-code && claude'));
  console.log('');
  console.log('  ' + chalk.yellow('5.') + chalk.bold(' OpenAI / Codex'));
  console.log(chalk.dim('     订阅: https://platform.openai.com'));
  console.log(chalk.dim('     安装 Codex CLI: npm i -g @openai/codex && codex'));
  console.log('');
  console.log('  ' + chalk.yellow('6.') + chalk.bold(' Cursor IDE'));
  console.log(chalk.dim('     订阅: https://cursor.com/pricing'));
  console.log(chalk.dim('     Pro $20/月，含 Claude/GPT 额度'));
  console.log('');
  console.log(chalk.bold.cyan('  🇨🇳 国内直连 API (无需代理):'));
  console.log('');
  console.log('  ' + chalk.cyan('7.') + chalk.bold(' 智谱AI (GLM)'));
  console.log(chalk.dim('     注册: https://open.bigmodel.cn'));
  console.log(chalk.dim('     运行: ai config → 输入 API 密钥'));
  console.log('');
  console.log('  ' + chalk.cyan('8.') + chalk.bold(' 通义千问 (阿里云)'));
  console.log(chalk.dim('     注册: https://dashscope.aliyun.com'));
  console.log('');
  console.log('  ' + chalk.cyan('9.') + chalk.bold(' DeepSeek'));
  console.log(chalk.dim('     注册: https://platform.deepseek.com'));
  console.log('');
  console.log(chalk.bold('  🌐 代理配置 (中国大陆访问海外 AI):'));
  console.log(chalk.dim('     运行 /proxy 自动检测 Clash 代理'));
  console.log(chalk.dim('     支持 HTTP/SOCKS5 手动配置'));
  console.log(chalk.dim('     配置后 Claude/OpenAI/Cursor 均可正常使用'));
  console.log('');
  console.log(chalk.bold.magenta('  🔗 API 中转渠道 (国内直连 Claude/GPT):'));
  console.log('');
  console.log('  ' + chalk.magenta('10.') + chalk.bold(' AWS Bedrock 中转'));
  console.log(chalk.dim('      通过 AWS 中国区或亚太区 Lambda/API Gateway 访问'));
  console.log(chalk.dim('      需要 AWS 账号 + Bedrock 模型权限'));
  console.log(chalk.dim('      注册: https://aws.amazon.com/cn/bedrock'));
  console.log('');
  console.log('  ' + chalk.magenta('11.') + chalk.bold(' 第三方中转站'));
  console.log(chalk.dim('      国内直连，按 token 计费，无需代理'));
  console.log(chalk.dim('      常见: OpenAI-SB, API2D, OhMyGPT, CloseAI 等'));
  console.log(chalk.dim('      配置: gateway config → 设置中转地址和密钥'));
  console.log('');
  console.log('  ' + chalk.magenta('12.') + chalk.bold(' 自建 VPS / Cloudflare Workers 反代'));
  console.log(chalk.dim('      购买海外 VPS (Vultr/DigitalOcean $5/月起)'));
  console.log(chalk.dim('      或使用 Cloudflare Workers 免费套餐'));
  console.log(chalk.dim('      反代 api.anthropic.com / api.openai.com'));
  console.log('');
  console.log(chalk.bold('  ⚙ 中转配置方法:'));
  console.log(chalk.dim('     gateway config → 选择 "API 中转"'));
  console.log(chalk.dim('     或设置环境变量:'));
  console.log(chalk.dim('       RELAY_API_ENDPOINT=https://your-relay.com/v1'));
  console.log(chalk.dim('       RELAY_API_KEY=sk-xxx'));
  console.log(chalk.dim('       RELAY_API_MODEL=claude-sonnet-4-20250514'));
  console.log('');
}

module.exports = {
  handleDocsQuickstart,
  handleDocsClaude,
  handleDocsGateway,
  handleDocsStrategy,
  handleDocsFaq,
  handleDocsSubscription,
};
