/**
 * CLI Handlers for the AI Gateway system.
 * Commands: gateway status, gateway config, gateway relay
 */
const chalkModule = require('chalk');
const chalk = chalkModule.default || chalkModule;
const readline = require('readline');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { spawn, spawnSync } = require('child_process');
const { printSuccess, printError, printInfo, printTable, ICON_GATEWAY } = require('../formatters');
const { getDataHome, getLegacyDataHome } = require('../../utils/dataHome');

const STRICT_OPERATIONAL_ADAPTERS = new Set(
  String(process.env.KHY_MODEL_STRICT_ADAPTERS || 'codex,claude,windsurf,trae')
    .split(',')
    .map(x => String(x || '').trim().toLowerCase())
    .filter(Boolean)
);
const MODEL_DEEP_PROBE_CACHE_MS = Math.max(
  10000,
  parseInt(process.env.KHY_MODEL_DEEP_PROBE_CACHE_MS || '300000', 10) || 300000
);
const _modelDeepProbeCache = new Map(); // key: adapter type -> { at, test }
const _modelDeepProbeInFlight = new Map();
const AI_MANAGE_RUNTIME_FILE = path.join(getDataHome(), 'ai_manage_runtime.json');
const AI_MANAGE_RUNTIME_FILE_LEGACY = path.join(getLegacyDataHome(), 'ai_manage_runtime.json');
const AI_MANAGE_READY_TIMEOUT_MS = Math.max(
  20000,
  parseInt(process.env.AI_MANAGE_READY_TIMEOUT_MS || '65000', 10) || 65000
);
const AI_MANAGE_DAEMON_SCRIPT = path.resolve(__dirname, '../../../scripts/ai-manage-daemon.js');

function _getDeepProbeCache(adapterType) {
  const key = String(adapterType || '').toLowerCase();
  if (!key) return null;
  const entry = _modelDeepProbeCache.get(key);
  if (!entry) return null;
  if ((Date.now() - entry.at) > MODEL_DEEP_PROBE_CACHE_MS) {
    _modelDeepProbeCache.delete(key);
    return null;
  }
  return entry;
}

function _setDeepProbeCache(adapterType, test) {
  const key = String(adapterType || '').toLowerCase();
  if (!key) return;
  _modelDeepProbeCache.set(key, { at: Date.now(), test });
}

function shouldTreatGenerationFailureAsWarning(adapterType) {
  // CLI-bridge related adapters can be environment-dependent.
  // Keep them selectable with warning instead of hard-blocking.
  return ['cli', 'claude', 'codex', 'localllm', 'ollama'].includes(String(adapterType || '').toLowerCase());
}

function _compactReasonText(text, maxLen = 140) {
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (!clean) return '';
  return clean.length > maxLen ? `${clean.slice(0, maxLen - 1)}…` : clean;
}

function _isTimeoutLikeReason(reasonText = '') {
  return /timeout|timed out|stream stalled|reconnecting|channel closed|socket hang up|econnreset|broken pipe|fetch failed|network error/i
    .test(String(reasonText || ''));
}

function _isAuthOrInstallLikeReason(reasonText = '') {
  return /auth|api[_\s-]?key|apikeysource|token|not authenticated|unauthorized|forbidden|login|permission denied|no token|not set|unavailable|command .* not found|not found|enoent/i
    .test(String(reasonText || ''));
}

function _classifyHiddenReason(status, test, fallbackReason = '') {
  const preferred = _compactReasonText(fallbackReason)
    || _compactReasonText(test?.generation?.error)
    || _compactReasonText(test?.models?.error)
    || _compactReasonText(test?.connectivity?.error)
    || '';
  const text = preferred.toLowerCase();
  if (!text) return '实测失败';
  if (_isAuthOrInstallLikeReason(text)) return `未登录/缺少凭证或未安装: ${preferred}`;
  if (_isTimeoutLikeReason(text)) return `探测超时: ${preferred}`;
  if (text.includes('not detected')) return '未检测到通道可用';
  return preferred;
}

function _formatModelSourceTag(model = {}) {
  const raw = String(model.discoverySource || model.source || '').trim().toLowerCase();
  if (!raw) return '';
  const map = {
    remote: '远端发现',
    local: '本地发现',
    'remote+local': '远端+本地',
    builtin: '内置',
    config: '配置项',
  };
  const label = map[raw] || raw;
  return chalk.dim(`[${label}]`);
}

function _formatConnectionTag(model = {}) {
  const mode = String(model.connectionMode || '').trim().toLowerCase();
  if (!mode) return '';
  const map = {
    direct: chalk.cyan('⚡直连'),
    bridge: chalk.yellow('🔗中转桥接'),
    proxy: chalk.dim('🔗代理中转'),
    local: chalk.green('📦本地推理'),
    auto: chalk.magenta('✨自动'),
  };
  return map[mode] || chalk.dim(mode);
}

function maskTokenValue(raw) {
  const token = String(raw || '').trim();
  if (!token) return '(empty)';
  if (token.length <= 10) return `${token.slice(0, 3)}***`;
  return `${token.slice(0, 6)}***${token.slice(-4)}`;
}

function parseProviderFromModelId(modelId) {
  const m = String(modelId || '').trim().match(/^([a-z0-9_-]+)[:/](.+)$/i);
  return m ? m[1].toLowerCase() : null;
}

const KEY_SELECTION_STRATEGY_CHOICES = [
  { name: 'round-robin (默认，优先级内轮询)', value: 'round-robin' },
  { name: 'least-fail (优先失败率低的 key)', value: 'least-fail' },
  { name: 'least-used (优先调用次数少的 key)', value: 'least-used' },
  { name: 'hybrid (综合失败率/退避/使用次数)', value: 'hybrid' },
];

const API_POOL_PROVIDER_KEYS = [
  'openai',
  'anthropic',
  'trae',
  'deepseek',
  'qwen',
  'glm',
  'doubao',
  'wenxin',
  'relay',
];

function _parseJsonObject(raw, fallback = {}) {
  const text = String(raw || '').trim();
  if (!text) return { ...fallback };
  try {
    const parsed = JSON.parse(text);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
  } catch {
    return { ...fallback };
  }
  return { ...fallback };
}

function _safeJsonLine(obj) {
  try {
    return JSON.stringify(obj || {});
  } catch {
    return '{}';
  }
}

function getPoolHint(provider) {
  if (!provider) return null;
  try {
    const pool = require('../../services/apiKeyPool');
    pool.init();
    const entries = pool.getPoolStatus(provider);
    if (!entries || entries.length === 0) return null;
    const previews = entries.slice(0, 2).map(e => e.keyPreview).join(', ');
    const more = entries.length > 2 ? ` +${entries.length - 2}` : '';
    return `池中 ${entries.length} 把 key (${previews}${more})`;
  } catch {
    return null;
  }
}

function getTokenInfoForSelection(selected) {
  const adapter = String(selected?.adapter || '').toLowerCase();
  const model = selected?.model || '';

  if (!adapter) return { source: 'unknown', detail: '未知适配器' };

  if (adapter === 'cursor2api') {
    try {
      const svc = require('../../services/cursor2apiIntegrationService');
      const cfg = svc.loadConfig();
      const token = process.env.CURSOR2API_TOKEN || cfg.authToken || '';
      return token
        ? { source: 'CURSOR2API_TOKEN', detail: maskTokenValue(token) }
        : { source: 'CURSOR2API_TOKEN', detail: '未设置' };
    } catch {
      return { source: 'CURSOR2API_TOKEN', detail: '读取失败' };
    }
  }

  if (adapter === 'relay_api') {
    const token = process.env.RELAY_API_KEY || '';
    if (token) return { source: 'RELAY_API_KEY', detail: maskTokenValue(token) };
    const poolHint = getPoolHint('relay');
    return { source: 'RELAY_API_KEY', detail: poolHint || '未设置' };
  }

  if (adapter === 'api') {
    const provider = parseProviderFromModelId(model);
    const envMap = {
      openai: 'OPENAI_API_KEY',
      anthropic: 'ANTHROPIC_API_KEY',
      deepseek: 'DEEPSEEK_API_KEY',
      qwen: 'QWEN_API_KEY',
      glm: 'GLM_API_KEY',
      doubao: 'DOUBAO_API_KEY',
      wenxin: 'WENXIN_API_KEY',
      trae: 'TRAE_API_KEY',
      relay: 'RELAY_API_KEY',
    };
    const envKey = provider ? envMap[provider] : null;
    if (envKey && process.env[envKey]) {
      return { source: envKey, detail: maskTokenValue(process.env[envKey]) };
    }
    const poolHint = getPoolHint(provider);
    if (provider) {
      return { source: provider, detail: poolHint || '未设置' };
    }
    return { source: 'api', detail: '该模型未包含 provider 前缀，无法定位 token' };
  }

  if (['cli', 'claude', 'codex', 'cursor', 'kiro', 'trae', 'warp', 'windsurf', 'vscode'].includes(adapter)) {
    return { source: 'local-login', detail: '本地 IDE/CLI 登录态（非显式 API token）' };
  }

  if (adapter === 'ollama' || adapter === 'localllm') {
    return { source: 'local-model', detail: '本地模型通道（无需 token）' };
  }

  if (adapter === 'relay' || adapter === 'clipboard') {
    return { source: 'manual-relay', detail: '网页/剪贴板中转（无需 API token）' };
  }

  return { source: adapter, detail: '未定义 token 映射' };
}

function getSharedReadline() {
  try {
    const toolCalling = require('../../services/toolCalling');
    const provider = toolCalling.getReadlineProvider ? toolCalling.getReadlineProvider() : null;
    return typeof provider === 'function' ? provider() : provider;
  } catch {
    return null;
  }
}

function askLine(promptText) {
  return new Promise((resolve) => {
    const shared = getSharedReadline();
    if (shared && typeof shared.question === 'function') {
      shared.question(promptText, (answer) => resolve(answer));
      return;
    }
    const temp = readline.createInterface({ input: process.stdin, output: process.stdout });
    temp.question(promptText, (answer) => {
      temp.close();
      resolve(answer);
    });
  });
}

function recoverGatewayPromptInput() {
  try {
    if (typeof process.stdin.setRawMode === 'function' && process.stdin.isRaw) {
      process.stdin.setRawMode(false);
    }
  } catch { /* ignore */ }
  try { process.stdin.resume(); } catch { /* ignore */ }
}

async function withTimeout(promise, ms, label = 'operation') {
  let timer = null;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} timeout after ${ms}ms`)), ms);
    if (timer && typeof timer.unref === 'function') timer.unref();
  });
  try {
    return await Promise.race([promise, timeout]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function isAdapterOperational(status, test, strictOperationalAdapters = STRICT_OPERATIONAL_ADAPTERS) {
  if (!status || !status.enabled || !status.available) return false;
  if (!test?.connectivity?.success) return false;
  const adapterType = String(status.type || '').toLowerCase();
  const strictMode = strictOperationalAdapters.has(adapterType);
  if (strictMode && test?.models) {
    if (!test.models.success) return false;
    if (Number(test.models.count || 0) <= 0) return false;
  }
  if (test?.generation && !test.generation.success) {
    if (!shouldTreatGenerationFailureAsWarning(adapterType)) return false;
    if (strictMode) {
      const reasonText = String(test?.generation?.error || '');
      // For strict adapters, keep auth/install failures blocked.
      // Timeouts are treated as warning to avoid false negatives in fast probe mode.
      if (!_isTimeoutLikeReason(reasonText) || _isAuthOrInstallLikeReason(reasonText)) return false;
    }
  }
  return true;
}

function _resolveEnvPathsForGateway() {
  const fs = require('fs');
  const path = require('path');
  const canonicalPath = process.env.KHY_ENV_FILE
    ? path.resolve(process.env.KHY_ENV_FILE)
    : path.resolve(__dirname, '../../../.env'); // backend/.env
  const mirrorPath = path.resolve(__dirname, '../../../../.env'); // repo root .env
  const syncMirror = String(process.env.KHY_ENV_SYNC_ROOT || 'true').toLowerCase() !== 'false';

  const targets = [canonicalPath];
  if (syncMirror && mirrorPath !== canonicalPath && (fs.existsSync(mirrorPath) || fs.existsSync(canonicalPath))) {
    targets.push(mirrorPath);
  }
  return {
    canonicalPath,
    targets,
  };
}

function _patchEnvContent(content, envMap = {}, unsetKeys = []) {
  let next = String(content || '');
  for (const [key, value] of Object.entries(envMap)) {
    const regex = new RegExp(`^${key}=.*$`, 'm');
    const line = `${key}=${value}`;
    if (regex.test(next)) next = next.replace(regex, line);
    else next = next.trimEnd() + '\n' + line + '\n';
  }
  for (const key of unsetKeys) {
    const regex = new RegExp(`^${key}=.*\\n?`, 'm');
    next = next.replace(regex, '');
  }
  return next;
}

function _writeEnvPatch(envMap = {}, unsetKeys = [], options = {}) {
  const fs = require('fs');
  const path = require('path');
  const resolved = _resolveEnvPathsForGateway();
  const canonicalPath = options.envPath
    ? path.resolve(options.envPath)
    : resolved.canonicalPath;
  const targets = options.envPath ? [canonicalPath] : resolved.targets;

  for (const targetPath of targets) {
    let content = '';
    try { content = fs.readFileSync(targetPath, 'utf-8'); } catch { /* no .env yet */ }
    const patched = _patchEnvContent(content, envMap, unsetKeys);
    fs.writeFileSync(targetPath, patched);
  }

  for (const [key, value] of Object.entries(envMap)) {
    process.env[key] = String(value);
  }
  for (const key of unsetKeys) {
    delete process.env[key];
  }
  return canonicalPath;
}

function persistGatewayPreference(selected) {
  const envMap = {
    GATEWAY_PREFERRED_ADAPTER: selected.adapter,
    GATEWAY_PREFERRED_STRICT: 'true',
  };
  if (selected.model) envMap.GATEWAY_PREFERRED_MODEL = selected.model;
  const unsetKeys = selected.model ? [] : ['GATEWAY_PREFERRED_MODEL'];
  _writeEnvPatch(envMap, unsetKeys);
}

function _resolveEnvPathForGateway() {
  const { canonicalPath } = _resolveEnvPathsForGateway();
  return canonicalPath;
}

function _resolveEnvPathForDiscoverModels() {
  const fs = require('fs');
  const path = require('path');
  const { canonicalPath } = _resolveEnvPathsForGateway();
  const candidates = [
    canonicalPath,
    path.resolve(__dirname, '../../../../.env'),
  ];
  return candidates.find(p => fs.existsSync(p)) || candidates[0];
}

function _writeEnvMap(envMap = {}, options = {}) {
  return _writeEnvPatch(envMap, [], options);
}

function _unsetEnvKeys(keys = [], options = {}) {
  return _writeEnvPatch({}, keys, options);
}

async function handleGatewayTuneLocal(args = [], options = {}) {
  const hw = require('../../services/hardwareProfileService');
  const modeArg = String(args[0] || options.mode || 'auto').trim().toLowerCase();
  const mode = ['auto', 'fast', 'balanced', 'quality'].includes(modeArg) ? modeArg : 'auto';
  const apply = !!options.apply
    || modeArg === 'apply'
    || String(args[1] || '').trim().toLowerCase() === 'apply'
    || String(args[1] || '').trim().toLowerCase() === '--apply'
    || String(args[2] || '').trim().toLowerCase() === '--apply';
  const rec = hw.recommendLocalAiTuning(mode);
  const rows = Object.entries(rec.env).map(([k, v]) => [k, String(v)]);

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('本地 AI 智能调优')}`);
  console.log('');
  printInfo(`硬件画像: ${rec.profile}`);
  printInfo(`推荐档位: ${rec.label} (${rec.mode})`);
  printInfo(`依据: ${rec.reason}`);
  console.log('');
  printTable(['配置项', '推荐值'], rows);
  console.log('');

  if (apply) {
    const envPath = _writeEnvMap(rec.env, {});
    printSuccess(`已写入智能匹配配置: ${envPath}`);
    printInfo('新会话将自动生效；当前进程已更新环境变量');
    console.log('');
    return {
      applied: true,
      mode,
      profile: rec.profile,
      envPath,
      values: rec.env,
    };
  }

  printInfo('预览模式：未写入 .env');
  printInfo('应用命令: khy gateway tune-local ' + mode + ' apply');
  console.log('');
  return {
    applied: false,
    mode,
    profile: rec.profile,
    values: rec.env,
  };
}

async function handleGatewayPreferRemote(options = {}) {
  const silent = !!options.silent;
  const probeOnlyAvailable = !!options.probeOnlyAvailable;
  const logInfo = (...args) => { if (!silent) printInfo(...args); };
  const logError = (...args) => { if (!silent) printError(...args); };
  const logSuccess = (...args) => { if (!silent) printSuccess(...args); };

  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus().filter(s => s.enabled);
  const localTypes = new Set(['localllm', 'ollama']);
  const remoteStatuses = statuses.filter((s) => {
    if (localTypes.has(String(s.type || '').toLowerCase())) return false;
    if (probeOnlyAvailable && !s.available) return false;
    return true;
  });
  if (remoteStatuses.length === 0) {
    logError('未找到远程通道（API/桥接/CLI）');
    logInfo('可运行 khy gateway config 配置 API 或桥接通道');
    return {
      switched: false,
      selected: null,
      reason: 'no-remote-channel',
      tested: 0,
    };
  }

  const requestedProbeTimeoutMs = Number(options.probeTimeoutMs);
  const probeTimeoutDefaultMs = parseInt(process.env.KHY_MODEL_PROBE_TIMEOUT_MS || '8000', 10) || 8000;
  const probeTimeoutBaseMs = Number.isFinite(requestedProbeTimeoutMs) ? requestedProbeTimeoutMs : probeTimeoutDefaultMs;
  const probeTimeoutMs = Math.max(Number.isFinite(requestedProbeTimeoutMs) ? 1000 : 4000, probeTimeoutBaseMs);
  const requestedGenerationProbeTimeoutMs = Number(options.probeGenerationTimeoutMs);
  const generationProbeTimeoutDefaultMs = parseInt(
    process.env.KHY_MODEL_PROBE_GENERATION_TIMEOUT_MS || '25000',
    10
  ) || 25000;
  const generationProbeTimeoutBaseMs = Number.isFinite(requestedGenerationProbeTimeoutMs)
    ? requestedGenerationProbeTimeoutMs
    : generationProbeTimeoutDefaultMs;
  const generationProbeTimeoutMs = Math.max(
    probeTimeoutMs,
    generationProbeTimeoutBaseMs
  );
  logInfo(`探测远程通道可用性（单通道超时 ${Math.round(probeTimeoutMs / 1000)}s）...`);

  const testResults = {};
  await Promise.all(remoteStatuses.map(async (s) => {
    const adapterType = String(s.type || '').toLowerCase();
    const requireGenerationProbe = STRICT_OPERATIONAL_ADAPTERS.has(adapterType);
    try {
      testResults[s.type] = await withTimeout(
        gateway.testAdapter(s.type, {
          quick: !requireGenerationProbe,
          timeoutMs: probeTimeoutMs,
          probeGenerationTimeoutMs: generationProbeTimeoutMs,
        }),
        Math.max(probeTimeoutMs + 1000, generationProbeTimeoutMs + 1000),
        `${s.type} probe`
      );
    } catch (err) {
      testResults[s.type] = {
        connectivity: {
          success: false,
          latencyMs: probeTimeoutMs,
          error: err && err.message ? err.message : 'probe failed',
        },
      };
    }
  }));

  const rankByAdapter = {
    api: 100,
    relay_api: 95,
    cursor2api: 90,
    cli: 85,
    claude: 80,
    codex: 78,
    cursor: 76,
    kiro: 74,
    trae: 72,
    windsurf: 68,
    vscode: 66,
    warp: 64,
    relay: 50,
  };

  const candidates = [];
  for (const s of remoteStatuses) {
    const test = testResults[s.type];
    if (!isAdapterOperational(s, test, STRICT_OPERATIONAL_ADAPTERS)) continue;

    const generationWarn = !!(test?.generation && !test.generation.success && shouldTreatGenerationFailureAsWarning(s.type));
    let selectedModel = null;
    try {
      const models = await withTimeout(gateway.listModels(s.type), Math.max(3000, probeTimeoutMs), `${s.type} listModels`);
      if (Array.isArray(models) && models.length > 0) {
        const preferred = models.find(m => m && m.isDefault) || models[0];
        selectedModel = preferred ? preferred.id : null;
      }
    } catch { /* keep null */ }

    const baseRank = Number(rankByAdapter[s.type] || 40);
    const warnPenalty = generationWarn ? 15 : 0;
    const latencyPenalty = Math.min(20, Math.round((Number(test?.connectivity?.latencyMs || 0) || 0) / 200));
    const score = baseRank - warnPenalty - latencyPenalty;

    candidates.push({
      adapter: s.type,
      model: selectedModel,
      score,
      latencyMs: Number(test?.connectivity?.latencyMs || 0) || 0,
      warn: generationWarn,
      detail: generationWarn ? (test?.generation?.error || 'generation warn') : '',
    });
  }

  if (candidates.length === 0) {
    logError('未找到可用远程通道');
    logInfo('可运行 khy gateway status 查看失败详情，或 khy gateway config 配置 API/桥接');
    return {
      switched: false,
      selected: null,
      reason: 'no-operational-remote',
      tested: remoteStatuses.length,
    };
  }

  candidates.sort((a, b) => b.score - a.score || a.latencyMs - b.latencyMs);
  const selected = candidates[0];
  persistGatewayPreference(selected);
  try { gateway.syncModelSwitch(selected.model || null); } catch { /* best effort */ }
  try { await gateway.refreshAdapters(); } catch { /* best effort */ }

  const tokenInfo = getTokenInfoForSelection(selected);
  const warnText = selected.warn ? `（实测告警: ${selected.detail || 'generation warn'}）` : '';
  logSuccess(`已切换默认远程通道: ${selected.adapter}${selected.model ? ` · ${selected.model}` : ''}`);
  logInfo(`探测得分: ${selected.score} · 延迟: ${selected.latencyMs}ms ${warnText}`);
  logInfo(`Token: ${tokenInfo.source} → ${tokenInfo.detail}`);

  if (options.fromDoctor) {
    logInfo('已根据 doctor 诊断自动避开本地受限通道');
  }

  return {
    switched: true,
    selected,
    tokenInfo,
    tested: remoteStatuses.length,
    reason: 'switched',
  };
}

/**
 * Display status of all gateway adapters with live connectivity test.
 */
async function handleGatewayStatus() {
  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus();

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('AI 网关状态')}`);
  console.log(chalk.dim('  正在检测各通道连通性...'));
  console.log('');

  // Run connectivity tests in parallel for enabled+available adapters
  const testPromises = {};
  for (const s of statuses) {
    if (s.enabled && s.available) {
      testPromises[s.type] = gateway.testAdapter(s.type).catch(() => null);
    }
  }
  const testResults = {};
  for (const [key, promise] of Object.entries(testPromises)) {
    testResults[key] = await promise;
  }

  const effectiveStatuses = statuses.map(s => {
    const test = testResults[s.type];
    if (s.enabled && s.available && test?.connectivity && !test.connectivity.success) {
      const reason = test.connectivity.error || 'connectivity failed';
      return {
        ...s,
        available: false,
        detail: `${s.detail}（连通失败: ${reason}）`,
      };
    }
    if (s.enabled && s.available && test?.generation && !test.generation.success) {
      if (shouldTreatGenerationFailureAsWarning(s.type)) {
        const reason = test.generation.error || 'generation probe failed';
        return {
          ...s,
          available: true,
          detail: `${s.detail}（实测告警: ${reason}）`,
        };
      }
      const reason = test.generation.error || 'generation probe failed';
      return {
        ...s,
        available: false,
        detail: `${s.detail}（实测不可用: ${reason}）`,
      };
    }
    return s;
  });

  printTable(
    ['优先级', '适配器', '类型', '状态', '连通', '详情'],
    effectiveStatuses.map(s => {
      const test = testResults[s.type];
      let connCol = chalk.dim('—');
      if (!s.enabled) {
        connCol = chalk.dim('已禁用');
      } else if (!s.available) {
        if (test?.generation && !test.generation.success) {
          connCol = chalk.red(`● ${test.generation.error || 'generation failed'}`);
        } else {
          connCol = chalk.dim('—');
        }
      } else if (test) {
        if (test.connectivity?.success) {
          const ms = test.connectivity.latencyMs;
          const modelOk = test.models?.success;
          const generationFail = test.generation && !test.generation.success;
          if (generationFail) {
            connCol = chalk.red(`● ${test.generation.error || 'generation failed'}`);
          } else if (modelOk) {
            connCol = chalk.green(`● ${ms}ms (${test.models.count} models)`);
          } else if (test.models) {
            connCol = chalk.yellow(`● ${ms}ms (models: ${test.models.error})`);
          } else {
            connCol = chalk.green(`● ${ms}ms`);
          }
        } else {
          connCol = chalk.red(`● ${test.connectivity?.error || 'failed'}`);
        }
      }
      return [
        String(s.priority),
        s.name,
        s.type,
        s.enabled
          ? (s.available ? chalk.green('✓ 可用') : chalk.yellow('⚠ 不可用'))
          : chalk.dim('已禁用'),
        connCol,
        s.detail,
      ];
    })
  );

  // Keep the "active channel" consistent with effective availability shown above.
  const activeEntry = effectiveStatuses.find(s => s.enabled && s.available);
  const active = activeEntry ? { name: activeEntry.name, type: activeEntry.type } : null;
  if (active) {
    console.log('');
    printSuccess(`当前活跃通道: ${active.name} (${active.type})`);
  } else {
    console.log('');
    printInfo('无活跃通道 — 可用 khy gateway relay 启动 Web 中转');
  }
  console.log('');
}

/**
 * Interactive gateway configuration.
 */
async function handleGatewayConfig() {
  const inquirer = require('inquirer');

  const { action } = await inquirer.prompt([{
    type: 'list',
    name: 'action',
    message: '网关配置:',
    choices: [
      { name: '设置 CLI 工具桥接 (开/关)', value: 'cli-toggle' },
      { name: '配置 Ollama 本地模型', value: 'ollama-config' },
      { name: '配置 API 中转 (Claude/GPT 中转站)', value: 'relay-api' },
      { name: '配置模型厂商 API Key (DeepSeek/Qwen/GLM/豆包等)', value: 'provider-keys' },
      { name: '高级: 模型路由规则 (GATEWAY_MODEL_ROUTE_MAP)', value: 'routing-policy' },
      { name: '高级: Key 选择策略 (GATEWAY_KEY_SELECTION_STRATEGY)', value: 'key-strategy' },
      { name: '高级: API 池默认 provider (GATEWAY_API_POOL_PROVIDER)', value: 'api-pool-default' },
      { name: '高级: 供应商映射 (alias/service/default-model)', value: 'api-provider-map' },
      { name: '设置 Web 中转端口', value: 'relay-port' },
      { name: '设置中转超时时间', value: 'relay-timeout' },
      { name: '↩️  返回', value: 'back' },
    ],
  }]);

  if (action === 'back') return;

  function setEnvVar(key, value) {
    _writeEnvMap({ [key]: String(value) });
  }
  function unsetEnvVar(key) {
    _unsetEnvKeys([key]);
  }

  if (action === 'cli-toggle') {
    const current = process.env.GATEWAY_CLI_ENABLED !== 'false';
    const { enabled } = await inquirer.prompt([{
      type: 'confirm',
      name: 'enabled',
      message: `CLI 工具桥接当前${current ? '已开启' : '已关闭'}，是否开启?`,
      default: true,
    }]);
    setEnvVar('GATEWAY_CLI_ENABLED', enabled);
    printSuccess(`CLI 工具桥接已${enabled ? '开启' : '关闭'}`);
  }

  if (action === 'ollama-config') {
    const ollamaAdapter = require('../../services/gateway/adapters/ollamaAdapter');
    const available = ollamaAdapter.detect(true); // force refresh
    const models = ollamaAdapter.getModels();

    if (!available) {
      printError('Ollama 服务未运行');
      printInfo('安装: https://ollama.com');
      printInfo('启动: ollama serve');
      printInfo('拉取模型: ollama pull qwen2.5:7b');
      return;
    }

    printSuccess(`Ollama 运行中，${models.length} 个模型可用`);

    if (models.length > 0) {
      const { model } = await inquirer.prompt([{
        type: 'list',
        name: 'model',
        message: '选择默认模型:',
        choices: models.map(m => ({ name: m, value: m })),
        default: process.env.OLLAMA_MODEL || 'qwen2.5:7b',
      }]);
      setEnvVar('OLLAMA_MODEL', model);
      printSuccess(`默认模型已设为 ${model}`);
    }

    const { host } = await inquirer.prompt([{
      type: 'input',
      name: 'host',
      message: 'Ollama 地址:',
      default: process.env.OLLAMA_HOST || 'http://localhost:11434',
    }]);
    if (host !== 'http://localhost:11434') {
      setEnvVar('OLLAMA_HOST', host);
      printSuccess(`Ollama 地址已设为 ${host}`);
    }
    return;
  }

  if (action === 'relay-api') {
    const chalk = require('chalk').default || require('chalk');
    const currentEndpoint = process.env.RELAY_API_ENDPOINT || '';
    const currentKey = process.env.RELAY_API_KEY || '';
    const currentModel = process.env.RELAY_API_MODEL || 'claude-sonnet-4-20250514';

    if (currentEndpoint) {
      console.log(chalk.dim(`  当前: ${currentEndpoint} / ${currentModel}`));
    }

    const { endpoint } = await inquirer.prompt([{
      type: 'input',
      name: 'endpoint',
      message: '中转 API 地址 (OpenAI 兼容格式):',
      default: currentEndpoint || 'https://api.example.com/v1',
      validate: v => v.startsWith('http') ? true : '请输入完整 URL (https://...)',
    }]);

    const { key } = await inquirer.prompt([{
      type: 'password',
      name: 'key',
      message: 'API Key:',
      mask: '*',
      default: currentKey,
      validate: v => v.length > 0 ? true : '请输入 API Key',
    }]);

    const { model } = await inquirer.prompt([{
      type: 'input',
      name: 'model',
      message: '模型名称:',
      default: currentModel,
    }]);

    setEnvVar('RELAY_API_ENDPOINT', endpoint);
    setEnvVar('RELAY_API_KEY', key);
    setEnvVar('RELAY_API_MODEL', model);

    printSuccess(`API 中转已配置: ${endpoint}`);
    printInfo(`模型: ${model}`);

    // Test connection
    const { test } = await inquirer.prompt([{
      type: 'confirm',
      name: 'test',
      message: '是否测试连接?',
      default: true,
    }]);

    if (test) {
      printInfo('测试中...');
      try {
        const relayAdapter = require('../../services/gateway/adapters/relayApiAdapter');
        relayAdapter.detect(true);
        const result = await relayAdapter.generate('Say "hello" in one word.', { maxTokens: 10 });
        if (result.success) {
          printSuccess(`连接成功! 响应: "${result.content.slice(0, 50)}" (${result.provider})`);
        } else {
          printError(`连接失败: ${result.error}`);
        }
      } catch (e) {
        printError(`测试错误: ${e.message}`);
      }
    }
    return;
  }

  if (action === 'provider-keys') {
    const pool = require('../../services/apiKeyPool');
    pool.init();

    const PROVIDERS = [
      { name: 'DeepSeek', poolKey: 'deepseek', envKey: 'DEEPSEEK_API_KEY', envEndpoint: 'DEEPSEEK_API_ENDPOINT', defaultEndpoint: 'https://api.deepseek.com/v1', models: ['deepseek-chat', 'deepseek-coder', 'deepseek-reasoner'] },
      { name: '通义千问 (Qwen)', poolKey: 'qwen', envKey: 'QWEN_API_KEY', envEndpoint: 'QWEN_API_ENDPOINT', defaultEndpoint: 'https://dashscope.aliyuncs.com/compatible-mode/v1', models: ['qwen-turbo', 'qwen-plus', 'qwen-max'] },
      { name: '智谱 GLM', poolKey: 'glm', envKey: 'GLM_API_KEY', envEndpoint: 'GLM_API_ENDPOINT', defaultEndpoint: 'https://open.bigmodel.cn/api/paas/v4', models: ['glm-4', 'glm-4-flash', 'glm-4-air'] },
      { name: '豆包 (Doubao)', poolKey: 'doubao', envKey: 'DOUBAO_API_KEY', envEndpoint: 'DOUBAO_API_ENDPOINT', defaultEndpoint: 'https://ark.cn-beijing.volces.com/api/v3', models: ['doubao-pro-32k', 'doubao-lite-32k'] },
      { name: '百度文心', poolKey: 'wenxin', envKey: 'WENXIN_API_KEY', envEndpoint: 'WENXIN_API_ENDPOINT', defaultEndpoint: 'https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop', models: ['ernie-4.0', 'ernie-speed'] },
      { name: 'OpenAI', poolKey: 'openai', envKey: 'OPENAI_API_KEY', envEndpoint: 'OPENAI_API_ENDPOINT', defaultEndpoint: 'https://api.openai.com/v1', models: ['gpt-4o', 'gpt-4o-mini', 'o1-mini'] },
      { name: 'Anthropic (Claude)', poolKey: 'anthropic', envKey: 'ANTHROPIC_API_KEY', envEndpoint: 'ANTHROPIC_API_ENDPOINT', defaultEndpoint: 'https://api.anthropic.com/v1', models: ['claude-sonnet-4-20250514', 'claude-3-5-haiku-20241022'] },
      { name: 'Trae API', poolKey: 'trae', envKey: 'TRAE_API_KEY', envEndpoint: 'TRAE_API_ENDPOINT', defaultEndpoint: 'https://api.trae.ai/v1', models: ['gpt-4o', 'claude-3.5-sonnet', 'deepseek-v3', 'doubao-1.5-pro'] },
      { name: 'HuggingFace', poolKey: null, envKey: 'HF_TOKEN', envEndpoint: null, defaultEndpoint: null, models: [], isToken: true },
      { name: 'Relay (中转站)', poolKey: 'relay', envKey: 'RELAY_API_KEY', envEndpoint: 'RELAY_API_ENDPOINT', defaultEndpoint: '', models: [] },
    ];

    // Show current pool status
    console.log('');
    console.log(chalk.cyan.bold('  API Key 池管理'));
    console.log('');
    for (const p of PROVIDERS) {
      if (p.poolKey) {
        const status = pool.getPoolStatus(p.poolKey);
        if (status.length > 0) {
          console.log(`  ${chalk.white(p.name)} ${chalk.dim(`(${status.length} keys)`)}`);
          for (const s of status) {
            const icon = s.status === 'active' ? chalk.green('●')
              : s.status === 'cooldown' ? chalk.yellow('○')
              : chalk.red('○');
            const cooldown = s.cooldownRemaining > 0 ? chalk.yellow(` ⏳${s.cooldownRemaining}s`) : '';
            console.log(`    ${icon} ${chalk.dim(s.keyPreview)}  ${s.label || ''}  P:${s.priority}  ${chalk.dim(`${s.totalRequests} req`)}${cooldown}`);
          }
        } else {
          const hasEnv = !!process.env[p.envKey];
          const icon = hasEnv ? chalk.green('●') : chalk.dim('○');
          console.log(`  ${icon} ${chalk.white(p.name)}${hasEnv ? chalk.dim(` (env)`) : ''}`);
        }
      } else {
        const hasKey = !!process.env[p.envKey];
        const icon = hasKey ? chalk.green('●') : chalk.dim('○');
        console.log(`  ${icon} ${chalk.white(p.name)}${hasKey ? chalk.dim(` (${process.env[p.envKey].slice(0, 6)}...)`) : ''}`);
      }
    }
    console.log('');

    const { providerAction } = await inquirer.prompt([{
      type: 'list',
      name: 'providerAction',
      message: '操作:',
      choices: [
        { name: '添加 API Key', value: 'add' },
        { name: '移除 API Key', value: 'remove' },
        { name: '查看 Key 池详情', value: 'status' },
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (providerAction === 'back') return;

    if (providerAction === 'add') {
      const { provider } = await inquirer.prompt([{
        type: 'list',
        name: 'provider',
        message: '选择厂商:',
        choices: [
          ...PROVIDERS.map(p => ({ name: p.name, value: p })),
          { name: '↩️  返回', value: null },
        ],
      }]);

      if (!provider) return;

      const { key } = await inquirer.prompt([{
        type: 'password',
        name: 'key',
        message: `${provider.name} API Key:`,
        mask: '*',
        validate: v => v.length > 0 ? true : '请输入 API Key',
      }]);

      // HuggingFace: token only, save to env
      if (provider.isToken) {
        setEnvVar(provider.envKey, key);
        printSuccess(`${provider.name} Token 已保存`);
        return;
      }

      // Endpoint
      let keyEndpoint = provider.defaultEndpoint;
      const { useDefault } = await inquirer.prompt([{
        type: 'confirm',
        name: 'useDefault',
        message: `使用默认地址 (${provider.defaultEndpoint || '无'})？`,
        default: true,
      }]);
      if (!useDefault) {
        const { ep } = await inquirer.prompt([{
          type: 'input',
          name: 'ep',
          message: 'API 地址:',
          default: provider.defaultEndpoint,
        }]);
        keyEndpoint = ep;
      }

      // Priority
      const { priority } = await inquirer.prompt([{
        type: 'input',
        name: 'priority',
        message: '优先级 (数字越大越优先, 0=默认):',
        default: '10',
        validate: v => /^\d+$/.test(v) ? true : '请输入数字',
      }]);

      // Label
      const { label } = await inquirer.prompt([{
        type: 'input',
        name: 'label',
        message: '标签 (可选, 如 "付费号"):',
        default: '',
      }]);

      if (provider.poolKey) {
        try {
          pool.addKey(provider.poolKey, {
            key,
            endpoint: keyEndpoint,
            priority: parseInt(priority, 10),
            label,
          });
          printSuccess(`已添加到 ${provider.name} Key 池`);
        } catch (e) {
          printError(e.message);
        }
      }

      // Also set as RELAY_API for gateway compatibility (first key)
      setEnvVar(provider.envKey, key);
      if (provider.envEndpoint && keyEndpoint) {
        setEnvVar(provider.envEndpoint, keyEndpoint);
      }

      // Model selection for non-relay providers
      if (provider.models.length > 0) {
        const { model } = await inquirer.prompt([{
          type: 'list',
          name: 'model',
          message: '选择默认模型:',
          choices: provider.models,
        }]);
        setEnvVar('RELAY_API_ENDPOINT', keyEndpoint);
        setEnvVar('RELAY_API_KEY', key);
        setEnvVar('RELAY_API_MODEL', model);
        printSuccess(`${provider.name} 已配置: ${model}`);
      }
    }

    if (providerAction === 'remove') {
      const allStatus = pool.getAllStatus();
      const removeChoices = [];
      for (const [prov, keys] of Object.entries(allStatus)) {
        for (const k of keys) {
          removeChoices.push({
            name: `${prov} · ${k.keyPreview} · ${k.label || '无标签'} · P:${k.priority}`,
            value: { provider: prov, keyId: k.keyId },
          });
        }
      }
      if (removeChoices.length === 0) {
        printInfo('Key 池为空');
        return;
      }
      const { toRemove } = await inquirer.prompt([{
        type: 'list',
        name: 'toRemove',
        message: '选择要移除的 Key:',
        choices: [...removeChoices, { name: '↩️  返回', value: null }],
      }]);
      if (toRemove) {
        pool.removeKey(toRemove.provider, toRemove.keyId);
        printSuccess('已移除');
      }
    }

    if (providerAction === 'status') {
      const allStatus = pool.getAllStatus();
      if (Object.keys(allStatus).length === 0) {
        printInfo('Key 池为空。使用「添加 API Key」开始配置');
        return;
      }
      console.log('');
      for (const [prov, keys] of Object.entries(allStatus)) {
        console.log(chalk.cyan(`  ${prov} (${keys.length} keys)`));
        for (const k of keys) {
          const icon = k.status === 'active' ? chalk.green('●')
            : k.status === 'cooldown' ? chalk.yellow('○')
            : chalk.red('○');
          const cooldown = k.cooldownRemaining > 0 ? chalk.yellow(` ⏳ ${k.cooldownRemaining}s`) : '';
          const error = k.lastError ? chalk.red(` · ${k.lastError.slice(0, 40)}`) : '';
          console.log(`    ${icon} ${chalk.dim(k.keyPreview)}  ${k.label || ''}  P:${k.priority}  ${chalk.dim(`✓ ${k.totalRequests} req · ✗ ${k.totalFailures} fail`)}${cooldown}${error}`);
        }
        console.log('');
      }
    }
    return;
  }

  if (action === 'routing-policy') {
    const routeMap = _parseJsonObject(process.env.GATEWAY_MODEL_ROUTE_MAP, {});
    const routeEntries = Object.entries(routeMap);
    const strictDefault = String(process.env.GATEWAY_MODEL_ROUTE_STRICT || 'false').toLowerCase() === 'true';

    console.log('');
    console.log(chalk.cyan.bold('  模型路由策略'));
    console.log(chalk.dim(`  strict 默认值: ${strictDefault ? 'true' : 'false'}`));
    if (routeEntries.length === 0) {
      console.log(chalk.dim('  当前无路由规则'));
    } else {
      for (const [pattern, target] of routeEntries) {
        if (target && typeof target === 'object') {
          console.log(`  ${chalk.green(pattern)} -> ${chalk.white(target.target || '')} ${chalk.dim(`(strict=${target.strict === true ? 'true' : 'false'})`)}`);
        } else {
          console.log(`  ${chalk.green(pattern)} -> ${chalk.white(String(target || ''))}`);
        }
      }
    }
    console.log('');

    const { policyAction } = await inquirer.prompt([{
      type: 'list',
      name: 'policyAction',
      message: '操作:',
      choices: [
        { name: '新增/更新规则', value: 'set' },
        { name: '移除规则', value: 'remove' },
        { name: '清空所有规则', value: 'clear' },
        { name: '设置 strict 默认值', value: 'strict' },
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (policyAction === 'back') return;
    if (policyAction === 'set') {
      const { pattern, target, strictMode } = await inquirer.prompt([
        {
          type: 'input',
          name: 'pattern',
          message: '匹配规则 (例: gpt-4o-mini 或 claude-*):',
          validate: v => String(v || '').trim() ? true : '请输入匹配规则',
        },
        {
          type: 'input',
          name: 'target',
          message: '目标路由 (例: api/openai:gpt-4o-mini 或 kiro/claude-sonnet-4):',
          validate: v => String(v || '').trim() ? true : '请输入目标路由',
        },
        {
          type: 'list',
          name: 'strictMode',
          message: 'strict 行为:',
          choices: [
            { name: '继承默认值', value: 'inherit' },
            { name: '强制 strict=true', value: 'true' },
            { name: '强制 strict=false', value: 'false' },
          ],
          default: 'inherit',
        },
      ]);
      if (strictMode === 'inherit') {
        routeMap[String(pattern).trim()] = String(target).trim();
      } else {
        routeMap[String(pattern).trim()] = {
          target: String(target).trim(),
          strict: strictMode === 'true',
        };
      }
      setEnvVar('GATEWAY_MODEL_ROUTE_MAP', _safeJsonLine(routeMap));
      printSuccess('模型路由规则已更新');
      return;
    }

    if (policyAction === 'remove') {
      const keys = Object.keys(routeMap);
      if (keys.length === 0) {
        printInfo('当前无规则可移除');
        return;
      }
      const { toRemove } = await inquirer.prompt([{
        type: 'list',
        name: 'toRemove',
        message: '选择要移除的规则:',
        choices: [...keys.map(k => ({ name: k, value: k })), { name: '↩️  返回', value: null }],
      }]);
      if (!toRemove) return;
      delete routeMap[toRemove];
      if (Object.keys(routeMap).length === 0) {
        unsetEnvVar('GATEWAY_MODEL_ROUTE_MAP');
      } else {
        setEnvVar('GATEWAY_MODEL_ROUTE_MAP', _safeJsonLine(routeMap));
      }
      printSuccess(`已移除规则: ${toRemove}`);
      return;
    }

    if (policyAction === 'clear') {
      const { confirmClear } = await inquirer.prompt([{
        type: 'confirm',
        name: 'confirmClear',
        message: '确认清空全部模型路由规则?',
        default: false,
      }]);
      if (!confirmClear) return;
      unsetEnvVar('GATEWAY_MODEL_ROUTE_MAP');
      printSuccess('已清空模型路由规则');
      return;
    }

    if (policyAction === 'strict') {
      const { strictOn } = await inquirer.prompt([{
        type: 'confirm',
        name: 'strictOn',
        message: '当规则未显式指定 strict 时，是否默认 strict=true?',
        default: strictDefault,
      }]);
      setEnvVar('GATEWAY_MODEL_ROUTE_STRICT', strictOn ? 'true' : 'false');
      printSuccess(`已设置 GATEWAY_MODEL_ROUTE_STRICT=${strictOn ? 'true' : 'false'}`);
      return;
    }
  }

  if (action === 'key-strategy') {
    const currentStrategy = String(process.env.GATEWAY_KEY_SELECTION_STRATEGY || 'round-robin').trim().toLowerCase();
    const currentStrategyMap = _parseJsonObject(process.env.GATEWAY_KEY_SELECTION_STRATEGY_MAP, {});

    const { strategy } = await inquirer.prompt([{
      type: 'list',
      name: 'strategy',
      message: '全局 Key 选择策略:',
      choices: KEY_SELECTION_STRATEGY_CHOICES,
      default: KEY_SELECTION_STRATEGY_CHOICES.some(c => c.value === currentStrategy) ? currentStrategy : 'round-robin',
    }]);
    setEnvVar('GATEWAY_KEY_SELECTION_STRATEGY', strategy);

    let nextMap = { ...currentStrategyMap };
    while (true) {
      const providerCount = Object.keys(nextMap).length;
      const { op } = await inquirer.prompt([{
        type: 'list',
        name: 'op',
        message: `Provider 覆盖策略 (${providerCount} 条):`,
        choices: [
          { name: '新增/更新覆盖', value: 'set' },
          { name: '移除覆盖', value: 'remove' },
          { name: '清空覆盖', value: 'clear' },
          { name: '完成', value: 'done' },
        ],
      }]);

      if (op === 'done') break;
      if (op === 'clear') {
        nextMap = {};
        continue;
      }
      if (op === 'remove') {
        const keys = Object.keys(nextMap);
        if (keys.length === 0) {
          printInfo('当前无覆盖项可移除');
          continue;
        }
        const { key } = await inquirer.prompt([{
          type: 'list',
          name: 'key',
          message: '选择要移除的 provider:',
          choices: [...keys.map(k => ({ name: `${k} => ${nextMap[k]}`, value: k })), { name: '↩️  返回', value: null }],
        }]);
        if (!key) continue;
        delete nextMap[key];
        continue;
      }

      if (op === 'set') {
        const { providerChoice } = await inquirer.prompt([{
          type: 'list',
          name: 'providerChoice',
          message: '选择 provider:',
          choices: [
            ...API_POOL_PROVIDER_KEYS.map(k => ({ name: k, value: k })),
            { name: '自定义 provider', value: '__custom__' },
            { name: '↩️  返回', value: null },
          ],
        }]);
        if (!providerChoice) continue;
        let providerKey = providerChoice;
        if (providerChoice === '__custom__') {
          const { customProvider } = await inquirer.prompt([{
            type: 'input',
            name: 'customProvider',
            message: '输入 provider 名称:',
            validate: v => String(v || '').trim() ? true : '请输入 provider',
          }]);
          providerKey = String(customProvider).trim().toLowerCase();
        }
        const { providerStrategy } = await inquirer.prompt([{
          type: 'list',
          name: 'providerStrategy',
          message: `${providerKey} 的策略:`,
          choices: KEY_SELECTION_STRATEGY_CHOICES,
          default: KEY_SELECTION_STRATEGY_CHOICES.some(c => c.value === String(nextMap[providerKey] || strategy))
            ? String(nextMap[providerKey] || strategy)
            : 'round-robin',
        }]);
        nextMap[providerKey] = providerStrategy;
      }
    }

    if (Object.keys(nextMap).length === 0) {
      unsetEnvVar('GATEWAY_KEY_SELECTION_STRATEGY_MAP');
    } else {
      setEnvVar('GATEWAY_KEY_SELECTION_STRATEGY_MAP', _safeJsonLine(nextMap));
    }
    printSuccess(`Key 选择策略已更新: ${strategy}`);
    if (Object.keys(nextMap).length > 0) {
      printInfo(`Provider 覆盖: ${_safeJsonLine(nextMap)}`);
    } else {
      printInfo('Provider 覆盖: 无');
    }
    return;
  }

  if (action === 'api-pool-default') {
    const current = String(process.env.GATEWAY_API_POOL_PROVIDER || '').trim().toLowerCase();
    const { provider } = await inquirer.prompt([{
      type: 'list',
      name: 'provider',
      message: 'API 适配器默认池 provider（未指定 model/provider 时生效）:',
      choices: [
        { name: '自动推断（默认）', value: '' },
        ...API_POOL_PROVIDER_KEYS.map(k => ({ name: k, value: k })),
      ],
      default: (current && API_POOL_PROVIDER_KEYS.includes(current)) ? current : '',
    }]);

    if (!provider) {
      unsetEnvVar('GATEWAY_API_POOL_PROVIDER');
      printSuccess('已恢复自动推断 provider');
    } else {
      setEnvVar('GATEWAY_API_POOL_PROVIDER', provider);
      printSuccess(`默认 provider 已设为 ${provider}`);
    }
    return;
  }

  if (action === 'api-provider-map') {
    const MAP_PRESETS = [
      {
        envKey: 'GATEWAY_API_POOL_PROVIDER_ALIAS_MAP',
        title: 'Alias 映射',
        keyHint: '别名',
        valueHint: '池 provider（如 deepseek/qwen/glm/openai）',
      },
      {
        envKey: 'GATEWAY_API_POOL_SERVICE_MAP',
        title: '池 -> 服务映射',
        keyHint: '池 provider',
        valueHint: '服务 provider（MultiFreeService key，如 openai/alibaba/zhipu/baidu）',
      },
      {
        envKey: 'GATEWAY_API_POOL_DEFAULT_MODEL_MAP',
        title: '池默认模型映射',
        keyHint: '池 provider',
        valueHint: '默认模型（如 deepseek-chat / qwen-plus）',
      },
    ];

    const { preset } = await inquirer.prompt([{
      type: 'list',
      name: 'preset',
      message: '选择映射类型:',
      choices: [
        ...MAP_PRESETS.map(p => ({ name: `${p.title} (${p.envKey})`, value: p })),
        { name: '↩️  返回', value: null },
      ],
    }]);
    if (!preset) return;

    const nextMap = _parseJsonObject(process.env[preset.envKey], {});
    while (true) {
      const rows = Object.entries(nextMap);
      console.log('');
      console.log(chalk.cyan.bold(`  ${preset.title}`));
      if (rows.length === 0) {
        console.log(chalk.dim('  当前为空'));
      } else {
        for (const [k, v] of rows) {
          console.log(`  ${chalk.green(k)} => ${chalk.white(String(v))}`);
        }
      }
      console.log('');

      const { op } = await inquirer.prompt([{
        type: 'list',
        name: 'op',
        message: '操作:',
        choices: [
          { name: '新增/更新', value: 'set' },
          { name: '移除', value: 'remove' },
          { name: '清空', value: 'clear' },
          { name: '完成', value: 'done' },
        ],
      }]);

      if (op === 'done') break;
      if (op === 'clear') {
        Object.keys(nextMap).forEach(k => { delete nextMap[k]; });
        continue;
      }
      if (op === 'remove') {
        const keys = Object.keys(nextMap);
        if (keys.length === 0) {
          printInfo('当前无可移除项');
          continue;
        }
        const { key } = await inquirer.prompt([{
          type: 'list',
          name: 'key',
          message: '选择要移除的键:',
          choices: [...keys.map(k => ({ name: k, value: k })), { name: '↩️  返回', value: null }],
        }]);
        if (!key) continue;
        delete nextMap[key];
        continue;
      }
      if (op === 'set') {
        const { mapKey, mapValue } = await inquirer.prompt([
          {
            type: 'input',
            name: 'mapKey',
            message: `${preset.keyHint}:`,
            validate: v => String(v || '').trim() ? true : '请输入 key',
          },
          {
            type: 'input',
            name: 'mapValue',
            message: `${preset.valueHint}:`,
            validate: v => String(v || '').trim() ? true : '请输入 value',
          },
        ]);
        nextMap[String(mapKey).trim().toLowerCase()] = String(mapValue).trim();
      }
    }

    if (Object.keys(nextMap).length === 0) {
      unsetEnvVar(preset.envKey);
      printSuccess(`已清空 ${preset.envKey}`);
    } else {
      setEnvVar(preset.envKey, _safeJsonLine(nextMap));
      printSuccess(`已更新 ${preset.envKey}`);
      printInfo(_safeJsonLine(nextMap));
    }
    return;
  }

  if (action === 'relay-port') {
    const { port } = await inquirer.prompt([{
      type: 'input',
      name: 'port',
      message: '中转服务端口:',
      default: process.env.GATEWAY_RELAY_PORT || '9099',
      validate: v => /^\d+$/.test(v) ? true : '请输入数字',
    }]);
    setEnvVar('GATEWAY_RELAY_PORT', port);
    printSuccess(`中转端口已设为 ${port}`);
    printInfo('重启中转服务后生效');
  }

  if (action === 'relay-timeout') {
    const { minutes } = await inquirer.prompt([{
      type: 'input',
      name: 'minutes',
      message: '中转超时 (分钟):',
      default: String(Math.round((parseInt(process.env.GATEWAY_RELAY_TIMEOUT, 10) || 600000) / 60000)),
      validate: v => /^\d+$/.test(v) ? true : '请输入数字',
    }]);
    setEnvVar('GATEWAY_RELAY_TIMEOUT', parseInt(minutes, 10) * 60000);
    printSuccess(`中转超时已设为 ${minutes} 分钟`);
  }
}

/**
 * Select AI model from available adapters (with connectivity indicators).
 */
async function handleGatewaySelectModel(args = [], options = {}) {
  try {
    const gateway = require('../../services/gateway/aiGateway');
    if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus();
  const enabledAdapters = statuses.filter(s => s.enabled);

  if (enabledAdapters.length === 0) {
    printError('无已启用 AI 通道');
    return;
  }

  const windsurfStatus = statuses.find(s => String(s.type || '').toLowerCase() === 'windsurf');
  if (windsurfStatus && windsurfStatus.tokenPath) {
    printInfo(`Windsurf token 位置: ${windsurfStatus.tokenPath}`);
    const official = windsurfStatus.officialModels || null;
    if (official) {
      if (official.hit) {
        const endpointLabel = official.endpoint ? ` (${official.endpoint})` : '';
        printInfo(`Windsurf 官方模型列表: 已命中${endpointLabel} · 官方 ${official.officialCount} / 本地 ${official.localCount} / 合并 ${official.mergedCount}`);
      } else {
        const reason = String(official.error || '').trim();
        printInfo(`Windsurf 官方模型列表: 未命中${reason ? ` (${reason})` : '（已回退本地发现）'}`);
      }
    }
  }

  // Fast probe for model-selection UX.
  // For unstable-prone adapters, include a lightweight generation probe
  // to avoid "detected but unusable" false positives in /model.
  const probeTimeoutMs = Math.max(
    4000,
    parseInt(process.env.KHY_MODEL_PROBE_TIMEOUT_MS || '8000', 10) || 8000,
  );
  const generationProbeTimeoutMs = Math.max(
    probeTimeoutMs,
    parseInt(process.env.KHY_MODEL_PROBE_GENERATION_TIMEOUT_MS || '25000', 10) || 25000,
  );
  const strictOperationalAdapters = STRICT_OPERATIONAL_ADAPTERS;
  const twoPhaseProbeEnabled = String(process.env.KHY_MODEL_TWO_PHASE_PROBE || 'true').toLowerCase() !== 'false';
  printInfo(`检测各通道连通性（快速模式，单通道超时 ${Math.round(probeTimeoutMs / 1000)}s）...`);
  const testResults = {};
  const strictCandidates = [];
  const testPromises = enabledAdapters.map(async (s) => {
    const adapterType = String(s.type || '').toLowerCase();
    const requireGenerationProbe = strictOperationalAdapters.has(adapterType);
    if (requireGenerationProbe) strictCandidates.push(s);
    try {
      testResults[s.type] = await withTimeout(
        gateway.testAdapter(s.type, {
          quick: twoPhaseProbeEnabled ? true : !requireGenerationProbe,
          timeoutMs: probeTimeoutMs,
          probeGenerationTimeoutMs: generationProbeTimeoutMs,
        }),
        Math.max(probeTimeoutMs + 1000, generationProbeTimeoutMs + 1000),
        `${s.type} probe`,
      );
    } catch (err) {
      testResults[s.type] = {
        connectivity: {
          success: false,
          latencyMs: probeTimeoutMs,
          error: err && err.message ? err.message : 'probe failed',
        },
      };
    }
  });
  await Promise.all(testPromises);

  let backgroundDeepProbeStarted = 0;
  if (twoPhaseProbeEnabled && strictCandidates.length > 0) {
    for (const s of strictCandidates) {
      const adapterType = String(s.type || '').toLowerCase();
      const cached = _getDeepProbeCache(adapterType);
      if (cached && cached.test && cached.test.generation) {
        testResults[s.type] = {
          ...(testResults[s.type] || {}),
          generation: cached.test.generation,
        };
        continue;
      }
      if (_modelDeepProbeInFlight.has(adapterType)) continue;
      backgroundDeepProbeStarted += 1;
      const deepTask = (async () => {
        try {
          const deep = await withTimeout(
            gateway.testAdapter(s.type, {
              quick: false,
              timeoutMs: probeTimeoutMs,
              probeGenerationTimeoutMs: generationProbeTimeoutMs,
            }),
            Math.max(probeTimeoutMs + 3000, generationProbeTimeoutMs + 3000),
            `${s.type} deep-probe`,
          );
          _setDeepProbeCache(adapterType, deep);
        } catch (err) {
          _setDeepProbeCache(adapterType, {
            connectivity: { success: false, error: err && err.message ? err.message : 'deep probe failed' },
            generation: { success: false, error: err && err.message ? err.message : 'deep probe failed' },
          });
        } finally {
          _modelDeepProbeInFlight.delete(adapterType);
        }
      })();
      _modelDeepProbeInFlight.set(adapterType, deepTask);
      deepTask.catch(() => {});
    }
  }

// Collect models from all available adapters with indicators
  const modelChoices = [];
  let skippedUnavailableAdapters = 0;
  const hiddenAdapters = [];
  let generationWarnCount = 0;
  for (const s of enabledAdapters) {
    const test = testResults[s.type];
    const adapterOk = isAdapterOperational(s, test);
    if (!adapterOk) {
      skippedUnavailableAdapters += 1;
      hiddenAdapters.push({
        name: s.name || s.type,
        type: s.type,
        reason: _classifyHiddenReason(s, test),
      });
      continue;
    }
    const generationWarn = !!(test?.generation && !test.generation.success && shouldTreatGenerationFailureAsWarning(s.type));
    if (generationWarn) generationWarnCount += 1;
    const indicator = generationWarn
      ? chalk.yellow(`● ${test.generation.error || '实测告警'}`)
      : chalk.green(`● ${test.connectivity.latencyMs}ms`);
    const statusTag = generationWarn ? chalk.yellow('[可用-告警]') : chalk.green('[可用]');

    try {
      const models = await withTimeout(
        gateway.listModels(s.type),
        Math.max(3000, probeTimeoutMs),
        `${s.type} listModels`,
      );
      if (models && models.length > 0) {
        for (const m of models) {
          const sourceTag = _formatModelSourceTag(m);
          const connTag = _formatConnectionTag(m);
          modelChoices.push({
            name: `${statusTag} ${m.name || m.id}${sourceTag ? ` ${sourceTag}` : ''}${connTag ? ` ${connTag}` : ''} ${chalk.dim('(' + s.name + ')')} ${indicator}${m.isDefault ? chalk.green(' ✓ 当前') : ''}`,
            value: { adapter: s.type, model: m.id },
            disabled: false,
          });
        }
      } else {
        // Adapter available but no model list (e.g. relay)
        modelChoices.push({
          name: `${statusTag} ${s.name} ${chalk.dim('(默认模型)')} ${indicator}`,
          value: { adapter: s.type, model: null },
          disabled: false,
        });
      }
    } catch (err) {
      skippedUnavailableAdapters += 1;
      hiddenAdapters.push({
        name: s.name || s.type,
        type: s.type,
        reason: _classifyHiddenReason(s, test, err && err.message ? err.message : 'listModels failed'),
      });
    }
  }

  if (modelChoices.length === 0) {
    printInfo('当前无可执行模型可选（已过滤未通过实测的通道）');
    return;
  }

  if (skippedUnavailableAdapters > 0) {
    printInfo(`已隐藏 ${skippedUnavailableAdapters} 个未通过实测的通道（可用 khy gateway status 查看详情）`);
    const shown = [];
    const seen = new Set();
    for (const item of hiddenAdapters) {
      const key = `${String(item.type || '').toLowerCase()}|${String(item.reason || '').toLowerCase()}`;
      if (seen.has(key)) continue;
      seen.add(key);
      shown.push(item);
      if (shown.length >= 3) break;
    }
    for (const item of shown) {
      printInfo(`  - ${item.name} (${item.type}): ${item.reason}`);
    }
    if (hiddenAdapters.length > shown.length) {
      printInfo(`  - 其余 ${hiddenAdapters.length - shown.length} 个通道请用 khy gateway status 查看完整原因`);
    }
  }
  if (generationWarnCount > 0) {
    printInfo(`探测告警 ${generationWarnCount} 项：为快速健康探测结果，不等同于运行时必然失败`);
  }
  if (twoPhaseProbeEnabled && backgroundDeepProbeStarted > 0) {
    printInfo(`已启动 ${backgroundDeepProbeStarted} 个后台深测任务（strict 通道），下次 /model 会显示更准确告警`);
  }

  const isInteractive = !!(process.stdin && process.stdin.isTTY && process.stdout && process.stdout.isTTY);
  const requestedAdapter = (args[0] || options.adapter || '').toLowerCase();
  const requestedModel = options.model || args[1] || '';

  // Non-interactive mode: auto-pick a model without prompting.
  if (!isInteractive) {
    let pick = null;
    if (requestedAdapter || requestedModel) {
      pick = modelChoices.find(c => {
        if (!c || !c.value || c.disabled) return false;
        const adapterOk = !requestedAdapter || c.value.adapter === requestedAdapter;
        const modelOk = !requestedModel || c.value.model === requestedModel;
        return adapterOk && modelOk;
      }) || null;
    }
    if (!pick) {
      pick = modelChoices.find(c => c && c.value && !c.disabled) || null;
    }
    if (!pick) {
      printError('无可用模型可选择');
      return;
    }
    const selected = pick.value;
    persistGatewayPreference(selected);
    try { gateway.syncModelSwitch(selected.model || null); } catch { /* best effort */ }
    try {
      await gateway.refreshAdapters();
    } catch { /* best effort */ }
    printSuccess(`已选择: ${selected.model || '默认模型'} (${selected.adapter})`);
    const tokenInfo = getTokenInfoForSelection(selected);
    printInfo(`可用性: ${pick.disabled ? '不可用' : '可用'}`);
    printInfo(`Token: ${tokenInfo.source} → ${tokenInfo.detail}`);
    return;
  }

  let selected = null;
  let picked = null;
  try {
    const inquirer = require('inquirer');
    const preferredAdapter = String(process.env.GATEWAY_PREFERRED_ADAPTER || '').trim().toLowerCase();
    const preferredModel = String(process.env.GATEWAY_PREFERRED_MODEL || '').trim();
    const defaultChoice = modelChoices.find((c) => {
      if (!c || !c.value || c.disabled) return false;
      if (!preferredAdapter) return false;
      if (c.value.adapter !== preferredAdapter) return false;
      return preferredModel ? String(c.value.model || '') === preferredModel : true;
    });

    const { selectedValue } = await inquirer.prompt([{
      type: 'list',
      name: 'selectedValue',
      message: '选择模型（上下方向键选择，回车确认）:',
      choices: [
        ...modelChoices.map(c => ({
          name: c.name,
          value: c.value,
          disabled: c.disabled ? '不可选' : false,
        })),
        new inquirer.Separator(),
        { name: '返回', value: null },
      ],
      pageSize: Math.min(16, Math.max(8, modelChoices.length + 2)),
      default: defaultChoice ? defaultChoice.value : undefined,
      loop: false,
    }]);
    if (!selectedValue) return;
    selected = selectedValue;
    picked = modelChoices.find((c) => (
      c && c.value
      && c.value.adapter === selected.adapter
      && String(c.value.model || '') === String(selected.model || '')
    )) || null;
  } catch {
    // Fallback: numeric selection for environments where inquirer is unavailable.
    console.log('');
    for (let i = 0; i < modelChoices.length; i++) {
      const c = modelChoices[i];
      const unavailable = c.disabled ? chalk.dim(' (不可选)') : '';
      console.log(`  ${chalk.white(`${i + 1}.`)} ${c.name}${unavailable}`);
    }
    console.log(`  ${chalk.dim('0. 返回')}`);
    console.log('');

    const answer = await askLine(chalk.dim('  输入编号: '));
    const idx = Number.parseInt(String(answer || '').trim(), 10);
    if (!Number.isFinite(idx) || idx === 0) return;
    if (idx < 1 || idx > modelChoices.length) {
      printError('编号超出范围');
      return;
    }
    picked = modelChoices[idx - 1];
    if (!picked || picked.disabled) {
      printError('该模型当前不可选，请选择可用模型');
      return;
    }
    selected = picked.value;
  }

  // Save selection to .env
  persistGatewayPreference(selected);
  try { gateway.syncModelSwitch(selected.model || null); } catch { /* best effort */ }
  try {
    await gateway.refreshAdapters();
  } catch { /* best effort */ }

  printSuccess(`已选择: ${selected.model || '默认模型'} (${selected.adapter})`);
  const selectedChoice = modelChoices.find((c) => {
    if (!c || !c.value) return false;
    return c.value.adapter === selected.adapter
      && String(c.value.model || '') === String(selected.model || '');
  });
  printInfo(`可用性: ${selectedChoice && selectedChoice.disabled ? '不可用' : '可用'}`);
  const tokenInfo = getTokenInfoForSelection(selected);
  printInfo(`Token: ${tokenInfo.source} → ${tokenInfo.detail}`);
  console.log('');
  } finally {
    recoverGatewayPromptInput();
  }
}

/**
 * Explicitly start the web relay server.
 */
async function handleGatewayRelay() {
  const { requireLogin } = require('../../services/authGuard');
  const auth = requireLogin('gateway relay');
  if (!auth.ok) {
    printError(auth.error);
    return;
  }

  const gateway = require('../../services/gateway/aiGateway');
  const relay = gateway.getRelayAdapter();

  if (relay.isRunning()) {
    printInfo(`中转服务已在运行: http://localhost:${relay.getPort()}`);
    return;
  }

  const port = await relay.start();
  console.log('');
  printSuccess(`AI 中转服务已启动`);
  console.log('');
  console.log(chalk.bold(`  🌐 打开浏览器访问: ${chalk.cyan(`http://localhost:${port}`)}`));
  console.log('');
  console.log(chalk.dim('  使用方式:'));
  console.log(chalk.dim('    1. 终端发送 AI 请求后，提示会出现在网页上'));
  console.log(chalk.dim('    2. 点击「一键复制」将提示复制到剪贴板'));
  console.log(chalk.dim('    3. 粘贴到任意 AI 网页（ChatGPT、Claude、Gemini 等）'));
  console.log(chalk.dim('    4. 复制 AI 回复，粘贴到网页文本框，点击「提交」'));
  console.log(chalk.dim('    5. 回复将自动返回到终端'));
  console.log('');
}

/**
 * Detect IDE installations and allow manual path configuration.
 */
async function handleGatewayDetect() {
  const { detectAll, setCustomPath, findInstallation, findDataPath } = require('../../services/gateway/adapters/ideDetector');

  const results = detectAll();

  console.log('');
  console.log(`  ${chalk.cyan.bold('IDE 安装检测')}`);
  console.log('');

  printTable(
    ['IDE', '安装路径', '数据路径', '状态'],
    results.map(r => [
      r.name.charAt(0).toUpperCase() + r.name.slice(1),
      r.installPath || chalk.dim('未找到'),
      r.dataPath ? chalk.dim('✓') : chalk.dim('—'),
      r.available ? chalk.green('✓ 已检测') : chalk.yellow('⚠ 未检测到'),
    ])
  );
  console.log('');

  // Offer to set custom paths for missing IDEs
  const missing = results.filter(r => !r.available);
  if (missing.length > 0) {
    printInfo('未检测到的 IDE 可手动设置安装路径');
    const inquirer = require('inquirer');

    const { action } = await inquirer.prompt([{
      type: 'list',
      name: 'action',
      message: '操作:',
      choices: [
        ...missing.map(r => ({
          name: `设置 ${r.name} 安装路径`,
          value: r.name,
        })),
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (action !== 'back') {
      const { customPath } = await inquirer.prompt([{
        type: 'input',
        name: 'customPath',
        message: `输入 ${action} 安装路径:`,
        validate: (v) => {
          if (!v.trim()) return '路径不能为空';
          return true;
        },
      }]);

      const envKey = `${action.toUpperCase()}_INSTALL_PATH`;
      _writeEnvMap({ [envKey]: customPath.trim() });
      setCustomPath(action, customPath.trim());

      printSuccess(`${action} 安装路径已设为: ${customPath.trim()}`);
    }
  }
}

/**
 * Two-step connectivity test for all or specific adapters.
 * Pattern inspired by cc-haha ProviderTestResult (connectivity + models).
 */
async function handleGatewayTest(targetAdapter) {
  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus();
  const toTest = targetAdapter
    ? statuses.filter(s => s.type === targetAdapter || s.name.toLowerCase().includes(targetAdapter.toLowerCase()))
    : statuses.filter(s => s.enabled);

  if (toTest.length === 0) {
    printError(targetAdapter ? `未找到适配器: ${targetAdapter}` : '无已启用的适配器');
    return;
  }

  console.log('');
  console.log(`  ${chalk.cyan.bold('AI 通道连通测试')}`);
  console.log('');

  for (const s of toTest) {
    console.log(`  ${chalk.bold(s.name)} ${chalk.dim(`(${s.type})`)}`);

    if (!s.available) {
      console.log(`    ${chalk.dim('① 检测')}  ${chalk.red('● 不可用')} ${chalk.dim(s.detail || '')}`);
      console.log('');
      continue;
    }

    const result = await gateway.testAdapter(s.type);

    // Step 1: Connectivity
    if (result.connectivity?.success) {
      console.log(`    ${chalk.dim('① 连接')}  ${chalk.green('● 已连接')} ${chalk.dim(`(${result.connectivity.latencyMs}ms)`)}`);
    } else {
      console.log(`    ${chalk.dim('① 连接')}  ${chalk.red('● 失败:')} ${chalk.red(result.connectivity?.error || 'unknown')}`);
      console.log('');
      continue;
    }

    // Step 2: Models (if tested)
    if (result.models) {
      if (result.models.success) {
        const modelNames = result.models.list?.slice(0, 3).map(m => m.name || m.id).join(', ') || '';
        const more = result.models.count > 3 ? ` +${result.models.count - 3}` : '';
        console.log(`    ${chalk.dim('② 模型')}  ${chalk.green('● 可用')} ${chalk.dim(`(${result.models.latencyMs}ms · ${result.models.count} models)`)}${modelNames ? chalk.dim(` ${modelNames}${more}`) : ''}`);
      } else {
        console.log(`    ${chalk.dim('② 模型')}  ${chalk.red('● 失败:')} ${chalk.red(result.models.error || 'unknown')} ${chalk.dim(`(${result.models.latencyMs}ms)`)}`);
      }
    }

    if (result.generation) {
      if (result.generation.success) {
        console.log(`    ${chalk.dim('③ 实测')}  ${chalk.green('● 可用')} ${chalk.dim(`(${result.generation.latencyMs}ms)`)}`);
      } else {
        console.log(`    ${chalk.dim('③ 实测')}  ${chalk.red('● 失败:')} ${chalk.red(result.generation.error || 'unknown')} ${chalk.dim(`(${result.generation.latencyMs}ms)`)}`);
      }
    }

    console.log('');
  }
}

function _parsePort(value, fallback) {
  const n = parseInt(String(value ?? '').trim(), 10);
  if (!Number.isFinite(n) || n <= 0 || n > 65535) return fallback;
  return n;
}

function _parseIntWithMin(value, fallback, min = 1) {
  const n = parseInt(String(value ?? '').trim(), 10);
  if (!Number.isFinite(n) || n < min) return fallback;
  return n;
}

function _isPidAlive(pid) {
  const p = parseInt(pid, 10);
  if (!Number.isFinite(p) || p <= 0) return false;
  try {
    process.kill(p, 0);
    return true;
  } catch {
    return false;
  }
}

function _loadAiManageRuntime() {
  const files = [AI_MANAGE_RUNTIME_FILE, AI_MANAGE_RUNTIME_FILE_LEGACY];
  for (const file of files) {
    try {
      if (!fs.existsSync(file)) continue;
      const raw = JSON.parse(fs.readFileSync(file, 'utf-8'));
      if (!raw || typeof raw !== 'object') continue;
      return raw;
    } catch {
      // try next
    }
  }
  return null;
}

function _clearAiManageRuntime() {
  for (const file of [AI_MANAGE_RUNTIME_FILE, AI_MANAGE_RUNTIME_FILE_LEGACY]) {
    try {
      if (fs.existsSync(file)) fs.unlinkSync(file);
    } catch {
      // best effort
    }
  }
}

function _resolveAiFrontendDir() {
  const candidates = [];
  if (process.env.KHYQUANT_ROOT) {
    candidates.push(path.resolve(process.env.KHYQUANT_ROOT, '..', 'ai-frontend'));
  }
  candidates.push(path.resolve(process.cwd(), 'ai-frontend'));

  for (const dir of candidates) {
    try {
      if (fs.existsSync(path.join(dir, 'package.json'))) return dir;
    } catch {
      // try next
    }
  }
  return null;
}

function _sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function _requestAiManageControl(runtime, method = 'GET', endpoint = '/status', body = null, timeoutMs = 2500) {
  return new Promise((resolve, reject) => {
    if (!runtime || !runtime.controlPort || !runtime.controlToken) {
      reject(new Error('runtime control 信息缺失'));
      return;
    }

    const queryJoiner = endpoint.includes('?') ? '&' : '?';
    const endpointWithToken = `${endpoint}${queryJoiner}token=${encodeURIComponent(runtime.controlToken)}`;
    const payload = body ? JSON.stringify(body) : null;
    const req = http.request({
      host: '127.0.0.1',
      port: runtime.controlPort,
      path: endpointWithToken,
      method,
      timeout: timeoutMs,
      headers: {
        'X-Khy-Token': runtime.controlToken,
        ...(payload ? {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload),
        } : {}),
      },
    }, (res) => {
      let raw = '';
      res.on('data', chunk => { raw += chunk.toString(); });
      res.on('end', () => {
        let parsed = {};
        try { parsed = raw ? JSON.parse(raw) : {}; } catch { parsed = {}; }
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(parsed);
        } else {
          reject(new Error(parsed.error || `HTTP ${res.statusCode}`));
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('control request timeout')));
    if (payload) req.write(payload);
    req.end();
  });
}

async function _waitAiManageRuntimeReady(timeoutMs = 15000) {
  const started = Date.now();
  while ((Date.now() - started) < timeoutMs) {
    const runtime = _loadAiManageRuntime();
    if (runtime?.pid && _isPidAlive(runtime.pid) && runtime.controlPort && runtime.controlToken) {
      try {
        // eslint-disable-next-line no-await-in-loop
        const status = await _requestAiManageControl(runtime, 'GET', '/status');
        if (status?.ok) return { runtime, status };
      } catch {
        // still starting
      }
    }
    // eslint-disable-next-line no-await-in-loop
    await _sleep(250);
  }
  return null;
}

function _openUrlInBrowser(url) {
  const { openDefault } = require('../../tools/platformUtils');
  try {
    openDefault(url);
    return true;
  } catch {
    return false;
  }
}

function _buildManageOpenUrl(runtime) {
  const base = String(runtime?.frontendUrl || `http://127.0.0.1:${runtime?.frontendPort || 8090}`).trim();
  if (!base) return '';
  if (!runtime?.controlPort || !runtime?.controlToken) return base;
  const ctl = `http://127.0.0.1:${runtime.controlPort}`;
  const joiner = base.includes('?') ? '&' : '?';
  return `${base}${joiner}khy_manage_ctl=${encodeURIComponent(ctl)}&khy_manage_token=${encodeURIComponent(runtime.controlToken)}`;
}

async function _waitPidExit(pid, timeoutMs = 6000) {
  const started = Date.now();
  while ((Date.now() - started) < timeoutMs) {
    if (!_isPidAlive(pid)) return true;
    // eslint-disable-next-line no-await-in-loop
    await _sleep(150);
  }
  return !_isPidAlive(pid);
}

function _spawnAiManageDaemon({ apiPort, frontendPort, idleMs, frontendHost }) {
  if (!fs.existsSync(AI_MANAGE_DAEMON_SCRIPT)) {
    throw new Error(`未找到守护脚本: ${AI_MANAGE_DAEMON_SCRIPT}`);
  }

  const args = [
    AI_MANAGE_DAEMON_SCRIPT,
    '--api-port', String(apiPort),
    '--frontend-port', String(frontendPort),
    '--idle-ms', String(idleMs),
    '--frontend-host', String(frontendHost || '127.0.0.1'),
  ];

  const frontendDir = _resolveAiFrontendDir();
  if (frontendDir) {
    args.push('--frontend-dir', frontendDir);
  }

  let fd = null;
  let stdio = 'ignore';
  try {
    const logDir = path.join(path.dirname(AI_MANAGE_RUNTIME_FILE), 'logs');
    fs.mkdirSync(logDir, { recursive: true });
    const daemonLogFile = path.join(logDir, 'ai_manage_daemon.log');
    fd = fs.openSync(daemonLogFile, 'a');
    stdio = ['ignore', fd, fd];
  } catch {
    stdio = 'ignore';
  }

  const child = spawn(process.execPath, args, {
    detached: true,
    stdio,
    env: { ...process.env },
    cwd: process.env.KHYQUANT_ROOT || path.resolve(__dirname, '../..'),
  });
  if (fd != null) {
    try { fs.closeSync(fd); } catch { /* ignore */ }
  }
  child.unref();
  return child.pid || 0;
}

async function handleGatewayManage(args = [], options = {}) {
  const action = String(args[0] || 'open').trim().toLowerCase();
  const validActions = new Set(['open', 'start', 'status', 'stop']);
  if (!validActions.has(action)) {
    printError(`未知 manage 操作: ${action}`);
    printInfo('用法: gateway manage [open|start|status|stop] [--frontend-port 8090] [--api-port 9090] [--idle-ms 600000]');
    return;
  }

  let runtime = _loadAiManageRuntime();
  let liveStatus = null;
  if (runtime?.pid && _isPidAlive(runtime.pid)) {
    try {
      liveStatus = await _requestAiManageControl(runtime, 'GET', '/status');
      if (!liveStatus?.ok) throw new Error('status not ok');
    } catch {
      runtime = null;
      liveStatus = null;
      _clearAiManageRuntime();
    }
  } else if (runtime) {
    _clearAiManageRuntime();
    runtime = null;
  }

  if (action === 'stop') {
    if (!runtime) {
      printInfo('AI 管理会话未运行');
      return;
    }

    try {
      await _requestAiManageControl(runtime, 'POST', '/shutdown', {});
    } catch {
      // fallback to signal
      const { safeSignal: _sig } = require('../../tools/platformUtils');
      try { _sig(runtime.pid, 'SIGTERM'); } catch { /* ignore */ }
    }

    const exited = await _waitPidExit(runtime.pid, 8000);
    if (!exited) {
      const { safeSignal: _sigKill } = require('../../tools/platformUtils');
      try { _sigKill(runtime.pid, 'SIGKILL'); } catch { /* ignore */ }
      await _waitPidExit(runtime.pid, 2000);
    }
    _clearAiManageRuntime();
    printSuccess('AI 管理会话已停止，端口已释放');
    return;
  }

  if (action === 'status' && !runtime) {
    printInfo('AI 管理会话未运行');
    printInfo('启动命令: khy gateway manage');
    return;
  }

  if (!runtime) {
    const frontendPort = _parsePort(
      options['frontend-port'] ?? options.port ?? process.env.AI_FRONTEND_PORT ?? process.env.VITE_AI_FRONTEND_PORT,
      8090
    );
    const apiPort = _parsePort(
      options['api-port'] ?? process.env.AI_MGMT_PORT,
      9090
    );
    const idleMs = _parseIntWithMin(
      options['idle-ms'] ?? process.env.AI_MANAGE_IDLE_MS,
      10 * 60 * 1000,
      10000
    );
    const frontendHost = String(options['frontend-host'] || process.env.AI_FRONTEND_HOST || '127.0.0.1').trim() || '127.0.0.1';

    _spawnAiManageDaemon({ apiPort, frontendPort, idleMs, frontendHost });
    const ready = await _waitAiManageRuntimeReady(AI_MANAGE_READY_TIMEOUT_MS);
    if (!ready) {
      printError('AI 管理会话启动失败或超时');
      printInfo('可检查日志: ~/.khy/logs/ai_manage_daemon.log 与 ~/.khy/logs/ai_frontend_dev.log');
      return;
    }
    runtime = ready.runtime;
    liveStatus = ready.status;
  }

  if (!liveStatus) {
    try {
      liveStatus = await _requestAiManageControl(runtime, 'GET', '/status');
    } catch {
      liveStatus = null;
    }
  }

  const statusRuntime = liveStatus?.runtime || runtime;
  const runtimeForOpen = {
    ...(statusRuntime || {}),
    controlPort: statusRuntime?.controlPort || runtime?.controlPort || 0,
    controlToken: runtime?.controlToken || statusRuntime?.controlToken || '',
    frontendHost: statusRuntime?.frontendHost || runtime?.frontendHost || '127.0.0.1',
    frontendPort: statusRuntime?.frontendPort || runtime?.frontendPort || 8090,
    frontendUrl: statusRuntime?.frontendUrl || runtime?.frontendUrl || '',
  };
  const frontendAvailable = !!statusRuntime?.frontendAvailable;
  const apiDisplay = `http://127.0.0.1:${runtimeForOpen.apiPort || statusRuntime?.apiPort || runtime?.apiPort || 9090}`;
  const frontendDisplay = `http://${runtimeForOpen.frontendHost}:${runtimeForOpen.frontendPort}`;
  const keepaliveUrl = _buildManageOpenUrl(runtimeForOpen);

  if (action === 'status') {
    console.log('');
    console.log(`  ${chalk.cyan.bold('AI 管理会话状态')}`);
    console.log('');
    console.log(`  ${chalk.gray('运行状态:')} ${chalk.green('● 运行中')}`);
    console.log(`  ${chalk.gray('守护进程 PID:')} ${statusRuntime.pid || runtime.pid}`);
    console.log(`  ${chalk.gray('API:')} ${chalk.cyan(`${apiDisplay}/api/health`)}`);
    console.log(`  ${chalk.gray('前端:')} ${frontendAvailable ? chalk.cyan(frontendDisplay) : chalk.yellow('未就绪')}`);
    console.log(`  ${chalk.gray('推荐入口:')} ${chalk.cyan('khy aiguanli  或  khy gateway manage open')}`);
    console.log(`  ${chalk.gray('保活直链:')} ${chalk.dim(keepaliveUrl)}`);
    console.log(`  ${chalk.gray('自动关闭:')} ${chalk.cyan('页面关闭后空闲自动释放端口')}`);
    console.log(`  ${chalk.gray('活跃页面:')} ${String(statusRuntime.sessions || 0)}`);
    console.log('');
    return;
  }

  const openUrl = _buildManageOpenUrl(runtimeForOpen);
  if (action === 'start') {
    printSuccess('AI 管理会话已启动');
  } else {
    const opened = _openUrlInBrowser(openUrl);
    if (opened) {
      printSuccess(`已打开管理页面: ${frontendDisplay}`);
    } else {
      printInfo(`请手动打开管理页面: ${openUrl}`);
    }
  }

  console.log('');
  console.log(`  ${chalk.gray('API:')} ${chalk.cyan(`${apiDisplay}/api/health`)}`);
  console.log(`  ${chalk.gray('前端:')} ${frontendAvailable ? chalk.cyan(frontendDisplay) : chalk.yellow('未就绪')}`);
  console.log(`  ${chalk.gray('推荐入口:')} ${chalk.cyan('khy aiguanli  或  khy gateway manage open')}`);
  console.log(`  ${chalk.gray('保活直链:')} ${chalk.dim(openUrl)}`);
  console.log(`  ${chalk.gray('状态:')} ${chalk.dim('khy gateway manage status')}`);
  console.log(`  ${chalk.gray('停止:')} ${chalk.dim('khy gateway manage stop')}`);
  console.log('');

  if (!frontendAvailable) {
    printInfo('未检测到可用前端服务。可手动运行: npm --prefix ai-frontend install && npm --prefix ai-frontend run dev');
  }
}

/**
 * Start/stop/status the AI management backend server.
 * @param {string} action - 'start' | 'stop' | 'status'
 */
async function handleAiServer(action) {
  const server = require('../../services/aiManagementServer');

  if (action === 'stop') {
    if (!server.isRunning()) {
      printInfo('AI 管理服务未运行');
      return;
    }
    await server.stop();
    printSuccess('AI 管理服务已停止');
    return;
  }

  if (action === 'status') {
    if (server.isRunning()) {
      printSuccess(`AI 管理服务运行中: http://localhost:${server.getPort()}`);
    } else {
      printInfo('AI 管理服务未运行');
    }
    return;
  }

  // Default: start
  if (server.isRunning()) {
    printInfo(`AI 管理服务已在运行: http://localhost:${server.getPort()}`);
    return;
  }

  const port = await server.start();
  console.log('');
  printSuccess('AI 管理服务已启动');
  console.log('');
  console.log(chalk.bold(`  🌐 API:       ${chalk.cyan(`http://localhost:${port}/api/health`)}`));
  console.log(chalk.bold(`  🔌 WebSocket: ${chalk.cyan(`ws://localhost:${port}/ws`)}`));
  console.log('');
  console.log(chalk.dim('  REST 端点:'));
  console.log(chalk.dim('    GET  /api/status          — 适配器状态'));
  console.log(chalk.dim('    GET  /api/models          — 模型列表 (含健康指标)'));
  console.log(chalk.dim('    POST /api/test/:adapter   — 两步连通测试'));
  console.log(chalk.dim('    GET  /api/config          — 网关配置'));
  console.log(chalk.dim('    PUT  /api/config          — 更新配置'));
  console.log(chalk.dim('    GET  /api/conversations   — 会话列表'));
  console.log(chalk.dim('    GET  /api/usage           — Token 用量'));
  console.log(chalk.dim('    GET  /api/tools           — 工具列表'));
  console.log(chalk.dim('    POST /api/tools/:name     — 执行工具'));
  console.log('');
}

/**
 * Display supported protocol conversion formats.
 */
function handleGatewayProtocols() {
  const { getSupportedProtocols, PROTOCOLS } = require('../../services/gateway/protocolConverter');

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('协议转换支持')}`);
  console.log('');

  const protocols = getSupportedProtocols();
  const rows = protocols.map(p => {
    const endpoints = {
      [PROTOCOLS.OPENAI]: '/v1/chat/completions',
      [PROTOCOLS.ANTHROPIC]: '/v1/messages',
      [PROTOCOLS.GEMINI]: '/v1beta/models/:model:generateContent',
      [PROTOCOLS.GROK]: '/v1/chat/completions (Grok)',
      [PROTOCOLS.CODEX]: '/v1/responses',
    };
    return [p, endpoints[p] || '—', chalk.green('✓ 双向')];
  });

  printTable(['协议', '端点', '转换方向'], rows);

  console.log('');
  printInfo('任意协议间可互转（通过 Canonical 中间格式）');
  printInfo('代理服务自动检测输入协议，以原协议格式返回');
  console.log('');
}

/**
 * OAuth token management.
 */
async function handleGatewayOAuth(action, provider) {
  const oauth = require('../../services/gateway/oauthManager');
  oauth.init();

  if (action === 'refresh' && provider) {
    printInfo(`正在刷新 ${provider} token...`);
    const token = await oauth.refreshToken(provider);
    if (token) {
      printSuccess(`${provider} token 已刷新`);
    } else {
      printError(`${provider} 刷新失败 — 请检查 refresh_token 配置`);
    }
    return;
  }

  // Default: status
  const allStatus = oauth.getAllStatus();
  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('OAuth Token 状态')}`);
  console.log('');

  for (const [key, status] of Object.entries(allStatus)) {
    const icon = status.valid ? chalk.green('●') : (status.registered ? chalk.yellow('●') : chalk.dim('○'));
    const expiry = status.expiresIn > 0 ? chalk.dim(`(${Math.round(status.expiresIn / 60)}min)`) : '';
    const error = status.error ? chalk.red(` · ${status.error.slice(0, 40)}`) : '';
    const refresh = status.hasRefreshToken ? chalk.dim(' [refresh]') : '';
    console.log(`  ${icon} ${chalk.white(status.provider || key)} ${status.valid ? chalk.green('有效') : (status.registered ? chalk.yellow('已过期') : chalk.dim('未配置'))} ${expiry}${refresh}${error}`);
  }

  console.log('');
  printInfo('使用 gateway oauth refresh <provider> 强制刷新');
  console.log('');
}

/**
 * Scan local IDE/config files and merge discovered model IDs into RELAY_API_MODELS.
 */
async function handleGatewayDiscoverModels() {
  const { discoverModels, updateRelayModelsInEnvFile } = require('../../services/gateway/modelDiscovery');
  const envPath = _resolveEnvPathForDiscoverModels();
  const result = discoverModels();
  const discovered = result.models || [];

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('模型自动发现')}`);
  console.log('');

  if (discovered.length === 0) {
    printInfo('未发现可用模型 ID。可手动设置 RELAY_API_MODELS。');
    console.log('');
    return;
  }

  const merged = updateRelayModelsInEnvFile(envPath, discovered);
  let mergedCount = 0;
  try { mergedCount = String(merged).split(',').filter(Boolean).length; } catch { mergedCount = 0; }

  printSuccess(`已发现 ${discovered.length} 个模型候选，并写入 RELAY_API_MODELS (${mergedCount} 个)`);

  if (result.evidence && result.evidence.length > 0) {
    printInfo('来源文件:');
    for (const e of result.evidence.slice(0, 12)) {
      const short = e.file.replace((process.env.HOME || ''), '~');
      console.log(`  ${chalk.dim('-')} ${short} ${chalk.dim(`(${e.count})`)}`);
    }
  }

  console.log('');
  printInfo('可运行 khy gateway model 重新选择模型');
  console.log('');
}

module.exports = {
  handleGatewayStatus,
  handleGatewayConfig,
  handleGatewayRelay,
  handleGatewayDetect,
  handleGatewaySelectModel,
  handleGatewayPreferRemote,
  handleGatewayTest,
  handleGatewayManage,
  handleAiServer,
  handleGatewayProtocols,
  handleGatewayOAuth,
  handleGatewayDiscoverModels,
  handleGatewayTuneLocal,
};
