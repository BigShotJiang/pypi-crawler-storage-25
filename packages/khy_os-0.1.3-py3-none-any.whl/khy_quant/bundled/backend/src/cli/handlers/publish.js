'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const inquirer = require('inquirer');
const {
  printError, printInfo, printSuccess, printWarn,
} = require('../formatters');

const HEARTBEAT_MS_DEFAULT = 10000;
const DIST_NAME_PATTERN = /\.whl$|\.tar\.gz$/i;
const PYPROJECT_PATH = 'pyproject.toml';
const PYTHON_INIT_PATH = path.join('khy_quant', '__init__.py');
const BACKEND_PKG_PATH = path.join('backend', 'package.json');

function _toInt(value, fallback, min = 1) {
  const n = parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(n) || n < min) return fallback;
  return n;
}

function _formatDuration(ms) {
  const sec = Math.max(1, Math.floor(ms / 1000));
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m > 0 && s > 0) return `${m}m ${s}s`;
  if (m > 0) return `${m}m`;
  return `${s}s`;
}

function _markFailure() {
  if (!process.exitCode || process.exitCode === 0) {
    process.exitCode = 1;
  }
}

function _findProjectRoot(startDir = process.cwd()) {
  let current = path.resolve(startDir);
  while (true) {
    const hasPyproject = fs.existsSync(path.join(current, PYPROJECT_PATH));
    const hasSetup = fs.existsSync(path.join(current, 'setup.py'));
    if (hasPyproject || hasSetup) return current;
    const parent = path.dirname(current);
    if (parent === current) return path.resolve(startDir);
    current = parent;
  }
}

function _readFileSafe(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf-8');
  } catch {
    return '';
  }
}

function _extractProjectBlock(pyprojectContent = '') {
  const m = String(pyprojectContent).match(/\[project\]([\s\S]*?)(?:\n\[[^\n]+\]|$)/);
  return m ? m[1] : '';
}

function _extractProjectField(pyprojectContent, key) {
  const block = _extractProjectBlock(pyprojectContent);
  if (!block) return '';
  const re = new RegExp(`^\\s*${key}\\s*=\\s*["']([^"']+)["']\\s*$`, 'm');
  const m = block.match(re);
  return m ? String(m[1] || '').trim() : '';
}

function _readState(projectRoot) {
  const pyprojectFile = path.join(projectRoot, PYPROJECT_PATH);
  const pyproject = _readFileSafe(pyprojectFile);
  const packageName = _extractProjectField(pyproject, 'name');
  const pyVersion = _extractProjectField(pyproject, 'version');

  const pyInitFile = path.join(projectRoot, PYTHON_INIT_PATH);
  const pyInit = _readFileSafe(pyInitFile);
  const pyInitVersionMatch = pyInit.match(/^\s*__version__\s*=\s*["']([^"']+)["']\s*$/m);
  const pyInitVersion = pyInitVersionMatch ? String(pyInitVersionMatch[1]).trim() : '';

  const backendPkgFile = path.join(projectRoot, BACKEND_PKG_PATH);
  let backendVersion = '';
  try {
    const parsed = JSON.parse(_readFileSafe(backendPkgFile) || '{}');
    backendVersion = String(parsed.version || '').trim();
  } catch { /* ignore */ }

  const versions = [pyVersion, pyInitVersion, backendVersion].filter(Boolean);
  const versionAligned = versions.length > 0 && versions.every(v => v === versions[0]);

  return {
    projectRoot,
    packageName,
    versions: {
      pyproject: pyVersion,
      python: pyInitVersion,
      backend: backendVersion,
    },
    versionAligned,
  };
}

function _isLikelyVersion(version) {
  // Practical release format for this CLI (simple + predictable):
  // 0.1.0 / 1.2.3 / 1.2.3rc1 / 1.2.3.post1 / 1.2.3.dev1
  return /^\d+(?:\.\d+){1,3}(?:[abrc]\d+)?(?:\.post\d+)?(?:\.dev\d+)?$/i.test(String(version || '').trim());
}

function _replaceOrThrow(content, regex, replacement, fileLabel) {
  if (!regex.test(content)) {
    throw new Error(`未在 ${fileLabel} 找到可更新的版本字段`);
  }
  return content.replace(regex, replacement);
}

function _updateVersions(projectRoot, nextVersion) {
  const version = String(nextVersion || '').trim();
  if (!_isLikelyVersion(version)) {
    throw new Error(`版本号格式不合法: ${version}（示例: 0.1.0, 1.2.3rc1）`);
  }

  const pyprojectFile = path.join(projectRoot, PYPROJECT_PATH);
  const pyInitFile = path.join(projectRoot, PYTHON_INIT_PATH);
  const backendPkgFile = path.join(projectRoot, BACKEND_PKG_PATH);

  const pyproject = _readFileSafe(pyprojectFile);
  const updatedPyproject = _replaceOrThrow(
    pyproject,
    /(\[project\][\s\S]*?^\s*version\s*=\s*["'])([^"']+)(["']\s*$)/m,
    `$1${version}$3`,
    PYPROJECT_PATH
  );
  fs.writeFileSync(pyprojectFile, updatedPyproject, 'utf-8');

  const pyInit = _readFileSafe(pyInitFile);
  const updatedPyInit = _replaceOrThrow(
    pyInit,
    /(^\s*__version__\s*=\s*["'])([^"']+)(["']\s*$)/m,
    `$1${version}$3`,
    PYTHON_INIT_PATH
  );
  fs.writeFileSync(pyInitFile, updatedPyInit, 'utf-8');

  const backendPkgRaw = _readFileSafe(backendPkgFile);
  let backendPkg;
  try {
    backendPkg = JSON.parse(backendPkgRaw || '{}');
  } catch {
    throw new Error(`无法解析 ${BACKEND_PKG_PATH}`);
  }
  backendPkg.version = version;
  fs.writeFileSync(backendPkgFile, `${JSON.stringify(backendPkg, null, 2)}\n`, 'utf-8');
}

function _detectPython() {
  const candidates = [
    process.env.KHY_PYTHON,
    'python3',
    'python',
  ].filter(Boolean);
  for (const cmd of candidates) {
    try {
      const result = spawnSync(cmd, ['--version'], { encoding: 'utf-8', timeout: 5000 });
      if (result.status === 0) return cmd;
    } catch { /* ignore */ }
  }
  return '';
}

function _moduleReady(pythonCmd, moduleName) {
  if (!pythonCmd) return false;
  try {
    const result = spawnSync(pythonCmd, ['-m', moduleName, '--version'], {
      encoding: 'utf-8',
      timeout: 8000,
    });
    return result.status === 0;
  } catch {
    return false;
  }
}

function _collectDistArtifacts(projectRoot) {
  const distDir = path.join(projectRoot, 'dist');
  if (!fs.existsSync(distDir)) return [];
  const names = fs.readdirSync(distDir).filter(n => DIST_NAME_PATTERN.test(n));
  return names.sort().map(n => path.join('dist', n));
}

function _hasPypircSection(repoName) {
  const pypirc = path.join(os.homedir(), '.pypirc');
  const content = _readFileSafe(pypirc);
  if (!content) return false;
  const section = String(repoName || 'pypi').toLowerCase();
  const re = new RegExp(`^\\s*\\[\\s*${section}\\s*\\]\\s*$`, 'mi');
  return re.test(content);
}

function _resolveToken(targetRepo, options = {}) {
  const byOption = String(
    options.token
    || options['pypi-token']
    || options.pypiToken
    || options.password
    || ''
  ).trim();
  if (byOption) return byOption;

  const envVars = targetRepo === 'testpypi'
    ? ['TEST_PYPI_TOKEN', 'PYPI_TEST_TOKEN', 'PYPI_TOKEN', 'TWINE_PASSWORD']
    : ['PYPI_TOKEN', 'TWINE_PASSWORD'];
  for (const key of envVars) {
    const val = String(process.env[key] || '').trim();
    if (val) return val;
  }
  return '';
}

function _buildUploadEnv(targetRepo, options = {}) {
  const env = { ...process.env };
  const token = _resolveToken(targetRepo, options);
  const explicitUser = String(options.username || process.env.TWINE_USERNAME || '').trim();
  const explicitPass = String(options.password || process.env.TWINE_PASSWORD || '').trim();

  if (token) {
    env.TWINE_USERNAME = '__token__';
    env.TWINE_PASSWORD = token;
  } else if (explicitUser && explicitPass) {
    env.TWINE_USERNAME = explicitUser;
    env.TWINE_PASSWORD = explicitPass;
  }

  return {
    env,
    hasCredential: !!(env.TWINE_USERNAME && env.TWINE_PASSWORD) || _hasPypircSection(targetRepo),
    fromToken: !!token,
  };
}

async function _runCommandLive(command, args, opts = {}) {
  const cwd = opts.cwd || process.cwd();
  const env = opts.env || process.env;
  const activity = opts.activity || `${command} ${args.join(' ')}`;
  const heartbeatMs = _toInt(
    process.env.KHY_ACTIVITY_PULSE_MS || process.env.GATEWAY_ACTIVITY_PULSE_MS,
    HEARTBEAT_MS_DEFAULT,
    3000
  );

  printInfo(`开始: ${activity}`);
  const startedAt = Date.now();

  await new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd,
      env,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    const timer = setInterval(() => {
      const elapsed = _formatDuration(Date.now() - startedAt);
      printInfo(`${activity} 进行中 (${elapsed})`);
    }, heartbeatMs);
    timer.unref?.();

    const cleanup = () => clearInterval(timer);

    child.stdout.on('data', (buf) => {
      try { process.stdout.write(String(buf)); } catch { /* ignore */ }
    });
    child.stderr.on('data', (buf) => {
      try { process.stderr.write(String(buf)); } catch { /* ignore */ }
    });
    child.on('error', (err) => {
      cleanup();
      reject(err);
    });
    child.on('close', (code) => {
      cleanup();
      if (code === 0) {
        printSuccess(`完成: ${activity}`);
        resolve();
      } else {
        reject(new Error(`${activity} 失败 (exit ${code})`));
      }
    });
  });
}

function _printState(state) {
  printInfo(`项目目录: ${state.projectRoot}`);
  printInfo(`包名: ${state.packageName || '(未读取到)'}`);
  printInfo(`版本(pyproject): ${state.versions.pyproject || '-'}`);
  printInfo(`版本(khy_quant): ${state.versions.python || '-'}`);
  printInfo(`版本(backend): ${state.versions.backend || '-'}`);
  if (!state.versionAligned) {
    printWarn('版本号未对齐（pyproject / khy_quant / backend 不一致）');
    printInfo('可用 --version <x.y.z> 一键同步版本');
  }
}

function _printHelp() {
  console.log('');
  console.log('  用法:');
  console.log('    khy publish check [--root <path>]');
  console.log('    khy publish build [--root <path>] [--clean]');
  console.log('    khy publish pypi [--version <x.y.z>] [--yes] [--skip-build]');
  console.log('    khy publish testpypi [--version <x.y.z>] [--yes] [--skip-build]');
  console.log('');
  console.log('  常用参数:');
  console.log('    --version <x.y.z>     同步 3 处版本号后再构建');
  console.log('    --yes                 跳过上传确认（CI/自动化）');
  console.log('    --token <token>       指定 PyPI token（也可用环境变量）');
  console.log('    --skip-build          直接上传 dist/*');
  console.log('    --root <path>         指定项目根目录');
  console.log('');
  console.log('  环境变量:');
  console.log('    PYPI_TOKEN / TEST_PYPI_TOKEN / TWINE_USERNAME / TWINE_PASSWORD');
  console.log('    KHY_PYTHON / KHY_ACTIVITY_PULSE_MS');
  console.log('');
}

async function _confirmUpload(targetRepo, packageName, version, options) {
  if (options.yes || options.confirm) return true;
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    printError('非交互环境请加 --yes 确认上传');
    return false;
  }
  const answer = await inquirer.prompt([{
    type: 'confirm',
    name: 'ok',
    default: false,
    message: `确认上传 ${packageName || 'package'} ${version || ''} 到 ${targetRepo} ?`,
  }]);
  return !!answer.ok;
}

async function _runBuildAndCheck(projectRoot, pythonCmd, cleanDist) {
  if (cleanDist) {
    const distPath = path.join(projectRoot, 'dist');
    if (fs.existsSync(distPath)) {
      fs.rmSync(distPath, { recursive: true, force: true });
      printInfo('已清理 dist/');
    }
  }

  try {
    await _runCommandLive(pythonCmd, ['-m', 'build'], {
      cwd: projectRoot,
      activity: '构建 Python 包',
    });
  } catch (firstErr) {
    printWarn('隔离构建失败，尝试使用 --no-isolation 离线构建...');
    await _runCommandLive(pythonCmd, ['-m', 'build', '--no-isolation'], {
      cwd: projectRoot,
      activity: '构建 Python 包(无隔离)',
    });
  }

  const artifacts = _collectDistArtifacts(projectRoot);
  if (artifacts.length === 0) {
    throw new Error('构建完成但 dist/ 下未找到可发布产物');
  }
  printInfo(`构建产物: ${artifacts.join(', ')}`);

  await _runCommandLive(pythonCmd, ['-m', 'twine', 'check', ...artifacts], {
    cwd: projectRoot,
    activity: '校验构建产物(twine check)',
  });
  return artifacts;
}

async function handlePublish(subCommand, args = [], options = {}) {
  const fallbackAction = String(args[0] || '').toLowerCase();
  const action = String(subCommand || fallbackAction || '').toLowerCase() || 'pypi';
  if (!['check', 'build', 'pypi', 'testpypi', 'help'].includes(action)) {
    printError(`未知 publish 子命令: ${action}`);
    _printHelp();
    _markFailure();
    return false;
  }
  if (action === 'help') {
    _printHelp();
    return true;
  }

  const startDir = options.root || options['project-root'] || process.cwd();
  const projectRoot = _findProjectRoot(startDir);

  let state = _readState(projectRoot);
  _printState(state);

  if (options.version) {
    _updateVersions(projectRoot, options.version);
    printSuccess(`版本已同步为 ${options.version}`);
    state = _readState(projectRoot);
    _printState(state);
  }

  const pythonCmd = _detectPython();
  if (!pythonCmd) {
    printError('未找到 Python 解释器（python3/python）');
    _markFailure();
    return false;
  }
  printInfo(`Python: ${pythonCmd}`);

  if (!_moduleReady(pythonCmd, 'build')) {
    printError('未安装 build 模块');
    printInfo(`运行: ${pythonCmd} -m pip install build`);
    _markFailure();
    return false;
  }
  if (!_moduleReady(pythonCmd, 'twine')) {
    printError('未安装 twine 模块');
    printInfo(`运行: ${pythonCmd} -m pip install twine`);
    _markFailure();
    return false;
  }

  if (!state.versionAligned && !options.force) {
    printError('版本未对齐，已中止。请使用 --version <x.y.z> 同步后重试，或加 --force 跳过。');
    _markFailure();
    return false;
  }

  if (action === 'check') {
    printSuccess('发布前检查通过');
    return true;
  }

  try {
    const cleanDist = options.clean !== false && String(options.clean || '').toLowerCase() !== 'false';
    if (action === 'build') {
      await _runBuildAndCheck(projectRoot, pythonCmd, cleanDist);
      printSuccess('构建流程完成');
      return true;
    }

    const targetRepo = action === 'testpypi' ? 'testpypi' : 'pypi';
    const uploadReady = _buildUploadEnv(targetRepo, options);
    if (!uploadReady.hasCredential) {
      printError(`未检测到 ${targetRepo} 上传凭据`);
      printInfo('可用方式:');
      printInfo('  1) 设置 PYPI_TOKEN / TEST_PYPI_TOKEN');
      printInfo('  2) 或配置 ~/.pypirc');
      printInfo('  3) 或命令加 --token <token>');
      _markFailure();
      return false;
    }

    const confirmed = await _confirmUpload(
      targetRepo,
      state.packageName,
      state.versions.pyproject,
      options
    );
    if (!confirmed) {
      printWarn('已取消上传');
      _markFailure();
      return false;
    }

    let artifacts = _collectDistArtifacts(projectRoot);
    const skipBuild = options['skip-build'] === true || String(options['skip-build'] || '').toLowerCase() === 'true';
    if (!skipBuild) {
      artifacts = await _runBuildAndCheck(projectRoot, pythonCmd, cleanDist);
    } else if (artifacts.length === 0) {
      printError('指定了 --skip-build，但 dist/ 下没有可上传文件');
      _markFailure();
      return false;
    }

    const uploadArgs = ['-m', 'twine', 'upload'];
    if (targetRepo === 'testpypi') {
      uploadArgs.push('--repository', 'testpypi');
    } else {
      uploadArgs.push('--repository', 'pypi');
    }
    const skipExisting = options['skip-existing'] !== false && String(options['skip-existing'] || '').toLowerCase() !== 'false';
    if (skipExisting) uploadArgs.push('--skip-existing');
    if (options['non-interactive'] || options.nonInteractive) uploadArgs.push('--non-interactive');
    uploadArgs.push(...artifacts);

    await _runCommandLive(pythonCmd, uploadArgs, {
      cwd: projectRoot,
      env: uploadReady.env,
      activity: `上传到 ${targetRepo}`,
    });

    const ver = state.versions.pyproject || '(unknown version)';
    printSuccess(`发布完成: ${state.packageName || 'package'} ${ver} -> ${targetRepo}`);
    return true;
  } catch (err) {
    printError(`发布失败: ${err.message || err}`);
    _markFailure();
    return false;
  }
}

module.exports = {
  handlePublish,
  // Exposed for testability / reuse
  _findProjectRoot,
  _readState,
  _updateVersions,
  _detectPython,
};
