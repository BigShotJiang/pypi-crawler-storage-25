"""
khy OS 首次启动初始化（bootstrap）

用户第一次 `pip install khy-os` 后执行 `khy`，需要先做一些准备工作，
否则 Node 后端无法正常运行。

初始化会做这些事：
1. 安装 npm 依赖（node_modules）
2. 生成 .env（自动写入随机 JWT_SECRET）
3. 初始化数据库（执行 seed 脚本）
4. 生成入门文档（非关键，失败不影响运行）

初始化是"可重复安全"的：
- 完成后会写入标记文件 `.khy_quant_bootstrapped`
- seed 成功后会写入标记文件 `.khy_quant_seeded`
- 下次启动检测到两个标记才完全跳过
- 若初始化中断，删除标记后重试即可
"""
import os
import secrets
import subprocess
import sys
from pathlib import Path

# 标记文件：存在则代表已初始化，下次可直接跳过
MARKER_FILE = ".khy_quant_bootstrapped"
# 数据库 seed 标记：与安装标记分离，避免 seed 漏跑后无法自动重试
SEED_MARKER_FILE = ".khy_quant_seeded"
# 可选依赖修复标记：避免每次启动重复检查/安装
OPTIONAL_FIX_MARKER_FILE = ".khy_quant_optional_fixed"

# npm install timeout: Windows native modules (node-llama-cpp) compile slower
_NPM_TIMEOUT = 600 if os.name == "nt" else 300


def _is_china_network() -> bool:
    """启发式判断是否使用国内 npm 镜像（提高下载成功率）。"""
    lang = os.environ.get("LANG", "") + os.environ.get("LC_ALL", "")
    tz = os.environ.get("TZ", "")
    if lang.startswith("zh") or "Shanghai" in tz or "Chongqing" in tz:
        return True
    if os.name == "nt":
        try:
            import locale
            loc = locale.getdefaultlocale()[0] or ""
            if loc.startswith("zh"):
                return True
        except Exception:
            pass
    return True  # default True: mirror works globally, avoid download stalls


def _configure_npm_registry(npm_cmd: str, cwd: Path):
    """确保 backend 目录下有项目级 .npmrc（不改全局配置）。"""
    npmrc = cwd / ".npmrc"
    if npmrc.exists():
        content = npmrc.read_text(encoding="utf-8", errors="replace")
        if "npmmirror" in content or "taobao" in content or "aliyun" in content:
            return

    try:
        npmrc.write_text("registry=https://registry.npmmirror.com\n",
                         encoding="utf-8")
        print("  [OK] .npmrc created (npmmirror.com)")
    except OSError:
        try:
            subprocess.run(
                [npm_cmd, "config", "set", "registry", "https://registry.npmmirror.com"],
                capture_output=True, timeout=10, cwd=str(cwd), **_subprocess_kwargs(),
            )
            print("  [OK] npm registry set to npmmirror.com")
        except Exception:
            pass


def _subprocess_kwargs():
    """返回子进程平台参数（Windows 下隐藏弹窗）。"""
    kwargs = {}
    if os.name == "nt":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0  # SW_HIDE
        kwargs["startupinfo"] = si
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    return kwargs


def _write_marker(marker: Path, content: str):
    """Write a marker file, ignoring errors (e.g. read-only filesystem)."""
    try:
        marker.write_text(f"{content}\n", encoding="utf-8")
    except OSError:
        pass


def _path_exists_safe(p: Path) -> bool:
    """
    Cross-platform Path.exists() that handles Windows junction/symlink edge
    cases where a broken junction raises PermissionError or OSError instead
    of returning False.
    """
    try:
        return p.exists()
    except (OSError, ValueError):
        return False


def _has_llama_pkg(node_modules: Path) -> bool:
    """Check if node-llama-cpp is installed (scoped or flat)."""
    return (
        _path_exists_safe(node_modules / "node-llama-cpp")
        or _path_exists_safe(node_modules / "@node-llama-cpp")
    )


def _node_env(backend_dir: Path) -> dict:
    """Return env dict with NODE_PATH set so @khy/shared can find deps."""
    env = os.environ.copy()
    node_modules = str(backend_dir / "node_modules")
    existing = env.get("NODE_PATH", "")
    env["NODE_PATH"] = (
        f"{node_modules}{os.pathsep}{existing}" if existing else node_modules
    )
    return env


def ensure_bootstrapped(backend_dir: Path, node_cmd: str):
    """主入口：如未初始化则执行初始化流程。"""
    marker = backend_dir / MARKER_FILE
    seed_marker = backend_dir / SEED_MARKER_FILE
    optional_fix_marker = backend_dir / OPTIONAL_FIX_MARKER_FILE
    if marker.exists() and seed_marker.exists():
        _maybe_repair_optional_local_ai_deps(backend_dir, optional_fix_marker)
        return  # 安装与 seed 都完成，直接跳过

    print()
    print("  khy OS first-run setup...")
    print()

    install_ok = True
    seed_ok = seed_marker.exists()

    # 1) 安装 npm 依赖（仅在安装标记缺失时执行）
    if not marker.exists():
        install_ok = _ensure_npm_install(backend_dir) and install_ok

    # 2) 生成 .env（可重复安全）
    _ensure_env_file(backend_dir)

    # 3) 初始化数据库（仅在 seed 标记缺失时执行，失败会在下次自动重试）
    if not seed_ok:
        seed_ok = _ensure_db_init(backend_dir, node_cmd)

    # 4) 注册到 app 清单（可重复安全）
    _register_app(backend_dir)

    # 安装标记：npm install 至少完成（即使 optional 依赖失败也算通过）
    # 避免 optional 失败导致每次启动都重跑完整 npm install
    if install_ok:
        _write_marker(marker, "bootstrapped")

    if seed_ok:
        _write_marker(seed_marker, "seeded")
    else:
        print("  [WARN] Database seed not confirmed; will retry on next startup.", file=sys.stderr)

    # 5) 生成入门文档（非关键）
    _generate_getting_started(backend_dir, node_cmd)

    # 6) 可选依赖自愈（避免旧安装缺失 node-llama-cpp）
    _maybe_repair_optional_local_ai_deps(backend_dir, optional_fix_marker)

    print()
    print("  Setup complete!")
    print()


def _maybe_repair_optional_local_ai_deps(backend_dir: Path, marker: Path):
    """
    One-shot repair for optional local AI dependency (node-llama-cpp).
    Writes a marker file regardless of outcome so npm never runs on every boot.
    """
    if marker.exists():
        return

    node_modules = backend_dir / "node_modules"
    include_optional_raw = str(os.environ.get("KHY_NPM_INCLUDE_OPTIONAL", "1")).strip().lower()
    include_optional = include_optional_raw not in {"0", "false", "no", "off"}

    if not include_optional:
        _write_marker(marker, "optional-disabled")
        return

    if not _path_exists_safe(node_modules):
        return

    if _has_llama_pkg(node_modules):
        _write_marker(marker, "ok")
        return

    # Attempt one-shot install — always write marker afterward
    npm_cmd = "npm.cmd" if os.name == "nt" else "npm"
    print("  [INFO] Repairing optional local AI dependency: node-llama-cpp ...")
    try:
        result = subprocess.run(
            [npm_cmd, "install", "node-llama-cpp", "--no-audit", "--no-fund"],
            cwd=str(backend_dir),
            timeout=_NPM_TIMEOUT,
            **_subprocess_kwargs(),
        )
        if result.returncode == 0 and _has_llama_pkg(node_modules):
            print("  [OK] Optional dependency repaired: node-llama-cpp")
            _write_marker(marker, "repaired")
        else:
            print("  [WARN] node-llama-cpp repair failed; will not retry", file=sys.stderr)
            _write_marker(marker, "failed")
    except Exception:
        print("  [WARN] node-llama-cpp repair failed; will not retry", file=sys.stderr)
        _write_marker(marker, "failed")


def _ensure_npm_install(backend_dir: Path) -> bool:
    """确保 Node 依赖完整；缺失时自动执行 npm install。"""
    node_modules = backend_dir / "node_modules"
    shared_link = node_modules / "@khy" / "shared"
    include_optional_raw = str(os.environ.get("KHY_NPM_INCLUDE_OPTIONAL", "1")).strip().lower()
    include_optional = include_optional_raw not in {"0", "false", "no", "off"}

    # Core packages that must be present; optional packages checked separately
    # so their absence does NOT trigger a full npm install loop.
    core_packages = [node_modules / "express"]
    # @khy/shared uses file: dep → may be a symlink/junction; use safe check
    core_ok = (
        _path_exists_safe(node_modules)
        and _path_exists_safe(core_packages[0])
        and _path_exists_safe(shared_link)
    )

    if core_ok:
        print("  [OK] Node.js dependencies already installed")
        return True

    if _path_exists_safe(node_modules):
        try:
            has_any = any(node_modules.iterdir())
        except OSError:
            has_any = False
        if has_any:
            print("  [INFO] Some packages missing, reinstalling...")

    print("  Installing Node.js dependencies...")
    print("  [INFO] This may take a few minutes on first run.")
    npm_cmd = "npm.cmd" if os.name == "nt" else "npm"
    npm_args = [npm_cmd, "install", "--no-audit", "--no-fund"]
    if not include_optional:
        npm_args.append("--omit=optional")
        print("  [INFO] Using slim install mode (omit optional dependencies)")
    else:
        print("  [INFO] Installing optional dependencies (includes node-llama-cpp)")

    _configure_npm_registry(npm_cmd, backend_dir)

    try:
        result = subprocess.run(
            npm_args,
            cwd=str(backend_dir),
            timeout=_NPM_TIMEOUT,
            **_subprocess_kwargs(),
        )
        if result.returncode == 0:
            # Verify @khy/shared link (file: deps need lock entry)
            if not _path_exists_safe(shared_link):
                lock = backend_dir / "package-lock.json"
                if lock.exists():
                    lock.unlink()
                subprocess.run(
                    npm_args,
                    cwd=str(backend_dir),
                    timeout=_NPM_TIMEOUT,
                    **_subprocess_kwargs(),
                )
            if include_optional and not _has_llama_pkg(node_modules):
                print("  [INFO] node-llama-cpp missing after npm install, trying explicit install...")
                try:
                    fix = subprocess.run(
                        [npm_cmd, "install", "node-llama-cpp", "--no-audit", "--no-fund"],
                        cwd=str(backend_dir),
                        timeout=_NPM_TIMEOUT,
                        **_subprocess_kwargs(),
                    )
                    if fix.returncode == 0 and _has_llama_pkg(node_modules):
                        print("  [OK] node-llama-cpp installed")
                    else:
                        print("  [WARN] node-llama-cpp install failed; local backend will fallback", file=sys.stderr)
                except Exception:
                    print("  [WARN] node-llama-cpp install failed; local backend will fallback", file=sys.stderr)
            print("  [OK] Node.js dependencies installed")
            return True
        else:
            print(
                "  [WARN] npm install exited with errors. "
                "You may need to run it manually:",
                file=sys.stderr,
            )
            print(f"    cd {backend_dir} && npm install", file=sys.stderr)
            return False
    except FileNotFoundError:
        print(
            f"  [WARN] '{npm_cmd}' not found. Install npm and run:",
            file=sys.stderr,
        )
        print(f"    cd {backend_dir} && npm install", file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        timeout_min = _NPM_TIMEOUT // 60
        print(f"  [WARN] npm install timed out ({timeout_min} min)", file=sys.stderr)
        return False


def _ensure_env_file(backend_dir: Path):
    """如不存在则自动生成 .env（含随机密钥）。"""
    env_file = backend_dir / ".env"
    if env_file.exists():
        print("  [OK] .env configuration exists")
        return

    print("  Generating .env configuration...")
    # 生成 64 位十六进制 JWT 密钥（安全随机）
    jwt_secret = secrets.token_hex(32)

    content = (
        "# khy OS Environment Configuration\n"
        "# Generated by khy-os bootstrap\n"
        "\n"
        "# Database (sqlite = zero config, postgres = production)\n"
        "DB_TYPE=sqlite\n"
        "\n"
        "# Server\n"
        "PORT=3000\n"
        "NODE_ENV=development\n"
        "LOG_LEVEL=info\n"
        "\n"
        "# Authentication\n"
        f"JWT_SECRET={jwt_secret}\n"
        "JWT_EXPIRES_IN=7d\n"
        "\n"
        "# Data Sources\n"
        "ENABLE_AKSHARE=true\n"
        "ENABLE_TUSHARE=false\n"
        "DEFAULT_DATA_SOURCE=reliable\n"
        "\n"
        "# AI Providers (fill in the ones you have)\n"
        "# GEMINI_API_KEY=\n"
        "# GROQ_API_KEY=\n"
        "# OPENROUTER_API_KEY=\n"
        "# ZHIPU_API_KEY=\n"
    )

    env_file.write_text(content)

    # Unix 下限制权限，避免其他用户读取密钥
    if os.name != "nt":
        try:
            os.chmod(str(env_file), 0o600)
        except OSError:
            pass

    print("  [OK] .env generated (secrets auto-generated)")


def _ensure_db_init(backend_dir: Path, node_cmd: str) -> bool:
    """执行 seed 脚本，初始化数据库默认表和基础数据。"""
    seed_script = backend_dir / "scripts" / "seed.js"
    if not seed_script.exists():
        return False

    print("  Initializing database...")
    try:
        result = subprocess.run(
            [node_cmd, str(seed_script)],
            cwd=str(backend_dir),
            env=_node_env(backend_dir),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            **_subprocess_kwargs(),
        )
        combined = f"{result.stdout or ''}\n{result.stderr or ''}"
        normalized = combined.lower()

        # seed.js 在异常时可能仍返回 0；优先基于输出关键字判断是否真正完成
        if "seed completed" in normalized and "seed warning" not in normalized:
            print("  [OK] Database initialized")
            return True

        if result.returncode == 0 and "seed warning" not in normalized:
            print("  [OK] Database initialized")
            return True

        print("  [WARN] Database seed did not confirm success", file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        print("  [WARN] Database initialization timed out", file=sys.stderr)
        return False
    except Exception as e:
        print(f"  [WARN] Database initialization error: {e}", file=sys.stderr)
        return False


def _generate_getting_started(backend_dir: Path, node_cmd: str):
    """调用 Node 服务生成 GETTING_STARTED.md（失败可忽略）。"""
    try:
        subprocess.run(
            [node_cmd, "-e",
             "require('./src/services/gettingStartedService').generateGettingStarted()"],
            cwd=str(backend_dir),
            env=_node_env(backend_dir),
            capture_output=True, timeout=15,
            **_subprocess_kwargs(),
        )
    except Exception:
        pass  # 非关键流程，失败不影响主功能


def _register_app(backend_dir: Path):
    """把 khyquant 注册到 ~/.khyquant/apps，便于主 CLI 发现并启动。"""
    import json

    apps_dir = Path(os.path.expanduser("~")) / ".khyquant" / "apps"
    apps_dir.mkdir(parents=True, exist_ok=True)

    manifest_file = apps_dir / "khyquant.json"

    # 读取版本号（用于 app 清单展示）
    version = "0.0.0"
    pkg_json = backend_dir / "package.json"
    try:
        if pkg_json.exists():
            pkg = json.loads(pkg_json.read_text(encoding="utf-8"))
            version = pkg.get("version", version)
    except Exception:
        pass

    server_js = str(backend_dir / "server.js")

    manifest = {
        "name": "khyquant",
        "version": version,
        "description": "量化交易系统",
        "entry": server_js,
        "port": 3000,
        "frontendPort": 8080,
        "source": "pip",
        "commands": ["khyquant", "quant"],
        "autoStart": False,
        "installedAt": __import__("datetime").datetime.now().isoformat(),
    }

    try:
        manifest_file.write_text(json.dumps(manifest, indent=2, ensure_ascii=False))
        print("  [OK] khyquant registered in app registry")
    except OSError as e:
        # Non-fatal: registry write issues should not block CLI bootstrap.
        print(f"  [WARN] Failed to register app manifest: {e}", file=sys.stderr)
