"""
Initialization for the EdgeFirst validator module."""
__version__ = "5.9.2"
