"""
Pure-NumPy decode helpers for Hailo split-output models.

This module is the single source of truth for the Hailo runner and any
reference / diagnostic scripts.  It contains no ``hailo_platform`` dependency
and is importable on any system, which lets it be unit-tested without a
Hailo accelerator and lets the reference script stay in sync with the runner.

Three concern groups live here:

* **Container format** — extracting the ``.hef + ZIP trailer`` pattern that
  EdgeFirst uses to embed ``edgefirst.json`` and ``labels.txt`` next to a
  HailoRT model.  HailoRT itself rejects HEF files with appended ZIP data,
  so the trailer must be stripped before the bytes are handed to ``HEF()``.

* **Schema-v2 metadata** — parsing ``edgefirst.json`` (per
  ``models/metadata.md``) and binding logical outputs to the physical tensor
  names the HEF actually produces.

* **DFL math** — softmax over reg_max bins, dist2bbox, anchor grids, and
  per-scale merging into the canonical YOLOv8 ``(1, 4+NC[+NM], total_anchors)``
  layout that the validator's existing postprocessing pipeline consumes.
"""

from __future__ import annotations

import io
import json
import zipfile
from typing import Any, Iterable, List, Optional, Sequence, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Container: .hef + ZIP trailer
# ---------------------------------------------------------------------------

def find_zip_start(data: bytes) -> Optional[int]:
    """
    Locate the start of an appended ZIP archive within a byte stream.

    Parameters
    ----------
    data : bytes
        The full file contents (e.g. a ``.hef`` with optional ZIP trailer).

    Returns
    -------
    Optional[int]
        Byte offset where the ZIP archive begins, or ``None`` if no valid
        ZIP trailer is present.

    Notes
    -----
    When a ZIP is appended to a non-ZIP prefix (e.g. via ``cat hef zip >
    combined``), the offsets in the EOCD record and each central-directory
    entry are left at their original values — which, for ZIPs produced by
    the standard tools, are **absolute within the combined file**, not
    relative to the ZIP's own start. That means the textbook formula
    ``eocd_idx - cd_size - cd_offset`` computes to zero for such files and
    would incorrectly claim the whole prefix is part of the archive.

    Python's ``zipfile`` module handles prefixed archives correctly — when
    given the full buffer it locates the EOCD, dereferences the absolute
    offsets, and populates ``ZipInfo.header_offset`` with each entry's
    absolute position. The smallest such offset is, by definition, the
    start of the archive (the first local file header).

    Using the zipfile module here also gives us EOCD signature validation
    for free: a spurious ``PK\\x05\\x06`` sequence in the HEF payload that
    doesn't actually frame a valid archive will fail to parse, and we
    return ``None``.
    """
    if len(data) < 22:
        return None
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            infos = zf.infolist()
            if not infos:
                return None
            return min(zi.header_offset for zi in infos)
    except zipfile.BadZipFile:
        return None


def split_hef_zip_trailer(data: bytes) -> Tuple[bytes, Optional[bytes]]:
    """
    Split a ``.hef`` byte stream into ``(hef_bytes, zip_bytes_or_None)``.

    If no ZIP trailer is present the input is returned unchanged with
    ``None`` for the second element.
    """
    zip_start = find_zip_start(data)
    if zip_start is None:
        return data, None
    return data[:zip_start], data[zip_start:]


def read_hef_with_trailer(
    path: str,
) -> Tuple[bytes, Optional[dict], Optional[List[str]]]:
    """
    Read a ``.hef`` file and extract its EdgeFirst metadata trailer.

    The EdgeFirst model packaging convention appends a ZIP archive to the
    end of the HailoRT-compiled HEF.  The ZIP carries ``edgefirst.json``
    (schema-v2 model metadata) and ``labels.txt``.  HailoRT rejects HEF
    files with extra trailing data, so callers must pass ``hef_bytes`` —
    not the raw file path — to ``HEF()``.

    Parameters
    ----------
    path : str
        Filesystem path to the ``.hef`` file.

    Returns
    -------
    hef_bytes : bytes
        The HEF payload with the ZIP trailer removed (safe to pass to
        ``HEF(bytes)``).
    metadata : Optional[dict]
        Parsed contents of ``edgefirst.json`` from the trailer, or ``None``
        if the file has no trailer or no ``edgefirst.json`` entry.
    labels : Optional[List[str]]
        Lines from ``labels.txt`` in the trailer, or ``None`` when absent.
    """
    with open(path, "rb") as f:
        data = f.read()

    hef_bytes, zip_bytes = split_hef_zip_trailer(data)
    if zip_bytes is None:
        return hef_bytes, None, None

    metadata: Optional[dict] = None
    labels: Optional[List[str]] = None
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        names = set(zf.namelist())
        if "edgefirst.json" in names:
            with zf.open("edgefirst.json") as ef:
                metadata = json.loads(ef.read().decode("utf-8"))
        if "labels.txt" in names:
            with zf.open("labels.txt") as lf:
                text = lf.read().decode("utf-8")
                labels = [
                    line.rstrip()
                    for line in text.splitlines()
                    if line.strip()
                ]
    return hef_bytes, metadata, labels


# ---------------------------------------------------------------------------
# Quantization
# ---------------------------------------------------------------------------

def dequantize(tensor: np.ndarray, quantization: dict) -> np.ndarray:
    """
    Per-tensor affine dequantization: ``real = scale * (q - zero_point)``.

    Used by the reference / fallback path where the runner receives raw
    quantized tensors.  The validator's production path requests
    ``FormatType.FLOAT32`` from HailoRT, which means the SDK applies this
    transform internally and the runner never calls this function — but it
    must still match exactly so the reference decoder produces identical
    results bit-for-bit.
    """
    scale = np.float32(quantization["scale"])
    zero_point = np.float32(quantization.get("zero_point", 0))
    return (tensor.astype(np.float32) - zero_point) * scale


# ---------------------------------------------------------------------------
# Anchor grids
# ---------------------------------------------------------------------------

def make_anchor_grid(
    h: int, w: int, offset: float = 0.5
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Pre-compute the per-FPN-level anchor centre grid in grid units.

    Returns ``(grid_x, grid_y)`` each of shape ``(H, W)``.  The ``+0.5``
    offset matches Ultralytics ``make_anchors()`` exactly — anchors sit at
    grid-cell centres, not corners.
    """
    gx = np.arange(w, dtype=np.float32) + offset
    gy = np.arange(h, dtype=np.float32) + offset
    grid_x, grid_y = np.meshgrid(gx, gy)
    return grid_x, grid_y


def make_anchors_flat(
    strides: Sequence[int],
    grid_sizes: Sequence[Tuple[int, int]],
    offset: float = 0.5,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Build flattened ``anchor_points (N, 2)`` and ``stride_tensor (N, 1)``.

    Equivalent to Ultralytics ``make_anchors``: produces one row per anchor
    across all FPN scales, ordered stride-ascending.
    """
    points: List[np.ndarray] = []
    strides_out: List[np.ndarray] = []
    for stride, (h, w) in zip(strides, grid_sizes):
        grid_x, grid_y = make_anchor_grid(h, w, offset=offset)
        points.append(np.stack([grid_x.ravel(), grid_y.ravel()], axis=-1))
        strides_out.append(np.full((h * w, 1), stride, dtype=np.float32))
    return np.concatenate(points), np.concatenate(strides_out)


# ---------------------------------------------------------------------------
# DFL decode
# ---------------------------------------------------------------------------

def _stable_softmax(x: np.ndarray, axis: int) -> np.ndarray:
    """Numerically stable softmax (subtract max before exp)."""
    x_max = x.max(axis=axis, keepdims=True)
    e = np.exp(x - x_max)
    return e / e.sum(axis=axis, keepdims=True)


def decode_dfl_level(
    bbox_tensor: np.ndarray,
    grid_x: np.ndarray,
    grid_y: np.ndarray,
    stride: float,
    dfl_bins: np.ndarray,
) -> np.ndarray:
    """
    Decode a single FPN level's DFL output into ``(H*W, 4)`` xcycwh pixels.

    Used by the runner, which receives already-dequantized FLOAT32 tensors
    per-level from HailoRT.  Working per-level avoids materializing a large
    merged ``(1, 4*reg_max, total_anchors)`` intermediate that the
    full-merge path ``decode_dfl_merged`` produces.

    Parameters
    ----------
    bbox_tensor : np.ndarray
        Float32 of shape ``(H, W, 4*reg_max)``.
    grid_x, grid_y : np.ndarray
        Pre-computed anchor centres of shape ``(H, W)``.
    stride : float
        Spatial stride for this FPN level (e.g. 8, 16, 32 for YOLOv8 640).
    dfl_bins : np.ndarray
        ``np.arange(reg_max)`` cached once per model.
    """
    h, w, c = bbox_tensor.shape
    reg_max = dfl_bins.shape[0]
    if c != 4 * reg_max:
        raise ValueError(
            f"DFL channel count {c} does not match 4*reg_max={4 * reg_max}"
        )

    raw = bbox_tensor.reshape(h, w, 4, reg_max)
    probs = _stable_softmax(raw, axis=-1)
    dist = (probs * dfl_bins).sum(axis=-1)  # (H, W, 4) — LTRB in grid units

    d_left, d_top, d_right, d_bottom = (
        dist[:, :, 0], dist[:, :, 1], dist[:, :, 2], dist[:, :, 3]
    )
    xc = (grid_x + (d_right - d_left) / 2.0) * stride
    yc = (grid_y + (d_bottom - d_top) / 2.0) * stride
    bw = (d_left + d_right) * stride
    bh = (d_top + d_bottom) * stride

    boxes = np.stack([xc, yc, bw, bh], axis=-1)  # (H, W, 4)
    return boxes.reshape(-1, 4)


def decode_dfl_merged(
    boxes_merged: np.ndarray, reg_max: int
) -> np.ndarray:
    """
    Decode a merged DFL tensor ``(1, 4*reg_max, N)`` into LTRB distances
    ``(1, 4, N)`` in grid units.

    Used by the full-merge reference path (``HailoSplitDecoder``).  Kept in
    sync with ``decode_dfl_level`` — both implement the same softmax +
    weighted-sum, just at different points in the pipeline.
    """
    _, num_features, num_anchors = boxes_merged.shape
    if num_features != 4 * reg_max:
        raise ValueError(
            f"Expected {4 * reg_max} features, got {num_features}"
        )
    x = boxes_merged.reshape(1, 4, reg_max, num_anchors)
    probs = _stable_softmax(x, axis=2)
    bins = np.arange(reg_max, dtype=np.float32).reshape(1, 1, reg_max, 1)
    return (probs * bins).sum(axis=2)


def dist2bbox(
    distances: np.ndarray,
    anchor_points: np.ndarray,
    stride_tensor: np.ndarray,
) -> np.ndarray:
    """
    Convert LTRB distances to xcycwh in pixel coordinates.

    ``distances`` is ``(1, 4, N)`` LTRB in grid units; ``anchor_points`` is
    ``(N, 2)`` in grid units; ``stride_tensor`` is ``(N, 1)``.
    """
    lt = distances[0, :2, :]
    rb = distances[0, 2:, :]
    ap = anchor_points.T

    x1y1 = ap - lt
    x2y2 = ap + rb
    cxy = (x1y1 + x2y2) / 2.0
    wh = x2y2 - x1y1

    s = stride_tensor.T
    cxy = cxy * s
    wh = wh * s
    return np.concatenate([cxy, wh], axis=0)[np.newaxis]


# ---------------------------------------------------------------------------
# Schema-v2 metadata parsing
# ---------------------------------------------------------------------------

def _dshape_dict(dshape: Iterable[dict]) -> dict:
    """Convert a dshape ordered-array into a flat ``{name: size}`` dict."""
    out: dict = {}
    for entry in dshape:
        # Each dshape entry is a single-key dict like {"height": 80}.
        for k, v in entry.items():
            out[k] = v
    return out


def _dshape_names(dshape: Iterable[dict]) -> List[str]:
    """Return the ordered axis-name sequence for a dshape array."""
    return [next(iter(entry.keys())) for entry in dshape]


class HailoMetadataError(ValueError):
    """Raised when ``edgefirst.json`` does not satisfy the v2 contract the
    Hailo runner relies on (missing fields, wrong nesting, etc.)."""


def parse_v2_outputs(metadata: dict) -> dict:
    """
    Parse a schema-v2 ``edgefirst.json`` into a structured layout the
    runner can drive directly.

    Returns a dict::

        {
          "fpn_levels": [
            {
              "stride": float,
              "h": int, "w": int,
              "reg_max": int,
              "nc": int,
              "bbox_child_shape": (H, W, C),
              "cls_child_shape":  (H, W, C),
              "mask_coefs_child_shape": (H, W, C) | None,
            },
            ...  # sorted stride ascending
          ],
          "nc": int,
          "has_mask_coefs": bool,
          "protos_meta": dict | None,    # logical "protos" output, NCHW shape
          "total_anchors": int,
        }

    Raises ``HailoMetadataError`` if mandatory fields are missing or the
    layout does not match the expected detection / segmentation pattern.
    """
    if metadata is None:
        raise HailoMetadataError("edgefirst.json metadata is required")
    if metadata.get("schema_version", 1) < 2:
        raise HailoMetadataError(
            "edgefirst.json schema_version must be >= 2"
        )
    outputs = metadata.get("outputs")
    if not outputs:
        raise HailoMetadataError("edgefirst.json has no 'outputs' entries")

    by_type: dict = {}
    for logical in outputs:
        ltype = logical.get("type")
        if not ltype:
            raise HailoMetadataError(
                f"Logical output {logical.get('name')!r} missing 'type'"
            )
        by_type.setdefault(ltype, []).append(logical)

    if "boxes" not in by_type or "scores" not in by_type:
        raise HailoMetadataError(
            "edgefirst.json must declare 'boxes' and 'scores' logical outputs"
        )

    boxes_meta = by_type["boxes"][0]
    scores_meta = by_type["scores"][0]
    mask_coefs_meta = by_type.get("mask_coefs", [None])[0]
    protos_meta = by_type.get("protos", [None])[0]

    box_children = boxes_meta.get("outputs") or []
    score_children = scores_meta.get("outputs") or []
    if not box_children or not score_children:
        raise HailoMetadataError(
            "Hailo runner requires per-scale split children for boxes and scores"
        )
    if len(box_children) != len(score_children):
        raise HailoMetadataError(
            "boxes and scores must have matching per-scale child counts"
        )

    # Index children by stride so we can join boxes ↔ scores ↔ mask_coefs.
    def _by_stride(children):
        out: dict = {}
        for child in children:
            stride = child.get("stride")
            if stride is None:
                raise HailoMetadataError(
                    f"Per-scale child {child.get('name')!r} missing 'stride'"
                )
            if stride in out:
                raise HailoMetadataError(
                    f"Duplicate stride {stride} in {child.get('name')!r}"
                )
            out[int(stride)] = child
        return out

    box_by_stride = _by_stride(box_children)
    score_by_stride = _by_stride(score_children)
    mask_by_stride = (
        _by_stride(mask_coefs_meta.get("outputs") or [])
        if mask_coefs_meta else {}
    )

    if set(box_by_stride) != set(score_by_stride):
        raise HailoMetadataError(
            "boxes and scores per-scale children must share the same strides"
        )
    if mask_by_stride and set(mask_by_stride) != set(box_by_stride):
        raise HailoMetadataError(
            "mask_coefs per-scale children must share strides with boxes"
        )

    fpn_levels: List[dict] = []
    nc_seen: Optional[int] = None
    for stride in sorted(box_by_stride):
        bx = box_by_stride[stride]
        sc = score_by_stride[stride]
        bx_ds = _dshape_dict(bx["dshape"])
        sc_ds = _dshape_dict(sc["dshape"])
        h = bx_ds.get("height")
        w = bx_ds.get("width")
        if h is None or w is None:
            raise HailoMetadataError(
                f"Box child {bx['name']!r} dshape missing height/width"
            )
        nc = sc_ds.get("num_classes", sc["shape"][-1])
        if nc_seen is None:
            nc_seen = nc
        elif nc != nc_seen:
            raise HailoMetadataError(
                f"Inconsistent num_classes across scales: {nc_seen} vs {nc}"
            )
        reg_max = bx_ds.get("num_features", bx["shape"][-1]) // 4

        level: dict = {
            "stride": float(stride),
            "h": int(h),
            "w": int(w),
            "reg_max": int(reg_max),
            "nc": int(nc),
            "bbox_child_shape": tuple(bx["shape"][1:]),
            "cls_child_shape": tuple(sc["shape"][1:]),
        }
        if mask_by_stride:
            mc = mask_by_stride[stride]
            level["mask_coefs_child_shape"] = tuple(mc["shape"][1:])
        fpn_levels.append(level)

    return {
        "fpn_levels": fpn_levels,
        "nc": nc_seen or 0,
        "has_mask_coefs": bool(mask_by_stride),
        "protos_meta": protos_meta,
        "total_anchors": sum(lvl["h"] * lvl["w"] for lvl in fpn_levels),
    }


def bind_levels_to_hef(
    layout: dict,
    hef_outputs: Sequence[Any],
) -> dict:
    """
    Bind a parsed v2 layout to a HailoRT output-info list.

    For each FPN level the function fills in ``bbox_name`` / ``cls_name`` /
    ``mask_coefs_name`` by matching the v2 child shapes ``(H, W, C)``
    against the HEF tensor shapes.  Also resolves the protos tensor name
    (NHWC in HEF, NCHW in metadata).

    Parameters
    ----------
    layout : dict
        Output of :func:`parse_v2_outputs`.
    hef_outputs : sequence
        ``self._output_infos`` — each item must expose ``.name`` and
        ``.shape`` (HailoRT ``VStreamInfo`` duck-typed).

    Returns
    -------
    dict
        ``layout`` with each ``fpn_levels`` entry augmented with HEF tensor
        names and a top-level ``protos_name`` (or ``None``).

    Raises
    ------
    HailoMetadataError
        If multiple HEF tensors share an expected shape, or no HEF tensor
        matches one of the v2 child shapes.
    """
    shape_map: dict = {}
    for info in hef_outputs:
        key = tuple(info.shape)
        if key in shape_map:
            raise HailoMetadataError(
                f"HEF tensors {shape_map[key]!r} and {info.name!r} share "
                f"shape {key} — cannot disambiguate by shape alone"
            )
        shape_map[key] = info.name

    def _lookup(shape: tuple, role: str, level_stride: float) -> str:
        name = shape_map.get(shape)
        if name is None:
            raise HailoMetadataError(
                f"No HEF tensor matches {role} shape {shape} at "
                f"stride {level_stride}"
            )
        return name

    for lvl in layout["fpn_levels"]:
        lvl["bbox_name"] = _lookup(
            lvl["bbox_child_shape"], "boxes", lvl["stride"]
        )
        lvl["cls_name"] = _lookup(
            lvl["cls_child_shape"], "scores", lvl["stride"]
        )
        if "mask_coefs_child_shape" in lvl:
            lvl["mask_coefs_name"] = _lookup(
                lvl["mask_coefs_child_shape"], "mask_coefs", lvl["stride"]
            )

    layout["protos_name"] = None
    layout["protos_channels"] = 0
    protos_meta = layout.get("protos_meta")
    if protos_meta is not None:
        # Logical protos shape is NCHW (1, C, H, W) per the spec; HEF emits
        # NHWC (H, W, C).  Match either ordering — HailoRT may report
        # different layouts depending on output configuration.
        logical_shape = tuple(protos_meta["shape"][1:])
        nhwc_shape = (
            (logical_shape[1], logical_shape[2], logical_shape[0])
            if len(logical_shape) == 3 else logical_shape
        )
        protos_name = shape_map.get(nhwc_shape) or shape_map.get(logical_shape)
        if protos_name is None:
            raise HailoMetadataError(
                f"No HEF tensor matches protos shape {nhwc_shape} or "
                f"{logical_shape}"
            )
        layout["protos_name"] = protos_name
        layout["protos_channels"] = int(logical_shape[0])

    return layout
