"""
Implementations for storing and parsing the model output metadata.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Union, List

import numpy as np

if TYPE_CHECKING:
    from edgefirst.validator.evaluators import ModelParameters


class Outputs:
    """
    Store the metadata output details needed for decoding the model outputs.

    If the metadata exists, then parse the metadata to store the output details.
    Otherwise, rely on a separate logic to define the output types based on shape.

    If the metadata exists, reinitialize the index based on the existing
    output tensors, as we cannot rely on the current output index stored in
    the metadata.

    Prioritize decoding the variant types such as "detection" and "segmentation".
    Otherwise, decode the known types such as "boxes", "scores", and "masks".

    Parameters
    ----------
    metadata: dict
        The contents of the model metadata for decoding the outputs.
    parameters: ModelParameters
        These are the model parameters set from the command line.
    outputs: Union[List[dict], List[np.ndarray]]
        This is either a List[dict] from a TFLite output details
        or a List[np.ndarray] containing the shapes from the model outputs.
    nc: int
        The number of unique labels in the model.
    """

    def __init__(self,
                 metadata: dict,
                 parameters: ModelParameters,
                 outputs: Union[List[dict], List[np.ndarray]]):

        self.metadata = metadata
        self.parameters = parameters
        self.outputs = outputs

        self.boxes = {
            "anchors": None,
            "decoder": None,
            "index": None,
            "shape": None,
            "type": "boxes",
            "dtype": None,
            "quantization": None,
            "score_format": None,
            "dshape": None,
            "normalized": None,
            "stride": None,
        }

        self.scores = {
            "anchors": None,
            "decoder": None,
            "index": None,
            "shape": None,
            "type": "scores",
            "dtype": None,
            "quantization": None,
            "score_format": None,
            "dshape": None,
            "normalized": None,
            "stride": None,
        }

        self.classes = {
            "anchors": None,
            "decoder": None,
            "index": None,
            "shape": None,
            "type": "classes",
            "dtype": None,
            "quantization": None,
            "score_format": None,
            "dshape": None,
            "normalized": None,
            "stride": None,
        }

        self.masks = {
            "anchors": None,
            "decoder": None,
            "index": None,
            # Store index of raw masks used for HAL visualization.
            "raw_mask_index": None,
            "shape": None,
            "type": "masks",
            "dtype": None,
            "quantization": None,
            "score_format": None,
            "dshape": None,
            "normalized": None,
            "stride": None,
        }

        self.mask_coefficients = {
            "anchors": None,
            "decoder": None,
            "index": None,
            "shape": None,
            "type": "mask_coefficients",
            "dtype": None,
            "quantization": None,
            "score_format": None,
            "dshape": None,
            "normalized": None,
            "stride": None,
        }

        # Variant types from the metadata to decode modelpack.
        # Currently contains types such as "detection" or "segmentation"
        # which can appear common for multiple outputs.
        self.mpk_types = []
        self.num_boxes = 0  # The number of boxes in the model output shape.

        # Parse the metadata if it exists to determine the output types.
        # Otherwise check the output shapes to automatically determine the
        # types.
        if self.metadata is not None and "outputs" in self.metadata.keys():
            self.parse_metadata()
        else:
            self.create_metadata()

    def parse_metadata(self):
        """
        Parses the contents of the metadata and redefines the output
        index based on the existing output as we cannot rely on the
        output index stored in the metadata.
        """

        # Model-level decoder_version is the canonical source for newer
        # converters (e.g. quantization_split yolov8-seg) that omit the
        # per-output `decoder` field. Fall back to it when an output lacks
        # its own decoder so the dispatcher routes to `process_yolo_hal`.
        model_decoder = self.metadata.get("decoder_version")

        for output_details in self.metadata["outputs"]:
            output_type = output_details.get("type", "detection")
            decoder = output_details.get("decoder") or model_decoder
            if decoder == "yolov8":
                from edgefirst.validator.publishers.utils.logger import logger
                logger("decoder 'yolov8' is deprecated, use 'ultralytics'.",
                       code="WARNING")
                decoder = "ultralytics"

            config_shape = output_details["shape"]
            output_index = output_details.get("output_index", 0)
            dtype = output_details.get("dtype")
            anchors = output_details.get("anchors")
            anchors = np.array(anchors) if anchors is not None else None
            quantization = None
            score_format = output_details.get("score_format", None)
            dshape = output_details.get("dshape", None)

            # Redefine the output index based on the actual model outputs.
            for i, output in enumerate(self.outputs):
                if isinstance(output, dict):
                    shape = output["shape"].tolist()
                    quantization = output["quantization"]
                else:
                    shape = list(output.shape)

                # Pattern matching for the output shapes.
                if config_shape == shape:
                    output_index = i
                    break

            context = {
                "index": output_index,
                "decoder": decoder,
                "anchors": anchors,
                "shape": config_shape,
                "type": output_type,
                "dtype": dtype,
                "quantization": quantization,
                "score_format": score_format,
                "dshape": dshape,
                "normalized": output_details.get("normalized"),
                "stride": output_details.get("stride"),
            }

            if output_type == "boxes":
                self.boxes = context
                self.parameters.common.with_boxes = True
            elif output_type == "scores":
                self.scores = context
                self.parameters.common.with_boxes = True
                if decoder == "ultralytics":
                    self.parameters.common.semantic = False
            elif output_type in ("mask_coefficients", "mask_coefs"):
                context["type"] = "mask_coefficients"
                self.mask_coefficients = context
                self.parameters.common.with_boxes = True
                self.parameters.common.with_masks = True
                if decoder == "ultralytics":
                    self.parameters.common.semantic = False
            elif output_type == "classes":
                self.classes = context
                self.parameters.common.with_boxes = True
            elif output_type == "masks":
                context["raw_mask_index"] = self.masks["raw_mask_index"]
                self.masks = context
                # Segmentation models from Ultralytics are multitask.
                if decoder == "ultralytics":
                    self.parameters.common.with_boxes = True
                    self.parameters.common.semantic = False
                self.parameters.common.with_masks = True
            else:
                if decoder == "ultralytics":
                    self.parameters.common.with_boxes = True
                    self.parameters.common.semantic = False
                    # shape [1, 160, 160, 32] are the mask protos outputs.
                    if (len(config_shape) > 3 or output_type == "protos"):
                        self.masks = context
                        self.parameters.common.with_masks = True
                    # shape [1, 116, 8400], [1, 85, 115200] are the score
                    # and/or mask outputs.
                    else:
                        self.scores = context
                else:
                    context["type"] = output_type
                    if output_type == "detection":
                        self.parameters.common.with_boxes = True
                    elif output_type == "segmentation":
                        self.parameters.common.with_masks = True
                        self.masks["raw_mask_index"] = output_index
                    self.mpk_types.append(context)

    def create_metadata(self):
        """
        Defines the output types based on the output shape
        as either a boxes, scores, classes, or masks tensors.
        This is called when the model metadata does not exist. The model
        metadata is created here based on the logic for specifying the
        model outputs.

        This method currently only supports finding decoded output types
        for ModelPack.
        """

        # Get the model output types.
        self.boxes["index"] = self.get_boxes_index()
        self.masks["index"] = self.get_masks_index()
        self.mask_coefficients["index"] = self.get_mask_coefficients_index()
        self.scores["index"] = self.get_scores_index()
        self.masks["raw_mask_index"] = self.masks["index"]
        decoded_masks_index = self.get_decoded_masks_index()

        if decoded_masks_index is not None:
            self.masks["index"] = decoded_masks_index
            self.masks["type"] = "masks"
        else:
            self.masks["type"] = "segmentation"

        self.classes["index"] = self.get_classes_index()

        # Get the model tasks.
        if (self.boxes["index"] is not None or
            self.scores["index"] is not None or
                self.classes["index"] is not None):
            self.parameters.common.with_boxes = True
        else:
            self.parameters.common.with_boxes = False

        if self.masks["index"] is not None:
            self.parameters.common.with_masks = True
        else:
            self.parameters.common.with_masks = False

        # MobileNet SSD has embedded NMS.
        if self.classes["index"] is not None:
            self.parameters.nms = "embedded"

        # Formulate model metadata format.
        self.metadata = {"outputs": []}
        # ModelPack or Kinara
        if (None not in [self.boxes["index"], self.scores["index"]]):
            boxes = self.outputs[self.boxes["index"]]

            kinara = False
            if isinstance(boxes, dict):
                shape = boxes["shape"].tolist()
                dtype = np.dtype(boxes["dtype"]).name
                self.boxes["quantization"] = boxes["quantization"]
            else:
                shape = list(boxes.shape)
                dtype = boxes.dtype.name if hasattr(
                    boxes, "dtype") and hasattr(
                        boxes.dtype, "name") else boxes.dtype if hasattr(
                            boxes, "dtype") else boxes.type
            dshape = self.get_shape_properties(shape)
            self.boxes["dshape"] = dshape
            self.boxes["shape"] = shape
            self.boxes["dtype"] = dtype

            scores = self.outputs[self.scores["index"]]
            if isinstance(scores, dict):
                shape = scores["shape"].tolist()
                dtype = np.dtype(scores["dtype"]).name
                self.scores["quantization"] = scores["quantization"]
            else:
                shape = list(scores.shape)
                dtype = scores.dtype.name if hasattr(
                    scores, "dtype") and hasattr(
                        scores.dtype, "name") else scores.dtype if hasattr(
                            scores, "dtype") else scores.type
            dshape = self.get_shape_properties(shape)
            self.scores["dshape"] = dshape
            self.scores["shape"] = shape
            self.scores["dtype"] = dtype
            
            # Split YOLOv8 model
            if self.mask_coefficients["index"] is not None:
                mask_coefficients = self.outputs[self.mask_coefficients["index"]]
                if isinstance(mask_coefficients, dict):
                    shape = mask_coefficients["shape"].tolist()
                    dtype = np.dtype(mask_coefficients["dtype"]).name
                    self.mask_coefficients["quantization"] = mask_coefficients["quantization"]
                else:
                    shape = list(mask_coefficients.shape)
                    dtype = mask_coefficients.dtype.name if hasattr(
                        mask_coefficients, "dtype") and hasattr(
                            mask_coefficients.dtype, "name") else mask_coefficients.dtype if hasattr(
                                mask_coefficients, "dtype") else mask_coefficients.type
                dshape = self.get_shape_properties(shape)
                self.mask_coefficients["dshape"] = dshape
                self.mask_coefficients["shape"] = shape
                self.mask_coefficients["dtype"] = dtype

            # Kinara YOLOv8
            if len(self.boxes["shape"]) == 3:
                kinara = True
                self.boxes["decode"] = True
                self.scores["decode"] = True
                self.boxes["decoder"] = "ultralytics"
                self.scores["decoder"] = "ultralytics"
                self.boxes["channels_first"] = False
                self.scores["channels_first"] = False
                self.scores["score_format"] = "per_class"

                # Split Model
                if self.mask_coefficients["index"] is not None:
                    self.mask_coefficients["decode"] = True
                    self.mask_coefficients["decoder"] = "ultralytics"
            else:
                # Creating metadata assumes ModelPack already has decoded
                # outputs.
                self.boxes["decoder"] = "modelpack"
                self.scores["decoder"] = "modelpack"

            self.metadata["outputs"].append(self.boxes)
            self.metadata["outputs"].append(self.scores)
            if self.mask_coefficients["index"] is not None:
                self.metadata["outputs"].append(self.mask_coefficients)

            if self.masks["index"] is not None:
                if kinara:
                    self.masks["decoder"] = "ultralytics"
                    self.parameters.common.semantic = False
                else:
                    self.masks["decoder"] = "modelpack"

                masks = self.outputs[self.masks["index"]]
                if isinstance(masks, dict):
                    shape = masks["shape"].tolist()
                    dtype = np.dtype(masks["dtype"]).name
                    self.masks["quantization"] = masks["quantization"]
                else:
                    shape = list(masks.shape)
                    dtype = masks.dtype.name if hasattr(
                        masks, "dtype") and hasattr(
                            masks.dtype, "name") else masks.dtype if hasattr(
                                masks, "dtype") else masks.type
                dshape = self.get_shape_properties(shape)
                self.masks["dshape"] = dshape
                self.masks["shape"] = shape
                self.masks["dtype"] = dtype
                self.metadata["outputs"].append(self.masks)

        # YOLOv5, YOLOv8, YOLOv11
        elif self.scores["index"] is not None:
            self.scores["decoder"] = "ultralytics"
            self.scores["type"] = "detection"

            scores = self.outputs[self.scores["index"]]
            if isinstance(scores, dict):
                shape = scores["shape"].tolist()
                dtype = np.dtype(scores["dtype"]).name
                self.scores["quantization"] = scores["quantization"]
            else:
                shape = list(scores.shape)
                dtype = scores.dtype.name if hasattr(
                    scores, "dtype") and hasattr(
                        scores.dtype, "name") else scores.dtype if hasattr(
                            scores, "dtype") else scores.type
            dshape = self.get_shape_properties(shape)
            self.scores["dshape"] = dshape
            self.scores["shape"] = shape
            self.scores["dtype"] = dtype

            if self.masks["index"] is not None:
                self.parameters.common.semantic = False
                self.masks["decoder"] = "ultralytics"

                masks = self.outputs[self.masks["index"]]
                if isinstance(masks, dict):
                    shape = masks["shape"].tolist()
                    dtype = np.dtype(masks["dtype"]).name
                    self.masks["quantization"] = masks["quantization"]
                else:
                    shape = list(masks.shape)
                    dtype = masks.dtype.name if hasattr(
                        masks, "dtype") and hasattr(
                            masks.dtype, "name") else masks.dtype if hasattr(
                                masks, "dtype") else masks.type
                dshape = self.get_shape_properties(shape)
                self.masks["dshape"] = dshape
                self.masks["shape"] = shape
                self.masks["dtype"] = dtype
                self.masks["type"] = "protos"

                self.metadata["outputs"].append(self.masks)
            self.metadata["outputs"].append(self.scores)

        # ModelPack segmentation
        else:
            if self.masks["index"] is not None:
                self.masks["decoder"] = "modelpack"

                masks = self.outputs[self.masks["index"]]
                if isinstance(masks, dict):
                    shape = masks["shape"].tolist()
                    dtype = np.dtype(masks["dtype"]).name
                    self.masks["quantization"] = masks["quantization"]
                else:
                    shape = list(masks.shape)
                    dtype = masks.dtype.name if hasattr(
                        masks, "dtype") and hasattr(
                            masks.dtype, "name") else masks.dtype if hasattr(
                                masks, "dtype") else masks.type
                dshape = self.get_shape_properties(shape)
                self.masks["dshape"] = dshape
                self.masks["shape"] = shape
                self.masks["dtype"] = dtype
                self.metadata["outputs"].append(self.masks)

    @staticmethod
    def get_shape_properties(shape: List[int]) -> list:
        """
        Get the properties of the output shape to assist with decoding the
        model outputs. This is primarily for decoding the mask proto outputs
        from Ultralytics YOLOv8 and YOLOv11 segmentation models which have a
        shape of [1, 32, 160, 160] or [1, 160, 160, 32].
        From the shape we extract batch, num_protos, height, width for "protos"
        type outputs and batch, num_features, num_boxes for "detection" 
        type outputs.

        Parameters
        ----------
        shape: List[int]
            The shape of the model output tensor.

        Returns
        -------
        list
            A list of tuples containing the properties of the output shape.
        """
        # [1, 32, 160, 160] or [1, 160, 160, 32]
        if len(shape) == 4:
            batch = shape[0]
            transposed = shape[1] < shape[-1]
            num_protos = shape[1] if transposed else shape[-1]
            height = shape[2] if transposed else shape[1]
            width = shape[-1] if transposed else shape[2]
            dshape = []
            keys = []
            for s in shape:
                if s == batch and "batch" not in keys:
                    dshape.append(("batch", batch))
                    keys.append("batch")
                elif s == num_protos and "num_protos" not in keys:
                    dshape.append(("num_protos", num_protos))
                    keys.append("num_protos")
                elif s == height and "height" not in keys:
                    dshape.append(("height", height))
                    keys.append("height")
                elif s == width and "width" not in keys:
                    dshape.append(("width", width))
                    keys.append("width")
        # [1, 37, 8400], [1, 80, 8400]
        elif len(shape) == 3:
            batch = shape[0]
            num_features = shape[1] if shape[1] < shape[2] else shape[2]
            num_boxes = shape[2] if shape[2] > shape[1] else shape[1]
            dshape = []
            keys = []
            for s in shape:
                if s == batch and "batch" not in keys:
                    dshape.append(("batch", batch))
                    keys.append("batch")
                elif s == num_features and "num_features" not in keys:
                    dshape.append(("num_features", num_features))
                    keys.append("num_features")
                elif s == num_boxes and "num_boxes" not in keys:
                    dshape.append(("num_boxes", num_boxes))
                    keys.append("num_boxes")
        # [1, 10] shapes seen in MobileNet SSD outputs
        else:
            batch = shape[0]
            dshape = [("batch", shape[0]), ("num_boxes", shape[1])]
        return dshape

    def get_boxes_index(self) -> Union[int, None]:
        """
        Get the index of the bounding box outputs from the model.
        Checking for Ultralytics and ModelPack variations.
        Box output shapes can be in these variations:
        [1, 6000, 1, 4], [1, 6000, 4], [1, 4, 8400]

        Returns
        -------
        Union[int, None]
            The index is returned if the bounding box output shape exists.
            Otherwise None is returned.
        """

        for i, output in enumerate(self.outputs):
            if isinstance(output, dict):
                shape = output["shape"]
            else:
                shape = output.shape

            if (len(shape) == 4 and shape[-1] == 4):
                self.num_boxes = shape[1]
                return i
            elif len(shape) == 3:
                if shape[1] == 4:
                    self.num_boxes = shape[-1]
                    return i
                elif shape[-1] == 4:
                    self.num_boxes = shape[1]
                    return i
        return None

    def get_masks_index(self) -> Union[int, None]:
        """
        Get the index of the encoded mask outputs from the model.
        Checking for ModelPack variations only.
        Mask shapes are typically [1, h, w, nc].

        Returns
        -------
        Union[int, None]
            The index is returned if the mask output shape exists.
            Otherwise None is returned.
        """
        for i, output in enumerate(self.outputs):
            if isinstance(output, dict):
                shape = output["shape"]
            else:
                shape = output.shape
            if len(shape) == 4 and shape[-2] != 1:  # Avoid shape of the boxes.
                return i
        return None

    def get_scores_index(self) -> Union[int, None]:
        """
        Get the index of the score outputs from the model.
        Checking for ModelPack and Ultralytics variations.
        Score output shapes can be in these variations:
        [1, 6000, 14], [1, 37, 8400], [1, 25200, 85], [1, 80, 8400]

        Returns
        -------
        Union[int, None]
            The index is returned if the score output shape exists.
            Otherwise None is returned.
        """
        for i, output in enumerate(self.outputs):
            if isinstance(output, dict):
                shape = output["shape"]
            else:
                shape = output.shape
            if self.num_boxes != 0:
                # Ultralytics Variations: [1, 8400, 80], [1, 80, 8400]
                if (len(shape) == 3 and self.num_boxes in [shape[1], shape[-1]] 
                    and i != self.mask_coefficients["index"]):
                    return i
                # MobileNet SSD [1, 10]
                elif len(shape) == 2 and i == 2 and shape[1] == self.num_boxes:
                    return i
            else:
                if len(shape) == 3:
                    if (((shape[1] > shape[2]) and (shape[1] / shape[2] > 5))
                        or ((shape[1] < shape[2]) and (shape[2] / shape[1] > 5))
                            and i != self.boxes["index"]):
                        return i
        return None

    def get_decoded_masks_index(self) -> Union[dict, None]:
        """
        Get the index of the decoded mask outputs from the model.
        Checking for ModelPack variations only.

        Returns
        -------
        Union[int, None]
            The index is returned if the decoded mask output shape exists.
            Otherwise None is returned.
        """
        # Segmentation will contain both encoded and decoded masks.
        if len(self.outputs) > 1:
            for i, output in enumerate(self.outputs):
                if isinstance(output, dict):
                    shape = output["shape"]
                else:
                    shape = output.shape
                if self.num_boxes != 0:
                    if len(shape) == 3 and self.num_boxes not in [
                            shape[1], shape[-1]]:
                        return i
                else:
                    if len(shape) == 3:
                        if ((shape[1] >= shape[2]) and (shape[1] / shape[2] < 5)) or (
                            (shape[1] <= shape[2]) and (shape[2] / shape[1] < 5)):
                            return i
        return None

    def get_classes_index(self) -> Union[int, None]:
        """
        Get the index of the class outputs. This is primarily seen
        in MobileNet SSD models.
        Class outputs are in these variations: [1, 10].

        Returns
        -------
        Union[int, None]
            The index is returned if the class output shape exists.
            Otherwise None is returned.
        """

        for i, output in enumerate(self.outputs):
            if isinstance(output, dict):
                shape = output["shape"]
            else:
                shape = output.shape
            if self.num_boxes != 0:
                # MobileNet SSD [1, 10]
                if len(shape) == 2 and i == i and shape[1] == self.num_boxes:
                    return i
        return None

    def get_mask_coefficients_index(self):
        """
        Get the index of the mask coefficients outputs. This is primarily seen
        in Ultralytics split outputs.
        Mask coefficients outputs are in these variations: [1, 32, 8400].

        Returns
        -------
        Union[int, None]
            The index is returned if the class output shape exists.
            Otherwise None is returned.
        """
        for i, output in enumerate(self.outputs):
            if isinstance(output, dict):
                shape = output["shape"]
            else:
                shape = output.shape

            if len(shape) == 3 and shape[1] == 32:
                return i
        return None