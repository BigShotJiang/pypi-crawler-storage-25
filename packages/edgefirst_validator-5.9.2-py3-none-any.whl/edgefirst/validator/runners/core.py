"""
Implementation of the base Runner class for model execution and postprocessing.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Optional, Union, Tuple, List
import time
import os
import traceback

import yaml
import numpy as np
import numpy.typing as npt
from PIL import Image

from edgefirst.validator.runners.processing.outputs import Outputs
from edgefirst.validator.datasets.utils.annotation_transforms import (check_normalized_boxes,
                                                                      xyxy2xcycwh,
                                                                      xcycwh2xyxy,
                                                                      xyxy2xywh)
from edgefirst.validator.datasets.utils.image_transforms import (preprocess_native,
                                                                 preprocess_hal,
                                                                 resize)
from edgefirst.validator.runners.processing.decode import (decode_mpk_boxes,
                                                           decode_mpk_masks,
                                                           decode_yolo_boxes,
                                                           decode_yolo_masks,
                                                           decode_yolox_boxes,
                                                           process_masks_retina,
                                                           dequantize)
from edgefirst.validator.publishers.utils.logger import logger
from edgefirst.validator.runners.processing.nms import nms, multiclass_nms
from edgefirst.validator.datasets.utils.fetch import get_shape

try:
    import edgefirst_hal
    _HAL_AVAILABLE = True
except ImportError:
    _HAL_AVAILABLE = False


_SPLIT_TYPES = {"boxes", "scores", "classes", "mask_coefficients",
                "mask_coefs", "protos", "mask"}


def _infer_output_type(name: str, shape) -> str:
    """Best-effort mapping from output tensor name to HAL output type.

    Split-decoder quantization_split converters (ModelPack, hailo-converter,
    ara2-converter) name outputs with a type suffix. Fall back to
    ``detection`` only when the name carries no hint, so end-to-end
    single-tensor heads keep working.
    """
    n = (name or "").lower()
    if n.endswith("_boxes"):
        return "boxes"
    if n.endswith("_scores"):
        return "scores"
    if n.endswith("_classes"):
        return "classes"
    if n.endswith("_mask_coefs") or n.endswith("_mask_coefficients"):
        return "mask_coefficients"
    # Protos tensor: 4D, spatially square, 32 channels — unique shape.
    try:
        s = list(shape) if shape is not None else []
    except TypeError:
        s = []
    if len(s) == 4 and s[1] == s[2] and s[-1] == 32:
        return "protos"
    return "detection"


def _is_split_decoder(hal_metadata: dict) -> bool:
    """Return True when metadata describes a split-decoder model.

    The dict/JSON path in HAL expects a single ``detection`` output or the
    per-FPN-scale layout used by HailoRT. Quantization-split heads produce
    per-type outputs that must be built via ``new_from_outputs``.
    """
    if hal_metadata.get("model", {}).get("split_decoder"):
        return True
    outs = hal_metadata.get("outputs", [])
    return any(o.get("type") in _SPLIT_TYPES for o in outs)


def _build_split_decoder(hal_metadata: dict, *,
                         score_threshold, iou_threshold, nms):
    """Programmatically build a HAL Decoder for split-decoder models."""
    outs = hal_metadata.get("outputs", [])
    factory = {
        "boxes": edgefirst_hal.Output.boxes,
        "scores": edgefirst_hal.Output.scores,
        "classes": edgefirst_hal.Output.classes,
        "mask_coefficients": edgefirst_hal.Output.mask_coefficients,
        "mask_coefs": edgefirst_hal.Output.mask_coefficients,
        "protos": edgefirst_hal.Output.protos,
        "mask": edgefirst_hal.Output.mask,
        "detection": edgefirst_hal.Output.detection,
        "segmentation": edgefirst_hal.Output.segmentation,
    }

    dv_raw = None
    for o in outs:
        dv_raw = o.get("decoder_version") or dv_raw
    dv_raw = dv_raw or hal_metadata.get("decoder_version")
    dv = _hal_decoder_version(dv_raw)

    hal_outputs = []
    for o in outs:
        t = o.get("type", "detection")
        make = factory.get(t, edgefirst_hal.Output.detection)
        # HAL takes shape XOR dshape: dshape carries sizes too, so when
        # the metadata declares dshape we let HAL derive shape from it
        # (and apply the physical→canonical permutation). Without
        # dshape, HAL assumes the declared shape is canonical for the
        # role — fine for TFLite NHWC protos but wrong for ARA-2 NCHW.
        dshape = _hal_dshape(o.get("dshape"))
        if dshape is not None:
            out = make(dshape=dshape)
        else:
            out = make(shape=o.get("shape"))
        q = o.get("quantization")
        if isinstance(q, (list, tuple)) and len(q) == 2:
            out.with_quantization(float(q[0]), int(q[1]))
        elif isinstance(q, dict):
            out.with_quantization(
                float(q.get("scale", q.get("qn", 0.0))),
                int(q.get("zero_point", q.get("offset", 0))),
            )
        hal_outputs.append(out)

    kwargs = dict(score_threshold=score_threshold,
                  iou_threshold=iou_threshold,
                  nms=nms)
    if dv is not None:
        kwargs["decoder_version"] = dv
    return edgefirst_hal.Decoder.new_from_outputs(hal_outputs, **kwargs)


def _hal_dshape(dshape):
    """Convert metadata dshape to HAL's [(DimName, size), ...] form.

    The validator carries dshape as either a list of single-key dicts
    (``[{"batch": 1}, {"num_protos": 32}, ...]`` from edgefirst.json
    schema-v2) or a list of [name, value] pairs (legacy). HAL expects
    a Vec of (PyDimName, usize). Returns None when dshape is missing
    or any entry's name doesn't map to a known DimName so the caller
    can fall back to canonical-shape semantics.
    """
    if not dshape:
        return None
    if not _HAL_AVAILABLE:
        return None
    name_map = {
        "batch": edgefirst_hal.DimName.Batch,
        "height": edgefirst_hal.DimName.Height,
        "width": edgefirst_hal.DimName.Width,
        "num_classes": edgefirst_hal.DimName.NumClasses,
        "num_features": edgefirst_hal.DimName.NumFeatures,
        "num_boxes": edgefirst_hal.DimName.NumBoxes,
        "num_protos": edgefirst_hal.DimName.NumProtos,
        "num_anchors_x_features": edgefirst_hal.DimName.NumAnchorsXFeatures,
        "padding": edgefirst_hal.DimName.Padding,
        "box_coords": edgefirst_hal.DimName.BoxCoords,
    }
    out = []
    for entry in dshape:
        if isinstance(entry, dict):
            if len(entry) != 1:
                return None
            name, value = next(iter(entry.items()))
        elif isinstance(entry, (list, tuple)) and len(entry) == 2:
            name, value = entry
        else:
            return None
        dim = name_map.get(str(name).lower())
        if dim is None:
            return None
        out.append((dim, int(value)))
    return out


def _hal_decoder_version(name):
    """Map a validator/string decoder_version to HAL's DecoderVersion enum."""
    if name is None:
        return None
    alias = {
        "yolov5": "Yolov5",
        "yolov8": "Yolov8",
        "ultralytics": "Yolov8",
        "yolo11": "Yolo11",
        "yolo26": "Yolo26",
    }
    key = alias.get(str(name).lower())
    if key is None:
        return None
    return getattr(edgefirst_hal.DecoderVersion, key, None)

if TYPE_CHECKING:
    from edgefirst.validator.evaluators import ModelParameters, TimerContext

DetOutput = Tuple[npt.NDArray[np.float32], 
                  npt.NDArray[np.float32], npt.NDArray[np.uintp]]
SegDetOutput = Tuple[npt.NDArray[np.float32],
                     npt.NDArray[np.float32],
                     npt.NDArray[np.uintp],
                     Union[None, npt.NDArray[np.uint8],
                           List[npt.NDArray[np.uint8]]]]


# Cache for Tensor buffers to avoid per-call allocation.
# Keyed by (shape, dtype) -> Tensor.
_TENSOR_CACHE: dict = {}


class Runner:
    """
    Abstract class that provides a template for the other runner classes.

    Parameters
    ----------
    model: Any
        This is typically the path to the model file or a loaded model.
    parameters: Parameters
        These are the model parameters set from the command line.
    timer: TimerContext
        A timer object for handling validation timings for the model.

    Raises
    ------
    FileNotFoundError
        Raised if the path to the model does not exist.
    """

    def __init__(self, model: Any, parameters: ModelParameters,
                 timer: TimerContext):
        self.model = model
        self.parameters = parameters
        self.timer = timer

        self.graph_name = "main_graph"
        self.outputs = None
        self.decoder = None
        self.input_shape = None
        self.input_dtype = None
        self.height, self.width = 0, 0

        from edgefirst.validator.datasets.utils.image_transforms import \
            image_processor
        self._hal_processor = image_processor

    def init_decoder(
            self, metadata: dict, outputs: Union[List[dict], List[np.ndarray]]):
        """
        Parse the model metadata and initialize the HAL decoder.

        Parameters
        ----------
        metadata: dict
            The contents of the model metadata for decoding the outputs.
        outputs: Union[List[dict], List[np.ndarray]]
            This is either a List[dict] from a TFLite output details
            or a List[np.ndarray] containing the shapes from the model outputs.
        """
        self.input_dtype = self.get_input_type()
        shape = self.get_input_shape()
        # Replace None with 1 for the batch size [None, height, width, 3]
        self.input_shape = np.array([d if d is not None else 1 for d in shape])
        self.height, self.width = get_shape(self.input_shape)
        self.parameters.common.dtype = self.input_dtype
        self.parameters.common.shape = self.input_shape

        # Parse the model output details in the metadata.
        self.outputs = Outputs(
            metadata=metadata,
            parameters=self.parameters,
            outputs=outputs,
        )

        if self.parameters.nms == "hal":
            if _HAL_AVAILABLE:
                # End-to-end models have NMS embedded — pass None.
                # Determined by validation.nms: none in metadata, not by
                # decoder_version (e.g. yolo26 can be trained without e2e).
                is_end2end = (
                    metadata.get("validation", {}).get("nms") == "none"
                ) if metadata else False

                if is_end2end:
                    nms_mode = None
                elif self.parameters.agnostic_nms:
                    nms_mode = edgefirst_hal.Nms.ClassAgnostic
                else:
                    nms_mode = edgefirst_hal.Nms.ClassAware

                # Normalize metadata for HAL compatibility.
                hal_metadata = self.outputs.metadata
                if hal_metadata:
                    outputs_list = hal_metadata.get("outputs", [])
                    for output in outputs_list:
                        # Infer 'type' from the output name when metadata
                        # omits it (the converter does not always emit
                        # it on quantization_split segmentation heads).
                        if "type" not in output:
                            output["type"] = _infer_output_type(
                                output.get("name", ""), output.get("shape"))

                        # HAL 0.17's Yolo decoder rejects
                        # ConfigOutput::Segmentation alongside split
                        # boxes/scores/mask_coefs. Converters still emit
                        # `type: "segmentation"` for the mask proto plane
                        # ([batch, H, W, num_protos]); rewrite to "protos"
                        # when the shape fits that pattern.
                        if output.get("type") == "segmentation":
                            shape = output.get("shape") or []
                            try:
                                shape = list(shape)
                            except TypeError:
                                shape = []
                            if (len(shape) == 4 and shape[1] == shape[2]
                                    and shape[-1] <= 64):
                                output["type"] = "protos"

                        # Convert dict quantization (e.g.
                        # {"scale": 0.5, "zero_point": 0}) to the
                        # [scale, zero_point] list HAL expects.
                        q = output.get("quantization")
                        if isinstance(q, dict):
                            scale = q.get("scale", q.get("qn", 0.0))
                            zp = q.get("zero_point", q.get("offset", 0))
                            output["quantization"] = [scale, zp]

                    # HAL interprets root-level decoder_version as
                    # end-to-end (single combined output).  For split-
                    # decoder models (multiple outputs) move it to each
                    # output so HAL applies version-specific decoding
                    # without the end-to-end constraint.
                    dv = hal_metadata.pop("decoder_version", None)
                    if dv and len(outputs_list) > 1:
                        for output in outputs_list:
                            output.setdefault("decoder_version", dv)

                # Split-decoder models (typed outputs) must go through
                # the programmatic `new_from_outputs` path — HAL's JSON
                # dict parser rejects the flat (1, C, anchors) layout
                # produced by quantization_split segmentation heads.
                if hal_metadata and _is_split_decoder(hal_metadata):
                    self.decoder = _build_split_decoder(
                        hal_metadata,
                        score_threshold=self.parameters.score_threshold,
                        iou_threshold=self.parameters.iou_threshold,
                        nms=nms_mode,
                    )
                else:
                    self.decoder = edgefirst_hal.Decoder(
                        hal_metadata,
                        score_threshold=self.parameters.score_threshold,
                        iou_threshold=self.parameters.iou_threshold,
                        nms=nms_mode
                    )
            else:
                raise ImportError(
                    "EdgeFirst HAL is needed to perform decoding using hal."
                )

    def _normalize_boxes_hal(self, boxes: np.ndarray) -> np.ndarray:
        """
        Normalize bounding boxes using HAL decoder's normalized_boxes property.

        Uses the decoder's metadata-driven normalized_boxes property when available,
        falling back to heuristic detection when the metadata doesn't specify.

        Parameters
        ----------
        boxes : np.ndarray
            Bounding boxes with shape (n, 4) in [xmin, ymin, xmax, ymax] format.

        Returns
        -------
        np.ndarray
            Normalized bounding boxes in [0, 1] range.
        """
        if not hasattr(self, 'decoder') or self.decoder is None:
            return check_normalized_boxes(boxes, width=self.width, height=self.height)

        # Use HAL's normalized_boxes property if available
        normalized = self.decoder.normalized_boxes
        if normalized is not None:
            if not normalized:
                # Boxes are in pixel coordinates, normalize them
                boxes = boxes.copy()
                boxes[:, [0, 2]] /= self.width
                boxes[:, [1, 3]] /= self.height
            # If normalized is True, boxes are already in [0, 1] range
            return boxes

        # Fallback to heuristic when metadata doesn't specify
        return check_normalized_boxes(boxes, width=self.width, height=self.height)

    def load_model_metadata(self) -> Union[dict, None]:
        """
        Returns the model metadata for decoding the outputs.

        Parameters
        ----------
        model_path: str
            The path to the model.
        """
        logger(
            "Reading the metadata for this model is not yet fully implemented.",
            code="WARNING")

        metadata = None
        if self.parameters.config_path is not None:
            if os.path.exists(self.parameters.config_path):
                with open(self.parameters.config_path, encoding="utf-8") as file:
                    metadata = yaml.safe_load(file)
            else:
                logger(
                    f"The model metadata path '{self.parameters.config_path}' does not exist.",
                    code="WARNING")

        if self.parameters.labels_path is not None:
            if os.path.exists(self.parameters.labels_path):
                with open(self.parameters.labels_path, 'r', encoding="utf-8") as f:
                    self.parameters.labels = [
                        line.rstrip()
                        for line in f.readlines()
                        if line not in ["\n", "", "\t"]
                    ]
            else:
                logger(
                    f"The labels file path '{self.parameters.labels_path}' does not exist.",
                    code="WARNING")

        self.set_metadata_parameters(metadata)
        return metadata

    def set_metadata_parameters(self, metadata: Union[dict, None]):
        """
        Sets the parameters specified in the model metadata.
        Validate with the model metadata parameters.
        By default in the command line override is set to False to use
        the command line parameters. Otherwise it will use
        model meta parameters.

        Parameters
        ----------
        metadata: Union[dict, None]
            The contents of the model metadata for decoding the outputs.
        """

        if metadata is not None:
            # Always extract camera adaptor from metadata if present
            camera_adaptor = metadata.get("input", {}).get("cameraadaptor")
            if camera_adaptor:
                self.parameters.common.camera_adaptor = camera_adaptor

            # Read root-level nms field for HAL class-agnostic/aware behavior
            root_nms = metadata.get("nms")
            if root_nms == "class_aware":
                self.parameters.agnostic_nms = False
            elif root_nms == "class_agnostic":
                self.parameters.agnostic_nms = True

        if self.parameters.override and metadata is not None:
            self.parameters.score_threshold = metadata\
                .get("validation", {}).get("score",
                                           self.parameters.score_threshold)
            self.parameters.iou_threshold = metadata\
                .get("validation", {}).get("iou",
                                           self.parameters.iou_threshold)
            self.parameters.common.norm = metadata\
                .get("validation", {}).get("normalization",
                                           self.parameters.common.norm)
            self.parameters.common.preprocessing = metadata\
                .get("validation", {}).get("preprocessing",
                                           self.parameters.common.preprocessing)

    def warmup(self, sample_image: Optional[str] = None):
        """
        Run model warmup.

        Parameters
        ----------
        sample_image: Optional[str]
            A sample image path for performing model warmup. If not provided,
            a dummy image will be used based on the input shape and dtype. 
        """

        logger("Running model warmup...", code="INFO")

        times = []

        for _ in range(self.parameters.warmup):
            start = time.perf_counter()
            # Warmup input preprocessing.
            if self.parameters.common.backend == "hal":
                if _HAL_AVAILABLE:
                    if sample_image is not None and os.path.exists(sample_image):
                        image = edgefirst_hal.Tensor.load(
                            sample_image, format=edgefirst_hal.PixelFormat.Rgba)
                    else:
                        image = self._hal_processor.create_image(
                            self.width, self.height, edgefirst_hal.PixelFormat.Rgba)
                    image, _, _, _ = preprocess_hal(
                        image=image,
                        input_shape=self.input_shape,
                        input_dtype=self.input_dtype,
                        view_tensor=self.parameters.common.view_tensor,
                        preprocessing=self.parameters.common.preprocessing,
                        normalization=self.parameters.common.norm,
                        quantization=self.parameters.common.input_quantization,
                        camera_adaptor=getattr(self.parameters.common, 'camera_adaptor', None),
                    )
                else:
                    raise ImportError(
                        "EdgeFirst HAL is needed to perform preprocessing using hal.")
            else:
                if sample_image is not None and os.path.exists(sample_image):
                    image = Image.open(sample_image)
                    image = np.array(image)
                else:
                    # Create warmup image - use 3 channels (RGB) as input since
                    # preprocess_native handles color conversion based on camera_adaptor
                    warmup_channels = 3
                    image = np.zeros(
                        (self.height, self.width, warmup_channels), dtype=np.uint8)
                image, _, _, _ = preprocess_native(
                    image=image,
                    input_shape=self.input_shape,
                    input_dtype=self.input_dtype,
                    view_tensor=self.parameters.common.view_tensor,
                    preprocessing=self.parameters.common.preprocessing,
                    normalization=self.parameters.common.norm,
                    quantization=self.parameters.common.input_quantization,
                    backend=self.parameters.common.backend,
                    camera_adaptor=getattr(self.parameters.common, 'camera_adaptor', None),
                )
            # run_single_instance already runs the full validation hot
            # path: inference + post-processing (HAL decode +
            # materialize_masks). Wrap so a degenerate all-zero
            # output that trips the decoder doesn't abort warmup.
            try:
                self.run_single_instance(image)
            except Exception:  # pylint: disable=broad-exception-caught
                traceback.print_exc()

            elapsed = time.perf_counter() - start
            times.append(elapsed * 1e3)  # Convert to ms

        message = "model warmup took %f ms (%f ms avg)" % (np.sum(times),
                                                           np.average(times))
        logger(message, code="INFO")
        self.timer.reset()

    def run_single_instance(self, image: Union[str, np.ndarray]) -> Any:
        """Abstract Method"""

    def postprocessing(self, outputs: Union[list, np.ndarray]) -> Any:
        """
        Postprocess outputs into boxes, scores, labels or masks.
        This method will perform NMS operations where the outputs
        will be transformed into the following format.

        Models trained using ModelPack separates the outputs and
        directly return the NMS bounding boxes, scores, and
        labels as described below.

        Models converted in YOLOv5 will be a list of length 1 which
        has a shape of (1, number of boxes, 6) and formatted as
        [[[xmin, ymin, xmax, ymax, confidence, label], [...], ...]].

        Models converted in YOLOv7 will directly extract the
        bounding boxes, scores, and labels from the outputs.

        Parameters
        ----------
        outputs: Union[list, np.ndarray]
            ModelPack outputs will be a list with varying lengths
            which could either contain bounding boxes, scores, labels,
            or masks (encoded and decoded).

            Models converted in YOLOv5 has the following shape
            (batch size, number of boxes, number of classes).

            Models converted in YOLOv7 will already have NMS embedded. The
            output has a shape of (number of boxes, 7) and formatted as
            [[batch_id, xmin, ymin, xmax, ymax, cls, score], ...].

        Returns
        -------
        Any
            This could either return detection outputs after NMS.
                np.ndarray
                    The prediction bounding boxes.. [[box1], [box2], ...].
                np.ndarray
                    The prediction confidence scores.. [score, score, ...]
                    normalized between 0 and 1.
                np.ndarray
                    The prediction labels.. [cl1, cl2, ...].
            This could also return segmentation masks.
                np.ndarray
        """
        masks = None

        # MobileNet SSD
        if self.outputs.classes["index"] is not None:
            with self.timer.time("output"):
                outputs = outputs[0] if len(outputs) == 1 else outputs
                outputs = outputs.numpy() if not isinstance(
                    outputs, (np.ndarray, list)) else outputs

                boxes, classes, scores, _ = outputs
                boxes = np.squeeze(boxes)
                classes = np.squeeze(classes).astype(np.uintp)
                scores = np.squeeze(scores)
        # ModelPack or Kinara
        elif len(self.outputs.mpk_types) > 0 or (None not in
                                                 [self.outputs.boxes["index"],
                                                  self.outputs.scores["index"]]):
            with self.timer.time("output"):
                # Kinara
                if self.outputs.boxes["decoder"] == "ultralytics":
                    if self.parameters.nms == "hal":
                        boxes, scores, classes, masks = self.process_yolo_hal(
                            outputs)
                    else:
                        boxes, scores, classes, masks = self._process_yolo_split(
                            outputs)

                # ModelPack
                else:
                    if self.parameters.nms == "hal":
                        boxes, scores, classes, masks = self.process_mpk_hal(
                            outputs)
                    else:
                        boxes, scores, classes, masks = self.process_mpk(
                            outputs)
        else:
            # YOLOx
            if (self.graph_name not in ["main_graph", "torch_jit", "tf2onnx"]
                    and outputs[0].shape[-1] == 85):

                # HAL decoder/NMS is not yet supported and fallback to NumPy.
                if self.parameters.nms == "hal":
                    self.parameters.nms = "numpy"

                with self.timer.time("output"):
                    boxes, scores, classes = self.process_yolox(
                        outputs=outputs)

            # YOLOv5, YOLOv8, YOLOv11 models.
            else:
                with self.timer.time("output"):
                    # End-to-end YOLO26 models. Output looks like embedded NMS
                    s = outputs[0].shape if hasattr(outputs[0], 'shape') else None
                    if self.parameters.nms == "hal":
                        # HAL decoder handles both traditional and end-to-end
                        boxes, scores, classes, masks = self.process_yolo_hal(
                            outputs)
                    elif self.parameters.nms == "none" or (s is not None
                        and len(s) == 3 and 6 <= s[-1] <= 40 and s[1] <= 1000):
                        boxes, scores, classes, masks = self.process_yolo26(
                            outputs)
                    else:
                        boxes, scores, classes, masks = self.process_yolo(
                            outputs)

        if self.parameters.common.with_boxes:
            if self.parameters.box_format == "xcycwh":
                boxes = xyxy2xcycwh(boxes)
            elif self.parameters.box_format == "xywh":
                boxes = xyxy2xywh(boxes)

            if self.parameters.label_offset != 0:
                classes += self.parameters.label_offset

            if self.parameters.common.with_masks:
                return boxes, scores, classes, masks
            else:
                return boxes, scores, classes
        else:
            return masks

    def process_mpk_hal(self, outputs: List[np.ndarray]) -> SegDetOutput:
        """
        ModelPack output decoding and postprocessing using the HAL decoder.

        Parameters
        ----------
        outputs: List[np.ndarray]
            ModelPack outputs will be a list with varying lengths
            which could either contain bounding boxes, scores, labels,
            or masks (encoded and decoded).

        Returns
        -------
        boxes : np.ndarray
            This contains decoded and valid bounding boxes post NMS.
        scores : np.ndarray
            This contains decoded and valid scores post NMS.
        classes : np.ndarray
            This contains decoded and valid classes post NMS.
        masks: np.ndarray
            This is the semantic segmentation mask output from
            ModelPack. If the model is not a segmentation model,
            None is returned.
        """

        if not _HAL_AVAILABLE:
            raise ImportError(
                "EdgeFirst HAL is needed to perform decoding using hal."
            )

        tensor_outputs = []
        for output in outputs:
            src_key = (tuple(output.shape), output.dtype.name)
            tensor = _TENSOR_CACHE.get(src_key)
            if tensor is None:
                tensor = edgefirst_hal.Tensor(
                    list(output.shape), dtype=output.dtype.name)
                _TENSOR_CACHE[src_key] = tensor
            tensor.from_numpy(output)
            tensor_outputs.append(tensor)

        # The decode function in HAL returns a 3D array for the masks.
        # Needs an argmax to convert to semantic segmentation.
        boxes, scores, classes, masks = self.decoder.decode(
            tensor_outputs, max_boxes=self.parameters.max_detections)

        # Decoded masks.
        if self.outputs.masks["index"] is not None:
            masks = np.squeeze(
                outputs[self.outputs.masks["index"]]).astype(np.uint8)
            # Resize the mask to the model input shape.
            masks = resize(masks, size=(self.width, self.height))
        # Deploy argmax to the mask and convert to semantic segmentation.
        elif len(masks):
            masks = self.decoder.segmentation_to_mask(masks[0])
            # Resize the mask to the model input shape.
            masks = resize(masks, size=(self.width, self.height))

        return boxes, scores, classes, masks

    def process_mpk(self, outputs: List[np.ndarray]) -> SegDetOutput:
        """
        ModelPack output decoding and postprocessing.

        Parameters
        ----------
        outputs: List[np.ndarray]
            ModelPack outputs will be a list with varying lengths
            which could either contain bounding boxes, scores, labels,
            or masks (encoded and decoded).

        Returns
        -------
        boxes : np.ndarray
            This contains decoded and valid bounding boxes post NMS.
        scores : np.ndarray
            This contains decoded and valid scores post NMS.
        classes : np.ndarray
            This contains decoded and valid classes post NMS.
        masks: np.ndarray
            This is the semantic segmentation mask output from
            ModelPack. If the model is not a segmentation model,
            None is returned.
        """

        outputs = outputs[0] if len(outputs) == 1 else outputs
        outputs = outputs.numpy() if not isinstance(
            outputs, (np.ndarray, list)) else outputs

        boxes, scores = [], []
        classes, masks = None, None

        # Masks Already Decoded
        if self.outputs.masks["index"] is not None:
            masks = np.squeeze(
                outputs[self.outputs.masks["index"]]).astype(np.uint8)
            masks = resize(masks, size=(self.width, self.height),
                           backend=self.parameters.common.backend)

        # Outputs Already Decoded
        if None not in [self.outputs.boxes["index"],
                        self.outputs.scores["index"]]:

            # Dequantize Outputs
            boxes = outputs[self.outputs.boxes["index"]]
            if (self.outputs.boxes["quantization"] is not None and
                    boxes.dtype != np.float32):
                boxes = dequantize(boxes, *self.outputs.boxes["quantization"])

            scores = outputs[self.outputs.scores["index"]]
            if (self.outputs.scores["quantization"] is not None and
                    scores.dtype != np.float32):
                scores = dequantize(
                    scores, *self.outputs.scores["quantization"])

        # Decode and Dequantize Outputs
        elif len(self.outputs.mpk_types) > 0:
            for context in self.outputs.mpk_types:
                x = outputs[context["index"]]
                if context["quantization"] is not None and x.dtype != np.float32:
                    x = dequantize(x, *context["quantization"])

                if context["type"] == "detection":
                    box, score = decode_mpk_boxes(
                        p=x, anchors=context["anchors"])
                    boxes.append(box)
                    scores.append(score)

                elif context["type"] == "segmentation" and masks is None:
                    masks = np.squeeze(decode_mpk_masks(masks=x))
                    masks = resize(masks, size=(self.width, self.height),
                                   backend=self.parameters.common.backend)

            if 0 not in [len(boxes), len(scores)]:
                scores = np.concatenate(scores, axis=1).astype(np.float32)
                boxes = np.concatenate(boxes, axis=1).astype(np.float32)

        # Postprocess Outputs
        if 0 not in [len(boxes), len(scores)]:
            boxes = np.squeeze(boxes, axis=0)
            scores = np.squeeze(scores, axis=0)

            boxes, scores, classes, _ = nms(
                boxes=boxes,
                scores=scores,
                iou_threshold=self.parameters.iou_threshold,
                score_threshold=self.parameters.score_threshold,
                max_detections=self.parameters.max_detections,
                class_agnostic=self.parameters.agnostic_nms,
                nms_type=self.parameters.nms
            )
            # Normalize bounding boxes if not already.
            boxes = check_normalized_boxes(
                boxes, width=self.width, height=self.height)
        return boxes, scores, classes, masks

    def _process_yolo_split(self, outputs: List[np.ndarray]) -> SegDetOutput:
        """
        Decode split YOLO outputs (boxes, scores, mask_coefficients as
        separate tensors). Shared path for both ARA2/Kinara and TFLite
        split outputs. Handles quantized integer inputs (uint8/int8/int16)
        with per-output dequantization.

        Parameters
        ----------
        outputs: List[np.ndarray]
            List of output arrays indexed by output type.
            The outputs have shapes like the following 
            [(1, 32, 160, 160), (1, 32, 8400), (1, 80, 8400), (1, 4, 8400)]
            which translates to [masks, mask coefficients, scores, boxes]

        Returns
        -------
        boxes : np.ndarray
            Decoded and valid bounding boxes post NMS.
        scores : np.ndarray
            Decoded and valid scores post NMS.
        classes : np.ndarray
            Decoded and valid classes post NMS.
        masks : np.ndarray or None
            Instance segmentation masks, or None.
        """

        # 1. Read and dequantize each output independently
        boxes_raw = outputs[self.outputs.boxes["index"]]
        if (self.outputs.boxes["quantization"] is not None
                and boxes_raw.dtype != np.float32):
            boxes = dequantize(boxes_raw, *self.outputs.boxes["quantization"])
        else:
            boxes = boxes_raw.astype(np.float32)

        scores_raw = outputs[self.outputs.scores["index"]]
        if (self.outputs.scores["quantization"] is not None
                and scores_raw.dtype != np.float32):
            scores = dequantize(scores_raw,
                                *self.outputs.scores["quantization"])
        else:
            scores = scores_raw.astype(np.float32)

        mask_coeffs = None
        if (self.outputs.mask_coefficients["index"] is not None):
            mc_raw = outputs[self.outputs.mask_coefficients["index"]]
            if (self.outputs.mask_coefficients["quantization"] is not None
                    and mc_raw.dtype != np.float32):
                mask_coeffs = dequantize(
                    mc_raw,
                    *self.outputs.mask_coefficients["quantization"])
            else:
                mask_coeffs = mc_raw.astype(np.float32)

        # 2. Reshape to [anchors, features] — handle both NCHW and NHWC
        if boxes.ndim == 3 and boxes.shape[0] == 1:
            boxes = boxes[0]  # remove batch dim
        if boxes.ndim == 2 and boxes.shape[0] < boxes.shape[1]:
            boxes = boxes.T  # [C, N] → [N, C]

        if scores.ndim == 3 and scores.shape[0] == 1:
            scores = scores[0]
        if scores.ndim == 2 and scores.shape[0] < scores.shape[1]:
            scores = scores.T

        if mask_coeffs is not None:
            if mask_coeffs.ndim == 3 and mask_coeffs.shape[0] == 1:
                mask_coeffs = mask_coeffs[0]
            if mask_coeffs.ndim == 2 and mask_coeffs.shape[0] < mask_coeffs.shape[1]:
                mask_coeffs = mask_coeffs.T

        # 3. Convert boxes to xyxy format
        boxes = xcycwh2xyxy(boxes)

        # 4. NMS
        boxes, scores, classes, mask_coeffs = nms(
            boxes=boxes,
            scores=scores,
            masks=mask_coeffs,
            iou_threshold=self.parameters.iou_threshold,
            score_threshold=self.parameters.score_threshold,
            max_detections=self.parameters.max_detections,
            class_agnostic=self.parameters.agnostic_nms,
            nms_type=self.parameters.nms
        )

        # 5. Normalize boxes
        boxes = check_normalized_boxes(
            boxes, width=self.width, height=self.height)

        # 6. Decode masks
        masks = None
        if mask_coeffs is not None and self.outputs.masks["index"] is not None:
            protos_raw = outputs[self.outputs.masks["index"]]
            if (self.outputs.masks["quantization"] is not None
                    and protos_raw.dtype != np.float32):
                protos = dequantize(protos_raw,
                                    *self.outputs.masks["quantization"])
            else:
                protos = protos_raw.astype(np.float32)
            masks = decode_yolo_masks(mask_coeffs, protos=protos)
            if masks.shape[0] > 0:
                masks = process_masks_retina(
                    masks, boxes, self.width, self.height)

        return boxes, scores, classes, masks

    def process_yolo_hal(self, outputs: List[np.ndarray]) -> SegDetOutput:
        """
        Utralytics YOLO output decoding and postprocessing using the
        HAL decoder.

        Parameters
        ----------
        outputs: List[np.ndarray]
            Models converted in YOLOv5 has the following shape
            (batch size, number of boxes, number of classes) for detection.

            Models converted in YOLOv7 will already have NMS embedded. The
            output has a shape of (number of boxes, 7) and formatted as
            [[batch_id, xmin, ymin, xmax, ymax, cls, score], ...].

            For segmentation models, this will contain two arrays containing
            the detection and segmentation outputs.

        Returns
        -------
        boxes : np.ndarray
            This contains decoded and valid bounding boxes post NMS.
        scores : np.ndarray
            This contains decoded and valid scores post NMS.
        classes : np.ndarray
            This contains decoded and valid classes post NMS.
        masks: np.ndarray
            This is the instance segmentation mask outputs from
            Ultralytics. If the model is not a segmentation model,
            None is returned.
        """

        if not _HAL_AVAILABLE:
            raise ImportError(
                "EdgeFirst HAL is needed to perform decoding using hal."
            )

        x = outputs[self.outputs.scores["index"]]
        # NOTE: HAL Decoder requires normalized bounding boxes.
        if x.dtype in [np.float32, np.float16]:
            x[:, :4, :] = check_normalized_boxes(
                x[:, :4, :], width=self.width, height=self.height)
            outputs[self.outputs.scores["index"]] = x

        tensor_outputs = []
        for output in outputs:
            src_key = (tuple(output.shape), output.dtype.name)
            tensor = _TENSOR_CACHE.get(src_key)
            if tensor is None:
                tensor = edgefirst_hal.Tensor(
                    list(output.shape), dtype=output.dtype.name)
                _TENSOR_CACHE[src_key] = tensor
            tensor.from_numpy(output)
            tensor_outputs.append(tensor)

        boxes, scores, classes, proto_data = self.decoder.decode_proto(
            tensor_outputs, max_boxes=self.parameters.max_detections
        )

        # Filter invalid 0-dimension boxes when there is no per-box
        # auxiliary state to keep aligned. With proto_data the
        # mask_coefficients array is indexed by detection and has no
        # public setter on the HAL side, so re-indexing boxes here
        # desyncs materialize_masks (rejects mismatched counts).
        # Degenerate boxes produce empty mask tiles in the paste
        # loop below and IoU=0 against GT, so leaving them in place
        # is safe — they just contribute noise of the same order as
        # the box-only path's filtered-out entries did.
        if proto_data is None:
            valid = np.where((boxes[..., 0] < boxes[..., 2]) &
                             (boxes[..., 1] < boxes[..., 3]))[0]
            boxes = boxes[valid]
            scores = scores[valid]
            classes = classes[valid]

        # Detection-only models: decode_proto returns proto_data=None.
        # Segmentation models: choose between 'proto' and 'scaled' output
        # resolutions (matches Ultralytics' process_mask / process_mask_native).
        #
        # - 'proto'  — per-detection mask at the proto-plane resolution
        #   (typically input/4, e.g. 160x160 for a 640-input yolov8-seg).
        #   16x less pixels → 16x less cost in downstream mask IoU
        #   matching, at the price of ~0.1 mAP vs the scaled path.
        # - 'scaled' (retina) — HAL upsamples the full proto plane once
        #   to model input resolution and crops per bbox. Matches the
        #   older retina behaviour; pick this when you care about the
        #   last fraction of a point of mAP.
        masks: Union[list, np.ndarray] = []
        mask_resolution = (
            getattr(self.parameters.common, "mask_resolution", "proto")
            or "proto")

        if proto_data is not None and len(boxes) > 0:
            if mask_resolution == "scaled":
                target_w, target_h = self.width, self.height
                hal_resolution = edgefirst_hal.MaskResolution.Scaled(
                    target_w, target_h)
            else:
                # Proto-plane resolution is hard-coded to input/4 —
                # matches the YOLOv5/v8/v11/v26-seg architectures and
                # the split-DFL metadata we consume.
                target_w, target_h = self.width // 4, self.height // 4
                hal_resolution = edgefirst_hal.MaskResolution.Proto()

            mask_tiles = self._hal_processor.materialize_masks(
                boxes, scores, classes, proto_data,
                letterbox=None,
                resolution=hal_resolution,
            )
            padded = np.zeros(
                (len(mask_tiles), target_h, target_w), dtype=np.float32)
            for i, (m, b) in enumerate(zip(mask_tiles, boxes)):
                left = int(round(b[0] * target_w))
                top = int(round(b[1] * target_h))
                mh, mw = m.shape[0], m.shape[1]
                # Clip paste region: YOLO can predict bboxes whose edges
                # extend past the target, and HAL sizes each tile to the
                # raw bbox extent.
                dst_l, dst_t = max(left, 0), max(top, 0)
                dst_r = min(left + mw, target_w)
                dst_b = min(top + mh, target_h)
                if dst_r <= dst_l or dst_b <= dst_t:
                    continue
                src_t, src_l = dst_t - top, dst_l - left
                src_b = src_t + (dst_b - dst_t)
                src_r = src_l + (dst_r - dst_l)
                padded[i, dst_t:dst_b, dst_l:dst_r] = (
                    m[src_t:src_b, src_l:src_r, 0] > 127
                )
            masks = padded

        return boxes, scores, classes, masks

    def process_yolo(self, outputs: List[np.ndarray]) -> SegDetOutput:
        """
        Utralytics YOLO output decoding and postprocessing.

        Parameters
        ----------
        outputs: List[np.ndarray]
            Models converted in YOLOv5 has the following shape
            (batch size, number of boxes, number of classes) for detection.

            Models converted in YOLOv7 will already have NMS embedded. The
            output has a shape of (number of boxes, 7) and formatted as
            [[batch_id, xmin, ymin, xmax, ymax, cls, score], ...].

            For segmentation models, this will contain two arrays containing
            the detection and segmentation outputs.

        Returns
        -------
        boxes : np.ndarray
            This contains decoded and valid bounding boxes post NMS.
        scores : np.ndarray
            This contains decoded and valid scores post NMS.
        classes : np.ndarray
            This contains decoded and valid classes post NMS.
        masks: np.ndarray
            This is the instance segmentation mask outputs from
            Ultralytics. If the model is not a segmentation model,
            None is returned.
        """
        outputs = outputs[0] if len(outputs) == 1 else outputs
        outputs = outputs.numpy() if not isinstance(
            outputs, (np.ndarray, list)) else outputs

        # Dequantize Outputs
        x = outputs[self.outputs.scores["index"]]
        x = x.astype(np.float32) if x.dtype == np.float16 else x
        if (self.outputs.scores["quantization"] is not None and
                x.dtype != np.float32):
            x = dequantize(x, *self.outputs.scores["quantization"])

        # Decode Outputs
        boxes, scores, masks = decode_yolo_boxes(
            p=x,
            with_masks=self.parameters.common.with_masks,
            nc=(len(self.parameters.labels)
                if self.parameters.labels is not None else 0),
            score_format=self.outputs.scores.get("score_format")
        )

        # Run NMS
        boxes, scores, classes, masks = nms(
            boxes=boxes,
            scores=scores,
            masks=masks,
            iou_threshold=self.parameters.iou_threshold,
            score_threshold=self.parameters.score_threshold,
            max_detections=self.parameters.max_detections,
            class_agnostic=self.parameters.agnostic_nms,
            nms_type=self.parameters.nms
        )

        # Normalize bounding boxes if not already.
        boxes = check_normalized_boxes(
            boxes, width=self.width, height=self.height)

        # Decode Masks.
        if masks is not None:
            protos = outputs[self.outputs.masks["index"]]
            protos = protos.astype(
                np.float32) if protos.dtype == np.float16 else protos

            if (self.outputs.masks["quantization"] is not None and
                    protos.dtype != np.float32):
                protos = dequantize(
                    protos, *self.outputs.masks["quantization"])
            masks = decode_yolo_masks(masks, protos=protos)

            # Mask postprocessing: upsample logits → crop → threshold.
            if masks.shape[0] > 0:
                masks = process_masks_retina(
                    masks, boxes, self.width, self.height)
            else:
                masks = np.zeros((0, self.height, self.width), dtype=np.uint8)

        return boxes, scores, classes, masks

    def process_yolo26(self, outputs: List[np.ndarray]) -> SegDetOutput:
        """
        YOLO26 output decoding. These are end-to-end models (e.g., YOLO26).
        No external NMS is required.
        
        Parameters
        ----------
        outputs: List[np.ndarray]
            YOLO26 outputs produce final detections directly
            in BNC format as [x1, y1, x2, y2, conf, class, ...mask_coefs].
            Detection: (1, max_det, 6), Segmentation: (1, max_det, 6+32).
            No external NMS is required.

        Returns
        -------
        boxes : np.ndarray
            This contains decoded and valid bounding boxes.
        scores : np.ndarray
            This contains decoded and valid scores.
        classes : np.ndarray
            This contains decoded and valid classes.
        masks: np.ndarray
            This is the instance segmentation mask outputs from
            Ultralytics. If the model is not a segmentation model,
            None is returned.
        """
        outputs = outputs[0] if len(outputs) == 1 else outputs
        outputs = outputs.numpy() if not isinstance(
            outputs, (np.ndarray, list)) else outputs

        masks = None
        # Dequantize Outputs (e.g., uint8 TFLite models)
        x = outputs[self.outputs.scores["index"]]
        x = np.squeeze(x)
        x = x.astype(np.float32) if x.dtype == np.float16 else x
        if (self.outputs.scores["quantization"] is not None and 
            x.dtype != np.float32):
            x = dequantize(x, *self.outputs.scores["quantization"])

        # Extract Detection Outputs
        boxes = x[:, 0:4]
        scores = x[:, 4]
        classes = x[:, 5]

        # Extract mask coefficients for segmentation models.
        # End-to-end seg: (N, 6+nm) where nm=32 mask coefficients.
        mask_coefficients = None
        if (self.parameters.common.with_masks
                and x.shape[-1] > 6):
            mask_coefficients = x[:, 6:]

        # Filter out zero-box padding rows
        filt = ~np.all(boxes == 0, axis=1)
        boxes = boxes[filt]
        scores = scores[filt]
        classes = classes[filt]
        if mask_coefficients is not None:
            mask_coefficients = mask_coefficients[filt]
        
        # Apply score threshold filter
        score_filt = scores >= self.parameters.score_threshold
        boxes = boxes[score_filt]
        scores = scores[score_filt]
        classes = classes[score_filt]
        if mask_coefficients is not None:
            mask_coefficients = mask_coefficients[score_filt]
        
        # Normalize bounding boxes if not already
        boxes = check_normalized_boxes(
            boxes, width=self.width, height=self.height)
        classes = classes.astype(np.uintp)

        # Decode instance masks from coefficients × prototypes
        if mask_coefficients is not None and len(outputs) > 1:
            protos = outputs[self.outputs.masks["index"]]
            protos = protos.astype(
                np.float32
            ) if protos.dtype == np.float16 else protos
            
            if (self.outputs.masks["quantization"] is not None
                    and protos.dtype != np.float32):
                protos = dequantize(
                    protos, *self.outputs.masks["quantization"])
            masks = decode_yolo_masks(
                mask_coefficients, protos=protos)
            
            if masks.shape[0] > 0:
                masks = process_masks_retina(
                    masks, boxes, self.width, self.height)

        return boxes, scores, classes, masks

    def process_yolox(self, outputs: List[np.ndarray]) -> DetOutput:
        """
        YOLOx output decoding and postprocessing.

        Parameters
        ----------
        outputs: List[np.ndarray]
            YOLOx raw output to postprocess into
            bounding boxes, scores, classes after NMS. This
            typically has the shape (1, 8400, 85).

        Returns
        -------
        boxes : np.ndarray
            This contains decoded and valid bounding boxes.
        scores : np.ndarray
            This contains decoded and valid scores.
        classes : np.ndarray
            This contains decoded and valid classes.
        """

        outputs = outputs[0] if len(outputs) == 1 else outputs
        outputs = outputs.numpy() if not isinstance(
            outputs, (np.ndarray, list)) else outputs

        if (self.outputs.scores["quantization"] is not None and
                outputs.dtype != np.float32):
            outputs = dequantize(outputs, *self.outputs.scores["quantization"])

        boxes, scores = decode_yolox_boxes(
            p=outputs,
            shape=(self.height, self.width)
        )
        boxes = xcycwh2xyxy(boxes=boxes)

        # Typical: nms_thr=0.45, score_thr=0.1
        dets = multiclass_nms(
            boxes=boxes,
            scores=scores,
            iou_threshold=self.parameters.iou_threshold,
            score_threshold=self.parameters.score_threshold,
            max_detections=self.parameters.max_detections,
            class_agnostic=self.parameters.agnostic_nms,
            nms_type=self.parameters.nms
        )
        if dets is None:
            return np.array([]), np.array([]), np.array([])

        boxes = dets[:, :4]
        scores = dets[:, 4]
        classes = dets[:, 5]

        # Normalize the bounding boxes.
        boxes = check_normalized_boxes(
            boxes, width=self.width, height=self.height)
        return boxes, scores, classes

    def get_input_type(self) -> np.dtype:
        """Abstract Method"""
        return np.float32

    def get_input_shape(self) -> np.ndarray:
        """Abstract Method"""
        return np.array([1, 640, 640, 3])
