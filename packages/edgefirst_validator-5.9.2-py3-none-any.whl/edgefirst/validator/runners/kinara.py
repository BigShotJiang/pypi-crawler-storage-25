"""
Implementations for the Kinara model runner.
"""

from __future__ import annotations

import json
import os
import time
import threading
import zipfile
from collections import namedtuple
from typing import TYPE_CHECKING, Any, Optional, Union

import numpy as np

try:
    import edgefirst_ara2 as ara2
except ImportError:
    ara2 = None

from edgefirst.validator.runners.core import Runner

if TYPE_CHECKING:
    from edgefirst.validator.evaluators import ModelParameters, TimerContext


_DTYPE_RANGES = {
    np.int8: (-128, 127),
    np.uint8: (0, 255),
    np.int16: (-32768, 32767),
    np.uint16: (0, 65535),
}


def _requantize(
    arr: np.ndarray,
    src_qn: float,
    src_off: int,
    dst_qn: float,
    dst_off: int,
) -> np.ndarray:
    """Re-express a quantized tensor under a new (qn, offset) pair.

    For each element, the source dequantized value is
    ``(raw - src_off) * src_qn``; we solve for the destination raw
    value under ``(raw' - dst_off) * dst_qn`` and round to the tensor's
    original dtype, preserving the dequantized meaning across the
    remap. If both (qn, offset) pairs already match, the input is
    returned unchanged.
    """
    if src_qn == dst_qn and src_off == dst_off:
        return arr
    lo, hi = _DTYPE_RANGES.get(arr.dtype.type, (None, None))
    scale = src_qn / dst_qn
    rescaled = (arr.astype(np.float32) - src_off) * scale + dst_off
    rounded = np.round(rescaled)
    if lo is not None:
        rounded = np.clip(rounded, lo, hi)
    return rounded.astype(arr.dtype)


def _normalize_shape(raw: tuple[int, ...]) -> list[int]:
    """Normalize an ARA-2 3D output shape to batched form.

    ARA-2 reports shapes as (C, H, W). For logically 2D outputs
    (e.g. scores [80, 8400]) the shape is padded as [80, 8400, 1].
    Strip trailing 1s and prepend batch=1 for the decoder.

      [80, 8400, 1]  -> [1, 80, 8400]
      [4, 8400, 1]   -> [1, 4, 8400]
      [32, 160, 160] -> [1, 32, 160, 160]
    """
    shape = list(raw)
    while len(shape) > 1 and shape[-1] == 1:
        shape.pop()
    shape.insert(0, 1)
    return shape


# Lightweight stand-in for the ``edgefirst_ara2.MetadataOutput`` dataclass.
# Used when reading schema_version:2 metadata directly from the embedded
# JSON so the rest of ``__init__`` can classify outputs by name using the
# same ``md_out.output_type`` / ``md_out.decoder`` attribute access.
_MetadataOutput = namedtuple("_MetadataOutput", ["name", "output_type", "decoder"])


def _read_embedded_json(dvm_path: str) -> dict | None:
    """Read ``edgefirst.json`` from the ZIP trailer of a DVM file.

    Returns the parsed dict, or ``None`` if the file is not a ZIP or
    does not contain ``edgefirst.json``.
    """
    if not isinstance(dvm_path, str) or not zipfile.is_zipfile(dvm_path):
        return None
    with zipfile.ZipFile(dvm_path) as zf:
        if "edgefirst.json" in zf.namelist():
            return json.loads(zf.read("edgefirst.json").decode("utf-8"))
    return None


def _v2_physical_outputs(v2_outputs: list[dict]) -> dict[str, _MetadataOutput]:
    """Build a ``layer_name → _MetadataOutput`` map from v2 two-layer outputs.

    Walks the logical/physical tree and emits one entry per physical
    tensor.  Logical outputs that have ``outputs[]`` children are
    expanded so each child is mapped by its ``name``.  Direct logical
    outputs (no children) map their own name.
    """
    result: dict[str, _MetadataOutput] = {}
    for logical in v2_outputs:
        decoder = logical.get("decoder")
        children = logical.get("outputs", [])
        if children:
            for child in children:
                name = child.get("name", "")
                result[name] = _MetadataOutput(
                    name=name,
                    output_type=child.get("type", ""),
                    decoder=decoder,
                )
        else:
            name = logical.get("name", "")
            result[name] = _MetadataOutput(
                name=name,
                output_type=logical.get("type", ""),
                decoder=decoder,
            )
    return result


def _strip_padding(shape: list[int],
                    dshape: list[dict] | None = None,
                    ) -> tuple[list[int], list[dict] | None]:
    """Strip trailing padding dimensions (value 1) from a shape.

    Preserves at least 2 dimensions so ``[1, 32, 160, 160]`` is
    returned unchanged while ``[1, 80, 8400, 1]`` becomes
    ``[1, 80, 8400]``.

    When *dshape* is provided, removes entries whose sole key is
    ``"padding"`` (with value 1) so the named-dimension list stays
    in sync with the stripped shape.
    """
    while len(shape) > 2 and shape[-1] == 1:
        shape = shape[:-1]
    if dshape is not None:
        dshape = [
            d for d in dshape
            if not (isinstance(d, dict) and list(d.keys()) == ["padding"])
        ]
    return shape, dshape


def _quant_to_list(q) -> list | None:
    """Normalise a quantization value to ``[scale, zero_point]``.

    Accepts ``None``, a dict ``{scale, zero_point}``, or an existing
    ``[scale, zp]`` list and returns the canonical two-element list
    (or ``None`` if *q* is ``None``).
    """
    if q is None:
        return None
    if isinstance(q, dict):
        scale = q.get("scale", q.get("qn", 0.0))
        zp = q.get("zero_point", q.get("offset", 0))
        return [float(scale), int(zp)]
    if isinstance(q, (list, tuple)) and len(q) >= 2:
        return [float(q[0]), int(q[1])]
    return None


class KinaraRunner(Runner):
    """
    Loads and runs Kinara models for inference via edgefirst-ara2.

    Parameters
    ----------
    model: Any
        This is typically the path to the model (.dvm)
        or the loaded Kinara model.
    parameters: ModelParameters
        These are the model parameters set from the command line.
    timer: TimerContext
        A timer object for handling validation timings for the model.
    sample_image: Optional[str]
        A sample image path for performing model warmup. If not provided,
        a dummy image will be used based on the input shape and dtype.  
    socket_path : str, optional
        Path to the UNIX socket for the ARA-2 proxy.

    Raises
    ------
    ImportError
        Missing edgefirst-ara2 package.
    FileNotFoundError
        Raised if the path to the model does not exist.
    """

    def __init__(
        self,
        model: Any,
        parameters: ModelParameters,
        timer: TimerContext,
        sample_image: Optional[str] = None,
        socket_path: str = "/var/run/ara2.sock"
    ):
        if ara2 is None:
            raise ImportError(
                "The edgefirst-ara2 package is required to run Kinara .dvm "
                "models. Install it with: pip install edgefirst-ara2>=0.3.0")

        super(KinaraRunner, self).__init__(model, parameters, timer)

        self.socket_path = socket_path
        self._lock = threading.Lock()

        self.session = ara2.Session.create_via_unix_socket(self.socket_path)
        endpoints = self.session.list_endpoints()
        if not endpoints:
            raise RuntimeError(
                "No ARA-2 endpoints found. Is the proxy running?")
        self.endpoint = endpoints[0]

        if isinstance(model, str):
            if not os.path.exists(model):
                raise FileNotFoundError(
                    "The model '{}' does not exist.".format(model))
            self.model = self.endpoint.load_model(model)
            self.model.allocate_tensors()

        iq = self.model.input_quants(0)
        c, h, w = self.model.input_shape(0)
        self._input_shape = (1, c, h, w)
        self._input_signed = iq.is_signed
        self.parameters.common.input_quantization = (
            float(iq.qn), int(iq.offset))

        # Read the DVM metadata once and build a name-indexed map of its
        # output specs so each compiled tensor can be classified by its
        # semantic `output_type` ("boxes_xy", "boxes_wh", "scores", ...).
        #
        # Schema v2 DVMs embed ``edgefirst.json`` in a ZIP trailer with a
        # two-layer output structure.  When detected, build the name→type
        # map from the physical children in the v2 metadata.  Fall back to
        # ``ara2.read_metadata()`` (the edgefirst_ara2 package's built-in
        # reader) for legacy DVMs.
        self._embedded_v2 = _read_embedded_json(model) if isinstance(model, str) else None
        if (self._embedded_v2 is not None
                and self._embedded_v2.get("schema_version", 1) >= 2):
            md_outputs = _v2_physical_outputs(
                self._embedded_v2.get("outputs", []))
            self._dvm_md = None  # not needed; v2 path replaces it
        else:
            self._embedded_v2 = None  # not v2; discard
            self._dvm_md = (
                ara2.read_metadata(model) if isinstance(model, str) else None)
            md_outputs = {}
            if self._dvm_md is not None and self._dvm_md.outputs:
                md_outputs = {o.name: o for o in self._dvm_md.outputs}

        # Build raw output details from the compiled model tensors.
        raw_details = []
        for i in range(self.model.n_outputs):
            shape = _normalize_shape(self.model.output_shape(i))
            oq = self.model.output_quants(i)
            info = self.model.output_info(i)

            bpp = info.bpp
            if bpp == 1:
                dtype = (np.int8 if oq.is_signed else np.uint8)
            elif bpp == 2:
                dtype = (np.int16 if oq.is_signed else np.uint16)
            else:
                dtype = (np.int32 if oq.is_signed else np.uint32)

            md_out = md_outputs.get(info.layer_name)
            raw_details.append(
                {
                    "shape": np.array(shape, dtype=np.int64),
                    # HAL expects [scale: f32, zero_point: i32]
                    "quantization": [float(oq.qn), int(oq.offset)],
                    "channels_first": False,
                    "dtype": dtype,
                    "layer_name": info.layer_name,
                    "output_type": (
                        md_out.output_type if md_out is not None else None),
                }
            )

        # YOLOv8 split-decoder exports emit the box tensor as two
        # 2-channel halves (`boxes_xy` = c_xy, `boxes_wh` = wh) with
        # their own per-tensor quantization. HAL's decoder requires a
        # single [1, 4, N] boxes tensor, so we synthesize a virtual
        # merged entry in output_details and concatenate the halves at
        # inference time.
        self.output_details = raw_details
        self._output_synth = [("raw", i) for i in range(len(raw_details))]

        xy_idx = next(
            (i for i, d in enumerate(raw_details)
             if d["output_type"] == "boxes_xy"), None)
        wh_idx = next(
            (i for i, d in enumerate(raw_details)
             if d["output_type"] == "boxes_wh"), None)

        if xy_idx is not None and wh_idx is not None:
            excluded = {xy_idx, wh_idx}
            xy_qn, xy_off = raw_details[xy_idx]["quantization"]
            wh_qn, wh_off = raw_details[wh_idx]["quantization"]
            # Adopt xy's (qn, offset) as the merged pair. If wh disagrees
            # on either one, run_single_instance re-quantizes its bytes
            # so both halves share the same dequant formula.
            merged_qn = float(xy_qn)
            merged_offset = int(xy_off)
            merged_shape = list(raw_details[xy_idx]["shape"])
            merged_shape[1] = 4
            merged_entry = {
                "shape": np.array(merged_shape, dtype=np.int64),
                "quantization": [merged_qn, merged_offset],
                "channels_first": False,
                "dtype": raw_details[xy_idx]["dtype"],
                "layer_name": "kinara_split_boxes_merged",
                "output_type": "boxes",
            }
            self.output_details = [
                d for i, d in enumerate(raw_details) if i not in excluded
            ] + [merged_entry]
            self._output_synth = [
                ("raw", i) for i in range(len(raw_details))
                if i not in excluded
            ] + [(
                "concat_xy_wh", xy_idx, wh_idx,
                float(xy_qn), int(xy_off),
                float(wh_qn), int(wh_off),
                merged_qn, merged_offset,
            )]

        self._raw_output_details = raw_details

        metadata = self.load_model_metadata(model)
        self.init_decoder(metadata=metadata, outputs=self.output_details)

        if self.parameters.warmup > 0:
            self.warmup(sample_image)

    def load_model_metadata(self, model_path: str) -> Union[dict, None]:
        """
        Returns the model metadata for decoding the outputs.

        For schema_version:2 DVMs the metadata is read directly from the
        ZIP-embedded ``edgefirst.json``.  The two-layer output structure is
        flattened into the validator's expected format: one flat entry per
        *logical* output (``boxes``, ``scores``, ``mask_coefficients``,
        ``protos``) with ``shape``, ``quantization``, ``type``, ``decoder``,
        etc.  Physical children are not exposed — the xy/wh merge is
        already handled in ``__init__`` at the tensor level.

        For legacy DVMs the ``edgefirst_ara2.read_metadata()`` path is used.

        Parameters
        ----------
        model_path: str
            The path to the model.

        Returns
        -------
        Union[dict, None]
            The model metadata as a dict in the validator's expected
            format. Otherwise None is returned.
        """

        # ------ Schema version 2 path ------
        if self._embedded_v2 is not None:
            metadata = self._build_v2_metadata(self._embedded_v2, model_path)
        # ------ Legacy path (edgefirst_ara2 dataclass) ------
        else:
            metadata = self._build_legacy_metadata()

        # Labels fallback from a separate file.
        if ((self.parameters.labels is None
             or len(self.parameters.labels) == 0) and
                self.parameters.labels_path is not None):
            if os.path.exists(self.parameters.labels_path):
                with open(self.parameters.labels_path, 'r', encoding="utf-8") as f:
                    self.parameters.labels = [
                        line.rstrip()
                        for line in f.readlines()
                        if line not in ["\n", "", "\t"]
                    ]

        self.set_metadata_parameters(metadata)
        return metadata

    def _build_v2_metadata(self, ef: dict, model_path: str) -> dict:
        """Build validator metadata dict from schema_version:2 edgefirst.json.

        Flattens the two-layer ``outputs[]`` into the flat format expected
        by ``Outputs.parse_metadata()`` and the HAL ``Decoder``.  Each
        logical output becomes one entry; shapes have trailing padding
        dimensions stripped so they match ``self.output_details``.

        Parameters
        ----------
        ef : dict
            Parsed edgefirst.json contents (schema_version >= 2).
        model_path : str
            Path to the DVM, used for labels.txt fallback.
        """
        # Extract labels from dataset.classes or ZIP labels.txt.
        classes = ef.get("dataset", {}).get("classes", [])
        if classes:
            self.parameters.labels = classes
        elif isinstance(model_path, str) and zipfile.is_zipfile(model_path):
            with zipfile.ZipFile(model_path) as zf:
                if "labels.txt" in zf.namelist():
                    text = zf.read("labels.txt").decode("utf-8").strip()
                    self.parameters.labels = [
                        ln for ln in text.splitlines() if ln.strip()
                    ]

        metadata: dict = {}

        # Input section.
        ca = ef.get("input", {}).get("cameraadaptor")
        if ca:
            metadata["input"] = {"cameraadaptor": ca}

        # Root-level fields.
        if ef.get("nms"):
            metadata["nms"] = ef["nms"]
        if ef.get("decoder_version"):
            metadata["decoder_version"] = ef["decoder_version"]

        task = ef.get("model", {}).get("task", "")
        if task:
            metadata["task"] = task

        # Validation section (needed for set_metadata_parameters).
        validation = ef.get("validation")
        if validation:
            metadata["validation"] = validation

        # Map from v2 type names to the validator's expected type names.
        _v2_type_map = {
            "boxes": "boxes",
            "scores": "scores",
            "mask_coefs": "mask_coefficients",
            "mask_coefficients": "mask_coefficients",
            "classes": "classes",
            "protos": "protos",
            "objectness": "objectness",
            "detections": "detections",
            "detection": "detection",
            "segmentation": "segmentation",
            "masks": "masks",
        }

        # Flatten logical outputs — use logical-level semantic fields but
        # match shapes against self.output_details to pick up the correct
        # quantization from the physical tensors.
        outputs_list = []
        for logical in ef.get("outputs", []):
            v2_type = logical.get("type", "")
            hal_type = _v2_type_map.get(v2_type, v2_type)
            shape, dshape = _strip_padding(
                list(logical.get("shape", [])),
                logical.get("dshape"),
            )

            # Match to output_details by shape.
            quantization = None
            for d in self.output_details:
                det_shape = [int(x) for x in d["shape"]]
                if det_shape == shape:
                    quantization = _quant_to_list(d.get("quantization"))
                    break

            # Fall back to the metadata's own quantization if present.
            if quantization is None:
                quantization = _quant_to_list(logical.get("quantization"))

            entry: dict = {
                "shape": shape,
                "channels_first": False,
                "type": hal_type,
            }
            if quantization is not None:
                entry["quantization"] = quantization
            if logical.get("decoder"):
                entry["decoder"] = logical["decoder"]
            if logical.get("normalized") is not None:
                entry["normalized"] = logical["normalized"]
            if logical.get("score_format"):
                entry["score_format"] = logical["score_format"]
            if logical.get("encoding"):
                entry["encoding"] = logical["encoding"]
            if dshape:
                entry["dshape"] = dshape
            if logical.get("stride") is not None:
                entry["stride"] = logical["stride"]
            if logical.get("anchors") is not None:
                entry["anchors"] = logical["anchors"]

            outputs_list.append(entry)

        # Propagate decoder from any output that has it to all siblings
        # (e.g. protos does not carry "decoder" in v2 but the validator
        # relies on it being present on every output).
        decoder = None
        for o in outputs_list:
            if o.get("decoder"):
                decoder = o["decoder"]
                break
        if decoder is not None:
            for o in outputs_list:
                o.setdefault("decoder", decoder)

        metadata["outputs"] = outputs_list
        return metadata

    def _build_legacy_metadata(self) -> Union[dict, None]:
        """Build validator metadata dict from the edgefirst_ara2 dataclass."""
        dvm_md = self._dvm_md
        metadata: Union[dict, None] = None
        if dvm_md is not None:
            if dvm_md.classes:
                self.parameters.labels = dvm_md.classes
            metadata = {}
            if dvm_md.input is not None:
                ca = getattr(dvm_md.input, "cameraadaptor", None)
                if ca:
                    metadata["input"] = {"cameraadaptor": ca}
            if dvm_md.nms:
                metadata["nms"] = dvm_md.nms
            if dvm_md.decoder_version:
                metadata["decoder_version"] = dvm_md.decoder_version
            if dvm_md.task:
                metadata["task"] = dvm_md.task

            decoder = (
                dvm_md.outputs[0].decoder if dvm_md.outputs else None)

            md_type_to_hal = {
                "scores": "scores",
                "mask_coefficients": "mask_coefficients",
                "mask_coefs": "mask_coefficients",
                "classes": "classes",
                "protos": "protos",
                "boxes": "boxes",
            }

            outputs_list = []
            for d in self.output_details:
                shape = [int(x) for x in d["shape"]]
                qn, zp = d["quantization"]
                out: dict = {
                    "shape": shape,
                    "channels_first": d["channels_first"],
                    "quantization": [float(qn), int(zp)],
                }
                md_type = d.get("output_type")
                hal_type = md_type_to_hal.get(md_type)
                if hal_type is None:
                    hal_type = "protos" if len(shape) == 4 else "detection"
                out["type"] = hal_type
                if hal_type in ("boxes", "detection"):
                    out["normalized"] = True
                if decoder is not None:
                    out["decoder"] = decoder
                outputs_list.append(out)
            metadata["outputs"] = outputs_list

        return metadata

    def infer(self, input_tensor: np.ndarray, timeout: int = 50000):
        """
        Run synchronous inference on input tensor.

        Parameters
        ----------
        input_tensor : np.ndarray
            Input array for inference.
        timeout : int, optional
            Timeout in milliseconds for inference (reserved for future use).

        Raises
        ------
        RuntimeError
                If inference execution fails.
        """

        # Host→NPU upload is part of input preparation; aggregate it onto
        # the existing "input" entry created by the dataset preprocessing.
        start = time.perf_counter()
        self.model.set_input_tensor(0, input_tensor.flatten())
        elapsed = time.perf_counter() - start
        self.timer.add_time("input", elapsed * 1e3)

        # Inference wall-clock — captures NPU execution plus the PCIe
        # round-trip that is unavoidable in real deployments. The
        # ara2-reported timing.run_time_us is NPU-core only and
        # undercounts the representative per-frame cost.
        with self._lock:
            with self.timer.time("inference"):
                self.model.run()

    def run_single_instance(self, image: np.ndarray) -> Any:
        """
        Run Kinara inference on a single image and record the timings.

        Parameters
        ----------
        image: np.ndarray
            The input image after being preprocessed.
            Typically this is an RGB image array.

        Returns
        -------
        Any
            This could either return detection outputs after NMS.
                np.ndarray
                    The prediction bounding boxes.. [[box1], [box2], ...].
                np.ndarray
                    The prediction confidence scores.. [score, score, ...]
                    normalized between 0 and 1.
                np.ndarray
                    The prediction labels.. [cl1, cl2, ...].
            This could also return segmentation masks.
                np.ndarray
        """
        self.infer(image)

        start = time.perf_counter()
        # Fetch raw (quantized) output tensors; the downstream HAL decoder
        # handles dequantization using the quantization params stored in
        # output_details. For split-decoder models the two box halves
        # (`boxes_xy` and `boxes_wh`) are re-quantized to a shared
        # `(qn, offset)` pair and concatenated into a single virtual
        # [1, 4, N] boxes tensor (see __init__).
        outputs = []
        for synth in self._output_synth:
            kind = synth[0]
            if kind == "raw":
                i = synth[1]
                t = self.model.get_output_tensor(i).reshape(
                    self._raw_output_details[i]["shape"])
                outputs.append(t)
            else:  # "concat_xy_wh"
                (_, xy_i, wh_i, xy_qn, xy_off, wh_qn, wh_off,
                 merged_qn, merged_off) = synth
                xy = self.model.get_output_tensor(xy_i).reshape(
                    self._raw_output_details[xy_i]["shape"])
                wh = self.model.get_output_tensor(wh_i).reshape(
                    self._raw_output_details[wh_i]["shape"])
                xy = _requantize(xy, xy_qn, xy_off, merged_qn, merged_off)
                wh = _requantize(wh, wh_qn, wh_off, merged_qn, merged_off)
                outputs.append(np.concatenate([xy, wh], axis=1))
        elapsed = time.perf_counter() - start

        # Postprocessing
        outputs = self.postprocessing(outputs)
        self.timer.add_time("output", elapsed * 1e3)

        return outputs

    def stop(self):
        """Close the ARA-2 session and model gracefully."""
        try:
            if self.model is not None:
                self.model.close()
        except Exception:  # pylint: disable=broad-exception-caught
            pass
        try:
            if self.session is not None:
                self.session.close()
        except Exception:  # pylint: disable=broad-exception-caught
            pass
        self.model = None
        self.endpoint = None
        self.session = None

    def get_input_type(self):
        """
        This returns the input type of the model. Kinara models
        are always quantized in either INT8 or UINT8 datatypes.

        Returns
        -------
        np.dtype
            The input type of the model.
        """
        if self._input_signed:
            return np.int8
        return np.uint8

    def get_input_shape(self):
        """
        This fetches the model input shape. Kinara models are
        always channels first.

        Returns
        -------
        tuple
            The model input shape (batch size, channels, height, width).
        """
        return self._input_shape
