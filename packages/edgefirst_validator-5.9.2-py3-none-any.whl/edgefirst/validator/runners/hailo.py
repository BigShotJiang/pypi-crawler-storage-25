"""
HailoRT runner for Hailo-8/8L accelerator inference.

Supports models compiled to the HEF format.  Two output modes are handled
transparently based on how the model was compiled:

* **On-chip NMS** — The Hailo device performs NMS internally.  Detections
  arrive in ``tf_nms_format`` as a NumPy array with shape
  ``(batch, num_classes, 5, max_dets_per_class)`` where each detection is
  ``[y_min, x_min, y_max, x_max, score]`` in coordinates normalised to
  [0, 1] of the model input.  The runner converts to xyxy and returns
  ``(boxes, scores, classes)`` directly — the validator's own NMS is
  bypassed since the hardware already performed it.

* **Raw DFL output heads** — The HEF returns separate spatial tensors per
  FPN level: a DFL bounding-box tensor ``(H, W, 4*reg_max)``, a class-score
  tensor ``(H, W, NC)``, and (for instance segmentation) a mask-coefficient
  tensor ``(H, W, num_protos)``, plus a single mask-prototype tensor.  The
  runner decodes DFL per level (softmax + weighted sum → distances → xcycwh
  pixels), appends scores and mask coefficients, and concatenates across
  scales into the canonical YOLOv8 layout ``(1, 4+NC[+NM], total_anchors)``
  consumed by the validator's standard postprocessing pipeline.

EdgeFirst packages each ``.hef`` with a ZIP trailer containing
``edgefirst.json`` (schema-v2 metadata, see ``models/metadata.md`` in the
user manual) and ``labels.txt``.  The runner reads the trailer first,
then hands the trailer-stripped bytes to ``HEF()`` (HailoRT rejects HEF
files that have extra trailing data).  Sidecar ``--config`` / ``--labels``
remain accepted for models distributed without an embedded trailer.

The split-output → canonical-YOLO merge logic, the DFL math, and the ZIP
trailer parser all live in ``runners.processing.hailo_decode`` so they can
be exercised by unit tests without a Hailo device and shared with the
reference decoder script.  See ``HAILORT.md`` at the repository root for
the HailoRT API reference.
"""

from __future__ import annotations

import os
import time
from typing import TYPE_CHECKING, Any, Optional, Union

import numpy as np

from edgefirst.validator.runners.core import Runner
from edgefirst.validator.runners.processing.hailo_decode import (
    HailoMetadataError,
    bind_levels_to_hef,
    decode_dfl_level,
    make_anchor_grid,
    parse_v2_outputs,
    read_hef_with_trailer,
)
from edgefirst.validator.datasets.utils.fetch import get_shape
from edgefirst.validator.publishers.utils.logger import logger

if TYPE_CHECKING:
    from edgefirst.validator.evaluators import ModelParameters, TimerContext


class HailoRTRunner(Runner):
    """
    Inference runner for Hailo-8/8L devices using the HailoRT Python API.

    Uses the synchronous ``InferVStreams`` pipeline kept alive across calls,
    avoiding the per-frame teardown of the deprecated ``HailoRunner``.
    """

    def __init__(
        self,
        model: Any,
        parameters: "ModelParameters",
        timer: "TimerContext",
        sample_image: Optional[str] = None,
    ):
        super().__init__(model, parameters, timer=timer)

        try:
            from hailo_platform import (
                HEF,
                VDevice,
                HailoStreamInterface,
                InferVStreams,
                ConfigureParams,
                InputVStreamParams,
                OutputVStreamParams,
                FormatType,
            )
        except ImportError as e:
            raise ImportError(
                "hailo_platform is required to run HailoRT models. "
                "Install with: apt install python3-hailort"
            ) from e

        self._InferVStreams = InferVStreams
        self._FormatType = FormatType

        if not isinstance(model, str):
            raise ValueError("HailoRTRunner requires a file path to a .hef model.")
        if not os.path.exists(model):
            raise FileNotFoundError(f"Model file not found: {model}")

        # Read the HEF and any embedded EdgeFirst trailer up front.  The
        # trailer (when present) carries edgefirst.json + labels.txt; the
        # stripped HEF bytes are what HailoRT will accept.
        hef_bytes, embedded_metadata, embedded_labels = read_hef_with_trailer(
            model
        )
        self._embedded_metadata = embedded_metadata
        if embedded_labels:
            self.parameters.labels = embedded_labels

        self.target = None
        try:
            # HailoRT rejects HEF files with appended ZIP data, so always
            # load from the trailer-stripped bytes (HAILORT.md confirms
            # HEF() accepts either a path or a bytes buffer).
            self.hef = HEF(hef_bytes)

            self.target = VDevice()
            configure_params = ConfigureParams.create_from_hef(
                self.hef, interface=HailoStreamInterface.PCIe
            )
            network_groups = self.target.configure(self.hef, configure_params)
            self.network_group = network_groups[0]
            self.network_group_params = self.network_group.create_params()

            self._input_info = self.hef.get_input_vstream_infos()[0]
            self._output_infos = self.hef.get_output_vstream_infos()
            self._output_names = [info.name for info in self._output_infos]

            self._has_onchip_nms, self._nms_output_name = self._detect_onchip_nms()
            if self._has_onchip_nms:
                nms_info = next(
                    i for i in self._output_infos
                    if i.name == self._nms_output_name
                )
                self._nms_num_classes = nms_info.nms_shape.number_of_classes
                self._nms_max_bboxes = nms_info.nms_shape.max_bboxes_per_class

            # Resolve metadata: prefer the trailer, fall back to sidecar
            # --config / --labels for models distributed without a trailer.
            metadata = self._resolve_metadata()

            if self._has_onchip_nms:
                self._fpn_layout = None
                self._setup_onchip_nms()
            else:
                # Raw DFL path needs the metadata to identify each tensor.
                if metadata is None:
                    raise HailoMetadataError(
                        "Raw-output HEF requires edgefirst.json metadata. "
                        "Either repackage the .hef with an embedded ZIP "
                        "trailer or pass --config / --labels."
                    )
                self._fpn_layout = self._build_fpn_layout(metadata)
                self._setup_dfl_decoder(metadata)

            # Persistent inference pipeline + activation context.
            self._input_params = InputVStreamParams.make(
                self.network_group, format_type=FormatType.UINT8
            )
            self._output_params = OutputVStreamParams.make(
                self.network_group, format_type=FormatType.FLOAT32
            )
            self.parameters.engine = "hailo"

            self._pipeline = self._InferVStreams(
                self.network_group,
                self._input_params,
                self._output_params,
                tf_nms_format=self._has_onchip_nms,
            )
            self._pipeline.__enter__()

            self._activation = self.network_group.activate(
                self.network_group_params
            )
            self._activation.__enter__()

            if self._has_onchip_nms:
                self._pipeline.set_nms_score_threshold(
                    self.parameters.score_threshold
                )
                self._pipeline.set_nms_iou_threshold(
                    self.parameters.iou_threshold
                )

            net_name = self.hef.get_network_group_names()[0]
            mode = "on-chip NMS" if self._has_onchip_nms else (
                f"DFL ({len(self._fpn_layout['fpn_levels'])} FPN levels, "
                f"nc={self._fpn_layout['nc']}, "
                f"masks={'yes' if self._fpn_layout['has_mask_coefs'] else 'no'})"
            )
            logger(
                f"HailoRT: loaded '{net_name}', "
                f"input {tuple(self._input_info.shape)}, mode={mode}",
                code="INFO",
            )

            if self.parameters.warmup > 0:
                self.warmup(sample_image)
        except Exception:
            # Release any partially-allocated device resources on failure
            # so a bad model file doesn't leak the VDevice.
            self.close()
            raise

    # ------------------------------------------------------------------
    # NMS detection
    # ------------------------------------------------------------------

    def _detect_onchip_nms(self):
        """Identify the on-chip NMS output, if any."""
        try:
            from hailo_platform.pyhailort.pyhailort import FormatOrder
            nms_orders = (
                FormatOrder.HAILO_NMS_BY_CLASS,
                FormatOrder.HAILO_NMS_BY_SCORE,
                FormatOrder.HAILO_NMS_WITH_BYTE_MASK,
            )
            for info in self._output_infos:
                if info.format.order in nms_orders:
                    return True, info.name
        except (ImportError, AttributeError):
            logger(
                "HailoRT: FormatOrder enum unavailable — assuming raw outputs.",
                code="WARNING",
            )
        return False, None

    # ------------------------------------------------------------------
    # Metadata resolution
    # ------------------------------------------------------------------

    def _resolve_metadata(self) -> Optional[dict]:
        """
        Return the edgefirst.json contents to drive output decoding.

        Order of precedence:
        1. Metadata embedded in the HEF ZIP trailer.
        2. ``--config`` sidecar file (JSON or YAML).
        Returns ``None`` if neither is available.

        Also loads the sidecar ``--labels`` file when ``labels.txt`` was not
        carried in the trailer.  Calls ``set_metadata_parameters`` so the
        usual override behaviour (validation thresholds, normalisation)
        runs regardless of where the metadata came from.
        """
        metadata = self._embedded_metadata
        if metadata is None and self.parameters.config_path is not None:
            if os.path.exists(self.parameters.config_path):
                metadata = self._load_sidecar_metadata(
                    self.parameters.config_path
                )
            else:
                logger(
                    f"Config path '{self.parameters.config_path}' not found.",
                    code="WARNING",
                )

        if (not self.parameters.labels) and self.parameters.labels_path:
            if os.path.exists(self.parameters.labels_path):
                with open(
                    self.parameters.labels_path, "r", encoding="utf-8"
                ) as f:
                    self.parameters.labels = [
                        line.rstrip()
                        for line in f.readlines()
                        if line.strip()
                    ]
            else:
                logger(
                    f"Labels path '{self.parameters.labels_path}' not found.",
                    code="WARNING",
                )

        self.set_metadata_parameters(metadata)
        return metadata

    @staticmethod
    def _load_sidecar_metadata(path: str) -> Optional[dict]:
        """Parse a sidecar config file as JSON, falling back to YAML."""
        import json as _json
        with open(path, encoding="utf-8") as f:
            content = f.read()
        try:
            return _json.loads(content)
        except _json.JSONDecodeError:
            import yaml
            return yaml.safe_load(content)

    # Kept for compatibility with the Runner contract — already invoked via
    # _resolve_metadata at __init__ time.
    def load_model_metadata(self) -> Union[dict, None]:
        return self._embedded_metadata

    # ------------------------------------------------------------------
    # Raw-DFL setup
    # ------------------------------------------------------------------

    def _build_fpn_layout(self, metadata: dict) -> dict:
        """Parse v2 metadata and bind logical outputs to HEF tensor names."""
        layout = parse_v2_outputs(metadata)
        bind_levels_to_hef(layout, self._output_infos)

        # Pre-compute per-level anchor grids and the DFL bin vector once.
        reg_max = layout["fpn_levels"][0]["reg_max"]
        for lvl in layout["fpn_levels"]:
            if lvl["reg_max"] != reg_max:
                raise HailoMetadataError(
                    "Heterogeneous reg_max across FPN levels is not supported"
                )
        self._dfl_bins = np.arange(reg_max, dtype=np.float32)
        self._fpn_grids: list[tuple[np.ndarray, np.ndarray]] = []
        for lvl in layout["fpn_levels"]:
            grid_x, grid_y = make_anchor_grid(lvl["h"], lvl["w"])
            self._fpn_grids.append((grid_x, grid_y))
        return layout

    def _setup_dfl_decoder(self, metadata: dict):
        """Wire the validator's standard decoder around the merged YOLO tensor."""
        details = self._build_output_details()
        init_meta = self._build_init_metadata(metadata)
        self.init_decoder(metadata=init_meta, outputs=details)

    def _build_output_details(self):
        """
        Describe the post-merge tensors the runner produces per inference.

        For DFL models the runner produces one combined YOLO tensor of
        shape ``(1, 4+NC[+NM], total_anchors)`` plus the protos tensor when
        the model is segmentation.  Reporting these shapes lets the
        ``Outputs`` auto-detection route through ``process_yolo`` /
        ``process_yolo_hal`` unchanged.
        """
        layout = self._fpn_layout
        nc = layout["nc"]
        protos_c = layout["protos_channels"]
        combined_c = 4 + nc + protos_c

        details = [{
            "shape": np.array([1, combined_c, layout["total_anchors"]]),
            "dtype": np.float32,
            "quantization": (1.0, 0),
        }]

        if layout["protos_name"] is not None:
            protos_meta = layout["protos_meta"]
            details.append({
                "shape": np.array(protos_meta["shape"]),
                "dtype": np.float32,
                "quantization": (1.0, 0),
            })

        return details

    def _build_init_metadata(self, raw_metadata: dict) -> dict:
        """
        Synthesise a flat metadata dict for the ``Outputs`` parser.

        The validator's ``Outputs.parse_metadata`` consumes a flat list of
        ``{type, shape, decoder, ...}`` entries — one per tensor the runner
        actually returns.  The Hailo runner returns the merged YOLO tensor
        (and optionally protos), so we synthesise matching entries here
        rather than passing the v2 two-layer ``outputs[]`` through.

        TODO(DE-XXX): teach ``Outputs.parse_metadata`` to consume the v2
        two-layer structure natively and remove this shim.
        """
        layout = self._fpn_layout
        meta: dict = {}
        for key in ("decoder_version", "validation", "nms",
                    "input", "model", "calibration"):
            if key in raw_metadata:
                meta[key] = raw_metadata[key]

        nc = layout["nc"]
        nm = layout["protos_channels"]
        combined_shape = [1, 4 + nc + nm, layout["total_anchors"]]
        # Type must be "detection" (not "scores"): the runner emits a single
        # combined YOLO tensor — boxes || scores || mask_coefs — and the HAL
        # decoder routes `type: "detection"` to its unsplit `YoloSegDet` path
        # (see hal crates/decoder/src/decoder/builder.rs::get_model_type_yolo).
        # Type "scores" would route to `split_scores` and HAL would demand a
        # matching `split_boxes` child that does not exist in this layout.
        outputs_list: list[dict] = [{
            "type": "detection",
            "decoder": "ultralytics",
            "shape": combined_shape,
            # Hailo applies sigmoid on-chip; downstream must NOT re-apply.
            # 'per_class' tells decode.py to extract scores from p[:, 4:]
            # without applying sigmoid (matching the YOLOv8 layout).
            "score_format": "per_class",
        }]
        if layout["protos_name"] is not None:
            outputs_list.append({
                "type": "protos",
                "decoder": "ultralytics",
                "shape": layout["protos_meta"]["shape"],
            })
        meta["outputs"] = outputs_list
        return meta

    # ------------------------------------------------------------------
    # On-chip NMS setup
    # ------------------------------------------------------------------

    def _setup_onchip_nms(self):
        """Configure input shape/dtype; downstream NMS pipeline is bypassed."""
        self.input_dtype = self.get_input_type()
        shape = self.get_input_shape()
        self.input_shape = np.array(
            [d if d is not None else 1 for d in shape]
        )
        self.height, self.width = get_shape(self.input_shape)
        self.parameters.common.dtype = self.input_dtype
        self.parameters.common.shape = self.input_shape

        self.parameters.common.with_boxes = True
        if not self.parameters.common.with_masks:
            self.parameters.common.with_masks = False

        logger(
            "HailoRT: on-chip NMS detected — the validator's NMS pipeline "
            "is bypassed. To use HAL/NumPy NMS, recompile the model "
            "without NMS layers.",
            code="WARNING",
        )
        logger(
            f"HailoRT: {self._nms_num_classes} classes, "
            f"up to {self._nms_max_bboxes} detections per class",
            code="INFO",
        )

    # ------------------------------------------------------------------
    # Inference
    # ------------------------------------------------------------------

    def run_single_instance(self, image: np.ndarray = None) -> Any:
        input_data = {self._input_info.name: image}
        with self.timer.time("inference"):
            results = self._pipeline.infer(input_data)

        if self._has_onchip_nms:
            return self._decode_onchip_nms(results)

        start = time.perf_counter()
        outputs = self._prepare_raw_outputs(results)
        elapsed = time.perf_counter() - start
        self.timer.add_time("output", elapsed * 1e3)
        return self.postprocessing(outputs)

    def _prepare_raw_outputs(self, results: dict) -> list:
        """
        Decode + merge per-level outputs into the canonical YOLO layout.

        For each FPN level, decode the DFL bbox tensor into xcycwh pixels,
        append class scores and mask coefficients, then concatenate
        stride-ascending and transpose to ``(1, 4+NC[+NM], total_anchors)``.
        Protos pass through with NHWC→NCHW transposition.
        """
        layout = self._fpn_layout
        parts: list[np.ndarray] = []
        for lvl, (grid_x, grid_y) in zip(layout["fpn_levels"], self._fpn_grids):
            bbox_t = results[lvl["bbox_name"]]
            cls_t = results[lvl["cls_name"]]
            if bbox_t.ndim == 4:
                bbox_t = bbox_t[0]
            if cls_t.ndim == 4:
                cls_t = cls_t[0]

            boxes = decode_dfl_level(
                bbox_t, grid_x, grid_y, lvl["stride"], self._dfl_bins
            )  # (H*W, 4)
            scores = cls_t.reshape(-1, cls_t.shape[-1])
            combined = np.concatenate([boxes, scores], axis=-1)

            if "mask_coefs_name" in lvl:
                mc_t = results[lvl["mask_coefs_name"]]
                if mc_t.ndim == 4:
                    mc_t = mc_t[0]
                mc_flat = mc_t.reshape(-1, mc_t.shape[-1])
                combined = np.concatenate([combined, mc_flat], axis=-1)

            parts.append(combined)

        detection = np.concatenate(parts, axis=0)
        detection = detection.T[np.newaxis]
        outputs: list[np.ndarray] = [detection]

        if layout["protos_name"] is not None:
            t = results[layout["protos_name"]]
            if t.ndim == 3:
                t = t[np.newaxis]
            # Protos arrive NHWC from the HEF; the YOLO decoder expects NCHW.
            if t.ndim == 4 and t.shape[1] != layout["protos_channels"]:
                t = t.transpose(0, 3, 1, 2)
            outputs.append(t)

        return outputs

    # ------------------------------------------------------------------
    # On-chip NMS decoding
    # ------------------------------------------------------------------

    def _decode_onchip_nms(self, results: dict):
        """
        Decode on-chip NMS output (``tf_nms_format=True``).

        The output tensor has shape
        ``(batch, num_classes, BBOX_PARAMS=5, max_dets_per_class)`` where
        each detection is ``[y_min, x_min, y_max, x_max, score]`` with
        coordinates normalised to [0, 1] of the model input (per HAILORT.md).

        Returns ``(boxes, scores, classes)`` with boxes in xyxy.

        TODO(DE-823 followup): the coordinate space returned here
        ([0,1] normalised vs pixel) and the score-padding filter
        (``score > 0`` vs ``score > score_threshold``) need on-target
        verification on the RPi5 + Hailo-8L before being treated as bugs.
        Documented in HAILORT.md "Validator Runner Design Notes".
        """
        start = time.perf_counter()

        output = results[self._nms_output_name][0]  # strip batch
        boxes_list: list[np.ndarray] = []
        scores_list: list[np.ndarray] = []
        classes_list: list[np.ndarray] = []

        for class_id in range(output.shape[0]):
            det_scores = output[class_id, 4, :]
            valid = det_scores > 0  # padding entries have score == 0
            if not valid.any():
                continue
            coords = output[class_id, :4, valid].T  # (N, 4) [y1,x1,y2,x2]
            xyxy = coords[:, [1, 0, 3, 2]]
            boxes_list.append(xyxy)
            scores_list.append(det_scores[valid])
            classes_list.append(
                np.full(int(valid.sum()), class_id, dtype=np.uintp)
            )

        if boxes_list:
            boxes = np.concatenate(boxes_list, axis=0).astype(np.float32)
            scores = np.concatenate(scores_list, axis=0).astype(np.float32)
            classes = np.concatenate(classes_list, axis=0).astype(np.uintp)
        else:
            boxes = np.empty((0, 4), dtype=np.float32)
            scores = np.empty((0,), dtype=np.float32)
            classes = np.empty((0,), dtype=np.uintp)

        elapsed = time.perf_counter() - start
        self.timer.add_time("output", elapsed * 1e3)

        if self.parameters.label_offset != 0:
            classes = classes + self.parameters.label_offset

        if self.parameters.box_format == "xcycwh":
            from edgefirst.validator.datasets.utils.annotation_transforms import (
                xyxy2xcycwh,
            )
            boxes = xyxy2xcycwh(boxes)
        elif self.parameters.box_format == "xywh":
            from edgefirst.validator.datasets.utils.annotation_transforms import (
                xyxy2xywh,
            )
            boxes = xyxy2xywh(boxes)

        return boxes, scores, classes

    # ------------------------------------------------------------------
    # Runner contract
    # ------------------------------------------------------------------

    def get_input_type(self) -> np.dtype:
        return np.uint8

    def get_input_shape(self) -> np.ndarray:
        h, w, c = self._input_info.shape
        return np.array([1, h, w, c])

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def close(self):
        for attr in ("_activation", "_pipeline"):
            ctx = getattr(self, attr, None)
            if ctx is not None:
                try:
                    ctx.__exit__(None, None, None)
                except Exception:
                    pass
                setattr(self, attr, None)

        target = getattr(self, "target", None)
        if target is not None:
            try:
                target.release()
            except Exception:
                pass
            self.target = None

    def __del__(self):
        self.close()
