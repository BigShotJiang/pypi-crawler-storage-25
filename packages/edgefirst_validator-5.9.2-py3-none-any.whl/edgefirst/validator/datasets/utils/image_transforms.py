"""
This module contains functions for transforming sensors data.

Color space conversions are handled by the edgefirst-cameraadaptor library
for consistency with training pipelines. HAL-accelerated conversions are
still supported for on-target inference.
"""

from __future__ import annotations

from io import BytesIO
from typing import TYPE_CHECKING, Optional, Union, Tuple, Callable

import numpy as np
from PIL import Image, ExifTags

# Import CameraAdaptor library for color conversions
try:
    from edgefirst.cameraadaptor import CameraAdaptorTransform
    from edgefirst.cameraadaptor.hal_utils import (
        get_pixel_format,
        get_planar_pixel_format,
    )
    _CAMERAADAPTOR_AVAILABLE = True
except ImportError:
    _CAMERAADAPTOR_AVAILABLE = False

try:
    import edgefirst_hal  # type: ignore
    image_processor = edgefirst_hal.ImageProcessor()
    _HAL_AVAILABLE = True
except ImportError:
    image_processor = None
    _HAL_AVAILABLE = False

from edgefirst.validator.publishers.utils.logger import logger

# Cache for Tensor buffers to avoid per-call GPU texture allocation.
# Keyed by (width, height, format_str) -> Tensor.
_TENSOR_CACHE: dict = {}
_NUMPY_CACHE: dict = {}

if TYPE_CHECKING:
    from edgefirst_hal import Tensor, PixelFormat, Normalization  # type: ignore


def get_hal_pixel_format(
    channels: int,
    transpose: bool,
    camera_adaptor: Optional[str] = None
) -> PixelFormat:
    """
    Determine the HAL PixelFormat for the model input buffer.

    Uses edgefirst-cameraadaptor hal_utils if available and camera_adaptor
    is specified, otherwise falls back to channel-based heuristics.

    Parameters
    ----------
    channels: int
        Number of input channels.
    transpose: bool
        Whether the model uses planar (NCHW) layout.
    camera_adaptor: Optional[str]
        The camera_adaptor color space from model metadata (e.g., "yuyv", "bgr").

    Returns
    -------
    edgefirst_hal.PixelFormat
        The PixelFormat enum value for creating HAL tensors.
    """
    # Try to use cameraadaptor hal_utils if available and color space is specified
    if _CAMERAADAPTOR_AVAILABLE and camera_adaptor:
        try:
            if transpose:
                return get_planar_pixel_format(camera_adaptor)
            else:
                return get_pixel_format(camera_adaptor)
        except (ValueError, AttributeError):
            # Fall back to heuristics if color space not supported
            logger(
                f"Unsupported camera_adaptor '{camera_adaptor}', "
                "falling back to channel-based PixelFormat selection.",
                code="WARNING"
            )
    
    # Fallback: channel-based heuristics
    if transpose:
        if channels == 1:
            return edgefirst_hal.PixelFormat.Grey
        elif channels == 2:
            return edgefirst_hal.PixelFormat.Nv16
        elif channels == 4:
            return edgefirst_hal.PixelFormat.PlanarRgba
        else:
            return edgefirst_hal.PixelFormat.PlanarRgb
    else:
        if channels == 1:
            return edgefirst_hal.PixelFormat.Grey
        elif channels == 2:
            return edgefirst_hal.PixelFormat.Yuyv
        elif channels == 4:
            return edgefirst_hal.PixelFormat.Rgba
        else:
            return edgefirst_hal.PixelFormat.Rgb
        

def get_hal_normalization(input_dtype: np.dtype, normalization: str) -> Normalization:
    """
    Determine the HAL Normalization mode based on
    input data type and specified normalization.

    Parameters
    ----------
    input_dtype: np.dtype
        The NumPy data type of the model input (e.g., np.float32, np.uint8).
    normalization: str
        The type of normalization to perform ("signed", "unsigned",
        "raw", "imagenet", or "default").

    Returns
    -------
    edgefirst_hal.Normalization
        The Normalization enum value for creating HAL tensors.
    """
    if input_dtype in [np.float16, np.float32]:
        if normalization == "unsigned":
            normalization = edgefirst_hal.Normalization.UNSIGNED
        elif normalization == "signed":
            normalization = edgefirst_hal.Normalization.SIGNED
        elif normalization == "raw":
            normalization = edgefirst_hal.Normalization.RAW
        elif normalization == "imagenet":
            raise NotImplementedError(
                "ImageNet normalization is currently not implemented in HAL.")
        else:
            normalization = edgefirst_hal.Normalization.DEFAULT
    else:
        normalization = edgefirst_hal.Normalization.DEFAULT
    return normalization
        

def bgr2rgb(image: np.ndarray) -> np.ndarray:
    """
    Converts BGR image to RGB image.

    Parameters
    ----------
    image: (height, width, 3) np.ndarray
        The BGR image NumPy array.

    Returns
    -------
    np.ndarray
        The RGB image NumPy array.
    """
    if _CAMERAADAPTOR_AVAILABLE:
        transform = CameraAdaptorTransform("rgb", source_format="bgr")
        return transform(image)
    return image[:, :, ::-1]


def rgb2bgr(image: np.ndarray) -> np.ndarray:
    """
    Converts RGB image to BGR image.

    Parameters
    ----------
    image: (height, width, 3) np.ndarray
        The RGB image NumPy array.

    Returns
    -------
    np.ndarray
        The BGR image NumPy array.
    """
    if _CAMERAADAPTOR_AVAILABLE:
        transform = CameraAdaptorTransform("bgr", source_format="rgb")
        return transform(image)
    return image[:, :, ::-1]


def rgb2yuyv(image: np.ndarray, backend: str = "hal") -> np.ndarray:
    """
    Convert an RGB image to YUYV format.

    Parameters
    ----------
    image: np.ndarray
        The 3-channel RGB image NumPy array.
    backend: str
        The backend library to use for this conversion.
        - "hal": Use EdgeFirst HAL (hardware-accelerated, preferred for inference)
        - "opencv" or "cameraadaptor": Use edgefirst-cameraadaptor library

    Returns
    -------
    np.ndarray
        The 2-channel YUYV image array.
    """
    if backend == "hal":
        if not _HAL_AVAILABLE:
            raise ImportError(
                "EdgeFirst HAL is needed to perform RGB to YUYV conversion.")

        if image_processor is None:
            raise ImportError(
                "EdgeFirst HAL image processor is not available for RGB to YUYV conversion.")

        height, width, _ = image.shape

        src_key = (width, height, "Rgb")
        src = _TENSOR_CACHE.get(src_key)
        if src is None:
            src = image_processor.create_image(
                width, height, edgefirst_hal.PixelFormat.Rgb)
            _TENSOR_CACHE[src_key] = src
        src.from_numpy(image)

        dst_key = (width, height, "Yuyv")
        dst = _TENSOR_CACHE.get(dst_key)
        if dst is None:
            dst = image_processor.create_image(
                width, height, edgefirst_hal.PixelFormat.Yuyv)
            _TENSOR_CACHE[dst_key] = dst
        image_processor.convert(src, dst)

        np_key = (dst.height, dst.width, 2)
        im = _NUMPY_CACHE.get(np_key)
        if im is None:
            im = np.zeros((dst.height, dst.width, 2), dtype=np.uint8)
            _NUMPY_CACHE[np_key] = im
        dst.normalize_to_numpy(im)
        return im
    else:
        # Use edgefirst-cameraadaptor for OpenCV-based conversion
        if _CAMERAADAPTOR_AVAILABLE:
            transform = CameraAdaptorTransform("yuyv", source_format="rgb")
            return transform(image)

        # Fallback to manual OpenCV conversion if cameraadaptor not available
        try:
            import cv2  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "OpenCV or edgefirst-cameraadaptor is needed to perform RGB to YUYV conversion."
            ) from exc

        return cv2.cvtColor(image, cv2.COLOR_RGB2YUV_YUYV)


def yuyv2rgb(image: np.ndarray, backend: str = "hal") -> np.ndarray:
    """
    Convert a YUYV image to RGB format.

    Parameters
    ----------
    image: np.ndarray
        The input 2-channel YUYV image.
    backend: str
        The backend library to use for this conversion.
        - "hal": Use EdgeFirst HAL (hardware-accelerated, preferred for inference)
        - "opencv": Use OpenCV directly

    Returns
    -------
    np.ndarray
        The output 3-channel RGB image.

    Note
    ----
    YUYV to RGB conversion is not supported by CameraAdaptorTransform
    as it's a reverse operation typically only needed for visualization.
    Use HAL or OpenCV directly.
    """
    if backend == "hal":
        if not _HAL_AVAILABLE:
            raise ImportError(
                "EdgeFirst HAL is needed to perform YUYV to RGB conversion.")
        
        if image_processor is None:
            raise ImportError(
                "EdgeFirst HAL image processor is not available for YUYV to RGB conversion.")

        height, width, _ = image.shape

        src_key = (width, height, "Yuyv")
        src = _TENSOR_CACHE.get(src_key)
        if src is None:
            src = image_processor.create_image(
                width, height, edgefirst_hal.PixelFormat.Yuyv)
            _TENSOR_CACHE[src_key] = src
        src.from_numpy(image)

        dst_key = (width, height, "Rgb")
        dst = _TENSOR_CACHE.get(dst_key)
        if dst is None:
            dst = image_processor.create_image(
                width, height, edgefirst_hal.PixelFormat.Rgb)
            _TENSOR_CACHE[dst_key] = dst
        image_processor.convert(src, dst)

        np_key = (dst.height, dst.width, 3)
        im = _NUMPY_CACHE.get(np_key)
        if im is None:
            im = np.zeros((dst.height, dst.width, 3), dtype=np.uint8)
            _NUMPY_CACHE[np_key] = im
        dst.normalize_to_numpy(im)
        return im
    else:
        try:
            import cv2  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "OpenCV is needed to perform YUYV to RGB conversion."
            ) from exc
        return cv2.cvtColor(image, cv2.COLOR_YUV2RGB_YUYV)


def rgb2rgba(image: np.ndarray, backend: str = "hal") -> np.ndarray:
    """
    Convert a 3-channel RGB image to 4-channel RGBA image.

    Parameters
    ----------
    image: np.ndarray
        The 3-channel RGB image array.
    backend: str
        The backend library to use for this conversion.
        - "hal": Use EdgeFirst HAL (hardware-accelerated)
        - "opencv" or "cameraadaptor": Use edgefirst-cameraadaptor library

    Returns
    -------
    np.ndarray
        The 4-channel RGBA image array with the alpha value set to 255.
    """
    if image.shape[0] == 3:
        _, height, width = image.shape
    elif image.shape[-1] == 3:
        height, width, _ = image.shape
    else:
        return image

    if backend == "hal":
        if not _HAL_AVAILABLE:
            raise ImportError(
                "EdgeFirst HAL is needed to perform RGB to RGBA conversion.")

        if image_processor is None:
            raise ImportError(
                "EdgeFirst HAL image processor is not available for RGB to RGBA conversion.")

        src_key = (width, height, "Rgb")
        src = _TENSOR_CACHE.get(src_key)
        if src is None:
            src = image_processor.create_image(
                width, height, edgefirst_hal.PixelFormat.Rgb)
            _TENSOR_CACHE[src_key] = src
        src.from_numpy(image)

        dst_key = (width, height, "Rgba")
        dst = _TENSOR_CACHE.get(dst_key)
        if dst is None:
            dst = image_processor.create_image(
                width, height, edgefirst_hal.PixelFormat.Rgba)
            _TENSOR_CACHE[dst_key] = dst
        image_processor.convert(src, dst)

        np_key = (dst.height, dst.width, 4)
        im = _NUMPY_CACHE.get(np_key)
        if im is None:
            im = np.zeros((dst.height, dst.width, 4), dtype=np.uint8)
            _NUMPY_CACHE[np_key] = im
        dst.normalize_to_numpy(im)
        return im
    else:
        # Use edgefirst-cameraadaptor for OpenCV-based conversion
        if _CAMERAADAPTOR_AVAILABLE:
            transform = CameraAdaptorTransform("rgba", source_format="rgb")
            return transform(image)

        # Fallback to manual alpha channel addition
        alpha_channel = np.full((height, width, 1), 255, dtype=np.uint8)
        return np.concatenate((image, alpha_channel), axis=-1)


def imagenet(image: np.ndarray) -> np.ndarray:
    """
    Normalize the image with imagenet normalization.

    Parameters
    ----------
    image: np.ndarray
        The image RGB array with shape
        (3, height, width) or (height, width, 3).

    Returns
    -------
    np.ndarray
        The image with imagenet normalization.
    """
    mean = np.array([0.079, 0.05, 0]) + 0.406
    std = np.array([0.005, 0, 0.001]) + 0.224

    if image.shape[0] == 3:
        for channel in range(image.shape[0]):
            image[channel, :, :] = (image[channel, :, :] / 255
                                    - mean[channel]) / std[channel]
    else:
        for channel in range(image.shape[2]):
            image[:, :, channel] = (image[:, :, channel] / 255
                                    - mean[channel]) / std[channel]
    return image


def image_normalization(
    image: np.ndarray,
    normalization: str,
    input_type: np.dtype = np.dtype(np.float32)
):
    """
    Performs image normalizations (signed, unsigned, raw).

    Parameters
    ----------
    image: np.ndarray
        The image to perform normalization.
    normalization: str
        This is the type of normalization to perform
        ("signed", "unsigned", "raw", "imagenet").
    input_type: np.dtype
        This is the NumPy datatype to convert. Ex. "uint8"

    Returns
    -------
    np.ndarray
        Depending on the normalization, the image will be returned.
    """
    if normalization.lower() == 'signed':
        return ((image.astype(np.float32) / 127.5) - 1.0).astype(input_type)
    elif normalization.lower() == 'unsigned':
        return (image.astype(np.float32) /
                255.0).astype(input_type)
    elif normalization.lower() == 'imagenet':
        return (imagenet(image.astype(np.float32))).astype(input_type)
    else:
        return (image).astype(input_type)


def crop_image(image: np.ndarray, box: Union[list, np.ndarray]) -> np.ndarray:
    """
    Crops the image to only the area that is covered by
    the box provided. This is primarily used in pose validation.

    Parameters
    ----------
    image: np.ndarray
        The frame to crop before feeding to the model.
    box: Union[list, np.ndarray]
        This contains non-normalized [xmin, ymin, xmax, ymax].

    Returns
    -------
    np.ndarray
        The image cropped to the area of the bounding box.
    """
    x1, y1, x2, y2 = box
    box_area = image[y1:y2, x1:x2, ...]
    return box_area


def rotate_image(data: Union[bytes, str]) -> Image.Image:
    """
    Read from the ImageExif to apply rotation on the image.

    Parameters
    ----------
    data: Union[bytes, str]
        Read image file as a bytes object or a string path
        to the image file.

    Returns
    -------
    Image.Image
        The pillow Image with rotation applied.
    """
    img_file = BytesIO(data) if isinstance(data, bytes) else data
    image = Image.open(img_file)

    # Get EXIF data safely
    exif_data = image.getexif()  # returns Exif object, behaves like dict
    if exif_data:
        # Find Orientation tag key
        orientation_key = next(
            (k for k, v in ExifTags.TAGS.items() if v == 'Orientation'),
            None
        )

        orientation = 1  # Default orientation
        if orientation_key and orientation_key in exif_data:
            orientation = exif_data[orientation_key]

        # Apply rotation based on orientation
        if orientation == 3:
            image = image.rotate(180, expand=True)
        elif orientation == 6:
            image = image.rotate(270, expand=True)
        elif orientation == 8:
            image = image.rotate(90, expand=True)
    return image


def resize(
    image: Union[Tensor, np.ndarray],
    size: Optional[tuple] = None,
    backend: str = "hal"
) -> Union[Tensor, np.ndarray]:
    """
    Resizes the images with the specified dimension using
    the EdgeFirst Tensor API. The original aspect ratio is not maintained.
    Image needs to be uint8.

    Parameters
    ----------
    image: Union[edgefirst_hal.Tensor, np.ndarray]
        The image (RGB, RGBA, Gray) tensor with uint8 dtype.
    size: Optional[tuple]
        Specify the (width, height) size of the new image.
    backend: str
        Specify the backend library for resizing the image from the options
        "hal", "opencv", "pillow".

    Returns
    -------
    Union[Tensor, np.ndarray]
        Resized image.
    """
    if size is None:
        return image

    if backend == "hal":
        if not _HAL_AVAILABLE:
            raise ImportError(
                "EdgeFirst HAL is needed to resize using hal.")

        if image_processor is None:
            raise ImportError(
                "EdgeFirst HAL image processor is not available for resizing.")

        if isinstance(image, np.ndarray):
            # Array without any channels is assumed to be grey.
            if len(image.shape) == 2:
                fourcc = edgefirst_hal.PixelFormat.Grey
                fourc = fourcc
                image = np.expand_dims(image, axis=-1)
                channels = 1
            else:
                # Currently OpenGL in x86_64 only supports RGBA.
                channels = 4
                fourcc = edgefirst_hal.PixelFormat.Rgba
                if image.shape[-1] == 4:
                    fourc = edgefirst_hal.PixelFormat.Rgba
                elif image.shape[-1] == 1:
                    fourcc = edgefirst_hal.PixelFormat.Grey
                    fourc = fourcc
                    channels = 1
                else:
                    fourc = edgefirst_hal.PixelFormat.Rgb
            height, width, _ = image.shape

            # Reuse cached Tensor buffers to avoid per-call GPU
            # texture allocation. Mask sizes are fixed within a model
            # (e.g., src always 160x160, dst always 640x640).
            src_key = (width, height, str(fourc))
            src = _TENSOR_CACHE.get(src_key)
            if src is None:
                src = image_processor.create_image(width, height, fourc)
                _TENSOR_CACHE[src_key] = src
            src.from_numpy(image)
        else:
            src = image
            # Currently OpenGL in x86_64 only supports RGBA.
            fourcc = (edgefirst_hal.PixelFormat.Rgba if
                      src.format == edgefirst_hal.PixelFormat.Rgb else src.format)
            channels = 1 if fourcc == edgefirst_hal.PixelFormat.Grey else 4

        dst_key = (size[0], size[1], str(fourcc))
        dst = _TENSOR_CACHE.get(dst_key)
        if dst is None:
            dst = image_processor.create_image(size[0], size[1], fourcc)
            _TENSOR_CACHE[dst_key] = dst
        image_processor.convert(src, dst)

        # Reuse numpy output buffer for same dst dimensions.
        np_key = (dst.height, dst.width, channels)
        im = _NUMPY_CACHE.get(np_key)
        if im is None:
            im = np.zeros((dst.height, dst.width, channels), dtype=np.uint8)
            _NUMPY_CACHE[np_key] = im
        dst.normalize_to_numpy(im)

        # Return a copy since the caller may accumulate results (e.g.,
        # list of resized masks) before the buffer is overwritten.
        if src.format == edgefirst_hal.PixelFormat.Grey:
            return im.squeeze().copy()
        elif src.format == edgefirst_hal.PixelFormat.Rgb:
            return im[:, :, 0:3].copy()
        return im.copy()
    elif backend == "opencv":
        try:
            import cv2  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "OpenCV is needed to resize using opencv.") from exc

        if isinstance(image, np.ndarray):
            return cv2.resize(image, size, interpolation=cv2.INTER_LINEAR)
    else:
        if isinstance(image, np.ndarray):
            im = Image.fromarray(image.astype(np.uint8))
            im = im.resize(size)
            return np.array(im)
    return image


def pad(
    image: np.ndarray,
    size: tuple,
    backend: str = "hal"
) -> Tuple[np.ndarray, list]:
    """
    Performs image padding based on the implementation provided in YOLOx:\
    https://github.com/Megvii-BaseDetection/YOLOX/blob/main/yolox/data/data_augment.py#L142

    The image is always padded on the right and at the bottom portions.

    Parameters
    ----------
    image: np.ndarray
        This is the input image to pad.
    size: tuple
        This is the model input size (generally) or the output image
        resolution after padding in the order (width, height).
    backend: str
        Specify the backend library for resizing the image from the options
        "hal", "opencv", "pillow".

    Returns
    --------
    image: np.ndarray
        This is the padded image.
    shapes: list
        This is used to scale the bounding boxes of the ground
        truth and the model detections based on the letterbox
        transformation.
        [[pad image height, pad image width],
        [[scale_y, scale_x], [pad x, pad y]].
    """
    height, width = image.shape[:2]  # current shape [height, width]
    if len(image.shape) == 3:
        padded_image = np.ones((size[1], size[0], 3), dtype=np.uint8) * 114
    else:
        padded_image = np.ones((size[1], size[0]), dtype=np.uint8) * 114

    r = min(size[1] / height, size[0] / width)
    resized_image = resize(
        image, (int(width * r), int(height * r)), backend=backend
    )
    padded_image[: int(height * r),
                 : int(width * r)] = resized_image
    padded_image = rgb2bgr(padded_image)  # RGB2BGR
    padded_image = np.ascontiguousarray(padded_image)

    # The bounding box offset to add due to image padding.
    # Requires normalization due to the bounding boxes are already normalized.
    new_unpad = int(round(height * r)), int(round(width * r))
    dw = padded_image.shape[1] - new_unpad[1]  # / new_unpad[1]
    dh = padded_image.shape[0] - new_unpad[0]  # / new_unpad[0]

    # The image was not rescaled, so default to 1.0.
    shapes = [
        # imgsz (model input shape) [height, width]
        [padded_image.shape[0], padded_image.shape[1]],
        [[resized_image.shape[0] / size[1],
          resized_image.shape[1] / size[0]],
         [dw, dh]]  # ratio_pad [[scale y, scale x], [pad w, pad h]]
    ]
    return padded_image, shapes


def letterbox_native(
    image: np.ndarray,
    size: tuple = (640, 640),
    constant: int = 114,
    backend: str = "hal"
) -> Tuple[np.ndarray, list]:
    """
    Applies the letterbox image transformations based in YOLOv5 and YOLOv7.

    Parameters
    ----------
    image : np.ndarray
        Input image array (HWC format).
    size : tuple, optional
        Target shape (width, height) for output image, by default (640, 640).
    constant : int, optional
        Padding pixel value (0–255), by default 114 (gray).
    backend: str
        Specify the backend library for letterboxing the
        image from the options "opencv", "pillow".

    Returns
    -------
    image: np.ndarray
        The resized and padded image in HWC format.
    shapes: list
        This is used to scale the bounding boxes of the ground
        truth and the model detections based on the letterbox
        transformation. Tuple containing padded image size, scale ratio,
        and padding offsets.
        [[pad image height, pad image width],
        [[scale_y, scale_x], [pad x, pad y]]].
    """
    height, width = image.shape[:2]
    scale = min(size[0] / width, size[1] / height)
    new_width = int(round(width * scale))
    new_height = int(round(height * scale))

    if scale != 1.0:
        image = resize(image, (new_width, new_height), backend=backend)

    # Compute padding
    dw, dh = size[0] - new_width, size[1] - new_height  # wh padding
    top = round(dh / 2)
    bottom = dh - top
    left = round(dw / 2)
    right = dw - left

    if backend == "opencv":
        try:
            import cv2  # type: ignore
        except ImportError as exc:
            raise ImportError("OpenCV is needed for letterbox.") from exc
        padded_image = cv2.copyMakeBorder(
            image, top, bottom, left, right, cv2.BORDER_CONSTANT,
            value=(constant, constant, constant))  # add border
    else:
        padded_image = np.zeros(
            (3, new_height + top + bottom, new_width + left + right))

        for i, _ in enumerate(padded_image):
            padded_image[i, :, :] = np.pad(
                image[:, :, i], ((top, bottom), (left, right)),
                mode='constant', constant_values=constant)
        padded_image = np.transpose(
            padded_image, axes=(1, 2, 0)).astype(np.uint8)

    shapes = [
        # imgsz (model input shape) [height, width]
        [padded_image.shape[0], padded_image.shape[1]],
        # ratio_pad [[scale y, scale x], [pad w, pad h]]
        [[scale, scale], [left, top]]
    ]
    return padded_image, shapes


def letterbox_hal(
    image: Tensor,
    dst: Tensor,
) -> list:
    """
    Applies the letterbox image transformations using HAL.

    Parameters
    ----------
    image: Tensor
        An RGBA tensor image loaded using the HAL.
    dst: Tensor
        The destination tensor image after letterbox transformation.

    Returns
    -------
    label_ratio: list
        Scaling factors (width, height) applied to original boxes.
    shapes: list
        This is used to scale the bounding boxes of the ground
        truth and the model detections based on the letterbox
        transformation. Tuple containing padded image size, scale ratio,
        and padding offsets.
        [[pad image height, pad image width],
        [[scale_y, scale_x], [pad x, pad y]]].
    """
    
    if not _HAL_AVAILABLE:
        raise ImportError(
            "EdgeFirst HAL is needed to perform letterbox using hal."
        )
    
    if image_processor is None:
        raise ImportError(
            "EdgeFirst HAL image processor is not available for letterbox.")

    ratio = min(dst.height / image.height, dst.width / image.width)
    height = image.height * ratio
    width = image.width * ratio
    top = round((dst.height - height) / 2)
    left = round((dst.width - width) / 2)
    height = round(height)
    width = round(width)
    image_processor.convert(image, dst,
                            dst_crop=edgefirst_hal.Rect(left, top, width, height),
                            dst_color=[114, 114, 114, 255])

    shapes = [
        # imgsz (model input shape) [height, width]
        [dst.height, dst.width],
        # ratio_pad [[scale y, scale x], [pad w, pad h]]
        [[ratio, ratio], [left, top]]
    ]
    return shapes


def preprocess_hal(
    image: Tensor,
    input_shape: tuple,
    input_dtype: np.dtype,
    view_tensor: Optional[Callable] = None,
    preprocessing: str = "letterbox",
    normalization: str = "unsigned",
    quantization: Optional[tuple] = None,
    visualize: bool = False,
    camera_adaptor: Optional[str] = None,
) -> Tuple[np.ndarray, np.ndarray, list, tuple]:
    """
    Optimized input preprocessing using the HAL. The process starts with
    an image in RGBA format loaded using HAL, then HAL letterbox, resizing, or
    padding is performed. The image is then converted to RGB, Grey, YUYV, etc.
    (depending on the model's input requirements).

    Parameters
    ----------
    image: Tensor
        The image input to preprocess loaded as RGBA 
        for optimized OpenGL processing.
    input_shape: tuple
        The model input shape. This can either be formatted as
        (batch size, channels, height, width) or
        (batch size, height, width, channels).
    input_dtype: np.dtype
        The input datatype of the model.
    view_tensor: Optional[Callable]
        Callable function for retrieving the input view tensor
        from the model for directly copying the input tensor
        into the model such as the case for TFLite.
    preprocessing: str
        The type of image preprocessing to apply. By default 'letterbox'
        is used. However, 'resize' or 'pad' are possible variations.
    normalization: str
        The type of image normalization to apply. Default is set to
        'unsigned'. However 'signed', 'raw', and 'imagenet' are possible
        values.
    quantization: Optional[tuple]
        The quantization parameters of the input containing
        the (scale, zero point) values.
    visualize: bool
        When visualizing the model outputs, this requires a second
        copy of the transformed image. By default,
        visualization is set to False.
    camera_adaptor: Optional[str]
        The camera adaptor format from model metadata (e.g., "grey", "yuyv").
        When specified, uses CameraAdaptorTransform for color conversion.

    Returns
    -------
    image: np.ndarray
        The image input after being preprocessed.
    visual_image: np.ndarray
        The image that is used for visualization post
        letterbox, padding, resize transformations.
    shapes: list
        This is used to scale the bounding boxes of the ground
        truth and the model detections based on the letterbox/padding
        transformation.

        .. code-block:: python

            [[input_height, input_width],
            [[scale_y, scale_x], [pad_w, pad_h]]]
    image_shape: tuple
        The original image dimensions.
    """

    if not _HAL_AVAILABLE:
        raise ImportError(
            "EdgeFirst HAL is needed to perform preprocessing using hal."
        )
    
    # Fetch only (height, width) from the input_shape.
    # Format for YUYV, RGB, and RGBA
    # MPK may return shape [1, 360, 640, 1] for example.
    transpose = False
    if input_shape[-1] in [1, 2, 3, 4]:
        channels = input_shape[-1]
        input_height, input_width = input_shape[1:3]
    else:
        channels = input_shape[1]
        input_height, input_width = input_shape[2:4]
        transpose = True
    pixel_format = get_hal_pixel_format(channels, transpose, camera_adaptor)
    pixel_format_str = str(pixel_format).replace("PixelFormat.", "")

    height, width = image.height, image.width
    shapes = [
        # imgsz (model input shape) [height, width]
        [int(input_height), int(input_width)],
        [[float(input_height / height), float(input_width / width)],
         [0.0, 0.0]]  # ratio_pad [image_scale, [pad w, pad h]]
    ]

    key = (input_width, input_height, pixel_format_str)
    input_tensor = _TENSOR_CACHE.get(key)
    if input_tensor is None:
        input_tensor = image_processor.create_image(
            input_width, input_height, pixel_format)
        _TENSOR_CACHE[key] = input_tensor

    # Perform letterbox and resizing and add convert to the correct color space
    # based on the model input requirements.
    if preprocessing == "letterbox":
        shapes = letterbox_hal(image, input_tensor)
    elif preprocessing == "pad":
        raise NotImplementedError("Padding with HAL is not yet implemented.")
    else:
        image_processor.convert(image, input_tensor)

    input_array = _NUMPY_CACHE.get(key)
    if input_array is None:
        input_array = (
            np.zeros((channels, input_height, input_width), dtype=input_dtype) 
            if transpose else np.zeros((input_height, input_width, channels), 
                                       dtype=input_dtype))
        _NUMPY_CACHE[key] = input_array

    # Normalize and quantize input tensor
    normalization = get_hal_normalization(input_dtype, normalization)
    zero_point = None
    if quantization is not None:
        if input_dtype == np.uint8:
            # For uint8 quantized models, use zero_point=0 (raw pixel data)
            zero_point = 0
        elif input_dtype == np.int8:
            zero_point = abs(quantization[-1])
    # Directly copy the input tensor into the model for TFLite.
    if view_tensor is not None:
        input_tensor.normalize_to_numpy(view_tensor()[0, :, :, :],
                                        normalization=normalization,
                                        zero_point=zero_point)
    else:
        input_tensor.normalize_to_numpy(input_array,
                                        normalization=normalization,
                                        zero_point=zero_point)
    visual_image = None
    if visualize:
        visual_image = (np.zeros(
            (channels, input_tensor.height, input_tensor.width),
            dtype=np.uint8) if transpose else np.zeros(
            (input_tensor.height, input_tensor.width, channels),
            dtype=np.uint8))
        input_tensor.normalize_to_numpy(visual_image)
        if transpose:
            visual_image = np.transpose(visual_image, axes=(1, 2, 0))
    # Add batch dimension to the image
    input_array = input_array[None]
    return input_array, visual_image, shapes, (height, width)


def preprocess_native(
    image: np.ndarray,
    input_shape: tuple,
    input_dtype: np.dtype,
    view_tensor: Optional[Callable] = None,
    preprocessing: str = "letterbox",
    normalization: str = "unsigned",
    quantization: Optional[tuple] = None,
    backend: str = "hal",
    camera_adaptor: Optional[str] = None,
) -> Tuple[np.ndarray, np.ndarray, list, tuple]:
    """
    Standard preprocessing method. Default parameters are based on
    Ultralytics defaults.

    Parameters
    ----------
    image: np.ndarray
        The image input to preprocess.
    input_shape: tuple
        The model input shape. This can either be formatted as
        (batch size, channels, height, width) or
        (batch size, height, width, channels).
    input_dtype: np.dtype
        The input datatype of the model.
    view_tensor: Optional[Callable]
        Callable function for retrieving the input view tensor
        from the model for directly copying the input tensor
        into the model such as the case for TFLite.
    preprocessing: str
        The type of image preprocessing to apply. By default 'letterbox'
        is used. However, 'resize' or 'pad' are possible variations.
    normalization: str
        The type of image normalization to apply. Default is set to
        'unsigned'. However 'signed', 'raw', and 'imagenet' are possible
        values.
    quantization: Optional[tuple]
        The quantization parameters of the input containing
        the (scale, zero point) values.
    backend: str
        Specify the backend library for letterboxing the
        image from the options "opencv", "pillow".
    camera_adaptor: Optional[str]
        The camera adaptor format from model metadata (e.g., "grey", "yuyv").
        When specified, uses CameraAdaptorTransform for color conversion.

    Returns
    -------
    image: np.ndarray
        The image input after being preprocessed.
    visual_image: np.ndarray
        The image that is used for visualization post
        letterbox, padding, resize transformations.
    shapes: list
        This is used to scale the bounding boxes of the ground
        truth and the model detections based on the letterbox/padding
        transformation.

        .. code-block:: python

            [[input_height, input_width],
            [[scale_y, scale_x], [pad_w, pad_h]]]
    image_shape: tuple
        The original image dimensions.
    """

    # Fetch only (height, width) from the shape.
    # Format for grayscale, YUYV, RGB, and RGBA
    # MPK may return shape [1, 360, 640, 1] for example.
    transpose = False
    if input_shape[-1] in [1, 2, 3, 4]:
        channel = input_shape[-1]
        input_shape = input_shape[1:3]
    else:
        channel = input_shape[1]
        input_shape = input_shape[2:4]
        # Transpose the image to meet requirements of the channel order.
        transpose = True

    # Set up color space transformer based on camera_adaptor or channel count
    transformer = None  # Function that transforms image formats.
    if camera_adaptor and _CAMERAADAPTOR_AVAILABLE:
        # Use CameraAdaptorTransform for color conversion (consistent with training)
        adaptor = CameraAdaptorTransform(camera_adaptor, source_format="rgb")
        def adaptor_transform(img, backend=None):
            result = adaptor(img)
            # Ensure 3D output (H, W, C) - expand grayscale if needed
            if result.ndim == 2:
                result = np.expand_dims(result, -1)
            return result
        transformer = adaptor_transform
    elif channel == 1:
        # Fallback grayscale conversion using OpenCV
        def rgb2grey(img, backend=None):
            import cv2
            grey = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
            return np.expand_dims(grey, -1)
        transformer = rgb2grey
    elif channel == 2:
        transformer = rgb2yuyv
    elif channel == 4:
        transformer = rgb2rgba

    height, width = image.shape[0:2]

    shapes = [
        input_shape,  # imgsz (model input shape) [height, width]
        [[input_shape[0] / height, input_shape[1] / width],
         [0.0, 0.0]]  # ratio_pad [image_scale, [pad w, pad h]]
    ]

    if backend == "opencv":
        # OpenCV reads images into BGR by default.
        image = bgr2rgb(image)

    if preprocessing == "letterbox":
        image, shapes = letterbox_native(
            image, (input_shape[1], input_shape[0]), backend=backend)
    elif preprocessing == "pad":
        image, shapes = pad(
            image, (input_shape[1], input_shape[0]), backend=backend)
    else:
        image = resize(
            image, (input_shape[1], input_shape[0]), backend=backend)

    visual_image = image
    if preprocessing == "pad":
        visual_image = bgr2rgb(visual_image)

    # Convert image format to either YUYV, RGBA or keep as RGB.
    image = transformer(image, backend=backend) if transformer else image

    # Expects batch size, channel, height, width.
    if transpose:
        image = np.transpose(image, axes=[2, 0, 1])

    # Handle full/half precision input types.
    if input_dtype in [np.float16, np.float32]:
        image = image_normalization(image, normalization, input_dtype)

    # For quantized models, run input quantization parameters.
    if quantization is not None:
        if input_dtype == np.uint8:
            # For uint8 quantized models, raw pixel data can be passed directly
            image = image.astype(np.uint8)
        elif input_dtype == np.int8:
            scale, zero_point = quantization
            # Apply proper INT8 quantization: quantized = round(normalized / scale) + zero_point
            # First normalize to [0, 1] range, then quantize
            normalized = image.astype(np.float32) / 255.0
            quantized = np.round(normalized / scale).astype(np.int32) + zero_point
            image = np.clip(quantized, -128, 127).astype(np.int8)

    image = image[None]
    # Directly copy the input tensor into the model for TFLite.
    if view_tensor is not None:
        np.copyto(view_tensor(), image)

    return image, visual_image, shapes, (height, width)
