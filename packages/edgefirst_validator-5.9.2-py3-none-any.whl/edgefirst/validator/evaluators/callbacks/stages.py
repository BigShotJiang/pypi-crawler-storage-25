"""
Implementation for the callback that manages stages of the validation process.
"""

from __future__ import annotations

import threading
import time
import traceback
from typing import TYPE_CHECKING, Generator, Iterable, Optional, Union, Tuple, List

from tqdm import tqdm

if TYPE_CHECKING:
    from edgefirst.validator.publishers import StudioPublisher


class _ProgressReporter:
    """Single-producer / single-consumer progress publisher.

    The main (producer) thread writes the latest ``(stage, message, n,
    total)`` via :meth:`update` — plain attribute assignment that the
    GIL makes visible to the consumer without any synchronisation
    primitive. A daemon (consumer) thread samples at its own cadence
    and posts to EdgeFirst Studio. The producer never blocks on the
    network, on a queue lock, or on the consumer thread.

    Compared to the prior queue-per-update design, this removes the
    synchronous HTTP from the per-sample hot path AND the shared mutex
    that cProfile was attributing to per-image wall time.
    """

    # A brief tick so the reporter both sees newly-written state
    # quickly (user-perceptible progress) and stays mostly asleep so
    # it never contends with the main loop for the GIL.
    _TICK_SECONDS = 0.5

    def __init__(
        self,
        studio_publisher: "StudioPublisher",
        update_interval_samples: int,
    ):
        self._publisher = studio_publisher
        self._update_interval = max(1, int(update_interval_samples))
        # Fields written ONLY by the producer; read by the consumer.
        # int/str assignments are atomic under the GIL so no lock is
        # needed. A torn read would at worst post a slightly stale
        # sample count on the next tick; the tick after that recovers.
        self._stage = ""
        self._message = ""
        self._n = 0
        self._total = 0
        # Fields written ONLY by the consumer.
        self._posted_n = -1
        self._posted_stage = ""
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self):
        """Spawn the daemon reporter. No-op if already running or if
        there is no publisher to post to."""
        if self._publisher is None or self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._loop, name="studio-progress-reporter", daemon=True
        )
        self._thread.start()

    def stop(self, timeout: float = 2.0):
        """Signal the daemon to exit and join briefly."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            self._thread = None

    def update(self, stage: str, message: str, n: int, total: int):
        """Producer-side store. Cheap — no locks, no HTTP."""
        self._stage = stage
        self._message = message
        self._n = n
        self._total = total

    def post_now(self, status: str = "in_progress"):
        """Synchronously flush the latest state. Used at stage
        boundaries where losing the final update would leave Studio
        stuck at a stale percentage."""
        if self._publisher is None:
            return
        self._try_post(self._stage, self._message, self._n, self._total,
                       status=status)

    def retire(self, stage: str, message: str, total: int):
        """Mark a stage as fully complete on Studio (100% + status=complete).

        Called from the producer at stage boundaries to flip Studio's
        stage status from `in_progress`/`Running` to `complete`. Without
        this, intermediate stages stay at "100% in_progress" because
        the daemon only posts the *current* stage; once the producer
        moves on the prior stage's terminal status never lands.

        Also tells the daemon to skip further posts to this stage so a
        late tick can't downgrade it back to in_progress.
        """
        if self._publisher is None:
            return
        self._try_post(stage, message, total, total, status="complete")
        # Pin the consumer's posted state so a stale producer snapshot
        # (e.g. n hasn't been reset before the daemon's next tick) can't
        # re-publish this stage at < 100% in_progress.
        self._posted_stage = stage
        self._posted_n = total

    def _loop(self):
        while not self._stop.is_set():
            self._stop.wait(self._TICK_SECONDS)
            self._sample_and_post()
        # Final flush in case the last sample hasn't been posted.
        self._sample_and_post(force=True)

    def _sample_and_post(self, force: bool = False):
        # Snapshot producer fields. Sequential reads may observe torn
        # state across multiple fields — acceptable for a progress
        # ping (percentage is just a UI hint).
        stage = self._stage
        msg = self._message
        n = self._n
        total = self._total

        if not stage or total <= 0:
            return

        stage_changed = stage != self._posted_stage
        enough_delta = (n - self._posted_n) >= self._update_interval
        at_end = n >= total

        if force or stage_changed or enough_delta or at_end:
            self._try_post(stage, msg, n, total)
            self._posted_n = n
            self._posted_stage = stage

    def _try_post(self, stage, msg, n, total, status="in_progress"):
        try:
            percentage = min(
                100, max(0, round((n / total) * 100))) if total > 0 else 0
            self._publisher.update_stage(
                stage=stage,
                status=status,
                message=msg,
                percentage=percentage,
            )
        except Exception:  # pylint: disable=broad-exception-caught
            # Studio is best-effort — a failed post must never stall
            # the validation run or crash the reporter.
            traceback.print_exc()


class StageTracker:
    """
    Class to manage and display different stages of the validation process.
    """

    def __init__(self, studio_publisher: StudioPublisher = None,
                 update_interval: int = 100):
        self.studio_publisher = studio_publisher
        # Post progress to Studio at most every `update_interval` samples
        # (plus once at the first sample and once at completion). Keeps the
        # main-loop HTTP chatter from stalling inference.
        self.update_interval = max(1, int(update_interval))
        self._reporter: Optional[_ProgressReporter] = None
        if studio_publisher is not None:
            self._reporter = _ProgressReporter(
                studio_publisher=studio_publisher,
                update_interval_samples=self.update_interval,
            )
            self._reporter.start()
        self.stages = {
            "stage_fetch_im": "Download Validation Images",
            "stage_fetch_as": "Download Image Annotations",
            "stage_validate": "Start Inference Validation",
            "stage_vmetrics": "Compute Validation Metrics",
            "stage_optimals": "Compute Optimal Thresholds",
            "stage_dmetrics": "Compute Deployment Metrics",
            "stage_vfigures": "Compute Validation Figures",
        }
        self.current_stage = "stage_fetch_im"

    def shutdown(self):
        """Stop the background progress reporter. Safe to call multiple
        times and safe when no reporter was created."""
        if self._reporter is not None:
            self._reporter.stop()
            self._reporter = None

    def __del__(self):
        # Daemon thread would die with the interpreter anyway but a
        # clean shutdown avoids the "still running" warning on exit.
        try:
            self.shutdown()
        except Exception:  # pylint: disable=broad-exception-caught
            pass

    def add_stage(self, stage: Tuple[str, str], index: Optional[int] = None):
        """
        Adds a new stage to the stages list.

        Parameters
        ----------
        stage_name: str
            The name of the stage.
        index: Optional[int]
            The index to insert the stage at. If None, appends to the end.
        """
        if index is not None:
            stages = list(self.stages.items())
            stages.insert(index, stage)
            self.stages = dict(stages)
        else:
            self.stages[stage[0]] = stage[1]

    def get_stage(self, stage_name: str) -> Tuple[str, str]:
        """
        Retrieves the description of a stage by its name.

        Parameters
        ----------
        stage_name: str
            The name of the stage.

        Returns
        -------
        Tuple[str, str]
            The description of the stage.
        """
        return (stage_name, self.stages.get(stage_name, "Stage not found."))

    def set_stage(self, stage_name: str):
        """
        Sets the current stage.

        Parameters
        ----------
        stage_name: str
            The name of the stage to set as current.

        Raises
        -------
        ValueError
            If the stage name is not found in the stages.
        """
        if stage_name in self.stages.keys():  # pylint: disable=consider-iterating-dictionary
            self.current_stage = stage_name
        else:
            raise ValueError(f"Stage '{stage_name}' not found in stages.")

    def current(self) -> Tuple[str, str]:
        """
        Returns the current stage.

        Returns
        -------
        tuple[str, str]
            The current stage name and description.
        """
        return (self.current_stage, self.stages[self.current_stage])

    def tolist(self) -> List[Tuple[str, str]]:
        """
        Returns the stages as a list of tuples.

        Returns
        -------
        list[tuple[str, str]]
            The list of stages.
        """
        return list(self.stages.items())

    def display_stages(self):
        """
        Displays all the stages in order.
        """
        for stage_name, description in self.stages.items():
            print(f"Stage: {stage_name} - {description}")

    def stage_iterator(
            self, iterable: Iterable, stage_name: str, **tqdm_kwargs) -> tqdm:
        """
        Wrap an iterable with tqdm using the current stage description.

        Parameters
        ----------
        iterable: Iterable
            The iterable to wrap.
        stage_name: str
            The name of the stage to set as current.
        tqdm_kwargs: dict
            Additional keyword arguments for tqdm.

        Returns
        -------
        tqdm.tqdm
            The tqdm-wrapped iterable.
        """
        self.current_stage = stage_name
        return tqdm(iterable, desc=self.stages[stage_name], **tqdm_kwargs)

    def stage_generator(
        self,
        generator: Union[Generator, List],
        stage_name: str,
        **tqdm_kwargs
    ) -> Generator:
        """
        Wrap a generator with tqdm using the current stage description.

        Parameters
        ----------
        generator: Generator
            The generator to wrap.
        stage_name: str
            The name of the stage to set as current.
        tqdm_kwargs: dict
            Additional keyword arguments for tqdm.

        Returns
        -------
        Generator
            The tqdm-wrapped generator.
        """
        self.current_stage = stage_name
        samples = tqdm(generator, desc=self.stages[stage_name], **tqdm_kwargs)
        total = len(samples)
        message = self.stages[stage_name]
        reporter = self._reporter
        completed = False
        try:
            for sample in samples:
                yield sample
                # Lockless producer-side update: the daemon reporter
                # (if one was started for this run) reads this state
                # on its own cadence and posts to Studio. Zero network
                # work, zero queue contention on the hot path.
                if reporter is not None:
                    reporter.update(stage_name, message, samples.n, total)
            completed = True
        finally:
            # Mark the stage complete on Studio when iteration ran to
            # the end. Skip on early exit (consumer broke or raised) so
            # the in-progress state remains visible — Studio shouldn't
            # show "complete" for a stage that didn't finish.
            if reporter is not None and completed:
                reporter.retire(stage_name, message, total)
