"""Logging configuration — stdlib logging with structured output.

Replaces loguru with Python's stdlib ``logging`` module.
File rotation is handled by :class:`logging.handlers.RotatingFileHandler`.
"""

import logging
import logging.handlers
import re
import sys
from pathlib import Path
from typing import Any

from .config import LoggingConfig

# ── Redaction ─────────────────────────────────────────────────────────────────

_REDACT_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (
        re.compile(r'password["\s]*[:=]["\s]*([^"\s,}]+)', re.IGNORECASE),
        'password="***"',
    ),
    (
        re.compile(r'card_expiration["\s]*[:=]["\s]*([^"\s,}]+)', re.IGNORECASE),
        'card_expiration="***"',
    ),
    (
        re.compile(r'smtp.*password["\s]*[:=]["\s]*([^"\s,}]+)', re.IGNORECASE),
        'smtp_password="***"',
    ),
    (
        re.compile(r'from_email["\s]*[:=]["\s]*([^"\s,}]+)', re.IGNORECASE),
        'from_email="***"',
    ),
    (
        re.compile(r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b"),
        "****-****-****-****",
    ),
    (
        re.compile(r'email["\s]*[:=]["\s]*([^"\s,}]+@[^"\s,}]+)', re.IGNORECASE),
        'email="***@***.***"',
    ),
]


class _RedactionFilter(logging.Filter):
    """logging.Filter that scrubs sensitive data from log messages."""

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        for pattern, replacement in _REDACT_PATTERNS:
            msg = pattern.sub(replacement, msg)
        # Replace the formatted message so handlers see the redacted version
        record.msg = msg
        record.args = ()
        return True


# ── Size parser ───────────────────────────────────────────────────────────────

_SIZE_UNITS = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3}


def _parse_size(size_str: str) -> int:
    """Convert a human-readable size string (e.g. ``"10MB"``) to bytes.

    Args:
        size_str: Size string with optional unit suffix.

    Returns:
        Size in bytes.
    """
    s = size_str.strip().upper()
    for unit, mult in _SIZE_UNITS.items():
        if s.endswith(unit):
            return int(s[: -len(unit)]) * mult
    return int(s)


# ── Configuration ─────────────────────────────────────────────────────────────

_ROOT = "tello_renewal"


def configure_logging(config: LoggingConfig | None = None) -> None:
    """Set up stdlib logging for the ``tello_renewal`` package.

    Configures console and/or file handlers on the ``"tello_renewal"``
    logger.  All child loggers (``tello_renewal.utils``, etc.) inherit
    from it automatically.

    Args:
        config: Logging configuration. Defaults to :class:`LoggingConfig` defaults.
    """
    if config is None:
        config = LoggingConfig()

    level: int = getattr(logging, config.level.upper(), logging.INFO)

    root = logging.getLogger(_ROOT)
    root.setLevel(level)
    root.propagate = False
    # Clear any handlers from a previous call (e.g. repeated config in tests)
    root.handlers.clear()

    redaction = _RedactionFilter()

    # ── Console handler ──────────────────────────────────────────────────
    if config.console_output:
        console = logging.StreamHandler(sys.stdout)
        console.setLevel(level)
        console.addFilter(redaction)

        if config.format == "json":
            fmt = (
                '{"time":"%(asctime)s","level":"%(levelname)s",'
                '"logger":"%(name)s","message":"%(message)s"}'
            )
        elif config.format == "simple":
            fmt = "%(asctime)s %(levelname)-8s %(message)s"
        else:  # detailed (default)
            fmt = "%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d - %(message)s"

        console.setFormatter(logging.Formatter(fmt, datefmt="%Y-%m-%d %H:%M:%S"))
        root.addHandler(console)

    # ── File handler ─────────────────────────────────────────────────────
    if config.file:
        log_path = Path(config.file)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.handlers.RotatingFileHandler(
            config.file,
            maxBytes=_parse_size(config.max_size),
            backupCount=config.backup_count,
            encoding="utf-8",
        )
        file_handler.setLevel(level)
        file_handler.addFilter(redaction)
        file_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d - %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        root.addHandler(file_handler)

    # Suppress noisy third-party loggers
    logging.getLogger("urllib3").setLevel(logging.WARNING)


# ── Public API ────────────────────────────────────────────────────────────────


def get_logger(name: str) -> logging.Logger:
    """Return a stdlib logger for *name*.

    Args:
        name: Logger name, typically ``__name__`` of the calling module.

    Returns:
        A :class:`logging.Logger` instance.
    """
    return logging.getLogger(name)


def log_function_call(func_name: str, **kwargs: Any) -> None:
    """Log a function call with its parameters (sensitive data is redacted).

    Args:
        func_name: Name of the function being called.
        **kwargs: Parameters to include in the log message.
    """
    params = ", ".join(f"{k}={v}" for k, v in kwargs.items())
    logging.getLogger(_ROOT).debug("Calling %s(%s)", func_name, params)


def log_duration(operation: str, duration: float) -> None:
    """Log the duration of an operation.

    Args:
        operation: Name of the operation.
        duration: Duration in seconds.
    """
    logging.getLogger(_ROOT).info("%s completed in %.2f seconds", operation, duration)


__all__ = [
    "configure_logging",
    "get_logger",
    "log_function_call",
    "log_duration",
]
