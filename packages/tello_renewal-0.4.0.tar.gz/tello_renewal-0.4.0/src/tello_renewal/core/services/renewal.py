"""Renewal service for Tello renewal system.

This module provides renewal-related business logic including
renewal execution via single-step POST to /process_buy.
"""

from datetime import date

from ...utils.logging import get_logger
from ...web.base_client import TelloWebClientBase

logger = get_logger(__name__)


class RenewalService:
    """Service for renewal-related operations."""

    def __init__(self, web_client: TelloWebClientBase):
        """Initialize renewal service.

        Args:
            web_client: Web client for automation
        """
        self.web_client: TelloWebClientBase = web_client

    def execute_renewal(self, card_expiration: date, dry_run: bool = False) -> bool:
        """Execute the renewal process.

        In the new Tello flow, renewal is a single-step POST. The
        card_expiration parameter is kept for interface compatibility
        but is no longer needed (credit card is pre-bound via autopay).

        Args:
            card_expiration: Credit card expiration date (unused in new flow)
            dry_run: If True, don't actually submit the renewal

        Returns:
            True if renewal was successful

        Raises:
            Exception: If renewal fails
        """
        try:
            logger.info(f"Starting renewal process (dry_run={dry_run})")

            success = self.submit_renewal(dry_run)

            if success:
                logger.info("Renewal process completed successfully")
            else:
                logger.error("Renewal process failed")

            return success

        except Exception as e:
            logger.error(f"Renewal execution failed: {e}")
            raise

    def submit_renewal(self, dry_run: bool = False) -> bool:
        """Submit the renewal order.

        Args:
            dry_run: If True, don't actually submit the form

        Returns:
            True if submission was successful (or skipped in dry run)

        Raises:
            Exception: If submission fails
        """
        try:
            success = self.web_client.submit_renewal()

            if dry_run:
                logger.info("DRY RUN: Renewal submission skipped")
            else:
                logger.info("Renewal submitted successfully")

            return success

        except Exception as e:
            logger.error(f"Failed to submit renewal: {e}")
            raise

    def complete_renewal_process(
        self, card_expiration: date, dry_run: bool = False
    ) -> bool:
        """Complete the entire renewal process in one operation.

        Args:
            card_expiration: Credit card expiration date (unused in new flow)
            dry_run: If True, don't actually submit the renewal

        Returns:
            True if renewal process completed successfully

        Raises:
            Exception: If any step fails
        """
        try:
            if dry_run:
                logger.info("DRY RUN: Complete renewal process skipped")
                return True
            return self.web_client.complete_renewal_process(card_expiration)

        except Exception as e:
            logger.error(f"Complete renewal process failed: {e}")
            raise

    def validate_renewal_prerequisites(self) -> bool:
        """Validate that all prerequisites for renewal are met.

        Returns:
            True if prerequisites are met, False otherwise
        """
        try:
            if not self.web_client.is_logged_in():
                logger.error("User is not logged in")
                return False

            logger.info("Renewal prerequisites validated successfully")
            return True

        except Exception as e:
            logger.error(f"Failed to validate renewal prerequisites: {e}")
            return False
