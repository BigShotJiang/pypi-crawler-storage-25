"""Factory for creating the Tello web client instance.

The only supported backend is **playwright / CloakBrowser**.
Use :func:`create_web_client` as the single entry point; it instantiates
:class:`~tello_renewal.web.playwright_client.PlaywrightWebClient` from the
supplied configuration.
"""

from ..utils.config import HttpClientConfig
from .base_client import TelloWebClientBase


def create_web_client(
    config: HttpClientConfig, dry_run: bool = False
) -> TelloWebClientBase:
    """Instantiate and return a :class:`PlaywrightWebClient`.

    Args:
        config: HTTP/browser configuration (``browser_type``, ``proxy_server``
            are read from here).
        dry_run: If True, skip actual form submission.

    Returns:
        An initialised (but not yet entered) :class:`PlaywrightWebClient`.
    """
    from .playwright_client import PlaywrightWebClient

    return PlaywrightWebClient(config, dry_run=dry_run)
