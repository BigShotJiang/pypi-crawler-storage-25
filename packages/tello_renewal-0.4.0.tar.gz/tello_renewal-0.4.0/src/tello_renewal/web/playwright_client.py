"""Web client for Tello automation using Playwright / CloakBrowser.

This module provides a real-browser-based client that executes JavaScript and
can bypass Cloudflare managed challenges that block pure-HTTP clients.

CloakBrowser (https://github.com/CloakHQ/CloakBrowser) is the primary target:
it applies 57 source-level Chromium patches to defeat bot-detection heuristics
and passes Cloudflare Turnstile, reCAPTCHA v3, etc.  Its ``launch()`` function
returns a standard Playwright **sync** Browser object, so no asyncio is needed.

Standard Playwright (chromium / firefox / webkit) is also supported as a
fallback ``browser_type`` value, though it provides weaker anti-detection coverage.
"""

from datetime import date
from types import TracebackType
from typing import Any

from typing_extensions import Self

from ..core.models import AccountBalance
from ..utils.config import HttpClientConfig
from ..utils.exceptions import LoginError, PageLoadError, RenewalError
from ..utils.logging import get_logger
from .base_client import TelloWebClientBase
from .html_parser import (
    parse_balance,
    parse_plan_balance,
    parse_renewal_date,
)

logger = get_logger(__name__)

# Timeouts (milliseconds for Playwright)
_NAV_TIMEOUT_MS = 60_000  # 60 s — CF challenges can take time
_SELECTOR_TIMEOUT_MS = 15_000
_POST_RENEWAL_WAIT_S = 5  # seconds to wait after clicking renew


class PlaywrightWebClient(TelloWebClientBase):
    """Browser-based Tello client using Playwright sync API or CloakBrowser.

    Launches a real (headless) Chromium-based browser so that JavaScript
    executes normally and Cloudflare's managed challenge can be solved.

    Usage::

        with PlaywrightWebClient(config) as client:
            client.open_login_page(base_url)
            client.login(email, password)
            renewal_date = client.get_renewal_date()
            client.submit_renewal()
    """

    def __init__(self, config: HttpClientConfig, dry_run: bool = False) -> None:
        """Initialize the playwright web client.

        Args:
            config: HTTP/browser configuration (``browser_type``, ``proxy_server``
                are read from here)
            dry_run: If True, skip actual form submission
        """
        self.config = config
        self.dry_run = dry_run

        self._base_url: str = "https://tello.com"
        self._logged_in: bool = False
        self._dashboard_html: str | None = None

        # Sync browser objects — initialised in __enter__
        self._playwright_ctx: Any = None  # only used for standard Playwright backend
        self._browser: Any = None
        self._page: Any = None

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> Self:
        """Launch browser and return self."""
        self._setup()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Close browser."""
        try:
            self._teardown()
        finally:
            self._browser = None
            self._page = None
            self._playwright_ctx = None
            self._logged_in = False
            self._dashboard_html = None

    # ------------------------------------------------------------------
    # Setup / teardown
    # ------------------------------------------------------------------

    def _setup(self) -> None:
        """Launch the browser and open a new page."""
        browser_type = self.config.browser_type.lower()

        proxy_cfg: dict[str, str] | None = None
        if self.config.proxy_server:
            proxy_cfg = {"server": self.config.proxy_server}

        if browser_type == "cloakbrowser":
            try:
                from cloakbrowser import (  # type: ignore[import-untyped]
                    launch,
                )
            except ImportError as exc:
                raise PageLoadError(
                    "The 'cloakbrowser' package is not installed. "
                    "Install it with: pip install 'tello-renewal[playwright]'"
                ) from exc

            launch_kwargs: dict[str, Any] = {"headless": True}
            if proxy_cfg:
                launch_kwargs["proxy"] = proxy_cfg
            self._browser = launch(**launch_kwargs)
            self._playwright_ctx = None

        elif browser_type in ("chromium", "firefox", "webkit"):
            try:
                from playwright.sync_api import (  # type: ignore[import-untyped]
                    sync_playwright,
                )
            except ImportError as exc:
                raise PageLoadError(
                    "The 'playwright' package is not installed. "
                    "Install it with: pip install playwright && playwright install"
                ) from exc

            self._playwright_ctx = sync_playwright().__enter__()
            launcher = getattr(self._playwright_ctx, browser_type)
            self._browser = launcher.launch(headless=True)

        else:
            raise PageLoadError(
                f"Unsupported browser_type '{browser_type}'. "
                "Choose from: cloakbrowser, chromium, firefox, webkit"
            )

        # Open a page (with optional proxy for standard Playwright)
        if browser_type != "cloakbrowser" and proxy_cfg:
            context = self._browser.new_context(proxy=proxy_cfg)
            self._page = context.new_page()
        else:
            self._page = self._browser.new_page()

        logger.info(f"Browser launched (browser_type={browser_type})")

    def _teardown(self) -> None:
        """Close the browser (and playwright context if applicable)."""
        if self._browser is not None:
            try:
                self._browser.close()
            except Exception:
                pass
        if self._playwright_ctx is not None:
            try:
                self._playwright_ctx.__exit__(None, None, None)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _p(self) -> Any:
        """Return the Playwright sync page, raising if not initialised."""
        if self._page is None:
            raise RenewalError(
                "Browser page not initialised. Use PlaywrightWebClient as a context manager."
            )
        return self._page

    def _get_dashboard(self) -> str:
        """Return dashboard HTML, fetching and caching if needed."""
        if self._dashboard_html is None:
            self._dashboard_html = self._fetch_dashboard()
        return self._dashboard_html

    def _invalidate_dashboard_cache(self) -> None:
        """Clear cached dashboard HTML so the next call re-fetches."""
        self._dashboard_html = None

    def _ensure_dashboard(self) -> None:
        """Navigate to the account dashboard if not already there."""
        if "/account/home" not in self._p.url:
            self._p.goto(
                self._base_url + "/account/home",
                wait_until="networkidle",
                timeout=_NAV_TIMEOUT_MS,
            )

    def _fetch_dashboard(self) -> str:
        """Navigate to dashboard and return page HTML.

        Returns:
            Page HTML string

        Raises:
            PageLoadError: If navigation fails
        """
        try:
            self._ensure_dashboard()
            return str(self._p.content())
        except PageLoadError:
            raise
        except Exception as exc:
            raise PageLoadError(f"Failed to fetch dashboard: {exc}") from exc

    # ------------------------------------------------------------------
    # TelloWebClientBase interface
    # ------------------------------------------------------------------

    def open_login_page(self, base_url: str) -> None:
        """Store the base URL.

        Args:
            base_url: Tello website base URL
        """
        self._base_url = base_url.rstrip("/")

    def login(self, email: str, password: str) -> None:
        """Navigate to login page, fill in credentials, and submit.

        Args:
            email: Account email
            password: Account password

        Raises:
            LoginError: If login fails or redirects back to login page
        """
        try:
            logger.info("Navigating to Tello login page…")
            self._p.goto(
                self._base_url + "/account/login",
                wait_until="networkidle",
                timeout=_NAV_TIMEOUT_MS,
            )

            # Wait for the username field (confirms CF challenge is solved)
            self._p.wait_for_selector(
                'input[name="username"]',
                timeout=_SELECTOR_TIMEOUT_MS,
            )

            # Fill credentials
            self._p.fill('input[name="username"]', email)
            self._p.fill('input[name="password"]', password)

            # Submit form
            self._p.click('button[type="submit"]')

            # Wait until we land on the dashboard
            try:
                self._p.wait_for_url(
                    "**/account/home**",
                    timeout=_NAV_TIMEOUT_MS,
                )
            except Exception as nav_exc:
                current = self._p.url
                if "/account/login" in current:
                    raise LoginError(
                        "Login failed — still on login page after submit"
                    ) from nav_exc

            self._logged_in = True
            logger.info(f"Successfully logged in as {email}")

        except LoginError:
            raise
        except Exception as exc:
            raise LoginError(f"Login failed: {exc}") from exc

    def get_renewal_date(self) -> date:
        """Extract renewal date from dashboard HTML.

        Returns:
            Next renewal date
        """
        return parse_renewal_date(self._get_dashboard())

    def get_current_balance(self) -> AccountBalance:
        """Get current account balance from dashboard.

        Returns:
            Current account balance
        """
        return parse_balance(self._get_dashboard())

    def get_plan_balance(self) -> AccountBalance:
        """Get plan balance from dashboard.

        Returns:
            Plan balance
        """
        return parse_plan_balance(self._get_dashboard())

    def submit_renewal(self) -> bool:
        """Click the renew button and verify success by checking renewal date.

        Returns:
            True if renewal succeeded (or skipped in dry-run mode)
        """
        html = self._get_dashboard()

        if self.dry_run:
            logger.info("DRY RUN: Would click button#renew_plan and submit renewal")
            return True

        try:
            pre_date: date | None = parse_renewal_date(html)
        except Exception:
            pre_date = None

        success = self._do_submit_renewal(pre_date)
        if success:
            self._invalidate_dashboard_cache()
        return success

    def _do_submit_renewal(self, pre_date: date | None) -> bool:
        """Click the renew button and verify success.

        Verification strategy (in order):
        1. **URL redirect** — Tello redirects to ``/account/checkout`` on success.
           Any navigation away from the dashboard (other than back to ``/account/login``)
           is treated as success.
        2. **Date advance** — if still on ``/account/home``, check whether the renewal
           date advanced.  Note: for *early* renewals (before the plan expires) Tello
           may keep showing the same expiry date, so an unchanged date is still
           treated as a **conditional success** with a warning.
        3. **Failure** — only if we end up back on the login page.

        Args:
            pre_date: Renewal date before clicking, used for secondary verification

        Returns:
            True if renewal is confirmed (or conditionally) successful
        """
        try:
            self._ensure_dashboard()

            # Wait for and click the renew button
            renew_btn = self._p.locator("button#renew_plan")
            renew_btn.wait_for(state="visible", timeout=_SELECTOR_TIMEOUT_MS)
            logger.info("Clicking button#renew_plan…")

            # Use expect_navigation to capture the redirect that follows the click
            with self._p.expect_navigation(
                timeout=_NAV_TIMEOUT_MS, wait_until="networkidle"
            ):
                renew_btn.click()

            post_click_url = self._p.url
            logger.info(f"Post-click URL: {post_click_url}")

            # PRIMARY: URL-based verification
            if "/account/login" in post_click_url:
                logger.error(
                    "Renewal failed — redirected to login page after clicking renew"
                )
                return False

            if "/account/home" not in post_click_url:
                # Navigated to checkout or another page — Tello processed the renewal
                logger.info(f"Renewal accepted — Tello redirected to {post_click_url}")
                return True

            # SECONDARY: still on dashboard — check date change
            new_html = str(self._p.content())
            try:
                new_date = parse_renewal_date(new_html)
                if pre_date is not None and new_date > pre_date:
                    logger.info(
                        f"Renewal verified: date advanced {pre_date} → {new_date}"
                    )
                    return True
                elif pre_date is None:
                    logger.info(
                        "Renewal submitted; could not compare dates (no pre_date). "
                        "Treating as success."
                    )
                    return True
                else:
                    # Date unchanged — this is normal for early renewal (plan not
                    # yet expired).  Log a warning but treat as success.
                    logger.warning(
                        f"Renewal date unchanged after clicking renew "
                        f"(pre={pre_date}, post={new_date}). "
                        "This is normal for early renewals — Tello updates the date "
                        "after the current plan expires. Treating as success."
                    )
                    return True
            except Exception as exc:
                logger.warning(
                    f"Could not parse renewal date for verification: {exc}. "
                    "Button was clicked without error — treating as success."
                )
                return True

        except Exception as exc:
            logger.error(f"Playwright renewal submission failed: {exc}")
            return False

    def complete_renewal_process(self, expiration_date: date) -> bool:
        """Delegate to submit_renewal (expiration_date unused in browser flow).

        Args:
            expiration_date: Unused; kept for interface compatibility

        Returns:
            True if renewal completed successfully
        """
        return self.submit_renewal()

    def is_logged_in(self) -> bool:
        """Return True if login was completed successfully.

        Returns:
            True if logged in
        """
        return self._logged_in

    def get_current_url(self) -> str:
        """Return the current browser page URL.

        Returns:
            Current URL string
        """
        return str(self._p.url)

    def get_page_title(self) -> str:
        """Return the current page title.

        Returns:
            Page title string
        """
        try:
            return str(self._p.title())
        except Exception:
            return "Tello"
