"""Abstract base class for Tello web clients.

This module defines the interface that all web client implementations must satisfy,
enabling interchangeable backends (e.g., primp HTTP, Playwright/CloakBrowser).
"""

from abc import ABC, abstractmethod
from datetime import date
from types import TracebackType

from typing_extensions import Self

from ..core.models import AccountBalance


class TelloWebClientBase(ABC):
    """Abstract base for all Tello web client implementations.

    Implementations must support context manager usage and expose the
    full set of operations used by the service layer.
    """

    @abstractmethod
    def __enter__(self) -> Self:
        """Initialize and return the client."""
        ...

    @abstractmethod
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Clean up resources."""
        ...

    @abstractmethod
    def open_login_page(self, base_url: str) -> None:
        """Set the base URL (and optionally navigate to the login page).

        Args:
            base_url: Tello website base URL
        """
        ...

    @abstractmethod
    def login(self, email: str, password: str) -> None:
        """Login to Tello account.

        Args:
            email: Account email
            password: Account password

        Raises:
            LoginError: If login fails
        """
        ...

    @abstractmethod
    def get_renewal_date(self) -> date:
        """Extract next renewal date from the account dashboard.

        Returns:
            Next renewal date

        Raises:
            PageLoadError: If page cannot be fetched
            ElementNotFoundError: If renewal date cannot be parsed
        """
        ...

    @abstractmethod
    def get_current_balance(self) -> AccountBalance:
        """Get current account balance from the dashboard.

        Returns:
            Current account balance
        """
        ...

    @abstractmethod
    def get_plan_balance(self) -> AccountBalance:
        """Get the plan balance (what the plan provides each renewal cycle).

        Returns:
            Plan balance
        """
        ...

    @abstractmethod
    def submit_renewal(self) -> bool:
        """Submit the renewal form / click the renew button.

        Returns:
            True if submission succeeded (or was skipped in dry-run mode)
        """
        ...

    @abstractmethod
    def complete_renewal_process(self, expiration_date: date) -> bool:
        """Complete the entire renewal process.

        The ``expiration_date`` parameter is kept for interface compatibility
        but may not be used by all backends.

        Args:
            expiration_date: Credit card expiration date (may be unused)

        Returns:
            True if renewal process completed successfully
        """
        ...

    @abstractmethod
    def is_logged_in(self) -> bool:
        """Return whether the client currently has an authenticated session.

        Returns:
            True if logged in
        """
        ...

    @abstractmethod
    def get_current_url(self) -> str:
        """Return the current page URL (or a best approximation).

        Returns:
            Current URL string
        """
        ...

    @abstractmethod
    def get_page_title(self) -> str:
        """Return the current page title.

        Returns:
            Page title string
        """
        ...
