"""Web automation module for Tello renewal system.

Uses the **playwright / CloakBrowser** backend exclusively to execute
real-browser automation that bypasses Cloudflare managed challenges.

Use :func:`create_web_client` as the single entry point.
"""

from .base_client import TelloWebClientBase
from .factory import create_web_client
from .playwright_client import PlaywrightWebClient

__all__ = [
    "TelloWebClientBase",
    "PlaywrightWebClient",
    "create_web_client",
]
