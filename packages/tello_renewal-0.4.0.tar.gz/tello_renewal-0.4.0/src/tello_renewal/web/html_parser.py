"""HTML parser for Tello dashboard pages.

This module extracts renewal dates and balances from Tello dashboard HTML
using the zerodep soup module (BeautifulSoup-compatible API, stdlib only).
"""

import re
from datetime import date, datetime

from .._vendor.soup import Soup
from ..core.models import AccountBalance, BalanceQuantity
from ..utils.exceptions import ElementNotFoundError
from ..utils.logging import get_logger

logger = get_logger(__name__)


def parse_renewal_date(html: str) -> date:
    """Extract renewal date from dashboard HTML.

    Looks for dates in MM/DD/YYYY format within span.card_text > span elements.

    Args:
        html: Dashboard page HTML

    Returns:
        Next renewal date

    Raises:
        ElementNotFoundError: If renewal date cannot be found or parsed
    """
    soup = Soup(html)

    # Primary: look in span.card_text > span (original locator)
    for card_text in soup.select("span.card_text > span"):
        text = card_text.get_text(strip=True)
        try:
            return datetime.strptime(text, "%m/%d/%Y").date()
        except ValueError:
            continue

    # Fallback: find any MM/DD/YYYY date in the page
    date_matches = re.findall(r"\b(\d{1,2}/\d{1,2}/\d{4})\b", html)
    for date_str in date_matches:
        try:
            return datetime.strptime(date_str, "%m/%d/%Y").date()
        except ValueError:
            continue

    raise ElementNotFoundError("Could not find renewal date on dashboard")


def parse_balance(html: str) -> AccountBalance:
    """Extract current account balance from dashboard HTML.

    Parses data (GB), minutes, and texts from balance-details elements.

    Args:
        html: Dashboard page HTML

    Returns:
        Current account balance

    Raises:
        ElementNotFoundError: If balance cannot be extracted
    """
    soup = Soup(html)

    # Find balance-details elements
    details = soup.select(".balance-details")

    if len(details) >= 2:
        data_text = details[0].get_text(separator="\n", strip=True)
        minutes_text = details[1].get_text(separator="\n", strip=True)
        texts_text = (
            details[2].get_text(separator="\n", strip=True)
            if len(details) >= 3
            else "unlimited texts"
        )

        return AccountBalance(
            data=BalanceQuantity.from_tello(data_text),
            minutes=BalanceQuantity.from_tello(minutes_text),
            texts=BalanceQuantity.from_tello(texts_text),
        )

    # Fallback: search for patterns in the page text
    data_match = re.search(r"(\d+(?:\.\d+)?)\s*GB", html)
    min_match = re.search(
        r"(\d+)\s*min(?:utes)?|unlimited\s*min(?:utes)?", html, re.IGNORECASE
    )
    txt_match = re.search(r"(\d+)\s*texts?|unlimited\s*texts?", html, re.IGNORECASE)

    if data_match:
        data_str = f"{data_match.group(1)} GB"
        if min_match:
            if "unlimited" in min_match.group(0).lower():
                min_str = "unlimited minutes"
            else:
                min_str = f"{min_match.group(1)} minutes"
        else:
            min_str = "unlimited minutes"

        if txt_match:
            if "unlimited" in txt_match.group(0).lower():
                txt_str = "unlimited texts"
            else:
                txt_str = f"{txt_match.group(1)} texts"
        else:
            txt_str = "unlimited texts"

        return AccountBalance(
            data=BalanceQuantity.from_tello(data_str),
            minutes=BalanceQuantity.from_tello(min_str),
            texts=BalanceQuantity.from_tello(txt_str),
        )

    raise ElementNotFoundError("Could not extract balance from dashboard")


def parse_plan_balance(html: str) -> AccountBalance:
    """Extract plan balance (what the plan provides) from dashboard HTML.

    Args:
        html: Dashboard page HTML

    Returns:
        Plan balance

    Raises:
        ElementNotFoundError: If plan balance cannot be extracted
    """
    soup = Soup(html)

    # Look for plan info in div.subtitle > div.subtitle_heading
    plan_data_el = soup.select_one("div.subtitle > div.subtitle_heading")
    plan_minutes_el = soup.select_one("div.subtitle > div:nth-child(4)")
    plan_texts_el = soup.select_one("div.subtitle > div:nth-child(5)")

    if plan_data_el:
        data_text = plan_data_el.get_text(separator="\n", strip=True)
        minutes_text = (
            plan_minutes_el.get_text(separator="\n", strip=True)
            if plan_minutes_el
            else "unlimited minutes"
        )
        texts_text = (
            plan_texts_el.get_text(separator="\n", strip=True)
            if plan_texts_el
            else "unlimited texts"
        )

        return AccountBalance(
            data=BalanceQuantity.from_tello(data_text),
            minutes=BalanceQuantity.from_tello(minutes_text),
            texts=BalanceQuantity.from_tello(texts_text),
        )

    # Fallback: try to parse from the renew button text (e.g., "Renew now | $8 + taxes")
    # and infer plan from page content
    renew_btn = soup.select_one("button#renew_plan")
    if renew_btn:
        # The plan details might be elsewhere on the page
        logger.warning("Could not find plan balance selectors, using fallback")

    raise ElementNotFoundError("Could not extract plan balance from dashboard")


def parse_account_balance_amount(html: str) -> float | None:
    """Extract the dollar balance amount from the dashboard.

    Looks for "Remaining balance" text near a dollar amount.

    Args:
        html: Dashboard page HTML

    Returns:
        Balance amount in dollars, or None if not found
    """
    soup = Soup(html)

    # Look in pack_card elements
    for card in soup.select(".pack_card"):
        card_text = card.get_text()
        if "Remaining balance" in card_text:
            # Handle Unicode directional marks
            balance_match = re.search(r"[⁦]?\$(\d+(?:\.\d{2})?)[⁩]?", card_text)
            if balance_match:
                return float(balance_match.group(1))

    # Fallback: any $ amount near "balance"
    balance_match = re.search(r"[Bb]alance[^$]*\$(\d+(?:\.\d{2})?)", html)
    if balance_match:
        return float(balance_match.group(1))

    return None
