"""Tests for HTML parser module."""

from datetime import date

import pytest

from src.tello_renewal.web.html_parser import (
    parse_account_balance_amount,
    parse_renewal_date,
)

# Fixture: minimal dashboard HTML with renewal date
DASHBOARD_HTML = """
<html>
<head><title>My Tello</title></head>
<body>
<div class="card">
  <span class="card_text"><span>04/15/2026</span></span>
</div>
<div class="balance-details">8.94 GB</div>
<div class="balance-details">100 minutes</div>
<div class="balance-details">unlimited texts</div>
<div class="pack_card">
  Remaining balance
  <span>⁦$8.00⁩</span>
</div>
<div class="subtitle">
  <div class="subtitle_heading">2 GB</div>
  <div>Plan details</div>
  <div>something</div>
  <div>100 minutes</div>
  <div>unlimited texts</div>
</div>
<form action="/process_buy" method="post" class="wid">
  <input type="hidden" name="_token" value="abc123token"/>
  <input class="hidden" type="text" name="_nothing_55e6552114599afc" value=""/>
  <input type="hidden" name="_snowman" value="☃"/>
  <input type="hidden" name="products[0][product_id]" value="683"/>
  <input type="hidden" name="products[0][quantity]" value="1"/>
  <input type="hidden" name="parent_subscription_id" value="30384231"/>
  <button type="submit" id="renew_plan">Renew now | ⁦$8⁩ + taxes</button>
</form>
</body>
</html>
"""


class TestParseRenewalDate:
    """Tests for parse_renewal_date."""

    def test_parse_from_card_text(self):
        """Test parsing date from span.card_text > span."""
        result = parse_renewal_date(DASHBOARD_HTML)
        assert result == date(2026, 4, 15)

    def test_parse_different_date(self):
        """Test parsing a different date format."""
        html = '<span class="card_text"><span>12/31/2025</span></span>'
        result = parse_renewal_date(html)
        assert result == date(2025, 12, 31)

    def test_fallback_to_regex(self):
        """Test fallback regex when card_text not present."""
        html = "<p>Next renewal: 01/05/2026</p>"
        result = parse_renewal_date(html)
        assert result == date(2026, 1, 5)

    def test_no_date_raises(self):
        """Test that missing date raises ElementNotFoundError."""
        from src.tello_renewal.utils.exceptions import ElementNotFoundError

        with pytest.raises(ElementNotFoundError):
            parse_renewal_date("<html><body>No dates here</body></html>")


class TestParseAccountBalance:
    """Tests for parse_account_balance_amount."""

    def test_parse_balance_from_pack_card(self):
        """Test extracting balance amount."""
        result = parse_account_balance_amount(DASHBOARD_HTML)
        assert result == 8.00

    def test_no_balance_returns_none(self):
        """Test that missing balance returns None."""
        result = parse_account_balance_amount("<html><body>Nothing</body></html>")
        assert result is None
