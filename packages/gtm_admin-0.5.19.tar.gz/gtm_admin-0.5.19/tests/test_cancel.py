"""Tests for the cancel workflow-run endpoints."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from gtm_admin.database import get_session
from gtm_admin.deps import get_current_user
from gtm_admin.models import TriggerType, Workflow, WorkflowRun, WorkflowStatus
from gtm_admin.router import create_router


def _build_run(status: WorkflowStatus = WorkflowStatus.pending) -> WorkflowRun:
    return WorkflowRun(
        id=42,
        workflow_id=1,
        status=status,
        triggered_by=TriggerType.cron,
        data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}},
    )


def _make_client(
    run: WorkflowRun | None,
    pending_runs: list[WorkflowRun] | None = None,
    workflows: list[Workflow] | None = None,
):
    """Create a TestClient with mocked session and auth dependencies."""
    app = FastAPI()
    router = create_router("testsecret", {}, {}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    async def _override_session():
        session = AsyncMock()

        wf = Workflow(id=1, name="my_workflow") if run is not None else None

        async def _mock_get(model_cls, pk):
            if model_cls is WorkflowRun:
                return run
            if model_cls is Workflow:
                return wf
            return None

        session.get = _mock_get
        session.add = MagicMock()

        # exec() is called by cancel-pending to fetch pending runs and their workflows
        exec_calls = []

        async def _mock_exec(stmt):
            result = MagicMock()
            call_idx = len(exec_calls)
            exec_calls.append(stmt)
            if call_idx == 0:
                # First exec: fetch pending WorkflowRuns
                result.all.return_value = pending_runs or []
            else:
                # Second exec: fetch Workflows for name resolution
                result.all.return_value = workflows or []
            return result

        session.exec = _mock_exec
        yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")

    return TestClient(app)


# ---------------------------------------------------------------------------
# POST /workflow-runs/{id}/cancel
# ---------------------------------------------------------------------------


@patch("gtm_admin.router.manager")
def test_cancel_run_not_found(mock_manager):
    mock_manager.broadcast = AsyncMock()
    client = _make_client(run=None)
    resp = client.post("/api/workflow-runs/42/cancel")
    assert resp.status_code == 404
    mock_manager.broadcast.assert_not_called()


@pytest.mark.parametrize("terminal_status", [
    WorkflowStatus.success,
    WorkflowStatus.failed,
    WorkflowStatus.cancelled,
])
@patch("gtm_admin.router.manager")
def test_cancel_run_already_terminal(mock_manager, terminal_status):
    mock_manager.broadcast = AsyncMock()
    run = _build_run(status=terminal_status)
    client = _make_client(run=run)
    resp = client.post(f"/api/workflow-runs/{run.id}/cancel")
    assert resp.status_code == 409
    assert "terminal" in resp.json()["detail"].lower()
    mock_manager.broadcast.assert_not_called()


@patch("gtm_admin.router.manager")
def test_cancel_pending_run(mock_manager):
    mock_manager.broadcast = AsyncMock()
    run = _build_run(status=WorkflowStatus.pending)
    client = _make_client(run=run)
    resp = client.post(f"/api/workflow-runs/{run.id}/cancel")
    assert resp.status_code == 200
    assert resp.json() == {"status": "cancelled"}
    assert run.status == WorkflowStatus.cancelled
    assert run.finished_at is not None


@patch("gtm_admin.router.manager")
def test_cancel_running_run(mock_manager):
    mock_manager.broadcast = AsyncMock()
    run = _build_run(status=WorkflowStatus.running)
    client = _make_client(run=run)
    resp = client.post(f"/api/workflow-runs/{run.id}/cancel")
    assert resp.status_code == 200
    assert resp.json() == {"status": "cancelled"}
    assert run.status == WorkflowStatus.cancelled
    assert run.finished_at is not None


@patch("gtm_admin.router.manager")
def test_cancel_running_run_cancels_live_task(mock_manager):
    """If a live asyncio task is registered for the run, it is cancelled."""
    import gtm_admin.decorator as dec

    mock_manager.broadcast = AsyncMock()
    run = _build_run(status=WorkflowStatus.running)

    # Simulate a live task registered for this run using a mock
    mock_task = MagicMock()
    mock_task.done.return_value = False
    dec._running_tasks[run.id] = mock_task

    try:
        client = _make_client(run=run)
        client.post(f"/api/workflow-runs/{run.id}/cancel")
        mock_task.cancel.assert_called_once()
    finally:
        dec._running_tasks.pop(run.id, None)


@patch("gtm_admin.router.manager")
def test_cancel_run_broadcasts_twice(mock_manager):
    """Should broadcast to both workflow_list and workflow_detail channels."""
    mock_manager.broadcast = AsyncMock()
    run = _build_run(status=WorkflowStatus.pending)
    client = _make_client(run=run)
    client.post(f"/api/workflow-runs/{run.id}/cancel")
    assert mock_manager.broadcast.call_count == 2
    channels = [call.args[0] for call in mock_manager.broadcast.call_args_list]
    assert "workflow_list" in channels
    assert f"workflow_detail:{run.id}" in channels


# ---------------------------------------------------------------------------
# POST /workflow-runs/cancel-pending
# ---------------------------------------------------------------------------


@patch("gtm_admin.router.manager")
def test_cancel_pending_none_pending(mock_manager):
    """Returns 0 when there are no pending runs."""
    mock_manager.broadcast = AsyncMock()
    client = _make_client(run=None, pending_runs=[])
    resp = client.post("/api/workflow-runs/cancel-pending")
    assert resp.status_code == 200
    assert resp.json() == {"cancelled": 0}
    mock_manager.broadcast.assert_not_called()


@patch("gtm_admin.router.manager")
def test_cancel_pending_cancels_all(mock_manager):
    """All pending runs are cancelled and the count is returned."""
    mock_manager.broadcast = AsyncMock()
    runs = [
        WorkflowRun(id=1, workflow_id=1, status=WorkflowStatus.pending,
                    triggered_by=TriggerType.cron,
                    data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}}),
        WorkflowRun(id=2, workflow_id=1, status=WorkflowStatus.pending,
                    triggered_by=TriggerType.manual,
                    data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}}),
        WorkflowRun(id=3, workflow_id=2, status=WorkflowStatus.pending,
                    triggered_by=TriggerType.cron,
                    data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}}),
    ]
    wfs = [Workflow(id=1, name="wf_one"), Workflow(id=2, name="wf_two")]
    client = _make_client(run=None, pending_runs=runs, workflows=wfs)
    resp = client.post("/api/workflow-runs/cancel-pending")
    assert resp.status_code == 200
    assert resp.json() == {"cancelled": 3}
    for run in runs:
        assert run.status == WorkflowStatus.cancelled
        assert run.finished_at is not None


@patch("gtm_admin.router.manager")
def test_cancel_pending_broadcasts_per_run(mock_manager):
    """Broadcasts 2 messages (list + detail) for every cancelled run."""
    mock_manager.broadcast = AsyncMock()
    runs = [
        WorkflowRun(id=10, workflow_id=1, status=WorkflowStatus.pending,
                    triggered_by=TriggerType.cron,
                    data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}}),
        WorkflowRun(id=11, workflow_id=1, status=WorkflowStatus.pending,
                    triggered_by=TriggerType.cron,
                    data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}}),
    ]
    wfs = [Workflow(id=1, name="wf_one")]
    client = _make_client(run=None, pending_runs=runs, workflows=wfs)
    client.post("/api/workflow-runs/cancel-pending")
    # 2 runs × 2 channels each = 4 broadcasts
    assert mock_manager.broadcast.call_count == 4
    channels = [call.args[0] for call in mock_manager.broadcast.call_args_list]
    assert channels.count("workflow_list") == 2
    assert f"workflow_detail:10" in channels
    assert f"workflow_detail:11" in channels


# ---------------------------------------------------------------------------
# POST /workflow-runs/cancel-all
# ---------------------------------------------------------------------------


@patch("gtm_admin.router.manager")
def test_cancel_all_none_active(mock_manager):
    """Returns 0 when there are no pending or running runs."""
    mock_manager.broadcast = AsyncMock()
    client = _make_client(run=None, pending_runs=[])
    resp = client.post("/api/workflow-runs/cancel-all")
    assert resp.status_code == 200
    assert resp.json() == {"cancelled": 0}
    mock_manager.broadcast.assert_not_called()


@patch("gtm_admin.router.manager")
def test_cancel_all_cancels_pending_and_running(mock_manager):
    """Both pending and running runs are cancelled and count is returned."""
    mock_manager.broadcast = AsyncMock()
    runs = [
        WorkflowRun(id=1, workflow_id=1, status=WorkflowStatus.pending,
                    triggered_by=TriggerType.cron,
                    data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}}),
        WorkflowRun(id=2, workflow_id=1, status=WorkflowStatus.running,
                    triggered_by=TriggerType.manual,
                    data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}}),
    ]
    wfs = [Workflow(id=1, name="wf_one")]
    client = _make_client(run=None, pending_runs=runs, workflows=wfs)
    resp = client.post("/api/workflow-runs/cancel-all")
    assert resp.status_code == 200
    assert resp.json() == {"cancelled": 2}
    for run in runs:
        assert run.status == WorkflowStatus.cancelled
        assert run.finished_at is not None


@patch("gtm_admin.router.manager")
def test_cancel_all_broadcasts_per_run(mock_manager):
    """Broadcasts 2 messages (list + detail) for every cancelled run."""
    mock_manager.broadcast = AsyncMock()
    runs = [
        WorkflowRun(id=20, workflow_id=1, status=WorkflowStatus.pending,
                    triggered_by=TriggerType.cron,
                    data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}}),
        WorkflowRun(id=21, workflow_id=1, status=WorkflowStatus.running,
                    triggered_by=TriggerType.cron,
                    data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}}),
    ]
    wfs = [Workflow(id=1, name="wf_one")]
    client = _make_client(run=None, pending_runs=runs, workflows=wfs)
    client.post("/api/workflow-runs/cancel-all")
    # 2 runs × 2 channels each = 4 broadcasts
    assert mock_manager.broadcast.call_count == 4
    channels = [call.args[0] for call in mock_manager.broadcast.call_args_list]
    assert channels.count("workflow_list") == 2
    assert "workflow_detail:20" in channels
    assert "workflow_detail:21" in channels
