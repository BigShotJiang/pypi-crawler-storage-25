"""Tests for workflow enable/disable via the trigger endpoint."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from gtm_admin.database import get_session
from gtm_admin.deps import get_current_user
from gtm_admin.models import Workflow
from gtm_admin.router import create_router
from gtm_admin.trigger_context import TriggerContext

_WORKFLOW_META = {
    "my_workflow": {
        "trigger_type": "manual",
        "cron": None,
        "interval": None,
        "is_webhook": False,
        "webhook_path": None,
    }
}


def _make_client(cfg: Workflow | None = None, invoke=None):
    captured: dict = {}

    async def default_invoke(name: str, ctx: TriggerContext) -> None:
        captured["name"] = name
        captured["ctx"] = ctx

    app = FastAPI()
    router = create_router("testsecret", {}, _WORKFLOW_META, invoke=invoke or default_invoke)
    app.include_router(router, prefix="/api")

    async def _override_session():
        mock_exec_result = MagicMock()
        mock_exec_result.first = MagicMock(return_value=cfg)
        session = AsyncMock()
        session.exec = AsyncMock(return_value=mock_exec_result)
        yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")

    return TestClient(app), captured


def test_trigger_workflow_not_found():
    client, _ = _make_client()
    resp = client.post(f"/api/workflows/unknown_workflow/trigger", json={"inputs": {}})
    assert resp.status_code == 404


def test_trigger_disabled_returns_409():
    cfg = Workflow(name="my_workflow", enabled=False)
    client, captured = _make_client(cfg=cfg)
    resp = client.post("/api/workflows/my_workflow/trigger", json={"inputs": {}})
    assert resp.status_code == 409
    assert "disabled" in resp.json()["detail"].lower()
    assert "name" not in captured


def test_trigger_enabled_returns_202():
    cfg = Workflow(name="my_workflow", enabled=True)
    client, captured = _make_client(cfg=cfg)
    resp = client.post("/api/workflows/my_workflow/trigger", json={"inputs": {}})
    assert resp.status_code == 202
    assert captured["name"] == "my_workflow"


def test_trigger_no_config_defaults_to_enabled():
    """A workflow with no DB row should be treated as enabled."""
    client, captured = _make_client(cfg=None)
    resp = client.post("/api/workflows/my_workflow/trigger", json={"inputs": {}})
    assert resp.status_code == 202
    assert captured["name"] == "my_workflow"


def test_trigger_passes_inputs_and_type():
    client, captured = _make_client(cfg=None)
    resp = client.post("/api/workflows/my_workflow/trigger", json={"inputs": {"key": "value"}})
    assert resp.status_code == 202
    assert captured["ctx"].inputs == {"key": "value"}
    assert captured["ctx"].type == "manual"
