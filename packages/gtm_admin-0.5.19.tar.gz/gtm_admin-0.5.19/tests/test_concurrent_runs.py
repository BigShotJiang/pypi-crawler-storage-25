"""Tests for max_concurrent_runs enforcement in make_workflow_wrapper."""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import gtm_admin.decorator as dec
from gtm_admin.decorator import make_workflow_wrapper
from gtm_admin.models import Workflow, WorkflowRun, WorkflowStatus


def _mock_session_local(cfg: Workflow | None, running_count: int = 0, capture_add: list | None = None):
    mock_exec_result = MagicMock()
    mock_exec_result.first = MagicMock(return_value=cfg)

    mock_count_result = MagicMock()
    mock_count_result.scalar_one = MagicMock(return_value=running_count)

    async def _refresh(obj):
        if hasattr(obj, "id") and obj.id is None:
            obj.id = 1

    session = AsyncMock()
    session.exec = AsyncMock(return_value=mock_exec_result)
    session.execute = AsyncMock(return_value=mock_count_result)
    if capture_add is not None:
        session.add = MagicMock(side_effect=lambda obj: capture_add.append(obj))
    else:
        session.add = MagicMock()
    session.refresh = _refresh

    cm = AsyncMock()
    cm.__aenter__ = AsyncMock(return_value=session)
    cm.__aexit__ = AsyncMock(return_value=None)
    return MagicMock(return_value=cm)


@pytest.fixture(autouse=True)
def _patch_broadcast():
    mock_manager = MagicMock()
    mock_manager.broadcast = AsyncMock()
    with patch("gtm_admin.broadcast.manager", mock_manager):
        with patch("gtm_admin.decorator._ensure_drain_task"):
            with patch("gtm_admin.decorator._notify_drain"):
                yield


@pytest.mark.asyncio
async def test_under_limit_runs():
    calls = []

    async def my_workflow(inputs: dict):
        calls.append(inputs)
        return {"ok": True}

    cfg = Workflow(id=1, name="my_workflow", max_concurrent_runs=2)
    with patch("gtm_admin.decorator._SessionLocal", _mock_session_local(cfg, running_count=1)):
        result = await make_workflow_wrapper(my_workflow)({})

    assert len(calls) == 1
    assert result == {"ok": True}


@pytest.mark.asyncio
async def test_at_limit_queues_pending_run():
    """When at the concurrency limit a pending WorkflowRun is created, not silently skipped."""
    calls = []
    added: list = []

    async def my_workflow(inputs: dict):
        calls.append(inputs)

    cfg = Workflow(id=1, name="my_workflow", max_concurrent_runs=1)
    with patch("gtm_admin.decorator._SessionLocal", _mock_session_local(cfg, running_count=1, capture_add=added)):
        result = await make_workflow_wrapper(my_workflow)({})

    assert calls == []   # fn is not called immediately — it is queued
    assert result is None
    pending = [o for o in added if isinstance(o, WorkflowRun) and o.status == WorkflowStatus.pending]
    assert len(pending) == 1


@pytest.mark.asyncio
async def test_exactly_at_zero_limit_skipped():
    calls = []

    async def my_workflow(inputs: dict):
        calls.append(inputs)

    cfg = Workflow(id=1, name="my_workflow", max_concurrent_runs=0)
    with patch("gtm_admin.decorator._SessionLocal", _mock_session_local(cfg, running_count=0)):
        result = await make_workflow_wrapper(my_workflow)({})

    assert calls == []
    assert result is None


@pytest.mark.asyncio
async def test_no_limit_in_config_always_runs():
    calls = []

    async def my_workflow(inputs: dict):
        calls.append(inputs)

    cfg = Workflow(id=1, name="my_workflow", max_concurrent_runs=None)
    with patch("gtm_admin.decorator._SessionLocal", _mock_session_local(cfg, running_count=99)):
        await make_workflow_wrapper(my_workflow)({})

    assert len(calls) == 1


@pytest.mark.asyncio
async def test_no_config_row_always_runs():
    calls = []

    async def my_workflow(inputs: dict):
        calls.append(inputs)

    with patch("gtm_admin.decorator._SessionLocal", _mock_session_local(None, running_count=99)):
        await make_workflow_wrapper(my_workflow)({})

    assert len(calls) == 1


@pytest.mark.asyncio
async def test_execute_existing_run_runs_fn():
    """_execute_existing_run transitions a pending run to running and calls fn."""
    from gtm_admin.decorator import _execute_existing_run

    calls = []

    async def my_workflow(inputs: dict):
        calls.append(inputs)
        return {"done": True}

    pending_run = WorkflowRun(
        id=5,
        workflow_id=1,
        status=WorkflowStatus.pending,
        triggered_by="manual",
        data={"trigger_context": {}, "nodes": [], "inputs": {"x": 42}, "outputs": {}},
    )
    cfg = Workflow(id=1, name="my_workflow")

    mock_wf_result = MagicMock()
    mock_wf_result.first = MagicMock(return_value=cfg)

    async def _refresh(obj):
        if hasattr(obj, "id") and obj.id is None:
            obj.id = 99

    session = AsyncMock()
    session.get = AsyncMock(return_value=pending_run)
    session.exec = AsyncMock(return_value=mock_wf_result)
    session.add = MagicMock()
    session.refresh = _refresh

    mock_count_r = MagicMock()
    mock_count_r.scalar_one = MagicMock(return_value=0)
    session.execute = AsyncMock(return_value=mock_count_r)

    cm = AsyncMock()
    cm.__aenter__ = AsyncMock(return_value=session)
    cm.__aexit__ = AsyncMock(return_value=None)

    with patch("gtm_admin.decorator._SessionLocal", MagicMock(return_value=cm)):
        with patch("gtm_admin.decorator._notify_drain"):
            await _execute_existing_run(my_workflow, 5, "my_workflow")

    assert calls == [{"x": 42}]
    assert pending_run.status == WorkflowStatus.success


@pytest.mark.asyncio
async def test_drain_loop_fills_all_free_slots():
    """When max_concurrent_runs increases (e.g. 1→10), drain loop should launch
    all free slots at once rather than one per completion event."""
    from gtm_admin.decorator import _drain_events, _drain_loop, _get_drain_event

    # Use a unique name to avoid cross-test state
    WF = "drain_fill_test"
    _drain_events.pop(WF, None)

    # 1 run already running, limit 4 → 3 free slots
    cfg = Workflow(id=10, name=WF, max_concurrent_runs=4)
    pending = [
        WorkflowRun(
            id=i, workflow_id=10, status=WorkflowStatus.pending,
            triggered_by="manual",
            data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}},
        )
        for i in (1, 2, 3)
    ]

    mock_cfg_r = MagicMock()
    mock_cfg_r.first = MagicMock(return_value=cfg)
    mock_pending_r = MagicMock()
    mock_pending_r.all = MagicMock(return_value=pending)
    mock_count_r = MagicMock()
    mock_count_r.scalar_one = MagicMock(return_value=1)  # 1 already running

    exec_n = 0

    async def _mock_exec(stmt):
        nonlocal exec_n
        exec_n += 1
        return mock_cfg_r if exec_n == 1 else mock_pending_r

    session = AsyncMock()
    session.exec = _mock_exec
    session.execute = AsyncMock(return_value=mock_count_r)

    cm = AsyncMock()
    cm.__aenter__ = AsyncMock(return_value=session)
    cm.__aexit__ = AsyncMock(return_value=None)

    executed: list[int] = []

    async def fake_execute(fn, run_id, name):
        executed.append(run_id)

    async def my_workflow(inputs: dict): ...

    with patch("gtm_admin.decorator._SessionLocal", MagicMock(return_value=cm)):
        with patch("gtm_admin.decorator._execute_existing_run", side_effect=fake_execute):
            # Start drain loop DIRECTLY — autouse fixture patches _ensure_drain_task,
            # so we bypass it to get a real task.
            drain_task = asyncio.create_task(_drain_loop(WF, my_workflow))

            # Wake it
            _get_drain_event(WF).set()

            # Enough ticks for: event.wait, __aenter__, 2×exec, __aexit__,
            # then the spawned fake_execute tasks to run.
            for _ in range(15):
                await asyncio.sleep(0)

            drain_task.cancel()
            try:
                await drain_task
            except asyncio.CancelledError:
                pass

    # free_slots = 4 - 1 = 3 — should launch exactly 3 tasks, not just 1
    assert len(executed) == 3
    assert set(executed) == {1, 2, 3}

    _drain_events.pop(WF, None)

@pytest.mark.asyncio
async def test_cancelled_error_skips_db_write():
    """When the workflow task is cancelled mid-flight, the decorator must not
    overwrite the DB status (the cancel endpoint already wrote 'cancelled')."""

    commit_calls = []

    async def slow_workflow(inputs: dict):
        # Simulate a long-running step — cancellation injects CancelledError here
        await asyncio.sleep(9999)

    cfg = Workflow(id=1, name="slow_workflow")
    run = WorkflowRun(
        id=7,
        workflow_id=1,
        status=WorkflowStatus.running,
        triggered_by="manual",
        started_at=datetime.now(timezone.utc),
        data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}},
    )

    mock_exec_result = MagicMock()
    mock_exec_result.first = MagicMock(return_value=cfg)

    async def _refresh(obj):
        if hasattr(obj, "id") and obj.id is None:
            obj.id = 1

    async def _commit():
        commit_calls.append(True)

    session = AsyncMock()
    session.exec = AsyncMock(return_value=mock_exec_result)
    session.add = MagicMock()
    session.commit = _commit
    session.refresh = _refresh

    cm = AsyncMock()
    cm.__aenter__ = AsyncMock(return_value=session)
    cm.__aexit__ = AsyncMock(return_value=None)

    with patch("gtm_admin.decorator._SessionLocal", _mock_session_local(cfg, running_count=0)):
        with patch("gtm_admin.decorator._notify_drain"):
            with patch("gtm_admin.broadcast.manager") as mock_mgr:
                mock_mgr.broadcast = AsyncMock()
                wrapper = make_workflow_wrapper(slow_workflow)
                outer_task = asyncio.create_task(wrapper({}))
                # Give the wrapper a tick to register the inner task, then cancel it
                await asyncio.sleep(0)
                await asyncio.sleep(0)
                inner_task = dec._running_tasks.get(1)  # run gets id=1 via _refresh
                if inner_task:
                    inner_task.cancel()
                try:
                    await outer_task
                except (asyncio.CancelledError, Exception):
                    pass

    # The commit for status=cancelled was done by the cancel *endpoint* (mocked out above).
    # The decorator itself must not have called session.add/commit a second time
    # after receiving CancelledError — confirmed by checking run.status was not
    # overwritten (it stays running because the endpoint mock didn't change it).
    assert run.status == WorkflowStatus.running  # decorator must not have mutated it


@pytest.mark.asyncio
async def test_cancelled_error_removed_from_running_tasks():
    """After cancellation, the run ID must be removed from _running_tasks."""

    async def slow_workflow(inputs: dict):
        await asyncio.sleep(9999)

    cfg = Workflow(id=1, name="slow_workflow")

    with patch("gtm_admin.decorator._SessionLocal", _mock_session_local(cfg, running_count=0)):
        with patch("gtm_admin.decorator._notify_drain"):
            with patch("gtm_admin.broadcast.manager") as mock_mgr:
                mock_mgr.broadcast = AsyncMock()
                wrapper = make_workflow_wrapper(slow_workflow)
                outer_task = asyncio.create_task(wrapper({}))
                await asyncio.sleep(0)
                await asyncio.sleep(0)
                inner_task = dec._running_tasks.get(1)
                if inner_task:
                    inner_task.cancel()
                try:
                    await outer_task
                except (asyncio.CancelledError, Exception):
                    pass

    assert 1 not in dec._running_tasks
